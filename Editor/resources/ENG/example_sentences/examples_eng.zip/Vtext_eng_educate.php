<G-vec00531-002-s246><educate.aufklären><en> We trained and financially supported ten theatre groups in the south and east of Sierra Leone who educate communities through drama performances on Ebola
<G-vec00531-002-s246><educate.aufklären><de> Zehn Theatergruppen im Süden und Osten von Sierra Leone wurden von uns ausgebildet und finanziell unterstützt, um Gemeinden durch Theaterdarbietungen über Ebola aufzuklären.
<G-vec00531-002-s247><educate.aufklären><en> Dental professionals are a great resource as they can educate teens about the hazards and potential complications of oral piercings.
<G-vec00531-002-s247><educate.aufklären><de> Zahnärzte sind gute Ansprechpartner, um Teenager über die Gefahren und möglichen Komplikationen von Mundpiercings aufzuklären.
<G-vec00531-002-s090><educate.ausbilden><en> With this GWO certification Avanti Wind Systems states that the company also will train and educate anyone working in wind turbines in the same high standards.
<G-vec00531-002-s090><educate.ausbilden><de> Mit der neuen GWO Zertifizierung stellt Avanti Wind Systems sicher, dass jeder Trainee nach den gleichen hohen Sicherheitsstandards ausgebildet wird.
<G-vec00531-002-s091><educate.ausbilden><en> I believe solutions should include an expanded Erasmus scheme, student exchanges and scholarships, as well as plans to create the Eastern Partnership University that would educate, at graduate level, the future personnel of the country.
<G-vec00531-002-s091><educate.ausbilden><de> Zu den möglichen Lösungsansätzen gehören nach meinem Dafürhalten eine Ausweitung des Erasmus-Programms, Studentenaustausche und Stipendien sowie die Gründung der Universität der Östlichen Partnerschaft, an der das zukünftige Führungspersonal des Landes auf Hochschulniveau ausgebildet würde.
<G-vec00531-002-s107><educate.beibringen><en> Times are changing fast, and one thing you can do to make your grandchild feel special is to ask him or her to educate you about what’s going on in the world, from the latest trends in music to Facebook or Twitter.
<G-vec00531-002-s107><educate.beibringen><de> Die Zeiten verändern sich schnell und eine Sache, die du tun kannst, um dafür zu sorgen, dass dein Enkelkind sich besonders fühlt, liegt darin, ihn oder sie zu bitten, dir beizubringen, was in der Welt so los ist, von den neuesten Musiktrends bis hin zu Facebook oder Twitter.
<G-vec00531-002-s108><educate.beibringen><en> His purpose is to educate you on making money gambling, plain and simple.
<G-vec00531-002-s108><educate.beibringen><de> Sein Zweck ist es, Ihnen schlicht und einfach beizubringen, wie man Geld durch Glücksspiel verdient.
<G-vec00531-002-s109><educate.belehren><en> This is something you need to know in order to recognise the value of what such a being of light mentally imparts to you when it works on My instructions in order to educate you....
<G-vec00531-002-s109><educate.belehren><de> Dieses müsset ihr wissen, um nun auch den Wert dessen zu erkennen, was ein solches Lichtwesen euch gedanklich vermittelt, wenn es in Meinem Auftrag tätig ist, um euch zu belehren....
<G-vec00531-002-s110><educate.belehren><en> Correction: King Michael Moore is stooping down to PERSONALLY educate his German audience and the German media on the misdeeds of George Bush and the stupidity of Americans.
<G-vec00531-002-s110><educate.belehren><de> Korrektur: König Michael Moore läßt sich dazu herab, das deutsche Publikum und die deutschen Medien PERSÖNLICH über die Untaten von George Bush und die Dummheit der Amerikaner zu belehren.
<G-vec00531-002-s111><educate.belehren><en> And precisely this teaching material should be seriously scrutinised by you if you want to educate your fellow human beings, because only that which came forth from Me as pure truth is a blessing.
<G-vec00531-002-s111><educate.belehren><de> Und gerade dieses Lehrgut solltet ihr einer ernsten Prüfung unterziehen, wenn ihr eure Mitmenschen belehren wollet, weil nur das von Segen ist, was von Mir als reine Wahrheit ausgegangen ist.
<G-vec00531-002-s112><educate.belehren><en> It is God's will that people should read every Word with complete sincerity, with the desire for truth and in contact with Him.... so that God Himself can speak to them, and then He will truly educate and enlighten them correctly.
<G-vec00531-002-s112><educate.belehren><de> Und es ist dies von Gott aus so gewollt, daß die Menschen mit rechtem Ernst, im Verlangen nach Wahrheit und in Verbindung mit Ihm ein jedes Wort lesen sollen.... auf daß dann Gott Selbst zu ihnen sprechen kann, Der sie dann wahrlich auch recht belehren und aufklären wird.
<G-vec00531-002-s041><educate.betreiben><en> In order to prevent this we have to spay and neuter intensely in Boca Chica in the coming years and educate the local residents.
<G-vec00531-002-s041><educate.betreiben><de> Also müssen wir in ganz Boca Chica in den kommenden Jahren intensiv kastrieren und Aufklärung betreiben.
<G-vec00531-002-s042><educate.betreiben><en> Above all, campaigns to educate the public are vital.
<G-vec00531-002-s042><educate.betreiben><de> Man kann und muss vor allem Aufklärung betreiben.
<G-vec00531-002-s113><educate.bilden><en> I educate them about what they are dealing with and teach them not only methods of protection and extraction, but the deep rewarding experience of healing based in love.
<G-vec00531-002-s113><educate.bilden><de> Ich bilde sie darin aus, womit sie umgehen und lehre sie nicht nur Methoden des Schutzes und der Extraktion, sondern auch die tiefe belohnende Erfahrung der Heilung, die in der Liebe begründet ist.
<G-vec00531-002-s114><educate.bilden><en> Educate yourself about the condition, but don't try to replace your doctor.
<G-vec00531-002-s114><educate.bilden><de> Bilde dich selbst über die Krankheit, aber versuche nicht, deinen Arzt zu ersetzen.
<G-vec00531-002-s145><educate.bringen><en> We educate children about health and wellbeing, encouraging self-confidence and independence while using team activities to help develop positive interaction with peers.
<G-vec00531-002-s145><educate.bringen><de> Wir bringen den Kindern ein Gefühl für Gesundheit und Wellness bei, fördern Selbstvertrauen und Unabhängigkeit und unterstützen die positive Interaktion mit Gleichaltrigen.
<G-vec00531-002-s146><educate.bringen><en> We will educate you how to behave as a conservative and safe practicing diver.
<G-vec00531-002-s146><educate.bringen><de> Wir bringen Ihnen bei, wie man sich als sicherer Taucher verhält.
<G-vec00531-002-s147><educate.bringen><en> In Autumn 1945 Albert Szent-Györgyi, professor of biochemistry at the Medical Faculty of the University Peter Pázmány of those times, suggested that the University should create a “medical chemistry” department to educate the medical students.
<G-vec00531-002-s147><educate.bringen><de> Im Herbst 1945 hat Albert Szent-Györgyi, Professor der Biochemie an der Medizinischen Fakultät der damaligen Pázmány Péter-Universität vorgeschlagen, für die Ausbildung von Medizinstudenten einen Lehrstuhl für medizinische Chemie zustande zu bringen.
<G-vec00531-002-s148><educate.bringen><en> Team Lunette is doing a lot more than making and selling the best menstrual cups and products on the market — we aim to educate and inform the wonderful world of women.
<G-vec00531-002-s148><educate.bringen><de> Wir bieten aber viel mehr als nur die besten Menstruationskappen am Markt an – unser Ziel ist es, dir die wunderbare Welt des Frauseins näher zu bringen und darüber zu informieren.
<G-vec00531-002-s180><educate.erziehen><en> Educate your young people to the sobriety that alone makes light the heart and enables it to reach upwards, to seek God.
<G-vec00531-002-s180><educate.erziehen><de> Erzieht eure Jugend zur Genügsamkeit, denn sie allein erlaubt uns, leichten Herzens nach oben zu schauen, um Gott zu suchen.
<G-vec00531-002-s181><educate.erziehen><en> God, however, does not tire, God has patience, He has a great deal of patience, and in time continues to educate and to form His people, as a father with His own child.
<G-vec00531-002-s181><educate.erziehen><de> Gott wird jedoch nicht müde, Gott hat Geduld, er hat viel Geduld, und in der Zeit erzieht und bildet er weiterhin sein Volk, wie ein Vater seinen eigenen Sohn.
<G-vec00531-002-s233><educate.erzählen><en> Our skilled guide will educate you about the glacier: how it’s formed, how it moves, and how it retreats.
<G-vec00531-002-s233><educate.erzählen><de> Unser fähiger Guide wird Ihnen mehr über den Gletscher erzählen: wie er entsteht, sich bewegt und zurückzieht.
<G-vec00531-002-s234><educate.erzählen><en> All cruises are narrated by expert captains who will educate you on the abundant ocean life on the coast.
<G-vec00531-002-s234><educate.erzählen><de> Alle Bootstouren werden von Kommentaren fachkundiger Kapitäne begleitet, die Ihnen mehr über die Vielfalt an Leben an der Küste erzählen.
<G-vec00531-002-s192><educate.fortbilden><en> In education, the network continues to expand access to quality teaching resources, so that people of every socioeconomic background have a chance to educate themselves and participate in the global economy.
<G-vec00531-002-s192><educate.fortbilden><de> Im Bildungssektor ermöglichen Netzwerke wachsenden Zugriff auf hochwertige Lehrmittel, damit alle Menschen unabhängig von ihrem sozio-ökonomischen Hintergrund die Möglichkeit haben, sich fortzubilden und Teil der Weltwirtschaft zu sein.
<G-vec00531-002-s193><educate.fortbilden><en> Its aim is to inform and continue to educate the industry on technical innovations and developments.
<G-vec00531-002-s193><educate.fortbilden><de> Ziel ist es, die Branche über technische Innovationen und Entwicklungen zu informieren und fortzubilden.
<G-vec00531-002-s194><educate.geben><en> Educate or entertain readers with audio and video, placed directly on the pages of your flipbooks.
<G-vec00531-002-s194><educate.geben><de> Geben Sie Ihren Lesern unterhaltende und bildende Inhalte mit Audio und Video, welche Sie direkt auf den Seiten Ihres Flipbooks platzieren.
<G-vec00531-002-s195><educate.geben><en> We educate young men to a profession in the metal-industry, because well-educated and motivated employees are undispensable for the future success of our company and our society.
<G-vec00531-002-s195><educate.geben><de> Wir geben jungen Menschen eine Ausbildung und einen Beruf in der Metall-Industrie, weil ausgebildete und motivierte Mitarbeiter unverzichtbar sind für den zukünftigen Erfolg unseres Unternehmens und unserer Gesellschaft.
<G-vec00531-002-s196><educate.geben><en> Furthermore, she suggests that more responsible coverage that educate the varied regions and countries of Africa would be essential for the future.
<G-vec00531-002-s196><educate.geben><de> Sie schlägt auch vor, dass es mehr verantwortliche Berichterstattung geben sollte, die über die unterschiedlichen Regionen und Länder in Afrika berichtet und es essentiell für die Zukunft ist.
<G-vec00531-002-s219><educate.informieren><en> The ambassadors educate fellow students about their rights and what to do if they face any sign of bullying.
<G-vec00531-002-s219><educate.informieren><de> Die Botschafter informieren ihre Mitschüler über ihre Rechte und darüber, was zu tun ist, wenn sie mit Anzeichen von Mobbing konfrontiert werden.
<G-vec00531-002-s220><educate.informieren><en> Educate customers on energy efficiency or answer questions on topics such as the costs of running household appliances or the selection of energy efficient appliances.
<G-vec00531-002-s220><educate.informieren><de> Informieren Sie Ihre Kunden über Energieeffizienz oder beantworten Sie Fragen zu Themen wie Betriebskosten von Haushaltsgeräten oder die Auswahl energieeffizienter Geräte.
<G-vec00531-002-s221><educate.klären><en> Disseminating knowledge: We educate local populations about vector-borne diseases and teach them the skills they need to prevent infections in their specific surroundings.
<G-vec00531-002-s221><educate.klären><de> Wissensaufbau: Wir klären die lokale Bevölkerung über vektorübertragende Krankheiten auf und vermitteln ihnen entsprechende Kompetenzen zur Prävention in ihrem Lebensumfeld.
<G-vec00531-002-s222><educate.klären><en> With our initiative "MESSAGE!" we educate our trainees on healthcare and addiction prevention in a targeted manner.
<G-vec00531-002-s222><educate.klären><de> Im Rahmen unserer Initiative „MESSAGE!“ klären wir unsere Auszubildenden gezielt über Gesundheitsvorsorge und Suchtprävention auf.
<G-vec00531-002-s223><educate.klären><en> Educate users about the whys and hows of your policies.
<G-vec00531-002-s223><educate.klären><de> Klären Sie die Benutzer über das Wie und Warum Ihrer Richtlinien auf.
<G-vec00531-002-s224><educate.klären><en> With this data privacy statement, we would like to educate you in accordance with the provisions of the EU Regulation 2016/679 (General Data Protection Regulation - GDPR) on the nature, extent and purpose of the processing of personal data in connection with our website.
<G-vec00531-002-s224><educate.klären><de> Mit dieser Datenschutzerklärung klären wir Sie als für die Datenverarbeitung Verantwortliche gemäß den Vorgaben der Verordnung (EU) 2016/679 (Datenschutz-Grundverordnung – DSGVO) über Art, Umfang und Zweck der Verarbeitung personenbezogener Daten im Zusammenhang mit unserem Internetangebot auf.
<G-vec00531-002-s225><educate.lehren><en> Individual therapy plans, relevant assessments, motivating exercises and visualization of movements help the therapist educate correct movements and improve the patient's movement awareness.
<G-vec00531-002-s225><educate.lehren><de> Individuelle Therapiepläne, klinische Assessments, motivierende Übungen und die Visualisierung der Bewegungen unterstützen den Therapeuten dabei, korrekte Bewegungsabläufe zu lehren und das Bewegungsbewusstsein des Patienten zu verbessern.
<G-vec00531-002-s226><educate.lehren><en> We educate our boys to be similar units of masculinity and then to vie with one another for economic and symbolic superiority.
<G-vec00531-002-s226><educate.lehren><de> Wir lehren alle Buben eine bestimmte Art von Maskulinität, auf deren Basis sie dann als Männer um ökonomische und symbolische Vorherrschaft kämpfen.
<G-vec00531-002-s227><educate.lehren><en> I don’t want him to send me crazy emails with ‘links to cults’ so he can ‘educate’ me.
<G-vec00531-002-s227><educate.lehren><de> Ich will nicht, dass er mir verrückte E-Mails mit Links zu ‘Sekten’ schickt, so dass er mich ‘lehren’ kann.
<G-vec00531-002-s228><educate.lehren><en> It is also a great instrument to educate to what is beautiful and good.
<G-vec00531-002-s228><educate.lehren><de> Es ist außerdem ein großartiges Instrument, um zu lehren, was schön und gut ist.
<G-vec00531-002-s229><educate.lehren><en> I believe that religion should practice and educate others in the heavenly principle of seeking the happiness of others before our own.
<G-vec00531-002-s229><educate.lehren><de> Ich glaube, dass Religion selbst den Weg des himmlischen Prinzips "zuerst das Wohl des anderen zu suchen" praktizieren und anderen lehren soll.
<G-vec00531-002-s230><educate.machen><en> So before you snag an image off the web, educate yourself.
<G-vec00531-002-s230><educate.machen><de> Bevor Sie also ein Bild aus dem Netz holen, machen Sie sich schlau.
<G-vec00531-002-s231><educate.machen><en> She is currently working to educate and engage the broader public about the latest developments in creative AI through monthly talks, tech demonstrations and art performances.
<G-vec00531-002-s231><educate.machen><de> Derzeit arbeitet sie daran, die neuesten Entwicklungen der kreativen KI in regelmäßigen Vorträgen, Technologievorführungen und Kunstperformances einer breiteren Öffentlichkeit zugänglich zu machen.
<G-vec00531-002-s232><educate.machen><en> This money helped to build a school for at-risk girls in Kenya, to educate girls in Afghanistan, support girls and their families in Vietnam, and fund many other vital charities and their projects. The Xaxis strategy
<G-vec00531-002-s232><educate.machen><de> Mithilfe dieses Geldes konnten wir in Kenia eine Schule für notleidende Mädchen bauen, Mädchen in Afghanistan Bildungsangebote machen, Mädchen und ihre Familien in Vietnam unterstützen sowie viele andere wichtige Wohltätigkeitsorganisationen und ihre Projekte finanzieren.
<G-vec00531-002-s235><educate.schulen><en> It’s your job to educate, inform, inspire, and build interest before recommending a product.
<G-vec00531-002-s235><educate.schulen><de> Es ist Deine Aufgabe sie zu informieren, zu schulen, zu inspirieren und ihr Interesse zu wecken, bevor Du ihnen ein Produkt empfiehlst.
<G-vec00531-002-s236><educate.schulen><en> We’ll set up demos, educate the customer, manage PoCs, answer any questions, and support you every step of the way.
<G-vec00531-002-s236><educate.schulen><de> Wir organisieren Demos, schulen Kunden, managen "Proof-of-concepts", beantworten Fragen und unterstützen Sie, wo immer wir können.
<G-vec00531-002-s237><educate.schulen><en> Safety We carefully certify and educate the operators at all our LuggageHero Rome storage lockers about how to safely handle your belongings.
<G-vec00531-002-s237><educate.schulen><de> Wir zertifizieren und schulen die Betreiber aller unserer Luggage-Hero-Standorte in Berlin in Bezug auf den sicheren Umgang mit Ihrem Gepäck.
<G-vec00531-002-s238><educate.schulen><en> Actually, I will teach / educate / train my body to fight.
<G-vec00531-002-s238><educate.schulen><de> Sie werden praktisch meinen Organismus zum Kampf ausbilden/ schulen/ trainieren.
<G-vec00531-002-s239><educate.schulen><en> Finally, for next year we wil plan to conduct a tour with a small group of experts to Ghana with the mission to educate caring and interested members.
<G-vec00531-002-s239><educate.schulen><de> Zu guter Letzt haben wir vor, für kommendes Jahr die Durchführung einer Reise mit einer kleinen Gruppe Fachkräfte nach Ghana zu unternehmen, um pflegende und interessierte Angehörige zu schulen.
<G-vec00531-002-s240><educate.schulen><en> Use the information you get from Kinesis to educate your drivers, incentivise them to adapt their driving style, and reduce fuel costs by more than 20%.
<G-vec00531-002-s240><educate.schulen><de> Verwenden Sie die Informationen, die Sie von Kinesis erhalten, um Ihre Fahrer zu schulen, sie zu motivieren, ihren Fahrstil anzupassen und die Kraftstoffkosten um mehr als 20% zu senken.
<G-vec00531-002-s241><educate.schulen><en> With CA API Management, you can use the developer portal to effectively engage, onboard, educate and manage partners and developers.
<G-vec00531-002-s241><educate.schulen><de> Mit CA API Management können Sie das Entwicklerportal nutzen, um Partner und Entwickler effektiv einzubeziehen, ihr Onboarding durchzuführen, sie zu schulen und sie zu managen.
<G-vec00531-002-s242><educate.schulen><en> We want to contribute to the debate on the ethical boundaries of digital technologies and educate our employees, partners and the public.
<G-vec00531-002-s242><educate.schulen><de> Wir möchten dazu beitragen, die ethischen Grenzen der Digitaltechnik zu diskutieren und unsere Mitarbeiter, Partner und die Öffentlichkeit zu schulen.
<G-vec00531-002-s243><educate.schulen><en> Because the FSF endorsed the Principles of Community-Oriented GPL Enforcement, you can rest assured that your report will help to educate the violator rather than punish them for their mistake.
<G-vec00531-002-s243><educate.schulen><de> Da die FSF die Grundsätze der gemeinschaftsorientierten GPL-Durchsetzung gutheißt, können Sie sicher sein, dass Ihr Bericht dazu beitragen wird, (mögliche) Verletzer zu schulen, anstatt für Fehler zu bestrafen.
<G-vec00531-002-s248><educate.unterrichten><en> Educate instead of criticize when correcting someone.
<G-vec00531-002-s248><educate.unterrichten><de> Unterrichte, statt zu kritisieren, wenn du jemanden korrigierst.
<G-vec00531-002-s249><educate.unterrichten><en> Support the administrative staff in hospitals and clinics, educate Jamaican locals about hygiene, illness prevention, nutrition, and many other topics.
<G-vec00531-002-s249><educate.unterrichten><de> Entlaste die Verwaltungskräfte in Krankenhäusern und Kliniken, unterrichte Einwohner in Sachen Hygiene, Krankheitsvorbeugung, Ernährung und vielen anderen Themen.
<G-vec00531-002-s271><educate.vermitteln><en> Ahead of the FIFA U-20 Women’s World Cup France 2018, players took part in a first of a new series of ethics workshops (EWS) aiming to help educate football’s next generation.
<G-vec00531-002-s271><educate.vermitteln><de> Im Vorfeld der FIFA U-20-Frauen-Weltmeisterschaft Frankreich 2018 nahmen die Spielerinnen an einer erstmals veranstalteten Reihe von Ethik-Workshops teil, die der neuen Generation wichtige Inhalte vermitteln soll.
<G-vec00531-002-s272><educate.vermitteln><en> It aimed to educate both parts of the population about each other's backgrounds, stimulate learning processes, and encourage mutual understanding.
<G-vec00531-002-s272><educate.vermitteln><de> Ziel ist es, in beiden Teilen der Bevölkerung gegenseitiges Wissen zu vermitteln, Lernprozesse anzustoßen und Verständnis zu erzeugen.
<G-vec00531-002-s273><educate.vermitteln><en> These buildings are open to the public to educate visitors about sustainable construction.
<G-vec00531-002-s273><educate.vermitteln><de> Diese Gebäude sind für die Öffentlichkeit zugänglich, um Besuchern Informationen über nachhaltiges Bauen zu vermitteln.
<G-vec00531-002-s274><educate.vermitteln><en> Our goal: To educate everyday Internet users about ciphers and the basics of encryption.
<G-vec00531-002-s274><educate.vermitteln><de> Unser Ziel: Allen Internetnutzern Chiffren näherzubringen und ihnen die Grundlagen von Verschlüsselung zu vermitteln.
<G-vec00531-002-s275><educate.weiterbilden><en> The offer is available to you around the clock – you can continue to educate yourself whenever you want and increase your competence step by step.
<G-vec00531-002-s275><educate.weiterbilden><de> Das Angebot steht Ihnen rund um die Uhr zur Verfügung – Sie können sich weiterbilden, wann immer Sie wollen und Schritt für Schritt Ihre Kompetenz steigern.
<G-vec00531-002-s276><educate.weiterbilden><en> Literacy We can’t solve misinformation with technology alone—we also need to educate and empower Internet users, as well as those leading innovative literacy initiatives.
<G-vec00531-002-s276><educate.weiterbilden><de> Wir können ‘Fake News‘ nicht allein auf technischem Weg begegnen – wir müssen auch die Internetnutzer weiterbilden und stärken sowie den Leitern innovativer Bildungsinitiativen unter die Arme greifen.
<G-vec00531-002-s277><educate.weiterbilden><en> He led a study which found out why seniors want to educate themselves further in older age.
<G-vec00531-002-s277><educate.weiterbilden><de> Er leitete eine Studie darüber, wie und warum sich Senioren im hohen Alter noch weiterbilden möchten.
<G-vec00531-002-s278><educate.weiterbilden><en> Your employees/students would have constant access to important information and knowledge resources, and could continue to educate themselves decentrally and on their own time.
<G-vec00531-002-s278><educate.weiterbilden><de> So können Ihre Mitarbeiter oder Schüler immer auf wichtige Wissensressourcen zugreifen und sich dezentral und nach eigenem Stundenplan fort- und weiterbilden.
<G-vec00531-002-s279><educate.weiterbilden><en> We all have to educate and in some areas re-educate ourselves constantly.
<G-vec00531-002-s279><educate.weiterbilden><de> Wir alle müssen uns ständig weiterbilden.
<G-vec00531-002-s280><educate.weiterbilden><en> Together, we had to develop a number of new methods and continually educate ourselves further.
<G-vec00531-002-s280><educate.weiterbilden><de> Gemeinsam mussten wir neue Methoden entwickeln und uns beständig weiterbilden.
<G-vec00531-002-s281><educate.weiterbilden><en> We would also like to inform, support and educate our clients, partners and readers in this New Year on current, exciting topics related to the working world.
<G-vec00531-002-s281><educate.weiterbilden><de> In spannenden und aktuellen Themen der Arbeitswelt möchten wir auch im neuen Jahr unsere Kunden, Partner und Leser weiterbilden, unterstützen und informieren.
<G-vec00531-002-s282><educate.weiterbilden><en> "With the next millennium just around the corner, developing this High Definition TV quality image of the full disk of the continuously lit Earth and making it available 24 hours a day on the Internet will awaken a new generation to the environment and educate millions of children around the globe.
<G-vec00531-002-s282><educate.weiterbilden><de> "Mit dem kommenden Millennium in Reichweite wird dieses HDTV Bild der vollständigen und sonnenbeschienenen Erde 24 Stunden am Tag im Internet zur Verfügung stehen und eine neue Generation für die Umwelt erwecken und Millionen Kinder in aller Welt weiterbilden.
<G-vec00531-002-s283><educate.weiterbilden><en> With our numerous courses you can further educate yourself effectively and intensively, no matter what knowledge you started out with.
<G-vec00531-002-s283><educate.weiterbilden><de> Denn in unseren zahlreichen Kursen können Sie sich effektiv und intensiv weiterbilden, ganz gleich, mit welchem Kenntnisstand Sie starten.
<G-vec00531-002-s306><educate.überzeugen><en> On every stage the participants of the rally will educate how important the bees are for harmonious development of nature.
<G-vec00531-002-s306><educate.überzeugen><de> An jedem Halt werden die Teilnehmer der Rallye davon überzeugen, dass Bienen für die harmonische Entwicklung der Natur benötigt werden.
<G-vec00531-002-s307><educate.überzeugen><en> Events, events, events are what are necessary to educate the masses in the necessity of a revolutionary transformation of society.
<G-vec00531-002-s307><educate.überzeugen><de> Ereignisse, Ereignisse, Ereignisse werden notwendig sein, um die Massen von der Notwendigkeit einer revolutionären Umwandlung der Gesellschaft zu überzeugen.
