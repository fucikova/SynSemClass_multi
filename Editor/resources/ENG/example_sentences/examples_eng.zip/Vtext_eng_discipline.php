<G-vec00484-002-s107><discipline.disziplinieren><en> The future agents of national security are accustomed to discipline from the first days.
<G-vec00484-002-s107><discipline.disziplinieren><de> Die zukünftigen Militärs werden von den ersten Tagen diszipliniert.
<G-vec00484-002-s108><discipline.disziplinieren><en> The second time around, Real did not execute this strategy with as much pressure and discipline as in the Santiago Bernabeu.
<G-vec00484-002-s108><discipline.disziplinieren><de> Real spielte diese Strategie beim zweiten Mal nicht so druckvoll und diszipliniert aus, wie im Santiago Bernabeu.
<G-vec00484-002-s109><discipline.disziplinieren><en> I feel such a responsibility to instill good values in her, to be polite, to have discipline.
<G-vec00484-002-s109><discipline.disziplinieren><de> Ich fühle mich verantwortlich ihr gute Werte zu vermitteln, höflich und diszipliniert zu sein.
<G-vec00484-002-s110><discipline.disziplinieren><en> M: To pursue plans with discipline and meditate every day.
<G-vec00484-002-s110><discipline.disziplinieren><de> M: Diszipliniert Pläne zu verfolgen und jeden Tag zu meditieren.
<G-vec00484-002-s111><discipline.disziplinieren><en> These can be used to discipline service providers that refuse to provide high-quality services.
<G-vec00484-002-s111><discipline.disziplinieren><de> Mit ihnen können Leistungserbringer diszipliniert werden, die sich der Qualitätsarbeit verweigern.
<G-vec00484-002-s112><discipline.disziplinieren><en> Embrace Discipline – never, ever let your colleagues or customers down.
<G-vec00484-002-s112><discipline.disziplinieren><de> Sei diszipliniert – lass deine Kollegen oder Kunden niemals im Stich.
<G-vec00484-002-s350><discipline.züchtigen><en> Discipline your son, for in that there is hope; do not be a willing party to his death (19:18, NIV).
<G-vec00484-002-s350><discipline.züchtigen><de> Züchtige deinen Sohn, denn darin liegt die Hoffnung; Lass dich nicht hinreißen, zu seinem Tod beizutragen (19:18, NIV).
<G-vec00484-002-s351><discipline.züchtigen><en> 17 Discipline your child, and he will give you rest; he will bring you happiness.
<G-vec00484-002-s351><discipline.züchtigen><de> 17 Züchtige deinen Sohn, so wird er dich ergötzen und wird deiner Seele sanft tun.
<G-vec00484-002-s352><discipline.züchtigen><en> 19:18 Discipline your son, for in that there is hope; do not be a willing party to his death.
<G-vec00484-002-s352><discipline.züchtigen><de> 19:18 Züchtige deinen Sohn, solange Hoffnung da ist, aber laß dich nicht hinreißen, ihn zu töten.
<G-vec00484-002-s353><discipline.züchtigen><en> 19 Those whom I love I rebuke and discipline.
<G-vec00484-002-s353><discipline.züchtigen><de> 19Ich überführe und züchtige, so viele ich liebe.
<G-vec00484-002-s354><discipline.züchtigen><en> 19 Those whom I love, I reprove and discipline, so be zealous and repent.
<G-vec00484-002-s354><discipline.züchtigen><de> 19 Alle, die ich lieb habe, die überführe und züchtige ich.
<G-vec00484-002-s355><discipline.züchtigen><en> I discipline my body and bring it into subjection, 1 Cor. 9:27.
<G-vec00484-002-s355><discipline.züchtigen><de> Ich züchtige und unterwerfe meinen Leib, 1 Kor 9:27.
