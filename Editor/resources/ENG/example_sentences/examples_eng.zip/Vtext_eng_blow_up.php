<G-vec00599-002-s019><blow_up.abblasen><en> The lack of such material is its ease, it can blow off strong gusts of wind.
<G-vec00599-002-s019><blow_up.abblasen><de> Der Mangel an solchem Material ist seine Leichtigkeit, es kann starke Windböen abblasen.
<G-vec00599-002-s020><blow_up.abblasen><en> The pluses include the ability to blow off and clean.
<G-vec00599-002-s020><blow_up.abblasen><de> Zu den Pluspunkten gehört die Fähigkeit zum Abblasen und Reinigen.
<G-vec00599-002-s021><blow_up.abblasen><en> After that blow off the balls and hide in such places of the apartment that the child could easily find it.
<G-vec00599-002-s021><blow_up.abblasen><de> Danach die Bälle abblasen und sich an solchen Stellen der Wohnung verstecken, dass das Kind es leicht finden könnte.
<G-vec00599-002-s022><blow_up.abblasen><en> With standard blast nozzles in front of sensing rollers to blow away chips in front of sensing areas.
<G-vec00599-002-s022><blow_up.abblasen><de> Mit serienmäßigen Blasdüsen vor den Tastrollenzum Abblasen von Spänen vor den Tastbereichen.
<G-vec00599-002-s023><blow_up.abblasen><en> With the pressure decreased through the blow down, large quantities of gaseous and vaporisable radioactive substances – in particular noble gases, iodine and caesium – escaped from the reactor vessel and entered the surrounding atmosphere.
<G-vec00599-002-s023><blow_up.abblasen><de> Freisetzung von Radioaktivität Mit der Druckabsenkung durch Abblasen gelangten große Mengen gasförmiger und verdampfbarer radioaktiver Stoffe – insbesondere Edelgase, Iod und Cäsium – aus dem Reaktorbehälter in die Umgebung.
<G-vec00599-002-s024><blow_up.abblasen><en> Approved for non-adhesive fluids, which are not vaporized during blow off.
<G-vec00599-002-s024><blow_up.abblasen><de> Zugelassen für nicht klebende Flüssigkeiten, unter der Voraussetzung, dass beim Abblasen keine Verdampfung eintritt.
<G-vec00599-002-s025><blow_up.abblasen><en> Application The unique way in which Air Amplifiers work makes them perfect for product drying or water blow off.
<G-vec00599-002-s025><blow_up.abblasen><de> Anwendung Die einzigartige Art und Weise, in der Luftverstärker arbeiten, macht sie für die Produkttrocknung oder Wasser Abblasen perfekt geeignet.
<G-vec00599-002-s030><blow_up.ausblasen><en> You should never blow out a candle, because if you blow out the flame, you blow away the good spirits, who like to gather around candles.
<G-vec00599-002-s030><blow_up.ausblasen><de> Man sollte niemals eine Kerze ausblasen, da sonst die guten Geister verschwinden, die sich gern um Kerzen ansammeln.
<G-vec00599-002-s031><blow_up.ausblasen><en> Tanabe: One new ability for Donkey Kong is the ability to blow out his breath.
<G-vec00599-002-s031><blow_up.ausblasen><de> Tanabe: Eine neue Fähigkeit von Donkey Kong ist, dass er seinen Atem ausblasen kann.
<G-vec00599-002-s032><blow_up.ausblasen><en> And the water froze before going into the cistern, and the pipes running water to the house from the cistern (which we had to disconnect and blow out to dry every time we got water).
<G-vec00599-002-s032><blow_up.ausblasen><de> Das Wasser war gefroren, bevor es in die Zisterne fließen konnte und die Rohre von der Zisterne zum Haus mussten wir jedes Mal unterbrechen und ausblasen, wenn wir Wasser gebraucht hatten.
<G-vec00599-002-s033><blow_up.ausblasen><en> This is the ideal installation situation, since the air can blow out without hindrance.
<G-vec00599-002-s033><blow_up.ausblasen><de> Dies stellt den idealen Einbaufall dar, da die Luft ungehindert ausblasen kann.
<G-vec00599-002-s034><blow_up.ausblasen><en> It may take up to 30 m³/h of air blow, the maximum attainable temperature is 650° C.
<G-vec00599-002-s034><blow_up.ausblasen><de> Es kann bis zu 30 m³/h Luft ausblasen, die maximal erreichbare Temperatur liegt bei 650 °C.
<G-vec00599-002-s035><blow_up.ausblasen><en> Let him shoot laser beams from his eyes, fire blow or perform other superhero skills to progress.
<G-vec00599-002-s035><blow_up.ausblasen><de> Lasse ihn Laserstrahlen aus den Augen schießen, Feuer ausblasen oder andere Superhelden-Fähigkeiten ausführen um weiter zu kommen.
<G-vec00599-002-s036><blow_up.ausblasen><en> Drill hole and blow out/brush.
<G-vec00599-002-s036><blow_up.ausblasen><de> Bohrloch erstellen und ausblasen/ausbürsten.
<G-vec00599-002-s037><blow_up.ausblasen><en> When the black part has melted a bit, blow out the flame (but it doesn't have to burn either, the plastic just has to become soft) and then press it flat with a small knife, spoon or similar, press it really flat.
<G-vec00599-002-s037><blow_up.ausblasen><de> Ist das schwarze Teil geschmolzen, die Flamme ausblasen (es muss aber auch nicht brennen, der Kunststoff muss nur weich werden) und dann entweder mit einem kleinen Messer, Löffel o. ä. platt drücken, richtig schön platt drücken.
<G-vec00599-002-s038><blow_up.ausblasen><en> The successful blow–down of the furnace is an absolute necessity to allow a successful salamander tap and quench, and ultimately a timely completion of the repair work itself.
<G-vec00599-002-s038><blow_up.ausblasen><de> Ein gelungenes Ausblasen/Niederfahren des Ofens ist ein absolutes Muß für einen erfolgreichen Sauabstich und Abkühlungsprozeß und letzten Endes für einen rechtzeitigen Abschluß der Reparaturarbeiten selbst.
<G-vec00599-002-s039><blow_up.ausblasen><en> The incense cones are lit at the top, then blow out the flame and burn on a fireproof surface.
<G-vec00599-002-s039><blow_up.ausblasen><de> Die Räucherkegel werden an der Spitze angezündet, die Flamme dann ausblasen und auf einer feuerfesten Unterlage abbrennen.
<G-vec00599-002-s040><blow_up.ausblasen><en> The adornments are mainly made by women who start many weeks before to blow out and paint chicken and goose eggs.
<G-vec00599-002-s040><blow_up.ausblasen><de> Der Schmuck an sich wird meistens von Frauen angefertigt, die bereits Wochen zuvor mit dem Ausblasen und Anmalen von Hühner- und Gänseeiern beginnen.
<G-vec00599-002-s173><blow_up.blasen><en> Our modern extruding equipment is used to blow polyethylene (PE) granulate into film...
<G-vec00599-002-s173><blow_up.blasen><de> An unseren modernen Extrudern werden Polyethylen (PE) -Granulate zu Folien geblasen...
<G-vec00599-002-s174><blow_up.blasen><en> Basically, the delivery boy not only gets to fuck the client but also a blow job through the pizza.
<G-vec00599-002-s174><blow_up.blasen><de> Um einfach zu machen, der Pizza Bote fickt die Kundin und wird durch die Pizza auch geblasen.
<G-vec00599-002-s175><blow_up.blasen><en> The cooling tubes are oriented to allow open passages for dirt and debris to blow through the core.
<G-vec00599-002-s175><blow_up.blasen><de> Die Kühlrohre sind so ausgerichtet, dass Staub und Schmutz durch den Kern geblasen werden können.
<G-vec00599-002-s176><blow_up.blasen><en> Charlotte`s web polyester screen is a flexible alternative to rigid insect screens, very easy to use, no fiddly catches, won`t blow off, bend or snap like other screens.
<G-vec00599-002-s176><blow_up.blasen><de> Charlottes Web-Polyester-Bildschirm ist eine flexible Alternative zu steifen Insektenschutzgittern, sehr einfach zu bedienen, keine kniffligen Fänge, wird nicht geblasen, gebogen oder gerissen wie andere Bildschirme.
<G-vec00599-002-s154><blow_up.föhnen><en> Ready to blow...
<G-vec00599-002-s154><blow_up.föhnen><de> Fertig zum Föhnen...
<G-vec00599-002-s155><blow_up.föhnen><en> Running a brush with natural bristles attached to the blow dryer through your hair from the scalp to the ends is especially gentle and therefore works best.
<G-vec00599-002-s155><blow_up.föhnen><de> Das anschließende Föhnen mit einer dicken Rundbürste – am besten mit schonenden Naturborsten – vom Ansatz zu den Spitzen sorgt für zusätzlichen Glanz, da dabei die Oberfläche geglättet wird.
<G-vec00599-002-s156><blow_up.föhnen><en> Do not blow dry, flat iron or use hair styling products the day after surgery or per your physician’s instructions.
<G-vec00599-002-s156><blow_up.föhnen><de> Nicht trocken föhnen, kein Glätteisen und keine Styling-Produkte am Tag nach Behandlung benutzen.
<G-vec00599-002-s157><blow_up.föhnen><en> We offer everything from dyeing, cutting, washing and blow drying to styling. More information
<G-vec00599-002-s157><blow_up.föhnen><de> Von Färben, Schneiden, Waschen und Föhnen über Styling bieten wir Ihnen alles an.
<G-vec00599-002-s158><blow_up.föhnen><en> If you want to use it as a heat shield, apply it on before blow drying or straightening the towel-dried hair.
<G-vec00599-002-s158><blow_up.föhnen><de> Wenn Sie es als Hitzeschutz verwenden wollen, tragen Sie es vor dem Föhnen oder Glätten im handtuchtrockenen Haar auf.
<G-vec00599-002-s159><blow_up.föhnen><en> Every Thursday: Men's complete package (wash, cut, blow dry, style) for € 10,-
<G-vec00599-002-s159><blow_up.föhnen><de> Donnerstags: Herren-Komplettpaket (waschen, schneiden, föhnen, stylen) für € 10,-.
<G-vec00599-002-s160><blow_up.föhnen><en> Apply 2-3 pumps to towel-dried hair and blow dry upside down.
<G-vec00599-002-s160><blow_up.föhnen><de> 2-3 Pumpenhübe auf handtuchtrockenes Haar geben und kopfüber Föhnen.
<G-vec00599-002-s161><blow_up.föhnen><en> Blow dry and style as desired.
<G-vec00599-002-s161><blow_up.föhnen><de> Föhnen und wie gewünscht stylen.
<G-vec00599-002-s162><blow_up.föhnen><en> If you want more volume, use the spray when blow drying, working it into the hair.
<G-vec00599-002-s162><blow_up.föhnen><de> Wenn Sie sich noch mehr Volumen wünschen, arbeiten Sie das Spray beim Föhnen in das Haar ein.
<G-vec00599-002-s163><blow_up.föhnen><en> Speaking of styling, it is not only stylish but also fast: just blow dry and define individual strands with a bit of styling wax.
<G-vec00599-002-s163><blow_up.föhnen><de> Apropos Styling, das ist nicht nur stylish, sondern auch schnell: Einfach trocken föhnen und mit etwas Styling-Wachs einzelne Strähnen definieren.
<G-vec00599-002-s164><blow_up.föhnen><en> Ideal for blow drying.
<G-vec00599-002-s164><blow_up.föhnen><de> Ideal für Föhnen.
<G-vec00599-002-s165><blow_up.föhnen><en> I have washed my hair and was about to blow, and they begin to style.
<G-vec00599-002-s165><blow_up.föhnen><de> Ich habe meine Haare gewaschen und wollte gerade anfangen sie zu föhnen und zu stylen.
<G-vec00599-002-s166><blow_up.föhnen><en> Alternatively spray into damp hair prior to blow drying for additional heat protection and shine.
<G-vec00599-002-s166><blow_up.föhnen><de> Alternativ in feuchtes Haar vor dem Föhnen für extra Hitzeschutz und Glanz einsprühen.
<G-vec00599-002-s167><blow_up.föhnen><en> Pureology Colour Fanatic Pureology Color Fanatic The light formula protects and perfects the hair while providing it with the combination of fennel extract, camellia, coconut and olive oil 21 benefits such as preventing frizz, making the blow dry easier, moisturizing, untangleing the hair etc.
<G-vec00599-002-s167><blow_up.föhnen><de> Die leichte Formel schützt und perfektioniert das Haar währenddessen es mit der Kombination aus Fenchel-Extrakt, Kamelien, Kokosnuss und Olivenöl dem Haar 21 Vorteile liefert z.B verhindert es Frizz, macht das föhnen leichter, spendet Feuchtigkeit, entwirrt die Haare etc.
<G-vec00599-002-s168><blow_up.föhnen><en> Then blow dry, and style as usual.
<G-vec00599-002-s168><blow_up.föhnen><de> Föhnen und frisieren Sie wie gewohnt.
<G-vec00599-002-s169><blow_up.föhnen><en> Simply distribute some mousse in damp hair and blow dry it strand by strand over a round brush.
<G-vec00599-002-s169><blow_up.föhnen><de> Verteilen Sie einfach etwas Schaumfestiger im feuchten Haar und föhnen Strähne für Strähne über einer Rundbürste trocken.
<G-vec00599-002-s170><blow_up.föhnen><en> Then blow dry downwards with a round brush to smooth the cuticles of your hair for a seductive sheen.
<G-vec00599-002-s170><blow_up.föhnen><de> Föhnen Sie Ihre Haare dann kopfüber mit einer Rundbürste glatt, um die Kutikula Ihrer Haare zu glätten, für einen verführerischen Glanz.
<G-vec00599-002-s171><blow_up.föhnen><en> Blow dry your hair into the shape you later want to style, to the back or to one side.
<G-vec00599-002-s171><blow_up.föhnen><de> Föhnen Sie das Haar so wie Sie es am Ende stylen möchten, also zum Beispiel nach hinten oder mit Seitenscheitel.
<G-vec00599-002-s172><blow_up.föhnen><en> If you want a semi-matt finish and smooth tips, apply the product on to your freshly washed hair and blow it then dry.
<G-vec00599-002-s172><blow_up.föhnen><de> Wenn Sie ein semi-mattes Finish und geschmeidige Spitzen wünschen, tragen Sie das Produkt auf Ihr frisch gewaschenes Haar auf und föhnen es anschließend.
<G-vec00599-002-s211><blow_up.jagen><en> You get into an automobile, you turn an ignition switch, and you set off a series of somewhere between four and eight explosions, and you have no fear that you’re going to blow up even though you have an internal combustion engine right at your knees.
<G-vec00599-002-s211><blow_up.jagen><de> Ihr steigt in ein Auto, schaltet die Zündung ein und löst eine Serie von vier bis acht Explosionen aus und habt keine Angst, euch selbst in die Luft zu jagen, obwohl direkt an euren Knien ein Verbrennungsmotor ist.
<G-vec00599-002-s212><blow_up.jagen><en> Personally, I'm hoping for the latter, because I'd rather not blow myself up.
<G-vec00599-002-s212><blow_up.jagen><de> Ich persönlich hoffe, es ist letzteres, denn eigentlich möchte ich mich nicht in die Luft jagen.
<G-vec00599-002-s213><blow_up.jagen><en> This scene also stands for the steady „survival of the Roma“, who are still there even if others blow up or destroy their homes.
<G-vec00599-002-s213><blow_up.jagen><de> Diese Szene steht auch für das stetige „Überleben der Roma“, die selbst dann noch da sind wenn andere ihre Häuser in die Luft jagen oder zerstören.
<G-vec00599-002-s214><blow_up.jagen><en> Said Mike Janov, VFX supervisor, SPY, “One of the things we did extensively in our shots for ‘Priest’ was blow stuff up.
<G-vec00599-002-s214><blow_up.jagen><de> Mike Janov, VFX Supervisor bei SPY, erklärt: „Für „Priest“ haben wir uns besonders ausführlich damit befasst, Sachen in die Luft zu jagen.
<G-vec00599-002-s215><blow_up.jagen><en> Convincing healthy individuals to blow themselves up is obviously not easy, but requires ideas and institutions.
<G-vec00599-002-s215><blow_up.jagen><de> Gesunde Individuen davon zu überzeugen sich selbst in die Luft zu jagen, ist offenbar nicht leicht, sondern bedarf Ideen und Institutionen.
<G-vec00599-002-s216><blow_up.jagen><en> Those bastards have sent a bunch of idiots that are going to blow up the whole area.
<G-vec00599-002-s216><blow_up.jagen><de> Jene Bastarde haben eine Gruppe von Idioten geschickt, die das ganze Gebiet in die Luft jagen werden.
<G-vec00599-002-s217><blow_up.jagen><en> You were sent to blow up the base.
<G-vec00599-002-s217><blow_up.jagen><de> Du wurdest geschickt, um die Basis in die Luft zu jagen.
<G-vec00599-002-s232><blow_up.pusten><en> In between, shake or blow off the hair from the clipper.
<G-vec00599-002-s232><blow_up.pusten><de> •Schütteln oder pusten Sie zwischendurch die Haare vom Gerät.
<G-vec00599-002-s233><blow_up.pusten><en> Incongruously, both wore gunbelts, and the pistols strapped to their sides were of sufficient size to blow holes in small mountains.
<G-vec00599-002-s233><blow_up.pusten><de> Es sah sonderbar aus, daß beide Pistolengürtel trugen, und die Pistolen daran waren groß genug, um Löcher in kleine Berge zu pusten.
<G-vec00599-002-s234><blow_up.pusten><en> Nevertheless, many biogas production plants lack an effective heating concept and blow the heat into the hall or outside.
<G-vec00599-002-s234><blow_up.pusten><de> Viele Anlagen haben dennoch kein effektives Wärmekonzept und pusten die Wärme in die Halle oder nach außen.
<G-vec00599-002-s235><blow_up.pusten><en> *Touch, drag, blow, rub, shake and many other games...
<G-vec00599-002-s235><blow_up.pusten><de> * Berühren, gleiten, pusten, reiben, schütteln und viele andere Spiele...
<G-vec00599-002-s236><blow_up.pusten><en> If a lot of hairs have accumulated on the appliance, simply blow them off.
<G-vec00599-002-s236><blow_up.pusten><de> Wenn sich sehr viele Haare auf dem Gerät angesammelt haben, pusten Sie sie zuerst weg.
<G-vec00599-002-s237><blow_up.pusten><en> The safest way to remove excess powder is to blow it off, either by mouth or with a blow-dryer on a low setting.
<G-vec00599-002-s237><blow_up.pusten><de> Die ungefährlichste Methode, um überschüssigen Puder zu entfernen, ist, ihn ab zu pusten, entweder mit dem Mund oder mit einem Haartrockner auf einer niedrigen Stufe.
<G-vec00599-002-s238><blow_up.putzen><en> It's natural to want to blow your nose when you're feeling stuffed up, but just be careful not to overdo it.
<G-vec00599-002-s238><blow_up.putzen><de> Dein natürlicher Instinkt wird dich vielleicht dazu verleiten, deine Nase zu putzen wenn sie sich blockiert anfühlt, aber es ist noch immer nicht entschieden, ob das eine gute Idee ist oder nicht.
<G-vec00599-002-s239><blow_up.putzen><en> A child cannot blow his nose on his own, therefore effective treatment is necessary.
<G-vec00599-002-s239><blow_up.putzen><de> Ein Kind kann sich nicht selbst die Nase putzen, daher ist eine wirksame Behandlung erforderlich.
<G-vec00599-002-s240><blow_up.putzen><en> To teach to blow your nose really and a two-year-old crumb, and even a year and a half.
<G-vec00599-002-s240><blow_up.putzen><de> Zu lehren, dir die Nase wirklich zu putzen und eine zwei Jahre alte Krume und sogar eineinhalb Jahre.
<G-vec00599-002-s241><blow_up.putzen><en> This minor trauma occurred during dinner where my father took his cotton handkerchief from his pocket as standard once a meal to blow his nose very hard.
<G-vec00599-002-s241><blow_up.putzen><de> Dieses kleine Trauma ereignete sich während des Abendessens, als mein Vater sein Baumwolltaschentuch als Standard einmal pro Mahlzeit aus der Tasche zog, um sich die Nase sehr hart zu putzen.
<G-vec00599-002-s242><blow_up.putzen><en> I knew that it is absolutely taboo to blow one s nose in public, and I knew I would have to constantly take my shoes off wherever I go.
<G-vec00599-002-s242><blow_up.putzen><de> Ich weiß, dass es in der Öffentlichkeit absolut tabu ist, sich die Nase zu putzen, und ich bin darauf eingestellt, mir ständig und überall die Schuhe ausziehen zu müssen.
<G-vec00599-002-s243><blow_up.putzen><en> You will first be asked to blow your nose, then tilt your head back to allow the health care practitioner access to your nasal passageway.
<G-vec00599-002-s243><blow_up.putzen><de> Zuerst werden Sie aufgefordert, sich die Nase zu putzen und dann den Kopf nach hinten zu neigen, um dem medizinischen Fachpersonal den Zugang zu Ihrem Nasengang zu ermöglichen.
<G-vec00599-002-s244><blow_up.putzen><en> After two weeks you can take the mask off and carefully try to blow your nose.
<G-vec00599-002-s244><blow_up.putzen><de> Nach zwei Wochen können Sie die Maske abnehmen und vorsichtig versuchen, sich die Nase zu putzen.
<G-vec00599-002-s218><blow_up.sprengen><en> My mom was worried to see me always return home very late and more than once threatened to blow up the Fine Arts department (seen in today’s situation in the world, her words may sound threatening, but then it was just a joke).
<G-vec00599-002-s218><blow_up.sprengen><de> Meine Mutter drohte, da sie mein spätes Heimkommen beunruhigte, damit, die Kunstabteilung im Gymnasium in die Luft zu sprengen (bei der heutigen Weltlage klingt das sehr bedrohlich, damals aber war das eher wie ein Scherz).
<G-vec00599-002-s219><blow_up.sprengen><en> Heidi then follows Angela, and tells her about Nathan's "conspiracy" to blow up New York with Peter.
<G-vec00599-002-s219><blow_up.sprengen><de> Heidi folgt daraufhin Angela und erzählt ihr von Nathans "Verschwörung", mit Peter New York City in die Luft zu sprengen.
<G-vec00599-002-s220><blow_up.sprengen><en> Khaled and Said, good friends since their childhood, have been chosen as suicide bombers and are expected to blow themselves up in Tel Aviv.
<G-vec00599-002-s220><blow_up.sprengen><de> Khaled und Said, seit ihrer Kindheit gute Freunde, sind dazu bestimmt worden, sich als Selbstmordattentäter in Tel Aviv in die Luft zu sprengen.
<G-vec00599-002-s221><blow_up.sprengen><en> . BELGIUM – Captured fugitive Salah Abdeslam initially planned to blow himself up outside the Stade de France during the Paris attacks but changed his mind, a prosecutor said Saturday, after Europe’s most wanted man was charged with “terrorist murder” for his role in the November assaults.
<G-vec00599-002-s221><blow_up.sprengen><de> Salah Abdeslam wollte sich laut der französischen Staatsanwaltschaft bei den Angriffen in Paris in die Luft sprengen Das habe er nach seiner Festnahme am Freitag in Brüssel den belgischen Ermittlern gesagt, teilte der Pariser Staatsanwalt François Molins mit.
<G-vec00599-002-s222><blow_up.sprengen><en> The station even proposed to headquarters through back channels that a squad be on hand at the moment of the coup to storm the [Communist] Chinese embassy, kill everyone inside, steal their secret records, and blow up the building to cover the facts.
<G-vec00599-002-s222><blow_up.sprengen><de> Er schlug dem Hauptquartier sogar vor, dass man eine geheime Spezialeinheit aufstellen solle, um während des Putsches die [kommunistische] chinesische Botschaft zu stürmen, alle Insassen zu killen, alle geheimen Dokumente zu stehlen und das Gebäude in die Luft zu sprengen, um alles zu vertuschen.
<G-vec00599-002-s223><blow_up.sprengen><en> Hedges can be shot out of a cannon to blow up if they interfere with the movement.
<G-vec00599-002-s223><blow_up.sprengen><de> Hedges kann aus einer Kanone geschossen werden, um die Luft zu sprengen, wenn sie mit der Bewegung stören.
<G-vec00599-002-s224><blow_up.sprengen><en> In 1955 there was a permission given to blow up the „Goering’s dacha” (as the people the building had been called amongst the citizens).
<G-vec00599-002-s224><blow_up.sprengen><de> Im Jahre 1955 kam die Erlaubnis, die „Datsche von Göring” – so wurde dieses Objekt von der Bevölkerung genannt – in die Luft zu sprengen.
<G-vec00599-002-s225><blow_up.sprengen><en> For years now – and on an almost daily basis – Muslims have been unscrupulously described in newspapers and talk shows as people who blow themselves up, style themselves as "Sharia police", oppress women, are intolerant of anyone with opposing views and who quite simply spread terror.
<G-vec00599-002-s225><blow_up.sprengen><de> In Zeitungen und Talkshows werden Muslime seit Jahren beinahe täglich auf hemmungslose Weise als Menschen beschrieben, die sich in die Luft sprengen, sich als "Scharia-Polizisten" aufspielen, Frauen unterdrücken, intolerant gegenüber Andersdenkenden sind und schlicht Terror verbreiten.
<G-vec00599-002-s340><blow_up.umhauen><en> And the results will blow you away.
<G-vec00599-002-s340><blow_up.umhauen><de> Und das Ergebnis wird Sie umhauen.
<G-vec00599-002-s341><blow_up.umhauen><en> The price won't blow you away, but it isn't too expensive.
<G-vec00599-002-s341><blow_up.umhauen><de> Der Preis wird nicht Sie umhauen, aber es ist nicht zu teuer.
<G-vec00599-002-s342><blow_up.umhauen><en> Team up with a friend to accomplish even more powerful moves that will blow away the villains
<G-vec00599-002-s342><blow_up.umhauen><de> Spiele mit einem Freund zusammen, um noch mächtigere Moves auszuführen, die die Bösewichte glatt umhauen.
<G-vec00599-002-s343><blow_up.umhauen><en> And it’s going to blow your customers’ minds.
<G-vec00599-002-s343><blow_up.umhauen><de> Und das wird Ihre Kunden umhauen.
<G-vec00599-002-s344><blow_up.umhauen><en> Inside, the Zone asymmetric core will allow for stored energy to vaporize the pins and blow your competition away.
<G-vec00599-002-s344><blow_up.umhauen><de> Im Inneren lässt der asymmetrische Kern der Zone gespeicherte Energie die Pins verdampfen und Ihre Konkurrenz umhauen.
<G-vec00599-002-s345><blow_up.umhauen><en> It contains 4 of the best sativa favourites that will blow your mind not just with their uplifting and sometimes outright psychedelic effects, but also with their great flavours and XXL yields.
<G-vec00599-002-s345><blow_up.umhauen><de> Er enthält 4 der besten Sativa-Favoriten, die Dich nicht nur mit ihrer erhebenden und manchmal absolut psychedelischen Wirkung umhauen, sondern auch mit ihren groĂźartigen Aromen und ihren XXL-Erträgen.
<G-vec00599-002-s346><blow_up.umhauen><en> Artec Leo, our newest scanner in the range is guaranteed to blow you away.
<G-vec00599-002-s346><blow_up.umhauen><de> Artec Leo, unser neuester Scanner, wird Sie garantiert umhauen.
<G-vec00599-002-s347><blow_up.umhauen><en> Get ready for a stunning find with 4 new watch references that will blow your mind.
<G-vec00599-002-s347><blow_up.umhauen><de> Mach dich bereit für einen atemberaubenden Fund mit 4 neuen Referenzen, die dich umhauen werden.
<G-vec00599-002-s348><blow_up.umhauen><en> At our website, we host the best girl-on-girl action that will definitely blow your mind and you will get the best erection ever.
<G-vec00599-002-s348><blow_up.umhauen><de> Auf unserer Website veranstalten wir die beste Girl-on-Girl-Action, die Sie definitiv umhauen wird, und Sie werden die beste Erektion aller Zeiten erhalten.
<G-vec00599-002-s293><blow_up.versetzen><en> Fossils dealt the most severe blow to the theory of evolution.
<G-vec00599-002-s293><blow_up.versetzen><de> Die Fossilienfunde haben der Evolutionstheorie einen schweren Schlag versetzt.
<G-vec00599-002-s294><blow_up.versetzen><en> Malcolm Faith was dealt a devastating blow at the height of the civil rights movement in 1963.
<G-vec00599-002-s294><blow_up.versetzen><de> Malcolm Faith wurde 1963 auf dem Höhepunkt der Bürgerrechtsbewegung ein verheerender Schlag versetzt.
<G-vec00599-002-s295><blow_up.versetzen><en> The Panama papers leaks and the shutting down of offshore tax havens has already dealt a huge blow to them.
<G-vec00599-002-s295><blow_up.versetzen><de> Das Durchsickern der Panama-Papiere und die Schließung ausländischer Steuer-Oasen hat ihnen bereits einen großen Schlag versetzt.
<G-vec00599-002-s296><blow_up.versetzen><en> In a huge blow to free speech, the Legal Affairs Committee of the European Parliament has voted to approve Article 13 of the Copyright Directive. Tags: copyright
<G-vec00599-002-s296><blow_up.versetzen><de> Der Rechtsausschuss des Europäischen Parlaments hat dem Recht auf freie Meinungsäußerung einen schweren Schlag versetzt, indem er für die Annahme von Artikel 13 der Urheberrechtsrichtlinie gestimmt hat.
<G-vec00599-002-s297><blow_up.versetzen><en> Tonight, Israeli combat aircraft, launching guided missiles, dealt a massive blow to the Syrian military base in the province of Aleppo.
<G-vec00599-002-s297><blow_up.versetzen><de> Heute Abend haben israelische Kampfflugzeuge, die Lenkflugkörper abfeuern, dem syrischen Militärstützpunkt in der Provinz Aleppo einen schweren Schlag versetzt.
<G-vec00599-002-s349><blow_up.wegblasen><en> This Grungy Bubble Texture pack is simply bubbling and bursting with 10 super high res textures that will blow you away.
<G-vec00599-002-s349><blow_up.wegblasen><de> Diese Grungy Bubble Texture Pack ist einfach sprudeln und platzen mit 10 super High Res Texturen, die Sie wegblasen wird.
<G-vec00599-002-s350><blow_up.wegblasen><en> The dust blower in BOSCH jigsaws deflects some of the cooling air to blow the sawdust off the cut line. Top
<G-vec00599-002-s350><blow_up.wegblasen><de> Mit der Späneblasvorrichtung bei BOSCH-Stichsägen wird ein Teil der Kühlluft abgezweigt und zum Wegblasen der Späne benützt.
<G-vec00599-002-s351><blow_up.wegblasen><en> This revolutionary smoking device will blow you away.
<G-vec00599-002-s351><blow_up.wegblasen><de> Dieses revolutionäre Rauchgerät wird Dich wegblasen.
<G-vec00599-002-s352><blow_up.wegblasen><en> I know that they are built very solid, a big storm can't blow them away, however, they don't look real anymore.
<G-vec00599-002-s352><blow_up.wegblasen><de> Ich weiß, dass sie sehr solide gebaut sind, ein großer Sturm kann sie nicht wegblasen, wie auch immer, sie schauen nicht echt aus.
<G-vec00599-002-s353><blow_up.wegblasen><en> I can dispense foul odours and adjust my scalp temperature and sometimes (I swear) I can blow the beam of the reading light an inch or two away from my nose.
<G-vec00599-002-s353><blow_up.wegblasen><de> Ich kann auf übelriechende Gerüche verzichten und die Temperatur meiner Kopfhaut abstimmen und manchmal (ich schwöre es) kann ich den Strahl meines Leselichts einen Inch (2,5 cm) oder zwei von meiner Nase wegblasen.
<G-vec00599-002-s373><blow_up.wehen><en> a quiet breeze will blow from the east.
<G-vec00599-002-s373><blow_up.wehen><de> Ein leiser Zug weht aus Richtung Westen.
<G-vec00599-002-s374><blow_up.wehen><en> A light breeze will blow from southeast.
<G-vec00599-002-s374><blow_up.wehen><de> Eine leichte Brise weht aus Richtung Südosten.
<G-vec00599-002-s375><blow_up.wehen><en> The sphere-shaped stores are meant to act as interim stores of power for periods in which the wind does not blow and the sun does not shine, but in which energy is required nevertheless.
<G-vec00599-002-s375><blow_up.wehen><de> Die kugelförmigen Speicher sollen Strom für die Zeiten zwischenspeichern, in denen der Wind nicht weht und die Sonne nicht scheint, aber Energie trotzdem nachgefragt wird.
<G-vec00599-002-s376><blow_up.wehen><en> Lian feels the wind blow through her hair and mentions the birds and ducks.
<G-vec00599-002-s376><blow_up.wehen><de> Lian spürt, wie der Wind durch ihr Haar weht und zeigt auf die Vögel und Enten.
<G-vec00599-002-s377><blow_up.wehen><en> Only in case of northerly wind, the wind will blow directly in from the sea.
<G-vec00599-002-s377><blow_up.wehen><de> Nur bei einer nördlichen Windrichtung weht der Wind direkt von dem Meer.
<G-vec00599-002-s378><blow_up.wehen><en> When the wind doesn’t blow or the sun doesn’t shine, however, they only meet a few percent of demand.
<G-vec00599-002-s378><blow_up.wehen><de> Wenn aber der Wind nicht weht und die Sonne nicht scheint, decken sie nur wenige Prozent des Bedarfs ab.
<G-vec00599-002-s379><blow_up.wehen><en> July and August are the months that the seasonal North winds blow.
<G-vec00599-002-s379><blow_up.wehen><de> Im Juni und August weht der saisonbedingte Nordwind.
<G-vec00599-002-s380><blow_up.wehen><en> A light breeze will blow from southeast.
<G-vec00599-002-s380><blow_up.wehen><de> Eine leichte Brise weht aus Richtung Osten.
<G-vec00599-002-s381><blow_up.wehen><en> summer's plant trend, which draws inspiration from the summer gardens of the Renaissance, new and milder winds are beginning to blow across the consumer landscape.
<G-vec00599-002-s381><blow_up.wehen><de> Mit dem Pflanzentrend dieses Sommers, der sich durch den sommerlichen Garten der Renaissance inspirieren lässt, weht ein neuer und milderer Wind durch die Verbraucherlandschaft.
<G-vec00599-002-s382><blow_up.wehen><en> He sincerely wants to give them the new birth, but He wills that the life-giving Spirit not blow on them.
<G-vec00599-002-s382><blow_up.wehen><de> Er möchte ihnen ernsthaft die Wiedergeburt ermöglichen, aber er will nicht, dass der Leben spendende Geist in ihnen weht.
<G-vec00599-002-s384><blow_up.wehen><en> A light breeze will blow from the north.
<G-vec00599-002-s384><blow_up.wehen><de> Eine schwache Brise weht aus Richtung Osten.
<G-vec00599-002-s386><blow_up.wehen><en> A moderate breeze will blow from the west.
<G-vec00599-002-s386><blow_up.wehen><de> Ein leiser Zug weht aus Richtung Süden.
<G-vec00599-002-s387><blow_up.wehen><en> Fresh and stimulating mountain breezes gently blow across the Schladming-Dachstein region.
<G-vec00599-002-s387><blow_up.wehen><de> In der Region Schladming-Dachstein weht ein inspirierend frischer Wind.
<G-vec00599-002-s388><blow_up.wehen><en> The wind doesn’t blow all the time.
<G-vec00599-002-s388><blow_up.wehen><de> Der Wind weht nicht immer.
<G-vec00599-002-s389><blow_up.wehen><en> “When the winds of change blow, some seek out the protection of a safe harbour, others set sail.”
<G-vec00599-002-s389><blow_up.wehen><de> “Wenn der Wind der Veränderung weht, suchen die einen Schutz im sicheren Hafen und die anderen setzen die Segel”.
<G-vec00599-002-s391><blow_up.wehen><en> a quiet breeze will blow from the north.
<G-vec00599-002-s391><blow_up.wehen><de> Eine schwache Brise weht aus Richtung Norden.
