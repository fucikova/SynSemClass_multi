<G-vec00169-002-s247><draw_off.machen><en> Some models of cranes draw attention to themselves with angular shapes, while others, on the contrary, fascinate with smooth shapes and grace.
<G-vec00169-002-s247><draw_off.machen><de> Einige Modelle von Kranen machen mit eckigen Formen auf sich aufmerksam, während andere mit glatten Formen und Grazie faszinieren.
<G-vec00169-002-s248><draw_off.machen><en> Negative priorities: In view of contracting resources, the CoR will not be able to draw attention to every activity on every subject at every level.
<G-vec00169-002-s248><draw_off.machen><de> Negative Prioritäten Im Sinne einer Bündelung der Ressourcen wird der AdR nicht in der Lage sein, auf jede Aktivität zu jedem Thema auf jeder Ebene aufmerksam zu machen.
<G-vec00169-002-s249><draw_off.machen><en> Analyzing a social and political situation in Kobrin district, it is possible to draw conclusions that the situation was difficult.
<G-vec00169-002-s249><draw_off.machen><de> Die gesellschaftspolitische Situation auf Kobrynschtschine analysierend, kann man die Schlussfolgerungen darüber machen, dass die Situation kompliziert war.
<G-vec00169-002-s250><draw_off.machen><en> For opposite souls it is a relief, an easing of their worry about men, when they can draw the attention of them to that, what threatens them, for which they have a fine feeling, however do not have the right explanation.
<G-vec00169-002-s250><draw_off.machen><de> Für die jenseitigen Seelen ist es eine Erleichterung, eine Entlastung ihrer Sorge um die Menschen, wenn sie diese aufmerksam machen können auf das, was ihnen droht, wofür sie ein feines Empfinden, jedoch nicht die rechte Erklärung haben.
<G-vec00169-002-s251><draw_off.machen><en> Prowindo committee's members and representatives of the member companies have been invited by Prowindo to draw attention to the special situation of plastic recycling.
<G-vec00169-002-s251><draw_off.machen><de> Im Rahmen eines parlamentarischen Frühstücks lud Prowindo im Februar die Mitglieder des CDU Umweltausschusses sowie Vertreter der Mitglieds unternehmen ein, um auf die beson dere Situation des Kunststofffensterrecyclings aufmerksam zu machen.
<G-vec00169-002-s252><draw_off.machen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00169-002-s252><draw_off.machen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00169-002-s253><draw_off.machen><en> After learning the basic characteristics in the first level of our study – Bargue Drawings Copying Technique – we start learning how to draw real objects.
<G-vec00169-002-s253><draw_off.machen><de> Nach dem Erlernen von Zeichengrundlagen im ersten Level unseres Studiums – das Zeichnen von Bargue Kopien – geht es bei den Cast-Zeichnungen darum erste Studien von realen Gegenständen zu machen.
<G-vec00169-002-s254><draw_off.machen><en> Together with Sudanese members of both human rights organisations beat on drums in Berlin on Thursday in front of the Brandenburger Tor to draw attention to the growing danger of a new war.
<G-vec00169-002-s254><draw_off.machen><de> Gemeinsam mit Sudanesen trommelten Mitglieder beider Menschenrechtsorganisationen auf alten Ölfässern am Donnerstag in Berlin vor dem Brandenburger Tor, um auf die wachsende Gefahr eines neuen Krieges aufmerksam zu machen.
<G-vec00169-002-s255><draw_off.machen><en> We would like to draw your attention to our rules for your four-legged friends.
<G-vec00169-002-s255><draw_off.machen><de> Gern möchten wir Sie auf unsere Spielregeln für Ihren Vierbeiner aufmerksam machen.
<G-vec00169-002-s256><draw_off.machen><en> That’s why we want to draw some attention to this with what we share here on this website and hope that we can be helpful for you.
<G-vec00169-002-s256><draw_off.machen><de> Deshalb möchten wir mit dem, was wir hier auf dieser Webseite teilen, ein bisschen darauf aufmerksam machen und hoffen, dass wir euch eine Hilfe sein können.
<G-vec00169-002-s257><draw_off.machen><en> The InformNapalm international volunteer community’s publication tries to draw attention of the French citizens, the media and politicians to the facts of participation of the French residents in the illegal activities against Ukraine.
<G-vec00169-002-s257><draw_off.machen><de> Mit dieser Publikation möchte die internationale Freiwilligengemeinschaft InformNapalm die französischen Bürger, Medien und Politiker auf die Belege für die Involvierung von Franzosen in rechtswidrige Handlungen gegen die Ukraine aufmerksam machen.
<G-vec00169-002-s258><draw_off.machen><en> The markers have a chisel tip with which you can draw lasting lines varying in thickness from 1 to 5 mm.
<G-vec00169-002-s258><draw_off.machen><de> Die Marker haben eine schräge Spitze, mit der Sie dauerhafte Linien mit einer Stärke von 1 bis 5 mm machen können.
<G-vec00169-002-s259><draw_off.machen><en> We can draw their attention to the importance of recognizing the work of Jesus on the cross and to make use of it for themselves and through this to undertake the actual step to get out from the world of darkness, out of that part of the spiritual world, where the incomplete spirits go so that they then can reach the world of dawn and from there can then completely leave the world of darkness and reach the world of light, and finally be happy and free and complete; and become free forever from matter and from the imprisonment in it.
<G-vec00169-002-s259><draw_off.machen><de> Wir können sie auf die Wichtigkeit aufmerksam machen, das Werk Jesus am Kreuz anzuerkennen und für sich selbst nutzbar zu machen und dadurch den eigentlichen Schritt zu unternehmen, da aus der Welt der Finsternis herauszukommen, aus dem Teil der geistigen Welt, wohin die unvollkommenen Geister hinkommen, damit die dann in die Welt der Dämmerung gelangen können und von da aus dann ganz die Welt der Dunkelheit verlassen können und in die Welt des Lichtes gelangen, und endlich glücklich werden, und frei, und vollkommen; und für immer frei werden von der Materie und von der Gefangenschaft in ihr.
<G-vec00169-002-s260><draw_off.machen><en> He will apply all means to draw them off me, but my servants recognize and see through him.
<G-vec00169-002-s260><draw_off.machen><de> Er wird alle Mittel anwenden, um sie Mir abtrünnig zu machen, doch Meine Diener erkennen und durchschauen ihn.
<G-vec00169-002-s261><draw_off.machen><en> You may print off one copy, and may download extracts, of any page(s) from our Website for your personal reference and you may draw the attention of others within your organisation to material posted on our Website.
<G-vec00169-002-s261><draw_off.machen><de> Sie dürfen eine Kopie von beliebigen Seiten auf unserer Website zur persönlichen Nutzung ausdrucken oder Auszüge daraus herunterladen und Sie können andere in Ihrer Organisation auf Materialien aufmerksam machen, die auf unserer Website veröffentlicht sind.
<G-vec00169-002-s262><draw_off.machen><en> At a recent protest against the Pamplona bull run, a British woman used her boobs to draw attention to animal rights.
<G-vec00169-002-s262><draw_off.machen><de> Bei einem Protest gegen den Stierlauf von Pamplona hat eine Frau ihre Brüste gezeigt, um auf Tierrechte aufmerksam zu machen.
<G-vec00169-002-s263><draw_off.machen><en> It is supposed to sound the alarm, to draw attention to flaws in the financial system, and to circulate suggestions for improvements if anything goes wrong.
<G-vec00169-002-s263><draw_off.machen><de> Es soll "Alarm" rufen, auf Mängel im Finanzsystem aufmerksam machen und Verbesserungsvorschläge unterbreiten, wenn irgendetwas schiefläuft.
<G-vec00169-002-s264><draw_off.machen><en> “In order to draw attention to Rivella bravely, boldly and loudly, we wanted to inspire people for the brand where they can live out their activities and passion without restriction by stimulating fresh thinking,” explains Andreas Janous, Group Head at follow red, the core of the activation concept.
<G-vec00169-002-s264><draw_off.machen><de> „Um mutig, frech und laut auf Rivella aufmerksam zu machen, wollten wir Menschen dort für die Marke begeistern, wo sie mit Anregung zu frischem Denken ihre Tätigkeit und Leidenschaft uneingeschränkt ausleben können”, erklärt Andreas Janous, Group Head bei follow red den Kern des Aktivierungskonzepts.
<G-vec00169-002-s265><draw_off.machen><en> In the three-day event, there will be some valuable company that can draw attention immediately.
<G-vec00169-002-s265><draw_off.machen><de> Bei der dreitägigen Veranstaltung wird es ein wertvolles Unternehmen geben, das sofort auf sich aufmerksam machen kann.
<G-vec00169-002-s285><draw_off.ziehen><en> Playing themselves, the actors draw on their own reality in order to explore what they could be..
<G-vec00169-002-s285><draw_off.ziehen><de> Die Akteure spielen sich selbst und nutzen ihre eigene Realität, um zu erforschen, was sie sein könnten….
<G-vec00169-002-s286><draw_off.ziehen><en> The publisher guarantees to respect in all publications the copyrights of used graphics, sound documents, video sequences and texts, to use self-made graphics, sound documents, video sequences and texts, or to draw upon free graphics sound documents, video sequences and texts.
<G-vec00169-002-s286><draw_off.ziehen><de> Der Herausgeber gewährleistet, in allen Publikationen die Urheberrechte der verwendeten Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihm selbst erstellte Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.
<G-vec00169-002-s287><draw_off.ziehen><en> In addition to the mainstream education system many students draw on private tutoring to improve their academic achievement.
<G-vec00169-002-s287><draw_off.ziehen><de> Neben dem öffentlichen Schulsystem nutzen viele Schülerinnen und Schüler privaten Nachhilfeunterricht, um ihre Schulleistung zu verbessern.
<G-vec00169-002-s288><draw_off.ziehen><en> He invites us to draw on existing realities such as the Easter Days, the Christian Forum, the Day of Christ, the March for Jesus.
<G-vec00169-002-s288><draw_off.ziehen><de> Er lädt uns ein, bestehende Realitäten wie die "Ostertage", das "Christliche Forum", den "Tag Christi", den "Marsch für Jesus" zu nutzen.
<G-vec00169-002-s289><draw_off.ziehen><en> During her research sojourn, Dr. Southwood will be collaborating with various scholars from the university and its School of Education to draw on their psycholinguistic and sociolinguistic expertise on linguistic aspects of migration research for her own studies.
<G-vec00169-002-s289><draw_off.ziehen><de> Dr. Southwood wird während ihres Forschungsaufenthaltes mit mehreren Wissenschaftlerinnen und Wissenschaftlern der Universität Heidelberg und der Pädagogischen Hochschule Heidelberg zusammenarbeiten, um deren psycho- und soziolinguistisches Fachwissen zu sprachlichen Aspekten der Migrationsforschung für die eigenen Untersuchungen zu nutzen.
<G-vec00169-002-s290><draw_off.ziehen><en> Draw upon expertise from Danfoss to optimize energy storage solutions on board vessels, and shore power supplies for quieter and cleaner harbors.
<G-vec00169-002-s290><draw_off.ziehen><de> Nutzen Sie das Know-how von Danfoss, um Energiespeicherlösungen an Bord von Schiffen sowie Landstromversorgungen für ruhigere und sauberere Häfen zu optimieren.
<G-vec00169-002-s291><draw_off.ziehen><en> We draw on the long standing market experience of HANDEN Group on the gas market and from VNG capital group specializing in energy sale.
<G-vec00169-002-s291><draw_off.ziehen><de> Wir nutzen die langjährige Markterfahrung der Gruppe HANDEN im Erdgashandel und der Kapitalgruppen VNG im Stromvertrieb.
<G-vec00169-002-s292><draw_off.ziehen><en> As an all-round multi-cloud solution, QSC’s Pure Enterprise Cloud will in future enable companies to draw both on traditional IT applications as well as new public and private cloud services on a common platform.
<G-vec00169-002-s292><draw_off.ziehen><de> Als ganzheitliche Multi-Cloud-Lösung ermöglicht die Pure Enterprise Cloud von QSC künftig Unternehmen, sowohl traditionelle IT-Applikationen als auch neue Public- und Private-Cloud-Services auf einer gemeinsamen Plattform zu nutzen.
<G-vec00169-002-s293><draw_off.ziehen><en> A vivid intercultural exchange ensures that societies don’t cut themselves off but draw on international input to help them handle social challenges in new ways.
<G-vec00169-002-s293><draw_off.ziehen><de> Ein lebendiger Austausch zwischen Kulturen sorgt dafür, dass Gesellschaften sich nicht abschotten, sondern internationale Impulse nutzen können, um mit gesellschaftlichen Herausforderungen kreativ umzugehen.
<G-vec00169-002-s294><draw_off.ziehen><en> Draw on their expertise if you need help implementing webCRM in your business.
<G-vec00169-002-s294><draw_off.ziehen><de> Nutzen Sie das Know-how von GLOBIT, wenn Sie bei der Implementierung von webCRM in Ihrem Unternehmen Hilfe brauchen.
<G-vec00169-002-s295><draw_off.ziehen><en> The author endeavours in all publications to observe the copyrights related to any external charts, audio or video clips and texts used, to make use of self-created charts, audio or video clips and texts, or to draw on such charts, audio or video clips and texts as are unlicensed public domain.
<G-vec00169-002-s295><draw_off.ziehen><de> Der Autor ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihm selbst erstellte Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.
<G-vec00169-002-s296><draw_off.ziehen><en> Curators in Presidential libraries and in other museums throughout the country draw upon these collections for historical exhibits.
<G-vec00169-002-s296><draw_off.ziehen><de> Kuratoren in den Präsidentenbibliotheken und andere Museen nutzen diese Sammlungen für historische Ausstellungen.
<G-vec00169-002-s297><draw_off.ziehen><en> We also draw upon our experience for future-oriented technology: In joint cooperation with our long-standing suppliers of raw materials, we constantly strive to improve materials and production techniques.
<G-vec00169-002-s297><draw_off.ziehen><de> Dabei nutzen wir unsere Erfahrung auch für zukunftsweisende Technologien: In Kooperation mit unseren langjährigen Rohstofflieferanten arbeiten wir ständig an der Weiterentwicklung von Materialien und Fertigungstechniken.
<G-vec00169-002-s298><draw_off.ziehen><en> Our consulting teams draw on that experience by investigating your global operations to design pragmatic solutions for complex operational issues.
<G-vec00169-002-s298><draw_off.ziehen><de> Unsere Beratungsteams nutzen diesen Erfahrungsschatz, um Ihren internationalen Betrieb zu analysieren und pragmatische Lösungen für komplexe betriebliche Fragen zu erarbeiten.
<G-vec00169-002-s299><draw_off.ziehen><en> Raoul Kaenzig, main author of the study, comments: “The spectacular view from the summit, quick and easy access from La Paz, the chance to acclimatize to high altitude, and - for some visitors - to see snow for the first time, continue to draw visitors from around the world.”
<G-vec00169-002-s299><draw_off.ziehen><de> «Die herrliche Aussicht vom Gipfel, die schnelle und mühelose Anreise von La Paz aus, die Möglichkeit, den Ort für die Höhenakklimatisation zu nutzen, und die für manche erstmalige Berührung mit Schnee sorgen dafür, dass dieser Ort immer noch Besucher aus der ganzen Welt anlockt», erläutert Raoul Kaenzig, Hauptautor der Studie.
<G-vec00169-002-s300><draw_off.ziehen><en> All the partners will draw on already existing field experiments.
<G-vec00169-002-s300><draw_off.ziehen><de> Alle Partner nutzen dazu bereits bestehende Feldexperimente.
<G-vec00169-002-s301><draw_off.ziehen><en> Starch and sugars supply a fast, immediate burst of energy which the horse can draw on with immediate effect.
<G-vec00169-002-s301><draw_off.ziehen><de> Stärke und Zucker bilden eine rasche, schubweise und vorübergehende Form der Energiezufuhr, die dem Pferd gleichfalls von Nutzen ist.
<G-vec00169-002-s302><draw_off.ziehen><en> Particularly before making an important decision, they want to draw on the expertise of a customer advisor during a face-to-face meeting.
<G-vec00169-002-s302><draw_off.ziehen><de> Gerade im Vorfeld wichtiger Entscheidungen möchten sie bei einem persönlichen Treffen die Expertise eines Kundenberaters nutzen.
<G-vec00169-002-s303><draw_off.ziehen><en> Working together as The Dream Team, Steve and Monika draw on their experience of year’s of freelance work on different boats to set-up and maintain Groovy so that guests can all have an easy and pleasant trip.
<G-vec00169-002-s303><draw_off.ziehen><de> Steve und Monika arbeiten als The Dream Team zusammen und nutzen ihre Erfahrungen aus jahrelanger freiberuflicher Arbeit an verschiedenen Booten, um Groovy so einzurichten und zu warten, dass alle Gäste eine einfache und angenehme Reise haben können.
<G-vec00169-002-s513><draw_off.ziehen><en> Based on the outline, draw the main body of the monster.
<G-vec00169-002-s513><draw_off.ziehen><de> Ziehe die Linien des Haikörpers anhand des Umrisses nach.
<G-vec00169-002-s514><draw_off.ziehen><en> On the exhale, draw your stomach inward from both above and below the navel (Fig. 1).
<G-vec00169-002-s514><draw_off.ziehen><de> Ziehe dann ausatmend Deinen Bauch kraftvoll von oberhalb und unterhalb des Bauchnabels nach innen (Bild 1).
<G-vec00169-002-s515><draw_off.ziehen><en> Video camera on and here we go: From the two bowls I draw alternately a price and a name.
<G-vec00169-002-s515><draw_off.ziehen><de> Videokamera an und los: Aus den beiden Schüsseln ziehe ich abwechselnd einen Preis und einen Namen.
<G-vec00169-002-s516><draw_off.ziehen><en> So I'm going to press the Spacebar to stop playback and draw a lasso around all four keyframes.
<G-vec00169-002-s516><draw_off.ziehen><de> Ich halte die Wiedergabe mit der Leertaste an und ziehe ein Lasso um alle vier Keyframes.
<G-vec00169-002-s517><draw_off.ziehen><en> Discard a card from your hand and draw a card from your extra deck.
<G-vec00169-002-s517><draw_off.ziehen><de> Wirf eine Karte aus deiner Hand ab und ziehe eine Karte aus deinem Extradeck.
<G-vec00169-002-s518><draw_off.ziehen><en> I draw my inspirations from various fields, may it be chaos theory, geometry or parametric and biological design.
<G-vec00169-002-s518><draw_off.ziehen><de> Ich ziehe meine Inspiration aus den verschiendensten Quellen, sei es Chaos-Theorie, Geometrie oder parametrisches und biologisches Design.
<G-vec00169-002-s519><draw_off.ziehen><en> Draw your lines to see glowing effect and win.
<G-vec00169-002-s519><draw_off.ziehen><de> Ziehe deine Linien und schau’ dir den glanzvollen Effekt an, um zu gewinnen.
<G-vec00169-002-s520><draw_off.ziehen><en> Based on the beast with 7 heads I draw a lesson from the fact that it is unlike the dinosaurs still alive, even if one of the centres of thought was already mortally wounded.
<G-vec00169-002-s520><draw_off.ziehen><de> Bezogen auf das Tier mit 7 Köpfen ziehe ich als Lehre daraus, dass es im Gegensatz zum Dinosaurier weiterlebt, auch wenn eines der Denkzentren längst tödlich verwundet wurde.
<G-vec00169-002-s521><draw_off.ziehen><en> Return 1 face-up Tribute Summoned "Steelswarm" monster you control to the hand; draw 1 card.
<G-vec00169-002-s521><draw_off.ziehen><de> Gib 1 offenes "Stahlschar"-Monster, das du kontrollierst und das als Tributbeschwörung beschworen wurde, auf die Hand zurück; ziehe 1 Karte.
<G-vec00169-002-s522><draw_off.ziehen><en> Forced - After you fail a skill test while investigating Ruins of Eztli: Draw the top card of the encounter deck.
<G-vec00169-002-s522><draw_off.ziehen><de> Erzwungen - Nachdem dir eine Fertigkeitsprobe misslungen ist, solange du in den Ruinen von Eztli ermittelst: Ziehe die oberste Karte des Begegnungsdecks.
<G-vec00169-002-s523><draw_off.ziehen><en> I draw Munich and Hanni Nuremberg, two main prizes.
<G-vec00169-002-s523><draw_off.ziehen><de> Ich ziehe München und Hanni Nürnberg, zwei Hauptpreise.
<G-vec00169-002-s524><draw_off.ziehen><en> I draw the energy I need for my work from my private life and share a lot of things with people I like.
<G-vec00169-002-s524><draw_off.ziehen><de> Ich ziehe ganz viel Energie für meine Arbeit aus meinem Privatleben und ich teile sehr viel mit Leuten, die ich mag.
<G-vec00169-002-s525><draw_off.ziehen><en> I believe that some political pressures are evident in the excerpt of the Report, but it will not be necessary for the reader to share my notions regarding the specific manifestations of these pressures in the excerpt in order to accept the major conclusion that I draw from the excerpt.
<G-vec00169-002-s525><draw_off.ziehen><de> Ich glaube, daß in diesem Auszug aus dem Bericht ein gewisser politischer Druck offensichtlich ist, aber es wird für den Leser nicht notwendig sein, meine Empfindungen im Hinblick auf besondere Bekundungen dieses Drucks in dem Auszug zu teilen, um die Hauptfolgerung anzuerkennen, die ich aus diesem Auszug ziehe.
<G-vec00169-002-s526><draw_off.ziehen><en> Draw the heel backward towards the floor to increase the stretch.
<G-vec00169-002-s526><draw_off.ziehen><de> Ziehe die Ferse in Richtung Boden, um die Dehnung zu verstärken.
<G-vec00169-002-s527><draw_off.ziehen><en> On the black shirt, draw the second line to the left of the center line when facing it.
<G-vec00169-002-s527><draw_off.ziehen><de> Ziehe die zweite Linie auf dem schwarzen Shirt links von der ursprünglichen Linie.
<G-vec00169-002-s528><draw_off.ziehen><en> If I draw a tarot card, then I assume that in our unconscious participatory life forces (both friendly and less friendly) are active. Am I still own the conscious subjective perception of my development, then shows me the Tarot card the exchange of views between the conscious and the unconscious.
<G-vec00169-002-s528><draw_off.ziehen><de> Wenn Ich eine Tarotkarte ziehe, dann gehe ich davon aus, dass in unserem Unbewussten mitbestimmende Lebenskräfte (wohltuende sowohl als auch weniger freundliche) aktiv sind, setze ich dann noch die bewusste eigene subjektive Wahrnehmung meines Lebens dazu, dann zeigt mir die Tarotkarte den im Jetzt und Hier stattfindenden Meinungsaustausch zwischen Bewusstem und Unbewusstem an.
<G-vec00169-002-s529><draw_off.ziehen><en> If you call it right, draw until your hand has 5 cards.
<G-vec00169-002-s529><draw_off.ziehen><de> Wenn du richtig vorausgesagt hast, ziehe, bis deine Hand 5 Karten enthält.
<G-vec00169-002-s530><draw_off.ziehen><en> Draw an imaginary line straight down from the North Star to the ground.
<G-vec00169-002-s530><draw_off.ziehen><de> Ziehe eine imaginäre Linie vom Nordstern auf den Boden.
<G-vec00169-002-s531><draw_off.ziehen><en> Contract your abs to draw your pelvic muscles toward your spine.
<G-vec00169-002-s531><draw_off.ziehen><de> Spanne deine Bauchmuskeln an und ziehe deine Beckenbodenmuskeln in Richtung deiner Wirbelsäule.
<G-vec00169-002-s532><draw_off.ziehen><en> This demands, above all, a willingness to draw lessons from the disaster we are currently experiencing.
<G-vec00169-002-s532><draw_off.ziehen><de> Dazu gehört vor allen Dingen die Bereitschaft, Lehren aus der Katastrophe zu ziehen, die wir gerade erleben.
<G-vec00169-002-s533><draw_off.ziehen><en> All countries need to draw firm conclusions from the current crisis.
<G-vec00169-002-s533><draw_off.ziehen><de> Alle Länder müssen ganz klare Schlüsse aus der aktuellen Krise ziehen.
<G-vec00169-002-s534><draw_off.ziehen><en> Using the Double Glam (107 Intense Blak and Champagne) black eyeliner, outline the outer eye contour along the upper and lower lash line. Using the black eyeshadow in the Beauty Apotheosis (02 Smokey Colour) palette, draw a thick line along the eyelid fold starting from the outer corner of the eye to where the eyebrow begins.
<G-vec00169-002-s534><draw_off.ziehen><de> Die äußere Augenkontur entlang des unteren und oberen Wimpernkranzes mit der schwarzen Farbe von Double Glam (107 Intense Blak and Champagne) eine kräftige Linie vom äußeren Augenwinkel bis zum Ansatz der Augenbraue ziehen, dabei der Falte des Augenlids folgen.
<G-vec00169-002-s535><draw_off.ziehen><en> The West must adopt a harsher tone and stop Russia's expansion, commentators urge, and draw parallels to the Anschluss of Austria by the Third Reich in 1938.
<G-vec00169-002-s535><draw_off.ziehen><de> Der Westen muss nun härtere Töne anschlagen und Russlands Expansion stoppen, fordern Kommentatoren und ziehen Parallelen zum Anschluss Österreichs an das Deutsche Reich 1938.
<G-vec00169-002-s536><draw_off.ziehen><en> You threw your clothes away from you, and with your nakedness tried to draw your neighbours toward you in the dark.
<G-vec00169-002-s536><draw_off.ziehen><de> Du hast deine Kleider von dir geworfen und mit deiner Nacktheit versucht, deine Nachbarn im Dunkeln an dich zu ziehen.
<G-vec00169-002-s537><draw_off.ziehen><en> I find it difficult to draw a line – to say, that’s artificial life, a living machine, and that’s not artificial life....
<G-vec00169-002-s537><draw_off.ziehen><de> Mir fällt es schwer, eine klare Grenze zu ziehen: Zu sagen, das ist künstliches Leben, eine Living Machine und das ist kein künstliches Leben...
<G-vec00169-002-s538><draw_off.ziehen><en> Take the doll in front of you and draw with a mechanical pencil eyes and hair.
<G-vec00169-002-s538><draw_off.ziehen><de> Nehmen Sie die Puppe vor Ihnen und ziehen mit einem mechanischen Bleistift Augen und Haare.
<G-vec00169-002-s539><draw_off.ziehen><en> For this, they heat one liter of red juice of your choice and add 1 tablespoon of our spice mixture, let it draw for 10 minutes and let it off.
<G-vec00169-002-s539><draw_off.ziehen><de> Dafür erhitzten sie einen Liter Roten Saft Ihrer Wahl und geben 1 EL unserer Gewürzmischung hinzu, lassen sie es 10 Minuten ziehen und seien sie es ab.
<G-vec00169-002-s540><draw_off.ziehen><en> (1.1.11.4.2.1.1) Connections of memories: If other memories are connected with the information or thought, on which one concentrates, these other memories can draw the attention to themselves.
<G-vec00169-002-s540><draw_off.ziehen><de> (1.1.11.4.2.1.1) Verbindungen von Erinnerungen: Wenn andere Erinnerungen mit den Informationen oder Gedanken verbunden sind, auf die man sich konzentriert, können diese anderen Erinnerungen die Aufmerksamkeit auf sich ziehen.
<G-vec00169-002-s541><draw_off.ziehen><en> The Blue Crack has recognized that it by no means matter whether you only sings a song or even writing, but on to draw the listener into his spell.
<G-vec00169-002-s541><draw_off.ziehen><de> Der Bluescrack hat erkannt, dass es mitnichten darauf ankommt, ob man einen Song lediglich singt oder selbst schreibt, sondern darauf, den Zuhörer in seinen Bann zu ziehen.
<G-vec00169-002-s542><draw_off.ziehen><en> I encourage you to study this teaching carefully, so as to draw out of it, all the elements that will lead you to a sincere repentance before the Lord, and to a radical change in your spiritual life.
<G-vec00169-002-s542><draw_off.ziehen><de> Ich ermutige Sie, diesen Unterricht gut zu untersuchen, um daraus alle Elemente zu ziehen, die Sie zu einer aufrichtigen Buße vor dem Herrn und zu einer radikalen Veränderung in Ihrem geistlichen Leben führen müssen.
<G-vec00169-002-s543><draw_off.ziehen><en> Albero is the perfect synthesis of a natural pattern and creative design: dark branches on a cream-coloured background draw the eye in deeper and open up new perspectives.
<G-vec00169-002-s543><draw_off.ziehen><de> Albero ist die perfekte Synthese aus natürlichem Vorbild und kreativer Gestaltung: Dunkle Äste auf cremefarbenem Hintergrund ziehen den Blick in die Weite und eröffnen neue Perspektiven.
<G-vec00169-002-s544><draw_off.ziehen><en> The presented themes around colour, ritual, movement and textile draw us into the artist’s universe of constructed narratives, both real and imagined.
<G-vec00169-002-s544><draw_off.ziehen><de> Die präsentierten Themen rund um Farbe, Ritual, Bewegung und Textil ziehen uns in das Universum konstruierter Erzählungen des Künstlers, sowohl real als auch imaginär.
<G-vec00169-002-s545><draw_off.ziehen><en> As early as 1935, Daimler-Benz was able to draw the conclusion that “all-steel bodies are used for the smallest as well as for the largest bus and all-weather vehicle because this design has proved superior to wooden bodywork structures in every respect.” The plant had thus converted the entire range of Mercedes-Benz buses to all-steel bodywork within the shortest conceivable time.
<G-vec00169-002-s545><draw_off.ziehen><de> Schon im Jahr 1935 kann Daimler-Benz als Fazit ziehen: „Für den kleinsten wie auch den größten Omnibus und Allwetter-Wagen werden Ganzstahlaufbauten vorgesehen, da sich diese Bauweise dem Holzaufbau in jeder Hinsicht überlegen gezeigt hat.“ In kürzester Zeit hat das Werk also das gesamte Programm für Mercedes-Benz Omnibusse umgestellt.
<G-vec00169-002-s546><draw_off.ziehen><en> After the people in the square had, right at the beginning, chanted the slogan "People and army go hand in hand" in order to reassure themselves and draw the army firmly onto their side, the military made haste to adopt this slogan as their own.
<G-vec00169-002-s546><draw_off.ziehen><de> Nachdem die Menschen auf dem Platz schon in den ersten Momenten die Losung "Volk und Armee gehen Hand in Hand" ausgegeben hatten, um sich selbst zu beruhigen und die Armee fest auf ihre Seite zu ziehen, beeilte sich das Militär, sich dieser Losung zu bemächtigen.
<G-vec00169-002-s547><draw_off.ziehen><en> Case studies will draw potential customers into your sales funnel, and at the very least encourage them to sign up to receive emails from your business.
<G-vec00169-002-s547><draw_off.ziehen><de> Fallstudien ziehen potenzielle Kunden in Ihren Verkaufstrichter und ermutigen sie zumindest dazu, sich für den Empfang von E-Mails von Ihrem Unternehmens anzumelden.
<G-vec00169-002-s548><draw_off.ziehen><en> Use the mouse to draw lines. Categories: Arcade Games
<G-vec00169-002-s548><draw_off.ziehen><de> Verwende den Mauszeiger, um in diesem Onlinespiel die Striche zu ziehen.
<G-vec00169-002-s549><draw_off.ziehen><en> It is therefore necessary to draw conclusion about the market and the competition from other sources of information.
<G-vec00169-002-s549><draw_off.ziehen><de> Es ist daher notwendig aus anderen Informationsquellen Rückschlüsse auf den Markt und die Wettbewerber zu ziehen.
<G-vec00169-002-s550><draw_off.ziehen><en> While this Monster is face-up on your Field, during your End Phase, you may put 1 Normal Monster in your hand at the bottom of your deck to draw 1 card.
<G-vec00169-002-s550><draw_off.ziehen><de> Solange sich diese Karte offen auf deiner Spielfeldseite befindet, kannst du in deiner End Phase 1 normale Monsterkarte von deiner Hand unter dein Deck legen, um 1 Karte von deinem Deck zu ziehen.
<G-vec00169-002-s551><draw_off.ziehen><en> You do not want to draw extra attention to yourself because you are acting nervously.
<G-vec00169-002-s551><draw_off.ziehen><de> Wenn du nervös wirkst, ziehst du nur unnötige Aufmerksamkeit auf dich.
<G-vec00169-002-s552><draw_off.ziehen><en> Irresistibly beautiful and never boring: you will draw all the looks with the Racing red uni basic colour.
<G-vec00169-002-s552><draw_off.ziehen><de> Racingred uni Bestechend schön und niemals langweilig: Mit der Basisfarbe Racingred uni ziehst Du die Blicke auf Dich.
<G-vec00169-002-s553><draw_off.ziehen><en> Next time you'll draw another one.
<G-vec00169-002-s553><draw_off.ziehen><de> Das nächste Mal ziehst du einen anderen.
<G-vec00169-002-s554><draw_off.ziehen><en> Using your ruler, begin at the tail of the vector and draw a horizontal line as wide as necessary to coincide with the head of the vector.
<G-vec00169-002-s554><draw_off.ziehen><de> Mit deinem Lineal beginnst du am Anfangspunkt des Vektors und ziehst eine horizontale Linie so weit wie nötig, sodass sie mit dem Endpunkt übereinstimmt.
<G-vec00169-002-s555><draw_off.ziehen><en> You will draw 7 cards less during the next drawing phase.
<G-vec00169-002-s555><draw_off.ziehen><de> Bei der nächsten Zugphase ziehst du 7 Karten weniger.
<G-vec00169-002-s556><draw_off.ziehen><en> 10 "When you draw near to a city to fight against it, offer terms of peace to it. 11 And if its answer to you is peace and it opens to you, then all the people who are found in it shall do forced labor for you and shall serve you. 12 But if it makes no peace with you, but makes war against you, then you shall besiege it; 13 and when the LORD your God gives it into your hand you shall put all its males to the sword, 14 but the women and the little ones, the cattle, and everything else in the city, all its spoil, you shall take as booty for yourselves; and you shall enjoy the spoil of your enemies, which the LORD your God has given you.
<G-vec00169-002-s556><draw_off.ziehen><de> Der Krieg gegen Städte 10 Wenn du vor eine Stadt ziehst, um sie anzugreifen, dann sollst du ihr zunächst eine friedliche Einigung vorschlagen.11 Nimmt sie die friedliche Einigung an und öffnet dir die Tore, dann soll die gesamte Bevölkerung, die du dort vorfindest, zum Frondienst verpflichtet und dir untertan sein.12 Lehnt sie eine friedliche Einigung mit dir ab und will sich mit dir im Kampf messen, dann darfst du sie belagern.13 Wenn der Herr, dein Gott, sie in deine Gewalt gibt, sollst du alle männlichen Personen mit scharfem Schwert erschlagen.14 Die Frauen aber, die Kinder und Greise, das Vieh und alles, was sich sonst in der Stadt befindet, alles, was sich darin plündern läßt, darfst du dir als Beute nehmen.
<G-vec00169-002-s557><draw_off.ziehen><en> Whenever equipped creature deals combat damage to a player, Sword of Fire and Ice deals 2 damage to target creature or player and you draw a card. Equip {2}
<G-vec00169-002-s557><draw_off.ziehen><de> Immer wenn die ausgerüstete Kreatur einem Spieler Kampfschaden zufügt, fügt das Schwert aus Feuer und Eis einer Kreatur oder einem Spieler deiner Wahl 2 Schadenspunkte zu und du ziehst eine Karte.
<G-vec00169-002-s558><draw_off.ziehen><en> You draw two cards and you lose 2 life.
<G-vec00169-002-s558><draw_off.ziehen><de> Du ziehst 2 Karten und verlierst 2 Lebenspunkte.
<G-vec00169-002-s559><draw_off.ziehen><en> They are placed in your Deck and you draw until you have 5 card in your Hand.
<G-vec00169-002-s559><draw_off.ziehen><de> Sie werden in dein Deck platziert und du ziehst neue Karten, bis du wieder 5 Karten auf der Hand hast.
<G-vec00169-002-s560><draw_off.ziehen><en> Once the raffle is over, you draw out names to see who won the prizes.
<G-vec00169-002-s560><draw_off.ziehen><de> Wenn der Teilnahmezeitraum abgelaufen ist, ziehst du die Namen und verkündest die Gewinner.
<G-vec00169-002-s561><draw_off.ziehen><en> The black and white Zombie Harlequin costume is a real sight and with the bells on the fool hood you draw additional attention to you.
<G-vec00169-002-s561><draw_off.ziehen><de> Das schwarz-weiße Böser Harlekin Kostüm ist ein echter Blickfang und mit den Glöckchen an der Narrenhaube ziehst du noch mehr Aufmerksamkeit auf dich.
<G-vec00169-002-s562><draw_off.ziehen><en> In order to do that, draw a line from one stone to another of the same colour.
<G-vec00169-002-s562><draw_off.ziehen><de> Mach dies indem du eine Linie ziehst von einem Stein zu dem Anderen mit der gleichen Farbe.
<G-vec00169-002-s563><draw_off.ziehen><en> You mix the cards and draw the joker.
<G-vec00169-002-s563><draw_off.ziehen><de> Du mischst die Karten neu und ziehst den Joker.
<G-vec00169-002-s564><draw_off.ziehen><en> One time only, when you draw a Monster Card during your Draw Phase while this card is in your Graveyard: You can reveal it; Special Summon it.
<G-vec00169-002-s564><draw_off.ziehen><de> Nur einmal, wenn du während deiner Draw Phase eine Monsterkarte ziehst, solange sich diese Karte in deinem Friedhof befindet: Du kannst sie vorzeigen; beschwöre sie als Spezialbeschwörung.
<G-vec00169-002-s565><draw_off.ziehen><en> * If you target yourself with Jace’s first ability, you’ll draw a card first, then put the top card of your library into your graveyard.
<G-vec00169-002-s565><draw_off.ziehen><de> * Falls du dich selbst als Ziel von Jaces erster Fähigkeit wählst, ziehst du erst eine Karte und legst dann die oberste Karte deiner Bibliothek auf deinen Friedhof.
<G-vec00169-002-s566><draw_off.ziehen><en> The card you draw will be Bright Star Dragon.
<G-vec00169-002-s566><draw_off.ziehen><de> Die Karte, die du ziehst, wird Leuchtsterndrache sein.
<G-vec00169-002-s567><draw_off.ziehen><en> This can either be typed in, or you can draw a rectangle or box around one element to define it.
<G-vec00169-002-s567><draw_off.ziehen><de> Der Abstand kann entweder eingegeben werden, oder Du ziehst ein Rechteck oder eine Box um ein Element, um den Abstand zu definieren.
<G-vec00169-002-s568><draw_off.ziehen><en> If you draw a skip card, you can distribute a sip.
<G-vec00169-002-s568><draw_off.ziehen><de> Wenn du eine Aussetzen-Karte ziehst, darfst du einen Schluck verteilen.
<G-vec00169-002-s569><draw_off.ziehen><en> Until end of turn, if target player would draw a card, instead that player skips that draw and you draw a yourself, this spell has no useful effect.
<G-vec00169-002-s569><draw_off.ziehen><de> Falls bis zum Ende des Zuges ein Spieler deiner Wahl eine Karte ziehen würde, übergeht dieser Spieler dieses Kartenziehen stattdessen, und du ziehst eine Karte.
<G-vec00169-002-s570><draw_off.ziehen><en> When using these general data and information, the Something Curated does not draw any conclusions about the data subject.
<G-vec00169-002-s570><draw_off.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Fachpraxis für Podologie Flinner UG und KO KG keine Rückschlüsse auf die betroffene Person.
<G-vec00169-002-s571><draw_off.ziehen><en> Lengthy questioning and interrogation will only draw attention to the sexual area and burden the child even more.
<G-vec00169-002-s571><draw_off.ziehen><de> Viel Befragen und Verhören zieht nur zusätzliche Aufmerksamkeit auf den sexuellen Bereich und belastet das Kind unnötig.
<G-vec00169-002-s572><draw_off.ziehen><en> And the team only has to draw the soft and heavy loden curtains that hang from the dark wooden ceiling to create a more intimate atmo sphere for smaller events.
<G-vec00169-002-s572><draw_off.ziehen><de> Und soll der Raum für kleinere Veranstaltungen etwas intimer wirken, zieht das Team einfach an den schweren, weichen Lodenvorhängen, die von der dunklen Holzdecke hängen.
<G-vec00169-002-s573><draw_off.ziehen><en> The wave concept enables you to draw attention to the overall design and give shape to the empty space that is left behind.
<G-vec00169-002-s573><draw_off.ziehen><de> Das Wellenkonzept zieht die Aufmerksamkeit auf das Gesamtdesign und gibt damit den Leerräumen, die sich dahinter verbergen, ein Profil.
<G-vec00169-002-s574><draw_off.ziehen><en> When using these general data and information, the Dr. Jan Hendrik Taubert – Exclusive Advice Worldwide does not draw any conclusions about the data subject.
<G-vec00169-002-s574><draw_off.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Dr. Jan Hendrik Taubert – Exclusive Advice Worldwide keine Rückschlüsse auf die betroffene Person.
<G-vec00169-002-s575><draw_off.ziehen><en> When the responsible body uses this general data and other information, it does not draw any conclusions about the specific individual concerned.
<G-vec00169-002-s575><draw_off.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die verantwortliche Stelle keine Rückschlüsse auf die betroffene Person.
<G-vec00169-002-s576><draw_off.ziehen><en> From these mistakes, people now draw the conclusion that the problem can only be rectified by avoiding any manager with a language barrier.
<G-vec00169-002-s576><draw_off.ziehen><de> Aus diesen Fehlentwicklungen zieht man nun das Fazit, dass das Problem nur dadurch zu beheben ist, überhaupt keinen Trainer mit Sprachbarrieren einzustellen.
<G-vec00169-002-s577><draw_off.ziehen><en> When using these general data and information, the Something Curated does not draw any conclusions about the data subject.
<G-vec00169-002-s577><draw_off.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Private Homepage Bananapage - Thomas Klabunde keine Rückschlüsse auf die betroffene Person.
<G-vec00169-002-s578><draw_off.ziehen><en> When using this general data and information, Ferag AG does not draw conclusions on the identity of the data subject.
<G-vec00169-002-s578><draw_off.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Meile GmbH keine Rückschlüsse auf die betroffene Person.
<G-vec00169-002-s579><draw_off.ziehen><en> To name only one example: in traditional Lovara communities, it is taboo for a woman to draw attention to herself – e.g. at family gatherings.
<G-vec00169-002-s579><draw_off.ziehen><de> Um nur ein Beispiel zu nennen: In traditionellen Lovara-Gemeinschaften gilt es für eine Frau als Schande, wenn sie – etwa bei einer Familienzusammenkunft – unaufgefordert die Aufmerksamkeit auf sich zieht.
<G-vec00169-002-s580><draw_off.ziehen><en> NASA is a big draw, but were also proud to regularly host business travelers in town with Lockheed Martin, Boeing and Northrop Grumman.
<G-vec00169-002-s580><draw_off.ziehen><de> NASA zieht viele Besucher an, aber auch Reisende, die geschäftlich bei Lockheed Martin, Boeing und Northrop Grumman zu tun haben, entscheiden sich oft für unser Hotel.
<G-vec00169-002-s581><draw_off.ziehen><en> When using these general data and information, the Diamond League AG does not draw any conclusions about the data subject.
<G-vec00169-002-s581><draw_off.ziehen><de> Die First-Immobilien & Wohnbau GmbH zieht durch diese allgemeinen Informationen und Daten keinerlei Rückschlüsse auf den Nutzer.
<G-vec00169-002-s582><draw_off.ziehen><en> After they know also the music industry now learned, them draw an interesting comparison.
<G-vec00169-002-s582><draw_off.ziehen><de> Nachdem sie jetzt auch die Musikbranche kennen gelernt hat, zieht sie einen interessanten Vergleich.
<G-vec00169-002-s583><draw_off.ziehen><en> This is how it works: Draw two imaginary horizontal and two vertical lines through your picture, thereby creating 9 even rectangles.
<G-vec00169-002-s583><draw_off.ziehen><de> So gehts: Man zieht zwei horizontale und zwei vertikale Striche durchs Bild und unterteilt es so in 9 gleichmässige Rechtecke.
<G-vec00169-002-s584><draw_off.ziehen><en> When using these general data and information, the VITO AG does not draw any conclusions about the data subject.
<G-vec00169-002-s584><draw_off.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Flagfactory Germany UG (haftungsbeschränkt) keine Rückschlüsse auf die betroffene Person.
<G-vec00169-002-s585><draw_off.ziehen><en> An easy way to lose in Magic is to just draw the wrong mix of lands and spells.
<G-vec00169-002-s585><draw_off.ziehen><de> Man kann bei Magic sehr leicht einfach dadurch verlieren, dass man die falsche Mischung aus Ländern und Zaubern zieht.
<G-vec00169-002-s586><draw_off.ziehen><en> But a gas flow too high will draw oxygen due to turbulences to the weld seam.
<G-vec00169-002-s586><draw_off.ziehen><de> Aber auch ein zu hoher Schutzgasstrom zieht durch Turbulenzen Sauerstoff in die Schweißnaht.
<G-vec00169-002-s587><draw_off.ziehen><en> Hampstead Heath has a large draw for those who play sports, including cricket, croquet and fishing.
<G-vec00169-002-s587><draw_off.ziehen><de> Hampstead Heath zieht all diejenigen an, die gerne Sport treiben wie zum Beispiel Cricket, Croquet oder Angeln.
<G-vec00169-002-s588><draw_off.ziehen><en> Greter plunges her arm – clad in a green plastic glove – deep into the rectum to draw out fresh dung.
<G-vec00169-002-s588><draw_off.ziehen><de> Helena Greter greift mit einem grünen Plastikhandschuh tief in den Darmausgang des Viehs und zieht frischen Kot heraus.
