<G-vec00316-003-s019><come_through.bieten><en> Many rooms come with a spectacular view over the hills.
<G-vec00316-003-s019><come_through.bieten><de> Viele Zimmer bieten eine tolle Ausblick auf die Berge an.
<G-vec00316-003-s020><come_through.bieten><en> Some rooms come with a view of Battery Park.
<G-vec00316-003-s020><come_through.bieten><de> Die modernen Hotelzimmer bieten einen Blick auf die Skyline.
<G-vec00316-003-s021><come_through.bieten><en> Rooms come with the garden view.
<G-vec00316-003-s021><come_through.bieten><de> Die Zimmer bieten einen wunderbaren Ausblick auf den Garten.
<G-vec00316-003-s022><come_through.bieten><en> Non-smoking rooms come with an in-room safe, climate control, flat-screen TV, a dining area and a closet. The property offers a bathroom with a shower and a bidet.
<G-vec00316-003-s022><come_through.bieten><de> Die En-suite Zimmer bieten einen Zimmersafe, eine Minibar, Kabelfernsehen mit Video-on-demand, einen Wohnbereich und einen Schreibtisch sowie eine tolle Aussicht auf das Meer.
<G-vec00316-003-s023><come_through.bieten><en> Rooms in Hotel Garni Elba come with a coffee/tea maker.
<G-vec00316-003-s023><come_through.bieten><de> Die Zimmer im Hotel Garni Elba mit einer Küche bieten Kaffeemaschine/Teekocher.
<G-vec00316-003-s024><come_through.bieten><en> Classic-style rooms at the Il Corallo bed and breakfast come with a TV and a private bathroom including a hairdryer.
<G-vec00316-003-s024><come_through.bieten><de> Die Doppelzimmer sind im klassischen Stil eingerichtet, und bieten Ihnen einen Flachbild-TV und ein eigenes Bad mit einem Haartrockner und Handtüchern.
<G-vec00316-003-s025><come_through.bieten><en> Some rooms come with a stunning view of Arabian Gulf.
<G-vec00316-003-s025><come_through.bieten><de> Die Zimmer bieten einen tollen Blick auf die Lagune.
<G-vec00316-003-s026><come_through.bieten><en> Guest units come with air conditioning, tiled floors and a private terrace with serene ocean views.
<G-vec00316-003-s026><come_through.bieten><de> Die Unterkünfte bieten eine Klimaanlage, Fliesenböden und eine private Terrasse mit ruhigem Meerblick.
<G-vec00316-003-s027><come_through.bieten><en> With astonishing brightness, incomparable contrast and captivating color, images come to life with much greater brightness while also featuring much deeper, more nuanced darks.
<G-vec00316-003-s027><come_through.bieten><de> Mithilfe punktueller Dimmfunktion und hoher maximaler Helligkeit bis zu 600 Nit werden Bilder mit sichtbaren Höhepunkten zum Leben erweckt, die tiefere, nuanciertere Schwarztöne bieten.
<G-vec00316-003-s028><come_through.bieten><en> World of Judaica's Israeli Bookmarks come in a variety of styles and shapes.
<G-vec00316-003-s028><come_through.bieten><de> Wir bieten eine Vielfalt an Mesusas,Tallitot, Jüdischem Schmuck und weiteren Dingen an.
<G-vec00316-003-s029><come_through.bieten><en> Certain rooms come with a balcony.
<G-vec00316-003-s029><come_through.bieten><de> Einige Zimmer bieten einen Balkon.
<G-vec00316-003-s030><come_through.bieten><en> Rooms come with a private bathroom equipped with a bath or shower.
<G-vec00316-003-s030><come_through.bieten><de> Die Zimmer bieten Ihnen ein eigenes Bad mit einer Badewanne oder einer Dusche.
<G-vec00316-003-s031><come_through.bieten><en> The rooms come with en suite bathrooms featuring a shower, free toiletries and a hairdryer.
<G-vec00316-003-s031><come_through.bieten><de> Sie bieten private Badezimmer, die über eine Dusche, einen Fön und eine Badewanne verfügen.
<G-vec00316-003-s032><come_through.bieten><en> All rooms come with a seating area and a toilet with shower, hairdryer and free toiletries.
<G-vec00316-003-s032><come_through.bieten><de> Alle Zimmer bieten einen Sitzbereich sowie ein Bad mit Dusche, Haartrockner und kostenlosen Pflegeprodukten.
<G-vec00316-003-s033><come_through.bieten><en> Quality materials and thorough workmanship guarantee a long service life and a reflection of excellence for years to come.
<G-vec00316-003-s033><come_through.bieten><de> Qualitativ hochwertige Materialien und solide Ausführung bieten die Gewähr für lange Lebensdauer und ein auf Dauer attraktives Erscheinungsbild.
<G-vec00316-003-s034><come_through.bieten><en> The apartments come with a kitchen, a dining area and a private bathroom.
<G-vec00316-003-s034><come_through.bieten><de> Die Apartments bieten Ihnen eine Küche, einen Essbereich und ein eigenes Bad.
<G-vec00316-003-s035><come_through.bieten><en> Some hotel rooms come with a panoramic view over the sea.
<G-vec00316-003-s035><come_through.bieten><de> Die Zimmer bieten einen tollen Ausblick auf das Meer.
<G-vec00316-003-s036><come_through.bieten><en> Room description The spacious rooms each come with a bath/ shower, a hairdryer, a direct dial telephone, a satellite TV, a radio and high speed Internet access.
<G-vec00316-003-s036><come_through.bieten><de> Zimmerbeschreibung Die Hotelzimmer bieten ein eigenes Badezimmer mit Dusche/Badewanne und Haartrockner sowie ein Direktwahltelefon, ein TV-Gerät mit Sat.-Kanälen, ein Radio und DSL-Internetzugang.
<G-vec00316-003-s037><come_through.bieten><en> These comfortable rooms come with a hairdryer and a Jacuzzi supplied in a designer bathroom.
<G-vec00316-003-s037><come_through.bieten><de> Die Zimmer bieten En-suite-Badezimmer mit einer Badewanne, einem Fön und einem Jacuzzi.
<G-vec00316-003-s076><come_through.entstehen><en> Something Great will come of it...
<G-vec00316-003-s076><come_through.entstehen><de> Es wird Großartiges daraus entstehen...
<G-vec00316-003-s077><come_through.entstehen><en> The basis for peace of mind is self-confidence and inner strength, which come from the practice of love and compassion, with a sense of respect for others and concern for their well-being.
<G-vec00316-003-s077><come_through.entstehen><de> Die Grundlage für geistigen Frieden ist Selbstvertrauen und innere Stärke, die durch die Praxis von Liebe und Mitgefühl, mit einem Gefühl des Respekts gegenüber anderen und einer Sorge um ihr Wohlergehen, entstehen.
<G-vec00316-003-s078><come_through.entstehen><en> My works come about in Hamburg Altona and Großenwörden in the inspiring Osteland.
<G-vec00316-003-s078><come_through.entstehen><de> Meine Arbeiten entstehen in Hamburg Altona und in Großenwörden im inspirierenden Osteland.
<G-vec00316-003-s079><come_through.entstehen><en> Combined with khaki, gold, thistle and indigo blue, interesting cold/warm contrasts come to light.
<G-vec00316-003-s079><come_through.entstehen><de> Kombiniert mit Khaki, Gold, Distelgrün und Indigo Blue entstehen interessante Kalt-Warm-Kontraste.
<G-vec00316-003-s080><come_through.entstehen><en> This is how the best services come about.
<G-vec00316-003-s080><come_through.entstehen><de> Auf diese Weise entstehen die besten Services.
<G-vec00316-003-s081><come_through.entstehen><en> An alternative approach may come from the potential therapeutic qualities of CBD.
<G-vec00316-003-s081><come_through.entstehen><de> Ein alternativer Ansatz könnte aus den potenziell therapeutischen Qualitäten von CBD entstehen.
<G-vec00316-003-s082><come_through.entstehen><en> Everything actually needs to come into being from nothing.
<G-vec00316-003-s082><come_through.entstehen><de> Alles muss eigentlich aus dem Nichts entstehen.
<G-vec00316-003-s083><come_through.entstehen><en> They come as well when the priesthood service is to members within the quorum.
<G-vec00316-003-s083><come_through.entstehen><de> Sie entstehen auch, wenn das Kollegium durch das Priestertum den Mitgliedern in seinen eigenen Reihen dient.
<G-vec00316-003-s084><come_through.entstehen><en> Or we can provide a complete team so the aforementioned problems don’t come up in the first place.
<G-vec00316-003-s084><come_through.entstehen><de> Oder wir stellen gleich ein komplettes Team, damit die oben beschriebenen Probleme erst gar nicht entstehen können.
<G-vec00316-003-s085><come_through.entstehen><en> And when a group unites against something, an amazingly powerful strength can come out of it.
<G-vec00316-003-s085><come_through.entstehen><de> Und wenn sich eine Gruppe gegen etwas vereinigt, kann daraus eine mächtige Energie entstehen.
<G-vec00316-003-s086><come_through.entstehen><en> It is important for self-confidence, but it can only come from someone else.
<G-vec00316-003-s086><come_through.entstehen><de> Sie ist wichtig für das Selbstbewusstsein, kann aber nicht aus dem eigenen Ich heraus entstehen.
<G-vec00316-003-s087><come_through.entstehen><en> At least I was able to sense, how his manipulated photographs could come into being.
<G-vec00316-003-s087><come_through.entstehen><de> Zumindest erahne ich gerade, wie seine manipulierte Fotografie entstehen könnte.
<G-vec00316-003-s088><come_through.entstehen><en> The object of much of today’s humanities research and cultural criticism is to demonstrate how an imaginary geography or an imagined community develops permanence and boundaries and ultimately replaces reality itself, and how this happens through identification processes in which some elements are discarded in order for that community’s identity to come into being, be it Swedish, Nordic, European or global.
<G-vec00316-003-s088><come_through.entstehen><de> Gegenstand der geisteswissenschaftlichen Forschung und Kulturkritik ist heute häufig, aufzuzeigen, wie eine imaginäre Geographie oder imaginäre Gemeinschaft Stabilität und Grenzen erhält und am Ende selbst den Platz der Wirklichkeit einnimmt, und wie dies durch Identifikationsprozesse geschieht, in denen manches aussortiert wird, damit die eigene Identität entstehen kann, ganz gleich ob schwedisch, nordisch, europäisch oder global.
<G-vec00316-003-s089><come_through.entstehen><en> Netflix also reported that more than 60% of its rentals come from recommendations that are based off of hyper personalization data. **
<G-vec00316-003-s089><come_through.entstehen><de> Auch Netflix berichtet, dass 60% ihrer Verkäufe aus Vorschlägen entstehen, die Kunden aufgrund ihrer personalisierten Daten erhalten.
<G-vec00316-003-s090><come_through.entstehen><en> You need creativity and skill to make Bronze Age decorations from metal and let the Middle Ages come to life with self decorated beads.
<G-vec00316-003-s090><come_through.entstehen><de> Kreativität und Geschick sind gefragt, wenn aus Metall bronzezeitliche Geschmeide entstehen und selbst verzierte Perlen das Mittelalter auferstehen lassen.
<G-vec00316-003-s091><come_through.entstehen><en> I’m not quite sure how the pictures come about, and why they are what they are.
<G-vec00316-003-s091><come_through.entstehen><de> Ich weiß nicht genau, wie die Bilder entstehen, und woran es liegt, wie sie sind.
<G-vec00316-003-s092><come_through.entstehen><en> Yet we all have long known that extraordinary ideas seldom come from nowhere.
<G-vec00316-003-s092><come_through.entstehen><de> Dabei wissen wir längst, dass außergewöhnliche Einfälle selten aus einem Vakuum heraus entstehen.
<G-vec00316-003-s093><come_through.entstehen><en> The relevant research is in the tradition of the resource-based basis and has not yet decided sufficiently what exactly dynamical capabilities are, where they are rooted in the organization, how they come into being, and how their advantage can be unfolded.
<G-vec00316-003-s093><come_through.entstehen><de> Die in der Tradition des ressourcen-orientierten Ansatzes stehende einschlägige Forschung hat bislang jedoch noch nicht hinreichend bestimmt, was genau unter dynamischen Fähigkeiten zu verstehen ist, wo in der Organisation sie zu verorten sind, wodurch sie entstehen und wie genau sich ihr Nutzen entfaltet.
<G-vec00316-003-s094><come_through.entstehen><en> Time and again almost magical moments come up - so great is the intimacy between the protagonists on stage and the audience.
<G-vec00316-003-s094><come_through.entstehen><de> So entstehen auch immer wieder fast schon magische Momente - so groß wird die Innigkeit zwischen den Akteuren auf der Bühne und dem Publikum.
<G-vec00316-003-s114><come_through.finden><en> "Players like him are hard to come by.
<G-vec00316-003-s114><come_through.finden><de> "Es ist sehr schwer, einen Spieler wie ihn zu finden.
<G-vec00316-003-s115><come_through.finden><en> You’ll hardly come across a model that is prettier and better.
<G-vec00316-003-s115><come_through.finden><de> Ein Exemplar, das schöner oder besser ist, werden Sie mit Sicherheit nicht finden.
<G-vec00316-003-s116><come_through.finden><en> Right in the center of Rotterdam, next to Blaak Station, you will come across this chocolate paradise in the Markthal.
<G-vec00316-003-s116><come_through.finden><de> Mitten im Zentrum von Rotterdam, neben der Blaak Station, finden Sie dieses Schokoladenparadies in der Markthal.
<G-vec00316-003-s117><come_through.finden><en> Our team is made up of people from various backgrounds who together can come up with an answer to any question.
<G-vec00316-003-s117><come_through.finden><de> Es besteht aus Menschen verschiedener Hintergrunds, die gemeinsam für jede Frage eine Antwort finden können.
<G-vec00316-003-s118><come_through.finden><en> It is a humanitarian imperative that the suffering, hunger and deaths finally come to an end.
<G-vec00316-003-s118><come_through.finden><de> Es ist ein Gebot der Menschlichkeit, dass Leiden, Hungern und Sterben endlich ein Ende finden.
<G-vec00316-003-s119><come_through.finden><en> In practice, work opportunities are rather more limited, although there is some seasonal tourist industry work available during the summer if you have the requisite skills and language abilities (Norwegian will come in handy).
<G-vec00316-003-s119><come_through.finden><de> In der Praxis ist die Arbeitserlaubnis trotzdem erschwert, obwohl du sehr schnell in der saisonalen Tourismusbranche eine Arbeit finden kannst, vorausgesetzt, du besitzt die nötigen Anforderungen und Sprachkenntnisse in Norwegisch.
<G-vec00316-003-s120><come_through.finden><en> If you want to learn English, make friends, have fun and explore the UK come and join us in the July and/or August.
<G-vec00316-003-s120><come_through.finden><de> Wenn Sie Englisch lernen, Freunde finden, Spaß haben und das Vereinigte Königreich erkunden möchten, besuchen Sie uns im Juli und / oder August.
<G-vec00316-003-s121><come_through.finden><en> It had saved his ears more then once to be able to come up with a believable explanation why some disaster was not at all related to the fact that he had been close.
<G-vec00316-003-s121><come_through.finden><de> Damit hatte er seine Ohren mehr als einmal retten können, wenn es darum ging eine glaubhaften Erklärung zu finden für die Tatsache, warum irgendeine Katastrophe ganz sicher nichts mit seiner Anwesenheit zu tun hatte.
<G-vec00316-003-s122><come_through.finden><en> It seems like it should be fairly easy for the two sides to come together.
<G-vec00316-003-s122><come_through.finden><de> Es scheint, als sollte es für die beiden Seiten relativ leicht sein, eine Einigung zu finden.
<G-vec00316-003-s123><come_through.finden><en> My immune system has crashed completely, I welcome each bacteria and virus I come across.
<G-vec00316-003-s123><come_through.finden><de> Mein Immunsystem ist so im Eimer, dass ich jede Bakterie und jeden Virus mitnehmen, den ich finden kann.
<G-vec00316-003-s124><come_through.finden><en> True unicorns that meet all of our criteria are hard to come by.
<G-vec00316-003-s124><come_through.finden><de> Wahre Unicorns, die alle unsere Kriterien erfüllen, sind jedoch schwer zu finden.
<G-vec00316-003-s125><come_through.finden><en> I, therefore, do not believe anybody could come up with a universal “sufficient condition” based on which you can always tell whether or not an enterprise has been acting ethically or not.
<G-vec00316-003-s125><come_through.finden><de> So glaube ich nicht, dass es genügt und gelingt, eine allgemeine „hinreichende Bedingung“ zu finden, an der gemessen werden kann, ob ein Unternehmen ethisch handelt oder nicht.
<G-vec00316-003-s126><come_through.finden><en> At that point the Iranian professor believed he’d come up with another argument.
<G-vec00316-003-s126><come_through.finden><de> In diesem Augenblick glaubte der Professor, ein anderes Argument zu finden.
<G-vec00316-003-s127><come_through.finden><en> One more fascinating variation you may come across web is Pontoon.
<G-vec00316-003-s127><come_through.finden><de> Eine andere interessante Internet-basierte Varianz Sie finden könnte, ist Pontoon.
<G-vec00316-003-s128><come_through.finden><en> The very goal of our industry is to come up with a smart and effective solution for these challenges.
<G-vec00316-003-s128><come_through.finden><de> Genau dies ist das Ziel unserer Branche: intelligente und effektive Lösungen für diese Herausforderungen zu finden.
<G-vec00316-003-s129><come_through.finden><en> Currently, there is not enough data and evidence to come up with a solution for that.
<G-vec00316-003-s129><come_through.finden><de> Gegenwärtig gibt es nicht genügend Daten und Beweise, um eine Lösung dafür zu finden.
<G-vec00316-003-s130><come_through.finden><en> Talking to other singles who have similar interests is a great way to come up with ideas to do on a first date.
<G-vec00316-003-s130><come_through.finden><de> Triff andere,die ähnliche Interessen haben, das ist ein perfekter Weg, um Ideen zu finden für gemeinsame Unternehmungen beim ersten Treffen.
<G-vec00316-003-s131><come_through.finden><en> Being a flexible co-packer, we would like to think along with you to come to your personal packaging solution.
<G-vec00316-003-s131><come_through.finden><de> Als flexibler Copacker arbeiten wir gerne mit Ihnen zusammen, um die für Sie ideale Verpackungslösung zu finden.
<G-vec00316-003-s132><come_through.finden><en> He added that he had been waiting for a lifetime to come up with a character together with his dad.
<G-vec00316-003-s132><come_through.finden><de> Er fügte hinzu, dass er auf ein Leben lang gewartet habe, um zusammen mit seinem Vater eine Figur zu finden.
<G-vec00316-003-s133><come_through.gehen><en> There are breathtaking film sets where visitors can come into close contact with the jaws of a great white shark, look underneath Marilyn Monroe's skirt or learn about fear at Jurassic Park.
<G-vec00316-003-s133><come_through.gehen><de> In atemberaubenden Filmkulissen können Besucher auf Tuchfühlung mit dem weißen Hai gehen, Marilyn Monroe unter den Rock schauen oder im Jurassic Park das Fürchten lernen.
<G-vec00316-003-s134><come_through.gehen><en> 44:25 And they shall come at no dead person to become unclean; but for father, or for mother, or for son, or for daughter, for brother, or for sister that hath had no husband, they may become unclean.
<G-vec00316-003-s134><come_through.gehen><de> 44:25 Und keiner soll zu dem Leichnam eines Menschen gehen, daß er unrein werde; nur allein wegen Vater und Mutter, und wegen Sohn und Tochter, wegen eines Bruders und wegen einer Schwester, die keines Mannes gewesen ist, dürfen sie sich verunreinigen.
<G-vec00316-003-s135><come_through.gehen><en> This is where interfaces and the single responsibility principle can come to work hand in hand.
<G-vec00316-003-s135><come_through.gehen><de> Hier können Schnittstellen und das Prinzip der einheitlichen Verantwortung Hand in Hand gehen.
<G-vec00316-003-s136><come_through.gehen><en> May your dream will come true this year.
<G-vec00316-003-s136><come_through.gehen><de> Möge Eure Wünsche auch in diesem Jahr in Erfüllung gehen.
<G-vec00316-003-s137><come_through.gehen><en> I hope you have a wonderful new year, and all your dreams and wished come true next year.
<G-vec00316-003-s137><come_through.gehen><de> Ich hoffe ihr habt ein wunderschönes neues Jahr und all eure Wünsche und Träume gehen dieses Jahr in Erfüllung.
<G-vec00316-003-s138><come_through.gehen><en> Sport has always played an important role in my life, in part because I come from a family of athletes.
<G-vec00316-003-s138><come_through.gehen><de> Auch Sport spielte schon immer eine wichtige Rolle in meinem Leben, egal ob Fußball spielen mit meinen Freunden oder einfach im Morgengrauen joggen gehen.
<G-vec00316-003-s139><come_through.gehen><en> Bishops should encourage priests to come to Medjugorje, to Our Lady's school.
<G-vec00316-003-s139><come_through.gehen><de> Die Bischöfe sollten die Menschen ermutigen, nach Medjugorje zu gehen, in die Schule der Muttergottes.
<G-vec00316-003-s140><come_through.gehen><en> 29 Let no evil talk come out of your mouths, but only what is useful for building up, as there is need, so that your words may give grace to those who hear.
<G-vec00316-003-s140><come_through.gehen><de> 29 Lasset kein faul Geschwätz aus eurem Munde gehen, sondern was nützlich zur Besserung ist, wo es not tut, daß es holdselig sei zu hören.
<G-vec00316-003-s141><come_through.gehen><en> It's just necessary to come to a doctor and pick up that medicine, which, according to the dose and type of hormone, will suit you.
<G-vec00316-003-s141><come_through.gehen><de> Es ist nur notwendig, zu einem Arzt zu gehen und die Medizin zu holen, die je nach Dosis und Art des Hormons zu Ihnen passt.
<G-vec00316-003-s142><come_through.gehen><en> Numerous performers, musicians, actors and entertainers come out onto the streets, and the entire city operates as a public space for the presentation of Croatian tradition.
<G-vec00316-003-s142><come_through.gehen><de> Viele Darsteller, Musiker, Performance-Künstler, Schauspieler und Unterhalter gehen auf die Straßen, während die ganze Stadt den Eindruck erweckt, ein öffentlicher Raum für die Vorstellung der kroatischen Tradition zu sein.
<G-vec00316-003-s143><come_through.gehen><en> The gift certificates of Ferienart Resort & Spa are always welcome and make small and bigger dreams come true.
<G-vec00316-003-s143><come_through.gehen><de> Die Geschenkgutscheine des Ferienart Resort & Spa sind immer willkommen und lassen kleine und größere Wünsche in Erfüllung gehen.
<G-vec00316-003-s144><come_through.gehen><en> But these privileges also come with duties.
<G-vec00316-003-s144><come_through.gehen><de> Diese Privilegien gehen jedoch mit Pflichten einher.
<G-vec00316-003-s145><come_through.gehen><en> They remind you that difficult moments and things that come to an end are signs of something beautiful and new that will soon arise.
<G-vec00316-003-s145><come_through.gehen><de> Sie erinnern daran, dass schwierige Momente und Dinge, die zu Ende gehen, Zeichen von etwas Schönem und Neuem sind, das bald auftauchen wird.
<G-vec00316-003-s146><come_through.gehen><en> Who listens to me, he has won much, because what I promise a man will indeed come true.
<G-vec00316-003-s146><come_through.gehen><de> Wer Mich anhöret, der hat viel gewonnen, denn was Ich einem Menschen verspreche, wird wahrlich in Erfüllung gehen.
<G-vec00316-003-s147><come_through.gehen><en> Thus, you will never come up empty and your apartment is always visitors fit, no matter what happens.
<G-vec00316-003-s147><come_through.gehen><de> Somit gehen Sie nie leer aus und Ihre Wohnung ist immer besuchertauglich, egal was auch passiert.
<G-vec00316-003-s148><come_through.gehen><en> Legend has it that if you want something while you ring the church bell, your wish might come true.
<G-vec00316-003-s148><come_through.gehen><de> Die Legende besagt es, wenn Sie etwas wünschen, während Sie die Kirchenglocke läuten, könnte Ihr Wunsch in Erfüllung gehen.
<G-vec00316-003-s149><come_through.gehen><en> 20 And now you will be silent and not able to speak until the day this happens, because you did not believe my words, which will come true at their appointed time.” (Luke 1:13-20)
<G-vec00316-003-s149><come_through.gehen><de> 1:20 Aber weil du meinen Worten nicht geglaubt hast, die in Erfüllung gehen, wenn die Zeit dafür da ist, sollst du stumm sein und nicht mehr reden können bis zu dem Tag, an dem all das eintrifft.
<G-vec00316-003-s150><come_through.gehen><en> They pleaded with me not to come.
<G-vec00316-003-s150><come_through.gehen><de> Sie haben auf mich eingeredet, nicht zu gehen.
<G-vec00316-003-s151><come_through.gehen><en> Because every Theum virtual expert knows about the others, users can query across them transparently and in parallel as new ones come online—without having to know where to look.
<G-vec00316-003-s151><come_through.gehen><de> Weil jeder virtuelle Experte von Theum jeden anderen „kennt“, können Anwender Abfragen über alle virtuellen Experten hinweg transparent und parallel ausführen, sobald neue virtuellen Experten online gehen – ohne deren Adresse zu kennen.
<G-vec00316-003-s285><come_through.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00316-003-s285><come_through.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00316-003-s286><come_through.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00316-003-s286><come_through.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00316-003-s287><come_through.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00316-003-s287><come_through.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00316-003-s288><come_through.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00316-003-s288><come_through.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00316-003-s289><come_through.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00316-003-s289><come_through.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00316-003-s290><come_through.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00316-003-s290><come_through.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00316-003-s291><come_through.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00316-003-s291><come_through.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00316-003-s292><come_through.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00316-003-s292><come_through.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00316-003-s293><come_through.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00316-003-s293><come_through.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00316-003-s294><come_through.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00316-003-s294><come_through.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00316-003-s295><come_through.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00316-003-s295><come_through.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00316-003-s296><come_through.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00316-003-s296><come_through.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00316-003-s297><come_through.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00316-003-s297><come_through.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00316-003-s298><come_through.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00316-003-s298><come_through.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00316-003-s299><come_through.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00316-003-s299><come_through.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00316-003-s300><come_through.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00316-003-s300><come_through.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00316-003-s301><come_through.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00316-003-s301><come_through.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00316-003-s302><come_through.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00316-003-s302><come_through.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00316-003-s303><come_through.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00316-003-s303><come_through.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00316-003-s551><come_through.stammen><en> But where does this Life come from to raise the dead?
<G-vec00316-003-s551><come_through.stammen><de> Woher stammt aber dieses Leben, das die Toten auferstehen lässt.
<G-vec00316-003-s552><come_through.stammen><en> 93.30% 97.80% The majority of visitors come from United States.
<G-vec00316-003-s552><come_through.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Deutschland, Reino Unido, Kanada, Indien & Vereinigte Staaten.
<G-vec00316-003-s553><come_through.stammen><en> Fun fact: Welsh ponies come from Wales and date back to the time of the Celts.
<G-vec00316-003-s553><come_through.stammen><de> Interessante Tatsache: Das Welsh-Pony stammt aus Wales und hat seine Ursprünge in der Zeit der Kelten.
<G-vec00316-003-s554><come_through.stammen><en> The majority of visitors come from United States, Italy, Greece, Spain, Poland & Chile.
<G-vec00316-003-s554><come_through.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Türkei, Polen, Spanien, Niederlande, Schweiz und Deutschland.
<G-vec00316-003-s555><come_through.stammen><en> Most of our clients come from the creative sector.
<G-vec00316-003-s555><come_through.stammen><de> Ein Großteil unserer KundInnen stammt aus dem Kreativbereich.
<G-vec00316-003-s556><come_through.stammen><en> The majority of visitors come from Germany, France, Indonesia, United Kingdom, Austria & Uruguay. City City Rank
<G-vec00316-003-s556><come_through.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Spanien, Deutschland, Australien, Vietnam, Reino Unido und Schweiz.
<G-vec00316-003-s557><come_through.stammen><en> Approximately half of all fossil resources now come from sources lying below the sea floor.
<G-vec00316-003-s557><come_through.stammen><de> Inzwischen stammt rund die Hälfte der fossilen Bodenschätze aus unter dem Meeresgrund liegenden Quellen.
<G-vec00316-003-s558><come_through.stammen><en> Even his Fleur de Sel does not just come from anywhere, rather he produces it himself.
<G-vec00316-003-s558><come_through.stammen><de> Auch sein Fleur de Sel stammt nicht von irgendwo, sondern aus seiner eigenen Produktion.
<G-vec00316-003-s559><come_through.stammen><en> A web analysis service collects, inter alia, data about the website from which a person has come (the so-called referrer), which sub-pages were visited, or how often and for what duration a sub-page was viewed.
<G-vec00316-003-s559><come_through.stammen><de> Ein Webanalysedienst erhebt unter anderem Daten über die Website, von der eine Person stammt (sogenannter Referrer), welche Unterseiten besucht wurden oder wie oft und für wie lange eine Unterseite aufgerufen wurde.
<G-vec00316-003-s560><come_through.stammen><en> Those who come from Eritrea and ask for asylum in Switzerland will have higher hurdles in the future.
<G-vec00316-003-s560><come_through.stammen><de> Wer aus Eritrea stammt und in der Schweiz um Asyl ersucht, hat künftig höhere Hürden.
<G-vec00316-003-s561><come_through.stammen><en> This is quite correct; but the proletariat must also recognize that the ‘national' element does not come from the oppressed and exploited masses, but from their oppressors and exploiters - the bourgeoisie.
<G-vec00316-003-s561><come_through.stammen><de> Dies ist ganz richtig, aber das Proletariat muss auch anerkennen, dass das nationale Element nicht von den unterdrückten und ausgebeuteten Massen stammt, sondern von ihren Unterdrückern und Ausbeutern - die Bourgeoisie.
<G-vec00316-003-s562><come_through.stammen><en> Many of the best grapes come from the limestone Arrábida hills high over the peninsula’s southern coast.
<G-vec00316-003-s562><come_through.stammen><de> Ein Großteil der besten Trauben stammt aus dem kalksteinhaltigen Arrábida Hügelland, das sich hoch über der südlichen Küste der Halbinsel erstreckt.
<G-vec00316-003-s563><come_through.stammen><en> Approximately one third of the members come from the fields of administration and education and approximately two thirds from the world of business, from bank institutes to medium-sized companies to global corporations.
<G-vec00316-003-s563><come_through.stammen><de> Rund ein Drittel der Mitglieder stammt aus dem Verwaltungs- und Bildungsbereich, etwa zwei Drittel aus der Wirtschaft, vom Bankinstitut über das mittelständische Unternehmen bis hin zum Weltkonzern.
<G-vec00316-003-s564><come_through.stammen><en> The basic prerequisites are that the ingredients come from the region, that production is regional, and that the products are firmly rooted in regional gastronomy.
<G-vec00316-003-s564><come_through.stammen><de> Grundvoraussetzungen sind, dass der Rohstoff aus der Region stammt, die Produktion örtlich erfolgt und die Produkte in der regionalen Gastronomie verankert sind.
<G-vec00316-003-s565><come_through.stammen><en> Authentication is a security measure implemented by NTP to ensure that the time signal that is sent comes from where it claims to come from.
<G-vec00316-003-s565><come_through.stammen><de> Die Authentifizierung ist eine Sicherheitsmaßnahme, die von NTP implementiert wird, um sicherzustellen, dass das gesendete Zeitsignal von der Stelle kommt, von der es angeblich stammt.
<G-vec00316-003-s566><come_through.stammen><en> The essential oils come from organic farming.
<G-vec00316-003-s566><come_through.stammen><de> Oliven-ätherische Öl stammt aus kontrolliert biologischem Anbau.
<G-vec00316-003-s567><come_through.stammen><en> The majority of international clients come from Venezuela, Jordan and China.
<G-vec00316-003-s567><come_through.stammen><de> Der Großteil der internationalen Kunden stammt aus Venezuela und Jordanien sowie aus China.
<G-vec00316-003-s568><come_through.stammen><en> Smartly Dressed Games is the name of the company that was created by Nelson and this probably isn’t the last title to come from them.
<G-vec00316-003-s568><come_through.stammen><de> Smartly Dressed Games ist der Name der Firma, die von Nelson gegründet wurde, und das ist wahrscheinlich nicht der letzte Titel, der von ihnen stammt.
<G-vec00316-003-s569><come_through.stammen><en> It’s name come from the work “Skufos” which namastea dating means giant cup in ancient Greek, and it is because it looks like one morphologically as it is surrounded from the higher mountain tops of Lefka Ori.
<G-vec00316-003-s569><come_through.stammen><de> Der Name stammt von “Skufos”, was auf Altgriechisch große Tasse bedeutet: und das aufgrund dessen, weil der Ort von den höheren Berggipfeln von Lefka Ori umgeben ist.
<G-vec00316-003-s570><come_through.treffen><en> In the process, people can come together who work in various forms of the care sector: professional care providers, caregivers in family and neighbour contexts, and those in self-care situations.
<G-vec00316-003-s570><come_through.treffen><de> Dabei treffen Menschen zusammen, die in verschiedener Form Arbeitende in diesem Bereich sind: Beruflich Sorgearbeitende, Sorgearbeitende in familiären und nachbarschaftlichen Zusammenhängen und in der Selbstsorge Tätige.
<G-vec00316-003-s571><come_through.treffen><en> Here you will come across a lot of young people and probably for the first time in a long time feel that there is something happening in the South Island!
<G-vec00316-003-s571><come_through.treffen><de> Hier wirst du viele junge Menschen treffen und vermutlich zum ersten Mal seit längerer Zeit das Gefühl haben, dass in Neuseeland ja doch etwas los ist.
<G-vec00316-003-s572><come_through.treffen><en> All the Syrians, as the UN Security Council resolution says, must sit down and come to an agreement.
<G-vec00316-003-s572><come_through.treffen><de> Alle Syrer sollten in Übereinstimmung mit der Resolution des UN-Sicherheitsrats am Verhandlungstisch zusammenkommen und eine Vereinbarung treffen.
<G-vec00316-003-s573><come_through.treffen><en> The prophet Isaiah brings to view the fearful deception which will come upon the wicked, causing them to count themselves secure from the judgments of God: "We have made a covenant with death, and with hell are we at agreement. When the overflowing scourge shall pass through, it shall not come unto (378) us; for we have made lies our refuge, and under falsehood have we hid ourselves." Isa.
<G-vec00316-003-s573><come_through.treffen><de> Der Prophet Jesaja weist auf die furchtbare Täuschung hin, welche über die Gottlosen kommen wird, so daß sie sich vor den Gerichten Gottes sicher fühlen: „Wir haben mit dem Tode einen Bund und mit der Hölle einen Vertrag gemacht; wenn eine Flut dahergeht, wird sie uns nicht treffen; denn wir haben die Lüge zu unserer Zuflucht und Heuchelei zu unserem Schirm gemacht.“ (Jes.
<G-vec00316-003-s574><come_through.treffen><en> Things often come to me with time, so a day later I sat on the beach and cried.
<G-vec00316-003-s574><come_through.treffen><de> Einen Tag später – manchmal treffen mich Dinge mit Zeitverzögerung – habe ich dann am Strand gesessen und geweint.
<G-vec00316-003-s575><come_through.treffen><en> If you cannot manage to come from Sunday to Sunday, try and come from Thursday or Friday evening until Sunday.
<G-vec00316-003-s575><come_through.treffen><de> Wer nicht von Sonntag bis Sonntag an den Treffen teilnehmen kann, sollte am Donnerstag- oder spätestens Freitagabend ankommen und bis Sonntag bleiben.
<G-vec00316-003-s576><come_through.treffen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00316-003-s576><come_through.treffen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00316-003-s577><come_through.treffen><en> As in the best tradition, the workshop is the natural place in which craftsmanship and design come together, inextricably linking production and design.
<G-vec00316-003-s577><come_through.treffen><de> Wie in der besten Tradition ist die Werkstatt der Ort, an dem sich Handwerk und Design treffen und dabei Produktion und Planung unlösbar miteinander verbinden.
<G-vec00316-003-s578><come_through.treffen><en> Numerous national and international representatives from business and politics will come together for this first-class event in order to discuss the most current topics.
<G-vec00316-003-s578><come_through.treffen><de> Anlässlich des hochkarätigen Anlasses treffen sich zahlreiche nationale und internationale Vertreter aus Wirtschaft und Politik in Vaduz, um topaktuelle Themen zu diskutieren.
<G-vec00316-003-s579><come_through.treffen><en> Then we pass through the gates of Heaven and come across the proud people who humbly pray the Pater Noster.
<G-vec00316-003-s579><come_through.treffen><de> Dann werden wir durch die Pforte des Himmels gehen und treffen die Stolzen die demütig das Pater Noster beten.
<G-vec00316-003-s580><come_through.treffen><en> Digitalisation and sustainability – two key “mega trends” come together.
<G-vec00316-003-s580><come_through.treffen><de> Digitalisierung und Nachhaltigkeit – hier treffen zwei Megatrends aufeinander.
<G-vec00316-003-s581><come_through.treffen><en> Schedule of events You can come and get to know the JBL team personally at the following events in April 2018.
<G-vec00316-003-s581><come_through.treffen><de> Auf folgenden Veranstaltungen können Sie uns im Juni 2018 treffen und das JBL Team persönlich kennenlernen.
<G-vec00316-003-s582><come_through.treffen><en> Wherever you go, you will come across open-minded people who will be happy to speak English with you.
<G-vec00316-003-s582><come_through.treffen><de> Überall werden Sie auf aufgeschlossene Menschen treffen, die gerne mit Ihnen Englisch plaudern.
<G-vec00316-003-s583><come_through.treffen><en> If these high-stakes talks come to pass, they would be the first between a sitting US president and a North Korean leader.
<G-vec00316-003-s583><come_through.treffen><de> Eine Reise des nordkoreanischen Außenministers nach Schweden nährt nun Spekulationen über den Austragungsort für dieses erste Treffen zwischen einem amtierenden US-Präsidenten und einem nordkoreanischen Machthaber.
<G-vec00316-003-s584><come_through.treffen><en> Because particular bodily organs correspond to every point, it is possible to come to the conclusion about state of this organs.
<G-vec00316-003-s584><come_through.treffen><de> Weil es jedem Punkt bestimmte Körperorgane entsprechen, ist auf Grund des gemessenen Widerstandes den Beschluss über den Stand dieser Organe zu treffen.
<G-vec00316-003-s585><come_through.treffen><en> Graduates of the Master of Science in International Cooperation in Urban Development come upon a broad field of work which has a strong demand for professionals in international projects about urban development.
<G-vec00316-003-s585><come_through.treffen><de> Absolventen und Absolventinnen des Master of Science International Cooperation in Urban Development treffen auf ein weites Arbeitsfeld mit einer starken Nachfrage nach Fachkräften für internationale Projekte im Bereich der Stadtentwicklung.
<G-vec00316-003-s586><come_through.treffen><en> Divers, snorkelers and musicians dressed in whimsical nautical costumes come together every year in Florida for the Underwater Music Festival.
<G-vec00316-003-s586><come_through.treffen><de> Taucher, Schnorchler und Musiker treffen sich Jahr für Jahr in Florida für das Unterwasser-Musik-Festival.
<G-vec00316-003-s587><come_through.treffen><en> The event aims to create a space in which different voices come together to start dialogue and find solutions and answers to the social, emotional and health problems that women face in today's society. The Forum is an open event, free of charge, with an open debate on women's issues.
<G-vec00316-003-s587><come_through.treffen><de> Mit diesem Forum will versucht werden ein Raum zu schaffen, in welchem sich verschiedene Stimmen treffen, unterschiedliche Meinungen ausgetauscht werden um so einen Dialog anzuregen und Lösungen und Antworten auf die soziale, emotionale und gesundheitliche Problematik zu finden, mit welcher sich die Frau tagtäglich in der Gesellschaft konfrontiert sieht.
<G-vec00316-003-s588><come_through.treffen><en> In the living room, family and friends come together for mutual hours.
<G-vec00316-003-s588><come_through.treffen><de> Im Wohnzimmer treffen sich Familie und Freunde für gemeinsame Stunden.
<G-vec00316-003-s589><come_through.treten><en> Also the cooperation with students regarding bachelor’s and master’s theses as well as compulsory internships, new findings come to light that are included in further product development.
<G-vec00316-003-s589><come_through.treten><de> Auch bei der Zusammenarbeit mit Studierenden in Hinblick auf Bachelor- und Masterarbeiten sowie Pflichtpraktika treten regelmäßig neue Erkenntnisse zu Tage, die in die weitere Produktentwicklung miteinfließen.
<G-vec00316-003-s590><come_through.treten><en> Lung cancer typically develops slowly and symptoms often come on gradually.
<G-vec00316-003-s590><come_through.treten><de> Lungenkrebs entwickelt sich gewöhnlich langsam und die Symptome treten oft schrittweise auf.
<G-vec00316-003-s591><come_through.treten><en> They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.
<G-vec00316-003-s591><come_through.treten><de> Und sie sollen hineingehen in mein Heiligtum und vor meinen Tisch treten, mir zu dienen und meine Sitten zu halten.
<G-vec00316-003-s592><come_through.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which lie outside the area of responsibility of the author, a liability obligation would come into force only in the case in which the contents are aware and technically possible and reasonable, the Use in case of illegal content.
<G-vec00316-003-s592><come_through.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00316-003-s593><come_through.treten><en> In the case of direct or indirect references to third-party websites ("hyperlinks"), which are outside the responsibility of the author, a liability obligation would only come into force in the case in which the author is aware of the contents and is technically possible and reasonable, To prevent the use in the case of unlawful content.
<G-vec00316-003-s593><come_through.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten (“Hyperlinks”), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00316-003-s594><come_through.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which are beyond the scope of responsibility of Ryf Sports, a liability obligation would only come into effect in the case in which Ryf Sports is aware of the content and it technically possible and reasonable to prevent the use of illegal content.
<G-vec00316-003-s594><come_through.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches von Ryf Sports liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem Ryf Sports von den Inhalten Kenntnis hat und es technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00316-003-s595><come_through.treten><en> emmerich exclusivbrillen GmbH & Co. reserves the right to amend the conditions of the present agreement in part or in full at any time and any such amendments come into force immediately following their publication on the website.
<G-vec00316-003-s595><come_through.treten><de> emmerich exclusivbrillen GmbH & Co.KG behält sich das Recht vor, die Bestimmungen dieses Vertrages jederzeit, ganz oder teilweise abzuändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Webseite in Kraft.
<G-vec00316-003-s596><come_through.treten><en> The resolutions passed at the Extraordinary General Meeting of Kaba will come into effect upon completion of the merger.
<G-vec00316-003-s596><come_through.treten><de> Die Beschlüsse der außerordentlichen Generalversammlung von Kaba treten mit dem Vollzug des Zusammenschlusses in Kraft.
<G-vec00316-003-s597><come_through.treten><en> Any provision of the Contract that expressly or by implication is intended to come into or continue in force on or after termination shall remain in full force and effect.
<G-vec00316-003-s597><come_through.treten><de> 8.6 Jedwede Bestimmung des Vertrags, die ausdrücklich oder stillschweigend in Kraft treten oder bei oder nach Kündigung in Kraft bleiben soll, bleibt in Kraft.
<G-vec00316-003-s600><come_through.treten><en> If amendments are merely insignificant, they shall come into force immediately.
<G-vec00316-003-s600><come_through.treten><de> Sollte es sich lediglich um unwesentliche Änderungen handeln, treten diese umgehend in Kraft.
<G-vec00316-003-s601><come_through.treten><en> Everybody shall come in touch with their own greatness, their own divinity.
<G-vec00316-003-s601><come_through.treten><de> Jeder soll vielmehr mit seiner eigenen Größe, seiner eigenen Göttlichkeit in Verbindung treten.
<G-vec00316-003-s602><come_through.treten><en> All direct or indirect references to other Internet sites (links), which lie outside the area of responsibility of the author, any liability obligation would only come into effect if the author is aware of the contents, and it would be technically possible and reasonable for him to prevent the use in the event of illegal contents.
<G-vec00316-003-s602><come_through.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00316-003-s603><come_through.treten><en> Straight line projection of the zone upwards indicates that it will come to surface (likely under till cover) very near the north boundary of the Burns Block.
<G-vec00316-003-s603><come_through.treten><de> Die geradlinige Weiterführung der Zone nach oben weist darauf hin, dass sie sehr nahe an der nördlichen Grenze des Burns Blocks zu Tage treten wird (wahrscheinlich unterhalb einer Geschiebemergelschicht).
<G-vec00316-003-s604><come_through.treten><en> The changed terms and conditions come in the place of the previous version of the General Terms and Conditions.
<G-vec00316-003-s604><come_through.treten><de> Die geänderten Bedingungen treten an die Stelle der vorhergehenden allgemeinen Geschäftsbedingungen.
<G-vec00316-003-s605><come_through.treten><en> In the case of direct or indirect references to external websites („links“), which are outside the responsibility of the website operator, a liability obligation would only come into force in the case where the website operator is aware of the contents and it is technically possible for him And it would be reasonable to prevent the use of illegal contents.
<G-vec00316-003-s605><come_through.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00316-003-s607><come_through.treten><en> The new prices will come into force from the announcement of the regulation. The cost of transport and other expenses are calculated separately.
<G-vec00316-003-s607><come_through.treten><de> Die neuen Preise treten mit der Bekanntgabe der Verordnung in Kraft, die Kosten für Transport und Sonstiges werden gesondert berechnet.
<G-vec00316-003-s627><come_through.verfügen><en> The rooms, suites and apartments at Garni Anni come with a balcony with mountain views and a bathroom with shower or bath.
<G-vec00316-003-s627><come_through.verfügen><de> Die Zimmer, Suiten und Apartments im Garni Anni verfügen über einen Balkon mit Bergblick und ein Badezimmer mit einer Dusche oder Badewanne.
<G-vec00316-003-s628><come_through.verfügen><en> All of our products come with a 100 percent guarantee of customer satisfaction.
<G-vec00316-003-s628><come_through.verfügen><de> Alle unsere Produkte verfügen über eine 100-prozentige Garantie der Zufriedenheit unserer Kunden.
<G-vec00316-003-s629><come_through.verfügen><en> Rooms come with flat-screen TVs and tea/coffee making facilities.
<G-vec00316-003-s629><come_through.verfügen><de> Die Zimmer verfügen über einen Flachbild-TV sowie Tee- und Kaffeezubehör.
<G-vec00316-003-s630><come_through.verfügen><en> The welcoming rooms come with a bathroom with a hairdryer, a direct dial telephone, a hire safe and a minibar.
<G-vec00316-003-s630><come_through.verfügen><de> Die freundlich eingerichteten Zimmer verfügen über Bad/WC, Haartrockner, Minibar, Mietsafe und Direktwahltelefon.
<G-vec00316-003-s631><come_through.verfügen><en> Rooms at Sheraton Sopot come with air conditioning and a flat-screen satellite TV.
<G-vec00316-003-s631><come_through.verfügen><de> Die Zimmer im Sheraton Colonia Golf And Spa Resort verfügen über eine Minibar, einen TV und ein eigenes Bad.
<G-vec00316-003-s632><come_through.verfügen><en> All these pickups come with 25K pots, stereo jack, battery clip and other mounting hardware.
<G-vec00316-003-s632><come_through.verfügen><de> Alle AHB-1 Tonabnehmer verfügen über 25K Töpfe, Klinkenstecker, Batterie-Clip und andere Montage-Hardware.
<G-vec00316-003-s633><come_through.verfügen><en> Divná pani Luxury Gallery Rooms provides certain rooms with garden views, and all rooms come with a private bathroom.
<G-vec00316-003-s633><come_through.verfügen><de> Das Divná pani Luxury Gallery Rooms bietet Zimmer mit Gartenblick und alle Zimmer verfügen über ein eigenes Bad.
<G-vec00316-003-s634><come_through.verfügen><en> All units come with a terrace, a kitchenette with a fridge, and a private bathroom with bath or shower.
<G-vec00316-003-s634><come_through.verfügen><de> Die modernen Zimmer verfügen über Holzböden, Kabel/Sat-TV, einen Wasserkocher sowie ein eigenes Bad mit einer Warmwasserdusche.
<G-vec00316-003-s635><come_through.verfügen><en> They come with a microwave, an electric kettle and a fridge as well as bathrooms with a shower, a spa bathtub and dressing gowns.
<G-vec00316-003-s635><come_through.verfügen><de> Sie verfügen über eine Mikrowelle, einen Wasserkocher und eine Kaffee-/Teemaschine sowie über private Badezimmer mit einer Dusche, einem Jacuzzi und kostenlosen Pflegeprodukten.
<G-vec00316-003-s636><come_through.verfügen><en> The rooms come with a private or shared bathroom.
<G-vec00316-003-s636><come_through.verfügen><de> Alle Zimmer verfügen über ein eigenes Bad oder bieten Zugang zu einem Gemeinschaftsbad.
<G-vec00316-003-s637><come_through.verfügen><en> Thus they are virtually maintenance-free, very rarely prone to malfunctions, require no lubricants, may be positioned exactly, have a constant stroke speed, and come with a mechanical self-locking mechanism.
<G-vec00316-003-s637><come_through.verfügen><de> So sind sie nahezu wartungsfrei, wenig fehleranfällig, schmiermittelfrei, exakt positionierbar und verfügen über eine konstante Hubgeschwindigkeit sowie über eine mechanische Selbsthemmung.
<G-vec00316-003-s638><come_through.verfügen><en> All units come with a patio, a kitchen with an oven and a microwave, and a private bathroom with bidet.
<G-vec00316-003-s638><come_through.verfügen><de> Alle Unterkünfte verfügen über eine Terrasse, eine Küche mit einem Backofen und einer Mikrowelle sowie ein eigenes Bad mit einem Bidet.
<G-vec00316-003-s639><come_through.verfügen><en> Bathrooms come with a shower, complimentary toiletries and towels.
<G-vec00316-003-s639><come_through.verfügen><de> Badezimmer verfügen über eine Dusche, einen Fön und Handtücher.
<G-vec00316-003-s640><come_through.verfügen><en> All rooms at the Cinco Calderas come with en suite bathroom complete with amenities.
<G-vec00316-003-s640><come_through.verfügen><de> Alle Zimmer im Cinco Calderas verfügen über ein eigenes Bad mit Pflegeprodukten.
<G-vec00316-003-s641><come_through.verfügen><en> rooms at the Linne come with satellite TV, tea/coffee facilities and a private bathroom with a shower.
<G-vec00316-003-s641><come_through.verfügen><de> Die hellen Zimmer im Linne verfügen über Sat-TV, Kaffee- und Teezubehör sowie ein eigenes Bad mit einer Dusche.
<G-vec00316-003-s642><come_through.verfügen><en> Featuring a balcony with outdoor furniture, the bright apartments come with tiled floors and a kitchenette.
<G-vec00316-003-s642><come_through.verfügen><de> Die hellen Apartments verfügen über einen Balkon mit Gartenmöbeln sowie Fliesenböden und eine Küchenzeile.
<G-vec00316-003-s643><come_through.verfügen><en> All wooden furnished, rooms here come with Satellite television, a fan, and a desk.
<G-vec00316-003-s643><come_through.verfügen><de> Alle mit Holz eingerichteten Zimmer verfügen über Sat-TV, einen Ventilator und einen Schreibtisch.
<G-vec00316-003-s644><come_through.verfügen><en> The non-smoking apartments and studios at the Cathedral all come with a private bathroom with a shower or a bathtub, a fully equipped kitchenette, and a satellite TV.
<G-vec00316-003-s644><come_through.verfügen><de> Die rauchfreien Apartments und Studios im Cathedral verfügen alle über ein eigenes Bad mit einer Dusche oder einer Badewanne, eine komplett ausgestattete Küchenzeile und Sat-TV.
<G-vec00316-003-s645><come_through.verfügen><en> Newer DVD players often come with a high definition upconversion feature as well.
<G-vec00316-003-s645><come_through.verfügen><de> Neuere DVD-Player verfügen häufig auch über eine Funktion zur Konvertierung in High Definition.
<G-vec00491-002-s190><come_through.geben><en> Surf boots come in different thicknesses such as 0.5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm or even 7 mm thick.
<G-vec00491-002-s190><come_through.geben><de> Surfschuhe gibt es in verschiedenen Stärken wie 0,5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm oder sogar 7 mm.
<G-vec00491-002-s191><come_through.geben><en> Chatbots come in different shapes and forms.
<G-vec00491-002-s191><come_through.geben><de> Chatbots gibt es in verschiedenen Formen und Arten.
<G-vec00491-002-s192><come_through.geben><en> Beacons come in all kinds of different formats, are scalable and highly portable. Benefits:
<G-vec00491-002-s192><come_through.geben><de> Beacons gibt es in den unterschiedlichsten Formen, sie sind skalierbar und sehr portabel.
<G-vec00491-002-s193><come_through.geben><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Wiko Sunny You'll never have to buy another screen protector for the life of your phone with the Olixar 2-in-1 screen protector pack
<G-vec00491-002-s193><come_through.geben><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Galaxy A5 2017 haben.
<G-vec00491-002-s194><come_through.geben><en> The Nucleus 6 sound processors come in a variety of colours designed to blend in with hair and skin tones.
<G-vec00491-002-s194><come_through.geben><de> Den Nucleus 6 Soundprozessor gibt es in verschiedenen Farbtönen, die zu Haut- und Haarfarben passen.
<G-vec00491-002-s195><come_through.geben><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Huawei P8 Lite.
<G-vec00491-002-s195><come_through.geben><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Gear S3 Smartwatch haben.
<G-vec00491-002-s196><come_through.geben><en> PCs come in all shapes and sizes, and the exact same tweaks might have different effects on different PC setups.
<G-vec00491-002-s196><come_through.geben><de> PCs gibt es in allen Farben und Formen, und exakt gleiche Anpassungen können verschiedene Auswirkungen auf verschiedenen PCs haben.
<G-vec00491-002-s197><come_through.geben><en> These garments come in a wide variety of styles: Tops which create a wasp waist under A-line dresses, high-waisted panties which optimally slim the stomach, upper thighs and bottom for skinny trousers, and undergarments which form a slim silhouette from chest to knee under tight-fitting knitted dresses.
<G-vec00491-002-s197><come_through.geben><de> Die Formwäsche gibt es in den unterschiedlichsten Varianten: Tops, die eine Wespentaille unter A-Linien-Kleider zaubern, Highwaist-Panties, die Bauch, Oberschenkel und Po optimal für Skinny Hosen schmälern, und Unterkleider, die von Brust bis Knie eine schlanke Silhouette unter anliegenden Strickkleidern formen.
<G-vec00491-002-s198><come_through.geben><en> Progressive Slots come in all shapes and sizes in the world of Online Gambling.
<G-vec00491-002-s198><come_through.geben><de> Progressive Slots Gibt es in allen Formen und Größen in der Welt der Online-Glücksspiel.
<G-vec00491-002-s199><come_through.geben><en> Cap constructions come in many shapes and sizes.
<G-vec00491-002-s199><come_through.geben><de> Diese Kappenkonstruktionen gibt es in vielen Formen und Größen.
<G-vec00491-002-s200><come_through.geben><en> Short-term trades come in three varieties, the typical 60 second options and the newest addition called the 2 and 5-minute expiries.
<G-vec00491-002-s200><come_through.geben><de> Kurzfristige Trades gibt es in drei Sorten, die typischen 60 Sekunden Optionen und die neueste Ergänzung genannt die 2 und 5-Minuten-Abläufe.
<G-vec00491-002-s201><come_through.geben><en> Lens filters generally come in two varieties: screw-on and front filters.
<G-vec00491-002-s201><come_through.geben><de> In der Regel gibt es Linsenfilter in zwei Varianten: Anschraub- und Frontfilter.
<G-vec00491-002-s202><come_through.geben><en> Nacho trays come in black / large with 2 cups for nachos...
<G-vec00491-002-s202><come_through.geben><de> Nachoschalen gibt es in der Ausführung schwarz / groß mit...
<G-vec00491-002-s203><come_through.geben><en> Coins come in 50 øre as well as 1, 2, 5, 10 and 20 Kroner.
<G-vec00491-002-s203><come_through.geben><de> Münzen gibt es in 50 Öre sowie 1, 2, 5, 10 und 20 Kronen.
<G-vec00491-002-s204><come_through.geben><en> All three series come with matching leggings, which are not a only a sexy accessory for the beach, but also the perfect garment for any type of beach activity – from beach volleyball to yoga workouts.
<G-vec00491-002-s204><come_through.geben><de> Zu allen drei Serien gibt es die passende Hose im Leggins-Style, die nicht nur ein sexy Strand-Accessoire ist, sondern auch der ideale Begleiter für jede Form von Strandaktivität – von Beachvolleyball bis zum Yoga-Workout.
<G-vec00491-002-s205><come_through.geben><en> Themes come in many different shapes, from blank themes with only the bare necessities, to more advanced themes with tons of features.
<G-vec00491-002-s205><come_through.geben><de> Themes gibt es in vielen verschiedenen Formen, von leeren Themes mit nur dem Nötigsten bis hin zu fortgeschritteneren Themes mit unzähligen Funktionen.
<G-vec00491-002-s206><come_through.geben><en> Heart rate monitors come in a variety of different models, with varying levels of functionality.
<G-vec00491-002-s206><come_through.geben><de> Herzfrequenzmesser gibt es in verschiedenen Modellen mit unterschiedlichen Funktionen.
<G-vec00491-002-s208><come_through.geben><en> Hotels in Germany come in all price ranges and equipments.
<G-vec00491-002-s208><come_through.geben><de> Hotels in Deutschland gibt es in allen Preisklassen und Ausstattungen.
<G-vec00491-002-s171><come_through.gelangen><en> The customer hereby grants the Bank a lien on valuables of any kind which, in the course of banking business, may come into the possession or power of disposition of the Bank through acts of the customer or of third parties for account of the customer.
<G-vec00491-002-s171><come_through.gelangen><de> Der Kunde räumt hiermit der BayernLB ein Pfandrecht ein an Werten jeder Art, die im bankmäßigen Geschäftsverkehr durch den Kunden oder durch Dritte für seine Rechnung in ihren Besitz oder ihre sonstige Verfügungsmacht gelangen.
<G-vec00491-002-s172><come_through.gelangen><en> And we need to make the bridge between the results of research on one hand and the potential investors on the other, for innovation to come out of the lab and onto the market.
<G-vec00491-002-s172><come_through.gelangen><de> Und wir müssen Brücken bauen zwischen den Forschungsergebnissen einerseits und potentiellen Investoren andererseits, damit die Innovation vom Labor auf den Markt gelangen kann.
<G-vec00491-002-s173><come_through.gelangen><en> 9 If they say thus to us, Stand still until we come to you, then we will stay in our place, and will not go up to them.
<G-vec00491-002-s173><come_through.gelangen><de> 9 Wenn sie dann zu uns sagen: «Steht stille, bis wir zu euch gelangen!» so wollen wir an unserm Ort stehenbleiben und nicht zu ihnen hinaufsteigen.
<G-vec00491-002-s174><come_through.gelangen><en> The parties will subsequently consult and try to come to an agreement.
<G-vec00491-002-s174><come_through.gelangen><de> Die Parteien werden sich daraufhin beraten und versuchen, zu einer Einigung zu gelangen.
<G-vec00491-002-s175><come_through.gelangen><en> After around 30 minutes, you will come to the clearing with the Ellmau Stone Circle.
<G-vec00491-002-s175><come_through.gelangen><de> Nach circa 30 Minuten gelangen Sie an die Lichtung mit dem Ellmauer Steinkreis.
<G-vec00491-002-s176><come_through.gelangen><en> You will look for me; and as I said to the Jews so now I say to you, “Where I am going, you cannot come.”
<G-vec00491-002-s176><come_through.gelangen><de> Ihr werdet mich suchen, und was ich den Juden gesagt habe, sage ich jetzt auch euch: Wohin ich gehe, dorthin könnt ihr nicht gelangen.
<G-vec00491-002-s177><come_through.gelangen><en> If you come to our website via a Google advert, Google AdWords will place a cookie on your device ("conversion cookie").
<G-vec00491-002-s177><come_through.gelangen><de> Wenn Sie über eine Googleanzeige auf unsere Webseite gelangen, setzt Google Adwords einen Cookie auf Ihrem Gerät („Conversion Cookie“).
<G-vec00491-002-s178><come_through.gelangen><en> The works resulting from this experience address our frequently ambiguous attitude to what is foreign to us: whereas “exotic” luxury items and food such as tropical fruit are regarded as positive and precious, people who come to us as refugees from the same countries are often rejected as being “foreign,” and their “exotic” nature is sometimes even perceived as a threat.
<G-vec00491-002-s178><come_through.gelangen><de> Die in der Folge entstandene Arbeiten thematisieren unser oft zwiespältiges Verhältnis zum Fremden: so wird das ‚Exotische‘ in Form von Luxusgütern und Essen, etwa den geschätzten Südfrüchten, als positiv und begehrenswert empfunden, während Menschen, die aus denselben Regionen der Erde als Geflüchtete zu uns gelangen, aufgrund ihrer ‚Fremdheit‘ Ablehnung erfahren, oder das ‚Exotische‘ gar als Bedrohung empfunden wird.
<G-vec00491-002-s179><come_through.gelangen><en> Over the past weeks, frequent interactions took place to come to a common understanding on the way forward for a long-term, strategic ESA–EU partnership, building on the successes so far: Galileo and EGNOS already provide world-class navigation services and Copernicus is the most complete Earth observation system in the world.
<G-vec00491-002-s179><come_through.gelangen><de> In den letzten Wochen haben zahlreiche Gespräche stattgefunden, um zu einem gemeinsamen Verständnis über das weitere Vorgehen im Hinblick auf eine langfristige strategische Partnerschaft zwischen der ESA und der EU zu gelangen, die auf den bisherigen Erfolgen aufbaut: Galileo und EGNOS bieten bereits Navigationsdienste der Spitzenklasse, und Copernicus ist das umfassendste Erdbeobachtungssystem der Welt.
<G-vec00491-002-s180><come_through.gelangen><en> Let the inner joy within you come to the surface.
<G-vec00491-002-s180><come_through.gelangen><de> Lasst die innere Freude inwendig in euch an die Oberfläche gelangen.
<G-vec00491-002-s181><come_through.gelangen><en> In a further advantageous embodiment of the invention, an impermeable immersion liquid protective layer is at least one surface of the terminating element, which can come into contact with immersion liquid, is applied.
<G-vec00491-002-s181><come_through.gelangen><de> Bei einer weiteren vorteilhaften Ausgestaltung der Erfindung ist auf wenigstens eine Oberfläche des Abschlußelements, die mit Immersionsflüssigkeit in Berührung gelangen kann, eine für Immersionsflüssigkeit undurchlässige Schutzschicht aufgebracht.
<G-vec00491-002-s182><come_through.gelangen><en> “Through your prayer, night and day, you bring before God the lives of so many of our brothers and sisters who for various reasons cannot come to him to experience his healing mercy, even as he patiently waits for them.
<G-vec00491-002-s182><come_through.gelangen><de> Durch euer Gebet tragt ihr Tag und Nacht das Leben vieler Brüder und Schwestern vor den Herrn, die aus verschiedenen Gründen nicht zu ihm gelangen und die Erfahrung seiner heilenden Barmherzigkeit machen können, während er sie erwartet, um ihnen Gnade zu erweisen.
<G-vec00491-002-s183><come_through.gelangen><en> See what we come to.
<G-vec00491-002-s183><come_through.gelangen><de> Seht, wozu wir gelangen.
<G-vec00491-002-s184><come_through.gelangen><en> This affects your health and energy (apart from the fact that plastic residues come into your food).
<G-vec00491-002-s184><come_through.gelangen><de> Dies ist negativ für Ihre Gesundheit und Energie (neben der Tatsache, dass Plastikreste ins Essen gelangen).
<G-vec00491-002-s185><come_through.gelangen><en> In Stage 2 of the Product Backlog, Items come exclusively from Stage 3.
<G-vec00491-002-s185><come_through.gelangen><de> In die Stufe 2 des Product Backlogs gelangen Items ausschließlich aus der Stufe 3.
<G-vec00491-002-s186><come_through.gelangen><en> From here, the path follows the stream bank and a little further on we come to the narrow part of the stream, where the gorge virtually begins.
<G-vec00491-002-s186><come_through.gelangen><de> Von hier aus folgt der Pfad dem Flussufer und ein bisschen weiter gelangen wir zur Enge des Flusslaufes, an der die Schlucht eigentlich beginnt.
<G-vec00491-002-s187><come_through.gelangen><en> With the help of this Upper Force, the world can come to the correct condition.
<G-vec00491-002-s187><come_through.gelangen><de> Mit Hilfe dieser Höheren Kraft kann die Welt zum richtigen Zustand gelangen.
<G-vec00491-002-s188><come_through.gelangen><en> We use the information to compile reports and to help us improve the website. The cookies collect information in an anonymous form, including the number of visitors to the websites, where visitors have come to the website from and the pages they visited.
<G-vec00491-002-s188><come_through.gelangen><de> Wir verwenden diese Daten, um Berichte zu erstellen und unsere Website zu verbessern Die Cookies erfassen Daten anonymisiert; es wird beispielsweise die Anzahl der Website-Besucher registriert, von wo aus Besucher auf die Websites gelangen sowie die Seiten, die sie besuchen.
<G-vec00491-002-s189><come_through.gelangen><en> Going past St. Johann im Pongau you will finally come to the region of Zell am See-Kaprun and to the Seehotel Bellevue, which is located in Thumersbach on the eastern lakeshore.
<G-vec00491-002-s189><come_through.gelangen><de> Über St. Johann im Pongau gelangen Sie schließlich in die Region Zell am See-Kaprun und zum Seehotel Bellevue, welches sich bei Thumersbach am östlichen Ufer des Zeller Sees befindet.
<G-vec00491-002-s209><come_through.haben><en> The girl's shorts come with a textile side stripe and ensure freedom of movement thanks to the supple viscose material - perfect companions for the next summer!
<G-vec00491-002-s209><come_through.haben><de> Die Mädchen Shorts haben seitlich einen farblich passenden Besatz und machen aufgrund der angenehmen Viskose-Qualität jede Bewegung mit – ein toller Begleiter für den nächsten Sommer.
<G-vec00491-002-s210><come_through.haben><en> They come with a black leather upper and a removable insole for hygiene and practicality.
<G-vec00491-002-s210><come_through.haben><de> Sie haben ein Obermaterial aus schwarzem Leder und eine hygienische und praktische herausnehmbare sohle.
<G-vec00491-002-s211><come_through.haben><en> Come and find our new presentation of the wonderful smelling incense sticks from Paris in our store in the Belgian quarter in Cologne.
<G-vec00491-002-s211><come_through.haben><de> Wir haben Parfums, Keramik, Räucherstäbchen, Duftkerzen und Papeterie bei uns im Store in Köln.
<G-vec00491-002-s212><come_through.haben><en> Passengers really do come first here! Travel in the VIP seats above the driver's cab on the GoldenPass SuperPanoramic train from Montreux to Zweisimmen, and you'll feel like you are flying!
<G-vec00491-002-s212><come_through.haben><de> Hier haben Passagiere die Nase vorn: Wer im GoldenPass SuperPanoramic von Montreux nach Zweisimmen die VIP-Plätze bucht, hat das Gefühl zu fliegen, denn sie befinden sich hoch über dem Führerstand ganz vorne im Zug.
<G-vec00491-002-s213><come_through.haben><en> © direktbroker-FX, Alle wing: CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage.
<G-vec00491-002-s213><come_through.haben><de> Adresse: direktbroker.de AG, Risikohinweis: CFDs sind komplexe Instrumente und haben ein hohes Risiko, durch Hebelwirkung schnell Geld zu verlieren.
<G-vec00491-002-s214><come_through.haben><en> It is not clear why the ESM or this debt repayment fund should come up with any different results – they are in effect the same.
<G-vec00491-002-s214><come_through.haben><de> Es ist nicht ersichtlich, warum ESM und dieser Schuldentilgungsfonds verschiedene Ergebnisse haben sollten – sie entsprechen einander.
<G-vec00491-002-s215><come_through.haben><en> And because Mac, iPhone, iPad and iPod touch all come equipped with FaceTime, you can talk to iOS and macOS users across the street or across the globe.
<G-vec00491-002-s215><come_through.haben><de> Und weil Mac, iPhone, iPad und iPod touch alle FaceTime haben, kannst du überall mit Benutzern von iOS und macOS sprechen.
<G-vec00491-002-s216><come_through.haben><en> The bathrooms come with a bathtub, a shower and free toiletries for more comfort.
<G-vec00491-002-s216><come_through.haben><de> Die Badezimmer haben eine Badewanne, eine Dusche und kostenlose Pflegeprodukte für mehr Komfort.
<G-vec00491-002-s217><come_through.haben><en> Some hotel rooms come with a wonderful view over the city.
<G-vec00491-002-s217><come_through.haben><de> Gäste haben die Möglichkeit, einen wunderbaren Blick auf den Hafen zu bewundern.
<G-vec00491-002-s218><come_through.haben><en> The expensive models come with a built-in sensor that lets the drone steer clear of large and small objects.
<G-vec00491-002-s218><come_through.haben><de> De kostspieligeren Modelle haben einen eingebauten Sensor, der die Drohnen um große Gegenstände herum steuern lässt.
<G-vec00491-002-s219><come_through.haben><en> The luxury rooms are 40 m², and all come with balconies and terraces with a pool, sea or garden view.
<G-vec00491-002-s219><come_through.haben><de> Die Luxuszimmer sind 40 qm groß und haben Balkon oder Terrasse mit Ausblick auf den Pool, das Meer oder den Garten.
<G-vec00491-002-s220><come_through.haben><en> Most units come with a balcony.
<G-vec00491-002-s220><come_through.haben><de> Die meisten Unterkünfte haben einen Balkon.
<G-vec00491-002-s221><come_through.haben><en> The truth is, I think, that Patrick wants to put a girl in his park who looks like the girls in his magazine, which only proves once again his remote controlled nature, and there’s more to come, because Patrick wants a girl to make him come who is sexually competent but has never had sex and this, I think, is where Patrick’s remote-controlled nature reaches its limitlessly stupid climax.
<G-vec00491-002-s221><come_through.haben><de> Tatsächlich, denke ich weiter, will Patrick sich ein Mädchen in sein Gehege stellen, das so aussieht wie die Mädchen aus seinem Magazin, was sein Ferngesteuertsein einmal mehr auf den Punkt bringt und es erreicht noch seinen unglaublichen Höhepunkt, denn seinen Höhepunkt, denke ich, will Patrick von einem Mädchen verschafft haben, das sexuell kompetent ist, aber noch nie Sex hatte und an dieser Stelle, denke ich, erreicht Patricks Ferngesteuertsein in seiner ganzen unbegrenzten Dummheit seinen Höhepunkt.
<G-vec00491-002-s222><come_through.haben><en> The right images on the web may come with copyright restrictions.
<G-vec00491-002-s222><come_through.haben><de> Die richtigen Bilder im Web haben möglicherweise Copyright Beschränkungen.
<G-vec00491-002-s223><come_through.haben><en> Both of them come with a Full HD display, but only the HP comes with a contrast-rich IPS panel with wide viewing angles.
<G-vec00491-002-s223><come_through.haben><de> Beide haben eine Full-HD-Anzeige, doch nur HP setzt auf ein blickwinkelstabiles und kontraststarkes IPS-Panel.
<G-vec00491-002-s224><come_through.haben><en> There is a statement in the "Remarks" to the effect that society is not powerless against the laws of science, that man, having come to know economic laws, can utilize them in the interests of society.
<G-vec00491-002-s224><come_through.haben><de> In den „Bemerkungen“ ist der bekannte Leitsatz enthalten, dass die Gesellschaft den Gesetzen der Wissenschaft gegenüber nicht machtlos ist, dass die Menschen, wenn sie die ökonomischen Gesetze erkannt haben, dieselben im Interesse der Gesellschaft ausnutzen können.
<G-vec00491-002-s225><come_through.haben><en> The rooms come with en suite bathrooms featuring a shower, a hairdryer and complimentary toiletries.
<G-vec00491-002-s225><come_through.haben><de> Die Zimmer haben einen modernen Dekor und En-suite-Badezimmer mit einer Dusche, Morgenmänteln und einem Fön.
<G-vec00491-002-s226><come_through.haben><en> 2014 will be a crucial year in deciding who will come out ahead in future years.
<G-vec00491-002-s226><come_through.haben><de> 2014 entscheidet sich, wer in den kommenden Jahren die Nase vorn haben wird.
<G-vec00491-002-s227><come_through.haben><en> Most models come with three or four shelves; exceptions to this are the double door freezer and double door bakery freezer.
<G-vec00491-002-s227><come_through.haben><de> Die meisten Gefrierschränke haben drei oder vier Fächer; eine Ausnahme stellen hier der zweitürige Gefrierschrank sowie der zweitürige Bäckerei-Gefrierschrank dar.
<G-vec00491-002-s456><come_through.sein><en> Biofuel can come in solid, liquid, or gaseous form.
<G-vec00491-002-s456><come_through.sein><de> Biobrennstoffe können fester, flüssiger oder gasförmiger Natur sein.
<G-vec00491-002-s457><come_through.sein><en> It is very common for such potentially unwanted applications to come bundled with freeware and adware.
<G-vec00491-002-s457><come_through.sein><de> Es ist durchaus üblich, dass solche potenziell unerwünschten Anwendungen mit Freeware und Adware gebündelt sein.
<G-vec00491-002-s458><come_through.sein><en> 13 And seeing a fig-tree afar off, having leaves, he came, if haply he might find any thing on it: and when he came to it, he found nothing but leaves: for the time of figs had not yet come.
<G-vec00491-002-s458><come_through.sein><de> 13 Und er sah einen Feigenbaum von ferne, der Blätter hatte; da trat er hinzu, ob er etwas darauf fände, und da er hinzukam, fand er nichts denn nur Blätter, denn es war noch nicht Zeit, daß Feigen sein sollten.
<G-vec00491-002-s459><come_through.sein><en> The end of the Italian Grand Prix also marked the end of an epoch: After 16 years, Formel Schumi should come to an end for the time being, the end of the season also meaning the end of an era for Ferrari, the most successful epoch a Formula 1 driver ever had together with his team.
<G-vec00491-002-s459><come_through.sein><de> Dass Ende des Großen Preises von Italien markiert auch das rasende Ende einer Epoche: Nach 16 Jahren soll vorerst Schluss sein mit der Formel Schumi, geht zum Saisonende auch eine Zeitrechnung von Ferrari zu Ende, die erfolgreichste Epoche, die je ein Formel-1-Fahrer mit seinem Team hatte.
<G-vec00491-002-s460><come_through.sein><en> The embossed wax must come from organic farming.
<G-vec00491-002-s460><come_through.sein><de> Das Imprägnierwachs muss aus kontrolliert biologischem Anbau sein.
<G-vec00491-002-s461><come_through.sein><en> Therefore, it should come as no surprise that the background of the game shows a vast, barren landscape.
<G-vec00491-002-s461><come_through.sein><de> Daher sollte es keine Überraschung sein, dass der Hintergrund des Spiels eine weite, öde Landschaft zeigt.
<G-vec00491-002-s462><come_through.sein><en> Another example when the “nofollow" attribute can come handy are widget links.
<G-vec00491-002-s462><come_through.sein><de> Ein weiteres Beispiel für einen Fall, in dem das Attribut "nofollow" praktisch sein kann, sind Widget-Links.
<G-vec00491-002-s463><come_through.sein><en> 13:14 And it shall come to pass, that as the chased roe, and as sheep that no man gathereth, they shall turn every man to his own people, and shall flee every man to his own land.
<G-vec00491-002-s463><come_through.sein><de> 13:14 Und es wird wie mit einer verscheuchten Gazelle sein und wie mit einer Herde, die niemand sammelt: jeder wird sich zu seinem Volk wenden und jeder in sein Land fliehen.
<G-vec00491-002-s464><come_through.sein><en> Today the rule is: anyone can come in who earns their living in the sports business and who has a relevant business relationship with at least one of the exhibitors.
<G-vec00491-002-s464><come_through.sein><de> Heute gilt: Zugelassen ist, wer sein Geld im Sport Business verdient und mit mindestens einem Aussteller eine einschlägige Geschäftsbeziehung hat.
<G-vec00491-002-s465><come_through.sein><en> The Ability quickly to tie around the waist can come in handy always.
<G-vec00491-002-s465><come_through.sein><de> Die Fähigkeit, schnell binden Sie sich um die eigene Taille kann immer nützlich sein.
<G-vec00491-002-s466><come_through.sein><en> Its Facebook messenger block feature can come in handy for the parents to ensure that their kids don’t engage in inappropriate activities.
<G-vec00491-002-s466><come_through.sein><de> Die Facebook-Messenger-Block -Funktion kann für die Eltern nützlich sein, um sicherzustellen, dass ihre Kinder keine unangemessenen Aktivitäten ausführen.
<G-vec00491-002-s467><come_through.sein><en> INTRODUCTION Jesus tells us: “Whoever wishes to come after me must deny himself, take up his cross each day and follow me”. This is an invitation addressed to everyone: to those who are married and those who are single, to young people, adults and the elderly, to the rich and poor, and to people of every nationality.
<G-vec00491-002-s467><come_through.sein><de> EINFÜHRUNG Jesus sagt: „Wer mein Jünger sein will, der verleugne sich selbst, nehme täglich sein Kreuz auf sich und folge mir nach.“ Das ist eine Aufforderung, die allen gilt, Ledigen und Verheirateten, Jugendlichen, Erwachsenen und alten Menschen, Reichen und Armen, Menschen aller Nationalitäten.
<G-vec00491-002-s468><come_through.sein><en> The LTE and 3G model should come out by the end of November.
<G-vec00491-002-s468><come_through.sein><de> Die Version mit LTE- und 3G-fähigem Mobilfunkmodul soll bis Ende November lieferbar sein.
<G-vec00491-002-s469><come_through.sein><en> And we though thought that we must had come decent far.
<G-vec00491-002-s469><come_through.sein><de> Und wir meinten schon, dass wir ganz ordentlich vorangekommen sein muessten.
<G-vec00491-002-s470><come_through.sein><en> You’ll come to your own conclusions.
<G-vec00491-002-s470><come_through.sein><de> Sie werden dann in der Lage sein, eigene Schlüsse zu ziehen.
<G-vec00491-002-s471><come_through.sein><en> When making a green smoothie I can rest assure it’ll come out silky smooth, every time.
<G-vec00491-002-s471><come_through.sein><de> Wenn ich grüne Smoothies herstelle, dann kann ich mir sicher sein, dass jedes Mal ein seidig weicher flüssiger Smoothie entsteht.
<G-vec00491-002-s472><come_through.sein><en> 8 And David saith on that day, 'Any one smiting the Jebusite, (let him go up by the watercourse), and the lame and the blind -- the hated of David's soul,' -- because the blind and lame say, 'He doth not come into the house.'
<G-vec00491-002-s472><come_through.sein><de> 8Da sprach David an diesem Tage: Wer die Jebusiter schlägt und durch den Schacht hinaufsteigt und die Lahmen und Blinden erschlägt, die David verhasst sind, der soll Hauptmann und Oberster sein.
<G-vec00491-002-s473><come_through.sein><en> At the same time, there is debate as to whether tighter capital requirements could come with a longer-term cost for the real economy.
<G-vec00491-002-s473><come_through.sein><de> Gleichzeitig gibt es eine Debatte darüber, ob höhere Kapitalanforderungen mit längerfristigen Kosten für die Realwirtschaft verbunden sein könnten.
<G-vec00491-002-s474><come_through.sein><en> As the oil acts on the sensitive oral mucosa for 10 to 20 minutes, the oil seeds and nuts should come from certified organic farming.
<G-vec00491-002-s474><come_through.sein><de> Da das Öl 10 bis 20 Minuten auf die empfindliche Mundschleimhaut einwirkt, sollte die Auswahl eines dafür bevorzugten Öles unbedingt auf Bio-Pflanzenöle ausgerichtet sein, die aus Ölsaaten und Nüssen aus kontrolliert biologischem Anbau und kalt gepresst werden.
<G-vec00491-002-s665><come_through.werden><en> These working groups are thematically orientated towards those future technologies that are relevant for the future of German industry and that the startups are active in: materials technologies, pharma, biotechnology and genetic technology, medical technology, energy technologies, digital business models/smart services and Industry 4.0 as well as integrated mobility (with more to come).
<G-vec00491-002-s665><come_through.werden><de> Die Arbeitsgruppen orientieren sich dabei thematisch an den für die Zukunft der deutschen Industrie relevanten Zukunftstechnologien, in denen die Startups aktiv sind: Materialtechnologien, integrierte Mobilität (die Liste wird schrittweise erweitert).
<G-vec00491-002-s666><come_through.werden><en> Come and see the ice kingdom at night when the spotlights light up the ice.
<G-vec00491-002-s666><come_through.werden><de> Besonders faszinierend – das Eiskönigreich in der Nacht, wenn es von Scheinwerfern angeleuchtet wird.
<G-vec00491-002-s667><come_through.werden><en> First, take the time to visit the Roman ruins on the Sirmione peninsula, a touristy and lively little town located on a promontory surrounded by water, where the singer Maria Callas liked to come to relax.
<G-vec00491-002-s667><come_through.werden><de> Nehmen Sie sich zuerst die Zeit, um die Ruinen aus römischer Zeit auf der Halbinsel Sirmione zu besuchen, einer lebendigen kleinen Stadt, die gerne von Touristen besucht wird und sich auf einem Felsen befindet, der von Wasser umgeben wird und wo die Sängerin Maria Callas sich gerne erholte.
<G-vec00491-002-s668><come_through.werden><en> All products in the Anal Fantasy range come with an anal pleasure preparation kit, including: 2 small finger sleeves, a desensitising anal cream, a lubricant especially designed for anal penetration as well as some sex toy cleaning fluid.
<G-vec00491-002-s668><come_through.werden><de> Jedes Produkt der „Anal Fantasy“ Modelle wird mit einem Sortiment zur Vorbereitung für das anale Vergnügen geliefert, einschließlich: 2 kleine Gummimanschetten für Finger, eine anale Desensibilisierungs-Creme, ein spezielles Gleitmittel für die anale Penetration und ein Sexspielzeugreiniger.
<G-vec00491-002-s669><come_through.werden><en> Most fitness trackers today come with a heart rate monitor built in.
<G-vec00491-002-s669><come_through.werden><de> Die Herzfrequenz wird bei beiden Fitness Trackern auch in gleicher Frequenz gemessen.
<G-vec00491-002-s670><come_through.werden><en> Should a significant deterioration in the Buyer’s financial circumstances occur or be expected to occur in future for objective reasons which does not come to our knowledge until after conclusion of the contract, we are entitled to demand cash pre-payments for future deliveries, or temporarily refuse delivery and invoice the goods on notification of readiness for shipment.
<G-vec00491-002-s670><come_through.werden><de> Für den Fall, dass in den Vermögensverhältnissen des Käufers eine wesentliche Verschlechterung eingetreten ist oder aufgrund objektiver Umstände für die Zukunft erwartet wird und wir hiervon erst nach dem Abschluss Kenntnis bekommen, können wir für weitere Lieferungen Vorauszahlungen in bar verlangen oder aber die Lieferungen einstweilen verweigern und die Ware bei Versandbereitschaft in Rechnung stellen.
<G-vec00491-002-s671><come_through.werden><en> Bass Drums are one of the most important parts of the drum kit, and come in various depths and diameters to produce different tones and pitches.
<G-vec00491-002-s671><come_through.werden><de> Die Bassdrum ist eines der wichtigsten Teile des Drum Kits und wird in verschiedenen Tiefen und Durchmessern produziert, sodass unterschiedliche Klänge und Tonhöhen entstehen.
<G-vec00491-002-s672><come_through.werden><en> Another reason is the tradition how they raise them animals, a way to come generations by generations.
<G-vec00491-002-s672><come_through.werden><de> Ein weiterer Grund ist die traditionelle Art der Tierzucht, die von Generation zu Generation weitergegeben wird.
<G-vec00491-002-s673><come_through.werden><en> It’s a holiday fantasy for parents of young football fans come true: a luxurious beach resort for them and a summer soccer camp for the kids.
<G-vec00491-002-s673><come_through.werden><de> Eine Urlaubsfantasie für Eltern von jungen Fußballfans wird wahr: ein luxuriöses Strandresort für sie und ein Fußball-Sommercamp für die Kids.
<G-vec00491-002-s674><come_through.werden><en> Binoculars come with a pouch, strap and optics cleaning cloth. The Scalpel
<G-vec00491-002-s674><come_through.werden><de> Das Fernglas wird mit einer Tasche, einem Riemen und einem Optikreinigungstuch geliefert.
<G-vec00491-002-s675><come_through.werden><en> Essential oils come from plants, while fragrance oils are usually artificially created and often contain synthetic chemicals.
<G-vec00491-002-s675><come_through.werden><de> Ersteres wird aus Pflanzen gewonnen, während Duftöle normalerweise künstlich hergestellt sind und häufig synthetische Chemikalien enthalten.
<G-vec00491-002-s676><come_through.werden><en> While Dean distracts Amara, Sam, Metatron and the Prophet Donatello Redfield come to Lucifer's rescue.
<G-vec00491-002-s676><come_through.werden><de> In Die Familie der Finsternis wird Luzifer von Amara durch ihre Macht gefoltert, aber er wird später von Sam, Metatron und Donatello Redfield gerettet.
<G-vec00491-002-s677><come_through.werden><en> The headphones come with a generous amount of accessories such as an extra pair of leatherette cushions and an airplane adapter.
<G-vec00491-002-s677><come_through.werden><de> Die Ausstattung wird mit dem üppigen Lieferumfang abgerundet, der ein zusätzliches Paar Velours-Ohrpolster und einen Flugzeug-Adapter beinhaltet.
<G-vec00491-002-s678><come_through.werden><en> Making the dream come true.
<G-vec00491-002-s678><come_through.werden><de> Damit der Traum wahr wird.
<G-vec00491-002-s679><come_through.werden><en> In the book of Galatians it happens to come under the brand name of circumcision and mosaic legalism.
<G-vec00491-002-s679><come_through.werden><de> Im Brief an die Galater wird das unter dem Namen „Beschneidung“ und „mosaischer Legalismus“ beschrieben.
<G-vec00491-002-s680><come_through.werden><en> The message that a continuation of the mission of Christianity would come can be found in Jesus’ predictions about the comforter, the holy spirit: "I have yet many things to say unto you, but ye cannot bear them now."
<G-vec00491-002-s680><come_through.werden><de> Die Botschaft, dass es eine Fortsetzung der Mission des Christentums geben wird, findet man in Jesu Voraussagen über den Sprecher, den Heiligen Geist: ”Ich habe euch noch Vieles zu sagen, aber ihr könnt es jetzt nicht tragen”.
<G-vec00491-002-s681><come_through.werden><en> The unique design and maximum functionality come together in a perfect symbiosis between the lines of the blade and the handle.
<G-vec00491-002-s681><come_through.werden><de> Die hochwertige Ausstrahlung des Natur-materials wird durch einen Mosaik-Pin in der Griff-mitte und die dekorative Endkappe aus Stahl zusätz-lich unterstrichen.
<G-vec00491-002-s682><come_through.werden><en> The new system is also significantly more energy-efficient and less labor-intensive than the previous lighting system, allowing it to inspire visitors for years to come.
<G-vec00491-002-s682><come_through.werden><de> Das neue System ist wesentlich energiesparender als das vorige und gleichzeitig auch weniger arbeitsintensiv – Eine Inspiration für jeden Besucher, die noch über Jahre hin faszinieren wird.
<G-vec00491-002-s683><come_through.werden><en> Moses said to Yahweh, ‘The people can’t come up to Mount Sinai, for you warned us, saying, “Set bounds around the mountain, and sanctify it.”’
<G-vec00491-002-s683><come_through.werden><de> 23 Und Mose sprach zu Jehova: Das Volk wird den Berg Sinai nicht ersteigen können; denn du hast uns ja gewarnt und gesagt: Mache eine Grenze um den Berg und heilige ihn.
