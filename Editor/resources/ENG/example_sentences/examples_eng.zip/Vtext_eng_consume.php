<G-vec00476-001-s009><consume.aufnehmen><en> Directions for use Feed between 8 and 17°C water temperature, but only as much as the fish can consume within a short time.
<G-vec00476-001-s009><consume.aufnehmen><de> Gebrauchsinformation FÃ1⁄4ttern Sie zwischen 8 und 17 °C, nur so viel, wie die Fische in kurzer Zeit aufnehmen.
<G-vec00476-001-s010><consume.aufnehmen><en> Feeding recommendation Tetra Pond Colour Sticks: Feed 2-3 times a day as much as the fish can consume within a few minutes.
<G-vec00476-001-s010><consume.aufnehmen><de> Fütterungsempfehlung Tetra Pond Colour Sticks: Füttern Sie mindestens 2 bis 3 Mal täglich nur so viel, wie Ihre Fische innerhalb weniger Minuten aufnehmen können.
<G-vec00476-001-s011><consume.aufnehmen><en> This is because with the water that you consume, the infectious, painful mucus is released and your mucous membranes can regenerate once again.
<G-vec00476-001-s011><consume.aufnehmen><de> Denn durch das Wasser, das Sie aufnehmen, wird der infektiöse, schmerzende Schleim gelöst, und auch die Schleimhäute können sich wieder regenerieren.
<G-vec00476-001-s012><consume.aufnehmen><en> Directions for use Feed below 12°C water temperature, but only as much as the fish can consume within a short time.
<G-vec00476-001-s012><consume.aufnehmen><de> Gebrauchsinformation FÃ1⁄4ttern Sie unter 12 °C, nur so viel, wie die Fische in kurzer Zeit aufnehmen.
<G-vec00476-001-s013><consume.aufnehmen><en> The body can also consume something unhealthy, that is, nourishment which still contains too many immature spiritual substances.... which then might not only bother the body but also the soul.... and manifest itself in the form of diseases....
<G-vec00476-001-s013><consume.aufnehmen><de> Es kann der Körper auch Ihm-Unzuträgliches aufnehmen, d.h. eine Kost, die noch im Übermaß unausgereiftes Geistiges birgt.... das nun sowohl den Körper als auch die Seele bedrängen kann.... was sich in Form von Krankheiten auswirkt....
<G-vec00476-001-s014><consume.aufnehmen><en> Problems arise when you consume a large amount of sugar.
<G-vec00476-001-s014><consume.aufnehmen><de> Probleme entstehen, wenn Sie große Mengen von Zucker aufnehmen.
<G-vec00476-001-s015><consume.aufnehmen><en> Since our role models are to a great extent shaped by what we consume in the media, we decided this would be a good approach.
<G-vec00476-001-s015><consume.aufnehmen><de> Da unsere Rollenbilder ja ganz stark von dem besetzt sind, was wir über die Medien aufnehmen, haben wir hier einen Ansatzpunkt gesehen.
<G-vec00476-001-s016><consume.aufnehmen><en> The components from BARTEC, which consume a total of 1.7 megawatts of power, are used in a wide range of areas.
<G-vec00476-001-s016><consume.aufnehmen><de> Die BARTEC-Komponenten, die zusammen 1,7 Megawatt Leistung aufnehmen, finden sich an den unterschiedlichsten Einsatzorten.
<G-vec00476-001-s017><consume.aufnehmen><en> Recommended feeding for Tetra Malawi Flakes:Feed the fish several times a day with only as much food as the fish can consume within a few minutes.
<G-vec00476-001-s017><consume.aufnehmen><de> Fütterungsempfehlung Tetra Malawi Flakes: Füttern Sie mehrmals täglich so viel, wie die Fische innerhalb weniger Minuten aufnehmen können.
<G-vec00476-001-s074><consume.fressen><en> The animals consume a great deal of the algae, digest and then excrete them.
<G-vec00476-001-s074><consume.fressen><de> Die Tiere fressen einen Großteil der Algen weg, verdauen diese und scheiden entsprechend viele Kotpartikel aus.
<G-vec00476-001-s075><consume.fressen><en> Insects live in highly organised social colonies with defined roles; they can build structures and ‘cities’ or consume and destroy everything in their wake.
<G-vec00476-001-s075><consume.fressen><de> Insekten leben in hoch organisierten sozialen Verbänden mit definierten Rollen; sie können Strukturen bilden und „Städte“ bauen, oder alles fressen und zerstören, was ihnen in den Weg kommt.
<G-vec00476-001-s076><consume.fressen><en> The young caterpillars preferably consume flowers or at least young shoots.
<G-vec00476-001-s076><consume.fressen><de> Die Jungraupen fressen gerne an Blüten oder zumindest Jungtrieben.
<G-vec00476-001-s077><consume.fressen><en> Feeding Recommendations: Feed daily as much as the animals can consume within 10 minutes.
<G-vec00476-001-s077><consume.fressen><de> Fütterungsempfehlung: Füttern Sie täglich soviel, wie die Tiere in 10 Minuten fressen können.
<G-vec00476-001-s078><consume.fressen><en> This particular variety of herring will gather in busy harbors to feed on the small sea creatures which consume the waste dumped from ships.
<G-vec00476-001-s078><consume.fressen><de> Diese Heringsart findet sich in Häfen wieder, um sich von den kleinen Meereskreaturen zu ernähren, die den Abfall von Schiffen fressen.
<G-vec00476-001-s079><consume.fressen><en> 14 But if ye will not hearken unto me, and will not do all these commandments; 15 And if ye shall despise my statutes, or if your soul abhor my judgments, so that ye will not do all my commandments, but that ye break my covenant: 16 I also will do this unto you; I will even appoint over you terror, consumption, and the burning ague, that shall consume the eyes, and cause sorrow of heart: and ye shall sow your seed in vain, for your enemies shall eat it.
<G-vec00476-001-s079><consume.fressen><de> 14 Werdet ihr aber mir nicht gehorchen und nicht tun diese Gebote alle, 15 und werdet meine Satzungen verachten, und eure SeeLE meine Rechte verwerfen, daß ihr nicht tut alLE meine Gebote, und werdet meinen Bund lassen anstehen, 16 so will ich euch auch solches tun:Ich will euch heimsuchen mit Schrecken, Schwulst und Fieber, daß euch die Angesichte verfallen und der Leib verschmachte; ihr sollt umsonst euren Samen säen, und eure Feinde sollen ihn fressen.
<G-vec00476-001-s080><consume.fressen><en> 42 Locusts shall consume all your trees and the produce of your land.
<G-vec00476-001-s080><consume.fressen><de> 42 Alle deine Bäume und Früchte deines Landes wird das Ungeziefer fressen.
<G-vec00476-001-s081><consume.fressen><en> Fish lovers say that all the kilos of fish the cormorants now consume would otherwise be available for the fisheries.
<G-vec00476-001-s081><consume.fressen><de> Die Fischliebhaber sagen, dass die Kilos Fisch, die die Kormorane jetzt fressen, ansonsten der Fischerei zur Verfügung stehen würden.
<G-vec00476-001-s082><consume.fressen><en> €10,95 Shirakura Ebi Dama soft are soft pads that are easier to consume for shrimp than the standard Shirakura Ebi Dama.
<G-vec00476-001-s082><consume.fressen><de> €10,95 Shirakura Ebi Dama soft sind weiche Pads, die für Garnelen einfacher zu fressen sind als die Standard Pads.
<G-vec00476-001-s091><consume.konsumieren><en> In addition to funding prominent British scientists, Coca-Cola also paid £4.8 million to the European Hydration Institute, a research foundation which recommended people to consume sport and soft drinks of the kind the company sells.
<G-vec00476-001-s091><consume.konsumieren><de> Neben der Finanzierung prominenter britischer Wissenschaftler zahlte Coca-Cola auch 4,8 Millionen Pfund an das European Hydration Institute, eine Forschungsstiftung, die den Konsum von Sport- und Erfrischungsgetränken, wie sie das Unternehmen verkauft, empfiehlt.
<G-vec00476-001-s092><consume.konsumieren><en> It can consume royal jelly throughout the year and cycles advantageous to cures (1 to 2 months) are fall and spring.
<G-vec00476-001-s092><consume.konsumieren><de> Man kann der Konsum von Gelee Royal das ganze Jahr, und die Zeiten für den Kuren (1 bis 2 Monate) sind im Herbst und Frühjahr.
<G-vec00476-001-s093><consume.konsumieren><en> He does not buy products tested on animals or containing unnecessary chemicals, and tries to consume in moderation.
<G-vec00476-001-s093><consume.konsumieren><de> Er kauft keine Produkte, die an Tieren getestet werden oder unnötige Chemikalien enthalten und versucht seinen Konsum einzuschränken.
<G-vec00476-001-s094><consume.konsumieren><en> The term ‘food system’ covers all the processes and the infrastructure we have established to produce and consume food.
<G-vec00476-001-s094><consume.konsumieren><de> "Mit dem Begriff „Nahrungsmittelsystem"" werden alle Prozesse und die Infrastruktur zusammengefasst, die wir für Herstellung und Konsum von Nahrungsmitteln geschaffen haben."
<G-vec00476-001-s095><consume.konsumieren><en> """Where the inclination to save is still very strong but weakening slightly, willingness to consume increases somewhat,"" says Bruckbauer."
<G-vec00476-001-s095><consume.konsumieren><de> """Bei weiterhin sehr hoher, aber leicht sinkender Sparneigung nimmt doch die Bereitschaft zum Konsum etwas zu"", sagt Bruckbauer."
<G-vec00476-001-s096><consume.konsumieren><en> Cocaine, MDMA, and lower potency stimulants such as dexamphetamine, could also be available at licensed premises like pubs or coffee shops, where members buy things to consume on site.
<G-vec00476-001-s096><consume.konsumieren><de> Kokain, MDMA und weniger Potente Stimulantien wie das ADHS-Mittel Dexamphetamin könnten man auch an lizenzierten Orte nach dem Modell niederländischer Coffeeshops verkaufen, wo Vereins- oder Clubmitglieder Substanzen zum Konsum vor Ort erstehen.
<G-vec00476-001-s097><consume.konsumieren><en> I began to consume heroin and cocaine early in 1993, shooting heroine regularly.
<G-vec00476-001-s097><consume.konsumieren><de> Mit dem Konsum von Heroin und Kokain begann ich Anfang 1993, wobei ich Heroin regelmäßig spritzte.
<G-vec00476-001-s098><consume.konsumieren><en> Tourists might be more inclined to purchase edibles over raw cannabis because they are less conspicuous and easier to consume.
<G-vec00476-001-s098><consume.konsumieren><de> Touristen könnten dazu tendieren, eher essbare Produkte zu kaufen als puren Cannabis, da ihr Konsum weniger auffällig und einfacher ist.
<G-vec00476-001-s099><consume.konsumieren><en> Precautions Before taking Thorazine tell your doctor about all the conditions you may have, especially if you are pregnant, planning to become pregnant or breastfeeding, if you are taking any medicines prescribed and not prescribed, herbal products or dietary supplement, if you have allergies to medicines, food, etc, if you have history of heart problems, blood problems, high blood pressure, liver problems such as cirrhosis, kidney problems, seizures or epilepsy, Parkinson disease, enlarged prostate gland, Reye syndrome, alcohol abuse or if you consume more than 3 alcoholic drinks per day, if you have lung infections, asthma and other lung problems, glaucoma, increased pressure in the eyes or if you are have a risk of glaucoma.
<G-vec00476-001-s099><consume.konsumieren><de> Vorsichtsmaßnahmen Bevor Sie mit der Einnahme von Thorazine beginnen, informieren Sie Ihren Arzt über sämtliche Zustände, die Sie haben können, besonders falls Sie schwanger sind, eine Schwangerschaft planen oder sich in der Stillzeit befinden; verschreibungspflichtige oder rezeptfreie Medikamente, pflanzliche Produkte oder Nahrungsergänzungsmittel einnehmen; allergisch auf Medikamente, Nahrungsmittel und so weiter reagieren, solche Erkrankungen in der Anamnese haben wie Herz- oder Blutprobleme, Bluthochdruck, Leberprobleme wie Leberzirrhose, Nierenerkrankungen, Krampfanfälle oder Epilepsie, die Parkinson-Krankheit, eine vergrößerte Prostata, das Reye-Syndrom, Alkoholmissbrauch oder der Konsum von mehr als drei alkoholischen Getränken pro Tag, Lungeninfektionen, Asthma und andere Lungenerkrankungen, Glaukom, erhöhter Druck in den Augen oder falls Sie ein Risiko von Glaukom haben.
<G-vec00476-001-s100><consume.konsumieren><en> Consume organic vegetables and fruits daily.
<G-vec00476-001-s100><consume.konsumieren><de> Konsumiere täglich biologisch angebautes Gemüse und Obst.
<G-vec00476-001-s101><consume.konsumieren><en> I consume this tablet for 3 months.
<G-vec00476-001-s101><consume.konsumieren><de> Ich konsumiere diese Tablette für 3 Monate.
<G-vec00476-001-s102><consume.konsumieren><en> I consume this product for 3 months.
<G-vec00476-001-s102><consume.konsumieren><de> Ich konsumiere diese Kapsel für 3 Monate.
<G-vec00476-001-s103><consume.konsumieren><en> But I consume very little of Berlin’s cultural offerings.
<G-vec00476-001-s103><consume.konsumieren><de> Aber von dem kulturellen Angebot Berlins konsumiere ich kaum etwas.
<G-vec00476-001-s104><consume.konsumieren><en> Do not consume tea tree oil, as it is toxic.
<G-vec00476-001-s104><consume.konsumieren><de> Konsumiere Teebaumöl nicht oral, weil es giftig ist.
<G-vec00476-001-s105><consume.konsumieren><en> Do not consume magic truffles if you are on medication or in combination with alcohol.
<G-vec00476-001-s105><consume.konsumieren><de> Konsumiere keine magischen Trüffel wenn Du auf Medikamenten bist oder in Kombination mit Alkohol.
<G-vec00476-001-s106><consume.konsumieren><en> Consume more vitamin E. Vitamin E is an antioxidant that protects body tissue from damage caused by bacteria and viruses.
<G-vec00476-001-s106><consume.konsumieren><de> Konsumiere mehr Vitamin E. Vitamin E ist ein Antioxidans, das den Körper vor Schäden durch Bakterien und Viren schützt.
<G-vec00476-001-s107><consume.konsumieren><en> It is really basic to consume Fish Oil.
<G-vec00476-001-s107><consume.konsumieren><de> Es ist wirklich grundlegende zu konsumieren Fish Oil .
<G-vec00476-001-s108><consume.konsumieren><en> Naturally the food you consume is an important aspect of your ayurvedic treatment and lifestyle.
<G-vec00476-001-s108><consume.konsumieren><de> NatÃ1⁄4rlich ist das Essen, das Sie konsumieren, ein wichtiger Aspekt Ihrer ayurvedischen Behandlung und Ihres Lebensstils.
<G-vec00476-001-s109><consume.konsumieren><en> Fish Oil supplements are the most effective technique to increase the intake of these essential compounds, without the responsibility to consume lots of fishes.
<G-vec00476-001-s109><consume.konsumieren><de> Fish Oil Tabletten sind der effektivste Weg, um die Aufnahme dieser entscheidenden Verbindungen zu steigern, ohne die Verantwortung mehr Fische zu konsumieren.
<G-vec00476-001-s110><consume.konsumieren><en> An average person should consume about 3000-5000 units per day.
<G-vec00476-001-s110><consume.konsumieren><de> Eine durchschnittliche Person sollte etwa 3000-5000 Einheiten pro Tag konsumieren.
<G-vec00476-001-s111><consume.konsumieren><en> In this way, we can offer our viewers fascinating content that they can consume on their choice of platform – either linearly or digitally.
<G-vec00476-001-s111><consume.konsumieren><de> Unseren Zuschauern bieten wir so faszinierende Inhalte, die sie plattformunabhängig sowohl linear als auch digital konsumieren können.
<G-vec00476-001-s112><consume.konsumieren><en> This means that you should regularly consume Oolong, should never be exaggerated and drinking liters and liters each day.
<G-vec00476-001-s112><consume.konsumieren><de> Dies bedeutet, dass, während Sie sollten regelmäßig Oolong-Tee zu konsumieren, sollten Sie niemals übertreibe und trinken Liter und Liter jeden Tag.
<G-vec00476-001-s113><consume.konsumieren><en> If you experience the impotence, you ought to consume some herbal pills to boost your testosterone degree.
<G-vec00476-001-s113><consume.konsumieren><de> Wenn Sie die Erektionsstörung auftreten, sollten Sie einige natürliche Kapseln konsumieren, um Ihren Testosteron Grad zu erhöhen.
<G-vec00476-001-s114><consume.konsumieren><en> It is very important to consume the raw water quality, the bacteria are destroyed by boiling, evaporation occurs free chlorine and organic matter, but chlorine, part of the organic compounds when heated turns into a poison, gradually accumulate in the body.
<G-vec00476-001-s114><consume.konsumieren><de> Es ist sehr wichtig, die Rohwasserqualität zu konsumieren, werden die Bakterien durch Kochen zerstört, tritt Verdunstung freies Chlor und organischem Material, aber Chlor, ein Teil der organischen Verbindungen, wenn sie erhitzt wird zum Gift, allmählich im Körper anreichern.
<G-vec00476-001-s115><consume.konsumieren><en> As zombies they 'consume' the (hi)story, the characters, and the roles ascribed to them.
<G-vec00476-001-s115><consume.konsumieren><de> "Als Zombies ""konsumieren"" sie die Geschichte, die Figuren, und die ihnen zugeschriebenen Rollen."
<G-vec00476-001-s116><consume.konsumieren><en> You should not consume cold drinks and junk food in excess if you wish to solve the problem of hair loss completely.
<G-vec00476-001-s116><consume.konsumieren><de> Sie sollten nicht konsumiert kalten Getränken und Junk-Food mehr, wenn Sie das Problem des Haarausfalls lösen wollen vollständig aus.
<G-vec00476-001-s117><consume.konsumieren><en> It always gives us the feeling that the whole post is constructed for the the reader to buy and consume and for the blogger to make cash – which is entirely missing the ‘inspiration’ point.
<G-vec00476-001-s117><consume.konsumieren><de> Uns vermittelt es stets das Gefühl, als sei der ganze Beitrag darauf ausgelegt, dass der Leser konsumiert und der Blogger kassiert – wir empfinden diese mit Links und Hinweisen zugeknallten Mode Posts daher am Thema ‚Inspiration‘ im Endeffekt völlig vorbei geschossen.
<G-vec00476-001-s118><consume.konsumieren><en> As for the prices are all displayed with the utmost transparency, no price is hidden and everyone is free to decide whether to consume or not.
<G-vec00476-001-s118><consume.konsumieren><de> Die Preise werden alle mit größter Transparenz angezeigt, kein Preis ist versteckt und jeder kann entscheiden, ob er konsumiert oder nicht.
<G-vec00476-001-s119><consume.konsumieren><en> D. 2) If the local Ordinary may permit a priest who finds himself in the same condition, to celebrate Mass, even alone, communicating by “intinction,” provided that the faithful who assist at the Mass consume the consecrated wine that remains.
<G-vec00476-001-s119><consume.konsumieren><de> "Frage 2) Ob der Ortsordinarius einem Priester mit demselben Problem erlauben kann, auch allein die Messe zu feiern und dabei die Kommunion durch ""Intinktion"" zu empfangen, wenn nur ein Gläubiger, der an der Messe teilnimmt, das, was vom konsekrierten Wein verbleibt, konsumiert."
<G-vec00476-001-s120><consume.konsumieren><en> It is possible to consume coca tea in the hotels and restaurants, even in the Western embassies in Bolivia.
<G-vec00476-001-s120><consume.konsumieren><de> Kokatee kann in Hotels und Restaurants konsumiert werden, selbst in den westlichen Botschaften in Bolivien.
<G-vec00476-001-s121><consume.konsumieren><en> You cannot import, export or consume drugs and narcotics; explosives; objects, photos, literature or any other pornographic item; animals, plants and their parts designated as a protected or endangered species.
<G-vec00476-001-s121><consume.konsumieren><de> Drogen und Rauschmittel, Sprengkörper, pornografische Schriften, Objekte, Fotos oder sonstige Artikel, Tiere, Pflanzen und Teile davon, die von bedrohten oder geschützten Arten stammen dürfen weder importiert noch exportiert oder konsumiert werden.
<G-vec00476-001-s122><consume.konsumieren><en> If the consume soft drinks regularly, he should stop this habit before surgery.
<G-vec00476-001-s122><consume.konsumieren><de> Wenn man regelmäßig kohlensäurehaltige Getränke konsumiert, sollte er diese Gewohnheit zu stoppen, bevor die Operation.
<G-vec00476-001-s123><consume.konsumieren><en> "The Prophet said to his retinue: ""Do not consume this food. It is poisoned."
<G-vec00476-001-s123><consume.konsumieren><de> Der Prophet sagte zu seinen Gefährten: “Konsumiert dieses Eßen nicht, es ist vergiftet”.
<G-vec00476-001-s124><consume.konsumieren><en> It is of course true that the worker himself does not consume the product which he himself has directly produced; but his product does bear within it a quality which all goods socially produced have in common: the average social labour-time required for its production.
<G-vec00476-001-s124><consume.konsumieren><de> Wohl konsumiert der Arbeiter nicht direkt das durch ihn selbst hergestellte Produkt; aber sein Produkt trägt etwas in sich, das alle gesellschaftlichen Güter gemeinsam haben: die gesellschaftlich notwendige Arbeitszeit, die ihre Herstellung kostete.
<G-vec00476-001-s179><consume.verbrauchen><en> In the next 10 to 15 years, the countries of North Africa will consume the vast majority of the electricity they generate.
<G-vec00476-001-s179><consume.verbrauchen><de> In den nächsten 10-15 Jahren werden die nordafrikanischen Länder den größten Anteil des Stroms selbst verbrauchen.
<G-vec00476-001-s180><consume.verbrauchen><en> Rather, it boosts the degree of satiation (satisfaction you get from food), making it less complicated to consume food much less.
<G-vec00476-001-s180><consume.verbrauchen><de> Vielmehr steigert es den Grad der Sättigung (Zufriedenheit, die Sie aus der Nahrung), so dass es weniger kompliziert Essen viel weniger zu verbrauchen.
<G-vec00476-001-s181><consume.verbrauchen><en> Synthetic stop premature ejaculation options may be difficult for your body to consume so with natural solutions you should have the ability to fully absorb the elements to enhance your intimate objectives.
<G-vec00476-001-s181><consume.verbrauchen><de> Synthetische Stop vorzeitige Ejakulation Optionen kann schwierig sein, für Ihren Körper zu tun mit natürlichen Lösungen verbrauchen, sollten Sie die Möglichkeit, die Elemente, um Ihre Ziele zu verbessern intime vollständig zu absorbieren.
<G-vec00476-001-s182><consume.verbrauchen><en> Lots of of the minerals you consume are missing due to sweat, in particular for the period of exercise routines, so it happens to be more critical than ever to assure that you simply get ample mineral dietary supplements for muscle building, and on the right periods.
<G-vec00476-001-s182><consume.verbrauchen><de> Viele der Mineralien, die Sie verbrauchen werden für den Zeitraum der Ausübung Routinen fehlen aufgrund von Schweiß, insbesondere, so kommt es wichtiger denn je, um sicherzustellen, dass Sie einfach zu bekommen reichlich Mineralnahrungsergänzungsmitteln für den Muskelaufbau zu sein und auf die richtigen Zeiträume .
<G-vec00476-001-s183><consume.verbrauchen><en> # Learn how to make dieting and eliminate the extra pounds, the body needs to consume fewer calories and provide more energy.
<G-vec00476-001-s183><consume.verbrauchen><de> Erfahren Sie, wie Diäten machen und die Beseitigung der überflüssigen Pfunde, muss der Körper weniger Kalorien zu verbrauchen und mehr Energie liefern.
<G-vec00476-001-s184><consume.verbrauchen><en> 20 percent of the world population consume 80 percent of the resources and are responsible for 80 percent of climate-damaging emissions.
<G-vec00476-001-s184><consume.verbrauchen><de> 20 Prozent der Weltbevölkerung verbrauchen 80 Prozent der Ressourcen und sind für 80 Prozent der klimaschädlichen Emissionen verantwortlich.
<G-vec00476-001-s185><consume.verbrauchen><en> For best results, do not consume food or protein shakes 1 hour after taking Anadraulic State.
<G-vec00476-001-s185><consume.verbrauchen><de> Für beste Ergebnisse, nicht verbrauchen Lebensmittel-oder Protein-Shakes 1 Stunde nach Einnahme Anadraulic Staat.
<G-vec00476-001-s186><consume.verbrauchen><en> LED spotlight consume only a minimum amount of power and are in use even under installed.
<G-vec00476-001-s186><consume.verbrauchen><de> Â LED-Strahler verbrauchen nur einen minimalen Anteil an Strom und liegen im Verbrauch sogar unter Energiesparleuchten.
<G-vec00476-001-s187><consume.verbrauchen><en> In other words, the 8 million people living in Switzerland consume as much resources as the 850 million inhabitants of the poorest countries.
<G-vec00476-001-s187><consume.verbrauchen><de> Oder anders gesagt, die acht Millionen in der Schweiz lebenden Menschen verbrauchen so viel Ressourcen wie die 850 Millionen EinwohnerInnen der ärmsten Länder.
<G-vec00476-001-s197><consume.verbrauchen><en> The basic of losing weight is simple; consume less calories than you burn.
<G-vec00476-001-s197><consume.verbrauchen><de> Das grundlegende des Schlussen Gewichts ist einfach; verbrauchen Sie weniger Kalorien als Sie Brand.
<G-vec00476-001-s198><consume.verbrauchen><en> Consume more water every day to prevent acid reflux.
<G-vec00476-001-s198><consume.verbrauchen><de> Verbrauchen Sie mehr Wasser jeden Tag, um Sodbrennen zu vermeiden.
<G-vec00476-001-s199><consume.verbrauchen><en> Consume a very small dose .
<G-vec00476-001-s199><consume.verbrauchen><de> Verbrauchen Sie eine sehr kleine Dosis.
<G-vec00476-001-s200><consume.verbrauchen><en> Consume 3 pills with water about 15 minutes after training.
<G-vec00476-001-s200><consume.verbrauchen><de> Verbrauchen Sie 3 Tabletten mit Wasser etwa 15 Minuten nach dem Training.
<G-vec00476-001-s201><consume.verbrauchen><en> Consume more live food.
<G-vec00476-001-s201><consume.verbrauchen><de> Verbrauchen Sie mehr Lebendfutter.
<G-vec00476-001-s202><consume.verbrauchen><en> Consume one pill 3 times daily with water roughly 30-45 mins before workout.
<G-vec00476-001-s202><consume.verbrauchen><de> Verbrauchen Sie eine Pille 3-mal täglich mit Wasser etwa 30 bis 45 Minuten vor dem Training.
<G-vec00476-001-s203><consume.verbrauchen><en> Consume daily dose of fiber.
<G-vec00476-001-s203><consume.verbrauchen><de> Verbrauchen Sie Ihre tägliche Dosis der Faser.
<G-vec00476-001-s204><consume.verbrauchen><en> Also consume flowers and fruits.
<G-vec00476-001-s204><consume.verbrauchen><de> Auch verbrauchen Sie, Blüten und Früchten.
<G-vec00476-001-s205><consume.verbrauchen><en> Consume one pill 3 times daily with water around 30-45 mins prior to exercise.
<G-vec00476-001-s205><consume.verbrauchen><de> Verbrauchen Sie eine Pille 3-mal täglich mit Wasser etwa 30-45 Minuten vor dem Training.
<G-vec00476-001-s206><consume.verbrauchen><en> Seen over the year this heater does not consume more electricity than the smaller model (it takes a shorter time to heat the water), but often does not fit into the aquarium lengthwise.
<G-vec00476-001-s206><consume.verbrauchen><de> Dieser verbraucht im Jahresdurchschnitt nicht mehr als das kleinere Modell (benötigt eine geringe Zeit für die Erhitzung des Wassers), passt aber häufig in der Länge nicht in das Aquarium.
<G-vec00476-001-s207><consume.verbrauchen><en> The power management ensures that on-board systems do not consume more electrical power than the alternator can supply, and thus maintains the maximum possible battery power level.
<G-vec00476-001-s207><consume.verbrauchen><de> Es regelt, dass nicht mehr elektrische Energie verbraucht als erzeugt wird und sorgt dadurch für einen optimalen Ladezustand der Batterie.
<G-vec00476-001-s208><consume.verbrauchen><en> An attacker can send a relatively small XML document that, when the entities are resolved, will consume extreme amounts of memory on the target system.
<G-vec00476-001-s208><consume.verbrauchen><de> Ein Angreifer kann so mithilfe eines verhältnismäßig kleinen XML-Dokuments erreichen, dass bei der Expansion der Entitäten extreme Mengen an Arbeitsspeicher auf dem Zielsystem verbraucht werden.
<G-vec00476-001-s209><consume.verbrauchen><en> This equipment may be unpleasant for the very first usage but it will consume 2-3 weeks for you to gain regular with this equipment.
<G-vec00476-001-s209><consume.verbrauchen><de> Dieses Gerät könnte für die erste Nutzung unruhig sein, aber es wird sicherlich 2-3 Wochen verbraucht für Sie mit diesem Gerät regelmäßig zu erhalten.
<G-vec00476-001-s210><consume.verbrauchen><en> This appliance could be unpleasant for the very first use however it will consume 2-3 weeks for you to obtain habitual with this equipment.
<G-vec00476-001-s210><consume.verbrauchen><de> Dieses Gerät könnte zum ersten Einsatz unangenehm sein aber es wird 2-3 Wochen verbraucht für Sie mit diesem Gerät gewöhnlichen zu erhalten.
<G-vec00476-001-s211><consume.verbrauchen><en> """And then shall be revealed the wicked one, whom the Lord shall consume with the spirit of His mouth, and shall destroy with the brightness of His coming: even him whose coming is after the working of Satan, with all power, and signs, and lying wonders, and with all deceivableness of unrighteousness in them that perish"" (Tertullian."
<G-vec00476-001-s211><consume.verbrauchen><de> """Und dann wird das gemeine aufgedeckt, das der Lord mit dem Geist seines Munds verbraucht, und zerstört mit der Helligkeit seines Kommens: sogar er, wer Kommen nachdem die Funktion von Satan, mit aller Energie und Zeichen und liegenwunder und mit allem deceivableness von Unrighteousness in ihnen ist, die"" umkommen (Tertullian."
<G-vec00476-001-s212><consume.verbrauchen><en> The 4-piece PvP healing set bonus has been modified to make Consumption no longer consume health when used with a stack of Force Surge, rather than restore 3% of max health over 6 seconds after use.
<G-vec00476-001-s212><consume.verbrauchen><de> Der 4-teilige PvP-Heilungs-Setbonus wurde verändert, damit Verbrauch keine Gesundheit mehr verbraucht, wenn es mit einem Stapel von Machtwoge verwendet wird, sondern stattdessen nach der Verwendung 3% der maximalen Gesundheit über 6 Sekunden wiederherstellt.
<G-vec00476-001-s213><consume.verbrauchen><en> The principle is also ideally suited to achieving cable redundancy when connecting Base Devices, and does not consume time slots or router switching capacity.
<G-vec00476-001-s213><consume.verbrauchen><de> Das Prinzip eignet sich auch hervorragend, um eine Kabelredundanz im Anschluss der Basisgeräte zu realisieren, bei der keinerlei Zeitschlitze oder Schaltkapazität des Routers verbraucht werden.
<G-vec00476-001-s214><consume.verbrauchen><en> Regardless of how quickly you will eventually lose the extra weight, just remember there are two things to focus on: How many calories you consume, how many calories you burn with exercise.
<G-vec00476-001-s214><consume.verbrauchen><de> Egal wie schnell Sie am Ende Ihrer zusätzliches Gewicht zu verlieren, nur nicht vergessen, es gibt zwei Dinge auf Folgendes konzentrieren: wie viele Kalorien man verbraucht und wie viele Kalorien verbrennen Sie durch Bewegung.
<G-vec00476-001-s222><consume.verschlingen><en> Completely unstructured experiments without a concrete application case can quickly lead to a situation where such projects consume incredible amounts of money.
<G-vec00476-001-s222><consume.verschlingen><de> Gänzlich unstrukturierte Experimente ohne konkreten Anwendungsfall können schnell dazu führen, dass solche Projekte Unmengen an Geldern verschlingen.
<G-vec00476-001-s223><consume.verschlingen><en> The Greek now looks round at the sun and notices to his and his daughter's terror that there is only a very narrow edge left of the sun, rises from his seat and thunders a curse up to the evil dragon that is now threatening to totally consume the sun.
<G-vec00476-001-s223><consume.verschlingen><de> Der Grieche sieht sich nun nach der Sonne um und bemerkt zu seinem und seiner Tochter Entsetzen, dass von der Sonne nur noch ein ganz schmaler Rand übrig ist, erhebt sich von seinem Sitze und donnert einen Fluch dem bösen Drachen empor, der die Sonne nun total zu verschlingen drohe.
<G-vec00476-001-s224><consume.verschlingen><en> I had an intense fear the light would consume me if I looked away and I was in absolute awe of what I was seeing.
<G-vec00476-001-s224><consume.verschlingen><de> Ich hatte eine intensive Furcht das Licht würde mich verschlingen wenn ich wegschauen würde und war in absoluter Ehrfurcht vor dem was ich sah.
<G-vec00476-001-s225><consume.verschlingen><en> For all the money Trump's new missile defense system will consume, the primary mechanism for ensuring that no missiles reach the United States in the event of war is the threat to destroy the entire landmass of a potential opponent with nuclear weapons.
<G-vec00476-001-s225><consume.verschlingen><de> Bei allem Geld, das Trumps neue Raketenabwehrsysteme verschlingen, werden im Kriegsfall hauptsächlich deshalb keine Raketen die USA erreichen, weil das Land jedes potenziellen Gegners sofort atomar zerstört werden wird.
<G-vec00476-001-s226><consume.verschlingen><en> PC workstations are expensive and can consume up to 50 percent of the IT budget at some companies.
<G-vec00476-001-s226><consume.verschlingen><de> PC-Arbeitsplätze sind teuer und verschlingen in manchen Unternehmen bis zu 50 Prozent der IT-Budgets.
<G-vec00476-001-s227><consume.verschlingen><en> That leaves only the development of two-stroke engines, but it seems to slowly consume all resources.
<G-vec00476-001-s227><consume.verschlingen><de> Bleibt nur die Entwicklung von Zweitaktmotoren, aber die scheint so langsam die letzten Mittel zu verschlingen.
<G-vec00476-001-s228><consume.verschlingen><en> The words of a wise man's mouth win him favor, but the lips of a fool consume him.
<G-vec00476-001-s228><consume.verschlingen><de> Die Worte aus dem Munde des Weisen bringen ihm Gunst; aber des Narren Lippen verschlingen ihn selbst.
<G-vec00476-001-s229><consume.verschlingen><en> Unfortunately, this creature needed a lot of fresh bodies to consume... so it started killing any kinds of life to regain strength, flesh and power.
<G-vec00476-001-s229><consume.verschlingen><de> Unglücklicherweise benötigt diese wieder erweckte Kreatur ständig frisches Leben, welches sie verschlingen muss, um Stärke zu gewinnen... darum begann Devon damit, sämtliche Formen von Leben zu töten, um es zu absorbieren.
<G-vec00476-001-s230><consume.vertilgen><en> But the judgment shall be set, and they shall take away his dominion, to consume and to destroy it to the end.
<G-vec00476-001-s230><consume.vertilgen><de> Aber das Gericht wird sich setzen und ihm die Herrschaft wegnehmen, um sie endgültig zu vertilgen und zu vernichten.
<G-vec00476-001-s231><consume.vertilgen><en> And then water and fire (symbols of the ardent faith and zeal of the Apostles of the End of Times) will purge the earth and consume all the works of men’s pride and all will be renewed.
<G-vec00476-001-s231><consume.vertilgen><de> Dann werden Wasser und Feuer (der Glaube und der Eifer der Apostel der letzten Zeiten) die Erde reinigen und alle Werke des menschlichen Hochmuts vertilgen und alles wird erneuert werden.
<G-vec00476-001-s232><consume.vertilgen><en> If I were to go up into the middle of you for one moment, I would consume you.
<G-vec00476-001-s232><consume.vertilgen><de> Wo ich nur einen Augenblick mit dir hinaufzöge, würde ich dich vertilgen.
<G-vec00476-001-s233><consume.vertilgen><en> You may not consume them at once, lest the animals of the field increase on you.
<G-vec00476-001-s233><consume.vertilgen><de> Du darfst sie aber nicht zu rasch vertilgen, sonst wüchse über dich das Wild des Feldes.
<G-vec00476-001-s234><consume.vertilgen><en> 16 Thou shalt consume all the people, which the Lord thy God will deliver to thee.
<G-vec00476-001-s234><consume.vertilgen><de> 16 Du wirst alle Völker vertilgen, die der HERR, dein Gott, dir geben wird.
<G-vec00476-001-s235><consume.vertilgen><en> 11 The Lord shall be terrible upon them, and shall consume all the gods of the earth: and they shall adore him every man from his own place, all the islands of the Gentiles.
<G-vec00476-001-s235><consume.vertilgen><de> 11 Heilig wird über ihnen der HERR sein; denn er wird alle Götter auf Erden vertilgen, und es sollen ihn anbeten alle Inseln der Heiden, ein jeder an seiner Stätte.
<G-vec00476-001-s236><consume.vertilgen><en> Then the Water and the Fire (the faith and zeal of the Apostles of the End of Times) will purge the earth and consume all the works of men's pride and all will be renewed.
<G-vec00476-001-s236><consume.vertilgen><de> Dann werden Wasser und Feuer (der Glaube und der Eifer der Apostel der letzten Zeiten) die Erde reinigen und alle Werke des menschlichen Hochmuts vertilgen und alles wird erneuert werden.
<G-vec00476-001-s237><consume.vertilgen><en> The village mandarin himself took on the responsibility of my meals, and every lunch time and evening I was taken in a sort of procession to him, where I had to consume his boiled chickens, ducks, and pork roasts.
<G-vec00476-001-s237><consume.vertilgen><de> Der Dorfmandarin selbst übernahm die Sorge für meinen Tisch, und jeden Mittag und jeden Abend wurde ich in einer Art Procession zu ihm geleitet, wo ich seine gesottenen Hühner und Enten und Ferkelbraten zu vertilgen hatte.
<G-vec00476-001-s238><consume.vertilgen><en> 26 But the judgment shall be set, and they shall take away his dominion, to consume and to destroy it to the end.
<G-vec00476-001-s238><consume.vertilgen><de> 26 Aber das Gericht wird sich setzen und ihm die Gewalt wegnehmen, sie endgültig vertilgen und vernichten.
<G-vec00476-001-s248><consume.verzehren><en> Oh, if only the earth would open up or fire would fall from heaven and consume the evil.
<G-vec00476-001-s248><consume.verzehren><de> Ach, würde sich doch die Erde auftun oder Feuer vom Himmel fallen und das Böse verzehren.
<G-vec00476-001-s249><consume.verzehren><en> "Eventually these temptations ""hatch"" to become the sin maggots that that consume us from within."
<G-vec00476-001-s249><consume.verzehren><de> "Irgendwann ""schlüpfen"" aus diesen Versuchungen ""Maden"" der Sünde, die uns von innen heraus verzehren."
<G-vec00476-001-s250><consume.verzehren><en> And yet it can only be offered what it had acquired for itself on earth, it cannot be moved into blissful realms to which it had never aspired nor can it be given light because this would consume the soul due to its immature state.
<G-vec00476-001-s250><consume.verzehren><de> Und doch kann ihr nur das geboten werden, was sie sich erworben hat auf Erden, sie kann nicht in glückselige Sphären versetzt werden, die sie niemals anstrebte, und ihr kann auch kein Licht geschenkt werden, weil dieses sie verzehren würde in ihrem unreifen Zustand.
<G-vec00476-001-s251><consume.verzehren><en> BgVV, therefore, recommends that children in principle should not consume AFA algae products. It is recommended that adults restrict their consumption of AFA algae products.
<G-vec00476-001-s251><consume.verzehren><de> Das BgVV rät deshalb, dass Kinder AFA-Algenprodukte grundsätzlich nicht verzehren sollten Erwachsenen wird eine Einschränkung des Konsums von AFA-Algenprodukten empfohlen.
<G-vec00476-001-s252><consume.verzehren><en> Trying to consume her mouth, my tongue darts into hers.
<G-vec00476-001-s252><consume.verzehren><de> Ich versuche, ihren Mund zu verzehren, meine Zunge schnellt in ihren Mund hinein.
<G-vec00476-001-s253><consume.verzehren><en> All drinks that you consume during your trip on board ship will be booked to your cabin and only billed at the end of the week.
<G-vec00476-001-s253><consume.verzehren><de> Alle Getränke, die Sie während der Reise an Bord verzehren, werden auf Ihre Kabine gebucht und erst am Ende der Woche abgerechnet.
<G-vec00476-001-s254><consume.verzehren><en> The flames of my Mercy consume me.
<G-vec00476-001-s254><consume.verzehren><de> Die Flammen meines Erbarmens verzehren mich.
<G-vec00476-001-s255><consume.verzehren><en> Instead of the Lord’s Supper, which we celebrate as a memorial meal in line with the Lord’s command, they have introduced an occult magical Transubstatiation, in which the believers allegedly consume the body of Christ.
<G-vec00476-001-s255><consume.verzehren><de> Sie hat statt dem Abendmahl, welches wir nach dem Gebot des Herrn als Gedächtnismahl feiern sollen, eine okkulte Zauberwandlung eingeführt, bei der die Gläubigen angeblich den Leib Christi verzehren.
<G-vec00476-001-s256><consume.verzehren><en> """Still He let the light shine more and more brightly through eternities, for He reasoned that thereby the light would consume and weaken itself, allowing Him to be again fully strengthened in His nature."
<G-vec00476-001-s256><consume.verzehren><de> Dennoch aber ließ Er das Licht Ewigkeiten hindurch heller und heller leuchten, da Er also bedachte, als müsse sich dadurch das Licht verzehren und somit schwächen vor Ihm, auf dass Er in Seiner Wesenheit daraus vollends wieder erstarke.
<G-vec00476-001-s257><consume.verbrauchen><en> During slaughter the Salmonella from infected animals can migrate to the meat and then constitute an infection risk for the people who consume the meat and meat products.
<G-vec00476-001-s257><consume.verbrauchen><de> Bei der Schlachtung können die Salmonellen von infizierten Tieren auf das Fleisch gelangen und ein Infektionsrisiko für den Menschen darstellen, der das Fleisch und daraus hergestellte Produkte verzehrt.
<G-vec00476-001-s258><consume.verbrauchen><en> It is very important for your patient to consume all the fat in the stock and off the bones as these fats are essential for the healing process.
<G-vec00476-001-s258><consume.verbrauchen><de> Es ist sehr wichtig, dass der Patient die ganzen Fette im Sud und von den Knochen verzehrt, denn diese Fette sind für den Heilungsprozess von wesentlicher Bedeutung.
<G-vec00476-001-s259><consume.verbrauchen><en> Both A and B consume new labor-power in the second period of 5 weeks and expend a new capital of 500 p. st. for the payment of this labor-power.
<G-vec00476-001-s259><consume.verbrauchen><de> Sub A wie sub B wird in der zweiten Periode von 5 Wochen neue Arbeitskraft verzehrt und ein neues Kapital von 500 £ in Zahlung dieser Arbeitskraft verausgabt.
<G-vec00476-001-s260><consume.verbrauchen><en> Nobody knows exactly how much it is safe to consume, or how often.
<G-vec00476-001-s260><consume.verbrauchen><de> Niemand weiß genau, wie viel davon ist unbedenklich verzehrt werden, oder wie oft.
<G-vec00476-001-s261><consume.verbrauchen><en> The feeding pattern is often quite striking as the larvae do not consume the whole leaves.
<G-vec00476-001-s261><consume.verbrauchen><de> Die Fraßspuren sind oft recht auffällig, da die Blätter nicht ganz verzehrt werden.
<G-vec00476-001-s262><consume.verbrauchen><en> 49:27 And I will kindle a fire in the wall of Damascus, and it shall consume the palaces of Ben-hadad.
<G-vec00476-001-s262><consume.verbrauchen><de> 49:27 Ich lege Feuer an die Mauer von Damaskus; / es verzehrt die Paläste Ben-Hadads.
<G-vec00476-002-s038><consume.aufnehmen><en> Amino acids are the building blocks of the proteins we have to consume every day through food in order for our bodies to function well.
<G-vec00476-002-s038><consume.aufnehmen><de> Aminosäuren Aminosäuren sind die Bausteine der Eiweiße, die wir über die Nahrung täglich aufnehmen müssen, damit unser Körper optimal funktioniert.
<G-vec00476-002-s040><consume.aufnehmen><en> The ADI is a toxicological reference value that indicates how much glyphosate we can consume daily (for our entire lives) with food, without any effect on our body.
<G-vec00476-002-s040><consume.aufnehmen><de> Die akzeptable tägliche Aufnahmemenge ist ein toxikologischer Referenzwert, der angibt, wie viel Glyphosat wir täglich (unser Leben lang) mit der Nahrung aufnehmen dürfen, ohne dass dies Auswirkungen auf unseren Körper hat.
<G-vec00476-002-s041><consume.aufnehmen><en> It may help to calculate how many calories you need to consume to lose weight before you get started.
<G-vec00476-002-s041><consume.aufnehmen><de> Es hilft sicher zu berechnen, wie viele Kalorien du aufnehmen darfst, damit du abnimmst.
<G-vec00476-002-s042><consume.aufnehmen><en> I really like the taste of these fruit pouches, and at the same time it allows me to consume the optimal amount of carbohydrates for my needs.
<G-vec00476-002-s042><consume.aufnehmen><de> Die Obstbeutel schmecken mir wirklich gut und ich kann gleichzeitig die für mich optimale Menge an Kohlenhydraten aufnehmen.
<G-vec00476-002-s043><consume.aufnehmen><en> The temperature of the food or water you consume is not a factor in regard to the impression of a thought since it is only the Akasha you are working with.
<G-vec00476-002-s043><consume.aufnehmen><de> Die Temperatur der Speise oder des Wassers das Sie aufnehmen ist nicht ausschlaggebend für das Anhaengen der Gedanken, da Sie nur mit dem Akasha arbeiten.
<G-vec00476-002-s044><consume.aufnehmen><en> Due to its properties, oilcake can bring tremendous health benefits, as a result of which it can consume even moderate amounts of allergies.
<G-vec00476-002-s044><consume.aufnehmen><de> Ölkuchen kann aufgrund seiner Eigenschaften enorme gesundheitliche Vorteile mit sich bringen, so dass er auch geringe Mengen an Allergien aufnehmen kann.
<G-vec00476-002-s045><consume.aufnehmen><en> When you are thirsty; you can consume only a limited quantity of water.
<G-vec00476-002-s045><consume.aufnehmen><de> Wenn du durstig bist, kannst du nur eine begrenzte Menge an Wasser aufnehmen.
<G-vec00476-002-s302><consume.verschlingen><en> Possibly the most important is your ability to consume others - you can absorb their intelligence, abilities, weapons and physical form in matter of seconds.
<G-vec00476-002-s302><consume.verschlingen><de> Die wichtigste deiner Fähigkeiten besteht darin, andere zu verschlingen - das heißt, du absorbierst in Sekundenschnelle ihr Wissen, ihr Können, ihre Waffen und ihre physische Form.
<G-vec00476-002-s303><consume.verschlingen><en> Finding new ways to grow the economy will only consume what is left of our wealth.
<G-vec00476-002-s303><consume.verschlingen><de> Finden wir neue Wege, die Wirtschaft zum Wachsen zu bringen, wird das den Rest verschlingen, der vom Reichtum noch übrig ist.
<G-vec00476-002-s305><consume.verschlingen><en> Economic cycles can have a big impact on the environment and consume large amounts of energy.
<G-vec00476-002-s305><consume.verschlingen><de> Wirtschaftszyklen können große Auswirkungen auf die Umwelt haben und große Mengen Energie verschlingen.
<G-vec00476-002-s306><consume.verschlingen><en> Smite your enemies with magical storms, melt their armour, sap their fighting spirit or bolster your own forces with devastating spells that split the sky and consume the battlefield.
<G-vec00476-002-s306><consume.verschlingen><de> Zerschmettere deine Feinde mit magischen Stürmen, lass ihre Rüstung schmelzen, raube ihren Kampfesmut oder stärke deine eigenen Truppen mit vernichtenden Zaubern, die den Himmel zerfetzen und das Schlachtfeld verschlingen.
<G-vec00476-002-s308><consume.verschlingen><en> In the frozen northern wastes, a sinister blight has awoken and now stands ready to consume everything in its path.
<G-vec00476-002-s308><consume.verschlingen><de> In den gefrorenen Weiten des Nordens ist eine finstere Plage erwacht und schickt sich nun an, alles zu verschlingen, was ihr in die Quere kommt.
