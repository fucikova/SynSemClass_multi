<G-vec00468-001-s073><breed.brüten><en> The skylarks that breed in Estonia still manage quite well, they are more than half a million pairs.
<G-vec00468-001-s073><breed.brüten><de> Die Feldlerchen die in Estland brüten kommen noch gut zurecht, es gibt mehr als eine halbe Millionen Paare.
<G-vec00468-001-s074><breed.brüten><en> Puffins come ashore only to breed, while other times they are exclusively on the sea.
<G-vec00468-001-s074><breed.brüten><de> Papageientaucher kommen nur zum Brüten an Land, während der übrigen Zeit sind sie ausschließlich auf dem Meer.
<G-vec00468-001-s075><breed.brüten><en> Hundreds of thousands of sea birds breed and nest on the island and also near Hiddensee.
<G-vec00468-001-s075><breed.brüten><de> Hunderttausende Seevögel brüten auf den Inseln und auch bei Hiddensee.
<G-vec00468-001-s076><breed.brüten><en> When insects breed in the nests of birds and animals in temperate and northern latitudes, the pupae that were in the nest after the owners left it will languish in this species until the next year, when the inhabitants reappear in the shelter.
<G-vec00468-001-s076><breed.brüten><de> Wenn sich Insekten in den Nestern von Vögeln und Tieren in gemäßigten und nördlichen Breiten brüten, werden die Puppen, die sich nach dem Verlassen der Besitzer im Nest befanden, bis zum nächsten Jahr, in dem die Bewohner im Tierheim wieder auftauchen, in dieser Art geschlängert.
<G-vec00468-001-s077><breed.brüten><en> Many of its 250 endemic species of cichlids are mouthbreeders: To protect their offspring and prevent other fish from devouring it, cichlids carry and breed their eggs in their mouths.
<G-vec00468-001-s077><breed.brüten><de> Viele seiner 250 endemischen Buntbarscharten sind Maulbrüter: Zum Schutz ihrer Nachkommen nehmen sie ihre Eier ins Maul, damit sie nicht von anderen Fischen gefressen werden, und brüten ihre Larven im Maul aus.
<G-vec00468-001-s078><breed.brüten><en> Of the common gulls that breed on the Matsalu islets, the adult birds leave immediately after the nesting period and head straight for their wintering areas.
<G-vec00468-001-s078><breed.brüten><de> Von den Sturmmöwen, die auf der Insel Matsalu brüten, fliegen die Altvögel sofort nach der Brutzeit weg und direkt in die Richtung ihres Überwinterungsgebietes.
<G-vec00468-001-s079><breed.brüten><en> Keeping close to civilisation on Cape Peninsula they even breed in the gardens of villas located in the suburbs of Cape Town.
<G-vec00468-001-s079><breed.brüten><de> Auf der Kap-Halbinsel im Stadtgebiet von Kapstadt sind sie Kulturfolger, die sogar in Hausgärten von Villen brüten.
<G-vec00468-001-s080><breed.brüten><en> Thanks to the plenty of space the Herp Nursery offer, this is a big advantage as you can incubate different species with different temperature requirements or breed for specific sexes and all in one device!
<G-vec00468-001-s080><breed.brüten><de> Aufgrund des großen Platzangebot im Herp Nursery II ist das ein Riesenvorteil, so kann man in dem Gerät auch problemlos Arten mit unterschiedlichen Temperaturbedürfnissen bebrüten oder auf besondere Geschlechter brüten.
<G-vec00468-001-s081><breed.brüten><en> Here there are only individuals that accidentally fell from the body or head, and there are no permanent populations that breed in bed.
<G-vec00468-001-s081><breed.brüten><de> Hier gibt es nur Personen, die versehentlich vom Körper oder Kopf gefallen sind, und es gibt keine dauerhaften Populationen, die im Bett brüten.
<G-vec00468-001-s082><breed.brüten><en> A few hundred pairs of black guillemot (Cepphus grylle) also breed here.
<G-vec00468-001-s082><breed.brüten><de> Auch einige Paare der Gryllteiste (Cepphus grylle) brüten auf Bonden.
<G-vec00468-001-s083><breed.brüten><en> The Siberian cat breed is a large cat, weighing up to twenty pounds, with an insulating coat of slightly oily hair.
<G-vec00468-001-s083><breed.brüten><de> Die Sibirien Katze brüten ist ein erklecklich Katze, wiegend bis zu zwanzig Pfunde, mit ein isolierend beschlagen über etwas kleiner ölig Haar.
<G-vec00468-001-s084><breed.brüten><en> Various songbirds and falcons breed on the high trees or in coves.
<G-vec00468-001-s084><breed.brüten><de> So brüten verschiedene Singvögel ebenso wie Falken auf hohen Bäumen oder in Felsnischen.
<G-vec00468-001-s085><breed.brüten><en> Hundreds of bird species come here every year to breed.
<G-vec00468-001-s085><breed.brüten><de> Jährlich kommen hunderte Vögel hierher, um zu brüten.
<G-vec00468-001-s086><breed.brüten><en> Terns breed in colonies and dive for small fish in coastal waters.
<G-vec00468-001-s086><breed.brüten><de> Seeschwalben brüten in Kolonien und tauchen nach kleinen Fischen in den Küstengewässern.
<G-vec00468-001-s087><breed.brüten><en> These birds will not breed yet this year.
<G-vec00468-001-s087><breed.brüten><de> Diese Vögel werden in diesem Jahr noch nicht brüten.
<G-vec00468-001-s088><breed.brüten><en> The European Rollers, Redd-footed and Lesser Kestrels, Bee-eater, Shrikes, Warbler and some flycatchers are now here, many of them are here to breed and create new populations.
<G-vec00468-001-s088><breed.brüten><de> Jetzt sind die Blauracken, Bienenfresser, Würger, Warbler und einige Schnäpper gekommen, viele von Ihnen werden hier brüten und neue Populationen schaffen.
<G-vec00468-001-s089><breed.brüten><en> As of 2010, around 15,000 pairs breed in the Netherlands, of which around 7000 in the Dutch wadden region.
<G-vec00468-001-s089><breed.brüten><de> Momentan brüten rund 15.000 Paare in den Niederlanden, davon etwa 7000 im niederländischen Wattenmeer.
<G-vec00468-001-s090><breed.brüten><en> About fifty bird species breed on Ameland, from the herring gull to the pigeon hole and from the harrier to the meadow pipit.
<G-vec00468-001-s090><breed.brüten><de> Auf Ameland brüten über fünfzig Vogelarten, von der Silbermöwe zur Hohltaube und von Rohrweihe zur Pieper.
<G-vec00468-001-s091><breed.brüten><en> The only inhabitants on these islands are birds who stopped by on their way to the north or breed there in the nature sanctuary.
<G-vec00468-001-s091><breed.brüten><de> Die einzigen Bewohner auf diesen Inseln sind Vögel, die dort auf ihren Vogelwanderungen Station machen oder brüten.
<G-vec00468-001-s092><breed.sich_fortpflanzen><en> This plant can breed: shanks, seeds and air layers.
<G-vec00468-001-s092><breed.sich_fortpflanzen><de> Diese Pflanze kann sich fortpflanzen: von den Ablegern, den Samen und luftig otwodkami.
<G-vec00468-001-s093><breed.sich_fortpflanzen><en> Even in the case of animals which breed slowly and unite for each birth, we must not assume that the effects of natural selection will always be immediately overpowered by free intercrossing; for I can bring a considerable body of facts, showing that within the same area, varieties of the same animal may long remain distinct, from haunting different stations, from breeding at slightly different seasons, or from varieties of the same kind preferring to pair together.
<G-vec00468-001-s093><breed.sich_fortpflanzen><de> Selbst bei Thieren mit langsamer Vermehrung, die sich zujeder Fortpflanzung paaren, dürfen wir die Wirkungen der Kreu-zung auf Verzögerung der natürlichen Zuchtwahl nicht über-schätzen; denn ich kann eine lange Liste von Thalsachen bei-bringen, woraus sich ergibt, dass innerhalb eines und desselbenGebietes Varietäten der nämlichen Thierart lange unterschiedenbleiben können, weil sie verschiedene Stationen innehaben, inetwas verschiedener Jahreszeit sich fortpflanzen, oder nur einerleiVarietäten sich unter einander zu paaren vorziehen.
<G-vec00468-001-s094><breed.sich_fortpflanzen><en> In April 2016, the Bird Ecological Environment Research Institute was able to successfully breed the birds.
<G-vec00468-001-s094><breed.sich_fortpflanzen><de> Im April 2016 konnte das ökologische Umweltforschungsinstitut für Vögel die Vögel erfolgreich fortpflanzen.
<G-vec00468-001-s095><breed.sich_fortpflanzen><en> Species protection projects all over Europe have so far faced the problem that European minks are difficult to breed in zoos.
<G-vec00468-001-s095><breed.sich_fortpflanzen><de> Artenschutzprojekte in ganz Europa standen bisher vor dem Problem, dass sich Europäische Nerze ungern im Zoo fortpflanzen.
<G-vec00468-001-s096><breed.sich_fortpflanzen><en> To enable fish to breed they need high water quality and appropriate creeks and shores.
<G-vec00468-001-s096><breed.sich_fortpflanzen><de> Damit Fische sich fortpflanzen können, bedarf es an hoher Wasserqualität und geeigneten Bächen und Flussufern.
<G-vec00468-001-s097><breed.sich_fortpflanzen><en> This allows them to mature and breed as normal.
<G-vec00468-001-s097><breed.sich_fortpflanzen><de> Daher können sich die Tiere normal entwickeln und fortpflanzen.
<G-vec00468-001-s117><breed.züchten><en> Before the pinkies can be processed on our equipment, they have to be perfectly clean or in other words: the food which was used to breed the larva shouldn´t be present anymore in them.
<G-vec00468-001-s117><breed.züchten><de> Bevor die Pinky-Maden in unseren Anlagen verarbeitet werden können, müssen sie perfekt gereinigt sein, d.h.: das Futter, auf dem die Larven gezüchtet werden, darf nicht mehr in der Larve vorhanden sein.
<G-vec00468-001-s118><breed.züchten><en> As we approach from Cáceres, we pass through fields and wooded pastures which serve as grazing for fighting bulls, and the distinctive Iberico breed of pig from which the famous cured hams and sausages of Extremadura are made.
<G-vec00468-001-s118><breed.züchten><de> Wer sich der Stadt von Cáceres aus nähert, der gelangt durch Felder und Weiden, auf denen Kampfstiere grasen und iberische Schweine gezüchtet werden, die später zu den berühmten Schinken- und Wurstwaren aus Extremadura verarbeitet werden.
<G-vec00468-001-s119><breed.züchten><en> Some fishes, such as eels, are always captured in the wild because it is not possible to breed them in captivity.
<G-vec00468-001-s119><breed.züchten><de> Manche Fische, wie zum Beispiel Aale, werden immer in freier Wildbahn gefangen, da sie nicht in Gefangenschaft gezüchtet werden können.
<G-vec00468-001-s120><breed.züchten><en> This breed was created to live in apartments.
<G-vec00468-001-s120><breed.züchten><de> Sie wurde für ein Leben in der Wohnung gezüchtet.
<G-vec00468-001-s121><breed.züchten><en> One does not breed with them.
<G-vec00468-001-s121><breed.züchten><de> Mit ihnen wird nicht gezüchtet.
<G-vec00468-001-s261><breed.vermehren><en> From April to October they live and breed in simple summer burrows.
<G-vec00468-001-s261><breed.vermehren><de> Von April bis Oktober leben und vermehren sie sich in einfachen Sommerbauen.
<G-vec00468-001-s262><breed.vermehren><en> Probably they are one of the most numerous mammals in Europe although they do not breed in winter.
<G-vec00468-001-s262><breed.vermehren><de> Wahrscheinlich sind sie eines der zahlreichsten Säugetiere in Europa, obwohl sie sich im Winter nicht vermehren.
<G-vec00468-001-s263><breed.vermehren><en> But as all creatures they want to breed for sure.
<G-vec00468-001-s263><breed.vermehren><de> Aber wie alle Lebewesen wollen auch sie sich vermehren.
<G-vec00468-001-s264><breed.vermehren><en> Since dogs breed rather uncontrolled in Sri Lanka, they increasingly pose a threat for the last wildlife animals.
<G-vec00468-001-s264><breed.vermehren><de> Da sich Hunde in Sri Lanka weitgehend unkontrolliert vermehren stellen sie mehr und mehr eine Bedrohung für die letzten freilebenden Tiere dar.
<G-vec00468-001-s265><breed.vermehren><en> Bedbugs love to breed and live within the cracks of furniture, bed posts, and headboards.
<G-vec00468-001-s265><breed.vermehren><de> Betwanzen leben und vermehren sich gern in den Spalten von Möbeln, Bettpfosten und Kopfbrettern.
<G-vec00468-001-s266><breed.vermehren><en> 22. Animal numbers will shrink in the next few years as instinctively they will breed less often and produce fewer offspring.
<G-vec00468-001-s266><breed.vermehren><de> 22) Die Tierzahlen werden in den nächsten Jahren schrumpfen, da sie sich instinktiv weniger vermehren und weniger Nachwusch in die Welt setzen werden.
<G-vec00468-001-s267><breed.vermehren><en> But slaves breed very slowly in captivity and so the only way a sufficient supply of slaves can be guaranteed is through continuous warfare.
<G-vec00468-001-s267><breed.vermehren><de> Aber Sklaven vermehren sich in der Gefangenschaft nur sehr langsam und so konnte die ausreichende Versorgung mit Sklaven nur durch ständige Kriege garantiert werden.
<G-vec00468-001-s268><breed.vermehren><en> This very attractive variant of the native Bitterling is just as easy to keep and to breed as the normal coloured kinds of this species.
<G-vec00468-001-s268><breed.vermehren><de> Diese sehr attraktive Variante des einheimischen Bitterlings ist ebenso einfach zu halten und zu vermehren wie die normal gefärbten Vertreter dieser Art.
<G-vec00468-001-s269><breed.vermehren><en> No time for bacterias to breed in the warm water.
<G-vec00468-001-s269><breed.vermehren><de> Keine Zeit für Bakterien sich im warmen Wasser zu vermehren.
<G-vec00468-001-s270><breed.vermehren><en> Females start to breed when they reach sexual maturity, typically in their second year.
<G-vec00468-001-s270><breed.vermehren><de> Weibliche Beutelteufel sind in ihrem zweiten Lebensjahr geschlechtsreif und beginnen ab diesem Zeitpunkt, sich zu vermehren.
<G-vec00468-001-s271><breed.vermehren><en> Rainbow trout are not native to Scotland and they do not breed in our lochs or rivers.
<G-vec00468-001-s271><breed.vermehren><de> Regenbogenforellen sind in Schottland nicht heimisch und sie vermehren sich in unseren Seen und Flüssen nicht.
<G-vec00468-001-s272><breed.vermehren><en> Considering the fact that young bugs can breed only a month after hatching from eggs, their number in an apartment is growing exponentially.
<G-vec00468-001-s272><breed.vermehren><de> In Anbetracht der Tatsache, dass sich junge Käfer nur einen Monat nach dem Schlüpfen aus Eiern vermehren können, wächst ihre Zahl in einer Wohnung exponentiell.
<G-vec00468-001-s292><breed.züchten><en> “The number of stray animals continues to rise because people breed uncontrollably.
<G-vec00468-001-s292><breed.züchten><de> „Die Zahl der streunenden Tiere steigt immer weiter, weil die Leute unkontrolliert züchten.
<G-vec00468-001-s293><breed.züchten><en> When it is well soaked with chemistry, it is possible to breed a fire in this place, and the whole underground and above-ground parts of the tree completely burn out.
<G-vec00468-001-s293><breed.züchten><de> Wenn es gut mit Chemie getränkt wird, ist es möglich, einen Brand an diesem Ort zu züchten, und die ganze unterirdischen und oberirdischen Teile des Baumes vollständig ausbrennen.
<G-vec00468-001-s294><breed.züchten><en> Kondrat promised us to breed Rkatsiteli as the Kakhetian vine deserves and that is not on the ground.
<G-vec00468-001-s294><breed.züchten><de> KONDRAT uns zu züchten Rkatsiteli als Kakhetian Wein verdient, und das ist nicht auf dem Boden.
<G-vec00468-001-s295><breed.züchten><en> Woodlice themselves in suitable conditions breed in large quantities and serve as food for many species of insects, birds and reptiles.
<G-vec00468-001-s295><breed.züchten><de> Waldlilien selbst züchten sich unter geeigneten Bedingungen in großen Mengen und dienen als Nahrung für viele Insektenarten, Vögel und Reptilien.
<G-vec00468-001-s296><breed.züchten><en> Although we should not exaggerate it with ethical intentions, there is to breed no reason such hybrid for not scientific purposes.
<G-vec00468-001-s296><breed.züchten><de> Obwohl man es mit ethischen Vorsätzen nicht übertreiben sollte, gibt es keinen Grund solche Hybriden für nicht wissenschaftliche Zwecke zu züchten.
<G-vec00468-001-s297><breed.züchten><en> I decided to breed Airedale Terriers because of my wish to make this wonderful breed, which has given me pleasure and stood by me for so many years, more accessible to people in Austria and maybe also in other countries.
<G-vec00468-001-s297><breed.züchten><de> Ich habe beschlossen, den Airedale Terrier zu züchten, da es mein Wunsch ist, diese wundervolle Rasse, die mir bereits über viele Jahre hinweg so viel Freude bereitet und mir stets treu zur Seite steht, den Menschen in Österreich und vielleicht auch anderen Ländern näher zu bringen.
<G-vec00468-001-s298><breed.züchten><en> Nuh worry cause you man a give you nuff a wey you want so definitely tell a gal sey who nuh vee nuh vaa, nuh worry cause you man a give you nuff a wey you need to how unno a live gal a nuh nothing if you breed.
<G-vec00468-001-s298><breed.züchten><de> Nuh Sorge führen, dass Sie ein geben Sie den Menschen nuff ein Wey Sie wollen also auf jeden Fall eine gal Sey sagen, wer nuh VEE nuh vaa, nuh führen, dass Sie sich sorgen ein geben Sie einen Wey nuff Menschen Sie brauchen, wie UNNO eine Live-gal ein nuh nichts wenn Sie züchten.
<G-vec00468-001-s299><breed.züchten><en> We breed according to the breeding rules and guidelines of the F.C.I.
<G-vec00468-001-s299><breed.züchten><de> Wir züchten nach den Zuchtbestimmungen und Richtlinien des F.C.I.
<G-vec00468-001-s300><breed.züchten><en> The new consortium will increase capacity to breed crops with specific traits, leading to plants that are adapted to different environments.
<G-vec00468-001-s300><breed.züchten><de> Das neue Konsortium wird die Möglichkeiten ausbauen, Nutzpflanzen mit speziellen Eigenschaften zu züchten, um diese noch besser an verschiedene Umweltbedingungen anzupassen, wie zum Beispiel verbesserte Nährstoffeigenschaften, Toleranz gegen Trockenheit, Hitze oder Hochwasser.
<G-vec00468-001-s301><breed.züchten><en> For grey parrots as well as birds, wich breed, moult or are younger than 5 months we recommend Dr. Harrisons breeding nutrition.
<G-vec00468-001-s301><breed.züchten><de> Für Graupapageien sowie Vögel, die züchten, sich mausern oder jünger als 5 Monate sind empfehlen wir Ihnen Dr. Harrisons Zuchtfutter.
<G-vec00468-001-s302><breed.züchten><en> Our main breeding interest is to breed healthy and vital cats.
<G-vec00468-001-s302><breed.züchten><de> Unser Hauptinteresse ist es, gesunde und vitale Katzen zu züchten.
<G-vec00468-001-s303><breed.züchten><en> Aquatic plant growers often make use of this circumstance and breed the plants emerged (= as a land form).
<G-vec00468-001-s303><breed.züchten><de> Diese Eigenschaft machen sich Wasserpflanzen- züchter häufig zu Nutze und züchten die Pflanzen emers (= als Landform).
<G-vec00468-001-s304><breed.züchten><en> In the year 1987I stumbled on the world cat and i have started to breed
<G-vec00468-001-s304><breed.züchten><de> Im Jahr 1987 stolperte ich in die Welt der Katzen und begann, weiße Perser zu züchten.
<G-vec00468-001-s305><breed.züchten><en> It was not easy for Evelyn Mague to breed Somalis, because the Abyssinian breeders considered the longhaired Abyssinians to be of low quality and sorted the longhaired kittens out.
<G-vec00468-001-s305><breed.züchten><de> Es war für Evelyn Mague nicht einfach, Somali zu züchten, weil die Abessinierzüchter diese langhaarigen Abessinier für minderwertig hielten und sie aus der Zucht aussortierten.
<G-vec00468-001-s306><breed.züchten><en> But there are many museums, the famous zoo and farms which breed rare interesting animals.
<G-vec00468-001-s306><breed.züchten><de> Aber es gibt viele Museen, den berühmten Zoo und Bauernhöfe, die seltene interessante Tiere züchten.
<G-vec00468-001-s307><breed.züchten><en> This is not very often and makes it all the more difficult to successfully breed elephants in zoos.
<G-vec00468-001-s307><breed.züchten><de> Dies ist sehr wenig und macht es umso schwerer in Zoos erfolgreich Elefanten zu züchten.
<G-vec00468-001-s308><breed.züchten><en> Some growers like to breed and cross their ownautoflowerseeds.
<G-vec00468-001-s308><breed.züchten><de> Einige Grower züchten und kreuzen ihre eigenen selbstblühenden Cannabis-Samen gerne selbst.
<G-vec00468-001-s309><breed.züchten><en> In JiyoPets you have to choose an avatar and then explore the wildsands capture, tame & breed creatures from around the worlds.
<G-vec00468-001-s309><breed.züchten><de> In JiyoPets müssen Sie einen Avatar wählen und dann erkunden Sie die wildsands Capture, zahm & züchten Tiere aus der ganzen Welt.
<G-vec00468-001-s310><breed.züchten><en> The farmers in the Elbe-Elster-Land breed mixes of breeds of horses residing in the states of Brandenburg and Saxony.
<G-vec00468-001-s310><breed.züchten><de> Die Bauern im Elbe-Elster-Land züchten Mischungen der ansässigen Pferderassen in den Bundesländern Brandenburg und Sachsen.
<G-vec00468-002-s260><breed.vermehren><en> The fact that they breed only during certain seasons, so do the breaks.
<G-vec00468-002-s260><breed.vermehren><de> Die Tatsache, dass Sie vermehren sich nur in bestimmten Jahreszeiten, so dass es immer noch Pausen machen.
<G-vec00468-002-s261><breed.vermehren><en> This method, used in India and Turkey, means that stray dogs and cats that can't be put up for adoption won't breed and make the problem worse.
<G-vec00468-002-s261><breed.vermehren><de> Diese Methode, die aktuell schon in Indien und der Türkei eingesetzt wird, ermöglicht es, die Hunde in Freiheit leben zu lassen, ohne dass die Gefahr besteht, dass diese sich ins Uferlose vermehren.
<G-vec00468-002-s262><breed.vermehren><en> If you've given them enough food, water, and heat, and your crickets are generally happy, they should breed profusely.
<G-vec00468-002-s262><breed.vermehren><de> Wenn du ihnen genügend Futter, Wasser und Wärme anbietest und deine Grillen glücklich sind, werden sie sich reichlich vermehren.
<G-vec00468-002-s264><breed.vermehren><en> Catching too small and young shrimp would destroy the biological equilibrium because they cannot breed’, says Chris and continues: ‘Fish and jellyfish are also removed.
<G-vec00468-002-s264><breed.vermehren><de> Zu kleine und junge Krabben würden das biologische Gleichgewicht stören, weil sie sich nicht mehr vermehren können,” erklärt Chris und fährt fort: „Und auch Fische und Quallen werden aussortiert.
<G-vec00468-002-s265><breed.vermehren><en> This way any new fleas your pet might pick up from the environment outside your home should be eliminated before they have a chance to breed.
<G-vec00468-002-s265><breed.vermehren><de> Auf diese Weise sollten alle neuen Flöhe, die ein Tier außerhalb des Hauses aufsammelt, vernichtet werden, bevor sie die Chance erhalten, sich zu vermehren.
<G-vec00468-002-s119><breed.züchten><en> Research your dog’s breed on through the breed’s national parent club to find out more about what traits your dog should possess in order to breed.
<G-vec00468-002-s119><breed.züchten><de> Erforsche die Rasse deines Hundes durch den europäischen Rassezuchtverein, um mehr darüber herauszufinden, welche Eigenschaften dein Hund besitzen sollte, um gezüchtet zu werden.
<G-vec00468-002-s120><breed.züchten><en> Were breed in the county Bentheim and Lingen (Emsland) .
<G-vec00468-002-s120><breed.züchten><de> Wurden in der Grafschaft Bentheim und Lingen (Emsland) gezüchtet.
<G-vec00468-002-s121><breed.züchten><en> Avella B was breed in Germany (Peter Biebrich) and bought from Verden, Hanoverian auction at 2013.
<G-vec00468-002-s121><breed.züchten><de> Avella B wurde in Deutschland gezüchtet (Peter Biebrich) und kaufte 2013 in Verden, Hannover.
<G-vec00468-002-s122><breed.züchten><en> In addition to growing corn, people breed a large number of Black Angus cattle.
<G-vec00468-002-s122><breed.züchten><de> Neben dem Anbau von Mais, werden vor allem Black Angus Rinder gezüchtet.
<G-vec00468-002-s123><breed.züchten><en> For example for years it has been possible to specifically switch off single genes in mice and to breed genetically modified mouse strains, so-called knockout mice.
<G-vec00468-002-s123><breed.züchten><de> Bei Mäusen beispielsweise können seit Jahren gezielt einzelne Gene ausgeschaltet und genetisch veränderte Mausstämme gezüchtet werden, sogenannte Knockout-Mäuse.
<G-vec00468-002-s124><breed.züchten><en> Because Betta can live in extremely small spaces, living in rice paddies and drainage ditches in the wild, they have been breed to live alone in small tanks or bowls as pets.
<G-vec00468-002-s124><breed.züchten><de> Da diese Kampffische mit sehr wenig Platz auskommen und in der Wildnis in Reisfeldern und Abflussgräben leben, wurden sie gezüchtet, um in kleinen Aquarien oder Goldfischgläsern als Haustiere zu leben.
<G-vec00468-002-s125><breed.züchten><en> We only breed with dogs having an A hipscore.
<G-vec00468-002-s125><breed.züchten><de> Es wird bei uns nur gezüchtet mit Hunde die einen HD-Befund A haben.
<G-vec00196-002-s131><breed.haben><en> They help curb the risk of excess endocannabinoids which might breed dire consequences to body processes.
<G-vec00196-002-s131><breed.haben><de> Sie tragen dazu bei, das Risiko überschüssiger Endocannabinoide einzudämmen, die fatale Folgen haben könnten.
<G-vec00196-002-s132><breed.haben><en> Designed by Nike for a new breed of attacker who's agile and deceptive with deadly killer instinct, the new HyperVenom Citrus
<G-vec00196-002-s132><breed.haben><de> Von Nike designed, um eine neue Angriffsgeneration zu haben, die besonders agil und unvorhersehbar ist - der neue Nike HyperVenom Phantom SG-Pro mit den revolutionären NikeSkin- und ACC- Technologien.
<G-vec00196-002-s133><breed.haben><en> The term “Pata Negra” refers to the Spanish Iberian breed. The reason is that the black hoof most Iberian pigs have, “pata negra” means black paw.
<G-vec00196-002-s133><breed.haben><de> Der Begriff “Pata Negra” wird often benutzt wen wir über Iberische Schinken reden, der Grund ist dass die überwiegende Mehrheit der Iberischen Schweinen eine schwarze Klaue (Pfote) haben.
<G-vec00196-002-s134><breed.haben><en> The breed is naturally assertive and may not tolerate young children or other animals in the home.
<G-vec00196-002-s134><breed.haben><de> Sie haben eine bestimmende Art und tolerieren kleine Kinder oder andere Tiere im Haus unter Umständen nur ungern.
<G-vec00196-002-s135><breed.haben><en> British Shorthair cats are generally a robust breed without too many problems.
<G-vec00196-002-s135><breed.haben><de> Britische Kurzhaarkatzen sind generell robuste Rassekatzen, die nicht viele Probleme haben.
<G-vec00196-002-s136><breed.haben><en> In the Cavalier breed, responsible breeders have used heart screening tests since 1995, but because many ignore veterinarian advice to only breed dogs over a certain age, there has been no health progress in that front.
<G-vec00196-002-s136><breed.haben><de> Beim Cavalier King Charles Spaniel haben manche Züchter allerdings bereits seit 1995 Herzuntersuchungen durchführen lassen, aber weil sehr viele Züchter die tierärztliche Empfehlung ignorieren, erst ab dem Alter von fünf Jahren zu züchten, hat sich die Situation nicht verbessert.
<G-vec00196-002-s137><breed.haben><en> Michel learnt the local language from elderly people who also taught him how to breed cattle.
<G-vec00196-002-s137><breed.haben><de> Michel lernte Ukrainisch von hiesigen älteren Menschen, die ihm auch das Viehzüchten beigebracht haben..
<G-vec00196-002-s138><breed.haben><en> Dschingis Khan is one of the four most meaningful sons of Tamerlane who even were of large impact to the German warmblood breed.
<G-vec00196-002-s138><breed.haben><de> Dschingis Khan ist einer von vier bedeutenden Söhnen des Tamerlane die selbst die deutsche Warmblutzucht nachhaltig beeinflusst haben.
