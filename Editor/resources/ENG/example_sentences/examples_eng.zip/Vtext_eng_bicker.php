<G-vec00019-002-s006><bicker.(sich)_streiten><en> As factions bicker to no end, a great evil conspires in shadows;
<G-vec00019-002-s006><bicker.(sich)_streiten><de> Während die Mächtigen endlos streiten, verschwört sich ein großes Übel im Schatten.
<G-vec00019-002-s007><bicker.(sich)_streiten><en> She’ll need to help them with their homework and make sure that they don’t bicker too much.
<G-vec00019-002-s007><bicker.(sich)_streiten><de> Sie muss ihnen bei den Hausaufgaben helfen und dafür sorgen, dass sie sich nicht streiten.
<G-vec00019-002-s006><bicker.streiten><en> As factions bicker to no end, a great evil conspires in shadows;
<G-vec00019-002-s006><bicker.streiten><de> Während die Mächtigen endlos streiten, verschwört sich ein großes Übel im Schatten.
<G-vec00019-002-s007><bicker.streiten><en> She’ll need to help them with their homework and make sure that they don’t bicker too much.
<G-vec00019-002-s007><bicker.streiten><de> Sie muss ihnen bei den Hausaufgaben helfen und dafür sorgen, dass sie sich nicht streiten.
