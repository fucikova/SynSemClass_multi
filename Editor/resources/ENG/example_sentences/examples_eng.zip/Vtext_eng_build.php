<G-vec00001-001-s038><build.aufbauen><en> As the new Cardinals accept the burden of this office, I am confident that they will be supported by your constant prayers and your cooperation in their efforts to build up the Body of Christ in unity, holiness and peace.
<G-vec00001-001-s038><build.aufbauen><de> Während die neuen Kardinäle die Last ihres Amtes annehmen, vertraue ich darauf, daß sie die Unterstützung durch eure ständigen Gebete und eure Mitwirkung in ihren Bemühungen um den Aufbau des Leibes Christi in Einheit, Heiligkeit und Frieden erhalten werden.
<G-vec00001-001-s039><build.aufbauen><en> The partners hailing from Germany, Sweden and Italy plan to ultimately build an array of modules covering ten square meters to demonstrate stable device performance on a large area.
<G-vec00001-001-s039><build.aufbauen><de> Zum Abschluss planen die Partner aus Deutschland, Schweden und Italien den Aufbau mehrerer Module mit einer Gesamtfläche von zehn Quadratmetern, um Stabilität und Ertrag auf großer Fläche zu demonstrieren.
<G-vec00001-001-s040><build.aufbauen><en> And in Pakistan, we worked with Germany's Malteser charity to build an elementary school after the 2010 floods.
<G-vec00001-001-s040><build.aufbauen><de> Und in Pakistan fördern wir nach den Überschwemmungen im Jahr 2010 mit dem Malteser Hilfsdienst ebenfalls den Aufbau einer Grundschule.
<G-vec00001-001-s041><build.aufbauen><en> Careers Careers By cultivating a culture that values innovation, respect, and flexibility, we helpÂ employees build long careersÂ and reach their highest potential.
<G-vec00001-001-s041><build.aufbauen><de> Durch die Bewahrung einer Kultur, die Wert auf Innovationen, Respekt und Flexibilität legt, unterstützen wir die Mitarbeiter beim Aufbau einer langen Karriere und dem Ausschöpfen ihres maximalen Potenzials.
<G-vec00001-001-s042><build.aufbauen><en> Use communication as a tool to build your network and the reality within which you wish to operate.
<G-vec00001-001-s042><build.aufbauen><de> Begreifen Sie Kommunikation als Instrument zum Aufbau ihres Netwerks und der Realitäten innerhalb derer Sie sich bewegen.
<G-vec00001-001-s043><build.aufbauen><en> TheSRH Alumni Network helps to establish contacts within the areas of business,science, politics and culture.It provides a platform to build and maintain friendships between alumni from different years.
<G-vec00001-001-s043><build.aufbauen><de> Das Alumni-Netzwerk der Hochschule hilft bei der Vermittlung von Kontakten in die Wirtschaft, Wissenschaft, Politik und Kultur und bietet eine Basis für den Aufbau und die Pflege von Freundschaften zwischen den Alumni verschiedener Jahrgänge.
<G-vec00001-001-s044><build.aufbauen><en> "Its message is considered a cornerstone in order to build peace in the world and is a starting point for useful reflection in the Year of Faith"", explains, in a note sent to Fides, His Exc. Mgr. Peter Takeo Okada, Archbishop of Tokyo and President of the Bishops' Conference of Japan."
<G-vec00001-001-s044><build.aufbauen><de> Diese Botschaft ist die Basis für den Aufbau des Friedens in der Welt und sie ist auch für uns im Jahr des Glaubens ein nützlicher Denkanstoß“, so der Vorsitzende der Japanischen Bischofskonferenz, Bischof Petzer Takeo Okada von Tokio.
<G-vec00001-001-s045><build.aufbauen><en> The vulnerability is due to insufficient validation of a URL used to build a path for an applet in a Document Object Model.
<G-vec00001-001-s045><build.aufbauen><de> Der Grund hierfür ist eine nicht ausreichend genaue Prüfung von URLs, die zum Aufbau des Pfades für ein Applet im Document Object Model genutzt werden.
<G-vec00001-001-s046><build.aufbauen><en> The capital used to build up the collection came from war profits and the brutal exploitation of forced labor.
<G-vec00001-001-s046><build.aufbauen><de> Das Vermögen zum Aufbau der Sammlung stammt nicht zuletzt aus Kriegsgewinnen und der brutalen Ausbeutung von Zwangsarbeitern.
<G-vec00001-001-s047><build.aufbauen><en> Its name comes from the near church dedicated to Bergamo’s patron Saint, destroyed in 1561, as shown by a commemorative plaque located next to the only surviving column, in order to build the Walls.
<G-vec00001-001-s047><build.aufbauen><de> Sein Name kommt aus dem nahe gelegenen Basilika, die dem Schutzpatron von Bergamo gewidmet ist und die im Jahr 1561 abgerissen wurde, um, wie eine Gedenktafel neben dem einzigen überbleibenden Säule der Basilika zitiert, um den Aufbau der Mauern zu ermöglichen.
<G-vec00001-001-s048><build.aufbauen><en> In this position, Jörg will help build Cogiscan’s customer base and provide local support to its fast-growing customer base in Europe. This includes direct Cogiscan customers as well as its partners’ customers, including Juki Automation Systems.
<G-vec00001-001-s048><build.aufbauen><de> In dieser Position wird Jörg beim Aufbau des Kundenstamms mithelfen sowie den Kunden, seien dies direkte oder von Partnern wie Juki Automation Systems, lokalen Support bieten.
<G-vec00001-001-s049><build.aufbauen><en> They are made for polyester film which first aligns through printing rollers, some print jobs just involve one basic colour while others layer many colours to build up a design.
<G-vec00001-001-s049><build.aufbauen><de> Sie sind für Polyesterfolie, die erst durch ausrichtet Druckwalzen, einige Druckaufträge einfach um eine grundlegende Farbe, während andere Schicht viele Farben zum Aufbau eines Design.
<G-vec00001-001-s050><build.aufbauen><en> Baikonur “Free” is destroyed, and the Brazilians Moscow intends to help build a spaceport Alcantara.
<G-vec00001-001-s050><build.aufbauen><de> Baikonur “Free” ist zerstört, und die Brasilianer Moskau will zum Aufbau einer Weltraumbahnhof Alcantara.
<G-vec00001-001-s051><build.aufbauen><en> For technical reasons (the width of the felt-tipped pen), only 6 elements were used to build a module.
<G-vec00001-001-s051><build.aufbauen><de> Aus technischen Gründen (Breite des Filzschreibers) wurden nur 6 Elemente zum Aufbau eines Bausteins benutzt.
<G-vec00001-001-s052><build.aufbauen><en> In every circumstance, even in debilitating periods of illness, he knew how to recognize God’s plan, which led him to build his Kingdom, above all through self-denial and the daily acceptance of God’s will, ever more complete with a trusting abandonment.
<G-vec00001-001-s052><build.aufbauen><de> Er verstand es, in allen Umständen – auch in demütigenden Niederlagen – den Plan Gottes zu erkennen, der ihn zum Aufbau seines Reiches führte, vor allem durch die Selbstverleugnung und durch die tägliche Annahme seines Willens, mit einer immer vertrauensvolleren Hingabe.
<G-vec00001-001-s053><build.aufbauen><en> At a later stage VDL may be awarded an order to build over 500 more vehicles.
<G-vec00001-001-s053><build.aufbauen><de> Es besteht die Möglichkeit, dass VDL in einem späteren Stadium mit dem Aufbau weiterer gut 500 Fahrzeuge beauftragt wird.
<G-vec00001-001-s054><build.aufbauen><en> "Also other organisations, such as the Austrian National Library, Department ""Ariadne"" have contributed to build up this digital collection."
<G-vec00001-001-s054><build.aufbauen><de> Auch andere Institutionen, wie die Österreichische Nationalbibliothek haben zum Aufbau der Sammlung ganz wesentlich beigetragen.
<G-vec00001-001-s055><build.aufbauen><en> Thanks to the diverse training, you will have the chance every day to build up an international network throughout the company.
<G-vec00001-001-s055><build.aufbauen><de> Durch die abwechslungsreiche Ausbildung bietet sich täglich für Sie die Chance zum Aufbau eines unternehmensinternen, internationalen Netzwerks.
<G-vec00001-001-s056><build.aufbauen><en> Ten years after Seattle the group „Diggers 2.0“ is calling for „solidarity out of the rubble of Neoliberalism“. „What we need is crisis management from below, a counterauthority of social movements with shovels in their hands getting ready to build up a post-capitalistic world“.
<G-vec00001-001-s056><build.aufbauen><de> 10 Jahre nach Seattle fordert die Gruppe „Diggers 2.0.“ zur „Solidarität aus dem Schutt des Neoliberalismus“ auf: „Wir brauchen Krisenlösungen von unten, eine Gegenmacht der sozialen Bewegungen, die sich mit der Schaufel in der Hand zum Aufbau einer post-kapitalistischen Welt aufmacht“.
<G-vec00001-001-s057><build.aufbauen><en> So you can gradually build up the muscle and increase the load in stages also.
<G-vec00001-001-s057><build.aufbauen><de> So kannst du die Muskulatur schrittweise aufbauen und auch die Belastung in Etappen erhöhen.
<G-vec00001-001-s058><build.aufbauen><en> You can also build an ad-hoc network, that allows nodes to communicate directly (computer-to-computer) without the need for an AP.
<G-vec00001-001-s058><build.aufbauen><de> Zudem können Sie ein Ad-hoc-Netzwerk aufbauen, das Knoten die direkte Kommunikation (Computer zu Computer) ermöglicht, ohne dass ein Zugangspunkt erforderlich ist.
<G-vec00001-001-s059><build.aufbauen><en> We have to build a radical tendency within the PSUV, not to split or divide the party, but to contribute as a tendency to the living debate, to the discussion of ideas.
<G-vec00001-001-s059><build.aufbauen><de> Wir müssen innerhalb der PSUV eine radikale Strömung aufbauen nicht um die Partei zu spalten, sondern um uns als Strömung in die Diskussion einzubringen.
<G-vec00001-001-s060><build.aufbauen><en> If some basic ideas are adhered to, there is a pretty solid foundation on which usability engineers and software developers can build upon in their joint effort to create user friendly and technically solid systems.
<G-vec00001-001-s060><build.aufbauen><de> Wenn einige grundlegende Dinge beachtet werden, so kann ein solides Fundament geschaffen werden, auf dem Usability Engineers und Software Entwickler ihre Zusammenarbeit aufbauen können, um benutzerfreundliche und technisch fundierte User Interfaces zu erstellen.
<G-vec00001-001-s061><build.aufbauen><en> With our easy-to-use website builder, you can build a powerful and elegant online store, all in one place.
<G-vec00001-001-s061><build.aufbauen><de> Mit unserem einfach zu benutzenden Webseiten-Baukasten können Sie einen mächtigen und eleganten Online-Shop aufbauen - alles von einem Ort aus.
<G-vec00001-001-s062><build.aufbauen><en> Sounds impossible, but with the portable development of EMS-Training (Electronical Muscle Stimulation), people are able to easily build up muscles while protecting their joints.
<G-vec00001-001-s062><build.aufbauen><de> Das klingt unmöglich, doch dank der Entwicklung von tragbaren Geräten für das EMS-Training (elektronische Muskelstimulation) können Sie ganz leicht Muskelmasse aufbauen und dabei ihre Gelenke schonen.
<G-vec00001-001-s063><build.aufbauen><en> • User can build up remote desktop connection With this you can forbid or allow that the user can use the remote desktop connection out of Password Safe.
<G-vec00001-001-s063><build.aufbauen><de> • Benutzer kann Remote-Desktop-Verbindung aufbauen Hiermit können Sie verhindern oder erlauben, dass der Benutzer die Remote-Desktop-Verbindung aus Password Safe heraus verwenden kann.
<G-vec00001-001-s064><build.aufbauen><en> In particular, they want to foster economic development in developing countries, giving more people access to a bank account and to credit so that they can build a livelihood.
<G-vec00001-001-s064><build.aufbauen><de> Besonders die wirtschaftliche Entwicklung in Entwicklungsländern soll dabei gefördert werden: Mehr Menschen sollen künftig Zugang zu einem Bankkonto und zu Krediten bekommen, um sich eine Existenz aufbauen zu können.
<G-vec00001-001-s065><build.aufbauen><en> In short: Let's build a just, fraternal and sustainable society.
<G-vec00001-001-s065><build.aufbauen><de> Kurz: Lasst uns eine gerechte, solidarische und nachhaltige Gesellschaft aufbauen.
<G-vec00001-001-s066><build.aufbauen><en> Scientists will report how they build gigantic experiments from this simple experimental arrangement in order to solve the mysteries of the universe (hall 6).
<G-vec00001-001-s066><build.aufbauen><de> Wissenschaftler berichten dabei, wie sie aus diesem einfachen experimentellen Aufbau riesige Experimente aufbauen, um den ungelösten Rätseln des Universums auf die Spur zu kommen (Halle 6).
<G-vec00001-001-s067><build.aufbauen><en> But the calculation took so long that I did not have time to build it up.
<G-vec00001-001-s067><build.aufbauen><de> Das berechnen dauerte aber so lange, dass ich nicht zum Aufbauen kamen.
<G-vec00001-001-s068><build.aufbauen><en> You can adapt one of the ready-made configurations or build a new RapidPro system from scratch.
<G-vec00001-001-s068><build.aufbauen><de> Sie können eine der vordefinierten Konfigurationen anpassen oder ein RapidPro-System komplett neu aufbauen.
<G-vec00001-001-s069><build.aufbauen><en> More than anybody else, Kim Yun-jin tries to give her best, and you can tell so, but she just has to fail as she has no foundation to build on.
<G-vec00001-001-s069><build.aufbauen><de> Besonders Kim Yun-Jin sieht man an, dass sie versucht ihr Bestes zu geben, aber einfach keine Grundlage hat, auf der sie aufbauen kann.
<G-vec00001-001-s070><build.aufbauen><en> “The Board has improved the overall governance of the company over the past two years and as Lead Independent Director, I expect to continue to build on this solid foundation,” Solso said.
<G-vec00001-001-s070><build.aufbauen><de> „Das Board hat in den beiden vergangenen Jahren die allgemeine Unternehmensführung verbessert und als Lead Independent Director erwarte ich, dass wir auf dieser soliden Basis weiter aufbauen können“, sagt Solso.
<G-vec00001-001-s071><build.aufbauen><en> On these achievements of Americanism humanity will build the new society.
<G-vec00001-001-s071><build.aufbauen><de> Auf diesen Errungenschaften des Amerikanismus wird die Menschheit die neue Gesellschaft aufbauen.
<G-vec00001-001-s072><build.aufbauen><en> The Global Campus will build retention spaces for water – and retention spaces for love.
<G-vec00001-001-s072><build.aufbauen><de> Der Globale Campus wird Retentionsräume für das Wasser aufbauen – und Retentionsräume für die Liebe.
<G-vec00001-001-s073><build.aufbauen><en> Nourishing ourselves at the level of consciousness that we now chose to live in lets us build our body and life circumstances to match.
<G-vec00001-001-s073><build.aufbauen><de> Uns selbst auf dem Level des Bewusstseins nähren, in dem wir jetzt zu leben wählen, lässt uns unseren Körper und Lebensumstände so aufbauen, dass sie passen.
<G-vec00001-001-s074><build.aufbauen><en> Russia is actually mystified to see Ukraine’s neighbors and likeminded free people all over the world united with Ukrainians who want to build a better life and choose their leaders for themselves, by themselves.
<G-vec00001-001-s074><build.aufbauen><de> Russland ist in der Tat völlig verblüfft zu sehen, dass die Nachbarn der Ukraine und freie Menschen auf der ganzen Welt gleiche Gefühle hegen, gemeinsame Sache mit den Ukrainern machen, und die ein besseres Leben aufbauen und ihre Führer für sich selbst wählen wollen.
<G-vec00001-001-s075><build.aufbauen><en> "Dr. Hubertus Erlen, Chairman of the Executive Board of Schering AG, said: ""Together with Bayer, we aim to build a leading global pharmaceuticals company that unites the strengths of both organizations."
<G-vec00001-001-s075><build.aufbauen><de> "Schering-Vorstandsvorsitzender Dr. Hubertus Erlen sagte: ""Gemeinsam mit Bayer wollen wir ein führendes globales Pharmaunternehmen aufbauen, das die Stärken beider Organisationen vereint."
<G-vec00001-001-s076><build.aufbauen><en> It is fundamental to the collective sense of society and mutual reliance on which we will build Europe’s future.
<G-vec00001-001-s076><build.aufbauen><de> Nur durch Kohäsion können Gemeinschaftssinn und gegenseitiges Vertrauen entstehen, auf denen die Zukunft Europas aufbaut.
<G-vec00001-001-s077><build.aufbauen><en> Today is a day of peace, but in the whole world there is a great lack of peace. That is why I call you all to build a new world of peace with me through prayer.
<G-vec00001-001-s077><build.aufbauen><de> Heute ist der Tag des Friedens, aber in der ganzen Welt ist viel Unfriede, deshalb rufe ich euch auf, daß ihr alle mit mir durch das Gebet eine neue Welt des Friedens aufbaut.
<G-vec00001-001-s078><build.aufbauen><en> The profession of faith is followed by an account of sacramental life, in which Christ is present, operative and continues to build his Church.
<G-vec00001-001-s078><build.aufbauen><de> Auf das Glaubensbekenntnis folgt nämlich die Erklärung des sakramentalen Lebens, in dem Christus gegenwärtig ist, wirkt und fortwährend seine Kirche aufbaut.
<G-vec00001-001-s079><build.aufbauen><en> Maintaining a chatbot is often not as easy as you might think. It is generally assumed that a 'cognitive bot' uses content to teach itself, understand texts and use new sources of information to build up its own knowledge, which is formulated automatically based on user queries.
<G-vec00001-001-s079><build.aufbauen><de> "Die Pflege eines Chatbot-Systems ist oftmals nicht so leicht wie gedacht: Allgemein wird angenommen, dass ein ""Cognitive Bot"" anhand von Inhalten eigenständig lernt, Texte versteht und mittels neuer Wissensquellen eigenes Wissen aufbaut, das auf Nutzeranfragen automatisch formuliert wird."
<G-vec00001-001-s080><build.aufbauen><en> This mimics the type of heat that would build up on normal usage.
<G-vec00001-001-s080><build.aufbauen><de> Dies nachgeahmt die Wärme, die bei normalem Einsatz aufbaut.
<G-vec00001-001-s081><build.aufbauen><en> Album: Battlegrounds A spherical track, which is mainly influenced by the solo violin and continues to build up.
<G-vec00001-001-s081><build.aufbauen><de> Album: Battlegrounds Ein sphärischer Track, der vor allem durch die Solo-Violine geprägt wird und sich immer weiter aufbaut.
<G-vec00001-001-s082><build.aufbauen><en> my $cache_directory = ''; This parameter specifies the fully qualified path name of the directory inside of which gzip_cnc will build up its cache directory tree for compressed versions of all files having been requested.
<G-vec00001-001-s082><build.aufbauen><de> my $cache_directory = ''; Dieser Parameter beschreibt den vollständigen Pfadnamen des Verzeichnisses, innerhalb dessen gzip_cnc seinen Verzeichnisbaum für den Cache der komprimierten Versionen aller angeforderten Dateien aufbaut.
<G-vec00001-001-s083><build.aufbauen><en> The aim of the course is to build up an individual standpoint on the subject of myth.
<G-vec00001-001-s083><build.aufbauen><de> Kursziel ist dabei, daß jeder eine individuelle Position zum Thema Mythos aufbaut.
<G-vec00001-001-s084><build.aufbauen><en> Minecraft is a game where you build a world around you by mining, combining, and placing resources.
<G-vec00001-001-s084><build.aufbauen><de> Minecraft ist ein Spiel, in dem der Spieler die Welt um ihn herum aufbaut und beeinflusst, indem er Ressourcen abbaut, sie kombiniert und neu platziert.
<G-vec00001-001-s085><build.aufbauen><en> We tried to understand how to listen to ourselves and how to build up trust in another person.
<G-vec00001-001-s085><build.aufbauen><de> Wir versuchten zu verstehen, wie wir auf uns selbst hören und wie man Vertrauen zu einer anderen Person aufbaut.
<G-vec00001-001-s086><build.aufbauen><en> The leaching process takes place at the side walls and predominantly at the ceiling, while the clay residues build up on the bed of the chamber.
<G-vec00001-001-s086><build.aufbauen><de> Die Laugung findet an den Werksulmen und vorwiegend am Werkshimmel statt, während sich auf der Werksohle ein Laiststock aufbaut.
<G-vec00001-001-s087><build.aufbauen><en> This is the universal pathway that must be activated for a muscle to build itself up.
<G-vec00001-001-s087><build.aufbauen><de> Dies ist der universelle Biosyntheseweg der Muskel, der sich aktivieren muss, damit er sich selbst wieder aufbaut.
<G-vec00001-001-s088><build.aufbauen><en> There are ways to properly build an acceptable contact list, if you do not already have one.
<G-vec00001-001-s088><build.aufbauen><de> Es gibt Weisen wie man anständig eine akzeptable Kontaktliste aufbaut, falls Sie noch keine haben.
<G-vec00001-001-s089><build.aufbauen><en> An effort of the external surface mind or emotions, a Tapasya of some kind may seem to build up some of these things, but the results are usually uncertain and fragmentary, compared to the result of the two radical ways.
<G-vec00001-001-s089><build.aufbauen><de> Es kann den Anschein haben, dass eine Bemühung von seiten des äußeren Oberflächen-Mentals oder der Oberflächen-Gefühle, eine tapasya irgendwelcher Art, einige dieser Dinge aufbaut, die Ergebnisse aber sind meist ungewiss und unvollständig, verglichen mit dem Ergebnis der beiden fundamentalen Wege.
<G-vec00001-001-s090><build.aufbauen><en> The foundation of a long-term cooperation with NDR is laid as subshell continues to build and expand its expertise in the media industry.
<G-vec00001-001-s090><build.aufbauen><de> Der Grundstein für eine langjährige Zusammenarbeit ist gelegt, in deren Rahmen subshell ein umfassendes Know-how in der Medienbranche aufbaut.
<G-vec00001-001-s091><build.aufbauen><en> A soft gainer in body building is someone who gains muscle mass, strength and body weight to build up relatively quickly in conjunction with physical training.
<G-vec00001-001-s091><build.aufbauen><de> Ein Softgainer bezeichnet im Bodybuilding eine Person, die in Verbindung mit körperlichem Training relativ zügig Muskelmasse, Kraft und Körpergewicht aufbaut, davon aber auch verstärkt Fettgewebe.
<G-vec00001-001-s092><build.aufbauen><en> In the centre of this project, which is to build and develop a network of all nature parks and national parks in Burgenland and in western Hungary, is the common marketing and the harmonized development of tourism.
<G-vec00001-001-s092><build.aufbauen><de> Gemeinsames überregionales Marketing und eine abgestimmte touristische Angebotsentwicklung stehen im Mittelpunkt des Projekts, das ein Netzwerk aller burgenländischen und westungarischen Natur- und Nationalparks aufbaut und weiterentwickelt.
<G-vec00001-001-s093><build.aufbauen><en> My personal respect goes to all those craftsmen who build up their own teams in the same way as to a “high-end start up”.
<G-vec00001-001-s093><build.aufbauen><de> Mein Respekt gilt jedem Handwerker, der sich selbstständig macht und ein Team aufbaut in gleichem Maß wie einem „high-end start up“.
<G-vec00001-001-s094><build.aufbauen><en> In contrast, it is time that the EU abandons its cold war against Cuba and finally build fair, future-oriented relations with Cuba to benefit all sides.
<G-vec00001-001-s094><build.aufbauen><de> Demgegenüber ist es an der Zeit, dass die EU ihren Kalten Krieg gegen Cuba endlich aufgibt und faire, zukunftsorientierte Beziehungen zu Cuba zu allseitigem Nutzen aufbaut.
<G-vec00001-001-s095><build.aufbauen><en> In a certain way you don’t build up any suspense during the 25 minutes of the film. However, it is exactly the last few minutes that contribute to the understanding of the previous scenes by revealing the water problem in Burkina Faso as well as the lack of customers for agricultural products.
<G-vec00001-001-s095><build.aufbauen><de> In gewisser Weise wird in den gut 25 Minuten, die der Film dauert, ja keinerlei Spannungsbogen aufgebaut, und dennoch geben dann gerade die letzten Minuten Aufschluss über die Wasserproblematik in Burkina Faso, den Mangel an Abnehmern für die landwirtschaftlichen Produkte und tragen damit zum Verständnis der vorher gesehenen Szenen bei.
<G-vec00001-001-s096><build.aufbauen><en> Whether learning how to build 3-D models for your printers or designing their next science project, students can tinker, test and collaborate freely with Wacom in your makerspace.
<G-vec00001-001-s096><build.aufbauen><de> Ganz gleich, ob Studierende lernen, wie 3D-Modelle für den Drucker aufgebaut werden, oder ihr nächstes Wissenschaftsprojekt entwerfen – mit Wacom können sie in Ihrem Makerspace als offenem Kreativraum frei tüfteln, testen und zusammenarbeiten.
<G-vec00001-001-s097><build.aufbauen><en> I am forever thankful for the awareness and wisdom and peace Falun Dafa has helped me build in my life. Falun Dafa has helped me shift my perspective of my relationships with my family, my friends and with my society.
<G-vec00001-001-s097><build.aufbauen><de> Ich werde für immer dankbar sein für die Erkenntnis, die Weisheit und den Frieden sein, den Falun Dafa in meinem Leben aufgebaut hat.Falun Dafa hat mir geholfen, meine Sichtweise über die Beziehungen zu meiner Familie, zu meinen Freunden und meiner gesellschaftlichen Umgebung, zu ändern.
<G-vec00001-001-s098><build.aufbauen><en> 2,Over 15 years in the shower room industry has seen us build up extensive knowledge and expertise in manufacturing, logistics, and distribution, which has given us the distinct ability to deliver a five-star service.
<G-vec00001-001-s098><build.aufbauen><de> 2, In über 15 Jahren in der Duschraumbranche haben wir umfangreiches Wissen und Know-how in den Bereichen Fertigung, Logistik und Vertrieb aufgebaut, was uns die Fähigkeit verleiht, einen Fünf-Sterne-Service zu liefern.
<G-vec00001-001-s099><build.aufbauen><en> The companies intend to also work together to create and build a network of esports talent, with expertise across all game genres and titles and with experience in additional forms of entertainment.
<G-vec00001-001-s099><build.aufbauen><de> Die Unternehmen haben auch ein Netzwerk von Exporttalenten aufgebaut, das über alle Spielgenres und -titel hinweg über Fachkenntnisse verfügt und Erfahrung mit zusätzlichen Formen der Unterhaltung besitzt.
<G-vec00001-001-s100><build.aufbauen><en> In reality, body weight is made up of fat mass and muscle mass—leaving an athletic person who has build a great deal of muscle mass weighing a whole lot on a scale that makes zero differentiations.
<G-vec00001-001-s100><build.aufbauen><de> In Wirklichkeit setzt sich das Körpergewicht aus der Fett- und Muskelmasse zusammen – wodurch ein Athlet, der eine Menge Muskelmasse aufgebaut hat, auf einer Waage viel mehr wiegt als man ihm ansieht.
<G-vec00001-001-s101><build.aufbauen><en> The question is how to raise the level of awareness in the US, and how to build on the momentum of the EU’s environmental policy development on both sides of the Atlantic.
<G-vec00001-001-s101><build.aufbauen><de> Die Frage lautet, wie das Bewusstsein in den USA gesteigert werden kann und wie auf beiden Seiten des Atlantiks auf die Entwicklung der EU-Umweltpolitik aufgebaut werden kann.
<G-vec00001-001-s102><build.aufbauen><en> Therefore, this seminar will showcase best practice examples and instruments for public and private procurement decisions in favour of energy efficiency and will provide concrete guidance how to build up a green procurement system in a company or a public body.
<G-vec00001-001-s102><build.aufbauen><de> Das Seminar wird Best Practice Beispiele sowie Instrumente für die private und öffentliche energie-effiziente Beschaffung aufzeigen und konkrete Hilfestellung dabei geben, wie ein ökologisches Beschaffungssystem in einem Unternehmen oder einer öffentlichen Einrichtung aufgebaut werden kann.
<G-vec00001-001-s103><build.aufbauen><en> The neurons are fully analog build and offer therefore the sonical attributes that are always so direct and powerful like it is needed for a musical or sonic instrument.
<G-vec00001-001-s103><build.aufbauen><de> Die Neuronen sind voll analog aufgebaut und bieten daher die klanglichen Eigenschaften, die stets so direkt und und unmittelbar sind, wie es sich für ein Musik- oder Klanginstrument gehört.
<G-vec00001-001-s104><build.aufbauen><en> The army attack and the fact that the old henchmen of the regime still represent the state apparatus clearly shows that Egypt is only at the beginning of a long way to get rid of the Mubarak regime and to build a democratic government of the people.
<G-vec00001-001-s104><build.aufbauen><de> Diese Handlung der Armee und die Tatsache, dass im Staatsapparat die selben Metzger des Regimes walten, bringt klar zum Ausdruck, dass in Ägypten noch ein langer Weg zurückzulegen ist, bis das Mubarak-Regime beseitigt und eine souveräne demokratische Regierung des Volkes aufgebaut ist.
<G-vec00001-001-s105><build.aufbauen><en> Soon the earth surface is build up again with the proven mosquito grid / plaster method.
<G-vec00001-001-s105><build.aufbauen><de> Die Erdkruste wird wieder aufgebaut in der bewährten Fliegengaze/ Gips Methode.
<G-vec00001-001-s106><build.aufbauen><en> Data silos that build up behind cumbersome, outdated technology can not only leave your staff feeling frustrated and uninspired, they also undermine the hard work and commitment put into case resolution, causing task repetition and confusion, to name only a few problems.
<G-vec00001-001-s106><build.aufbauen><de> Datensilos, die durch schwerfällige, veraltete Technologien aufgebaut werden, führen nicht nur zu Frust und geringerer Motivation bei Ihren Mitarbeitern, sondern sie untergraben auch die harte Arbeit und den Einsatz, der in die Bearbeitung eines Falls fließt.
<G-vec00001-001-s107><build.aufbauen><en> A hydraulic hose was leaking, making it impossible to build up the constant pressure required.
<G-vec00001-001-s107><build.aufbauen><de> Ein Hydraulikschlauch war undicht so dass der erforderliche kontinuierliche Druck nicht aufgebaut werden konnte.
<G-vec00001-001-s108><build.aufbauen><en> This is how to build the civilization of love.
<G-vec00001-001-s108><build.aufbauen><de> So wird die Zivilisation der Liebe aufgebaut.
<G-vec00001-001-s109><build.aufbauen><en> I build my own tester without an etched board but on a simple hole matrix board.
<G-vec00001-001-s109><build.aufbauen><de> Prototyp Meinen eigenen Tester habe ich ohne geätzte Platine sondern auf einer einfachen Lochrasterplatine aufgebaut.
<G-vec00001-001-s110><build.aufbauen><en> In the 1960s the secondary plant was build in Delmenhorst and the first research and development laboratory was equipped.
<G-vec00001-001-s110><build.aufbauen><de> In den 1960-ern wurde das Zweitwerk bei Delmenhorst aufgebaut und das erste Forschung und Entwicklungslabor wurde eingerichtet.
<G-vec00001-001-s111><build.aufbauen><en> When I began my blogging career, I believed that “if you build it, they will come. ”
<G-vec00001-001-s111><build.aufbauen><de> Als ich meine Blogger-Karriere begann, glaubte ich, dass „sie schon kommen, wenn ich es aufgebaut habe“.
<G-vec00001-001-s112><build.aufbauen><en> Arnold suspects that if THC is taken over a long period of time, sufficient THC levels could build up in body fat to explain abnormally high levels of THC-COOH in people who claim not to have taken the drug recently.
<G-vec00001-001-s112><build.aufbauen><de> Arnold vermutet, dass, wenn THC über einen langen Zeitraum eingenommen wird, ausreichend hohe THC-Spiegel im Körperfett aufgebaut werden könnten, um ungewöhnlich hohe Konzentrationen von THC-COOH bei Personen zu erklären, die behaupten, die Droge kürzlich nicht verwendet zu haben.
<G-vec00001-001-s113><build.aufbauen><en> He had worked in foreign botanical gardens, i.e. South Africa, and had build a great collection in Copenhagen .
<G-vec00001-001-s113><build.aufbauen><de> Er hatte in verschiedenen Gärten gearbeitet, zum Beispiel in Süd-Afrika, und eine exzellente Sammlung in Kopenhagen aufgebaut.
<G-vec00001-001-s114><build.aufbauen><en> """So Pierre Ferrari, CEO of Heifer Int'l, challenged the organization to build an infrastructure of best in class systems to support growth, diversification of revenue, and increase scale of program impact."
<G-vec00001-001-s114><build.aufbauen><de> Daher forderte Pierre Ferrari, CEO von Heifer International, die Organisation auf, eine Infrastruktur von branchenführenden Systemen aufzubauen, um Wachstum und Umsatzdiversifizierung zu unterstützen und das Ausmaß des Programmeffekts zu steigern.
<G-vec00001-001-s115><build.aufbauen><en> Build relationships, maintain and develop is a very complex task.
<G-vec00001-001-s115><build.aufbauen><de> Beziehungen aufzubauen, zu halten und weiterzuentwickeln ist eine sehr umfangreiche Aufgabe.
<G-vec00001-001-s116><build.aufbauen><en> As he says: “In this mutual understanding and friendship, in this sacred communion, we must also… work together to build the common future of the human race”.[5] In the first place, this duty falls to those who are most privileged.
<G-vec00001-001-s116><build.aufbauen><de> Und er erklärt: »In diesem gegenseitigen Verstehen und in dieser Freundschaft, in dieser heiligen Gemeinschaft müssen wir zusammenarbeiten, um die gemeinsame Zukunft der Menschheit aufzubauen.«[5] Diese Aufgabe betrifft an erster Stelle die am meisten Bevorzugten.
<G-vec00001-001-s117><build.aufbauen><en> During the G20 Summit, Hytera was designated to provide the security guards with wireless communication support and build a communication network that covered the area from Hangzhou International Airport to Hangzhou-Jiaxing-Huzhou Plain.
<G-vec00001-001-s117><build.aufbauen><de> Während des G20-Gipfels war Hytera beauftragt, eine drahtlose Kommunikationsunterstützung für die Sicherheitsbeamten bereitzustellen und ein Kommunikationsnetz aufzubauen, das das Gebiet vom Hangzhou International Airport bis zur Hangzhou-Jiaxing-Huzhou Plain abdeckte.
<G-vec00001-001-s118><build.aufbauen><en> These exercises are designed to build up muscle strength and stamina and to improve and maintain the range of movement of the joints.
<G-vec00001-001-s118><build.aufbauen><de> Ziel der Behandlung ist es, Muskelstärke und Ausdauer aufzubauen und die Beweglichkeit der Gelenke zu verbessern und aufrechtzuerhalten.
<G-vec00001-001-s119><build.aufbauen><en> That must have been true, because otherwise she never could have managed, on more mature age, not only to set up a hotel but also to build up a very close-knit circle of guests, which is so necessary for the survival of any starting company.
<G-vec00001-001-s119><build.aufbauen><de> Das muss auch wohl so gewesen sein, denn sonst wäre es ihr nie gelungen, in ihrem reiferen Alter nicht nur ein Hotel aufzubauen, sondern auch einen soliden Kreis von Stammgästen anzuwerben, die gerade in den Aufbauphase so überlebenswichtig sind.
<G-vec00001-001-s120><build.aufbauen><en> This allows the company to build a long-term relationship with its customers.
<G-vec00001-001-s120><build.aufbauen><de> Dies versetzt Roland DG in die Lage, eine langfristige Geschäftsbeziehung mit seinen Kunden aufzubauen.
<G-vec00001-001-s121><build.aufbauen><en> Inspired by Jewish values of Kesher programs should contribute to a pluralistic community, committed to social justice, build, and support for civic engagement across ethnic, religious and national boundaries.
<G-vec00001-001-s121><build.aufbauen><de> Die von jüdischen Werten inspirierten Programme von Kesher sollen dazu beitragen, pluralistische Gemeinden, die sich für soziale Gerechtigkeit einsetzen, aufzubauen, und bürgerschaftliches Engagement über ethnische, religiöse und nationale Grenzen hinweg zu unterstützen.
<G-vec00001-001-s122><build.aufbauen><en> Under the motto of “migration with dignity” the former president of Kiribati, Anote Tong, initiated an emigration strategy that should enable the population to gradually build a new life in another country before the islands become uninhabitable and the approximately 100,000 inhabitants of Kiribati become homeless refugees.
<G-vec00001-001-s122><build.aufbauen><de> Unter dem Motto „Migration with Dignity“ (Auswanderung mit Würde) hat der ehe malige Präsident von Kiribati, Anote Tong, eine Auswanderungsstrategie gestartet, mit der die Bevölkerung nach und nach dazu befähigt werden soll, sich im Ausland eine neue Existenz aufzubauen, ehe die Inseln unbewohnbar und die rund 100 000 Einwohner Kiribatis zu heimatlosen Flüchtlingen werden.
<G-vec00001-001-s123><build.aufbauen><en> It is up to us Christians to build a culture of life.
<G-vec00001-001-s123><build.aufbauen><de> Es ist die Aufgabe von uns Christen, eine Kultur des Lebens aufzubauen.
<G-vec00001-001-s124><build.aufbauen><en> In addition, a number of developing nations are using their new wealth to build up and modernise their armed forces, especially in the Asia-Pacific region.
<G-vec00001-001-s124><build.aufbauen><de> Zusätzlich nutzen eine Reihe von Entwicklungsländer - insbesondere in der asiatisch-pazifischen Region - ihren neuen Reichtum, um ihre Armeen aufzubauen und zu modernisieren.
<G-vec00001-001-s125><build.aufbauen><en> An internship at Transenter will help you develop professional skills and build a network of contacts.
<G-vec00001-001-s125><build.aufbauen><de> Ein Praktikum bei Transenter unterstützt Dich dabei, fachliche Kompetenz zu entwickeln und ein Netzwerk von Kontakten aufzubauen.
<G-vec00001-001-s126><build.aufbauen><en> On the other hand, carbohydrates are the fuel, gasoline, pure energy that the body uses to move and build strength.
<G-vec00001-001-s126><build.aufbauen><de> Auf der anderen Seite, Kohlenhydrate sind der Treibstoff, Benzin, reine Energie, die der Körper zu bewegen und Kraft aufzubauen.
<G-vec00001-001-s127><build.aufbauen><en> So whether you’re trying to cut, bulk, build lean muscle, increase muscle strength or increase stamina and endurance, Crazy Bulk has got you covered .
<G-vec00001-001-s127><build.aufbauen><de> Also ob du versuchst, geschnitten, Bulk, Muskelmasse aufzubauen, Muskelkraft erhöhen Sie oder Ausdauer und Durchhaltevermögen, Verrückte Masse hat vorgesorgt.
<G-vec00001-001-s128><build.aufbauen><en> It's a challenging game that rewards fast reflexes and you will soon build up the best strategy to get rid of the aliens.
<G-vec00001-001-s128><build.aufbauen><de> Es ist ein schwieriges Spiel, das schnelle Reflexe Belohnungen und Sie werden bald aufzubauen die beste Strategie, der Aliens loszuwerden.
<G-vec00001-001-s129><build.aufbauen><en> As the fight neared, Promoted Tweets helped @MetroPCS extend their reach and build a larger audience on Twitter.
<G-vec00001-001-s129><build.aufbauen><de> Als der Kampf näher rückte, halfen Promoted Tweets @MetroPCS, die Reichweite zu erhöhen und eine größere Zielgruppe auf Twitter aufzubauen.
<G-vec00001-001-s130><build.aufbauen><en> Working in close collaboration with local and international partners, we aim to build inspiring and long-term relationships.
<G-vec00001-001-s130><build.aufbauen><de> In enger Zusammenarbeit mit internationalen Partnern und mit Partnern vor Ort sind wir darum bemüht, langfristige produktive interkulturelle Beziehungen aufzubauen.
<G-vec00001-001-s131><build.aufbauen><en> Creating tutorials, instructional videos, interactive videos, webinars, streamed live events or just creating entertaining content could help you to build a strong online presence in both the video community and the social community.
<G-vec00001-001-s131><build.aufbauen><de> Die Erstellung von Lehr-Videos, interaktiven Videos, Live Veranstaltungen, oder einfach nur unterhaltsame Inhalte zu erstellen, können Ihnen helfen eine starke Online Präsenz, sowohl in der Video- und der Sozialen Gemeinschaft aufzubauen.
<G-vec00001-001-s132><build.aufbauen><en> Through regular training, you will be given opportunities to expand your skills and competences, and thus build your SunExpress career over the longer term.
<G-vec00001-001-s132><build.aufbauen><de> Bei den regelmäßigen Fortbildungen erhalten Sie die Gelegenheit, Ihre Fähigkeiten und Kompetenzen zu erweitern und so Ihre Karriere bei SunExpress langfristig aufzubauen.
<G-vec00001-001-s133><build.ausbauen><en> We want to build on this position and become the number 1 system partner.
<G-vec00001-001-s133><build.ausbauen><de> Diese Position wollen wir weiter ausbauen und zum Systempartner Nummer 1 werden.
<G-vec00001-001-s134><build.ausbauen><en> "Henke views his new position as one that offers a range of challenges. ""First, of course, I want to maintain and build upon the high standards set by my predecessor, Professor Szodruch."
<G-vec00001-001-s134><build.ausbauen><de> "Henke sieht in seiner neuen Position verschiedene Herausforderungen: ""Zum einen will ich natürlich den hohen Standard halten und ausbauen, den mein Vorgänger Prof. Szodruch gesetzt hat."
<G-vec00001-001-s135><build.ausbauen><en> Apart from this milestone, there are other new International Research Training Groups that build upon existing cooperation arrangements with the USA, Japan, Russia, Spain and South Korea within this funding programme.
<G-vec00001-001-s135><build.ausbauen><de> Neben diesem Meilenstein gibt es weitere neue Internationale Graduiertenkollegs, die die in diesem Förderprogramm bereits bestehenden Kooperationen mit den USA, Japan, Russland, Spanien und Südkorea weiter ausbauen.
<G-vec00001-001-s136><build.ausbauen><en> "In France, the Group will continue to build on its strong position as a ""private and personal insurer""."
<G-vec00001-001-s136><build.ausbauen><de> In Frankreich wiederum wird die Gruppe ihre starke Position als «Private and Personal Insurer» weiter ausbauen.
<G-vec00001-001-s137><build.ausbauen><en> This workshop should inform the participants of the possibilities, how users of the AAC through use of a variety of communication methods can build up their effectiveness as communication participants.
<G-vec00001-001-s137><build.ausbauen><de> Dieser Workshop soll den TeilnehmerInnen die Möglichkeit vermitteln, wie NutzerInnen der Unterstützten Kommunikation durch vielseitige Anwendung verschiedener Kommunikationsmethoden ihre Effektivität als KommunikationsteilnehmerInnen ausbauen können.
<G-vec00001-001-s138><build.ausbauen><en> With sufficient capital in the bank, we're confident we can achieve our goals and continue to build out our technology platform.
<G-vec00001-001-s138><build.ausbauen><de> Mit ausreichend Kapitalreserven ausgestattet, sind wir zuversichtlich, unsere Ziele erreichen und unsere Technologie-Plattform weiter ausbauen zu können.
<G-vec00001-001-s139><build.ausbauen><en> Speakers at the rally celebrated the success of the day, while many marchers gathered in “Circles of Resistance,” some set up around their parachute banners, to talk about how to continue to build their movement.
<G-vec00001-001-s139><build.ausbauen><de> "Viele Demonstranten versammelten sich beim Abschluss der Kundgebung in ""Circles of Resistance"", um darüber zu sprechen, wie sie ihre Bewegung fortsetzen und ausbauen."
<G-vec00001-001-s140><build.ausbauen><en> Curvature’s Design services can help you manage this complexity and help you build the IT infrastructure needed to meet your goals.
<G-vec00001-001-s140><build.ausbauen><de> Mit den Design-Services von Curvature können Sie diese Komplexität beherrschen und die IT-Infrastruktur Ihren Zielen entsprechend ausbauen.
<G-vec00001-001-s141><build.ausbauen><en> """As part of the technotrans Group, we will be able to access the international network of sales and service locations and build on our customer ties to give our competitiveness a further boost,"" explained Helmut Gries, Sales and Marketing Director of gwk."
<G-vec00001-001-s141><build.ausbauen><de> """Als Teil der technotrans-Unternehmensgruppe können wir auf das internationale Netzwerk der Sales- und Servicestandorte zurückgreifen und unsere Kundenbeziehungen weiter ausbauen, um unsere Wettbewerbsfähigkeit weiter zu erhöhen"", erläutert Helmut Gries, Geschäftsführer für Vertrieb und Marketing der gwk."
<G-vec00001-001-s142><build.ausbauen><en> It is seeking to build on its relations to the countries in the region.
<G-vec00001-001-s142><build.ausbauen><de> Damit will sie ihre Beziehungen zu den Ländern der Region ausbauen.
<G-vec00001-001-s143><build.ausbauen><en> Our aim must be to further strengthen and build on this excellent foundation.
<G-vec00001-001-s143><build.ausbauen><de> Diese hervorragende Basis müssen wir weiter stärken und ausbauen.
<G-vec00001-001-s144><build.ausbauen><en> They would better build themselves spiritually here, and then convey the values acquired to the people by preaching and by own example, in the quiet of the monastery.
<G-vec00001-001-s144><build.ausbauen><de> Da werden sie sich seelisch besser ausbauen und dann den Leuten durch Predigen und Beispiele die in der Ruhe des Klosters erworbenen Werte übermitteln.
<G-vec00001-001-s145><build.ausbauen><en> The users can complete their tasks independently, or share information, knowledge and ideas with others so that they can build up their contacts in the creative community.
<G-vec00001-001-s145><build.ausbauen><de> Die Nutzer können ihre Aufgaben unabhängig voneinander erledigen oder mit anderen Informationen, Wissen und Ideen austauschen, sodass sie ihre Kontakte in der kreativen Gemeinschaft ausbauen können.
<G-vec00001-001-s146><build.ausbauen><en> With the best toolkit in the industry at your disposal, you can build your client platform at any level.
<G-vec00001-001-s146><build.ausbauen><de> Sie haben das beste Toolkit der Branche zu Ihrer Verfügung und können damit Ihre Kundenplattform auf- und ausbauen.
<G-vec00001-001-s147><build.ausbauen><en> Receive (through your mobile phone) translations of English words to German, Vietnamese and Chinese Prepare for the TOEIC exams; and Build your English vocabulary.
<G-vec00001-001-s147><build.ausbauen><de> (über das Handy) Übersetzungen von englischen Wörtern ins Deutsche, Vietnamesische und Chinesische erhalten Sich auf die TOEIC® -Prüfungen vorbereiten; und Seinen Englischwortschatz ausbauen.
<G-vec00001-001-s148><build.ausbauen><en> Deal fairly inside and outside of the company, build an environment of trust and active co-operation between employees and in relation to business partners.
<G-vec00001-001-s148><build.ausbauen><de> Vertrauens und aktive Zusammenarbeit in den Beziehungen mit den Innerhalb und außerhalb der Gesellschaft fair play handeln, Milieu des Geschäftspartnern ausbauen.
<G-vec00001-001-s149><build.ausbauen><en> It allowed SkyTeam to build a broader network and provide customers with access to additional regions of the world.
<G-vec00001-001-s149><build.ausbauen><de> So konnte SkyTeam das Streckennetz ausbauen und Kunden Zugang zu weiteren Regionen der Welt ermöglichen.
<G-vec00001-001-s150><build.ausbauen><en> We also plan to build up our business in Africa and the Middle East.
<G-vec00001-001-s150><build.ausbauen><de> Auch in Afrika und dem Mittleren Osten werden wir unser Geschäft ausbauen.
<G-vec00001-001-s151><build.ausbauen><en> "We see great potential in this future market and aim to build on our position as the leading provider of digital financial solutions,"" says Ulrich Dietz, CEO of GFT Technologies SE."
<G-vec00001-001-s151><build.ausbauen><de> "Wir sehen ein großes Potenzial in diesem Zukunftsmarkt und wollen unsere Position als führender Anbieter von digitalen Finanzlösungen weiter ausbauen"", sagt Ulrich Dietz, CEO der GFT Technologies SE."
<G-vec00001-001-s152><build.ausbauen><en> """Commitment to our customers is the key for Momentive to build on our highly respected position in the market"" stated Kasper van der Heijden, Commercial Leader RTV & Sealants in Europe."
<G-vec00001-001-s152><build.ausbauen><de> "„Der Einsatz für unsere Kunden ist Momentive wichtig, um unsere hoch angesehene Marktposition weiter auszubauen"", konstatiert Kasper van der Heij-den, Commercial Leader RTV & Sealants in Europa."
<G-vec00001-001-s153><build.ausbauen><en> Our mission is to attract, recruit, develop and retain the people that will help us build on our success.
<G-vec00001-001-s153><build.ausbauen><de> Unsere Mission lautet, diejenigen Menschen zu interessieren, zu rekrutieren, zu entwickeln und zu halten, die uns helfen, unseren Erfolg auszubauen.
<G-vec00001-001-s154><build.ausbauen><en> To build on the position that has been achieved, KOMET is advancing development in the three principal directions mentioned.
<G-vec00001-001-s154><build.ausbauen><de> Um die erreichten Positionen auszubauen, treibt KOMET die Entwicklung in den genannten drei Stoß richtungen voran.
<G-vec00001-001-s155><build.ausbauen><en> "David Tibble, Mercator's Executive Chairman said, ""To build upon our already strong position in the aviation technology-enabled solutions market, Mercator has been looking for a platform that provides the right extension into the ocean and ground carrier market."
<G-vec00001-001-s155><build.ausbauen><de> "Mercators Executive Chairman David Tibble erklärte: ""Mercator hat nach einer Plattform gesucht, die geeignete Erweiterungsmöglichkeiten im Hinblick auf Boden- und Seefracht bietet, um unsere starke Marktposition bei technologiegestützten Lösungen für die Luftfahrt weiter auszubauen."
<G-vec00001-001-s156><build.ausbauen><en> """This acquisition will allow Kao to further build its presence in the New England region by leveraging existing business unit infrastructure and strengthening the base for further growth."
<G-vec00001-001-s156><build.ausbauen><de> """Dieser Erwerb ermöglicht es Kao, die Präsenz in Neuengland durch die Nutzung der bestehenden Infrastruktur der Geschäftseinheiten weiter auszubauen und das Fundament für weiteres Wachstum zu festigen."
<G-vec00001-001-s157><build.ausbauen><en> Then there were Jewish schools that had to be renovated for reasons other than the pressure by Polish authorities; these schools, which depended largely on voluntary contributions, were rarely in a position to build or renovate without financial aid.
<G-vec00001-001-s157><build.ausbauen><de> Dann waren da jüdische Schulen, die aus anderen Gründen renoviert werden mussten, nicht wegen dem Druck der polnischen Behörden; diese Schulen, die im Grossen und Ganzen von freiwilligen Beiträgen abhingen, waren ohne finanzielle Hilfe kaum in der Lage, die Schule auszubauen oder zu renovieren.
<G-vec00001-001-s158><build.ausbauen><en> With 17 positive late-stage clinical trials in 2011, we continue to build our future business with innovative products.
<G-vec00001-001-s158><build.ausbauen><de> Mit 17 positiven Studien in der Spätphase der klinischen Entwicklung haben wir die Voraussetzungen weiter verbessert, in den kommenden Jahren unser Geschäft mit innovativen Produkten auszubauen.
<G-vec00001-001-s159><build.ausbauen><en> This dependency forces state managers to be concerned about maintaining economic activity, irrespective of whether they are bureaucrats or elected professional politicians and regardless of whether their goals are to build up military capacity or implement social reforms.
<G-vec00001-001-s159><build.ausbauen><de> Diese Abhängigkeit zwingt die Entscheidungsträger des Staates, sich um die Aufrechterhaltung der wirtschaftlichen Aktivität zu kümmern, unabhängig davon, ob sie in der staatlichen Verwaltung arbeiten, oder zum gewählten hauptberuflichen politischen Führungspersonal gehören und auch unabhängig davon, ob ihr Ziel daran besteht, die Schlagkraft des Militärs auszubauen oder Sozialreformen umzusetzen.
<G-vec00001-001-s160><build.ausbauen><en> This is what I'm talking about when I echo the words of a young Hungarian political analyst, who has said that we have been mandated to build a new era.
<G-vec00001-001-s160><build.ausbauen><de> Ich deute dies dahingehend – und damit stimme ich der Meinung eines jungen ungarischen Analysten zu, dass man uns ermächtigt hat, eine neue Epoche auszubauen.
<G-vec00001-001-s161><build.ausbauen><en> It is assisting these partner institutions to develop strategies, funding mechanisms and systems for the monitoring, reporting and verification (MRV) of climate impacts and to build their NAMA implementation capacities.
<G-vec00001-001-s161><build.ausbauen><de> Diese unterstützt es dabei, Konzepte, Finanzierungsmechanismen und Systeme für die Messung, Berichterstattung und Verifizierung (englisch: Measuring, Reporting, Verification - MRV) der Klimawirkungen zu entwickeln und ihre Kapazitäten für die Umsetzung der NAMAs auszubauen.
<G-vec00001-001-s162><build.ausbauen><en> 3.3 The practitioner continuously learns and evolves to build and improve their knowledge, skills and abilities.
<G-vec00001-001-s162><build.ausbauen><de> 3.3 Der Praktiker lernt und entwickelt sich ständig weiter, um sein Wissen, seine Fertigkeiten und Fähigkeiten auszubauen und zu verbessern.
<G-vec00001-001-s163><build.ausbauen><en> TIER Mobility will use proceeds to accelerate its European expansion strategy and continue to build the leading micro-mobility platform for citizens, city authorities and public transportation partners.
<G-vec00001-001-s163><build.ausbauen><de> TIER Mobility wird das gesammelte Kapital dazu nutzen, seine Expansionsstrategie in Europa zu beschleunigen und weiter daran zu arbeiten, die führende Mikromobilitätsplattform für Bürger, Stadtverwaltungen und Partner des öffentlichen Nahverkehrs auf- und auszubauen.
<G-vec00001-001-s164><build.ausbauen><en> My ambition, after Genesis, was to create a career that had balance and to gradually build my audience, slowly.
<G-vec00001-001-s164><build.ausbauen><de> Meine Ambitionen, nach Genesis, richteten sich danach, eine ausbalancierte Karriere auf- und mein Publikum auszubauen.
<G-vec00001-001-s165><build.ausbauen><en> You have to build and protect your city, to entertain your folk and to pay tributes to Rome...
<G-vec00001-001-s165><build.ausbauen><de> Als römischer Stadthalter ist man dafür verantwortlich, seine Stadt auszubauen und zu beschützen.
<G-vec00001-001-s166><build.ausbauen><en> At the beginning of 1995, the Anhui Provincial Party Committee and Anhui provincial government jointly made a strategic decision to build up Hefei into a large modern city in the near future.
<G-vec00001-001-s166><build.ausbauen><de> Anfang 1995 entschied das Parteikomitee der Provinz Anhui zusammen mit der Provinzregierung, Hefei in kürzester Zeit zu einer modernen Großstadt auszubauen.
<G-vec00001-001-s167><build.ausbauen><en> We're delighted to see the positive impact the Jet Press 720S is already having on Estermann's business and we look forward to helping them to continue to build on this early success.
<G-vec00001-001-s167><build.ausbauen><de> Wir freuen uns, dass die Jet Press 720S bereits positive Auswirkungen auf das Geschäft von Estermann hat und wir freuen uns darauf, ihnen dabei zu helfen, diesen frÃ1⁄4hen Erfolg weiter auszubauen.
<G-vec00001-001-s168><build.ausbauen><en> They are hosting a series of natural building workshops for women to build the centre.
<G-vec00001-001-s168><build.ausbauen><de> Sie führen verschiedene Seminare für Frauen durch, um das Zentrum mit Naturmaterialien auszubauen.
<G-vec00001-001-s169><build.ausbauen><en> to Socialism, E. A. Preobrazhensky had advocated the necessity of “primitive socialist accumulation” to build up the resources for the expansion of the Soviet industrial base.
<G-vec00001-001-s169><build.ausbauen><de> Preobraschenski für die Notwendigkeit einer „ursprünglichen sozialistischen Akkumulation“ eingetreten, um die Ressourcen für die Ausweitung der sowjetischen industriellen Basis auszubauen.
<G-vec00001-001-s170><build.ausbauen><en> Classic playing cards might not be trendy and people may need a bit of persuasion to play them, but traditional topics such as skat and rummy coupled with advanced licencing themes and interactive possibilities give us the opportunity to further build on the strengths of the company.
<G-vec00001-001-s170><build.ausbauen><de> Vielleicht sind die klassischen Spielkarten kein Trendspiel und benötigen etwas Überzeugungsarbeit, aber traditionelle Themen wie Skat oder Rommé gepaart mit modernen Lizenzthemen und interaktiven Möglichkeiten, geben uns die Chance, die Stärken der Firma weiter auszubauen.
<G-vec00001-001-s190><build.bauen><en> 1 And Balaam said to Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00001-001-s190><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre, und stelle mir hier bereit sieben Farren und sieben Widder.
<G-vec00001-001-s191><build.bauen><en> 3 And Solomon sent to Huram king of Tyre, saying, As thou didst deal with David my father, and didst send him cedars to build him a house to dwell therein so do for me.
<G-vec00001-001-s191><build.bauen><de> 3 Und Salomo sandte zu Huram, dem König von Tyrus, und ließ ihm sagen: So wie du meinem Vater David getan und ihm Zedern gesandt hast, daß er sich ein Haus baue, um darin zu wohnen, so tue auch mir.
<G-vec00001-001-s192><build.bauen><en> Build a model of a German rocket launcher from World War II.
<G-vec00001-001-s192><build.bauen><de> Baue ein Modell eines deutschen Raketenwerfers aus dem Zweiten Weltkrieg.
<G-vec00001-001-s193><build.bauen><en> add these cards to your arsenal and build your perfect deck.
<G-vec00001-001-s193><build.bauen><de> füge diese Karten deinem Arsenal hinzu und baue dein perfektes Deck.
<G-vec00001-001-s194><build.bauen><en> And build an altar to the LORD your God upon the top of this rock, in an orderly manner, and take the second bullock, and offer it upon it as a burnt offering with the wood of the grove which you shall cut down.
<G-vec00001-001-s194><build.bauen><de> und baue dem HERRN, deinem Gott, oben auf der Höhe dieses Felsens einen Altar und rüste ihn zu und nimm den andern Farren und opfere ein Brandopfer mit dem Holz des Ascherabildes, das du abgehauen hast.
<G-vec00001-001-s195><build.bauen><en> Build your tower higher and higher and make sure it doesn't collapse.
<G-vec00001-001-s195><build.bauen><de> Baue deinen Turm höher und höher und pass auf dass er nicht einstürzt.
<G-vec00001-001-s196><build.bauen><en> 1 And Balaam said unto Balak, Build me here seven altars, and prepare me here seven oxen and seven rams.
<G-vec00001-001-s196><build.bauen><de> 1 Und Bileam sprach zu Balak: Baue mir hier sieben Altäre und schaffe mir her sieben junge Stiere und sieben Widder.
<G-vec00001-001-s197><build.bauen><en> Build the most ecologic city in the world
<G-vec00001-001-s197><build.bauen><de> Baue die ökologischste Stadt der Welt.
<G-vec00001-001-s198><build.bauen><en> I received a sample package from the company PESTAS which produces wooden dominoes in Austria. In this video, I compare the dominoes to the ones I frequently use and build up some smaller testing projects.
<G-vec00001-001-s198><build.bauen><de> Ich habe von der Firma PESTAS, welche Holzdominosteine in Österreich herstellt, ein Musterpaket zugeschickt bekommen und vergleiche in diesem Video die Steine mit meinen Dominos und baue ein paar kleine Beispielprojekte.
<G-vec00001-001-s199><build.bauen><en> "Build the model railroad of your dreams in ""Train Table"" mode, where your imagination is free from the pressures of finance or competition."
<G-vec00001-001-s199><build.bauen><de> "Baue die Eisenbahn deiner Träume im Modus ""Train Table"", in dem deine Fantasie sich ohne Rücksicht auf finanziellen oder wertbewerblichen Druck frei entfalten kann."
<G-vec00001-001-s200><build.bauen><en> Build and place the Tina Goldstein minifigure on the LEGO Toy Pad to send her into the game where she can cast Aguamenti to help solve puzzles and Protego to keep her safe from enemies.
<G-vec00001-001-s200><build.bauen><de> Baue Tina Goldstein, platziere sie auf dem LEGO Toypad und schicke sie in das Spiel, wo sie mit Aguamenti Rätsel lösen und sich mit Protego vor Gegnern schÃ1⁄4tzen kann.
<G-vec00001-001-s201><build.bauen><en> Build the models and sit him in position.
<G-vec00001-001-s201><build.bauen><de> Baue die Modelle und setze ihn auf Posten.
<G-vec00001-001-s202><build.bauen><en> When that happens, I often decide to build some special models.
<G-vec00001-001-s202><build.bauen><de> Dann baue ich neben der Serienfertigung ein paar ganz besondere Ukulelen mit.
<G-vec00001-001-s203><build.bauen><en> Remix new tracks and build your song library by purchasing “Burning Down The House” by Talking Heads.
<G-vec00001-001-s203><build.bauen><de> Erstelle einen Remix von neuen Tracks und baue deine Song-Bibliothek auf, indem du “Burning Down The House” von Talking Heads kaufst.
<G-vec00001-001-s204><build.bauen><en> For every tenth flute which I build I plant here a little Red Cedar tree.
<G-vec00001-001-s204><build.bauen><de> Für jede zehnte Flöte die ich baue pflanze ich hier einen kleinen Red Cedar Baum.
<G-vec00001-001-s205><build.bauen><en> Build your own castle and defeat other players in tactical fights on a giant world map.
<G-vec00001-001-s205><build.bauen><de> Baue deine eigenes Schloss und besiege andere Spieler in taktischen Kämpfen auf einer riesigen Weltkarte.
<G-vec00001-001-s206><build.bauen><en> Build your defense and stop them now! Mighty Warriors: You can choose wizard, paladin or barbarian as your warrior and deploy them to the battlefield.
<G-vec00001-001-s206><build.bauen><de> Baue deine Verteidigung und halte sie auf!Mächtige Krieger:Wähle Magier, Paladins oder Barbaren als deine Krieger und befehlige sie auf dem Schlachtfeld.
<G-vec00001-001-s207><build.bauen><en> Build a deck around a specific legendary creature or planeswalker from the Standard card pool, and battle against friends in one-on-one or multiplayer free-for-all games.
<G-vec00001-001-s207><build.bauen><de> Baue ein Deck aus dem Standard-Kartenpool um eine bestimmte legendäre Kreatur oder einen Planeswalker herum auf und tritt in Duellen oder Multiplayer-Partien gegen einen oder mehrere Freunde an.
<G-vec00001-001-s208><build.bauen><en> Build the truck, Schnall to the driver and defeat any obstacle with the massive tires and powerful engine.
<G-vec00001-001-s208><build.bauen><de> Baue den Truck, schnall den Fahrer an und bezwinge jedes Hindernis mit den massiven Reifen und dem leistungsstarken Motor.
<G-vec00001-001-s209><build.bauen><en> Wherever possible, we take advantage of public subsidy programs to build affordable housing.
<G-vec00001-001-s209><build.bauen><de> Wir nutzen, wo es möglich ist, öffentliche Förderprogramme, um bezahlbare Wohnungen zu bauen.
<G-vec00001-001-s210><build.bauen><en> Whether you build an offshore platform or you work on a refinery shutdown, you fight daily for reducing operational downtime.
<G-vec00001-001-s210><build.bauen><de> Ob Sie eine Offshore Plattform bauen oder an einem Raffinerie Shutdown arbeiten, sie kämpfen täglich damit die Ausfallzeiten zu reduzieren.
<G-vec00001-001-s211><build.bauen><en> A few days later rumours spread that the?Brujo de Bargota?, which was Juanes' nickname, had invoked the Devil one night and had made use of evil genies to build his house in just one night.
<G-vec00001-001-s211><build.bauen><de> Tage später begann das Gerücht die Runde zu machen, dass der Hexer von Bargota, wie sie Juanes nannten, eines Nachts den Teufel angerufen habe und sich bösartiger Geister bedient habe, um in einer einzigen Nacht ein Haus zu bauen.
<G-vec00001-001-s212><build.bauen><en> The Preferred Supplier Agreements with Volvo Construction Equipment creates conditions to consolidate operations and build a new production plant in Sollentuna, Sweden.
<G-vec00001-001-s212><build.bauen><de> Aus der Zusammenarbeit als Vorzugslieferant mit Volvo Construction Equipment ergeben sich die Möglichkeiten, die operativen Abläufe zu konsolidieren und eine neue Produktionsstätte in Edsberg in Sollentuna zu bauen.
<G-vec00001-001-s213><build.bauen><en> It is planned to build one more storey (additional 90 sq m), then the total living area would be of the surface of 180 sq m. There is a marvellous sea-view from the property.
<G-vec00001-001-s213><build.bauen><de> Es ist geplant, ein weiteres Stockwerk (weitere 90 qm) zu bauen, dann ist die gesamte Wohnfläche würde der Fläche von 180 qm werden Es ist ein wunderbarer Blick aufs Meer vom Haus.
<G-vec00001-001-s214><build.bauen><en> Only 2 kms from the historical town of Alcobaca and 10 kms from the beaches (Nazare and Sao Martinho do Porto) This plot of land has a total of 1.077m2, and it is allowed to build 60% of the total size.
<G-vec00001-001-s214><build.bauen><de> Nur 2 km von der historischen Stadt Alcobaca und 10 km von den Stränden (Nazare und Sao Martinho do Porto) entfernt, hat dieses Grundstück eine Gesamtfläche von 1.077 m2, und es ist erlaubt, 60% der Gesamtgröße zu bauen.
<G-vec00001-001-s215><build.bauen><en> We may err, for we build a world with broken straws.
<G-vec00001-001-s215><build.bauen><de> Wir mögen Fehler begehen, denn wir bauen eine Welt mit gebrochenen Strohhalmen.
<G-vec00001-001-s216><build.bauen><en> All in all, the Habs will need to bring their A game against Calgary if they want to build on last Saturday’s win over the Flyers.
<G-vec00001-001-s216><build.bauen><de> Alles in allem werden die Habs benötigen, um ihre Ein Spiel gegen Calgary zu bringen, wenn sie sich auf letzten Samstag den Sieg über die Flyers bauen wollen.
<G-vec00001-001-s217><build.bauen><en> Enough space to build a pool.
<G-vec00001-001-s217><build.bauen><de> Genug Platz, um einen Pool zu bauen.
<G-vec00001-001-s218><build.bauen><en> And that ́s right – he even let them take their money with them and allowed them to import goods from Germany to build Rothschild ́s colonies in Palestine – and THE ZIONISTS HAD A TREATY WITH THE ZIONISTS ON THIS MATTER: THE HAAVARA TRANSFER AGREEMENT.
<G-vec00001-001-s218><build.bauen><de> Und das ist richtig – er ließ sie sogar nach Rothschilds Kolonien in Palästina auswandern,, ihr Geld mitnehmen und erlaubte ihnen, Waren aus Deutschland zu importieren, um die Kolonien zu bauen – und hatte einen VERTRAG MIT DEN ZIONISTEN DIESBEZÜGLICH: DAS HAAVARA TRANSFER AGREEMENT.
<G-vec00001-001-s219><build.bauen><en> The BAS program provides individuals with an associate's degree or equivalent the opportunity to build upon the foundational skills attained through their associate's degree programs by completing upper-division coursework in management and leadership practices.
<G-vec00001-001-s219><build.bauen><de> Das BAS-Programm bietet Personen mit einem Abschluss oder eine gleichwertige Gelegenheit auf die grundlegenden Fähigkeiten, die durch durch die Vollendung der oberen Abteilung Kurs in Management- und Führungspraktiken ihre Associate-Studiengänge erreicht zu bauen.
<G-vec00001-001-s220><build.bauen><en> The New Baghdad table is difficult to build, a delicate puzzle in the shape of the city map.
<G-vec00001-001-s220><build.bauen><de> Der New Baghdad-Tisch ist schwierig zu bauen, ein filigranes Puzzle in Form eines Stadtplans.
<G-vec00001-001-s221><build.bauen><en> Build a deeper tan by reapplying daily until the desired depth is achieved.
<G-vec00001-001-s221><build.bauen><de> Bauen Sie eine tiefere Bräune auf, indem Sie es täglich erneut auftragen, bis die gewünschte Farbtiefe erreicht ist.
<G-vec00001-001-s222><build.bauen><en> "Master CVV said: ""I know that you cannot build this bridge, because you are confined as by the mind of a mosquito."
<G-vec00001-001-s222><build.bauen><de> "Meister CVV sagte: ""Ich weiß, dass ihr diese Brücke nicht bauen könnt, weil ihr wie vom Denkvermögen eines Moskitos begrenzt werdet."
<G-vec00001-001-s223><build.bauen><en> Their choice depends on what you are going to build a house: switchboard or square log.
<G-vec00001-001-s223><build.bauen><de> Die Wahl hängt davon ab, was Sie vorhaben, ein Haus zu bauen: Telefonzentrale oder quadratisch Protokoll.
<G-vec00001-001-s224><build.bauen><en> 9th C Charlemagne asks his son Louis le Débonnaire to build a first tower on the island of Antros.
<G-vec00001-001-s224><build.bauen><de> Karl der Große gibt seinem Sohn Louis le Débonnaire den Auftrag, auf der Insel Antros einen Leuchtturm zu bauen.
<G-vec00001-001-s225><build.bauen><en> When a friend told me about his father's adventures during World War II flying this aircraft I was hooked: I must build this machine.
<G-vec00001-001-s225><build.bauen><de> Als mir dann ein Freund von den abenteuerlichen Geschichten die sein Vater während des zweiten Weltkrieges mit dieser Maschine erlebt hat erzählte, stand für mich fest: Dieses Flugzeug mußt du bauen.
<G-vec00001-001-s226><build.bauen><en> To counter the enemy, we need to build and safely strengthen your own castle.
<G-vec00001-001-s226><build.bauen><de> Um den Feind zu begegnen, wir brauchen, um zu bauen und sicher stärken Sie Ihre eigene Burg.
<G-vec00001-001-s227><build.bauen><en> We will explore their ideas during the guided tour and build our own models afterwards.
<G-vec00001-001-s227><build.bauen><de> Während der Kinderführung erkunden wir die Ausstellung und bauen anschließend unsere eigenen Stadtminiaturen.
<G-vec00001-001-s228><build.bauen><en> Johnny had learned how to build virtual worlds and had created this world for himself and Cleopatra to live in as it should have been.
<G-vec00001-001-s228><build.bauen><de> Johnny hat gelernt, wie man virtuelle Welten baut und diese Welt für Cleopatra und sich selbst erschaffen, damit sie so darin leben können, wie es hätte sein sollen.
<G-vec00001-001-s229><build.bauen><en> "If the CRABster does not completely conform to your needs, then DEMAN will build a ""custom winch "" for you."
<G-vec00001-001-s229><build.bauen><de> "Sollte das Windwerk CRABster Ihren Anforderungen nicht vollständig gerecht werden, dann baut DEMAN ein ""Custom Winch"" nach Maß."
<G-vec00001-001-s230><build.bauen><en> Those are the kinds of features that make tourism management drool, and as the country elevates out of its existing slump, it is likely that not only will tourism build, but that the list of Mozambique’s casinos will grow longer for sure.
<G-vec00001-001-s230><build.bauen><de> Das sind die Arten von Funktionen, die Tourismus-Management drool zu machen, und wie das Land erhebt mit seinen bestehenden Krise, ist es wahrscheinlich, dass nicht nur der Tourismus baut, sondern dass die Liste der Casinos von Mosambik wird wachsen mehr sicher.
<G-vec00001-001-s231><build.bauen><en> This project will enrich green cover and build confidence, tolerance and collaborations between organizations working among forest fringe communities to restore forests and build social mobility in the area.
<G-vec00001-001-s231><build.bauen><de> Dieses Projekt baut Vertrauen, Toleranz und Kollaborationen zwischen den Organisationen aus, die gemeinsam mit den Waldanreinergemeinschaften arbeiten.
<G-vec00001-001-s232><build.bauen><en> These basic skills, always combined with gymnastics and mobility training, are required to build up the many and various specific competition training units.
<G-vec00001-001-s232><build.bauen><de> Auf der Basis dieser Fertigkeiten, deren Training ständig mit dem Gymnastizieren und damit dem Beweglichkeitstraining der Pferde einhergeht, baut dann das komplexe Wettkampftraining auf.
<G-vec00001-001-s233><build.bauen><en> The Museum of The Future, to be opened at the end of 2019, will build on more than five years of temporary immersive exhibitions at the world-government summit in Dubai.
<G-vec00001-001-s233><build.bauen><de> Das Museum of The Future, das Ende 2019 eröffnet wird, baut auf mehr als fünf Jahren temporärer immersiver Ausstellungen auf dem Weltregierungsgipfel in Dubai auf.
<G-vec00001-001-s234><build.bauen><en> The proposed joint venture will build on the momentum of Fuse™ Technologies, AGCO’s next generation approach to precision agriculture and precision machine management.
<G-vec00001-001-s234><build.bauen><de> Das vorgeschlagene Joint Venture baut auf der Dynamik von Fuse™ Technologies, AGCOs zukunftsträchtigem Ansatz für die Präzisionslandwirtschaft und das Präzisionsmanagement von Maschinen.
<G-vec00001-001-s235><build.bauen><en> Moaning won't build a network.
<G-vec00001-001-s235><build.bauen><de> Jammern baut kein Netz.
<G-vec00001-001-s236><build.bauen><en> Take a dip, go snorkelling or build sand castles, all just 15 minutes away from the city centre.
<G-vec00001-001-s236><build.bauen><de> Springt ins kühle Wasser, übt euch im Schnorcheln oder baut Sandburgen, nur 15 Minuten vom Stadtzentrum entfernt.
<G-vec00001-001-s237><build.bauen><en> Please build a bridge between people, among people and between countries.
<G-vec00001-001-s237><build.bauen><de> Bitte baut eine Brücke zwischen den Menschen und zwischen Ländern.
<G-vec00001-001-s238><build.bauen><en> In your efforts to prepare for the fifth centenary, build on this solid foundation.
<G-vec00001-001-s238><build.bauen><de> Baut bei euren Bemühungen zur Vorbereitung der Fünfhundertjahrfeier auf diesem soliden Fundament auf.
<G-vec00001-001-s239><build.bauen><en> There is a way: Fight to mobilize labor/black immigrant power – Build workers defense guards – Break with the Democrats and build a workers party to fight for international socialist revolution.
<G-vec00001-001-s239><build.bauen><de> Es gibt einen Weg: Kämpft für die Mobilisierung der Macht von Arbeitern, Schwarzen und Einwanderern – Formiert Arbeiterverteidigungsgruppen – Brecht mit den Demokraten und baut eine Arbeiterpartei auf, um für internationale sozialistische Revolution zu kämpfen.
<G-vec00001-001-s240><build.bauen><en> Where necessary or requested by the client, IEFE will further design, build and commission test facilities with the related metrology.
<G-vec00001-001-s240><build.bauen><de> Dazu konzipiert, baut und nimmt das IEFE, wenn nötig oder vom Kunden gewünscht, Prüfstände mit der passenden Messtechnik in Betrieb.
<G-vec00001-001-s241><build.bauen><en> A Nigerian proverb states that ‘in the moment of crisis, the wise build bridges and the foolish build dams’.
<G-vec00001-001-s241><build.bauen><de> Ein nigerianisches Sprichwort sagt: In Krisenzeiten baut der Weise Brücken, der Törichte Wälle.
<G-vec00001-001-s242><build.bauen><en> Build special LEGO objects to discover new areas and items.
<G-vec00001-001-s242><build.bauen><de> Baut tolle LEGO Objekte, um neue Bereiche und Gegenstände zu entdecken.
<G-vec00001-001-s243><build.bauen><en> "Krone Easy Rider - Five tons across the range Krone continues to build its expertise in the tyre sector and has once more improved the quality of its own ""Easy Rider"" range."
<G-vec00001-001-s243><build.bauen><de> "Krone Easy Rider - Fünf Tonnen für alle Krone baut seine Kompetenz im Portfolio Reifen weiter aus und hat die Qualität seiner eigenen Baureihe ""Easy Rider"" einmal mehr verbessert."
<G-vec00001-001-s244><build.bauen><en> Some build their houses upon a rock, meaning they live according to divine principles and standards.
<G-vec00001-001-s244><build.bauen><de> Der eine baut sein Haus auf einen Felsen; er richtet sein Leben also nach göttlichen Prinzipien und Maßstäben aus.
<G-vec00001-001-s245><build.bauen><en> Faulkner’s baroque prose is of course light years away from Shalamov’s sternly purged and pared-down variety. It is hardly Faulkner’s elaborate sentence structure that appeals to Shalamov, however, but more his ability, in book after book, to conjure up a world that is completely and utterly itself, held together by an idiom of its own (a language only spoken in these books), where every single text continues to build on, and intensify, the set of symbols and motifs that run through them all.
<G-vec00001-001-s245><build.bauen><de> Was Schalamow anspricht, ist jedoch kaum dessen ausgefeilter Satzbau, sondern mehr Faulkners Fähigkeit, Buch für Buch eine vollkommen eigene Welt zu erschaffen, die durch eine gänzlich eigene Idiomatik (eine Sprache, die man nur in diesen Büchern spricht) zusammengehalten wird und in der jeder einzelne Text weiter an dem ihnen allen eigenen Symbol- und Motivkreis baut und ihn verstärkt.
<G-vec00001-001-s246><build.bauen><en> The group working with Heinz Billing build the world's most sensitive cylinder detectors in Munich and in Frascati, Italy.
<G-vec00001-001-s246><build.bauen><de> Die Gruppe um Heinz Billing baut in München und im italienischen Frascati die empfindlichsten Zylinderdetektoren weltweit.
<G-vec00001-001-s247><build.bilden><en> These business areas are recording dynamic growth and build a strong foundation for further profitable growth in the coming years.
<G-vec00001-001-s247><build.bilden><de> Diese Bereiche entwickeln sich dynamisch und bilden eine starke Grundlage für weiteres profitables Wachstum in den kommenden Jahren.
<G-vec00001-001-s248><build.bilden><en> As long as all players still have at least two cards left in their draw piles, they build - as at the start of the game - new vertical card columns for the next round.
<G-vec00001-001-s248><build.bilden><de> Haben alle Spieler nach Rundenende noch mindestens zwei Karten in ihrem Nachziehsta- pel, bilden sie - wie bei Spielbeginn - mit den obersten Karten ihrer Nachziehstapel neue senkrechte Kartenreihen für die nächste Run- de.
<G-vec00001-001-s249><build.bilden><en> Very simple compositions build a wild space and the sportive personalities build a familiar but different atmosphere.
<G-vec00001-001-s249><build.bilden><de> Sehr einfache Kompositionen bilden einen Freiraum und die sportlichen Persönlichkeiten eine vertraute, doch andersartige Atmosphäre.
<G-vec00001-001-s250><build.bilden><en> Brands build a richer, unified profile of their customers with the platform for improved behavioral targeting, testing and content recommendations.
<G-vec00001-001-s250><build.bilden><de> Mit der Plattform für verbessertes Behavioral Targeting, Testen und Content-Empfehlungen bilden Marken ein umfassenderes, einheitliches Profil ihrer Kunden.
<G-vec00001-001-s251><build.bilden><en> In addition, we are investing in management training for all managers to build and support better teams.
<G-vec00001-001-s251><build.bilden><de> Zusätzlich dazu investieren wir in Management-Trainings für alle Manager, um so bessere Teams bilden zu können.
<G-vec00001-001-s252><build.bilden><en> The trilobites build a row, it is assumed in some publications that some trilobites do marching in rows.
<G-vec00001-001-s252><build.bilden><de> Die Trilobiten bilden eine Reihe, in einigen Publikationen wird davon ausgeganen, dass einige Trilobiten manchmalquasi im Gänsemarsch gelaufen sind.
<G-vec00001-001-s253><build.bilden><en> Put in the following verbs to build meaningful sentences.
<G-vec00001-001-s253><build.bilden><de> Quiz Setzen Sie die folgenden Verben ein um sinnvolle Sätze zu bilden.
<G-vec00001-001-s254><build.bilden><en> The path they build leads to a simple wooden table with a center piece where soon a couple is about to tie the knot.
<G-vec00001-001-s254><build.bilden><de> Der Weg den sie bilden führt zu einem schlichten Holztisch mit Blumengesteck, an dem in Kürze ein Bund fürs Leben geschlossen wird.
<G-vec00001-001-s255><build.bilden><en> The results build an integral part of the mass balance approach of the EOF concept, therewith enabling to close the current gap between targeted single substance analysis and EOF measurements.
<G-vec00001-001-s255><build.bilden><de> Die Ergebnisse bilden einen Teil des Massenbilanzansatzes des EOF-Konzepts, und helfen damit die gegenwärtige Lücke zwischen Einzelstoffanalytik und EOF-Befunden zu schließen.
<G-vec00001-001-s256><build.bilden><en> A somber atmosphere and spacy soundscapes build the matrix.
<G-vec00001-001-s256><build.bilden><de> Eine düster melancholische Atmosphäre und spacige Soundteppiche bilden das Grundgerüst.
<G-vec00001-001-s257><build.bilden><en> The aim of the Minorities Initiative is to build up „minority alliances“, in order to deal with sociopolitical concerns.
<G-vec00001-001-s257><build.bilden><de> Das Ziel der Initiative Minderheiten ist es, “minoritäre Allianzen” zu bilden, um gesellschaftspolitische Anliegen durchzusetzen.
<G-vec00001-001-s258><build.bilden><en> "This mission which follows the principles of sustainable development has emerged from the original mission: ""To build and maintain long-term relationships with clients and customers by offering them unique and innovative products and services suited to their individual needs."
<G-vec00001-001-s258><build.bilden><de> "Die Mission, die mit den Prinzipien der nachhaltigen Entwicklung übereinstimmt, entstand aus der einstigen Mission mit dem Motto: ""Langfristige Beziehungen mit Kunden und Verbrauchern zu bilden und zu pflegen, in dem ihnen einzigartige innovative Produkte und Dienstleistungen angepasst an ihre individuellen Bedürfnisse, angeboten werden."
<G-vec00001-001-s259><build.bilden><en> An organization's ability to build flexible target-oriented teams is a key success factor, we are convinced.
<G-vec00001-001-s259><build.bilden><de> Die Möglichkeit einer Organisation, flexible zielorientierte Teams zu bilden, ist ein Schlüssel-Erfolgsfaktor, sind wir überzeugt.
<G-vec00001-001-s260><build.bilden><en> And it is very important to practise this mutual support, to learn how to accept the other as the other in his otherness, and to learn that he has to support me in my otherness, in order to become “we”, so that we can also build community in the parish, calling people into the community of the word, and journeying with one another towards the living God.
<G-vec00001-001-s260><build.bilden><de> Und gerade das Sich-Ertragen einüben ist etwas ganz Wichtiges; das Lernen, den anderen anzunehmen als den anderen in seiner Andersheit, und zu erlernen, daß er mich ertragen muss in meiner Andersheit, um „wir“ zu werden, damit wir einmal dann auch in der Pfarrei Gemeinschaft bilden können, Menschen in die Gemeinsamkeit des Wortes hineinrufen können und miteinander auf dem Weg zum lebendigen Gott sind.
<G-vec00001-001-s261><build.bilden><en> One of the aims of the Convention on Biological Diversity (CBD) is to build awareness of the value of biodiversity.
<G-vec00001-001-s261><build.bilden><de> Das Bewusstsein für den Wert der biologischen Vielfalt zu bilden, ist eines der wichtigen Ziele des Übereinkommens über die biologische Vielfalt (Convention on Biological Diversity, CBD).
<G-vec00001-001-s262><build.bilden><en> The doctor guides the little surgeons over to the X-ray pictures and explains how calcium deposits build up kidney stones.
<G-vec00001-001-s262><build.bilden><de> Der Arzt führt die Chirurginnen zum Röntgenbild und erläutert, wie Kalziumablagerungen in den Nieren Steine bilden.
<G-vec00001-001-s263><build.bilden><en> Suitable for both males and females; utilize it during cutting cycles to keep lean, high quality muscular tissue and also to build the excellent beach physique.
<G-vec00001-001-s263><build.bilden><de> Ideal für Männer und Frauen; Nutzen sie im gesamten schneiden Zyklen zu mager, halten Qualität Muskel Gewebe und auch zu bilden die ideale Küste-Figur.
<G-vec00001-001-s264><build.bilden><en> His great mission is to build a bridge between East and West and to bring the Light from the East to the West.
<G-vec00001-001-s264><build.bilden><de> Seine große Mission ist es, eine Brücke zwischen Ost und West zu bilden und das Licht vom Osten in den Westen zu bringen.
<G-vec00001-001-s265><build.bilden><en> Each genome contains all of the hereditary information needed to build and maintain that organism.
<G-vec00001-001-s265><build.bilden><de> Jedes Genom enthält alle vererbbaren Informationen, die benötigt werden, um einen Organismus zu bilden und aufrechtzuerhalten.
<G-vec00001-001-s304><build.entwickeln><en> So we eventually took the somewhat brave decision that, as part of our contribution to the project, we would build our own.
<G-vec00001-001-s304><build.entwickeln><de> Daher trafen wir schließlich die recht mutige Entscheidung, als Teil dieses Projektes unser eigenes Programm hierfür zu entwickeln.
<G-vec00001-001-s305><build.entwickeln><en> The developer encourages everyone to build own boards as descriped shortly in the documentation.
<G-vec00001-001-s305><build.entwickeln><de> Es wird dazu ermuntert, auch selber eigene Boards zu entwickeln, was auch kurz in der Dokumentation erklärt wird.
<G-vec00001-001-s306><build.entwickeln><en> QuAI enables data scientists and developers to quickly build, train, optimize, and deploy machine-learning models with high-performance machine-learning algorithms that come with a wide range of supported AI frameworks on top of QNAP's robust NAS.
<G-vec00001-001-s306><build.entwickeln><de> QuAI ermöglicht es Datenwissenschaftlern und Entwicklern, schnell und einfach Maschinen-Lernmodelle mit leistungsstarken Algorithmen für das maschinelle Lernen zu entwickeln, zu trainieren, zu optimieren und einzusetzen, die mit einer breiten Palette von unterstützten KI-Frameworks auf dem zuverlässigen NAS von QNAP ausgeliefert werden.
<G-vec00001-001-s307><build.entwickeln><en> We build our products to consistently and reliably deliver results.
<G-vec00001-001-s307><build.entwickeln><de> Wir entwickeln unsere Produkte so, dass sie durchgängig und zuverlässig Ergebnisse liefern.
<G-vec00001-001-s308><build.entwickeln><en> Because He came before Shri Krishna, He tried to build up the inner side of a human being.
<G-vec00001-001-s308><build.entwickeln><de> Da er vor Shri Krishna kam, versuchte er die innere Seite der Menschen zu entwickeln.
<G-vec00001-001-s309><build.entwickeln><en> But we cannot underestimate that the business model is completely different and takes a disproportionate amount of resources in sales and marketing operations to build and grow this recurring revenue that the VC community actually loves when it actually occurs.
<G-vec00001-001-s309><build.entwickeln><de> Aber man darf nicht unterschätzen, dass das Geschäftsmodell komplett anders ist, und dass es unverhältnismäßig viele Ressourcen für Vertriebs- und Marketingaktivitäten in Anspruch nimmt, um diesen wiederkehrenden Umsatz, den die VC-Gemeinschaft liebt, wenn es tatsächlich passiert, zu entwickeln und weiter auszubauen.
<G-vec00001-001-s310><build.entwickeln><en> Additionally, if you build mobile apps, Google Analytics offers Software Development Kits for iOS and Android so that you can measure how people use your app.
<G-vec00001-001-s310><build.entwickeln><de> Wenn Sie auch mobile Apps entwickeln, bietet Google Analytics Softwareentwicklungs-Kits für iOS und Android, damit Sie analysieren können, wie Ihre App genutzt wird.
<G-vec00001-001-s311><build.entwickeln><en> Build sophisticated installations in record time without any programming or scripting skills.
<G-vec00001-001-s311><build.entwickeln><de> Entwickeln Sie anspruchsvolle Installationen in Rekordzeit, ohne Programmier- oder Scripting-Kenntnisse.
<G-vec00001-001-s312><build.entwickeln><en> Build and deploy your own applications for the Internet of Things (IoT) on the SAP Cloud Platform – our in-memory IoT platform-as-a-service (PaaS).
<G-vec00001-001-s312><build.entwickeln><de> Internet of Things (IoT): Entwickeln und implementieren Sie Ihre eigenen Anwendungen auf der SAP In-Memory-Platform-as-a-Service (PaaS) für IoT.
<G-vec00001-001-s313><build.entwickeln><en> Let us work with you to build a solution to fit your needs.
<G-vec00001-001-s313><build.entwickeln><de> Kontakt Lassen Sie uns eine Lösung für Sie entwickeln, die auf Ihre Anforderungen abgestimmt ist.
<G-vec00001-001-s314><build.entwickeln><en> It took POST Luxembourg less than six weeks to build a fully customized and secure IoT offering using Software AG's Cumulocity IoT.
<G-vec00001-001-s314><build.entwickeln><de> POST Luxembourg benötigte weniger als sechs Wochen, um mit Cumulocity IoT eine IoT-Lösung zu entwickeln, mit der sie Millionen Geräte sicher und schnell vernetzen und registrieren kann.
<G-vec00001-001-s315><build.entwickeln><en> 2011: Cornell University began to build 3D food printer.
<G-vec00001-001-s315><build.entwickeln><de> 2011: Die Cornell University beginnt, 3D-Lebensmitteldrucker zu entwickeln.
<G-vec00001-001-s316><build.entwickeln><en> An additional offset hole, FCC-00 30, was drilled for a total of four holes to build and support the southern extension target.
<G-vec00001-001-s316><build.entwickeln><de> Eine zusätzliche versetzte Bohrung, FCC-0030, wurde für insgesamt vier Bohrlöcher angesetzt, um das Zielgebiet Southern Expansion weiter zu entwickeln und zu unterstützen.
<G-vec00001-001-s317><build.entwickeln><en> In the application economy, every enterprise must be able to build and release new applications, quickly and securely.
<G-vec00001-001-s317><build.entwickeln><de> In der App-Economy müssen alle Unternehmen in der Lage sein, neue Applikationen schnell und sicher zu entwickeln und zu veröffentlichen.
<G-vec00001-001-s318><build.entwickeln><en> Student teams are given a kit of biological parts at the beginning of the summer from the Registry of Standard Biological Parts. Working at their own schools over the summer, they use these parts and new parts of their own design to build biological systems and operate them in living cells.
<G-vec00001-001-s318><build.entwickeln><de> Studentische Teams erhalten ein Kit mit biologischen Teilen Anfang des Sommers, arbeiten dann in ihren Hochschulen indem sie diese Teile benutzen sowie neue Teile selber gestalten, um biologische Systeme zu entwickeln und sie in lebenden Zellen operieren zu lassen.
<G-vec00001-001-s319><build.entwickeln><en> This really helped us to build a very full range of technologies to serve our end market.
<G-vec00001-001-s319><build.entwickeln><de> Dies hat uns wirklich sehr geholfen, eine sehr umfassende Palette von Technologien für unseren Zielmarkt zu entwickeln.
<G-vec00001-001-s320><build.entwickeln><en> I am youth leader in our local unit and teach and help the lads between 12 and 18 build strong moral character and faith in God and learning to love and serve others.
<G-vec00001-001-s320><build.entwickeln><de> Ich bin Jugendleiter in unserer örtlichen Gemeinde, und ich unterrichte die Jungs zwischen 12 und 18 und helfe ihnen, einen moralisch starken Charakter und Glauben an Gott zu entwickeln und zu lernen, andere zu lieben und ihnen zu dienen.
<G-vec00001-001-s321><build.entwickeln><en> To ensure the sustainability of its activities, Terre des hommes intends to build the capacity of the youth by training them on basic topics such as project management, accounting, fundraising etc.
<G-vec00001-001-s321><build.entwickeln><de> Um die Nachhaltigkeit der Aktivitäten sicherzustellen, möchte Terre des hommes die Kompetenzen dieser jungen Menschen entwickeln und ihnen Ausbildungen in den Bereichen Projektmanagement und Buchhaltung anbieten.
<G-vec00001-001-s322><build.entwickeln><en> This is extremely pleasure in order to help you locating the right item to build your boy a healthy diet.
<G-vec00001-001-s322><build.entwickeln><de> Das ist wirklich die Zufriedenheit Sie Ortung das entsprechende Element zu helfen, Ihr Kind eine gesunde Ernährung zu entwickeln.
<G-vec00179-001-s307><build.entwickeln><en> We build our products to consistently and reliably deliver results.
<G-vec00179-001-s307><build.entwickeln><de> Wir entwickeln unsere Produkte so, dass sie durchgängig und zuverlässig Ergebnisse liefern.
<G-vec00001-001-s342><build.erbauen><en> She took a white dove, blessed it and promised to build a church at the place the dove went after its release.
<G-vec00001-001-s342><build.erbauen><de> Sie nahm eine weiße Taube, segnete sie und versprach, eine Kirche an dem Ort zu erbauen, zu dem die Taube fliegen würde.
<G-vec00001-001-s343><build.erbauen><en> One day, the Holy One, throwing an ax into the air and to build a church in the place where the ax had arisen decided.
<G-vec00001-001-s343><build.erbauen><de> Eines Tages beschloss der Heilige, ein Beil in die Luft zu werfen und an die Stelle eine Kirche zu erbauen, an der das Beil aufgekommen war.
<G-vec00001-001-s344><build.erbauen><en> Cleopatra, queen of Egypt, has bet Julius Caesar that her people could build him a sumptuous palace within three months.
<G-vec00001-001-s344><build.erbauen><de> Kleopatra, die Königin Ägyptens, hat mit Julius Cäsar gewettet, ihr Volk könnte ihr in drei Monaten einen prunkvollen Palast erbauen.
<G-vec00001-001-s345><build.erbauen><en> He build a house for himself and his soldiers then the village grew bigger and bigger.
<G-vec00001-001-s345><build.erbauen><de> Nachdem er seine Residenz und die Häuser seiner Soldaten erbauen ließ, wuchs das Dorf nach und nach zu.
<G-vec00001-001-s346><build.erbauen><en> Our goals relate primarily to the fact, that we build you a house which will be sufficient for your needs, will give you a feeling of security and will be worthy of the word HOME.
<G-vec00001-001-s346><build.erbauen><de> Unsere Ziele beziehen sich vor allem auf die Tatsache, dass wir Ihnen ein Haus erbauen wollen, das Ihren Bedürfnissen ausreichen wird und Ihnen ein Gefühl von Sicherheit geben wird und sich des Wortes ZUHAUSE würdig erwiesen wird.
<G-vec00001-001-s347><build.erbauen><en> Build your society of the future, colonize islands, and create sprawling megacities with multitudes of buildings, vehicles, and resources to manage.
<G-vec00001-001-s347><build.erbauen><de> Ebnen Sie den Weg für die Gesellschaft der Zukunft, besiedeln Sie Inseln und erbauen Sie aufblühende Metropolen, in denen Sie eine Vielzahl von Gebäuden, Fahrzeugen und Ressourcen verwalten.
<G-vec00001-001-s348><build.erbauen><en> We follow your desires and needs and strive in particular to build you a house, where you will always return with a smile on your face and happy, that you have it.
<G-vec00001-001-s348><build.erbauen><de> Wir folgen Ihren Wünschen und Bedürfnissen und bemühen uns vor allem um Ihnen ein Haus zu erbauen, in das Sie immer wieder lächelnd und glücklich, dass Sie es haben, zurückkehren werden.
<G-vec00001-001-s349><build.erbauen><en> This deep disappointment did not let him go and he started to build a monument for his lost love - the Coral Castle.
<G-vec00001-001-s349><build.erbauen><de> Diese tiefe Enttäuschung ließ ihn nicht mehr los und er begann für seine verlorene Liebe ein Monument zu erbauen – das Coral Castle.
<G-vec00001-001-s350><build.erbauen><en> If the old pharaohs had not pondered for long enough, how to build these structures as institutions to preserve their secret arts and sciences - buildings which were not be destroyed by the ravages of time for thousands of years - those pyramids would not now stand as monuments of the primordial skills of their constructors; but because these men did nurture their original concepts for years before they were transformed into a final design and brought it to maturity in this way, it is therefore understandable how these ideas were consolidated and given reality so that the traveller is filled with amazement to this day.
<G-vec00001-001-s350><build.erbauen><de> Hätten die alten Pharaonen nicht lange genug nachgedacht, solche Gebäude als Bewahranstalten für ihre Geheimkünste und Wissenschaften zu erbauen, die der Zahn der Zeit Jahrtausende hindurch nicht zerstören solle, so ständen diese Pyramiden nimmer als Denkmäler der Urbaukunst; aber weil die Erbauer zuvor ihre einmal gefasste und in eine volle Form übergegangene Idee jahrelang genährt und auf diese Weise zu einer Reife gebracht haben, so ist es denn auch begreiflich, warum ihre in die Materie übersetzte Idee noch heute den Wanderer mit Staunen erfüllt.
<G-vec00001-001-s351><build.erbauen><en> The Count of Artois accepted Queen Marie-Antoinette's challenge to build a small chateau in the Bois de Boulogne in less than 64 days.
<G-vec00001-001-s351><build.erbauen><de> Der Graf von Artois nahm die Herausforderung Marie-Antoinettes an, im Bois de Boulogne in weniger als 64 Tagen ein kleines Schloss zu erbauen.
<G-vec00001-001-s352><build.erbauen><en> With abundant energy, loud drums, pounding bass, subdued delay guitars and the unmistakeable, versatile voice of their singer, they build a sound wall that inspires the audience for a moment before forcefully pressing them down on the floor again in the next.
<G-vec00001-001-s352><build.erbauen><de> Mit viel Energie, lauten Drums, drückendem Bass, verhallten Delay-Gitarren und der unverkennbaren, vielseitigen Stimme ihres Sängers, erbauen sie eine klangliche Wand, die den Besucher ihrer Shows in einem Moment innerlich beflügelt und im anderen Moment wieder kraftvoll zu Boden drückt.
<G-vec00001-001-s353><build.erbauen><en> """When in this way you will as soon as possible build this temple for Me, erecting in the center of the same an altar for burnt offerings, also made from pure gold, and will on each Sabbath in the evening burn an offering of grain to Me, I shall bless all the fields of the lowlands and they will bear a hundredfold fruit for you and your people."
<G-vec00001-001-s353><build.erbauen><de> Wenn du nun auf diese Weise Mir wirst diesen Tempel baldmöglichst erbauen und wirst in der Mitte desselben errichten einen Brandopferaltar, ebenfalls aus reinem Golde angefertigt, und wirst Mir an jedem Sabbate abends ein Getreideopfer abbrennen, so werde Ich alle Felder der Tiefe segnen, und sie werden dir und deinem Volke hundertfältige Früchte tragen.
<G-vec00001-001-s354><build.erbauen><en> To in truth build a genuine paradise, a world of abundance and love, you have to face all the old attitudes, limiting thought prisons, and emotional prisons that you are in, and leave them behind.
<G-vec00001-001-s354><build.erbauen><de> Um in Wahrheit ein wirkliches Paradies zu erbauen, eine Welt der Fülle und Liebe, müsst ihr euch alle alten Einstellungen vornehmen, alle begrenzenden Gedankengefängnisse und emotionalen Gefängnisse, in denen ihr seid und sie hinter euch lassen.
<G-vec00001-001-s355><build.erbauen><en> want to build within us, we returned to our closer homeland.
<G-vec00001-001-s355><build.erbauen><de> in uns erbauen wollen, sind wir in die engere Heimat zurückgekehrt.
<G-vec00001-001-s356><build.erbauen><en> 32 Now, brothers, I entrust you to God, and to the word of his grace, which is able to build up, and to give you the inheritance among all those who are sanctified.
<G-vec00001-001-s356><build.erbauen><de> 32 Und nun, liebe Brüder, ich befehle euch Gott und dem Wort seiner Gnade, der da mächtig ist, euch zu erbauen und zu geben das Erbe unter allen, die geheiligt werden.
<G-vec00001-001-s357><build.erbauen><en> In the year 1858 the physician Dr. Heggli had let build in Zugerland a nursing centre for patients wanting a rest.
<G-vec00001-001-s357><build.erbauen><de> Im Jahre 1858 hatte der Arzt Dr. Heggli im Zugerland ein Kurhaus für erholungsbedürftige Patienten erbauen lassen.
<G-vec00001-001-s358><build.erbauen><en> So it is that even in the history of a promise, in a springtime moment, the commitment of the one who must sow the Word with Christ and, as we say, build the Church, continues to be difficult.
<G-vec00001-001-s358><build.erbauen><de> Auch in einem verheißungsvollen Moment der Geschichte, des Frühlings, ist die Arbeit dessen, der mit Christus das Wort aussäen und – sagen wir – die Kirche erbauen muss, schwierig.
<G-vec00001-001-s359><build.erbauen><en> From the podium of the massive November 4 demonstration writer Stefan Heym was enthusiastically received when he said, “Socialism, not Stalinist but the real thing, which we want to finally build, for our benefit and that of all Germany, is unthinkable without democracy.” The defense of collectivized property in East Germany requires its extension to the West.
<G-vec00001-001-s359><build.erbauen><de> Stefan Heym löste auf der riesigen Demonstration am 4.November Begeisterung aus, als er vom Podium aus sagte: „Der Sozialismus – nicht der Stalinsche, sondern der richtige – den wir endlich erbauen wollen, zu unserem Nutzen und zum Nutzen ganz Deutschlands, ist nicht denkbar ohne Demokratie.“ Die Verteidigung der vergesellschafteten Eigentumsformen in der DDR erfordert ihre Ausdehnung in den Westen.
<G-vec00001-001-s360><build.erbauen><en> [MO 2.3] First of all, this gas makes them so light that they can jump effortlessly over any river, given that, due to the absence of timber, they cannot build bridges over the rivers.
<G-vec00001-001-s360><build.erbauen><de> [MO 2.3] Fürs erste macht dieses Gas sie leicht, so daß sie wegen des Mangels an Bauholz, vermöge dessen sie keine Brücke über die Flüsse erbauen können, sehr leicht über jeden Fluss hinwegspringen können.
<G-vec00001-001-s361><build.errichten><en> Generally, you would find the keywords for niche topics with a low R/S value, build a theme around these keywords and work out a mini website of around 20 to 50 pages.The key to such a website is written content.In many cases, I found reprint rights articles were also used and these were also sites that were successful in bringing in consistent traffic and revenue.
<G-vec00001-001-s361><build.errichten><de> Im Allgemeinen würden Sie die Schlüsselwörter für Nische Themen mit einem niedrigen R/S Wert finden, ein Thema um diese Schlüsselwörter errichten und ausarbeiten eine Miniweb site von herum 20 bis 50 Seiten.Der Schlüssel zu solch einer Web site schriftlich Inhalt.In vielen Fällen fand ich Neuauflage Rechte, die Artikel auch benutzt wurden und diese waren auch Aufstellungsorte, die beim Holen in gleichbleibenden Verkehr und in Einkommen erfolgreich waren.
<G-vec00001-001-s362><build.errichten><en> Under the terms of the joint venture agreement, the two parent companies will build a world-scale organometallics production facility strategically located in the Arabian Gulf Industrial City of Al-Jubail.
<G-vec00001-001-s362><build.errichten><de> Die Joint Venture-Vereinbarung sieht vor, dass die beiden Muttergesellschaften am strategischen Standort der Industriestadt Al-Jubail am Arabischen Golf eine Produktionsanlage für metallorganische Verbindungen auf Weltklasseniveau errichten werden.
<G-vec00001-001-s363><build.errichten><en> You can build your partnership with your daycare by volunteering your time, contributing goods or services, or donating money.
<G-vec00001-001-s363><build.errichten><de> Sie können Ihre Teilhaberschaft mit Ihrer Kindertagesstätte errichten, indem Sie Ihre Zeit, beitragenden Waren oder Dienstleistungen oder Spenden des Geldes freiwillig erbieten.
<G-vec00001-001-s364><build.errichten><en> [18] Similarly, large British companies like Unilever and ICI are finding it increasingly profitable to build subsidiaries all over the world.
<G-vec00001-001-s364><build.errichten><de> Ähnlich finden auch große britische Firmen wie Unilever und ICI es in immer stärkerem Maße ertragreich, Zweigwerke in der ganzen Welt zu errichten.
<G-vec00001-001-s365><build.errichten><en> When you write your article, you'll have the opportunity to include a resource box at the end of your article and this is where you can capitalize on your chance to build link reputation.
<G-vec00001-001-s365><build.errichten><de> Wenn Sie Ihren Artikel schreiben, haben Sie die Gelegenheit, einen Hilfsmittelkasten am Ende Ihres Artikels mit einzuschließen und dieser ist, wo Sie auf Ihrer Wahrscheinlichkeit gross schreiben können, Verbindung Renommee zu errichten.
<G-vec00001-001-s366><build.errichten><en> "- ""Frustrated people are unable to build a free state."
<G-vec00001-001-s366><build.errichten><de> "- ""Enttäuschte Menschen sind nicht in der Lage einen freien Staat zu errichten."
<G-vec00001-001-s367><build.errichten><en> You'll need to build the infrastructure necessary to gather raw materials and energy supplies.
<G-vec00001-001-s367><build.errichten><de> Zuerst müssen Sie die nötige Infrastruktur errichten, um die Versorgung mit Rohstoffen und Energie sicherzustellen.
<G-vec00001-001-s368><build.errichten><en> Further you learn how to build a self-made shell the hands.
<G-vec00001-001-s368><build.errichten><de> Weiter erkennen Sie, wie das selbstgemachte Geschoss von den Händen zu errichten.
<G-vec00001-001-s369><build.errichten><en> We can design and build your cargo terminal with our friends in the baggage and cargo handling industries.
<G-vec00001-001-s369><build.errichten><de> Wir können Ihr Frachtterminal entwickeln und errichten und arbeiten dabei mit unseren Freunden aus der Gepäck- und Frachttransportbranche zusammen.
<G-vec00001-001-s370><build.errichten><en> This is why I decided to build an orchid forum...so people looking for help could find information and ask questions.
<G-vec00001-001-s370><build.errichten><de> Deshalb entschied ich, ein Orchideeforum zu errichten…, also das Suchen nach Hilfe bevölkeren könnte Informationen finden und Fragen stellen.
<G-vec00001-001-s371><build.errichten><en> When he returned to Mongolia in 1651, hundreds of Tibetian lamas and many artists and craftsmen, sent by the Fifth Dalai Lama to propagate the faith and to build new monasteries, accompanied him.
<G-vec00001-001-s371><build.errichten><de> Bei seiner Rückkehr in die Mongolei im Jahr 1651 begleiteten ihn Hunderte von tibetischen Lamas und viele Künstler und Handwerker, die vom Fünften Dalai Lama geschickt worden waren, um den Glauben zu verbreiten und neue Klöster zu errichten.
<G-vec00001-001-s372><build.errichten><en> If you had your own way to build your list and added your own web site, then you have COMPLETE OWNERSHIP.
<G-vec00001-001-s372><build.errichten><de> Wenn Sie Ihre eigene Weise hatten, Ihre Liste zu errichten und Ihre Selbst addierten Web site, dann haben Sie KOMPLETTEN BESITZ.
<G-vec00001-001-s373><build.errichten><en> Wikidata will build an infrastructure that will enable other Wikimedia projects to access centralized data, in a manner similar to how Wikimedia Commons today provides multimedia files.
<G-vec00001-001-s373><build.errichten><de> Wikidata wird eine Infrastruktur errichten, die es den anderen Wikimedia-Projekten ermöglicht, auf zentrale Daten zuzugreifen, ähnlich wie es Wikimedia Commons heute für Multimediadateien anbietet.
<G-vec00001-001-s374><build.errichten><en> Perhaps the community members say that their priority goal is to build a clinic.
<G-vec00001-001-s374><build.errichten><de> Vielleicht sagen die Gemeindemitglieder, ihre Priorität sei es, eine Klinik zu errichten.
<G-vec00001-001-s375><build.errichten><en> What he did achieve, was to build a nation out of over a hundred tribes and create the most peaceful country in a region of great social and political turbulence.
<G-vec00001-001-s375><build.errichten><de> Was er jedoch erreichte, war, aus über einhundert Stämmen eine Nation zu errichten und eines der friedlichsten Länder in einer Region zu schaffen, die ständig von großen sozialen und politischen Unruhen heimgesucht wird.
<G-vec00001-001-s376><build.errichten><en> SCOLA: To an existence worthy of the name, in which the intangible and sacred value of the person - in itself and in its relations - be recognized, and in which the possibility is revealed for mankind to build a society of the good life, in which the personal dimension and the social dimension are simultaneously pursued and the data constitutive of the elementary experience of mankind are not neglected: the affections, work, rest.
<G-vec00001-001-s376><build.errichten><de> SCOLA: Zu einer Existenz, die diesen Namen auch verdient, in der der greifbare und sakrosankte Wert der Person – in sich selbst und in ihren Beziehungen – anerkannt wird, in der sich dem Menschen die Chance bietet, eine Gesellschaft guten Lebens zu errichten, deren persönlicher und sozialer Dimension Rechnung getragen wird und wo man auch die konstitutiven Gegebenheiten der grundlegenden Erfahrung des Menschen nicht vernachlässigt: die Gefühle, die Arbeit, die Freizeit.
<G-vec00001-001-s377><build.errichten><en> Fortunately, Antoni Gaudi was supported by the industrialist Eusebi Güell and he could thus many buildings of timeless beauty build, which were of course more expensive than simple finishing buildings.
<G-vec00001-001-s377><build.errichten><de> Glücklicherweise wurde Antoni Gaudi durch den Industriellen Eusebi Güell unterstützt und er konnte dadurch viele Bauwerke von zeitloser Schönheit errichten, die natürlich etwas teurer waren als einfache Schlichtbauten.
<G-vec00001-001-s378><build.errichten><en> Poker Table Plans Here we've put together a collection of poker table plans that you should find useful if you're looking to build your own poker table or other poker furniture.
<G-vec00001-001-s378><build.errichten><de> Hier haben wir eine Ansammlung Poker-Tisch-Pläne zusammengefügt, daß Sie nützlich finden sollten, wenn Sie schauen, um Ihre eigene Poker-Tisch oder andere Pokermöbel zu errichten.
<G-vec00001-001-s379><build.errichten><en> The ZARGES employees at the Weilheim factory were flabbergasted to discover in the spring that a pair of storks had begun to build a nest on the heating pipe of an assembly hall.
<G-vec00001-001-s379><build.errichten><de> Da staunten die ZARGES-Mitarbeiter im Weilheimer Werk nicht schlecht: Im Frühjahr hatte ein Storchenpaar begonnen, auf dem Heizungsrohr einer Montagehalle ein Nest zu errichten.
<G-vec00001-001-s380><build.errichten><en> It took two years to build the bear from 2003 to 2005.
<G-vec00001-001-s380><build.errichten><de> "Der Bär wurde in den Jahren von 2003-2005 durch die Arbeitsgemeinschaft ""Sveg"" errichtet."
<G-vec00001-001-s381><build.errichten><en> By performing body building exercises just a few days each week you can increase your stamina and metabolism, and build lean, strong muscles.
<G-vec00001-001-s381><build.errichten><de> Indem es durchführt, übt Körpergebäude gerade einige Tage jede Woche, die Sie Ihr stamina und Metabolismus erhöhen können aus und errichtet die mageren, starken Muskeln.
<G-vec00001-001-s382><build.errichten><en> 2007-11-13 22:16:19 - How to make it easy for your web designer to build your website You have an idea for a website and you are now looking for somebody to build you the site.
<G-vec00001-001-s382><build.errichten><de> 2007-11-13 22:16:19 - Wie Man Ihn Einfach Bildet, Damit Ihr Netz-Entwerfer Ihre Web site Errichtet Sie haben eine Idee für eine Web site und Sie suchen jetzt jemand, um Sie zu errichten der Aufstellungsort.
<G-vec00001-001-s383><build.errichten><en> "The columnist gets to the question of positive identity with this statement: ""He's.... the kind of guy who likes to play poker, watch football, hunt white-tailed deer, call turkeys, play golf, spend a few bucks at a strip club once in a blue moon, change his own oil and build things."
<G-vec00001-001-s383><build.errichten><de> Der Feuilletonist gelangt an die Frage der positiven Identität mit dieser Aussage: Er ist.... die Art des Kerls, der Schürhaken, Uhrfußball, Jagd spielen mag weiß-angebundene Rotwild, Anruftruthähne, Spielgolf, ausgibt einige Dollars an einer Streifenverein einmal in einem blauen Mond, ändert sein eigenes Öl und errichtet Sachen.
<G-vec00001-001-s384><build.errichten><en> The dam itself is build exactly on the rapids.
<G-vec00001-001-s384><build.errichten><de> Dieser ist genau auf den Stromschnellen errichtet, so daß man fast nur noch den Damm sieht.
<G-vec00001-001-s385><build.errichten><en> In the coming year the plan is to build the first industrial plant, aimed at accessing the large raw-material potential.
<G-vec00001-001-s385><build.errichten><de> Auf dieser Basis soll im kommenden Jahr die erste industrielle Produktionsanlage errichtet werden, um das große Wertstoffpotential zu erschließen.
<G-vec00001-001-s386><build.errichten><en> The vicarage was accommodated in the former villa and the church was build on the vineyard.
<G-vec00001-001-s386><build.errichten><de> In der ehemaligen Villa ist das Pfarrhaus untergebracht, auf dem Weinberg wurde die Kirche errichtet.
<G-vec00001-001-s387><build.errichten><en> The stronger the foundation, then when the time comes to build a building, the taller it can go, the more stable it will be.
<G-vec00001-001-s387><build.errichten><de> Je stärker diese Grundlage ist, desto größer kann das Gebäude sein, das darauf errichtet wird, wenn die Zeit dafür gekommen ist und umso stabiler wird es auch sein.
<G-vec00001-001-s388><build.errichten><en> 2007-11-13 22:16:19 - Writing internal newsletters: how to build your network and your reputation To help build your profile and reputation within a large company create or contribute to, an internal newsletter.
<G-vec00001-001-s388><build.errichten><de> 2007-11-13 22:16:19 - Schreiben Der Internen Rundschreiben: Wie man Ihr Netz und Ihr Renommee errichtet Um zu helfen Ihr Profil und Renommee innerhalb einer großen Firma zu errichten verursachen Sie oder tragen Sie zu, ein internes Rundschreiben bei.
<G-vec00001-001-s389><build.errichten><en> SCHWENK took over the plant in 1990 and tore down the existing systems to build an entirely new plant.
<G-vec00001-001-s389><build.errichten><de> Nach der Wende hat SCHWENK es im Jahr 1990 übernommen, die bestehenden Anlagen abgerissen und ein komplett neues Werk errichtet.
<G-vec00001-001-s390><build.errichten><en> Xing LinkedIn Stuttgart and Dresden, Germany – Continuing its course of investing heavily in Germany, Bosch is to build a wafer fab in Dresden.
<G-vec00001-001-s390><build.errichten><de> Xing LinkedIn Stuttgart/Dresden – Bosch investiert weiter kräftig in Deutschland und errichtet eine Chipfabrik in Dresden.
<G-vec00001-001-s391><build.errichten><en> Build strategic Headquarters in your outpost.
<G-vec00001-001-s391><build.errichten><de> Errichtet ein strategisches Hauptquartier in Eurem Außenposten.
<G-vec00001-001-s392><build.errichten><en> You don't need four or five recreation rooms, you only need one, and once it is build, you pay the loan and it's finished.
<G-vec00001-001-s392><build.errichten><de> Man braucht nicht vier oder fünf Gemeinschaftshäuser, man braucht nur eins, und sobald es errichtet ist, bezahlt man den Kredit ab und die Sache ist erledigt.
<G-vec00001-001-s393><build.errichten><en> So not only does this drug help to build muscle, it can help to burn fat.
<G-vec00001-001-s393><build.errichten><de> Errichtet diese Drogenhilfe so nicht nur Muskel, es kann helfen, Fett zu brennen.
<G-vec00001-001-s394><build.errichten><en> A Silicon Mine is build on an asteroid, where it is to mine it.
<G-vec00001-001-s394><build.errichten><de> Eine Siliziummine wird auf einem Asteroiden errichtet, wo sie Silizium abbaut.
<G-vec00001-001-s395><build.errichten><en> Besides building drinking water wells, sanitary facilities and two junior schools, GIZ and its partner, the Afghan Ministry of Refugees and Repatriation, have supported 725 families by setting up temporary housing and providing materials for people to build their own homes.
<G-vec00001-001-s395><build.errichten><de> Neben dem Bau von Trinkwasserbrunnen, sanitären Einrichtungen und zwei Grundschulen hat die GIZ als Partner des afghanischen Ministeriums für Flüchtlinge und Repatriierung 725 Familien temporäre Unterkünfte errichtet oder Materialien für den eigenständigen Hausbau zur Verfügung gestellt – für weitere 500 Familien ist dies in den Jahren 2017 und 2018 vorgesehen.
<G-vec00001-001-s396><build.errichten><en> The main difference to the British projects: Closed refugee camps should be build inside the (extended) EU .
<G-vec00001-001-s396><build.errichten><de> Unterschied zu den britischen Plänen: Die Lager sollten innerhalb der Grenzen der (erweiterten) EU statt außerhalb errichtet werden.
<G-vec00001-001-s397><build.errichten><en> All our previous attempts to grow vegetables failed because the goats that jumped over low fence and ruined what we had struggled to build.
<G-vec00001-001-s397><build.errichten><de> Sind doch all unsere bisherigen Versuche im Gemüsebau an den Ziegen gescheitert die über den zu niedrigen Zaun gesprungen sind und verwüstet haben was wir mühsam errichtet hatten.
<G-vec00001-001-s398><build.errichten><en> This steroid will not build a lot of mass despite a massive anabolic rating; in fact, it really won't do much at all for mass promotion.
<G-vec00001-001-s398><build.errichten><de> Dieses Steroid errichtet nicht viel Masse trotz einer enormen aufbauenden Bewertung; tatsächlich tut es wirklich nicht viel überhaupt für Massenförderung.
<G-vec00001-001-s418><build.erstellen><en> We're excited to release our newest offering, Acquia Lift Starter, a starter pack to help companies build robust customer profiles that are the foundation for every customer journey and successful personalization strategy.
<G-vec00001-001-s418><build.erstellen><de> Wir freuen uns, unser neuestes Produkt, Acquia Lift Starter, vorstellen zu können, ein Starter-Paket, das Unternehmen hilft, robuste Kundenprofile zu erstellen, die die Grundlage für jede Kundenreise und erfolgreiche Personalisierungsstrategie bilden.
<G-vec00001-001-s419><build.erstellen><en> We’ll then build a bespoke glossary for your content to ensure that the translated content is consistent, accurate and of a high standard, regardless of the number of linguists actively working on the project.
<G-vec00001-001-s419><build.erstellen><de> Als Nächstes erstellen wir ein auf Ihre Inhalte zugeschnittenes Glossar, um sicherzustellen, dass alle Übersetzungen einheitlich und exakt sind sowie einem hohen Standard entsprechen – unabhängig von der Anzahl an Linguisten, die an dem Projekt mitwirken.
<G-vec00001-001-s420><build.erstellen><en> With this awesome plugin you can build your gallery in 1 minute.
<G-vec00001-001-s420><build.erstellen><de> Mit diesem awesome Plugin können Sie Ihre Galerie erstellen, 1 Minute.
<G-vec00001-001-s421><build.erstellen><en> Build the adapter Using Maven or MobileFirst CLI.
<G-vec00001-001-s421><build.erstellen><de> Erstellen Sie den Adapter mit Maven oder Ã1⁄4ber die MobileFirst CLI.
<G-vec00001-001-s422><build.erstellen><en> Mura MPX Series PCI Express x16 Gen2 video wall controller boards have four high-definition outputs and either four, two, or zero inputs, enabling AV installers to build custom, scalable video walls of up to 16 boards for a total of 56 HD outputs and 56 HD inputs.
<G-vec00001-001-s422><build.erstellen><de> Mura MPX Series PCI Express x16 Gen2-Videowand-Controller-Boards besitzen vier hochauflösende Ausgänge und vier, zwei oder keine Eingänge, sodass AV-Installierer benutzerspezifische skalierbare Videowände mit bis zu 16 Boards für insgesamt 56 HD-Ausgänge und 56 HD-Eingänge erstellen können.
<G-vec00001-001-s423><build.erstellen><en> Back in the year 2015 we were entrusted to devise a master plan for the redevelopment of Pusat Sains Negara (National Science Centre) Malaysia and to conceptualize, design and build I-Rays, a gallery about the science of radiation.
<G-vec00001-001-s423><build.erstellen><de> Im Jahr 2015 wurden wir beauftragt, einen Masterplan für das Redesign von Pusat Sains Negara (National Science Centre) Malaysia zu erstellen und I-Rays, eine Galerie über die Wissenschaft der Strahlung, zu konzipieren, zu entwickeln und zu fertigen.
<G-vec00001-001-s424><build.erstellen><en> Build the city of your dreams in a building simulator City Island 3.
<G-vec00001-001-s424><build.erstellen><de> Erstellen Sie die Stadt Ihrer Träume in einem Gebäude Simulator City Island 3.
<G-vec00001-001-s425><build.erstellen><en> This means applying technology to build new business models, processes, software, and systems.
<G-vec00001-001-s425><build.erstellen><de> Durch den Einsatz von Technologie erstellen sie neue Geschäftsmodelle, Prozesse, Software und Systeme.
<G-vec00001-001-s426><build.erstellen><en> QVR Pro's open event platform provides greater flexibility to integrate into your system to build a comprehensive event management and action solution.
<G-vec00001-001-s426><build.erstellen><de> Die offene Ereignisplattform von QVR Pro bietet mehr Flexibilität bei der Integration in Ihr System, um eine umfassende Ereignisverwaltung und Aktionslösung zu erstellen.
<G-vec00001-001-s427><build.erstellen><en> Use QNAP NAS and Platform9 to build a hybrid cloud solution that is remarkably easy to deploy and easy to use for OpenStack environments.
<G-vec00001-001-s427><build.erstellen><de> Erstellen Sie mit QNAP NAS und Platform9 eine Hybrid-Cloud-Lösung, die sich sehr einfach einsetzen und mühelos für OpenStack-Umgebungen nutzen lässt.
<G-vec00001-001-s428><build.erstellen><en> Build customised applications to automatically delete call recordings in Talk.
<G-vec00001-001-s428><build.erstellen><de> Um Anrufaufzeichnungen in Talk automatisch zu löschen, können Sie eine eigene angepasste App erstellen.
<G-vec00001-001-s429><build.erstellen><en> So let us build two server-groups: subcluster1 and subcluster2.
<G-vec00001-001-s429><build.erstellen><de> Wir erstellen zwei Server-Gruppen: subcluster1 und subcluster2.
<G-vec00001-001-s430><build.erstellen><en> DBX Platform enables you to leverage our robust set of APIs to build custom solutions that improve collaboration, streamline workflows and secure content.
<G-vec00001-001-s430><build.erstellen><de> Mit DBX Platform haben Sie Zugriff auf unsere zuverlässigen APIs und können damit maßgeschneiderte Lösungen erstellen, die die Zusammenarbeit erleichtern, Abläufe straffen und Inhalte schützen.
<G-vec00001-001-s431><build.erstellen><en> About CData API Server Build a REST API from your database with a few clicks.
<G-vec00001-001-s431><build.erstellen><de> Kaufen Über CData API Server Erstellen Sie mit einigen wenigen Klicks eine REST-API.
<G-vec00001-001-s432><build.erstellen><en> But the issues with most no-code tools are that the apps you can build on them often don’t scale well and integration capabilities are very limited.
<G-vec00001-001-s432><build.erstellen><de> Aber das Problem der meisten No-Code-Tools ist, dass die Anwendungen, die Sie darauf erstellen können, oft nicht gut skalierbar und die Integrationsmöglichkeiten sehr begrenzt sind.
<G-vec00001-001-s433><build.erstellen><en> A4Desk - Build Flash menus and Web sites without coding.
<G-vec00001-001-s433><build.erstellen><de> A4Desk - Erstellen Sie Flash-Menüs und Webseiten ohne Codierung.
<G-vec00001-001-s434><build.erstellen><en> Build a huge and beautiful city that will become the center of the world.
<G-vec00001-001-s434><build.erstellen><de> Erstellen Sie eine riesige und schöne Stadt, die das Zentrum der Welt werden wird.
<G-vec00001-001-s435><build.erstellen><en> For example, you can: Build interactive wayfinding kiosks with multiple displays to help people understand where they are now and how to get where they're going.
<G-vec00001-001-s435><build.erstellen><de> Erstellen Sie interaktive Kioske als Wegweiser mit mehreren Displays, damit Ihre Kunden schneller erfahren, wo sie sind und wie sie an ihr Ziel gelangen.
<G-vec00001-001-s436><build.erstellen><en> Use Dynamic Yield's platform to serve ads and build new ad variations at scale
<G-vec00001-001-s436><build.erstellen><de> Nutzen Sie die Plattform von Dynamic Yield, um Anzeigen zu schalten und Anzeigevarianten nach Wunsch zu erstellen.
<G-vec00179-001-s424><build.erstellen><en> Build the city of your dreams in a building simulator City Island 3.
<G-vec00179-001-s424><build.erstellen><de> Erstellen Sie die Stadt Ihrer Träume in einem Gebäude Simulator City Island 3.
<G-vec00179-001-s434><build.erstellen><en> Build a huge and beautiful city that will become the center of the world.
<G-vec00179-001-s434><build.erstellen><de> Erstellen Sie eine riesige und schöne Stadt, die das Zentrum der Welt werden wird.
<G-vec00001-001-s456><build.bauen><en> The coal pit Zeche Zollverein in Essen was build at the end of the 1920s and was closed down in the year 1986.
<G-vec00001-001-s456><build.bauen><de> Der Gesamtkomplex Zeche Zollverein in Essen wurde Ende der 20er Jahre gebaut und im Jahre 1986 stillgelegt.
<G-vec00001-001-s457><build.bauen><en> Know therefore and discern, that from the going forth of the commandment to restore and to build Jerusalem to the Anointed One, the prince, shall be seven weeks, and sixty-two weeks: it shall be built again, with street and moat, even in troubled times.
<G-vec00001-001-s457><build.bauen><de> So wisse nun und merke: von der Zeit an, da ausgeht der Befehl, daß Jerusalem soll wieder gebaut werden, bis auf den Gesalbten, den Fürsten, sind sieben Wochen; und zweiundsechzig Wochen, so werden die Gassen und Mauern wieder gebaut werden, wiewohl in kümmerlicher Zeit.
<G-vec00001-001-s458><build.bauen><en> One house is an old mill build in 1877,restored,serves as a dam for fresh water lake behind the house on northern side of the property; while on the southern side is in the direct contact with sea.
<G-vec00001-001-s458><build.bauen><de> Ein Haus ist eine alte Mühle im Jahre 1877 gebaut, restauriert, dient als Damm für Süßwassersee hinter dem Haus an der nördlichen Seite des Grundstücks, während auf der Südseite befindet sich im direkten Kontakt mit Meer.
<G-vec00001-001-s459><build.bauen><en> The participants learn how a robot works and how you can build and control such a mobile “creature” yourself.
<G-vec00001-001-s459><build.bauen><de> Die Teilnehmer und Teilnehmerinnen lernen, wie ein Roboter funktioniert und wie solch eine bewegliche „Kreatur“ selbst gebaut und gesteuert werden kann.
<G-vec00001-001-s460><build.bauen><en> By using an OO approach to design a system can be designed and tested (or more correctly simulated) without having to actually build the system first.
<G-vec00001-001-s460><build.bauen><de> Durch die Anwendung des OO-Design- Ansatzes kann ein System entworfen und getestet (oder korrekter: simuliert) werden, ohne dass es vorher gebaut werden muss.
<G-vec00001-001-s461><build.bauen><en> Stunning medieval castle build on a steep rock 112 m above river Orava.
<G-vec00001-001-s461><build.bauen><de> Eine beeindruckende mittelalterliche Burg, gebaut auf einem steilen Fels 112 Meter über der Wasserfläche des Arwa-Flusses.
<G-vec00001-001-s462><build.bauen><en> [2] But he didn't build a prototype.
<G-vec00001-001-s462><build.bauen><de> [2] Es wurde allerdings kein Prototyp gebaut.
<G-vec00001-001-s463><build.bauen><en> The house is build in a special way.
<G-vec00001-001-s463><build.bauen><de> Das Haus ist in besonderer Weise gebaut.
<G-vec00001-001-s464><build.bauen><en> GUIs are build as a tree of windows (rectangle) with their own properties.
<G-vec00001-001-s464><build.bauen><de> GUIs werden als Baum von Fenstern (Rechtecken), mit ihren eigenen Eigenschaften gebaut.
<G-vec00001-001-s465><build.bauen><en> As most of the buildings seem to be build of the same grey stone the are gives a rather dull impression.
<G-vec00001-001-s465><build.bauen><de> Da alle Gebäude aus dem gleichen grauen Stein gebaut zu sein scheinen wirkt das Areal etwas trist.
<G-vec00001-001-s466><build.bauen><en> From 1930 to 1937 the boats were build under the regulations of the international 'J' class (yacht classes were numbered by the alphabet).
<G-vec00001-001-s466><build.bauen><de> Von 1930 bis 1937 wurden die Boote nach den Regeln der internationalen 'J'-Klasse gebaut (Yacht-Klassen wurde nach dem Alphabet durchnummeriert).
<G-vec00001-001-s467><build.bauen><en> This provencal country house was build 250 years ago.
<G-vec00001-001-s467><build.bauen><de> Dieses provenzalische Landhaus wurde gebaut vor 250 Jahren.
<G-vec00001-001-s468><build.bauen><en> Trading Post no longer requires Garrison Resources to build or upgrade.
<G-vec00001-001-s468><build.bauen><de> Der Handelsposten benötigt keine Garnisonsressourcen mehr, um gebaut oder ausgebaut zu werden.
<G-vec00001-001-s469><build.bauen><en> Since 2001 the Elemental team has continued to build thousands of housing units in his homeland of Chile, using inventive, flexible, and affordable solutions.
<G-vec00001-001-s469><build.bauen><de> Das Elemental-Team hat seit 2001 konsequent mit einfallsreichen, flexiblen und kostengünstigen architektonischen Lösungen Tausende Wohneinheiten in seinem Heimatland Chile gebaut.
<G-vec00001-001-s470><build.bauen><en> In Songkhla a new Arena must be build.
<G-vec00001-001-s470><build.bauen><de> In Songkhla muss ein neues Stadion gebaut werden.
<G-vec00001-001-s471><build.bauen><en> 1 And it came to pass in the four hundred and eightieth year after the children of Israel were come out of the land of Egypt, in the fourth year of Solomon 's reign over Israel, in the month Zif, which is the second month, that he began to build the house of the LORD.
<G-vec00001-001-s471><build.bauen><de> 1 Im vierhundertundachtzigsten Jahr nach dem Auszug Israels aus Ägyptenland, im vierten Jahr der Herrschaft Salomos über Israel, im Monat Siw, das ist der zweite Monat, wurde das Haus dem HERRN gebaut.
<G-vec00001-001-s472><build.bauen><en> Turbo, build 1912, sank, World War Two, WW II, 04.04.1942, torpedo hit, Abu Dias, Ras Bananas, Egypt, Red Sea, Africa | Heck, Wrack, Schiff, Tanker, S.S.
<G-vec00001-001-s472><build.bauen><de> Turbo, gebaut 1912, gesunken, Zweiter Weltkrieg, am 04.04.1942 durch Torpedo, Abu Dias, Ras Banas, Ägypten, Rotes Meer, Afrika | Stern, Wreck, ship, tanker, S.S.
<G-vec00001-001-s473><build.bauen><en> "After the required level is gained, the Clan Leader is summoned by captain Agden Gal-Tark and receives the ""Laying the Foundation"" Quest in which Gal-Tark explains that in order to reach the Roaming Archipelago, a Clan would need to construct a Dockyard and build a Ship."
<G-vec00001-001-s473><build.bauen><de> "Nach Erreichen des Levels erhält das Oberhaupt den Auftrag Agden Gal-Tarks ""Werftbau"", in dem der Kapitän davon erzählt, dass für den Bau von Schiffen, die den Wandernden Archipel erreichen können, der Clan erst eine eigene Werft anlegen sollte, in der dann das Schiff gebaut wird."
<G-vec00001-001-s474><build.bauen><en> In this phase, a new assembly hall is being build.
<G-vec00001-001-s474><build.bauen><de> Während dieser Phase wird eine komplett neue Montagehalle gebaut.
<G-vec00001-001-s475><build.gestalten><en> """Remembering the Future"" is an invitation not to view this history with nostalgia, but to engage with it so we may continue to build alternative futures."
<G-vec00001-001-s475><build.gestalten><de> """Remembering the Future"" ist eine Einladung, diese reiche Geschichte nicht nostalgisch zu betrachten, sondern sich mit ihr zu beschäftigen, um weiter alternative Zukünfte zu gestalten."
<G-vec00001-001-s476><build.gestalten><en> All of Allianz's golf partnerships aim to expand the appeal of the sport, develop the future of both amateur and professional golf, and strengthen the emotional bonds that golf helps to build among friends and families.
<G-vec00001-001-s476><build.gestalten><de> Alle Golf-Partnerschaften der Allianz zielen darauf ab, den Sport für mehr Menschen attraktiv zu machen, seine Zukunft auf Amateur- und Profi-Ebene zu gestalten und die emotionalen Bande zu stärken, die der Golfsport unter Freunden und Familienmitgliedern knüpft.
<G-vec00001-001-s477><build.gestalten><en> In general we try to build the pages for all kinds of browers and screens.
<G-vec00001-001-s477><build.gestalten><de> Allgemein versuchen wir die Seiten sowohl optisch ansprechend als auch für möglichst jeden Browser und Monitor lesbar zu gestalten.
<G-vec00001-001-s478><build.gestalten><en> This provides for fast and simple build of an essential alarm system without necessity to lay cables.
<G-vec00001-001-s478><build.gestalten><de> Auf diese Weise ist es möglich, schnell und einfach ein grundsätzliches Alarmsystem zu gestalten, ohne die Verkabelung anpassen zu müssen.
<G-vec00001-001-s479><build.gestalten><en> On this World Day against Trafficking in Persons, let us come together around the key issues of prevention, protection and prosecution to build a future where this crime cannot exist.
<G-vec00001-001-s479><build.gestalten><de> Lassen Sie uns am diesjährigen Welttag gegen Menschenhandel gemeinsam über die Schlüsselfragen zu Prävention, Schutz und Strafverfolgung nachdenken, um eine Zukunft zu gestalten, in der diese Verbrechen keinen Platz haben.
<G-vec00001-001-s480><build.gestalten><en> Thank you also to everyone who helped build this website, for their support and advice! A great thank you to Thomas, Elisabeth and Guillaume for your constant support, your patience and for always being there when we need you.
<G-vec00001-001-s480><build.gestalten><de> Danke an alle, die halfen, diese Webseite zu gestalten, Danke für Eure Unterstützung und Euren Rat!Großer Dank an Euch Thomas, Elisabeth and Guillaume für Eure beständige Unterstützung, für Eure Geduld und dafür, dass Ihr immer da seid, wenn wir Euch brauchen.
<G-vec00001-001-s481><build.gestalten><en> Build your intelligent enterprise with a machine learning platform and software that unite human expertise and computer insights.
<G-vec00001-001-s481><build.gestalten><de> Gestalten Sie ein intelligentes Unternehmen, das eine Plattform und Software für maschinelles Lernen einsetzt, die menschliche Expertise mit computergenerierten Erkenntnissen vereinen.
<G-vec00001-001-s482><build.gestalten><en> Social dialogue with trade unions, workers and experts is necessary to build a future where the workers can ride the opportunity of the new technology instead of be buried by it, and can live the advantages without fear.
<G-vec00001-001-s482><build.gestalten><de> Der soziale Dialog mit Gewerkschaften, Arbeitnehmern und Sachverständigen ist notwendig, um eine Zukunft zu gestalten, in der die Arbeitnehmer die Gelegenheit der neuen Technologie nutzen können, anstatt von ihr zugrunde gerichtet zu werden, und die Vorteile ohne Angst wahrnehmen können.
<G-vec00001-001-s483><build.gestalten><en> Qualys helps organizations streamline and consolidate their security and compliance solutions in a single platform and build security into digital transformation initiatives for greater agility, better business outcomes and substantial cost savings.
<G-vec00001-001-s483><build.gestalten><de> Qualys hilft Unternehmen, ihre Sicherheits- und Compliance-Lösungen zu optimieren und in einer einzigen Plattform zu konsolidieren, Initiativen zur digitalen Transformation grundlegend sicher zu gestalten und so mehr Agilität, bessere Geschäftsergebnisse und bedeutende Kosteneinsparungen zu erzielen.
<G-vec00001-001-s484><build.gestalten><en> Build it together Add collaborators to let anyone – friends, classmates or colleagues – build your survey with you at the same time, just like with Docs, Sheets and Slides.
<G-vec00001-001-s484><build.gestalten><de> Umfragen gemeinsam erstellen Fügen Sie Mitbearbeiter hinzu – etwa Freunde, Mitschüler, Kommilitonen oder Kollegen – und gestalten Sie gemeinsam eine Umfrage nach Ihren Vorstellungen.
<G-vec00001-001-s485><build.gestalten><en> To build a future of serenity and solidarity, it is right to turn our gaze to this true disciple of Christ and to follow his teaching, courageously presenting anew to the contemporary world the saving message of the Gospel.
<G-vec00001-001-s485><build.gestalten><de> Um eine friedvolle und solidarische Zukunft zu gestalten, ist es angebracht, auf diesen wahren Jünger Christi zu schauen und seine Lehre zu befolgen, das heißt, der zeitgenössischen Welt die Heilsbotschaft des Evangeliums mutig anzubieten.
<G-vec00001-001-s486><build.gestalten><en> Build your advertising exactly to your liking and make full use of social networks.
<G-vec00001-001-s486><build.gestalten><de> Gestalten Sie Ihre Werbung genau nach Ihren Vorstellungen und nutzen sie Social Media in vollem Umfang.
<G-vec00001-001-s487><build.gestalten><en> Heavenly Father, in the name of Your Son, Jesus, we ask You on behalf of the visionaries, the entire Parish, all the pilgrims and especially for the youth who will be coming to the Prayer Festival, that this town may become for everyone who comes here a town of the meeting of hearts, and so that Your Fatherly Heart and Jesus' and Mary's Hearts may always remain before our eyes and that we build our lives according to them.
<G-vec00001-001-s487><build.gestalten><de> Himmlischer Vater, im Namen Deines Sohnes Jesus bitten wir Dich für die Seher, für die Pfarrei, für alle Pilger, besonders für die Jugendlichen, die zum Gebetstreffen der Jugend kommen, dass dieser Ort für jeden, der kommt, ein Ort der Begegnung der Herzen werden kann, dass Dein väterliches Herz, das Herz Deines Sohnes und das Herz Mariens ständig vor unseren Augen bleiben und dass wir unser Leben nach Deinem Herzen gestalten.
<G-vec00001-001-s488><build.gestalten><en> Passing our faith along also means helping to build the Church of tomorrow.
<G-vec00001-001-s488><build.gestalten><de> Den Glauben weiterzugeben heißt auch die Kirche von morgen zu gestalten.
<G-vec00001-001-s489><build.gestalten><en> Fulfill your dreams and let us build a successful future together.
<G-vec00001-001-s489><build.gestalten><de> Erfüllen Sie Lebensträume und gestalten Sie mit uns gemeinsam eine erfolgreiche Zukunft.
<G-vec00001-001-s490><build.gestalten><en> It will be these same values that enable today's generations to build their future with hope, giving life to a truly supportive and fraternal society, in which all the various contexts, the institutions and the economy are imbued with a Gospel spirit.
<G-vec00001-001-s490><build.gestalten><de> Eben diese Werte werden es den Generationen von heute gestatten, hoffnungsvoll ihre Zukunft zu gestalten und so eine wahrhaft solidarische und brüderliche Gesellschaft ins Leben zu rufen, in der alle verschiedenen Bereiche, die Institutionen und die Wirtschaft vom Geist des Evangeliums durchdrungen sind.
<G-vec00001-001-s491><build.gestalten><en> By working together business and science can help build a more sustainable world for tomorrow.
<G-vec00001-001-s491><build.gestalten><de> Wirtschaft und Wissenschaft können gemeinsam dazu beitragen, die Welt von morgen nachhaltig zu gestalten.
<G-vec00001-001-s492><build.gestalten><en> Remember: What unites us all as “Clarkians” is the will to actively build the future.
<G-vec00001-001-s492><build.gestalten><de> Bleibt festzuhalten: Was uns alle als „Clarkianer“ eint, ist der Wille, Zukunft aktiv zu gestalten.
<G-vec00001-001-s493><build.gestalten><en> Expected outcome: To create a network of people across the continent who are working to build a genuinely multicultural Europe.
<G-vec00001-001-s493><build.gestalten><de> Angestrebte Ergebnisse: Ein Netzwerk zwischen Menschen des gesamten Kontinents schaffen, die ein wirklich multikulturelles Europa gestalten.
<G-vec00001-001-s513><build.schaffen><en> """International partnerships like this one build the connections that allow Massachusetts' businesses to navigate the rapidly-growing global markets for clean energy technologies."
<G-vec00001-001-s513><build.schaffen><de> """Internationale Partnerschaften wie diese schaffen Verbindungen, die es den Unternehmen in Massachusetts ermöglichen, sich in den rasch wachsenden globalen Märkten der sauberen Energietechnologien zurechtzufinden."
<G-vec00001-001-s514><build.schaffen><en> And we have to harmonize with all the people and build a world we can live in at ease and without fights.
<G-vec00001-001-s514><build.schaffen><de> Ausserdem müssen wir in Harmonie mit unseren Mitmenschen eine Welt ohne Streit schaffen, in der wir uns wohl fühlen können.
<G-vec00001-001-s515><build.schaffen><en> Shingles are wonderful, wind resistant roofing product that allows architects to build exceptional buildings and owners to feel safe under their roof.
<G-vec00001-001-s515><build.schaffen><de> Schindeln sind ein wundervolles Bedachungsprodukt, das es Architekten ermöglicht, außergewöhnliche Bauwerke zu schaffen, und das den Eigentümern gleichzeitig Sicherheit unter ihrem eigenen Dach bietet.
<G-vec00001-001-s516><build.schaffen><en> Before purses can be pooled via a fiscal union, the EU needs to build the political union that it so urgently needs.
<G-vec00001-001-s516><build.schaffen><de> Bevor nun die Vergemeinschaftung der Geldbörsen durch eine Fiskalunion fortgesetzt werden kann, sollte die EU erst einmal die dringend nötige politische Union schaffen.
<G-vec00001-001-s517><build.schaffen><en> """We maximize networking to build innovative ecosystems, created through our networked approach to signal management and the tight integration between all of our products,"" said Lars Höhmann, Product Manager for MediorNet at Riedel Communications."
<G-vec00001-001-s517><build.schaffen><de> """Wir konzentrieren uns auch weiterhin auf eine maximale Vernetzung und schaffen innovative Ökosysteme, die durch unseren vernetzten Ansatz beim Signal-Management und die enge Integration zwischen all unseren Produkten entstehen"", so Lars Höhmann, Produktmanager für MediorNet bei Riedel Communications."
<G-vec00001-001-s518><build.schaffen><en> World Health Day: open dialogue about depression is needed to raise awareness, build understanding and reduce stigma 05-04-2017 World Health Day 2017 focuses on depression – a leading cause of disability globally.
<G-vec00001-001-s518><build.schaffen><de> Weltgesundheitstag: Wir müssen offen über Depressionen reden, um Bewusstsein und Verständnis zu schaffen und Stigmatisierung zu bekämpfen 05-04-2017 Der Weltgesundheitstag 2017 ist dem Thema Depressionen und damit der weltweit führenden Ursache für Behinderungen gewidmet.
<G-vec00001-001-s519><build.schaffen><en> I am always interested in efforts to build a better workplace for all colleagues.
<G-vec00001-001-s519><build.schaffen><de> Es macht mir viel Spaß daran zu arbeiten, uns allen ein besseres Arbeitsumfeld zu schaffen.
<G-vec00001-001-s520><build.schaffen><en> "I remember that he said to me: ""Our idea is to avoid difficult situations and bloodshed; our plan is to build alliances between social and political forces, because, in 1998, we could launch a vigorous political campaign with considerable electoral strength, with the support of the people and of broad sectors in the armed forces, and take power in this traditional way."
<G-vec00001-001-s520><build.schaffen><de> Ich erinnere mich, dass er mir sagte: Unsere Linie ist, ernste Situationen und Blutvergießen zu vermeiden; unsere Perspektive ist, Bündnisse sozialer und politischer Kräfte zu schaffen, so könnten wir 1998 eine nachdrückliche Kampagne starten, mit einer bedeutenden Wahlkraft, der Unterstützung der Bevölkerung und breiter Kreise der Streitkräfte, um auf diese traditionelle Weise zur Macht zu kommen.
<G-vec00001-001-s521><build.schaffen><en> “In the absence of a viable national bourgeoisie, many ex-colonial countries have seen the development of single-party dictatorships—led by the civil and military intelligentsia, based on national and social demagoguery—which seek to build the economic and social base for native capitalist exploitation.
<G-vec00001-001-s521><build.schaffen><de> „Ohne eine lebensfähige nationale Bourgeoisie haben sich in vielen ehemaligen Kolonialländern Einparteiendiktaturen entwickelt – unter Führung der zivilen und militärischen Intelligenz und auf der Grundlage nationaler und sozialer Demagogie –, die danach trachten, die wirtschaftliche und gesellschaftliche Grundlage für einheimische kapitalistische Ausbeutung zu schaffen.
<G-vec00001-001-s522><build.schaffen><en> """This Communication will help to build a European Doctrine in line with the European Parliament’s recommendations."
<G-vec00001-001-s522><build.schaffen><de> Diese Mitteilung wird helfen, eine europäische Doktrin im Einklang mit den Empfehlungen des Europäischen Parlaments zu schaffen.
<G-vec00001-001-s523><build.schaffen><en> Jus ad bellum has served to build a consensus within the Armed Forces command structures.
<G-vec00001-001-s523><build.schaffen><de> Das Recht zum Krieg hat dazu gedient Konsens innerhalb der Strukturen der Streitkräfte zu schaffen.
<G-vec00001-001-s524><build.schaffen><en> "Abstract: The EU-financed project ""Measuring and Comparing Achievements of Learning Outcomes in Higher Education in Europe"" (CALOHEE) aims to build infrastructures that allow the measurement and comparison of students' competences in bachelor's and master's programmes throughout Europe."
<G-vec00001-001-s524><build.schaffen><de> "Zusammenfassung: Das EU-geförderte Projekt ""Measuring and Comparing Achievements of Learning Outcomes in Higher Education in Europe"" (CALOHEE) hat sich zum Ziel gesetzt, Infrastrukturen zu schaffen, die es ermöglichen, europaweit die Kompetenzen von Studierenden in Bachelor- und Master-Programmen zu messen und zu vergleichen."
<G-vec00001-001-s525><build.schaffen><en> One of the most preferred use of anavar is to boost muscle interpretation, and to build excellent quality muscular tissue mass.
<G-vec00001-001-s525><build.schaffen><de> Die am meisten bevorzugte Verwendung von anavar ist Muskel Bedeutung zu steigern, und auch Top-Qualität Muskelgewebe Masse zu schaffen.
<G-vec00001-001-s526><build.schaffen><en> Only with that, and only with an orientation on scientific and related progress, cultural progress, as the law, to reverse the anti-progress tendency, since 1968—only that, that is, reversing the direction of policy-shaping, from 1968 to the present, and going back to what had been the implicit agreement among nations coming out of World War II, an implicit agreement to build a world free of colonization, free of subjugation of people, and free of the traditions of oligarchism: the same principle which had motivated the Europeans who had sent colonists across the waters of the Atlantic, and tried to build a bastion for saving European civilization from what was going on in Europe itself.
<G-vec00001-001-s526><build.schaffen><de> Wir müssen, anders gesagt, die ganze grundsätzliche Richtung der Politik von 1968 bis heute umdrehen und zu dem zurückkehren, was nach dem Zweiten Weltkrieg die stillschweigende Einigung unter den Nationen war: eine Einigkeit darin, eine Welt zu schaffen, die frei von Kolonisierung ist, frei von Unterwerfung von Völkern und frei von den Traditionen des Oligarchentums, Das ist das gleiche Prinzip, das die Europäer motiviert hatte, die Kolonisten über die Wasser des Atlantik schickten, um eine Bastion aufzubauen, mit der man die europäische Zivilisation vor dem, was in Europa selbst vorging, retten konnte.
<G-vec00001-001-s527><build.schaffen><en> There is much that we can do to benefit the poor, the needy and those who suffer, and to favour justice, promote reconciliation and build peace.
<G-vec00001-001-s527><build.schaffen><de> Wir können viel tun für das Wohl der Armen, der Schwachen und der Leidenden, wir können viel tun, um die Gerechtigkeit zu fördern, die Versöhnung voranzutreiben, den Frieden zu schaffen.
<G-vec00001-001-s528><build.schaffen><en> """Coming together in September with a renewed commitment to build on our achievements so far and to bridge the gaps identified, we can deliver on our shared responsibility to build a better world for generations to come,"" the Secretary-General says."
<G-vec00001-001-s528><build.schaffen><de> """Wenn wir im September zusammenkommen, auf dem bisher Erreichten aufbauen und die bestehenden Lücken schließen, dann können wir unserer gemeinsamen Verantwortung gerecht werden und eine bessere Welt für kommende Generationen schaffen"", sagte der UNO-Generalsekretär."
<G-vec00001-001-s529><build.schaffen><en> You need to be brilliant to know all details to build your body.
<G-vec00001-001-s529><build.schaffen><de> Sie müssen klug sein, alle Informationen erkennen Sie Ihren Körper zu schaffen.
<G-vec00001-001-s530><build.schaffen><en> These preliminaries help to eliminate emotional blocks and build up the positive force needed to succeed in their meditation practice.
<G-vec00001-001-s530><build.schaffen><de> Diese vorbereitenden Übungen tragen dazu bei, emotionale Blockaden zu beseitigen und schaffen positive Kraft, die erforderlich ist, damit die Meditationspraxis gelingt.
<G-vec00001-001-s531><build.schaffen><en> We build long-term trust through open and respectful interaction with our customers.
<G-vec00001-001-s531><build.schaffen><de> Im offenen und respektvollen Umgang mit unseren Kunden schaffen wir langfristiges Vertrauen.
<G-vec00001-001-s532><build.schlagen><en> The most commonly applied tool to seal interdynastic connections was marriage; that said, other relationships, such as godparenthood, could also build bridges between dynasties.
<G-vec00001-001-s532><build.schlagen><de> Das am häufigsten verwandte Mittel für interdynastische Verbindungen war die Heirat; aber auch andere Beziehungsformen, etwa Patenschaften, konnten Brücken zwischen Dynastien schlagen.
<G-vec00001-001-s533><build.schlagen><en> EAM addresses this issue and aims to build a bridge between industry and local suppliers by promoting business partnerships.
<G-vec00001-001-s533><build.schlagen><de> EAM greift diesen Punkt auf und sucht durch Unternehmenskooperationen eine Brücke zwischen Industrie und lokalen Zulieferern zu schlagen.
<G-vec00001-001-s534><build.schlagen><en> Improvisation shall build a bridge and make the impossible happening – through humour, magic and games.
<G-vec00001-001-s534><build.schlagen><de> Improvisation soll eine Brücke schlagen und das Unmögliche in möglich gemacht werden durch Kreativität – mit Humor, Magie und Spiel.
<G-vec00001-001-s535><build.schlagen><en> Description of the original vehicle: With that dream sports car of superlatives, Mercedes McLaren tieds up to the track record of the SLR of the 50's and understood in its very own way to build a bridge between past an present.
<G-vec00001-001-s535><build.schlagen><de> Von Hand genähte Ziernähte an den Ledersitzen Beschreibung des Originalfahrzeugs: Mit diesem Traum-Sportwagen der Superlative knüpft Mercedes McLaren an die Erfolgsgeschichte des SLR der Fünfzigerjahre an und hat es in einer unnachahmlichen Weise verstanden eine Brücke zwischen Vergangenheit und Gegenwart zu schlagen.
<G-vec00001-001-s536><build.schlagen><en> Only people who offer more than just outstanding specialist qualifications can build bridges to the future.
<G-vec00001-001-s536><build.schlagen><de> Brücken in die Zukunft schlagen nur diejenigen, die mehr als nur hervorragende fachliche Qualifikationen mitbringen.
<G-vec00001-001-s537><build.schlagen><en> "BILL error: With the opener ""Reign Supreme"" still trying to build a bridge to the past."
<G-vec00001-001-s537><build.schlagen><de> "ARVE Fehler: Mit dem Opener ""Reign Supreme"" versucht man noch die Brücke in die Vergangenheit zu schlagen."
<G-vec00001-001-s538><build.schlagen><en> The new metropolitan internationalism, however, failed to build bridges across the Mediterranean.
<G-vec00001-001-s538><build.schlagen><de> Doch dem metropolitanen neuen Internationalismus gelang es nicht, Brücken über das Mittelmeer zu schlagen.
<G-vec00001-001-s539><build.schlagen><en> Indeed do your bodies, your souls and your spirit build a bridge between Spirit and Sexus.
<G-vec00001-001-s539><build.schlagen><de> In der Tat schlagen euer Körper, eure Seele und euer Geist den Bogen zwischen Spirit und Sexus.
<G-vec00001-001-s540><build.schlagen><en> Seoul (Fides Service) - To build bridges of reconciliation between the people of Korea and Japan the local Churches in these two Asian countries are about to publish a new History of Korea and Japan.
<G-vec00001-001-s540><build.schlagen><de> Seoul (Fidesdienst) - Die Kirche versucht Brücken zwischen den Menschen in Korea und Japan zu schlagen: dazu soll ein Dokument zur Geschichte der beiden Länder dienen, das in beiden Ländern im April dieses Jahres erscheinen wird.
<G-vec00001-001-s541><build.schlagen><en> You must want to build bridges as we believe in diplomacy as a driving force on the conflict-ridden world stage.
<G-vec00001-001-s541><build.schlagen><de> Sie müssen Brücken schlagen, wenn wir an die Diplomatie als treibende Kraft auf der konfliktreichen Weltbühne glauben.
<G-vec00001-001-s542><build.schlagen><en> Together we examine important issues in both national and international projects, and help to build bridges between our clients and their customers, in order to achieve added value for everyone.
<G-vec00001-001-s542><build.schlagen><de> Gemeinsam untersuchen wir in nationalen wie internationalen Projekten wichtige Themen und helfen, Brücken zwischen unseren Auftraggebern und deren Kunden zum Mehrwert aller zu schlagen.
<G-vec00001-001-s543><build.schlagen><en> The objective of the meeting was to build new cultural bridges and collaborate together to produce sustainable and lasting relationships.
<G-vec00001-001-s543><build.schlagen><de> Ziel des Treffen war es, neue kulturelle Brücken zu schlagen und gemeinsam nachhaltige und dauerhafte Beziehungen zu schaffen.
<G-vec00001-001-s544><build.schlagen><en> "It has worked to build new bridges, to touch people with music and to get to know each other a little"", says Goisern."
<G-vec00001-001-s544><build.schlagen><de> "Es hat geklappt, neue Brücken zu schlagen, mit der Musik Menschen zu berühren und uns gegenseitig ein bissl kennenzulernen"", so Goisern."
<G-vec00001-001-s545><build.schlagen><en> Music and sound art are intrinsically linked to the notion of transit and form a force field afforded a special space in the festival primarily with artists who build bridges, cross borders, repeatedly relocate and move between countries, cultures and genres.
<G-vec00001-001-s545><build.schlagen><de> Musik und Klangkunst sind geradezu intrinsisch mit dem Begriff des Transits verbunden und bilden ein Spannungsfeld, dem im Festival ein besonderer Raum gegeben werden soll, zu vorderster Stelle mit Künstlern, die Brücken schlagen, Grenzen überschreiten, sich wiederholt neu verorten und sich zwischen Ländern, Kulturen und Genres bewegen.
<G-vec00001-001-s546><build.schlagen><en> """By offering the ticket sale, we want to build a bridge between our core competence as a telecommunications provider and our commitment to events"", says Sebastian Prange, Vice President O2 Shops, TelefÃ3nica O2 Germany."
<G-vec00001-001-s546><build.schlagen><de> """Wir möchten mit dem Ticketverkauf eine Brücke schlagen zwischen unserer Kernkompetenz als Telekommunikationsanbieter und unserem Engagement im Eventbereich,"" sagt Sebastian Prange, Vice President O2 Shops bei Telefónica O2 Germany."
<G-vec00001-001-s547><build.schlagen><en> Info Architecture At the University of Liechtenstein, we try to build bridges between the values of the past, cultural heritage and any necessary renewal, and between regional responsibility and global awareness.
<G-vec00001-001-s547><build.schlagen><de> Info Architektur Wir schlagen Brücken zwischen den Werten der Vergangenheit, kulturellem Erbe und notwendiger Erneuerung, zwischen regionaler Verantwortung und globalem Bewusstsein.
<G-vec00001-001-s548><build.schlagen><en> Either we consider that we must create a rear for the vanguard of the socialist revolution in the shape of the peoples which are rising against national oppression — and in that case we shall build a bridge between West and East and shall indeed be steering for a world socialist revolution; or we do not do this—and in that case we shall find ourselves isolated and shall be abandoning the tactics of utilizing every revolutionary movement among the oppressed nationalities for the purpose of destroying imperialism.
<G-vec00001-001-s548><build.schlagen><de> Entweder sind wir der Auffassung, dass wir aus den Völkern, die sich gegen die nationale Unterdrückung erheben, ein Hinterland für die Avantgarde der sozialistischen Revolution bilden müssen - und dann schlagen wir eine Brücke zwischen West und Ost, dann halten wir tatsächlich Kurs auf die sozialistische Weltrevolution, oder wir tun das nicht - und dann stehen wir isoliert da, dann verzichten wir auf die Taktik, alle und jede revolutionäre Bewegung innerhalb der unterdrückten Nationalitäten auszunutzen, um den Imperialismus zu vernichten.
<G-vec00001-001-s549><build.schlagen><en> However, systransis is one of the very few companies which are able to build a bridge between modern IT and railway operations.
<G-vec00001-001-s549><build.schlagen><de> Systransis gehört jedoch zu den wenigen Anbietern, die eine Brücke zwischen moderner IT und dem Bahnbetrieb schlagen können.
<G-vec00001-001-s550><build.schlagen><en> Meanwhile, the To Learn from Stolipinovo project will try to build a bridge to the marginalized local Roma community, the largest in the Balkans.
<G-vec00001-001-s550><build.schlagen><de> "Genauso wie das Projekt ""Learn from Stopinovo"", das versucht, eine Brücke zur Roma-Gemeinschaft in und um Plovdiv zu schlagen."
<G-vec00001-001-s551><build.steigern><en> Want to build confidence to speak Japanese in different situations.
<G-vec00001-001-s551><build.steigern><de> Das Selbstvertrauen steigern möchten und Japanisch in verschiedensten Situation sprechen zu können.
<G-vec00001-001-s552><build.steigern><en> """With the additional capital and our strong stock performance we intend to expand our brand portfolio and continue to build shareholder value through strategic acquisitions and joint ventures,"" said Penny Green, President and CEO of Yield Growth."
<G-vec00001-001-s552><build.steigern><de> """Mit dem zusätzliche n Kapital und unserer starken Aktienperformance wollen wir unser Markenportfolio erweitern und den Unternehmenswert durch strategische Übernahmen und Joint Ventures weiter steigern"", erklärt Penny Green, President und CEO von Yield Growth."
<G-vec00001-001-s553><build.steigern><en> Want to build confidence to speak Manx in different situations.
<G-vec00001-001-s553><build.steigern><de> Das Steigern des Selbstvertrauens um Manx in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s554><build.steigern><en> Want to build confidence to speak Dutch in different situations.
<G-vec00001-001-s554><build.steigern><de> Das Steigern des Selbstvertrauens um Niederländisch in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s555><build.steigern><en> Want to build confidence to speak Croatian in different situations.
<G-vec00001-001-s555><build.steigern><de> Das Selbstvertrauen steigern möchten und Kroatisch in verschiedensten Situation sprechen zu können.
<G-vec00001-001-s556><build.steigern><en> Want to build confidence to speak Haitian Creole in different situations.
<G-vec00001-001-s556><build.steigern><de> Das Steigern des Selbstvertrauens um Bosnisch in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s557><build.steigern><en> "Following the Company's up-listing to the NASDAQ and subsequent listing on the Frankfurt Stock Exchange, the addition of well- respected analyst coverage like that produced by Heiko and Jake will help Pershing Gold to continue to build high-quality investor awareness for the Company,"" Alfers said ."
<G-vec00001-001-s557><build.steigern><de> "Im Anschluss an die Zulassung für die Handelsaufstufung an den NASDAQ Global Market und die darauffolgende Notierung an der Frankfurter Wertpapierb örse werden Analystenberichte von angesehenen Analysten wie Heiko und Jake Pershing Gold dabei helfen, die Bekanntheit des Unternehmens bei hochwertigen Investoren zu steigern,"" so Alfers weiter."
<G-vec00001-001-s558><build.steigern><en> Want to build confidence to speak Malayalam in different situations.
<G-vec00001-001-s558><build.steigern><de> Das Steigern des Selbstvertrauens um Malayalam in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s559><build.steigern><en> Want to build confidence to speak Icelandic in different situations.
<G-vec00001-001-s559><build.steigern><de> Das Steigern des Selbstvertrauens um Grönländisch in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s560><build.steigern><en> Want to build confidence to speak Bosnian in different situations.
<G-vec00001-001-s560><build.steigern><de> Das Steigern des Selbstvertrauens um Bosnisch in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s561><build.steigern><en> Want to build confidence to speak Shona in different situations.
<G-vec00001-001-s561><build.steigern><de> Das Selbstvertrauen steigern möchten und Shona in verschiedensten Situation sprechen zu können.
<G-vec00001-001-s562><build.steigern><en> Want to build confidence to speak Russian in different situations.
<G-vec00001-001-s562><build.steigern><de> Das Selbstvertrauen steigern möchten und Russisch in verschiedensten Situation sprechen zu können.
<G-vec00001-001-s564><build.steigern><en> You will almost certainly find it easier to build up hearing aid use gradually.
<G-vec00001-001-s564><build.steigern><de> Sehr wahrscheinlich werden Sie es am einfachsten finden, die Benutzungszeit der Hörgeräte allmählich zu steigern.
<G-vec00001-001-s565><build.steigern><en> Want to build confidence to speak Quechua in different situations.
<G-vec00001-001-s565><build.steigern><de> Das Steigern des Selbstvertrauens um Quechua in verschiedenartigen Situation sprechen zu können.
<G-vec00001-001-s566><build.steigern><en> The additional infrastructure and support available from Naturally Splendid creates the opportunity to build upon this revenue base .
<G-vec00001-001-s566><build.steigern><de> Durch die zusätzliche Infrastruktur und die Unterstützung von Naturally Splendid bietet sich nun die Gelegenheit, diese Umsätze weiter zu steigern.
<G-vec00001-001-s567><build.steigern><en> Advertising and promotional activities are being developed to build more awareness and generate sales opportunities in this market.
<G-vec00001-001-s567><build.steigern><de> Es finden Werbe- und Promotionmaßnahmen statt, um den Bekanntheitsgrad zu steigern und Absatzmöglichkeiten auf diesem Markt zu generieren.
<G-vec00001-001-s568><build.steigern><en> Want to build confidence to speak Arabic (Egyptian) in different situations.
<G-vec00001-001-s568><build.steigern><de> Das Selbstvertrauen steigern möchten und Arabisch (Ägyptisch) in verschiedensten Situation sprechen zu können.
<G-vec00084-002-s038><build.aufbauen><en> Every day, exercising will help you burn calories and build muscle and give your metabolism to increase, even at rest.
<G-vec00084-002-s038><build.aufbauen><de> Die tägliche Ausübung hilft Ihnen, Kalorien verbrennen und Muskeln aufbauen und geben Sie Ihrem Stoffwechsel einen Schub auch in Ruhe.
<G-vec00084-002-s039><build.aufbauen><en> To help students build their confidence and prepare them for the real world.
<G-vec00084-002-s039><build.aufbauen><de> Damit die Schüler ihr Vertrauen aufbauen und sie für die reale Welt vorzubereiten.
<G-vec00084-002-s040><build.aufbauen><en> Anyone can build on top of OneNote using our Developer APIs, which are already used by hundreds of developers to create experiences that are integrated with OneNote.
<G-vec00084-002-s040><build.aufbauen><de> Jeder kann mithilfe unserer bereits von vielen Entwicklern genutzten Entwickler-APIs auf OneNote aufbauen, um Benutzeroberflächen zu erstellen, die in OneNote integriert sind.
<G-vec00084-002-s041><build.aufbauen><en> Tags and toppers are additional punchlines that build upon your first punchline.
<G-vec00084-002-s041><build.aufbauen><de> Anhänger und Spitzen sind zusätzliche Pointen, die auf deiner ersten Pointe aufbauen.
<G-vec00084-002-s042><build.aufbauen><en> You can build the color up of course.
<G-vec00084-002-s042><build.aufbauen><de> Natürlich kann man die Farbe auch aufbauen.
<G-vec00084-002-s043><build.aufbauen><en> When your Testosterone degree is high, you can build muscular tissue and also shred fat efficiently.
<G-vec00084-002-s043><build.aufbauen><de> Wenn Ihr Testosteronspiegel hoch ist, könnten Sie Muskelmasse aufbauen und auch Fett effektiv zerkleinern.
<G-vec00084-002-s044><build.aufbauen><en> Over the years I have been able to build a stable international network.
<G-vec00084-002-s044><build.aufbauen><de> Über die Jahre konnte ich ein gutes internationales Netzwerk aufbauen.
<G-vec00084-002-s045><build.aufbauen><en> The EU also wants to build strategic relationships with emerging economies, to discuss issues of common concern, promote cooperation on regulation and other matters, and resolve bilateral issues.
<G-vec00084-002-s045><build.aufbauen><de> Darüber hinaus möchte die EU strategische Beziehungen mit Schwellenländern aufbauen, um gemeinsame Angelegenheiten zu erörtern, die Zusammenarbeit bei Regulierungs- und anderen Fragen zu fördern und bilaterale Meinungsverschiedenheiten zu lösen.
<G-vec00084-002-s046><build.aufbauen><en> It provides interested operators with three choices: Live Casino in a Box - a product intended for betting shop operators to set up a live casino operation using PC terminals in physical locations; Live Turnkey Online Casino - an overall solution for operators who’d rather efficiently build, manage and market their own casino brands, at the same time benefiting from a multitude of options offered by Visionary iGaming; and Live Casino Game Feed – a product which can easily be integrated into operators’ existing casino infrastructure.
<G-vec00084-002-s046><build.aufbauen><de> Er stellt interessierten Anbieter drei Optionen zur Wahl: Live Casino in a Box: Ein Produkt, dass sich an Wett-Anbieter mit lokalen Geschäften richtet, die Live Casino Angebote in Form von PC Terminals anbieten möchten; Liver Turnkey Online Casino: Eine Rundum-Lösung für Anbieter, die eher eine eigene Casinomarke aufbauen, managen und vermarkten möchten und dabei gleichzeitig von einer Vielfalt an Optionen von Visionary iGaming profitieren möchten; und Live Casino Game Feed: Ein Produkt, das leicht in ein bestehendes Casino integriert werden kann.
<G-vec00084-002-s047><build.aufbauen><en> In order to make your cilia more dense, you can build up a short "silk".
<G-vec00084-002-s047><build.aufbauen><de> Um Ihre Wimpern dichter zu machen, können Sie eine kurze "Seide" aufbauen.
<G-vec00084-002-s048><build.aufbauen><en> It is they who build direct and long-lasting relationships with our patients and improve their quality of life every single day.
<G-vec00084-002-s048><build.aufbauen><de> Es sind diese Mitarbeiter, die direkte und lang anhaltende Beziehungen zu unseren Patienten aufbauen und ihre Lebensqualität Tag für Tag verbessern.
<G-vec00084-002-s049><build.aufbauen><en> School classes, working groups or inquisitive individual researchers can either launch into bionics with the ready-made kit or organize and build up everything from scratch themselves.
<G-vec00084-002-s049><build.aufbauen><de> So können Schulklassen, Arbeitsgruppen oder neugierige Einzelforscher entweder mit dem vorab ausgestatteten Baukasten in die Bionik starten oder von A bis Z alles selbst organisieren und aufbauen.
<G-vec00084-002-s050><build.aufbauen><en> Regin’s cloud central gives you a platform you can build on.
<G-vec00084-002-s050><build.aufbauen><de> Regins Cloud Zentrale bietet Ihnen eine Platform, auf der Sie aufbauen können.
<G-vec00084-002-s051><build.aufbauen><en> This way you can build up your defenses and as you move the infantry to the front lines then you can buy your armor as it get closer to attack time.
<G-vec00084-002-s051><build.aufbauen><de> Auf diese Weise kann man seine Verteidigung aufbauen und während man seine Infanteristen Richtung Front bewegt kann man immer noch Panzer kaufen, wenn man sich der Zeit des Angriffs nähert.
<G-vec00084-002-s052><build.aufbauen><en> Sessioning DH runs will improve your overall speed as you build your confidence by repeating runs, trying multiple lines and sessioning sections that a normal ride would only let you hit once.
<G-vec00084-002-s052><build.aufbauen><de> Eine Abfahrt immer wieder zu wiederholen macht euch insgesamt schneller, denn ihr könnt Selbstvertrauen aufbauen, indem ihr verschiedene Lines ausprobiert und Passagen intensiv kennenlernt, die ihr auf einer normalen Tour nur einmal fahren würdet.
<G-vec00084-002-s053><build.aufbauen><en> The indoor space of new luxury cab has been enlarged for 360°view, which can build up a pleasant working environment for the operator.
<G-vec00084-002-s053><build.aufbauen><de> Der Innenraum des neuen Luxusfahrerhauses ist für 360°view vergrößert worden, das einen angenehmen Arbeitsbereich für den Betreiber aufbauen kann.
<G-vec00084-002-s054><build.aufbauen><en> At the same time, we can provide our expertise about how to benefit from IoT solutions and how to build a fully autonomous plant.
<G-vec00084-002-s054><build.aufbauen><de> Zeitgleich können wir unsere Expertise anbieten, wie man von IoT-Lösungen profitieren und eine vollautonome Anlage aufbauen kann.
<G-vec00084-002-s055><build.aufbauen><en> This conformity to law therefore makes research easier for man, because they can draw the conclusions out of this and build up their knowledge upon them.
<G-vec00084-002-s055><build.aufbauen><de> Diese Gesetzmäßigkeit also erleichtert den Menschen das Forschen, denn daraus können sie die Folgerungen ziehen und auf diesen wieder ihr Wissen aufbauen.
<G-vec00084-002-s056><build.aufbauen><en> You can also build scenarios hierarchically with scenarios.
<G-vec00084-002-s056><build.aufbauen><de> Außerdem können Sie die Szenarien hierarchisch mit Szenarien aufbauen.
<G-vec00084-002-s058><build.aufbauen><en> An initial common achievement on which further collaborative processes can build.
<G-vec00084-002-s058><build.aufbauen><de> Ein erster gemeinsamer Erfolg, auf dem die weitere Zusammenarbeit aufbaut.
<G-vec00084-002-s059><build.aufbauen><en> “The target for Airbnb as company from California was to build up a local presence in Germany. Thanks to Schwartz Public Relations we could reach out to all relevant national daily and economic media in a very short period of time.
<G-vec00084-002-s059><build.aufbauen><de> “Als Internet-Unternehmen aus Kalifornien, das in Deutschland eine Präsenz aufbaut, konnten wir dank Schwartz PR in kürzester Zeit alle relevanten Medien der nationalen Tages- und Wirtschaftspresse erreichen.
<G-vec00084-002-s060><build.aufbauen><en> However, a lot is possible if you build a close bond with the dog, have good nerves and have the time to work with it daily.
<G-vec00084-002-s060><build.aufbauen><de> Vieles ist trotzdem möglich, wenn man eine enge Bindung zum Hund aufbaut, gute Nerven und die nötige Zeit hat, um täglich mit ihm zu arbeiten.
<G-vec00084-002-s061><build.aufbauen><en> Please help me to value godly women in ways that bless them, honor you, and build up your Church.
<G-vec00084-002-s061><build.aufbauen><de> Bitte hilf mir, diese göttlichen Frauen auf eine Weise wertzuschätzen, die sie segnet, dich ehrt und deine Gemeinde aufbaut.
<G-vec00084-002-s062><build.aufbauen><en> Learn how to build the business case, make connections and make it happen.
<G-vec00084-002-s062><build.aufbauen><de> Lernen Sie, wie man das geschäftliche Szenario aufbaut, Verbindungen knüpft und Ziele verwirklicht.
<G-vec00084-002-s063><build.aufbauen><en> The cell is submerged in a dilute sulphuric acid solution and is irradiated with sunlight from the front to cause an electrical tension to build up inside the cell.
<G-vec00084-002-s063><build.aufbauen><de> Die Zelle ist in verdünnte Schwefelsäure getaucht und wird von vorne mit Sonnenlicht bestrahlt, so dass sich eine elektrische Spannung aufbaut.
<G-vec00084-002-s064><build.aufbauen><en> 3 min 17 March, 2016 Cannabis Tolerance: What It Is And How To Bring It Down Smoking weed all the time can cause a tolerance to build up, requiring more weed to be used to reach the same level of high.
<G-vec00084-002-s064><build.aufbauen><de> 3 min 17 March, 2016 Cannabis Toleranz: Was Es Ist Und Wie Man Sie Schlägt Ständiges Kiffen kann bewirken, dass man eine Toleranz aufbaut, so dass man mehr Weed konsumieren muss, um das gleiche Maß an Rausch zu erreichen.
<G-vec00084-002-s065><build.aufbauen><en> At that meeting, we agreed on concrete progress in local cross-border traffic around Kaliningrad to make the lives of people in the region easier and, at the same time, build up trust.
<G-vec00084-002-s065><build.aufbauen><de> Wir haben damals konkrete Fortschritte im kleinen Grenzverkehr um Kaliningrad auf den Weg gebracht, der den Menschen der Region das Leben erleichtert und zugleich Vertrauen aufbaut.
<G-vec00084-002-s066><build.aufbauen><en> This healing causes plaque to build up where the arteries are damaged.
<G-vec00084-002-s066><build.aufbauen><de> Diese Heilung bewirkt, dass sich dort, wo die Arterien beschädigt sind, Plaque aufbaut.
<G-vec00084-002-s067><build.aufbauen><en> It is important that your dog no longer pulls on the leash, the dog to build a reference to his dog.
<G-vec00084-002-s067><build.aufbauen><de> Wichtig ist, damit ihr Hund nicht mehr an der Leine zieht, dass der Hund einen Bezug zu seinem Hundehalter aufbaut.
<G-vec00084-002-s069><build.aufbauen><en> I am inspired in the way you build upon spirit.
<G-vec00084-002-s069><build.aufbauen><de> Ich bin begeistert davon, wie ihr auf den Geist aufbaut.
<G-vec00084-002-s070><build.aufbauen><en> Here’s an example. Maybe you have an internet marketing blog where you share useful posts on how to build a successful online business.
<G-vec00084-002-s070><build.aufbauen><de> Hier ist ein Beispiel: Du hast einen Internet Marketing Blog, auf dem Du nützliche Posts teilst, wie man ein erfolgreiches Online Business aufbaut.
<G-vec00084-002-s071><build.aufbauen><en> It works as an authentic testosterone which not only build up solid muscles and strength but it also keeps in good shape and enhances progression of male sex organs, one of the most excellent choice for bulking phases.
<G-vec00084-002-s071><build.aufbauen><de> Es wirkt wie ein authentisches Testosteron, das nicht nur feste Muskeln und Kraft aufbaut, sondern es auch in gutem Zustand hält und die Progression der männlichen Geschlechtsorgane fördert, eine der besten Wahl für Bulking-Phasen.
<G-vec00084-002-s072><build.aufbauen><en> Creating a bond that will build lasting relationships and provide mutual satisfaction and trust.
<G-vec00084-002-s072><build.aufbauen><de> Wir erstellen ein Band, dass dauerhafte Beziehungen aufbaut und gegenseitige Zufriedenheit und Vertrauen bietet.
<G-vec00084-002-s073><build.aufbauen><en> For the participating cinemas we have designed a sophisticated participation scheme which is build on the catchment area of the cinema.
<G-vec00084-002-s073><build.aufbauen><de> Für die teilnehmenden Kinos entwickelten wir ein ausgeklügeltes Beteiligungsmodell, welches auf dem Einzugsgebiet der Kinos aufbaut.
<G-vec00084-002-s074><build.aufbauen><en> Most importantly, Arrow continues to build an unparalleled ecosystem of Edge and IoT partners and suppliers capable of implementing cutting-edge, end-to-end Edge and IoT solutions across a variety of markets and industries.
<G-vec00084-002-s074><build.aufbauen><de> Am wichtigsten ist jedoch, dass Arrow weiterhin ein einzigartiges Ökosystem von Edge- und IoT-Partnern und -Lieferanten aufbaut, das in der Lage ist, innovative Edge-to-End-Edge- und IoT-Lösungen in einer Vielzahl von Märkten und Branchen zu implementieren.
<G-vec00084-002-s075><build.aufbauen><en> That's where they can learn how to manage things, promote, and build up and manage their own business.
<G-vec00084-002-s075><build.aufbauen><de> Dort können sie lernen, wie man Dinge managt, Werbung macht, wie man ein eigenes Geschäft aufbaut und organisiert.
<G-vec00084-002-s077><build.aufbauen><en> Our core shooters are of modular build and can therefore be specifically configured in accordance with customer requirements.
<G-vec00084-002-s077><build.aufbauen><de> Unsere Kernschießmaschinen sind modular aufgebaut und können daher entsprechend den Kundenwünschen konfiguriert werden.
<G-vec00084-002-s078><build.aufbauen><en> Although FinTechs have raised nearly US$110 billion since 2009, the report found that most are likely to fail if they do not build an effective partnership ecosystem.
<G-vec00084-002-s078><build.aufbauen><de> Obwohl Fintechs seit 2009 mit 110 Milliarden US-Dollar finanziert wurden, sieht der Bericht die meisten von ihnen scheitern, weil sie kein effektives Partner-Ökosystem aufgebaut haben.
<G-vec00084-002-s079><build.aufbauen><en> The machines and facilities are build up, electrically installed and set up by our experienced service team.
<G-vec00084-002-s079><build.aufbauen><de> Die Maschinen oder Anlagen werden von unserem erfahrenen Serviceteam aufgebaut, elektrisch installiert und in Betrieb genommen.
<G-vec00084-002-s080><build.aufbauen><en> The whole song is composed to build up to its powerful energetic refrain.
<G-vec00084-002-s080><build.aufbauen><de> Der ganze Song ist auf den mächtigen energetischen Refrain hinlaufend aufgebaut.
<G-vec00084-002-s081><build.aufbauen><en> All together we did more water related activities - irrigation in Mesopotamia, were and when do we use water (we baked bread, cooked apple sauce, both need some water), we build up a miniature water purification system.
<G-vec00084-002-s081><build.aufbauen><de> Alle zusammen haben wir weiter unser Wasserthema verfolgt - Bewässerung in Mesopotamien, wie und wo verwenden wir Wasser (wir haben Brot gebacken, Apfelmus eingekocht für beides braucht man ja auch etwas Wasser), wir haben eine Minikläranlage aufgebaut.
<G-vec00084-002-s082><build.aufbauen><en> Up until today, however, the Waldorf School in Chișinău remains the only Waldorf initiative in the country that was able to surpass its baby steps and build a viable organism.
<G-vec00084-002-s082><build.aufbauen><de> Die Waldorfschule in Chişinău ist nach wie vor die einzige Waldorfinitiative, die über die Kinderschuhe hinaus einen überlebensfähigen Organismus aufgebaut hat.
<G-vec00084-002-s083><build.aufbauen><en> Meanwhile different Non-Profit-Organizations from Switzerland and abroad belong to her clients, for which Rosi Blissenbach either founded a Swiss entity to build it up or took over the management of the existing organization to develop and expand it.
<G-vec00084-002-s083><build.aufbauen><de> Inzwischen gehören Non-Profit-Organisationen aus dem In- und Ausland zu ihren Kunden, für die Rosi Blissenbach entweder eine Tochter-Organisation in der Schweiz gegründet und aufgebaut oder eine bereits bestehende Organisation in der Geschäftsführung übernommen hat, um sie weiter auszubauen.
<G-vec00084-002-s084><build.aufbauen><en> Just connect the central unit to the router and then gradually build up a complex, smart household by connecting other devices.
<G-vec00084-002-s084><build.aufbauen><de> Die Zentraleinheit muss nur mit dem Router verbunden werden, damit dann nach und nach ein komplexes, intelligentes Zuhause mit anderen smarten Geräten aufgebaut werden kann.
<G-vec00084-002-s085><build.aufbauen><en> We at BAUNAT recognise the importance of consumer trust and have build the company upon it:
<G-vec00084-002-s085><build.aufbauen><de> Bei BAUNAT legen wir Wert auf die Bedeutung vom Verbrauchervertrauen und haben das Unternehmen so aufgebaut.
<G-vec00084-002-s086><build.aufbauen><en> The Cooler Master SX power pack is build modular, as already mentioned on the first page and provides thanks to individually connectable cables a cleared up PC for a better aeration and/or heat dissipation from the PC case.
<G-vec00084-002-s086><build.aufbauen><de> Wie bereits auf der ersten Netzteil Test Seite erwähnt, ist das Cooler Master V700 Netzteil vollkommen modular aufgebaut und ermöglicht einen aufgeräumten PC dank individuell ansteckbarer Kabel.
<G-vec00084-002-s087><build.aufbauen><en> Since we’ve already arrived a few days earlier to build our stand and install all products and systems, we wondered if and how you might like it.
<G-vec00084-002-s087><build.aufbauen><de> Wir sind ja schon ein paar Tage vorher angereist, haben den Stand aufgebaut, alle Produkte und Systeme installiert und uns Gedanken darüber gemacht, ob und wie es Ihnen gefallen wird.
<G-vec00084-002-s088><build.aufbauen><en> The investor mainly benefits from the increased customer relations and the good reputation IVT was able to form and build up in the last three decades, as well as its employees’ expertise, experience and loyalty.
<G-vec00084-002-s088><build.aufbauen><de> Dabei profitiert der Investor vor allem von den gewachsenen Kundenbeziehungen und dem guten Ruf, den sich IVT in dreieinhalb Jahrzehnten aufgebaut hat, sowie von der Kompetenz, Erfahrung und Loyalität der Mitarbeiter.
<G-vec00084-002-s089><build.aufbauen><en> Also, swimming tends not to build muscle, because the muscles are supported by the water, which restricts the type of movements the muscles make.
<G-vec00084-002-s089><build.aufbauen><de> Hinzu kommt, dass beim Schwimmen kaum Muskel aufgebaut werden, weil die Muskeln vom Wasser getragen werden, was die Art der von den Muskeln ausgeführten Bewegungen eingrenzt.
<G-vec00084-002-s090><build.aufbauen><en> By working closely with local project developers and companies the fund also helps build up know-how on renewable energy.
<G-vec00084-002-s090><build.aufbauen><de> Darüber hinaus wird durch die enge Zusammenarbeit des Fonds mit lokalen Projektentwicklern und Unternehmen Know-how im Bereich Erneuerbare Energie aufgebaut.
<G-vec00084-002-s091><build.aufbauen><en> However, if you work at it, the relationship you build with your cat will be worth the time and effort.
<G-vec00084-002-s091><build.aufbauen><de> Wenn du daran arbeitest, dann ist die Beziehung, die du mit der Katze aufgebaut hast, die Zeit und Mühe definitiv wert.
<G-vec00084-002-s092><build.aufbauen><en> Unfortunately I build up the tent a bit behind the pass and so I could see, what a stunning sunrise was going on behind the mountains, while I was packing my things together.
<G-vec00084-002-s092><build.aufbauen><de> Leider habe ich mein Zelt hinter dem Pass aufgebaut und so konnte ich nur sehen was sich da am Himmel hinter den Bergen abspielen musste, während ich meine Sachen zusammenpackte.
<G-vec00084-002-s093><build.aufbauen><en> The stolen books were taken to depots to be routed to various destinations, such as the Hohe Schule, a projected Nazi élite academy, never completed, which was supposed to build its library from the expropriated books.
<G-vec00084-002-s093><build.aufbauen><de> Die gestohlenen Bücher wurden zwischengelagert für weitere Verwendungszwecke wie die Hohe Schule, eine geplante, jedoch nie gänzlich realisierte nationalsozialistische Elitehochschule, deren Bibliothek aus dem Fundus der enteigneten Bücher aufgebaut werden sollte.
<G-vec00084-002-s094><build.aufbauen><en> OpenCms is an enterprise - ready content management solution build in Java and XML from open source components.
<G-vec00084-002-s094><build.aufbauen><de> OpenCms ist eine Java und XML basierte Website Content Management Lösung für Unternehmen, welche komplett aus Open Source Komponenten aufgebaut ist.
<G-vec00084-002-s095><build.aufbauen><en> Trade petitions and remedies are blunt and unwieldy policy tools that do nothing to address the underlying issue at hand—the U.S. can’t compete with China and Germany and other clean energy leaders unless it makes an assertive effort to build a more sustainable economy at home and abroad.
<G-vec00084-002-s095><build.aufbauen><de> Handelseingaben und Gegenmaßnahmen sind stumpfe und schwerfällige politische Instrumente, die nichts dazu beitragen, das zugrunde liegende Problem anzugehen – die Vereinigten Staaten können mit China, Deutschland und anderen Führern auf dem Gebiet der erneuerbaren Energie nicht konkurrieren, solange sie nicht ausdrückliche Anstrengungen unternehmen, zu Hause und im Ausland eine nachhaltigere Wirtschaft aufzubauen.
<G-vec00084-002-s096><build.aufbauen><en> I'm still a member of that organization today, I question patriarchy, and I try to build freedom for myself.
<G-vec00084-002-s096><build.aufbauen><de> Ich befinde mich heute immer noch in derselben Organisation, hinterfrage das Patriarchat und versuche, mir meine Freiheit aufzubauen.
<G-vec00084-002-s097><build.aufbauen><en> There’s no doubt that penning good blog posts can help you build a successful online business.
<G-vec00084-002-s097><build.aufbauen><de> Zweifellos kann das Bloggen Dir dabei helfen, ein erfolgreiches Online-Unternehmen aufzubauen.
<G-vec00084-002-s098><build.aufbauen><en> Those looking at expanding their manufacturing capabilities can meet technology experts to get answers on selecting the right system for their plant processes according to individual plant needs and be sure to discover the technology developments in the industry, develop contacts and build a potential supplier base. The educational sessions and learning zone will perfectly complement the visitor’s needs.
<G-vec00084-002-s098><build.aufbauen><de> Auf der Suche nach einer Erweiterung der Fertigungsmöglichkeiten kann man mit Technologieexperten sprechen, um Antworten hinsichtlich der Auswahl des richtigen Systems für die Anlagenprozesse entsprechend dem Bedarf des jeweiligen Werks zu erhalten, um sich über die technologischen Entwicklungen in der Branche zu informieren, um Kontakte zu knüpfen und einen Stamm potenzieller Lieferanten aufzubauen.
<G-vec00084-002-s099><build.aufbauen><en> Read more about how CREALOGIX helped Société Générale to successfully build up their digital bank.
<G-vec00084-002-s099><build.aufbauen><de> Lesen Sie mehr wie CREALOGIX Société Générale geholfen hat ihre digitale Bank erfolgreich aufzubauen.
<G-vec00084-002-s100><build.aufbauen><en> But we did not consider it as part of the program of the National Socialist Revolution to destroy human life or material goods, but rather to build up a new and better life.
<G-vec00084-002-s100><build.aufbauen><de> Allein wir sahen die Aufgabe der nationalsozialistischen Revolution nicht darin, Menschenleben oder Sachwerte zu vernichten, als vielmehr darin, ein neues und besseres Leben aufzubauen.
<G-vec00084-002-s101><build.aufbauen><en> Emilie, a University Partnerships Manager at JobTeaser, advises to build trust by including advice that doesn’t come from the career services department: career development blogs like The Muse or JobTeaser Advice can make easily shareable content, for instance.
<G-vec00084-002-s101><build.aufbauen><de> Emilie, eine Managerin für Universitätspartnerschaften bei JobTeaser, rät dazu, mithilfe von Tipps, die nicht aus der Career-Service-Abteilung kommen, Vertrauen aufzubauen: Blogs rund um das Thema Karriereentwicklung wie The Muse oder JobTeaser Advice beispielsweise bieten Inhalte, die sich leicht teilen lassen.
<G-vec00084-002-s102><build.aufbauen><en> Your body starts to expel the bad and to build up again the good.
<G-vec00084-002-s102><build.aufbauen><de> Ihr Körper fängt an, das Schlechte auszustoßen und das Gute wieder aufzubauen.
<G-vec00084-002-s103><build.aufbauen><en> From the first day we are developing, like parents, together with a tiny child, we learn to live together, experience, care for each other, and build new family relationships.
<G-vec00084-002-s103><build.aufbauen><de> Vom ersten Tag an entwickeln wir wie Eltern zusammen mit einem winzigen Kind zusammen zu leben, zu erleben, füreinander zu sorgen und neue Familienbeziehungen aufzubauen.
<G-vec00084-002-s104><build.aufbauen><en> With XProtect as the foundation of your video surveillance, you get the freedom to build the entire system just the way you like it.
<G-vec00084-002-s104><build.aufbauen><de> Mit XProtect als Grundlage für Ihre Videoüberwachung erhalten Sie die Freiheit, das gesamte System genau so aufzubauen, wie es Ihnen gefällt.
<G-vec00084-002-s105><build.aufbauen><en> From the outset, one of the major cornerstones of the Baobab Family has been its efforts to build up the “most transparent project” of its kind.
<G-vec00084-002-s105><build.aufbauen><de> Einer der ausgesprochenen Eckpfeiler der Baobab Family ist seit Anfang an das Bestreben, das „Transparenteste Projekt“ in seiner Form aufzubauen.
<G-vec00084-002-s106><build.aufbauen><en> He would not have been the right man to build up the mission in South Shandong as superior.
<G-vec00084-002-s106><build.aufbauen><de> Er wäre wohl nicht der richtige Mann gewesen, die Mission in Süd-Shantung als Oberer aufzubauen.
<G-vec00084-002-s107><build.aufbauen><en> It adopts leading 3D printing technology to build biological micro-structure which guarantees the access, proliferation and differentiation of bone cells, growth of new vessels and exchange of metabolite.
<G-vec00084-002-s107><build.aufbauen><de> Es nutzt die führende 3D-Drucktechnologie, um eine biologische Mikrostruktur aufzubauen, die den Zugang, die Proliferation und Differenzierung von Knochenzellen, das Wachstum neuer Gefäße und den Austausch von Metaboliten garantiert.
<G-vec00084-002-s108><build.aufbauen><en> Her support in various types of projects, like restructuring programs, change of ownership, foundation of new branches of business, company’s rebranding, product launches and establishment of international divisions in Australia, China and India have enabled Christine Och, to build a broad range of knowledge.
<G-vec00084-002-s108><build.aufbauen><de> Ihre Begleitung der unterschiedlichsten Projekte, sei es Restrukturierungsprogramme, Eigentümerwechsel, Gründung neuer Geschäftszweige, Änderung der Markenpolitik, Produkteinführungen und der Aufbau internationaler Abteilungen in Australien, China und Indien haben es Christine Och ermöglicht, ein breites Wissensspektrum aufzubauen.
<G-vec00084-002-s109><build.aufbauen><en> But many women believe that weight training only for men who want to "bulk" or build muscle.
<G-vec00084-002-s109><build.aufbauen><de> Aber viele Frauen glauben, dass Krafttraining ist nur für Männer, die wollten "Bulk-up " oder Muskeln aufzubauen.
<G-vec00084-002-s110><build.aufbauen><en> These materials are solid proteins when they are used to build lean muscle.
<G-vec00084-002-s110><build.aufbauen><de> Diese Materialien sind feste Proteine, wenn sie verwendet werden, um Muskelmasse aufzubauen.
<G-vec00084-002-s111><build.aufbauen><en> If something goes wrong: Trigger chaos / civil war, because the end goal is the demolition of the old order to build the new on the ruins – with reduced slaves population.
<G-vec00084-002-s111><build.aufbauen><de> Sollte etwas schief gehen: Chaos/Bürgerkrieg auslösen, denn das Endziel ist der Abriss der alten Ordnung, um die Neue auf den Ruinen aufzubauen – mit reduzierter Sklavenbevölkerung.
<G-vec00084-002-s112><build.aufbauen><en> This model will definitely help ourselves to ask the right questions and to build our company on a solid basis.
<G-vec00084-002-s112><build.aufbauen><de> Der Geschäftsplan wird uns helfen, uns die richtigen Fragen zu stellen und unsere Firma auf stabilem Grund aufzubauen.
<G-vec00084-002-s113><build.aufbauen><en> A highly functional website can help you build your brand...
<G-vec00084-002-s113><build.aufbauen><de> Eine hochfunktionelle Website kann Ihnen dabei helfen, Ihre Marke aufzubauen...
<G-vec00084-002-s133><build.bauen><en> Plot with permission to build a large villa with pool and garden, located close to all amenities with good access, between Estômbar and Lagoa.
<G-vec00084-002-s133><build.bauen><de> Grundstück in Erlaubnis zum Bau einer großen Villa mit Pool und Garten, in der Nähe von allen Annehmlichkeiten in Lagoa.
<G-vec00084-002-s134><build.bauen><en> The currently applicable building codes allow on each property to build a country house with up to 500 m² of living space.
<G-vec00084-002-s134><build.bauen><de> Die derzeit gültigen Baunormen erlauben auf jedem Grundstück den Bau eines Landhauses mit bis zu 500 m² Wohnfläche.
<G-vec00084-002-s135><build.bauen><en> History The Bed and Breakfast business in the Casa di Peppino e Lucia was started in the summer of 2008, but the history of this house began in the early 60’s when Peppino Aiello and Lucia Puccio decided to build it.
<G-vec00084-002-s135><build.bauen><de> Geschichte Das B&B besteht seit Sommer 2008, aber die Geschichte dieses Hauses ist schon viel älter – sie beginnt in den frühen 60er Jahren, als Peppino Aiello und Lucia Puccio sich zum Bau des Hauses entschieden haben.
<G-vec00084-002-s136><build.bauen><en> With our listings of land for sale in Mallorca you can find that perfect plot to start your build.
<G-vec00084-002-s136><build.bauen><de> Mit unseren Grundstücksangeboten auf Mallorca können Sie das perfekte Grundstück für Ihren Bau finden.
<G-vec00084-002-s137><build.bauen><en> The majority of the raw materials (such as wood and Co.), which we need to build our loving Floors, we source from the region.
<G-vec00084-002-s137><build.bauen><de> Den Großteil der Rohstoffe (wie Holz und Co.), die wir zum Bau unserer liebevollen Floors benötigen, beziehen wir aus der Region.
<G-vec00084-002-s138><build.bauen><en> In 2001, Sultan Qaboos decided by royal decree to build an opera house in Oman's capital, Muscat.
<G-vec00084-002-s138><build.bauen><de> Im Jahr 2001 beschloss Sultan Qaboos durch ein königliches Dekret den Bau eines Opernhauses in Omans Haupt...
<G-vec00084-002-s139><build.bauen><en> When the rush finished, they were desperate for work, so the farmers had them build dams.
<G-vec00084-002-s139><build.bauen><de> Als sie nach Beendigung des Goldrausches nach Arbeit suchten, stellten die Farmer sie zum Bau von Dämmen an.
<G-vec00084-002-s140><build.bauen><en> Who ever buys this kit should know that he buys pure Science Fiction or a nice spare parts box with parts to build several better Mistel Models .
<G-vec00084-002-s140><build.bauen><de> Wer sich diesen Bausatz kauft, der sollte sich bewußt sein, daß er hier pure Science Fiction erwirbt oder eine schöne Grabelkiste mit Einzelteilen zum Bau verschiedener besserer Mistel Modelle.
<G-vec00084-002-s141><build.bauen><en> The inside of the church is made of different but harmonious materials: the floor is of Kalithea white marble with a grey cross of Gramata marble – the same kind of stone was used to build the pulpit; the window panes are in onyx, the balustrades and the altars in marble, the tables are monolithic blocks of Gramata stone and the tabernacles are in Kamiros stone.
<G-vec00084-002-s141><build.bauen><de> Das Innere der Kirche besteht aus verschiedenen, aber gut harmonierenden Materialien: der Boden ist aus Calitea mit weißen Marmor und einem grauen Kreuz aus Gramata Marmor – der gleiche Stein, der für den Bau der Kanzel benutzt wurde; die Fensterscheiben sind aus Onyx, die Balustraden und der Altar aus Marmor, die Tische gigantische Gramata Marmor Steinblöcke und die Stiftshütten sind aus Camiro Stein.
<G-vec00084-002-s142><build.bauen><en> To build the XOno is in my opinion a plus for most audio systems.
<G-vec00084-002-s142><build.bauen><de> Der Bau des XOno lohnt sich meiner Meinung nach auf jeden Fall und ist sicherlich ein Gewinn in fast jeder Audio Kette.
<G-vec00084-002-s143><build.bauen><en> At the museum of the city's history you can see that the grave stones were used to build the city walls.
<G-vec00084-002-s143><build.bauen><de> Im Museum der Stadtgeschichte können Sie auch die Verwendung der Grabsteine zum Bau der Stadtmauer sehen.
<G-vec00084-002-s144><build.bauen><en> The estimated project economics for Canarc to build and operate a 750 tonne per day gold mine at New Polaris using bio-oxidation followed by a leaching process to produce 80,000 ounces of gold per year in doré bars at site are reasonably achievable for this project.
<G-vec00084-002-s144><build.bauen><de> Die geschätzte Projektwirtschaftlichkeit für den Bau und Betrieb einer Goldmine mit 750 Tagestonnen Kapazität bei New Polaris mittels Bio-Oxidation gefolgt von einem Laugungsverfahren zur Herstellung von 80.000 Unzen Gold pro Jahr in Form von Doré-Barren vor Ort durch Canarc ist vernünftigerweise erreichbar.
<G-vec00084-002-s145><build.bauen><en> KfW is also contributing to a fund that provides finance to help people on moderate or low incomes to build energy-efficient houses.
<G-vec00084-002-s145><build.bauen><de> Die KfW ist zudem an einem Fonds beteiligt, der den Bau energieeffizienter Häuser für Menschen mit mittleren und niedrigen Einkommen finanziert.
<G-vec00084-002-s146><build.bauen><en> The focus remains to increase renewable capacity and to build highly efficient fossil-fuel-fired power stations.
<G-vec00084-002-s146><build.bauen><de> Schwerpunkt bleibt der Ausbau der erneuerbaren Energien und der Bau von hocheffizienten fossil befeuerten Kraftwerken.
<G-vec00084-002-s147><build.bauen><en> This big contract to build the dome and main structure is expected to be awarded towards the end of 2014.
<G-vec00084-002-s147><build.bauen><de> Die Vergabe dieses großen Vertrags über den Bau des Schutzbaus und der Hauptstruktur wird voraussichtlich gegen Ende des Jahres 2014 abgeschlossen sein.
<G-vec00084-002-s148><build.bauen><en> There are more ways than ever before to build, conquer, and inspire.
<G-vec00084-002-s148><build.bauen><de> Es gibt mehr Möglichkeiten für Bau, Eroberung und Inspiration als je zuvor.
<G-vec00084-002-s149><build.bauen><en> Build yourself your own RePricing for eBay.
<G-vec00084-002-s149><build.bauen><de> Bau dir dein eigenes RePricing für ebay.
<G-vec00084-002-s150><build.bauen><en> Call "I am the descendant of Sir Sobha Singh who worked closely with Sir Edwin Lutyens to construct and build the city of New Delhi.
<G-vec00084-002-s150><build.bauen><de> „Ich bin ein Nachkomme von Sir Sobha Singh, einem engen Mitarbeiter von Sir Edwin Lutyens bei Planung und Bau der Stadt Neu Delhi.
<G-vec00084-002-s151><build.bauen><en> So the LORD scattered them abroad from thence upon the face of all the earth: and they left off to build the city.
<G-vec00084-002-s151><build.bauen><de> 8 So zerstreute der Herr die Menschen über die ganze Erde; den Bau der Stadt mussten sie abbrechen.
<G-vec00084-002-s152><build.bauen><en> Build a house from cards with the highest value.
<G-vec00084-002-s152><build.bauen><de> Baue ein Kartenhaus mit dem höchstmöglichen Wert.
<G-vec00084-002-s153><build.bauen><en> Build a Farm.
<G-vec00084-002-s153><build.bauen><de> Baue eine Farm.
<G-vec00084-002-s154><build.bauen><en> Build 100 Missile towers.
<G-vec00084-002-s154><build.bauen><de> Baue 100 Raketen-Türme.
<G-vec00084-002-s155><build.bauen><en> With Live and Push this has completely changed actually, because I either start with a melody or a drum loop that I construct myself and then build on it and the song is created along the way.
<G-vec00084-002-s155><build.bauen><de> Mit Live und Push hat sich das komplett geändert eigentlich, weil ich fang entweder mit einer Melodie oder einem Drum-Loop an, den ich mir zusammenbaue und baue dann darauf auf und das Lied entsteht so währenddessen.
<G-vec00084-002-s156><build.bauen><en> Ezra 1:3 - Who is there among you of all his people? his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of the LORD God of Israel, (he is the God,) which is in Jerusalem.
<G-vec00084-002-s156><build.bauen><de> 3 Wer irgend unter euch aus seinem Volke ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem, das in Juda ist, und baue das Haus Jahwes, des Gottes Israels (er ist Gott), in Jerusalem.
<G-vec00084-002-s157><build.bauen><en> Build shoulder muscles by lifting dumbbells out from your sides for resistance.
<G-vec00084-002-s157><build.bauen><de> Baue Schulter- und Nackenmuskulatur auf, indem du seitliche Hantelübungen für mehr Kraft ausführst.
<G-vec00084-002-s158><build.bauen><en> Build Lumber Yards to secure a steady supply of raw materials and Upgrade them to increase production.
<G-vec00084-002-s158><build.bauen><de> Baue Holzlager, um für stetigen Nachschub an Rohmaterial zu sorgen und verbessere sie, um deine Produktion zu steigern.
<G-vec00084-002-s159><build.bauen><en> Build your organic grocery store, cozy movie theater, vintage diner, relaxing spa, classic Bed & Breakfast, dreamy beach cafe and more.
<G-vec00084-002-s159><build.bauen><de> Baue deinen Biokostladen, ein gemütliches Kino, einen altmodischen Imbiss, ein entspannendes Kurbad, eine klassische Pension, ein verträumtes Strandcafé und mehr.
<G-vec00084-002-s160><build.bauen><en> Founded in 1947 by Edwin J. Montalvo Sr. the Montalvo Corporation continues the core principle it was built on: build a product right the first time and back it up with the highest quality service and support.
<G-vec00084-002-s160><build.bauen><de> Gegründet 1947 von Edwin J. Montalvo Sr. gilt bei der Montalvo Corporation nach wie vor ihr Grundprinzip, auf dem es aufgebaut wurde: baue ein Produkt bereits beim ersten Mal richtig und unterstütze es mit einem erstklassigen Service und Support.
<G-vec00084-002-s161><build.bauen><en> Build your dream team - Choose from among the best football stars of all time and build a team to take home the glory in FIFA Ultimate Team.
<G-vec00084-002-s161><build.bauen><de> Traumteam zusammenstellen - Verpflichte die besten Fußballstars aller Zeiten und baue in FIFA Ultimate Team eine Mannschaft auf, die dir jede Menge Ruhm einbringt.
<G-vec00084-002-s162><build.bauen><en> Build, buy and sell houses.
<G-vec00084-002-s162><build.bauen><de> Baue, verbaue und verkaufe Häuser.
<G-vec00084-002-s163><build.bauen><en> Let yourself be engulfed by the rich world of the Dark Souls. Gradually build your character, discover scary locations, and collect and master an extensive range of weapons, equipment and magic spells to create a truly unique gaming experience.
<G-vec00084-002-s163><build.bauen><de> Erlebe die dunkle Welt der dunklen Seelen, baue deinen Charakter Schritt nach Schritt auf, entdecke erschreckende Orte und sammle und meistere eine umfangreiche Sammlung von Waffen, Ausrüstung und Zaubersprüchen, um ein wirklich einzigartiges Spielerlebnis zu erschaffen.
<G-vec00084-002-s164><build.bauen><en> His God is with him, and he doth go up to Jerusalem, that [is] in Judah, and build the house of Jehovah, God of Israel -- He [is] God -- that [is] in Jerusalem.
<G-vec00084-002-s164><build.bauen><de> 3Wer nun unter euch von seinem Volk ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem in Juda und baue das Haus des HERRN, des Gottes Israels; das ist der Gott, der zu Jerusalem ist.
<G-vec00084-002-s165><build.bauen><en> Build your case with logical reasoning and fact while adding in an emotional element.
<G-vec00084-002-s165><build.bauen><de> Baue dein Anliegen mit logischen Argumenten und Fakten auf und setze dann einen emotionalen Bestandteil ein.
<G-vec00084-002-s166><build.bauen><en> Build fluency and confidence through interactive Danish classes that are effective and fun.
<G-vec00084-002-s166><build.bauen><de> Baue deine Fremdsprachkenntnisse und dein Selbstvertrauen durch interaktiven Online-Unterricht auf.
<G-vec00084-002-s167><build.bauen><en> Build your own monster vehicle with weapons to take part in crazy racing tracks.
<G-vec00084-002-s167><build.bauen><de> Baue dein eigenes Monster Vehikel, mit Deinen bevorzugten Waffen.
<G-vec00084-002-s168><build.bauen><en> Build a party of famous warriors and epic monsters from Dragon...
<G-vec00084-002-s168><build.bauen><de> Baue eine Gruppe aus berühmten Kriegern und epischen Monstern aus...
<G-vec00084-002-s169><build.bauen><en> If I build an elephant house for a zoo, I have to deal with elephants.
<G-vec00084-002-s169><build.bauen><de> Wenn ich für einen Zoo ein Elefantenhaus baue, muss ich mich mit Elefanten beschäftigen.
<G-vec00084-002-s170><build.bauen><en> I build two new bikes.
<G-vec00084-002-s170><build.bauen><de> Ich baue zwei neue Motorräder auf.
<G-vec00084-002-s171><build.bauen><en> 3:2 He began to build in the second [day] of the second month, in the fourth year of his reign.
<G-vec00084-002-s171><build.bauen><de> 3:2 Und er fing an zu bauen im zweiten Monat, am zweiten [Tag] im vierten Jahr seiner Regierung.
<G-vec00084-002-s172><build.bauen><en> Build a beautiful pair of Pandora earring with these 14K gold and Onyx Drop charms.
<G-vec00084-002-s172><build.bauen><de> Bauen Sie ein schönes Paar Pandora Ohrring mit diesen 14K Gold und Onyx Tropfen Reize.
<G-vec00084-002-s173><build.bauen><en> In one of the few places in the world where you can surf in the morning and ski in the afternoon, Nick set out to build a vehicle that could deal with the climatic extremes of his “Urban Adventures”.
<G-vec00084-002-s173><build.bauen><de> In einem der wenigen Orte auf der Welt, wo man am Morgen surfen und am Nachmittag Skifahren kann, hat sich Nick vorgenommen, ein Fahrzeug zu bauen, das mit den klimatischen Extremen seines "Stadtabendteuers" umgehen konnte.
<G-vec00084-002-s174><build.bauen><en> 10See, today I appoint you over nations and kingdoms to uproot and tear down, to destroy and overthrow, to build and to plant.’
<G-vec00084-002-s174><build.bauen><de> 10Siehe, ich bestelle dich an diesem Tage über die Nationen und über die Königreiche, um auszurotten und niederzureißen und zu zerstören und abzubrechen, um zu bauen und um zu pflanzen.
<G-vec00084-002-s175><build.bauen><en> "The decision to build a house is elementary and a long-term decision.
<G-vec00084-002-s175><build.bauen><de> Bemusterungszentrum Hartenfels „Die Entscheidung ein Haus zu bauen ist elementar und langfristig.
<G-vec00084-002-s176><build.bauen><en> We are confident that we can create a system that is tightly scoped to our needs that will not be complex to design, build and deploy.
<G-vec00084-002-s176><build.bauen><de> Wir sind zuversichtlich, dass wir ein System erschaffen können, welches sich fest an unsere Bedingungen anpasst und dabei einfach zu entwerfen, bauen und einzusetzen ist.
<G-vec00084-002-s177><build.bauen><en> Easily build your own custom app to meet the unique – and changing – needs of your business.
<G-vec00084-002-s177><build.bauen><de> Bauen Sie ganz einfach Ihre eigene maßgeschneiderte App auf, um den speziellen – und sich verändernden – Anforderungen Ihres Unternehmens gerecht zu werden.
<G-vec00084-002-s178><build.bauen><en> 3 You know how that David my father could not build an house to the name of the LORD his God for the wars which were about him on every side, until the LORD put them under the soles of his feet.
<G-vec00084-002-s178><build.bauen><de> 3 Du weißt, daß David, mein Vater, nicht vermochte, ein Haus zu bauen dem Namen Jehova's, seines Gottes, wegen des Krieges, womit sie ihn umgaben, bis sie Jehova unter seine Fußsohlen legte.
<G-vec00084-002-s179><build.bauen><en> Since then it has been his claim to build the best possible tools ever.
<G-vec00084-002-s179><build.bauen><de> Seitdem ist es sein Anspruch, das bestmögliche Werkzeug überhaupt zu bauen.
<G-vec00084-002-s180><build.bauen><en> The announced fact that some businessmen are planing to build big hotel complexes on different nature protected areas abusing all existing laws provokes civic attention and in fact this ecological in its beginning protests grown into civil ones, attracting a lot of students and young people.
<G-vec00084-002-s180><build.bauen><de> Mira Die öffentlich bekannt gegebene Tatsache, dass einige Geschäftsmänner große Hotelkomplexe auf verschiedenen naturgeschützten Geländen zu bauen beabsichtigen, wobei sie gültige Gesetze missachten, provozierte die zivile Öffentlichkeit, womit diese ursprünglich ökologisch motivierten Proteste zu einem zivilen, viele Studenten und Jugendliche anziehenden Widerstand wurden.
<G-vec00084-002-s181><build.bauen><en> This lovely plot is tranquill, has good connections, beautiful surroundings and ample space to build a large villa with pool and terraces.
<G-vec00084-002-s181><build.bauen><de> Hier genießt man Ruhe, hat eine gute Anbindung, eine schöne Umgebung und Platz, um eine große Villa mit Pool und Terrassen zu bauen.
<G-vec00084-002-s182><build.bauen><en> With Drupal 8, you can build almost any integrated experience you can imagine.
<G-vec00084-002-s182><build.bauen><de> Mit Drupal 8 können Sie so gut wie jeden integrierten Web-Auftritt bauen, den Sie sich vorstellen können.
<G-vec00084-002-s183><build.bauen><en> We build on the experience, motivation and qualifications of our employees to fulfill the most sophisticated customer requirements with excellence and dedication.
<G-vec00084-002-s183><build.bauen><de> Wir bauen auf die Erfahrung, Motivation und Qualifikation unserer Mitarbeitenden, um selbst die anspruchsvollsten Kundenanforderungen kompetent und mit persönlichem Einsatz zu erfüllen.
<G-vec00084-002-s184><build.bauen><en> Build with LemonChili many pages and beverage menu, as you want.
<G-vec00084-002-s184><build.bauen><de> Bauen Sie mit LemonChili viele Seiten und Getränkekarte, wie Sie wollen.
<G-vec00084-002-s185><build.bauen><en> “More and more Is- tanbulites are buying land in the area to build villas and holiday homes, thus taking land away from agriculture.
<G-vec00084-002-s185><build.bauen><de> «Immer mehr Istanbuler erwerben außerdem Land in der Um- gebung, um Villen und Ferienhäuser zu bauen – dieses Land geht der Landwirt- schaft verloren.
<G-vec00084-002-s186><build.bauen><en> Help Jane to make the pickiest customers happy: choose refined furniture, build a golf course and please your customers with exquisite drinks and good meals.
<G-vec00084-002-s186><build.bauen><de> Helfen Sie Jane die heikelste Kunden glücklich zu machen: Wählen Sie raffinierte Möbel, einen Golfplatz zu bauen und bitte Sie Ihre Kunden mit exquisiten Drinks und gutes Essen.
<G-vec00084-002-s187><build.bauen><en> Our mission is to build lightweight, efficient, all-terrain bikes that build two-wheeled balance, coordination, and confidence in children.
<G-vec00084-002-s187><build.bauen><de> Unser Ziel ist es, leichtgewichtige, effiziente Geländeräder zu bauen, die das Gleichgewichthalten, die Koordination und das Selbstvertrauen von Kindern fördern.
<G-vec00084-002-s188><build.bauen><en> It is our aim to build and operate properties with their setting, with the result to achieve a maximum of user satisfaction, productivity and efficiency by using a minimum of resources (ecology, economy, personal expenditure).
<G-vec00084-002-s188><build.bauen><de> Unser Ziel ist es, Immobilien und deren Umfeld zu bauen und zu betreiben, so dass mit einem Minimum an Ressourcen (Ökologie, Ökonomie, Personalaufwand) ein Maximum an Nutzerzufriedenheit, Produktivität und Effizienz erreicht werden kann.
<G-vec00084-002-s189><build.bauen><en> Print Bodyshop We engineer, design, build and install manual as well as automatic systems for hemflange adhesive application as well as for cosmetic sealing, untiflutter and sounddeadener.
<G-vec00084-002-s189><build.bauen><de> Wir planen, konstruieren, bauen und installieren manuelle und automatische Anlagen für die Nahtabdichtungen, Kosmetiksealer, Unterbodenschutzauftrag, Schweller-Beschichtungssysteme sowie für spritzbare Schalldämmmassen.
<G-vec00084-002-s190><build.bauen><en> Protect the devices customers depend on and build trust in your brand.
<G-vec00084-002-s190><build.bauen><de> Schützen Sie die Geräte, auf die Kunden angewiesen sind, und bauen Sie das Vertrauen in Ihre Marke auf.
<G-vec00084-002-s191><build.bauen><en> Multiplayer— Build a region with friends for the first time!
<G-vec00084-002-s191><build.bauen><de> Multiplayer: Bauen Sie zum ersten Mal mit Freunden eine ganze Region auf.
<G-vec00084-002-s192><build.bauen><en> Build deeper customer relationships and personalized digital experiences with AI, while lowering operating costs and boosting return on investment.
<G-vec00084-002-s192><build.bauen><de> Bauen Sie engere Kundenbeziehungen und ein personalisiertes digitales Erlebnis mit KI auf, während die Kosten sinken und der Return-on-Investment steigt.
<G-vec00084-002-s193><build.bauen><en> Build upon your existing IT infrastructure with a step-by-step approach featuring technologies engineered to optimize your future infrastructure. Learn more Events
<G-vec00084-002-s193><build.bauen><de> Bauen Sie mit einer Schritt-für-Schritt-Methode auf Ihrer bestehenden IT-Infrastruktur auf und nutzen Sie dabei Technologien, die eigens in Hinblick auf eine Optimierung Ihrer künftigen Infrastruktur entwickelt wurden.
<G-vec00084-002-s194><build.bauen><en> Use individual customer scores to build personalized automation workflows.
<G-vec00084-002-s194><build.bauen><de> Bauen Sie mithilfe des Punktestands einzelner Kunden personalisierte Automatisierungsworkflows.
<G-vec00084-002-s195><build.bauen><en> - Hard coating, avoid the light pollution and build good ecological environment.
<G-vec00084-002-s195><build.bauen><de> - Harte Beschichtung, vermeiden Sie die Lichtverschmutzung und bauen Sie eine gute ökologische Umgebung.
<G-vec00084-002-s196><build.bauen><en> Build the web site and all documents.
<G-vec00084-002-s196><build.bauen><de> Bauen Sie die Webseite und alle Dokumente.
<G-vec00084-002-s197><build.bauen><en> Build the essential relationships that set the foundation for ExxonMobil’s continued industry leadership.
<G-vec00084-002-s197><build.bauen><de> Bauen Sie die richtigen Geschäftsbeziehungen auf, die die Grundlage für ExxonMobils fortwährende Führungsrolle innerhalb der Branche schaffen.
<G-vec00084-002-s198><build.bauen><en> Build mission-critical applications and take advantage of open frameworks, open source applications, and various development languages.
<G-vec00084-002-s198><build.bauen><de> Bauen Sie Auftrag-kritische Anwendungen auf und nutzen Sie offene Rahmen, Anwendungen der offenen Quelle und verschiedene Entwicklungssprachen.
<G-vec00084-002-s199><build.bauen><en> Build a rock-solid network for mission-critical business applications.
<G-vec00084-002-s199><build.bauen><de> Bauen Sie ein zuverlässiges Netzwerk für geschäftskritische Unternehmensanwendungen.
<G-vec00084-002-s200><build.bauen><en> Build with us – it’s pleasure combined with good business
<G-vec00084-002-s200><build.bauen><de> Bauen Sie mit uns – so verbinden Sie ein Vergnügen mit gutem Geschäft.
<G-vec00084-002-s201><build.bauen><en> Build great user experience
<G-vec00084-002-s201><build.bauen><de> Bauen Sie großartige Benutzererfahrung auf.
<G-vec00084-002-s202><build.bauen><en> Partner with us to build the perfect production facility to meet your business needs.
<G-vec00084-002-s202><build.bauen><de> Werden Sie unser Partner und bauen Sie sich Ihre perfekte Produktionsstätte nach Ihren Geschäftsvorstellungen.
<G-vec00084-002-s203><build.bauen><en> Build your tomorrow, today.
<G-vec00084-002-s203><build.bauen><de> Bauen Sie sich heute Ihre Zukunft auf.
<G-vec00084-002-s204><build.bauen><en> Build over 60 base upgrades and large scale secret projects for your empire.
<G-vec00084-002-s204><build.bauen><de> Bauen Sie über 60 Basiseinrichtungen und gewaltige Geheimprojekte, um Ihren Machtbereich auszuweiten.
<G-vec00084-002-s205><build.bauen><en> Description Build your city township - build houses, decorations, decorate the streets.
<G-vec00084-002-s205><build.bauen><de> Errichten Sie die Stadt aus der Siedlung, bauen Sie Häuser und ihre Ausstattung, dekorieren Sie Straßen.
<G-vec00084-002-s206><build.bauen><en> Lose weight, build lean muscle and increase energy with this 20-minute workout.
<G-vec00084-002-s206><build.bauen><de> Verlieren Sie an Gewicht, bauen Sie schlanke Muskeln auf und steigern Sie mit diesem 20-Minuten-Programm Ihre Kraft.
<G-vec00084-002-s207><build.bauen><en> Build your IoT success on our foundation of 100+ years developing operational technologies and 50+ years creating IT innovation and solutions. Improve Efficiency
<G-vec00084-002-s207><build.bauen><de> Bauen Sie für Ihren IoT-Erfolg auf das technologische Fundament von über 100 Jahren Erfahrung in der Entwicklung operativer Technologien und mehr als 50 Jahren von IT-Innovationen und -Lösungen.
<G-vec00084-002-s208><build.bauen><en> Build on your taste in the game.
<G-vec00084-002-s208><build.bauen><de> Bauen Sie auf Ihren Geschmack im Spiel.
<G-vec00084-002-s209><build.bauen><en> Structure a company wiki, build a self-service knowledge base, and onboard new hires simply and effectively.
<G-vec00084-002-s209><build.bauen><de> Legt ein Unternehmens-Wiki an, baut eine Wissensdatenbank für die Mitarbeiter auf und bringt neue Kollegen schnell und effektiv auf Stand.
<G-vec00084-002-s210><build.bauen><en> Whoever has no house will never build one now.
<G-vec00084-002-s210><build.bauen><de> Wer jetzt kein Haus hat, baut sich keines mehr.
<G-vec00084-002-s211><build.bauen><en> In fact, at times the Lord himself is one who ”uproots”, ”tears down”, ”destroys” and ”overthrows” in order to ”build” and to ”plant”.
<G-vec00084-002-s211><build.bauen><de> Tatsächlich ist zu gewissen Zeiten der Herr selbst einer, der „entwurzelt“, „herunterreißt“, „zerstört“ und „übergibt“, bevor er „baut“ und „pflanzt“.
<G-vec00084-002-s212><build.bauen><en> Making changes in your body takes time but if you have been working hard for a few months and still do not see results, it's a sign that you need to learn how to build muscles faster.
<G-vec00084-002-s212><build.bauen><de> Veränderungen in Ihrem Körper braucht Zeit, aber wenn Sie seit ein paar Monaten hart gearbeitet haben und immer noch keine Ergebnisse sehen, ist es ein Zeichen, dass Sie lernen müssen, wie man Muskeln schneller baut.
<G-vec00084-002-s213><build.bauen><en> Verner Panton is not about superficial effects, he is more inclined to build upon the functional persuasiveness of an idea.
<G-vec00084-002-s213><build.bauen><de> Verner Panton ist nicht auf vordergründige Effekte aus, er baut vielmehr auf die funktionale Überzeugungskraft einer Idee.
<G-vec00084-002-s214><build.bauen><en> They argue that the only way to avoid using energy or resources is to not build at all.
<G-vec00084-002-s214><build.bauen><de> Nur wer gar nicht baut, verbraucht weder Energie noch Ressourcen.
<G-vec00084-002-s215><build.bauen><en> This will help improve your form, and build up the arm and shoulder strength needed for one-handed cartwheels.
<G-vec00084-002-s215><build.bauen><de> Das hilft dir, deine Form zu verbessern und baut die Kraft in den Schultern und Armen auf, die du zum Radschlagen brauchst.
<G-vec00084-002-s216><build.bauen><en> Build the sacred room, dear ones, with the stones of your own walls mixed with the mortar of the love of Home.
<G-vec00084-002-s216><build.bauen><de> Baut den Heiligen Raum, Ihr Lieben, mit den Steinen eurer eigenen gefallenen Mauern, vermischt mit dem Mörtel der Liebe von Zuhause.
<G-vec00084-002-s217><build.bauen><en> Far from being a single product, the term refers to a culture or “software development discipline, where you build software in such a way that [it] can be released to production at any time,” explains Martin Fowler.
<G-vec00084-002-s217><build.bauen><de> Es handelt sich dabei nicht um ein einzelnes Produkt, sondern der Begriff bezieht sich auf eine Kultur oder „Software-Entwicklungsdisziplin, wo man Software auf eine Weise baut, dass sie jederzeit für die Produktion freigegeben werden kann“, erklärt Martin Fowler.
<G-vec00084-002-s218><build.bauen><en> You build deep connections to your fellow students and this cohesion is a really, really strong asset of HHL.
<G-vec00084-002-s218><build.bauen><de> Man baut tiefgehende Verbindungen zu seinen Kommilitonen auf und dieser Zusammenhalt ist ein richtig, richtig starkes Asset der HHL.
<G-vec00084-002-s219><build.bauen><en> This causes a brake pressure to build up, which stops the cutterhead.
<G-vec00084-002-s219><build.bauen><de> Dadurch baut sich ein Bremsdruck auf, der die Häckseltrommel stoppt.
<G-vec00084-002-s220><build.bauen><en> Your confidence in the water will grow and you’ll build on what you’ve already learned.
<G-vec00084-002-s220><build.bauen><de> Der Kurs baut auf dem auf, was du bereits gelernt hast und erweitert deine Kenntnisse.
<G-vec00084-002-s221><build.bauen><en> Therefore, Jeremiah sent a letter to the exiled recommending to organize themselves in Babylon, to “build houses, settle down… marry and have sons and daughters… work for the good of the city to which I have exiled you; pray to Yahweh on its behalf. For Yahweh says this: “When the seventy years granted to Babylon are over… I will bring you back to this place” (Jeremiah 29,4-10).
<G-vec00084-002-s221><build.bauen><de> Jeremia sandte zu dieser Zeit einen Brief an die Verbannten mit dem Rat sie sollten sich in Babylonien organisieren: “Baut Häuser und wohnt darin… Nehmt euch Frauen und zeugt Söhne und Töchter… Bemüht euch um das Wohl der Stadt, aus der ich euch weggeführt habe, und betet für sie zum Herrn… Denn so spricht der Herr: Wenn siebzig Jahre für Babel vorüber sind, dann werde ich euch an diesen Ort zurückführen” (Jeremia 29,4-10).
<G-vec00084-002-s222><build.bauen><en> Castle Wars 2 is the sequel to Castle wars, and is a very addictive card game where your goal is to crush your enemy's castle or be the first to build a 100 storey castle.
<G-vec00084-002-s222><build.bauen><de> Castle Wars 2 ist die Fortsetzung von Castle Wars 1 und ein sehr fesselndes Kartenspiel, in dem es Dein Ziel ist, die feindliche Burg zu vernichten oder der Erste zu sein, der eine Burg mit 100 Stockwerken baut.
<G-vec00084-002-s223><build.bauen><en> You have fought many wars. You are not the one who will build a house for my Name.
<G-vec00084-002-s223><build.bauen><de> Weil du so viel Blut vor mir vergossen hast, sollst du es nicht sein, der ein Haus zu Ehren meines Namens baut.
<G-vec00084-002-s224><build.bauen><en> The Master's degree in German Studies is designed to follow and build on the academic skills acquired during the Bachelor's degree and is substantially research-based.
<G-vec00084-002-s224><build.bauen><de> Der konsekutiv angelegte Masterstudiengang Germanistik baut auf den im Bachelorstudium erworbenen wissenschaftlichen Fähigkeiten auf und ist dezidiert forschungsbezogen gestaltet.
<G-vec00084-002-s225><build.bauen><en> If you build a big church, it can be taken away, as has happened in Central Asia.
<G-vec00084-002-s225><build.bauen><de> Wenn man ein großes Kirchengebäude baut, kann es weggenommen werden, das ist auch in Zentralasien passiert.
<G-vec00084-002-s226><build.bauen><en> VK started to build an agent network in the Baltic countries and Poland.
<G-vec00084-002-s226><build.bauen><de> VK baut ein Netzwerk von Agenten in den baltischen Staaten und in Polen auf.
<G-vec00084-002-s418><build.bauen><en> Increase the number of clan members and open new Zones, which allow you to build additional structures.
<G-vec00084-002-s418><build.bauen><de> Erhöhen Sie die Anzahl der Clanmitglieder und öffnen Sie neue Zonen, in denen zusätzliche Strukturen gebaut werden können.
<G-vec00084-002-s419><build.bauen><en> This lens is build more compact as its neighbor.
<G-vec00084-002-s419><build.bauen><de> Dieses Objektiv ist etwas kompakter gebaut.
<G-vec00084-002-s420><build.bauen><en> Thus making it easier for you to control and navigate, as it is smaller and with a lighter build.
<G-vec00084-002-s420><build.bauen><de> Dadurch ist es für Sie einfacher zu kontrollieren und zu navigieren, da es kleiner und leichter gebaut ist.
<G-vec00084-002-s421><build.bauen><en> The clinics that we cooperate with are a bright example of how to build a team of experts who excel beyond other companies on the market.
<G-vec00084-002-s421><build.bauen><de> Die Kliniken, mit denen wir kooperieren sind ein leuchtendes Beispiel dafür, wie ein Team von Experten gebaut wird, die sich von anderen Unternehmen auf dem Markt auszeichnen.
<G-vec00084-002-s422><build.bauen><en> GIZ has also worked with UNICEF to build seven schools and provide equipment for them.
<G-vec00084-002-s422><build.bauen><de> Außerdem hat die GIZ in Zusammenarbeit mit UNICEF sieben Schulen gebaut und ausgestattet.
<G-vec00084-002-s423><build.bauen><en> It is ideal for those who want buy a special and unique plot where to build a large housing dimensions, with stunning views and total privacy.
<G-vec00084-002-s423><build.bauen><de> Es ist ideal für diejenigen, die ein besonderes und einzigartiges Grundstück kaufen wollen, wo ein großes Haus gebaut werden kann, mit atemberaubender Aussicht und absolute Privatsphäre.
<G-vec00084-002-s424><build.bauen><en> Well build, no health issues.
<G-vec00084-002-s424><build.bauen><de> Gut gebaut, keine gesundheitlichen Probleme.
<G-vec00084-002-s425><build.bauen><en> Top House is build on 2 floors.
<G-vec00084-002-s425><build.bauen><de> Top Haus gebaut auf 2 Etagen.
<G-vec00084-002-s426><build.bauen><en> In the morning, visit Lingyin Buddhist Temple, one of the best known Buddhist monasteries in China, Which was build in 326 at the foot of Linyin Mountain.
<G-vec00084-002-s426><build.bauen><de> Am Morgen besuchen Sie Lingyin Tempel, der im Jahr 326 am Fuß des Linyin Berges gebaut wurde.
<G-vec00084-002-s427><build.bauen><en> Since my homepage in online I've got many requests of people who have never build a loudspeaker system their own.
<G-vec00084-002-s427><build.bauen><de> Seit meine Homepage im Netz ist habe ich viele Anfragen von Leuten bekommen, die noch nie selbst Lautsprecher gebaut haben.
<G-vec00084-002-s428><build.bauen><en> The whole property is build around a pleasant interior courtyard.
<G-vec00084-002-s428><build.bauen><de> Das gesamte Anwesen ist um einen angenehmen Innenhof herum gebaut.
<G-vec00084-002-s429><build.bauen><en> Ailerons At this time the wings are finsihed except the bottom main skins, so it was time to build the elevators and flaps.
<G-vec00084-002-s429><build.bauen><de> Zu diesem Zeitpunkt sind die Tragflächen bis auf die Hauptbeplankung der Unterseite fertig, also müssen erstmal die Querruder und Klappen gebaut werden.
<G-vec00084-002-s431><build.bauen><en> This Microcontroller bases DC power supply is not the simplest circuit but I can assure you that you will not regret the time needed to build it.
<G-vec00084-002-s431><build.bauen><de> Diese Mikrocontroller basierte Stromversorgung ist nicht die einfachste Schaltung, aber ich kann dir versichern, dass du es nicht bereuen wirst, diese Schaltung gebaut zu haben.
<G-vec00084-002-s432><build.bauen><en> He showed how to create automatic swells, to build a preset for an acoustic guitar, to fight annoying frequencies by using peak EQ-ing and more.
<G-vec00084-002-s432><build.bauen><de> Er zeigte, wie ein automatischer Swell gebaut wird, wie man ein Proeset für die Akustische Gitarre anlegt, wie man nervende Frequenzen mit Hilfe des Equalizers eindämmt, und mehr.
<G-vec00084-002-s433><build.bauen><en> To instruct Moses in how to build the sanctuary, God showed him a pattern already existing.
<G-vec00084-002-s433><build.bauen><de> Um Mose anzuweisen, wie das Heiligtum gebaut werden sollte, zeigte ihm Gott ein schon existierendes Vorbild.
<G-vec00084-002-s434><build.bauen><en> Venetian blind motor Airy and transparent – is how we build today.
<G-vec00084-002-s434><build.bauen><de> Luftig und transparent - so wird heute gebaut.
<G-vec00084-002-s435><build.bauen><en> With the right set-up we knew what to do and were quickly able to build up the first engine.
<G-vec00084-002-s435><build.bauen><de> Mit dem richtigen Set-Up wussten wir, was wir zu tun hatten und dann haben wir ziemlich schnell den ersten Motor gebaut.
<G-vec00084-002-s436><build.bauen><en> There was also a new toilet seat beeing build by a few boys.
<G-vec00084-002-s436><build.bauen><de> Außerdem hatten einige Jungs der Gruppe einen Toilettensitz gebaut.
<G-vec00084-002-s228><build.bilden><en> The observations and analyses of social development processes in connection with experiences from missions throughout Germany build important focal points in the approach of the GRC.
<G-vec00084-002-s228><build.bilden><de> Die Beobachtungen und Analysen gesellschaftlicher Entwicklungsprozesse in Verbindung mit Erfahrungen aus Einsätzen in ganz Deutschland bilden hierbei wichtige Schwerpunkte im Vorgehen des DRK.
<G-vec00084-002-s229><build.bilden><en> Hitachi’s array was the one to go with because it’s going to be the foundation to build our media distribution business on, as well as our editorial business on.
<G-vec00084-002-s229><build.bilden><de> Wir haben uns für das Array von Hitachi entschieden, da es die Grundlage für unser Medienverbreitungsgeschäft und unser redaktionelles Geschäft bilden wird.
<G-vec00084-002-s230><build.bilden><en> They build the framework from which to address the (semi)-professional athletes who shop here in a truthful way.
<G-vec00084-002-s230><build.bilden><de> Sie bilden den Rahmen für eine authentische Ansprache der (semi)professionellen Sportler, die hier einkaufen.
<G-vec00084-002-s231><build.bilden><en> Whereby both currencies build one currency pair.
<G-vec00084-002-s231><build.bilden><de> Wobei beide Währungen ein Währungspaar bilden.
<G-vec00084-002-s232><build.bilden><en> On good days, impressive waves build up near the shore.
<G-vec00084-002-s232><build.bilden><de> An guten Tagen bilden sich in Küstennähe beeindruckende Wellen.
<G-vec00084-002-s233><build.bilden><en> A conference, varying exhibition formats, a film and video program, performances, and workshops build its programmatic core.
<G-vec00084-002-s233><build.bilden><de> Den Schwerpunkt des jährlichen Festivals bilden ein Konferenzprogramm, wechselnde Ausstellungsformate, ein Film- und Videoprogramm, Performances und Workshops.
<G-vec00084-002-s234><build.bilden><en> When applying the HLB test one can find out through the way blood proteins are stored and build a net how strongly the body is affected by free radicals which corresponds to the severity of the disease.
<G-vec00084-002-s234><build.bilden><de> Beim HLB-Test kann aus der Art und Weise, wie sich die Bluteiweiße anlagern und ein Netz bilden, abgelesen werden, wie stark der Körper mit freien Radikalen belastet ist, was wiederum mit der Schwere der Erkrankung einhergeht.
<G-vec00084-002-s235><build.bilden><en> These questions build the framework of this talk. Final answers are intentionally not given because questions do not have an expiry date.
<G-vec00084-002-s235><build.bilden><de> Diese Fragen bilden das Gerüst dieses Vortrags, finale Antworten werden bewusst nicht geliefert, denn Fragen haben kein Verfallsdatum, Antworten hingegen schon.
<G-vec00084-002-s236><build.bilden><en> Traders can use support and resistance to build positions: using gains to finance additional lots.
<G-vec00084-002-s236><build.bilden><de> Trader können Unterstützung und Widerstand einsetzen, um Positionen zu bilden: Mittels Gewinnen zur Finanzierung zusätzlicher Lots.
<G-vec00084-002-s237><build.bilden><en> We build the bridge between production sites all over the world and the exacting requirements of European customers.
<G-vec00084-002-s237><build.bilden><de> Wir bilden die Brücke zwischen den Produktionen der ganzen Welt und den anspruchsvollen Kunden in Europa.
<G-vec00084-002-s238><build.bilden><en> Participation in sport and exercise can build trust and facilitate access to further guidance and educational programmes.
<G-vec00084-002-s238><build.bilden><de> Ein Zugang über Sport- und Bewegungsangebote kann Vertrauen bilden und so den Zugang für weitere Beratungs- und Bildungsangebote erleichtern.
<G-vec00084-002-s239><build.bilden><en> The cavities build up a threedimensional branched system. In the crystal structure determination no guest molecules were found to be in these cavities.
<G-vec00084-002-s239><build.bilden><de> Die Hohlräume bilden ein dreidimensional verzweigtes System, in dem in der Einkristallstrukturanalyse keine Gastmoleküle lokalisiert werden konnten.
<G-vec00084-002-s240><build.bilden><en> The stillness and beauty of Nature with its mountains, lakes, narrow valleys and scenic trails build the backdrop for rejuvenation, connecting with intuition and listening to the longing of our “True Nature”.
<G-vec00084-002-s240><build.bilden><de> Die Ruhe sowie die wunderschöne Natur mit ihrer Hügel- und Berglandschaft, weiten Seen, engen Tälern und herrlichen Wegen bilden einen energievollen Rahmen für Entschleunigung und kraftvolles Auftanken.
<G-vec00084-002-s241><build.bilden><en> RAe/StB build an office community and not a common firm with the consultancy company.
<G-vec00084-002-s241><build.bilden><de> RAe/StB bilden mit der Unternehmensberatung eine Bürogemeinschaft und keine Sozietät.
<G-vec00084-002-s242><build.bilden><en> Alternating stripes of classical herringbone and basket weaves build a tonal design, whose pattern affords both interesting close-up views and a broad texture when seen from further afar.
<G-vec00084-002-s242><build.bilden><de> Wechselnde Streifen des Fischgrätmusters und Leinenbindung bilden ein komplexes Design, dessen Muster sowohl interessante Nahansichten bietet als auch eine breite Textur aus der Ferne.
<G-vec00084-002-s243><build.bilden><en> With grammar, the student has the essential basis to build the correct sentences.
<G-vec00084-002-s243><build.bilden><de> Durch die Grammatik bekommt der Student die unentbehrliche Basis, um einen korrekten Satz zu bilden.
<G-vec00084-002-s244><build.bilden><en> We have made investments in developing an Automotive Competence Center which has allowed us to build a team of industry experts to best support our customers this growing sector," said Cindy Haring, managing director DHL Global Forwarding Brazil.
<G-vec00084-002-s244><build.bilden><de> Wir haben in ein Kompetenzzentrum für den Automobilbereich investiert und konnten ein Team von Branchenexperten bilden, welches unsere Kunden in diesem Wachstumssektor bestmöglich unterstützen", sagte Cindy Haring, Managing Director von DHL Global Forwarding Brasilien.
<G-vec00084-002-s245><build.bilden><en> The battle is not only to locate the best talent, it is to build teams around it, and to ensure the competencies the CFO needs to drive better productivity in their department are available.
<G-vec00084-002-s245><build.bilden><de> Es geht nicht nur darum, die talentiertesten Mitarbeiter ausfindig zu machen, sondern auch darum, Teams um sie herum zu bilden und dabei sicherzustellen, dass die Kompetenzen, die der CFO zur Steigerung der Produktivität in seiner Abteilung benötigt, verfügbar sind.
<G-vec00084-002-s246><build.bilden><en> In phase 2, glyceraldehyde-3-phosphate – a sugar with three carbon atoms from which the plant can build other organic compounds – forms.
<G-vec00084-002-s246><build.bilden><de> Das Enzym Rubisco ermöglicht die Anlagerung von Zucker mit drei Kohlenstoff-Atomen, aus dem die Pflanze andere organische Verbindungen bilden kann.
<G-vec00084-002-s323><build.errichten><en> To achieve this, we raise the soil and build settlements in cooperation with the population above the inundation level.
<G-vec00084-002-s323><build.errichten><de> Dazu schütten wir Erde auf und errichten in Zusammenarbeit mit der Bevölkerung Siedlungen, die über dem kritischen Pegelstand liegen.
<G-vec00084-002-s324><build.errichten><en> Holzhandlung Gundelach GmbH will build a modern wood retailers on its 18,000 sq.m. site.
<G-vec00084-002-s324><build.errichten><de> Die Holzhandlung Gundelach GmbH wird auf ihrem 18.000 Quadratmeter großen Grundstück eine moderne Holzhandlung errichten.
<G-vec00084-002-s325><build.errichten><en> Over the next few years, the company will also build a large module factory in California.
<G-vec00084-002-s325><build.errichten><de> In den nächsten Jahren wird das Unternehmen zudem eine große Modulfabrik in Kalifornien errichten.
<G-vec00084-002-s326><build.errichten><en> Overview Trellis Formwork is an easy and intuitive system of modular formwork in plastic used to build concrete walls, foundations and columns.
<G-vec00084-002-s326><build.errichten><de> Gitter-Verschalung ist ein einfaches und intuitives System der modularen Verschalung im Plastik, der benutzt wird, um Betonmauern, Grundlagen und Spalten zu errichten.
<G-vec00084-002-s327><build.errichten><en> Everyone who keeps a fence will agree with us: it’s not difficult to build a fence, but it’s difficult to maintain it regularly.
<G-vec00084-002-s327><build.errichten><de> Jeder, der einen Zaun sein eigen nennt, wird uns Recht geben, dass die Schwierigkeit nicht darin besteht, einen Zaun zu errichten, sondern ihn in Ordnung zu halten.
<G-vec00084-002-s328><build.errichten><en> The estate was built in a place where "Domator" housing cooperative had been planning to build a multilevel garage.
<G-vec00084-002-s328><build.errichten><de> Die Investition ist an derjenigen Stelle entstanden, wo die Wohnbaugenossenschaft "Domator" vorhatte, eine Tiefgarage mit mehreren Etagen zu errichten.
<G-vec00084-002-s329><build.errichten><en> We had to build a terrace.
<G-vec00084-002-s329><build.errichten><de> Wir mussten eine Terrasse errichten.
<G-vec00084-002-s330><build.errichten><en> Moreover,we additionally provide hardware and software to build complete solution.
<G-vec00084-002-s330><build.errichten><de> Außerdem stellen wir zusätzlich Hardware und Software zur Verfügung, um komplette Lösung zu errichten.
<G-vec00084-002-s331><build.errichten><en> But this new approach could help us build stronger and lighter materials in the future - which is something that's of great interest to industries such as aerospace and aviation.
<G-vec00084-002-s331><build.errichten><de> Aber dieses neue Konzept könnte uns helfen, die stärkeren und helleren Materialien in der Zukunft zu errichten - das etwas ist, das vom großen Interesse zu den Industrien wie Aerospace und Luftfahrt ist.
<G-vec00084-002-s332><build.errichten><en> Strategy Free Build your military empire and conquer your enemies by becoming a war mastermind.
<G-vec00084-002-s332><build.errichten><de> Strategie Frei Errichten Sie ein Militär-Imperium und besiegen Sie Ihre Feinde mit überlegener Kriegskunst.
<G-vec00084-002-s333><build.errichten><en> In a document released to the public and the media, the group reports speaks of "the state and federal governments' violent actions against the people of San Salvador Atenco, which are now registered among the systematic aggressions against the people of Atenco, starting with the federal government's attempt to build an international airport there in 2002."
<G-vec00084-002-s333><build.errichten><de> In einer an die Öffentlichkeit und die Presse gerichteten Stellungnahme spricht die Gruppe von gewaltsamen Aktionen gegen die Einwohner von San Salvador Atenco, die der Reihe systematischer Angriffe gegen die Bevölkerung hinzugefügt wurden - beginnend im Jahr 2002 mit dem Versuch der Bundesregierung einen internationalen Flughafen zu errichten.
<G-vec00084-002-s334><build.errichten><en> As today's standard for the transmission of electrical signals in a network, for example in a data center, compatible Blade Networks BN-QS-QS-CBL-1M Direct Attach Cables (DAC) provide a way to build high-availability connections in high-speed networks on short distances without having to compromise the arbitrary Blade Networks price policy of the large world conglomerates.
<G-vec00084-002-s334><build.errichten><de> Als heute üblicher Standard für die Übertragung elektrischer Signale, zum Beispiel in einem Rechenzentrum, stellen Blade Networks kompatible BN-QS-QS-CBL-1M Direct Attach Kabel (DAC) eine Möglichkeit dar, günstige hochverfügbarkeits-Verbindungen in Highspeed Netzwerken auf kurzen Distanzen zu errichten, ohne sich der willkürlichen Preispolitik der großen Weltkonzerne unterwerfen zu müssen.
<G-vec00084-002-s335><build.errichten><en> As today's standard for the transmission of electrical signals in a network, for example in a data center, compatible Dell 450-16140 Direct Attach Cables (DAC) provide a way to build high-availability connections in high-speed networks on short distances without having to compromise the arbitrary Dell price policy of the large world conglomerates.
<G-vec00084-002-s335><build.errichten><de> Als heute üblicher Standard für die Übertragung elektrischer Signale, zum Beispiel in einem Rechenzentrum, stellen Dell kompatible 450-16140 Direct Attach Kabel (DAC) eine Möglichkeit dar, günstige hochverfügbarkeits-Verbindungen in Highspeed Netzwerken auf kurzen Distanzen zu errichten, ohne sich der willkürlichen Preispolitik der großen Weltkonzerne unterwerfen zu müssen.
<G-vec00084-002-s336><build.errichten><en> Either you do not have enough resources to build the building or you cannot place it on that area of land.
<G-vec00084-002-s336><build.errichten><de> Entweder hast du nicht genug Ressourcen, um das Gebäude zu errichten, oder du kannst das Gebäude nicht auf diesem Terrain platzieren.
<G-vec00084-002-s337><build.errichten><en> Generous donations from the United States enabled Freie Universität to build some of its central facilities, including the Benjamin Franklin University Hospital and the Henry Ford Building.
<G-vec00084-002-s337><build.errichten><de> Großzügige Spenden aus den USA ermöglichten der Freien Universität, einige ihrer zentralen Gebäude zu errichten, unter ihnen das Universitätsklinikum Benjamin Franklin und der Henry-Ford-Bau.
<G-vec00084-002-s338><build.errichten><en> At the end of this course students will have all the knowledge and experience required to build powerful Access 2010 databases from scratch. Key learning points
<G-vec00084-002-s338><build.errichten><de> Am Ende des Kurses werden die Kursteilnehmer grundlegende Kenntnisse und eine breitgefächerte Erfahrung haben, die benötigt wird, um leistungsfähige Access 2010 Datenbanken von Grund auf zu errichten.
<G-vec00084-002-s339><build.errichten><en> This film is born from the want to understand what drives a woman or an elderly person to leave their homes to build barricades.
<G-vec00084-002-s339><build.errichten><de> Dieser Film versucht zu verstehen, was eine Dame oder einen Greisen dazu ermutigt, sein Haus zu verlassen, um Barrikaden zu errichten.
<G-vec00084-002-s340><build.errichten><en> In your guilds stronghold map you will come together to build many types of structures that will benefit your guild in PvE and PvP.
<G-vec00084-002-s340><build.errichten><de> Auf der Strongholds-Karte werdet ihr mit eurer Gilde gemeinsam viele verschiedene Strukturen errichten, die euch im PvE oder PvP Vorteile bieten.
<G-vec00084-002-s341><build.errichten><en> To protect your throne of ones and zeroes, you build a perimeter wall around yourself.
<G-vec00084-002-s341><build.errichten><de> Zum Schutz Ihres Volks aus Bits und Bytes errichten Sie eine Mauer um Ihr Gebiet.
<G-vec00084-002-s343><build.errichten><en> The strategic location was last exploited by the Japanese during World War II, who used POW labor to build the infamous Death Railway to ferry supplies across.
<G-vec00084-002-s343><build.errichten><de> Außerdem wurde hier im Zweiten Weltkrieg die sogenannte Todeseisenbahn von den Japanern errichtet.
<G-vec00084-002-s344><build.errichten><en> It is free to build and allows for smaller Combines to have as much fun, as the bigger ones have with Mining Complexes.
<G-vec00084-002-s344><build.errichten><de> Sie kann kostenlos errichtet werden und ermöglicht kleineren Ligen ebenso viel Spielspaß wie Lichttürme den großen Clans.
<G-vec00084-002-s345><build.errichten><en> If you rather want to build you own home in paradise we can show you various Bali Real Estate that has been build by the architects and contractors we represent.
<G-vec00084-002-s345><build.errichten><de> Falls Sie am liebsten alles selber planen und auch selber bauen wollen, bieten wir Ihnen die Möglichkeit, zur Anregung Häuser zu besichtigen, die von den Architekten und Bauunternehmern, die wir vertreten, errichtet wurden.
<G-vec00084-002-s346><build.errichten><en> You could build a house on it or a block of flats as the land is large enough.
<G-vec00084-002-s346><build.errichten><de> Durch das relativ große Grundstück kann ein Haus oder auch ein Apartmentblock errichtet werden.
<G-vec00084-002-s347><build.errichten><en> Make it something new and build it as strong as you can.
<G-vec00084-002-s347><build.errichten><de> Macht etwas Neues daraus und errichtet es so stark wie ihr könnt.
<G-vec00084-002-s349><build.errichten><en> In the third period the tower was build in two segments.
<G-vec00084-002-s349><build.errichten><de> Der Turm wurde seit 1463 bis 1484 errichtet, zuerst mit zwei Segmente(1).
<G-vec00084-002-s350><build.errichten><en> As a contemporary marketer, you understand the value of a brand story, the tribe you build around your brand with that story, the influence this has on a buyer, especially with a considered purchase (and one that is so public that can be a statement of you).
<G-vec00084-002-s350><build.errichten><de> Moderne Marketer verstehen den Wert einer Markenstory, den Stamm, den man mit einer solchen Story rund um die Marke errichtet, und die Wirkung, die das, insbesondere bei einem durchdachten Kauf, auf einen Käufer hat (und eine, die so öffentlich ist, wie eine Aussage von Ihnen nur sein kann).
<G-vec00084-002-s351><build.errichten><en> To better serve customers in China and Asia with their cutting edge technology, the two global companies aligned in a joint venture to build the largest silicone manufacturing site in China.
<G-vec00084-002-s351><build.errichten><de> Um ihre jeweiligen Kunden in China und in der Region Asien noch besser mit technologisch hochstehenden Lösungen bedienen zu können, haben die beiden Unternehmen gemeinsam den größten Produktionsstandort für Silicone in China errichtet.
<G-vec00084-002-s352><build.errichten><en> For example, if someone wants to build a new house, he needs to build a small one for the ghost first before he can even start to build his own. It’s because the Thai people believe that every property is haunted by a ghost.
<G-vec00084-002-s352><build.errichten><de> Wenn zum Beispiel irgendwo ein neues Haus gebaut wird, dann wird erst ein kleines Geisterhaus errichtet und der Geist, der auf dem Grundstück „wohnt“, von einem Mönch beschwichtigt in dieses für ihn errichtete Haus umzuziehen.
<G-vec00084-002-s354><build.errichten><en> A unique blend of peptide-loaded Matrixyl 3000, Wild Pansy extract and Pro-Biotic Complexes work to reduce the appearance of fine lines and build a protective skin barrier to repair and smooth uneven textures.
<G-vec00084-002-s354><build.errichten><de> Eine einzigartige Mischung aus peptidbeladenem Matrixyl 3000, wildes Stiefmütterchenextrakt und probiotischen Komplexen reduziert das Auftreten von feinen Linien und errichtet eine schützende Hautbarriere, um unebene Strukturen zu reparieren und auszuglätten.
<G-vec00084-002-s355><build.errichten><en> In 2012 we set out to build the first watch factory in Detroit and to create jobs by doing so.
<G-vec00084-002-s355><build.errichten><de> 2012 haben wir die erste Uhrenfabrik in Detroit errichtet, weil wir Arbeitsplätze schaffen wollten.
<G-vec00084-002-s356><build.errichten><en> The Alaska Blood bank was build with big effort and support from the Lions Clubs.
<G-vec00084-002-s356><build.errichten><de> Die Blutbank von Alaska wurde mit großer Unterstützung und Beteiligung der Lions errichtet.
<G-vec00084-002-s357><build.errichten><en> Build a net turret that immobilizes nearby foes.
<G-vec00084-002-s357><build.errichten><de> Errichtet einen Netzturm, der Gegner in der Nähe immobilisiert.
<G-vec00084-002-s358><build.errichten><en> It is not allowed to build new churches.
<G-vec00084-002-s358><build.errichten><de> Neue Kirchen dürfen nicht errichtet werden.
<G-vec00084-002-s359><build.errichten><en> Over the past several years of Earth time, we have given in-depth instructions about how to build Pyramids of Light/Power in the fifth dimension.
<G-vec00084-002-s359><build.errichten><de> Während der letzten paar Jahre der Erdenzeit haben wir Euch detaillierte Instruktionen darüber gegeben, wie man Pyramiden des Lichts/der Macht in der fünften Dimension errichtet.
<G-vec00084-002-s360><build.errichten><en> Hall 12, the former saddlery and needle case room build in 1899, is the most interesting hall of the SPINNEREI.
<G-vec00084-002-s360><build.errichten><de> Die Halle 12, ursprünglich als Nadelsetzerei und Sattlerei im Jahre 1899 errichtet, ist heute eine der spannendsten Ausstellungsflächen der SPINNEREI.
<G-vec00084-002-s361><build.erstellen><en> This type of services allows the Owner to build user profiles by starting from an email address, a personal name, or other information that the User provides to this Application, as well as to track User activities through analytics features.
<G-vec00084-002-s361><build.erstellen><de> Diese Art von Diensten erlauben es dem Eigentümer Nutzerprofile zu erstellen, indem sie zunächst die E-Mail-Adresse, den Namen oder sonstige Angaben verwenden, die der Nutzer an diese Anwendung übermittelt hat, als auch das Nachverfolgen von Nutzeraktivitäten durch Analysefunktionalitäten.
<G-vec00084-002-s362><build.erstellen><en> NetGuardians’ solution uses advanced analytics, dynamic profiling and machine learning to build highly accurate customer and employee profiles.
<G-vec00084-002-s362><build.erstellen><de> Die Lösung von NetGuardians kombiniert fortschrittliche Analysen, dynamisches Profiling und maschinelles Lernen, um hochpräzise Kunden- und Mitarbeiterprofile zu erstellen.
<G-vec00084-002-s363><build.erstellen><en> If you still want to sell extensions through your own websites or via other channels, you can build your own installer or provide instructions to your users on how to use the Extension Manager command line to install your extension.
<G-vec00084-002-s363><build.erstellen><de> Wenn Sie Ihre Erweiterungen über eigene Websites oder andere Vertriebskanäle verkaufen möchten, können Sie eigene Installationsprogramme erstellen oder Ihren Benutzern Anweisungen zur Installation der Erweiterung mithilfe der Extension Manager-Befehlszeile zur Verfügung stellen.
<G-vec00084-002-s364><build.erstellen><en> Our software suites ~sedna presenter and ~sedna touch offer a maximum of creative possibilities and a wealth of tools to build and transport fascinating, attractive and convincing brand messages with the highest quality level.
<G-vec00084-002-s364><build.erstellen><de> Unsere Softwarekollektionen ~sedna presenter und ~sedna touch ermöglichen ein Höchstmaß an kreativen Ideen und die notwendigen Mittel, um faszinierende, anziehende und überzeugende Markenbotschaften zu erstellen.
<G-vec00084-002-s365><build.erstellen><en> Build a family tree that can be accessed online and updated by other family members.
<G-vec00084-002-s365><build.erstellen><de> Erstellen Sie einen Familienstammbaum, der online abgerufen und von anderen Familienmitgliedern aktualisiert werden kann.
<G-vec00084-002-s366><build.erstellen><en> Build lists of up to 200,000 generated keyword lists.
<G-vec00084-002-s366><build.erstellen><de> Erstellen von Listen mit bis zu 200.000 generierten Keywords.
<G-vec00084-002-s367><build.erstellen><en> We use it in particular to develop algorithms for our search platforms and machine learning features, and we find SageMaker's hosted Jupyter Notebooks allows us to build and iterate rapidly.
<G-vec00084-002-s367><build.erstellen><de> Wir verwenden es insbesondere, um Algorithmen für unsere Suchplattformen und Funktionen für maschinelles Lernen zu entwickeln, und stellen fest, dass wir mit den von SageMaker gehosteten Jupyter-Notebooks schnell erstellen und iterieren können.
<G-vec00084-002-s368><build.erstellen><en> This means that we must always define the purpose before we can define and build the model, and that there will always be several models for different purposes.
<G-vec00084-002-s368><build.erstellen><de> Das bedeutet, dass wir immer den Zweck vordefinieren müssen, bevor wir das Modell beschreiben und erstellen können, und dass es immer mehrere Modelle für die unterschiedlichen Zwecke geben wird.
<G-vec00084-002-s369><build.erstellen><en> Making sure that MediaWiki, the platform we build our wikis on, is available in as many languages as possible is a central task for Wikimedia translators.
<G-vec00084-002-s369><build.erstellen><de> Die Gewährleistung, dass MediaWiki, die Plattform, mit der wir unsere Wikis erstellen, in so vielen Sprachen wie möglich verfügbar ist, ist eine zentrale Aufgabe für Wikimedia-Übersetzer.
<G-vec00084-002-s370><build.erstellen><en> Part of Arian Silver's forward-looking strategy lies in the envisaged use of large scale mechanized mining techniques over wider mineralized structures, which reduces the overall operating cost per ounce of silver, and to build up NI 43-101 compliant resources.
<G-vec00084-002-s370><build.erstellen><de> Ein Teil der vorausblickenden Strategie von Arian Silver ist die Verwendung von groß angelegten mechanisierten Bergbautechniken auf größeren mineralisierten Strukturen, um die insgesamten Betriebskosten pro Unze Silber zu reduzieren und um Ressourcen gemäß NI 43-101 zu erstellen.
<G-vec00084-002-s371><build.erstellen><en> You can access a pre-built report directly from the AWS IoT 1-Click console, the iOS or Android mobile app, or build a custom report using Amazon CloudWatch.
<G-vec00084-002-s371><build.erstellen><de> Sie können direkt über die AWS IoT 1-Click-Konsole oder die Mobil-App für iOS oder Android auf einen vordefinierten Bericht zugreifen oder mit Amazon CloudWatch einen individuellen Bericht erstellen.
<G-vec00084-002-s372><build.erstellen><en> Upload or record greetings, build menus and easily make changes to customise your customers' experiences. More Resources Phone support 101
<G-vec00084-002-s372><build.erstellen><de> Sie können Grüße hochladen oder aufzeichnen, Menüs erstellen und im Handumdrehen Änderungen vornehmen, um das Kundenerlebnis wie gewünscht anzupassen.
<G-vec00084-002-s373><build.erstellen><en> We can help you build a robust business case to support your investment decision.
<G-vec00084-002-s373><build.erstellen><de> Wir können Ihnen helfen, einen robusten Business Case zu erstellen, der Ihre Investitionsentscheidung unterstützt.
<G-vec00084-002-s374><build.erstellen><en> This 27-minute video will walk you through step-by-step how to build your first app with Windows App Studio Beta.
<G-vec00084-002-s374><build.erstellen><de> In diesem 27-minütigen Video wird Schritt für Schritt beschrieben, wie Sie mit Windows App Studio Beta Ihre erste App erstellen.
<G-vec00084-002-s375><build.erstellen><en> This is accomplished by the application taking user input and combining it with static parameters to build a SQL query.
<G-vec00084-002-s375><build.erstellen><de> Dies wird durch die Applikation erreicht, welche den Input des Benutzers mit statischen Parametern kombiniert, um eine SQL Abfrage zu erstellen.
<G-vec00084-002-s376><build.erstellen><en> Multiple reference frames can be related to each other to build the dependency that exists in a real application.
<G-vec00084-002-s376><build.erstellen><de> Mehrere Bezugssysteme können miteinander verknüpft werden, um die Abhängigkeit zu erstellen, die der Realität entspricht.
<G-vec00084-002-s377><build.erstellen><en> Work across teams to build, test and manage different versions of your models in production with Azure Databricks and Azure Machine Learning.
<G-vec00084-002-s377><build.erstellen><de> Arbeiten Sie mit Azure Databricks und Azure Machine Learning im Team zusammen, um verschiedene Versionen Ihrer Modelle in der Produktion zu erstellen, zu testen und zu verwalten.
<G-vec00084-002-s378><build.erstellen><en> Hire C++ developers on hourly or full time (dedicated monthly) basis to build feature-rich, interactive and secure C++ applications.
<G-vec00084-002-s378><build.erstellen><de> ENTWICKLER EINSTELLEN Stellen Sie C++-Entwickler stündlich oder ganztägig (monatlich) ein, um funktionsreiche, interaktive und sichere C++-Anwendungen zu erstellen.
<G-vec00084-002-s379><build.erstellen><en> Help your child build a word family.
<G-vec00084-002-s379><build.erstellen><de> Hilf deinem Kind dabei, eine Wortfamilie zu erstellen.
<G-vec00084-002-s380><build.erstellen><en> The virtual machines with appropriate resource allocation, software installation, and system configurations are used to build lightweight security laboratories on a hosting computer.
<G-vec00084-002-s380><build.erstellen><de> Unter Beachtung angemessener Ressourcennutzung, Softwareinstallationen und Systemkonfigurationen wurden virtuelle Maschinen als Übungsstationen erstellt, die auf einem einzelnen Rechner betrieben werden.
<G-vec00084-002-s381><build.erstellen><en> Technical Trader uses palettes and buttons to build a custom user interface.
<G-vec00084-002-s381><build.erstellen><de> Technical Trader erstellt eine spezielle Anwenderschnittstelle mit Paletten und Knöpfen.
<G-vec00084-002-s382><build.erstellen><en> This data will be used to build the statistical models that underpin the Predict product recommendations.
<G-vec00084-002-s382><build.erstellen><de> Auf Basis dieser Daten werden die statistischen Modelle erstellt, die den Predict Produktempfehlungen zugrunde liegen.
<G-vec00084-002-s383><build.erstellen><en> Having performed this example in countless workshops (which is a bit different than reading on a webpage), I have found that some of the comments about the business idea for more technical people are about how to build it, whereas for marketers, the focus is on how to market the product.
<G-vec00084-002-s383><build.erstellen><de> Nachdem ich dieses Beispiel in unzähligen Workshops durchgeführt habe (was ein bisschen anders ist als das Lesen auf einer Webseite), habe ich festgestellt, dass einige der Kommentare über die Geschäftsidee für technisch versiertere Leute sind, wie man sie erstellt, während für Vermarkter der Fokus ist wie man das Produkt vermarktet.
<G-vec00084-002-s384><build.erstellen><en> Based on the wishes, we select a suitable platform to build the online store with.
<G-vec00084-002-s384><build.erstellen><de> Basierend auf den Wünschen wählen wir eine geeignete Plattform aus, mit der der Internetshop erstellt werden kann.
<G-vec00084-002-s385><build.erstellen><en> I was experimenting processing and build this little stupid game to see how far we can go with it.
<G-vec00084-002-s385><build.erstellen><de> Ich hab mit Processing experimentiert und dieses kleine blöde Spiel erstellt, um zu sehen, wie weit wir damit kommen.
<G-vec00084-002-s386><build.erstellen><en> 3D printing The design process of 3D printing: firstly use software to build a model, and then split the 3D model to a layer-by-layer cross-section, ie, slicing, so as to guide the printer to print layer by layer.
<G-vec00084-002-s386><build.erstellen><de> 3D-Druck Der Entwurfsprozess des 3D-Drucks: Zuerst wird ein Modell mithilfe von Software erstellt und anschließend das 3D-Modell in einen schichtweisen Querschnitt (Slicing) aufgeteilt, um den Drucker Schicht für Schicht zu drucken.
<G-vec00084-002-s387><build.erstellen><en> But Outlook prefers that you build distribution lists from your Contacts, so you first must add the sender to an address book in Contacts.
<G-vec00084-002-s387><build.erstellen><de> In Outlook werden Verteilerlisten jedoch aus Ihren Kontakten erstellt, daher müssen Sie also den Absender zuerst zu einem Adressbuch in den Kontakten hinzufügen.
<G-vec00084-002-s388><build.erstellen><en> How to build Spark applications architecture to facilitate code reuse, quality and performance.
<G-vec00084-002-s388><build.erstellen><de> Wie man eine Architektur von Spark-Anwendungen erstellt, um die Wiederverwendung von Code, Qualität und Leistung zu unterstützen.
<G-vec00084-002-s389><build.erstellen><en> Before this plugin worked by converting CSV files into HTML Tables, but now you can start from scratch and build your table in the backend.
<G-vec00084-002-s389><build.erstellen><de> Zu Anfang konnte das Plugin nur CSV Dateien konvertieren, nun können Tabellen von Grund auf in einem Tabellen-Editor gestaltet und erstellt werden.
<G-vec00084-002-s390><build.erstellen><en> In each Class you will have to select up to 7 Units that will be used to build your 2 teams.
<G-vec00084-002-s390><build.erstellen><de> In jeder Klasse könnt ihr bis zu 7 Einheiten auswählen, aus denen ihr dann eure 2 Teams erstellt.
<G-vec00084-002-s391><build.erstellen><en> After you build the Desktop Web Viewer app, click "URL" to display your content in your current browser.
<G-vec00084-002-s391><build.erstellen><de> Nachdem Sie die App für den Web Viewer für den Desktop erstellt haben, klicken Sie auf „URL“, um den Inhalt in Ihrem aktuellen Browser anzuzeigen.
<G-vec00084-002-s392><build.erstellen><en> They know how to build networks with reduced vulnerability, but depend on applications like web servers and web browsers to keep things safe.
<G-vec00084-002-s392><build.erstellen><de> Sie wissen, wie man Netzwerke mit geringerer Anfälligkeit erstellt, aber diese hängen von Anwendungen wie Webservern und Webbrowsern ab, um die Sicherheit zu gewährleisten.
<G-vec00084-002-s393><build.erstellen><en> − Using the external toolchain is an easy way to build applications for your Neo.
<G-vec00084-002-s393><build.erstellen><de> Die Benutzung der externen Toolchain stellt einen einfachen Weg dar, mit den Applikationen für das Neo erstellt werden können.
<G-vec00084-002-s394><build.erstellen><en> The Media Manager will build a list of all the files used in your composition, and mark the missing ones in red for you.
<G-vec00084-002-s394><build.erstellen><de> Der Medienmanager erstellt eine Liste aller in Ihrer Komposition verwendeten Dateien und markiert die fehlenden in Rot.
<G-vec00084-002-s395><build.erstellen><en> Power BI Embedded provides stunning, fully interactive data visualisations in your customer-facing apps without the time and expense of having to build it from the ground up.
<G-vec00084-002-s395><build.erstellen><de> Power BI Embedded bietet beeindruckende, hochgradig interaktive Datenvisualisierungen in Ihren Apps für Kunden – und das ohne den Zeit- und Kostenaufwand, der erforderlich wäre, wenn diese von Grund auf erstellt werden müssten.
<G-vec00084-002-s396><build.erstellen><en> Instead, the team developed a method to build two meters of belt at a time and then assemble them together at the end.
<G-vec00084-002-s396><build.erstellen><de> Stattdessen entwickelte das Team eine Methode, bei der jeweils zwei Meter des Bands erstellt und die Teile am Ende zusammengesetzt wurden.
<G-vec00084-002-s397><build.erstellen><en> This website is build with Hugo, the source code is hosted on GitHub.
<G-vec00084-002-s397><build.erstellen><de> Diese Website wird mit Hugo erstellt, der Quellcode ist öffentlich auf GitHub verfügbar.
<G-vec00084-002-s398><build.erstellen><en> It ingests all of a company’s first-party data and uses that to build complete pictures of all of your customers (also known as a single customer view).
<G-vec00084-002-s398><build.erstellen><de> Sie erfasst alle Erstanbieter-Daten eines Unternehmens und erstellt daraus vollständige Kundenprofile (auch Single Customer View genannt).
<G-vec00084-002-s475><build.schaffen><en> From developing the dreams of students and makers to helping professional engineers develop their ideas and products, we build a community that benefits from our technology.
<G-vec00084-002-s475><build.schaffen><de> Egal, ob es darum geht, Träume von Studenten und Makern weiterzuentwickeln oder professionellen Entwicklern bei der Umsetzung ihrer Ideen und Produkte zu helfen – wir schaffen eine Community, die von unseren Technologien profitiert.
<G-vec00084-002-s476><build.schaffen><en> We are new to eBay and our goal is to build a reputation from honesty and transparency.
<G-vec00084-002-s476><build.schaffen><de> Wir sind neu zu eBay und unser Ziel ist es, einen Ruf von Ehrlichkeit und Transparenz zu schaffen.
<G-vec00084-002-s477><build.schaffen><en> Albeit in the case of the Vietnam war, the painful daily images of the dead American youths that were brought home highly contributed to build an awareness about how useless, unfair and absurd that war was, the situation with the child was different.
<G-vec00084-002-s477><build.schaffen><de> Wenn auch beim Vietnams Krieg die schmerzhaften Bilder junger leblos zurückkehrender Nordamerikaner, die es täglich beobachten musste, dazu beitrugen, ein Bewußtsein über das Sterile, Ungerechte und Absurde jenes Krieges zu schaffen, geschah im Falle des Jungen nichts Ähnliches.
<G-vec00084-002-s478><build.schaffen><en> Fastems mission is to build a world where the manufacturing industry is a cornerstone of success and a source of sustainable well-being in the society.
<G-vec00084-002-s478><build.schaffen><de> Die Mission von Fastems besteht darin, eine Welt zu schaffen, in der die Fertigungsindustrie ein Eckpfeiler des Erfolgs und eine Quelle nachhaltigen Wohlbefindens in der Gesellschaft ist.
<G-vec00084-002-s479><build.schaffen><en> With our network of partners we build connections across Europe.
<G-vec00084-002-s479><build.schaffen><de> Mit unserem Partnernetzwerk schaffen wir Verbindungen in ganz Europa.
<G-vec00084-002-s480><build.schaffen><en> Here, we started to build a new home, while we wait for the time of our revenge.
<G-vec00084-002-s480><build.schaffen><de> Hier fingen wir an, ein neues Heim zu schaffen, während wir auf den Tag unserer Rache warten.
<G-vec00084-002-s481><build.schaffen><en> May Israelis and Palestinians have the courage and determination to write a new page of history, where hate and revenge give way to the will to build together a future of mutual understanding and harmony.
<G-vec00084-002-s481><build.schaffen><de> Israelis und Palästinenser mögen den Mut und die Entschlossenheit haben, eine neue Seite der Geschichte zu schreiben, in der Hass und Vergeltung den Platz räumen gegenüber dem Willen, gemeinsam eine Zukunft gegenseitigen Verständnisses und Einklanges zu schaffen.
<G-vec00084-002-s482><build.schaffen><en> Contentserv has been recently recognized as a Contender by Forrester in its latest independent MRM evaluation and highlighted in Forrester”s latest PIM Now Tech report as providing end-to-end functionality for organizations looking to build a foundation for today and beyond.
<G-vec00084-002-s482><build.schaffen><de> Contentserv wurde kürzlich von Forrester in seiner jüngsten unabhängigen MRM-Bewertung als Contender anerkannt und im jüngsten PIM Now Tech-Bericht von Forrester als Anbieter von End-to-End-Funktionalität für Organisationen hervorgehoben, die eine digitale Basis für heute und darüber hinaus schaffen wollen.
<G-vec00084-002-s483><build.schaffen><en> Instead, they aim for a kaleidoscopic and resourceful approach that emerges from the glaring necessity to build a knowledge-base simultaneously broad in its disciplinary perspectives as well as out-of-the-box and that helps to readjust the human position within a broader geo-fabric.
<G-vec00084-002-s483><build.schaffen><de> Stattdessen streben sie nach einem kaleidoskopischen Ansatz, der sich aus der dringenden Notwendigkeit ergibt, eine Wissensbasis zu schaffen, die in ihren einzelwissenschaftlichen Sichtweisen breit aufgestellt und frei von Schubladendenken ist.
<G-vec00084-002-s484><build.schaffen><en> In order to to be able to fundamentally understand the consequences of a collision between an aircraft and a drone, the Fraunhofer Institute for High-Speed Dynamics, Ernst-Mach-Institut, EMI is now planning to build a test bench for recreating various collision scenarios with complete drones.
<G-vec00084-002-s484><build.schaffen><de> Um entsprechende Grundlagen zu schaffen, plant das Fraunhofer-Institut für Kurzzeitdynamik, Ernst-Mach-Institut, EMI derzeit die Errichtung eines Teststands, auf dem Kollisionsszenarien mit kompletten Drohnen nachgestellt werden können.
<G-vec00084-002-s485><build.schaffen><en> Build your services revenue Form the foundation for years of profitable services revenue by leveraging the migration and device renewal opportunity.
<G-vec00084-002-s485><build.schaffen><de> Schaffen Sie die Grundlage für viele Jahre profitabler Dienstleistungsumsätze, indem Sie Chancen bei der Migration und Reprofilierung von Geräten nutzen.
<G-vec00084-002-s486><build.schaffen><en> Our core values are trust, which helps us build solutions together, passion, which inspires dedication, teamwork with our customers and our partners, disruption to innovate and think outside the box, and responsibility, since we always hold responsibility for our actions.
<G-vec00084-002-s486><build.schaffen><de> Unsere Kernwerte sind das Vertrauen, das es uns ermöglicht, gemeinsam Großes zu schaffen, die Leidenschaft, die uns dazu treibt, stets unser Bestes zu geben, der Teamgeist zur erfolgreichen Zusammenarbeit mit Kunden und OVH Partnern, die Disruption, um durch eine andere Denkweise Innovationen hervorzubringen, und unsere Verantwortung, denn wir wissen, dass unser Handeln auch verpflichtet.
<G-vec00084-002-s487><build.schaffen><en> Our goal: to build a foundation of trust between management and employees, partners and customers alike.
<G-vec00084-002-s487><build.schaffen><de> Das Ziel: zwischen Geschäftsleitung und Mitarbeitern, Partnern und Kunden ein Fundament des Vertrauens zu schaffen.
<G-vec00084-002-s488><build.schaffen><en> The Nexus 9 is an impressive tablet but not with the build quality you expect out of HTC.
<G-vec00084-002-s488><build.schaffen><de> Mit dem Nexus 9 hätte Google einen großen Wurf am Tablet-Markt schaffen können.
<G-vec00084-002-s489><build.schaffen><en> AI seeks, fundamentally, to build a constructive union between a whole people and the massive entirety of what people talk about as past and present capacities: achievements, assets, unexplored potentials, innovations, strengths, elevated thoughts, opportunities, benchmarks, high point moments, lived values, traditions, strategic competencies, stories, expressions of wisdom, insights into the deeper corporate spirit or soul - and visions of valued and possible futures.
<G-vec00084-002-s489><build.schaffen><de> AI versucht grundlegend einen konstruktiven Zusammenschluss zwischen ganzen Leuten und der massiven Ganzheit zu schaffen, worüber Leute als vergangene und gegenwärtige Kapazitäten sprechen: Erfolge, Aktiva, nicht erforschte Potentiale, Innovationen, Stärken, höhere Gedanken, Gelegenheiten Benchmarks, Höhepunkte, gelebte Werte, Traditionen, strategische Kompetenzen, Geschichten, Ausdrücke von Klugheit, Einblicke in den tieferen unternehmerischen Geist oder in die Seele - und Vorstellungen der geschätzten und möglichen Zukunft.
<G-vec00084-002-s490><build.schaffen><en> ProveSource is a social proof marketing platform that streams recent customer behaviors on your website to build trust and increase conversions.
<G-vec00084-002-s490><build.schaffen><de> ProveSource ist eine Social-Proof-Marketingplattform, die das aktuelle Kundenverhalten auf deiner Website streamt, um Vertrauen zu schaffen und die Zahl der Conversions zu steigern.
<G-vec00084-002-s491><build.schaffen><en> Planon wants to build its future on sustainable profit, based on sound business ethics and respect for its stakeholders, and wants to be a good corporate citizen.
<G-vec00084-002-s491><build.schaffen><de> Planon möchte ein guter Corporate Citizen sein und ist bestrebt, seine Profitabilität auf nachhaltige Weise und auf der Grundlage einer guten Geschäftsethik sowie Respekt gegenüber seinen Stakeholdern zu schaffen.
<G-vec00084-002-s492><build.schaffen><en> We build the requirements to realise your ideas.
<G-vec00084-002-s492><build.schaffen><de> Wir schaffen die Voraussetzungen für die Realisierung Ihrer Vorstellungen.
<G-vec00084-002-s493><build.schaffen><en> All this potential, taken together, can make the difference to a business that places at its centre: the person, the quality of its relationships, the truth of its commitment to build a more just world, a world that is truly everyone’s.
<G-vec00084-002-s493><build.schaffen><de> Gemeinsam können all diese Kräfte etwas bewirken in einem Unternehmen, das den Menschen in den Mittelpunkt stellt, die Qualität seiner Beziehungen, die Wahrhaftigkeit seines Einsatzes, eine gerechtere Welt zu schaffen, eine Welt, die wirklich für alle da ist.
