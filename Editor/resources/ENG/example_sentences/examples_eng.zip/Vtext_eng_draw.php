<G-vec00169-001-s038><draw.ausdrucken><en> Printable nš 7 Arthur activities for kids learn to draw pictures 7
<G-vec00169-001-s038><draw.ausdrucken><de> Bild no 7 Arthur Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s039><draw.ausdrucken><en> Printable nš 7 Doremi activities for kids learn to draw pictures 7
<G-vec00169-001-s039><draw.ausdrucken><de> Bild no 7 Doremi Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s040><draw.ausdrucken><en> Corpse Bride activities for kids learn to draw pictures 7
<G-vec00169-001-s040><draw.ausdrucken><de> Corpse Bride Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s041><draw.ausdrucken><en> Printable nš 7 Umizoomi activities for kids learn to draw pictures 7
<G-vec00169-001-s041><draw.ausdrucken><de> Bild no 7 Umizoomi Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s042><draw.ausdrucken><en> Woody Woodpecker activities for kids learn to draw pictures 7
<G-vec00169-001-s042><draw.ausdrucken><de> Woody Woodpecker Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s043><draw.ausdrucken><en> Printable nš 7 Lunnis activities for kids learn to draw pictures 7
<G-vec00169-001-s043><draw.ausdrucken><de> Bild no 7 Lunnis Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s044><draw.ausdrucken><en> Printable nš 7 Dumbo activities for kids learn to draw pictures 7
<G-vec00169-001-s044><draw.ausdrucken><de> Bild no 7 Dumbo Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s045><draw.ausdrucken><en> Printable nš 7 Mulan activities for kids learn to draw pictures 7
<G-vec00169-001-s045><draw.ausdrucken><de> Bild no 7 Mulan Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s046><draw.ausdrucken><en> Printable nš 7 Ant-Man activities for kids learn to draw pictures 7
<G-vec00169-001-s046><draw.ausdrucken><de> Bild no 7 Ant-Man Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s047><draw.ausdrucken><en> Printable nš 7 Wallykazam activities for kids learn to draw pictures 7
<G-vec00169-001-s047><draw.ausdrucken><de> Bild no 7 Wallykazam Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s048><draw.ausdrucken><en> Printable nš 7 Frozen activities for kids learn to draw pictures 7
<G-vec00169-001-s048><draw.ausdrucken><de> Bild no 7 Frozen Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s049><draw.ausdrucken><en> Nature Cat activities for kids learn to draw pictures 7
<G-vec00169-001-s049><draw.ausdrucken><de> Nature Cat Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s050><draw.ausdrucken><en> Printable nš 7 Sonic activities for kids learn to draw pictures 7
<G-vec00169-001-s050><draw.ausdrucken><de> Bild no 7 Sonic Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s051><draw.ausdrucken><en> Printable nš 7 Fifi and the Flowertots activities for kids learn to draw pictures 7
<G-vec00169-001-s051><draw.ausdrucken><de> Bild no 7 Fifi und die Blumenkinder Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s052><draw.ausdrucken><en> Onegai My Melody activities for kids learn to draw pictures 7
<G-vec00169-001-s052><draw.ausdrucken><de> Onegai My Melody Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s053><draw.ausdrucken><en> Printable nš 7 Shopkins activities for kids learn to draw pictures 7
<G-vec00169-001-s053><draw.ausdrucken><de> Bild no 7 Shopkins Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s054><draw.ausdrucken><en> Bat Pat activities for kids learn to draw pictures 3
<G-vec00169-001-s054><draw.ausdrucken><de> Bat Pat Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s055><draw.ausdrucken><en> Miss Spider activities for kids learn to draw pictures 7
<G-vec00169-001-s055><draw.ausdrucken><de> Miss Spider Aktivitäten für Kinder zum ausdrucken.
<G-vec00169-001-s056><draw.ausdrucken><en> Printable nš 7 Tarzan activities for kids learn to draw pictures 7
<G-vec00169-001-s056><draw.ausdrucken><de> Bild no 7 Tarzan Aktivitäten für Kinder zum ausdrucken.
<G-vec00042-001-s076><draw.beziehen><en> Moreover, members of the Group Management have an option to draw a further 20% of the performance bonus in the form of shares of Sika AG.
<G-vec00042-001-s076><draw.beziehen><de> Ferner hat die Konzernleitung die Möglichkeit, weitere 20% des Leistungsbonus in Aktien der Sika AG zu beziehen.
<G-vec00042-001-s077><draw.beziehen><en> Both draw upon the most arcane aspects of all spiritual disciplines.
<G-vec00042-001-s077><draw.beziehen><de> Beide beziehen sich auf die geheimnisvollsten Aspekte aller spirituellen Disziplinen.
<G-vec00042-001-s078><draw.beziehen><en> Draw out feedback on your products, proposition and people.
<G-vec00042-001-s078><draw.beziehen><de> Beziehen Sie Feedback zu Ihren Produkten, Angeboten und Mitarbeitern.
<G-vec00042-001-s079><draw.beziehen><en> In the way of thinking, speaking, and judging events of the world, of serving and loving, of relating to people, also in his habits, the priest must draw prophetic power from his sacramental belonging, from his profound being.
<G-vec00042-001-s079><draw.beziehen><de> In seiner Art zu denken, zu sprechen, die Gegebenheiten der Welt zu beurteilen, zu dienen und zu lieben, mit den Menschen auch im Priestergewand in Beziehung zu treten, soll der Priester aus seiner sakramentalen Zugehörigkeit, aus seinem tiefsten Wesen prophetische Kraft beziehen.
<G-vec00042-001-s080><draw.beziehen><en> Today, with gratefulness for these fruits, I would like to finally draw attention to some of the premises concerning the present and the future of our two nations.
<G-vec00042-001-s080><draw.beziehen><de> Wenn ich heute für diese Früchte danke, so möchte ich schließlich auch den Aspekten desHirtenbriefes Aufmerksamkeit schenken, die sich auf die Gegenwart und Zukunft unserer beiden Nationen beziehen.
<G-vec00042-001-s081><draw.beziehen><en> "These ""pro-active"" operations draw heavily from the military handbook, using dawn raids, and relying on intelligence gathering procedures that are exempt from public scrutiny as they are kept secret in ensuing court processes."
<G-vec00042-001-s081><draw.beziehen><de> "Diese ""proaktiven"" Einsätze beziehen sehr viel aus dem Militärhandbuch, wenden Nachtrazzien an und verlassen sich auf Informationssammelprozeduren, die dem prüfenden Blick der Öffentlichkeit entgehen, da sie in den darauf folgenden Prozessen geheim gehalten werden."
<G-vec00042-001-s082><draw.beziehen><en> Socrates never wrote anything and historians of philosophy draw information about his views from secondary sources, the “Socratic” works of Plato and Xenophon.
<G-vec00042-001-s082><draw.beziehen><de> "Sokrates hat nie etwas geschrieben und Historiker der Philosophie beziehen Informationen über seine Ansichten aus sekundären Quellen, den ""sokratischen"" Werken von Plato und Xenophon."
<G-vec00042-001-s083><draw.beziehen><en> My epilogue is therefore directed straight at the reader and challenges him to walk through the world with his eyes open and to draw his inspiration from the environment.
<G-vec00042-001-s083><draw.beziehen><de> Mein Epilog richtet sich dadurch direkt an den Leser und fordert ihn auf, ebenfalls mit offenen Augen durch die Welt zu gehen und sich seine Inspiration aus der Umgebung zu beziehen.
<G-vec00042-001-s084><draw.beziehen><en> At the point in the astronomical year when the light returns to triumph over the darkness all of our sacred rituals draw upon the power of that light to inspire us to begin anew.
<G-vec00042-001-s084><draw.beziehen><de> An dem Punkt im astronomischen Jahr, an dem das Licht zurückkehrt um über die Dunkelheit zu triumphieren, beziehen sich alle unsere heiligen Rituale auf die Macht des Lichts, um uns für einen Neubeginn zu inspirieren.
<G-vec00042-001-s085><draw.beziehen><en> The members of the Diet shall not be allowed draw any salary, or be compensated as such.
<G-vec00042-001-s085><draw.beziehen><de> Die Mitglieder des Reichstages dürfen als solche keine Besoldung oder Entschädigung beziehen.
<G-vec00042-001-s086><draw.beziehen><en> At the workshop the speakers will draw on their own practical experiences while acting as facilitators for FC users who were able, through FC, to increase their independence and self-sufficiency (both in communication and in everyday life).
<G-vec00042-001-s086><draw.beziehen><de> Die Referenten beziehen sich im Workshop auf ihre praktischen Erfahrungen in der Begleitung von FC-Nutzern, die durch FC ihre Selbständigkeit und Unabhängigkeit (in der Kommunikation und im Alltag) erweitern konnten.
<G-vec00042-001-s087><draw.beziehen><en> On the other hand, some people also draw long-term basic income support benefits who are not without work but who are not at the disposal of the labour market because of childcare or further training activities or who are in employment but do not gain enough income to support the whole household.
<G-vec00042-001-s087><draw.beziehen><de> Andererseits beziehen auch Personen längerfristig Grundsicherungsleistungen, die nicht arbeitslos sind, aber wegen Erziehungs- und Weiterbildungsaktivitäten dem Arbeitsmarkt nicht zur Verfügung stehen oder erwerbstätig sind, aber kein ausreichendes Einkommen zur Versorgung des kompletten Haushalts erzielen.
<G-vec00042-001-s088><draw.beziehen><en> Important! For safety reasons, a current consumer may still not draw electrical current at the same time from two different power sources.
<G-vec00042-001-s088><draw.beziehen><de> Wichtig!Ein Stromverbraucher darf auch weiterhin aus Sicherheitsgründen nicht gleichzeitig aus zwei verschiedenen Versorgungsquellen den elektrischen Strom beziehen.
<G-vec00042-001-s089><draw.beziehen><en> If you keep your residence in Switzerland and continue to draw a salary from a Swiss employer, you do not need to make any arrangements in terms of retirement provision.
<G-vec00042-001-s089><draw.beziehen><de> Wenn Sie Ihren Wohnsitz in der Schweiz behalten und weiterhin Lohn von Ihrem Schweizer Arbeitgeber beziehen, brauchen Sie in puncto Vorsorge keine Vorkehrungen zu treffen.
<G-vec00042-001-s090><draw.beziehen><en> I think it’s difficult to draw parallels to the present day, I see more in common with the Nouvelle Vague.
<G-vec00042-001-s090><draw.beziehen><de> Schwierig, ich glaube, man kann es schwer auf heute beziehen, ich sehe da eher Parallelen zur Nouvelle Vague.
<G-vec00042-001-s091><draw.beziehen><en> This system does not prioritize which AC consumers can draw energy from the battery bank.
<G-vec00042-001-s091><draw.beziehen><de> Dieses System priorisiert nicht, welche AC-Verbraucher Energie aus der Batteriebank beziehen können.
<G-vec00042-001-s092><draw.beziehen><en> We draw our strengths from the constructive and respectful cooperation of associates, advisors, management and all employees.
<G-vec00042-001-s092><draw.beziehen><de> Wir beziehen unsere Stärke aus der konstruktiven, respektvollen Zusammenarbeit von Gesellschaftern, Beirat, Geschäftsleitung und allen Mitarbeiterinnen und Mitarbeitern.
<G-vec00042-001-s093><draw.beziehen><en> Computer animation and atmospherically compelling reenactments serve both to illustrate the action and to draw the viewer emotionally into the action at the same time.
<G-vec00042-001-s093><draw.beziehen><de> Computeranimationen und atmosphärisch dichte Reenactments dienen der Veranschaulichung und beziehen den Zuschauer gleichzeitig emotional in das Geschehen ein.
<G-vec00042-001-s094><draw.beziehen><en> The members of the State Council – faithful servants of two or three emperors continued to sit, or at least to draw their salaries.
<G-vec00042-001-s094><draw.beziehen><de> Die Mitglieder des Staatsrates, treue Diener zweier oder dreier Kaiser, fuhren fort zu tagen, zumindest ihr Gehalt zu beziehen.
<G-vec00169-001-s076><draw.beziehen><en> Moreover, members of the Group Management have an option to draw a further 20% of the performance bonus in the form of shares of Sika AG.
<G-vec00169-001-s076><draw.beziehen><de> Ferner hat die Konzernleitung die Möglichkeit, weitere 20% des Leistungsbonus in Aktien der Sika AG zu beziehen.
<G-vec00169-001-s077><draw.beziehen><en> Both draw upon the most arcane aspects of all spiritual disciplines.
<G-vec00169-001-s077><draw.beziehen><de> Beide beziehen sich auf die geheimnisvollsten Aspekte aller spirituellen Disziplinen.
<G-vec00169-001-s078><draw.beziehen><en> Draw out feedback on your products, proposition and people.
<G-vec00169-001-s078><draw.beziehen><de> Beziehen Sie Feedback zu Ihren Produkten, Angeboten und Mitarbeitern.
<G-vec00169-001-s079><draw.beziehen><en> In the way of thinking, speaking, and judging events of the world, of serving and loving, of relating to people, also in his habits, the priest must draw prophetic power from his sacramental belonging, from his profound being.
<G-vec00169-001-s079><draw.beziehen><de> In seiner Art zu denken, zu sprechen, die Gegebenheiten der Welt zu beurteilen, zu dienen und zu lieben, mit den Menschen auch im Priestergewand in Beziehung zu treten, soll der Priester aus seiner sakramentalen Zugehörigkeit, aus seinem tiefsten Wesen prophetische Kraft beziehen.
<G-vec00169-001-s080><draw.beziehen><en> Today, with gratefulness for these fruits, I would like to finally draw attention to some of the premises concerning the present and the future of our two nations.
<G-vec00169-001-s080><draw.beziehen><de> Wenn ich heute für diese Früchte danke, so möchte ich schließlich auch den Aspekten desHirtenbriefes Aufmerksamkeit schenken, die sich auf die Gegenwart und Zukunft unserer beiden Nationen beziehen.
<G-vec00169-001-s081><draw.beziehen><en> "These ""pro-active"" operations draw heavily from the military handbook, using dawn raids, and relying on intelligence gathering procedures that are exempt from public scrutiny as they are kept secret in ensuing court processes."
<G-vec00169-001-s081><draw.beziehen><de> "Diese ""proaktiven"" Einsätze beziehen sehr viel aus dem Militärhandbuch, wenden Nachtrazzien an und verlassen sich auf Informationssammelprozeduren, die dem prüfenden Blick der Öffentlichkeit entgehen, da sie in den darauf folgenden Prozessen geheim gehalten werden."
<G-vec00169-001-s082><draw.beziehen><en> Socrates never wrote anything and historians of philosophy draw information about his views from secondary sources, the “Socratic” works of Plato and Xenophon.
<G-vec00169-001-s082><draw.beziehen><de> "Sokrates hat nie etwas geschrieben und Historiker der Philosophie beziehen Informationen über seine Ansichten aus sekundären Quellen, den ""sokratischen"" Werken von Plato und Xenophon."
<G-vec00169-001-s083><draw.beziehen><en> My epilogue is therefore directed straight at the reader and challenges him to walk through the world with his eyes open and to draw his inspiration from the environment.
<G-vec00169-001-s083><draw.beziehen><de> Mein Epilog richtet sich dadurch direkt an den Leser und fordert ihn auf, ebenfalls mit offenen Augen durch die Welt zu gehen und sich seine Inspiration aus der Umgebung zu beziehen.
<G-vec00169-001-s084><draw.beziehen><en> At the point in the astronomical year when the light returns to triumph over the darkness all of our sacred rituals draw upon the power of that light to inspire us to begin anew.
<G-vec00169-001-s084><draw.beziehen><de> An dem Punkt im astronomischen Jahr, an dem das Licht zurückkehrt um über die Dunkelheit zu triumphieren, beziehen sich alle unsere heiligen Rituale auf die Macht des Lichts, um uns für einen Neubeginn zu inspirieren.
<G-vec00169-001-s085><draw.beziehen><en> The members of the Diet shall not be allowed draw any salary, or be compensated as such.
<G-vec00169-001-s085><draw.beziehen><de> Die Mitglieder des Reichstages dürfen als solche keine Besoldung oder Entschädigung beziehen.
<G-vec00169-001-s086><draw.beziehen><en> At the workshop the speakers will draw on their own practical experiences while acting as facilitators for FC users who were able, through FC, to increase their independence and self-sufficiency (both in communication and in everyday life).
<G-vec00169-001-s086><draw.beziehen><de> Die Referenten beziehen sich im Workshop auf ihre praktischen Erfahrungen in der Begleitung von FC-Nutzern, die durch FC ihre Selbständigkeit und Unabhängigkeit (in der Kommunikation und im Alltag) erweitern konnten.
<G-vec00169-001-s087><draw.beziehen><en> On the other hand, some people also draw long-term basic income support benefits who are not without work but who are not at the disposal of the labour market because of childcare or further training activities or who are in employment but do not gain enough income to support the whole household.
<G-vec00169-001-s087><draw.beziehen><de> Andererseits beziehen auch Personen längerfristig Grundsicherungsleistungen, die nicht arbeitslos sind, aber wegen Erziehungs- und Weiterbildungsaktivitäten dem Arbeitsmarkt nicht zur Verfügung stehen oder erwerbstätig sind, aber kein ausreichendes Einkommen zur Versorgung des kompletten Haushalts erzielen.
<G-vec00169-001-s088><draw.beziehen><en> Important! For safety reasons, a current consumer may still not draw electrical current at the same time from two different power sources.
<G-vec00169-001-s088><draw.beziehen><de> Wichtig!Ein Stromverbraucher darf auch weiterhin aus Sicherheitsgründen nicht gleichzeitig aus zwei verschiedenen Versorgungsquellen den elektrischen Strom beziehen.
<G-vec00169-001-s089><draw.beziehen><en> If you keep your residence in Switzerland and continue to draw a salary from a Swiss employer, you do not need to make any arrangements in terms of retirement provision.
<G-vec00169-001-s089><draw.beziehen><de> Wenn Sie Ihren Wohnsitz in der Schweiz behalten und weiterhin Lohn von Ihrem Schweizer Arbeitgeber beziehen, brauchen Sie in puncto Vorsorge keine Vorkehrungen zu treffen.
<G-vec00169-001-s090><draw.beziehen><en> I think it’s difficult to draw parallels to the present day, I see more in common with the Nouvelle Vague.
<G-vec00169-001-s090><draw.beziehen><de> Schwierig, ich glaube, man kann es schwer auf heute beziehen, ich sehe da eher Parallelen zur Nouvelle Vague.
<G-vec00169-001-s091><draw.beziehen><en> This system does not prioritize which AC consumers can draw energy from the battery bank.
<G-vec00169-001-s091><draw.beziehen><de> Dieses System priorisiert nicht, welche AC-Verbraucher Energie aus der Batteriebank beziehen können.
<G-vec00169-001-s092><draw.beziehen><en> We draw our strengths from the constructive and respectful cooperation of associates, advisors, management and all employees.
<G-vec00169-001-s092><draw.beziehen><de> Wir beziehen unsere Stärke aus der konstruktiven, respektvollen Zusammenarbeit von Gesellschaftern, Beirat, Geschäftsleitung und allen Mitarbeiterinnen und Mitarbeitern.
<G-vec00169-001-s093><draw.beziehen><en> Computer animation and atmospherically compelling reenactments serve both to illustrate the action and to draw the viewer emotionally into the action at the same time.
<G-vec00169-001-s093><draw.beziehen><de> Computeranimationen und atmosphärisch dichte Reenactments dienen der Veranschaulichung und beziehen den Zuschauer gleichzeitig emotional in das Geschehen ein.
<G-vec00169-001-s094><draw.beziehen><en> The members of the State Council – faithful servants of two or three emperors continued to sit, or at least to draw their salaries.
<G-vec00169-001-s094><draw.beziehen><de> Die Mitglieder des Staatsrates, treue Diener zweier oder dreier Kaiser, fuhren fort zu tagen, zumindest ihr Gehalt zu beziehen.
<G-vec00169-001-s095><draw.bringen><en> Repressed and relegated to the netherworld of the unconscious, this shadow-side will peep out from behind your equable exterior, revealing a more dictatorial and arrogant personality than you wish others to see; and it will draw you compulsively into entanglements where you are thrown back on your own resources.
<G-vec00169-001-s095><draw.bringen><de> Wenn diese Schattenseite unterdrückt und in die Unterwelt des Unbewussten verwiesen wird, kommt sie hinter Ihrem freundlichen Äusseren zum Vorschein und zeigt dann eine diktatorischere und arrogantere Persönlichkeit, als Sie anderen Leuten zeigen möchten, und sie wird Sie zwanghaft in Komplikationen bringen, wo Sie auf Ihre eigenen Ressourcen zurückgreifen müssen.
<G-vec00169-001-s096><draw.bringen><en> May she intercede for us all, and draw us closer to Christ her Son.
<G-vec00169-001-s096><draw.bringen><de> Sie möge für uns alle Fürsprache halten und uns näher zu Christus, ihrem Sohn, bringen.
<G-vec00169-001-s097><draw.bringen><en> 6) Combining the legislative and the executive powers, the revolutionary state power of the proletariat shall do its utmost to draw the administrative apparatus nearer to the masses and merge it with them and to ensure the participation of all toilers to the conduct of administrative affairs.
<G-vec00169-001-s097><draw.bringen><de> 6) Die vereinten legislativen und exekutiven Kräfte des revolutionären proletarischen Staates werden ihr äusserstes tun, um den Verwaltungsapparat näher zu den Massen zu bringen, diesen mit ihnen zu verschmelzen und die Teilnahme der Werktätigen an allen verwaltungsmässigen Belangen sicher zu stellen.
<G-vec00169-001-s098><draw.bringen><en> But today what is being suggested is to draw up a preamble without a constitution.
<G-vec00169-001-s098><draw.bringen><de> Doch was man jetzt zu Papier bringen will, ist eine Präambel ohne Verfassung.
<G-vec00169-001-s099><draw.bringen><en> This will surely enable us to draw better conclusions.
<G-vec00169-001-s099><draw.bringen><de> Das wird uns sicherlich einige Erkenntnisse mehr bringen als das letzte Wochenende.
<G-vec00169-001-s100><draw.bringen><en> It is admittedly difficult to keep one's joy - the dance of one's soul - high when dealing with a cantankerous person, or an unkind person or a domineering or manipulative person, or a person who exhibits a pattern of trying to draw one into a conflict.
<G-vec00169-001-s100><draw.bringen><de> Es ist ohne Zweifel schwierig, die eigene Freude - den Tanz der eigenen Seele - hoch zu halten, wenn man mit streitsüchtigen, unfreundlichen, herrischen oder manipulativen Menschen zu tun hat, oder auch Menschen, die das Muster an den Tag legen, einen in Konflikt zu bringen.
<G-vec00169-001-s101><draw.bringen><en> As the Paris climate talks take the global stage, it's time to draw attention to the military elephant in the room and demand that adaptation to climate change is led by principles of human rights and solidarity, rather than militarism and corporate profits.
<G-vec00169-001-s101><draw.bringen><de> Während die Klimaverhandlungen in Paris in den internationalen Medien im Mittelpunkt stehen, ist es höchste Zeit, das Thema Militär auf den Tisch zu bringen und zu fordern, dass die Anpassung an den Klimawandel von Menschenrechtsprinzipien und Solidarität geleitet wird, statt von Militarismus und Konzernprofiten.
<G-vec00169-001-s102><draw.bringen><en> One has to see the publication of this information more as an opportunity to draw attention to one’s own business interests and oneself and not so much as a useful evaluation of brands.
<G-vec00169-001-s102><draw.bringen><de> Man muss die Veröffentlichungen dieser Informationen eher als Möglichkeit sehen, die eigenen Geschäftsinteressen sich ins Gespräch zu bringen und nicht so sehr als brauchbare Bewertung von Marken.
<G-vec00169-001-s103><draw.bringen><en> If you wish, a St. Regis Butler will arrive after your morning wake-up call to draw your shades, deliver your coffee or tea, and provide the day's newspaper and weather forecast.
<G-vec00169-001-s103><draw.bringen><de> Auf Wunsch kommt nach dem Weckruf ein Butler des St. Regis, um die Vorhänge aufzuziehen, Ihnen Kaffee oder Tee sowie die Tageszeitung zu bringen und um Ihnen die Wettervorhersage mitzuteilen.
<G-vec00169-001-s104><draw.bringen><en> The 2009 Championships in Berlin are supposed to enthuse the youth for athletics and draw them back to the clubs long before the event.
<G-vec00169-001-s104><draw.bringen><de> Die WM 2009 Berlin sollte schon weit im Vorfeld auch die Jugend für die Leichtathletik begeistern und wieder in die Vereine bringen.
<G-vec00169-001-s105><draw.bringen><en> Our systems draw all these functions together under a uniform design concept.
<G-vec00169-001-s105><draw.bringen><de> Unsere Systeme bringen alle Funktionen in eine einheitliche Gestaltung.
<G-vec00169-001-s106><draw.bringen><en> Changed into the body and blood of Christ, the bread and wine insert us into a principle of gradual transfiguration that will draw us towards the goal we long for – the definitive transformation of all in communion with Christ and with one another: ‘And all of us…are being transformed into the same image from one degree of glory to another; for this comes from the Lord, the Spirit’ (2 Cor 3:18).
<G-vec00169-001-s106><draw.bringen><de> Die in den Leib und das Blut Christi verwandelten Gestalten von Brot und Wein ziehen uns hinein in die Dynamik einer kontinuierlichen Umgestaltung und bringen uns dem Ziel näher, nach dem wir uns sehnen– der endgültigen Verwandlung von allem in der Communio mit Christus und untereinander: „Wir alle... werden so in sein eigenes Bild verwandelt, von Herrlichkeit zu Herrlichkeit, durch den Geist des Herrn.“ (2Kor 3,18).
<G-vec00169-001-s107><draw.bringen><en> As well as dry, dusty areas—wet, moist areas draw the risk of mold allergens into your home sweet home.
<G-vec00169-001-s107><draw.bringen><de> Wie trockene und staubige Bereiche bringen auch nasse und feuchte Stellen das Risiko von Schimmelpilzallergie in Ihr zu Hause.
<G-vec00169-001-s108><draw.bringen><en> They draw together business experts, corporate delegates and social enterprises to build local and regional networks for sharing good practices and to disseminate awareness and support for new ethical enterprises.
<G-vec00169-001-s108><draw.bringen><de> Sie bringen Wirtschafsexperten, Vertreter von Konzernen und sozialen Unternehmen zusammen, um auf lokaler und regionaler Ebene Netzwerke aufzubauen, in denen bewährte Praktiken ausgetauscht und Bewusstsein und Unterstützung für neue ethisch orientierte Unternehmen verbreitet werden können.
<G-vec00169-001-s109><draw.bringen><en> Again I desire to draw you closer to my Immaculate Heart, where you will find refuge and peace.
<G-vec00169-001-s109><draw.bringen><de> Ich möchte euch von neuem meinem Unbefleckten Herzen näher bringen, wo ihr Zuflucht und Frieden finden werdet.
<G-vec00169-001-s110><draw.bringen><en> In this way they not only want to secure that the EU remains within the American global system but also draw them closer to their aggressive approach to the Middle East.
<G-vec00169-001-s110><draw.bringen><de> Auf diesem Weg wollen sie nicht nur sicherstellen, dass die EU innerhalb des amerikanischen globalen Systems bleibt, sondern sie auch näher an ihre aggressive Haltung im Nahen Osten bringen.
<G-vec00169-001-s111><draw.bringen><en> The Jazz Festival, numerous local sporting events, and of course famous attractions also draw guests to our hotel.
<G-vec00169-001-s111><draw.bringen><de> Das Jazzfestival, zahlreiche lokale Sportveranstaltungen und selbstverständlich die berühmten Attraktionen bringen Gäste ebenfalls in unser Hotel.
<G-vec00169-001-s112><draw.bringen><en> Yet whereas in the positive realms the [mode] is to draw the developing soul toward deep degrees of expansion into light, in the corresponding negative realms the object is, rather, a … development of appropriate mind/body mechanical means of devouring more light, stuffing the light-energy into the voracious hole or constitutional void of emotional lack comprising the negative state of the ego-soul altogether.
<G-vec00169-001-s112><draw.bringen><de> Während in den positiven Bereichen der (Modus) darin liegt, die sich entwickelnde Seele in Situationen zu bringen, wo sie sich tiefgehend INS Licht erweitern kann, besteht das Ziel in den korrespondierenden negativen Bereich darin,... die Entwicklung von passenden mechanischen Geist/Körper Funktionen zu erreichen, damit die Lichtenergie vom gierigen Loch oder der naturgegebenen Leere des Fehlens von Emotionen mehr Licht verschlungen werden kann, einschließlich des negativen Zustandes des Ego-Seele Komplexes.
<G-vec00169-001-s113><draw.bringen><en> Creative project with an aim to draw creativity and emotions to technical glass.
<G-vec00169-001-s113><draw.bringen><de> Das kreatives Projekt mit Ziel die Schöpfungskraft und die Gefühle in dem technischen Glas zu bringen.
<G-vec00169-001-s190><draw.drucken><en> Printable nš 11 Clarence activities for kids learn to draw pictures 11
<G-vec00169-001-s190><draw.drucken><de> Bild no 11 Clarence Aktivitäten für Kindern zum drucken.
<G-vec00169-001-s191><draw.drucken><en> Printable nš 3 Muppets activities for kids learn to draw pictures 3
<G-vec00169-001-s191><draw.drucken><de> Bild no 3 Muppets Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s192><draw.drucken><en> Code Lyoko activities for kids learn to draw pictures 3
<G-vec00169-001-s192><draw.drucken><de> Code Lyoko Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s193><draw.drucken><en> Fireman Sam activities for kids learn to draw pictures 3
<G-vec00169-001-s193><draw.drucken><de> Feuerwehrmann Sam Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s194><draw.drucken><en> Captain Underpants activities for kids learn to draw pictures 11
<G-vec00169-001-s194><draw.drucken><de> Captain Underpants Aktivitäten für Kindern zum drucken.
<G-vec00169-001-s195><draw.drucken><en> Bob the Builder activities for kids learn to draw pictures 7
<G-vec00169-001-s195><draw.drucken><de> Bob der Baumeister Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s196><draw.drucken><en> Moxie Girlz activities for kids learn to draw pictures 3
<G-vec00169-001-s196><draw.drucken><de> Moxie Girlz Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s197><draw.drucken><en> Super Wings activities for kids learn to draw pictures 3
<G-vec00169-001-s197><draw.drucken><de> Super Wings Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s198><draw.drucken><en> World of Waldorf activities for kids learn to draw pictures 11
<G-vec00169-001-s198><draw.drucken><de> Welt von Waldorf Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s199><draw.drucken><en> Printable nš 3 Barbapapa activities for kids learn to draw pictures 3
<G-vec00169-001-s199><draw.drucken><de> Bild no 3 Barbapapa Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s200><draw.drucken><en> Dora the Explorer activities for kids learn to draw pictures 51
<G-vec00169-001-s200><draw.drucken><de> Dora the Explorer Aktivitäten für Kindern zum drucken.
<G-vec00169-001-s201><draw.drucken><en> Disney activities for kids learn to draw pictures 263
<G-vec00169-001-s201><draw.drucken><de> Disney Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s202><draw.drucken><en> The Beatles activities for kids learn to draw pictures 19
<G-vec00169-001-s202><draw.drucken><de> The Beatles Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s203><draw.drucken><en> Printable nš 3 Max And Ruby activities for kids learn to draw pictures 3
<G-vec00169-001-s203><draw.drucken><de> Bild no 3 Max und Ruby Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s204><draw.drucken><en> Matt Hatter activities for kids learn to draw pictures 3
<G-vec00169-001-s204><draw.drucken><de> Matt Hatter Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s205><draw.drucken><en> Pinky Dinky Doo activities for kids learn to draw pictures 3
<G-vec00169-001-s205><draw.drucken><de> Pinky Dinky Doo Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s206><draw.drucken><en> Rusty Rivets activities for kids learn to draw pictures 3
<G-vec00169-001-s206><draw.drucken><de> Rusty Rivets Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s207><draw.drucken><en> Postman Pat activities for kids learn to draw pictures 19
<G-vec00169-001-s207><draw.drucken><de> Postbote Pat Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s208><draw.drucken><en> Teen Titans activities for kids learn to draw pictures 3
<G-vec00169-001-s208><draw.drucken><de> Teen Titans Aktivitäten für Kinder zum drucken.
<G-vec00169-001-s209><draw.entwerfen><en> With their active support, you will be able to draw up well-planned catechetical programmes that employ a progressive and gradual methodology, so that from year to year an ever-deepening encounter with the Triune God may be fostered among your people.
<G-vec00169-001-s209><draw.entwerfen><de> Mit ihrer aktiven Unterstützung wird es euch möglich sein, gutgeplante Katecheseprogramme zu entwerfen, die einer fortschreitenden, graduellen Methode folgen, um von Jahr zu Jahr in eurem Volk eine immer tiefere Begegnung mit dem dreifaltigen Gott zu fördern.
<G-vec00169-001-s210><draw.entwerfen><en> The Together initiative brings policymakers closer to citizens with debates online and across Europe to draw up a roadmap for the 2019 European Parliament elections.
<G-vec00169-001-s210><draw.entwerfen><de> Die Initiative Together bringt politische Entscheidungsträger und Bürgerinnen und Bürger zusammen, um mit Debatten im Internet und in ganz Europa einen Fahrplan für die Europawahlen 2019 zu entwerfen.
<G-vec00169-001-s211><draw.entwerfen><en> Restructurings require a unique combination of financial, corporate, real estate, tax, employment and litigation expertise not mentioning the ability to lead intensive parallel negotiations and to draw up the most complex contractual schemes.
<G-vec00169-001-s211><draw.entwerfen><de> Restrukturierung und Insolvenzrecht Umstrukturierungen machen eine einzigartige Kombination aus finanz-, gesellschafts-, immobilien-, steuer-, arbeits- und prozessrechtlicher Expertise erforderlich, darüber hinaus die Fähigkeit, intensive Parallelverhandlungen zu führen und sehr komplexe Vertragskonzepte zu entwerfen.
<G-vec00169-001-s212><draw.entwerfen><en> First of all the transmission system operators draw up a Scenario Framework and present their assessment of the electricity consumption in 10 and 20 years’ time.
<G-vec00169-001-s212><draw.entwerfen><de> Zunächst entwerfen die Übertragungsnetzbetreiber einen Szenariorahmen und stellen ihre Einschätzung zum Stromverbrauch in 10 und 20 Jahren vor.
<G-vec00169-001-s213><draw.entwerfen><en> Description Inspired by Martin Buber's anthology of mystical writings, the brothers Marc and Nicolas T. Weiser draw up an acoustic liturgy.
<G-vec00169-001-s213><draw.entwerfen><de> Beschreibung Angelehnt an Martin Bubers Anthologie mystischer Schriften entwerfen die Brüder Marc und Nicolas T. Weiser eine akustische Liturgie.
<G-vec00169-001-s214><draw.entwerfen><en> We will be happy to advise you and draw up the concept for the optimal use of your energy potential.
<G-vec00169-001-s214><draw.entwerfen><de> Wir beraten Sie gerne und entwerfen das Konzept für die optimale Nutzung Ihrer Energiepotentiale.
<G-vec00169-001-s215><draw.entwerfen><en> “.. to get the public’s attention we have to draw up shocking scenarios using simple and dramatic statements.
<G-vec00169-001-s215><draw.entwerfen><de> """... Um die öffentliche Aufmerksamkeit zu erringen, müssen wir erschreckende Szenarien entwerfen und mit vereinfachten und dramatischen Stellungnahmen in die Offensive gehen."
<G-vec00169-001-s216><draw.entwerfen><en> to get the public's attention we have to draw up shocking scenarios using simple and dramatic statements.
<G-vec00169-001-s216><draw.entwerfen><de> """... Um die öffentliche Aufmerksamkeit zu erringen, müssen wir erschreckende Szenarien entwerfen und mit vereinfachten und dramatischen Stellungnahmen in die Offensive gehen."
<G-vec00169-001-s217><draw.entwerfen><en> I hope that in your work during this Assembly, you will be able to draw up a plan capable of helping the whole Church and the different particular Churches in the commitment to the new evangelization; a project where the urgency of a renewed proclamation involves formation, especially for the new generations, and is combined with a proposal of concrete signs able to make evident the response which the Church intends to offer in this particular moment.
<G-vec00169-001-s217><draw.entwerfen><de> Ich wünsche mir, daß ihr im Rahmen der Arbeit dieser Tage ein Projekt entwerfen könnt, das sich dazu eignet, der Gesamtkirche und den verschiedenen Teilkirchen bei der Aufgabe der Neuevangelisierung zu helfen; ein Projekt, wo man sich bei der dringenden Notwendigkeit einer erneuerten Verkündigung um die Erziehung, besonders für die jungen Generationen, kümmert, verbunden mit dem Vorschlag von konkreten Zeichen, welche die Antwort deutlich zu machen vermögen, die die Kirche in diesem besonderen Augenblick anbieten möchte.
<G-vec00169-001-s218><draw.entwerfen><en> The aim of the Development Dialogue is to draw up an individual development plan that fosters employees' strengths and addresses areas in which they would like to develop further.
<G-vec00169-001-s218><draw.entwerfen><de> Ziel des Entwicklungsdialoges ist es, einen individuellen Entwicklungsplan zu entwerfen, der Stärken fördert und Bereiche adressiert, in denen die Mitarbeiter sich noch weiterentwickeln möchten.
<G-vec00169-001-s219><draw.entwerfen><en> However, considering the intense and constant demand for new technologies and also the current movements of verticalization of this industrial segment, it became essential to draw a bold strategy.
<G-vec00169-001-s219><draw.entwerfen><de> Und, wenn man die vielseitigen und konstanten Anforderungen an neue Technologien in Betracht zieht, sowie die aktuelle Bewegung hin zur Vertikalisierung dieser Branche wird deutlich, dass es nötig wurde eine mutige Strategie zu entwerfen.
<G-vec00169-001-s220><draw.entwerfen><en> We draw up creative and cost-efficient plans in collaboration with the client, so that a unique and brilliant building is constructed, which satisfies all needs of the client.
<G-vec00169-001-s220><draw.entwerfen><de> Wir entwerfen mit dem Auftraggeber zusammen kreative und kostengünstige Pläne, um so schließlich ein einzigartiges und geniales Gebäude zu schaffen, das alle Bedürfnisse der Kunden erfüllt.
<G-vec00169-001-s221><draw.entwerfen><en> They never met around a table to have a Round-Table Conference, to draw up a scheme of doctrine and practice for the churches.
<G-vec00169-001-s221><draw.entwerfen><de> Sie setzten sich nie an einen runden Tisch, um eine Konferenz abzuhalten, um dabei einen Plan für die Lehre und Praxis der Gemeinde zu entwerfen.
<G-vec00169-001-s222><draw.entwerfen><en> We draw up economic and secure communication infrastructures for solutions of your business area.
<G-vec00169-001-s222><draw.entwerfen><de> Wir entwerfen wirtschafliche und sichere Kommunikationsinfrastrukturen für Ihre Branchenlösungen.
<G-vec00169-001-s223><draw.entwerfen><en> Four officers from the Ministry of the Interior and the State Security Service meet in the Interior Ministry at the request of the Politburo to draw up new regulations on leaving the country.
<G-vec00169-001-s223><draw.entwerfen><de> Vier Offiziere des Ministeriums des Innern und der Staatssicherheit kommen im Innenministerium zusammen, um dem Auftrag des Politbüros gemäÃ eine neue Ausreisereiseregelung zu entwerfen.
<G-vec00169-001-s224><draw.entwerfen><en> They then index it into their database in order to draw a pattern of the things you like to buy or would like to buy.
<G-vec00169-001-s224><draw.entwerfen><de> Sie indizieren diese Informationen dann in ihre Datenbank, um ein Muster der Dinge zu entwerfen, die Du gerne kaufst oder kaufen möchtest.
<G-vec00169-001-s225><draw.entwerfen><en> By focusing on the story of an individual, the filmmakers draw a complex picture of the Chilean military dictatorship which despite its historical perspective is now more timely than ever.
<G-vec00169-001-s225><draw.entwerfen><de> Jurybegründung: „Den Filmemachern gelingt es anhand einer Einzelperson ein komplexes Panorama der chilenischen Militärdiktatur zu entwerfen, das trotz des Bezugs auf historische Ereignisse von großer Aktualität ist.
<G-vec00169-001-s226><draw.entwerfen><en> Guides to carry out a fitness check and subsequently draw up a personal nutrition and fitness plan to support a healthier lifestyle in the long term.
<G-vec00169-001-s226><draw.entwerfen><de> Auf Wunsch machen die BLUEf!t-Guides einen Fitness-Check und entwerfen daraufhin einen individuellen Ernährungs- und Trainingsplan mit Fokus auf einen langfristig gesünderen Lebensstil.
<G-vec00169-001-s227><draw.entwerfen><en> At the beginning of a new year it's a good and useful thing to draw up a programme for our inner life and invoke the gift of the Holy Spirit so that God's gift - granted us as an instrument of grace - might bear abundant fruit.
<G-vec00169-001-s227><draw.entwerfen><de> Zu Beginn dieses neuen Jahres ist es schön und nützlich ein Programm zu entwerfen für unser inneres Leben und die Gabe des Heiligen Geistes zu erbitten, so dass das, was Gott uns als Instrument der Gnade gibt reichlich Frucht bringen kann.
<G-vec00169-001-s228><draw.erarbeiten><en> In close cooperation with you, we draw up modelling and development guidelines to aid your modellers and developers.
<G-vec00169-001-s228><draw.erarbeiten><de> Wir erarbeiten mit Ihnen Modellierungs-Guidelines und Entwicklungsrichtlinien, an denen sich ihre Modellierer und Entwickler orientieren.
<G-vec00169-001-s229><draw.erarbeiten><en> You may however speak with your insurer to draw up a joint policy that provides cover for both building and household property, but you can be certain that the premium for this will be on the high side.
<G-vec00169-001-s229><draw.erarbeiten><de> Sie können jedoch mit Ihrem Versicherer sprechen eine gemeinsame Politik zu erarbeiten, die Abdeckung sowohl für Gebäude und Hausrat bietet, aber Sie können sicher sein, dass die Prämie für diese auf der hohen Seite sein wird,.
<G-vec00169-001-s230><draw.erarbeiten><en> IR:digital is a structured approach that we draw upon to address the top five digitalisation opportunities for your company.
<G-vec00169-001-s230><draw.erarbeiten><de> Der IR:digital ist ein strukturiertes Vorgehen, mit dessen Hilfe wir gemeinsam die Top-5-Digitalisierungschancen Ihres Unternehmens erarbeiten.
<G-vec00169-001-s231><draw.erarbeiten><en> The participants therefore agreed to draw up a binding convention under international law for the protection of the Alps.
<G-vec00169-001-s231><draw.erarbeiten><de> Die Teilnehmer der Alpenkonferenz beschlossen daher, ein völkerrechtlich verbindliches Vertragswerk zum Schutz der Alpen zu erarbeiten.
<G-vec00169-001-s232><draw.erarbeiten><en> As a result, the Steering Committee of DIN's Ergonomics Standards Committee recommended its Working Committee on Anthropometry and Biomechanics to draw up a user guide in the form of a DIN SPEC.
<G-vec00169-001-s232><draw.erarbeiten><de> "Der Beirat des Normenausschusses Ergonomie im DIN hat daraufhin seinem zuständigen Arbeitsausschuss ""Anthropometrie und Biomechanik"" empfohlen, einen Anwenderleitfaden in Form einer DIN SPEC zu erarbeiten, der die richtige Auswahl und Verwendung anthropometrischer Daten allgemeinverständlich behandelt."
<G-vec00169-001-s233><draw.erarbeiten><en> We analyse national and international policy concepts and instruments such as environmental labels and draw up sustainability strategies – especially for the trade sector – which are tailored to the respective protagonists.
<G-vec00169-001-s233><draw.erarbeiten><de> Wir analysieren nationale und internationale Politikkonzepte und -instrumente wie Umweltzeichen und erarbeiten Nachhaltigkeitsstrategien – beispielsweise für den Handel –, die auf die Akteure zugeschnitten sind.
<G-vec00169-001-s234><draw.erarbeiten><en> Our applications engineers draw up individual solutions concepts and specialise in finding the most efficient alternative for the production of your moulded part.
<G-vec00169-001-s234><draw.erarbeiten><de> Unsere Anwendungstechniker erarbeiten individuelle Lösungskonzepte und sind darauf spezialisiert, die effizienteste Alternative zur Herstellung Ihres Spritzteils zu finden.
<G-vec00169-001-s235><draw.erarbeiten><en> In our Smart Development Assessment we draw up an analysis of potential based on our maturity model, including an improvement concept and implementation planning.
<G-vec00169-001-s235><draw.erarbeiten><de> Mit unserem Smart Development Assessment erarbeiten wir eine reifegradmodell-gestützte Potenzialanalyse einschließlich eines Verbesserungskonzepts und einer Umsetzungsplanung.
<G-vec00169-001-s236><draw.erarbeiten><en> MFK development and mechanical engineering draw up meshwork and composite materials which are suitable for users, including for your specific requirements.
<G-vec00169-001-s236><draw.erarbeiten><de> MFK Entwicklung und Maschinenbau erarbeiten anwendergerechte Maschenwerke und Verbundmaterialien, auch für Ihre spezielle Aufgabenstellung.
<G-vec00169-001-s237><draw.erarbeiten><en> The aim was to draw up a list of criteria for transparency and uniform quality standards such as effectiveness, trust and data security.
<G-vec00169-001-s237><draw.erarbeiten><de> Ziel war es, eine Liste mit Kriterien zu erarbeiten, die Aussagen zur Transparenz und einheitlichen Quali tätsstandards wie Wirksamkeit, Ver trauenswürdigkeit und Datensicherheit enthält.
<G-vec00169-001-s238><draw.erarbeiten><en> Germany and Mali cooperate at various levels. On the one hand, Germany is supporting the government in its efforts to draw up and implement national policies.
<G-vec00169-001-s238><draw.erarbeiten><de> Die Kooperation von Deutschland und Mali erfolgt auf mehreren Ebenen: Zum einen wird die Regierung dabei unterstützt, nationale politische Strategien zu erarbeiten und umzusetzen.
<G-vec00169-001-s239><draw.erarbeiten><en> With the aid of their experimental findings and computer simulations, Jülich researchers continue to develop existing climate models, act as experts, and draw up recommendations for action for policymakers.
<G-vec00169-001-s239><draw.erarbeiten><de> Mit ihren experimentellen Erkenntnissen sowie Computersimulationen entwickeln Jülicher Forscher bestehende Klimamodelle weiter, wirken als Gutachter und erarbeiten Handlungsempfehlungen für politische Entscheidungsträger.
<G-vec00169-001-s240><draw.erarbeiten><en> At the request of the customer, experts are able to draw up a detailed plan to standardize the machinery.
<G-vec00169-001-s240><draw.erarbeiten><de> Auf Kundenwunsch erarbeiten Experten ein detailliertes Konzept, um den Maschinenpark zu vereinheitlichen.
<G-vec00169-001-s241><draw.erarbeiten><en> Our thirty years of experience has led us to draw up simple yet at the same time efficient Quality Control procedures.
<G-vec00169-001-s241><draw.erarbeiten><de> Durch unsere zwanzigjährige Erfahrung sind wir dazu in der Lage, einfache und gleichzeitig effiziente Qualitätskontrollprozesse zu erarbeiten.
<G-vec00169-001-s242><draw.erarbeiten><en> We suggest that the Biblical Pontifical Commission, together with the International Theological Commission draw up a document which provides rules governing the use of the apocryphal in the exegesis of biblical texts, without compromising the inspired character of the biblical texts, and above all, without compromising the Salvific message that they contain.
<G-vec00169-001-s242><draw.erarbeiten><de> Man schlägt vor, dass die Päpstliche Bibelkommission zusammen mit der Internationalen Theologischen Kommission ein Dokument erarbeiten möge, welches den Gebrauch der Apokryphen bei der Exegese der biblischen Texte, ohne den inspirierten Charakter der biblischen Texte und vor allem ohne die erlösende Botschaft, die darin enthalten ist, zu kompromittieren, regelt.
<G-vec00169-001-s243><draw.erarbeiten><en> With a popular initiative a minimum required number of citizens can call on a state parliament to draw up a law.
<G-vec00169-001-s243><draw.erarbeiten><de> Mit der Volksinitiative fordert eine Mindestzahl von Bürgern ein Landesparlament auf, ein Gesetz zu erarbeiten.
<G-vec00169-001-s244><draw.erarbeiten><en> With the aid of their experimental findings and computer simulations, Jülich researchers continue to develop existing climate models, act as experts, and draw up recommended actions for policymakers.
<G-vec00169-001-s244><draw.erarbeiten><de> Mit ihren experimentellen Erkenntnissen sowie Computersimulationen entwickeln Jülicher Forscher bestehende Klimamodelle weiter, wirken als Gutachter und erarbeiten Handlungsempfehlungen für politische Entscheidungsträger.
<G-vec00169-001-s245><draw.erarbeiten><en> Our applications engineers draw up individual solutions concepts and specialise in finding the most efficient alternative for the production of your moulded part.
<G-vec00169-001-s245><draw.erarbeiten><de> Anwendungstechnik Unsere Anwendungstechniker erarbeiten individuelle Lösungskonzepte und sind darauf spezialisiert, die effizienteste Alternative zur Herstellung Ihres Spritzteils zu finden.
<G-vec00169-001-s246><draw.erarbeiten><en> Every threat demands specific countermeasures, and our experts will therefore draw up tailor-made security solutions together with you.
<G-vec00169-001-s246><draw.erarbeiten><de> Da jede Sicherheitsgefährdung eine spezielle Gegenmaßnahme verlangt, erarbeiten unsere Experten mit Ihnen gemeinsam maßgeschneiderte Sicherheitslösungen.
<G-vec00169-001-s247><draw.erstellen><en> We also draw up detailed documentation complete with optimisation options and a list of recommended repairs in order of urgency.
<G-vec00169-001-s247><draw.erstellen><de> Zudem erstellen wir eine ausführliche Dokumentation samt Optimierungsoptionen und einer Liste empfohlener Reparaturen in der Reihenfolge ihrer Dringlichkeit.
<G-vec00169-001-s248><draw.erstellen><en> Using our electricity market trading systems, we evaluate your large customers' load profile and draw up an analysis.
<G-vec00169-001-s248><draw.erstellen><de> Wir bewerten das Lastprofil Ihres Grosskunden anhand unserer Handelssysteme am Strommarkt und erstellen eine Analyse.
<G-vec00169-001-s249><draw.erstellen><en> Immediately after the occupation, the Jewish religious communities had to draw up lists of their members' names.
<G-vec00169-001-s249><draw.erstellen><de> Unmittelbar nach der Okkupation mussten die jüdischen Glaubensgemeinschaften Listen mit den Namen ihrer Mitglieder erstellen.
<G-vec00169-001-s250><draw.erstellen><en> The European standards organizations, CEN, CENELEC and ETSI are commissioned to draw up EU standards that technically solidify the applicable directives and legal provisions.
<G-vec00169-001-s250><draw.erstellen><de> Die europäischen Normenorganisationen CEN, CENELEC und ETSI sind beauftragt, EU-Normen zu erstellen, die die Richtlinien und gesetzlichen Bestimmungen technisch konkretisieren.
<G-vec00169-001-s251><draw.erstellen><en> After processing a sample, we first draw up a record of all process parameters.
<G-vec00169-001-s251><draw.erstellen><de> Nach einer Musterbearbeitung erstellen wir zunächst ein Protokoll über sämtliche Prozess­parameter.
<G-vec00169-001-s252><draw.erstellen><en> Working in harness with areas such as computer technology, application engineering, hardware development, and technical sales, you draw up requirements analysis and develop user-specific solutions.
<G-vec00169-001-s252><draw.erstellen><de> In Zusammenarbeit mit Bereichen wie Informationstechnologie, Applikation, Hardwareentwicklung oder dem technischen Vertrieb erstellen Sie Anforderungsanalysen und entwickeln anwenderspezifische Lösungen.
<G-vec00169-001-s253><draw.erstellen><en> The Expert Committee Personal Protective Equipment of the DGUV and its 11 subcommittees advise and support the individual German Social Accident Insurance Institutions, state bodies, companies, insured individuals, manufacturers, and other stakeholders across all sectors with regard to personal protective equipment, and draw up rules and guidelines for its proper use.
<G-vec00169-001-s253><draw.erstellen><de> Der Fachbereich Persönliche Schutzausrüstungen der DGUV und seine 11 Sachgebiete beraten und unterstützen Unfallversicherungsträger, staatliche Stellen, Unternehmen, Versicherte, Hersteller und andere interessierte Kreise branchenübergreifend in Fragen zu persönlichen Schutzausrüstungen und erstellen Regeln und Leitlinien für den richtigen Umgang mit PSA.
<G-vec00169-001-s254><draw.erstellen><en> Specialized and experienced doctors draw up an optimal treatment program for each guest of Piešt'any Health Spa on an individual basis.
<G-vec00169-001-s254><draw.erstellen><de> Spezialisierte und erfahrene Ärzte erstellen stets für jeden Gast des Heilbades Piešt'any ein optimales Behandlungsprogramm.
<G-vec00169-001-s255><draw.erstellen><en> He also had to draw up instructions for keeping and breeding the fish.
<G-vec00169-001-s255><draw.erstellen><de> Zudem musste er Anleitungen für die Haltung und Zucht erstellen.
<G-vec00169-001-s256><draw.erstellen><en> Multi Colors Chart Lines Indicator Download Multi Colors Chart Lines Indicator will draw up to 10 different colors horizontal lines that can be hided or shown with buttons on the chart. Download Multi Colors Chart Lines Indicator:... Tagged with: Average Daily Range
<G-vec00169-001-s256><draw.erstellen><de> Multi Farben Diagrammlinien Indikator herunterladen Multi Farben Diagrammlinien-Anzeige erstellen, wird 10 verschiedenen Farben horizontale Linien, die mit den Tasten auf der Karte ausgeblendete oder gezeigt werden kann,.
<G-vec00169-001-s257><draw.erstellen><en> We draw up specifications, document generally accepted practices (golden rules), and define operating logic, operating procedures, and operating modalities.
<G-vec00169-001-s257><draw.erstellen><de> Wir erstellen Lastenhefte, dokumentieren allgemeingültige Rahmenbedingungen (Golden Rules) und definieren Bedienlogiken, Bedienabläufe und –modalitäten.
<G-vec00169-001-s258><draw.erstellen><en> We regularly monitor progress, draw up detailed organizational, schedule and payment plans, collect feedback for the suppliers and streamline change management.
<G-vec00169-001-s258><draw.erstellen><de> Wir kontrollieren regelmäßig den Fortgang der Arbeiten, erstellen detaillierte Organisations-, Termin- und Zahlungspläne, sammeln die Rückmeldungen an den Lieferanten und bündeln das Änderungsmanagement.
<G-vec00169-001-s259><draw.erstellen><en> Together with other experts we draw up comparative analyses to assist you in your decision for a business location.
<G-vec00169-001-s259><draw.erstellen><de> Länderanalysen Gemeinsam mit anderen Länderexperten erstellen wir vergleichende Analysen, die Sie in der Standortentscheidung unterstützen.
<G-vec00169-001-s260><draw.erstellen><en> They acquire customers and advise and support them before and during events, they draw up time schedules and procedures ensuring that they are being implemented.
<G-vec00169-001-s260><draw.erstellen><de> Sie akquirieren Kunden, beraten und betreuen diese vor und während der Veranstaltungen, erstellen Ablauf- und Regiepläne und setzen diese um.
<G-vec00169-001-s261><draw.erstellen><en> Businesses which use more drugs than comparable businesses must draw up plans and take measures to reduce use.
<G-vec00169-001-s261><draw.erstellen><de> Betriebe, die mehr Arzneimittel anwenden als Vergleichsbetriebe, müssen Pläne erstellen und Maßnahmen ergreifen, um diesen Einsatz zu reduzieren.
<G-vec00169-001-s262><draw.erstellen><en> For this reason, we draw up a controversial evaluation on the basis of media reports in order to be able to better assess the actual behaviour of the companies.
<G-vec00169-001-s262><draw.erstellen><de> Aus diesem Grund erstellen wir auf der Basis von Medienberichten eine Kontroversen-Bewertung, um das tatsächliche Verhalten der Unternehmen besser abschätzen zu können.
<G-vec00169-001-s263><draw.erstellen><en> Draw up a realistic budget.
<G-vec00169-001-s263><draw.erstellen><de> Erstellen Sie ein realistisches Budget.
<G-vec00169-001-s264><draw.erstellen><en> SilverFast is advantageous in this chapter, due to its numerous possibilities to draw up a perfect Scan.
<G-vec00169-001-s264><draw.erstellen><de> Von Vorteil ist hier die SilverFast Software mit ihren zahlreichen Möglichkeiten, einen perfekten Scan zu erstellen.
<G-vec00169-001-s265><draw.erstellen><en> As a result, the fluctuating loads caused by consumers have to be predicted in order to draw up power plant schedules for the following day.
<G-vec00169-001-s265><draw.erstellen><de> Die fluktuierenden Lasten durch die Verbraucher müssen somit prognostiziert werden, um damit Kraftwerksfahrpläne für den Folgetag erstellen zu können.
<G-vec00169-001-s266><draw.erstellen><en> The Commission shall draw up a report in respect of the delegation of power not later than nine months before the end of the five-year period.
<G-vec00169-001-s266><draw.erstellen><de> Die Kommis­ sion erstellt spätestens neun Monate vor Ablauf des Zeitraums von fünf Jahren einen Bericht über die Befugnisübertragung.
<G-vec00169-001-s267><draw.erstellen><en> With a consortium comprised of international non-governmental organisations and universities, the project has started to draw up five case studies that identify and document the multiple benefits of preserving ecosystems.
<G-vec00169-001-s267><draw.erstellen><de> Das Projekt erstellt in einem Konsortium bestehend aus internationalen Nichtregierungsorganisationen und Universitäten fünf Fallstudien, die die vielseitigen Vorteile des Erhalts von Ökosystemen herausarbeiten und dokumentieren.
<G-vec00169-001-s268><draw.erstellen><en> The bodice is encrusted with sparkling beadings decoration which will draw attention to the dress.
<G-vec00169-001-s268><draw.erstellen><de> Das Oberteil ist mit funkelnden gefrieste Dekoration, die Aufmerksamkeit auf das Kleid erstellt verkrustet.
<G-vec00169-001-s269><draw.erstellen><en> Provided an application has been accorded a date of filing and is not deemed to be withdrawn, Article 92 EPC requires that the Search Division shall draw up the European search report on the basis of the claims of the application (with due regard to the description and any drawings).
<G-vec00169-001-s269><draw.erstellen><de> Steht der Anmeldetag einer Anmeldung fest und gilt die Anmeldung nicht als zurückgenommen, so erstellt die Recherchenabteilung nach Artikel 92 EPÜ den europäischen Recherchenbericht auf der Grundlage der Patentansprüche der Anmeldung (unter angemessener Berücksichtigung der Beschreibung und der vorhandenen Zeichnungen).
<G-vec00169-001-s270><draw.erstellen><en> If the search division considers that the application lacks unity of invention, it shall draw up a partial search report on the first invention.
<G-vec00169-001-s270><draw.erstellen><de> Entspricht die Anmeldung nach Auffassung der Recherchenabteilung nicht den Anforderungen an die Einheitlichkeit der Erfindung, so erstellt sie einen teilweisen Recherchenbericht für die erste Erfindung.
<G-vec00169-001-s271><draw.erstellen><en> At Brunner, we are well prepared to tackle client-specific product development: in the joinery, in the upholstery and in the final manufacturing, there is one employee each responsible only for building models and special editions, who can draw up feasibility analyses and can act at once if needed.
<G-vec00169-001-s271><draw.erstellen><de> Auch für die kundenspezifische Produktentwicklung ist man bei Brunner bestens gerüstet: In Schreinerei, Polsterei und Endmontage steht jeweils ein Mitarbeiter ausschließlich für Musterbau und Sonderanfertigungen zur Verfügung, erstellt Machbarkeitsanalysen und kann bei Bedarf sofort agieren.
<G-vec00169-001-s272><draw.erstellen><en> 2 Â The Federal Council shall draw up a list of the criteria governing the classification of wines with appellation contrÃ ́lée and domestic wines.
<G-vec00169-001-s272><draw.erstellen><de> 2 Der Bundesrat erstellt die Liste der für Weine mit kontrollierter Ursprungsbezeichnung und Landweine geltenden Kriterien.
<G-vec00169-001-s273><draw.erstellen><en> """Before we spend money on anything, we draw up a budget and calculate everything through."
<G-vec00169-001-s273><draw.erstellen><de> """Bevor wir Geld für etwas ausgeben, wird ein Finanzplan erstellt und alles durchgerechnet."
<G-vec00169-001-s274><draw.erstellen><en> We point out any discrepancies and draw up a list of proposed, targeted improvement measures for your business.
<G-vec00169-001-s274><draw.erstellen><de> Neosys zeigt Abweichungen auf und erstellt für Sie zielorientierte Massnahmenvorschläge für Verbesserungen in Ihrem Betrieb.
<G-vec00169-001-s275><draw.erstellen><en> He will manage in accord with the Treasurer the funds of the ISIA, the bills, keep receipts and draw up the balance sheet for the Assemblies.
<G-vec00169-001-s275><draw.erstellen><de> Er verwaltet in Absprache mit dem Schatzmeister die Gelder der ISIA, veranlasst die Ausbezahlung der Rechnungen, verwahrt die Rechnungsbelege und erstellt die Abrechnungen zu den Versammlungen.
<G-vec00169-001-s276><draw.erstellen><en> For this purpose, the Arbeitsgemeinschaft erneuerbare Energie GmbH, Gleisdorf, was instructed to do a dynamic building and site simulation and to draw up from this an optimized energy concept.
<G-vec00169-001-s276><draw.erstellen><de> Dazu wurde die Arbeitsgemeinschaft erneuerbare Energie GmbH, Gleisdorf, mit einer dynamischen Gebäude- und Anlagensimulation beauftragt und es wurde daraus ein optimiertes Energiekonzept erstellt.
<G-vec00169-001-s277><draw.erstellen><en> The waist of the dress is accented by the pattern motif which will draw attention to the dress.
<G-vec00169-001-s277><draw.erstellen><de> Die Taille des Kleides wird durch das Muster Motiv, das die Aufmerksamkeit auf das Kleid erstellt akzentuiert.
<G-vec00169-001-s278><draw.erstellen><en> After examining the size of the order, the text and possible specific requirements of the client, Pro-Tran shall draw up an estimate.
<G-vec00169-001-s278><draw.erstellen><de> Nach Überprüfung des Auftragsumfangs, des Textes und etwaiger Sonderwünsche des Auftraggebers wird ein Kostenvoranschlag erstellt.
<G-vec00169-001-s279><draw.erstellen><en> "Depending upon the additional fees which have been duly paid, the Search Division then has to draw up the search report ""for those parts of the European patent application which relate to inventions in respect of which search fees have been paid""."
<G-vec00169-001-s279><draw.erstellen><de> "Sind zusätzliche Gebühren ordnungsgemäß entrichtet worden, so erstellt die Recherchenabteilung den Recherchenbericht ""für die Teile der europäischen Anmeldung, die sich auf die Erfindungen beziehen, für die Recherchengebühren entrichtet worden sind""."
<G-vec00169-001-s280><draw.erstellen><en> This school considers the complexity and Importance of environment question in the future, in 1999 established the department of environmental management, and draw up the related curriculum in view of the future trend of development to plan.
<G-vec00169-001-s280><draw.erstellen><de> Diese Schule ist der Auffassung, die Komplexität und die Bedeutung der Umweltfrage in der Zukunft, gegrÃ1⁄4ndet 1999 die Abteilung fÃ1⁄4r Umweltmanagement und erstellt die zugehörigen Lehrpläne im Hinblick auf die zukÃ1⁄4nftige Entwicklung der Entwicklung zu planen.
<G-vec00169-001-s281><draw.erstellen><en> A logical continuation of the product development process is that, after elaborating the idea, verifying the appliance’s functionality, verifying mechanical features of structures and optimizing parts in order to reduce the mass or increase the bearing capacity, it is necessary to draw up product documents according to which these parts will be produced.
<G-vec00169-001-s281><draw.erstellen><de> Nachdem die Idee erarbeitet und die Funktionalität des Geräts überprüft wurden, die mechanischen Eigenschaften der Konstruktion geprüft und alle Teile optimiert wurden, damit die Masse so gering wie möglich gehalten oder eine stärkere Belastbarkeit hergestellt wird, muss im Prozess der Produktentwicklung auch die zugehörige Produktdokumentation erstellt werden, gemäß welcher die einzelnen Teile dann hergestellt werden.
<G-vec00169-001-s282><draw.erstellen><en> The Commission shall draw up a plan for the phasing out of UNRWA and shall facilitate the transfer of UNRWA functions to host states.
<G-vec00169-001-s282><draw.erstellen><de> Die Kommission erstellt einen Plan für die phasenweise Auflösung der UNRWA und fördert die Übertragung von UNRWA-Funktionen an die Aufnahmestaaten.
<G-vec00169-001-s283><draw.erstellen><en> During acceptance testing, CL shall draw up a report on defects detected, giving the information required for detecting the defects.
<G-vec00169-001-s283><draw.erstellen><de> Der AG erstellt während der Abnahmeprüfung ein Proto koll über fest ge stellte Mängel unter Angabe der für die Mängel erkennung zweckdienlichen Informationen.
<G-vec00169-001-s284><draw.erstellen><en> Collage draw by hand”, - told the art director of “X-Project Denis Suponitskaja.
<G-vec00169-001-s284><draw.erstellen><de> Collage erstellt von Hand”, - sagte die künstlerische Leiterin des “X-Project Denis Suponitskaja.
<G-vec00042-001-s304><draw.zeichnen><en> On a cardboard we draw an oblong petal as at a lily of 10 x 6 cm in size and we cut out it.
<G-vec00042-001-s304><draw.zeichnen><de> Auf der Pappe ist prodolgowatyj das Blumenblatt wie bei der Lilie den Umfang in 10 ch 6 cm gezeichnet und ist es ausgeschnitten.
<G-vec00042-001-s305><draw.zeichnen><en> When we highlight the drawing area, we can use the drawing line to mark the area so we know where to draw it.
<G-vec00042-001-s305><draw.zeichnen><de> Wenn wir den Zeichnungsbereich hervorheben, können wir die Zeichnungslinie verwenden, um den Bereich zu markieren, sodass wir wissen, wo er gezeichnet werden soll.
<G-vec00042-001-s306><draw.zeichnen><en> "The place where the texture map both starts and ends requires wrapping flags to be on so that it doesn't draw the texture wrong way causing those nice ""wrinkled"" surfaces we've seen in far too many demos already."
<G-vec00042-001-s306><draw.zeichnen><de> "An beiden Punkten, wo die Textur beginnt und endet muss die Wrapping Flag aktiviert sein so daß die Textur nicht auf die falsche Weise gezeichnet wird und diese ""abgeschittenen"" Oberflächen hervorruft, die schon schon in zu vielen Demos gesehen haben."
<G-vec00042-001-s307><draw.zeichnen><en> We will not only draw, but also take photographs and make tracings and sound recordings.
<G-vec00042-001-s307><draw.zeichnen><de> Es wird nicht nur gezeichnet sondern auch fotografiert, abgepaust und Soundaufnahmen gemacht.
<G-vec00042-001-s308><draw.zeichnen><en> Any question raised due to the inordinate nature of these events were of no real consequence (then) for the simple reason I had no base of experiences from which to draw from at the time due to the naive nature of my young age.
<G-vec00042-001-s308><draw.zeichnen><de> Jede Frage aufgrund der übermäßig Natur dieser Ereignisse ausgelöst wurden keine echte Rolle (dann) aus dem einfachen Grund, dass ich keine Grundlage der Erfahrungen aus dem zur Zeit aufgrund der naive Art von meinem jungen Alter von gezeichnet werden soll.
<G-vec00042-001-s309><draw.zeichnen><en> There were mothers who had never used a tablet before, fathers who are mad about Minecraft and children who have already learned how to draw in CAD programs.
<G-vec00042-001-s309><draw.zeichnen><de> Es gab Mütter, die noch nie ein Tablet bedient haben, Väter die leidenschaftliche Minecrafter sind, Kinder die schon mit einem CAD-Programm gezeichnet haben.
<G-vec00042-001-s310><draw.zeichnen><en> An application that wants to draw using X11 connects to the server and tells it what to draw.
<G-vec00042-001-s310><draw.zeichnen><de> Ein Programm, das über X11 zeichnen möchte, verbindet sich mit dem Server und teilt ihm mit, was gezeichnet werden soll.
<G-vec00042-001-s311><draw.zeichnen><en> Unfortunately ACHERON starts with –2 Points, because the cover of their new album might be the most stupid one I’ve ever seen, perhaps a 11 year old Black kid draw it to shock his parents or so.
<G-vec00042-001-s311><draw.zeichnen><de> ACHERON haben es tatsächlich geschafft, eins der dümmsten und dämlichsten Cover zu fabrizieren, die ich je gesehen habe, als ob ein 11 jähriger Black Metaller das gezeichnet hätte, um seine Eltern zu erschrecken, gibt zumindest schon mal eine -2 Hypothek.
<G-vec00042-001-s312><draw.zeichnen><en> #Texture The texture to draw on.
<G-vec00042-001-s312><draw.zeichnen><de> #Textur Die Textur, auf der gezeichnet werden soll.
<G-vec00042-001-s313><draw.zeichnen><en> #Gadget The gadget to draw on.
<G-vec00042-001-s313><draw.zeichnen><de> #Gadget Das Gadget, auf welchem gezeichnet werden soll.
<G-vec00042-001-s314><draw.zeichnen><en> The triangle ruler is a multifunctional form of the rule, to draw a variety of forms.
<G-vec00042-001-s314><draw.zeichnen><de> Das Geodreieck® ist eine multifunktionale Form des Lineals, mit dem vielfältige Formen gezeichnet werden können.
<G-vec00042-001-s315><draw.zeichnen><en> Each draw their flowers and presented separately.
<G-vec00042-001-s315><draw.zeichnen><de> Jeder hat seine Blume gezeichnet und präsentiert.
<G-vec00042-001-s316><draw.zeichnen><en> When determining where to draw text, the logical bounding box is the interesting one.
<G-vec00042-001-s316><draw.zeichnen><de> Bei der Bestimmung, wo der Text gezeichnet werden soll, ist die logische Zeichen-Box die interessante.
<G-vec00042-001-s317><draw.zeichnen><en> x, y The location at which to draw the text.
<G-vec00042-001-s317><draw.zeichnen><de> x, y Die Position, an welcher der Text gezeichnet werden soll.
<G-vec00042-001-s318><draw.zeichnen><en> Once you draw the horizon line, you can begin drawing the foreground below it and the sky or large objects in the landscape above it.
<G-vec00042-001-s318><draw.zeichnen><de> Wenn du den Horizont gezeichnet hast, kannst du damit anfangen, den Vordergrund darunter und den Himmel oder größere Objekte in der Landschaft darüber zu zeichnen.
<G-vec00042-001-s319><draw.zeichnen><en> We first set the suitable material and draw the button afterwards.
<G-vec00042-001-s319><draw.zeichnen><de> Es wird zuerst das passende Material gesetzt, und danach der Button gezeichnet.
<G-vec00042-001-s320><draw.zeichnen><en> Then you can begin to draw lines and curves on a piece of paper.
<G-vec00042-001-s320><draw.zeichnen><de> Dann können Linien und Kurven auf einem Blatt gezeichnet werden.
<G-vec00042-001-s321><draw.zeichnen><en> "At Edit -> Loop, you can now also select ""without loop"" for to calculate and draw endless spring without loops."
<G-vec00042-001-s321><draw.zeichnen><de> "Jetzt kann man unter Bearbeiten -> Öse auch ""ohne Öse"" wählen, dann wird ein Zugfederstrang ohne Ösen berechnet und gezeichnet."
<G-vec00042-001-s322><draw.zeichnen><en> The children paint and draw – with colored pencils, with crayons, with felt-tip pens, with charcoal, and watercolors.
<G-vec00042-001-s322><draw.zeichnen><de> Es wird gemalt und gezeichnet – mit Buntstiften, mit Wachsmalkreide, mit Filzstiften, mit Kohle, mit Aquarell- und mit Wasserfarben.
<G-vec00169-001-s304><draw.gezeichnen><en> On a cardboard we draw an oblong petal as at a lily of 10 x 6 cm in size and we cut out it.
<G-vec00169-001-s304><draw.gezeichnen><de> Auf der Pappe ist prodolgowatyj das Blumenblatt wie bei der Lilie den Umfang in 10 ch 6 cm gezeichnet und ist es ausgeschnitten.
<G-vec00169-001-s305><draw.gezeichnen><en> When we highlight the drawing area, we can use the drawing line to mark the area so we know where to draw it.
<G-vec00169-001-s305><draw.gezeichnen><de> Wenn wir den Zeichnungsbereich hervorheben, können wir die Zeichnungslinie verwenden, um den Bereich zu markieren, sodass wir wissen, wo er gezeichnet werden soll.
<G-vec00169-001-s306><draw.gezeichnen><en> "The place where the texture map both starts and ends requires wrapping flags to be on so that it doesn't draw the texture wrong way causing those nice ""wrinkled"" surfaces we've seen in far too many demos already."
<G-vec00169-001-s306><draw.gezeichnen><de> "An beiden Punkten, wo die Textur beginnt und endet muss die Wrapping Flag aktiviert sein so daß die Textur nicht auf die falsche Weise gezeichnet wird und diese ""abgeschittenen"" Oberflächen hervorruft, die schon schon in zu vielen Demos gesehen haben."
<G-vec00169-001-s307><draw.gezeichnen><en> We will not only draw, but also take photographs and make tracings and sound recordings.
<G-vec00169-001-s307><draw.gezeichnen><de> Es wird nicht nur gezeichnet sondern auch fotografiert, abgepaust und Soundaufnahmen gemacht.
<G-vec00169-001-s308><draw.gezeichnen><en> Any question raised due to the inordinate nature of these events were of no real consequence (then) for the simple reason I had no base of experiences from which to draw from at the time due to the naive nature of my young age.
<G-vec00169-001-s308><draw.gezeichnen><de> Jede Frage aufgrund der übermäßig Natur dieser Ereignisse ausgelöst wurden keine echte Rolle (dann) aus dem einfachen Grund, dass ich keine Grundlage der Erfahrungen aus dem zur Zeit aufgrund der naive Art von meinem jungen Alter von gezeichnet werden soll.
<G-vec00169-001-s309><draw.gezeichnen><en> There were mothers who had never used a tablet before, fathers who are mad about Minecraft and children who have already learned how to draw in CAD programs.
<G-vec00169-001-s309><draw.gezeichnen><de> Es gab Mütter, die noch nie ein Tablet bedient haben, Väter die leidenschaftliche Minecrafter sind, Kinder die schon mit einem CAD-Programm gezeichnet haben.
<G-vec00169-001-s310><draw.gezeichnen><en> An application that wants to draw using X11 connects to the server and tells it what to draw.
<G-vec00169-001-s310><draw.gezeichnen><de> Ein Programm, das über X11 zeichnen möchte, verbindet sich mit dem Server und teilt ihm mit, was gezeichnet werden soll.
<G-vec00169-001-s311><draw.gezeichnen><en> Unfortunately ACHERON starts with –2 Points, because the cover of their new album might be the most stupid one I’ve ever seen, perhaps a 11 year old Black kid draw it to shock his parents or so.
<G-vec00169-001-s311><draw.gezeichnen><de> ACHERON haben es tatsächlich geschafft, eins der dümmsten und dämlichsten Cover zu fabrizieren, die ich je gesehen habe, als ob ein 11 jähriger Black Metaller das gezeichnet hätte, um seine Eltern zu erschrecken, gibt zumindest schon mal eine -2 Hypothek.
<G-vec00169-001-s312><draw.gezeichnen><en> #Texture The texture to draw on.
<G-vec00169-001-s312><draw.gezeichnen><de> #Textur Die Textur, auf der gezeichnet werden soll.
<G-vec00169-001-s313><draw.gezeichnen><en> #Gadget The gadget to draw on.
<G-vec00169-001-s313><draw.gezeichnen><de> #Gadget Das Gadget, auf welchem gezeichnet werden soll.
<G-vec00169-001-s314><draw.gezeichnen><en> The triangle ruler is a multifunctional form of the rule, to draw a variety of forms.
<G-vec00169-001-s314><draw.gezeichnen><de> Das Geodreieck® ist eine multifunktionale Form des Lineals, mit dem vielfältige Formen gezeichnet werden können.
<G-vec00169-001-s315><draw.gezeichnen><en> Each draw their flowers and presented separately.
<G-vec00169-001-s315><draw.gezeichnen><de> Jeder hat seine Blume gezeichnet und präsentiert.
<G-vec00169-001-s316><draw.gezeichnen><en> When determining where to draw text, the logical bounding box is the interesting one.
<G-vec00169-001-s316><draw.gezeichnen><de> Bei der Bestimmung, wo der Text gezeichnet werden soll, ist die logische Zeichen-Box die interessante.
<G-vec00169-001-s317><draw.gezeichnen><en> x, y The location at which to draw the text.
<G-vec00169-001-s317><draw.gezeichnen><de> x, y Die Position, an welcher der Text gezeichnet werden soll.
<G-vec00169-001-s318><draw.gezeichnen><en> Once you draw the horizon line, you can begin drawing the foreground below it and the sky or large objects in the landscape above it.
<G-vec00169-001-s318><draw.gezeichnen><de> Wenn du den Horizont gezeichnet hast, kannst du damit anfangen, den Vordergrund darunter und den Himmel oder größere Objekte in der Landschaft darüber zu zeichnen.
<G-vec00169-001-s319><draw.gezeichnen><en> We first set the suitable material and draw the button afterwards.
<G-vec00169-001-s319><draw.gezeichnen><de> Es wird zuerst das passende Material gesetzt, und danach der Button gezeichnet.
<G-vec00169-001-s320><draw.gezeichnen><en> Then you can begin to draw lines and curves on a piece of paper.
<G-vec00169-001-s320><draw.gezeichnen><de> Dann können Linien und Kurven auf einem Blatt gezeichnet werden.
<G-vec00169-001-s321><draw.gezeichnen><en> "At Edit -> Loop, you can now also select ""without loop"" for to calculate and draw endless spring without loops."
<G-vec00169-001-s321><draw.gezeichnen><de> "Jetzt kann man unter Bearbeiten -> Öse auch ""ohne Öse"" wählen, dann wird ein Zugfederstrang ohne Ösen berechnet und gezeichnet."
<G-vec00169-001-s322><draw.gezeichnen><en> The children paint and draw – with colored pencils, with crayons, with felt-tip pens, with charcoal, and watercolors.
<G-vec00169-001-s322><draw.gezeichnen><de> Es wird gemalt und gezeichnet – mit Buntstiften, mit Wachsmalkreide, mit Filzstiften, mit Kohle, mit Aquarell- und mit Wasserfarben.
<G-vec00169-001-s323><draw.hinweisen><en> Another feature that I'd like to draw your attention to is the Logic tab.
<G-vec00169-001-s323><draw.hinweisen><de> Ich möchte Dich noch auf eine weitere tolle Funktion hinweisen, auf den Bereich Logic .
<G-vec00169-001-s324><draw.hinweisen><en> The video description says only that Suzuki now wants to draw attention to a “complement of the model range for 2020” with a series of teasers.
<G-vec00169-001-s324><draw.hinweisen><de> In der Videobeschreibung steht nur, dass Suzuki jetzt mit einer Reihe von Teasern auf eine „Ergänzung der Modellpalette für 2020“ hinweisen möchte.
<G-vec00169-001-s325><draw.hinweisen><en> However, once I want to draw attention to the fact that in no case should not fight this ailment on its own, even despite the presence of a mass of folk remedies.
<G-vec00169-001-s325><draw.hinweisen><de> Aber nur darauf hinweisen will, dass in jedem Fall ist es nicht notwendig, diese Krankheit auf ihrem eigenen zu kämpfen, trotz der Existenz einer Masse von Volksmedizin.
<G-vec00169-001-s326><draw.hinweisen><en> Medicine wanted to draw attention to the invisible, to the dangers that humans cannot perceive with their senses, dangers such as viruses, bacteria and radioactive beams.
<G-vec00169-001-s326><draw.hinweisen><de> Die Medizin wollte auf die Unsichtbarkeit hinweisen, die durch Gefahren entstehen, die Menschen mit den Sinnen nicht wahrnehmen können, wie Viren, Bakterien und radioaktive Strahlen.
<G-vec00169-001-s327><draw.hinweisen><en> However, BENEFIT cannot control all risks associated with Internet operations and would like to draw the attention of internet users to potential risks which are inherent to using the internet and to its operation.
<G-vec00169-001-s327><draw.hinweisen><de> Da BENEFIT jedoch nicht alle mit der Internetnutzung verbundene Risiken kontrollieren kann, möchten wir die Internetnutzer darauf hinweisen, dass mit der Nutzung des Internet potentielle Gefahren einhergehen.
<G-vec00169-001-s328><draw.hinweisen><en> We would also like to draw your attention to the open access part of the Network Online .
<G-vec00169-001-s328><draw.hinweisen><de> Weiterhin möchten wir Sie auf das öffentliche Netzwerk Online hinweisen.
<G-vec00169-001-s329><draw.hinweisen><en> The aim of the organisers – the European Milk Board together with Faircoop Belgium – was to bring dairy farmers, the retail trade, consumers and politicians together and draw attention to the importance of fairly produced milk.
<G-vec00169-001-s329><draw.hinweisen><de> Die Veranstalter - das European Milk Board gemeinsam mit Faircoop Belgien - wollten Milcherzeuger, Einzelhandel, Konsumenten und Politiker zusammenbringen und auf die Bedeutung einer fair produzierten Milch hinweisen.
<G-vec00169-001-s330><draw.hinweisen><en> When conveniently placed at a central location – for example on a main road – the dealers can draw attention to their event.
<G-vec00169-001-s330><draw.hinweisen><de> An zentraler Stelle angebracht – zum Beispiel an einer Hauptverkehrsstraße – können die Händler aufmerksamkeitswirksam auf ihr Event hinweisen.
<G-vec00169-001-s331><draw.hinweisen><en> I-Cell, as a telematics service provider on the road passenger transport and freight market, considers the continuous development of safety and accident prevention as priority, besides, we would like to draw the attention to the fact, that the self-sacrificing heroism is one the greatest human value and it deserves the recognition of the widest strata of the society.
<G-vec00169-001-s331><draw.hinweisen><de> i-Cell Kft, als Telematik-Dienstleister auf dem Gebiet von Personenstraßenverkehr und von Straßengüterverkehr, betrachtet die kontinuierliche Weiterentwickung der Sicherheit und der Unfallprävention als Priorität, darüber hinaus möchten wir auch darauf hinweisen, dass das aufopfernde Heldentum einer der größten menschlichen Wert ist und es verdient die Anerkennung der breitesten Schichten der Gesellschaft.
<G-vec00169-001-s332><draw.hinweisen><en> I want to highlight the current position of the industry, to draw attention to problems and to represent the interests of the industry.
<G-vec00169-001-s332><draw.hinweisen><de> Ich möchte den Ist-Zustand der Industrie aufzeigen, auf Probleme hinweisen und die Interessen der Industrie vertreten.
<G-vec00169-001-s333><draw.hinweisen><en> A collage of 4,000 portraits has even made it to the North Pole. The group responsible for this wanted to draw attention to the environmental damage done to the Arctic.
<G-vec00169-001-s333><draw.hinweisen><de> Eine Collage aus 4000 Porträts hat es an den Nordpol geschafft, die dafür verantwortliche Gruppe wollte auf die Umweltzerstörung in der Arktis hinweisen.
<G-vec00169-001-s334><draw.hinweisen><en> However, we would like to draw your attention to one particular aspect, which we have realized is frequently overlooked. This aspect concerns the scope of applicability of the Regulation.
<G-vec00169-001-s334><draw.hinweisen><de> Auf einen Aspekt, der den Anwendungsbereich der Verordnung betrifft, möchten wir dennoch besonders hinweisen, da wir feststellen, dass dieser häufig verkannt wird.
<G-vec00169-001-s335><draw.hinweisen><en> The “TO DO Award Human Rights in Tourism“ is meant to draw the attention of political decision-makers, business players, and target groups from this sector to the relevance of human rights in their context and to contribute to reflections on the respective problems and issues.
<G-vec00169-001-s335><draw.hinweisen><de> Der „TO DO Award Human Rights in Tourism“ soll politisch Verantwortliche, wirtschaftlich Handelnde und Zielgruppen aus diesem Bereich auf die menschenrechtliche Relevanz ihres Tuns hinweisen und zur Reflexion entsprechender Fragestellungen und Problemlagen beitragen.
<G-vec00169-001-s336><draw.hinweisen><en> However, you humans only have eyes for the world, you give the world your every attention but fail to think of Me, and irritably you shrug everything off what could draw your attention to Me and the end....
<G-vec00169-001-s336><draw.hinweisen><de> Ihr Menschen aber sehet nur die Welt, ihr schenket der Welt alle Aufmerksamkeit, an Mich aber denket ihr nicht, und unmutig werfet ihr alles von euch, was hinweisen konnte auf Mich und auf das Ende....
<G-vec00169-001-s337><draw.hinweisen><en> As soon as you have gained the conviction that all My Words are given with love, that they merely draw attention to love, you will also have to recognise their origin, you will have to regard My Word as the outpouring of Myself, as a work of love for the sinful human race in order to provide it with help.
<G-vec00169-001-s337><draw.hinweisen><de> Sowie ihr einmal die Überzeugung gewonnen habt, daß alle Meine Worte in Liebe gegeben sind, daß sie nur zur Liebe hinweisen, müsset ihr auch den Ursprung erkennen, ihr müsset Mein Wort als Ausfluß Meiner Selbst ansehen, als Liebeswirken an der sündigen Menschheit, um ihr Hilfe zu bringen.
<G-vec00169-001-s338><draw.hinweisen><en> Here we would like to draw your attention to ourÂ events Â .
<G-vec00169-001-s338><draw.hinweisen><de> Hier möchten wir insbesondere auf unsere Veranstaltungen hinweisen.
<G-vec00169-001-s339><draw.hinweisen><en> Before you contact us, we would like to draw your attention to the fact that, under the provisions of the Stock Exchange Act, we may not provide any information with regard to an ongoing proceeding.
<G-vec00169-001-s339><draw.hinweisen><de> Bevor Sie uns kontaktieren, möchten wir Sie darauf hinweisen, dass wir aufgrund der Bestimmungen des Börsengeset-zes keine Auskunft über laufende Verfahren geben dürfen.
<G-vec00169-001-s340><draw.hinweisen><en> We would like to draw your attention to our special promotion .
<G-vec00169-001-s340><draw.hinweisen><de> Besonders hinweisen möchten wir Sie noch auf unsere Sonderaktion .
<G-vec00169-001-s341><draw.hinweisen><en> In any case, I can provide testimonials and recommendations and also draw their attention to advertisements and programmes.
<G-vec00169-001-s341><draw.hinweisen><de> In jedem Fall kann ich Gutachten und Empfehlungen schreiben und sie auf Ausschreibungen und Programme hinweisen.
<G-vec00169-001-s342><draw.kommen><en> The twelve draw closer to feast—Edgar first, catching the blood in a silver goblet before drinking it.
<G-vec00169-001-s342><draw.kommen><de> Die Zwölf kommen näher, um sich zu laben – zuerst Edgar, der das Blut in einem silbernen Kelch auffängt, ehe er es trinkt.
<G-vec00169-001-s343><draw.kommen><en> These are behavioral patterns that are only too familiar to Historical Revisionists and explain why Nick Cook found it difficult to draw a technical expert into conversation, since in such matters they shun the media like the devil shuns holy water. Podkletnov's experiments,[3]
<G-vec00169-001-s343><draw.kommen><de> Das sind Verhaltensweisen, wie sie den historischen Revisionisten nur zu bekannt sind, und die erklären, warum es Nick Cook so schwer fällt, mit den Experten überhaupt ins Gespräch zu kommen, die in diesen Dingen die Medien scheuen wie der Teufel das Weihwasser.
<G-vec00169-001-s344><draw.kommen><en> These are behavioral patterns that are only too familiar to Historical Revisionists and explain why Nick Cook found it difficult to draw a technical expert into conversation, since in such matters they shun the media like the devil shuns holy water.
<G-vec00169-001-s344><draw.kommen><de> Das sind Verhaltensweisen, wie sie den historischen Revisionisten nur zu bekannt sind, und die erklären, warum es Nick Cook so schwer fällt, mit den Experten überhaupt ins Gespräch zu kommen, die in diesen Dingen die Medien scheuen wie der Teufel das Weihwasser.
<G-vec00169-001-s345><draw.kommen><en> campaign is to draw attention to inner-city traffic and to start a dialogue with interested citizens.
<G-vec00169-001-s345><draw.kommen><de> ist es, Aufmerksamkeit für den Verkehr in der Stadt zu wecken und mit interessierten Bürgern ins Gespräch zu kommen.
<G-vec00169-001-s346><draw.kommen><en> Thus they recognize God through these qualities of beauty and seek to draw close to Him through beautiful words, deeds and attitudes.
<G-vec00169-001-s346><draw.kommen><de> So erkennen sie Gott durch diese Eigenschaften der Schönheit an, und versuchen, Ihm durch schöne Worte, Taten und Eigenschaften näher zu kommen.
<G-vec00169-001-s347><draw.kommen><en> The prayer, the liturgy, and the icon developed from the desire to experience God and draw close to Him.
<G-vec00169-001-s347><draw.kommen><de> Aus dem Verlangen Gott zu erleben und zu ihm zu kommen, ist das Gebet, die Liturgie und die Ikone entstanden.
<G-vec00169-001-s348><draw.kommen><en> I also feel that should this event occur again it will draw to an ultimate conclusion.
<G-vec00169-001-s348><draw.kommen><de> Ich fühle auch dass wenn dieses Ereignis nochmals auftreten sollte es zu einem endgültigen Abschluss kommen wird.
<G-vec00169-001-s349><draw.kommen><en> The Stevens' Inquiry's terms of reference were so narrow that it is reasonable to draw the conclusion that those who designed them sought to prevent information from emerging as opposed to constructing a process for full and proper disclosure.
<G-vec00169-001-s349><draw.kommen><de> Der Arbeitsauftrag der Stevens-Untersuchung war so eng abgefasst, dass es keineswegs abwegig erscheint zu dem Schluss zu kommen, dass die Auftraggeber damit zu verhindern suchten, dass Informationen ans Licht kommen - was in krassem Gegensatz zum beabsichtigten Prozess hin zu einer restlosen und wahrheitsgemäßen Aufklärung steht.
<G-vec00169-001-s350><draw.kommen><en> To develop an even better common understanding and draw concrete conclusions.
<G-vec00169-001-s350><draw.kommen><de> Ein noch besseres gemeinsames Verständnis entwickeln und auch konkret zu Konsequenzen kommen.
<G-vec00169-001-s351><draw.kommen><en> In this sense we have been saved, and can draw near to the Father.
<G-vec00169-001-s351><draw.kommen><de> In diesem Sinn sind wir errettet worden und können nahe zum Vater kommen.
<G-vec00169-001-s352><draw.kommen><en> The conclusion that we wish to draw is that the criteria which we must use as a basis to judge the efficiency of the communist parties must be quite different from an a posteriori estimate of their numerical forces as compared with those of the other parties which claim to represent the proletariat.
<G-vec00169-001-s352><draw.kommen><de> Wir kommen daher zu dem Schluss, dass die Kriterien, die Schlagkraft der kommunistischen Parteien zu beurteilen, ganz andere sein müssen, als „a posteriori“ ihre Mitgliederzahl mit der der anderen Parteien zu vergleichen.
<G-vec00169-001-s353><draw.kommen><en> The major challenge is to draw conclusions about extensive areas based on small-scale measurements.
<G-vec00169-001-s353><draw.kommen><de> Die große Herausforderung ist, von kleinräumigen Messungen aus zu Aussagen über ein großräumiges Gebiet zu kommen.
<G-vec00169-001-s354><draw.kommen><en> We ask you to KNOW that we consider you all to be part of our family and as we draw closer in this way... it seems that our connection with more and more of you is made more easily viable.
<G-vec00169-001-s354><draw.kommen><de> Wir bitten euch, zu WISSEN, dass wir euch alle als Teil unserer Familie sehen und indem wir uns auf diese Weise näher kommen... scheint unsere Verbindung mit immer mehr von euch leichter realisierbar zu sein.
<G-vec00169-001-s355><draw.kommen><en> For the analysis of dynamic networks the researchers draw upon methods from various disciplines, such as biology, physics or the social sciences.
<G-vec00169-001-s355><draw.kommen><de> Um dynamische Netzwerke analysieren zu können, kommen Methoden aus unterschiedlichen Disziplinen wie der Biologie, der Physik oder den Sozialwissenschaften zum Einsatz.
<G-vec00169-001-s356><draw.kommen><en> We ask now with your permission for White Cloud to draw close and we ask too that this channeling is given with ease, truth and clarity to assist us all as we walk this time upon life's journey.
<G-vec00169-001-s356><draw.kommen><de> Wir bitten nun, mit Deiner Erlaubnis, White Cloud näher zu kommen, und wir bitten auch, dass diese Durchgabe mit Leichtigkeit, Wahrheit und Klarheit uns allen gegeben wird, zur Unterstützung auf unserer jetzigen Lebensreise.
<G-vec00169-001-s357><draw.kommen><en> Overall, the cost advantage German universities offer over universities in the USA, the UK, and Australia is the main draw for most students heading to Germany.
<G-vec00169-001-s357><draw.kommen><de> Die Hauptmotivation der meisten Studierenden, nach Deutschland zu kommen, ist jedoch der Kostenvorteil deutscher Universitäten gegenÃ1⁄4ber Hochschulen in den USA, Großbritannien und Australien.
<G-vec00169-001-s358><draw.kommen><en> The authors draw the conclusion that the potential inherent in the economic analysis has not been fully exploited yet.
<G-vec00169-001-s358><draw.kommen><de> Die Autoren kommen zu dem Schluss, dass das Potenzial der wirtschaftlichen Analyse bislang noch nicht ausgereizt wurde.
<G-vec00169-001-s359><draw.kommen><en> "This may not seem like much at first but then reflect upon the following narration: ""On the Day of Resurrection, the sun would draw so close to the people that there would be left a distance of only one mile."
<G-vec00169-001-s359><draw.kommen><de> "Das mag zunächst nicht sehr viel scheinen, denke jedoch über folgenden Bericht nach: ""Am Tag der Auferstehung wird die Sonne den Menschen so nahe kommen, dass nur noch eine Meile Abstand zu ihnen bleibt."
<G-vec00169-001-s360><draw.kommen><en> Under conditions of crisis the bourgeois will eventually draw the conclusion: there is too much disorder, too much chaos, too many strikes and demonstrations.
<G-vec00169-001-s360><draw.kommen><de> Unter den Bedingungen der Krise werden die Bürgerlichen schlussendlich zu der Schlussfolgerung kommen, dass es zu viel Unordnung, Chaos, Streiks und Demos gibt.
<G-vec00169-001-s361><draw.lenken><en> However, spiritual disciples are advised not to pay much attention to black magic in order not to draw energy to it.
<G-vec00169-001-s361><draw.lenken><de> Spirituellen Schülern wird jedoch geraten, schwarzer Magie nicht viel Aufmerksamkeit zu schenken, um keine Energie darauf zu lenken.
<G-vec00169-001-s362><draw.lenken><en> Be determined not to draw the attention of yourself and others to the earthen vessels, but unto the mighty treasure of the Holy Spirit.
<G-vec00169-001-s362><draw.lenken><de> Sei entschlossen, deine Aufmerksamkeit und die der anderen nicht auf die irdenen Gefäße zu lenken, sondern auf den mächtigen Schatz des Heiligen Geistes.
<G-vec00169-001-s363><draw.lenken><en> Information columns draw attention to architecture, craftsmanship, the cultur­al landscape and culinary specialities.
<G-vec00169-001-s363><draw.lenken><de> Infostelen lenken die Aufmerk­ samkeit auf Architektur, Handwerk, die Kulturland­schaft und kulinarische Besonderheiten.
<G-vec00169-001-s364><draw.lenken><en> My visit is also meant to draw attention to Africa as a whole, its promise, its hopes, its struggles and its achievements.
<G-vec00169-001-s364><draw.lenken><de> Mein Besuch hat auch den Sinn, die Aufmerksamkeit auf Afrika als Ganzes, auf seine Aussichten, seine Hoffnungen, sein Ringen und seine Leistungen zu lenken.
<G-vec00169-001-s365><draw.lenken><en> The horizontal lines draw focus to the width of the chair, while the details around the armrests and on the front lighten the expression.
<G-vec00169-001-s365><draw.lenken><de> Die horizontalen Linien lenken den Fokus zwar auf die Breite des Sessels, aber die feinen Details an den Armlehnen und der Vorderseite garantieren die nötige Leichtigkeit.
<G-vec00169-001-s366><draw.lenken><en> By designating Jesus as Rabbi, the Gospel could draw attention to its own special status, first, by marking its content as the Rabbi's authoritative interpretation of the divine will to its readers, and, second, by signalling that, like the sermons or teachings of other authoritative Jewish teachers or masters, it should be encountered by the community in the context of a regular liturgical gathering.
<G-vec00169-001-s366><draw.lenken><de> Indem das Evangelium Jesus als Rabbi konzipiert, könnte es die Aufmerksamkeit auf seinen eigenen besonderen Status lenken, und zwar erstens, indem es den Lesern seinen Inhalt als des Rabbis autoritative Auslegung des göttlichen Willens vorstellt, und zweitens, indem es anzeigt, dass es – wie die Predigten und Lehren anderer jüdischer Lehrer oder Meister – von der Gemeinde im Kontext regelmäßiger liturgischer Versammlungen gebraucht werden soll.
<G-vec00169-001-s367><draw.lenken><en> Set up your display along the central walking paths and draw the attention of the visitors to your free brochures.
<G-vec00169-001-s367><draw.lenken><de> Stellen Sie Ihr Prospektdisplay entlang der zentralen Laufwege auf und lenken Sie die Blicke der Besucher auf Ihre kostenlose Prospekte zum Mitnehmen.
<G-vec00169-001-s368><draw.lenken><en> It's good that you care, publicity has a lot of power to draw attention to things.
<G-vec00169-001-s368><draw.lenken><de> Publicity hat große Macht um Aufmerksamkeit auf diese Dinge zu lenken.
<G-vec00169-001-s369><draw.lenken><en> They tell stories, draw attention to the special and present their cultures, arts, crafts and messages.
<G-vec00169-001-s369><draw.lenken><de> Wir erzählen Geschichten, lenken den Blick auch auf Verborgenes in den Kiezen, stellen Kulturen und Künste vor, transportieren Botschaften und Themen.
<G-vec00169-001-s370><draw.lenken><en> He underscores this by showing the video tape played backwards and without sound on a monitor in the lobby of the Secession: the irritating way of presenting the film, with a storyline that one cannot follow this way, is to draw our attention to the type of film instead of the narrative.
<G-vec00169-001-s370><draw.lenken><de> Das unterstreicht McCarthy auch mit dem rückwärts abgespielten Videoband auf dem Monitor im Foyer der Secession, das ohne Ton und mit der irritierenden und die Geschichte nicht nachvollziehbar machenden Abspielmethode unsere Aufmerksamkeit auf die Art des Films und nicht auf seine Erzählung lenken soll.
<G-vec00169-001-s371><draw.lenken><en> Learning Chinese will provide you with an excellent chance to get a step ahead and draw the attention of future employers.
<G-vec00169-001-s371><draw.lenken><de> Chinesisch zu lernen ist daher eine exzellente Chance einen Schritt voraus zu sein und die Aufmerksamkeit Ihres potenziellen, zukünftigen Arbeitgebers auf Sie zu lenken.
<G-vec00169-001-s372><draw.lenken><en> Avoid graphics that draw more attention to themselves than the data.
<G-vec00169-001-s372><draw.lenken><de> Vermeiden Sie graphische Darstellungen, die mehr Aufmerksamkeit auf sich selbst lenken als auf die Daten.
<G-vec00169-001-s373><draw.lenken><en> As discussed above, colors and patterns can draw the attention of those around you.
<G-vec00169-001-s373><draw.lenken><de> Wie oben besprochen, können Farben und Muster die Aufmerksamkeit von den dich umgebenden Menschen lenken.
<G-vec00169-001-s374><draw.lenken><en> The songs are inspired by many different things that I have felt or seen and want to draw attention to/share a message about.
<G-vec00169-001-s374><draw.lenken><de> Die Songs sind von vielen verschiedenen Dingen inspiriert, die ich gefühlt oder gesehen habe und Aufmerksamkeit darauf lenken und/oder eine Nachricht darüber verbreiten will.
<G-vec00169-001-s375><draw.lenken><en> Your efforts to draw attention to this unprecedented persecution are essential for the fight against this persecution.
<G-vec00169-001-s375><draw.lenken><de> Ihre Bemühungen, die Aufmerksamkeit auf diese beispiellose Verfolgung zu lenken, sind essentiell für den Widerstand gegen diese Verfolgung.
<G-vec00169-001-s376><draw.lenken><en> The miracle is narrated by John in just two verses, because the Evangelist does not want to draw attention to the miracle itself, but rather to what follows, to the discussions it arouses, also to the gossip.
<G-vec00169-001-s376><draw.lenken><de> Das Wunder wird von Johannes in zwei knappen Versen erzählt, da der Evangelist die Aufmerksamkeit nicht auf das Wunder an sich, sondern auf das lenken will, was nachher geschieht, auf die Diskussionen, die es hervorruft; aber auch auf das Gerede.
<G-vec00169-001-s377><draw.lenken><en> The performance by David Tudor, expressly named as exemplary by Cage, saw the pianist open the piano's lid in order to draw the audience's attention.
<G-vec00169-001-s377><draw.lenken><de> Die von Cage ausdrücklich als beispielhaft erwähnte Aufführung David Tudors beschreibt einen Pianisten, der den Klavierdeckel öffnet, um die Aufmerksamkeit zu lenken.
<G-vec00169-001-s378><draw.lenken><en> The letter states the following: The Frente POLISARIO also wishes to draw attention to the ongoing illegal exploration and exploitation of the natural resources of Western Sahara.
<G-vec00169-001-s378><draw.lenken><de> Die Frente Polisario will auch die Aufmerksamkeit auf die andauernde illegale Erforschung und Ausbeutung der natürlichen Ressourcen der Westsahara lenken.
<G-vec00169-001-s379><draw.lenken><en> The prize aims to draw public attention to sustainable laws and policies.
<G-vec00169-001-s379><draw.lenken><de> Ziel des Preises ist es, die öffentliche Aufmerksamkeit auf nachhaltige Gesetze und Maßnahmen zu lenken.
<G-vec00042-001-s380><draw.locken><en> The whole biathlon community is engrossed in the competition of the best teams and athletes, and an attractive supporting programme and festivities draw visitors and guests from Italy and abroad.
<G-vec00042-001-s380><draw.locken><de> Ein ganzes „Biathlon-Dorf“ fiebert mit den besten Mannschaften und Athleten mit, ein reichliches Rahmenprogramm und grandiose Festlichkeiten locken Besucher und Gäste aus dem In- und Ausland.
<G-vec00042-001-s381><draw.locken><en> Inside the cell they destroy the intruders and use chemical messenger substances to draw further immune cells into the source of infection .
<G-vec00042-001-s381><draw.locken><de> Im Zellinneren zerstören sie die Eindringlinge und locken mit chemischen Botenstoffen weitere Immunzellen an den Infektionsherd .
<G-vec00042-001-s382><draw.locken><en> The colorful flower fields and Keukenhof, the world's biggest flower park, are an important attraction that draw thousands of tourists every year.
<G-vec00042-001-s382><draw.locken><de> Die farbenprächtigen Blumenfelder und Keukenhof, der größte Blumenpark der Welt, sind eine einzigartige Attraktion, und locken alljährlich unzählige Touristen an.
<G-vec00042-001-s383><draw.locken><en> For Yosemite National Park the many waterfalls are what draw millions of visitors to the park each year.
<G-vec00042-001-s383><draw.locken><de> Im Yosemite Nationalpark locken die zahlreichen Wasserfälle jedes Jahr Millionen von Besuchern an.
<G-vec00042-001-s384><draw.locken><en> The elector of Saxony was urged by his councilors not to appear at the Diet. The emperor, they said, required the attendance of the princes in order to draw them into a snare.
<G-vec00042-001-s384><draw.locken><de> Der Kurfürst von Sachsen wurde von seinen Räten gedrängt, nicht auf dem Reichstag zu erscheinen; denn der Kaiser verlange nur die Anwesenheit der Fürsten, um sie in eine Falle zu locken.
<G-vec00042-001-s385><draw.locken><en> Aromatic coffee specialities, homemade tortes and cakes as well as fine dishes draw the guests as much as the adjacent flower shop.
<G-vec00042-001-s385><draw.locken><de> Duftende Kaffeespezialitäten, hausgemachte Torten und Kuchen sowie das feine Speiseangebot locken die Gäste ebenso wie der angrenzende Blumenladen.
<G-vec00042-001-s386><draw.locken><en> Good music and glitzy décor draw a mixed crowd to this out-of-town club.
<G-vec00042-001-s386><draw.locken><de> Gute Musik und ein glamouröses Design locken ein gemischtes Publikum in diesen größten Club der Stadt.
<G-vec00042-001-s387><draw.locken><en> The Cooper River Bridge Run and other annual events also draw travelers from around the country.
<G-vec00042-001-s387><draw.locken><de> Auch der Cooper River Bridge Run und andere Veranstaltungen locken jedes Jahr Besucher aus dem ganzen Land an.
<G-vec00042-001-s388><draw.locken><en> Each year, the research centre’s unique facilities draw more than 3000 guest scientists from over 40 countries to Hamburg.
<G-vec00042-001-s388><draw.locken><de> Die weltweit einzigartigen Anlagen des Forschungszentrums locken jedes Jahr mehr als 3000 Gastwissenschaftler aus über 40 Nationen nach Hamburg.
<G-vec00042-001-s389><draw.locken><en> Traditional concerts with wind ensembles from surrounding communities, performances by folk dance groups, and shows by visiting bands draw visitors from near and far to the town center of Lienz, and to countless terrace cafes.
<G-vec00042-001-s389><draw.locken><de> Traditionelle Konzerte von Blasmusikkapellen aus der Umgebung, Auftritte von Volkstanzgruppen oder Darbietungen verschiedenster Bands locken Besucher aus nah und fern in das Stadtzentrum von Lienz und in die unzähligen Terrassencafés.
<G-vec00042-001-s390><draw.locken><en> Outdoor concerts draw serious big names - think Lady Gaga and Bruno Mars during summer.
<G-vec00042-001-s390><draw.locken><de> Im Sommer locken Freiluftkonzerte große Namen wie Lady Gaga und Bruno Mars an.
<G-vec00042-001-s391><draw.locken><en> Grindelwald Bern The Jungfraujoch, the area around the Aletsch Glacier and the infamous north face of the Eiger draw visitors from around the world to the Bernese Oberland every year.
<G-vec00042-001-s391><draw.locken><de> Grindelwald Bern Das Jungfrau-Joch, die Gegend um den Aletsch-Gletscher und die berÃ1⁄4hmt-berÃ1⁄4chtigte Eigernordwand locken jedes Jahr Besucher aus aller Welt ins Berner Oberland.
<G-vec00042-001-s392><draw.locken><en> Fresh wounds and the scent of blood often draw out the scavengers to finish the job.
<G-vec00042-001-s392><draw.locken><de> Frische Wunden und der Geruch von Blut locken oft Aasfresser an, die die Sache zu Ende bringen.
<G-vec00042-001-s393><draw.locken><en> DangerTV posts short clips on its social media accounts, including Facebook and Instagram, to draw viewers to its site.
<G-vec00042-001-s393><draw.locken><de> DangerTV veröffentlicht auf seinen Social-Media-Konten wie Facebook und Instagram kurze Clips, um Zuschauer auf ihre Website zu locken.
<G-vec00042-001-s394><draw.locken><en> —We’ll just have to draw him up there, then push him in.
<G-vec00042-001-s394><draw.locken><de> „Wir müssen ihn nur nach oben locken und ihn dann dorthin schleudern.
<G-vec00042-001-s395><draw.locken><en> In the evenings the bright promises from across the world draw people to the television.
<G-vec00042-001-s395><draw.locken><de> Abends locken die bunten Verheißungen aus aller Welt vor das TV-Kastl.
<G-vec00042-001-s396><draw.locken><en> Zermatt's proud and closely guarded mountain guiding culture reflects the character of the challenging peaks that draw adventurous tourists.
<G-vec00042-001-s396><draw.locken><de> Zermatts stolze und streng gehütete Bergführer-Kultur spiegelt den Charakter der Gipfel, die abenteuerlustige Touristen ins Tal locken.
<G-vec00042-001-s397><draw.locken><en> Outdoor concerts draw serious big names—think Lady Gaga and Bruno Mars—during summer.
<G-vec00042-001-s397><draw.locken><de> Im Sommer locken Freiluftkonzerte große Namen wie Lady Gaga und Bruno Mars an.
<G-vec00042-001-s398><draw.locken><en> There's plenty of sunshine here: Over 12 hours of sun a day draw visitors to Side, Alanya, Kemer and Antalya, for example.
<G-vec00042-001-s398><draw.locken><de> Hier gibt es Sonne satt: Über 12 Sonnenstunden pro Tag locken im Sommer zum Beispiel nach Side, Alanya, Kemer und Antalya .
<G-vec00169-001-s380><draw.locken><en> The whole biathlon community is engrossed in the competition of the best teams and athletes, and an attractive supporting programme and festivities draw visitors and guests from Italy and abroad.
<G-vec00169-001-s380><draw.locken><de> Ein ganzes „Biathlon-Dorf“ fiebert mit den besten Mannschaften und Athleten mit, ein reichliches Rahmenprogramm und grandiose Festlichkeiten locken Besucher und Gäste aus dem In- und Ausland.
<G-vec00169-001-s381><draw.locken><en> Inside the cell they destroy the intruders and use chemical messenger substances to draw further immune cells into the source of infection .
<G-vec00169-001-s381><draw.locken><de> Im Zellinneren zerstören sie die Eindringlinge und locken mit chemischen Botenstoffen weitere Immunzellen an den Infektionsherd .
<G-vec00169-001-s382><draw.locken><en> The colorful flower fields and Keukenhof, the world's biggest flower park, are an important attraction that draw thousands of tourists every year.
<G-vec00169-001-s382><draw.locken><de> Die farbenprächtigen Blumenfelder und Keukenhof, der größte Blumenpark der Welt, sind eine einzigartige Attraktion, und locken alljährlich unzählige Touristen an.
<G-vec00169-001-s383><draw.locken><en> For Yosemite National Park the many waterfalls are what draw millions of visitors to the park each year.
<G-vec00169-001-s383><draw.locken><de> Im Yosemite Nationalpark locken die zahlreichen Wasserfälle jedes Jahr Millionen von Besuchern an.
<G-vec00169-001-s384><draw.locken><en> The elector of Saxony was urged by his councilors not to appear at the Diet. The emperor, they said, required the attendance of the princes in order to draw them into a snare.
<G-vec00169-001-s384><draw.locken><de> Der Kurfürst von Sachsen wurde von seinen Räten gedrängt, nicht auf dem Reichstag zu erscheinen; denn der Kaiser verlange nur die Anwesenheit der Fürsten, um sie in eine Falle zu locken.
<G-vec00169-001-s385><draw.locken><en> Aromatic coffee specialities, homemade tortes and cakes as well as fine dishes draw the guests as much as the adjacent flower shop.
<G-vec00169-001-s385><draw.locken><de> Duftende Kaffeespezialitäten, hausgemachte Torten und Kuchen sowie das feine Speiseangebot locken die Gäste ebenso wie der angrenzende Blumenladen.
<G-vec00169-001-s386><draw.locken><en> Good music and glitzy décor draw a mixed crowd to this out-of-town club.
<G-vec00169-001-s386><draw.locken><de> Gute Musik und ein glamouröses Design locken ein gemischtes Publikum in diesen größten Club der Stadt.
<G-vec00169-001-s387><draw.locken><en> The Cooper River Bridge Run and other annual events also draw travelers from around the country.
<G-vec00169-001-s387><draw.locken><de> Auch der Cooper River Bridge Run und andere Veranstaltungen locken jedes Jahr Besucher aus dem ganzen Land an.
<G-vec00169-001-s388><draw.locken><en> Each year, the research centre’s unique facilities draw more than 3000 guest scientists from over 40 countries to Hamburg.
<G-vec00169-001-s388><draw.locken><de> Die weltweit einzigartigen Anlagen des Forschungszentrums locken jedes Jahr mehr als 3000 Gastwissenschaftler aus über 40 Nationen nach Hamburg.
<G-vec00169-001-s389><draw.locken><en> Traditional concerts with wind ensembles from surrounding communities, performances by folk dance groups, and shows by visiting bands draw visitors from near and far to the town center of Lienz, and to countless terrace cafes.
<G-vec00169-001-s389><draw.locken><de> Traditionelle Konzerte von Blasmusikkapellen aus der Umgebung, Auftritte von Volkstanzgruppen oder Darbietungen verschiedenster Bands locken Besucher aus nah und fern in das Stadtzentrum von Lienz und in die unzähligen Terrassencafés.
<G-vec00169-001-s390><draw.locken><en> Outdoor concerts draw serious big names - think Lady Gaga and Bruno Mars during summer.
<G-vec00169-001-s390><draw.locken><de> Im Sommer locken Freiluftkonzerte große Namen wie Lady Gaga und Bruno Mars an.
<G-vec00169-001-s391><draw.locken><en> Grindelwald Bern The Jungfraujoch, the area around the Aletsch Glacier and the infamous north face of the Eiger draw visitors from around the world to the Bernese Oberland every year.
<G-vec00169-001-s391><draw.locken><de> Grindelwald Bern Das Jungfrau-Joch, die Gegend um den Aletsch-Gletscher und die berÃ1⁄4hmt-berÃ1⁄4chtigte Eigernordwand locken jedes Jahr Besucher aus aller Welt ins Berner Oberland.
<G-vec00169-001-s392><draw.locken><en> Fresh wounds and the scent of blood often draw out the scavengers to finish the job.
<G-vec00169-001-s392><draw.locken><de> Frische Wunden und der Geruch von Blut locken oft Aasfresser an, die die Sache zu Ende bringen.
<G-vec00169-001-s393><draw.locken><en> DangerTV posts short clips on its social media accounts, including Facebook and Instagram, to draw viewers to its site.
<G-vec00169-001-s393><draw.locken><de> DangerTV veröffentlicht auf seinen Social-Media-Konten wie Facebook und Instagram kurze Clips, um Zuschauer auf ihre Website zu locken.
<G-vec00169-001-s394><draw.locken><en> —We’ll just have to draw him up there, then push him in.
<G-vec00169-001-s394><draw.locken><de> „Wir müssen ihn nur nach oben locken und ihn dann dorthin schleudern.
<G-vec00169-001-s395><draw.locken><en> In the evenings the bright promises from across the world draw people to the television.
<G-vec00169-001-s395><draw.locken><de> Abends locken die bunten Verheißungen aus aller Welt vor das TV-Kastl.
<G-vec00169-001-s396><draw.locken><en> Zermatt's proud and closely guarded mountain guiding culture reflects the character of the challenging peaks that draw adventurous tourists.
<G-vec00169-001-s396><draw.locken><de> Zermatts stolze und streng gehütete Bergführer-Kultur spiegelt den Charakter der Gipfel, die abenteuerlustige Touristen ins Tal locken.
<G-vec00169-001-s397><draw.locken><en> Outdoor concerts draw serious big names—think Lady Gaga and Bruno Mars—during summer.
<G-vec00169-001-s397><draw.locken><de> Im Sommer locken Freiluftkonzerte große Namen wie Lady Gaga und Bruno Mars an.
<G-vec00169-001-s398><draw.locken><en> There's plenty of sunshine here: Over 12 hours of sun a day draw visitors to Side, Alanya, Kemer and Antalya, for example.
<G-vec00169-001-s398><draw.locken><de> Hier gibt es Sonne satt: Über 12 Sonnenstunden pro Tag locken im Sommer zum Beispiel nach Side, Alanya, Kemer und Antalya .
<G-vec00042-001-s418><draw.malen><en> In the Himmelswerkstadt children don shimmering robes and golden wings to become little angels who bake, draw and make models.
<G-vec00042-001-s418><draw.malen><de> In schimmernden Gewändern mit goldenen Flügeln verwandeln sich die Kinder in der Himmelswerkstadt zu kleinen Engeln beim Backen, Malen und Basteln.
<G-vec00042-001-s419><draw.malen><en> He/she can draw well.
<G-vec00042-001-s419><draw.malen><de> Er/sie kann gut malen.
<G-vec00042-001-s420><draw.malen><en> Many of them draw for the first time in their life and through this medium, they express all their hidden pain.
<G-vec00042-001-s420><draw.malen><de> Viele von ihnen malen zum ersten Mal in ihrem Leben, und durch dieses Medium drücken sie ihr ganzes verborgenes Leid aus.
<G-vec00042-001-s421><draw.malen><en> We have increased the staff, that draw on outside contractors when there was too much work.
<G-vec00042-001-s421><draw.malen><de> Wir haben die Mitarbeiter erhöht, dass Malen Fremdfirmen, wenn es zu viel Arbeit.
<G-vec00042-001-s422><draw.malen><en> The artistic treatment is to draw many lanterns, representing millions and millions of Dafa practitioners' hearts.
<G-vec00042-001-s422><draw.malen><de> Die künstlerische Aufbereitung ist, viele Kerzenlampen zu malen, welche bildlich Millionen und Abermillionen Herzen der Dafa Praktizierenden verkörpern.
<G-vec00042-001-s423><draw.malen><en> It is easier to learn how to draw and sketch than to learn how to read and write.
<G-vec00042-001-s423><draw.malen><de> Malen und zeichnen zu lernen ist leichter als Lesen und Schreiben.
<G-vec00042-001-s424><draw.malen><en> In a dark room Liu let his friends draw their fears on photographic paper.
<G-vec00042-001-s424><draw.malen><de> In einer Dunkelkammer ließ Liu seine Probanden ihre Ängste aufs Fotopapier malen.
<G-vec00042-001-s425><draw.malen><en> Kids from 2 years can play, draw, colour, do arts and crafts and of cause play inside and outside of our Villa Bambini.
<G-vec00042-001-s425><draw.malen><de> Kinder ab 2 Jahren können dann in der Villa Bambini spielen, malen, basteln und natürlich bei schönem Wetter auch draußen gemeinsam Spiele machen.
<G-vec00042-001-s426><draw.malen><en> This time, it’s important for him to draw the earth, the tulip is grown in.
<G-vec00042-001-s426><draw.malen><de> Hier ist es ihm wichtig, auch die Erde zu malen, in der die Tulpe wächst.
<G-vec00042-001-s427><draw.malen><en> Watch that children do not have an opportunity to draw on your tests with pen.
<G-vec00042-001-s427><draw.malen><de> Man sollte aufpassen, dass Kinder nicht die Gelegenheit haben, mit einem Kugelschreiber auf den Testen zu malen.
<G-vec00042-001-s428><draw.malen><en> It's not easy to draw pictures there and to make them appear.
<G-vec00042-001-s428><draw.malen><de> Es ist nicht leicht Bilder dort zu malen und diese zum Erscheinen zu bringen.
<G-vec00042-001-s429><draw.malen><en> She develops a metaphorical language based on the semantic of objects, sounds and movements; letting the images draw emotions in space.
<G-vec00042-001-s429><draw.malen><de> Sie entwickelt eine metaphorische Sprache, die auf der Bedeutung der Objekte, Geräusche und Bewegungen basiert; die Bilder Emotionen im Raum malen lassen.
<G-vec00042-001-s430><draw.malen><en> We engage with our children, sing songs, go for a walk, do crafting, play, make music and draw so that the children learn to engage themselves in a positive way.
<G-vec00042-001-s430><draw.malen><de> Wir beschäftigen uns mit den Kindern, wir singen Lieder, machen Spaziergänge, basteln, spielen, musizieren und malen, damit die Kinder lernen, sich selbst auf positive Art zu beschäftigen.
<G-vec00042-001-s431><draw.malen><en> The goal was to draw an AKVIS mascot (a horse).
<G-vec00042-001-s431><draw.malen><de> Die Aufgabe bestand darin, das Maskottchen von AKVIS - das Pferd - zu malen.
<G-vec00042-001-s432><draw.malen><en> Two thick felt tip pens with which it will be easy to draw big objects.
<G-vec00042-001-s432><draw.malen><de> Zwei dicke Filzstifte, mit denen man leichter große Sachen malen kann.
<G-vec00042-001-s433><draw.malen><en> Another example can be painting a picture of a deity while making efforts to draw the deity in such a manner that it resembles its actual form.
<G-vec00042-001-s433><draw.malen><de> Ein weiteres Beispiel ist das Malen einer Gottheit, indem man sich bemüht die Gottheit auf einer solchen Art und Weise zu malen, dass es mit ihrer tatsächlichen Form übereinstimmt.
<G-vec00042-001-s434><draw.malen><en> To remove a part of the clone, press the Ctrl-key on Windows / on Mac, and keeping it pressed draw over the area.
<G-vec00042-001-s434><draw.malen><de> Um einen Bereich des Klons zu entfernen, drücken Sie die Strg-Taste auf Windows, oder ⌘ auf Mac und, die Taste gedrückt haltend, malen Sie über den Bereich.
<G-vec00042-001-s435><draw.malen><en> In this way, an educational workshop offers the opportunity to draw, handcraft and experiment.
<G-vec00042-001-s435><draw.malen><de> So bietet eine Bildungswerkstatt die Möglichkeit zum Malen, Werken und Experimentieren.
<G-vec00042-001-s436><draw.malen><en> Nothing but a sound, a tone, an eddy between train and ship, to me, when I suddenly jump from the swing and run to the fence on solid ground, look through it in order to draw a horizon with my eyes, on which a raft is drifting towards me.
<G-vec00042-001-s436><draw.malen><de> Nichts als ein Ton, ein Klang, ein Wirbel zwischen Zug und Schiff, für mich, wenn ich augenblicklich von der Schaukel springe und auf festem Boden zum Zaun laufe, um mit meinen Augen durch ihn hindurch einen Horizont zu malen, auf dem ein Floß auf mich zu treibt.
<G-vec00169-001-s418><draw.malen><en> In the Himmelswerkstadt children don shimmering robes and golden wings to become little angels who bake, draw and make models.
<G-vec00169-001-s418><draw.malen><de> In schimmernden Gewändern mit goldenen Flügeln verwandeln sich die Kinder in der Himmelswerkstadt zu kleinen Engeln beim Backen, Malen und Basteln.
<G-vec00169-001-s419><draw.malen><en> He/she can draw well.
<G-vec00169-001-s419><draw.malen><de> Er/sie kann gut malen.
<G-vec00169-001-s420><draw.malen><en> Many of them draw for the first time in their life and through this medium, they express all their hidden pain.
<G-vec00169-001-s420><draw.malen><de> Viele von ihnen malen zum ersten Mal in ihrem Leben, und durch dieses Medium drücken sie ihr ganzes verborgenes Leid aus.
<G-vec00169-001-s421><draw.malen><en> We have increased the staff, that draw on outside contractors when there was too much work.
<G-vec00169-001-s421><draw.malen><de> Wir haben die Mitarbeiter erhöht, dass Malen Fremdfirmen, wenn es zu viel Arbeit.
<G-vec00169-001-s422><draw.malen><en> The artistic treatment is to draw many lanterns, representing millions and millions of Dafa practitioners' hearts.
<G-vec00169-001-s422><draw.malen><de> Die künstlerische Aufbereitung ist, viele Kerzenlampen zu malen, welche bildlich Millionen und Abermillionen Herzen der Dafa Praktizierenden verkörpern.
<G-vec00169-001-s423><draw.malen><en> It is easier to learn how to draw and sketch than to learn how to read and write.
<G-vec00169-001-s423><draw.malen><de> Malen und zeichnen zu lernen ist leichter als Lesen und Schreiben.
<G-vec00169-001-s424><draw.malen><en> In a dark room Liu let his friends draw their fears on photographic paper.
<G-vec00169-001-s424><draw.malen><de> In einer Dunkelkammer ließ Liu seine Probanden ihre Ängste aufs Fotopapier malen.
<G-vec00169-001-s425><draw.malen><en> Kids from 2 years can play, draw, colour, do arts and crafts and of cause play inside and outside of our Villa Bambini.
<G-vec00169-001-s425><draw.malen><de> Kinder ab 2 Jahren können dann in der Villa Bambini spielen, malen, basteln und natürlich bei schönem Wetter auch draußen gemeinsam Spiele machen.
<G-vec00169-001-s426><draw.malen><en> This time, it’s important for him to draw the earth, the tulip is grown in.
<G-vec00169-001-s426><draw.malen><de> Hier ist es ihm wichtig, auch die Erde zu malen, in der die Tulpe wächst.
<G-vec00169-001-s427><draw.malen><en> Watch that children do not have an opportunity to draw on your tests with pen.
<G-vec00169-001-s427><draw.malen><de> Man sollte aufpassen, dass Kinder nicht die Gelegenheit haben, mit einem Kugelschreiber auf den Testen zu malen.
<G-vec00169-001-s428><draw.malen><en> It's not easy to draw pictures there and to make them appear.
<G-vec00169-001-s428><draw.malen><de> Es ist nicht leicht Bilder dort zu malen und diese zum Erscheinen zu bringen.
<G-vec00169-001-s429><draw.malen><en> She develops a metaphorical language based on the semantic of objects, sounds and movements; letting the images draw emotions in space.
<G-vec00169-001-s429><draw.malen><de> Sie entwickelt eine metaphorische Sprache, die auf der Bedeutung der Objekte, Geräusche und Bewegungen basiert; die Bilder Emotionen im Raum malen lassen.
<G-vec00169-001-s430><draw.malen><en> We engage with our children, sing songs, go for a walk, do crafting, play, make music and draw so that the children learn to engage themselves in a positive way.
<G-vec00169-001-s430><draw.malen><de> Wir beschäftigen uns mit den Kindern, wir singen Lieder, machen Spaziergänge, basteln, spielen, musizieren und malen, damit die Kinder lernen, sich selbst auf positive Art zu beschäftigen.
<G-vec00169-001-s431><draw.malen><en> The goal was to draw an AKVIS mascot (a horse).
<G-vec00169-001-s431><draw.malen><de> Die Aufgabe bestand darin, das Maskottchen von AKVIS - das Pferd - zu malen.
<G-vec00169-001-s432><draw.malen><en> Two thick felt tip pens with which it will be easy to draw big objects.
<G-vec00169-001-s432><draw.malen><de> Zwei dicke Filzstifte, mit denen man leichter große Sachen malen kann.
<G-vec00169-001-s433><draw.malen><en> Another example can be painting a picture of a deity while making efforts to draw the deity in such a manner that it resembles its actual form.
<G-vec00169-001-s433><draw.malen><de> Ein weiteres Beispiel ist das Malen einer Gottheit, indem man sich bemüht die Gottheit auf einer solchen Art und Weise zu malen, dass es mit ihrer tatsächlichen Form übereinstimmt.
<G-vec00169-001-s434><draw.malen><en> To remove a part of the clone, press the Ctrl-key on Windows / on Mac, and keeping it pressed draw over the area.
<G-vec00169-001-s434><draw.malen><de> Um einen Bereich des Klons zu entfernen, drücken Sie die Strg-Taste auf Windows, oder ⌘ auf Mac und, die Taste gedrückt haltend, malen Sie über den Bereich.
<G-vec00169-001-s435><draw.malen><en> In this way, an educational workshop offers the opportunity to draw, handcraft and experiment.
<G-vec00169-001-s435><draw.malen><de> So bietet eine Bildungswerkstatt die Möglichkeit zum Malen, Werken und Experimentieren.
<G-vec00169-001-s436><draw.malen><en> Nothing but a sound, a tone, an eddy between train and ship, to me, when I suddenly jump from the swing and run to the fence on solid ground, look through it in order to draw a horizon with my eyes, on which a raft is drifting towards me.
<G-vec00169-001-s436><draw.malen><de> Nichts als ein Ton, ein Klang, ein Wirbel zwischen Zug und Schiff, für mich, wenn ich augenblicklich von der Schaukel springe und auf festem Boden zum Zaun laufe, um mit meinen Augen durch ihn hindurch einen Horizont zu malen, auf dem ein Floß auf mich zu treibt.
<G-vec00042-001-s456><draw.nutzen><en> In addition, the LDC works closely with inventors to integrate their specific expertise and to draw on their unique tools, technologies, models, methods and materials.
<G-vec00042-001-s456><draw.nutzen><de> Zudem kooperiert das LDC eng mit den entsprechenden Erfindern, um deren Fachwissen einzubinden und deren Werkzeuge, Technologien, Modelle, Methoden oder Materialien zu nutzen.
<G-vec00042-001-s457><draw.nutzen><en> This, in turn, will open up new business opportunities for SMEs because – with the help of cloud platforms – they will be able to draw upon new data for new service products.
<G-vec00042-001-s457><draw.nutzen><de> Für die KMU eröffnen sich damit neue Geschäftsfelder, da sie jetzt durch die Cloud-Plattformen neue Daten für neue Dienstleistungsprodukte nutzen können.
<G-vec00042-001-s458><draw.nutzen><en> They draw on the very best science, technology, application knowledge and consumer/market insights from across the Symrise Group.
<G-vec00042-001-s458><draw.nutzen><de> Dazu nutzen sie das Beste aus Wissenschaft, Technologie, Anwendungswissen sowie unsere Einblicke in Kunden und Märkte über den gesamten Symrise Konzern hinweg.
<G-vec00042-001-s459><draw.nutzen><en> Group Leaders can draw on infrastructure and administration of a Max Planck Institute, but are also provided with own funds for personnel, equipment and running costs, which enable them to independently engage in their research project, thus laying the foundations for a successful career.
<G-vec00042-001-s459><draw.nutzen><de> Die Leiterinnen und Leiter nutzen Infrastruktur und Verwaltung eines Max-Planck-Instituts, verfügen jedoch über eigene Personal- und Sachmittel, die es ihnen ermöglichen, eigenständig ein Forschungsprojekt zu verfolgen und damit den Grundstein für eine erfolgreiche Karriere zu legen.
<G-vec00042-001-s460><draw.nutzen><en> """Before we develop a new insurance product, we draw on the results of a customer survey."
<G-vec00042-001-s460><draw.nutzen><de> Bevor wir eine neue Versicherung entwickeln, nutzen wir die Ergebnisse der Kundenbefragung.
<G-vec00042-001-s461><draw.nutzen><en> Statisticians at P&G draw on a variety of different data sets, from consumer and sensorial panel testing to stability and reliability to accelerated experiments that look at how well products maintain their shelf-life.
<G-vec00042-001-s461><draw.nutzen><de> Die Statistiker von P&G nutzen eine Vielzahl unterschiedlicher Daten, von Verbraucher- und Sensorpanel-Tests über Stabilität und Zuverlässigkeit bis zu beschleunigten Tests, mit denen überprüft wird, in welchem Umfang Produkte ihre Haltbarkeitsdauer erfüllen.
<G-vec00042-001-s462><draw.nutzen><en> Hispacar is celebrating the Holiday Season with a fantastic price draw We would like to take the opportunity to thank you for your confidence in our car hire services.
<G-vec00042-001-s462><draw.nutzen><de> Hispacar feiert Weihnachten mit grossartige Wettbewerbe Wir möchten diese Gelegenheit nutzen, um Ihnen für die Nutzung unseres Service und Ihr Vertrauen zu danken.
<G-vec00042-001-s463><draw.nutzen><en> Their drawings have much in common: both artists draw on the power of intuition and the unconscious, both are fascinated by the unfathomable and the grotesque, both explore the light and shadow sides of human existence and find clear images for unclear circumstances.
<G-vec00042-001-s463><draw.nutzen><de> Ihre Zeichnungen offenbaren Gemeinsamkeiten: Beide Künstler nutzen die Kräfte der Intuition und des Unbewussten, beide sind fasziniert vom Abgründigen und Grotesken, beide erkunden die Licht- und Schattenseiten des Menschseins und finden klare Bildzeichen für unklare Verhältnisse.
<G-vec00042-001-s464><draw.nutzen><en> During her research sojourn, Dr. Southwood will be collaborating with various scholars from the university and its School of Education to draw on their psycholinguistic and sociolinguistic expertise on linguistic aspects of migration research for her own studies.
<G-vec00042-001-s464><draw.nutzen><de> Dr. Southwood wird während ihres Forschungsaufenthaltes mit mehreren Wissenschaftlerinnen und Wissenschaftlern der Universität Heidelberg und der Pädagogischen Hochschule Heidelberg zusammenarbeiten, um deren psycho- und soziolinguistisches Fachwissen zu sprachlichen Aspekten der Migrationsforschung für die eigenen Untersuchungen zu nutzen.
<G-vec00042-001-s465><draw.nutzen><en> Our tax professionals draw on their diverse perspectives and skills to give you a seamless service through all the challenges of planning, financial accounting, tax compliance and maintaining effective relationships with the tax authorities.
<G-vec00042-001-s465><draw.nutzen><de> Unsere Steuerexperten nutzen ihre unterschiedlichen Perspektiven und Fähigkeiten, um Ihnen einen nahtlosen globalen Service zu bieten, der alle Anforderungen im Hinblick auf Planung, Finanzbuchhaltung, die Einhaltung steuerlicher Vorschriften und die Pflege effektiver Beziehungen zu den Steuerbehörden erfüllt.
<G-vec00042-001-s466><draw.nutzen><en> We draw on our extensive R&D network to build up our know-how and conduct targeted research as part of joint, partly funded projects with application-oriented and innovative content.
<G-vec00042-001-s466><draw.nutzen><de> Unser umfangreiches FuE-Netzwerk nutzen wir zum Know-how-Aufbau und für zielgerichtete Forschung innerhalb gemeinsamer, teilweise geförderter Projekte, die anwendungsnahe und innovative Inhalte umfassen.
<G-vec00042-001-s467><draw.nutzen><en> In this, we can draw on capabilities acquired in the development, construction, and operation of infrastructure projects, real estate, and facilities.
<G-vec00042-001-s467><draw.nutzen><de> Wir nutzen dabei die Fähigkeiten, die wir aus der Entwicklung, dem Bau und dem Betrieb von Infrastrukturprojekten, Immobilien und Anlagen haben.
<G-vec00042-001-s468><draw.nutzen><en> I would like to grab the opportunity to draw everybody's attention once more to the new search possibility in the picture database.
<G-vec00042-001-s468><draw.nutzen><de> Ich möchte die Gelegenheit nutzen, alle Aufmerksamkeit noch einmal auf die neue Möglichkeit der Suche in der Bilddatenbank ziehen zu greifen.
<G-vec00042-001-s469><draw.nutzen><en> H. + H. Maslanka Chirurgische Instrumente GmbH aims to respect the copyrights of the images, graphics, audio documents, video sequences and texts used in its publications, to use self-created images, graphics, audio documents, video sequences and texts or to draw on license-free graphics, audio documents, video sequences and texts.
<G-vec00042-001-s469><draw.nutzen><de> H. + H. Maslanka Chirurgische Instrumente GmbH ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihm selbst erstellte Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.
<G-vec00042-001-s470><draw.nutzen><en> This entitles him/her to draw upon the offerings of the Graduate Academy to the same extent and under the same conditions as University doctoral students not supported by the Max Planck Society.
<G-vec00042-001-s470><draw.nutzen><de> Er ist damit berechtigt, das Angebot der Graduiertenakademie im gleichen Umfang und zu gleichen Konditionen zu nutzen wie Doktoranden der Universität, die nicht durch die Max-Planck-Gesellschaft gefördert werden.
<G-vec00042-001-s471><draw.nutzen><en> Two other empirical manuscripts draw on experiments, allowing for particularly firm causal conclusions.
<G-vec00042-001-s471><draw.nutzen><de> Zwei weitere empirische Manuskripte nutzen experimentelle Designs und erlauben somit besonders starke, kausale Schlüsse.
<G-vec00042-001-s472><draw.nutzen><en> When I appointed him Prefect of the Congregation for the Oriental Churches and created him Cardinal, I wished not only to draw upon his experience and wisdom, but also to pay tribute to the Churches of the East and to the Church in Syria in particular.
<G-vec00042-001-s472><draw.nutzen><de> Als ich ihn zum Präfekten der Kongregation für die Orientalischen Kirchen ernannte und in den Kardinalsstand erhob, war es mein Wunsch, nicht nur seine Erfahrung und Weisheit zu nutzen, sondern auch meine Anerkennung für die orientalischen Kirchen, insbesondere die syrische Kirche, zum Ausdruck zu bringen.
<G-vec00042-001-s473><draw.nutzen><en> COPYRIGHT AND TRADEMARK RIGHTS Das Central endeavours, in all publications, to respect copyright of the pictures, graphics, sound recordings, video sequences and texts, to use pictures, graphics, sound recordings, video sequences and texts or to draw upon public domain graphics, sound recordings, video sequences and texts.
<G-vec00042-001-s473><draw.nutzen><de> Das Central ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihm selbst erstellte Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.
<G-vec00042-001-s474><draw.nutzen><en> "Glos on this: ""The EU must draw on the experience gained by ESA."
<G-vec00042-001-s474><draw.nutzen><de> "Glos dazu: ""Die EU muss die Erfahrungen der ESA nutzen."
<G-vec00169-001-s456><draw.nutzen><en> In addition, the LDC works closely with inventors to integrate their specific expertise and to draw on their unique tools, technologies, models, methods and materials.
<G-vec00169-001-s456><draw.nutzen><de> Zudem kooperiert das LDC eng mit den entsprechenden Erfindern, um deren Fachwissen einzubinden und deren Werkzeuge, Technologien, Modelle, Methoden oder Materialien zu nutzen.
<G-vec00169-001-s457><draw.nutzen><en> This, in turn, will open up new business opportunities for SMEs because – with the help of cloud platforms – they will be able to draw upon new data for new service products.
<G-vec00169-001-s457><draw.nutzen><de> Für die KMU eröffnen sich damit neue Geschäftsfelder, da sie jetzt durch die Cloud-Plattformen neue Daten für neue Dienstleistungsprodukte nutzen können.
<G-vec00169-001-s458><draw.nutzen><en> They draw on the very best science, technology, application knowledge and consumer/market insights from across the Symrise Group.
<G-vec00169-001-s458><draw.nutzen><de> Dazu nutzen sie das Beste aus Wissenschaft, Technologie, Anwendungswissen sowie unsere Einblicke in Kunden und Märkte über den gesamten Symrise Konzern hinweg.
<G-vec00169-001-s459><draw.nutzen><en> Group Leaders can draw on infrastructure and administration of a Max Planck Institute, but are also provided with own funds for personnel, equipment and running costs, which enable them to independently engage in their research project, thus laying the foundations for a successful career.
<G-vec00169-001-s459><draw.nutzen><de> Die Leiterinnen und Leiter nutzen Infrastruktur und Verwaltung eines Max-Planck-Instituts, verfügen jedoch über eigene Personal- und Sachmittel, die es ihnen ermöglichen, eigenständig ein Forschungsprojekt zu verfolgen und damit den Grundstein für eine erfolgreiche Karriere zu legen.
<G-vec00169-001-s460><draw.nutzen><en> """Before we develop a new insurance product, we draw on the results of a customer survey."
<G-vec00169-001-s460><draw.nutzen><de> Bevor wir eine neue Versicherung entwickeln, nutzen wir die Ergebnisse der Kundenbefragung.
<G-vec00169-001-s461><draw.nutzen><en> Statisticians at P&G draw on a variety of different data sets, from consumer and sensorial panel testing to stability and reliability to accelerated experiments that look at how well products maintain their shelf-life.
<G-vec00169-001-s461><draw.nutzen><de> Die Statistiker von P&G nutzen eine Vielzahl unterschiedlicher Daten, von Verbraucher- und Sensorpanel-Tests über Stabilität und Zuverlässigkeit bis zu beschleunigten Tests, mit denen überprüft wird, in welchem Umfang Produkte ihre Haltbarkeitsdauer erfüllen.
<G-vec00169-001-s462><draw.nutzen><en> Hispacar is celebrating the Holiday Season with a fantastic price draw We would like to take the opportunity to thank you for your confidence in our car hire services.
<G-vec00169-001-s462><draw.nutzen><de> Hispacar feiert Weihnachten mit grossartige Wettbewerbe Wir möchten diese Gelegenheit nutzen, um Ihnen für die Nutzung unseres Service und Ihr Vertrauen zu danken.
<G-vec00169-001-s463><draw.nutzen><en> Their drawings have much in common: both artists draw on the power of intuition and the unconscious, both are fascinated by the unfathomable and the grotesque, both explore the light and shadow sides of human existence and find clear images for unclear circumstances.
<G-vec00169-001-s463><draw.nutzen><de> Ihre Zeichnungen offenbaren Gemeinsamkeiten: Beide Künstler nutzen die Kräfte der Intuition und des Unbewussten, beide sind fasziniert vom Abgründigen und Grotesken, beide erkunden die Licht- und Schattenseiten des Menschseins und finden klare Bildzeichen für unklare Verhältnisse.
<G-vec00169-001-s464><draw.nutzen><en> During her research sojourn, Dr. Southwood will be collaborating with various scholars from the university and its School of Education to draw on their psycholinguistic and sociolinguistic expertise on linguistic aspects of migration research for her own studies.
<G-vec00169-001-s464><draw.nutzen><de> Dr. Southwood wird während ihres Forschungsaufenthaltes mit mehreren Wissenschaftlerinnen und Wissenschaftlern der Universität Heidelberg und der Pädagogischen Hochschule Heidelberg zusammenarbeiten, um deren psycho- und soziolinguistisches Fachwissen zu sprachlichen Aspekten der Migrationsforschung für die eigenen Untersuchungen zu nutzen.
<G-vec00169-001-s465><draw.nutzen><en> Our tax professionals draw on their diverse perspectives and skills to give you a seamless service through all the challenges of planning, financial accounting, tax compliance and maintaining effective relationships with the tax authorities.
<G-vec00169-001-s465><draw.nutzen><de> Unsere Steuerexperten nutzen ihre unterschiedlichen Perspektiven und Fähigkeiten, um Ihnen einen nahtlosen globalen Service zu bieten, der alle Anforderungen im Hinblick auf Planung, Finanzbuchhaltung, die Einhaltung steuerlicher Vorschriften und die Pflege effektiver Beziehungen zu den Steuerbehörden erfüllt.
<G-vec00169-001-s466><draw.nutzen><en> We draw on our extensive R&D network to build up our know-how and conduct targeted research as part of joint, partly funded projects with application-oriented and innovative content.
<G-vec00169-001-s466><draw.nutzen><de> Unser umfangreiches FuE-Netzwerk nutzen wir zum Know-how-Aufbau und für zielgerichtete Forschung innerhalb gemeinsamer, teilweise geförderter Projekte, die anwendungsnahe und innovative Inhalte umfassen.
<G-vec00169-001-s467><draw.nutzen><en> In this, we can draw on capabilities acquired in the development, construction, and operation of infrastructure projects, real estate, and facilities.
<G-vec00169-001-s467><draw.nutzen><de> Wir nutzen dabei die Fähigkeiten, die wir aus der Entwicklung, dem Bau und dem Betrieb von Infrastrukturprojekten, Immobilien und Anlagen haben.
<G-vec00169-001-s468><draw.nutzen><en> I would like to grab the opportunity to draw everybody's attention once more to the new search possibility in the picture database.
<G-vec00169-001-s468><draw.nutzen><de> Ich möchte die Gelegenheit nutzen, alle Aufmerksamkeit noch einmal auf die neue Möglichkeit der Suche in der Bilddatenbank ziehen zu greifen.
<G-vec00169-001-s469><draw.nutzen><en> H. + H. Maslanka Chirurgische Instrumente GmbH aims to respect the copyrights of the images, graphics, audio documents, video sequences and texts used in its publications, to use self-created images, graphics, audio documents, video sequences and texts or to draw on license-free graphics, audio documents, video sequences and texts.
<G-vec00169-001-s469><draw.nutzen><de> H. + H. Maslanka Chirurgische Instrumente GmbH ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihm selbst erstellte Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.
<G-vec00169-001-s470><draw.nutzen><en> This entitles him/her to draw upon the offerings of the Graduate Academy to the same extent and under the same conditions as University doctoral students not supported by the Max Planck Society.
<G-vec00169-001-s470><draw.nutzen><de> Er ist damit berechtigt, das Angebot der Graduiertenakademie im gleichen Umfang und zu gleichen Konditionen zu nutzen wie Doktoranden der Universität, die nicht durch die Max-Planck-Gesellschaft gefördert werden.
<G-vec00169-001-s471><draw.nutzen><en> Two other empirical manuscripts draw on experiments, allowing for particularly firm causal conclusions.
<G-vec00169-001-s471><draw.nutzen><de> Zwei weitere empirische Manuskripte nutzen experimentelle Designs und erlauben somit besonders starke, kausale Schlüsse.
<G-vec00169-001-s472><draw.nutzen><en> When I appointed him Prefect of the Congregation for the Oriental Churches and created him Cardinal, I wished not only to draw upon his experience and wisdom, but also to pay tribute to the Churches of the East and to the Church in Syria in particular.
<G-vec00169-001-s472><draw.nutzen><de> Als ich ihn zum Präfekten der Kongregation für die Orientalischen Kirchen ernannte und in den Kardinalsstand erhob, war es mein Wunsch, nicht nur seine Erfahrung und Weisheit zu nutzen, sondern auch meine Anerkennung für die orientalischen Kirchen, insbesondere die syrische Kirche, zum Ausdruck zu bringen.
<G-vec00169-001-s473><draw.nutzen><en> COPYRIGHT AND TRADEMARK RIGHTS Das Central endeavours, in all publications, to respect copyright of the pictures, graphics, sound recordings, video sequences and texts, to use pictures, graphics, sound recordings, video sequences and texts or to draw upon public domain graphics, sound recordings, video sequences and texts.
<G-vec00169-001-s473><draw.nutzen><de> Das Central ist bestrebt, in allen Publikationen die Urheberrechte der verwendeten Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu beachten, von ihm selbst erstellte Bilder, Grafiken, Tondokumente, Videosequenzen und Texte zu nutzen oder auf lizenzfreie Grafiken, Tondokumente, Videosequenzen und Texte zurückzugreifen.
<G-vec00169-001-s474><draw.nutzen><en> "Glos on this: ""The EU must draw on the experience gained by ESA."
<G-vec00169-001-s474><draw.nutzen><de> "Glos dazu: ""Die EU muss die Erfahrungen der ESA nutzen."
<G-vec00169-001-s475><draw.nähern><en> Paul’s God starts a movement from heart to hands, the movement of one who is unafraid to draw near, to touch, to caress, without being scandalized, without condemning, without dismissing anyone.
<G-vec00169-001-s475><draw.nähern><de> Der Gott des heiligen Paulus erzeugt eine Bewegung, die vom Herz zu den Händen geht, die Bewegung dessen, der keine Angst hat, sich zu nähern, der keine Berührungsängste hat, der keine Angst hat zu liebkosen; und all das ohne entsetzt zu sein, zu verurteilen und ohne jemanden auszuschließen.
<G-vec00169-001-s476><draw.nähern><en> In the deep of night I shall draw near to bless thy sandals.
<G-vec00169-001-s476><draw.nähern><de> In der Hefe der Nacht werde Ich Mich dir nähern und deine Sandalen segnen.
<G-vec00169-001-s477><draw.nähern><en> Let no soul fear to draw near to Me, even though its sins be as scarlet.” (Diary, 699)
<G-vec00169-001-s477><draw.nähern><de> Keine Seele soll Angst haben, sich Mir zu nähern, auch wenn ihre Sünden rot wie Scharlach wären“(TB 699).
<G-vec00169-001-s478><draw.nähern><en> Many new people draw near and are growing.
<G-vec00169-001-s478><draw.nähern><de> Viele neue Menschen nähern sich, und ihre Zahl nimmt zu.
<G-vec00169-001-s479><draw.nähern><en> Draw near to God, and he will draw near to you.
<G-vec00169-001-s479><draw.nähern><de> Sucht die Nähe Gottes; dann wird er sich euch nähern.
<G-vec00169-001-s480><draw.nähern><en> 4:8 Draw nigh to God, and he will draw nigh to you.
<G-vec00169-001-s480><draw.nähern><de> 4:8 Sucht die Nähe Gottes; dann wird er sich euch nähern.
<G-vec00169-001-s481><draw.nähern><en> 8:19 And I have given the Levites as a gift to Aaron and to his sons, from among the children of Israel, to perform the service of the children of Israel in the tent of meeting, and to make atonement for the children of Israel; that there be no plague among the children of Israel, when the children of Israel draw near to the sanctuary.
<G-vec00169-001-s481><draw.nähern><de> 18 Und ich habe die Leviten genommen als Ersatz für alle Erstgeborenen unter den Söhnen Israel; 19 und ich habe die Leviten dem Aaron und seinen Söhnen als Gabe aus der Mitte der Söhne Israel gegeben, den Dienst der Söhne Israel am Zelt der Begegnung auszuüben und für die Söhne Israel Sühnung zu erwirken, damit unter den Söhnen Israel keine Plage dadurch entsteht, daß die Söhne Israel sich dem Heiligtum nähern.
<G-vec00169-001-s482><draw.nähern><en> But I have been indeed ungrateful person and infidel; I have not maintained verse of you the votes and the promises that I had solemnly done in my baptism and I have not honored my appointments; I don't deserve to be called your child, and not even your slave: in me, all deserves your reproaches and your anger; on my behalf, I don't dare to draw near anymore, alone, to yours holy and sovereign Majesty.
<G-vec00169-001-s482><draw.nähern><de> Aber ich war wirklich undankbar und untreu; ich erhielt keinen Vers von dir die Stimmen und die Versprechen, die feierlich in meiner Taufe gemacht hatte, und ich ehrte meine Verpflichtungen nicht; ich verdiene nicht, dein Kind gerufen zu werden, und auch nicht dein Sklave: in ich verdient Ganze deine Vorwürfe und deine Wut;, ich wage nicht mehr, sich mich allein deinem Heilige und souveräner Majestät zu nähern.
<G-vec00169-001-s483><draw.nähern><en> As the 2008 Olympics draw near, the CCP is carrying out another round of special persecution, using the Olympics as a convenient excuse.
<G-vec00169-001-s483><draw.nähern><de> Während sich die Olympischen Spiele 2008 nähern, führt die KPCh eine weitere Runde der speziellen Verfolgung durch, indem sie die Spiele als günstige Entschuldigung angibt.
<G-vec00169-001-s484><draw.nähern><en> In order to draw near to that mystery of union with God, which the Greek Fathers called the divinization of man, and to grasp accurately the manner in which this is realized, it is necessary in the first place to bear in mind that man is essentially a creature,16 and remains such for eternity, so that an absorbing of the human self into the divine self is never possible, not even in the highest states of grace.
<G-vec00169-001-s484><draw.nähern><de> Um sich jenem Geheimnis der Vereinigung mit Gott zu nähern, das die griechischen Väter Vergöttlichung des Menschen nennen, und um genau die Weisen zu erfassen, nach denen sie erfolgt, muss man sich vor allem vor Augen halten, dass der Mensch wesentlich Geschöpf ist[16] und es ewig bleibt; es wird daher nie ein Aufgehen des menschlichen Ich im göttlichen Ich, auch nie auf der höchsten Stufe der Gnade, möglich sein.
<G-vec00169-001-s485><draw.nähern><en> To the extent that we draw close to Christ, in our own lives too, truth and love are blended.
<G-vec00169-001-s485><draw.nähern><de> In dem Maße, in dem wir uns Christus nähern, verschmelzen auch in unserem Leben Wahrheit und Liebe.
<G-vec00169-001-s486><draw.nähern><en> 8 “These people draw near to Me with their mouth, and honor Me with their lips, but their heart is far from Me.
<G-vec00169-001-s486><draw.nähern><de> "8 ""Diese Leute nähern sich mir mit den Mund und ehrt mich mit den Lippen, aber ihr Herz ist fern von mir."
<G-vec00169-001-s487><draw.nähern><en> Only by the blood of Jesus Christ can we draw near to God.
<G-vec00169-001-s487><draw.nähern><de> Nur durch das Blut Jesu Christi können wir uns Gott nähern.
<G-vec00169-001-s488><draw.nähern><en> I desire, little children, for each of you to fall in love with eternal life which is your future, and for all worldly things to be a help for you to draw you closer to God the Creator.
<G-vec00169-001-s488><draw.nähern><de> Meine lieben Kinder, ich wünsche, dass jeder von euch sich in das ewige Leben verliebt, welches eure Zukunft ist, und dass alle irdischen Dinge euch helfen, euch Gott dem Schöpfer zu nähern.
<G-vec00169-001-s489><draw.nähern><en> Closeness to the Heart of the Lord urges our heart to lovingly draw near to a brother or sister, and helps us assume this compassion for the world.
<G-vec00169-001-s489><draw.nähern><de> Die Nähe zum Herzen des Herrn spornt unser Herz an, sich liebevoll dem Bruder zu nähern, und hilft, in dieses Mitleid für die Welt einzutreten.
<G-vec00169-001-s490><draw.nähern><en> If we are far from him, we are awaited; when we draw near, we are embraced; if we fall, he lifts us up; if we are repentant, he forgives us.
<G-vec00169-001-s490><draw.nähern><de> Wenn wir fern von ihm sind, dann erwartet er uns; wenn wir uns ihm nähern, dann werden wir umarmt; wenn wir zu Boden fallen, dann richtet er uns wieder auf; wenn wir reumütig sind, dann vergibt er uns.
<G-vec00169-001-s491><draw.nähern><en> What is happening is known throughout the Universe, and many visitors excitedly draw near to you to witness yours and Mother Earth's unique Ascension.
<G-vec00169-001-s491><draw.nähern><de> Was jetzt geschieht, ist im gesamten Universum bekannt, und viele Besucher sind davon sehr angeregt und nähern sich euch, um Zeuge eures Aufstiegs und dessen der Mutter Erde zu werden.
<G-vec00169-001-s492><draw.nähern><en> And it falls in darkness more and more dense, in a kind of desperation that makes her foretaste in certain way the hell and it makes her/it completely incapable to draw near himself/herself/themselves to God.
<G-vec00169-001-s492><draw.nähern><de> Und sie überstürzt in Finsternis immer mehr Stiche, in eine Art von Verzweiflung, die ihr im voraus in gewißer Art und Weise die Hölle genießen macht, und es macht sie ganz unfähig sich Gott zu nähern.
<G-vec00169-001-s493><draw.nähern><en> Today too, Jesus lives and walks along the paths of ordinary life in order to draw near to everyone, beginning with the least, and to heal us of our infirmities and illnesses.
<G-vec00169-001-s493><draw.nähern><de> Auch heute lebt Jesus in den Wirklichkeiten unseres gewöhnlichen Lebens und ist in ihnen auf dem Weg, um sich allen zu nähern, begonnen bei den Letzten, und uns von unseren Krankheiten und Gebrechen zu heilen.
<G-vec00042-001-s513><draw.schöpfen><en> PROLETARIAN SOCIALISM For our party and for our party tactics there is but one valid basis: the basis of the class struggle, out of which the Social Democratic party has sprung up, and out of which alone it can draw the necessary strength to bid defiance to every storm and to all its enemies.
<G-vec00042-001-s513><draw.schöpfen><de> Für unsere Partei und für unsere Parteitaktik gibt es nur einen Rechtsboden: den Boden des Klassenkampfes, aus dem die Sozialdemokratische Partei hervorgewachsen ist und aus dem allein sie die nötige Kraft schöpfen kann, um jeden Sturm und all ihren Feinden trotzen zu können.
<G-vec00042-001-s514><draw.schöpfen><en> 2:16 Now a priest of Midian had seven daughters, and they came to draw water and fill the troughs to water their father's flock.
<G-vec00042-001-s514><draw.schöpfen><de> 2:16 Der Priester aber von Midian hatte sieben Töchter; die kamen, Wasser zu schöpfen, und füllten die Rinnen, daß sie ihres Vaters Schafe tränkten.
<G-vec00042-001-s515><draw.schöpfen><en> And she hasted and emptied her pitcher into the trough, and ran again to the well to draw [water]; and she drew for all his camels.
<G-vec00042-001-s515><draw.schöpfen><de> Und eilte und goß den Krug aus in die Tränke und lief abermals zum Brunnen, zu schöpfen, und schöpfte allen seinen Kamelen.
<G-vec00042-001-s516><draw.schöpfen><en> Thus they will find Me in their heart again even when I Am no longer physically visible to them, so that they will constantly be able to draw strength from it and diligently accomplish the work for My kingdom after I have spoken from above which will result in acute adversity for people.
<G-vec00042-001-s516><draw.schöpfen><de> Und so werden sie Mich im Herzen wiederfinden, auch wenn Ich ihnen leiblich nicht mehr sichtbar bin, und sie werden ständig Kraft schöpfen können und emsig die Arbeit für Mein Reich verrichten, wenn Ich gesprochen habe aus der Höhe und die Menschen in äußerste Not dadurch gekommen sind.
<G-vec00042-001-s517><draw.schöpfen><en> 19 And she finished giving drink to him. And she said, I also will draw for your camels until they have finished drinking.
<G-vec00042-001-s517><draw.schöpfen><de> 19 Und als sie ihm genug zu trinken gegeben hatte, sprach sie: Ich will auch für deine Kamele schöpfen, bis sie genug getrunken haben.
<G-vec00042-001-s518><draw.schöpfen><en> 7 There came a woman of Samaria to draw water.
<G-vec00042-001-s518><draw.schöpfen><de> 7 Da kommt eine Frau aus Samaria, Wasser zu schöpfen.
<G-vec00042-001-s519><draw.schöpfen><en> Prayer is not only the breath of the soul but, to make use of a metaphor, it is also the oasis of peace from which we can draw the water that nourishes our spiritual life and transforms our existence.
<G-vec00042-001-s519><draw.schöpfen><de> Das Gebet ist nicht nur der Atem der Seele, sondern es ist, um ein Bild zu gebrauchen, auch die Oase des Friedens, in der wir das Wasser schöpfen können, das unser geistliches Leben nährt und unser Leben verwandelt.
<G-vec00042-001-s520><draw.schöpfen><en> It is the wellspring from which we draw in every prayer.
<G-vec00042-001-s520><draw.schöpfen><de> Sie ist die Quelle, aus der wir bei jedem Gebet schöpfen.
<G-vec00042-001-s521><draw.schöpfen><en> In it he was able to draw on the full experience of his long composing career.
<G-vec00042-001-s521><draw.schöpfen><de> Darin kann er aus der prallen Erfahrung seines langen Komponistenlebens schöpfen.
<G-vec00042-001-s522><draw.schöpfen><en> As one of the leading service providers on the German market for media and PR evaluation we can draw on a wealth of experience to create new innovative solutions that meet the demands of tomorrow's marketplace.
<G-vec00042-001-s522><draw.schöpfen><de> Als einer der führenden Fullservice-Dienstleister im Markt der Medien- und PR-Evaluation in Deutschland schöpfen wir aus dem Fundus an Tradition Innovationskraft für die Marktanforderungen von morgen.
<G-vec00042-001-s523><draw.schöpfen><en> 19 And when she had given him enough to drink, she said, I will draw [water] for thy camels also, until they have drunk enough.
<G-vec00042-001-s523><draw.schöpfen><de> 19 Und als sie ihm genug zu trinken gegeben hatte, sprach sie: Ich will auch fÃ1⁄4r deine Kamele schöpfen, bis sie genug getrunken haben.
<G-vec00042-001-s524><draw.schöpfen><en> Yet you will not be left without warning, time and again you will be informed from above and when you see how everything I foretold you comes true you can already draw strength from it....
<G-vec00042-001-s524><draw.schöpfen><de> Doch ihr werdet nicht ungewarnt bleiben, es wird euch immer wieder Kunde zugehen von oben, und ihr werdet daraus schon Kraft schöpfen können, wenn ihr sehet, wie sich alles erfüllet, was Ich euch vorausgesagt habe....
<G-vec00042-001-s525><draw.schöpfen><en> The modern proletariat, as the heir and foster-child of bourgeois society, is far too much a born materialist, far too much an individual of flesh and blood and healthy instincts to draw its strength and devotion to ideas, in accordance with the morale of slaves, from sufferings alone.
<G-vec00042-001-s525><draw.schöpfen><de> Der moderne Proletarier als Erbe und Zögling der bürgerlichen Gesellschaft ist viel zu sehr geborener Materialist, zu sehr gesund-sinnlicher Fleischesmensch, um der Sklavenmoral entsprechend aus den Martern allein Liebe und Kraft für seine Ideen zu schöpfen.
<G-vec00042-001-s526><draw.schöpfen><en> And he will be able to draw with full hands and experience strengthening; all weakness will fall off him; he will look upwards and see, what he did not see before – pure truth is imparted to him; he will recover at his soul; from now on he will want to drink constantly from the spring, which the love of God let him find, and he will constantly be filled; he will be delighted by the clarity of spiritual knowledge; he will recognize the infinite love of God, and his heart will beat towards him full of love; he will first feel as guest and then as child of God, which is allowed to take from his fullness unlimitedly.
<G-vec00042-001-s526><draw.schöpfen><de> Und er wird mit vollen Händen schöpfen können und Stärkung erfahren, jede Schwäche wird von ihm abfallen, er wird zur Höhe blicken und sehen, was er zuvor nicht sah - ihm wird die reine Wahrheit vermittelt, er wird gesunden an seiner Seele, er wird fortan ständig trinken wollen aus dem Quell, den ihn die Liebe Gottes finden ließ, und er wird ständig gesättigt werden, er wird sich ergötzen an der Klarheit geistigen Wissens, er wird die unendliche Liebe Gottes erkennen, und voller Liebe wird sein Herz Ihm entgegenschlagen, er wird sich zuerst als Gast und dann als ein Kind Gottes fühlen, das aus Seiner Fülle nehmen darf unbeschränkt.
<G-vec00042-001-s527><draw.schöpfen><en> 44 And she say to me, Both drink thou, and I will also draw for thy camels: let the same be the woman whom the LORD hath appointed out for my master's son.
<G-vec00042-001-s527><draw.schöpfen><de> 44 und sie wird sagen:Trinke du, ich will deinen Kamelen auch schöpfen, daß die sei das Weib, das der HERR meines HERRN Sohne bescheret hat.
<G-vec00042-001-s528><draw.schöpfen><en> Breathe deeply again – and draw from nature's nurturing treasures.
<G-vec00042-001-s528><draw.schöpfen><de> Atmen Sie wieder einmal richtig durch – und schöpfen Sie aus den pflegenden Schätzen der Natur.
<G-vec00042-001-s529><draw.schöpfen><en> I pray that the Church in the Holy Land will always draw new strength from its contemplation of the empty tomb of the Savior.
<G-vec00042-001-s529><draw.schöpfen><de> Ich bete, daß die Kirche im Heiligen Land stets neue Kraft aus der Betrachtung des leeren Grabes des Heilands schöpfen möge.
<G-vec00042-001-s530><draw.schöpfen><en> The shrine is becoming famous, even in other former Soviet countries, and many go there on pilgrimage to draw from the fount of grace which God sends.
<G-vec00042-001-s530><draw.schöpfen><de> Nach und nach wird das Heiligtum auch in andern Ländern der ehemaligen Sowjetunion berühmt und viele kommen wallfahrend, um aus dem Gnadenstrom zu schöpfen, der Gott ihnen schickt.
<G-vec00042-001-s531><draw.schöpfen><en> "(August 2009) ""You will draw water from the wells of salvation."" These words of the prophet Isaiah (12:3) in the Old Testament were already a reference to the time of the Lord Jesus."
<G-vec00042-001-s531><draw.schöpfen><de> "(August 2009) ""Ihr werdet mit Freuden Wasser schöpfen aus den Heilsbrunnen"" – Der Prophet Jesaja blickte in diesem Wort (Jes 12,3) schon im Alten Testament in die Zeit des Herrn Jesus."
<G-vec00169-001-s513><draw.schöpfen><en> PROLETARIAN SOCIALISM For our party and for our party tactics there is but one valid basis: the basis of the class struggle, out of which the Social Democratic party has sprung up, and out of which alone it can draw the necessary strength to bid defiance to every storm and to all its enemies.
<G-vec00169-001-s513><draw.schöpfen><de> Für unsere Partei und für unsere Parteitaktik gibt es nur einen Rechtsboden: den Boden des Klassenkampfes, aus dem die Sozialdemokratische Partei hervorgewachsen ist und aus dem allein sie die nötige Kraft schöpfen kann, um jeden Sturm und all ihren Feinden trotzen zu können.
<G-vec00169-001-s514><draw.schöpfen><en> 2:16 Now a priest of Midian had seven daughters, and they came to draw water and fill the troughs to water their father's flock.
<G-vec00169-001-s514><draw.schöpfen><de> 2:16 Der Priester aber von Midian hatte sieben Töchter; die kamen, Wasser zu schöpfen, und füllten die Rinnen, daß sie ihres Vaters Schafe tränkten.
<G-vec00169-001-s515><draw.schöpfen><en> And she hasted and emptied her pitcher into the trough, and ran again to the well to draw [water]; and she drew for all his camels.
<G-vec00169-001-s515><draw.schöpfen><de> Und eilte und goß den Krug aus in die Tränke und lief abermals zum Brunnen, zu schöpfen, und schöpfte allen seinen Kamelen.
<G-vec00169-001-s516><draw.schöpfen><en> Thus they will find Me in their heart again even when I Am no longer physically visible to them, so that they will constantly be able to draw strength from it and diligently accomplish the work for My kingdom after I have spoken from above which will result in acute adversity for people.
<G-vec00169-001-s516><draw.schöpfen><de> Und so werden sie Mich im Herzen wiederfinden, auch wenn Ich ihnen leiblich nicht mehr sichtbar bin, und sie werden ständig Kraft schöpfen können und emsig die Arbeit für Mein Reich verrichten, wenn Ich gesprochen habe aus der Höhe und die Menschen in äußerste Not dadurch gekommen sind.
<G-vec00169-001-s517><draw.schöpfen><en> 19 And she finished giving drink to him. And she said, I also will draw for your camels until they have finished drinking.
<G-vec00169-001-s517><draw.schöpfen><de> 19 Und als sie ihm genug zu trinken gegeben hatte, sprach sie: Ich will auch für deine Kamele schöpfen, bis sie genug getrunken haben.
<G-vec00169-001-s518><draw.schöpfen><en> 7 There came a woman of Samaria to draw water.
<G-vec00169-001-s518><draw.schöpfen><de> 7 Da kommt eine Frau aus Samaria, Wasser zu schöpfen.
<G-vec00169-001-s519><draw.schöpfen><en> Prayer is not only the breath of the soul but, to make use of a metaphor, it is also the oasis of peace from which we can draw the water that nourishes our spiritual life and transforms our existence.
<G-vec00169-001-s519><draw.schöpfen><de> Das Gebet ist nicht nur der Atem der Seele, sondern es ist, um ein Bild zu gebrauchen, auch die Oase des Friedens, in der wir das Wasser schöpfen können, das unser geistliches Leben nährt und unser Leben verwandelt.
<G-vec00169-001-s520><draw.schöpfen><en> It is the wellspring from which we draw in every prayer.
<G-vec00169-001-s520><draw.schöpfen><de> Sie ist die Quelle, aus der wir bei jedem Gebet schöpfen.
<G-vec00169-001-s521><draw.schöpfen><en> In it he was able to draw on the full experience of his long composing career.
<G-vec00169-001-s521><draw.schöpfen><de> Darin kann er aus der prallen Erfahrung seines langen Komponistenlebens schöpfen.
<G-vec00169-001-s522><draw.schöpfen><en> As one of the leading service providers on the German market for media and PR evaluation we can draw on a wealth of experience to create new innovative solutions that meet the demands of tomorrow's marketplace.
<G-vec00169-001-s522><draw.schöpfen><de> Als einer der führenden Fullservice-Dienstleister im Markt der Medien- und PR-Evaluation in Deutschland schöpfen wir aus dem Fundus an Tradition Innovationskraft für die Marktanforderungen von morgen.
<G-vec00169-001-s523><draw.schöpfen><en> 19 And when she had given him enough to drink, she said, I will draw [water] for thy camels also, until they have drunk enough.
<G-vec00169-001-s523><draw.schöpfen><de> 19 Und als sie ihm genug zu trinken gegeben hatte, sprach sie: Ich will auch fÃ1⁄4r deine Kamele schöpfen, bis sie genug getrunken haben.
<G-vec00169-001-s524><draw.schöpfen><en> Yet you will not be left without warning, time and again you will be informed from above and when you see how everything I foretold you comes true you can already draw strength from it....
<G-vec00169-001-s524><draw.schöpfen><de> Doch ihr werdet nicht ungewarnt bleiben, es wird euch immer wieder Kunde zugehen von oben, und ihr werdet daraus schon Kraft schöpfen können, wenn ihr sehet, wie sich alles erfüllet, was Ich euch vorausgesagt habe....
<G-vec00169-001-s525><draw.schöpfen><en> The modern proletariat, as the heir and foster-child of bourgeois society, is far too much a born materialist, far too much an individual of flesh and blood and healthy instincts to draw its strength and devotion to ideas, in accordance with the morale of slaves, from sufferings alone.
<G-vec00169-001-s525><draw.schöpfen><de> Der moderne Proletarier als Erbe und Zögling der bürgerlichen Gesellschaft ist viel zu sehr geborener Materialist, zu sehr gesund-sinnlicher Fleischesmensch, um der Sklavenmoral entsprechend aus den Martern allein Liebe und Kraft für seine Ideen zu schöpfen.
<G-vec00169-001-s526><draw.schöpfen><en> And he will be able to draw with full hands and experience strengthening; all weakness will fall off him; he will look upwards and see, what he did not see before – pure truth is imparted to him; he will recover at his soul; from now on he will want to drink constantly from the spring, which the love of God let him find, and he will constantly be filled; he will be delighted by the clarity of spiritual knowledge; he will recognize the infinite love of God, and his heart will beat towards him full of love; he will first feel as guest and then as child of God, which is allowed to take from his fullness unlimitedly.
<G-vec00169-001-s526><draw.schöpfen><de> Und er wird mit vollen Händen schöpfen können und Stärkung erfahren, jede Schwäche wird von ihm abfallen, er wird zur Höhe blicken und sehen, was er zuvor nicht sah - ihm wird die reine Wahrheit vermittelt, er wird gesunden an seiner Seele, er wird fortan ständig trinken wollen aus dem Quell, den ihn die Liebe Gottes finden ließ, und er wird ständig gesättigt werden, er wird sich ergötzen an der Klarheit geistigen Wissens, er wird die unendliche Liebe Gottes erkennen, und voller Liebe wird sein Herz Ihm entgegenschlagen, er wird sich zuerst als Gast und dann als ein Kind Gottes fühlen, das aus Seiner Fülle nehmen darf unbeschränkt.
<G-vec00169-001-s527><draw.schöpfen><en> 44 And she say to me, Both drink thou, and I will also draw for thy camels: let the same be the woman whom the LORD hath appointed out for my master's son.
<G-vec00169-001-s527><draw.schöpfen><de> 44 und sie wird sagen:Trinke du, ich will deinen Kamelen auch schöpfen, daß die sei das Weib, das der HERR meines HERRN Sohne bescheret hat.
<G-vec00169-001-s528><draw.schöpfen><en> Breathe deeply again – and draw from nature's nurturing treasures.
<G-vec00169-001-s528><draw.schöpfen><de> Atmen Sie wieder einmal richtig durch – und schöpfen Sie aus den pflegenden Schätzen der Natur.
<G-vec00169-001-s529><draw.schöpfen><en> I pray that the Church in the Holy Land will always draw new strength from its contemplation of the empty tomb of the Savior.
<G-vec00169-001-s529><draw.schöpfen><de> Ich bete, daß die Kirche im Heiligen Land stets neue Kraft aus der Betrachtung des leeren Grabes des Heilands schöpfen möge.
<G-vec00169-001-s530><draw.schöpfen><en> The shrine is becoming famous, even in other former Soviet countries, and many go there on pilgrimage to draw from the fount of grace which God sends.
<G-vec00169-001-s530><draw.schöpfen><de> Nach und nach wird das Heiligtum auch in andern Ländern der ehemaligen Sowjetunion berühmt und viele kommen wallfahrend, um aus dem Gnadenstrom zu schöpfen, der Gott ihnen schickt.
<G-vec00169-001-s531><draw.schöpfen><en> "(August 2009) ""You will draw water from the wells of salvation."" These words of the prophet Isaiah (12:3) in the Old Testament were already a reference to the time of the Lord Jesus."
<G-vec00169-001-s531><draw.schöpfen><de> "(August 2009) ""Ihr werdet mit Freuden Wasser schöpfen aus den Heilsbrunnen"" – Der Prophet Jesaja blickte in diesem Wort (Jes 12,3) schon im Alten Testament in die Zeit des Herrn Jesus."
<G-vec00169-001-s570><draw.stellen><en> In the garden draw up several stećci, of the medieval sarcophagi with their lid with pinion going back to the worship of Bogomiles, a sect opposed to the Byzantine Empire which developed in Balkans during Xe century.
<G-vec00169-001-s570><draw.stellen><de> Im Garten stellen sich mehrere stećci auf mittelalterliche Sarkophag mit ihrem Zahnraddeckel, der am Kult Bogomiles hinaufgeht, eine Sekte, die dem byzantinischen Imperium entgegengesetzt wurde, das sich im Balkan im Laufe des Xe Jahrhundert entwickelte.
<G-vec00169-001-s571><draw.stellen><en> When one scans the horizon in the North-East in clear weather, one distinguishes from north and the east as from the more high summits of Madeira the silhouette of the close small island there still, from abrupt cliffs emerge brutally from the sea and of the frayed summits draw up themselves with far.
<G-vec00169-001-s571><draw.stellen><de> Wenn man den Horizont im Nordosten durch klare Zeit absucht, unterscheidet man vom Norden, und vom Osten sowie von den höchsten Gipfel von Madeira der Umriß der kleinen benachbarten Insel dort noch tauchen schroffe Felsen brutal aus dem Meer auf, und von ausgefaserten Gipfeln stellen sich an weit auf.
<G-vec00169-001-s572><draw.stellen><en> Our doctoral molecular biologists are happy to advise you on the spectrum of possibilities and draw up together with you, a quality control procedure adapted to your needs.
<G-vec00169-001-s572><draw.stellen><de> Unsere promovierten Molekularbiologen beraten Sie gerne über die bestehenden Möglichkeiten und stellen gemeinsam mit Ihnen ein auf Ihre Bedürfnisse zugeschnittenes Kontrollverfahren zusammen.
<G-vec00169-001-s573><draw.stellen><en> the initiative to draw up EU guidelines on the promotion and protection of the rights of the child,
<G-vec00169-001-s573><draw.stellen><de> Und doch wird immer wieder versucht, die universelle Geltung der Menschenrechte in Frage zu stellen.
<G-vec00169-001-s574><draw.stellen><en> Draw up a list beforehand and use it as a checklist so that no-one is missed Provide seats for older or disabled guests Make sure that any seating or shelter provided is close enough to where you and the celebrant will be standing to form an intimate grouping and ensure that everyone hears and sees the ceremony Limit the amount of alcohol served before the ceremony Attention to all these quite simple things will make the world of difference to how smoothly your celebration runs, and how much everyone, including you, enjoys the ceremony.Jennifer Cram is an accredited General Civil Celebrant based in Brisbane Queensland Australia where she specialises in performing one of a kind Naming Ceremonies as Beautiful as your Baby and other ceremonies.
<G-vec00169-001-s574><draw.stellen><de> Stellen Sie eine Liste vorher auf und benutzen Sie sie als Checkliste, damit niemand vermißt wird Stellen Sie Sitze für die älteren oder untauglichen Gäste zur Verfügung Überprüfen Sie, ob jede mögliche Sitzplätze oder Schutz, die bereitgestellt wird, genug nah ist zu, wo Sie und der Zelebrant stehen werden, um zu bilden andeuten die Gruppierung und sicherstellen, daß jeder die Zeremonie hört und sieht Begrenzen Sie die Menge von Spiritus gedient vor der Zeremonie Aufmerksamkeit zu allen diesen ziemlich einfachen Sachen bildet die Welt vom Unterschied, zu wie glatt Ihre Feier läuft und zu wieviel jeder, einschließlich Sie, die Zeremonie genießt.Jennifer Cram ist ein beglaubigter allgemeiner Zivilzelebrant, der in Brisbane Queensland Australien gegründet wird, in dem sie auf das Durchführen von die freundlichen nennenzeremonien spezialisiert, die so schön sind wie Ihr Baby und andere Zeremonien.
<G-vec00169-001-s575><draw.stellen><en> Please enter the relevant data about your extraction unit and we will draw up an optimal control tender appropriate to your requirements.
<G-vec00169-001-s575><draw.stellen><de> Bitte geben Sie hier die bestehenden Daten Ihrer Absauganlage ein und wir stellen Ihnen entsprechend Ihren Anforderungen einen optimierten Steuerungsvorschlag zusammen.
<G-vec00169-001-s576><draw.stellen><en> The reception staff at the ACHAT Premium Budapest will gladly give you tips and suggestions or draw up a personal excursion program.
<G-vec00169-001-s576><draw.stellen><de> Die Mitarbeiter an der Rezeption im ACHAT Premium Budapest geben Ihnen gern Hinweise und Anregungen oder stellen Ihnen ein Ausflugsprogramm zusammen.
<G-vec00169-001-s577><draw.stellen><en> Draw up the environmental claim promoting the environmental qualities of your products/services, taking into account the requirements for it to be verifiable, accurate, and relevant.
<G-vec00169-001-s577><draw.stellen><de> Stellen Sie eine Umweltaussage auf, welche die Umweltqualitäten Ihres Produktes/Ihrer Dienstleistungen kommuniziert und die Vorgaben erfüllt, um verifizierbar, genau und relevant zu sein.
<G-vec00169-001-s578><draw.stellen><en> Use the online-service and let draw up your personal schedule.
<G-vec00169-001-s578><draw.stellen><de> Nutzen Sie den Onlinedienst und stellen Sie sich Ihren persönlichen Fahrplan zusammen.
<G-vec00169-001-s579><draw.stellen><en> Views 30 In the North Caucasus District Military Court in Rostov-on-Don, the judge returned the case of those accused of involvement to the prosecutor's office in the Yalta cell of the banned organization Hizb ut-Tahrir in order to draw up a new the indictment.
<G-vec00169-001-s579><draw.stellen><de> Ansichten 30 Im Militärgericht des Bezirks Nordkaukasus in Rostow am Don gab der Richter den Fall der Angeklagten an die Staatsanwaltschaft in der Jalta-Zelle der verbotenen Organisation Hizb ut-Tahrir zurück, um eine neue Anklage zu stellen.
<G-vec00169-001-s580><draw.stellen><en> (1) Before the beginning of each working year the members of the Enlarged Board of Appeal appointed under Article 11, paragraph 3, EPC shall draw up a business distribution scheme.
<G-vec00169-001-s580><draw.stellen><de> Geschäftsverteilung und Besetzung (1) Vor Beginn eines jeden Geschäftsjahres stellen die nach Artikel 11 Absatz 3 EPÜ ernannten Mitglieder der Großen Beschwerdekammer einen Geschäftsverteilungsplan auf.
<G-vec00169-001-s581><draw.stellen><en> However, few funds draw a connection between the “sustainability performance” and value development of the companies.
<G-vec00169-001-s581><draw.stellen><de> Allerdings stellen nur wenige Fonds einen Zusammenhang zwischen der „Nachhaltigkeitsperformance“ und der Wertentwicklung der Unternehmen her.
<G-vec00169-001-s582><draw.stellen><en> Then, we draw the animation slider to the 2/8 position and rotate the wheels another 45 degrees.
<G-vec00169-001-s582><draw.stellen><de> Anschließend stellen wir den Animationsschieber auf 2/8 und drehen wiederum 45 Grad weiter.
<G-vec00169-001-s583><draw.stellen><en> "Read User Report ""Our employees can draw on any information they need to support a customer."
<G-vec00169-001-s583><draw.stellen><de> „Unsere Mitarbeiter haben alle Informationen, die sie brauchen, um den Kunden zufrieden zu stellen.
<G-vec00169-001-s584><draw.stellen><en> Industry associations draw up similar lists, which also regularly recommend tabletop games.
<G-vec00169-001-s584><draw.stellen><de> Interessenverbände stellen ähnliche Listen auf, die auch regelmäßig Gesellschaftsspiele empfehlen.
<G-vec00169-001-s585><draw.stellen><en> """Our employees can draw on any information they need to support a customer."
<G-vec00169-001-s585><draw.stellen><de> „Unsere Mitarbeiter haben alle Informationen, die sie brauchen, um den Kunden zufrieden zu stellen.
<G-vec00169-001-s586><draw.stellen><en> Although this reading of St. Bernard s use of observances is not exhaustive, it would seem that we can attempt to draw up a list.
<G-vec00169-001-s586><draw.stellen><de> Wenn auch unsere Lektüre der Stellen, wo der heilige Bernhard von den Observanzen spricht, nicht erschöpfend war, können wir doch eine Liste aufzustellen versuchen, so scheint es.
<G-vec00169-001-s587><draw.stellen><en> On the left and on the right draw up dark rock faces - in the east, one dug a tunnel under the mountain which leads to the port.
<G-vec00169-001-s587><draw.stellen><de> Links und rechts stellen sich von dunklen Felswänden auf - im Osten hat man einen Tunnel unter dem Berg gegraben, der zum Hafen führt.
<G-vec00169-001-s588><draw.stellen><en> The bright New Year's composition on a reception will help to draw attention of visitors, the main thing that it was not too shouting.
<G-vec00169-001-s588><draw.stellen><de> Wenn bei Ihnen im Büro ressepschn ist (vergessen Sie nicht der Anmelderaum zu stellen), dort ist klein fein neujahrs- jelotschku, tisch- möglich.
<G-vec00169-001-s589><draw.unentschieden><en> It didn’t help his cause that when he was playing against Japan in what turned out to be a scoreless draw, his famous hot temper forced the referees to red card him.
<G-vec00169-001-s589><draw.unentschieden><de> Es half him nicht aus, dass als er gegen Japan spielte, was ein torloses Unentschieden war, sein beruehmter Jaehzorn den Schiedsrichter dazu brachte, die rote Karte zu ziehen.
<G-vec00169-001-s590><draw.unentschieden><en> If no side manages to destroy the other until then, we have a draw.
<G-vec00169-001-s590><draw.unentschieden><de> Schafft es bis dahin keine Partei die andere zu vernichten haben wir ein Unentschieden.
<G-vec00169-001-s591><draw.unentschieden><en> This Hermes 2012 Horse Draw Carriage Embossed Lichee Pattern Brown Gold comes with: Hermes authenticity card, Hermes tags, Hermes dust bag and Hermes care booklet.
<G-vec00169-001-s591><draw.unentschieden><de> dieseHermes 2012 Pferd Unentschieden Carriage Embossed Lichee Muster Braun Silberkommt mit: Hermes Echtheit Karte, Hermes Tags, Hermes Staubbeutel und Hermes Pflege Booklet.
<G-vec00169-001-s592><draw.unentschieden><en> It is here the game Win, Lose or Draw based on the famous TV series that in Quebec, it is also named, Fais-moi un dessin!, developed by Softie, Inc., but Published by Hi-Tech Expressions, Inc. in 1988.
<G-vec00169-001-s592><draw.unentschieden><de> Es ist hier der Spielgewinn, Verlieren oder Unentschieden basierend auf der berühmten TV-Serie, dass in Québec, aufgerufen, Machen Sie mir eine Zeichnung!, entwickelt von Softie, Inc., aber verteilt durch High-Tech-Ausdrücke, Inc.. de 1988.
<G-vec00169-001-s593><draw.unentschieden><en> When we´re on the pitch we don´t think about the other teams, but after the match we will watch their results and I hope that Bremen against Schalke will be a draw.
<G-vec00169-001-s593><draw.unentschieden><de> Nach dem Spiel gucken wir dann auf die anderen Resultate, und dann hoffe ich natürlich, dass Bremen gegen Schalke unentschieden ausgegangen ist.
<G-vec00169-001-s594><draw.unentschieden><en> What is very unique about the Euro Millions live draw is that after the main and lucky star draw machines have generated numbers, the studio system within 10 seconds informs viewers which countries, if any, have generated jackpot winners.
<G-vec00169-001-s594><draw.unentschieden><de> Was ist das Besondere an den Euro Millions Unentschieden leben ist, dass nach der Haupt-und Lucky Star Auslosung Maschinen-Nummern generiert haben, das Studio-System innerhalb von Sekunden 10 Zuschauer, die Länder, wenn überhaupt, Jackpot-Gewinner generiert haben informiert.
<G-vec00169-001-s595><draw.unentschieden><en> If it is a draw (both you and the computer make the same move), your bet is returned.
<G-vec00169-001-s595><draw.unentschieden><de> Bei einem Unentschieden (Sie und der Computer machen den gleichen Zug) erhalten Sie Ihren Einsatz zurück.
<G-vec00169-001-s596><draw.unentschieden><en> Players alternate until someone wins a tic-tac-toe or the game is a draw.
<G-vec00169-001-s596><draw.unentschieden><de> Die Spieler wechseln sich ab, bis jemand einen Tic-Tac-Toe gewinnt oder das Spiel unentschieden ist.
<G-vec00169-001-s597><draw.unentschieden><en> The match will mark the Selecao’s first return to the United Kingdom since former coach Luiz Felipe Scolari led the side to a 1-1 draw with Russia at Stamford Bridge in March 2013.
<G-vec00169-001-s597><draw.unentschieden><de> Das Spiel wird der Selecao erste Rückkehr in das Vereinigte Königreich zu markieren, da ehemalige Nationaltrainer Luiz Felipe Scolari führte die Seite ein 1-1 Unentschieden gegen Russland an der Stamford Bridge März 2013.
<G-vec00169-001-s598><draw.unentschieden><en> corresponding to the first draw.
<G-vec00169-001-s598><draw.unentschieden><de> entsprechend dem ersten Unentschieden.
<G-vec00169-001-s599><draw.unentschieden><en> Today, Cannavaro played 21 matches at his helm, of which 15 teams won, one played a draw and only five lost.
<G-vec00169-001-s599><draw.unentschieden><de> Heute spielte Cannavaro 21 Spiele an seiner Spitze, von denen 15 Teams gewonnen, eine Unentschieden gespielt und nur fünf verloren haben.
<G-vec00169-001-s600><draw.unentschieden><en> It’s rugged. There’s certainly nothing slim, smooth or cute about a Draw Tite hitch.
<G-vec00169-001-s600><draw.unentschieden><de> Thereâ € ™ s sicher nichts schlank, glatt oder niedlich über ein Unentschieden Tite Problem.
<G-vec00169-001-s601><draw.unentschieden><en> Now we have a draw in the foreground and the mouse pointer is a white cross shape.
<G-vec00169-001-s601><draw.unentschieden><de> Jetzt haben wir ein Unentschieden im Vordergrund und der Mauszeiger ist ein weißes Kreuz.
<G-vec00169-001-s602><draw.unentschieden><en> If no more move is possible, the game is scored as a draw.
<G-vec00169-001-s602><draw.unentschieden><de> Wenn kein Spielzug mehr möglich ist, gibt es ein Unentschieden.
<G-vec00169-001-s603><draw.unentschieden><en> If all numbers are used up without someone getting 15, the game is a draw.
<G-vec00169-001-s603><draw.unentschieden><de> Wenn alle Zahlen bis 15, ohne dass jemand immer verwendet werden, ist das Spiel unentschieden.
<G-vec00169-001-s604><draw.unentschieden><en> Set up Auto-Calculations in each column to calculate the required output (3 point for a win; 1 point for a draw; 0 points for a loss).
<G-vec00169-001-s604><draw.unentschieden><de> Definieren Sie in jeder Spalte automatische Berechnungen, um die erforderliche Ausgabe zu berechnen (3 Punkte für einen Sieg; 1 Punkt für ein Unentschieden; 0 Punkte für eine Niederlage).
<G-vec00169-001-s605><draw.unentschieden><en> Three points are awarded for a win, one point for a draw, and none for a defeat.
<G-vec00169-001-s605><draw.unentschieden><de> Ein Sieg ergibt drei Punkte, ein Unentschieden einen Punkt und eine Niederlage null Punkte.
<G-vec00169-001-s606><draw.unentschieden><en> These discrepancies will always appear to be a negative draw.
<G-vec00169-001-s606><draw.unentschieden><de> Diese Diskrepanzen werden immer wie ein negatives Unentschieden erscheinen.
<G-vec00169-001-s607><draw.unentschieden><en> Every day at noon in ports all over the world the sirens will sound for 30 seconds of ships as a form of protest recommended by BIMCO, the association representing the international shipping industry, to draw public attention to the problem of maritime piracy that threatens world trade and holding hostage about 800 seamen.
<G-vec00169-001-s607><draw.unentschieden><de> Jeden Tag mittags in den Häfen der ganzen Welt die Sirenen werden für 30 Sekunden von Schiffen als eine Form des Protestes durch BIMCO, dem Verband der internationalen Schifffahrt empfohlen Sound, die öffentliche Aufmerksamkeit auf das Problem der Unentschieden Piraterie auf See, dass der Welthandel und als Geisel genommen haben rund 800 Seeleute droht.
<G-vec00169-001-s627><draw.weisen><en> We draw your attention to the fact that the data transmission on the Internet may have security gaps.
<G-vec00169-001-s627><draw.weisen><de> Wir weisen darauf hin, dass die Datenübertragung im Internet Sicherheitslücken aufweisen kann.
<G-vec00169-001-s628><draw.weisen><en> Moreover, the referees also play an important role and draw attention to possible biases or works that the authors may have overlooked.
<G-vec00169-001-s628><draw.weisen><de> Außerdem spielen die Referees eine wichtige Rolle und weisen auf eventuelle Unausgewogenheiten oder Arbeiten hin, die die Autoren übersehen haben.
<G-vec00169-001-s629><draw.weisen><en> They draw our attention to a contemporary literary style, which was particularly used first by the Greek sophists, later by the cynical and stoical philosophers.
<G-vec00169-001-s629><draw.weisen><de> Sie weisen uns hin auf eine zeitgenössische literarische Stilform, die zuerst von den griechischen Sophisten, später besonders von den kynischen und stoischen Philosophen verwendet wurde.
<G-vec00169-001-s630><draw.weisen><en> We draw some fast corners and noticed the G force as accused without noticing the slightest loss of control, As the car is nailed to the floor.
<G-vec00169-001-s630><draw.weisen><de> Wir weisen einige schnelle Kurven und bemerkte die G-Kraft als Beschuldigten ohne den geringsten Verlust der Kontrolle zu bemerken, Als das Auto auf den Boden genagelt.
<G-vec00169-001-s631><draw.weisen><en> "Floormats with the lettering ""Prime Edition"" draw attention to the special status of the new model."
<G-vec00169-001-s631><draw.weisen><de> Fußmatten mit dem Schriftzug „Prime Edition“ weisen im Innenraum auf die Sonderstellung des neuen Modells hin.
<G-vec00169-001-s632><draw.weisen><en> (5) We draw your attention to the fact that we evaluate your user behaviour when the newsletter is sent.
<G-vec00169-001-s632><draw.weisen><de> (5) Wir weisen Sie darauf hin, dass wir bei Versand des Newsletters Ihr Nutzerverhalten auswerten.
<G-vec00169-001-s633><draw.weisen><en> When this is necessary, we draw your attention to it.
<G-vec00169-001-s633><draw.weisen><de> Wo dies erforderlich ist, weisen wir Sie entsprechend darauf hin.
<G-vec00169-001-s634><draw.weisen><en> We draw to attention that an attorney cannot guarantee a client success in litigation.
<G-vec00169-001-s634><draw.weisen><de> Wir weisen darauf hin, dass der Rechtsanwalt dem Mandanten nicht für einen Erfolg im Gerichtsverfahren garantiert.
<G-vec00169-001-s635><draw.weisen><en> We draw your attention to the fact that we as the provider of the website do not receive any notification of the content of the transmitted data as well as its use by Facebook.
<G-vec00169-001-s635><draw.weisen><de> Wir weisen darauf hin, dass wir als Anbieter der Seiten keine Kenntnis vom Inhalt der übermittelten Daten sowie deren Nutzung durch Facebook erhalten.
<G-vec00169-001-s636><draw.weisen><en> Finally, there are two options for regulation mechanisms. On the one hand, there is the intervention method (the process is automatically stopped in the event of an irregularity) and, on the other, there is the alarm method (acoustic or visual signals draw attention to the error).
<G-vec00169-001-s636><draw.weisen><de> Bei den Regulierungsmechanismen schließlich bieten sich zwei Möglichkeiten an: Zum einen die Eingriffsmethode (bei Unregelmäßigkeiten wird der Vorgang automatisch gestoppt), zum anderen die Alarmmethode (akustische oder optische Signale weisen auf den Fehler hin).
<G-vec00169-001-s637><draw.weisen><en> Should you choose to contact us by email, we would like to draw your attention to the following: personally identifiable information (name, address) which you provide to us will be stored electronically for the purpose of communication with you.
<G-vec00169-001-s637><draw.weisen><de> Falls Sie per E-Mail Kontakt mit uns aufnehmen möchten, weisen wir Sie auf Folgendes hin: Persönliche Daten (Name, Adresse), die Sie uns übermitteln, werden für Kommunikationszwecke mit Ihnen elektronisch gespeichert.
<G-vec00169-001-s638><draw.weisen><en> Because the manufacturer has no influence over the correct assembly, maintenance and operation we expressly draw these hazards to your attention.
<G-vec00169-001-s638><draw.weisen><de> Da der Hersteller keinen Einfluss auf ordnungsgemäßen Zusammenbau, Wartung und Betrieb hat, weisen wir ausdrücklich auf diese Gefahren hin.
<G-vec00169-001-s639><draw.weisen><en> We hereby draw your attention to the fact that in your country the possession and / or the operation of such a device might be not permitted.
<G-vec00169-001-s639><draw.weisen><de> Wir weisen Sie hiermit darauf hin, dass in Ihrem Land der Besitz und/oder der Betrieb eines solchen Gerätes nicht zulässig sein kann.
<G-vec00169-001-s640><draw.weisen><en> Furthermore you may prevent the storage of cookies in general or in the individual case by an adequate setting of your browser software; however, we draw your attention to the fact that you may then not be able to use all functions of this website to the full extent.
<G-vec00169-001-s640><draw.weisen><de> Ferner könnten Sie die Speicherung von Cookies generell oder im Einzelfall durch eine entsprechende Einstellung Ihrer Browser-Software verhindern; wir weisen Sie jedoch darauf hin, dass Sie in diesem Fall gegebenenfalls nicht sämtliche Funktionen dieser Webseite vollumfänglich nutzbar können.
<G-vec00169-001-s641><draw.weisen><en> We draw attention to the fact that, due to the technical design, in particular the fact that the service can be retrieved exclusively over the Internet, there may be interrup- tions in availability and times when the portal cannot be accessed.
<G-vec00169-001-s641><draw.weisen><de> Wir weisen darauf hin, dass es aufgrund der technischen Ausgestaltung, insbesondere der Abrufbarkeit ausschließlich über das Internet, zu Unterbrechungen der Verfügbarkeit und zu Zeiten der Nichterreichbarkeit des Portals kommen kann.
<G-vec00169-001-s642><draw.weisen><en> We draw your attention to the fact that we as the provider of the website do not receive any notification of the content of the transmitted data as well as its use by YouTube.
<G-vec00169-001-s642><draw.weisen><de> Wir weisen darauf hin, dass wir als Anbieter der Seiten keine Kenntnis vom Inhalt der übermittelten Daten sowie deren Nutzung durch Youtube erhalten.
<G-vec00169-001-s643><draw.weisen><en> The symbols of the bread and wine, chosen by the Lord for this mystery, draw our attention to the act of receiving.
<G-vec00169-001-s643><draw.weisen><de> Die Zeichen von Brot und Wein, die der Herr für sie gewählt hat, weisen auf das Empfangen hin.
<G-vec00169-001-s644><draw.weisen><en> If not clearly recognizable as such, we draw your attention to the fact that the link is an external link.
<G-vec00169-001-s644><draw.weisen><de> Soweit diese nicht offensichtlich erkennbar sind, weisen wir Sie darauf hin, dass es sich um einen externen Link handelt.
<G-vec00169-001-s645><draw.weisen><en> We draw the readers’ attention on the fact that the Koran testifies in favour of the “correct” reading of the Gospel, that means “as it was inspired”, according to the Koranic interpretation of “Al Jalalein”.
<G-vec00169-001-s645><draw.weisen><de> Wir weisen den Leser auf die Tatsache hin, dass der Koran die richtige Lektüre des Evangeliums bekräftigt, d.h. “wie es offenbart wurde”, so die Interpretation des Korans durch die “Jalalein”.
<G-vec00042-001-s646><draw.zeichnen><en> I don’t paint or draw very often anymore, since I have both music and lyrics to express myself through now.
<G-vec00042-001-s646><draw.zeichnen><de> Ich male oder zeichne nicht mehr sehr oft, da ich jetzt sowohl die Musik als auch die Texte habe, durch die ich mich ausdrücke.
<G-vec00042-001-s647><draw.zeichnen><en> Draw curves using a freehand tool, or move, stretch and condense groups of keyframes using the Transform box.
<G-vec00042-001-s647><draw.zeichnen><de> Zeichne Kurven mit einem Freihand werkzeug oder bewege, dehne und stauche Keyframe-Gruppen mit dem Feld „Transformieren“.
<G-vec00042-001-s648><draw.zeichnen><en> And I'm often a part of what I draw.
<G-vec00042-001-s648><draw.zeichnen><de> Ich bin ja ganz oft ein Teil von dem, was ich zeichne.
<G-vec00042-001-s649><draw.zeichnen><en> Draw generative tree diagrams of kernel sentences in English.
<G-vec00042-001-s649><draw.zeichnen><de> Zeichne generative Baumdiagramme von Kernsätzen in Englisch.
<G-vec00042-001-s650><draw.zeichnen><en> But this does not mean that the enterprise can not imitate, hardware enterprises can be innovated and developed in the process of imitation, as far as possible from the follow enterprise prototype draw something help to enterprise, take these as a foundation for the development of enterprises, and consistent with the innovative idea and the leading mode of the enterprise itself, in order to bring benefits to the enterprise.
<G-vec00042-001-s650><draw.zeichnen><de> Aber das bedeutet nicht, dass das Unternehmen nicht zu imitieren, Hardware können Unternehmen erneuert und in den Prozess der Nachahmung entwickelt, so weit wie möglich aus der Folge Unternehmen Prototyp zeichne etwas Hilfe, um Unternehmen sein, nehmen Sie diese als Grundlage für die Entwicklung von Unternehmen und im Einklang mit der innovativen Idee und dem führenden Modus des Unternehmens selbst, um die Vorteile für das Unternehmen zu bringen.
<G-vec00042-001-s651><draw.zeichnen><en> When I draw, I can reflect.
<G-vec00042-001-s651><draw.zeichnen><de> Wenn ich zeichne, kann ich nachdenken.
<G-vec00042-001-s652><draw.zeichnen><en> I draw an atomic blast there and that is ended.
<G-vec00042-001-s652><draw.zeichnen><de> Ich zeichne da eine Atomexplosion hin, und das ist beendet.
<G-vec00042-001-s653><draw.zeichnen><en> Draw the missing shapes to complete each pattern.
<G-vec00042-001-s653><draw.zeichnen><de> Zeichne die fehlenden Formen, um jede Reihe zu vervollständigen.
<G-vec00042-001-s654><draw.zeichnen><en> Draw a line through the points at which these new circles intersect.
<G-vec00042-001-s654><draw.zeichnen><de> Zeichne eine Linie durch die Punkte, an denen sich die neuen Kreise überschneiden.
<G-vec00042-001-s655><draw.zeichnen><en> Draw a line along the new crease.
<G-vec00042-001-s655><draw.zeichnen><de> Zeichne entlang dieses neuen Knicks eine Linie.
<G-vec00042-001-s656><draw.zeichnen><en> I sketch them out, afterwards I decide whether I will continue to edit on photoshop with fonts or draw it myself completely.
<G-vec00042-001-s656><draw.zeichnen><de> Ich fertige Skizzen an und entscheide anschließend ob ich sie mit Fonts in Photoshop weiter ausarbeite oder sie komplett selbst zeichne.
<G-vec00042-001-s657><draw.zeichnen><en> Draw a line.
<G-vec00042-001-s657><draw.zeichnen><de> Zeichne eine Linie.
<G-vec00042-001-s658><draw.zeichnen><en> On Easter Monday, during shows and other occasions, I draw signs onto Easter eggs: fulfilling the requests of my sprinklers.
<G-vec00042-001-s658><draw.zeichnen><de> Am Ostermontag, in Vorstellungen und bei anderen Anlässen: zeichne ich die Symbole auf Eier, damit werden die Wünsche der Einzelpersonen erfüllt.
<G-vec00042-001-s659><draw.zeichnen><en> Draw this outline lightly so you can erase any unnecessary pencil marks later in the process.
<G-vec00042-001-s659><draw.zeichnen><de> Zeichne diesen Umriss leicht, so dass du später alle unnötigen Bleistiftstriche wegradieren kannst.
<G-vec00042-001-s660><draw.zeichnen><en> Draw a slanted oval.
<G-vec00042-001-s660><draw.zeichnen><de> Zeichne ein schräges Oval.
<G-vec00042-001-s661><draw.zeichnen><en> Draw or write out the theme or plot of your favorite book or movie.
<G-vec00042-001-s661><draw.zeichnen><de> Zeichne oder beschreibe das Thema oder die Handlung deines Lieblingsbuchs oder –films.
<G-vec00042-001-s662><draw.zeichnen><en> Powers of observation, report writing, quick decisions about life or death matters, they are just a few of the nursing skills I still draw on each day.
<G-vec00042-001-s662><draw.zeichnen><de> Energien der Beobachtung, des Verfassens von Berichten, der schnellen Entscheidungen über das Leben oder der Todesstoffe, sind- sie einige der Krankenpflegefähigkeiten gerecht, die ich noch an jedem Tag zeichne.
<G-vec00042-001-s663><draw.zeichnen><en> Draw a bow that is pointing to the left for the first part for the mouth.
<G-vec00042-001-s663><draw.zeichnen><de> Zeichne einen Bogen, der nach links zeigt, als ersten Teil des Mundes.
<G-vec00042-001-s664><draw.zeichnen><en> Use hot pink lipstick or eyeliner to draw a little heart on your cheek like Draculaura's.
<G-vec00042-001-s664><draw.zeichnen><de> Benutze deinen pinken Lippenstift oder Eyeliner und zeichne dir ein kleines Herz auf die Wange, ganz wie bei Draculaura.
<G-vec00169-001-s646><draw.zeichnen><en> I don’t paint or draw very often anymore, since I have both music and lyrics to express myself through now.
<G-vec00169-001-s646><draw.zeichnen><de> Ich male oder zeichne nicht mehr sehr oft, da ich jetzt sowohl die Musik als auch die Texte habe, durch die ich mich ausdrücke.
<G-vec00169-001-s647><draw.zeichnen><en> Draw curves using a freehand tool, or move, stretch and condense groups of keyframes using the Transform box.
<G-vec00169-001-s647><draw.zeichnen><de> Zeichne Kurven mit einem Freihand werkzeug oder bewege, dehne und stauche Keyframe-Gruppen mit dem Feld „Transformieren“.
<G-vec00169-001-s648><draw.zeichnen><en> And I'm often a part of what I draw.
<G-vec00169-001-s648><draw.zeichnen><de> Ich bin ja ganz oft ein Teil von dem, was ich zeichne.
<G-vec00169-001-s649><draw.zeichnen><en> Draw generative tree diagrams of kernel sentences in English.
<G-vec00169-001-s649><draw.zeichnen><de> Zeichne generative Baumdiagramme von Kernsätzen in Englisch.
<G-vec00169-001-s650><draw.zeichnen><en> But this does not mean that the enterprise can not imitate, hardware enterprises can be innovated and developed in the process of imitation, as far as possible from the follow enterprise prototype draw something help to enterprise, take these as a foundation for the development of enterprises, and consistent with the innovative idea and the leading mode of the enterprise itself, in order to bring benefits to the enterprise.
<G-vec00169-001-s650><draw.zeichnen><de> Aber das bedeutet nicht, dass das Unternehmen nicht zu imitieren, Hardware können Unternehmen erneuert und in den Prozess der Nachahmung entwickelt, so weit wie möglich aus der Folge Unternehmen Prototyp zeichne etwas Hilfe, um Unternehmen sein, nehmen Sie diese als Grundlage für die Entwicklung von Unternehmen und im Einklang mit der innovativen Idee und dem führenden Modus des Unternehmens selbst, um die Vorteile für das Unternehmen zu bringen.
<G-vec00169-001-s651><draw.zeichnen><en> When I draw, I can reflect.
<G-vec00169-001-s651><draw.zeichnen><de> Wenn ich zeichne, kann ich nachdenken.
<G-vec00169-001-s652><draw.zeichnen><en> I draw an atomic blast there and that is ended.
<G-vec00169-001-s652><draw.zeichnen><de> Ich zeichne da eine Atomexplosion hin, und das ist beendet.
<G-vec00169-001-s653><draw.zeichnen><en> Draw the missing shapes to complete each pattern.
<G-vec00169-001-s653><draw.zeichnen><de> Zeichne die fehlenden Formen, um jede Reihe zu vervollständigen.
<G-vec00169-001-s654><draw.zeichnen><en> Draw a line through the points at which these new circles intersect.
<G-vec00169-001-s654><draw.zeichnen><de> Zeichne eine Linie durch die Punkte, an denen sich die neuen Kreise überschneiden.
<G-vec00169-001-s655><draw.zeichnen><en> Draw a line along the new crease.
<G-vec00169-001-s655><draw.zeichnen><de> Zeichne entlang dieses neuen Knicks eine Linie.
<G-vec00169-001-s656><draw.zeichnen><en> I sketch them out, afterwards I decide whether I will continue to edit on photoshop with fonts or draw it myself completely.
<G-vec00169-001-s656><draw.zeichnen><de> Ich fertige Skizzen an und entscheide anschließend ob ich sie mit Fonts in Photoshop weiter ausarbeite oder sie komplett selbst zeichne.
<G-vec00169-001-s657><draw.zeichnen><en> Draw a line.
<G-vec00169-001-s657><draw.zeichnen><de> Zeichne eine Linie.
<G-vec00169-001-s658><draw.zeichnen><en> On Easter Monday, during shows and other occasions, I draw signs onto Easter eggs: fulfilling the requests of my sprinklers.
<G-vec00169-001-s658><draw.zeichnen><de> Am Ostermontag, in Vorstellungen und bei anderen Anlässen: zeichne ich die Symbole auf Eier, damit werden die Wünsche der Einzelpersonen erfüllt.
<G-vec00169-001-s659><draw.zeichnen><en> Draw this outline lightly so you can erase any unnecessary pencil marks later in the process.
<G-vec00169-001-s659><draw.zeichnen><de> Zeichne diesen Umriss leicht, so dass du später alle unnötigen Bleistiftstriche wegradieren kannst.
<G-vec00169-001-s660><draw.zeichnen><en> Draw a slanted oval.
<G-vec00169-001-s660><draw.zeichnen><de> Zeichne ein schräges Oval.
<G-vec00169-001-s661><draw.zeichnen><en> Draw or write out the theme or plot of your favorite book or movie.
<G-vec00169-001-s661><draw.zeichnen><de> Zeichne oder beschreibe das Thema oder die Handlung deines Lieblingsbuchs oder –films.
<G-vec00169-001-s662><draw.zeichnen><en> Powers of observation, report writing, quick decisions about life or death matters, they are just a few of the nursing skills I still draw on each day.
<G-vec00169-001-s662><draw.zeichnen><de> Energien der Beobachtung, des Verfassens von Berichten, der schnellen Entscheidungen über das Leben oder der Todesstoffe, sind- sie einige der Krankenpflegefähigkeiten gerecht, die ich noch an jedem Tag zeichne.
<G-vec00169-001-s663><draw.zeichnen><en> Draw a bow that is pointing to the left for the first part for the mouth.
<G-vec00169-001-s663><draw.zeichnen><de> Zeichne einen Bogen, der nach links zeigt, als ersten Teil des Mundes.
<G-vec00169-001-s664><draw.zeichnen><en> Use hot pink lipstick or eyeliner to draw a little heart on your cheek like Draculaura's.
<G-vec00169-001-s664><draw.zeichnen><de> Benutze deinen pinken Lippenstift oder Eyeliner und zeichne dir ein kleines Herz auf die Wange, ganz wie bei Draculaura.
<G-vec00042-001-s665><draw.zeichnen><en> First of all, we draw a circle for the head, a long wavy line for the body and guides for the legs.
<G-vec00042-001-s665><draw.zeichnen><de> Zeichnen Sie zuerst einen Kreis für den Kopf, eine lange Wellenlinie für den Körper und Führungen für die Beine.
<G-vec00042-001-s666><draw.zeichnen><en> Began to draw and paint in 2011, autodidact, using acrylic...
<G-vec00042-001-s666><draw.zeichnen><de> Begann zu zeichnen und zu malen in 2011, Autodidakt, Verwendung von Acryl...
<G-vec00042-001-s667><draw.zeichnen><en> Draw a pencil line on parallel lines.
<G-vec00042-001-s667><draw.zeichnen><de> Zeichnen Sie ein Bleistiftstrich auf parallelen Linien.
<G-vec00042-001-s668><draw.zeichnen><en> "Draw the way and then let her go by pressing the ""Go"" button on the right upper side of the screen."
<G-vec00042-001-s668><draw.zeichnen><de> "Die Art und Weise zu zeichnen und dann lass sie gehen mit der ""Go"" Taste auf der rechten oberen Seite des Bildschirms."
<G-vec00042-001-s669><draw.zeichnen><en> Sign the day in the calendar with a pen, draw a good bad day.
<G-vec00042-001-s669><draw.zeichnen><de> Unterzeichnen Sie den Tag im Kalender mit einem Stift, zeichnen Sie einen guten schlechten Tag.
<G-vec00042-001-s670><draw.zeichnen><en> Parameters: timeframe momentum period, price, draw indicator trendlines, draw price trendlines, draw lines identificator, display alert, alerts message, alerts sound, alerts email, alerts push notification.
<G-vec00042-001-s670><draw.zeichnen><de> Parameter: Zeitraum Dynamik Periode, Preis, zeichnen Indikator Trendlinien, zeichnen Preis Trendlinien, Linien zeichnen Identificator, Anzeige Alarm, Warnungen Meldung, Warnungen klingen, Benachrichtigung E-Mail, Benachrichtigungen Push-Benachrichtigung.
<G-vec00042-001-s671><draw.zeichnen><en> Parameters: timeframe momentum period, price, draw indicator trendlines, draw price trendlines, draw lines identificator, display alert, alerts message, alerts sound, alerts email, alerts push notification.
<G-vec00042-001-s671><draw.zeichnen><de> Parameter: Zeitraum Dynamik Periode, Preis, zeichnen Indikator Trendlinien, zeichnen Preis Trendlinien, Linien zeichnen Identificator, Anzeige Alarm, Warnungen Meldung, Warnungen klingen, Benachrichtigung E-Mail, Benachrichtigungen Push-Benachrichtigung.
<G-vec00042-001-s672><draw.zeichnen><en> From a contour to the center to draw in serially different flowers a shape of heart.
<G-vec00042-001-s672><draw.zeichnen><de> Von der Kontur zum Zentrum, von abwechselnd verschiedenen Farben die Form des Herzes zu zeichnen.
<G-vec00042-001-s673><draw.zeichnen><en> 2007-11-13 22:16:19 - Start your wine cellar the right way One of the great joys of wine is to be able to select a bottle from your own cellar, perhaps one that you've been storing for some years, draw the cork and enjoy it with friends.
<G-vec00042-001-s673><draw.zeichnen><de> 2007-11-13 22:16:19 - Beginnen Sie Ihren Weinkeller Die Rechte Weise Eine der großen Freuden am Wein soll in der LageSEIN, eine Flasche von Ihrem eigenen Keller vorzuwählen, möglicherweise einer, den Sie ihn mit Freunden gespeichert für einige Jahre, zeichnen den Korken und genießen haben.
<G-vec00042-001-s674><draw.zeichnen><en> Drawing in the game works perfectly on this mobile form as you use your finger to draw shapes.
<G-vec00042-001-s674><draw.zeichnen><de> Zeichnung in das Spiel funktioniert perfekt auf dieser mobil, wie Sie Ihren Finger verwenden, um Formen zu zeichnen.
<G-vec00042-001-s675><draw.zeichnen><en> Tap Aa to add text, to add a sticker, or to draw on your photo or video.
<G-vec00042-001-s675><draw.zeichnen><de> Tippe auf Aa, um Text hinzuzufügen, auf, um einen Sticker hinzuzufügen oder auf, um etwas in dein Foto oder Video zu zeichnen.
<G-vec00042-001-s676><draw.zeichnen><en> The sheep can be cheerful or sad, we will accurately draw in detail a mouth a needle tip.
<G-vec00042-001-s676><draw.zeichnen><de> Das Schaf kann lustig oder traurig sein, rotik werden wir von der Spitze der Nadel akkurat zeichnen.
<G-vec00042-001-s677><draw.zeichnen><en> Productivity: In order to simplify communication and avoid switching between different applications, the EFSS should allow users to access, create, annotate (highlight, annotate, draw, erase), edit, search and share files.
<G-vec00042-001-s677><draw.zeichnen><de> Produktivität: Zugreifen, erstellen, annotieren (hervorheben, kommentieren, zeichnen, ausradieren), editieren, suchen, streamen und Filesharing soll möglich sein, um nicht ständig von App zu App wechseln zu müssen und zusätzlich die Kommunikation zu vereinfachen.
<G-vec00042-001-s678><draw.zeichnen><en> Actually, there isn’t a direct way to add the arrows to the column bar, but you can draw the arrow shapes and copy them to the column chart.
<G-vec00042-001-s678><draw.zeichnen><de> Eigentlich gibt es keine direkte Möglichkeit, die Pfeile zur Spaltenleiste hinzuzufügen, aber Sie können die Pfeilformen zeichnen und in das Säulendiagramm kopieren.
<G-vec00042-001-s679><draw.zeichnen><en> One can now determine the readings off for further points at different distances, and with them draw a scale, on which one can directly read off the distances.
<G-vec00042-001-s679><draw.zeichnen><de> Nun kann man sich für verschieden entfernte Punkte die Ablesung ermitteln, und damit eine Skala zeichnen, auf der man gleich die Entfernungen ablesen kann.
<G-vec00042-001-s680><draw.zeichnen><en> We examined the basic principles of how to draw a rhinoceros.
<G-vec00042-001-s680><draw.zeichnen><de> Wir haben die Grundprinzipien für das Zeichnen eines Nashorns untersucht.
<G-vec00042-001-s681><draw.zeichnen><en> For a better illustration, we create various material nodes and draw two overlapping PlaneGeometry objects with each node.
<G-vec00042-001-s681><draw.zeichnen><de> Zur besseren Veranschaulichung erstellen wir verschiedene Materialknoten und zeichnen damit jeweils zwei überlappende PlaneGeometry-Objekte.
<G-vec00042-001-s682><draw.zeichnen><en> Apart from the simple application to draw the trim NOMASTYL ® PLUS stands for high strength.
<G-vec00042-001-s682><draw.zeichnen><de> Neben der einfachen Anwendung zeichnen sich die Zierleisten NOMASTYL® PLUS durch hohe Festigkeit aus.
<G-vec00042-001-s683><draw.zeichnen><en> In case you draw one character in a several strokes and the time interval between drawing each stroke is less than the recognition delay time, the result will be automatically modified.
<G-vec00042-001-s683><draw.zeichnen><de> Für den Fall, dass Sie ein Zeichen mit einem Strich zeichnen und das Zeitintervall zwischen dem Zeichnen eines Striches kürzer ist als die Erkennungszeit, wird das Ergebnis automatisch geändert.
<G-vec00169-001-s665><draw.zeichnen><en> First of all, we draw a circle for the head, a long wavy line for the body and guides for the legs.
<G-vec00169-001-s665><draw.zeichnen><de> Zeichnen Sie zuerst einen Kreis für den Kopf, eine lange Wellenlinie für den Körper und Führungen für die Beine.
<G-vec00169-001-s666><draw.zeichnen><en> Began to draw and paint in 2011, autodidact, using acrylic...
<G-vec00169-001-s666><draw.zeichnen><de> Begann zu zeichnen und zu malen in 2011, Autodidakt, Verwendung von Acryl...
<G-vec00169-001-s667><draw.zeichnen><en> Draw a pencil line on parallel lines.
<G-vec00169-001-s667><draw.zeichnen><de> Zeichnen Sie ein Bleistiftstrich auf parallelen Linien.
<G-vec00169-001-s668><draw.zeichnen><en> "Draw the way and then let her go by pressing the ""Go"" button on the right upper side of the screen."
<G-vec00169-001-s668><draw.zeichnen><de> "Die Art und Weise zu zeichnen und dann lass sie gehen mit der ""Go"" Taste auf der rechten oberen Seite des Bildschirms."
<G-vec00169-001-s669><draw.zeichnen><en> Sign the day in the calendar with a pen, draw a good bad day.
<G-vec00169-001-s669><draw.zeichnen><de> Unterzeichnen Sie den Tag im Kalender mit einem Stift, zeichnen Sie einen guten schlechten Tag.
<G-vec00169-001-s670><draw.zeichnen><en> Parameters: timeframe momentum period, price, draw indicator trendlines, draw price trendlines, draw lines identificator, display alert, alerts message, alerts sound, alerts email, alerts push notification.
<G-vec00169-001-s670><draw.zeichnen><de> Parameter: Zeitraum Dynamik Periode, Preis, zeichnen Indikator Trendlinien, zeichnen Preis Trendlinien, Linien zeichnen Identificator, Anzeige Alarm, Warnungen Meldung, Warnungen klingen, Benachrichtigung E-Mail, Benachrichtigungen Push-Benachrichtigung.
<G-vec00169-001-s671><draw.zeichnen><en> Parameters: timeframe momentum period, price, draw indicator trendlines, draw price trendlines, draw lines identificator, display alert, alerts message, alerts sound, alerts email, alerts push notification.
<G-vec00169-001-s671><draw.zeichnen><de> Parameter: Zeitraum Dynamik Periode, Preis, zeichnen Indikator Trendlinien, zeichnen Preis Trendlinien, Linien zeichnen Identificator, Anzeige Alarm, Warnungen Meldung, Warnungen klingen, Benachrichtigung E-Mail, Benachrichtigungen Push-Benachrichtigung.
<G-vec00169-001-s672><draw.zeichnen><en> From a contour to the center to draw in serially different flowers a shape of heart.
<G-vec00169-001-s672><draw.zeichnen><de> Von der Kontur zum Zentrum, von abwechselnd verschiedenen Farben die Form des Herzes zu zeichnen.
<G-vec00169-001-s673><draw.zeichnen><en> 2007-11-13 22:16:19 - Start your wine cellar the right way One of the great joys of wine is to be able to select a bottle from your own cellar, perhaps one that you've been storing for some years, draw the cork and enjoy it with friends.
<G-vec00169-001-s673><draw.zeichnen><de> 2007-11-13 22:16:19 - Beginnen Sie Ihren Weinkeller Die Rechte Weise Eine der großen Freuden am Wein soll in der LageSEIN, eine Flasche von Ihrem eigenen Keller vorzuwählen, möglicherweise einer, den Sie ihn mit Freunden gespeichert für einige Jahre, zeichnen den Korken und genießen haben.
<G-vec00169-001-s674><draw.zeichnen><en> Drawing in the game works perfectly on this mobile form as you use your finger to draw shapes.
<G-vec00169-001-s674><draw.zeichnen><de> Zeichnung in das Spiel funktioniert perfekt auf dieser mobil, wie Sie Ihren Finger verwenden, um Formen zu zeichnen.
<G-vec00169-001-s675><draw.zeichnen><en> Tap Aa to add text, to add a sticker, or to draw on your photo or video.
<G-vec00169-001-s675><draw.zeichnen><de> Tippe auf Aa, um Text hinzuzufügen, auf, um einen Sticker hinzuzufügen oder auf, um etwas in dein Foto oder Video zu zeichnen.
<G-vec00169-001-s676><draw.zeichnen><en> The sheep can be cheerful or sad, we will accurately draw in detail a mouth a needle tip.
<G-vec00169-001-s676><draw.zeichnen><de> Das Schaf kann lustig oder traurig sein, rotik werden wir von der Spitze der Nadel akkurat zeichnen.
<G-vec00169-001-s677><draw.zeichnen><en> Productivity: In order to simplify communication and avoid switching between different applications, the EFSS should allow users to access, create, annotate (highlight, annotate, draw, erase), edit, search and share files.
<G-vec00169-001-s677><draw.zeichnen><de> Produktivität: Zugreifen, erstellen, annotieren (hervorheben, kommentieren, zeichnen, ausradieren), editieren, suchen, streamen und Filesharing soll möglich sein, um nicht ständig von App zu App wechseln zu müssen und zusätzlich die Kommunikation zu vereinfachen.
<G-vec00169-001-s678><draw.zeichnen><en> Actually, there isn’t a direct way to add the arrows to the column bar, but you can draw the arrow shapes and copy them to the column chart.
<G-vec00169-001-s678><draw.zeichnen><de> Eigentlich gibt es keine direkte Möglichkeit, die Pfeile zur Spaltenleiste hinzuzufügen, aber Sie können die Pfeilformen zeichnen und in das Säulendiagramm kopieren.
<G-vec00169-001-s679><draw.zeichnen><en> One can now determine the readings off for further points at different distances, and with them draw a scale, on which one can directly read off the distances.
<G-vec00169-001-s679><draw.zeichnen><de> Nun kann man sich für verschieden entfernte Punkte die Ablesung ermitteln, und damit eine Skala zeichnen, auf der man gleich die Entfernungen ablesen kann.
<G-vec00169-001-s680><draw.zeichnen><en> We examined the basic principles of how to draw a rhinoceros.
<G-vec00169-001-s680><draw.zeichnen><de> Wir haben die Grundprinzipien für das Zeichnen eines Nashorns untersucht.
<G-vec00169-001-s681><draw.zeichnen><en> For a better illustration, we create various material nodes and draw two overlapping PlaneGeometry objects with each node.
<G-vec00169-001-s681><draw.zeichnen><de> Zur besseren Veranschaulichung erstellen wir verschiedene Materialknoten und zeichnen damit jeweils zwei überlappende PlaneGeometry-Objekte.
<G-vec00169-001-s682><draw.zeichnen><en> Apart from the simple application to draw the trim NOMASTYL ® PLUS stands for high strength.
<G-vec00169-001-s682><draw.zeichnen><de> Neben der einfachen Anwendung zeichnen sich die Zierleisten NOMASTYL® PLUS durch hohe Festigkeit aus.
<G-vec00169-001-s683><draw.zeichnen><en> In case you draw one character in a several strokes and the time interval between drawing each stroke is less than the recognition delay time, the result will be automatically modified.
<G-vec00169-001-s683><draw.zeichnen><de> Für den Fall, dass Sie ein Zeichen mit einem Strich zeichnen und das Zeitintervall zwischen dem Zeichnen eines Striches kürzer ist als die Erkennungszeit, wird das Ergebnis automatisch geändert.
<G-vec00042-001-s684><draw.zeichnen><en> Tattoo School: how to draw a cat in realistic style (part 1).
<G-vec00042-001-s684><draw.zeichnen><de> Tattoo-School: So zeichnet man eine Katze im Realistic-Stil (Teil 1).
<G-vec00042-001-s685><draw.zeichnen><en> S draw HP-GL lines using strokes with the appropriate ends (round or square).
<G-vec00042-001-s685><draw.zeichnen><de> S zeichnet HP-GL-Linien mittels Strichen der entsprechenden Kopfenden (rund oder viereckig).
<G-vec00042-001-s686><draw.zeichnen><en> I have always thought that the lighting object takes shape from the light source, through a design concept aimed at solving needs.... on the sheet you draw the bulb, you add a ground plane, maybe a deposit for books or music, and why not, endless profiles of lamps that envelop the light..... Also available with a writable surface with markers for the whiteboard.
<G-vec00042-001-s686><draw.zeichnen><de> Ich habe immer gedacht, dass das Lichtobjekt Form von der Lichtquelle annimmt, durch ein Designkonzept, das auf die Lösung der Bedürfnisse ausgerichtet ist..... auf dem Blatt, auf dem man die Glühbirne zeichnet, fügt man eine Grundplatte hinzu, vielleicht eine Kaution für Bücher oder Musik, und warum nicht, endlose Profile von Lampen, die das Licht umhüllen........ Auch mit beschreibbarer Oberfläche mit Markern für das Whiteboard erhältlich.
<G-vec00042-001-s687><draw.zeichnen><en> To do that, you simply draw two overlapping circles on a cardboard and cut out the overlapping part.
<G-vec00042-001-s687><draw.zeichnen><de> Dazu zeichnet man sich einfach zwei überlappende Kreise auf eine stärkere Pappe und schneidet den überlappenden Teil aus.
<G-vec00042-001-s688><draw.zeichnen><en> "At the same time the concept does not draw the simple picture of an open door (as in ""leaving the door open ajar""), of letting someone into a room and engaging with the one thus admitted, of a possible integration into an already existing territory."
<G-vec00042-001-s688><draw.zeichnen><de> "Der Begriff zeichnet aber auch nicht einfach nur das Bild einer offenen Türe (wie in ""die Türe einen Spalt weit offen lassen""), des Einlassens in einen Raum und auf die oder den Eingelassene/n, der möglichen Integration in ein schon bestehendes Territorium."
<G-vec00042-001-s689><draw.zeichnen><en> When architects design a building or artists draw a painting, they first conceive the work that would be completed in their minds before they actually begin working on their project.
<G-vec00042-001-s689><draw.zeichnen><de> Wenn Architekten ein Gebäude entwerfen oder ein Künstler ein Gemälde zeichnet, stellen sie sich das Werk zuerst in ihren Gedanken abgeschlossen vor, bevor sie tatsächlich mit der Arbeit an ihrem Projekt beginnen.
<G-vec00042-001-s690><draw.zeichnen><en> Draw a plane instead of using an existing surface as the base objects.
<G-vec00042-001-s690><draw.zeichnen><de> Zeichnet eine Ebene anstatt dass eine bestehende Fläche als Basisobjekt verwendet wird.
<G-vec00042-001-s691><draw.zeichnen><en> Situations that we experience or read about or hear about may well draw exclamations of disapproval from us, but how often do we actively choose to do something about it.
<G-vec00042-001-s691><draw.zeichnen><de> Situationen, der wir erfahren oder ungefähr lasen oder ungefähr zeichnet Ausrufe der Mißbilligung von uns vielleicht gut hören, aber wie oft macht, wir wählen aktiv, etwas dagegen zu machen.
<G-vec00042-001-s692><draw.zeichnen><en> First you should draw the design on the buckskin with a pen.
<G-vec00042-001-s692><draw.zeichnen><de> Als erstes zeichnet man mit einem Stift das Design auf das Leder.
<G-vec00042-001-s693><draw.zeichnen><en> Draw the specified image directly to the vector drawing output.
<G-vec00042-001-s693><draw.zeichnen><de> Zeichnet das angegebene Bild direkt in die Vektorzeichnen-Ausgabe.
<G-vec00042-001-s694><draw.zeichnen><en> Draw an arc tangent to existing curves.
<G-vec00042-001-s694><draw.zeichnen><de> Zeichnet einen Bogen tangential zu existierenden Kurven.
<G-vec00042-001-s695><draw.zeichnen><en> Tattoo school: find out how to draw a deer's head .
<G-vec00042-001-s695><draw.zeichnen><de> Tattoo School: Wir zeigen dir, wie man einen Hirschkopf zeichnet.
<G-vec00042-001-s696><draw.zeichnen><en> If you double down, the dealer will give you only one more card and then draw the cards needed to complete his own hand.
<G-vec00042-001-s696><draw.zeichnen><de> Wenn Sie unten verdoppeln, gibt der Händler Ihnen nur eine weitere Karte und zeichnet dann die Karten, die benötigt werden, um seine eigene Hand durchzuführen.
<G-vec00042-001-s697><draw.zeichnen><en> Between two points will draw a line between two selected points.
<G-vec00042-001-s697><draw.zeichnen><de> Linie zeichnet eine Linie zwischen zwei ausgewählten Punkten.
<G-vec00042-001-s698><draw.zeichnen><en> Draw a circle tangent to existing curves.
<G-vec00042-001-s698><draw.zeichnen><de> Zeichnet einen Kreis tangential zu existierenden Kurven.
<G-vec00042-001-s699><draw.zeichnen><en> Draw a solid sphere, from center and radius.
<G-vec00042-001-s699><draw.zeichnen><de> Zeichnet eine Kugel, definiert durch Mittelpunkt und Radius.
<G-vec00042-001-s700><draw.zeichnen><en> "Chinese knowledge of this ""chi"" was on such an advanced level, that even today people constantly draw from it."
<G-vec00042-001-s700><draw.zeichnen><de> "nennen), Chinesisches Wissen dieses ""Chi"" war auf solch einem vorgercktem Niveau, diese gleichmigen Tagleute zeichnet stndig von ihm."
<G-vec00042-001-s701><draw.zeichnen><en> It draw the TPOs as letters or blocks the way you want, detects the TPO value area(not the volume VA) of the percentage you detect (0.7 is the default) and shows the Point of control of the day and the Initial Balance plus the opening flag for all of a number of days.
<G-vec00042-001-s701><draw.zeichnen><de> Es zeichnet die TPO als Buchstaben oder Blöcke, wie Sie wollen, detektiert den TPO-Wert-Bereich(nicht das Volumen VA) der Prozentsatz, den Sie erfassen (0.7 ist die Standardeinstellung) und zeigt den Punkt der Kontrolle über den Tag und die Eröffnungssaldo plus der Öffnung Flagge für alle eine Anzahl von Tagen.
<G-vec00042-001-s702><draw.zeichnen><en> When architects design a building or artists draw a painting, they first conceive the work that would be completed in their minds before they actually begin working on their project. Just like this, our
<G-vec00042-001-s702><draw.zeichnen><de> Wenn Architekten ein Gebäude entwerfen oder ein Künstler ein Gemälde zeichnet, stellen sie sich das Werk zuerst in ihren Gedanken abgeschlossen vor, bevor sie tatsächlich mit der Arbeit an ihrem Projekt beginnen.
<G-vec00169-001-s684><draw.zeichnen><en> Tattoo School: how to draw a cat in realistic style (part 1).
<G-vec00169-001-s684><draw.zeichnen><de> Tattoo-School: So zeichnet man eine Katze im Realistic-Stil (Teil 1).
<G-vec00169-001-s685><draw.zeichnen><en> S draw HP-GL lines using strokes with the appropriate ends (round or square).
<G-vec00169-001-s685><draw.zeichnen><de> S zeichnet HP-GL-Linien mittels Strichen der entsprechenden Kopfenden (rund oder viereckig).
<G-vec00169-001-s686><draw.zeichnen><en> I have always thought that the lighting object takes shape from the light source, through a design concept aimed at solving needs.... on the sheet you draw the bulb, you add a ground plane, maybe a deposit for books or music, and why not, endless profiles of lamps that envelop the light..... Also available with a writable surface with markers for the whiteboard.
<G-vec00169-001-s686><draw.zeichnen><de> Ich habe immer gedacht, dass das Lichtobjekt Form von der Lichtquelle annimmt, durch ein Designkonzept, das auf die Lösung der Bedürfnisse ausgerichtet ist..... auf dem Blatt, auf dem man die Glühbirne zeichnet, fügt man eine Grundplatte hinzu, vielleicht eine Kaution für Bücher oder Musik, und warum nicht, endlose Profile von Lampen, die das Licht umhüllen........ Auch mit beschreibbarer Oberfläche mit Markern für das Whiteboard erhältlich.
<G-vec00169-001-s687><draw.zeichnen><en> To do that, you simply draw two overlapping circles on a cardboard and cut out the overlapping part.
<G-vec00169-001-s687><draw.zeichnen><de> Dazu zeichnet man sich einfach zwei überlappende Kreise auf eine stärkere Pappe und schneidet den überlappenden Teil aus.
<G-vec00169-001-s688><draw.zeichnen><en> "At the same time the concept does not draw the simple picture of an open door (as in ""leaving the door open ajar""), of letting someone into a room and engaging with the one thus admitted, of a possible integration into an already existing territory."
<G-vec00169-001-s688><draw.zeichnen><de> "Der Begriff zeichnet aber auch nicht einfach nur das Bild einer offenen Türe (wie in ""die Türe einen Spalt weit offen lassen""), des Einlassens in einen Raum und auf die oder den Eingelassene/n, der möglichen Integration in ein schon bestehendes Territorium."
<G-vec00169-001-s689><draw.zeichnen><en> When architects design a building or artists draw a painting, they first conceive the work that would be completed in their minds before they actually begin working on their project.
<G-vec00169-001-s689><draw.zeichnen><de> Wenn Architekten ein Gebäude entwerfen oder ein Künstler ein Gemälde zeichnet, stellen sie sich das Werk zuerst in ihren Gedanken abgeschlossen vor, bevor sie tatsächlich mit der Arbeit an ihrem Projekt beginnen.
<G-vec00169-001-s690><draw.zeichnen><en> Draw a plane instead of using an existing surface as the base objects.
<G-vec00169-001-s690><draw.zeichnen><de> Zeichnet eine Ebene anstatt dass eine bestehende Fläche als Basisobjekt verwendet wird.
<G-vec00169-001-s691><draw.zeichnen><en> Situations that we experience or read about or hear about may well draw exclamations of disapproval from us, but how often do we actively choose to do something about it.
<G-vec00169-001-s691><draw.zeichnen><de> Situationen, der wir erfahren oder ungefähr lasen oder ungefähr zeichnet Ausrufe der Mißbilligung von uns vielleicht gut hören, aber wie oft macht, wir wählen aktiv, etwas dagegen zu machen.
<G-vec00169-001-s692><draw.zeichnen><en> First you should draw the design on the buckskin with a pen.
<G-vec00169-001-s692><draw.zeichnen><de> Als erstes zeichnet man mit einem Stift das Design auf das Leder.
<G-vec00169-001-s693><draw.zeichnen><en> Draw the specified image directly to the vector drawing output.
<G-vec00169-001-s693><draw.zeichnen><de> Zeichnet das angegebene Bild direkt in die Vektorzeichnen-Ausgabe.
<G-vec00169-001-s694><draw.zeichnen><en> Draw an arc tangent to existing curves.
<G-vec00169-001-s694><draw.zeichnen><de> Zeichnet einen Bogen tangential zu existierenden Kurven.
<G-vec00169-001-s695><draw.zeichnen><en> Tattoo school: find out how to draw a deer's head .
<G-vec00169-001-s695><draw.zeichnen><de> Tattoo School: Wir zeigen dir, wie man einen Hirschkopf zeichnet.
<G-vec00169-001-s696><draw.zeichnen><en> If you double down, the dealer will give you only one more card and then draw the cards needed to complete his own hand.
<G-vec00169-001-s696><draw.zeichnen><de> Wenn Sie unten verdoppeln, gibt der Händler Ihnen nur eine weitere Karte und zeichnet dann die Karten, die benötigt werden, um seine eigene Hand durchzuführen.
<G-vec00169-001-s697><draw.zeichnen><en> Between two points will draw a line between two selected points.
<G-vec00169-001-s697><draw.zeichnen><de> Linie zeichnet eine Linie zwischen zwei ausgewählten Punkten.
<G-vec00169-001-s698><draw.zeichnen><en> Draw a circle tangent to existing curves.
<G-vec00169-001-s698><draw.zeichnen><de> Zeichnet einen Kreis tangential zu existierenden Kurven.
<G-vec00169-001-s699><draw.zeichnen><en> Draw a solid sphere, from center and radius.
<G-vec00169-001-s699><draw.zeichnen><de> Zeichnet eine Kugel, definiert durch Mittelpunkt und Radius.
<G-vec00169-001-s700><draw.zeichnen><en> "Chinese knowledge of this ""chi"" was on such an advanced level, that even today people constantly draw from it."
<G-vec00169-001-s700><draw.zeichnen><de> "nennen), Chinesisches Wissen dieses ""Chi"" war auf solch einem vorgercktem Niveau, diese gleichmigen Tagleute zeichnet stndig von ihm."
<G-vec00169-001-s701><draw.zeichnen><en> It draw the TPOs as letters or blocks the way you want, detects the TPO value area(not the volume VA) of the percentage you detect (0.7 is the default) and shows the Point of control of the day and the Initial Balance plus the opening flag for all of a number of days.
<G-vec00169-001-s701><draw.zeichnen><de> Es zeichnet die TPO als Buchstaben oder Blöcke, wie Sie wollen, detektiert den TPO-Wert-Bereich(nicht das Volumen VA) der Prozentsatz, den Sie erfassen (0.7 ist die Standardeinstellung) und zeigt den Punkt der Kontrolle über den Tag und die Eröffnungssaldo plus der Öffnung Flagge für alle eine Anzahl von Tagen.
<G-vec00169-001-s702><draw.zeichnen><en> When architects design a building or artists draw a painting, they first conceive the work that would be completed in their minds before they actually begin working on their project. Just like this, our
<G-vec00169-001-s702><draw.zeichnen><de> Wenn Architekten ein Gebäude entwerfen oder ein Künstler ein Gemälde zeichnet, stellen sie sich das Werk zuerst in ihren Gedanken abgeschlossen vor, bevor sie tatsächlich mit der Arbeit an ihrem Projekt beginnen.
<G-vec00042-001-s703><draw.ziehen><en> Make a small mark on the edge of the laminate, so you know where to cut or use a chalk pencil to draw your measurement line across the face of the laminate.
<G-vec00042-001-s703><draw.ziehen><de> Mache eine kleine Markierung am Rand des Laminats, damit du weißt, wo du sägen musst, oder ziehe mit einer Kreide die Messlinie über das Stück.
<G-vec00042-001-s704><draw.ziehen><en> No man can come to me, except the Father which hath sent me draw him: and I will raise him up at the last day.
<G-vec00042-001-s704><draw.ziehen><de> Es kann niemand zu mir kommen, es sei denn, daÃ ihn ziehe der Vater, der mich gesandt hat; und ich werde ihn auferwecken am Jüngsten Tage.
<G-vec00042-001-s705><draw.ziehen><en> While this card is face-up on the field, you can Normal Summon it to have it be treated as an Effect Monster with this effect: ● When this card destroys an opponent's monster by battle and sends it to the Graveyard, draw 1 card.
<G-vec00042-001-s705><draw.ziehen><de> Solange diese Karte offen auf dem Spielfeld liegt, kannst du sie als Normalbeschwörung beschwören, damit sie als Effektmonster mit diesem Effekt behandelt wird: ● Wenn diese Karte ein Monster deines Gegners durch Kampf zerstört und auf den Friedhof legt, ziehe 1 Karte.
<G-vec00042-001-s706><draw.ziehen><en> At the beginning of your Draw Phase, if you have no cards in your hand, draw 1 more card in addition to the normal draw.
<G-vec00042-001-s706><draw.ziehen><de> Zu Beginn deiner Draw Phase, falls du keine Karten in deiner Hand hast, ziehe 1 Karte zusätzlich zu deinen normalen Ziehen.
<G-vec00042-001-s707><draw.ziehen><en> Tempest-GX Discard your hand and draw 10 cards.
<G-vec00042-001-s707><draw.ziehen><de> Lege deine Handkarten auf deinen Ablagestapel und ziehe 10 Karten.
<G-vec00042-001-s708><draw.ziehen><en> I beseech Thee, O my God, by the rustling of the Divine Lote-Tree and the murmur of the breezes of Thine utterance in the kingdom of Thy names, to remove me far from whatsoever Thy will abhorreth, and draw me nigh unto the station wherein He Who is the Dayspring of Thy signs hath shone forth.
<G-vec00042-001-s708><draw.ziehen><de> Ich flehe Dich an, o mein Gott, beim Rauschen des göttlichen Lotosbaumes und dem Raunen Deiner Stimme im Königreich Deiner Namen: Halte mich fern von allem, was Dein Wille verabscheut, und ziehe mich empor zu der Stufe, von der Er, der Morgen Deiner Zeichen, herniederstrahlt.
<G-vec00042-001-s709><draw.ziehen><en> But I draw everything to me what becomes like me by forming itself to love.
<G-vec00042-001-s709><draw.ziehen><de> Ich aber ziehe alles an Mich, was sich Mir angleichet, indem es sich zur Liebe gestaltet.
<G-vec00042-001-s710><draw.ziehen><en> Draw 3 cards from your Deck, then discard any 2 cards from your hand.
<G-vec00042-001-s710><draw.ziehen><de> Ziehe 3 Karten von deinem Deck und wirf dann 2 Karten aus deiner Hand ab.
<G-vec00042-001-s711><draw.ziehen><en> If you call it right, draw until your hand has 5 cards.
<G-vec00042-001-s711><draw.ziehen><de> Wenn du richtig vorausgesagt hast, ziehe, bis deine Hand 5 Karten enthält.
<G-vec00042-001-s712><draw.ziehen><en> Return 2 WATER monsters from your hand to your Deck and draw 3 cards.
<G-vec00042-001-s712><draw.ziehen><de> Lege 2 WASSER Monster von deiner Hand in dein Deck zurück und ziehe 3 Karten.
<G-vec00042-001-s713><draw.ziehen><en> I draw Munich and Hanni Nuremberg, two main prizes.
<G-vec00042-001-s713><draw.ziehen><de> Ich ziehe München und Hanni Nürnberg, zwei Hauptpreise.
<G-vec00042-001-s714><draw.ziehen><en> """No one can come to Me unless the Father Who has sent Me draw him, and I will raise him up at the last day"" (John 6:44 MKJV)."
<G-vec00042-001-s714><draw.ziehen><de> """Niemand kann zu mir kommen, es sei denn, dass ihn ziehe der Vater, der mich gesandt hat, und ich werde ihn auferwecken am letzten Tag"" (Johannes 6:44)."
<G-vec00042-001-s715><draw.ziehen><en> Draw 2 cards from your Deck and skip your next 2 Draw Phases.
<G-vec00042-001-s715><draw.ziehen><de> Ziehe 2 Karten von deinem Deck und überspringe deine nächsten 2 Draw Phasen.
<G-vec00042-001-s716><draw.ziehen><en> When you successfully Tribute Summon or Set a monster that required 2 or more Tributes, draw 2 cards from your Deck.
<G-vec00042-001-s716><draw.ziehen><de> Wenn du erfolgreich ein Monster als Tributbeschwörung beschwörst, für das 2 oder mehr Monster als Tribut notwendig sind, ziehe 2 Karten von deinem Deck.
<G-vec00042-001-s717><draw.ziehen><en> Draw the remaining sides of the triangle: two more straight lines will connect the apex with the two open ends of the line segment.
<G-vec00042-001-s717><draw.ziehen><de> Ziehe die verbleibenden Seiten des Dreiecks: zwei gerade Linien, die den Scheitelpunkt mit den zwei freien Ende der Linie verbinden.
<G-vec00042-001-s718><draw.ziehen><en> When Summoned this way: Draw 1 card, and if you do, your opponent gains 2000 Life Points.
<G-vec00042-001-s718><draw.ziehen><de> Wenn sie auf diese Art beschworen wird: Ziehe 1 Karte und falls du dies tust, erhält dein Gegner 2000 Life Points.
<G-vec00042-001-s719><draw.ziehen><en> As you are lighting, slowly draw the bottle out of the water.
<G-vec00042-001-s719><draw.ziehen><de> Wenn das Kraut brennt, ziehe die Flasche langsam aus dem Wasser.
<G-vec00042-001-s720><draw.ziehen><en> When a stone is too heavy to lift I roll it in my fish tray and draw it over the grass by a rope.
<G-vec00042-001-s720><draw.ziehen><de> Ist ein Stein zu schwer, um ihn anzuheben, rolle ich ihn in meine Fischkiste und ziehe diese mit Hilfe eines Seils über das Gras.
<G-vec00042-001-s721><draw.ziehen><en> Then draw 2 cards.
<G-vec00042-001-s721><draw.ziehen><de> Dann ziehe 2 Karten.
<G-vec00169-001-s703><draw.ziehen><en> Make a small mark on the edge of the laminate, so you know where to cut or use a chalk pencil to draw your measurement line across the face of the laminate.
<G-vec00169-001-s703><draw.ziehen><de> Mache eine kleine Markierung am Rand des Laminats, damit du weißt, wo du sägen musst, oder ziehe mit einer Kreide die Messlinie über das Stück.
<G-vec00169-001-s704><draw.ziehen><en> No man can come to me, except the Father which hath sent me draw him: and I will raise him up at the last day.
<G-vec00169-001-s704><draw.ziehen><de> Es kann niemand zu mir kommen, es sei denn, daÃ ihn ziehe der Vater, der mich gesandt hat; und ich werde ihn auferwecken am Jüngsten Tage.
<G-vec00169-001-s705><draw.ziehen><en> While this card is face-up on the field, you can Normal Summon it to have it be treated as an Effect Monster with this effect: ● When this card destroys an opponent's monster by battle and sends it to the Graveyard, draw 1 card.
<G-vec00169-001-s705><draw.ziehen><de> Solange diese Karte offen auf dem Spielfeld liegt, kannst du sie als Normalbeschwörung beschwören, damit sie als Effektmonster mit diesem Effekt behandelt wird: ● Wenn diese Karte ein Monster deines Gegners durch Kampf zerstört und auf den Friedhof legt, ziehe 1 Karte.
<G-vec00169-001-s706><draw.ziehen><en> At the beginning of your Draw Phase, if you have no cards in your hand, draw 1 more card in addition to the normal draw.
<G-vec00169-001-s706><draw.ziehen><de> Zu Beginn deiner Draw Phase, falls du keine Karten in deiner Hand hast, ziehe 1 Karte zusätzlich zu deinen normalen Ziehen.
<G-vec00169-001-s707><draw.ziehen><en> Tempest-GX Discard your hand and draw 10 cards.
<G-vec00169-001-s707><draw.ziehen><de> Lege deine Handkarten auf deinen Ablagestapel und ziehe 10 Karten.
<G-vec00169-001-s708><draw.ziehen><en> I beseech Thee, O my God, by the rustling of the Divine Lote-Tree and the murmur of the breezes of Thine utterance in the kingdom of Thy names, to remove me far from whatsoever Thy will abhorreth, and draw me nigh unto the station wherein He Who is the Dayspring of Thy signs hath shone forth.
<G-vec00169-001-s708><draw.ziehen><de> Ich flehe Dich an, o mein Gott, beim Rauschen des göttlichen Lotosbaumes und dem Raunen Deiner Stimme im Königreich Deiner Namen: Halte mich fern von allem, was Dein Wille verabscheut, und ziehe mich empor zu der Stufe, von der Er, der Morgen Deiner Zeichen, herniederstrahlt.
<G-vec00169-001-s709><draw.ziehen><en> But I draw everything to me what becomes like me by forming itself to love.
<G-vec00169-001-s709><draw.ziehen><de> Ich aber ziehe alles an Mich, was sich Mir angleichet, indem es sich zur Liebe gestaltet.
<G-vec00169-001-s710><draw.ziehen><en> Draw 3 cards from your Deck, then discard any 2 cards from your hand.
<G-vec00169-001-s710><draw.ziehen><de> Ziehe 3 Karten von deinem Deck und wirf dann 2 Karten aus deiner Hand ab.
<G-vec00169-001-s711><draw.ziehen><en> If you call it right, draw until your hand has 5 cards.
<G-vec00169-001-s711><draw.ziehen><de> Wenn du richtig vorausgesagt hast, ziehe, bis deine Hand 5 Karten enthält.
<G-vec00169-001-s712><draw.ziehen><en> Return 2 WATER monsters from your hand to your Deck and draw 3 cards.
<G-vec00169-001-s712><draw.ziehen><de> Lege 2 WASSER Monster von deiner Hand in dein Deck zurück und ziehe 3 Karten.
<G-vec00169-001-s713><draw.ziehen><en> I draw Munich and Hanni Nuremberg, two main prizes.
<G-vec00169-001-s713><draw.ziehen><de> Ich ziehe München und Hanni Nürnberg, zwei Hauptpreise.
<G-vec00169-001-s714><draw.ziehen><en> """No one can come to Me unless the Father Who has sent Me draw him, and I will raise him up at the last day"" (John 6:44 MKJV)."
<G-vec00169-001-s714><draw.ziehen><de> """Niemand kann zu mir kommen, es sei denn, dass ihn ziehe der Vater, der mich gesandt hat, und ich werde ihn auferwecken am letzten Tag"" (Johannes 6:44)."
<G-vec00169-001-s715><draw.ziehen><en> Draw 2 cards from your Deck and skip your next 2 Draw Phases.
<G-vec00169-001-s715><draw.ziehen><de> Ziehe 2 Karten von deinem Deck und überspringe deine nächsten 2 Draw Phasen.
<G-vec00169-001-s716><draw.ziehen><en> When you successfully Tribute Summon or Set a monster that required 2 or more Tributes, draw 2 cards from your Deck.
<G-vec00169-001-s716><draw.ziehen><de> Wenn du erfolgreich ein Monster als Tributbeschwörung beschwörst, für das 2 oder mehr Monster als Tribut notwendig sind, ziehe 2 Karten von deinem Deck.
<G-vec00169-001-s717><draw.ziehen><en> Draw the remaining sides of the triangle: two more straight lines will connect the apex with the two open ends of the line segment.
<G-vec00169-001-s717><draw.ziehen><de> Ziehe die verbleibenden Seiten des Dreiecks: zwei gerade Linien, die den Scheitelpunkt mit den zwei freien Ende der Linie verbinden.
<G-vec00169-001-s718><draw.ziehen><en> When Summoned this way: Draw 1 card, and if you do, your opponent gains 2000 Life Points.
<G-vec00169-001-s718><draw.ziehen><de> Wenn sie auf diese Art beschworen wird: Ziehe 1 Karte und falls du dies tust, erhält dein Gegner 2000 Life Points.
<G-vec00169-001-s719><draw.ziehen><en> As you are lighting, slowly draw the bottle out of the water.
<G-vec00169-001-s719><draw.ziehen><de> Wenn das Kraut brennt, ziehe die Flasche langsam aus dem Wasser.
<G-vec00169-001-s720><draw.ziehen><en> When a stone is too heavy to lift I roll it in my fish tray and draw it over the grass by a rope.
<G-vec00169-001-s720><draw.ziehen><de> Ist ein Stein zu schwer, um ihn anzuheben, rolle ich ihn in meine Fischkiste und ziehe diese mit Hilfe eines Seils über das Gras.
<G-vec00169-001-s721><draw.ziehen><en> Then draw 2 cards.
<G-vec00169-001-s721><draw.ziehen><de> Dann ziehe 2 Karten.
<G-vec00042-001-s722><draw.ziehen><en> In the interest of warding off terrorism, fundamentalism and lack of party loyalty he will draw all strategically thinking rulers and parliaments over to his side.
<G-vec00042-001-s722><draw.ziehen><de> Im Namen der Abwehr des Terrorismus, des Fundamentalismus sowie einer mangelnden Linientreue wird er alle strategisch denkenden Herrscher und Parlamente auf seine Seite ziehen.
<G-vec00042-001-s723><draw.ziehen><en> The Librans who push others away are no less sensitive than the ones who draw them near.
<G-vec00042-001-s723><draw.ziehen><de> Waagen, die andere wegstossen, sind nicht weniger sensibel als jene, die andere nahe zu sich ziehen.
<G-vec00042-001-s724><draw.ziehen><en> And accordingly, her 1984 work in the Deutsche Bank Collection appears to draw the viewer into a kaleidoscopic spiral.
<G-vec00042-001-s724><draw.ziehen><de> Und so erscheint auch ihre 1984 entstandene Arbeit in der Sammlung Deutsche Bank den Blick geradewegs in einen kaleidoskopischen Strudel zu ziehen.
<G-vec00042-001-s725><draw.ziehen><en> This means that every cold is entitled to draw legal Microsoft software for free or huge discounts.
<G-vec00042-001-s725><draw.ziehen><de> Dies bedeutet, dass jedes kalt befugt, rechtliche Microsoft-Software für kostenlose oder großen Rabatten zu ziehen.
<G-vec00042-001-s726><draw.ziehen><en> And his hand, which he stretched out against him, dried up, so that he could not draw it back to himself.
<G-vec00042-001-s726><draw.ziehen><de> Und seine Hand verdorrte, die er gegen ihn ausgestreckt hatte, und er konnte sie nicht wieder an sich ziehen.
<G-vec00042-001-s727><draw.ziehen><en> We will then draw 15 winners from Facebook and Twitter each for the Perfect Privacy accounts and one from each for the VPN router.
<G-vec00042-001-s727><draw.ziehen><de> Wir ziehen dann jeweils 15 Gewinner von Facebook und Twitter für einen Perfect-Privacy-Monatskonto sowie jeweils einen Gewinner für den Netgear VPN-Router.
<G-vec00042-001-s728><draw.ziehen><en> On account of sociological circumstances the early Church could not immediately draw the consequences from the revolutionary new priesthood of Christ.
<G-vec00042-001-s728><draw.ziehen><de> Die Kirche der Frühzeit konnte wegen der damaligen soziologischen Verhältnisse nicht sofort die Konsequenzen aus dem revolutionären neuen Priestertum Christi ziehen.
<G-vec00042-001-s729><draw.ziehen><en> Following the contest, Morihei went out to his garden to draw water from the well to wash the sweat from his face and hands.
<G-vec00042-001-s729><draw.ziehen><de> Nach dem Wettbewerb Morihei ging in seinen Garten, um Wasser aus dem Brunnen, den Schweiß von seinem Gesicht und Hände waschen ziehen.
<G-vec00042-001-s730><draw.ziehen><en> "With a length of 68 ""he is to draw soft, the locator handle allows a comfortable hold, the incorporated arrow rest makes it easier to shoot and increased the Treffsichertheit."
<G-vec00042-001-s730><draw.ziehen><de> "Mit einer Länge von 68"" ist er weich zu ziehen, der Locatorgriff erlaubt ein bequemes Halten, die eingearbeitete Pfeilauflage erleichtert das Schiessen und erhöht die Treffsichertheit."
<G-vec00042-001-s731><draw.ziehen><en> Create digital magazines, eBooks and interactive online documents that draw people in with audio, video, slideshows and animations.
<G-vec00042-001-s731><draw.ziehen><de> Erstellen Sie digitale Magazine, eBooks und Online-Dokumente mit interaktivem Content wie Audio, Video, Dia-Shows oder Animationen, die Leser in ihren Bann ziehen.
<G-vec00042-001-s732><draw.ziehen><en> The Sisters Rodeo, Folk Festival and Quilt Festival always draw a crowd, and are top attractions for guests who are looking for something off the beaten path.
<G-vec00042-001-s732><draw.ziehen><de> Das Sisters Rodeo, das Folk-Festival und das Quilt-Festival ziehen stets viele Besucher an und sind erstklassige Attraktionen für Gäste, die etwas ganz Besonderes suchen.
<G-vec00042-001-s733><draw.ziehen><en> It's very difficult to know where to draw the line between what is sentient and what isn't.
<G-vec00042-001-s733><draw.ziehen><de> Es ist sehr schwierig, eine Grenzlinie zu ziehen zwischen dem, was bewusst empfindungsfähig ist, und etwas, bei dem das nicht der Fall ist.
<G-vec00042-001-s734><draw.ziehen><en> But, that an entire episcopacy formed by 34 bishops - although it has warned its involvement in the scandal spread and persisted for many years -, comes the unprecedented serious decision to resign as, with a compactness that knows what forced, as it might be in union protests or in a factory committee, more than witnessing an act of repentance, It gives evidence of a damaging wave of his episcopal dignity, to draw to itself the world's attention.
<G-vec00042-001-s734><draw.ziehen><de> aber, daß eine gesamte episcopacy gebildet durch 34 Bischöfe - auch wenn es seine Beteiligung an dem Skandal verbreitet und blieb seit vielen Jahren gewarnt hat -, kommt die beispiellos schwere Entscheidung zum Rücktritt als, mit einer Kompaktheit, die weiß, was gezwungen, wie es in Gewerkschaftsprotesten oder in einer Fabrikkomitee sein könnte, mehr als ein Akt der Reue erleben, Es gibt Hinweise auf einen schädlichen Welle seiner bischöflichen Würde, ziehen die Aufmerksamkeit auf sich der Welt.
<G-vec00042-001-s735><draw.ziehen><en> And I will draw unto thee to the river Kishon Sisera, the captain of Jabin's army, with his chariots and his multitude; and I will deliver him into thine hand.
<G-vec00042-001-s735><draw.ziehen><de> Denn ich will Sisera, den Feldhauptmann Jabins, zu dir ziehen an das Wasser Kison mit seinen Wagen und mit seiner Menge und will ihn in deine Hände geben.
<G-vec00042-001-s736><draw.ziehen><en> Nevertheless, we Marxist-Leninists draw some conclusions, seeing that the people came out in the streets, overthrew the Shah and succeeded in bringing the army, which was armed to its teeth, over to their side.
<G-vec00042-001-s736><draw.ziehen><de> Wie dem auch sei, wir Marxisten-Leninisten ziehen einige Schlussfolgerungen und stellen fest, dass das Volk auf die Straße ging, den Schah stürzte und die bis an die Zähne bewaffnete Armee dazu trieb, auf seine Seite überzugehen.
<G-vec00042-001-s737><draw.ziehen><en> They draw the audience – almost magically – into the cinemas and in front of the TVs.
<G-vec00042-001-s737><draw.ziehen><de> Sie ziehen das Publikum – fast magisch – in die Kinos und vor den Fernseher.
<G-vec00042-001-s738><draw.ziehen><en> Later on the larger collections of matter unite and gradually draw the smaller bodies to themselves.
<G-vec00042-001-s738><draw.ziehen><de> Später vereinigen sich die größeren Materieanhäufungen miteinander und ziehen die kleineren Körper allmählich an sich.
<G-vec00042-001-s739><draw.ziehen><en> Hay que saber dejar ir a las personas que dañan una parte de ti teniendo en cuenta que de todo, absolutely everything, We can draw a lesson for future experiences.
<G-vec00042-001-s739><draw.ziehen><de> Hay que saber dejar ir a las personas que dañan una parte de ti teniendo en cuenta que de todo, absolut alles, Wir können eine Lehre für zukünftige Erfahrungen ziehen.
<G-vec00042-001-s740><draw.ziehen><en> I know that there are other applications, but I am convinced that the main point is this – we must ask, seek, and knock for God to give the Holy Spirit to sinners, to illuminate them, to convict them of sin, to draw them to Christ.
<G-vec00042-001-s740><draw.ziehen><de> Ich weiß, es gibt sonstige Anwendungen dieser Parabel, aber ich bin überzeugt, die Hauptsache ist das: Wir müssen bitten, suchen und klopfen, daß Gott den Sündern den heiligen Geist gebe, sie zu erleuchten, sie der Sünde zu überzeugen, sie zu Christo zu ziehen.
<G-vec00169-001-s722><draw.ziehen><en> In the interest of warding off terrorism, fundamentalism and lack of party loyalty he will draw all strategically thinking rulers and parliaments over to his side.
<G-vec00169-001-s722><draw.ziehen><de> Im Namen der Abwehr des Terrorismus, des Fundamentalismus sowie einer mangelnden Linientreue wird er alle strategisch denkenden Herrscher und Parlamente auf seine Seite ziehen.
<G-vec00169-001-s723><draw.ziehen><en> The Librans who push others away are no less sensitive than the ones who draw them near.
<G-vec00169-001-s723><draw.ziehen><de> Waagen, die andere wegstossen, sind nicht weniger sensibel als jene, die andere nahe zu sich ziehen.
<G-vec00169-001-s724><draw.ziehen><en> And accordingly, her 1984 work in the Deutsche Bank Collection appears to draw the viewer into a kaleidoscopic spiral.
<G-vec00169-001-s724><draw.ziehen><de> Und so erscheint auch ihre 1984 entstandene Arbeit in der Sammlung Deutsche Bank den Blick geradewegs in einen kaleidoskopischen Strudel zu ziehen.
<G-vec00169-001-s725><draw.ziehen><en> This means that every cold is entitled to draw legal Microsoft software for free or huge discounts.
<G-vec00169-001-s725><draw.ziehen><de> Dies bedeutet, dass jedes kalt befugt, rechtliche Microsoft-Software für kostenlose oder großen Rabatten zu ziehen.
<G-vec00169-001-s726><draw.ziehen><en> And his hand, which he stretched out against him, dried up, so that he could not draw it back to himself.
<G-vec00169-001-s726><draw.ziehen><de> Und seine Hand verdorrte, die er gegen ihn ausgestreckt hatte, und er konnte sie nicht wieder an sich ziehen.
<G-vec00169-001-s727><draw.ziehen><en> We will then draw 15 winners from Facebook and Twitter each for the Perfect Privacy accounts and one from each for the VPN router.
<G-vec00169-001-s727><draw.ziehen><de> Wir ziehen dann jeweils 15 Gewinner von Facebook und Twitter für einen Perfect-Privacy-Monatskonto sowie jeweils einen Gewinner für den Netgear VPN-Router.
<G-vec00169-001-s728><draw.ziehen><en> On account of sociological circumstances the early Church could not immediately draw the consequences from the revolutionary new priesthood of Christ.
<G-vec00169-001-s728><draw.ziehen><de> Die Kirche der Frühzeit konnte wegen der damaligen soziologischen Verhältnisse nicht sofort die Konsequenzen aus dem revolutionären neuen Priestertum Christi ziehen.
<G-vec00169-001-s729><draw.ziehen><en> Following the contest, Morihei went out to his garden to draw water from the well to wash the sweat from his face and hands.
<G-vec00169-001-s729><draw.ziehen><de> Nach dem Wettbewerb Morihei ging in seinen Garten, um Wasser aus dem Brunnen, den Schweiß von seinem Gesicht und Hände waschen ziehen.
<G-vec00169-001-s730><draw.ziehen><en> "With a length of 68 ""he is to draw soft, the locator handle allows a comfortable hold, the incorporated arrow rest makes it easier to shoot and increased the Treffsichertheit."
<G-vec00169-001-s730><draw.ziehen><de> "Mit einer Länge von 68"" ist er weich zu ziehen, der Locatorgriff erlaubt ein bequemes Halten, die eingearbeitete Pfeilauflage erleichtert das Schiessen und erhöht die Treffsichertheit."
<G-vec00169-001-s731><draw.ziehen><en> Create digital magazines, eBooks and interactive online documents that draw people in with audio, video, slideshows and animations.
<G-vec00169-001-s731><draw.ziehen><de> Erstellen Sie digitale Magazine, eBooks und Online-Dokumente mit interaktivem Content wie Audio, Video, Dia-Shows oder Animationen, die Leser in ihren Bann ziehen.
<G-vec00169-001-s732><draw.ziehen><en> The Sisters Rodeo, Folk Festival and Quilt Festival always draw a crowd, and are top attractions for guests who are looking for something off the beaten path.
<G-vec00169-001-s732><draw.ziehen><de> Das Sisters Rodeo, das Folk-Festival und das Quilt-Festival ziehen stets viele Besucher an und sind erstklassige Attraktionen für Gäste, die etwas ganz Besonderes suchen.
<G-vec00169-001-s733><draw.ziehen><en> It's very difficult to know where to draw the line between what is sentient and what isn't.
<G-vec00169-001-s733><draw.ziehen><de> Es ist sehr schwierig, eine Grenzlinie zu ziehen zwischen dem, was bewusst empfindungsfähig ist, und etwas, bei dem das nicht der Fall ist.
<G-vec00169-001-s734><draw.ziehen><en> But, that an entire episcopacy formed by 34 bishops - although it has warned its involvement in the scandal spread and persisted for many years -, comes the unprecedented serious decision to resign as, with a compactness that knows what forced, as it might be in union protests or in a factory committee, more than witnessing an act of repentance, It gives evidence of a damaging wave of his episcopal dignity, to draw to itself the world's attention.
<G-vec00169-001-s734><draw.ziehen><de> aber, daß eine gesamte episcopacy gebildet durch 34 Bischöfe - auch wenn es seine Beteiligung an dem Skandal verbreitet und blieb seit vielen Jahren gewarnt hat -, kommt die beispiellos schwere Entscheidung zum Rücktritt als, mit einer Kompaktheit, die weiß, was gezwungen, wie es in Gewerkschaftsprotesten oder in einer Fabrikkomitee sein könnte, mehr als ein Akt der Reue erleben, Es gibt Hinweise auf einen schädlichen Welle seiner bischöflichen Würde, ziehen die Aufmerksamkeit auf sich der Welt.
<G-vec00169-001-s735><draw.ziehen><en> And I will draw unto thee to the river Kishon Sisera, the captain of Jabin's army, with his chariots and his multitude; and I will deliver him into thine hand.
<G-vec00169-001-s735><draw.ziehen><de> Denn ich will Sisera, den Feldhauptmann Jabins, zu dir ziehen an das Wasser Kison mit seinen Wagen und mit seiner Menge und will ihn in deine Hände geben.
<G-vec00169-001-s736><draw.ziehen><en> Nevertheless, we Marxist-Leninists draw some conclusions, seeing that the people came out in the streets, overthrew the Shah and succeeded in bringing the army, which was armed to its teeth, over to their side.
<G-vec00169-001-s736><draw.ziehen><de> Wie dem auch sei, wir Marxisten-Leninisten ziehen einige Schlussfolgerungen und stellen fest, dass das Volk auf die Straße ging, den Schah stürzte und die bis an die Zähne bewaffnete Armee dazu trieb, auf seine Seite überzugehen.
<G-vec00169-001-s737><draw.ziehen><en> They draw the audience – almost magically – into the cinemas and in front of the TVs.
<G-vec00169-001-s737><draw.ziehen><de> Sie ziehen das Publikum – fast magisch – in die Kinos und vor den Fernseher.
<G-vec00169-001-s738><draw.ziehen><en> Later on the larger collections of matter unite and gradually draw the smaller bodies to themselves.
<G-vec00169-001-s738><draw.ziehen><de> Später vereinigen sich die größeren Materieanhäufungen miteinander und ziehen die kleineren Körper allmählich an sich.
<G-vec00169-001-s739><draw.ziehen><en> Hay que saber dejar ir a las personas que dañan una parte de ti teniendo en cuenta que de todo, absolutely everything, We can draw a lesson for future experiences.
<G-vec00169-001-s739><draw.ziehen><de> Hay que saber dejar ir a las personas que dañan una parte de ti teniendo en cuenta que de todo, absolut alles, Wir können eine Lehre für zukünftige Erfahrungen ziehen.
<G-vec00169-001-s740><draw.ziehen><en> I know that there are other applications, but I am convinced that the main point is this – we must ask, seek, and knock for God to give the Holy Spirit to sinners, to illuminate them, to convict them of sin, to draw them to Christ.
<G-vec00169-001-s740><draw.ziehen><de> Ich weiß, es gibt sonstige Anwendungen dieser Parabel, aber ich bin überzeugt, die Hauptsache ist das: Wir müssen bitten, suchen und klopfen, daß Gott den Sündern den heiligen Geist gebe, sie zu erleuchten, sie der Sünde zu überzeugen, sie zu Christo zu ziehen.
<G-vec00042-001-s741><draw.ziehen><en> When using these general data and information, the RATE Network Ingenieurgesellschaft bR does not draw any conclusions about the data subject.
<G-vec00042-001-s741><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die RATE Network Ingenieurgesellschaft bR keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s742><draw.ziehen><en> When using these general data and information, the Olympic Wings does not draw any conclusions about the data subject.
<G-vec00042-001-s742><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Olympic Wings keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s743><draw.ziehen><en> And then the subtle systems: so you keep the one drop, and then you have two more drops, and then you have four more drops, and then you have eight more drops – and the full mandala's in each of them – and then you draw it back, in order.
<G-vec00042-001-s743><draw.ziehen><de> Zur Übung der subtilen Systeme behält man diesen einen Tropfen bei und visualisiert dann noch zwei weitere Tropfen, dann vier weitere und dann acht weitere Tropfen – und in jedem davon das komplette Mandala –, und dann zieht man all das der Reihe nach wieder zurück.
<G-vec00042-001-s744><draw.ziehen><en> When using these general data and information, the LignoLab does not draw any conclusions about the data subject.
<G-vec00042-001-s744><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Flugschule Engelberg keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s745><draw.ziehen><en> When using these general data and information, the quinta da tosca does not draw any conclusions about the data subject.
<G-vec00042-001-s745><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die menschen-und-magic keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s746><draw.ziehen><en> When using these general data and information, the Meyer zu Bexten GmbH & Co. KG does not draw any conclusions about the data subject.
<G-vec00042-001-s746><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Meyer zu Bexten GmbH & Co. KG keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s747><draw.ziehen><en> When using these general data and information, the Zootierliste does not draw any conclusions about the data subject.
<G-vec00042-001-s747><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die SCHULER-DENTAL GmbH & Co. KG keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s748><draw.ziehen><en> When using these general data and information, the Mikrogen GmbH does not draw any conclusions about the data subject.
<G-vec00042-001-s748><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die fejo.dk ApS keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s749><draw.ziehen><en> However, the organization responsible does not draw any conclusions as to a specific person.
<G-vec00042-001-s749><draw.ziehen><de> Der Verantwortliche zieht allerdings keine Rückschlüsse auf eine Person.
<G-vec00042-001-s750><draw.ziehen><en> When using this general data and information, TRADUguide does not draw any conclusions about the person affected.
<G-vec00042-001-s750><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Augustin Produktentwicklung keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s751><draw.ziehen><en> When using these general data and information, the PPI Pharma Packaging GmbH does not draw any conclusions about the data subject.
<G-vec00042-001-s751><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die PPI Pharma Packaging GmbH keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s752><draw.ziehen><en> When using these general data and information, the Neubauer Automation OHG does not draw any conclusions about the data subject.
<G-vec00042-001-s752><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Neubauer Automation OHG keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s753><draw.ziehen><en> In this way, you draw to you all that you need and are ready to have.
<G-vec00042-001-s753><draw.ziehen><de> Auf diese Weise zieht ihr alles zu euch, was ihr benötigt und zu haben bereit seid.
<G-vec00042-001-s754><draw.ziehen><en> Another example: if the flame of a candle burns your finger, you draw back your hand immediately.
<G-vec00042-001-s754><draw.ziehen><de> Ein weiteres Beispiel: Wenn die Flamme einer Kerze die Finger verbrennt, zieht man sofort die Hand zurück.
<G-vec00042-001-s755><draw.ziehen><en> The politics of the VVN-BdA organizers of the Day of Remembrance and Warning, as expressed in the call, draw the wrong lessons from the rise of the Nazis and the struggle against these murderous scum; these politics are an obstacle to the necessary proletarian struggle against fascism and against capitalism, which breeds it.
<G-vec00042-001-s755><draw.ziehen><de> Die Politik der Organisatoren des Tags der Erinnerung und Mahnung – VVN-BdA –, wie sie im Aufruf zum Ausdruck kommt, zieht die falschen Lehren aus dem Aufstieg der Nazis und dem Kampf gegen diesen mörderischen Abschaum und ist daher ein Hindernis für den notwendigen proletarischen Kampf gegen den Faschismus und den Kapitalismus, der ihn ausbrütet.
<G-vec00042-001-s756><draw.ziehen><en> When using these general data and information, Music Unlimited does not draw any conclusions about the data subject.
<G-vec00042-001-s756><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Music Unlimited keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s757><draw.ziehen><en> When using these general data and information, the AVOS Equipment AG does not draw any conclusions about the data subject.
<G-vec00042-001-s757><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die AVOS Equipment AG keine Rückschlüsse auf die betroffene Person.
<G-vec00042-001-s758><draw.ziehen><en> The concept is complex and multidimensional, and deciding where to draw the boundaries of the project in order to provide a focused and relevant solution required careful consideration.
<G-vec00042-001-s758><draw.ziehen><de> Das Konzept ist komplex und multidimensional, was erforderte, sich sehr genau zu überlegen, wo man die Grenzen des Projektes zieht, damit eine fokussierte und relevante Lösung entstehen kann.
<G-vec00042-001-s759><draw.ziehen><en> When using these general data and information, the easy Sports-Software does not draw any conclusions about the data subject.
<G-vec00042-001-s759><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Rudolf Weißenbach keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s741><draw.ziehen><en> When using these general data and information, the RATE Network Ingenieurgesellschaft bR does not draw any conclusions about the data subject.
<G-vec00169-001-s741><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die RATE Network Ingenieurgesellschaft bR keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s742><draw.ziehen><en> When using these general data and information, the Olympic Wings does not draw any conclusions about the data subject.
<G-vec00169-001-s742><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Olympic Wings keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s743><draw.ziehen><en> And then the subtle systems: so you keep the one drop, and then you have two more drops, and then you have four more drops, and then you have eight more drops – and the full mandala's in each of them – and then you draw it back, in order.
<G-vec00169-001-s743><draw.ziehen><de> Zur Übung der subtilen Systeme behält man diesen einen Tropfen bei und visualisiert dann noch zwei weitere Tropfen, dann vier weitere und dann acht weitere Tropfen – und in jedem davon das komplette Mandala –, und dann zieht man all das der Reihe nach wieder zurück.
<G-vec00169-001-s744><draw.ziehen><en> When using these general data and information, the LignoLab does not draw any conclusions about the data subject.
<G-vec00169-001-s744><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Flugschule Engelberg keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s745><draw.ziehen><en> When using these general data and information, the quinta da tosca does not draw any conclusions about the data subject.
<G-vec00169-001-s745><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die menschen-und-magic keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s746><draw.ziehen><en> When using these general data and information, the Meyer zu Bexten GmbH & Co. KG does not draw any conclusions about the data subject.
<G-vec00169-001-s746><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Meyer zu Bexten GmbH & Co. KG keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s747><draw.ziehen><en> When using these general data and information, the Zootierliste does not draw any conclusions about the data subject.
<G-vec00169-001-s747><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die SCHULER-DENTAL GmbH & Co. KG keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s748><draw.ziehen><en> When using these general data and information, the Mikrogen GmbH does not draw any conclusions about the data subject.
<G-vec00169-001-s748><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die fejo.dk ApS keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s749><draw.ziehen><en> However, the organization responsible does not draw any conclusions as to a specific person.
<G-vec00169-001-s749><draw.ziehen><de> Der Verantwortliche zieht allerdings keine Rückschlüsse auf eine Person.
<G-vec00169-001-s750><draw.ziehen><en> When using this general data and information, TRADUguide does not draw any conclusions about the person affected.
<G-vec00169-001-s750><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Augustin Produktentwicklung keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s751><draw.ziehen><en> When using these general data and information, the PPI Pharma Packaging GmbH does not draw any conclusions about the data subject.
<G-vec00169-001-s751><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die PPI Pharma Packaging GmbH keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s752><draw.ziehen><en> When using these general data and information, the Neubauer Automation OHG does not draw any conclusions about the data subject.
<G-vec00169-001-s752><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Neubauer Automation OHG keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s753><draw.ziehen><en> In this way, you draw to you all that you need and are ready to have.
<G-vec00169-001-s753><draw.ziehen><de> Auf diese Weise zieht ihr alles zu euch, was ihr benötigt und zu haben bereit seid.
<G-vec00169-001-s754><draw.ziehen><en> Another example: if the flame of a candle burns your finger, you draw back your hand immediately.
<G-vec00169-001-s754><draw.ziehen><de> Ein weiteres Beispiel: Wenn die Flamme einer Kerze die Finger verbrennt, zieht man sofort die Hand zurück.
<G-vec00169-001-s755><draw.ziehen><en> The politics of the VVN-BdA organizers of the Day of Remembrance and Warning, as expressed in the call, draw the wrong lessons from the rise of the Nazis and the struggle against these murderous scum; these politics are an obstacle to the necessary proletarian struggle against fascism and against capitalism, which breeds it.
<G-vec00169-001-s755><draw.ziehen><de> Die Politik der Organisatoren des Tags der Erinnerung und Mahnung – VVN-BdA –, wie sie im Aufruf zum Ausdruck kommt, zieht die falschen Lehren aus dem Aufstieg der Nazis und dem Kampf gegen diesen mörderischen Abschaum und ist daher ein Hindernis für den notwendigen proletarischen Kampf gegen den Faschismus und den Kapitalismus, der ihn ausbrütet.
<G-vec00169-001-s756><draw.ziehen><en> When using these general data and information, Music Unlimited does not draw any conclusions about the data subject.
<G-vec00169-001-s756><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Music Unlimited keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s757><draw.ziehen><en> When using these general data and information, the AVOS Equipment AG does not draw any conclusions about the data subject.
<G-vec00169-001-s757><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die AVOS Equipment AG keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s758><draw.ziehen><en> The concept is complex and multidimensional, and deciding where to draw the boundaries of the project in order to provide a focused and relevant solution required careful consideration.
<G-vec00169-001-s758><draw.ziehen><de> Das Konzept ist komplex und multidimensional, was erforderte, sich sehr genau zu überlegen, wo man die Grenzen des Projektes zieht, damit eine fokussierte und relevante Lösung entstehen kann.
<G-vec00169-001-s759><draw.ziehen><en> When using these general data and information, the easy Sports-Software does not draw any conclusions about the data subject.
<G-vec00169-001-s759><draw.ziehen><de> Bei der Nutzung dieser allgemeinen Daten und Informationen zieht die Rudolf Weißenbach keine Rückschlüsse auf die betroffene Person.
<G-vec00169-001-s779><draw.übertragen><en> A great news is that in case no winner is found, the Kosovo Loto 7/39 top prize rolls over to the next draw.
<G-vec00169-001-s779><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Kosovo Loto 7/39 Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s780><draw.übertragen><en> A great news is that in case no winner is found, the Georgia Lottery Fantasy 5 top prize rolls over to the next draw.
<G-vec00169-001-s780><draw.übertragen><de> Eine gute Nachricht besteht darin, dass wenn niemand den Georgia Lotto Fantasy 5 Hauptgewinn in der Ziehung gewonnen hat, wird der Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s781><draw.übertragen><en> A great news is that in case no winner is found, the Lotto CT top prize rolls over to the next draw.
<G-vec00169-001-s781><draw.übertragen><de> Eine gute Nachricht besteht darin, dass wenn niemand den Lotto CT Hauptgewinn in der Ziehung gewonnen hat, wird der Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s782><draw.übertragen><en> A great news is that in case no winner is found, the Lotto 6/45 Belgium top prize rolls over to the next draw.
<G-vec00169-001-s782><draw.übertragen><de> Eine gute Nachricht besteht darin, dass wenn niemand den Belgien Lotto 6/45 Hauptgewinn in der Ziehung gewonnen hat, wird der Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s783><draw.übertragen><en> A great news is that in case no winner is found, the Uruguay 5 De Oro Revancha top prize rolls over to the next draw.
<G-vec00169-001-s783><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Uruguay 5 De Oro Revancha Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s784><draw.übertragen><en> A great news is that in case no winner is found, the Nicaragua La Grande Loto top prize rolls over to the next draw.
<G-vec00169-001-s784><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Nicaragua La Grande Loto Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s785><draw.übertragen><en> A great news is that in case no winner is found, the American Lotto top prize rolls over to the next draw.
<G-vec00169-001-s785><draw.übertragen><de> Eine gute Nachricht besteht darin, dass wenn niemand den Amerika Lotto Hauptgewinn in der Ziehung gewonnen hat, wird der Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s786><draw.übertragen><en> A great news is that in case no winner is found, the Macedonia Loto 7/34 top prize rolls over to the next draw.
<G-vec00169-001-s786><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Mazedonien Loto 7/34 Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s787><draw.übertragen><en> A great news is that in case no winner is found, the Super Lotto India top prize rolls over to the next draw.
<G-vec00169-001-s787><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Super Lotto India Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s788><draw.übertragen><en> A great news is that in case no winner is found, the Loto fácil Brazil top prize rolls over to the next draw.
<G-vec00169-001-s788><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Loto fácil Brasilien Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s789><draw.übertragen><en> A great news is that in case no winner is found, the OH Lotto top prize rolls over to the next draw.
<G-vec00169-001-s789><draw.übertragen><de> Eine gute Nachricht besteht darin, dass wenn niemand den OH Lotto Hauptgewinn in der Ziehung gewonnen hat, wird der Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s790><draw.übertragen><en> A great news is that in case no winner is found, the Idaho Cash Lotto top prize rolls over to the next draw.
<G-vec00169-001-s790><draw.übertragen><de> Eine gute Nachricht besteht darin, dass wenn niemand den Lotto Idaho Cash Hauptgewinn in der Ziehung gewonnen hat, wird der Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s791><draw.übertragen><en> A great news is that in case no winner is found, the Russia Lotto 6/36 top prize rolls over to the next draw.
<G-vec00169-001-s791><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Russland Lotto 6/36 Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s792><draw.übertragen><en> A great news is that in case no winner is found, the Lotto Joker Romania top prize rolls over to the next draw.
<G-vec00169-001-s792><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Lotto Joker Rumänien Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s793><draw.übertragen><en> A great news is that in case no winner is found, the Luxembourg Lotto top prize rolls over to the next draw.
<G-vec00169-001-s793><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Luxemburg Lotto Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s794><draw.übertragen><en> If there are no jackpot winners in a draw, the jackpot amount is carried over to the next draw.
<G-vec00169-001-s794><draw.übertragen><de> Wenn es in einer Ziehung keine Jackpot-Gewinner gibt, wird der Jackpot-Betrag auf die nächste Ziehung übertragen.
<G-vec00169-001-s795><draw.übertragen><en> A great news is that in case no winner is found, the Malaysia 4D Damacai top prize rolls over to the next draw.
<G-vec00169-001-s795><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Malaysia 4D Damacai Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s796><draw.übertragen><en> A great news is that in case no winner is found, the Azerlotereya 5/36 Azerbaijan top prize rolls over to the next draw.
<G-vec00169-001-s796><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Azerlotereya 5/36 Aserbaidschan Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s797><draw.übertragen><en> A great news is that in case no winner is found, the Jamaica Lotto top prize rolls over to the next draw.
<G-vec00169-001-s797><draw.übertragen><de> Es gibt eine gute Nachricht: Wenn es keinen Jackpot-Gewinner gibt, wird der Jamaika Lotto Jackpot auf die nächste Ziehung übertragen.
<G-vec00169-001-s798><draw.zurückgreifen><en> Manufacturing corporations can draw on a series of national and international standards, which they can apply in cooperation with suppliers.
<G-vec00169-001-s798><draw.zurückgreifen><de> Fertigungsunternehmen können auf verschiedene nationale und internationale Standards und Normen zurückgreifen, die sie in Zusammenarbeit mit Lieferanten anwenden können.
<G-vec00169-001-s799><draw.zurückgreifen><en> In addition, Schmidt can also draw on grapes from various contract winegrowers for the Kiefer wines, which brings him a total of 92 hectares.
<G-vec00169-001-s799><draw.zurückgreifen><de> Daneben kann Schmidt für die Kiefer Weine aber auch auf Trauben von verschiedenen Vertragswinzern zurückgreifen, was ihm insgesamt 92 weitere Hektar einbringt.
<G-vec00169-001-s800><draw.zurückgreifen><en> In this field, Trützschler Nonwovens can draw on extensive experience from more than 100 projects.
<G-vec00169-001-s800><draw.zurückgreifen><de> Trützschler Nonwovens kann in diesem Bereich auf eine umfassende Erfahrung aus mehr als 100 Projekten zurückgreifen.
<G-vec00169-001-s801><draw.zurückgreifen><en> For this reason you need to work with a partner who supports you locally and is also able to draw upon a worldwide network.
<G-vec00169-001-s801><draw.zurückgreifen><de> Arbeiten Sie deshalb mit einem Partner zusammen, der Sie lokal betreut und gleichzeitig auf ein weltweites Netzwerk zurückgreifen kann.
<G-vec00169-001-s802><draw.zurückgreifen><en> The Homepage provides comprehensive information and work material for interested consumers, the media but also for public authorities and scientists who wish to draw on the work of BgVV.
<G-vec00169-001-s802><draw.zurückgreifen><de> Die Homepage stellt damit umfangreiches Informations- und Arbeitsmaterial zur Verfügung für interessierte Verbraucher, für die Medien, aber auch für Behörden und Wissenschaftler, die auf die Arbeiten des BgVV zurückgreifen.
<G-vec00169-001-s803><draw.zurückgreifen><en> Multi-CB can draw on many years of experience in the production of PCBs.
<G-vec00169-001-s803><draw.zurückgreifen><de> Dabei kann Multi-CB auf langjährige Erfahrung in der Fertigung von Leiterplatten zurückgreifen.
<G-vec00169-001-s804><draw.zurückgreifen><en> We can draw on many years of experience in this area and are happy to help you to plan and support your product development.
<G-vec00169-001-s804><draw.zurückgreifen><de> Wir können auf jahrelange Erfahrung diesbezüglich zurückgreifen und helfen Ihnen gern, Ihre Produktentwicklung zu planen und zu betreuen.
<G-vec00169-001-s805><draw.zurückgreifen><en> As far as the selection of the technology was concerned, we could draw on the experience of the other cooperatives.
<G-vec00169-001-s805><draw.zurückgreifen><de> Bei der Auswahl der Technik konnte man auf die die Erfahrungswerte der Nachbargenossenschaften zurückgreifen.
<G-vec00169-001-s806><draw.zurückgreifen><en> Our many years of experience enable us to draw on a huge knowledge base.
<G-vec00169-001-s806><draw.zurückgreifen><de> Unsere langjährige Erfahrung lässt uns auf einen großen Wissensschatz zurückgreifen.
<G-vec00169-001-s807><draw.zurückgreifen><en> A few years ago, we were able to take over the stock of replacement parts previously owned by Kurt Fuchs in Switzerland. For this reason, we can now draw on a wide range of parts for use in our restoration work.
<G-vec00169-001-s807><draw.zurückgreifen><de> Da wir vor geraumer Zeit das Ersatzteillager des bekannten Harmoniumrestaurators Kurt Fuchs aus der Schweiz übernommen haben, können wir bei unseren Restaurierungen auf ein außerordentlich gutes Teilesortiment zurückgreifen.
<G-vec00169-001-s808><draw.zurückgreifen><en> For instance, it was very helpful in clarifying our understanding of baptism. It was likewise very beneficial to draw from elements of theology in our discussion of original sin.
<G-vec00169-001-s808><draw.zurückgreifen><de> So war es durchaus hilfreich, bei der Klärung unseres Taufverständnisses oder bei dem Begriff „Erbsünde“ auf theologische Überlegungen zurückgreifen zu können.
<G-vec00169-001-s809><draw.zurückgreifen><en> At the same time, this great Dutch conductor, who has lived beside Lake Lucerne for several years, can draw on the mastery he has accrued over the course of his long-standing experience.
<G-vec00169-001-s809><draw.zurückgreifen><de> Gleichzeitig kann der große niederländische Dirigent, der seit einigen Jahren am Vierwaldstättersee lebt, auf seine aus langjähriger Erfahrung erwachsene Meisterschaft zurückgreifen.
<G-vec00169-001-s810><draw.zurückgreifen><en> Thanks to the poster competition of March 2000, activists of «No Person Is Illegal» had a wealth of graphic elements to draw from before launching their campaign against the infamous «Deportation.Class» of Lufthansa, and later when combining and reshaping it along the lines of a construction kit.
<G-vec00169-001-s810><draw.zurückgreifen><de> Die Aktivisten von »kein mensch ist illegal« konnten vor dem Start ihrer Kampagne gegen die »Deportation.Class« der Lufthansa dank des Plakatwettbewerbes im März 2000 auf eine Vielzahl von grafischen Elementen zurückgreifen, die später nach dem Baukastenprinzip miteinander kombiniert und neuzusammengesetzt wurden.
<G-vec00169-001-s811><draw.zurückgreifen><en> During his short research stay in India, Julian was able to draw on the international network of the Faculty of Arts and Humanities.
<G-vec00169-001-s811><draw.zurückgreifen><de> Julian hat im Research Master-Programm die Möglichkeit eines Auslandsaufenthalts genutzt, für den die Studierenden auf das internationale Netzwerk der Fakultät zurückgreifen können.
<G-vec00169-001-s812><draw.zurückgreifen><en> Our consultants have over 20 years of experience in business process optimization, risk management, IT transformation, and change management – creating an unparalleled pool of skills, knowledge, and methodology expertise that they draw on to improve your company’s operations.
<G-vec00169-001-s812><draw.zurückgreifen><de> Mit über 20 Jahren Erfahrung in den Bereichen Geschäftsprozessoptimierung, Risikomanagement, IT-Transformation und Change Management haben unsere Berater neben einem einzigartigen Fähigkeiten- und Wissenspool auch umfassende Methodenkompetenzen geschaffen, auf die sie zurückgreifen, um die Aktivitäten Ihres Unternehmens zu optimieren.
<G-vec00169-001-s813><draw.zurückgreifen><en> In order to be able to draw on the best technologies during later series production, the process development also often takes place internally at SCHERDEL.
<G-vec00169-001-s813><draw.zurückgreifen><de> Um bei der späteren Serienproduktion auf die besten Technologien zurückgreifen zu können, erfolgt auch die Prozessentwicklung vielfach SCHERDEL intern.
<G-vec00169-001-s814><draw.zurückgreifen><en> My traineeship opened lots of doors for me, as during this time I gained insights into many different departments and built up a network of contacts at Festo that I can draw upon today.
<G-vec00169-001-s814><draw.zurückgreifen><de> Mein Praktikum hat mir viele Türen geöffnet: Während dieser Zeit habe ich abteilungsübergreifend Einblicke gewonnen und mir ein Netzwerk bei Festo aufgebaut, auf das ich heute zurückgreifen kann.
<G-vec00169-001-s815><draw.zurückgreifen><en> As required, he or she can draw on the support of a team of experts that has been especially set up for each client's needs.
<G-vec00169-001-s815><draw.zurückgreifen><de> Er kann bei Bedarf auf die Unterstützung eines individuell für die jeweiligen Kundenbedürfnisse zusammen-gestellten Expertenteams zurückgreifen.
<G-vec00169-001-s816><draw.zurückgreifen><en> So we can draw on the experience that has been gained and we don't always need to start from scratch.
<G-vec00169-001-s816><draw.zurückgreifen><de> Damit man auf die gemachten Erfahrungen zurückgreifen und nicht immer wieder von vorne anfangen muss.
