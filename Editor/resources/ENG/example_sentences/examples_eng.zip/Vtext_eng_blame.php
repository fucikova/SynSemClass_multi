<G-vec00347-001-s012><blame.anlasten><en> In these cases the choice to have an abortion always remains a grave sin. But before being something to blame on the woman, it is a crime for which guilt needs to be attributed to men and to the complicity of the general social environment.
<G-vec00347-001-s012><blame.anlasten><de> Unter solchen Umständen ist die Entscheidung zur Abtreibung, die freilich immer eine schwere Sünde bleibt, eher ein Verbrechen, das dem Mann und der Mitwirkung des Umfeldes anzulasten ist, als eine den Frauen aufzuerlegende Schuld.
<G-vec00347-001-s013><blame.anlasten><en> In other words, if young people lack an understanding of classical cultural techniques, the experts also attribute this first and foremost to deficiencies in upbringing and support within families, rather than laying the blame wholly at the door of the schools.
<G-vec00347-001-s013><blame.anlasten><de> Mit anderen Worten: Wenn die Jugendlichen die klassischen Kulturtechniken nicht beherrschen, so ist dies aus Sicht der Experten und Expertinnen nicht allein den Schulen anzulasten, sondern auch hier zuvorderst einer unzureichenden Erziehung und Betreuung in den Familien.
<G-vec00347-001-s014><blame.anlasten><en> The plan is to blame the engineered economic hardship on Trump, Rothschild family sources say.
<G-vec00347-001-s014><blame.anlasten><de> Geplant ist, diese künstlich erzeugten wirtschaftlichen Schwierigkeiten Trump anzulasten, sagen Quellen der Familie Rothschild.
<G-vec00347-001-s015><blame.anlasten><en> He plans to blame Tell for the murder of the King and Queen and the kidnapping of the Princess.
<G-vec00347-001-s015><blame.anlasten><de> Er plant Tell den Mord am König und an der Königin sowie die Entführung anzulasten.
<G-vec00347-001-s016><blame.anlasten><en> When Hillary and crew tried to blame the hacking of Democratic Party e-mails on the “Russians,” it was none other than Director of National Intelligence James Clapper who told the Senate Intelligence committee he was “taken aback” by the “hyperventilation” about Russia.
<G-vec00347-001-s016><blame.anlasten><de> "Als Clinton und ihre Crew versuchten, den E-Mails-Hack bei der Demokratischen Partei den ""Russen"" anzulasten, war es kein anderer als der Direktor der Nationalen Nachrichtendienste James Clapper, der dem Nachrichten-Komitee des Senats erzählte, er wäre ""bestürzt"" über die ""Hyperventilation"" gegenüber Russland."
<G-vec00291-001-s027><blame.beschuldigen><en> Do not blame for all sins of the director, is also formation Department.
<G-vec00291-001-s027><blame.beschuldigen><de> Beschuldige in allen Sünden des Direktors nicht, es gibt auch die Abteilung der Bildung.
<G-vec00291-001-s028><blame.beschuldigen><en> I do not blame him, I was pretty muddled myself.
<G-vec00291-001-s028><blame.beschuldigen><de> Ich beschuldige ihn nicht, ich war ja selbst ziemlich verwirrt.
<G-vec00291-001-s029><blame.beschuldigen><en> I blame this on Diablo 3 Reaper of Souls [shakes fist at game].
<G-vec00291-001-s029><blame.beschuldigen><de> Ich beschuldige diese auf Teufel 3 Reaper of Souls [schüttelt die Faust-Spiel].
<G-vec00291-001-s030><blame.beschuldigen><en> I blame TV or satellite.
<G-vec00291-001-s030><blame.beschuldigen><de> Ich beschuldige TV oder Satelliten.
<G-vec00291-001-s031><blame.beschuldigen><en> If blame is the only emotion behind a revolution then no new and improved forms of governance will emerge.
<G-vec00291-001-s031><blame.beschuldigen><de> Wenn Beschuldigen die einzige Energie hinter einer Revolution ist, dann werden keine neuen und verbesserten Formen der Regierung auftauchen.
<G-vec00291-001-s032><blame.beschuldigen><en> "According to František Matúš: ""These facts cannot be used to blame Brahms from plagiarism, even if they are credible..."
<G-vec00291-001-s032><blame.beschuldigen><de> "František Matúš schreibt: ""Mit diesen Tatsachen kann man Brahms nicht des Plagiats beschuldigen, auch wenn sie glaubwürdig sind..."
<G-vec00291-001-s033><blame.beschuldigen><en> I cannot blame him because he is less technically skilled person and doesn't understand much about computer.
<G-vec00291-001-s033><blame.beschuldigen><de> Ich kann ihn nicht beschuldigen, weil er technisch weniger versiert ist und nicht viel über Computer versteht.
<G-vec00291-001-s034><blame.beschuldigen><en> What we discovered in the workshop is that when the Inner Child/Ego has not agreed to allow the pain and fears to surface, if we have not instructed him/her as to what to do with the pain once it surfaces nor assured him/her that we will not abandon and blame him/her when the pain surfaces, he/she will surely block us.
<G-vec00291-001-s034><blame.beschuldigen><de> Im Workshop fanden wir folgendes heraus: Wenn das innere Kind/Ego nicht zugestimmt hat, daß Schmerz und Angst hochkommen dürfen, weil wir es nicht darüber unterrichtet haben, was mit dem Schmerz geschehen soll, oder wir ihm nicht versichert haben, daß wir es nicht verlassen und beschuldigen werden, sobald der Schmerz hochkommt, wird es uns mit Sicherheit blockieren.
<G-vec00291-001-s035><blame.beschuldigen><en> "A state whose military high command and the office of its defense minister are located at the heart of a crowded city, and which sends civilians, including their women and children, to ""expand the boundaries of the country"" and whose bridgehead for occupation and takeover regularly hides being babies and pregnant women, and which refers to its own armed soldiers who died in battle or were captured as ""boys"" – such state needs a very high level of nerve in order to blame others for hiding behind civilians and children."
<G-vec00291-001-s035><blame.beschuldigen><de> "Ein Staat, dessen Oberkommando und Verteidigungsministerium mitten im Herzen einer dicht bevölkerten Stadt liegt und der Zivilisten, einschließlich ihrer Frauen und Kinder ausschickt, um die Grenzen des Landes weiter hinaus zu schieben und dessen Brückenkopf für Besatzung und Landraub sich regelmäßig zwischen Babys und schwangeren Frauen verbirgt und der seine eigenen bewaffneten Soldaten, die in der Schlacht gefallen sind oder gefangen genommen wurden, als ""Jungs"" bezeichnet – solch ein Staat braucht schon sehr dickes Fell, um andere zu beschuldigen, dass sie sich hinter Zivilisten und Kindern verstecken."
<G-vec00291-001-s036><blame.beschuldigen><en> Quality of manufacture: The click to deployment is a little scary at first, to see what it gives in the time put to leave it nothing to blame.
<G-vec00291-001-s036><blame.beschuldigen><de> Qualität der Herstellung: Der Klick auf die Bereitstellung ist zunächst etwas unheimlich, um zu sehen, was in der Zeit gegeben wird, um nichts zu beschuldigen.
<G-vec00291-001-s037><blame.beschuldigen><en> He begins to blame Snowball, the pig he chased away, for incidents happening on the farm.
<G-vec00291-001-s037><blame.beschuldigen><de> Er fängt an, Schneeball zu beschuldigen, das Schwein, das er verjagt hat, für Vorfälle, die auf dem Bauernhof passieren.
<G-vec00291-001-s038><blame.beschuldigen><en> They don’t look to blame others, but rather find a way to make things work.
<G-vec00291-001-s038><blame.beschuldigen><de> Sie schauen nicht, um andere zu beschuldigen, sondern einen Weg finden, um die Arbeit zu machen.
<G-vec00291-001-s039><blame.beschuldigen><en> Some children, if they trip or fall, have learned to blame the sidewalk.
<G-vec00291-001-s039><blame.beschuldigen><de> Einige Kinder haben gelernt, den Gehsteig zu beschuldigen wenn sie stolpern oder fallen.
<G-vec00291-001-s040><blame.beschuldigen><en> Yet we do not blame... we do no scorn.
<G-vec00291-001-s040><blame.beschuldigen><de> Aber wir beschuldigen nicht... wir verachten nicht.
<G-vec00291-001-s041><blame.beschuldigen><en> VI: As is very often the case, the new government will blame its predecessors for all or most of the deaths and atrocities, even if they happened after their actual rule.
<G-vec00291-001-s041><blame.beschuldigen><de> W. Ischtschenko: Wie das sehr oft der Fall ist, wird die neue Regierung ihre Vorgänger der meisten Tode und Gräueltaten beschuldigen, selbst wenn diese nach ihrer Herrschaft passiert sind.
<G-vec00291-001-s042><blame.beschuldigen><en> And while they blame us, they keep on contaminating the environment and our souls.
<G-vec00291-001-s042><blame.beschuldigen><de> Und während sie uns beschuldigen, fahren sie damit fort ohne Ende unsere Umwelt und unsere Gedanken zu verpesten.
<G-vec00291-001-s043><blame.beschuldigen><en> Overview 1. The reinforcing and institutionalizing of the protest against the Iranian regime, as exemplified by the riots during Ashura,1 have made it necessary for the regime to assign increasing blame to foreign countries.
<G-vec00291-001-s043><blame.beschuldigen><de> Die Intensivierung und Institutionalisierung der Proteste gegen das iranische Regime, die sich in den Ausschreitungen während der Ashura klar gezeigt hat, zwingt das Regime dazu, zunehmend fremde Staaten zu beschuldigen.
<G-vec00291-001-s044><blame.beschuldigen><en> And, it is senseless to blame the child for the irresponsible relation to expensive equipment in this situation.
<G-vec00291-001-s044><blame.beschuldigen><de> Wobei, das Kind in der verantwortungslosen Beziehung zu teuerer Technik in dieser Situation zu beschuldigen ist sinnlos.
<G-vec00291-001-s045><blame.beschuldigen><en> Good morning, we have never taken reservations for umbrellas and deck chairs, while for the sea menu paying € 35.00 you had 7 sea appetizers 1 first sea and a second sea, fruit, dessert, coffee, including all drinks and l 'bitter, with you there were 3 children who have consumed a slice in three and you have not been charged in the covered in the service, you ordered for six not for nine if you gave the stuff to eat the children blame not it's ours, we're sorry that you did not feel good, good evening.
<G-vec00291-001-s045><blame.beschuldigen><de> "Guten Morgen, wir haben noch nie Reservierungen für Sonnenschirme und Liegestühle, während für das Meer Menü zahlen 35,00 € hatten Sie 7 Meer Vorspeisen 1 erstes Meer und ein zweites Meer, Obst, Dessert, Kaffee, einschließlich aller Getränke und l ""bitter, mit dir gab es 3 Kinder, die eine Scheibe in drei verzehrt haben und dir wurde nicht in der Deckung im Dienst aufgeladen, du hast für sechs nicht für neun bestellt, wenn du das Zeug zum Essen gegeben hast, beschuldigen die Kinder nicht es gehört uns, es tut uns leid, dass du dich nicht gut gefühlt hast, guten Abend."
<G-vec00291-001-s046><blame.beschuldigen><en> But they forget to blame the organisation which took people living in an area of 4000 square kilometres into a strip of land of just 10 square kilometres.
<G-vec00291-001-s046><blame.beschuldigen><de> Aber sie vergessen, die Organisation, die Menschen zwang auf einem Landstreifen von nur 10 Quadratkilometern und einer Fläche von 4000 Quadratkilometern zu leben, zu beschuldigen.
<G-vec00291-001-s047><blame.beschuldigen><en> Some say she never loved any of them enough to marry; others blame her observations of her father's actions, and they alleged she could not trust men; still others say that to marry was to give up her power, especially in the realm of foreign affairs.
<G-vec00291-001-s047><blame.beschuldigen><de> Manche sagen, sie liebte niemanden genug, um zu heiraten; Andere beschuldigen ihre Beobachtungen über die Handlungen ihres Vaters, und sie behaupteten, sie könne den Männern nicht vertrauen; Noch andere sagen, dass zu heiraten war, ihre Macht aufzugeben, vor allem im Bereich der auswärtigen Angelegenheiten.
<G-vec00291-001-s048><blame.beschuldigen><en> If we make the wrong choices and go down the path of sin then we have nobody but ourselves to blame, and we must therefore face our sin alone and be answerable for it ourselves.
<G-vec00291-001-s048><blame.beschuldigen><de> Wenn wir dann die falschen Wahlen und den Gehen den Pfad der Sünde entlang machen, haben wir niemanden aber uns zu beschuldigen, und wir müssen deshalb unserer Sünde allein gegenüberstehen und sind verantwortlich dafür selbst.
<G-vec00291-001-s049><blame.beschuldigen><en> From then on, there is no one else to blame for the results you create and experience.
<G-vec00291-001-s049><blame.beschuldigen><de> Von da an kannst du keinen anderen mehr für die Ergebnisse, die du erzeugst und erfährst, beschuldigen.
<G-vec00347-001-s022><blame.beschuldigen><en> "According to František Matúš: ""These facts cannot be used to blame Brahms from plagiarism, even if they are credible..."
<G-vec00347-001-s022><blame.beschuldigen><de> "František Matúš schreibt: ""Mit diesen Tatsachen kann man Brahms nicht des Plagiats beschuldigen, auch wenn sie glaubwürdig sind..."
<G-vec00347-001-s023><blame.beschuldigen><en> I cannot blame him because he is less technically skilled person and doesn't understand much about computer.
<G-vec00347-001-s023><blame.beschuldigen><de> Ich kann ihn nicht beschuldigen, weil er technisch weniger versiert ist und nicht viel über Computer versteht.
<G-vec00347-001-s029><blame.beschuldigen><en> Some children, if they trip or fall, have learned to blame the sidewalk.
<G-vec00347-001-s029><blame.beschuldigen><de> Einige Kinder haben gelernt, den Gehsteig zu beschuldigen wenn sie stolpern oder fallen.
<G-vec00291-001-s050><blame.beschuldigen><en> He does not give way to despair and blame God.
<G-vec00291-001-s050><blame.beschuldigen><de> Er gibt sich nicht der Verzweiflung hin und beschuldigt Gott.
<G-vec00291-001-s051><blame.beschuldigen><en> Don't blame Venezuela now, which has done so much for education since the Bolivarian revolution, or the Republic of Haiti, crushed by poverty, diseases and natural catastrophes, as if any of these were ideal conditions for the freedom of expression proclaimed by the OAS.
<G-vec00291-001-s051><blame.beschuldigen><de> Beschuldigt jetzt weder Venezuela, das seit der Bolivarianischen Revolution so viel für die Bildung getan hat, noch die Republik Haiti, welche durch die Armut, die Krankheiten und Naturkatastrophen niedergeschlagen ist, als ob jene die idealen Bedingungen für die Meinungsfreiheit wären, welche die OAS ausruft.
<G-vec00291-001-s052><blame.beschuldigen><en> The rush to blame the Syrian military, and to update target lists for possible airstrikes, on the basis of no evidence, smacks of political motivation.
<G-vec00291-001-s052><blame.beschuldigen><de> Die Eile, mit der die syrische Armee beschuldigt wird und Ziele für mögliche Luftangriffe festgelegt werden, auf der Basis von NULL Beweisen, riecht nach politischer Motivation.
<G-vec00291-001-s053><blame.beschuldigen><en> He does not sidestep or blame.
<G-vec00291-001-s053><blame.beschuldigen><de> Er weicht nicht aus oder beschuldigt andere.
<G-vec00291-001-s054><blame.beschuldigen><en> This country kills us, silences us, rapes us, blame us.
<G-vec00291-001-s054><blame.beschuldigen><de> Dieses Land tötet uns, bringt uns zum Schweigen, vergewaltigt uns, beschuldigt uns.
<G-vec00291-001-s055><blame.beschuldigen><en> The class blame Rhydian, but he convinces Maddy that he didn't do it.
<G-vec00291-001-s055><blame.beschuldigen><de> Die Klasse beschuldigt Rhydian, aber er kann Maddy davon überzeugen, dass er es nicht getan hat.
<G-vec00291-001-s056><blame.beschuldigen><en> The authorities of the state have nonetheless attempted to redirect public attention using arguments that blame the victims for having exposed themselves to risky situations.
<G-vec00291-001-s056><blame.beschuldigen><de> Die lokalen Behörden versuchen jedoch weiterhin, die öffentliche Aufmerksamkeit abzulenken, indem sie die Opfer beschuldigt, sich risikoreichen Situationen ausgesetzt zu haben.
<G-vec00291-001-s057><blame.beschuldigen><en> In other words they blame themselves.
<G-vec00291-001-s057><blame.beschuldigen><de> Mit anderen Worten, es beschuldigt sich selbst.
<G-vec00291-001-s058><blame.beschuldigen><en> Hannah doesn't blame him, but explains that she liked him.
<G-vec00291-001-s058><blame.beschuldigen><de> Hannah beschuldigt ihn nicht, sondern erklärt, dass sie ihn mochte.
<G-vec00347-001-s035><blame.beschuldigen><en> The class blame Rhydian, but he convinces Maddy that he didn't do it.
<G-vec00347-001-s035><blame.beschuldigen><de> Die Klasse beschuldigt Rhydian, aber er kann Maddy davon überzeugen, dass er es nicht getan hat.
<G-vec00291-001-s059><blame.beschuldigen><en> He further put the blame for it upon the Soviet Jews, who, according to Khrushchev, never liked collective work and group discipline.
<G-vec00291-001-s059><blame.beschuldigen><de> Im weiteren Verlauf beschuldigte er aber die sowjetischen Juden, die gemäß Chruschtschew die kollektive Arbeit und die Gruppendisziplin ablehnen, für den Fehlschlag.
<G-vec00291-001-s060><blame.beschuldigen><en> Then Xinhua News Agency put the blame on Falun Gong again.
<G-vec00291-001-s060><blame.beschuldigen><de> Wieder beschuldigte die Xinhua Nachrichtenagentur Falun Gong.
<G-vec00291-001-s061><blame.beschuldigen><en> And I would blame God.
<G-vec00291-001-s061><blame.beschuldigen><de> Und ich beschuldigte Gott.
<G-vec00291-001-s088><blame.beschuldigen><en> I’d have to acknowledge that I created my current reality and could no longer blame anybody or anything else.
<G-vec00291-001-s088><blame.beschuldigen><de> – Müsste ich anerkennen, dass ich meine derzeitige Realität erschaffen habe, und ich könnte nicht länger irgendjemand oder irgendetwas dafür beschuldigen.
<G-vec00291-001-s089><blame.beschuldigen><en> Yes, you were wrong, but it is impossible to blame all life himself for it: only the one who does nothing is not mistaken.
<G-vec00291-001-s089><blame.beschuldigen><de> Ja, Sie waren neprawy, aber man darf sich nicht lebenslang dafür beschuldigen: irrt sich nur nicht, wer nichts macht.
<G-vec00291-001-s090><blame.beschuldigen><en> I'd have to acknowledge that I created my current reality and could no longer blame anybody or anything else.
<G-vec00291-001-s090><blame.beschuldigen><de> - Müsste ich anerkennen, dass ich meine derzeitige Realität erschaffen habe, und ich könnte nicht länger irgendjemand oder irgendetwas dafür beschuldigen.
<G-vec00291-001-s091><blame.machen><en> At the very least, when you're sitting here meditating and things don't seem to be going right, don't blame it on the weather.
<G-vec00291-001-s091><blame.machen><de> Zum mindesten, wenn ihr hier sitzt und meditiert, und die Dinge sich nicht richtig zu entwickeln scheinen, dann macht nicht das Wetter dafür verantwortlich.
<G-vec00291-001-s092><blame.machen><en> You will either love or hate it, but do not blame me if you suddenly get the idea of becoming an acolyte and feel the duty to obey the great leader Morsus Christ.
<G-vec00291-001-s092><blame.machen><de> Ihr werdet es entweder lieben oder hassen, aber macht mich bitte nicht dafür verantwortlich, falls ihr plötzlich den Drang verspürt, Messdiener zu werden, und euch verpflichtet fühlt, dem großen Anführer Morsus Christus zu folgen.
<G-vec00291-001-s093><blame.machen><en> If have the impression that the file transfer is too slow, don't blame it on the NEXTO CF.
<G-vec00291-001-s093><blame.machen><de> Falls jemand den Eindruck haben sollte, die Übertragung wäre zu langsam, so ist mit Sicherheit nicht der NEXTO CF dafür verantwortlich.
<G-vec00291-001-s094><blame.machen><en> It is simply wrong to blame the EU if decision-makers do not pursue sustainable nor good policies.
<G-vec00291-001-s094><blame.machen><de> Es ist schlicht falsch, die EU dafür verantwortlich zu machen, wenn Entscheidungsträger*innen weder nachhaltige noch inhaltlich gute Politik betreiben.
<G-vec00291-001-s095><blame.geben><en> Parties are not held to fullfil any obligation, if they are prohibited to do so by circumstances which have nothing to do with blame and, in accordance with the law, a judicial act or common belief cannot be held into account.
<G-vec00291-001-s095><blame.geben><de> Die Parteien sind nicht verpflichtet zum nachkommen einer ihrer Pflichten, wenn sie daran gehindert werden, durch Umstaende die nicht zuordnerbar sind aan eigener Schuld, des Gesetzes, Rechtshandlungen oder gemeinschaftlicher Auffassungen der Gesellschaft.
<G-vec00291-001-s096><blame.geben><en> It is suspected that congenital processes may be to blame (in which the tendency to develop this type of condition is passed on to offspring while in utero), or alternately, that these may develop secondary to chronic inflammatory processes.
<G-vec00291-001-s096><blame.geben><de> Es wird vermutet, dass angeborene Prozesse können daran schuld sein (in dem die Tendenz, diese Art von Zustand zu entwickeln wird an die Nachkommen weitergegeben, während in utero), oder alternativ, dass diese entwickeln kann sekundär chronisch-entzündlichen Prozessen.
<G-vec00291-001-s097><blame.geben><en> But maybe the badly written dialogues are to blame that you seldom can call the acting well done.
<G-vec00291-001-s097><blame.geben><de> Vielleicht sind aber auch die schlecht geschriebenen Dialoge daran schuld, dass man das Schauspiel selten als gelungen bezeichnen kann.
<G-vec00291-001-s098><blame.geben><en> To blame for this are not only the parties, but also the new and extremely weak electoral law.
<G-vec00291-001-s098><blame.geben><de> Daran sind nicht nur die Parteien, sondern auch das neue äußerst schwache Wahlgesetz schuld.
<G-vec00291-001-s099><blame.geben><en> Germany to the Germans, These are slogans from the time, should no longer be our right or from corners, are to blame, one does not say any more than Nazi today can (who wants), I am proud to be German.
<G-vec00291-001-s099><blame.geben><de> Deutschland den Deutschen, das sind Parolen aus Zeiten, die nicht mehr unsere sein sollten oder aus rechten Ecken, die daran schuld sind, das man als nicht Nazi heute nicht mehr sagen kann (wer das will), ich bin stolz ein Deutscher zu sein .
<G-vec00291-001-s100><blame.geben><en> So, for example, depression can develop, if they were not already there or – mostly undetected – even were to blame, that someone could no longer cope with his duties.
<G-vec00291-001-s100><blame.geben><de> So können sich beispielsweise Depressionen entwickeln, wenn sie nicht schon vorher da waren oder – meist unerkannt – sogar daran schuld waren, dass jemand seine Tätigkeit nicht mehr bewältigen konnte.
<G-vec00291-001-s101><blame.geben><en> Sometimes the band members were to blame for it themselves.
<G-vec00291-001-s101><blame.geben><de> Manchmal war die Band sogar selbst daran schuld.
<G-vec00291-001-s102><blame.geben><en> Thereby he has fulfilled the measure of evil, has become a devil and has in himself caused judgement to break loose over him, and must in his great torment ascribe it to himself, that nobody else except he himself is to blame for it.
<G-vec00291-001-s102><blame.geben><de> Dadurch aber hat er auch das Maß des Bösen erfüllt, ist ein Teufel geworden und hat dadurch denn auch in sich und aus sich das Gericht über sich selbst zum Losbruche gebracht und muss es sich in seiner großen Qual und Pein nun selbst zuschreiben, dass daran niemand als nur er selbst schuld war.
<G-vec00291-001-s103><blame.geben><en> But he added that the heroes of sport, such as Tiger Woods, who turned out recently in the center of the scandal, is also to blame, as the children take with them an example.
<G-vec00291-001-s103><blame.geben><de> Aber er fügte hinzu, dass die Helden des Sports, wie Tiger Woods, wie sich herausstellte kürzlich in den Mittelpunkt des Skandals, auch daran schuld ist, wie die Kinder mit ihnen ein Beispiel nehmen.
<G-vec00291-001-s104><blame.geben><en> Technological advances, the rise of the gig economy and low productivity are all to blame, says Juergen.
<G-vec00291-001-s104><blame.geben><de> Daran sind sowohl technologische Fortschritte, das Wachstum der Gig Economy sowie niedrige Produktivität schuld, erklärt Jürgen Maier.
<G-vec00291-001-s105><blame.geben><en> If any man fails, it must never be said that God is to blame.
<G-vec00291-001-s105><blame.geben><de> Wenn irgendein Mensch versagt, darf man nie sagen, dass Gott daran schuld ist.
<G-vec00291-001-s106><blame.geben><en> If they are defeated only their 'good nature' will be to blame.
<G-vec00291-001-s106><blame.geben><de> Wenn sie unterliegen, so ist nichts daran schuld, als ihre 'Gutmütigkeit'.
<G-vec00291-001-s107><blame.geben><en> Additional types of bacteria, as well as anaerobic bacteria – which are capable of living and growing in the absence of oxygen, may also be to blame.
<G-vec00291-001-s107><blame.geben><de> Zusätzliche Typen von Bakterien, sowie anaerobe Bakterien – befähigt sind und wachsen, in Abwesenheit von Sauerstoff, kann auch daran schuld sein.
<G-vec00291-001-s108><blame.geben><en> And US patent law is to blame for authorizing patents on information-manipulating techniques and patterns of communication—a policy that is harmful in general.
<G-vec00291-001-s108><blame.geben><de> Auch das US-Patentrecht ist daran Schuld, Patente auf informantionsmanipulierenden Techniken und Kommunikationsmuster zuzulassen–eine Politik, die im Allgemeinen schädlich ist.
<G-vec00291-001-s137><blame.geben><en> And don’t blame on the paint price because that is the same.
<G-vec00291-001-s137><blame.geben><de> Und geben Sie keinen Schuld an den Farbepreis, weil das den gleicher ist.
<G-vec00291-001-s138><blame.geben><en> "Of course, the Portuguese revisionists don't want to understand this and they blame Gorbachev for having ""destroyed socialism""."
<G-vec00291-001-s138><blame.geben><de> "Auf diesem Ohr sind die portugiesischen Revisionisten natürlich taub und so geben sie Gorbatschow die Schuld an der ""Zerschlagung des Sozialismus""."
<G-vec00291-001-s139><blame.geben><en> Some blame escaping sulfide gas from hot underwater springs, some attribute it to the overproduction of the 15'000 fish farms around the 38 sq.mi.
<G-vec00291-001-s139><blame.geben><de> Einige geben dem Austreten von Schwefel aus den heissen Unterwasserquellen die Schuld, andere der Überproduktion der 15'000 Fischfarmen rund um den 100km2 umfassenden See.
<G-vec00291-001-s140><blame.geben><en> They blame the European Union and say that everything that happened was predictable or prearranged.
<G-vec00291-001-s140><blame.geben><de> Sie geben der europäischen Union die Schuld und sagen, das wäre doch alles planbar und berechenbar gewesen.
<G-vec00291-001-s141><blame.geben><en> """The losers in the race for European integration are now finding a joint framework for expressing their discontent and back precisely those politicians who are to blame for their precarious situation."
<G-vec00291-001-s141><blame.geben><de> """Die Verlierer im Rennen um die europäische Integration finden jetzt einen gemeinsamen Ausdrucksrahmen für ihre Unzufriedenheit und geben genau jenen Politikern Rückendeckung, die Schuld an ihrer prekären Lage sind."
<G-vec00347-001-s095><blame.geben><en> They blame the European Union and say that everything that happened was predictable or prearranged.
<G-vec00347-001-s095><blame.geben><de> Sie geben der europäischen Union die Schuld und sagen, das wäre doch alles planbar und berechenbar gewesen.
<G-vec00291-001-s149><blame.machen><en> Some people blame the neo-liberal economic model, claiming it puts too high a priority on price stability, limits investment, restricts wage growth, and makes conditions even more precarious for the unemployed – a situation that has forced the government to permit indiscriminate growth in the informal, underground economy.
<G-vec00291-001-s149><blame.machen><de> Manche Leute machen die neoliberale Wirtschaftsmodell und behauptete, es stellt eine zu hohe Priorität auf die Preisstabilität, Grenzen Investitionen beschränkt Lohnwachstum, und macht noch mehr prekären Bedingungen für die Arbeitslosen eine Situation, hat die Regierung gezwungen, um wahllose Wachstum in der informellen Schattenwirtschaft.
<G-vec00291-001-s150><blame.machen><en> Finally, they blame Sepideh for having invited Elly in the first place and ruining their holiday.
<G-vec00291-001-s150><blame.machen><de> Schließlich machen sie es Sepideh zum Vorwurf, Elly überhaupt eingeladen und damit die Ferien ruiniert zu haben.
<G-vec00291-001-s151><blame.machen><en> Critics of Trump being hesitant about pinning the blame on Riyadh are taking the easy way out, Lidové noviny believes: Those who accuse...
<G-vec00291-001-s151><blame.machen><de> Die Kritiker Trumps zögerlicher Reaktion gegen Riad machen es sich zu leicht, findet hingegen Lidové noviny: Diejenigen, die Trump den...
<G-vec00291-001-s152><blame.machen><en> Some people blame their excessive weight gain on a slow metabolism.
<G-vec00291-001-s152><blame.machen><de> Einige Menschen machen ihre übermäßige Gewichtszunahme auf langsamen Stoffwechsel.
<G-vec00291-001-s153><blame.machen><en> Environmentalists and the local government put the blame on the NATA who are undertaking marine-manoeuvres in the area.
<G-vec00291-001-s153><blame.machen><de> Umweltschützer und die Regionalregierung machen die Nato, die in dem Seegebiet Marine-Manöver abhält, für den Tod verantwortlich.
<G-vec00291-001-s154><blame.machen><en> Accept full responsibility without apportioning blame to anyone for the actions of the person, persons or collective that is expressing negativity towards you.
<G-vec00291-001-s154><blame.machen><de> Übernehme die volle Verantwortung, ohne Anlastung einer Teilschuld an Dritte, für die Handlungen einer Person, von Personen oder Gemeinschaften, die dir gegenüber negative Äußerungen machen.
<G-vec00291-001-s155><blame.machen><en> 2007-11-13 22:16:19 - 5 tips to reduce holiday depression As the holidays approach each year, more and more people suffer from Holiday Depression.Some experts blame it on factors relating to nutrition.
<G-vec00291-001-s155><blame.machen><de> 2007-11-13 22:16:19 - 5 Tipps zur Verringerung der Urlaub Depression Da der Ansatz Urlaub jedes Jahr mehr und mehr Menschen leiden an Holiday Depression.Some Experten machen es auf Faktoren im Zusammenhang mit der Ernährung.
<G-vec00291-001-s156><blame.machen><en> "It seems you are only having fun up until you choose to contemplate your squanderings and the blame sets in, and of course you keep telling yourself ""I might be able to earn the funds back"" ad nauseam."
<G-vec00291-001-s156><blame.machen><de> "Es fühlt sich an wie Sie sind nur unter Summe Aufregung, bis Sie eine Entscheidung, Ihre Verluste zu prüfen und die Angst machen, setzt ein, und dann weiter beraten Sie ""Ich habe es wieder gewinnen können"" wiederholt."
<G-vec00291-001-s157><blame.machen><en> Many in the party blame the controversial coalition with Mrs Merkel's conservatives.
<G-vec00291-001-s157><blame.machen><de> Viele in der SPD machen die umstrittene Koalition mit Merkels Konservativen verantwortlich.
<G-vec00291-001-s158><blame.machen><en> Gus and Alicia blame Chase for Vickie's slithering her way into Mario's heart and sexuality.
<G-vec00291-001-s158><blame.machen><de> Gus und Alicia machen Chase dafür verantwortlich, dass Vickie sich in Marios Herz und Sexualität eingeschlichen hat.
<G-vec00291-001-s159><blame.machen><en> The Nazis are quick to blame the communists for the fire.
<G-vec00291-001-s159><blame.machen><de> Schnell machen die Nazis Kommunisten für den Brand verantwortlich.
<G-vec00291-001-s160><blame.machen><en> Apart from misguided planning, experts blame the deforestation of the rain forest for the drought.
<G-vec00291-001-s160><blame.machen><de> Neben Fehlplanungen machen Experten die Abholzung des Regenwaldes für die Dürre verantwortlich.
<G-vec00291-001-s161><blame.machen><en> For instance, medical researchers blame stress, medications, eating habits, and no surprise, lack of shut eye, for lowered immunity and your body’s inability to ward off all types of viruses, illness, and infections.
<G-vec00291-001-s161><blame.machen><de> Zum Beispiel machen medizinische Forscher Stress, Medikamente, Ernährung und – keine Überraschung – Schlafmangel, für ein schlechteres Immunsystem und die Unfähigkeit Ihres Körpers alle Arten von Viren, Krankheiten und Infektionen abzuwehren verantwortlich.
<G-vec00291-001-s162><blame.machen><en> Others blame the Eurosceptic UK Independence Party for the Conservatives' impending loss of votes.
<G-vec00291-001-s162><blame.machen><de> Andere machen die EU-kritische Partei Ukip für die drohenden Stimmverluste der Konservativen verantwortlich.
<G-vec00291-001-s163><blame.machen><en> We may also blame our difficulties on the political or economic situation.
<G-vec00291-001-s163><blame.machen><de> Wir machen auch die politische und wirtschaftliche Situation für unsere Probleme verantwortlich.
<G-vec00291-001-s164><blame.machen><en> Indeed, most of the shopkeepers in Nahr al-Bared blame the lack of customers from outside for their terrible situation.
<G-vec00291-001-s164><blame.machen><de> Tatsächlich machen viele Ladenbesitzer in Nahr al-Bared die mangelnde Kundschaft von außerhalb für ihre aussichtslose Situation verantwortlich.
<G-vec00291-001-s165><blame.machen><en> Some commentators blame German Chancellor Merkel's liberal immigration policy for the attacks.
<G-vec00291-001-s165><blame.machen><de> Einige Kommentatoren machen die Bundeskanzlerin mit ihrer liberalen Einwanderungspolitik für die Taten verantwortlich.
<G-vec00291-001-s166><blame.machen><en> The researchers at Cambridge University who produced a report on these developments placed the blame in large part on cuts in medical and social services, including help for drug-addicts, whose numbers are growing.
<G-vec00291-001-s166><blame.machen><de> Die Forscher/-innen der Universität Cambridge, die eine Studie dazu veröffentlicht haben, machen zu einem guten Teil die Budgetkürzungen im Gesundheits- und Sozialwesen für diese Entwicklung verantwortlich, darunter unter anderem auch die Sparmaßnahmen bei der Betreuung Suchtkranker, deren Zahl ebenfalls steigt.
<G-vec00291-001-s167><blame.machen><en> Some of them talk about the appearance of black spots, but blame it on the individual skin reaction.
<G-vec00291-001-s167><blame.machen><de> Einige sprechen über das Auftreten von schwarzen Flecken, machen aber die individuelle Hautreaktion verantwortlich.
<G-vec00291-001-s168><blame.machen><en> Commentators also pin the blame on politicians.
<G-vec00291-001-s168><blame.machen><de> Kommentatoren machen auch die Politik verantwortlich.
<G-vec00291-001-s169><blame.machen><en> Now, if they are Republicans, only 19% blame it on global warming and 51% (just like independents) attribute it to normal variations.
<G-vec00291-001-s169><blame.machen><de> Wenn sie jetzt Republikaner sind, machen sie nur 19% für die globale Erwärmung verantwortlich und 51% (ebenso wie Unabhängige) führen sie normalen Schwankungen zu.
<G-vec00291-001-s170><blame.machen><en> "Left-liberal intellectuals blame the ""servant mentality"" of the public for the failure of the left-wing alliance parties."
<G-vec00291-001-s170><blame.machen><de> "Linksliberale Intellektuelle machen die ""Untertanenmentalität"" des Volkes für das Scheitern der Linksallianz bei den Wahlen verantwortlich."
<G-vec00291-001-s171><blame.machen><en> And that many of them put the blame for this on the EU in distant Brussels.
<G-vec00291-001-s171><blame.machen><de> Und dafür machen viele auch die EU im fernen Brüssel verantwortlich.
<G-vec00291-001-s172><blame.machen><en> Brokers blame the HFT algorithms and trading set-ups when volatility increases and they are not able to provide stable rates as promised to customers.
<G-vec00291-001-s172><blame.machen><de> Broker machen die HFT-Algorithmen und Trading-Setups verantwortlich, wenn die Volatilität steigt und sie nicht in der Lage sind, stabile und den Kunden versprochene Kurse anzubieten.
<G-vec00347-001-s112><blame.machen><en> Many in the party blame the controversial coalition with Mrs Merkel's conservatives.
<G-vec00347-001-s112><blame.machen><de> Viele in der SPD machen die umstrittene Koalition mit Merkels Konservativen verantwortlich.
<G-vec00347-001-s114><blame.machen><en> The Nazis are quick to blame the communists for the fire.
<G-vec00347-001-s114><blame.machen><de> Schnell machen die Nazis Kommunisten für den Brand verantwortlich.
<G-vec00347-001-s115><blame.machen><en> Apart from misguided planning, experts blame the deforestation of the rain forest for the drought.
<G-vec00347-001-s115><blame.machen><de> Neben Fehlplanungen machen Experten die Abholzung des Regenwaldes für die Dürre verantwortlich.
<G-vec00347-001-s116><blame.machen><en> For instance, medical researchers blame stress, medications, eating habits, and no surprise, lack of shut eye, for lowered immunity and your body’s inability to ward off all types of viruses, illness, and infections.
<G-vec00347-001-s116><blame.machen><de> Zum Beispiel machen medizinische Forscher Stress, Medikamente, Ernährung und – keine Überraschung – Schlafmangel, für ein schlechteres Immunsystem und die Unfähigkeit Ihres Körpers alle Arten von Viren, Krankheiten und Infektionen abzuwehren verantwortlich.
<G-vec00347-001-s117><blame.machen><en> Others blame the Eurosceptic UK Independence Party for the Conservatives' impending loss of votes.
<G-vec00347-001-s117><blame.machen><de> Andere machen die EU-kritische Partei Ukip für die drohenden Stimmverluste der Konservativen verantwortlich.
<G-vec00347-001-s118><blame.machen><en> We may also blame our difficulties on the political or economic situation.
<G-vec00347-001-s118><blame.machen><de> Wir machen auch die politische und wirtschaftliche Situation für unsere Probleme verantwortlich.
<G-vec00347-001-s119><blame.machen><en> Indeed, most of the shopkeepers in Nahr al-Bared blame the lack of customers from outside for their terrible situation.
<G-vec00347-001-s119><blame.machen><de> Tatsächlich machen viele Ladenbesitzer in Nahr al-Bared die mangelnde Kundschaft von außerhalb für ihre aussichtslose Situation verantwortlich.
<G-vec00347-001-s120><blame.machen><en> Some commentators blame German Chancellor Merkel's liberal immigration policy for the attacks.
<G-vec00347-001-s120><blame.machen><de> Einige Kommentatoren machen die Bundeskanzlerin mit ihrer liberalen Einwanderungspolitik für die Taten verantwortlich.
<G-vec00347-001-s143><blame.schieben><en> The drone is detonated at a place where the blame can be put on the adverse party.
<G-vec00347-001-s143><blame.schieben><de> Die Drohne wird an einer Stelle zur Explosion gebracht, wo man es der Gegenpartei in die Schuhe schieben kann.
<G-vec00347-001-s144><blame.schieben><en> Following the discovery of a far-right group, involving army officers who planned terrorist acts and would then blame refugees, German Defence Minister Ursula von der Leyen announced a review of the Bundeswehr and its traditions.
<G-vec00347-001-s144><blame.schieben><de> Nach der Entdeckung einer rechten Terrorzelle unter Bundeswehroffizieren, die Anschläge planten, um sie Flüchtlingen in die Schuhe zu schieben, versuchte Verteidigungsministerin von der Leyen abzuwiegeln, indem sie eine Überprüfung der Traditionspflege der Bundeswehr ankündigte.
<G-vec00347-001-s145><blame.schieben><en> "As for the alleged ""mistakes"" of Stalin as Commander-in-Chief of the Red Army, these were in fact mistakes of such generals as Zhukov, Tukhachevsky, and other generals and officers such as Khrushchev. It was they who tried to blame Stalin for their own crimes."
<G-vec00347-001-s145><blame.schieben><de> "Was die angeblichen ""Fehler"" Stalins als Oberbefehlshaber der Roten Armee betrifft, so waren das in Wahrheit Fehler solcher Generäle wie Schukow, Tuchatschewski und andere Generäle und Offiziere wie zum Beispiel Chruschtschow, die ihre eigenen Fehler im Nachhinein Stalin in die Schuhe zu schieben versuchten."
<G-vec00347-001-s146><blame.schieben><en> They probably will again try to pin the blame on the Kurdish opposition, which is supported on the other side not only by our country.
<G-vec00347-001-s146><blame.schieben><de> Wahrscheinlich wird man es wieder der kurdischen Opposition in die Schuhe zu schieben versuchen, welche auf der anderen Seite nicht nur von unserem Land unterstützt wird.
<G-vec00347-001-s147><blame.schieben><en> If the conditions of our world gets worse and catastrophes and wars occur, then, we should not blame this to the plotters or reptilians alone – we really would not have learned anything.
<G-vec00347-001-s147><blame.schieben><de> Wenn sich der Zustand unserer Welt verschlechtert und es zu Katastrophen und Kriegen kommt, dann sollten wir das nicht allein den Verschwörern in die Schuhe schieben - dann hätten wir ja wirklich nichts dazu gelernt.
<G-vec00347-001-s148><blame.schieben><en> ], the leader of a Hindu sect tries to cause a terrible disaster in Mumbai and throw the blame on Muslim extremists.
<G-vec00347-001-s148><blame.schieben><de> versucht der Leader einer hinduistischen Sekte, in Mumbai eine schreckliche Katastrophe heraufzubeschwören und diese den muslimischen Extremisten in die Schuhe zu schieben.
<G-vec00347-001-s149><blame.schieben><en> Even murdering a rival, if he can pin the blame on the serial killer.
<G-vec00347-001-s149><blame.schieben><de> Auch der Mord eines Rivalen, den er dankenswerterweise dem Serienkiller in die Schuhe schieben kann.
<G-vec00347-001-s150><blame.schieben><en> I brought proof that certain academics in our Party had shown themselves inconsistent and unstable, and that they had no right to lay the blame for their own lack of discipline upon the Russian proletarians.
<G-vec00347-001-s150><blame.schieben><de> Ich führte Beweise dafür an, daß gewisse Akademiker in unserer Partei ihre Inkonsequenz und Unbeständigkeit offenbarten und daß sie keinerlei Recht hatten, ihre Disziplinlosigkeit den russischen Proletariern in die Schuhe zu schieben.
<G-vec00347-001-s151><blame.schieben><en> If the arsonists are radical Arab powers, there can be only one reason to keep this a secret, namely, in order to blame the Lübeck arson on the political right-wing and justify any kind of repression against right-wing elements and also against historical Revisionists.
<G-vec00347-001-s151><blame.schieben><de> Wenn hinter dem Brandanschlag also radikale arabische Kräfte stünden, so gäbe es nur einen Grund, dies geheim zu halten, nämlich die politische Absicht, den Brandanschlag von Lübeck weiterhin den politisch rechten Kräften in die Schuhe schieben zu können, um damit alle möglichen Repressalien gegen rechte Kräfte und auch gegen den historischen Revisionismus zu rechtfertigen.
<G-vec00291-001-s226><blame.geben><en> Undeniably, those who willfully shut out God from their hearts and try to dodge religious questions are not following the dictates of their consciences, and hence are not free of blame; yet believers themselves frequently bear some responsibility for this situation.
<G-vec00291-001-s226><blame.geben><de> Gewiß sind die, die in Ungehorsam gegen den Spruch ihres Gewissens absichtlich Gott von ihrem Herzen fernzuhalten und religiöse Fragen zu vermeiden suchen, nicht ohne Schuld; aber auch die Gläubigen selbst tragen daran eine gewisse Verantwortung.
<G-vec00291-001-s227><blame.geben><en> They are not to blame for this, for society does not inculcate such values in them on a massive scale.
<G-vec00291-001-s227><blame.geben><de> Die Fachleute sind nicht Schuld daran, denn die Gesellschaft erzieht sie nicht breit angelegt in diesem Sinn.
<G-vec00291-001-s228><blame.geben><en> Blame the massive eruption of Tambora volcano was (Indonesia) in April 1815.
<G-vec00291-001-s228><blame.geben><de> Schuld daran war der gewaltige Ausbruch des Tambora-Vulkans (Indonesien) im April 1815.
<G-vec00291-001-s229><blame.geben><en> Fortia conceded the Atlantis stone to be a forgery, but he loaded off all the blame onto Grognet. Grognet, however, never admitted that the Atlantis stone was a forgery.
<G-vec00291-001-s229><blame.geben><de> Dass der Atlantis-Stein eine Fälschung war, wurde von Fortia eingeräumt, doch wurde die Schuld daran auf Grognet abgewälzt.
<G-vec00291-001-s230><blame.geben><en> And if, in spite of the existence of such organizations and of such possibilities, which facilitate the achievement of successes, we still have quite a number of shortcomings in our work and not a few failures, then it is only we ourselves, our organizational work, our bad organizational leadership, that are to blame for this.
<G-vec00291-001-s230><blame.geben><de> Und wenn wir trotz des Vorhandenseins solcher Organisationen und solcher Möglichkeiten, die die Erzielung von Erfolgen erleichtern, nicht wenig Mängel in der Arbeit und eine nicht geringe Anzahl von Misserfolgen zu verzeichnen haben, so sind nur wir, unsere Organisationsarbeit, unsere schlechte organisatorische Leitung schuld daran.
<G-vec00291-001-s231><blame.geben><en> But the Capernaumians themselves are to blame, for when at the other occasion He had awaked the Chief’s little daughter from visible and perceptible death, back to fullest life, it did not take long for the Pharisees of this city, condemned by Him, to declare Him a deceiver, telling all folk that Jairus only wanted to put Jesus to the test by laying his healthy daughter upon a makeshift death bed, whereupon the deceiver Jesus, having no notion of the trap set Him, was easily able to awaken her from death to life, which He effected as I heard it said by some, after having in the end discerned that she lives, by applying much pressure when seizing her by the hand.
<G-vec00291-001-s231><blame.geben><de> Aber es sind die Kapernaumer selbst schuld daran; denn damals, als Er des Obersten Töchterchen wirklich vom sichtbarsten und fühlbarsten Tode zum vollsten Leben wieder erweckt hatte, da dauerte es gar nicht lange, daß sie, die Pharisäer dieser von Ihm verwünschten Stadt, Ihn geradeheraus für einen Betrüger erklärten und haben allem Volke bewiesen und gesagt, Jairus habe Jesum nur auf eine Probe stellen wollen und habe deshalb sein kerngesundes Töchterchen auf ein eigens aufgerichtetes Totenbett gelegt, und der Betrüger Jesus, der keine Ahnung von der Falle, die ihm gelegt war, hatte, habe sie dann freilich wohl leicht vom Tode zum Leben erweckt, was er dadurch bewirkt hätte – wie ich es von einigen vernommen habe –, daß er sie, weil er am Ende doch gewahr wurde, daß sie lebe, recht stark drückend bei der Hand faßte und sie am Ende lieber aufstand, als daß sie noch länger den Schmerz des starken Druckes ertrüge.
<G-vec00291-001-s232><blame.geben><en> They talk about the good old times and about some unfinished business that Ulrik has with Kenny, who was to blame for Ulrik’s spell in prison.
<G-vec00291-001-s232><blame.geben><de> Sie sprechen über die guten alten Zeiten und über die offene Rechnung, die Ulrik noch mit Kenny hat, der Schuld daran war, dass er in den Knast musste.
<G-vec00291-001-s233><blame.geben><en> Journey are to blame that I'm an expert now - an expert for chasing CD's and DVD's that have only been published in foreign countries.
<G-vec00291-001-s233><blame.geben><de> Journey sind mit Schuld daran, dass ich zur Fachfrau für die Jagd nach nur im Ausland erschienener CD-Versionen und DVDs wurde.
<G-vec00291-001-s234><blame.geben><en> To invoke Gore is a way to obfuscate about climate science, for which Gore has neither responsibility, claim nor blame.
<G-vec00291-001-s234><blame.geben><de> Sich auf Gore zu berufen ist eine Verschleierungstaktik beim Thema Klimawandel, für die Gore weder Verantwortung trägt, noch Anspruch darauf oder Schuld daran hat.
<G-vec00291-001-s235><blame.geben><en> Blame it on the resurgence of 80s nostalgia, but bold, bright colors are back in fashion in a big way.
<G-vec00291-001-s235><blame.geben><de> Schuld daran ist das Wiederaufleben der 80er Jahre Nostalgie, aber fett, helle Farben sind wieder in Mode im großen Stil.
<G-vec00291-001-s236><blame.geben><en> Those who died in Lampedusa were murdered, and the blame lies with the barrage of vicious anti-immigrant laws that have been imposed by Italian governments, whether left-of-center or right-of-center, and the EU.
<G-vec00291-001-s236><blame.geben><de> Alle, die vor Lampedusa starben, wurden ermordet, und schuld daran ist die Flut an bösartigen immigrantenfeindlichen Gesetzen, die von italienischen Regierungen, ob Mitte-links oder Mitte-rechts, und der EU durchgesetzt wurden.
<G-vec00291-001-s237><blame.geben><en> But the band itself is significantly to blame for that.
<G-vec00291-001-s237><blame.geben><de> Aber die Band ist selbst maßgeblich schuld daran.
<G-vec00291-001-s238><blame.geben><en> Accept if you were to blame for anything that made the situation worse.
<G-vec00291-001-s238><blame.geben><de> Akzeptiere es, wenn du schuld daran warst, dass sich eine Situation verschlimmert hat.
<G-vec00291-001-s239><blame.geben><en> Mile Boskov, President of Business Confederation of Macedonia said that all parties are to blame, because nobody takes any action, but all are talking about it.
<G-vec00291-001-s239><blame.geben><de> Laut Mile Boskov, Präsident des Wirtschaftsverbandes in Mazedonien, tragen alle Parteien Schuld daran, da niemand irgendeine Maßnahme ergreift, obwohl alle davon sprechen.
<G-vec00291-001-s240><blame.geben><en> Hardly surprising, considering Joachim ends up in bed with his mother-in-law, manages to hit on Anna's sister, Kathi (Anna Fischer), is to blame for Anna's grandmother (Bibiana Zeller) ending up in hospital and – worse still – he manages to even kill the beloved family dog.
<G-vec00291-001-s240><blame.geben><de> Kein Wunder, denn Joachim landet bei der Schwiegermutter im Bett, baggert Annas Schwester Kathi (Anna Fischer) an, ist Schuld daran, dass Annas GroÃÅ ̧mutter (Bibiana Zeller) im Krankenhaus liegt, und -das Schlimmste- er befördert den geliebten Hund der Familie ins Jenseits.
<G-vec00291-001-s241><blame.geben><en> ðŸTM But I really don't think that Clark is the one to blame.
<G-vec00291-001-s241><blame.geben><de> 🙁 Aber ich glaube ehrlich nicht, dass Clark derjenige ist, der schuld daran ist.
<G-vec00291-001-s242><blame.geben><en> The Democrats are to blame for the shutdown and for illegal immigrants posing a threat to the US - at least that's what Trump's first televised address to the nation would have us believe.
<G-vec00291-001-s242><blame.geben><de> Die Demokraten sind schuld am Shutdown und daran, dass die USA von illegalen Einwanderern bedroht werden: So lautet in Kürze der Inhalt von Trumps erster TV-Rede an die Nation.
<G-vec00291-001-s243><blame.geben><en> And it is the Bolsheviki who are to blame.
<G-vec00291-001-s243><blame.geben><de> Und es sind die Bolschewiki, die schuld daran sind.
<G-vec00291-001-s244><blame.geben><en> Scatter printed teasers like: 'Tickle me', 'Come Play Dress Up', 'Blame It on the Boa', 'Flirt Like You Mean It' and 'Dance With Me' near flickering candlelight votives around the room.
<G-vec00291-001-s244><blame.geben><de> "Scatter gedruckt Teaser wie: 'Tickle me', ""Kommen Spiel Dress Up ', ""Schuld daran ist der Boa"", ""Flirt wie Sie Durchschnitt es' und ""Dance With Me' in der Nähe von flackernden Kerzenlicht Windlichter durch den Raum."
<G-vec00291-001-s245><blame.geben><en> It will come through people; and if we blame the people and focus our attention on them, we have missed the point.
<G-vec00291-001-s245><blame.geben><de> Er wird durch Leute kommen; und wenn wir den Leuten die Schuld geben und unsere Aufmerksamkeit auf sie lenken, haben wir das Entscheidende verpasst.
<G-vec00291-001-s246><blame.geben><en> However, to blame users for all those bad things is a distraction from the fact that it's the policy makers who are ultimately responsible.
<G-vec00291-001-s246><blame.geben><de> Aber die Schuld für diese schlimmen Dinge den Konsumierenden zu geben, lenkt nur von der Tatsache ab, dass letztendlich die politischen Entscheidungsträgerinnen und -träger dafür verantwortlich sind.
<G-vec00291-001-s247><blame.geben><en> If it is true that there are higher percentages of the mentally weak, the eccentric, the unbalanced, the hypersensitive and the hypertense among homosexuals than among those oriented in the usual way, the blame should not be placed on the predisposition, but rather upon the circumstances in which these people find themselves: one who lives constantly under the onus of attitudes and laws that stamp his inclination as inferior, must be of an unusually robust nature to retain his full worth in every respect.
<G-vec00291-001-s247><blame.geben><de> Wenn es wahr ist, dass der Prozentzatz der seelisch Schwachen, Verschrobenen, Gleichgewichtslosen, der Hypersensitiven und Ueberreizten unter Homosexuellen größer ist als unter Personen mit der regulären Triebrichtung, so muss man nicht der Anlage, sondern der Lage dieser Menschen die Schuld geben: Wer ständig unter dem Druck von Anschauungen und Gesetzen lebt, die seine Eigenart zur Minderwertigkeit stempeln, muss von Natur ungewöhnlich robust sein, um in jeder Hinsicht vollwertig zu bleiben.
<G-vec00291-001-s248><blame.geben><en> Sometimes the karma connected with a particular time can also be linked to the personal karma. In no case, however, should one ever blame the Teacher for the karma.
<G-vec00291-001-s248><blame.geben><de> Zuweilen kann das Karma mit festgelegtem Datum auf ein persönliches übertragen werden, doch in keinem Fall sollte man je dem Lehrer die Schuld geben.
<G-vec00291-001-s249><blame.geben><en> "Although France's President Hollande has made many mistakes, it's unfair to blame him alone for his country's political paralysis, the left-liberal daily Süddeutsche Zeitung writes: ""For decades France has failed to prepare its state, administration, taxation and social systems for the globalised world. Hollande's conservative predecessors Chirac and Sarkozy undertook too little."
<G-vec00291-001-s249><blame.geben><de> "Obwohl Frankreichs Präsident Hollande viele Fehler gemacht hat, ist es unfair, ihm allein die Schuld an der politischen Lähmung des Landes zu geben, meint die linksliberale Süddeutsche Zeitung: ""Frankreich hat es über Jahrzehnte versäumt, Staat und Verwaltung, Steuer- und Sozialsystem auf die Globalisierung vorzubereiten."
<G-vec00291-001-s250><blame.geben><en> However, a victim can complain secretly to the bosses with evidence rather than just making judgments and putting blame on someone who doesn’t even aware of the evil activity.
<G-vec00291-001-s250><blame.geben><de> Jedoch kann ein Opfer beschweren sich heimlich bei den Chefs mit Beweisen Anstatt nur Urteile zu fällen und jemandem die Schuld zu geben, der sich der bösen Aktivitäten nicht einmal bewusst ist.
<G-vec00291-001-s251><blame.geben><en> Following independence the SPLM will no longer be able to blame the common enemy in Khartoum, and frozen conflicts among southern ethnic groups may flare up as frustration with the newly sovereign Juba government grows.
<G-vec00291-001-s251><blame.geben><de> "Ist die Unabhängigkeit erreicht, kann die SPLM nicht länger dem gemeinsamen Feind in Khartum die Schuld geben und ""eingefrorene"" Konflikte zwischen Ethnien im Süden können erneut aufflackern, wenn die Enttäuschung über die souveräne Regierung in Juba wachsen sollte."
<G-vec00291-001-s252><blame.geben><en> "The thing is, with these sites you can't say that the videos suck, that the quality is not on point but you can blame the ""other"" mother site that actually hosts the video."
<G-vec00291-001-s252><blame.geben><de> "Die Sache ist, mit diesen Seiten kann man nicht sagen, dass die Videos schlecht sind, dass die Qualität nicht stimmt, aber man kann der ""anderen"" Mutterseite die Schuld geben, die das Video tatsächlich hostet."
<G-vec00291-001-s253><blame.geben><en> “Even though you cannot blame anyone for the stopping of the race, we are not at all pleased “, said Klasen.
<G-vec00291-001-s253><blame.geben><de> „Auch wenn man dafür niemandem die Schuld geben kann, ärgert uns der Rennabbruch sehr“, sagte Klasen.
<G-vec00291-001-s254><blame.geben><en> Zankou's (guest star Oded Feher) plan to make the sisters vulnerable so that he can take control of the Book of Shadows starts to work when Phoebe (Alyssa Milano) is left guilt-ridden after a classmate is brutally killed in front of her and comes back from the dead to blame her.
<G-vec00291-001-s254><blame.geben><de> Zaunkous Plan, die Schwestern anfällig zu machen, um Kontrolle über das Buch der Schatten zu erlangen, fängt an zu funktionieren, als Phoebe sich Vorwürfe darüber macht, nachdem einer ihrer Klassenkammeraden vor ihren Augen von einem Dämon getötet wird und anschließend aus dem Reich der Toten kommt um ihr die Schuld zu geben.
<G-vec00291-001-s255><blame.geben><en> You cannot blame your lunatic and outrageous hardcore ideologues partners like Bennett, Shaked, and Lieberman, who refuse to see the light and choose to live in the dark, not knowing what's in store for them.
<G-vec00291-001-s255><blame.geben><de> Sie können nicht Ihren irren und skandalöse, hartherzigen Ideologie-Partnern wie Bennett, Shaked und Lieberman die Schuld geben, die sich weigern, das Licht zu sehen und lieber im Dunkeln leben und die nicht wissen, was vor ihnen liegt.
<G-vec00291-001-s256><blame.geben><en> A professional setting from beginning to end, so if this goes wrong now, we have no one to blame other than ourselves.
<G-vec00291-001-s256><blame.geben><de> Ein professioneller Plan von A bis Z, wenn es also jetzt schiefläuft, haben wir niemandem, dem wir die Schuld geben können, außer uns selbst.
<G-vec00291-001-s257><blame.geben><en> Our relatives would argue that the 500 years of Ottoman rule were to blame, or others would blame the communists.
<G-vec00291-001-s257><blame.geben><de> Meine Verwandten würden die Schuld der 500-jährigen Herrschaft der Osmanen geben, andere würden den Kommunismus dafür verantwortlich machen.
<G-vec00291-001-s258><blame.geben><en> So, you (the US) have to solve your problem, rather than put the blame on us.
<G-vec00291-001-s258><blame.geben><de> Ihr (die USA) müsst euer Problem lösen, statt uns die Schuld zu geben.
<G-vec00291-001-s259><blame.geben><en> Pinning all the blame for this on Angela Merkel is facile.
<G-vec00291-001-s259><blame.geben><de> Dafür Angela Merkel die alleinige Schuld zu geben, ist billig.
<G-vec00291-001-s260><blame.geben><en> I mean the only blame is on the government not on the settlers.
<G-vec00291-001-s260><blame.geben><de> Ich denke, die einzige Schuld ist der Regierung zu geben, nicht den Siedlern.
<G-vec00291-001-s261><blame.geben><en> However, other observers reject attempts to lay all blame on outsiders.
<G-vec00291-001-s261><blame.geben><de> Andere Beobachter lehnen es jedoch ab, Außenstehenden die Schuld zu geben.
<G-vec00291-001-s262><blame.geben><en> They may be cross that an item isn’t there, but by the afternoon of Christmas Eve most will blame themselves for leaving it too late rather than blaming the store for not maintaining high stock levels.
<G-vec00291-001-s262><blame.geben><de> Es kann vorkommen, dass ein Kunde auf ein leeres Regal trifft, aber am Nachmittag vor Weihnachtsabend werden sich die meisten aufgrund der späten Einkäufe selbst die Schuld geben, anstatt das Geschäft dafür verantwortlich zu machen, keine hohen Bestände aufrechtzuerhalten.
<G-vec00291-001-s263><blame.geben><en> The biggest problem we have as black people is always placing the blame of our situation on whites.
<G-vec00291-001-s263><blame.geben><de> Unser größtes Problem ist es, dass wir Schwarzen den Weißen die Schuld an unserer Situation geben.
<G-vec00347-001-s181><blame.geben><en> “Even though you cannot blame anyone for the stopping of the race, we are not at all pleased “, said Klasen.
<G-vec00347-001-s181><blame.geben><de> „Auch wenn man dafür niemandem die Schuld geben kann, ärgert uns der Rennabbruch sehr“, sagte Klasen.
<G-vec00347-001-s182><blame.schieben><en> When he had managed once again to blame everything on his big brother and never got punished but always got comforted instead.
<G-vec00347-001-s182><blame.schieben><de> Wenn er es wieder geschafft hatte, alle Schuld auf den großen Bruder zu schieben, und niemals bestraft sondern immer nur getröstet zu werden.
<G-vec00347-001-s183><blame.schieben><en> For a university rector, it is easier to express exasperation over the lack of these things, to lay the blame on something else, on politicians, students, or external circumstances outside Austria.
<G-vec00347-001-s183><blame.schieben><de> Einfacher ist es nun wieder, als Rektor einer Uni, sich über das Fehlen dieses aufzuregen, die Schuld von sich zu schieben, auf die Politik, auf die Studenten, auf die Umstände außerhalb Österreichs.
<G-vec00347-001-s184><blame.schieben><en> Their foolish attempt to deceive people and put the blame on Falun Gong ultimately failed.
<G-vec00347-001-s184><blame.schieben><de> Ihr törichter Versuch, die Menschen zu täuschen und die Schuld auf Falun Gong zu schieben, schlug letztlich fehl.
<G-vec00347-001-s185><blame.schieben><en> They like to lay the blame on purported conspiracies against the Church in the media and politics.
<G-vec00347-001-s185><blame.schieben><de> Sie mögen es, die Schuld auf angebliche Verschwörungen gegen die Kirche in Medien und Politik zu schieben.
<G-vec00347-001-s186><blame.schieben><en> One observes constantly their efforts to deny the obvious, to reverse roles, and finally to place all blame on others.
<G-vec00347-001-s186><blame.schieben><de> Man beobachtet ständig ihre Bemühungen, das Offensichtliche zu leugnen, Rollen umzudrehen und schließlich alle Schuld auf andere zu schieben.
<G-vec00347-001-s187><blame.schieben><en> Another interesting finding was that around 60% of respondents lay the blame on legacy systems.
<G-vec00347-001-s187><blame.schieben><de> Ein weiteres interessantes Ergebnis unserer Umfrage war, dass rund 60% der Befragten die Schuld auf Legacy-Systeme schieben.
<G-vec00347-001-s191><blame.tragen><en> The servant who had brought him here was furious over the long trip and the many rejections, for which, in his opinion, Karl was alone to blame.
<G-vec00347-001-s191><blame.tragen><de> Der Diener, der ihn hierher gebracht hatte, war wütend über die lange Führung und die vielen Abweisungen, an denen seiner Meinung nach Karl allein die Schuld tragen musste.
<G-vec00347-001-s192><blame.tragen><en> Especially as each of us must own the blame while creating the solutions for what happens on the planet.
<G-vec00347-001-s192><blame.tragen><de> "Insbesondere deshalb, weil jeder von uns selbst die ""Schuld"" zu tragen hat, wenn wir die Lösungen dafür erschaffen, was auf den Planeten geschieht."
<G-vec00347-001-s193><blame.tragen><en> "However, ""our"" NWO politicians are to blame for this misery."
<G-vec00347-001-s193><blame.tragen><de> "Aber die Schuld für dieses Elend tragen ""unsere"" NWO-Politiker-Marionetten."
<G-vec00347-001-s194><blame.tragen><en> The fight for national emancipation, not to speak of socialism, is constantly sabotaged by the Québécois bourgeois nationalists and their lackeys on the left, who are no less to blame for the horrors of January 29.
<G-vec00347-001-s194><blame.tragen><de> Der Kampf für nationale Emanzipation, geschweige denn für Sozialismus, wird von den bürgerlichen Nationalisten Québecs und ihren Lakaien auf der Linken, die an den schrecklichen Ereignissen vom 29.Januar nicht weniger Schuld tragen, ständig sabotiert.
<G-vec00347-001-s195><blame.treffen><en> The horseman lies dying in Leon's arms. He tells his friend that William is not to blame.
<G-vec00347-001-s195><blame.treffen><de> Sterbend liegt er in Leons Armen und berichtet seinem Freund, dass William keine Schuld trifft.
<G-vec00347-001-s196><blame.treffen><en> She hates Richard and loves Richard, all at the same time, thinking he is the one to blame for Curtis' death on the one hand, but knowing he is not on the other hand.
<G-vec00347-001-s196><blame.treffen><de> Sie hasst Richard und liebt Richard, alles zugleich, einerseits in dem Glauben, dass ihn die Schuld an Curtis' Tod trifft, andererseits aber in dem Wissen, dass das nicht der Fall ist.
<G-vec00347-001-s197><blame.treffen><en> Who is to blame is not the only question to ask and no one is innocent isn't good enough as an answer if we want to find out what really happened and who is a perpetrator.
<G-vec00347-001-s197><blame.treffen><de> Wen die Schuld trifft, ist nicht die einzige Frage, die gestellt werden muss und dass niemand unschuldig ist, reicht auch nicht als Antwort, wenn wir herausfinden wollen, was wirklich passiert ist und wer der Täter ist.
<G-vec00347-001-s198><blame.tragen><en> They cannot see who is to blame for the situation that has emerged since the fall of the apartheid regime.
<G-vec00347-001-s198><blame.tragen><de> Sie können nicht erkennen, wer für die Situation, die sich nach dem Fall des Apartheid-Regimes entwickelte, die Schuld trägt.
<G-vec00347-001-s199><blame.tragen><en> Let us use the example of a sexually abused girl who grows up believing the lie it was her fault, that she somehow was too attractive or flirty to her uncle/dad/neighbor, so she at shared the blame for her abuse.
<G-vec00347-001-s199><blame.tragen><de> Lasst uns das Beispiel eines sexuell missbrauchten Mädchens nehmen, das aufwächst und der Lüge glaubt, dass es seine Schuld war, weil sie irgendwie zu attraktiv oder flirtend zu ihrem Onkel, Vater oder Nachbarn gewesen ist, weswegen sie zum Teil die Schuld für ihren Missbrauch trägt.
<G-vec00347-001-s200><blame.tragen><en> No matter which side is to blame, the clearing of differences and misunderstandings calls for negotiations.
<G-vec00347-001-s200><blame.tragen><de> Unabhängig davon, welche Seite die Schuld trägt, erfordern die Meinungsverschiedenheiten und Missverständnisse gemeinsame Gespräche, um sie zu bereinigen.
<G-vec00347-001-s201><blame.tragen><en> Netizens are debating who is to blame.
<G-vec00347-001-s201><blame.tragen><de> Netzbürger debattieren, wer die Schuld trägt.
<G-vec00347-001-s202><blame.tragen><en> Indeed, it is not possible for a person who sees things from a German perspective not to have any doubts, since Germany bore a great degree of blame for two world wars that inflicted endless suffering on the world (and all the blame for the Second World War).
<G-vec00347-001-s202><blame.tragen><de> Wer aus der Perspektive Deutschlands denkt und urteilt, also eines Landes, das an zwei Weltkriegen erhebliche Schuld trägt (am Zweiten Weltkrieg sogar die Alleinschuld) und das unendliches Leid über die Welt gebracht hat, kann nicht ohne Zweifel sein.
<G-vec00347-001-s203><blame.zuweisen><en> However, after all he can only give himself the blame for all that is about to come eventually.
<G-vec00347-001-s203><blame.zuweisen><de> Doch eigentlich kann er nur sich selbst die Schuld zuweisen für alles, was schließlich kommt.
<G-vec00347-001-s204><blame.zuweisen><en> You cannot pin the blame on Siemens in such a case: the new CPU does behave according to IEC 1131.
<G-vec00347-001-s204><blame.zuweisen><de> Siemens kann man in einem solchen Fall keine Schuld zuweisen: die neue CPU verhält sich ja gemäß IEC 1131.
<G-vec00347-001-s205><blame.zuweisen><en> After Eli assures him that he is not looking to make trouble for Jack or his company or lay blame, but is trying to help a young woman to get her life back, Jack tells him that Rick Hartman was a typical pencil pusher who one day turned up and started booking the most dangerous tours.
<G-vec00347-001-s205><blame.zuweisen><de> Nachdem Eli ihm versichert hat, dass er ihm keinen Ärger machen will und auch keine Schuld zuweisen, sondern lediglich versucht, einer jungen Frau zu helfen, ihr Leben wieder in den Griff zu bekommen, erzählt Jack Eli, dass Rick Hartman ein typischer Büromensch war, der eines Tages auftrauchte und nur sehr gefährliche Touren buchte.
<G-vec00347-001-s206><blame.zuschieben><en> "When an impossible person makes a statement like, ""Everyone else likes me,"" he is trying to shift the blame onto you."
<G-vec00347-001-s206><blame.zuschieben><de> Wenn eine unmögliche Person eine Aussage wie, „Jeder sonst mag mich“, trifft, versucht sie damit nur, dir die Schuld zuzuschieben.
<G-vec00347-001-s207><blame.zuschieben><en> To divert from their wretched, class-collaborationist betrayals of the mineworkers in their own union—betrayals now sealed with the blood of the 34 massacred workers—the NUM tops have sought to lay the blame on a rival union, the Association of Mineworkers and Construction Union (AMCU), which has been making inroads especially among the lowest-paid sections of the mineworkers.
<G-vec00347-001-s207><blame.zuschieben><de> Um von ihrer elenden – nun mit dem Blut der 34 massakrierten Arbeiter besiegelten – Verratspolitik der Klassenzusammenarbeit gegen die Bergarbeiter in ihrer eigenen Gewerkschaft abzulenken, haben die NUM-Führer versucht, einer konkurrierenden Gewerkschaft die Schuld zuzuschieben: der Association of Mineworkers and Construction Union (AMCU), die besonders unter den am schlechtesten bezahlten Schichten der Bergarbeiter Mitglieder gewonnen hat.
<G-vec00347-001-s208><blame.zuschieben><en> It was noticeable that, at this stage, no one seemed to put the blame on the Government.
<G-vec00347-001-s208><blame.zuschieben><de> Es ist bemerkenswert, dass zu diesem Zeitpunkt niemand der Regierung die Schuld zuzuschieben schien.
<G-vec00347-001-s216><blame.erklaeren><en> How convenient then, that there is already someone to blame for the economic misery, namely 'the West', which still considers Saudi Arabia its main partner in the region.
<G-vec00347-001-s216><blame.erklaeren><de> "Wie praktisch, dass der 'Schuldige' für die wirtschaftliche Misere bereits fest steht: ""der Westen"", der weiterhin allein Saudi-Arabien als Hauptpartner in der Region betrachtet."
<G-vec00347-001-s217><blame.erklaeren><en> blame the victims, saying that it's their own fault, it just leaves me enraged and at the same time terribly sad – to hear that even after all these incidents, this voice is still way too loud.
<G-vec00347-001-s217><blame.erklaeren><de> die Opfer als Schuldige darstellen, dann macht es mich wütend und gleichzeitig wahnsinnig traurig, zu sehen, dass das selbst nach diesen Vorfällen noch viel zu laut zu hören ist.
<G-vec00347-001-s218><blame.erklaeren><en> At the police station the question of who is legally to blame is discussed.
<G-vec00347-001-s218><blame.erklaeren><de> Auf der Polizeistation wird diskutiert, wer der eigentliche Schuldige ist.
<G-vec00291-001-s327><blame.tadeln><en> The eight worldly conditions are gain and loss, pleasure and pain, praise and blame, and fame and disrepute.
<G-vec00291-001-s327><blame.tadeln><de> Die acht weltlichen Bedingungen sind Gewinn und Verlust, Freude und Leiden, Lob und Tadel, Ruhm und Verruf.
<G-vec00291-001-s328><blame.tadeln><en> The vicissitudes are eight in number: gain and loss, good-repute and ill-repute, praise and blame, joy and sorrow.
<G-vec00291-001-s328><blame.tadeln><de> Die Wechselhaftigkeiten sind acht an der Zahl: Gewinn und Verlust, gutes Ansehen und schlechter Ruf, Lob und Tadel, Freude und Leid.
<G-vec00291-001-s329><blame.tadeln><en> Mr. Dirkschneider is of course no motional wonder (anymore, for that he has his whippersnappers) but his vocal performance was without wrong and blame, despite the cold weather.
<G-vec00291-001-s329><blame.tadeln><de> Herr Dirkschneider selbst ist natürlich kein Bewegungswunder mehr (dafür hat er ja seine Jungspunde), dafür aber immer gesanglich ohne Fehl und Tadel, so auch trotz der kühlen Witterung an diesem Abend.
<G-vec00291-001-s330><blame.tadeln><en> Criticism and blame are negative factors and the things of the evil spirit of communism.
<G-vec00291-001-s330><blame.tadeln><de> Kritik und Tadel sind negative Faktoren und Dinge des bösartigen Geistes des Kommunismus.
<G-vec00291-001-s331><blame.tadeln><en> The first one to bring the gifts as a just tribute to my holy majesty shall also be the first to earn the praise of justice, and I shall accept from him the lesser as if it were much. The later ones will have to bring much, and I shall receive it as if it were only little because thereby I shall measure their laziness and their actions will bring them just praise or just blame.
<G-vec00291-001-s331><blame.tadeln><de> Der erste, der da bringen wird die Gaben als rechte Gebühr für meine heilige Majestät, der wird auch das Lob der Gerechtigkeit als erster ernten, und ich werde das wenigere von ihm annehmen, als wäre es vieles; die späteren aber werden müssen bringen vieles, und ich werde es annehmen, als wäre es nur weniges, da ich daraus ihre Trägheit bemessen und ihren Handlungen ein gerechtes Lob oder einen gerechten Tadel werde zukommen lassen; und der letzte aber wird übergeben werden dem ersten, damit er sich bessere im Eifer und in der Strenge aller gerechten Sachen.
<G-vec00291-001-s332><blame.tadeln><en> And what aggravates the mischief is that the journalists who are most to blame are not the amusing journalists who write for what are called Society papers.
<G-vec00291-001-s332><blame.tadeln><de> Und was noch ärger ist, die Journalisten, die den schwersten Tadel verdienen, sind nicht etwa die unterhaltenden Zeitungsschreiber, die für die sogenannten Gesellschaftsblätter schreiben.
<G-vec00291-001-s333><blame.tadeln><en> O you who have believed, whoever of you should revert from his religion - Allah will bring forth [in place of them] a people He will love and who will love Him [who are] humble toward the believers, powerful against the disbelievers; they strive in the cause of Allah and do not fear the blame of a critic.
<G-vec00291-001-s333><blame.tadeln><de> O die ihr glaubt, wer von euch sich von seiner Religion abkehrt -, so wird Allah Leute bringen, die Er liebt und die Ihn lieben, bescheiden gegenüber den Gläubigen, mächtig (auftretend) gegenüber den Ungläubigen, und die sich auf Allahs Weg abmühen und nicht den Tadel des Tadlers fürchten.
<G-vec00291-001-s334><blame.tadeln><en> This elevated position of criticism, its praise and blame pronounced with a full knowledge of all the circumstances, has in itself nothing which hurts our feelings; it only does so if the critic pushes himself forward, and speaks in a tone as if all the wisdom which he has obtained by an exhaustive examination of the event under consideration were really his own talent.
<G-vec00291-001-s334><blame.tadeln><de> Diese höhere Stellung der Kritik, dieses Lob und der Tadel nach einer völligen Einsicht der Sache hat auch an sich nichts, was unser Gefühl verletzt, sondern bekommt es erst dann, wenn der Kritiker sich persönlich hervordrängt und in einem Ton spricht, als wäre alle die Weisheit, die ihm durch die vollkommene Einsicht der Begebenheit gekommen ist, sein eigentümliches Talent.
<G-vec00291-001-s335><blame.tadeln><en> Ways of the world — fortune, loss, praise, blame, status, disgrace, pleasure, and pain.
<G-vec00291-001-s335><blame.tadeln><de> Wege der Welt: Glück, Verlust, Lob, Tadel, Status, Schande, Wohl und Weh.
<G-vec00291-001-s336><blame.tadeln><en> But another and much more powerful stimulus to the development of the social virtues, is afforded by the praise and the blame of our fellow-men.
<G-vec00291-001-s336><blame.tadeln><de> Es gibt aber noch einen andern und noch kräftigeren Antrieb zur Entwickelung der socialen Tugenden, nämlich das Lob und den Tadel unserer Mitmenschen.
<G-vec00291-001-s337><blame.tadeln><en> The appreciation and the bestowal of praise and blame both rest on sympathy; and this emotion, as we have seen, is one of the most important elements of the social instincts.
<G-vec00291-001-s337><blame.tadeln><de> Beides, sowohl die Anerkennung' und das Aussprechen von Lob als das vom Tadel, beruht auf Sympathie, und diese Erregung ist, wie wir gesehen haben, eines der bedeutungsvollsten Elemente der socialen Instincte.
<G-vec00291-001-s338><blame.tadeln><en> As all men desire their own happiness, praise or blame is bestowed on actions and motives, according as they lead to this end; and as happiness is an essential part of the general good, the greatest-happiness principle indirectly serves as a nearly safe standard of right and wrong.
<G-vec00291-001-s338><blame.tadeln><de> "Da alle Menschen ihre eigene Glückseligkeit wünschen, so wird Lob oder Tadel für Handlungen und Motive in dem Maasse ausgetheilt, als sie zu jenem Ziele führen; und da das Glück ein wesentlicher Theil des allgemeinen Besten ist, so dient das Princip ""des größten Glücks* indireet als ein nahezu richtiger Maassstab für Kecht und Unrecht."
<G-vec00291-001-s339><blame.tadeln><en> Consequently man would be influenced in the highest degree by the wishes, approbation, and blame of his fellow-men, as expressed by their gestures and language.
<G-vec00291-001-s339><blame.tadeln><de> In Folge hiervon wird der Mensch durch die Wünsche, den Beifall und Tadel seiner Mitmenschen, wie diese durch deren Gesten und Sprache ausgedrückt werden, bedeutend' beeinfhisst.
<G-vec00291-001-s340><blame.tadeln><en> When ye are exalted above praise and blame, and your will would command all things, as a loving one's will: there is the origin of your virtue.
<G-vec00291-001-s340><blame.tadeln><de> Wenn ihr erhaben seid über Lob und Tadel, und euer Wille allen Dingen befehlen will, als eines Liebenden Wille: da ist der Ursprung eurer Tugend.
<G-vec00291-001-s341><blame.tadeln><en> Surveying the world with the eye of a Buddha, I saw beings with little dust in their eyes and with much dust in their eyes, with keen faculties and with dull faculties, with good qualities and with bad qualities, easy to teach and hard to teach, and some who dwelt seeing fear and blame in the other world.
<G-vec00291-001-s341><blame.tadeln><de> Als ich die Welt mit dem Auge eines Buddha begutachtete, sah ich Wesen mit wenig Staub auf den Augen und mit viel Staub auf den Augen, mit scharfen geistigen Fähigkeiten und mit dumpfen geistigen Fähigkeiten, mit guten Eigenschaften und mit schlechten Eigenschaften, leicht zu lehren und schwer zu lehren, und einige, die weilten, indem sie Furcht und Tadel in der anderen Welt erblickten.
<G-vec00291-001-s342><blame.tadeln><en> Beset by dukkha obstructed by dukkha, subject to praise and blame, loss and gain, fame and ill-fame, happiness and unhappiness.
<G-vec00291-001-s342><blame.tadeln><de> Von dukkha befallen, von dukkha behindert, unterworfen Lob und Tadel, Verlust und Gewinn, Ruhm und Verruf, Glück und Unglück.
<G-vec00291-001-s343><blame.tadeln><en> Praise, blame, and so forth are perishable entities.
<G-vec00291-001-s343><blame.tadeln><de> Lob, Tadel und so weiter sind vergängliche Größen.
<G-vec00291-001-s344><blame.tadeln><en> "The Malamatis were especially aware of this danger, and would often act in an ""unspiritual"" way in order to attract blame and negate the ego."
<G-vec00291-001-s344><blame.tadeln><de> "Die Malaømatiøs waren sich dieser Gefahr besonders bewusst und handelten oft auf ""unspirituelle"" Weise, um Tadel auf sich zu ziehen und das Ego außer Gefecht zu setzen."
<G-vec00291-001-s345><blame.tadeln><en> "This game of praise and blame, between strokes and strokes makes them happy, especially when it comes from people like them or from the ""Jewish state""."
<G-vec00291-001-s345><blame.tadeln><de> "Dieses Spiel zwischen Lob und Tadel, zwischen Schlägen und Streicheln macht sie glücklich, besonders wenn es von Menschen wie ihnen oder vom ""Jüdischen Staat"" kommt."
<G-vec00291-001-s346><blame.tadeln><en> One should not blame oneself for this fiery habit, but should observe the properties of Fire.
<G-vec00291-001-s346><blame.tadeln><de> Man sollte sich nicht wegen dieser feurigen Gewohnheit tadeln, sollte jedoch die Eigenschaften des Feuers beobachten.
<G-vec00291-001-s347><blame.tadeln><en> If I were to be arrogant, I would blame myself for this; the wise, having investigated, would censure me for this; and on the dissolution of the body, after death, because of being arrogant an unhappy destination would be expected.
<G-vec00291-001-s347><blame.tadeln><de> Wenn ich überheblich wäre, würde ich mich selbst dafür tadeln; und die Weisen, die nachgeforscht haben, würden mich dafür tadeln; und bei der Auflösung des Körpers, nach dem Tode, wäre ein unglücklicher Bestimmungsort, wegen der Überheblichkeit, zu erwarten.
<G-vec00291-001-s348><blame.tadeln><en> This article is not intended to blame Beijing practitioners.
<G-vec00291-001-s348><blame.tadeln><de> Dieser Artikel beabsichtigt nicht, Pekinger Praktizierende zu tadeln.
<G-vec00291-001-s349><blame.tadeln><en> Can't really blame you.
<G-vec00291-001-s349><blame.tadeln><de> Kann nicht Sie wirklich tadeln.
<G-vec00291-001-s350><blame.tadeln><en> I could not blame the local police.
<G-vec00291-001-s350><blame.tadeln><de> Ich könnte die lokale Polizei nicht tadeln.
<G-vec00291-001-s351><blame.tadeln><en> In conclusion, we (the souls) are the masters of our own destiny and we should not blame anyone or anything else for our own destiny.
<G-vec00291-001-s351><blame.tadeln><de> Als schlu©¬folgerung sind wir (die Seelen) die Meister unseres eigenen Schicksals und wir sollten nicht jedermann oder noch etwas für unser eigenes Schicksal tadeln.
<G-vec00291-001-s352><blame.tadeln><en> The Lyricist's shortcoming is his inclination to blame others considering them guilty of his own misfortunes.
<G-vec00291-001-s352><blame.tadeln><de> Das Manko des Lyrikers ist seine Neigung, andere zu tadeln, wenn sie seiner Meinung nach an seinem eigenen Unglück Schuld sind.
<G-vec00291-001-s353><blame.tadeln><en> You cannot blame anyone else, and you can't look outside of yourself for someone else to create the miracles for you.
<G-vec00291-001-s353><blame.tadeln><de> Sie können nicht niemand sonst tadeln, und Sie können nicht außerhalb selbst nach jemand anderes schauen, um die Wunder für Sie zu ver...
<G-vec00291-001-s354><blame.tadeln><en> They are outraged that the phrases USA is to blame, Russia is to blame, Obama is to blame, Medvedev is to blame entered into the search engine Google, translated as the United States not to blame, to blame Russia, Obama is not guilty, guilty Medvedev.
<G-vec00291-001-s354><blame.tadeln><de> Sie sind empört darüber, dass die Sätze USA ist schuld Russland, der ist schuld, Obama ist schuld, ist Medwedew in die Suchmaschine Google, übersetzt als die Vereinigten Staaten in die Schuld nicht zu tadeln, zu Russland verantwortlich, Obama ist nicht schuldig, schuldig Medwedew.
<G-vec00291-001-s355><blame.tadeln><en> He developed his style from traditional Malian songs, ballads that either praise or blame.
<G-vec00291-001-s355><blame.tadeln><de> Seinen Stil hat er aus malischen Volksliedern entwickelt, aus Liedern, die loben oder tadeln.
<G-vec00291-001-s356><blame.tadeln><en> Later blame themselves for being a victim of erasing complete valuable data saved in USB drive.
<G-vec00291-001-s356><blame.tadeln><de> Später tadeln Sie sich dafür, ein Opfer von Löschen von wertvollen Daten auf dem USB Stick gespeichert werden.
<G-vec00291-001-s357><blame.tadeln><en> If you do, you have no one to blame but yourself.
<G-vec00291-001-s357><blame.tadeln><de> Wenn du, hast du zu tadeln keine, aber sich.
<G-vec00291-001-s358><blame.tadeln><en> Those on the left would blame the right.
<G-vec00291-001-s358><blame.tadeln><de> Die auf der linken Seite würden die Rechte tadeln.
<G-vec00291-001-s359><blame.tadeln><en> In a culture of blame-shifting we often look for someone to blame for our predicament.
<G-vec00291-001-s359><blame.tadeln><de> In einer Schuld-verschiebenden Kultur von suchen uns häufig jemand, um für unsere Zwangslage zu tadeln.
<G-vec00291-001-s360><blame.tadeln><en> We blame God in our ignorance.
<G-vec00291-001-s360><blame.tadeln><de> Wir tadeln Gott in unserer Unwissenheit.
<G-vec00291-001-s361><blame.tadeln><en> The director of orthopaedic department at first showed sympathy for Rongrong, but after he was pressured by the 610 Office (an organisation of special agents just for persecuting Falun Gong) and the Shenyang Judiciary Bureau, he started to blame us instead.
<G-vec00291-001-s361><blame.tadeln><de> Zuerst hatte der Leiter der orthopädischen Abteilung Mitgefühl mit Rongrong, doch nachdem er vom Büro 610 und dem Justizbüro in Shenyang unter Druck gesetzt worden war, begann er stattdessen uns zu tadeln.
<G-vec00291-001-s362><blame.tadeln><en> Blame this on Taft's predecessor.
<G-vec00291-001-s362><blame.tadeln><de> Tadeln dieses auf Vorgänger Tafts.
<G-vec00291-001-s363><blame.tadeln><en> 2007-11-13 22:16:19 - The asbestos disaster - who is to blame The ancient Greeks, Romans and Egyptians were all aware of the health dangers of asbestos.
<G-vec00291-001-s363><blame.tadeln><de> 2007-11-13 22:16:19 - Der Asbest-Unfall - Wer Tadeln Soll Der alte Grieche, das Romans und die Ägypter berücksichtigten alle die Gesundheit Gefahren des Asbests.
<G-vec00291-001-s364><blame.tadeln><en> I did my best not to blame my husband and find fault in him.
<G-vec00291-001-s364><blame.tadeln><de> Ich bemühte mich sehr, meinen Mann nicht zu tadeln und den Fehler bei ihm zu suchen.
<G-vec00291-001-s365><blame.tadeln><en> So do not blame me but blame yourselves.
<G-vec00291-001-s365><blame.tadeln><de> So tadelt nicht mich, sondern tadelt euch selber.
<G-vec00291-001-s367><blame.tadeln><en> "Kennedy laughed, ""Can’t say I blame him."
<G-vec00291-001-s367><blame.tadeln><de> "Gelachtes Kennedy, ""können nicht sagen, daß I ihn tadelt."
<G-vec00291-001-s368><blame.machen><en> In Belgium, the judge Genevieve Denisti stated that the businessman, the victim of numerous robberies, he is to blame for his misfortune: “It is unwise to be driving around in a Jaguar and settle in a nice house in a poor suburb of Charleroi.
<G-vec00291-001-s368><blame.machen><de> In Belgien, erklärte der Richter Genevieve Denisti, dass der Geschäftsmann das Opfer zahlreicher Raubüberfälle, ist er für sein Unglück verantwortlich: “Es ist unklug, zu fahren um in einem Jaguar und sich in einem schönen Haus in einem armen Stadtteil von Charleroi.
<G-vec00291-001-s369><blame.machen><en> It would be a mistake to blame only Virgin Interactive, since the hardcore trial simulation happened to target a much thinner layer of gamers than its rival could, and the fine-tuning of the physics engine didn't fit the game-play that well.
<G-vec00291-001-s369><blame.machen><de> Es wäre ein Fehler, nur Virgin Interactive verantwortlich sein, da die Hardcore-Testsimulation zufällig ein viel dünner Schicht von Spielern als sein Rivale zielen konnte, und die Feinabstimmung der Physik-Engine passe nicht in die Spiel-Spiel, das gut.
<G-vec00291-001-s370><blame.machen><en> The bitter truth is that London and Paris have only themselves to blame for the refugee problem.
<G-vec00291-001-s370><blame.machen><de> Die bittere Wahrheit ist, dass London und Paris für die Flüchtlingsproblematik selbst verantwortlich sind.
<G-vec00291-001-s371><blame.machen><en> Children often believe they are to blame for the violence.
<G-vec00291-001-s371><blame.machen><de> Kinder glauben oft für die Gewalt verantwortlich zu sein.
<G-vec00291-001-s372><blame.machen><en> In the last text-threat from ITS Brazil, where they blame the Hambach Forest defenders for the death of the comrade who fell from the trees, we find the jealousy, the resentment, the bitterness of those who understand nothing about what it is that we are fighting for.
<G-vec00291-001-s372><blame.machen><de> Im letzten Drohbrief der ITS Brasilien, in dem sie die Verteidiger*innen des Hambacher Forsts für den Tod des Gefährten der vom Baum gestürzt ist verantwortlich machen, merken wir die Eifersucht, die Bitterkeit derjenigen, die Nichts von all dem für das wir kämpfen verstehen.
<G-vec00291-001-s373><blame.machen><en> In these instances, something else is clearly to blame, and scientists have pinpointed almost a dozen possible culprits.
<G-vec00291-001-s373><blame.machen><de> Für diese Allergien muss offensichtlich etwas anderes verantwortlich sein, und die Forscher haben fast ein Dutzend möglicher Übeltäter ausfindig gemacht.
<G-vec00291-001-s374><blame.machen><en> Two factors were chiefly to blame: Firstly, the natural and nuclear catastrophe in Japan disrupted supply chains around the globe.
<G-vec00291-001-s374><blame.machen><de> Insbesondere zwei Faktoren zeichnen sich hierfür verantwortlich: Zum einen hat die Natur- und Reaktorkatastrophe in Japan die Produktionsketten global behindert.
<G-vec00291-001-s375><blame.machen><en> Don't blame Satan for your predicament.
<G-vec00291-001-s375><blame.machen><de> Mache nicht Satan für deine mißliche Lage verantwortlich.
<G-vec00291-001-s376><blame.machen><en> Vandana Shiva’s response to a question about feeding such a growing population after her recent Reith lecture was simply to talk of “non-sustainable population growth” and to blame it on “non-sustainable development”:
<G-vec00291-001-s376><blame.machen><de> Als Vandana Shiva kürzlich nach einer Vorlesung in Reith nach der Ernährung einer so stark wachsenden Bevölkerung gefragt wurde, war ihre Reaktion, einfach von „nicht tragbarem Bevölkerungswachstum“ zu sprechen, für das sie eine „nicht nachhaltige Entwicklung“ verantwortlich machte: Sehen Sie sich die Zahlen an.
<G-vec00291-001-s377><blame.machen><en> The implication is that man has no responsibility for his action and whatever he does or however he errs and falls in consequence, the Divine Force is to blame. It may be so, but in that case there is no need or utility in doing sadhana.
<G-vec00291-001-s377><blame.machen><de> Die Folgerung deiner Frage ist, dass der Mensch für sein Tun nicht zur Rechenschaft gezogen werden kann, und für alles, was er tut oder wie sehr er auch irrt und folglich strauchelt, die Göttliche Kraft verantwortlich ist.
<G-vec00291-001-s378><blame.machen><en> Actually, we don’t blame Matt, we thanks him for making the game just that little bit more interesting, not to mention the whole movie just that little bit more Oscar Worthy.
<G-vec00291-001-s378><blame.machen><de> Tatsächlich, wir nicht verantwortlich Matt, wir danken ihm für die Herstellung, das Spiel noch ein bisschen interessanter, nicht den ganzen Film noch ein bisschen mehr Oscar Worthy erwähnen.
<G-vec00291-001-s379><blame.machen><en> Based on her man, who was to blame for the incident, expects to receive a suspended sentence.
<G-vec00291-001-s379><blame.machen><de> Basierend auf ihren Mann, der für den Vorfall verantwortlich war, erwartet eine Bewährungsstrafe erhalten.
<G-vec00291-001-s380><blame.machen><en> We are not to blame for what has produced the results that we are now witnessing.
<G-vec00291-001-s380><blame.machen><de> Wir sind nicht verantwortlich für das, was die Ereignisse, die wir heute erleben, produzieren konnte.
<G-vec00291-001-s381><blame.machen><en> The question of who is actually to blame for the problems quite rightly inflames tempers, but in the middle of a crisis of confidence, dwelling on that does not resolve the problem.
<G-vec00291-001-s381><blame.machen><de> Die Schuldfrage, wer für die Probleme eigentlich verantwortlich ist, erhitzt zu Recht die Gemüter, führt aber mitten in einer Vertrauenskrise nicht zu einer Lösung des Problems.
<G-vec00291-001-s382><blame.machen><en> Automatic Repair If your system failed due to an unknown cause and you basically do not know which part of the system is to blame for the failure, use Automatic Repair .
<G-vec00291-001-s382><blame.machen><de> Automatische Reparatur Wenn Ihr System aufgrund einer unbekannten Ursache ausgefallen ist und Sie nicht wissen, welcher Teil des Systems für den Ausfall verantwortlich ist, sollten Sie die Automatische Reparatur verwenden.
<G-vec00291-001-s383><blame.machen><en> Myth 5: Droughts and other natural disasters are to blame for hunger.
<G-vec00291-001-s383><blame.machen><de> Mythos 5: Dürren und andere Naturkatastrophen sind für den Hunger verantwortlich.
<G-vec00291-001-s384><blame.machen><en> Antonius' investigations show that the calcareous red algae, an old reef inhabitant, is to blame for a large percentage of the destroyed reefs.
<G-vec00291-001-s384><blame.machen><de> Die Untersuchungen von Antonius zeigen, dass die Kalkrotalge, ein alter Riffbewohner, für einen beachtlichen Teil der zerstörten Riffe verantwortlich ist.
<G-vec00291-001-s385><blame.machen><en> This group is very rare in the world (only 0.01%), and the chromosomal mutation is to blame for its appearance.
<G-vec00291-001-s385><blame.machen><de> Diese Gruppe ist in der Welt sehr selten (nur 0,01%) und die chromosomale Mutation ist für ihr Auftreten verantwortlich.
<G-vec00291-001-s386><blame.machen><en> Safe Havens Rally as China Gives US Ultimatum China published a white paper which makes it very clear that the US is to blame for the negative turn in the trade talks and that concluding that in order for China to return to the negotiation table the hefty tariffs on Chinese imports and the ban on Huawei need to be lifted.
<G-vec00291-001-s386><blame.machen><de> China veröffentlicht Berichte China veröffentlichte einen Bericht, der sehr deutlich macht, dass die USA für die negative Wendung in den Handelsgesprächen verantwortlich sind und zu dem Schluss kommt, dass die hohen Zölle auf chinesische Importe und das Verbot von Huawei aufgehoben werden müssen, damit China an den Verhandlungstisch zurückkehren kann.
<G-vec00291-001-s387><blame.machen><en> Thus, one of the stresses will be on the fragile cover-up, with the increasingly despised Bush Administration and their lackey NASA taking the blame for the cover-up.
<G-vec00291-001-s387><blame.machen><de> Somit wird der Streß auf dem zerbrechlichen Cover-Up liegen, und die zunehmend verachtete Bush-Administration und ihr Lakai, NASA, werden für das Cover-Up verantwortlich gemacht.
<G-vec00291-001-s388><blame.machen><en> """Everybody is to blame for the conflict except Israel,"" Labor Party lawmaker Michiel Servaes commented on Twitter ."
<G-vec00291-001-s388><blame.machen><de> """Alle müssen für den Konflikt verantwortlich gemacht werden, außer Israel"", kommentierte der Parlamentarier der Arbeitspartei Michiel Servaes auf Twitter ."
<G-vec00291-001-s389><blame.machen><en> So the one-two punch to the Gulf Coast from Katrina and Rita has naturally led many people to wonder: Is global warming to blame for back-to-back major hurricanes slamming into the United States?
<G-vec00291-001-s389><blame.machen><de> Der Doppelsieg von Katrina und Rita an die Golfküste hat natürlich viele Leute dazu gebracht, sich zu fragen, ob die globale Erwärmung für die großen Wirbelstürme in den Vereinigten Staaten verantwortlich gemacht wird.
<G-vec00291-001-s390><blame.machen><en> The blame was put on an oversupply of milk and cheap products from the world market, to which processors increasingly resort.
<G-vec00291-001-s390><blame.machen><de> Verantwortlich gemacht wird ein zu großes Milchangebot sowie preiswerte Ware vom Weltmarkt, auf welche die Verarbeiter verstärkt zugreifen.
<G-vec00347-001-s273><blame.machen><en> The blame was put on an oversupply of milk and cheap products from the world market, to which processors increasingly resort.
<G-vec00347-001-s273><blame.machen><de> Verantwortlich gemacht wird ein zu großes Milchangebot sowie preiswerte Ware vom Weltmarkt, auf welche die Verarbeiter verstärkt zugreifen.
<G-vec00291-001-s391><blame.machen><en> You may blame other persons, situations, or institutions for your problem, but this is misplaced responsibility.
<G-vec00291-001-s391><blame.machen><de> Ihr könnt andere Personen, Situationen oder Institutionen für euer Problem verantwortlich machen, aber damit verlagert ihr die Verantwortung an die falsche Stelle.
<G-vec00291-001-s392><blame.machen><en> And finally, the poor living conditions and thus the high mortality rate were also exacerbated by factors which one cannot blame on the camp Administration and the Central Construction Office, such as the lack of transportation facilities resulting from the developments along the eastern front, which caused additional delays in bringing in the materials needed for building the sewer system.
<G-vec00291-001-s392><blame.machen><de> Schließlich trugen auch Umstände zu den schlimmen Lebensbedingungen und damit zu der hohen Sterblichkeit bei, für die man die Lagerführung und die Zentralbauleitung billigerweise nicht verantwortlich machen kann, etwa der durch die Entwicklung an der Ostfront bedingte Mangel an Transportmitteln, welcher das Heranschaffen des Baumaterials für die Kanalisation zusätzlich verzögerte.
<G-vec00291-001-s393><blame.machen><en> Rabinowitch would like to blame Lenin for it all, accusing the Bolsheviks of provoking the Left SRs and “fabricating” a Bolshevik majority at the Fifth Soviet Congress.
<G-vec00291-001-s393><blame.machen><de> Rabinowitch, der Lenin für all das verantwortlich machen möchte, behauptet, die Bolschewiki hätten die Linken SR provoziert und die bolschewistische Mehrheit auf dem Fünften Sowjetkongress „gefälscht“.
<G-vec00291-001-s394><blame.machen><en> And faced by a serious crisis you just revolt against the power which inflicts this on you, for as soon as you are in serious trouble you gladly blame someone else for it, even if you yourselves deny a God and Creator....
<G-vec00291-001-s394><blame.machen><de> Und tritt große Not an euch heran, so bäumet ihr euch auch nur auf gegen die Macht, die solche über euch kommen lässet, denn sowie ihr in arge Not geratet, wollet ihr gern einen dafür verantwortlich machen, selbst wenn ihr einen Gott und Schöpfer leugnet....
<G-vec00291-001-s395><blame.machen><en> They can't blame others so they blame themselves.
<G-vec00291-001-s395><blame.machen><de> Sie können niemanden verantwortlich machen, folglich richten sie es auf sich selbst.
<G-vec00291-001-s396><blame.machen><en> We can’t blame the World Cup for all our sorrows because we all know that when it has gone our sorrows will continue.
<G-vec00291-001-s396><blame.machen><de> Wir können die WM nicht für alle unsere Schmerzen verantwortlich machen, weil wir wissen, dass unsere Schmerzen weitergehen werden, wenn sie vorbei ist.
<G-vec00291-001-s397><blame.machen><en> Show More So we won't blame you if you want to enact a little twenty-first century vengeance by appreciating the firm assets and spread pussies of modern-day British women.
<G-vec00291-001-s397><blame.machen><de> So werden wir Dich nicht verantwortlich machen, wenn Du eine kleine Rache des einundzwanzigsten Jahrhunderts nehemn willst, indem Du die festen Werte schätzst und Muschis der modernen britischen Frauen dehnst.
<G-vec00291-001-s398><blame.machen><en> Even if foreigners are often considered a common foe in troubled economic times, that suggests it is not only ironic for Trump to blame globalisation for his country’s economic woes, but that his policies could have sizeable negative repercussions for the US economy too.
<G-vec00291-001-s398><blame.machen><de> Auch wenn Ausländer in Wirtschaftskrisen oft als gemeinsamer Feind gelten, deutet das darauf hin, dass es für Trump nicht nur ironisch ist, die Globalisierung für die wirtschaftlichen Nöte seines Landes verantwortlich zu machen, sondern dass seine Politik auch erhebliche negative Auswirkungen auf die US-Wirtschaft haben könnte.
<G-vec00291-001-s399><blame.machen><en> "For example, some MD Kalisturh in communicating with their staff on the case of the Red Army to the German population, said: ""We can not hide the fact that I personally beheld poor attitude of some Russian fighter for our ladies, but I have read that the blame for this war, and the most the main thing is that our soldiers and especially the SS behaved in relation to Russian ladies even worse."
<G-vec00291-001-s399><blame.machen><de> "Zum Beispiel, ein Doktor der Medizin Kalisturh im Gespräch mit seinen Kollegen auf die Haltung der Roten Armee, der deutschen Bevölkerung, sagte: "" Wir können die Tatsache, dass ich persönlich einige schlechte Haltung russischen Soldaten für unsere Frauen sehen sich nicht verstecken, aber ich sagte, dass, um den Krieg verantwortlich zu machen, und die meisten das Wichtigste ist, dass unsere Soldaten und vor allem der SS in Richtung russische Frauen verhielt es noch viel schlimmer."
<G-vec00291-001-s400><blame.machen><en> we can blame the Mother of Harlots .
<G-vec00291-001-s400><blame.machen><de> können wir die Mutter aller Huren verantwortlich machen.
<G-vec00291-001-s401><blame.machen><en> But it would also allow him to turn the 2020 campaign into a trench war and blame the Democrats for the end of the economic boom....
<G-vec00291-001-s401><blame.machen><de> Aber es würde ihm auch erlauben, die Kampagne 2020 in einen Grabenkrieg zu verwandeln und die Demokraten für das Ende des Wirtschaftsbooms verantwortlich zu machen....
<G-vec00291-001-s402><blame.machen><en> Even very excellent, but it spoils for the rest… Totally absent music (except in the logon screen), fairly generic sound effects but nothing to be consistent with the quality of graphic presentation… But hey I have to blame the presentation it's lack of introduction, everything is done to have cool air, but it just lacks the cool effect to be cool.
<G-vec00291-001-s402><blame.machen><de> Völlig abwesend Musik (außer dem Anmeldebildschirm), ziemlich generisch Sound-Effekte, aber nichts mit der Qualität der grafischen Präsentation in Einklang stehen... Aber hey, ich habe die Präsentation verantwortlich zu machen es ist ein Mangel an Einführung, alles wird getan, um kühle Luft haben, aber es fehlt einfach die coole Wirkung kühl sein.
<G-vec00291-001-s403><blame.machen><en> Mörner: Yes, and it's much better to blame something else.
<G-vec00291-001-s403><blame.machen><de> Mörner: Ja, und es ist viel besser, etwas anderes verantwortlich zu machen.
<G-vec00291-001-s404><blame.machen><en> Often parents simply refuse to accept this fact and fall into terrible despair and depression, blaming only themselves, but often they are absolutely in no way to blame for all the troubles.
<G-vec00291-001-s404><blame.machen><de> Oft einfach Eltern sich weigern, diese Tatsache zu akzeptieren und fallen in schreckliche Verzweiflung und Depression, nur sich selbst die Schuld, aber oft sind sie absolut in keiner Weise für alle Probleme verantwortlich zu machen.
<G-vec00291-001-s405><blame.machen><en> If you faced any of above stated scenarios, then don’t blame yourself for your silly mistakes.
<G-vec00291-001-s405><blame.machen><de> Wenn Sie eine der oben genannten Szenarien konfrontiert, dann nicht sich für Ihre dumme Fehler verantwortlich zu machen.
<G-vec00291-001-s406><blame.machen><en> Often, immense shame and guilt will set in if they blame themselves for the tragedy.
<G-vec00291-001-s406><blame.machen><de> Enormer Scham und Schuldgefühle sind die Folge, wenn sie sich selbst für die Tragödie verantwortlich machen.
<G-vec00291-001-s407><blame.machen><en> However, Salmonella germs are not always to blame.
<G-vec00291-001-s407><blame.machen><de> Doch nicht immer ist für eine bakterielle Diarrhöe dieser Keim verantwortlich zu machen.
<G-vec00291-001-s408><blame.machen><en> When you can’t blame your genetics, weight gain due to pregnancy and obesity can also be a cause.
<G-vec00291-001-s408><blame.machen><de> Wenn Sie Ihre Genetik nicht verantwortlich machen können, können auch Gewichtszunahme aufgrund von Schwangerschaft und Fettleibigkeit die Ursachen sein.
<G-vec00291-001-s409><blame.machen><en> And that’s the most encouraging message to take away from reading both of these papers: Don't blame the economy when you can do something about it yourself.
<G-vec00291-001-s409><blame.machen><de> Und das ist die ermutigendste Botschaft der beiden Strategiepapiere: Man sollte nicht die wirtschaftliche Lage verantwortlich machen, wenn man selbst etwas ändern kann.
<G-vec00347-001-s274><blame.machen><en> You may blame other persons, situations, or institutions for your problem, but this is misplaced responsibility.
<G-vec00347-001-s274><blame.machen><de> Ihr könnt andere Personen, Situationen oder Institutionen für euer Problem verantwortlich machen, aber damit verlagert ihr die Verantwortung an die falsche Stelle.
<G-vec00347-001-s287><blame.verdenken><en> """The Sacred Dragon does not consider me alive...I cannot blame him."
<G-vec00347-001-s287><blame.verdenken><de> """Der Heilige Drache sieht mich nicht als Lebewesen an... Das kann ich ihm nicht verdenken."
<G-vec00347-001-s288><blame.verdenken><en> As he mentions in his interview, he might have just had a slight feeling of victory similar to that of an Olympian and I don't blame him: HB-SIA, a prototype initially designed to fly day and night has entered the annals of history as the first solar airplane to connect two continents: Europe to Africa .
<G-vec00347-001-s288><blame.verdenken><de> Wie er in seinem Interview erwähnte, hatte er nur ein leichtes Gefühl des Sieges, ähnlich wie ein Olympiagewinner und ich glaube ich kann es ihm nicht verdenken: HB-SIA, der Prototyp, der gebaut wurde, um am Tag und in der Nacht zu fliegen, wird nun in die Geschichte als das erste Solarflugzeug, dass zwei Kontinenten, Europa und Afrika, verbunden hat, eingehen.
<G-vec00347-001-s289><blame.verdenken><en> «…I cannot blame your bitterness of heart, you suffered too much.
<G-vec00347-001-s289><blame.verdenken><de> „…Ich kann euch die Verbitterung nicht verdenken, ihr habt zu viel gelitten.
<G-vec00347-001-s290><blame.verdenken><en> Honestly, I cannot blame them for it – I would have done the same.
<G-vec00347-001-s290><blame.verdenken><de> Ich muss hier ehrlich sein und sagen, dass dies der Jugend nicht zu verdenken ist, ich hätte es genauso getan.
<G-vec00347-001-s291><blame.verdenken><en> I cannot blame them for such belief.
<G-vec00347-001-s291><blame.verdenken><de> Ich kann ihnen für einen solchen Glauben nicht verdenken.
<G-vec00347-001-s304><blame.verübeln><en> The man (n) likes to nod him is probably not to blame.
<G-vec00347-001-s304><blame.verübeln><de> Das Man(n) gerne daran nuckelt ist ihm wohl nicht zu verübeln.
<G-vec00347-001-s305><blame.verübeln><en> Our Lord will surely not blame me if I see in this coincidence a particular sign of His providence in view of my present vocation as a priest-victim of the Sacred Heart.
<G-vec00347-001-s305><blame.verübeln><de> Unser Herr wird es mir nicht verübeln, darin eine Aufmerksamkeit der Vorsehung mit Blick auf meine jetzige Berufung als Priester-Hostie des Herzens Jesu zu sehen.
<G-vec00347-001-s306><blame.verübeln><en> Since the terrain is extremely steep and very difficult to access, you can’t blame anyone.
<G-vec00347-001-s306><blame.verübeln><de> Da es extrem steil und sehr schwer zugänglich ist, kann man das auch keinem verübeln.
<G-vec00347-001-s307><blame.verübeln><en> "Walter Köhler adds sensibly: ""One will the less blame Duhr for a slight apologetic as often completely false judgements on the Jesuits are circulating yet"" (Theol."
<G-vec00347-001-s307><blame.verübeln><de> "Walter Köhler fügt verständig hinzu: ""Eine leise Apologetik wird man Duhr um so weniger verübeln, als noch vielfach ganz verkehrte Urteile über die Jesuiten umlaufen"" (Theol."
<G-vec00347-001-s308><blame.verübeln><en> Hey, you can't blame the obese dude, since this was probably his first encounter with the other sex and his mommy probably never told him the story about the birds and the bees.
<G-vec00347-001-s308><blame.verübeln><de> Hey, man kann es dem fettleibigen Kerl nicht verübeln, da dies wahrscheinlich seine erste Begegnung mit dem anderen Geschlecht war und seine Mami ihm wahrscheinlich nie die Geschichte über die Vögel und die Bienen erzählt hat.
<G-vec00347-001-s309><blame.verübeln><en> "And our elected MEPs can say: ""We are not to blame."
<G-vec00347-001-s309><blame.verübeln><de> "Und unsere gewählten MdEP können sagen:"" Uns kann man nicht verübeln."
<G-vec00347-001-s310><blame.verübeln><en> If you hear pottery I would not blame you for not having something particularly cool in mind.
<G-vec00347-001-s310><blame.verübeln><de> Wenn du Töpferei hörst, würde ich es dir nicht verübeln, dass du nicht etwas besonders Cooles im Sinn hast.
<G-vec00291-001-s438><blame.vorwerfen><en> [Psycho] Incompetence would surely be the last someone would:: DORNENREICH:: blame for.
<G-vec00291-001-s438><blame.vorwerfen><de> [Psycho] Mangelnde Kompetenz wäre sicherlich das letzte, was man:: DORNENREICH:: vorwerfen könnte.
<G-vec00291-001-s439><blame.vorwerfen><en> Unable to blame non-Bolshevik organisations entirely for Lenin’s dictatorship, Trotsky tells “those theoreticians who attempt to prove that the present totalitarian regime of the U.S.S.R. is due... to the ugly nature of Bolshevism itself,” that they forget the years of Civil War, “which laid an indelible impress on the Soviet Government by virtue of the fact that very many of the administrators, a considerable layer of them, had become accustomed to command and demanded unconditional submission to their orders.”
<G-vec00291-001-s439><blame.vorwerfen><de> Da er den nicht-bolschewistischen Organisationen Lenins Diktatur nicht vorwerfen kann, erzählt Trotzki, „daß diejenigen Theoretiker, die zu beweisen versuchen, daß das gegenwärtige totalitäre System der UdSSR gebunden ist an die scheußliche Natur des Bolschewismus selbst“, die Jahre des Bürgerkriegs vergessen, „welche einen unauslöschlichen Eindruck bei der Sowjet-Regierung hinterließen aufgrund der Tatsache, daß sehr viele Administratoren, eine beachtliche Schicht von ihnen, sich daran gewöhnt hatte, zu kommandieren und bedingungslose Unterwerfung unter ihre Befehle verlangte“.
<G-vec00291-001-s440><blame.vorwerfen><en> """The British (or rather the English) leading class is to blame for the illusions of more power and wealth outside the EU having fallen on fertile ground."
<G-vec00291-001-s440><blame.vorwerfen><de> """Dass die Illusionen von mehr Macht und Reichtum außerhalb der EU auf fruchtbaren Boden fielen, muss man der gesamten britischen (besser gesagt englischen) führenden Klasse vorwerfen."
<G-vec00291-001-s441><blame.vorwerfen><en> Faced with the reproaches that come from other European capitals, Salvini has a good game to blame the EU for having left Italy alone and for not honoring the agreements on relocations.
<G-vec00291-001-s441><blame.vorwerfen><de> Angesichts der Vorwürfe, die von anderen europäischen Hauptstädten ausgehen, kann Salvini der EU vorwerfen, dass er Italien allein gelassen hat und die Vereinbarungen über Umsiedlungen nicht einhält.
<G-vec00291-001-s442><blame.vorwerfen><en> Now he tries to keep his promise, despite the discontent of some politicians, who blame him of again exceeding his authority.
<G-vec00291-001-s442><blame.vorwerfen><de> Nun versucht er sein Versprechen einzuhalten, zum Unmut mancher Politiker, die ihm vorwerfen, wieder einmal seine Kompetenzen zu überschreiten.
<G-vec00291-001-s443><blame.vorwerfen><en> Diligence commits us always to do our best, because as soon as we have given our best, we cannot blame us for anything.
<G-vec00291-001-s443><blame.vorwerfen><de> Fleiß verpflichtet uns immer das Beste zu geben, denn wenn wir unser Bestes gegeben haben, können wir uns nichts vorwerfen.
<G-vec00291-001-s444><blame.vorwerfen><en> Review: At least no one can blame me for not having tried.
<G-vec00291-001-s444><blame.vorwerfen><de> Kritik: Ich werde mir jedenfalls nicht vorwerfen können, dass ich es nicht versucht hätte.
<G-vec00291-001-s445><blame.vorwerfen><en> Diligence commits us always “to do our best”, because as soon as we have given our best, we cannot blame us for anything.
<G-vec00291-001-s445><blame.vorwerfen><de> Fleiß verpflichtet uns immer „das Beste zu geben“, denn wenn wir unser Bestes gegeben haben, können wir uns nichts vorwerfen.
<G-vec00291-001-s446><blame.vorwerfen><en> The Chilean film El mocito (The Young Butler) by Marcela Said and Jean de Certeau takes a similar approach. The film is about a man who worked with the torturers of the Pinochet regime, which you can't really blame him for.
<G-vec00291-001-s446><blame.vorwerfen><de> Ähnlich wie der chilenische Film El mocito (The Young Butler) von Marcela Said und Jean de Certeau, in dem es um einen Mann geht, der mit den Folterern des Pinochet-Regimes zusammengearbeitet hat, was man ihm nicht wirklich vorwerfen kann.
<G-vec00347-001-s324><blame.machen><en> While poverty makes people vulnerable to human trafficking, gender discrimination and sexism are also to blame.
<G-vec00347-001-s324><blame.machen><de> Während Armut Menschen gegenüber Menschenhandel angreifbar macht, sind auch Geschlechterdiskriminierung und Sexismus ein Vorwurf zu machen.
<G-vec00347-001-s325><blame.machen><en> Therefore, when I can find an attorney who has experience in such trials and who will disregard the hostility from society to defend me or others like me, no one should blame him for this.
<G-vec00347-001-s325><blame.machen><de> Wenn ich mir also einen Rechtsanwalt nehme, der in solchen Prozessen Erfahrung hat und der den Anfeindungen der Gesellschaft zum Trotz mich und ähnliche Fälle verteidigt, dann darf ihm dies niemand zum Vorwurf machen.
<G-vec00347-001-s326><blame.machen><en> However, most likely you also have to blame the original script of Larry Cohen for that.
<G-vec00347-001-s326><blame.machen><de> Aber hier muss man wohl auch dem Originaldrehbuch von Larry Cohen einen Vorwurf machen.
<G-vec00347-001-s327><blame.machen><en> Rather, it means that we do not blame the other person or ourselves for making the relationship end.
<G-vec00347-001-s327><blame.machen><de> Stattdessen bedeutet es, dass wir dem anderen oder uns selbst keinen Vorwurf daraus machen, dass die Beziehung endet.
<G-vec00347-001-s328><blame.machen><en> If there is one thing to blame the movie for then it is that it doesn't feel as a whole and that the script would have needed some serious finishing touches.
<G-vec00347-001-s328><blame.machen><de> Wenn man dem Film also einen Vorwurf machen muss, dann den, dass er sich nicht wie ein gelungenes Ganzes anfühlt und dass das Drehbuch unbedingt noch den nötigen letzten Schliff benötigt hätte.
<G-vec00347-001-s329><blame.machen><en> This is why it is absurd to blame the 'Marxists (as Harms does) for allegedly seeing Socialist economy behind the capitalist economy, while not seeing world economy.
<G-vec00347-001-s329><blame.machen><de> Es ist deshalb ganz unsinnig, den Marxisten (wie das Harms tut) den Vorwurf zu machen, sie sähen nach der kapitalistischen Wirtschaft nur die sozialistische, nicht aber die Weltwirtschaft.
<G-vec00347-001-s330><blame.machen><en> While we might consider the husband as the villain at the beginning of the movie - after all, it becomes clear quite soon that he killed his wife -, we cannot really blame him for the murder when we see in some flashbacks how his wife treated him like a trophy and that she was part of a really powerful family, who would never have agreed to a divorce.
<G-vec00347-001-s330><blame.machen><de> Halten wir den Ehemann anfangs für den Bösewicht, schließlich ist sehr schnell klar, dass er seine Frau ermordet hat, können wir ihm nach diversen eingestreuten Rückblenden nur noch bedingt einen Vorwurf für den Mord machen, da seine Ehefrau ihn wie eine Trophäe behandelt hat und Teil einer äußerst mächtigen Familie war, die einer Scheidung niemals zugestimmt hätte.
<G-vec00347-001-s331><blame.machen><en> Their contradictions, internal tensions, and historical improbabilities were noticed not only by the Dutchmen but also by other researchers before them. Therefore, one can hardly blame the Dutch radicals on the ground that they were simply not satisfied with the results of the investigations of ZAHN, LIGHTFOOT, and HARNACK but kept asking their critical questions.
<G-vec00347-001-s331><blame.machen><de> Man kann es darum den holländischen Radikalen kaum zum Vorwurf machen, daß sie sich mit den Ergebnissen der Untersuchungen ZAHNs, LIGHTFOOT s und HARNACK s nicht zufriedengeben mochten und weiterhin ihre kritischen Fragen stellten.
<G-vec00347-001-s341><blame.machen><en> "It's impossible to put any blame on Moon for his actions, in fact we even can sympathize with him, yet he also isn't any sort of ""hero"" in the sense of a heroic-bloodshed movie."
<G-vec00347-001-s341><blame.machen><de> "Es ist also unmöglich Moon Vorwürfe für seine Taten zu machen, eigentlich können wir sogar immer mit ihm fühlen, doch ein ""Held"" ist er auch im Sinne eines Heroic-Bloodshed Movies nicht."
<G-vec00347-001-s342><blame.machen><en> Blame indicates shame, and it lingers.
<G-vec00347-001-s342><blame.machen><de> Vorwürfe machen zeigt Scham an, und jene lungert.
<G-vec00347-001-s343><blame.machen><en> "And let not Messieurs the bourgeoisie blame us if some of the governments near and dear to them, which today rule happily ""by the grace of God,"" are missing on the morrow after such a war."
<G-vec00347-001-s343><blame.machen><de> "Und mögen die Herren Bourgeois nicht uns Vorwürfe machen, wenn sie am Tage nach einem solchen Kriege einige ihnen nahe stehende Regierungen vermissen werden, die jetzt ""von Gottes Gnaden"" wohlbehalten regieren."
<G-vec00347-001-s344><blame.machen><en> I would not blame the Bitkom.
<G-vec00347-001-s344><blame.machen><de> Ich möchte dem Bitkom keine Vorwürfe machen.
<G-vec00347-001-s345><blame.machen><en> For those who blame themselves.
<G-vec00347-001-s345><blame.machen><de> Für jene, die sich selbst Vorwürfe machen.
<G-vec00347-001-s346><blame.machen><en> When I looked around the hall I saw people praying for one another by laying hands, then I felt miserable and I started to cry and to blame myself for not praying over my mother.
<G-vec00347-001-s346><blame.machen><de> Als ich mich umsah in der Halle sah ich dass die Menschen einander die Hände auflegten und beteten, da fühlte ich mich elend und ich fing an zu weinen und mir selber Vorwürfe zu machen weil ich nicht für meine Mutter betete.
<G-vec00347-001-s347><blame.machen><en> But instead of turning off immediately the main switch, she and her guard start to blame us and get abusive.
<G-vec00347-001-s347><blame.machen><de> Anstatt dass die herbeigerufene Lady und ihr Beschützer sofort den Haupthahn zudrehen, beginnen sie uns Vorwürfe zu machen und werden ausfällig.
<G-vec00347-001-s348><blame.machen><en> It belongs to this special component that, under such circumstances, one can therefore not blame Nietzsche, precisely under these circumstances, it could by no means be his duty, to conduct a specific reflection on the duality.
<G-vec00347-001-s348><blame.machen><de> Zu dieser Sonderkomponente gehört es, dass man unter solchen Umstaenden Nietzsche deshalb auch keine Vorwürfe machen kann, gerade unter diesen Umstaenden konnte es keineswegs seine Aufgabe gewesen sein, auch noch eine besondere Reflexion über die Zweiheit anzustellen.
<G-vec00347-001-s349><blame.machen><en> You can blame the song the world sings on the chorus of voices that, randomly and unknowingly, sing along with yours, yet still, your voice can be heard above the throng.
<G-vec00347-001-s349><blame.machen><de> Du kannst dem Lied, was die Welt in dem Chor der Stimmen singt, die, zufällig und ohne ein Wissen, mit deiner Stimme einhergehen, Vorwürfe machen, indes kann deine Stimme nach wie vor über dem Gewühl vernommen werden.
<G-vec00291-001-s483><blame.vorwerfen><en> The reference to Arafat is pertinent, but the protesters continue to blame him for having accepted the two phases (Palestinian Authority and State).
<G-vec00291-001-s483><blame.vorwerfen><de> Immer wieder beruft man sich auf Arafat, aber die Gegner werden nicht müde, ihm vorzuwerfen, die beiden Phasen (Palästinensische Autonomiebehörde und Staat) akzeptiert zu haben.
<G-vec00291-001-s484><blame.vorwerfen><en> But gradually the two of them realize that they have little to blame each other for.
<G-vec00291-001-s484><blame.vorwerfen><de> Doch allmählich gelangen die beiden zu der Erkenntnis, dass sie einander wenig vorzuwerfen haben.
<G-vec00291-001-s485><blame.vorwerfen><en> It would, however, be wrong to blame the commercial banks not to provide services to these neglected customer segments.
<G-vec00291-001-s485><blame.vorwerfen><de> Es wäre falsch, den kommerziellen Banken vorzuwerfen, die vernachlässigten Kundensegmente nicht zu bedienen.
<G-vec00291-001-s486><blame.vorwerfen><en> If we recognize we are to blame, we may feel guilt and a need for forgiveness.
<G-vec00291-001-s486><blame.vorwerfen><de> Wenn wir feststellen, dass wir uns etwas vorzuwerfen haben, dann fühlen wir uns schuldig und wünschen uns Vergebung.
<G-vec00291-001-s487><blame.vorwerfen><en> Anyway, it seems absurd to blame a professional composer for trying to maintain his family in the only way he could, by writing music for money.
<G-vec00291-001-s487><blame.vorwerfen><de> Jedoch ist es absurd, einem professionellen Komponisten vorzuwerfen, dass er seine Werke komponierte, um Geld zu verdienen, wenn das für ihn die einzige Möglichkeit war, seine Familie zu versorgen.
<G-vec00347-001-s355><blame.zuschreiben><en> Whoever then, like you all, wants it, will be saved as you are; but whoever does not want it will only have himself to blame if he perishes.
<G-vec00347-001-s355><blame.zuschreiben><de> Wer dann, euch gleich, will, der wird so wie ihr gerettet sein; wer aber dann nicht wollen wird, der wird es sich selbst zuschreiben müssen, so er verlorengeht.
<G-vec00347-001-s356><blame.zuschreiben><en> But then they also must only blame themselves, when everything becomes deserted and withers, when no right life can thrive in the wide surrounding area, when men just only live naturally, however spiritually are completely without life, because they lack power, which they can draw out of the spring of life, out of the eternal source of divine life.
<G-vec00347-001-s356><blame.zuschreiben><de> Dann aber müssen sie es sich auch selbst zuschreiben, wenn alles verödet und verdorrt, wenn in weitem Umkreis kein rechtes Leben gedeihen kann, wenn die Menschen nur noch naturmäßig leben, geistig jedoch völlig ohne Leben sind, denn es mangelt ihnen an der Kraft, die sie aus dem Born des Lebens, aus dem ewigen Quell göttlicher Liebe schöpfen können.
<G-vec00347-001-s357><blame.zuschreiben><en> In our Christian religion, we believe that our actions if they are good they are influenced from above, that is from God, because He dwells in us and His Spirit guides us, but if our actions are bad, we cannot blame God, we must blame it on our personal evil intentions and our passionate desires.
<G-vec00347-001-s357><blame.zuschreiben><de> In unserer christlichen Religion glauben wir, dass unsere Taten, wenn sie gut sind, von oben, das heißt von Gott, gelenkt sind, weil Er in uns wohnt und Sein Geist uns führt; doch wenn unsere Taten schlecht sind, können wir Gott nicht die Schuld daran geben, wir müssen dies dann unseren eigenen bösen Absichten zuschreiben und unseren leidenschaftlichen Wünschen.
<G-vec00347-002-s019><blame.annotieren><en> When the mouse is over the blame info columns, a context menu is available which helps with comparing revisions and examining history, using the revision number of the line under the mouse as a reference.
<G-vec00347-002-s019><blame.annotieren><de> Wenn die Maus sich über den Informationsspalten im Annotieren Fenster befindet, steht ein Kontextmenü zur Verfügung, mit dessen Hilfe Sie Revisionen vergleichen und die Historie, unter Verwendung der Revisionsnummer über der sich die Maus befindet, betrachten können.
<G-vec00347-002-s020><blame.annotieren><en> When lines are merged from another source, the blame information shows the revision the change was made in the original source as well as the revision when it was merged into this file.
<G-vec00347-002-s020><blame.annotieren><de> Wenn Zeilen aus einer anderen Quelle integriert wurden, wird beim Annotieren die Revision angezeigt in der die Änderungen im Original vorgenommen wurden sowie die Revision in der sie in dieser Datei zusammengeführt wurden.
<G-vec00347-002-s021><blame.annotieren><en> The revision shown in the blame information represents the last revision where the content of that line changed.
<G-vec00347-002-s021><blame.annotieren><de> Die Revisionsnummer beim Annotieren repräsentiert die letzte Revision in der der Inhalt der Zeile geändert wurde.
<G-vec00347-002-s047><blame.beschuldigen><en> You blame God, yourself, or others.
<G-vec00347-002-s047><blame.beschuldigen><de> Sie beschuldigen Gott oder sich selbst oder die anderen.
<G-vec00347-002-s048><blame.beschuldigen><en> That is, we always blame people for problems, but not circumstances.
<G-vec00347-002-s048><blame.beschuldigen><de> Das heißt, wir beschuldigen die Menschen immer für Probleme, aber nicht für Umstände.
<G-vec00347-002-s119><blame.geben><en> Many researchers blame GM glyphosate-tolerant crops for the catastrophic decline of the monarch butterfly, since glyphosate weedkillers applied to the crops eradicate milkweed, the monarch larvae's only food.
<G-vec00347-002-s119><blame.geben><de> Viele Forscher geben gv Glyphosat-toleranten Pflanzen Schuld an dem katastrophalen Rückgang des Monarchfalters, da Glyphosat-Unkrautvernichter, die auf die Pflanzen aufgetragen werden, Seidenpflanzen vernichten, das einzige Nahrungsmittel der Monarchlarven.
<G-vec00347-002-s120><blame.geben><en> When socialism fails to deliver a consumer society because socialism is not based on imperialist exploitation, the revisionists blame socialism itself.
<G-vec00347-002-s120><blame.geben><de> Wenn der Sozialismus es dann nicht schafft, eine Konsumgesellschaft zu errichten, weil der Sozialismus nicht auf der imperialistischen Ausbeutung basiert, geben die Revisionisten dem Sozialismus die Schuld.
<G-vec00347-002-s134><blame.machen><en> You blame it for many things.
<G-vec00347-002-s134><blame.machen><de> Du machst ihm wegen vieler Dinge Vorwürfe.
<G-vec00347-002-s135><blame.machen><en> When you take responsibility, you do not blame anyone.
<G-vec00347-002-s135><blame.machen><de> Wenn du Verantwortung übernimmst, machst du niemandem Vorwürfe.
<G-vec00347-002-s144><blame.schieben><en> For me it would be too easy to blame evil actions on a wicked person, the devil.
<G-vec00347-002-s144><blame.schieben><de> Für mich wäre es zu einfach, böses Handeln auf eine niederträchtige Person, den Teufel, zu schieben.
<G-vec00347-002-s145><blame.schieben><en> This time I can't blame it on pilot error. This time no regrets."
<G-vec00347-002-s145><blame.schieben><de> Dieses Mal, dieses Mal kann ich es nicht auf einen Pilotenfehler schieben, dieses Mal keine Reue.
<G-vec00347-002-s146><blame.schieben><en> As we rented a scooter, we paid attention – German as we are – to already existing damages – after 10 scrapes and scratches we stopped counting. We thought, we could lay the blame for the next few scrapes on the previous owner.
<G-vec00347-002-s146><blame.schieben><de> Wenn man einen Roller mietet, achtet man – deutsch wie man ist – natürlich zu erst auf eventuelle Schäden – nach 10 Kratzern und Schrammen hörten wir allerdings auf zu zählen und gedachten weitere Blessuren getrost auf den Vormieter schieben zu können.
<G-vec00347-002-s147><blame.schieben><en> Others instead blame it on the failure of the tough diplomacy of the nationalist-driven government under Benyamin Netanyahu and his foreign minister, Avigdor Lieberman.
<G-vec00347-002-s147><blame.schieben><de> Andere schieben dem Scheitern der harten Diplomatie der nationalistischen Regierung unter Benjamin Netanjahu und seinem Außenminister, Avigdor Lieberman, die Schuld zu.
<G-vec00347-002-s148><blame.schieben><en> Therefore criticism and the masses stand on the same basis: both fight against egoism, both reject it for themselves and shift the blame for it to the other.
<G-vec00347-002-s148><blame.schieben><de> Mithin stehen Kritik und Masse auf derselben Basis: beide kämpfen gegen den Egoismus, beide weisen ihn von sich ab, und schieben ihn einander zu.
<G-vec00347-002-s204><blame.schuldigen><en> “The uproar over the use of the instruments created by Cambridge Analytica is just a further attempt to find someone to blame for the political defeats of the liberals in America and Europe in the last two years.
<G-vec00347-002-s204><blame.schuldigen><de> „Die Empörung über die Benutzung der von Cambridge Analytica geschaffenen Instrumente ist nur ein weiterer Versuch, einen Schuldigen für die politischen Niederlagen der Liberalen in Amerika und Europa in den letzten zwei Jahren zu finden.
<G-vec00347-002-s205><blame.schuldigen><en> Since God is holy, we were the ones to blame.
<G-vec00347-002-s205><blame.schuldigen><de> Da Gott heilig ist, waren wir die Schuldigen.
<G-vec00347-002-s206><blame.schuldigen><en> Share it Facebook Twitter After a crucial member of his political group resigned today, leaving his group in tatters, Mr Farage has started to look for someone to blame, making petty attacks on President Schulz.
<G-vec00347-002-s206><blame.schuldigen><de> Teilen Facebook Twitter Nachdem ein entscheidendes Mitglied seiner politischen Fraktion heute zurückgetreten ist und die Fraktion in Scherben liegt, begann Herr Farage, mit gehässigen Angriffen gegen den Parlamentspräsidenten Martin Schulz einen Schuldigen zu suchen.
<G-vec00347-002-s193><blame.tragen><en> Then you're the one who's going to take the blame.
<G-vec00347-002-s193><blame.tragen><de> Dann bist du derjenige, der die Schuld trägt.
<G-vec00347-002-s306><blame.verschulden><en> Therefore the entire events are according to the divine plan from eternity, although something will never find Godís approval what human will is to blame for, because it is obviously the work of his opponent.
<G-vec00347-002-s306><blame.verschulden><de> Es ist das gesamte Geschehen daher dem göttlichen Plan von Ewigkeit entsprechend, wenngleich niemals etwas Gottes Zustimmung finden wird, was menschlicher Wille verschuldet, weil es offensichtlich das Werk Seines Gegners ist.
<G-vec00347-002-s307><blame.verschulden><en> The usual arrangement is that if one party is to blame for the cancellation, he/she must pay.
<G-vec00347-002-s307><blame.verschulden><de> Ein Standard ist: Verschuldet eine Vertragspartei den Ausfall, muss sie zahlen.
<G-vec00347-002-s308><blame.vertreten><en> Periods of time allowed for goods to be supplied and services to be rendered shall be extended by that length of time in which the Customer is in default with payment under the contract and by that length of time in which ADN is prevented from supplying goods or rendering services as a result of circumstances for which it is not to blame, plus a reasonable amount of start-up time when the hindrance no longer applies.
<G-vec00347-002-s308><blame.vertreten><de> Liefer- und Leistungsfristen verlängern sich um den Zeitraum, in welchem sich der Kunde in Zahlungsverzug aus dem Vertrag befindet, und um den Zeitraum, in dem die ADN durch Umstände, die sie nicht zu vertreten hat, an der Lieferung oder Leistung gehindert ist, und um eine angemessene Anlaufzeit nach Ende des Hinderungsgrundes.
<G-vec00347-002-s309><blame.vertreten><en> Withdrawal The bus company may withdraw from the contract if exceptional circumstances for which it is not to blame make it impossible to render its performance.
<G-vec00347-002-s309><blame.vertreten><de> Das Busunternehmen kann vor Fahrtantritt vom Vertrag zurücktreten, wenn außergewöhnliche Umstände, die es nicht zu vertreten hat, die Leistungserbringung unmöglich machen.
<G-vec00347-002-s117><blame.verübeln><en> Often the ones who helped me along the way are suspicious of the internet, and I can't blame them.
<G-vec00347-002-s117><blame.verübeln><de> Häufig sind die Menschen die mir unterwegs geholfen haben misstrauisch gegenüber dem Internet und ich kann es ihnen nicht verübeln.
<G-vec00347-002-s118><blame.verübeln><en> means more than a moving. You are busy enough and you cannot blame anyone else, if your moving plans become overwhelming.
<G-vec00347-002-s118><blame.verübeln><de> Damit sind Sie beschäftigt genug, und es kann Ihnen niemand verübeln, wenn Ihnen die Planung des Umzugs über den Kopf wächst.
<G-vec00347-002-s195><blame.zuschieben><en> When they are tempted and fall into sin, it is typical for them to put the blame somewhere else.
<G-vec00347-002-s195><blame.zuschieben><de> Wenn sie versucht werden und der Sünde nachgeben, ist es typisch für sie, irgendjemand anderem die Schuld zuzuschieben.
