<G-vec00373-002-s494><double.verdoppeln><en> How do you double your capital?" were common in their meetings.
<G-vec00373-002-s494><double.verdoppeln><de> Wie man sein Kapital verdoppelt" waren in ihren Meetings üblich.
<G-vec00373-002-s495><double.verdoppeln><en> In summer, with the influx of tourists, double the population.
<G-vec00373-002-s495><double.verdoppeln><de> Im Sommer mit dem Zustrom von Touristen, verdoppelt sich die Bevölkerung.
<G-vec00373-002-s496><double.verdoppeln><en> If you guess right, you double your money; guess wrong and you lose the lot.
<G-vec00373-002-s496><double.verdoppeln><de> Sollten Sie richtig liegen, verdoppelt sich das Geld, eine falsche Antwort lässt Sie alles verlieren.
<G-vec00373-002-s497><double.verdoppeln><en> 2E mechatronic GmbH & Co. KG ATS Automation Tooling Systems distribution facility in Hörsching is carried out by a flat belt sorter system with which it was possible to nearly double the existing storage capacities.
<G-vec00373-002-s497><double.verdoppeln><de> 2E mechatronic GmbH & Co. KG ATS Sortierung im modernsten Paketumschlagplatz des DPD Austria in Hörsching erfolgt über eine Flachbandsorteranlage, mit der die bisherigen Kapzitäten des Depots nahezu verdoppelt wurden.
<G-vec00373-002-s498><double.verdoppeln><en> Parkinson's Disease is the second most common chronic progressive neurodegenerative disorder in the elderly after Alzheimer's disease and the number of patients is expected to double by 2030.
<G-vec00373-002-s498><double.verdoppeln><de> Parkinson ist die zweithäufigste chronisch-progressive, neurodegenerative Erkrankung älterer Menschen nach der Alzheimer-Krankheit; und es wird erwartet, dass sich die Anzahl der Patienten bis 2030 verdoppelt.
<G-vec00373-002-s499><double.verdoppeln><en> This will double all points.
<G-vec00373-002-s499><double.verdoppeln><de> Dadurch werden alle Punkte verdoppelt.
<G-vec00373-002-s500><double.verdoppeln><en> Moore’s law, an observation in a 1965 paper by Intel™ co-founder Gordon Moore, suggests that the performance of semiconductors, the basic components of technology, will double every year while their cost halves.
<G-vec00373-002-s500><double.verdoppeln><de> Das Mooresche Gesetz, das der Mitbegründer von Intel™, Gordon Moore, 1965 formulierte, besagt, dass sich die Leistung von Halbleitern, der technologischen Grundbausteine, jedes Jahr verdoppelt, während sich ihre Kosten halbieren.
<G-vec00373-002-s501><double.verdoppeln><en> The building of a new terminal will double handling capacity to over 2,000 passengers per hour.
<G-vec00373-002-s501><double.verdoppeln><de> Durch den Bau eines neuen Terminals verdoppelt sich die Abfertigungskapazität auf über 2.000 Passagiere pro Stunde.
<G-vec00373-002-s502><double.verdoppeln><en> And since I could not really decide which "look" I like the best, I decided to double the recipe and prepare both kinds.
<G-vec00373-002-s502><double.verdoppeln><de> Da ich mich nicht entscheiden konnte welche mir besser gefallen, habe ich einfach mal das Rezept verdoppelt und beide Sorten gemacht.
<G-vec00373-002-s503><double.verdoppeln><en> With the donation from the Nano Foundation, the sum will double to a value of over $600,000.
<G-vec00373-002-s503><double.verdoppeln><de> Mit der Spende von der Nano Foundation verdoppelt sich die Summe auf umgerechnet knapp 500.000 Euro.
<G-vec00373-002-s504><double.verdoppeln><en> Availability: Keeps Allied players gain double effectiveness of the keep’s objective aura while within the perimeter of the keep.
<G-vec00373-002-s504><double.verdoppeln><de> Innerhalb der Eingrenzung der Feste verdoppelt sich für verbündete Spieler die Effektivität der Zielaura der Feste.
<G-vec00373-002-s505><double.verdoppeln><en> This perk will double the amount of ammunition found in random encounters.
<G-vec00373-002-s505><double.verdoppeln><de> Das Extra verdoppelt die Munition, die man in zufälligen Begegnungen findet.
<G-vec00373-002-s506><double.verdoppeln><en> The dough should double in size during this time.
<G-vec00373-002-s506><double.verdoppeln><de> Das Volumen des Teiges sollte sich in dieser Zeit verdoppelt haben.
<G-vec00373-002-s507><double.verdoppeln><en> The new system has around a third more cores and nodes than FAU’s currently most powerful HPC system, while the maximum theoretical computing power is more than double.
<G-vec00373-002-s507><double.verdoppeln><de> Gegenüber dem aktuell leistungsfähigsten HPC-System der FAU erhöht sich die Kern- und Knotenanzahl um etwa ein Drittel, während sich die theoretische Spitzenrechenleistung mehr als verdoppelt.
<G-vec00373-002-s508><double.verdoppeln><en> In the end we get a feeling that fortune will more than double when shared.”
<G-vec00373-002-s508><double.verdoppeln><de> Am Ende bekommt man das Gefühl, dass sich Glück mehr als verdoppelt, wenn man es teilt.
<G-vec00373-002-s509><double.verdoppeln><en> This number is expected to double by the end of 2018.
<G-vec00373-002-s509><double.verdoppeln><de> Seit Ende 2016 hat sich dieser Anteil von ursprünglich 34 Prozent mehr als verdoppelt.
<G-vec00373-002-s510><double.verdoppeln><en> The new order will more than double the number of Airbus aircraft in their fleet.
<G-vec00373-002-s510><double.verdoppeln><de> Die Zahl der Airbus-Flugzeuge in der Gulf Air Flotte wird mit dem neuen Auftrag mehr als verdoppelt.
<G-vec00373-002-s511><double.verdoppeln><en> While your Life Points are lower than your opponent's, double the original ATK of a monster equipped with this card.
<G-vec00373-002-s511><double.verdoppeln><de> Solange deine Life Points niedriger sind die deines Gegners, werden die ATK des ausgerüsteten Monsters verdoppelt.
<G-vec00373-002-s512><double.verdoppeln><en> You gain an additional skill point for reading a book (for a total of 4 instead of 3), and double the temporary skill points from magazines (for a total of 20 instead of 10).
<G-vec00373-002-s512><double.verdoppeln><de> Durch das Lesen eines Fallout: New Vegas Fertigkeitsbuches erhält man einen zusätzlichen Fertigkeitspunkt (4, anstatt 3) und verdoppelt temporär den Wert der Fertigkeitspunkte aus den Fertigkeitsmagazinen (20, anstatt 10).
