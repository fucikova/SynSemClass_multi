<G-vec00383-002-s019><die.absterben><en> Fungi are not immediately visible but may cause the grass to die.
<G-vec00383-002-s019><die.absterben><de> Letztere sind nicht sofort sichtbar, können den Rasen aber absterben lassen.
<G-vec00383-002-s020><die.absterben><en> Typical for this species are the thick and long roots, that do not die off over winter.
<G-vec00383-002-s020><die.absterben><de> Typisch für die Art sind die langen, dicken Wurzeln, die auch über Winter nicht absterben.
<G-vec00383-002-s021><die.absterben><en> When trastuzumab binds to HER2 it can stop the cancer cells growth and cause them to die.
<G-vec00383-002-s021><die.absterben><de> Wenn Trastuzumab an HER2 bindet, kann es das Krebszellwachstum blockieren und zum Absterben der Krebszellen führen.
<G-vec00383-002-s022><die.absterben><en> When they die, they sink to the bottom of the sea, decomposing into flaky lumps as they descend.
<G-vec00383-002-s022><die.absterben><de> Wenn sie absterben, sinken sie zum Meeresboden, werden dabei im Laufe des Abstiegs zersetzt zu flockigen Klumpen.
<G-vec00383-002-s023><die.absterben><en> On the contrary, they severely damage nerve cells and cause them to die.
<G-vec00383-002-s023><die.absterben><de> Im Gegenteil: Sie schädigen Nervenzellen massiv und führen zu deren Absterben.
<G-vec00383-002-s024><die.absterben><en> This usually happens when an external factor changes the environment of the vagina, causing other microorganisms to die off, leaving space for candida to colonise.
<G-vec00383-002-s024><die.absterben><de> Dies geschieht normalerweise, wenn ein äußerer Faktor die Umgebung der Vagina verändert, wodurch andere Mikroorganismen absterben und Raum für Candida bleibt.
<G-vec00383-002-s025><die.absterben><en> Therefore the water needs to be aerated additionally when algae die! Why do algae sometimes grow so much?
<G-vec00383-002-s025><die.absterben><de> Daher sollte das Wasser zusätzlich belüftet werden, wenn Algen von alleine oder bei aktiver Bekämpfung absterben.
<G-vec00383-002-s026><die.absterben><en> Even though our bodies may die, the Spirit of God animates, inspires, and empowers us to victory.
<G-vec00383-002-s026><die.absterben><de> Auch wenn unsere Körper absterben, der Geist Gottes belebt, inspiriert und befähigt uns zum Sieg.
<G-vec00383-002-s027><die.absterben><en> These plants are annuals that will die off in the winter.
<G-vec00383-002-s027><die.absterben><de> Diese Pflanzen sind einjährige Pflanzen, die im Winter absterben.
<G-vec00383-002-s028><die.absterben><en> This process allows the plant to focus as much energy as possible on making a great product, rather than wasting energy maintaining leaves that may die anyway.
<G-vec00383-002-s028><die.absterben><de> Dieser Prozess ermöglicht es der Pflanze, so viel Energie wie möglich auf ein großartiges Produkt zu fokussieren, statt Energie für die Aufrechterhaltung der Blätter zu verschwenden, die sowieso absterben.
<G-vec00383-002-s029><die.absterben><en> It misses the necessary life sap and will die.
<G-vec00383-002-s029><die.absterben><de> Sie entbehrt dem notwendigen Lebenssaft und wird absterben.
<G-vec00383-002-s030><die.absterben><en> Rosette bush must remain on the surface, otherwise it may die.
<G-vec00383-002-s030><die.absterben><de> Der Rosettenstrauch muss an der Oberfläche bleiben, da er sonst absterben kann.
<G-vec00383-002-s031><die.absterben><en> The active ingredient induces a process called lipolysis, where the fat cells rupture and die.
<G-vec00383-002-s031><die.absterben><de> Der Wirkstoff induziert einen Prozess namens Lipolyse, bei dem die Fettzellen reißen und absterben.
<G-vec00383-002-s032><die.absterben><en> There remain, therefore still some remnants of inequality which could not yet die off.
<G-vec00383-002-s032><die.absterben><de> Es bleiben somit noch gewisse Reste der Ungleichheit bestehen, die noch nicht absterben konnten.
<G-vec00383-002-s033><die.absterben><en> This causes them to die out, and then the infection goes away.
<G-vec00383-002-s033><die.absterben><de> Dies bewirkt, dass sie absterben und die Infektion verschwindet.
<G-vec00383-002-s034><die.absterben><en> Those who have these animals in the household know that there is a dangerous disease of rabbits - myxomatosis, from which all the livestock may die out if the necessary measures are not taken.
<G-vec00383-002-s034><die.absterben><de> Diejenigen, die diese Tiere auf dem Bauernhof haben, wissen, dass es eine gefährliche Kaninchenerkrankung gibt - die Myxomatose, bei der alle Tiere absterben, wenn Sie nicht die erforderlichen Maßnahmen ergreifen.
<G-vec00383-002-s035><die.absterben><en> Free radicals attack our body's cells, damage our fat cells and proteins and destroy their genetic code until our cells' functions are so restricted that they give up and die.
<G-vec00383-002-s035><die.absterben><de> Freie Radikale greifen die Körperzellen an, machen das Fett ranzig, schädigen Proteine und zerstören deren genetischen Code, bis die Funktion unserer Zellen so eingeschränkt ist, dass diese aufgeben und absterben.
<G-vec00383-002-s036><die.absterben><en> Here the challenge is that the cells die if they thaw out.
<G-vec00383-002-s036><die.absterben><de> Das ist eine Herausforderung, da die Zellen bei Erwärmung absterben.
<G-vec00383-002-s037><die.absterben><en> Complications In stages II and III, the free piece of bone can die, so it can not be united with the rest of the talus.
<G-vec00383-002-s037><die.absterben><de> Komplikationen In den Stadien II und III kann das freie Knochenstück absterben, sich also nicht mit dem übrigen Sprungbein vereinigen.
<G-vec00383-002-s247><die.sterben><en> Don't die like cats and dogs.
<G-vec00383-002-s247><die.sterben><de> Sterbt nicht wie Katzen und Hunde.
<G-vec00383-002-s248><die.sterben><en> 2 And the woman said to the serpent, We may eat of the fruit of the trees of the garden, 3 but of the fruit of the tree in the middle of the garden, God has said, You shall not eat of it, nor shall you touch it, lest you die.
<G-vec00383-002-s248><die.sterben><de> 2 Da sprach das Weib zu der Schlange: Wir essen von den Früchten der Bäume im Garten; 3 aber von den Früchten des Baumes mitten im Garten hat Gott gesagt: Eßt nicht davon, rührt's auch nicht an, daß ihr nicht sterbt.
<G-vec00383-002-s249><die.sterben><en> 7 And do not go outside the entrance of the tent of meeting, lest you die, for the anointing oil of the Lord is upon you.”
<G-vec00383-002-s249><die.sterben><de> 7 Vom Eingang des Zeltes der Begegnung sollt ihr nicht weggehen, damit ihr nicht sterbt; denn das Öl der Salbung des HERRN ist auf euch.
<G-vec00383-002-s250><die.sterben><en> When you die in a fight no more than 5 items will be broken at one time.
<G-vec00383-002-s250><die.sterben><de> Wenn ihr sterbt, können nicht mehr als 5 Gegenstände gleichzeitig kaputtgehen.
<G-vec00383-002-s251><die.sterben><en> 35 Day and night shall you remain in the tabernacle observing the watches of the Lord, lest you die: for so it hath been commanded me.
<G-vec00383-002-s251><die.sterben><de> 35Und ihr sollt vor der Tür der Stiftshütte Tag und Nacht bleiben sieben Tage lang und sollt nach dem Gebot des HERRN tun, dass ihr nicht sterbt; denn so ist es mir geboten.
<G-vec00383-002-s252><die.sterben><en> 3 but of the fruit of the tree that is in the midst of the garden, God has said, Ye shall not eat of it, and ye shall not touch it, lest ye die.
<G-vec00383-002-s252><die.sterben><de> 3 aber von den Früchten des Baumes mitten im Garten hat Gott gesagt: Eßt nicht davon, rührt's auch nicht an, daß ihr nicht sterbt.
<G-vec00383-002-s253><die.sterben><en> God of Schemes: The doors now work if you die while in Heart’s Grief Vestibule.
<G-vec00383-002-s253><die.sterben><de> Der Gott der Intrigen: Die Türen funktionieren nun, falls ihr sterbt, wenn ihr im Herzeleid-Vestibül seid.
<G-vec00383-002-s254><die.sterben><en> And if ye die, or are slain, Lo! it is unto Allah that ye are brought together.
<G-vec00383-002-s254><die.sterben><de> [3:157] Und wenn ihr sterbt oder erschlagen werdet, werdet ihr vor Allah versammelt.
<G-vec00383-002-s255><die.sterben><en> 9 You shall not drink wine nor any thing that may make drunk, thou nor thy sons, when you enter into the tabernacle of the testimony, lest you die: because it is an everlasting precept through your generations:
<G-vec00383-002-s255><die.sterben><de> 9Du und deine Söhne, ihr sollt weder Wein noch starke Getränke trinken, wenn ihr in die Stiftshütte geht, damit ihr nicht sterbt.
<G-vec00383-002-s256><die.sterben><en> 8 Then Jehovah said to Aaron: 9 “Do not drink wine or other alcoholic beverages, you and your sons with you, when you come into the tent of meeting,+ so that you will not die.
<G-vec00383-002-s256><die.sterben><de> 8 Und Jehova redete dann zu Aaron, indem [er] sprach: 9 „Trink nicht Wein noch berauschendes Getränk,+ du und deine Söhne mit dir, wenn ihr in das Zelt der Zusammenkunft kommt, damit ihr nicht sterbt.
<G-vec00383-002-s257><die.sterben><en> And it was revealed in my ears by the LORD of hosts, Surely this iniquity shall not be purged from you till you die, says the Lord GOD of hosts.
<G-vec00383-002-s257><die.sterben><de> 14 Aber der HERR der Heerscharen hat sich meinen Ohren geoffenbart: Wenn euch diese Schuld vergeben wird, bis ihr sterbt, spricht der Herr, der HERR der Heerscharen.
<G-vec00383-002-s258><die.sterben><en> 6 Moshe said to Aharon, and to El`azar and to Itamar, his sons, "Don't let the hair of your heads go loose, neither tear your clothes; that you don't die, and that he not be angry with all the congregation: but let your brothers, the whole house of Yisra'el, bewail the burning which the LORD has kindled.
<G-vec00383-002-s258><die.sterben><de> 6 Und Mose sagte zu Aaron und zu seinen Söhnen Eleasar und Itamar: Euer Haupthaar sollt ihr nicht frei hängen lassen und eure Kleider nicht zerreißen, damit ihr nicht sterbt und er nicht über die ganze Gemeinde zornig wird.
<G-vec00383-002-s259><die.sterben><en> They’re in their perfection because that’s what happens when you die.
<G-vec00383-002-s259><die.sterben><de> Sie befinden sich in ihrem perfekten Zustand, denn das ist so, wenn ihr sterbt.
<G-vec00383-002-s260><die.sterben><en> 3But of the fruit of the tree which is in the midst of the garden, God hath said, Ye shall not eat of it, neither shall ye touch it, lest ye die.
<G-vec00383-002-s260><die.sterben><de> 3aber von den Früchten des Baumes mitten im Garten hat Gott gesagt: Eßt nicht davon, rührt's auch nicht an, daß ihr nicht sterbt.
<G-vec00383-002-s261><die.sterben><en> So, your spirit is free, and when you die, what happens to you is a very simple thing, that you feel very liberated, absolutely, and then you feel your freedom, completely, and you can decide what you want to do.
<G-vec00383-002-s261><die.sterben><de> Euer Geist ist also frei, und wenn ihr sterbt, passiert etwas ganz Einfaches mit euch, nämlich, daß ihr euch sehr befreit fühlt, absolut, und dann spürt ihr eure Freiheit vollständig, und ihr könnt wählen, was ihr tun möchtet.
<G-vec00383-002-s262><die.sterben><en> Die 1000 times.
<G-vec00383-002-s262><die.sterben><de> Sterbt 1.000-mal.
<G-vec00383-002-s263><die.sterben><en> "If you do die and respawn, things will not happen the same way," Morin explained.
<G-vec00383-002-s263><die.sterben><de> „Wenn ihr sterbt und respawnt, werden die Dinge nicht auf die gleiche Art und Weise ablaufen“, erklärt Morin.
<G-vec00383-002-s264><die.sterben><en> OLD: When you die, you instead turn into a statue for 3 seconds and gain 200 Ultimate.
<G-vec00383-002-s264><die.sterben><de> ALT: Wenn Ihr sterbt, werdet Ihr stattdessen 3 Sekunden lang in eine Statue verwandelt und erhaltet 200 ultimative Kraft.
<G-vec00383-002-s265><die.sterben><en> 3:3 ‹‹Ama But of the fruit of the tree which is in the midst of the garden, God has said, All of you shall not eat of it, neither shall all of you touch it, lest all of you die.
<G-vec00383-002-s265><die.sterben><de> 3:3 aber von den Früchten des Baumes mitten im Garten hat Gott gesagt: Eßt nicht davon, rührt's auch nicht an, daß ihr nicht sterbt.
