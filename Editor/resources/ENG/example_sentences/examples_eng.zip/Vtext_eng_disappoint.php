<G-vec00587-002-s103><disappoint.enttäuschen><en> I said yes because on no account I wanted to disappoint her again.
<G-vec00587-002-s103><disappoint.enttäuschen><de> Ich bejahte, denn ich wollte sie heute auf keinen Fall schon wieder enttäuschen.
