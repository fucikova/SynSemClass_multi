<G-vec00141-002-s019><display.anzeigen><en> Our maps are based on hotel search and display areas and neighborhoods of each hotel so you can see how close you are from Red Town Hall and refine your search within Srodmiescie or West Pomeranian Voivodeship based on closest public transportation, restaurants and entertainment so you can easily get around the city.
<G-vec00141-002-s019><display.anzeigen><de> Mithilfe der Standorte der einzelnen Hotels, die deutlich um Rotes Rathaus herum angezeigt werden, können Sie Ihre Suche innerhalb von Śródmieście oder West Pomeranian Voivodeship einschränken, basierend auf anderen Sehenswürdigkeiten in der Nähe und Stadtvierteln sowie Transportoptionen.
<G-vec00141-002-s020><display.anzeigen><en> The BullionVault website may not display properly, but the site will still be functional.
<G-vec00141-002-s020><display.anzeigen><de> Es könnte sein, dass die BullionVault-Webseite nicht vollständig angezeigt ist, sie wird aber trotzdem funktionieren.
<G-vec00141-002-s021><display.anzeigen><en> When a report.csv file for an activity report is opened in Excel, Chinese characters do not display correctly, even though the report.csv file has been created correctly by default because Excel always reads the file using the ISO Latin character set.
<G-vec00141-002-s021><display.anzeigen><de> Wird die Datei report.csv für einen Aktivitätsbericht in Microsoft Excel geöffnet, so werden chinesische Zeichen nicht korrekt angezeigt, obwohl die Datei report.csv korrekt konfiguriert wurde.
<G-vec00141-002-s022><display.anzeigen><en> Websites that utilize PPC ads will display an advertisement when a keyword query matches an advertiser's keyword list, or when a content site displays relevant content.
<G-vec00141-002-s022><display.anzeigen><de> Webseiten, die PPC-Anzeigen nutzen, werden angezeigt, wenn eine Keyword-Suchanfrage, mit der Keyword-Liste eines Inserenten übereinstimmt; oder wenn eine Content-Webseite relevante Inhalte anzeigt.
<G-vec00141-002-s023><display.anzeigen><en> It may not be available to display the incoming call number correctly.
<G-vec00141-002-s023><display.anzeigen><de> Die eingehende Rufnummer wird unter Umständen nicht richtig angezeigt.
<G-vec00141-002-s024><display.anzeigen><en> We will only display your firstname, username, age and your gender publicly.
<G-vec00141-002-s024><display.anzeigen><de> Nur dein Vorname, dein Benutzername, dein Alter und dein Geschlecht werden später öffentlich angezeigt.
<G-vec00141-002-s025><display.anzeigen><en> Dubbed Second Screen, the smaller display can be set to “always on” to display the time, weather, date and battery icon when the primary display is off.
<G-vec00141-002-s025><display.anzeigen><de> Schaltet man seinen Hauptbildschirm beispielsweise aus, können im Second Screen über einen bestimmten Modus das Wetter, die Batterielaufzeit, das Datum und die Uhrzeit angezeigt werden.
<G-vec00141-002-s026><display.anzeigen><en> Any keyboard shortcuts that are assigned currently to that command or item will display in the Current keys box.
<G-vec00141-002-s026><display.anzeigen><de> Alle Tastaturkurzbefehle, die diesem Befehl oder Element zugewiesen sind, werden im Feld Aktuelle Schlüssel angezeigt.
<G-vec00141-002-s027><display.anzeigen><en> Kaart Your browser does not support inline frames or is currently configured not to display inline frames.
<G-vec00141-002-s027><display.anzeigen><de> Der Browser unterstuetzt keine Inlineframes oder ist aktuell so konfiguriert, dass Inlineframes nicht angezeigt werden.
<G-vec00141-002-s028><display.anzeigen><en> Fixed a bug that caused several spells, including Tornado, Arcane Shield, and most frequently Whirlpool, to sometimes fail to display any graphics.
<G-vec00141-002-s028><display.anzeigen><de> Ein Fehler wurde behoben, der dazu führte, dass für verschiedene Zauber, unter anderem Tornado, Arkaner Schild und am häufigsten Strudel, manchmal keine Grafik angezeigt wurde.
<G-vec00141-002-s029><display.anzeigen><en> If the Windows display language is still set to English, the title bar remains in English and the Close, Minimize, and Maximize buttons remain in the upper-right corner as they do in a left-to-right interface.
<G-vec00141-002-s029><display.anzeigen><de> Wenn die Windows-Anzeigesprache noch auf Englisch festgelegt ist, wird die Titelleiste weiterhin in Englisch angezeigt, und die Schaltflächen Schließen, Minimieren und Maximieren werden weiterhin in der rechten oberen Ecke angezeigt, genau wie bei einer Links-nach-rechts-Oberfläche.
<G-vec00141-002-s030><display.anzeigen><en> frames or is currently configured not to display inline frames. Weight
<G-vec00141-002-s030><display.anzeigen><de> Der Browser unterstützt keine Inlineframes oder ist aktuell so konfiguriert, dass Inlineframes nicht angezeigt werden.
<G-vec00141-002-s031><display.anzeigen><en> Stacked Japanese dates do not display correctly in converted files.
<G-vec00141-002-s031><display.anzeigen><de> Gestapelte japanische Datumsangaben werden in konvertierten Dateien nicht richtig angezeigt.
<G-vec00141-002-s032><display.anzeigen><en> The system will then display the responsible single point of contact, who you can contact with your request.
<G-vec00141-002-s032><display.anzeigen><de> Ihnen wird dann der zuständige einheitliche Ansprechpartner, an den Sie sich mit Ihrem Anliegen wenden können, angezeigt.
<G-vec00141-002-s033><display.anzeigen><en> This command works in a similar fashion to the Get command, but does not display the "Source control - Get" dialog box.
<G-vec00141-002-s033><display.anzeigen><de> Dieser Befehl funktioniert ähnlich wie der Befehl "Abrufen", doch wird das Dialogfeld "Versionskontrolle - Abrufen" nicht angezeigt.
<G-vec00141-002-s034><display.anzeigen><en> It then displays the signs digitally in the instrument panel’s cluster display.
<G-vec00141-002-s034><display.anzeigen><de> Diese Zeichen werden digital auf dem Display des Kombiinstruments angezeigt.
<G-vec00141-002-s035><display.anzeigen><en> And it may not display the timer, either.
<G-vec00141-002-s035><display.anzeigen><de> Außerdem wird möglicherweise die Uhrzeit nicht angezeigt.
<G-vec00141-002-s036><display.anzeigen><en> Remarque: This page might not display properly in other browsers.
<G-vec00141-002-s036><display.anzeigen><de> Bitte beachten Sie, dass diese Seite in anderen Browsern möglicherweise nicht korrekt angezeigt wird.
<G-vec00141-002-s037><display.anzeigen><en> You can also remove one of the marked lines when prompted to add the style — then the list of blockable items will display on the right side or on the top.
<G-vec00141-002-s037><display.anzeigen><de> Man kann aber auch eine der markierten Zeilen des User Style entfernen, wenn man es hinzufügt — dann wird die Liste auf der rechten Seite beziehungsweise oben angezeigt.
<G-vec00141-002-s038><display.anzeigen><en> Dynamic Green view offers distances from the front, centre and back of the green are made viewable on the 1.26" LCD display.
<G-vec00141-002-s038><display.anzeigen><de> Dynamic Green View gibt Ihnen Entfernungen zur Vorderseite, Mitte und Rückseite des Grüns, die auf einem 1,26 Zoll großen LCD-Display angezeigt werden.
<G-vec00141-002-s039><display.anzeigen><en> Not exporting a column can be of interest if the intent is only to display the column in the dashboard.
<G-vec00141-002-s039><display.anzeigen><de> Es kann von Vorteil sein, eine Spalte nicht zu exportieren, wenn Sie nur im Dashboard angezeigt werden soll.
<G-vec00141-002-s040><display.anzeigen><en> A second Web page can display a different form if it contains a different object.
<G-vec00141-002-s040><display.anzeigen><de> Auf einer zweiten Webseite kann ein anderes Formular angezeigt werden, wenn diese ein anderes Objekt enthält.
<G-vec00141-002-s041><display.anzeigen><en> Without the cache, you may have to wait several minutes for some surfaces to display.
<G-vec00141-002-s041><display.anzeigen><de> Ohne den Cache müssen Sie möglicherweise mehrere Minuten warten, bis einige Oberflächen angezeigt werden.
<G-vec00141-002-s042><display.anzeigen><en> If you work with giant spreadsheets, you might prefer one large monitor that can display more rows and columns at once.
<G-vec00141-002-s042><display.anzeigen><de> Wenn Sie mit sehr umfangreichen Tabellen arbeiten, kommen Sie vielleicht mit einem großen Monitor, auf dem mehr Zeilen und Spalten gleichzeitig angezeigt werden können, besser zurecht.
<G-vec00141-002-s043><display.anzeigen><en> Switch to any other layout, and add any text you want to display as the caption.
<G-vec00141-002-s043><display.anzeigen><de> Wechseln Sie zu einem beliebigen anderen Layout und fügen Sie dann Ihren gewünschten Text hinzu, der als Beschriftung angezeigt werden soll.
<G-vec00141-002-s044><display.anzeigen><en> Here are more options you can choose for the display of your menu item.
<G-vec00141-002-s044><display.anzeigen><de> Es erscheinen weitere Optionen, aus denen man wählen kann, wie der Menüeintrag angezeigt werden soll.
<G-vec00141-002-s045><display.anzeigen><en> Depending on the level of traffic on a specific environment, it may take a few more hours to display the updates.
<G-vec00141-002-s045><display.anzeigen><de> Je nach Datenverkehrsaufkommen in einer bestimmten Umgebung kann es einige Stunden dauern, bis die Updates angezeigt werden.
<G-vec00141-002-s046><display.anzeigen><en> A delay only becomes noticeable if several users are accessing the same thing, e.g. if several users call up a PHP page or script at the same time, it can take longer to display the page or script, depending on the hardware.
<G-vec00141-002-s046><display.anzeigen><de> Es macht sich erst bemerkbar, wenn sehr viele Anwender auf ein und dasselbe zugreifen, d.h. wenn sehr viele Anwender eine PHP-Seite/-Script gleichzeitig aufrufen, kann es je nach Server-Hardware hier und da etwas länger dauern, bis diese angezeigt werden.
<G-vec00141-002-s047><display.anzeigen><en> In the Crosstab section, next to Column, select the time period that you want to display, and then enter the number of time periods for each column.
<G-vec00141-002-s047><display.anzeigen><de> Wählen Sie im Abschnitt Kreuztabelle neben Spalte den Zeitraum aus, der angezeigt werden soll, und geben Sie dann die Anzahl der Zeiträume für jede Spalte ein.
<G-vec00141-002-s048><display.anzeigen><en> Books are QuarkXPress files that display as windows containing links to individual documents, called chapters.
<G-vec00141-002-s048><display.anzeigen><de> Bücher sind QuarkXPress Dateien, die als Fenster angezeigt werden mit Links zu einzelnen Dokumenten, den Kapiteln.
<G-vec00141-002-s049><display.anzeigen><en> The payment status may display as pending for up to 24 hours, even if no grace period is set.
<G-vec00141-002-s049><display.anzeigen><de> Der Zahlungsstatus kann bis zu 24 Stunden lang als ausstehend angezeigt werden, auch wenn kein Kulanzzeitraum festgelegt wurde.
<G-vec00141-002-s050><display.anzeigen><en> support inline frames or is currently configured not to display inline All right reserved.
<G-vec00141-002-s050><display.anzeigen><de> Ihr Browser unterstützt keine inline frames oder ist so konfiguriert, das inline frames nicht angezeigt werden.
<G-vec00141-002-s051><display.anzeigen><en> They also can nicely display in your home or office.
<G-vec00141-002-s051><display.anzeigen><de> Sie können auch schön in Ihrem Zuhause oder im Büro angezeigt werden.
<G-vec00141-002-s052><display.anzeigen><en> However, the goal is to load and display only the car models of the manufacturer that the user selects in the combo box.
<G-vec00141-002-s052><display.anzeigen><de> Es sollen jedoch nur die Fahrzeugmodelle des vom Benutzer in der Auswahlliste ausgewählten Herstellers geladen und angezeigt werden.
<G-vec00141-002-s053><display.anzeigen><en> Unable to display this Web Part.
<G-vec00141-002-s053><display.anzeigen><de> Dieses Webpart kann nicht angezeigt werden.
<G-vec00141-002-s054><display.anzeigen><en> If pressing F6 doesn't display the task pane you want, try pressing ALT to place the focus on the menu bar and then pressing CTRL+TAB to move to the task pane.
<G-vec00141-002-s054><display.anzeigen><de> Hinweis: Wenn der gewünschte Aufgabenbereich nicht durch Drücken von F6 angezeigt werden kann, drücken Sie ALT, um den Fokus in das Menüband zu setzen, und drücken Sie dann F6, um zum Aufgabenbereich zu wechseln.
<G-vec00141-002-s055><display.anzeigen><en> I’ve included with this article a picture of my office wall, where I display copies of many of the key models.
<G-vec00141-002-s055><display.anzeigen><de> Ich habe diesem Artikel ein Bild meiner Bürowand beigefügt, auf der Kopien vieler Schlüsselmodelle angezeigt werden.
<G-vec00141-002-s056><display.anzeigen><en> To display the data that you want in the List Web Part as well as the other connected Web Part, you may need to edit the view of the list.
<G-vec00141-002-s056><display.anzeigen><de> Damit im Listenwebpart und im verbundenen Webpart die gewünschten Daten angezeigt werden, müssen Sie die Listenansicht möglicherweise bearbeiten.
<G-vec00141-002-s057><display.anzeigen><en> A change in the weather symbol on the display may at times take longer than desired.
<G-vec00141-002-s057><display.anzeigen><de> Eine WetterSymboländerung in der Anzeige kann zum Teil länger als erwünscht dauern.
<G-vec00141-002-s058><display.anzeigen><en> VIVE Wireless Adapter > Sometimes the wireless signal seems weak or the headset display gets disrupted.
<G-vec00141-002-s058><display.anzeigen><de> VIVE WLAN Adapter > Manchmal erscheint das Funksignal schwach oder die Anzeige des Headsets wird gestört.
<G-vec00141-002-s059><display.anzeigen><en> System Symptom No operation No function or display No sound or unnatural sound.
<G-vec00141-002-s059><display.anzeigen><de> System Symptom Kein Betrieb Keine Funktion oder Anzeige Kein oder unnatürlicher Ton.
<G-vec00141-002-s060><display.anzeigen><en> The display of the Digital thermostat comes with a backlit and can be so also in the twilight take a look at the functionality, as well as the current room temperature.
<G-vec00141-002-s060><display.anzeigen><de> Die Anzeige des Digital Thermostat kommt mit einer Hintergrundbeleuchtung und lässt so auch in der Dämmerung einen Blick auf die Funktionalität, sowie die aktuelle Raumtemperatur werfen.
<G-vec00141-002-s061><display.anzeigen><en> held GPS receiver with large color display, electronic compass, barometrical altimeter, integrated world and Europe/Africa map, auto-routing, USB and serial interface.
<G-vec00141-002-s061><display.anzeigen><de> Empfänger mit großer, farbiger Anzeige, elektronischem Kompass, barometrischem Höhenmeter, integrierter Welt- und Europa/Afrika-Karte, automatischer Routenberechnung, USB- und serieller Schnittstelle.
<G-vec00141-002-s062><display.anzeigen><en> Combined display of all available logs of IRC Improv Wiki.
<G-vec00141-002-s062><display.anzeigen><de> Dies ist die kombinierte Anzeige aller in E-Assessment-Wiki geführten Logbücher.
<G-vec00141-002-s063><display.anzeigen><en> Display current sensor data, including: engine rpm, calculated load value, coolant temperature, fuel system status, vehicle speed, short term fuel trim, long term fuel trim, intake manifold pressure, timing advance, intake air temperature, air flow rate, absolute throttle position, oxygen sensor voltages/associated short term fuel trims, fuel system status, fuel pressure.
<G-vec00141-002-s063><display.anzeigen><de> (SMART SCANNING) Anzeige der ECHTZEIT-Motorsensordaten, einschließlich Motordrehzahl, berechneter Lastwert, Kühlmitteltemperatur, Kraftstoffsystemstatus, Fahrzeuggeschwindigkeit, kurzzeitige Kraftstofftrimmung, langfristige Kraftstofftrimmung, Ansaugkrümmerdruck, Zeitvorlauf, Ansauglufttemperatur, Luftdurchflussrate, absolute Drosselklappenstellung, Sauerstoffsensorspannungen / zugehörige Kurzzeit-Kraftstoffverkleidungen, Kraftstoffsystemstatus, Kraftstoffdruck.
<G-vec00141-002-s064><display.anzeigen><en> By submitting information, you grant BioClin a nonexclusive, royalty-free, perpetual, irrevocable and fully sub licensable right to reproduce, use, modify, publish, adapt, translate, create derivative works from, distribute and display such content throughout the world in any media.
<G-vec00141-002-s064><display.anzeigen><de> Mit dem Einreichen von Informationen gewähren Sie BioClin ein nicht exklusives, gebührenfreies, ständiges, unwiderrufliches und vollständig unterlizenzierbares Recht zur Vervielfältigung, Nutzung, Veränderung, Veröffentlichung, Anpassung, Übersetzung, Erzeugung abgeleiteter Werke, Verteilung und Anzeige solcher Inhalte auf der ganzen Welt.
<G-vec00141-002-s065><display.anzeigen><en> This release includes several significant new features, including the showing the web hosted in IE8 processes in the process tooltip, display of a svchost’s service host category in its tooltip, mapping of service names to threads on the threads tab and TCP/IP tabs of the process properties dialog on Windows Vista and higher, a new.NET assembly information tab in the process properties dialog, as well as other improvements and bug fixes.
<G-vec00141-002-s065><display.anzeigen><de> Diese Version enthält mehrere wichtige neue Funktionen, darunter die Anzeige des in IE8-Prozessen gehosteten Webs im Prozess-Tooltip, die Anzeige der Service-Host-Kategorie eines svchosts im Tooltip, die Zuordnung von Dienstnamen zu Threads auf der Registerkarte Threads und TCP/IP-Registerkarten des Prozesseigenschaften-Dialogfelds unter Windows Vista und höher, eine neue Registerkarte mit Informationen zur.NET-Assembly im Prozesseigenschaften-Dialogfeld sowie weitere Verbesserungen und Fehlerbehebungen.
<G-vec00141-002-s066><display.anzeigen><en> The Anti-Climb fence is a unique perimeter security product that maintains a guarded display ofvisual screening balancing the need to delay and deter an attack.
<G-vec00141-002-s066><display.anzeigen><de> Der Anti-Aufstiegszaun ist ein einzigartiges Umkreissicherheitsprodukt, das eine vorsichtige ofvisual Siebung der Anzeige beibehält, die den Bedarf balanciert, einen Angriff zu verzögern und abzuhalten.
<G-vec00141-002-s067><display.anzeigen><en> The default for this button is to display the current ISO setting.
<G-vec00141-002-s067><display.anzeigen><de> Die voreingestellte Funktion dieser Taste besteht in der Anzeige der Lichtempfindlichkeit (ISO-Wert).
<G-vec00141-002-s068><display.anzeigen><en> The heat setting display for the reduced zone changes between two levels.
<G-vec00141-002-s068><display.anzeigen><de> Die Anzeige der reduzierten Kochzone wechselt zwischen den beiden Kochstufen.
<G-vec00141-002-s069><display.anzeigen><en> The HL760U features a digital readout of elevation that provides a numeric display of ± 5 cm (± 2 inches).
<G-vec00141-002-s069><display.anzeigen><de> Der HL760U verfügt über eine digitale Anzeige der Sollhöhenabweichung, die eine numerische Anzeige von 5 cm bietet.
<G-vec00141-002-s070><display.anzeigen><en> Devices for set point monitoring, conversion and display of rotational speed, speed and flow rate, with analog output and/or data interface.
<G-vec00141-002-s070><display.anzeigen><de> Tachometer Geräte für die Grenzüberwachung, Umformung und Anzeige von Drehzahl, Geschwindigkeit und Durchfluss, mit Analogausgang und/oder Dateninterface.
<G-vec00141-002-s071><display.anzeigen><en> Therefor, the SENTINEL - position indicator is in the known versions (with mechanical, with electrical display and with circuit monitoring) available in a corrosion-free design.
<G-vec00141-002-s071><display.anzeigen><de> Damit ist das SENTINEL - Zeigerwerk in den bekannten Versionen (mit mechanischer, mit elektrischer Anzeige und mit Leitungsüberwachung) auch in einer korrosionsfreien Bauform verfügbar.
<G-vec00141-002-s072><display.anzeigen><en> Wearable computing academics and makers adopted these viewers and often adapted them for their mobile needs by removing the display for one eye.
<G-vec00141-002-s072><display.anzeigen><de> Forscher im Wearable-Computing und die “Maker”-Community haben sich diese Abspielgeräte zunutze gemacht und passten sie für ihre besonderen mobilen Bedürfnisse an, etwa durch das Entfernen der Anzeige für ein Auge.
<G-vec00141-002-s073><display.anzeigen><en> Messages + Music: display call and SMS messages via the touch screen display
<G-vec00141-002-s073><display.anzeigen><de> Benachrichtigungen + Musik: Anzeige von Anruf- und SMS-Benachrichtigungen über das Touchscreen-Display.
<G-vec00141-002-s074><display.anzeigen><en> Third-party cookie IDE Used by Google Double Click to register the user’s actions on the website after showing or even clicking on an advert to measure the effectiveness of an advert and the display of target-oriented advertising for the user.
<G-vec00141-002-s074><display.anzeigen><de> Drittanbieter-Cookie IDE Verwendet von Google DoubleClick, um die Handlungen des Benutzers auf der Website nach der Anzeige oder dem Klicken auf eine der Anzeigen des Anbieters zu registrieren und zu melden, mit dem Zweck der Messung der Wirksamkeit einer Werbung und der Anzeige zielgerichteter Werbung für den Benutzer.
<G-vec00141-002-s075><display.anzeigen><en> It contains devices for operating, controlling and regulating as well as for the graphical display of machine data.
<G-vec00141-002-s075><display.anzeigen><de> Sie beinhaltet Geräte für die Bedienung, Steuerung und Regelung sowie für die grafische Anzeige von Maschinendaten.
<G-vec00141-002-s076><display.anzeigen><en> 1 = Only display the first column in the footer.
<G-vec00141-002-s076><display.anzeigen><de> 1 = Nur die erste Spalte im Footer anzeigen.
<G-vec00141-002-s077><display.anzeigen><en> Together with the small seconds display at “6 o’clock” and the date display at “3”, this gives the dial a pleasing equilibrium.
<G-vec00141-002-s077><display.anzeigen><de> Zusammen mit den Anzeigen für die kleine Sekunde bei «6 Uhr» und dem Datum bei «3 Uhr» entsteht so ein ausgewogenes Zifferblattbild.
<G-vec00141-002-s078><display.anzeigen><en> We may use your Personal Data and other information collected in accordance with this Privacy Statement to provide a targeted display, feature, Services or offer to you on third-party websites.
<G-vec00141-002-s078><display.anzeigen><de> Wir können Ihre personenbezogenen Daten und sonstige Informationen, die wir gemäß diesen Datenschutzgrundsätzen erfasst haben, nutzen, um Ihnen personalisierte Anzeigen, Funktionen oder Angebote auf Websites von Drittanbietern bereitzustellen.
<G-vec00141-002-s079><display.anzeigen><en> If you want to display cells with a highlight when you print a worksheet, you can use formatting features to apply cell shading.
<G-vec00141-002-s079><display.anzeigen><de> Wenn Sie Zellen beim Drucken eines Arbeitsblatts mit einer Hervorhebung anzeigen möchten, können Sie mithilfe von Formatierungsfeatures eine Zellenschattierung anwenden.
<G-vec00141-002-s080><display.anzeigen><en> It allows that web site to recognize your computer when you return, enabling it to display personalized settings and other user preferences.
<G-vec00141-002-s080><display.anzeigen><de> Dadurch kann die Website Ihren Computer wiedererkennen, wenn Sie sie erneut besuchen, und benutzerspezifische Einstellungen anzeigen.
<G-vec00141-002-s081><display.anzeigen><en> The type of content modules you use will vary depending on what kinds of content you want to create, store, and display.
<G-vec00141-002-s081><display.anzeigen><de> Welches Inhaltsmodul Sie verwenden, hängt von der Art der Inhalte ab, die Sie erstellen, speichern und anzeigen möchten.
<G-vec00141-002-s082><display.anzeigen><en> Commercial affiliation These services allow this website to display advertisements for third party products or services.
<G-vec00141-002-s082><display.anzeigen><de> Mit dieser Art von Diensten kann diese Website Werbung für die Produkte oder Dienstleistungen Dritter anzeigen.
<G-vec00141-002-s083><display.anzeigen><en> WebView Webview Adds web pages as contacts to your contact list and can display text and/or issue change alerts from those pages in a window.
<G-vec00141-002-s083><display.anzeigen><de> WebView Webview Fügt Webseiten Ihrer Kontaktliste hinzu, und kann Text anzeigen und/oder bei Änderungen auf diesen Seiten einen Alarm auslösen.
<G-vec00141-002-s084><display.anzeigen><en> You can display your Update Profile form in mobile mode to preview how it will look on your subscribers’ devices. Simply toggle the view from desktop to mobile on the top of the form editor.
<G-vec00141-002-s084><display.anzeigen><de> Sie können eine Vorschau des Renderings Ihres Formulars auf einem Mobilgerät anzeigen, indem Sie die Ansicht oben im Formulareditor von "Desktop" auf "Mobilgerät" umschalten.
<G-vec00141-002-s085><display.anzeigen><en> Slack will display the top three records – simply click Show details to see more or to view it in Salesforce.
<G-vec00141-002-s085><display.anzeigen><de> Slack wird die Top Drei deiner Einträge anzeigen – klicke einfach auf Details anzeigen, um mehr zu sehen oder sie in Salesforce zu öffnen.
<G-vec00141-002-s086><display.anzeigen><en> Step 3: Then iTunes would display the latest update information for you, just follow the wizard and iTunes will automatically download the latest firmware used to update iPhone to latest iOS version.
<G-vec00141-002-s086><display.anzeigen><de> Schritt 3: Dann werden iTunes Ihnen die Informationen zu den neuesten Updates anzeigen, befolgen Sie den Assistenten und iTunes werden die neueste Firmware automatisch herunterladen, die schon beim Update auf iOS 10/9 verwendet wird.
<G-vec00141-002-s087><display.anzeigen><en> We will then display several download buttons that will allow you download converted video as mp3.
<G-vec00141-002-s087><display.anzeigen><de> Wir werden dann mehrere Download-Buttons anzeigen, mit denen du konvertierte Videos als MP3 herunterladen kannst.
<G-vec00141-002-s088><display.anzeigen><en> You may use a thumbnail and display it full sized with a Tooltip.
<G-vec00141-002-s088><display.anzeigen><de> Man kann auch ein kleines Bild mit einem Tooltip vergrößert anzeigen.
<G-vec00141-002-s089><display.anzeigen><en> The central sweep seconds hand allows an accurate reading of 1/8 second, while the two counters on the dial display the lapsed time in hours and minutes.
<G-vec00141-002-s089><display.anzeigen><de> Die Zentralsekunde ermöglicht das genaue Ablesen der Achtelsekunde, während die beiden Totalisatoren auf dem Zifferblatt die abgelaufene Zeit in Stunden- und Minutenschritten anzeigen.
<G-vec00141-002-s090><display.anzeigen><en> Evalanche offers different types of profiling to optimise the profile structure and to improve the capture information and reading behaviors of subscribers - from content profiling to profiling (interest) tagging and progressive profiling (automatic display of data fields) for landing pages.
<G-vec00141-002-s090><display.anzeigen><de> Zur Optimierung des Profilaufbaus und zur besseren Erfassung des Informations- und Leseverhaltens von Abonnenten bietet Evalanche verschiedene Arten des Profilings – angefangen vom Content Profiling über Profile (Interessen)-Tagging bis hin zum Progressive Profiling (automatisches Anzeigen von Datenfeldern) für Landingpages.
<G-vec00141-002-s091><display.anzeigen><en> Section user name, used to display section name in menus or in the document view (Read-only with subsections).
<G-vec00141-002-s091><display.anzeigen><de> Benutzername für Abschnitt zum Anzeigen des Abschnittsnamens in Menüs oder in der Dokumentansicht (Nur-Lesen mit Unterabschnitten).
<G-vec00141-002-s092><display.anzeigen><en> This Privacy Statement applies to pb.com and Pitney Bowes websites, services and products that collect data and display these terms, and that are owned and operated by Pitney Bowes and Pitney Bowes subsidiaries, collectively, "Pitney Bowes".
<G-vec00141-002-s092><display.anzeigen><de> Diese Datenschutzerklärung gilt für pb.com und Pitney Bowes-Websites, -Dienstleistungen und -Produkte, die Daten erfassen und diese Bedingungen anzeigen, und die Pitney Bowes und Tochtergesellschaften von Pitney Bowes gehören und von diesen betrieben werden, gemeinsam als „Pitney Bowes“ bezeichnet.
<G-vec00141-002-s093><display.anzeigen><en> CoPilot Truck can display the speed limit of the current road and warn you if you accidentally exceed it.
<G-vec00141-002-s093><display.anzeigen><de> CoPilot Truck kann die derzeit gültige Geschwindigkeitsbegrenzung anzeigen und Sie warnen, falls Sie diese versehentlich überschreiten.
<G-vec00141-002-s094><display.anzeigen><en> Once you’ve figured out where you want to display a user’s credit balance, use loadRewards() to display how many credits a user has.
<G-vec00141-002-s094><display.anzeigen><de> Wenn Sie festgelegt haben, in welchem Bereich Sie den Kontostand eines Nutzers anzeigen möchten, nutzen Sie loadRewards() zur Anzeige der aktuellen Anzahl Credits.
<G-vec00141-002-s095><display.anzeigen><en> In Writer, you can also display the Navigation toolbar by clicking on the small Navigation icon near the lower right-hand corner of the window below the vertical scroll bar, as shown in Figure 6.
<G-vec00141-002-s095><display.anzeigen><de> In Writer können Sie die Navigationssymbolleiste auch anzeigen lassen, indem Sie auf das kleine Icon klicken, das sich in der unteren rechten Ecke des Fensters unterhalb der vertikalen Bildlaufleiste befindet (siehe Abbildung XYZ).
<G-vec00141-002-s096><display.anzeigen><en> When you change your online ID, you will have the option to display your previous ID with your new ID.
<G-vec00141-002-s096><display.anzeigen><de> Ändert ihr eure Online-ID, habt ihr die Möglichkeit, eure vorherige ID mit eurer neuen ID anzeigen zu lassen, damit eure Freunde euch erkennen können.
<G-vec00141-002-s097><display.anzeigen><en> Tap the Home button twice on your iPhone to display recently used apps
<G-vec00141-002-s097><display.anzeigen><de> a. Tippe die Home-Taste doppelt an, um kürzlich verwendete Apps anzeigen zu lassen.
<G-vec00141-002-s098><display.anzeigen><en> However, you can filter out individual transactions. To do this, go to the transaction list under Reports > Transactions and for Transaction type click on the transactions you want to display.
<G-vec00141-002-s098><display.anzeigen><de> Sie können jedoch einzelne Transaktionen rausfiltern, indem Sie in der Transaktionsliste unter Berichte > Transaktionen bei Transaktionstyp die Transaktionen anklicken, die Sie sich anzeigen lassen wollen.
<G-vec00141-002-s099><display.anzeigen><en> Most browsers offer the possibility to display a warning before storing a cookie, to completely refuse the acceptance of cookies and/or to delete existing cookies again.
<G-vec00141-002-s099><display.anzeigen><de> Die meisten Browser bieten die Möglichkeit, vor Speicherung eines Cookies eine Warnung anzeigen zu lassen, die Annahme von Cookies ganz zu verweigern und/oder bestehende Cookies wieder zu löschen.
<G-vec00141-002-s100><display.anzeigen><en> You can also display departure and arrival information for the stations.
<G-vec00141-002-s100><display.anzeigen><de> Sie können auch Abfahrts- und Ankunftstafeln für die Stationen anzeigen lassen.
<G-vec00141-002-s101><display.anzeigen><en> 3) You can display the video in three different sizes.
<G-vec00141-002-s101><display.anzeigen><de> 3) Du kannst das Video in drei verschiedenen Größen anzeigen lassen.
<G-vec00141-002-s102><display.anzeigen><en> The software user can switch back and forth between stages within a trend project or display relevant/defined stage areas exclusively.
<G-vec00141-002-s102><display.anzeigen><de> Der Softwareanwender kann unter anderem zwischen Stufen innerhalb eines Trend-Projektes hin- und herschalten oder sich relevante Stufenbereiche exklusiv anzeigen lassen.
<G-vec00141-002-s103><display.anzeigen><en> To display the form you have to deactivate the protection for this website temporarily.
<G-vec00141-002-s103><display.anzeigen><de> Um das Formular anzeigen zu lassen, müssen Sie den Schutz für diese Seite temporär deaktivieren.
<G-vec00141-002-s104><display.anzeigen><en> For example, you can display important properties at the top of the page.
<G-vec00141-002-s104><display.anzeigen><de> Zum Beispiel können Sie wichtige Eigenschaften am oberen Rand der Seite anzeigen lassen.
<G-vec00141-002-s105><display.anzeigen><en> You can use the PS Vita as a secondary screen to display unique content when playing games that support the Second Screen feature.
<G-vec00141-002-s105><display.anzeigen><de> Du kannst das PlayStation Vita-System als zweiten Bildschirm verwenden, um darauf Inhalte von Spielen anzeigen zu lassen, welche die Funktion "Zweitbildschirm" unterstützen.
<G-vec00141-002-s106><display.anzeigen><en> Yes, you can display the maximum deformation of each member. Go to the "Display" navigator, open the items "Results", "Deformation" and "Members", and activate the option "Show extremes".
<G-vec00141-002-s106><display.anzeigen><de> Die maximale Verformung jedes Stabes können Sie sich anzeigen lassen, indem Sie im "Zeigen"-Navigator unter "Ergebnisse" -> "Verformung" -> "Stäbe" die Option "Extremwerte anzeigen" aktivieren.
<G-vec00141-002-s107><display.anzeigen><en> You cannot display a Word file from the first round of uploads and a PowerPoint file from the final round for one submission at the same time.
<G-vec00141-002-s107><display.anzeigen><de> Sie können nicht gleichzeitig eine Datei aus der ersten Datei-Upload-Runde und eine PowerPoint-Datei aus der letzten Runde für einen Beitrag anzeigen lassen.
<G-vec00141-002-s108><display.anzeigen><en> During this period, no events have been found that you can display.
<G-vec00141-002-s108><display.anzeigen><de> In diesem Zeitraum wurden keine Events gefunden, die du anzeigen lassen kannst.
<G-vec00141-002-s109><display.anzeigen><en> Integrated into the experiment environment of INCA V7.1, the new oscilloscope makes it possible to dissect the display of analog measurement values into several horizontal strips, enabling vertical stacking of the display with a variety of signal groups.
<G-vec00141-002-s109><display.anzeigen><de> Das neue, in die Experimentierumgebung von INCA V7.1 integrierte Oszilloskop ermöglicht es, die Anzeige in mehrere horizontale Streifen zu unterteilen, so dass sich die Messkurven verschiedener Signalgruppen separat voneinander anzeigen lassen.
<G-vec00141-002-s110><display.anzeigen><en> The Fleet Tracking API offers different tracking modes: You can choose to display single GPS points or the vehicles’ whole track history.
<G-vec00141-002-s110><display.anzeigen><de> Die Fleet Tracking API bietet verschiedene Tracking-Modi: Sie können sich einzelne GPS-Punkte oder die gesamte Streckenhistorie der Fahrzeuge anzeigen lassen.
<G-vec00141-002-s111><display.anzeigen><en> With this Google AdSense widget, you can display Google ads on your website.
<G-vec00141-002-s111><display.anzeigen><de> Mit dem Widget von Google AdSense können Sie Google Werbeanzeigen auf Ihrer Webseite anzeigen lassen.
<G-vec00141-002-s112><display.anzeigen><en> • Using the integrated journal, you can display the details of all historical loads at any time.
<G-vec00141-002-s112><display.anzeigen><de> • Über das integrierte Journal können Sie sich jederzeit die Details aller historischen Ladevorgänge anzeigen lassen.
<G-vec00141-002-s113><display.anzeigen><en> It allows us to display personalized and interest-based advertising on Facebook to certain groups of pseudonymous visitors to our site who also use Facebook.
<G-vec00141-002-s113><display.anzeigen><de> Dieser ermöglicht es uns, bestimmten Gruppen von pseudonymisierten Besuchern unserer Website, die auch Facebook nutzen, individuell abgestimmte und interessenbezogene Werbung auf Facebook anzeigen zu lassen.
<G-vec00141-002-s114><display.anzeigen><en> Row Labels Use to display summary numeric data.
<G-vec00141-002-s114><display.anzeigen><de> Wird verwendet, um numerische Daten in einer Zusammenfassung anzuzeigen.
<G-vec00141-002-s115><display.anzeigen><en> In the Toolbox list on the left side of the panel, click the Basic Actions category to display the basic actions.
<G-vec00141-002-s115><display.anzeigen><de> Klicken Sie in der Toolbox-Liste links im Fenster auf die Kategorie „Basic Actions“ (Einfache Aktionen), um die einfachen Aktionen anzuzeigen.
<G-vec00141-002-s116><display.anzeigen><en> To display SwissPass Mobile on the digital device, it is important to have activated the feature properly, and you must also have sufficiently battery power and a display that is undamaged.
<G-vec00141-002-s116><display.anzeigen><de> Um SwissPass Mobile auf dem digitalen Endgerät anzuzeigen ist es wichtig, die Funktion ordnungsgemäss aktiviert zu haben sowie über genügend Akku und ein nicht beschädigtes Display zu verfügen.
<G-vec00141-002-s117><display.anzeigen><en> (“Google”) remarketing features to display ads on the Google Display Network (GDN).
<G-vec00141-002-s117><display.anzeigen><de> Wir verwenden Google-Inc. („Google“) Remarketing-Funktionen, um Anzeigen im Google Display Network (GDN) anzuzeigen.
<G-vec00141-002-s118><display.anzeigen><en> Your TV must also support the HDR10 media profile to display HDR.
<G-vec00141-002-s118><display.anzeigen><de> Bei diesem Abschnitt wird geprüft, ob Ihr Fernsehgerät in der Lage ist, HDR für Spiele anzuzeigen.
<G-vec00141-002-s119><display.anzeigen><en> In Payroll and Compensation Management, there is an option to display employees’ salary statements directly online and let your employees select their individual compensation plan from those available.
<G-vec00141-002-s119><display.anzeigen><de> Im Bereich der Personalabrechnung und des Vergütungsmanagements gibt es die Option, Mitarbeitern Ihren Gehaltsnachweis direkt online anzuzeigen und die Mitarbeiter selbstständig aus den verfügbaren Vergütungsplänen wählen zu lassen, um ihre individuelle Vergütungskombination zu erstellen.
<G-vec00141-002-s120><display.anzeigen><en> From a command prompt, use showmount –e server to display the names of shared directories on the server.
<G-vec00141-002-s120><display.anzeigen><de> Verwenden Sie an einer Eingabeaufforderung showmount –e Server, um die Namen der freigegebenen Verzeichnisse auf dem Server anzuzeigen.
<G-vec00141-002-s121><display.anzeigen><en> Choose the color to display the months.
<G-vec00141-002-s121><display.anzeigen><de> Wählen Sie die Farbe, die Monate anzuzeigen.
<G-vec00141-002-s122><display.anzeigen><en> When you request to view our website, we collect the following data which are technically required for us to display our website to you and to ensure stability and security.
<G-vec00141-002-s122><display.anzeigen><de> Wenn Sie unsere Website betrachten möchten, erheben wir die folgenden Daten, die für uns technisch erforderlich sind, um Ihnen unsere Website anzuzeigen und die Stabilität und Sicherheit zu gewährleisten.
<G-vec00141-002-s123><display.anzeigen><en> 2... click [apply] to display the selected modified wind in the forecast
<G-vec00141-002-s123><display.anzeigen><de> 2... Klicke auf [Übernehmen], um den ausgewählten modifizierten Wind in der Vorhersage anzuzeigen.
<G-vec00141-002-s124><display.anzeigen><en> Here you have the option to display all of the required information.
<G-vec00141-002-s124><display.anzeigen><de> Hier haben Sie die Möglichkeit, alle gewünschten Informationen anzuzeigen.
<G-vec00141-002-s125><display.anzeigen><en> Expand the folder you are filtering to display the objects it contains.
<G-vec00141-002-s125><display.anzeigen><de> Erweitern Sie den Ordner, den Sie filtern, um die darin enthaltenen Objekte anzuzeigen.
<G-vec00141-002-s126><display.anzeigen><en> Open the file SHA1SUM with a text editor, such as WordPad, to display its contents.
<G-vec00141-002-s126><display.anzeigen><de> Öffnen Sie die Datei SHA1SUM mit einem Texteditor, beispielsweise Notepad, um ihren Inhalt anzuzeigen.
<G-vec00141-002-s127><display.anzeigen><en> Y Subtotal key s Use this key to display and print the current subtotal (includes add-on tax) amount.
<G-vec00141-002-s127><display.anzeigen><de> Y Zwischensummentaste s Verwenden Sie diese Taste, um die gegenwärtige Zwischensumme (einschließlich Umsatzsteuer) anzuzeigen und auszudrucken.
<G-vec00141-002-s128><display.anzeigen><en> By accessing this website, the browser loads web fonts in the browser cache to correctly display the required typefaces.
<G-vec00141-002-s128><display.anzeigen><de> Beim Aufruf einer Seite lädt Ihr Browser die benötigten Web Fonts in ihren Browsercache, um Texte und Schriftarten korrekt anzuzeigen.
<G-vec00141-002-s129><display.anzeigen><en> Used to display files and folders in the graphical user interface (GUI) operating systems.
<G-vec00141-002-s129><display.anzeigen><de> Wird verwendet, um Dateien und Ordner auf der grafischen Benutzeroberfläche (GUI) der Betriebssysteme anzuzeigen.
<G-vec00141-002-s130><display.anzeigen><en> Consider using the size attribute to display the first set of options in a select control.
<G-vec00141-002-s130><display.anzeigen><de> Erwägen Sie, das size-Attribut zu verwenden, um die ersten Optionen einer Auswahlliste anzuzeigen.
<G-vec00141-002-s131><display.anzeigen><en> After the guild reaches level 100, the Prestige column will be replaced with Nobility (to display the number of Nobility points gained by each member during the current month).
<G-vec00141-002-s131><display.anzeigen><de> Nachdem die Gilde Stufe 100 erreicht hat wird die Prestige Zeile mit Bekanntheit ersetzt (um die Anzahl an Bekanntheitspunkten, die von jedem Spieler im aktuellen Monat erhalten wurde anzuzeigen).
<G-vec00141-002-s132><display.anzeigen><en> Fixed a problem where the application could hang while beginning to display live output from external utility tools that have been started without privileged permissions.
<G-vec00141-002-s132><display.anzeigen><de> Es wurde ein Problem behoben, bei dem das Programm hängen konnte, wenn es begonnen hat, Live-Ausgaben externer Dienstprogramme anzuzeigen, die ohne privilegierte Rechte gestartet wurden.
<G-vec00141-002-s190><display.darstellen><en> With this layout, you are able to display one large picture on the front as the main image of the carousel.
<G-vec00141-002-s190><display.darstellen><de> Mit diesem Layout können Sie ein großes Bild auf der Vorderseite als Hauptbild des Karussells darstellen.
<G-vec00141-002-s191><display.darstellen><en> You acknowledge and confirm that you have no expectation of privacy when using such Product features, including without limitation when uploading or submitting UGC; comparing your statistics, personal bests, and leaderboards against other users; searching for other users by username; discovering events that other users have signed up for; and linking to social media accounts that publicly display user information.
<G-vec00141-002-s191><display.darstellen><de> Sie nehmen zur Kenntnis und bestätigen, dass Sie bei der Nutzung derartiger Funktionen des Produkts keine Privatsphäre erwarten, einschließlich ohne Einschränkung beim Hochladen oder Einsenden von selbst erstellten Inhalten; beim Vergleich Ihrer Statistik, persönlichen Rang- und Bestenlisten mit denen anderer Benutzer; bei der Suche nach anderen Benutzern mittels des Benutzernamens; beim Entdecken von Events, für die sich andere Spieler angemeldet haben, und für die Verlinkung mit Social-Media-Konten, die Benutzerinformationen öffentlich darstellen.
<G-vec00141-002-s192><display.darstellen><en> For example, if you drag the "Part" attribute into this analysis group, the Analyzer can display the total of the accepted net purchases for each part depending on the view.
<G-vec00141-002-s192><display.darstellen><de> Ziehen Sie beispielsweise das Attribut "Teil" in diese Analysegruppe, so kann der Analyzer je nach Ansicht pro Teil die Summe der akzeptierten Warenwerte darstellen.
<G-vec00141-002-s193><display.darstellen><en> Swami ji writes about media and advertisements that display nearly naked women which sets parameters for beauty and is not respectful for women.
<G-vec00141-002-s193><display.darstellen><de> Swami ji schreibt über Medien und Werbung, die Frauen nackt darstellen, was ein falsches Bild von Schönheit gibt und keinen Respekt für Frauen schafft.
<G-vec00141-002-s194><display.darstellen><en> The person responsible uses Google Maps to conveniently display addresses and directions.
<G-vec00141-002-s194><display.darstellen><de> Der Verantwortliche verwendet Google Maps, um Adressen und Wegbeschreibungen komfortabel darstellen zu können.
<G-vec00141-002-s195><display.darstellen><en> This data processing is necessary to be able to display weather information on our website within your browser.
<G-vec00141-002-s195><display.darstellen><de> Diese Datenverarbeitung ist erforderlich, um Wetterinformationen direkt auf unserer Internetseite über Ihren Internet-Browser darstellen zu können.
<G-vec00141-002-s196><display.darstellen><en> With Color Modes you can display and change colors on nodes in your graph to improve readability.
<G-vec00141-002-s196><display.darstellen><de> Mit Farbmodi können Sie Farben auf Nodes in Ihrem Graph darstellen und ändern, um die Übersichtlichkeit zu erhöhen.
<G-vec00141-002-s197><display.darstellen><en> It can only display single variables (no full structures), however, these variables can be a part of structures.
<G-vec00141-002-s197><display.darstellen><de> Sie kann nur einzelne Variablen (keine ganzen Strukturen) darstellen, dennoch können diese Variablen Teil einer Struktur sein.
<G-vec00141-002-s198><display.darstellen><en> The application can display multiple current values in the graphical interface or via the command line a single value directly.
<G-vec00141-002-s198><display.darstellen><de> Die Applikation kann dann in der grafischen Oberfläche mehrere Momentanwerte darstellen oder auf der Befehlszeile immer einen Wert direkt abrufen.
<G-vec00141-002-s199><display.darstellen><en> You may not, other than in accordance with these Terms and Conditions of Use, modify, copy, distribute, transmit, display, redistribute, transfer, or sell in whole or in part, the Website or any of the Intellectual Property Rights relating thereto, without first obtaining written permission from Hunter to do so.
<G-vec00141-002-s199><display.darstellen><de> Sie dürfen ohne die vorherige Einholung einer schriftlichen Genehmigung von Hunter die Webseite oder jegliche hierauf bezogenen geistigen Eigentumsrechte außerhalb dieser Nutzungsbedingungen weder ganz noch teilweise modifizieren, kopieren, vertreiben, übermitteln, darstellen, weiterleiten, transferieren oder verkaufen.
<G-vec00141-002-s200><display.darstellen><en> Thus, it offers an unsurpassed detailed image display, which gives the user more space to display content on the screen at the same size, as well as an image sharpness that is so unbelievable that one simply has to have seen it.
<G-vec00141-002-s200><display.darstellen><de> Somit bietet er eine unübertroffen detaillierte Bilddarstellung, welche dem Nutzer bei gleicher Grösse mehr Platz bietet, um Inhalte auf dem Bildschirm darstellen zu können sowie eine Bildschärfe, die so unglaublich ist, dass man sie einfach gesehen haben muss.
<G-vec00141-002-s201><display.darstellen><en> The display can also graphically display changes in flow over time.
<G-vec00141-002-s201><display.darstellen><de> Die Anzeige kann auch die Änderung des Durchflusses über die Zeit grafisch darstellen.
<G-vec00141-002-s202><display.darstellen><en> This allows you to display the look of your outdoor floor in your pool.
<G-vec00141-002-s202><display.darstellen><de> Sie können somit die Optik Ihres Outdoor-Bodens auch in Ihrem Pool darstellen.
<G-vec00141-002-s203><display.darstellen><en> It describes the average color space a standard monitor is able to display.
<G-vec00141-002-s203><display.darstellen><de> Er beschreibt den durchschnittlichen Farbraum, den ein Standardmonitor darstellen kann.
<G-vec00141-002-s204><display.darstellen><en> I want my dances to display different elements of this divinely inspired culture, so they can live on in the hearts of the audience.
<G-vec00141-002-s204><display.darstellen><de> Mit meinen Tänzen möchte ich unterschiedliche Aspekte dieser göttlich inspirierten Kultur darstellen, damit sie in den Herzen des Publikums weiterleben können.
<G-vec00141-002-s205><display.darstellen><en> Your web browser must have JavaScript enabled in order for this application to display correctly.
<G-vec00141-002-s205><display.darstellen><de> Ihr Webbrowser kann keine Frames darstellen, daher kann diese Seite nicht korrekt angezeigt werden.
<G-vec00141-002-s206><display.darstellen><en> Support Overview This 2-Port VGA Video Splitter allows a computer to display VGA video on two monitors simultaneously.
<G-vec00141-002-s206><display.darstellen><de> Support Überblick Mit dem 2-Port VGA Video-Splitter ST122LEU können Sie das Signal einer einzelnen VGA-Quelle gleichzeitig auf zwei Monitoren darstellen.
<G-vec00141-002-s207><display.darstellen><en> Dentsu looked to build Japan’s first Digital Art Board (DAB), a revolutionary digital signage display designed to be part art exhibit, part advertising tool.
<G-vec00141-002-s207><display.darstellen><de> Dentsu war darauf aus, das erste Digital Art Board (DAB) in Japan zu bauen, ein revolutionäres Digital Signage-Display, das zum Teil ein Kunstobjekt und zum anderen Teil ein Werbemittel darstellen soll.
<G-vec00141-002-s208><display.darstellen><en> This latter mode allows for the measurement and display of SWR graphs over an entire frequency band.
<G-vec00141-002-s208><display.darstellen><de> So lassen sich sehr leicht SWR-Verläufe zum Beispiel über ein ganzes Band ermitteln und darstellen.
<G-vec00141-002-s228><display.darstellen><en> We may use the information for security purposes, to facilitate navigation, to display information more effectively, to personalize your experience while using the AIG Electronic Services, or to gather statistical information about the usage of the AIG Electronic Services.
<G-vec00141-002-s228><display.darstellen><de> Wir verwenden diese Informationen zu Sicherheitszwecken, um die Navigation zu erleichtern, Informationen wirkungsvoller darzustellen, Ihre Nutzung der AIG Elektronischen Dienstleistungen zu personalisieren oder um statistische Informationen über die Nutzung der AIG Elektronischen Dienstleistungen zu erheben.
<G-vec00141-002-s229><display.darstellen><en> Today, large, high-resolution screens are used to accurately display photo and video content. However, mobile presentation remains problematic for partly different reasons.
<G-vec00141-002-s229><display.darstellen><de> Um Foto- und Video-Inhalte in angemessener Weise darzustellen, kommen heutzutage vor allem große, hochauflösende Bildschirme zum Einsatz, die mobile Präsentation hingegen gestaltet sich teilweise aus unterschiedlichen Gründen noch problematisch.
<G-vec00141-002-s230><display.darstellen><en> It's usually enough to display all current games smoothly.
<G-vec00141-002-s230><display.darstellen><de> Sie reicht in der Regel aus, um alle aktuellen Spiele flüssig darzustellen.
<G-vec00141-002-s231><display.darstellen><en> Location data can offer a wealth of insight that is easy to understand and display.
<G-vec00141-002-s231><display.darstellen><de> Standortdaten liefern eine Fülle an Informationen, die einfach zu verstehen und darzustellen sind.
<G-vec00141-002-s232><display.darstellen><en> However, social media platforms are forever changing the image sizes and formats to optimally display your images.
<G-vec00141-002-s232><display.darstellen><de> Doch jedes Netzwerk bietet unterschiedliche Möglichkeiten und Vorgaben für die Bildformate, um Deine Bilder optimal darzustellen.
<G-vec00141-002-s233><display.darstellen><en> Individual monitors – especially in the instrument cluster – can be used to display the rear image of several cameras fused.
<G-vec00141-002-s233><display.darstellen><de> Einzelne Monitore – vor allem im Kombiinstrument – können dazu genutzt werden, das rückwärtige Bild mehrerer Kameras fusioniert darzustellen.
<G-vec00141-002-s234><display.darstellen><en> Without this data it would not be possible for technical reasons to supply and display the website content in all cases.
<G-vec00141-002-s234><display.darstellen><de> Ohne diese Daten wäre es technisch teils nicht möglich, die Inhalte der Webseite auszuliefern und darzustellen.
<G-vec00141-002-s236><display.darstellen><en> The CubeServ Data Explorer provides you with the means to display all data contents in the SAP BW and to detect errors.
<G-vec00141-002-s236><display.darstellen><de> Der CubeServ Data Explorer bietet Ihnen die Möglichkeit sämtliche Dateninhalte im SAP BW darzustellen und Fehler zu erkennen.
<G-vec00141-002-s237><display.darstellen><en> An ordinary 3D solder paste inspection system generates a wire mesh model to display the paste application.
<G-vec00141-002-s237><display.darstellen><de> Ein gewöhnliches 3D Solder Paste Inspection System generiert ein Drahtgittermodell um den Pastenauftrag darzustellen.
<G-vec00141-002-s238><display.darstellen><en> I undertake the duty to publish, display, text, upload, transmit to Cam Girl Pimp the photo/video/audio/text content only in accordance with the law requirements and the terms and conditions applied by Cam Girl Pimp to the photo/video/audio/text content.
<G-vec00141-002-s238><display.darstellen><de> Ich verpflichte mich, Foto-/Video-/Audio-/Textinhalte nur in Übereinstimmung mit den gesetzlichen Erfordernissen und den von CamFuze für diese Inhalte zugrunde gelegten Allgemeinen Geschäftsbedingungen auf CamFuze zu veröffentlichen, darzustellen, zu simsen, hochzuladen oder zu übertragen.
<G-vec00141-002-s239><display.darstellen><en> If you do post content or submit material, and unless we indicate otherwise, you grant DOMINUS CERVIX INTERNATIONAL and its associates a nonexclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such content throughout the world in any media.
<G-vec00141-002-s239><display.darstellen><de> Falls Sie Inhalte posten oder Material einreichen und Pearson VUE keine anderweitige schriftlich unterzeichnete Zustimmung erteilt, gewähren Sie Pearson VUE ein nicht-exklusives, Lizenzgebühr-freies, unbefristetes, unwiderrufbares und vollständig unterlizenzierbares Recht, diese Inhalte weltweit und in allen Medien zu benutzen, zu reproduzieren, zu modifizieren, zu adaptieren, zu veröffentlichen, zu übersetzen, zu verteilen, darzustellen und derivate Werke daraus zu erstellen.
<G-vec00141-002-s240><display.darstellen><en> Google created its original logo in 1998 using a standard font to display the company name.
<G-vec00141-002-s240><display.darstellen><de> Google entwarf sein ursprüngliches Logo 1998 und nutzte eine Standardschrift, um den Unternehmensnamen darzustellen.
<G-vec00141-002-s241><display.darstellen><en> This website uses the API of Google Maps for the display of geographical information.
<G-vec00141-002-s241><display.darstellen><de> Diese Webseite verwendet Google Maps API, um geographische Informationen visuell darzustellen.
<G-vec00141-002-s242><display.darstellen><en> Reflections of the environment remain within limits and the brightness is just sufficient to make the display content visible even in strong sunlight.
<G-vec00141-002-s242><display.darstellen><de> Außerhalb schattiger Bereiche kommt es allerdings immer wieder zu Spiegelungen und die Helligkeit des LG-Smartphones reicht nicht aus, um Displayinhalte lesbar darzustellen.
<G-vec00141-002-s243><display.darstellen><en> Your License to 6thScale: If you do post content or submit material, and unless we indicate otherwise, you grant 6thScale and its affiliates a nonexclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such content throughout the world in any media.
<G-vec00141-002-s243><display.darstellen><de> IHRE LIZENZ Wenn Sie uns Materialien einsenden, räumen Sie – soweit nicht von uns anders angezeigt – Amazon ein nicht ausschließliches, gebührenfreies, unwiderrufliches und vollständig unterlizenzierbares Recht ein, diese weltweit in beliebigen Medien zu verwenden, zu reproduzieren, zu verändern, zu modifizieren, zu veröffentlichen, zu übersetzen und abgeleitete Werke daraus zu erstellen, sie zu verteilen und darzustellen, solange Sie nach dem geltenden Recht zur Erteilung einer entsprechenden Lizenz berechtigt sind.
<G-vec00141-002-s244><display.darstellen><en> With Augmented Reality you have the possibility to easily display even complex work processes in any imaginable environment.
<G-vec00141-002-s244><display.darstellen><de> Mit Augmented Reality haben Sie die Möglichkeit selbst komplexe Arbeitsprozesse in jeder erdenklichen Umgebung einfach darzustellen.
<G-vec00141-002-s245><display.darstellen><en> The embroidery and textile work allows Katrin for her illustrations, the ability to display the images in three dimensions and thus opens up new areas of presentation.
<G-vec00141-002-s245><display.darstellen><de> Die Stickereien und Textilarbeiten ermöglichen Katrin für ihre Illustrationen, die Fähigkeit, die Bilder dreidimensional darzustellen und eröffnet damit neue Präsentationsflächen.
<G-vec00141-002-s246><display.darstellen><en> We have made every effort to display as accurately as possible the colors and images of our products that appear at the store.
<G-vec00141-002-s246><display.darstellen><de> Wir haben uns bemüht, so genau wie möglich die Farben und Bilder unserer Produkte, die in unserem Onlineshop zu sehen sind, darzustellen.
<G-vec00141-002-s323><display.zeigen><en> Screen burn is a permanent defect in areas of a TV display that can be caused by the effects of viewing the same image or scene for long periods of time.
<G-vec00141-002-s323><display.zeigen><de> Ein Einbrenneffekt ist ein permanenter Defekt in bestimmten Bereichen des TVs, der dadurch entstehen kann, dass ein Standbild über lange Dauer gezeigt wird.
<G-vec00141-002-s324><display.zeigen><en> On display was young, free, sometimes wild but always authentic contemporary art.
<G-vec00141-002-s324><display.zeigen><de> Gezeigt wurde junge, freie zeitgenössische Kunst.
<G-vec00141-002-s325><display.zeigen><en> Different facets of the collection are on public display in a converted bunker, with 3000 sqm exhibition space.
<G-vec00141-002-s325><display.zeigen><de> In einem umgebauten Bunker werden auf 3000 qm Ausschnitte der Sammlung in wechselnden Präsentationen der Öffentlichkeit gezeigt.
<G-vec00141-002-s326><display.zeigen><en> A selection of this collection is now on display on the second floor of the Sharjah Art Museum.
<G-vec00141-002-s326><display.zeigen><de> Eine Auswahl aus dieser Sammlung wird jetzt in der ersten Etage des Sharjah Art Museums gezeigt.
<G-vec00141-002-s327><display.zeigen><en> The exported page will be placed in the main frame and the frame beneath will display a table of contents in the form of Hyperlinks.
<G-vec00141-002-s327><display.zeigen><de> Die exportierte Seite wird im Hauptframe angelegt, während in einem Nebenframe ein Inhaltsverzeichnis in Form von Hyperlinks gezeigt wird.
<G-vec00141-002-s328><display.zeigen><en> Transmitted light will be used to display the A3 format photos in all their clarity, while extensive incident light will further enhance the original drawings, emphasising them even more.
<G-vec00141-002-s328><display.zeigen><de> Die Fotos im Format A3 werden mittels Durchlicht in aller Klarheit gezeigt, während die Originalzeichnungen durch flächendeckendes Auflicht noch besser zur Geltung gebracht werden.
<G-vec00141-002-s329><display.zeigen><en> On display are woody plants from the subtropical regions of Australia, the Canary Islands, the Mediterranean basin, and South Africa, in particularly the Cape region.
<G-vec00141-002-s329><display.zeigen><de> Gehölze aus den subtropischen Gebieten Australiens, von Südafrika, insbesondere dem Kapland, den Kanaren und dem Mittelmeerraum werden gezeigt.
<G-vec00141-002-s330><display.zeigen><en> God’s justice and wrath were on display when He sent the flood, and God’s mercy and grace were again demonstrated when He saved Noah and his family.
<G-vec00141-002-s330><display.zeigen><de> Gottes Gerechtigkeit und Zorn wurden gezeigt, als er die große Flut schickte, und Gottes Barmherzigkeit und Gnade wurden wiederum deutlich, als er Noah und seine Familie rettete.
<G-vec00141-002-s331><display.zeigen><en> In the “Collectors’ Gallery” objects on permanent loan from important private Viennese collections are on display – among them the oldest globe extant in Austria, the terrestrial globe of Gemma Frisius (about 1536), a unique object from the collection of Rudolf Technical literature on the study of globes
<G-vec00141-002-s331><display.zeigen><de> Im „Kabinett der Sammlerinnen und Sammler“ werden Dauerleihgaben aus bedeutenden Wiener Privatsammlungen gezeigt – unter anderem der älteste, sich in Österreich befindliche Globus, der Erdglobus von Gemma Frisius (um 1536), ein Unikat aus der Sammlung Rudolf Schmidt, Wien.
<G-vec00141-002-s332><display.zeigen><en> On display are paintings and drawings by Berlin artists Andrea Lein and André Bauersfeld. […]
<G-vec00141-002-s332><display.zeigen><de> Gezeigt werden Gemälde und Zeichnungen der Berliner Künstler Andrea Lein und André Bauersfeld.
<G-vec00141-002-s333><display.zeigen><en> On display is art at the interface between painting and cartography.
<G-vec00141-002-s333><display.zeigen><de> Gezeigt wird Kunst an der Schnittstelle von Malerei und Kartographie.
<G-vec00141-002-s334><display.zeigen><en> On display were objects of the applied arts "... without any embellishing ornamentation", as the Württembergische Arbeitsgemeinschaft put it.
<G-vec00141-002-s334><display.zeigen><de> Gezeigt wurden "nur Gegenstände aus dem Gebiet der angewandten Kunst..., die mit keinerlei Ornament geschmückt sind", wie es die Württembergische Arbeitsgemeinschaft formulierte.
<G-vec00141-002-s335><display.zeigen><en> Where once famous paintings, drawings and engravings were created, these works are now on display with commentary.
<G-vec00141-002-s335><display.zeigen><de> Wo einst berühmte Gemälde, Zeichnungen und Stiche entstanden, werden eben diese Werke gezeigt und erläutert.
<G-vec00141-002-s336><display.zeigen><en> Move mouse on the planning item to display the field with the start and end date of it.
<G-vec00141-002-s336><display.zeigen><de> Wenn Sie mit der Maus auf ein Planungselement darüber fahren, wird ein Feld mit dem Start- und Enddatum zu dem jeweiligen Element gezeigt.
<G-vec00141-002-s337><display.zeigen><en> More than 50 works by the expressionist and 70 works by other artists of importance to modern art will be on display.
<G-vec00141-002-s337><display.zeigen><de> Gezeigt werden über 50 Werke des Expressionisten sowie 70 Arbeiten weiterer für die Moderne bedeutender Künstler.
<G-vec00141-002-s338><display.zeigen><en> Her more famous works and series of photographs are on display alongside earlier and less popular pieces in the current exhibition at the Institute of Contemporary Art in Philadelphia.
<G-vec00141-002-s338><display.zeigen><de> In der aktuellen Ausstellung am Institute of Contemporary Art in Philadelphia werden sowohl bekanntere Werke wie ihre fotografischen Serien, als auch frühere und weniger populäre Stücke gezeigt.
<G-vec00141-002-s339><display.zeigen><en> The results display a continuous fluctuation between purist and less purist solutions, which result in a somewhat disjointed current picture of codified Standard Friulian (spelling, pronunciation, morphology, vocabulary).
<G-vec00141-002-s339><display.zeigen><de> Was sich gezeigt hat, ist ein ständiges Schwanken zwischen puristischen und weniger puristischen Lösungen, was das jetzige Gesamtbild des kodifizierten Standardfriaulischen (Schreibung, Aussprache, Morphologie, Wortschatz) etwas uneinheitlich erscheinen lässt.
<G-vec00141-002-s340><display.zeigen><en> Paintings and reliefs created after designs by Michelangelo will also be on display.
<G-vec00141-002-s340><display.zeigen><de> Zudem werden Gemälde und Reliefs gezeigt, die nach Entwürfen Michelangelos entstanden sind.
<G-vec00141-002-s341><display.zeigen><en> A completely new, forward-thinking series of measuring instruments for flow measurement and the new device portfolio for radar level measurement will also be on display, alongside current digitalization possibilities and process automation services.
<G-vec00141-002-s341><display.zeigen><de> Eine komplett neue, zukunftsorientierte Messgerätelinie der Durchflussmesstechnik und das neue Geräteportfolio zur Füllstandmessung mit Radar werden ebenso gezeigt, wie aktuelle Möglichkeiten rund um Digitalisierung und Dienstleistungen in der Prozessautomatisierung.
<G-vec00141-002-s418><display.zeigen><en> Display only the analytic tools and menus you use routinely.
<G-vec00141-002-s418><display.zeigen><de> Zeigen Sie nur die Analysetools und Menüs an, die Sie gewöhnlich verwenden.
<G-vec00141-002-s419><display.zeigen><en> Our maps display the areas and neighborhoods around all Bascara hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s419><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Vilafreser sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s420><display.zeigen><en> Our maps display the areas and neighborhoods around all Calle Uria hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s420><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Calle San Pedro sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s421><display.zeigen><en> Our maps display the areas and neighborhoods around all Gastonia hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s421><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Charlotte sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s422><display.zeigen><en> Note: Devices already display the participant's name if an NFC card is inserted.
<G-vec00141-002-s422><display.zeigen><de> Hinweis: Geräte zeigen bereits den Namen des Teilnehmers an, wenn eine NFC-Karte eingesteckt ist.
<G-vec00141-002-s423><display.zeigen><en> Line and bar charts are intended to display the evolution of an account or a group of accounts over the time whilst the pie chart simply shows ratios.
<G-vec00141-002-s423><display.zeigen><de> Linien- und Balkendiagramme sind dazu gedacht, die Entwicklung eines Kontos oder einer Gruppe von Konten in einem Zeitraum zu zeigen, während Tortendiagramme einfach nur Anteile sichtbar machen.
<G-vec00141-002-s424><display.zeigen><en> Purpose The collected information can be used to identify you as a user and to display adverts, that would highly likely be relevant for you, to register your purchases and payments, as well as, to deliver the services you have requested, like e.g.
<G-vec00141-002-s424><display.zeigen><de> Zweck Die Daten können dazu verwendet werden, Sie als Nutzer zu identifizieren, Ihnen personalisierte Anzeigen zu zeigen, Ihre Käufe und Zahlungen zu registrieren und Ihnen die Leistungen zu liefern, die Sie nachgefragt haben, z.
<G-vec00141-002-s425><display.zeigen><en> Our maps display the areas and neighborhoods around all Puig Campana hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s425><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Puig Campana sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s426><display.zeigen><en> Our maps display the areas and neighborhoods around all Vilafranca del Penedes hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s426><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Vilafranca del Penedès sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s427><display.zeigen><en> Display the recorded information in Google Maps™ when you playback the video on the Mio Player.
<G-vec00141-002-s427><display.zeigen><de> Zeigen Sie bei der Video-Wiedergabe auf dem Mio Player die aufgezeichneten Informationen in Google Maps™ an.
<G-vec00141-002-s428><display.zeigen><en> Some voltage meters misunderstand this and display a wrong voltage.
<G-vec00141-002-s428><display.zeigen><de> Einige Voltmeter missverstehen das und zeigen eine falsche Spannung an.
<G-vec00141-002-s429><display.zeigen><en> If possible, display the picture of the bishop or branch president as a boy, but do not tell the children who he is.
<G-vec00141-002-s429><display.zeigen><de> Zeigen Sie möglichst ein Kinderbild vom Bischof oder Zweigpräsidenten, verraten Sie den Kindern aber nicht, wer es ist.
<G-vec00141-002-s430><display.zeigen><en> Conduct a search and display the search results.
<G-vec00141-002-s430><display.zeigen><de> Führen Sie eine Suche aus, und zeigen Sie die Suchergebnisse an.
<G-vec00141-002-s431><display.zeigen><en> Seattle also has many commercial art galleries where upcoming artists display their work to the public.
<G-vec00141-002-s431><display.zeigen><de> Seattle hat auch viele Kunstgalerien, wo aufstrebende Künstler zeigen ihre Arbeiten der Öffentlichkeit.
<G-vec00141-002-s432><display.zeigen><en> Our maps display the areas and neighborhoods around all Es Castell hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s432><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Es Castell sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s433><display.zeigen><en> Our maps display the areas and neighborhoods around all Kassari hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s433><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels in Kassari (Dorf) an, damit Sie gleich sehen, wie weit Sie von Wahrzeichen und Attraktionen entfernt sind, und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s434><display.zeigen><en> Key Chain A fantastic addition to your keys or bag which allows you to proudly display the new Highland Titles buckler
<G-vec00141-002-s434><display.zeigen><de> Der Highland Titles Schlüsselanhänger ist eine tolle Ergänzung zu Ihrem Schlüssel oder Tasche, mit der Möglichkeit stolz das neue Highland Titles Logo zu zeigen.
<G-vec00141-002-s435><display.zeigen><en> Our maps display the areas and neighborhoods around all Pascagoula hotels so you can see how close you are from landmarks and attractions, and then refine your search within the larger area.
<G-vec00141-002-s435><display.zeigen><de> Unsere Karten zeigen die Umgebung jedes Hotels an, damit Sie gleich sehen, wie nah Sie an Pascagoula sind und Ihre Suche im größeren Umkreis eingrenzen können.
<G-vec00141-002-s436><display.zeigen><en> When you hand the parcel in at one of DPD's 6,000 Pickup parcelshops you simply display the mobile parcel label on your smartphone or Apple Watch and we take care of the rest.
<G-vec00141-002-s436><display.zeigen><de> Zeigen Sie einfach im Pickup Paketshop den mobilen Paketschein auf Ihrem Smartphone oder der Apple Watch vor und wir erledigen den Rest für Sie.
<G-vec00141-002-s437><display.zeigen><en> The ring around the activity display advances according to how many active calories you burn during the day compared to your goal. Table of Content
<G-vec00141-002-s437><display.zeigen><de> Der Ring rund um Ihr Aktivitätsdisplay schließt sich im Laufe des Tages immer weiter und zeigt dadurch an, wie viele aktive Kalorien Sie im Verhältnis zu Ihrem Ziel verbrannt haben.
<G-vec00141-002-s438><display.zeigen><en> If you already have your own app, FidMe display a smart link to either propose your customer to download it (get new app users) or launch it if already installed (get more uses).
<G-vec00141-002-s438><display.zeigen><de> Wenn Sie bereits über eine eigene App verfügen zeigt FidMe einen Smart-Link, die Ihren Benutzern die Möglichkeit bietet Ihre App herunterzuladen (neue App Benutzer) oder die bereits installierte App zu starten.
<G-vec00141-002-s439><display.zeigen><en> However, the total account balance amount will be synced instantaneously and Money Pro will display your current balance.
<G-vec00141-002-s439><display.zeigen><de> Der gesamte Kontostand wird jedoch sofort synchronisiert und Money Pro zeigt Ihren aktuellen Kontostand an.
<G-vec00141-002-s440><display.zeigen><en> -um server option The -um option allows you to connect to the DBLauncher.app instance, if it is running, and display database server messages in a new window within DBLauncher.app.
<G-vec00141-002-s440><display.zeigen><de> Serveroption -um Die Option -um ermöglicht eine Verbindung mit der DBLauncher.app-Instanz, wenn diese läuft, und zeigt Datenbankservermeldungen in einem neuen Fenster in DBLauncher.app an.
<G-vec00141-002-s441><display.zeigen><en> normal: Display one line per interface.
<G-vec00141-002-s441><display.zeigen><de> normal: Zeigt eine Zeile per Schnittstelle an.
<G-vec00141-002-s442><display.zeigen><en> Google will display rich snippet stars only for sites that contain a maximum of one type.
<G-vec00141-002-s442><display.zeigen><de> Google zeigt rich snippet stars nur für Webseiten an, die maximal einen Typ enthalten.
<G-vec00141-002-s443><display.zeigen><en> When you log in, this page will display your favorite plugins.
<G-vec00141-002-s443><display.zeigen><de> Wenn du dich anmeldest, zeigt dir diese Seite deine favorisierten Plugins.
<G-vec00141-002-s444><display.zeigen><en> The built-in LCD display allows you to control the input and display the printed image.
<G-vec00141-002-s444><display.zeigen><de> Das eingebaute LCD Display ermöglicht die Kontrolle der Eingaben und zeigt das Druckbild an.
<G-vec00141-002-s445><display.zeigen><en> The staggering ground floor display houses collection from the surface of the Acropolis.
<G-vec00141-002-s445><display.zeigen><de> Das atemberaubende Erdgeschoss zeigt Häuser von der Oberfläche der Akropolis.
<G-vec00141-002-s446><display.zeigen><en> Display speed, elevation, G-force, heart rate and more on your video to reveal the true effort and thrill of each moment.
<G-vec00141-002-s446><display.zeigen><de> Zeigt Geschwindigkeit, Höhe, G-Kraft, Herzfrequenz und mehr im Video um die wirkliche Anstrengung und Spannung einzufangen.
<G-vec00141-002-s447><display.zeigen><en> If you start from Windows using Boot Camp, your Mac doesn't display an Apple logo or the other screens in this article.
<G-vec00141-002-s447><display.zeigen><de> Wenn Sie Windows mit Boot Camp starten, zeigt Ihr Mac weder das Apple-Logo noch die anderen Bildschirme in diesem Artikel an.
<G-vec00141-002-s448><display.zeigen><en> The button display a number showing how many updates are available.
<G-vec00141-002-s448><display.zeigen><de> Der Button zeigt eine Zahl, die anzeigt, wie viele Updates es gibt.
<G-vec00141-002-s449><display.zeigen><en> After signing in with your Adobe ID, the cloud icon (at the upper-right corner) shows a moving blue spinner over it, but the grid remains blank and doesn't load or display any photos.
<G-vec00141-002-s449><display.zeigen><de> Nachdem Sie sich mit Ihrer Adobe ID angemeldet haben, zeigt das Cloud-Symbol (in der oberen rechten Ecke) einen sich bewegenden blauen Kreisel darüber, aber das Raster bleibt leer und lädt oder zeigt keine Fotos an.
<G-vec00141-002-s450><display.zeigen><en> As with option 1, these steps start the Debian boot loader which will display a menu page for you to select a boot kernel and options.
<G-vec00141-002-s450><display.zeigen><de> Wie bei der ersten Option startet der Debian-Bootloader und zeigt eine Menüseite an, um einen Boot-Kernel und zusätzliche Optionen zur Auswahl anzubieten.
<G-vec00141-002-s452><display.zeigen><en> Each camera that successfully arms will display a blue motion icon .
<G-vec00141-002-s452><display.zeigen><de> Jede Kamera, die erfolgreich aktiviert wird, zeigt ein blaues Bewegungssymbol an.
<G-vec00141-002-s453><display.zeigen><en> lifetime artist, Grayson’s affinity for both antique prints and modern graphic design is on display in this book cover.
<G-vec00141-002-s453><display.zeigen><de> Graysons Affinität zu antiken Drucken und modernem Grafikdesign zeigt sich in diesem Einband.
<G-vec00141-002-s454><display.zeigen><en> Except in special circumstances, Google won't display content that is not visible to the user.
<G-vec00141-002-s454><display.zeigen><de> Google zeigt Inhalte, die für Nutzer nicht sichtbar sind, nur in Ausnahmefällen an.
<G-vec00141-002-s455><display.zeigen><en> Display the specified page, with its contents magnified just enough to fit the rectangle specified by the coordinates left, bottom, right, and top entirely within the window both horizontally and vertically.
<G-vec00141-002-s455><display.zeigen><de> Zeigt die spezifizierte Seite an, wobei der Inhalt gerade genug vergrößert ist damit er komplett in das Rechteck passt das durch die Koordinaten links, unten, rechts und oben spezifiziert wird sowohl horizontal als auch vertikal.
