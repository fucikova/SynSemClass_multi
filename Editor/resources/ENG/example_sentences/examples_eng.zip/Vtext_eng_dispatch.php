<G-vec00209-002-s198><dispatch.melden><en> The delivery terms shall start on the day of sending the acknowledgement of order and will be complied with if the object of purchase left our works by the end of the delivery term or the readiness for dispatch was announced.
<G-vec00209-002-s198><dispatch.melden><de> Beginnt mit dem Tag der Absendung der Auftragsbestätigung und ist eingehalten, wenn bis Ende der Lieferfrist die Ware das Werk/Lager verlassen hat oder die Versandbereitschaft der Ware gemeldet ist.
<G-vec00209-002-s199><dispatch.melden><en> If the grace period set by the Buyer expires without notification that the Goods are ready for dispatch, the Buyer is only entitled to withdraw from the contract or to terminate the contract in any other way if the Buyer has threatened such consequences of an unsuccessful expiry of the deadline simultaneously with the setting of the deadline.
<G-vec00209-002-s199><dispatch.melden><de> Ist nach Ablauf der von dem Besteller gesetzten Frist die Ware nicht versandbereit gemeldet, so ist der Besteller zum Rücktritt vom Vertrag oder zur Beendigung des Vertrages in sonstiger Weise berechtigt, wenn er diese Konsequenz des fruchtlosen Fristablaufs zusammen mit der Fristsetzung schriftlich angedroht hat.
<G-vec00209-002-s200><dispatch.melden><en> After expiry of this extension, the buyer can withdraw from the contract if he has not by this time received word that the good(s) are ready for dispatch.
<G-vec00209-002-s200><dispatch.melden><de> Nach Ablauf dieser Nachfrist kann er vom Vertrag zurücktreten, wenn die Ware ihm bis zu diesem Zeitpunkt nicht als versandbereit gemeldet wurde.
<G-vec00209-002-s201><dispatch.melden><en> 4.3 The delivery period is complied with if the delivery item has left the Supplier's factory or notification of readiness to dispatch has been given prior to expiry of the delivery period.
<G-vec00209-002-s201><dispatch.melden><de> 4.3 Die Lieferzeit ist eingehalten, wenn der Liefergegenstand bis zu ihrem Ablauf das Werk des Lieferers verlassen hat oder die Versandbereitschaft gemeldet ist.
<G-vec00209-002-s202><dispatch.melden><en> 4.2 The delivery term is deemed complied with, when the delivery has left our works by expiry or the readiness for dispatch has been issued.
<G-vec00209-002-s202><dispatch.melden><de> Die Lieferzeit ist eingehalten, wenn der Liefergegenstand bis zu ihrem Ablauf unser Werk verlassen hat oder die Versandbereitschaft gemeldet ist.
<G-vec00209-002-s203><dispatch.melden><en> The term of delivery is also deemed to have been adhered to, if the containers left our depot at the stipulated time or the readiness to dispatch has been communicated to the buyer, but the containers were, at no fault of our own, unable to be dispatched on time.
<G-vec00209-002-s203><dispatch.melden><de> Die Lieferfrist gilt auch als eingehalten, wenn die Container zum vereinbarten Zeitpunkt unser Depot verlassen oder die Versandbereitschaft dem Käufer gemeldet ist, die Container aber ohne unser Verschulden nicht rechtzeitig abgesandt werden können.
<G-vec00209-002-s235><dispatch.mitteilen><en> The delivery period shall be deemed to have been observed if the delivery item has left our factory or readiness for dispatch has been reported by the end of the delivery period.
<G-vec00209-002-s235><dispatch.mitteilen><de> (2) Die Lieferfrist ist eingehalten, wenn bis zu ihrem Ablauf der Liefergegenstand das Werk verlassen hat oder die Versandbereitschaft mitgeteilt ist.
<G-vec00209-002-s236><dispatch.mitteilen><en> The delivery period shall be deemed to have been observed if the delivery item has left our factory or readiness for dispatch has been reported by the end of the delivery period.
<G-vec00209-002-s236><dispatch.mitteilen><de> Die Lieferfrist ist eingehalten, wenn bis zu ihrem Ablauf der Liefergegenstand das Lieferwerk verlassen hat oder die Versandbereitschaft mitgeteilt ist.
<G-vec00209-002-s237><dispatch.mitteilen><en> The agreed delivery period is deemed as met if the contract item has left the plant, or readiness for dispatch has been advertised.
<G-vec00209-002-s237><dispatch.mitteilen><de> Die vereinbarte Lieferzeit ist eingehalten, wenn bis zu ihrem Ablauf der Vertragsgegenstand das Werk verlassen hat oder die Versandbereitschaft mitgeteilt worden ist.
<G-vec00209-002-s238><dispatch.mitteilen><en> If the customer picks up the goods, risk will pass to the customer upon announcement of readiness for dispatch already.
<G-vec00209-002-s238><dispatch.mitteilen><de> Die Gefahr geht zu dem Zeitpunkt auf den Besteller über, wenn die Ware unsere Räume verlässt oder dem Besteller Versandbereitschaft mitgeteilt wurde.
<G-vec00209-002-s239><dispatch.mitteilen><en> A delivery deadline is deemed have been met, if, prior to said deadline, the goods have left Betz-Tools or Betz-Tools has reported readiness for dispatch.
<G-vec00209-002-s239><dispatch.mitteilen><de> Die Lieferfrist ist eingehalten, wenn die Ware das Werk verlassen hat oder die Versandbereitschaft mitgeteilt ist.
<G-vec00209-002-s240><dispatch.mitteilen><en> The delivery dates and periods shall be deemed to have been met where, by expiry of this period, the goods have left the works and were delivered to the forwarding company or where a notice of readiness for dispatch has been given.
<G-vec00209-002-s240><dispatch.mitteilen><de> Liefertermine und Lieferfristen sind eingehalten, wenn bis zu ihrem Ablauf die Ware das Lager verlassen hat und an das Transportunternehmen übergeben wurde oder die Versandbereitschaft mitgeteilt ist.
<G-vec00209-002-s252><dispatch.schicken><en> The Seller could dispatch an engineer against the requests of the Buyer to install and adjust the machines for one week(free of charge) in the Buyer's factory.
<G-vec00209-002-s252><dispatch.schicken><de> INSTALLATION U. EINSTELLUNG Der Verkäufer könnte einen Ingenieur gegen die Anträge des Kunden schicken, die Maschinen auf eine Woche (kostenlos) in der Fabrik des Kunden zu installieren und einzustellen.
<G-vec00209-002-s253><dispatch.schicken><en> You’re also welcome to dispatch a carrier pigeon, although we can’t guarantee that it will arrive.
<G-vec00209-002-s253><dispatch.schicken><de> Gerne dürfen Sie auch eine Brieftaube schicken – da können wir aber nicht garantieren, ob das klappt.
<G-vec00209-002-s254><dispatch.schicken><en> Gladly we dispatch the detailed quality criteria of our houses to you.
<G-vec00209-002-s254><dispatch.schicken><de> Gerne schicken wir Ihnen die ausführlichen Qualitätsmerkmale von unseren Häusern zu.
<G-vec00209-002-s255><dispatch.schicken><en> I reached for my cell phone and called 911 to dispatch the ambulance.
<G-vec00209-002-s255><dispatch.schicken><de> Ich reichte nach meinem Handy und rief 911, daß sie eine Ambulanz schicken sollten.
<G-vec00209-002-s256><dispatch.schicken><en> We dispatch technician to customer's factory for installation and preoperation of machines.
<G-vec00209-002-s256><dispatch.schicken><de> Wir schicken den Techniker zum Werk des Kunden, um die Maschinen zu installieren und in Betrieb zu nehmen.
<G-vec00209-002-s466><dispatch.verschicken><en> If you submit your order by 12 pm on weekdays, we will strive to dispatch the order to you on the same day.
<G-vec00209-002-s466><dispatch.verschicken><de> Wenn Sie Ihre Bestellung an Werktagen vor 12:00 Uhr aufgeben, bemühen wir uns, die Bestellung noch am selben Tag zu verschicken.
<G-vec00209-002-s467><dispatch.verschicken><en> You must pay for products before we dispatch them.
<G-vec00209-002-s467><dispatch.verschicken><de> Für Waren müssen Sie die Produkte bezahlen, bevor wir sie verschicken.
<G-vec00209-002-s468><dispatch.verschicken><en> With immediate effect, the local logistics section is expected to organise the flow of goods globally, and dispatch many different, small product units at high speed.
<G-vec00209-002-s468><dispatch.verschicken><de> Ab sofort soll die hiesige Logistik den Warenfluss weltweit organisieren, und viele unterschiedliche, kleinteilige Produkteinheiten in hoher Geschwindigkeit verschicken.
<G-vec00209-002-s469><dispatch.verschicken><en> 1.15 After receiving payment we dispatch the goods directly.
<G-vec00209-002-s469><dispatch.verschicken><de> 1.15 Nach Geldeingang verschicken wir die Ware direkt.
<G-vec00209-002-s470><dispatch.verschicken><en> Unless stipulated otherwise, we opt for the cheapest mode of transportation and dispatch the goods by post, parcel service or forwarding agent.
<G-vec00209-002-s470><dispatch.verschicken><de> Sofern nicht anders vereinbart, wählen wir die günstigste Versandart und verschicken die Ware per Post, Paketdienst oder Spedition.
<G-vec00209-002-s471><dispatch.verschicken><en> Congratulations! We will dispatch the prizes as soon as possible, so that you'll hopefully receive them until Christmas.
<G-vec00209-002-s471><dispatch.verschicken><de> Wir werden die Gewinne nun schnellstmöglich an Euch verschicken, so dass Ihr sie hoffentlich noch rechtzeitig zu Weihnachten habt.
<G-vec00209-002-s472><dispatch.verschicken><en> Cheap to make and economical in terms of space – the finished products are easy to transport and dispatch – and owing their position at the interface between film and visual art, they facilitate a greater exposure than traditional media, as both film festivals and art events also provide a forum for presentation.
<G-vec00209-002-s472><dispatch.verschicken><de> Günstig in der Anschaffung und wenig platzaufwendig – die fertigen Arbeiten sind leicht zu transportieren und zu verschicken – ermöglichen sie durch ihre Position an der Schnittstelle zwischen Film und visueller Kunst eine größere Exponiertheit als traditionelle Medien, indem sich sowohl Filmfestivals als auch Kunstevents als Präsentationsfläche anbieten.
<G-vec00209-002-s473><dispatch.verschicken><en> Several times a year we dispatch a newsletter: you get everything at a glance and all events at the WSC in clear statements.
<G-vec00209-002-s473><dispatch.verschicken><de> Mehrmals im Jahr verschicken wir einen Newsletter, in dem Sie alles auf einen Blick haben: Ereignisse, die am WSC stattgefunden haben, werden übersichtlich dargestellt.
<G-vec00209-002-s493><dispatch.versenden><en> Unless otherwise agreed, the Translator shall dispatch the Translation in such a way that the Client can reasonably expect to receive it not later than the normal close of business at the Client’s premises on the date of delivery.
<G-vec00209-002-s493><dispatch.versenden><de> Sofern nicht anders vereinbart, versendet die Übersetzerin die Übersetzung so, dass der Auftraggeber vernünftigerweise davon ausgehen kann, sie spätestens bis zum Ende des Geschäftstages des Lieferdatums am Standort des Auftraggebers zu erhalten.
<G-vec00209-002-s494><dispatch.versenden><en> It was Julian who personally welcomed us and presented how to keep, feed and dispatch animals professionally.
<G-vec00209-002-s494><dispatch.versenden><de> Julian nahm uns persönlich in Empfang und präsentierte, wie professionell die Tiere gehalten, versorgt und versendet werden.
<G-vec00209-002-s495><dispatch.versenden><en> Because the base is delivered in two parcels, it is possible to dispatch it by parcel service providers.
<G-vec00209-002-s495><dispatch.versenden><de> Da der Sockel in zwei Paketsendungen geliefert wird, kann er per Paketdienstleister versendet werden.
<G-vec00209-002-s496><dispatch.versenden><en> When listing your products, select “I want Amazon to dispatch and provide customer service for my items if they sell” in the section “delivery method” in the Offer tab.
<G-vec00209-002-s496><dispatch.versenden><de> Wählen Sie beim Listen Ihrer Produkte auf der Registerkarte „Angebot“ im Abschnitt „Versandart“ die Option „Ich möchte, dass Amazon meine verkauften Artikel versendet und den Kundenservice leistet“ aus.
<G-vec00209-002-s497><dispatch.versenden><en> For security reasons we do not dispatch passwords in clear text format by email.
<G-vec00209-002-s497><dispatch.versenden><de> Von uns werden aus Sicherheitsgründen keine Passwörter im Klartext per E-Mail versendet.
<G-vec00209-002-s498><dispatch.versenden><en> Order today and enjoy same-day dispatch on weekdays.
<G-vec00209-002-s498><dispatch.versenden><de> Bestellen Sie noch heute und an Werktagen wird noch am selben Tag versendet.
