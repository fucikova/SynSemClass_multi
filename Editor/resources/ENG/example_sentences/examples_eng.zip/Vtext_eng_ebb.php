<G-vec00028-002-s086><ebb.zurückgehen><en> Time to flow, ebb and weave as ONE.
<G-vec00028-002-s086><ebb.zurückgehen><de> Zeit zu fließen, zurückzugehen und sich als EINS zu verweben.
