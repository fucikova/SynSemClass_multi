<G-vec00121-002-s359><battle.führen><en> The king of Israel disguised himself, and went into the battle.
<G-vec00121-002-s359><battle.führen><de> Der König Israels aber verstellete sich auch und zog in den Streit.
<G-vec00121-002-s360><battle.führen><en> 89:43 You have also turned the edge of his sword, and have not made him to stand in the battle.
<G-vec00121-002-s360><battle.führen><de> 89:43 Auch hast du die Kraft seines Schwertes weggenommen und lässest ihn nicht siegen im Streit.
<G-vec00121-002-s361><battle.führen><en> Then the men of David sware unto him, saying, Thou shalt go no more out with us to battle, that thou quench not the lamp of Israel.
<G-vec00121-002-s361><battle.führen><de> Da schwuren ihm die Männer Davids und sprachen: Du sollst nicht mehr mit uns ausziehen in den Streit, daß nicht die Leuchte in Israel verlösche.
<G-vec00121-002-s362><battle.führen><en> When he went to do battle, the LORD handed over to him King Cushan-Rishathaim of Aram and he overpowered him.
<G-vec00121-002-s362><battle.führen><de> Und der Geist des HERRN kam auf ihn, und er ward Richter in Israel und zog aus zum Streit.
<G-vec00121-002-s363><battle.führen><en> 1Now the Philistines gathered together their armies to battle; and they were gathered together at Socoh, which belongeth to Judah, and encamped between Socoh and Azekah, in Ephes-dammim.
<G-vec00121-002-s363><battle.führen><de> 1Und die Philister sammelten ihre Heere zum Streit und versammelten sich zu Soko, das Juda gehört, und lagerten sich bei Ephes-Dammim, zwischen Soko und Aseka.
<G-vec00121-002-s364><battle.führen><en> 22Also when all the men of Israel who had hidden themselves in the hill country of Ephraim heard that the Philistines had fled, they also chased after them in the battle.
<G-vec00121-002-s364><battle.führen><de> 22Und alle Männer von Israel, die sich im Gebirge Ephraim versteckt hatten, hörten, daß die Philister geflohen waren; und auch sie setzten ihnen nach im Streit.
<G-vec00121-002-s365><battle.führen><en> 43You have also turned back the edge of his sword, and you have not made him stand in battle.
<G-vec00121-002-s365><battle.führen><de> 43Auch hast du die Kraft seines Schwertes weggenommen und lässest ihn nicht siegen im Streit.
<G-vec00121-002-s366><battle.führen><en> Now Israel went out against the Philistines to battle, and pitched beside Ebenezer: and the Philistines pitched in Aphek.
<G-vec00121-002-s366><battle.führen><de> Da zog Israel aus, den Philistern entgegen, in den Streit und lagerte sich bei Eben-Eser; die Philister aber hatten sich zu Aphek gelagert.
<G-vec00121-002-s367><battle.führen><en> I am familiar with your pride and deceit!39 You have come down here to watch the battle!”
<G-vec00121-002-s367><battle.führen><de> Ich kenne deine Vermessenheit wohl und die Bosheit deines Herzens; denn um den Streit zu sehen, bist du herabgekommen.
<G-vec00121-002-s368><battle.führen><en> The battle grew fierce during the day, and the king, who was propped up in his chariot facing the Arameans, died in the evening.
<G-vec00121-002-s368><battle.führen><de> Und der Streit nahm überhand desselben Tages, und der König stand auf dem Wagen der Syrer und starb des Abends.
<G-vec00121-002-s369><battle.führen><en> Download Bible: Num 31:21-23 31:21 Then Eleazar the priest said to the men of war who had gone into the battle, “This is the ordinance of the law that the Lord commanded Moses: 31:22 ‘Only the gold, the silver, the bronze, the iron, the tin, and the lead, 31:23 everything that may stand the fire, you are to pass through the fire, 1 and it will be ceremonially clean, but it must still be purified with the water of purification.
<G-vec00121-002-s369><battle.führen><de> 21Und Eleasar, der Priester, sprach zu den Kriegsleuten, die in den Streit gezogen waren: Dies ist die Satzung des Gesetzes, das Jehova dem Mose geboten hat: 22Nur das Gold und das Silber, das Erz, das Eisen, das Zinn und das Blei, 23alles, was das Feuer verträgt, sollt ihr durchs Feuer gehen lassen, und es wird rein sein; nur soll es mit dem Wasser der Reinigung entsündigt werden; und alles, was das Feuer nicht verträgt, sollt ihr durchs Wasser gehen lassen.
<G-vec00121-002-s371><battle.führen><en> 17And the battle was very sore that day; and Abner was beaten, and the men of Israel, before the servants of David.
<G-vec00121-002-s371><battle.führen><de> 17Und der Streit wurde überaus heftig an jenem Tage; und Abner und die Männer von Israel wurden vor den Knechten Davids geschlagen.
<G-vec00121-002-s372><battle.führen><en> We have no might with which to meet “this great host that comes out against us,” but Jehovah, Might in Battle, is our Savior, our Intercessor, our Elder Brother, our everpresent Friend.
<G-vec00121-002-s372><battle.führen><de> Wir haben nicht in uns die Kraft dieser Wirte des Bösen zu stellen, aber der Herr, mächtig im Streit, ist unser Erlöser, unser Fürsprecher, unser Bruder, unser treuer Freund, der uns ständig begleitet.
<G-vec00121-002-s373><battle.führen><en> And the king of Israel said unto Jehoshaphat, I will disguise myself, and go into the battle; but put thou on thy robes.
<G-vec00121-002-s373><battle.führen><de> Und der König Israels sprach zu Josaphat: Ich will mich verstellen und in den Streit kommen; du aber habe deine Kleider an.
<G-vec00121-002-s374><battle.führen><en> 5You have not gone up into the breaches, or built up a wall for the house of Israel, that it might stand in battle in the day of the LORD.
<G-vec00121-002-s374><battle.führen><de> 5In die Risse seid ihr nicht getreten, und die Mauer habt ihr nicht vermauert um das Haus Israel her, um standzuhalten im Streit am Tage Jehovas.
<G-vec00121-002-s375><battle.führen><en> < 28:6 and a spirit of justice to him that sitteth in judgment, and strength to them that turn back the battle at the gate.
<G-vec00121-002-s375><battle.führen><de> 28:6 und zum Geiste des Rechts dem, der zu Gericht sitzt; und zur Heldenkraft denen, welche den Streit zurückdrängen ans Tor.
<G-vec00121-002-s376><battle.führen><en> Joab and Abishai his brother had been lying in wait for Abner because he killed Asahel their brother in battle at Gibeon.
<G-vec00121-002-s376><battle.führen><de> Also erwürgten Joab und Abisai Abner, darum daß er ihren Bruder Asahel getötet hatte im Streit zu Gibeon.
<G-vec00121-002-s377><battle.führen><en> 8. For the battle was there scattered over the face of all the country: and the forest devoured more people that day than the sword devoured.
<G-vec00121-002-s377><battle.führen><de> 18:8 Und war daselbst der Streit zerstreut auf allem Lande; und der Wald fraß viel mehr Volk des Tages, denn das Schwert fraß.
<G-vec00121-002-s264><battle.kämpfen><en> So it is noteworthy that, as the US-led invasion of Iraq--and with it, America's clash with the Islamic world--grows more heated, Russia's battle with Muslim Chechens may be waning into something like peace.
<G-vec00121-002-s264><battle.kämpfen><de> Es ist daher beachtenswert, dass, zur Zeit der Invasion in den Irak unter Führung der USA und während Amerikas Zusammenstoß mit der islamischen Welt dadurch an Hitze gewinnt, Russlands Kämpfe mit den mohammedanischen Tschetschenen zu etwas wie einem Frieden abflauen könnten.
<G-vec00121-002-s265><battle.kämpfen><en> The oldest mention on the target from 972 commemorates the arrival of the first German immigrants, and the latest from 1841 records the dedication of the memorial for loyalty and commitment, Treue und Beharrlichkeit, which the city exhibited during the battle in 1809.
<G-vec00121-002-s265><battle.kämpfen><de> Die älteste Erwähnung auf der Scheibe bindet sich an das Jahr 972 und erinnert an die Ankunft der ersten deutschen Immigranten, die jüngste bindet sich an das Jahr 1841, als im Rathaussaal ein Denkmal der Treue und Beharrlichkeit, die die Stadt während der Kämpfe im Jahre 1809 erwiesen habe, enthüllt wurde.
<G-vec00121-002-s266><battle.kämpfen><en> Battle with more than 35 different enemies, including sneaky penguins, exploding foxes and ninja squirrels.
<G-vec00121-002-s266><battle.kämpfen><de> Kämpfe gegen über 35 verschiedene Gegner, darunter hinterlistige Pinguine, explodierende Füchse und Ninja-Eichhörnchen.
<G-vec00121-002-s267><battle.kämpfen><en> Upgrade your skills and weapons and battle your way through many levels.
<G-vec00121-002-s267><battle.kämpfen><de> Dann fange gleich damit an und kämpfe dich durch viele Level.
<G-vec00121-002-s268><battle.kämpfen><en> Hack computer terminals: Enter a virtual world to escape mazes, battle in arenas, and race to find the code.
<G-vec00121-002-s268><battle.kämpfen><de> • Hacke Computerterminals – Betritt eine virtuelle Welt, um aus Labyrinthen zu entkommen, kämpfe in Arenen, und finde so schnell wie möglich den Code.
<G-vec00121-002-s269><battle.kämpfen><en> Fittingly, the Galactic Republic and Separatist Alliance enter Star Wars: Legion with two of the most recognisable leaders in the galaxy leading their troops into battle.
<G-vec00121-002-s269><battle.kämpfen><de> Passenderweise führen zwei der bekanntesten Anführer der Galaxis die Galaktische Republik und die Separatisten-Allianz in die Kämpfe von Star Wars: Legion.
<G-vec00121-002-s270><battle.kämpfen><en> Battle fearsome foes alongside your partner, Malroth – Accompanying you on your quest is the mysterious Malroth, an aggressive amnesiac with a fondness for fighting foes.
<G-vec00121-002-s270><battle.kämpfen><de> Kämpfe an der Seite deines Freundes Malroth – Deine Begleitung auf deiner Mission ist der mysteriöse Malroth, grober Gedächtnisloser mit einer Vorliebe fürs Verprügeln von Feinden.
<G-vec00121-002-s271><battle.kämpfen><en> Other goodies available only in the Resident Evil 5: Gold Edition include two costume packs and the famous Resident Evil 5 Versus Mode, where you and up to three of your friends can battle hideous creatures or each other via PlayStation Network.
<G-vec00121-002-s271><battle.kämpfen><de> Resident Evil 5: Gold Edition wartet außerdem mit zwei Kostümpaketen und dem legendären Versus-Modus für Resident Evil 5 auf, in dem du dich mit bis zu drei Freunden irrwitzigen Geschöpfen entgegenstellen oder Kämpfe über das PlayStation Network austragen kannst.
<G-vec00121-002-s272><battle.kämpfen><en> Battle for world domination.
<G-vec00121-002-s272><battle.kämpfen><de> Kämpfe um die Weltherrschaft.
<G-vec00121-002-s273><battle.kämpfen><en> At the site of the 1864 battle there is a modern centre which explains the historical background for the battle.
<G-vec00121-002-s273><battle.kämpfen><de> Am Ort der Schlacht von 1864 erklärt ein modernes Zentrum die geschichtlichen Hintergründe der Kämpfe.
<G-vec00121-002-s274><battle.kämpfen><en> All versus all battle: search for weapons, find a safe zone, plunder your enemies... survive until the end.
<G-vec00121-002-s274><battle.kämpfen><de> Kämpfe gegen alle: suche nach Waffen, finde einen sicheren Bereich, plündere deine Feinde... überlebe, bis du der Letzte bist, der noch lebt.
<G-vec00121-002-s275><battle.kämpfen><en> Collect an unbeatable team of heroes and engage in a battle with strong monsters that want to conquer your world.
<G-vec00121-002-s275><battle.kämpfen><de> Sammle ein unschlagbares Team von Helden und kämpfe mit starken Monstern, die deine Welt erobern wollen.
<G-vec00121-002-s276><battle.kämpfen><en> Battle by tapping – Pokémon Quest uses simple touch controls that can be enjoyed by everyone
<G-vec00121-002-s276><battle.kämpfen><de> Kämpfe durch Berühren: Pokémon Quest bietet eine einfache Berührungssteuerung, die jeder meistern kann.
<G-vec00121-002-s277><battle.kämpfen><en> Eclipse, DLC 2 Map Pack for Call of Duty®: Black Ops III Eclipse is available on PS4® and Xbox One®. Battle through four new multiplayer maps that take full advantage of the Black Ops III movement system, including a martial arts tournament arena, a post-Apocalyptic tribal compound, a future civilian sub-orbital airport, and a military rail system suspended high above an active volcano.
<G-vec00121-002-s277><battle.kämpfen><de> Kämpfen Sie sich über vier neue Multiplayer-Maps, die das Bewegungssystem von Black Ops III voll ausschöpfen, einschließlich einer Kampfkunstarena, einem postapokalyptischen Stammesgebiet, eines futuristischen, suborbitalen zivilen Flughafenterminals und eines militärischen Schienensystems hoch über einem "Banzai," verlegt die Multiplayer-Kämpfe in das Zentrum einer fernen postapokalyptischen den Wolken, wo mehrere Ebenen und offene Bereiche intensive Kämpfe auf mittlere Distanz in einer sauberen, zivilen Hightech-Umgebung fördern.
<G-vec00121-002-s278><battle.kämpfen><en> Battle with Batman and his super allies in outer space and across the Lantern worlds.
<G-vec00121-002-s278><battle.kämpfen><de> Kämpfe mit Batman und seinen verbündeten Superhelden im Weltraum und in verschiedenen Lantern-Welten.
<G-vec00121-002-s279><battle.kämpfen><en> Battle and carnage are the lifeblood of the Barbarian Bloddwalkers.
<G-vec00121-002-s279><battle.kämpfen><de> Kämpfe und Gemetzel sind ihr Lebenssaft.
<G-vec00121-002-s280><battle.kämpfen><en> Defeat over 20 different types of opponents and battle for the Highscore.
<G-vec00121-002-s280><battle.kämpfen><de> Besiege über 20 unterschiedliche Gegnertypen und kämpfe um den Highscore.
<G-vec00121-002-s281><battle.kämpfen><en> In LEGO Indiana Jones 2, everyone can build, battle and brawl their way through their favourite cinematic moments from the Indiana Jones movie series – or create their own.
<G-vec00121-002-s281><battle.kämpfen><de> Fans können LEGO bauen, Kämpfe austragen und sich durch ihre Lieblings-Filmszenen schlagen, von Indys Begegnung mit Schlangen bis zu seiner überstürzten Flucht vor einer gewaltigen Felskugel.
<G-vec00121-002-s282><battle.kämpfen><en> Working at adidas Group is not a battle to be won, it’s a journey into the unknown.
<G-vec00121-002-s282><battle.kämpfen><de> Bei Ihrer Arbeit bei adidas müssen Sie keine Kämpfe gewinnen – vielmehr befinden Sie sich auf einer Reise ins Unbekannte.
<G-vec00121-002-s283><battle.kämpfen><en> Over 350 unique, historically accurate vehicles battle each other in 7-on-7 battles in more than 25 locations in multiple modes.
<G-vec00121-002-s283><battle.kämpfen><de> Über 350 einzigartige, historisch genaue Fahrzeuge kämpfen hier in 7-gegen-7-Gefechten an mehr als 25 Orten in mehreren Modi gegeneinander.
<G-vec00121-002-s284><battle.kämpfen><en> The game is very spooky and you must battle against the SS forces in Transylvania.
<G-vec00121-002-s284><battle.kämpfen><de> Das Spiel ist sehr unheimlich und Sie müssen kämpfen gegen die SS-Truppen in Transylvania.
<G-vec00121-002-s285><battle.kämpfen><en> Battle your way to the Loom Chamber in under 10 minutes.
<G-vec00121-002-s285><battle.kämpfen><de> Kämpfen Sie sich in unter 10 Minuten zur Webstuhlkammer vor.
<G-vec00121-002-s286><battle.kämpfen><en> To help you pick a strong group to bring to battle, six Pokémon will automatically be recommended to use in the battle based your opponents’ strengths and weaknesses.
<G-vec00121-002-s286><battle.kämpfen><de> Um dir beim Auswählen einer starken Gruppe zum Kämpfen zu helfen, werden automatisch basierend auf den Stärken und Schwächen deines Gegners sechs Pokémon für den Kampf vorgeschlagen.
<G-vec00121-002-s287><battle.kämpfen><en> Navy vs. Army is a fun skill shot game with physics engine where some guys of Navy and Army battle against each other.
<G-vec00121-002-s287><battle.kämpfen><de> Navy vs. Army ist ein lustiges Geschicklichkeits Schiessspiel, in dem Typen aus der Navy und der Armee gegeneinander kämpfen.
<G-vec00121-002-s288><battle.kämpfen><en> 20 And the men of Israel went out to battle against Benjamin; and the men of Israel put themselves in array to fight against them at Gibeah.
<G-vec00121-002-s288><battle.kämpfen><de> 20 Und die Männer von Israel zogen aus, um mit Benjamin zu kämpfen, und stellten sich in Schlachtordnung auf zum Kampf gegen Gibea.
<G-vec00121-002-s289><battle.kämpfen><en> Experts believe that number will likely swell, potentially driving at least another 1.5 million men, women and children to flee once the U.S.-backed battle for Mosul begins.
<G-vec00121-002-s289><battle.kämpfen><de> Experten sind der Meinung, dass die Zahl noch ansteigen wird, wenn noch 1,5 Millionen weitere Männer, Frauen und Kinder fliehen werden, um den von den USA unterstützen Kämpfen um Mosul zu entkommen.
<G-vec00121-002-s290><battle.kämpfen><en> Open to any to take the challenge and show to all that they have what it takes to be one of the best, teams battle to rise to the top through a series of ZOTAC CUP qualifiers building up to a ZOTAC CUP MASTERS live event where the best meet best.
<G-vec00121-002-s290><battle.kämpfen><de> Offen für alle, die sich der Herausforderung stellen möchten und es allen zeigen wollen, dass sie das Zeug dazu haben, ganz oben mitzuspielen und sich durch eine Reihe von ZOTAC CUP Online Qualifikationen und dem regionalen Finale kämpfen können.
<G-vec00121-002-s291><battle.kämpfen><en> Occupation In this remake of a classic Call of Duty® map, players battle through the streets and shops of German-occupied Paris during WWII.
<G-vec00121-002-s291><battle.kämpfen><de> Occupation – In diesem Remake einer klassischen CoD-Karte kämpfen sich Spieler durch die Straßen und Geschäfte eines von den Deutschen besetzten Paris im zweiten Weltkrieg.
<G-vec00121-002-s292><battle.kämpfen><en> Most planeswalkers can't be used as commanders, but these four have been designed specifically to fill that role, so you can battle with a true legend of the Multiverse by your side.
<G-vec00121-002-s292><battle.kämpfen><de> Die meisten Planeswalker können nicht als Kommandeure eingesetzt werden, diese vier aber sind eigens für eine solche Rolle konzipiert; du kannst also mit einer wahren Legende des Multiversums an deiner Seite kämpfen.
<G-vec00121-002-s293><battle.kämpfen><en> 2 Behold, we have not come out to battle against you that we might shed your blood for power; neither do we desire to bring any one to the ayoke of bondage.
<G-vec00121-002-s293><battle.kämpfen><de> 2 Siehe, wir sind nicht hergekommen, um gegen euch zu kämpfen, daß wir um der Macht willen euer Blut vergießen; wir haben auch nicht den Wunsch, irgend jemand unter das Joch der Knechtschaft zu bringen.
<G-vec00121-002-s294><battle.kämpfen><en> He teams up with his ex-girlfriend Marian and the Arab fighter Little John (Jamie Foxx) he came across during the battle.
<G-vec00121-002-s294><battle.kämpfen><de> Robin Hood beschließt gemeinsam mit seinem Verbündeten Little John (Jamie Foxx), die Missstände nicht länger hinzunehmen und gegen die vorherrschende Ungerechtigkeit zu kämpfen.
<G-vec00121-002-s295><battle.kämpfen><en> Save Aleppo The battle for the Syrian city of Aleppo has left hundreds of people dead or injured.
<G-vec00121-002-s295><battle.kämpfen><de> In den Kämpfen in und um Aleppo wurden in den letzten Tagen und Wochen Hunderte Menschen getötet oder verletzt.
<G-vec00121-002-s296><battle.kämpfen><en> Some Thing Cards even have uses in puzzles outside of battle, too!
<G-vec00121-002-s296><battle.kämpfen><de> Einige Dings-Karten kann man auch außerhalb von Kämpfen in Rätseln sehr gut anwenden.
<G-vec00121-002-s297><battle.kämpfen><en> Eight of the top European teams will battle for dominance in the European Regionals at Gamescom, with the top three teams advancing to the World Championship in Los Angeles, California.
<G-vec00121-002-s297><battle.kämpfen><de> Acht der besten Teams aus Europa werden auf der gamescom um die Vorherrschaft kämpfen und die drei besten Teams rücken zur Weltmeisterschaft in Los Angeles, Kalifornien, vor.
<G-vec00121-002-s298><battle.kämpfen><en> Selected contestants will be pre-judged for craftsmanship off stage and then battle it out on the Main Stage for First Place in their respective categories.
<G-vec00121-002-s298><battle.kämpfen><de> Die ausgewählten Kandidaten werden vor Ort auf der VIECC Vienna Comic Con vorab für ihr handwerkliches Geschick abseits der Bühne von einer professionellen Cosplay Jury beurteilt und kämpfen anschließend auf der Hauptbühne um den ersten Platz in ihrer jeweiligen Kategorie.
<G-vec00121-002-s299><battle.kämpfen><en> Remember that you are very slow, so pick the spot you will be most useful in battle very carefully - you will most likely not have the chance to readjust your position later on.
<G-vec00121-002-s299><battle.kämpfen><de> Denkt auch daran, dass ihr euch eher langsam fortbewegt, also müsst ihr schon am Anfang festlegen, wo ihr mit eurem Panzer kämpfen möchtet, da ihr später wahrscheinlich keine Möglichkeit haben werdet, die Flanke zu wechseln.
<G-vec00121-002-s300><battle.kämpfen><en> At the same time, however, they are also so that God may do battle with Satan.
<G-vec00121-002-s300><battle.kämpfen><de> Gleichzeitig sind sie jedoch so, dass Gott mit Satan kämpfen kann.
<G-vec00121-002-s301><battle.kämpfen><en> Super Pokémon Rumble allows players to battle against waves of opposing wind-up Toy Pokémon, and connect with a friend to battle together.
<G-vec00121-002-s301><battle.kämpfen><de> In Super Pokémon Rumble können die Spieler gegen Spielzeug-Pokémon kämpfen und sich mit einem Freund verbinden, um gemeinsam in die Schlacht zu ziehen.
