<G-vec00057-001-s133><contact.aufnehmen><en> By coincidence, they establish contact with an alien form of life.
<G-vec00057-001-s133><contact.aufnehmen><de> Der Zufall will es, dass sie Kontakt mit einer fremden Lebensform aufnehmen.
<G-vec00057-001-s134><contact.aufnehmen><en> For water is enough to come in contact with the substance to learn about its properties and to keep this information in its memory.
<G-vec00057-001-s134><contact.aufnehmen><de> Dem Wasser ist genug den Kontakt mit dem Stoff aufnehmen, um seine Eigenschaften zu erfahren und diese Information in seinem Gedächtnis halten zu können.
<G-vec00057-001-s135><contact.aufnehmen><en> It is very unlikely that clients are open with you and make contact.
<G-vec00057-001-s135><contact.aufnehmen><de> Es ist sehr unwahrscheinlich, dass sich die Klienten Ihnen öffnen und Kontakt aufnehmen.
<G-vec00057-001-s136><contact.aufnehmen><en> To clarify the details, please contact us by telephone contact or insert your phone number in the comments section, we will call you back.
<G-vec00057-001-s136><contact.aufnehmen><de> Um die Details abzuklären, bitte mit uns telefonisch Kontakt aufnehmen oder Ihre Telefonnummer in das Bemerkungsfeld eintragen, wir rufen gerne zurück.
<G-vec00057-001-s137><contact.aufnehmen><en> In this case, and assuming that the user wishes to enter into business relations with Siemens, the user should contact the Siemens representatives in the respective country.
<G-vec00057-001-s137><contact.aufnehmen><de> In diesem Fall und falls der Nutzer in geschäftliche Beziehungen mit Siemens treten möchte, sollte der Nutzer zu Siemens-Repräsentanten in dem jeweiligen Land Kontakt aufnehmen.
<G-vec00057-001-s138><contact.aufnehmen><en> You can contact our press office directly using the e-mail form.
<G-vec00057-001-s138><contact.aufnehmen><de> Über das E-Mail-Formular können Sie direkten Kontakt zu unserer Pressestelle aufnehmen.
<G-vec00057-001-s139><contact.aufnehmen><en> Individuals may request to access, correct, amend or delete information we hold about them by contacting on our contact page.
<G-vec00057-001-s139><contact.aufnehmen><de> Einzelpersonen können verlangen, auf Informationen, die wir über sie haben, zuzugreifen, sie zu korrigieren, zu ändern oder zu löschen, indem sie auf unserer Kontaktseite Kontakt aufnehmen.
<G-vec00057-001-s140><contact.aufnehmen><en> In the event that an unauthorised purchase is dispatched prior to your notifying us of the unauthorised nature of the purchase, Eu-pharmacy-online.net accepts no liability or responsibility and you should make contact with the Carrier detailed in the Purchase Information.
<G-vec00057-001-s140><contact.aufnehmen><de> Sollte ein unautorisierter Kauf, vor Ihrer Notifikation, getätigt worden sein, so übernimmt Eu-pharmacy-online.net keine Haftung und Sie sollten mit dem Frachtführer Kontakt aufnehmen.
<G-vec00057-001-s141><contact.aufnehmen><en> Are you a reliable quality supplier who can respond rapidly and dynamically to changing market requirements? Please contact our Strategic Purchasing Department.
<G-vec00057-001-s141><contact.aufnehmen><de> Als zuverlässiger Qualitätsanbieter, der in der Lage ist, schnell und flexibel auf wechselnde Marktanforderungen zu reagieren, sollten Sie Kontakt zu unserem strategischen Einkauf aufnehmen.
<G-vec00057-001-s142><contact.aufnehmen><en> The hospital and all 28 villages are equipped with radio appliances in order to establish contact.
<G-vec00057-001-s142><contact.aufnehmen><de> Das Hospital und alle 28 Gemeinden verfügen über ein Funkgerät, um Kontakt aufnehmen zu können.
<G-vec00057-001-s143><contact.aufnehmen><en> You can get in contact to arrange a visit, ask questions about the work of both institutions, and request a document, among other services.
<G-vec00057-001-s143><contact.aufnehmen><de> Sie können Kontakt aufnehmen, unter anderem um einen Besuch zu organisieren, um Fragen über die Arbeit der beiden Organe zu stellen oder um Dokumente anzufordern.
<G-vec00057-001-s144><contact.aufnehmen><en> E-mails are actually a great means of advertising: You can make contact with your customers more or less for free, send them information which is up-to-the-minute and offer them a chance to give a direct reaction.
<G-vec00057-001-s144><contact.aufnehmen><de> E-Mails sind eigentlich ein tolles Werbemedium: Man kann praktisch umsonst Kontakt zu seinen Kunden aufnehmen, ihnen tagesaktuelle Inhalte schicken und ihnen die Möglichkeit zu einer direkten Reaktion anbieten.
<G-vec00057-001-s145><contact.aufnehmen><en> Whenever you make use of a feature that allows you to upload material to our site, or to make contact with other users of our site, you must comply with the content standards set out in our Acceptable Use Policy .
<G-vec00057-001-s145><contact.aufnehmen><de> HOCHLADEN VON MATERIALIEN AUF UNSERE WEBSITE Wenn Sie eine Funktion nutzen, mit der Sie Materialien auf unsere Website hochladen oder Kontakt mit anderen Benutzern unserer Website aufnehmen können, müssen Sie die Inhaltsanforderungen einhalten, die in unserer Richtlinie über die zulässige Nutzung dargelegt sind.
<G-vec00057-001-s146><contact.aufnehmen><en> I built my computer from components; I don't have a system manufacturer Â to contact.
<G-vec00057-001-s146><contact.aufnehmen><de> Ich habe meinen Computer aus Bauteilen gebaut; Ich habe keinen Systemhersteller, der Kontakt aufnehmen muss.
<G-vec00057-001-s147><contact.aufnehmen><en> Innovation Sustainability Here you can contact the Siemens Innovation Communications.
<G-vec00057-001-s147><contact.aufnehmen><de> Innovation Nachhaltigkeit Hier können Sie Kontakt zur Siemens-Innovationskommunikation aufnehmen.
<G-vec00057-001-s148><contact.aufnehmen><en> If You contact Us by telephone, We reserve the right to record such calls.
<G-vec00057-001-s148><contact.aufnehmen><de> Wenn Sie telefonisch mit uns Kontakt aufnehmen, behalten wir uns das Recht vor, diese Anrufe aufzunehmen.
<G-vec00057-001-s149><contact.aufnehmen><en> The social media apps like Facebook let the user choose who can contact, send a friend request, transmit messages and see social media posts.
<G-vec00057-001-s149><contact.aufnehmen><de> Mit den Social-Media-Apps wie Facebook kann der Benutzer auswählen, wer Kontakt aufnehmen, eine Freundschaftsanfrage senden, Nachrichten senden und Social-Media-Beiträge anzeigen kann.
<G-vec00057-001-s150><contact.aufnehmen><en> After your application via our registration form, we will get in contact with you to take care about your nomination and the requirements as soon as possible.
<G-vec00057-001-s150><contact.aufnehmen><de> Nach deiner Bewerbung über unser Anmeldeformular werden wir dies entsprechend prüfen und so schnell wie möglich mit dir Kontakt aufnehmen, um deine Nominierung zu bestätigen oder die Voraussetzungen zu erfüllen.
<G-vec00057-001-s151><contact.aufnehmen><en> You can contact us quickly by email.
<G-vec00057-001-s151><contact.aufnehmen><de> Per E-Mail können Sie mit uns schnell Kontakt aufnehmen.
<G-vec00057-001-s171><contact.treten><en> Don't hesitate to contact us if you need further information on any of our products or services.
<G-vec00057-001-s171><contact.treten><de> Wenn Sie weitere Informationen zu unserem Service wünschen, zögern Sie nicht, mit uns in Kontakt zu treten.
<G-vec00057-001-s172><contact.treten><en> At this page, you can get information about the prices of our apartments and contact with us if you want to make a reservation.
<G-vec00057-001-s172><contact.treten><de> Hier können Sie Informationen über die Preise der Appartements finden und für Ihre Buchung mit uns in Kontakt treten.
<G-vec00057-001-s173><contact.treten><en> It keeps you informed about current Career Service projects and keeps you updated on new opportunities to contact our students.
<G-vec00057-001-s173><contact.treten><de> Er informiert Sie über die Arbeit des Career Service und stellt Ihnen aktuelle Möglichkeiten vor, mit unseren Studierenden in Kontakt zu treten.
<G-vec00057-001-s174><contact.treten><en> Note: If you would like to contact us by E-mail, please note that the contents of unencrypted E-mails can be viewed by third parties.
<G-vec00057-001-s174><contact.treten><de> Hinweis: Sollten Sie mit uns per E-Mail in Kontakt treten wollen, weisen wir darauf hin, dass der Inhalt unverschlüsselter E-Mails von Dritten eingesehen werden kann.
<G-vec00057-001-s175><contact.treten><en> Therefore, for help in this matter is best to contact the experts, that accurately calculate the right amount of the pillars and their technical characteristics.
<G-vec00057-001-s175><contact.treten><de> Daher ist für Hilfe in dieser Angelegenheit ist am besten, die Experten in Kontakt zu treten, dass genau die richtige Menge der Säulen und ihre technischen Eigenschaften zu berechnen.
<G-vec00057-001-s176><contact.treten><en> "JiÅTMÃ­ Milek, Minister for Agriculture of the Czech Republic: ""This prestigious event is an excellent opportunity for our producers to present quality items from the Czech Republic and to make contact with potential business partners."
<G-vec00057-001-s176><contact.treten><de> "JiÅTMÃ­ Milek, Landwirtschaftsminister der Tschechischen Republik: ""Die prestigeträchtige Veranstaltung ist eine großartige Möglichkeit fÃ1⁄4r unsere Produzenten, tschechische Qualitätsprodukte vorzustellen und mit potenziellen Businesspartnern in Kontakt zu treten."
<G-vec00057-001-s177><contact.treten><en> It's the only thing effective in every case: when you want to do something, when you cannot do something, when you act, when the body can no longer act... In EACH and EVERY case, that alone – that alone: make conscious contact with the Supreme Consciousness, unite with it, and... wait. There.
<G-vec00057-001-s177><contact.treten><de> Dies ist in jedem Fall das einzig Zutreffende: Sei es, daß man etwas tun will, sei es, daß man etwas nicht tun kann, sei es, daß man handelt, sei es, daß der Körper nicht mehr handeln kann... in ALLEN, allen Fällen – nur dies: in einen bewußten Kontakt mit dem Höchsten Bewußtsein treten, sich mit ihm vereinen und... warten.
<G-vec00057-001-s178><contact.treten><en> Here are 20 of our most recent Arabic, Middle Eastern language pen pals that could become your pen friends.To view all registered Arabic, Middle Eastern language pen pals, please click here .Click on a name for more information or to contact the member.
<G-vec00057-001-s178><contact.treten><de> Unsere neuesten Arabisch-Nahostsprachigen Mitglieder Hier sind 20 unserer neuesten Arabisch-Nahostsprachigen Mitglieder, die dein Austauschpartner werden könnten.Hier klicken, um alle registrierten Arabisch-Nahostsprachigen Mitglieder zu sehen.Klicke auf einen der Namen für mehr Information, oder um mit einem Mitglied in Kontakt zu treten.
<G-vec00057-001-s179><contact.treten><en> By integrating social networking into your contact management system you can track who your contacts' contacts are, who they are talking to, who the key players are that you should be in contact with, and who can provide you with introductions to them.
<G-vec00057-001-s179><contact.treten><de> Durch die Integration sozialer Netzwerke in Ihr Kontaktmanagementsystem können Sie nachverfolgen, wer die Kontakte Ihrer Kontakte sind, mit wem sie sich austauschen, wer die Hauptakteure sind, mit denen Sie in Kontakt treten sollten, und wer Sie ihnen vorstellen kann.
<G-vec00057-001-s180><contact.treten><en> "The guys have fun, so it seems, and the vocalist always tries to keep audience contact, tries for example the ""Radler""-drink of a fan and comments it like: ""You know, I heard about this story of the Germans drinking beer mixed with lemonade and I found it very weird."
<G-vec00057-001-s180><contact.treten><de> "Die Jungs haben Spaß, so scheint es zumindest, der Sänger ist stetig bemüht mit dem Publikum in Kontakt zu treten, probiert zum Beispiel das Radler eines Fans, und meint dann dazu ""You know, I heard about this story of the Germans drinking beer mixed with lemonade and I found it very weird."
<G-vec00057-001-s181><contact.treten><en> Here are 20 of our most recent Marathi language pen pals that could become your pen friends.To view all registered Marathi language pen pals, please click here .Click on a name for more information or to contact the member.
<G-vec00057-001-s181><contact.treten><de> Unsere neuesten Marathischsprachigen Mitglieder Hier sind 20 unserer neuesten Marathischsprachigen Mitglieder, die dein Austauschpartner werden könnten.Hier klicken, um alle registrierten Marathischsprachigen Mitglieder zu sehen.Klicke auf einen der Namen für mehr Information, oder um mit einem Mitglied in Kontakt zu treten.
<G-vec00057-001-s182><contact.treten><en> Almost 99 percent of male customers are satisfied and can no longer help but repeatedly to get in contact with our ladies.
<G-vec00057-001-s182><contact.treten><de> Nahezu 99 Prozent der männlichen Kunden sind zufrieden und können gar nicht mehr anders, als immer wieder mit unseren Ladies in den Kontakt zu treten.
<G-vec00057-001-s183><contact.treten><en> Click on Contact and you will be put in touch with our experts by email.
<G-vec00057-001-s183><contact.treten><de> Dann klicken Sie auf Kontakt und treten mit unseren Experten per Mail in Verbindung.
<G-vec00057-001-s184><contact.treten><en> Furthermore, there is the opportunity for users to make contact with others and to embed selected content on their own websites.
<G-vec00057-001-s184><contact.treten><de> Weiterhin besteht auf clipflakes.tv die Möglichkeit mit anderen Nutzern in Kontakt zu treten und eingestellte Inhalte auf eigenen Webseiten einzubinden.
<G-vec00057-001-s185><contact.treten><en> At the same time, they have the possibility to establish direct contact with potential partners and to benefit from their experience.
<G-vec00057-001-s185><contact.treten><de> Gleichzeitig haben sie die Möglichkeit, mit potenziellen Partnern in Kontakt zu treten und von deren Erfahrung zu profitieren.
<G-vec00057-001-s186><contact.treten><en> 'In that case, it wasn't a dance, but the complete absence of noise and movement, the silence, that brought me into contact with myself.
<G-vec00057-001-s186><contact.treten><de> In meinem Fall war es nicht der Tanz, sondern das vollkommene Fehlen von Geräuschen und Bewegung, die Stille, die mich mit mir selber in Kontakt treten ließ.
<G-vec00057-001-s187><contact.treten><en> Magicline makes it easier than ever – even incorporating several studios – to manage and get in contact with interested parties, as well as past and present customers.
<G-vec00057-001-s187><contact.treten><de> Mit der Magicline wird es einfacher als je zuvor, auch über mehrere Studios hinweg Interessenten, Kunden und Ehemalige optimal zu verwalten und mit ihnen in Kontakt zu treten.
<G-vec00057-001-s188><contact.treten><en> "From Anarchism was to be taken the organizational principle ""from the periphery to the center, from the basis to the top"", what, for instance, meant: to advance in ""therapy"" (from now on: agitation), by means of an as extensive as possible understanding of the systematics of Capitalism in mind (""periphery"") to illness itself (""center""), or – another example – to contact other organizations and movements only via their basis, in order to activate the consciousnesses of illness and to drive them without break towards the organizational top (thus avoiding both entrism and splitting up in factions)."
<G-vec00057-001-s188><contact.treten><de> "Vom Anarchismus war das Organisationsprinzip ""von der Peripherie zum Zentrum, von der Basis zur Spitze"" zu übernehmen, was beispielsweise bedeutete, in der ""Therapie"" (ab jetzt Agitation) mit der möglichst weitgehend begriffenen Systematik des Kapitalismus im Kopf (""Peripherie"") zur Krankheit (""Zentrum"") vorzudringen, oder – anderes Beispiel – mit anderen Organisationen und Bewegungen nur über deren Basis in Kontakt zu treten, um die Krankheitsbewußtseine zu aktivieren und der Spitze bruchlos entgegenzutreiben (also weder Entrismus noch Spalterei aufkommen zu lassen)."
<G-vec00057-001-s189><contact.treten><en> Here are 20 of our most recent Berber (Tamazight) language pen pals that could become your pen friends.To view all registered Berber (Tamazight) language pen pals, please click here .Click on a name for more information or to contact the member.
<G-vec00057-001-s189><contact.treten><de> Unsere neuesten Berberischsprachigen Mitglieder Hier sind 20 unserer neuesten Berberischsprachigen Mitglieder, die dein Austauschpartner werden könnten.Hier klicken, um alle registrierten Berberischsprachigen Mitglieder zu sehen.Klicke auf einen der Namen für mehr Information, oder um mit einem Mitglied in Kontakt zu treten.
<G-vec00057-001-s304><contact.kontaktieren><en> Contact your child's teacher to learn the code if you don't know it already.
<G-vec00057-001-s304><contact.kontaktieren><de> Kontaktiere den Lehrer deines Kindes, um den Code zu erfahren, wenn du ihn noch nicht hast.
<G-vec00057-001-s305><contact.kontaktieren><en> Contact our Recruiter Mandy Beer if you want to know more.
<G-vec00057-001-s305><contact.kontaktieren><de> Kontaktiere unsere Recruiterin Mandy Beer, wenn du mehr wissen möchtest.
<G-vec00057-001-s306><contact.kontaktieren><en> If you have any questions or concerns regarding privacy using the Services, please contact us here .
<G-vec00057-001-s306><contact.kontaktieren><de> Solltest du Fragen oder Bedenken hinsichtlich des Datenschutzes bei der Nutzung der Dienste haben, kontaktiere uns bitte .
<G-vec00057-001-s307><contact.kontaktieren><en> If you have any questions about these Terms, please contact us.
<G-vec00057-001-s307><contact.kontaktieren><de> Falls du irgendwelche Fragen zu den Bedingungen hast, bitte kontaktiere uns.
<G-vec00057-001-s308><contact.kontaktieren><en> Please use the Contact Nancy form, a link from the ZetaTalk home page, which does not allow attachments, to open a dialog with Nancy.
<G-vec00057-001-s308><contact.kontaktieren><de> Bitte nutze das Kontaktiere Nancy Formular, ein Link von der ZetaTalk-Homepage, das keine Anhänge erlaubt, um einen Dialog mit Nancy zu eröffnen.
<G-vec00057-001-s309><contact.kontaktieren><en> If you're still unsure or you have questions about a particular T-shirt, then simply contact our customer service .
<G-vec00057-001-s309><contact.kontaktieren><de> Solltest du dir dennoch unsicher sein und du Fragen zu einem T-Shirt deiner Wahl haben, dann kontaktiere einfach unseren Kundenservice .
<G-vec00057-001-s310><contact.kontaktieren><en> Please contact us if you have any questions.
<G-vec00057-001-s310><contact.kontaktieren><de> Bitte kontaktiere uns falls du Fragen hast.
<G-vec00057-001-s311><contact.kontaktieren><en> If you have further questions, visit the Open Doors FAQ, contact the Open Doors committee, or leave a comment on this post and we'll respond as soon as we can.
<G-vec00057-001-s311><contact.kontaktieren><de> Falls Du noch weitere Fragen hast, schaue in die Open Doors-FAQ oder kontaktiere Open Doors, oder hinterlasse einen Kommentar unter dieser Ankündigung, und wir werden so schnell wir können antworten.
<G-vec00057-001-s312><contact.kontaktieren><en> Alternatively you may contact us through the Contact Us page.
<G-vec00057-001-s312><contact.kontaktieren><de> Alternativ können Sie einen interaktiven Dienst auch über die Kontaktiere Uns -Seite melden.
<G-vec00057-001-s313><contact.kontaktieren><en> So if you want to level up or add a couple more years to your Kramfors, visit our website or contact us.
<G-vec00057-001-s313><contact.kontaktieren><de> Also, wenn du dein Kramfors Sofa aufpeppen möchtest, dann besuche unsere Website oder kontaktiere uns.
<G-vec00057-001-s314><contact.kontaktieren><en> If you have any questions about the budget or the OTW’s finances, please contact the Finance committee.
<G-vec00057-001-s314><contact.kontaktieren><de> Falls Du noch weitere Fragen zu Budget oder Finanzen der OTW hast, kontaktiere bitte das Finanzkomitee.
<G-vec00057-001-s315><contact.kontaktieren><en> Please contact us if interested.
<G-vec00057-001-s315><contact.kontaktieren><de> Kontaktiere Sie uns bitte.
<G-vec00057-001-s316><contact.kontaktieren><en> "If you have urgent space problems, for example, because your new home is not yet ready for you to move in or you need to store furniture, decor items, files, collections urgently, ""construction site storage” is the answer: Contact us on 044 273 91 91 or via this form."
<G-vec00057-001-s316><contact.kontaktieren><de> Wenn du dringende Platzprobleme hast, zum Beispiel weil deine neue Wohnung noch nicht bezugsbereit ist oder du Möbel, Wohnungseinrichtung, Akten, Sammlungen dringend einlagern musst, dann kannst du bereits jetzt von einer „Baustelleneinlagerung“ profitieren: Kontaktiere uns unter 044 273 91 91 oder über dieses Formular.
<G-vec00057-001-s317><contact.kontaktieren><en> If you have reason to believe that this has occurred, please contact us at info@99roots.com, and we will delete all relevant information.
<G-vec00057-001-s317><contact.kontaktieren><de> Hast du Grund zu der Annahme, dass dies geschehen ist, kontaktiere uns bitte unter info@99roots.com, und wir werden alle relevanten Informationen löschen.
<G-vec00057-001-s318><contact.kontaktieren><en> Please contact our Billing Department using our feedback form, email, or call toll-free (U.S. and Canada only) at 888-575-8383.
<G-vec00057-001-s318><contact.kontaktieren><de> Bitte kontaktiere unsere Rechnungsabteilung über unser Feedback-Formular, per E-Mail, oder gebührenfrei (nur für die USA und Kanada) unter 888-575-8383.
<G-vec00057-001-s319><contact.kontaktieren><en> If you placed your order via the Dynafit Online Shop and received the wrong product, please contact us directly here.
<G-vec00057-001-s319><contact.kontaktieren><de> Wenn du deine Bestellung über den Dynafit Onlinestore aufgegeben und das falsche Produkt erhalten hast, kontaktiere uns bitte direkt hier.
<G-vec00057-001-s320><contact.kontaktieren><en> If you have any inquiries or questions,welcome to contact us.
<G-vec00057-001-s320><contact.kontaktieren><de> Wenn Sie irgendwelche Anfragen oder Fragen haben, begrüßen zu kontaktiere uns.
<G-vec00057-001-s321><contact.kontaktieren><en> For further information, advice and enrolment just contact us.
<G-vec00057-001-s321><contact.kontaktieren><de> Für weitere Informationen, Beratung und Anmeldung kontaktiere uns einfach.
<G-vec00057-001-s322><contact.kontaktieren><en> If you are willing to share some tips, notes, suggestions or offers, please contact me.
<G-vec00057-001-s322><contact.kontaktieren><de> Wenn du mir einige Tipps, Hinweise, Anmerkungen oder Angebote zukommen lassen willst, kontaktiere mich bitte.
<G-vec00057-001-s323><contact.kontaktieren><en> Communications If you contact BCBG in any manner whatsoever, we may keep a record of such correspondence.
<G-vec00057-001-s323><contact.kontaktieren><de> Kommunikation Wenn Sie BCBG kontaktieren, egal aus welchem Grund, können wir diese Kommunikation dokumentieren.
<G-vec00057-001-s324><contact.kontaktieren><en> Contact campsite Go to the home page Campsite address Campsite El Brillante Avda.
<G-vec00057-001-s324><contact.kontaktieren><de> Campingplatz kontaktieren Zur Homepage gehen Adresse des Campingplatzes Campingplatz El Brillante Avda.
<G-vec00057-001-s325><contact.kontaktieren><en> In addition, we will also collect personal information from you when you correspond with us (for example, if you contact us with a query about one of our products or services), when you provide your details when you visit a Vacheron Constantin boutique or contact the Vacheron Constantin concierge by telephone.
<G-vec00057-001-s325><contact.kontaktieren><de> Wir können außerdem personenbezogene Daten über Sie erheben, wenn Sie mit uns kommunizieren (etwa, wenn Sie sich mit einer Rückfrage zu einem unserer Produkte oder einer unserer Dienstleistungen an uns wenden), wenn Sie anlässlich eines Besuchs einer Vacheron Constantin-Boutique Ihre Kontaktangaben hinterlassen, oder wenn Sie die Vacheron Constantin-Rezeption telefonisch kontaktieren.
<G-vec00057-001-s326><contact.kontaktieren><en> If you are aware of any other file formats using the NDC file extension, please contact us so that we can update our information accordingly.
<G-vec00057-001-s326><contact.kontaktieren><de> Wenn Sie Kenntnis über weitere Dateiformate mit der NDC-Dateiendung erlangen, kontaktieren Sie uns bitte, damit wir unsere Daten entsprechend aktualisieren.
<G-vec00057-001-s327><contact.kontaktieren><en> If you disagree with the changes that have been made, please contact us (by e-mail, using a website contact form, or in writing by mail), and any changes made to this policy will not apply to information we have collected from you prior to making the changes.
<G-vec00057-001-s327><contact.kontaktieren><de> Wenn Sie mit den Änderungen nicht einverstanden, die vorgenommen wurden sind, kontaktieren Sie uns (per E-mail, über eine Website-Kontakt-Formular oder schriftlich per Post) und alle Änderungen dieser Datenschutzbestimmungen gelten nicht für Informationen, die wir von Ihnen erfasst haben, vor Durchführung der Änderungen.
<G-vec00057-001-s328><contact.kontaktieren><en> If you are interested in please contact us for price list, pictures, etc
<G-vec00057-001-s328><contact.kontaktieren><de> Wenn Sie daran interessiert sind, bitte kontaktieren Sie uns für Preisliste, Bilder, etc.
<G-vec00057-001-s329><contact.kontaktieren><en> To get it in the property, the entrepreneur must contact the land department, which is located in the administration - district or city.
<G-vec00057-001-s329><contact.kontaktieren><de> Um es in das Eigentum zu bekommen, muss der Unternehmer die Landabteilung kontaktieren, die im Verwaltungsbezirk oder in der Stadt gelegen ist.
<G-vec00057-001-s330><contact.kontaktieren><en> If we want to make use of your personal data in a way that we haven't previously identified, we will contact you to provide information about this and, if necessary, to ask for your consent.
<G-vec00057-001-s330><contact.kontaktieren><de> Wenn wir Ihre persönlichen Daten in einer Art und Weise verwenden möchten, die wir vorher nicht identifiziert haben, werden wir Sie kontaktieren Informationen Ã1⁄4ber die Verwendung zur VerfÃ1⁄4gung zu stellen und, falls erforderlich, um ihre Zustimmung bitten.
<G-vec00057-001-s331><contact.kontaktieren><en> If you do not have any other rights to end the contract (see clause 8.1), you can still contact us before it is completed and tell us you want to end it.
<G-vec00057-001-s331><contact.kontaktieren><de> Wenn Sie keine weiteren Rechte haben, den Vertrag zu beenden (siehe Ziffer 8.1), können Sie uns, vor ErfÃ1⁄4llung, immer noch kontaktieren und uns mitteilen, dass Sie ihn beenden möchten.
<G-vec00057-001-s332><contact.kontaktieren><en> Please visit our website or contact us for more information.
<G-vec00057-001-s332><contact.kontaktieren><de> Bitte besuchen Sie unsere Website oder kontaktieren Sie uns für weitere Informationen.
<G-vec00057-001-s333><contact.kontaktieren><en> If any questions remain unanswered, please do not hesitate to contact us. Appointment
<G-vec00057-001-s333><contact.kontaktieren><de> Sollten dennoch offene Fragen bleiben, scheuen Sie nicht uns zu kontaktieren.
<G-vec00057-001-s334><contact.kontaktieren><en> To contact us, please send email to support@any-video-converter.com . Free Recommened Related Products
<G-vec00057-001-s334><contact.kontaktieren><de> Um uns zu kontaktieren, bitte schicken Sie uns per E-Mail an support@anvsoft.de .
<G-vec00057-001-s335><contact.kontaktieren><en> To contact Borel, please fill in our form below.
<G-vec00057-001-s335><contact.kontaktieren><de> Um Borel zu kontaktieren, füllen Sie bitte untenstehendes Formular aus.
<G-vec00057-001-s336><contact.kontaktieren><en> Please provide us with the alternative email which can be used to contact you additionally (not the same domain as blocked please).
<G-vec00057-001-s336><contact.kontaktieren><de> Bitte geben Sie uns mit der alternativen e-Mail-Adresse die verwendet werden können, um Sie zusätzlich zu kontaktieren (nicht der gleichen Domäne wie blockierte bitte).
<G-vec00057-001-s337><contact.kontaktieren><en> If you are looking for support for other subarchitectures, please contact the debian-mips mailing list.
<G-vec00057-001-s337><contact.kontaktieren><de> Wenn Sie Unterstützung für andere Unterarchitekturen benötigen, kontaktieren Sie bitte die debian mips-Mailingliste.
<G-vec00057-001-s338><contact.kontaktieren><en> Please contact us if you have any questions on our organisation or if you wish to receive press related information.
<G-vec00057-001-s338><contact.kontaktieren><de> Kontaktieren Sie uns, wenn Sie Fragen zum Unternehmen haben oder Presseinformationen erhalten möchten.
<G-vec00057-001-s339><contact.kontaktieren><en> any difficulty in paying our fees on time, we encourage you to contact us at the earliest opportunity in order to agree a revised payment schedule, alternative fee option or other solution.
<G-vec00057-001-s339><contact.kontaktieren><de> Wenn Sie Schwierigkeiten haben, unsere Gebühren pünktlich zu bezahlen, bitten wir Sie, uns so bald wie möglich zu kontaktieren, um einen überarbeiteten Zahlungsplan, eine alternative Gebührenoption oder eine andere Lösung zu vereinbaren.
<G-vec00057-001-s340><contact.kontaktieren><en> See RC200 literature pageor contact Rotork Sweden AB for further details.
<G-vec00057-001-s340><contact.kontaktieren><de> Schauen Sie sich für weitere Details dieLiteratur zum RC200 oder dieZeichnungen an oder kontaktieren SieRotork Sweden AB.
<G-vec00057-001-s341><contact.kontaktieren><en> If you are missing parts for the Kyosho Inferno VE Race Spec, please contact us by email.
<G-vec00057-001-s341><contact.kontaktieren><de> Sollten Sie Ersatzteile für den Kyosho Inferno VE Race Spec vermissen,kontaktieren Sie uns bitte per eMail.
<G-vec00057-001-s342><contact.kontaktieren><en> Contact us to learn more about TimeTac products.
<G-vec00057-001-s342><contact.kontaktieren><de> Kontaktieren Sie uns um mehr über die Produkte von Timetac zu erfahren.
<G-vec00057-001-s343><contact.kontaktieren><en> Contact this company SFM PLASTIK PROFIL...
<G-vec00057-001-s343><contact.kontaktieren><de> Kontaktieren Sie diese Firma SFM PLASTIK PROFIL...
<G-vec00057-001-s344><contact.kontaktieren><en> For information contact us at: office@csdp.ro We will reply with... Read More
<G-vec00057-001-s344><contact.kontaktieren><de> Für Informationen kontaktieren Sie uns unter: office@csdp.ro Va vom raspunde cu...
<G-vec00057-001-s345><contact.kontaktieren><en> Contact us if you cannot find your products on our website.
<G-vec00057-001-s345><contact.kontaktieren><de> Kontaktieren Sie uns, wenn Sie Ihre Produkte auf unserer Website nicht finden können.
<G-vec00057-001-s346><contact.kontaktieren><en> Contact this company TUTTO FOTOVOLTAICO...
<G-vec00057-001-s346><contact.kontaktieren><de> Kontaktieren Sie diese Firma KEWA...
<G-vec00057-001-s347><contact.kontaktieren><en> For a full copy of the report or to learn more, please contact Milevka Grceva (milevka.grceva@partnersgroup.com). < Back
<G-vec00057-001-s347><contact.kontaktieren><de> Bitte kontaktieren Sie Frau Milevka Grceva (milevka.grceva(at)partnersgroup.com), falls Sie Interesse an einer Druckversion der Studie haben oder weitere Informationen benötigen.
<G-vec00057-001-s348><contact.kontaktieren><en> Contact us for more information about Data Communications services and other TEMCare Managed Services.
<G-vec00057-001-s348><contact.kontaktieren><de> Kontaktieren Sie uns für mehr Informationen über die Datenübertragungs –Dienstleistungen und andere TEMCare geleitete Dienstleistungen.
<G-vec00057-001-s349><contact.kontaktieren><en> Submit the detailed inquiry information by clicking on the booking button or contact us form.
<G-vec00057-001-s349><contact.kontaktieren><de> Unterziehen Sie die Detail-Anfrage Informationen, indem Sie auf die Buchung Button klicken oder kontaktieren Sie uns nach Erhalt Form.
<G-vec00057-001-s350><contact.kontaktieren><en> Contact us to learn how to integrate multiple resellers and to earn money from them.
<G-vec00057-001-s350><contact.kontaktieren><de> Kontaktieren Sie uns und erfahren Sie, wie Sie verschiedene Reseller integrieren und Geld mit ihnen verdienen können.
<G-vec00057-001-s351><contact.kontaktieren><en> A:First, you can contact us by email, our professional staff will give you answer any questions.
<G-vec00057-001-s351><contact.kontaktieren><de> A: Zuerst können Sie uns per E-Mail kontaktieren, unsere professionellen Mitarbeiter geben Ihnen Beantworten Sie alle Fragen.
<G-vec00057-001-s352><contact.kontaktieren><en> If you have questions about what you are required to do contact E-Verify at 888-897-7781 (TTY: 877-875-6028) or e-mail E-Verify@dhs.gov .
<G-vec00057-001-s352><contact.kontaktieren><de> Wenn Sie Fragen darüber haben, was von Ihnen verlangt wird, kontaktieren Sie E-Verify unter 888-897-7781 (TTY: 877-875- 6028) oder per E-Mail E-Verify@dhs.gov .
<G-vec00057-001-s353><contact.kontaktieren><en> Contact us for more information and configuration support on the AIR-ANT25137NP-R4.
<G-vec00057-001-s353><contact.kontaktieren><de> Kontaktieren Sie uns für nähere Informationen und darüber, welche Konfiguration AIR-ANT25137NP-R4 unterstützt.
<G-vec00057-001-s354><contact.kontaktieren><en> Contact this company BUSINESS AND DRIVE,...
<G-vec00057-001-s354><contact.kontaktieren><de> Kontaktieren Sie diese Firma BUSINESS AND DRIVE,...
<G-vec00057-001-s355><contact.kontaktieren><en> Contact the owner of the domain dress2dance.de.
<G-vec00057-001-s355><contact.kontaktieren><de> Kontaktieren Sie den Inhaber der Domain architecho.de.
<G-vec00057-001-s356><contact.kontaktieren><en> Contact this company RONGCHENG CITY YIRAN...
<G-vec00057-001-s356><contact.kontaktieren><de> Kontaktieren Sie diese Firma RONGCHENG JINYUAN...
<G-vec00057-001-s357><contact.kontaktieren><en> If you are interested, feel free to contact us.
<G-vec00057-001-s357><contact.kontaktieren><de> Falls wir Ihr Interesse geweckt haben, kontaktieren Sie uns.
<G-vec00057-001-s358><contact.kontaktieren><en> If you are interested in offering a permanent home, please contact VOCAL.
<G-vec00057-001-s358><contact.kontaktieren><de> Wenn Sie einer Katze ein Zuhause geben möchten, kontaktieren Sie bitte VOCAL.
<G-vec00057-001-s359><contact.kontaktieren><en> Contact us today for your personalised offer.
<G-vec00057-001-s359><contact.kontaktieren><de> Kontaktieren Sie uns noch heute für Ihr persönliches Angebot.
<G-vec00057-001-s360><contact.kontaktieren><en> To participate in the promotion you must submit an application to the services of NTV-Plus online or by phone, or contact your nearest customer service centre of the company, its branch, Regional Center or partner organization.
<G-vec00057-001-s360><contact.kontaktieren><de> Um an der Aktion teilzunehmen müssen Sie die Dienste des NTV-Plus einen Antrag online oder per Telefon senden., oder kontaktieren Sie Ihren nächstgelegene Customer Servicecenter der Firma, Niederlassung, Regional Center oder Partner-Organisation.
<G-vec00057-001-s513><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the ASLAN Holding International GmbH.
<G-vec00057-001-s513><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der ASLAN Holding International GmbH wenden.
<G-vec00057-001-s514><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Wilhelm Gärtner GmbH Stanztechnik.
<G-vec00057-001-s514><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der Kurz & Spiegel GbR wenden.
<G-vec00057-001-s515><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Bio-Gate AG.
<G-vec00057-001-s515><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an den von der KUNDE_FIRMA bestellten Datenschutzbeauftragten oder einen anderen Mitarbeiter wenden.
<G-vec00057-001-s516><contact.sich_wenden><en> You can contact us at any time at the address given in the legal notice about this or on any other questions regarding personal data.
<G-vec00057-001-s516><contact.sich_wenden><de> Hierzu sowie zu weiteren Fragen zum Thema personenbezogene Daten können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.
<G-vec00057-001-s517><contact.sich_wenden><en> However, it is possible to contact the Office of the Ombudsman for Telecommunications by telephone, by calling 02 223 09 09, to find out as much as you can about your rights.
<G-vec00057-001-s517><contact.sich_wenden><de> Sie können sich jedoch auch telefonisch an den Ombudsdienst unter der Rufnummer 02 223 06 06 wenden, um umfassend über ihre Rechte aufgeklärt zu werden.
<G-vec00057-001-s518><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Nähmaschinenfabrik Emil Stuznäcker GmbH & Co. KG.
<G-vec00057-001-s518><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der Nähmaschinenfabrik Emil Stuznäcker GmbH & Co. KG wenden.
<G-vec00057-001-s519><contact.sich_wenden><en> Interested parties can contact Reuthers if they are keen to join the affiliate program.
<G-vec00057-001-s519><contact.sich_wenden><de> Interessenten können sich bei Interesse an Reuthers wenden, um für das Partnerprogramm freigeschaltet zu werden.
<G-vec00057-001-s520><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the ARGE Golf Festival Kitzbühel.
<G-vec00057-001-s520><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der ARGE Golf Festival Kitzbühel wenden.
<G-vec00057-001-s521><contact.sich_wenden><en> For this purpose, or in case of other questions relating to personal data, you can contact us at any time at the address provided in the Legal Notice.
<G-vec00057-001-s521><contact.sich_wenden><de> Hierzu sowie zu weiteren Fragen zum Thema personenbezogene Daten können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.
<G-vec00057-001-s522><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Dr. Martin van der Ven.
<G-vec00057-001-s522><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der CATHARA-design wenden.
<G-vec00057-001-s523><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the BD|SENSORS GmbH.
<G-vec00057-001-s523><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der BD|SENSORS GmbH wenden.
<G-vec00057-001-s524><contact.sich_wenden><en> The person concerned may contact TRADUguide at any time to assert the right to data transferability.
<G-vec00057-001-s524><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an TRADUguide wenden.
<G-vec00057-001-s525><contact.sich_wenden><en> To assert the right to data transferability, the person concerned can contact an employee of DIE NEUE SCHULE GbR at any time.
<G-vec00057-001-s525><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der DIE NEUE SCHULE GbR wenden.
<G-vec00057-001-s526><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the MIB GmbH.
<G-vec00057-001-s526><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der MIB GmbH wenden.
<G-vec00057-001-s527><contact.sich_wenden><en> We also invite you to contact CSD’s researchers directly by e-mail.
<G-vec00057-001-s527><contact.sich_wenden><de> Gerne können Sie sich auch per E-Mail direkt an die einzelnen Professoren des ZDEMO wenden.
<G-vec00057-001-s528><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of ORALIA.
<G-vec00057-001-s528><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der TWO.AG wenden.
<G-vec00057-001-s529><contact.sich_wenden><en> In the unlikely event that you are dissatisfied with an article purchased from us on board, you can of course contact us at any time.
<G-vec00057-001-s529><contact.sich_wenden><de> Sollten Sie einmal mit einem bei uns an Bord gekauften Artikel nicht zufrieden sein, können Sie sich selbstverständlich jederzeit uns wenden.
<G-vec00057-001-s530><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Markus Lerner Design.
<G-vec00057-001-s530><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der MLPD wenden.
<G-vec00057-001-s531><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of OMNIA Music VOF.
<G-vec00057-001-s531><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter von AOM Software wenden.
<G-vec00057-001-s551><contact.kontaktieren><en> Interested Persons should contact me with this below details .
<G-vec00057-001-s551><contact.kontaktieren><de> Interessierte Personen sollten Sie mich mit dieser unterhalb Details kontaktieren.
<G-vec00057-001-s552><contact.kontaktieren><en> If you would like to be accommodated in a hotel or villa, please contact us by e-mail to discuss your preferences.
<G-vec00057-001-s552><contact.kontaktieren><de> Falls Sie die Unterbringung in einem Hotel oder eine Villa (Landhaus in Istrien) wünschen, bitten wir Sie uns per E-Mail zu kontaktieren, um uns Ihre Wünsche (Präferenzen) mitzuteilen.
<G-vec00057-001-s553><contact.kontaktieren><en> Who to Contact: APEX PRINTER Email: apex@apex-jet.com ·If you are regular customers, you could call your sales representative for help.
<G-vec00057-001-s553><contact.kontaktieren><de> Wen Sie kontaktieren sollten: APEX-DRUCKER Email: apex@apex-jet.com · Wenn Sie Stammkunde sind, können Sie Ihren Vertriebsmitarbeiter um Hilfe bitten.
<G-vec00057-001-s554><contact.kontaktieren><en> Feel free to contact us. Sincerely,
<G-vec00057-001-s554><contact.kontaktieren><de> Fühlen Sie sich frei, uns zu kontaktieren.
<G-vec00057-001-s555><contact.kontaktieren><en> Feel free to contact us if you would like to discuss further.
<G-vec00057-001-s555><contact.kontaktieren><de> Fühlen Sie sich frei, uns zu kontaktieren, wenn Sie weiter diskutieren möchten.
<G-vec00057-001-s556><contact.kontaktieren><en> Request form Please confirm your details and the best time to call, and we'll contact you very shortly.
<G-vec00057-001-s556><contact.kontaktieren><de> zum Formular Bitte bestätigen Sie Ihre Angaben und nennen Sie uns einen günstigen Zeitpunkt, zu dem wir Sie anrufen können und wir werden Sie in Kürze kontaktieren.
<G-vec00057-001-s557><contact.kontaktieren><en> • Receive more leads as it allows prospects to contact, sign up or order directly from your ForeverGreen Screen.
<G-vec00057-001-s557><contact.kontaktieren><de> • Erhalten Sie mehr potentielle Kontakte denn es erlaubt Interessenten sie zu kontaktieren, sich einzuschreiben oder direkt über Ihren ForeverGreen Screen zu bestellen.
<G-vec00057-001-s558><contact.kontaktieren><en> Once the reservation has been made a representative will contact the guest to arrange this prepayment.
<G-vec00057-001-s558><contact.kontaktieren><de> Im Anschluss an Ihre Reservierung wird Sie ein Hotelmitarbeiter bezüglich der Vorauszahlung kontaktieren.
<G-vec00057-001-s559><contact.kontaktieren><en> If you have any interest in ourdoped molybdenum alloy or other molybdenum alloy products, please feel free to contact us by email:sales@chinatungsten.com,sales@xiamentungsten.com or by telephone:86 592 512 9696.
<G-vec00057-001-s559><contact.kontaktieren><de> Wenn Sie Interesse an unseren dotierten Molybdän-Legierung oder anderen Molybdän-Legierung Produkte haben, bitte zögern Sie nicht uns per E-Mail kontaktieren: sales@chinatungsten.com,sales@xiamentungsten.com oder per Telefon: 86 592 512 9696.
<G-vec00057-001-s560><contact.kontaktieren><en> Alternatively, you may contact our Concierge for instructions on how to send your watch directly to our service center.
<G-vec00057-001-s560><contact.kontaktieren><de> Alternativ können Sie auch unseren Concierge kontaktieren, der Ihnen erklären wird, wie Sie Ihre Uhr direkt an unser Servicecenter schicken können.
<G-vec00057-001-s561><contact.kontaktieren><en> If you have any interest in our molybdenum vadadium alloy or other molybdenum alloy products, please feel free to contact us by email:sales@chinatungsten.com,sales@xiamentungsten.com or by telephone:86 592 512 9696.
<G-vec00057-001-s561><contact.kontaktieren><de> Wenn Sie Interesse an unseren ZHM Legierung (Zirkonium Hafnium Molybdän-Legierung) oder andere Molybdän-Legierung Produkte haben, bitte zögern Sie nicht uns per E-Mail kontaktieren: sales@chinatungsten.com,sales@xiamentungsten.com oder per Telefon: 86 592 512 9696 .
<G-vec00057-001-s562><contact.kontaktieren><en> If you want to change the minimum and maximum deposit and withdrawal amounts, then customer service contact is required.
<G-vec00057-001-s562><contact.kontaktieren><de> Wenn Sie die minimale und maximale Einzahlung und Abhebungen in der Höhe abändern möchten, dann ist es erforderlich Sie kontaktieren den Kundenservice.
<G-vec00057-001-s563><contact.kontaktieren><en> Use MatchUp! to contact EXPO REAL participants of interest to you.
<G-vec00057-001-s563><contact.kontaktieren><de> Nutzen Sie die MatchUp!, um für Sie interessante EXPO REAL-Teilnehmer zu kontaktieren.
<G-vec00057-001-s564><contact.kontaktieren><en> Important information The property will contact the guest after the reservation is made to provide information about the check-in process.
<G-vec00057-001-s564><contact.kontaktieren><de> Wichtige Informationen Die Unterkunft wird Sie nach der Buchung kontaktieren, um Ihnen Informationen zum Check-in mitzuteilen.
<G-vec00057-001-s565><contact.kontaktieren><en> If you have decided to make a payment by credit card, please contact Euro Tours via e-mail or phone.
<G-vec00057-001-s565><contact.kontaktieren><de> Wenn Sie sich entschieden haben eine Zahlung per Kreditkarte zu leisten, bitten wir Sie dass Euro Tours Team per E-Mail oder Telefon zu kontaktieren.
<G-vec00057-001-s566><contact.kontaktieren><en> Contact the board administrator if you are unsure about why you are unable to add attachments.
<G-vec00057-001-s566><contact.kontaktieren><de> Sie können einen Administrator kontaktieren, falls Sie sich nicht sicher sind, wieso Sie keine Dateianhänge anfügen können.
<G-vec00057-001-s567><contact.kontaktieren><en> Feel free to contact your Personal Account Manager via live chat, email or by phone to schedule a presentation on MT4
<G-vec00057-001-s567><contact.kontaktieren><de> Zögern Sie nicht, Ihren persönlichen Kundenbetreuer per Live-Chat, E-Mail oder Telefon zu kontaktieren, um eine Präsentation über MT4 zu vereinbaren.
<G-vec00057-001-s568><contact.kontaktieren><en> There are also other ways to contact the FSF.
<G-vec00057-001-s568><contact.kontaktieren><de> Sie können auch die Free Software Foundation kontaktieren.
<G-vec00057-001-s569><contact.kontaktieren><en> Then you need to contact your registrar and ask him to register this dns name as its own primary nameserver (see the schema below).
<G-vec00057-001-s569><contact.kontaktieren><de> In diesem Fall müssen Sie Ihren DNS-Agenten kontaktieren und fragen, diesen DNS-Namen als seinen eigenen primären Nameserver zu registrieren (siehe das Schema weiter unten).
<G-vec00057-001-s589><contact.treten><en> This duality is fundamental to every religion, its roots lie in old cultic ceremonies like the ghost dance which the native Americans used to put themselves into a trance in order to get in contact with the dead.
<G-vec00057-001-s589><contact.treten><de> Diese Dualität liegt jeder Religion zugrunde, sie wurzelt in alten kultischen Zeremonien, wie etwa dem Geistertanz, mit dem sich die amerikanischen Ureinwohner in einen tranceartigen Zustand versetzten, um in Verbindung mit ihren Toten zu treten.
<G-vec00057-001-s590><contact.treten><en> Welcome to visit our factory at any time, If any questions, pls feel free to contact us.
<G-vec00057-001-s590><contact.treten><de> Willkommen, zum unserer Fabrik jederzeit zu besichtigen, wenn irgendwelche Fragen, pls frei sich fühlen, mit uns in Verbindung zu treten.
<G-vec00057-001-s591><contact.treten><en> Any feedback or inquiry of Tungsten Copper Alloy Products please feel free to contact us: Email: sales@chinatungsten.com Tel.
<G-vec00057-001-s591><contact.treten><de> Wolfram oder Kupfer Wolfram Rückgespräch oder Anfrage von Wolfram Kupferlegierung Produkte fühlen bitte sich frei, mit uns in Verbindung zu treten: Email: sales@chinatungsten.com Tel.
<G-vec00057-001-s592><contact.treten><en> If you are interested in 2b cold rolled stainless steel coilor any question, please feel free to contact us.
<G-vec00057-001-s592><contact.treten><de> Wenn Sie an 2b kaltgewalzter Edelstahlspule oder an irgendeiner Frage interessiert sind, fühlen Sie bitte sich frei, mit uns in Verbindung zu treten.
<G-vec00057-001-s593><contact.treten><en> Do not refuse to contact any group, even if it consists of only three persons; make it the one sole condition that it should be reliable as far as police spying is concerned and prepared to fight the tsar's troops.
<G-vec00057-001-s593><contact.treten><de> Weigert euch nicht, mit jedem Zirkel in Verbindung zu treten, auch wenn er nur aus drei Personen besteht, unter der einzigen Bedingung, daß er in bezug auf die Polizei unverdächtig und bereit ist, gegen die zaristischen Truppen zu kämpfen.
<G-vec00057-001-s594><contact.treten><en> * Welcome to contact us, sample is available.
<G-vec00057-001-s594><contact.treten><de> * Welcome, zum mit uns in Verbindung zu treten, Probe ist verfügbar.
<G-vec00057-001-s595><contact.treten><en> The item comes from a legitimate maker whom you can contact at any moment – 24 Hr, 7 days a week.
<G-vec00057-001-s595><contact.treten><de> Der Artikel stammt von einem legitimen Hersteller, die Sie jederzeit in Verbindung treten können – 24 Hr, 7 Tage die Woche.
<G-vec00057-001-s596><contact.treten><en> Need more details pls feel free to contact us. Contact us if you need more details on Plastic Tap.
<G-vec00057-001-s596><contact.treten><de> Benötigen Sie mehr Details pls fühlen sich frei, mit uns in Verbindung zu treten.
<G-vec00057-001-s597><contact.treten><en> We also have many other inflatable planetarium domes, for more option and details, please feel free to contact us.
<G-vec00057-001-s597><contact.treten><de> Wir haben auch viele andere aufblasbare Planetariumkuppeln, für mehr Wahl und Details, fühlen bitte sich frei, mit uns in Verbindung zu treten.
<G-vec00057-001-s598><contact.treten><en> Those who are interested in becoming students should contact the individual schools for accurate tuition and fee information.
<G-vec00057-001-s598><contact.treten><de> Diejenigen, die daran interessiert sind, Studierenden sollen die einzelnen Schulen zur genauen Unterricht und die Gebühreninformationen in Verbindung zu treten.
<G-vec00057-001-s599><contact.treten><en> In this case, you need to immediately contact the child's doctor and dentist with him to decide when to wean the child from the pacifier.
<G-vec00057-001-s599><contact.treten><de> In diesem Fall müssen Sie sofort den Arzt des Kindes in Verbindung treten und Zahnarzt mit ihm zu entscheiden, wann das Kind aus dem Schnuller zu entwöhnen.
<G-vec00057-001-s600><contact.treten><en> As a very prospective manufacture, we have developed more designs . If you are interesting and have any needs please feel free to contact me, It is my pleasure to offer news to you regular.
<G-vec00057-001-s600><contact.treten><de> Wenn Sie interessant sind und haben alle Bedürfnisse bitte mich frei fühlen in Verbindung zu treten, es ist mein Vergnügen, Nachrichten regelmäßig zu Ihnen zu bieten.
<G-vec00057-001-s601><contact.treten><en> However, only one person bothered to contact me on the basis of the information given in the leaflet.
<G-vec00057-001-s601><contact.treten><de> Jedoch störte nur eine Person, mit mir auf der Grundlage von die Informationen in Verbindung zu treten, die im Blättchen gegeben wurden.
<G-vec00057-001-s602><contact.treten><en> Good pre&after-sales service: Any problem please feel free to contact us, we will always be online for you.
<G-vec00057-001-s602><contact.treten><de> Guter Pre&afterverkaufsservice: Jedes mögliches Problem fühlen bitte sich frei, mit uns in Verbindung zu treten, wir sein immer online für Sie.
<G-vec00057-001-s603><contact.treten><en> Any question, please feel free to contact with us, we will do our best to assist you.
<G-vec00057-001-s603><contact.treten><de> Irgendwelche Frage, fühlen Sie bitte sich frei, mit uns in Verbindung zu treten, wir tun unser Bestes, um Ihnen zu helfen.
<G-vec00057-001-s604><contact.treten><en> Important information 5 days before arrival, the property will contact the guest by e-mail to confirm estimated arrival time and provide a contact phone number.
<G-vec00057-001-s604><contact.treten><de> Wichtige Informationen 5 Tage vor Anreise wird die Unterkunft mit Ihnen per E-Mail in Verbindung treten, um die voraussichtliche Ankunftszeit zu bestätigen und eine Kontakttelefonnummer zu hinterlegen.
<G-vec00057-001-s605><contact.treten><en> Most of customer are foreigner, If you have any project that we can support you, pls do not hesitate to contact us.
<G-vec00057-001-s605><contact.treten><de> Die meisten Kunden sind Ausländer, wenn Sie irgendein Projekt haben, das wir Sie unterstützen können, pls zögern nicht, mit uns in Verbindung zu treten.
<G-vec00057-001-s606><contact.treten><en> You have the option to provide your personal data to Aristo for the use in the CV database or the subcontractor database, to thereby establish contact quickly and expediently with potential employers or clients.
<G-vec00057-001-s606><contact.treten><de> Sie haben die Möglichkeit, Ihre persönlichen Daten Aristo zur Nutzung in die Lebenslauf-Datenbank oder die Datenbank als Subunternehmer zur Verfügung zu stellen, um dadurch schnell und zielführend mit potenziellen Arbeitgebern oder Auftraggebern in Verbindung zu treten.
<G-vec00057-001-s607><contact.treten><en> Those with questions can contact the brand and even order over the phone.
<G-vec00057-001-s607><contact.treten><de> Diejenigen mit Fragen können die Marke in Verbindung treten und auch um über das Telefon.
<G-vec00057-001-s608><contact.sich_wenden><en> At this critical stage, a child is likely to hear words spoken in L2 and physically turn to the source of L2, often holding eye contact with the source of L2.
<G-vec00057-001-s608><contact.sich_wenden><de> In diesem kritischen Stadium ist dem Kind möglich, die Wörter die in L2 gesprochen werden zu hören, und sich an die Quelle von L2 physikalisch zu wenden und hält dabei Blickkontakt mit der Quelle von L2.
<G-vec00057-001-s609><contact.sich_wenden><en> Prospective students should contact the admissions office of the schools in which they're interested to fully understand the costs.
<G-vec00057-001-s609><contact.sich_wenden><de> Studieninteressierte sollten die Zulassungsstelle der Schulen wenden, in denen sie interessiert sind zur Deckung der Kosten verstehen.
<G-vec00057-001-s610><contact.sich_wenden><en> For further information, please refer to our FAQs section or contact the Client Relations Center.
<G-vec00057-001-s610><contact.sich_wenden><de> "Für weitere Informationen hierzu siehe bitte unseren Abschnitt ""Häufig gestellte Fragen"" oder wenden Sie sich an unser Client-Relations-Center."
<G-vec00057-001-s611><contact.sich_wenden><en> Next he needs to contact his bank, there is often some processing time before a refund is posted.
<G-vec00057-001-s611><contact.sich_wenden><de> Als nächstes er seine Bank wenden muss, gibt es oft einige Verarbeitungszeit, bevor eine Rückerstattung gebucht wird.
<G-vec00057-001-s612><contact.sich_wenden><en> If this is not the case, then please use the contact form below to contact us.
<G-vec00057-001-s612><contact.sich_wenden><de> Ist dies nicht der Fall, Dann nutzen Sie bitte das untenstehende Kontaktformular an uns wenden.
<G-vec00057-001-s613><contact.sich_wenden><en> Please contact us by e-mail at datenschutz@suelzle-gruppe.de if you wish to object to your consent to the collection, processing and use of your data.
<G-vec00057-001-s613><contact.sich_wenden><de> Bitte wenden Sie sich per E-Mail an datenschutz@suelzle-gruppe.de, wenn Sie Ihre Einwilligung in die Erhebung, Verarbeitung und Nutzung Ihrer Daten widersprechen möchten.
<G-vec00057-001-s614><contact.sich_wenden><en> With this question, you can contact one of our psychologists, who had just engaged in family matters, including the restoration of the family after a divorce on the grounds of jealousy.
<G-vec00057-001-s614><contact.sich_wenden><de> Mit dieser Frage können Sie eine unserer Psychologen wenden, der in Familienangelegenheiten beteiligt war, einschließlich der Wiederherstellung der Familie nach einer Scheidung auf dem Gelände der Eifersucht.
<G-vec00057-001-s615><contact.sich_wenden><en> You can contact the competent supervisory authority to file the claim it deems appropriate.
<G-vec00057-001-s615><contact.sich_wenden><de> Sie können die zuständige Aufsichtsbehörde wenden, die Forderung es für angemessen hält einzureichen.
<G-vec00057-001-s616><contact.sich_wenden><en> Do not hesitate to contact us via the contact form.
<G-vec00057-001-s616><contact.sich_wenden><de> Sie können sich auch über das Kontaktformular an uns wenden.
<G-vec00057-001-s617><contact.sich_wenden><en> For questions please contact public.relations@suedzucker.de.
<G-vec00057-001-s617><contact.sich_wenden><de> Bei Fragen wenden Sie sich bitte an public.relations@suedzucker.de.
<G-vec00057-001-s618><contact.sich_wenden><en> By definition, the box is classified as combat, contact sport where opponents of each other to punch, wearing special gloves.
<G-vec00057-001-s618><contact.sich_wenden><de> Per Definition ist die Box als Kampf eingestuft wird, wenden Sport, wo Gegner von einander zu schlagen, trägt spezielle Handschuhe.
<G-vec00057-001-s619><contact.sich_wenden><en> "Fill out the form below and we will contact you about the ""Chalkboard Trees""."
<G-vec00057-001-s619><contact.sich_wenden><de> "Füllen Sie das folgende Formular aus und wir werden Sie für die Bereitstellung ""Kreidetafel Trees"" wenden."
<G-vec00057-001-s620><contact.sich_wenden><en> You may also contact: The provincial emergency helpline Samtalsakuten on 054-18 00 50 if you feel the need to talk with a professional counselor in Värmland.
<G-vec00057-001-s620><contact.sich_wenden><de> Sie können sich auch an folgende Nummern wenden: Die Bezirks-Notfallnummer Samtalsakuten 054-18 00 50, wenn Sie das Bedürfnis haben, mit einem professionellen Berater in Värmland zu sprechen.
<G-vec00057-001-s621><contact.sich_wenden><en> If you would like further advice on choosing the right airbrush accessory or have a specific question, feel free to contact us.
<G-vec00057-001-s621><contact.sich_wenden><de> Falls Du bei der Auswahl des richtigen Airbrush Zubehörs weiter beraten werden möchtest oder eine bestimmte Frage hast, kannst Du Dich gerne an uns wenden.
<G-vec00057-001-s622><contact.sich_wenden><en> Kindly take up contact with one of our lawyers specialized in European law.
<G-vec00057-001-s622><contact.sich_wenden><de> Bitte wenden sie sich an einen unserer Anwälte für Europäisches Recht .
<G-vec00057-001-s623><contact.sich_wenden><en> Please contact info@heisenhof.at for further information.
<G-vec00057-001-s623><contact.sich_wenden><de> Wenden Sie sich hierzu bitte ebenfalls an info@heisenhof.at.
<G-vec00057-001-s624><contact.sich_wenden><en> If you have further questions about data protection, please don’ t hesitate to contact us.
<G-vec00057-001-s624><contact.sich_wenden><de> Haben Sie weitere Fragen zum Thema Datenschutz, so können Sie sich jederzeit gerne an uns wenden.
<G-vec00057-001-s625><contact.sich_wenden><en> If you feel that we are violating this Privacy Statement, please contact us at info@fetal-cells.com.
<G-vec00057-001-s625><contact.sich_wenden><de> Wenn Sie meinen, dass wir diesen Datenschutzhinweis missachten, wenden Sie uns bitte an info@fetal-cells.com.
<G-vec00057-001-s626><contact.sich_wenden><en> Should you, in spite of the above, be convinced that Mollie unlawfully processed special or sensitive data, Mollie requests you to contact us at info@mollie.com or +31 20 820 20 70.
<G-vec00057-001-s626><contact.sich_wenden><de> Sollten Sie trotzdem der Ansicht sein, dass Mollie zu Unrecht besondere oder sensible Daten verarbeitet hat, möchten wir Sie bitten, sich per E-Mail an info@mollie.com oder telefonisch unter +49 (0)30 22 40 90 20 an Mollie zu wenden.
<G-vec00057-002-s304><contact.kontaktieren><en> If you reached this page from another part of our website, please contact us below so we can correct our mistake.
<G-vec00057-002-s304><contact.kontaktieren><de> Falls du von einem anderen Teil unserer Webseite hier gelandet bist, kontaktiere uns bitte damit wir den Fehler beheben können.
<G-vec00057-002-s305><contact.kontaktieren><en> Contact our support team at support@goconqr.com.
<G-vec00057-002-s305><contact.kontaktieren><de> Kontaktiere unser Support-Team unter hilfe@goconqr.com.
<G-vec00057-002-s306><contact.kontaktieren><en> Contact us using the “contact us” link on the bottom of this site to request an RMA number.
<G-vec00057-002-s306><contact.kontaktieren><de> Kontaktiere uns über den ''Kontakt'' Link am Ende dieser Seite um eine RMA Nummer zu beantragen.
<G-vec00057-002-s307><contact.kontaktieren><en> If you can’t find your driver, contact them through the app to confirm your location.
<G-vec00057-002-s307><contact.kontaktieren><de> Wenn du deinen Fahrer nicht finden kannst, kontaktiere ihn einfach über die App.
<G-vec00057-002-s308><contact.kontaktieren><en> Contact your bank to check that you have not exceeded the authorized purchase limit.
<G-vec00057-002-s308><contact.kontaktieren><de> Kontaktiere Deine Bank, um herauszufinden, ob Du Deinen autorisierten Verfügungsrahmen überschritten hast.
<G-vec00057-002-s309><contact.kontaktieren><en> Contact our Group Travel team directly for a tailor made solution for your group of the city in the famous Gozsdu-udvar.
<G-vec00057-002-s309><contact.kontaktieren><de> Kontaktiere unser Group Travel Team direkt und du bekommst von uns ein maßgeschneidertes Angebot speziell für deine Reisegruppe.
<G-vec00057-002-s310><contact.kontaktieren><en> Facebook Book Now, Contact Us, Use App, Play Game, Shop Now, Sign Up und Watch Video.
<G-vec00057-002-s310><contact.kontaktieren><de> Zur Option stehen „Jetzt buchen“, „Kontaktiere uns“, „App nutzen“, „Spielen“, „Jetzt einkaufen“, „Registrieren“ und „Video abspielen“.
<G-vec00057-002-s312><contact.kontaktieren><en> It is therefore best if you contact DB Stations and Services before your trip and inquire about how the station is currently equipped.
<G-vec00057-002-s312><contact.kontaktieren><de> Kontaktiere am besten vor Deiner Reise DB Stations und Services und frage nach der aktuellen Ausstattung des Bahnhofs.
<G-vec00057-002-s313><contact.kontaktieren><en> Please contact us if you’re interested.
<G-vec00057-002-s313><contact.kontaktieren><de> Bitte kontaktiere uns bei Interesse.
<G-vec00057-002-s316><contact.kontaktieren><en> Click "Contact the Advertiser" in the ad that interests you.
<G-vec00057-002-s316><contact.kontaktieren><de> Klicke "Kontaktiere den Werber" in der Anzeige, die dich interessiert.
<G-vec00057-002-s317><contact.kontaktieren><en> Au Pair Host Families from Slovenia – Contact them today for free and find out if you can be an Au Pair.
<G-vec00057-002-s317><contact.kontaktieren><de> Au Pair Gastfamilien aus Uruguay – Kontaktiere sie heute noch kostenlos und finde heraus, ob du ein Au Pair werden kannst.
<G-vec00057-002-s319><contact.kontaktieren><en> Au Pair Host Families from Morocco – Contact them today for free and find out if you can be an Au Pair.
<G-vec00057-002-s319><contact.kontaktieren><de> Au Pair Gastfamilien aus Marokko – Kontaktiere sie heute noch kostenlos und finde heraus, ob du ein Au Pair werden kannst.
<G-vec00057-002-s320><contact.kontaktieren><en> Contact friends and family and do your research.
<G-vec00057-002-s320><contact.kontaktieren><de> Kontaktiere Freunde und Familie oder informiere dich selbst.
<G-vec00057-002-s321><contact.kontaktieren><en> If you are unable to do this, please contact us via the Email Address.
<G-vec00057-002-s321><contact.kontaktieren><de> Wenn du dies nicht tun kannst, kontaktiere uns bitte über die E-Mail-Adresse.
<G-vec00057-002-s322><contact.kontaktieren><en> Please contact our customer support to get the details of these instructions.
<G-vec00057-002-s322><contact.kontaktieren><de> Bitte kontaktiere unseren Fairphone Kundenservice, um die genaue Vorgehensweise zu erfahren.
<G-vec00057-002-s323><contact.kontaktieren><en> All of our Alcoy property adverts are updated daily and you are free to contact the owner or agent directly.
<G-vec00057-002-s323><contact.kontaktieren><de> Alle unsere Little Cayman Immobilienanzeigen werden täglich aktualisiert und Sie sind frei, die Eigentümer oder Vertreter direkt zu kontaktieren.
<G-vec00057-002-s324><contact.kontaktieren><en> Whether you schedule your appointment online or contact our call center, you will need the 16-digit visa fee receipt number printed on your receipt.
<G-vec00057-002-s324><contact.kontaktieren><de> Wenn Sie online einen Termin vereinbaren oder unser Callcenter kontaktieren, benötigen Sie die CGI-Referenznummer oder die Transaktionsnummer auf Ihrem Beleg.
<G-vec00057-002-s325><contact.kontaktieren><en> If you would like to learn more about our products, need additional information, or would like to schedule a demonstration, please don’t hesitate to contact us. Get in touch
<G-vec00057-002-s325><contact.kontaktieren><de> Wenn Sie mehr über unsere Produkte erfahren möchten, weitere Informationen benötigen oder einen Termin für eine Gerätedemonstration vereinbaren möchten, zögern Sie bitte nicht, uns zu kontaktieren.
<G-vec00057-002-s326><contact.kontaktieren><en> If you have comments or questions regarding this privacy policy or other terms related to this website, please contact us via email.
<G-vec00057-002-s326><contact.kontaktieren><de> Falls Sie Bemerkungen oder Fragen zu unseren Richtlinien oder Geschäftsbedingungen haben, möchten wir Sie bitten, uns per Email zu kontaktieren.
<G-vec00057-002-s327><contact.kontaktieren><en> - New section FEATURED ARTISTS IMPORTANT If you bought the full game before, simply contact us at support@digixart.com and send us the related Apple's invoice to obtain compensation.
<G-vec00057-002-s327><contact.kontaktieren><de> - Discover WICHTIG Wenn Sie das vollständige Spiel vorher gekauft haben, kontaktieren Sie uns einfach unter support@digixart.com und schicken Sie uns die entsprechende Apple-Rechnung, um eine Entschädigung zu erhalten.
<G-vec00057-002-s328><contact.kontaktieren><en> If you are aware of any other file formats using the UPCASE file extension, please contact us so that we can update our information accordingly.
<G-vec00057-002-s328><contact.kontaktieren><de> Wenn Sie Kenntnis über weitere Dateiformate mit der UPCASE-Dateiendung erlangen, kontaktieren Sie uns bitte, damit wir unsere Daten entsprechend aktualisieren.
<G-vec00057-002-s329><contact.kontaktieren><en> Individuals should contact schools directly for current admission requirements and fees.
<G-vec00057-002-s329><contact.kontaktieren><de> Einzelpersonen sollten die Schulen direkt wegen der aktuellen Zulassungsvoraussetzungen und Gebühren kontaktieren.
<G-vec00057-002-s330><contact.kontaktieren><en> Compare all the plastic surgery clinics and contact the plastic surgeon in Antalya who's right for you.
<G-vec00057-002-s330><contact.kontaktieren><de> Vergleichen Sie alle Kliniken für Plastische Chirurgie und kontaktieren Sie passende Plastische Chirurgen in der Provinz Antalya.
<G-vec00057-002-s331><contact.kontaktieren><en> If you wish to object to the processing set out under C-F and no opt-out mechanism is available to you directly (for instance in your account settings), to the extent applicable, please contact pousadavb@oi.com.br .
<G-vec00057-002-s331><contact.kontaktieren><de> Falls Sie der unter den Punkten C - F beschriebenen Verarbeitung widersprechen möchten und keine Methode vorhanden ist, um sich entsprechend direkt abzumelden (zum Beispiel in den Kontoeinstellungen), dann kontaktieren Sie bitte pousadavb@oi.com.br .
<G-vec00057-002-s332><contact.kontaktieren><en> If you have questions about or need further information concerning the legal basis on which we collect and use your personal information, please contact us using the contact details provided under the “How to contact us” heading below.
<G-vec00057-002-s332><contact.kontaktieren><de> Wenn Sie Fragen zu der Rechtsgrundlage haben, auf der wir Ihre personenbezogenen Daten erheben und verwenden, oder weitere Informationen dazu benötigen, kontaktieren Sie uns bitte über die unten in dieser Datenschutzrichtlinie genannten Kontaktinformationen.
<G-vec00057-002-s333><contact.kontaktieren><en> Do not hesitate to contact us to request further information, book one of our courses or add other services to your holiday.
<G-vec00057-002-s333><contact.kontaktieren><de> Kontaktieren Sie uns für weitere Informationen, um einen unserer Kurse zu buchen oder um andere Leistungen zu erfragen.
<G-vec00057-002-s334><contact.kontaktieren><en> Step 3: Contact your new provider. This procedure will help you avoid delays in transferring your number
<G-vec00057-002-s334><contact.kontaktieren><de> Schritt 2: Kontaktieren Sie Ihren neuen Anbieter, um den Transfer Ihrer Nummer auszulösen.
<G-vec00057-002-s335><contact.kontaktieren><en> Our goal is to be as transparent and clear as possible but if you still have questions about how we process your personal data, please contact our Data Protection Officer.
<G-vec00057-002-s335><contact.kontaktieren><de> Unser Ziel ist es, so transparent und deutlich zu sein wie möglich, aber falls Sie weitere Fragen dazu haben, wie wir Ihre personenbezogenen Daten verarbeiten, kontaktieren Sie bitte unseren Datenschutzbeauftragten.
<G-vec00057-002-s336><contact.kontaktieren><en> If you want to share your knowledge about the .NK2 file with the users of FileExtension.info, write the description of the file, please contact us.
<G-vec00057-002-s336><contact.kontaktieren><de> Wenn Sie Ihr ganzes Wissen zum Thema der .MSW-Datei mit den Nutzern von FileDateiendung.info teilen möchten, ihn beschreiben möchten, kontaktieren Sie uns.
<G-vec00057-002-s337><contact.kontaktieren><en> If you have specific questions about clinical trials at the Comprehensive Cancer Center Zürich, don't hesitate to contact us.
<G-vec00057-002-s337><contact.kontaktieren><de> Falls Sie spezifische Fragen zu klinischen Studien am Comprehensive Cancer Center Zürich haben, zögern Sie nicht uns zu kontaktieren.
<G-vec00057-002-s338><contact.kontaktieren><en> Stay the LEDs still dark, please contact the Support.
<G-vec00057-002-s338><contact.kontaktieren><de> Bleiben die LEDs dennoch dunkel kontaktieren Sie bitte den Support.
<G-vec00057-002-s339><contact.kontaktieren><en> If you are missing parts from Maverick, please contact us by email.
<G-vec00057-002-s339><contact.kontaktieren><de> Sollten Sie Ersatzteile von Maverick vermissen,kontaktieren Sie uns bitte per eMail.
<G-vec00057-002-s340><contact.kontaktieren><en> To stay or sleep in Pickett, OK or Saulsbury, WV, you can contact without commitment: Hotels, b&b, country house, camping,guest house, lodging etc.
<G-vec00057-002-s340><contact.kontaktieren><de> Zu bleiben oder schlafen in McElhattan, PA oder Bowlby, WV, kontaktieren Sie unverbindlich: Hotels, B & B, Landhaus, camping, Gästehaus, Unterkunft usw..
<G-vec00057-002-s341><contact.kontaktieren><en> Please contact us via phone, email or in person at our headquarters if you wish to exercise any of the above rights.
<G-vec00057-002-s341><contact.kontaktieren><de> Wenn Sie eines dieser Rechte nutzen möchten, kontaktieren Sie uns bitte telefonisch, per E-Mail oder persönlich an unserem Sitz.
<G-vec00057-002-s342><contact.kontaktieren><en> you are not sure if this product can be used with your Kärcher contact us.
<G-vec00057-002-s342><contact.kontaktieren><de> Falls Sie nicht sicher sind, ob dieser Artikel zu Ihrem Gerät passt, kontaktieren Sie uns.
<G-vec00057-002-s343><contact.kontaktieren><en> Contact this company MEIENBERG + CO....
<G-vec00057-002-s343><contact.kontaktieren><de> Kontaktieren Sie diese Firma ELMETHERM S.A....
<G-vec00057-002-s344><contact.kontaktieren><en> Contact the reception for more information or reservation.
<G-vec00057-002-s344><contact.kontaktieren><de> Kontaktieren Sie die Rezeption für weitere Informationen oder Reservierung.
<G-vec00057-002-s345><contact.kontaktieren><en> Please contact us for an indivudual quote.
<G-vec00057-002-s345><contact.kontaktieren><de> Bitte kontaktieren Sie uns, um ein individuelles Angebot einzuholen.
<G-vec00057-002-s346><contact.kontaktieren><en> Please contact FedEx if you are considering doing business with Canada.
<G-vec00057-002-s346><contact.kontaktieren><de> Bitte kontaktieren Sie FedEx, wenn Sie Geschäfte mit Kanada machen.
<G-vec00057-002-s347><contact.kontaktieren><en> Contact the owner of the domain freizeitreitsport.de.
<G-vec00057-002-s347><contact.kontaktieren><de> Kontaktieren Sie den Inhaber der Domain freizeitreitsport.de.
<G-vec00057-002-s348><contact.kontaktieren><en> Contact your web host and ask them to enable imagepng for PHP. August 2019
<G-vec00057-002-s348><contact.kontaktieren><de> Kontaktieren Sie Ihren Web-Hoster und bitten Sie um die Aktivierung der Funktion imagepng in PHP.
<G-vec00057-002-s349><contact.kontaktieren><en> Contact the owner of the domain garthof.de.
<G-vec00057-002-s349><contact.kontaktieren><de> Kontaktieren Sie den Inhaber der Domain garthof.de.
<G-vec00057-002-s350><contact.kontaktieren><en> Swissness Contact us in order to see if you might be allowed using Swiss emblems or the name of the Swiss Confederation.
<G-vec00057-002-s350><contact.kontaktieren><de> Aktualität Swissness Kontaktieren Sie uns, um zu sehen, ob und wie Sie Schweizer Embleme oder den Namen nutzen können.
<G-vec00057-002-s351><contact.kontaktieren><en> Contact this company RPS RAUSCHER &...
<G-vec00057-002-s351><contact.kontaktieren><de> Kontaktieren Sie diese Firma MARSONER & PARTNER...
<G-vec00057-002-s352><contact.kontaktieren><en> Please contact VICPAS for more information.
<G-vec00057-002-s352><contact.kontaktieren><de> Bitte kontaktieren Sie VICPAS für weitere Informationen.
<G-vec00057-002-s353><contact.kontaktieren><en> To request information on the use of your personal data, to opt-out and for any questions or comments about our privacy policy, please feel free to contact us on info@quot8.com or visit our website www.quot8.com to find the contact details of our closest office.
<G-vec00057-002-s353><contact.kontaktieren><de> Um Informationen über die Verwendung Ihrer persönlichen Daten anzufordern, sich abzumelden und Fragen oder Kommentare zu unserer Datenschutzerklärung zu erhalten, kontaktieren Sie uns bitte unter info@quot8.com oder besuchen Sie unsere Website www.quot8.com, sodass Sie die Kontaktdaten unseres nächstgelegenen Büros erhalten können.
<G-vec00057-002-s354><contact.kontaktieren><en> Contact the owner of the domain enib.de.
<G-vec00057-002-s354><contact.kontaktieren><de> Kontaktieren Sie den Inhaber der Domain enib.de.
<G-vec00057-002-s355><contact.kontaktieren><en> Contact the owner of the domain eifelworld.de.
<G-vec00057-002-s355><contact.kontaktieren><de> Kontaktieren Sie den Inhaber der Domain eifelworld.de.
<G-vec00057-002-s356><contact.kontaktieren><en> Contact us if you require to run the App on a closed Military System.
<G-vec00057-002-s356><contact.kontaktieren><de> Kontaktieren Sie uns, falls Sie die Anwendung in einem geschlossenen militärischen System nutzen wollen.
<G-vec00057-002-s357><contact.kontaktieren><en> Please contact us before submitting burned bones.
<G-vec00057-002-s357><contact.kontaktieren><de> Bitte kontaktieren Sie uns, bevor Sie verbrannte Knochen einsenden.
<G-vec00057-002-s358><contact.kontaktieren><en> Please contact us before leaving neutral(3 stars) or negative(1- 2 stars) feedback.
<G-vec00057-002-s358><contact.kontaktieren><de> Bitte kontaktieren Sie uns, bevor Sie ein neutrales (3 Sterne) oder negatives (1 - 2 Sterne) Feedback abgeben.
<G-vec00057-002-s359><contact.kontaktieren><en> Please note that you must contact the property informing about your arrival time as soon as your booking as been confirmed.
<G-vec00057-002-s359><contact.kontaktieren><de> Bitte kontaktieren Sie das Personal des Town House sobald Ihre Buchung bestätigt wird und teilen Sie Ihre Ankunftszeit mit.
<G-vec00057-002-s360><contact.kontaktieren><en> Contact this company SAUERSTOFFWERK...
<G-vec00057-002-s360><contact.kontaktieren><de> Kontaktieren Sie diese Firma SAUERSTOFFWERK...
<G-vec00057-002-s532><contact.kontaktieren><en> Please contact us by e-mail or phone if you need assistance.
<G-vec00057-002-s532><contact.kontaktieren><de> Sollten Sie bei der Berechnung Hilfe benötigen, bitten wir Sie uns telefonisch oder per E-Mail zu kontaktieren.
<G-vec00057-002-s533><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you want to exercise any of the rights you have under this notice, you are welcome to contact us at res@villasonate.com .
<G-vec00057-002-s533><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@terregialle.com kontaktieren.
<G-vec00057-002-s534><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you wish to exercise any of the rights you have under this notice, you are welcome to contact us via info@hotels2go.it .
<G-vec00057-002-s534><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@hotels2go.it kontaktieren.
<G-vec00057-002-s535><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you want to exercise any of the rights you have under this notice, you are welcome to contact us at administracion@hotelplanas.net .
<G-vec00057-002-s535><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@leipzig-zimmer.de kontaktieren.
<G-vec00057-002-s536><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you want to exercise any of the rights you have under this notice, you are welcome to contact us at vischnou1@hotmail.fr .
<G-vec00057-002-s536><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über vischnou1@hotmail.fr kontaktieren.
<G-vec00057-002-s537><contact.kontaktieren><en> Why not contact us before a trade fair you intend to visit.
<G-vec00057-002-s537><contact.kontaktieren><de> Wir würden uns freuen, wenn Sie uns bereits im Vorfeld einer Messe kontaktieren würden.
<G-vec00057-002-s538><contact.kontaktieren><en> Tell us details of your plan and we will contact you to organize an amazing adventure.
<G-vec00057-002-s538><contact.kontaktieren><de> Erzählen Sie uns mehr von Ihrem Plan und wir werden Sie kontaktieren, um ein unglaubliches Abenteuer zu organisieren.
<G-vec00057-002-s539><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you want to exercise any of the rights you have under this notice, you are welcome to contact us at info@adelaidehostel.com .
<G-vec00057-002-s539><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@gondaapartments.cz kontaktieren.
<G-vec00057-002-s540><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you wish to exercise any of the rights you have under this notice, you are welcome to contact us via info@villaclementine.com .
<G-vec00057-002-s540><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@bbgentes.com kontaktieren.
<G-vec00057-002-s541><contact.kontaktieren><en> Before you contact us, be ready with your product’s serial number, your Apple ID and password. Find your product’s serial number
<G-vec00057-002-s541><contact.kontaktieren><de> Stellen Sie sicher, dass Sie die Seriennummer Ihres Geräts, Ihre Apple-ID und Ihr Passwort bereithalten, wenn Sie uns kontaktieren.
<G-vec00057-002-s542><contact.kontaktieren><en> Or contact us directly yourself.
<G-vec00057-002-s542><contact.kontaktieren><de> Oder Sie kontaktieren uns persönlich.
<G-vec00057-002-s543><contact.kontaktieren><en> Alternatively, feel free to contact us, and we’ll help you out.
<G-vec00057-002-s543><contact.kontaktieren><de> Alternativ können Sie auch uns kontaktieren, wir helfen Ihnen gerne weiter.
<G-vec00057-002-s544><contact.kontaktieren><en> Feel free to contact our Engineers for a custom solution.
<G-vec00057-002-s544><contact.kontaktieren><de> Gerne können Sie einen unserer Ingenieure für eine persönliche Beratung kontaktieren.
<G-vec00057-002-s545><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you want to exercise any of the rights you have under this notice, you are welcome to contact us at info@freedom-traveller.it .
<G-vec00057-002-s545><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@castrumnovum.com kontaktieren.
<G-vec00057-002-s546><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you want to exercise any of the rights you have under this notice, you are welcome to contact us at info@residencekale.com .
<G-vec00057-002-s546><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über info@residencekale.com kontaktieren.
<G-vec00057-002-s547><contact.kontaktieren><en> 52-54, 04275 Leipzig, or contact the operator of this website through the stated contact details within the imprint.
<G-vec00057-002-s547><contact.kontaktieren><de> 52-54, 04275 Leipzig oder Sie kontaktieren den Betreiber dieser Webseite unter den im Impressum angegebenen Kontaktdaten.
<G-vec00057-002-s548><contact.kontaktieren><en> If you have questions or concerns about our processing of your personal data, or if you wish to exercise any of the rights you have under this notice, you are welcome to contact us via kartanohotelli@karhulanhovi.fi .
<G-vec00057-002-s548><contact.kontaktieren><de> Falls Sie Fragen oder Bedenken über die Verarbeitung Ihrer personenbezogenen Daten haben, oder falls Sie Bedenken zu der Verarbeitung Ihrer persönlichen Daten haben, oder falls Sie Ihre in dieser Bekanntmachung beschriebenen Rechte beanspruchen möchten, dann können Sie uns über debbierurka@hotmail.com kontaktieren.
<G-vec00057-002-s549><contact.kontaktieren><en> Send an email to the ask a student team and an International Business student will contact you.
<G-vec00057-002-s549><contact.kontaktieren><de> Dann schreiben Sie eine E-Mail an das Ask a student-Team und ein International Business-Student wird Sie kontaktieren.
<G-vec00057-002-s550><contact.kontaktieren><en> We may also use this information for contact purposes for events and courses.
<G-vec00057-002-s550><contact.kontaktieren><de> Wir sind auch berechtigt, diese Daten zu verwenden, um Sie bezüglich Veranstaltungen und Fortbildungskursen zu kontaktieren.
<G-vec00057-002-s570><contact.sich_wenden><en> You are to contact the distribution partner from whom you purchased the Tickets as regards your claim to reimbursement of the Ticket Purchase Price, not including the paid charges.
<G-vec00057-002-s570><contact.sich_wenden><de> 4.5 Sie haben sich wegen des Anspruchs auf Rückerstattung des Ticketkaufpreises mit Ausnahme der gezahlten Gebühren an den Vertriebspartner zu wenden, bei dem Sie die Tickets erworben haben.
<G-vec00057-002-s571><contact.sich_wenden><en> If you have any questions or are interested in our products,please feel free to contact us.
<G-vec00057-002-s571><contact.sich_wenden><de> Wenn Sie Fragen haben oder an unseren Produkten interessiert sind, können Sie sich gerne an uns wenden.
<G-vec00057-002-s572><contact.sich_wenden><en> To gain access, you may contact your local contact person at HUBER Packaging.
<G-vec00057-002-s572><contact.sich_wenden><de> Um einen Zugang zu erhalten, dürfen Sie sich gerne an Ihren zuständigen Ansprechpartner bei HUBER Packaging wenden.
<G-vec00057-002-s573><contact.sich_wenden><en> Consumers can contact the competent consumer arbitration board for this purpose: Contact: Strassburger Str.
<G-vec00057-002-s573><contact.sich_wenden><de> Verbraucher können sich hierzu an die zuständige Verbraucherschlichtungsstelle wenden: Allgemeine Verbraucherschlichtungsstelle des Zentrums für Schlichtung e.
<G-vec00057-002-s574><contact.sich_wenden><en> If you have questions on data protection or want to assert your rights as person affected, please contact the contact address specified in the Imprint.
<G-vec00057-002-s574><contact.sich_wenden><de> Wenn Sie Fragen zum Datenschutz haben oder Ihre Betroffenenrechte geltend machen wollen, dann können Sie sich gern an die im Impressum angegebene Kontaktadresse wenden.
<G-vec00057-002-s575><contact.sich_wenden><en> You can get in touch with us using the contact data specified in Section 1 “Responsibility for data processing and contact data” to exercise the above rights.
<G-vec00057-002-s575><contact.sich_wenden><de> Zur Ausübung der vorgenannten Rechte können Sie sich an die im ersten Abschnitt – Allgemeine Informationen unter Ziffer 1 und 2 genannten Stellen wenden.
<G-vec00057-002-s576><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of YOUR PHOTOGRAPHERS.
<G-vec00057-002-s576><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter von Hieronymus Reisen wenden.
<G-vec00057-002-s577><contact.sich_wenden><en> Make sure there is someone on a stand to receive the delivery- For deliveries in the run-up to the fair, please contact one of our service partners.
<G-vec00057-002-s577><contact.sich_wenden><de> Für Lieferungen im Vorfeld der Messe wenden Sie sich bitte an einen unserer Spediteure.
<G-vec00057-002-s578><contact.sich_wenden><en> If you discover that you have purchased a counterfeited good, you will have to contact directly that seller.
<G-vec00057-002-s578><contact.sich_wenden><de> Wenn Sie feststellen, dass Sie eine Fälschung erworben haben, müssen Sie sich im Falle einer Reklamation direkt an den betreffenden Verkäufer wenden.
<G-vec00057-002-s579><contact.sich_wenden><en> If you do not find the manual / guide you need, you are always welcome to contact our service department, who is always ready to assist you with your inquiry.
<G-vec00057-002-s579><contact.sich_wenden><de> Wenn Sie die gewünschten Handbücher/Leitfäden nicht finden, wenden Sie sich gerne an unsere Kundenberatung, die Ihnen jederzeit behilflich ist.
<G-vec00057-002-s580><contact.sich_wenden><en> If you have any questions or remarks, please don’t hesitate to contact him.
<G-vec00057-002-s580><contact.sich_wenden><de> Falls Sie Fragen oder Anmerkungen haben, zögern Sie nicht, sich an ihn zu wenden.
<G-vec00057-002-s582><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Animal Kingdom Corporation.
<G-vec00057-002-s582><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter des Musikateliers Rostock wenden.
<G-vec00057-002-s583><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact the Data Protection Officer designated by the Symmonsroberts.com website or another employee.
<G-vec00057-002-s583><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der ALWID GmbH wenden.
<G-vec00057-002-s584><contact.sich_wenden><en> If you have questions just get in touch with your local contact person or call the Sortimo Team: +44 (0)1925 831636.
<G-vec00057-002-s584><contact.sich_wenden><de> Bei Fragen können Sie sich an Ihren persönlichen Ansprechpartner vor Ort wenden oder an das Sortimo Direct Team über die kostenfreie Hotline.
<G-vec00057-002-s585><contact.sich_wenden><en> If you have any further questions regarding the processing of your personal data, you are welcome to contact us.
<G-vec00057-002-s585><contact.sich_wenden><de> Soweit Sie weitere Fragen hinsichtlich der Verarbeitung Ihrer personenbezogenen Daten haben, können Sie sich gern an uns wenden.
<G-vec00057-002-s586><contact.sich_wenden><en> In order to assert the right to data portability, the data subject may at any time contact the Data Protection Officer designated by the Biovis Diagnostik MVZ GmbH or another employee.
<G-vec00057-002-s586><contact.sich_wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der UEBB wenden.
<G-vec00057-002-s587><contact.sich_wenden><en> Please contact your Subject Librarian if you want to order reference materials and please hand in the application form: Antrag Handapparateinrichtung.
<G-vec00057-002-s587><contact.sich_wenden><de> Bitte wenden Sie sich an das zuständige Fachreferat, wenn Sie einen Handapparat benötigen und reichen Sie den Antrag Handapparateinrichtung ein.
<G-vec00057-002-s588><contact.sich_wenden><en> If you are worried about your gambling or are affected by another person's gambling behaviour, please contact GamCare or GamblersAnonymous for help.
<G-vec00057-002-s588><contact.sich_wenden><de> Wenn Sie sich Sorgen um Ihr Glücksspiel machen oder vom Spielverhalten einer anderen Person besorgt sind, wenden Sie sich bei der Organisation Anonyme Spieler.
<G-vec00057-002-s589><contact.sich_wenden><en> If you made a mistake when ordering, please contact our customer service team at the email address: info@goldandroses.com who will be happy to assist you.
<G-vec00057-002-s589><contact.sich_wenden><de> Wenn Sie bei der Bestellung einen Fehler gemacht haben, wenden Sie sich bitte an unser Kundenservice-Team unter der E-Mail-Adresse: info@goldandroses.com, das Ihnen gerne weiterhilft.
<G-vec00057-002-s590><contact.sich_wenden><en> If you have any questions or concerns regarding privacy at Plarium, please contact our Support team at support.plarium.com.
<G-vec00057-002-s590><contact.sich_wenden><de> Bei Fragen und Bedenken zu Ihrem Datenschutz bei Plarium wenden Sie sich bitte an unserer Support-Team unter support@plarium.com.
<G-vec00057-002-s591><contact.sich_wenden><en> If you wish to have access to this information, please contact us at the above address.
<G-vec00057-002-s591><contact.sich_wenden><de> Wenn Sie auf diese Informationen zugreifen möchten, wenden Sie sich bitte an die oben genannte Adresse.
<G-vec00057-002-s592><contact.sich_wenden><en> If you have any questions, please contact emailing us at info@norkid.com
<G-vec00057-002-s592><contact.sich_wenden><de> Bei Fragen wenden Sie sich bitte an info@norkid.com.
<G-vec00057-002-s593><contact.sich_wenden><en> To request a personalised presentation and unique event session, please contact us on info@gubelinacademy.com
<G-vec00057-002-s593><contact.sich_wenden><de> Für mehr Informationen oder Anfragen bezüglich der Verfügbarkeit, wenden Sie sich bitte direkt unter info@gubelinacademy.com an uns.
<G-vec00057-002-s594><contact.sich_wenden><en> 2.7 If the travel documents are not delivered until 4 days before travel please contact immediately the tour operator or the travel agency where you booked the tour.
<G-vec00057-002-s594><contact.sich_wenden><de> 2.7 Sollten Ihnen die Reiseunterlagen nicht bis spätestens 4 Tage vor Reiseantritt zugegangen sein, wenden Sie sich bitte umgehend an Ihr Reisebüro.
<G-vec00057-002-s595><contact.sich_wenden><en> Given all the above, as well as all the additional information regarding this great land, please feel free to contact us by phone or contact form.
<G-vec00057-002-s595><contact.sich_wenden><de> Wenn Sie alle oben genannten Informationen sowie alle zusätzlichen Informationen zu diesem großartigen Land vorfinden, wenden Sie sich bitte telefonisch oder per Kontaktformular an uns.
<G-vec00057-002-s596><contact.sich_wenden><en> If you have any questions about this form, please contact us by emailing partners@buffalo-technology.com.
<G-vec00057-002-s596><contact.sich_wenden><de> Haben Sie Fragen zu diesem Formular, wenden Sie sich bitte per E-Mail an partners@buffalo-technology.com.
<G-vec00057-002-s597><contact.sich_wenden><en> If you are a user of another company’s product that relies on Intel® Anti-Theft Technology, please contact the company directly to learn more about its plans.
<G-vec00057-002-s597><contact.sich_wenden><de> Wenn Sie ein Produkt eines anderen Anbieters verwenden, das die Intel® Anti-Theft-Technik nutzt, wenden Sie sich bitte direkt an dieses Unternehmen, um weitere Informationen zu erhalten.
<G-vec00057-002-s598><contact.sich_wenden><en> If you have any questions, please contact Customer Service by e-mail at casupport@vitalimagery.com, or by phone at 1-800-482-4567, weekdays from 9 am to 5 pm EST.
<G-vec00057-002-s598><contact.sich_wenden><de> happen Wenn Sie Fragen haben, wenden Sie sich bitte an den Kundendienst per E-Mail unter casupport@vitalimagery.com, oder telefonisch unter 1-800-482-4567, wochentags von 9 bis 17 Uhr EST.
<G-vec00057-002-s599><contact.sich_wenden><en> If you think that we have collected Personal Information from a child under the age of 13, please contact us at [insert country level inbox email address].
<G-vec00057-002-s599><contact.sich_wenden><de> Wenn Sie der Meinung sind, dass wir persönliche Informationen von einem Kind unter 13 Jahren gesammelt haben, wenden Sie sich bitte an folgende E-Mail Adresse .
<G-vec00057-002-s600><contact.sich_wenden><en> If you wish to book for another individual, please contact the property directly for further information after booking.
<G-vec00057-002-s600><contact.sich_wenden><de> Wenn Sie für eine andere Person buchen, wenden Sie sich bitte nach der Buchung direkt an die Unterkunft.
<G-vec00057-002-s601><contact.sich_wenden><en> If you have forgotten your password or have not assigned one yet, please contact us atÂ support@miacara.com.
<G-vec00057-002-s601><contact.sich_wenden><de> Sollten Sie Ihr Passwort vergessen oder noch keins erhalten haben, wenden Sie sich bitte an support@miacara.com.
<G-vec00057-002-s602><contact.sich_wenden><en> Please contact our office using the contact form if you wish more information about manuals and check lists.
<G-vec00057-002-s602><contact.sich_wenden><de> Bei Fragen zu Handbüchern und Prüflisten wenden Sie sich bitte mit Hilfe des Kontaktformulars an unser Büro.
<G-vec00057-002-s603><contact.sich_wenden><en> If you have any questions, please contact Customer Service by e-mail at casupport@vitalimagery.com, or by phone at 1-800-482-4567, weekdays from 9 am to 5 pm EST.
<G-vec00057-002-s603><contact.sich_wenden><de> Überbleibsel Wenn Sie Fragen haben, wenden Sie sich bitte an den Kundendienst per E-Mail unter casupport@vitalimagery.com, oder telefonisch unter 1-800-482-4567, wochentags von 9 bis 17 Uhr EST.
<G-vec00057-002-s604><contact.sich_wenden><en> If you are interested please contact us at (e-mail in contact data) or +31 (0) 228 855 380 for more information or to make an appointment for viewing on board.
<G-vec00057-002-s604><contact.sich_wenden><de> Wenn Sie interessiert sind, wenden Sie sich bitte an (Email in den Kontaktdaten) oder +31(0)228 855 380 für weitere Informationen oder um einen Termin für eine Besichtigung an Bord zu vereinbaren.
<G-vec00057-002-s605><contact.sich_wenden><en> Booking: If you require a wheelchair or other type of mobility aid, please contact reservations at least 48 hours in advance of your flight so we can make the necessary arrangements.Up to 2 pieces of mobility equipment per person with a disability or person with reduced mobility can be booked.
<G-vec00057-002-s605><contact.sich_wenden><de> Buchung: Wenn Sie einen Rollstuhl oder eine andere Form an Mobilitätsbedarf benötigen, wenden Sie sich bitte mindestens 48 Stunden vor Abflug an die Reservierungsabteilung, damit die erforderlichen Vorkehrungen getroffen werden können.
<G-vec00057-002-s606><contact.sich_wenden><en> If you have any questions, please contact Corel Customer Service at 1-877-582-6735.
<G-vec00057-002-s606><contact.sich_wenden><de> Bei Fragen wenden Sie sich bitte an unseren Kundendienst unter 1-877-582-6735.
<G-vec00057-002-s607><contact.sich_wenden><en> If you have questions that are not answered by this privacy statement or if you wish to receive more detailed information, please contact us at any time mbH to the Supervisor of the hotel operating company.
<G-vec00057-002-s607><contact.sich_wenden><de> Wenn Sie Fragen haben, die Ihnen diese Datenschutzerklärung nicht beantworten konnte oder wenn Sie zu einem Punkt vertiefte Informationen wünschen, wenden Sie sich bitte jederzeit an den Datenschutzbeauftragten der Hotelbetriebs- gesellschaft mbH.
<G-vec00057-002-s190><contact.treten><en> This place invites you to be in contact with nature and at the same time, easy and quick access to the city.. .
<G-vec00057-002-s190><contact.treten><de> Dieser Ort lädt Sie ein, mit der Natur in Kontakt zu treten und gleichzeitig die Stadt schnell und einfach zu erreichen.. .
<G-vec00057-002-s191><contact.treten><en> We will need your email address in order to contact you if a third party should object to your comment as being unlawful.
<G-vec00057-002-s191><contact.treten><de> Ihre E-Mail-Adresse benötigen wir, um mit Ihnen in Kontakt zu treten, falls ein Dritter Ihren Kommentar als rechtswidrig beanstanden sollte.
<G-vec00057-002-s192><contact.treten><en> Through educational books, even very young children can learn more about other habitats and also how to treat the environment respectfully." She would therefore also be delighted to establish contact with schools or other educational institutions and to inform them about her research.
<G-vec00057-002-s192><contact.treten><de> Durch lehrreiche Kinderbücher können schon die ganz Kleinen mehr über andere Lebensräume lernen und auch darüber, respektvoll mit der Umwelt umzugehen.“ Sie ist daher ebenfalls gern bereit, mit Schulen oder anderen Bildungseinrichtungen in Kontakt zu treten und dort über ihre Forschung zu berichten.
<G-vec00057-002-s193><contact.treten><en> At ETH your company has the chance of taking part in a number of fairs, where students and doctoral students can find out about your business, and where you can make contact with talented people who are interested in your company.
<G-vec00057-002-s193><contact.treten><de> An der ETH haben Sie als Firma die Möglichkeit, an verschiedenen Messen teilzunehmen und so Ihr Unternehmen bei den Studierenden und Doktorierenden bekannt zu machen und mit interessierten Talenten in Kontakt zu treten.
<G-vec00057-002-s194><contact.treten><en> I am already looking forward to be able to contact you in contact and to be able to spend an erotic good time.
<G-vec00057-002-s194><contact.treten><de> Ich freue mich bereits jetzt, mit dir In Kontakt treten zu dürfen und eine erotische schöne Zeit verbringen zu können.
<G-vec00057-002-s195><contact.treten><en> If one weighs the child’s interest in having steady contact with both parents against a parent’s interest in not wanting or no longer wanting to have personal contact with it, then one should accord the child’s desire considerably more weight than the parent’s wishes.
<G-vec00057-002-s195><contact.treten><de> Wägt man das Interesse des Kindes an einem gedeihlichen Umgang mit seinen beiden Elternteilen mit dem Interesse eines Elternteils ab, mit dem Kind nicht in persönlichen Kontakt treten zu wollen, dann ist dem kindlichen Anliegen gegenüber dem elterlichen Wunsch ein erheblich größeres Gewicht beizumessen.
<G-vec00057-002-s196><contact.treten><en> TUI and Travelview may collect impersonal identification information from Users every time they come into contact with P6A.
<G-vec00057-002-s196><contact.treten><de> TUI und Travelview können Informationen zur nicht persönlichen Identifizierung der Benutzer immer dann erfassen, wenn diese mit P6A in Kontakt treten.
<G-vec00057-002-s197><contact.treten><en> In today's dynamic daily life, we rarely have the opportunity to contact nature.
<G-vec00057-002-s197><contact.treten><de> Im heutigen dynamischen Alltag haben wir selten die Möglichkeit, mit der Natur in Kontakt zu treten.
<G-vec00057-002-s198><contact.treten><en> Germany is not the market! When it comes to contact with the potential customer / user of a product, we need to go international.
<G-vec00057-002-s198><contact.treten><de> Wenn es darum geht, mit dem potentiellen Kunden/Nutzer eines Produkts in Kontakt zu treten, muss der Weg weg von sozialen Medien hin zu „social media“ gehen.
<G-vec00057-002-s199><contact.treten><en> Language exchange sites allow you to make contact with people from around the world that want to learn a language in a cool and efficient way through meeting new people, and without spending any money to do so.
<G-vec00057-002-s199><contact.treten><de> Durch Seiten für den Online-Sprachaustausch oder zum Finden eines Tandempartners haben Sie die Möglichkeit, mit Menschen aus der ganzen Welt in Kontakt zu treten, die wie Sie eine Sprache auf eine abwechslungsreiche und effiziente Art lernen wollen, indem Sie neue Bekanntschaften schließen und kein Geld ausgeben.
<G-vec00057-002-s200><contact.treten><en> In the campaign as well as in the sandbox mode, the player can get into contact with these guilds and have profitable diplomatic relationships with the.
<G-vec00057-002-s200><contact.treten><de> Der Spieler kann sowohl in der Kampagne als auch im freien Spiel mit den Gilden in Kontakt treten und lohnende diplomatische Beziehungen aufbauen.
<G-vec00057-002-s201><contact.treten><en> EN Contact form Please fill in the form below to contact us.
<G-vec00057-002-s201><contact.treten><de> EN Kontakt Füllen Sie bitte untenstehendes Formular aus, um mit uns in Kontakt zu treten.
<G-vec00057-002-s202><contact.treten><en> Adventure and culture travelers can browse and compare tours and get into direct contact with the operator or the DMC.
<G-vec00057-002-s202><contact.treten><de> Abenteuer-und Kulturreisende können nach Touren in Ihrer Region suchen und direkt mit dem lokalen Anbieter in Kontakt treten.
<G-vec00057-002-s203><contact.treten><en> The research, production and interpretation of our projects brought us into contact with book authors, curators, musicians, and many other interesting and innovative media people.
<G-vec00057-002-s203><contact.treten><de> Unsere Recherche, die Herstellung und Auswertung unserer Projekte lässt uns mit Buchautoren, Ausstellungsmachern, Musikern, und vielen anderen Medienmenschen in Kontakt treten.
<G-vec00057-002-s204><contact.treten><en> In many ways, hyperobjects, albeit at least partly created by humans, may come closest to a human-alien encounter in our present time, they in fact may mark a historical moment in which non-humans could make a decisive and irrevocable contact with humans.
<G-vec00057-002-s204><contact.treten><de> In vielerlei Hinsicht könnten Hyperobjekte, auch wenn sie zumindest teilweise vom Menschen erschaffen wurden, einer gegenwärtigen Begegnung von Mensch und Alien am nächsten kommen; tatsächlich könnten sie einen historischen Moment darstellen, an dem Nicht-Menschen und Menschen in einen entscheidenden und unwiderruflichen Kontakt treten.
<G-vec00057-002-s205><contact.treten><en> 129 We're looking forward to getting in contact with you.
<G-vec00057-002-s205><contact.treten><de> 129 Wir freuen uns, wenn Sie mit uns in Kontakt treten.
<G-vec00057-002-s206><contact.treten><en> 3. mobilelearningarena on the LEARNTEC 2007 of 13. - a forum offers 15.02.2006, in order to become acquainted with and step with experts into contact mobiles learning.
<G-vec00057-002-s206><contact.treten><de> Die 3. mobilelearningarena auf der LEARNTEC 2007 vom 13.-15.02.2006 bietet ein Forum, um mobiles Lernen kennenzulernen und mit Experten in Kontakt zu treten.
<G-vec00057-002-s207><contact.treten><en> The regional Organisation of the groups has the advantage that buyers and sellers can directly contact each other, and changes to the product, such as at a flea market and directly from Hand to Hand.
<G-vec00057-002-s207><contact.treten><de> Die regionale Organisation der Gruppen hat den Vorteil, dass Käufer und Verkäufer direkt miteinander in Kontakt treten können und die Ware wie auf einem Flohmarkt direkt von Hand zu Hand wechselt.
<G-vec00057-002-s208><contact.treten><en> Eosta/Nature&More processes your personal data in order to be able to contact you by telephone if you request this, and/or to be able to contact you in writing (by e-mail and/or by post) if you cannot be reached by telephone.
<G-vec00057-002-s208><contact.treten><de> Eosta/Nature & More verarbeitet Ihre personenbezogenen Daten, um Sie auf Wunsch per Telefon kontaktieren zu können und/oder um mit Ihnen schriftlich (per E-Mail und/oder per Post) in Kontakt treten zu können, sollten Sie telefonisch nicht erreichbar sein.
<G-vec00057-002-s570><contact.wenden><en> You are to contact the distribution partner from whom you purchased the Tickets as regards your claim to reimbursement of the Ticket Purchase Price, not including the paid charges.
<G-vec00057-002-s570><contact.wenden><de> 4.5 Sie haben sich wegen des Anspruchs auf Rückerstattung des Ticketkaufpreises mit Ausnahme der gezahlten Gebühren an den Vertriebspartner zu wenden, bei dem Sie die Tickets erworben haben.
<G-vec00057-002-s571><contact.wenden><en> If you have any questions or are interested in our products,please feel free to contact us.
<G-vec00057-002-s571><contact.wenden><de> Wenn Sie Fragen haben oder an unseren Produkten interessiert sind, können Sie sich gerne an uns wenden.
<G-vec00057-002-s572><contact.wenden><en> To gain access, you may contact your local contact person at HUBER Packaging.
<G-vec00057-002-s572><contact.wenden><de> Um einen Zugang zu erhalten, dürfen Sie sich gerne an Ihren zuständigen Ansprechpartner bei HUBER Packaging wenden.
<G-vec00057-002-s573><contact.wenden><en> Consumers can contact the competent consumer arbitration board for this purpose: Contact: Strassburger Str.
<G-vec00057-002-s573><contact.wenden><de> Verbraucher können sich hierzu an die zuständige Verbraucherschlichtungsstelle wenden: Allgemeine Verbraucherschlichtungsstelle des Zentrums für Schlichtung e.
<G-vec00057-002-s574><contact.wenden><en> If you have questions on data protection or want to assert your rights as person affected, please contact the contact address specified in the Imprint.
<G-vec00057-002-s574><contact.wenden><de> Wenn Sie Fragen zum Datenschutz haben oder Ihre Betroffenenrechte geltend machen wollen, dann können Sie sich gern an die im Impressum angegebene Kontaktadresse wenden.
<G-vec00057-002-s575><contact.wenden><en> You can get in touch with us using the contact data specified in Section 1 “Responsibility for data processing and contact data” to exercise the above rights.
<G-vec00057-002-s575><contact.wenden><de> Zur Ausübung der vorgenannten Rechte können Sie sich an die im ersten Abschnitt – Allgemeine Informationen unter Ziffer 1 und 2 genannten Stellen wenden.
<G-vec00057-002-s576><contact.wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of YOUR PHOTOGRAPHERS.
<G-vec00057-002-s576><contact.wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter von Hieronymus Reisen wenden.
<G-vec00057-002-s577><contact.wenden><en> Make sure there is someone on a stand to receive the delivery- For deliveries in the run-up to the fair, please contact one of our service partners.
<G-vec00057-002-s577><contact.wenden><de> Für Lieferungen im Vorfeld der Messe wenden Sie sich bitte an einen unserer Spediteure.
<G-vec00057-002-s578><contact.wenden><en> If you discover that you have purchased a counterfeited good, you will have to contact directly that seller.
<G-vec00057-002-s578><contact.wenden><de> Wenn Sie feststellen, dass Sie eine Fälschung erworben haben, müssen Sie sich im Falle einer Reklamation direkt an den betreffenden Verkäufer wenden.
<G-vec00057-002-s579><contact.wenden><en> If you do not find the manual / guide you need, you are always welcome to contact our service department, who is always ready to assist you with your inquiry.
<G-vec00057-002-s579><contact.wenden><de> Wenn Sie die gewünschten Handbücher/Leitfäden nicht finden, wenden Sie sich gerne an unsere Kundenberatung, die Ihnen jederzeit behilflich ist.
<G-vec00057-002-s580><contact.wenden><en> If you have any questions or remarks, please don’t hesitate to contact him.
<G-vec00057-002-s580><contact.wenden><de> Falls Sie Fragen oder Anmerkungen haben, zögern Sie nicht, sich an ihn zu wenden.
<G-vec00057-002-s581><contact.wenden><en> For this and for any other questions on the topic of personal data, feel free to contact us at any time using the address specified in the impressum.
<G-vec00057-002-s581><contact.wenden><de> Hierzu sowie zu weiteren Fragen zum Thema personenbezogene Daten können Sie sich jederzeit unter der im Impressum angegebenen Adresse an uns wenden.
<G-vec00057-002-s582><contact.wenden><en> In order to assert the right to data portability, the data subject may at any time contact any employee of the Animal Kingdom Corporation.
<G-vec00057-002-s582><contact.wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter des Musikateliers Rostock wenden.
<G-vec00057-002-s583><contact.wenden><en> In order to assert the right to data portability, the data subject may at any time contact the Data Protection Officer designated by the Symmonsroberts.com website or another employee.
<G-vec00057-002-s583><contact.wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der ALWID GmbH wenden.
<G-vec00057-002-s584><contact.wenden><en> If you have questions just get in touch with your local contact person or call the Sortimo Team: +44 (0)1925 831636.
<G-vec00057-002-s584><contact.wenden><de> Bei Fragen können Sie sich an Ihren persönlichen Ansprechpartner vor Ort wenden oder an das Sortimo Direct Team über die kostenfreie Hotline.
<G-vec00057-002-s585><contact.wenden><en> If you have any further questions regarding the processing of your personal data, you are welcome to contact us.
<G-vec00057-002-s585><contact.wenden><de> Soweit Sie weitere Fragen hinsichtlich der Verarbeitung Ihrer personenbezogenen Daten haben, können Sie sich gern an uns wenden.
<G-vec00057-002-s586><contact.wenden><en> In order to assert the right to data portability, the data subject may at any time contact the Data Protection Officer designated by the Biovis Diagnostik MVZ GmbH or another employee.
<G-vec00057-002-s586><contact.wenden><de> Zur Geltendmachung des Rechts auf Datenübertragbarkeit kann sich die betroffene Person jederzeit an einen Mitarbeiter der UEBB wenden.
<G-vec00057-002-s587><contact.wenden><en> Please contact your Subject Librarian if you want to order reference materials and please hand in the application form: Antrag Handapparateinrichtung.
<G-vec00057-002-s587><contact.wenden><de> Bitte wenden Sie sich an das zuständige Fachreferat, wenn Sie einen Handapparat benötigen und reichen Sie den Antrag Handapparateinrichtung ein.
<G-vec00057-002-s588><contact.wenden><en> If you are worried about your gambling or are affected by another person's gambling behaviour, please contact GamCare or GamblersAnonymous for help.
<G-vec00057-002-s588><contact.wenden><de> Wenn Sie sich Sorgen um Ihr Glücksspiel machen oder vom Spielverhalten einer anderen Person besorgt sind, wenden Sie sich bei der Organisation Anonyme Spieler.
<G-vec00057-002-s589><contact.wenden><en> If you made a mistake when ordering, please contact our customer service team at the email address: info@goldandroses.com who will be happy to assist you.
<G-vec00057-002-s589><contact.wenden><de> Wenn Sie bei der Bestellung einen Fehler gemacht haben, wenden Sie sich bitte an unser Kundenservice-Team unter der E-Mail-Adresse: info@goldandroses.com, das Ihnen gerne weiterhilft.
<G-vec00057-002-s590><contact.wenden><en> If you have any questions or concerns regarding privacy at Plarium, please contact our Support team at support.plarium.com.
<G-vec00057-002-s590><contact.wenden><de> Bei Fragen und Bedenken zu Ihrem Datenschutz bei Plarium wenden Sie sich bitte an unserer Support-Team unter support@plarium.com.
<G-vec00057-002-s591><contact.wenden><en> If you wish to have access to this information, please contact us at the above address.
<G-vec00057-002-s591><contact.wenden><de> Wenn Sie auf diese Informationen zugreifen möchten, wenden Sie sich bitte an die oben genannte Adresse.
<G-vec00057-002-s592><contact.wenden><en> If you have any questions, please contact emailing us at info@norkid.com
<G-vec00057-002-s592><contact.wenden><de> Bei Fragen wenden Sie sich bitte an info@norkid.com.
<G-vec00057-002-s593><contact.wenden><en> To request a personalised presentation and unique event session, please contact us on info@gubelinacademy.com
<G-vec00057-002-s593><contact.wenden><de> Für mehr Informationen oder Anfragen bezüglich der Verfügbarkeit, wenden Sie sich bitte direkt unter info@gubelinacademy.com an uns.
<G-vec00057-002-s594><contact.wenden><en> 2.7 If the travel documents are not delivered until 4 days before travel please contact immediately the tour operator or the travel agency where you booked the tour.
<G-vec00057-002-s594><contact.wenden><de> 2.7 Sollten Ihnen die Reiseunterlagen nicht bis spätestens 4 Tage vor Reiseantritt zugegangen sein, wenden Sie sich bitte umgehend an Ihr Reisebüro.
<G-vec00057-002-s595><contact.wenden><en> Given all the above, as well as all the additional information regarding this great land, please feel free to contact us by phone or contact form.
<G-vec00057-002-s595><contact.wenden><de> Wenn Sie alle oben genannten Informationen sowie alle zusätzlichen Informationen zu diesem großartigen Land vorfinden, wenden Sie sich bitte telefonisch oder per Kontaktformular an uns.
<G-vec00057-002-s596><contact.wenden><en> If you have any questions about this form, please contact us by emailing partners@buffalo-technology.com.
<G-vec00057-002-s596><contact.wenden><de> Haben Sie Fragen zu diesem Formular, wenden Sie sich bitte per E-Mail an partners@buffalo-technology.com.
<G-vec00057-002-s597><contact.wenden><en> If you are a user of another company’s product that relies on Intel® Anti-Theft Technology, please contact the company directly to learn more about its plans.
<G-vec00057-002-s597><contact.wenden><de> Wenn Sie ein Produkt eines anderen Anbieters verwenden, das die Intel® Anti-Theft-Technik nutzt, wenden Sie sich bitte direkt an dieses Unternehmen, um weitere Informationen zu erhalten.
<G-vec00057-002-s598><contact.wenden><en> If you have any questions, please contact Customer Service by e-mail at casupport@vitalimagery.com, or by phone at 1-800-482-4567, weekdays from 9 am to 5 pm EST.
<G-vec00057-002-s598><contact.wenden><de> happen Wenn Sie Fragen haben, wenden Sie sich bitte an den Kundendienst per E-Mail unter casupport@vitalimagery.com, oder telefonisch unter 1-800-482-4567, wochentags von 9 bis 17 Uhr EST.
<G-vec00057-002-s599><contact.wenden><en> If you think that we have collected Personal Information from a child under the age of 13, please contact us at [insert country level inbox email address].
<G-vec00057-002-s599><contact.wenden><de> Wenn Sie der Meinung sind, dass wir persönliche Informationen von einem Kind unter 13 Jahren gesammelt haben, wenden Sie sich bitte an folgende E-Mail Adresse .
<G-vec00057-002-s600><contact.wenden><en> If you wish to book for another individual, please contact the property directly for further information after booking.
<G-vec00057-002-s600><contact.wenden><de> Wenn Sie für eine andere Person buchen, wenden Sie sich bitte nach der Buchung direkt an die Unterkunft.
<G-vec00057-002-s601><contact.wenden><en> If you have forgotten your password or have not assigned one yet, please contact us atÂ support@miacara.com.
<G-vec00057-002-s601><contact.wenden><de> Sollten Sie Ihr Passwort vergessen oder noch keins erhalten haben, wenden Sie sich bitte an support@miacara.com.
<G-vec00057-002-s602><contact.wenden><en> Please contact our office using the contact form if you wish more information about manuals and check lists.
<G-vec00057-002-s602><contact.wenden><de> Bei Fragen zu Handbüchern und Prüflisten wenden Sie sich bitte mit Hilfe des Kontaktformulars an unser Büro.
<G-vec00057-002-s603><contact.wenden><en> If you have any questions, please contact Customer Service by e-mail at casupport@vitalimagery.com, or by phone at 1-800-482-4567, weekdays from 9 am to 5 pm EST.
<G-vec00057-002-s603><contact.wenden><de> Überbleibsel Wenn Sie Fragen haben, wenden Sie sich bitte an den Kundendienst per E-Mail unter casupport@vitalimagery.com, oder telefonisch unter 1-800-482-4567, wochentags von 9 bis 17 Uhr EST.
<G-vec00057-002-s604><contact.wenden><en> If you are interested please contact us at (e-mail in contact data) or +31 (0) 228 855 380 for more information or to make an appointment for viewing on board.
<G-vec00057-002-s604><contact.wenden><de> Wenn Sie interessiert sind, wenden Sie sich bitte an (Email in den Kontaktdaten) oder +31(0)228 855 380 für weitere Informationen oder um einen Termin für eine Besichtigung an Bord zu vereinbaren.
<G-vec00057-002-s605><contact.wenden><en> Booking: If you require a wheelchair or other type of mobility aid, please contact reservations at least 48 hours in advance of your flight so we can make the necessary arrangements.Up to 2 pieces of mobility equipment per person with a disability or person with reduced mobility can be booked.
<G-vec00057-002-s605><contact.wenden><de> Buchung: Wenn Sie einen Rollstuhl oder eine andere Form an Mobilitätsbedarf benötigen, wenden Sie sich bitte mindestens 48 Stunden vor Abflug an die Reservierungsabteilung, damit die erforderlichen Vorkehrungen getroffen werden können.
<G-vec00057-002-s606><contact.wenden><en> If you have any questions, please contact Corel Customer Service at 1-877-582-6735.
<G-vec00057-002-s606><contact.wenden><de> Bei Fragen wenden Sie sich bitte an unseren Kundendienst unter 1-877-582-6735.
<G-vec00057-002-s607><contact.wenden><en> If you have questions that are not answered by this privacy statement or if you wish to receive more detailed information, please contact us at any time mbH to the Supervisor of the hotel operating company.
<G-vec00057-002-s607><contact.wenden><de> Wenn Sie Fragen haben, die Ihnen diese Datenschutzerklärung nicht beantworten konnte oder wenn Sie zu einem Punkt vertiefte Informationen wünschen, wenden Sie sich bitte jederzeit an den Datenschutzbeauftragten der Hotelbetriebs- gesellschaft mbH.
