<G-vec00254-002-s779><decide.(sich)_überlegen><en> We would not be the Insomnia if we did not go a little further: The fine line between harmless cuddles and deliberate touches is narrow and so there will be a second part of the party where everyone can decide whether he wants to participate or stay with the intentionless cuddling.
<G-vec00254-002-s779><decide.(sich)_überlegen><de> Wir wären ja nicht das Insomnia, wenn wir nicht auch ein wenig weiter gehen würden: Der Grat aus harmlosen Kuscheln zu absichtvollen Berührungen ist schmal und so wird es einen zweiten Teil der Party geben, bei dem sich jeder überlegen kann ob er mitmachen will oder es beim absichtslosen Kuscheln belässt.
<G-vec00254-002-s780><decide.(sich)_überlegen><en> Our search engine will help you book a flight to Milwaukee - all you have to do, is decide what to pack.
<G-vec00254-002-s780><decide.(sich)_überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Milwaukee-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s781><decide.(sich)_überlegen><en> After deciding whether you wish to operate your child-care business at home or in an independent facility, the next step is to decide what type of child care you would like to offer.
<G-vec00254-002-s781><decide.(sich)_überlegen><de> Nachdem du dich entschlossen hast, ob du deine Kinderbetreuungseinrichtung bei dir zuhause oder in externen Räumlichkeiten eröffnen willst, ist der nächste Schritt, zu überlegen, welche Art Kinderbetreuungseinrichtung du gerne anbieten würdest.
<G-vec00254-002-s782><decide.(sich)_überlegen><en> As far as the opening of the TLD catalogue is concerned, trademark owners must decide whether they wish to have their trademark(s) registered as a TLD, and they should also think about how to defend their trademarks against new TLDs that infringe upon their trademark(s).
<G-vec00254-002-s782><decide.(sich)_überlegen><de> Markeninhaber müssen sich im Zusammenhang mit der Öffnung des TLD-Katalogs zum einen überlegen, ob sie ihre Marke(n) als TLD registrieren wollen und zum anderen darüber nachdenken, wie sie ihre Marken gegen neue TLDs verteidigen, welche ihre Marke(n) verletzen.
<G-vec00254-002-s783><decide.(sich)_überlegen><en> And if the price is already in the internet, then I can decide whether I am going to play along or not.
<G-vec00254-002-s783><decide.(sich)_überlegen><de> Und wenn es den Preis im Internet bereits gibt, dann kann ich mir überlegen, ob ich da mitspiele oder nicht.
<G-vec00254-002-s784><decide.(sich)_überlegen><en> The children repeat the different steps of working with the Clip Art program and decide which picture each child will paint so that all important procedures are covered and documented.
<G-vec00254-002-s784><decide.(sich)_überlegen><de> Die Kinder wiederholen die verschiedenen Schritte zur Arbeit mit dem Clip Art-Programm und überlegen, welche Bilder jedes einzelne Kind malt, so dass alle wichtigen Vorgänge dokumentiert werden.
<G-vec00254-002-s785><decide.(sich)_überlegen><en> Watch the dancing waves from your four-poster sunbed next to a private plunge pool, as you decide what to have for dinner.
<G-vec00254-002-s785><decide.(sich)_überlegen><de> Während Ihr vom Himmelbett direkt neben Eurem eigenen Pool den Wellen zuseht, könnt Ihr Euch schon einmal überlegen, was Ihr zu Abend essen möchtet.
<G-vec00254-002-s786><decide.(sich)_überlegen><en> When opting for WordPress hosting, you need to decide what exactly your website should offer its users.
<G-vec00254-002-s786><decide.(sich)_überlegen><de> Wenn Sie sich für Managed-WordPress-Hosting entscheiden, müssen Sie sich nur noch überlegen, was Ihre Website den Besuchern bieten soll.
<G-vec00254-002-s787><decide.(sich)_überlegen><en> Instead of giving the answer, the teacher split the class into two groups, male and female, and asked them to decide for themselves whether computer' should be a masculine or a feminine noun.
<G-vec00254-002-s787><decide.(sich)_überlegen><de> Anstatt einer Antwort, teilte der Lehrer die Klasse in zwei Gruppen ein, Frauen und Männer, und beauftragte sie, selber zu überlegen, ob "Computer" männlich oder weiblich sei.
<G-vec00254-002-s788><decide.(sich)_überlegen><en> If you decide to install your own Wi-Fi access points, approval from LRZ is required.
<G-vec00254-002-s788><decide.(sich)_überlegen><de> Falls Sie überlegen, eigene WLAN-Access Points zu installieren, ist eine Genehmigung durch das LRZ notwendig.
<G-vec00254-002-s789><decide.(sich)_überlegen><en> You can then see the result on-screen and decide whether you want to continue with or cancel the print job.
<G-vec00254-002-s789><decide.(sich)_überlegen><de> Sie können sich das Ergebnis anschließend am Bildschirm anschauen und überlegen, ob Sie den Druckauftrag fortsetzen oder stornieren wollen.
<G-vec00254-002-s790><decide.(sich)_überlegen><en> Our search engine will help you book a flight to Victoria Inner Harbour - all you have to do, is decide what to pack.
<G-vec00254-002-s790><decide.(sich)_überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Victoria Inner Harbour-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s791><decide.(sich)_überlegen><en> Because of this, you can decide if you want to cover the inside of the zine with artwork as well.
<G-vec00254-002-s791><decide.(sich)_überlegen><de> Daher kannst du überlegen, ob du das Innere des Buches auch illustrieren willst.
<G-vec00254-002-s792><decide.(sich)_überlegen><en> The second step in planning your wedding is to decide when the event should take place.
<G-vec00254-002-s792><decide.(sich)_überlegen><de> Der zweite Schritt ist zu überlegen, wann die Hochzeit statt finden soll.
<G-vec00254-002-s793><decide.(sich)_überlegen><en> First, you need to decide which data formats and data types to implement.
<G-vec00254-002-s793><decide.(sich)_überlegen><de> Zunächst müssen Sie überlegen, welche Datenformate und Datentypen implementiert werden müssen.
<G-vec00254-002-s794><decide.(sich)_überlegen><en> There is now the occasion to decide about how much of customization should really be retained.
<G-vec00254-002-s794><decide.(sich)_überlegen><de> Es ist auch der Moment, zu überlegen, wieviel Anpassung (Customization) überhaupt beibehalten werden soll.
<G-vec00254-002-s795><decide.(sich)_überlegen><en> I’d rather drink a cup of tea with her first, gab with her and then at the end decide whether or not to kiss her hand.
<G-vec00254-002-s795><decide.(sich)_überlegen><de> Eher würde ich zuerst einen Tee mit ihr trinken, mit ihr tratschen und dann zum Abschied überlegen, ob ich ihr vielleicht die Hand küsse.
<G-vec00254-002-s796><decide.(sich)_überlegen><en> You will have to collectively discuss and decide how to answer each question.
<G-vec00254-002-s796><decide.(sich)_überlegen><de> Ihr müsst gemeinsam überlegen, wie ihr jede dieser Fragen beantworten wollt.
<G-vec00254-002-s797><decide.(sich)_überlegen><en> Whether you have already introduced some happy hens to your garden or you're trying to decide if keeping chickens is for you, you're in the right place.
<G-vec00254-002-s797><decide.(sich)_überlegen><de> Egal ob Sie schon in Ihrem Garten ein paar glückliche Hühner haben oder Sie noch überlegen, ob die Hühnerhaltung etwas für Sie ist, so sind Sie hier am richtigen Platz.
<G-vec00254-002-s057><decide.beschließen><en> Article 39 The Security Council shall determine the existence of any threat to the peace, breach of the peace, or act of aggression and shall make recommendations, or decide what measures shall be taken in accordance with Articles 41 and 42, to maintain or restore international peace and security.
<G-vec00254-002-s057><decide.beschließen><de> Artikel 39 (Maßnahmen zur Wahrung des Weltfriedens) Der Sicherheitsrat stellt fest, ob eine Bedrohung oder ein Bruch des Friedens oder eine Angriffshandlung vorliegt; er gibt Empfehlungen ab oder beschließt, welche Maßnahmen auf Grund der Artikel 41 und 42 zu treffen sind, um den Weltfrieden und die internationale Sicherheit zu wahren oder wiederherzustellen.
<G-vec00254-002-s058><decide.beschließen><en> According to Article 97(2) EPC, if it is established that the applicant has approved the text in which the Examining Division intends to grant the patent, and if the fees for grant and printing have been paid within the set period, and if the renewal fees and any additional fees already due have been paid, the Examining Division shall decide to grant the European patent.
<G-vec00254-002-s058><decide.beschließen><de> Nach Artikel 97 (2) EPÜ beschließt die Prüfungsabteilung die Erteilung des europäischen Patents, sofern feststeht, daß der Anmelder mit der Fassung, in der die Prüfungsabteilung das Patent zu erteilen beabsichtigt, einverstanden ist, die Erteilungs- und die Druckkostengebühr innerhalb der vorgeschriebenen Frist entrichtet und die bereits fälligen Jahresgebühren und Zuschlagsgebühren gezahlt worden sind.
<G-vec00254-002-s059><decide.beschließen><en> Before you decide to treat yourselves and your guests with an experience they’ll never forget, make sure you get familiar with all the downsides of getting married abroad.
<G-vec00254-002-s059><decide.beschließen><de> Bevor ihr beschließt, euch und euren Gästen ein Erlebnis zu bescheren, das unvergesslich bleibt, vergewissert euch, ob ihr euch auch mit allen Nachteilen einer Hochzeit im Ausland vertraut gemacht habt.
<G-vec00254-002-s060><decide.beschließen><en> The board shall discuss and decide on rule changes and, at the request of the associations and national general meetings, matters relating to association football in its international relations.
<G-vec00254-002-s060><decide.beschließen><de> Das Gremium erörtert und beschließt Regeländerungen und auch auf Bitte der Verbände und nationalen Generalversammlungen Angelegenheiten, die den Verbandsfußball in seinen internationalen Beziehungen betreffen.
<G-vec00254-002-s061><decide.beschließen><en> That way, if you decide that you don't like the changes, you always have the original unaltered photo on-hand.
<G-vec00254-002-s061><decide.beschließen><de> Auf diese Weise hast du das ursprüngliche, unveränderte Foto immer zur Hand, falls du beschließt, dass dir die Änderungen nicht gefallen.
<G-vec00254-002-s062><decide.beschließen><en> The ECB shall decide whether or not to oppose the acquisition on the basis of its assessment of the proposed acquisition and the NCA’s draft decision.
<G-vec00254-002-s062><decide.beschließen><de> Die EZB beschließt, ob sie den Erwerb auf Grundlage ihrer Prüfung des geplanten Erwerbs und des Beschlussentwurfs der NCA ablehnt oder nicht ablehnt.
<G-vec00254-002-s063><decide.beschließen><en> Jürgen Fechter and Alexander Isola were newly elected to the Supervisory Board for the maximum period stipulated in the Articles of Association (i.e. until the end of the Annual General Meeting that will decide on the discharge for 2020).
<G-vec00254-002-s063><decide.beschließen><de> Jürgen Fechter und Dr. Alexander Isola wurden als neue Mitglieder des Aufsichtsrats für die satzungsmäßige Höchstdauer gewählt (das ist bis zum Ende jener Hauptversammlung, die über die Entlastung für das Geschäftsjahr 2020 beschließt).
<G-vec00254-002-s064><decide.beschließen><en> The Executive Board shall decide on the repayment of this loan.
<G-vec00254-002-s064><decide.beschließen><de> Der Vorstand beschließt über die Rückzahlung.
<G-vec00254-002-s065><decide.beschließen><en> The Council shall decide by qualified majority.
<G-vec00254-002-s065><decide.beschließen><de> Der Rat beschließt mit qualifizierter Mehrheit.
<G-vec00254-002-s066><decide.beschließen><en> The Board of Directors shall decide on the signatory powers of the members of the Executive Committee.
<G-vec00254-002-s066><decide.beschließen><de> Der Verwaltungsrat beschließt über die Zeichnungsbefugnisse der Mitglieder des Executive Committee.
<G-vec00254-002-s067><decide.beschließen><en> The Council shall decide on the organisation of the General Secretariat by a simple majority.
<G-vec00254-002-s067><decide.beschließen><de> Der Rat beschließt mit einfacher Mehrheit über die Organisation des Generalsekretariats.
<G-vec00254-002-s068><decide.beschließen><en> On conclusion of the period, the Commission shall decide either to terminate the suspension after informing the Committee referred to in Article 27 or to extend the period of suspension in accordance with the procedure referred to in paragraph 3 of this Article.
<G-vec00254-002-s068><decide.beschließen><de> Spätestens nach Ablauf dieses Zeitraums beschließt die Kommission nach dem Dringlichkeitsverfahren des Artikels 39 Absatz 4 entweder, die vorübergehende Rücknahme zu beenden, oder die vorübergehende Rücknahme zu verlängern.
<G-vec00254-002-s069><decide.beschließen><en> MrJake shared his bewilderment with other Reddit users who suggested he spend the coins as soon as possible in case Respawn decide to do something about this.
<G-vec00254-002-s069><decide.beschließen><de> MrJake teilte seine Verwirrung mit anderen Reddit-Benutzern, die vorschlugen, die Münzen so schnell wie möglich auszugeben, falls Respawn beschließt, etwas dagegen zu unternehmen.
<G-vec00254-002-s070><decide.beschließen><en> On the seventh and final station raises the Granattor, a container filled with tons of garnet through the indication of the largest garnet deposits in Europe inside the Alpe Millstätter are, with the hikers a look into the future together and decide the way.
<G-vec00254-002-s070><decide.beschließen><de> An der siebten und letzten Station wirft das Granattor, ein mit Tonnen von Granatstein gefüllter Durchgang der Hinweis auf das größte Granatvorkommen Europas im Inneren der Millstätter Alpe gibt, mit den Wanderern einen Blick in die gemeinsame Zukunft und beschließt den Weg.
<G-vec00254-002-s071><decide.beschließen><en> The Commission shall decide within three months following the notification provided for in point (a) of paragraph 4.
<G-vec00254-002-s071><decide.beschließen><de> (5) Die Kommission beschließt innerhalb von drei Monaten nach der Mitteilung gemäß Absatz 4 Buchstabe a. Diese Frist beginnt am Tag nach dem Eingang der vollständigen Mitteilung.
<G-vec00254-002-s072><decide.beschließen><en> ECB decision on acquisition The ECB shall decide whether or not to oppose the acquisition on the basis of its assessment of the proposed acquisition and the NCA’s draft decision.
<G-vec00254-002-s072><decide.beschließen><de> Beschluss der EZB über den Erwerb Die EZB beschließt, ob sie den Erwerb auf Grundlage ihrer Prüfung des geplanten Erwerbs und des Beschlussentwurfs der NCA ablehnt oder nicht ablehnt.
<G-vec00254-002-s073><decide.beschließen><en> It shall decide the budget for receipts and expenditures within the limit of existing appropriations, and shall audit and approve the accounts.
<G-vec00254-002-s073><decide.beschließen><de> Sie beschließt den Haushalt der Einnahmen und Ausgaben im Rahmen der bestehenden Mittel und kontrolliert und billigt die Rechnungsabschlüsse.
<G-vec00254-002-s074><decide.beschließen><en> He is brought before the council and the council decide to put him to death.
<G-vec00254-002-s074><decide.beschließen><de> Er wird vor den Hohenrat geführt, und der Hoherat beschließt, ihn zu töten.
<G-vec00254-002-s075><decide.beschließen><en> According to our trade union, guests who, following government announcements, decide to leave the campsite before the end of their stay, or who decide to cancel a booked stay, do so on their own initiative.
<G-vec00254-002-s075><decide.beschließen><de> Unserem Berufsverband zufolge macht ein Kunde, der nach den Ansagen der Regierung beschließt, den Campingplatz vor Beendigung seines Aufenthalts zu verlassen, oder einen gebuchten Aufenthalt zu stornieren, dieses aus eigener Initiative.
<G-vec00254-002-s076><decide.bestimmen><en> It is possible to decide on the size and the quantity of the stones.
<G-vec00254-002-s076><decide.bestimmen><de> Es ist möglich, die Größe und die Anzahl der zu bearbeitenden Steine zu bestimmen.
<G-vec00254-002-s077><decide.bestimmen><en> ED/2015/10 Annual Improvements to IFRSs 2014–2016 Cycle contains no proposed effective dates for any of the proposed amendments. The intention is to decide on these after the exposure period.
<G-vec00254-002-s077><decide.bestimmen><de> Im Entwurf ED/2019/2 Jährliche Verbesserungen an den IFRS 2018-2020 sind keine vorgeschlagenen Zeitpunkte des Inkrafttretens für die vorgeschlagenen Änderungen enthalten, weil beabsichtigt ist, diese nach der Kommentierungsphase zu bestimmen.
<G-vec00254-002-s078><decide.bestimmen><en> This means, you can decide yourself what happens next. About the delivery status Redirection options
<G-vec00254-002-s078><decide.bestimmen><de> Das heißt, Sie können selbst bestimmen, was jetzt mit Ihrem Paket passieren soll.
<G-vec00254-002-s079><decide.bestimmen><en> You decide what information goes on your public profile.
<G-vec00254-002-s079><decide.bestimmen><de> Sie bestimmen, welche Informationen in Ihrem öffentlichen Profil angezeigt werden.
<G-vec00254-002-s080><decide.bestimmen><en> You can decide which members can manage shared channels on your Enterprise Grid organization.
<G-vec00254-002-s080><decide.bestimmen><de> Du kannst bestimmen, welche Mitglieder Geteilte Channels in deiner Enterprise Grid-Organisation verwalten können.
<G-vec00254-002-s081><decide.bestimmen><en> Naturally, you decide on the length yourself depending on the number of photos.
<G-vec00254-002-s081><decide.bestimmen><de> Die Länge bestimmen sie je nach Anzahl der Fotos natürlich selbst.
<G-vec00254-002-s082><decide.bestimmen><en> That will decide on the final texture and refinement of the praline or truffle and that is what we foster at Carline, for decades already…
<G-vec00254-002-s082><decide.bestimmen><de> Denn diese bestimmen die letztendliche Textur und den raffinierten Geschmack - und das hat bei Carline oberste Priorität, schon seit Jahrzehnten...
<G-vec00254-002-s083><decide.bestimmen><en> Our clients know each and every one of us; they themselves decide who will work on their case.
<G-vec00254-002-s083><decide.bestimmen><de> Unsere Mandanten kennen uns – jeden einzeln – und sie bestimmen, wer ihren Fall bearbeitet.
<G-vec00254-002-s084><decide.bestimmen><en> You can decide yourself which products should be grouped together.
<G-vec00254-002-s084><decide.bestimmen><de> Sie können selbst bestimmen, welche Produkte in welchen Gruppen zusammengefasst werden.
<G-vec00254-002-s085><decide.bestimmen><en> But in fact the Commonwealth of Puerto Rico remains a colony of the U.S., as the real power to decide about its status lies with Congress.
<G-vec00254-002-s085><decide.bestimmen><de> Da jedoch der Kongress in Washington über die Zukunft des Commonwealth of Puerto Rico zu bestimmen hat, bleibt die Insel eine Kolonie der USA.
<G-vec00254-002-s086><decide.bestimmen><en> The neurotransmitters diffuse across the synaptic cleft to bind receptors which, to large extent, decide on final effect.
<G-vec00254-002-s086><decide.bestimmen><de> Die Neurotransmitter wandern durch den synaptischen Spalt und binden dann an Rezeptoren, die über den endgültigen Effekt bestimmen.
<G-vec00254-002-s087><decide.bestimmen><en> The parties will then have to decide on the time and location of the mediation.
<G-vec00254-002-s087><decide.bestimmen><de> Das Ergebnis und die Beendigung des Verfahrens bestimmen ausschließlich die Parteien.
<G-vec00254-002-s088><decide.bestimmen><en> The snooze intervals can be set so that you decide after how many minutes the alarm should sound again.
<G-vec00254-002-s088><decide.bestimmen><de> Die Snooze-Dauer lässt sich einstellen, so dass Sie bestimmen, nach wie viel Minuten der Alarm erneut ertönt.
<G-vec00254-002-s089><decide.bestimmen><en> By previewing the games, you can easily decide whichever game you want to play.
<G-vec00254-002-s089><decide.bestimmen><de> Durch die Vorschau der Spiele, können Sie bequem bestimmen je nachdem, welcher Online-Spiel Sie spielen möchten.
<G-vec00254-002-s090><decide.bestimmen><en> You can decide if your personal stripper will do her girlstrip in a favorite outfit.
<G-vec00254-002-s090><decide.bestimmen><de> Sie können bestimmen, ob Ihre persönliche Stripperin ihren Girlstrip in einem bevorzugten Outfit durchführt.
<G-vec00254-002-s091><decide.bestimmen><en> You decide whether to start receiving your annuity straightaway or at a later date.
<G-vec00254-002-s091><decide.bestimmen><de> Sie bestimmen, ob die Rentenzahlung sofort oder zu einem späteren Zeitpunkt startet.
<G-vec00254-002-s092><decide.bestimmen><en> The Guild Leaders can decide how much will be the Guild tax, meaning - they can determine what % of the earned gold will automatically go the Guild Treasury.
<G-vec00254-002-s092><decide.bestimmen><de> Die Leiter der Gilde haben das Recht die Steuer der Gilde zu bestimmen, d.h. sie bestimmen was für einen Prozent des erworbenen Goldes von jedem Spieler automatisch in die Kasse geht.
<G-vec00254-002-s093><decide.bestimmen><en> never have arrived at the conception of a free almighty God and of what may be called an “arbitrary Providence,“ a Providence, that is, which can decree something in one way, and then in answer to prayers or from other motives decide in a contrary direction. * We do not find that, outside of Judaism, man ever came to the conception of a quite intimate and continual personal relation between God and mankind — to the conception of a God who would almost seem to be there only for the sake of man.
<G-vec00254-002-s093><decide.bestimmen><de> Aus eigenen Kräften wären wir gewiss nie zu der Vorstellung eines freien allmächtigen Gottes und einer sozusagen „willkürlichen Vorsehung“ gekommen, einer Vorsehung nämlich, die eine Sache so bestimmen kann, und dann, durch Gebete oder andere Beweggründe veranlasst, wieder anders.¹) Wir sehen nicht, dass man außerhalb des Judentums auf den Gedanken einer ganz intimen und beständigen persönlichen Beziehung zwischen Gott und Mensch gekommen sei, auf den Gedanken eines Gottes, der, wenn ich so sagen darf, lediglich der Menschen wegen da zu sein scheint.
<G-vec00254-002-s094><decide.bestimmen><en> ISOE’s water researchers suggest that from now on, the population development and the related economic progression will again increasingly decide about the expected water demand.
<G-vec00254-002-s094><decide.bestimmen><de> Die Wasserforscher des ISOE gehen davon aus, dass zukünftig vor allem die Bevölkerungsentwicklung und die damit auch verbundene wirtschaftliche Entwicklung den Wasserbedarf bestimmen werden.
<G-vec00254-002-s247><decide.entscheiden><en> Once a year, the executive board and the scientific management of Wings for Life sit down together to decide which new research projects should be funded.
<G-vec00254-002-s247><decide.entscheiden><de> Einmal im Jahr entscheiden der Vorstand und die wissenschaftliche Leitung von Wings for Life darüber, welche neuen Forschungsprojekte gefördert werden.
<G-vec00254-002-s248><decide.entscheiden><en> All cantons decide on how education should look like, as long as it meets certain requirements.
<G-vec00254-002-s248><decide.entscheiden><de> Alle Kantone entscheiden darüber, wie Erziehung aussehen sollte, solange sie bestimmte Anforderungen erfüllt.
<G-vec00254-002-s249><decide.entscheiden><en> You as the administrator decide what your supplier can and cannot see.
<G-vec00254-002-s249><decide.entscheiden><de> Sie als Administrator entscheiden darüber, was Ihr Lieferant einsehen kann und was nicht.
<G-vec00254-002-s250><decide.entscheiden><en> The selection of different types of peppers and the amount of fat-containing pepper seeds decide whether sweet or hot paprika is produced.
<G-vec00254-002-s250><decide.entscheiden><de> Die Auswahl der verschiedenen Paprikasorten und die Menge der zugegebenen, fetthaltigen Paprikasamen entscheiden darüber, ob edelsüßes oder scharfes Paprikapulver entsteht.
<G-vec00254-002-s251><decide.entscheiden><en> We shall not be obliged to take part in dispute resolution procedures before a consumer conciliation body and shall decide on these on a case-by-case basis.
<G-vec00254-002-s251><decide.entscheiden><de> Wir sind zur Teilnahme an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle nicht verpflichtet und entscheiden darüber im Einzelfall.
<G-vec00254-002-s252><decide.entscheiden><en> You alone decide whether or not you wish to disclose this data to us, for example in the context of a registration, survey or similar.
<G-vec00254-002-s252><decide.entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung, Umfrage o. ä., diese Daten bekannt geben wollen oder nicht.
<G-vec00254-002-s253><decide.entscheiden><en> Sandra and I decide such things together even though, as the manager, Sandra naturally has her eye on the furnishings every day.
<G-vec00254-002-s253><decide.entscheiden><de> Sandra und ich entscheiden gemeinsam darüber, auch wenn Sandra als Geschäftsführerin die Einrichtung natürlich täglich im Blick hat.
<G-vec00254-002-s254><decide.entscheiden><en> Database users decide what data are released.
<G-vec00254-002-s254><decide.entscheiden><de> Die Datenbankbenutzer entscheiden darüber, welche Daten freigegeben werden.
<G-vec00254-002-s255><decide.entscheiden><en> Therefore, a user or administrator must decide whether to trust that CA and, by extension, the policies and procedures that the CA has in place for confirming the identity of the entities that are issued certificates by that CA.
<G-vec00254-002-s255><decide.entscheiden><de> Deshalb muss ein Benutzer oder Administrator entscheiden, ob dieser Zertifizierungsstelle und darüber hinaus den Richtlinien und Verfahren dieser Zertifizierungsstelle zur Bestätigung der Identität der Entitäten, denen von dieser Zertifizierungsstelle Zertifikate ausgestellt werden, vertraut werden kann.
<G-vec00254-002-s256><decide.entscheiden><en> You are free to decide which information you provide to the Bertelsmann Stiftung.
<G-vec00254-002-s256><decide.entscheiden><de> Wahlmöglichkeit Sie entscheiden frei darüber, welche Informationen Sie der Bertelsmann Stiftung zur Verfügung stellen.
<G-vec00254-002-s257><decide.entscheiden><en> You alone decide whether you want to or do not want to disclose this data to us, for example in the course of a registration process.
<G-vec00254-002-s257><decide.entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung, diese Daten bekannt geben wollen oder nicht.
<G-vec00254-002-s258><decide.entscheiden><en> By combining them you can easily decide how to bake your dish and be sure about the final result.
<G-vec00254-002-s258><decide.entscheiden><de> Die Betriebsarten können problemlos miteinander kombiniert werden; wir entscheiden darüber, wie unsere Speise zuzubereiten ist, wobei wir uns des Endergebnisses immer sicher sein können.
<G-vec00254-002-s259><decide.entscheiden><en> In our houses and gardens, in our facilities for water, energy and food, in our love relationships and partnerships and in our social and political systems, we decide which information is sent to the world.
<G-vec00254-002-s259><decide.entscheiden><de> In unseren Häusern und Gärten, unseren Anlagen für Wasser, Energie und Nahrung, unseren Liebesbeziehungen und Partnerschaften, unseren sozialen und politischen Systemen entscheiden wir darüber, welche Information in die Welt geht.
<G-vec00254-002-s260><decide.entscheiden><en> You may freely decide what information to give us.
<G-vec00254-002-s260><decide.entscheiden><de> Sie entscheiden frei darüber, welche Informationen Sie zur Verfügung stellen.
<G-vec00254-002-s261><decide.entscheiden><en> You alone decide if you wish to give us this information or not, for example when registering online or during an online application.
<G-vec00254-002-s261><decide.entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung/ Online-Bewerbung, diese Daten bekannt geben wollen oder nicht.
<G-vec00254-002-s262><decide.entscheiden><en> The market doesn't take into account the costs but by selling directly from the pier the fishermen can decide their own prices.
<G-vec00254-002-s262><decide.entscheiden><de> Der Markt berücksichtigt die Kosten nicht - beim Direktverkauf jedoch entscheiden die Fischer selbst darüber.
<G-vec00254-002-s263><decide.entscheiden><en> Your listeners and viewers will decide on it.
<G-vec00254-002-s263><decide.entscheiden><de> Ihre Zuhörer und Zuschauer entscheiden darüber.
<G-vec00254-002-s264><decide.entscheiden><en> Function, operating comfort, graphical design, speed and availability decide on how internet applications are perceived.
<G-vec00254-002-s264><decide.entscheiden><de> Funktionalität, Bedienungskomfort, grafische Ausgestaltung, Geschwindigkeit und Verfügbarkeit entscheiden darüber, wie Internetanwendungen erlebt werden.
<G-vec00254-002-s265><decide.entscheiden><en> This is essential indeed, because your ability to draw these tonalities, decide how 3-dimensional and realistic your ball will look in the end.
<G-vec00254-002-s265><decide.entscheiden><de> Denn eure Fähigkeiten diese Tonalitäten zeichnen zu können, entscheiden darüber wie 3-dimensional und realistisch eure Kugel fertig aussieht.
<G-vec00254-002-s665><decide.entschleißen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00254-002-s665><decide.entschleißen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00254-002-s666><decide.entschleißen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00254-002-s666><decide.entschleißen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00254-002-s667><decide.entschleißen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00254-002-s667><decide.entschleißen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00254-002-s668><decide.entschleißen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00254-002-s668><decide.entschleißen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00254-002-s669><decide.entschleißen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00254-002-s669><decide.entschleißen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00254-002-s670><decide.entschleißen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00254-002-s670><decide.entschleißen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00254-002-s671><decide.entschleißen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00254-002-s671><decide.entschleißen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00254-002-s672><decide.entschleißen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00254-002-s672><decide.entschleißen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00254-002-s673><decide.entschleißen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00254-002-s673><decide.entschleißen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00254-002-s674><decide.entschleißen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00254-002-s674><decide.entschleißen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00254-002-s675><decide.entschleißen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00254-002-s675><decide.entschleißen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00254-002-s676><decide.entschleißen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00254-002-s676><decide.entschleißen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00254-002-s677><decide.entschleißen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00254-002-s677><decide.entschleißen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00254-002-s678><decide.entschleißen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00254-002-s678><decide.entschleißen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00254-002-s679><decide.entschleißen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00254-002-s679><decide.entschleißen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00254-002-s680><decide.entschleißen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00254-002-s680><decide.entschleißen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00254-002-s681><decide.entschleißen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00254-002-s681><decide.entschleißen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00254-002-s682><decide.entschleißen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00254-002-s682><decide.entschleißen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00254-002-s683><decide.entschleißen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00254-002-s683><decide.entschleißen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00254-002-s513><decide.festlegen><en> Upgrading Your System Once you have chosen to upgrade, you can also decide whether you want to customize your packages.
<G-vec00254-002-s513><decide.festlegen><de> Wenn Sie sich für das Upgraden entschieden haben, können Sie auch festlegen, ob Sie die zu installierenden Pakete individuell festlegen möchten.
<G-vec00254-002-s514><decide.festlegen><en> At the end you can also decide whether the content text shoulb be duplicated as well.
<G-vec00254-002-s514><decide.festlegen><de> Am unteren Ende können Sie außerdem festlegen, ob auch der Inhaltstext dupliziert werden soll.
<G-vec00254-002-s515><decide.festlegen><en> You can decide the price for your Study Material yourself.
<G-vec00254-002-s515><decide.festlegen><de> Sie selbst können den Preis für Ihre Studienunterlagen festlegen.
<G-vec00254-002-s516><decide.festlegen><en> When searching and filtering database objects, you can decide whether or not this should be case sensitive.
<G-vec00254-002-s516><decide.festlegen><de> Sie können beim Suchen und Filtern von Datenbankobjekten festlegen, ob dabei die Groß- und Kleinschreibung beachtet werden soll.
<G-vec00254-002-s517><decide.festlegen><en> Kubernetes enables the administration of containerised applications over their entire lifecycle and users are able to decide themselves how to run applications and how these should interact with each other.
<G-vec00254-002-s517><decide.festlegen><de> Kubernetes ermöglicht die vollständige Verwaltung des Lebenszyklus der containerisierten Anwendungen und die Nutzer können selbst festlegen wie Anwendungen ausgeführt werden sollen und miteinander interagieren.
<G-vec00254-002-s518><decide.festlegen><en> For example, you can decide that every night, your mobile phone should be under maintenance from 23H00 to 06H00 but that email alerts should however be maintained 24 hours a day.
<G-vec00254-002-s518><decide.festlegen><de> Sie können zum Beispiel festlegen, dass sich Ihr Mobiltelefon jede Nacht zwischen 23.00 und 6.00 Uhr im Wartungszustand befindet, dass jedoch E-Mail-Alarme rund um die Uhr weiterhin erfolgen.
<G-vec00254-002-s519><decide.festlegen><en> Dr. Schörner also noted that Statute 7.2 states that the committee is entitled to amend and change regulations (other than those in the statutes) and to decide when such changes come into force.
<G-vec00254-002-s519><decide.festlegen><de> Dr. Schöner bemerkte weiters, dass der Ausschuss laut Statuten 7.2. alle anderen UNICA Regeln und Vorschriften soweit erforderlich ändern und aktualisieren kann, und festlegen kann wann diese in Kraft treten.
<G-vec00254-002-s520><decide.festlegen><en> If choosing the LAN client, you only need to decide if the Sysap should receive an automatic IP-address or choose a static.
<G-vec00254-002-s520><decide.festlegen><de> Wenn Sie den LAN-Client auswählen, müssen Sie nur festlegen, ob der Sysap eine automatische IP-Adresse beziehen oder eine statische IP-Adresse erhalten soll.
<G-vec00254-002-s521><decide.festlegen><en> You can also decide on the output folder location of the recovered items.
<G-vec00254-002-s521><decide.festlegen><de> Sie können auch den Speicherort des Ausgabeordners für die wiederhergestellten Elemente festlegen.
<G-vec00254-002-s522><decide.festlegen><en> Now, for instance, users can create a group in which to discuss and decide where to go out together in the evening.
<G-vec00254-002-s522><decide.festlegen><de> Nun kann man beispielsweise in einer Gruppe diskutieren und festlegen, wohin es denn am Abend gemeinsam gehen soll.
<G-vec00254-002-s523><decide.festlegen><en> Afterwards you should decide at home whether you want to continue working with this therapist and then decide with her how to proceed.
<G-vec00254-002-s523><decide.festlegen><de> Danach sollten Sie in Ruhe zu Hause entscheiden, ob Sie mit dieser Therapeutin weiterarbeiten möchten und dann mit ihr das weitere Vorgehen festlegen.
<G-vec00254-002-s524><decide.festlegen><en> The companies, which did not need paid support until now, have to decide in a relatively short time whether they can or want to continue using Java free of charge or need commercial support.
<G-vec00254-002-s524><decide.festlegen><de> Die Unternehmen, die bis dato keinen kostenpflichtigen Support benötigten, müssen nun relativ zeitnah festlegen, ob sie Java weiterhin kostenfrei nutzen können oder wollen oder einen kommerziellen Support benötigen.
<G-vec00254-002-s525><decide.festlegen><en> You must decide which data formats you will provide in the data package.
<G-vec00254-002-s525><decide.festlegen><de> Sie müssen festlegen, welche Datenformate in Ihrem Datenpaket bereitgestellt werden.
<G-vec00254-002-s526><decide.festlegen><en> And therefore, recently a section has appeared in the main menu where a collage of the selected shape is generated in no time (you just need to load the materials, then select the thickness of the frames, and then decide on the resolution and additional parameters on which the final result depends), opens access to instructions that provide answers to frequently asked questions.
<G-vec00254-002-s526><decide.festlegen><de> Daher wurde kürzlich im Hauptmenü ein Abschnitt angezeigt, in dem in kürzester Zeit eine Collage der ausgewählten Form erstellt wird (Sie müssen nur die Materialien laden, dann die Dicke der Rahmen auswählen und dann die Auflösung und zusätzliche Parameter festlegen, von denen das Endergebnis abhängt) Zugriff auf Anweisungen, die Antworten auf häufig gestellte Fragen geben.
<G-vec00254-002-s527><decide.festlegen><en> This policy setting lets you decide whether employees can see the open Microsoft Edge button, which appears next to the New Tab button.
<G-vec00254-002-s527><decide.festlegen><de> Mit dieser Richtlinieneinstellung können Sie festlegen, ob Mitarbeitern die Schaltfläche zum Öffnen von Microsoft Edge angezeigt wird, die neben der Schaltfläche „Neue Registerkarte” erscheint.
<G-vec00254-002-s528><decide.festlegen><en> The campsite can decide for itself whether more than two adults may camp on them (where the CampingCard rate applies to the two adults) or whether the campers will be referred to pitches that are not allocated to CampingCard ACSI users and for which the regular rates will be charged.
<G-vec00254-002-s528><decide.festlegen><de> Der Campingplatz kann selbst festlegen, ob mehr als zwei Erwachsene campen dürfen (wobei dann für zwei Erwachsene der CampingCard-Tarif gilt), oder ob die Camper auf Plätze gewiesen werden, die nicht für CampingCard ACSI-Inhaber bestimmt sind und dafür die üblichen Preise verlangt werden.
<G-vec00254-002-s529><decide.festlegen><en> Configure the standard zoom level of the process portal: You can now decide for your process portal, whether by default a diagram should be displayed completely or in its original size.
<G-vec00254-002-s529><decide.festlegen><de> Standard-Zoomwert der Prozessportal-Anzeige einstellen: Sie können für Ihr Prozessportal nun festlegen, ob beim Anzeigen eines Diagramms dieses standardmäßig vollständig oder in Originalgröße zu sehen ist.
<G-vec00254-002-s530><decide.festlegen><en> Furthermore you have the opportunity to select a thumbnail that appears in the list of presentations and decide whether the presentation shall be "Private", or publicly "Readable" or "Writable".
<G-vec00254-002-s530><decide.festlegen><de> Zudem können Sie beim Erstellen einer neuen Präsentation ein Thumbnail für die Anzeige in der Liste auswählen und festlegen, ob ihre Präsentation "Privat" oder öffentlich "Lesbar" oder "Schreibbar" sein soll.
<G-vec00254-002-s531><decide.festlegen><en> SEDEX is not a policy-making body and will also not decide on or certify standards or policy.
<G-vec00254-002-s531><decide.festlegen><de> SEDEX ist keine strategische Instanz und wird auch keine Standards oder Richtlinien festlegen oder zertifizieren.
<G-vec00254-002-s646><decide.sich_entscheiden><en> In case you decide in favor of a camper trip you will most likely witness the same as we did.
<G-vec00254-002-s646><decide.sich_entscheiden><de> Wenn man sich für einen Campertrip entscheidet, wacht man hier in malerischer Natur auf.
<G-vec00254-002-s647><decide.sich_entscheiden><en> If you decide to grow a garden, you must be able to imagine the final result even before you set the first plant.
<G-vec00254-002-s647><decide.sich_entscheiden><de> Wenn man sich entscheidet, einen Garten anzubauen, muss man in der Lage sein, schon bevor man die erste Pflanze setzt, sich das Endergebnis vorstellen zu können.
<G-vec00254-002-s648><decide.sich_entscheiden><en> And those who decide to work there, like Florentine Degen, have to come to terms with death.
<G-vec00254-002-s648><decide.sich_entscheiden><de> Und wer sich entscheidet, dort zu arbeiten, wie Florentine Degen, muss sich mit dem Tod arrangieren.
<G-vec00254-002-s649><decide.sich_entscheiden><en> It does not matter which series of fittings you decide on - the accessories harmoniously round off the overall impression of the kitchen.
<G-vec00254-002-s649><decide.sich_entscheiden><de> Ganz gleich, für welche Armaturenserie man sich entscheidet, rundet das Zubehör das Gesamtbild der Küche stimmig ab.
<G-vec00254-002-s650><decide.sich_entscheiden><en> If you decide to quit your job, you should deposit your retirement savings in a vested benefits account at an insurance company or bank.
<G-vec00254-002-s650><decide.sich_entscheiden><de> Wer sich für eine Kündigung entscheidet, sollte das angesparte Altersguthaben auf einem Freizügigkeitskonto bei einer Versicherung oder Bank anlegen.
<G-vec00254-002-s651><decide.sich_entscheiden><en> If you decide to use PVR images in your application, you should make sure that these images are only used on those devices that support them.
<G-vec00254-002-s651><decide.sich_entscheiden><de> Wenn man sich für PVR-Grafiken entscheidet, muss zuvor sichergestellt werden, dass diese Grafiken nur auf jenen Mobilgeräten benutzt werden, die sie auch unterstützen.
<G-vec00254-002-s652><decide.sich_entscheiden><en> The check mark (which indicates that the customer wants to purchase the add-on) is already set and can be removed by the customer if they decide not to buy the add-on product.
<G-vec00254-002-s652><decide.sich_entscheiden><de> Der Auswahlhaken (der bestimmt, dass man das Addon zusätzlich kaufen möchte) ist dabei bereits gesetzt und kann vom Kunden entfernt werden, wenn sich gegen den Kauf des Addon-Produkts entscheidet.
<G-vec00254-002-s653><decide.sich_entscheiden><en> Whether remote maintenance, technical on–site service or training courses with practical relevance for users in the most modern equipped training rooms: those who decide in favour of a HEUFT system can rely on its long–term availability.
<G-vec00254-002-s653><decide.sich_entscheiden><de> Ob Fernwartung, technischer Vor–Ort–Service oder praxisnahe Anwendertrainings in modern ausgestatteten Schulungsräumen: Wer sich für ein HEUFT–System entscheidet, kann sich auf dessen langfristige Verfügbarkeit verlassen.
<G-vec00254-002-s654><decide.sich_entscheiden><en> If any of our friends / work colleagues decide to holiday in Spain next year, I shall have Tourism Golf In Malaga
<G-vec00254-002-s654><decide.sich_entscheiden><de> Falls einer unserer Freunde oder Kollegen sich für einen Urlaub in Spanien nächstes Jahr entscheidet, werde ich nicht zögern Sie zu empfehlen.
<G-vec00254-002-s655><decide.sich_entscheiden><en> But if you decide on drugs and alcohol, then your route is predestined.
<G-vec00254-002-s655><decide.sich_entscheiden><de> Aber wenn man sich nur für Drogen und Alkohol entscheidet, dann ist der Weg vorgeplant.
<G-vec00254-002-s656><decide.sich_entscheiden><en> This way of accommodation is a long-time classic… and with a reason: If you decide for accommodation in a host family you will also learn German after class – very individually and completely relaxed – by being a new member of the family… We also take care that you share your room only with a student who has a different native language – in order to make sure that you can really speak German all day long.
<G-vec00254-002-s656><decide.sich_entscheiden><de> Diese Wohnmöglichkeit ist seit langer Zeit ein Klassiker… und das hat vor allem einen Grund: Wer sich für die Unterkunft in einer Gastfamilie entscheidet, der lernt auch nach dem Unterricht noch Deutsch – ganz entspannt und sehr persönlich – als neues Mitglied der Familie… Und damit Sie auch wirklich nur Deutsch sprechen, achten wir darauf, dass Sie Ihr Zimmer mit einem Mitschüler anderer Muttersprache teilen.
<G-vec00254-002-s657><decide.sich_entscheiden><en> You should know what you're getting into when you decide on a vacation in this place, of course.
<G-vec00254-002-s657><decide.sich_entscheiden><de> Man sollte natürlich wissen, worauf man sich einlässt, wenn man sich für einen Urlaub an diesem Ort entscheidet.
<G-vec00254-002-s658><decide.sich_entscheiden><en> At some stage everyone comes to a point, where you have to decide if you are driven by something, or if you want to be the driving force behind others.
<G-vec00254-002-s658><decide.sich_entscheiden><de> Irgendwann kommt jeder an einen Punkt, an dem man sich entscheidet anzutreiben oder angetrieben zu werden.
<G-vec00254-002-s659><decide.sich_entscheiden><en> Remaining uncertain in this area is a suboptimal choice — it’s better to decide one way or the other and be wrong than it is to remain uncertain and do nothing.
<G-vec00254-002-s659><decide.sich_entscheiden><de> Sich mit der Unsicherheit zufrieden zugeben ist eine suboptimale Wahl – es ist besser, wenn man sich für die eine oder andere Option entscheidet und falsch liegt, als wenn man einfach verharrt und gar nichts macht.
<G-vec00254-002-s660><decide.sich_entscheiden><en> Those who decide to study Informatics should possess solid mathematical skills as mathematical contents make up a large proportion of the programme.
<G-vec00254-002-s660><decide.sich_entscheiden><de> Wer sich für ein Studium der Informatik entscheidet, sollte solide mathematische Kenntnisse mitbringen, da mathematische Inhalte einen hohen Anteil des Studiums ausmachen.
<G-vec00254-002-s661><decide.sich_entscheiden><en> The “occasional marketplace fan” prefers to roam undetected through the Internet shopping arcades, and likes to compare prices and quality before they decide.
<G-vec00254-002-s661><decide.sich_entscheiden><de> Der "gelegentliche Marktplatz-Fan" streift am liebsten unerkannt durch die Ladenpassagen im Netz und vergleicht gerne Preise und Produktqualität, bevor er sich entscheidet.
<G-vec00254-002-s662><decide.sich_entscheiden><en> Those who decide to live life as a witch end up in a “witch house.”
<G-vec00254-002-s662><decide.sich_entscheiden><de> Wer sich für das Leben als Hexe entscheidet, endet in einem «Hexenhaus».
<G-vec00254-002-s663><decide.sich_entscheiden><en> These are fragile moments that decide whether an agreement is reached and whether new orders come about.
<G-vec00254-002-s663><decide.sich_entscheiden><de> Es sind fragile Momente, in denen sich entscheidet, ob es zu einer Verständigung kommt, ob neue Ordnungen entstehen.
<G-vec00254-002-s664><decide.sich_entscheiden><en> If you decide to purchase Crea Shot you can be sure that the creatine will not be converted in to the unnecessary and ineffective creatinine. It will also not place a burden on the own organism.
<G-vec00254-002-s664><decide.sich_entscheiden><de> Wer sich für das Kaufen von Crea Shot entscheidet, kann sich somit sicher sein, dass das Creatin nicht in das überflüssige und wirkungslose Creatinin umgewandelt wird und damit auch nicht den eigenen Organismus belastet.
<G-vec00254-002-s665><decide.sich_entschleißen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00254-002-s665><decide.sich_entschleißen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00254-002-s666><decide.sich_entschleißen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00254-002-s666><decide.sich_entschleißen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00254-002-s667><decide.sich_entschleißen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00254-002-s667><decide.sich_entschleißen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00254-002-s668><decide.sich_entschleißen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00254-002-s668><decide.sich_entschleißen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00254-002-s669><decide.sich_entschleißen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00254-002-s669><decide.sich_entschleißen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00254-002-s670><decide.sich_entschleißen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00254-002-s670><decide.sich_entschleißen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00254-002-s671><decide.sich_entschleißen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00254-002-s671><decide.sich_entschleißen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00254-002-s672><decide.sich_entschleißen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00254-002-s672><decide.sich_entschleißen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00254-002-s673><decide.sich_entschleißen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00254-002-s673><decide.sich_entschleißen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00254-002-s674><decide.sich_entschleißen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00254-002-s674><decide.sich_entschleißen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00254-002-s675><decide.sich_entschleißen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00254-002-s675><decide.sich_entschleißen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00254-002-s676><decide.sich_entschleißen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00254-002-s676><decide.sich_entschleißen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00254-002-s677><decide.sich_entschleißen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00254-002-s677><decide.sich_entschleißen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00254-002-s678><decide.sich_entschleißen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00254-002-s678><decide.sich_entschleißen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00254-002-s679><decide.sich_entschleißen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00254-002-s679><decide.sich_entschleißen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00254-002-s680><decide.sich_entschleißen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00254-002-s680><decide.sich_entschleißen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00254-002-s681><decide.sich_entschleißen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00254-002-s681><decide.sich_entschleißen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00254-002-s682><decide.sich_entschleißen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00254-002-s682><decide.sich_entschleißen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00254-002-s683><decide.sich_entschleißen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00254-002-s683><decide.sich_entschleißen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00254-002-s722><decide.wählen><en> You can decide if you would rather glide along the Peene, the "Amazon of the north", or cruise around the famous chalk cliffs at Kap Arkona.
<G-vec00254-002-s722><decide.wählen><de> Wählen Sie, ob Sie lieber die Peene, den "Amazonas des Nordens", entlanggleiten oder die berühmten Kreidefelsen am Kap Arkona umschiffen möchten.
<G-vec00254-002-s723><decide.wählen><en> You can decide whether you want to visit Budapest's biggest malls, or you want to go to the famous Váci street, our guides will take you there.
<G-vec00254-002-s723><decide.wählen><de> Du kannst wählen, ob du die größten Einkaufszentren vonBudapest oder die berühmte Váci Straße besuchen willst, unsere Guidesbegleiten dich.
<G-vec00254-002-s724><decide.wählen><en> Internet gambling halls provide table games with one big difference, if you decide on your casino thoroughly, these games are winnable.
<G-vec00254-002-s724><decide.wählen><de> Web Spielhöllen bieten Tabellen mit einem großen Unterschied, wenn Sie Ihren Online-Casino wählen Sie vorsichtig, diese Casino-Spiele sind schlagbar.
<G-vec00254-002-s725><decide.wählen><en> Read a good book on the rocking chair on your balcony, or leaf through our brochures and decide which wellness treatment you'd like to book.
<G-vec00254-002-s725><decide.wählen><de> Ein gutes Buch, der Schaukelstuhl auf Ihrem Balkon und der See … oder Sie blättern im Spa-Prospekt und wählen, welche Anwendung Sie am Nachmittag gerne machen möchten.
<G-vec00254-002-s726><decide.wählen><en> In dealing with the same quality of stone – and this is the case for quarries – it is possible to decide on and maintain an optimal speed.
<G-vec00254-002-s726><decide.wählen><de> Sägeplan Wenn Steine von gleicher Qualität bearbeitet werden – und dies ist der Fall bei Steinbrüchen -, kann man die optimale Geschwindigkeit wählen und auch beibehalten.
<G-vec00254-002-s727><decide.wählen><en> If you decide not to use cookies, the session data will be transmitted in every links you click.
<G-vec00254-002-s727><decide.wählen><de> Wenn Sie wählen, dass diese Informationen nicht in einem Cookie gespeichert werden sollen, so werden die Sitzungs-Daten mit jedem Link, auf den Sie klicken, mitversendet.
<G-vec00254-002-s728><decide.wählen><en> If you are trying to find the most powerful alternative, you need to decide on Phen375.
<G-vec00254-002-s728><decide.wählen><de> Wenn Sie die leistungsfähigste Alternative suchen, sollten Sie Phen375 wählen.
<G-vec00254-002-s729><decide.wählen><en> Decide for yourself how you would like to use our facilities.
<G-vec00254-002-s729><decide.wählen><de> Wählen Sie, wie Sie unsere Angebote nutzen möchten.
<G-vec00254-002-s730><decide.wählen><en> Using drag-and-drop technology, you’ll glide through your analysis – decide which question you want to analyze, what type of analysis you want to perform and in two clicks generate your graph or table, ready to be added to the report!
<G-vec00254-002-s730><decide.wählen><de> Die Analyse mit der Drag and Drop Technik Verschieben Sie die Frage, die Sie analysieren möchten, mit der Drag and Drop Technik in Ihren Fragebogen und wählen Sie, welche Art von Analyse Sie durchführen wollen.
<G-vec00254-002-s732><decide.wählen><en> When registering to set up your Swisscom Login you can decide whether you want to authenticate the registration via your mobile number, your land line or through the post.
<G-vec00254-002-s732><decide.wählen><de> Bei der Registrierung zur Einrichtung Ihres Swisscom Login können Sie wählen, ob wir Sie über Ihre Mobiltelefonnummer, Ihren Festnetzanschluss oder auf dem Postweg authentifizieren.
<G-vec00254-002-s733><decide.wählen><en> In such a case you can decide whether you still want to enforce your claim at your own expense.
<G-vec00254-002-s733><decide.wählen><de> Sie können in diesem Fall wählen, ob Sie Ihre Forderung auf Ihre eigenen Kosten weiterverfolgen wollen.
<G-vec00254-002-s734><decide.wählen><en> If agreement has not been reached concerning the procedure for the enquiry, the Parties should agree on the choice of an umpire who will decide upon the procedure to be followed.
<G-vec00254-002-s734><decide.wählen><de> Kann über das Untersuchungsverfahren keine Übereinstimmung erzielt werden, so kommen die Parteien überein, einen Schiedsrichter zu wählen, der über das zu befolgende Verfahren entscheidet.
<G-vec00254-002-s735><decide.wählen><en> If the delivered item is defective, we can at first decide whether we provide a supplementary performance by eliminating the defect (improvement) or by delivering a faultless item (replacement).
<G-vec00254-002-s735><decide.wählen><de> 7.5 Ist die gelieferte Sache mangelhaft, können wir zunächst wählen, ob wir Nacherfüllung durch Beseitigung des Mangels (Nachbesserung) oder durch Lieferung einer mangelfreien Sache (Ersatzlieferung) leisten.
<G-vec00254-002-s736><decide.wählen><en> In the first part of the dialog you can decide wheter you want to convert the text from all text symbols or only objects from a selected symbol.
<G-vec00254-002-s736><decide.wählen><de> Im ersten Teil des Dialogs können Sie wählen, ob Sie alle Objekte von allen Textsymbolen oder nur Objekte von einem selektierten Symbol umwandeln möchten.
<G-vec00254-002-s737><decide.wählen><en> You can decide how much privacy you prefer.
<G-vec00254-002-s737><decide.wählen><de> Sie wählen, wie viel Privatsphäre Sie möchten.
<G-vec00254-002-s738><decide.wählen><en> Consumers can decide the delivery days and locations that work best for their schedules - and you can benefit from their improved satisfaction with shipping and collection.
<G-vec00254-002-s738><decide.wählen><de> Kunden können den Tag und Ort der Lieferung wählen, der ihnen am besten passt - und Sie profitieren von gesteigerter Kundenzufriedenheit mit Lieferung und Abholung.
<G-vec00254-002-s739><decide.wählen><en> You just have to decide in which direction to point your bike.
<G-vec00254-002-s739><decide.wählen><de> Man braucht nur zu wählen, wohin man das Fahrrad lenken will.
<G-vec00254-002-s740><decide.wählen><en> You can decide between the following methods of payment: Cash, credit card, invoice, electronic direct debit (ELV) or AirPlus credit card (corporate customers).
<G-vec00254-002-s740><decide.wählen><de> Sie können zwischen den folgenden Bezahlmethoden wählen: Bar, Kreditkarte, Rechnung, Elektronisches Lastschriftverfahren (ELV) oder AirPlus-Kreditkarte (Geschäftskunden).
<G-vec00254-002-s779><decide.überlegen><en> We would not be the Insomnia if we did not go a little further: The fine line between harmless cuddles and deliberate touches is narrow and so there will be a second part of the party where everyone can decide whether he wants to participate or stay with the intentionless cuddling.
<G-vec00254-002-s779><decide.überlegen><de> Wir wären ja nicht das Insomnia, wenn wir nicht auch ein wenig weiter gehen würden: Der Grat aus harmlosen Kuscheln zu absichtvollen Berührungen ist schmal und so wird es einen zweiten Teil der Party geben, bei dem sich jeder überlegen kann ob er mitmachen will oder es beim absichtslosen Kuscheln belässt.
<G-vec00254-002-s780><decide.überlegen><en> Our search engine will help you book a flight to Milwaukee - all you have to do, is decide what to pack.
<G-vec00254-002-s780><decide.überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Milwaukee-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s781><decide.überlegen><en> After deciding whether you wish to operate your child-care business at home or in an independent facility, the next step is to decide what type of child care you would like to offer.
<G-vec00254-002-s781><decide.überlegen><de> Nachdem du dich entschlossen hast, ob du deine Kinderbetreuungseinrichtung bei dir zuhause oder in externen Räumlichkeiten eröffnen willst, ist der nächste Schritt, zu überlegen, welche Art Kinderbetreuungseinrichtung du gerne anbieten würdest.
<G-vec00254-002-s782><decide.überlegen><en> As far as the opening of the TLD catalogue is concerned, trademark owners must decide whether they wish to have their trademark(s) registered as a TLD, and they should also think about how to defend their trademarks against new TLDs that infringe upon their trademark(s).
<G-vec00254-002-s782><decide.überlegen><de> Markeninhaber müssen sich im Zusammenhang mit der Öffnung des TLD-Katalogs zum einen überlegen, ob sie ihre Marke(n) als TLD registrieren wollen und zum anderen darüber nachdenken, wie sie ihre Marken gegen neue TLDs verteidigen, welche ihre Marke(n) verletzen.
<G-vec00254-002-s783><decide.überlegen><en> And if the price is already in the internet, then I can decide whether I am going to play along or not.
<G-vec00254-002-s783><decide.überlegen><de> Und wenn es den Preis im Internet bereits gibt, dann kann ich mir überlegen, ob ich da mitspiele oder nicht.
<G-vec00254-002-s784><decide.überlegen><en> The children repeat the different steps of working with the Clip Art program and decide which picture each child will paint so that all important procedures are covered and documented.
<G-vec00254-002-s784><decide.überlegen><de> Die Kinder wiederholen die verschiedenen Schritte zur Arbeit mit dem Clip Art-Programm und überlegen, welche Bilder jedes einzelne Kind malt, so dass alle wichtigen Vorgänge dokumentiert werden.
<G-vec00254-002-s785><decide.überlegen><en> Watch the dancing waves from your four-poster sunbed next to a private plunge pool, as you decide what to have for dinner.
<G-vec00254-002-s785><decide.überlegen><de> Während Ihr vom Himmelbett direkt neben Eurem eigenen Pool den Wellen zuseht, könnt Ihr Euch schon einmal überlegen, was Ihr zu Abend essen möchtet.
<G-vec00254-002-s786><decide.überlegen><en> When opting for WordPress hosting, you need to decide what exactly your website should offer its users.
<G-vec00254-002-s786><decide.überlegen><de> Wenn Sie sich für Managed-WordPress-Hosting entscheiden, müssen Sie sich nur noch überlegen, was Ihre Website den Besuchern bieten soll.
<G-vec00254-002-s787><decide.überlegen><en> Instead of giving the answer, the teacher split the class into two groups, male and female, and asked them to decide for themselves whether computer' should be a masculine or a feminine noun.
<G-vec00254-002-s787><decide.überlegen><de> Anstatt einer Antwort, teilte der Lehrer die Klasse in zwei Gruppen ein, Frauen und Männer, und beauftragte sie, selber zu überlegen, ob "Computer" männlich oder weiblich sei.
<G-vec00254-002-s788><decide.überlegen><en> If you decide to install your own Wi-Fi access points, approval from LRZ is required.
<G-vec00254-002-s788><decide.überlegen><de> Falls Sie überlegen, eigene WLAN-Access Points zu installieren, ist eine Genehmigung durch das LRZ notwendig.
<G-vec00254-002-s789><decide.überlegen><en> You can then see the result on-screen and decide whether you want to continue with or cancel the print job.
<G-vec00254-002-s789><decide.überlegen><de> Sie können sich das Ergebnis anschließend am Bildschirm anschauen und überlegen, ob Sie den Druckauftrag fortsetzen oder stornieren wollen.
<G-vec00254-002-s790><decide.überlegen><en> Our search engine will help you book a flight to Victoria Inner Harbour - all you have to do, is decide what to pack.
<G-vec00254-002-s790><decide.überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Victoria Inner Harbour-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s791><decide.überlegen><en> Because of this, you can decide if you want to cover the inside of the zine with artwork as well.
<G-vec00254-002-s791><decide.überlegen><de> Daher kannst du überlegen, ob du das Innere des Buches auch illustrieren willst.
<G-vec00254-002-s792><decide.überlegen><en> The second step in planning your wedding is to decide when the event should take place.
<G-vec00254-002-s792><decide.überlegen><de> Der zweite Schritt ist zu überlegen, wann die Hochzeit statt finden soll.
<G-vec00254-002-s793><decide.überlegen><en> First, you need to decide which data formats and data types to implement.
<G-vec00254-002-s793><decide.überlegen><de> Zunächst müssen Sie überlegen, welche Datenformate und Datentypen implementiert werden müssen.
<G-vec00254-002-s794><decide.überlegen><en> There is now the occasion to decide about how much of customization should really be retained.
<G-vec00254-002-s794><decide.überlegen><de> Es ist auch der Moment, zu überlegen, wieviel Anpassung (Customization) überhaupt beibehalten werden soll.
<G-vec00254-002-s795><decide.überlegen><en> I’d rather drink a cup of tea with her first, gab with her and then at the end decide whether or not to kiss her hand.
<G-vec00254-002-s795><decide.überlegen><de> Eher würde ich zuerst einen Tee mit ihr trinken, mit ihr tratschen und dann zum Abschied überlegen, ob ich ihr vielleicht die Hand küsse.
<G-vec00254-002-s796><decide.überlegen><en> You will have to collectively discuss and decide how to answer each question.
<G-vec00254-002-s796><decide.überlegen><de> Ihr müsst gemeinsam überlegen, wie ihr jede dieser Fragen beantworten wollt.
<G-vec00254-002-s797><decide.überlegen><en> Whether you have already introduced some happy hens to your garden or you're trying to decide if keeping chickens is for you, you're in the right place.
<G-vec00254-002-s797><decide.überlegen><de> Egal ob Sie schon in Ihrem Garten ein paar glückliche Hühner haben oder Sie noch überlegen, ob die Hühnerhaltung etwas für Sie ist, so sind Sie hier am richtigen Platz.
<G-vec00297-002-s551><decide.möchten><en> If you decide to leave the Developer Preview Program, you’ll have to do a factory reset on your Xbox One console.
<G-vec00297-002-s551><decide.möchten><de> Wenn Sie das Developer Preview Program verlassen möchten, müssen Sie die Xbox One Konsole auf die Werkseinstellungen zurücksetzen.
<G-vec00297-002-s552><decide.möchten><en> If you decide not to send your message, click Cancel.
<G-vec00297-002-s552><decide.möchten><de> Wenn Sie Ihre Nachricht nicht versenden möchten, klicken Sie auf Abbruch.
<G-vec00297-002-s553><decide.möchten><en> If you decide to change your password, the facebook connect will no longer work.
<G-vec00297-002-s553><decide.möchten><de> Wenn Sie Ihr Passwort ändern möchten, funktioniert Facebook Connect nicht mehr.
<G-vec00297-002-s554><decide.möchten><en> When you decide not to show content, the window is see-through and looks just like any window.
<G-vec00297-002-s554><decide.möchten><de> Wenn Sie nichts anzeigen möchten, ist das Fenster transparent und sieht wie ein gewöhnliches Fenster aus.
<G-vec00297-002-s555><decide.möchten><en> Address, Email address, First name / Last name, Radisson Rewards membership number, Stay details, Telephone number, and any other data you may decide to share with us in open comment boxes.
<G-vec00297-002-s555><decide.möchten><de> Adresse, E-Mail-Adresse, Vorname/Nachname, Radisson Rewards Mitgliedsnummer, Aufenthaltsdetails, Telefonnummer und alle anderen Daten, die Sie in offenen Kommentarboxen mit uns teilen möchten.
<G-vec00297-002-s556><decide.möchten><en> Your hosts very much look forward to seeing you soon and are happy to provide all the information you need, responding to your requests and ideas as soon as you decide to rent our catered chalet in South Tyrol.
<G-vec00297-002-s556><decide.möchten><de> Ihr Gastgeberpaar freut sich auf Sie und steht gerne für Informationen, Wünsche und Vorstellungen bereit, sobald Sie das Chalet in Südtirol mieten möchten.
<G-vec00297-002-s557><decide.möchten><en> And yes, it’s allowed on airplanes too if you decide to fly.
<G-vec00297-002-s557><decide.möchten><de> Und ja, es ist auch in Flugzeugen erlaubt, wenn Sie fliegen möchten.
<G-vec00297-002-s558><decide.möchten><en> Keep files private until you decide to share them.
<G-vec00297-002-s558><decide.möchten><de> Stellen Sie sicher, dass Dateien so lange privat bleiben, bis Sie sie freigeben möchten.
<G-vec00297-002-s559><decide.möchten><en> To allow you to share the information you decide to disclose to the users of Navionics’ services, we will use data relating to your location and the personal information that you will decide to post using certain features which will be activated exclusively upon your request.
<G-vec00297-002-s559><decide.möchten><de> Damit Sie Informationen teilen können, die Sie anderen Benutzern von Navionics-Diensten offenlegen möchten, verwenden wir Daten zu Ihrer Position sowie die personenbezogenen Daten, die Sie mithilfe bestimmter Funktionen im Beitrag veröffentlichen möchten, wobei diese Funktionen nur nach ausdrücklicher Anweisung durch Sie aktiviert werden.
<G-vec00297-002-s561><decide.möchten><en> If you decide not to use the template you opened, close the template (if you made any changes to it, click Delete in the dialog), then open another one.
<G-vec00297-002-s561><decide.möchten><de> Wenn Sie die geöffnete Vorlage nicht verwenden möchten, schließen Sie die Vorlage (wenn Sie bereits Änderungen vorgenommen haben, klicken Sie im angezeigten Dialogfenster auf „Löschen“) und öffnen Sie eine andere Vorlage.
<G-vec00297-002-s562><decide.möchten><en> If you decide to opt-out of any future tracking, a cookie will be set up in your browser to remember this choice for one year.
<G-vec00297-002-s562><decide.möchten><de> Falls Sie aus diesem Tracking aussteigen möchten, wird ein Cookie in ihrem Browser angelegt, um diese Entscheidung für ein Jahr zu gewährleisten.
<G-vec00297-002-s563><decide.möchten><en> Should you decide to change your preferences later through your browsing session, you can click on the „Privacy & Cookie Policy“ tab on your screen.
<G-vec00297-002-s563><decide.möchten><de> Wenn Sie Ihre Einstellungen später während Ihrer Browsersitzung ändern möchten, können Sie auf Ihrem Bildschirm auf die Registerkarte "Datenschutz- und Cookie-Richtlinie" klicken.
<G-vec00297-002-s564><decide.möchten><en> Should you decide to change your preferences later through your browsing session, you can click on the “Privacy & Cookie Policy” tab on your screen.
<G-vec00297-002-s564><decide.möchten><de> Wenn Sie Ihre Einstellungen später während Ihrer Browsersitzung ändern möchten, können Sie auf dem Bildschirm auf die Registerkarte „Datenschutz-Cookie-Richtlinie“ klicken.
<G-vec00297-002-s565><decide.möchten><en> For example, if you decide to store content in the public folder, the content will be public and available to anyone on the Internet who can find the folder.
<G-vec00297-002-s565><decide.möchten><de> Wenn Sie beispielsweise Inhalte im öffentlichen Ordner speichern möchten, wird der Inhalt der Öffentlichkeit und für jeden im Internet zugänglich, der diesen Ordner finden kann.
<G-vec00297-002-s566><decide.möchten><en> If you decide to visit Magnitogorsk, but do not know where to stay, our hotel is ready to offer you the best apartments.
<G-vec00297-002-s566><decide.möchten><de> Wenn Sie Magnitogorsk besuchen möchten, aber keine Ahnung haben, wo man unterhalten kann, ist unser Hotel bereit, die besten Zimmer zur Verfügung zu stellen.
<G-vec00297-002-s567><decide.möchten><en> Crew insurance is an issue to consider when you decide to rent a yacht.
<G-vec00297-002-s567><decide.möchten><de> Die Versicherung der Besatzung ist ein Thema, das Sie berücksichtigen sollten, wenn Sie eine Yacht mieten möchten.
<G-vec00297-002-s568><decide.möchten><en> This assures you that your gas fire is safe and ready for use at the time that you decide to enjoy it.
<G-vec00297-002-s568><decide.möchten><de> Das verschafft Ihnen die Gewissheit eines sicheren Gaskamins, der zu den Zeiten, an denen Sie ihn genießen möchten, einsatzbereit ist.
<G-vec00297-002-s569><decide.möchten><en> If you decide to use a compatible smart device*, you will need to download the new Dexcom G6 app.
<G-vec00297-002-s569><decide.möchten><de> Wenn Sie ein kompatibles Kommunikationsgerät* verwenden möchten, müssen Sie die neue G6-App herunterladen.
<G-vec00297-002-s703><decide.wollen><en> If students decide to discontinue coursework that has already been commenced in spite of an extension, an individual course of action shall be determined by the respective Examination Board.
<G-vec00297-002-s703><decide.wollen><de> Sollten Studierende eine angefangene Prüfungsleistung trotz Fristverlängerung abbrechen wollen, entscheidet der jeweilige Prüfungsausschuss über den Einzelfall.
<G-vec00297-002-s704><decide.wollen><en> If you decide to use it later, you can acquire a license from the online order page.
<G-vec00297-002-s704><decide.wollen><de> Wenn Sie es länger benutzen wollen, können Sie über die Online-Bestellseite eine Lizenz erwerben.
<G-vec00297-002-s705><decide.wollen><en> Ben je in de stemming voor je eigen Private tired of satisfying their ardent desires amongst themselves, they decide to spend a few days in the Alps in search of new, hot and wild sexual experiences which are capable of melting Albertville itself.
<G-vec00297-002-s705><decide.wollen><de> Lernen Sie diese sechs Zimmergefährten kennen, die, nachdem sie sich gegenseitig alle Wünsche erfüllt haben, einige Tagen in den Alpen verbringen wollen, um dort nach neuen, erregenden Sexerlebnissen zu suchen, die das Eis in dem kleinen Ort Albertville zum Schmelzen bringen werden.
<G-vec00297-002-s706><decide.wollen><en> If you decide to purchase a domain and search for terms and keywords such as Collaborative,Cooperation network,Network perhaps the search for your desired domain is now over.
<G-vec00297-002-s706><decide.wollen><de> Wenn Sie eine Domain erwerben wollen und nach Begriffen und Stichwörtern wie Kooperationsnetze,Netzwerk,Zusammenarbeit suchen, ist vielleicht jetzt die Suche nach Ihrer Wunschdomain beendet.
<G-vec00297-002-s707><decide.wollen><en> If you decide to purchase a domain and search for terms and keywords such as Automatically,Identification,Indexing perhaps the search for your desired domain is now over.
<G-vec00297-002-s707><decide.wollen><de> Wenn Sie eine Domain erwerben wollen und nach Begriffen und Stichwörtern wie Automatisch,Erkennung,Indizierung suchen, ist vielleicht jetzt die Suche nach Ihrer Wunschdomain beendet.
<G-vec00297-002-s708><decide.wollen><en> For those who decide to get around Venice by car the hotel offers on-site parking at no additional charge.
<G-vec00297-002-s708><decide.wollen><de> Für alle, die Venedig mit dem Auto erkunden wollen, bietet das Hotel einen hoteleigenen Parkplatz, den Sie kostenlos nutzen können.
<G-vec00297-002-s709><decide.wollen><en> Visitors may set their browsers to provide notice before they receive a cookie, giving the opportunity to decide whether to accept the cookie.
<G-vec00297-002-s709><decide.wollen><de> Besucher können ihren Browser so einstellen, dass Sie die Möglichkeit haben, bevor sie ein Cookie erhalten, gefragt zu werden, ob Sie das Cookie akzeptieren wollen oder nicht.
<G-vec00297-002-s710><decide.wollen><en> It is easiest, of course, to let the little ones decide which model from the current collection by Kjus for children is the best for them.
<G-vec00297-002-s710><decide.wollen><de> Am einfachsten ist es natürlich, man lässt die Kleinen mitentscheiden, welches Modell aus der aktuellen Kollektion von Kjus für Kinder sie haben wollen.
<G-vec00297-002-s711><decide.wollen><en> Fixed rate break fee: most lenders can charge this fee is you have a fixed-rate loan and you decide to repay your loan early.
<G-vec00297-002-s711><decide.wollen><de> Gebühr für vorzeitige Kreditrückzahlung: Sollten Sie Ihren Kredit vorzeitig zurückzahlen wollen, müssen Sie diese Gebühr möglicherweise zahlen.
<G-vec00297-002-s712><decide.wollen><en> At any point, you can use a backspace to back up what you are drawing in case you decide to change directions.
<G-vec00297-002-s712><decide.wollen><de> Sie können jederzeit mit der Backspace-Taste das von Ihnen Gezeichnete rückgängig machen, wenn Sie die Richtung ändern wollen.
<G-vec00297-002-s713><decide.wollen><en> The plot is located in a very quiet and peaceful location surrounded by trees which would future owners (whether they decide to build a family house or apartment building) allow peace and tranquility throughout the whole year.
<G-vec00297-002-s713><decide.wollen><de> Die Immobilie befindet sich im ruhigen Teil Brodaricas und ist vom Wald umgeben, was den zukünftigen Eigentümern Ruhe und Frieden das ganze Jahr hidurch bietet (egal ob sie ein Familienhaus oder Apartment-Gebäude bauen wollen).
<G-vec00297-002-s714><decide.wollen><en> If you decide to purchase the goods in your shopping cart, press "Continue to Next Step".
<G-vec00297-002-s714><decide.wollen><de> Wenn Sie die Produkte im Warenkorb kaufen wollen, klicken Sie den Button "weiter zum nächsten Schritt".
<G-vec00297-002-s715><decide.wollen><en> Getting around For those who decide to get around Tenerife by car the hotel offers nearby parking at no additional charge.
<G-vec00297-002-s715><decide.wollen><de> Für alle, die Teneriffa mit dem Auto erkunden wollen, bietet das Hotel einen in der Nähe Parkplatz, den Sie kostenlos nutzen können.
<G-vec00297-002-s716><decide.wollen><en> However, if you decide to stop there, you will get a digital attendance certificate according to the level completed.
<G-vec00297-002-s716><decide.wollen><de> Wenn Sie das aber nicht wollen, erhalten Sie eine Bestätigung der digitalen Anwesenheit für Ihr Level.
<G-vec00297-002-s717><decide.wollen><en> Women who decide to give up the traditional family cycle often join the women’s self-defence forces, such as the YPJ, dedicating their lives to defend the revolution and the people.
<G-vec00297-002-s717><decide.wollen><de> Frauen, die mit diesem Familienkreislauf brechen wollen, die auf der Suche nach einem befreiten Leben sind, schließen sich oft den Selbstverteidigungseinheiten (YPJ) an, um ihr Leben der Verteidigung und Befreiung der Bevölkerung zu widmen.
<G-vec00297-002-s718><decide.wollen><en> With this I do not wish to criticise certain individual voters, since we all have the freedom to vote for whomever we decide – be it a conservative, a social democrat, a communist or a nationalist.
<G-vec00297-002-s718><decide.wollen><de> An dieser Stelle möchte ich nicht einzelne Wähler*innen kritisieren, immerhin haben wir alle Wahlfreiheit und können stimmen für wen wir wollen – sei es konservativ, sozialdemokratisch, kommunistisch oder nationalistisch.
<G-vec00297-002-s719><decide.wollen><en> If you decide to purchase a domain and search for terms and keywords such as Business,Client,File perhaps the search for your desired domain is now over.
<G-vec00297-002-s719><decide.wollen><de> Wenn Sie eine Domain erwerben wollen und nach Begriffen und Stichwörtern wie Akte,Geschäft,Kunde suchen, ist vielleicht jetzt die Suche nach Ihrer Wunschdomain beendet.
<G-vec00297-002-s720><decide.wollen><en> And if you decide to stick around, the Sphere restaurant has - as you can imagine - pretty nice window tables.
<G-vec00297-002-s720><decide.wollen><de> Wenn Sie dort etwas länger bleiben wollen, hat das Sphere Restaurant - wie Sie sich denken können - nette Tische am Fenster.
<G-vec00297-002-s721><decide.wollen><en> Therefore you may decide to avoid whey protein powders in favor of another, if slightly less powerful type - beef or egg protein, for instance.
<G-vec00297-002-s721><decide.wollen><de> Aus diesem Grund könntest Du Molkeneiweißpulver zugunsten eines anderen, leicht weniger effektiven Pulvertyps vermeiden wollen – Rind- oder Hühnereiweiß zum Beispiel.
<G-vec00509-002-s570><decide.bestimmen><en> I wanted the starting block to be special, we can all decide on how much work we put into the starting row.
<G-vec00509-002-s570><decide.bestimmen><de> Der Startblock soll etwas Besonderes sein, jeder kann selbst bestimmen wie viel Arbeit er in seine Startreihe steckt.
<G-vec00509-002-s571><decide.bestimmen><en> All your adverts shown together, with a personal touch because you decide the layout, color, logo, photos and text of your website!
<G-vec00509-002-s571><decide.bestimmen><de> Alle Ihre Artikel werden zusammen präsentiert, mit einer persönlichen Note, da Sie selbst das Layout, Farbe und Logo Ihrer Website bestimmen.
<G-vec00509-002-s572><decide.bestimmen><en> You can decide how to invest them or spend them.
<G-vec00509-002-s572><decide.bestimmen><de> Sie können auch selbst bestimmen, wie Sie dieses anlegen und wann Sie es aufbrauchen möchten.
<G-vec00509-002-s573><decide.bestimmen><en> From the moment you open the app, you can decide when you want to connect to your Deeper sonar, start a new fishing session, pause and resume it whenever you choose to get back to it.
<G-vec00509-002-s573><decide.bestimmen><de> Scansteuerung Ab dem ersten Öffnen der App haben Sie die Möglichkeit, den Verbindungzeitpunkt zu Ihrem Deeper Sonar selbst zu bestimmen, eine neue Angelsitzung zu starten, sie anzuhalten oder mit ihr fortzufahren, wann immer Sie dies wünschen.
<G-vec00509-002-s574><decide.bestimmen><en> Changes would also permit each plant to decide the level of bruises, feathers, bile or ingesta appropriate for birds going down the line.
<G-vec00509-002-s574><decide.bestimmen><de> Die Änderungen würden es auch jedem Betrieb gestatten, selbst zu bestimmen, in welchem Umfang bei den zu verarbeitenden Tieren blaue Flecken, Federn, Galle und Ingesta toleriert werden können.
<G-vec00509-002-s575><decide.bestimmen><en> Because you have manual bidding enabled, it is up to you to decide the price here.
<G-vec00509-002-s575><decide.bestimmen><de> Da Du das manuelle Bieten aktiviert hast, kannst Du den Preis selbst bestimmen.
<G-vec00509-002-s576><decide.bestimmen><en> It should be up to you to decide on the equipment you want to use.
<G-vec00509-002-s576><decide.bestimmen><de> Sie können selbst bestimmen, welche Systeme Sie einsetzen möchten.
<G-vec00509-002-s577><decide.bestimmen><en> You can decide how many apps, contacts, and links will make it on to your homescreen.
<G-vec00509-002-s577><decide.bestimmen><de> Du kannst selbst bestimmen, wie viele Apps, Kontakte und Verknüpfungen auf einem Homescreen Platz finden.
<G-vec00509-002-s578><decide.bestimmen><en> In the absence of any agreement otherwise, we are entitled to decide the method of transport (in particular the transport company, route and packaging).
<G-vec00509-002-s578><decide.bestimmen><de> Soweit nicht etwas anderes vereinbart ist, sind wir berechtigt, die Art der Versendung (insbesondere Transportunternehmen, Versandweg, Verpackung) selbst zu bestimmen.
<G-vec00509-002-s579><decide.bestimmen><en> In order to offer you a larger selection, we always shoot a slightly larger selection of pictures, so that you can decide flexibly.
<G-vec00509-002-s579><decide.bestimmen><de> Um Dir eine größere Auswahl zu bieten schießen wir immer eine etwas größere Auswahl an Bildern, sodass Du Deinen Favoriten selbst bestimmen kannst.
<G-vec00509-002-s580><decide.bestimmen><en> First, a driver cannot decide the fare.
<G-vec00509-002-s580><decide.bestimmen><de> Erstens kann er den Fahrpreis nicht selbst bestimmen.
<G-vec00509-002-s581><decide.bestimmen><en> That is a good requirement for a successful future: Ace Of Base don't have to rely on other people's ideas and can decide on their own musical direction.
<G-vec00509-002-s581><decide.bestimmen><de> Das ist eine gute Voraussetzung für eine erfolgreiche Zukunft: Ace of Base müssen sich nicht auf die Ideen anderer verlassen und können ihre musikalische Richtung selbst bestimmen.
<G-vec00509-002-s582><decide.bestimmen><en> Students will be able to decide the duration of their deployment and arrange their work schedules to fit around other commitments.
<G-vec00509-002-s582><decide.bestimmen><de> Sie können die Dauer ihres Einsatzes und die tägliche Arbeitszeit nach Verfügbarkeit selbst bestimmen.
<G-vec00509-002-s583><decide.bestimmen><en> This is a completely legal tactic, as it is up to any individual player to decide his own best strategy.
<G-vec00509-002-s583><decide.bestimmen><de> Da jeder Spieler seine Strategie selbst bestimmen kann, ist dies eine vollkommen zulässige Taktik.
<G-vec00509-002-s584><decide.bestimmen><en> Shariff Wrapper enables you to decide, whether and when to transfer data to social networks.
<G-vec00509-002-s584><decide.bestimmen><de> Mit Hilfe von Shariff können Sie selbst bestimmen, ob und wann Daten an die Betreiber der jeweiligen sozialen Netzwerke übermittelt werden.
<G-vec00509-002-s585><decide.bestimmen><en> You decide about the amount you want to give.
<G-vec00509-002-s585><decide.bestimmen><de> Sie selbst bestimmen die Höhe des Gutscheines.
<G-vec00509-002-s586><decide.bestimmen><en> From luxury lodges to local community–run basic campsites, you can decide the flavour of your safari experience.
<G-vec00509-002-s586><decide.bestimmen><de> Von Luxus Lodgen bis hin zu Zeltcamps, so dass Sie selbst den Stil ihrer einzigartigen Safari bestimmen können.
<G-vec00509-002-s587><decide.bestimmen><en> Each room features its own temperature control so you can decide how warm you Architektur Neuigkeiten zum Projekt
<G-vec00509-002-s587><decide.bestimmen><de> Jedes Zimmer verfügt über eine eigene Temperaturregulierung, sodass Sie selbst bestimmen können, wo es wie warm sein soll.
<G-vec00509-002-s588><decide.bestimmen><en> This means that you decide whether or not you want to receive our newsletters and other information about new opportunities, events, and services.
<G-vec00509-002-s588><decide.bestimmen><de> Das bedeutet, dass Sie selbst bestimmen, ob Sie unsere Rundschreiben und andere Informationen über neue Möglichkeiten, Veranstaltungen und Dienstleistungen erhalten möchten.
<G-vec00509-002-s665><decide.entschließen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00509-002-s665><decide.entschließen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00509-002-s666><decide.entschließen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00509-002-s666><decide.entschließen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00509-002-s667><decide.entschließen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00509-002-s667><decide.entschließen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00509-002-s668><decide.entschließen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00509-002-s668><decide.entschließen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00509-002-s669><decide.entschließen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00509-002-s669><decide.entschließen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00509-002-s670><decide.entschließen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00509-002-s670><decide.entschließen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00509-002-s671><decide.entschließen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00509-002-s671><decide.entschließen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00509-002-s672><decide.entschließen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00509-002-s672><decide.entschließen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00509-002-s673><decide.entschließen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00509-002-s673><decide.entschließen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00509-002-s674><decide.entschließen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00509-002-s674><decide.entschließen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00509-002-s675><decide.entschließen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00509-002-s675><decide.entschließen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00509-002-s676><decide.entschließen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00509-002-s676><decide.entschließen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00509-002-s677><decide.entschließen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00509-002-s677><decide.entschließen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00509-002-s678><decide.entschließen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00509-002-s678><decide.entschließen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00509-002-s679><decide.entschließen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00509-002-s679><decide.entschließen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00509-002-s680><decide.entschließen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00509-002-s680><decide.entschließen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00509-002-s681><decide.entschließen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00509-002-s681><decide.entschließen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00509-002-s682><decide.entschließen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00509-002-s682><decide.entschließen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00509-002-s683><decide.entschließen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00509-002-s683><decide.entschließen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00509-002-s665><decide.sich_entschließen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00509-002-s665><decide.sich_entschließen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00509-002-s666><decide.sich_entschließen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00509-002-s666><decide.sich_entschließen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00509-002-s667><decide.sich_entschließen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00509-002-s667><decide.sich_entschließen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00509-002-s668><decide.sich_entschließen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00509-002-s668><decide.sich_entschließen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00509-002-s669><decide.sich_entschließen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00509-002-s669><decide.sich_entschließen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00509-002-s670><decide.sich_entschließen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00509-002-s670><decide.sich_entschließen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00509-002-s671><decide.sich_entschließen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00509-002-s671><decide.sich_entschließen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00509-002-s672><decide.sich_entschließen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00509-002-s672><decide.sich_entschließen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00509-002-s673><decide.sich_entschließen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00509-002-s673><decide.sich_entschließen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00509-002-s674><decide.sich_entschließen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00509-002-s674><decide.sich_entschließen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00509-002-s675><decide.sich_entschließen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00509-002-s675><decide.sich_entschließen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00509-002-s676><decide.sich_entschließen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00509-002-s676><decide.sich_entschließen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00509-002-s677><decide.sich_entschließen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00509-002-s677><decide.sich_entschließen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00509-002-s678><decide.sich_entschließen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00509-002-s678><decide.sich_entschließen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00509-002-s679><decide.sich_entschließen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00509-002-s679><decide.sich_entschließen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00509-002-s680><decide.sich_entschließen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00509-002-s680><decide.sich_entschließen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00509-002-s681><decide.sich_entschließen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00509-002-s681><decide.sich_entschließen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00509-002-s682><decide.sich_entschließen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00509-002-s682><decide.sich_entschließen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00509-002-s683><decide.sich_entschließen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00509-002-s683><decide.sich_entschließen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00509-002-s475><decide.treffen><en> But its finally up to the Presentation Manager and the Event Team to decide about if this option can be applied to your presentation.
<G-vec00509-002-s475><decide.treffen><de> Die Entscheidung darüber, ob dies auf Ihren Vortrag angewendet werden kann, treffen schlussendlich der Referentenbetreuer und das Event Team.
<G-vec00509-002-s476><decide.treffen><en> For example, when three tote companies are available and two of the three share an attribute that make them more desirable than the remaining tote, an additional factor may be used to decide between these two desirable totes.
<G-vec00509-002-s476><decide.treffen><de> Wenn beispielsweise drei Toto-Gesellschaften zur Auswahl stehen und zwei von den drei aufgrund irgendeines Attributs attraktiver erscheinen als der restliche Toto, kann ein zusätzlicher Faktor herangezogen werden, um eine Entscheidung zwischen diesen beiden attraktiveren Totos zu treffen.
<G-vec00509-002-s477><decide.treffen><en> This solution allows our clients to observe each stage of the project and decide about the final result of the renovation.
<G-vec00509-002-s477><decide.treffen><de> Eine derartige Lösung ermöglicht es dem Kunden, in jede Phase des Projekts Einsicht zu nehmen sowie eine letztendliche Entscheidung hinsichtlich des Effekts der Renovierung zu treffen.
<G-vec00509-002-s478><decide.treffen><en> If your case turns out to be untypical, you will be able to determine the cost of your treatment in advance and decide whether you wish to proceed with it.
<G-vec00509-002-s478><decide.treffen><de> Soll sich Ihre Situation aus irgendwelchem Grund als ungewöhnlich erweisen, können Sie dann den Preis der Behandlung im voraus bestimmen und die entsprechende Entscheidung davon treffen.
<G-vec00509-002-s479><decide.treffen><en> NATO would have had to decide on a ground campaign or else suspend the bombing and in a ground war it would not have been easy for NATO to overcome the growing political obstacles nor would the war ever have ended.
<G-vec00509-002-s479><decide.treffen><de> Die NATO hätte die Entscheidung treffen müssen, auf dem Boden zu kämpfen - und mit einem Bodenkrieg wäre es für die NATO nicht leicht gewesen, die zunehmenden politischen Hindernisse zu überwinden, und der Krieg wäre niemals zu einem Ende gekommen -, oder die Bombardierungen zu beenden.
<G-vec00509-002-s480><decide.treffen><en> The competent investigative judge could not be reached; at 4:42 pm his deputy said on the telephone that without knowing the investigative file he could not decide upon the requested search warrant.
<G-vec00509-002-s480><decide.treffen><de> Der zuständige Ermittlungsrichter konnte nicht erreicht werden; sein Vertreter erklärte um 16:42 Uhr telefonisch, er könne ohne Vorlage der Ermittlungsakte keine Entscheidung über die beantragte Durchsuchungsanordnung treffen.
<G-vec00509-002-s481><decide.treffen><en> The Commission shall examine the opinion of the Authority without delay and decide in accordance with the procedure referred to in Article 22(2).
<G-vec00509-002-s481><decide.treffen><de> Die Kommission kann nach dem in Artikel 28 Absatz 2 genannten Beratungsverfahren eine Entscheidung treffen, gegebenenfalls nach Einholung einer Stellungnahme der Behörde.
<G-vec00509-002-s482><decide.treffen><en> In order to decide for the most suitable machines for the required application, you should use the consulting services of an independent planner.
<G-vec00509-002-s482><decide.treffen><de> Um eine Entscheidung zu treffen, wer die passendsten Maschinen für den gewünschten Einsatzfall hat, sollte die unabhängige Hilfe eines Planers in Anspruch nehmen.
<G-vec00509-002-s483><decide.treffen><en> At this point you may decide that it’s best not to continue this relationship any further.
<G-vec00509-002-s483><decide.treffen><de> An diesem Punkt wirst du vielleicht die Entscheidung treffen, dass es besser ist, diese Beziehung nicht weiter fortzusetzen.
<G-vec00509-002-s484><decide.treffen><en> The inhabitants' enthusiasm and positive responds encouraged the Local Government and the organisers to decide to organise a summer festival annually.
<G-vec00509-002-s484><decide.treffen><de> Die positive Einstellung und die Rückmeldungen der Einwohner bewog die Organisatoren die Entscheidung zu treffen, dass ab 1996 die Programme des Jászberényer Sommers (JÁSZBERÉNYI NYÁR) jährlich veranstaltet werden.
<G-vec00509-002-s485><decide.treffen><en> In November 2015, the potential Democratic presidential candidate presented a bill at the United States Senate, S. 2237: Ending Federal Marijuana Prohibition Act of 2015 which aims to restrict the application of federal laws to the distribution and consumption of cannabis, remove prison sentences for its possession and cultivation, and allow states to decide for themselves and set their own laws regarding recreational use, without clashing with the legal restrictions of the federal government.
<G-vec00509-002-s485><decide.treffen><de> Der Kandidat der demokratischen Vorwahlen hat im November 2015 einen Gesetzentwurf in den Senat der Vereinigten Staaten eingebracht, S. 2237: Ending Federal Marijuana Prohibition Act of 2015, der die Anwendung der Bundesgesetze auf den Vertrieb und Konsum von Cannabis beschränken und die Strafen wegen Besitz und Anbau abschaffen und so den Bundesstaaten die Möglichkeit einräumen will, eine eigene Entscheidung zu treffen und eigene Gesetze bezüglich der Verwendung als Freizeitdroge zu erlassen, ohne auf gesetzliche Hürden seitens der Bundesregierung zu stoßen.
<G-vec00509-002-s486><decide.treffen><en> A and I could not decide on what pheno was better to backcross to the G13 father, the Cannalope B or E. And after plenty of testing we still could not decide which one was better.
<G-vec00509-002-s486><decide.treffen><de> Wir konnten uns nicht entscheiden welcher Pheno besser für eine Rückkreuzung mit dem G13-Vater war, die Cannalope B oder E... Selbst nach einer Reihe an Prüfungen konnten wir keine Entscheidung treffen.
<G-vec00509-002-s487><decide.treffen><en> This is also the time when you decide to double, take insurance, or break-up a pair.
<G-vec00509-002-s487><decide.treffen><de> Dies ist auch die Zeit, wenn Sie eine Entscheidung treffen zu Verdoppeln, eine Versicherung oder ein Teil eines Paares.
<G-vec00509-002-s488><decide.treffen><en> The appropriate nursing staff can accept the alarm by single touch and decide about next steps.
<G-vec00509-002-s488><decide.treffen><de> Der entsprechende Pflegemitarbeiter kann den Alarm annehmen und eine Entscheidung über die nächsten Schritte treffen.
<G-vec00509-002-s489><decide.treffen><en> I wrested this power from him and made the spiritual unfree so long, until the possibility existed to choose between two lords - so long until the spiritual was again able, to decide itself.
<G-vec00509-002-s489><decide.treffen><de> Diese Macht entwand Ich ihm und machte das Geistige unfrei so lange, bis die Möglichkeit bestand, zwischen zwei Herren zu wählen - so lange, bis das Geistige wieder fähig war, selbst eine Entscheidung zu treffen.
<G-vec00509-002-s490><decide.treffen><en> These people will decide for themselves.
<G-vec00509-002-s490><decide.treffen><de> Diese Menschen werden ihre eigene Entscheidung treffen.
<G-vec00509-002-s491><decide.treffen><en> The cows can completely decide themselves when they are milked.
<G-vec00509-002-s491><decide.treffen><de> Die Kühe können eine vollständige eigene Entscheidung treffen wann sie gemolken werden.
<G-vec00509-002-s492><decide.treffen><en> This should fairly highlight your professional experience, as an employer will decide on a possible interview, based on the details provided in your CV.
<G-vec00509-002-s492><decide.treffen><de> Dieser muss Ihre berufliche Erfahrung deutlich und fair ausdeuten weil der Arbeitgeber eine Entscheidung über ein mögliches Vorstellungsgespräch nur laut der Information aus dem Lebenslauf treffen kann.
<G-vec00509-002-s493><decide.treffen><en> The Saints were told they had only fifteen minutes to decide what to do.
<G-vec00509-002-s493><decide.treffen><de> Sie sagten den Heiligen, sie hätten fünfzehn Minuten Zeit, eine Entscheidung zu treffen.
