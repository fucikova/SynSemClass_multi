<G-vec00254-002-s779><decide.(sich)_überlegen><en> We would not be the Insomnia if we did not go a little further: The fine line between harmless cuddles and deliberate touches is narrow and so there will be a second part of the party where everyone can decide whether he wants to participate or stay with the intentionless cuddling.
<G-vec00254-002-s779><decide.(sich)_überlegen><de> Wir wären ja nicht das Insomnia, wenn wir nicht auch ein wenig weiter gehen würden: Der Grat aus harmlosen Kuscheln zu absichtvollen Berührungen ist schmal und so wird es einen zweiten Teil der Party geben, bei dem sich jeder überlegen kann ob er mitmachen will oder es beim absichtslosen Kuscheln belässt.
<G-vec00254-002-s780><decide.(sich)_überlegen><en> Our search engine will help you book a flight to Milwaukee - all you have to do, is decide what to pack.
<G-vec00254-002-s780><decide.(sich)_überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Milwaukee-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s781><decide.(sich)_überlegen><en> After deciding whether you wish to operate your child-care business at home or in an independent facility, the next step is to decide what type of child care you would like to offer.
<G-vec00254-002-s781><decide.(sich)_überlegen><de> Nachdem du dich entschlossen hast, ob du deine Kinderbetreuungseinrichtung bei dir zuhause oder in externen Räumlichkeiten eröffnen willst, ist der nächste Schritt, zu überlegen, welche Art Kinderbetreuungseinrichtung du gerne anbieten würdest.
<G-vec00254-002-s782><decide.(sich)_überlegen><en> As far as the opening of the TLD catalogue is concerned, trademark owners must decide whether they wish to have their trademark(s) registered as a TLD, and they should also think about how to defend their trademarks against new TLDs that infringe upon their trademark(s).
<G-vec00254-002-s782><decide.(sich)_überlegen><de> Markeninhaber müssen sich im Zusammenhang mit der Öffnung des TLD-Katalogs zum einen überlegen, ob sie ihre Marke(n) als TLD registrieren wollen und zum anderen darüber nachdenken, wie sie ihre Marken gegen neue TLDs verteidigen, welche ihre Marke(n) verletzen.
<G-vec00254-002-s783><decide.(sich)_überlegen><en> And if the price is already in the internet, then I can decide whether I am going to play along or not.
<G-vec00254-002-s783><decide.(sich)_überlegen><de> Und wenn es den Preis im Internet bereits gibt, dann kann ich mir überlegen, ob ich da mitspiele oder nicht.
<G-vec00254-002-s784><decide.(sich)_überlegen><en> The children repeat the different steps of working with the Clip Art program and decide which picture each child will paint so that all important procedures are covered and documented.
<G-vec00254-002-s784><decide.(sich)_überlegen><de> Die Kinder wiederholen die verschiedenen Schritte zur Arbeit mit dem Clip Art-Programm und überlegen, welche Bilder jedes einzelne Kind malt, so dass alle wichtigen Vorgänge dokumentiert werden.
<G-vec00254-002-s785><decide.(sich)_überlegen><en> Watch the dancing waves from your four-poster sunbed next to a private plunge pool, as you decide what to have for dinner.
<G-vec00254-002-s785><decide.(sich)_überlegen><de> Während Ihr vom Himmelbett direkt neben Eurem eigenen Pool den Wellen zuseht, könnt Ihr Euch schon einmal überlegen, was Ihr zu Abend essen möchtet.
<G-vec00254-002-s786><decide.(sich)_überlegen><en> When opting for WordPress hosting, you need to decide what exactly your website should offer its users.
<G-vec00254-002-s786><decide.(sich)_überlegen><de> Wenn Sie sich für Managed-WordPress-Hosting entscheiden, müssen Sie sich nur noch überlegen, was Ihre Website den Besuchern bieten soll.
<G-vec00254-002-s787><decide.(sich)_überlegen><en> Instead of giving the answer, the teacher split the class into two groups, male and female, and asked them to decide for themselves whether computer' should be a masculine or a feminine noun.
<G-vec00254-002-s787><decide.(sich)_überlegen><de> Anstatt einer Antwort, teilte der Lehrer die Klasse in zwei Gruppen ein, Frauen und Männer, und beauftragte sie, selber zu überlegen, ob "Computer" männlich oder weiblich sei.
<G-vec00254-002-s788><decide.(sich)_überlegen><en> If you decide to install your own Wi-Fi access points, approval from LRZ is required.
<G-vec00254-002-s788><decide.(sich)_überlegen><de> Falls Sie überlegen, eigene WLAN-Access Points zu installieren, ist eine Genehmigung durch das LRZ notwendig.
<G-vec00254-002-s789><decide.(sich)_überlegen><en> You can then see the result on-screen and decide whether you want to continue with or cancel the print job.
<G-vec00254-002-s789><decide.(sich)_überlegen><de> Sie können sich das Ergebnis anschließend am Bildschirm anschauen und überlegen, ob Sie den Druckauftrag fortsetzen oder stornieren wollen.
<G-vec00254-002-s790><decide.(sich)_überlegen><en> Our search engine will help you book a flight to Victoria Inner Harbour - all you have to do, is decide what to pack.
<G-vec00254-002-s790><decide.(sich)_überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Victoria Inner Harbour-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s791><decide.(sich)_überlegen><en> Because of this, you can decide if you want to cover the inside of the zine with artwork as well.
<G-vec00254-002-s791><decide.(sich)_überlegen><de> Daher kannst du überlegen, ob du das Innere des Buches auch illustrieren willst.
<G-vec00254-002-s792><decide.(sich)_überlegen><en> The second step in planning your wedding is to decide when the event should take place.
<G-vec00254-002-s792><decide.(sich)_überlegen><de> Der zweite Schritt ist zu überlegen, wann die Hochzeit statt finden soll.
<G-vec00254-002-s793><decide.(sich)_überlegen><en> First, you need to decide which data formats and data types to implement.
<G-vec00254-002-s793><decide.(sich)_überlegen><de> Zunächst müssen Sie überlegen, welche Datenformate und Datentypen implementiert werden müssen.
<G-vec00254-002-s794><decide.(sich)_überlegen><en> There is now the occasion to decide about how much of customization should really be retained.
<G-vec00254-002-s794><decide.(sich)_überlegen><de> Es ist auch der Moment, zu überlegen, wieviel Anpassung (Customization) überhaupt beibehalten werden soll.
<G-vec00254-002-s795><decide.(sich)_überlegen><en> I’d rather drink a cup of tea with her first, gab with her and then at the end decide whether or not to kiss her hand.
<G-vec00254-002-s795><decide.(sich)_überlegen><de> Eher würde ich zuerst einen Tee mit ihr trinken, mit ihr tratschen und dann zum Abschied überlegen, ob ich ihr vielleicht die Hand küsse.
<G-vec00254-002-s796><decide.(sich)_überlegen><en> You will have to collectively discuss and decide how to answer each question.
<G-vec00254-002-s796><decide.(sich)_überlegen><de> Ihr müsst gemeinsam überlegen, wie ihr jede dieser Fragen beantworten wollt.
<G-vec00254-002-s797><decide.(sich)_überlegen><en> Whether you have already introduced some happy hens to your garden or you're trying to decide if keeping chickens is for you, you're in the right place.
<G-vec00254-002-s797><decide.(sich)_überlegen><de> Egal ob Sie schon in Ihrem Garten ein paar glückliche Hühner haben oder Sie noch überlegen, ob die Hühnerhaltung etwas für Sie ist, so sind Sie hier am richtigen Platz.
<G-vec00254-002-s057><decide.beschließen><en> Article 39 The Security Council shall determine the existence of any threat to the peace, breach of the peace, or act of aggression and shall make recommendations, or decide what measures shall be taken in accordance with Articles 41 and 42, to maintain or restore international peace and security.
<G-vec00254-002-s057><decide.beschließen><de> Artikel 39 (Maßnahmen zur Wahrung des Weltfriedens) Der Sicherheitsrat stellt fest, ob eine Bedrohung oder ein Bruch des Friedens oder eine Angriffshandlung vorliegt; er gibt Empfehlungen ab oder beschließt, welche Maßnahmen auf Grund der Artikel 41 und 42 zu treffen sind, um den Weltfrieden und die internationale Sicherheit zu wahren oder wiederherzustellen.
<G-vec00254-002-s058><decide.beschließen><en> According to Article 97(2) EPC, if it is established that the applicant has approved the text in which the Examining Division intends to grant the patent, and if the fees for grant and printing have been paid within the set period, and if the renewal fees and any additional fees already due have been paid, the Examining Division shall decide to grant the European patent.
<G-vec00254-002-s058><decide.beschließen><de> Nach Artikel 97 (2) EPÜ beschließt die Prüfungsabteilung die Erteilung des europäischen Patents, sofern feststeht, daß der Anmelder mit der Fassung, in der die Prüfungsabteilung das Patent zu erteilen beabsichtigt, einverstanden ist, die Erteilungs- und die Druckkostengebühr innerhalb der vorgeschriebenen Frist entrichtet und die bereits fälligen Jahresgebühren und Zuschlagsgebühren gezahlt worden sind.
<G-vec00254-002-s059><decide.beschließen><en> Before you decide to treat yourselves and your guests with an experience they’ll never forget, make sure you get familiar with all the downsides of getting married abroad.
<G-vec00254-002-s059><decide.beschließen><de> Bevor ihr beschließt, euch und euren Gästen ein Erlebnis zu bescheren, das unvergesslich bleibt, vergewissert euch, ob ihr euch auch mit allen Nachteilen einer Hochzeit im Ausland vertraut gemacht habt.
<G-vec00254-002-s060><decide.beschließen><en> The board shall discuss and decide on rule changes and, at the request of the associations and national general meetings, matters relating to association football in its international relations.
<G-vec00254-002-s060><decide.beschließen><de> Das Gremium erörtert und beschließt Regeländerungen und auch auf Bitte der Verbände und nationalen Generalversammlungen Angelegenheiten, die den Verbandsfußball in seinen internationalen Beziehungen betreffen.
<G-vec00254-002-s061><decide.beschließen><en> That way, if you decide that you don't like the changes, you always have the original unaltered photo on-hand.
<G-vec00254-002-s061><decide.beschließen><de> Auf diese Weise hast du das ursprüngliche, unveränderte Foto immer zur Hand, falls du beschließt, dass dir die Änderungen nicht gefallen.
<G-vec00254-002-s062><decide.beschließen><en> The ECB shall decide whether or not to oppose the acquisition on the basis of its assessment of the proposed acquisition and the NCA’s draft decision.
<G-vec00254-002-s062><decide.beschließen><de> Die EZB beschließt, ob sie den Erwerb auf Grundlage ihrer Prüfung des geplanten Erwerbs und des Beschlussentwurfs der NCA ablehnt oder nicht ablehnt.
<G-vec00254-002-s063><decide.beschließen><en> Jürgen Fechter and Alexander Isola were newly elected to the Supervisory Board for the maximum period stipulated in the Articles of Association (i.e. until the end of the Annual General Meeting that will decide on the discharge for 2020).
<G-vec00254-002-s063><decide.beschließen><de> Jürgen Fechter und Dr. Alexander Isola wurden als neue Mitglieder des Aufsichtsrats für die satzungsmäßige Höchstdauer gewählt (das ist bis zum Ende jener Hauptversammlung, die über die Entlastung für das Geschäftsjahr 2020 beschließt).
<G-vec00254-002-s064><decide.beschließen><en> The Executive Board shall decide on the repayment of this loan.
<G-vec00254-002-s064><decide.beschließen><de> Der Vorstand beschließt über die Rückzahlung.
<G-vec00254-002-s065><decide.beschließen><en> The Council shall decide by qualified majority.
<G-vec00254-002-s065><decide.beschließen><de> Der Rat beschließt mit qualifizierter Mehrheit.
<G-vec00254-002-s066><decide.beschließen><en> The Board of Directors shall decide on the signatory powers of the members of the Executive Committee.
<G-vec00254-002-s066><decide.beschließen><de> Der Verwaltungsrat beschließt über die Zeichnungsbefugnisse der Mitglieder des Executive Committee.
<G-vec00254-002-s067><decide.beschließen><en> The Council shall decide on the organisation of the General Secretariat by a simple majority.
<G-vec00254-002-s067><decide.beschließen><de> Der Rat beschließt mit einfacher Mehrheit über die Organisation des Generalsekretariats.
<G-vec00254-002-s068><decide.beschließen><en> On conclusion of the period, the Commission shall decide either to terminate the suspension after informing the Committee referred to in Article 27 or to extend the period of suspension in accordance with the procedure referred to in paragraph 3 of this Article.
<G-vec00254-002-s068><decide.beschließen><de> Spätestens nach Ablauf dieses Zeitraums beschließt die Kommission nach dem Dringlichkeitsverfahren des Artikels 39 Absatz 4 entweder, die vorübergehende Rücknahme zu beenden, oder die vorübergehende Rücknahme zu verlängern.
<G-vec00254-002-s069><decide.beschließen><en> MrJake shared his bewilderment with other Reddit users who suggested he spend the coins as soon as possible in case Respawn decide to do something about this.
<G-vec00254-002-s069><decide.beschließen><de> MrJake teilte seine Verwirrung mit anderen Reddit-Benutzern, die vorschlugen, die Münzen so schnell wie möglich auszugeben, falls Respawn beschließt, etwas dagegen zu unternehmen.
<G-vec00254-002-s070><decide.beschließen><en> On the seventh and final station raises the Granattor, a container filled with tons of garnet through the indication of the largest garnet deposits in Europe inside the Alpe Millstätter are, with the hikers a look into the future together and decide the way.
<G-vec00254-002-s070><decide.beschließen><de> An der siebten und letzten Station wirft das Granattor, ein mit Tonnen von Granatstein gefüllter Durchgang der Hinweis auf das größte Granatvorkommen Europas im Inneren der Millstätter Alpe gibt, mit den Wanderern einen Blick in die gemeinsame Zukunft und beschließt den Weg.
<G-vec00254-002-s071><decide.beschließen><en> The Commission shall decide within three months following the notification provided for in point (a) of paragraph 4.
<G-vec00254-002-s071><decide.beschließen><de> (5) Die Kommission beschließt innerhalb von drei Monaten nach der Mitteilung gemäß Absatz 4 Buchstabe a. Diese Frist beginnt am Tag nach dem Eingang der vollständigen Mitteilung.
<G-vec00254-002-s072><decide.beschließen><en> ECB decision on acquisition The ECB shall decide whether or not to oppose the acquisition on the basis of its assessment of the proposed acquisition and the NCA’s draft decision.
<G-vec00254-002-s072><decide.beschließen><de> Beschluss der EZB über den Erwerb Die EZB beschließt, ob sie den Erwerb auf Grundlage ihrer Prüfung des geplanten Erwerbs und des Beschlussentwurfs der NCA ablehnt oder nicht ablehnt.
<G-vec00254-002-s073><decide.beschließen><en> It shall decide the budget for receipts and expenditures within the limit of existing appropriations, and shall audit and approve the accounts.
<G-vec00254-002-s073><decide.beschließen><de> Sie beschließt den Haushalt der Einnahmen und Ausgaben im Rahmen der bestehenden Mittel und kontrolliert und billigt die Rechnungsabschlüsse.
<G-vec00254-002-s074><decide.beschließen><en> He is brought before the council and the council decide to put him to death.
<G-vec00254-002-s074><decide.beschließen><de> Er wird vor den Hohenrat geführt, und der Hoherat beschließt, ihn zu töten.
<G-vec00254-002-s075><decide.beschließen><en> According to our trade union, guests who, following government announcements, decide to leave the campsite before the end of their stay, or who decide to cancel a booked stay, do so on their own initiative.
<G-vec00254-002-s075><decide.beschließen><de> Unserem Berufsverband zufolge macht ein Kunde, der nach den Ansagen der Regierung beschließt, den Campingplatz vor Beendigung seines Aufenthalts zu verlassen, oder einen gebuchten Aufenthalt zu stornieren, dieses aus eigener Initiative.
<G-vec00254-002-s076><decide.bestimmen><en> It is possible to decide on the size and the quantity of the stones.
<G-vec00254-002-s076><decide.bestimmen><de> Es ist möglich, die Größe und die Anzahl der zu bearbeitenden Steine zu bestimmen.
<G-vec00254-002-s077><decide.bestimmen><en> ED/2015/10 Annual Improvements to IFRSs 2014–2016 Cycle contains no proposed effective dates for any of the proposed amendments. The intention is to decide on these after the exposure period.
<G-vec00254-002-s077><decide.bestimmen><de> Im Entwurf ED/2019/2 Jährliche Verbesserungen an den IFRS 2018-2020 sind keine vorgeschlagenen Zeitpunkte des Inkrafttretens für die vorgeschlagenen Änderungen enthalten, weil beabsichtigt ist, diese nach der Kommentierungsphase zu bestimmen.
<G-vec00254-002-s078><decide.bestimmen><en> This means, you can decide yourself what happens next. About the delivery status Redirection options
<G-vec00254-002-s078><decide.bestimmen><de> Das heißt, Sie können selbst bestimmen, was jetzt mit Ihrem Paket passieren soll.
<G-vec00254-002-s079><decide.bestimmen><en> You decide what information goes on your public profile.
<G-vec00254-002-s079><decide.bestimmen><de> Sie bestimmen, welche Informationen in Ihrem öffentlichen Profil angezeigt werden.
<G-vec00254-002-s080><decide.bestimmen><en> You can decide which members can manage shared channels on your Enterprise Grid organization.
<G-vec00254-002-s080><decide.bestimmen><de> Du kannst bestimmen, welche Mitglieder Geteilte Channels in deiner Enterprise Grid-Organisation verwalten können.
<G-vec00254-002-s081><decide.bestimmen><en> Naturally, you decide on the length yourself depending on the number of photos.
<G-vec00254-002-s081><decide.bestimmen><de> Die Länge bestimmen sie je nach Anzahl der Fotos natürlich selbst.
<G-vec00254-002-s082><decide.bestimmen><en> That will decide on the final texture and refinement of the praline or truffle and that is what we foster at Carline, for decades already…
<G-vec00254-002-s082><decide.bestimmen><de> Denn diese bestimmen die letztendliche Textur und den raffinierten Geschmack - und das hat bei Carline oberste Priorität, schon seit Jahrzehnten...
<G-vec00254-002-s083><decide.bestimmen><en> Our clients know each and every one of us; they themselves decide who will work on their case.
<G-vec00254-002-s083><decide.bestimmen><de> Unsere Mandanten kennen uns – jeden einzeln – und sie bestimmen, wer ihren Fall bearbeitet.
<G-vec00254-002-s084><decide.bestimmen><en> You can decide yourself which products should be grouped together.
<G-vec00254-002-s084><decide.bestimmen><de> Sie können selbst bestimmen, welche Produkte in welchen Gruppen zusammengefasst werden.
<G-vec00254-002-s085><decide.bestimmen><en> But in fact the Commonwealth of Puerto Rico remains a colony of the U.S., as the real power to decide about its status lies with Congress.
<G-vec00254-002-s085><decide.bestimmen><de> Da jedoch der Kongress in Washington über die Zukunft des Commonwealth of Puerto Rico zu bestimmen hat, bleibt die Insel eine Kolonie der USA.
<G-vec00254-002-s086><decide.bestimmen><en> The neurotransmitters diffuse across the synaptic cleft to bind receptors which, to large extent, decide on final effect.
<G-vec00254-002-s086><decide.bestimmen><de> Die Neurotransmitter wandern durch den synaptischen Spalt und binden dann an Rezeptoren, die über den endgültigen Effekt bestimmen.
<G-vec00254-002-s087><decide.bestimmen><en> The parties will then have to decide on the time and location of the mediation.
<G-vec00254-002-s087><decide.bestimmen><de> Das Ergebnis und die Beendigung des Verfahrens bestimmen ausschließlich die Parteien.
<G-vec00254-002-s088><decide.bestimmen><en> The snooze intervals can be set so that you decide after how many minutes the alarm should sound again.
<G-vec00254-002-s088><decide.bestimmen><de> Die Snooze-Dauer lässt sich einstellen, so dass Sie bestimmen, nach wie viel Minuten der Alarm erneut ertönt.
<G-vec00254-002-s089><decide.bestimmen><en> By previewing the games, you can easily decide whichever game you want to play.
<G-vec00254-002-s089><decide.bestimmen><de> Durch die Vorschau der Spiele, können Sie bequem bestimmen je nachdem, welcher Online-Spiel Sie spielen möchten.
<G-vec00254-002-s090><decide.bestimmen><en> You can decide if your personal stripper will do her girlstrip in a favorite outfit.
<G-vec00254-002-s090><decide.bestimmen><de> Sie können bestimmen, ob Ihre persönliche Stripperin ihren Girlstrip in einem bevorzugten Outfit durchführt.
<G-vec00254-002-s091><decide.bestimmen><en> You decide whether to start receiving your annuity straightaway or at a later date.
<G-vec00254-002-s091><decide.bestimmen><de> Sie bestimmen, ob die Rentenzahlung sofort oder zu einem späteren Zeitpunkt startet.
<G-vec00254-002-s092><decide.bestimmen><en> The Guild Leaders can decide how much will be the Guild tax, meaning - they can determine what % of the earned gold will automatically go the Guild Treasury.
<G-vec00254-002-s092><decide.bestimmen><de> Die Leiter der Gilde haben das Recht die Steuer der Gilde zu bestimmen, d.h. sie bestimmen was für einen Prozent des erworbenen Goldes von jedem Spieler automatisch in die Kasse geht.
<G-vec00254-002-s093><decide.bestimmen><en> never have arrived at the conception of a free almighty God and of what may be called an “arbitrary Providence,“ a Providence, that is, which can decree something in one way, and then in answer to prayers or from other motives decide in a contrary direction. * We do not find that, outside of Judaism, man ever came to the conception of a quite intimate and continual personal relation between God and mankind — to the conception of a God who would almost seem to be there only for the sake of man.
<G-vec00254-002-s093><decide.bestimmen><de> Aus eigenen Kräften wären wir gewiss nie zu der Vorstellung eines freien allmächtigen Gottes und einer sozusagen „willkürlichen Vorsehung“ gekommen, einer Vorsehung nämlich, die eine Sache so bestimmen kann, und dann, durch Gebete oder andere Beweggründe veranlasst, wieder anders.¹) Wir sehen nicht, dass man außerhalb des Judentums auf den Gedanken einer ganz intimen und beständigen persönlichen Beziehung zwischen Gott und Mensch gekommen sei, auf den Gedanken eines Gottes, der, wenn ich so sagen darf, lediglich der Menschen wegen da zu sein scheint.
<G-vec00254-002-s094><decide.bestimmen><en> ISOE’s water researchers suggest that from now on, the population development and the related economic progression will again increasingly decide about the expected water demand.
<G-vec00254-002-s094><decide.bestimmen><de> Die Wasserforscher des ISOE gehen davon aus, dass zukünftig vor allem die Bevölkerungsentwicklung und die damit auch verbundene wirtschaftliche Entwicklung den Wasserbedarf bestimmen werden.
<G-vec00254-002-s247><decide.entscheiden><en> Once a year, the executive board and the scientific management of Wings for Life sit down together to decide which new research projects should be funded.
<G-vec00254-002-s247><decide.entscheiden><de> Einmal im Jahr entscheiden der Vorstand und die wissenschaftliche Leitung von Wings for Life darüber, welche neuen Forschungsprojekte gefördert werden.
<G-vec00254-002-s248><decide.entscheiden><en> All cantons decide on how education should look like, as long as it meets certain requirements.
<G-vec00254-002-s248><decide.entscheiden><de> Alle Kantone entscheiden darüber, wie Erziehung aussehen sollte, solange sie bestimmte Anforderungen erfüllt.
<G-vec00254-002-s249><decide.entscheiden><en> You as the administrator decide what your supplier can and cannot see.
<G-vec00254-002-s249><decide.entscheiden><de> Sie als Administrator entscheiden darüber, was Ihr Lieferant einsehen kann und was nicht.
<G-vec00254-002-s250><decide.entscheiden><en> The selection of different types of peppers and the amount of fat-containing pepper seeds decide whether sweet or hot paprika is produced.
<G-vec00254-002-s250><decide.entscheiden><de> Die Auswahl der verschiedenen Paprikasorten und die Menge der zugegebenen, fetthaltigen Paprikasamen entscheiden darüber, ob edelsüßes oder scharfes Paprikapulver entsteht.
<G-vec00254-002-s251><decide.entscheiden><en> We shall not be obliged to take part in dispute resolution procedures before a consumer conciliation body and shall decide on these on a case-by-case basis.
<G-vec00254-002-s251><decide.entscheiden><de> Wir sind zur Teilnahme an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle nicht verpflichtet und entscheiden darüber im Einzelfall.
<G-vec00254-002-s252><decide.entscheiden><en> You alone decide whether or not you wish to disclose this data to us, for example in the context of a registration, survey or similar.
<G-vec00254-002-s252><decide.entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung, Umfrage o. ä., diese Daten bekannt geben wollen oder nicht.
<G-vec00254-002-s253><decide.entscheiden><en> Sandra and I decide such things together even though, as the manager, Sandra naturally has her eye on the furnishings every day.
<G-vec00254-002-s253><decide.entscheiden><de> Sandra und ich entscheiden gemeinsam darüber, auch wenn Sandra als Geschäftsführerin die Einrichtung natürlich täglich im Blick hat.
<G-vec00254-002-s254><decide.entscheiden><en> Database users decide what data are released.
<G-vec00254-002-s254><decide.entscheiden><de> Die Datenbankbenutzer entscheiden darüber, welche Daten freigegeben werden.
<G-vec00254-002-s255><decide.entscheiden><en> Therefore, a user or administrator must decide whether to trust that CA and, by extension, the policies and procedures that the CA has in place for confirming the identity of the entities that are issued certificates by that CA.
<G-vec00254-002-s255><decide.entscheiden><de> Deshalb muss ein Benutzer oder Administrator entscheiden, ob dieser Zertifizierungsstelle und darüber hinaus den Richtlinien und Verfahren dieser Zertifizierungsstelle zur Bestätigung der Identität der Entitäten, denen von dieser Zertifizierungsstelle Zertifikate ausgestellt werden, vertraut werden kann.
<G-vec00254-002-s256><decide.entscheiden><en> You are free to decide which information you provide to the Bertelsmann Stiftung.
<G-vec00254-002-s256><decide.entscheiden><de> Wahlmöglichkeit Sie entscheiden frei darüber, welche Informationen Sie der Bertelsmann Stiftung zur Verfügung stellen.
<G-vec00254-002-s257><decide.entscheiden><en> You alone decide whether you want to or do not want to disclose this data to us, for example in the course of a registration process.
<G-vec00254-002-s257><decide.entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung, diese Daten bekannt geben wollen oder nicht.
<G-vec00254-002-s258><decide.entscheiden><en> By combining them you can easily decide how to bake your dish and be sure about the final result.
<G-vec00254-002-s258><decide.entscheiden><de> Die Betriebsarten können problemlos miteinander kombiniert werden; wir entscheiden darüber, wie unsere Speise zuzubereiten ist, wobei wir uns des Endergebnisses immer sicher sein können.
<G-vec00254-002-s259><decide.entscheiden><en> In our houses and gardens, in our facilities for water, energy and food, in our love relationships and partnerships and in our social and political systems, we decide which information is sent to the world.
<G-vec00254-002-s259><decide.entscheiden><de> In unseren Häusern und Gärten, unseren Anlagen für Wasser, Energie und Nahrung, unseren Liebesbeziehungen und Partnerschaften, unseren sozialen und politischen Systemen entscheiden wir darüber, welche Information in die Welt geht.
<G-vec00254-002-s260><decide.entscheiden><en> You may freely decide what information to give us.
<G-vec00254-002-s260><decide.entscheiden><de> Sie entscheiden frei darüber, welche Informationen Sie zur Verfügung stellen.
<G-vec00254-002-s261><decide.entscheiden><en> You alone decide if you wish to give us this information or not, for example when registering online or during an online application.
<G-vec00254-002-s261><decide.entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung/ Online-Bewerbung, diese Daten bekannt geben wollen oder nicht.
<G-vec00254-002-s262><decide.entscheiden><en> The market doesn't take into account the costs but by selling directly from the pier the fishermen can decide their own prices.
<G-vec00254-002-s262><decide.entscheiden><de> Der Markt berücksichtigt die Kosten nicht - beim Direktverkauf jedoch entscheiden die Fischer selbst darüber.
<G-vec00254-002-s263><decide.entscheiden><en> Your listeners and viewers will decide on it.
<G-vec00254-002-s263><decide.entscheiden><de> Ihre Zuhörer und Zuschauer entscheiden darüber.
<G-vec00254-002-s264><decide.entscheiden><en> Function, operating comfort, graphical design, speed and availability decide on how internet applications are perceived.
<G-vec00254-002-s264><decide.entscheiden><de> Funktionalität, Bedienungskomfort, grafische Ausgestaltung, Geschwindigkeit und Verfügbarkeit entscheiden darüber, wie Internetanwendungen erlebt werden.
<G-vec00254-002-s265><decide.entscheiden><en> This is essential indeed, because your ability to draw these tonalities, decide how 3-dimensional and realistic your ball will look in the end.
<G-vec00254-002-s265><decide.entscheiden><de> Denn eure Fähigkeiten diese Tonalitäten zeichnen zu können, entscheiden darüber wie 3-dimensional und realistisch eure Kugel fertig aussieht.
<G-vec00254-002-s665><decide.entschleißen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00254-002-s665><decide.entschleißen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00254-002-s666><decide.entschleißen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00254-002-s666><decide.entschleißen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00254-002-s667><decide.entschleißen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00254-002-s667><decide.entschleißen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00254-002-s668><decide.entschleißen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00254-002-s668><decide.entschleißen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00254-002-s669><decide.entschleißen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00254-002-s669><decide.entschleißen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00254-002-s670><decide.entschleißen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00254-002-s670><decide.entschleißen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00254-002-s671><decide.entschleißen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00254-002-s671><decide.entschleißen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00254-002-s672><decide.entschleißen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00254-002-s672><decide.entschleißen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00254-002-s673><decide.entschleißen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00254-002-s673><decide.entschleißen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00254-002-s674><decide.entschleißen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00254-002-s674><decide.entschleißen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00254-002-s675><decide.entschleißen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00254-002-s675><decide.entschleißen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00254-002-s676><decide.entschleißen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00254-002-s676><decide.entschleißen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00254-002-s677><decide.entschleißen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00254-002-s677><decide.entschleißen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00254-002-s678><decide.entschleißen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00254-002-s678><decide.entschleißen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00254-002-s679><decide.entschleißen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00254-002-s679><decide.entschleißen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00254-002-s680><decide.entschleißen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00254-002-s680><decide.entschleißen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00254-002-s681><decide.entschleißen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00254-002-s681><decide.entschleißen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00254-002-s682><decide.entschleißen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00254-002-s682><decide.entschleißen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00254-002-s683><decide.entschleißen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00254-002-s683><decide.entschleißen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00254-002-s513><decide.festlegen><en> Upgrading Your System Once you have chosen to upgrade, you can also decide whether you want to customize your packages.
<G-vec00254-002-s513><decide.festlegen><de> Wenn Sie sich für das Upgraden entschieden haben, können Sie auch festlegen, ob Sie die zu installierenden Pakete individuell festlegen möchten.
<G-vec00254-002-s514><decide.festlegen><en> At the end you can also decide whether the content text shoulb be duplicated as well.
<G-vec00254-002-s514><decide.festlegen><de> Am unteren Ende können Sie außerdem festlegen, ob auch der Inhaltstext dupliziert werden soll.
<G-vec00254-002-s515><decide.festlegen><en> You can decide the price for your Study Material yourself.
<G-vec00254-002-s515><decide.festlegen><de> Sie selbst können den Preis für Ihre Studienunterlagen festlegen.
<G-vec00254-002-s516><decide.festlegen><en> When searching and filtering database objects, you can decide whether or not this should be case sensitive.
<G-vec00254-002-s516><decide.festlegen><de> Sie können beim Suchen und Filtern von Datenbankobjekten festlegen, ob dabei die Groß- und Kleinschreibung beachtet werden soll.
<G-vec00254-002-s517><decide.festlegen><en> Kubernetes enables the administration of containerised applications over their entire lifecycle and users are able to decide themselves how to run applications and how these should interact with each other.
<G-vec00254-002-s517><decide.festlegen><de> Kubernetes ermöglicht die vollständige Verwaltung des Lebenszyklus der containerisierten Anwendungen und die Nutzer können selbst festlegen wie Anwendungen ausgeführt werden sollen und miteinander interagieren.
<G-vec00254-002-s518><decide.festlegen><en> For example, you can decide that every night, your mobile phone should be under maintenance from 23H00 to 06H00 but that email alerts should however be maintained 24 hours a day.
<G-vec00254-002-s518><decide.festlegen><de> Sie können zum Beispiel festlegen, dass sich Ihr Mobiltelefon jede Nacht zwischen 23.00 und 6.00 Uhr im Wartungszustand befindet, dass jedoch E-Mail-Alarme rund um die Uhr weiterhin erfolgen.
<G-vec00254-002-s519><decide.festlegen><en> Dr. Schörner also noted that Statute 7.2 states that the committee is entitled to amend and change regulations (other than those in the statutes) and to decide when such changes come into force.
<G-vec00254-002-s519><decide.festlegen><de> Dr. Schöner bemerkte weiters, dass der Ausschuss laut Statuten 7.2. alle anderen UNICA Regeln und Vorschriften soweit erforderlich ändern und aktualisieren kann, und festlegen kann wann diese in Kraft treten.
<G-vec00254-002-s520><decide.festlegen><en> If choosing the LAN client, you only need to decide if the Sysap should receive an automatic IP-address or choose a static.
<G-vec00254-002-s520><decide.festlegen><de> Wenn Sie den LAN-Client auswählen, müssen Sie nur festlegen, ob der Sysap eine automatische IP-Adresse beziehen oder eine statische IP-Adresse erhalten soll.
<G-vec00254-002-s521><decide.festlegen><en> You can also decide on the output folder location of the recovered items.
<G-vec00254-002-s521><decide.festlegen><de> Sie können auch den Speicherort des Ausgabeordners für die wiederhergestellten Elemente festlegen.
<G-vec00254-002-s522><decide.festlegen><en> Now, for instance, users can create a group in which to discuss and decide where to go out together in the evening.
<G-vec00254-002-s522><decide.festlegen><de> Nun kann man beispielsweise in einer Gruppe diskutieren und festlegen, wohin es denn am Abend gemeinsam gehen soll.
<G-vec00254-002-s523><decide.festlegen><en> Afterwards you should decide at home whether you want to continue working with this therapist and then decide with her how to proceed.
<G-vec00254-002-s523><decide.festlegen><de> Danach sollten Sie in Ruhe zu Hause entscheiden, ob Sie mit dieser Therapeutin weiterarbeiten möchten und dann mit ihr das weitere Vorgehen festlegen.
<G-vec00254-002-s524><decide.festlegen><en> The companies, which did not need paid support until now, have to decide in a relatively short time whether they can or want to continue using Java free of charge or need commercial support.
<G-vec00254-002-s524><decide.festlegen><de> Die Unternehmen, die bis dato keinen kostenpflichtigen Support benötigten, müssen nun relativ zeitnah festlegen, ob sie Java weiterhin kostenfrei nutzen können oder wollen oder einen kommerziellen Support benötigen.
<G-vec00254-002-s525><decide.festlegen><en> You must decide which data formats you will provide in the data package.
<G-vec00254-002-s525><decide.festlegen><de> Sie müssen festlegen, welche Datenformate in Ihrem Datenpaket bereitgestellt werden.
<G-vec00254-002-s526><decide.festlegen><en> And therefore, recently a section has appeared in the main menu where a collage of the selected shape is generated in no time (you just need to load the materials, then select the thickness of the frames, and then decide on the resolution and additional parameters on which the final result depends), opens access to instructions that provide answers to frequently asked questions.
<G-vec00254-002-s526><decide.festlegen><de> Daher wurde kürzlich im Hauptmenü ein Abschnitt angezeigt, in dem in kürzester Zeit eine Collage der ausgewählten Form erstellt wird (Sie müssen nur die Materialien laden, dann die Dicke der Rahmen auswählen und dann die Auflösung und zusätzliche Parameter festlegen, von denen das Endergebnis abhängt) Zugriff auf Anweisungen, die Antworten auf häufig gestellte Fragen geben.
<G-vec00254-002-s527><decide.festlegen><en> This policy setting lets you decide whether employees can see the open Microsoft Edge button, which appears next to the New Tab button.
<G-vec00254-002-s527><decide.festlegen><de> Mit dieser Richtlinieneinstellung können Sie festlegen, ob Mitarbeitern die Schaltfläche zum Öffnen von Microsoft Edge angezeigt wird, die neben der Schaltfläche „Neue Registerkarte” erscheint.
<G-vec00254-002-s528><decide.festlegen><en> The campsite can decide for itself whether more than two adults may camp on them (where the CampingCard rate applies to the two adults) or whether the campers will be referred to pitches that are not allocated to CampingCard ACSI users and for which the regular rates will be charged.
<G-vec00254-002-s528><decide.festlegen><de> Der Campingplatz kann selbst festlegen, ob mehr als zwei Erwachsene campen dürfen (wobei dann für zwei Erwachsene der CampingCard-Tarif gilt), oder ob die Camper auf Plätze gewiesen werden, die nicht für CampingCard ACSI-Inhaber bestimmt sind und dafür die üblichen Preise verlangt werden.
<G-vec00254-002-s529><decide.festlegen><en> Configure the standard zoom level of the process portal: You can now decide for your process portal, whether by default a diagram should be displayed completely or in its original size.
<G-vec00254-002-s529><decide.festlegen><de> Standard-Zoomwert der Prozessportal-Anzeige einstellen: Sie können für Ihr Prozessportal nun festlegen, ob beim Anzeigen eines Diagramms dieses standardmäßig vollständig oder in Originalgröße zu sehen ist.
<G-vec00254-002-s530><decide.festlegen><en> Furthermore you have the opportunity to select a thumbnail that appears in the list of presentations and decide whether the presentation shall be "Private", or publicly "Readable" or "Writable".
<G-vec00254-002-s530><decide.festlegen><de> Zudem können Sie beim Erstellen einer neuen Präsentation ein Thumbnail für die Anzeige in der Liste auswählen und festlegen, ob ihre Präsentation "Privat" oder öffentlich "Lesbar" oder "Schreibbar" sein soll.
<G-vec00254-002-s531><decide.festlegen><en> SEDEX is not a policy-making body and will also not decide on or certify standards or policy.
<G-vec00254-002-s531><decide.festlegen><de> SEDEX ist keine strategische Instanz und wird auch keine Standards oder Richtlinien festlegen oder zertifizieren.
<G-vec00254-002-s646><decide.sich_entscheiden><en> In case you decide in favor of a camper trip you will most likely witness the same as we did.
<G-vec00254-002-s646><decide.sich_entscheiden><de> Wenn man sich für einen Campertrip entscheidet, wacht man hier in malerischer Natur auf.
<G-vec00254-002-s647><decide.sich_entscheiden><en> If you decide to grow a garden, you must be able to imagine the final result even before you set the first plant.
<G-vec00254-002-s647><decide.sich_entscheiden><de> Wenn man sich entscheidet, einen Garten anzubauen, muss man in der Lage sein, schon bevor man die erste Pflanze setzt, sich das Endergebnis vorstellen zu können.
<G-vec00254-002-s648><decide.sich_entscheiden><en> And those who decide to work there, like Florentine Degen, have to come to terms with death.
<G-vec00254-002-s648><decide.sich_entscheiden><de> Und wer sich entscheidet, dort zu arbeiten, wie Florentine Degen, muss sich mit dem Tod arrangieren.
<G-vec00254-002-s649><decide.sich_entscheiden><en> It does not matter which series of fittings you decide on - the accessories harmoniously round off the overall impression of the kitchen.
<G-vec00254-002-s649><decide.sich_entscheiden><de> Ganz gleich, für welche Armaturenserie man sich entscheidet, rundet das Zubehör das Gesamtbild der Küche stimmig ab.
<G-vec00254-002-s650><decide.sich_entscheiden><en> If you decide to quit your job, you should deposit your retirement savings in a vested benefits account at an insurance company or bank.
<G-vec00254-002-s650><decide.sich_entscheiden><de> Wer sich für eine Kündigung entscheidet, sollte das angesparte Altersguthaben auf einem Freizügigkeitskonto bei einer Versicherung oder Bank anlegen.
<G-vec00254-002-s651><decide.sich_entscheiden><en> If you decide to use PVR images in your application, you should make sure that these images are only used on those devices that support them.
<G-vec00254-002-s651><decide.sich_entscheiden><de> Wenn man sich für PVR-Grafiken entscheidet, muss zuvor sichergestellt werden, dass diese Grafiken nur auf jenen Mobilgeräten benutzt werden, die sie auch unterstützen.
<G-vec00254-002-s652><decide.sich_entscheiden><en> The check mark (which indicates that the customer wants to purchase the add-on) is already set and can be removed by the customer if they decide not to buy the add-on product.
<G-vec00254-002-s652><decide.sich_entscheiden><de> Der Auswahlhaken (der bestimmt, dass man das Addon zusätzlich kaufen möchte) ist dabei bereits gesetzt und kann vom Kunden entfernt werden, wenn sich gegen den Kauf des Addon-Produkts entscheidet.
<G-vec00254-002-s653><decide.sich_entscheiden><en> Whether remote maintenance, technical on–site service or training courses with practical relevance for users in the most modern equipped training rooms: those who decide in favour of a HEUFT system can rely on its long–term availability.
<G-vec00254-002-s653><decide.sich_entscheiden><de> Ob Fernwartung, technischer Vor–Ort–Service oder praxisnahe Anwendertrainings in modern ausgestatteten Schulungsräumen: Wer sich für ein HEUFT–System entscheidet, kann sich auf dessen langfristige Verfügbarkeit verlassen.
<G-vec00254-002-s654><decide.sich_entscheiden><en> If any of our friends / work colleagues decide to holiday in Spain next year, I shall have Tourism Golf In Malaga
<G-vec00254-002-s654><decide.sich_entscheiden><de> Falls einer unserer Freunde oder Kollegen sich für einen Urlaub in Spanien nächstes Jahr entscheidet, werde ich nicht zögern Sie zu empfehlen.
<G-vec00254-002-s655><decide.sich_entscheiden><en> But if you decide on drugs and alcohol, then your route is predestined.
<G-vec00254-002-s655><decide.sich_entscheiden><de> Aber wenn man sich nur für Drogen und Alkohol entscheidet, dann ist der Weg vorgeplant.
<G-vec00254-002-s656><decide.sich_entscheiden><en> This way of accommodation is a long-time classic… and with a reason: If you decide for accommodation in a host family you will also learn German after class – very individually and completely relaxed – by being a new member of the family… We also take care that you share your room only with a student who has a different native language – in order to make sure that you can really speak German all day long.
<G-vec00254-002-s656><decide.sich_entscheiden><de> Diese Wohnmöglichkeit ist seit langer Zeit ein Klassiker… und das hat vor allem einen Grund: Wer sich für die Unterkunft in einer Gastfamilie entscheidet, der lernt auch nach dem Unterricht noch Deutsch – ganz entspannt und sehr persönlich – als neues Mitglied der Familie… Und damit Sie auch wirklich nur Deutsch sprechen, achten wir darauf, dass Sie Ihr Zimmer mit einem Mitschüler anderer Muttersprache teilen.
<G-vec00254-002-s657><decide.sich_entscheiden><en> You should know what you're getting into when you decide on a vacation in this place, of course.
<G-vec00254-002-s657><decide.sich_entscheiden><de> Man sollte natürlich wissen, worauf man sich einlässt, wenn man sich für einen Urlaub an diesem Ort entscheidet.
<G-vec00254-002-s658><decide.sich_entscheiden><en> At some stage everyone comes to a point, where you have to decide if you are driven by something, or if you want to be the driving force behind others.
<G-vec00254-002-s658><decide.sich_entscheiden><de> Irgendwann kommt jeder an einen Punkt, an dem man sich entscheidet anzutreiben oder angetrieben zu werden.
<G-vec00254-002-s659><decide.sich_entscheiden><en> Remaining uncertain in this area is a suboptimal choice — it’s better to decide one way or the other and be wrong than it is to remain uncertain and do nothing.
<G-vec00254-002-s659><decide.sich_entscheiden><de> Sich mit der Unsicherheit zufrieden zugeben ist eine suboptimale Wahl – es ist besser, wenn man sich für die eine oder andere Option entscheidet und falsch liegt, als wenn man einfach verharrt und gar nichts macht.
<G-vec00254-002-s660><decide.sich_entscheiden><en> Those who decide to study Informatics should possess solid mathematical skills as mathematical contents make up a large proportion of the programme.
<G-vec00254-002-s660><decide.sich_entscheiden><de> Wer sich für ein Studium der Informatik entscheidet, sollte solide mathematische Kenntnisse mitbringen, da mathematische Inhalte einen hohen Anteil des Studiums ausmachen.
<G-vec00254-002-s661><decide.sich_entscheiden><en> The “occasional marketplace fan” prefers to roam undetected through the Internet shopping arcades, and likes to compare prices and quality before they decide.
<G-vec00254-002-s661><decide.sich_entscheiden><de> Der "gelegentliche Marktplatz-Fan" streift am liebsten unerkannt durch die Ladenpassagen im Netz und vergleicht gerne Preise und Produktqualität, bevor er sich entscheidet.
<G-vec00254-002-s662><decide.sich_entscheiden><en> Those who decide to live life as a witch end up in a “witch house.”
<G-vec00254-002-s662><decide.sich_entscheiden><de> Wer sich für das Leben als Hexe entscheidet, endet in einem «Hexenhaus».
<G-vec00254-002-s663><decide.sich_entscheiden><en> These are fragile moments that decide whether an agreement is reached and whether new orders come about.
<G-vec00254-002-s663><decide.sich_entscheiden><de> Es sind fragile Momente, in denen sich entscheidet, ob es zu einer Verständigung kommt, ob neue Ordnungen entstehen.
<G-vec00254-002-s664><decide.sich_entscheiden><en> If you decide to purchase Crea Shot you can be sure that the creatine will not be converted in to the unnecessary and ineffective creatinine. It will also not place a burden on the own organism.
<G-vec00254-002-s664><decide.sich_entscheiden><de> Wer sich für das Kaufen von Crea Shot entscheidet, kann sich somit sicher sein, dass das Creatin nicht in das überflüssige und wirkungslose Creatinin umgewandelt wird und damit auch nicht den eigenen Organismus belastet.
<G-vec00254-002-s665><decide.sich_entschleißen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00254-002-s665><decide.sich_entschleißen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00254-002-s666><decide.sich_entschleißen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00254-002-s666><decide.sich_entschleißen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00254-002-s667><decide.sich_entschleißen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00254-002-s667><decide.sich_entschleißen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00254-002-s668><decide.sich_entschleißen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00254-002-s668><decide.sich_entschleißen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00254-002-s669><decide.sich_entschleißen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00254-002-s669><decide.sich_entschleißen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00254-002-s670><decide.sich_entschleißen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00254-002-s670><decide.sich_entschleißen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00254-002-s671><decide.sich_entschleißen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00254-002-s671><decide.sich_entschleißen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00254-002-s672><decide.sich_entschleißen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00254-002-s672><decide.sich_entschleißen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00254-002-s673><decide.sich_entschleißen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00254-002-s673><decide.sich_entschleißen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00254-002-s674><decide.sich_entschleißen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00254-002-s674><decide.sich_entschleißen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00254-002-s675><decide.sich_entschleißen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00254-002-s675><decide.sich_entschleißen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00254-002-s676><decide.sich_entschleißen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00254-002-s676><decide.sich_entschleißen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00254-002-s677><decide.sich_entschleißen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00254-002-s677><decide.sich_entschleißen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00254-002-s678><decide.sich_entschleißen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00254-002-s678><decide.sich_entschleißen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00254-002-s679><decide.sich_entschleißen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00254-002-s679><decide.sich_entschleißen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00254-002-s680><decide.sich_entschleißen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00254-002-s680><decide.sich_entschleißen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00254-002-s681><decide.sich_entschleißen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00254-002-s681><decide.sich_entschleißen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00254-002-s682><decide.sich_entschleißen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00254-002-s682><decide.sich_entschleißen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00254-002-s683><decide.sich_entschleißen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00254-002-s683><decide.sich_entschleißen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00254-002-s722><decide.wählen><en> You can decide if you would rather glide along the Peene, the "Amazon of the north", or cruise around the famous chalk cliffs at Kap Arkona.
<G-vec00254-002-s722><decide.wählen><de> Wählen Sie, ob Sie lieber die Peene, den "Amazonas des Nordens", entlanggleiten oder die berühmten Kreidefelsen am Kap Arkona umschiffen möchten.
<G-vec00254-002-s723><decide.wählen><en> You can decide whether you want to visit Budapest's biggest malls, or you want to go to the famous Váci street, our guides will take you there.
<G-vec00254-002-s723><decide.wählen><de> Du kannst wählen, ob du die größten Einkaufszentren vonBudapest oder die berühmte Váci Straße besuchen willst, unsere Guidesbegleiten dich.
<G-vec00254-002-s724><decide.wählen><en> Internet gambling halls provide table games with one big difference, if you decide on your casino thoroughly, these games are winnable.
<G-vec00254-002-s724><decide.wählen><de> Web Spielhöllen bieten Tabellen mit einem großen Unterschied, wenn Sie Ihren Online-Casino wählen Sie vorsichtig, diese Casino-Spiele sind schlagbar.
<G-vec00254-002-s725><decide.wählen><en> Read a good book on the rocking chair on your balcony, or leaf through our brochures and decide which wellness treatment you'd like to book.
<G-vec00254-002-s725><decide.wählen><de> Ein gutes Buch, der Schaukelstuhl auf Ihrem Balkon und der See … oder Sie blättern im Spa-Prospekt und wählen, welche Anwendung Sie am Nachmittag gerne machen möchten.
<G-vec00254-002-s726><decide.wählen><en> In dealing with the same quality of stone – and this is the case for quarries – it is possible to decide on and maintain an optimal speed.
<G-vec00254-002-s726><decide.wählen><de> Sägeplan Wenn Steine von gleicher Qualität bearbeitet werden – und dies ist der Fall bei Steinbrüchen -, kann man die optimale Geschwindigkeit wählen und auch beibehalten.
<G-vec00254-002-s727><decide.wählen><en> If you decide not to use cookies, the session data will be transmitted in every links you click.
<G-vec00254-002-s727><decide.wählen><de> Wenn Sie wählen, dass diese Informationen nicht in einem Cookie gespeichert werden sollen, so werden die Sitzungs-Daten mit jedem Link, auf den Sie klicken, mitversendet.
<G-vec00254-002-s728><decide.wählen><en> If you are trying to find the most powerful alternative, you need to decide on Phen375.
<G-vec00254-002-s728><decide.wählen><de> Wenn Sie die leistungsfähigste Alternative suchen, sollten Sie Phen375 wählen.
<G-vec00254-002-s729><decide.wählen><en> Decide for yourself how you would like to use our facilities.
<G-vec00254-002-s729><decide.wählen><de> Wählen Sie, wie Sie unsere Angebote nutzen möchten.
<G-vec00254-002-s730><decide.wählen><en> Using drag-and-drop technology, you’ll glide through your analysis – decide which question you want to analyze, what type of analysis you want to perform and in two clicks generate your graph or table, ready to be added to the report!
<G-vec00254-002-s730><decide.wählen><de> Die Analyse mit der Drag and Drop Technik Verschieben Sie die Frage, die Sie analysieren möchten, mit der Drag and Drop Technik in Ihren Fragebogen und wählen Sie, welche Art von Analyse Sie durchführen wollen.
<G-vec00254-002-s732><decide.wählen><en> When registering to set up your Swisscom Login you can decide whether you want to authenticate the registration via your mobile number, your land line or through the post.
<G-vec00254-002-s732><decide.wählen><de> Bei der Registrierung zur Einrichtung Ihres Swisscom Login können Sie wählen, ob wir Sie über Ihre Mobiltelefonnummer, Ihren Festnetzanschluss oder auf dem Postweg authentifizieren.
<G-vec00254-002-s733><decide.wählen><en> In such a case you can decide whether you still want to enforce your claim at your own expense.
<G-vec00254-002-s733><decide.wählen><de> Sie können in diesem Fall wählen, ob Sie Ihre Forderung auf Ihre eigenen Kosten weiterverfolgen wollen.
<G-vec00254-002-s734><decide.wählen><en> If agreement has not been reached concerning the procedure for the enquiry, the Parties should agree on the choice of an umpire who will decide upon the procedure to be followed.
<G-vec00254-002-s734><decide.wählen><de> Kann über das Untersuchungsverfahren keine Übereinstimmung erzielt werden, so kommen die Parteien überein, einen Schiedsrichter zu wählen, der über das zu befolgende Verfahren entscheidet.
<G-vec00254-002-s735><decide.wählen><en> If the delivered item is defective, we can at first decide whether we provide a supplementary performance by eliminating the defect (improvement) or by delivering a faultless item (replacement).
<G-vec00254-002-s735><decide.wählen><de> 7.5 Ist die gelieferte Sache mangelhaft, können wir zunächst wählen, ob wir Nacherfüllung durch Beseitigung des Mangels (Nachbesserung) oder durch Lieferung einer mangelfreien Sache (Ersatzlieferung) leisten.
<G-vec00254-002-s736><decide.wählen><en> In the first part of the dialog you can decide wheter you want to convert the text from all text symbols or only objects from a selected symbol.
<G-vec00254-002-s736><decide.wählen><de> Im ersten Teil des Dialogs können Sie wählen, ob Sie alle Objekte von allen Textsymbolen oder nur Objekte von einem selektierten Symbol umwandeln möchten.
<G-vec00254-002-s737><decide.wählen><en> You can decide how much privacy you prefer.
<G-vec00254-002-s737><decide.wählen><de> Sie wählen, wie viel Privatsphäre Sie möchten.
<G-vec00254-002-s738><decide.wählen><en> Consumers can decide the delivery days and locations that work best for their schedules - and you can benefit from their improved satisfaction with shipping and collection.
<G-vec00254-002-s738><decide.wählen><de> Kunden können den Tag und Ort der Lieferung wählen, der ihnen am besten passt - und Sie profitieren von gesteigerter Kundenzufriedenheit mit Lieferung und Abholung.
<G-vec00254-002-s739><decide.wählen><en> You just have to decide in which direction to point your bike.
<G-vec00254-002-s739><decide.wählen><de> Man braucht nur zu wählen, wohin man das Fahrrad lenken will.
<G-vec00254-002-s740><decide.wählen><en> You can decide between the following methods of payment: Cash, credit card, invoice, electronic direct debit (ELV) or AirPlus credit card (corporate customers).
<G-vec00254-002-s740><decide.wählen><de> Sie können zwischen den folgenden Bezahlmethoden wählen: Bar, Kreditkarte, Rechnung, Elektronisches Lastschriftverfahren (ELV) oder AirPlus-Kreditkarte (Geschäftskunden).
<G-vec00254-002-s779><decide.überlegen><en> We would not be the Insomnia if we did not go a little further: The fine line between harmless cuddles and deliberate touches is narrow and so there will be a second part of the party where everyone can decide whether he wants to participate or stay with the intentionless cuddling.
<G-vec00254-002-s779><decide.überlegen><de> Wir wären ja nicht das Insomnia, wenn wir nicht auch ein wenig weiter gehen würden: Der Grat aus harmlosen Kuscheln zu absichtvollen Berührungen ist schmal und so wird es einen zweiten Teil der Party geben, bei dem sich jeder überlegen kann ob er mitmachen will oder es beim absichtslosen Kuscheln belässt.
<G-vec00254-002-s780><decide.überlegen><en> Our search engine will help you book a flight to Milwaukee - all you have to do, is decide what to pack.
<G-vec00254-002-s780><decide.überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Milwaukee-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s781><decide.überlegen><en> After deciding whether you wish to operate your child-care business at home or in an independent facility, the next step is to decide what type of child care you would like to offer.
<G-vec00254-002-s781><decide.überlegen><de> Nachdem du dich entschlossen hast, ob du deine Kinderbetreuungseinrichtung bei dir zuhause oder in externen Räumlichkeiten eröffnen willst, ist der nächste Schritt, zu überlegen, welche Art Kinderbetreuungseinrichtung du gerne anbieten würdest.
<G-vec00254-002-s782><decide.überlegen><en> As far as the opening of the TLD catalogue is concerned, trademark owners must decide whether they wish to have their trademark(s) registered as a TLD, and they should also think about how to defend their trademarks against new TLDs that infringe upon their trademark(s).
<G-vec00254-002-s782><decide.überlegen><de> Markeninhaber müssen sich im Zusammenhang mit der Öffnung des TLD-Katalogs zum einen überlegen, ob sie ihre Marke(n) als TLD registrieren wollen und zum anderen darüber nachdenken, wie sie ihre Marken gegen neue TLDs verteidigen, welche ihre Marke(n) verletzen.
<G-vec00254-002-s783><decide.überlegen><en> And if the price is already in the internet, then I can decide whether I am going to play along or not.
<G-vec00254-002-s783><decide.überlegen><de> Und wenn es den Preis im Internet bereits gibt, dann kann ich mir überlegen, ob ich da mitspiele oder nicht.
<G-vec00254-002-s784><decide.überlegen><en> The children repeat the different steps of working with the Clip Art program and decide which picture each child will paint so that all important procedures are covered and documented.
<G-vec00254-002-s784><decide.überlegen><de> Die Kinder wiederholen die verschiedenen Schritte zur Arbeit mit dem Clip Art-Programm und überlegen, welche Bilder jedes einzelne Kind malt, so dass alle wichtigen Vorgänge dokumentiert werden.
<G-vec00254-002-s785><decide.überlegen><en> Watch the dancing waves from your four-poster sunbed next to a private plunge pool, as you decide what to have for dinner.
<G-vec00254-002-s785><decide.überlegen><de> Während Ihr vom Himmelbett direkt neben Eurem eigenen Pool den Wellen zuseht, könnt Ihr Euch schon einmal überlegen, was Ihr zu Abend essen möchtet.
<G-vec00254-002-s786><decide.überlegen><en> When opting for WordPress hosting, you need to decide what exactly your website should offer its users.
<G-vec00254-002-s786><decide.überlegen><de> Wenn Sie sich für Managed-WordPress-Hosting entscheiden, müssen Sie sich nur noch überlegen, was Ihre Website den Besuchern bieten soll.
<G-vec00254-002-s787><decide.überlegen><en> Instead of giving the answer, the teacher split the class into two groups, male and female, and asked them to decide for themselves whether computer' should be a masculine or a feminine noun.
<G-vec00254-002-s787><decide.überlegen><de> Anstatt einer Antwort, teilte der Lehrer die Klasse in zwei Gruppen ein, Frauen und Männer, und beauftragte sie, selber zu überlegen, ob "Computer" männlich oder weiblich sei.
<G-vec00254-002-s788><decide.überlegen><en> If you decide to install your own Wi-Fi access points, approval from LRZ is required.
<G-vec00254-002-s788><decide.überlegen><de> Falls Sie überlegen, eigene WLAN-Access Points zu installieren, ist eine Genehmigung durch das LRZ notwendig.
<G-vec00254-002-s789><decide.überlegen><en> You can then see the result on-screen and decide whether you want to continue with or cancel the print job.
<G-vec00254-002-s789><decide.überlegen><de> Sie können sich das Ergebnis anschließend am Bildschirm anschauen und überlegen, ob Sie den Druckauftrag fortsetzen oder stornieren wollen.
<G-vec00254-002-s790><decide.überlegen><en> Our search engine will help you book a flight to Victoria Inner Harbour - all you have to do, is decide what to pack.
<G-vec00254-002-s790><decide.überlegen><de> Mit unserer Flugsuchmaschine können Sie einen Victoria Inner Harbour-Flug buchen und müssen sich nur noch überlegen, was Sie in den Koffer packen.
<G-vec00254-002-s791><decide.überlegen><en> Because of this, you can decide if you want to cover the inside of the zine with artwork as well.
<G-vec00254-002-s791><decide.überlegen><de> Daher kannst du überlegen, ob du das Innere des Buches auch illustrieren willst.
<G-vec00254-002-s792><decide.überlegen><en> The second step in planning your wedding is to decide when the event should take place.
<G-vec00254-002-s792><decide.überlegen><de> Der zweite Schritt ist zu überlegen, wann die Hochzeit statt finden soll.
<G-vec00254-002-s793><decide.überlegen><en> First, you need to decide which data formats and data types to implement.
<G-vec00254-002-s793><decide.überlegen><de> Zunächst müssen Sie überlegen, welche Datenformate und Datentypen implementiert werden müssen.
<G-vec00254-002-s794><decide.überlegen><en> There is now the occasion to decide about how much of customization should really be retained.
<G-vec00254-002-s794><decide.überlegen><de> Es ist auch der Moment, zu überlegen, wieviel Anpassung (Customization) überhaupt beibehalten werden soll.
<G-vec00254-002-s795><decide.überlegen><en> I’d rather drink a cup of tea with her first, gab with her and then at the end decide whether or not to kiss her hand.
<G-vec00254-002-s795><decide.überlegen><de> Eher würde ich zuerst einen Tee mit ihr trinken, mit ihr tratschen und dann zum Abschied überlegen, ob ich ihr vielleicht die Hand küsse.
<G-vec00254-002-s796><decide.überlegen><en> You will have to collectively discuss and decide how to answer each question.
<G-vec00254-002-s796><decide.überlegen><de> Ihr müsst gemeinsam überlegen, wie ihr jede dieser Fragen beantworten wollt.
<G-vec00254-002-s797><decide.überlegen><en> Whether you have already introduced some happy hens to your garden or you're trying to decide if keeping chickens is for you, you're in the right place.
<G-vec00254-002-s797><decide.überlegen><de> Egal ob Sie schon in Ihrem Garten ein paar glückliche Hühner haben oder Sie noch überlegen, ob die Hühnerhaltung etwas für Sie ist, so sind Sie hier am richtigen Platz.
<G-vec00297-002-s551><decide.möchten><en> If you decide to leave the Developer Preview Program, you’ll have to do a factory reset on your Xbox One console.
<G-vec00297-002-s551><decide.möchten><de> Wenn Sie das Developer Preview Program verlassen möchten, müssen Sie die Xbox One Konsole auf die Werkseinstellungen zurücksetzen.
<G-vec00297-002-s552><decide.möchten><en> If you decide not to send your message, click Cancel.
<G-vec00297-002-s552><decide.möchten><de> Wenn Sie Ihre Nachricht nicht versenden möchten, klicken Sie auf Abbruch.
<G-vec00297-002-s553><decide.möchten><en> If you decide to change your password, the facebook connect will no longer work.
<G-vec00297-002-s553><decide.möchten><de> Wenn Sie Ihr Passwort ändern möchten, funktioniert Facebook Connect nicht mehr.
<G-vec00297-002-s554><decide.möchten><en> When you decide not to show content, the window is see-through and looks just like any window.
<G-vec00297-002-s554><decide.möchten><de> Wenn Sie nichts anzeigen möchten, ist das Fenster transparent und sieht wie ein gewöhnliches Fenster aus.
<G-vec00297-002-s555><decide.möchten><en> Address, Email address, First name / Last name, Radisson Rewards membership number, Stay details, Telephone number, and any other data you may decide to share with us in open comment boxes.
<G-vec00297-002-s555><decide.möchten><de> Adresse, E-Mail-Adresse, Vorname/Nachname, Radisson Rewards Mitgliedsnummer, Aufenthaltsdetails, Telefonnummer und alle anderen Daten, die Sie in offenen Kommentarboxen mit uns teilen möchten.
<G-vec00297-002-s556><decide.möchten><en> Your hosts very much look forward to seeing you soon and are happy to provide all the information you need, responding to your requests and ideas as soon as you decide to rent our catered chalet in South Tyrol.
<G-vec00297-002-s556><decide.möchten><de> Ihr Gastgeberpaar freut sich auf Sie und steht gerne für Informationen, Wünsche und Vorstellungen bereit, sobald Sie das Chalet in Südtirol mieten möchten.
<G-vec00297-002-s557><decide.möchten><en> And yes, it’s allowed on airplanes too if you decide to fly.
<G-vec00297-002-s557><decide.möchten><de> Und ja, es ist auch in Flugzeugen erlaubt, wenn Sie fliegen möchten.
<G-vec00297-002-s558><decide.möchten><en> Keep files private until you decide to share them.
<G-vec00297-002-s558><decide.möchten><de> Stellen Sie sicher, dass Dateien so lange privat bleiben, bis Sie sie freigeben möchten.
<G-vec00297-002-s559><decide.möchten><en> To allow you to share the information you decide to disclose to the users of Navionics’ services, we will use data relating to your location and the personal information that you will decide to post using certain features which will be activated exclusively upon your request.
<G-vec00297-002-s559><decide.möchten><de> Damit Sie Informationen teilen können, die Sie anderen Benutzern von Navionics-Diensten offenlegen möchten, verwenden wir Daten zu Ihrer Position sowie die personenbezogenen Daten, die Sie mithilfe bestimmter Funktionen im Beitrag veröffentlichen möchten, wobei diese Funktionen nur nach ausdrücklicher Anweisung durch Sie aktiviert werden.
<G-vec00297-002-s561><decide.möchten><en> If you decide not to use the template you opened, close the template (if you made any changes to it, click Delete in the dialog), then open another one.
<G-vec00297-002-s561><decide.möchten><de> Wenn Sie die geöffnete Vorlage nicht verwenden möchten, schließen Sie die Vorlage (wenn Sie bereits Änderungen vorgenommen haben, klicken Sie im angezeigten Dialogfenster auf „Löschen“) und öffnen Sie eine andere Vorlage.
<G-vec00297-002-s562><decide.möchten><en> If you decide to opt-out of any future tracking, a cookie will be set up in your browser to remember this choice for one year.
<G-vec00297-002-s562><decide.möchten><de> Falls Sie aus diesem Tracking aussteigen möchten, wird ein Cookie in ihrem Browser angelegt, um diese Entscheidung für ein Jahr zu gewährleisten.
<G-vec00297-002-s563><decide.möchten><en> Should you decide to change your preferences later through your browsing session, you can click on the „Privacy & Cookie Policy“ tab on your screen.
<G-vec00297-002-s563><decide.möchten><de> Wenn Sie Ihre Einstellungen später während Ihrer Browsersitzung ändern möchten, können Sie auf Ihrem Bildschirm auf die Registerkarte "Datenschutz- und Cookie-Richtlinie" klicken.
<G-vec00297-002-s564><decide.möchten><en> Should you decide to change your preferences later through your browsing session, you can click on the “Privacy & Cookie Policy” tab on your screen.
<G-vec00297-002-s564><decide.möchten><de> Wenn Sie Ihre Einstellungen später während Ihrer Browsersitzung ändern möchten, können Sie auf dem Bildschirm auf die Registerkarte „Datenschutz-Cookie-Richtlinie“ klicken.
<G-vec00297-002-s565><decide.möchten><en> For example, if you decide to store content in the public folder, the content will be public and available to anyone on the Internet who can find the folder.
<G-vec00297-002-s565><decide.möchten><de> Wenn Sie beispielsweise Inhalte im öffentlichen Ordner speichern möchten, wird der Inhalt der Öffentlichkeit und für jeden im Internet zugänglich, der diesen Ordner finden kann.
<G-vec00297-002-s566><decide.möchten><en> If you decide to visit Magnitogorsk, but do not know where to stay, our hotel is ready to offer you the best apartments.
<G-vec00297-002-s566><decide.möchten><de> Wenn Sie Magnitogorsk besuchen möchten, aber keine Ahnung haben, wo man unterhalten kann, ist unser Hotel bereit, die besten Zimmer zur Verfügung zu stellen.
<G-vec00297-002-s567><decide.möchten><en> Crew insurance is an issue to consider when you decide to rent a yacht.
<G-vec00297-002-s567><decide.möchten><de> Die Versicherung der Besatzung ist ein Thema, das Sie berücksichtigen sollten, wenn Sie eine Yacht mieten möchten.
<G-vec00297-002-s568><decide.möchten><en> This assures you that your gas fire is safe and ready for use at the time that you decide to enjoy it.
<G-vec00297-002-s568><decide.möchten><de> Das verschafft Ihnen die Gewissheit eines sicheren Gaskamins, der zu den Zeiten, an denen Sie ihn genießen möchten, einsatzbereit ist.
<G-vec00297-002-s569><decide.möchten><en> If you decide to use a compatible smart device*, you will need to download the new Dexcom G6 app.
<G-vec00297-002-s569><decide.möchten><de> Wenn Sie ein kompatibles Kommunikationsgerät* verwenden möchten, müssen Sie die neue G6-App herunterladen.
<G-vec00297-002-s703><decide.wollen><en> If students decide to discontinue coursework that has already been commenced in spite of an extension, an individual course of action shall be determined by the respective Examination Board.
<G-vec00297-002-s703><decide.wollen><de> Sollten Studierende eine angefangene Prüfungsleistung trotz Fristverlängerung abbrechen wollen, entscheidet der jeweilige Prüfungsausschuss über den Einzelfall.
<G-vec00297-002-s704><decide.wollen><en> If you decide to use it later, you can acquire a license from the online order page.
<G-vec00297-002-s704><decide.wollen><de> Wenn Sie es länger benutzen wollen, können Sie über die Online-Bestellseite eine Lizenz erwerben.
<G-vec00297-002-s705><decide.wollen><en> Ben je in de stemming voor je eigen Private tired of satisfying their ardent desires amongst themselves, they decide to spend a few days in the Alps in search of new, hot and wild sexual experiences which are capable of melting Albertville itself.
<G-vec00297-002-s705><decide.wollen><de> Lernen Sie diese sechs Zimmergefährten kennen, die, nachdem sie sich gegenseitig alle Wünsche erfüllt haben, einige Tagen in den Alpen verbringen wollen, um dort nach neuen, erregenden Sexerlebnissen zu suchen, die das Eis in dem kleinen Ort Albertville zum Schmelzen bringen werden.
<G-vec00297-002-s706><decide.wollen><en> If you decide to purchase a domain and search for terms and keywords such as Collaborative,Cooperation network,Network perhaps the search for your desired domain is now over.
<G-vec00297-002-s706><decide.wollen><de> Wenn Sie eine Domain erwerben wollen und nach Begriffen und Stichwörtern wie Kooperationsnetze,Netzwerk,Zusammenarbeit suchen, ist vielleicht jetzt die Suche nach Ihrer Wunschdomain beendet.
<G-vec00297-002-s707><decide.wollen><en> If you decide to purchase a domain and search for terms and keywords such as Automatically,Identification,Indexing perhaps the search for your desired domain is now over.
<G-vec00297-002-s707><decide.wollen><de> Wenn Sie eine Domain erwerben wollen und nach Begriffen und Stichwörtern wie Automatisch,Erkennung,Indizierung suchen, ist vielleicht jetzt die Suche nach Ihrer Wunschdomain beendet.
<G-vec00297-002-s708><decide.wollen><en> For those who decide to get around Venice by car the hotel offers on-site parking at no additional charge.
<G-vec00297-002-s708><decide.wollen><de> Für alle, die Venedig mit dem Auto erkunden wollen, bietet das Hotel einen hoteleigenen Parkplatz, den Sie kostenlos nutzen können.
<G-vec00297-002-s709><decide.wollen><en> Visitors may set their browsers to provide notice before they receive a cookie, giving the opportunity to decide whether to accept the cookie.
<G-vec00297-002-s709><decide.wollen><de> Besucher können ihren Browser so einstellen, dass Sie die Möglichkeit haben, bevor sie ein Cookie erhalten, gefragt zu werden, ob Sie das Cookie akzeptieren wollen oder nicht.
<G-vec00297-002-s710><decide.wollen><en> It is easiest, of course, to let the little ones decide which model from the current collection by Kjus for children is the best for them.
<G-vec00297-002-s710><decide.wollen><de> Am einfachsten ist es natürlich, man lässt die Kleinen mitentscheiden, welches Modell aus der aktuellen Kollektion von Kjus für Kinder sie haben wollen.
<G-vec00297-002-s711><decide.wollen><en> Fixed rate break fee: most lenders can charge this fee is you have a fixed-rate loan and you decide to repay your loan early.
<G-vec00297-002-s711><decide.wollen><de> Gebühr für vorzeitige Kreditrückzahlung: Sollten Sie Ihren Kredit vorzeitig zurückzahlen wollen, müssen Sie diese Gebühr möglicherweise zahlen.
<G-vec00297-002-s712><decide.wollen><en> At any point, you can use a backspace to back up what you are drawing in case you decide to change directions.
<G-vec00297-002-s712><decide.wollen><de> Sie können jederzeit mit der Backspace-Taste das von Ihnen Gezeichnete rückgängig machen, wenn Sie die Richtung ändern wollen.
<G-vec00297-002-s713><decide.wollen><en> The plot is located in a very quiet and peaceful location surrounded by trees which would future owners (whether they decide to build a family house or apartment building) allow peace and tranquility throughout the whole year.
<G-vec00297-002-s713><decide.wollen><de> Die Immobilie befindet sich im ruhigen Teil Brodaricas und ist vom Wald umgeben, was den zukünftigen Eigentümern Ruhe und Frieden das ganze Jahr hidurch bietet (egal ob sie ein Familienhaus oder Apartment-Gebäude bauen wollen).
<G-vec00297-002-s714><decide.wollen><en> If you decide to purchase the goods in your shopping cart, press "Continue to Next Step".
<G-vec00297-002-s714><decide.wollen><de> Wenn Sie die Produkte im Warenkorb kaufen wollen, klicken Sie den Button "weiter zum nächsten Schritt".
<G-vec00297-002-s715><decide.wollen><en> Getting around For those who decide to get around Tenerife by car the hotel offers nearby parking at no additional charge.
<G-vec00297-002-s715><decide.wollen><de> Für alle, die Teneriffa mit dem Auto erkunden wollen, bietet das Hotel einen in der Nähe Parkplatz, den Sie kostenlos nutzen können.
<G-vec00297-002-s716><decide.wollen><en> However, if you decide to stop there, you will get a digital attendance certificate according to the level completed.
<G-vec00297-002-s716><decide.wollen><de> Wenn Sie das aber nicht wollen, erhalten Sie eine Bestätigung der digitalen Anwesenheit für Ihr Level.
<G-vec00297-002-s717><decide.wollen><en> Women who decide to give up the traditional family cycle often join the women’s self-defence forces, such as the YPJ, dedicating their lives to defend the revolution and the people.
<G-vec00297-002-s717><decide.wollen><de> Frauen, die mit diesem Familienkreislauf brechen wollen, die auf der Suche nach einem befreiten Leben sind, schließen sich oft den Selbstverteidigungseinheiten (YPJ) an, um ihr Leben der Verteidigung und Befreiung der Bevölkerung zu widmen.
<G-vec00297-002-s718><decide.wollen><en> With this I do not wish to criticise certain individual voters, since we all have the freedom to vote for whomever we decide – be it a conservative, a social democrat, a communist or a nationalist.
<G-vec00297-002-s718><decide.wollen><de> An dieser Stelle möchte ich nicht einzelne Wähler*innen kritisieren, immerhin haben wir alle Wahlfreiheit und können stimmen für wen wir wollen – sei es konservativ, sozialdemokratisch, kommunistisch oder nationalistisch.
<G-vec00297-002-s719><decide.wollen><en> If you decide to purchase a domain and search for terms and keywords such as Business,Client,File perhaps the search for your desired domain is now over.
<G-vec00297-002-s719><decide.wollen><de> Wenn Sie eine Domain erwerben wollen und nach Begriffen und Stichwörtern wie Akte,Geschäft,Kunde suchen, ist vielleicht jetzt die Suche nach Ihrer Wunschdomain beendet.
<G-vec00297-002-s720><decide.wollen><en> And if you decide to stick around, the Sphere restaurant has - as you can imagine - pretty nice window tables.
<G-vec00297-002-s720><decide.wollen><de> Wenn Sie dort etwas länger bleiben wollen, hat das Sphere Restaurant - wie Sie sich denken können - nette Tische am Fenster.
<G-vec00297-002-s721><decide.wollen><en> Therefore you may decide to avoid whey protein powders in favor of another, if slightly less powerful type - beef or egg protein, for instance.
<G-vec00297-002-s721><decide.wollen><de> Aus diesem Grund könntest Du Molkeneiweißpulver zugunsten eines anderen, leicht weniger effektiven Pulvertyps vermeiden wollen – Rind- oder Hühnereiweiß zum Beispiel.
<G-vec00509-002-s570><decide.bestimmen><en> I wanted the starting block to be special, we can all decide on how much work we put into the starting row.
<G-vec00509-002-s570><decide.bestimmen><de> Der Startblock soll etwas Besonderes sein, jeder kann selbst bestimmen wie viel Arbeit er in seine Startreihe steckt.
<G-vec00509-002-s571><decide.bestimmen><en> All your adverts shown together, with a personal touch because you decide the layout, color, logo, photos and text of your website!
<G-vec00509-002-s571><decide.bestimmen><de> Alle Ihre Artikel werden zusammen präsentiert, mit einer persönlichen Note, da Sie selbst das Layout, Farbe und Logo Ihrer Website bestimmen.
<G-vec00509-002-s572><decide.bestimmen><en> You can decide how to invest them or spend them.
<G-vec00509-002-s572><decide.bestimmen><de> Sie können auch selbst bestimmen, wie Sie dieses anlegen und wann Sie es aufbrauchen möchten.
<G-vec00509-002-s573><decide.bestimmen><en> From the moment you open the app, you can decide when you want to connect to your Deeper sonar, start a new fishing session, pause and resume it whenever you choose to get back to it.
<G-vec00509-002-s573><decide.bestimmen><de> Scansteuerung Ab dem ersten Öffnen der App haben Sie die Möglichkeit, den Verbindungzeitpunkt zu Ihrem Deeper Sonar selbst zu bestimmen, eine neue Angelsitzung zu starten, sie anzuhalten oder mit ihr fortzufahren, wann immer Sie dies wünschen.
<G-vec00509-002-s574><decide.bestimmen><en> Changes would also permit each plant to decide the level of bruises, feathers, bile or ingesta appropriate for birds going down the line.
<G-vec00509-002-s574><decide.bestimmen><de> Die Änderungen würden es auch jedem Betrieb gestatten, selbst zu bestimmen, in welchem Umfang bei den zu verarbeitenden Tieren blaue Flecken, Federn, Galle und Ingesta toleriert werden können.
<G-vec00509-002-s575><decide.bestimmen><en> Because you have manual bidding enabled, it is up to you to decide the price here.
<G-vec00509-002-s575><decide.bestimmen><de> Da Du das manuelle Bieten aktiviert hast, kannst Du den Preis selbst bestimmen.
<G-vec00509-002-s576><decide.bestimmen><en> It should be up to you to decide on the equipment you want to use.
<G-vec00509-002-s576><decide.bestimmen><de> Sie können selbst bestimmen, welche Systeme Sie einsetzen möchten.
<G-vec00509-002-s577><decide.bestimmen><en> You can decide how many apps, contacts, and links will make it on to your homescreen.
<G-vec00509-002-s577><decide.bestimmen><de> Du kannst selbst bestimmen, wie viele Apps, Kontakte und Verknüpfungen auf einem Homescreen Platz finden.
<G-vec00509-002-s578><decide.bestimmen><en> In the absence of any agreement otherwise, we are entitled to decide the method of transport (in particular the transport company, route and packaging).
<G-vec00509-002-s578><decide.bestimmen><de> Soweit nicht etwas anderes vereinbart ist, sind wir berechtigt, die Art der Versendung (insbesondere Transportunternehmen, Versandweg, Verpackung) selbst zu bestimmen.
<G-vec00509-002-s579><decide.bestimmen><en> In order to offer you a larger selection, we always shoot a slightly larger selection of pictures, so that you can decide flexibly.
<G-vec00509-002-s579><decide.bestimmen><de> Um Dir eine größere Auswahl zu bieten schießen wir immer eine etwas größere Auswahl an Bildern, sodass Du Deinen Favoriten selbst bestimmen kannst.
<G-vec00509-002-s580><decide.bestimmen><en> First, a driver cannot decide the fare.
<G-vec00509-002-s580><decide.bestimmen><de> Erstens kann er den Fahrpreis nicht selbst bestimmen.
<G-vec00509-002-s581><decide.bestimmen><en> That is a good requirement for a successful future: Ace Of Base don't have to rely on other people's ideas and can decide on their own musical direction.
<G-vec00509-002-s581><decide.bestimmen><de> Das ist eine gute Voraussetzung für eine erfolgreiche Zukunft: Ace of Base müssen sich nicht auf die Ideen anderer verlassen und können ihre musikalische Richtung selbst bestimmen.
<G-vec00509-002-s582><decide.bestimmen><en> Students will be able to decide the duration of their deployment and arrange their work schedules to fit around other commitments.
<G-vec00509-002-s582><decide.bestimmen><de> Sie können die Dauer ihres Einsatzes und die tägliche Arbeitszeit nach Verfügbarkeit selbst bestimmen.
<G-vec00509-002-s583><decide.bestimmen><en> This is a completely legal tactic, as it is up to any individual player to decide his own best strategy.
<G-vec00509-002-s583><decide.bestimmen><de> Da jeder Spieler seine Strategie selbst bestimmen kann, ist dies eine vollkommen zulässige Taktik.
<G-vec00509-002-s584><decide.bestimmen><en> Shariff Wrapper enables you to decide, whether and when to transfer data to social networks.
<G-vec00509-002-s584><decide.bestimmen><de> Mit Hilfe von Shariff können Sie selbst bestimmen, ob und wann Daten an die Betreiber der jeweiligen sozialen Netzwerke übermittelt werden.
<G-vec00509-002-s585><decide.bestimmen><en> You decide about the amount you want to give.
<G-vec00509-002-s585><decide.bestimmen><de> Sie selbst bestimmen die Höhe des Gutscheines.
<G-vec00509-002-s586><decide.bestimmen><en> From luxury lodges to local community–run basic campsites, you can decide the flavour of your safari experience.
<G-vec00509-002-s586><decide.bestimmen><de> Von Luxus Lodgen bis hin zu Zeltcamps, so dass Sie selbst den Stil ihrer einzigartigen Safari bestimmen können.
<G-vec00509-002-s587><decide.bestimmen><en> Each room features its own temperature control so you can decide how warm you Architektur Neuigkeiten zum Projekt
<G-vec00509-002-s587><decide.bestimmen><de> Jedes Zimmer verfügt über eine eigene Temperaturregulierung, sodass Sie selbst bestimmen können, wo es wie warm sein soll.
<G-vec00509-002-s588><decide.bestimmen><en> This means that you decide whether or not you want to receive our newsletters and other information about new opportunities, events, and services.
<G-vec00509-002-s588><decide.bestimmen><de> Das bedeutet, dass Sie selbst bestimmen, ob Sie unsere Rundschreiben und andere Informationen über neue Möglichkeiten, Veranstaltungen und Dienstleistungen erhalten möchten.
<G-vec00509-002-s665><decide.entschließen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00509-002-s665><decide.entschließen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00509-002-s666><decide.entschließen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00509-002-s666><decide.entschließen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00509-002-s667><decide.entschließen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00509-002-s667><decide.entschließen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00509-002-s668><decide.entschließen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00509-002-s668><decide.entschließen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00509-002-s669><decide.entschließen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00509-002-s669><decide.entschließen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00509-002-s670><decide.entschließen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00509-002-s670><decide.entschließen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00509-002-s671><decide.entschließen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00509-002-s671><decide.entschließen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00509-002-s672><decide.entschließen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00509-002-s672><decide.entschließen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00509-002-s673><decide.entschließen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00509-002-s673><decide.entschließen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00509-002-s674><decide.entschließen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00509-002-s674><decide.entschließen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00509-002-s675><decide.entschließen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00509-002-s675><decide.entschließen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00509-002-s676><decide.entschließen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00509-002-s676><decide.entschließen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00509-002-s677><decide.entschließen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00509-002-s677><decide.entschließen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00509-002-s678><decide.entschließen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00509-002-s678><decide.entschließen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00509-002-s679><decide.entschließen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00509-002-s679><decide.entschließen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00509-002-s680><decide.entschließen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00509-002-s680><decide.entschließen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00509-002-s681><decide.entschließen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00509-002-s681><decide.entschließen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00509-002-s682><decide.entschließen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00509-002-s682><decide.entschließen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00509-002-s683><decide.entschließen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00509-002-s683><decide.entschließen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00509-002-s665><decide.sich_entschließen><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00509-002-s665><decide.sich_entschließen><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00509-002-s666><decide.sich_entschließen><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00509-002-s666><decide.sich_entschließen><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00509-002-s667><decide.sich_entschließen><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00509-002-s667><decide.sich_entschließen><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00509-002-s668><decide.sich_entschließen><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00509-002-s668><decide.sich_entschließen><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00509-002-s669><decide.sich_entschließen><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00509-002-s669><decide.sich_entschließen><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00509-002-s670><decide.sich_entschließen><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00509-002-s670><decide.sich_entschließen><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00509-002-s671><decide.sich_entschließen><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00509-002-s671><decide.sich_entschließen><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00509-002-s672><decide.sich_entschließen><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00509-002-s672><decide.sich_entschließen><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00509-002-s673><decide.sich_entschließen><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00509-002-s673><decide.sich_entschließen><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00509-002-s674><decide.sich_entschließen><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00509-002-s674><decide.sich_entschließen><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00509-002-s675><decide.sich_entschließen><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00509-002-s675><decide.sich_entschließen><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00509-002-s676><decide.sich_entschließen><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00509-002-s676><decide.sich_entschließen><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00509-002-s677><decide.sich_entschließen><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00509-002-s677><decide.sich_entschließen><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00509-002-s678><decide.sich_entschließen><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00509-002-s678><decide.sich_entschließen><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00509-002-s679><decide.sich_entschließen><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00509-002-s679><decide.sich_entschließen><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00509-002-s680><decide.sich_entschließen><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00509-002-s680><decide.sich_entschließen><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00509-002-s681><decide.sich_entschließen><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00509-002-s681><decide.sich_entschließen><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00509-002-s682><decide.sich_entschließen><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00509-002-s682><decide.sich_entschließen><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00509-002-s683><decide.sich_entschließen><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00509-002-s683><decide.sich_entschließen><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00509-002-s475><decide.treffen><en> But its finally up to the Presentation Manager and the Event Team to decide about if this option can be applied to your presentation.
<G-vec00509-002-s475><decide.treffen><de> Die Entscheidung darüber, ob dies auf Ihren Vortrag angewendet werden kann, treffen schlussendlich der Referentenbetreuer und das Event Team.
<G-vec00509-002-s476><decide.treffen><en> For example, when three tote companies are available and two of the three share an attribute that make them more desirable than the remaining tote, an additional factor may be used to decide between these two desirable totes.
<G-vec00509-002-s476><decide.treffen><de> Wenn beispielsweise drei Toto-Gesellschaften zur Auswahl stehen und zwei von den drei aufgrund irgendeines Attributs attraktiver erscheinen als der restliche Toto, kann ein zusätzlicher Faktor herangezogen werden, um eine Entscheidung zwischen diesen beiden attraktiveren Totos zu treffen.
<G-vec00509-002-s477><decide.treffen><en> This solution allows our clients to observe each stage of the project and decide about the final result of the renovation.
<G-vec00509-002-s477><decide.treffen><de> Eine derartige Lösung ermöglicht es dem Kunden, in jede Phase des Projekts Einsicht zu nehmen sowie eine letztendliche Entscheidung hinsichtlich des Effekts der Renovierung zu treffen.
<G-vec00509-002-s478><decide.treffen><en> If your case turns out to be untypical, you will be able to determine the cost of your treatment in advance and decide whether you wish to proceed with it.
<G-vec00509-002-s478><decide.treffen><de> Soll sich Ihre Situation aus irgendwelchem Grund als ungewöhnlich erweisen, können Sie dann den Preis der Behandlung im voraus bestimmen und die entsprechende Entscheidung davon treffen.
<G-vec00509-002-s479><decide.treffen><en> NATO would have had to decide on a ground campaign or else suspend the bombing and in a ground war it would not have been easy for NATO to overcome the growing political obstacles nor would the war ever have ended.
<G-vec00509-002-s479><decide.treffen><de> Die NATO hätte die Entscheidung treffen müssen, auf dem Boden zu kämpfen - und mit einem Bodenkrieg wäre es für die NATO nicht leicht gewesen, die zunehmenden politischen Hindernisse zu überwinden, und der Krieg wäre niemals zu einem Ende gekommen -, oder die Bombardierungen zu beenden.
<G-vec00509-002-s480><decide.treffen><en> The competent investigative judge could not be reached; at 4:42 pm his deputy said on the telephone that without knowing the investigative file he could not decide upon the requested search warrant.
<G-vec00509-002-s480><decide.treffen><de> Der zuständige Ermittlungsrichter konnte nicht erreicht werden; sein Vertreter erklärte um 16:42 Uhr telefonisch, er könne ohne Vorlage der Ermittlungsakte keine Entscheidung über die beantragte Durchsuchungsanordnung treffen.
<G-vec00509-002-s481><decide.treffen><en> The Commission shall examine the opinion of the Authority without delay and decide in accordance with the procedure referred to in Article 22(2).
<G-vec00509-002-s481><decide.treffen><de> Die Kommission kann nach dem in Artikel 28 Absatz 2 genannten Beratungsverfahren eine Entscheidung treffen, gegebenenfalls nach Einholung einer Stellungnahme der Behörde.
<G-vec00509-002-s482><decide.treffen><en> In order to decide for the most suitable machines for the required application, you should use the consulting services of an independent planner.
<G-vec00509-002-s482><decide.treffen><de> Um eine Entscheidung zu treffen, wer die passendsten Maschinen für den gewünschten Einsatzfall hat, sollte die unabhängige Hilfe eines Planers in Anspruch nehmen.
<G-vec00509-002-s483><decide.treffen><en> At this point you may decide that it’s best not to continue this relationship any further.
<G-vec00509-002-s483><decide.treffen><de> An diesem Punkt wirst du vielleicht die Entscheidung treffen, dass es besser ist, diese Beziehung nicht weiter fortzusetzen.
<G-vec00509-002-s484><decide.treffen><en> The inhabitants' enthusiasm and positive responds encouraged the Local Government and the organisers to decide to organise a summer festival annually.
<G-vec00509-002-s484><decide.treffen><de> Die positive Einstellung und die Rückmeldungen der Einwohner bewog die Organisatoren die Entscheidung zu treffen, dass ab 1996 die Programme des Jászberényer Sommers (JÁSZBERÉNYI NYÁR) jährlich veranstaltet werden.
<G-vec00509-002-s485><decide.treffen><en> In November 2015, the potential Democratic presidential candidate presented a bill at the United States Senate, S. 2237: Ending Federal Marijuana Prohibition Act of 2015 which aims to restrict the application of federal laws to the distribution and consumption of cannabis, remove prison sentences for its possession and cultivation, and allow states to decide for themselves and set their own laws regarding recreational use, without clashing with the legal restrictions of the federal government.
<G-vec00509-002-s485><decide.treffen><de> Der Kandidat der demokratischen Vorwahlen hat im November 2015 einen Gesetzentwurf in den Senat der Vereinigten Staaten eingebracht, S. 2237: Ending Federal Marijuana Prohibition Act of 2015, der die Anwendung der Bundesgesetze auf den Vertrieb und Konsum von Cannabis beschränken und die Strafen wegen Besitz und Anbau abschaffen und so den Bundesstaaten die Möglichkeit einräumen will, eine eigene Entscheidung zu treffen und eigene Gesetze bezüglich der Verwendung als Freizeitdroge zu erlassen, ohne auf gesetzliche Hürden seitens der Bundesregierung zu stoßen.
<G-vec00509-002-s486><decide.treffen><en> A and I could not decide on what pheno was better to backcross to the G13 father, the Cannalope B or E. And after plenty of testing we still could not decide which one was better.
<G-vec00509-002-s486><decide.treffen><de> Wir konnten uns nicht entscheiden welcher Pheno besser für eine Rückkreuzung mit dem G13-Vater war, die Cannalope B oder E... Selbst nach einer Reihe an Prüfungen konnten wir keine Entscheidung treffen.
<G-vec00509-002-s487><decide.treffen><en> This is also the time when you decide to double, take insurance, or break-up a pair.
<G-vec00509-002-s487><decide.treffen><de> Dies ist auch die Zeit, wenn Sie eine Entscheidung treffen zu Verdoppeln, eine Versicherung oder ein Teil eines Paares.
<G-vec00509-002-s488><decide.treffen><en> The appropriate nursing staff can accept the alarm by single touch and decide about next steps.
<G-vec00509-002-s488><decide.treffen><de> Der entsprechende Pflegemitarbeiter kann den Alarm annehmen und eine Entscheidung über die nächsten Schritte treffen.
<G-vec00509-002-s489><decide.treffen><en> I wrested this power from him and made the spiritual unfree so long, until the possibility existed to choose between two lords - so long until the spiritual was again able, to decide itself.
<G-vec00509-002-s489><decide.treffen><de> Diese Macht entwand Ich ihm und machte das Geistige unfrei so lange, bis die Möglichkeit bestand, zwischen zwei Herren zu wählen - so lange, bis das Geistige wieder fähig war, selbst eine Entscheidung zu treffen.
<G-vec00509-002-s490><decide.treffen><en> These people will decide for themselves.
<G-vec00509-002-s490><decide.treffen><de> Diese Menschen werden ihre eigene Entscheidung treffen.
<G-vec00509-002-s491><decide.treffen><en> The cows can completely decide themselves when they are milked.
<G-vec00509-002-s491><decide.treffen><de> Die Kühe können eine vollständige eigene Entscheidung treffen wann sie gemolken werden.
<G-vec00509-002-s492><decide.treffen><en> This should fairly highlight your professional experience, as an employer will decide on a possible interview, based on the details provided in your CV.
<G-vec00509-002-s492><decide.treffen><de> Dieser muss Ihre berufliche Erfahrung deutlich und fair ausdeuten weil der Arbeitgeber eine Entscheidung über ein mögliches Vorstellungsgespräch nur laut der Information aus dem Lebenslauf treffen kann.
<G-vec00509-002-s493><decide.treffen><en> The Saints were told they had only fifteen minutes to decide what to do.
<G-vec00509-002-s493><decide.treffen><de> Sie sagten den Heiligen, sie hätten fünfzehn Minuten Zeit, eine Entscheidung zu treffen.
<G-vec00106-002-s095><decide.entscheiden><en> If you change the staging status in the last document line, you decide in a system message whether the staging status in the document header is automatically changed as well.
<G-vec00106-002-s095><decide.entscheiden><de> Wenn Sie den Kommissionierstatus in der letzten Belegposition ändern, dann entscheiden Sie in einer Systemmeldung, ob auch der Kommissionierstatus im Belegkopf automatisch geändert wird.
<G-vec00106-002-s096><decide.entscheiden><en> He will review your work and decide if you are right for us.
<G-vec00106-002-s096><decide.entscheiden><de> Sie wird einen Blick auf Ihre Projekte werfen und dann entscheiden, ob Sie zu uns passen.
<G-vec00106-002-s097><decide.entscheiden><en> Once these samples have been produced, the artist can decide upon the technique or the type of glass that will be used for the development of the draft.
<G-vec00106-002-s097><decide.entscheiden><de> Nach der Anfertigung der Musterscheiben kann dann der Künstler entscheiden in welcher Technik oder Glasart der Entwurf zur Umsetzung kommt.
<G-vec00106-002-s098><decide.entscheiden><en> Unless the term of the suspended Board Member ends according to the Charter, the association's members decide upon the dismissal from the Supervisory Board.
<G-vec00106-002-s098><decide.entscheiden><de> Sofern die Amtszeit des beurlaubten Präsidiumsmitglieds dann nicht sowieso endet, entscheiden die Vereinsmitglieder über eine Abberufung aus dem Präsidium.
<G-vec00106-002-s099><decide.entscheiden><en> If the staging suggestion contains such document lines, you decide in a system message whether the staging suggestion still is to be posted.
<G-vec00106-002-s099><decide.entscheiden><de> Wenn der Kommissioniervorschlag solche Belegpositionen enthält, dann entscheiden Sie in einer Systemmeldung, ob der Kommissioniervorschlag trotzdem verbucht wird.
<G-vec00106-002-s100><decide.entscheiden><en> Also on this area Dusseldorf has much to offer and problems arise only if we cannot decide at the abundance of alternatives.
<G-vec00106-002-s100><decide.entscheiden><de> Auch davon hat Düsseldorf viel zu bieten und Probleme entstehen nur dann, wenn wir uns bei der Fülle von Alternativen nicht entscheiden können.
<G-vec00106-002-s101><decide.entscheiden><en> There you can decide if you spend the time of the break watching the market or taking a Cafe con leche at the Place.
<G-vec00106-002-s101><decide.entscheiden><de> Dort kannst du dann entscheiden, ob du lieber über den Markt schlenderst oder an der Place bei einem Cafe con leche dem bunten Treiben zuschaust.
<G-vec00106-002-s102><decide.entscheiden><en> If the day comes when we decide we want to become a pop band, that will be no ones choice but our own.
<G-vec00106-002-s102><decide.entscheiden><de> Wenn der Tag kommt, an dem wir eine Pop Band sein wollen, dann hat das niemand außer uns zu entscheiden.
<G-vec00106-002-s103><decide.entscheiden><en> 3. By way of derogation from paragraph 2 and notwithstanding the fact that a parent undertaking does not meet the conditions established in Article 18(1), the Board may decide on resolution action with regard to that parent undertaking when one or more of its subsidiaries which are institutions meet the conditions established in Article 18(1), (4) and (5) and their assets and liabilities are such that their failure threatens an institution or the group as a whole and resolution action with regard to that parent undertaking is necessary for the resolution of such subsidiaries which are institutions or for the resolution of the group as a whole.
<G-vec00106-002-s103><decide.entscheiden><de> (3) Abweichend von Absatz 2 kann der Ausschuss auch dann, wenn ein Mutterunternehmen die in Artikel 18 Absatz 1 genannten Voraussetzungen nicht erfüllt, über eine Abwicklungsmaßnahme in Bezug auf dieses Mutterunternehmen entscheiden, sofern ein oder mehrere seiner Tochterunternehmen, bei denen es sich um Institute handelt, die in Artikel 18 Absätze 1, 4 und 5 genannten Voraussetzungen erfüllen, ihre Vermögenswerte und Verbindlichkeiten so beschaffen sind, dass ihr Ausfall eine Bedrohung für ein Institut oder die Gruppe als Ganzes bewirkt, und eine Abwicklungsmaßnahme in Bezug auf dieses Mutterunternehmen für die Abwicklung solcher Tochterunternehmen, bei denen es sich um Institute handelt, oder für die Abwicklung der Gruppe als Ganzes erforderlich ist.
<G-vec00106-002-s104><decide.entscheiden><en> For each change, you can decide for yourself whether you want to accept or reject it.
<G-vec00106-002-s104><decide.entscheiden><de> Sie können dann für jede einzelne Änderung selbst entscheiden, ob Sie diese annehmen oder ablehnen möchten.
<G-vec00106-002-s105><decide.entscheiden><en> They can now decide, what you would like to do with the found files.
<G-vec00106-002-s105><decide.entscheiden><de> Sie können dann entscheiden, was Sie mit den Duplikaten machen möchten.
<G-vec00106-002-s106><decide.entscheiden><en> Whether the claims are true or not, you have to decide for yourself.
<G-vec00106-002-s106><decide.entscheiden><de> Ob man die gezeigte Darstellung hinterher glaubt oder nicht, muss man dann selbst entscheiden.
<G-vec00106-002-s107><decide.entscheiden><en> It will lead you to the north shore where you can decide for yourself if you prefer walking through a cute little grove or rather stroll along the promenade.
<G-vec00106-002-s107><decide.entscheiden><de> Die führt Dich direkt zum Nordufer, wo Du dann entscheiden kannst, ob Du lieber durch ein kleines Wäldchen spazieren oder an der Allee entlang flanieren möchtest.
<G-vec00106-002-s108><decide.entscheiden><en> Afterwards, you get to decide whether you want to buy the Sion or not.
<G-vec00106-002-s108><decide.entscheiden><de> Nach der Probefahrt kannst du dann entscheiden, ob du den Sion kaufen willst oder nicht.
<G-vec00106-002-s109><decide.entscheiden><en> After the exhibition has opened a jury will decide on a winner.
<G-vec00106-002-s109><decide.entscheiden><de> Eine Jury wird dann entscheiden, wer den Preis der Nationalgalerie gewinnt.
<G-vec00106-002-s110><decide.entscheiden><en> And last, but not least, is up to player to decide which seven soldiers from the pool will be the best squad for the mission.
<G-vec00106-002-s110><decide.entscheiden><de> Zu guter Letzt muss der Spieler dann entscheiden, welche sieben Söldner aus der Auswahl am besten geeignet sind für das Team dieser Mission.
<G-vec00106-002-s111><decide.entscheiden><en> If a patient has already been diagnosed with a disease, his or her doctor may decide to use Hair Element Analysis as an auxiliary method to achieve better results of treatment.
<G-vec00106-002-s111><decide.entscheiden><de> Falls eine Krankheit bei dem Patienten schon früher festgestellt wurde, dann kann der Arzt entscheiden, die Haar-Mineralstoff-Analyse als eine Hilfsmethode zu besseren Behandlungsergebnissen zu verwenden.
<G-vec00106-002-s112><decide.entscheiden><en> If the associations differ, you decide in a system message which association is to be adopted into the target document.
<G-vec00106-002-s112><decide.entscheiden><de> Wenn der Verband abweicht, dann entscheiden Sie in einer Systemmeldung, welcher Verband in den Zielbeleg übernommen wird.
<G-vec00106-002-s113><decide.entscheiden><en> (2) YOUR CHOICE AND USE OF ChatGF IS AT YOUR SOLE RISK, INCLUDING YOUR SELF-SELECTION OF ONLINE GIRLS FROM THE AVAILABLE LIST, DONE IN YOUR FULL AUTONOMY WITH NO INTERFERENCES FROM ChatGF, WHO DO NOT RECOMMEND YOU ANY SPECIFIC ONLINE GIRL OR GROUP OF THEM, BUT JUST PROVIDE SCHEDULE SOFTWARE THAT IS USED BY ONLINE GIRLS AUTONOMOUSLY TO PUBLISH THE TIMES AND DATES WHEN THEY CAN AND WISH TO DO VIDEO CHATS, THAT YOU MAY DECIDE TO ATTEND.
<G-vec00106-002-s113><decide.entscheiden><de> (2) IHRE WAHL UND BENUTZUNG VON ChatGF IST ALLEIN IHR RISIKO, EINSCHLIESSLICH IHRER EIGENEN AUSWAHL VON ONLINE GIRLS AUS DER LISTE DER VERFÜGBAREN, DIE SIE VÖLLIG EIGENSTÄNDIG OHNE EINMISCHUNG VON ChatGF TREFFEN, DIE IHNEN KEIN BESTIMMTES ONLINE GIRL ODER EINE GRUPPE VON IHNEN EMPFEHLEN, SONDERN NUR DIE TERMINIERUNGS-SOFTWARE ZUR VERFÜGUNG STELLEN, DIE VON DEN ONLINE GIRLS EIGENSTÄNDIG DAZU BENUTZT WIRD, UM DIE ZEITEN UND DATEN ZU VERÖFFENTLICHEN, WANN SIE VIDEO-CHATS MACHEN KÖNNEN UND WOLLEN, DIE SIE DANN ENTSCHEIDEN KÖNNEN ZU BESUCHEN.
<G-vec00106-002-s114><decide.entscheiden><en> Furthermore, you can set there your browser in such a way that you are informed about the placement of cookies as well as to be able to decide in each individual case whether you would like to accept a given cookie or not.
<G-vec00106-002-s114><decide.entscheiden><de> Ferner können Sie Ihren Browser dort so einstellen, dass Sie über das Setzen von Cookies informiert werden und jeweils im Einzelnen darüber entscheiden können, ob Sie ein Cookie annehmen möchten oder nicht.
<G-vec00106-002-s115><decide.entscheiden><en> Combining these services with our software solutions, customers can freely decide to utilize our engineering services solely or to institute smoothly in- house solutions based on their particular applications we already analyzed for them.
<G-vec00106-002-s115><decide.entscheiden><de> Die Kombination von Dienstleistungen mit unseren Software- Lösungen ermöglicht dem Kunden, frei darüber zu entscheiden, unsere Engineering- Dienstleistungen ausschließlich in Anspruch zu nehmen oder nahtlos firmeninterne Berechnungstools einzuführen, die dann bereits auf kundenspezifischen Anwendungsfällen beruhen.
<G-vec00106-002-s116><decide.entscheiden><en> In the present appeal proceedings, the board must decide whether the third party which claims to have replaced the appellants in these proceedings as their successor in title is right in maintaining that the appeal was never validly withdrawn.
<G-vec00106-002-s116><decide.entscheiden><de> Die Kammer hat im anhängigen Beschwerdeverfahren darüber zu entscheiden, ob der Dritte, der als Rechtsnachfolger in das Beschwerdeverfahren als Beschwerdeführer eingetreten zu sein geltend macht, die Wirksamkeit der Rücknahme der Beschwerde zu Recht bestreitet.
<G-vec00106-002-s117><decide.entscheiden><en> You can decide for yourself what information to send us in the contact form.
<G-vec00106-002-s117><decide.entscheiden><de> Sie können selbst darüber entscheiden, welche Information Sie uns über das Kontaktformular übermitteln.
<G-vec00106-002-s118><decide.entscheiden><en> You can decide for yourself which information you want to give us about the contact options.
<G-vec00106-002-s118><decide.entscheiden><de> Sie können selbst darüber entscheiden, welche Information Sie uns über die Kontaktmöglichkeiten übermitteln.
<G-vec00106-002-s119><decide.entscheiden><en> The 1920s will decide whether we still play a role in the world.
<G-vec00106-002-s119><decide.entscheiden><de> Die 20er Jahre werden darüber entscheiden, ob wir in der Welt noch eine Rolle spielen.
<G-vec00106-002-s120><decide.entscheiden><en> And the only thing that can be done when telling people that their place of birth is a mere coincidence (and not a merit) and that this coincidence does not hold the exclusive right to decide who may step on this part of earth and who may not, is to tell all the individual stories.
<G-vec00106-002-s120><decide.entscheiden><de> Und alles, was wir tun können, ist diese Geschichten von Menschen zu erzählen und damit deutlich zu sagen, dass wir per Geburt, also durch reinen Zufall (und nicht weil wir es verdient haben), zu unserer Heimat gekommen sind, und dass dieser Zufall nicht das Recht beinhaltet, darüber zu entscheiden, wer diesen Teil der Erde außerdem betreten darf, und wer nicht.
<G-vec00106-002-s121><decide.entscheiden><en> To find out how these insects decide whether or not to take up a challenger, Guillermo-Ferreira and his colleagues conducted fieldwork at a stream in Sao Paulo State in Brazil.
<G-vec00106-002-s121><decide.entscheiden><de> Guillermo-Ferreira und seine Kolleginnen und Kollegen führten an einem Fluss im Bundesstaat Sao Paulo in Brasilien einen Feldversuch durch, um herauszufinden, wie diese Insekten darüber entscheiden, ob sie sich in einen Kampf mit einem Rivalen begeben oder nicht.
<G-vec00106-002-s122><decide.entscheiden><en> Europeans will continue to decide for themselves how they want, for example, their healthcare, education and water delivered.
<G-vec00106-002-s122><decide.entscheiden><de> So werden die Menschen in Europa nach wie vor selbst darüber entscheiden, wie etwa Dienstleistungen in den Bereichen Gesundheit, Bildung und Wasserversorgung erbracht werden sollen.
<G-vec00106-002-s123><decide.entscheiden><en> And in this regards, it was planned that the people of Western Sahara were to take part in a referendum, to decide themselves how the territory was to be governed in the future.
<G-vec00106-002-s123><decide.entscheiden><de> Und hierzu war geplant, dass die Bevölkerung der Westsahara an einem Referendum teilnehmen sollte, um selbst darüber zu entscheiden, wie das Gebiet in Zukunft zu regieren sei.
<G-vec00106-002-s124><decide.entscheiden><en> Soft skills and personality are the key criteria for employers to decide which candidates will receive a job offer.
<G-vec00106-002-s124><decide.entscheiden><de> Soft Skills und Persönlichkeit sind die ausschlaggebenden Kriterien für Arbeitgeber, die darüber entscheiden welche Kandidaten ein Jobangebot erhalten.
<G-vec00106-002-s125><decide.entscheiden><en> It is the way you implement your plans that will decide whether you make it big or not.
<G-vec00106-002-s125><decide.entscheiden><de> Es ist die Art und Weise, wie du deine Pläne umsetzt, die darüber entscheiden wird, ob du dort groß rauskommst oder nicht.
<G-vec00106-002-s126><decide.entscheiden><en> – Constitution and legal laws: The constitution of a country indicates which state entity or person has the power to decide whether or not to go to war.
<G-vec00106-002-s126><decide.entscheiden><de> Verfassung und Gesetze: Die Verfassung eines Landes gibt vor, welche staatliche Institution oder Person darüber entscheiden kann, ob das Land in den Krieg zieht.
<G-vec00106-002-s127><decide.entscheiden><en> Just for a split-second before reviving, I was struggling with whether I wanted to come back or not, but I felt it wasn't up to me to decide that.
<G-vec00106-002-s127><decide.entscheiden><de> Nur für den Bruchteil einer Sekunde bevor ich wieder lebte, kämpfte ich damit ob ich zurückkommen wollte oder nicht, aber ich spürte dass es nicht an mir war darüber zu entscheiden.
<G-vec00106-002-s128><decide.entscheiden><en> Google can decide whether or not to use the information for other Google services.
<G-vec00106-002-s128><decide.entscheiden><de> Google kann darüber entscheiden, ob es diese Informationen für andere Google-Services übernimmt oder nicht.
<G-vec00106-002-s129><decide.entscheiden><en> Wolfgang Ketzler does the suggestion to decide on it today, if nobody of the present is against it, although no written proposition is available, since the club was already a member earlier.
<G-vec00106-002-s129><decide.entscheiden><de> Wolfgang Ketzler macht den Vorschlag, heute darüber zu entscheiden, wenn niemand der Anwesenden dagegen ist, obwohl kein schriftlicher Antrag vorliegt, da der Klub früher schon Mitglied war.
<G-vec00106-002-s130><decide.entscheiden><en> The heeling at a sports event can already decide after the first 10-20 steps, if the interested spectator leaves the terraces after the protection service bored or whether he stays tensely left in the expectation of a terrific performance.
<G-vec00106-002-s130><decide.entscheiden><de> Die Freifolge an einer Sportveranstaltung, kann bereits nach den ersten 10-20 Schritten darüber entscheiden, ob der interessierte Zuschauer nach dem Schutzdienst gelangweilt sich von der Tribüne entfernt, oder ob er gespannt sitzen bleibt in der Erwartung einer tollen Leistung.
<G-vec00106-002-s131><decide.entscheiden><en> The parents have decided to defer all medically unnecessary surgeries until their child can decide for herself.
<G-vec00106-002-s131><decide.entscheiden><de> Die Eltern haben entschieden, dass sie jegliche unnötige Operationen aufschieben, bis ihr Kind darüber selbst entscheiden kann.
<G-vec00106-002-s132><decide.entscheiden><en> Each newsletter begins with the subject, and it can decide on whether the message is ever taken note of or not.
<G-vec00106-002-s132><decide.entscheiden><de> Folgen Jeder Newsletter beginnt mit der Betreffzeile und diese kann darüber entscheiden, ob die Nachricht überhaupt zur Kenntnis genommen wird oder nicht.
<G-vec00106-002-s152><decide.entscheiden><en> For long journeys and training camps we recommend our roller bags and trolleys with a capacity of up to 100 liters (if you can't decide on the right shoes before heading out).
<G-vec00106-002-s152><decide.entscheiden><de> Für lange Reisen und Trainingslager empfehlen wir Dir unsere Rollentaschen und Trolleys mit bis zu 100 Liter Fassungsvermögen (Wenn Du dich vor der Abfahrt mal wieder nicht für die richtigen Schuhe entscheiden kannst).
<G-vec00106-002-s153><decide.entscheiden><en> At last you can decide to integrate yourself into Grigori Grabovoi’s structure also as a volunteer, as an agent and as a publisher.
<G-vec00106-002-s153><decide.entscheiden><de> Letztendlich kannst Du Dich entscheiden, Dich in Grigori Grabovois Struktur auch als Ehrenamtlicher, als Repräsentant und als Verleger zu integrieren.
<G-vec00106-002-s154><decide.entscheiden><en> You can even decide never to give your phone number to anyone again.
<G-vec00106-002-s154><decide.entscheiden><de> Du kannst dich sogar entscheiden, deine Telefonnummer nie wieder an jemanden weiterzugeben.
<G-vec00106-002-s155><decide.entscheiden><en> If drinking is happening at your home, you need to decide how you want to run it.
<G-vec00106-002-s155><decide.entscheiden><de> Wenn bei dir zu Hause getrunken wird, musst du dich entscheiden, wie das ablaufen soll.
<G-vec00106-002-s156><decide.entscheiden><en> On each turn, you roll the dice, and then decide which box is the best for your scores.
<G-vec00106-002-s156><decide.entscheiden><de> In jedem Zug würfelst du und kannst dich dann für ein Feld entscheiden, in das deine Punkte am besten passen.
<G-vec00106-002-s157><decide.entscheiden><en> You now have to decide.
<G-vec00106-002-s157><decide.entscheiden><de> Jetzt musst du dich entscheiden.
<G-vec00106-002-s158><decide.entscheiden><en> If you decide to master with TMF NET, quite naturally will 100% of all rights remain with you.
<G-vec00106-002-s158><decide.entscheiden><de> Solltest du dich für ein Mastering von TMF NET entscheiden, bleiben natürlich alle Rechte zu 100% bei dir.
<G-vec00106-002-s159><decide.entscheiden><en> If you decide not to use Feiyr, you do not have to pay anything.
<G-vec00106-002-s159><decide.entscheiden><de> Solltest Du Dich entscheiden, Dein Feiyr Konto nicht zu nutzen, musst Du nichts bezahlen.
<G-vec00106-002-s160><decide.entscheiden><en> When you have reviewed the Certification Preparation Packet you may decide to contact an assessor or assessors of your choosing to explore a mutual agreement to work together.
<G-vec00106-002-s160><decide.entscheiden><de> Wenn du das CNVC-Programm zur Vorbereitung der Zertifizierung (CPP) durchgelesen hast, kannst du dich entscheiden, einen Assessor oder eine Assessorin deiner Wahl zu kontaktieren, um eine gegenseitige Vereinbarung zur Zusammenarbeit zu finden.
<G-vec00106-002-s161><decide.entscheiden><en> You have to decide really quickly as the clock is ticking, but keep in mind that a mistake would be fatal.
<G-vec00106-002-s161><decide.entscheiden><de> Du musst dich schnell entscheiden, denn die Zeit läuft, aber denk daran, ein Fehler wäre tödlich.
<G-vec00106-002-s162><decide.entscheiden><en> You’re taking too long to decide.
<G-vec00106-002-s162><decide.entscheiden><de> Du brauchst zu lange, um dich zu entscheiden.
<G-vec00106-002-s163><decide.entscheiden><en> Everything is very easy with fashionette: You order without shipping charges and have an entire 30 days to decide if you want to keep the product – if not, return is also naturally gratis.
<G-vec00106-002-s163><decide.entscheiden><de> Mit Fashionette ist alles ganz easy: Du bestellst versandkostenfrei und hast ganze 30 Tage, um dich zu entscheiden, ob du die Produkte behalten möchtest – falls nicht, ist der Rückversand selbstverständlich auch gratis.
<G-vec00106-002-s164><decide.entscheiden><en> When you start advertising you have to decide about different things.
<G-vec00106-002-s164><decide.entscheiden><de> Wenn du anfängst zu werben, musst du dich über verschiedene Dinge entscheiden.
<G-vec00106-002-s165><decide.entscheiden><en> If the person is upset about something that you did, but you don't think it was a big deal or that it warrants an apology, then you have to decide.
<G-vec00106-002-s165><decide.entscheiden><de> Wenn die Person enttäuscht wegen etwas ist, von dem du denkst, dass es wirklich keine große Sache war oder keine Entschuldigung erfordert, musst du dich entscheiden.
<G-vec00106-002-s166><decide.entscheiden><en> Once you’ve recovered possession, you have to decide what to do with it.
<G-vec00106-002-s166><decide.entscheiden><de> Sobald du den Ball wiedererlangt hast, musst du dich entscheiden, was du damit machen willst.
<G-vec00106-002-s167><decide.entscheiden><en> You could not decide – neither going back nor forward.
<G-vec00106-002-s167><decide.entscheiden><de> Du konntest dich nicht entscheiden - weder zurückzugehen noch vorwärts.
<G-vec00106-002-s168><decide.entscheiden><en> Now she only needs to decide what to nibble on first, and with whom to share this exquisite chocolatey bounty!
<G-vec00106-002-s168><decide.entscheiden><de> Jetzt musst du dich nur noch entscheiden, was du zuerst anknabberst und mit wem du diese exquisite schokoladige Beute teilen möchtest.
<G-vec00106-002-s169><decide.entscheiden><en> Even before the first three community cards are dealt (the flop), you need to decide whether your hand can be played or not.
<G-vec00106-002-s169><decide.entscheiden><de> Noch bevor überhaupt die ersten drei Gemeinschaftskarten (der Flop) aufgedeckt werden, musst du dich entscheiden, ob du mit deiner Starthand in das Spiel einsteigen willst oder nicht.
<G-vec00106-002-s170><decide.entscheiden><en> If you decide to purchase CodeCheck Premium, it will be done through your Play-Store account.
<G-vec00106-002-s170><decide.entscheiden><de> Solltest Du Dich für den Kauf von CodeCheck Premium entscheiden, wird dieser über Dein Konto durchgeführt.
<G-vec00106-002-s171><decide.entscheiden><en> If you decide to take one from the bars or night clubs that can be a great value for money since they are generally good looking, however, it also takes some time to find them and if you are unlucky there might not even be any of them in that one particular club the night you are going.
<G-vec00106-002-s171><decide.entscheiden><de> Wenn du dich entscheidest in eine der Bars oder Nachtclubs zu gehen, welche ein gutes Preis-Leistungs-Verhältnis haben können, da sie dort in der Regel relativ gut aussehen, kann es jedoch einige Zeit dauern um jemanden zu finden und wenn du Pech hast, gibt es in dieser Nacht in diesem Club überhaupt keine.
<G-vec00106-002-s172><decide.entscheiden><en> This is ONLY used when you decide to use an in-app payment option.
<G-vec00106-002-s172><decide.entscheiden><de> Diese Option wird NUR benutzt, wenn du dich entscheidest, eine In-App-Zahlungsoption zu verwenden.
<G-vec00106-002-s173><decide.entscheiden><en> Before you decide on your equipment you can rent out skis and accessories from us and try these out.
<G-vec00106-002-s173><decide.entscheiden><de> Bevor du dich für eine Ausrüstung entscheidest, kannst du Skier und Zubehör bei uns ausleihen und ausgiebig testen.
<G-vec00106-002-s174><decide.entscheiden><en> The crowd gets involved, so be sure to bring your A-game if you decide to visit.
<G-vec00106-002-s174><decide.entscheiden><de> Die Menge wird mit einbezogen, also solltest du dein A-Spiel mitbringen, wenn du dich entscheidest, es zu besuchen.
<G-vec00106-002-s175><decide.entscheiden><en> Images from any Bound can be displayed on our website if you decide to publish them at the end of the Bound.
<G-vec00106-002-s175><decide.entscheiden><de> Von jedem Bound können Bilder auf unserer Internetseite angezeigt werden, wenn du dich am Ende des Bounds zur Veröffentlichung entscheidest.
<G-vec00106-002-s176><decide.entscheiden><en> If you decide for a day pass, you can get off at the main attractions and continue on the next bus.
<G-vec00106-002-s176><decide.entscheiden><de> Wenn du dich für ein Tagesticket entscheidest, kannst du an den wichtigsten Sehenswürdigkeiten aussteigen und mit dem nächsten Bus weiterfahren.
<G-vec00106-002-s177><decide.entscheiden><en> If you decide to get a ST sport suspension kit, you are definitely on the sporty side.
<G-vec00106-002-s177><decide.entscheiden><de> Wenn Du dich für ein ST Sportfahrwerk entscheidest bist Du zweifellos auf der sportlichen Seite.
<G-vec00106-002-s178><decide.entscheiden><en> Whatever type of lighting you decide to use, there are a couple of things to take note of.
<G-vec00106-002-s178><decide.entscheiden><de> Egal für welchen Leuchtmittel-Typ du dich entscheidest: es gibt ein paar Dinge, die du dir merken solltest.
<G-vec00106-002-s179><decide.entscheiden><en> When you decide for an available option, we shall ask you to send us your personal information and to wire the first month's rent plus the agency's fee in advance.
<G-vec00106-002-s179><decide.entscheiden><de> Wenn du dich für eine Option entscheidest, bitten wir dich um ein paar persönliche Angaben sowie um die Überweisung der ersten Monatsmiete und der Vermittlungsgebühr (siehe Gebühren).
<G-vec00106-002-s180><decide.entscheiden><en> Whether you decide to optimise your whole site or only select content (which we’ll discuss in a bit), you’ll be focusing mostly on URL structure and language targeting.
<G-vec00106-002-s180><decide.entscheiden><de> Unabhängig davon, ob Du Dich für eine Optimierung Deiner gesamten Webseite, oder nur für einige wichtige Teilbereiche entscheidest (hierauf gehen wir noch ein), liegt der Fokus generell auf einer optimierten URL Struktur und Sprache.
<G-vec00106-002-s181><decide.entscheiden><en> Plus you get to keep all your progress, and you can save 10% on the game if you decide you love it.
<G-vec00106-002-s181><decide.entscheiden><de> Außerdem bleiben all deine Fortschritte erhalten, und du kannst 10 % sparen, wenn du dich entscheidest, das Spiel zu kaufen.
<G-vec00106-002-s182><decide.entscheiden><en> With RaceRoom you can test all chargeable Vehicles for an indefinite period before you decide to buy your favourites.
<G-vec00106-002-s182><decide.entscheiden><de> Bei uns kannst du auch alle kostenpflichtigen Fahrzeuge für einen unbegrenzten Zeitraum kostenlos testen, bevor du dich für deine Favoriten entscheidest.
<G-vec00106-002-s183><decide.entscheiden><en> Before you decide to follow the Channel you can also check the Channel details, such as the topics covered as written in the description, the Channel Owner and members.
<G-vec00106-002-s183><decide.entscheiden><de> Bevor du dich entscheidest einem Channel zu folgen, kannst du die Channel-Details (Themen, Follower und Besitzer) erstmals auschecken.
<G-vec00106-002-s184><decide.entscheiden><en> Whichever you decide is the one for you, you know that onlookers will take you seriously on the slopes in the Le Tour pullover.
<G-vec00106-002-s184><decide.entscheiden><de> Für welche Farbe Du Dich auch entscheidest, Deine Zuschauer auf der Piste werden Dir im Le Tour Sport-Pullover sicher sein.
<G-vec00106-002-s185><decide.entscheiden><en> I have already touched this topic in the beginning of the guide, but let me tell you one thing: No matter if you decide to spend your sex holiday in Thailand, Cambodia, Philippines or Indonesia – you will have an unforgettable time in any of these countries and you won’t find it hard to meet and sleep with young girls that are more than 10 times as attractive as the girls from your home country – at a fraction of the cost.
<G-vec00106-002-s185><decide.entscheiden><de> Ich habe dieses Thema bereits zu Beginn des Guides angestoßen, aber lass mich dir eines sagen: Egal, ob du dich entscheidest, deinen Sex Urlaub in Thailand, Kambodscha, den Philippinen oder Indonesien zu verbringen – du wirst eine unvergessliche Zeit in allen diesen Ländern erleben, und du wirst es nicht schwierig finden, um intime Bekanntschaften mit jungen Frauen zu machen, die 10 mal so attraktiv sind wie die deutschen Frauen – zu einem Bruchteil des Preises.
<G-vec00106-002-s186><decide.entscheiden><en> No matter which field of activity you may decide, you will work in a team of qualified professionals, as well as apprentices and trainees.
<G-vec00106-002-s186><decide.entscheiden><de> Egal für welchen Praxisbereich du dich entscheidest, arbeitest du im Team zusammen mit qualifizierten Fachkräften, sowie Auszubildenden oder Praktikanten/Praktikantinnen.
<G-vec00106-002-s187><decide.entscheiden><en> This is ONLY used when you decide to use an in-game payment option.
<G-vec00106-002-s187><decide.entscheiden><de> Diese Option wird NUR benutzt, wenn du dich entscheidest, eine Zahlungsoption im Spiel zu verwenden.
<G-vec00106-002-s188><decide.entscheiden><en> Before you decide to go through with a tummy tuck, talk to your doctor.
<G-vec00106-002-s188><decide.entscheiden><de> Bevor du dich für eine Bauchstraffung entscheidest, solltest du mit einem Arzt sprechen.
<G-vec00106-002-s189><decide.entscheiden><en> Whatever you decide, to be honest, I am not bothered whether I am born in a water pool, on a birthing swing or at home.
<G-vec00106-002-s189><decide.entscheiden><de> Wie auch immer du dich entscheidest: Ehrlich gesagt ist es mir egal, ob ich in einem Wasserbecken, auf einer Geburtsschaukel oder zu Hause geboren werde.
<G-vec00106-002-s190><decide.entscheiden><en> Afterwards decide whether the following statements are true or nbsp;
<G-vec00106-002-s190><decide.entscheiden><de> Entscheide danach ob die folgenden Aussagen wahr oder falsch sind.
<G-vec00106-002-s191><decide.entscheiden><en> I decide the adoptions, go to the future parents of my dog and prove everything, often bringing several dogs to the new home so they can decide themselves which dog is the best choice - especially if they have already a dog and are looking for another dog.
<G-vec00106-002-s191><decide.entscheiden><de> Ich entscheide die Adoptionen, fahre zu den zukünftigen Eltern meines Hundes und besichtige alles, bringe oft mehrere Hunde, damit im Haus selbst entschieden werden kann, welcher Hund ist die beste Wahl – speziell wenn schon ein eigener Hund vorhanden ist.
<G-vec00106-002-s192><decide.entscheiden><en> My gut and belly, which I by the way learned to love from the inside and the outside, makes a lovely flutter or gives me a terrifying uaargh-feel and within seconds when I decide the things I have to decide.
<G-vec00106-002-s192><decide.entscheiden><de> Mein Bauch, den ich übrigens von Innen als auch von Außen sehr lieb gewonnen habe, gibt dann entweder ein nettes Kribbeln oder ein ungutes Uuuarghs-Gefühl von sich und ich entscheide Dinge innerhalb von Sekunden.
<G-vec00106-002-s193><decide.entscheiden><en> Save your search on the home page and decide what recipes inspire you every day.
<G-vec00106-002-s193><decide.entscheiden><de> Speichere deine Suchen auf der Startseite und entscheide, welche Rezepte dich täglich inspirieren.
<G-vec00106-002-s194><decide.entscheiden><en> I decide how I see things.
<G-vec00106-002-s194><decide.entscheiden><de> Ich entscheide, wie ich die Dinge sehe.
<G-vec00106-002-s195><decide.entscheiden><en> 1 Decide how you’d like to cook your momos.
<G-vec00106-002-s195><decide.entscheiden><de> 1 Entscheide, wie du die Momos garen möchtest.
<G-vec00106-002-s196><decide.entscheiden><en> But I shall leave nothing to fate now and face up to the challenge: Despite the rain, I decide to go for a walk.
<G-vec00106-002-s196><decide.entscheiden><de> Ich überlasse nun aber nichts dem Schicksal und stelle mich tapfer der Herausforderung: Trotz Regen entscheide ich mich, einen Spaziergang zu unternehmen.
<G-vec00106-002-s197><decide.entscheiden><en> If a funding does come into question, do not force the non-profits to tailor their application to your expectations - decide whether a funding according to their expectations is feasible.
<G-vec00106-002-s197><decide.entscheiden><de> Wenn eine Förderung in Frage kommt, dann zwinge die Non-Profits nicht, ihren Antrag auf Deine Vorstellungen hin zuzuschneiden, sondern entscheide, ob eine Förderung entlang ihrer Vorstellungen sinnvoll ist.
<G-vec00106-002-s198><decide.entscheiden><en> Decide if you will fight for justice or revel in anarchy.
<G-vec00106-002-s198><decide.entscheiden><de> Entscheide, ob du für die Gerechtigkeit kämpfst oder dich der Anarchie verschreibst.
<G-vec00106-002-s199><decide.entscheiden><en> After having seen the village of Alt-Marzahn from the platform of the Skywalk, situated in the middle of the prefabricated buildings, I decide to go for a walk through the historic village after my high-rise adventure.
<G-vec00106-002-s199><decide.entscheiden><de> Nachdem ich von der Plattform des Skywalks aus bereits das inmitten der Plattenbauten gelegene Dorf Alt-Marzahn gesehen habe, entscheide ich mich nach meiner Kletterpartie zu einem Spaziergang durch das historische Örtchen.
<G-vec00106-002-s200><decide.entscheiden><en> Decide which type of distribution suits your experiment.
<G-vec00106-002-s200><decide.entscheiden><de> Entscheide, welche Verteilung zu deinem Experiment passt.
<G-vec00106-002-s201><decide.entscheiden><en> Decide the length of the chimes desired.
<G-vec00106-002-s201><decide.entscheiden><de> Entscheide die Länge des gewünschten Glockenspiel.
<G-vec00106-002-s202><decide.entscheiden><en> I decide the destination of each man not on the basis of age, seniority, amount of suffering, or least of all, the degree of misery, but on whether they possess truth.
<G-vec00106-002-s202><decide.entscheiden><de> Ich entscheide den Bestimmungsort eines jeden Menschen nicht auf der Grundlage von Alter, Vorrang, Umfang des Leidens und am Allerwenigsten nach dem Grad, in dem er um Mitleid bittet, sondern danach, ob er die Wahrheit besitzt.
<G-vec00106-002-s203><decide.entscheiden><en> Against the backdrop of all I’ve seen and heard, I decide to call my ex.
<G-vec00106-002-s203><decide.entscheiden><de> Vor dem Hintergrund all dessen, was ich nun gesehen und gehört habe, entscheide ich mich, meinen mittlerweile Ex-Freund anzurufen.
<G-vec00106-002-s204><decide.entscheiden><en> Decide which color you prefer, or try growing different varieties of African Violets.
<G-vec00106-002-s204><decide.entscheiden><de> Entscheide, welche Farbe du bevorzugst oder probiere verschiedene Sorten von Usambaraveilchen aus.
<G-vec00106-002-s205><decide.entscheiden><en> 4 Decide if surgery is an option.
<G-vec00106-002-s205><decide.entscheiden><de> 4 Entscheide, ob eine Operation eine Option ist.
<G-vec00106-002-s206><decide.entscheiden><en> Go through what you already own and decide what you like.
<G-vec00106-002-s206><decide.entscheiden><de> Sieh die Sachen durch, die Du bereits besitzt und entscheide, was Dir davon gefällt.
<G-vec00106-002-s207><decide.entscheiden><en> I get to decide who I am, on my terms.
<G-vec00106-002-s207><decide.entscheiden><de> Ich entscheide, wer ich bin.
<G-vec00106-002-s208><decide.entscheiden><en> Decide whether you have to use much or wrong answers
<G-vec00106-002-s208><decide.entscheiden><de> Entscheide, ob du much oder many einsetzen musst.
<G-vec00106-002-s209><decide.entscheiden><en> Decide whether or not to talk to a doctor.
<G-vec00106-002-s209><decide.entscheiden><de> Entscheide dich, ob du mit einem Arzt sprechen willst.
<G-vec00106-002-s210><decide.entscheiden><en> Before you get started on the initial design of your logo, decide what “feel” you want to create with your logo―your “brand identity”.
<G-vec00106-002-s210><decide.entscheiden><de> Bevor du mit dem Designen deines Logos beginnst, entscheide dich, welches „Gefühl“ du mit deinem Logo erzeugen willst – das ist deine Markenidentität.
<G-vec00106-002-s211><decide.entscheiden><en> 1 Decide what illness you are going to fake.
<G-vec00106-002-s211><decide.entscheiden><de> 1 Entscheide dich, welche Krankheit du vortäuschen willst.
<G-vec00106-002-s212><decide.entscheiden><en> 1 Decide on the purpose for your notebook.
<G-vec00106-002-s212><decide.entscheiden><de> 1 Entscheide dich für den Zweck deines Notizbuches.
<G-vec00106-002-s213><decide.entscheiden><en> Well, then decide to give HIM control.
<G-vec00106-002-s213><decide.entscheiden><de> Also entscheide dich, IHM die Kontrolle zu überlassen.
<G-vec00106-002-s214><decide.entscheiden><en> Your solo birthday should be about you doing exactly what you want to do, so whether you decide to stay in or go out, be sure to choose a fun or relaxing activity of some sort.
<G-vec00106-002-s214><decide.entscheiden><de> Dein Geburtstag sollte dazu da sein, um genau das zu tun, was du tun möchtest, also entscheide dich, ob du ausgehen oder zuhause bleiben möchtest.
<G-vec00106-002-s215><decide.entscheiden><en> 5 Decide on a time and place.
<G-vec00106-002-s215><decide.entscheiden><de> 5 Entscheide dich für eine Zeit und einen Ort.
<G-vec00106-002-s216><decide.entscheiden><en> Decide on a container.
<G-vec00106-002-s216><decide.entscheiden><de> Entscheide dich für einen Behälter.
<G-vec00106-002-s217><decide.entscheiden><en> Decide to allow conflicts to get close to you, to engage.
<G-vec00106-002-s217><decide.entscheiden><de> Entscheide dich, Konflikte an dich heranzulassen, dich auf sie einzulassen.
<G-vec00106-002-s218><decide.entscheiden><en> Decide when you’d like to host your meals, and what you will cook.
<G-vec00106-002-s218><decide.entscheiden><de> Entscheide Dich, wann du ein Essen veranstalten möchstest und was du kochen willst.
<G-vec00106-002-s219><decide.entscheiden><en> Decide how many strands of yarn you want to put together.
<G-vec00106-002-s219><decide.entscheiden><de> Entscheide dich, wie viele Stränge du zusammennehmen möchtest.
<G-vec00106-002-s220><decide.entscheiden><en> Decide below if you want both sides of the bed runner made of decorative fabric or the underside finished with decorative lining.
<G-vec00106-002-s220><decide.entscheiden><de> Unterhalb entscheide Dich, ob der Kissenbezug doppelseitig aus Dekostoff gefertigt sein wird oder auf der Stoffunterseite mit einer dekorativen Verkleidung veredelt sein soll.
<G-vec00106-002-s221><decide.entscheiden><en> Decide what games and activities you want to plan for the party, and gather any items you need before the party starts.
<G-vec00106-002-s221><decide.entscheiden><de> Entscheide dich, welche Spiele und Aktivitäten du für die Party planst und lege alles was du dafür brauchst bereit, bevor sie beginnt.
<G-vec00106-002-s222><decide.entscheiden><en> 7 Decide if you are willing to work through this, or if you're through.
<G-vec00106-002-s222><decide.entscheiden><de> 7 Entscheide dich, ob du bereit bist, das aufzuarbeiten oder ob die Sache für dich durch ist.
<G-vec00106-002-s223><decide.entscheiden><en> Decide if you want to host the blog yourself.
<G-vec00106-002-s223><decide.entscheiden><de> Entscheide dich, ob du den Blog selbst hosten möchtest.
<G-vec00106-002-s224><decide.entscheiden><en> Decide when to go to the Grand Canyon.
<G-vec00106-002-s224><decide.entscheiden><de> Entscheide dich für die richtige Reisezeit.
<G-vec00106-002-s225><decide.entscheiden><en> Decide on a harmless reason for your fake faint.
<G-vec00106-002-s225><decide.entscheiden><de> Entscheide dich für einen harmlosen Auslöser für deine simulierte Ohnmacht.
<G-vec00106-002-s226><decide.entscheiden><en> Decide what level of limit poker feels comfortable, and set a profit target for the session.
<G-vec00106-002-s226><decide.entscheiden><de> Entscheide dich, bei welchem Niveau des Limits du dich am wohlsten fühlst, und setze dir ein Ziel für deinen Profit während dieser Session.
<G-vec00106-002-s227><decide.entscheiden><en> 1 Decide whether you will serve the salad plain or as a sandwich.
<G-vec00106-002-s227><decide.entscheiden><de> 1 Entscheide dich, ob du den Eiersalat schlicht oder als Sandwich servieren möchtest.
<G-vec00106-002-s228><decide.entscheiden><en> In the rooms, the customer can decide what temperature you want.
<G-vec00106-002-s228><decide.entscheiden><de> In den Räumen, kann der Kunde entscheiden, welche Temperatur Sie wollen.
<G-vec00106-002-s229><decide.entscheiden><en> The future of the economic trade schemes and volumes is very closely attached to the actions the politicians on both sides will take. The political class will decide, in which way the economic cooperation between Russia and the European Union will develop.
<G-vec00106-002-s229><decide.entscheiden><de> In diesem Fall liegt der wirtschaftliche Austausch eindeutig den Handlungen der Politik zugrunde, diese wird entscheiden, wie sich der Handel und die wirtschaftliche Kooperation zwischen Russland und der EU weiter entwickeln werden.
<G-vec00106-002-s230><decide.entscheiden><en> This includes such things as reflecting on the value of personal data, understanding how opinions are influenced and thinking about what artificial intelligence can do and what it should not be allowed to decide.
<G-vec00106-002-s230><decide.entscheiden><de> Dazu gehört zum Beispiel das Nachdenken über den Wert von persönlichen Daten, das Erkennen, wie Meinungen beeinflusst werden oder auch die Auseinandersetzung damit, was künstliche Intelligenz kann und was sie nicht entscheiden sollte.
<G-vec00106-002-s231><decide.entscheiden><en> In addition, the GA has the power to decide on TIPA membership issues and make all other decisions on extraordinary matters.
<G-vec00106-002-s231><decide.entscheiden><de> Des Weiteren ist die Hauptversammlung berechtigt, über TIPA-Mitgliedschaftsfragen zu entscheiden und Entscheidungen in anderen außerordentlichen Angelegenheiten zu treffen.
<G-vec00106-002-s232><decide.entscheiden><en> Actions taken and not taken here in Panama will decide the answers to these questions as this week’s meeting unfolds.
<G-vec00106-002-s232><decide.entscheiden><de> Über die Antworten auf all diese Fragen werden die Entwicklungen diese Woche hier in Panama entscheiden.
<G-vec00106-002-s233><decide.entscheiden><en> The Divisions and the Boards of Appeal shall decide as to the action to be taken in the cases specified in paragraphs 2 and 3 without the participation of the member concerned.
<G-vec00106-002-s233><decide.entscheiden><de> Die Abteilungen und die Beschwerdekammern entscheiden in den Fällen der Absätze 2 und 3 ohne Mitwirkung des betreffenden Mitglieds.
<G-vec00106-002-s234><decide.entscheiden><en> From the moment a transaction is notified, the Commission generally has a total of 25 working days to decide whether to grant approval (Phase I) or to start an in-depth investigation (Phase II).
<G-vec00106-002-s234><decide.entscheiden><de> Nach der Anmeldung eines Zusammenschlusses hat die Kommission in der Regel 25 Arbeitstage Zeit, um zu entscheiden, ob sie das Rechtsgeschäft in einer ersten vorläufigen Prüfung genehmigt (Phase I) oder eine eingehende Prüfung einleitet (Phase 2).
<G-vec00106-002-s235><decide.entscheiden><en> An important point is that patients must be able to decide themselves whether they want an electronic patient record.
<G-vec00106-002-s235><decide.entscheiden><de> Ein wichtiger Punkt ist, dass der Patient selbst entscheiden kann, ob er ein elektronisches Patientendossier will.
<G-vec00106-002-s236><decide.entscheiden><en> In case some erotic content is provided, Chateadoras will assess the situation and decide whether the claim of customer is grounded and any compensation/refund of tokens is due.
<G-vec00106-002-s236><decide.entscheiden><de> Für den Fall, dass irgendwelche erotische Inhalte bereitgestellt wurden, wird Chateadoras die Situation bewerten und entscheiden, ob der Anspruch des Kunden begründet ist und ein Ausgleich / eine Rückerstattung von Token vorzunehmen ist.
<G-vec00106-002-s237><decide.entscheiden><en> Whether it’s a Monster, Spell, or Trap, you get to choose its fate with powerful negation effects that decide the Duel.
<G-vec00106-002-s237><decide.entscheiden><de> Egal ob es sich um eine Monster, Zauber- oder eine Fallenkarte handelt, du kannst Schicksal spielen und mit mächtigen Negationseffekten das Duell entscheiden.
<G-vec00106-002-s238><decide.entscheiden><en> No, Free Canadian Sex Chat does not have any recurring charges as we want our members to decide for themselves when they want to buy more tokens.
<G-vec00106-002-s238><decide.entscheiden><de> Nein, Busty Free Webcams Live Sex Chat Free bietet kein Abonnement oder regelmäßige Abrechnung an, da wir möchten, dass unsere Mitglieder selbst entscheiden, wann sie weitere Token kaufen wollen.
<G-vec00106-002-s239><decide.entscheiden><en> After two weeks of test mode, parents can decide whether they want to receive them on or not.
<G-vec00106-002-s239><decide.entscheiden><de> Nach zwei Wochen Test-Modus, können die Eltern entscheiden, ob sie sie auf oder nicht erhalten möchten.
<G-vec00106-002-s240><decide.entscheiden><en> In any case, let's take a look at this powerful hormone and let you decide if there's a use for you.
<G-vec00106-002-s240><decide.entscheiden><de> Auf jeden Fall lassen Sie uns einen Blick auf dieses starke Hormon werfen und lassen Sie Sie entscheiden, wenn es einen Gebrauch für Sie gibt.
<G-vec00106-002-s241><decide.entscheiden><en> This means that you must consistently decide whether a particular project in your portfolio is more important than another.
<G-vec00106-002-s241><decide.entscheiden><de> Das heißt, Sie müssen in Ihrem Portfolio konsequent entscheiden, ob ein bestimmtes Projekt wichtiger ist als ein anderes.
<G-vec00106-002-s242><decide.entscheiden><en> This game belongs to him, which will be discussed to the list - you decide.
<G-vec00106-002-s242><decide.entscheiden><de> Dieses Spiel gehört ihm, was wird in die Liste diskutiert werden - Sie entscheiden.
<G-vec00106-002-s243><decide.entscheiden><en> Given that reddit just took a $150 million investment from a Chinese censorship powerhouse, I thought it would be nice to post this picture of “Tank Man” at Tienanmen Square before our new glorious overlords decide we cannot post it anymore. from r/pics
<G-vec00106-002-s243><decide.entscheiden><de> "Angesichts der Tatsache, dass Reddit gerade eine Investition von 150 Millionen US-Dollar von einem chinesischen Kraftwerk der Zensur übernommen hatte, dachte ich, es wäre schön, dieses Bild von Winnie-The-Pooh zu posten, bevor unsere neuen glorreichen Overlords entscheiden, dass wir es nicht mehr veröffentlichen können", so der Post-Read.
<G-vec00106-002-s244><decide.entscheiden><en> This information is shared to help the ad network decide whether they want to serve an ad to the user and, if so, which ad they want to show, and how much they want to bid.
<G-vec00106-002-s244><decide.entscheiden><de> Diese Informationen werden weitergegeben, damit der Bieter entscheiden kann, ob er eine Anzeige für den Nutzer bereitstellen möchte, und wenn ja, welche Anzeige es sein soll und wie viel er bieten möchte.
<G-vec00106-002-s245><decide.entscheiden><en> People that are able to decide are people that win.
<G-vec00106-002-s245><decide.entscheiden><de> Menschen, die entscheiden können, sind Menschen, die gewinnen.
<G-vec00106-002-s246><decide.entscheiden><en> Thor electronic exhaust system allows the owner to decide for himself about the way his car should sound and how loud it should be.
<G-vec00106-002-s246><decide.entscheiden><de> Mit der elektronischen Thor-Abgassystem kann der Inhaber selbst entscheiden, wie laut das Auto sein soll.
<G-vec00106-002-s266><decide.entscheiden><en> But in order to decide whether you will raise or fold, you must understand a very important concept in poker: position.
<G-vec00106-002-s266><decide.entscheiden><de> Um entscheiden zu können, ob du erhöhen oder folden sollst, musst du eins der wichtigsten Konzepte beim Poker verstehen: die Position.
<G-vec00106-002-s267><decide.entscheiden><en> You will have to decide for yourself, whether you will want to raise loosely, tightly or just the average amount in any situation that presents itself to you.
<G-vec00106-002-s267><decide.entscheiden><de> Du musst selbst entscheiden können, ob du in einer dir gegebenen Situation lieber loose, tight oder durchschnittlich viel raisen möchtest.
<G-vec00106-002-s268><decide.entscheiden><en> We have a great responsibility because we can all decide – no matter our upbringing or ancestors – wether we want to be a Jonathan Edwards or a Max Jukes.
<G-vec00106-002-s268><decide.entscheiden><de> Wir haben eine große Verantwortung, weil wir alle entscheiden können – egal wie wir aufgewachsen sind und was unsere Vorfahren getan oder nicht getan haben.
<G-vec00106-002-s269><decide.entscheiden><en> Here are some tips to help you set realistic expectations and decide which model is right for you.
<G-vec00106-002-s269><decide.entscheiden><de> Hier finden Sie einige Tipps, mit denen Sie realistische Erwartungen festlegen und entscheiden können, welches Modell für Sie das Richtige ist.
<G-vec00106-002-s270><decide.entscheiden><en> You can set your browser to notify you when you receive a cookie, giving you the chance to decide whether to accept it.
<G-vec00106-002-s270><decide.entscheiden><de> Sie können Ihren Browser so einrichten, dass Sie beim Empfang eines Cookies benachrichtigt werden und so entscheiden können, ob Sie den Cookie annehmen oder ablehnen.
<G-vec00106-002-s271><decide.entscheiden><en> National populations will only be able to recognize and decide what is in their own respective interests in the long run when we begin to discuss– far beyond the bounds of academic journals – the far-reaching alternatives between abandoning the euro, or else returning to a currency system allowing for a limited margin of fluctuation, or indeed opting for closer cooperation.
<G-vec00106-002-s271><decide.entscheiden><de> Die nationalen Bevölkerungen werden nur erkennen und entscheiden können, was längerfristig auch im jeweils eigenen Interesse liegt, wenn die folgenreichen Alternativen zwischen einer Rückabwicklung des Euro oder der Rückkehr zur einem Währungssystem begrenzter Schwankungsbreiten oder eben doch einer engeren Kooperation nicht mehr nur in akademischen Zeitschriften diskutiert werden.
<G-vec00106-002-s272><decide.entscheiden><en> Here we take a look at those pros and cons, to help you decide where to take your career in asset management.
<G-vec00106-002-s272><decide.entscheiden><de> Hier finden Sie einige Vor- und Nachteile, sodass Sie entscheiden können, wo Sie Ihre Karriere als Asset Manager beginnen möchten.
<G-vec00106-002-s273><decide.entscheiden><en> Landscape ecologists at the Helmholtz Centre for Environmental Research (UFZ) in Leipzig have designed the computer game LandYOUs, which allows players to decide how much of the national budget they wish to invest in nature conservation, education, reforestation, urban development and farming subsidies.
<G-vec00106-002-s273><decide.entscheiden><de> Am Helmholtz-Zentrum für Umweltforschung – UFZ in Leipzig haben Landschaftsökologen das Spiel LandYOUs entworfen, bei dem Spieler entscheiden können, wie viel Geld des Staatsbudgets sie in Naturschutz, Bildung, Aufforstung, Stadtentwicklung und die Förderung der Landwirtschaft investieren wollen.
<G-vec00106-002-s274><decide.entscheiden><en> If you can not decide which decor is right for you, you can order the Tilo Vinyl Design sample portfolio.
<G-vec00106-002-s274><decide.entscheiden><de> Sollten Sie sich überhaupt nicht entscheiden können, welches Dekor für Sie in frage kommt, können Sie die Tilo Vinyl Design-Mustermappe bestellen.
<G-vec00106-002-s275><decide.entscheiden><en> The new solution offers customers more payment flexibility, allowing them to decide whether their credit card data shall be stored by Wirecard for separate one-click-payments or recurring payments on a monthly basis.
<G-vec00106-002-s275><decide.entscheiden><de> Die neue Lösung bietet Kunden mehr Flexibilität, da sie entscheiden können, ob ihre Kreditkartendaten von Wirecard für separate 1-Click-Zahlungen oder für monatlich wiederkehrende Zahlungen gespeichert werden sollen.
<G-vec00106-002-s276><decide.entscheiden><en> This will help you retain your data, letting you decide what to do before selling iPad or iPhone.
<G-vec00106-002-s276><decide.entscheiden><de> Dies wird Ihnen dabei helfen, Ihre Daten zu behalten, so dass Sie entscheiden können, was Sie vor dem Verkauf von iPad oder iPhone tun wollen.
<G-vec00106-002-s277><decide.entscheiden><en> Another method that allows you to decide how to communicate with the child, Gippenreiter Yu.B.
<G-vec00106-002-s277><decide.entscheiden><de> Eine andere Methode, mit der Sie entscheiden können, wie Sie mit dem Kind kommunizieren möchten, Gippenreiter Yu.B.
<G-vec00106-002-s278><decide.entscheiden><en> This mouthpiece is manufactured in Europe and made of high quality leather and has an adjustable belt buckle so you decide how tight or loose he sits.
<G-vec00106-002-s278><decide.entscheiden><de> Dieses Mundstück wird in Europa hergestellt und besteht aus hochwertigem Leder und hat eine verstellbare Gürtelschnalle, so dass Sie entscheiden können, wie eng oder locker er sitzt.
<G-vec00106-002-s279><decide.entscheiden><en> We’ll cover what tasks you can outsource, the pros and cons of outsourcing, and how to decide if outsourcing is right for your business.
<G-vec00106-002-s279><decide.entscheiden><de> Wir besprechen, welche Aufgaben Sie auslagern können, welche Vor- und Nachteile das Outsourcing hat und wie Sie entscheiden können, ob das Outsourcing für Ihr Unternehmen richtig ist.
<G-vec00106-002-s280><decide.entscheiden><en> This guarantees that the remaining shareholders retain the sole authority to decide on these matters, especially those that pertain to the supervision of management.
<G-vec00106-002-s280><decide.entscheiden><de> So ist gewährleistet, dass die übrigen Aktionäre über diese Fragen, die insbesondere die Kontrolle der Geschäftsführung betreffen, allein entscheiden können.
<G-vec00106-002-s281><decide.entscheiden><en> They can objectively tell you about the condition of the vessel before you decide whether or not to spend your time to look at the boat.
<G-vec00106-002-s281><decide.entscheiden><de> Er kann Ihnen ganz objektiv über den Zustand des Bootes berichten, sodass Sie entscheiden können, ob sich eine Besichtigung lohnt.
<G-vec00106-002-s282><decide.entscheiden><en> If you want to have control over your computer and the information is stored by means of cookies, you need this simple program with which to decide in a quick fashion which cookies you are interested in and which ones you aren't.
<G-vec00106-002-s282><decide.entscheiden><de> Wenn Sie die Kontrolle über Ihren Computer haben möchten und über die Informationen, die via Cookies gespeichert sind, brauchen Sie dieses einfache Programm, mit dem Sie ganz schnell entscheiden können, an welchen Cookies Sie interessiert sind und an welchen nicht.
<G-vec00106-002-s283><decide.entscheiden><en> If you're concerned that the filesystem status is reported as "Clean" or "Dirty", learn how to use cvfsck to decide if you need to make a repair.
<G-vec00106-002-s283><decide.entscheiden><de> Wenn Sie sich nicht sicher sind, was es bedeutet, wenn der Status des Dateisystems als "Clean" (sauber) oder "Dirty" (unsauber) angegeben wird, erfahren Sie hier, wie Sie mit cvfsck entscheiden können, ob eine Reparatur notwendig ist.
<G-vec00106-002-s284><decide.entscheiden><en> You have to be friends with people you trust 100% to plan anything dangerous, you have to be aware and informed about anything that is happening in this world to decide what the proper course of action is, you have to be crazy and enthusiastic, to feel that you can do incredible things—you have to be ready to give your life, your time, your years in a struggle that will never end.
<G-vec00106-002-s284><decide.entscheiden><de> Du musst mit den Leuten befreundet sein und ihnen 100% trauen, um irgendwas gefährliches zu planen, du musst dir über alles was in der Welt vorgeht im Klaren sein, informiert sein, um entscheiden zu können, was der entsprechende Verlauf einer Aktion ist, du musst verrückt und begeistert sein, um zu spüren, dass du unglaubliche Dinge tun kannst - du musst bereit sein dein Leben, deine Zeit, deine Jahre in einem Kampf zu geben, der nie enden wird.
<G-vec00106-002-s285><decide.entscheiden><en> Neck Construction: product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s285><decide.entscheiden><de> Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s286><decide.entscheiden><en> You can also decide on which side the viewing opening should be, ensuring an ideal fit for your shelving system.
<G-vec00106-002-s286><decide.entscheiden><de> Außerdem können Sie entscheiden, ob sich die Öffnung an der Stirnseite oder an Längsseite befinden soll.
<G-vec00106-002-s287><decide.entscheiden><en> As moderator you are opening the conference and you decide who is able to speak.
<G-vec00106-002-s287><decide.entscheiden><de> Als Moderator eröffnen Sie die Konferenz und entscheiden, ob die Mikrophone der Teilnehmer stumm oder laut sind.
<G-vec00106-002-s288><decide.entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s288><decide.entscheiden><de> Mittlerer Stärke Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s289><decide.entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s289><decide.entscheiden><de> VideoMic Pro Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s290><decide.entscheiden><en> You can decide how much sunlight shines through by choosing slightly transparent or completely opaque fabrics.
<G-vec00106-002-s290><decide.entscheiden><de> Sie entscheiden, ob der Stoff leicht transparent oder komplett blickdicht ist und wie viel Sonne somit durchscheinen darf.
<G-vec00106-002-s293><decide.entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s293><decide.entscheiden><de> Dropring Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s294><decide.entscheiden><en> Option 3 is similar to Option 2 but leaves some flexibility to Member States that can decide to apply the exception depending on the availability of licences.
<G-vec00106-002-s294><decide.entscheiden><de> Option 3 ähnelt Option 2, sieht jedoch eine gewisse Flexibilität für die Mitgliedstaaten vor, die je nach Verfügbarkeit von Lizenzen entscheiden können, ob sie die Ausnahme anwenden.
<G-vec00106-002-s295><decide.entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s295><decide.entscheiden><de> Ashton Addario ® Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s296><decide.entscheiden><en> Type: is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s296><decide.entscheiden><de> Typ: Ausgerichtet Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s297><decide.entscheiden><en> From this point, you should be able to scan through all the retrieved information and decide to keep them all or just pick which ones that you prefer to keep.
<G-vec00106-002-s297><decide.entscheiden><de> Von diesem Punkt an sollten Sie in der Lage sein, alle abgerufenen Informationen zu durchsuchen und zu entscheiden, ob Sie alle behalten oder nur auswählen möchten, welche Sie lieber behalten möchten.
<G-vec00106-002-s298><decide.entscheiden><en> He doesn’t have to decide it is one or the other.
<G-vec00106-002-s298><decide.entscheiden><de> Er muss nicht entscheiden ob es das eine oder das andere ist.
<G-vec00106-002-s299><decide.entscheiden><en> As is already the case for physical ballots, a court would then decide on the merits of the case and what measures should be initiated.
<G-vec00106-002-s299><decide.entscheiden><de> Ein Gericht müsste dann – so wie heute bereits für physische Urnengänge – entscheiden, ob es die Anfechtung gutheisst und welche Maßnahmen abzuleiten sind.
<G-vec00106-002-s300><decide.entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s300><decide.entscheiden><de> Power Supply PS0913B Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s302><decide.entscheiden><en> If you're switching from Clutter to Focused Inbox, they can decide to enable it (“Try it”) or dismiss the feature.
<G-vec00106-002-s302><decide.entscheiden><de> Wenn Sie von "Clutter" zum Posteingang mit Relevanz wechseln, können sie entscheiden, ob sie ihn aktivieren ("Testen") oder das Feature schließen möchten.
<G-vec00106-002-s303><decide.entscheiden><en> Once the product is delivered, you have 60 days to decide that you definitely want to keep it.
<G-vec00106-002-s303><decide.entscheiden><de> Kunststoff Hardcase Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s304><decide.entscheiden><en> They now can decide when to hunt and to kill animals for meat.
<G-vec00106-002-s304><decide.entscheiden><de> Sie entscheiden selbst, wieviele Tiere sie zur Fleischgewinnung jagen dürfen.
<G-vec00106-002-s305><decide.entscheiden><en> You decide how spicy your drink should be: measure out the quantity of juice or water that Dr. Muche's liquid ginger is to be added to.
<G-vec00106-002-s305><decide.entscheiden><de> Sie entscheiden selbst, wie scharf Ihr Getränk schmecken soll: Dosieren Sie die Menge an Saft oder Wasser, in die Sie Dr. Muches Ingwertropfen geben.
<G-vec00106-002-s306><decide.entscheiden><en> However, it is up to the employees at the workplace to decide how their representatives should be chosen.
<G-vec00106-002-s306><decide.entscheiden><de> Die Beschäftigten entscheiden selbst, wie ihre Vertreter ausgewählt werden.
<G-vec00106-002-s307><decide.entscheiden><en> Concealed blade, fully automatic blade retraction or automatic blade retraction - you decide which MARTOR safety technology fits best to your requirements for cutting safety in the workplace. Play
<G-vec00106-002-s307><decide.entscheiden><de> Verdeckt liegende Klinge, vollautomatischer oder automatischer Klingenrückzug – entscheiden Sie selbst, welche MARTOR-Sicherheitstechnik am besten zu Ihren Bedürfnissen, vor allem im Bereich Arbeitsschutz und Arbeitssicherheit, passt.
<G-vec00106-002-s308><decide.entscheiden><en> With Klarna part payment you decide every month how much you want to pay.
<G-vec00106-002-s308><decide.entscheiden><de> Mit Klarna Ratenkauf entscheiden Sie selbst jeden Monat aufs Neue, wieviel Sie bezahlen möchten.
<G-vec00106-002-s309><decide.entscheiden><en> You decide how often and when you want to learn.
<G-vec00106-002-s309><decide.entscheiden><de> Sie entscheiden selbst, wie oft und wann Sie lernen möchten.
<G-vec00106-002-s310><decide.entscheiden><en> By entering your data you decide voluntarily what data we receive about your company or yourself.
<G-vec00106-002-s310><decide.entscheiden><de> Mit der Dateneingabe entscheiden Sie selbst, welche Daten wir von Ihnen über Ihr Unternehmen oder Sie erhalten.
<G-vec00106-002-s311><decide.entscheiden><en> The Convention on Human Rights and Biomedicine serves as a framework convention: While the Parties to the Convention have committed themselves to complying with the provisions set forth in the treaty, they are free to decide what kind of measures are needed at the national level to do so.
<G-vec00106-002-s311><decide.entscheiden><de> Das Übereinkommen über Menschenrechte und Biomedizin dient seinen Vertragsstaaten als Rahmenabkommen: Sie verpflichten sich rechtlich zur Einhaltung der in der Konvention festgehaltenen Bedingungen, entscheiden aber selbst, welche Maßnahmen auf nationaler Ebene dafür notwendig sind.
<G-vec00106-002-s312><decide.entscheiden><en> It is for you to decide how much you are prepared to spend on dental care.
<G-vec00106-002-s312><decide.entscheiden><de> Entscheiden sie selbst, was Sie für Ihre Behandlung ausgeben möchten.
<G-vec00106-002-s313><decide.entscheiden><en> From now on it is up to you to decide whether you wish to prepare a monochrome or color texture scan.
<G-vec00106-002-s313><decide.entscheiden><de> Von nun an entscheiden Sie selbst, ob Sie einen monochromen oder farbigen Texturscan vorbereiten möchten.
<G-vec00106-002-s314><decide.entscheiden><en> After 12 months, you decide whether you wish to renew the service.
<G-vec00106-002-s314><decide.entscheiden><de> Nach 12 Monaten entscheiden Sie selbst, ob Sie diesen Service verlängern möchten.
<G-vec00106-002-s315><decide.entscheiden><en> After your show ends, head out of the theater, and decide what you’d like to do next.
<G-vec00106-002-s315><decide.entscheiden><de> Nach der Vorstellung verlassen Sie das Theater und entscheiden selbst, was Sie als Nächstes tun möchten.
<G-vec00106-002-s316><decide.entscheiden><en> You decide where your data are saved.
<G-vec00106-002-s316><decide.entscheiden><de> Sie entscheiden selbst, wo Ihre Daten liegen.
<G-vec00106-002-s317><decide.entscheiden><en> Like learning any skill, it is up to you to decide how far you want to develop it.
<G-vec00106-002-s317><decide.entscheiden><de> Wie beim Erlernen einer jeden Fertigkeit, entscheiden Sie selbst, wie weit Sie diese entwickeln wollen.
<G-vec00106-002-s318><decide.entscheiden><en> In this programme you can decide exactly what you want to learn.
<G-vec00106-002-s318><decide.entscheiden><de> In diesem Programm entscheiden Sie selbst, was Sie lernen wollen.
<G-vec00106-002-s319><decide.entscheiden><en> You decide what you want to paint and on what level.
<G-vec00106-002-s319><decide.entscheiden><de> Sie entscheiden selbst was Sie auf Ihrer eigenen Ebene malen möchten.
<G-vec00106-002-s320><decide.entscheiden><en> You decide at the touch of a button if you want to control the car with the remote control or if the child takes control of it.
<G-vec00106-002-s320><decide.entscheiden><de> Sie entscheiden per Knopfdruck, ob Sie mit der Fernbedienung das Auto steuern möchten oder ob das Kind selbst die Steuerung übernimmt.
<G-vec00106-002-s321><decide.entscheiden><en> They try everything and decide whether or not they like it for themselves.
<G-vec00106-002-s321><decide.entscheiden><de> Sie probieren alles und entscheiden selbst, ob es ihnen schmeckt.
<G-vec00106-002-s322><decide.entscheiden><en> In the information section of RSS, you can decide which messages you want to receive.
<G-vec00106-002-s322><decide.entscheiden><de> Bei der Informationssuche über RSS entscheiden Sie selbst, welche Mitteilungen Sie erhalten wollen.
<G-vec00106-002-s323><decide.entscheiden><en> You decide to add a +20% bid adjustment for California, and a -50% adjustment for Saturday.
<G-vec00106-002-s323><decide.entscheiden><de> Sie entscheiden sich für eine Gebotsanpassung von +20 % für Bayern und eine Anpassung von -50 % für Samstag.
<G-vec00106-002-s324><decide.entscheiden><en> If you have to go to hospital, when being admitted you can decide whether you want to stay on a semi-private, comfort single or twin room on the general ward or on the general ward.
<G-vec00106-002-s324><decide.entscheiden><de> Müssen Sie ins Spital, entscheiden Sie sich bei Eintritt, ob Sie halbprivat, komfortabel im Ein- oder Zweibettzimmer in der allgemeinen Abteilung oder allgemein liegen möchten.
<G-vec00106-002-s325><decide.entscheiden><en> With Sinteso, you decide for fire safety that is always by your side – protecting you in the present and in the future.
<G-vec00106-002-s325><decide.entscheiden><de> Mit Sinteso entscheiden Sie sich für einen Brandschutz, der Ihnen immer zuverlässig zur Seite steht – heute wie morgen.
<G-vec00106-002-s326><decide.entscheiden><en> For example, you decide to purchase a Call option for XYZ stock because you heard in a financial news report that the stocks are looking to rise.
<G-vec00106-002-s326><decide.entscheiden><de> So entscheiden Sie sich zum Beispiel zum Kauf einer Kaufoption der Aktie XYZ, weil Sie in den Finanznachrichten gehört haben, dass die Aktien voraussichtlich steigen werden.
<G-vec00106-002-s327><decide.entscheiden><en> See for yourself and see you into our products of wood and decide you for trying out these appear for you at the most suitable for you.
<G-vec00106-002-s327><decide.entscheiden><de> Überzeugen Sie sich selbst und sehen Sie sich unsere Produkte aus Holz an und entscheiden Sie sich für das Ausprobieren des Puzzles oder Holzspiel welches für Sie am besten geeignet scheint.
<G-vec00106-002-s328><decide.entscheiden><en> Often, the owners of a private house decide to plant evergreen conifers in the form of bushes and trees.
<G-vec00106-002-s328><decide.entscheiden><de> Oft entscheiden sich die Eigentümer eines Privathauses, immergrüne Nadelbäume in Form von Büschen und Bäumen zu pflanzen.
<G-vec00106-002-s329><decide.entscheiden><en> Frequently, small organizations decide not to use a third-party certificate or not to install their own PKI to issue their own certificates.
<G-vec00106-002-s329><decide.entscheiden><de> Kleine Organisationen entscheiden sich häufig gegen die Verwendung eines Drittanbieterzertifikats oder die Installation einer eigenen PKI zur Ausstellung eigener Zertifikate.
<G-vec00106-002-s330><decide.entscheiden><en> When individuals and couples are given a real choice, many decide to have smaller, healthier families and invest more in each child’s future.
<G-vec00106-002-s330><decide.entscheiden><de> Wenn Personen und Paare vor eine wirkliche Wahl gestellt werden, entscheiden sich viele für kleinere, gesündere Familien und investieren in die Zukunft jedes Kindes.
<G-vec00106-002-s331><decide.entscheiden><en> Many couples decide to have their wedding day in Prague.
<G-vec00106-002-s331><decide.entscheiden><de> Viele Paare entscheiden sich sogar für eine Hochzeit in Prag.
<G-vec00106-002-s332><decide.entscheiden><en> The players decide who will dig in the mountains for gold and who will pan in the rivers.
<G-vec00106-002-s332><decide.entscheiden><de> Die Spieler entscheiden sich, wer in den Bergen und wer in den Flüssen nach Gold schürfen will.
<G-vec00106-002-s333><decide.entscheiden><en> Basically, namely, every human is fully responsible for himself, consequently he - if he makes the effort - can decide for himself how his life should develop.
<G-vec00106-002-s333><decide.entscheiden><de> Grundsätzlich nämlich ist jeder Mensch in vollem Umfang für sich selbst verantwortlich, folglich er sich - wenn er sich bemüht - selbst entscheiden kann, wie sich sein Leben entwickeln soll.
<G-vec00106-002-s334><decide.entscheiden><en> Many students decide to live in Colmar for the first semester in order to immerse themselves completely in the local culture - and this is highly appreciated.
<G-vec00106-002-s334><decide.entscheiden><de> Viele Studierende entscheiden sich das erste Semester in Colmar zu wohnen, um komplett in die Kultur einzutauchen - und das wird sehr geschätzt.
<G-vec00106-002-s335><decide.entscheiden><en> Many couples still decide for marriage.
<G-vec00106-002-s335><decide.entscheiden><de> Nach wie vor entscheiden sich viele Paare für eine Eheschließung.
<G-vec00106-002-s336><decide.entscheiden><en> You decide before the beginning of your medical journey for one of our Service Levels.
<G-vec00106-002-s336><decide.entscheiden><de> Sie entscheiden sich vor Beginn Ihrer medizinischen Reise für eines unserer Service-Levels.
<G-vec00106-002-s337><decide.entscheiden><en> Many will later decide to study in their former host country and some of them even will even work there.
<G-vec00106-002-s337><decide.entscheiden><de> Viele entscheiden sich später, im jeweiligen Gastland zu studieren und manche sogar dort zu arbeiten.
<G-vec00106-002-s338><decide.entscheiden><en> Elzie and Ovella decide not to join the traveling show and walk home.
<G-vec00106-002-s338><decide.entscheiden><de> Elzie und Ovella entscheiden sich nicht, sich der Wanderausstellung anzuschließen und nach Hause zu gehen.
<G-vec00106-002-s339><decide.entscheiden><en> Many young foreign entrepreneurs decide for the capital city, a perceptible development which last but not least can be attributed to the annual PIONEERS Festival.
<G-vec00106-002-s339><decide.entscheiden><de> Auch viele ausländische Jungunternehmer entscheiden sich für die Hauptstadt, was nicht zuletzt durch das alljährliche PIONEERS Festival zu spüren ist.
<G-vec00106-002-s340><decide.entscheiden><en> Inspiration After a romantic proposal, the newly engaged couple – full of anticipation – start to plan their dream wedding – many decide on a colour palette that runs through the whole wedding.
<G-vec00106-002-s340><decide.entscheiden><de> Inspiration Nach einem romantischen Heiratsantrag beginnen die frisch Verlobten, voller Vorfreude ihre Traumhochzeit zu planen – viele entscheiden sich von Anfang an für ein konkretes Farbmotto, das sich wie ein roter Faden durch die Hochzeit zieht.
<G-vec00106-002-s341><decide.entscheiden><en> Decide for yourself, what the issue is at hand, and do not let others undermine you.
<G-vec00106-002-s341><decide.entscheiden><de> Entscheiden Sie selbst, um was es gerade geht, und lassen Sie sich darin nicht beirren.
<G-vec00106-002-s342><decide.entscheiden><en> Decide what car you want to drive in the city of Thessaloniki Airport to find out daily average cost.
<G-vec00106-002-s342><decide.entscheiden><de> Entscheiden Sie, welches Auto Sie in der Stadt Bourgas Flughafen fahren möchten, um die durchschnittlichen Tageskosten herauszufinden.
<G-vec00106-002-s343><decide.entscheiden><en> Decide what car you want to drive in the city of Clermont Ferrand Airport to find out daily average cost.
<G-vec00106-002-s343><decide.entscheiden><de> Entscheiden Sie, welches Auto Sie in der Stadt Kalakaua Allee fahren möchten, um die durchschnittlichen Tageskosten herauszufinden.
<G-vec00106-002-s344><decide.entscheiden><en> Decide which profiling method suits your needs.
<G-vec00106-002-s344><decide.entscheiden><de> Entscheiden Sie, welche Methode der Profilerstellung Ihren Anforderungen entspricht.
<G-vec00106-002-s345><decide.entscheiden><en> •Decide whether you want to work with ODBC tables interactively in the relationships graph or through "static" ODBC imports.
<G-vec00106-002-s345><decide.entscheiden><de> •Entscheiden Sie, ob Sie mit ODBC-Tabellen interaktiv im Beziehungsdiagramm arbeiten oder „statische“ ODBC-Importe verwenden möchten.
<G-vec00106-002-s346><decide.entscheiden><en> First decide how and/or why you’d like to include an annotation and add it to your slide.
<G-vec00106-002-s346><decide.entscheiden><de> Zuerst entscheiden Sie, wie und/oder Warum können Sie eine Anmerkung enthalten und Ihrer Folie hinzufügen.
<G-vec00106-002-s347><decide.entscheiden><en> Decide individually on site.
<G-vec00106-002-s347><decide.entscheiden><de> Entscheiden Sie individuell vor Ort.
<G-vec00106-002-s348><decide.entscheiden><en> Please decide at this point how and where you wish the doors to be assembled and follow the appropriate diagram.
<G-vec00106-002-s348><decide.entscheiden><de> Bitte entscheiden Sie zu diesem Zeitpunkt, wie und wo Sie die Türen einbauen wollen und halten Sie sich an die entsprechende Grafik.
<G-vec00106-002-s349><decide.entscheiden><en> Decide on anything that has to do with strategy and playing style.
<G-vec00106-002-s349><decide.entscheiden><de> Entscheiden Sie alles, was mit Strategie und Spielstil zu tun hat.
<G-vec00106-002-s350><decide.entscheiden><en> Thoroughly consider and decide as early as possible within the acquiring company how to involve leadership and employees from the target company in the project organisation.
<G-vec00106-002-s350><decide.entscheiden><de> Überlegen und entscheiden Sie innerhalb des Erwerberunternehmens sorgfältig und so früh wie möglich, wie Management und Mitarbeitende des Zielunternehmens in die Projektorganisation eingebunden werden.
<G-vec00106-002-s351><decide.entscheiden><en> Instruction one Decide how ready your child is for the trip.
<G-vec00106-002-s351><decide.entscheiden><de> Anweisung 1 Entscheiden Sie, wie bereit Ihr Kind für die Reise ist.
<G-vec00106-002-s352><decide.entscheiden><en> Social media accounts to show: Decide which accounts shall appear on the page.
<G-vec00106-002-s352><decide.entscheiden><de> Social Media-Accounts anzeigen: Entscheiden Sie welche Accounts in der Ansicht erscheinen sollen.
<G-vec00106-002-s353><decide.entscheiden><en> Select it and decide whether you would like this information once or as a subscription.
<G-vec00106-002-s353><decide.entscheiden><de> Wählen Sie dieses an und entscheiden Sie, ob Sie diese Information einmalig oder im Abonnement erhalten möchten.
<G-vec00106-002-s354><decide.entscheiden><en> You can read the description below and decide which one you prefer.
<G-vec00106-002-s354><decide.entscheiden><de> Lesen Sie die folgende Beschreibung und entscheiden Sie, welche Tickets Sie bevorzugen.
<G-vec00106-002-s355><decide.entscheiden><en> Spam detection: Decide whether a given email is spam or not.
<G-vec00106-002-s355><decide.entscheiden><de> Spam-Erkennung: Entscheiden Sie, ob eine bestimmte E-Mail Spam ist oder nicht.
<G-vec00106-002-s356><decide.entscheiden><en> Decide which headline goes with which text, choosing from the two options given.
<G-vec00106-002-s356><decide.entscheiden><de> Entscheiden Sie, welcher Titel zu welchem Text gehört; wählen Sie zwischen den zwei Vorschlägen aus.
<G-vec00106-002-s357><decide.entscheiden><en> Decide on what breeds you like, and look through the help groups for these breeds in search of a suitable option.
<G-vec00106-002-s357><decide.entscheiden><de> Antwort №9: Entscheiden Sie, was Sie züchten, und schauen Sie durch die Hilfegruppen für diese Rassen auf der Suche nach einer geeigneten Option.
<G-vec00106-002-s358><decide.entscheiden><en> Decide which park you like best.
<G-vec00106-002-s358><decide.entscheiden><de> Entscheiden Sie, welcher Park Ihnen am besten gefällt.
<G-vec00106-002-s359><decide.entscheiden><en> - Decide when and where it makes sense to use React, and when to rethink the conventional MVC model.
<G-vec00106-002-s359><decide.entscheiden><de> - Entscheiden Sie, wann und wo die Verwendung von React sinnvoll ist und wann Sie das herkömmliche MVC-Modell überdenken müssen.
<G-vec00106-002-s360><decide.entscheiden><en> This means that you can find out for free what you’re owed and then decide if you want to proceed.
<G-vec00106-002-s360><decide.entscheiden><de> Das heißt, dass Sie kostenlos herausfinden können, was Ihnen geschuldet wird, und anschließend entscheiden Sie, ob Sie mit dem Vorgang fortfahren möchten.
<G-vec00106-002-s361><decide.entscheiden><en> Practically we decide for the nearest goodies, a steep northern slope down the eastern ridge of Annalper Joch.
<G-vec00106-002-s361><decide.entscheiden><de> Praktisch entscheiden wir uns für das kürzeste Schmankerl, einen steilen Nordhang vom östlichen Grat des Annalper Jochs hinunter.
<G-vec00106-002-s362><decide.entscheiden><en> As we see it’s not raining anymore we decide to drive to the city centre yet again.
<G-vec00106-002-s362><decide.entscheiden><de> Wir sehen, dass es jetzt nicht mehr regnet, und so entscheiden wir uns, doch noch in die Innenstadt zu fahren.
<G-vec00106-002-s363><decide.entscheiden><en> The change appeals to us, and we decide to fly there.
<G-vec00106-002-s363><decide.entscheiden><de> Die Abwechslung reizt uns, und wir entscheiden uns, dorthin zu fliegen.
<G-vec00106-002-s364><decide.entscheiden><en> This giant consumer goods fair spans eleven buildings, which we decide to attack from the rear. read more ›
<G-vec00106-002-s364><decide.entscheiden><de> Die riesige Konsumgütermesse erstreckt sich über elf Gebäude, und wir entscheiden uns dazu, das Feld von hinten aufzurollen.
<G-vec00106-002-s365><decide.entscheiden><en> We decide to stop in Sant Feliu de Guíxols for the night.
<G-vec00106-002-s365><decide.entscheiden><de> Wir entscheiden uns in Sant Feliu de Guíxols eine Halt für die Nacht einzulegen.
<G-vec00106-002-s366><decide.entscheiden><en> At this point, we decide to leave, as we don’t want to spoil the wonderful feeling we had when it was still early and nobody was in the garden alongside us.
<G-vec00106-002-s366><decide.entscheiden><de> Hier entscheiden wir uns, zu gehen, denn wir möchten uns die Magie, die dieser Garten auf uns hat übergehen lassen, nicht mehr nehmen lassen.
<G-vec00106-002-s367><decide.entscheiden><en> We decide to stay in the camp.
<G-vec00106-002-s367><decide.entscheiden><de> Wir entscheiden uns im Camp zu bleiben.
<G-vec00106-002-s368><decide.entscheiden><en> We are on the verge of robbing all the chocolate shops, but then decide to go for an original Belgian waffle.
<G-vec00106-002-s368><decide.entscheiden><de> Wir sind kurz davor, sämtliche Schokoladen-Läden auszurauben, entscheiden uns dann aber für eine original belgische Waffel.
<G-vec00106-002-s369><decide.entscheiden><en> We decide to return to Banff (the campground in Lake Louise is right next to the railway tracks) and simply sit tight for a day, because by all means we want to see the Icefields Parkway to Jasper in nice weather.
<G-vec00106-002-s369><decide.entscheiden><de> Wir entscheiden uns, nach Banff zurückzukehren (der Campground in Lake Louise liegt unmittelbar neben den Bahnschienen) und einfach einen Tag zu abzuwarten, denn den Icefields Parkway nach Jasper wollen wir unbedingt bei schönem Wetter erleben.
<G-vec00106-002-s370><decide.entscheiden><en> Zoom We browser the stands and decide to try on a dirndl and some lederhosen.
<G-vec00106-002-s370><decide.entscheiden><de> Zoom Wir stöbern am Ständer und entscheiden uns, in ein Dirndl und eine Lederhose zu schlüpfen.
<G-vec00106-002-s371><decide.entscheiden><en> You decide our level of involvement with your team so that your systems work properly.
<G-vec00106-002-s371><decide.entscheiden><de> Sie entscheiden, bis zu welchem Level wir uns mit Ihrem Team involvieren.
<G-vec00106-002-s372><decide.entscheiden><en> We make it ten kilometer far, in three or four hours, and decide to wait until the evening.
<G-vec00106-002-s372><decide.entscheiden><de> Wir kommen zehn Kilometer weit, in drei oder vier Stunden, und entscheiden uns bis zum Abend zu warten.
<G-vec00106-002-s373><decide.entscheiden><en> After a thorough examination and lengthy discussion, Dr. Greene and I decide on the mini pill.
<G-vec00106-002-s373><decide.entscheiden><de> Nach einer sorgfältigen Untersuchung und einem ausführlichen Gespräch entscheiden Dr. Greene und ich uns für die Minipille.
<G-vec00106-002-s374><decide.entscheiden><en> We decide to go to Kelly Lake, and agree upon $1,500 Can for the flight.
<G-vec00106-002-s374><decide.entscheiden><de> Wir entscheiden uns für den Kelly Lake, und vereinbaren für den Flug inklusive Kanu 1.500 Can.$.
<G-vec00106-002-s375><decide.entscheiden><en> As we understand the words, we decide whether we agree or disagree with the sentiments and ideas expressed through those words.
<G-vec00106-002-s375><decide.entscheiden><de> Wenn wir die Worte verstehen entscheiden wir uns, ob wir den Meinungen und Ideen zustimmen oder nicht, die durch diese Worte ausgedrückt werden.
<G-vec00106-002-s376><decide.entscheiden><en> As the weather gets more and more beautiful, we decide to take the path over the Silvretta High Alpine Road.
<G-vec00106-002-s376><decide.entscheiden><de> Bei immer schöner werdendem Wetter, entscheiden wir uns für den Weg über die Silvretta Hochalpenstraße.
<G-vec00106-002-s377><decide.entscheiden><en> Even though a thunderstorm is building up we decide to do the hike.
<G-vec00106-002-s377><decide.entscheiden><de> Trotz dem drohenden Gewitter entscheiden wir uns, auf den Berg zu wandern.
<G-vec00106-002-s378><decide.entscheiden><en> We decide on this therapy in cases where standard physical therapy has not been sufficiently successful.
<G-vec00106-002-s378><decide.entscheiden><de> Wir entscheiden uns für diese Therapie, nachdem die standardisierte physikalische Therapie keine zufriedenstellenden Ergebnisse brachte.
<G-vec00106-002-s379><decide.entscheiden><en> Thus, we decide to flee to Teheran.
<G-vec00106-002-s379><decide.entscheiden><de> Somit entscheiden wir uns für die Flucht nach Teheran.
<G-vec00106-002-s380><decide.entscheiden><en> The various German Design Council panels of experts will decide which organisations are eligible to enter the competition.
<G-vec00106-002-s380><decide.entscheiden><de> Die Expertengremien des Rat für Formgebung entscheiden über die Zulassung zum Wettbewerb.
<G-vec00106-002-s381><decide.entscheiden><en> There they are examined in detail, and doctors decide the issue of the term of their delivery.
<G-vec00106-002-s381><decide.entscheiden><de> Dort werden sie im Detail untersucht, und Ärzte entscheiden über die Frage der Laufzeit ihrer Lieferung.
<G-vec00106-002-s382><decide.entscheiden><en> The white proletariat and the Boer farmers form the base of apartheid - they decide the destiny of South Africa today.
<G-vec00106-002-s382><decide.entscheiden><de> Das weisse Proletariat und die Burenfarmer bilden die Basis der Apartheid, sie entscheiden heute über das Schicksal Südafrikas.
<G-vec00106-002-s383><decide.entscheiden><en> “As you explore the furthest reaches of space and encounter various factions, all vying for power, the character you decide to become will determine how this player-driven story unfolds.
<G-vec00106-002-s383><decide.entscheiden><de> Während die Spieler die äußersten Gebiete des Weltraums erkunden und auf verschiedene, machthungrige Fraktionen treffen, entscheiden sie mit dem von ihnen entwickelten Charakter über den Verlauf der spielergetriebenen Handlung.
<G-vec00106-002-s384><decide.entscheiden><en> There are many factors that decide the overall efficiency of a compressed air station.
<G-vec00106-002-s384><decide.entscheiden><de> Viele Punkte entscheiden über die gesamte Energieeffizienz einer Druckluftanlage.
<G-vec00106-002-s385><decide.entscheiden><en> At the start of the agreement you decide the length of the agreement and any options, such as service agreements or care agreements.
<G-vec00106-002-s385><decide.entscheiden><de> Zu Beginn des Vertrags entscheiden Sie über die Vertragslaufzeit und alle Optionen, wie zum Beispiel die Servicevereinbarungen oder Wartungsvereinbarungen.
<G-vec00106-002-s386><decide.entscheiden><en> In many cases, flawless, residue-free surfaces decide the quality of modern products.
<G-vec00106-002-s386><decide.entscheiden><de> Makellose, rückstandsfreie Oberflächen entscheiden daher in vielen Fällen über die Qualität moderner Produkte.
<G-vec00106-002-s387><decide.entscheiden><en> In a few days, the British will decide whether or not they want to stay in the EU.
<G-vec00106-002-s387><decide.entscheiden><de> Die Folgen für die Wissenschaft In wenigen Tagen entscheiden die Briten über den Verbleib in der EU.
<G-vec00106-002-s388><decide.entscheiden><en> Whether the stock exchange floor or the racetrack - speed and performance decide success or failure in both worlds.
<G-vec00106-002-s388><decide.entscheiden><de> Ob Börsenparkett oder Rennstrecke - Schnelligkeit und Performance entscheiden in beiden Welten über Erfolg oder Misserfolg.
<G-vec00106-002-s389><decide.entscheiden><en> You decide what the scope of our work will be: We are happy to explain your various options.
<G-vec00106-002-s389><decide.entscheiden><de> Dabei entscheiden Sie über den Umfang unserer Arbeit: Wir erläutern Ihnen gern die verschiedenen Möglichkeiten.
<G-vec00106-002-s390><decide.entscheiden><en> You decide the number and frequency of checks, and we handle the rest.
<G-vec00106-002-s390><decide.entscheiden><de> Sie entscheiden über die Anzahl und Häufigkeit der Kontrollen, wir kümmern uns um den Rest.
<G-vec00106-002-s391><decide.entscheiden><en> 4 expert juries, a youth jury and the audience will decide who is going to receive the total of 11 awards in the four competitions, all of them including a prize money amounting to 42,000 Euros.
<G-vec00106-002-s391><decide.entscheiden><de> 4 Fachjurys, eine Jugendjury und das Publikum entscheiden über die Vergabe der insgesamt 11 Preise in den 4 Wettbewerben, die mit insgesamt 42.000 Euro dotiert sind.
<G-vec00106-002-s392><decide.entscheiden><en> Hereby our customer’s decide which processing status is appropriate to the application of their product.
<G-vec00106-002-s392><decide.entscheiden><de> Dabei entscheiden unsere Kunden über die einzelnen Verarbeitungsstufen angepasst an die Produktanwendung.
<G-vec00106-002-s393><decide.entscheiden><en> You decide the composition of the shipping.
<G-vec00106-002-s393><decide.entscheiden><de> Sie entscheiden über die Zusammensetzung der Sendung.
<G-vec00106-002-s394><decide.entscheiden><en> Often also the specific skills and experience of the surgeon decide the outcome of the operation. The former method is applicable in practice and as part of the clinical routine only in small and / or low structured defects and reach the shaping and adaptation in complicated defects and implants quickly reach their limits of manufacturing technology.
<G-vec00106-002-s394><decide.entscheiden><de> Oftmals entscheiden auch hier die besonderen Fähigkeiten und Erfahrungen des Chirurgen über das Ergebnis der Die erstgenannten Verfahren sind in der Praxis und im Rahmen der Kliniksroutine nur bei kleineren und/oder gering strukturierten Defekten anwendbar und gelangen zur Formung und Anpassung bei komplizierten Defekten und Implantaten schnell an ihre herstellungstechnischen Grenzen.
<G-vec00106-002-s395><decide.entscheiden><en> In the traditional tendering process, suppliers are only able to decide two variables: First, whether to submit an offer or not; second, what product price to offer.
<G-vec00106-002-s395><decide.entscheiden><de> Beim klassischen Ausschreibungsprozess hat ein Lieferant nur die Möglichkeit, über zwei Variable zu entscheiden: Zum einen über die Variable, ob der Lieferant überhaupt ein Angebot abgeben möchte.
<G-vec00106-002-s396><decide.entscheiden><en> The sponsors decide the scope of supported packages but updates and security fixes will be available for all Debian users without cost.
<G-vec00106-002-s396><decide.entscheiden><de> Die Sponsoren entscheiden über das Ausmaß der zu unterstützenden Pakete, jedoch werden Updates und die Behebung von Sicherheitslücken allen Debianbenutzern ohne Kosten zur Verfügung gestellt.
<G-vec00106-002-s397><decide.entscheiden><en> You may decide the time.
<G-vec00106-002-s397><decide.entscheiden><de> Sie entscheiden über die Zeit.
<G-vec00106-002-s398><decide.entscheiden><en> Today, aromas and additives very often decide the success or failure of a new product.
<G-vec00106-002-s398><decide.entscheiden><de> Heutzutage entscheiden Aromen und Zusatzstoffe nicht selten über den Erfolg oder Misserfolg eines neuen Produktes.
<G-vec00106-002-s399><decide.entscheiden><en> How about I just show you the options and let you decide for yourself?
<G-vec00106-002-s399><decide.entscheiden><de> Zeige ich Dir einfach die Marken, die es gibt und Du entscheidest selbst.
<G-vec00106-002-s400><decide.entscheiden><en> You decide which assistant you use.
<G-vec00106-002-s400><decide.entscheiden><de> Du entscheidest, welche Assistenten eingesetzt werden.
<G-vec00106-002-s401><decide.entscheiden><en> You decide that.
<G-vec00106-002-s401><decide.entscheiden><de> Du entscheidest das.
<G-vec00106-002-s402><decide.entscheiden><en> Each has advantages and disadvantages - you decide which tank is best to use.
<G-vec00106-002-s402><decide.entscheiden><de> Jedes Produkt hat Vorteile und Nachteile - Du entscheidest, welcher Panzer am besten geeignet ist.
<G-vec00106-002-s403><decide.entscheiden><en> In inFamous 2, you must decide which path reluctant hero Cole MacGrath travels down – good or bad, come what may.
<G-vec00106-002-s403><decide.entscheiden><de> Bei inFamous 2 entscheidest du, welchen Weg der zögerliche Superheld Cole MacGrath einschlägt – gut oder böse, auf Gedeih und Verderb.
<G-vec00106-002-s404><decide.entscheiden><en> You decide which style brings the right sense to your bedroom.
<G-vec00106-002-s404><decide.entscheiden><de> Du entscheidest, welcher Stil den richtigen Sinn in Dein Schlafzimmer bringt.
<G-vec00106-002-s405><decide.entscheiden><en> You decide for yourself which tools and technologies you want to work with.
<G-vec00106-002-s405><decide.entscheiden><de> Du entscheidest selbst, mit welchen Arbeitsgeräten und Technologien du arbeiten möchtest.
<G-vec00106-002-s406><decide.entscheiden><en> Sound and voice volume can be controlled separately, so you can decide for yourself how loud you want to hear the game sound or your team mates.
<G-vec00106-002-s406><decide.entscheiden><de> Sound- und Sprachlautstärke lassen sich getrennt regeln; so entscheidest du selbst, wie laut du den Game-Sound oder deine Teamkollegen hören willst.
<G-vec00106-002-s407><decide.entscheiden><en> We will inform you if there is an order close by and you decide whether you want to take the job or not.
<G-vec00106-002-s407><decide.entscheiden><de> Wir informieren dich, wenn es in deiner Nähe Lieferaufträge gibt und du entscheidest, ob du den Job übernehmen möchtest oder nicht.
<G-vec00106-002-s408><decide.entscheiden><en> You decide when you want to jump onto the train.
<G-vec00106-002-s408><decide.entscheiden><de> Du entscheidest, wann du aufspringen möchtest.
<G-vec00106-002-s409><decide.entscheiden><en> On Mantil Island (as Fish Eye told you) you can find Thomas Cook, an old pirate who wants you to decide which of his sons is worth to wear the family bandana.
<G-vec00106-002-s409><decide.entscheiden><de> Auf der Mantil Insel (wie Fischauge dir erzählt hat) findest du Thomas Cook, einen alten Piraten, der möchte, dass du entscheidest, welcher seiner Söhne es wert ist, das Familienkopftuch zu tragen.
<G-vec00106-002-s410><decide.entscheiden><en> Self-effecacy means that you – and only you – decide what your life path looks like.
<G-vec00106-002-s410><decide.entscheiden><de> Selbstwirksam bedeutet, dass Du – und nur Du – entscheidest, wie Dein Lebensweg aussieht.
<G-vec00106-002-s411><decide.entscheiden><en> You decide with your tip what the tour is worth it.
<G-vec00106-002-s411><decide.entscheiden><de> Die Guides werden belohnt, indem Du mit Deinem Trinkgeld entscheidest, wieviel Dir die Tour Wert war.
<G-vec00106-002-s412><decide.entscheiden><en> If you decide to make your cuts with a blade, place a piece of cardboard, wood, or other protective board under the leather to protect the surface you are cutting on.
<G-vec00106-002-s412><decide.entscheiden><de> Wenn du entscheidest, die Schnitte mit einer Klinge zu machen, lege ein Stück Karton, Holz oder ein anderes schützendes Material unter das Leder und schütze so die Oberfläche auf der du schneidest.
<G-vec00106-002-s413><decide.entscheiden><en> For instance, if you decide, "I will be kind in every moment.
<G-vec00106-002-s413><decide.entscheiden><de> Wenn du zum Beispiel entscheidest „Ich will in jedem Moment freundlich sein.
<G-vec00106-002-s414><decide.entscheiden><en> List in the last two title boxes what you will decide to do positively tomorrow starting with “tomorrow I…”.
<G-vec00106-002-s414><decide.entscheiden><de> Liste in den letzten zwei Titelkästen, was du entscheidest, morgen positiv zu machen, beginnend mit "morgen ich...".
<G-vec00106-002-s415><decide.entscheiden><en> You yourself decide what route you'll take – take the liberty of being yourself, even when it comes to choosing your ideal watch.
<G-vec00106-002-s415><decide.entscheiden><de> Du selbst entscheidest, welchen Weg Du gehst – nimmst Dir die Freiheit, Du selbst zu sein, auch bei der Wahl Deiner Uhr.
<G-vec00106-002-s416><decide.entscheiden><en> Content you submit to the forum belongs to you, and you decide what permission to give others for it.
<G-vec00106-002-s416><decide.entscheiden><de> Die Inhalte, die du im Forum einreichst, gehören dir, und du entscheidest, welche Berechtigung du anderen dafür gibst.
<G-vec00106-002-s417><decide.entscheiden><en> It’s still good to know about them, just in case the day comes when you decide your studio needs one.
<G-vec00106-002-s417><decide.entscheiden><de> Ist es doch gut, über sie Bescheid zu wissen, nur für den Fall, dass Du eines Tages entscheidest, dass Dein Studio eines braucht.
<G-vec00106-002-s418><decide.entscheiden><en> Titan Poker will team up the players on a daily basis, on a first to register, first to be served level and will also decide on the roles of the players within the team.
<G-vec00106-002-s418><decide.entscheiden><de> Titan Poker stellt die Teams täglich und in chronologischer Reihenfolge (Wer zuerst kommt, malt zuerst) zusammen und entscheidet auch über die Zuordnung der Rollen im Team.
<G-vec00106-002-s419><decide.entscheiden><en> 19) The client will decide freely and responsibly, which address information, including his/her email address and name, will be displayed in the listing.
<G-vec00106-002-s419><decide.entscheiden><de> 19) Der Auftraggeber entscheidet frei und eigenverantwortlich, welche Adressangaben einschließlich seiner Emailadresse und seines Namens als Ansprechpartner in den Einträgen angezeigt werden.
<G-vec00106-002-s420><decide.entscheiden><en> For creditors whose claims are contested by the debtor or by the insolvency administrator, and in the case of creditors with a right to separate satisfaction, the insolvency court shall decide on its own discretion on the requirement for consent to be given by such creditors or a security to be provided to them.
<G-vec00106-002-s420><decide.entscheiden><de> Bei Gläubigern, deren Forderungen vom Schuldner oder vom Insolvenzverwalter bestritten werden, und bei absonderungsberechtigten Gläubigern entscheidet das Insolvenzgericht nach freiem Ermessen, inwieweit es einer Zustimmung dieser Gläubiger oder einer Sicherheitsleistung gegenüber ihnen bedarf.
<G-vec00106-002-s421><decide.entscheiden><en> 5. The Council shall decide, on the basis of a proposal from the Commission, on any amendment to Annex I.
<G-vec00106-002-s421><decide.entscheiden><de> (5) Der Rat entscheidet auf Vorschlag der Kommission über jede Änderung des Anhangs I.
<G-vec00106-002-s422><decide.entscheiden><en> Even if something comes to mind from the environment, it is always up to the brain to decide what value it may have to be taken into account.
<G-vec00106-002-s422><decide.entscheiden><de> Auch wenn einem irgendetwas aus der Umwelt einfällt, liegt es immer am Gehirn, das entscheidet, welchen Wert es eventuell hat, um berücksichtigt zu werden.
<G-vec00106-002-s423><decide.entscheiden><en> In the end HERE Maps only provides the map database for Opel and they decide when they make an update for which system.
<G-vec00106-002-s423><decide.entscheiden><de> „HERE“ stellt nur die Kartendatenbank für Opel bereit und Opel entscheidet, wann für welche Systeme eine Aktualisierung gemacht wird.
<G-vec00106-002-s424><decide.entscheiden><en> If both are really selected go to Objects-->Align and decide how the text should be aligned).
<G-vec00106-002-s424><decide.entscheiden><de> Wenn beide wirklich selektiert sind, geht man zu Objects-->Align und entscheidet, wie der Text zur Box hin ausgerichtet werden soll).
<G-vec00106-002-s425><decide.entscheiden><en> The committee of the association will decide on admission.
<G-vec00106-002-s425><decide.entscheiden><de> Über die Aufnahme entscheidet der Vorstand.
<G-vec00106-002-s426><decide.entscheiden><en> Before you buy, think about the purposes for which you need your laminator and then decide which model suits you best.
<G-vec00106-002-s426><decide.entscheiden><de> Bevor es an den Kauf geht, überlegt ihr euch am besten, für welche Zwecke ihr euer Laminiergerät benötigt und entscheidet dann, welches Modell am besten zu euch passt.
<G-vec00106-002-s427><decide.entscheiden><en> After 12 to 24 months, Swisscom will decide which suppliers need to be reassessed, provided the supplier has not initiated the reassessment themselves.
<G-vec00106-002-s427><decide.entscheiden><de> Nach 12 bis 24 Monaten entscheidet Swisscom, bei welchen Lieferanten eine Neubewertung erforderlich ist, sofern der Lieferant das Re-Assessment nicht selbständig eingeleitet hat.
<G-vec00106-002-s428><decide.entscheiden><en> In cases of a tie, the Chairperson has a right to decide.
<G-vec00106-002-s428><decide.entscheiden><de> Bei Stimmengleichheit entscheidet der Vorsitzende.
<G-vec00106-002-s429><decide.entscheiden><en> This suspension shall apply until the next annual general meeting, which will decide upon the expulsion of the member.
<G-vec00106-002-s429><decide.entscheiden><de> Die Suspendierung endet zum Zeitpunkt der nächsten Generalversammlung, die dann über einen Ausschluss des Mitglieds entscheidet.
<G-vec00106-002-s430><decide.entscheiden><en> Upon motion being submitting by the executive board, the general assembly shall decide on the said expulsion with a majority of three quarters of the votes cast by the members present.
<G-vec00106-002-s430><decide.entscheiden><de> Über den Ausschluss entscheidet auf Antrag des Vorstands die Mitgliederversammlung mit einer Mehrheit von drei Vierteln der anwesenden Mitglieder.
<G-vec00106-002-s431><decide.entscheiden><en> The Electoral Board shall decide on the validity of the votes cast and on any queries and objections arising during the poll and during the counting of votes.
<G-vec00106-002-s431><decide.entscheiden><de> Der Wahlvorstand entscheidet über die Gültigkeit der abgegebenen Stimmen und über alle bei der Wahlhandlung und bei der Ermittlung des Wahlergebnisses sich ergebenden Anstände.
<G-vec00106-002-s432><decide.entscheiden><en> Top Unless otherwise agreed by the parties, the arbitrator will decide whether hearings must be held to present arguments, hear evidence and enter pleadings, or whether this can be done exclusively in writing.
<G-vec00106-002-s432><decide.entscheiden><de> Vorbehaltlich einer anders lautenden Vereinbarung der Parteien entscheidet der Schiedsrichter, ob Verhandlungstermine für Einlassungen, die Beweisaufnahme und den Vortrag der Schlussanträge anzusetzen sind oder ob die Rechtshandlungen ausschließlich in Schriftform erfolgen.
<G-vec00106-002-s433><decide.entscheiden><en> The latter shall also decide in cases where no agreement can be reached on the number of assessors.
<G-vec00106-002-s433><decide.entscheiden><de> Dieses entscheidet auch, wenn kein Einverständnis über die Zahl der Beisitzer erzielt wird.
<G-vec00106-002-s434><decide.entscheiden><en> In cases of dispute, a labour court has to decide on the person who is to chair the board and on the number of the board's members.
<G-vec00106-002-s434><decide.entscheiden><de> Im Streitfall entscheidet über die Person des Vorsitzenden und die Anzahl der Beisitzer das Arbeitsgericht.
<G-vec00106-002-s435><decide.entscheiden><en> And if all this doesn’t decide the winner, then we will decide it by lots.
<G-vec00106-002-s435><decide.entscheiden><de> Und wenn das alles nicht hilft, entscheidet das Los.
<G-vec00106-002-s436><decide.entscheiden><en> 1. If the Commission finds that expenditure as indicated in Article 3(1) and Article 4 has been incurred in a way that has infringed Community rules, it shall decide what amounts are to be excluded from Community financing in accordance with the procedure referred to in Article 41(3).
<G-vec00106-002-s436><decide.entscheiden><de> Konformitätsabschluss (1) Die Kommission entscheidet nach dem in Artikel 41 Absatz 3 genannten Verfahren, welche Beträge von der gemeinschaftlichen Finanzierung auszuschließen sind, wenn sie feststellt, dass Ausgaben nach Artikel 3 Absatz 1 und Artikel 4 nicht in Übereinstimmung mit den Gemeinschaftsvorschriften getätigt worden sind.
<G-vec00106-002-s437><decide.entscheiden><en> A very low percentage of Ethiopian arrivals decide to seek asylum in Yemen, partly due to a lack of awareness and access to asylum mechanisms, or do not meet the criteria to be recognized as refugees.
<G-vec00106-002-s437><decide.entscheiden><de> Ein sehr geringer Prozentsatz der äthiopischen Ankömmlinge entscheidet sich für ein Asylgesuch im Jemen, teilweise aus mangelndem Bewusstsein und Zugang zum Asylverfahren oder weil sie die Kriterien zur Flüchtlingsanerkennung nicht erfüllen.
<G-vec00106-002-s438><decide.entscheiden><en> At one of the many touchpoints, they decide whether to buy, buy again, recommend, or whether they are willing to pay a premium price.
<G-vec00106-002-s438><decide.entscheiden><de> An einem der vielen Touchpoints entscheidet er sich, ob er kauft, wieder kauft, weiterempfiehlt oder ob er bereit ist, ein Preispremium zu bezahlen.
<G-vec00106-002-s439><decide.entscheiden><en> Its criteria decide whether the purchase or sale of drinkable South American water, arable Sudanese land, or Württembergian sewage plants can be financed and turned into the basis of new securities that provide the market with a new supply of speculative material.
<G-vec00106-002-s439><decide.entscheiden><de> Das entscheidet nach seinen Kriterien, ob sich der An- und Verkauf südamerikanischen Trinkwassers, sudanesischen Ackerlandes oder württembergischer Kläranlagen finanzieren und zur Grundlage neuer Wertpapiere machen lässt, die dem Markt neuen Zufluss an spekulativem Stoff verschaffen.
<G-vec00106-002-s440><decide.entscheiden><en> Those who visit the lake always come back... or perhaps they decide to change their life and live here.
<G-vec00106-002-s440><decide.entscheiden><de> Wer einmal den See gesehen hat, kommt immer wieder zurück... oder entscheidet sich, für immer hier zu bleiben.
<G-vec00106-002-s441><decide.entscheiden><en> If you decide to limit the accessibility of your content to anybody except yourself or to a certain group of people, this does not influence the storage of your information by PUSHAR.
<G-vec00106-002-s441><decide.entscheiden><de> Entscheidet sich der Nutzer für eine Beschränkung der Zugriffsmöglichkeiten auf gar keine oder nur ausgewählte Dritte, so änder dies nichts an der Speicherung des Contents durch PUSHAR.
<G-vec00106-002-s442><decide.entscheiden><en> 27 - Editorial decide to spend their summer holiday in Apulia. They go to a travel agency in order to book their family holiday at the holiday resort requested.
<G-vec00106-002-s442><decide.entscheiden><de> Familie Hofer aus Südtirol entscheidet sich für einen Sommerurlaub in Apulien und begibt sich ins Reisebüro um dort den Familienurlaub in der gewünschten Ferienanlage zu buchen.
<G-vec00106-002-s443><decide.entscheiden><en> In case that customers want to shop in the pro shop after spending time on the driving range, or decide to rent a golf cart, they can use their deposit to do so.
<G-vec00106-002-s443><decide.entscheiden><de> Entscheidet sich der Kunde nach der Drivingrange noch ein paar Dinge im ProShop einzukaufen oder ein Cart zu mieten, kann auch dies mittels seines Guthabens erfolgen.
<G-vec00106-002-s444><decide.entscheiden><en> The artist alone is at liberty to decide what should happen (or not happen) (13) and when –in the attempt to subject the art form itself to a closer interrogation.
<G-vec00106-002-s444><decide.entscheiden><de> Allein der Künstler entscheidet frei, was sich wo wie lange ereignen wird – oder auch nicht (13) – in dem Versuch, auch die Kunstform selbst stärker zu befragen.
<G-vec00106-002-s445><decide.entscheiden><en> At the end of the day, they are the ones to decide how quickly the player can progress in the game, what and how many rewards the player will receive, and how difficult conquering the Blade Coast should be.
<G-vec00106-002-s445><decide.entscheiden><de> Hier entscheidet sich am Ende des Tages, wie schnell der Spieler im Spiel voranschreitet, welche und wieviele Belohnungen dieser erhält und ob die Klingenküste einfach oder schwer zu erobern ist.
<G-vec00106-002-s446><decide.entscheiden><en> After a few errands in your home village, where the elements of the game are sparely taught to you, you decide which side you want to align with for the time and then you do quests for your chosen fraction.
<G-vec00106-002-s446><decide.entscheiden><de> Nach ein paar anfänglichen Quests im Dorf, bei denen man die einzelnen Elemente des Spiels mehr schlecht als recht erklärt bekommt, entscheidet man sich bald für eine der beiden Seiten und erledigt Quests für die jeweilige Fraktion.
<G-vec00106-002-s447><decide.entscheiden><en> With the production of this project the participant will decide which technical means will be used: the construction of Apps, the use of projection mapping procedures, the construction of Quartz-Compositions or Max / MSP patches, or other technologies.
<G-vec00106-002-s447><decide.entscheiden><de> Bei der Erstellung der eigenen Arbeit entscheidet sich welche technischen Mittel eingesetzt werden: sei dies nun die Nutzung von Apps oder Programmen, die Anwendung von Projektions-Verfahren, das Erstellen von einfachen Programmierskripten, oder anderer Technologien.
<G-vec00106-002-s448><decide.entscheiden><en> Course of the game[edit] After setting the desired parameters in the options screen (see more in section "Hints" below) you decide on which map the game should take place.
<G-vec00106-002-s448><decide.entscheiden><de> Spielablauf[Bearbeiten] Nachdem man im Auswahlbildschirm die gewünschten Parameter eingestellt hat (näheres hierzu s. "Hinweise" weiter unten) entscheidet man sich auf welcher Karte das Spiel stattfinden soll.
<G-vec00106-002-s449><decide.entscheiden><en> The next moment will decide the fate of the closet alchemist playing with the elements in the privacy of his garret.
<G-vec00106-002-s449><decide.entscheiden><de> Im nächsten Augenblick entscheidet sich das weitere Schicksal des unzeitgemäßen Alchimisten, der heimlich auf dem Dachboden mit den Elementen hantiert.
<G-vec00106-002-s450><decide.entscheiden><en> Should TIPWIN decide to close a user’s account for any reason, bets which have already been placed and accepted within the general terms and conditions and sports rules will not be voided, and the user will be paid any winnings.
<G-vec00106-002-s450><decide.entscheiden><de> Entscheidet sich TIPWIN, das Konto eines Nutzers aus irgendeinem gerechtfertigten Grund zu schließen, so werden die bereits gesetzten und angenommenen Wetten innerhalb der Allgemeinen Geschäftsbedingungen und Sportregeln nicht annulliert und die Nutzer bekommen alle Gewinne ausbezahlt.
<G-vec00106-002-s451><decide.entscheiden><en> Complaints department worker will assess the claimed defect and decide the merits of the claim and whether it is a fundamental breach of contract or irrelevant, if possible immediately.
<G-vec00106-002-s451><decide.entscheiden><de> Der Mitarbeiter der Reklamationsabteilung beurteilt den reklamierten Mangel und entscheidet möglichst sofort über die Begründetheit der Reklamation und ob es sich um eine wesentliche oder nicht wesentliche Verletzung des Vertrags handelt.
<G-vec00106-002-s452><decide.entscheiden><en> A high percentage of patients from the USA, Norway, and the UK decide to seek fertility care abroad because of their desire for access to anonymous egg donors.
<G-vec00106-002-s452><decide.entscheiden><de> Ein hoher Prozentsatz der Patienten aus den USA, Norwegen und Großbritannien entscheidet sich für eine Fruchtbarkeitsversorgung im Ausland, weil sie den Zugang zu anonymen Eizellspenderinnen wünschen.
<G-vec00106-002-s453><decide.entscheiden><en> Very often a person may decide to quit the CCP in just a few minutes.
<G-vec00106-002-s453><decide.entscheiden><de> Sehr oft entscheidet sich eine Person innerhalb weniger Minuten zum Austritt aus der KPCh.
<G-vec00106-002-s454><decide.entscheiden><en> While cloud solutions require the transmission of information to a remote server in a data center, with on-premises software you can keep all data with you unless you decide to use cloud storage.
<G-vec00106-002-s454><decide.entscheiden><de> Während Cloud-Lösungen die Übertragung von Informationen an einen entfernten Server in einem Rechenzentrum voraussetzen, behält man bei On-Premises-Software alle Daten bei sich – außer man entscheidet sich, einen Cloud-Speicher einzusetzen.
<G-vec00106-002-s455><decide.entscheiden><en> In this case, the association may decide to exclusively create association EPDs so that its members may not create individualized EPDs or their own EPDs through the association.
<G-vec00106-002-s455><decide.entscheiden><de> In diesem Fall entscheidet sich der Verband, ausschließlich Verbands-EPDs zu erstellen, sodass seine Mitglieder keine individualisierten EPDs oder eigene EPDs über den Verband erstellen können.
<G-vec00106-002-s494><decide.entscheiden><en> We decide together on a case-by-case basis how this business can be contractually arranged.
<G-vec00106-002-s494><decide.entscheiden><de> Wie dieses Geschäft vertraglich zu regeln ist, wird von Fall zu Fall gemeinsam entschieden.
<G-vec00106-002-s496><decide.entscheiden><en> After the game computer has dealt 2 cards for each hand and 1 card for himself you have to decide for each hand, which activity you would like to perform.
<G-vec00106-002-s496><decide.entscheiden><de> Nachdem der Spielcomputer für jede Hand 2 Karten und für sich selbst eine Karte gegeben hat, musst du für jede Hand entschieden, welche Aktion du durchführen willst.
<G-vec00106-002-s497><decide.entscheiden><en> Turning the spacecraft by 90 degrees took around 30 minutes, so it was necessary to decide which experiment would be the main instrument before each of the rapid flybys.
<G-vec00106-002-s497><decide.entscheiden><de> Da eine Drehung der Sonde um 90 Grad zirka 30 Minuten dauerte, musste vor den schnellen Vorbeiflügen entschieden werden, welches Experiment das Hauptinstrument sein sollte.
<G-vec00106-002-s498><decide.entscheiden><en> Voters should decide on the new constitution and will be able to elect a new parliament within a few months.
<G-vec00106-002-s498><decide.entscheiden><de> Über die neue Verfassung, Neuwahlen und danach indirekt eine neue Regierung sollte nicht mehr auf der Straße gestritten, sondern an den Urnen durch das gesamte ägyptische Wahlvolk entschieden werden.
<G-vec00106-002-s499><decide.entscheiden><en> Ultimately, the church councils did not decide if a book was Scripture; that was decided when the human author was chosen by God to write.
<G-vec00106-002-s499><decide.entscheiden><de> Letztendlich hat nicht das Kirchenoberhaupt entschieden, ob ein Buch zur heiligen Schrift gehörte; das wurde entschieden, wenn der menschliche Autor von Gott ausgewählt wurde.
<G-vec00106-002-s500><decide.entscheiden><en> Once you decide what time of day works best for you and form some kind of writing schedule, stick to that schedule.
<G-vec00106-002-s500><decide.entscheiden><de> Wenn du einmal entschieden hast, zu welcher Zeit des Tages du am besten arbeitest, solltest du eine Art Schreibplan erstellen und dich auch an diesen Plan halten.
<G-vec00106-002-s501><decide.entscheiden><en> The State Labor Court of Rheinland-Pfalz had to decide on the consequences arising from a secret recording of a staff appraisal by using a Smartphone.
<G-vec00106-002-s501><decide.entscheiden><de> Das LAG Rheinland-Pfalz hat entschieden, welche Folge die heimliche Aufnahme eines Personalgesprächs mit dem Smartphone für den Arbeitnehmer hat.
<G-vec00106-002-s502><decide.entscheiden><en> These departments would then check the proposals, make a final project selection and decide on the financing.
<G-vec00106-002-s502><decide.entscheiden><de> Die DEZA und das SECO prüften die Projektanträge, nahmen die definitive Auswahl der Projekte vor und entschieden über die Finanzierung.
<G-vec00106-002-s503><decide.entscheiden><en> It is then only possible to decide with some certain knowledge whether the journey can be continued at all.
<G-vec00106-002-s503><decide.entscheiden><de> Nur mit Sachkenntnis kann dann entschieden werden, ob die Fahrt überhaupt fortgesetzt werden kann.
<G-vec00106-002-s504><decide.entscheiden><en> We shall, therefore, only have to hand over the matter to the experimenters, and, while waiting for them to finally decide the debate, not to preoccupy ourselves with these disquieting problems, and to tranquilly continue our work as if the principles were still uncontested.
<G-vec00106-002-s504><decide.entscheiden><de> Wir können es also nur den Experimentatoren überlassen und sollten uns, bis sie den Streit endgültig entschieden haben, nicht mit diesen beunruhigenden Problemen beschäftigen, sondern unsere Arbeiten ruhig fortsetzen, als ob die Prinzipien noch nicht angefochten wären.
<G-vec00106-002-s505><decide.entscheiden><en> Through the analysis of the most common genetic causes associated with male factor infertility, affected men not only discover the reason behind their reduced sperm quality—but they also have the opportunity to discuss the results of these finding with their doctor, and decide how this information will influence their plans to start a family.
<G-vec00106-002-s505><decide.entscheiden><de> Durch die Analyse der häufigsten genetischen Ursachen für männliche Unfruchtbarkeit können betroffene Männer nicht nur die Gründe der eingeschränkten Samenqualität erfahren und somit eine Erklärung bekommen, sondern es kann auch ganz individuell mit dem Arzt entschieden werden, welche Konsequenzen dieser Befund für einen Kinderwunsch hat.
<G-vec00106-002-s506><decide.entscheiden><en> We will then decide whether and under what conditions a course of study is still possible for you.
<G-vec00106-002-s506><decide.entscheiden><de> Im Anschluss wird entschieden, ob und unter welchen Voraussetzungen für Sie ein Studium trotzdem möglich ist.
<G-vec00106-002-s507><decide.entscheiden><en> I’ve clearly decide that the second way is more reasonable and constructive.
<G-vec00106-002-s507><decide.entscheiden><de> Ich habe eindeutig entschieden, dass der zweite Weg sinnvoller und konstruktiver ist.
<G-vec00106-002-s508><decide.entscheiden><en> That must have hit really hard for the self-appointed representatives of “The People’s Vote”, because the people did not decide as “Bild” had expected them to.
<G-vec00106-002-s508><decide.entscheiden><de> Das muss die selbsternannten Vertreter von „Volkes Stimme“ ins Mark und Bein treffen, denn das Volk hatte nicht so entschieden, wie es die Bild-Zeitung erwartet hatte.
<G-vec00106-002-s509><decide.entscheiden><en> They are announced on <debian-devel-announce@lists.debian.org> and the announcement explains which area will be the focus of the party: usually they focus on release critical bugs but it may happen that they decide to help finish a major upgrade (like a new perl version which requires recompilation of all the binary modules).
<G-vec00106-002-s509><decide.entscheiden><de> Sie werden auf <debian-devel-announce@lists.debian.org> angekündigt und in der Ankündigung wird erklärt, auf welchem Bereich der Fokus der Party liegt: Üblicherweise liegt der Fokus auf release-kritischen Fehlern, aber es kann vorkommen, dass entschieden wird, bei der Fertigstellung eines Haupt-Upgrades zu helfen (wie einer neuen perl-Version, die ein Neukompilieren aller binären Module erfordert).
<G-vec00106-002-s510><decide.entscheiden><en> I regret that I did not decide earlier.
<G-vec00106-002-s510><decide.entscheiden><de> Ich bedaure, dass ich mich nicht schon früher entschieden habe.
<G-vec00106-002-s511><decide.entscheiden><en> As soon as a fault message is received, a service technician promptly carries out a remote diagnosis and liaises with the operating personnel to decide what measures are to be taken.
<G-vec00106-002-s511><decide.entscheiden><de> Sobald die Fehlermeldung eintrifft, führt ein Servicetechniker sofort eine Ferndiagnose durch und setzt sich mit dem Bedienpersonal in Verbindung - dann wird entschieden, welche Maßnahmen getroffen werden.
<G-vec00106-002-s512><decide.entscheiden><en> You can of course isolate any number of moments that decide a sporting event, but this one proved especially visceral for the Gnomes.
<G-vec00106-002-s512><decide.entscheiden><de> Du kannst bei jeder Sportveranstaltung Momente benennen, die ein Spiel entschieden haben, und dieser Moment war schon ein Wirkungstreffer bei den Gnomes.
<G-vec00106-002-s589><decide.entscheiden><en> If the city would have lived up to its aspirations, refugees could decide on their own in which flat they want to live.
<G-vec00106-002-s589><decide.entscheiden><de> Hätte die Stadt ihre eigenen Ansprüche umgesetzt, könnten Geflüchtete selbst entscheiden, in welcher Wohnung sie leben möchten.
<G-vec00106-002-s590><decide.entscheiden><en> But at the end of the day they were allowed to decide what they wanted to film.
<G-vec00106-002-s590><decide.entscheiden><de> Aber letztlich durften sie selbst entscheiden, was sie filmen wollten.
<G-vec00106-002-s591><decide.entscheiden><en> By following online courses you can, to a great extent, decide at what time you want to study.
<G-vec00106-002-s591><decide.entscheiden><de> Wenn Sie Onlinekursen belegen, können Sie bis zu einem gewissen Punkt selbst entscheiden, wann Sie lernen möchten.
<G-vec00106-002-s592><decide.entscheiden><en> In this case the client can decide if the deposit will be refunded or credited for a future stay. Book Request availability
<G-vec00106-002-s592><decide.entscheiden><de> In diesen Fällen darf der Gast selbst entscheiden ob die geleistete Anzahlung zurückerstattet oder für einen zukünftigen Aufenthalt gutgeschrieben wird.
<G-vec00106-002-s593><decide.entscheiden><en> Each observer should so decide which meaningful moment is seen and felt in the image.
<G-vec00106-002-s593><decide.entscheiden><de> Jeder Betrachter solle so selbst entscheiden, welcher bedeutungsvolle Moment im Bild sichtbar und spürbar wird.
<G-vec00106-002-s594><decide.entscheiden><en> This caused more than one headache to design, but it’s your adventure, and we wanted you to decide where your next stop would be.
<G-vec00106-002-s594><decide.entscheiden><de> Das hat uns während der Entwicklung zwar einige Kopfschmerzen bereitet, aber es ist euer Abenteuer und wir wollten, dass ihr selbst entscheiden könnt, wohin euch eure Reise als Nächstes führt.
<G-vec00106-002-s595><decide.entscheiden><en> The visitor may decide which cookies to accept in their Internet browser settings.
<G-vec00106-002-s595><decide.entscheiden><de> Der Besucher der Webseite kann selbst entscheiden, welche Cookies er in den Einstellungen seines Webbrowsers akzeptiert möchte.
<G-vec00106-002-s596><decide.entscheiden><en> It is up to the user to decide which meal is to be served.
<G-vec00106-002-s596><decide.entscheiden><de> Um welche Mahlzeit es sich dabei handelt, dass kann der Nutzer selbst entscheiden.
<G-vec00106-002-s597><decide.entscheiden><en> Text proposed by the Commission Amendment (19)While this Directive does not increase the overall amount of admissible advertising time during the period from 7:00 to 23:00, it is important for broadcasters to have more flexibility and to be able to decide when to place advertising in order to maximise advertisers' demand and viewers' flow.
<G-vec00106-002-s597><decide.entscheiden><de> (19)Diese Richtlinie sieht zwar keine Verlängerung der zulässigen Gesamtwerbedauer im Zeitraum von 7.00 bis 23.00 Uhr vor, es ist jedoch wichtig, dass die Fernsehveranstalter mehr Flexibilität erhalten und selbst entscheiden können, wann sie Werbung platzieren, um die Nachfrage der Werbenden und den Zuschauerfluss bestmöglich aufeinander abzustimmen.
<G-vec00106-002-s598><decide.entscheiden><en> Note: You can decide whether to transfer updates securely to your customer account by selecting the corresponding option in the publication settings.
<G-vec00106-002-s598><decide.entscheiden><de> Bemerkung: Sie können selbst entscheiden, ob Updates auf sicherem Wege an Ihr Kundenkonto übertragen werden sollen, indem Sie in den Veröffentlichungseinstellungen die entsprechende Option aktivieren.
<G-vec00106-002-s599><decide.entscheiden><en> You can decide which border crossing you would like to use.
<G-vec00106-002-s599><decide.entscheiden><de> Sie können selbst entscheiden, welchen Grenzübergang sie nutzen möchten.
<G-vec00106-002-s600><decide.entscheiden><en> You can also make settings in your Internet browser so that you are informed when cookies are saved and you can then decide in each individual case if you wish to accept the cookie or not.
<G-vec00106-002-s600><decide.entscheiden><de> Sie können Ihren Internetbrowser auch so einstellen, dass Sie über das Speichern von Cookies informiert werden, in jedem Einzelfall können Sie dann selbst entscheiden, ob Sie Cookies akzeptieren oder nicht.
<G-vec00106-002-s601><decide.entscheiden><en> Everyone must decide for themselves what is convenient.
<G-vec00106-002-s601><decide.entscheiden><de> Jeder Mensch muss selbst für sich entscheiden, was günstig ist.
<G-vec00106-002-s602><decide.entscheiden><en> All of them have their advantages and disadvantages, and we have tried our best to indicate them in the comparison table for your own convenience to decide what to choose.
<G-vec00106-002-s602><decide.entscheiden><de> Alle haben ihre Vor- und Nachteile, und wir haben unser Bestes getan, um sie in der Vergleichstabelle anzugeben, damit Sie selbst entscheiden können, was Sie wählen möchten.
<G-vec00106-002-s603><decide.entscheiden><en> It is on you to decide how long you desire the lady´s company for.
<G-vec00106-002-s603><decide.entscheiden><de> Sie können selbst entscheiden, wie lange Sie die Escort Begleitung der Dame wünschen.
<G-vec00106-002-s604><decide.entscheiden><en> The user can decide if the newly created password is only accessible for himself/herself, or if it is a public password and therefore the normal folder inheritance of rights takes effect.
<G-vec00106-002-s604><decide.entscheiden><de> Der Benutzer kann selbst entscheiden, ob das neu angelegte Passwort nur für ihn persönlich zugänglich ist, oder ob es ein öffentliches Passwort ist und somit die normale Ordner-Vererbung der Rechte zum Tragen kommt.
<G-vec00106-002-s605><decide.entscheiden><en> Moreover, it added a humane dimension: the active self-help, self-determination, and the right to decide on the countries’ own food supplies.
<G-vec00106-002-s605><decide.entscheiden><de> Darüber hinaus kam eine menschliche Dimension hinzu: die aktive Selbsthilfe, die Selbstbestimmung und das Recht der Länder, über ihren eigenen Ernährungsbedarf selbst zu entscheiden.
<G-vec00106-002-s606><decide.entscheiden><en> Visitors can decide the extent to which they wish to abandon themselves to the illusion.
<G-vec00106-002-s606><decide.entscheiden><de> Der Besucher kann selbst entscheiden, wie weit er sich der Illusion hingibt.
<G-vec00106-002-s607><decide.entscheiden><en> You can decide which document to upload.
<G-vec00106-002-s607><decide.entscheiden><de> Sie können selbst entscheiden, welches Dokument Sie hochladen.
<G-vec00106-002-s627><decide.entscheiden><en> Even before you decide on a certain treatment, you can reserve your "well-being time frame."
<G-vec00106-002-s627><decide.entscheiden><de> Noch bevor Sie sich für eine bestimmte Behandlung entscheiden, können Sie Ihr "Wohlfühl-Zeitfenster" reservieren.
<G-vec00106-002-s628><decide.entscheiden><en> If you decide to utilize this tablet, it is important to adhere to the advised dosage and weight loss guidelines.
<G-vec00106-002-s628><decide.entscheiden><de> Wenn Sie sich entscheiden, diese Pille zu verwenden, ist es wichtig, die empfohlene Dosierung und Diäten Anweisungen zu folgen.
<G-vec00106-002-s629><decide.entscheiden><en> In order to choose the suitable system of sliding doors for you, you have to decide what models are currently offered in the building products market.
<G-vec00106-002-s629><decide.entscheiden><de> Um das für Sie geeignete System von Schiebetüren auszuwählen, müssen Sie sich entscheiden, welche Modelle derzeit auf dem Markt für Bauprodukte angeboten werden.
<G-vec00106-002-s630><decide.entscheiden><en> Before you decide to trade, you need to make sure that you understand the risks involved, taking into account your investment objectives and level of experience.
<G-vec00106-002-s630><decide.entscheiden><de> Bevor Sie sich für den Handel entscheiden, müssen Sie sicherstellen, dass Sie die damit verbundenen Risiken unter Berücksichtigung Ihrer Anlageziele und des Erfahrungsniveaus verstehen.
<G-vec00106-002-s631><decide.entscheiden><en> For the use of some contents it is necessary to provide us with personal information, for example if you wish to receive a newsletter or if you decide to support us with a donation..
<G-vec00106-002-s631><decide.entscheiden><de> Für die Verwendung einiger Inhalt es ist notwendig, uns persönliche Daten zur Verfügung stellen, beispielsweise um den Newsletter zu abonnieren oder wenn Sie sich entscheiden, uns mit einer Spende zu unterstützen.
<G-vec00106-002-s632><decide.entscheiden><en> If you decide to choose an orange color for your kitchen, you should know that it blends nicely with the dark color scheme.
<G-vec00106-002-s632><decide.entscheiden><de> Wenn Sie sich entscheiden, eine orange Farbe für Ihre Küche zu wählen, sollten Sie wissen, dass es sich gut mit dem dunklen Farbschema verbindet.
<G-vec00106-002-s633><decide.entscheiden><en> Even if deceased persons do not wish to cause any disagreement between the heirs with the will and decide that they shall inherit as provided by law (intestate succession), disputes that have a negative impact on family relations still occur in practice.
<G-vec00106-002-s633><decide.entscheiden><de> Auch wenn verstorbene Personen keine Entzweiung zwischen den Erben mit dem Testament hervorrufen möchten und sich entscheiden, dass sie wie gesetzlich vorgesehen erben sollen (gesetzliche Erbfolge), kommt es in der Praxis immer noch zu Streitigkeiten, die sich negativ auf die Familienbeziehungen auswirken.
<G-vec00106-002-s634><decide.entscheiden><en> In order to achieve a great bonus, you must decide which strategy fits better and go by that one.
<G-vec00106-002-s634><decide.entscheiden><de> Um einen guten Bonus zu erreichen müssen Sie sich entscheiden, welche Strategie besser passt und damit spielen.
<G-vec00106-002-s635><decide.entscheiden><en> Finally, when classifying the data, it should be borne in mind that many academic players in the knowledge market decide – as do many small and medium-sized companies – not to apply for protection of their intellectual property rights because of the high costs involved in patent applications, the issue of patents, and also the enforcement of patent rights.
<G-vec00106-002-s635><decide.entscheiden><de> Schließlich bleibt bei der Einordnung der Daten zu beachten, dass aufgrund der hohen Kosten einer Patentanmeldung, -erteilung und auch Patentrechtsdurchsetzung sich viele akademisch orientierte Wissensakteure ähnlich wie Mittelständler dazu entscheiden, keinen Schutz auf ihre intellektuellen Eigentumsrechte zu beantragen.
<G-vec00106-002-s636><decide.entscheiden><en> In the evening courses you can try the first session of a new group and then decide how you want to move forward.
<G-vec00106-002-s636><decide.entscheiden><de> In den Abendkursen können Sie nach vorheriger Absprache zu einer Probestunde in einen Standard-Gruppenkurs kommen und sich danach entscheiden, wie Sie weitermachen wollen.
<G-vec00106-002-s637><decide.entscheiden><en> If you decide to do the Camino de Santiago by bike, the Portuguese route that runs along the coast can be completed in just 5 days. Or even less.
<G-vec00106-002-s637><decide.entscheiden><de> Wenn Sie sich entscheiden, den Jakobsweg mit dem Fahrrad zu fahren, können Sie den portugiesischen Weg, der entlang der Küste verläuft, in nur 5 Tagen absolvieren, oder sogar weniger.
<G-vec00106-002-s638><decide.entscheiden><en> In your installation, you need to decide whether to install the configuration file at c:\usr\local\ssl\openssl.cnf or whether to install it someplace else and use environmental variables (possibly on a per-virtual-host basis) to locate the configuration file.
<G-vec00106-002-s638><decide.entscheiden><de> Damit diese Datei gefunden wird, müsssen Sie sich bei der Installation entscheiden, entweder die Konfigurationsdatei unter c:\usr\local\ssl\openssl.cnf anzulegen, oder diese Datei an einem anderen Ort abzulegen und Umgebungsvariablen zu benutzen (möglicherweise auf Basis verschiedener Virtual-Host Konfigurationen).
<G-vec00106-002-s639><decide.entscheiden><en> Also you can decide for a certain topic, e.g.
<G-vec00106-002-s639><decide.entscheiden><de> Auch können Sie sich für eine bestimmte Thematik entscheiden, z.
<G-vec00106-002-s640><decide.entscheiden><en> In the event of an emergency, if the owner does not object, the examining magistrate may decide within 14 days to release the animal for sale.
<G-vec00106-002-s640><decide.entscheiden><de> Handelt es sich um einen Notfall, kann der Untersuchungsrichter, falls der Besitzer keine Einwände erhebt, innerhalb einer Frist von 14 Tagen entscheiden, das Tier zum Verkauf freizugeben.
<G-vec00106-002-s641><decide.entscheiden><en> Here is a list of foods that should be excluded from the diet, if you decide that the salt-free diet is right for you: spices, bananas, jam, flour, cereals, grapes, pasta, sugar, salted, smoked, sour and spicy food, watermelons, lamb, fried foods, pork, confectionery and meat broths.
<G-vec00106-002-s641><decide.entscheiden><de> Hier ist eine Liste von Lebensmitteln, die aus der Ernährung ausgeschlossen werden sollen, wenn Sie sich entscheiden, dass die salzfreie Diät ist die richtige für Sie: Gewürze, Bananen, Marmelade, Mehl, Getreide, Trauben, Teigwaren, Zucker, gepökelt, geräuchert, sauer und scharfes Essen, Wassermelonen, Lamm, gebratene Lebensmittel, Schweinefleisch, Süßwaren und Fleischbrühe.
<G-vec00106-002-s642><decide.entscheiden><en> We want that every time you decide to go to a hotel, you do it with a smile and with the of satisfaction knowing that you have only paid for the time you will spend at the hotel.
<G-vec00106-002-s642><decide.entscheiden><de> Wir möchten, dass Sie jedes Mal, wenn Sie sich entscheiden, ein Hotel zu buchen, dies mit einem zufriedenen Lächeln tun, weil Sie wissen, dass Sie nur die Stunden zahlen, die Sie auch wirklich dort verbringen werden.
<G-vec00106-002-s643><decide.entscheiden><en> If you decide on a VISA course, you have various options which make your stay in Germany possible.
<G-vec00106-002-s643><decide.entscheiden><de> Wenn Sie sich für einen VISA-Kurs entscheiden, haben Sie verschiedene Möglichkeiten Ihren Aufenthalt in Deutschland zu gestalten.
<G-vec00106-002-s644><decide.entscheiden><en> As an HR manager, you must decide which method you want to use to get to know and test the candidates for the position for which you are responsible.
<G-vec00106-002-s644><decide.entscheiden><de> Als Personaler müssen Sie sich entscheiden, mit welcher Methode Sie die Kandidaten für die von Ihnen verantwortete Stelle kennenlernen und testen möchten.
<G-vec00106-002-s645><decide.entscheiden><en> Oyunu A kind of daughter can not decide what to wear.
<G-vec00106-002-s645><decide.entscheiden><de> Oyunu Eine Art Tochter kann sich nicht entscheiden, was zu tragen.
<G-vec00106-002-s646><decide.entscheiden><en> In case you decide in favor of a camper trip you will most likely witness the same as we did.
<G-vec00106-002-s646><decide.entscheiden><de> Wenn man sich für einen Campertrip entscheidet, wacht man hier in malerischer Natur auf.
<G-vec00106-002-s647><decide.entscheiden><en> If you decide to grow a garden, you must be able to imagine the final result even before you set the first plant.
<G-vec00106-002-s647><decide.entscheiden><de> Wenn man sich entscheidet, einen Garten anzubauen, muss man in der Lage sein, schon bevor man die erste Pflanze setzt, sich das Endergebnis vorstellen zu können.
<G-vec00106-002-s648><decide.entscheiden><en> And those who decide to work there, like Florentine Degen, have to come to terms with death.
<G-vec00106-002-s648><decide.entscheiden><de> Und wer sich entscheidet, dort zu arbeiten, wie Florentine Degen, muss sich mit dem Tod arrangieren.
<G-vec00106-002-s649><decide.entscheiden><en> It does not matter which series of fittings you decide on - the accessories harmoniously round off the overall impression of the kitchen.
<G-vec00106-002-s649><decide.entscheiden><de> Ganz gleich, für welche Armaturenserie man sich entscheidet, rundet das Zubehör das Gesamtbild der Küche stimmig ab.
<G-vec00106-002-s650><decide.entscheiden><en> If you decide to quit your job, you should deposit your retirement savings in a vested benefits account at an insurance company or bank.
<G-vec00106-002-s650><decide.entscheiden><de> Wer sich für eine Kündigung entscheidet, sollte das angesparte Altersguthaben auf einem Freizügigkeitskonto bei einer Versicherung oder Bank anlegen.
<G-vec00106-002-s651><decide.entscheiden><en> If you decide to use PVR images in your application, you should make sure that these images are only used on those devices that support them.
<G-vec00106-002-s651><decide.entscheiden><de> Wenn man sich für PVR-Grafiken entscheidet, muss zuvor sichergestellt werden, dass diese Grafiken nur auf jenen Mobilgeräten benutzt werden, die sie auch unterstützen.
<G-vec00106-002-s652><decide.entscheiden><en> The check mark (which indicates that the customer wants to purchase the add-on) is already set and can be removed by the customer if they decide not to buy the add-on product.
<G-vec00106-002-s652><decide.entscheiden><de> Der Auswahlhaken (der bestimmt, dass man das Addon zusätzlich kaufen möchte) ist dabei bereits gesetzt und kann vom Kunden entfernt werden, wenn sich gegen den Kauf des Addon-Produkts entscheidet.
<G-vec00106-002-s653><decide.entscheiden><en> Whether remote maintenance, technical on–site service or training courses with practical relevance for users in the most modern equipped training rooms: those who decide in favour of a HEUFT system can rely on its long–term availability.
<G-vec00106-002-s653><decide.entscheiden><de> Ob Fernwartung, technischer Vor–Ort–Service oder praxisnahe Anwendertrainings in modern ausgestatteten Schulungsräumen: Wer sich für ein HEUFT–System entscheidet, kann sich auf dessen langfristige Verfügbarkeit verlassen.
<G-vec00106-002-s654><decide.entscheiden><en> If any of our friends / work colleagues decide to holiday in Spain next year, I shall have Tourism Golf In Malaga
<G-vec00106-002-s654><decide.entscheiden><de> Falls einer unserer Freunde oder Kollegen sich für einen Urlaub in Spanien nächstes Jahr entscheidet, werde ich nicht zögern Sie zu empfehlen.
<G-vec00106-002-s655><decide.entscheiden><en> But if you decide on drugs and alcohol, then your route is predestined.
<G-vec00106-002-s655><decide.entscheiden><de> Aber wenn man sich nur für Drogen und Alkohol entscheidet, dann ist der Weg vorgeplant.
<G-vec00106-002-s656><decide.entscheiden><en> This way of accommodation is a long-time classic… and with a reason: If you decide for accommodation in a host family you will also learn German after class – very individually and completely relaxed – by being a new member of the family… We also take care that you share your room only with a student who has a different native language – in order to make sure that you can really speak German all day long.
<G-vec00106-002-s656><decide.entscheiden><de> Diese Wohnmöglichkeit ist seit langer Zeit ein Klassiker… und das hat vor allem einen Grund: Wer sich für die Unterkunft in einer Gastfamilie entscheidet, der lernt auch nach dem Unterricht noch Deutsch – ganz entspannt und sehr persönlich – als neues Mitglied der Familie… Und damit Sie auch wirklich nur Deutsch sprechen, achten wir darauf, dass Sie Ihr Zimmer mit einem Mitschüler anderer Muttersprache teilen.
<G-vec00106-002-s657><decide.entscheiden><en> You should know what you're getting into when you decide on a vacation in this place, of course.
<G-vec00106-002-s657><decide.entscheiden><de> Man sollte natürlich wissen, worauf man sich einlässt, wenn man sich für einen Urlaub an diesem Ort entscheidet.
<G-vec00106-002-s658><decide.entscheiden><en> At some stage everyone comes to a point, where you have to decide if you are driven by something, or if you want to be the driving force behind others.
<G-vec00106-002-s658><decide.entscheiden><de> Irgendwann kommt jeder an einen Punkt, an dem man sich entscheidet anzutreiben oder angetrieben zu werden.
<G-vec00106-002-s659><decide.entscheiden><en> Remaining uncertain in this area is a suboptimal choice — it’s better to decide one way or the other and be wrong than it is to remain uncertain and do nothing.
<G-vec00106-002-s659><decide.entscheiden><de> Sich mit der Unsicherheit zufrieden zugeben ist eine suboptimale Wahl – es ist besser, wenn man sich für die eine oder andere Option entscheidet und falsch liegt, als wenn man einfach verharrt und gar nichts macht.
<G-vec00106-002-s660><decide.entscheiden><en> Those who decide to study Informatics should possess solid mathematical skills as mathematical contents make up a large proportion of the programme.
<G-vec00106-002-s660><decide.entscheiden><de> Wer sich für ein Studium der Informatik entscheidet, sollte solide mathematische Kenntnisse mitbringen, da mathematische Inhalte einen hohen Anteil des Studiums ausmachen.
<G-vec00106-002-s661><decide.entscheiden><en> The “occasional marketplace fan” prefers to roam undetected through the Internet shopping arcades, and likes to compare prices and quality before they decide.
<G-vec00106-002-s661><decide.entscheiden><de> Der "gelegentliche Marktplatz-Fan" streift am liebsten unerkannt durch die Ladenpassagen im Netz und vergleicht gerne Preise und Produktqualität, bevor er sich entscheidet.
<G-vec00106-002-s662><decide.entscheiden><en> Those who decide to live life as a witch end up in a “witch house.”
<G-vec00106-002-s662><decide.entscheiden><de> Wer sich für das Leben als Hexe entscheidet, endet in einem «Hexenhaus».
<G-vec00106-002-s663><decide.entscheiden><en> These are fragile moments that decide whether an agreement is reached and whether new orders come about.
<G-vec00106-002-s663><decide.entscheiden><de> Es sind fragile Momente, in denen sich entscheidet, ob es zu einer Verständigung kommt, ob neue Ordnungen entstehen.
<G-vec00106-002-s664><decide.entscheiden><en> If you decide to purchase Crea Shot you can be sure that the creatine will not be converted in to the unnecessary and ineffective creatinine. It will also not place a burden on the own organism.
<G-vec00106-002-s664><decide.entscheiden><de> Wer sich für das Kaufen von Crea Shot entscheidet, kann sich somit sicher sein, dass das Creatin nicht in das überflüssige und wirkungslose Creatinin umgewandelt wird und damit auch nicht den eigenen Organismus belastet.
<G-vec00106-002-s665><decide.entscheiden><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00106-002-s665><decide.entscheiden><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00106-002-s666><decide.entscheiden><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00106-002-s666><decide.entscheiden><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00106-002-s667><decide.entscheiden><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00106-002-s667><decide.entscheiden><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00106-002-s668><decide.entscheiden><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00106-002-s668><decide.entscheiden><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00106-002-s669><decide.entscheiden><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00106-002-s669><decide.entscheiden><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00106-002-s670><decide.entscheiden><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00106-002-s670><decide.entscheiden><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00106-002-s671><decide.entscheiden><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00106-002-s671><decide.entscheiden><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00106-002-s672><decide.entscheiden><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00106-002-s672><decide.entscheiden><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00106-002-s673><decide.entscheiden><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00106-002-s673><decide.entscheiden><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00106-002-s674><decide.entscheiden><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00106-002-s674><decide.entscheiden><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00106-002-s675><decide.entscheiden><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00106-002-s675><decide.entscheiden><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00106-002-s676><decide.entscheiden><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00106-002-s676><decide.entscheiden><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00106-002-s677><decide.entscheiden><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00106-002-s677><decide.entscheiden><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00106-002-s678><decide.entscheiden><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00106-002-s678><decide.entscheiden><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00106-002-s679><decide.entscheiden><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00106-002-s679><decide.entscheiden><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00106-002-s680><decide.entscheiden><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00106-002-s680><decide.entscheiden><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00106-002-s681><decide.entscheiden><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00106-002-s681><decide.entscheiden><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00106-002-s682><decide.entscheiden><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00106-002-s682><decide.entscheiden><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00106-002-s683><decide.entscheiden><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00106-002-s683><decide.entscheiden><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00106-002-s760><decide.entscheiden><en> Of course a baby can’t decide what color it wants for its clothes and surroundings.
<G-vec00106-002-s760><decide.entscheiden><de> Ein Baby kann ja nicht über die Farbe seiner Kleidung und Umgebung entscheiden.
<G-vec00106-002-s761><decide.entscheiden><en> America is not a place where chance of birth or circumstance should decide our destiny.
<G-vec00106-002-s761><decide.entscheiden><de> Die Vereinigten Staaten sind kein Land, in dem die Herkunft oder die Umstände über das Schicksal entscheiden sollten.
<G-vec00106-002-s762><decide.entscheiden><en> You can set your browser so that you are informed about the setting of cookies and individually decide whether to accept or refuse cookies in specific cases or in general.
<G-vec00106-002-s762><decide.entscheiden><de> Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und einzeln über deren Annahme entscheiden oder die Annahme von Cookies für bestimmte Fälle oder generell ausschließen.
<G-vec00106-002-s763><decide.entscheiden><en> In the next few months, the European Commission will be assessing the impact of the Roaming Regulation and, depending on developments in the market, will decide whether the Regulation should be extended in time and scope to cover SMS and MMS messaging and the transfer of data.
<G-vec00106-002-s763><decide.entscheiden><de> Die Kommission wird die Wirksamkeit der Roamingverordnung in den kommenden Monaten bewerten und auf der Grundlage der Marktentwicklungen über eine Verlängerung des Geltungszeitraums und eine Ausweitung des Anwendungsbereichs auf SMS, MMS und Datenübertragungen entscheiden.
<G-vec00106-002-s764><decide.entscheiden><en> But it is September and October sunshine and rainfall which decide of the vintage quality.
<G-vec00106-002-s764><decide.entscheiden><de> Es sind jedoch die Sonneneinstrahlung und die Niederschlagsmengen in den Monaten September & Oktober, die über die Qualität des Jahrgangs entscheiden.
<G-vec00106-002-s765><decide.entscheiden><en> These are the ones who decide success in the overall picture.
<G-vec00106-002-s765><decide.entscheiden><de> Diese sind es, die im Gesamtbild über den Erfolg entscheiden.
<G-vec00106-002-s766><decide.entscheiden><en> In order to enable the Commission to decide whether sampling is necessary, and if so, to select a sample, all exporting producers, or representatives acting on their behalf, are hereby requested to make themselves known to the Commission.
<G-vec00106-002-s766><decide.entscheiden><de> Damit die Kommission über die Notwendigkeit eines Stichprobenverfahrens entscheiden und gegebenenfalls eine Stichprobe bilden kann, werden alle ausführenden Hersteller oder die in ihrem Namen handelnden Vertreter hiermit gebeten, der Kommission binnen 7 Tagen nach Veröffentlichung dieser Bekanntmachung die in Anhang I erbetenen Angaben zu ihren Unternehmen vorzulegen.
<G-vec00106-002-s767><decide.entscheiden><en> In the end, I’m committed to the idea that five hundred million people should decide the future of Europe. Not twenty-eight people.
<G-vec00106-002-s767><decide.entscheiden><de> Letztendlich bin ich überzeugt, dass 500 Millionen Menschen über die Zukunft Europas entscheiden sollten, und nicht bloß achtundzwanzig Personen.
<G-vec00106-002-s768><decide.entscheiden><en> An example of such Flickr Managing Cookies Notwithstanding the foregoing, Users can set up their browser to accept or reject all cookies by default or receive an on-screen notification when receiving each cookie and decide there and then whether to allow it access to their hard drive.
<G-vec00106-002-s768><decide.entscheiden><de> Unbeschadet der obigen Erläuterungen hat der Benutzer die Möglichkeit, seinen Browser so zu konfigurieren, dass alle Cookies standardmäßig akzeptiert oder abgelehnt werden, oder um eine Meldung auf dem Bildschirm bei Erhalt eines Cookies anzuzeigen und in diesem Moment über seine Speicherung auf der Festplatte zu entscheiden.
<G-vec00106-002-s770><decide.entscheiden><en> To be on the safe side the regents wanted to let the crown council decide the question of the European astronomy.
<G-vec00106-002-s770><decide.entscheiden><de> Die Regenten suchten sich zu sichern, indem sie den Kronrat über die Frage der europäischen Astronomie entscheiden lassen wollten.
<G-vec00106-002-s771><decide.entscheiden><en> In the larger factories of all important industrial centres the establishment of workers’ committees has, as if by itself, taken place, with which alone the employer negotiates and which decide all disputes.
<G-vec00106-002-s771><decide.entscheiden><de> In den größten Fabriken aller wichtigsten Industriezentren hat sich wie von selbst die Einrichtung der Arbeiterausschüsse gebildet, mit denen allein der Unternehmer verhandelt, die über alle Konflikte entscheiden.
<G-vec00106-002-s772><decide.entscheiden><en> The Sailor War will decide the destiny of the galaxie.
<G-vec00106-002-s772><decide.entscheiden><de> In der Zukunft wird der Krieg der Sailor Senshi über das Schicksal der Galaxie entscheiden.
<G-vec00106-002-s773><decide.entscheiden><en> As the EU decides whether to expand its special trade relationship with Israel, as Obama and the US Congress set next year's budget for Israeli military aid, and as neighbours like Turkey and Egypt decide their next diplomatic steps -- let's make the world's voice unignorable: it's time for truth and accountability on the flotilla raid, and it's time for Israel to comply with international law and end the siege of Gaza.
<G-vec00106-002-s773><decide.entscheiden><de> Während die EU beschliesst, ob sie ihre besonderen Handelsbeziehungen mit Israel erweitert, Obama und der US-Kongress über die Ausgaben für die israelische Militärhilfe im kommenden Jahr beraten und Nachbarstaaten wie die Türkei und Ägypten über ihre nächsten diplomatischen Schritte entscheiden - Lasst uns die Stimme der Weltöffentlichkeit unüberhörbar machen: Es ist Zeit die Wahrheit über den Angriff zu erfahren, Rechenschaft zu verlangen und es ist höchste Zeit, dass Israel das Völkerrecht respektiert und die Blockade des Gaza-Streifens beendet.
<G-vec00106-002-s774><decide.entscheiden><en> But in all these cases, the terrible truth is that it is the strong who decide the fate of the weak; human beings therefore become instruments in the hands of other human beings.
<G-vec00106-002-s774><decide.entscheiden><de> Aber in all diesen Fällen sieht die nackte Wahrheit so aus, dass die Starken über das Schicksal der Schwachen entscheiden; die Menschen werden somit zu Werkzeugen in den Händen anderer Menschen.
<G-vec00106-002-s775><decide.entscheiden><en> If you intend to decide on the transfer option after receiving your letter of admission, please inform Mr. Rademacher when submitting your application.
<G-vec00106-002-s775><decide.entscheiden><de> Möchten Sie über Ihre Wechselabsichten erst nach Erhalt der Zulassung entscheiden, informieren Sie bitte Herrn Rademacher bei Abgabe der Bewerbung.
<G-vec00106-002-s776><decide.entscheiden><en> You and your companions may very well decide the fate of the world.
<G-vec00106-002-s776><decide.entscheiden><de> Dabei könnten sie durchaus über das Schicksal der Welt entscheiden.
<G-vec00106-002-s777><decide.entscheiden><en> Moreover, these units must be authorised to decide how funds are to be spent with regard to their tasks.
<G-vec00106-002-s777><decide.entscheiden><de> Außerdem müssen sie die Befugnis besitzen, mit Blick auf ihre Aufgaben über die Mittelverwendung zu entscheiden.
<G-vec00106-002-s778><decide.entscheiden><en> It is the workers who decide the matters at issue and carry their decisions out through the shop committees.
<G-vec00106-002-s778><decide.entscheiden><de> Es sind die Arbeiter, die über strittige Fragen entscheiden und ihre Entscheidungen durch den Werksausschuß ausführen.
<G-vec00106-002-s095><decide.sich_entscheiden><en> If you change the staging status in the last document line, you decide in a system message whether the staging status in the document header is automatically changed as well.
<G-vec00106-002-s095><decide.sich_entscheiden><de> Wenn Sie den Kommissionierstatus in der letzten Belegposition ändern, dann entscheiden Sie in einer Systemmeldung, ob auch der Kommissionierstatus im Belegkopf automatisch geändert wird.
<G-vec00106-002-s096><decide.sich_entscheiden><en> He will review your work and decide if you are right for us.
<G-vec00106-002-s096><decide.sich_entscheiden><de> Sie wird einen Blick auf Ihre Projekte werfen und dann entscheiden, ob Sie zu uns passen.
<G-vec00106-002-s097><decide.sich_entscheiden><en> Once these samples have been produced, the artist can decide upon the technique or the type of glass that will be used for the development of the draft.
<G-vec00106-002-s097><decide.sich_entscheiden><de> Nach der Anfertigung der Musterscheiben kann dann der Künstler entscheiden in welcher Technik oder Glasart der Entwurf zur Umsetzung kommt.
<G-vec00106-002-s098><decide.sich_entscheiden><en> Unless the term of the suspended Board Member ends according to the Charter, the association's members decide upon the dismissal from the Supervisory Board.
<G-vec00106-002-s098><decide.sich_entscheiden><de> Sofern die Amtszeit des beurlaubten Präsidiumsmitglieds dann nicht sowieso endet, entscheiden die Vereinsmitglieder über eine Abberufung aus dem Präsidium.
<G-vec00106-002-s099><decide.sich_entscheiden><en> If the staging suggestion contains such document lines, you decide in a system message whether the staging suggestion still is to be posted.
<G-vec00106-002-s099><decide.sich_entscheiden><de> Wenn der Kommissioniervorschlag solche Belegpositionen enthält, dann entscheiden Sie in einer Systemmeldung, ob der Kommissioniervorschlag trotzdem verbucht wird.
<G-vec00106-002-s100><decide.sich_entscheiden><en> Also on this area Dusseldorf has much to offer and problems arise only if we cannot decide at the abundance of alternatives.
<G-vec00106-002-s100><decide.sich_entscheiden><de> Auch davon hat Düsseldorf viel zu bieten und Probleme entstehen nur dann, wenn wir uns bei der Fülle von Alternativen nicht entscheiden können.
<G-vec00106-002-s101><decide.sich_entscheiden><en> There you can decide if you spend the time of the break watching the market or taking a Cafe con leche at the Place.
<G-vec00106-002-s101><decide.sich_entscheiden><de> Dort kannst du dann entscheiden, ob du lieber über den Markt schlenderst oder an der Place bei einem Cafe con leche dem bunten Treiben zuschaust.
<G-vec00106-002-s102><decide.sich_entscheiden><en> If the day comes when we decide we want to become a pop band, that will be no ones choice but our own.
<G-vec00106-002-s102><decide.sich_entscheiden><de> Wenn der Tag kommt, an dem wir eine Pop Band sein wollen, dann hat das niemand außer uns zu entscheiden.
<G-vec00106-002-s103><decide.sich_entscheiden><en> 3. By way of derogation from paragraph 2 and notwithstanding the fact that a parent undertaking does not meet the conditions established in Article 18(1), the Board may decide on resolution action with regard to that parent undertaking when one or more of its subsidiaries which are institutions meet the conditions established in Article 18(1), (4) and (5) and their assets and liabilities are such that their failure threatens an institution or the group as a whole and resolution action with regard to that parent undertaking is necessary for the resolution of such subsidiaries which are institutions or for the resolution of the group as a whole.
<G-vec00106-002-s103><decide.sich_entscheiden><de> (3) Abweichend von Absatz 2 kann der Ausschuss auch dann, wenn ein Mutterunternehmen die in Artikel 18 Absatz 1 genannten Voraussetzungen nicht erfüllt, über eine Abwicklungsmaßnahme in Bezug auf dieses Mutterunternehmen entscheiden, sofern ein oder mehrere seiner Tochterunternehmen, bei denen es sich um Institute handelt, die in Artikel 18 Absätze 1, 4 und 5 genannten Voraussetzungen erfüllen, ihre Vermögenswerte und Verbindlichkeiten so beschaffen sind, dass ihr Ausfall eine Bedrohung für ein Institut oder die Gruppe als Ganzes bewirkt, und eine Abwicklungsmaßnahme in Bezug auf dieses Mutterunternehmen für die Abwicklung solcher Tochterunternehmen, bei denen es sich um Institute handelt, oder für die Abwicklung der Gruppe als Ganzes erforderlich ist.
<G-vec00106-002-s104><decide.sich_entscheiden><en> For each change, you can decide for yourself whether you want to accept or reject it.
<G-vec00106-002-s104><decide.sich_entscheiden><de> Sie können dann für jede einzelne Änderung selbst entscheiden, ob Sie diese annehmen oder ablehnen möchten.
<G-vec00106-002-s105><decide.sich_entscheiden><en> They can now decide, what you would like to do with the found files.
<G-vec00106-002-s105><decide.sich_entscheiden><de> Sie können dann entscheiden, was Sie mit den Duplikaten machen möchten.
<G-vec00106-002-s106><decide.sich_entscheiden><en> Whether the claims are true or not, you have to decide for yourself.
<G-vec00106-002-s106><decide.sich_entscheiden><de> Ob man die gezeigte Darstellung hinterher glaubt oder nicht, muss man dann selbst entscheiden.
<G-vec00106-002-s107><decide.sich_entscheiden><en> It will lead you to the north shore where you can decide for yourself if you prefer walking through a cute little grove or rather stroll along the promenade.
<G-vec00106-002-s107><decide.sich_entscheiden><de> Die führt Dich direkt zum Nordufer, wo Du dann entscheiden kannst, ob Du lieber durch ein kleines Wäldchen spazieren oder an der Allee entlang flanieren möchtest.
<G-vec00106-002-s108><decide.sich_entscheiden><en> Afterwards, you get to decide whether you want to buy the Sion or not.
<G-vec00106-002-s108><decide.sich_entscheiden><de> Nach der Probefahrt kannst du dann entscheiden, ob du den Sion kaufen willst oder nicht.
<G-vec00106-002-s109><decide.sich_entscheiden><en> After the exhibition has opened a jury will decide on a winner.
<G-vec00106-002-s109><decide.sich_entscheiden><de> Eine Jury wird dann entscheiden, wer den Preis der Nationalgalerie gewinnt.
<G-vec00106-002-s110><decide.sich_entscheiden><en> And last, but not least, is up to player to decide which seven soldiers from the pool will be the best squad for the mission.
<G-vec00106-002-s110><decide.sich_entscheiden><de> Zu guter Letzt muss der Spieler dann entscheiden, welche sieben Söldner aus der Auswahl am besten geeignet sind für das Team dieser Mission.
<G-vec00106-002-s111><decide.sich_entscheiden><en> If a patient has already been diagnosed with a disease, his or her doctor may decide to use Hair Element Analysis as an auxiliary method to achieve better results of treatment.
<G-vec00106-002-s111><decide.sich_entscheiden><de> Falls eine Krankheit bei dem Patienten schon früher festgestellt wurde, dann kann der Arzt entscheiden, die Haar-Mineralstoff-Analyse als eine Hilfsmethode zu besseren Behandlungsergebnissen zu verwenden.
<G-vec00106-002-s112><decide.sich_entscheiden><en> If the associations differ, you decide in a system message which association is to be adopted into the target document.
<G-vec00106-002-s112><decide.sich_entscheiden><de> Wenn der Verband abweicht, dann entscheiden Sie in einer Systemmeldung, welcher Verband in den Zielbeleg übernommen wird.
<G-vec00106-002-s113><decide.sich_entscheiden><en> (2) YOUR CHOICE AND USE OF ChatGF IS AT YOUR SOLE RISK, INCLUDING YOUR SELF-SELECTION OF ONLINE GIRLS FROM THE AVAILABLE LIST, DONE IN YOUR FULL AUTONOMY WITH NO INTERFERENCES FROM ChatGF, WHO DO NOT RECOMMEND YOU ANY SPECIFIC ONLINE GIRL OR GROUP OF THEM, BUT JUST PROVIDE SCHEDULE SOFTWARE THAT IS USED BY ONLINE GIRLS AUTONOMOUSLY TO PUBLISH THE TIMES AND DATES WHEN THEY CAN AND WISH TO DO VIDEO CHATS, THAT YOU MAY DECIDE TO ATTEND.
<G-vec00106-002-s113><decide.sich_entscheiden><de> (2) IHRE WAHL UND BENUTZUNG VON ChatGF IST ALLEIN IHR RISIKO, EINSCHLIESSLICH IHRER EIGENEN AUSWAHL VON ONLINE GIRLS AUS DER LISTE DER VERFÜGBAREN, DIE SIE VÖLLIG EIGENSTÄNDIG OHNE EINMISCHUNG VON ChatGF TREFFEN, DIE IHNEN KEIN BESTIMMTES ONLINE GIRL ODER EINE GRUPPE VON IHNEN EMPFEHLEN, SONDERN NUR DIE TERMINIERUNGS-SOFTWARE ZUR VERFÜGUNG STELLEN, DIE VON DEN ONLINE GIRLS EIGENSTÄNDIG DAZU BENUTZT WIRD, UM DIE ZEITEN UND DATEN ZU VERÖFFENTLICHEN, WANN SIE VIDEO-CHATS MACHEN KÖNNEN UND WOLLEN, DIE SIE DANN ENTSCHEIDEN KÖNNEN ZU BESUCHEN.
<G-vec00106-002-s114><decide.sich_entscheiden><en> Furthermore, you can set there your browser in such a way that you are informed about the placement of cookies as well as to be able to decide in each individual case whether you would like to accept a given cookie or not.
<G-vec00106-002-s114><decide.sich_entscheiden><de> Ferner können Sie Ihren Browser dort so einstellen, dass Sie über das Setzen von Cookies informiert werden und jeweils im Einzelnen darüber entscheiden können, ob Sie ein Cookie annehmen möchten oder nicht.
<G-vec00106-002-s115><decide.sich_entscheiden><en> Combining these services with our software solutions, customers can freely decide to utilize our engineering services solely or to institute smoothly in- house solutions based on their particular applications we already analyzed for them.
<G-vec00106-002-s115><decide.sich_entscheiden><de> Die Kombination von Dienstleistungen mit unseren Software- Lösungen ermöglicht dem Kunden, frei darüber zu entscheiden, unsere Engineering- Dienstleistungen ausschließlich in Anspruch zu nehmen oder nahtlos firmeninterne Berechnungstools einzuführen, die dann bereits auf kundenspezifischen Anwendungsfällen beruhen.
<G-vec00106-002-s116><decide.sich_entscheiden><en> In the present appeal proceedings, the board must decide whether the third party which claims to have replaced the appellants in these proceedings as their successor in title is right in maintaining that the appeal was never validly withdrawn.
<G-vec00106-002-s116><decide.sich_entscheiden><de> Die Kammer hat im anhängigen Beschwerdeverfahren darüber zu entscheiden, ob der Dritte, der als Rechtsnachfolger in das Beschwerdeverfahren als Beschwerdeführer eingetreten zu sein geltend macht, die Wirksamkeit der Rücknahme der Beschwerde zu Recht bestreitet.
<G-vec00106-002-s117><decide.sich_entscheiden><en> You can decide for yourself what information to send us in the contact form.
<G-vec00106-002-s117><decide.sich_entscheiden><de> Sie können selbst darüber entscheiden, welche Information Sie uns über das Kontaktformular übermitteln.
<G-vec00106-002-s118><decide.sich_entscheiden><en> You can decide for yourself which information you want to give us about the contact options.
<G-vec00106-002-s118><decide.sich_entscheiden><de> Sie können selbst darüber entscheiden, welche Information Sie uns über die Kontaktmöglichkeiten übermitteln.
<G-vec00106-002-s119><decide.sich_entscheiden><en> The 1920s will decide whether we still play a role in the world.
<G-vec00106-002-s119><decide.sich_entscheiden><de> Die 20er Jahre werden darüber entscheiden, ob wir in der Welt noch eine Rolle spielen.
<G-vec00106-002-s120><decide.sich_entscheiden><en> And the only thing that can be done when telling people that their place of birth is a mere coincidence (and not a merit) and that this coincidence does not hold the exclusive right to decide who may step on this part of earth and who may not, is to tell all the individual stories.
<G-vec00106-002-s120><decide.sich_entscheiden><de> Und alles, was wir tun können, ist diese Geschichten von Menschen zu erzählen und damit deutlich zu sagen, dass wir per Geburt, also durch reinen Zufall (und nicht weil wir es verdient haben), zu unserer Heimat gekommen sind, und dass dieser Zufall nicht das Recht beinhaltet, darüber zu entscheiden, wer diesen Teil der Erde außerdem betreten darf, und wer nicht.
<G-vec00106-002-s121><decide.sich_entscheiden><en> To find out how these insects decide whether or not to take up a challenger, Guillermo-Ferreira and his colleagues conducted fieldwork at a stream in Sao Paulo State in Brazil.
<G-vec00106-002-s121><decide.sich_entscheiden><de> Guillermo-Ferreira und seine Kolleginnen und Kollegen führten an einem Fluss im Bundesstaat Sao Paulo in Brasilien einen Feldversuch durch, um herauszufinden, wie diese Insekten darüber entscheiden, ob sie sich in einen Kampf mit einem Rivalen begeben oder nicht.
<G-vec00106-002-s122><decide.sich_entscheiden><en> Europeans will continue to decide for themselves how they want, for example, their healthcare, education and water delivered.
<G-vec00106-002-s122><decide.sich_entscheiden><de> So werden die Menschen in Europa nach wie vor selbst darüber entscheiden, wie etwa Dienstleistungen in den Bereichen Gesundheit, Bildung und Wasserversorgung erbracht werden sollen.
<G-vec00106-002-s123><decide.sich_entscheiden><en> And in this regards, it was planned that the people of Western Sahara were to take part in a referendum, to decide themselves how the territory was to be governed in the future.
<G-vec00106-002-s123><decide.sich_entscheiden><de> Und hierzu war geplant, dass die Bevölkerung der Westsahara an einem Referendum teilnehmen sollte, um selbst darüber zu entscheiden, wie das Gebiet in Zukunft zu regieren sei.
<G-vec00106-002-s124><decide.sich_entscheiden><en> Soft skills and personality are the key criteria for employers to decide which candidates will receive a job offer.
<G-vec00106-002-s124><decide.sich_entscheiden><de> Soft Skills und Persönlichkeit sind die ausschlaggebenden Kriterien für Arbeitgeber, die darüber entscheiden welche Kandidaten ein Jobangebot erhalten.
<G-vec00106-002-s125><decide.sich_entscheiden><en> It is the way you implement your plans that will decide whether you make it big or not.
<G-vec00106-002-s125><decide.sich_entscheiden><de> Es ist die Art und Weise, wie du deine Pläne umsetzt, die darüber entscheiden wird, ob du dort groß rauskommst oder nicht.
<G-vec00106-002-s126><decide.sich_entscheiden><en> – Constitution and legal laws: The constitution of a country indicates which state entity or person has the power to decide whether or not to go to war.
<G-vec00106-002-s126><decide.sich_entscheiden><de> Verfassung und Gesetze: Die Verfassung eines Landes gibt vor, welche staatliche Institution oder Person darüber entscheiden kann, ob das Land in den Krieg zieht.
<G-vec00106-002-s127><decide.sich_entscheiden><en> Just for a split-second before reviving, I was struggling with whether I wanted to come back or not, but I felt it wasn't up to me to decide that.
<G-vec00106-002-s127><decide.sich_entscheiden><de> Nur für den Bruchteil einer Sekunde bevor ich wieder lebte, kämpfte ich damit ob ich zurückkommen wollte oder nicht, aber ich spürte dass es nicht an mir war darüber zu entscheiden.
<G-vec00106-002-s128><decide.sich_entscheiden><en> Google can decide whether or not to use the information for other Google services.
<G-vec00106-002-s128><decide.sich_entscheiden><de> Google kann darüber entscheiden, ob es diese Informationen für andere Google-Services übernimmt oder nicht.
<G-vec00106-002-s129><decide.sich_entscheiden><en> Wolfgang Ketzler does the suggestion to decide on it today, if nobody of the present is against it, although no written proposition is available, since the club was already a member earlier.
<G-vec00106-002-s129><decide.sich_entscheiden><de> Wolfgang Ketzler macht den Vorschlag, heute darüber zu entscheiden, wenn niemand der Anwesenden dagegen ist, obwohl kein schriftlicher Antrag vorliegt, da der Klub früher schon Mitglied war.
<G-vec00106-002-s130><decide.sich_entscheiden><en> The heeling at a sports event can already decide after the first 10-20 steps, if the interested spectator leaves the terraces after the protection service bored or whether he stays tensely left in the expectation of a terrific performance.
<G-vec00106-002-s130><decide.sich_entscheiden><de> Die Freifolge an einer Sportveranstaltung, kann bereits nach den ersten 10-20 Schritten darüber entscheiden, ob der interessierte Zuschauer nach dem Schutzdienst gelangweilt sich von der Tribüne entfernt, oder ob er gespannt sitzen bleibt in der Erwartung einer tollen Leistung.
<G-vec00106-002-s131><decide.sich_entscheiden><en> The parents have decided to defer all medically unnecessary surgeries until their child can decide for herself.
<G-vec00106-002-s131><decide.sich_entscheiden><de> Die Eltern haben entschieden, dass sie jegliche unnötige Operationen aufschieben, bis ihr Kind darüber selbst entscheiden kann.
<G-vec00106-002-s132><decide.sich_entscheiden><en> Each newsletter begins with the subject, and it can decide on whether the message is ever taken note of or not.
<G-vec00106-002-s132><decide.sich_entscheiden><de> Folgen Jeder Newsletter beginnt mit der Betreffzeile und diese kann darüber entscheiden, ob die Nachricht überhaupt zur Kenntnis genommen wird oder nicht.
<G-vec00106-002-s152><decide.sich_entscheiden><en> For long journeys and training camps we recommend our roller bags and trolleys with a capacity of up to 100 liters (if you can't decide on the right shoes before heading out).
<G-vec00106-002-s152><decide.sich_entscheiden><de> Für lange Reisen und Trainingslager empfehlen wir Dir unsere Rollentaschen und Trolleys mit bis zu 100 Liter Fassungsvermögen (Wenn Du dich vor der Abfahrt mal wieder nicht für die richtigen Schuhe entscheiden kannst).
<G-vec00106-002-s153><decide.sich_entscheiden><en> At last you can decide to integrate yourself into Grigori Grabovoi’s structure also as a volunteer, as an agent and as a publisher.
<G-vec00106-002-s153><decide.sich_entscheiden><de> Letztendlich kannst Du Dich entscheiden, Dich in Grigori Grabovois Struktur auch als Ehrenamtlicher, als Repräsentant und als Verleger zu integrieren.
<G-vec00106-002-s154><decide.sich_entscheiden><en> You can even decide never to give your phone number to anyone again.
<G-vec00106-002-s154><decide.sich_entscheiden><de> Du kannst dich sogar entscheiden, deine Telefonnummer nie wieder an jemanden weiterzugeben.
<G-vec00106-002-s155><decide.sich_entscheiden><en> If drinking is happening at your home, you need to decide how you want to run it.
<G-vec00106-002-s155><decide.sich_entscheiden><de> Wenn bei dir zu Hause getrunken wird, musst du dich entscheiden, wie das ablaufen soll.
<G-vec00106-002-s156><decide.sich_entscheiden><en> On each turn, you roll the dice, and then decide which box is the best for your scores.
<G-vec00106-002-s156><decide.sich_entscheiden><de> In jedem Zug würfelst du und kannst dich dann für ein Feld entscheiden, in das deine Punkte am besten passen.
<G-vec00106-002-s157><decide.sich_entscheiden><en> You now have to decide.
<G-vec00106-002-s157><decide.sich_entscheiden><de> Jetzt musst du dich entscheiden.
<G-vec00106-002-s158><decide.sich_entscheiden><en> If you decide to master with TMF NET, quite naturally will 100% of all rights remain with you.
<G-vec00106-002-s158><decide.sich_entscheiden><de> Solltest du dich für ein Mastering von TMF NET entscheiden, bleiben natürlich alle Rechte zu 100% bei dir.
<G-vec00106-002-s159><decide.sich_entscheiden><en> If you decide not to use Feiyr, you do not have to pay anything.
<G-vec00106-002-s159><decide.sich_entscheiden><de> Solltest Du Dich entscheiden, Dein Feiyr Konto nicht zu nutzen, musst Du nichts bezahlen.
<G-vec00106-002-s160><decide.sich_entscheiden><en> When you have reviewed the Certification Preparation Packet you may decide to contact an assessor or assessors of your choosing to explore a mutual agreement to work together.
<G-vec00106-002-s160><decide.sich_entscheiden><de> Wenn du das CNVC-Programm zur Vorbereitung der Zertifizierung (CPP) durchgelesen hast, kannst du dich entscheiden, einen Assessor oder eine Assessorin deiner Wahl zu kontaktieren, um eine gegenseitige Vereinbarung zur Zusammenarbeit zu finden.
<G-vec00106-002-s161><decide.sich_entscheiden><en> You have to decide really quickly as the clock is ticking, but keep in mind that a mistake would be fatal.
<G-vec00106-002-s161><decide.sich_entscheiden><de> Du musst dich schnell entscheiden, denn die Zeit läuft, aber denk daran, ein Fehler wäre tödlich.
<G-vec00106-002-s162><decide.sich_entscheiden><en> You’re taking too long to decide.
<G-vec00106-002-s162><decide.sich_entscheiden><de> Du brauchst zu lange, um dich zu entscheiden.
<G-vec00106-002-s163><decide.sich_entscheiden><en> Everything is very easy with fashionette: You order without shipping charges and have an entire 30 days to decide if you want to keep the product – if not, return is also naturally gratis.
<G-vec00106-002-s163><decide.sich_entscheiden><de> Mit Fashionette ist alles ganz easy: Du bestellst versandkostenfrei und hast ganze 30 Tage, um dich zu entscheiden, ob du die Produkte behalten möchtest – falls nicht, ist der Rückversand selbstverständlich auch gratis.
<G-vec00106-002-s164><decide.sich_entscheiden><en> When you start advertising you have to decide about different things.
<G-vec00106-002-s164><decide.sich_entscheiden><de> Wenn du anfängst zu werben, musst du dich über verschiedene Dinge entscheiden.
<G-vec00106-002-s165><decide.sich_entscheiden><en> If the person is upset about something that you did, but you don't think it was a big deal or that it warrants an apology, then you have to decide.
<G-vec00106-002-s165><decide.sich_entscheiden><de> Wenn die Person enttäuscht wegen etwas ist, von dem du denkst, dass es wirklich keine große Sache war oder keine Entschuldigung erfordert, musst du dich entscheiden.
<G-vec00106-002-s166><decide.sich_entscheiden><en> Once you’ve recovered possession, you have to decide what to do with it.
<G-vec00106-002-s166><decide.sich_entscheiden><de> Sobald du den Ball wiedererlangt hast, musst du dich entscheiden, was du damit machen willst.
<G-vec00106-002-s167><decide.sich_entscheiden><en> You could not decide – neither going back nor forward.
<G-vec00106-002-s167><decide.sich_entscheiden><de> Du konntest dich nicht entscheiden - weder zurückzugehen noch vorwärts.
<G-vec00106-002-s168><decide.sich_entscheiden><en> Now she only needs to decide what to nibble on first, and with whom to share this exquisite chocolatey bounty!
<G-vec00106-002-s168><decide.sich_entscheiden><de> Jetzt musst du dich nur noch entscheiden, was du zuerst anknabberst und mit wem du diese exquisite schokoladige Beute teilen möchtest.
<G-vec00106-002-s169><decide.sich_entscheiden><en> Even before the first three community cards are dealt (the flop), you need to decide whether your hand can be played or not.
<G-vec00106-002-s169><decide.sich_entscheiden><de> Noch bevor überhaupt die ersten drei Gemeinschaftskarten (der Flop) aufgedeckt werden, musst du dich entscheiden, ob du mit deiner Starthand in das Spiel einsteigen willst oder nicht.
<G-vec00106-002-s170><decide.sich_entscheiden><en> If you decide to purchase CodeCheck Premium, it will be done through your Play-Store account.
<G-vec00106-002-s170><decide.sich_entscheiden><de> Solltest Du Dich für den Kauf von CodeCheck Premium entscheiden, wird dieser über Dein Konto durchgeführt.
<G-vec00106-002-s171><decide.sich_entscheiden><en> If you decide to take one from the bars or night clubs that can be a great value for money since they are generally good looking, however, it also takes some time to find them and if you are unlucky there might not even be any of them in that one particular club the night you are going.
<G-vec00106-002-s171><decide.sich_entscheiden><de> Wenn du dich entscheidest in eine der Bars oder Nachtclubs zu gehen, welche ein gutes Preis-Leistungs-Verhältnis haben können, da sie dort in der Regel relativ gut aussehen, kann es jedoch einige Zeit dauern um jemanden zu finden und wenn du Pech hast, gibt es in dieser Nacht in diesem Club überhaupt keine.
<G-vec00106-002-s172><decide.sich_entscheiden><en> This is ONLY used when you decide to use an in-app payment option.
<G-vec00106-002-s172><decide.sich_entscheiden><de> Diese Option wird NUR benutzt, wenn du dich entscheidest, eine In-App-Zahlungsoption zu verwenden.
<G-vec00106-002-s173><decide.sich_entscheiden><en> Before you decide on your equipment you can rent out skis and accessories from us and try these out.
<G-vec00106-002-s173><decide.sich_entscheiden><de> Bevor du dich für eine Ausrüstung entscheidest, kannst du Skier und Zubehör bei uns ausleihen und ausgiebig testen.
<G-vec00106-002-s174><decide.sich_entscheiden><en> The crowd gets involved, so be sure to bring your A-game if you decide to visit.
<G-vec00106-002-s174><decide.sich_entscheiden><de> Die Menge wird mit einbezogen, also solltest du dein A-Spiel mitbringen, wenn du dich entscheidest, es zu besuchen.
<G-vec00106-002-s175><decide.sich_entscheiden><en> Images from any Bound can be displayed on our website if you decide to publish them at the end of the Bound.
<G-vec00106-002-s175><decide.sich_entscheiden><de> Von jedem Bound können Bilder auf unserer Internetseite angezeigt werden, wenn du dich am Ende des Bounds zur Veröffentlichung entscheidest.
<G-vec00106-002-s176><decide.sich_entscheiden><en> If you decide for a day pass, you can get off at the main attractions and continue on the next bus.
<G-vec00106-002-s176><decide.sich_entscheiden><de> Wenn du dich für ein Tagesticket entscheidest, kannst du an den wichtigsten Sehenswürdigkeiten aussteigen und mit dem nächsten Bus weiterfahren.
<G-vec00106-002-s177><decide.sich_entscheiden><en> If you decide to get a ST sport suspension kit, you are definitely on the sporty side.
<G-vec00106-002-s177><decide.sich_entscheiden><de> Wenn Du dich für ein ST Sportfahrwerk entscheidest bist Du zweifellos auf der sportlichen Seite.
<G-vec00106-002-s178><decide.sich_entscheiden><en> Whatever type of lighting you decide to use, there are a couple of things to take note of.
<G-vec00106-002-s178><decide.sich_entscheiden><de> Egal für welchen Leuchtmittel-Typ du dich entscheidest: es gibt ein paar Dinge, die du dir merken solltest.
<G-vec00106-002-s179><decide.sich_entscheiden><en> When you decide for an available option, we shall ask you to send us your personal information and to wire the first month's rent plus the agency's fee in advance.
<G-vec00106-002-s179><decide.sich_entscheiden><de> Wenn du dich für eine Option entscheidest, bitten wir dich um ein paar persönliche Angaben sowie um die Überweisung der ersten Monatsmiete und der Vermittlungsgebühr (siehe Gebühren).
<G-vec00106-002-s180><decide.sich_entscheiden><en> Whether you decide to optimise your whole site or only select content (which we’ll discuss in a bit), you’ll be focusing mostly on URL structure and language targeting.
<G-vec00106-002-s180><decide.sich_entscheiden><de> Unabhängig davon, ob Du Dich für eine Optimierung Deiner gesamten Webseite, oder nur für einige wichtige Teilbereiche entscheidest (hierauf gehen wir noch ein), liegt der Fokus generell auf einer optimierten URL Struktur und Sprache.
<G-vec00106-002-s181><decide.sich_entscheiden><en> Plus you get to keep all your progress, and you can save 10% on the game if you decide you love it.
<G-vec00106-002-s181><decide.sich_entscheiden><de> Außerdem bleiben all deine Fortschritte erhalten, und du kannst 10 % sparen, wenn du dich entscheidest, das Spiel zu kaufen.
<G-vec00106-002-s182><decide.sich_entscheiden><en> With RaceRoom you can test all chargeable Vehicles for an indefinite period before you decide to buy your favourites.
<G-vec00106-002-s182><decide.sich_entscheiden><de> Bei uns kannst du auch alle kostenpflichtigen Fahrzeuge für einen unbegrenzten Zeitraum kostenlos testen, bevor du dich für deine Favoriten entscheidest.
<G-vec00106-002-s183><decide.sich_entscheiden><en> Before you decide to follow the Channel you can also check the Channel details, such as the topics covered as written in the description, the Channel Owner and members.
<G-vec00106-002-s183><decide.sich_entscheiden><de> Bevor du dich entscheidest einem Channel zu folgen, kannst du die Channel-Details (Themen, Follower und Besitzer) erstmals auschecken.
<G-vec00106-002-s184><decide.sich_entscheiden><en> Whichever you decide is the one for you, you know that onlookers will take you seriously on the slopes in the Le Tour pullover.
<G-vec00106-002-s184><decide.sich_entscheiden><de> Für welche Farbe Du Dich auch entscheidest, Deine Zuschauer auf der Piste werden Dir im Le Tour Sport-Pullover sicher sein.
<G-vec00106-002-s185><decide.sich_entscheiden><en> I have already touched this topic in the beginning of the guide, but let me tell you one thing: No matter if you decide to spend your sex holiday in Thailand, Cambodia, Philippines or Indonesia – you will have an unforgettable time in any of these countries and you won’t find it hard to meet and sleep with young girls that are more than 10 times as attractive as the girls from your home country – at a fraction of the cost.
<G-vec00106-002-s185><decide.sich_entscheiden><de> Ich habe dieses Thema bereits zu Beginn des Guides angestoßen, aber lass mich dir eines sagen: Egal, ob du dich entscheidest, deinen Sex Urlaub in Thailand, Kambodscha, den Philippinen oder Indonesien zu verbringen – du wirst eine unvergessliche Zeit in allen diesen Ländern erleben, und du wirst es nicht schwierig finden, um intime Bekanntschaften mit jungen Frauen zu machen, die 10 mal so attraktiv sind wie die deutschen Frauen – zu einem Bruchteil des Preises.
<G-vec00106-002-s186><decide.sich_entscheiden><en> No matter which field of activity you may decide, you will work in a team of qualified professionals, as well as apprentices and trainees.
<G-vec00106-002-s186><decide.sich_entscheiden><de> Egal für welchen Praxisbereich du dich entscheidest, arbeitest du im Team zusammen mit qualifizierten Fachkräften, sowie Auszubildenden oder Praktikanten/Praktikantinnen.
<G-vec00106-002-s187><decide.sich_entscheiden><en> This is ONLY used when you decide to use an in-game payment option.
<G-vec00106-002-s187><decide.sich_entscheiden><de> Diese Option wird NUR benutzt, wenn du dich entscheidest, eine Zahlungsoption im Spiel zu verwenden.
<G-vec00106-002-s188><decide.sich_entscheiden><en> Before you decide to go through with a tummy tuck, talk to your doctor.
<G-vec00106-002-s188><decide.sich_entscheiden><de> Bevor du dich für eine Bauchstraffung entscheidest, solltest du mit einem Arzt sprechen.
<G-vec00106-002-s189><decide.sich_entscheiden><en> Whatever you decide, to be honest, I am not bothered whether I am born in a water pool, on a birthing swing or at home.
<G-vec00106-002-s189><decide.sich_entscheiden><de> Wie auch immer du dich entscheidest: Ehrlich gesagt ist es mir egal, ob ich in einem Wasserbecken, auf einer Geburtsschaukel oder zu Hause geboren werde.
<G-vec00106-002-s190><decide.sich_entscheiden><en> Afterwards decide whether the following statements are true or nbsp;
<G-vec00106-002-s190><decide.sich_entscheiden><de> Entscheide danach ob die folgenden Aussagen wahr oder falsch sind.
<G-vec00106-002-s191><decide.sich_entscheiden><en> I decide the adoptions, go to the future parents of my dog and prove everything, often bringing several dogs to the new home so they can decide themselves which dog is the best choice - especially if they have already a dog and are looking for another dog.
<G-vec00106-002-s191><decide.sich_entscheiden><de> Ich entscheide die Adoptionen, fahre zu den zukünftigen Eltern meines Hundes und besichtige alles, bringe oft mehrere Hunde, damit im Haus selbst entschieden werden kann, welcher Hund ist die beste Wahl – speziell wenn schon ein eigener Hund vorhanden ist.
<G-vec00106-002-s192><decide.sich_entscheiden><en> My gut and belly, which I by the way learned to love from the inside and the outside, makes a lovely flutter or gives me a terrifying uaargh-feel and within seconds when I decide the things I have to decide.
<G-vec00106-002-s192><decide.sich_entscheiden><de> Mein Bauch, den ich übrigens von Innen als auch von Außen sehr lieb gewonnen habe, gibt dann entweder ein nettes Kribbeln oder ein ungutes Uuuarghs-Gefühl von sich und ich entscheide Dinge innerhalb von Sekunden.
<G-vec00106-002-s193><decide.sich_entscheiden><en> Save your search on the home page and decide what recipes inspire you every day.
<G-vec00106-002-s193><decide.sich_entscheiden><de> Speichere deine Suchen auf der Startseite und entscheide, welche Rezepte dich täglich inspirieren.
<G-vec00106-002-s194><decide.sich_entscheiden><en> I decide how I see things.
<G-vec00106-002-s194><decide.sich_entscheiden><de> Ich entscheide, wie ich die Dinge sehe.
<G-vec00106-002-s195><decide.sich_entscheiden><en> 1 Decide how you’d like to cook your momos.
<G-vec00106-002-s195><decide.sich_entscheiden><de> 1 Entscheide, wie du die Momos garen möchtest.
<G-vec00106-002-s196><decide.sich_entscheiden><en> But I shall leave nothing to fate now and face up to the challenge: Despite the rain, I decide to go for a walk.
<G-vec00106-002-s196><decide.sich_entscheiden><de> Ich überlasse nun aber nichts dem Schicksal und stelle mich tapfer der Herausforderung: Trotz Regen entscheide ich mich, einen Spaziergang zu unternehmen.
<G-vec00106-002-s197><decide.sich_entscheiden><en> If a funding does come into question, do not force the non-profits to tailor their application to your expectations - decide whether a funding according to their expectations is feasible.
<G-vec00106-002-s197><decide.sich_entscheiden><de> Wenn eine Förderung in Frage kommt, dann zwinge die Non-Profits nicht, ihren Antrag auf Deine Vorstellungen hin zuzuschneiden, sondern entscheide, ob eine Förderung entlang ihrer Vorstellungen sinnvoll ist.
<G-vec00106-002-s198><decide.sich_entscheiden><en> Decide if you will fight for justice or revel in anarchy.
<G-vec00106-002-s198><decide.sich_entscheiden><de> Entscheide, ob du für die Gerechtigkeit kämpfst oder dich der Anarchie verschreibst.
<G-vec00106-002-s199><decide.sich_entscheiden><en> After having seen the village of Alt-Marzahn from the platform of the Skywalk, situated in the middle of the prefabricated buildings, I decide to go for a walk through the historic village after my high-rise adventure.
<G-vec00106-002-s199><decide.sich_entscheiden><de> Nachdem ich von der Plattform des Skywalks aus bereits das inmitten der Plattenbauten gelegene Dorf Alt-Marzahn gesehen habe, entscheide ich mich nach meiner Kletterpartie zu einem Spaziergang durch das historische Örtchen.
<G-vec00106-002-s200><decide.sich_entscheiden><en> Decide which type of distribution suits your experiment.
<G-vec00106-002-s200><decide.sich_entscheiden><de> Entscheide, welche Verteilung zu deinem Experiment passt.
<G-vec00106-002-s201><decide.sich_entscheiden><en> Decide the length of the chimes desired.
<G-vec00106-002-s201><decide.sich_entscheiden><de> Entscheide die Länge des gewünschten Glockenspiel.
<G-vec00106-002-s202><decide.sich_entscheiden><en> I decide the destination of each man not on the basis of age, seniority, amount of suffering, or least of all, the degree of misery, but on whether they possess truth.
<G-vec00106-002-s202><decide.sich_entscheiden><de> Ich entscheide den Bestimmungsort eines jeden Menschen nicht auf der Grundlage von Alter, Vorrang, Umfang des Leidens und am Allerwenigsten nach dem Grad, in dem er um Mitleid bittet, sondern danach, ob er die Wahrheit besitzt.
<G-vec00106-002-s203><decide.sich_entscheiden><en> Against the backdrop of all I’ve seen and heard, I decide to call my ex.
<G-vec00106-002-s203><decide.sich_entscheiden><de> Vor dem Hintergrund all dessen, was ich nun gesehen und gehört habe, entscheide ich mich, meinen mittlerweile Ex-Freund anzurufen.
<G-vec00106-002-s204><decide.sich_entscheiden><en> Decide which color you prefer, or try growing different varieties of African Violets.
<G-vec00106-002-s204><decide.sich_entscheiden><de> Entscheide, welche Farbe du bevorzugst oder probiere verschiedene Sorten von Usambaraveilchen aus.
<G-vec00106-002-s205><decide.sich_entscheiden><en> 4 Decide if surgery is an option.
<G-vec00106-002-s205><decide.sich_entscheiden><de> 4 Entscheide, ob eine Operation eine Option ist.
<G-vec00106-002-s206><decide.sich_entscheiden><en> Go through what you already own and decide what you like.
<G-vec00106-002-s206><decide.sich_entscheiden><de> Sieh die Sachen durch, die Du bereits besitzt und entscheide, was Dir davon gefällt.
<G-vec00106-002-s207><decide.sich_entscheiden><en> I get to decide who I am, on my terms.
<G-vec00106-002-s207><decide.sich_entscheiden><de> Ich entscheide, wer ich bin.
<G-vec00106-002-s208><decide.sich_entscheiden><en> Decide whether you have to use much or wrong answers
<G-vec00106-002-s208><decide.sich_entscheiden><de> Entscheide, ob du much oder many einsetzen musst.
<G-vec00106-002-s209><decide.sich_entscheiden><en> Decide whether or not to talk to a doctor.
<G-vec00106-002-s209><decide.sich_entscheiden><de> Entscheide dich, ob du mit einem Arzt sprechen willst.
<G-vec00106-002-s210><decide.sich_entscheiden><en> Before you get started on the initial design of your logo, decide what “feel” you want to create with your logo―your “brand identity”.
<G-vec00106-002-s210><decide.sich_entscheiden><de> Bevor du mit dem Designen deines Logos beginnst, entscheide dich, welches „Gefühl“ du mit deinem Logo erzeugen willst – das ist deine Markenidentität.
<G-vec00106-002-s211><decide.sich_entscheiden><en> 1 Decide what illness you are going to fake.
<G-vec00106-002-s211><decide.sich_entscheiden><de> 1 Entscheide dich, welche Krankheit du vortäuschen willst.
<G-vec00106-002-s212><decide.sich_entscheiden><en> 1 Decide on the purpose for your notebook.
<G-vec00106-002-s212><decide.sich_entscheiden><de> 1 Entscheide dich für den Zweck deines Notizbuches.
<G-vec00106-002-s213><decide.sich_entscheiden><en> Well, then decide to give HIM control.
<G-vec00106-002-s213><decide.sich_entscheiden><de> Also entscheide dich, IHM die Kontrolle zu überlassen.
<G-vec00106-002-s214><decide.sich_entscheiden><en> Your solo birthday should be about you doing exactly what you want to do, so whether you decide to stay in or go out, be sure to choose a fun or relaxing activity of some sort.
<G-vec00106-002-s214><decide.sich_entscheiden><de> Dein Geburtstag sollte dazu da sein, um genau das zu tun, was du tun möchtest, also entscheide dich, ob du ausgehen oder zuhause bleiben möchtest.
<G-vec00106-002-s215><decide.sich_entscheiden><en> 5 Decide on a time and place.
<G-vec00106-002-s215><decide.sich_entscheiden><de> 5 Entscheide dich für eine Zeit und einen Ort.
<G-vec00106-002-s216><decide.sich_entscheiden><en> Decide on a container.
<G-vec00106-002-s216><decide.sich_entscheiden><de> Entscheide dich für einen Behälter.
<G-vec00106-002-s217><decide.sich_entscheiden><en> Decide to allow conflicts to get close to you, to engage.
<G-vec00106-002-s217><decide.sich_entscheiden><de> Entscheide dich, Konflikte an dich heranzulassen, dich auf sie einzulassen.
<G-vec00106-002-s218><decide.sich_entscheiden><en> Decide when you’d like to host your meals, and what you will cook.
<G-vec00106-002-s218><decide.sich_entscheiden><de> Entscheide Dich, wann du ein Essen veranstalten möchstest und was du kochen willst.
<G-vec00106-002-s219><decide.sich_entscheiden><en> Decide how many strands of yarn you want to put together.
<G-vec00106-002-s219><decide.sich_entscheiden><de> Entscheide dich, wie viele Stränge du zusammennehmen möchtest.
<G-vec00106-002-s220><decide.sich_entscheiden><en> Decide below if you want both sides of the bed runner made of decorative fabric or the underside finished with decorative lining.
<G-vec00106-002-s220><decide.sich_entscheiden><de> Unterhalb entscheide Dich, ob der Kissenbezug doppelseitig aus Dekostoff gefertigt sein wird oder auf der Stoffunterseite mit einer dekorativen Verkleidung veredelt sein soll.
<G-vec00106-002-s221><decide.sich_entscheiden><en> Decide what games and activities you want to plan for the party, and gather any items you need before the party starts.
<G-vec00106-002-s221><decide.sich_entscheiden><de> Entscheide dich, welche Spiele und Aktivitäten du für die Party planst und lege alles was du dafür brauchst bereit, bevor sie beginnt.
<G-vec00106-002-s222><decide.sich_entscheiden><en> 7 Decide if you are willing to work through this, or if you're through.
<G-vec00106-002-s222><decide.sich_entscheiden><de> 7 Entscheide dich, ob du bereit bist, das aufzuarbeiten oder ob die Sache für dich durch ist.
<G-vec00106-002-s223><decide.sich_entscheiden><en> Decide if you want to host the blog yourself.
<G-vec00106-002-s223><decide.sich_entscheiden><de> Entscheide dich, ob du den Blog selbst hosten möchtest.
<G-vec00106-002-s224><decide.sich_entscheiden><en> Decide when to go to the Grand Canyon.
<G-vec00106-002-s224><decide.sich_entscheiden><de> Entscheide dich für die richtige Reisezeit.
<G-vec00106-002-s225><decide.sich_entscheiden><en> Decide on a harmless reason for your fake faint.
<G-vec00106-002-s225><decide.sich_entscheiden><de> Entscheide dich für einen harmlosen Auslöser für deine simulierte Ohnmacht.
<G-vec00106-002-s226><decide.sich_entscheiden><en> Decide what level of limit poker feels comfortable, and set a profit target for the session.
<G-vec00106-002-s226><decide.sich_entscheiden><de> Entscheide dich, bei welchem Niveau des Limits du dich am wohlsten fühlst, und setze dir ein Ziel für deinen Profit während dieser Session.
<G-vec00106-002-s227><decide.sich_entscheiden><en> 1 Decide whether you will serve the salad plain or as a sandwich.
<G-vec00106-002-s227><decide.sich_entscheiden><de> 1 Entscheide dich, ob du den Eiersalat schlicht oder als Sandwich servieren möchtest.
<G-vec00106-002-s228><decide.sich_entscheiden><en> In the rooms, the customer can decide what temperature you want.
<G-vec00106-002-s228><decide.sich_entscheiden><de> In den Räumen, kann der Kunde entscheiden, welche Temperatur Sie wollen.
<G-vec00106-002-s229><decide.sich_entscheiden><en> The future of the economic trade schemes and volumes is very closely attached to the actions the politicians on both sides will take. The political class will decide, in which way the economic cooperation between Russia and the European Union will develop.
<G-vec00106-002-s229><decide.sich_entscheiden><de> In diesem Fall liegt der wirtschaftliche Austausch eindeutig den Handlungen der Politik zugrunde, diese wird entscheiden, wie sich der Handel und die wirtschaftliche Kooperation zwischen Russland und der EU weiter entwickeln werden.
<G-vec00106-002-s230><decide.sich_entscheiden><en> This includes such things as reflecting on the value of personal data, understanding how opinions are influenced and thinking about what artificial intelligence can do and what it should not be allowed to decide.
<G-vec00106-002-s230><decide.sich_entscheiden><de> Dazu gehört zum Beispiel das Nachdenken über den Wert von persönlichen Daten, das Erkennen, wie Meinungen beeinflusst werden oder auch die Auseinandersetzung damit, was künstliche Intelligenz kann und was sie nicht entscheiden sollte.
<G-vec00106-002-s231><decide.sich_entscheiden><en> In addition, the GA has the power to decide on TIPA membership issues and make all other decisions on extraordinary matters.
<G-vec00106-002-s231><decide.sich_entscheiden><de> Des Weiteren ist die Hauptversammlung berechtigt, über TIPA-Mitgliedschaftsfragen zu entscheiden und Entscheidungen in anderen außerordentlichen Angelegenheiten zu treffen.
<G-vec00106-002-s232><decide.sich_entscheiden><en> Actions taken and not taken here in Panama will decide the answers to these questions as this week’s meeting unfolds.
<G-vec00106-002-s232><decide.sich_entscheiden><de> Über die Antworten auf all diese Fragen werden die Entwicklungen diese Woche hier in Panama entscheiden.
<G-vec00106-002-s233><decide.sich_entscheiden><en> The Divisions and the Boards of Appeal shall decide as to the action to be taken in the cases specified in paragraphs 2 and 3 without the participation of the member concerned.
<G-vec00106-002-s233><decide.sich_entscheiden><de> Die Abteilungen und die Beschwerdekammern entscheiden in den Fällen der Absätze 2 und 3 ohne Mitwirkung des betreffenden Mitglieds.
<G-vec00106-002-s234><decide.sich_entscheiden><en> From the moment a transaction is notified, the Commission generally has a total of 25 working days to decide whether to grant approval (Phase I) or to start an in-depth investigation (Phase II).
<G-vec00106-002-s234><decide.sich_entscheiden><de> Nach der Anmeldung eines Zusammenschlusses hat die Kommission in der Regel 25 Arbeitstage Zeit, um zu entscheiden, ob sie das Rechtsgeschäft in einer ersten vorläufigen Prüfung genehmigt (Phase I) oder eine eingehende Prüfung einleitet (Phase 2).
<G-vec00106-002-s235><decide.sich_entscheiden><en> An important point is that patients must be able to decide themselves whether they want an electronic patient record.
<G-vec00106-002-s235><decide.sich_entscheiden><de> Ein wichtiger Punkt ist, dass der Patient selbst entscheiden kann, ob er ein elektronisches Patientendossier will.
<G-vec00106-002-s236><decide.sich_entscheiden><en> In case some erotic content is provided, Chateadoras will assess the situation and decide whether the claim of customer is grounded and any compensation/refund of tokens is due.
<G-vec00106-002-s236><decide.sich_entscheiden><de> Für den Fall, dass irgendwelche erotische Inhalte bereitgestellt wurden, wird Chateadoras die Situation bewerten und entscheiden, ob der Anspruch des Kunden begründet ist und ein Ausgleich / eine Rückerstattung von Token vorzunehmen ist.
<G-vec00106-002-s237><decide.sich_entscheiden><en> Whether it’s a Monster, Spell, or Trap, you get to choose its fate with powerful negation effects that decide the Duel.
<G-vec00106-002-s237><decide.sich_entscheiden><de> Egal ob es sich um eine Monster, Zauber- oder eine Fallenkarte handelt, du kannst Schicksal spielen und mit mächtigen Negationseffekten das Duell entscheiden.
<G-vec00106-002-s238><decide.sich_entscheiden><en> No, Free Canadian Sex Chat does not have any recurring charges as we want our members to decide for themselves when they want to buy more tokens.
<G-vec00106-002-s238><decide.sich_entscheiden><de> Nein, Busty Free Webcams Live Sex Chat Free bietet kein Abonnement oder regelmäßige Abrechnung an, da wir möchten, dass unsere Mitglieder selbst entscheiden, wann sie weitere Token kaufen wollen.
<G-vec00106-002-s239><decide.sich_entscheiden><en> After two weeks of test mode, parents can decide whether they want to receive them on or not.
<G-vec00106-002-s239><decide.sich_entscheiden><de> Nach zwei Wochen Test-Modus, können die Eltern entscheiden, ob sie sie auf oder nicht erhalten möchten.
<G-vec00106-002-s240><decide.sich_entscheiden><en> In any case, let's take a look at this powerful hormone and let you decide if there's a use for you.
<G-vec00106-002-s240><decide.sich_entscheiden><de> Auf jeden Fall lassen Sie uns einen Blick auf dieses starke Hormon werfen und lassen Sie Sie entscheiden, wenn es einen Gebrauch für Sie gibt.
<G-vec00106-002-s241><decide.sich_entscheiden><en> This means that you must consistently decide whether a particular project in your portfolio is more important than another.
<G-vec00106-002-s241><decide.sich_entscheiden><de> Das heißt, Sie müssen in Ihrem Portfolio konsequent entscheiden, ob ein bestimmtes Projekt wichtiger ist als ein anderes.
<G-vec00106-002-s242><decide.sich_entscheiden><en> This game belongs to him, which will be discussed to the list - you decide.
<G-vec00106-002-s242><decide.sich_entscheiden><de> Dieses Spiel gehört ihm, was wird in die Liste diskutiert werden - Sie entscheiden.
<G-vec00106-002-s243><decide.sich_entscheiden><en> Given that reddit just took a $150 million investment from a Chinese censorship powerhouse, I thought it would be nice to post this picture of “Tank Man” at Tienanmen Square before our new glorious overlords decide we cannot post it anymore. from r/pics
<G-vec00106-002-s243><decide.sich_entscheiden><de> "Angesichts der Tatsache, dass Reddit gerade eine Investition von 150 Millionen US-Dollar von einem chinesischen Kraftwerk der Zensur übernommen hatte, dachte ich, es wäre schön, dieses Bild von Winnie-The-Pooh zu posten, bevor unsere neuen glorreichen Overlords entscheiden, dass wir es nicht mehr veröffentlichen können", so der Post-Read.
<G-vec00106-002-s244><decide.sich_entscheiden><en> This information is shared to help the ad network decide whether they want to serve an ad to the user and, if so, which ad they want to show, and how much they want to bid.
<G-vec00106-002-s244><decide.sich_entscheiden><de> Diese Informationen werden weitergegeben, damit der Bieter entscheiden kann, ob er eine Anzeige für den Nutzer bereitstellen möchte, und wenn ja, welche Anzeige es sein soll und wie viel er bieten möchte.
<G-vec00106-002-s245><decide.sich_entscheiden><en> People that are able to decide are people that win.
<G-vec00106-002-s245><decide.sich_entscheiden><de> Menschen, die entscheiden können, sind Menschen, die gewinnen.
<G-vec00106-002-s246><decide.sich_entscheiden><en> Thor electronic exhaust system allows the owner to decide for himself about the way his car should sound and how loud it should be.
<G-vec00106-002-s246><decide.sich_entscheiden><de> Mit der elektronischen Thor-Abgassystem kann der Inhaber selbst entscheiden, wie laut das Auto sein soll.
<G-vec00106-002-s247><decide.sich_entscheiden><en> Once a year, the executive board and the scientific management of Wings for Life sit down together to decide which new research projects should be funded.
<G-vec00106-002-s247><decide.sich_entscheiden><de> Einmal im Jahr entscheiden der Vorstand und die wissenschaftliche Leitung von Wings for Life darüber, welche neuen Forschungsprojekte gefördert werden.
<G-vec00106-002-s248><decide.sich_entscheiden><en> All cantons decide on how education should look like, as long as it meets certain requirements.
<G-vec00106-002-s248><decide.sich_entscheiden><de> Alle Kantone entscheiden darüber, wie Erziehung aussehen sollte, solange sie bestimmte Anforderungen erfüllt.
<G-vec00106-002-s249><decide.sich_entscheiden><en> You as the administrator decide what your supplier can and cannot see.
<G-vec00106-002-s249><decide.sich_entscheiden><de> Sie als Administrator entscheiden darüber, was Ihr Lieferant einsehen kann und was nicht.
<G-vec00106-002-s250><decide.sich_entscheiden><en> The selection of different types of peppers and the amount of fat-containing pepper seeds decide whether sweet or hot paprika is produced.
<G-vec00106-002-s250><decide.sich_entscheiden><de> Die Auswahl der verschiedenen Paprikasorten und die Menge der zugegebenen, fetthaltigen Paprikasamen entscheiden darüber, ob edelsüßes oder scharfes Paprikapulver entsteht.
<G-vec00106-002-s251><decide.sich_entscheiden><en> We shall not be obliged to take part in dispute resolution procedures before a consumer conciliation body and shall decide on these on a case-by-case basis.
<G-vec00106-002-s251><decide.sich_entscheiden><de> Wir sind zur Teilnahme an Streitbeilegungsverfahren vor einer Verbraucherschlichtungsstelle nicht verpflichtet und entscheiden darüber im Einzelfall.
<G-vec00106-002-s252><decide.sich_entscheiden><en> You alone decide whether or not you wish to disclose this data to us, for example in the context of a registration, survey or similar.
<G-vec00106-002-s252><decide.sich_entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung, Umfrage o. ä., diese Daten bekannt geben wollen oder nicht.
<G-vec00106-002-s253><decide.sich_entscheiden><en> Sandra and I decide such things together even though, as the manager, Sandra naturally has her eye on the furnishings every day.
<G-vec00106-002-s253><decide.sich_entscheiden><de> Sandra und ich entscheiden gemeinsam darüber, auch wenn Sandra als Geschäftsführerin die Einrichtung natürlich täglich im Blick hat.
<G-vec00106-002-s254><decide.sich_entscheiden><en> Database users decide what data are released.
<G-vec00106-002-s254><decide.sich_entscheiden><de> Die Datenbankbenutzer entscheiden darüber, welche Daten freigegeben werden.
<G-vec00106-002-s255><decide.sich_entscheiden><en> Therefore, a user or administrator must decide whether to trust that CA and, by extension, the policies and procedures that the CA has in place for confirming the identity of the entities that are issued certificates by that CA.
<G-vec00106-002-s255><decide.sich_entscheiden><de> Deshalb muss ein Benutzer oder Administrator entscheiden, ob dieser Zertifizierungsstelle und darüber hinaus den Richtlinien und Verfahren dieser Zertifizierungsstelle zur Bestätigung der Identität der Entitäten, denen von dieser Zertifizierungsstelle Zertifikate ausgestellt werden, vertraut werden kann.
<G-vec00106-002-s256><decide.sich_entscheiden><en> You are free to decide which information you provide to the Bertelsmann Stiftung.
<G-vec00106-002-s256><decide.sich_entscheiden><de> Wahlmöglichkeit Sie entscheiden frei darüber, welche Informationen Sie der Bertelsmann Stiftung zur Verfügung stellen.
<G-vec00106-002-s257><decide.sich_entscheiden><en> You alone decide whether you want to or do not want to disclose this data to us, for example in the course of a registration process.
<G-vec00106-002-s257><decide.sich_entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung, diese Daten bekannt geben wollen oder nicht.
<G-vec00106-002-s258><decide.sich_entscheiden><en> By combining them you can easily decide how to bake your dish and be sure about the final result.
<G-vec00106-002-s258><decide.sich_entscheiden><de> Die Betriebsarten können problemlos miteinander kombiniert werden; wir entscheiden darüber, wie unsere Speise zuzubereiten ist, wobei wir uns des Endergebnisses immer sicher sein können.
<G-vec00106-002-s259><decide.sich_entscheiden><en> In our houses and gardens, in our facilities for water, energy and food, in our love relationships and partnerships and in our social and political systems, we decide which information is sent to the world.
<G-vec00106-002-s259><decide.sich_entscheiden><de> In unseren Häusern und Gärten, unseren Anlagen für Wasser, Energie und Nahrung, unseren Liebesbeziehungen und Partnerschaften, unseren sozialen und politischen Systemen entscheiden wir darüber, welche Information in die Welt geht.
<G-vec00106-002-s260><decide.sich_entscheiden><en> You may freely decide what information to give us.
<G-vec00106-002-s260><decide.sich_entscheiden><de> Sie entscheiden frei darüber, welche Informationen Sie zur Verfügung stellen.
<G-vec00106-002-s261><decide.sich_entscheiden><en> You alone decide if you wish to give us this information or not, for example when registering online or during an online application.
<G-vec00106-002-s261><decide.sich_entscheiden><de> Allein Sie entscheiden darüber, ob Sie uns, etwa im Rahmen einer Registrierung/ Online-Bewerbung, diese Daten bekannt geben wollen oder nicht.
<G-vec00106-002-s262><decide.sich_entscheiden><en> The market doesn't take into account the costs but by selling directly from the pier the fishermen can decide their own prices.
<G-vec00106-002-s262><decide.sich_entscheiden><de> Der Markt berücksichtigt die Kosten nicht - beim Direktverkauf jedoch entscheiden die Fischer selbst darüber.
<G-vec00106-002-s263><decide.sich_entscheiden><en> Your listeners and viewers will decide on it.
<G-vec00106-002-s263><decide.sich_entscheiden><de> Ihre Zuhörer und Zuschauer entscheiden darüber.
<G-vec00106-002-s264><decide.sich_entscheiden><en> Function, operating comfort, graphical design, speed and availability decide on how internet applications are perceived.
<G-vec00106-002-s264><decide.sich_entscheiden><de> Funktionalität, Bedienungskomfort, grafische Ausgestaltung, Geschwindigkeit und Verfügbarkeit entscheiden darüber, wie Internetanwendungen erlebt werden.
<G-vec00106-002-s265><decide.sich_entscheiden><en> This is essential indeed, because your ability to draw these tonalities, decide how 3-dimensional and realistic your ball will look in the end.
<G-vec00106-002-s265><decide.sich_entscheiden><de> Denn eure Fähigkeiten diese Tonalitäten zeichnen zu können, entscheiden darüber wie 3-dimensional und realistisch eure Kugel fertig aussieht.
<G-vec00106-002-s266><decide.sich_entscheiden><en> But in order to decide whether you will raise or fold, you must understand a very important concept in poker: position.
<G-vec00106-002-s266><decide.sich_entscheiden><de> Um entscheiden zu können, ob du erhöhen oder folden sollst, musst du eins der wichtigsten Konzepte beim Poker verstehen: die Position.
<G-vec00106-002-s267><decide.sich_entscheiden><en> You will have to decide for yourself, whether you will want to raise loosely, tightly or just the average amount in any situation that presents itself to you.
<G-vec00106-002-s267><decide.sich_entscheiden><de> Du musst selbst entscheiden können, ob du in einer dir gegebenen Situation lieber loose, tight oder durchschnittlich viel raisen möchtest.
<G-vec00106-002-s268><decide.sich_entscheiden><en> We have a great responsibility because we can all decide – no matter our upbringing or ancestors – wether we want to be a Jonathan Edwards or a Max Jukes.
<G-vec00106-002-s268><decide.sich_entscheiden><de> Wir haben eine große Verantwortung, weil wir alle entscheiden können – egal wie wir aufgewachsen sind und was unsere Vorfahren getan oder nicht getan haben.
<G-vec00106-002-s269><decide.sich_entscheiden><en> Here are some tips to help you set realistic expectations and decide which model is right for you.
<G-vec00106-002-s269><decide.sich_entscheiden><de> Hier finden Sie einige Tipps, mit denen Sie realistische Erwartungen festlegen und entscheiden können, welches Modell für Sie das Richtige ist.
<G-vec00106-002-s270><decide.sich_entscheiden><en> You can set your browser to notify you when you receive a cookie, giving you the chance to decide whether to accept it.
<G-vec00106-002-s270><decide.sich_entscheiden><de> Sie können Ihren Browser so einrichten, dass Sie beim Empfang eines Cookies benachrichtigt werden und so entscheiden können, ob Sie den Cookie annehmen oder ablehnen.
<G-vec00106-002-s271><decide.sich_entscheiden><en> National populations will only be able to recognize and decide what is in their own respective interests in the long run when we begin to discuss– far beyond the bounds of academic journals – the far-reaching alternatives between abandoning the euro, or else returning to a currency system allowing for a limited margin of fluctuation, or indeed opting for closer cooperation.
<G-vec00106-002-s271><decide.sich_entscheiden><de> Die nationalen Bevölkerungen werden nur erkennen und entscheiden können, was längerfristig auch im jeweils eigenen Interesse liegt, wenn die folgenreichen Alternativen zwischen einer Rückabwicklung des Euro oder der Rückkehr zur einem Währungssystem begrenzter Schwankungsbreiten oder eben doch einer engeren Kooperation nicht mehr nur in akademischen Zeitschriften diskutiert werden.
<G-vec00106-002-s272><decide.sich_entscheiden><en> Here we take a look at those pros and cons, to help you decide where to take your career in asset management.
<G-vec00106-002-s272><decide.sich_entscheiden><de> Hier finden Sie einige Vor- und Nachteile, sodass Sie entscheiden können, wo Sie Ihre Karriere als Asset Manager beginnen möchten.
<G-vec00106-002-s273><decide.sich_entscheiden><en> Landscape ecologists at the Helmholtz Centre for Environmental Research (UFZ) in Leipzig have designed the computer game LandYOUs, which allows players to decide how much of the national budget they wish to invest in nature conservation, education, reforestation, urban development and farming subsidies.
<G-vec00106-002-s273><decide.sich_entscheiden><de> Am Helmholtz-Zentrum für Umweltforschung – UFZ in Leipzig haben Landschaftsökologen das Spiel LandYOUs entworfen, bei dem Spieler entscheiden können, wie viel Geld des Staatsbudgets sie in Naturschutz, Bildung, Aufforstung, Stadtentwicklung und die Förderung der Landwirtschaft investieren wollen.
<G-vec00106-002-s274><decide.sich_entscheiden><en> If you can not decide which decor is right for you, you can order the Tilo Vinyl Design sample portfolio.
<G-vec00106-002-s274><decide.sich_entscheiden><de> Sollten Sie sich überhaupt nicht entscheiden können, welches Dekor für Sie in frage kommt, können Sie die Tilo Vinyl Design-Mustermappe bestellen.
<G-vec00106-002-s275><decide.sich_entscheiden><en> The new solution offers customers more payment flexibility, allowing them to decide whether their credit card data shall be stored by Wirecard for separate one-click-payments or recurring payments on a monthly basis.
<G-vec00106-002-s275><decide.sich_entscheiden><de> Die neue Lösung bietet Kunden mehr Flexibilität, da sie entscheiden können, ob ihre Kreditkartendaten von Wirecard für separate 1-Click-Zahlungen oder für monatlich wiederkehrende Zahlungen gespeichert werden sollen.
<G-vec00106-002-s276><decide.sich_entscheiden><en> This will help you retain your data, letting you decide what to do before selling iPad or iPhone.
<G-vec00106-002-s276><decide.sich_entscheiden><de> Dies wird Ihnen dabei helfen, Ihre Daten zu behalten, so dass Sie entscheiden können, was Sie vor dem Verkauf von iPad oder iPhone tun wollen.
<G-vec00106-002-s277><decide.sich_entscheiden><en> Another method that allows you to decide how to communicate with the child, Gippenreiter Yu.B.
<G-vec00106-002-s277><decide.sich_entscheiden><de> Eine andere Methode, mit der Sie entscheiden können, wie Sie mit dem Kind kommunizieren möchten, Gippenreiter Yu.B.
<G-vec00106-002-s278><decide.sich_entscheiden><en> This mouthpiece is manufactured in Europe and made of high quality leather and has an adjustable belt buckle so you decide how tight or loose he sits.
<G-vec00106-002-s278><decide.sich_entscheiden><de> Dieses Mundstück wird in Europa hergestellt und besteht aus hochwertigem Leder und hat eine verstellbare Gürtelschnalle, so dass Sie entscheiden können, wie eng oder locker er sitzt.
<G-vec00106-002-s279><decide.sich_entscheiden><en> We’ll cover what tasks you can outsource, the pros and cons of outsourcing, and how to decide if outsourcing is right for your business.
<G-vec00106-002-s279><decide.sich_entscheiden><de> Wir besprechen, welche Aufgaben Sie auslagern können, welche Vor- und Nachteile das Outsourcing hat und wie Sie entscheiden können, ob das Outsourcing für Ihr Unternehmen richtig ist.
<G-vec00106-002-s280><decide.sich_entscheiden><en> This guarantees that the remaining shareholders retain the sole authority to decide on these matters, especially those that pertain to the supervision of management.
<G-vec00106-002-s280><decide.sich_entscheiden><de> So ist gewährleistet, dass die übrigen Aktionäre über diese Fragen, die insbesondere die Kontrolle der Geschäftsführung betreffen, allein entscheiden können.
<G-vec00106-002-s281><decide.sich_entscheiden><en> They can objectively tell you about the condition of the vessel before you decide whether or not to spend your time to look at the boat.
<G-vec00106-002-s281><decide.sich_entscheiden><de> Er kann Ihnen ganz objektiv über den Zustand des Bootes berichten, sodass Sie entscheiden können, ob sich eine Besichtigung lohnt.
<G-vec00106-002-s282><decide.sich_entscheiden><en> If you want to have control over your computer and the information is stored by means of cookies, you need this simple program with which to decide in a quick fashion which cookies you are interested in and which ones you aren't.
<G-vec00106-002-s282><decide.sich_entscheiden><de> Wenn Sie die Kontrolle über Ihren Computer haben möchten und über die Informationen, die via Cookies gespeichert sind, brauchen Sie dieses einfache Programm, mit dem Sie ganz schnell entscheiden können, an welchen Cookies Sie interessiert sind und an welchen nicht.
<G-vec00106-002-s283><decide.sich_entscheiden><en> If you're concerned that the filesystem status is reported as "Clean" or "Dirty", learn how to use cvfsck to decide if you need to make a repair.
<G-vec00106-002-s283><decide.sich_entscheiden><de> Wenn Sie sich nicht sicher sind, was es bedeutet, wenn der Status des Dateisystems als "Clean" (sauber) oder "Dirty" (unsauber) angegeben wird, erfahren Sie hier, wie Sie mit cvfsck entscheiden können, ob eine Reparatur notwendig ist.
<G-vec00106-002-s284><decide.sich_entscheiden><en> You have to be friends with people you trust 100% to plan anything dangerous, you have to be aware and informed about anything that is happening in this world to decide what the proper course of action is, you have to be crazy and enthusiastic, to feel that you can do incredible things—you have to be ready to give your life, your time, your years in a struggle that will never end.
<G-vec00106-002-s284><decide.sich_entscheiden><de> Du musst mit den Leuten befreundet sein und ihnen 100% trauen, um irgendwas gefährliches zu planen, du musst dir über alles was in der Welt vorgeht im Klaren sein, informiert sein, um entscheiden zu können, was der entsprechende Verlauf einer Aktion ist, du musst verrückt und begeistert sein, um zu spüren, dass du unglaubliche Dinge tun kannst - du musst bereit sein dein Leben, deine Zeit, deine Jahre in einem Kampf zu geben, der nie enden wird.
<G-vec00106-002-s285><decide.sich_entscheiden><en> Neck Construction: product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s285><decide.sich_entscheiden><de> Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s286><decide.sich_entscheiden><en> You can also decide on which side the viewing opening should be, ensuring an ideal fit for your shelving system.
<G-vec00106-002-s286><decide.sich_entscheiden><de> Außerdem können Sie entscheiden, ob sich die Öffnung an der Stirnseite oder an Längsseite befinden soll.
<G-vec00106-002-s287><decide.sich_entscheiden><en> As moderator you are opening the conference and you decide who is able to speak.
<G-vec00106-002-s287><decide.sich_entscheiden><de> Als Moderator eröffnen Sie die Konferenz und entscheiden, ob die Mikrophone der Teilnehmer stumm oder laut sind.
<G-vec00106-002-s288><decide.sich_entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s288><decide.sich_entscheiden><de> Mittlerer Stärke Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s289><decide.sich_entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s289><decide.sich_entscheiden><de> VideoMic Pro Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s290><decide.sich_entscheiden><en> You can decide how much sunlight shines through by choosing slightly transparent or completely opaque fabrics.
<G-vec00106-002-s290><decide.sich_entscheiden><de> Sie entscheiden, ob der Stoff leicht transparent oder komplett blickdicht ist und wie viel Sonne somit durchscheinen darf.
<G-vec00106-002-s293><decide.sich_entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s293><decide.sich_entscheiden><de> Dropring Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s294><decide.sich_entscheiden><en> Option 3 is similar to Option 2 but leaves some flexibility to Member States that can decide to apply the exception depending on the availability of licences.
<G-vec00106-002-s294><decide.sich_entscheiden><de> Option 3 ähnelt Option 2, sieht jedoch eine gewisse Flexibilität für die Mitgliedstaaten vor, die je nach Verfügbarkeit von Lizenzen entscheiden können, ob sie die Ausnahme anwenden.
<G-vec00106-002-s295><decide.sich_entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s295><decide.sich_entscheiden><de> Ashton Addario ® Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s296><decide.sich_entscheiden><en> Type: is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s296><decide.sich_entscheiden><de> Typ: Ausgerichtet Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s297><decide.sich_entscheiden><en> From this point, you should be able to scan through all the retrieved information and decide to keep them all or just pick which ones that you prefer to keep.
<G-vec00106-002-s297><decide.sich_entscheiden><de> Von diesem Punkt an sollten Sie in der Lage sein, alle abgerufenen Informationen zu durchsuchen und zu entscheiden, ob Sie alle behalten oder nur auswählen möchten, welche Sie lieber behalten möchten.
<G-vec00106-002-s298><decide.sich_entscheiden><en> He doesn’t have to decide it is one or the other.
<G-vec00106-002-s298><decide.sich_entscheiden><de> Er muss nicht entscheiden ob es das eine oder das andere ist.
<G-vec00106-002-s299><decide.sich_entscheiden><en> As is already the case for physical ballots, a court would then decide on the merits of the case and what measures should be initiated.
<G-vec00106-002-s299><decide.sich_entscheiden><de> Ein Gericht müsste dann – so wie heute bereits für physische Urnengänge – entscheiden, ob es die Anfechtung gutheisst und welche Maßnahmen abzuleiten sind.
<G-vec00106-002-s300><decide.sich_entscheiden><en> Once the product is delivered, you have 30 days to decide that you definitely want to keep it.
<G-vec00106-002-s300><decide.sich_entscheiden><de> Power Supply PS0913B Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s302><decide.sich_entscheiden><en> If you're switching from Clutter to Focused Inbox, they can decide to enable it (“Try it”) or dismiss the feature.
<G-vec00106-002-s302><decide.sich_entscheiden><de> Wenn Sie von "Clutter" zum Posteingang mit Relevanz wechseln, können sie entscheiden, ob sie ihn aktivieren ("Testen") oder das Feature schließen möchten.
<G-vec00106-002-s303><decide.sich_entscheiden><en> Once the product is delivered, you have 60 days to decide that you definitely want to keep it.
<G-vec00106-002-s303><decide.sich_entscheiden><de> Kunststoff Hardcase Nach Lieferung haben Sie 30 Tage Zeit sich zu entscheiden, ob Sie das bestellte Produkt behalten wollen.
<G-vec00106-002-s304><decide.sich_entscheiden><en> They now can decide when to hunt and to kill animals for meat.
<G-vec00106-002-s304><decide.sich_entscheiden><de> Sie entscheiden selbst, wieviele Tiere sie zur Fleischgewinnung jagen dürfen.
<G-vec00106-002-s305><decide.sich_entscheiden><en> You decide how spicy your drink should be: measure out the quantity of juice or water that Dr. Muche's liquid ginger is to be added to.
<G-vec00106-002-s305><decide.sich_entscheiden><de> Sie entscheiden selbst, wie scharf Ihr Getränk schmecken soll: Dosieren Sie die Menge an Saft oder Wasser, in die Sie Dr. Muches Ingwertropfen geben.
<G-vec00106-002-s306><decide.sich_entscheiden><en> However, it is up to the employees at the workplace to decide how their representatives should be chosen.
<G-vec00106-002-s306><decide.sich_entscheiden><de> Die Beschäftigten entscheiden selbst, wie ihre Vertreter ausgewählt werden.
<G-vec00106-002-s307><decide.sich_entscheiden><en> Concealed blade, fully automatic blade retraction or automatic blade retraction - you decide which MARTOR safety technology fits best to your requirements for cutting safety in the workplace. Play
<G-vec00106-002-s307><decide.sich_entscheiden><de> Verdeckt liegende Klinge, vollautomatischer oder automatischer Klingenrückzug – entscheiden Sie selbst, welche MARTOR-Sicherheitstechnik am besten zu Ihren Bedürfnissen, vor allem im Bereich Arbeitsschutz und Arbeitssicherheit, passt.
<G-vec00106-002-s308><decide.sich_entscheiden><en> With Klarna part payment you decide every month how much you want to pay.
<G-vec00106-002-s308><decide.sich_entscheiden><de> Mit Klarna Ratenkauf entscheiden Sie selbst jeden Monat aufs Neue, wieviel Sie bezahlen möchten.
<G-vec00106-002-s309><decide.sich_entscheiden><en> You decide how often and when you want to learn.
<G-vec00106-002-s309><decide.sich_entscheiden><de> Sie entscheiden selbst, wie oft und wann Sie lernen möchten.
<G-vec00106-002-s310><decide.sich_entscheiden><en> By entering your data you decide voluntarily what data we receive about your company or yourself.
<G-vec00106-002-s310><decide.sich_entscheiden><de> Mit der Dateneingabe entscheiden Sie selbst, welche Daten wir von Ihnen über Ihr Unternehmen oder Sie erhalten.
<G-vec00106-002-s311><decide.sich_entscheiden><en> The Convention on Human Rights and Biomedicine serves as a framework convention: While the Parties to the Convention have committed themselves to complying with the provisions set forth in the treaty, they are free to decide what kind of measures are needed at the national level to do so.
<G-vec00106-002-s311><decide.sich_entscheiden><de> Das Übereinkommen über Menschenrechte und Biomedizin dient seinen Vertragsstaaten als Rahmenabkommen: Sie verpflichten sich rechtlich zur Einhaltung der in der Konvention festgehaltenen Bedingungen, entscheiden aber selbst, welche Maßnahmen auf nationaler Ebene dafür notwendig sind.
<G-vec00106-002-s312><decide.sich_entscheiden><en> It is for you to decide how much you are prepared to spend on dental care.
<G-vec00106-002-s312><decide.sich_entscheiden><de> Entscheiden sie selbst, was Sie für Ihre Behandlung ausgeben möchten.
<G-vec00106-002-s313><decide.sich_entscheiden><en> From now on it is up to you to decide whether you wish to prepare a monochrome or color texture scan.
<G-vec00106-002-s313><decide.sich_entscheiden><de> Von nun an entscheiden Sie selbst, ob Sie einen monochromen oder farbigen Texturscan vorbereiten möchten.
<G-vec00106-002-s314><decide.sich_entscheiden><en> After 12 months, you decide whether you wish to renew the service.
<G-vec00106-002-s314><decide.sich_entscheiden><de> Nach 12 Monaten entscheiden Sie selbst, ob Sie diesen Service verlängern möchten.
<G-vec00106-002-s315><decide.sich_entscheiden><en> After your show ends, head out of the theater, and decide what you’d like to do next.
<G-vec00106-002-s315><decide.sich_entscheiden><de> Nach der Vorstellung verlassen Sie das Theater und entscheiden selbst, was Sie als Nächstes tun möchten.
<G-vec00106-002-s316><decide.sich_entscheiden><en> You decide where your data are saved.
<G-vec00106-002-s316><decide.sich_entscheiden><de> Sie entscheiden selbst, wo Ihre Daten liegen.
<G-vec00106-002-s317><decide.sich_entscheiden><en> Like learning any skill, it is up to you to decide how far you want to develop it.
<G-vec00106-002-s317><decide.sich_entscheiden><de> Wie beim Erlernen einer jeden Fertigkeit, entscheiden Sie selbst, wie weit Sie diese entwickeln wollen.
<G-vec00106-002-s318><decide.sich_entscheiden><en> In this programme you can decide exactly what you want to learn.
<G-vec00106-002-s318><decide.sich_entscheiden><de> In diesem Programm entscheiden Sie selbst, was Sie lernen wollen.
<G-vec00106-002-s319><decide.sich_entscheiden><en> You decide what you want to paint and on what level.
<G-vec00106-002-s319><decide.sich_entscheiden><de> Sie entscheiden selbst was Sie auf Ihrer eigenen Ebene malen möchten.
<G-vec00106-002-s320><decide.sich_entscheiden><en> You decide at the touch of a button if you want to control the car with the remote control or if the child takes control of it.
<G-vec00106-002-s320><decide.sich_entscheiden><de> Sie entscheiden per Knopfdruck, ob Sie mit der Fernbedienung das Auto steuern möchten oder ob das Kind selbst die Steuerung übernimmt.
<G-vec00106-002-s321><decide.sich_entscheiden><en> They try everything and decide whether or not they like it for themselves.
<G-vec00106-002-s321><decide.sich_entscheiden><de> Sie probieren alles und entscheiden selbst, ob es ihnen schmeckt.
<G-vec00106-002-s322><decide.sich_entscheiden><en> In the information section of RSS, you can decide which messages you want to receive.
<G-vec00106-002-s322><decide.sich_entscheiden><de> Bei der Informationssuche über RSS entscheiden Sie selbst, welche Mitteilungen Sie erhalten wollen.
<G-vec00106-002-s323><decide.sich_entscheiden><en> You decide to add a +20% bid adjustment for California, and a -50% adjustment for Saturday.
<G-vec00106-002-s323><decide.sich_entscheiden><de> Sie entscheiden sich für eine Gebotsanpassung von +20 % für Bayern und eine Anpassung von -50 % für Samstag.
<G-vec00106-002-s324><decide.sich_entscheiden><en> If you have to go to hospital, when being admitted you can decide whether you want to stay on a semi-private, comfort single or twin room on the general ward or on the general ward.
<G-vec00106-002-s324><decide.sich_entscheiden><de> Müssen Sie ins Spital, entscheiden Sie sich bei Eintritt, ob Sie halbprivat, komfortabel im Ein- oder Zweibettzimmer in der allgemeinen Abteilung oder allgemein liegen möchten.
<G-vec00106-002-s325><decide.sich_entscheiden><en> With Sinteso, you decide for fire safety that is always by your side – protecting you in the present and in the future.
<G-vec00106-002-s325><decide.sich_entscheiden><de> Mit Sinteso entscheiden Sie sich für einen Brandschutz, der Ihnen immer zuverlässig zur Seite steht – heute wie morgen.
<G-vec00106-002-s326><decide.sich_entscheiden><en> For example, you decide to purchase a Call option for XYZ stock because you heard in a financial news report that the stocks are looking to rise.
<G-vec00106-002-s326><decide.sich_entscheiden><de> So entscheiden Sie sich zum Beispiel zum Kauf einer Kaufoption der Aktie XYZ, weil Sie in den Finanznachrichten gehört haben, dass die Aktien voraussichtlich steigen werden.
<G-vec00106-002-s327><decide.sich_entscheiden><en> See for yourself and see you into our products of wood and decide you for trying out these appear for you at the most suitable for you.
<G-vec00106-002-s327><decide.sich_entscheiden><de> Überzeugen Sie sich selbst und sehen Sie sich unsere Produkte aus Holz an und entscheiden Sie sich für das Ausprobieren des Puzzles oder Holzspiel welches für Sie am besten geeignet scheint.
<G-vec00106-002-s328><decide.sich_entscheiden><en> Often, the owners of a private house decide to plant evergreen conifers in the form of bushes and trees.
<G-vec00106-002-s328><decide.sich_entscheiden><de> Oft entscheiden sich die Eigentümer eines Privathauses, immergrüne Nadelbäume in Form von Büschen und Bäumen zu pflanzen.
<G-vec00106-002-s329><decide.sich_entscheiden><en> Frequently, small organizations decide not to use a third-party certificate or not to install their own PKI to issue their own certificates.
<G-vec00106-002-s329><decide.sich_entscheiden><de> Kleine Organisationen entscheiden sich häufig gegen die Verwendung eines Drittanbieterzertifikats oder die Installation einer eigenen PKI zur Ausstellung eigener Zertifikate.
<G-vec00106-002-s330><decide.sich_entscheiden><en> When individuals and couples are given a real choice, many decide to have smaller, healthier families and invest more in each child’s future.
<G-vec00106-002-s330><decide.sich_entscheiden><de> Wenn Personen und Paare vor eine wirkliche Wahl gestellt werden, entscheiden sich viele für kleinere, gesündere Familien und investieren in die Zukunft jedes Kindes.
<G-vec00106-002-s331><decide.sich_entscheiden><en> Many couples decide to have their wedding day in Prague.
<G-vec00106-002-s331><decide.sich_entscheiden><de> Viele Paare entscheiden sich sogar für eine Hochzeit in Prag.
<G-vec00106-002-s332><decide.sich_entscheiden><en> The players decide who will dig in the mountains for gold and who will pan in the rivers.
<G-vec00106-002-s332><decide.sich_entscheiden><de> Die Spieler entscheiden sich, wer in den Bergen und wer in den Flüssen nach Gold schürfen will.
<G-vec00106-002-s333><decide.sich_entscheiden><en> Basically, namely, every human is fully responsible for himself, consequently he - if he makes the effort - can decide for himself how his life should develop.
<G-vec00106-002-s333><decide.sich_entscheiden><de> Grundsätzlich nämlich ist jeder Mensch in vollem Umfang für sich selbst verantwortlich, folglich er sich - wenn er sich bemüht - selbst entscheiden kann, wie sich sein Leben entwickeln soll.
<G-vec00106-002-s334><decide.sich_entscheiden><en> Many students decide to live in Colmar for the first semester in order to immerse themselves completely in the local culture - and this is highly appreciated.
<G-vec00106-002-s334><decide.sich_entscheiden><de> Viele Studierende entscheiden sich das erste Semester in Colmar zu wohnen, um komplett in die Kultur einzutauchen - und das wird sehr geschätzt.
<G-vec00106-002-s335><decide.sich_entscheiden><en> Many couples still decide for marriage.
<G-vec00106-002-s335><decide.sich_entscheiden><de> Nach wie vor entscheiden sich viele Paare für eine Eheschließung.
<G-vec00106-002-s336><decide.sich_entscheiden><en> You decide before the beginning of your medical journey for one of our Service Levels.
<G-vec00106-002-s336><decide.sich_entscheiden><de> Sie entscheiden sich vor Beginn Ihrer medizinischen Reise für eines unserer Service-Levels.
<G-vec00106-002-s337><decide.sich_entscheiden><en> Many will later decide to study in their former host country and some of them even will even work there.
<G-vec00106-002-s337><decide.sich_entscheiden><de> Viele entscheiden sich später, im jeweiligen Gastland zu studieren und manche sogar dort zu arbeiten.
<G-vec00106-002-s338><decide.sich_entscheiden><en> Elzie and Ovella decide not to join the traveling show and walk home.
<G-vec00106-002-s338><decide.sich_entscheiden><de> Elzie und Ovella entscheiden sich nicht, sich der Wanderausstellung anzuschließen und nach Hause zu gehen.
<G-vec00106-002-s339><decide.sich_entscheiden><en> Many young foreign entrepreneurs decide for the capital city, a perceptible development which last but not least can be attributed to the annual PIONEERS Festival.
<G-vec00106-002-s339><decide.sich_entscheiden><de> Auch viele ausländische Jungunternehmer entscheiden sich für die Hauptstadt, was nicht zuletzt durch das alljährliche PIONEERS Festival zu spüren ist.
<G-vec00106-002-s340><decide.sich_entscheiden><en> Inspiration After a romantic proposal, the newly engaged couple – full of anticipation – start to plan their dream wedding – many decide on a colour palette that runs through the whole wedding.
<G-vec00106-002-s340><decide.sich_entscheiden><de> Inspiration Nach einem romantischen Heiratsantrag beginnen die frisch Verlobten, voller Vorfreude ihre Traumhochzeit zu planen – viele entscheiden sich von Anfang an für ein konkretes Farbmotto, das sich wie ein roter Faden durch die Hochzeit zieht.
<G-vec00106-002-s341><decide.sich_entscheiden><en> Decide for yourself, what the issue is at hand, and do not let others undermine you.
<G-vec00106-002-s341><decide.sich_entscheiden><de> Entscheiden Sie selbst, um was es gerade geht, und lassen Sie sich darin nicht beirren.
<G-vec00106-002-s342><decide.sich_entscheiden><en> Decide what car you want to drive in the city of Thessaloniki Airport to find out daily average cost.
<G-vec00106-002-s342><decide.sich_entscheiden><de> Entscheiden Sie, welches Auto Sie in der Stadt Bourgas Flughafen fahren möchten, um die durchschnittlichen Tageskosten herauszufinden.
<G-vec00106-002-s343><decide.sich_entscheiden><en> Decide what car you want to drive in the city of Clermont Ferrand Airport to find out daily average cost.
<G-vec00106-002-s343><decide.sich_entscheiden><de> Entscheiden Sie, welches Auto Sie in der Stadt Kalakaua Allee fahren möchten, um die durchschnittlichen Tageskosten herauszufinden.
<G-vec00106-002-s344><decide.sich_entscheiden><en> Decide which profiling method suits your needs.
<G-vec00106-002-s344><decide.sich_entscheiden><de> Entscheiden Sie, welche Methode der Profilerstellung Ihren Anforderungen entspricht.
<G-vec00106-002-s345><decide.sich_entscheiden><en> •Decide whether you want to work with ODBC tables interactively in the relationships graph or through "static" ODBC imports.
<G-vec00106-002-s345><decide.sich_entscheiden><de> •Entscheiden Sie, ob Sie mit ODBC-Tabellen interaktiv im Beziehungsdiagramm arbeiten oder „statische“ ODBC-Importe verwenden möchten.
<G-vec00106-002-s346><decide.sich_entscheiden><en> First decide how and/or why you’d like to include an annotation and add it to your slide.
<G-vec00106-002-s346><decide.sich_entscheiden><de> Zuerst entscheiden Sie, wie und/oder Warum können Sie eine Anmerkung enthalten und Ihrer Folie hinzufügen.
<G-vec00106-002-s347><decide.sich_entscheiden><en> Decide individually on site.
<G-vec00106-002-s347><decide.sich_entscheiden><de> Entscheiden Sie individuell vor Ort.
<G-vec00106-002-s348><decide.sich_entscheiden><en> Please decide at this point how and where you wish the doors to be assembled and follow the appropriate diagram.
<G-vec00106-002-s348><decide.sich_entscheiden><de> Bitte entscheiden Sie zu diesem Zeitpunkt, wie und wo Sie die Türen einbauen wollen und halten Sie sich an die entsprechende Grafik.
<G-vec00106-002-s349><decide.sich_entscheiden><en> Decide on anything that has to do with strategy and playing style.
<G-vec00106-002-s349><decide.sich_entscheiden><de> Entscheiden Sie alles, was mit Strategie und Spielstil zu tun hat.
<G-vec00106-002-s350><decide.sich_entscheiden><en> Thoroughly consider and decide as early as possible within the acquiring company how to involve leadership and employees from the target company in the project organisation.
<G-vec00106-002-s350><decide.sich_entscheiden><de> Überlegen und entscheiden Sie innerhalb des Erwerberunternehmens sorgfältig und so früh wie möglich, wie Management und Mitarbeitende des Zielunternehmens in die Projektorganisation eingebunden werden.
<G-vec00106-002-s351><decide.sich_entscheiden><en> Instruction one Decide how ready your child is for the trip.
<G-vec00106-002-s351><decide.sich_entscheiden><de> Anweisung 1 Entscheiden Sie, wie bereit Ihr Kind für die Reise ist.
<G-vec00106-002-s352><decide.sich_entscheiden><en> Social media accounts to show: Decide which accounts shall appear on the page.
<G-vec00106-002-s352><decide.sich_entscheiden><de> Social Media-Accounts anzeigen: Entscheiden Sie welche Accounts in der Ansicht erscheinen sollen.
<G-vec00106-002-s353><decide.sich_entscheiden><en> Select it and decide whether you would like this information once or as a subscription.
<G-vec00106-002-s353><decide.sich_entscheiden><de> Wählen Sie dieses an und entscheiden Sie, ob Sie diese Information einmalig oder im Abonnement erhalten möchten.
<G-vec00106-002-s354><decide.sich_entscheiden><en> You can read the description below and decide which one you prefer.
<G-vec00106-002-s354><decide.sich_entscheiden><de> Lesen Sie die folgende Beschreibung und entscheiden Sie, welche Tickets Sie bevorzugen.
<G-vec00106-002-s355><decide.sich_entscheiden><en> Spam detection: Decide whether a given email is spam or not.
<G-vec00106-002-s355><decide.sich_entscheiden><de> Spam-Erkennung: Entscheiden Sie, ob eine bestimmte E-Mail Spam ist oder nicht.
<G-vec00106-002-s356><decide.sich_entscheiden><en> Decide which headline goes with which text, choosing from the two options given.
<G-vec00106-002-s356><decide.sich_entscheiden><de> Entscheiden Sie, welcher Titel zu welchem Text gehört; wählen Sie zwischen den zwei Vorschlägen aus.
<G-vec00106-002-s357><decide.sich_entscheiden><en> Decide on what breeds you like, and look through the help groups for these breeds in search of a suitable option.
<G-vec00106-002-s357><decide.sich_entscheiden><de> Antwort №9: Entscheiden Sie, was Sie züchten, und schauen Sie durch die Hilfegruppen für diese Rassen auf der Suche nach einer geeigneten Option.
<G-vec00106-002-s358><decide.sich_entscheiden><en> Decide which park you like best.
<G-vec00106-002-s358><decide.sich_entscheiden><de> Entscheiden Sie, welcher Park Ihnen am besten gefällt.
<G-vec00106-002-s359><decide.sich_entscheiden><en> - Decide when and where it makes sense to use React, and when to rethink the conventional MVC model.
<G-vec00106-002-s359><decide.sich_entscheiden><de> - Entscheiden Sie, wann und wo die Verwendung von React sinnvoll ist und wann Sie das herkömmliche MVC-Modell überdenken müssen.
<G-vec00106-002-s360><decide.sich_entscheiden><en> This means that you can find out for free what you’re owed and then decide if you want to proceed.
<G-vec00106-002-s360><decide.sich_entscheiden><de> Das heißt, dass Sie kostenlos herausfinden können, was Ihnen geschuldet wird, und anschließend entscheiden Sie, ob Sie mit dem Vorgang fortfahren möchten.
<G-vec00106-002-s361><decide.sich_entscheiden><en> Practically we decide for the nearest goodies, a steep northern slope down the eastern ridge of Annalper Joch.
<G-vec00106-002-s361><decide.sich_entscheiden><de> Praktisch entscheiden wir uns für das kürzeste Schmankerl, einen steilen Nordhang vom östlichen Grat des Annalper Jochs hinunter.
<G-vec00106-002-s362><decide.sich_entscheiden><en> As we see it’s not raining anymore we decide to drive to the city centre yet again.
<G-vec00106-002-s362><decide.sich_entscheiden><de> Wir sehen, dass es jetzt nicht mehr regnet, und so entscheiden wir uns, doch noch in die Innenstadt zu fahren.
<G-vec00106-002-s363><decide.sich_entscheiden><en> The change appeals to us, and we decide to fly there.
<G-vec00106-002-s363><decide.sich_entscheiden><de> Die Abwechslung reizt uns, und wir entscheiden uns, dorthin zu fliegen.
<G-vec00106-002-s364><decide.sich_entscheiden><en> This giant consumer goods fair spans eleven buildings, which we decide to attack from the rear. read more ›
<G-vec00106-002-s364><decide.sich_entscheiden><de> Die riesige Konsumgütermesse erstreckt sich über elf Gebäude, und wir entscheiden uns dazu, das Feld von hinten aufzurollen.
<G-vec00106-002-s365><decide.sich_entscheiden><en> We decide to stop in Sant Feliu de Guíxols for the night.
<G-vec00106-002-s365><decide.sich_entscheiden><de> Wir entscheiden uns in Sant Feliu de Guíxols eine Halt für die Nacht einzulegen.
<G-vec00106-002-s366><decide.sich_entscheiden><en> At this point, we decide to leave, as we don’t want to spoil the wonderful feeling we had when it was still early and nobody was in the garden alongside us.
<G-vec00106-002-s366><decide.sich_entscheiden><de> Hier entscheiden wir uns, zu gehen, denn wir möchten uns die Magie, die dieser Garten auf uns hat übergehen lassen, nicht mehr nehmen lassen.
<G-vec00106-002-s367><decide.sich_entscheiden><en> We decide to stay in the camp.
<G-vec00106-002-s367><decide.sich_entscheiden><de> Wir entscheiden uns im Camp zu bleiben.
<G-vec00106-002-s368><decide.sich_entscheiden><en> We are on the verge of robbing all the chocolate shops, but then decide to go for an original Belgian waffle.
<G-vec00106-002-s368><decide.sich_entscheiden><de> Wir sind kurz davor, sämtliche Schokoladen-Läden auszurauben, entscheiden uns dann aber für eine original belgische Waffel.
<G-vec00106-002-s369><decide.sich_entscheiden><en> We decide to return to Banff (the campground in Lake Louise is right next to the railway tracks) and simply sit tight for a day, because by all means we want to see the Icefields Parkway to Jasper in nice weather.
<G-vec00106-002-s369><decide.sich_entscheiden><de> Wir entscheiden uns, nach Banff zurückzukehren (der Campground in Lake Louise liegt unmittelbar neben den Bahnschienen) und einfach einen Tag zu abzuwarten, denn den Icefields Parkway nach Jasper wollen wir unbedingt bei schönem Wetter erleben.
<G-vec00106-002-s370><decide.sich_entscheiden><en> Zoom We browser the stands and decide to try on a dirndl and some lederhosen.
<G-vec00106-002-s370><decide.sich_entscheiden><de> Zoom Wir stöbern am Ständer und entscheiden uns, in ein Dirndl und eine Lederhose zu schlüpfen.
<G-vec00106-002-s371><decide.sich_entscheiden><en> You decide our level of involvement with your team so that your systems work properly.
<G-vec00106-002-s371><decide.sich_entscheiden><de> Sie entscheiden, bis zu welchem Level wir uns mit Ihrem Team involvieren.
<G-vec00106-002-s372><decide.sich_entscheiden><en> We make it ten kilometer far, in three or four hours, and decide to wait until the evening.
<G-vec00106-002-s372><decide.sich_entscheiden><de> Wir kommen zehn Kilometer weit, in drei oder vier Stunden, und entscheiden uns bis zum Abend zu warten.
<G-vec00106-002-s373><decide.sich_entscheiden><en> After a thorough examination and lengthy discussion, Dr. Greene and I decide on the mini pill.
<G-vec00106-002-s373><decide.sich_entscheiden><de> Nach einer sorgfältigen Untersuchung und einem ausführlichen Gespräch entscheiden Dr. Greene und ich uns für die Minipille.
<G-vec00106-002-s374><decide.sich_entscheiden><en> We decide to go to Kelly Lake, and agree upon $1,500 Can for the flight.
<G-vec00106-002-s374><decide.sich_entscheiden><de> Wir entscheiden uns für den Kelly Lake, und vereinbaren für den Flug inklusive Kanu 1.500 Can.$.
<G-vec00106-002-s375><decide.sich_entscheiden><en> As we understand the words, we decide whether we agree or disagree with the sentiments and ideas expressed through those words.
<G-vec00106-002-s375><decide.sich_entscheiden><de> Wenn wir die Worte verstehen entscheiden wir uns, ob wir den Meinungen und Ideen zustimmen oder nicht, die durch diese Worte ausgedrückt werden.
<G-vec00106-002-s376><decide.sich_entscheiden><en> As the weather gets more and more beautiful, we decide to take the path over the Silvretta High Alpine Road.
<G-vec00106-002-s376><decide.sich_entscheiden><de> Bei immer schöner werdendem Wetter, entscheiden wir uns für den Weg über die Silvretta Hochalpenstraße.
<G-vec00106-002-s377><decide.sich_entscheiden><en> Even though a thunderstorm is building up we decide to do the hike.
<G-vec00106-002-s377><decide.sich_entscheiden><de> Trotz dem drohenden Gewitter entscheiden wir uns, auf den Berg zu wandern.
<G-vec00106-002-s378><decide.sich_entscheiden><en> We decide on this therapy in cases where standard physical therapy has not been sufficiently successful.
<G-vec00106-002-s378><decide.sich_entscheiden><de> Wir entscheiden uns für diese Therapie, nachdem die standardisierte physikalische Therapie keine zufriedenstellenden Ergebnisse brachte.
<G-vec00106-002-s379><decide.sich_entscheiden><en> Thus, we decide to flee to Teheran.
<G-vec00106-002-s379><decide.sich_entscheiden><de> Somit entscheiden wir uns für die Flucht nach Teheran.
<G-vec00106-002-s380><decide.sich_entscheiden><en> The various German Design Council panels of experts will decide which organisations are eligible to enter the competition.
<G-vec00106-002-s380><decide.sich_entscheiden><de> Die Expertengremien des Rat für Formgebung entscheiden über die Zulassung zum Wettbewerb.
<G-vec00106-002-s381><decide.sich_entscheiden><en> There they are examined in detail, and doctors decide the issue of the term of their delivery.
<G-vec00106-002-s381><decide.sich_entscheiden><de> Dort werden sie im Detail untersucht, und Ärzte entscheiden über die Frage der Laufzeit ihrer Lieferung.
<G-vec00106-002-s382><decide.sich_entscheiden><en> The white proletariat and the Boer farmers form the base of apartheid - they decide the destiny of South Africa today.
<G-vec00106-002-s382><decide.sich_entscheiden><de> Das weisse Proletariat und die Burenfarmer bilden die Basis der Apartheid, sie entscheiden heute über das Schicksal Südafrikas.
<G-vec00106-002-s383><decide.sich_entscheiden><en> “As you explore the furthest reaches of space and encounter various factions, all vying for power, the character you decide to become will determine how this player-driven story unfolds.
<G-vec00106-002-s383><decide.sich_entscheiden><de> Während die Spieler die äußersten Gebiete des Weltraums erkunden und auf verschiedene, machthungrige Fraktionen treffen, entscheiden sie mit dem von ihnen entwickelten Charakter über den Verlauf der spielergetriebenen Handlung.
<G-vec00106-002-s384><decide.sich_entscheiden><en> There are many factors that decide the overall efficiency of a compressed air station.
<G-vec00106-002-s384><decide.sich_entscheiden><de> Viele Punkte entscheiden über die gesamte Energieeffizienz einer Druckluftanlage.
<G-vec00106-002-s385><decide.sich_entscheiden><en> At the start of the agreement you decide the length of the agreement and any options, such as service agreements or care agreements.
<G-vec00106-002-s385><decide.sich_entscheiden><de> Zu Beginn des Vertrags entscheiden Sie über die Vertragslaufzeit und alle Optionen, wie zum Beispiel die Servicevereinbarungen oder Wartungsvereinbarungen.
<G-vec00106-002-s386><decide.sich_entscheiden><en> In many cases, flawless, residue-free surfaces decide the quality of modern products.
<G-vec00106-002-s386><decide.sich_entscheiden><de> Makellose, rückstandsfreie Oberflächen entscheiden daher in vielen Fällen über die Qualität moderner Produkte.
<G-vec00106-002-s387><decide.sich_entscheiden><en> In a few days, the British will decide whether or not they want to stay in the EU.
<G-vec00106-002-s387><decide.sich_entscheiden><de> Die Folgen für die Wissenschaft In wenigen Tagen entscheiden die Briten über den Verbleib in der EU.
<G-vec00106-002-s388><decide.sich_entscheiden><en> Whether the stock exchange floor or the racetrack - speed and performance decide success or failure in both worlds.
<G-vec00106-002-s388><decide.sich_entscheiden><de> Ob Börsenparkett oder Rennstrecke - Schnelligkeit und Performance entscheiden in beiden Welten über Erfolg oder Misserfolg.
<G-vec00106-002-s389><decide.sich_entscheiden><en> You decide what the scope of our work will be: We are happy to explain your various options.
<G-vec00106-002-s389><decide.sich_entscheiden><de> Dabei entscheiden Sie über den Umfang unserer Arbeit: Wir erläutern Ihnen gern die verschiedenen Möglichkeiten.
<G-vec00106-002-s390><decide.sich_entscheiden><en> You decide the number and frequency of checks, and we handle the rest.
<G-vec00106-002-s390><decide.sich_entscheiden><de> Sie entscheiden über die Anzahl und Häufigkeit der Kontrollen, wir kümmern uns um den Rest.
<G-vec00106-002-s391><decide.sich_entscheiden><en> 4 expert juries, a youth jury and the audience will decide who is going to receive the total of 11 awards in the four competitions, all of them including a prize money amounting to 42,000 Euros.
<G-vec00106-002-s391><decide.sich_entscheiden><de> 4 Fachjurys, eine Jugendjury und das Publikum entscheiden über die Vergabe der insgesamt 11 Preise in den 4 Wettbewerben, die mit insgesamt 42.000 Euro dotiert sind.
<G-vec00106-002-s392><decide.sich_entscheiden><en> Hereby our customer’s decide which processing status is appropriate to the application of their product.
<G-vec00106-002-s392><decide.sich_entscheiden><de> Dabei entscheiden unsere Kunden über die einzelnen Verarbeitungsstufen angepasst an die Produktanwendung.
<G-vec00106-002-s393><decide.sich_entscheiden><en> You decide the composition of the shipping.
<G-vec00106-002-s393><decide.sich_entscheiden><de> Sie entscheiden über die Zusammensetzung der Sendung.
<G-vec00106-002-s394><decide.sich_entscheiden><en> Often also the specific skills and experience of the surgeon decide the outcome of the operation. The former method is applicable in practice and as part of the clinical routine only in small and / or low structured defects and reach the shaping and adaptation in complicated defects and implants quickly reach their limits of manufacturing technology.
<G-vec00106-002-s394><decide.sich_entscheiden><de> Oftmals entscheiden auch hier die besonderen Fähigkeiten und Erfahrungen des Chirurgen über das Ergebnis der Die erstgenannten Verfahren sind in der Praxis und im Rahmen der Kliniksroutine nur bei kleineren und/oder gering strukturierten Defekten anwendbar und gelangen zur Formung und Anpassung bei komplizierten Defekten und Implantaten schnell an ihre herstellungstechnischen Grenzen.
<G-vec00106-002-s395><decide.sich_entscheiden><en> In the traditional tendering process, suppliers are only able to decide two variables: First, whether to submit an offer or not; second, what product price to offer.
<G-vec00106-002-s395><decide.sich_entscheiden><de> Beim klassischen Ausschreibungsprozess hat ein Lieferant nur die Möglichkeit, über zwei Variable zu entscheiden: Zum einen über die Variable, ob der Lieferant überhaupt ein Angebot abgeben möchte.
<G-vec00106-002-s396><decide.sich_entscheiden><en> The sponsors decide the scope of supported packages but updates and security fixes will be available for all Debian users without cost.
<G-vec00106-002-s396><decide.sich_entscheiden><de> Die Sponsoren entscheiden über das Ausmaß der zu unterstützenden Pakete, jedoch werden Updates und die Behebung von Sicherheitslücken allen Debianbenutzern ohne Kosten zur Verfügung gestellt.
<G-vec00106-002-s397><decide.sich_entscheiden><en> You may decide the time.
<G-vec00106-002-s397><decide.sich_entscheiden><de> Sie entscheiden über die Zeit.
<G-vec00106-002-s398><decide.sich_entscheiden><en> Today, aromas and additives very often decide the success or failure of a new product.
<G-vec00106-002-s398><decide.sich_entscheiden><de> Heutzutage entscheiden Aromen und Zusatzstoffe nicht selten über den Erfolg oder Misserfolg eines neuen Produktes.
<G-vec00106-002-s399><decide.sich_entscheiden><en> How about I just show you the options and let you decide for yourself?
<G-vec00106-002-s399><decide.sich_entscheiden><de> Zeige ich Dir einfach die Marken, die es gibt und Du entscheidest selbst.
<G-vec00106-002-s400><decide.sich_entscheiden><en> You decide which assistant you use.
<G-vec00106-002-s400><decide.sich_entscheiden><de> Du entscheidest, welche Assistenten eingesetzt werden.
<G-vec00106-002-s401><decide.sich_entscheiden><en> You decide that.
<G-vec00106-002-s401><decide.sich_entscheiden><de> Du entscheidest das.
<G-vec00106-002-s402><decide.sich_entscheiden><en> Each has advantages and disadvantages - you decide which tank is best to use.
<G-vec00106-002-s402><decide.sich_entscheiden><de> Jedes Produkt hat Vorteile und Nachteile - Du entscheidest, welcher Panzer am besten geeignet ist.
<G-vec00106-002-s403><decide.sich_entscheiden><en> In inFamous 2, you must decide which path reluctant hero Cole MacGrath travels down – good or bad, come what may.
<G-vec00106-002-s403><decide.sich_entscheiden><de> Bei inFamous 2 entscheidest du, welchen Weg der zögerliche Superheld Cole MacGrath einschlägt – gut oder böse, auf Gedeih und Verderb.
<G-vec00106-002-s404><decide.sich_entscheiden><en> You decide which style brings the right sense to your bedroom.
<G-vec00106-002-s404><decide.sich_entscheiden><de> Du entscheidest, welcher Stil den richtigen Sinn in Dein Schlafzimmer bringt.
<G-vec00106-002-s405><decide.sich_entscheiden><en> You decide for yourself which tools and technologies you want to work with.
<G-vec00106-002-s405><decide.sich_entscheiden><de> Du entscheidest selbst, mit welchen Arbeitsgeräten und Technologien du arbeiten möchtest.
<G-vec00106-002-s406><decide.sich_entscheiden><en> Sound and voice volume can be controlled separately, so you can decide for yourself how loud you want to hear the game sound or your team mates.
<G-vec00106-002-s406><decide.sich_entscheiden><de> Sound- und Sprachlautstärke lassen sich getrennt regeln; so entscheidest du selbst, wie laut du den Game-Sound oder deine Teamkollegen hören willst.
<G-vec00106-002-s407><decide.sich_entscheiden><en> We will inform you if there is an order close by and you decide whether you want to take the job or not.
<G-vec00106-002-s407><decide.sich_entscheiden><de> Wir informieren dich, wenn es in deiner Nähe Lieferaufträge gibt und du entscheidest, ob du den Job übernehmen möchtest oder nicht.
<G-vec00106-002-s408><decide.sich_entscheiden><en> You decide when you want to jump onto the train.
<G-vec00106-002-s408><decide.sich_entscheiden><de> Du entscheidest, wann du aufspringen möchtest.
<G-vec00106-002-s409><decide.sich_entscheiden><en> On Mantil Island (as Fish Eye told you) you can find Thomas Cook, an old pirate who wants you to decide which of his sons is worth to wear the family bandana.
<G-vec00106-002-s409><decide.sich_entscheiden><de> Auf der Mantil Insel (wie Fischauge dir erzählt hat) findest du Thomas Cook, einen alten Piraten, der möchte, dass du entscheidest, welcher seiner Söhne es wert ist, das Familienkopftuch zu tragen.
<G-vec00106-002-s410><decide.sich_entscheiden><en> Self-effecacy means that you – and only you – decide what your life path looks like.
<G-vec00106-002-s410><decide.sich_entscheiden><de> Selbstwirksam bedeutet, dass Du – und nur Du – entscheidest, wie Dein Lebensweg aussieht.
<G-vec00106-002-s411><decide.sich_entscheiden><en> You decide with your tip what the tour is worth it.
<G-vec00106-002-s411><decide.sich_entscheiden><de> Die Guides werden belohnt, indem Du mit Deinem Trinkgeld entscheidest, wieviel Dir die Tour Wert war.
<G-vec00106-002-s412><decide.sich_entscheiden><en> If you decide to make your cuts with a blade, place a piece of cardboard, wood, or other protective board under the leather to protect the surface you are cutting on.
<G-vec00106-002-s412><decide.sich_entscheiden><de> Wenn du entscheidest, die Schnitte mit einer Klinge zu machen, lege ein Stück Karton, Holz oder ein anderes schützendes Material unter das Leder und schütze so die Oberfläche auf der du schneidest.
<G-vec00106-002-s413><decide.sich_entscheiden><en> For instance, if you decide, "I will be kind in every moment.
<G-vec00106-002-s413><decide.sich_entscheiden><de> Wenn du zum Beispiel entscheidest „Ich will in jedem Moment freundlich sein.
<G-vec00106-002-s414><decide.sich_entscheiden><en> List in the last two title boxes what you will decide to do positively tomorrow starting with “tomorrow I…”.
<G-vec00106-002-s414><decide.sich_entscheiden><de> Liste in den letzten zwei Titelkästen, was du entscheidest, morgen positiv zu machen, beginnend mit "morgen ich...".
<G-vec00106-002-s415><decide.sich_entscheiden><en> You yourself decide what route you'll take – take the liberty of being yourself, even when it comes to choosing your ideal watch.
<G-vec00106-002-s415><decide.sich_entscheiden><de> Du selbst entscheidest, welchen Weg Du gehst – nimmst Dir die Freiheit, Du selbst zu sein, auch bei der Wahl Deiner Uhr.
<G-vec00106-002-s416><decide.sich_entscheiden><en> Content you submit to the forum belongs to you, and you decide what permission to give others for it.
<G-vec00106-002-s416><decide.sich_entscheiden><de> Die Inhalte, die du im Forum einreichst, gehören dir, und du entscheidest, welche Berechtigung du anderen dafür gibst.
<G-vec00106-002-s417><decide.sich_entscheiden><en> It’s still good to know about them, just in case the day comes when you decide your studio needs one.
<G-vec00106-002-s417><decide.sich_entscheiden><de> Ist es doch gut, über sie Bescheid zu wissen, nur für den Fall, dass Du eines Tages entscheidest, dass Dein Studio eines braucht.
<G-vec00106-002-s418><decide.sich_entscheiden><en> Titan Poker will team up the players on a daily basis, on a first to register, first to be served level and will also decide on the roles of the players within the team.
<G-vec00106-002-s418><decide.sich_entscheiden><de> Titan Poker stellt die Teams täglich und in chronologischer Reihenfolge (Wer zuerst kommt, malt zuerst) zusammen und entscheidet auch über die Zuordnung der Rollen im Team.
<G-vec00106-002-s419><decide.sich_entscheiden><en> 19) The client will decide freely and responsibly, which address information, including his/her email address and name, will be displayed in the listing.
<G-vec00106-002-s419><decide.sich_entscheiden><de> 19) Der Auftraggeber entscheidet frei und eigenverantwortlich, welche Adressangaben einschließlich seiner Emailadresse und seines Namens als Ansprechpartner in den Einträgen angezeigt werden.
<G-vec00106-002-s420><decide.sich_entscheiden><en> For creditors whose claims are contested by the debtor or by the insolvency administrator, and in the case of creditors with a right to separate satisfaction, the insolvency court shall decide on its own discretion on the requirement for consent to be given by such creditors or a security to be provided to them.
<G-vec00106-002-s420><decide.sich_entscheiden><de> Bei Gläubigern, deren Forderungen vom Schuldner oder vom Insolvenzverwalter bestritten werden, und bei absonderungsberechtigten Gläubigern entscheidet das Insolvenzgericht nach freiem Ermessen, inwieweit es einer Zustimmung dieser Gläubiger oder einer Sicherheitsleistung gegenüber ihnen bedarf.
<G-vec00106-002-s421><decide.sich_entscheiden><en> 5. The Council shall decide, on the basis of a proposal from the Commission, on any amendment to Annex I.
<G-vec00106-002-s421><decide.sich_entscheiden><de> (5) Der Rat entscheidet auf Vorschlag der Kommission über jede Änderung des Anhangs I.
<G-vec00106-002-s422><decide.sich_entscheiden><en> Even if something comes to mind from the environment, it is always up to the brain to decide what value it may have to be taken into account.
<G-vec00106-002-s422><decide.sich_entscheiden><de> Auch wenn einem irgendetwas aus der Umwelt einfällt, liegt es immer am Gehirn, das entscheidet, welchen Wert es eventuell hat, um berücksichtigt zu werden.
<G-vec00106-002-s423><decide.sich_entscheiden><en> In the end HERE Maps only provides the map database for Opel and they decide when they make an update for which system.
<G-vec00106-002-s423><decide.sich_entscheiden><de> „HERE“ stellt nur die Kartendatenbank für Opel bereit und Opel entscheidet, wann für welche Systeme eine Aktualisierung gemacht wird.
<G-vec00106-002-s424><decide.sich_entscheiden><en> If both are really selected go to Objects-->Align and decide how the text should be aligned).
<G-vec00106-002-s424><decide.sich_entscheiden><de> Wenn beide wirklich selektiert sind, geht man zu Objects-->Align und entscheidet, wie der Text zur Box hin ausgerichtet werden soll).
<G-vec00106-002-s425><decide.sich_entscheiden><en> The committee of the association will decide on admission.
<G-vec00106-002-s425><decide.sich_entscheiden><de> Über die Aufnahme entscheidet der Vorstand.
<G-vec00106-002-s426><decide.sich_entscheiden><en> Before you buy, think about the purposes for which you need your laminator and then decide which model suits you best.
<G-vec00106-002-s426><decide.sich_entscheiden><de> Bevor es an den Kauf geht, überlegt ihr euch am besten, für welche Zwecke ihr euer Laminiergerät benötigt und entscheidet dann, welches Modell am besten zu euch passt.
<G-vec00106-002-s427><decide.sich_entscheiden><en> After 12 to 24 months, Swisscom will decide which suppliers need to be reassessed, provided the supplier has not initiated the reassessment themselves.
<G-vec00106-002-s427><decide.sich_entscheiden><de> Nach 12 bis 24 Monaten entscheidet Swisscom, bei welchen Lieferanten eine Neubewertung erforderlich ist, sofern der Lieferant das Re-Assessment nicht selbständig eingeleitet hat.
<G-vec00106-002-s428><decide.sich_entscheiden><en> In cases of a tie, the Chairperson has a right to decide.
<G-vec00106-002-s428><decide.sich_entscheiden><de> Bei Stimmengleichheit entscheidet der Vorsitzende.
<G-vec00106-002-s429><decide.sich_entscheiden><en> This suspension shall apply until the next annual general meeting, which will decide upon the expulsion of the member.
<G-vec00106-002-s429><decide.sich_entscheiden><de> Die Suspendierung endet zum Zeitpunkt der nächsten Generalversammlung, die dann über einen Ausschluss des Mitglieds entscheidet.
<G-vec00106-002-s430><decide.sich_entscheiden><en> Upon motion being submitting by the executive board, the general assembly shall decide on the said expulsion with a majority of three quarters of the votes cast by the members present.
<G-vec00106-002-s430><decide.sich_entscheiden><de> Über den Ausschluss entscheidet auf Antrag des Vorstands die Mitgliederversammlung mit einer Mehrheit von drei Vierteln der anwesenden Mitglieder.
<G-vec00106-002-s431><decide.sich_entscheiden><en> The Electoral Board shall decide on the validity of the votes cast and on any queries and objections arising during the poll and during the counting of votes.
<G-vec00106-002-s431><decide.sich_entscheiden><de> Der Wahlvorstand entscheidet über die Gültigkeit der abgegebenen Stimmen und über alle bei der Wahlhandlung und bei der Ermittlung des Wahlergebnisses sich ergebenden Anstände.
<G-vec00106-002-s432><decide.sich_entscheiden><en> Top Unless otherwise agreed by the parties, the arbitrator will decide whether hearings must be held to present arguments, hear evidence and enter pleadings, or whether this can be done exclusively in writing.
<G-vec00106-002-s432><decide.sich_entscheiden><de> Vorbehaltlich einer anders lautenden Vereinbarung der Parteien entscheidet der Schiedsrichter, ob Verhandlungstermine für Einlassungen, die Beweisaufnahme und den Vortrag der Schlussanträge anzusetzen sind oder ob die Rechtshandlungen ausschließlich in Schriftform erfolgen.
<G-vec00106-002-s433><decide.sich_entscheiden><en> The latter shall also decide in cases where no agreement can be reached on the number of assessors.
<G-vec00106-002-s433><decide.sich_entscheiden><de> Dieses entscheidet auch, wenn kein Einverständnis über die Zahl der Beisitzer erzielt wird.
<G-vec00106-002-s434><decide.sich_entscheiden><en> In cases of dispute, a labour court has to decide on the person who is to chair the board and on the number of the board's members.
<G-vec00106-002-s434><decide.sich_entscheiden><de> Im Streitfall entscheidet über die Person des Vorsitzenden und die Anzahl der Beisitzer das Arbeitsgericht.
<G-vec00106-002-s435><decide.sich_entscheiden><en> And if all this doesn’t decide the winner, then we will decide it by lots.
<G-vec00106-002-s435><decide.sich_entscheiden><de> Und wenn das alles nicht hilft, entscheidet das Los.
<G-vec00106-002-s436><decide.sich_entscheiden><en> 1. If the Commission finds that expenditure as indicated in Article 3(1) and Article 4 has been incurred in a way that has infringed Community rules, it shall decide what amounts are to be excluded from Community financing in accordance with the procedure referred to in Article 41(3).
<G-vec00106-002-s436><decide.sich_entscheiden><de> Konformitätsabschluss (1) Die Kommission entscheidet nach dem in Artikel 41 Absatz 3 genannten Verfahren, welche Beträge von der gemeinschaftlichen Finanzierung auszuschließen sind, wenn sie feststellt, dass Ausgaben nach Artikel 3 Absatz 1 und Artikel 4 nicht in Übereinstimmung mit den Gemeinschaftsvorschriften getätigt worden sind.
<G-vec00106-002-s437><decide.sich_entscheiden><en> A very low percentage of Ethiopian arrivals decide to seek asylum in Yemen, partly due to a lack of awareness and access to asylum mechanisms, or do not meet the criteria to be recognized as refugees.
<G-vec00106-002-s437><decide.sich_entscheiden><de> Ein sehr geringer Prozentsatz der äthiopischen Ankömmlinge entscheidet sich für ein Asylgesuch im Jemen, teilweise aus mangelndem Bewusstsein und Zugang zum Asylverfahren oder weil sie die Kriterien zur Flüchtlingsanerkennung nicht erfüllen.
<G-vec00106-002-s438><decide.sich_entscheiden><en> At one of the many touchpoints, they decide whether to buy, buy again, recommend, or whether they are willing to pay a premium price.
<G-vec00106-002-s438><decide.sich_entscheiden><de> An einem der vielen Touchpoints entscheidet er sich, ob er kauft, wieder kauft, weiterempfiehlt oder ob er bereit ist, ein Preispremium zu bezahlen.
<G-vec00106-002-s439><decide.sich_entscheiden><en> Its criteria decide whether the purchase or sale of drinkable South American water, arable Sudanese land, or Württembergian sewage plants can be financed and turned into the basis of new securities that provide the market with a new supply of speculative material.
<G-vec00106-002-s439><decide.sich_entscheiden><de> Das entscheidet nach seinen Kriterien, ob sich der An- und Verkauf südamerikanischen Trinkwassers, sudanesischen Ackerlandes oder württembergischer Kläranlagen finanzieren und zur Grundlage neuer Wertpapiere machen lässt, die dem Markt neuen Zufluss an spekulativem Stoff verschaffen.
<G-vec00106-002-s440><decide.sich_entscheiden><en> Those who visit the lake always come back... or perhaps they decide to change their life and live here.
<G-vec00106-002-s440><decide.sich_entscheiden><de> Wer einmal den See gesehen hat, kommt immer wieder zurück... oder entscheidet sich, für immer hier zu bleiben.
<G-vec00106-002-s441><decide.sich_entscheiden><en> If you decide to limit the accessibility of your content to anybody except yourself or to a certain group of people, this does not influence the storage of your information by PUSHAR.
<G-vec00106-002-s441><decide.sich_entscheiden><de> Entscheidet sich der Nutzer für eine Beschränkung der Zugriffsmöglichkeiten auf gar keine oder nur ausgewählte Dritte, so änder dies nichts an der Speicherung des Contents durch PUSHAR.
<G-vec00106-002-s442><decide.sich_entscheiden><en> 27 - Editorial decide to spend their summer holiday in Apulia. They go to a travel agency in order to book their family holiday at the holiday resort requested.
<G-vec00106-002-s442><decide.sich_entscheiden><de> Familie Hofer aus Südtirol entscheidet sich für einen Sommerurlaub in Apulien und begibt sich ins Reisebüro um dort den Familienurlaub in der gewünschten Ferienanlage zu buchen.
<G-vec00106-002-s443><decide.sich_entscheiden><en> In case that customers want to shop in the pro shop after spending time on the driving range, or decide to rent a golf cart, they can use their deposit to do so.
<G-vec00106-002-s443><decide.sich_entscheiden><de> Entscheidet sich der Kunde nach der Drivingrange noch ein paar Dinge im ProShop einzukaufen oder ein Cart zu mieten, kann auch dies mittels seines Guthabens erfolgen.
<G-vec00106-002-s444><decide.sich_entscheiden><en> The artist alone is at liberty to decide what should happen (or not happen) (13) and when –in the attempt to subject the art form itself to a closer interrogation.
<G-vec00106-002-s444><decide.sich_entscheiden><de> Allein der Künstler entscheidet frei, was sich wo wie lange ereignen wird – oder auch nicht (13) – in dem Versuch, auch die Kunstform selbst stärker zu befragen.
<G-vec00106-002-s445><decide.sich_entscheiden><en> At the end of the day, they are the ones to decide how quickly the player can progress in the game, what and how many rewards the player will receive, and how difficult conquering the Blade Coast should be.
<G-vec00106-002-s445><decide.sich_entscheiden><de> Hier entscheidet sich am Ende des Tages, wie schnell der Spieler im Spiel voranschreitet, welche und wieviele Belohnungen dieser erhält und ob die Klingenküste einfach oder schwer zu erobern ist.
<G-vec00106-002-s446><decide.sich_entscheiden><en> After a few errands in your home village, where the elements of the game are sparely taught to you, you decide which side you want to align with for the time and then you do quests for your chosen fraction.
<G-vec00106-002-s446><decide.sich_entscheiden><de> Nach ein paar anfänglichen Quests im Dorf, bei denen man die einzelnen Elemente des Spiels mehr schlecht als recht erklärt bekommt, entscheidet man sich bald für eine der beiden Seiten und erledigt Quests für die jeweilige Fraktion.
<G-vec00106-002-s447><decide.sich_entscheiden><en> With the production of this project the participant will decide which technical means will be used: the construction of Apps, the use of projection mapping procedures, the construction of Quartz-Compositions or Max / MSP patches, or other technologies.
<G-vec00106-002-s447><decide.sich_entscheiden><de> Bei der Erstellung der eigenen Arbeit entscheidet sich welche technischen Mittel eingesetzt werden: sei dies nun die Nutzung von Apps oder Programmen, die Anwendung von Projektions-Verfahren, das Erstellen von einfachen Programmierskripten, oder anderer Technologien.
<G-vec00106-002-s448><decide.sich_entscheiden><en> Course of the game[edit] After setting the desired parameters in the options screen (see more in section "Hints" below) you decide on which map the game should take place.
<G-vec00106-002-s448><decide.sich_entscheiden><de> Spielablauf[Bearbeiten] Nachdem man im Auswahlbildschirm die gewünschten Parameter eingestellt hat (näheres hierzu s. "Hinweise" weiter unten) entscheidet man sich auf welcher Karte das Spiel stattfinden soll.
<G-vec00106-002-s449><decide.sich_entscheiden><en> The next moment will decide the fate of the closet alchemist playing with the elements in the privacy of his garret.
<G-vec00106-002-s449><decide.sich_entscheiden><de> Im nächsten Augenblick entscheidet sich das weitere Schicksal des unzeitgemäßen Alchimisten, der heimlich auf dem Dachboden mit den Elementen hantiert.
<G-vec00106-002-s450><decide.sich_entscheiden><en> Should TIPWIN decide to close a user’s account for any reason, bets which have already been placed and accepted within the general terms and conditions and sports rules will not be voided, and the user will be paid any winnings.
<G-vec00106-002-s450><decide.sich_entscheiden><de> Entscheidet sich TIPWIN, das Konto eines Nutzers aus irgendeinem gerechtfertigten Grund zu schließen, so werden die bereits gesetzten und angenommenen Wetten innerhalb der Allgemeinen Geschäftsbedingungen und Sportregeln nicht annulliert und die Nutzer bekommen alle Gewinne ausbezahlt.
<G-vec00106-002-s451><decide.sich_entscheiden><en> Complaints department worker will assess the claimed defect and decide the merits of the claim and whether it is a fundamental breach of contract or irrelevant, if possible immediately.
<G-vec00106-002-s451><decide.sich_entscheiden><de> Der Mitarbeiter der Reklamationsabteilung beurteilt den reklamierten Mangel und entscheidet möglichst sofort über die Begründetheit der Reklamation und ob es sich um eine wesentliche oder nicht wesentliche Verletzung des Vertrags handelt.
<G-vec00106-002-s452><decide.sich_entscheiden><en> A high percentage of patients from the USA, Norway, and the UK decide to seek fertility care abroad because of their desire for access to anonymous egg donors.
<G-vec00106-002-s452><decide.sich_entscheiden><de> Ein hoher Prozentsatz der Patienten aus den USA, Norwegen und Großbritannien entscheidet sich für eine Fruchtbarkeitsversorgung im Ausland, weil sie den Zugang zu anonymen Eizellspenderinnen wünschen.
<G-vec00106-002-s453><decide.sich_entscheiden><en> Very often a person may decide to quit the CCP in just a few minutes.
<G-vec00106-002-s453><decide.sich_entscheiden><de> Sehr oft entscheidet sich eine Person innerhalb weniger Minuten zum Austritt aus der KPCh.
<G-vec00106-002-s454><decide.sich_entscheiden><en> While cloud solutions require the transmission of information to a remote server in a data center, with on-premises software you can keep all data with you unless you decide to use cloud storage.
<G-vec00106-002-s454><decide.sich_entscheiden><de> Während Cloud-Lösungen die Übertragung von Informationen an einen entfernten Server in einem Rechenzentrum voraussetzen, behält man bei On-Premises-Software alle Daten bei sich – außer man entscheidet sich, einen Cloud-Speicher einzusetzen.
<G-vec00106-002-s455><decide.sich_entscheiden><en> In this case, the association may decide to exclusively create association EPDs so that its members may not create individualized EPDs or their own EPDs through the association.
<G-vec00106-002-s455><decide.sich_entscheiden><de> In diesem Fall entscheidet sich der Verband, ausschließlich Verbands-EPDs zu erstellen, sodass seine Mitglieder keine individualisierten EPDs oder eigene EPDs über den Verband erstellen können.
<G-vec00106-002-s494><decide.sich_entscheiden><en> We decide together on a case-by-case basis how this business can be contractually arranged.
<G-vec00106-002-s494><decide.sich_entscheiden><de> Wie dieses Geschäft vertraglich zu regeln ist, wird von Fall zu Fall gemeinsam entschieden.
<G-vec00106-002-s496><decide.sich_entscheiden><en> After the game computer has dealt 2 cards for each hand and 1 card for himself you have to decide for each hand, which activity you would like to perform.
<G-vec00106-002-s496><decide.sich_entscheiden><de> Nachdem der Spielcomputer für jede Hand 2 Karten und für sich selbst eine Karte gegeben hat, musst du für jede Hand entschieden, welche Aktion du durchführen willst.
<G-vec00106-002-s497><decide.sich_entscheiden><en> Turning the spacecraft by 90 degrees took around 30 minutes, so it was necessary to decide which experiment would be the main instrument before each of the rapid flybys.
<G-vec00106-002-s497><decide.sich_entscheiden><de> Da eine Drehung der Sonde um 90 Grad zirka 30 Minuten dauerte, musste vor den schnellen Vorbeiflügen entschieden werden, welches Experiment das Hauptinstrument sein sollte.
<G-vec00106-002-s498><decide.sich_entscheiden><en> Voters should decide on the new constitution and will be able to elect a new parliament within a few months.
<G-vec00106-002-s498><decide.sich_entscheiden><de> Über die neue Verfassung, Neuwahlen und danach indirekt eine neue Regierung sollte nicht mehr auf der Straße gestritten, sondern an den Urnen durch das gesamte ägyptische Wahlvolk entschieden werden.
<G-vec00106-002-s499><decide.sich_entscheiden><en> Ultimately, the church councils did not decide if a book was Scripture; that was decided when the human author was chosen by God to write.
<G-vec00106-002-s499><decide.sich_entscheiden><de> Letztendlich hat nicht das Kirchenoberhaupt entschieden, ob ein Buch zur heiligen Schrift gehörte; das wurde entschieden, wenn der menschliche Autor von Gott ausgewählt wurde.
<G-vec00106-002-s500><decide.sich_entscheiden><en> Once you decide what time of day works best for you and form some kind of writing schedule, stick to that schedule.
<G-vec00106-002-s500><decide.sich_entscheiden><de> Wenn du einmal entschieden hast, zu welcher Zeit des Tages du am besten arbeitest, solltest du eine Art Schreibplan erstellen und dich auch an diesen Plan halten.
<G-vec00106-002-s501><decide.sich_entscheiden><en> The State Labor Court of Rheinland-Pfalz had to decide on the consequences arising from a secret recording of a staff appraisal by using a Smartphone.
<G-vec00106-002-s501><decide.sich_entscheiden><de> Das LAG Rheinland-Pfalz hat entschieden, welche Folge die heimliche Aufnahme eines Personalgesprächs mit dem Smartphone für den Arbeitnehmer hat.
<G-vec00106-002-s502><decide.sich_entscheiden><en> These departments would then check the proposals, make a final project selection and decide on the financing.
<G-vec00106-002-s502><decide.sich_entscheiden><de> Die DEZA und das SECO prüften die Projektanträge, nahmen die definitive Auswahl der Projekte vor und entschieden über die Finanzierung.
<G-vec00106-002-s503><decide.sich_entscheiden><en> It is then only possible to decide with some certain knowledge whether the journey can be continued at all.
<G-vec00106-002-s503><decide.sich_entscheiden><de> Nur mit Sachkenntnis kann dann entschieden werden, ob die Fahrt überhaupt fortgesetzt werden kann.
<G-vec00106-002-s504><decide.sich_entscheiden><en> We shall, therefore, only have to hand over the matter to the experimenters, and, while waiting for them to finally decide the debate, not to preoccupy ourselves with these disquieting problems, and to tranquilly continue our work as if the principles were still uncontested.
<G-vec00106-002-s504><decide.sich_entscheiden><de> Wir können es also nur den Experimentatoren überlassen und sollten uns, bis sie den Streit endgültig entschieden haben, nicht mit diesen beunruhigenden Problemen beschäftigen, sondern unsere Arbeiten ruhig fortsetzen, als ob die Prinzipien noch nicht angefochten wären.
<G-vec00106-002-s505><decide.sich_entscheiden><en> Through the analysis of the most common genetic causes associated with male factor infertility, affected men not only discover the reason behind their reduced sperm quality—but they also have the opportunity to discuss the results of these finding with their doctor, and decide how this information will influence their plans to start a family.
<G-vec00106-002-s505><decide.sich_entscheiden><de> Durch die Analyse der häufigsten genetischen Ursachen für männliche Unfruchtbarkeit können betroffene Männer nicht nur die Gründe der eingeschränkten Samenqualität erfahren und somit eine Erklärung bekommen, sondern es kann auch ganz individuell mit dem Arzt entschieden werden, welche Konsequenzen dieser Befund für einen Kinderwunsch hat.
<G-vec00106-002-s506><decide.sich_entscheiden><en> We will then decide whether and under what conditions a course of study is still possible for you.
<G-vec00106-002-s506><decide.sich_entscheiden><de> Im Anschluss wird entschieden, ob und unter welchen Voraussetzungen für Sie ein Studium trotzdem möglich ist.
<G-vec00106-002-s507><decide.sich_entscheiden><en> I’ve clearly decide that the second way is more reasonable and constructive.
<G-vec00106-002-s507><decide.sich_entscheiden><de> Ich habe eindeutig entschieden, dass der zweite Weg sinnvoller und konstruktiver ist.
<G-vec00106-002-s508><decide.sich_entscheiden><en> That must have hit really hard for the self-appointed representatives of “The People’s Vote”, because the people did not decide as “Bild” had expected them to.
<G-vec00106-002-s508><decide.sich_entscheiden><de> Das muss die selbsternannten Vertreter von „Volkes Stimme“ ins Mark und Bein treffen, denn das Volk hatte nicht so entschieden, wie es die Bild-Zeitung erwartet hatte.
<G-vec00106-002-s509><decide.sich_entscheiden><en> They are announced on <debian-devel-announce@lists.debian.org> and the announcement explains which area will be the focus of the party: usually they focus on release critical bugs but it may happen that they decide to help finish a major upgrade (like a new perl version which requires recompilation of all the binary modules).
<G-vec00106-002-s509><decide.sich_entscheiden><de> Sie werden auf <debian-devel-announce@lists.debian.org> angekündigt und in der Ankündigung wird erklärt, auf welchem Bereich der Fokus der Party liegt: Üblicherweise liegt der Fokus auf release-kritischen Fehlern, aber es kann vorkommen, dass entschieden wird, bei der Fertigstellung eines Haupt-Upgrades zu helfen (wie einer neuen perl-Version, die ein Neukompilieren aller binären Module erfordert).
<G-vec00106-002-s510><decide.sich_entscheiden><en> I regret that I did not decide earlier.
<G-vec00106-002-s510><decide.sich_entscheiden><de> Ich bedaure, dass ich mich nicht schon früher entschieden habe.
<G-vec00106-002-s511><decide.sich_entscheiden><en> As soon as a fault message is received, a service technician promptly carries out a remote diagnosis and liaises with the operating personnel to decide what measures are to be taken.
<G-vec00106-002-s511><decide.sich_entscheiden><de> Sobald die Fehlermeldung eintrifft, führt ein Servicetechniker sofort eine Ferndiagnose durch und setzt sich mit dem Bedienpersonal in Verbindung - dann wird entschieden, welche Maßnahmen getroffen werden.
<G-vec00106-002-s512><decide.sich_entscheiden><en> You can of course isolate any number of moments that decide a sporting event, but this one proved especially visceral for the Gnomes.
<G-vec00106-002-s512><decide.sich_entscheiden><de> Du kannst bei jeder Sportveranstaltung Momente benennen, die ein Spiel entschieden haben, und dieser Moment war schon ein Wirkungstreffer bei den Gnomes.
<G-vec00106-002-s589><decide.sich_entscheiden><en> If the city would have lived up to its aspirations, refugees could decide on their own in which flat they want to live.
<G-vec00106-002-s589><decide.sich_entscheiden><de> Hätte die Stadt ihre eigenen Ansprüche umgesetzt, könnten Geflüchtete selbst entscheiden, in welcher Wohnung sie leben möchten.
<G-vec00106-002-s590><decide.sich_entscheiden><en> But at the end of the day they were allowed to decide what they wanted to film.
<G-vec00106-002-s590><decide.sich_entscheiden><de> Aber letztlich durften sie selbst entscheiden, was sie filmen wollten.
<G-vec00106-002-s591><decide.sich_entscheiden><en> By following online courses you can, to a great extent, decide at what time you want to study.
<G-vec00106-002-s591><decide.sich_entscheiden><de> Wenn Sie Onlinekursen belegen, können Sie bis zu einem gewissen Punkt selbst entscheiden, wann Sie lernen möchten.
<G-vec00106-002-s592><decide.sich_entscheiden><en> In this case the client can decide if the deposit will be refunded or credited for a future stay. Book Request availability
<G-vec00106-002-s592><decide.sich_entscheiden><de> In diesen Fällen darf der Gast selbst entscheiden ob die geleistete Anzahlung zurückerstattet oder für einen zukünftigen Aufenthalt gutgeschrieben wird.
<G-vec00106-002-s593><decide.sich_entscheiden><en> Each observer should so decide which meaningful moment is seen and felt in the image.
<G-vec00106-002-s593><decide.sich_entscheiden><de> Jeder Betrachter solle so selbst entscheiden, welcher bedeutungsvolle Moment im Bild sichtbar und spürbar wird.
<G-vec00106-002-s594><decide.sich_entscheiden><en> This caused more than one headache to design, but it’s your adventure, and we wanted you to decide where your next stop would be.
<G-vec00106-002-s594><decide.sich_entscheiden><de> Das hat uns während der Entwicklung zwar einige Kopfschmerzen bereitet, aber es ist euer Abenteuer und wir wollten, dass ihr selbst entscheiden könnt, wohin euch eure Reise als Nächstes führt.
<G-vec00106-002-s595><decide.sich_entscheiden><en> The visitor may decide which cookies to accept in their Internet browser settings.
<G-vec00106-002-s595><decide.sich_entscheiden><de> Der Besucher der Webseite kann selbst entscheiden, welche Cookies er in den Einstellungen seines Webbrowsers akzeptiert möchte.
<G-vec00106-002-s596><decide.sich_entscheiden><en> It is up to the user to decide which meal is to be served.
<G-vec00106-002-s596><decide.sich_entscheiden><de> Um welche Mahlzeit es sich dabei handelt, dass kann der Nutzer selbst entscheiden.
<G-vec00106-002-s597><decide.sich_entscheiden><en> Text proposed by the Commission Amendment (19)While this Directive does not increase the overall amount of admissible advertising time during the period from 7:00 to 23:00, it is important for broadcasters to have more flexibility and to be able to decide when to place advertising in order to maximise advertisers' demand and viewers' flow.
<G-vec00106-002-s597><decide.sich_entscheiden><de> (19)Diese Richtlinie sieht zwar keine Verlängerung der zulässigen Gesamtwerbedauer im Zeitraum von 7.00 bis 23.00 Uhr vor, es ist jedoch wichtig, dass die Fernsehveranstalter mehr Flexibilität erhalten und selbst entscheiden können, wann sie Werbung platzieren, um die Nachfrage der Werbenden und den Zuschauerfluss bestmöglich aufeinander abzustimmen.
<G-vec00106-002-s598><decide.sich_entscheiden><en> Note: You can decide whether to transfer updates securely to your customer account by selecting the corresponding option in the publication settings.
<G-vec00106-002-s598><decide.sich_entscheiden><de> Bemerkung: Sie können selbst entscheiden, ob Updates auf sicherem Wege an Ihr Kundenkonto übertragen werden sollen, indem Sie in den Veröffentlichungseinstellungen die entsprechende Option aktivieren.
<G-vec00106-002-s599><decide.sich_entscheiden><en> You can decide which border crossing you would like to use.
<G-vec00106-002-s599><decide.sich_entscheiden><de> Sie können selbst entscheiden, welchen Grenzübergang sie nutzen möchten.
<G-vec00106-002-s600><decide.sich_entscheiden><en> You can also make settings in your Internet browser so that you are informed when cookies are saved and you can then decide in each individual case if you wish to accept the cookie or not.
<G-vec00106-002-s600><decide.sich_entscheiden><de> Sie können Ihren Internetbrowser auch so einstellen, dass Sie über das Speichern von Cookies informiert werden, in jedem Einzelfall können Sie dann selbst entscheiden, ob Sie Cookies akzeptieren oder nicht.
<G-vec00106-002-s601><decide.sich_entscheiden><en> Everyone must decide for themselves what is convenient.
<G-vec00106-002-s601><decide.sich_entscheiden><de> Jeder Mensch muss selbst für sich entscheiden, was günstig ist.
<G-vec00106-002-s602><decide.sich_entscheiden><en> All of them have their advantages and disadvantages, and we have tried our best to indicate them in the comparison table for your own convenience to decide what to choose.
<G-vec00106-002-s602><decide.sich_entscheiden><de> Alle haben ihre Vor- und Nachteile, und wir haben unser Bestes getan, um sie in der Vergleichstabelle anzugeben, damit Sie selbst entscheiden können, was Sie wählen möchten.
<G-vec00106-002-s603><decide.sich_entscheiden><en> It is on you to decide how long you desire the lady´s company for.
<G-vec00106-002-s603><decide.sich_entscheiden><de> Sie können selbst entscheiden, wie lange Sie die Escort Begleitung der Dame wünschen.
<G-vec00106-002-s604><decide.sich_entscheiden><en> The user can decide if the newly created password is only accessible for himself/herself, or if it is a public password and therefore the normal folder inheritance of rights takes effect.
<G-vec00106-002-s604><decide.sich_entscheiden><de> Der Benutzer kann selbst entscheiden, ob das neu angelegte Passwort nur für ihn persönlich zugänglich ist, oder ob es ein öffentliches Passwort ist und somit die normale Ordner-Vererbung der Rechte zum Tragen kommt.
<G-vec00106-002-s605><decide.sich_entscheiden><en> Moreover, it added a humane dimension: the active self-help, self-determination, and the right to decide on the countries’ own food supplies.
<G-vec00106-002-s605><decide.sich_entscheiden><de> Darüber hinaus kam eine menschliche Dimension hinzu: die aktive Selbsthilfe, die Selbstbestimmung und das Recht der Länder, über ihren eigenen Ernährungsbedarf selbst zu entscheiden.
<G-vec00106-002-s606><decide.sich_entscheiden><en> Visitors can decide the extent to which they wish to abandon themselves to the illusion.
<G-vec00106-002-s606><decide.sich_entscheiden><de> Der Besucher kann selbst entscheiden, wie weit er sich der Illusion hingibt.
<G-vec00106-002-s607><decide.sich_entscheiden><en> You can decide which document to upload.
<G-vec00106-002-s607><decide.sich_entscheiden><de> Sie können selbst entscheiden, welches Dokument Sie hochladen.
<G-vec00106-002-s627><decide.sich_entscheiden><en> Even before you decide on a certain treatment, you can reserve your "well-being time frame."
<G-vec00106-002-s627><decide.sich_entscheiden><de> Noch bevor Sie sich für eine bestimmte Behandlung entscheiden, können Sie Ihr "Wohlfühl-Zeitfenster" reservieren.
<G-vec00106-002-s628><decide.sich_entscheiden><en> If you decide to utilize this tablet, it is important to adhere to the advised dosage and weight loss guidelines.
<G-vec00106-002-s628><decide.sich_entscheiden><de> Wenn Sie sich entscheiden, diese Pille zu verwenden, ist es wichtig, die empfohlene Dosierung und Diäten Anweisungen zu folgen.
<G-vec00106-002-s629><decide.sich_entscheiden><en> In order to choose the suitable system of sliding doors for you, you have to decide what models are currently offered in the building products market.
<G-vec00106-002-s629><decide.sich_entscheiden><de> Um das für Sie geeignete System von Schiebetüren auszuwählen, müssen Sie sich entscheiden, welche Modelle derzeit auf dem Markt für Bauprodukte angeboten werden.
<G-vec00106-002-s630><decide.sich_entscheiden><en> Before you decide to trade, you need to make sure that you understand the risks involved, taking into account your investment objectives and level of experience.
<G-vec00106-002-s630><decide.sich_entscheiden><de> Bevor Sie sich für den Handel entscheiden, müssen Sie sicherstellen, dass Sie die damit verbundenen Risiken unter Berücksichtigung Ihrer Anlageziele und des Erfahrungsniveaus verstehen.
<G-vec00106-002-s631><decide.sich_entscheiden><en> For the use of some contents it is necessary to provide us with personal information, for example if you wish to receive a newsletter or if you decide to support us with a donation..
<G-vec00106-002-s631><decide.sich_entscheiden><de> Für die Verwendung einiger Inhalt es ist notwendig, uns persönliche Daten zur Verfügung stellen, beispielsweise um den Newsletter zu abonnieren oder wenn Sie sich entscheiden, uns mit einer Spende zu unterstützen.
<G-vec00106-002-s632><decide.sich_entscheiden><en> If you decide to choose an orange color for your kitchen, you should know that it blends nicely with the dark color scheme.
<G-vec00106-002-s632><decide.sich_entscheiden><de> Wenn Sie sich entscheiden, eine orange Farbe für Ihre Küche zu wählen, sollten Sie wissen, dass es sich gut mit dem dunklen Farbschema verbindet.
<G-vec00106-002-s633><decide.sich_entscheiden><en> Even if deceased persons do not wish to cause any disagreement between the heirs with the will and decide that they shall inherit as provided by law (intestate succession), disputes that have a negative impact on family relations still occur in practice.
<G-vec00106-002-s633><decide.sich_entscheiden><de> Auch wenn verstorbene Personen keine Entzweiung zwischen den Erben mit dem Testament hervorrufen möchten und sich entscheiden, dass sie wie gesetzlich vorgesehen erben sollen (gesetzliche Erbfolge), kommt es in der Praxis immer noch zu Streitigkeiten, die sich negativ auf die Familienbeziehungen auswirken.
<G-vec00106-002-s634><decide.sich_entscheiden><en> In order to achieve a great bonus, you must decide which strategy fits better and go by that one.
<G-vec00106-002-s634><decide.sich_entscheiden><de> Um einen guten Bonus zu erreichen müssen Sie sich entscheiden, welche Strategie besser passt und damit spielen.
<G-vec00106-002-s635><decide.sich_entscheiden><en> Finally, when classifying the data, it should be borne in mind that many academic players in the knowledge market decide – as do many small and medium-sized companies – not to apply for protection of their intellectual property rights because of the high costs involved in patent applications, the issue of patents, and also the enforcement of patent rights.
<G-vec00106-002-s635><decide.sich_entscheiden><de> Schließlich bleibt bei der Einordnung der Daten zu beachten, dass aufgrund der hohen Kosten einer Patentanmeldung, -erteilung und auch Patentrechtsdurchsetzung sich viele akademisch orientierte Wissensakteure ähnlich wie Mittelständler dazu entscheiden, keinen Schutz auf ihre intellektuellen Eigentumsrechte zu beantragen.
<G-vec00106-002-s636><decide.sich_entscheiden><en> In the evening courses you can try the first session of a new group and then decide how you want to move forward.
<G-vec00106-002-s636><decide.sich_entscheiden><de> In den Abendkursen können Sie nach vorheriger Absprache zu einer Probestunde in einen Standard-Gruppenkurs kommen und sich danach entscheiden, wie Sie weitermachen wollen.
<G-vec00106-002-s637><decide.sich_entscheiden><en> If you decide to do the Camino de Santiago by bike, the Portuguese route that runs along the coast can be completed in just 5 days. Or even less.
<G-vec00106-002-s637><decide.sich_entscheiden><de> Wenn Sie sich entscheiden, den Jakobsweg mit dem Fahrrad zu fahren, können Sie den portugiesischen Weg, der entlang der Küste verläuft, in nur 5 Tagen absolvieren, oder sogar weniger.
<G-vec00106-002-s638><decide.sich_entscheiden><en> In your installation, you need to decide whether to install the configuration file at c:\usr\local\ssl\openssl.cnf or whether to install it someplace else and use environmental variables (possibly on a per-virtual-host basis) to locate the configuration file.
<G-vec00106-002-s638><decide.sich_entscheiden><de> Damit diese Datei gefunden wird, müsssen Sie sich bei der Installation entscheiden, entweder die Konfigurationsdatei unter c:\usr\local\ssl\openssl.cnf anzulegen, oder diese Datei an einem anderen Ort abzulegen und Umgebungsvariablen zu benutzen (möglicherweise auf Basis verschiedener Virtual-Host Konfigurationen).
<G-vec00106-002-s639><decide.sich_entscheiden><en> Also you can decide for a certain topic, e.g.
<G-vec00106-002-s639><decide.sich_entscheiden><de> Auch können Sie sich für eine bestimmte Thematik entscheiden, z.
<G-vec00106-002-s640><decide.sich_entscheiden><en> In the event of an emergency, if the owner does not object, the examining magistrate may decide within 14 days to release the animal for sale.
<G-vec00106-002-s640><decide.sich_entscheiden><de> Handelt es sich um einen Notfall, kann der Untersuchungsrichter, falls der Besitzer keine Einwände erhebt, innerhalb einer Frist von 14 Tagen entscheiden, das Tier zum Verkauf freizugeben.
<G-vec00106-002-s641><decide.sich_entscheiden><en> Here is a list of foods that should be excluded from the diet, if you decide that the salt-free diet is right for you: spices, bananas, jam, flour, cereals, grapes, pasta, sugar, salted, smoked, sour and spicy food, watermelons, lamb, fried foods, pork, confectionery and meat broths.
<G-vec00106-002-s641><decide.sich_entscheiden><de> Hier ist eine Liste von Lebensmitteln, die aus der Ernährung ausgeschlossen werden sollen, wenn Sie sich entscheiden, dass die salzfreie Diät ist die richtige für Sie: Gewürze, Bananen, Marmelade, Mehl, Getreide, Trauben, Teigwaren, Zucker, gepökelt, geräuchert, sauer und scharfes Essen, Wassermelonen, Lamm, gebratene Lebensmittel, Schweinefleisch, Süßwaren und Fleischbrühe.
<G-vec00106-002-s642><decide.sich_entscheiden><en> We want that every time you decide to go to a hotel, you do it with a smile and with the of satisfaction knowing that you have only paid for the time you will spend at the hotel.
<G-vec00106-002-s642><decide.sich_entscheiden><de> Wir möchten, dass Sie jedes Mal, wenn Sie sich entscheiden, ein Hotel zu buchen, dies mit einem zufriedenen Lächeln tun, weil Sie wissen, dass Sie nur die Stunden zahlen, die Sie auch wirklich dort verbringen werden.
<G-vec00106-002-s643><decide.sich_entscheiden><en> If you decide on a VISA course, you have various options which make your stay in Germany possible.
<G-vec00106-002-s643><decide.sich_entscheiden><de> Wenn Sie sich für einen VISA-Kurs entscheiden, haben Sie verschiedene Möglichkeiten Ihren Aufenthalt in Deutschland zu gestalten.
<G-vec00106-002-s644><decide.sich_entscheiden><en> As an HR manager, you must decide which method you want to use to get to know and test the candidates for the position for which you are responsible.
<G-vec00106-002-s644><decide.sich_entscheiden><de> Als Personaler müssen Sie sich entscheiden, mit welcher Methode Sie die Kandidaten für die von Ihnen verantwortete Stelle kennenlernen und testen möchten.
<G-vec00106-002-s645><decide.sich_entscheiden><en> Oyunu A kind of daughter can not decide what to wear.
<G-vec00106-002-s645><decide.sich_entscheiden><de> Oyunu Eine Art Tochter kann sich nicht entscheiden, was zu tragen.
<G-vec00106-002-s665><decide.sich_entscheiden><en> There is no immediate danger concerning getting into trouble, but it is better safe than sorry, just in case the German authorities decide to change their mind later.
<G-vec00106-002-s665><decide.sich_entscheiden><de> Es gibt keine unmittelbare Gefahr, in Schwierigkeiten zu geraten, aber es ist besser sicher als leid, nur für den Fall, dass die deutschen Behörden sich entschließen, später ihre Meinung zu ändern.
<G-vec00106-002-s666><decide.sich_entscheiden><en> There are circumstances where ACCO Brands may decide to buy, sell or reorganise business in selected countries.
<G-vec00106-002-s666><decide.sich_entscheiden><de> Unter bestimmten Umständen kann ACCO Brands sich entschließen, Unternehmungen in ausgewählten Ländern zu kaufen, zu verkaufen oder neu zu strukturieren.
<G-vec00106-002-s667><decide.sich_entscheiden><en> In keeping with the various meanings of the Latin verb constituo, the term ‘constituent’ power moves in a semantic field of ‘situate’‘together’, ‘set’, ‘settle’, but also ‘decide’, ‘create’, ‘determine’.
<G-vec00106-002-s667><decide.sich_entscheiden><de> Der Begriff ‚konstituierende’ Macht bewegt sich gemäß der verschiedenen Bedeutungen des lateinischen Verbs constituo in einem Bedeutungsfeld von ‚zusammen’ ‚setzen’, von ‚hinsetzen’, ‚siedeln’, aber auch ‚sich entschließen’, ‚schaffen’, ‚festsetzen’.
<G-vec00106-002-s668><decide.sich_entscheiden><en> If they decide to become involved in the world system they lose their testimony.
<G-vec00106-002-s668><decide.sich_entscheiden><de> Wenn sie sich entschließen, in das Weltsystem verwickelt zu werden, verlieren sie ihr Zeugnis.
<G-vec00106-002-s669><decide.sich_entscheiden><en> You don’t have to start from the scratch anymore and you can save a lot of time and money if you decide to use our expert knowledge for your projects.
<G-vec00106-002-s669><decide.sich_entscheiden><de> Sie müssen nicht mehr von Grund auf anfangen und Sie können viel Zeit und Geld sparen, wenn Sie sich entschließen, unser Fachwissen für Ihre Projekte zu nutzen.
<G-vec00106-002-s670><decide.sich_entscheiden><en> If, however, you decide to seek professional help, we recommend that you do not contact the civilian brigades - in which case they are practically impossible to file claims.
<G-vec00106-002-s670><decide.sich_entscheiden><de> Wenn Sie sich jedoch entschließen, professionelle Hilfe in Anspruch zu nehmen, empfehlen wir Ihnen, sich nicht an die zivile Brigade zu wenden - in diesem Fall ist es praktisch unmöglich, Ansprüche geltend zu machen.
<G-vec00106-002-s671><decide.sich_entscheiden><en> If You decide to access other web sites, You do so at Your own risk.
<G-vec00106-002-s671><decide.sich_entscheiden><de> Wenn Sie sich entschließen, andere Websites aufzurufen, tun Sie dies auf eigenes Risiko.
<G-vec00106-002-s672><decide.sich_entscheiden><en> If you decide to cancel your order before receiving your package, do not accept delivery of the package.
<G-vec00106-002-s672><decide.sich_entscheiden><de> Wenn Sie sich entschließen, Ihre Bestellung vor dem Erhalt Ihres Pakets zu stornieren, akzeptieren Sie die Lieferung des Pakets nicht.
<G-vec00106-002-s673><decide.sich_entscheiden><en> You may decide to cap your remaining quantities and obtain a fixed price in the course of supply.
<G-vec00106-002-s673><decide.sich_entscheiden><de> Sie können sich während der Belieferung entschließen, Ihre Restmengen zu schließen und so einen Fixpreis zu erhalten.
<G-vec00106-002-s674><decide.sich_entscheiden><en> If you decide to replace or supplement, this data can be taken over.
<G-vec00106-002-s674><decide.sich_entscheiden><de> Falls Sie sich zu einer Ablösung oder Ergänzung entschließen, können diese Daten übernommen werden.
<G-vec00106-002-s675><decide.sich_entscheiden><en> This audio drama[2] takes place during and after their adventures in the Digital World. The children find a mailbox and decide to write letters to the people they care about, expressing things that they normally cannot say.
<G-vec00106-002-s675><decide.sich_entscheiden><de> Dieses spielt in der zweiten Hälfte der Serie und handelt von den Kindern, die in der Digiwelt ein Mailbox-ähnliches Gerät finden und sich entschließen Briefe an die Menschen zu schreiben, die ihnen sehr nahe liegen.
<G-vec00106-002-s676><decide.sich_entscheiden><en> Alleged witches could decide to neutralize the occult harm by taking the bewitched to a hospital in the hope that a successful treatment would make the allegation go away.
<G-vec00106-002-s676><decide.sich_entscheiden><de> Mutmaßliche Hexen konnten sich entschließen, den okkulten Schaden zu beseitigen, indem sie die verzauberte Person in ein Krankenhaus brachten – in der Hoffnung, dass eine erfolgreiche Behandlung zur Aufhebung der Beschuldigung führte.
<G-vec00106-002-s677><decide.sich_entscheiden><en> Whenever our Clients decide to provide us personal data, we will ask them to inform the data subjects about the purpose and means of processing it.
<G-vec00106-002-s677><decide.sich_entscheiden><de> Wenn sich unsere Kunden entschließen, uns personenbezogene Daten zu übermitteln, werden wir sie bitten, die Betroffenen über den Zweck und die Form der Verarbeitung ihrer Daten zu informieren.
<G-vec00106-002-s678><decide.sich_entscheiden><en> In case you would decide to cancel or edit your order, you can easily do it on our website within the first 30 minutes after placing your order.
<G-vec00106-002-s678><decide.sich_entscheiden><de> STORNIERUNG ODER BEARBEITUNG EINER BESTELLUNG Sollten Sie sich entschließen, Ihre Bestellung zu stornieren oder zu bearbeiten, können Sie dies innerhalb von 30 Minuten nach Ihrer Bestellung auf unserer Webseite durchführen.
<G-vec00106-002-s679><decide.sich_entscheiden><en> Preserving the Ukrainian and Syrian conflicts as proxy wars will continue to deliver significant foreign policy gains for Moscow, as long as the US and the EU do not decide to make costly investments in Ukrainian sovereignty and the political development of Syria’s Sunni opposition.
<G-vec00106-002-s679><decide.sich_entscheiden><de> Eine Konservierung der Konflikte in Syrien und der Ukraine als Stellvertreterkriege wird Moskau beträchtliche außenpolitischen Gewinn einbringen, solang die Vereinigten Staaten und die EU sich nicht entschließen, kostspielige Investitionen in die Souveränität der Ukraine und die politische Entwicklung der sunnitischen Opposition in Syrien zu tätigen.
<G-vec00106-002-s680><decide.sich_entscheiden><en> Even if you decide to travel last-minute and you are looking for a cheap accommodation a rental in Middle East, you will find the accommodation you are looking for on Likibu.
<G-vec00106-002-s680><decide.sich_entscheiden><de> Selbst wenn Sie sich entschließen, Last-Minute zu reisen, oder wenn Sie eine preisgünstige Ferienunterkunft in Mittelamerika und Karibik suchen, hier werden Sie garantiert fündig.
<G-vec00106-002-s681><decide.sich_entscheiden><en> We would be very happy if you could decide to support our work by becoming a member of the Schumann House Society.
<G-vec00106-002-s681><decide.sich_entscheiden><de> Wir würden uns freuen, wenn Sie sich entschließen könnten, unsere Arbeit durch Mitgliedschaft im Verein Schumannhaus zu unterstützen.
<G-vec00106-002-s682><decide.sich_entscheiden><en> If you then decide that you want to use collaborative law to try to resolve issues, you will have to ensure that your partner has also instructed or will instruct a collaborative lawyer.
<G-vec00106-002-s682><decide.sich_entscheiden><de> Wenn Sie sich dann zu dem Modell des Collaborative Law entschließen, um zu versuchen, eine Lösung zu finden, müssen Sie sicherstellen, dass Ihr Partner auch einen Anwalt hat, der im Collaborative Law geschult ist, oder so einen Anwalt mandatieren wird.
<G-vec00106-002-s683><decide.sich_entscheiden><en> If you decide to disable the cookies we use, this may affect the user experience while is on one of our Sites.
<G-vec00106-002-s683><decide.sich_entscheiden><de> Wenn Sie sich entschließen, die von uns verwendeten Cookies zu deaktivieren, kann sich dies auf die Benutzererfahrung auf einer unserer Websites auswirken.
<G-vec00106-002-s760><decide.sich_entscheiden><en> Of course a baby can’t decide what color it wants for its clothes and surroundings.
<G-vec00106-002-s760><decide.sich_entscheiden><de> Ein Baby kann ja nicht über die Farbe seiner Kleidung und Umgebung entscheiden.
<G-vec00106-002-s761><decide.sich_entscheiden><en> America is not a place where chance of birth or circumstance should decide our destiny.
<G-vec00106-002-s761><decide.sich_entscheiden><de> Die Vereinigten Staaten sind kein Land, in dem die Herkunft oder die Umstände über das Schicksal entscheiden sollten.
<G-vec00106-002-s762><decide.sich_entscheiden><en> You can set your browser so that you are informed about the setting of cookies and individually decide whether to accept or refuse cookies in specific cases or in general.
<G-vec00106-002-s762><decide.sich_entscheiden><de> Sie können Ihren Browser so einstellen, dass Sie über das Setzen von Cookies informiert werden und einzeln über deren Annahme entscheiden oder die Annahme von Cookies für bestimmte Fälle oder generell ausschließen.
<G-vec00106-002-s763><decide.sich_entscheiden><en> In the next few months, the European Commission will be assessing the impact of the Roaming Regulation and, depending on developments in the market, will decide whether the Regulation should be extended in time and scope to cover SMS and MMS messaging and the transfer of data.
<G-vec00106-002-s763><decide.sich_entscheiden><de> Die Kommission wird die Wirksamkeit der Roamingverordnung in den kommenden Monaten bewerten und auf der Grundlage der Marktentwicklungen über eine Verlängerung des Geltungszeitraums und eine Ausweitung des Anwendungsbereichs auf SMS, MMS und Datenübertragungen entscheiden.
<G-vec00106-002-s764><decide.sich_entscheiden><en> But it is September and October sunshine and rainfall which decide of the vintage quality.
<G-vec00106-002-s764><decide.sich_entscheiden><de> Es sind jedoch die Sonneneinstrahlung und die Niederschlagsmengen in den Monaten September & Oktober, die über die Qualität des Jahrgangs entscheiden.
<G-vec00106-002-s765><decide.sich_entscheiden><en> These are the ones who decide success in the overall picture.
<G-vec00106-002-s765><decide.sich_entscheiden><de> Diese sind es, die im Gesamtbild über den Erfolg entscheiden.
<G-vec00106-002-s766><decide.sich_entscheiden><en> In order to enable the Commission to decide whether sampling is necessary, and if so, to select a sample, all exporting producers, or representatives acting on their behalf, are hereby requested to make themselves known to the Commission.
<G-vec00106-002-s766><decide.sich_entscheiden><de> Damit die Kommission über die Notwendigkeit eines Stichprobenverfahrens entscheiden und gegebenenfalls eine Stichprobe bilden kann, werden alle ausführenden Hersteller oder die in ihrem Namen handelnden Vertreter hiermit gebeten, der Kommission binnen 7 Tagen nach Veröffentlichung dieser Bekanntmachung die in Anhang I erbetenen Angaben zu ihren Unternehmen vorzulegen.
<G-vec00106-002-s767><decide.sich_entscheiden><en> In the end, I’m committed to the idea that five hundred million people should decide the future of Europe. Not twenty-eight people.
<G-vec00106-002-s767><decide.sich_entscheiden><de> Letztendlich bin ich überzeugt, dass 500 Millionen Menschen über die Zukunft Europas entscheiden sollten, und nicht bloß achtundzwanzig Personen.
<G-vec00106-002-s768><decide.sich_entscheiden><en> An example of such Flickr Managing Cookies Notwithstanding the foregoing, Users can set up their browser to accept or reject all cookies by default or receive an on-screen notification when receiving each cookie and decide there and then whether to allow it access to their hard drive.
<G-vec00106-002-s768><decide.sich_entscheiden><de> Unbeschadet der obigen Erläuterungen hat der Benutzer die Möglichkeit, seinen Browser so zu konfigurieren, dass alle Cookies standardmäßig akzeptiert oder abgelehnt werden, oder um eine Meldung auf dem Bildschirm bei Erhalt eines Cookies anzuzeigen und in diesem Moment über seine Speicherung auf der Festplatte zu entscheiden.
<G-vec00106-002-s770><decide.sich_entscheiden><en> To be on the safe side the regents wanted to let the crown council decide the question of the European astronomy.
<G-vec00106-002-s770><decide.sich_entscheiden><de> Die Regenten suchten sich zu sichern, indem sie den Kronrat über die Frage der europäischen Astronomie entscheiden lassen wollten.
<G-vec00106-002-s771><decide.sich_entscheiden><en> In the larger factories of all important industrial centres the establishment of workers’ committees has, as if by itself, taken place, with which alone the employer negotiates and which decide all disputes.
<G-vec00106-002-s771><decide.sich_entscheiden><de> In den größten Fabriken aller wichtigsten Industriezentren hat sich wie von selbst die Einrichtung der Arbeiterausschüsse gebildet, mit denen allein der Unternehmer verhandelt, die über alle Konflikte entscheiden.
<G-vec00106-002-s772><decide.sich_entscheiden><en> The Sailor War will decide the destiny of the galaxie.
<G-vec00106-002-s772><decide.sich_entscheiden><de> In der Zukunft wird der Krieg der Sailor Senshi über das Schicksal der Galaxie entscheiden.
<G-vec00106-002-s773><decide.sich_entscheiden><en> As the EU decides whether to expand its special trade relationship with Israel, as Obama and the US Congress set next year's budget for Israeli military aid, and as neighbours like Turkey and Egypt decide their next diplomatic steps -- let's make the world's voice unignorable: it's time for truth and accountability on the flotilla raid, and it's time for Israel to comply with international law and end the siege of Gaza.
<G-vec00106-002-s773><decide.sich_entscheiden><de> Während die EU beschliesst, ob sie ihre besonderen Handelsbeziehungen mit Israel erweitert, Obama und der US-Kongress über die Ausgaben für die israelische Militärhilfe im kommenden Jahr beraten und Nachbarstaaten wie die Türkei und Ägypten über ihre nächsten diplomatischen Schritte entscheiden - Lasst uns die Stimme der Weltöffentlichkeit unüberhörbar machen: Es ist Zeit die Wahrheit über den Angriff zu erfahren, Rechenschaft zu verlangen und es ist höchste Zeit, dass Israel das Völkerrecht respektiert und die Blockade des Gaza-Streifens beendet.
<G-vec00106-002-s774><decide.sich_entscheiden><en> But in all these cases, the terrible truth is that it is the strong who decide the fate of the weak; human beings therefore become instruments in the hands of other human beings.
<G-vec00106-002-s774><decide.sich_entscheiden><de> Aber in all diesen Fällen sieht die nackte Wahrheit so aus, dass die Starken über das Schicksal der Schwachen entscheiden; die Menschen werden somit zu Werkzeugen in den Händen anderer Menschen.
<G-vec00106-002-s775><decide.sich_entscheiden><en> If you intend to decide on the transfer option after receiving your letter of admission, please inform Mr. Rademacher when submitting your application.
<G-vec00106-002-s775><decide.sich_entscheiden><de> Möchten Sie über Ihre Wechselabsichten erst nach Erhalt der Zulassung entscheiden, informieren Sie bitte Herrn Rademacher bei Abgabe der Bewerbung.
<G-vec00106-002-s776><decide.sich_entscheiden><en> You and your companions may very well decide the fate of the world.
<G-vec00106-002-s776><decide.sich_entscheiden><de> Dabei könnten sie durchaus über das Schicksal der Welt entscheiden.
<G-vec00106-002-s777><decide.sich_entscheiden><en> Moreover, these units must be authorised to decide how funds are to be spent with regard to their tasks.
<G-vec00106-002-s777><decide.sich_entscheiden><de> Außerdem müssen sie die Befugnis besitzen, mit Blick auf ihre Aufgaben über die Mittelverwendung zu entscheiden.
<G-vec00106-002-s778><decide.sich_entscheiden><en> It is the workers who decide the matters at issue and carry their decisions out through the shop committees.
<G-vec00106-002-s778><decide.sich_entscheiden><de> Es sind die Arbeiter, die über strittige Fragen entscheiden und ihre Entscheidungen durch den Werksausschuß ausführen.
