<G-vec00001-001-s032><assemble.assemblieren><en> Our strategy was to select the best one from various providers and to then assemble it.
<G-vec00001-001-s032><assemble.assemblieren><de> Unsere Strategie war, von verschiedensten Anbietern das Beste zu wählen und das dann zu assemblieren.
<G-vec00001-001-s033><assemble.assemblieren><en> Specialists from Starline assemble the respective model variants according to customer requirements with the corresponding components: Additional processors, memory, RAID controllers, interface cards and, if necessary, NVMe SSDs are reassembled for each individual system.
<G-vec00001-001-s033><assemble.assemblieren><de> Spezialisten von Starline assemblieren die jeweiligen Modellvarianten nach Kundenanforderung mit den entsprechenden Zusatzkomponenten: Zusätzliche Prozessoren, Speicher, RAID-Controller, Interface-Karten und gegebenenfalls NVMe-SSDs werden stets neu für den jeweiligen Auftrag zusammengestellt.
<G-vec00001-001-s034><assemble.assemblieren><en> Its almost tool-free setup makes it quick and easy to assemble.
<G-vec00001-001-s034><assemble.assemblieren><de> Durch sein nahezu werkzeugloses Setup lässt er sich schnell und einfach assemblieren.
<G-vec00001-001-s035><assemble.assemblieren><en> Our state-of-the-art machinery enables us to manufacture and assemble cutting-edge technology electronic assemblies and to fully assemble devices.
<G-vec00001-001-s035><assemble.assemblieren><de> Mit unserem modernen Maschinenpark sind wir in der Lage elektronische Baugruppen neuester Technologie zu fertigen, zu assemblieren und Geräte komplett zu montieren.
<G-vec00001-001-s049><assemble.aufbauen><en> When I arrived at the park I had to first familiarize myself with the tripod and assemble it quickly.
<G-vec00001-001-s049><assemble.aufbauen><de> Im Park angekommen musste ich zunächst das Stativ kennenlernen und es schnell aufbauen.
<G-vec00001-001-s050><assemble.aufbauen><en> The trainer has a simplified mounting system, which makes it easy and quick to assemble.
<G-vec00001-001-s050><assemble.aufbauen><de> Mit seinem vereinfachten Montagesystem lässt sich der Trainer leicht und schnell aufbauen.
<G-vec00001-001-s051><assemble.aufbauen><en> If you do not want to assemble your bike box yourself, you can also book the installation directly via our online shop.
<G-vec00001-001-s051><assemble.aufbauen><de> Wenn Sie Ihre Fahrradbox nicht selbst aufbauen möchten, können Sie die Montage über unseren Online Shop auch direkt mitbuchen.
<G-vec00001-001-s052><assemble.aufbauen><en> The concept kitchen is the very opposite of a fitted kitchen, being easy to assemble, easy to dismantle and extremely straightforward to adjust.
<G-vec00001-001-s052><assemble.aufbauen><de> Höchste Design-Ansprüche Die Concept Kitchen ist das Gegenteil von einer Einbauküche: Sie lässt sich leicht aufbauen, leicht abbauen und vollkommen unkompliziert verstellen.
<G-vec00001-001-s053><assemble.aufbauen><en> He must assemble his tent up in less than twenty seconds to avoid freezing.
<G-vec00001-001-s053><assemble.aufbauen><de> Um nicht zu erfrieren, muss er sein Zelt in weniger als 20 Sekunden aufbauen.
<G-vec00001-001-s054><assemble.aufbauen><en> This user-friendly system is quick and easy to assemble.
<G-vec00001-001-s054><assemble.aufbauen><de> Das benutzerfreundliche System lässt sich schnell und problemlos aufbauen.
<G-vec00001-001-s055><assemble.aufbauen><en> Choose – assemble – start.
<G-vec00001-001-s055><assemble.aufbauen><de> Auswählen – aufbauen – starten.
<G-vec00001-001-s056><assemble.aufbauen><en> While the nephews assemble the tent Donald would like to be one with nature.
<G-vec00001-001-s056><assemble.aufbauen><de> Während die Neffen das Zelt aufbauen, möchte Donald liebend gerne eins sein mit der Natur.
<G-vec00001-001-s057><assemble.aufbauen><en> But Tribal Wars 2 is so much more than just a simple strategy city building game – you also have to assemble an army by recruiting and training soldiers, such as axemen or spear fighters.
<G-vec00001-001-s057><assemble.aufbauen><de> Doch Tribal Wars 2 ist viel mehr als nur ein simples Strategie-Stadtbau-Spiel - du musst außerdem eine Armee aufbauen, indem du Soldaten rekrutierst und beispielsweise zu Axt- oder Speerkämpfern ausbildest.
<G-vec00001-001-s061><assemble.aufbauen><en> it is quick to assemble and easy to move.
<G-vec00001-001-s061><assemble.aufbauen><de> es ist schnell aufzubauen und zu bewegen.
<G-vec00001-001-s062><assemble.aufbauen><en> The Chimney Scaffold is safe to assemble and suitable for roofs with an angle of 30-45 degrees.
<G-vec00001-001-s062><assemble.aufbauen><de> Das Kamingerüst ist sicher aufzubauen und für Dächer mit einer Neigung von 30 bis 45 Grad geeignet.
<G-vec00001-001-s063><assemble.aufbauen><en> In order to assemble a three-phase energy supply, three inverters are connected to the DC bus.
<G-vec00001-001-s063><assemble.aufbauen><de> Um eine dreiphasige Energieversorgung aufzubauen, werden drei Wechselrichter an den DC-Bus angeschlossen.
<G-vec00001-001-s064><assemble.aufbauen><en> This Linkstar octagonal softbox (octabox) is easy to assemble and with the bayonet connector, the speed ring, it can be mounted on the flash unit.
<G-vec00001-001-s064><assemble.aufbauen><de> Benachrichtigen, wenn verfügbar Diese Linkstar Softbox (Octobox) ist einfach aufzubauen und lässt sich durch den Bajonettanschluss des Halters, den Speedring, leicht am Studioblitz anbringen.
<G-vec00001-001-s065><assemble.aufbauen><en> Thanks to its innovative technique, it is easy to assemble in a few steps.
<G-vec00001-001-s065><assemble.aufbauen><de> Sie sind dank ihrer innovativen Technik mit wenigen Handgriffen einfach aufzubauen.
<G-vec00001-001-s066><assemble.aufbauen><en> If fixing points are missing in the garden, it is the optimal solution to assemble the Slackline quickly and easily.
<G-vec00001-001-s066><assemble.aufbauen><de> Bei fehlenden Fixpunkten im Garten ist sie die optimale Lösung um eine Slackline schnell und unkompliziert aufzubauen.
<G-vec00001-001-s067><assemble.aufbauen><en> "But because ""Jessica"" was able to finish her job at Limmo Peninsula faster than planned, there is now enough space to lower and assemble all of ""Ellie"" through the auxiliary shaft."
<G-vec00001-001-s067><assemble.aufbauen><de> "Weil aber ""Jessica"" ihren Job auf der Limmo Peninsula schneller erledigen konnte als geplant, ist jetzt genug Platz, ""Ellie"" komplett über den Hilfsschacht abzulassen und aufzubauen."
<G-vec00001-001-s068><assemble.aufbauen><en> """A high-quality PA column speaker... easy to transport, quick to assemble and easy to use.... even smaller concerts can be realised with this system."""
<G-vec00001-001-s068><assemble.aufbauen><de> """Eine hochwertige PA-Säule... gut zu transportieren, schnell aufzubauen und einfach zu bedienen.... auch kleinere Konzerte können mit diesem System problemlos realisiert werden."
<G-vec00443-001-s048><assemble.aufbauen><en> The Chimney Scaffold is safe to assemble and suitable for roofs with an angle of 30-45 degrees.
<G-vec00443-001-s048><assemble.aufbauen><de> Das Kamingerüst ist sicher aufzubauen und für Dächer mit einer Neigung von 30 bis 45 Grad geeignet.
<G-vec00443-001-s052><assemble.aufbauen><en> If fixing points are missing in the garden, it is the optimal solution to assemble the Slackline quickly and easily.
<G-vec00443-001-s052><assemble.aufbauen><de> Bei fehlenden Fixpunkten im Garten ist sie die optimale Lösung um eine Slackline schnell und unkompliziert aufzubauen.
<G-vec00001-001-s069><assemble.bauen><en> Information Format 230x230x100 / 160x160x100 / 160x300x100mm, This set is easy to assemble.
<G-vec00001-001-s069><assemble.bauen><de> Informationen Format 230x230x100 / 160x160x100 / 160x300x100mm, Dieses Set ist einfach zusammen zu bauen.
<G-vec00001-001-s070><assemble.bauen><en> RP-T2/S is delivered as a complete set, you can assemble four working width of the rotary hoe - 16, 22, 32 and 38 cm, which is in fact width of the cover.
<G-vec00001-001-s070><assemble.bauen><de> Wir liefern die Rotationshacke als ein kompletter Satz, aus dem man vier Arbeitsbreiten der Hacke bauen kann - 16, 22, 32 und 38 cm; es geht eigentlich um die Breite der Abdeckung.
<G-vec00001-001-s071><assemble.bauen><en> The ideal self assembly solution for your production: WEINMANN provides the technology - you assemble the table (VarioTec).
<G-vec00001-001-s071><assemble.bauen><de> Die geniale Selbstbaulösung für Ihren Montagetisch: WEINMANN liefert die Technik, Sie bauen den Tisch (VarioTec).
<G-vec00001-001-s074><assemble.bauen><en> Kuala Lumpur - DRB-HICOM Bhd (1619)and Volkswagen AG, the largest carmaker in Europe, will collectively invest close to RM1 billion over the next five to six years mainly to set up the infrastructure to assemble VW vehicles in Malaysia.
<G-vec00001-001-s074><assemble.bauen><de> Kuala Lumpur - DRB-HICOM Berhad und die Volkswagen AG, Europas größter Autobauer, werden gemeinsam 1 Milliarde Ringgit (etwa 250 MIllionen Euro) in den nächsten sechs Jahren investieren, um künftig VW Autos in Malaysia zu bauen.
<G-vec00001-001-s075><assemble.bauen><en> 'We now have a new set of building blocks that we can use to assemble many different new quasicrystalline structures.
<G-vec00001-001-s075><assemble.bauen><de> 'Wir besitzen nun ein neues Set an Bausteinen, aus denen wir viele verschiedene neue quasikristalline Strukturen bauen können', erklären die TUM Physiker.
<G-vec00001-001-s076><assemble.bauen><en> Guncrafter - it's a great designer for Android, which will appeal to all fans of Minecraft, as well as those who love to invent and assemble their own products.
<G-vec00001-001-s076><assemble.bauen><de> Guncrafter - es ist ein großer Designer für Android, die allen Fans von Minecraft ansprechen wird, sowie diejenigen, die zu erfinden und bauen ihre eigenen Produkte lieben.
<G-vec00001-001-s077><assemble.bauen><en> Become a ninja and learn the new tricks of Spinjitzu with the set Nya - Master of Spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s077><assemble.bauen><de> Werde zum ninja und lernt neue tricks des Spinjitzu-set Nya - Meister des Spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s078><assemble.bauen><en> Become a ninja and learn the new tricks of Spinjitzu set, jay-master of spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s078><assemble.bauen><de> Werde zum ninja und lernt neue tricks des Spinjitzu mit dem satz von zane-meister des spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s079><assemble.bauen><en> Now the enterprise will assemble 30 cars every hour, whereas previously this figure was around 25-27 cars per hour.
<G-vec00001-001-s079><assemble.bauen><de> Das Unternehmen wird jede Stunde 30 Autos bauen, früher waren es 25 bis 27 Autos pro Stunde.
<G-vec00001-001-s080><assemble.bauen><en> Bring your technical Spinjitzu on another level with the set of Kai - a Master of Spinjitzu, spinners Spinjitzu with handle lego bricks to assemble, the element at the top with the capsule for minifigures and launcher.
<G-vec00001-001-s080><assemble.bauen><de> Bringen sie ihre technik Spinjitzu auf einer anderen ebene mit dem set von Kai - Meister des Spinjitzu, mit Spinjitzu spinner mit griff aus lego-steinen bauen, element kreisel mit kapsel für minifigur und krug.
<G-vec00001-001-s081><assemble.bauen><en> """I design complete cars, featuring tight tolerances, from scratch by myself, and we assemble the cars with a team of four,"" Palatov says."
<G-vec00001-001-s081><assemble.bauen><de> """Ich konstruiere komplette Fahrzeuge mit geringen Toleranzen von Grund auf selbst und wir bauen die Fahrzeuge mit einem vierköpfigen Team zusammen"", sagt Palatov."
<G-vec00001-001-s082><assemble.bauen><en> The set also contains the cars of the Scorpion with pincers and a tail mobile, more an alley with a wall with window opening, ramp, dual-link, large spider web, thread of spider's web, is flexible and a catapult to assemble.
<G-vec00001-001-s082><assemble.bauen><de> Das set enthält auch das auto des Skorpions mit zangen und schwanz möbel, mehr eine gasse mit einer mauer mit fenster und schiebedach, rampe mit doppeltem anschluss, großes spinnennetz aus draht, spinnennetz, flexibel und ein katapult bauen.
<G-vec00001-001-s083><assemble.bauen><en> Nevertheless, like bricks that can be used to assemble many different structures, the tubulin subunits in the cell's microtubules are identical to one another.
<G-vec00001-001-s083><assemble.bauen><de> Dennoch, wie Ziegelsteine gebraucht werden können, um viele unterschiedliche Strukturen zu bauen, sind die Tubulin-Untergruppen in den Mikrotubuli der Zellen untereinander identisch.
<G-vec00001-001-s084><assemble.bauen><en> Assemble a team of 4 people to kill bosses or Bounce from enemy waves in survival mode.
<G-vec00001-001-s084><assemble.bauen><de> Bauen Sie ein Team von 4 Personen Bosse zu töten oder von feindlichen Wellen im Survival-Modus Bounce.
<G-vec00001-001-s085><assemble.bauen><en> Assemble the small pieces of glass into a lead frame with grooves and then weld the large pieces of the frame together with a lipid coat on the glass surface to prevent the weathering and fixing.
<G-vec00001-001-s085><assemble.bauen><de> Bauen Sie die kleinen Stücke von Glas in einen Leiterrahmen mit Rillen und dann verschweißen die großen Stücke des Rahmens zusammen mit einer Lipidschicht auf der Glasoberfläche die Verwitterung zu verhindern, und Befestigungs.
<G-vec00001-001-s086><assemble.bauen><en> Assemble a team of heroes invincible in the game Ninja Turtles: Legends and go to the rescue of the Ninja Turtles.
<G-vec00001-001-s086><assemble.bauen><de> Bauen Sie ein Team von Helden unbesiegbar im Spiel Ninja Turtles: Legends und gehen auf die Rettung der Ninja Turtles.
<G-vec00001-001-s087><assemble.bauen><en> Version D is supplied in three parts: l Transducer l Transducer cable l electronics for wall mounting Assemble the version as follows: 1 Loosen the hexagon nut (3) on the transducer cable 2 Insert the transducer tube from below into the mounting opening G 1A 3 Fasten (SW 46) the hexagon nut (3) 4 Remove the plug from below out of the connection head and plug it into the socket of the transducer tube
<G-vec00001-001-s087><assemble.bauen><de> Die Ausführung D wird in drei Teilen geliefert: l Schallwandler l Schallwandlerkabel l Elektronik für Wandmontage Bauen Sie diese Ausführung folgendermaßen zusammen: 1 Sechskantmutter (3) am Schallwandlerrohr lösen 2 Schallwandlerrohr von unten in die Montageöffnung G1 A ein-schieben 3 Sechskantmutter (3) festschrauben (SW 46) 4 Stecker aus Anschlusskopf unten herausziehen und in die Buchse des Schallwandlerrohrs stecken 5 Anschlusskopf auf das Schallwandlerrohr aufstecken.
<G-vec00001-001-s088><assemble.bauen><en> Assemble this wind turbine and learn about sustainable design.
<G-vec00001-001-s088><assemble.bauen><de> Bauen Sie diese Windturbine und erfahren Sie mehr über nachhaltige Konstruktionen.
<G-vec00001-001-s089><assemble.bauen><en> Assemble a team of heroes and move them along a grid-based path in order to complete each mission.
<G-vec00001-001-s089><assemble.bauen><de> Bauen Sie ein Team von Helden und verschieben Sie sie entlang einer Grid-basierten Weg, um jede Mission erfolgreich abzuschließen.
<G-vec00001-001-s090><assemble.bauen><en> Assemble your own..
<G-vec00001-001-s090><assemble.bauen><de> Bauen Sie Ihr eigenes ..
<G-vec00001-001-s091><assemble.bauen><en> Thrush Treatment - Assemble a jigsaw puzzle with an image of a Dog.
<G-vec00001-001-s091><assemble.bauen><de> Thrush Treatment - Bauen Sie ein Puzzle mit einem Bild von einem Hund.
<G-vec00001-001-s092><assemble.zusammenbauen><en> 8, easy assemble, move, put it away, it is suitable for different occasions.
<G-vec00001-001-s092><assemble.zusammenbauen><de> 8, einfach bauen zusammen, bewegen sich, weg gesetzt ihm, es ist passend für verschiedene Gelegenheiten.
<G-vec00001-001-s093><assemble.zusammenbauen><en> John Deere Service Advisor 4.0 CF (Construction and Forestry)software support dealer technical assistance, diagnostics, connection readings, calibrations, interactive tests, specification, tools, assemble and disassemble presented all models John Deere Construction Equipment and some models Hitachi, Euclid, Bell and Timberjack.
<G-vec00001-001-s093><assemble.zusammenbauen><de> John- Deereservice-Berater 4,0 des Software- Supporthändlers CF (Bau und Forstwirtschaft) technische Unterstützung, Diagnosen, Verbindungslesungen, Kalibrierungen, wechselwirkende Tests, Spezifikation, Werkzeuge, bauen zusammen und bauen darstellte alle Modelle John- DeereBaugeräte und einige Modelle Hitachi, Euclid, Bell und Timberjack auseinander.
<G-vec00001-001-s094><assemble.zusammenbauen><en> "The Jülich researchers are working on a simulation of the human brain. ""We are able to describe a neuron in just a few equations and can thus assemble networks that should be similar to the human brain."
<G-vec00001-001-s094><assemble.zusammenbauen><de> "Die Jülicher Forscher arbeiten an einer Simulation des menschlichen Gehirns: ""Wir beschreiben eine Nervenzelle mit wenigen Gleichungen und bauen daraus Netzwerke zusammen, die dem menschlichen Gehirn möglichst ähnlich sein sollen."
<G-vec00001-001-s095><assemble.zusammenbauen><en> They cut, fit, and assemble wood and other materials for the construction of buildings, highways, bridges, docks, industrial plants, boats, and many other structures.
<G-vec00001-001-s095><assemble.zusammenbauen><de> Sie schneiden, passen und bauen Holz und andere Materialien für den Aufbau der Gebäude, der Landstraßen, der Brücken, der Docks, der Industrieanlagen, der Boote und vieler anderer Strukturen zusammen.
<G-vec00001-001-s096><assemble.zusammenbauen><en> 4,Simply assemble:connecting air pump to valve and turn on pump to inflate it; Take off the valve to deflate it .
<G-vec00001-001-s096><assemble.zusammenbauen><de> 4,bauen einfach zusammen: Verbindungsluftpumpe zum Ventil und schalten Pumpe ein, um sie aufzublasen; Entfernen Sie das Ventil, um es zu entlüften.
<G-vec00001-001-s097><assemble.zusammenbauen><en> Just because _you_ can't do this, doesn't mean that the designer can't either. Actually, you can, it's a relatively simple process: draw each frame as a separate image in MS Paint, save each file (sequential numbering would be a good idea), and assemble in your favorite video editing software, adding the soundtrack.
<G-vec00001-001-s097><assemble.zusammenbauen><de> Wirklich können Sie, es sind ein verhältnismäßig einfacher Prozess: zeichnen Sie jeden Rahmen als unterschiedliches Bild in der Mitgliedstaat-Farbe, außer jeder Akte (aufeinander folgende Nummerierung würde eine gute Idee sein), und bauen Sie in Ihrem Lieblingsvideo zusammen, welches die Software redigiert und den Ton addieren.
<G-vec00001-001-s098><assemble.zusammenbauen><en> The island people still come here to pray and offer their ex-votos, and once a year they assemble for its annual festival; but it is plain that the old monastery has had its day.
<G-vec00001-001-s098><assemble.zusammenbauen><de> travel Inselleute kommen noch her, ihr ex-votos-votos zu sport en und anzubieten, und einmal jährlich bauen sie für sein jährliches Festival zusammen; aber es ist Ebene, daß der alte Monastery seinen Tag gehabt hat.
<G-vec00001-001-s099><assemble.zusammenbauen><en> Once all your components are manufactured and the surface finish is completed, we assemble your products.
<G-vec00001-001-s099><assemble.zusammenbauen><de> Nachdem alle Komponenten produziert sind und das Oberflächenfinish abgeschlossen ist bauen wir ihre Produkte zusammen.
<G-vec00001-001-s100><assemble.zusammenbauen><en> The pilgrims assemble in the little town by the sea, that was once the favoured of Poseidon; and a great harvest is reaped by the shrine.
<G-vec00001-001-s100><assemble.zusammenbauen><de> travel Pilgrims bauen in der kleinen Stadt durch das Meer zusammen, das waren sobald bevorzugt von Poseidon; und eine große Ernte wird durch das shrine geerntet.
<G-vec00001-001-s101><assemble.erstellen><en> They have actually definitely taken unique care right here to assemble a item which balances its technique to weight reduction, and this is the secret to large cause a short time-frame without tossing your physical body out of whack.
<G-vec00001-001-s101><assemble.erstellen><de> Sie haben wirklich einzigartig Hygiene unten getroffen werden, um ein Einzelteil, die ihren Ansatz zur Gewichtsabnahme stabilisiert zu erstellen, und dies ist das Geheimnis zum großen Ursache eine kurze Zeitrahmen zu werfen, ohne deinen physischen Körper nicht in Ordnung.
<G-vec00001-001-s102><assemble.erstellen><en> To assemble a list of fields to be used as a 'Table of Contents' for the document, click the Contents... button: see PDF Table of Contents.
<G-vec00001-001-s102><assemble.erstellen><de> Um eine Liste von Felder zu erstellen, die als 'Inhaltsverzeichnis' für das Dokument verwendet wird, klicken Sie den Inhalt... Knopf: siehe Das PDF-'Inhaltsverzeichnis'.
<G-vec00001-001-s103><assemble.erstellen><en> They have actually actually taken unique care below to assemble a product which balances its approach to weight reduction, and also this is the crucial to big cause a brief time-frame without tossing your body haywire.
<G-vec00001-001-s103><assemble.erstellen><de> Sie haben eigentlich wirklich einzigartige Pflege unten getroffen werden, um ein Produkt, das seine Strategie zur Gewichtsabnahme ausgleicht erstellen, und auch das ist das von entscheidender Bedeutung für großen Vorsprung auf einen kurzen Zeitrahmen zu werfen, ohne Ihren Körper nicht in Ordnung.
<G-vec00001-001-s104><assemble.erstellen><en> Just drag and drop to assemble impressive animations, with a choice of more than 200 filters and effects built into Motion.
<G-vec00001-001-s104><assemble.erstellen><de> In Motion kannst du mit einer Auswahl von über 200 Filtern und Effekten beeindruckende Animationen per Drag & Drop erstellen.
<G-vec00001-001-s105><assemble.erstellen><en> Assemble your own unique support plan through a selection of sub-services geared to helping you achieve your data center and hybrid IT goals.
<G-vec00001-001-s105><assemble.erstellen><de> Erstellen Sie einen individuellen Supportplan und wählen Sie einige Subservices aus, damit Sie die Ziele für Ihr Rechenzentrum und Ihre Hybrid IT verwirklichen können.
<G-vec00001-001-s106><assemble.fertigen><en> We assemble solar modules either from monocrystalline or polycrystalline cells.
<G-vec00001-001-s106><assemble.fertigen><de> Wir fertigen Solarmodule aus monokristallinen oder polykristallinen Zellen.
<G-vec00001-001-s107><assemble.fertigen><en> "The Maquiladoras are factories, operating under NAFTA, that import duty-free materials and equipment, assemble goods and then re-export them (the term ‘maquiladora’ refers to the practice of millers charging a ""maquila"" for processing other people's grain.)"
<G-vec00001-001-s107><assemble.fertigen><de> "Diese NAFTA-gesteuerten Fabriken importieren zollfreie Waren und Ausrüstung, fertigen Güter und exportieren sie wieder (der Begriff ""Maquiladora"" bezieht sich auf die Gepflogenheit von Müllern, eine ""Maquila"" für das Mahlen von Getreide zu verlangen)."
<G-vec00001-001-s108><assemble.fertigen><en> A 2+2-cavity mould is used to produce and assemble two-coloured LSR wristwatches in a cycle time of around 70 seconds.
<G-vec00001-001-s108><assemble.fertigen><de> Mit einem 2+2-fach-Werkzeug werden in einer Zykluszeit von rund 70 s zweifarbige LSR-Armbanduhren produziert und zur fertigen Uhr montiert.
<G-vec00001-001-s109><assemble.fertigen><en> "The Maquiladoras are factories, operating under NAFTA, that import duty-free materials and equipment, assemble goods and then re-export them (the term 'maquiladora' refers to the practice of millers charging a ""maquila"" for processing other people's grain.)"
<G-vec00001-001-s109><assemble.fertigen><de> "Diese NAFTA-gesteuerten Fabriken importieren zollfreie Waren und Ausrüstung, fertigen Güter und exportieren sie wieder (der Begriff ""Maquiladora"" bezieht sich auf die Gepflogenheit von Müllern, eine ""Maquila"" für das Mahlen von Getreide zu verlangen)."
<G-vec00001-001-s110><assemble.fertigen><en> They could then use this technology when visiting customers to assemble standard plants in the virtual world using premanufactured modules.
<G-vec00001-001-s110><assemble.fertigen><de> Beim Kunden könnten sie dann sogar Standardanlagen aus fertigen Modulen in der virtuellen Welt zusammenbauen.
<G-vec00001-001-s111><assemble.fertigen><en> Our team is based on skilled professionals, who with their know-how and experience produce and assemble with maximum approach regarding quality and precision no matter if it is a serial product or a one-piece-solution.
<G-vec00001-001-s111><assemble.fertigen><de> Unser Haus arbeitet ausschließlich mit Facharbeitern, die mit ihrem Know-How und ihrer Erfahrung jedes Instrument, sei es aus dem Serienprogramm oder ein kundenindividuelles Unikat, mit maximalem Anspruch an Qualität und Präzision entwickeln und fertigen.
<G-vec00001-001-s112><assemble.fertigen><en> Blancpain is one of the few Manufactures where the watchmakers still assemble each movement by hand from beginning to end.
<G-vec00001-001-s112><assemble.fertigen><de> Blancpain ist eine der wenigen Manufakturen, in denen die Uhrmacher auch heute noch ein Uhrwerk von A bis Z per Hand fertigen.
<G-vec00001-001-s113><assemble.herstellen><en> Our technicians and engineers from the Testing & Development department make sure every day in our own laboratory that our customers can assemble the safest and most reliable hose lines possible.
<G-vec00001-001-s113><assemble.herstellen><de> Unsere Techniker und Ingenieure aus der Abteilung Prüfung & Entwicklung sorgen jeden Tag in unserem eigenen Prüflabor dafür, dass unsere Kunden die sichersten Schlauchleitungen herstellen können.
<G-vec00001-001-s114><assemble.herstellen><en> “Today, I can assemble any garment, from beginning to end.
<G-vec00001-001-s114><assemble.herstellen><de> “Mittlerweile kann ich jedes Kleidungsstück herstellen.
<G-vec00001-001-s115><assemble.herstellen><en> With that card you can assemble a beautiful pillow box.
<G-vec00001-001-s115><assemble.herstellen><de> Mit dieser Karte kann man eine bildschöne Geschenkschachtel herstellen.
<G-vec00001-001-s116><assemble.kommen><en> 2 Assemble and listen, sons of Jacob; listen to your father Israel.
<G-vec00001-001-s116><assemble.kommen><de> Gen 49:2 Kommt zuhauf und höret zu, ihr Kinder Jakobs, und höret euren Vater Israel.
<G-vec00001-001-s117><assemble.kommen><en> 49:2 Assemble yourselves, and hear, you sons of Jacob.
<G-vec00001-001-s117><assemble.kommen><de> 49:2 Kommt zuhauf und höret zu, ihr Kinder Jakobs, und höret euren Vater Israel.
<G-vec00001-001-s118><assemble.kommen><en> Assemble yourselves, and hear, ye sons of Jacob; And hearken unto Israel your father.
<G-vec00001-001-s118><assemble.kommen><de> Kommt zuhauf und höret zu, ihr Kinder Jakobs, und höret euren Vater Israel.
<G-vec00001-001-s119><assemble.kommen><en> Assemble yourselves, and hear, ye sons of Jacob: and hearken to Israel your father.
<G-vec00001-001-s119><assemble.kommen><de> Kommt zuhauf und höret zu, ihr Kinder Jakobs, und höret euren Vater Israel.
<G-vec00001-001-s120><assemble.kommen><en> Assemble yourselves, and hear, ye sons of Jacob, And listen to Israel your father.
<G-vec00001-001-s120><assemble.kommen><de> Kommt zuhauf und höret zu, ihr Kinder Jakobs, und höret euren Vater Israel.
<G-vec00001-001-s121><assemble.konfektionieren><en> From the systematization of R & D processes, the streamlining of scheduling and procurement processes, the customer-oriented manufacturing and service processes, up to sales organization, the IFS provides a modular system to assemble a comprehensive method for your company’s appropriate production system
<G-vec00001-001-s121><assemble.konfektionieren><de> Von der Systematisierung der F&E-Prozesse, der Verschlankung von Dispositions- und Beschaffungsprozesse über die kundenorientierten Fertigungs- und Serviceprozesse bis hin zur Absatzorganisation bietet die IFS einen umfassenden Methodenbaukasten um für Ihr Unternehmen das passende Produktionssystem zu konfektionieren.
<G-vec00001-001-s122><assemble.konfektionieren><en> We design, manufacture, assemble and deliver standardized products right up to modern innovations.
<G-vec00001-001-s122><assemble.konfektionieren><de> Wir konzipieren, produzieren, konfektionieren und liefern standardisierte Produkte bis hin zu zeitgemäßen Innovationslösungen.
<G-vec00001-001-s123><assemble.konfektionieren><en> We produce and assemble banding material (Banding paper and banding film) for common banding machines that are available on the market.
<G-vec00001-001-s123><assemble.konfektionieren><de> Wir produzieren und konfektionieren Banderoliermaterial (Banderolierpaper sowie Banderolierfolie) für die gängigsten Banderoliermaschinen am Markt.
<G-vec00001-001-s124><assemble.konfektionieren><en> Plug connections from Intercontec are process-reliable, easy to assemble and of high quality.
<G-vec00001-001-s124><assemble.konfektionieren><de> Steckverbindungen von Intercontec sind prozesssicher, einfach zu konfektionieren und qualitativ hochwertig.
<G-vec00001-001-s125><assemble.konfektionieren><en> Our workshops can produce seals according to your drawings, process synthetic materials, assemble hose lines and prepare required test certificates.
<G-vec00001-001-s125><assemble.konfektionieren><de> Unsere Werkstätten fertigen Dichtungen nach Ihren Vorlagen, verarbeiten Kunststoffe, konfektionieren Schlauchleitungen und erstellen erforderliche Prüfzertifikate.
<G-vec00001-001-s126><assemble.konfektionieren><en> They are quick to assemble and offer high operational safety by protecting downstream electronic components.
<G-vec00001-001-s126><assemble.konfektionieren><de> Sie lassen sich schnell konfektionieren und gewährleisten durch den Schutz nachgeschalteter elektronischer Komponenten eine hohe Betriebssicherheit.
<G-vec00001-001-s127><assemble.konfektionieren><en> In order for shelves to store food as desired, we can assemble supplementary components to the glass on request, such as frames and trims, and, even the integration of LED light strips is possible.
<G-vec00001-001-s127><assemble.konfektionieren><de> Damit Kühlschrankböden Lebensmittel wie gewünscht lagern, konfektionieren wir auf Wunsch ergänzende Komponenten wie Rahmen und Abschlussleisten, selbst die Integration von LED-Lichtleisten ist möglich.
<G-vec00001-001-s128><assemble.konfektionieren><en> We deliver your products quickly as panels or individual parts – and we assemble and package them individually to meet your specifications.
<G-vec00001-001-s128><assemble.konfektionieren><de> Wir liefern Ihre Produkte innerhalb kürzester Frist als Nutzen oder Einzelteil – und konfektionieren und verpacken individuell nach Ihren Vorgaben.
<G-vec00001-001-s151><assemble.montieren><en> Where components need to be box, cabinet or chassis-mounted, ASCO Numatics will assemble, test and deliver turnkey solutions to specification.
<G-vec00001-001-s151><assemble.montieren><de> Sind Komponenten im Schaltkasten oder Schaltschrank oder auf einem Rahmen zu montieren, kann ASCO Numatics schlüsselfertige Lösungen anbieten, die gemäß Ihrer Spezifikation zusammengebaut und getestet werden.
<G-vec00001-001-s152><assemble.montieren><en> The Handtmann Armaturenfabrik will continue to operate in the global market from its base in Biberach. It will design and assemble systems and components at this site and commission them at the customers' premises.
<G-vec00001-001-s152><assemble.montieren><de> Die Handtmann Armaturenfabrik wird auch weiterhin von Biberach aus weltweit am Markt tätig sein, Anlagen und Komponenten hier konstruieren, montieren und bei den Kunden in Betrieb nehmen.
<G-vec00001-001-s153><assemble.montieren><en> The limber storage area is faithfully reproduced and extremely easy to assemble.
<G-vec00001-001-s153><assemble.montieren><de> Die geschmeidig Speicherbereich originalgetreu reproduziert und äußerst einfach zu montieren.
<G-vec00001-001-s154><assemble.montieren><en> The heat press machine transfer size 297*420 mm, auto-pneumatic working mode, inside with air pump, no need any Other assemble or change.
<G-vec00001-001-s154><assemble.montieren><de> Die Wärmepressmaschine Übertragungsgröße 297 * 420 mm, Auto-pneumatische Arbeitsmodus, innen mit Luftpumpe, keine Notwendigkeit, irgendwelche andere montieren oder zu ändern.
<G-vec00001-001-s155><assemble.montieren><en> The Hydrogel film is easy to assemble.
<G-vec00001-001-s155><assemble.montieren><de> Die Hydrogelfolie ist einfach zu montieren.
<G-vec00001-001-s156><assemble.montieren><en> “Our customer for the moment has to assemble 2 shafts equipped with 2 locking heads, through the tightening of 16 screws (4 for each head).
<G-vec00001-001-s156><assemble.montieren><de> “Unser Kunde muss momentan 2 mit 2 Spannköpfen ausgestattete Stangen durch Verschrauben von 16 Schrauben montieren (4 für jeden Kopf).
<G-vec00001-001-s157><assemble.montieren><en> "Upon returning from ""Pharaohs"" life gets hectic: expect from Japan the new bikes, amended in accordance with the experience of the race in Egypt, bikes arriving anco-ra to assemble and check."
<G-vec00001-001-s157><assemble.montieren><de> "Nach ihrer Rückkehr aus ""Pharaonen"" das Leben wird hektischer: die neuen Bikes aus Japan erwarten, nach den Erfahrungen des Rennens in Ägypten geändert, Fahrräder kommen Anco-Ra montieren und prüfen."
<G-vec00001-001-s158><assemble.montieren><en> You can assemble this Forward Controls for Dyna yourself within 1 hour.
<G-vec00001-001-s158><assemble.montieren><de> Sie können diese Forward Controls für Dyna selbst innerhalb von 1 Stunde montieren.
<G-vec00001-001-s159><assemble.montieren><en> Build the mythical castle “Fritter Time” easy to assemble, not to look at the classic regulation is to push as much as you can.
<G-vec00001-001-s159><assemble.montieren><de> "Bauen sie das legendäre schloss ""Fritter Time"" einfach zu montieren, schauen sie nicht in den klassischen verordnung "" drücken können."
<G-vec00001-001-s160><assemble.montieren><en> The booster was actually really easy to assemble, and I figure it out by myself, with just the help of the instructions and FAQ section of the website.
<G-vec00001-001-s160><assemble.montieren><de> Der Verstärker war eigentlich wirklich einfach zu montieren, und ich finde es selbst heraus, mit nur der Hilfe der Anweisungen und FAQ-Bereich der Website.
<G-vec00001-001-s161><assemble.montieren><en> Disclaimer: ● Please read and follow the user manual carefully before you assemble or operate the 3D printer.
<G-vec00001-001-s161><assemble.montieren><de> Großhandelsanfrage Haftungsausschluss: ● Bitte lesen und befolgen Sie die Bedienungsanleitung sorgfältig, bevor Sie den 3D Drucker montieren oder bedienen.
<G-vec00001-001-s162><assemble.montieren><en> Assemble the screwcoverby pressing on the lateral sides first and finally on the central part (Fig.
<G-vec00001-001-s162><assemble.montieren><de> Die Abdeckung montieren, indem man zuerst auf die Seitenteile und danach auf den Mittelteil drückt (Fig.
<G-vec00001-001-s163><assemble.montieren><en> The Guee Aero-X is easy to assemble without tools.
<G-vec00001-001-s163><assemble.montieren><de> Der Guee Aero-X ist ohne Werkzeug leicht zu montieren.
<G-vec00001-001-s164><assemble.montieren><en> The Hapro Atlas 3 Blue has a smart design and is very easy to assemble and lock.
<G-vec00001-001-s164><assemble.montieren><de> Der Hapro Atlas 3 Blue hat ein schickes Design und ist sehr einfach zu montieren und zu verriegeln.
<G-vec00001-001-s165><assemble.montieren><en> Length of modules is up to 1,25 m, so they are easy to lift and simple to assemble that allows to quickly change the configuration of the fairway and continue the game.
<G-vec00001-001-s165><assemble.montieren><de> Die Module sind 1,25 Meter lang, also es ist leicht sie zu erheben und unkompliziert zu montieren, und deshalb man kann schnell die Bahnkonfiguration ändern und das Spiel weiterführen.
<G-vec00001-001-s166><assemble.montieren><en> Easy to assemble without using glue or safety wires.
<G-vec00001-001-s166><assemble.montieren><de> Sind sehr leicht zu montieren, ohne verwendung von leim oder backup-leitungen.
<G-vec00001-001-s167><assemble.montieren><en> The Grove Push Button, like all the modules compatible with this system, is very easy to assemble, even for beginners.
<G-vec00001-001-s167><assemble.montieren><de> Die Grove-Taste ist ebenso wie alle mit diesem System kompatiblen Module leicht zu montieren und auch für Anfänger gut geeignet.
<G-vec00001-001-s168><assemble.montieren><en> These two helicopters, distinguished by their impressive Cartograf markings, are ready to take to the air, and thanks to their superior engineering quality, they assemble with consummate ease.
<G-vec00001-001-s168><assemble.montieren><de> Diese beiden Hubschrauber, die durch ihre beeindruckende Cartograf Markierungen unterscheiden, sind bereit, um die Luft zu nehmen, und dank ihrer Ã1⁄4berlegenen Technik die Qualität, montieren sie mit Leichtigkeit.
<G-vec00001-001-s169><assemble.montieren><en> The more Monsters you assemble on the island, the bigger and better the sounds.
<G-vec00001-001-s169><assemble.montieren><de> Je mehr Monster Sie montieren auf der Insel, die größer und besser klingt.
<G-vec00001-001-s170><assemble.montieren><en> Assemble the parts to complete the picture and the picture puzzle game Kayu II.
<G-vec00001-001-s170><assemble.montieren><de> Montieren Sie die Teile, um das Bild und das Bild Puzzle-Spiel Kayu II abzuschließen.
<G-vec00001-001-s171><assemble.montieren><en> Description: Assemble squares and complete the puzzles.
<G-vec00001-001-s171><assemble.montieren><de> Beschreibung: Montieren Plätze und füllen Sie das Rätsel.
<G-vec00001-001-s172><assemble.montieren><en> Using these wholesalers, you'd be able to purchase bulk materials at a lower price (which is good news for your bottom line) and then assemble your jewelry products before launching them in your online store.
<G-vec00001-001-s172><assemble.montieren><de> Mit diesen Großhändler, Sie wäre in der Lage zum Kauf von bulk-Materialien zu einem niedrigeren Preis (das ist eine gute Nachricht für Ihre bottom line) und dann montieren Sie Ihre Schmuck-Produkte vor der Einführung Sie in Ihrem online-Shop.
<G-vec00001-001-s173><assemble.montieren><en> Description: Assemble Mecha is a coordinating game where you will probably collect goliath kick-ass robots parts by parts.
<G-vec00001-001-s173><assemble.montieren><de> Beschreibung: Montieren Sie Mecha ist eine koordinierende Spiel wo Sie wahrscheinlich Goliath Kick-Ass Roboter Teile durch Teile sammeln.
<G-vec00001-001-s174><assemble.montieren><en> Assemble the lining and outside of the pocket in the flap, place against place.
<G-vec00001-001-s174><assemble.montieren><de> Montieren Sie die Verkleidung und außerhalb der Tasche in der Klappe, statt vor Ort.
<G-vec00001-001-s175><assemble.montieren><en> Assemble the mounting tool and bolt for mounting tool using the allen key screws.
<G-vec00001-001-s175><assemble.montieren><de> Montieren Sie das Montagewerkzeug und die Schraube für das Montagewerkzeug mit den Inbusschrauben.
<G-vec00001-001-s176><assemble.montieren><en> Game Description: Assemble the puzzle with the image of a beautiful and cute girls who are in a rather interesting and beautiful places in the game.
<G-vec00001-001-s176><assemble.montieren><de> Spielbeschreibung: Montieren Sie das Puzzle mit einem Bild von schönen und netten Mädchen, die sehr interessant sind und schöne Orte im Spiel.
<G-vec00001-001-s177><assemble.montieren><en> The first thing to do is hang the lights and assemble the beds and wardrobes.
<G-vec00001-001-s177><assemble.montieren><de> Sorgen Sie zuerst für die Beleuchtung und montieren Sie Betten und Kleiderschränke.
<G-vec00001-001-s178><assemble.montieren><en> Finally, assemble the black connectors, inserting the sockets into the casing.
<G-vec00001-001-s178><assemble.montieren><de> Zum Schluss montieren Sie den schwarzen Verbinder, indem Sie die Anschlüsse in das Verbindergehäuse einlegen.
<G-vec00001-001-s179><assemble.montieren><en> Assemble with clothes ON in the little park on the southern side of Hamilton Railway Station .
<G-vec00001-001-s179><assemble.montieren><de> Montieren Sie die Kleidung im kleinen Park an der Südseite des Bahnhofs Hamilton .
<G-vec00001-001-s180><assemble.montieren><en> Assemble the rod and attach the shelves.
<G-vec00001-001-s180><assemble.montieren><de> Montieren Sie die Stange und befestigen Sie die Regale.
<G-vec00001-001-s181><assemble.montieren><en> Assemble the po’ boys by placing 3 slices of Buffalo tofu onto the bread.
<G-vec00001-001-s181><assemble.montieren><de> Montieren Sie den po 'Jungen, indem 3 Scheiben von Buffalo Tofu auf dem Brot.
<G-vec00001-001-s182><assemble.montieren><en> Assemble prototypes from various 3D printed materials.
<G-vec00001-001-s182><assemble.montieren><de> Montieren Sie Prototypen aus verschiedenen 3D-gedruckten Materialien.
<G-vec00001-001-s183><assemble.montieren><en> Assemble the cream.
<G-vec00001-001-s183><assemble.montieren><de> Montieren Sie die Creme.
<G-vec00001-001-s184><assemble.montieren><en> If your sections are small or modular you can install the plywood to the framework before the section is installed on the wall, in otherwords, assemble the entire modular section then mount it to the wall.
<G-vec00001-001-s184><assemble.montieren><de> Wenn Ihre Sektionen klein oder modular sind, können Sie das Sperrholz am Rahmen anbringen, bevor der Abschnitt an der Wand installiert wird, das heißt, montieren Sie den gesamten modularen Abschnitt und montieren Sie ihn an der Wand.
<G-vec00001-001-s185><assemble.montieren><en> Bearbarians - Assemble and upgrade your army of bears and prepare to fight to the death.
<G-vec00001-001-s185><assemble.montieren><de> Bearbarians - Montieren Sie und aktualisieren Sie Ihre Armee von Bären und vorbereiten, bis zum Tod kämpfen.
<G-vec00001-001-s186><assemble.montieren><en> Assembling and Installation • Assemble the stand in accordance with the assembly instructions and securely attach all screws at the designated locations.
<G-vec00001-001-s186><assemble.montieren><de> Montage und Installation • Montieren Sie den Ständer gemäß den Montageanweisungen und befestigen Sie alle Schrauben sicher an den jeweils vorgesehenen Positionen.
<G-vec00001-001-s187><assemble.montieren><en> We can produce and assemble a wide variety of switchgear – from individual switching cabinets to highly complex technical installations in compliance with all relevant standards and regulations.
<G-vec00001-001-s187><assemble.montieren><de> Von einzelnen Schaltschränken bis hin zu hoch komplexen Anlagen fertigen und montieren wir unter Einhaltung aller einschlägigen Normen und Vorschriften die unterschiedlichsten Schaltanlagen für Sie.
<G-vec00001-001-s188><assemble.montieren><en> From design to final assembly, the CHANEL teams draw, design, fashion, cut, mould, polish, assemble, adjust and regulate all watch components, including certain mechanical components in the famous J12 high-tech ceramic cases.
<G-vec00001-001-s188><assemble.montieren><de> Von der Konzeption bis hin zur Endmontage werden alle Uhrenbestandteile, darunter auch einige Bauteile der Mechanikwerke der J12-Modelle mit ihren berühmten Gehäusen aus Hightech-Keramik, von den CHANEL-Teams entworfen, konzipiert, bearbeitet, zugeschnitten, gegossen, poliert, montiert, justiert und reguliert.
<G-vec00001-001-s189><assemble.montieren><en> It will be just what you need to import EML to Outlook and assemble a new PST file after its predecessor was damaged and processed by a data recovery tool that generated hundreds of EML files clogging your hard drive.
<G-vec00001-001-s189><assemble.montieren><de> Es ist genau das, was Sie brauchen, um Import EML zu Outlook und montiert eine neue PST-Datei nach seinem Vorgänger beschädigt wurde und durch ein Datenrettungs-Tool verarbeitet, die Hunderte von EML-Dateien erzeugen die Festplatte zu verstopfen.
<G-vec00001-001-s190><assemble.montieren><en> Our single-ended cordsets for the new push-pull variants of the Profinet modules are fast and easy to assemble, whether copper or fiber optic cables.
<G-vec00001-001-s190><assemble.montieren><de> Unsere Anschlussleitungen für die neuen Push-Pull-Varianten der Profinet-Module sind besonders schnell und einfach montiert – ob als Kupfer- oder Lichtwellenleiterleitungen.
<G-vec00001-001-s191><assemble.montieren><en> Our qualified personnel help you assemble and package your goods, where the costs are lowest.
<G-vec00001-001-s191><assemble.montieren><de> Unser Fachpersonal hilft Ihnen und montiert und verpackt Ihre Ware dort, wo für Sie die geringsten Kosten entstehen.
<G-vec00001-001-s192><assemble.montieren><en> Far more stable than tropical hardwood, which makes it possible to assemble the planks with fer / groove over the ends.
<G-vec00001-001-s192><assemble.montieren><de> Hohe Stabilität Weitaus stabiler als tropisches Hartholz, wodurch die Dielen mit Fer / Nut über den Enden montiert werden können.
<G-vec00001-001-s193><assemble.montieren><en> """ As we wait for the installation of the first PET scanner in a series of many, t he first device is assemble d and is producing high resolution images from initial test scans as expected,"" said Dr. A.F."
<G-vec00001-001-s193><assemble.montieren><de> """ Während wir auf die Installation des ersten PET-Scanners - einer von vielen - warten, ist das Gerät montiert worden und lieferte bei Testbetrieb wie erwart hochauflösende Aufnahmen"", sagte Dr. A.F."
<G-vec00001-001-s194><assemble.montieren><en> In Subotica the segment currently has approximately 650 employees and uses its shop floor area of 7.200 m 2 to assemble hose lines for the power train.
<G-vec00001-001-s194><assemble.montieren><de> In Subotica montiert das Segment derzeit auf 7.200 m 2 Produktionsfläche und mit rund 650 Mitarbeitern Schlauchleitungen für den Antriebsstrang.
<G-vec00001-001-s195><assemble.montieren><en> We produce, assemble and package products under controlled Air Purity Class C/ISO 7 conditions.
<G-vec00001-001-s195><assemble.montieren><de> Die Produkte werden unter kontrollierten Bedingungen der Luftreinheitsklasse C/ISO 7 produziert, montiert und verpackt.
<G-vec00001-001-s196><assemble.montieren><en> Here it uses its sensitive touch to assemble part of an automatic transmission and moves more slowly.
<G-vec00001-001-s196><assemble.montieren><de> Hier montiert er sensitiv den Teil eines Automatikgetriebes und bewegt sich dabei entsprechend langsamer.
<G-vec00001-001-s197><assemble.montieren><en> The WinSafe series from BURG-WÄCHTER is fast and easy to assemble to your doors and windows.
<G-vec00001-001-s197><assemble.montieren><de> Die WinSafe Serie von BURG-WÄCHTER ist schnell und einfach an Türen und Fenstern montiert.
<G-vec00001-001-s198><assemble.montieren><en> The IEC 61340-5-1 Ed. 2.0 (2016-05) applies to activities that manufactures, process, assemble, install, package, label, service, test, inspect, transport or otherwise handle ESDS (E lectro S tatic D ischarge Sensitive Devices) susceptible to damage by electrostatic discharges greater or equal to 100 V according to the H uman B ody M odel (HBM), 200V CDM and 35V for isolated conductors.
<G-vec00001-001-s198><assemble.montieren><de> Die aktuelle Version der DIN EN 61340-5-1 (2017-07) gilt für Aktivitäten, bei denen ESDS (E lectro S tatic D ischarge Sensitive Devices) mit einer Empfindlichkeit gegen Schädigung durch elektrostatische Entladungen von 100 V oder mehr nach dem H uman B ody M odell (HBM), 200V nach dem C harged D evice M odel (CDM) und 35 V bei isolierten Leitern hergestellt, verarbeitet, montiert, installiert, verpackt, gekennzeichnet, gewartet, erprobt, geprüft oder auf eine andere Art und Weise gehandhabt werden.
<G-vec00001-001-s199><assemble.montieren><en> Required to realize the very complex Crane & Conveyor Systems is the “Scheffer Krantechnik GmbH”. We design the Systems in close collaboration with “Lichtgitter” and produce, assemble and put them in operation by our experts.
<G-vec00001-001-s199><assemble.montieren><de> Die hierfür benötigte komplexe Kran- & Fördertechnik wird durch die Scheffer Krantechnik GmbH in enger Zusammenarbeit mit Lichtgitter kundenindividuell geplant und durch unser Fachpersonal produziert, montiert und in Betrieb genommen.
<G-vec00001-001-s200><assemble.montieren><en> This is where employees wearing AR glasses can monitor the construction of prototypes or receive messages at the assembly line concerning the sequence of steps that must be taken to assemble a brake disk.
<G-vec00001-001-s200><assemble.montieren><de> Dort können Mitarbeiter mit AR-Brillen die Bauweise von Prototypen überprüfen oder am Fließband angezeigt bekommen, in welchen Schritten eine Bremsscheibe montiert werden muss.
<G-vec00001-001-s201><assemble.montieren><en> To make work-piece be the best position for welding or assemble by workbench’s lifting, rotation and overturning, the positioner could be made up for the auto-welding special welding machine with welding operator, or it could be matched up with the robot’s peripheral equipments to come out the welding automatic.
<G-vec00001-001-s201><assemble.montieren><de> Um Werkstück die beste Position zum Schweißen oder montiert durch Werkbank Heben, Drehen und Umkippen zu machen, könnte der Stellungsregler für die Auto-Schweißen speziellen Schweißmaschine mit Schweißers nachgeholt werden, oder es könnte mit den Roboterperipheriegeräten abgestimmt werden das Schweißen kommen automatisch.
<G-vec00001-001-s202><assemble.sammeln><en> The shores, where almost all the turtles of the Oroonoko appear to assemble annually, are situate between the junction of the Oroonoko with the Apure, and the great cataracts, or Raudales; that is to say, between Cabruta and the mission of Atures.
<G-vec00001-001-s202><assemble.sammeln><de> Die Gestade, auf denen sich fast alle Schildkröten vom Orenoko alljährlich zu sammeln scheinen, sind zwischen dem Zusammenfluss des Orenoko mit dem Apure und den großen Cataracten oder Raudales, das will sagen, zwischen Cabruta und der Mission von Atures gelegen.
<G-vec00001-001-s203><assemble.sammeln><en> Many are nearly impossible to assemble and use.
<G-vec00001-001-s203><assemble.sammeln><de> Viele sind fast unmöglich, zu sammeln und, zu verwenden.
<G-vec00001-001-s204><assemble.sammeln><en> Rest Day: Salta The first week of the Dakar had been exhausting for everybody. The only rest day within two weeks gave the riders at least some time to relax and assemble their forces for the second week of competition.
<G-vec00001-001-s204><assemble.sammeln><de> Ruhetag: Salta Nach einer anstrengenden ersten Woche hatten die Fahrer am einzigen Ruhetag innerhalb von zwei Wochen zumindest ein bisschen Zeit sich auszuruhen und Kraft für die zweite Woche zu sammeln.
<G-vec00001-001-s205><assemble.sammeln><en> The only thing you should do in this case is to assemble the original solid storage using data recovery software.
<G-vec00001-001-s205><assemble.sammeln><de> Die einzige Sache, die Sie in diesem Fall machen sollten, soll die ursprüngliche feste Speicherung mit der Datenrettungssoftware sammeln.
<G-vec00001-001-s206><assemble.sammeln><en> In following this same order, you will thus first try to assemble the photos, which will be, by their nature, the basis of the identification of the different works.
<G-vec00001-001-s206><assemble.sammeln><de> In der gleichen Reihenfolge wird er also zuvor versuchen die Fotos zu sammeln, die natürlich die Basis der individuellen Identifizierung der Werke sein wird.
<G-vec00001-001-s207><assemble.sammeln><en> Israel ben Eliezer now began to assemble a circle of disciples, although, admittedly, not all of them would share his beliefs in every aspect.
<G-vec00001-001-s207><assemble.sammeln><de> Israel ben Eliezer begann nun, einen Kreis von Schülern um sich zu sammeln, von denen freilich nicht alle später in jeder Hinsicht seine Lehre teilten.
<G-vec00001-001-s208><assemble.sammeln><en> As indicated in the following section, we also use cookies and/or logs to assemble information concerning you.
<G-vec00001-001-s208><assemble.sammeln><de> Wie in nachstehendem Abschnitt angegeben verwenden wir auch Cookies und/oder Logs, um Sie betreffende Informationen zu sammeln.
<G-vec00001-001-s209><assemble.sammeln><en> Postponement meant: assemble your forces and strangle the revolution.
<G-vec00001-001-s209><assemble.sammeln><de> Das Hinziehen bedeutete: Kräfte sammeln und die Revolution erdrosseln.
<G-vec00001-001-s210><assemble.sammeln><en> If data recovery is possible without repair, you should assemble your RAID using data recovery software specifying the drives (including placeholders for any missing drive), drives order, stripe size and a parity distribution algorithm.
<G-vec00001-001-s210><assemble.sammeln><de> Wenn Datenrettung ohne Reparatur möglich ist, sollten Sie Ihren RAID mit der Datenrettungssoftware sammeln, die die Laufwerke (einschließlich Platzhalter für jedes fehlende Laufwerk), Laufwerkordnung, Größe des Streifens und Paritätsvertriebsalgorithmus angibt.
<G-vec00001-001-s211><assemble.sammeln><en> Wherever they want to manifest they assemble the dense material and appear.
<G-vec00001-001-s211><assemble.sammeln><de> Wo immer sie sich manifestieren möchten, sammeln sie das dichte Material an und erscheinen.
<G-vec00001-001-s212><assemble.sammeln><en> Therefore say, Thus saith the Lord Jehovah: I will gather you from the peoples, and assemble you out of the countries where ye have been scattered, and I will give you the land of Israel.
<G-vec00001-001-s212><assemble.sammeln><de> Darum sprich: So sagt der HERR HERR: Ich will euch sammeln aus den Völkern und will euch sammeln aus den Ländern, dahin ihr zerstreut seid, und will euch das Land Israel geben.
<G-vec00001-001-s213><assemble.sammeln><en> The consortium that will assemble and interpret these maps includes the two institutes of the Max Planck Society in Germany, the University of Hawaii, the Harvard-Smithsonian Center for Astrophysics and the Johns Hopkins University in the USA, plus a group of Universities in the United Kingdom.
<G-vec00001-001-s213><assemble.sammeln><de> Zu dem Konsortium, das diese Daten sammeln und interpretieren wird, gehören die Max-Planck-Gesellschaft in Deutschland, die University of Hawaii, das Harvard-Smithsonian Center for Astrophysics und die Johns Hopkins University in den USA sowie eine Gruppe von Universitäten in Großbritannien.
<G-vec00001-001-s214><assemble.sammeln><en> In order to perform this function the banks must be able to assemble,concentrate, and lend out as much of the available idle money as possible.
<G-vec00001-001-s214><assemble.sammeln><de> Umm diese Funktion zu erfüllen, müssen die Banken möglichst alle Gelder, die in den Händen ihrer Besitzer brachliegen, sammeln, konzentrieren und sie dann den Produktiven ausleihen.
<G-vec00001-001-s215><assemble.sammeln><en> Now is rolled with a rolling pin on a side edge of the mold, cut off all the excess dough and assemble it into a ball.
<G-vec00001-001-s215><assemble.sammeln><de> Jetzt mit einem Rollenstift auf dem Rand der Felge Form gerollt wird, schneiden alle überschüssigen Teiges aus und in eine Kugel sammeln.
<G-vec00001-001-s216><assemble.sammeln><en> Let us then assemble all the expedients of equilibrium.
<G-vec00001-001-s216><assemble.sammeln><de> Dann laßt uns alles sammeln, was dem Gleichgewicht dienlich ist.
<G-vec00001-001-s217><assemble.sammeln><en> The Captain’s next task is to assemble in formation with other planes of the squadron, as stipulated by orders.
<G-vec00001-001-s217><assemble.sammeln><de> Die nächste Aufgabe des Kommandeurs ist, sich auf Befehl in einer Formation mit den anderen Flugzeugen der Staffel zu sammeln.
<G-vec00001-001-s218><assemble.sammeln><en> 11:12 He will raise a banner for the nations and gather the exiles of Israel; he will assemble the scattered people of Judah from the four quarters of the earth.
<G-vec00001-001-s218><assemble.sammeln><de> 11:12 Und er wird ein Zeichen aufrichten unter den Völkern und zusammenbringen die Verjagten Israels und die Zerstreuten Judas sammeln von den vier Enden der Erde.
<G-vec00001-001-s219><assemble.sammeln><en> Regards the site. These tips will help you assemble a pregnancy wardrobe that's comfortable, attractive, and affordable.
<G-vec00001-001-s219><assemble.sammeln><de> Diese Vorsagen werden Ihnen helfen, den Kleiderschrank der Schwangerschaft zu sammeln, es ist, attraktiv bequem, und es ist möglich.
<G-vec00001-001-s220><assemble.sammeln><en> It is possible to assemble all, for example, handles, calendars, brands, coins, hours and many other things.
<G-vec00001-001-s220><assemble.sammeln><de> Sammeln es kann alle, zum Beispiel, Griffe, die Kalender, die Marke, die Münze, die Stunden und anderes.
<G-vec00443-001-s152><assemble.sammeln><en> In following this same order, you will thus first try to assemble the photos, which will be, by their nature, the basis of the identification of the different works.
<G-vec00443-001-s152><assemble.sammeln><de> In der gleichen Reihenfolge wird er also zuvor versuchen die Fotos zu sammeln, die natürlich die Basis der individuellen Identifizierung der Werke sein wird.
<G-vec00443-001-s153><assemble.sammeln><en> Israel ben Eliezer now began to assemble a circle of disciples, although, admittedly, not all of them would share his beliefs in every aspect.
<G-vec00443-001-s153><assemble.sammeln><de> Israel ben Eliezer begann nun, einen Kreis von Schülern um sich zu sammeln, von denen freilich nicht alle später in jeder Hinsicht seine Lehre teilten.
<G-vec00001-001-s221><assemble.sich_sammeln><en> The competent offices of the Roman Curia will publish a Compendium which will assemble texts from the Catechism of the Catholic Church, prayers, explanations of the Eucharistic Prayers of the Roman Missal and other useful aids for a correct understanding, celebration and adoration of the Sacrament of the Altar (251).
<G-vec00001-001-s221><assemble.sich_sammeln><de> Es wird ein von den zuständigen Dikasterien herausgegebenes Kompendium veröffentlicht werden, das Texte aus dem Katechismus der Katholischen Kirche, Orationen, Erläuterungen der Eucharistischen Hochgebete aus dem Meßbuch und anderes sammeln wird, das sich für ein rechtes Verständnis sowie für die Feier und die Anbetung des Altarssakramentes als nützlich erweisen kann.
<G-vec00001-001-s222><assemble.sich_sammeln><en> He answered: “Where will be the body, there the vultures will also assemble” (Luke 17,37).
<G-vec00001-001-s222><assemble.sich_sammeln><de> Er antwortete ihnen: „Wo ein Leib ist, da sammeln sich auch die Geier” (Lukas 17,37).
<G-vec00001-001-s223><assemble.sich_sammeln><en> Schoolchildren assemble for the start of the 'second shift', afternoon lessons at the school.
<G-vec00001-001-s223><assemble.sich_sammeln><de> "Schülerinnen und Schüler sammeln sich zum Beginn der ""zweiten Schicht"", dem Nachmittagsbetrieb an der Schule."
<G-vec00001-001-s224><assemble.zusammensetzen><en> Installers, in turn, assemble your customized PV systems from individual components and are responsible for commissioning.
<G-vec00001-001-s224><assemble.zusammensetzen><de> Dieser wiederum setzt aus einzelnen Komponenten deine maßgeschneiderte Solaranlage zusammen und ist für die Inbetriebnahme zuständig.
<G-vec00001-001-s225><assemble.zusammensetzen><en> The puzzle will assemble itself piece by piece and it's not even necessary to understand every little detail of the story the first time you see the movie in order to just basically follow the thriller.
<G-vec00001-001-s225><assemble.zusammensetzen><de> Das Puzzle setzt sich langsam und stetig zusammen und dabei ist es noch nicht mal nötig, jedes Detail der Geschichte beim ersten Sehen des Films zu verstehen, um dem Thriller im Gesamten folgen zu können.
<G-vec00001-001-s226><assemble.zusammensetzen><en> The indifferent gonads thus assemble themselves from cells of various origins, whereby, as a result, the primordial germ cells and the local somatic blastema influence each other reciprocally (13).
<G-vec00001-001-s226><assemble.zusammensetzen><de> Die indifferente Gonade setzt sich also aus einem Blastem mit Zellen unterschiedlicher Herkunft zusammen, wobei sich in der Folge die Urkeimzellen und das lokale somatische Blastem reziprok beeinflussen (13).
<G-vec00001-001-s246><assemble.sich_versammeln><en> 21:0.5The original Michael is the presiding head of the primary Paradiseˆ Sons when they assemble for conference at the center of all things.
<G-vec00001-001-s246><assemble.sich_versammeln><de> 21:0.5 (234.5) Der ursprüngliche Michael ist das leitende Oberhaupt der primären Paradies-Söhne, wenn sich diese in der Mitte aller Dinge zur Beratung versammeln.
<G-vec00001-001-s247><assemble.sich_versammeln><en> The original Michael is the presiding head of the primary Paradise Sons when they assemble for conference at the center of all things.
<G-vec00001-001-s247><assemble.sich_versammeln><de> Der ursprüngliche Michael ist das leitende Oberhaupt der primären Paradies-Söhne, wenn sich diese in der Mitte aller Dinge zur Beratung versammeln.
<G-vec00001-001-s248><assemble.sich_versammeln><en> If the Sejm cannot assemble for a sitting, the President of the Republic may declare a state of war.
<G-vec00001-001-s248><assemble.sich_versammeln><de> Kann der Sejm sich nicht zu einer Sitzung versammeln, entscheidet der Präsident der Republik Polen über den Kriegszustand.
<G-vec00001-001-s249><assemble.sich_versammeln><en> 7 They made a proclamation throughout Judah and Jerusalem to all the exiles, that they should assemble at Jerusalem,
<G-vec00001-001-s249><assemble.sich_versammeln><de> Ezr 10:7 Dann ließen sie einen Ruf ergehen in Juda und Jerusalem an alle Söhne der Gefangenschaft, sie sollten sich in Jerusalem versammeln.
<G-vec00001-001-s250><assemble.sich_versammeln><en> It depends on the freedom of citizens to speak their minds and assemble without fear, and on the rule of law and due process that guarantees the rights of all people.
<G-vec00001-001-s250><assemble.sich_versammeln><de> Sie beruht auf dem Recht der Bürger, ohne Angst ihre Meinung sagen und sich versammeln zu können, auf Rechtsstaatlichkeit und ordentlichen Gerichtsverfahren, die die Rechte aller Menschen gewährleisten.
<G-vec00001-001-s251><assemble.sich_versammeln><en> But those marches, on which troops have to assemble daily in divisions, or perhaps in corps, and have an additional move to get into quarters, take up the most time, and are only advisable in rich countries, and where the masses of troops are not too large, as in such cases the greater facilility of subsistence and the advantage of the shelter which the troops obtain compensate sufficiently for the fatigue of a longer march.
<G-vec00001-001-s251><assemble.sich_versammeln><de> Diejenigen Märsche aber, bei welchen die Truppen sich täglich in Divisionen oder gar in Korps versammeln müssen und doch in Quartiere abrücken, kosten die meiste Zeit und sind nur in reichen Gegenden und bei nicht zu großen Truppenmassen ratsam, weil dann die erleichterte Beköstigung und das Obdach einen hinreichenden Ersatz geben für die längere Anstrengung.
<G-vec00001-001-s252><assemble.sich_versammeln><en> Riders should assemble at the park starting at 4:00 PM for body painting, other preparations, and other events.
<G-vec00001-001-s252><assemble.sich_versammeln><de> Die Fahrer sollten sich ab 16.00 Uhr im Park für Body-Painting, andere Vorbereitungen und andere Veranstaltungen versammeln.
<G-vec00001-001-s256><assemble.sich_zusammenbauen><en> This product is easy to assemble.
<G-vec00001-001-s256><assemble.sich_zusammenbauen><de> Dieses Produkt lässt sich leicht zusammenbauen.
<G-vec00001-001-s257><assemble.sich_zusammenbauen><en> Now you can, without any knowledge of horology, assemble your own clockwork.
<G-vec00001-001-s257><assemble.sich_zusammenbauen><de> Jetzt können Sie sich ohne uhrmacherische Kenntnisse selbst Ihre Präzisions-Tischuhr zusammenbauen.
<G-vec00001-001-s258><assemble.sich_zusammenbauen><en> Curved Tension Fabric Display is quick and easy to assemble with simple push button framework with no tools required.
<G-vec00001-001-s258><assemble.sich_zusammenbauen><de> Curved Tension Stoffdisplay lässt sich schnell und einfach mit einem einfachen Druckknopfrahmen ohne Werkzeug zusammenbauen.
<G-vec00179-001-s256><assemble.zusammenbauen><en> This product is easy to assemble.
<G-vec00179-001-s256><assemble.zusammenbauen><de> Dieses Produkt lässt sich leicht zusammenbauen.
<G-vec00179-001-s257><assemble.zusammenbauen><en> Now you can, without any knowledge of horology, assemble your own clockwork.
<G-vec00179-001-s257><assemble.zusammenbauen><de> Jetzt können Sie sich ohne uhrmacherische Kenntnisse selbst Ihre Präzisions-Tischuhr zusammenbauen.
<G-vec00179-001-s258><assemble.zusammenbauen><en> Curved Tension Fabric Display is quick and easy to assemble with simple push button framework with no tools required.
<G-vec00179-001-s258><assemble.zusammenbauen><de> Curved Tension Stoffdisplay lässt sich schnell und einfach mit einem einfachen Druckknopfrahmen ohne Werkzeug zusammenbauen.
<G-vec00001-001-s259><assemble.sich_zusammenstellen><en> Here, companies and also end-users can assemble their own productivity portfolio from a catalog of services and therefore have a selected overview of the possible potential candidates.
<G-vec00001-001-s259><assemble.sich_zusammenstellen><de> Hier können sich Unternehmen aber auch Endnutzer aus einem Katalog von Services ihr eigenes Produktivätsportfolio zusammenstellen und haben dadurch einen ausgewählten Überblick von möglichen potentiellen Kandidaten.
<G-vec00001-001-s260><assemble.sich_zusammenstellen><en> In addition, with our different options, you can assemble your machine in terms of drive system, tyres, hydraulics and the driver's cabin so that it is one-hundred per cent tailored to you, your business and your work tasks.Â
<G-vec00001-001-s260><assemble.sich_zusammenstellen><de> Darüber hinaus können Sie sich mit unseren unterschiedlichen Optionen in punkto Antrieb, Bereifung, Hydraulik und Fahrerstand Ihre Maschine so zusammenstellen, dass sie hundertprozentig zu Ihnen, Ihrem Betrieb und Ihren Arbeitsaufgaben passt.
<G-vec00001-001-s261><assemble.sich_zusammenstellen><en> That's why you can assemble your testo Saveris 2 package, with the right loggers and the optimum Cloud licence yourself.
<G-vec00001-001-s261><assemble.sich_zusammenstellen><de> Deshalb können Sie sich Ihr testo Saveris 2 Paket mit den passenden Loggern und der für Sie optimalen Cloud-Lizenz selbst zusammenstellen.
<G-vec00001-001-s262><assemble.sich_zusammenstellen><en> By using libraries, it is possible to assemble geographic information, which can be reused for different maps (for different use cases).
<G-vec00001-001-s262><assemble.sich_zusammenstellen><de> Mit Hilfe von Bibliotheken lassen sich geografische Informationen zusammenstellen, die in unterschiedlichen Karten (für unterschiedliche Anwendungsfälle) wiederverwendet werden können.
<G-vec00179-001-s259><assemble.zusammenstellen><en> Here, companies and also end-users can assemble their own productivity portfolio from a catalog of services and therefore have a selected overview of the possible potential candidates.
<G-vec00179-001-s259><assemble.zusammenstellen><de> Hier können sich Unternehmen aber auch Endnutzer aus einem Katalog von Services ihr eigenes Produktivätsportfolio zusammenstellen und haben dadurch einen ausgewählten Überblick von möglichen potentiellen Kandidaten.
<G-vec00179-001-s260><assemble.zusammenstellen><en> In addition, with our different options, you can assemble your machine in terms of drive system, tyres, hydraulics and the driver's cabin so that it is one-hundred per cent tailored to you, your business and your work tasks.Â
<G-vec00179-001-s260><assemble.zusammenstellen><de> Darüber hinaus können Sie sich mit unseren unterschiedlichen Optionen in punkto Antrieb, Bereifung, Hydraulik und Fahrerstand Ihre Maschine so zusammenstellen, dass sie hundertprozentig zu Ihnen, Ihrem Betrieb und Ihren Arbeitsaufgaben passt.
<G-vec00179-001-s261><assemble.zusammenstellen><en> That's why you can assemble your testo Saveris 2 package, with the right loggers and the optimum Cloud licence yourself.
<G-vec00179-001-s261><assemble.zusammenstellen><de> Deshalb können Sie sich Ihr testo Saveris 2 Paket mit den passenden Loggern und der für Sie optimalen Cloud-Lizenz selbst zusammenstellen.
<G-vec00179-001-s262><assemble.zusammenstellen><en> By using libraries, it is possible to assemble geographic information, which can be reused for different maps (for different use cases).
<G-vec00179-001-s262><assemble.zusammenstellen><de> Mit Hilfe von Bibliotheken lassen sich geografische Informationen zusammenstellen, die in unterschiedlichen Karten (für unterschiedliche Anwendungsfälle) wiederverwendet werden können.
<G-vec00001-001-s270><assemble.zusammenstellen><en> For large projects such as book translations, we’ll assemble a small team of translators and editors.
<G-vec00001-001-s270><assemble.zusammenstellen><de> Bei großen Projekten wie Buchübersetzungen, stellen wir ein kleines Team an Übersetzern und Lektoren zusammen.
<G-vec00001-001-s271><assemble.zusammenstellen><en> We assemble interpreting teams perfectly suited to the mode of interpretation, relevant language pairs, and industry-specific vocabulary required for your event.
<G-vec00001-001-s271><assemble.zusammenstellen><de> Abgestimmt auf Dolmetschart, Fachgebiet und Sprachbedarf stellen wir die Teams in den entsprechenden Sprachpaaren für Ihre Veranstaltung zusammen.
<G-vec00001-001-s272><assemble.zusammenstellen><en> William Winder and his colleagues assemble each order with care and precision, and ensure that the goods are safely packaged for transport.
<G-vec00001-001-s272><assemble.zusammenstellen><de> Willi Wickler und seine Kollegen stellen alle Sendungen gewissenhaft zusammen und sorgen dafür, dass die Ware transportsicher verpackt ist.
<G-vec00001-001-s273><assemble.zusammenstellen><en> Furthermore we would be pleased to assemble individual arrangements for your seminar.
<G-vec00001-001-s273><assemble.zusammenstellen><de> Natürlich stellen wir Ihnen gerne ein individuelles Arrangement für Ihr Seminar zusammen.
<G-vec00001-001-s274><assemble.zusammenstellen><en> With its modular system you can assemble your colposcope individually for your personal application.
<G-vec00001-001-s274><assemble.zusammenstellen><de> Mit seinem Baukastensystem stellen Sie sich Ihr Kolposkop für Ihre persönliche Anwendung individuell zusammen.
<G-vec00001-001-s275><assemble.zusammenstellen><en> You assemble assessments – in your preferred diagram display – in personal dashboards, and you can receive an overview of your performance processes at any time.
<G-vec00001-001-s275><assemble.zusammenstellen><de> Auswertungen stellen Sie in Ihrer bevorzugten Diagrammdarstellung in persönlichen Dashboards zusammen und behalten zu jeder Zeit den Überblick über die Performance Ihrer Prozesse.
<G-vec00001-001-s276><assemble.treffen><en> Every year, DebConf allows new and existing Debian project participants from around the world to assemble, share knowledge, make collaborative contributions to Debian, and build tighter community bonds.
<G-vec00001-001-s276><assemble.treffen><de> Die DebConf ermöglicht es jedes Jahr, neuen und bestehenden Debian-Projektteilnehmern aus aller Welt, sich zu treffen, Wissen zu teilen, zusammen Beiträge zu Debian zu leisten und engere Bande in der Gemeinschaft zu knüpfen.
<G-vec00001-001-s277><assemble.treffen><en> 8.30 a.m. Participants assemble at the school and then walk to the woods with the children.
<G-vec00001-001-s277><assemble.treffen><de> 8.30 Uhr Treffen an der Schule, von dort wurde gemeinsam mit den Kindern in den Wald gewandert.
<G-vec00001-001-s278><assemble.treffen><en> These people will come from all over the world and assemble together even if the functions take place every month.
<G-vec00001-001-s278><assemble.treffen><de> Da kommen Leute aus aller Welt zu Treffen zusammen, selbst wenn die Veranstaltungen jeden Monat stattfinden.
<G-vec00001-001-s279><assemble.treffen><en> "Norton ordered all interested parties to assemble at Platt's Music Hall in San Francisco in February 1860 to ""remedy the evil complained of"".[29]"
<G-vec00001-001-s279><assemble.treffen><de> "Deshalb forderte der Kaiser ""alle interessierten Seiten"" zum Treffen in Platt's Music Hall in San Francisco im Februar 1860 auf, ""auf dass man das beklagte Übel bekämpfe""."
<G-vec00001-001-s299><assemble.versammeln><en> Baruch announces that the Messiah will assemble the peoples and confer life on those that submit to the descendants of Jacob, and wipe out the others, who have oppressed Israel.
<G-vec00001-001-s299><assemble.versammeln><de> Baruch verkündet, der Messias werde die Völker versammeln und jenen das Leben verleihen, die sich den Nachtkommen Jakobs nnterwerfen, die anderen vertilgen, die Israel unterdrückt haben.
<G-vec00001-001-s300><assemble.versammeln><en> Even some of Chávez's close allies recognize that until now he has failed to assemble a team with the skills and talents needed to tackle the difficult challenges facing his government.
<G-vec00001-001-s300><assemble.versammeln><de> Selbst Chávez' engste Verbündete geben zu, dass er es bisher versäumt hat, ein Team mit den Fähigkeiten und Talenten zu versammeln, die benötigt werden, um die schwierigen Herausforderungen zu meistern, die seine Regierung konfrontieren.
<G-vec00001-001-s301><assemble.versammeln><en> When this was done, we had to assemble and run.
<G-vec00001-001-s301><assemble.versammeln><de> Wenn das getan war, mussten wir uns versammeln und rennen.
<G-vec00001-001-s302><assemble.versammeln><en> 10:3 And when they shall blow with them, all the assembly shall assemble themselves to thee at the door of the tabernacle of the congregation.
<G-vec00001-001-s302><assemble.versammeln><de> 10:3 Wenn man mit beiden schlicht bläst, soll sich zu dir versammeln die ganze Gemeinde vor die Tür der Hütte des Stifts.
<G-vec00001-001-s303><assemble.versammeln><en> After a time, as the number of hearers increased, it was thought safer to assemble outside the city.
<G-vec00001-001-s303><assemble.versammeln><de> Als bald die Zahl seiner Zuhörer wuchs, hielt man es für sicherer, sich außerhalb der Stadt zu versammeln.
<G-vec00001-001-s304><assemble.versammeln><en> They maintain extensive areas wherein they assemble their pupils and from time to time make requisition on the celestial artisans and the reversion directors for the embellishment of their programs.
<G-vec00001-001-s304><assemble.versammeln><de> Sie unterhalten ausgedehnte Zonen, in denen sie ihre Schüler versammeln, und von Zeit zu Zeit fordern sie himmlische Künstler und Leiter der Rückschau an, um ihre Programme zu verschönern.
<G-vec00001-001-s305><assemble.versammeln><en> 4 Thus saith the LORD God of Israel; Behold, I will turn back the weapons of war that {are} in your hands, with which ye fight against the king of Babylon, and {against} the Chaldeans, who besiege you without the walls, and I will assemble them into the midst of this city.
<G-vec00001-001-s305><assemble.versammeln><de> 4 So spricht Jehova, der Gott Israels: Siehe, ich will die Kriegswaffen umwenden, die in eurer Hand sind, mit welchen ihr außerhalb der Mauer wider den König von Babel und wider die Chaldäer streitet, die euch belagern, und sie in diese Stadt hinein versammeln.
<G-vec00001-001-s306><assemble.versammeln><en> They do not now assemble in gymnasiums and academies, but in stock exchanges and markets. The speculations in which they are absorbed do not concern questions of truth and justice, but the prices of wool and whiskey, bonds and coupons.
<G-vec00001-001-s306><assemble.versammeln><de> Nicht in Gymnasien und Akademien versammeln sie sich, sondern auf Börsen und Märkten; die Spekulationen, in die sie versunken sind, betreffen nicht die Begriffe der Wahrheit und Gerechtigkeit, sondern Wolle und Schnaps, russische Anleihen und portugiesische Coupons.
<G-vec00001-001-s307><assemble.versammeln><en> Wedding atmosphere then prevails in both the families and women assemble and sing songs of marriage describing the valour of the boy and the beauty of the girl.
<G-vec00001-001-s307><assemble.versammeln><de> Wedding Atmosphäre herrscht dann sowohl in den Familien und Frauen versammeln und singen Lieder der Ehe beschreibt die Tapferkeit des Jungen und die Schönheit des Mädchens.
<G-vec00001-001-s308><assemble.versammeln><en> It is also dedicated to making a painting of everyday life in the society of the time, although the dramatic axis has to do with the players, the heroes of this story, and the misadventures that lived to train, meet and assemble the means to travel to Montevideo, faraway place then.
<G-vec00001-001-s308><assemble.versammeln><de> Es wird auch zur Erstellung einer Malerei des täglichen Lebens in der Gesellschaft der Zeit gewidmet, obwohl die dramatische Achse muss mit den Spielern, den Helden dieser Geschichte, und die Missgeschicke, die zu trainieren lebte tun, treffen und versammeln die Mittel, um reisen nach Montevideo, weit entfernten Ort dann.
<G-vec00001-001-s309><assemble.versammeln><en> In the late 1970s, while employed as an accountant with a crane manufacturer, I finally was able to assemble the idea notes related to rhythm and self-consciousness and some other subjects in a typed manuscript that was 135 single-spaced pages in length, including an appendix.
<G-vec00001-001-s309><assemble.versammeln><de> In den späten 1970er Jahren, während als Buchhalter mit einem Kran Hersteller beschäftigt, konnte ich schließlich auf die Idee versammeln Anmerkungen zu Rhythmus und Selbst-Bewusstsein im Zusammenhang und einige andere Themen in einer typisierten Manuskript, das 135 Seiten mit einfachem Zeilenabstand in Länge, einschließlich war ein Anhang.
<G-vec00001-001-s310><assemble.versammeln><en> (1) All Germans shall have the right to assemble peacefully and unarmed without prior notification or permission
<G-vec00001-001-s310><assemble.versammeln><de> (1) Alle Deutschen haben das Recht, sich ohne Anmeldung oder Erlaubnis friedlich und ohne Waffen zu versammeln.
<G-vec00001-001-s311><assemble.versammeln><en> "And although Satan and his two assistants send out their spirits to assemble the kings of the whole world with their armies there, it is in actual fact again God, who ""turns them about"" and leads them to Israel, as we can read here below, in Eze 39,2."
<G-vec00001-001-s311><assemble.versammeln><de> "Und obwohl Satan und seine zwei Gehilfen ihre Geister aussenden, um die Könige der ganzen Welt mit ihren Heeren dort zu versammeln, ist es in Wahrheit wieder Gott, der sie ""herumlenkt"" und sie nach Israel bringt, wie wir hier anschließend, in Hes 39,2 lesen können."
<G-vec00001-001-s312><assemble.versammeln><en> Or: we can all eat but we can eat like pigs or we can assemble in a civilized manner and eat our meal in style.
<G-vec00001-001-s312><assemble.versammeln><de> Oder: Wir können alle essen, aber man kann es den Schweinen ähnlich tun oder sich gesittet zu einem stilvollen Mahl versammeln.
<G-vec00001-001-s313><assemble.versammeln><en> In 1977, to commemorate the sixtieth anniversary of the last apparition, it was still possible to assemble in Fatima more than thirty persons who had been present at the solar prodigy and who could reveal their memories.
<G-vec00001-001-s313><assemble.versammeln><de> 1977 war es immer noch möglich, für die Kommemoration des sechzigsten Jahrestages der Erscheinungen, in Fatima mehr als dreißig Personen, die dem Sonnenwunder beigewohnt hatten und ihre Erinnerungen offenbaren konnten zu versammeln.
<G-vec00001-001-s314><assemble.versammeln><en> To do this, you need to fully assemble the whole picture in order to win this flash toy.
<G-vec00001-001-s314><assemble.versammeln><de> Dazu müssen Sie das ganze Bild zu versammeln, um in diesem Flash-Spielzeug zu gewinnen.
<G-vec00001-001-s315><assemble.versammeln><en> Four individuals were asked to assemble in an empty front room of a flat, the floor of which had been laid out as a grid, so that they could enact responses to each other, thus symbolising the process of group formation.
<G-vec00001-001-s315><assemble.versammeln><de> Vier Personen wurden gebeten, sich im leeren Vorderzimmer einer Wohnung zu versammeln, wobei der Zimmerboden mit einem Raster ausgelegt war, auf dem sie ihre Reaktion aufeinander austragen und damit den Prozeß der Gruppenbildung symbolisch darstellen konnten.
<G-vec00001-001-s317><assemble.versammeln><en> Judas requested the captain to assemble the guards and informed him that he was ready to lead them to Jesus.
<G-vec00001-001-s317><assemble.versammeln><de> Judas ersuchte den Hauptmann, die Wachen zu versammeln, und teilte ihm mit, dass er bereit sei, sie zu Jesus zu führen.
<G-vec00001-001-s318><assemble.sich_versammeln><en> Trinitized sons assigned to these worlds, together with the ascenders who have attained Paradise, assemble with the spirit personalities of the Third Source and Center in the reunions of the struggles and triumphs of the ascendant career.
<G-vec00001-001-s318><assemble.sich_versammeln><de> Diesen Welten zugeteilte trinitisierte Söhne zusammen mit Aufsteigern, die das Paradies erreicht haben, versammeln sich mit den Geistper­sön­lichkeiten des Dritten Zentralen Ursprungs an Treffen, die die Kämpfe und Triumphe der aufsteigenden Laufbahn zum Gegenstand haben.
<G-vec00001-001-s319><assemble.sich_versammeln><en> The evil X-Hunters assemble in Mega Man X2, focused on destroying X and claiming Zero for their own destructive deeds.
<G-vec00001-001-s319><assemble.sich_versammeln><de> Die bösen X-Jäger versammeln sich in Mega Man X2 und versuchen, X zu zerstören und Zero für ihre dunklen Machenschaften zu rekrutieren.
<G-vec00001-001-s320><assemble.sich_versammeln><en> When it is time for the meeting, attendees assemble around a “virtual” semi-circular table in a Cisco TelePresence room equipped for video conferencing.
<G-vec00001-001-s320><assemble.sich_versammeln><de> "Zum Zeitpunkt der Konferenz versammeln sich die Teilnehmer um einen ""virtuellen"" halbrunden Tisch in einem für Videokonferenzen ausgestatteten Cisco TelePresence-Raum."
<G-vec00001-001-s321><assemble.sich_versammeln><en> The curious, sceptics and those who have always held the very real legend of the Gratzug in due respect will assemble for the full moon.
<G-vec00001-001-s321><assemble.sich_versammeln><de> Bei Vollmond versammeln sich die Neugierigen, die Ungläubigen und alle, die es schon immer wussten, um in ehrfürchtiger Stille der fleisch gewordenen Sage des Gratzuges beizuwohnen.
<G-vec00001-001-s322><assemble.versammeln><en> 31:28 Assemble before me all the elders of your tribes and all your officials, so that I can speak these words in their hearing and call heaven and earth to testify against them.
<G-vec00001-001-s322><assemble.versammeln><de> 31:28 Versammelt vor mir alle Ältesten eurer Stämme und eure Amtleute, daß ich diese Worte vor ihren Ohren rede und Himmel und Erde wider sie zu Zeugen nehme.
<G-vec00001-001-s323><assemble.versammeln><en> And in my view, it's also important for us to assemble a good blend of skills and experience on our Executive Board.
<G-vec00001-001-s323><assemble.versammeln><de> Dabei ist es aus meiner Sicht auch wichtig, dass wir eine gute Kombination von Fähigkeiten und Erfahrungen im Vorstand versammelt haben.
<G-vec00001-001-s324><assemble.versammeln><en> """The 30,000 Jews who assembled [in Kyiv] were taken to the forest and slaughtered over the course of two days. "" Leni Yahil does not name witnesses, nor does she give an explanation and/or evidence for how it was possible to assemble and lead off more than 30,000 people within a few hours, without thousands of people noticing and potentially appearing as witnesses later."
<G-vec00001-001-s324><assemble.versammeln><de> »Die 30.000 Juden, die sich [in Kiew] versammelten, wurden in den Wald geführt und dort [von den Deutschen] im Laufe von zwei Tagen abgeschlachtet.« Leni Yahil nennt weder Zeugen noch produziert sie Erklärungen und/oder Beweise, wie man mehr als 30.000 Menschen innerhalb von Stunden versammelt und abführt, ohne daß dies Tausenden auffällt, die später als Zeugen hätten auftreten können.
<G-vec00001-001-s325><assemble.versammlen><en> "4:10 Remember the day you stood before the LORD your God at Horeb, when he said to me, ""Assemble the people before me to hear my words so that they may learn to revere me as long as they live in the land and may teach them to their children."""
<G-vec00001-001-s325><assemble.versammlen><de> 4:10 den Tag, da du vor dem HERRN, deinem Gott, standest am Berge Horeb, da der HERR zu mir sagte: Versammle mir das Volk, daß sie meine Worte hören und lernen mich fürchten alle ihre Lebtage auf Erden und lehren ihre Kinder.
<G-vec00001-001-s326><assemble.versammlen><en> "3 and assemble all the congregation at the doorway of the tent of meeting."""
<G-vec00001-001-s326><assemble.versammlen><de> 3 und versammle die ganze Gemeinde vor dem Eingang der Stiftshütte.
<G-vec00001-001-s327><assemble.versammlen><en> 16 And from thence to Beer: that is the well of which Jehovah spoke to Moses, Assemble the people, and I will give them water.
<G-vec00001-001-s327><assemble.versammlen><de> 16 Und von dort zogen sie nach Beer; (Brunnen) das ist der Brunnen, von welchem Jehova zu Mose sprach: Versammle das Volk, und ich will ihnen Wasser geben.
<G-vec00001-001-s328><assemble.versammlen><en> 31:12 Assemble the people, the men and the women and the little ones, and your foreigner who is within your gates, that they may hear, and that they may learn, and fear Yahweh your God, and observe to do all the words of this law;
<G-vec00001-001-s328><assemble.versammlen><de> 31:12 Versammle das Volk, die Männer und die Weiber und die Kindlein, und deinen Fremdling, der in deinen Toren ist; auf daß sie hören, und auf daß sie lernen, und Jehova, euren Gott, fürchten und darauf achten, alle Worte dieses Gesetzes zu tun.
<G-vec00179-001-s325><assemble.versammeln><en> "4:10 Remember the day you stood before the LORD your God at Horeb, when he said to me, ""Assemble the people before me to hear my words so that they may learn to revere me as long as they live in the land and may teach them to their children."""
<G-vec00179-001-s325><assemble.versammeln><de> 4:10 den Tag, da du vor dem HERRN, deinem Gott, standest am Berge Horeb, da der HERR zu mir sagte: Versammle mir das Volk, daß sie meine Worte hören und lernen mich fürchten alle ihre Lebtage auf Erden und lehren ihre Kinder.
<G-vec00179-001-s326><assemble.versammeln><en> "3 and assemble all the congregation at the doorway of the tent of meeting."""
<G-vec00179-001-s326><assemble.versammeln><de> 3 und versammle die ganze Gemeinde vor dem Eingang der Stiftshütte.
<G-vec00179-001-s327><assemble.versammeln><en> 16 And from thence to Beer: that is the well of which Jehovah spoke to Moses, Assemble the people, and I will give them water.
<G-vec00179-001-s327><assemble.versammeln><de> 16 Und von dort zogen sie nach Beer; (Brunnen) das ist der Brunnen, von welchem Jehova zu Mose sprach: Versammle das Volk, und ich will ihnen Wasser geben.
<G-vec00179-001-s328><assemble.versammeln><en> 31:12 Assemble the people, the men and the women and the little ones, and your foreigner who is within your gates, that they may hear, and that they may learn, and fear Yahweh your God, and observe to do all the words of this law;
<G-vec00179-001-s328><assemble.versammeln><de> 31:12 Versammle das Volk, die Männer und die Weiber und die Kindlein, und deinen Fremdling, der in deinen Toren ist; auf daß sie hören, und auf daß sie lernen, und Jehova, euren Gott, fürchten und darauf achten, alle Worte dieses Gesetzes zu tun.
<G-vec00001-001-s348><assemble.zusammenbauen><en> Use this interactive software tool to build and assemble ANSI/ISA 76.00.02-compliant miniature modular designs, including complete bills of materials and assembly schematics.
<G-vec00001-001-s348><assemble.zusammenbauen><de> Verwenden Sie dieses interaktive Software Tool, zum Bau und Zusammenbau von ANSI/ISA 76.00.02-kompatiblen modularen Designs, darunter auch Stücklisten und Baupläne.
<G-vec00001-001-s349><assemble.zusammenbauen><en> A kit scientific with which to assemble a real compass and learn how to work this instrument of antiquity.
<G-vec00001-001-s349><assemble.zusammenbauen><de> Ein kit, das wissenschaftliche mit dem zusammenbau eine wahre kompass und entdecken sie, wie funktioniert dieses instrument der antike.
<G-vec00001-001-s350><assemble.zusammenbauen><en> Warning At least one other person must help you assemble the stand.
<G-vec00001-001-s350><assemble.zusammenbauen><de> Bitten Sie mindestens eine Person, Ihnen beim Zusammenbau des Ständers zu helfen.
<G-vec00001-001-s351><assemble.zusammenbauen><en> This game, measuring 122 x 91 x 91 centimeters, the box contains everything you need to assemble with ease the door from football, trained with your father and with your friends to become a true champion.
<G-vec00001-001-s351><assemble.zusammenbauen><de> Dieses tor, maße 122 x 91 x 91 cm, scatolo enthält alles notwendige für den zusammenbau mit leichtigkeit die tür von fußball, trainierte sie mit ihrem vater und mit ihren freunden, um ein champion zu werden.
<G-vec00001-001-s352><assemble.zusammenbauen><en> 1 top unit 48 left and 1 top unit 48 right are required to assemble a Triplex brace.
<G-vec00001-001-s352><assemble.zusammenbauen><de> Zum Zusammenbau werden je ein Kopfstück 48 links und ein Kopfstück 48 rechts benötigt.
<G-vec00001-001-s353><assemble.zusammenbauen><en> Choose from an expansive roster of classic characters straight out of the best SNK games, assemble the ultimate tag team and chain-up your fighters’ special move in battle to unleash devastating combos onto your challengers.Unlock, recruit and collect fighters from a roster of 70+, including fan-favorite Terry Bogart, Kyo Kusanagi, Iori Yagami, Mai Shiranui and many more.
<G-vec00001-001-s353><assemble.zusammenbauen><de> Wählen Sie aus einer expansiven Liste von klassischen Charaktere direkt aus den besten SNK-Spiele, zusammenbauen das ultimative Tag-Teams und Kette-up Ihrer Kämpfer besondere Bewegung im Kampf verheerende Kombos auf Ihre challengers.Unlock zu entfesseln, rekrutieren und sammeln Kämpfer aus einer Liste von 70+, einschließlich Fan-Liebling Terry Bogart, Kyo Kusanagi, Iori Yagami, Mai Shiranui und viele mehr.
<G-vec00001-001-s354><assemble.zusammenbauen><en> "Upon a promontory near the sea, in the midst of wild gorges and desolate hills, the people have raised up a shrine to the Madonna, and this "" Panaghia "" is not only beautiful and enticing from its loneliness, but a place to which they carry their vows and their hopes, and where they assemble twice a year for a holiday, sleeping within its precincts."
<G-vec00001-001-s354><assemble.zusammenbauen><de> "Nach einem Vorgebirge nahe dem Meer, in der Mitte von wilden Schluchten und desolate Hügel, die Leute haben herauf ein shrine zum Madonna angehoben, und dieses ""Panaghia"" ist nicht nur schön und verleitend von seiner Einsamkeit, aber zu der ein Platz sie ihre Versprechen und ihre Hoffnungen tragen, und von wo sie zweimal jährlich für einen Feiertag zusammenbauen und innerhalb seiner Bezirke schlafen."
<G-vec00001-001-s355><assemble.zusammenbauen><en> A:Yes,most of our furniture are assemble.
<G-vec00001-001-s355><assemble.zusammenbauen><de> A: Ja sind die meisten unserer Möbel zusammenbauen.
<G-vec00001-001-s356><assemble.zusammenbauen><en> While the „elder“ kids learned about the company and the products during a company tour and visited the workplace of their parent, the younger ones were allowed to assemble a tractor or a solar wind wheel themselves in the apprentices‘ workshop.
<G-vec00001-001-s356><assemble.zusammenbauen><de> Während die „Älteren“ bei einem Betriebsrundgang die Firma und Produkte kennenlernten und an den Arbeitsplätzen des Elternteils vorbeischauten, durften die „Kleinen“ in der Ausbildungswerkstatt einen Traktor oder ein Solarwindrad selber zusammenbauen.
<G-vec00001-001-s357><assemble.zusammenbauen><en> 7.2 Assemble Valve (see Fig.
<G-vec00001-001-s357><assemble.zusammenbauen><de> 7.2 Ventil zusammenbauen (siehe Abb.
<G-vec00001-001-s358><assemble.zusammenbauen><en> It consists of 19 individually placeable models with which you have carried your one work site to assemble.
<G-vec00001-001-s358><assemble.zusammenbauen><de> Er besteht aus 19 einzeln platzierbaren Modellen, mit denen Ihr Euch eine Einsatzstelle zusammenbauen könnt.
<G-vec00001-001-s359><assemble.zusammenbauen><en> Footboard adjustable pedal on the bottom,to assemble and disassemble gas cylinder conveniently.
<G-vec00001-001-s359><assemble.zusammenbauen><de> Footboard verstellbares Pedal auf der Unterseite, Gasflasche bequem zusammenbauen und auseinanderbauen.
<G-vec00001-001-s360><assemble.zusammenbauen><en> In relation to the kits, we also offer workshops and team events in which you can make your music stool assemble together.
<G-vec00001-001-s360><assemble.zusammenbauen><de> Im Zusammenhang zu den Bausätzen bieten wir Ihnen auch Workshops und Team-Events an, bei dem Sie gemeinsam Ihren Musikhocker zusammenbauen können.
<G-vec00001-001-s361><assemble.zusammenbauen><en> These designs include simple detachments of parts to clean, wipe, and after that assemble again to make another round of hot cocoa.
<G-vec00001-001-s361><assemble.zusammenbauen><de> Diese Designs sind einfachere Abordnungen der Teile zu reinigen, wischen und danach wieder zusammenbauen um eine weitere Runde heißen Kakao zu machen.
<G-vec00001-001-s362><assemble.zusammenbauen><en> When the unassembled cold room arrives, users can easily assemble and install the cold rooms by themselves.
<G-vec00001-001-s362><assemble.zusammenbauen><de> Wenn der demontierte Kühlraum ankommt, können Benutzer die Kühlräume leicht zusammenbauen und selbst installieren.
<G-vec00001-001-s363><assemble.zusammenbauen><en> Students who complete this course will be able to describe the internal components of a computer, assemble a computer system, install an operating system, and troubleshoot using system tools and diagnostic software.
<G-vec00001-001-s363><assemble.zusammenbauen><de> Die Studenten, die diesen Kurs absolvieren in der Lage, die internen Komponenten eines Computers zu beschreiben, zusammenbauen ein Computersystem, ein Betriebssystem installieren, und Behandeln von Problemen mit System-Tools und Diagnosesoftware.
<G-vec00001-001-s364><assemble.zusammenbauen><en> But when you consider China's imports in a different way the numbers change dramatically: a more integrated global supply chain means that many countries, particularly China, simply import components of a product, assemble it in a factory and then re-export it to another country for further work or sale.
<G-vec00001-001-s364><assemble.zusammenbauen><de> Betrachtet man jedoch die chinesischen Importe aus einem anderen Blickwinkel, verändern sich die Zahlen dramatisch: Eine stärker miteinander verflochtene globale Versorgungskette bedeutet, dass viele Länder – insbesondere China – einfach Komponenten eines Produkts importieren, es in einer Fabrik zusammenbauen und dann in ein anderes Land exportieren, in dem es weiterbearbeitet oder verkauft wird.
<G-vec00001-001-s365><assemble.zusammenbauen><en> With Uniqlo's video wall requirements in mind, Allen stated, “Once a store build out is ready for its video wall, we ship out the basic video wall frames which are received by the installation crew, who then assemble and install the video wall frame onto wall anchors.
<G-vec00001-001-s365><assemble.zusammenbauen><de> Mit Uniqlo Videowand Anforderungen im Verstand, erklärte Allen, „sobald ein Laden bau heraus zu seiner Videowand bereit ist, wir versenden heraus die grundlegenden Videowand Rahmen, die von der Installation Mannschaft empfangen werden, das dann den Videowand Rahmen auf Wandanker zusammenbauen und anbringen.
<G-vec00001-001-s366><assemble.zusammenbauen><en> Anyone who wants to can now produce their own vehicle in a factory on the “Second Life” Internet platform. They can program the industrial robots, and transport and assemble the individual parts themselves. Learning platforms provide relevant background information.
<G-vec00001-001-s366><assemble.zusammenbauen><de> Das eigene Fahrzeug selbst produzieren, die Industrieroboter entsprechend programmieren, Einzelteile lackieren, transportieren und zusammenbauen – das können Interessierte nun in einer Fabrik auf der Internetplattform »Second Life«.
<G-vec00001-001-s367><assemble.zusammenbauen><en> It can automatically assemble the syringe barrel, syringe plunger and syringe gasket together.
<G-vec00001-001-s367><assemble.zusammenbauen><de> Es kann automatisch den Spritzenzylinder, den Spritzenkolben und die Spritzendichtung zusammenbauen.
<G-vec00001-001-s368><assemble.zusammenbauen><en> We land at a rough pier, the Communists wet to the skin assemble in a group, the tips of their cigarettes glowing in the general dark.
<G-vec00001-001-s368><assemble.zusammenbauen><de> Wir landen an einem rauhen Pier, travel Kommunisten, travel zur Haut naß sind, zusammenbauen in einer Gruppe, travel Spitzen ihrer Zigaretten, travel in travel allgemeine Dunkelheit glühen.
<G-vec00001-001-s369><assemble.zusammenbauen><en> Children can assemble the drone with all parts by themselves.
<G-vec00001-001-s369><assemble.zusammenbauen><de> Kinder können die Drohne mit allen Teilen selbst zusammenbauen.
<G-vec00001-001-s370><assemble.zusammenbauen><en> The GHOST - Papa Emeritus II rod DLX consists of 3 parts to assemble.
<G-vec00001-001-s370><assemble.zusammenbauen><de> Der GHOST - Papa Emeritus II Stab DLX besteht aus 3 Teilen zum zusammenbauen.
<G-vec00001-001-s371><assemble.zusammenbauen><en> Only if you are an experienced user you may assemble the A-100 system by yourself.
<G-vec00001-001-s371><assemble.zusammenbauen><de> Nur falls Sie über ausreichend Erfahrung verfügen, sollten Sie Ihr A-100-System selbst zusammenbauen.
<G-vec00001-001-s372><assemble.zusammenbringen><en> I will surely assemble all of you, Jacob, I will surely gather the remnant of Israel.
<G-vec00001-001-s372><assemble.zusammenbringen><de> Der Herr wird Jakob sammeln und, was übrig ist von Israel, zusammenbringen.
<G-vec00001-001-s373><assemble.zusammenbringen><en> 11:17 Therefore say, Thus saith the Lord GOD; I will even gather you from the people, and assemble you out of the countries where ye have been scattered, and I will give you the land of Israel.
<G-vec00001-001-s373><assemble.zusammenbringen><de> 17 Darum sage: So spricht der Herr, HERR: Ich werde euch aus den Völkern sammeln und euch aus den Ländern zusammenbringen, in die ihr zerstreut worden seid, und werde euch das Land Israel geben.
<G-vec00001-001-s374><assemble.zusammenbringen><en> 17 Therefore say, 'Thus says the Lord GOD: I will gather you from the peoples and assemble you out of the countries where you have been scattered, and I will give you the land of Israel.'
<G-vec00001-001-s374><assemble.zusammenbringen><de> 17 Darum sage: So spricht der Herr, HERR: Ich werde euch aus den Völkern sammeln und euch aus den Ländern zusammenbringen, in die ihr zerstreut worden seid, und werde euch das Land Israel geben.
<G-vec00001-001-s375><assemble.zusammenfügen><en> In the case of chlorotrinitromethane, this effect is particularly pronounced and leads to an unusually short chlorine-carbon bond. However, it could be of importance in various other cases, especially in areas, where molecules recognize one another and assemble to larger structures.
<G-vec00001-001-s375><assemble.zusammenfügen><de> Im Fall von Chlorotrinitromethan ist dieser Effekt besonders ausgeprägt und führt zu einem ungewöhnlich kurzen Chlor-Kohlenstoff-Abstand, er könnte aber für vielfältige weitere Fälle von Bedeutung sein - insbesondere in Bereichen, wo Moleküle sich selbständig gegenseitig erkennen und zu größeren Strukturen zusammenfügen.
<G-vec00001-001-s376><assemble.zusammenfügen><en> Indoor Led video wall 's High artistry and creativity can assemble different shapes.
<G-vec00001-001-s376><assemble.zusammenfügen><de> Die hohe Kunstfertigkeit und Kreativität der Indoor-LED-Videowand kann verschiedene Formen zusammenfügen.
<G-vec00001-001-s377><assemble.zusammenfügen><en> Q: (L) It's almost as much fun to be learning the things I am having to assemble as if I were reading it.
<G-vec00001-001-s377><assemble.zusammenfügen><de> F: Das Lernen all dieser Dinge, die ich zusammenfügen muss, macht fast soviel Spaß, als ob ich sie lesen würde.
<G-vec00001-001-s378><assemble.zusammenfügen><en> The tubular rivet creates a mechanical joint; this kind of rivet is usually used to assemble metal sheets or composite materials.
<G-vec00001-001-s378><assemble.zusammenfügen><de> Der Hohlniet schafft eine mechanische Verbindung und wird für das Zusammenfügen von Metallblechen und für Verbundmaterialien verwendet.
<G-vec00001-001-s379><assemble.zusammenfügen><en> As we did not read the Cyrillic alphabet, we had to slow down for the road signs so I could look in my notebook and assemble the correct letter combinations.
<G-vec00001-001-s379><assemble.zusammenfügen><de> Da wir das kyrillische Alphabet nicht lesen konnten, mussten wir bei Verkehrsschildern abbremsen, so dass ich in meinem Notizbuch nachschauen und die korrekte Buchstabenkombination zusammenfügen konnte.
<G-vec00001-001-s380><assemble.zusammenfügen><en> Should it be necessary to enclose larger objects, then you can easily assemble the sheets of several mold kits into a larger pouring box.
<G-vec00001-001-s380><assemble.zusammenfügen><de> Sollte es erforderlich sein, größere Objekte zu umschließen, so kann man die Bleche mehrerer Formbaurahmen zu einem größeren Gießkasten problemlos zusammenfügen.
<G-vec00001-001-s381><assemble.zusammenfügen><en> Manufacturers can assemble a train quickly from already existing modular elements.
<G-vec00001-001-s381><assemble.zusammenfügen><de> So können Hersteller einen Zug schnell aus bereits bestehenden Elementen und Modulen im Baukastenprinzip zusammenfügen.
<G-vec00001-001-s382><assemble.zusammenfügen><en> This tutorial will teach you how to slice your 3D model into 2D laser cut parts and then assemble them together into amazing 3D structures.
<G-vec00001-001-s382><assemble.zusammenfügen><de> In diesem Tutorial lernen Sie, wie Sie Ihr 3D-Modell in 2D-Laserschnittteile zerlegen und sie dann zu erstaunlichen 3D-Strukturen zusammenfügen.
<G-vec00001-001-s383><assemble.zusammensetzen><en> It took him four years to cut and assemble the 3700 pieces.
<G-vec00001-001-s383><assemble.zusammensetzen><de> Es hat 4 Jahre gedauert, und er hat in dieser Zeit 3700 Teile zusammengesetzt.
<G-vec00001-001-s384><assemble.zusammensetzen><en> Special feature: Using the V system, it was possible to build the bridge structure without any intermediate supports and assemble it completely on site.
<G-vec00001-001-s384><assemble.zusammensetzen><de> Besonderheit: Die Brückenkonstruktion konnte durch Verwendung des Systems V ohne Zwischenstützen realisiert werden und wurde komplett vor Ort zusammengesetzt.
<G-vec00001-001-s385><assemble.zusammensetzen><en> It takes 14 weeks to assemble a Boeing 777 from 3 million separate parts.
<G-vec00001-001-s385><assemble.zusammensetzen><de> 14 Wochen dauert es, bis eine Boeing 777 aus rund drei Millionen Einzelteilen zusammengesetzt ist.
<G-vec00001-001-s386><assemble.zusammenstellen><en> You can assemble production lines including up to 20 networked winding positions from these frames.
<G-vec00001-001-s386><assemble.zusammenstellen><de> Aus diesen Gestellen können Produktionslinien mit bis zu 20 vernetzten Spulstellen zusammengestellt werden.
<G-vec00001-001-s387><assemble.zusammenstellen><en> Southern Lithium Corp. has managed to assemble an experienced management team with a growth strategy to develop a diversified portfolio of projects.
<G-vec00001-001-s387><assemble.zusammenstellen><de> Southern Lithium Corp. hat ein erfahrenes Management-Team mit einer Wachstumsstrategie zusammengestellt, um ein diversifiziertes Projekt-Portfolio zu erstellen.
<G-vec00001-001-s388><assemble.zusammenstellen><en> Above 3,2 m width we assemble the tanks on the spot.
<G-vec00001-001-s388><assemble.zusammenstellen><de> Über 3,2 m Breite das Behälter wird am Ort zusammengestellt.
<G-vec00001-001-s389><assemble.zusammenstellen><en> For every project, we identify the best technologies and assemble optimally cohesive and efficient teams from our pool of highly qualified software developers.
<G-vec00001-001-s389><assemble.zusammenstellen><de> Für jedes Projekt werden die geeignetsten Technologien bestimmt und ein Team aus unserem Pool von hochqualifizierten Softwareentwicklerinnen und Softwareentwicklern zusammengestellt.
<G-vec00001-001-s390><assemble.zusammenstellen><en> “As a general rule, we assemble bespoke packages for customers,” explains Wolfgang Goeke, the person responsible for sales at AFS.
<G-vec00001-001-s390><assemble.zusammenstellen><de> „Grundsätzlich werden für den Kunden individuelle Pakete zusammengestellt“, erklärt Wolfgang Goeke, bei der AFS zuständig für den Vertrieb.
<G-vec00001-001-s391><assemble.zusammenkommen><en> Normally, when we talk about democracy, we think of the nation state, but there is potential for democracy everywhere that people assemble or live together.
<G-vec00001-001-s391><assemble.zusammenkommen><de> Wenn wir von Demokratie sprechen, denken wir oft an den Nationalstaat, aber überall wo Menschen zusammenkommen oder zusammenleben ist es möglich und oft notwendig demokratisch zu handeln.
<G-vec00001-001-s392><assemble.zusammenkommen><en> Friday night graduations are another Scientology tradition—a time when Church staff and parishioners assemble to acknowledge those who have completed auditing or training steps in the previousweek.
<G-vec00001-001-s392><assemble.zusammenkommen><de> Die Freitagabend-Graduierungen stellen eine weitere Scientology Tradition dar – eine Zeit, in der hauptamtliche Mitglieder der Kirche und Gemeindemitglieder zusammenkommen, um diejenigen zu bestätigen, die in der vergangenen Woche einen Auditing- oder Ausbildungs-Schritt abgeschlossenhaben.
<G-vec00001-001-s393><assemble.zusammenkommen><en> "Using the concept of ""An event where the disabled from the world over assemble in one place, and through the shared culture of sports expand the spirit of friendship and international goodwill, and are able to find new possibilities nourished by dreams and courage"" as our central theme, we welcomed the athletes of each country by burning hinoki incense at the athlete entrance and within the field during the opening ceremonies, welcoming them with fragrances suited to the location of the event."
<G-vec00001-001-s393><assemble.zusammenkommen><de> "Mit dem Konzept ""eine Veranstaltung, wo Behinderte aus aller Welt an einem Ort zusammenkommen, den Geist von Freundschaft und internationalem Wohlwollen durch die gemeinsame Kultur von Sport vertiefen und neue Möglichkeiten finden, die durch Träume und Mut genährt werden"" als zentrales Thema hießen wir die Athleten aus allen Ländern durch das Abbrennen von Weihrauch am Athleteneingang und auf dem Feld während der Eröffnungszeremonie willkommen mit Düften, die sich nahtlos in den Ort der Veranstaltung einfügten."
<G-vec00001-001-s394><assemble.zusammenkommen><en> Spectators were able to receive a program, assemble in a common space, and watch a play by Shakespeare.
<G-vec00001-001-s394><assemble.zusammenkommen><de> Die Zuschauer konnten ein Programm erhalten, in einem gemeinsamen Raum zusammenkommen und ein Stück von Shakespeare ansehen.
<G-vec00001-001-s395><assemble.zusammenkommen><en> We will assemble right here at Sky Rock.
<G-vec00001-001-s395><assemble.zusammenkommen><de> Wir werden genau hier auf dem Himmelsfelsen zusammenkommen.
<G-vec00001-001-s396><assemble.zusammensetzen><en> Fortunately, the Philips AVENT electric breast pump is easy to assemble and use so you will soon get used to expressing with it.
<G-vec00001-001-s396><assemble.zusammensetzen><de> Glücklicherweise lässt sich die elektrische Philips AVENT Milchpumpe einfach zusammensetzen und verwenden, sodass Sie sich schnell an das Abpumpen gewöhnen werden.
<G-vec00001-001-s397><assemble.zusammensetzen><en> But separate petals of the fiery Lotus can be seen, and in accordance with them let us assemble the entire flower.
<G-vec00001-001-s397><assemble.zusammensetzen><de> Doch einzelne Blütenblätter des feurigen Lotos können gesehen werden, und ihnen gemäß laßt uns die ganze Blume zusammensetzen.
<G-vec00001-001-s398><assemble.zusammensetzen><en> Children from about 14 years of age can assemble this level 5 kit, which consists of 93 individual parts, largely without outside help.
<G-vec00001-001-s398><assemble.zusammensetzen><de> Kinder ab etwa 14 Jahren können diesen Bausatz des Levels 5, der aus 93 Einzelteilen besteht, weitgehend ohne fremde Hilfe zusammensetzen.
<G-vec00001-001-s399><assemble.zusammensetzen><en> "In the data division of this CD (not in this Online version) you can find a functional demo version of the program WIN AUDIO with which you can assemble the "" building blocks "" as desired to a song."
<G-vec00001-001-s399><assemble.zusammensetzen><de> "Im Daten-Teil dieser CD (nicht in dieser Online-Version) finden Sie eine funktionsfähige Demo-Version des WIN AUDIO Programmes, mit dem Sie die „Bausteine"" nach Belieben zu einem Song zusammensetzen können."
<G-vec00001-001-s400><assemble.zusammensetzen><en> Due to the ease of use of LabVIEW, engineers who normally would not use industrial robotics now can integrate them into their applications to automate laboratories, precisely assemble components and test complex parts.
<G-vec00001-001-s400><assemble.zusammensetzen><de> Da LabVIEW sehr intuitiv zu handhaben ist, können auch Anwender, die noch keine Erfahrungen mit Industrierobotern haben, diese in ihre Applikationen integrieren und damit Labore automatisieren, Komponenten präzise zusammensetzen und komplexe Bauteile prüfen.
<G-vec00001-001-s401><assemble.zusammensetzen><en> The same is true for the small facility in which they could assemble a warhead or a nuclear device that could be placed in a container ship.
<G-vec00001-001-s401><assemble.zusammensetzen><de> Gleiches gilt auch für die kleine Fabrik, in der man einen Sprengkopf oder einen nuklearen Apparat zusammensetzen könnte, der in ein Containerschiff passen würde.
<G-vec00001-001-s402><assemble.zusammensetzen><en> R-Studio can automatically recognize and assemble the components of these disk managers even if their databases are slightly damaged.
<G-vec00001-001-s402><assemble.zusammensetzen><de> R-Studio kann die Komponenten dieser Datenträger-Manager automatisch erkennen und zusammensetzen, selbst wenn ihre Datenbanken leicht beschädigt sind.
<G-vec00001-001-s403><assemble.zusammensetzen><en> In one of our partner's private workshops, guests may participate in the manufacture of a watch by discovering, selecting and helping to assemble watch pieces under the guidance of a master watchmaker.
<G-vec00001-001-s403><assemble.zusammensetzen><de> In der privaten Werkstatt eines unserer Partner können sie unter der Anleitung eines Uhrmachermeisters die Teile einer Uhr wählen, öffnen, entdecken und zusammensetzen.
<G-vec00001-001-s404><assemble.zusammensetzen><en> You can either buy a complete, ready-built detached house, or you can buy the individual bricks and assemble something completely new.
<G-vec00001-001-s404><assemble.zusammensetzen><de> Man kann ein komplettes, fertiges Einfamilienhaus kaufen oder man kann einzelne Bausteine kaufen und zu etwas ganz Neuem zusammensetzen.
<G-vec00001-001-s405><assemble.zusammensetzen><en> Fortunately, the Philips AVENT manual breast pump is easy to assemble and use so you will soon get used to expressing with it.
<G-vec00001-001-s405><assemble.zusammensetzen><de> GlÃ1⁄4cklicherweise lässt sich die Philips AVENT Handmilchpumpe einfach zusammensetzen und verwenden, sodass Sie sich schnell an das Abpumpen gewöhnen werden.
<G-vec00001-001-s406><assemble.zusammensetzen><en> Today, a significant proportion of our orders are comprised of various appliances, the components of which we not only manufacture but assemble, too.
<G-vec00001-001-s406><assemble.zusammensetzen><de> Heute besteht bereits ein beträchtlicher Anteil unserer Aufträge aus verschiedenen Geräten, deren Teile wir nicht nur fertigen sondern auch zusammensetzen.
<G-vec00001-001-s407><assemble.zusammensetzen><en> Separate the scenes out and work them piecemeal as you assemble the larger overall work.
<G-vec00001-001-s407><assemble.zusammensetzen><de> Trennen Sie die Szenen und arbeiten Sie Stück für Stück, während Sie die größere Gesamtarbeit zusammensetzen.
<G-vec00001-001-s408><assemble.zusammenstellen><en> The pictograms described for the eras can also be found by the models so that you can assemble prototypical trains from an era is question.
<G-vec00001-001-s408><assemble.zusammenstellen><de> Die beschriebenen Piktogramme der Epochen finden Sie auch bei den Modellen, so daß Sie sich vorbildgerechte Züge aus der jeweiligen Zeit zusammenstellen können.
<G-vec00001-001-s409><assemble.zusammenstellen><en> Creating and testing manufacturing processes on a PC– this is easy in the CIROS®virtual factory environment. Assemble a production line from the module library, create the matching MES project with one mouse click, enter the process parameters and start the process. The 3D simulation now clearly illustrates the procedure, with real robot programmes running in the simulated robots.
<G-vec00001-001-s409><assemble.zusammenstellen><de> Fertigungsprozesse konzipieren und erproben am PC – in der virtuellen Fabrikumgebung von CIROS®kein Problem:aus der Modulbibliothek die Fertigungslinie zusammenstellen, das dazu passende MES-Projekt per Mausklick erstellen, Prozessparameter eintragen und den Prozess starten.Die 3D-Simulation zeigt nun anschaulich den Ablauf, wobei in den simulierten Robotern reale Roboterprogramme ablaufen.
<G-vec00001-001-s410><assemble.zusammenstellen><en> McClelland processed the core for assaying and will assemble the composites for the metallurgical program described above .
<G-vec00001-001-s410><assemble.zusammenstellen><de> McClelland bereitete die Bohrkerne für die Analyse vor und wird die Erzmischungen für das oben beschriebene metallurgische Programm zusammenstellen.
<G-vec00001-001-s411><assemble.zusammenstellen><en> With the configurator for RAID and NAS you can assemble your system individually and ask a quotation.
<G-vec00001-001-s411><assemble.zusammenstellen><de> Mit dem Konfigurator für RAID und NAS können Sie Ihr System individuell zusammenstellen und ein Angebot anfordern.
<G-vec00001-001-s412><assemble.zusammenstellen><en> Alien Attack Team 2: Aliens have assaulted Earth so its up to you to assemble your squad and defend the human race with your alien attack team.
<G-vec00001-001-s412><assemble.zusammenstellen><de> Alien Attack-Team 2: Aliens haben die Erde angegriffen, also sein bis Sie Ihren Kader zusammenstellen und verteidigen die menschliche Rasse mit Ihrem Alien attack Team.
<G-vec00001-001-s413><assemble.zusammenstellen><en> You're almost there... just assemble the prepared parts.
<G-vec00001-001-s413><assemble.zusammenstellen><de> Fast geschafft... Wir müssen nur noch die vorbereiteten Teile zusammenstellen.
<G-vec00001-001-s414><assemble.zusammenstellen><en> This allows you to assemble a double dildo or double plug according to your own wishes and combine additional clip-on toys with each other.
<G-vec00001-001-s414><assemble.zusammenstellen><de> So kann man einen Doppeldildo oder Doppel-Plug ganz nach Wunsch selbst zusammenstellen und weitere Hung System Aufsätze wahlweise miteinander kombinieren.
<G-vec00001-001-s415><assemble.zusammenstellen><en> OEM is welcome and we can also provide all series parts for our customers so that they can assemble on their own to save their import tax .
<G-vec00001-001-s415><assemble.zusammenstellen><de> OEM ist willkommen und wir können auch alle Serienteile für unsere Kunden so, dass sie auf ihren eigenen zusammenstellen können ihre Einfuhrsteuer zu sparen.
<G-vec00001-001-s416><assemble.zusammenstellen><en> Children can assemble the drone with all parts by themselves.
<G-vec00001-001-s416><assemble.zusammenstellen><de> Kinder können die Drohne mit allen Teilen selbst zusammenstellen.
<G-vec00001-001-s417><assemble.zusammenstellen><en> The workers also have to assemble student books.
<G-vec00001-001-s417><assemble.zusammenstellen><de> Die Arbeiter müssen auch Schulbücher zusammenstellen.
<G-vec00001-001-s418><assemble.zusammenstellen><en> Audials Tunebite helps find the most suited best artists for any mood in order to assemble a playlist.
<G-vec00001-001-s418><assemble.zusammenstellen><de> Damit hilft dir Audials Tunebite die besten, zu einer Stimmung passenden Künstler zum Zusammenstellen einer Playlist zu finden.
<G-vec00001-001-s419><assemble.zusammenstellen><en> I would assemble the relevant papers for the chapter after putting the old ones away.
<G-vec00001-001-s419><assemble.zusammenstellen><de> Ich würde die relevanten Papiere für das Kapitel zusammenstellen, nachdem weg die alten setzen.
<G-vec00001-001-s420><assemble.zusammenstellen><en> We always work with the same crews, so you can be assured that they know how to assemble our products and work to the agreed timing plan.
<G-vec00001-001-s420><assemble.zusammenstellen><de> Wir arbeiten immer mit den gleichen Mannschaften zusammen, so dass Sie sicher sein können, dass sie wissen, wie wir unsere Produkte zusammenstellen und mit dem vereinbarten Zeitplan arbeiten können.
<G-vec00001-001-s421><assemble.zusammenstellen><en> Unlike international law firms we are able to assemble a team of lawyers’ which is custom-tailored towards the needs of the respective mandate.
<G-vec00001-001-s421><assemble.zusammenstellen><de> Anders als Großkanzleien können wir dadurch ein auf die Bedürfnisse des jeweiligen Mandats zugeschnittenes Team von Rechtsanwälten zusammenstellen.
<G-vec00001-001-s422><assemble.zusammenstellen><en> If you think that you can assemble a team of authors from, for example, linguistics, computational linguistics and language technology, please get in touch with series co-editor Georg Rehm .
<G-vec00001-001-s422><assemble.zusammenstellen><de> Wenn Sie denken, dass Sie ein Team von Autoren aus den Bereichen Linguistik, Computerlinguistik oder Sprachtechnologie zusammenstellen können, dann wenden Sie sich bitte an den Mitherausgeber der Serie Georg Rehm .
<G-vec00001-001-s423><assemble.zusammenstellen><en> Contestants for prizes 1 and 2 need to assemble the participants they have recruited at the start of the ride and the finish of the ride for a head count.
<G-vec00001-001-s423><assemble.zusammenstellen><de> Die Teilnehmer für die Preise 1 und 2 müssen die Teilnehmer, die sie zu Beginn der Fahrt und am Ende der Fahrt rekrutiert haben, für einen Head Count zusammenstellen.
<G-vec00001-001-s424><assemble.zusammenstellen><en> Whether you're a photographer who needs to assemble a catalogue from a recent photo shoot, or a designer with a folder of images to review or lay out, the ImageGridTM feature is a huge timesaver.
<G-vec00001-001-s424><assemble.zusammenstellen><de> Ganz gleich, ob Sie ein Fotograf sind, der aus einem neuen Fotoshooting einen Katalog zusammenstellen muss, oder ein Designer, der einen Ordner voller Bilder prüfen oder zu einem Layout arrangieren möchte: Die Funktion ImageGridTM spart viel Zeit.
<G-vec00001-001-s425><assemble.zusammenstellen><en> Users can also assemble and organize data portlets, create a personal dashboard, or place frequently used links in a section of the navigation pane.
<G-vec00001-001-s425><assemble.zusammenstellen><de> Außerdem können Anwender Daten-Portlets zusammenstellen und anordnen, ein persönliches Dashboard erstellen oder häufig verwendete Links in einen Abschnitt des Navigationsbereichs platzieren.
<G-vec00001-001-s426><assemble.zusammenstellen><en> We can assemble our heat insulation glasses in diverse sizes and shapes, from the simple angular enclosing shape to the arched or completely amorphous shapes.
<G-vec00001-001-s426><assemble.zusammenstellen><de> Wir können unsere Wärmedämmgläser in vielfältiger Größe und Form angefangen von der einfachen rechteckigen Einfassungsform bis hin zu den gebogenen oder völlig amorphen Formen zusammenstellen.
<G-vec00001-001-s430><assemble.zusammenbauen><en> No need to assemble for this tiny house.
<G-vec00001-001-s430><assemble.zusammenbauen><de> Kein Bedarf, für dieses kleine Haus zusammenzubauen.
<G-vec00001-001-s431><assemble.zusammenbauen><en> A word or caution - evac tube collectors contain a million (seems like it) little parts to assemble.
<G-vec00001-001-s431><assemble.zusammenbauen><de> Ein Wort oder eine Vorsicht - evac Schlauchkollektoren enthalten Million (scheint wie es), kleine Teile, um zusammenzubauen.
<G-vec00001-001-s432><assemble.zusammenbauen><en> 5. inflating, just need to turn on blowers,it is easy to assemble.
<G-vec00001-001-s432><assemble.zusammenbauen><de> 5. aufblasend, gerade Bedarf, Gebläse, zusammenzubauen ist einzuschalten einfach.
<G-vec00001-001-s433><assemble.zusammenbauen><en> began to assemble private libraries.
<G-vec00001-001-s433><assemble.zusammenbauen><de> an, private Bibliotheken zusammenzubauen.
<G-vec00001-001-s434><assemble.zusammenbauen><en> But since a single bacterium is responsible for pain, it should be possible to assemble a recipe for it.
<G-vec00001-001-s434><assemble.zusammenbauen><de> Aber, da ein einzelnes Bakterium fur Schmerz verantwortlich ist, sollte es möglich sein, ein Rezept dagegen zusammenzubauen.
<G-vec00001-001-s435><assemble.zusammenbauen><en> It only takes a few pieces and an afternoon to assemble a TED on your own, to bend individual leg shapes and install your self-created neural network.
<G-vec00001-001-s435><assemble.zusammenbauen><de> Man benötigt nur wenige Einzelteile, um an einem Nachmittag selbst einen TED zusammenzubauen, individuelle Beinformen zu biegen und sein selbst kreiertes neuronales Netz aufzuspielen.
<G-vec00001-001-s436><assemble.zusammenbauen><en> The work performed to assemble a car from its many components (such as windshield, tires, motor, and so on), is the value added in a car assembly plant.
<G-vec00001-001-s436><assemble.zusammenbauen><de> Die Arbeit, um ein Auto aus seinen vielen Bestandteilen zusammenzubauen (wie Windschutzscheibe, Gummireifen, Motor und so weiter), ist der Mehrwert eine Autofabrik.
<G-vec00001-001-s437><assemble.zusammenbauen><en> Not only is it easy to assemble and customize, also equipped with extensive documentation and libraries.
<G-vec00001-001-s437><assemble.zusammenbauen><de> Ist nicht nur besonders anzufertigen einfach zusammenzubauen und, auch ausgerüstet mit umfangreicher Dokumentation und Bibliotheken.
<G-vec00001-001-s438><assemble.zusammenbauen><en> It requires no foundation and is easy and very quick to assemble (30min) by unskilled labors.
<G-vec00001-001-s438><assemble.zusammenbauen><de> Zusammenzubauen erfordert keine Grundlage und ist einfach und sehr schnell, (30min) durch unerfahrene Arbeiten.
<G-vec00001-001-s439><assemble.zusammenbauen><en> Is there any warranty? We often use global-standard components to assemble machinery and attach a copy of operation manual which specifically indicates parts' names and specifications as well as the machine troubleshooting.
<G-vec00001-001-s439><assemble.zusammenbauen><de> Wir verwenden häufig global standardisierte Komponenten, um Maschinen zusammenzubauen, und fügen eine Kopie des Betriebshandbuchs hinzu, in der die Namen und Spezifikationen der Teile sowie die Fehlersuche an der Maschine angegeben sind.
<G-vec00001-001-s440><assemble.zusammenbauen><en> To assemble a high-speed, but budget laptop, you can use 2 hard drives.
<G-vec00001-001-s440><assemble.zusammenbauen><de> Um einen schnellen, aber preiswerten Laptop zusammenzubauen, können Sie 2 Festplatten verwenden.
<G-vec00001-001-s441><assemble.zusammenbauen><en> From such modules it is possible to assemble screens of almost any form or to lay out different symbols and logos from modules, on surface of which high-quality video image can be demonstrated.
<G-vec00001-001-s441><assemble.zusammenbauen><de> Von solchen Modulen ist es möglich, LED-Bildschirme fast jeder möglicher Form zusammenzubauen oder verschiedene Symbole und Firmenzeichen von den Modulen auszubreiten, auf dessen Oberfläche hochwertiges Videobild demonstriert werden kann.
<G-vec00001-001-s442><assemble.zusammenbauen><en> This machine allows human researchers to assemble and evaluate a huge amount of data, as, for instance, in the human genome.
<G-vec00001-001-s442><assemble.zusammenbauen><de> Diese Maschine erlaubt menschlichen Forschern, eine sehr große Menge Daten, Als zum Beispiel in das menschliche Genom zusammenzubauen und auszuwerten.
<G-vec00001-001-s443><assemble.zusammenbauen><en> - It is easier to assemble .
<G-vec00001-001-s443><assemble.zusammenbauen><de> - Es ist leichter zusammenzubauen.
<G-vec00001-001-s444><assemble.zusammenbauen><en> The Exo Terra Terrarium Cabinets are flat packed for convenience and easy to assemble.
<G-vec00001-001-s444><assemble.zusammenbauen><de> Die Exo Terra Terrarienschränke sind flach verpackt und einfach zusammenzubauen.
<G-vec00001-001-s445><assemble.zusammenbauen><en> C. Easy to assemble and maintain.
<G-vec00001-001-s445><assemble.zusammenbauen><de> C. Easy zusammenzubauen und instandzuhalten.
<G-vec00001-001-s446><assemble.zusammenbauen><en> These components, combined with open source will allow to assemble their own firmware, similar in features with the standard firmware.
<G-vec00001-001-s446><assemble.zusammenbauen><de> Diese Komponenten, kombiniert mit Open Source ermöglicht, ihre eigene Firmware, ähnlich in Funktionen mit der Standard-Firmware zusammenzubauen.
<G-vec00001-001-s447><assemble.zusammenbauen><en> operation The kit is presented in a simple and practical to assemble.
<G-vec00001-001-s447><assemble.zusammenbauen><de> Der Bausatz in einer einfachen und praktischen zusammenzubauen dargestellt.
<G-vec00001-001-s448><assemble.zusammenbauen><en> Of course, it is possible to make calculations for the future product, but for safety reasons, it is recommended to experiment with low power of the manual generator, since without experience it is impossible to assemble a fully working model from the first time.
<G-vec00001-001-s448><assemble.zusammenbauen><de> Natürlich ist es möglich, Berechnungen für das zukünftige Produkt durchzuführen, aber aus Sicherheitsgründen wird empfohlen, mit geringer Leistung des manuellen Generators zu experimentieren, da es ohne Erfahrung nicht möglich ist, ein voll funktionsfähiges Modell von Anfang an zusammenzubauen.
<G-vec00001-001-s449><assemble.zusammensetzen><en> """ A typical little Gaulish village, complete with warriors, craftsmen, tradesmen, druid and bard "" Such is the pretty scene that this Asterix jigsaw puzzle, part of the range made in the Czech Republic, invites you to patiently assemble."
<G-vec00001-001-s449><assemble.zusammensetzen><de> """ E in typisches, kleines gallisches Dorf, mit seinen Kriegern, seinen Handwerkern, seinem Druiden, seinem Barden..."" Dieses Asterix-Puzzle aus der in der Tschechischen Republik verlegten Asterix-Puzzle-Kollektion lädt Sie ein, dieses hübsche Motiv geduldig zusammenzusetzen."
<G-vec00001-001-s450><assemble.zusammensetzen><en> Minimally invasive techniques require a precise knowledge of the anatomy and pathology, since not the full overview is available, but often only with help of the imagination in order to assemble the whole body from single images and to focus on the intention.
<G-vec00001-001-s450><assemble.zusammensetzen><de> Minimalinvasive Techniken setzen eine genaue Kenntnis der Anatomie und der Pathologie voraus, da nicht die volle Übersicht vorhanden ist, sondern häufig das Vorstellungsvermögen helfen muss, um aus Einzelbildern den gesamten Körper zusammenzusetzen und um das Ziel an zu visieren.
<G-vec00001-001-s451><assemble.zusammensetzen><en> So much to do, so many parts to assemble.
<G-vec00001-001-s451><assemble.zusammensetzen><de> So viel zu tun, so viele Teile zusammenzusetzen.
<G-vec00001-001-s452><assemble.zusammensetzen><en> 7 Directive 2005/29 must be interpreted as, that in cases, where a trader has chosen, the price for a subscription to assemble so, that the consumer has to pay both a monthly fee as well as a half-yearly fee, this practice is to be regarded as a misleading omission, if the monthly fee is emphasized in marketing, die Halbjahresgebühr aber ganz vorenthalten oder auf eine weniger auffällige Weise dargestellt wird.
<G-vec00001-001-s452><assemble.zusammensetzen><de> 7 der Richtlinie 2005/29 dahin auszulegen ist, dass in Fällen, in denen sich ein Gewerbetreibender dafür entschieden hat, den Preis für ein Abonnement so zusammenzusetzen, dass der Verbraucher sowohl eine Monatsgebühr als auch eine Halbjahresgebühr zu entrichten hat, diese Praxis als irreführende Unterlassung anzusehen ist, wenn die Monatsgebühr in der Vermarktung besonders hervorgehoben wird, die Halbjahresgebühr aber ganz vorenthalten oder auf eine weniger auffällige Weise dargestellt wird.
<G-vec00001-001-s453><assemble.zusammensetzen><en> Man needs much fewer noises than all common languages have today, in order to assemble a nearly unlimited amount of words. Think of phone numbers, for example.
<G-vec00001-001-s453><assemble.zusammensetzen><de> Der Mensch braucht viel weniger Laute, als alle gängigen Sprachen heute haben, um eine beinahe unendliche Menge von Worten zusammenzusetzen.
<G-vec00001-001-s454><assemble.zusammensetzen><en> Each study is the occasion of a work of com-position, all the musical elements are provided, it is enough to assemble them, each in their own way.
<G-vec00001-001-s454><assemble.zusammensetzen><de> Jede Studie ist der Anlass einer Kompositionsarbeit, alle musikalischen Elemente werden zur Verfügung gestellt, es ist genug, um sie auf ihre Weise zusammenzusetzen.
<G-vec00001-001-s455><assemble.zusammensetzen><en> Man needs much fewer noises than all common languages have today, in order to assemble a nearly unlimited amount of words.
<G-vec00001-001-s455><assemble.zusammensetzen><de> Der Mensch braucht viel weniger Laute, als alle gängigen Sprachen heute haben, um eine beinahe unendliche Menge von Worten zusammenzusetzen.
<G-vec00001-001-s456><assemble.zusammenstellen><en> The challenge, however, still falls on the job hunter’s shoulders to assemble stellar references.
<G-vec00001-001-s456><assemble.zusammenstellen><de> Die Herausforderung fällt jedoch immer noch auf die Schuljäger, um stellare Referenzen zusammenzustellen.
<G-vec00001-001-s457><assemble.zusammenstellen><en> No more long time to assemble a hike, rent a boat or a boat, buy tackle and bait, just start the game Russian fishing line and enjoy the tranquility and beauty of your monitor, and a great catch.
<G-vec00001-001-s457><assemble.zusammenstellen><de> Nicht mehr lange, um eine Wanderung zusammenzustellen, ein Boot mieten oder ein Boot, kaufen und Köder, starte das Spiel russischen Angelschnur und genießen Sie die Ruhe und die Schönheit Ihres Monitors, und ein großer Fang.
<G-vec00001-001-s458><assemble.zusammenstellen><en> Once within its main window, you’ll have a menu with the basic options to assemble your contents and choose the place where it will be saved.
<G-vec00001-001-s458><assemble.zusammenstellen><de> Einmal auf dem Hauptfenster, haben Sie ein Menü mit den grundlegenden Optionen, um Ihre Inhalte zusammenzustellen und den Ort zu wählen, wo es gespeichert werden soll.
<G-vec00001-001-s459><assemble.zusammenstellen><en> This program provides an additional opportunity to assemble complex RAID storage and get access to its data.
<G-vec00001-001-s459><assemble.zusammenstellen><de> Dieses Programm bietet eine zusätzliche Möglichkeit, komplexe RAID-Speicher zusammenzustellen und Zugriff auf Ihre Daten zu erhalten.
<G-vec00001-001-s460><assemble.zusammenstellen><en> But now, through new scientific advances, and societal, political and human rights gains, we have discovered that it is possible to assemble and deliver a package of proven strategies, which, if taken to scale, can turn the tide on AIDS.
<G-vec00001-001-s460><assemble.zusammenstellen><de> Doch jetzt, durch neue wissenschaftliche Fortschritte und gesellschaftliche, politische und menschenrechtliche Gewinne haben wir entdeckt, dass es möglich ist, ein Paket an bewährten Strategien zusammenzustellen und zu liefern, die, wenn sie als Maßstab genommen werden, das Blatt bei AIDS wenden können...
<G-vec00001-001-s461><assemble.zusammenstellen><en> The AG on Heart Failure has taken care to assemble brief informative summaries here with the hope that this will make it easier for you to deal with this disease.
<G-vec00001-001-s461><assemble.zusammenstellen><de> Die AG-Herzinsuffizienz hat sich bemüht ihnen kurz zusammengefasst Informationen zusammenzustellen, die ihnen den Umgang mit dieser Erkrankung erleichtern sollen.
<G-vec00001-001-s462><assemble.zusammenstellen><en> Each girl wants to look great for her first day back at school, so help her assemble a wonderful outfit.
<G-vec00001-001-s462><assemble.zusammenstellen><de> Jedes Mädchen möchte am ersten Schultag großartig aussehen, also helfen Sie ihm, ein wunderbares Outfit zusammenzustellen.
<G-vec00001-001-s463><assemble.zusammenstellen><en> This makes it possible to assemble the goods at an early stage, prepare them for dispatch and hand them over to the logistics company without any loss of time.
<G-vec00001-001-s463><assemble.zusammenstellen><de> So ist es möglich, die Waren frühzeitig zusammenzustellen, für den Versand vorzubereiten und ohne Zeitverluste an den Logistiker zu übergeben.
<G-vec00001-001-s464><assemble.zusammenstellen><en> Stresses computed by Altair OptiStruct from unit loads were also included, enabling the engineers to assemble stress histories for all locations on the wheel carrier.
<G-vec00001-001-s464><assemble.zusammenstellen><de> Außerdem wurden in Altair OptiStruct berechnete Spannungen von Einheitenlasten hinzugefügt, die es den Ingenieuren ermöglichten, Spannungshistorien für alle Positionen auf dem Radträger zusammenzustellen.
<G-vec00001-001-s465><assemble.zusammenstellen><en> Select the Data Partition of the SSD component and open it as Apple Core Storage Volume to assemble the storage.
<G-vec00001-001-s465><assemble.zusammenstellen><de> Wählen Sie die Datenpartition der SSD-Komponente aus und öffnen Sie sie als Apple Core Storage Volumen, um den Speicher zusammenzustellen.
<G-vec00001-001-s466><assemble.zusammenstellen><en> Use the cards to dress your models,assemble trendsetting outfits, and create signature collections for a summer fashion show.
<G-vec00001-001-s466><assemble.zusammenstellen><de> Verwenden Sie die Karten, um Ihre Modelle zu kleiden, richtungsweisende Outfits zusammenzustellen und Signaturkollektionen für eine Sommermodeschau zu kreieren.
<G-vec00001-001-s467><assemble.zusammenstellen><en> The Beretta Layering System helps assemble a perfect outfit that can be enjoyed throughout the entire hunting season with maximum comfort and protection in all conditions.
<G-vec00001-001-s467><assemble.zusammenstellen><de> Das Beretta-Schichtsystem hilft ein perfektes Outfit zusammenzustellen, das Sie in der gesamten Jagdsaison mit maximalen Komfort und Schutz in jeder Situation genießen können.
<G-vec00001-001-s468><assemble.zusammenstellen><en> There's no color blending producing faux digital mosaic; instead, Artensoft Photo Collage Maker uses advanced mix-and-match to assemble a perfect photo collage out of a number of different images.
<G-vec00001-001-s468><assemble.zusammenstellen><de> Es wird kein Überblenden von Farben verwendet, um ein Mosaik vorzutäuschen; stattdessen wendet Artensoft Photo Collage Maker fortschrittliche Misch- und Abgleichverfahren an, um aus einer Vielzahl verschiedener Einzelbilder die perfekte Collage zusammenzustellen.
<G-vec00001-001-s469><assemble.zusammenstellen><en> It gives me immense pleasure to assemble the objects in different rooms.
<G-vec00001-001-s469><assemble.zusammenstellen><de> Es macht ja auch wahnsinnig Spaß die Dinge in verschiedenen Räumen zusammenzustellen.
<G-vec00001-001-s470><assemble.zusammenstellen><en> At this step, you can also calculate the number of each set so that you can also visualize the number of contacts for each, as it takes time to assemble the list.
<G-vec00001-001-s470><assemble.zusammenstellen><de> An dieser Stelle können Sie auch die Anzahl jedes einzelnen Sets berechnen, damit Sie die Anzahl der Kontakte einfacher visualisieren können, da es Zeit braucht, um eine Liste zusammenzustellen.
<G-vec00001-001-s471><assemble.zusammenstellen><en> Flat delivered, easy to assemble.
<G-vec00001-001-s471><assemble.zusammenstellen><de> Flach geliefert, einfach zusammenzustellen.
<G-vec00001-001-s472><assemble.zusammenstellen><en> You may not have the budget to assemble a top-tier team that will constantly monitor your progress, but you can leverage tools.
<G-vec00001-001-s472><assemble.zusammenstellen><de> Du hast vielleicht nicht das Budget, um ein hochrangiges Team zusammenzustellen, das Deinen Fortschritt dauerhaft überprüft, aber Du kannst Dir Tools zunutze machen.
<G-vec00001-001-s473><assemble.zusammenstellen><en> Due to the reunification of the commandos in the fall of 1949, we were able to exchange all numbers and measures taken, hold on to them and assemble them after our return from Russia.
<G-vec00001-001-s473><assemble.zusammenstellen><de> Durch die Zusammenführung dieser Kommandos 38 im Herbst 1949 vermochten wir alle Zahlen und Maßnahmen auszutauschen, festzuhalten und nach Rückkehr aus Rußland zusammenzustellen.
<G-vec00001-001-s474><assemble.zusammenstellen><en> You might have seen Quickshot driving around Berlin in a swanky KIA car to assemble the casting team, you'll now also see the Kia fleet making an appearance at our roadshows and offline events, where we'll be cooking up special onsite activations for our fans.
<G-vec00001-001-s474><assemble.zusammenstellen><de> Vielleicht habt ihr gesehen, wie Quickshot in einem schmucken KIA-Auto durch Berlin fuhr, um das Casting-Team zusammenzustellen, und nun werdet ihr auch sehen, wie die Kia-Flotte auf unseren Roadshows und Offline-Veranstaltungen auftritt, wo wir für unsere Fans spezielle Aktivitäten vor Ort vorbereiten werden.
<G-vec00443-002-s032><assemble.aufbauen><en> Assemble, stand out, disassemble, transport and reassemble.
<G-vec00443-002-s032><assemble.aufbauen><de> Aufbauen, glänzen, abbauen, transportieren und das Ganze wieder aufbauen.
<G-vec00443-002-s033><assemble.aufbauen><en> We deliver your log house by PERR in form of a construction-kit, so that, with sort of manual skills and with the aid of our detailed construction manual, you are able to assemble all of our smaller wooden houses as well as our garden or tool houses easily by yourself.
<G-vec00443-002-s033><assemble.aufbauen><de> Wir liefern Ihr PERR Blockhaus im Bausatz an und mit etwas handwerklichem Geschick und unserer detaillierten Bauanleitung, können Sie alle kleineren Holzhäuser, wie ein Garten- oder Gerätehaus, problemlos selbst aufbauen.
<G-vec00443-002-s034><assemble.aufbauen><en> To assemble, only a metal disc is attached to the wall at a given position by means of a screw with dowel.
<G-vec00443-002-s034><assemble.aufbauen><de> Zum Aufbauen wird lediglich eine Metallscheibe an vorgegebener Position mittels einer Schraube mit Dübel an der Wand befestigt.
<G-vec00443-002-s036><assemble.aufbauen><en> The POS kit is easy for field sales teams or merchandisers to assemble in store, with just a few simple steps.
<G-vec00443-002-s036><assemble.aufbauen><de> Im Handel lässt sie das Set von den Außendienstmitarbeitern des Babynahrungsherstellers mit wenigen Handgriffen aufbauen.
<G-vec00443-002-s037><assemble.aufbauen><en> It is ergonomically designed, has a rotating head, and is quick to assemble and refill with the specially developed Bona Wood Floor Cleaner Cartridge.
<G-vec00443-002-s037><assemble.aufbauen><de> Der Spray Mop lässt sich leicht und schnell aufbauen und mit der speziell entwickelten Kartusche des Bona Parkettreiniger nachfüllen.
<G-vec00443-002-s038><assemble.aufbauen><en> Throughout the course of time, you can assemble it in different assembly heights without having to buy additional parts.
<G-vec00443-002-s038><assemble.aufbauen><de> Sie können es im Laufe der Jahre in verschiedenen Aufbauhöhen aufbauen, ohne zusätzliche Teile kaufen zu müssen.
<G-vec00443-002-s039><assemble.aufbauen><en> This cupboard is easy to assemble thanks to the illustrated instructions.
<G-vec00443-002-s039><assemble.aufbauen><de> Dieser Küchenschrank lässt sich dank der bebilderten Anleitung unkompliziert aufbauen.
<G-vec00443-002-s040><assemble.aufbauen><en> Small pack size, no tools easy to assemble.
<G-vec00443-002-s040><assemble.aufbauen><de> Kleines Packmaß, ohne Werkzeug einfach zum Aufbauen.
<G-vec00443-002-s063><assemble.bauen><en> We assemble the parts we produce or outsource and the components you supply into modules and deliver them ready to install as per your
<G-vec00443-002-s063><assemble.bauen><de> Wir bauen die bei uns gefertigten Einzelteile und auch die von Ihnen angelieferten Bauteile oder von uns beschafften Kaufteile zu Baugruppen zusammen und liefern diese nach Ihrem Wunsch einbaufertig an.
<G-vec00443-002-s064><assemble.bauen><en> The kit contains 30 pieces from which it is possible to assemble a pet salon .
<G-vec00443-002-s064><assemble.bauen><de> Das Kit enthält 30 Stücke, von denen es möglich ist, einen Salon für Haustiere zu bauen.
<G-vec00443-002-s065><assemble.bauen><en> Assemble: Merge, merge.
<G-vec00443-002-s065><assemble.bauen><de> Bauen: Zusammenführen, verschmelzen.
<G-vec00443-002-s066><assemble.bauen><en> If you are not able at all to assemble your Mysticum on your own, but like to have one, please contact me!
<G-vec00443-002-s066><assemble.bauen><de> Wenn du überhaupt nicht in der Lage bist, dir einen Mysticum zu bauen, aber gerne einen haben möchtest, dann kontaktiere mich bitte.
<G-vec00443-002-s067><assemble.bauen><en> Not only that, but there are additional trophies available for pirates who diligently assemble a variety of toys.
<G-vec00443-002-s067><assemble.bauen><de> Außerdem gibt es weitere Trophäen für Piraten, die eine Vielzahl an Spielzeugen bauen.
<G-vec00443-002-s068><assemble.bauen><en> Our mechanics assemble your dream bike according to your wishes.
<G-vec00443-002-s068><assemble.bauen><de> Unsere Monteure bauen Ihr Traumbike individuell auf Sie abgestimmt und nach Ihren Wünschen auf.
<G-vec00443-002-s069><assemble.bauen><en> To ensure proper functionality, we assemble our tactile in a class 100-rated dust-free facility, and instead of doing the assembly manually, we use fully automated equipment designed by our own R&D team to produce 10,000 units each day.
<G-vec00443-002-s069><assemble.bauen><de> Um richtige Funktionalität sicherzustellen, bauen wir unser Tast in einer Klasse 100 veranschlagten staubfreie Anlage zusammen, und anstatt die Versammlung manuell zu tun, benutzen wir die völlig automatisierte Ausrüstung, die von unserem eigenen R&D-Team entworfen ist um 10.000 Einheiten jeden Tag zu produzieren.
<G-vec00443-002-s070><assemble.bauen><en> This multi-part plastic kit contains the components necessary to assemble Khârn the Betrayer, a single-pose model armed with a plasma pistol and his chainaxe, Gorechild.
<G-vec00443-002-s070><assemble.bauen><de> Dieser mehrteilige Kunststoffbausatz enthält alle Teile, die nötig sind, um Khârn the Betrayer zu bauen, ein Modell mit fester Pose, das mit einer Plasmapistole und seiner Kettenaxt Bluttrinker bewaffnet ist.
<G-vec00443-002-s071><assemble.bauen><en> With this kit, you can assemble a model of a 1966 2 litre flat-six engine in around three hours.
<G-vec00443-002-s071><assemble.bauen><de> Mit diesem Paket bauen Sie in rund drei Stunden ein transparentes Funktionsmodell des 2-Liter-6-Zylinder-Boxermotors aus dem Jahr 1966.
<G-vec00443-002-s072><assemble.bauen><en> Upon request we design and assemble special axes according to your requirements and application areas.
<G-vec00443-002-s072><assemble.bauen><de> Auf Wunsch konstruieren und bauen wir nach Ihren individuellen Aufgabenstellungen und Einsatzbereichen spezielle Sonderachsen.
<G-vec00443-002-s073><assemble.bauen><en> Our machines are built up modular – mainly from the standard components (which are produced in series) we assemble a device which is tuned exactly to your medium.
<G-vec00443-002-s073><assemble.bauen><de> Unsere Maschinen sind modular aufgebaut – aus weitgehenden Standardkomponenten (die in Serien gefertigt werden) bauen wir ein Gerät, das genau auf Ihr Medium abgestimmt ist.
<G-vec00443-002-s074><assemble.bauen><en> You have access to an array of parts to assemble fully-functional spacecraft that flies (or doesn’t) based on realistic aerodynamic and orbital physics.
<G-vec00443-002-s074><assemble.bauen><de> Dazu nutzen sie eine breite Palette an Teilen, um voll funktionsfähige Raumfahrzeuge zu bauen, die nach den Regeln realistischer Aerodynamik und Orbitalphysik durch das Weltall gleiten – oder eben nicht.
<G-vec00443-002-s075><assemble.bauen><en> We also assemble other electronic and mechanical systems to our electronic and plastic components in order to supply a fully finished product to the client, even with the packaging personalized, with instructions and perfectly prepared to be sent to the end customer.
<G-vec00443-002-s075><assemble.bauen><de> Außerdem bauen wir andere elektronische und mechanische Systeme in unsere eigenen Elektronik- und Kunststoffentwicklungen ein und liefern dem Kunden das vollständige fertige System, einschließlich personalisierter Verpackung, mit Anleitung und absolut bereit für den Versand an den Endkunden.
<G-vec00443-002-s076><assemble.bauen><en> We sell electronic DIY kits that are fun, easy to assemble and instructive.
<G-vec00443-002-s076><assemble.bauen><de> Wir vertreiben Elektronikbausätze, die einfach zu bauen und lehrreich sind und Spaß machen.
<G-vec00443-002-s077><assemble.bauen><en> Choose your basic pump, select your accessories, and we will assemble, test and ship your pump.
<G-vec00443-002-s077><assemble.bauen><de> Wählen Sie die Basispumpe aus, ergänzen Sie diese mit dem Zubehör Ihrer Wahl - wir bauen, testen und liefern ihnen ihre Pumpe.
<G-vec00443-002-s078><assemble.bauen><en> If you are not able at all to assemble your Mysticum on your own, but like to have one, contact me at webmaster(at)miclangschach(dot)de!
<G-vec00443-002-s078><assemble.bauen><de> Wenn du überhaupt nicht in der Lage bist, dir einen Mysticum zu bauen, aber gerne einen haben möchtest, dann kontaktiere mich unter webmaster(at)miclangschach(dot)de.
<G-vec00443-002-s079><assemble.bauen><en> Member States must ensure that companies which manufacture or import explosives, and those which assemble detonators mark these products with a unique identification.
<G-vec00443-002-s079><assemble.bauen><de> Die Mitgliedstaaten müssen sicherstellen, dass die Unternehmen, die Explosivstoffe herstellen oder einführen oder Sprengzünder bauen, auf den Explosivstoffen eine eindeutige Kennzeichnung anbringen.
<G-vec00443-002-s080><assemble.bauen><en> Journalists who drive the New Phantom to ochs und junior’s Lucerne workshop during the press launch will assemble a perpetual calendar.
<G-vec00443-002-s080><assemble.bauen><de> Journalisten, die den New Phantom bei diesem Medienevent zu den Luzerner Arbeitsräumen von ochs und junior lenken, werden einen Ewigen Kalender bauen.
<G-vec00443-002-s139><assemble.montieren><en> The steel structural member is easy to manufacture and assemble at the site.
<G-vec00443-002-s139><assemble.montieren><de> Das Stahl-Tragwerk ist einfach zu fertigen und montieren vor Ort.
<G-vec00443-002-s140><assemble.montieren><en> Really good quality design and very easy to assemble.
<G-vec00443-002-s140><assemble.montieren><de> Wirklich gute Qualität Design und sehr einfach zu montieren.
<G-vec00443-002-s141><assemble.montieren><en> The BMW automobile concern has chosen a plant in Leipzig (Germany) to assemble a 1-series coupe.
<G-vec00443-002-s141><assemble.montieren><de> Der BMW-Automobilkonzern hat ein Werk in Leipzig (Deutschland) ausgewählt, um ein 1er-Coupé zu montieren.
<G-vec00443-002-s142><assemble.montieren><en> Our many years of experience enable us to offer highly specialised individual solutions that we will be happy to design, produce and assemble in accordance with your ideas and conceptions.
<G-vec00443-002-s142><assemble.montieren><de> Auf Grund unserer langjährigen Erfahrungen können wir Ihnen auch hochspezielle Individuallösungen anbieten, die wir entsprechend Ihrer Ideen und Vorstellungen gern für Sie konzipieren, produzieren und montieren.
<G-vec00443-002-s143><assemble.montieren><en> At the cleanroom plant in Emmen, we manufacture and assemble high-purity valves, measurement and control systems, as well as products for the medical and pharmaceutical industries.
<G-vec00443-002-s143><assemble.montieren><de> Im Reinraumwerk Emmen fertigen und montieren wir hochreine Ventil-, Mess- und Regeltechnik sowie Produkte für die Medizintechnik und die Pharmaindustrie.
<G-vec00443-002-s144><assemble.montieren><en> If it is correct to assemble and disassemble a pine tree, it will delight every year.
<G-vec00443-002-s144><assemble.montieren><de> Wenn es richtig ist, eine Kiefer zu montieren und zu zerlegen, wird sie jedes Jahr begeistert.
<G-vec00443-002-s145><assemble.montieren><en> Place the tray sides together in the way you want to assemble them.
<G-vec00443-002-s145><assemble.montieren><de> Positionieren Sie die Tablettseiten nun so zueinander, wie Sie sie montieren wollen.
<G-vec00443-002-s146><assemble.montieren><en> As Mak Plus Power Systems, we produce and assemble with the best and highest quality electrical and electronically parts.
<G-vec00443-002-s146><assemble.montieren><de> Als Mak Plus Power Systems, produzieren und montieren wir mit den besten und qualitativ hochwertigsten elektrischen und elektronischen Bauteilen.
<G-vec00443-002-s147><assemble.montieren><en> Stackable and very easy to assemble.
<G-vec00443-002-s147><assemble.montieren><de> Stapelbar und sehr einfach zu montieren.
<G-vec00443-002-s148><assemble.montieren><en> It is quick and easy to assemble and provides good weather protection at storage and trans-shipment centres around the world
<G-vec00443-002-s148><assemble.montieren><de> Sie ist einfach und schnell zu montieren und schützt sicher gegen Witterungseinflüsse an den Lager- und Umschlagplätzen der Welt.
<G-vec00443-002-s149><assemble.montieren><en> Replaceable lightweight concrete panel’s lightweight make installers easy to assemble the panel,and one skilled worker can install 40 square meter per day,so totally reduce the workers salary and engineering cost.
<G-vec00443-002-s149><assemble.montieren><de> Das leichte Gewicht der austauschbaren Leichtbetonplatte macht den Installateur leicht zu montieren, und ein Facharbeiter kann 40 Quadratmeter pro Tag installieren, um so das Lohn- und Technikaufkommen der Arbeiter zu reduzieren.
<G-vec00443-002-s150><assemble.montieren><en> We have instruction in each our stand base, it is very easy to assemble new banner into the base.
<G-vec00443-002-s150><assemble.montieren><de> Wir haben Unterricht in jedem unserer Standbasis, es ist sehr einfach, neue Banner in der Basis zu montieren.
<G-vec00443-002-s151><assemble.montieren><en> The SM6-AL distance measuring sensor from Rexroth with a maximum measurement range of 1007 mm is easy to assemble on profile cylinders.
<G-vec00443-002-s151><assemble.montieren><de> Der Wegmesssensor SM6-AL von Rexroth mit maximalen Wegmesslängen von 1007 mm ist einfach auf dem Profilzylinder zu montieren.
<G-vec00443-002-s152><assemble.montieren><en> This universal lighting graphic is easy to assemble and disassemble.
<G-vec00443-002-s152><assemble.montieren><de> Diese vielseitige Leuchtkastenfolie ist leicht zu montieren und zu demontieren.
<G-vec00443-002-s153><assemble.montieren><en> Easy to assemble, high carrying capacity, cheap to ship, find all the benefits below.
<G-vec00443-002-s153><assemble.montieren><de> Einfach zu montieren, hohe Tragfähigkeit, günstiger Versand, finden Sie alle Vorteile unten.
<G-vec00443-002-s154><assemble.montieren><en> You can get wheels of different sizes (including glow-in-the-dark ones), brakes, and compatible screws on our website and in your local Decathlon workshop. It's all easy to assemble.
<G-vec00443-002-s154><assemble.montieren><de> Rollen verschiedener Größen (auch Leuchtrollen), Bremsstopper oder passende Schrauben findest du in unserem Onlineshop und am Servicepoint deiner DECATHLON-Filiale.Alle Teile sind einfach zu montieren.
<G-vec00443-002-s155><assemble.montieren><en> The material is easy to assemble and is able to embody the designer's wildest fantasies;
<G-vec00443-002-s155><assemble.montieren><de> Das Material ist einfach zu montieren und verkörpert die wildesten Phantasien des Designers.
<G-vec00443-002-s156><assemble.montieren><en> Our experienced and well-coordinated teams assemble and disassemble machines, technical installations and equipment of various sizes quickly, safely and exactly according to the time schedule.
<G-vec00443-002-s156><assemble.montieren><de> Unsere erfahrenen und eingespielten Teams montieren und demontieren Maschinen, technische Geräte und Equipment unterschiedlicher Größenordnung – schnell, sicher und exakt nach Terminplan.
<G-vec00443-002-s157><assemble.montieren><en> We deliver or assemble stationary and mobile all truck windows throughout Germany.
<G-vec00443-002-s157><assemble.montieren><de> Wir liefern oder montieren stationär sowie mobil alle LKW-Scheiben deutschlandweit.
<G-vec00443-002-s183><assemble.sammeln><en> Giddianhi, the Gadianton leader, demands that Lachoneus and the Nephites surrender themselves and their lands—Lachoneus appoints Gidgiddoni as chief captain of the armies—The Nephites assemble in Zarahemla and Bountiful to defend themselves. About A.D. 16–18.
<G-vec00443-002-s183><assemble.sammeln><de> Giddianhi, der Gadiantonführer, verlangt, daß Lachoneus und die Nephiten sich und ihre Länder aufgeben—Lachoneus bestimmt Gidgiddoni zum obersten Hauptmann der Heere—Die Nephiten sammeln sich im Land Zarahemla und Überfluß, um sich zu verteidigen.
<G-vec00443-002-s184><assemble.sammeln><en> It was my job to take the results and assemble them together into a final test image.
<G-vec00443-002-s184><assemble.sammeln><de> Meine Aufgabe war es, die Ergebnisse zu sammeln und daraus ein finales Testdiagramm zu erstellen.
<G-vec00443-002-s185><assemble.sammeln><en> For a while that music is playing, participants must be able to glue and assemble a beautiful, sturdy house for the newlyweds.
<G-vec00443-002-s185><assemble.sammeln><de> Für die Zeit, die Musik spielt, müssen die Teilnehmer kleben und sammeln ein schönes, dauerhaftes Haus für das Brautpaar.
<G-vec00443-002-s187><assemble.sammeln><en> Try to assemble a collection of more than 80 species of colorful fish.
<G-vec00443-002-s187><assemble.sammeln><de> Versuchen Sie, eine Sammlung von mehr als 80 Arten von bunten Fischen zu sammeln.
<G-vec00443-002-s188><assemble.sammeln><en> And in Agni Yoga: My warriors, I can assemble you according to usefulness and devotion.
<G-vec00443-002-s188><assemble.sammeln><de> Und im Agni Yoga: Meine Krieger, Ich kann euch der Nützlichkeit und der Ergebenheit gemäß sammeln.
<G-vec00443-002-s189><assemble.sammeln><en> 12 I will surely assemble, Jacob, all of you; I will surely gather the remnant of Israel; I will put them together as the sheep of Bozrah, as a flock in the midst of their pasture; they will swarm with people.
<G-vec00443-002-s189><assemble.sammeln><de> 12 Ich will dich, Jakob, sammeln, und zwar ganz sammeln; ich will den Überrest Israels vollständig zusammenbringen, will sie vereinigen wie die Schafe in der Hürde, wie eine Herde auf ihrem Weideplatz, dass es von Menschen wimmeln soll.
<G-vec00443-002-s190><assemble.sammeln><en> For the bourgeoisie, the desire to re-establish national unity, to 're-unite with the ceded parts of the country', is nothing but an attempt of the defeated to assemble forces for new wars.
<G-vec00443-002-s190><assemble.sammeln><de> Die Bestrebungen auf Wiederherstellung der nationalen Einheit, auf “Wiedervereinigung mit abgetretenen Landesteilen” sind für die Bourgeoisie nichts anderes als der Versuch der Besiegten, Kräfte zu neuen Kriegen zu sammeln.
<G-vec00443-002-s191><assemble.sammeln><en> The payroll register is a multicolumn journal used to assemble and summarize payroll data. Information that can typically be
<G-vec00443-002-s191><assemble.sammeln><de> LOHNLISTENREGISTER Das Lohnlistenregister ist ein mehrspaltiges Journal, dass verwendet wird, um Lohnlistendaten zu sammeln und zusammenzufassen.
<G-vec00443-002-s267><assemble.sich_versammeln><en> 4 “Lift up your eyes and look about you: All assemble and come to you; your sons come from afar, and your daughters are carried on the hip.
<G-vec00443-002-s267><assemble.sich_versammeln><de> Sie alle versammeln sich, kommen zu dir: deine Söhne kommen von ferne, und deine Töchter werden auf den Armen herbeigetragen.
<G-vec00443-002-s268><assemble.sich_versammeln><en> Some visitors assemble here regularly each summer to enjoy the energy radiation, as they believe it to be one of earths seven energy spots.
<G-vec00443-002-s268><assemble.sich_versammeln><de> Einige Menschen versammeln sich hier regelmäßig jeden Sommer um die Energieausstrahlung zu genießen, denn sie glauben, dass dies einer der sieben Energiepunkte der Erde sei.
<G-vec00443-002-s269><assemble.sich_versammeln><en> In the morning, all the quarry workers assemble near the quarry face and the quarry master allocates the day’s work.
<G-vec00443-002-s269><assemble.sich_versammeln><de> Morgens versammeln sich alle Steinhauer im Steinbruch, um ihre Arbeitsaufgaben zugeteilt zu bekommen.
<G-vec00443-002-s248><assemble.versammeln><en> 7 And proclamation was made throughout Judah and Jerusalem to all the returned exiles, that they should assemble in Jerusalem,
<G-vec00443-002-s248><assemble.versammeln><de> 7Und sie ließen durch Juda und Jerusalem einen Ruf ergehen an alle Kinder der Wegführung, daß sie sich nach Jerusalem versammeln sollten.
<G-vec00443-002-s249><assemble.versammeln><en> - We do NOT train our children to obey a bell when they are expected to assemble for singing, play, painting sessions or for meals.
<G-vec00443-002-s249><assemble.versammeln><de> Wir trainieren und 'dressieren' unsere Kinder nicht dazu einer Glocke zu folgen, wenn sie sich zum Singen, Spielen, Basteln oder Essen versammeln sollten.
<G-vec00443-002-s250><assemble.versammeln><en> When we assemble together as a communion, it will not be primarily to lament the state of the world.
<G-vec00443-002-s250><assemble.versammeln><de> Wenn wir uns jedoch als Gemeinschaft versammeln, wird dies nicht hauptsächlich geschehen, um den Zustand der Welt zu beklagen.
<G-vec00443-002-s251><assemble.versammeln><en> The intention of the founders was to assemble in one place the full range of services for entrepreneurs and the unemployed seeking self-development opportunities.
<G-vec00443-002-s251><assemble.versammeln><de> Die Absicht der Gründer war es, an einem Ort das gesamte Spektrum der Dienstleistungen für Unternehmer und Arbeitslose, die eigenständige Entwicklungsmöglichkeiten suchen, zu versammeln.
<G-vec00443-002-s252><assemble.versammeln><en> 4 If only one is sounded, the leaders—the heads of the clans of Israel—are to assemble before you.
<G-vec00443-002-s252><assemble.versammeln><de> Und wenn man [nur] eine bläst, dann sollen sich die Fürsten zu dir versammeln, die Häupter der Tausendschaften Israels.
<G-vec00443-002-s253><assemble.versammeln><en> 21:4 Thus says the LORD God of Israel; Behold, I will turn back the weapons of war that are in your hands, wherewith all of you fight against the king of Babylon, and against the Chaldeans, which besiege you without the walls, and I will assemble them into the midst of this city.
<G-vec00443-002-s253><assemble.versammeln><de> 4 Das spricht der HERR, der Gott Israels: Siehe, ich will euch zum Rückzug zwingen samt euren Waffen, die ihr in euren Händen habt und mit denen ihr kämpft gegen den König von Babel und gegen die Chaldäer, die euch draußen vor der Mauer belagern, und will euch versammeln mitten in dieser Stadt.
<G-vec00443-002-s254><assemble.versammeln><en> For My decision and determination and right it is to gather the nations together, to assemble the kingdoms, to pour upon them My indignation, even all [the heat of] My fierce anger; for [in that day] all the earth shall be consumed with the fire of My zeal and jealousy.
<G-vec00443-002-s254><assemble.versammeln><de> Denn mein Rechtsspruch ist, die Nationen zu versammeln, die Königreiche zusammenzubringen, um meinen Grimm über sie auszugießen, die ganze Glut meines Zornes; denn durch das Feuer meines Eifers wird die ganze Erde verzehrt werden.
<G-vec00443-002-s255><assemble.versammeln><en> And if the waters have successfully departed and the liquid has a normal appearance and color, calmly assemble and go to the hospital: there is already a little time left.
<G-vec00443-002-s255><assemble.versammeln><de> Und wenn das Wasser erfolgreich abgegangen ist und die Flüssigkeit ein normales Aussehen und eine normale Farbe hat, versammeln Sie sich ruhig und gehen Sie ins Krankenhaus: Es ist schon etwas Zeit übrig.
<G-vec00443-002-s256><assemble.versammeln><en> We call the European Union to demand from the Turkish government in compliance with European values: democracy, rule of law, press freedom and the right to freely assemble, to express themselves peacefully or to pursue one’s own religion.
<G-vec00443-002-s256><assemble.versammeln><de> Wir fordern die Europ?ische Union auf, gegenüber der türkischen Regierung die Einhaltung europ?ischer Werte: Demokratie, Rechtsstaatlichkeit, Pressefreiheit sowie das Recht sich frei zu versammeln, sich friedlich zu?u?ern oder der eigenen Religion nachzugehen, einzufordern.
<G-vec00443-002-s257><assemble.versammeln><en> He will surely assemble you for the Day of Resurrection, about which there is no doubt.
<G-vec00443-002-s257><assemble.versammeln><de> Er wird euch am jüngsten Tag, über den es keinen Zweifel gibt, sicherlich versammeln.
<G-vec00443-002-s258><assemble.versammeln><en> Any statements critical of the government are harshly punished, and citizens who assemble peacefully have been repressed, and sometimes attacked by government militias.
<G-vec00443-002-s258><assemble.versammeln><de> Jede regierungskritische Äußerung wird schwer bestraft und es kann vorkommen, dass Bürger, die sich zu friedlichen Zwecken versammeln, Repressalien ausgesetzt oder sogar von Regierungsmilizen auseinandergesprengt werden.
<G-vec00443-002-s259><assemble.versammeln><en> Hide Verse Numbers Close 8 and will go out to lead astray the nations in all the four corners of the earth, Gog and Magog, and assemble them for war, and they are like the sands on the seashore in number.
<G-vec00443-002-s259><assemble.versammeln><de> Offenbarung 20:8 - ELB - und wird und wird ausgehen, die Nationen zu verführen, die an den vier Ecken der Erde sind, den Gog und den Magog, sie zum Kriege zu versammeln, deren Zahl wie der Sand des Meeres ist.
<G-vec00443-002-s260><assemble.versammeln><en> 016:016 And assemble them they did at the place called in Hebrew 'Har-Magedon.'
<G-vec00443-002-s260><assemble.versammeln><de> 16 Sie versammeln sie an dem Ort, der auf hebräisch Harmagedon heißt.
<G-vec00443-002-s261><assemble.versammeln><en> 1–3, Elders are to assemble in conference; 4–6, They are to organize according to the laws of the land and to care for the poor.
<G-vec00443-002-s261><assemble.versammeln><de> 1–3 Die Ältesten sollen sich zu einer Konferenz versammeln; 4–6 Sie sollen sich gemäß den Gesetzen des Landes organisieren und für die Armen sorgen.
<G-vec00443-002-s262><assemble.versammeln><en> Schoenberg unleashes the massive power of his orchestra here, with an overpowering use of the brass section to capture the jangling of armour and horses as the vassals assemble.
<G-vec00443-002-s262><assemble.versammeln><de> Schönberg entfesselt hier die ganze Kraft des riesigen Orchesters und macht überwältigenden Gebrauch von den Blechbläsern, um den Klang der rasselnden Rüstungen und der Pferde nachzuempfinden, während sich seine Männer versammeln.
<G-vec00443-002-s263><assemble.versammeln><en> Editors Bayerdörfer, Fischer, and Halbach from the Institute for Theatre Studies of Ludwig-Maximilians-University in Munich assemble in their volume Judenrollen (Jewish Roles) 21 essays on the depiction of Jews in European theatre from the Restauration through the post-WWI era.
<G-vec00443-002-s263><assemble.versammeln><de> Darstellungsformen im europäischen Theater von der Restauration bis zur Zwischenkrietätigen Bayerdörfer, Fischer und Halbach versammeln in ihrem Band Judenrollen 21 Untersuchungen zu der Darstellung von Juden auf dem europäischen Theater von der Restauration bis zur Zwischenkriegszeit.
<G-vec00443-002-s264><assemble.versammeln><en> It has proven very difficult to assemble a group of interested teachers who are ready to purposively work in an assigned anti-manipulation direction.
<G-vec00443-002-s264><assemble.versammeln><de> Es hat sich als sehr schwierig erwiesen, eine Gruppe von interessierten Lehrern zu versammeln, die bereit sind, in einer festgesetzten Antimanipulations-Richtung zweckentsprechend zu arbeiten.
<G-vec00443-002-s265><assemble.versammeln><en> Moses had given a command that when the Israelites came to the land they should assemble before two mountains in the center of the country to receive God’s blessing.
<G-vec00443-002-s265><assemble.versammeln><de> Mose hatte befohlen, dass sich die Israeliten, sobald sie das Land erreicht hatten, in der Mitte des Landes vor zwei Bergen versammeln sollten, um Gottes Segen zu empfangen.
<G-vec00443-002-s266><assemble.versammeln><en> The original Michael is the presiding head of the primary Paradise Sons when they assemble for conference at the center of all things.
<G-vec00443-002-s266><assemble.versammeln><de> Der ursprüngliche Michael ist das leitende Oberhaupt der primären Paradies-Söhne, wenn sich diese in der Mitte aller Dinge zur Beratung versammeln.
<G-vec00443-002-s340><assemble.zusammenbauen><en> As an automotive parts subcontractor, we develop, optimize, die-cast, machine and assemble.
<G-vec00443-002-s340><assemble.zusammenbauen><de> Als automotiver Zulieferer werden die Komponenten entwickelt, optimiert, gegossen, mechanisch bearbeitet und zusammengebaut.
<G-vec00443-002-s341><assemble.zusammenbauen><en> The parts of valve includes two pieces body of valve, disc, gasket of valve disc, bush, two flanges, two gaskets of flange and the entire valve is assemble together with bolts and nuts.
<G-vec00443-002-s341><assemble.zusammenbauen><de> Die Teile des Ventils umfassen zwei Teile des Ventilkörpers, der Scheibe, der Dichtung der Ventilscheibe, der Buchse, zwei Flansche, zwei Dichtungen des Flansches, und das gesamte Ventil wird zusammen mit Schrauben und Muttern zusammengebaut.
<G-vec00443-002-s342><assemble.zusammenbauen><en> Merlin is delivered as a construction set that is quick and easy to assemble.
<G-vec00443-002-s342><assemble.zusammenbauen><de> Merlin wird als Bausatz geliefert, der schnell und einfach zusammengebaut werden kann.
<G-vec00443-002-s343><assemble.zusammenbauen><en> The e-cigarette is easy to use and is quick to assemble.
<G-vec00443-002-s343><assemble.zusammenbauen><de> Die E-Zigarette ist einfach zu handhaben und kann schnell zusammengebaut werden.
<G-vec00443-002-s331><assemble.zusammenbringen><en> 11 And it shall come to pass in that day, that the Lord shall set his hand again the second time to recover the remnant of his people, which shall be left, from Assyria, and from Egypt, and from Pathros, and from Cush, and from Elam, and from Shinar, and from Hamath, and from the islands of the sea. 12 And he shall set up an ensign for the nations, and shall assemble the outcasts of Israel, and gather together the dispersed of Judah from the four corners of the earth.
<G-vec00443-002-s331><assemble.zusammenbringen><de> 11:11 Und der HERR wird zu der Zeit zum andernmal seine Hand ausstrecken, daß er das Übrige seines Volks erkriege, so überblieben ist von den Assyrern, Ägyptern, Pathros, Mohrenland, Elamiten, Sinear, Hamath und von den Inseln des Meers, 11:12 und wird ein Panier unter die Heiden aufwerfen und zusammenbringen die Verjagten Israels und die Zerstreueten aus Juda zuhauf führen von den vier Örtern des Erdreichs.
<G-vec00443-002-s332><assemble.zusammenbringen><en> We’re telling America’s scientists and engineers that if they assemble teams of the best minds in their fields, and focus on the hardest problems in clean energy, we’ll fund the Apollo projects of our time.
<G-vec00443-002-s332><assemble.zusammenbringen><de> Wir sagen den amerikanischen Wissenschaftlern und Ingenieuren, wenn sie die besten Köpfe in ihren Bereichen zusammenbringen und sich in diesen Teams auf die schwierigsten Probleme im Bereich saubere Energien konzentrieren, dann werden wir die Apollo-Projekte unserer Zeit finanzieren.
<G-vec00443-002-s333><assemble.zusammenbringen><en> But his sons shall be stirred up, and shall assemble a multitude of great forces: and one shall certainly come, and overflow, and pass through: then shall he return, and be stirred up, even to his fortaleza.
<G-vec00443-002-s333><assemble.zusammenbringen><de> 10 Aber seine Söhne werden zornig werden und große Heere zusammenbringen; und der eine wird kommen und wie eine Flut daherfahren und wiederum Krieg führen bis vor seine Feste.
<G-vec00443-002-s334><assemble.zusammenbringen><en> 4:6 "In that day," declares the Lord, "I will gather the lame; I will assemble the exiles and those I have brought to grief.
<G-vec00443-002-s334><assemble.zusammenbringen><de> 4:6 Zur selben Zeit, spricht der HERR, will ich die Lahmen sammeln und die Verstoßenen zusammenbringen und die ich geplagt habe.
<G-vec00443-002-s335><assemble.zusammenfügen><en> Under the guidance of our trainees, interested students were able to create a metric M8 thread with a pitch of 1.25 mm and a flank angle of 60° and, using a CAD design program, create individual components and assemble them into modules.
<G-vec00443-002-s335><assemble.zusammenfügen><de> Unter der Leitung unserer Auszubildenden konnten die interessierten Schüler ein metrisches M8-Gewinde mit einer Steigung von 1,25 mm und einem Flankenwinkel von 60° herstellen und mit Hilfe eines CAD-Konstruktionsprogramms einzelne Bauteile erstellen und diese zu Baugruppen zusammenfügen.
<G-vec00443-002-s336><assemble.zusammenfügen><en> Users can easily select the individual test cases from a constantly growing database and assemble them into a new test run by drag-and-drop.
<G-vec00443-002-s336><assemble.zusammenfügen><de> Die Anwender können die einzelnen Testfälle einfach aus einer ständigen wachsenden Datenbank auswählen und per Drag-und-Drop zu einem neuen Testlauf zusammenfügen.
<G-vec00443-002-s338><assemble.zusammenfügen><en> Rummaging through vacant apartments and shuttered factories, Holmer Feldmann and Andreas Grahl amass truckloads of urinals, toys, eggcups, glass flasks, and other finds. Following Haze’s instructions, they assemble them in an extraordinary installation: the Cabinet.
<G-vec00443-002-s338><assemble.zusammenfügen><de> Holmer Feldmann und Andreas Grahl tragen aus leerstehenden Wohnungen und stillgelegten Fabriken lastwagenweise Urinale, Spielzeug, Eierbecher, Glaskolben und weitere Fundobjekte zusammen, die sie nach Hazes Anweisungen auf hunderten Quadratmetern zu einer außergewöhnlichen Installation zusammenfügen: dem Schrank.
<G-vec00443-002-s339><assemble.zusammenfügen><en> When you have all of the pieces cut and engraved, it's time to assemble the invitation.
<G-vec00443-002-s339><assemble.zusammenfügen><de> Nachdem alle Elemente geschnitten und graviert wurden, können Sie die Einladung zusammenfügen.
<G-vec00443-002-s348><assemble.zusammenkommen><en> Using the concept of "An event where the disabled from the world over assemble in one place, and through the shared culture of sports expand the spirit of friendship and international goodwill, and are able to find new possibilities nourished by dreams and courage" as our central theme, we welcomed the athletes of each country by burning hinoki incense at the athlete entrance and within the field during the opening ceremonies, welcoming them with fragrances suited to the location of the event.
<G-vec00443-002-s348><assemble.zusammenkommen><de> Mit dem Konzept „eine Veranstaltung, wo Behinderte aus aller Welt an einem Ort zusammenkommen, den Geist von Freundschaft und internationalem Wohlwollen durch die gemeinsame Kultur von Sport vertiefen und neue Möglichkeiten finden, die durch Träume und Mut genährt werden“ als zentrales Thema hießen wir die Athleten aus allen Ländern durch das Abbrennen von Weihrauch am Athleteneingang und auf dem Feld während der Eröffnungszeremonie willkommen mit Düften, die sich nahtlos in den Ort der Veranstaltung einfügten.
<G-vec00443-002-s350><assemble.zusammenkommen><en> Friday night graduations are another Scientology tradition—a time when Church staff and parishioners assemble to acknowledge those who have completed auditing or training steps in the previous week.
<G-vec00443-002-s350><assemble.zusammenkommen><de> Die Freitagabend-Graduierungen stellen eine weitere Scientology Tradition dar – eine Zeit, in der hauptamtliche Mitglieder der Kirche und Gemeindemitglieder zusammenkommen, um diejenigen zu bestätigen, die in der vergangenen Woche einen Auditing- oder Ausbildungs-Schritt abgeschlossen haben.
<G-vec00443-002-s195><assemble.zusammensetzen><en> The following levels build on these simple features and assemble them into more complex features.
<G-vec00443-002-s195><assemble.zusammensetzen><de> Die darauffolgenden Ebenen bauen auf diesen einfachen Features auf und setzen sie zu komplexeren Features zusammen.
<G-vec00443-002-s196><assemble.zusammensetzen><en> They assemble our cars, mow our lawns and assist with nursing.
<G-vec00443-002-s196><assemble.zusammensetzen><de> Sie setzen unsere Autos zusammen, mähen den Rasen und unterstützen bei der Krankenpflege.
<G-vec00443-002-s197><assemble.zusammensetzen><en> In small teams of around four people, the participants assemble real prosthetic hands for landmine victims.
<G-vec00443-002-s197><assemble.zusammensetzen><de> Gemeinsam setzen die Teilnehmer bei diesem Charity Event in kleinen Teams à vier Personen Handprothesen für Landminen-Opfer zusammen.
<G-vec00443-002-s198><assemble.zusammensetzen><en> Thus all that exists underlies continuous change; forms assemble and disintegrate again.
<G-vec00443-002-s198><assemble.zusammensetzen><de> Dadurch ist alles was existiert dem ständigem Wandel unterworfen; Formen setzen sich zusammen und lösen sich wieder auf.
<G-vec00443-002-s199><assemble.zusammensetzen><en> With the PANTHER puzzle, you can assemble the most successful airport fire-fighting vehicle in the world.
<G-vec00443-002-s199><assemble.zusammensetzen><de> Mit dem PANTHER Puzzle setzen sie den erfolgreichsten Airport Firefighter der Welt spielerisch zusammen.
<G-vec00443-002-s200><assemble.zusammensetzen><en> When you design a workflow, you identify the necessary sequence of actions, and then you assemble that sequence of actions in the Workflow Designer.
<G-vec00443-002-s200><assemble.zusammensetzen><de> Beim Entwerfen eines Workflows bestimmen Sie die erforderliche Sequenz von Aktionen, und dann setzen Sie diese Sequenz von Aktionen im Workflow-Designer zusammen.
<G-vec00443-002-s345><assemble.zusammenstellen><en> In the Applications menu, it is also possible to assemble an individualised array of services such as webcams, fuel price information, parking information, as well as travel and hotel guides.
<G-vec00443-002-s345><assemble.zusammenstellen><de> Zudem können Services wie Spritpreisinformationen, Parkinfos, Reise- und Hotelführer im Menü „Anwendungen“ individuell zusammengestellt werden.
<G-vec00443-002-s346><assemble.zusammenstellen><en> You can do this by creating a custom product in the system for the customer, and abas will come up with an estimate that gives you an approximated cost, measure the likelihood of the availability of the product, and provide a time frame in which it will take to assemble and deliver the product.
<G-vec00443-002-s346><assemble.zusammenstellen><de> Sie legen einen individuellen Artikel für den Kunden im System an, abas schätzt die ungefähren Kosten, beurteilt die Verfügbarkeit des Artikels und gibt eine Zeitspanne an, in der der Artikel zusammengestellt und geliefert werden kann.
<G-vec00443-002-s347><assemble.zusammenstellen><en> Now everyone can seamlessly merge scanned paper documents and over 150 electronic file formats on their desktop – with drag and drop simplicity, allowing individuals to manipulate and assemble new document types for sharing and archiving.
<G-vec00443-002-s347><assemble.zusammenstellen><de> Jetzt kann jeder gescannte Papierdokumente und über 150 elektronische Dateiformate auf dem Desktop zusammenführen – ganz einfach mit Drag & Drop, so dass neue Dokumenttypen zur Freigabe und Archivierung geändert und zusammengestellt werden können.
<G-vec00084-002-s042><assemble.aufbauen><en> To help ensure that your designs will assemble correctly, use SOLIDWORKS 3D design software to quickly check that all mating parts, mounting holes, and fasteners are aligned and that threads match.
<G-vec00084-002-s042><assemble.aufbauen><de> Stellen Sie sicher, dass Ihre Konstruktion korrekt aufgebaut werden kann, Montagebohrungen und Verbindungselemente richtig ausgerichtet sind und ob die Gewinde in der Baugruppenkonstruktion übereinstimmen.
<G-vec00084-002-s043><assemble.aufbauen><en> There are two possible versions to assemble the transmission unit: the 25:1 gear transmission ratio allows high speed driving, the 125:1 gear transmission ratio allows precise driving.
<G-vec00084-002-s043><assemble.aufbauen><de> Das Getriebe kann in zwei verschiedenen Varianten aufgebaut werden: die 25:1 Übersetzung ermöglicht eine hohe Geschwindigkeit, die 125:1 Übersetzung ermöglicht ein präzises Fahren des Roboters.
<G-vec00084-002-s044><assemble.aufbauen><en> The sturdy, mobile Etan TopShot Alley-Oop basketball hoop - quick to assemble, manually adjustable in height - start your workout right now and exercise your dunks.
<G-vec00084-002-s044><assemble.aufbauen><de> Der solide, mobile Etan TopShot Alley-Oop Basketballkorb - schnell aufgebaut, manuell höhenverstellbar und freibeweglich können Sie sofort loslegen und Ihre Wurfkünste trainieren.
<G-vec00084-002-s045><assemble.aufbauen><en> The number thrower, which is printed on both sides, is quick to assemble and can easily be used anywhere.
<G-vec00084-002-s045><assemble.aufbauen><de> Der beidseitig bedruckte Zahlenwerfer ist schnell aufgebaut und kann leicht an jedem Ort zum Einsatz kommen.
<G-vec00084-002-s046><assemble.aufbauen><en> It will take another six hours for the client’s service personnel to assemble the compact rotary indexing machine - it measures less than four metres in every dimension - and put it into operation.
<G-vec00084-002-s046><assemble.aufbauen><de> Noch gut 6 Stunden wird es dauern, bis die Servicemitarbeiter beim Auftraggeber den mit nicht einmal 4 mal 4 Metern platzsparend ausgeführten Rundschalttisch aufgebaut und in Betrieb genommen haben.
<G-vec00084-002-s047><assemble.aufbauen><en> This unit is simple to assemble and has the ideal aesthetics for installation (Imperial)
<G-vec00084-002-s047><assemble.aufbauen><de> Die Mittelraumeinheiten sind problemlos aufgebaut und haben die ideale Ästhetik für schöne Innenraumdisplays.
<G-vec00084-002-s048><assemble.aufbauen><en> Heiko Ramke, from the External Technical Service Team for Large Cranes at Ulferts & Wittrock, who handled the control levers of the LTM 1500-8.1 himself for some of the time, explained the situation on site. "The size of the area available meant that it was not initially possible to assemble the portal slewing crane on the rails.
<G-vec00084-002-s048><assemble.aufbauen><de> Heiko Ramke, Technischer Außendienst für Großkrane bei Ulferts & Wittrock, der bei diesem Einsatz zeitweise selbst an den Steuerhebeln des LTM 1500-8.1 saß, erklärt die Situation vor Ort: "Die Platzverhältnisse ließen es nicht zu, den Portalkran von Anfang an auf den Schienen aufzubauen.
<G-vec00084-002-s050><assemble.aufbauen><en> It is robust and easy to assemble and fold with its exclusive and sophisticated folding system.
<G-vec00084-002-s050><assemble.aufbauen><de> Er ist mit seinem exklusiven und ausgefeilten Klappsystem robust und leicht aufzubauen und zusammenzuklappen.
<G-vec00084-002-s051><assemble.aufbauen><en> Eventually, the Berlin Museum agreed to assemble a Jewish collection and to open a Jewish wing.
<G-vec00084-002-s051><assemble.aufbauen><de> Nach einiger Zeit willigte das Berlin Museum ein, eine jüdische Sammlung aufzubauen und eine jüdische Abteilung zu eröffnen.
<G-vec00084-002-s052><assemble.aufbauen><en> In order for the implementation to work, some conditions had to be met: The system had to be very robust, easy to assemble, and simple to operate.
<G-vec00084-002-s052><assemble.aufbauen><de> Für die Umsetzung galt es, einige Voraussetzung zu erfüllen: So muss das System sehr robust sein, einfach aufzubauen und einfach zu bedienen.
<G-vec00084-002-s053><assemble.aufbauen><en> Many of our light shapers such as softboxes and reflectors are collapsible and very simple to assemble. Therefore, they are ideally suited to outdoor shoots, since they are easy to transport.
<G-vec00084-002-s053><assemble.aufbauen><de> Viele unsere Lichtformer wie Softboxen und Reflektoren sind faltbar und sehr einfach aufzubauen, wodurch sie sich optimal für Outdoor-Shootings eignen, da sie leicht zu transportieren sind.
<G-vec00084-002-s054><assemble.aufbauen><en> 20 it is no longer possible to assemble tents, verandas or any structure in pitches.
<G-vec00084-002-s054><assemble.aufbauen><de> Nach 20:00 Uhr ist es verboten Zelte, Vorzelte und irgendeine Struktur aufzubauen.
<G-vec00084-002-s055><assemble.aufbauen><en> KEA furniture is actually not all that hard to assemble.
<G-vec00084-002-s055><assemble.aufbauen><de> Eigentlich sind IKEA-Möbel gar nicht so schwer aufzubauen.
<G-vec00084-002-s083><assemble.bauen><en> Assemble the SSD in a 2.5" to 3.5" bracket first and then mount the bracket in an empty HDD bay.
<G-vec00084-002-s083><assemble.bauen><de> Bauen Sie die SSD in den 2,5-Zoll-zu-3,5-Zoll-Einbaurahmen und dann den Einbaurahmen in ein leeres HDD-Fach ein.
<G-vec00084-002-s084><assemble.bauen><en> Rinse and dry the piercer and nozzle and then assemble back together before inserting back into the brewing unit.
<G-vec00084-002-s084><assemble.bauen><de> Spülen und trocknen Sie die Stanzvorrichtung und den Getränkeauslauf und bauen Sie diese wieder zusammen, bevor Sie sie wieder in die Brühvorrichtung zurücksetzen.
<G-vec00084-002-s100><assemble.fertigen><en> WIDE Automation S.r.l. was established in Pesaro, Italy, in 1985, aiming to design, assemble and sell components for industrial automation.
<G-vec00084-002-s100><assemble.fertigen><de> WIDE Automation S.r.l wird im Jahr 1985 in Pesaro mit dem Ziel gegründet, Komponenten für die industrielle Automation zu entwickeln, zu fertigen und dem Markt bereitzustellen.
<G-vec00084-002-s101><assemble.fertigen><en> We assemble sling chains and chain hangers grade 80, 100, 120 to measure for you.
<G-vec00084-002-s101><assemble.fertigen><de> Wir fertigen für Sie Anschlagketten in den Güteklassen 8, 10 und 12 nach Maß.
<G-vec00084-002-s158><assemble.montieren><en> DCP05 is a 3D software integrated onboard the Leica Geosystems Industrial Laser Stations to quickly inspect and assemble parts, even based on design data
<G-vec00084-002-s158><assemble.montieren><de> DCP05 ist eine 3D-Software, die mit jeder Leica TDRA6000 Laser Station mitgeliefert wird, um Teile schnell prüfen und montieren zu können, und das auf der Grundlage von Konstruktionsdaten.
<G-vec00084-002-s159><assemble.montieren><en> We manufacture mechanical sub-assemblies and assemble highly complex, high-precision systems, while guaranteeing a very secure source of supply.
<G-vec00084-002-s159><assemble.montieren><de> Wir fertigen für Sie mechanische Baugruppen und montieren hochkomplexe und präzise Systeme und können Ihnen eine äußerst sichere Lieferquelle garantieren.
<G-vec00084-002-s160><assemble.montieren><en> Because of their very long and bulky lengths, special handling methods were devised to assemble the anchors, factory pre-grout the 8m bond length, coil the free lengths and transport them to the project site.
<G-vec00084-002-s160><assemble.montieren><de> Da die Anker äußerst lang und sperrig sind, mussten spezielle Handhabungsmethoden entwickelt werden, um sie montieren zu können, die Verbundlängen von 8 m im Werk vorzupressen, die freie Länge aufzurollen und die Anker zu transportieren.
<G-vec00084-002-s162><assemble.montieren><en> • Assemble the sealing plate between radiator and engine hood, avoid the hot air reflow and make sure the cooling effect.
<G-vec00084-002-s162><assemble.montieren><de> • Montieren Sie die Dichtungsplatte zwischen Kühler und Motorhaube, vermeiden Sie das Nachströmen von Heißluft und achten Sie auf die Kühlwirkung.
<G-vec00084-002-s163><assemble.montieren><en> 1/ Assemble the support cradle
<G-vec00084-002-s163><assemble.montieren><de> 1/ Montieren Sie die Stützbalken.
<G-vec00084-002-s164><assemble.montieren><en> Then attach the axle to the door frame and assemble the box finally.
<G-vec00084-002-s164><assemble.montieren><de> Dann befestigen Sie die Achse am Türrahmen und montieren Sie die Box schließlich.
<G-vec00084-002-s165><assemble.montieren><en> Assemble a movie in mere minutes.
<G-vec00084-002-s165><assemble.montieren><de> Montieren Sie einen Film in nur wenigen Minuten.
<G-vec00084-002-s166><assemble.montieren><en> Assemble the hubs onto the shaft of driving and driven side.
<G-vec00084-002-s166><assemble.montieren><de> Montieren Sie die Naben auf die Welle der An- und Abtriebsseite.
<G-vec00084-002-s167><assemble.montieren><en> To install a continuous line of fire, just assemble the modular water vapor inserts from the AFIREWATER ADVANCE line.
<G-vec00084-002-s167><assemble.montieren><de> Um eine kontinuierliche Feuerlinie zu installieren, montieren Sie einfach die modularen Wasserdampf Einsätze von der AFIREWATER-ADVANCE-Linie.
<G-vec00084-002-s168><assemble.montieren><en> They will assemble it for you for a small expense allowance.
<G-vec00084-002-s168><assemble.montieren><de> Dieser montiert es dir für eine kleine Aufwandsentschädigung.
<G-vec00084-002-s169><assemble.montieren><en> A Titanium tent is made of a hot-dip galvanized steel frame, which is stable, durable and easy to assemble.
<G-vec00084-002-s169><assemble.montieren><de> Ein Titanium-Zelt besteht aus einem feuerverzinkten Stahlrahmen, der stabil und robust ist und leicht montiert werden kann.
<G-vec00084-002-s170><assemble.montieren><en> The tents are easy to assemble if you are two or more to help.
<G-vec00084-002-s170><assemble.montieren><de> Die Zelte können leicht montiert werden, wenn zwei oder mehr Personen sich unterstützen.
<G-vec00084-002-s171><assemble.montieren><en> Our indicators correspond in form and function to the original indicators and will be easy assemble in exchange on the original bracket.
<G-vec00084-002-s171><assemble.montieren><de> Unsere Blinker entsprechen in Form und Funktion den originalen Blinkern und werden einfach im Tausch an die Originalhalterung montiert.
<G-vec00084-002-s173><assemble.montieren><en> It can be used to disassemble, assemble and adjust both first generation dry double clutches (up to May 2011) and second generation dry double clutches (from June 2011) in vehicles manufactured by Audi, Seat, Škoda and Volkswagen with a 0AM transmission.
<G-vec00084-002-s173><assemble.montieren><de> Damit können sowohl trockene Doppelkupplungen der ersten Generation (bis Produktionsdatum 05.2011), als auch der zweiten Generation (ab Produktionsdatum 06.2011) bei Fahrzeugen der Marken Audi, Seat, Skoda und Volkswagen mit Getriebetyp 0AM demontiert, montiert und eingestellt werden.
<G-vec00084-002-s174><assemble.montieren><en> The galvanised racks are adjustable in height every 25 mm and are easy to assemble.
<G-vec00084-002-s174><assemble.montieren><de> Die verzinkten Steckregale mit im Raster von 25 mm höhenverstellbaren Regalebenen sind leicht montiert.
<G-vec00084-002-s175><assemble.montieren><en> A manufacturer of electronic, electrical and fibre optic connection systems assemble electronic components onto flexible thin film circuits to be used for automotive computers.
<G-vec00084-002-s175><assemble.montieren><de> Ein Hersteller elektronischer, elektrischer und faseroptischer Verbindungssysteme montiert elektronische Bauteile auf biegsame Dünnschichtschaltungen, die für Automobilcomputer verwendet werden.
<G-vec00084-002-s176><assemble.montieren><en> With just a single operator, the machine can assemble up to one thousand valves per hour, around the clock. That is 30 percent more than in the past.
<G-vec00084-002-s176><assemble.montieren><de> Mit nur einem Bediener montiert die Maschine rund um die Uhr nun bis zu 1.000 Ventile pro Stunde – das sind 30 Prozent mehr als bisher.
<G-vec00084-002-s177><assemble.montieren><en> A concrete example: imagine a car assembly line in which one robot can assemble a wheel and another the bonnet, while employees work alongside on higher value-added tasks.
<G-vec00084-002-s177><assemble.montieren><de> Ein konkretes Beispiel: Stellen Sie sich eine Montagelinie in der Automobilindustrie vor, wo ein Roboter etwa ein Rad montiert, ein anderer die Kühlerhaube, gleichzeitig arbeiten Bediener an ihrer Seite und erledigen Aufgaben mit höherem Mehrwert.
<G-vec00084-002-s178><assemble.montieren><en> And you are ready to assemble the furniture.
<G-vec00084-002-s178><assemble.montieren><de> Schon kann der Möbelkorpus montiert werden.
<G-vec00084-002-s179><assemble.montieren><en> Wachendorff also ensures that the encoder is easy to assemble and arrives logistically sensible to the customer.
<G-vec00084-002-s179><assemble.montieren><de> Wachendorff stellt zudem sicher, dass der Drehgeber einfach montiert und logistisch sinnvoll zum Kunden kommt.
<G-vec00084-002-s180><assemble.montieren><en> This fixture comes with suspension brackets and fasteners, making it easy and quick to assemble.
<G-vec00084-002-s180><assemble.montieren><de> Diese Halterung wird mit Aufhängebügeln und Befestigungselementen geliefert, so dass sie einfach und schnell montiert werden kann.
<G-vec00084-002-s181><assemble.montieren><en> They assemble roughly 22,000 showroom kitchens every year.
<G-vec00084-002-s181><assemble.montieren><de> An die 22.000 Ausstellungsküchen werden von ihnen pro Jahr montiert.
<G-vec00084-002-s056><assemble.zusammenbauen><en> Assemble your spaceship while shooting at meteors coming your way, grab the fuels and get away from...
<G-vec00084-002-s056><assemble.zusammenbauen><de> Baue dein Raumschiff zusammen, während du auf Meteore schießt, die auf deinem Weg sind, schnapp dir...
<G-vec00084-002-s057><assemble.zusammenbauen><en> Sometimes I paint them in different colours (like the FROSTA stools), or I use them as a frame (like the KURA bed in Felix’s room), or I assemble them differently (like the VITTSJÖ coffee table).
<G-vec00084-002-s057><assemble.zusammenbauen><de> Manchmal streiche ich sie farbig (wie die FROSTA Hocker), oder ich benutze sie als Gerüst (wie das KURA Bett in Felix’ Zimmer), oder ich baue sie anders zusammen (wie den VITTSJÖ Couchtisch).
<G-vec00084-002-s058><assemble.zusammenbauen><en> Assemble it and play.
<G-vec00084-002-s058><assemble.zusammenbauen><de> Baue ihn zusammen und spiele.
<G-vec00084-002-s059><assemble.zusammenbauen><en> Assemble this small lion head and give it a nice spot in your room.
<G-vec00084-002-s059><assemble.zusammenbauen><de> Baue dieses Giraffenköpfchen zusammen und gib ihm einen schönen Platz in deinem Zimmer.
<G-vec00084-002-s060><assemble.zusammenbauen><en> Discover shipwrecks and underwater ruins, take a swing at the Drowned for a chance to earn a mighty trident, or assemble the awesome conduit.
<G-vec00084-002-s060><assemble.zusammenbauen><de> Entdecke Schiffswracks und Unterwasserruinen, kämpfe gegen die Ertrunkenen, um an einen mächtigen Dreizack zu kommen, oder baue den fantastischen Aquisator zusammen.
<G-vec00084-002-s061><assemble.zusammenbauen><en> Assemble the main board with all the parts but do not put the ICs into the sockets.
<G-vec00084-002-s061><assemble.zusammenbauen><de> Baue die Hauptplatine mit allen Teilen zusammen, aber stecke die ICs noch nicht in die Sockel.
<G-vec00084-002-s085><assemble.zusammenbauen><en> Over hours and days, they assemble more than one hundred parts.
<G-vec00084-002-s085><assemble.zusammenbauen><de> Über Stunden und Tage bauen sie mehr als hundert Teile zusammen.
<G-vec00084-002-s087><assemble.zusammenbauen><en> Then we patiently assemble the skeleton from the neck down to the soles of the feet and to the palms of the hands.
<G-vec00084-002-s087><assemble.zusammenbauen><de> Dann bauen wir geduldig das Skelett vom Hals bis zu den Fußsohlen und Handflächen zusammen.
<G-vec00084-002-s088><assemble.zusammenbauen><en> Plumber at work in a bathroom, plumbing repair service, assemble.
<G-vec00084-002-s088><assemble.zusammenbauen><de> Klempner bei der Arbeit in einem Badezimmer, Reparaturservice plombierend, bauen zusammen.
<G-vec00084-002-s089><assemble.zusammenbauen><en> Polymechanics (Polymechaniker EFZ) manufacture workpieces, manufacture tools and devices for production and assemble equipment, devices, machines and installations.
<G-vec00084-002-s089><assemble.zusammenbauen><de> Polymechanikerinnen EFZ und Polymechaniker EFZ fertigen Werkstücke, stellen Werkzeuge und Vorrichtungen für die Produktion her und bauen Geräte, Apparate, Maschinen und Anlagen zusammen.
<G-vec00084-002-s090><assemble.zusammenbauen><en> You manually or automatically process material and assemble mechanical, electro-mechanical, electric and electronic components to mechatronic systems.
<G-vec00084-002-s090><assemble.zusammenbauen><de> Sie bearbeiten manuell und maschinell Werkstoffe und bauen mechanische, elektromechanische, elektrische und elektronische Komponenten zu mechatronischen Systemen zusammen.
<G-vec00084-002-s300><assemble.zusammenbauen><en> This set is easy to assemble.
<G-vec00084-002-s300><assemble.zusammenbauen><de> Dieses Set ist einfach zusammen zu bauen.
<G-vec00084-002-s301><assemble.zusammenbauen><en> Information Format 230x230x100 / 160x160x100 / 160x300x100mm, This set is easy to assemble.
<G-vec00084-002-s301><assemble.zusammenbauen><de> Informationen Format 230x230x100 / 160x160x100 / 160x300x100mm, Dieses Set ist einfach zusammen zu bauen.
<G-vec00084-002-s302><assemble.zusammenbauen><en> You'll need scissors, glue, a ruler, and a pencil to help you assemble the bag
<G-vec00084-002-s302><assemble.zusammenbauen><de> Du brauchst eine Schere, Klebstoff, ein Lineal und einen Bleistift, um die Tüte zusammen zu bauen.
<G-vec00084-002-s303><assemble.zusammenbauen><en> €17,95 Click to enlarge With the 6-in-1 Solar Kit you can assemble 6 different robots.
<G-vec00084-002-s303><assemble.zusammenbauen><de> Mit dem 6-in-1 Solar Kit kannst du 6 verschiedenen Roboter zusammen bauen, wie zum Beispiel: ein Boot, ein Auto, eine Windmühle oder Flugzeuge.
<G-vec00084-002-s312><assemble.zusammenbauen><en> Model building kits are available for slightly older children, allowing them to assemble vehicles largely independently.
<G-vec00084-002-s312><assemble.zusammenbauen><de> Schon für etwas ältere Kinder sind Modellbau-Sets verfügbar, mit denen sie weitgehend selbstständig Fahrzeuge zusammenbauen können.
<G-vec00084-002-s313><assemble.zusammenbauen><en> 9.Easy Assembly: Integrated design, you can assemble or disassemble it in 20 minutes with the operation instruction.
<G-vec00084-002-s313><assemble.zusammenbauen><de> Versammlung 9.Easy: Integrierter Entwurf, können Sie ihn in 20 Minuten mit der Operationsanweisung zusammenbauen oder auseinanderbauen.
<G-vec00084-002-s315><assemble.zusammenbauen><en> Es To those, who have never seen my paintings in the original, I would like to point out, that I do not paint on canvas, but on plywood-frames, that we assemble ourselves.
<G-vec00084-002-s315><assemble.zusammenbauen><de> Diejenigen, die meine Bilder noch nie im Original gesehen haben, möchte ich darauf hinweisen, dass ich nicht auf mit Leinwand bespannte Keilrahmen male, sondern auf Sperrholzrahmen, die wir selbst zusammenbauen.
<G-vec00084-002-s316><assemble.zusammenbauen><en> Whether they design, manufacture, assemble, test, install, sale or service machine, it goes without saying that NUMALLIANCE would not be alike, without the men and women that everyday looks at new ways to bend and going beyond bending.
<G-vec00084-002-s316><assemble.zusammenbauen><de> Menschliche Werte Ohne die Frauen und Männer, die jeden Tag die Maschinen entwickeln, herstellen, zusammenbauen, prüfen, installieren, verkaufen oder warten, und Lösungen für ihre Kunden zu verbessern suchen, wäre Numalliance nicht die Gruppe, die sie ist.
<G-vec00084-002-s317><assemble.zusammenbauen><en> Shadow Box 200 x 155 x 33 mm, easy to assemble.
<G-vec00084-002-s317><assemble.zusammenbauen><de> Shadow Box 200 x 155 x 33 mm, einfach zum zusammenbauen.
<G-vec00084-002-s318><assemble.zusammenbauen><en> Subassemblies will be made on my order by other companies, and in Sokołów we will assemble aggregates – he plans.
<G-vec00084-002-s318><assemble.zusammenbauen><de> Unterbaugruppen werden auf meine Bestellung von anderen Unternehmen hergestellt, und in Sokołów werden wir Aggregate zusammenbauen – er plant.
<G-vec00084-002-s319><assemble.zusammenbauen><en> While some companies simply assemble purchased parts, our vertical integration of product manufacturing allows tight control of all procedures.
<G-vec00084-002-s319><assemble.zusammenbauen><de> Während einige Unternehmen nur eingekaufte Teile zusammenbauen, ermöglicht unsere vertikale Integration der Produktfertigung eine strenge Kontrolle aller Verfahren.
<G-vec00084-002-s320><assemble.zusammenbauen><en> It is now so simple to assemble and view stylus systems for your applications on any PC with the new Stylus System Creator (SSC) standalone software.
<G-vec00084-002-s320><assemble.zusammenbauen><de> Mit der neuen Stylus System Creator (SSC) Standalone Software können Sie jetzt auf jedem PC Tastersysteme für Ihre Anwendungen kinderleicht zusammenbauen und anschauen.
<G-vec00084-002-s324><assemble.zusammenbauen><en> We come with our trucks with containers. Inside the containers you have robots ready to assemble the car.
<G-vec00084-002-s324><assemble.zusammenbauen><de> Dann kommen wir mit unseren LKW und Anhängern, in denen Roboter die Autos zusammenbauen.
<G-vec00084-002-s325><assemble.zusammenbauen><en> With the parts and semi-finished products of Van Egmond Group, OEMs and manufacturing industry can assemble machines.
<G-vec00084-002-s325><assemble.zusammenbauen><de> Mit den Bauteilen und Halbzeugen der Van Egmond Groep können OEMs und das verarbeitende Gewerbe Maschinen zusammenbauen.
<G-vec00084-002-s326><assemble.zusammenbauen><en> Parents can assemble the stroller according to their desire.
<G-vec00084-002-s326><assemble.zusammenbauen><de> Eltern können den Kinderwagen nach ihren Wünschen zusammenbauen.
<G-vec00084-002-s327><assemble.zusammenbauen><en> BoConcept Design Team Assembly instructions This product is easy to assemble.
<G-vec00084-002-s327><assemble.zusammenbauen><de> Armlehne: 16 kg/m3 PolyurethanschaumDieses Produkt lässt sich leicht zusammenbauen.
<G-vec00084-002-s328><assemble.zusammenbauen><en> In general, the design of the gable roof system is considered very simple, and a team of professional builders can assemble it "from scratch" in less than a day.
<G-vec00084-002-s328><assemble.zusammenbauen><de> Im Allgemeinen wird das Design des Giebeldachsystems als sehr einfach angesehen, und ein Team von professionellen Bauherren kann es in weniger als einem Tag "von Grund auf" zusammenbauen.
<G-vec00084-002-s329><assemble.zusammenbauen><en> Twice slats are slipped out, I had to assemble again until.
<G-vec00084-002-s329><assemble.zusammenbauen><de> Zweimal sind Latten rausgerutscht, die ich erst wieder zusammenbauen musste.
<G-vec00084-002-s330><assemble.zusammenbauen><en> Whether as bedside lamp or fancy floor lamp in the living room - the tripod frames can be used to quickly assemble exceptional light constructions.
<G-vec00084-002-s330><assemble.zusammenbauen><de> Egal, ob als Nachttischleuchte oder ausgefallene Stehleuchte im Wohnzimmer, mit den Tripod-Gestellen lassen sich im Nu ausgefallene Lichtkonstruktionen zusammenbauen.
<G-vec00084-002-s390><assemble.zusammenbauen><en> Afterwards, you will have the chance to assemble a watch with dial, hands, crown and winding stem and then take it home with you.
<G-vec00084-002-s390><assemble.zusammenbauen><de> Anschliessend haben Sie die Gelegenheit, eine Uhr, die Sie anschließend behalten dürfen, zusammenzubauen und sie dabei mit Zifferblatt, Zeiger, Krone und Aufzugswelle zu versehen.
<G-vec00084-002-s391><assemble.zusammenbauen><en> + Compared to round logs, square logs take up less space during transportation and are easier to assemble.
<G-vec00084-002-s391><assemble.zusammenbauen><de> + Im Vergleich mit Rundbohlen benötigen Blockbohlen beim Transport weniger Platz und sind einfacher zusammenzubauen.
<G-vec00084-002-s392><assemble.zusammenbauen><en> It is really solid, easy to assemble and wonderfully simple in design.
<G-vec00084-002-s392><assemble.zusammenbauen><de> Es ist wirklich solide, einfach zusammenzubauen und wunderbar schlicht im Design.
<G-vec00084-002-s393><assemble.zusammenbauen><en> 3) Easy to buld up, only need 2 mimuts to assemble it well.
<G-vec00084-002-s393><assemble.zusammenbauen><de> 3) Einfach zum buld oben, benötigen Sie nur 2 mimuts, es gut zusammenzubauen.
<G-vec00084-002-s394><assemble.zusammenbauen><en> It is easy to assemble or disassemble and transport them.
<G-vec00084-002-s394><assemble.zusammenbauen><de> Es ist einfach, sie zusammenzubauen oder auseinanderzubauen und zu transportieren.
<G-vec00084-002-s395><assemble.zusammenbauen><en> The shoring tower is safe and convenient, easy and flexible to assemble and disassemble, has good bearing capacity, can be widely used in construction.
<G-vec00084-002-s395><assemble.zusammenbauen><de> Der Stützbalkenturm ist sicher und bequem, einfach und flexibel zusammenzubauen und auseinanderzubauen, hat gute Tragfähigkeit, kann im Bau weit verbreitet sein.
<G-vec00084-002-s396><assemble.zusammenbauen><en> 3)Easy to disassemble and assemble.
<G-vec00084-002-s396><assemble.zusammenbauen><de> 3) Einfach auseinanderzubauen und zusammenzubauen....
<G-vec00084-002-s398><assemble.zusammenbauen><en> Eva foam is durable, non-toxic, premium foam that is lightweight and easy to assemble.
<G-vec00084-002-s398><assemble.zusammenbauen><de> Eva-Schaum ist haltbarer, ungiftiger, erstklassiger Schaum, der leicht und einfach zusammenzubauen ist.
<G-vec00084-002-s399><assemble.zusammenbauen><en> 5)Easy to assemble,Save freight cost and labor cost.
<G-vec00084-002-s399><assemble.zusammenbauen><de> 5)Einfach, Frachtkosten und Arbeitskosten zusammenzubauen, zu sparen.
<G-vec00084-002-s400><assemble.zusammenbauen><en> With this refrigerated pizza prep table, you'll be able to store and assemble ingredients all in the same area of the kitchen, exp editing the food preparation process.
<G-vec00084-002-s400><assemble.zusammenbauen><de> Mit dieser gekühlten Pizzavorbereitungstabelle sind Sie in der Lage, Bestandteile alle im gleichen Bereich der Küche zu speichern und zusammenzubauen, exp den Lebensmittelzubereitungsprozeß redigierend.
<G-vec00084-002-s401><assemble.zusammenbauen><en> Synthetic biology uses tools from genetic engineering to design, create, and assemble living organisms with a particular function.
<G-vec00084-002-s401><assemble.zusammenbauen><de> Die synthetische Biologie nutzt Werkzeuge aus der Gentechnik, um lebende Organismen mit besonderen Funktionen zu entwerfen und zusammenzubauen.
<G-vec00084-002-s402><assemble.zusammenbauen><en> This self-aligned tank turning roll is used to weld, polish and assemble the cylinder-shells, and to line the shells with rubber.
<G-vec00084-002-s402><assemble.zusammenbauen><de> Diese selbst-ausgerichtete Behälterdrehenrolle wird, um die Zylinderoberteile zu schweißen, zu polieren und zusammenzubauen, benutzt und die Oberteile mit Gummi zu zeichnen.
<G-vec00084-002-s403><assemble.zusammenbauen><en> Easy to assemble and most likely quite easy to paint, as a simple white dry brush might give you a satisfying result.
<G-vec00084-002-s403><assemble.zusammenbauen><de> Einfach zusammenzubauen und einfach zu bemalen, im Grunde würde wohl schon ein weißes Trockenbürsten zu einem guten Ergebnis führen.
<G-vec00084-002-s404><assemble.zusammenbauen><en> We use conductive silver paste to assemble LED or other components.
<G-vec00084-002-s404><assemble.zusammenbauen><de> Wir verwenden leitfähige Silberpaste, um LED oder andere Komponenten zusammenzubauen.
<G-vec00084-002-s407><assemble.zusammenbauen><en> R R PORTABLE FORCED AIR HEATERS SAFETY INFORMATION WARNINGS IMPORTANT: Read this owner’s manual carefully and completely before trying to assemble, operate, or service this heater.
<G-vec00084-002-s407><assemble.zusammenbauen><de> R R TRAGBARE HOCHDRUCK-HEISSLUFTTURBINEN SICHERHEITSINFORMATIONEN WARNHINWEISE WICHTIG: Lesen Sie diese Bedienungsanleitung sorgfaltig und vollstandig durch, bevor Sie versuchen, dieses Heizgerat zusammenzubauen, zu bedienen oder zu war- ten.
<G-vec00084-002-s408><assemble.zusammenbauen><en> The main reason that most our customer are fond of our transparent aluminum tent is that the aluminum tent structure is easy to assemble and disassemble, so it is very convenient to move the transparent tent from one place to another, and it only takes little time.
<G-vec00084-002-s408><assemble.zusammenbauen><de> Der Hauptgrund, dass der meiste unser Kunde in unser transparentes Aluminiumzelt vernarrt sind, ist, dass die Aluminiumzeltstruktur einfach zusammenzubauen und auseinanderzubauen ist, also es ist sehr bequem, das transparente Zelt von einem Platz auf andere zu verschieben, und es dauert nur wenig Zeit.
<G-vec00084-002-s409><assemble.zusammenfügen><en> Most clients would want an added-value brick to simplify their operations, but larger clients or more secretive clients would require simpler bricks to assemble and enhance information by themselves, possibly with other suppliers.
<G-vec00084-002-s409><assemble.zusammenfügen><de> Die meisten Kunden würden eine Komponente mit Mehrwert zur Vereinfachung ihrer Geschäfte bevorzugen, doch größere oder verschlossenere Kunden würden einfachere Bausteine benötigen, um Informationen selber zusammenzufügen und zu verbessern, wahrscheinlich auch mit anderen Anbietern.
<G-vec00084-002-s410><assemble.zusammenfügen><en> The questioner now searches for as many halves of the picture as possible in order to assemble them into whole pictures.
<G-vec00084-002-s410><assemble.zusammenfügen><de> Der Frager sucht nun nach möglichst vielen zusammengehörigen Bildhälften, um sie zu ganzen Bildern zusammenzufügen.
<G-vec00084-002-s411><assemble.zusammenfügen><en> The Arctic Governance Project aims to capture and assemble the best of these research efforts in order to lay the foundation for the way forward and communicate conclusions to policymakers.
<G-vec00084-002-s411><assemble.zusammenfügen><de> Das Arctic Governance Projekt zielt darauf ab, die erfolgreichsten dieser Forschungsbemühungen zu erfassen und zusammenzufügen, um ein Fundament für den weiteren Weg zu bilden und Ergebnisse an politische Entscheidungsträger zu kommunizieren.
<G-vec00084-002-s192><assemble.zusammensetzen><en> They will stroll through Heiner Müller's "Dream Forest" or assemble objects to bring Gustav Falke's "Foolish Dreams" back together.
<G-vec00084-002-s192><assemble.zusammensetzen><de> Sie durchschreiten Heiner Müllers "Traumwald" oder setzen aus Objekten Gustav Falkes "Närrische Träume" zusammen.
<G-vec00084-002-s193><assemble.zusammensetzen><en> Robots then assemble the finished lenses into the smartphone camera.
<G-vec00084-002-s193><assemble.zusammensetzen><de> Roboter setzen die fertigen Linsen dann in die Smartphone-Kamera ein.
<G-vec00084-002-s194><assemble.zusammensetzen><en> Assemble them in a set.
<G-vec00084-002-s194><assemble.zusammensetzen><de> Setzen Sie sie in einem Set.
<G-vec00084-002-s352><assemble.zusammensetzen><en> Fill the two mushrooms with 15g of stuffing each, then assemble them.
<G-vec00084-002-s352><assemble.zusammensetzen><de> Die beiden Pilze mit jeweils 15 g Füllung garnieren, dann zusammensetzen.
<G-vec00084-002-s353><assemble.zusammensetzen><en> Learn how to unroll, print out and assemble a 3D model from a sheet of paper.
<G-vec00084-002-s353><assemble.zusammensetzen><de> In diesem Video lernen Sie das Abwickeln, Drucken und Zusammensetzen eines 3D-Modells aus einem Blatt Papier.
<G-vec00084-002-s354><assemble.zusammensetzen><en> The ArcGIS Pro application allows you to assemble all the resources required to complete a project in one place.
<G-vec00084-002-s354><assemble.zusammensetzen><de> Die ArcGIS Pro-Anwendung ermöglicht Ihnen das Zusammensetzen sämtlicher Ressourcen, die zum Abschließen eines Projekts an zentraler Stelle erforderlich sind.
<G-vec00084-002-s355><assemble.zusammensetzen><en> Remove 10 mm of bark from the branches at the bottom of the legs and grind them a bit to make it easier to assemble the animal.
<G-vec00084-002-s355><assemble.zusammensetzen><de> Bei den Beinen entfernen Sie unten an den Ästen 10 mm Rinde und spitzen diese etwas an, damit sich das Tier leichter zusammensetzen lässt.
<G-vec00084-002-s356><assemble.zusammensetzen><en> As with the Soma cube, you can use the L4 puzzle to assemble a cube and many other three-dimensional figures.
<G-vec00084-002-s356><assemble.zusammensetzen><de> Wie beim Soma-Würfel kann man mit dem L4-Puzzle einen Würfel und viele andere dreidimensionale Figuren zusammensetzen.
<G-vec00084-002-s358><assemble.zusammensetzen><en> To assemble the layer cake, place the first sponge cake on a cake stand.
<G-vec00084-002-s358><assemble.zusammensetzen><de> Zum Zusammensetzen den ersten Tortenboden auf eine Tortenplatte legen.
<G-vec00084-002-s359><assemble.zusammensetzen><en> A query can pull the information from various tables and assemble it for display in the form or report.
<G-vec00084-002-s359><assemble.zusammensetzen><de> Eine Abfrage kann die Informationen aus verschiedenen Tabellen abrufen und zusammensetzen, damit sie im Formular oder Bericht angezeigt werden können.
<G-vec00084-002-s360><assemble.zusammensetzen><en> Eight of these 20 so-called proteinogenic amino acids must necessarily be absorbed through the diet, because the organism can not assemble them from other substances.
<G-vec00084-002-s360><assemble.zusammensetzen><de> Acht dieser 20 sogenannten proteinogenen Aminosäuren müssen zwingend über die Nahrung aufgenommen werden, weil der Organismus sie nicht aus anderen Stoffen zusammensetzen kann.
<G-vec00084-002-s361><assemble.zusammensetzen><en> You can then assemble the overlapping sections.
<G-vec00084-002-s361><assemble.zusammensetzen><de> Die überlappenden Bereiche können Sie anschließend zusammensetzen.
<G-vec00084-002-s362><assemble.zusammensetzen><en> But that was exactly what I didn’t want. I wanted to assemble the picture out of clearly distinct elements and obtain an organic picture at the end nonetheless.
<G-vec00084-002-s362><assemble.zusammensetzen><de> Aber genau das wollte ich ja nicht, sondern ich wollte das Bild aus deutlich unterschiedenen Elementen zusammensetzen, um am Ende trotzdem ein organisches Bild zu haben.
<G-vec00084-002-s363><assemble.zusammensetzen><en> Assemble your clips Learn tips for adding short and long clips to the timeline, inserting In and Out points, shuttling around the timeline using keyboard shortcuts, and understanding track indicators.
<G-vec00084-002-s363><assemble.zusammensetzen><de> Clips zusammensetzen Lernen Sie, wie Sie kurze und lange Clips zum Schnittfenster hinzufügen, In- und Out-Points einfügen, per Tastaturbefehl innerhalb des Schnittfensters navigieren und Spurenmarken interpretieren.
<G-vec00084-002-s364><assemble.zusammensetzen><en> “Subdividing the line into independent modules that we can assemble and test individually was our first choice,” emphasizes Italo Busto, project manager at O.M.G.
<G-vec00084-002-s364><assemble.zusammensetzen><de> „Die Unterteilung der Linie in unabhängige Module, die wir einzeln zusammensetzen und testen können, war unsere erste Wahl“, betont deshalb Italo Busto, Projektleiter bei O.M.G.
<G-vec00084-002-s366><assemble.zusammensetzen><en> By breaking apart layers in basic clip art, you can cut different pieces and assemble them to create a decoration that has depth and dimension.
<G-vec00084-002-s366><assemble.zusammensetzen><de> Durch die Aufteilung einer Illustration in mehrere Ebenen können Sie verschiedene Elemente ausschneiden und zusammensetzen, um Tiefe und Dimension zu erzeugen.
<G-vec00084-002-s412><assemble.zusammensetzen><en> Kapitel 1: This page helps you to assemble cube structure and PCB to the fully functional LED Cube.
<G-vec00084-002-s412><assemble.zusammensetzen><de> Diese Seite wird dir helfen die Cubestruktur und die Platine zu einem voll funktionsfähigen LED Cube zusammenzusetzen.
<G-vec00084-002-s413><assemble.zusammensetzen><en> You need to move them so as to assemble the picture.
<G-vec00084-002-s413><assemble.zusammensetzen><de> Sie müssen sie verschieben, um das Bild zusammenzusetzen.
<G-vec00084-002-s414><assemble.zusammensetzen><en> Therefore, robots should learn to find their own solution in inadequately defined situations by trial and error and assemble the promising elements into a new and better solution.
<G-vec00084-002-s414><assemble.zusammensetzen><de> Roboter sollen also lernen, in unzureichend definierten Situationen durch Versuch und Irrtum eine eigene Lösung zu finden und die erfolgsversprechenden Elemente zu einer neuen, besseren Lösung zusammenzusetzen.
<G-vec00084-002-s415><assemble.zusammensetzen><en> Easy to assemble in a closed groove, depending on the minimum diameter values indicated in the table below.
<G-vec00084-002-s415><assemble.zusammensetzen><de> Leicht in eine geschlossene Nut zusammenzusetzen, in Abhängigkeit von den minimalen Durchmesser Werte in der folgenden Tabelle angegeben.
<G-vec00084-002-s416><assemble.zusammensetzen><en> Everyone who tries to make some electronic device first starts with the schematics, and then makes a printed circuit board (PCB) which is later used to assemble all the components of some specific device.
<G-vec00084-002-s416><assemble.zusammensetzen><de> Jeder, der ein elektronisches Gerät zu bauen versucht, beginnt zuerst mit den Plänen und erstellt dann eine gedruckte Schaltung [printed circuit board, PCB], die später gebraucht wird, um alle Komponenten des Gerätes zusammenzusetzen.
<G-vec00084-002-s417><assemble.zusammensetzen><en> For film scholar Noël Burch, film history begins with a “Frankenstein-like dream” of control: the film medium dismembers animated life into dead fragments to then assemble and reanimate them under its own power.
<G-vec00084-002-s417><assemble.zusammensetzen><de> Für Filmwissenschaftler Noël Burch beginnt die Filmgeschichte mit einem „Frankenstein’schen Traum“ der Verfügungsgewalt: Das Medium Film zerstückelt bewegtes Leben in tote Fragmente, um sie dann aus eigener Kraft neu zusammenzusetzen und zu reanimieren.
<G-vec00084-002-s419><assemble.zusammensetzen><en> This allowed them to sequence and assemble the 750 million nucleotides, that make up the genome of this wide-spread European species, whose genetic diversity is ten times greater than that of humans.
<G-vec00084-002-s419><assemble.zusammensetzen><de> Dies ermöglichte es, die 750 Millionen Nukleotide zu sequenzieren und zusammenzusetzen, aus denen das Genom besteht.
<G-vec00084-002-s219><assemble.zusammenstellen><en> That way they can assemble a perfect selection of clothes for you for the following orders.
<G-vec00084-002-s219><assemble.zusammenstellen><de> So kann er Ihnen für folgende Bestellungen eine perfekte Auswahl an Kleidung für Sie zusammenstellen.
<G-vec00084-002-s220><assemble.zusammenstellen><en> The video tutorial shows you how to assemble this lovely bird buffet in just a few steps.
<G-vec00084-002-s220><assemble.zusammenstellen><de> Das Video-Tutorial zeigt Ihnen, wie Sie dieses schöne Vogelbuffet in wenigen Schritten zusammenstellen.
<G-vec00084-002-s221><assemble.zusammenstellen><en> Pegi: +16 In a land torn asunder by incessant warfare, it is time to assemble your own band of hardened warriors and enter the fray.
<G-vec00084-002-s221><assemble.zusammenstellen><de> Das Land wurde durch ständige Kriege auseinander gerissen und es ist an der Zeit, dass Sie Ihre eigene Truppe an hart gesottenen Kriegern zusammenstellen und sich mitten in die Schlacht begeben.
<G-vec00084-002-s223><assemble.zusammenstellen><en> Assemble a team.
<G-vec00084-002-s223><assemble.zusammenstellen><de> Stelle ein Team zusammen.
<G-vec00084-002-s224><assemble.zusammenstellen><en> Fantasy Soccer that's out of this world! Assemble the best soccer team in the galaxy to defeat the League of Evil!
<G-vec00084-002-s224><assemble.zusammenstellen><de> Fantasy-Fußball aus einer anderen Welt!Stelle das beste Fußballteam der Galaxie zusammen, um die Liga des Bösen zu besiegen!Features1.
<G-vec00084-002-s225><assemble.zusammenstellen><en> Assemble and lead your team aboard the SSV Normandy, the most advanced ship in the galaxy, and travel to distant and unexplored star systems.
<G-vec00084-002-s225><assemble.zusammenstellen><de> Stelle dein Team an Bord der SSV Normandy zusammen, dem modernsten Schiff der Galaxie, und reise zu entfernten und unerforschten Sonnensystemen.
<G-vec00084-002-s226><assemble.zusammenstellen><en> Establish your base, and assemble the best crew to go on risky quests.
<G-vec00084-002-s226><assemble.zusammenstellen><de> Richte deine Basis ein und stelle die beste Truppe für riskante Aufträge zusammen.
<G-vec00084-002-s227><assemble.zusammenstellen><en> • Assemble your own band by hiring a bassist, drummer, guitarist and vocalist, as in a real band.
<G-vec00084-002-s227><assemble.zusammenstellen><de> • Stelle deine eigene Band zusammen, indem du einen Bassisten, Schlagzeuger, Gitarristen und Sänger engagierst, wie in einer echten Band.
<G-vec00084-002-s228><assemble.zusammenstellen><en> Recruit heroes, assemble and summon powerful troops and send them into battle!
<G-vec00084-002-s228><assemble.zusammenstellen><de> Rekrutiere Helden und stelle mächtige Truppen zusammen um sie in den Kampf zu schicken.
<G-vec00084-002-s229><assemble.zusammenstellen><en> For regular assignments, we’ll assemble a small team of translators and proofreaders who’ll always take care of your assignments.
<G-vec00084-002-s229><assemble.zusammenstellen><de> Bei regelmäßigen Aufträgen, stellen wir ein kleines Team an Übersetzern und Lektoren zusammen, die sich jedes Mal um Ihre Aufträge kümmern.
<G-vec00084-002-s230><assemble.zusammenstellen><en> While in France, they assemble a team of expatriate Africans and French bohemians and return to Ayorou.
<G-vec00084-002-s230><assemble.zusammenstellen><de> Während sie in Frankreich sind, stellen sie eine Gruppe von Exilafrikanern und französischen Bohemiens zusammen und kehren mit ihnen nach Ayorou zurück.
<G-vec00084-002-s231><assemble.zusammenstellen><en> As a company builder, our first task is to assemble an excellent start-up team that best fits the business idea.
<G-vec00084-002-s231><assemble.zusammenstellen><de> Unsere erste Aufgabe als Company Builder ist es, herausragende Gründerteams zusammen zu stellen, die optimal zu der Geschäftsidee passen.
<G-vec00084-002-s232><assemble.zusammenstellen><en> Simply assemble the modules of the srtToolbox interface yourself.
<G-vec00084-002-s232><assemble.zusammenstellen><de> Stellen Sie sich die Module der Schnittstelle srtToolbox einfach selbst zusammen.
<G-vec00084-002-s233><assemble.zusammenstellen><en> Besides the fact that our smart luminaires enjoy tremendous energy savings, we assemble our products at Tomin, a company that offers people with a distance to the labour market a chance to reintegrate in our society.
<G-vec00084-002-s233><assemble.zusammenstellen><de> Neben der Tatsache, dass unsere intelligenten Leuchten enorme Energieeinsparungen haben, stellen wir unsere Produkte bei Tomin zusammen, einem Unternehmen, das Menschen mit Abstand zum Arbeitsmarkt eine Chance zur Wiedereingliederung in unsere Gesellschaft bietet.
<G-vec00084-002-s234><assemble.zusammenstellen><en> SSW will assemble a specific service package for you.
<G-vec00084-002-s234><assemble.zusammenstellen><de> Wir stellen ein individuelles Service-Paket für Sie zusammen.
<G-vec00084-002-s235><assemble.zusammenstellen><en> With us, you assemble your own individual solution for your industry.
<G-vec00084-002-s235><assemble.zusammenstellen><de> Bei uns stellen Sie sich Ihre individuelle Branchenlösung selbst zusammen.
<G-vec00084-002-s236><assemble.zusammenstellen><en> Armed with the theory that the right coach can make any team champions, they assemble a Dream Team of all the best dancers across the country.
<G-vec00084-002-s236><assemble.zusammenstellen><de> Gemeinsam glauben sie fest daran, dass der richtige Trainer aus jedem Team Champions machen kann und stellen ein Dream Team aus den besten B-Boys des Landes zusammen.
<G-vec00084-002-s237><assemble.zusammenstellen><en> Assemble information into a view that makes sense for you.
<G-vec00084-002-s237><assemble.zusammenstellen><de> Stellen Sie Informationen in einer für Sie sinnvollen Ansicht zusammen.
<G-vec00084-002-s238><assemble.zusammenstellen><en> You can easily assemble a rectangular shower using shower doors of adequate size and you can be sure that we also offer matching shower trays for any solution that you select.
<G-vec00084-002-s238><assemble.zusammenstellen><de> Die rechteckige Duschecke stellen Sie leicht mithilfe von Duschtüren der entsprechenden Maße zusammen, wobei Sie sich darauf verlassen können, dass wir zu einer jedweden, von Ihnen gewählten Lösung auch die entsprechenden Duschwannen anbieten.
<G-vec00084-002-s239><assemble.zusammenstellen><en> Assemble your personally desired model online from the AMAG house brands VW, Audi, SEAT, ŠKODA and VW Commercial Vehicles. Configure new vehicles
<G-vec00084-002-s239><assemble.zusammenstellen><de> Stellen Sie Ihr persönliches Wunschmodell der AMAG Hausmarken VW, Audi, SEAT, CUPRA, ŠKODA und VW Nutzfahrzeuge gleich online zusammen.
<G-vec00084-002-s240><assemble.zusammenstellen><en> About 20 workers assemble plants for the orders and package them for transport.
<G-vec00084-002-s240><assemble.zusammenstellen><de> Etwa 20 Mitarbeiterinnen stellen die Aufträge zusammen und verpacken die Pflanzen für den Transport.
<G-vec00084-002-s241><assemble.zusammenstellen><en> Assemble for yourself an air rifle matching your requirements in full, and start to prepare for your competition.
<G-vec00084-002-s241><assemble.zusammenstellen><de> Stellen Sie sich Ihr Luftgewehr komplett nach Ihren Wünschen zusammen und starten Sie Ihre Wettkampf-Vorbereitung.
<G-vec00084-002-s243><assemble.zusammenstellen><en> Assemble the applications you need on your own, and keep an eye on your production – regardless of time or place.
<G-vec00084-002-s243><assemble.zusammenstellen><de> Stellen Sie sich Ihre benötigten Anwendungen selbst zusammen und behalten Ihre Fertigung - unabhängig von Zeit und Ort - im Blick.
<G-vec00084-002-s245><assemble.zusammenstellen><en> Together with people who know the local conditions, we assemble a team that can relieve you of “avalanche worries”.
<G-vec00084-002-s245><assemble.zusammenstellen><de> Zusammen mit Personen, welche die lokalen Verhältnisse kennen, stellen wir eine Mannschaft zusammen, die Ihnen im wahrsten Sinne des Wortes die „Lawinensorgen“ abnehmen.
<G-vec00084-002-s246><assemble.zusammenstellen><en> Assemble the equipment you need for your smokers' corner easily online by choosing from these quality articles.
<G-vec00084-002-s246><assemble.zusammenstellen><de> Stellen Sie sich die gewünschte Einrichtung für Ihre Raucherräume mit diesen Qualitätsartikeln ganz einfach online zusammen.
<G-vec00084-002-s367><assemble.zusammenstellen><en> You can assemble components yourself as your wish or refer to our Online Store which contains several pre-configured product recommendations.
<G-vec00084-002-s367><assemble.zusammenstellen><de> Sie können sich die Komponenten beliebig selber zusammenstellen, nutzen Sie dazu am besten unseren Online Catalog mit vielen, vorkonfigurierten Produktvorschlägen.
<G-vec00084-002-s368><assemble.zusammenstellen><en> Up until now, the customer had to assemble their system from numerous different individual components.
<G-vec00084-002-s368><assemble.zusammenstellen><de> Der Kunde musste bisher aus vielen verschiedenen Einzelkomponenten sein System zusammenstellen.
<G-vec00084-002-s369><assemble.zusammenstellen><en> Whether assemble sets (bundling, upselling), wrapped in paper, with a branding, rebranding or (laser) printing provided,on request we take over for you the complete finishing and packaging of your products.
<G-vec00084-002-s369><assemble.zusammenstellen><de> Ob Sets zusammenstellen (Bundling, Upselling), in Geschenkpapier verpacken, mit einem Branding, Rebranding oder (Laser-)Druck versehen, wir übernehmen für Sie auf Wunsch die komplette Veredelung und Konfektionierung Ihrer Produkte.
<G-vec00084-002-s370><assemble.zusammenstellen><en> In fact, the developers were allowed to assemble a team, and then – together get out to the server to fight for victory.
<G-vec00084-002-s370><assemble.zusammenstellen><de> Tatsächlich durften die Entwickler ein Team zusammenstellen und dann gemeinsam zum Server gehen, um um den Sieg zu kämpfen.
<G-vec00084-002-s371><assemble.zusammenstellen><en> Allows you to assemble a double dildo or double plug according to your own wishes and combine additional Hung System...
<G-vec00084-002-s371><assemble.zusammenstellen><de> Verwandelt alle Hung System Dildos und Ermöglicht das Zusammenstellen eines Doppeldildos oder Doppel-Plugs ganz nach Wunsch mit den Aufsteck-Toys des Hung S...
<G-vec00084-002-s372><assemble.zusammenstellen><en> First, in the selection of furniture, the room is selected for one wants to assemble furniture.
<G-vec00084-002-s372><assemble.zusammenstellen><de> Zunächst wird in der Möbelauswahl das Zimmer ausgewählt für das man Möbel zusammenstellen möchte.
<G-vec00084-002-s373><assemble.zusammenstellen><en> Users must not copy, modify, create derivative pieces of work, assemble, decompile, assign, sub-licence or transfer in any way any content of the Medium or any material related to the Medium.
<G-vec00084-002-s373><assemble.zusammenstellen><de> Die Nutzer dürfen die Inhalte der Website oder mit der Website verbundenes Material (einschließlich Software) nicht kopieren, verändern, versuchen abgeleitete Werke zu schaffen, zusammenstellen, dekompilieren, zuweisen, Unterlizenzen erstellen oder auf eine beliebige Art und Weise übertragen.
<G-vec00084-002-s374><assemble.zusammenstellen><en> E.g., a developer can assemble an app package and then install it onto the mobile phone.
<G-vec00084-002-s374><assemble.zusammenstellen><de> Beispielsweise kann der Entwickler ein App-Paket zusammenstellen und es dann auf dem Mobiltelefon installieren.
<G-vec00084-002-s375><assemble.zusammenstellen><en> This war game lets you assemble a squad with 14 different types of soldiers.
<G-vec00084-002-s375><assemble.zusammenstellen><de> Dieses Kriegsspiel lässt dich eine Einheit mit 14 verschiedenen Soldatenarten zusammenstellen.
<G-vec00084-002-s376><assemble.zusammenstellen><en> You get insight into the development, participate in decision-making processes and can assemble the system according to your needs.
<G-vec00084-002-s376><assemble.zusammenstellen><de> Sie erhalten Einblick in die Entwicklung, nehmen an Entscheidungsprozessen teil und können das System ganz nach Ihren Bedürfnissen zusammenstellen.
<G-vec00084-002-s377><assemble.zusammenstellen><en> Subsequently I have to assemble the films, add music and label it; this is a job again.
<G-vec00084-002-s377><assemble.zusammenstellen><de> Nachher muss ich dafür die Filme zusammenstellen, Musik einfügen und beschriften, das ist auch wieder eine Arbeit für sich.
<G-vec00084-002-s378><assemble.zusammenstellen><en> The customer can select the chapters they want to assemble in the data file.
<G-vec00084-002-s378><assemble.zusammenstellen><de> Sie können die Kapitel auswählen, die Sie in der Datendatei zusammenstellen möchten.
<G-vec00084-002-s379><assemble.zusammenstellen><en> That way we can assemble a made-to-measure quotation that exactly meets your needs.
<G-vec00084-002-s379><assemble.zusammenstellen><de> So können wir Ihnen eine massgeschneiderte Offerte zusammenstellen, die genau Ihren Bedürfnissen entspricht.
<G-vec00084-002-s380><assemble.zusammenstellen><en> The business user himself gets access to database systems and can assemble the desired information according to the self-service model and then drag and drop it into a pretty graphic.
<G-vec00084-002-s380><assemble.zusammenstellen><de> Der Fachanwender erhält selbst Zugriff auf Datenbank-Systeme und kann sich nach dem Selbstbedienungsmodell die gewünschten Informationen zusammenstellen und dann per Drag- und Drop in eine hübsche Grafik schieben.
<G-vec00084-002-s381><assemble.zusammenstellen><en> Collectors can also assemble a collection of modern military vehicles into an army.
<G-vec00084-002-s381><assemble.zusammenstellen><de> Sammler können auch eine Kollektion moderner Militärfahrzeuge zu einer Armee zusammenstellen.
<G-vec00084-002-s382><assemble.zusammenstellen><en> When he and his wife Martha were able to assemble enough musicians to get a band together again, they began a popular radio show on CKRD in Red Deer, using the name 'The Musical Round-Up Gang' at first, as they were part of a popular local disc-jockey show called the 'Musical Round-Up.'
<G-vec00084-002-s382><assemble.zusammenstellen><de> Als er und seine Frau Martha genügend Musiker zusammenstellen konnten, um wieder eine Band zu gründen, begannen sie eine beliebte Radiosendung auf CKRD in Red Deer unter dem Namen'The Musical Round-Up Gang', da sie Teil einer beliebten lokalen Discjockey-Show namens'Musical Round-Up' waren.
<G-vec00084-002-s383><assemble.zusammenstellen><en> We can also assemble any complex mechanical assemblies and produce all the required parts ourselves.
<G-vec00084-002-s383><assemble.zusammenstellen><de> Wir können die anspruchsvollsten mechanischen Baugruppen zusammenstellen, für die wir alle Produkte selbst herstellen.
<G-vec00084-002-s384><assemble.zusammenstellen><en> You may also choose to assemble your bracelet based entirely on beauty, diversity, colour or occasion.
<G-vec00084-002-s384><assemble.zusammenstellen><de> Du kannst deinen Schmuck auch ganz nach Schönheit, Vielfalt, Farbe oder Anlass zusammenstellen.
<G-vec00084-002-s385><assemble.zusammenstellen><en> What's more, the president's suggestion of using the Moon as a base — a place to assemble equipment and produce fuel for a Mars mission less expensively — has the potential to turn into a costly sideshow.
<G-vec00084-002-s385><assemble.zusammenstellen><de> Der Vorschlag des Präsidenten, den Mond als eine Basis – einen Ort zum Zusammenstellen der Ausrüstung und zum billigeren Herstellen von Treibstoff – zu benutzen, könnte vielmehr zu einer sehr kostspieligen Nebensache geraten.
<G-vec00084-002-s422><assemble.zusammenstellen><en> Van den Berk B.V. has attempted to assemble the information in this book as meticulously as possible without claiming this to have been exhaustive.
<G-vec00084-002-s422><assemble.zusammenstellen><de> Van den Berk B.V. hat sich bemüht, die Inhalte dieses Buches mit der größtmöglichen Sorgfalt zusammenzustellen, ohne einen Anspruch auf Vollständigkeit.
<G-vec00084-002-s423><assemble.zusammenstellen><en> To assemble an order from several items, they won’t need a paper pick list any more.
<G-vec00084-002-s423><assemble.zusammenstellen><de> Um eine Bestellung aus mehreren Artikeln zusammenzustellen, braucht er keine papierne Packliste mehr.
<G-vec00084-002-s424><assemble.zusammenstellen><en> Finally, they spawn more rarely, in lower numbers and are more difficult to tame, so it will take more time to assemble a pack of any given size.
<G-vec00084-002-s424><assemble.zusammenstellen><de> Schließlich spawnen sie seltener und in niedrigerer Anzahl und sind schwieriger zu zähmen, so dass es länger dauert ein Rudel beliebiger Größe zusammenzustellen.
<G-vec00084-002-s425><assemble.zusammenstellen><en> This is the real impetus and motivation behind the decision to assemble a new band and tour again.
<G-vec00084-002-s425><assemble.zusammenstellen><de> Das ist der wahre Antrieb und die Motivation dahinter, jetzt wieder eine neue Band zusammenzustellen und auf Tour zu gehen.
<G-vec00084-002-s426><assemble.zusammenstellen><en> QuickDisc™ allows users to assemble and submit projects to their Rimage system.
<G-vec00084-002-s426><assemble.zusammenstellen><de> QuickDisc™ gestattet allen Benutzern Aufträge und Projekte zusammenzustellen und an das Rimage System zu schicken.
<G-vec00084-002-s427><assemble.zusammenstellen><en> Twitter0 Pinterest0 There have always been enough skilled craftsmen to assemble all kinds of mechanisms from improvised means in our country.
<G-vec00084-002-s427><assemble.zusammenstellen><de> Twitter0 Pinterest0 Es gab immer genügend fähige Handwerker, um alle Arten von Mechanismen aus improvisierten Mitteln in unserem Land zusammenzustellen.
<G-vec00084-002-s428><assemble.zusammenstellen><en> Google uses this information to evaluate your use of the website, assemble reports on website activities for the website operator, and to render additional services related to the use of the website and the internet.
<G-vec00084-002-s428><assemble.zusammenstellen><de> Im Auftrag des Betreibers dieser Website wird Google diese Informationen benutzen, um Ihre Nutzung der Website auszuwerten, um Reports über die Websiteaktivitäten zusammenzustellen und um weitere mit der Websitenutzung und der Internetnutzung verbundene Dienstleistungen gegenüber dem Websitebetreiber zu erbringen.
<G-vec00084-002-s429><assemble.zusammenstellen><en> As I had the Haute Couture in my blog name from minute one, I loved the idea to assemble my own “Couture Edition” for you!
<G-vec00084-002-s429><assemble.zusammenstellen><de> Da Haute Couture von Stunde 0 an Teil meines Blog-Namens war, gefiel mir die Idee besonders gut, hochwertige Couture Produkte für euch zusammenzustellen.
<G-vec00084-002-s430><assemble.zusammenstellen><en> Example: “Archive for 2008 – Jens Meiert” instead of “Jens Meiert – Archive for 2008”, (in this case) following a convention to assemble the page title out of the h2 and h1 headings, in this order.
<G-vec00084-002-s430><assemble.zusammenstellen><de> Beispiel: »Archiv – Max Mustermann« anstatt »Max Mustermann – Archiv«, was der einfachen Konvention entsprechen mag, den Seitentitel aus den h2- und h1-Überschriften zusammenzustellen, durchaus in dieser Reihenfolge.
<G-vec00084-002-s431><assemble.zusammenstellen><en> With Vontobel Compose, we offer you access to all our solutions – and at the same time give you the possibility to assemble them individually.
<G-vec00084-002-s431><assemble.zusammenstellen><de> Mit Vontobel Compose bieten wir Ihnen einen Zugang zu all unseren Lösungen – und geben Ihnen gleichzeitig die Möglichkeit, sie individuell zusammenzustellen.
<G-vec00084-002-s432><assemble.zusammenstellen><en> Google will use this information on our behalf to evaluate the usage of our Website by the users, to assemble reports about the activities on our Website and to deliver to us further services connected to the use of the Website.
<G-vec00084-002-s432><assemble.zusammenstellen><de> Google wird diese Informationen in unserem Auftrag benutzen, um die Nutzung unserer Website durch die Nutzer auszuwerten, um Reports über die Aktivitäten auf unserer Website zusammenzustellen und um weitere, mit der Nutzung der Website verbundene Dienstleistungen, uns gegenüber zu erbringen.
<G-vec00084-002-s433><assemble.zusammenstellen><en> Bonfiglioli most qualified business partners, BEST distributors (Bonfiglioli Excellence Service Team) -thanks to a wide stock of products and components, and technical expertise - are able to assemble a wide range of products, thus adapting to their customers’ requirements in a very short time.
<G-vec00084-002-s433><assemble.zusammenstellen><de> Unsere 65 Vertriebsunternehmen des Bonfiglioli Excellence Service Teams sind - dank einer breiten Palette an Produkten und Einzelteilen sowie der technischen Fachkenntnisse - in der Lage, eine große Bandbreite an Produkten zusammenzustellen, um die Anforderungen der Kunden in kürzester Zeit erfüllen zu können.
<G-vec00084-002-s434><assemble.zusammenstellen><en> The high-rack warehouse comes with an efficient picking line that allows us to also assemble and dispatch even complex orders according to your specifications.
<G-vec00084-002-s434><assemble.zusammenstellen><de> In das Hochregallager ist eine effiziente Kommissionierstrecke integriert, die es uns ermöglicht, auch komplexe Sendungen zusammenzustellen und entsprechend Ihrer Wünsche zu versenden.
<G-vec00084-002-s435><assemble.zusammenstellen><en> When choosing a suitable and cost-saving system it is still important to assemble the system components that are technically and economically best for the desired application.
<G-vec00084-002-s435><assemble.zusammenstellen><de> Wichtig bleibt bei der Auswahl eines geeigneten und kostengünstigen Heizungssystems, auf den jeweiligen Anwendungsfall bezogen die technisch und wirtschaftlich am besten geeigneten Systembestandteile zusammenzustellen.
<G-vec00084-002-s436><assemble.zusammenstellen><en> The Videopoker is a game, where the Player is to assemble cards matching one of the winning combinations.
<G-vec00084-002-s436><assemble.zusammenstellen><de> Videopoker ist ein Spiel, wo der Spieler Karten nach den gewinnenden Kombinationen zusammenzustellen hat.
<G-vec00084-002-s437><assemble.zusammenstellen><en> This gives customers the opportunity to assemble the machine precisely for the work that needs to be done and for a competitive price.
<G-vec00084-002-s437><assemble.zusammenstellen><de> Das alles verschafft den Kunden die Möglichkeit, die Maschine zu einem wettbewerbsfähigen Preis so zusammenzustellen, dass sie für die Arbeit, die erledigt werden muss, ideal passt.
<G-vec00084-002-s438><assemble.zusammenstellen><en> Easy to use and assemble - the controller attaches to the belt with new magnetic connectors.
<G-vec00084-002-s438><assemble.zusammenstellen><de> Einfach zu bedienen und zusammenzustellen - der Controller wird mithilfe von Magnetverbindungen an dem Bauchgürtel befestigt.
<G-vec00179-002-s096><assemble.einbauen><en> For large assembly applications, multiple robots can be synchronized to lift or assemble a large component using cooperative motion control.
<G-vec00179-002-s096><assemble.einbauen><de> Für Anwendungen mit großen Baugruppen können mehrere Roboter synchronisiert werden, um ein großes Bauteil mithilfe kooperativer Bewegungssteuerung anzuheben oder einzubauen.
<G-vec00179-002-s097><assemble.einbauen><en> Thanks to our exclusive technology, it is possible to assemble the pool yourself or to be assisted.
<G-vec00179-002-s097><assemble.einbauen><de> Dank unserer exklusiven Technologie ist es möglich, Ihren Swimmingpool selbst einzubauen oder einbauen zu lassen.
<G-vec00179-002-s098><assemble.einbauen><en> They are axially pluggable, thus easy to assemble.
<G-vec00179-002-s098><assemble.einbauen><de> Sie sind axial steckbar und dadurch sehr leicht einzubauen.
