<G-vec00196-002-s019><bring_about.bewirken><en> The Church Fathers strongly affirmed the faith of the Church in the efficacy of the Word of Christ and of the action of the Holy Spirit to bring about this conversion.
<G-vec00196-002-s019><bring_about.bewirken><de> Die Kirchenväter betonten entschieden den Glauben der Kirche, daß das Wort Christi und das Walten des Heiligen Geistes so wirkkräftig sind, daß sie diese Verwandlung zu bewirken vermögen.
<G-vec00196-002-s020><bring_about.bewirken><en> Sound development policies sustained by substantial development aid are crucial, yet they will not in themselves bring about any change unless they are effectively converted into concrete and coherent development action.
<G-vec00196-002-s020><bring_about.bewirken><de> Vernünftige entwicklungspolitische Konzepte, die sich auf substanzielle Hilfeleistungen stützen, sind von entscheidender Bedeutung, können aber nur Veränderungen bewirken, wenn sie in konkrete und kohärente Entwicklungsmaßnahmen umgesetzt werden.
<G-vec00196-002-s021><bring_about.bewirken><en> "The Atlas Copco ER heat recovery systems do not only achieve energy conservation, they also bring an ROI.
<G-vec00196-002-s021><bring_about.bewirken><de> "Die ER-Wärmerückgewinnungssysteme von Atlas Copco sind nicht nur für Energieeinsparungen verantwortlich, sie können auch eine schnelle Amortisation bewirken.
<G-vec00196-002-s022><bring_about.bewirken><en> The medical volunteer program is not designed to interfere with the Thai healthcare system or bring about major changes.
<G-vec00196-002-s022><bring_about.bewirken><de> Das medizinische Programm zielt nicht darauf ab, Eingriffe in das thailändische Gesundheitssystem zu bewirken oder größere Veränderungen herbeizuführen.
<G-vec00196-002-s023><bring_about.bewirken><en> They solve problems and can bring about profound changes in economy and society by implementing creative ideas.
<G-vec00196-002-s023><bring_about.bewirken><de> Sie lösen Probleme und können durch die Umsetzung kreativer Ideen einen tiefgreifenden Wandel in Wirtschaft und Gesellschaft bewirken.
<G-vec00196-002-s024><bring_about.bewirken><en> Be “not ashamed” to bring before the power of God, through your prayers, the miseries of mankind.
<G-vec00196-002-s024><bring_about.bewirken><de> Seid „schamlos“, schämt euch nicht, mit dem Gebet zu bewirken, dass das Elend der Menschen sich der Macht Gottes annähere.
<G-vec00196-002-s025><bring_about.bewirken><en> The measurement of the result of what love and charity may bring into the world is impossible.
<G-vec00196-002-s025><bring_about.bewirken><de> Man kann gar nicht ermessen, was Liebe und Nächstenliebe in der Welt bewirken können.
<G-vec00196-002-s026><bring_about.bewirken><en> For at least some of the hearers, however, the distressing call to repentance of the two servants of Christ will bring about true repentance.
<G-vec00196-002-s026><bring_about.bewirken><de> Bei einigen Einzelnen wird die erschütternde Bußpredigt der beiden Knechte Christi echte Buße bewirken.
<G-vec00196-002-s027><bring_about.bewirken><en> If a social justice movement manages to bring about real change in society, as is the case with animal protection, then it can be beaten down.
<G-vec00196-002-s027><bring_about.bewirken><de> Sollte eine soziale Bewegung eine echte Veränderung in der Gesellschaft bewirken, wie das der Tierschutzbewegung zunehmend gelungen ist, dann kann sie auf diese Weise zerschlagen werden.
<G-vec00196-002-s028><bring_about.bewirken><en> Temporary binders:Temporary binders bring about an increase in mechanical resistance at the surface of glazes and engobes hence leading to an improved touch-resistant finish.
<G-vec00196-002-s028><bring_about.bewirken><de> Temporäre Bindemittel:Temporäre Bindemittel bewirken eine Erhöhung der mechanischen Festigkeit an der Oberfläche von Glasuren und Engoben und führen zu einer Verbesserung der Grifffestigkeit.
<G-vec00196-002-s029><bring_about.bewirken><en> The codes of conduct envisaged will not bring a new balance into trade relations.
<G-vec00196-002-s029><bring_about.bewirken><de> Die ins Auge gefassten Verhaltenskodizes werden kein neues Gleichgewicht in den Handelsbeziehungen bewirken.
<G-vec00196-002-s030><bring_about.bewirken><en> The Dharma Gem refers to the states in which suffering and the causes for suffering have been removed forever and these evolving Buddha-nature networks have been activated and energized to the point at which they can bring about these states of removal.
<G-vec00196-002-s030><bring_about.bewirken><de> Das Dharma-Juwel bezieht sich auf Zustände, in denen das Leiden und die Ursachen des Leidens für immer beseitigt worden sind und die sich entwickelnden Buddha-Natur-Netzwerke aktiviert und bis zu dem Punkt hin angeregt worden sind, dass sie diese Zustände der Beseitigung bewirken.
<G-vec00196-002-s031><bring_about.bewirken><en> Daily application in the morning and evening is enough to start to bring about real improvement in joint pain in two to four weeks.
<G-vec00196-002-s031><bring_about.bewirken><de> Tägliches Auftragen morgens und abends ist ausreichend, um schon nach zwei bis 10 Tagen eine deutliche Verbesserung der Gelenkschmerzen bewirken zu können.
<G-vec00196-002-s032><bring_about.bewirken><en> A growing number of regulations—such as the recent European reporting obligation—come into play precisely to strengthen business responsibility and bring about change.
<G-vec00196-002-s032><bring_about.bewirken><de> Immer mehr Regularien – wie zuletzt die europäische Berichtspflicht – setzen hier an, um unternehmerische Verantwortung zu stärken und Veränderung zu bewirken.
<G-vec00196-002-s033><bring_about.bewirken><en> And you can bring about change: Send directly from your Android Phone a protest email to the manufacturer.
<G-vec00196-002-s033><bring_about.bewirken><de> Und Du kannst Veränderung bewirken: Schicke direkt von Deinem Android Phone eine Protestmail an den Hersteller.
<G-vec00196-002-s034><bring_about.bewirken><en> To this end, effective movement patterns will be selected for you, which will not only bring about progress in the actual training session but also in your everyday life, and also cause noticeable positive changes in your performance in other sports.
<G-vec00196-002-s034><bring_about.bewirken><de> Wesentlich im HOC – House Of Calisthenics Trainingskonzept ist die grundsätzliche Übertragbarkeit in den Alltag: Daher werden für dich effektive Bewegungsmuster ausgewählt, die nicht nur in der eigentlichen Trainingseinheit einen Fortschritt bewirken, sondern sich auch in deinem Alltag oder bei anderen Sportarten positiv bemerkbar machen.
<G-vec00196-002-s035><bring_about.bewirken><en> If the law has to change litigation has been identified as one of the tools that can bring about reform in this area.
<G-vec00196-002-s035><bring_about.bewirken><de> Will man das Rechtssystem ändern, erweisen sich Gerichtsverfahren als ein sinnvolles Mittel um Reformen in diesem Bereich zu bewirken.
<G-vec00196-002-s036><bring_about.bewirken><en> They bring about an expression of fatigue, accentuate the age and thus provoke a negative visual impression.
<G-vec00196-002-s036><bring_about.bewirken><de> Sie bewirken einen Ausdruck von Müdigkeit und Alter und rufen damit einen negativen Gesichtseindruck hervor.
<G-vec00196-002-s037><bring_about.bewirken><en> Isolation and withdrawing into one's own interests are never the way to restore hope and bring about a renewal. Rather, it is closeness, it is the culture of encounter.
<G-vec00196-002-s037><bring_about.bewirken><de> Die Isolierung und das Verschlossensein in sich selbst oder die eigenen Interessen sind nie der Weg, um wieder Hoffnung zu geben und Erneuerung zu bewirken, wohl aber die Nähe, die Kultur der Begegnung.
<G-vec00196-002-s057><bring_about.bringen><en> “WE BRING IDEAS TO LIFE.” briefly describes Doehler’s holistic and strategic approach to innovation.
<G-vec00196-002-s057><bring_about.bringen><de> „WE BRING IDEAS TO LIFE.“ beschreibt prägnant den integrierten Leistungsansatz.
<G-vec00196-002-s058><bring_about.bringen><en> Unicorn Killer — fresh taste music: Bring Me The Horizon
<G-vec00196-002-s058><bring_about.bringen><de> Offizielle schwarze Mütze der britischen Band Bring Me The Horizon.
<G-vec00196-002-s059><bring_about.bringen><en> Bring your personal touch and your perspective, be open and direct but always be friendly.
<G-vec00196-002-s059><bring_about.bringen><de> Bring dich und deine Sichtweise ein, sei offen und direkt, aber immer freundlich.
<G-vec00196-002-s060><bring_about.bringen><en> Bring and pick up service from and to Toverland is possible.
<G-vec00196-002-s060><bring_about.bringen><de> Bring und Abholservice von und nach Toverland ist möglich.
<G-vec00196-002-s061><bring_about.bringen><en> Bring It In To start the betting on the first round.
<G-vec00196-002-s061><bring_about.bringen><de> Bring It In - um die Wette an die erste Runde zu beginnen.
<G-vec00196-002-s062><bring_about.bringen><en> You can choose from 20 arrangements for 18 instruments for the composition Santa, Bring My Baby Back (To Me).
<G-vec00196-002-s062><bring_about.bringen><de> Sie können aus 20 Arrangements für 18 Musikinstrumente der Komposition Santa, Bring My Baby Back (To Me) wählen.
<G-vec00196-002-s063><bring_about.bringen><en> Bring your own campervan.
<G-vec00196-002-s063><bring_about.bringen><de> Bring dein eigenes Reisemobil mit.
<G-vec00196-002-s064><bring_about.bringen><en> Bring torch or diving light, DSMB and wrist compass.
<G-vec00196-002-s064><bring_about.bringen><de> Bring Fackel oder Tauchlicht, DSMB und Handgelenk Kompass.
<G-vec00196-002-s065><bring_about.bringen><en> Remember to bring a padlock or buy one from reception for £3.50.
<G-vec00196-002-s065><bring_about.bringen><de> Bitte bring ein Vorhängeschloss mit oder kaufe eins an der Rezeption für £3.
<G-vec00196-002-s066><bring_about.bringen><en> You are able to buy new or use existing FileMaker software licenses via Bring Your Own License (BYOL).
<G-vec00196-002-s066><bring_about.bringen><de> Über Bring Your Own License (BYOL) können Sie neue FileMaker-Software-Lizenzen kaufen oder bereits bestehende Lizenzen verwenden.
<G-vec00196-002-s067><bring_about.bringen><en> Bring your own to share.
<G-vec00196-002-s067><bring_about.bringen><de> Bring dein Lieblingsspiel mit.
<G-vec00196-002-s068><bring_about.bringen><en> Bring Me Flowers - stock photography images.
<G-vec00196-002-s068><bring_about.bringen><de> Bring mir Blumen - Sammlung von photographischen Bildern.
<G-vec00196-002-s069><bring_about.bringen><en> Bring me peace and solace.
<G-vec00196-002-s069><bring_about.bringen><de> Bring mir Frieden und Trost.
<G-vec00196-002-s070><bring_about.bringen><en> In 2016, around 85% of packaging that was collected for recycling in Spain was collected via bring banks.
<G-vec00196-002-s070><bring_about.bringen><de> In 2016 wurde ungefähr 85% von Verpackungsmüll in Spanien durch „Bring Banks“ gesammelt.
<G-vec00196-002-s071><bring_about.bringen><en> 7 And this [is] of Judah: And he said, Hear, LORD, the voice of Judah, and bring him into his people. With his hands he contended for himself, and thou shall be a help against his adversaries.
<G-vec00196-002-s071><bring_about.bringen><de> 7 Und dieses von Juda; und er sprach: Höre, Jehova, die Stimme Juda's, und zu seinem Volke bring ihn, seine Hand streite für ihn, und Hülfe gegen seine Feinde sey du.
<G-vec00196-002-s072><bring_about.bringen><en> • Free Shopping: Bring with you what you do not need and take what you want.
<G-vec00196-002-s072><bring_about.bringen><de> • Umsonstladen: Bring mit, was Du nicht brauchst und nimm was Du willst.
<G-vec00196-002-s073><bring_about.bringen><en> The cover “Bring it home to me” followed, when Steve asked the audience to start snipping.
<G-vec00196-002-s073><bring_about.bringen><de> Es folgte das Cover „Bring it home to me“, wofür Steve das Publikum zum Schnippen aufforderte.
<G-vec00196-002-s074><bring_about.bringen><en> In this case it is necessary to say the following words: "The hair is long, drowned, bring me the spirit of water.
<G-vec00196-002-s074><bring_about.bringen><de> In diesem Fall ist es notwendig, die folgenden Worte zu sagen: "Die Haare sind lang, ertränkt, bring mir den Geist des Wassers.
<G-vec00196-002-s075><bring_about.bringen><en> Bring them in bring them in
<G-vec00196-002-s075><bring_about.bringen><de> Bring sie doch zurück zu mir.
<G-vec00196-002-s076><bring_about.bringen><en> Inhale as you bend your elbows and bring your butt towards the floor.
<G-vec00196-002-s076><bring_about.bringen><de> Atme ein, beuge die Ellbogen und bringe deinen Po zum Boden.
<G-vec00196-002-s077><bring_about.bringen><en> Let me be thy proper servant, who took him into my trust, and promised, saying: If I bring him not again, I will be guilty of sin against my father for ever.
<G-vec00196-002-s077><bring_about.bringen><de> Denn ich, dein Knecht, bin Bürge geworden für den Knaben gegen meinen Vater und sprach: Bringe ich ihn dir nicht wieder, so will ich mein Leben lang die Schuld tragen.
<G-vec00196-002-s078><bring_about.bringen><en> He is to bring it to the priest, who is to take a handful of it to be put on the burnt offering for Yahweh in order to recall this man to Yahweh.
<G-vec00196-002-s078><bring_about.bringen><de> 12 Er bringe es dem Priester, der davon eine Hand voll nimmt und als Gedächtnisanteil auf dem Altar mit den Feueropfern des Herrn in Rauch aufgehen lässt.
<G-vec00196-002-s079><bring_about.bringen><en> Bring yourself and your skills into the battle, slip into the role of a paratrooper, tank commander or sniper and immerse yourself in realistic battles.
<G-vec00196-002-s079><bring_about.bringen><de> Bringe Dich und Deine Fähigkeiten in den Kampf, schlüpfe in die Rolle eines Fallschirmjägers, Panzerkommandanten oder Scharfschützen und tauche ein in realistische Schlachten.
<G-vec00196-002-s080><bring_about.bringen><en> Now it happened one day that he was going to a fair; so he asked his daughter, who was named Betta, what she would like him to bring her on his return. And she said, "Papa, if you love me, bring me half a hundredweight of Palermo sugar, and as much again of sweet almonds, with four to six bottles of scented water, and a little musk and amber, also forty pearls, two sapphires, a few garnets and rubies, with some gold thread, and above all a trough and a little silver trowel."
<G-vec00196-002-s080><bring_about.bringen><de> Als er nun einmal zu einer Messe reisen musste, fragte er seine Tochter, die Betta hieß, was er ihr mitbringen solle, worauf sie erwiderte: »Wenn du mich liebhast, Väterchen, so bringe mir einen halben Zentner Palermozucker, einen halben süße Mandeln, vier bis sechs Flaschen wohlriechendes Wasser, etwas Moschus und Ambra, ferner etwa vierzig Stück Perlen, zwei Saphire, einige Granaten und Rubine, etwas Goldgespinst, besonders aber einen Backtrog und Kratzmesser von Silber.« Der Vater wunderte sich zwar über diese etwas unbescheidene Forderung, wollte aber seiner Tochter nicht widersprechen, er reiste daher zur Messe ab und brachte ihr bei seiner Rückkehr ganz genau alles, was sie gewünscht.
<G-vec00196-002-s081><bring_about.bringen><en> Bring your written notes with you when you go to the meeting, as well as any other coworkers who also wish to complain.
<G-vec00196-002-s081><bring_about.bringen><de> Bringe deine schriftlichen Notizen zu dem Meeting und sorge dafür, dass alle Kollegen, die deine Sache unterstützen, ebenfalls zu dem Termin erscheinen.
<G-vec00196-002-s082><bring_about.bringen><en> 23 And he shall bring them on the eighth day for his cleansing unto the priest, unto the door of the tabernacle of the congregation, before YHVH.
<G-vec00196-002-s082><bring_about.bringen><de> 23 und bringe sie am achten Tage seiner Reinigung zum Priester vor die Tür der Hütte des Stifts, vor den HERRN.
<G-vec00196-002-s083><bring_about.bringen><en> 4Then Pilate went out again, and said to them, PONTIUS PILATE Behold, I bring him out to you, that you may know that I find no basis for a charge against him.
<G-vec00196-002-s083><bring_about.bringen><de> Pilatus ging wieder hinaus und sagte zu ihnen: Seht ich bringe ihn zu euch heraus; ihr sollt wissen, das ich keinen Grund finde, ihn zu verurteilen.
<G-vec00196-002-s084><bring_about.bringen><en> Go deeper than the surface with personal stories and context that bring the experience to life.
<G-vec00196-002-s084><bring_about.bringen><de> Gehe tiefer als die Oberfläche und bringe deine Entdeckung mit persönlichen Geschichten und ihrem besonderen Hintergrund zum Leben.
<G-vec00196-002-s085><bring_about.bringen><en> 6:25 Then hear thou from heaven, and forgive the sin of thy people Israel, and bring them back into the land, which thou gavest to them, and their fathers.
<G-vec00196-002-s085><bring_about.bringen><de> 6:25 so höre du vom Himmel her und vergib die Sünde deines Volkes Israel; und bringe sie in das Land zurück, das du ihnen und ihren Vätern gegeben hast.
<G-vec00196-002-s086><bring_about.bringen><en> 5:7 And if he shall not be able to bring a lamb, then he shall bring for his trespass which he hath committed, two turtle-doves, or two young pigeons, to the LORD; one for a sin-offering, and the other for a burnt-offering.
<G-vec00196-002-s086><bring_about.bringen><de> 5:7 Vermag er aber nicht ein Schaf, so bringe er dem HERRN für seine Schuld, die er getan hat, zwo Turteltauben oder zwo junge Tauben, die erste zum Sündopfer, die andere zum Brandopfer.
<G-vec00196-002-s087><bring_about.bringen><en> Join the gods of Greek legend and bring peace to an ancient world on the brink of war!
<G-vec00196-002-s087><bring_about.bringen><de> Bringe einer alten Welt, die an der Schwelle des Krieges steht, Seite an Seite mit den griechischen Göttern Frieden.
<G-vec00196-002-s088><bring_about.bringen><en> In this book, I bring you in as you bring your marketing into the present and make it a success driver for your company.
<G-vec00196-002-s088><bring_about.bringen><de> In diesem Buch bringe ich Ihnen bei, wie Sie Ihr Marketing in die Gegenwart holen und es zu einem Erfolgstreiber in Ihrem Unternehmen machen.
<G-vec00196-002-s089><bring_about.bringen><en> 24When your people Israel are defeated by an enemy because they have sinned against you, and then they turn, praise your name, pray to you, and entreat you in this house, 25listen from heaven and forgive the sin of your people Israel, and bring them back to the land you gave them and their ancestors.
<G-vec00196-002-s089><bring_about.bringen><de> 24Und wenn dein Volk Israel vor dem Feinde geschlagen wird, weil sie wider dich gesündigt haben, und sie kehren um und bekennen deinen Namen und beten und flehen zu dir in diesem Hause: 25so höre du vom Himmel her und vergib die Sünde deines Volkes Israel; und bringe sie in das Land zurück, das du ihnen und ihren Vätern gegeben hast.
<G-vec00196-002-s090><bring_about.bringen><en> Bring your kicking leg out to the side or in front of you with the knee bent all the way.
<G-vec00196-002-s090><bring_about.bringen><de> Bringe das Bein, mit dem du trittst, zur Seite oder nach vorne mit gebeugtem Knie.
<G-vec00196-002-s091><bring_about.bringen><en> And I will bring you into the land of Israel.
<G-vec00196-002-s091><bring_about.bringen><de> Ich bringe euch zurück in das Land Israel.
<G-vec00196-002-s092><bring_about.bringen><en> So why is it, that you do not fight in the way of Allah, and for the abased among men, women, and children who say: 'Our Lord, bring us out from this village whose people are harmdoers, and give to us a guardian from You, and give to us a helper from You.
<G-vec00196-002-s092><bring_about.bringen><de> Was ist mit euch, daß ihr nicht auf Allahs Weg, und (zwar) für die Unterdrückten unter den Männern, Frauen und Kindern kämpft, die sagen: "Unser Herr, bringe uns aus dieser Stadt heraus, deren Bewohner ungerecht sind, und schaffe uns von Dir aus einen Schutzherrn, und schaffe uns von Dir aus einen Helfer.
<G-vec00196-002-s093><bring_about.bringen><en> Let the earth open that it may bring forth salvation, and let it cause righteousness to spring up together.
<G-vec00196-002-s093><bring_about.bringen><de> Die Erde tue sich auf und bringe Heil, und Gerechtigkeit wachse mit zu.
<G-vec00196-002-s094><bring_about.bringen><en> ¶ And if he cannot afford to bring a she lamb, then he shall bring for his sin offering two turtledoves or two young pigeons, one for a sin offering and the other for a burnt offering.
<G-vec00196-002-s094><bring_about.bringen><de> Kann er aber nicht so viel aufbringen, dass es für ein Lamm reicht, so bringe er dem Herrn für das, worin er gesündigt hat, als sein Schuldopfer zwei Turteltauben oder zwei junge Tauben dar; eine als Sündopfer, die andere als Brandopfer.
<G-vec00196-002-s095><bring_about.bringen><en> A war that would bring those swinging sixties to an end.
<G-vec00196-002-s095><bring_about.bringen><de> Ein Krieg, der diese "Swinging Sixties" zu einem bitteren Ende bringen würde.
<G-vec00196-002-s096><bring_about.bringen><en> We bring you up to date regarding the upcoming General Data Protection Regulation, provide information on recent judgements and (planned) legislation amendments.
<G-vec00196-002-s096><bring_about.bringen><de> Wir bringen Sie auf den neusten Stand zur kommenden Datenschutzgrundverordnung, informieren über aktuelle Urteile und (geplante) Gesetzesänderungen.
<G-vec00196-002-s097><bring_about.bringen><en> The Arabic reads, "Stab, and your hands will bring victory."
<G-vec00196-002-s097><bring_about.bringen><de> Der Text lautet: „Stich zu und deine Hände werden den Sieg bringen“ (Jerusalem Brigaden).
<G-vec00196-002-s098><bring_about.bringen><en> Then add the flour mixture to the pan along with the remaining vegetable broth. Stir constantly and bring to the boil.
<G-vec00196-002-s098><bring_about.bringen><de> Die Mehlmischung zusammen mit der restlichen Gemüsebrühe in die Pfanne geben und unter Rühren zum Kochen bringen.
<G-vec00196-002-s099><bring_about.bringen><en> It is our goal to bring products on the market that are as clean and pure as possible, and that contributes to a healthy lifestyle.
<G-vec00196-002-s099><bring_about.bringen><de> Unser Ziel ist es, ein Produkt auf den Markt zu bringen, das so sauber und rein wie möglich ist, und zu einem gesunden Lebensstil beiträgt.
<G-vec00196-002-s100><bring_about.bringen><en> “We are incredibly excited to bring virtual reality to PlayStation 4,” said Jim Ryan, President of Global Sales and Marketing, SIE and President of SIEE.
<G-vec00196-002-s100><bring_about.bringen><de> „Wir freuen uns wirklich sehr darauf, die virtuelle Realität auf PlayStation 4 zu bringen“, so Jim Ryan, President of Global Sales and Marketing von SIE sowie President von SIEE.
<G-vec00196-002-s101><bring_about.bringen><en> Surely that will bring Dawg out of hiding.
<G-vec00196-002-s101><bring_about.bringen><de> Das wird Dawg sicherlich aus dem Versteck bringen.
<G-vec00196-002-s102><bring_about.bringen><en> On point #2: Only properly trained drivers and escorts are fit to bring a heavy load transport safely and competently to its destination.
<G-vec00196-002-s102><bring_about.bringen><de> Zu Punkt 2: Nur gut geschulte Fahrer und Begleiter sind in der Lage, einen Schwertransport sicher und souverän ans Ziel zu bringen.
<G-vec00196-002-s103><bring_about.bringen><en> However, this means that the gym exercises and a balanced diet will not bring such good results if they are not supported by properly matched slimming pills.
<G-vec00196-002-s103><bring_about.bringen><de> Dies bedeutet jedoch, dass die Gymnastikübungen und eine ausgewogene Ernährung nicht so gute Ergebnisse bringen, wenn sie nicht durch richtig abgestimmte Schlankheitspillen unterstützt werden.
<G-vec00196-002-s104><bring_about.bringen><en> 6 You must also bring to the Supreme Priest a ram to be an offering to me in order that you will no longer be guilty.
<G-vec00196-002-s104><bring_about.bringen><de> 6 5:25 Aber für seine Schuld soll er dem HERRN zu dem Priester einen Widder von der Herde ohne Fehl bringen, der eines Schuldopfers wert ist.
<G-vec00196-002-s105><bring_about.bringen><en> One was at this point, however, still clearly said: it is never too late Even if you have exceeded the 45 some time ago, can be obtained by the regular daily intake of melatonin to normalize Zirbeldrüsenfunktion again and the natural, endogenous melatonin production to a level bring corresponds to a much younger body.
<G-vec00196-002-s105><bring_about.bringen><de> Eines sei an dieser Stelle jedoch noch deutlich gesagt: es ist nie zu spät Auch wenn man die 45 schon vor längerer Zeit überschritten hat, kann man durch die regelmäßige tägliche Einnahme von Melatonin, die Zirbeldrüsenfunktion wieder normalisieren und die natürliche, körpereigene Melatoninproduktion auf ein Niveau bringen, das einem wesentlich jüngeren Organismus entspricht.
<G-vec00196-002-s106><bring_about.bringen><en> The foreman told me, “You can bring the materials to the factory if you have any.
<G-vec00196-002-s106><bring_about.bringen><de> Der Vorarbeiter sagte, “Du kannst die Materialien in die Firma bringen, wenn du welche hast.
<G-vec00196-002-s107><bring_about.bringen><en> Close with a lid and bring to a boil.
<G-vec00196-002-s107><bring_about.bringen><de> Einen Deckel auflegen und zum Kochen bringen.
<G-vec00196-002-s108><bring_about.bringen><en> Many people believe that having a pharmacy in Ukraine is synonymous of success since normally in the cities there is a limit per zone, but still many coexist in a very close ratio, if you want to stand out about them and bring you more customers, please, sign up for our directory of Pharmacies in L’vivs’ka oblast’.
<G-vec00196-002-s108><bring_about.bringen><de> Viele Leute glauben, dass eine Apotheke in Deutschland gleichbedeutend mit Erfolg ist, denn normalerweise in den Städten gibt es eine Grenze pro Zone, aber immer noch viele koexistieren in einem sehr engen Verhältnis, wenn Sie sich über sie herausstellen und Ihnen mehr Kunden bringen wollen Bitte melden Sie sich für unser Verzeichnis von Apotheken in Veelböken.
<G-vec00196-002-s109><bring_about.bringen><en> The opulent main courses that bring a taste of the Orient to Cologne are also very well received by diners.
<G-vec00196-002-s109><bring_about.bringen><de> Aber auch die opulenten Hauptspeisen bringen einen Hauch Orient mit nach Köln und kommen bei den Gästen bestens an.
<G-vec00196-002-s110><bring_about.bringen><en> Great quality with popular, beautiful designs and melodious music bring you the warmest regards and unlimited happiness all the time, especially as a gift to your friends.
<G-vec00196-002-s110><bring_about.bringen><de> Große Qualität mit bekannten, schönen Designs und melodische Musik bringen Sie den herzlichsten Grüßen und unbegrenztes Glück die ganze Zeit, vor allem als Geschenk für Ihre Freunde.
<G-vec00196-002-s111><bring_about.bringen><en> The non-agricultural labourers of an Asiatic monarchy have little but their individual bodily exertions to bring to the task, but their number is their strength, and the power of directing these masses gave rise to the palaces and temples, the pyramids, and the armies of gigantic statues of which the remains astonish and perplex us.
<G-vec00196-002-s111><bring_about.bringen><de> Die nicht ackerbauenden Arbeiter einer asiatischen Monarchie haben außer ihren individuellen körperlichen Bemühungen wenig zum Werk zu bringen, aber ihre Zahl ist ihre Kraft, und die Macht der Direktion über diese Massen gab jenen Riesenwerken den Ursprung.
<G-vec00196-002-s112><bring_about.bringen><en> The ocean-going ships were converted for the purpose of sea rescue and patrol alternately off the Libyan coast, where most of the fleeing people, in the attempt to bring to safety, go in greatest mortal danger.
<G-vec00196-002-s112><bring_about.bringen><de> Die hochseetauglichen Schiffe wurden für den Zweck der Seenotrettung umgerüstet und patrouillieren abwechselnd vor der libyschen Küste, wo sich die meisten flüchtenden Menschen, bei dem Versuch sich in Sicherheit zu bringen, in größte Lebensgefahr begeben.
<G-vec00196-002-s113><bring_about.bringen><en> To benefit from this arrangement, please bring along the equivalent insurance form of your home health insurance.
<G-vec00196-002-s113><bring_about.bringen><de> Bringen Sie dazu bitte das entsprechende Formblatt der Krankenversicherung Ihres Heimatlandes mit.
<G-vec00196-002-s114><bring_about.bringen><en> Yamazaki Bring beauty & function to your home with Japanese homeware designer Yamazaki.
<G-vec00196-002-s114><bring_about.bringen><de> Yamazaki Bringen Sie mit dem japanischen Haushaltswaren-Designer Yamazaki Schönheit und Funktion in Ihr Zuhause.
<G-vec00196-002-s115><bring_about.bringen><en> There are many wet parts of the trail, you are inevitably going to get we, so bring waterproof shoes and clothes that will dry easy.
<G-vec00196-002-s115><bring_about.bringen><de> Es gibt viele nasse Teile des Weges, die Sie unweigerlich bekommen werden, bringen Sie also wasserdichte Schuhe und Kleidung mit, die leicht trocknen.
<G-vec00196-002-s116><bring_about.bringen><en> The House of Friendship is a wonderful place to bring your convention guests – your family and your friends from home.
<G-vec00196-002-s116><bring_about.bringen><de> Und das Schönste daran: Bringen Sie auch Ihre Gäste, Ihre Freunde, Ihre Familie mit.
<G-vec00196-002-s117><bring_about.bringen><en> Bring the water to a rolling boil, then add the sliced mushrooms.
<G-vec00196-002-s117><bring_about.bringen><de> Bringen Sie das Wasser zum kochen, dann geben Sie die in Scheiben geschnittenen Pilze dazu.
<G-vec00196-002-s118><bring_about.bringen><en> A travel cot (and a highchair) can be made available for either bedroom at no extra cost - just bring your own cot sheets.
<G-vec00196-002-s118><bring_about.bringen><de> Ein Kinderreisebett (und ein Hochstuhl) kann für beide Schlafzimmer ohne zusätzliche Kosten zur Verfügung gestellt werden - bringen Sie nur Ihre eigenen Kinderbett Bettwäsche.
<G-vec00196-002-s119><bring_about.bringen><en> Bring Payments to your iOS app
<G-vec00196-002-s119><bring_about.bringen><de> Bringen Sie Zahlungen zu Ihrer iOS App.
<G-vec00196-002-s120><bring_about.bringen><en> Bring 2 a 3 nuts to the hair.
<G-vec00196-002-s120><bring_about.bringen><de> Bringen Sie 2 ein 3 Muttern auf das Haar.
<G-vec00196-002-s121><bring_about.bringen><en> Bring a water bottle.
<G-vec00196-002-s121><bring_about.bringen><de> Bringen Sie eine Wasserflasche.
<G-vec00196-002-s122><bring_about.bringen><en> Follow the instructions and change his diaper, bring his favorite toys and play a while and make sure he gets tried and goes to sleep.
<G-vec00196-002-s122><bring_about.bringen><de> Folgen Sie den Anweisungen und wechseln Sie seine Windel, bringen Sie seine Lieblings-Spielzeug und spielen Sie eine Weile und stellen Sie sicher, er wird erprobt und in den Ruhezustand versetzt.
<G-vec00196-002-s123><bring_about.bringen><en> Bring focus, discipline and speed to your security operations center and mitigate the impact of data breaches with a swift, sure cyber incident response capability.
<G-vec00196-002-s123><bring_about.bringen><de> Bringen Sie Fokus, Disziplin und Tempo in Ihr Security Operations Center und vermindern Sie die Auswirkungen von Datenschutzverletzungen mit schnellen, zuverlässigen Funktionen zur Behandlung von Cyber-Incidents.
<G-vec00196-002-s124><bring_about.bringen><en> Wear your bathing suit under your wetsuit and bring a towel and your sense of adventure.
<G-vec00196-002-s124><bring_about.bringen><de> Tragen Sie Ihre Badesachen unter Ihrem Neoprenanzug und bringen Sie ein Handtuch und Ihre Abenteuerlust mit.
<G-vec00196-002-s125><bring_about.bringen><en> Discover with us secret boutiques, meet independent designers or ancient handicraft producers and bring back home an authentic Italian atmosphere.
<G-vec00196-002-s125><bring_about.bringen><de> Entdecken Sie mit uns geheime Boutiquen, treffen Sie unabhängige Designer oder alte Kunsthandwerker und bringen Sie eine authentische italienische Atmosphäre mit nach Hause.
<G-vec00196-002-s126><bring_about.bringen><en> Bonus tip: bring carnelian to the gym for a pocket-sized personal trainer who will always encourage you to do your very best.
<G-vec00196-002-s126><bring_about.bringen><de> Kleiner extra Tipp: Bringen Sie einen Karneol mit ins Fitnessstudio – als Personal Trainer im Taschenformat, der Sie stets ermutigen wird, Ihr Bestes zu geben.
<G-vec00196-002-s127><bring_about.bringen><en> Bring a friend, your child or anyone else you want to spend this time learning about the science of colours.
<G-vec00196-002-s127><bring_about.bringen><de> Bringen Sie einen Freund, Ihr Kind oder irgendjemand anderes, mit dem Sie diese Zeit verbringen möchten, um sich über die Wissenschaft der Farben zu informieren.
<G-vec00196-002-s128><bring_about.bringen><en> Bring extra weather gear and prepare for thunderstorms, or a sudden dip in the temperature.
<G-vec00196-002-s128><bring_about.bringen><de> Bringen Sie zusätzliche Kleidungsstücke mit und seien Sie auch auf ein Gewitter oder einen plötzlichen Temperatursturz vorbereitet.
<G-vec00196-002-s129><bring_about.bringen><en> With Pega Mashup, bring the intelligence of our Case Management directly to the customer touchpoint, instead of hard-coding logic into each channel independently.
<G-vec00196-002-s129><bring_about.bringen><de> Mit Pega Mashup bringen Sie die Intelligenz unseres Case Managements direkt zum Kundenkontaktpunkt, die Hartcodierung der Logik für jeden einzelnen Kanal entfällt.
<G-vec00196-002-s130><bring_about.bringen><en> You will find everything you need (linen and provisions, internal mini-market) so bring only your suitcases. Activity
<G-vec00196-002-s130><bring_about.bringen><de> Sie finden alles, was Sie brauchen (Bettwäsche und Proviant, Minimarkt), bringen Sie also nur Ihre Koffer mit.
<G-vec00196-002-s131><bring_about.bringen><en> Bring a good book, a camera, a glass of wine and a sense of adventure.
<G-vec00196-002-s131><bring_about.bringen><de> Bringen Sie ein gutes Buch, eine Kamera, ein Glas Wein und ein Gefühl von Abenteuer.
<G-vec00196-002-s132><bring_about.bringen><en> Use this rug as a decorative accessory in your living room or bring more comfort to your driveway.
<G-vec00196-002-s132><bring_about.bringen><de> Verwenden Sie diesen Teppich als dekoratives Accessoire in Ihrem Wohnzimmer oder bringen Sie mehr Komfort in Ihre Einfahrt.
<G-vec00196-002-s133><bring_about.bringen><en> One or more, she will bring a vintage style with its orange filaments.
<G-vec00196-002-s133><bring_about.bringen><de> Eine oder mehrere, bringt sie einen Vintage-Stil mit seinen orangefarbenen Filamente.
<G-vec00196-002-s134><bring_about.bringen><en> The rest of the day will bring cloudless weather.
<G-vec00196-002-s134><bring_about.bringen><de> Der Nachmittag bringt wechselnd bis stark bewölktes, aber verbreitet trockenes Wetter.
<G-vec00196-002-s135><bring_about.bringen><en> The evening will bring clouds with rain or sleet.
<G-vec00196-002-s135><bring_about.bringen><de> Die Mittagszeit bringt wechselhaftes Wetter mit ab und zu etwas Regen.
<G-vec00196-002-s136><bring_about.bringen><en> The noon will bring variable clouds with scattered rain showers.
<G-vec00196-002-s136><bring_about.bringen><de> Die Mittagszeit bringt unbeständiges und ab und zu nasses Wetter.
<G-vec00196-002-s137><bring_about.bringen><en> Android 7.0 System--High efficient Android 7.0 operating system with lower battery consumption and bring more high performance experience.
<G-vec00196-002-s137><bring_about.bringen><de> Android 7.0 System --Hochleistungsfähiges Android 7.0 Betriebssystem mit niedrigerem Batterieverbrauch und bringt mehr Hochleistungserfahrung.
<G-vec00196-002-s138><bring_about.bringen><en> The noon will bring variable cloudy, but mostly dry weather.
<G-vec00196-002-s138><bring_about.bringen><de> Der Nachmittag bringt sonniges oder leicht bewölktes Wetter.
<G-vec00196-002-s139><bring_about.bringen><en> Ex 23,20 "Behold, I am going to send an angel before you to guard you along the way and to bring you into the place which I have prepared.
<G-vec00196-002-s139><bring_about.bringen><de> 2Mo 23,20 Siehe, ich sende einen Engel vor dir her damit er dich auf dem Weg bewahrt und dich an den Ort bringt, den ich für dich bereitet habe.
<G-vec00196-002-s140><bring_about.bringen><en> Get the Noble Staff Components and bring it to Tataka.
<G-vec00196-002-s140><bring_about.bringen><de> Beschafft die Empyrianische Stabkomponente und bringt sie zu Tataka.
<G-vec00196-002-s141><bring_about.bringen><en> Givat Haviva is one of the biggest, oldest, and leading institutions which in Israel concern itself with Jewish Arab mutual understanding, which support cultural and religious pluralism, which work for democratic values and peace, and which bring the past of the Jewish people to the consciousness of the youth of today in its educational work.
<G-vec00196-002-s141><bring_about.bringen><de> Givat Haviva ist eines der größten, ältesten und führenden Institute, das sich in Israel für jüdisch-arabische Verständigung einsetzt, den kulturellen und religiösen Pluralismus fördert, für demokratische Werte und Frieden wirkt und die Vergangenheit des jüdischen Volkes in erzieherischer Arbeit der Jugend von heute nahe bringt.
<G-vec00196-002-s142><bring_about.bringen><en> The late evening will bring clouds with local snowfall.
<G-vec00196-002-s142><bring_about.bringen><de> Der Nachmittag bringt zeitweise sonniges Wetter.
<G-vec00196-002-s143><bring_about.bringen><en> We cannot predict what time will bring. But we can make it more beautiful.
<G-vec00196-002-s143><bring_about.bringen><de> Wir wissen nicht was die Zeit bringt, wir können sie aber schöner machen.
<G-vec00196-002-s144><bring_about.bringen><en> The night will bring cloudy, but mostly dry weather.
<G-vec00196-002-s144><bring_about.bringen><de> Der Nachmittag bringt wechselnd bewölktes und meist trockenes Wetter.
<G-vec00196-002-s145><bring_about.bringen><en> The noon will bring partly sunny, partly cloudy weather.
<G-vec00196-002-s145><bring_about.bringen><de> Die Mittagszeit bringt zeitweise sonniges Wetter.
<G-vec00196-002-s146><bring_about.bringen><en> Bring your tent, your passion and commitment and join us to stop the next generation of nuclear weapons from being built.
<G-vec00196-002-s146><bring_about.bringen><de> Bringt Euer Zelt, Eure Leidenschaft und Engagement und schließt Euch uns an, um zu verhindern, dass die nächste Generation von Atomwaffen gebaut wird.
<G-vec00196-002-s147><bring_about.bringen><en> Each sticker delivers a nice message for Christmas and will bring a chic touch to your gifts with their silver and gold colors.
<G-vec00196-002-s147><bring_about.bringen><de> Jeder Aufkleber liefert eine nette Nachricht für Weihnachten und bringt Ihren Geschenken mit ihren silbernen und goldenen Farben einen schicken Touch.
<G-vec00196-002-s148><bring_about.bringen><en> The evening will bring mostly cloudy weather.
<G-vec00196-002-s148><bring_about.bringen><de> Der Nachmittag bringt meist bewölktes, aber trockenes Wetter.
<G-vec00196-002-s149><bring_about.bringen><en> When one’s wishing turns to such subjects, he stops wishing and tries to acquire these by doing what he thinks will develop virtue and bring wisdom.
<G-vec00196-002-s149><bring_about.bringen><de> Wenn sich jemand solchen Themen zuwendet, hört er auf zu wünschen und versucht, diese zu erlangen, indem er das tut, von dem er glaubt, dass es Tugend entwickelt und Weisheit bringt.
<G-vec00196-002-s150><bring_about.bringen><en> The first stage only needs 10 Stars and will bring you 3000 Crystals, and the Microbiology Animated Paint if you have a Battle Pass.
<G-vec00196-002-s150><bring_about.bringen><de> Die erste Stufe benötigt nur 10 Sterne und bringt Euch 3000 Kristalle und die animierte Farbe «Mikrobiologie», wenn Ihr das Schlacht-Abonnement habt.
<G-vec00196-002-s151><bring_about.bringen><en> But Buddel is drunk so he might bring you to the wrong island.
<G-vec00196-002-s151><bring_about.bringen><de> Aber Buddel ist betrunken, deshalb kann es sein, dass er dich zur falschen Insel bringt.
<G-vec00196-002-s304><bring_about.bringen><en> Visitors are not allowed to drive directly to the house, but we will bring your baggage there for you .
<G-vec00196-002-s304><bring_about.bringen><de> Es besteht keine Fahrmöglichkeit für Sie zum Haus, allerdings wird das Gepäck von uns mit Ihnen hoch gebracht.
<G-vec00196-002-s305><bring_about.bringen><en> He was playing his acoustic guitar while she was standing at the doors, waiting for the tour manager to bring her to the band.
<G-vec00196-002-s305><bring_about.bringen><de> Er spielte auf seiner akustischen Gitarre, während sie an der Tür stand und darauf wartete, dass sie vom Tourmanager zur Band gebracht wurde.
<G-vec00196-002-s306><bring_about.bringen><en> Unfortunately the dress a tad too big and therefore it will be my first piece of clothing, ever that I will bring to the tailor.
<G-vec00196-002-s306><bring_about.bringen><de> Leider ist es mir ein wenig groß und so wird dieses Kleid mein erstes Stück sein, welches ich jemals zum Schneider gebracht habe.
<G-vec00196-002-s307><bring_about.bringen><en> Fixed network penetration peaked at around 32%, falling back slightly in response to recent price changes designed to bring prices more closely into line with costs as required by the acquis.
<G-vec00196-002-s307><bring_about.bringen><de> Die Anschlussdichte im Festnetz erreichte einen Höchststand von etwa 32 % und ging als Reaktion auf die jüngsten Tarifänderungen, mit denen die Tarife entsprechend den Vorgaben des Besitzstands in größere Übereinstimmung mit den echten Kosten gebracht werden sollen, leicht zurück.
<G-vec00196-002-s308><bring_about.bringen><en> 7:52, He asked to bring him to his home for one night.
<G-vec00196-002-s308><bring_about.bringen><de> 7:52 Er bat darum, für eine Nacht nach Hause gebracht zu werden.
<G-vec00196-002-s309><bring_about.bringen><en> But that has nearly nothing to do with my work on land and that did not bring me to deep-sea taxonomy.
<G-vec00196-002-s309><bring_about.bringen><de> Mit meiner täglichen Arbeit an Land hat das aber natürlich wenig zu tun und dieser Anreiz allein hat mich auch nicht zur Tiefsee-Taxonomie gebracht.
<G-vec00196-002-s310><bring_about.bringen><en> But the borrower did not bring nor did he deposit any money, since he came to the bank to get money he did not have.
<G-vec00196-002-s310><bring_about.bringen><de> Der Darlehensnehmer hat es jedoch weder gebracht noch eingezahlt, da er gekommen ist, um Geld zu holen, das er nicht besaß.
<G-vec00196-002-s311><bring_about.bringen><en> We continued to bring new and further stages of technical developments into the car in the second half of the season, but unfortunately they didn’t produce the performance gains we expected.
<G-vec00196-002-s311><bring_about.bringen><de> Wir haben auch in der zweiten Saisonhälfte technische Neu- und Weiterentwicklungen gebracht, sie haben aber leider nicht den erwarteten Zuwachs an Performance gebracht.
<G-vec00196-002-s312><bring_about.bringen><en> For this reason, it was first necessary to bring the different volumes of individual works to a unified level, as the volume can’t constantly be turned up and down on an aircraft, of course.
<G-vec00196-002-s312><bring_about.bringen><de> Daher mussten zunächst die unterschiedlichen Laufstärke der einzelnen Werke auf ein einheitliches Niveau gebracht werden, da man im Flugzeug natürlich nicht ständig lauter und leiser drehen kann.
<G-vec00196-002-s313><bring_about.bringen><en> Under the slogan “Bring it today, best in the morning, collect it tomorrow or already this evening”, W. Klinger is able to promise customers a highly appreciated full service.
<G-vec00196-002-s313><bring_about.bringen><de> Nach dem Motto: „Heute oder morgens gebracht, morgen oder schon abends gemacht“ bietet W. Klinger einen bei den Kunden gefragten Fullservice.
<G-vec00196-002-s314><bring_about.bringen><en> 3 And he proceeded to bring me there, and, look! there was a man.
<G-vec00196-002-s314><bring_about.bringen><de> 3 Als er mich dorthin gebracht hatte, erschien plötzlich ein Mann, der glänzend wie Erz aussah.
<G-vec00196-002-s315><bring_about.bringen><en> 11 Your gates shall be open continually; day and night they shall not be shut, that people may bring to you the wealth of the nations, with their kings led in procession.
<G-vec00196-002-s315><bring_about.bringen><de> 11 Deine Tore sollen stets offen stehen und weder Tag noch Nacht zugeschlossen werden, dass der Reichtum der Völker zu dir gebracht und ihre Könige herzugeführt werden.
<G-vec00196-002-s316><bring_about.bringen><en> There is a wheelchair available on all ships to use exclusively to bring the passenger into the cabin.
<G-vec00196-002-s316><bring_about.bringen><de> Auf allen Schiffen steht ein Rollstuhl zur Verfügung, den die Passagiere ausschließlich dafür nutzen können, in die Kabine gebracht zu werden.
<G-vec00196-002-s317><bring_about.bringen><en> It did not bring about a real social reform, although it became for the whole world a powerful threat and a challenge.
<G-vec00196-002-s317><bring_about.bringen><de> Er hat keine wirkliche Sozialreform zuwege gebracht, obwohl er für die ganze Welt zu einer mächtigen Bedrohung und einer Herausforderung geworden ist.
<G-vec00196-002-s318><bring_about.bringen><en> Hidden from view beneath the product surface of all highly complicated electronic systems is the pressure to develop at an acceptable price, manufacture and bring onto the market an utterly reliable as well as energy efficient product.
<G-vec00196-002-s318><bring_about.bringen><de> Für das Auge meist unsichtbar unter der Produktoberfläche verborgen, müssen elektronische Systeme mit höchster Komplexität in extrem kurzer Zeit zu einem akzeptablen Preis entworfen, hergestellt und auf den Markt gebracht werden und absolut zuverlässig sowie energieeffizient funktionieren.
<G-vec00196-002-s319><bring_about.bringen><en> Changing the page order within a PDF and then saving did not bring the desired effect.
<G-vec00196-002-s319><bring_about.bringen><de> Das Ändern der Seitenreihenfolge innerhalb einer PDF und das anschließende Speichern hat nicht den gewünschten Effekt gebracht.
<G-vec00196-002-s320><bring_about.bringen><en> I could rescue all my books and bring them back to Germany.
<G-vec00196-002-s320><bring_about.bringen><de> Meine sämtlichen Bücher habe ich gerettet und mit nach Deutschland gebracht.
<G-vec00196-002-s321><bring_about.bringen><en> Afterall, everyone wants that unique piece to bring back home.
<G-vec00196-002-s321><bring_about.bringen><de> Schließlich möchte jeder, dass dieses einzigartige Stück nach Hause gebracht wird.
<G-vec00196-002-s322><bring_about.bringen><en> We hope that these pages, which are constantly updated in order to bring you the very latest on our holiday menu, will help you plan your stay in advance.
<G-vec00196-002-s322><bring_about.bringen><de> Wir hoffen das diese Seiten, die ständig auf den neusten Stand gebracht werden, ihnen helfen werden ihren Aufenthalt so angenehm wie möglich im Voraus zu gestalten.
<G-vec00196-002-s247><bring_about.führen><en> 38 I will purge out the rebels from among you, and those who transgress against me; I will bring them out of the land where they sojourn, but they shall not enter the land of Israel. Then you will know that I am the LORD.
<G-vec00196-002-s247><bring_about.führen><de> Ich führe sie zwar aus dem Land, in dem sie als Fremde leben, heraus, in das Land Israel aber werden sie nicht kommen; dann werdet ihr erkennen, daß ich der Herr bin.
<G-vec00196-002-s248><bring_about.führen><en> 2 And desired of him letters to Damascus to the synagogues, that if he found any of this way, whether they were men or women, he might bring them bound unto Jerusalem.
<G-vec00196-002-s248><bring_about.führen><de> 2und bat ihn um Briefe nach Damaskus an die Synagogen, damit er Anhänger des neuen Weges, Männer und Frauen, wenn er sie dort fände, gefesselt nach Jerusalem führe.
<G-vec00196-002-s249><bring_about.führen><en> Paul had access and a reputation with the highest rulers in the Jews religion before his conversion. 2 And desired of him letters to Damascus to the synagogues, that if he found any of this way, whether they were men or women, he might bring them bound unto Jerusalem.
<G-vec00196-002-s249><bring_about.führen><de> 9 1 Saulus aber schnaubte noch mit Drohen und Morden gegen die Jünger des Herrn und ging zum Hohenpriester 2 und bat ihn um Briefe nach Damaskus an die Synagogen, damit er Anhänger des neuen Weges, Männer und Frauen, wenn er sie dort fände, gefesselt nach Jerusalem führe.
<G-vec00196-002-s250><bring_about.führen><en> In the footnote to this text he shows that other authorities agree with him in this respect. Leaving out then, these two unnecessary words, the full text reads, “For Christ also hath once suffered for sins, the just for the unjust, that he might bring us to God, being put to death in the flesh, but quickened by the Spirit; by which also he preached unto the spirits in prison.”
<G-vec00196-002-s250><bring_about.führen><de> In der Fußnote zu diesem Text zeigt er, dass andere Autoritäten ihm in dieser Hinsicht zustimmen: Wenn wir also diese beiden entbehrlichen Worte auslassen, lautet der vollständige Text: „Denn es hat ja Christus einmal für Sünden gelitten, der Gerechte für die Ungerechten, auf dass er uns zu Gott führe, getötet nach dem Fleische, aber lebendig gemacht nach dem Geiste, in welchem er auch predigte den Geistern, die im Gefängnis sind.“ Die Bedeutung hier ist offensichtlich, nämlich, dass Jesus durch seinen Tod und seine Auferstehung diesen gefallenen Engeln predigte - ein belehrendes Beispiel gab durch seine Ergebenheit für den Himmlischen Vater und Schöpfer, gegen den diese „Geister“ sich aufgelehnt hatten.
<G-vec00196-002-s251><bring_about.führen><en> "Today bring to Me all mankind, especially all sinners, and immerse them in the ocean of My mercy.
<G-vec00196-002-s251><bring_about.führen><de> JESUS: "Heute führe Mir die ganze Menschheit zu, besonders alle Sünder, und tauche sie ein in den Ozean Meiner Barmherzigkeit.
<G-vec00196-002-s252><bring_about.führen><en> 3 And I will gather the remnant of my flock out of all countries whither I have driven them, and will bring them again to their folds; and they shall be fruitful and increase.
<G-vec00196-002-s252><bring_about.führen><de> 3 "Ich sammle den Rest meiner Schafe aus allen Ländern, wohin ich sie versprengt habe, und führe sie wieder auf ihre Weide, daß sie wachsen und sich mehren.
<G-vec00196-002-s253><bring_about.führen><en> Jesus said: “Today bring to me all mankind, especially all sinners, and immerse them in the ocean of my mercy.
<G-vec00196-002-s253><bring_about.führen><de> JESUS: «Heute führe mir die ganze Menschheit zu, besonders alle Sünder, und tauche Sie ein in den Ozean Meiner Barmherzigkeit.
<G-vec00196-002-s254><bring_about.führen><en> Cross the ends twice in front at your forehead, then bring them together at the back and knot together.
<G-vec00196-002-s254><bring_about.führen><de> Überkreuze die beiden Enden vorne auf Höhe der Stirn zweimal und führe sie dann hinten zusammen und verknote das Ganze.
<G-vec00196-002-s255><bring_about.führen><en> Then the master of the house being angry said to his servant, Go out quickly into the streets and lanes of the city, and bring in hither the poor and maimed and blind and lame .
<G-vec00196-002-s255><bring_about.führen><de> Da wurde der Hausherr zornig und sprach zu seinem Knecht: Geh schnell hinaus auf die Straßen und Gassen der Stadt und führe die Armen, Verkrüppelten, Blinden und Lahmen herein.
<G-vec00196-002-s256><bring_about.führen><en> “Then Saul, still breathing threats and murder against the disciples of the Lord, went to the high priest and asked letters from him to the synagogues of Damascus, so that if he found any who were of the Way, whether men or women, he might bring them bound to Jerusalem.”
<G-vec00196-002-s256><bring_about.führen><de> Saulus aber schnaubte noch mit Drohen und Morden gegen die Jünger des Herrn und ging zum Hohenpriester und bat ihn um Briefe nach Damaskus an die Synagogen, damit er Anhänger des neuen Weges, Männer und Frauen, wenn er sie dort fände, gefesselt nach Jerusalem führe.
<G-vec00196-002-s257><bring_about.führen><en> Every support is granted to them from my side, which makes a spreading of pure truth possible, and for that reason everything is to be considered in accordance with the work for me and my kingdom, what approaches my servants, because I bring mine together, so that they can work united for me in the last time before the end.
<G-vec00196-002-s257><bring_about.führen><de> Ihnen wird von Mir aus jede Unterstützung gewährt, die ein Verbreiten der reinen Wahrheit ermöglicht, und darum soll alles im Sinne der Arbeit für Mich und Mein Reich betrachtet werden, was an Meine Diener herantritt, denn Ich führe die Meinen zusammen, auf daß sie vereint wirken können für Mich in der letzten Zeit vor dem Ende.
<G-vec00196-002-s258><bring_about.führen><en> 13 Lv 24, 13 And the LORD spake unto Moses, saying, 14 Lv 24, 14 Bring forth him that hath cursed without the camp; and let all that heard him lay their hands upon his head, and let all the congregation stone him.
<G-vec00196-002-s258><bring_about.führen><de> 13 Lv 24, 13 Und Jehova redete zu Mose und sprach: 14 Lv 24, 14 Führe den Flucher außerhalb des Lagers; und alle, die es gehört haben, sollen ihre Hände auf seinen Kopf legen, und die ganze Gemeinde soll ihn steinigen.
<G-vec00196-002-s259><bring_about.führen><en> 15 And he said to him, If thy presence do not go, bring us not up hence.
<G-vec00196-002-s259><bring_about.führen><de> 15Mose aber sprach zu ihm: Wenn nicht dein Angesicht vorangeht, so führe uns nicht von hier hinauf.
<G-vec00196-002-s260><bring_about.führen><en> Bring them down to the water, and I will test them for you there.
<G-vec00196-002-s260><bring_about.führen><de> Führe sie hinab ans Wasser; dort will ich sie dir sichten.
<G-vec00196-002-s261><bring_about.führen><en> Bring the petals together to create "legs."
<G-vec00196-002-s261><bring_about.führen><de> Führe die Blütenblätter zusammen, um "Beine" zu kreieren.
<G-vec00196-002-s262><bring_about.führen><en> Bring your guests in a dark room.
<G-vec00196-002-s262><bring_about.führen><de> Führe deine Gäste in einen dunklen Raum.
<G-vec00196-002-s263><bring_about.führen><en> For your cone shape, bring one cut end of your disc over to the other in a cone shape.
<G-vec00196-002-s263><bring_about.führen><de> Führe ein Schnittende deiner Scheibe in einer Kegelform über das andere.
<G-vec00196-002-s264><bring_about.führen><en> Using your left hand for aim and right for power, bring the ball across your body and towards your target.
<G-vec00196-002-s264><bring_about.führen><de> Führe den Ball über deinen Körper und auf dein Ziel zu, wobei du deine linke Hand zum Zielen und die rechte für die Kraft gebrauchst.
<G-vec00196-002-s265><bring_about.führen><en> Bring us, and all your chosen ones, to the fullness of grace in your eternal Kingdom.
<G-vec00196-002-s265><bring_about.führen><de> Führe uns und alle deine Auserwählten zur Fülle der Gnade in dein ewiges Reich.
<G-vec00196-002-s266><bring_about.führen><en> The ministers decided on recommendations for all 27 EU countries regarding sound economic policy and economic reforms that will help bring Europe out of the crisis and boost growth and job creation.
<G-vec00196-002-s266><bring_about.führen><de> Die Minister einigten sich auf Empfehlungen für alle 27 EU-Länder in Bezug auf eine gesunde Wirtschaftspolitik und Reformen, die Europa aus der Krise führen, das Wachstum ankurbeln und Jobs schaffen sollen.
<G-vec00196-002-s267><bring_about.führen><en> Yet, the decline could likewise bring about wellness issues given that the body sheds a security layer versus any type of diseases.
<G-vec00196-002-s267><bring_about.führen><de> Dennoch kann die Abnahme auch zu gesundheitlichen Problemen führen, weil der Körper eine Schutzschicht gegen alle Arten von Krankheiten verliert.
<G-vec00196-002-s268><bring_about.führen><en> 24 "'I will take you from the nations and gather you from all the countries; then I will bring you to your land.
<G-vec00196-002-s268><bring_about.führen><de> Denn ich will euch aus den Heiden holen und euch aus allen Landen versammeln und wieder in euer Land führen.
<G-vec00196-002-s269><bring_about.führen><en> All participants agreed that it makes sense to use such a cooperation as a medium to bring the Earth observation and OSGeo communities closer together.
<G-vec00196-002-s269><bring_about.führen><de> Alle Beteiligten waren sich darüber einig, dass es sinnvoll ist eine solche Kooperation als Medium zu nutzen, um die Erdbeobachtungs- und die OSGeo-Community enger zusammen zu führen.
<G-vec00196-002-s270><bring_about.führen><en> Place your fingertips behind your head, lift your upper back off of the mat, and rotate your torso to bring your right elbow toward your left knee.
<G-vec00196-002-s270><bring_about.führen><de> Drehe deinen Oberkörper, um deinen rechten Ellenbogen zum linken Knie zu führen.
<G-vec00196-002-s271><bring_about.führen><en> How I labor morning, noon and night to prepare the days lesson and all the connections you must make to bring you to your next appointed times.
<G-vec00196-002-s271><bring_about.führen><de> Wie Ich am Morgen, am Nachmittag und in der Nacht arbeite, um die Lektionen für den Tag vorzubereiten und all die Verbindungen, die ihr machen müsst, um euch zu euren nächsten Terminen zu führen.
<G-vec00196-002-s272><bring_about.führen><en> From this it follows, however, that it was precisely on this major question that we had to bring the masses of the workers up against the treachery of the General Council, and that is what we did.
<G-vec00196-002-s272><bring_about.führen><de> Daraus aber folgt, dass man den Arbeitermassen eben in dieser wichtigsten Frage den Verrat des Generalrats greifbar vor Augen führen musste, was von uns auch getan wurde.
<G-vec00196-002-s273><bring_about.führen><en> It is Zentrum Paul Klee’s ambitious goal to bring together as many of the three artists‘ works – now scattered across the whole world – and to reveal the fascinating pictorial ‘competition’ that inspired Klee and Macke in particular to produce their supreme artistic achievements.
<G-vec00196-002-s273><bring_about.führen><de> Es ist das ehrgeizige Ziel des Zentrum Paul Klee, möglichst viele der heute über die ganze Welt verstreuten Arbeiten der drei Künstler zusammen zu führen und den faszinierenden bildnerischen «Wettstreit» zu veranschaulichen, der vor allem Klee und Macke während ihrer Reise zu künstlerischen Höchstleistungen inspirierte.
<G-vec00196-002-s274><bring_about.führen><en> 5 (UKJV) As also the high priest does bear me witness, and all the estate of the elders: from whom also I received letters unto the brethren, and went to Damascus, to bring them which were there bound unto Jerusalem, in order to be punished.
<G-vec00196-002-s274><bring_about.führen><de> 5 (ELB) wie auch der Hohepriester und die ganze Ältestenschaft mir Zeugnis gibt, von denen ich auch Briefe an die Brüder empfing und nach Damaskus reiste, um auch diejenigen, die dort waren, gebunden nach Jerusalem zu führen, auf daß sie gestraft würden.
<G-vec00196-002-s275><bring_about.führen><en> They bring together information and tasks from various systems and automate workflows.
<G-vec00196-002-s275><bring_about.führen><de> Sie führen Daten und Aufgaben aus verschiedenen Systemen zusammen und automatisieren Workflows.
<G-vec00196-002-s276><bring_about.führen><en> God's grace working in the heart of an individual may bring about a desire to communicate with someone who understands.
<G-vec00196-002-s276><bring_about.führen><de> Gottes Gnade, die im Herzen jedes Einzelnen tätig ist, mag zu dem Wunsch führen, mit jemandem zu sprechen, der auch versteht.
<G-vec00196-002-s277><bring_about.führen><en> While temperatures stay pleasant year-round, hurricane season is a serious threat that may bring in heavy rains (or worse) that can ruin plans.
<G-vec00196-002-s277><bring_about.führen><de> Während die Temperaturen das ganze Jahr über angenehm bleiben, ist die Hurrikansaison eine ernsthafte Bedrohung, die zu heftigen Regenfällen (oder schlechter) führen kann, die die Pläne ruinieren können.
<G-vec00196-002-s278><bring_about.führen><en> At the same time it wants to bring Germany to autarky, i.e., onto the road of provincialism and voluntary restriction.
<G-vec00196-002-s278><bring_about.führen><de> Gleichzeitig will er Deutschland zur Autarkie führen, d.h. auf den Weg des Provinzialismus und der Selbstbeschränkung.
<G-vec00196-002-s279><bring_about.führen><en> Take the Maienfeld exit and drive towards Bad Ragaz. This will bring you directly to the Grand Resort Bad Ragaz (right after the roundabout on the left side).
<G-vec00196-002-s279><bring_about.führen><de> Nehmen Sie die Ausfahrt Maienfeld und fahren Sie in Richtung Bad Ragaz, dies wird Sie direkt zum Grand Resort Bad Bad Ragaz führen (nach dem Kreisverkehr auf der linken Seite).
<G-vec00196-002-s280><bring_about.führen><en> 2 and asked him for letters to the synagogues at Damascus, so that if he found any belonging to the Way, men or women, he might bring them bound to Jerusalem.
<G-vec00196-002-s280><bring_about.führen><de> 2 und erbat sich von ihm Briefe nach Damaskus an die Synagogen, in der Absicht, wenn er irgendwelche Anhänger des Weges1 fände, ob Männer oder Frauen, sie gebunden nach Jerusalem zu führen.
<G-vec00196-002-s281><bring_about.führen><en> The task of the enemy is to bring people into corruption by deception, which finally ends with eternal damnation.
<G-vec00196-002-s281><bring_about.führen><de> Die Aufgabe des Feindes ist durch Täuschung die Menschen ins Verderben zu führen, welche schlussendlich mit der ewigen Verdammnis endet.
<G-vec00196-002-s282><bring_about.führen><en> Among them the figure of Elijah stands out, impelled by God to bring the people to conversion.
<G-vec00196-002-s282><bring_about.führen><de> Unter ihnen hebt sich die Gestalt des Elija heraus, der von Gott erweckt wurde, um das Volk zur Umkehr zu führen.
<G-vec00196-002-s283><bring_about.führen><en> "Cristian will first supervise the challenging development of our next generation core satellite systems, Meteosat Third Generation (MTG) and the EUMETSAT Polar System of Second Generation (EPS-SG), which we expect will bring forecasting of high-impact weather into a new era in the next decade.
<G-vec00196-002-s283><bring_about.führen><de> „Cristian wird zunächst die anspruchsvolle Entwicklung der nächsten Generation unserer wichtigsten Satellitensysteme, überwachen, von denen wir uns erhoffen, dass sie die Vorhersagen schwerer Wetterphänomene im Laufe des kommenden Jahrzehnts in eine neue Ära führen werden.
<G-vec00196-002-s284><bring_about.führen><en> The test device is capable of switching currents up to 500 A and includes safety functions which bring the device to a secure state during malfunction.
<G-vec00196-002-s284><bring_about.führen><de> Der Prüfstand kann Ströme bis zu 500 A schalten und bietet Sicherheitsfunktionen, die das Gerät bei Fehlverhalten in einen sicheren Zustand führen.
