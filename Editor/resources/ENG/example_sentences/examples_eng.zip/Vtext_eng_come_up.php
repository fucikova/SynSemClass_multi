<G-vec00006-002-s266><come_up.vorkommen><en> It was a feature of the UK implementation of the EMD that KYC measures did not come into play until a client had developed a material level of activity.
<G-vec00006-002-s266><come_up.vorkommen><de> Ein Merkmal der Umsetzung der EGR im Vereinigten Königreich bestand darin, dass das KYC-Prinzip erst zum Tragen kam, wenn ein Kunde beachtliche Aktivitäten entfaltete.
<G-vec00006-002-s267><come_up.vorkommen><en> I've come to understand the inner logic of the Tech. It is expressed in the Factors, the Axioms, and the Class VIII materials.
<G-vec00006-002-s267><come_up.vorkommen><de> Ich kam zum Verständnis der inneren Logik der Tech, die in den Faktoren, den Axiomen und den Class VIII Materialien ausgedrückt ist.
<G-vec00006-002-s268><come_up.vorkommen><en> No one has seen you come but you have come to stay.
<G-vec00006-002-s268><come_up.vorkommen><de> Niemand sah ihn kommen, aber er kam, um zu bleiben.
<G-vec00006-002-s269><come_up.vorkommen><en> Twice it has come with no tidings from abroad, but now finally with its return the knight and his servant ride back from Rome, bearing a papal ban against the widow who dared oppose the pious Bishop.
<G-vec00006-002-s269><come_up.vorkommen><de> Zweimal kam er, nun endlich ruft er den Rittern und Knechten ein Willkommen entgegen, die mit einem päpstlichen Briefe von Rom heimkehren, mit einem Bannbriefe über die Witwe, die den frommen Bischof zu beleidigen wagte.
<G-vec00006-002-s270><come_up.vorkommen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00006-002-s270><come_up.vorkommen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00006-002-s271><come_up.vorkommen><en> I was wearing a white gown but when reached where I was going, I come upon at least eight people sitting in chairs in half horseshoe shape.
<G-vec00006-002-s271><come_up.vorkommen><de> Ich trug ein weißes Gewand, aber als ich den Ort erreichte, zu dem ich hinstrebte, kam ich auf mindestens 8 Personen, die in Sesseln saßen, die hufeisenförmig aufgestellt waren.
<G-vec00006-002-s272><come_up.vorkommen><en> I'd come home off the road sometimes and find my wife crying.
<G-vec00006-002-s272><come_up.vorkommen><de> Ich kam einmal nach unserem Konzert nach Hause und fand meine Frau weinend zu Hause.
<G-vec00006-002-s273><come_up.vorkommen><en> Go, and you shall proceed, and come to the man of God to mount Carmel.
<G-vec00006-002-s273><come_up.vorkommen><de> 25 Also zog sie hin und kam zu dem Mann Gottes auf den Berg Karmel.
<G-vec00006-002-s274><come_up.vorkommen><en> The Term "summary" has come to us from the Latin language.
<G-vec00006-002-s274><come_up.vorkommen><de> Der Begriff "Zusammenfassung" kam zu uns aus der lateinischen Sprache.
<G-vec00006-002-s275><come_up.vorkommen><en> If Clara, who has been living in Jerusalem for years, remembers the joy of a year when she accompanied the person closest to her in the Basilica, her mother who had come to visit her, Elena waits for her parents and Sara remembers the joy of when she celebrated her Easter with his colleagues in a family atmosphere.
<G-vec00006-002-s275><come_up.vorkommen><de> Clara, die seit Jahren in Jerusalem wohnt, erinnert sich an die Freude des Jahres, als sie die Person, die ihr am meisten am Herzen liegt, nämlich ihre Mutter, die sie besuchen kam, in die Basilika begleitete, und so erwartet auch Elena ihre Eltern und Sara ist die Freude beim Feiern des Osterfestes mit ihren Kollegen in einer vertrauten Atmosphäre in Erinnerung geblieben.
<G-vec00006-002-s276><come_up.vorkommen><en> Despondent, we waited for someone from the team to come rescue us.
<G-vec00006-002-s276><come_up.vorkommen><de> Niedergeschlagen warteten wir darauf, dass jemand vom Team kam, um uns abzuholen.
<G-vec00006-002-s277><come_up.vorkommen><en> He did not realise where it had come from, though the servants who had drawn the water knew.
<G-vec00006-002-s277><come_up.vorkommen><de> Er wusste nicht, woher der Wein kam; die Diener aber, die das Wasser geschöpft hatten, wussten es.
<G-vec00006-002-s278><come_up.vorkommen><en> Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.
<G-vec00006-002-s278><come_up.vorkommen><de> Dennoch gewährte Ich diesen und ihren Vätern Versorgung in Fülle, bis die Wahrheit und ein offenkundiger Gesandter zu ihnen kam.
<G-vec00006-002-s279><come_up.vorkommen><en> They follow nothing but conjecture and what the souls desire!- Even though there has already come to them Guidance from their Lord!
<G-vec00006-002-s279><come_up.vorkommen><de> Sie folgen einem bloßen Wahn und dem Wunsche (ihres) Ichs, obwohl doch Weisung von ihrem Herrn zu ihnen kam.
<G-vec00006-002-s280><come_up.vorkommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec00006-002-s280><come_up.vorkommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec00006-002-s281><come_up.vorkommen><en> Dear children, I am your Mom and come from Heaven to lead you to My Lord.
<G-vec00006-002-s281><come_up.vorkommen><de> Ich bin eure Mutter und kam vom Himmel um euch zum Himmel zu fuehren.
<G-vec00006-002-s282><come_up.vorkommen><en> But because the Holy Spirit has come to dwell within us, and because of the promises in John 14, Jesus makes it very plain that Our Authentic Christian faith is not an esoteric religion, secret elite society, New Age or Buddhist doctrine.
<G-vec00006-002-s282><come_up.vorkommen><de> Aber weil der Heilige Geist kam, um in uns zu wohnen und aufgrund der Verheissungen in Johannes 14, macht es Jesus sehr deutlich, dass unser authentischer, christlicher Glaube keine esoterische Religion, keine geheime, elitäre Gesellschaft, kein New Age und keine buddhistische Lehre ist.
<G-vec00006-002-s283><come_up.vorkommen><en> But through their trespass salvation has come to the Gentiles, so as to make Israel jealous.
<G-vec00006-002-s283><come_up.vorkommen><de> Vielmehr kam durch ihr Versagen das Heil zu den Heiden, um sie selbst eifersüchtig zu machen.
<G-vec00006-002-s284><come_up.vorkommen><en> I saw her last one 16 months ago before I come to Germany.
<G-vec00006-002-s284><come_up.vorkommen><de> Ich habe sie zuletzt vor 16 Monaten gesehen, bevor ich nach Deutschland kam.
<G-vec00006-002-s285><come_up.vorkommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00006-002-s285><come_up.vorkommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00006-002-s286><come_up.vorkommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00006-002-s286><come_up.vorkommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00006-002-s287><come_up.vorkommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00006-002-s287><come_up.vorkommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00006-002-s288><come_up.vorkommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00006-002-s288><come_up.vorkommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00006-002-s289><come_up.vorkommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00006-002-s289><come_up.vorkommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00006-002-s290><come_up.vorkommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00006-002-s290><come_up.vorkommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00006-002-s291><come_up.vorkommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00006-002-s291><come_up.vorkommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00006-002-s292><come_up.vorkommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00006-002-s292><come_up.vorkommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00006-002-s293><come_up.vorkommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00006-002-s293><come_up.vorkommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00006-002-s294><come_up.vorkommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00006-002-s294><come_up.vorkommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00006-002-s295><come_up.vorkommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00006-002-s295><come_up.vorkommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00006-002-s296><come_up.vorkommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00006-002-s296><come_up.vorkommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00006-002-s297><come_up.vorkommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00006-002-s297><come_up.vorkommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00006-002-s298><come_up.vorkommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00006-002-s298><come_up.vorkommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00006-002-s299><come_up.vorkommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00006-002-s299><come_up.vorkommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00006-002-s300><come_up.vorkommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00006-002-s300><come_up.vorkommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00006-002-s301><come_up.vorkommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00006-002-s301><come_up.vorkommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00006-002-s302><come_up.vorkommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00006-002-s302><come_up.vorkommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00006-002-s303><come_up.vorkommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00006-002-s303><come_up.vorkommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00006-002-s304><come_up.vorkommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec00006-002-s304><come_up.vorkommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec00006-002-s305><come_up.vorkommen><en> All your wishes - come true here.
<G-vec00006-002-s305><come_up.vorkommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec00006-002-s306><come_up.vorkommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec00006-002-s306><come_up.vorkommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec00006-002-s307><come_up.vorkommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00006-002-s307><come_up.vorkommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00006-002-s308><come_up.vorkommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec00006-002-s308><come_up.vorkommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec00006-002-s309><come_up.vorkommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00006-002-s309><come_up.vorkommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00006-002-s310><come_up.vorkommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec00006-002-s310><come_up.vorkommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec00006-002-s311><come_up.vorkommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec00006-002-s311><come_up.vorkommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec00006-002-s312><come_up.vorkommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec00006-002-s312><come_up.vorkommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec00006-002-s313><come_up.vorkommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec00006-002-s313><come_up.vorkommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec00006-002-s314><come_up.vorkommen><en> Come wherever you are unknown.
<G-vec00006-002-s314><come_up.vorkommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec00006-002-s315><come_up.vorkommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec00006-002-s315><come_up.vorkommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec00006-002-s316><come_up.vorkommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec00006-002-s316><come_up.vorkommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec00006-002-s317><come_up.vorkommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec00006-002-s317><come_up.vorkommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec00006-002-s318><come_up.vorkommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec00006-002-s318><come_up.vorkommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec00006-002-s319><come_up.vorkommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec00006-002-s319><come_up.vorkommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec00006-002-s320><come_up.vorkommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec00006-002-s320><come_up.vorkommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec00006-002-s321><come_up.vorkommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec00006-002-s321><come_up.vorkommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec00006-002-s322><come_up.vorkommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec00006-002-s322><come_up.vorkommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec00006-002-s323><come_up.vorkommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec00006-002-s323><come_up.vorkommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec00006-002-s324><come_up.vorkommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00006-002-s324><come_up.vorkommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00006-002-s325><come_up.vorkommen><en> – English translation: I come from Britain.
<G-vec00006-002-s325><come_up.vorkommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec00006-002-s326><come_up.vorkommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00006-002-s326><come_up.vorkommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00006-002-s327><come_up.vorkommen><en> Will definitely come back if headed to this area again.
<G-vec00006-002-s327><come_up.vorkommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec00006-002-s328><come_up.vorkommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec00006-002-s328><come_up.vorkommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec00006-002-s329><come_up.vorkommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec00006-002-s329><come_up.vorkommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec00006-002-s330><come_up.vorkommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec00006-002-s330><come_up.vorkommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00006-002-s331><come_up.vorkommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec00006-002-s331><come_up.vorkommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00006-002-s332><come_up.vorkommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec00006-002-s332><come_up.vorkommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec00006-002-s333><come_up.vorkommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec00006-002-s333><come_up.vorkommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec00006-002-s334><come_up.vorkommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec00006-002-s334><come_up.vorkommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec00006-002-s335><come_up.vorkommen><en> I come from the picturesque city of brides, Sumy.
<G-vec00006-002-s335><come_up.vorkommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec00006-002-s336><come_up.vorkommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec00006-002-s336><come_up.vorkommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec00006-002-s337><come_up.vorkommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec00006-002-s337><come_up.vorkommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec00006-002-s338><come_up.vorkommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec00006-002-s338><come_up.vorkommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec00006-002-s339><come_up.vorkommen><en> And so I come to a second reflection.
<G-vec00006-002-s339><come_up.vorkommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec00006-002-s340><come_up.vorkommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec00006-002-s340><come_up.vorkommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec00006-002-s341><come_up.vorkommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec00006-002-s341><come_up.vorkommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec00006-002-s342><come_up.vorkommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec00006-002-s342><come_up.vorkommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec00006-002-s343><come_up.vorkommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec00006-002-s343><come_up.vorkommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec00006-002-s344><come_up.vorkommen><en> I love this country so it has been nice to be forced to come home.
<G-vec00006-002-s344><come_up.vorkommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec00006-002-s345><come_up.vorkommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec00006-002-s345><come_up.vorkommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec00006-002-s346><come_up.vorkommen><en> These now come from the cold stores.
<G-vec00006-002-s346><come_up.vorkommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec00006-002-s347><come_up.vorkommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec00006-002-s347><come_up.vorkommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec00006-002-s348><come_up.vorkommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec00006-002-s348><come_up.vorkommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec00006-002-s349><come_up.vorkommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec00006-002-s349><come_up.vorkommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec00006-002-s350><come_up.vorkommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec00006-002-s350><come_up.vorkommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec00006-002-s351><come_up.vorkommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec00006-002-s351><come_up.vorkommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec00006-002-s352><come_up.vorkommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec00006-002-s352><come_up.vorkommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec00006-002-s353><come_up.vorkommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00006-002-s353><come_up.vorkommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00006-002-s354><come_up.vorkommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec00006-002-s354><come_up.vorkommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec00006-002-s355><come_up.vorkommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec00006-002-s355><come_up.vorkommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec00006-002-s356><come_up.vorkommen><en> The artists come from Frohnau or other places.
<G-vec00006-002-s356><come_up.vorkommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec00006-002-s357><come_up.vorkommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec00006-002-s357><come_up.vorkommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec00006-002-s358><come_up.vorkommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec00006-002-s358><come_up.vorkommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec00006-002-s359><come_up.vorkommen><en> It looks like the babies all come in "twos" this spring.
<G-vec00006-002-s359><come_up.vorkommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec00006-002-s360><come_up.vorkommen><en> Come, see, hear, and marvel.
<G-vec00006-002-s360><come_up.vorkommen><de> Kommen, schauen, hören, staunen.
<G-vec00006-002-s361><come_up.vorkommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec00006-002-s361><come_up.vorkommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec00006-002-s362><come_up.vorkommen><en> Come to us, and you will not regret.
<G-vec00006-002-s362><come_up.vorkommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec00006-002-s363><come_up.vorkommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec00006-002-s363><come_up.vorkommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec00006-002-s364><come_up.vorkommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec00006-002-s364><come_up.vorkommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec00006-002-s365><come_up.vorkommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec00006-002-s365><come_up.vorkommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec00006-002-s366><come_up.vorkommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec00006-002-s366><come_up.vorkommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec00006-002-s367><come_up.vorkommen><en> Come and have a look or check our website.
<G-vec00006-002-s367><come_up.vorkommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec00006-002-s368><come_up.vorkommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec00006-002-s368><come_up.vorkommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec00006-002-s369><come_up.vorkommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec00006-002-s369><come_up.vorkommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec00006-002-s370><come_up.vorkommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec00006-002-s370><come_up.vorkommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec00006-002-s371><come_up.vorkommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec00006-002-s371><come_up.vorkommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec00006-002-s372><come_up.vorkommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec00006-002-s372><come_up.vorkommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec00006-002-s373><come_up.vorkommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec00006-002-s373><come_up.vorkommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec00006-002-s374><come_up.vorkommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec00006-002-s374><come_up.vorkommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec00006-002-s375><come_up.vorkommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec00006-002-s375><come_up.vorkommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec00006-002-s376><come_up.vorkommen><en> Come to Ulm – it will make a difference in your life.
<G-vec00006-002-s376><come_up.vorkommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec00006-002-s377><come_up.vorkommen><en> Just come, book it now and you will see for yourself.
<G-vec00006-002-s377><come_up.vorkommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec00006-002-s378><come_up.vorkommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec00006-002-s378><come_up.vorkommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec00006-002-s379><come_up.vorkommen><en> Here come easily in 4 steps to your desired server.
<G-vec00006-002-s379><come_up.vorkommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec00006-002-s399><come_up.vorkommen><en> Lights turn on when you come home.
<G-vec00006-002-s399><come_up.vorkommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec00006-002-s400><come_up.vorkommen><en> From there you will not come back.
<G-vec00006-002-s400><come_up.vorkommen><de> Von da kommst du nicht zurück.
<G-vec00006-002-s401><come_up.vorkommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec00006-002-s401><come_up.vorkommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec00006-002-s402><come_up.vorkommen><en> Will you come over and play for me.
<G-vec00006-002-s402><come_up.vorkommen><de> Kommst du rüber und spielst für mich.
<G-vec00006-002-s403><come_up.vorkommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec00006-002-s403><come_up.vorkommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec00006-002-s404><come_up.vorkommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec00006-002-s404><come_up.vorkommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec00006-002-s405><come_up.vorkommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec00006-002-s405><come_up.vorkommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec00006-002-s406><come_up.vorkommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec00006-002-s406><come_up.vorkommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec00006-002-s407><come_up.vorkommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec00006-002-s407><come_up.vorkommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec00006-002-s408><come_up.vorkommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec00006-002-s408><come_up.vorkommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00006-002-s409><come_up.vorkommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec00006-002-s409><come_up.vorkommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec00006-002-s410><come_up.vorkommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec00006-002-s410><come_up.vorkommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec00006-002-s411><come_up.vorkommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec00006-002-s411><come_up.vorkommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec00006-002-s412><come_up.vorkommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec00006-002-s412><come_up.vorkommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec00006-002-s413><come_up.vorkommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec00006-002-s413><come_up.vorkommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec00006-002-s414><come_up.vorkommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec00006-002-s414><come_up.vorkommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00006-002-s415><come_up.vorkommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec00006-002-s415><come_up.vorkommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec00006-002-s416><come_up.vorkommen><en> Moving forward is more like the platform you come from.
<G-vec00006-002-s416><come_up.vorkommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec00006-002-s417><come_up.vorkommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec00006-002-s417><come_up.vorkommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec00006-002-s418><come_up.vorkommen><en> The color must have come from cocoa powder.
<G-vec00006-002-s418><come_up.vorkommen><de> Die Farbe kommt von Kakaopulver.
<G-vec00006-002-s419><come_up.vorkommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec00006-002-s419><come_up.vorkommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec00006-002-s420><come_up.vorkommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec00006-002-s420><come_up.vorkommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec00006-002-s421><come_up.vorkommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec00006-002-s421><come_up.vorkommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec00006-002-s422><come_up.vorkommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec00006-002-s422><come_up.vorkommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec00006-002-s423><come_up.vorkommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec00006-002-s423><come_up.vorkommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec00006-002-s424><come_up.vorkommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec00006-002-s424><come_up.vorkommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec00006-002-s425><come_up.vorkommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00006-002-s425><come_up.vorkommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00006-002-s426><come_up.vorkommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec00006-002-s426><come_up.vorkommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec00006-002-s427><come_up.vorkommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec00006-002-s427><come_up.vorkommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec00006-002-s428><come_up.vorkommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec00006-002-s428><come_up.vorkommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec00006-002-s429><come_up.vorkommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec00006-002-s429><come_up.vorkommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec00006-002-s430><come_up.vorkommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec00006-002-s430><come_up.vorkommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec00006-002-s431><come_up.vorkommen><en> Come and see the place where the Lord was laid.
<G-vec00006-002-s431><come_up.vorkommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec00006-002-s432><come_up.vorkommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec00006-002-s432><come_up.vorkommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec00006-002-s433><come_up.vorkommen><en> Run up till you come to the snapping doors.
<G-vec00006-002-s433><come_up.vorkommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec00006-002-s434><come_up.vorkommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec00006-002-s434><come_up.vorkommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec00006-002-s435><come_up.vorkommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec00006-002-s435><come_up.vorkommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec00006-002-s436><come_up.vorkommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec00006-002-s436><come_up.vorkommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
<G-vec00097-002-s570><come_up.eintreffen><en> In the process, people can come together who work in various forms of the care sector: professional care providers, caregivers in family and neighbour contexts, and those in self-care situations.
<G-vec00097-002-s570><come_up.eintreffen><de> Dabei treffen Menschen zusammen, die in verschiedener Form Arbeitende in diesem Bereich sind: Beruflich Sorgearbeitende, Sorgearbeitende in familiären und nachbarschaftlichen Zusammenhängen und in der Selbstsorge Tätige.
<G-vec00097-002-s571><come_up.eintreffen><en> Here you will come across a lot of young people and probably for the first time in a long time feel that there is something happening in the South Island!
<G-vec00097-002-s571><come_up.eintreffen><de> Hier wirst du viele junge Menschen treffen und vermutlich zum ersten Mal seit längerer Zeit das Gefühl haben, dass in Neuseeland ja doch etwas los ist.
<G-vec00097-002-s572><come_up.eintreffen><en> All the Syrians, as the UN Security Council resolution says, must sit down and come to an agreement.
<G-vec00097-002-s572><come_up.eintreffen><de> Alle Syrer sollten in Übereinstimmung mit der Resolution des UN-Sicherheitsrats am Verhandlungstisch zusammenkommen und eine Vereinbarung treffen.
<G-vec00097-002-s573><come_up.eintreffen><en> The prophet Isaiah brings to view the fearful deception which will come upon the wicked, causing them to count themselves secure from the judgments of God: "We have made a covenant with death, and with hell are we at agreement. When the overflowing scourge shall pass through, it shall not come unto (378) us; for we have made lies our refuge, and under falsehood have we hid ourselves." Isa.
<G-vec00097-002-s573><come_up.eintreffen><de> Der Prophet Jesaja weist auf die furchtbare Täuschung hin, welche über die Gottlosen kommen wird, so daß sie sich vor den Gerichten Gottes sicher fühlen: „Wir haben mit dem Tode einen Bund und mit der Hölle einen Vertrag gemacht; wenn eine Flut dahergeht, wird sie uns nicht treffen; denn wir haben die Lüge zu unserer Zuflucht und Heuchelei zu unserem Schirm gemacht.“ (Jes.
<G-vec00097-002-s574><come_up.eintreffen><en> Things often come to me with time, so a day later I sat on the beach and cried.
<G-vec00097-002-s574><come_up.eintreffen><de> Einen Tag später – manchmal treffen mich Dinge mit Zeitverzögerung – habe ich dann am Strand gesessen und geweint.
<G-vec00097-002-s575><come_up.eintreffen><en> If you cannot manage to come from Sunday to Sunday, try and come from Thursday or Friday evening until Sunday.
<G-vec00097-002-s575><come_up.eintreffen><de> Wer nicht von Sonntag bis Sonntag an den Treffen teilnehmen kann, sollte am Donnerstag- oder spätestens Freitagabend ankommen und bis Sonntag bleiben.
<G-vec00097-002-s576><come_up.eintreffen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00097-002-s576><come_up.eintreffen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00097-002-s577><come_up.eintreffen><en> As in the best tradition, the workshop is the natural place in which craftsmanship and design come together, inextricably linking production and design.
<G-vec00097-002-s577><come_up.eintreffen><de> Wie in der besten Tradition ist die Werkstatt der Ort, an dem sich Handwerk und Design treffen und dabei Produktion und Planung unlösbar miteinander verbinden.
<G-vec00097-002-s578><come_up.eintreffen><en> Numerous national and international representatives from business and politics will come together for this first-class event in order to discuss the most current topics.
<G-vec00097-002-s578><come_up.eintreffen><de> Anlässlich des hochkarätigen Anlasses treffen sich zahlreiche nationale und internationale Vertreter aus Wirtschaft und Politik in Vaduz, um topaktuelle Themen zu diskutieren.
<G-vec00097-002-s579><come_up.eintreffen><en> Then we pass through the gates of Heaven and come across the proud people who humbly pray the Pater Noster.
<G-vec00097-002-s579><come_up.eintreffen><de> Dann werden wir durch die Pforte des Himmels gehen und treffen die Stolzen die demütig das Pater Noster beten.
<G-vec00097-002-s580><come_up.eintreffen><en> Digitalisation and sustainability – two key “mega trends” come together.
<G-vec00097-002-s580><come_up.eintreffen><de> Digitalisierung und Nachhaltigkeit – hier treffen zwei Megatrends aufeinander.
<G-vec00097-002-s581><come_up.eintreffen><en> Schedule of events You can come and get to know the JBL team personally at the following events in April 2018.
<G-vec00097-002-s581><come_up.eintreffen><de> Auf folgenden Veranstaltungen können Sie uns im Juni 2018 treffen und das JBL Team persönlich kennenlernen.
<G-vec00097-002-s582><come_up.eintreffen><en> Wherever you go, you will come across open-minded people who will be happy to speak English with you.
<G-vec00097-002-s582><come_up.eintreffen><de> Überall werden Sie auf aufgeschlossene Menschen treffen, die gerne mit Ihnen Englisch plaudern.
<G-vec00097-002-s583><come_up.eintreffen><en> If these high-stakes talks come to pass, they would be the first between a sitting US president and a North Korean leader.
<G-vec00097-002-s583><come_up.eintreffen><de> Eine Reise des nordkoreanischen Außenministers nach Schweden nährt nun Spekulationen über den Austragungsort für dieses erste Treffen zwischen einem amtierenden US-Präsidenten und einem nordkoreanischen Machthaber.
<G-vec00097-002-s584><come_up.eintreffen><en> Because particular bodily organs correspond to every point, it is possible to come to the conclusion about state of this organs.
<G-vec00097-002-s584><come_up.eintreffen><de> Weil es jedem Punkt bestimmte Körperorgane entsprechen, ist auf Grund des gemessenen Widerstandes den Beschluss über den Stand dieser Organe zu treffen.
<G-vec00097-002-s585><come_up.eintreffen><en> Graduates of the Master of Science in International Cooperation in Urban Development come upon a broad field of work which has a strong demand for professionals in international projects about urban development.
<G-vec00097-002-s585><come_up.eintreffen><de> Absolventen und Absolventinnen des Master of Science International Cooperation in Urban Development treffen auf ein weites Arbeitsfeld mit einer starken Nachfrage nach Fachkräften für internationale Projekte im Bereich der Stadtentwicklung.
<G-vec00097-002-s586><come_up.eintreffen><en> Divers, snorkelers and musicians dressed in whimsical nautical costumes come together every year in Florida for the Underwater Music Festival.
<G-vec00097-002-s586><come_up.eintreffen><de> Taucher, Schnorchler und Musiker treffen sich Jahr für Jahr in Florida für das Unterwasser-Musik-Festival.
<G-vec00097-002-s587><come_up.eintreffen><en> The event aims to create a space in which different voices come together to start dialogue and find solutions and answers to the social, emotional and health problems that women face in today's society. The Forum is an open event, free of charge, with an open debate on women's issues.
<G-vec00097-002-s587><come_up.eintreffen><de> Mit diesem Forum will versucht werden ein Raum zu schaffen, in welchem sich verschiedene Stimmen treffen, unterschiedliche Meinungen ausgetauscht werden um so einen Dialog anzuregen und Lösungen und Antworten auf die soziale, emotionale und gesundheitliche Problematik zu finden, mit welcher sich die Frau tagtäglich in der Gesellschaft konfrontiert sieht.
<G-vec00097-002-s588><come_up.eintreffen><en> In the living room, family and friends come together for mutual hours.
<G-vec00097-002-s588><come_up.eintreffen><de> Im Wohnzimmer treffen sich Familie und Freunde für gemeinsame Stunden.
<G-vec00097-002-s152><come_up.kommen><en> Then you have come to the right place.
<G-vec00097-002-s152><come_up.kommen><de> Dann sind Sie zum rechten Platz gekommen.
<G-vec00097-002-s153><come_up.kommen><en> You have come to the right page.
<G-vec00097-002-s153><come_up.kommen><de> Sie sind zur rechten Seite gekommen.
<G-vec00097-002-s154><come_up.kommen><en> "The hour is come that the Son of man should be glorified" (John 12:23).
<G-vec00097-002-s154><come_up.kommen><de> "Die Stunde ist gekommen, dass der Menschensohn verherrlicht werden sollte" (Johannes 12:23).
<G-vec00097-002-s155><come_up.kommen><en> The Spirit had come upon him powerfully, and he had broken down, weeping.
<G-vec00097-002-s155><come_up.kommen><de> Der Geist war mächtig auf ihn gekommen, und er war weinend zusammengebrochen.
<G-vec00097-002-s156><come_up.kommen><en> “For judgment I have come into this world, so that the blind will see and those who see will become blind.”
<G-vec00097-002-s156><come_up.kommen><de> 39Und Jesus sprach: Ich bin zum Gericht auf diese Welt gekommen, auf daß, die da nicht sehen, sehend werden, und die da sehen, blind werden.
<G-vec00097-002-s157><come_up.kommen><en> SHAKIR: Certainly a Messenger has come to you from among yourselves; grievous to him is your falling into distress, excessively solicitous respecting you; to the believers (he is) compassionate, 009.129
<G-vec00097-002-s157><come_up.kommen><de> Wahrlich, ein Gesandter ist zu euch gekommen aus eurer Mitte; schmerzlich ist es ihm, daß ihr in Unheil geraten solltet; eure Wohlfahrt begehrt er eifrig; gegen die Gläubigen ist er gütig, barmherzig.
<G-vec00097-002-s158><come_up.kommen><en> I twisted around and ran back the way I had come.
<G-vec00097-002-s158><come_up.kommen><de> Ich drehte mich weg und lief den Weg zurück, den wir gekommen waren.
<G-vec00097-002-s159><come_up.kommen><en> Make a photo of the defect and make photos that show how the product was installed and how it has come to the damage if possible.
<G-vec00097-002-s159><come_up.kommen><de> Fotografieren Sie den Defekt und versuchen Sie dabei, auf den Fotos deutlich zu machen, wie das Produkt eingebaut war und wie es zu dem Schaden gekommen ist.
<G-vec00097-002-s160><come_up.kommen><en> Gehazi answered, “Yes, but my master sent me to say, ‘Two young men who are members of a group of prophets have just now come to me from the hills of Ephraim.
<G-vec00097-002-s160><come_up.kommen><de> Mein Herr sendet mich und lässt sagen: Siehe, eben jetzt sind vom Gebirge Ephraim zwei junge Männer von den Söhnen der Propheten zu mir gekommen.
<G-vec00097-002-s161><come_up.kommen><en> 12 "But I tell you: Elijah has already come, and they didn't recognize him. On the contrary, they did whatever they pleased to him.
<G-vec00097-002-s161><come_up.kommen><de> 13 Aber ich sage euch, daß auch Elias gekommen ist, und sie haben ihm getan, was irgend sie wollten, so wie über ihn geschrieben steht.
<G-vec00097-002-s162><come_up.kommen><en> But I am sure I have always thought of Christmas-time, when it has come round—apart from the veneration due to its sacred name and origin, if anything belonging to it can be apart from that—as a good time; a kind, forgiving, charitable, pleasant time; the only time I know of, in the long calendar of the year, when men and women seem by one consent to open their shut-up hearts freely, and to think of people below them as if they really were fellow-passengers to the grave, and not another race of creatures bound on other journeys.
<G-vec00097-002-s162><come_up.kommen><de> Aber das weiß ich bestimmt, daß ich Weihnachten, wenn es gekommen ist, abgesehen von der Verehrung, die wir seinem heiligen Namen und Ursprung schuldig sind, immer als eine gute Zeit angeschaut habe, als eine liebe Zeit, als die Zeit der Vergebung und des Erbarmens, als die einzige Zeit, die ich im langen Kalenderjahr kenne, wo die Menschen einträchtig ihre verschlossenen Herzen auftun und die andern Menschen betrachten, als wenn sie wirklich Reisegenossen nach dem Grabe wären und nicht eine ganz andere Art von Lebewesen, die für einen ganz andern Weg vorgesehen sind.
<G-vec00097-002-s163><come_up.kommen><en> But I have also come to share with you the joys and hopes, efforts and commitments, ideals and aspirations of this diocesan community.
<G-vec00097-002-s163><come_up.kommen><de> Doch ich bin auch gekommen, um mit euch Freuden und Hoffnungen, Mühen und Anstrengungen, Ideale und Wünsche dieser Diözesangemeinschaft zu teilen.
<G-vec00097-002-s164><come_up.kommen><en> It’s a funny story that just goes to show how far both our businesses have come.
<G-vec00097-002-s164><come_up.kommen><de> Es ist eine lustige Geschichte, die zeigt, wie weit unsere beiden Unternehmen gekommen sind.
<G-vec00097-002-s165><come_up.kommen><en> 27She said to Him, Yes, Lord, I have believed [I do believe] that You are the Christ (the Messiah, the Anointed One), the Son of God, [even He] Who was to come into the world.
<G-vec00097-002-s165><come_up.kommen><de> 27Sie spricht zu ihm: HERR, ja, ich glaube, daß du bist Christus, der Sohn Gottes, der in die Welt gekommen ist.
<G-vec00097-002-s166><come_up.kommen><en> Acts 1, verse 8 and 9 “But you will receive power when the Holy Spirit has come upon you. You will be witnesses to me in Jerusalem, in all Judea and Samaria, and to the uttermost parts of the earth.”
<G-vec00097-002-s166><come_up.kommen><de> Apostelgeschichte 1, Vers 8 und 9 Aber ihr werdet Kraft empfangen, wenn der Heilige Geist auf euch gekommen ist; und ihr werdet meine Zeugen sein, sowohl in Jerusalem als auch in ganz Judäa und Samaria und bis an das Ende der Erde.
<G-vec00097-002-s167><come_up.kommen><en> 13Thou wilt rise up, thou wilt have mercy upon Zion: for it is the time to be gracious to her, for the set time is come. 14For thy servants take pleasure in her stones, and favour her dust.
<G-vec00097-002-s167><come_up.kommen><de> 13Du wirst aufstehen, wirst dich Zions erbarmen; denn es ist Zeit, es zu begnadigen, denn gekommen ist die bestimmte Zeit; 14Denn deine Knechte haben Gefallen an seinen Steinen und haben Mitleid mit seinem Schutt.
<G-vec00097-002-s168><come_up.kommen><en> And he said, No; but I have come as captain of the armies of the Lord.
<G-vec00097-002-s168><come_up.kommen><de> Er sprach: Nein, sondern ich bin ein Fürst über das Heer des HERRN und bin jetzt gekommen.
<G-vec00097-002-s169><come_up.kommen><en> 47 “If anyone hears my words but does not keep them, I do not judge that person. For I did not come to judge the world, but to save the world.
<G-vec00097-002-s169><come_up.kommen><de> 47 Und wenn jemand meine Worte hört und nicht glaubt, so richte ich ihn nicht; denn ich bin nicht gekommen, um die Welt zu richten, sondern damit ich die Welt rette.
<G-vec00097-002-s170><come_up.kommen><en> Today, mankind has once again come to the crossroads of the transformation of the transportation energy power system.
<G-vec00097-002-s170><come_up.kommen><de> Heute ist die Menschheit wieder an den Scheideweg der Transformation des Verkehrsenergiesystems gekommen.
<G-vec00097-002-s266><come_up.kommen><en> It was a feature of the UK implementation of the EMD that KYC measures did not come into play until a client had developed a material level of activity.
<G-vec00097-002-s266><come_up.kommen><de> Ein Merkmal der Umsetzung der EGR im Vereinigten Königreich bestand darin, dass das KYC-Prinzip erst zum Tragen kam, wenn ein Kunde beachtliche Aktivitäten entfaltete.
<G-vec00097-002-s267><come_up.kommen><en> I've come to understand the inner logic of the Tech. It is expressed in the Factors, the Axioms, and the Class VIII materials.
<G-vec00097-002-s267><come_up.kommen><de> Ich kam zum Verständnis der inneren Logik der Tech, die in den Faktoren, den Axiomen und den Class VIII Materialien ausgedrückt ist.
<G-vec00097-002-s268><come_up.kommen><en> No one has seen you come but you have come to stay.
<G-vec00097-002-s268><come_up.kommen><de> Niemand sah ihn kommen, aber er kam, um zu bleiben.
<G-vec00097-002-s269><come_up.kommen><en> Twice it has come with no tidings from abroad, but now finally with its return the knight and his servant ride back from Rome, bearing a papal ban against the widow who dared oppose the pious Bishop.
<G-vec00097-002-s269><come_up.kommen><de> Zweimal kam er, nun endlich ruft er den Rittern und Knechten ein Willkommen entgegen, die mit einem päpstlichen Briefe von Rom heimkehren, mit einem Bannbriefe über die Witwe, die den frommen Bischof zu beleidigen wagte.
<G-vec00097-002-s270><come_up.kommen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00097-002-s270><come_up.kommen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00097-002-s271><come_up.kommen><en> I was wearing a white gown but when reached where I was going, I come upon at least eight people sitting in chairs in half horseshoe shape.
<G-vec00097-002-s271><come_up.kommen><de> Ich trug ein weißes Gewand, aber als ich den Ort erreichte, zu dem ich hinstrebte, kam ich auf mindestens 8 Personen, die in Sesseln saßen, die hufeisenförmig aufgestellt waren.
<G-vec00097-002-s272><come_up.kommen><en> I'd come home off the road sometimes and find my wife crying.
<G-vec00097-002-s272><come_up.kommen><de> Ich kam einmal nach unserem Konzert nach Hause und fand meine Frau weinend zu Hause.
<G-vec00097-002-s273><come_up.kommen><en> Go, and you shall proceed, and come to the man of God to mount Carmel.
<G-vec00097-002-s273><come_up.kommen><de> 25 Also zog sie hin und kam zu dem Mann Gottes auf den Berg Karmel.
<G-vec00097-002-s274><come_up.kommen><en> The Term "summary" has come to us from the Latin language.
<G-vec00097-002-s274><come_up.kommen><de> Der Begriff "Zusammenfassung" kam zu uns aus der lateinischen Sprache.
<G-vec00097-002-s275><come_up.kommen><en> If Clara, who has been living in Jerusalem for years, remembers the joy of a year when she accompanied the person closest to her in the Basilica, her mother who had come to visit her, Elena waits for her parents and Sara remembers the joy of when she celebrated her Easter with his colleagues in a family atmosphere.
<G-vec00097-002-s275><come_up.kommen><de> Clara, die seit Jahren in Jerusalem wohnt, erinnert sich an die Freude des Jahres, als sie die Person, die ihr am meisten am Herzen liegt, nämlich ihre Mutter, die sie besuchen kam, in die Basilika begleitete, und so erwartet auch Elena ihre Eltern und Sara ist die Freude beim Feiern des Osterfestes mit ihren Kollegen in einer vertrauten Atmosphäre in Erinnerung geblieben.
<G-vec00097-002-s276><come_up.kommen><en> Despondent, we waited for someone from the team to come rescue us.
<G-vec00097-002-s276><come_up.kommen><de> Niedergeschlagen warteten wir darauf, dass jemand vom Team kam, um uns abzuholen.
<G-vec00097-002-s277><come_up.kommen><en> He did not realise where it had come from, though the servants who had drawn the water knew.
<G-vec00097-002-s277><come_up.kommen><de> Er wusste nicht, woher der Wein kam; die Diener aber, die das Wasser geschöpft hatten, wussten es.
<G-vec00097-002-s278><come_up.kommen><en> Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.
<G-vec00097-002-s278><come_up.kommen><de> Dennoch gewährte Ich diesen und ihren Vätern Versorgung in Fülle, bis die Wahrheit und ein offenkundiger Gesandter zu ihnen kam.
<G-vec00097-002-s279><come_up.kommen><en> They follow nothing but conjecture and what the souls desire!- Even though there has already come to them Guidance from their Lord!
<G-vec00097-002-s279><come_up.kommen><de> Sie folgen einem bloßen Wahn und dem Wunsche (ihres) Ichs, obwohl doch Weisung von ihrem Herrn zu ihnen kam.
<G-vec00097-002-s280><come_up.kommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec00097-002-s280><come_up.kommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec00097-002-s281><come_up.kommen><en> Dear children, I am your Mom and come from Heaven to lead you to My Lord.
<G-vec00097-002-s281><come_up.kommen><de> Ich bin eure Mutter und kam vom Himmel um euch zum Himmel zu fuehren.
<G-vec00097-002-s282><come_up.kommen><en> But because the Holy Spirit has come to dwell within us, and because of the promises in John 14, Jesus makes it very plain that Our Authentic Christian faith is not an esoteric religion, secret elite society, New Age or Buddhist doctrine.
<G-vec00097-002-s282><come_up.kommen><de> Aber weil der Heilige Geist kam, um in uns zu wohnen und aufgrund der Verheissungen in Johannes 14, macht es Jesus sehr deutlich, dass unser authentischer, christlicher Glaube keine esoterische Religion, keine geheime, elitäre Gesellschaft, kein New Age und keine buddhistische Lehre ist.
<G-vec00097-002-s283><come_up.kommen><en> But through their trespass salvation has come to the Gentiles, so as to make Israel jealous.
<G-vec00097-002-s283><come_up.kommen><de> Vielmehr kam durch ihr Versagen das Heil zu den Heiden, um sie selbst eifersüchtig zu machen.
<G-vec00097-002-s284><come_up.kommen><en> I saw her last one 16 months ago before I come to Germany.
<G-vec00097-002-s284><come_up.kommen><de> Ich habe sie zuletzt vor 16 Monaten gesehen, bevor ich nach Deutschland kam.
<G-vec00097-002-s285><come_up.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00097-002-s285><come_up.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00097-002-s286><come_up.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00097-002-s286><come_up.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00097-002-s287><come_up.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00097-002-s287><come_up.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00097-002-s288><come_up.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00097-002-s288><come_up.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00097-002-s289><come_up.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00097-002-s289><come_up.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00097-002-s290><come_up.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00097-002-s290><come_up.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00097-002-s291><come_up.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00097-002-s291><come_up.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00097-002-s292><come_up.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00097-002-s292><come_up.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00097-002-s293><come_up.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00097-002-s293><come_up.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00097-002-s294><come_up.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00097-002-s294><come_up.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00097-002-s295><come_up.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00097-002-s295><come_up.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00097-002-s296><come_up.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00097-002-s296><come_up.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00097-002-s297><come_up.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00097-002-s297><come_up.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00097-002-s298><come_up.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00097-002-s298><come_up.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00097-002-s299><come_up.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00097-002-s299><come_up.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00097-002-s300><come_up.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00097-002-s300><come_up.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00097-002-s301><come_up.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00097-002-s301><come_up.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00097-002-s302><come_up.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00097-002-s302><come_up.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00097-002-s303><come_up.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00097-002-s303><come_up.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00097-002-s304><come_up.kommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec00097-002-s304><come_up.kommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec00097-002-s305><come_up.kommen><en> All your wishes - come true here.
<G-vec00097-002-s305><come_up.kommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec00097-002-s306><come_up.kommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec00097-002-s306><come_up.kommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec00097-002-s307><come_up.kommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00097-002-s307><come_up.kommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00097-002-s308><come_up.kommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec00097-002-s308><come_up.kommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec00097-002-s309><come_up.kommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00097-002-s309><come_up.kommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00097-002-s310><come_up.kommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec00097-002-s310><come_up.kommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec00097-002-s311><come_up.kommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec00097-002-s311><come_up.kommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec00097-002-s312><come_up.kommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec00097-002-s312><come_up.kommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec00097-002-s313><come_up.kommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec00097-002-s313><come_up.kommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec00097-002-s314><come_up.kommen><en> Come wherever you are unknown.
<G-vec00097-002-s314><come_up.kommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec00097-002-s315><come_up.kommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec00097-002-s315><come_up.kommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec00097-002-s316><come_up.kommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec00097-002-s316><come_up.kommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec00097-002-s317><come_up.kommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec00097-002-s317><come_up.kommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec00097-002-s318><come_up.kommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec00097-002-s318><come_up.kommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec00097-002-s319><come_up.kommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec00097-002-s319><come_up.kommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec00097-002-s320><come_up.kommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec00097-002-s320><come_up.kommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec00097-002-s321><come_up.kommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec00097-002-s321><come_up.kommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec00097-002-s322><come_up.kommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec00097-002-s322><come_up.kommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec00097-002-s323><come_up.kommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec00097-002-s323><come_up.kommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec00097-002-s324><come_up.kommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00097-002-s324><come_up.kommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00097-002-s325><come_up.kommen><en> – English translation: I come from Britain.
<G-vec00097-002-s325><come_up.kommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec00097-002-s326><come_up.kommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00097-002-s326><come_up.kommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00097-002-s327><come_up.kommen><en> Will definitely come back if headed to this area again.
<G-vec00097-002-s327><come_up.kommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec00097-002-s328><come_up.kommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec00097-002-s328><come_up.kommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec00097-002-s329><come_up.kommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec00097-002-s329><come_up.kommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec00097-002-s330><come_up.kommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec00097-002-s330><come_up.kommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00097-002-s331><come_up.kommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec00097-002-s331><come_up.kommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00097-002-s332><come_up.kommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec00097-002-s332><come_up.kommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec00097-002-s333><come_up.kommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec00097-002-s333><come_up.kommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec00097-002-s334><come_up.kommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec00097-002-s334><come_up.kommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec00097-002-s335><come_up.kommen><en> I come from the picturesque city of brides, Sumy.
<G-vec00097-002-s335><come_up.kommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec00097-002-s336><come_up.kommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec00097-002-s336><come_up.kommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec00097-002-s337><come_up.kommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec00097-002-s337><come_up.kommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec00097-002-s338><come_up.kommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec00097-002-s338><come_up.kommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec00097-002-s339><come_up.kommen><en> And so I come to a second reflection.
<G-vec00097-002-s339><come_up.kommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec00097-002-s340><come_up.kommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec00097-002-s340><come_up.kommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec00097-002-s341><come_up.kommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec00097-002-s341><come_up.kommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec00097-002-s342><come_up.kommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec00097-002-s342><come_up.kommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec00097-002-s343><come_up.kommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec00097-002-s343><come_up.kommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec00097-002-s344><come_up.kommen><en> I love this country so it has been nice to be forced to come home.
<G-vec00097-002-s344><come_up.kommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec00097-002-s345><come_up.kommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec00097-002-s345><come_up.kommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec00097-002-s346><come_up.kommen><en> These now come from the cold stores.
<G-vec00097-002-s346><come_up.kommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec00097-002-s347><come_up.kommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec00097-002-s347><come_up.kommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec00097-002-s348><come_up.kommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec00097-002-s348><come_up.kommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec00097-002-s349><come_up.kommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec00097-002-s349><come_up.kommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec00097-002-s350><come_up.kommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec00097-002-s350><come_up.kommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec00097-002-s351><come_up.kommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec00097-002-s351><come_up.kommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec00097-002-s352><come_up.kommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec00097-002-s352><come_up.kommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec00097-002-s353><come_up.kommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00097-002-s353><come_up.kommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00097-002-s354><come_up.kommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec00097-002-s354><come_up.kommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec00097-002-s355><come_up.kommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec00097-002-s355><come_up.kommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec00097-002-s356><come_up.kommen><en> The artists come from Frohnau or other places.
<G-vec00097-002-s356><come_up.kommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec00097-002-s357><come_up.kommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec00097-002-s357><come_up.kommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec00097-002-s358><come_up.kommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec00097-002-s358><come_up.kommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec00097-002-s359><come_up.kommen><en> It looks like the babies all come in "twos" this spring.
<G-vec00097-002-s359><come_up.kommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec00097-002-s360><come_up.kommen><en> Come, see, hear, and marvel.
<G-vec00097-002-s360><come_up.kommen><de> Kommen, schauen, hören, staunen.
<G-vec00097-002-s361><come_up.kommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec00097-002-s361><come_up.kommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec00097-002-s362><come_up.kommen><en> Come to us, and you will not regret.
<G-vec00097-002-s362><come_up.kommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec00097-002-s363><come_up.kommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec00097-002-s363><come_up.kommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec00097-002-s364><come_up.kommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec00097-002-s364><come_up.kommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec00097-002-s365><come_up.kommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec00097-002-s365><come_up.kommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec00097-002-s366><come_up.kommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec00097-002-s366><come_up.kommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec00097-002-s367><come_up.kommen><en> Come and have a look or check our website.
<G-vec00097-002-s367><come_up.kommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec00097-002-s368><come_up.kommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec00097-002-s368><come_up.kommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec00097-002-s369><come_up.kommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec00097-002-s369><come_up.kommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec00097-002-s370><come_up.kommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec00097-002-s370><come_up.kommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec00097-002-s371><come_up.kommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec00097-002-s371><come_up.kommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec00097-002-s372><come_up.kommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec00097-002-s372><come_up.kommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec00097-002-s373><come_up.kommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec00097-002-s373><come_up.kommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec00097-002-s374><come_up.kommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec00097-002-s374><come_up.kommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec00097-002-s375><come_up.kommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec00097-002-s375><come_up.kommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec00097-002-s376><come_up.kommen><en> Come to Ulm – it will make a difference in your life.
<G-vec00097-002-s376><come_up.kommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec00097-002-s377><come_up.kommen><en> Just come, book it now and you will see for yourself.
<G-vec00097-002-s377><come_up.kommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec00097-002-s378><come_up.kommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec00097-002-s378><come_up.kommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec00097-002-s379><come_up.kommen><en> Here come easily in 4 steps to your desired server.
<G-vec00097-002-s379><come_up.kommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec00097-002-s399><come_up.kommen><en> Lights turn on when you come home.
<G-vec00097-002-s399><come_up.kommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec00097-002-s400><come_up.kommen><en> From there you will not come back.
<G-vec00097-002-s400><come_up.kommen><de> Von da kommst du nicht zurück.
<G-vec00097-002-s401><come_up.kommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec00097-002-s401><come_up.kommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec00097-002-s402><come_up.kommen><en> Will you come over and play for me.
<G-vec00097-002-s402><come_up.kommen><de> Kommst du rüber und spielst für mich.
<G-vec00097-002-s403><come_up.kommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec00097-002-s403><come_up.kommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec00097-002-s404><come_up.kommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec00097-002-s404><come_up.kommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec00097-002-s405><come_up.kommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec00097-002-s405><come_up.kommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec00097-002-s406><come_up.kommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec00097-002-s406><come_up.kommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec00097-002-s407><come_up.kommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec00097-002-s407><come_up.kommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec00097-002-s408><come_up.kommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec00097-002-s408><come_up.kommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00097-002-s409><come_up.kommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec00097-002-s409><come_up.kommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec00097-002-s410><come_up.kommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec00097-002-s410><come_up.kommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec00097-002-s411><come_up.kommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec00097-002-s411><come_up.kommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec00097-002-s412><come_up.kommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec00097-002-s412><come_up.kommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec00097-002-s413><come_up.kommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec00097-002-s413><come_up.kommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec00097-002-s414><come_up.kommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec00097-002-s414><come_up.kommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00097-002-s415><come_up.kommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec00097-002-s415><come_up.kommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec00097-002-s416><come_up.kommen><en> Moving forward is more like the platform you come from.
<G-vec00097-002-s416><come_up.kommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec00097-002-s417><come_up.kommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec00097-002-s417><come_up.kommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec00097-002-s418><come_up.kommen><en> The color must have come from cocoa powder.
<G-vec00097-002-s418><come_up.kommen><de> Die Farbe kommt von Kakaopulver.
<G-vec00097-002-s419><come_up.kommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec00097-002-s419><come_up.kommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec00097-002-s420><come_up.kommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec00097-002-s420><come_up.kommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec00097-002-s421><come_up.kommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec00097-002-s421><come_up.kommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec00097-002-s422><come_up.kommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec00097-002-s422><come_up.kommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec00097-002-s423><come_up.kommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec00097-002-s423><come_up.kommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec00097-002-s424><come_up.kommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec00097-002-s424><come_up.kommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec00097-002-s425><come_up.kommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00097-002-s425><come_up.kommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00097-002-s426><come_up.kommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec00097-002-s426><come_up.kommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec00097-002-s427><come_up.kommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec00097-002-s427><come_up.kommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec00097-002-s428><come_up.kommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec00097-002-s428><come_up.kommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec00097-002-s429><come_up.kommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec00097-002-s429><come_up.kommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec00097-002-s430><come_up.kommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec00097-002-s430><come_up.kommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec00097-002-s431><come_up.kommen><en> Come and see the place where the Lord was laid.
<G-vec00097-002-s431><come_up.kommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec00097-002-s432><come_up.kommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec00097-002-s432><come_up.kommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec00097-002-s433><come_up.kommen><en> Run up till you come to the snapping doors.
<G-vec00097-002-s433><come_up.kommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec00097-002-s434><come_up.kommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec00097-002-s434><come_up.kommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec00097-002-s435><come_up.kommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec00097-002-s435><come_up.kommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec00097-002-s436><come_up.kommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec00097-002-s436><come_up.kommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
