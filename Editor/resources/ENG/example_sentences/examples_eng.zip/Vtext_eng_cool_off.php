<G-vec00463-002-s019><cool_off.abkühlen><en> That may cool your Surface down.
<G-vec00463-002-s019><cool_off.abkühlen><de> Möglicherweise wird das Surface hierdurch abgekühlt.
<G-vec00463-002-s020><cool_off.abkühlen><en> Make sure that the appliance is cool before you touch it.
<G-vec00463-002-s020><cool_off.abkühlen><de> Vergewissern Sie sich, dass das Gerät abgekühlt ist, bevor Sie es anfassen.
<G-vec00463-002-s021><cool_off.abkühlen><en> Iran continues to arm the terrorist organizations despite its cool relations with Hamas.
<G-vec00463-002-s021><cool_off.abkühlen><de> Der Iran bewaffnet die Terrororganisationen auch weiterhin, obwohl sich seine Beziehungen mit der Hamas stark abgekühlt haben.
<G-vec00463-002-s022><cool_off.abkühlen><en> Once the iron is cool, empty the water tank.
<G-vec00463-002-s022><cool_off.abkühlen><de> Sobald das Bügeleisen abgekühlt ist, leeren Sie den Wassertank.
<G-vec00463-002-s023><cool_off.abkühlen><en> Now wait for your radiators to cool down - depending on your home, this may take an hour or so, but it is important for the next step.
<G-vec00463-002-s023><cool_off.abkühlen><de> Warte nun bis deine Heizkörper abgekühlt sind - je nach Gebäudeeigenschaften kann dies eine Stunde oder sogar mehr dauern - aber es ist wichtig für den nächsten Schritt.
<G-vec00463-002-s024><cool_off.abkühlen><en> Snow / Ice Room / Frigidarium – dry and cold room intended to cool the body.
<G-vec00463-002-s024><cool_off.abkühlen><de> Schnee- / Eiszimmer / Frigidarium – ein trockener, kalter Raum, in dem man bleibt bis der Körper abgekühlt wird.
<G-vec00463-002-s025><cool_off.abkühlen><en> When the appliance is cool again, an acoustic signal sounds and the door unlocks.
<G-vec00463-002-s025><cool_off.abkühlen><de> Sobald das Gerät abgekühlt ist, ertönt ein akustisches Signal, und die Backofentür wird entriegelt.
<G-vec00463-002-s026><cool_off.abkühlen><en> The more advanced model comes with an automatic refrigeration system and variable temperature controls that can be set to cool the drinks to any temperature between 7 and 12 degrees Celsius.
<G-vec00463-002-s026><cool_off.abkühlen><de> Das erweiterte Modell ist mit einem automatischen Kühlsystem und variablen Temperaturreglern ausgestattet, mit denen die Getränke auf jede Temperatur zwischen sieben und 12 °C abgekühlt werden können.
<G-vec00463-002-s027><cool_off.abkühlen><en> If you are using chocolate decorations, allow the ganache to cool down a bit. Otherwise your decorations will melt.
<G-vec00463-002-s027><cool_off.abkühlen><de> Wenn man Schokodekoration verwendet, sollte man vielleicht warten bis die Ganache etwas abgekühlt ist, sonst schmilzt die Deko.
<G-vec00463-002-s028><cool_off.abkühlen><en> The sheet must remain in the correct shape until it is completely cool and hard again.
<G-vec00463-002-s028><cool_off.abkühlen><de> Die Platte muss in der richtigen Form bleiben, bis sie wieder vollständig abgekühlt und hart ist.
<G-vec00463-002-s029><cool_off.abkühlen><en> Following stirring for 2 hours at room temperature, the mixture was allowed to cool to room temperature, water was added, the product was extracted into toluene, and the organic layer was washed sequentially with water and a saturated aqueous solution of sodium chloride before being dried over anhydrous sodium sulfate.
<G-vec00463-002-s029><cool_off.abkühlen><de> Nach dem Rühren für 2 Stunden bei Raumtemperatur wurde das Gemisch auf Raumtemperatur abgekühlt, Wasser wurde zugegeben, das Produkt wurde in Toluol extrahiert, und die organische Schicht wurde nacheinander gewaschen mit Wasser und gesättigter wässriger Lösung an Natriumchlorid, bevor es über wasserfreiem Natriumsulfat getrocknet wurde.
<G-vec00463-002-s030><cool_off.abkühlen><en> Wait for the machine to cool down before you touch the internal parts of the machine.
<G-vec00463-002-s030><cool_off.abkühlen><de> Warten Sie, bis sich das Gerät abgekühlt hat, bevor Sie Teile im Inneren des Gerätes berühren.
<G-vec00463-002-s031><cool_off.abkühlen><en> Let yourself completely dry and let your body cool down before you put clothes on, or you may immediately start sweating.
<G-vec00463-002-s031><cool_off.abkühlen><de> Achte darauf, dass dein Körper vollkommen trocken ist und du dich ein wenig abgekühlt hast, bevor du dich anziehst, da du sonst sofort wieder beginnen würdest zu schwitzen.
<G-vec00463-002-s032><cool_off.abkühlen><en> When the mixture is cool, add the eggs and the breadcrumbs until you can shape it.
<G-vec00463-002-s032><cool_off.abkühlen><de> Sobald die Mischung abgekühlt ist, die Eier und Paniermehl unterrühren bis ein formbarer Teig entsteht.
<G-vec00463-002-s033><cool_off.abkühlen><en> In this refrigerator ash remains can cool off to a temperature that is safe and acceptable for further processing.
<G-vec00463-002-s033><cool_off.abkühlen><de> In dieser Abkühleinheit kann die Asche auf eine für die weitere Verarbeitung akzeptable Temperatur abgekühlt werden.
<G-vec00463-002-s034><cool_off.abkühlen><en> Get proactive with prospects and move then from ‘cool’ to ‘qualified’ through instant engagement, information and advice via real-time messaging.
<G-vec00463-002-s034><cool_off.abkühlen><de> Gehen Sie proaktiv mit Interessenten um und lassen Sie ‘abgekühlt’ zu ‘qualifiziert’ werden durch sofortige Ansprache, Informationsweitergabe und Beratung durch Echtzeit-Nachrichten.
<G-vec00463-002-s035><cool_off.abkühlen><en> For working operations in which materials have a high temperature, it is necessary to let them cool down first.
<G-vec00463-002-s035><cool_off.abkühlen><de> Für Arbeitsvorgänge, bei denen die Materialien eine hohe Temperatur haben, müssen sie zuerst abgekühlt werden.
<G-vec00463-002-s036><cool_off.abkühlen><en> If this happens, wait for the projector's internal components to cool down.
<G-vec00463-002-s036><cool_off.abkühlen><de> Warten Sie in einem derartigen Fall, bis die internen Komponenten abgekühlt sind.
<G-vec00463-002-s037><cool_off.abkühlen><en> Then, the mash is smeared on a plate and allowed to cool off for about 30 minutes.
<G-vec00463-002-s037><cool_off.abkühlen><de> Sodann wird der Jahressuppenbrei auf einen Teller gestrichen und abgekühlt, was etwa 30 Minuten dauert.
