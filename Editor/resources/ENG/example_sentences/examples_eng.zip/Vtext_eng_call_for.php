<G-vec00272-003-s038><call_for.abrufen><en> Get phone call logs history with Location Read more...
<G-vec00272-003-s038><call_for.abrufen><de> Abrufen des Anrufprotokollverlaufs mit Standort Mehr erfahren...
<G-vec00272-003-s039><call_for.abrufen><en> In future the air conditioning will link up to my smartphone via an interface provided by the manufacturer and an app and call up my settings – temperature, ventilator, off.
<G-vec00272-003-s039><call_for.abrufen><de> In Zukunft wird sich die Klimaanlage über ein Interface des Herstellers und eine App mit meinem Smartphone verbinden und meine Einstellungen abrufen – Temperatur, Ventilator, Off-Einstellung.
<G-vec00272-003-s040><call_for.abrufen><en> Topped off by the intelligent design, athletes can call up their optimum performance - both during workout and in competition.
<G-vec00272-003-s040><call_for.abrufen><de> Abgerundet durch das intelligente Design können Sportler Ihre optimale Leistung abrufen – sowohl beim Workout als auch im Wettkampf.
<G-vec00272-003-s041><call_for.abrufen><en> No profound mission stimulating thought - design, like Clayman with his "Zero," no deliberation is announced here, just follow the orders and do your thing, and call on your abilities, to exist in this mission, which is called "go, go, go..." from beginning to end.
<G-vec00272-003-s041><call_for.abrufen><de> Kein tiefgründiges, zum Denken anregendes Mission – Design, wie Clayman mit seinem „Zero“, kein Überlegen ist hier angesagt, nein den Orders folgen und Deinen Dienst tun und Dein Können abrufen, um in dieser Mission zu bestehen, die von Anfang bis Ende „go,go,go...“ heißt.
<G-vec00272-003-s042><call_for.abrufen><en> Drivers can call up camera images and receive alarm alerts during their trip.
<G-vec00272-003-s042><call_for.abrufen><de> Während der Fahrt kann der Fahrer Kamerabilder abrufen und Alarmmeldungen empfangen.
<G-vec00272-003-s043><call_for.abrufen><en> VitaDock® Online from Medisana makes it possible to save, call up, evaluate and export your personal vital data such as blood pressure, blood sugar, blood oxygen, body temperature, weight and activity.
<G-vec00272-003-s043><call_for.abrufen><de> VitaDock® Online von Medisana ermöglicht das Speichern, Abrufen, Auswerten und Exportieren Ihrer persönlichen Vitaldaten wie Blutdruck, Blutzucker, Blutsauerstoff, Körpertemperatur, Gewicht und Aktivität.
<G-vec00272-003-s044><call_for.abrufen><en> Therefore, you should have a high –tech tool that empowers you to get the Voip call history logs.
<G-vec00272-003-s044><call_for.abrufen><de> Daher sollten Sie über ein Hightech-Tool verfügen, mit dem Sie die Voip-Anrufprotokolle abrufen können.
<G-vec00272-003-s045><call_for.abrufen><en> In NoRA, you can call up the abstract of any of the standards, and for the majority of standards also the table of contents.
<G-vec00272-003-s045><call_for.abrufen><de> Sie können über NoRA zu jeder Norm das Kurzreferat und in den meisten Fällen auch das Inhaltsverzeichnis abrufen.
<G-vec00272-003-s046><call_for.abrufen><en> With the monitoring tools, users can call up and view the system’s performance online at any time.
<G-vec00272-003-s046><call_for.abrufen><de> Mit Monitoring-Tools kann der Nutzer die Leistung der Anlage jederzeit online abrufen.
<G-vec00272-003-s047><call_for.abrufen><en> Intelligent service starts in your BMW X6 from where you can call up your service status at any time.
<G-vec00272-003-s047><call_for.abrufen><de> Im BMW M3 Coupé können Sie jederzeit den Service-Status abrufen.
<G-vec00272-003-s048><call_for.abrufen><en> In addition, you can easily go with a few clicks the Our company call in order to find us easily.
<G-vec00272-003-s048><call_for.abrufen><de> Darüber hinaus können Sie bequem unterwegs mit ein paar Klicks den Standort unserer Firma abrufen damit Sie uns leicht finden.
<G-vec00272-003-s049><call_for.abrufen><en> If you call up this website from inside the Provincial Government Buildings, there is no limit on the 'Addressee' field, but your own Province e-mail address has to be in the 'Sender' field.
<G-vec00272-003-s049><call_for.abrufen><de> Wenn Sie diese Website innerhalb des Gouvernements abrufen, gilt keine Einschränkung für das Feld 'Adressat', doch im Feld 'Absender' sollte Ihre Provinz-E-Mail-Adresse stehen.
<G-vec00272-003-s050><call_for.abrufen><en> Our partners can call up special additional services directly at the POS with a personal password.
<G-vec00272-003-s050><call_for.abrufen><de> Mit einem persönlichen Passwort können unsere Partner am Point of Sale die besonderen Zusatzleistungen abrufen.
<G-vec00272-003-s051><call_for.abrufen><en> Should you call up pages and files within our site and thus be asked to enter data about yourself, we hereby give notice that such data transmission via the internet is not secure, and that these data can thus be seen by unauthorised persons, or can be forged.
<G-vec00272-003-s051><call_for.abrufen><de> Wenn Sie innerhalb unseres Angebotes Seiten und Dateien abrufen und dabei aufgefordert werden, Daten über sich einzugeben, so weisen wir darauf hin, dass diese Datenübertragung über das Internet ungesichert erfolgt, die Daten somit von Unbefugten zur Kenntnis genommen oder auch verfälscht werden können.
<G-vec00272-003-s052><call_for.abrufen><en> In the future, marketing will increasingly become a service, as users are able to call up additional information via tags and communicate directly with the retailer.
<G-vec00272-003-s052><call_for.abrufen><de> Künftig wird Marketing immer mehr zum Service, indem User über Tags Zusatzinformationen abrufen und mit dem Händler direkt kommunizieren können.
<G-vec00272-003-s053><call_for.abrufen><en> I do not leave you without a fight to my opponent but I can only oppose him with love and therefore also call you away out of love when the only thing that you can still expect on earth is death, spiritual death, which is so terrible that I take pity and want to protect you from it.
<G-vec00272-003-s053><call_for.abrufen><de> Ich überlasse euch nicht kampflos Meinem Gegner, doch nur mit Liebe kann Ich ihm gegenübertreten und also auch aus Liebe euch abrufen, wenn ihr auf Erden nur noch den Tod zu erwarten habt, den geistigen Tod, der so entsetzlich ist, daß es Mich erbarmet und Ich euch davor bewahren will.
<G-vec00272-003-s054><call_for.abrufen><en> This saves time, for example, when the operator can call data required from CAD/CAM applications directly from the TNC control.
<G-vec00272-003-s054><call_for.abrufen><de> Das spart Zeit, wenn Sie direkt von der TNC-Steuerung fehlende Daten aus CAD/CAM-Anwendungen abrufen können.
<G-vec00272-003-s055><call_for.abrufen><en> The user can for example call up video sequences that show the changing of the film roll and the film knife.
<G-vec00272-003-s055><call_for.abrufen><de> Der Bediener kann zum Beispiel Videosequenzen abrufen, die den Folienrollen- und Folienmesserwechsel zeigen.
<G-vec00272-003-s056><call_for.abrufen><en> In addition, the website operator can also recognize which subpages you call up on the page, as each page call ends up in a so-called log file.
<G-vec00272-003-s056><call_for.abrufen><de> Zudem kann der Webseitenbetreiber erkennen, welche Unterseiten Sie auf der Seite abrufen, da jeder Seitenabruf in einer sogenannten Log-Datei landet.
<G-vec00272-003-s570><call_for.anrufen><en> Guests arriving by public transport call the hotel from the PostBus terminal or the tourist office.
<G-vec00272-003-s570><call_for.anrufen><de> Gäste, die mit öffentlichen Verkehrsmitteln anreisen, rufen das Hotel vom PostAuto-Terminal oder vom Tourismusbüro aus an.
<G-vec00272-003-s571><call_for.anrufen><en> Alternatively, call +44870 400 9121 (not toll-free) or your country-specific number.
<G-vec00272-003-s571><call_for.anrufen><de> Rufen Sie andernfalls +44870 400 9121 (gebührenpflichtig) oder Ihre länderspezifische Nummer an.
<G-vec00272-003-s572><call_for.anrufen><en> For EVE Audio demos in USA please contact our distributor EVE Audio US or call +1 845 378 1189.
<G-vec00272-003-s572><call_for.anrufen><de> Für eine Demo von EVE-Monitoren in den USA kontaktieren Sie bitte unseren Vertrieb EVE Audio US oder rufen an +1 845 378 1189.
<G-vec00272-003-s573><call_for.anrufen><en> Every day, people call psychotherapists offices for help in a crisis.
<G-vec00272-003-s573><call_for.anrufen><de> Jeden Tag rufen in den Psychotherapeutischen Praxen Menschen an, die Hilfe in einer Krise suchen.
<G-vec00272-003-s574><call_for.anrufen><en> Melding: questions, comments or concerns, please call us.
<G-vec00272-003-s574><call_for.anrufen><de> Wenn Sie Fragen, Anmerkungen oder Bedenken haben, rufen Sie uns bitte an.
<G-vec00272-003-s576><call_for.anrufen><en> AGROSPOL, Malý you have any questions, comments or concerns, please call us.
<G-vec00272-003-s576><call_for.anrufen><de> Schließen Wenn Sie Fragen, Anmerkungen oder Bedenken haben, rufen Sie uns bitte an.
<G-vec00272-003-s577><call_for.anrufen><en> View them on the page or call one of our employees for further information. Suzanna Dee
<G-vec00272-003-s577><call_for.anrufen><de> Sehen Sie sich diese auf der Seite an oder rufen Sie einen unserer Mitarbeiter für weitere Informationen an.
<G-vec00272-003-s578><call_for.anrufen><en> If you are a dog groomer and would like more information about KW and are interested in testing our competitively priced quality products, please do not hesitate to call or write to us.
<G-vec00272-003-s578><call_for.anrufen><de> Sind Sie Hundefriseur und daran interessiert, mehr über KW zu erfahren, und unsere hohe Qualität bei den Produkten zu wettbewerbsfähigen Preisen auszuprobieren – dann schreiben Sie uns oder rufen Sie uns an.
<G-vec00272-003-s579><call_for.anrufen><en> Also, if you need to find the address of the person or on the phone to find someone by the name, then just immediately call the detective agency " Private detective Kharkiv", which carries out its activities in the city Pervomajskij .
<G-vec00272-003-s579><call_for.anrufen><de> Auch, wenn Sie benötigen die Adresse der Person am Telefon zu wissen oder den Nachnamen, jemanden zu finden, rufen Sie einfach direkt an die Detektei "Kharkov Private Detective", die Pervomajskij im Gebiet der Stadt tätig ist.
<G-vec00272-003-s581><call_for.anrufen><en> Procédure au retour Please call the staff of Park & Fly as soon as you have collected your luggage.
<G-vec00272-003-s581><call_for.anrufen><de> Nach Ihrer Gepäckannahme, rufen Sie bitte die PMS Park & Fly Service Hotline an, um Ihre Ankunft zu bestätigen.
<G-vec00272-003-s582><call_for.anrufen><en> If you need help, call 972-385-0100. Ribbon Text Our Company
<G-vec00272-003-s582><call_for.anrufen><de> Wenn Sie Hilfe benötigen, rufen uns bitte an unter +31 (0)20 305 8620.
<G-vec00272-003-s583><call_for.anrufen><en> Simply give our Managed Security team a call now and they will have your data safe in no time.
<G-vec00272-003-s583><call_for.anrufen><de> Rufen Sie unser Managed Security-Team einfach an, damit es Ihre Daten im Handumdrehen schützt.
<G-vec00272-003-s584><call_for.anrufen><en> Please give us a call or send an email.
<G-vec00272-003-s584><call_for.anrufen><de> Bitte rufen Sie uns an oder schreiben Sie uns eine E-Mail.
<G-vec00272-003-s585><call_for.anrufen><en> To book, we kindly ask you to call on +41 (0)91 996 21 55 between 8am and 10pm from Monday to Sunday.
<G-vec00272-003-s585><call_for.anrufen><de> Um eine Reservierung vorzunehmen, rufen Sie bitte zwischen 08:00 und 22:00 Uhr, Montag bis Sonntag, unter +41 (91) 996 21 55 an.
<G-vec00272-003-s586><call_for.anrufen><en> Quick question? Call KBC Live
<G-vec00272-003-s586><call_for.anrufen><de> Rufen Sie KBC Live an, Tel.
<G-vec00272-003-s587><call_for.anrufen><en> In other call centres the 'human' work plays a crucial role: people call because they want to talk (besides ordering stuff).
<G-vec00272-003-s587><call_for.anrufen><de> Bei anderen Call Centern spielt die "menschliche" Arbeit eine zentrale Rolle: Die Leute rufen an, weil sie reden wollen (und nebenbei die Bestellung aufgeben).
<G-vec00272-003-s588><call_for.anrufen><en> They call us frequently, knowing they can rely on a fast, knowledgeable response to their requests for information.
<G-vec00272-003-s588><call_for.anrufen><de> Sie rufen uns häufig an und wissen, dass sie sich auf eine schnelle und kompetente Antwort auf ihre Fragen verlassen können.
<G-vec00272-003-s266><call_for.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00272-003-s266><call_for.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00272-003-s267><call_for.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00272-003-s267><call_for.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00272-003-s268><call_for.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00272-003-s268><call_for.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00272-003-s269><call_for.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00272-003-s269><call_for.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00272-003-s270><call_for.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00272-003-s270><call_for.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00272-003-s271><call_for.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00272-003-s271><call_for.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00272-003-s272><call_for.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00272-003-s272><call_for.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00272-003-s273><call_for.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00272-003-s273><call_for.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00272-003-s274><call_for.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00272-003-s274><call_for.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00272-003-s275><call_for.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00272-003-s275><call_for.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00272-003-s276><call_for.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00272-003-s276><call_for.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00272-003-s277><call_for.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00272-003-s277><call_for.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00272-003-s278><call_for.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00272-003-s278><call_for.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00272-003-s279><call_for.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00272-003-s279><call_for.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00272-003-s280><call_for.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00272-003-s280><call_for.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00272-003-s281><call_for.aufrufen><en> Tried to call a removed routine.
<G-vec00272-003-s281><call_for.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00272-003-s282><call_for.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00272-003-s282><call_for.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00272-003-s283><call_for.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00272-003-s283><call_for.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00272-003-s284><call_for.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00272-003-s284><call_for.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00272-003-s323><call_for.bezeichnen><en> Bahlsen: You could call him that.
<G-vec00272-003-s323><call_for.bezeichnen><de> Bahlsen: So könnte man ihn bezeichnen.
<G-vec00272-003-s324><call_for.bezeichnen><en> It is therefore incomprehensible that the guests call me the house as not clean.
<G-vec00272-003-s324><call_for.bezeichnen><de> Es ist mir daher unverständlich das die Gäste das Haus als nicht sauber bezeichnen.
<G-vec00272-003-s325><call_for.bezeichnen><en> Because there are already four of those restaurants, so I guess you can call it a chain.
<G-vec00272-003-s325><call_for.bezeichnen><de> Weil es mittlerweile bereits vier Ishins gibt, von daher kann man es wohl getrost als Ladenkette bezeichnen.
<G-vec00272-003-s326><call_for.bezeichnen><en> External creation as well as quotation from the Bible urged to call this bell "Christ's bell".
<G-vec00272-003-s326><call_for.bezeichnen><de> Sowohl äußere Gestaltung als auch Bibelwort legten nahe, diese Glocke als "Christusglocke" zu bezeichnen.
<G-vec00272-003-s327><call_for.bezeichnen><en> This positive confirmation of aesthetic interventions was the motivation to examine current trends more closely and to carry out an analysis based on historical developments, which, in our opinion, must necessarily lead to a changed philosophy of aesthetic medicine, which we would like to call Compositional Aesthetics.
<G-vec00272-003-s327><call_for.bezeichnen><de> Diese positive Bestätigung ästhetischer Interventionen war Motivation, die aktuellen Trends genauer zu untersuchen und eine Analyse auf Basis der historischen Entwicklung durchzuführen, die notwendigerweise unserer Auffassung nach zu einer veränderten Philosophie der ästhetischen Medizin führen muss, die wir mit dem Begriff Kompositorische Ästhetik bezeichnen wollen.
<G-vec00272-003-s328><call_for.bezeichnen><en> Thus the Jews call God the Father, and in Christianity God has even put forth a human Son.
<G-vec00272-003-s328><call_for.bezeichnen><de> Entsprechend bezeichnen die Juden Gott als Vater, im Christentum hat Gott sogar einen menschlichen Sohn gezeugt.
<G-vec00272-003-s329><call_for.bezeichnen><en> Many scientist have described what we call the information field as a "field of mental and physical interchange".
<G-vec00272-003-s329><call_for.bezeichnen><de> Viele Wissenschaftler beschrieben bereits den Bereich, den wir als Informationsfeld bezeichnen, als ein Feld der mentalen und physischen Wechselwirkungen.
<G-vec00272-003-s330><call_for.bezeichnen><en> As boxer engine you can not call it well, because opposite cylinders run on a connecting rod pin and thus always run the same movement.
<G-vec00272-003-s330><call_for.bezeichnen><de> Als Boxermotor kann man ihn wohl nicht bezeichnen, weil gegenüberliegende Zylinder auf einem Pleuelzapfen laufen und damit immer die gleiche Bewegung ausführen.
<G-vec00272-003-s331><call_for.bezeichnen><en> Share On pinterest Pin Wrestling might be fake, but at least it has the chops to call it a squared circle.
<G-vec00272-003-s331><call_for.bezeichnen><de> Beim Wrestling mag zwar vieles Fake sein, aber immerhin haben die genügend Eier, ihren Ring als quadratischen Kreis zu bezeichnen.
<G-vec00272-003-s332><call_for.bezeichnen><en> I would call our group “blue helmets” as an analogy to UN peacekeepers.
<G-vec00272-003-s332><call_for.bezeichnen><de> Ich würde unsere ganze Gruppe als „Blauhelme“ bezeichnen, in Analogie zu den Friedensstiftern der UNO.
<G-vec00272-003-s333><call_for.bezeichnen><en> I am now able to call myself bilingual, as I use both English and German in my daily life.
<G-vec00272-003-s333><call_for.bezeichnen><de> Nun kann ich mich selbst als bilingual bezeichnen, denn in meinem Alltag gebrauche ich sowohl Englisch als auch Deutsch.
<G-vec00272-003-s334><call_for.bezeichnen><en> We always call them LR44 on Lovehoney.com
<G-vec00272-003-s334><call_for.bezeichnen><de> Wir bezeichnen sie stets als LR44-Batterien.
<G-vec00272-003-s335><call_for.bezeichnen><en> You can call Him a hippie, all right!
<G-vec00272-003-s335><call_for.bezeichnen><de> Man könnte Ihn als Hippie bezeichnen.
<G-vec00272-003-s336><call_for.bezeichnen><en> It also extends to those who call themselves "healers" in this room, for they have the same task as the channeller or the teacher, and that is translating a perceptual, metaphörical message into something that is 3D and practical.
<G-vec00272-003-s336><call_for.bezeichnen><de> Es schließt auch diejenigen im Raum ein, die sich als Heiler bezeichnen, denn sie haben die gleiche Aufgabe wie die Channeler oder Lehrer, nämlich, eine wahrgenommene metaphorische Botschaft in etwas zu übersetzen, was 3D und praktisch ist.
<G-vec00272-003-s337><call_for.bezeichnen><en> With our nearly 30 years of experience and extensive series of delivered projects, we can rightly call ourselves solid surface experts.
<G-vec00272-003-s337><call_for.bezeichnen><de> Mit unseren fast 30 Jahren Erfahrung und bereits realisierte, erfolgreiche Projekte können wir uns mit Recht als Solid Surface-Experten bezeichnen.
<G-vec00272-003-s338><call_for.bezeichnen><en> If the score of any method is above a certain limit, then we call that moment “abnormal” according to that method.
<G-vec00272-003-s338><call_for.bezeichnen><de> Wenn der Wert einer dieser Methoden einen bestimmten Grenzwert überschreitet, bezeichnen wir diesen Moment als „abnormal“ entsprechend der jeweiligen Methode.
<G-vec00272-003-s339><call_for.bezeichnen><en> The shape of the main island of Taiwan is similar to a sweet potato seen in a south-to-north direction, and therefore, Taiwanese (especially Min Nan speakers) often call themselves "children of the Sweet Potato.
<G-vec00272-003-s339><call_for.bezeichnen><de> Charakteristisch für Taiwan ist die auf der Landkarte eine Süßkartoffel ähnelnde Form, aufgrund deren sich die Min Nan Ureinwohner auch als „Kinder der Süßkartoffel“ bezeichnen.
<G-vec00272-003-s340><call_for.bezeichnen><en> What we call "evil spirits" are Satan and all the evil spirit men on his side.
<G-vec00272-003-s340><call_for.bezeichnen><de> Mit dem Ausdruck "böse Geister" bezeichnen wir Satan und all seine bösen Geister.
<G-vec00272-003-s341><call_for.bezeichnen><en> As a top place I would not call this place.
<G-vec00272-003-s341><call_for.bezeichnen><de> Als Top-Platz würde ich diesen Platz nicht bezeichnen.
<G-vec00272-003-s380><call_for.erfordern><en> The challenges of international competition and the EC internal market call for an increased effort to structure the world of work more humanely.
<G-vec00272-003-s380><call_for.erfordern><de> Die Herausforderungen des internationalen Wettbewerbs und des EG-Binnenmarktes erfordern vermehrte Anstrengungen für eine menschengerechtere Strukturierung der Arbeitswelt.
<G-vec00272-003-s381><call_for.erfordern><en> Modern printers and smart devices call for a multi-layered approach to security that spans intrusion prevention, device detection, document and data detection and external partnerships with security specialists.
<G-vec00272-003-s381><call_for.erfordern><de> Moderne Drucker und intelligente Geräte erfordern einen mehrschichtigen Sicherheitsansatz, der die Bereiche Angriffsverhinderung, Geräteerkennung sowie Dokumenten- und Datenschutz abdeckt und Partnerschaften mit externen Anbietern für Datensicherheit beinhaltet.
<G-vec00272-003-s382><call_for.erfordern><en> Variable inlet guide vanes (IGV) ensure optimal flow rates, especially when changing on-site conditions call for immediate adjustments.
<G-vec00272-003-s382><call_for.erfordern><de> Verstellbare Eintrittsleitschaufeln (IGVs, Inlet Guide Vanes) gewährleisten optimale Flussraten, insbesondere, wenn sich wandelnde Bedingungen vor Ort eine sofortige Anpassung erfordern.
<G-vec00272-003-s383><call_for.erfordern><en> Special working environments call for special solutions.
<G-vec00272-003-s383><call_for.erfordern><de> Besondere Arbeitsumgebungen erfordern besondere Lösungen.
<G-vec00272-003-s384><call_for.erfordern><en> Trial and error, early corrections, and brand-new approaches call for a creative way of working toward solutions.
<G-vec00272-003-s384><call_for.erfordern><de> Versuch und Irrtum, frühe Korrekturen und völlig neue Ansätze erfordern eine kreative Annäherung an die Lösungen.
<G-vec00272-003-s385><call_for.erfordern><en> Rough, sloping terrain and cramped working conditions call for robust and reliable forestry machines.
<G-vec00272-003-s385><call_for.erfordern><de> Raues, abschüssiges Gelände und beengte Arbeitsbedingungen erfordern robuste und zuverlässige Forstmaschinen.
<G-vec00272-003-s386><call_for.erfordern><en> Such deep dives are, however, quite strenuous and usually call for some resting time at the surface which was observed in some of the pilot whales this morning.
<G-vec00272-003-s386><call_for.erfordern><de> Solche tiefen Tauchgänge sind jedoch ziemlich anstrengend und erfordern normalerweise eine gewisse Ruhezeit an der Wasseroberfläche, die bei einigen Pilotwale während der heutigen Nachmittagstour beobachtet werden konnte.
<G-vec00272-003-s387><call_for.erfordern><en> From ultrasonic welding, gluing or riveting, whether force, current or position measurement: custom drives call for customized solutions.
<G-vec00272-003-s387><call_for.erfordern><de> Ob Ultraschall-Schweißen, Kleben oder Vernieten, ob Kraft-, Strom- oder Positionsmessung: Individuelle Antriebe erfordern individuelle Lösungen.
<G-vec00272-003-s388><call_for.erfordern><en> Each situation and each woman may call for something different.
<G-vec00272-003-s388><call_for.erfordern><de> Jede Situation und jede Frau kann etwas anderes erfordern.
<G-vec00272-003-s389><call_for.erfordern><en> Specifically, they call for a lifestyle marked by sobriety and solidarity, with new rules and forms of engagement, one which focuses confidently and courageously on strategies that actually work, while decisively rejecting those that have failed.
<G-vec00272-003-s389><call_for.erfordern><de> Sie erfordern insbesondere eine durch Maßhalten und Solidarität gekennzeichnete Lebensweise mit neuen Regeln und Formen des Einsatzes, die zuversichtlich und mutig die positiven Erfahrungen aufgreifen und die negativen entschieden zurückweisen.
<G-vec00272-003-s390><call_for.erfordern><en> Highly complex food products like fruit juices may – depending on the performance requirements – call for the use of the entire spectrum of analytical methods.
<G-vec00272-003-s390><call_for.erfordern><de> Fruchtsäfte als hochkomplexe Lebensmittel erfordern je nach Aufgabenstellung das gesamte Spektrum der analytischen Methoden.
<G-vec00272-003-s391><call_for.erfordern><en> On the mountain, extreme conditions call for the right balance between weight and functionality.
<G-vec00272-003-s391><call_for.erfordern><de> Die extremen Bedingungen am Berg erfordern eine ausgewogene Balance zwischen Gewicht und Funktionalität.
<G-vec00272-003-s392><call_for.erfordern><en> Ever-increasing demands regarding the cleanliness of component surfaces call for increasingly effective cleaning methods.
<G-vec00272-003-s392><call_for.erfordern><de> Immer höhere Anforderungen an die Sauberkeit von Bauteiloberflächen erfordern immer effektivere Reinigungsverfahren.
<G-vec00272-003-s393><call_for.erfordern><en> Industrial revolutions always call for investments to implement structural change – and Industry 4.0 is no exception.
<G-vec00272-003-s393><call_for.erfordern><de> Industrielle Revolutionen erfordern Investitionen, ohne die nun mal kein Strukturwandel möglich ist – da macht auch die Industrie 4.0 keine Ausnahme.
<G-vec00272-003-s394><call_for.erfordern><en> Constantly rising competition and cost pressure as well as decreasing margins call for flexibility and constant adaptability.
<G-vec00272-003-s394><call_for.erfordern><de> Ständig steigender Wettbewerbs- und Kostendruck und sinkende Margen erfordern Flexibilität und stetige Anpassungen.
<G-vec00272-003-s395><call_for.erfordern><en> Pressing conflicts, risks and crisis may call for rapid, decisive actions.
<G-vec00272-003-s395><call_for.erfordern><de> Konflikte, dringende Risiken und Krisen erfordern entschlossenes und rasches Handeln.
<G-vec00272-003-s396><call_for.erfordern><en> Granting rights of use not only needs to be taken into consideration for traditional licensing agreements, but also in a variety of other types of agreement: creating websites, drafting ASP agreements or transferring databases all call for copyright provisions which may be critical to the quality of the overall contractual framework.
<G-vec00272-003-s396><call_for.erfordern><de> Die Einräumung von Nutzungsrechten ist nicht nur bei klassischen Lizenzverträgen zu berücksichtigen, sondern auch bei einer Reihe anderer Vereinbarungen: Die Erstellung von Webseiten, ASP-Verträge oder die Übernahme von Datenbanken erfordern urheberrechtliche Regelungen, die über die Qualität des gesamten Vertragswerkes entscheiden können.
<G-vec00272-003-s397><call_for.erfordern><en> The great challenges of our time call upon us all to stand together and to commit to continual improvement.
<G-vec00272-003-s397><call_for.erfordern><de> Klimawandel, knappe Ressourcen und globale Märkte – die großen Herausforderungen unserer Zeit erfordern Zusammenhalt und den Willen zur stetigen Verbesserung.
<G-vec00272-003-s398><call_for.erfordern><en> Individual needs call for individual solutions.
<G-vec00272-003-s398><call_for.erfordern><de> Individuelle Bedürfnisse erfordern individuelle Lösungen.
<G-vec00272-003-s399><call_for.fordern><en> To call for the use of arms under the guise of democracy is in itself impermissible, but to speak of Germany as a democracy state, which in this way could somehow repair its damaged image, that is defamatory, and the question must be asked of why Germany could be so bent on playing at war again, instead of eschewing it for all time.
<G-vec00272-003-s399><call_for.fordern><de> Waffeneinsätze unter dem Deckmantel der Demokratie zu fordern ist schon unzulässig, aber Deutschland als demokratischen Staat anzupreisen, der dadurch eine Art Imageschaden wieder gut machen könnte, das ist ehrenrührig und es muss die Frage gestellt werden, warum Deutschland so versessen darauf sein könnte, wieder Krieg zu spielen, anstatt dies für alle Zeiten bleiben zu lassen.
<G-vec00272-003-s400><call_for.fordern><en> In an article in Spiegel Online, Andre Wilkens and Jakob von Weizsäcker call for a publicly financed media channel that is produced in and for Europe.1 It is their hope that the project will make an important contribution to European democracy.
<G-vec00272-003-s400><call_for.fordern><de> In ihrem Gastbeitrag für „Spiegel Online“ fordern die Autoren Andre Wilkens und Jakob von Weizsäcker einen öffentlich-rechtlichen Medienkanal aus und für Europa.1 Von diesem erhoffen sie sich einen wichtigen Beitrag zur Rettung der europäischen Demokratie.
<G-vec00272-003-s401><call_for.fordern><en> Meanwhile, we call on the Council of the EU to take a final decision on further sanctions against the Russian Federation only after thoroughly evaluating the progress towards the political solution.
<G-vec00272-003-s401><call_for.fordern><de> In der Zwischenzeit fordern wir den Rat der Europäischen Union auf, einen endgültigen Beschluss über weitere Sanktionen gegen Russland erst nach einer gründlichen Bewertung des Fortschritts auf dem Weg zur politischen Lösung zu fassen.
<G-vec00272-003-s402><call_for.fordern><en> About 60 protesters marched to the local police headquarters to support the arrested reclaimers and call for their release.
<G-vec00272-003-s402><call_for.fordern><de> Etwa 60 DemonstrantInnen marschierten zur Polizeistation, um die Verhafteten zu unterstützen und ihre Freilassung zu fordern.
<G-vec00272-003-s403><call_for.fordern><en> Younger Central Committee members call on the "old comrades" to leave the CC voluntarily in the face of the demands of the rank and file.
<G-vec00272-003-s403><call_for.fordern><de> Jüngere ZK-Mitglieder fordern die „alten Genossen" auf, freiwillig aus dem ZK zurückzutreten, weil dies die Parteibasis verlange.
<G-vec00272-003-s404><call_for.fordern><en> Their feeling that they are under threat is fuelled above all by the fact that hard-liners in Tehran time and again openly call for the destruction of Israel while Hezbollah’s rockets are, at the same time, stationed on Israel’s northern border.
<G-vec00272-003-s404><call_for.fordern><de> Das Gefühl der Bedrohung wird vor allem dadurch genährt, dass immer wieder Hardliner in Teheran offen die Vernichtung Israels fordern, während gleichzeitig an Israels Nordgrenze die Raketen der Hisbollah stehen.
<G-vec00272-003-s405><call_for.fordern><en> In accordance with the FBE previous and constant position we call upon an end to arbitrary arrest, detention, and prosecution of judges, lawyers and journalists.
<G-vec00272-003-s405><call_for.fordern><de> Entsprechend dem bisherigen und festen Standpunkt des FBE fordern wir ein Ende der willkürlichen Festnahme, Inhaftierung und Verfolgung von Richtern, Anwälten und Journalisten.
<G-vec00272-003-s406><call_for.fordern><en> We call for EU citizens to have the choice to continue to buy healthy bulbs in the future.
<G-vec00272-003-s406><call_for.fordern><de> Wir fordern für alle europäischen Bürger die Freiheit, auch in Zukunft gesunde Leuchtmittel kaufen zu können.
<G-vec00272-003-s407><call_for.fordern><en> We also call on all armed groups to put an immediate end to violence.
<G-vec00272-003-s407><call_for.fordern><de> Wir fordern außerdem alle bewaffneten Gruppierungen auf, die Gewalt unverzüglich zu beenden.
<G-vec00272-003-s408><call_for.fordern><en> Organic Farming News European experts call to convert organic agriculture in the model for European agriculture.
<G-vec00272-003-s408><call_for.fordern><de> Landwirtschaft News Europäische Experten fordern die Umstellung auf den ökologischen Landbau in dem Modell für die europäische Landwirtschaft.
<G-vec00272-003-s409><call_for.fordern><en> We call for an independent review of all existing surveillance powers as to their effectiveness, proportionality, costs, harmful side-effects and alternative solutions.
<G-vec00272-003-s409><call_for.fordern><de> Wir fordern eine unabhängige Überprüfung aller bestehenden Überwachungsbefugnisse in Hinblick auf ihre Wirksamkeit, Verhältnismäßigkeit, Kosten, schädliche Nebenwirkungen und Alternativen.
<G-vec00272-003-s410><call_for.fordern><en> We call on Europe to push for the conversion of the INF Treaty into a multilateral Treaty in order to include other nuclear states, like China.
<G-vec00272-003-s410><call_for.fordern><de> Wir fordern die EU auf, die Umwandlung des INF-Vertrags in einen multilateralen Vertrag voranzutreiben, um andere Nuklearstaaten wie China einzubeziehen.
<G-vec00272-003-s411><call_for.fordern><en> The stream that meanders through the grounds, the trickily undulating greens well protected by bunkers, and the ancient tree population including some majestic solitary giants, call for accurate play on this special 9-hole course.
<G-vec00272-003-s411><call_for.fordern><de> Der sich durch das Gelände ziehende Bach, die durch Bunker gut verteidigten und anspruchsvoll ondulierten Grüns sowie der alte Baumbestand mit großen Solitären fordern ein akkurates Spiel auf diesem besonderen 9-Loch-Platz.
<G-vec00272-003-s412><call_for.fordern><en> She told the audience that the reason she came to South Africa was to call for a stop to the persecution of Falun Dafa.
<G-vec00272-003-s412><call_for.fordern><de> Sie erzählte den Zuschauern warum sie nach Südafrika gekommen war, nämlich um ein Ende der Verfolgung von Falun Gong zu fordern.
<G-vec00272-003-s413><call_for.fordern><en> When “masters” control servants, or when capitalists control workers, this is considered to be in the nature of things; the private life of the working and exploited people is not considered inviolable. The bourgeoisie are entitled to call to account any "wage slave" and at any time to make public his income and expenditure.
<G-vec00272-003-s413><call_for.fordern><de> Wenn die „Herrschaften“ die Dienstboten kontrollieren, wenn die Kapitalisten die Arbeiter kontrollieren, dann hält man das für ganz in Ordnung, das Privatleben des Werktätigen und Ausgebeuteten gilt nicht für unantastbar, die Bourgeoisie ist berechtigt, von jedem „Lohnsklaven“ Rechenschaft zu fordern, seine Einnahmen und Ausgaben jederzeit an die Öffentlichkeit zu zerren.
<G-vec00272-003-s414><call_for.fordern><en> We need a more creative and coordinated response from the EU and its Member States, and we call for a European strategy on demographic change and for more familyand child-friendly environments.
<G-vec00272-003-s414><call_for.fordern><de> Wir benötigen eine kreativere und koordiniertere Antwort der EU und ihrer Mitgliedstaaten, und wir fordern eine europäische Strategie zum demografischen Wandel sowie zu familien- und kinderfreundlichen Umgebungen.
<G-vec00272-003-s415><call_for.fordern><en> The artists call for the resignation of the Senator of Culture, because a competent Senator for Cultural Affairs would do something intelligent for the city of Berlin with the keys of the house in his/her hands.
<G-vec00272-003-s415><call_for.fordern><de> Die Künstler fordern den Rücktritt des Kultursenators, da ein kompetenter Senator für kulturelle Angelegenheiten mit dem ihm übergebenen Tacheles Schlüssel etwas Intelligentes für die Stadt Berlin bewirken könnte.
<G-vec00272-003-s416><call_for.fordern><en> We call on the Russian Federation to immediately cease its attacks on the Syrian opposition and civilians and to focus its efforts on fighting ISIL.
<G-vec00272-003-s416><call_for.fordern><de> Wir fordern die Russische Föderation auf, ihre Angriffe auf die syrische Opposition und die Zivilbevölkerung unverzüglich zu stoppen und sich auf die Bekämpfung von ISIS zu konzentrieren.
<G-vec00272-003-s417><call_for.fordern><en> However, the finite nature of fossil fuels, climate change and smog call for alternative solutions from the automotive industry, such as the electric drive.
<G-vec00272-003-s417><call_for.fordern><de> Die Endlichkeit fossiler Kraftstoffe, der Klimawand und Smog fordern von der Automobilindustrie jedoch alternative Lösungen wie den Elektroantrieb.
<G-vec00272-003-s494><call_for.nennen><en> 13 “You call me ‘Teacher’ and ‘Lord,’ and rightly so, for that is what I am.
<G-vec00272-003-s494><call_for.nennen><de> Ihr nennt mich Meister und Herr und sagt es mit Recht, denn ich bin’s auch.
<G-vec00272-003-s495><call_for.nennen><en> Cheap flights from Seville to Rio De Janeiro from 502 € on Iberia From the moment you enter Rio de Janeiro, you will understand why they call it the ‘Marvellous City’.
<G-vec00272-003-s495><call_for.nennen><de> Billige Tickets für Iberia Flüge von Berlin nach Rio de Janeiro ab 638 € bei Iberia Vom Zeitpunkt an, in dem Sie Rio de Janeiro betreten, werden Sie verstehen, warum man sie „die wundervolle Stadt“ nennt.
<G-vec00272-003-s496><call_for.nennen><en> Once he says his sounding name at the end of the phone call, they put his Hungarian language to a test.
<G-vec00272-003-s496><call_for.nennen><de> Als er gegen Ende des Telefonats seinen klingenden Namen nennt, stellt man gleich sein Ungarisch auf eine Belastungsprobe.
<G-vec00272-003-s497><call_for.nennen><en> Let us take it from another aspect of what you call insects and bees.
<G-vec00272-003-s497><call_for.nennen><de> Lasst uns das unter einem anderen Aspekt sehen, von den Kreaturen, die ihr Insekten und Bienen nennt.
<G-vec00272-003-s498><call_for.nennen><en> You do not put your feet on the table, you do not burp while eating, and you do not call the twelve worst years in German history "bird shit."
<G-vec00272-003-s498><call_for.nennen><de> Man legt die Füße nicht auf den Tisch, man rülpst nicht beim Essen, und man nennt die 12 schlimmsten Jahre der deutschen Geschichte nicht einen „Vogelschiss“.
<G-vec00272-003-s499><call_for.nennen><en> The two of them then make up after he assures her that he will not leave her (although she continues to call him a liar).
<G-vec00272-003-s499><call_for.nennen><de> Die beiden von ihnen machen dann auf, nachdem er ihr versichert hat, dass er sie nicht verlassen wird (obwohl sie ihn weiterhin einen Lügner nennt).
<G-vec00272-003-s500><call_for.nennen><en> That would be exactly what we call diplomacy: the art of (secret) negotiation....
<G-vec00272-003-s500><call_for.nennen><de> Das wäre genau das, was man Diplomatie nennt: die Kunst des (geheimen) Verhandelns....
<G-vec00272-003-s501><call_for.nennen><en> Perhaps you already have a remedy that has helped you to heal the wounds quickly, and you know exactly what to call the pharmacist in the pharmacy.
<G-vec00272-003-s501><call_for.nennen><de> Vielleicht haben Sie bereits ein Mittel, das Ihnen geholfen hat, die Wunden schnell zu heilen, und Sie wissen genau, wie man den Apotheker in der Apotheke nennt.
<G-vec00272-003-s502><call_for.nennen><en> It is possible to go back into what you call your history and change or alter it.
<G-vec00272-003-s502><call_for.nennen><de> Es ist möglich, in das, was ihr eure Geschichte nennt, zurückzugehen und sie zu ändern oder umzugestalten.
<G-vec00272-003-s503><call_for.nennen><en> We wish you much Joy and Love as you "unfold" into the New Cycle which you call a New Year.
<G-vec00272-003-s503><call_for.nennen><de> Wir wünschen euch viel Freude und Liebe, wenn ihr euch in den Neuen Zyklus hinein „entfaltet“, den ihr das Neue Jahr nennt.
<G-vec00272-003-s504><call_for.nennen><en> When we talk about the first collective dimension, this is what you actually call God.
<G-vec00272-003-s504><call_for.nennen><de> Wenn wir über die erste kollektive Dimension sprechen, so ist dies das, was ihr Gott nennt.
<G-vec00272-003-s505><call_for.nennen><en> You call them Gods but... Kana yakulani atta'ama.
<G-vec00272-003-s505><call_for.nennen><de> Ihr nennt sie Götter, aber "Kana Yakulani Atta'ama".
<G-vec00272-003-s506><call_for.nennen><en> I also know that many persons, including nuns from various monasteries of contemplative life, "mystical antennae", as you call them, accompany you and support you with their prayers, while the sick, hospital patients and prisoners offer up their sufferings for your apostolate.
<G-vec00272-003-s506><call_for.nennen><de> Ich weiß, daß euch viele Personen, darunter Nonnen in verschiedenen Klöstern des kontemplativen Lebens, die ihr »mystische Antennen« nennt, durch ihr Gebet unterstützen, während Kranke, bettlägerige Patienten in Krankenhäusern sowie Gefangene ihr Leiden eurem Apostolat widmen.
<G-vec00272-003-s507><call_for.nennen><en> In the Basque country, they call it a transition stage, but 6 climbs were on the program on the 164 kilomters between Ataun and Villatuerta.
<G-vec00272-003-s507><call_for.nennen><de> Ausreissersieg durch Baskenland nennt man das eine Übergangsetappe, doch nicht weniger als 6 Bergwertungen standen auch heute auf den 164 Kilometern zwischen Ataun und Villatuerta auf dem Programm.
<G-vec00272-003-s508><call_for.nennen><en> In order to have a clear concept of this planetary body which you call Saturn, it is important to know what its actual name denotes: Earth Calmness, World Nothingdom. It is also absolutely necessary to learn about its natural sphere, its distance from the sun, its size, structure, its inhabitants as well as the inhabitants on the rings and moons, as well as its diverse vegetation in accordance with the conditions that prevail because of distinctly varying climates.
<G-vec00272-003-s508><call_for.nennen><de> Der Saturn Um sich von diesem Weltkörper, den ihr Saturn nennt – während sein eigentlicher Name soviel besagt wie: Erdruhe, Weltnichtstum – einen deutlichen Begriff zu machen, ist vor allem nötig, seine natürliche Sphäre, Entfernung von der Sonne, seine Größe wie auch die seiner Monde so genau wie nur immer eurer Fassungskraft möglich zu erkennen.
<G-vec00272-003-s509><call_for.nennen><en> Furthermore, you become aware of your own limits, in English, you call that ‘Humility’.
<G-vec00272-003-s509><call_for.nennen><de> Des Weiteres wirst du dir auch deiner eigenen Grenzen bewusst, im Englischen nennt man das ‚Humility‘.
<G-vec00272-003-s510><call_for.nennen><en> Indeed these occur through connectivity in the neural networks (plasmic filaments) of the Living Cosmos or gestalt energy you call God.
<G-vec00272-003-s510><call_for.nennen><de> In der Tat geschieht dies durch die Verbindungsfähigkeit in den neuronalen Netzwerken (plasmaartige Leuchtfäden) des lebendigen Kosmos oder der gestaltenden Energie, die ihr Gott nennt.
<G-vec00272-003-s511><call_for.nennen><en> As long as no one is in the way … or a wing is broken – or what would you call it?
<G-vec00272-003-s511><call_for.nennen><de> Das ist ein großer Spaß, wenn keiner im Wege steht … oder ein Flügel hinkt, oder wie man das nennt.
<G-vec00272-003-s512><call_for.nennen><en> In any case, Marlen was not a year old when Lore become pregnant again; so Cristina was what in show business you call the encore, the familiar song, saved for last and laid in a gently polished version at the feet of the breathless audience.
<G-vec00272-003-s512><call_for.nennen><de> Jedenfalls war Marlen noch kein Jahr alt, als Lore wieder schwanger war; Cristina wurde also das, was man im Showbusiness die Zugabe nennt, der vertraute Song, aufgespart, um ihn dem atemlosen Publikum in einer sanft polierten Variante zu Füßen zu legen.
<G-vec00272-003-s532><call_for.rufen><en> Contact us We’re here to help, so send us an e-mail, call us or chat to us live online.
<G-vec00272-003-s532><call_for.rufen><de> Wir helfen Dir gerne weiter, also sende uns doch einfach eine E-Mail, rufe uns an oder chatte live mit uns.
<G-vec00272-003-s533><call_for.rufen><en> 33:3 Call unto Me, and I will answer thee, and will tell thee great things, and hidden, which thou knowest not.
<G-vec00272-003-s533><call_for.rufen><de> 33:3 Rufe mich an, dann will ich dir antworten und will dir Großes und Unfaßbares mitteilen, das du nicht kennst.
<G-vec00272-003-s534><call_for.rufen><en> I call on both parties to continue their constructive approach in the next rounds of talks and to show the necessary willingness to compromise."
<G-vec00272-003-s534><call_for.rufen><de> Ich rufe beide Seiten dazu auf, auch in den folgenden Gesprächsrunden ihren bisherigen konstruktiven Ansatz weiterzuführen und die notwendige Kompromissbereitschaft zu zeigen“.
<G-vec00272-003-s535><call_for.rufen><en> I call some hotel service number and ask for explanations.
<G-vec00272-003-s535><call_for.rufen><de> Ich rufe eine Servicenummer des Hotels an und bitte um Erklärungen.
<G-vec00272-003-s536><call_for.rufen><en> Call upon God to convict you so deeply that you can say, “My sin is ever before me” (Psalm 51:3).
<G-vec00272-003-s536><call_for.rufen><de> Rufe zu Gott, dich so zu überzeugen, daß du sagen kannst, “Meine Sünde ist immer vor mir.” (Ps.
<G-vec00272-003-s537><call_for.rufen><en> 26 I call heaven and earth as witnesses this day, that you shall quickly perish from the land, which, when you have crossed over the Jordan, you will possess.
<G-vec00272-003-s537><call_for.rufen><de> 26. den Himmel und die Erde rufe ich heute als Zeugen gegen euch an: dann werdet ihr unverzüglich aus dem Land ausgetilgt sein, in das ihr jetzt über den Jordan zieht, um es in Besitz zu nehmen.
<G-vec00272-003-s538><call_for.rufen><en> He says, “Call to me and I will answer you, and will tell you great and hidden things that you have not known” (Jer.
<G-vec00272-003-s538><call_for.rufen><de> Er sagt: „Rufe zu mir, so will ich dir antworten und dir große, unfassbare Dinge mitteilen, die du nicht kennst“ (Jer.
<G-vec00272-003-s539><call_for.rufen><en> Males begin to call around March and throughout May.
<G-vec00272-003-s539><call_for.rufen><de> Männchen fangen an, im März und bis Mai Rufe auszustossen.
<G-vec00272-003-s540><call_for.rufen><en> 16I call my servant but he does not reply though I beg him with my own mouth.
<G-vec00272-003-s540><call_for.rufen><de> 16Meinem Knechte rufe ich, und er antwortet nicht; mit meinem Munde muss ich zu ihm flehen.
<G-vec00272-003-s541><call_for.rufen><en> Then call now and learn from a French teacher at a distance.
<G-vec00272-003-s541><call_for.rufen><de> Dann rufe jetzt an und lerne von einem Französischlehrer aus der Ferne.
<G-vec00272-003-s542><call_for.rufen><en> I always get there one more time, there’s nothing else I can do, even here, where I let my hand pass over the tall grass, raise my head and call, my hand, my distinctly real hand.
<G-vec00272-003-s542><call_for.rufen><de> Ich gelange da immer noch einmal hin, ich kann nicht anders, auch hier, wo ich die Hand übers hohe Gras streichen lasse, den Kopf hebe und rufe, meine Hand, meine ausgesprochen wirkliche Hand.
<G-vec00272-003-s543><call_for.rufen><en> Psalms 50:15 And call me in the day of trouble; I will deliver you, and you will glorify me."
<G-vec00272-003-s543><call_for.rufen><de> Psalms 50:15 Und rufe mich an in der Not, so will ich dich erretten, so sollst du mich preisen.
<G-vec00272-003-s544><call_for.rufen><en> I call heaven and earth to record this day against you, that I have set before you life and death, blessing and cursing: therefore choose life, that both thou and thy seed may live…
<G-vec00272-003-s544><call_for.rufen><de> Ich rufe Himmel und Erde an, um diesen Tag gegen dich festzuhalten, den ich dir vor Leben und Tod, Segen und Fluchen gestellt habe: also wähle das Leben, damit sowohl du als auch dein Same leben möge...
<G-vec00272-003-s545><call_for.rufen><en> Call the dialog to search and replace texts in the schematic.
<G-vec00272-003-s545><call_for.rufen><de> Rufe den Dialog, um Texte im Schaltplan zu suchen und zu ersetzen, auf.
<G-vec00272-003-s546><call_for.rufen><en> Call to me and I will answer you, and will tell you great and hidden things that you have not known. prayer listening
<G-vec00272-003-s546><call_for.rufen><de> Rufe mich an, so will ich dir antworten und will dir kundtun große und unfassbare Dinge, von denen du nichts weißt.
<G-vec00272-003-s547><call_for.rufen><en> If you fear that your parent may hurt you, your siblings, or themselves, call the emergency department.
<G-vec00272-003-s547><call_for.rufen><de> Wenn du Angst hast, dass dein Vater oder deine Mutter dich, deine Geschwister oder sich selbst verletzt, rufe den Notdienst.
<G-vec00272-003-s548><call_for.rufen><en> Plumbing, however, is another story. Then I call for help immediately.
<G-vec00272-003-s548><call_for.rufen><de> Klempnerarbeiten sind allerdings etwas ganz anderes: da rufe ich sofort um Hilfe.
<G-vec00272-003-s549><call_for.rufen><en> 16 Jesus said to her, "Go, call your husband, and come here."
<G-vec00272-003-s549><call_for.rufen><de> 16 Er sagte zu ihr: Geh, rufe deinen Mann und komm hierher.
<G-vec00272-003-s550><call_for.rufen><en> Use quirks and call on your companions to help you launch powerful attacks in which you also use the environment — or destroy it completely.
<G-vec00272-003-s550><call_for.rufen><de> Setze Macken ein und rufe Deine Begleiter zu Hilfe, um mächtige Angriffe zu starten, in denen Du auch die Umgebung einsetzt — oder vollständig zerstörst.
<G-vec00272-003-s665><call_for.telefonieren><en> Whether you need to make a call while driving, require current traffic information, want to reach your destination using the navigation system or simply want to listen to your own music – your Golf SV provides various options for using modern technology in a convenient and uncomplicated way.
<G-vec00272-003-s665><call_for.telefonieren><de> Infotainment Ob Sie beim Fahren telefonieren müssen, aktuelle Verkehrsinformationen benötigen, per Navigation Ihr Ziel erreichen wollen oder einfach nur Ihre eigene Musik hören möchten – Ihr Golf Sportsvan bietet Ihnen diverse Möglichkeiten, moderne Technik bequem und unkompliziert zu nutzen.
<G-vec00272-003-s666><call_for.telefonieren><en> No, the man in the picture does not want to call, but checks with the help of the 'Internet of Things', if he has loaded all his tools and not has forgotten any at his former working place.
<G-vec00272-003-s666><call_for.telefonieren><de> Nein, der Mitarbeiter auf dem Bild will nicht telefonieren, sondern überprüft mit Hilfe des 'Internets der Dinge', ob er alle Werkzeuge eingeladen, also keins auf der Baustelle vergessen hat.
<G-vec00272-003-s667><call_for.telefonieren><en> 3 Keeping in touch 3 Keeping in touch Call in style Launching the Phone app Your ASUS Tablet’s Phone app offers you many ways to make a call.
<G-vec00272-003-s667><call_for.telefonieren><de> 3 In Kontakt bleiben In Verbindung bleiben 3 Stilvoll telefonieren Starten der Phone-App Die Telefon-App Ihres ASUS Tablets bietet Ihnen viele Möglichkeiten, einen Anruf abzusetzen.
<G-vec00272-003-s668><call_for.telefonieren><en> Employees can make a call or send an email or fax directly from SAP, Microsoft Dynamics & Co.
<G-vec00272-003-s668><call_for.telefonieren><de> Mitarbeiter können direkt aus SAP, Microsoft Dynamics & Co. telefonieren, eine Mail oder ein Fax versenden.
<G-vec00272-003-s669><call_for.telefonieren><en> If you have to make a phone call while travelling, be careful not to sit in the quiet section when booking your business trip.
<G-vec00272-003-s669><call_for.telefonieren><de> Wenn du während der Fahrt telefonieren musst, achte bei der Buchung der Geschäftsreise darauf, nicht im Ruheabteil zu sitzen.
<G-vec00272-003-s670><call_for.telefonieren><en> Until now, it simply wasn’t possible to listen to music, watch TV, or make a phone call with the vacuum cleaner on in the background.
<G-vec00272-003-s670><call_for.telefonieren><de> Bis jetzt war es schlicht und einfach nicht möglich, Musik zu hören, fernzusehen oder zu telefonieren, wenn ein Staubsauger im Hintergrund lief.
<G-vec00272-003-s671><call_for.telefonieren><en> Regardless of whether you use your cell phone to make a call in the morning, drive your electric car to work or boot your laptop, metal weld connections in the lithium-ion cells made by Schunk Sonosystem devices accompany you reliably throughout the whole day.
<G-vec00272-003-s671><call_for.telefonieren><de> Egal ob Sie morgens mit Ihrem Handy telefonieren, mit Ihrem E-Auto zur Arbeit fahren oder Ihren Laptop hochfahren: Metallschweißungen an den Li-Ionen Zellen von Schunk Sonosystems begleiten Sie zuverlässig den ganzen Tag.
<G-vec00272-003-s672><call_for.telefonieren><en> In the event that it is a false alarm, you can then lie back and relax and call your friends, as Scope doubles up as a cordless landline telephone.
<G-vec00272-003-s672><call_for.telefonieren><de> Sollte es bloß falscher Alarm sein, können Sie sich beruhigt zurücklehnen und ganz in Ruhe mit Ihren Freunden telefonieren, denn Scope ist zugleich ein schnurloses Festnetztelefon.
<G-vec00272-003-s673><call_for.telefonieren><en> No matter where you are from and no matter where exactly you want to call cheap to Russia: from the source of the Volga to the Caspian Sea.
<G-vec00272-003-s673><call_for.telefonieren><de> Egal woher Sie stammen und egal wohin genau Sie günstig nach Russland telefonieren möchten: von der Quelle der Wolga bis ans kaspische Meer.
<G-vec00272-003-s674><call_for.telefonieren><en> Surf, Call, Text security that keeps your communications safe by blocking unwanted content and contact
<G-vec00272-003-s674><call_for.telefonieren><de> Sicherheit beim Surfen, Telefonieren und Simsen schützt Ihre gesamte Kommunikation, indem unerwünschte Inhalte und Kontakte gesperrt werden.
<G-vec00272-003-s675><call_for.telefonieren><en> Up to 8 hours battery life while being used on a call, and up to 200 hours on standby.
<G-vec00272-003-s675><call_for.telefonieren><de> Bis zu 8 Stunden Akkulaufzeit beim Telefonieren und bis zu 200 Stunden im Standby-Betrieb.
<G-vec00272-003-s676><call_for.telefonieren><en> Why to call if all the important information about the office services and working schedules obviously placed on the homepage.
<G-vec00272-003-s676><call_for.telefonieren><de> Warum telefonieren, wenn alle wichtigen Informationen über die Leistungen und Arbeitszeiten offensichtlich auf der Homepage platziert sind.
<G-vec00272-003-s677><call_for.telefonieren><en> Intern: By dialing the room number, you can call another room in the hotel free of charge.
<G-vec00272-003-s677><call_for.telefonieren><de> Intern: Durch wählen der Zimmernummer können Sie im Haus kostenfrei zu einem anderen Zimmer telefonieren.
<G-vec00272-003-s678><call_for.telefonieren><en> They are third party modules integrated into apps to track the user and „call home“ with their findings.
<G-vec00272-003-s678><call_for.telefonieren><de> Dabei handelt es sich um in Apps eingebundene Module von Drittanbietern, die das Verhalten der Anwender beobachten und „nach Hause telefonieren“.
<G-vec00272-003-s679><call_for.telefonieren><en> We couldn’t call each other or text, but in the end we found each other.
<G-vec00272-003-s679><call_for.telefonieren><de> Telefonieren und SMSen war nicht möglich, aber schlussendlich fanden wir uns doch.
<G-vec00272-003-s680><call_for.telefonieren><en> They want to make a call.
<G-vec00272-003-s680><call_for.telefonieren><de> Sie möchten telefonieren.
<G-vec00272-003-s681><call_for.telefonieren><en> Except you call a local KBC employee from the comfort of your home, outside office hours.
<G-vec00272-003-s681><call_for.telefonieren><de> Sie telefonieren mit einem KBC-Mitarbeiter aus Ihrer Nähe, ruhig von zu Hause aus, auch außerhalb der Geschäftszeiten.
<G-vec00272-003-s682><call_for.telefonieren><en> Being a full-blown alternative to a fixed line, it can meet the needs of customers who want to call while remaining connected to the data network. Fixed-line replacement
<G-vec00272-003-s682><call_for.telefonieren><de> Als vollwertige Alternative zum Festnetz geht man auf die Bedürfnisse der Kunden ein, welche telefonieren sowie gleichzeitig über einen Datennetzanschluss verfügen möchten, aber aus unterschiedlichen Gründen kein Festnetz haben.
<G-vec00272-003-s683><call_for.telefonieren><en> How to call from Skype for free, we have already figured out.
<G-vec00272-003-s683><call_for.telefonieren><de> Wie telefonieren mit "Skype" kostenlos, haben wir bereits verstanden.
<G-vec00272-003-s722><call_for.verlangen><en> The SDGs call for a division of labour and a concentration on low income countries that are especially dependent on external support.
<G-vec00272-003-s722><call_for.verlangen><de> Die SDGs verlangen einen arbeitsteiligen Ansatz und eine Konzentration auf Ländern, die besonders stark von externer Unterstützung abhängig sind.
<G-vec00272-003-s723><call_for.verlangen><en> The Registrar has broad powers over trade union accounts, including the right to call for accounts at any time and to investigate any accounts that the Registrar considers unsatisfactory (ss 39 and 40, Trade Unions Act).
<G-vec00272-003-s723><call_for.verlangen><de> Der zuständige Beamte hat weitreichende Befugnisse bezüglich Gewerkschaftskonten wie zum Beispiel das Recht, jederzeit Kontoauszüge zu verlangen oder Konten zu prüfen, die er für unbefriedigend hält (Artikel 39 und 40 des Gewerkschaftsgesetzes).
<G-vec00272-003-s724><call_for.verlangen><en> They shall also be entitled to call for the data to be updated, rectified, supplemented or deleted, ask for them to be blocked or object to their processing, and require further information on the processing of personal data by contacting Assicurazioni Generali, Piazza Duca degli Abruzzi 2, 34132 Trieste.
<G-vec00272-003-s724><call_for.verlangen><de> Sie sind auch berechtigt zu verlangen, dass die Daten aktualisiert, korrigiert, ergänzt oder gelöscht werden; sie können die Daten blockieren lassen oder ihre Verarbeitung ablehnen sowie weitere Informationen über die Verarbeitung der personenbezogenen Daten verlangen, indem sie sich mit Assicurazioni Generali, Piazza Duca degli Abruzzi 2, 34132 Triest, in Verbindung setzen.
<G-vec00272-003-s725><call_for.verlangen><en> They also call for the clubs to respect the legislation dealing with immigration, especially when they employ young players from other countries, and the possibility of their returning to their country of origin if their career doesn’t take off.
<G-vec00272-003-s725><call_for.verlangen><de> Die Abgeordneten verlangen von den Sportvereinen, dass sie insbesondere bei der Verpflichtung jugendlicher Sportler aus Drittländern bestehende Einwanderungsvorschriften einhalten und ihnen die Möglichkeit der Rückkehr in ihr Heimatland offen lassen, falls ihre Karriere nicht wie geplant verläuft.
<G-vec00272-003-s726><call_for.verlangen><en> New technical capabilites and new moral challenges in clinical medicine call for new parameters and principles in post-Hippocratic health care ethics.
<G-vec00272-003-s726><call_for.verlangen><de> Neue technische Möglichkeiten und neue ethische Herausforderungen der klinischen Medizin verlangen nach dem Ausmessen neuer Parameter der klinischen Ethik jenseits von Hippokrates.
<G-vec00272-003-s727><call_for.verlangen><en> These requirements call for structure and for a perfect balance of text and visual elements.
<G-vec00272-003-s727><call_for.verlangen><de> Forderungen, die eine übersichtliche Struktur und ein perfektes Zusammenspiel zwischen den verbalen und visuellen Elementen verlangen.
<G-vec00272-003-s728><call_for.verlangen><en> Since this look can take on a costume makeup appearance, save it for special occasions that call for getting dressed up in style.
<G-vec00272-003-s728><call_for.verlangen><de> Da dieser Look ein Kostüm-Make-up-Erscheinungsbild annehmen kann, solltest du ihn für besondere Ereignisse aufheben, die danach verlangen, dass du dich mit Stil zurecht machst.
<G-vec00272-003-s729><call_for.verlangen><en> Anarcho-primitivists like the Fifth Estate paper in Detroit call for nothing less than the eradication of industrial-technological society and a return to primitive communism.
<G-vec00272-003-s729><call_for.verlangen><de> Anarcho-Primitivlinge wie die Zeitung FIFTH ESTATE in Detroit verlangen nichts geringeres als die Ausmerzung der industriell-technologischen Gesellschaft und die Rückkehr zum primitiven Kommunismus.
<G-vec00272-003-s730><call_for.verlangen><en> Different employers and situations will call for different styles and tones in a cover letter.
<G-vec00272-003-s730><call_for.verlangen><de> Verschiedene Arbeitgeber und Situationen verlangen nach einem sehr unterschiedlichen Stil und Ton im Bewerbungsschreiben.
<G-vec00272-003-s731><call_for.verlangen><en> One is thus led to think that perhaps David Irving, by taking the great risk of launching his libel suit, secretly intended to call the cards of his opponents and that we now see their hand, in the form of van Pelt's book.
<G-vec00272-003-s731><call_for.verlangen><de> Da er sein Plädoyer nun dennoch so vorträgt, kann man vielleicht darauf schließen, dass David Irving, als er das große Risiko seiner Verleumdungsklage auf sich nahm, insgeheim darauf abzielte, von seinen Gegnern zu verlangen, ihre Karten auf den Tisch zu legen und wir nun diese Karten in Gestalt von van Pelts Buch vor uns haben.
<G-vec00272-003-s732><call_for.verlangen><en> Heavier trucks require tires to match, and new tire product lines call for matching tire retreading materials.
<G-vec00272-003-s732><call_for.verlangen><de> Schwere Lkws fordern passende Reifen und neue Reifenproduktlinien verlangen nach passenden Materialien für die Runderneuerung.
<G-vec00272-003-s733><call_for.verlangen><en> Most recommendations call for repeating each exercise 10 times, at least twice a week, for noticeable results.
<G-vec00272-003-s733><call_for.verlangen><de> Die meisten Empfehlungen verlangen, dass jede Übung zehn Mal wiederholt wird, mindestens zweimal pro Woche, um spürbare Ergebnisse zu erzielen.
<G-vec00272-003-s734><call_for.verlangen><en> New energy efficiency targets, such as the 80PLUS® Gold requirement promoted by Climate Savers Computing Initiative, call for approximately a 10 percent improvement in the energy efficiency of computers compared to the current requirements of the U.S. Energy Star program.
<G-vec00272-003-s734><call_for.verlangen><de> Neue Vorgaben zur Energieeinsparung wie die 80PLUS® Gold-Anforderung der Climate Savers Computing Initiative verlangen bei Computern eine weitere Verbesserung der Energieeffizienz im Vergleich zum derzeitigen U.S. Energy Star Programm.
<G-vec00272-003-s735><call_for.verlangen><en> Accelerated social and technological changes call for new attitudes and behaviours on the part of individuals, groups and institutions.
<G-vec00272-003-s735><call_for.verlangen><de> Beschleunigte gesellschaftliche und technologische Wandlungsprozesse verlangen neue Einstellungen und Verhaltensweisen von Individuen, Gruppen und Institutionen.
<G-vec00272-003-s736><call_for.verlangen><en> It is in this spirit that we call for a European peace initiative with a set timeframe leading to tangible results in the context of the two-state solution, which should include an international monitoring and implementation mechanism.
<G-vec00272-003-s736><call_for.verlangen><de> In diesem Geiste verlangen wir eine europäische Friedensinitiative mit einem festgelegten Zeitrahmen, die zu konkreten Ergebnissen im Rahmen der Zwei-Staaten-Lösung führt und einen internationalen Überwachungs- und Umsetzungsmechanismus beinhalten sollte.
<G-vec00272-003-s737><call_for.verlangen><en> Call for an ambulance as soon as possible because the casualty needs hospital care.
<G-vec00272-003-s737><call_for.verlangen><de> Einen Krankenwagen so bald wie möglich verlangen, weil der Unfall Krankenhausobacht benötigt.
<G-vec00272-003-s738><call_for.verlangen><en> In order to completely exit Container Shipping, TUI will obtain the right to call for an IPO with priority placement of the shares held by TUI any time as of end of June 2012.
<G-vec00272-003-s738><call_for.verlangen><de> Um den vollständigen Ausstieg aus der Containerschiffahrt zu vollziehen, erhält TUI das Recht, jederzeit ab Ende Juni 2012 einen Börsengang mit vorrangiger Platzierung der von TUI gehaltenen Aktien zu verlangen.
<G-vec00272-003-s739><call_for.verlangen><en> This shows that the call for a united “Fatherland” had a very material background.
<G-vec00272-003-s739><call_for.verlangen><de> Man sieht hieraus, wie das Verlangen nach einem einheitlichen "Vaterland" einen sehr materiellen Hintergrund besaß.
<G-vec00272-003-s740><call_for.verlangen><en> The Trump administration and the Republican Party will get nearly everything they want, while the Democrats wage a phony war and call on the victims of Trump’s attacks to wait until the 2018 elections.
<G-vec00272-003-s740><call_for.verlangen><de> Die Trump-Regierung und die Republikaner werden fast alles durchsetzen, während die Demokraten nur symbolisch kämpfen und von den Opfern verlangen, dass sie sich bis zur Kongresswahl 2018 gedulden.
