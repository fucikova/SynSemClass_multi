<G-vec00520-002-s044><depend.abhängen><en> Yes, mineral waters have different tastes, which depend on the minerals specialities
<G-vec00520-002-s044><depend.abhängen><de> Denn die Mineralwasser haben verschiedene Geschmäcke, die abhängen von der im Wasser enthaltenen Mineralisierung.
<G-vec00520-002-s045><depend.abhängen><en> Rotating Tables can be in round, square, even eight-jaws, depend on various requirements of welding task.
<G-vec00520-002-s045><depend.abhängen><de> Drehende Tabellen können in der Runde, Quadrat, sogar Achtkiefer sein, abhängen von den verschiedenen Anforderungen der Schweißensaufgabe.
<G-vec00520-002-s046><depend.abhängen><en> If this place is located in the bilingual Brussels Capital Region, this competence will depend on the language that is used in the application or the language chosen by the defendant.
<G-vec00520-002-s046><depend.abhängen><de> Wenn sich dieser Ort im zweisprachigen Gebiet Brüssel-Hauptstadt befindet, wird diese Zuständigkeit von der Sprache abhängen, die im Antrag verwendet wurde oder von der Sprache, die vom Beklagten gewählt wurde.
<G-vec00520-002-s047><depend.abhängen><en> How I act will therefore depend on how my capacity for intuition works in relation to a particular situation.
<G-vec00520-002-s047><depend.abhängen><de> Wie ein Mensch handelt, wird also abhängen von der Art, wie sein Intuitionsvermögen einer bestimmten Situation gegenüber wirkt.
<G-vec00520-002-s048><depend.abhängen><en> The amounts in which proteolytic enzymes are used versus the animal protein will depend on substrate concentration, enzyme titer, reaction temperature, and reaction time, but typically range from about 100 to 10,000 units of activity per 1 g of protein contained in the animal protein dispersion or solution.
<G-vec00520-002-s048><depend.abhängen><de> Die Mengen, in denen proteolytische Enzyme in Bezug auf tierisches Protein verwendet werden, wird abhängen von der Substratkonzentration, dem Enzymtiter, der Reaktionstemperatur und der Reaktionszeit, wobei sie im typischen Fall im Bereich von 100 bis 10.000 Einheiten der Enzymaktivität pro 1 g Protein, die in der Dispersion oder Lösung des tierischen Proteins enthalten sind.
<G-vec00520-002-s049><depend.abhängen><en> Not only do we depend on our cars to get us where we want to go, we also depend on them to get us there without discomfort.
<G-vec00520-002-s049><depend.abhängen><de> Nicht nur hängen wir von unseren Autos ab, um uns zu erhalten, wo wir gehen möchten, wir abhängen auch von ihnen, um uns ohne Unannehmlichkeit dort zu erhalten.
<G-vec00520-002-s050><depend.abhängen><en> Whether this expropriation is to be compensated for or not will, to a great extent, depend not upon us but the circumstances under which we obtain power, and particularly upon the attitude adopted by these gentry, the big landowners, themselves.
<G-vec00520-002-s050><depend.abhängen><de> Ob diese Expropriation mit oder ohne Entschädigung erfolgt, wird großenteils nicht von uns abhängen, sondern von den Umständen, unter denen wir in den Besitz der Macht kommen, und namentlich auch von der Haltung der Herren Großgrundbesitzer selbst.
<G-vec00520-002-s204><depend.beruhen><en> Simulation models depend on a large amount of organizational information from across the business to generate a precise, on-demand picture of expected future supply and demand.
<G-vec00520-002-s204><depend.beruhen><de> Simulationsmodelle beruhen auf Informationen aus dem gesamten Unternehmen, um ein präzises und stets aktuelles Bild von zukünftigen Angebot-und-Nachfrage-Situationen darzustellen.
<G-vec00520-002-s205><depend.beruhen><en> These rates depend on your individual credit history and specific loan transaction.
<G-vec00520-002-s205><depend.beruhen><de> Diese Zinssätze beruhen auf Ihrem individuellen Kreditverlauf und spezifischen Kredittransaktionen.
<G-vec00520-002-s206><depend.beruhen><en> But these breaks depend merely on the number of related forms which have become extinct.
<G-vec00520-002-s206><depend.beruhen><de> Aber alle diese Unterbrechungen beruhen lediglich auf der Zahl der verwandten Formen, welche ausgestorben sind.
<G-vec00520-002-s207><depend.beruhen><en> The efficient running and ultimate success of your international events depend to a large extent on the quality of the interpretation.
<G-vec00520-002-s207><depend.beruhen><de> Ein reibungsloser Ablauf und der Erfolg internationaler Veranstaltungen beruhen zu einem großen Teil auf der Qualität des Dolmetschens.
<G-vec00520-002-s208><depend.beruhen><en> Successful projects depend on interaction and cooperation between partners.
<G-vec00520-002-s208><depend.beruhen><de> Erfolgreiche Projekte beruhen auf Interaktion und Kooperation zwischen Partnern.
<G-vec00520-002-s209><depend.beruhen><en> The formation of the body, the functioning of the immune system and the spread of cancer all depend on the ability of cells to migrate.
<G-vec00520-002-s209><depend.beruhen><de> Die Entwicklung des Körpers, die Funktionen des Immunsystems und die Ausbreitung von Krebs beruhen auf Zellmigration.
<G-vec00520-002-s210><depend.beruhen><en> the critique of correlation seems to depend on an equivocation regarding the relation of thinking and being, of epistemology and ontology.
<G-vec00520-002-s210><depend.beruhen><de> [...] [Meine Übersetzung: Die Kritik am Korrelationismus scheint auf einer Äquivokation bezüglich der Relation zwischen Denken und Sein zu beruhen, zwischen Erkenntnistheorie und Ontologie.
<G-vec00520-002-s211><depend.beruhen><en> On the whole, the concepts of remembrance and memory depend upon what a national collective imagines when it thinks back over the past.
<G-vec00520-002-s211><depend.beruhen><de> Die Begriffe der Erinnerung und des Gedächtnisses beruhen in der Regel auf der Vorstellung eines nationalen Kollektivs, das an die Vergangenheit zurückdenkt.
<G-vec00520-002-s212><depend.beruhen><en> Your actions will depend on your choice and the type of mission you have to fulfill (attack or defense).
<G-vec00520-002-s212><depend.beruhen><de> Die Aktionen werden auf Ihrer Auswahl beruhen und die Art der Mission, die Sie erfüllen müssen (Angriff oder Verteidigung).
<G-vec00520-002-s213><depend.beruhen><en> Numerous OECD guidelines depend on the use of fish, including OECD 203 (acute fish test), OECD 210 (early life stage toxicity test) and OECD 305 (bioconcentration test).
<G-vec00520-002-s213><depend.beruhen><de> Zahlreiche Richtlinien der OECD beruhen auf dem Einsatz von Fischen, einschließlich OECD 203 (akuter Fischtest), OECD 210 (Toxizitätstest mit frühen Lebensstadien von Fischen) und OECD 305 (Biokonzentrations-Test).
<G-vec00520-002-s214><depend.brauchen><en> 27 June 2017 To improve Germany – and Berlin and Hamburg in particular – as a business location for startups, we depend on high-quality data and information how these startup ecosystems perform in an international comparison and develop over time.
<G-vec00520-002-s214><depend.brauchen><de> Um Deutschland – sowie Berlin und Hamburg im Speziellen – als Standort für Startups weiterzuentwickeln, brauchen wir hochwertige Daten und Informationen darüber, wo die Startup-Ökosysteme im internationalen Vergleich stehen und wie sie sich im Zeitverlauf entwickeln.
<G-vec00520-002-s215><depend.brauchen><en> Our future growth will depend on experienced and highly competent advisors such as him”, explains managing partner Prof. Dr. Christian Rödl.
<G-vec00520-002-s215><depend.brauchen><de> Für unser weiteres Wachstum brauchen wir erfahrene und hoch kompetente Beratungspersönlichkeiten wie ihn”, erklärt der Geschäftsführende Partner Prof. Dr. Christian Rödl.
<G-vec00520-002-s217><depend.brauchen><en> The quality of our paper production and the smooth operation of all our departments and divisions depend absolutely on the quality of our people.
<G-vec00520-002-s217><depend.brauchen><de> Für die Qualität der Papierproduktion und für den reibungslosen Ablauf in allen Bereichen brauchen wir gute Leute.
<G-vec00520-002-s218><depend.brauchen><en> Each crop has varieties suitable for outdoor growing but they depend on good, warm weather and you need to provide them with shelter and careful positioning for them to thrive.
<G-vec00520-002-s218><depend.brauchen><de> Jede dieser Gemüsearten beinhaltet auch Sorten, die sich im Freien anbauen lassen, aber diese brauchen gutes, warmes Wetter und Sie müssen sie an einen gut durchdachten, geschützten Standort pflanzen, damit sie gedeihen.
<G-vec00520-002-s219><depend.brauchen><en> European Commissioner for the Environment Janez Potočnik said: "We are part of biodiversity, but we also depend on it for our food, for fresh water and clean air, and for a stable climate.
<G-vec00520-002-s219><depend.brauchen><de> Hierzu erklärte EU-Umweltkommissar Janez Potočnik: „Wir selbst sind Teil der Biodiversität, aber wir brauchen sie auch, für unsere Ernährung, für frisches Wasser, saubere Luft und ein stabiles Klima.
<G-vec00520-002-s220><depend.brauchen><en> Creative Cloud for enterprise includes all of the creative apps global organisations depend on for video production.
<G-vec00520-002-s220><depend.brauchen><de> Creative Cloud für Unternehmen bietet sämtliche Kreativ-Tools, die Organisationen weltweit für die Videoproduktion brauchen.
<G-vec00520-002-s221><depend.brauchen><en> Fish farmers depend on clean water and sanitary living conditions.
<G-vec00520-002-s221><depend.brauchen><de> Fischzüchter brauchen sauberes Wasser und gesunde Lebensbedingungen für die Tiere.
<G-vec00520-002-s222><depend.brauchen><en> While most smokers depend on cigarettes to temporarily relieve stress, the habit actually increases anxiety, stress, and depression in the long run.
<G-vec00520-002-s222><depend.brauchen><de> Die meisten Raucher brauchen Zigaretten, um kurzzeitig Stress zu lindern, aber diese Gewohnheit erhöht in Wahrheit auf lange Sicht Angstzustände, Stress und Depression.
<G-vec00520-002-s223><depend.brauchen><en> Two key technological trends that reinforce each other – and arguably even depend on each other – are photonics and digitalization.
<G-vec00520-002-s223><depend.brauchen><de> Mit Photonik und Digitalisierung kommen zwei große technische Trends zusammen und verstärken einander – ja: brauchen einander.
<G-vec00520-002-s224><depend.brauchen><en> Like humans, many animals depend on beneficial microbes for survival.
<G-vec00520-002-s224><depend.brauchen><de> Wie wir Menschen brauchen die meisten Tiere Mikroorganismen für ihr Überleben.
<G-vec00520-002-s419><depend.müssen><en> Of course, the characteristics of the different kinds of construction boards depend on the applications they are used for.
<G-vec00520-002-s419><depend.müssen><de> Bauplatten müssen für verschiedene Anwendungen selbstverständlich verschiedenen Kriterien entsprechen.
<G-vec00520-002-s420><depend.müssen><en> However, to personalize your experience on the Travel Alberta websites, including targeting offers and advertisements of interest to you, certain features depend on the ability to automatically issue a "persistent" cookie.
<G-vec00520-002-s420><depend.müssen><de> Um Ihre Nutzererfahrung auf den Websites von Travel Alberta individuell anzupassen und unter anderem für Sie interessante Angebote und Werbung zu platzieren, müssen bestimmte Funktionen automatisch ein Dauer-Cookie setzen.
<G-vec00520-002-s421><depend.müssen><en> When it comes to quantity, it can depend on many factors.
<G-vec00520-002-s421><depend.müssen><de> Wenn es um die optimale Dosierung geht, müssen verschiedene Faktoren berücksichtigt werden.
<G-vec00520-002-s422><depend.müssen><en> They depend on an active partner to be read.
<G-vec00520-002-s422><depend.müssen><de> Sie müssen einen aktiven Partner haben, um gelesen zu werden.
<G-vec00520-002-s423><depend.müssen><en> Attaining this Lisbon objective will depend on the committed involvement of all players in education and training.
<G-vec00520-002-s423><depend.müssen><de> Soll das in Lissabon gesetzte Ziel erreicht werden, so müssen sich sämtliche Akteure der allgemeinen und beruflichen Bildung voll engagieren.
<G-vec00520-002-s424><depend.müssen><en> While every industry has its own challenges, its own language, its own regulations and its own strategy, they all depend on similar processes to bring their brands to market.
<G-vec00520-002-s424><depend.müssen><de> Jede Branche hat ihre eigenen Herausforderungen, eine eigene Sprache, eigene Vorschriften und eine eigene Strategie - doch alle müssen auf ähnliche Weise ihre Marken im Markt positionieren.
<G-vec00520-002-s444><depend.richten><en> Type and design of the customised TST systems depend on the respective production volume of our customers.
<G-vec00520-002-s444><depend.richten><de> Art und Aufbau der individuell gefertigten TST-Anlagen richtet sich nach dem jeweiligen Produktionsvolumen unserer Kunden.
<G-vec00520-002-s445><depend.richten><en> The dimensions of the diamond aggregate depend on the dimensions of the grinding wheel and the customer‘s desired tool replacement interval.
<G-vec00520-002-s445><depend.richten><de> Die Dimension des Diamantaggregates richtet sich nach der Dimension der Schleifscheibe sowie dem gewünschten Werkzeugwechselintervall des Kunden.
<G-vec00520-002-s446><depend.richten><en> The amount of winnings depend on your current stakes.
<G-vec00520-002-s446><depend.richten><de> Die Höhe des Gewinns richtet sich nach Ihrem aktuellen Einsatz.
<G-vec00520-002-s447><depend.richten><en> The time required to solve the problem will depend on the complexity of the problem and the urgency finding a solution.
<G-vec00520-002-s447><depend.richten><de> Der Zeitraum für die Problemlösung richtet sich nach der Komplexität des Problems und der Dringlichkeit der Lösung.
<G-vec00520-002-s448><depend.richten><en> The type of visa will depend on the length of the stay.
<G-vec00520-002-s448><depend.richten><de> Welches Visum du genau benötigst, richtet sich nach der Länge deines Aufenthalts.
<G-vec00520-002-s449><depend.richten><en> The size of a module will depend on the content of the Flow Box.
<G-vec00520-002-s449><depend.richten><de> Die Größe eines Moduls richtet sich nach dem Inhalt der Flow Box.
<G-vec00520-002-s450><depend.richten><en> Further treatment strategies depend on the extent of disease and the recurrence risk.
<G-vec00520-002-s450><depend.richten><de> Die weitere Behandlung der Krebserkrankung richtet sich nach dem Ausmaß der Erkrankung und dem Risiko des Wiederauftretens der Erkrankung.
<G-vec00520-002-s451><depend.richten><en> The numbers of points allocated in the VLN depend on the numbers of cars in the various classes.
<G-vec00520-002-s451><depend.richten><de> Die Punktevergabe in der VLN richtet sich nach der Anzahl der Gegner in der Klasse.
<G-vec00520-002-s452><depend.richten><en> The decision as to which of the two procedures will be used to collect stem cells from the donor will depend on the needs of the patient.
<G-vec00520-002-s452><depend.richten><de> Die Entscheidung, welches der beiden Verfahren zur Stammzellgewinnung beim Spender angewandt wird, richtet sich nach den Belangen des Patienten.
<G-vec00520-002-s453><depend.richten><en> The performances depend on the current building site situation and will take place in the afternoon. Contributors
<G-vec00520-002-s453><depend.richten><de> Die Performance richtet sich nach der aktuellen Baustellensituation, daher variieren die Anfangs- und Endzeiten an den Aufführungstagen.
<G-vec00520-002-s454><depend.richten><en> CE conformity marking The procedures for obtaining the CE conformity marking depend upon the device and level of safety provided.
<G-vec00520-002-s454><depend.richten><de> CE-Kennzeichnung Nach welchen Verfahren die CE-Kennzeichnung beantragt wird, richtet sich nach dem betreffenden Gerät und dem Schutzumfang.
<G-vec00520-002-s455><depend.richten><en> Your competent supervisory authority will depend on the state of your domicile, work or the presumed violation.
<G-vec00520-002-s455><depend.richten><de> Ihre zuständige Aufsichtsbehörde richtet sich nach dem Bundesland Ihres Wohnsitzes, Ihrer Arbeit oder der mutmaßlichen Verletzung.
<G-vec00520-002-s456><depend.richten><en> The sponsorship amount and duration depend on the academic status of the applicant. In addition, a number of allowances and contributions may be applied for.
<G-vec00520-002-s456><depend.richten><de> Die Höhe und Dauer der monatlichen Förderung richtet sich nach dem Status des Bewerbers, zudem können eine Reihe von Zuschüssen und Beihilfen dazukommen.
<G-vec00520-002-s457><depend.richten><en> Treatment will depend on the cause and type of your anemia.
<G-vec00520-002-s457><depend.richten><de> Die Behandlung richtet sich nach der Ursache und dem Schweregrad der Anämie.
<G-vec00520-002-s458><depend.richten><en> The number of sanding steps and the fineness of the sanding materials depend on the surface treatment.
<G-vec00520-002-s458><depend.richten><de> Die Anzahl der Schleifgänge und die Feinheit der Körnung richtet sich nach der Oberflächenbehandlung.
<G-vec00520-002-s459><depend.richten><en> The frequency of inspections and supervision shall depend on the size of the plant, the type of products manufactured, risk assessment and guarantees offered, based on the principles of the system of HACCP.
<G-vec00520-002-s459><depend.richten><de> Die Häufigkeit der Inspektionen und sonstigen Überwachungsmaßnahmen richtet sich nach der Größe des Betriebs, der Art der hergestellten Erzeugnisse, der Risikobewertung und den nach den Grundsätzen des HACCP-Systems gebotenen Garantien.
<G-vec00520-002-s460><depend.richten><en> 6.1 The amount of the Commissions in each individual case, and the type of business transactions entitling to the payment of Commissions, shall depend on the respective Advertiser's partner program.
<G-vec00520-002-s460><depend.richten><de> 6.1 Wie hoch die Vergütung im Einzelfall ist und für welche Art von Geschäftsabschlüssen diese gewährt wird, richtet sich nach dem jeweiligen Partnerprogramm des Advertisers.
<G-vec00520-002-s462><depend.richten><en> The choice for the second route will depend on the nature of the substance and the likely route of human exposure.
<G-vec00520-002-s462><depend.richten><de> Die Wahl des zweiten Verabreichungsweges richtet sich nach der Art des Stoffes und dem wahrscheinlichen Expositionsweg beim Menschen.
<G-vec00520-002-s578><depend.sein><en> These colours correspond to the body construction and depend on the composition of the blood-blue-brown-grey.
<G-vec00520-002-s578><depend.sein><de> Die Farben – blau, braun oder grau entsprechen der Körper-Konstruktion und sind von der Zusammensetzung des Bluts abhängig.
<G-vec00520-002-s579><depend.sein><en> The upstream and downstream straight lengths depend on many factors, such as the piping system and the beta ratio, for which reason no blanket statement can be made on this.
<G-vec00520-002-s579><depend.sein><de> Die Ein- und Auslaufstrecken sind von vielen Faktoren beeinflusst, wie dem Rohrsystem und den Beta-Verhältnissen, weshalb sich darüber pauschal keine Aussage treffen lässt.
<G-vec00520-002-s580><depend.sein><en> The quality of plastic products and the productivity of plastics processing machines depend on many factors and influences.
<G-vec00520-002-s580><depend.sein><de> Die Qualität von Kunststoffprodukten sowie die Produktivität von kunststoffverarbeitenden Maschinen sind von vielen Faktoren abhängig.
<G-vec00520-002-s581><depend.sein><en> 3.1.1 The possibility to cancel or change a travel service purchased through this Platform, as well as the way to change or cancel, will depend on the terms and conditions of your Travel Supplier(s), which usually depend on the type of fare chosen (i.e. low cost airlines do not usually allow for a change or cancellation).
<G-vec00520-002-s581><depend.sein><de> 3.1.1 Die Möglichkeit, einen über diese Plattform gekauften Reiseservice zu ändern oder zu stornieren, sowie die Art und Weise, wie Sie diesen ändern oder stornieren können, sind von den allgemeinen Geschäftsbedingungen des/der Reiseanbieter(s) abhängig, die in der Regel von der Art des ausgewählten Tarifs abhängig sind (d. h. Billigfluglinien lassen in der Regel keine Änderungen oder Stornierungen zu).
<G-vec00520-002-s582><depend.sein><en> These future residual values depend on the situation in the used-vehicle markets prevailing when the vehicles are returned.
<G-vec00520-002-s582><depend.sein><de> Diese zukünftigen Restwerte sind von den Verhältnissen auf den Gebrauchtfahrzeugmärkten bei Rückgabe der Fahrzeuge abhängig.
<G-vec00520-002-s583><depend.sein><en> Attraction, activation and transmigration of inflammatory cells to the site of ß-cell injury depend on two major molecular interactions.
<G-vec00520-002-s583><depend.sein><de> Für die Rekrutierung, Aktivierung und Transmigration von Leukozyten sind Interaktionen zwischen Oberflächenrezeptoren von zirkulierenden Leukozyten und endothelialen Entzündungsfaktoren oder Adhäsionsmolekülen verantwortlich.
<G-vec00520-002-s468><depend.setzen><en> Many academic institutions mistakenly rely solely on waivers to protect them against potential liability and depend exclusively on embassies should something go wrong.
<G-vec00520-002-s468><depend.setzen><de> Zahlreiche akademische Institutionen verlassen sich irrtümlich allein auf Verzichts- / Freistellungserklärungen, um einer potentiellen Haftpflicht zu entgehen und setzen ausschließlich auf die Botschaften.
<G-vec00520-002-s469><depend.setzen><en> We depend on you and we offer more than just an exciting, varied work environment.
<G-vec00520-002-s469><depend.setzen><de> Wir setzen auf Sie und bieten Ihnen mehr als nur ein spannendes und abwechslungsreiches Arbeitsumfeld.
<G-vec00520-002-s470><depend.setzen><en> Regarding the end H, we also depend, when applicable, on our obligation to comply with the applicable legislation.
<G-vec00520-002-s470><depend.setzen><de> Im Hinblick auf den Zweck von H setzen wir, soweit anwendbar, unsere Verpflichtung, anwendbare Gesetze zu befolgen, voraus.
<G-vec00520-002-s471><depend.setzen><en> Depend on datacenters and cloud services that meet or exceed the critical requirements needed for your agency’s workloads.
<G-vec00520-002-s471><depend.setzen><de> Setzen Sie auf Rechenzentren und Clouddienste, die die kritischen Anforderungen an die Workloads Ihrer Behörde erfüllen oder sogar übertreffen.
<G-vec00520-002-s472><depend.setzen><en> Depend on our well-thought-out concepts for skills, in-house, or emergency training.
<G-vec00520-002-s472><depend.setzen><de> Setzen Sie auf unsere ausgereiften Konzepte für Skill-, Inhouse- oder Notfall-Training.
<G-vec00520-002-s473><depend.setzen><en> “All these developments depend on the continued collaboration of industry, academia, government, and associations — the four dimensions of 3D printing,” says Prof. Dr. Michael Süss, Chairman of the Board of Directors of Oerlikon.
<G-vec00520-002-s473><depend.setzen><de> „All diese Entwicklungen setzen auf die kontinuierliche Zusammenarbeit von Industrie, Wissenschaft, Behörden und Verbänden – die 4 Dimensionen des 3D-Drucks,“ appelliert Prof. Dr. Michael Süss, Vorstandsvorsitzender von Oerlikon.
<G-vec00520-002-s474><depend.setzen><en> Professional garages depend, therefore, on the original – the LuK DMF from Schaeffler Automotive Aftermarket.
<G-vec00520-002-s474><depend.setzen><de> Professionelle Werkstätten setzen daher auf das Original – das LuK DMF von Schaeffler Automotive Aftermarket.
<G-vec00520-002-s475><depend.setzen><en> We depend upon sustainable management, through which a combination of economic, ecological and social factors forms the basis of all our actions.
<G-vec00520-002-s475><depend.setzen><de> Wir setzen auf ein nachhaltiges Management, bei dem ein Zusammenspiel aus ökonomischen, ökologischen und sozialen Faktoren die Basis für unsere Handlungen bildet.
<G-vec00520-002-s476><depend.setzen><en> This is an area where we depend on breathing space, trust, and fairness.
<G-vec00520-002-s476><depend.setzen><de> Hier setzen wir auf Freiräume, Vertrauen und Fairness.
<G-vec00520-002-s444><depend.sich_richten><en> Type and design of the customised TST systems depend on the respective production volume of our customers.
<G-vec00520-002-s444><depend.sich_richten><de> Art und Aufbau der individuell gefertigten TST-Anlagen richtet sich nach dem jeweiligen Produktionsvolumen unserer Kunden.
<G-vec00520-002-s445><depend.sich_richten><en> The dimensions of the diamond aggregate depend on the dimensions of the grinding wheel and the customer‘s desired tool replacement interval.
<G-vec00520-002-s445><depend.sich_richten><de> Die Dimension des Diamantaggregates richtet sich nach der Dimension der Schleifscheibe sowie dem gewünschten Werkzeugwechselintervall des Kunden.
<G-vec00520-002-s446><depend.sich_richten><en> The amount of winnings depend on your current stakes.
<G-vec00520-002-s446><depend.sich_richten><de> Die Höhe des Gewinns richtet sich nach Ihrem aktuellen Einsatz.
<G-vec00520-002-s447><depend.sich_richten><en> The time required to solve the problem will depend on the complexity of the problem and the urgency finding a solution.
<G-vec00520-002-s447><depend.sich_richten><de> Der Zeitraum für die Problemlösung richtet sich nach der Komplexität des Problems und der Dringlichkeit der Lösung.
<G-vec00520-002-s448><depend.sich_richten><en> The type of visa will depend on the length of the stay.
<G-vec00520-002-s448><depend.sich_richten><de> Welches Visum du genau benötigst, richtet sich nach der Länge deines Aufenthalts.
<G-vec00520-002-s449><depend.sich_richten><en> The size of a module will depend on the content of the Flow Box.
<G-vec00520-002-s449><depend.sich_richten><de> Die Größe eines Moduls richtet sich nach dem Inhalt der Flow Box.
<G-vec00520-002-s450><depend.sich_richten><en> Further treatment strategies depend on the extent of disease and the recurrence risk.
<G-vec00520-002-s450><depend.sich_richten><de> Die weitere Behandlung der Krebserkrankung richtet sich nach dem Ausmaß der Erkrankung und dem Risiko des Wiederauftretens der Erkrankung.
<G-vec00520-002-s451><depend.sich_richten><en> The numbers of points allocated in the VLN depend on the numbers of cars in the various classes.
<G-vec00520-002-s451><depend.sich_richten><de> Die Punktevergabe in der VLN richtet sich nach der Anzahl der Gegner in der Klasse.
<G-vec00520-002-s452><depend.sich_richten><en> The decision as to which of the two procedures will be used to collect stem cells from the donor will depend on the needs of the patient.
<G-vec00520-002-s452><depend.sich_richten><de> Die Entscheidung, welches der beiden Verfahren zur Stammzellgewinnung beim Spender angewandt wird, richtet sich nach den Belangen des Patienten.
<G-vec00520-002-s453><depend.sich_richten><en> The performances depend on the current building site situation and will take place in the afternoon. Contributors
<G-vec00520-002-s453><depend.sich_richten><de> Die Performance richtet sich nach der aktuellen Baustellensituation, daher variieren die Anfangs- und Endzeiten an den Aufführungstagen.
<G-vec00520-002-s454><depend.sich_richten><en> CE conformity marking The procedures for obtaining the CE conformity marking depend upon the device and level of safety provided.
<G-vec00520-002-s454><depend.sich_richten><de> CE-Kennzeichnung Nach welchen Verfahren die CE-Kennzeichnung beantragt wird, richtet sich nach dem betreffenden Gerät und dem Schutzumfang.
<G-vec00520-002-s455><depend.sich_richten><en> Your competent supervisory authority will depend on the state of your domicile, work or the presumed violation.
<G-vec00520-002-s455><depend.sich_richten><de> Ihre zuständige Aufsichtsbehörde richtet sich nach dem Bundesland Ihres Wohnsitzes, Ihrer Arbeit oder der mutmaßlichen Verletzung.
<G-vec00520-002-s456><depend.sich_richten><en> The sponsorship amount and duration depend on the academic status of the applicant. In addition, a number of allowances and contributions may be applied for.
<G-vec00520-002-s456><depend.sich_richten><de> Die Höhe und Dauer der monatlichen Förderung richtet sich nach dem Status des Bewerbers, zudem können eine Reihe von Zuschüssen und Beihilfen dazukommen.
<G-vec00520-002-s457><depend.sich_richten><en> Treatment will depend on the cause and type of your anemia.
<G-vec00520-002-s457><depend.sich_richten><de> Die Behandlung richtet sich nach der Ursache und dem Schweregrad der Anämie.
<G-vec00520-002-s458><depend.sich_richten><en> The number of sanding steps and the fineness of the sanding materials depend on the surface treatment.
<G-vec00520-002-s458><depend.sich_richten><de> Die Anzahl der Schleifgänge und die Feinheit der Körnung richtet sich nach der Oberflächenbehandlung.
<G-vec00520-002-s459><depend.sich_richten><en> The frequency of inspections and supervision shall depend on the size of the plant, the type of products manufactured, risk assessment and guarantees offered, based on the principles of the system of HACCP.
<G-vec00520-002-s459><depend.sich_richten><de> Die Häufigkeit der Inspektionen und sonstigen Überwachungsmaßnahmen richtet sich nach der Größe des Betriebs, der Art der hergestellten Erzeugnisse, der Risikobewertung und den nach den Grundsätzen des HACCP-Systems gebotenen Garantien.
<G-vec00520-002-s460><depend.sich_richten><en> 6.1 The amount of the Commissions in each individual case, and the type of business transactions entitling to the payment of Commissions, shall depend on the respective Advertiser's partner program.
<G-vec00520-002-s460><depend.sich_richten><de> 6.1 Wie hoch die Vergütung im Einzelfall ist und für welche Art von Geschäftsabschlüssen diese gewährt wird, richtet sich nach dem jeweiligen Partnerprogramm des Advertisers.
<G-vec00520-002-s462><depend.sich_richten><en> The choice for the second route will depend on the nature of the substance and the likely route of human exposure.
<G-vec00520-002-s462><depend.sich_richten><de> Die Wahl des zweiten Verabreichungsweges richtet sich nach der Art des Stoffes und dem wahrscheinlichen Expositionsweg beim Menschen.
<G-vec00520-002-s617><depend.sich_verlassen><en> Production capacity Depend on different products.
<G-vec00520-002-s617><depend.sich_verlassen><de> Produktion Kapazität Verlassen Sie sich auf verschiedene Produkte.
<G-vec00520-002-s618><depend.sich_verlassen><en> You should not depend on specific bucket naming conventions for availability or security verification purposes.
<G-vec00520-002-s618><depend.sich_verlassen><de> Verlassen Sie sich nicht auf eine spezifische Benennungskonvention für Buckets für Verfügbarkeits- oder Sicherheitsprüfungszwecke.
<G-vec00520-002-s619><depend.sich_verlassen><en> Today, millions of users depend on AlgoRex completely.
<G-vec00520-002-s619><depend.sich_verlassen><de> Heute verlassen sich Millionen Anwender ausschließlich auf AlgoRex®.
<G-vec00520-002-s620><depend.sich_verlassen><en> Owners, outfitters, and shipyards around the world depend on AVENTICS.
<G-vec00520-002-s620><depend.sich_verlassen><de> Eigner, Reedereien und Werften rund um den Globus verlassen sich auf AVENTICS.
<G-vec00520-002-s621><depend.sich_verlassen><en> Nearly a million citizens and foreign workers depend on the city’s government for daily services.
<G-vec00520-002-s621><depend.sich_verlassen><de> Etwa eine Million Bürger und ausländische Arbeitskräfte verlassen sich täglich auf die Dienstleistungen der Stadtverwaltung.
<G-vec00520-002-s622><depend.sich_verlassen><en> You may depend on our longtime wedding experience: we will see you through the preparations and all the way through your big day.
<G-vec00520-002-s622><depend.sich_verlassen><de> Verlassen Sie sich auf unseren erfahrenen Service: Wir beraten und begleiten Sie durch die Vorbereitungen und durch Ihren großen Tag.
<G-vec00520-002-s623><depend.sich_verlassen><en> Too many people depend on us.
<G-vec00520-002-s623><depend.sich_verlassen><de> Zu viele Leute verlassen sich auf uns.
<G-vec00520-002-s624><depend.sich_verlassen><en> They strongly depend on the explosive jump.
<G-vec00520-002-s624><depend.sich_verlassen><de> Sie verlassen sich stark auf die enormen Springen.
<G-vec00520-002-s625><depend.sich_verlassen><en> Proven quality from Testo: you can depend on reliable measurement results, because the humidity/temperature probe is equipped with our long-term stable humidity sensor.
<G-vec00520-002-s625><depend.sich_verlassen><de> Bewährte Qualität von Testo: Verlassen Sie sich auf zuverlässige Messergebnisse, denn die Feuchte-Temperatur-Sonde ist mit unserem langzeitstabilen Feuchtesensor ausgestattet.
<G-vec00520-002-s626><depend.sich_verlassen><en> Builders, manufacturers, shippers and retailers depend on our thermal solutions to protect perishables and save energy.
<G-vec00520-002-s626><depend.sich_verlassen><de> Bauunternehmer, Fabrikanten, Speditionen und Wiederverkäufer verlassen sich auf unsere Lösungen zum thermischen Schutz temperatursensibler Ware und zur Energieeinsparung.
<G-vec00520-002-s627><depend.sich_verlassen><en> Don't depend on GPS.
<G-vec00520-002-s627><depend.sich_verlassen><de> Verlassen Sie sich nicht auf GPS.
<G-vec00520-002-s628><depend.sich_verlassen><en> I have taken the lead in doing many things and they have come to depend on me, causing them to have nothing to say.
<G-vec00520-002-s628><depend.sich_verlassen><de> Bei der Erledigung mancher Dinge habe ich die Leitung übernommen und sie verlassen sich auf mich, was bewirkt, dass sie nichts sagen.
<G-vec00520-002-s629><depend.sich_verlassen><en> Proven quality from Testo: you can depend on reliable measurement results, because the humidity/temperature probe is equipped with our high-precision, long-term stable humidity sensor.
<G-vec00520-002-s629><depend.sich_verlassen><de> Bewährte Qualität von Testo: Verlassen Sie sich auf zuverlässige Messergebnisse, denn die Feuchte-Temperatur-Sonde ist mit unserem hochpräzisen und langzeitstabilen Feuchtesensor ausgestattet.
<G-vec00520-002-s630><depend.sich_verlassen><en> They depend solely on their intuition and taste in art. “We buy only what we like.
<G-vec00520-002-s630><depend.sich_verlassen><de> Dabei verlassen sich der Nussdorfer und die US-Amerikanerin ganz auf ihre Intuition und ihren Geschmack: „Wir kaufen nur, was uns gefällt.
<G-vec00520-002-s598><depend.verlassen><en> “ The cooperation with Sabine Haller and her team is always very professional and we can always depend on the dependability and punctuality of the team.
<G-vec00520-002-s598><depend.verlassen><de> “ Die Zusammenarbeit mit dem Team rund um Sabine Haller ist immer sehr professionell und wir können uns immer auf die Zuverlässigkeit und Pünktlichkeit des Teams verlassen.
<G-vec00520-002-s599><depend.verlassen><en> This gives our clients the reassurance that they can depend on our excellent expertise in tax law and criminal tax law at all times.
<G-vec00520-002-s599><depend.verlassen><de> So können unsere Mandanten sicher sein, dass sie sich jederzeit auf unsere ausgezeichnete Expertise im Steuerrecht und Steuerstrafrecht verlassen können.
<G-vec00520-002-s600><depend.verlassen><en> Resist the urge to depend on him materially.
<G-vec00520-002-s600><depend.verlassen><de> Widerstehe dem Drang, dich auf ihn materiell verlassen zu wollen.
<G-vec00520-002-s601><depend.verlassen><en> The advantage of this is that it is steady income that we can depend on and we REALLY need this.
<G-vec00520-002-s601><depend.verlassen><de> Der Vorteil davon ist, dass es ein stetiges Einkommen ist, auf das wir uns verlassen können und wir benötigen dies WIRKLICH.
<G-vec00520-002-s602><depend.verlassen><en> With BusStore - the brand for used vehicles in Europe - our customers can avail themselves of a partner they can depend upon when they buy one of your pre-owned buses and coaches.
<G-vec00520-002-s602><depend.verlassen><de> Mit BusStore - der Marke für Gebrauchtfahrzeuge in Europa - steht unseren Kunden beim Verkauf von Ihren Omnibus-Gebrauchtfahrzeugen ein Partner an der Seite, auf den man sich verlassen kann.
<G-vec00520-002-s603><depend.verlassen><en> The emergency team must be able to depend one hundred percent on the technology.
<G-vec00520-002-s603><depend.verlassen><de> Die Einsatzkräfte müssen sich auf die Technik hundertprozentig verlassen können.
<G-vec00520-002-s604><depend.verlassen><en> Our customers know that they can depend on us to provide them with reliable products in a timely manner.
<G-vec00520-002-s604><depend.verlassen><de> Unsere Kunden wissen genau, dass sie sich auf uns verlassen können, wenn es um die pünktliche Belieferung mit vertrauenswürdigen Produkten geht.
<G-vec00520-002-s605><depend.verlassen><en> We do depend on the happiness from everything except ourselves: this is the real self-sabotage that the mind commente automatically, searching for something that justifying a positive state of mind.
<G-vec00520-002-s605><depend.verlassen><de> Wir haben auf das Glück von allem außer uns selbst verlassen: das ist die eigentliche Selbst-Sabotage, dass der Geist commente automatisch auf der Suche nach etwas, das rechtfertigt einen positiven Zustand des Geistes.
<G-vec00520-002-s606><depend.verlassen><en> When a system manager can see a user's screen he/she will not have to depend on that inexperienced user to determine their exact problem or describe it accurately over the phone.
<G-vec00520-002-s606><depend.verlassen><de> Wenn ein Systemmanager den Bildschirm eines Benutzers sehen kann, muss er sich nicht auf diesen unerfahrenen Benutzer verlassen, um sein genaues Problem zu ermitteln oder es genau über das Telefon zu beschreiben.
<G-vec00520-002-s607><depend.verlassen><en> Sooner or later we will wait for you at the airport so that you can depend on our pick-up service.
<G-vec00520-002-s607><depend.verlassen><de> Demnach werden wir früher oder später am Flughafen auf Sie warten, damit Sie sich auf unseren Abholservice verlassen können.
<G-vec00520-002-s608><depend.verlassen><en> We apply not only our knowledge and production facilities, but can also depend on partners with a complementary product range.
<G-vec00520-002-s608><depend.verlassen><de> Wir setzen nicht nur unser Wissen und unsere Produktionsanlagen ein, wir können uns auch auf Partner mit einem ergänzenden Produktsortiment verlassen.
<G-vec00520-002-s609><depend.verlassen><en> We want to be able to depend on others.
<G-vec00520-002-s609><depend.verlassen><de> Wir wollen uns auf andere verlassen können.
<G-vec00520-002-s610><depend.verlassen><en> * High quality that developers and users alike can depend on for robustness, security, and longevity.
<G-vec00520-002-s610><depend.verlassen><de> Hohe Qualität - damit sich Benutzer und Entwickler auf die Stabilität, Sicherheit und Robustheit verlassen können.
<G-vec00520-002-s611><depend.verlassen><en> Yvonne knows that she can always depend on her sewing machine when working with multiple layers of material or leather.
<G-vec00520-002-s611><depend.verlassen><de> Yvonne weiß, dass sie sich selbst bei mehreren Schichten Stoff oder bei Lederarbeiten immer auf ihre Nähmaschine verlassen kann.
<G-vec00520-002-s612><depend.verlassen><en> For example, one must be able to depend on handoffs and ward visits to occur at fixed times and not subject to unpredictable changes by the chief surgeon/chief physician. Outline
<G-vec00520-002-s612><depend.verlassen><de> Man muss sich beispielsweise verlassen können, dass Übergaben und Visiten zu dem festgesetzten Zeitpunkt stattfinden, und nicht nach den unkalkulierbaren Vorstellungen des Chefarztes/der Chefärztin frei vereinbart werden.
<G-vec00520-002-s613><depend.verlassen><en> It is comforting to know that one can depend on friends during difficult occasions,” said Johannes Bussmann.
<G-vec00520-002-s613><depend.verlassen><de> Es ist gut zu wissen, dass man sich in schweren Zeiten auf seine Freunde verlassen kann“, sagte Johannes Bußmann.
<G-vec00520-002-s614><depend.verlassen><en> Quite simply, we can no longer depend on the seasons.
<G-vec00520-002-s614><depend.verlassen><de> Wir können uns einfach nicht mehr auf die Jahreszeiten verlassen.
<G-vec00520-002-s615><depend.verlassen><en> Aluminium is thus a reliable and long-lasting material on which manufacturers and users can depend.
<G-vec00520-002-s615><depend.verlassen><de> Aluminium ist so ein zuverlässiger und langlebiger Werkstoff, auf den sich die Hersteller und Anwender verlassen können.
<G-vec00520-002-s616><depend.verlassen><en> No, my life has not been easy, but through it all I've learned to trust Jesus and depend upon His Word.
<G-vec00520-002-s616><depend.verlassen><de> Nein, mein Leben war nicht gerade leicht, aber durch alle Schwierigkeiten hindurch habe ich gelernt, Jesus zu vertrauen und mich auf Sein Wort zu verlassen.
<G-vec00520-002-s631><depend.vertrauen><en> 11 ‘Leave your fatherless children; I will keep them alive. Your widows too can depend on me.’ ”
<G-vec00520-002-s631><depend.vertrauen><de> 11 Verlasse deine Waisen, ich werde sie am Leben erhalten; und deine Witwen sollen auf mich vertrauen.
<G-vec00520-002-s632><depend.vertrauen><en> In cases of property and financial damages caused by negligence, the Hotel and its vicarious agents shall only be liable if and when a fundamental contractual obligation been breached, however such liability shall be limited to foreseeable and contractually typical damages when the contract was entered into; fundamental contractual duties being such, the fulfilment of which is substantial to the contract, and on which the customer may depend.
<G-vec00520-002-s632><depend.vertrauen><de> Bei fahrlässig verursachten Sach- und Vermögensschäden haften das Hotel und seine Erfüllungsgehilfen nur bei der Verletzung einer wesentlichen Vertragspflicht, jedoch der Höhe nach beschränkt auf die bei Vertragsschluss vorhersehbaren und vertragstypischen Schäden; wesentliche Vertragspflichten sind solche, deren Erfüllung den Vertrag prägt und auf die der Kunde vertrauen darf.
<G-vec00520-002-s633><depend.vertrauen><en> 49:11 Leave your orphans behind and I will keep them alive. Your widows too can depend on me.”
<G-vec00520-002-s633><depend.vertrauen><de> 11Verlasse deine Waisen, ich werde sie am Leben erhalten; und deine Witwen sollen auf mich vertrauen.
<G-vec00520-002-s634><depend.vertrauen><en> Many business travelers depend on us to provide them with clean, quiet rooms that make it easy to take care of work. Hotels in Calexico, CA are close to numerous top businesses.
<G-vec00520-002-s634><depend.vertrauen><de> Zahlreiche Geschäftsreisende vertrauen uns bei der Suche nach sauberen, ruhigen Zimmern, in denen es sich leicht arbeiten lässt.Hotels in Calexico, CA, liegen in der Nähe zahlreicher bedeutender Unternehmen.
<G-vec00520-002-s635><depend.vertrauen><en> Here, the notion of an essential contractual obligation refers to such obligations of which the fulfilment enables the proper execution of the contract at all and where the customer may ordinarily depend on said fulfilment.
<G-vec00520-002-s635><depend.vertrauen><de> Der Begriff der Kardinalpflicht bezeichnet dabei abstrakt solche Pflichten, deren Erfüllung die ordnungsgemäße Durchführung des Vertrages überhaupt erst ermöglicht und auf deren Einhaltung der Nutzer regelmäßig vertrauen darf.
<G-vec00520-002-s636><depend.vertrauen><en> Designers and manufacturers of cardiovascular devices depend on the quality and reliability of biocompatible polycarbonate resins from Covestro, such as the biocompatible MAKROLON® that is ideal for constructing complex components of blood pumps that circulate oxygenated blood during heart surgery. Further Information
<G-vec00520-002-s636><depend.vertrauen><de> Entwickler und Hersteller kardiovaskulärer Medizingeräte vertrauen auf die Qualität und Verlässlichkeit von biokompatiblen Polycarbonatharzen von Covestro, wie zum Beispiel biokompatiblem MAKROLON®, das sich perfekt für die Herstellung komplexer Komponenten wie Blutpumpen eignet, mit denen während einer Herz-OP mit Sauerstoff angereichertes Blut durch den Organismus gepumpt werden kann .
<G-vec00520-002-s637><depend.vertrauen><en> The design of the rooms was kept subtle and sensitive in order to respect the type of building as well as the patients' subjective perception, who must depend on the competence of the doctor.
<G-vec00520-002-s637><depend.vertrauen><de> Eine zurückhaltende, sensible Gestaltung der Räume berücksichtigt sowohl die Gebäudesituation wie auch das subjektive Empfinden von Patienten, die auf die Kompetenz eines Arztes vertrauen müssen.
<G-vec00520-002-s638><depend.vertrauen><en> Hoshizaki is widely considered to be one of the world’s leading manufacturers of ice machines and is committed to providing an outstanding level of reliability and performance to ensure customers can depend on them season after season, year after year.
<G-vec00520-002-s638><depend.vertrauen><de> Hoshizaki ist als einer der weltweit führenden Hersteller von Eisbereitern anerkannt und bemüht sich, außergewöhnliche Zuverlässigkeit und Leistung zu bieten, um sicherzustellen, dass Kunden Saison für Saison, Jahr für Jahr auf seine Produkte vertrauen können.
