<G-vec00552-002-s038><clear_out.deaktivieren><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00552-002-s038><clear_out.deaktivieren><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00552-002-s039><clear_out.deaktivieren><en> Clear all the IIS Resource Kit Tools and components check boxes except the Metabase Explorer 1.6 check box.
<G-vec00552-002-s039><clear_out.deaktivieren><de> Deaktivieren Sie alle IIS Resource Kit Tools und Komponenten Kontrollkästchen außer dem KontrollkästchenMetabase Explorer 1.6 .
<G-vec00552-002-s040><clear_out.deaktivieren><en> * Word wipe: Clear the board for a Power Point bonus.
<G-vec00552-002-s040><clear_out.deaktivieren><de> * Wort wischen: Deaktivieren Sie das Board für eine Power-Point-Bonus.
<G-vec00552-002-s041><clear_out.deaktivieren><en> All you need is 45,000 points and then clear all the jellies.
<G-vec00552-002-s041><clear_out.deaktivieren><de> Alles, was Sie brauchen, ist 45.000 Punkte und dann deaktivieren Sie alle Gelees.
<G-vec00552-002-s042><clear_out.deaktivieren><en> However if, for example, you want to limit the Objectionable content policy to outbound mail, you can clear all check boxes except Outbound.
<G-vec00552-002-s042><clear_out.deaktivieren><de> Wenn Sie die Einstellung jedoch auf ausgehende E-Mails beschränken möchten, können Sie alle Kontrollkästchen außer "Ausgehend" deaktivieren.
<G-vec00552-002-s043><clear_out.deaktivieren><en> Clear the check boxes for products you do not want to repair.
<G-vec00552-002-s043><clear_out.deaktivieren><de> Deaktivieren Sie Kontrollkästchen für Produkte, die nicht repariert werden sollen.
<G-vec00552-002-s044><clear_out.deaktivieren><en> Clear the check box next to the folder you want to keep off this device.
<G-vec00552-002-s044><clear_out.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen neben dem Ordner, der auf diesem Gerät nicht angezeigt werden soll.
<G-vec00552-002-s045><clear_out.deaktivieren><en> Clear this check box to hide these updates.
<G-vec00552-002-s045><clear_out.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00552-002-s046><clear_out.deaktivieren><en> Open the document library and clear all check marks so no files are selected.
<G-vec00552-002-s046><clear_out.deaktivieren><de> Öffnen Sie die Dokumentbibliothek, und deaktivieren Sie alle Häkchen, sodass keine Dateien ausgewählt sind.
<G-vec00552-002-s047><clear_out.deaktivieren><en> Click to clear the Use Cached Exchange Mode checkbox, click Next, and then click Finish.
<G-vec00552-002-s047><clear_out.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen Exchange-Cache-Modus verwenden, klicken Sie auf Weiterund dann auf Fertig stellenklicken.
<G-vec00552-002-s048><clear_out.deaktivieren><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00552-002-s048><clear_out.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00552-002-s049><clear_out.deaktivieren><en> Clear all eight exciting levels and enjoy the
<G-vec00552-002-s049><clear_out.deaktivieren><de> Deaktivieren Sie alle acht spannende Levels und genießen das Spiel.
<G-vec00552-002-s050><clear_out.deaktivieren><en> Clear the setting that blocks activation.
<G-vec00552-002-s050><clear_out.deaktivieren><de> Deaktivieren Sie die Einstellung, die die Aktivierung blockiert.
<G-vec00552-002-s051><clear_out.deaktivieren><en> Select the Temporary Internet files check box, clear the other check boxes, and then click Delete.
<G-vec00552-002-s051><clear_out.deaktivieren><de> Aktivieren Sie das Kontrollkästchen Temporäre Internetdateien, deaktivieren Sie die übrigen Kontrollkästchen, und klicken Sie auf Löschen.
<G-vec00552-002-s052><clear_out.deaktivieren><en> If you do not want the Connect to MobiLink Server dialog to appear when you start the Monitor without command line options, clear the checkbox beside this option.
<G-vec00552-002-s052><clear_out.deaktivieren><de> Wenn das Fenster Mit dem MobiLink-Server verbinden beim Aufruf des MobiLink-Monitors ohne Befehlszeilenoptionen nicht erscheinen soll, deaktivieren Sie das Kontrollkästchen zu dieser Option.
<G-vec00552-002-s053><clear_out.deaktivieren><en> Eat a grass and clear a level.
<G-vec00552-002-s053><clear_out.deaktivieren><de> Essen Sie alle das Gras und deaktivieren Sie die Ebene.
<G-vec00552-002-s054><clear_out.deaktivieren><en> Clear series of exiting levels and have fun.
<G-vec00552-002-s054><clear_out.deaktivieren><de> Deaktivieren Sie alle Ebenen und gewinnen das Spiel zu.
<G-vec00552-002-s055><clear_out.deaktivieren><en> If you do not want to display table headers, on the Tables tab, under Table Options, clear Header Row.
<G-vec00552-002-s055><clear_out.deaktivieren><de> Hinweis: Wenn Sie keine Tabellenüberschriften anzeigen möchten, können Sie sie später deaktivieren.
<G-vec00552-002-s056><clear_out.deaktivieren><en> Clear the check box to display the docking area at the bottom of the window.
<G-vec00552-002-s056><clear_out.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um den Andockbereich unten im Vegas-Fenster anzuzeigen.
<G-vec00552-002-s399><clear_out.klären><en> While historians in the Weimar Republic worked to clear Germany’s name, others chose their own path.
<G-vec00552-002-s399><clear_out.klären><de> Während Historiker in der Weimarer Republik daran arbeiteten, den Namen Deutschlands zu klären, wählten andere ihren eigenen Weg.
<G-vec00552-002-s400><clear_out.klären><en> I missed being given important back up information that could be explained in English (in less time) to clear up misunderstandings.
<G-vec00552-002-s400><clear_out.klären><de> Leider habe ich wichtige Hintergrundinformationen zum Kursablauf vermisst, die in Englisch (in kürzerer Zeit) hätten erklärt werden können, um Missverständnisse zu klären.
<G-vec00552-002-s401><clear_out.klären><en> And that is my message through this clear channel, who sits in this chair before you.
<G-vec00552-002-s401><clear_out.klären><de> Und das ist die Botschaft durch diesen klären Kanal, der in diesem Stuhl vor euch sitzt.
<G-vec00552-002-s402><clear_out.klären><en> The last day you rise early and clear out your cabin.
<G-vec00552-002-s402><clear_out.klären><de> Am letzten Tag stehen Sie früh auf und klären Ihre Kabine aus.
<G-vec00552-002-s403><clear_out.klären><en> David Marcus, the current Facebook Blockchain chain recently wrote a blog article that sort to defend and clear the air about Libra and complaints that the company has too much control over it.
<G-vec00552-002-s403><clear_out.klären><de> David Marcus, die aktuelle Facebook-Blockchain-Kette, hat kürzlich einen Blog-Artikel geschrieben, der die Luft über die Waage verteidigen und klären soll, und sich darüber beschwert, dass das Unternehmen zu viel Kontrolle darüber hat.
<G-vec00552-002-s404><clear_out.klären><en> The benefits of these courses for you will be to: Get clear on what you want for your health, relationships, money issues, work, other areas or life in general
<G-vec00552-002-s404><clear_out.klären><de> Sie klären für sich, was Sie für Ihre Gesundheit, Ihre Beziehungen, Ihre Arbeit, Ihre Lebensfreude und andere Bereiche Ihres Lebens erreichen wollen.
<G-vec00552-002-s405><clear_out.klären><en> Hope, we are able to clear at least some of them.
<G-vec00552-002-s405><clear_out.klären><de> Hoffe, wir können zumindest einige von ihnen klären.
<G-vec00552-002-s406><clear_out.klären><en> It helps us order our thoughts, clear our feelings, harmonize our body and expand our consciousness.
<G-vec00552-002-s406><clear_out.klären><de> Sie hilft, unsere Gedanken zu ordnen, unsere Gefühle zu klären, den Körper zu harmonisieren und unsere Bewusstheit auszudehnen.
<G-vec00552-002-s407><clear_out.klären><en> EU Commissioners Clear the Enigma: Muslim Immigrants for Muslim Support to Superpower Status Acc. to The Lisbon Treaty.
<G-vec00552-002-s407><clear_out.klären><de> EU Kommissare Klären Das Rätsel: Muslimische Zuwanderer Für Muslimische Stütze Für Supermachtstatus Supermagtsstatus I.h.t.
<G-vec00552-002-s408><clear_out.klären><en> AntiSpy is designed to clear the history of your activities on a PC.
<G-vec00552-002-s408><clear_out.klären><de> Antispion wird entworfen, um die Geschichte von Ihren Tätigkeiten auf einem PC zu klären.
<G-vec00552-002-s409><clear_out.klären><en> As far as to us this is known, we clear up the users about that.
<G-vec00552-002-s409><clear_out.klären><de> Soweit uns dies bekannt ist, klären wir die Nutzer darüber auf.
<G-vec00552-002-s410><clear_out.klären><en> Not only is it essential to clear our energy field of undesirable energy, but it's essential to replace that cleared energy with something of a higher vibration, otherwise, we'll attract the same old patterns again.
<G-vec00552-002-s410><clear_out.klären><de> Nicht nur ist es essentiell unser Enrgiefeld von unerwünschter Energie zu klären, jedoch ist es auch essentiell die geklärete Enerie mit etwas mit einer höheren Schwingung zu ersetzen, ansonsten werden dieselben alten Muster wieder angezogen.
<G-vec00552-002-s411><clear_out.klären><en> As each of you works to clear yourself of all that does not match the highest frequency so to is the collective.
<G-vec00552-002-s411><clear_out.klären><de> Indem jede/r von euch daran arbeitet, sich von allem zu klären, was nicht der höchsten Frequenz entspricht, tut es auch das Kollektiv.
<G-vec00552-002-s412><clear_out.klären><en> If these methods don't help your acne, there are still other treatments, including lasers, light treatments, microdermabrasion, or chemical peels to help clear your skin.
<G-vec00552-002-s412><clear_out.klären><de> Falls diese Methoden nicht gegen deine Akne helfen, gibt es noch andere Behandlungen (einschließlich Laser, Lichtbehandlungen, Mikrodermabrasion oder chemischer Peelings), die dabei helfen, deine Haut zu klären.
<G-vec00552-002-s413><clear_out.klären><en> If you have already decided your trip or you are thinking about it, we will clear up all your doubts.
<G-vec00552-002-s413><clear_out.klären><de> Wenn Sie Ihre Reise bereits entschieden haben oder darüber nachdenken, klären wir alle Ihre Zweifel auf.
<G-vec00552-002-s414><clear_out.klären><en> The picture for third quarter GDP growth in the US is starting to clear up.
<G-vec00552-002-s414><clear_out.klären><de> Das Bild für das BIP-Wachstum im dritten Quartal in den USA beginnt sich auch zu klären.
<G-vec00552-002-s415><clear_out.klären><en> However, not all the stories are true and there’s a lot of hot air being circulated, so here we clear up some of the myths…
<G-vec00552-002-s415><clear_out.klären><de> Allerdings sind nicht alle Geschichten wahr und es gibt eine Menge heiße Luft, darum klären wir hier einige der Mythen auf...
<G-vec00552-002-s416><clear_out.klären><en> There is only one question left to clear up, and that is the ninth planet’s name.
<G-vec00552-002-s416><clear_out.klären><de> Bleibt nur noch eine Frage zu klären, und zwar die des Namens.
<G-vec00552-002-s417><clear_out.klären><en> Obviously we still need to clear up that whole issue of new traffic regulations and hovering signs in the stratosphere.
<G-vec00552-002-s417><clear_out.klären><de> Zu klären wäre dann noch die Sache mit der Straßenverkehrsordnung und den schwebenden Verkehrsschildern in der Stratosphäre.
<G-vec00552-002-s475><clear_out.löschen><en> To clear the New Shortcut Key input field, press any of the control keys, Ctrl, Alt, or Shift.
<G-vec00552-002-s475><clear_out.löschen><de> Um die Eingabe im Feld "Tastaturkürzel drücken" zu löschen, drücken Sie eine der Tasten Strg, Alt oder Umschalt.
<G-vec00552-002-s476><clear_out.löschen><en> Expand Settings and select the check box next to Clear update cache.
<G-vec00552-002-s476><clear_out.löschen><de> Erweitern Sie Einstellungen und aktivieren Sie das Kontrollkästchen neben Update-Cache löschen.
<G-vec00552-002-s477><clear_out.löschen><en> However, you can clear the results in the Output Pane.
<G-vec00552-002-s477><clear_out.löschen><de> Sie können jedoch die Ergebnisse im Ausgabebereich löschen.
<G-vec00552-002-s478><clear_out.löschen><en> This is an amazing action game.One man army in war as a frontline commando...You are appointed as an sniper shooter, your mission is to clear the small enemy unit that will try to protect the city.You are equipped with a modern sniper...
<G-vec00552-002-s478><clear_out.löschen><de> Das ist ein erstaunliches Action-Spiel.Ein Mann Armee im Krieg als Frontline-Kommando...Sie werden als Scharfschützen-Shooter ernannt, Ihre Mission ist es, die kleine feindliche Einheit zu löschen, die versuchen wird, die Stadt zu schützen.Sie sind mit einer...
<G-vec00552-002-s479><clear_out.löschen><en> Clear your Internet tracks, sweep away temporary files you may have downloaded, and hide which programs you have recently used.
<G-vec00552-002-s479><clear_out.löschen><de> Löschen Sie Ihre Internet-Spuren, wegfegen temporäre Dateien, die Sie heruntergeladen haben, und verstecken sich, welche Programme Sie in letzter Zeit verwendet haben.
<G-vec00552-002-s480><clear_out.löschen><en> Solution 3: Clear the system cache Press the Guide button on your controller. Go to Settings and select System Settings.
<G-vec00552-002-s480><clear_out.löschen><de> Löschen des Systemcaches Drücken Sie auf dem Controller die Guide-Taste, wechseln Sie zu den "Einstellungen", und wählen Sie "Systemeinstellungen" aus.
<G-vec00552-002-s481><clear_out.löschen><en> Tap "Privacy" and then "Clear personal data".
<G-vec00552-002-s481><clear_out.löschen><de> Tippen Sie auf "Datenschutz" und dann auf "Persönliche Daten löschen".
<G-vec00552-002-s482><clear_out.löschen><en> To clear your history and cookies, go to Settings > Safari, and tap Clear History and Website Data.
<G-vec00552-002-s482><clear_out.löschen><de> Um den Verlauf und Cookies zu löschen, gehen Sie zu "Einstellungen" > "Safari", und tippen Sie auf "Verlauf und Websitedaten löschen".
<G-vec00552-002-s484><clear_out.löschen><en> In order to clear the data being stored by the border concepts GmbH, you can turn to the border concepts GmbH (dataprivacy(at)borderconcepts.biz) at any time.
<G-vec00552-002-s484><clear_out.löschen><de> Zum Löschen der von der border concepts GmbH gespeicherten Daten können Sie sich jederzeit an die border concepts GmbH wenden (datenschutz(at)borderconcepts.biz).
<G-vec00552-002-s485><clear_out.löschen><en> You can also clear formatting.
<G-vec00552-002-s485><clear_out.löschen><de> Sie können auch die Formatierung löschen.
<G-vec00552-002-s486><clear_out.löschen><en> To clear the operational indicators, press ON SCREEN twice.
<G-vec00552-002-s486><clear_out.löschen><de> Um die Betriebsanzeigen zu löschen, drücken Sie zweimal auf ON SCREEN.
<G-vec00552-002-s487><clear_out.löschen><en> First of all, you need to clear the file from cuts and possible rust.
<G-vec00552-002-s487><clear_out.löschen><de> Zunächst einmal müssen Sie die Datei aus Kürzungen und möglichem Rost löschen.
<G-vec00552-002-s488><clear_out.löschen><en> If you want to clear the text you entered, click the button [Clear].
<G-vec00552-002-s488><clear_out.löschen><de> Wollen Sie den eingegebenen Text wieder löschen, klicken Sie auf die Schaltfläche [Löschen].
<G-vec00552-002-s490><clear_out.löschen><en> Copy the rule, "Clear categories on mail."
<G-vec00552-002-s490><clear_out.löschen><de> Kopiere die Regel "Kategorie aus Mail löschen".
<G-vec00552-002-s491><clear_out.löschen><en> Clear passwords: Deletes any previously stored user names or passwords.
<G-vec00552-002-s491><clear_out.löschen><de> Kennwörter löschen: Löscht gespeicherte Kennwörter.
<G-vec00552-002-s492><clear_out.löschen><en> Match colors vertically to clear them.
<G-vec00552-002-s492><clear_out.löschen><de> Spiel Farben vertikal um sie zu löschen.
<G-vec00552-002-s493><clear_out.löschen><en> Here you will find options related to displaying recent searches or if you care to clear all of them when exiting the browser.
<G-vec00552-002-s493><clear_out.löschen><de> Hier finden Sie Optionen, um die Anzeige der aktuellen Suchanfragen zu ändern oder um alle zu löschen, wenn Sie den Browser schließen.
