<G-vec00484-002-s076><convict.aufdecken><en> And when he comes he will convict the world in regard to sin and righteousness and condemnation: sin, because they do not believe in me; righteousness, because I am going to the Father and you will no longer see me; condemnation, because the ruler of this world has been condemned."
<G-vec00484-002-s076><convict.aufdecken><de> Und wenn er kommt, wird er die Welt überführen und aufdecken, was Sünde, Gerechtigkeit und Gericht ist; Sünde: dass sie nicht an mich glauben; Gerechtigkeit: dass ich zum Vater gehe und ihr mich nicht mehr seht; Gericht: dass der Herrscher dieser Welt gerichtet ist.
<G-vec00484-002-s052><convict.fällen><en> The Court cannot convict for more items than the Prosecutor requested.
<G-vec00484-002-s052><convict.fällen><de> Das Gericht kann kein Urteil fällen für mehr Punkte als die, die der Staatsanwalt beantragt hat.
<G-vec00484-002-s061><convict.verurteilen><en> Therefore it is possible that the innocent convict John received a vision of God’s judgment that is fulfilled continually over all times.
<G-vec00484-002-s061><convict.verurteilen><de> So könnte es sein, dass der unschuldig Verurteilte Johannes, eine Sicht von Gottes Gericht bekam, die sich fortwährend über alle Zeiten erfüllt.
<G-vec00484-002-s078><convict.überführen><en> You, convict people of sin, righteousness and judgment, through God’s spirit in you.
<G-vec00484-002-s078><convict.überführen><de> Du überführst die Leute von Sünde, Gerechtigkeit und Gericht.
<G-vec00484-002-s079><convict.überzeugen><en> Call upon God to convict you so deeply that you can say, “My sin is ever before me” (Psalm 51:3).
<G-vec00484-002-s079><convict.überzeugen><de> Rufe zu Gott, dich so zu überzeugen, daß du sagen kannst, “Meine Sünde ist immer vor mir.” (Ps.
<G-vec00484-002-s080><convict.überzeugen><en> To convict them of the sin of rejecting Jesus.
<G-vec00484-002-s080><convict.überzeugen><de> Sie der Sünde, Jesum zu verwerfen, zu überzeugen.
<G-vec00484-002-s081><convict.überzeugen><en> That the ministry of the Holy Spirit is to glorify the Lord Jesus Christ and, during this age, to convict men, regenerate the believing sinner, and indwell, guide, instruct and empower the believer for godly living and service.
<G-vec00484-002-s081><convict.überzeugen><de> Der Heilige Geist ist eine Person der Gottheit, gesandt, um in dem Gläubigen zu wohnen, ihn zu führen, zu lehren und zu stärken, und die Welt von dem was Sünde, Gerechtigkeit und Gericht ist, zu überzeugen.
<G-vec00541-002-s054><convict.verurteilen><en> Furthermore, a prison sentence of between three months and three years may be imposed; if the convict does not hold Syrian citizenship, prison is mandatory.
<G-vec00541-002-s054><convict.verurteilen><de> Daneben ist die Verhängung einer Freiheitsstrafe von drei Monaten bis zu drei Jahren möglich; Besitzt der Verurteilte nicht die syrische Staatsangehörigkeit, ist die Haft obligatorisch.
