<EnglishT-wsj_1019-s27#EnglishT-wsj_1019-s27-t9><ev-w1173f1.v-w2071f1> Similarly, the Big Board hopes <start_vauxs>to<end_vauxs> <start_vs>entice<end_vs> Merrill Lynch&Co. 
<EnglishT-wsj_1642-s16#EnglishT-wsj_1642-s16-t24><ev-w1173f1.v-w5177f2> But there was a dearth of sellers, traders said , so buyers had to bid prices up <start_vauxs>to<end_vauxs> <start_vs>entice<end_vs> them. 
