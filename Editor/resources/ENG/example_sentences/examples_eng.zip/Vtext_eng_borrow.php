<G-vec00505-001-s023><borrow.aufnehmen><en> Eurobonds could be created to fund industrial policy; a new European Public Investment Bank could borrow funds directly from the ECB; the ECB could directly provide funds for industrial policy.
<G-vec00505-001-s023><borrow.aufnehmen><de> Es könnten Eurobonds zur Finanzierung der Industriepolitik aufgelegt werden; eine neue Europäische Öffentliche Investitionsbank könnte direkt bei der EZB Geld aufnehmen; die EZB könnte direkt Gelder fÃ1⁄4r die Industriepolitik bereitstellen.
<G-vec00505-001-s024><borrow.aufnehmen><en> In 2014, the Bank plans to borrow EUR 70bn.
<G-vec00505-001-s024><borrow.aufnehmen><de> 2014 will die Bank 70Milliarden Euro aufnehmen.
<G-vec00505-001-s025><borrow.aufnehmen><en> The EIB has an AAA credit rating and, therefore, is able to borrow funds at keen terms in international capital markets.
<G-vec00505-001-s025><borrow.aufnehmen><de> Die EIB verfügt über ein AAA-Rating und kann daher auf den internationalen Kapitalmärkten Mittel zu hervorragenden Bedingungen aufnehmen.
<G-vec00505-001-s026><borrow.aufnehmen><en> "In addition, the proceeds from the transaction ensure Schaltbau""s ability to finance loan repayments due at the end of February without needing to borrow new funds."
<G-vec00505-001-s026><borrow.aufnehmen><de> Zudem stellt Schaltbau mit den Erlösen aus der Transaktion die Finanzierung der Ende Februar anstehenden Kreditrückführungen sicher, ohne neue Fremdmittel aufnehmen zu müssen.
<G-vec00505-001-s027><borrow.aufnehmen><en> The partner banks are also contributing to the financing which will enable schools to borrow a total of EUR 600m.
<G-vec00505-001-s027><borrow.aufnehmen><de> Die Partnerbanken tragen ebenfalls zur Finanzierung bei, so dass die Schulen insgesamt 600Mio EUR aufnehmen können.
<G-vec00505-001-s028><borrow.aufnehmen><en> Thanks to its Statute and shareholders (the 27 Member States, including Romania), the EIB has a AAA rating and can therefore borrow funds on the capital markets on favourable terms, which it passes on via the loans that it grants to its customers and final beneficiaries.
<G-vec00505-001-s028><borrow.aufnehmen><de> Aufgrund ihrer Satzung und ihrer Anteilseigner – die 27 Mitgliedstaaten, darunter Rumänien – verfügt die EIB über ein AAA-Rating und kann daher an den Kapitalmärkten Mittel zu günstigen Konditionen aufnehmen, die sie über Darlehen an ihre Kunden und Endbegünstigten weitergibt.
<G-vec00505-001-s032><borrow.ausborgen><en> After a short, five-minute car ride (there are also bicycles and e-bikes available to borrow for more athletically inclined guests), we had already arrived at the shores of Lake Garda.
<G-vec00505-001-s032><borrow.ausborgen><de> Nach einer kurzen, fünfminütigen Autofahrt (für sportlichere Gäste gibt es auch Fahrräder und E-Bikes zum Ausborgen) waren wir auch schon am Ufer des Gardasees.
<G-vec00505-001-s033><borrow.ausborgen><en> Do not forget to sign in: Only by signing in to the catalog, you will see, if and for how long you can borrow a book.
<G-vec00505-001-s033><borrow.ausborgen><de> Anmelden nicht vergessen: Melden Sie sich beim WU-Katalog an, um zu sehen, wie lange Sie ein Buch ausborgen dürfen.
<G-vec00505-001-s034><borrow.ausborgen><en> "In addition, Stockley Park employees are able to borrow a fully equipped bicycle for free under the ""Borrow a Bike"" scheme."
<G-vec00505-001-s034><borrow.ausborgen><de> "Darüber hinaus können Beschäftigte der Stockley Park Gruppe im Rahmen des ""Borrow a Bike"" Systems kostenlos ein voll ausgerüstetes Fahrrad ausborgen."
<G-vec00505-001-s035><borrow.ausborgen><en> Whereas the ratings of Pakistan's bonds in 1999 were below the investment grade they rose in 2006 to better than the B level and Pakistan's country risk premium dropped to 2 percent; i.e., Pakistan could borrow at a rate only 2 percent higher than the interest rate on U.S. government bonds.
<G-vec00505-001-s035><borrow.ausborgen><de> Während die Bewertungen von Pakistans Bindungen in 1999 unterhalb der Versicherungsklassifizierung waren, stiegen sie 2006, um als die b-Niveau- und Pakistans Länderrisikoprämie zu verbessern, die zu 2 Prozent fallen gelassen wurde; d.h. Pakistan konnte mit einer Rate nur 2 Prozent höher als der Zinssatz auf US-Staatsanleihen ausborgen.
<G-vec00505-001-s036><borrow.ausborgen><en> The amount you can borrow for your pay day loans really depends on how much you would like or need, anywhere from three hundred dollars to one thousand dollars.
<G-vec00505-001-s036><borrow.ausborgen><de> Die Menge, die Sie für Ihre Abrechnungstagdarlehen ausborgen können, hängt wirklich von, wie viel Sie würden möchten oder benötigen, überall von drei hundert Dollar bis tausend Dollar ab.
<G-vec00505-001-s037><borrow.ausborgen><en> On the way out of the city we stop an oncoming Minibus, because we are still missing the most important thing: the MP3 player, which we borrow for the trip.
<G-vec00505-001-s037><borrow.ausborgen><de> Auf dem Weg aus der Stadt halten wir einen entgegenkommenden Minibus auf, uns fehlt nämlich noch das wichtigste: der MP3-Player, den wir uns für die Fahrt ausborgen.
<G-vec00505-001-s038><borrow.ausleihen><en> There is a selection of reading materials (both unabridged literature and abridged stories) and DVDs that the students may borrow.
<G-vec00505-001-s038><borrow.ausleihen><de> Eine Auswahl an Lesematerial (sowohl authentische Literatur als auch Kurzgeschichten) und DVDs kann von den Studenten ausgeliehen werden.
<G-vec00505-001-s039><borrow.ausleihen><en> When I had my “brand eins”, I let some other people borrow it.
<G-vec00505-001-s039><borrow.ausleihen><de> Wie ich dann mein brand eins wieder hatte, habe ich es ein paar Mal ausgeliehen.
<G-vec00505-001-s040><borrow.ausleihen><en> The handheld video games devices are gone these days, but they have access to the tablets and cell phones and use it independently whether they have their own or they used to borrow from parents, mobile phones are in particular.
<G-vec00505-001-s040><borrow.ausleihen><de> Die handgehaltenen Videospielgeräte sind heutzutage weg, aber sie haben Zugang zu den Tablets und Handys und nutzen sie unabhängig davon, ob sie ihre eigenen haben oder sie von Eltern ausgeliehen haben, insbesondere Mobiltelefone.
<G-vec00505-001-s041><borrow.ausleihen><en> We have fitted out a laundry area, including washing machines, a tumble dryer and an ironing board (it is possible to borrow an iron at reception).
<G-vec00505-001-s041><borrow.ausleihen><de> Wir haben einen Waschraum mit Waschmaschinen, einem Trockner und einem Bügelbrett ausgestattet (Bügeleisen kann an der Rezeption ausgeliehen werden).
<G-vec00505-001-s042><borrow.ausleihen><en> In this case it is not possible to borrow books for home loan.
<G-vec00505-001-s042><borrow.ausleihen><de> Eine Ausleihe außer Haus ist in diesem Fall nicht möglich.
<G-vec00505-001-s043><borrow.ausleihen><en> They believed that samouglublennaya Asia is seeking to borrow from Europe to boost physical, real activity, but it is virtually impossible to achieve the mechanical transfer of capitalism in the Asian, non-European in general, the soil.
<G-vec00505-001-s043><borrow.ausleihen><de> Sie glaubten, dass samouglublennaya Asien ist es, eine Ausleihe aus Europa zur Förderung der körperlichen, real, aber es ist praktisch unmöglich, die mechanische Übertragung des Kapitalismus in den asiatischen, Nicht-EU im Allgemeinen, die Erde.
<G-vec00505-001-s044><borrow.ausleihen><en> If you have a 401(k) account, it can be very tempting to borrow from your account especially when your balance is very high and a loan could easily pay off existing debt, fund a home purchase, or pay for college tuition.
<G-vec00505-001-s044><borrow.ausleihen><de> Wenn Sie einen 401 (k)-Konto, kann es sehr verlockend, Ausleihe von Ihrem Konto vor allem, wenn Ihr Kontostand ist sehr hoch und könnte leicht ein Darlehen auszahlen bestehenden Schulden, Fonds ein Haus kaufen, oder der Preis für Hochschule Studiengebühren.
<G-vec00505-001-s045><borrow.ausleihen><en> In order to borrow the stage you will need to deposit of 200 Euro in cash.
<G-vec00505-001-s045><borrow.ausleihen><de> Für die Ausleihe der Bühne wird eine Kautionshinterlegung von 200 Euro in bar erforderlich.
<G-vec00505-001-s046><borrow.ausleihen><en> To help us calculate the cost of paying the piper we will borrow from the math of physics.
<G-vec00505-001-s046><borrow.ausleihen><de> Damit wir berechnen die Kosten für die Zahlung der Piper wir Ausleihe aus der mathematischen Physik.
<G-vec00505-001-s047><borrow.ausleihen><en> You need a library card of the ZB MED to borrow these holdings.
<G-vec00505-001-s047><borrow.ausleihen><de> Für die Ausleihe dieser Bestände benötigen Sie einen Bibliotheksausweis der ZB MED.
<G-vec00505-001-s048><borrow.ausleihen><en> 2007-11-13 22:16:19 - Establishing credit? what you need to know part 1 Establishing credit is one of the most important things you can do in order to add stability to your financial record and dramatically increase your ability to borrow necessary funds in order to purchase a new home, new car or even pay for college expenses.
<G-vec00505-001-s048><borrow.ausleihen><de> Was Sie wissen müssen, Teil 1 Kredit zur Gründung eines der wichtigsten Dinge, die Sie tun können, um, um Ihre finanzielle Stabilität zu erfassen und drastisch erhöhen Ihre Fähigkeit zur Ausleihe notwendigen Mittel, um ein neues Zuhause, neue Auto oder selbst bezahlen Hochschule Aufwendungen.
<G-vec00505-001-s049><borrow.ausleihen><en> Another difficulty was to find a wheelchair to borrow in order to develop and run tests under real conditions.
<G-vec00505-001-s049><borrow.ausleihen><de> Eine weitere Schwierigkeit bestand darin, einen elektrischen Rollstuhl zur Ausleihe zu erhalten, um Entwicklungen und Tests unter reellen Bedingungen durchführen zu können.
<G-vec00505-001-s050><borrow.ausleihen><en> Please present your library card when you wish to borrow an item.
<G-vec00505-001-s050><borrow.ausleihen><de> Zur Ausleihe legen Sie bitte Ihren Benutzungsausweis vor.
<G-vec00505-001-s051><borrow.ausleihen><en> Users must be registered with a NEBIS library to borrow any media.
<G-vec00505-001-s051><borrow.ausleihen><de> Voraussetzung für die Ausleihe ist dieEinschreibungals Benutzer/in in einer NEBIS Bibliothek.
<G-vec00505-001-s052><borrow.ausleihen><en> Borrowing of Technical Equipment The ZHdK allows students and employees to borrow an extensive range of equipment.
<G-vec00505-001-s052><borrow.ausleihen><de> Ausleihe von technischem Material Die ZHdK bietet für Studierende und Mitarbeitende einen umfangreichen Gerätepark zur Ausleihe an.
<G-vec00505-001-s053><borrow.ausleihen><en> All other persons can purchase a membership of the Zurich Art Society, which entitles for one year not only to borrow items from the library but also to visit all exhibitions in the Kunsthaus Zürich as often as one pleases.Registration implies acceptance of the library's user regulations as well as the fees and charges.
<G-vec00505-001-s053><borrow.ausleihen><de> Alle anderen Personen können eine Mitgliedschaft der Zürcher Kunstgesellschaft erwerben, mit der man neben der Ausleihe ein Jahr lang auch alle Ausstellungen im Kunsthaus beliebig oft besuchen kann.Mit der Anmeldung anerkennt der/die Benutzer/in die Benutzungs - und die Gebührenordnung .
<G-vec00505-001-s054><borrow.ausleihen><en> In this case it is not possible to borrow books and media for home loan.
<G-vec00505-001-s054><borrow.ausleihen><de> Eine Ausleihe nach Hause ist in diesem Fall nicht möglich.
<G-vec00505-001-s055><borrow.ausleihen><en> Borrow it in Happy Mask Shop at Market after you sold the Spooky Mask, and sell it at night to the guy running around south of Lon Lon Ranch after you are done with Lord Jabu Jabu.
<G-vec00505-001-s055><borrow.ausleihen><de> Beim Maskenhändler auf dem Marktplatz ausleihen, nachdem du die Geister-Maske verkauft hast, und verkaufen an den Typ der nachts südlich der Lon Lon-Farm herum läuft, nachdem du mit Lord Jabu Jabu fertig bist.
<G-vec00505-001-s056><borrow.ausleihen><en> Because... we provide the best support to our guests in order to make it easier to visit Rome and to discover the Etruscan, Roman and Christian culture of Latium: you can get maps and tourist information in your own language; borrow books in different languages; benefit of multi-medial services;choose concerts and exhibitions from our updated lists; have reservations for entrance in museums and art galleries.
<G-vec00505-001-s056><borrow.ausleihen><de> Weil... wir unseren Gsten beste Untersttzung anbieten, um die Stadt Rom besichtigen zu knnen und die Kultur der Etrusker, Rmer und Christen in Latium zu entdecken: Sie knnen Landkarten und Touristeninformationen in Ihrer eigenen Sprache erhalten; Bcher in verschiedenen Sprachen ausleihen; multimediale Dienstleistungen nutzen; whlen Sie Konzerte und Ausstellungen von unseren aktualisierten Listen; Eintrittsreservierungen fr Museen und Kunstgalerieen.
<G-vec00505-001-s057><borrow.ausleihen><en> Organizing funds for personal causes from external sources might be easy but the same task becomes more difficult when it comes to borrow money for commercial or business purpose.
<G-vec00505-001-s057><borrow.ausleihen><de> Organizing Mittel für den persönlichen Ursachen von externen Quellen können einfach sein, aber die gleiche Aufgabe wird schwieriger, wenn es um Geld für kommerzielle oder geschäftliche Zwecke ausleihen kommt.
<G-vec00505-001-s058><borrow.ausleihen><en> You can also borrow life jackets, wetsuits, spray decks, paddle floats, pumps and various paddles.
<G-vec00505-001-s058><borrow.ausleihen><de> Sie können außerdem Schwimmwesten, Neoprenanzüge, Spritzdecken, Paddle Floats, Pumpen und verschiedene Paddel ausleihen.
<G-vec00505-001-s059><borrow.ausleihen><en> Students can borrow books from the library or purchase their own books.
<G-vec00505-001-s059><borrow.ausleihen><de> Die Schüler können Bücher aus der Bibliothek ausleihen oder ihre eigenen Bücher kaufen.
<G-vec00505-001-s060><borrow.ausleihen><en> We have tiptoi books in our Preschool library, which you can borrow anytime (opening hours: Mondays and Thursdays from 1:45pm to 4pm).
<G-vec00505-001-s060><borrow.ausleihen><de> wir haben in unserer Kindergartenbücherei tiptoi-Bücher, die sie sich gerne ausleihen können (Öffnungszeiten: montags und donnerstags von 13:45 bis16:00 Uhr).
<G-vec00505-001-s061><borrow.ausleihen><en> You are only a few metersaway from the reception and the Ranch.All rooms are wheelchair accessible, have over aluminum windows with mosquito netting, ceramic floors,110V/60 Hz power outlets, clothesline, hammock, covered patio, garden furniture, stairs and look forSapoa flow as well as private parking.In the small library next to the ranch, there are books to borrow and swap, time-killersand information for onward journey.On the hills, offers a magnificent view of the Orosi Volcano (Costa Rica) and the volcanoConcepcion in the Lago de Nicaragua.
<G-vec00505-001-s061><borrow.ausleihen><de> Sie befinden sich nur wenige Meter von der Reception und dem Rancho entfernt.Sämtliche Unterkünfte sind rollstuhlgängig, verfügen ueber Alufenster mit Moskitoschutzgitter, Keramikböden, Steckdosen 110V/60 Hz, Wäscheleine, Hängematte, gedeckten Sitzplatz, Gartenbestuhlung, Blick und Treppen zum Fluss Sapoa sowie private Parkplätze.In der kleinen Bibliothek neben dem Rancho gibt es Bücher zum Ausleihen und Tauschen, Spiele zum Zeitvertreib und Infos zur Weiterreise.Auf den Hügeln bietet sich eine herrliche Sicht auf den Vulkan Orosi (Costa Rica) und zum Vulkan Concepcion im Lago de Nicaragua.
<G-vec00505-001-s062><borrow.ausleihen><en> This is the fast source to borrow the needful amount to meet the sudden expenses.
<G-vec00505-001-s062><borrow.ausleihen><de> Dies ist die schnelle Quelle bis zur Höhe nötig ausleihen, um den plötzliche Ausgaben.
<G-vec00505-001-s063><borrow.ausleihen><en> If they borrow Grim\'s spell book it\'ll take no time at all however.
<G-vec00505-001-s063><borrow.ausleihen><de> Wenn sie ausleihen Grim 's Zauberbuch es ' ll keine Zeit mehr zu vergehen jedoch.
<G-vec00505-001-s064><borrow.ausleihen><en> Right on the beach, there is a surf school where one can learn to surf or simply borrow a surfboard for an hour.
<G-vec00505-001-s064><borrow.ausleihen><de> Gleich am Strand gibt es eine Surf-Schule, wo man das Windsurfen erlernen oder sich auch nur ein Brett für eine Stunde ausleihen kann.
<G-vec00505-001-s065><borrow.ausleihen><en> Let yourself surprise! You can also borrow our animated puppets and enchanting picture stories.
<G-vec00505-001-s065><borrow.ausleihen><de> Unser Automatenfiguren und traumhaften Bildergeschichten können Sie auch von uns ausleihen.
<G-vec00505-001-s066><borrow.ausleihen><en> A large canoe is available with a small electric motor to borrow.
<G-vec00505-001-s066><borrow.ausleihen><de> Großes Kanu mit kleinem Elektromotor zum Ausleihen.
<G-vec00505-001-s067><borrow.ausleihen><en> You may borrow our canoes for wonderful excursions on the lake.
<G-vec00505-001-s067><borrow.ausleihen><de> Sie können unsere Kanus für herrliche Ausflüge auf dem See ausleihen.
<G-vec00505-001-s068><borrow.ausleihen><en> Barbecue available to borrow and outdoor furniture stands on the porch and in the back, even a cafeset available at the entrance.
<G-vec00505-001-s068><borrow.ausleihen><de> Barbecue zum Ausleihen und Outdoor-Möbel steht auf der Veranda und in dem Rücken, auch einen cafeset am Eingang zur Verfügung.
<G-vec00505-001-s069><borrow.ausleihen><en> Facilities of the complex include a lobby with a fireplace where you can borrow books and board games, a heated indoor pool, and a parking garage.
<G-vec00505-001-s069><borrow.ausleihen><de> Sie finden hier einen Empfangsbereich mit Kamin, wo Sie Bücher und Gesellschaftsspiele ausleihen können, ein beheiztes Hallenbad und eine gebührenpflichtige Tiefgarage.
<G-vec00505-001-s071><borrow.ausleihen><en> Locally you can borrow for a small fee, sun loungers and parasols.
<G-vec00505-001-s071><borrow.ausleihen><de> Vor Ort kann man für eine geringe Gebühr Liegestühle und Sonnenschirme ausleihen.
<G-vec00505-001-s072><borrow.ausleihen><en> Students may borrow up to 5 books over the weekend (from Friday to Monday).
<G-vec00505-001-s072><borrow.ausleihen><de> Studierende können bis zu 5 Bücher über das Wochenende ausleihen (von Freitag auf Montag).
<G-vec00505-001-s073><borrow.ausleihen><en> You can borrow bicycles, golf clubs, cribs and various games.
<G-vec00505-001-s073><borrow.ausleihen><de> Sie können Fahrräder, Golfschläger, Krippen und verschiedene Spiele ausleihen.
<G-vec00505-001-s074><borrow.ausleihen><en> Visitors are welcome to browse; membership is required to borrow books.
<G-vec00505-001-s074><borrow.ausleihen><de> Um Bücher auszuleihen, ist jedoch eine Mitgliedschaft erforderlich.
<G-vec00505-001-s075><borrow.ausleihen><en> If you complete your studies successfully, you will have a lifelong entitlement to borrow media from the FH Vorarlberg library free of charge.
<G-vec00505-001-s075><borrow.ausleihen><de> Sofern Sie Ihr Studium erfolgreich abschließen, sind Sie lebenslang berechtigt, kostenfrei Medien der Bibliothek der FH Vorarlberg auszuleihen.
<G-vec00505-001-s076><borrow.ausleihen><en> The eLibrary is a digital service offered by the Goethe-Institut Yaoundé library for Cameroon which allows you to borrow digital media.
<G-vec00505-001-s076><borrow.ausleihen><de> Die Onleihe ist ein digitales Angebot der Bibliothek des Goethe-Instituts Yaoundé für Kamerun, das Ihnen ermöglicht, digitale Medien auszuleihen.
<G-vec00505-001-s077><borrow.ausleihen><en> eLibrary The eLibrary is a digital service offered by the Goethe-Institut in Africa which allows you to borrow digital media.
<G-vec00505-001-s077><borrow.ausleihen><de> Die Onleihe ist ein digitales Angebot der Bibliothek der Goethe-Institute in Afrika, das Ihnen ermöglicht, digitale Medien auszuleihen.
<G-vec00505-001-s078><borrow.ausleihen><en> The eLibrary is a digital service offered by the Goethe-Institut Johannesburg library for South Africa which allows you to borrow digital media.
<G-vec00505-001-s078><borrow.ausleihen><de> Die Onleihe ist ein digitales Angebot der Bibliothek des Goethe-Instituts Johannesburg für Südafrika, das Ihnen ermöglicht, digitale Medien auszuleihen.
<G-vec00505-001-s079><borrow.ausleihen><en> "This triple-printing technique also allowed some money to be saved by using it to ""borrow"" the Civil War battle sequences from ""Raintree County"" (Camera 65) and scenes of marching soldiers from ""The Alamo"" (Todd-AO)."
<G-vec00505-001-s079><borrow.ausleihen><de> Diese dreifach-Printing-Technik sparte auch Geld ein, als man sie nutzte, um Bürgerkriegsszenen aus „Raintree County“ (Camera 65) sowie Szenen mit marschierenden Soldaten aus „The Alamo“ (Todd-AO) „auszuleihen“.
<G-vec00505-001-s080><borrow.ausleihen><en> I had 4 library cards for every library within 20 km and I went every Wednesday to my favourite library to read and borrow books.
<G-vec00505-001-s080><borrow.ausleihen><de> Ich hatte 4 Bibliothek Karten für jede Bibliothek im Umkreis von 20 km, und ich ging jeden Mittwoch zu meinen Lieblings-Bibliothek zum Lesen und um Bücher auszuleihen.
<G-vec00505-001-s081><borrow.ausleihen><en> I was sharing a home with seven people when one night I decided to borrow my roommate’s computer.
<G-vec00505-001-s081><borrow.ausleihen><de> Ich teilte mein Heim mit sieben Leuten, als ich mich eines Abends entschloss, den Computer meiner Zimmergenossin auszuleihen.
<G-vec00505-001-s082><borrow.ausleihen><en> For the exhibition we asked artists to borrow the books that they think are of great significance to the local scene to be introduced throughout the course of the exhibition.
<G-vec00505-001-s082><borrow.ausleihen><de> Die Künstlerinnen und Künstler wurden gebeten, Bücher auszuleihen, die sie für ihre lokale Szene für wichtig erachten und die im Rahmen der Ausstellung präsentiert werden.
<G-vec00505-001-s083><borrow.ausleihen><en> It is necessary to stop and... to borrow.
<G-vec00505-001-s083><borrow.ausleihen><de> Nur man braucht, und... stehenzubleiben, auszuleihen.
<G-vec00505-001-s084><borrow.ausleihen><en> Q: (S) Well, I was brought up to not borrow money and to keep all the bills paid first … then if there is anything left over …
<G-vec00505-001-s084><borrow.ausleihen><de> F: (S) Ich wurde so erzogen, kein Geld auszuleihen und meine Rechnungen zuerst zu bezahlen... und dann, wenn noch etwas übrig bleibt...
<G-vec00505-001-s085><borrow.ausleihen><en> TV, DVDs, books to borrow, Free Internet, security cabinets, CCTV, towels, Hair Dryer and parking. from 9.16 USD
<G-vec00505-001-s085><borrow.ausleihen><de> TV, DVDs, Bücher auszuleihen, Freier Internet-, Sicherheits-Schränke, Wäsche-, CCTV, Handtücher, Haartrockner und einen Parkplatz.
<G-vec00505-001-s086><borrow.ausleihen><en> The → festival’s blog was used to locate six households in Morley willing to borrow works from Leeds Art Gallery for the project.
<G-vec00505-001-s086><borrow.ausleihen><de> Für das Festival wurden über den → Festivalblog sechs Haushalte aus Morley gesucht, die bereit waren, Werke aus der Leeds Art Gallery auszuleihen.
<G-vec00505-001-s089><borrow.borgen><en> But to quickly refund, if one cannot support exorbitant monthly payments, that wants to say to borrow less.
<G-vec00505-001-s089><borrow.borgen><de> Aber zu schnell zurückerstatten, wenn man nicht übertriebene Monatszahlungen stützen kann, das sagen möchte, kleiner zu borgen.
<G-vec00505-001-s090><borrow.borgen><en> If no one wants to borrow the funds to make purchases then the availability of funds in the financial institutions is irrelevant.
<G-vec00505-001-s090><borrow.borgen><de> Wenn niemand die Kapital borgen möchte, um Käufe abzuschließen dann, ist die Verwendbarkeit der Kapital in den Finanzinstituten irrelevant.
<G-vec00505-001-s091><borrow.borgen><en> As long as the interest rate is substantially below the profit rate entrepreneurs will presumably borrow and invest until this gap is eliminated.
<G-vec00505-001-s091><borrow.borgen><de> Solange der Zinssatz deutlich unter der Profitrate liegt, werden Unternehmer voraussichtlich borgen und investieren, bis sich diese Lücke schließt.
<G-vec00505-001-s092><borrow.borgen><en> "And the context confirms the right understanding for Jesus continues: ""Give to him who asks of you, and if someone wants to borrow something, don't turn them away."
<G-vec00505-001-s092><borrow.borgen><de> "Und der Zusammenhang bestätigt das richtige Verständnis, denn Jesus fährt fort, indem er sagt: ""Gebt demjenigen der euch bittet und wenn jemand etwas von euch borgen möchte, dann weist ihn nicht ab."
<G-vec00505-001-s093><borrow.borgen><en> "The profound understanding of, ""temperature"" is the key to open the door, no temperature control, will not be able to inspire the unique flavor of chocolate and smooth taste, also won't be able to borrow chocolate offer the confession of love."
<G-vec00505-001-s093><borrow.borgen><de> "Das tiefe Verständnis von ""Temperatur"" ist der Schlüssel, um die Tür zu öffnen, keine Temperaturregelung, wird nicht in der Lage sein, den einzigartigen Geschmack von Schokolade und weichen Geschmack zu inspirieren, wird auch nicht in der Lage sein zu borgen Schokolade bieten das Geständnis der Liebe."
<G-vec00505-001-s094><borrow.borgen><en> The amount of money you borrow is called principal, and interest is the cost for borrowing the money.
<G-vec00505-001-s094><borrow.borgen><de> Die Menge des Geldes, das Sie borgen, wird Direktion genannt, und Interesse ist die Kosten für das Borgen des Geldes.
<G-vec00505-001-s095><borrow.borgen><en> If you are going to borrow the money to finance the expansion of your business, you need to make sure that you are not going to get yourself into a cash crunch situation.
<G-vec00505-001-s095><borrow.borgen><de> Wenn Sie das Geld borgen werden, um die Expansion Ihres Geschäfts zu finanzieren, müssen Sie überprüfen, ob Sie nicht sich in eine Bargeldknirschensituation erhalten werden.
<G-vec00505-001-s096><borrow.borgen><en> The real mortgage will be an instrument to reach that point. Thus, behind the barbarian name of refillable mortgage, Bercy wants to encourage the French to borrow as much as their European neighbors.
<G-vec00505-001-s096><borrow.borgen><de> So hinter dem barbarischen Namen der nachfüllbaren Hypothek, möchte Bercy die Franzosen anregen, ihre europäischen Nachbarn soviel wie zu borgen.
<G-vec00505-001-s097><borrow.borgen><en> They continued to borrow.
<G-vec00505-001-s097><borrow.borgen><de> Sie fuhren fort, zu borgen.
<G-vec00505-001-s098><borrow.borgen><en> "If you are not a Mac user but would like new design al Yosemite system and want to ""borrow"" your system Windows You can download and install third-party theme Swift OS X Yosemite for Windows 7 si Windows 8 / 8.1 ."
<G-vec00505-001-s098><borrow.borgen><de> "Wenn Sie nicht ein Mac-Benutzer, sondern möchte neues Design al Yosemite-System und wollen zu ""borgen"" Ihr System Windows- Sie können herunterladen und installieren Dritter Thema Swift OS X Yosemite für Windows-7 si Windows-8 / 8.1 ."
<G-vec00505-001-s099><borrow.borgen><en> But who would want to borrow to increase capacity in a recession.
<G-vec00505-001-s099><borrow.borgen><de> Aber wer würde borgen wollen, um die Kapazität in einer Rezession zu erhöhen.
<G-vec00505-001-s100><borrow.borgen><en> 2007-11-13 22:16:19 - Secrets & benefits of secured loans Borrowing money has become more and more popular in the UK over recent years, and this is partly due to the fact that it has become far easier to borrow money.
<G-vec00505-001-s100><borrow.borgen><de> 2007-11-13 22:16:19 - Geheimnisse u. Nutzen der gesicherten Darlehen Geld zu borgen ist in Großbritannien seit einigen Jahren immer mehr populär geworden, und dieses liegt an der Tatsache teils, der es weit einfacher geworden ist, Geld zu borgen.
<G-vec00505-001-s101><borrow.borgen><en> We would like to let you know, in case you haven’t heard, that the Mexican Electrical Union (SME) refused to let us, the CNI and the EZLN, borrow one of their facilities for the celebration of cultural events in Mexico City during the First World Festival of Resistance and Rebellion against Capitalism: «Where Those Above Destroy, We Below Rebuild.»
<G-vec00505-001-s101><borrow.borgen><de> Wir weisen darauf hin, denn wir glauben, dass Sie es nicht wissen, dass das Sindicato Mexicano de Electricistas (SME) (= mexikanische Elektrikergewerkschaft) sich geweigert hat, uns, dem CNI und der EZLN, eines ihrer Gebäude im DF zu borgen, damit wir dort den kulturellen Teil des Ersten Weltfestivals der Widerstände und der Rebellionen gegen den Kapitalismus mit dem Titel ´Wo die von oben zerstören, widmen sich die von unten dem Wideraufbau´ abhalten könnten.
<G-vec00505-001-s102><borrow.borgen><en> So the banks will again borrow from Switzerland and send the money again to Switzerland.
<G-vec00505-001-s102><borrow.borgen><de> Also können die Banken wieder von der Schweiz borgen und weiter Geld in die Schweiz schicken.
<G-vec00505-001-s103><borrow.borgen><en> We borrow the securities provided by the lender and pass them on immediately to the borrower.
<G-vec00505-001-s103><borrow.borgen><de> Wir borgen die vom Lender gelieferten Titel, um diese sogleich an den Borrower weiterzureichen.
<G-vec00505-001-s104><borrow.borgen><en> "Therefore you will have to find other ways to give your website the exposure it requires to generate traffic.One way is to "" borrow"" the traffic from existing sites."
<G-vec00505-001-s104><borrow.borgen><de> "Folglich müssen Sie andere Wege finden, Ihrer Web site die Belichtung zu geben, die sie erfordert, um Verkehr zu erzeugen.One-way ist ""borgen"" den Verkehr von vorhandenen Aufstellungsorten."
<G-vec00505-001-s105><borrow.borgen><en> You shall lend to many nations, but you shall not borrow.
<G-vec00505-001-s105><borrow.borgen><de> Und du wirst vielen Völkern leihen; du aber wirst von niemand borgen.
<G-vec00505-001-s106><borrow.borgen><en> They forced the common freemen, overwhelmed by the taxes which they had themselves imposed, to borrow of them, and then, first as their debtors, afterward legally as their serfs, to surrender their liberty.
<G-vec00505-001-s106><borrow.borgen><de> Sie nötigten die Gemeinfreien, die die Steuerlast erdrückte, bei ihnen zu borgen und zuerst tatsächlich als Schuldner, dann rechtlich als Hörige sich ihrer Freiheit zu begeben.
<G-vec00505-001-s107><borrow.borgen><en> They can not save and they can not borrow, and in increasing numbers, they can not work.
<G-vec00505-001-s107><borrow.borgen><de> Sie können nicht anlegen und können nicht borgen, und zunehmend können sie auch nicht mehr arbeiten.
<G-vec00505-001-s108><borrow.borgen><en> 42 Give to the one who asks you, and do not turn away from the one who wants to borrow from you.
<G-vec00505-001-s108><borrow.borgen><de> Mat 5:42 Wer dich bittet, dem gib; wer von dir borgen will, den weise nicht ab.
<G-vec00505-001-s109><borrow.borgen><en> 42 Whoever asks of you, give to him. And if anyone would borrow from you, do not turn away from him.
<G-vec00505-001-s109><borrow.borgen><de> 42 Dem, der dich bittet, gib; wenn einer von dir borgen will, weise ihn nicht ab.
<G-vec00505-001-s117><borrow.leihen><en> I always have extra of these for teaching, and when a schoolmate is bore a student, they borrow one of these and there are no problems.
<G-vec00505-001-s117><borrow.leihen><de> Ich habe immer besonders mit denen, für die Bildung, und wenn eine Schule Maske ein Student neckt, so dass sie leihen einer von ihnen, und so gibt es kein Problem.
<G-vec00505-001-s118><borrow.leihen><en> (Others have made this point, but the banksubsidy can be partially estimatedfrom the yield at which banks can borrow with the implicit too-big-to-fail subsidy versus without it.
<G-vec00505-001-s118><borrow.leihen><de> (Andere haben diesen Punkt gemacht, aber die Bank Zuschuss teilweise geschätzt werden, von der Ausbeute bei dem die Banken können mit der impliziten too-big-to-fail-Subvention gegenüber, ohne dass es zu leihen.
<G-vec00505-001-s119><borrow.borgen><en> Please swallow your pride, if have things you need to borrow.
<G-vec00505-001-s119><borrow.borgen><de> Bitte schlucke deinen Stolz herunter, Sollte ich Sachen haben, die du dir borgen musst.
<G-vec00505-001-s120><borrow.borgen><en> Ask around for une opinion or if a friend has a set of CDs or a program you can borrow.
<G-vec00505-001-s120><borrow.borgen><de> Frage nach une opinion oder ob ein Freund CDs hat, die du dir borgen kannst.
<G-vec00505-001-s123><borrow.ausleihen><en> He wants to borrow some of our cavalry to help him move around the island.
<G-vec00505-001-s123><borrow.ausleihen><de> Er möchte einen Teil unserer Reiterei ausleihen, um sich besser auf der Insel bewegen zu können.
<G-vec00505-001-s124><borrow.ausleihen><en> If you would like to experience the city by yourself, you can borrow our audio guides (Swedish and English).
<G-vec00505-001-s124><borrow.ausleihen><de> Wenn Sie die Stadt auf eigene Faust erkunden möchten, können Sie einen Audioguide ausleihen, der in schwedischer und englischer Sprache erhältlich ist.
<G-vec00505-001-s131><borrow.entlehnen><en> "As a result of squirrels, necessary for synthesis of hormones, the organism will ""borrow"" from muscles therefore weight loss happens due to reduction of amount not of fat, and muscle bulk."
<G-vec00505-001-s131><borrow.entlehnen><de> "Infolge der Eichhörner, notwendig wird für die Synthese der Hormone, der Organismus aus den Muskeln ""entlehnen"", deshalb die Abmagerung geschieht auf Kosten von der Verkleinerung der Zahl nicht des Fettes, und der Muskelmasse."
<G-vec00505-001-s132><borrow.entlehnen><en> 28:12 Yahweh will open to you his good treasure in the sky, to give the rain of your land in its season, and to bless all the work of your hand: and you shall lend to many nations, and you shall not borrow.
<G-vec00505-001-s132><borrow.entlehnen><de> 28:12 Jehova wird dir seinen guten Schatz, den Himmel, auftun, um den Regen deines Landes zu geben zu seiner Zeit, und um alles Werk deiner Hand zu segnen; und du wirst vielen Nationen leihen, du aber wirst nicht entlehnen.
<G-vec00505-001-s133><borrow.entlehnen><en> < 15:6 For Jehovah thy God will bless thee, as he promised thee: and thou shalt lend unto many nations, but thou shalt not borrow; and thou shalt rule over many nations, but they shall not rule over thee.
<G-vec00505-001-s133><borrow.entlehnen><de> < 15:6 Denn Jehova, dein Gott, wird dich segnen, wie er zu dir geredet hat; und du wirst vielen Nationen auf Pfand leihen, du aber wirst nichts auf Pfand entlehnen; und du wirst über viele Nationen herrschen, über dich aber werden sie nicht herrschen.
<G-vec00505-001-s134><borrow.entlehnen><en> In the module designing of metal designs you can borrow the information model of a building created in Revit Structure, to import files cis/2, and also to create models independently.
<G-vec00505-001-s134><borrow.entlehnen><de> Im Baustein der Entwicklung der metallischen Konstruktionen Sie können das informative Modell des Gebäudes, das in Revit Structure erstellt ist entlehnen, die Dateien cis/2 einzuführen, sowie, die Modelle zu erstellen ist selbständig.
<G-vec00505-001-s135><borrow.entlehnen><en> 28:12 Jehovah will open unto thee his good treasure the heavens, to give the rain of thy land in its season, and to bless all the work of thy hand: and thou shalt lend unto many nations, and thou shalt not borrow.
<G-vec00505-001-s135><borrow.entlehnen><de> 28:12 Jehova wird dir seinen guten Schatz, den Himmel, auftun, um den Regen deines Landes zu geben zu seiner Zeit, und um alles Werk deiner Hand zu segnen; und du wirst vielen Nationen leihen, du aber wirst nicht entlehnen.
<G-vec00505-001-s136><borrow.entleihen><en> The library card (UniCard) allows you to borrow items from the University Library or use the interlibrary loan.
<G-vec00505-001-s136><borrow.entleihen><de> Der Bibliotheksausweis (UniCard) berechtigt Sie zum Entleihen von Medien aus der Universitätsbibliothek und zur Aufgabe von Fernleihbestellungen.
<G-vec00505-001-s137><borrow.entleihen><en> "To relegate Racinet to the past would be as false to him as to ""borrow bits and pieces"" from him for utilitarian purposes or even to make him into an authority of a presumably unassailable truth."
<G-vec00505-001-s137><borrow.entleihen><de> Racinet als der Vergangenheit angehörig zu sehen, wäre seinem Beitrag gegenüber ebenso unangebracht, wie daraus für oberflächliche Zwecke Teile zu entleihen oder ihn zu einer Autorität einer angeblich unbezweifelbaren Wahrheit zu erheben.
<G-vec00505-001-s138><borrow.entleihen><en> People who are not members of state universities and academies in Germany may not borrow from the textbook collections.
<G-vec00505-001-s138><borrow.entleihen><de> Personen, die nicht Mitglieder und Angehörige einer Hochschule in Deutschland in staatlicher Trägerschaft sind, können aus den Lehrbuchsammlungen nicht entleihen.
<G-vec00505-001-s139><borrow.entleihen><en> Borrow paintings like you borrow books - a highlight in our library is our art library.
<G-vec00505-001-s139><borrow.entleihen><de> Bilder leihen wie Bücher - Eine Besonderheit in unserer Bücherei ist das Entleihen von Bildern.
<G-vec00505-001-s140><borrow.entleihen><en> You can order articles from printed journals of selected chinese libraries and also borrow books via China Direct .
<G-vec00505-001-s140><borrow.entleihen><de> Über China Direkt können Sie Artikel aus gedruckten Zeitschriften ausgewählter chinesischer Bibliotheken bestellen, sowie Bücher entleihen.
<G-vec00505-001-s141><borrow.entleihen><en> Fifty Fifty (Sharing Community)| From drills to electric pianos, students and co-workers from the University of Basel have the opportunity to loan and borrow all types of objects thanks to Fifty Fifty, an easy-to-use internet platform.
<G-vec00505-001-s141><borrow.entleihen><de> Fifty Fifty (Sharing Community) | Von einer Bohrmaschine zu bis einem Elektropiano, die Studierenden und Angehörigen der Universität Basel können mit Hilfe der Sharingplattform Fifty Fifty alle möglichen Dinge ver- und entleihen.
<G-vec00505-001-s145><borrow.leihen><en> If you need to borrow over the long term but are still planning to carry out other projects in the years to come, fixed rates offer greater stability and predictability.
<G-vec00505-001-s145><borrow.leihen><de> Wenn Sie langfristig Geld leihen und in den folgenden Jahren noch weitere Projekte verwirklichen wollen, bietet Ihnen der feste Zinssatz eine größere Stabilität und Planbarkeit.
<G-vec00505-001-s146><borrow.leihen><en> If interest rates stay low, the government and others can borrow more to build more armaments while keeping taxes relatively low.
<G-vec00505-001-s146><borrow.leihen><de> Wenn der Zinssatz niedrig bleibt, können die Regierung und andere Geld leihen, um die Rüstungsausgaben zu erhöhen und trotzdem die Steuern relativ niedrig zu halten.
<G-vec00505-001-s147><borrow.leihen><en> Moreover, the US has the ability to borrow from the Federal Reserve (FED, equivalent of a central bank).
<G-vec00505-001-s147><borrow.leihen><de> Außerdem steht den USA die Möglichkeit zu, von der Federal Reserve (die einer Zentralbank gleicht) Geld zu leihen.
<G-vec00505-001-s148><borrow.leihen><en> Then we did not borrow any money and we learned how to deal with such a situation.
<G-vec00505-001-s148><borrow.leihen><de> Schon damals haben wir kein Geld geliehen, und wir lernten, wie man mit so einer Lage umgeht.
<G-vec00505-001-s149><borrow.leihen><en> You can very easily hire or borrow bicycles.
<G-vec00505-001-s149><borrow.leihen><de> Fahrräder können ganz leicht geliehen oder gemietet werden.
<G-vec00505-001-s152><borrow.aufnehmen><en> I can borrow up to £ 7,500 on Credit Card 1 and £ 6,000 on Credit Card 2.
<G-vec00505-001-s152><borrow.aufnehmen><de> Ich kann Kredite bis zu £ 7.500 auf der Kreditkarte 1 und £ 6.000 auf der Kreditkarte 2.
<G-vec00505-001-s153><borrow.aufnehmen><en> Until 2008 it was usual to borrow up to 90% of the value of the property, 95% or even more than 100%.
<G-vec00505-001-s153><borrow.aufnehmen><de> Bis 2008 war es üblich, Kredite bis zu 90% des Wertes der Eigenschaft, 95% oder sogar mehr als 100%.
<G-vec00505-001-s154><borrow.aufnehmen><en> When borrowing is low and the economy is struggling, then a central bank will often look to the lower interest rates to boost incentives to borrow, which is often the quickest way to grow the economy.
<G-vec00505-001-s154><borrow.aufnehmen><de> Wenn die Darlehen gering sind und die Volkswirtschaft Mühe hat, dann wird eine Zentralbank oft die Zinssätze senken, um die Kredite zu fördern, was oft der schnellste Weg für ein Wirtschaftswachstum ist.
<G-vec00505-001-s155><borrow.aufnehmen><en> 2011-08-17 05:00:15 - No document payday loans - borrow easy cash without annoying formalities If you are searching for short term loan assistance that can help you in meeting various day-to-day and sudden financial crisis, no document payday loans can be the most suitable and affordable loan deal.
<G-vec00505-001-s155><borrow.aufnehmen><de> 2011-08-17 05:00:15 - Kein Dokument Zahltag Darlehen - Kredite easy cash ohne lästige Formalitäten Wenn Sie sich für kurzfristige Darlehen Unterstützung, die Sie bei der Erfüllung verschiedener Tag-zu-Tag-und plötzliche Finanzkrise helfen suchen, können kein Dokument Zahltag Darlehen am besten geeigneten und bezahlbaren Kredit zu behandeln.
<G-vec00505-001-s156><borrow.aufnehmen><en> A house could be financed with the help of relations and a company could also borrow from other companies.
<G-vec00505-001-s156><borrow.aufnehmen><de> Ein Haus lässt sich mit Hilfe von Verwandten finanzieren, eine Firma kann Kredite auch bei anderen Firmen aufnehmen.
<G-vec00505-001-s157><borrow.aufnehmen><en> This symbol was a clear representation of what Mintos does: a point of connection between those looking for opportunities to save and invest and those looking to borrow.
<G-vec00505-001-s157><borrow.aufnehmen><de> Dieses Symbol war eine klare Darstellung dessen, was Mintos tut: ein Verbindungspunkt zwischen denen, die nach Möglichkeiten zum Sparen und Investieren suchen, und denen, die Kredite aufnehmen möchten.
<G-vec00505-001-s158><borrow.aufnehmen><en> corporations wanting to borrow money) or from financial institutions who are the firm's counterparties.
<G-vec00505-001-s158><borrow.aufnehmen><de> B. von Unternehmen, die Kredite aufnehmen wollen) oder von Finanzinstitutionen, die die Gegenparteien der Firma sind.
<G-vec00505-001-s159><borrow.aufnehmen><en> But only rich people, big corporations or governments get to borrow at such low rates.
<G-vec00505-001-s159><borrow.aufnehmen><de> Aber nur reiche Leute, große Unternehmen oder Regierungen können zu so niedrigen Zinssätzen Kredite aufnehmen.
<G-vec00505-001-s160><borrow.aufnehmen><en> This is at a time where some of the nations that McKinsey suggests need extra spending are able to borrow at all time low, and even negative, rates.
<G-vec00505-001-s160><borrow.aufnehmen><de> Diese Situation besteht zu einer Zeit, in der einige Staaten laut McKinsey mit Bedarf für höhere Ausgaben Kredite zu den niedrigsten Zinssätzen überhaupt und sogar zu negativen Raten aufnehmen können.
<G-vec00505-001-s161><borrow.aufnehmen><en> "If necessary, schemes can borrow a limited amount from other schemes and other funding arrangements as a last resort (""mutual borrowing"")."
<G-vec00505-001-s161><borrow.aufnehmen><de> Bei Bedarf können die Systeme als letztes Mittel Kredite in begrenzter Höhe bei anderen Systemen aufnehmen (gegenseitige Kreditvergabe) oder auf andere Finanzierungsmöglichkeiten zurückgreifen.
<G-vec00505-001-s162><borrow.aufnehmen><en> But governments have been forced into enterprises owned by the Rothschild Khazarian Mafia and are consequently required to borrow from the central banks.
<G-vec00505-001-s162><borrow.aufnehmen><de> Aber Regierungen wurden in Unternehmen der Rothschild Khazarian Mafia gezwungen und sind daher verpflichtet, Kredite bei den Zentralbanken aufzunehmen.
<G-vec00505-001-s163><borrow.aufnehmen><en> From that moment on, the freedom of the people to refuse to borrow from the banks and to refuse to pay interest was stripped away.
<G-vec00505-001-s163><borrow.aufnehmen><de> Von diesem Moment an wurde die Freiheit des Volkes, sich zu weigern Kredite bei den Banken aufzunehmen und Zinsen zu zahlen aufgehoben.
<G-vec00505-001-s164><borrow.aufnehmen><en> Under Maastricht, it would not be allowed to borrow money to cover the deficit.
<G-vec00505-001-s164><borrow.aufnehmen><de> Dem Maastricht-Vertrag zufolge hätte sie keine Möglichkeit, Kredite aufzunehmen, um das Defizit abzudecken.
<G-vec00505-001-s165><borrow.aufnehmen><en> This encourages many customers to borrow, thus more book money is created.
<G-vec00505-001-s165><borrow.aufnehmen><de> Dies ermutigt viele Kunden, Kredite aufzunehmen – es wird mehr Buchgeld geschaffen.
<G-vec00505-001-s166><borrow.aufnehmen><en> more options for reducing credit card costs Borrowing money against your credit cards has always been among the most expensive ways to borrow money, and when you fail to pay your bill in full each month, borrowing is exactly what you're doing.
<G-vec00505-001-s166><borrow.aufnehmen><de> Weitere Optionen für die Verringerung der Kreditkarte Kosten Anleihen gegen Geld Ihrer Kreditkarte ist seit jeher zu den teuersten Möglichkeiten, Kredite aufzunehmen, und wenn Sie nicht zu zahlen Sie Ihre Rechnung in voller jeden Monat, Anleihe ist genau das, was du tust.
<G-vec00505-001-s170><borrow.ausleihen><en> You are also welcome to borrow a toboggan from us, and we will be happy to show you the best sled runs close to the Bacherhof.
<G-vec00505-001-s170><borrow.ausleihen><de> Gern können Sie sich bei uns einen Schlitten ausleihen und wir zeigen Ihnen die besten Naturrodelbahnen rund um den Bacherhof.
<G-vec00505-001-s171><borrow.ausleihen><en> If you would like to borrow the project report please indicate the project number.
<G-vec00505-001-s171><borrow.ausleihen><de> Den Abschlussbericht zum Vorhaben können Sie unter Angabe der Projektnummer ausleihen.
<G-vec00505-001-s172><borrow.leihen><en> Borrow a tip from the pros and use chicken wire or garden fencing.
<G-vec00505-001-s172><borrow.leihen><de> Leih Dir einen Tipp von den Pros und verwende Hühnerdraht oder Gartenzaun.
<G-vec00505-001-s173><borrow.leihen><en> And there are plenty of opportunities to unleash your own creativity and become part of the exhibition: use the free experimental photo booth to capture your psychic transparencies, or borrow some felt tips to contribute your interpretation of 'curious', 'torture', or 'nude' to the museum's walls .
<G-vec00505-001-s173><borrow.leihen><de> Und es gibt unzählige Möglichkeiten deiner eigenen Kreativität freien Lauf zu lassen und so Teil der Ausstellung zu werden: nutze den kostenlosen Foto-Automaten oder leih dir einige Filzstifte und leiste deinen Beitrag an den Wänden des Museums mit deiner Interpretation der Wörter 'neugierig', 'foltern' oder 'nackt'.
<G-vec00505-001-s174><borrow.leihen><en> Anyway, Pearsey and I said hurrah, and set off in the old Ford Consul... filled with instruments, a large selection of paperbacks, several changes of clothes, Wellies for the Waldeck, and then other sundry bits and bobs of varying shapes, sizes and material, which apparently have an insatiable desire to accumulate in the boot of any car which I own, borrow, or drive.
<G-vec00505-001-s174><borrow.leihen><de> Wie auch immer, Pearsey und ich sagten Hurra, und machten uns auf den Weg in den alten Ford Konsul.... gefüllt mit Instrumenten, einer großen Auswahl an Taschenbüchern, mehreren Kleiderwechseln, Gummistiefeln für das Waldeck und dann anderen verschiedenen Bits und Bobs verschiedener Formen, Größen und Materialien, die anscheinend den unersättlichen Wunsch haben, sich im Kofferraum eines jeden Autos zu versammeln, das ich besitze, leihe oder fahre.
<G-vec00505-001-s175><borrow.leihen><en> On a cloudy day I borrow a bicycle and ride on lava tracks further and further away from the civilization. Hoping all the time that it does not rain, that the rickety rental bike will survive and that I also will find the cave in this huge lava field.
<G-vec00505-001-s175><borrow.leihen><de> An einem relativ trüben Tag leihe ich mir ein Fahrrad aus und fahre los, auf einer Lavapiste vorbei an der Kraterreihe Lúdentarborgir immer weiter weg von der Zivilisation: in der Hoffnung, dass es nicht gleich regnet, dass das klapprige Mietrad die Strapazen übersteht und dass ich die Höhle auch finde.
<G-vec00505-001-s176><borrow.leihen><en> I always borrow snowshoes and ski poles from Malbun Sport in the centre of this small place, which is fully geared towards winter sports.
<G-vec00505-001-s176><borrow.leihen><de> Schneeschuhe und Skistöcke leihe ich mir stets bei Malbun Sport im Zentrum dieses voll auf Wintersport eingestellten kleinen Orts aus.
<G-vec00505-001-s177><borrow.leihen><en> I borrow the term assemblage points from Carlos Castaneda’s reports of Don Juan Matus’ Yaqui teachings.
<G-vec00505-001-s177><borrow.leihen><de> Ich leihe mir den Begriff „Montagepunkte“ aus Carlos Castanedas Berichten über die Yaqui Lehren von Don Juan Matus aus.
<G-vec00505-001-s178><borrow.leihen><en> With regard to short sales to be covered by purchase of the share during the same day this includes confir­ mation by the third party that it considers the share to be easy to borrow or to purchase.
<G-vec00505-001-s178><borrow.leihen><de> Bei Leerverkäufen, die durch Kauf der Aktie am selben Tag gedeckt werden sollen, gehört dazu auch die Zusage eines Dritten, dass er die Aktie als leicht zu leihen oder zu kaufen erachtet.
<G-vec00505-001-s179><borrow.leihen><en> Ironically other European banks, who are less successful at attracting savings and dependent on the financial markets for their funding needs, can borrow very cheaply from the European Central Bank improving their relative profitability.
<G-vec00505-001-s179><borrow.leihen><de> Ironischerweise können andere europäische Banken, denen weniger Einlagen zufließen und die für ihre Eigenkapitalbedürfnisse auf die Finanzmärkte angewiesen sind, sehr billig Geld von der Europäischen Zentralbank leihen und ihre relative Rentabilität so verbessern.
<G-vec00505-001-s180><borrow.leihen><en> Financial spread betting are leveraged and you have to borrow capital for trading from brokerage firms.
<G-vec00505-001-s180><borrow.leihen><de> Finanzielle Spread Betting sind Hebel und Sie haben Kapital zu leihen, um von Brokerfirmen gehandelt.
<G-vec00505-001-s181><borrow.leihen><en> Year-round facility can be used to organize sports, training and other gatherings (to borrow data projector, overhead projector, flipchart, whiteboard and video).
<G-vec00505-001-s181><borrow.leihen><de> Ganzjährig die Objekt kann verwendet werden fűr Sport, Training und andere Veranstaltungen zu organisieren (ein Datenprojektor, Overhead -Projektor, Flipchart, Whiteboard und Video zu leihen).
<G-vec00505-001-s182><borrow.leihen><en> “He walked into my dressing room, minutes before I was to take the stage, and asked if he could borrow a shirt, as his had a giant pizza stain.
<G-vec00505-001-s182><borrow.leihen><de> “Er ging in mein Ankleidezimmer, Minuten vorher war ich auf der Bühne, und fragte, ob er ein Hemd leihen könnte, wie er hatte einen Riesen Pizza-Fleck.
<G-vec00505-001-s183><borrow.leihen><en> I want to go to the library to borrow a book.
<G-vec00505-001-s183><borrow.leihen><de> Ich will in die Bibliothek, um ein Buch zu leihen.
<G-vec00505-001-s184><borrow.leihen><en> The EIB is able to borrow billions on the markets to fund the aid because it has a triple AAA credit rating.
<G-vec00505-001-s184><borrow.leihen><de> Die EIB ist in der Lage, Milliarden an den Märkten zu leihen, um die Hilfsfonds zu finanzieren, weil es eine dreifache AAA-Rating hat.
<G-vec00505-001-s185><borrow.leihen><en> Feel free to borrow the narrow streets that start from either side.
<G-vec00505-001-s185><borrow.leihen><de> Fühlen Sie sich frei, um die engen Gassen, die von beiden Seiten beginnen zu leihen.
<G-vec00505-001-s186><borrow.leihen><en> George Harrison played one on a ton of Beatles material (he even used to get annoyed when John Lennon kept asking to borrow it).
<G-vec00505-001-s186><borrow.leihen><de> George Harrison spielte eine auf eine Tonne von Beatles-Material (er benutzt auch ärgern, wenn John Lennon Fragen gehalten, um es zu leihen).
<G-vec00505-001-s187><borrow.leihen><en> “We do not inherit the earth from our parents, we borrow it from our children” – Chief Seattle.
<G-vec00505-001-s187><borrow.leihen><de> „Wir erben die Erde nicht von unseren Eltern, wir leihen sie von unseren Kindern“, sagte einst Chief Seattle.
<G-vec00505-001-s188><borrow.leihen><en> It is not normally possible to borrow money and pay interest at the same rate as when you invest funds.
<G-vec00505-001-s188><borrow.leihen><de> Es ist normalerweise nicht möglich, wie bei der Anlage von Geldern Geld zu leihen und Zinsen zu bezahlen.
<G-vec00505-001-s189><borrow.leihen><en> We can borrow them from the reception desk.
<G-vec00505-001-s189><borrow.leihen><de> An der Rezeption gibt es sie zu leihen.
<G-vec00505-001-s190><borrow.leihen><en> The Prophet (salla Allahu alihi wa sallam) had been told that Safwan possessed a hundred coats of mail together with many kinds of weapons, so he asked whether he might borrow them.
<G-vec00505-001-s190><borrow.leihen><de> Der Prophet (salla Allahu alihi wa sallam) war gesagt worden, dass Safwan besaß hundert Panzer zusammen mit vielen Arten von Waffen, so fragte er, ob er sie zu leihen.
<G-vec00505-001-s191><borrow.leihen><en> In most of Broward County, were large areas of muck or material unsuited for roadway construction exist, borrow canals were excavated on both sides of the future fourlane facility.
<G-vec00505-001-s191><borrow.leihen><de> In den meisten von Broward County, wurden große Bereiche der Dreck oder Material für Straßenbau ungeeignet existieren, leihen Kanäle wurden auf beiden Seiten der zukünftigen fourlane Anlage graben.
<G-vec00505-001-s192><borrow.leihen><en> You can borrow money for any type of holiday: a skiing holiday, a cruise, a family holiday or an adventurous expedition.
<G-vec00505-001-s192><borrow.leihen><de> Sie können für jede Art von Urlaub Geld leihen: vom Skiurlaub bis zur Kreuzfahrt, vom Familienurlaub bis zur Abenteuer-Expedition.
<G-vec00505-001-s193><borrow.leihen><en> "To borrow a phrase from the German writer Heinrich von Kleist, the journalist, like everyone else, is subject to ""human frailty."""
<G-vec00505-001-s193><borrow.leihen><de> "Der Journalismus unterliegt, wie alles, um ein Wort von Heinrich von Kleist zu leihen, der ""Gebrechlichkeit der Welt""."
<G-vec00505-001-s194><borrow.leihen><en> Paddles and balls are free to borrow at the wellness reception.
<G-vec00505-001-s194><borrow.leihen><de> Schläger und Bälle sind kostenlos an der Wellness-Rezeption zu leihen.
<G-vec00505-001-s195><borrow.leihen><en> Nevertheless, they forced Yan Haidong's mother Qin Sumin to return home and borrow money to pay the ransom.
<G-vec00505-001-s195><borrow.leihen><de> Nichtsdestotrotz zwangen sie Yan Haidongs Mutter Qin Sumin, nach Hause zurückzukehren, um Geld für das Lösegeld zu leihen.
<G-vec00505-001-s196><borrow.leihen><en> It can not be a good idea if you are planning to borrow funds from friends or relatives.
<G-vec00505-001-s196><borrow.leihen><de> Es kann nicht eine gute Idee, wenn Sie planen, Gelder von Freunden oder Verwandten leihen werden.
<G-vec00505-001-s197><borrow.sich_leihen><en> The city center, with stores and activities, is just a few steps away.Live in comfortable rooms with wooden floors, enjoy eating out on the restaurants terrace or borrow a bike and see the town from two wheels.
<G-vec00505-001-s197><borrow.sich_leihen><de> Die Innenstadt mit ihren Läden und Aktivitäten liegt nur ein paar Schritte entfernt.Genießen Sie komfortable Zimmer mit Holzboden, speisen Sie auf der Restaurant-Terrasse oder leihen Sie sich ein Fahrrad und erkunden Sie die Stadt auf zwei Rädern.
<G-vec00505-001-s198><borrow.sich_leihen><en> You can bring variety to your visit by going horse riding or visiting the nearby church or by borrow a raft on the Drava river.
<G-vec00505-001-s198><borrow.sich_leihen><de> Ihren Besuch können Sie noch bunter gestalten durch Reiten oder einen Besuch in der nahe gelegenen Kirche, oder Sie leihen sich ein Boot auf der Drau aus.
<G-vec00505-001-s199><borrow.sich_leihen><en> In the area of the resort you can play tennis, table tennis and other games or borrow a mountain bike.
<G-vec00505-001-s199><borrow.sich_leihen><de> Im Bereich des Resorts können Sie spielen Tennis, Tischtennis und andere Spiele oder leihen sich ein Mountainbike.
<G-vec00505-001-s200><borrow.sich_leihen><en> These artists copy, duplicate, and borrow motifs and style variations from each other, so that there are often identical pictures by different painters.
<G-vec00505-001-s200><borrow.sich_leihen><de> Die Vertreter kopieren, duplizieren und leihen sich Motive und Stilvariationen gegenseitig aus, so dass oft identische Bilder von unterschiedlichen Malern existieren.
<G-vec00505-001-s201><borrow.sich_leihen><en> They borrow money until they go bankrupt.
<G-vec00505-001-s201><borrow.sich_leihen><de> Sie leihen sich Geld, bis sie bankrott sind.
<G-vec00505-001-s202><borrow.sich_leihen><en> For those who don't own fishing license we offer a possibility of fishing in Doksy or OboÅTM where they can buy a temporary license and borrow equipment.
<G-vec00505-001-s202><borrow.sich_leihen><de> Die Gaste, die nicht eigene Fischerei Lizenz haben, können zum Fischen benutzen die Zuchtteiche in Doksy und Obora, wo kaufen sie die Lizenz und leihen sich die Ausstattung.
<G-vec00505-001-s203><borrow.leihen><en> The hotel has a lounge with TV and relax with a DVD, or playing board games, which we borrow here.
<G-vec00505-001-s203><borrow.leihen><de> Das Hotel verfügt über eine Lounge mit TV und entspannen Sie mit einem DVD-oder Brettspiele, die wir leihen Sie hier.
<G-vec00505-001-s204><borrow.leihen><en> When you borrow money your mortgage will be the price of the home minus your down payment.
<G-vec00505-001-s204><borrow.leihen><de> Wenn Sie Geld leihen Sie Ihre Hypothek wird der Preis des Hauses abzüglich Anzahlung werden.
<G-vec00505-001-s205><borrow.leihen><en> Borrow a bicycle from our hotel reception and head outdoors to explore Jyvaskyla city or the stunning Jyvasjarvi lake.
<G-vec00505-001-s205><borrow.leihen><de> Leihen Sie ein Fahrrad am Empfang und erkunden Sie die Innenstadt von Jyväskylä oder die wunderschöne Gegend am Jyvasjarvi-See.
<G-vec00505-001-s206><borrow.leihen><en> Borrow yourselves into the Surfstation by the hour that Equippment.
<G-vec00505-001-s206><borrow.leihen><de> Leihen Sie sich in der Surfstation stundenweise das Equippment.
<G-vec00505-001-s207><borrow.leihen><en> Borrow eBooks, audiobooks, and streaming video from your library using OverDrive on your iPad, iPhone, and iPod touch.
<G-vec00505-001-s207><borrow.leihen><de> Leihen Sie mit OverDrive auf Ihrem iPad, iPhone und iPod touch eBooks, Hörbücher und Streaming-Videos bei Ihrer Bibliothek aus.
<G-vec00505-001-s208><borrow.leihen><en> Put on a button up shirt and tie, put on that best dress, or borrow a friend's, be uncomfortable, and be proud.
<G-vec00505-001-s208><borrow.leihen><de> Setzen Sie auf eine Schaltfläche, bis Hemd und Krawatte, auf diesem bestes Kleid an, oder leihen Sie ein Freund ist, unbequem sein, und stolz sein.
<G-vec00505-001-s209><borrow.leihen><en> He let me borrow the pamphlet to photocopy.
<G-vec00505-001-s209><borrow.leihen><de> Er lieh mir den Bericht aus, um davon Kopien zu machen.
<G-vec00505-001-s210><borrow.leihen><en> Even let us borrow an umbrella and cooler bag.
<G-vec00505-001-s210><borrow.leihen><de> Auch lieh uns einen Sonnenschirm und Kühltasche.
<G-vec00505-001-s233><borrow.sich_ausleihen><en> You can also borrow dumbbells and steppers at the reception.
<G-vec00505-001-s233><borrow.sich_ausleihen><de> Außerdem kann man sich an der Rezeption Hanteln und Stepper ausleihen.
<G-vec00505-001-s234><borrow.sich_ausleihen><en> What I found really great, the opportunity was there to do his laundry lassen.Im summer there is 1x per week a Grillfest.Man can borrow bikes for free.
<G-vec00505-001-s234><borrow.sich_ausleihen><de> Was ich ganz toll fand, war die Möglichkeit seine Wäsche dort waschen zu lassen.Im Sommer gibt es 1x pro Woche ein Grillfest.Man kann sich kostenlos Fahrräder ausleihen.
<G-vec00505-001-s235><borrow.sich_ausleihen><en> The Boutique Hotel is centrally located at the Wiener Westbahnhof and therefor offers the perfect starting location to both explore the city of Vienna by walking, by public transport and by bike that you can borrow from our hotel .
<G-vec00505-001-s235><borrow.sich_ausleihen><de> Das Boutiquehotel Stadthalle ist zentral am Wiener Westbahnhof gelegen und bietet dadurch die perfekte Ausgangslage, um die Stadt Wien sowohl zu Fuß, mit öffentlichen Verkehrsmitteln, als auch mit dem Fahrrad, welches Sie sich bei uns im Hotel ausleihen können, zu erkunden.
<G-vec00505-001-s236><borrow.sich_ausleihen><en> In the event that the user is outside the network, the administrator can also borrow the license offline for him.
<G-vec00505-001-s236><borrow.sich_ausleihen><de> Für den Fall, dass sich der Mitarbeiter bereits außerhalb des Netzwerks befindet, kann ein Administrator die Lizenz auch offline für den Mitarbeiter ausleihen.
<G-vec00505-001-s237><borrow.sich_ausleihen><en> In addition, you can borrow ice skates from a counter, and have your own skates sharpened. There's also a kiosk that sells chips and hot and cold drinks.
<G-vec00505-001-s237><borrow.sich_ausleihen><de> Außerdem: An einem Schalter kann man sich Schlittschuhe ausleihen und eigene Schlittschuhe schleifen lassen, ein Kiosk bietet Pommes sowie heiße und kalte Getränke.
<G-vec00505-001-s238><borrow.sich_ausleihen><en> Later, at university, friends kept asking to borrow his concealer so they'd look better in their newly created Facebook profiles.
<G-vec00505-001-s238><borrow.sich_ausleihen><de> Später, an der Universität, baten Freunde immer wieder darum, sich seinen Abdeckstift ausleihen zu dürfen, damit sie auf den Fotos für ihre neu erstellten Facebook-Profile besser aussahen.
<G-vec00505-001-s239><borrow.sich_ausleihen><en> You can also borrow walking poles and bikes from our hotel reception - don't miss this opportunity to explore Nuuksio National Park!
<G-vec00505-001-s239><borrow.sich_ausleihen><de> Außerdem können Sie sich an unserem Empfang Walkingstöcke oder ein Fahrrad ausleihen und so den Nuuksio Nationalpark und die Umgebung von Espoo erkunden.
<G-vec00505-001-s240><borrow.sich_ausleihen><en> "In a back street in a courtyard between bamboo is the ""Face"", a restaurant and bar with a certain dress code (Didi had to borrow a shirt)."
<G-vec00505-001-s240><borrow.sich_ausleihen><de> "In einer Hinterstraße in einem Hinterhof zwischen Bambus befindet sich das ""Face"", ein Restaurant und Bar mit einer gewissen Kleiderordnung (Didi musste sich ein Shirt ausleihen)."
<G-vec00505-001-s241><borrow.sich_ausleihen><en> That is, your up to 10 y.o. child can borrow the equipment for free in your company.
<G-vec00505-001-s241><borrow.sich_ausleihen><de> D.h. Dein Kind bis 10 Jahre, kann sich die Ausrüstung in deiner Begleitung kostenfrei ausleihen.
<G-vec00505-001-s242><borrow.sich_ausleihen><en> Here you can borrow one of the 4,000 art works for your living room wall for up to six months.
<G-vec00505-001-s242><borrow.sich_ausleihen><de> Hier können Sie sich für bis zu sechs Monate eines der 4.000 Werke für die Wand Ihres Wohnzimmers ausleihen.
<G-vec00505-001-s243><borrow.sich_ausleihen><en> You can work out in the gym. If you prefer birdsong borrow walking poles or bicycles from reception.
<G-vec00505-001-s243><borrow.sich_ausleihen><de> Wer lieber im Freien Sport machen will, kann sich an der Rezeption Nordic Walking-Stöcke oder Fahrräder ausleihen.
<G-vec00505-001-s244><borrow.sich_ausleihen><en> It is possible to borrow the sports and swimming equipment at reasonable prices.
<G-vec00505-001-s244><borrow.sich_ausleihen><de> Die Sport und Schwimmausrüstung kann man sich ausleihen.
<G-vec00505-001-s245><borrow.sich_ausleihen><en> And down you come with a toboggan that you can borrow in the guest-house and park again in a wooden shed at the end of the toboggan run.
<G-vec00505-001-s245><borrow.sich_ausleihen><de> Und hinunter kommt man mit einem Rodel, den man sich im Gasthaus ausleihen und am Ende der Rodelbahn wieder in einem Holzschuppen abstellen kann.
<G-vec00505-001-s246><borrow.sich_ausleihen><en> In the ship's library you can borrow Hamsun novels during your journey.
<G-vec00505-001-s246><borrow.sich_ausleihen><de> Im Schiffseigenen Bibliothek können Sie sich während der Reise Hamsun Romane ausleihen.
<G-vec00505-001-s247><borrow.sich_ausleihen><en> In most yoga schools you can borrow yoga mats and blocks as a practicing one.
<G-vec00505-001-s247><borrow.sich_ausleihen><de> In den meisten Yogaschulen kann man sich als Übender Yogamatten und Blöcke ausleihen.
<G-vec00505-001-s248><borrow.sich_ausleihen><en> If you wish to borrow an iron, go to reception.
<G-vec00505-001-s248><borrow.sich_ausleihen><de> Wenden Sie sich bitte an die Rezeption, wenn Sie ein Bügeleisen ausleihen möchten.
<G-vec00505-001-s249><borrow.sich_ausleihen><en> For babies, you can borrow cribs, high chairs, strollers, baby phones, bottle warmers, baby tubs, and changing mats at the hotel for free.
<G-vec00505-001-s249><borrow.sich_ausleihen><de> Für Babys können Sie sich Gitterbett, Hochstuhl, Rückentrage, Buggy, Babyphone, Flaschenwärmer, Babywanne und Wickelauflage kostenlos im Hotel ausleihen.
<G-vec00505-001-s250><borrow.sich_ausleihen><en> The teaching materials that IIZ/DVV Office in Sarajevo bought are being offered for the teachers who can borrow them from the DLV.
<G-vec00505-001-s250><borrow.sich_ausleihen><de> Die Dank dem IIZ/DVV, Büro Sarajevo, gekauften Lehrwerke werden den Lehrern bei Anfrage zur Verfügung gestellt, die sie sich jederzeit vom DLV ausleihen können.
<G-vec00505-001-s251><borrow.sich_ausleihen><en> The hike passes the Green Pearls® hotel Irota Eco Lodge where guests can borrow mountain bikes for free.
<G-vec00505-001-s251><borrow.sich_ausleihen><de> Eure Wanderung führt euch vorbei am Green Pearls® Hotel Irota Eco Lodge, wo sich Hotelgäste kostenlos Mountainbikes ausleihen können.
<G-vec00505-001-s252><borrow.sich_ausleihen><en> "Such businesses are changing the way we ""do business"" and see the world, including in such areas as sharing of information, making games that educate as well as bring enjoyment, selling fair trade or fairly sourced products, producing eco-friendly items and financial projects that help people to borrow for or invest in small projects that benefit many people in local communities."
<G-vec00505-001-s252><borrow.sich_ausleihen><de> Darunter fällt auch der Verkauf von Fair Trade-Produkten oder von Produkten, die auf fairer Basis bezogen werden, die Produktion von umweltfreundlichen Gegenständen und finanziellen Projekten, die Menschen helfen, sich etwas auszuleihen oder in kleine Projekte zu investieren, die viele Menschen in örtlichen Gemeinden begünstigen.
<G-vec00505-001-s253><borrow.sich_ausleihen><en> In the village there is an opportunity to borrow a mountain bike or skies and snowboards.
<G-vec00505-001-s253><borrow.sich_ausleihen><de> In der Gemeinde besteht auch die Möglichkeit sich Mountainbikes oder Ski und Snowboards auszuleihen.
<G-vec00505-001-s254><borrow.borgen><en> Useful for those wishing to borrow items without getting caught.
<G-vec00505-001-s254><borrow.borgen><de> Praktisch für alle, die sich etwas borgen möchten, ohne dabei erwischt zu werden.
<G-vec00505-001-s255><borrow.borgen><en> "Investment banks rake in fees and interest from advising on the deals and trading the debt, but the real bonanza falls to the private equity firms, who in addition to the ""carried interest"" from a successful ""exit"" earn management fees, acquisition fees and ""financial advisory"" fees whenever they borrow money."
<G-vec00505-001-s255><borrow.borgen><de> "Investmentbanken streichen für ihre Beratungstätigkeit und die Fremdkapitalvermittlung Honorare und Zinsen ein, aber der wirkliche warme Regen fällt auf die Private Equity Firmen, die neben dem ""carried interest"" bei einem erfolgreichen ""Ausstieg"" Verwaltungs-, Übernahme- und ""Finanzberatungs""honorare kassieren, wann immer sie sich Geld borgen."
<G-vec00505-001-s256><borrow.sich_leihen><en> She had to sell belongings, teach, work in an art gallery, conduct telephone solicitations for the Metropolitan Opera, and borrow money to finance the project, which was rejected for funding because it was considered “too controversial.”
<G-vec00505-001-s256><borrow.sich_leihen><de> Dazu musste sie Sachen verkaufen, Unterricht geben, in einer Kunstgalerie arbeiten, für die Metropolitan Opera telefonisch Spenden einwerben und sich Geld leihen zur Finanzierung ihres Vorhabens, dem man Fördermittel verweigerte, weil es als „zu kontrovers“ galt.
<G-vec00505-001-s257><borrow.sich_leihen><en> Managers have discovered that it is safer and more profitable to borrow money and buy their own stocks than to undertake risky, long-term new ventures.
<G-vec00505-001-s257><borrow.sich_leihen><de> Manager haben herausgefunden, dass es sicherer und rentabler ist, sich Geld zu leihen und eigene Aktien zu kaufen, als riskante, langfristige neue Unternehmungen zu tätigen.
<G-vec00505-001-s258><borrow.sich_leihen><en> Her mother Marietta has become a heavy drinker after her husband has left her. From time to time she visits her daughter to borrow some money.
<G-vec00505-001-s258><borrow.sich_leihen><de> Ihre Mutter Marietta, die dem Alkohol verfallen ist, nachdem ihr Mann sie verlassen hat, sucht sie regelmäßig auf, um sich Geld zu leihen.
<G-vec00505-001-s259><borrow.sich_leihen><en> That is why they are not miserly when someone wants to borrow money from them.
<G-vec00505-001-s259><borrow.sich_leihen><de> Deshalb geizen sie auch nicht, wenn sich jemand Geld von ihnen leihen will.
<G-vec00505-001-s260><borrow.sich_leihen><en> His audacity goes to borrow larger by placing the sail locker outside.
<G-vec00505-001-s260><borrow.sich_leihen><de> Seine Kühnheit geht, um sich zu leihen, indem man das Segelschließfach draußen setzt.
<G-vec00505-001-s261><borrow.sich_leihen><en> Then he sent a boy to Great Claus to borrow a bushel measure.
<G-vec00505-001-s261><borrow.sich_leihen><de> Nun sandte er einen Knaben zum großen Klaus hin, um sich ein Scheffelmaß zu leihen.
<G-vec00505-001-s262><borrow.sich_leihen><en> The minimum purchase order quantity for the product is 1 More info Ty Derrick asks to borrow step-brother Blake Hunter's iron but he looks a little too long at his ass.
<G-vec00505-001-s262><borrow.sich_leihen><de> Die Mindestbestellmenge für diesen Artikel ist 1 Mehr Infos Ty Derrick fragt, ob er sich das Bügeleisen von seinem Stiefbruder Blake Hunter leihen kann, doch er schaut ihm zu lange auf den Arsch.
<G-vec00505-001-s263><borrow.sich_leihen><en> Many have no option about when their MRP to coat or to borrow from private money.
<G-vec00505-001-s263><borrow.sich_leihen><de> Vielen bleibt nichts weiter über, als ihren Dispo zu überziehen oder sich von Privat Geld zu leihen.
<G-vec00505-001-s264><borrow.sich_leihen><en> Thereby the debt to Rothschild increases perpetually – and the host debtor must borrow more money to pay the interest > more debt > more dependence on Rothschild ́s London City and more debt slavery of peoples.
<G-vec00505-001-s264><borrow.sich_leihen><de> Dadurch steigt die Schuld gegenüber Rothschild ständig an – und der Gastgeberlandschuldner muss sich mehr Geld leihen, um die Zinsen zu zahlen > mehr Schulden> mehr Abhängigkeit von Rothschilds London City und mehr Schuldensklaverei der Völker.
<G-vec00505-001-s265><borrow.sich_leihen><en> To get to the finca, it is advisable to borrow at the airport of Palma de Mallorca a car. If you book the apartment or guest house you will automatically receive a detailed road map.
<G-vec00505-001-s265><borrow.sich_leihen><de> Um zur KINDERFREI geführten FincaOase-Can Negre zu gelangen, ist es empfehlenswert, sich am Flughafen von Palma de Mallorca einen Mietwagen zu leihen.
<G-vec00505-001-s266><borrow.sich_leihen><en> No nation, even the United States with all its wealth, can continue to borrow money forever.
<G-vec00505-001-s266><borrow.sich_leihen><de> Kein Land, selbst die USA mit all ihrem Wohlstand, kann sich unendlich Geld leihen.
<G-vec00505-001-s267><borrow.sich_leihen><en> Then the fiendish police forced intravenous drips on her and forced her to borrow money to pay for them.
<G-vec00505-001-s267><borrow.sich_leihen><de> Gegen ihren Willen gab ihr die niederträchtige Polizei Infusionen und zwang sie sich Geld zu leihen, um sie zu bezahlen.
<G-vec00505-001-s268><borrow.sich_leihen><en> The government will borrow from them 55 billion Euros, in order to pay back debt.
<G-vec00505-001-s268><borrow.sich_leihen><de> Die Regierung wird sich von ihnen 55 Milliarden Euro leihen, um Schulden zurück zu zahlen.
<G-vec00505-001-s269><borrow.sich_leihen><en> In October of 2003, Mr. Wu Chunlong had to borrow money to open a hair salon business.
<G-vec00505-001-s269><borrow.sich_leihen><de> Im Oktober 2003 musste sich Herr Wu Geld leihen, um einen Haarsalon zu eröffnen.
<G-vec00505-001-s274><borrow.ausleihen><en> Guests wishing to explore the surroundings can borrow bikes from the hotel reception.
<G-vec00505-001-s274><borrow.ausleihen><de> Wenn Sie die Umgebung erkunden möchten, können Sie an der Rezeption Fahrräder ausleihen.
<G-vec00505-001-s275><borrow.ausleihen><en> User can borrow up to five items at the same time, these may include a maximum of three Books and two DVDs/CDs.
<G-vec00505-001-s275><borrow.ausleihen><de> Sie können bis zu fünf Medien gleichzeitig ausleihen, davon maximal drei Bücher und maximal zwei DVDs/CDs.
<G-vec00505-001-s286><borrow.borgen><en> 5:42 To him that asks of thee give, and from him that desires to borrow of thee turn not away.
<G-vec00505-001-s286><borrow.borgen><de> 5:42 Gib dem, der dich bittet, und weise den nicht ab, der von dir borgen will.
<G-vec00505-001-s287><borrow.borgen><en> Give to him who asks you, and don't turn away him who desires to borrow from you.
<G-vec00505-001-s287><borrow.borgen><de> Gib dem, der dich bittet, und weise den nicht ab, der von dir borgen will.
<G-vec00505-001-s288><borrow.borgen><en> 42 To him that asks of thee give, and from him that desires to borrow of thee turn not away.
<G-vec00505-001-s288><borrow.borgen><de> 42 Gib dem, der dich bittet, und weise den nicht ab, (O. wende dich nicht von dem ab) der von dir borgen will.
<G-vec00505-001-s289><borrow.borgen><en> Whoever asks of you, give to him. And if anyone would borrow from you, do not turn away from him.
<G-vec00505-001-s289><borrow.borgen><de> Gib dem, der dich bittet, und weise den nicht ab, der von dir borgen will.
