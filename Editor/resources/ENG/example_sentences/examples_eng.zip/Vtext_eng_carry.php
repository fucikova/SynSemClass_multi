<G-vec00241-001-s114><carry.befördern><en> 5d4) We will not carry you if you are aged under 14 at the date of travel and are not travelling with someone aged 16 or older on your booking or on a linked booking.
<G-vec00241-001-s114><carry.befördern><de> 5d4) Wir befördern Sie nicht, wenn Sie zum Zeitpunkt der Reise jünger als 14 Jahre sind und Ihre Buchung oder eine verknüpfte Buchung keine mitreisende Person enthält, die mindestens 16 Jahre alt ist.
<G-vec00241-001-s115><carry.befördern><en> In ski resort Lienzer Bergbahnen the 12 lifts can carry 13,000 people per hour.
<G-vec00241-001-s115><carry.befördern><de> Im Skigebiet Lienzer Bergbahnen können die 12 Skilifte bis zu 13.000 Personen pro Stunde befördern.
<G-vec00241-001-s116><carry.befördern><en> • Always carry the air mattress in a stuff sack or other protective bag.
<G-vec00241-001-s116><carry.befördern><de> • Matte stets in einem Packsack oder einem anderen Schutzbeutel befördern.
<G-vec00241-001-s117><carry.befördern><en> With the German shipping line Hapag-Lloyd's merger with the Chilean line CSAV, the top four lines in the world, i.e. Maersk, MSC, CMA CGM & Hapag-Lloyd would now carry over 40% of the world's container capacity.
<G-vec00241-001-s117><carry.befördern><de> Mit dem Merger zwischen der deutschen Schifffahrtslinie Hapag-Lloyd mit der chilenischen Reederei CSAV würden die vier größten Linien der Welt, Maersk, MSC, CMA CGM und Hapag-Lloyd mehr als 40% der Containerkapazität der Welt befördern.
<G-vec00241-001-s118><carry.befördern><en> The German railways carry 6.3 million passengers per day in regional transport and 300,000 inter-city passengers.
<G-vec00241-001-s118><carry.befördern><de> Die deutschen Eisenbahnen befördern täglich 6,3 Millionen Fahrgäste, 6 Millionen im Nahverkehr und 300.000 im Fernverkehr.
<G-vec00241-001-s119><carry.befördern><en> Humic substances carry minerals through cell membrane.
<G-vec00241-001-s119><carry.befördern><de> Huminsäure ist im Stande, die anorganischen Spurenelemente durch die Zellmembran zu befördern.
<G-vec00241-001-s120><carry.befördern><en> To carry passengers or goods when this implies subletting vehicle directly or indirectly.
<G-vec00241-001-s120><carry.befördern><de> Güter oder Personen zu befördern, wenn dies direkt oder indirekt die Untervermietung des Fahrzeuges beinhaltet.
<G-vec00241-001-s121><carry.befördern><en> We do carry for free children's buggies and dogs.
<G-vec00241-001-s121><carry.befördern><de> Gerne befördern wir den Kinderwagen sowie Hunde kostenlos.
<G-vec00241-001-s122><carry.befördern><en> The villagers created a bamboo platform with small wheels along a track to carry crops and goods from one village to the next.
<G-vec00241-001-s122><carry.befördern><de> Die Dorfbewohner bauten Plattformen aus Bambus, an denen sie kleine Räder befestigten, um Getreide und Güter von einem Dorf zum nächsten befördern zu können.
<G-vec00241-001-s123><carry.befördern><en> The ten modern lifts carry nearly 11.000 people uphill per hour.
<G-vec00241-001-s123><carry.befördern><de> Die zehn modernen Lifte befördern in der Stunde insgesamt beinahe 11.000 Personen bergwärts.
<G-vec00241-001-s124><carry.befördern><en> In the cabin of aircraft allowed to carry up to 7 kg of hand luggage per passenger.
<G-vec00241-001-s124><carry.befördern><de> In der Kabine von Flugzeugen erlaubt, bis zu 7 kg Handgepäck pro Passagier zu befördern.
<G-vec00241-001-s125><carry.befördern><en> Today jet planes carry more than five billion passengers worldwide.
<G-vec00241-001-s125><carry.befördern><de> Heute befördern Düsenjets weltweit jährlich mehr als fünf Milliarden Passagiere.
<G-vec00241-001-s126><carry.befördern><en> To carry persons or goods without having obtained the corresponding official permits.
<G-vec00241-001-s126><carry.befördern><de> Güter oder Personen zu befördern, ohne hierfür die erforderlichen Genehmigungen vorliegen zu haben.
<G-vec00241-001-s127><carry.befördern><en> At the right time His intention will then begin to shine out, and I and all those like me will immediately fully take in the same into our being and carry it into all infinity; therefore we also carry the name ‘supreme messengers’, because we are the bearers and executers of the divine will.
<G-vec00241-001-s127><carry.befördern><de> Zur rechten Zeit wird dann Sein Wille schon nach außen hinaus zu strahlen anfangen, und ich und alle meinesgleichen werden denselben alsogleich in uns völlig aufnehmen und ihn befördern in alle Unendlichkeit hinaus; darum führen wir auch eigenschaftlich den Namen,Erzboten‘, weil wir die Austräger und die Auswirker des göttlichen Willens sind.
<G-vec00241-001-s128><carry.befördern><en> With the pull cart can carry easily the utensils and the food for the day.
<G-vec00241-001-s128><carry.befördern><de> Mit dem Ziehwagen können Sie auf einfache Weise die Untensilien und das Essen für den Tag befördern.
<G-vec00241-001-s129><carry.befördern><en> We recently developed a kind of small Unimog for Africa that can carry passengers and goods for 80 kilometres on one battery charge.
<G-vec00241-001-s129><carry.befördern><de> Vor Kurzem haben wir eine Art kleinen Unimog für Afrika entwickelt, der Personen und Güter mit einer Batterieladung 80 Kilometer weit befördern kann.
<G-vec00241-001-s130><carry.befördern><en> It may happen that goods are available, that all the possibilities exist for expanding trade turnover, but transport cannot keep up with the development of trade turnover and refuses to carry the freight.
<G-vec00241-001-s130><carry.befördern><de> Es kann vorkommen, dass Waren vorhanden sind, dass die volle Möglichkeit besteht, den Warenumsatz zu entfalten, das Verkehrswesen aber nicht mit der Entwicklung des Warenumsatzes Schritt hält und nicht imstande ist, die Güter zu befördern.
<G-vec00241-001-s131><carry.befördern><en> It has the advantage that one can carry something in it, even if it's only air and it transports a visible message in the print on it.
<G-vec00241-001-s131><carry.befördern><de> Sie hat den Vorteil, dass man etwas in ihr befördern kann, selbst wenn es nur Luft ist und dass sie per Aufdruck eine deutlich sichtbare Botschaft vermittelt.
<G-vec00241-001-s132><carry.befördern><en> Now, the scientists at the DLR Institute of Planetary Research are waiting with bated breath for other instruments, among them the spectrometer VIRTIS, in which they were contributing partners, to deliver data on the gases that carry the dust particles from the surface of the comet into space.
<G-vec00241-001-s132><carry.befördern><de> Die Wissenschaftler des DLR-Institut für Planetenforschung warten nun mit Spannung darauf, dass weitere Instrumente wie das Spektrometer VIRTIS, an denen sie beteiligt sind, Daten zu den Gasen liefern, die die Staubteilchen von der Kometenoberfläche ins All befördern.
<G-vec00241-001-s399><carry.führen><en> Furthermore, we regularly carry out individual improvement projects in purchasing, production and logistics on site at our suppliers in order to constantly improve our efficient skills network.
<G-vec00241-001-s399><carry.führen><de> Darüber hinaus führen wir regelmäßig individuelle Verbessungsprojekte in den Bereichen Einkauf, Produktion und Logistik vor Ort bei unseren Lieferanten durch, um so unser effektives Kompetenznetzwerk kontinuierlich zu stärken.
<G-vec00241-001-s400><carry.führen><en> We carry all important brands in the areas furniture, closets, beds, shelves, armchairs and sofas, outdoor, carpets, crockery, and gifts .
<G-vec00241-001-s400><carry.führen><de> Wir führen alle wichtigen Hersteller im Bereich Möbel, Schränke, Betten, Regale, Sessel und Sofas, Armlehnstühle, Outdoor, Teppiche, Geschirr und Geschenke .
<G-vec00241-001-s401><carry.führen><en> We are highly competent to advise clients in this area and to carry out migration testing.
<G-vec00241-001-s401><carry.führen><de> Wir beraten Sie gerne und führen für Sie auch eine Lebensmittelunbedenklichkeitsprüfung durch.
<G-vec00241-001-s402><carry.führen><en> Fishing Tackle We carry fishing tackle, lures, equipment and outdoor gear.
<G-vec00241-001-s402><carry.führen><de> Fishing Tackle Wir führen Angelausrüstung, lockt, Ausrüstung und Outdoor-Ausrüstung.
<G-vec00241-001-s403><carry.führen><en> "Since there are several weapons put to use - from knives to giant swords, which you normally would only see Cloud from ""Final Fantasy VII"" carry around - the individual fights are short, concise and coined by tension-building breaks of tactical thinking."
<G-vec00241-001-s403><carry.führen><de> "Da vermehrt Waffen - von Dolchen bis zu riesigen Schwertern, die man sonst nur Cloud aus ""Final Fantasy VII"" mit sich führen sieht - eingesetzt werden, sind die einzelnen Kämpfe kurz, prägnant und von einer spannungsfördernden Pause des Taktierens geprägt."
<G-vec00241-001-s404><carry.führen><en> Parents who first think about how to remove lice from their child, usually carry out this procedure in a big hurry, almost in a panic.
<G-vec00241-001-s404><carry.führen><de> Eltern, die zuerst darüber nachdenken, wie man Läuse von ihrem Kind entfernen kann, führen dieses Verfahren in der Regel in großer Eile aus, fast in Panik.
<G-vec00241-001-s405><carry.führen><en> When you carry from prison to court, is this: even before the rise of the total breakfast, pickling, bending, in the “glass”, transport of Moscow traffic jams - at least 2 hours.
<G-vec00241-001-s405><carry.führen><de> Wenn Sie aus dem Gefängnis zum Gericht führen, ist dies: Schon vor dem Anstieg der gesamten Frühstück-, Beiz-, Biege-, in der “Glas”, der Transport von Moskau Staus - mindestens 2 Stunden.
<G-vec00241-001-s406><carry.führen><en> "Browder presented the agreement of the anti-fascist allies to carry the war against Hitlerite Germany through to the end as the beginning of a new historical epoch, in which socialism and capitalism had found the way to co-operation within ""one and the same world"", as he expressed it."
<G-vec00241-001-s406><carry.führen><de> Die Übereinkunft der anti-faschistischen Allierten, den Kampf gegen das faschistische Deutschland zu Ende zu führen, stellte Browder als den Beginn einer neuen historischen Epoche hin, in der Sozialismus und Kapitalismus im Rahmen ́ einer einheitlichen und gleichartigen Welt`, wie er sich ausdrückte, den Weg der Zusammenarbeit gefunden hätten.
<G-vec00241-001-s407><carry.führen><en> First, you must always carry with you either a handkerchief or paper napkins to be able to regularly clean the nasal cavity.
<G-vec00241-001-s407><carry.führen><de> Zuerst müssen Sie entweder ein Taschentuch oder eine Papierserviette mit sich führen, um die Nasenhöhle regelmäßig reinigen zu können.
<G-vec00241-001-s408><carry.führen><en> We carry also fresh meat, various sausages and salami.
<G-vec00241-001-s408><carry.führen><de> Weiteres führen wir Frischfleisch, verschiedene Wurstwaren, Salami.
<G-vec00241-001-s409><carry.führen><en> Every second, everyday, we carry out hundreds of activities on the internet. Sending and receiving emails, checking social profiles, updating status, uploading photos, paying bills, online shopping and so much more.
<G-vec00241-001-s409><carry.führen><de> Wir führen jede Sekunde, jeden Tag hunderte von Aktivitäten im Internet aus, sei es E-Mails versenden oder empfangen, Social-Media-Profilen folgen, den Status aktualisieren, Fotos hochladen, Rechnungen bezahlen, Online-Shopping und vieles mehr.
<G-vec00241-001-s410><carry.führen><en> You also carry out tests and conformity assessments of products and assemblies on the manufacturer side.
<G-vec00241-001-s410><carry.führen><de> Auch auf Herstellerseite führen Sie Prüfungen und Konformitätsbewertungen von Produkten und Baugruppen durch.
<G-vec00241-001-s411><carry.führen><en> To this end members of the network carry out independent integration projects and underpin them with dedicated sponsorships.
<G-vec00241-001-s411><carry.führen><de> Dazu führen die die teilnehmenden Unternehmen eigenständige Integrationsprojekte durch und untermauern sie mit verbindlichen Patenschaften.
<G-vec00241-001-s412><carry.führen><en> Through RTT the user can carry a text conversation while being called.
<G-vec00241-001-s412><carry.führen><de> Über RTT kann der Benutzer während des Anrufs ein Textgespräch führen.
<G-vec00241-001-s413><carry.führen><en> You should ensure that you understand all the details before you carry the process out.
<G-vec00241-001-s413><carry.führen><de> Sie sollten sicherstellen, dass Sie alle Details verstehen, bevor Sie den Vorgang aus führen.
<G-vec00241-001-s414><carry.führen><en> «Those who know it and those who don't know it, both carry out rituals using this syllable.» But knowledge and ignorance are two very different things.
<G-vec00241-001-s414><carry.führen><de> «Diejenigen, die es wissen, und diejenigen, die es kennen, nicht beide führen Rituale mit dieser Silbe.» Aber wissen und Unwissenheit sind zwei sehr verschiedene Dinge.
<G-vec00241-001-s415><carry.führen><en> We carry out due diligence for target companies with a seat in the entire Adriatic region.
<G-vec00241-001-s415><carry.führen><de> Wir führen Due Diligence bei Zielunternehmen in der gesamten Adria-Region durch.
<G-vec00241-001-s416><carry.führen><en> Scientists of these institutes carry out fruitful fundamental and applied research in computer science and information technology.
<G-vec00241-001-s416><carry.führen><de> Wissenschaftler dieser Institute führen fruchtbare Grundlagen- und angewandte Forschung in Informatik und Informationstechnologie durch.
<G-vec00241-001-s417><carry.führen><en> For that reason, we carry out a series of annual events in the field of NVH, which focus on the exchange of experiences and the active dialog with our customers.
<G-vec00241-001-s417><carry.führen><de> Deshalb führen wir im Bereich NVH jedes Jahr eine Reihe von Veranstaltungen durch, bei denen der Erfahrungsaustausch und der Dialog mit unseren Kunden im Vordergrund stehen.
<G-vec00241-001-s418><carry.führen><en> 12:6 The tents of marauders are undisturbed, and those who provoke God are secure--those who carry their god in their hands.
<G-vec00241-001-s418><carry.führen><de> 12:6 Die Zelte der Verwüster sind in Ruhe, und Sicherheit ist für die, welche Gott reizen, für den, welcher Gott in seiner Hand führt.
<G-vec00241-001-s419><carry.führen><en> The Federal Police carry out the measurement flights and is responsible for the exact positioning of the helicopters in the areas to be mapped.
<G-vec00241-001-s419><carry.führen><de> Die Bundespolizei führt die Messflüge durch und ist für die exakte Positionierung der Hubschrauber in den zu kartierenden Gebieten verantwortlich.
<G-vec00241-001-s420><carry.führen><en> 15.2 TeamSpeak will also carry out the data processing through external service providers.
<G-vec00241-001-s420><carry.führen><de> 15.2 TeamSpeak führt die Datenverarbeitung auch über externe Dienstleister durch.
<G-vec00241-001-s421><carry.führen><en> Membership Committee:Performs activities to support membership growth, ensure adequate representation of members at all levels, carry out member surveys, identify member needs, convey requests/needs of members to other committees and maintain membership metrics.
<G-vec00241-001-s421><carry.führen><de> Mitgliedschaftsausschuss: Wirbt durch Aktivitäten Mitglieder, sorgt für die angemessene Vertretung der Mitglieder auf allen Ebenen, führt Umfragen unter den Mitgliedern durch, erkundet die Bedürfnisse der Mitglieder, leitet Anfragen/Bedürfnisse der Mitglieder an andere Ausschüsse weiter und pflegt die Mitgliedschaftsdaten.
<G-vec00241-001-s422><carry.führen><en> Membership Committee: Â Performs activities to support membership growth, ensure adequate representation of members at all levels, carry out member surveys, identify member needs, convey requests/needs of members to other committees and maintain membership metrics.
<G-vec00241-001-s422><carry.führen><de> Mitgliedschaftsausschuss: Wirbt durch Aktivitäten Mitglieder, sorgt für die angemessene Vertretung der Mitglieder auf allen Ebenen, führt Umfragen unter den Mitgliedern durch, erkundet die Bedürfnisse der Mitglieder, leitet Anfragen/Bedürfnisse der Mitglieder an andere Ausschüsse weiter und pflegt die Mitgliedschaftsdaten.
<G-vec00241-001-s423><carry.führen><en> Carry out the financial valuation of an organization to collaborate in merger and acquisition processes.
<G-vec00241-001-s423><carry.führen><de> Finanz führt die Bewertung einer Organisation in Fusions- und Akquisitionsprozessen zusammenzuarbeiten.
<G-vec00241-001-s424><carry.führen><en> The EU relies on organisations with the right experience to carry out its development projects on the ground.
<G-vec00241-001-s424><carry.führen><de> Die EU führt ihre Entwicklungsprojekte vor Ort mit Hilfe erfahrener Organisationen durch.
<G-vec00241-001-s425><carry.führen><en> carry out CQI-15 auditing of your company or suppliers without any need for costly training, following optionally the AIAG CQI-15 standard questionnaire or a checklist compiled in accordance with specific customer requirements.
<G-vec00241-001-s425><carry.führen><de> führt ohne aufwendige Einarbeitung und innerhalb kürzester Zeit die CQI-15 Auditierung Ihres Unternehmens oder bei Ihren Lieferanten durch, nach AIAG CQI-15 Standardkatalog oder gemäß speziellem Kundenwunsch.
<G-vec00241-001-s426><carry.führen><en> Within the scope of Inga I Voith will carry out a comprehensive rehabilitation program for two generator-turbine units inside the hydropower station.
<G-vec00241-001-s426><carry.führen><de> Im Rahmen von Inga I führt Voith eine umfassende Rehabilitation von zwei Generator-Turbinen-Einheiten des Wasserkraftwerks durch.
<G-vec00241-001-s427><carry.führen><en> Viator accepts no liability for travelers who are refused entry onto a flight or into any country because of the traveler's failure to carry the travel documents required by any airline, authority, or country, including countries the traveler may just be passing through en route to his or her destination.
<G-vec00241-001-s427><carry.führen><de> Viator haftet nicht gegenüber Reisenden, denen der Einstieg in ein Flugzeug oder die Einreise in ein Land verweigert wird, weil der Reisende nicht die Reisedokumente bei sich führt, die von einer Airline, einer Behörde oder einem Land, einschließlich Ländern, die der Reisende auf dem Weg zu seinem Ziel nur durchreist, gefordert werden.
<G-vec00241-001-s428><carry.führen><en> I never know where the current will carry me, but I feel honoured to be allowed to be part of that ocean.
<G-vec00241-001-s428><carry.führen><de> Ich weiß nie, wohin mich der Strom führt, aber ich fühle mich privilegiert und geehrt ein Teil dieses Meeres sein zu dürfen.
<G-vec00241-001-s429><carry.führen><en> It must derive the maintenance measures necessary for its vehicles from the requirements and will carry out the maintenance measures itself or avail itself of maintenance workshops acc. to EU Regulation, with which it concludes contracts.
<G-vec00241-001-s429><carry.führen><de> Sie muss aus den Anforderungen die für ihre Fahrzeuge erforderlichen Instandhaltungsmaßnahmen ableiten und führt die Instandhaltungsmaßnahmen selbst durch oder bedient sich nach EU Verordnung zertifizierten Instandhaltungswerkstätten, mit denen sie entsprechende Verträge abschließt.
<G-vec00241-001-s430><carry.führen><en> “Quality awareness” are always in AODI people’s mind, it is our principle to accordance with and carry out the IATF16949:2016/ISO9001:2005 management system.
<G-vec00241-001-s430><carry.führen><de> „Qualitätsbewusstsein“ ist immer in AODI Verstand der Leute, es ist unser Prinzip nach und führt den IATF16949: 2016 / ISO 9001: 2005-Management-System.
<G-vec00241-001-s431><carry.führen><en> Farmer with tractor is the game in which the farmer will carry our Red trailer by vegetable farm in these works the zor to fulfill the daily norm of picking vegetables.
<G-vec00241-001-s431><carry.führen><de> Landwirt mit Traktor ist das Spiel, in dem der Bauer unser Red Trailer führt, von Gemüse Bauernhof in diesen Arbeiten der Zor, die tägliche Norm der Kommissionierung Gemüse zu erfüllen.
<G-vec00241-001-s432><carry.führen><en> 29 In 2009, Roskosmos will carry out 39 launches of spacecraft.
<G-vec00241-001-s432><carry.führen><de> 29 Im Jahr 2009, Roskosmos führt 39 startet von Raumfahrzeugen.
<G-vec00241-001-s433><carry.führen><en> 4.3 The conformity assessment body shall carry out periodic audits to make sure that the manufacturer maintains and applies the quality system and shall provide the manufacturer with an audit report.
<G-vec00241-001-s433><carry.führen><de> 4.3 Die Konformitätsbewertungsstelle führt regelmäßig Audits durch, um sicherzustellen, dass die Herstellerin das Qualitätssicherungssystem aufrechterhält und anwendet, und übergibt ihm einen entsprechenden Prüfbericht.
<G-vec00241-001-s434><carry.führen><en> An experienced team consisting of a pilot and system operator carry out the flight.
<G-vec00241-001-s434><carry.führen><de> Ein erfahrenes Team bestehend aus Pilot und Systembediener führt die Befliegung durch.
<G-vec00241-001-s435><carry.führen><en> "From his perspective, Scientology's being a ""totalitarian movement,"" thereby ""working against democracy,"" appears to be less momentous than the fact that he has to carry on his battle against Scientology in the USA himself."
<G-vec00241-001-s435><carry.führen><de> "Wobei seine Ansicht, Scientology sei eine ""totalitäre Bewegung"" und damit ""gegen die Demokratie eingestellt"", für die Sekte weniger schwerwiegend zu sein scheint als die Tatsache, dass er seinen Kampf gegen Scientology in den USA selbst führt."
<G-vec00241-001-s436><carry.führen><en> The western route will carry on to Paris and Brussels, the eastern one to Freiburg, Frankfurt and Cologne – taking in Berlin along the way.
<G-vec00241-001-s436><carry.führen><de> Die westliche Route führt über Paris und Brüssel, die östliche über Freiburg, Frankfurt und Köln, daneben ist ein Abstecher nach Berlin geplant.
<G-vec00241-001-s456><carry.tragen><en> It is an appeal that we should all carry out our work of evangelization in great humility, knowing that we are not the first to work in the vineyard of the Lord nor will we be the last.
<G-vec00241-001-s456><carry.tragen><de> Ich rufe dazu auf, dass wir unser Evangelisierungswerk mit großer Demut voranbringen, von dem Wissen getragen, dass wir nicht die ersten sind, die im Weinberg des Herrn arbeiten, und auch nicht die letzten sein werden.
<G-vec00241-001-s457><carry.tragen><en> The verification process is already fully automated, that means there is no need to carry a mail folder from A to B for invoice control.
<G-vec00241-001-s457><carry.tragen><de> Der Prüfprozess ist schon durchautomatisiert, sprich es muss keine Postmappe zur Rechnungskontrolle von A nach B getragen werden.
<G-vec00241-001-s458><carry.tragen><en> Just as if he were to place upright what was overturned, to reveal what was hidden, to show the way to one who was lost, or to carry a lamp into the dark so that those with eyes could see forms, in the same way has Master Ananda — through many lines of reasoning — made the Dhamma clear.
<G-vec00241-001-s458><carry.tragen><de> Gerade so als hätte jemand etwas aufgerichtet was kopfüber war, freigelegt, was verborgen war, einem der den Weg verloren, den Weg gezeigt, oder eine Lampe in die Dunkelheit getragen hätte, sodass jene mit Augen Form sehen können, in selber Weise hat Meister Ananda, durch viele Zeilen der Begründung hindurch, das Dhamma klar gemacht.
<G-vec00241-001-s459><carry.tragen><en> You can significantly increase your performance with the robust BEUMER Parcel Picker® compared to conventional manual unloading: you no longer need to physically lift and carry the packages.
<G-vec00241-001-s459><carry.tragen><de> Der robuste BEUMER Parcel Picker® ermöglicht eine deutliche Leistungssteigerung im Vergleich zur bisher üblichen manuellen Entladung: Packstücke müssen im gesamten Prozess nicht mehr körperlich gehoben und getragen werden.
<G-vec00241-001-s460><carry.tragen><en> Above all lie the strong vocals of Andreas Bunk, which carry the music both hard rocking and also sensitive.
<G-vec00241-001-s460><carry.tragen><de> Und alles das wird vom Gesang von Andreas Bunk getragen, der mit Charisma mal raubeinig rockig, aber auch mal feinfühlig mit starkem Ausdruck, sehr authentisch ist.
<G-vec00241-001-s461><carry.tragen><en> When Jesus carried His cross up Golgotha to be crucified, no one was thinking of the cross as symbolic of a burden to carry.
<G-vec00241-001-s461><carry.tragen><de> Als Jesus sein Kreuz nach Golgatha hinauftrug, um gekreuzigt zu werden, dachte niemand über das Kreuz als Symbol für eine Last, die getragen wird.
<G-vec00241-001-s462><carry.tragen><en> The images embedded in the six cushions are the flowers the living carry through time, believing it will be new and wonderful.
<G-vec00241-001-s462><carry.tragen><de> Die auf den sechs Kissen eingebetteten Erscheinungen sind die Blumen, die von den Lebenden durch die Zeit getragen werden, von der sie glauben, daß sie gar neu und wunderbar wird.
<G-vec00241-001-s463><carry.tragen><en> Some packages are so heavy that three or four women at a time are needed to carry them.
<G-vec00241-001-s463><carry.tragen><de> Manche Pakete sind so schwer, dass sie von drei bis vier Frauen gleichzeitig getragen werden müssen.
<G-vec00241-001-s464><carry.tragen><en> "49:22 This is what the Sovereign LORD says: ""See, I will beckon to the Gentiles, I will lift up my banner to the peoples; they will bring your sons in their arms and carry your daughters on their shoulders."
<G-vec00241-001-s464><carry.tragen><de> 49:22 So spricht der Herr, Jehova: Siehe, ich werde meine Hand zu den Nationen hin erheben, und zu den Völkern hin mein Panier aufrichten; und sie werden deine Söhne im Busen bringen, und deine Töchter werden auf der Schulter getragen werden.
<G-vec00241-001-s465><carry.tragen><en> Just as if he were to place upright what was overturned, to reveal what was hidden, to show the way to one who was lost, or to carry a lamp into the dark so that those with eyes could see forms, in the same way has the Blessed One — through many lines of reasoning — made the Dhamma clear.
<G-vec00241-001-s465><carry.tragen><de> Gerade so, als ob Er aufgerichtet hätte, was umgedreht war, freigelegt, was verdeckt war, den Weg jemandem gezeigt hätte, der verloren war, oder eine Lampe ins Dunkle getragen hätte, sodass jene mit Augen Form sehen könnten, in gleicher Weise hat der Befreite - in vielen Linien der Begründung - das Dhamma klar gemacht.
<G-vec00241-001-s466><carry.tragen><en> Four flange bearings carry the entire weight of the system.
<G-vec00241-001-s466><carry.tragen><de> Das gesamte Gewicht des Systems wird von vier Flanschlagern getragen.
<G-vec00241-001-s467><carry.tragen><en> Campgrounds are accessible by the bus, you never have to carry your luggage very far
<G-vec00241-001-s467><carry.tragen><de> Die Zeltplätze sind mit dem Bus erreichbar, Gepäck braucht nie weit getragen zu werden.
<G-vec00241-001-s468><carry.tragen><en> He bore our sins. He didn't just carry them; he suffered the penalty we deserved.
<G-vec00241-001-s468><carry.tragen><de> Er hat sie nicht nur getragen, sondern auch die Qualen der Strafe ertragen, die wir verdient hätten.
<G-vec00241-001-s469><carry.tragen><en> Just as if he were to place upright what was overturned, to reveal what was hidden, to point out the way to one who was lost, or to carry a lamp into the dark so that those with eyes could see forms, in the same way has Master Ananda — through many lines of reasoning — made the Dhamma clear.
<G-vec00241-001-s469><carry.tragen><de> Gerade so als hätte jemand etwas aufgerichtet was kopfüber war, freigelegt, was verborgen war, einem der den Weg verloren, den Weg gezeigt, oder eine Lampe in die Dunkelheit getragen hätte, sodass jene mit Augen Form sehen können, in selber Weise hat Meister Ananda, durch viele Zeilen der Begründung hindurch, das Dhamma klar gemacht.
<G-vec00241-001-s470><carry.tragen><en> That was a hymn we often used to sing at the Seminary of Traunstein and it takes me back to my early youth, thus enabling me to perceive all the joy in the Lord and in the Mother of God, then as now, which we carry in our hearts.
<G-vec00241-001-s470><carry.tragen><de> Das ist ein Lied, das wir im Traunsteiner Seminar auch oft gesungen haben und das mich wieder in meine frühe Jugend zurückversetzt und so die ganze Freude am Herrn und an der Muttergottes wieder spüren läßt, die wir damals und jetzt in uns getragen haben und tragen.
<G-vec00241-001-s471><carry.tragen><en> Its exclusive design makes Hippo a real gem in your home or garden; it is easy to carry so that you can be close to your baby at all times.
<G-vec00241-001-s471><carry.tragen><de> Das exklusive Design macht Hippo zu einem echten Schmuckstück im Haus oder im Garten, es kann einfach und leicht getragen werden, damit man sein Baby immer bei sich in der Nähe hat.
<G-vec00241-001-s472><carry.tragen><en> Buddhist monks will carry the lantern _ by foot _ south and west during the next three weeks, passing through California, Arizona and part of New Mexico.
<G-vec00241-001-s472><carry.tragen><de> Während der kommenden drei Wochen wird sie von buddhistischen Mönchen getragen, die – zu Fuß – Kalifornien, Arizona und Teile New Mexicos durchqueren.
<G-vec00241-001-s473><carry.tragen><en> This holster is designed to carry the Guardian Angel 3 concealed.
<G-vec00241-001-s473><carry.tragen><de> Das Holster für den Piexon Guardian Angel 3 wird verdeckt im Hosenbund getragen.
<G-vec00241-001-s474><carry.tragen><en> The remaining families carry the resulting monthly deficit.
<G-vec00241-001-s474><carry.tragen><de> Das dadurch entstehende monatliche Defizit wird von den restlichen Familien getragen.
<G-vec00241-001-s551><carry.mitnehmen><en> In all tours the participants have to carry food and pay the admission to the nationals parks, as it helps to realize the activity in a better way.
<G-vec00241-001-s551><carry.mitnehmen><de> Bei allen Ausflügen müssen die Teilnehmer Verpflegung mitnehmen und den Eintritt zu Nationalparks selbst bezahlen, da dies dazu beiträgt, die Aktivität auf bessere Art und Weise durchzuführen.
<G-vec00241-001-s552><carry.mitnehmen><en> A good friend has just sent me the obituary of columnist William Raspberry, who died while we were in Australia, and I think that two passages quoted from a speech he gave at the University of Virginia in 2006 are good messages for us to carry with us in the coming weeks.
<G-vec00241-001-s552><carry.mitnehmen><de> Ein guter Freund hat mir gerade den Nachruf auf den Kolumnisten William Raspberry geschickt, der starb, als wir in Australien waren, und ich denke, zwei Abschnitte aus der Rede, die er 2006 an der Universität von Virginia hielt, sind eine gute Botschaft, die wir in die nächsten Wochen mitnehmen können.
<G-vec00241-001-s553><carry.mitnehmen><en> Carry in any case sufficient water forward with the trips.
<G-vec00241-001-s553><carry.mitnehmen><de> Bei den Ausflügen auf jeden Fall genügend Wasser mitnehmen.
<G-vec00241-001-s554><carry.mitnehmen><en> Given the mobility of smartphones and tablets, we understand that people you wish to monitor can carry them anywhere they want.
<G-vec00241-001-s554><carry.mitnehmen><de> Angesichts der Mobilität von Smartphones und Tablets wissen wir, dass Personen, die Sie überwachen möchten, sie überall hin mitnehmen können.
<G-vec00241-001-s555><carry.mitnehmen><en> We can put you in touch with robust rickshaw pedicabs that can carry you along with the ride (at a modest fee).
<G-vec00241-001-s555><carry.mitnehmen><de> Wir bringen Sie mit robusten Rikscha-Pedicabs in Kontakt, die Sie mitnehmen können (gegen eine geringe Gebühr).
<G-vec00241-001-s556><carry.mitnehmen><en> With a maximum rated overall weight of 149 kg, riders can be a little heavier, or could carry more luggage.
<G-vec00241-001-s556><carry.mitnehmen><de> Mit einem zulässigem Gesamtgewicht von 149 kg darf Mann oder Frau auch etwas schwerer sein oder etwas mehr Gepäck mitnehmen.
<G-vec00241-001-s557><carry.mitnehmen><en> It shelters a gun Mauser Bk 27 of 27 Misters In operation, Gripen can carry more than 4 T of external loads on six points of fastener.
<G-vec00241-001-s557><carry.mitnehmen><de> Sie schützt eine Kanone Mauser Bk 27 von 27 mm in Operation, Gripen kann mehr als 4 t externe Lasten zu sechs Heimatstandorten mitnehmen.
<G-vec00241-001-s558><carry.mitnehmen><en> This new project was born from the desire of the Clara family to provide you with a unique experience to carry with you forever.
<G-vec00241-001-s558><carry.mitnehmen><de> Dieses neue Projekt entstand aus dem Wunsch der Familie Clara, Ihnen eine einzigartige Erfahrung zu bieten, die Sie für immer mitnehmen werden.
<G-vec00241-001-s559><carry.mitnehmen><en> And with 64 GB of internal memory, this is the perfect Walkman® for music fans who want to carry all their favorite songs wherever they go.
<G-vec00241-001-s559><carry.mitnehmen><de> Und dank der internen Speicherkapazität von 64 GB ist dies der ideale Walkman® für Musikfans, die all ihre Lieblingssongs überall hin mitnehmen möchten.
<G-vec00241-001-s560><carry.mitnehmen><en> Staying safe while browsing the internet has become a concern even for casual users, and it’s especially important for Android owners who carry their devices everywhere they go.
<G-vec00241-001-s560><carry.mitnehmen><de> Sich sicher zu fühlen, während man im Internet surft, ist auch für gelegentliche Benutzer ein Problem geworden, und es ist besonders wichtig für Android-Besitzer, die ihre Geräte überall hin mitnehmen.
<G-vec00241-001-s561><carry.mitnehmen><en> A mast in form of a fiber glass telescope mast for a vertical you can carry forward in almost all cases without problems also with flights (when fishing rod camouflaged).
<G-vec00241-001-s561><carry.mitnehmen><de> Ein Mast in Form eines Fiberglas-Teleskop-Mastes für eine Vertical können Sie in fast allen Fällen problemlos auch bei Flügen (als Angelrute getarnt) mitnehmen.
<G-vec00241-001-s562><carry.mitnehmen><en> Carry on bags: You are allowed one carry on which must fit in the overhead compartment.
<G-vec00241-001-s562><carry.mitnehmen><de> Handgepäck: Du darfst ein Handgepäckstück mitnehmen, das in die Gepäckablage passen muss.
<G-vec00241-001-s563><carry.mitnehmen><en> We can carry more passengers, offer them greater comfort and also improve usability for people with reduced mobility.
<G-vec00241-001-s563><carry.mitnehmen><de> Wir können mehr Fahrgäste mitnehmen, wir bieten ihnen deutlich mehr Komfort und wir verbessern die Nutzbarkeit für mobilitätseingeschränkte Menschen.
<G-vec00241-001-s564><carry.mitnehmen><en> You can only carry a pet in a closed container.
<G-vec00241-001-s564><carry.mitnehmen><de> Sie dürfen nur ein Haustier in einer verschlossenen Transportbox mitnehmen.
<G-vec00241-001-s565><carry.mitnehmen><en> Who can carry one forward iPod, also like the Xda orbit can carry forward a small PDA - has then in addition, all important functions at hand.
<G-vec00241-001-s565><carry.mitnehmen><de> Wer einen iPod mitnehmen kann, kann auch einen kleinen PDA wie den Xda Orbit mitnehmen – hat dann aber auch alle wichtigen Funktionen griffbereit.
<G-vec00241-001-s566><carry.mitnehmen><en> Who can carry one forward iPod, also like the Xda orbit can carry forward a small PDA - has then in addition, all important functions at hand.
<G-vec00241-001-s566><carry.mitnehmen><de> Wer einen iPod mitnehmen kann, kann auch einen kleinen PDA wie den Xda Orbit mitnehmen – hat dann aber auch alle wichtigen Funktionen griffbereit.
<G-vec00241-001-s567><carry.mitnehmen><en> In the shape of a suitcase, carry and protect your iPhone 8 / iPhone 7 wherever you go.
<G-vec00241-001-s567><carry.mitnehmen><de> In Form eines Koffers können Sie Ihr iPhone 8 / iPhone 7 überall hin mitnehmen und schützen.
<G-vec00241-001-s568><carry.mitnehmen><en> Differently than the firmly blocked systems of the automakers PNAs („portable navigation Assistants “) can be used flexibly: Who drives for example with the car into the vacation and breaks open there to a Radtour, can develop its PNA forward with few handles and on the trip carry.
<G-vec00241-001-s568><carry.mitnehmen><de> Anders als die fest verbauten Systeme der Autohersteller lassen sich PNAs („Portable Navi-gation Assistants“) flexibel nutzen: Wer zum Beispiel mit dem Auto in den Urlaub fährt und dort zu einer Radtour aufbricht, kann seinen PNA mit wenigen Handgriffen ausbauen und auf den Ausflug mitnehmen.
<G-vec00241-001-s569><carry.mitnehmen><en> However, if you want to be able to provide an explanation or proof in the event of any questions about the different surnames, carry a birth certificate in several languages with you.
<G-vec00241-001-s569><carry.mitnehmen><de> Wenn Sie bei möglichen Fragen jedoch Erklärungen oder Beweise über den unterschiedlichen Nachnamen geben wollen, können Sie einen mehrsprachigen Auszug aus der Geburtsurkunde mitnehmen.
<G-vec00241-001-s608><carry.tragen><en> I wish all of you dear brothers and sisters whom I carry in my Bishop's heart, a new year 2004, which will remove all obstacles on the Path of Love who is Christ.
<G-vec00241-001-s608><carry.tragen><de> Euch allen, liebe Schwestern und Brüder, die ich in meinem Hirtenherzen trage, wünsche ich für das Jahr 2004, dass alle Hindernisse auf dem Weg der Liebe, der Christus ist, beseitigt werden mögen.
<G-vec00241-001-s609><carry.tragen><en> "Being father of a daughter and a son, ""the backpack I carry has become bigger and heavier,"" Robert admits."
<G-vec00241-001-s609><carry.tragen><de> "Als Vater einer Tochter und eines Sohns sei ""der Rucksack, den ich trage, größer und schwerer geworden"", räumt Robert ein."
<G-vec00241-001-s610><carry.tragen><en> For the kind of ministry that I carry not always live in my home diocese, which are, however, associated, as in similar situations to my several priests dedicated to particular activities.
<G-vec00241-001-s610><carry.tragen><de> Für die Art des Dienstes, die ich trage nicht immer leben in meiner Heimatdiözese, die sind aber verbunden, wie in ähnlichen Situationen zu meinem mehrere Priester für bestimmte Tätigkeiten gewidmet.
<G-vec00241-001-s611><carry.tragen><en> Carry this garden with you today in your mind.
<G-vec00241-001-s611><carry.tragen><de> Trage diesen Garten heute in deinem Sinn mit dir.
<G-vec00241-001-s612><carry.tragen><en> ” In Saint Ephraim the Syrian’s Hymns on the Nativity, from the mid-fourth century, using imagery that recalls Revelation 12:4, Mary seems to foretell the conveyance of her body to heaven, saying, “ The Babe that I carry has carried me … .
<G-vec00241-001-s612><carry.tragen><de> In St. Ephraim die syrische der Hymns auf die Geburt Christi, Von der Mitte des vierten Jahrhunderts, Verwendung von Bildmaterial, das erinnert Offenbarung 12:4, Mary scheint die Beförderung ihres Körpers in den Himmel zu foretell, Sprichwort, “Das Baby, das ich trage hat mich durch … .
<G-vec00241-001-s613><carry.tragen><en> That is to say all of you, the Oneness I carry in My heart.
<G-vec00241-001-s613><carry.tragen><de> Damit möchte Ich sagen, alle von euch trage Ich, das Einssein trage Ich in Meinem Herzen.
<G-vec00241-001-s614><carry.tragen><en> Carry on a legacy or just celebrate good memories. 8.
<G-vec00241-001-s614><carry.tragen><de> Trage ihr Vermächtnis weiter oder feiere einfach die guten Erinnerungen.
<G-vec00241-001-s615><carry.tragen><en> Carry your MacBook in a custom sleeve.
<G-vec00241-001-s615><carry.tragen><de> Trage deinen MacBook in einer selbstentworfenen Tasche.
<G-vec00241-001-s616><carry.tragen><en> I still carry with me the starry sky and the fireflies that rejoice the lawn, in the afternoons spent at the pool, without omitting the cinquettio of the birds that welcome the morning awakening.
<G-vec00241-001-s616><carry.tragen><de> Ich trage immer noch bei mir die Sterne und Glühwürmchen, die den Rasen erhellt nach dem Abendessen am Pool verbracht, ohne das Zwitschern der Vögel Weglassen, der das Erwachen am Morgen begrüßen.
<G-vec00241-001-s617><carry.tragen><en> You take a gun, hunt a deer, gut it, carry it home...and follow the cooking instructions .
<G-vec00241-001-s617><carry.tragen><de> Man nehme eine Flinte, jage einen Hirsch, weide ihn aus, trage ihn nach Hause... und folge der Rezeptbeschreibung .
<G-vec00241-001-s618><carry.tragen><en> I call on my children, the true faithful, those who have given themselves to me so that I may lead them to my divine Son, those whom I carry in my arms, so to speak, those who have lived on my spirit.
<G-vec00241-001-s618><carry.tragen><de> Ich rufe auf meine Kinder, meine wahren Frommen; jene, die sich mir hingegeben haben, damit ich sie zu meinem göttlichen Sohn führe; jene, die ich sozusagen in meinen Armen trage; jene, die von meinem Geiste gelebt haben.
<G-vec00241-001-s619><carry.tragen><en> I carry it there and clean it with a garden hose, hoping that I can spread it out to dry it in the sun somewhere in the afternoon.
<G-vec00241-001-s619><carry.tragen><de> Ich trage es dorthin und spritze es mit einem Gartenschlauch wieder sauber, in der Hoffnung, dass ich es irgendwo am Tag trocknen lassen kann.
<G-vec00241-001-s620><carry.tragen><en> And he said to the servant, Carry him to his mother.
<G-vec00241-001-s620><carry.tragen><de> Und er sprach zu dem Knechte: Trage ihn zu seiner Mutter.
<G-vec00241-001-s621><carry.tragen><en> Carry love, and you carry confidence.
<G-vec00241-001-s621><carry.tragen><de> Trage Liebe bei dir, und du trägst Zutrauen bei dir.
<G-vec00241-001-s622><carry.tragen><en> Do not pick up life and carry it every which way.
<G-vec00241-001-s622><carry.tragen><de> Lies das Leben nicht auf und trage es nicht auf jedwedem Weg mit dir herum.
<G-vec00241-001-s623><carry.tragen><en> I draw, and it's what I carry inside me, my own way of seeing the world.
<G-vec00241-001-s623><carry.tragen><de> Ich zeichne, und es ist das, was ich in mir trage – es ist also meine Art, die Welt zu sehen.
<G-vec00241-001-s624><carry.tragen><en> 40 Jonathan gave his weapons to his boy, and said to him, “Go, carry them to the city.”
<G-vec00241-001-s624><carry.tragen><de> 40 Da gab Jonathan seine Waffen seinem Knaben und sprach zu ihm: Gehe hin und trage sie in die Stadt.
<G-vec00241-001-s625><carry.tragen><en> Until you are more used to it, carry My Name and mark it down before and after what you do and say until you do not need to carry it.
<G-vec00241-001-s625><carry.tragen><de> Bis du es deutlicher gewohnt bist, trage Meinen Namen und schreibe ihn nieder, bevor und nachdem du etwas tust und sagst, so lange, bis du ihn nicht mehr zu tragen brauchst.
<G-vec00241-001-s626><carry.tragen><en> Omnia mea mecum porto – I carry all my possessions with me.
<G-vec00241-001-s626><carry.tragen><de> Omnia mea mecum porto - All meinen Besitz trage ich bei mir.
<G-vec00241-001-s627><carry.tragen><en> Companies that were rated by their employees as an employer with outstanding working conditions carry that title.
<G-vec00241-001-s627><carry.tragen><de> Diesen Titel tragen jene Unternehmen, die von ihren Mitarbeitern als Arbeitgeber mit überragenden Arbeitsbedingungen bewertet wurden und in denen die Beschäftigten höchste Zufriedenheit aufweisen.
<G-vec00241-001-s628><carry.tragen><en> "By the strength of our friendship with the living God we live this manifold ""yes"" and at the same time we carry it as a signpost into this world of ours today."
<G-vec00241-001-s628><carry.tragen><de> Aus der Kraft unserer Freundschaft mit dem lebendigen Gott heraus leben wir dieses vielfältige Ja und tragen es zugleich als Wegweisung in diese unsere Weltstunde hinein.
<G-vec00241-001-s629><carry.tragen><en> Sing the song of lands from far away Other times and another place The wind can carry us all away from here Charmed in her embrace Leaves turn to red, the nights are getting colder Seasons will change, the clock ticks on Leaves fill the trees as the days are getting warmer, Days turn to years, the clocks ticks on...
<G-vec00241-001-s629><carry.tragen><de> Sing das Lied von weit entfernten Landen, Anderen Zeiten und einem anderen Platz, Der Wind kann uns alle fort von hier tragen Bezaubernd in seiner Umarmung... *Blätter färben sich zu rot, die Nächte werden kälter, Jahreszeiten werden sich ändern, die Uhr tickt weiter... Blätter füllen die Bäume wenn die Tage wärmer werden, Tage werden zu Jahren, die Uhr tickt weiter...
<G-vec00241-001-s630><carry.tragen><en> The cross will be taken from you again as soon as the purpose has been achieved, for I will not let you suffer any longer than necessary, and I will also help you carry it when it seems too heavy for you at times....
<G-vec00241-001-s630><carry.tragen><de> Das Kreuz wird euch wieder abgenommen, sowie der Zweck erreicht ist, denn Ich lasse euch nicht länger leiden, als nötig ist, und Ich helfe es euch auch tragen, wenn es euch zeitweilig zu schwer erscheint....
<G-vec00241-001-s631><carry.tragen><en> Pilgrims carry rocks of different sizes, forming the so-called apachetas, to symbolize the sins of the devout.
<G-vec00241-001-s631><carry.tragen><de> Die Pilger tragen Steine verschiedener Größen mit denen sie die so genannten Apachetas(Kapellen der Inka) errichten, die die Sünden der Gläubigen symbolisieren.
<G-vec00241-001-s632><carry.tragen><en> Remember to carry water, the Vercors offers very few surface springs.
<G-vec00241-001-s632><carry.tragen><de> Denken Sie daran, Wasser zu tragen, die Vercors bietet nur sehr wenige Oberflächenquellen.
<G-vec00241-001-s633><carry.tragen><en> This is what happens when we try to get a perfect match for the image that we carry inside us.
<G-vec00241-001-s633><carry.tragen><de> So etwas geschieht, wenn wir versuchen, ein perfektes Pendant für das Bild zu finden, das wir in uns tragen.
<G-vec00241-001-s634><carry.tragen><en> Mini bag for multipurpose, to carry any accessory.
<G-vec00241-001-s634><carry.tragen><de> Minitasche mit Mehrzwecktuch, um Zubehör zu tragen.
<G-vec00241-001-s635><carry.tragen><en> Carry bear spray and know how to use it.
<G-vec00241-001-s635><carry.tragen><de> Tragen Sie ein Bärenspray mit sich und machen sich mit der Anwendung vertraut.
<G-vec00241-001-s636><carry.tragen><en> Its rotating center will help you calm down and relax can have him mantras you carry recitations.
<G-vec00241-001-s636><carry.tragen><de> Seine Drehzentrum wird Ihnen helfen, beruhigen und entspannen kann ihn haben Mantras Sie Rezitationen tragen.
<G-vec00241-001-s637><carry.tragen><en> "15:2 Then David said, ""No one but the Levites may carry the ark of God, because the Lord chose them to carry the ark of the Lord and to minister before him forever."""
<G-vec00241-001-s637><carry.tragen><de> 15:2 Damals sprach David: Die Lade Gottes soll niemand tragen außer den Leviten; denn diese hat der HERR erwählt, daß sie die Lade des HERRN tragen und ihm dienen allezeit.
<G-vec00241-001-s638><carry.tragen><en> "15:2 Then David said, ""No one but the Levites may carry the ark of God, because the Lord chose them to carry the ark of the Lord and to minister before him forever."""
<G-vec00241-001-s638><carry.tragen><de> 15:2 Damals sprach David: Die Lade Gottes soll niemand tragen außer den Leviten; denn diese hat der HERR erwählt, daß sie die Lade des HERRN tragen und ihm dienen allezeit.
<G-vec00241-001-s639><carry.tragen><en> I thank the young people who will now carry this Cross, in which we can as it were touch the mystery of Jesus on the highways of the world.
<G-vec00241-001-s639><carry.tragen><de> Ich danke den Jugendlichen, die dieses Kreuz, in dem wir das Geheimnis Jesu gleichsam berühren können, jetzt durch die Straßen der Welt tragen werden.
<G-vec00241-001-s640><carry.tragen><en> Carry a bare laptop and keep sensitive documents on your work PC, while still having total access to them with Laplink Everywhere. 4.
<G-vec00241-001-s640><carry.tragen><de> Tragen Sie einen nackten Laptop und bewahren Sie vertrauliche Dokumente auf Ihrem Arbeits-PC auf, während Sie mit Laplink Everywhere immer noch uneingeschränkten Zugriff darauf haben.
<G-vec00241-001-s641><carry.tragen><en> It is with embosses the unit pairing chocolate by the convertor seal machine to carry on the packing,after its packing product contour artistic,the colored design is bright, stereoscopic effect.
<G-vec00241-001-s641><carry.tragen><de> Es ist mit der Einheit Pairing Schokolade Prägungen durch die Konverter Beutelmaschine auf der Verpackung zu tragen, nach der Verpackung Produktkontur künstlerisch, die farbige Gestaltung hellt, stereoskopischer Effekt ist.
<G-vec00241-001-s642><carry.tragen><en> Often parents, trying to soothe a crying child, take him in their arms and carry it, swaying and entertaining.
<G-vec00241-001-s642><carry.tragen><de> Oft Eltern, die versuchen, ein weinendes Kind zu beruhigen, nehmen es in die Arme und tragen es schwankend und unterhaltsam.
<G-vec00241-001-s643><carry.tragen><en> Their LED screens frequently carry diverse images in the series of “The Art of Outdoor”, an interactive program that includes direct participation of the public in creative festivals.
<G-vec00241-001-s643><carry.tragen><de> Ihre LED-Bildschirme tragen häufig verschiedene Bilder in der Reihe „The Art of Outdoor“, ein interaktives Programm, das direkte Teilnahme der Öffentlichkeit in den kreativen Festivals umfasst.
<G-vec00241-001-s644><carry.tragen><en> If you want to carry the baby on your back, the baby insert can also be easily used on your back.
<G-vec00241-001-s644><carry.tragen><de> Wenn man das Baby auf dem Rücken tragen möchte, lässt sich der Babyeinsatz auch ganz einfach am Rücken einsetzen.
<G-vec00241-001-s645><carry.tragen><en> Rpte: WernerGood morning, we are a company with 10 years of market specialized in computers and computer ergonomic accessories, and other items to large supermarket chains and department stores, we want to expand our business in your country, where we seek a partnership with a representative to carry out work in this country.
<G-vec00241-001-s645><carry.tragen><de> Rpte: WernerGuten Morgen, wir sind eine Firma mit 10 Jahren der Markt in Computern und Computer-Ergonomie Zubehör und andere Einzelteile zu großen Supermarktketten und Warenhäuser spezialisiert, um unser Geschäft in Ihrem Land, in dem wir suchen, eine Partnerschaft mit einem Vertreter zu tragen erweitern möchten wir Arbeiten in diesem Land.
<G-vec00241-001-s646><carry.tragen><en> Just prior to the pole shift and post pole shift carry as much salt in the bottom of your pack as you can fit.
<G-vec00241-001-s646><carry.tragen><de> Genau vor dem Polsprung und nach dem Polsprung tragt soviel Salz unten in eurem Rucksack wie es euch paßt.
<G-vec00241-001-s647><carry.tragen><en> And carry the Cross of Jesus Christ.
<G-vec00241-001-s647><carry.tragen><de> Und tragt das Kreuz Jesu Christi.
<G-vec00241-001-s648><carry.tragen><en> In this way, also you, little children, grow in Gods love and carry it to all those who are far from God.
<G-vec00241-001-s648><carry.tragen><de> So wachst auch ihr, meine lieben Kinder, in der Liebe Gottes und tragt sie zu all jenen, die fern von Gott sind.
<G-vec00241-001-s649><carry.tragen><en> Now drop off the suitcases of yesteryear and no longer carry them with you.
<G-vec00241-001-s649><carry.tragen><de> Lasst nunmehr die Koffer des letzten Jahres fallen und tragt sie nicht mehr länger mit euch herum.
<G-vec00241-001-s650><carry.tragen><en> RH). It has taken many ages for you to incorporate the distorted energy you now carry.
<G-vec00241-001-s650><carry.tragen><de> Es hat viele Zeitalter gedauert, die verzerrten Energien, die Ihr nun tragt, aufzunehmen.
<G-vec00241-001-s651><carry.tragen><en> If you carry Jesus in your innocent hearts and walk with Him in personal relationship through intimate prayers and reception of sacraments, especially the Holy Eucharist, where you can be one with Him; you have nothing to fear.
<G-vec00241-001-s651><carry.tragen><de> Wenn ihr Jesus in euren unschuldigen Herzen tragt und mit ihm in einer persönlichen Beziehung lebt durch innige Gebete und den Empfang der Sakramente, besonders der Heiligen Eucharistie, wo ihr mit ihm eins sein könnt, braucht ihr nichts zu fürchten.
<G-vec00241-001-s652><carry.tragen><en> Carry out your mission with dignity, and those who believe you will be the ones whom I have chosen to make them My disciples.
<G-vec00241-001-s652><carry.tragen><de> Tragt eure Aufgabe mit Würde, und jene, welche euch glauben, werden diejenigen sein, die Ich erwählt habe, um aus ihnen meine Jünger zu machen.
<G-vec00241-001-s653><carry.tragen><en> The possibilities of illness are always there in your body and around you; you carry within you or there swarm about you the microbes and germs of every disease.
<G-vec00241-001-s653><carry.tragen><de> Krankheitsmöglichkeiten sind stets in eurem Körper und um euch herum vorhanden, da wimmelt es von Keimen und Mikroben, und ihr tragt sie in euch.
<G-vec00241-001-s654><carry.tragen><en> You carry the tent; the tent doesn't carry you.
<G-vec00241-001-s654><carry.tragen><de> Ihr tragt das Zelt; das Zelt trägt nicht euch.
<G-vec00241-001-s655><carry.tragen><en> They were responsible for My words that only I as the Son knew the Father and He Me, although I once personally taught on earth how this knowledge could also be given to you humans, all of whom carry a spark of My divine Self in your hearts, which keeps urging you towards becoming one with Me.
<G-vec00241-001-s655><carry.tragen><de> Sie nötigten Mich zu dem Ausruf, dass nur Ich als Sohn den Vater kenne und Er Mich. Dabei lehrte Ich einst körperlich auf Erden, wie diese Erkenntnis auch euch Menschen, die ihr doch alle einen Funken Meines göttlichen Ichs in eurem Herzen tragt, welcher euch stets zur Vereinigung mit Mir antreibt, gegeben werden könne.
<G-vec00241-001-s656><carry.tragen><en> Take the burden, carry the weight yourself, work life out yourself, and sooner or later you will come up against some tremendous situation with which you cannot cope, and that is the alternative which many have so grievously found.
<G-vec00241-001-s656><carry.tragen><de> Nehmt die Last auf dich, tragt selber das ganze Gewicht, bewältigt das Leben selber, und früher oder später werdet ihr euch einer ungeheuren Situation gegenüber sehen, mit der ihr nicht fertig werdet, und das ist die Alternative, die so viele so schmerzlich vorgefunden haben.
<G-vec00241-001-s657><carry.tragen><en> Yes, you carry light, yet you are not separate from it.
<G-vec00241-001-s657><carry.tragen><de> Ja, ihr tragt das Licht auch, dennoch seid ihr nicht getrennt davon.
<G-vec00241-001-s658><carry.tragen><en> Take this Gospel and carry it with you, to read it often, every day. Carry it in your purse, in your pocket, read from it often, a passage every day.
<G-vec00241-001-s658><carry.tragen><de> Nehmt es und tragt es bei euch, um oft darin zu lesen, um es jeden Tag in der Handtasche, in der Jackentasche zu tragen und jeden Tag einen Abschnitt daraus zu lesen.
<G-vec00241-001-s659><carry.tragen><en> Carry them in your heart and pray for them.
<G-vec00241-001-s659><carry.tragen><de> Tragt sie im Herzen und betet für sie.
<G-vec00241-001-s660><carry.tragen><en> Take care that your dog is always on a leash in public and that you carry a muzzle, especially if you have a larger dog.
<G-vec00241-001-s660><carry.tragen><de> Achten Sie darauf, dass Ihr Hund immer an der Leine ist und Maulkorb tragt in der Öffentlichkeit, besonders wenn Sie einen größeren Hund haben.
<G-vec00241-001-s661><carry.tragen><en> For us, the fact that you carry the message of an ethical alternative out into the world is utterly priceless.
<G-vec00241-001-s661><carry.tragen><de> Dass ihr die Botschaft einer ethischen Alternative hinaus in die Welt tragt, das ist für uns unbezahlbar.
<G-vec00241-001-s662><carry.tragen><en> 4 Carry neither purse nor scrip nor sandals, and salute no one on the way.
<G-vec00241-001-s662><carry.tragen><de> 4 Tragt weder Beutel noch Tasche noch Schuhe und grüßt niemand auf dem Weg.
<G-vec00241-001-s663><carry.tragen><en> Speak about peace and carry peace in your hearts.
<G-vec00241-001-s663><carry.tragen><de> Sprecht vom Frieden und tragt den Frieden in euren Herzen.
<G-vec00241-001-s664><carry.tragen><en> In fact, carry nothing with you.
<G-vec00241-001-s664><carry.tragen><de> Ja, tragt gar nichts mehr herum.
<G-vec00241-001-s665><carry.transportieren><en> The moisture-drain off materials of the adidas adiSTAR shirt have a supporting effect and optimally carry the moisture away from the body.
<G-vec00241-001-s665><carry.transportieren><de> Die feuchtigkeitsableitenden Materialien des adidas adiSTAR Shirts wirken unterstützend und transportieren die Feuchtigkeit optimal vom Körper weg.
<G-vec00241-001-s666><carry.transportieren><en> Carry the chain saw with the engine stopped, the guide bar and cutting chain to the rear, and the muffler away from your body.
<G-vec00241-001-s666><carry.transportieren><de> Transportieren Sie die Kettensäge nur bei ausgeschaltetem Motor; Führungsschiene und Sägekette müssen nach hinten gerichtet sein und der Schalldämpfer weg von Ihrem Körper zeigen.
<G-vec00241-001-s667><carry.transportieren><en> Ve i n s The veins carry the blood back to the heart.
<G-vec00241-001-s667><carry.transportieren><de> Venen Die Venen transportieren das Blut zurück zum Herzen.
<G-vec00241-001-s668><carry.transportieren><en> As they were looking for alternative treatment options after prescription medicine failed to relieve their symptoms, they came up with the idea for an EDC (Every Day Carry) that was discreet and easy to travel with.
<G-vec00241-001-s668><carry.transportieren><de> Nachdem verschreibungspflichtige Medikamente ihre Symptome nicht lindern konnten, waren sie auf der Suche nach alternativen Behandlungsmöglichkeiten und kamen auf die Idee für einen Alltagshelfer, der diskret und einfach zu transportieren war.
<G-vec00241-001-s669><carry.transportieren><en> So that you can easily carry your tables and chairs.
<G-vec00241-001-s669><carry.transportieren><de> Damit können Sie problemlos Ihre Tische und Stühle transportieren.
<G-vec00241-001-s670><carry.transportieren><en> The foldable handle has an ergonomic shape and the entire megaphone is extremely light, making it very easy to carry and use the speaker.
<G-vec00241-001-s670><carry.transportieren><de> Der klappbare Griff hat eine ergonomische Form und das gesamte Megafon ein äußerst geringes Gewicht, dadurch lässt sich der Lautsprecher sehr leicht transportieren und auch verwenden.
<G-vec00241-001-s671><carry.transportieren><en> "With its 6.5"" woofer and 3/4"" drivers for the highs are the absolute tops very easy to carry lightweight and ultra compact design and install."
<G-vec00241-001-s671><carry.transportieren><de> "Mit ihrem 6,5""-Woofer und den 3/4""-Treibern für die Höhen sind die Topteile absolute Leichtgewichte und durch die ultrakompakten Abmessungen sehr leicht zu transportieren und aufzustellen."
<G-vec00241-001-s672><carry.transportieren><en> The same support has a little place to save a SD memory, to you carry it to everywhere. Reviews
<G-vec00241-001-s672><carry.transportieren><de> Dieser selbe Träger verfügt einen kleinen Raum, um eine sd-Karte zu behalten, damit du es mit Ihnen transportieren kannst.
<G-vec00241-001-s673><carry.transportieren><en> In this context, large rivers obviously play a particularly large role - not only because they also carry a comparatively large volume of waste on account of their larger discharge.
<G-vec00241-001-s673><carry.transportieren><de> Dabei spielen große Flüsse offenbar eine besonders große Rolle - und das nicht nur, weil sie aufgrund ihres größeren Abflusses im Vergleich auch mehr Müll transportieren.
<G-vec00241-001-s674><carry.transportieren><en> Minerals: as the Iron, it is very important to fight anemia and carry oxygen to the tissues, and Magnesium, indicated to improve the muscle function and to relax the stress.
<G-vec00241-001-s674><carry.transportieren><de> Mineralien: als das Eisen, sehr wichtig zur Bekämpfung der Anämie und transportieren Sauerstoff zu den Geweben, und mg angegeben, zur Verbesserung der Muskelfunktion und Stress zu entspannen.
<G-vec00241-001-s675><carry.transportieren><en> As it can be conveniently folded on the length of a rule, the Tripod is especially easy to carry and find its place in every bag.
<G-vec00241-001-s675><carry.transportieren><de> Auf Grund seiner praktischen Zusammenklappbarkeit auf die Länge eines Zollstocks ist das Stativ besonders leicht zu transportieren und findet in jeder Tasche Platz.
<G-vec00241-001-s676><carry.transportieren><en> The 2-in-1 design allows you to to carry one or both the adapter and power bank.
<G-vec00241-001-s676><carry.transportieren><de> Das 2-in-1 Design ermöglicht Ihnen die Freiheit, den Adapter und die Powerbank einzeln oder zusammen zu transportieren.
<G-vec00241-001-s677><carry.transportieren><en> The grey matter houses the neurons themselves—one way to look at it is the neurons generate the information and the axons carry it to new neurons, which then act on it.
<G-vec00241-001-s677><carry.transportieren><de> Die graue Substanz beherbergt die Neuronen selbst, und man kann sie auf folgende Weise betrachten: Die Neuronen erzeugen Informationen, und die Axone transportieren diese zu neuen Neuronen, die eine entsprechende Wirkung auslösen.
<G-vec00241-001-s678><carry.transportieren><en> In addition, Airwheel Q5 twin-wheel scooter is super easy to carry, fashionable and proves to be pretty safe.
<G-vec00241-001-s678><carry.transportieren><de> Darüber hinaus Airwheel Q5 selbststabilisierendes Einrad Zwillingsbereifung Roller ist super leicht zu transportieren, modische und erweist sich als ziemlich sicher.
<G-vec00241-001-s679><carry.transportieren><en> Arabian slave dealers raged among African people, killed total villages and spared the fittest only, whom they then forced to carry the preyed ivory down to the coast.
<G-vec00241-001-s679><carry.transportieren><de> Arabische Sklavenhändler wüteten in afrikanischen Völkern, brachten ganze Dörfer um und verschonten nur die Kräftigsten, die dann das erbeutete Elfenbein an die Küste transportieren mussten.
<G-vec00241-001-s680><carry.transportieren><en> THE BRUCHE CANAL The waterway was constructed under the direction of Vauban (1681) to carry the materials for building the ramparts and forts circling Strasbourg.
<G-vec00241-001-s680><carry.transportieren><de> Der Kanal der Bruche Wasserstraβe, die unter Vauban (1681) konstruiert wurde, um Baumaterialien zu transportieren, die für die Realisierung von Stadtmauern und Festungen um Straβburg herum bestimmt waren.
<G-vec00241-001-s681><carry.transportieren><en> A small package is convenient, eliminating secondary pollution, and easy to carry when going out and traveling.
<G-vec00241-001-s681><carry.transportieren><de> Ein kleines Paket ist praktisch, beseitigt sekundäre Umweltverschmutzung und ist auf Reisen und auf Reisen leicht zu transportieren.
<G-vec00241-001-s682><carry.transportieren><en> Packaging should be noted that sales of small and beautiful, easy to carry and play to extend the shelf-life role.
<G-vec00241-001-s682><carry.transportieren><de> Verpackung wird darauf hingewiesen, dass der Verkauf von kleinen und schönen, leicht zu transportieren und verlängern die Haltbarkeit Rolle spielen.
<G-vec00241-001-s683><carry.transportieren><en> Specially modified vehicles carry passengers and equipment.
<G-vec00241-001-s683><carry.transportieren><de> Bestimmte, dafür modifizierte Wagen transportieren Touristen und Gepäck.
<G-vec00241-001-s684><carry.tragen><en> These God-given powers carry with them an important responsibility, namely, that man is answerable to God for the choices he makes.
<G-vec00241-001-s684><carry.tragen><de> Diese gottgegebene Freiheit trägt eine wichtige Verantwortung mit sich, nämlich, dass der Mensch für die gemachte Wahl Rechenschaft bei Gott ablegen muss.
<G-vec00241-001-s685><carry.tragen><en> “Nay, let it be!” she said: “I carry them better so balanced.
<G-vec00241-001-s685><carry.tragen><de> “Laßt ihn”, sprach sie; “es trägt sich besser die gleichere Last so.
<G-vec00241-001-s686><carry.tragen><en> When I factor in just the costs of the tickets, then accommodation, transportation and the cost of socialising it will mean that attending will carry a large price tag.
<G-vec00241-001-s686><carry.tragen><de> Wenn ich nur die Kosten für die Tickets berücksichtige, dann bedeutet die Unterbringung, der Transport und die Kosten für die Sozialisierung, dass die Teilnahme einen hohen Preis trägt.
<G-vec00241-001-s687><carry.tragen><en> And, sometimes, we even carry them around with us: on our skin, as a T-shirt print, as a sticker, as a photo in our wallet, as a magazine under our arm, as a logo on our mobile phone display.
<G-vec00241-001-s687><carry.tragen><de> Und bisweilen trägt man sie mit sich herum: auf der Haut, als T-Shirt-Aufdruck, als Aufkleber, als Foto in der Brieftasche, als Zeitschrift unterm Arm, als Motiv auf dem Display eines Mobiltelefons.
<G-vec00241-001-s688><carry.tragen><en> About 1 in 25 people carry this abnormal gene, and the carriers do not have CF or its symptoms, adds the organization.
<G-vec00241-001-s688><carry.tragen><de> Mehr als 1 in 25 Menschen trägt dieses abnorme Gen, und die Träger haben keine ZF oder deren Symptome, fügt die Organisation hinzu.
<G-vec00241-001-s689><carry.tragen><en> And anyone who does not carry his cross and follow me cannot be my disciple.
<G-vec00241-001-s689><carry.tragen><de> und wer nicht sein Kreuz trägt und mir nachkommt, kann nicht mein Jünger sein.
<G-vec00241-001-s690><carry.tragen><en> Everyone has secrets, big or small - you carry them alone or share them.
<G-vec00241-001-s690><carry.tragen><de> Jeder hat Geheimnisse, kleine oder große, man trägt sie allein oder teilt sie.
<G-vec00241-001-s691><carry.tragen><en> The exoskeleton weighs 38 kg, but the user does not carry any of this weight.
<G-vec00241-001-s691><carry.tragen><de> Das Exoskelett wiegt 38 Kilogramm, wobei der Anwender nichts von diesem Gewicht trägt.
<G-vec00241-001-s692><carry.tragen><en> It does not lie within the power of the workers to prevent the petty-bourgeois democrats from doing this; but it does lie within their power to make it as difficult as possible for the petty bourgeoisie to use its power against the armed proletariat, and to dictate such conditions to them that the rule of the bourgeois democrats, from the very first, will carry within it the seeds of its own destruction, and its subsequent displacement by the proletariat will be made considerably easier.
<G-vec00241-001-s692><carry.tragen><de> Es liegt nicht in der Macht der Arbeiter, den kleinbürgerlichen Demokraten dies zu verwehren, aber es liegt in ihrer Macht, ihnen das Aufkommen gegenüber dem bewaffneten Proletariat zu erschweren und ihnen solche Bedingungen zu diktieren, daß die Herrschaft der bürgerlichen Demokraten von vornherein den Keim des Unterganges in sich trägt und ihre spätere Verdrängung durch die Herrschaft des Proletariats bedeutend erleichtert wird.
<G-vec00241-001-s693><carry.tragen><en> On Good Friday afternoon, church bells begin to toll a funereal knell, flags are flown at half-mast and sentries outside official buildings carry reversed arms.
<G-vec00241-001-s693><carry.tragen><de> Am Karfreitag Nachmittag beginnen Kirchenglocken zu Zoll ein trauervolles Glockengeläut, Fahnen sind geflogen an Halbmast und Wachen außerhalb offizieller Gebäude trägt umgekehrte Arme.
<G-vec00241-001-s694><carry.tragen><en> From a number of fertilised egg cells that one is selected which does not carry the disease-causing gene.
<G-vec00241-001-s694><carry.tragen><de> Aus einer Auswahl von mehreren befruchteten Eizellen wird diejenige ausgewählt, die das entsprechende krankmachende Gen nicht trägt.
<G-vec00241-001-s695><carry.tragen><en> There is hardly a path left that doesn't already carry his tire print.
<G-vec00241-001-s695><carry.tragen><de> Es gibt kaum noch einen Pfad der nicht schon seinen Reifenabdruck trägt.
<G-vec00241-001-s696><carry.tragen><en> If the function is successful carry flag is clear, else carry flag is set and AX register returns status code and drive will not be in emulation mode.
<G-vec00241-001-s696><carry.tragen><de> Wenn die Funktion tragen Markierungsfahne ist frei erfolgreich ist, trägt sonst Markierungsfahne ist gesetzt und AXT-Registerrückkehrstatus code und -antrieb sind nicht im Emulation Modus.
<G-vec00241-001-s697><carry.tragen><en> And it is the new generation of the world proletariat, which raises the torch of the world socialist revolution, and which will carry it towards victory.
<G-vec00241-001-s697><carry.tragen><de> Es ist die neue Generation des Weltproletariats, die die Fackel der sozialistischen Weltrevolution übernimmt, um sie zum Sieg trägt.
<G-vec00241-001-s698><carry.tragen><en> This is particularly true of the components WEISS has specialised in. Indeed, rotary indexing tables, linear systems and handling units often form the basis of a special machine, the foundations that carry all other components.
<G-vec00241-001-s698><carry.tragen><de> Das gilt besonders für Komponenten, auf die sich WEISS spezialisiert hat: Rundschalttische, Linearsysteme und Handlingeinheiten sind oft genug die Basis einer Sondermaschine, das Fundament, das alle anderen Bauteile trägt.
<G-vec00241-001-s699><carry.tragen><en> In the second year the woody stems carry flowers, and now, berries that ripen unevenly; so one stem can be harvested many times.
<G-vec00241-001-s699><carry.tragen><de> Im zweiten Jahr trägt der holzige Stiel Blüten, Beeren können unregelmäßig reifen; so kann von einem Stiel viele Male geerntet werden.
<G-vec00241-001-s700><carry.tragen><en> Some of the trees carry fruits this month, and to avoid that they are harvested by monkeys or neighbors, our boys from Hilltop and Bawani have gone to Buttala and picked more than 3000 mangoes.
<G-vec00241-001-s700><carry.tragen><de> Ein Teil der Bäume trägt in diesem Monat Früchte und damit die weder von Affen noch von Nachbarn geerntet werden sind unsere Jungs aus Hilltop mit Bawani nach Buttala gefahren und haben mehr als 3000 Früchte gepflückt.
<G-vec00241-001-s701><carry.tragen><en> All the Saints of God are there to protect me, to sustain me and to carry me.
<G-vec00241-001-s701><carry.tragen><de> Die Schar der Heiligen Gottes schützt und stützt und trägt mich.
<G-vec00241-001-s702><carry.tragen><en> Not only does this steroid carry no estrogenic activity, but it can actually act as an anti-estrogen in the body.
<G-vec00241-001-s702><carry.tragen><de> Nicht nur trägt dieses Steroid keine estrogenic Tätigkeit, aber es kann als ein Antiöstrogen im Körper wirklich auftreten.
<G-vec00241-001-s798><carry.übernehmen><en> We will carry out the printing of your wedding cards in our usual first-class quality.
<G-vec00241-001-s798><carry.übernehmen><de> Den Druck der Hochzeitskarte übernehmen wir in gewohnter, erstklassiger Qualität.
<G-vec00241-001-s799><carry.übernehmen><en> It was hauled to the west coast of America, where, as theÂ Clipper V,Â it will carry traffic between Seattle in the USA and Victoria on Vancouver Island (Canada).
<G-vec00241-001-s799><carry.übernehmen><de> "Er wurde an die amerikanische Westküste verholt, wo er zukünftig als ""Clipper V"" den Verkehr zwischen Seattle und Victoria auf Vancouver Island (Kanada) übernehmen wird."
<G-vec00241-001-s800><carry.übernehmen><en> When democracies are failing, or have failed, it is the institutions of civil society that can carry an added burden to help sustain improvements in quality of life.
<G-vec00241-001-s800><carry.übernehmen><de> Wenn Demokratien scheitern oder gescheitert sind, sind es die Institutionen der Zivilgesellschaft, die eine zusätzliche Last übernehmen können, um dazu beizutragen, Verbesserungen in der Lebensqualität zu erhalten.
<G-vec00241-001-s801><carry.übernehmen><en> They must carry the tent and everything that belongs to it.
<G-vec00241-001-s801><carry.übernehmen><de> Sie sollen auch die Weiterbeförderung der Wohnung und ihrer sämtlichen Geräte übernehmen.
<G-vec00241-001-s802><carry.übernehmen><en> If special material tests are required for the calculation task, we will be pleased to carry out the test for you in cooperation with external partners.
<G-vec00241-001-s802><carry.übernehmen><de> Sind spezielle Werkstoffprüfungen für die gestellte Berechnungsaufgabe erforderlich, so übernehmen wir für Sie gerne die Testdurchführung in Zusammenarbeit mit externen Partnern.
<G-vec00241-001-s803><carry.übernehmen><en> The foam projectiles carry out the actual cleaning: They are 15 per cent larger than the inner diameter of the tube or hose to be cleaned.
<G-vec00241-001-s803><carry.übernehmen><de> Die Schaumstoffprojektile übernehmen die eigentliche Reinigung: Da sie rund 15 Prozent größer ausgelegt sind als die Innendurchmesser der zu reinigenden Leitungen, entsteht Reibung, welche Verschmutzungen wirkungsvoll ablöst.
<G-vec00241-001-s804><carry.übernehmen><en> Today's robots can only carry out the same tasks in the same environment.
<G-vec00241-001-s804><carry.übernehmen><de> Heutige Roboter können nur die gleichen Aufgaben im stets gleichen Umfeld übernehmen.
<G-vec00241-001-s805><carry.übernehmen><en> In this case, we might offer to carry a part of the development expenses or alternative license models.
<G-vec00241-001-s805><carry.übernehmen><de> In diesem Fall ist es möglich, dass wir Teile des Entwicklungsaufwands übernehmen oder alternative Lizensierungsformen finden.
<G-vec00241-001-s806><carry.übernehmen><en> The foam projectiles carry out the actual cleaning: They are 15 per cent larger than the inner diameter of the tube or hose to be cleaned. This creates friction which effectively releases contaminations.
<G-vec00241-001-s806><carry.übernehmen><de> Die Schaumstoffprojektile übernehmen die eigentliche Reinigung: Da sie rund 15 Prozent größer ausgelegt sind als die Innendurchmesser der zu reinigenden Leitungen, entsteht Reibung, welche Verschmutzungen wirkungsvoll ablöst.
<G-vec00241-001-s807><carry.übernehmen><en> You carry never buy Dianabol simply by itself, bear in mind to buy an anti – estrogen along with clomid for the pct, and if you desire a appropriate hardcore pattern then increase Testosterone and perhaps also Deca to your order.
<G-vec00241-001-s807><carry.übernehmen><de> Sie übernehmen nie kaufen Dianabol nur auf seine eigene, denken Sie daran, eine Anti kaufen – Östrogen zusammen mit clomid für die PCT, und wenn Sie eine entsprechende hardcore Muster wünschen, dann gehören Testosteron und vielleicht sogar Deca auf Ihre Bestellung.
<G-vec00241-001-s808><carry.übernehmen><en> During the many years of the persecution that Ms. Zhang has suffered, her husband Chen Dongming had to carry on the tasks of both father and mother.
<G-vec00241-001-s808><carry.übernehmen><de> Während der vielen Jahre an Verfolgung, die Frau Zhang erlitten hat, musste ihre Mann Chen Dongming die Aufgabe übernehmen, gleichzeitig Vater und Mutter zu sein.
<G-vec00241-001-s809><carry.übernehmen><en> We carry out transportation of liquid chemicals in road tankers, capacity from 24,000 to 37,000 litres, in single and triple chamber configuration, with breakwaters.
<G-vec00241-001-s809><carry.übernehmen><de> Wir übernehmen den Transport von Flüssigchemikalien in Tanklastwagen mit einem Fassungsvermögen zwischen 24.000 und 37.000 Litern in Ein- bis Dreikammerkonfiguration mit Schwallwänden.
<G-vec00241-001-s810><carry.übernehmen><en> Beyond enumerating rights, the Commission argued for a new clarity about who should carry out the corresponding duties, and how.
<G-vec00241-001-s810><carry.übernehmen><de> Neben der Neuanordnung der Rechte sprach sich die Kommission für eine Klärung dessen aus, wer die damit zusammenhängenden Pflichten übernehmen soll und wie sie erfüllt werden müssen.
<G-vec00241-001-s811><carry.übernehmen><en> So two spokes carry out the function of one, slackening and torsion are extremely limited, and the transmission of power from the athlete is much more effective.
<G-vec00241-001-s811><carry.übernehmen><de> Auf diese Weise übernehmen hier zwei Speichen die Funktion einer einzelnen, die Lockerung und Torsion sind extrem gering und die Übertragung der Energie des Athleten ist sehr viel wirksamer.
<G-vec00241-001-s812><carry.übernehmen><en> In most cases, companies carry out distribution of the email themselves. However, some also leave this to HRS too, because transmission via HRS enables valuable analyses, for example how often a training video was viewed or a particular link was clicked.
<G-vec00241-001-s812><carry.übernehmen><de> In den meisten Fällen übernehmen die Firmen den Versand selbst, manche überlassen dies allerdings auch HRS, weil der Versand über HRS wertvolle Auswertungen ermöglicht, etwa wie oft ein Schulungsvideo angesehen oder ein bestimmter Link geklickt wurde.
<G-vec00241-001-s813><carry.übernehmen><en> We carry out intensive preliminary research, work with you to prepare for the negotiations and train your negotiators.
<G-vec00241-001-s813><carry.übernehmen><de> Wir übernehmen die intensive Vorfeld-Recherche, bereiten mit Ihnen gemeinsam die Verhandlungen vor und trainieren Ihre Verhandlungsführer.
<G-vec00241-001-s814><carry.übernehmen><en> As the largest employer in Reinbek, Almirall Hermal GmbH primarily supports municipal organisations or projects that carry out social tasks.
<G-vec00241-001-s814><carry.übernehmen><de> Als größter Arbeitgeber am Standort Reinbek unterstützt die Almirall Hermal GmbH in erster Linie kommunale Einrichtungen oder Projekte, die soziale Aufgaben übernehmen.
<G-vec00241-001-s815><carry.übernehmen><en> Although soils carry out many important tasks in the natural balance and for the supply and nutrition of humans, their protection receives little attention.
<G-vec00241-001-s815><carry.übernehmen><de> Obwohl Böden viele wichtige Aufgaben im Naturhaushalt und für die Versorgung und Ernährung der Menschen übernehmen, wird ihrem Schutz wenig Aufmerksamkeit geschenkt.
<G-vec00241-001-s816><carry.übernehmen><en> Through our solutions we can guarantee you not only efficient warehousing and reliable handling, but we carry out different professional modification work and the maintenance of your machinery, too.
<G-vec00241-001-s816><carry.übernehmen><de> Durch unsere Lösungen garantieren wir Ihnen nicht nur effiziente Lagerhaltung und zuverlässiges Handling, sondern übernehmen auch diverse fachmännische Umbauarbeiten und die Wartung Ihrer Maschinen.
