<G-vec00241-001-s114><carry.befördern><en> 5d4) We will not carry you if you are aged under 14 at the date of travel and are not travelling with someone aged 16 or older on your booking or on a linked booking.
<G-vec00241-001-s114><carry.befördern><de> 5d4) Wir befördern Sie nicht, wenn Sie zum Zeitpunkt der Reise jünger als 14 Jahre sind und Ihre Buchung oder eine verknüpfte Buchung keine mitreisende Person enthält, die mindestens 16 Jahre alt ist.
<G-vec00241-001-s115><carry.befördern><en> In ski resort Lienzer Bergbahnen the 12 lifts can carry 13,000 people per hour.
<G-vec00241-001-s115><carry.befördern><de> Im Skigebiet Lienzer Bergbahnen können die 12 Skilifte bis zu 13.000 Personen pro Stunde befördern.
<G-vec00241-001-s116><carry.befördern><en> • Always carry the air mattress in a stuff sack or other protective bag.
<G-vec00241-001-s116><carry.befördern><de> • Matte stets in einem Packsack oder einem anderen Schutzbeutel befördern.
<G-vec00241-001-s117><carry.befördern><en> With the German shipping line Hapag-Lloyd's merger with the Chilean line CSAV, the top four lines in the world, i.e. Maersk, MSC, CMA CGM & Hapag-Lloyd would now carry over 40% of the world's container capacity.
<G-vec00241-001-s117><carry.befördern><de> Mit dem Merger zwischen der deutschen Schifffahrtslinie Hapag-Lloyd mit der chilenischen Reederei CSAV würden die vier größten Linien der Welt, Maersk, MSC, CMA CGM und Hapag-Lloyd mehr als 40% der Containerkapazität der Welt befördern.
<G-vec00241-001-s118><carry.befördern><en> The German railways carry 6.3 million passengers per day in regional transport and 300,000 inter-city passengers.
<G-vec00241-001-s118><carry.befördern><de> Die deutschen Eisenbahnen befördern täglich 6,3 Millionen Fahrgäste, 6 Millionen im Nahverkehr und 300.000 im Fernverkehr.
<G-vec00241-001-s119><carry.befördern><en> Humic substances carry minerals through cell membrane.
<G-vec00241-001-s119><carry.befördern><de> Huminsäure ist im Stande, die anorganischen Spurenelemente durch die Zellmembran zu befördern.
<G-vec00241-001-s120><carry.befördern><en> To carry passengers or goods when this implies subletting vehicle directly or indirectly.
<G-vec00241-001-s120><carry.befördern><de> Güter oder Personen zu befördern, wenn dies direkt oder indirekt die Untervermietung des Fahrzeuges beinhaltet.
<G-vec00241-001-s121><carry.befördern><en> We do carry for free children's buggies and dogs.
<G-vec00241-001-s121><carry.befördern><de> Gerne befördern wir den Kinderwagen sowie Hunde kostenlos.
<G-vec00241-001-s122><carry.befördern><en> The villagers created a bamboo platform with small wheels along a track to carry crops and goods from one village to the next.
<G-vec00241-001-s122><carry.befördern><de> Die Dorfbewohner bauten Plattformen aus Bambus, an denen sie kleine Räder befestigten, um Getreide und Güter von einem Dorf zum nächsten befördern zu können.
<G-vec00241-001-s123><carry.befördern><en> The ten modern lifts carry nearly 11.000 people uphill per hour.
<G-vec00241-001-s123><carry.befördern><de> Die zehn modernen Lifte befördern in der Stunde insgesamt beinahe 11.000 Personen bergwärts.
<G-vec00241-001-s124><carry.befördern><en> In the cabin of aircraft allowed to carry up to 7 kg of hand luggage per passenger.
<G-vec00241-001-s124><carry.befördern><de> In der Kabine von Flugzeugen erlaubt, bis zu 7 kg Handgepäck pro Passagier zu befördern.
<G-vec00241-001-s125><carry.befördern><en> Today jet planes carry more than five billion passengers worldwide.
<G-vec00241-001-s125><carry.befördern><de> Heute befördern Düsenjets weltweit jährlich mehr als fünf Milliarden Passagiere.
<G-vec00241-001-s126><carry.befördern><en> To carry persons or goods without having obtained the corresponding official permits.
<G-vec00241-001-s126><carry.befördern><de> Güter oder Personen zu befördern, ohne hierfür die erforderlichen Genehmigungen vorliegen zu haben.
<G-vec00241-001-s127><carry.befördern><en> At the right time His intention will then begin to shine out, and I and all those like me will immediately fully take in the same into our being and carry it into all infinity; therefore we also carry the name ‘supreme messengers’, because we are the bearers and executers of the divine will.
<G-vec00241-001-s127><carry.befördern><de> Zur rechten Zeit wird dann Sein Wille schon nach außen hinaus zu strahlen anfangen, und ich und alle meinesgleichen werden denselben alsogleich in uns völlig aufnehmen und ihn befördern in alle Unendlichkeit hinaus; darum führen wir auch eigenschaftlich den Namen,Erzboten‘, weil wir die Austräger und die Auswirker des göttlichen Willens sind.
<G-vec00241-001-s128><carry.befördern><en> With the pull cart can carry easily the utensils and the food for the day.
<G-vec00241-001-s128><carry.befördern><de> Mit dem Ziehwagen können Sie auf einfache Weise die Untensilien und das Essen für den Tag befördern.
<G-vec00241-001-s129><carry.befördern><en> We recently developed a kind of small Unimog for Africa that can carry passengers and goods for 80 kilometres on one battery charge.
<G-vec00241-001-s129><carry.befördern><de> Vor Kurzem haben wir eine Art kleinen Unimog für Afrika entwickelt, der Personen und Güter mit einer Batterieladung 80 Kilometer weit befördern kann.
<G-vec00241-001-s130><carry.befördern><en> It may happen that goods are available, that all the possibilities exist for expanding trade turnover, but transport cannot keep up with the development of trade turnover and refuses to carry the freight.
<G-vec00241-001-s130><carry.befördern><de> Es kann vorkommen, dass Waren vorhanden sind, dass die volle Möglichkeit besteht, den Warenumsatz zu entfalten, das Verkehrswesen aber nicht mit der Entwicklung des Warenumsatzes Schritt hält und nicht imstande ist, die Güter zu befördern.
<G-vec00241-001-s131><carry.befördern><en> It has the advantage that one can carry something in it, even if it's only air and it transports a visible message in the print on it.
<G-vec00241-001-s131><carry.befördern><de> Sie hat den Vorteil, dass man etwas in ihr befördern kann, selbst wenn es nur Luft ist und dass sie per Aufdruck eine deutlich sichtbare Botschaft vermittelt.
<G-vec00241-001-s132><carry.befördern><en> Now, the scientists at the DLR Institute of Planetary Research are waiting with bated breath for other instruments, among them the spectrometer VIRTIS, in which they were contributing partners, to deliver data on the gases that carry the dust particles from the surface of the comet into space.
<G-vec00241-001-s132><carry.befördern><de> Die Wissenschaftler des DLR-Institut für Planetenforschung warten nun mit Spannung darauf, dass weitere Instrumente wie das Spektrometer VIRTIS, an denen sie beteiligt sind, Daten zu den Gasen liefern, die die Staubteilchen von der Kometenoberfläche ins All befördern.
<G-vec00241-001-s399><carry.führen><en> Furthermore, we regularly carry out individual improvement projects in purchasing, production and logistics on site at our suppliers in order to constantly improve our efficient skills network.
<G-vec00241-001-s399><carry.führen><de> Darüber hinaus führen wir regelmäßig individuelle Verbessungsprojekte in den Bereichen Einkauf, Produktion und Logistik vor Ort bei unseren Lieferanten durch, um so unser effektives Kompetenznetzwerk kontinuierlich zu stärken.
<G-vec00241-001-s400><carry.führen><en> We carry all important brands in the areas furniture, closets, beds, shelves, armchairs and sofas, outdoor, carpets, crockery, and gifts .
<G-vec00241-001-s400><carry.führen><de> Wir führen alle wichtigen Hersteller im Bereich Möbel, Schränke, Betten, Regale, Sessel und Sofas, Armlehnstühle, Outdoor, Teppiche, Geschirr und Geschenke .
<G-vec00241-001-s401><carry.führen><en> We are highly competent to advise clients in this area and to carry out migration testing.
<G-vec00241-001-s401><carry.führen><de> Wir beraten Sie gerne und führen für Sie auch eine Lebensmittelunbedenklichkeitsprüfung durch.
<G-vec00241-001-s402><carry.führen><en> Fishing Tackle We carry fishing tackle, lures, equipment and outdoor gear.
<G-vec00241-001-s402><carry.führen><de> Fishing Tackle Wir führen Angelausrüstung, lockt, Ausrüstung und Outdoor-Ausrüstung.
<G-vec00241-001-s403><carry.führen><en> "Since there are several weapons put to use - from knives to giant swords, which you normally would only see Cloud from ""Final Fantasy VII"" carry around - the individual fights are short, concise and coined by tension-building breaks of tactical thinking."
<G-vec00241-001-s403><carry.führen><de> "Da vermehrt Waffen - von Dolchen bis zu riesigen Schwertern, die man sonst nur Cloud aus ""Final Fantasy VII"" mit sich führen sieht - eingesetzt werden, sind die einzelnen Kämpfe kurz, prägnant und von einer spannungsfördernden Pause des Taktierens geprägt."
<G-vec00241-001-s404><carry.führen><en> Parents who first think about how to remove lice from their child, usually carry out this procedure in a big hurry, almost in a panic.
<G-vec00241-001-s404><carry.führen><de> Eltern, die zuerst darüber nachdenken, wie man Läuse von ihrem Kind entfernen kann, führen dieses Verfahren in der Regel in großer Eile aus, fast in Panik.
<G-vec00241-001-s405><carry.führen><en> When you carry from prison to court, is this: even before the rise of the total breakfast, pickling, bending, in the “glass”, transport of Moscow traffic jams - at least 2 hours.
<G-vec00241-001-s405><carry.führen><de> Wenn Sie aus dem Gefängnis zum Gericht führen, ist dies: Schon vor dem Anstieg der gesamten Frühstück-, Beiz-, Biege-, in der “Glas”, der Transport von Moskau Staus - mindestens 2 Stunden.
<G-vec00241-001-s406><carry.führen><en> "Browder presented the agreement of the anti-fascist allies to carry the war against Hitlerite Germany through to the end as the beginning of a new historical epoch, in which socialism and capitalism had found the way to co-operation within ""one and the same world"", as he expressed it."
<G-vec00241-001-s406><carry.führen><de> Die Übereinkunft der anti-faschistischen Allierten, den Kampf gegen das faschistische Deutschland zu Ende zu führen, stellte Browder als den Beginn einer neuen historischen Epoche hin, in der Sozialismus und Kapitalismus im Rahmen ́ einer einheitlichen und gleichartigen Welt`, wie er sich ausdrückte, den Weg der Zusammenarbeit gefunden hätten.
<G-vec00241-001-s407><carry.führen><en> First, you must always carry with you either a handkerchief or paper napkins to be able to regularly clean the nasal cavity.
<G-vec00241-001-s407><carry.führen><de> Zuerst müssen Sie entweder ein Taschentuch oder eine Papierserviette mit sich führen, um die Nasenhöhle regelmäßig reinigen zu können.
<G-vec00241-001-s408><carry.führen><en> We carry also fresh meat, various sausages and salami.
<G-vec00241-001-s408><carry.führen><de> Weiteres führen wir Frischfleisch, verschiedene Wurstwaren, Salami.
<G-vec00241-001-s409><carry.führen><en> Every second, everyday, we carry out hundreds of activities on the internet. Sending and receiving emails, checking social profiles, updating status, uploading photos, paying bills, online shopping and so much more.
<G-vec00241-001-s409><carry.führen><de> Wir führen jede Sekunde, jeden Tag hunderte von Aktivitäten im Internet aus, sei es E-Mails versenden oder empfangen, Social-Media-Profilen folgen, den Status aktualisieren, Fotos hochladen, Rechnungen bezahlen, Online-Shopping und vieles mehr.
<G-vec00241-001-s410><carry.führen><en> You also carry out tests and conformity assessments of products and assemblies on the manufacturer side.
<G-vec00241-001-s410><carry.führen><de> Auch auf Herstellerseite führen Sie Prüfungen und Konformitätsbewertungen von Produkten und Baugruppen durch.
<G-vec00241-001-s411><carry.führen><en> To this end members of the network carry out independent integration projects and underpin them with dedicated sponsorships.
<G-vec00241-001-s411><carry.führen><de> Dazu führen die die teilnehmenden Unternehmen eigenständige Integrationsprojekte durch und untermauern sie mit verbindlichen Patenschaften.
<G-vec00241-001-s412><carry.führen><en> Through RTT the user can carry a text conversation while being called.
<G-vec00241-001-s412><carry.führen><de> Über RTT kann der Benutzer während des Anrufs ein Textgespräch führen.
<G-vec00241-001-s413><carry.führen><en> You should ensure that you understand all the details before you carry the process out.
<G-vec00241-001-s413><carry.führen><de> Sie sollten sicherstellen, dass Sie alle Details verstehen, bevor Sie den Vorgang aus führen.
<G-vec00241-001-s414><carry.führen><en> «Those who know it and those who don't know it, both carry out rituals using this syllable.» But knowledge and ignorance are two very different things.
<G-vec00241-001-s414><carry.führen><de> «Diejenigen, die es wissen, und diejenigen, die es kennen, nicht beide führen Rituale mit dieser Silbe.» Aber wissen und Unwissenheit sind zwei sehr verschiedene Dinge.
<G-vec00241-001-s415><carry.führen><en> We carry out due diligence for target companies with a seat in the entire Adriatic region.
<G-vec00241-001-s415><carry.führen><de> Wir führen Due Diligence bei Zielunternehmen in der gesamten Adria-Region durch.
<G-vec00241-001-s416><carry.führen><en> Scientists of these institutes carry out fruitful fundamental and applied research in computer science and information technology.
<G-vec00241-001-s416><carry.führen><de> Wissenschaftler dieser Institute führen fruchtbare Grundlagen- und angewandte Forschung in Informatik und Informationstechnologie durch.
<G-vec00241-001-s417><carry.führen><en> For that reason, we carry out a series of annual events in the field of NVH, which focus on the exchange of experiences and the active dialog with our customers.
<G-vec00241-001-s417><carry.führen><de> Deshalb führen wir im Bereich NVH jedes Jahr eine Reihe von Veranstaltungen durch, bei denen der Erfahrungsaustausch und der Dialog mit unseren Kunden im Vordergrund stehen.
<G-vec00241-001-s418><carry.führen><en> 12:6 The tents of marauders are undisturbed, and those who provoke God are secure--those who carry their god in their hands.
<G-vec00241-001-s418><carry.führen><de> 12:6 Die Zelte der Verwüster sind in Ruhe, und Sicherheit ist für die, welche Gott reizen, für den, welcher Gott in seiner Hand führt.
<G-vec00241-001-s419><carry.führen><en> The Federal Police carry out the measurement flights and is responsible for the exact positioning of the helicopters in the areas to be mapped.
<G-vec00241-001-s419><carry.führen><de> Die Bundespolizei führt die Messflüge durch und ist für die exakte Positionierung der Hubschrauber in den zu kartierenden Gebieten verantwortlich.
<G-vec00241-001-s420><carry.führen><en> 15.2 TeamSpeak will also carry out the data processing through external service providers.
<G-vec00241-001-s420><carry.führen><de> 15.2 TeamSpeak führt die Datenverarbeitung auch über externe Dienstleister durch.
<G-vec00241-001-s421><carry.führen><en> Membership Committee:Performs activities to support membership growth, ensure adequate representation of members at all levels, carry out member surveys, identify member needs, convey requests/needs of members to other committees and maintain membership metrics.
<G-vec00241-001-s421><carry.führen><de> Mitgliedschaftsausschuss: Wirbt durch Aktivitäten Mitglieder, sorgt für die angemessene Vertretung der Mitglieder auf allen Ebenen, führt Umfragen unter den Mitgliedern durch, erkundet die Bedürfnisse der Mitglieder, leitet Anfragen/Bedürfnisse der Mitglieder an andere Ausschüsse weiter und pflegt die Mitgliedschaftsdaten.
<G-vec00241-001-s422><carry.führen><en> Membership Committee: Â Performs activities to support membership growth, ensure adequate representation of members at all levels, carry out member surveys, identify member needs, convey requests/needs of members to other committees and maintain membership metrics.
<G-vec00241-001-s422><carry.führen><de> Mitgliedschaftsausschuss: Wirbt durch Aktivitäten Mitglieder, sorgt für die angemessene Vertretung der Mitglieder auf allen Ebenen, führt Umfragen unter den Mitgliedern durch, erkundet die Bedürfnisse der Mitglieder, leitet Anfragen/Bedürfnisse der Mitglieder an andere Ausschüsse weiter und pflegt die Mitgliedschaftsdaten.
<G-vec00241-001-s423><carry.führen><en> Carry out the financial valuation of an organization to collaborate in merger and acquisition processes.
<G-vec00241-001-s423><carry.führen><de> Finanz führt die Bewertung einer Organisation in Fusions- und Akquisitionsprozessen zusammenzuarbeiten.
<G-vec00241-001-s424><carry.führen><en> The EU relies on organisations with the right experience to carry out its development projects on the ground.
<G-vec00241-001-s424><carry.führen><de> Die EU führt ihre Entwicklungsprojekte vor Ort mit Hilfe erfahrener Organisationen durch.
<G-vec00241-001-s425><carry.führen><en> carry out CQI-15 auditing of your company or suppliers without any need for costly training, following optionally the AIAG CQI-15 standard questionnaire or a checklist compiled in accordance with specific customer requirements.
<G-vec00241-001-s425><carry.führen><de> führt ohne aufwendige Einarbeitung und innerhalb kürzester Zeit die CQI-15 Auditierung Ihres Unternehmens oder bei Ihren Lieferanten durch, nach AIAG CQI-15 Standardkatalog oder gemäß speziellem Kundenwunsch.
<G-vec00241-001-s426><carry.führen><en> Within the scope of Inga I Voith will carry out a comprehensive rehabilitation program for two generator-turbine units inside the hydropower station.
<G-vec00241-001-s426><carry.führen><de> Im Rahmen von Inga I führt Voith eine umfassende Rehabilitation von zwei Generator-Turbinen-Einheiten des Wasserkraftwerks durch.
<G-vec00241-001-s427><carry.führen><en> Viator accepts no liability for travelers who are refused entry onto a flight or into any country because of the traveler's failure to carry the travel documents required by any airline, authority, or country, including countries the traveler may just be passing through en route to his or her destination.
<G-vec00241-001-s427><carry.führen><de> Viator haftet nicht gegenüber Reisenden, denen der Einstieg in ein Flugzeug oder die Einreise in ein Land verweigert wird, weil der Reisende nicht die Reisedokumente bei sich führt, die von einer Airline, einer Behörde oder einem Land, einschließlich Ländern, die der Reisende auf dem Weg zu seinem Ziel nur durchreist, gefordert werden.
<G-vec00241-001-s428><carry.führen><en> I never know where the current will carry me, but I feel honoured to be allowed to be part of that ocean.
<G-vec00241-001-s428><carry.führen><de> Ich weiß nie, wohin mich der Strom führt, aber ich fühle mich privilegiert und geehrt ein Teil dieses Meeres sein zu dürfen.
<G-vec00241-001-s429><carry.führen><en> It must derive the maintenance measures necessary for its vehicles from the requirements and will carry out the maintenance measures itself or avail itself of maintenance workshops acc. to EU Regulation, with which it concludes contracts.
<G-vec00241-001-s429><carry.führen><de> Sie muss aus den Anforderungen die für ihre Fahrzeuge erforderlichen Instandhaltungsmaßnahmen ableiten und führt die Instandhaltungsmaßnahmen selbst durch oder bedient sich nach EU Verordnung zertifizierten Instandhaltungswerkstätten, mit denen sie entsprechende Verträge abschließt.
<G-vec00241-001-s430><carry.führen><en> “Quality awareness” are always in AODI people’s mind, it is our principle to accordance with and carry out the IATF16949:2016/ISO9001:2005 management system.
<G-vec00241-001-s430><carry.führen><de> „Qualitätsbewusstsein“ ist immer in AODI Verstand der Leute, es ist unser Prinzip nach und führt den IATF16949: 2016 / ISO 9001: 2005-Management-System.
<G-vec00241-001-s431><carry.führen><en> Farmer with tractor is the game in which the farmer will carry our Red trailer by vegetable farm in these works the zor to fulfill the daily norm of picking vegetables.
<G-vec00241-001-s431><carry.führen><de> Landwirt mit Traktor ist das Spiel, in dem der Bauer unser Red Trailer führt, von Gemüse Bauernhof in diesen Arbeiten der Zor, die tägliche Norm der Kommissionierung Gemüse zu erfüllen.
<G-vec00241-001-s432><carry.führen><en> 29 In 2009, Roskosmos will carry out 39 launches of spacecraft.
<G-vec00241-001-s432><carry.führen><de> 29 Im Jahr 2009, Roskosmos führt 39 startet von Raumfahrzeugen.
<G-vec00241-001-s433><carry.führen><en> 4.3 The conformity assessment body shall carry out periodic audits to make sure that the manufacturer maintains and applies the quality system and shall provide the manufacturer with an audit report.
<G-vec00241-001-s433><carry.führen><de> 4.3 Die Konformitätsbewertungsstelle führt regelmäßig Audits durch, um sicherzustellen, dass die Herstellerin das Qualitätssicherungssystem aufrechterhält und anwendet, und übergibt ihm einen entsprechenden Prüfbericht.
<G-vec00241-001-s434><carry.führen><en> An experienced team consisting of a pilot and system operator carry out the flight.
<G-vec00241-001-s434><carry.führen><de> Ein erfahrenes Team bestehend aus Pilot und Systembediener führt die Befliegung durch.
<G-vec00241-001-s435><carry.führen><en> "From his perspective, Scientology's being a ""totalitarian movement,"" thereby ""working against democracy,"" appears to be less momentous than the fact that he has to carry on his battle against Scientology in the USA himself."
<G-vec00241-001-s435><carry.führen><de> "Wobei seine Ansicht, Scientology sei eine ""totalitäre Bewegung"" und damit ""gegen die Demokratie eingestellt"", für die Sekte weniger schwerwiegend zu sein scheint als die Tatsache, dass er seinen Kampf gegen Scientology in den USA selbst führt."
<G-vec00241-001-s436><carry.führen><en> The western route will carry on to Paris and Brussels, the eastern one to Freiburg, Frankfurt and Cologne – taking in Berlin along the way.
<G-vec00241-001-s436><carry.führen><de> Die westliche Route führt über Paris und Brüssel, die östliche über Freiburg, Frankfurt und Köln, daneben ist ein Abstecher nach Berlin geplant.
<G-vec00241-001-s456><carry.tragen><en> It is an appeal that we should all carry out our work of evangelization in great humility, knowing that we are not the first to work in the vineyard of the Lord nor will we be the last.
<G-vec00241-001-s456><carry.tragen><de> Ich rufe dazu auf, dass wir unser Evangelisierungswerk mit großer Demut voranbringen, von dem Wissen getragen, dass wir nicht die ersten sind, die im Weinberg des Herrn arbeiten, und auch nicht die letzten sein werden.
<G-vec00241-001-s457><carry.tragen><en> The verification process is already fully automated, that means there is no need to carry a mail folder from A to B for invoice control.
<G-vec00241-001-s457><carry.tragen><de> Der Prüfprozess ist schon durchautomatisiert, sprich es muss keine Postmappe zur Rechnungskontrolle von A nach B getragen werden.
<G-vec00241-001-s458><carry.tragen><en> Just as if he were to place upright what was overturned, to reveal what was hidden, to show the way to one who was lost, or to carry a lamp into the dark so that those with eyes could see forms, in the same way has Master Ananda — through many lines of reasoning — made the Dhamma clear.
<G-vec00241-001-s458><carry.tragen><de> Gerade so als hätte jemand etwas aufgerichtet was kopfüber war, freigelegt, was verborgen war, einem der den Weg verloren, den Weg gezeigt, oder eine Lampe in die Dunkelheit getragen hätte, sodass jene mit Augen Form sehen können, in selber Weise hat Meister Ananda, durch viele Zeilen der Begründung hindurch, das Dhamma klar gemacht.
<G-vec00241-001-s459><carry.tragen><en> You can significantly increase your performance with the robust BEUMER Parcel Picker® compared to conventional manual unloading: you no longer need to physically lift and carry the packages.
<G-vec00241-001-s459><carry.tragen><de> Der robuste BEUMER Parcel Picker® ermöglicht eine deutliche Leistungssteigerung im Vergleich zur bisher üblichen manuellen Entladung: Packstücke müssen im gesamten Prozess nicht mehr körperlich gehoben und getragen werden.
<G-vec00241-001-s460><carry.tragen><en> Above all lie the strong vocals of Andreas Bunk, which carry the music both hard rocking and also sensitive.
<G-vec00241-001-s460><carry.tragen><de> Und alles das wird vom Gesang von Andreas Bunk getragen, der mit Charisma mal raubeinig rockig, aber auch mal feinfühlig mit starkem Ausdruck, sehr authentisch ist.
<G-vec00241-001-s461><carry.tragen><en> When Jesus carried His cross up Golgotha to be crucified, no one was thinking of the cross as symbolic of a burden to carry.
<G-vec00241-001-s461><carry.tragen><de> Als Jesus sein Kreuz nach Golgatha hinauftrug, um gekreuzigt zu werden, dachte niemand über das Kreuz als Symbol für eine Last, die getragen wird.
<G-vec00241-001-s462><carry.tragen><en> The images embedded in the six cushions are the flowers the living carry through time, believing it will be new and wonderful.
<G-vec00241-001-s462><carry.tragen><de> Die auf den sechs Kissen eingebetteten Erscheinungen sind die Blumen, die von den Lebenden durch die Zeit getragen werden, von der sie glauben, daß sie gar neu und wunderbar wird.
<G-vec00241-001-s463><carry.tragen><en> Some packages are so heavy that three or four women at a time are needed to carry them.
<G-vec00241-001-s463><carry.tragen><de> Manche Pakete sind so schwer, dass sie von drei bis vier Frauen gleichzeitig getragen werden müssen.
<G-vec00241-001-s464><carry.tragen><en> "49:22 This is what the Sovereign LORD says: ""See, I will beckon to the Gentiles, I will lift up my banner to the peoples; they will bring your sons in their arms and carry your daughters on their shoulders."
<G-vec00241-001-s464><carry.tragen><de> 49:22 So spricht der Herr, Jehova: Siehe, ich werde meine Hand zu den Nationen hin erheben, und zu den Völkern hin mein Panier aufrichten; und sie werden deine Söhne im Busen bringen, und deine Töchter werden auf der Schulter getragen werden.
<G-vec00241-001-s465><carry.tragen><en> Just as if he were to place upright what was overturned, to reveal what was hidden, to show the way to one who was lost, or to carry a lamp into the dark so that those with eyes could see forms, in the same way has the Blessed One — through many lines of reasoning — made the Dhamma clear.
<G-vec00241-001-s465><carry.tragen><de> Gerade so, als ob Er aufgerichtet hätte, was umgedreht war, freigelegt, was verdeckt war, den Weg jemandem gezeigt hätte, der verloren war, oder eine Lampe ins Dunkle getragen hätte, sodass jene mit Augen Form sehen könnten, in gleicher Weise hat der Befreite - in vielen Linien der Begründung - das Dhamma klar gemacht.
<G-vec00241-001-s466><carry.tragen><en> Four flange bearings carry the entire weight of the system.
<G-vec00241-001-s466><carry.tragen><de> Das gesamte Gewicht des Systems wird von vier Flanschlagern getragen.
<G-vec00241-001-s467><carry.tragen><en> Campgrounds are accessible by the bus, you never have to carry your luggage very far
<G-vec00241-001-s467><carry.tragen><de> Die Zeltplätze sind mit dem Bus erreichbar, Gepäck braucht nie weit getragen zu werden.
<G-vec00241-001-s468><carry.tragen><en> He bore our sins. He didn't just carry them; he suffered the penalty we deserved.
<G-vec00241-001-s468><carry.tragen><de> Er hat sie nicht nur getragen, sondern auch die Qualen der Strafe ertragen, die wir verdient hätten.
<G-vec00241-001-s469><carry.tragen><en> Just as if he were to place upright what was overturned, to reveal what was hidden, to point out the way to one who was lost, or to carry a lamp into the dark so that those with eyes could see forms, in the same way has Master Ananda — through many lines of reasoning — made the Dhamma clear.
<G-vec00241-001-s469><carry.tragen><de> Gerade so als hätte jemand etwas aufgerichtet was kopfüber war, freigelegt, was verborgen war, einem der den Weg verloren, den Weg gezeigt, oder eine Lampe in die Dunkelheit getragen hätte, sodass jene mit Augen Form sehen können, in selber Weise hat Meister Ananda, durch viele Zeilen der Begründung hindurch, das Dhamma klar gemacht.
<G-vec00241-001-s470><carry.tragen><en> That was a hymn we often used to sing at the Seminary of Traunstein and it takes me back to my early youth, thus enabling me to perceive all the joy in the Lord and in the Mother of God, then as now, which we carry in our hearts.
<G-vec00241-001-s470><carry.tragen><de> Das ist ein Lied, das wir im Traunsteiner Seminar auch oft gesungen haben und das mich wieder in meine frühe Jugend zurückversetzt und so die ganze Freude am Herrn und an der Muttergottes wieder spüren läßt, die wir damals und jetzt in uns getragen haben und tragen.
<G-vec00241-001-s471><carry.tragen><en> Its exclusive design makes Hippo a real gem in your home or garden; it is easy to carry so that you can be close to your baby at all times.
<G-vec00241-001-s471><carry.tragen><de> Das exklusive Design macht Hippo zu einem echten Schmuckstück im Haus oder im Garten, es kann einfach und leicht getragen werden, damit man sein Baby immer bei sich in der Nähe hat.
<G-vec00241-001-s472><carry.tragen><en> Buddhist monks will carry the lantern _ by foot _ south and west during the next three weeks, passing through California, Arizona and part of New Mexico.
<G-vec00241-001-s472><carry.tragen><de> Während der kommenden drei Wochen wird sie von buddhistischen Mönchen getragen, die – zu Fuß – Kalifornien, Arizona und Teile New Mexicos durchqueren.
<G-vec00241-001-s473><carry.tragen><en> This holster is designed to carry the Guardian Angel 3 concealed.
<G-vec00241-001-s473><carry.tragen><de> Das Holster für den Piexon Guardian Angel 3 wird verdeckt im Hosenbund getragen.
<G-vec00241-001-s474><carry.tragen><en> The remaining families carry the resulting monthly deficit.
<G-vec00241-001-s474><carry.tragen><de> Das dadurch entstehende monatliche Defizit wird von den restlichen Familien getragen.
<G-vec00241-001-s551><carry.mitnehmen><en> In all tours the participants have to carry food and pay the admission to the nationals parks, as it helps to realize the activity in a better way.
<G-vec00241-001-s551><carry.mitnehmen><de> Bei allen Ausflügen müssen die Teilnehmer Verpflegung mitnehmen und den Eintritt zu Nationalparks selbst bezahlen, da dies dazu beiträgt, die Aktivität auf bessere Art und Weise durchzuführen.
<G-vec00241-001-s552><carry.mitnehmen><en> A good friend has just sent me the obituary of columnist William Raspberry, who died while we were in Australia, and I think that two passages quoted from a speech he gave at the University of Virginia in 2006 are good messages for us to carry with us in the coming weeks.
<G-vec00241-001-s552><carry.mitnehmen><de> Ein guter Freund hat mir gerade den Nachruf auf den Kolumnisten William Raspberry geschickt, der starb, als wir in Australien waren, und ich denke, zwei Abschnitte aus der Rede, die er 2006 an der Universität von Virginia hielt, sind eine gute Botschaft, die wir in die nächsten Wochen mitnehmen können.
<G-vec00241-001-s553><carry.mitnehmen><en> Carry in any case sufficient water forward with the trips.
<G-vec00241-001-s553><carry.mitnehmen><de> Bei den Ausflügen auf jeden Fall genügend Wasser mitnehmen.
<G-vec00241-001-s554><carry.mitnehmen><en> Given the mobility of smartphones and tablets, we understand that people you wish to monitor can carry them anywhere they want.
<G-vec00241-001-s554><carry.mitnehmen><de> Angesichts der Mobilität von Smartphones und Tablets wissen wir, dass Personen, die Sie überwachen möchten, sie überall hin mitnehmen können.
<G-vec00241-001-s555><carry.mitnehmen><en> We can put you in touch with robust rickshaw pedicabs that can carry you along with the ride (at a modest fee).
<G-vec00241-001-s555><carry.mitnehmen><de> Wir bringen Sie mit robusten Rikscha-Pedicabs in Kontakt, die Sie mitnehmen können (gegen eine geringe Gebühr).
<G-vec00241-001-s556><carry.mitnehmen><en> With a maximum rated overall weight of 149 kg, riders can be a little heavier, or could carry more luggage.
<G-vec00241-001-s556><carry.mitnehmen><de> Mit einem zulässigem Gesamtgewicht von 149 kg darf Mann oder Frau auch etwas schwerer sein oder etwas mehr Gepäck mitnehmen.
<G-vec00241-001-s557><carry.mitnehmen><en> It shelters a gun Mauser Bk 27 of 27 Misters In operation, Gripen can carry more than 4 T of external loads on six points of fastener.
<G-vec00241-001-s557><carry.mitnehmen><de> Sie schützt eine Kanone Mauser Bk 27 von 27 mm in Operation, Gripen kann mehr als 4 t externe Lasten zu sechs Heimatstandorten mitnehmen.
<G-vec00241-001-s558><carry.mitnehmen><en> This new project was born from the desire of the Clara family to provide you with a unique experience to carry with you forever.
<G-vec00241-001-s558><carry.mitnehmen><de> Dieses neue Projekt entstand aus dem Wunsch der Familie Clara, Ihnen eine einzigartige Erfahrung zu bieten, die Sie für immer mitnehmen werden.
<G-vec00241-001-s559><carry.mitnehmen><en> And with 64 GB of internal memory, this is the perfect Walkman® for music fans who want to carry all their favorite songs wherever they go.
<G-vec00241-001-s559><carry.mitnehmen><de> Und dank der internen Speicherkapazität von 64 GB ist dies der ideale Walkman® für Musikfans, die all ihre Lieblingssongs überall hin mitnehmen möchten.
<G-vec00241-001-s560><carry.mitnehmen><en> Staying safe while browsing the internet has become a concern even for casual users, and it’s especially important for Android owners who carry their devices everywhere they go.
<G-vec00241-001-s560><carry.mitnehmen><de> Sich sicher zu fühlen, während man im Internet surft, ist auch für gelegentliche Benutzer ein Problem geworden, und es ist besonders wichtig für Android-Besitzer, die ihre Geräte überall hin mitnehmen.
<G-vec00241-001-s561><carry.mitnehmen><en> A mast in form of a fiber glass telescope mast for a vertical you can carry forward in almost all cases without problems also with flights (when fishing rod camouflaged).
<G-vec00241-001-s561><carry.mitnehmen><de> Ein Mast in Form eines Fiberglas-Teleskop-Mastes für eine Vertical können Sie in fast allen Fällen problemlos auch bei Flügen (als Angelrute getarnt) mitnehmen.
<G-vec00241-001-s562><carry.mitnehmen><en> Carry on bags: You are allowed one carry on which must fit in the overhead compartment.
<G-vec00241-001-s562><carry.mitnehmen><de> Handgepäck: Du darfst ein Handgepäckstück mitnehmen, das in die Gepäckablage passen muss.
<G-vec00241-001-s563><carry.mitnehmen><en> We can carry more passengers, offer them greater comfort and also improve usability for people with reduced mobility.
<G-vec00241-001-s563><carry.mitnehmen><de> Wir können mehr Fahrgäste mitnehmen, wir bieten ihnen deutlich mehr Komfort und wir verbessern die Nutzbarkeit für mobilitätseingeschränkte Menschen.
<G-vec00241-001-s564><carry.mitnehmen><en> You can only carry a pet in a closed container.
<G-vec00241-001-s564><carry.mitnehmen><de> Sie dürfen nur ein Haustier in einer verschlossenen Transportbox mitnehmen.
<G-vec00241-001-s565><carry.mitnehmen><en> Who can carry one forward iPod, also like the Xda orbit can carry forward a small PDA - has then in addition, all important functions at hand.
<G-vec00241-001-s565><carry.mitnehmen><de> Wer einen iPod mitnehmen kann, kann auch einen kleinen PDA wie den Xda Orbit mitnehmen – hat dann aber auch alle wichtigen Funktionen griffbereit.
<G-vec00241-001-s567><carry.mitnehmen><en> In the shape of a suitcase, carry and protect your iPhone 8 / iPhone 7 wherever you go.
<G-vec00241-001-s567><carry.mitnehmen><de> In Form eines Koffers können Sie Ihr iPhone 8 / iPhone 7 überall hin mitnehmen und schützen.
<G-vec00241-001-s568><carry.mitnehmen><en> Differently than the firmly blocked systems of the automakers PNAs („portable navigation Assistants “) can be used flexibly: Who drives for example with the car into the vacation and breaks open there to a Radtour, can develop its PNA forward with few handles and on the trip carry.
<G-vec00241-001-s568><carry.mitnehmen><de> Anders als die fest verbauten Systeme der Autohersteller lassen sich PNAs („Portable Navi-gation Assistants“) flexibel nutzen: Wer zum Beispiel mit dem Auto in den Urlaub fährt und dort zu einer Radtour aufbricht, kann seinen PNA mit wenigen Handgriffen ausbauen und auf den Ausflug mitnehmen.
<G-vec00241-001-s569><carry.mitnehmen><en> However, if you want to be able to provide an explanation or proof in the event of any questions about the different surnames, carry a birth certificate in several languages with you.
<G-vec00241-001-s569><carry.mitnehmen><de> Wenn Sie bei möglichen Fragen jedoch Erklärungen oder Beweise über den unterschiedlichen Nachnamen geben wollen, können Sie einen mehrsprachigen Auszug aus der Geburtsurkunde mitnehmen.
<G-vec00241-001-s608><carry.tragen><en> I wish all of you dear brothers and sisters whom I carry in my Bishop's heart, a new year 2004, which will remove all obstacles on the Path of Love who is Christ.
<G-vec00241-001-s608><carry.tragen><de> Euch allen, liebe Schwestern und Brüder, die ich in meinem Hirtenherzen trage, wünsche ich für das Jahr 2004, dass alle Hindernisse auf dem Weg der Liebe, der Christus ist, beseitigt werden mögen.
<G-vec00241-001-s609><carry.tragen><en> "Being father of a daughter and a son, ""the backpack I carry has become bigger and heavier,"" Robert admits."
<G-vec00241-001-s609><carry.tragen><de> "Als Vater einer Tochter und eines Sohns sei ""der Rucksack, den ich trage, größer und schwerer geworden"", räumt Robert ein."
<G-vec00241-001-s610><carry.tragen><en> For the kind of ministry that I carry not always live in my home diocese, which are, however, associated, as in similar situations to my several priests dedicated to particular activities.
<G-vec00241-001-s610><carry.tragen><de> Für die Art des Dienstes, die ich trage nicht immer leben in meiner Heimatdiözese, die sind aber verbunden, wie in ähnlichen Situationen zu meinem mehrere Priester für bestimmte Tätigkeiten gewidmet.
<G-vec00241-001-s611><carry.tragen><en> Carry this garden with you today in your mind.
<G-vec00241-001-s611><carry.tragen><de> Trage diesen Garten heute in deinem Sinn mit dir.
<G-vec00241-001-s612><carry.tragen><en> ” In Saint Ephraim the Syrian’s Hymns on the Nativity, from the mid-fourth century, using imagery that recalls Revelation 12:4, Mary seems to foretell the conveyance of her body to heaven, saying, “ The Babe that I carry has carried me … .
<G-vec00241-001-s612><carry.tragen><de> In St. Ephraim die syrische der Hymns auf die Geburt Christi, Von der Mitte des vierten Jahrhunderts, Verwendung von Bildmaterial, das erinnert Offenbarung 12:4, Mary scheint die Beförderung ihres Körpers in den Himmel zu foretell, Sprichwort, “Das Baby, das ich trage hat mich durch … .
<G-vec00241-001-s613><carry.tragen><en> That is to say all of you, the Oneness I carry in My heart.
<G-vec00241-001-s613><carry.tragen><de> Damit möchte Ich sagen, alle von euch trage Ich, das Einssein trage Ich in Meinem Herzen.
<G-vec00241-001-s614><carry.tragen><en> Carry on a legacy or just celebrate good memories. 8.
<G-vec00241-001-s614><carry.tragen><de> Trage ihr Vermächtnis weiter oder feiere einfach die guten Erinnerungen.
<G-vec00241-001-s615><carry.tragen><en> Carry your MacBook in a custom sleeve.
<G-vec00241-001-s615><carry.tragen><de> Trage deinen MacBook in einer selbstentworfenen Tasche.
<G-vec00241-001-s616><carry.tragen><en> I still carry with me the starry sky and the fireflies that rejoice the lawn, in the afternoons spent at the pool, without omitting the cinquettio of the birds that welcome the morning awakening.
<G-vec00241-001-s616><carry.tragen><de> Ich trage immer noch bei mir die Sterne und Glühwürmchen, die den Rasen erhellt nach dem Abendessen am Pool verbracht, ohne das Zwitschern der Vögel Weglassen, der das Erwachen am Morgen begrüßen.
<G-vec00241-001-s617><carry.tragen><en> You take a gun, hunt a deer, gut it, carry it home...and follow the cooking instructions .
<G-vec00241-001-s617><carry.tragen><de> Man nehme eine Flinte, jage einen Hirsch, weide ihn aus, trage ihn nach Hause... und folge der Rezeptbeschreibung .
<G-vec00241-001-s618><carry.tragen><en> I call on my children, the true faithful, those who have given themselves to me so that I may lead them to my divine Son, those whom I carry in my arms, so to speak, those who have lived on my spirit.
<G-vec00241-001-s618><carry.tragen><de> Ich rufe auf meine Kinder, meine wahren Frommen; jene, die sich mir hingegeben haben, damit ich sie zu meinem göttlichen Sohn führe; jene, die ich sozusagen in meinen Armen trage; jene, die von meinem Geiste gelebt haben.
<G-vec00241-001-s619><carry.tragen><en> I carry it there and clean it with a garden hose, hoping that I can spread it out to dry it in the sun somewhere in the afternoon.
<G-vec00241-001-s619><carry.tragen><de> Ich trage es dorthin und spritze es mit einem Gartenschlauch wieder sauber, in der Hoffnung, dass ich es irgendwo am Tag trocknen lassen kann.
<G-vec00241-001-s620><carry.tragen><en> And he said to the servant, Carry him to his mother.
<G-vec00241-001-s620><carry.tragen><de> Und er sprach zu dem Knechte: Trage ihn zu seiner Mutter.
<G-vec00241-001-s621><carry.tragen><en> Carry love, and you carry confidence.
<G-vec00241-001-s621><carry.tragen><de> Trage Liebe bei dir, und du trägst Zutrauen bei dir.
<G-vec00241-001-s622><carry.tragen><en> Do not pick up life and carry it every which way.
<G-vec00241-001-s622><carry.tragen><de> Lies das Leben nicht auf und trage es nicht auf jedwedem Weg mit dir herum.
<G-vec00241-001-s623><carry.tragen><en> I draw, and it's what I carry inside me, my own way of seeing the world.
<G-vec00241-001-s623><carry.tragen><de> Ich zeichne, und es ist das, was ich in mir trage – es ist also meine Art, die Welt zu sehen.
<G-vec00241-001-s624><carry.tragen><en> 40 Jonathan gave his weapons to his boy, and said to him, “Go, carry them to the city.”
<G-vec00241-001-s624><carry.tragen><de> 40 Da gab Jonathan seine Waffen seinem Knaben und sprach zu ihm: Gehe hin und trage sie in die Stadt.
<G-vec00241-001-s625><carry.tragen><en> Until you are more used to it, carry My Name and mark it down before and after what you do and say until you do not need to carry it.
<G-vec00241-001-s625><carry.tragen><de> Bis du es deutlicher gewohnt bist, trage Meinen Namen und schreibe ihn nieder, bevor und nachdem du etwas tust und sagst, so lange, bis du ihn nicht mehr zu tragen brauchst.
<G-vec00241-001-s626><carry.tragen><en> Omnia mea mecum porto – I carry all my possessions with me.
<G-vec00241-001-s626><carry.tragen><de> Omnia mea mecum porto - All meinen Besitz trage ich bei mir.
<G-vec00241-001-s627><carry.tragen><en> Companies that were rated by their employees as an employer with outstanding working conditions carry that title.
<G-vec00241-001-s627><carry.tragen><de> Diesen Titel tragen jene Unternehmen, die von ihren Mitarbeitern als Arbeitgeber mit überragenden Arbeitsbedingungen bewertet wurden und in denen die Beschäftigten höchste Zufriedenheit aufweisen.
<G-vec00241-001-s628><carry.tragen><en> "By the strength of our friendship with the living God we live this manifold ""yes"" and at the same time we carry it as a signpost into this world of ours today."
<G-vec00241-001-s628><carry.tragen><de> Aus der Kraft unserer Freundschaft mit dem lebendigen Gott heraus leben wir dieses vielfältige Ja und tragen es zugleich als Wegweisung in diese unsere Weltstunde hinein.
<G-vec00241-001-s629><carry.tragen><en> Sing the song of lands from far away Other times and another place The wind can carry us all away from here Charmed in her embrace Leaves turn to red, the nights are getting colder Seasons will change, the clock ticks on Leaves fill the trees as the days are getting warmer, Days turn to years, the clocks ticks on...
<G-vec00241-001-s629><carry.tragen><de> Sing das Lied von weit entfernten Landen, Anderen Zeiten und einem anderen Platz, Der Wind kann uns alle fort von hier tragen Bezaubernd in seiner Umarmung... *Blätter färben sich zu rot, die Nächte werden kälter, Jahreszeiten werden sich ändern, die Uhr tickt weiter... Blätter füllen die Bäume wenn die Tage wärmer werden, Tage werden zu Jahren, die Uhr tickt weiter...
<G-vec00241-001-s630><carry.tragen><en> The cross will be taken from you again as soon as the purpose has been achieved, for I will not let you suffer any longer than necessary, and I will also help you carry it when it seems too heavy for you at times....
<G-vec00241-001-s630><carry.tragen><de> Das Kreuz wird euch wieder abgenommen, sowie der Zweck erreicht ist, denn Ich lasse euch nicht länger leiden, als nötig ist, und Ich helfe es euch auch tragen, wenn es euch zeitweilig zu schwer erscheint....
<G-vec00241-001-s631><carry.tragen><en> Pilgrims carry rocks of different sizes, forming the so-called apachetas, to symbolize the sins of the devout.
<G-vec00241-001-s631><carry.tragen><de> Die Pilger tragen Steine verschiedener Größen mit denen sie die so genannten Apachetas(Kapellen der Inka) errichten, die die Sünden der Gläubigen symbolisieren.
<G-vec00241-001-s632><carry.tragen><en> Remember to carry water, the Vercors offers very few surface springs.
<G-vec00241-001-s632><carry.tragen><de> Denken Sie daran, Wasser zu tragen, die Vercors bietet nur sehr wenige Oberflächenquellen.
<G-vec00241-001-s633><carry.tragen><en> This is what happens when we try to get a perfect match for the image that we carry inside us.
<G-vec00241-001-s633><carry.tragen><de> So etwas geschieht, wenn wir versuchen, ein perfektes Pendant für das Bild zu finden, das wir in uns tragen.
<G-vec00241-001-s634><carry.tragen><en> Mini bag for multipurpose, to carry any accessory.
<G-vec00241-001-s634><carry.tragen><de> Minitasche mit Mehrzwecktuch, um Zubehör zu tragen.
<G-vec00241-001-s635><carry.tragen><en> Carry bear spray and know how to use it.
<G-vec00241-001-s635><carry.tragen><de> Tragen Sie ein Bärenspray mit sich und machen sich mit der Anwendung vertraut.
<G-vec00241-001-s636><carry.tragen><en> Its rotating center will help you calm down and relax can have him mantras you carry recitations.
<G-vec00241-001-s636><carry.tragen><de> Seine Drehzentrum wird Ihnen helfen, beruhigen und entspannen kann ihn haben Mantras Sie Rezitationen tragen.
<G-vec00241-001-s637><carry.tragen><en> "15:2 Then David said, ""No one but the Levites may carry the ark of God, because the Lord chose them to carry the ark of the Lord and to minister before him forever."""
<G-vec00241-001-s637><carry.tragen><de> 15:2 Damals sprach David: Die Lade Gottes soll niemand tragen außer den Leviten; denn diese hat der HERR erwählt, daß sie die Lade des HERRN tragen und ihm dienen allezeit.
<G-vec00241-001-s639><carry.tragen><en> I thank the young people who will now carry this Cross, in which we can as it were touch the mystery of Jesus on the highways of the world.
<G-vec00241-001-s639><carry.tragen><de> Ich danke den Jugendlichen, die dieses Kreuz, in dem wir das Geheimnis Jesu gleichsam berühren können, jetzt durch die Straßen der Welt tragen werden.
<G-vec00241-001-s640><carry.tragen><en> Carry a bare laptop and keep sensitive documents on your work PC, while still having total access to them with Laplink Everywhere. 4.
<G-vec00241-001-s640><carry.tragen><de> Tragen Sie einen nackten Laptop und bewahren Sie vertrauliche Dokumente auf Ihrem Arbeits-PC auf, während Sie mit Laplink Everywhere immer noch uneingeschränkten Zugriff darauf haben.
<G-vec00241-001-s641><carry.tragen><en> It is with embosses the unit pairing chocolate by the convertor seal machine to carry on the packing,after its packing product contour artistic,the colored design is bright, stereoscopic effect.
<G-vec00241-001-s641><carry.tragen><de> Es ist mit der Einheit Pairing Schokolade Prägungen durch die Konverter Beutelmaschine auf der Verpackung zu tragen, nach der Verpackung Produktkontur künstlerisch, die farbige Gestaltung hellt, stereoskopischer Effekt ist.
<G-vec00241-001-s642><carry.tragen><en> Often parents, trying to soothe a crying child, take him in their arms and carry it, swaying and entertaining.
<G-vec00241-001-s642><carry.tragen><de> Oft Eltern, die versuchen, ein weinendes Kind zu beruhigen, nehmen es in die Arme und tragen es schwankend und unterhaltsam.
<G-vec00241-001-s643><carry.tragen><en> Their LED screens frequently carry diverse images in the series of “The Art of Outdoor”, an interactive program that includes direct participation of the public in creative festivals.
<G-vec00241-001-s643><carry.tragen><de> Ihre LED-Bildschirme tragen häufig verschiedene Bilder in der Reihe „The Art of Outdoor“, ein interaktives Programm, das direkte Teilnahme der Öffentlichkeit in den kreativen Festivals umfasst.
<G-vec00241-001-s644><carry.tragen><en> If you want to carry the baby on your back, the baby insert can also be easily used on your back.
<G-vec00241-001-s644><carry.tragen><de> Wenn man das Baby auf dem Rücken tragen möchte, lässt sich der Babyeinsatz auch ganz einfach am Rücken einsetzen.
<G-vec00241-001-s645><carry.tragen><en> Rpte: WernerGood morning, we are a company with 10 years of market specialized in computers and computer ergonomic accessories, and other items to large supermarket chains and department stores, we want to expand our business in your country, where we seek a partnership with a representative to carry out work in this country.
<G-vec00241-001-s645><carry.tragen><de> Rpte: WernerGuten Morgen, wir sind eine Firma mit 10 Jahren der Markt in Computern und Computer-Ergonomie Zubehör und andere Einzelteile zu großen Supermarktketten und Warenhäuser spezialisiert, um unser Geschäft in Ihrem Land, in dem wir suchen, eine Partnerschaft mit einem Vertreter zu tragen erweitern möchten wir Arbeiten in diesem Land.
<G-vec00241-001-s646><carry.tragen><en> Just prior to the pole shift and post pole shift carry as much salt in the bottom of your pack as you can fit.
<G-vec00241-001-s646><carry.tragen><de> Genau vor dem Polsprung und nach dem Polsprung tragt soviel Salz unten in eurem Rucksack wie es euch paßt.
<G-vec00241-001-s647><carry.tragen><en> And carry the Cross of Jesus Christ.
<G-vec00241-001-s647><carry.tragen><de> Und tragt das Kreuz Jesu Christi.
<G-vec00241-001-s648><carry.tragen><en> In this way, also you, little children, grow in Gods love and carry it to all those who are far from God.
<G-vec00241-001-s648><carry.tragen><de> So wachst auch ihr, meine lieben Kinder, in der Liebe Gottes und tragt sie zu all jenen, die fern von Gott sind.
<G-vec00241-001-s649><carry.tragen><en> Now drop off the suitcases of yesteryear and no longer carry them with you.
<G-vec00241-001-s649><carry.tragen><de> Lasst nunmehr die Koffer des letzten Jahres fallen und tragt sie nicht mehr länger mit euch herum.
<G-vec00241-001-s650><carry.tragen><en> RH). It has taken many ages for you to incorporate the distorted energy you now carry.
<G-vec00241-001-s650><carry.tragen><de> Es hat viele Zeitalter gedauert, die verzerrten Energien, die Ihr nun tragt, aufzunehmen.
<G-vec00241-001-s651><carry.tragen><en> If you carry Jesus in your innocent hearts and walk with Him in personal relationship through intimate prayers and reception of sacraments, especially the Holy Eucharist, where you can be one with Him; you have nothing to fear.
<G-vec00241-001-s651><carry.tragen><de> Wenn ihr Jesus in euren unschuldigen Herzen tragt und mit ihm in einer persönlichen Beziehung lebt durch innige Gebete und den Empfang der Sakramente, besonders der Heiligen Eucharistie, wo ihr mit ihm eins sein könnt, braucht ihr nichts zu fürchten.
<G-vec00241-001-s652><carry.tragen><en> Carry out your mission with dignity, and those who believe you will be the ones whom I have chosen to make them My disciples.
<G-vec00241-001-s652><carry.tragen><de> Tragt eure Aufgabe mit Würde, und jene, welche euch glauben, werden diejenigen sein, die Ich erwählt habe, um aus ihnen meine Jünger zu machen.
<G-vec00241-001-s653><carry.tragen><en> The possibilities of illness are always there in your body and around you; you carry within you or there swarm about you the microbes and germs of every disease.
<G-vec00241-001-s653><carry.tragen><de> Krankheitsmöglichkeiten sind stets in eurem Körper und um euch herum vorhanden, da wimmelt es von Keimen und Mikroben, und ihr tragt sie in euch.
<G-vec00241-001-s654><carry.tragen><en> You carry the tent; the tent doesn't carry you.
<G-vec00241-001-s654><carry.tragen><de> Ihr tragt das Zelt; das Zelt trägt nicht euch.
<G-vec00241-001-s655><carry.tragen><en> They were responsible for My words that only I as the Son knew the Father and He Me, although I once personally taught on earth how this knowledge could also be given to you humans, all of whom carry a spark of My divine Self in your hearts, which keeps urging you towards becoming one with Me.
<G-vec00241-001-s655><carry.tragen><de> Sie nötigten Mich zu dem Ausruf, dass nur Ich als Sohn den Vater kenne und Er Mich. Dabei lehrte Ich einst körperlich auf Erden, wie diese Erkenntnis auch euch Menschen, die ihr doch alle einen Funken Meines göttlichen Ichs in eurem Herzen tragt, welcher euch stets zur Vereinigung mit Mir antreibt, gegeben werden könne.
<G-vec00241-001-s656><carry.tragen><en> Take the burden, carry the weight yourself, work life out yourself, and sooner or later you will come up against some tremendous situation with which you cannot cope, and that is the alternative which many have so grievously found.
<G-vec00241-001-s656><carry.tragen><de> Nehmt die Last auf dich, tragt selber das ganze Gewicht, bewältigt das Leben selber, und früher oder später werdet ihr euch einer ungeheuren Situation gegenüber sehen, mit der ihr nicht fertig werdet, und das ist die Alternative, die so viele so schmerzlich vorgefunden haben.
<G-vec00241-001-s657><carry.tragen><en> Yes, you carry light, yet you are not separate from it.
<G-vec00241-001-s657><carry.tragen><de> Ja, ihr tragt das Licht auch, dennoch seid ihr nicht getrennt davon.
<G-vec00241-001-s658><carry.tragen><en> Take this Gospel and carry it with you, to read it often, every day. Carry it in your purse, in your pocket, read from it often, a passage every day.
<G-vec00241-001-s658><carry.tragen><de> Nehmt es und tragt es bei euch, um oft darin zu lesen, um es jeden Tag in der Handtasche, in der Jackentasche zu tragen und jeden Tag einen Abschnitt daraus zu lesen.
<G-vec00241-001-s659><carry.tragen><en> Carry them in your heart and pray for them.
<G-vec00241-001-s659><carry.tragen><de> Tragt sie im Herzen und betet für sie.
<G-vec00241-001-s660><carry.tragen><en> Take care that your dog is always on a leash in public and that you carry a muzzle, especially if you have a larger dog.
<G-vec00241-001-s660><carry.tragen><de> Achten Sie darauf, dass Ihr Hund immer an der Leine ist und Maulkorb tragt in der Öffentlichkeit, besonders wenn Sie einen größeren Hund haben.
<G-vec00241-001-s661><carry.tragen><en> For us, the fact that you carry the message of an ethical alternative out into the world is utterly priceless.
<G-vec00241-001-s661><carry.tragen><de> Dass ihr die Botschaft einer ethischen Alternative hinaus in die Welt tragt, das ist für uns unbezahlbar.
<G-vec00241-001-s662><carry.tragen><en> 4 Carry neither purse nor scrip nor sandals, and salute no one on the way.
<G-vec00241-001-s662><carry.tragen><de> 4 Tragt weder Beutel noch Tasche noch Schuhe und grüßt niemand auf dem Weg.
<G-vec00241-001-s663><carry.tragen><en> Speak about peace and carry peace in your hearts.
<G-vec00241-001-s663><carry.tragen><de> Sprecht vom Frieden und tragt den Frieden in euren Herzen.
<G-vec00241-001-s664><carry.tragen><en> In fact, carry nothing with you.
<G-vec00241-001-s664><carry.tragen><de> Ja, tragt gar nichts mehr herum.
<G-vec00241-001-s665><carry.transportieren><en> The moisture-drain off materials of the adidas adiSTAR shirt have a supporting effect and optimally carry the moisture away from the body.
<G-vec00241-001-s665><carry.transportieren><de> Die feuchtigkeitsableitenden Materialien des adidas adiSTAR Shirts wirken unterstützend und transportieren die Feuchtigkeit optimal vom Körper weg.
<G-vec00241-001-s666><carry.transportieren><en> Carry the chain saw with the engine stopped, the guide bar and cutting chain to the rear, and the muffler away from your body.
<G-vec00241-001-s666><carry.transportieren><de> Transportieren Sie die Kettensäge nur bei ausgeschaltetem Motor; Führungsschiene und Sägekette müssen nach hinten gerichtet sein und der Schalldämpfer weg von Ihrem Körper zeigen.
<G-vec00241-001-s667><carry.transportieren><en> Ve i n s The veins carry the blood back to the heart.
<G-vec00241-001-s667><carry.transportieren><de> Venen Die Venen transportieren das Blut zurück zum Herzen.
<G-vec00241-001-s668><carry.transportieren><en> As they were looking for alternative treatment options after prescription medicine failed to relieve their symptoms, they came up with the idea for an EDC (Every Day Carry) that was discreet and easy to travel with.
<G-vec00241-001-s668><carry.transportieren><de> Nachdem verschreibungspflichtige Medikamente ihre Symptome nicht lindern konnten, waren sie auf der Suche nach alternativen Behandlungsmöglichkeiten und kamen auf die Idee für einen Alltagshelfer, der diskret und einfach zu transportieren war.
<G-vec00241-001-s669><carry.transportieren><en> So that you can easily carry your tables and chairs.
<G-vec00241-001-s669><carry.transportieren><de> Damit können Sie problemlos Ihre Tische und Stühle transportieren.
<G-vec00241-001-s670><carry.transportieren><en> The foldable handle has an ergonomic shape and the entire megaphone is extremely light, making it very easy to carry and use the speaker.
<G-vec00241-001-s670><carry.transportieren><de> Der klappbare Griff hat eine ergonomische Form und das gesamte Megafon ein äußerst geringes Gewicht, dadurch lässt sich der Lautsprecher sehr leicht transportieren und auch verwenden.
<G-vec00241-001-s671><carry.transportieren><en> "With its 6.5"" woofer and 3/4"" drivers for the highs are the absolute tops very easy to carry lightweight and ultra compact design and install."
<G-vec00241-001-s671><carry.transportieren><de> "Mit ihrem 6,5""-Woofer und den 3/4""-Treibern für die Höhen sind die Topteile absolute Leichtgewichte und durch die ultrakompakten Abmessungen sehr leicht zu transportieren und aufzustellen."
<G-vec00241-001-s672><carry.transportieren><en> The same support has a little place to save a SD memory, to you carry it to everywhere. Reviews
<G-vec00241-001-s672><carry.transportieren><de> Dieser selbe Träger verfügt einen kleinen Raum, um eine sd-Karte zu behalten, damit du es mit Ihnen transportieren kannst.
<G-vec00241-001-s673><carry.transportieren><en> In this context, large rivers obviously play a particularly large role - not only because they also carry a comparatively large volume of waste on account of their larger discharge.
<G-vec00241-001-s673><carry.transportieren><de> Dabei spielen große Flüsse offenbar eine besonders große Rolle - und das nicht nur, weil sie aufgrund ihres größeren Abflusses im Vergleich auch mehr Müll transportieren.
<G-vec00241-001-s674><carry.transportieren><en> Minerals: as the Iron, it is very important to fight anemia and carry oxygen to the tissues, and Magnesium, indicated to improve the muscle function and to relax the stress.
<G-vec00241-001-s674><carry.transportieren><de> Mineralien: als das Eisen, sehr wichtig zur Bekämpfung der Anämie und transportieren Sauerstoff zu den Geweben, und mg angegeben, zur Verbesserung der Muskelfunktion und Stress zu entspannen.
<G-vec00241-001-s675><carry.transportieren><en> As it can be conveniently folded on the length of a rule, the Tripod is especially easy to carry and find its place in every bag.
<G-vec00241-001-s675><carry.transportieren><de> Auf Grund seiner praktischen Zusammenklappbarkeit auf die Länge eines Zollstocks ist das Stativ besonders leicht zu transportieren und findet in jeder Tasche Platz.
<G-vec00241-001-s676><carry.transportieren><en> The 2-in-1 design allows you to to carry one or both the adapter and power bank.
<G-vec00241-001-s676><carry.transportieren><de> Das 2-in-1 Design ermöglicht Ihnen die Freiheit, den Adapter und die Powerbank einzeln oder zusammen zu transportieren.
<G-vec00241-001-s677><carry.transportieren><en> The grey matter houses the neurons themselves—one way to look at it is the neurons generate the information and the axons carry it to new neurons, which then act on it.
<G-vec00241-001-s677><carry.transportieren><de> Die graue Substanz beherbergt die Neuronen selbst, und man kann sie auf folgende Weise betrachten: Die Neuronen erzeugen Informationen, und die Axone transportieren diese zu neuen Neuronen, die eine entsprechende Wirkung auslösen.
<G-vec00241-001-s678><carry.transportieren><en> In addition, Airwheel Q5 twin-wheel scooter is super easy to carry, fashionable and proves to be pretty safe.
<G-vec00241-001-s678><carry.transportieren><de> Darüber hinaus Airwheel Q5 selbststabilisierendes Einrad Zwillingsbereifung Roller ist super leicht zu transportieren, modische und erweist sich als ziemlich sicher.
<G-vec00241-001-s679><carry.transportieren><en> Arabian slave dealers raged among African people, killed total villages and spared the fittest only, whom they then forced to carry the preyed ivory down to the coast.
<G-vec00241-001-s679><carry.transportieren><de> Arabische Sklavenhändler wüteten in afrikanischen Völkern, brachten ganze Dörfer um und verschonten nur die Kräftigsten, die dann das erbeutete Elfenbein an die Küste transportieren mussten.
<G-vec00241-001-s680><carry.transportieren><en> THE BRUCHE CANAL The waterway was constructed under the direction of Vauban (1681) to carry the materials for building the ramparts and forts circling Strasbourg.
<G-vec00241-001-s680><carry.transportieren><de> Der Kanal der Bruche Wasserstraβe, die unter Vauban (1681) konstruiert wurde, um Baumaterialien zu transportieren, die für die Realisierung von Stadtmauern und Festungen um Straβburg herum bestimmt waren.
<G-vec00241-001-s681><carry.transportieren><en> A small package is convenient, eliminating secondary pollution, and easy to carry when going out and traveling.
<G-vec00241-001-s681><carry.transportieren><de> Ein kleines Paket ist praktisch, beseitigt sekundäre Umweltverschmutzung und ist auf Reisen und auf Reisen leicht zu transportieren.
<G-vec00241-001-s682><carry.transportieren><en> Packaging should be noted that sales of small and beautiful, easy to carry and play to extend the shelf-life role.
<G-vec00241-001-s682><carry.transportieren><de> Verpackung wird darauf hingewiesen, dass der Verkauf von kleinen und schönen, leicht zu transportieren und verlängern die Haltbarkeit Rolle spielen.
<G-vec00241-001-s683><carry.transportieren><en> Specially modified vehicles carry passengers and equipment.
<G-vec00241-001-s683><carry.transportieren><de> Bestimmte, dafür modifizierte Wagen transportieren Touristen und Gepäck.
<G-vec00241-001-s684><carry.tragen><en> These God-given powers carry with them an important responsibility, namely, that man is answerable to God for the choices he makes.
<G-vec00241-001-s684><carry.tragen><de> Diese gottgegebene Freiheit trägt eine wichtige Verantwortung mit sich, nämlich, dass der Mensch für die gemachte Wahl Rechenschaft bei Gott ablegen muss.
<G-vec00241-001-s685><carry.tragen><en> “Nay, let it be!” she said: “I carry them better so balanced.
<G-vec00241-001-s685><carry.tragen><de> “Laßt ihn”, sprach sie; “es trägt sich besser die gleichere Last so.
<G-vec00241-001-s686><carry.tragen><en> When I factor in just the costs of the tickets, then accommodation, transportation and the cost of socialising it will mean that attending will carry a large price tag.
<G-vec00241-001-s686><carry.tragen><de> Wenn ich nur die Kosten für die Tickets berücksichtige, dann bedeutet die Unterbringung, der Transport und die Kosten für die Sozialisierung, dass die Teilnahme einen hohen Preis trägt.
<G-vec00241-001-s687><carry.tragen><en> And, sometimes, we even carry them around with us: on our skin, as a T-shirt print, as a sticker, as a photo in our wallet, as a magazine under our arm, as a logo on our mobile phone display.
<G-vec00241-001-s687><carry.tragen><de> Und bisweilen trägt man sie mit sich herum: auf der Haut, als T-Shirt-Aufdruck, als Aufkleber, als Foto in der Brieftasche, als Zeitschrift unterm Arm, als Motiv auf dem Display eines Mobiltelefons.
<G-vec00241-001-s688><carry.tragen><en> About 1 in 25 people carry this abnormal gene, and the carriers do not have CF or its symptoms, adds the organization.
<G-vec00241-001-s688><carry.tragen><de> Mehr als 1 in 25 Menschen trägt dieses abnorme Gen, und die Träger haben keine ZF oder deren Symptome, fügt die Organisation hinzu.
<G-vec00241-001-s689><carry.tragen><en> And anyone who does not carry his cross and follow me cannot be my disciple.
<G-vec00241-001-s689><carry.tragen><de> und wer nicht sein Kreuz trägt und mir nachkommt, kann nicht mein Jünger sein.
<G-vec00241-001-s690><carry.tragen><en> Everyone has secrets, big or small - you carry them alone or share them.
<G-vec00241-001-s690><carry.tragen><de> Jeder hat Geheimnisse, kleine oder große, man trägt sie allein oder teilt sie.
<G-vec00241-001-s691><carry.tragen><en> The exoskeleton weighs 38 kg, but the user does not carry any of this weight.
<G-vec00241-001-s691><carry.tragen><de> Das Exoskelett wiegt 38 Kilogramm, wobei der Anwender nichts von diesem Gewicht trägt.
<G-vec00241-001-s692><carry.tragen><en> It does not lie within the power of the workers to prevent the petty-bourgeois democrats from doing this; but it does lie within their power to make it as difficult as possible for the petty bourgeoisie to use its power against the armed proletariat, and to dictate such conditions to them that the rule of the bourgeois democrats, from the very first, will carry within it the seeds of its own destruction, and its subsequent displacement by the proletariat will be made considerably easier.
<G-vec00241-001-s692><carry.tragen><de> Es liegt nicht in der Macht der Arbeiter, den kleinbürgerlichen Demokraten dies zu verwehren, aber es liegt in ihrer Macht, ihnen das Aufkommen gegenüber dem bewaffneten Proletariat zu erschweren und ihnen solche Bedingungen zu diktieren, daß die Herrschaft der bürgerlichen Demokraten von vornherein den Keim des Unterganges in sich trägt und ihre spätere Verdrängung durch die Herrschaft des Proletariats bedeutend erleichtert wird.
<G-vec00241-001-s693><carry.tragen><en> On Good Friday afternoon, church bells begin to toll a funereal knell, flags are flown at half-mast and sentries outside official buildings carry reversed arms.
<G-vec00241-001-s693><carry.tragen><de> Am Karfreitag Nachmittag beginnen Kirchenglocken zu Zoll ein trauervolles Glockengeläut, Fahnen sind geflogen an Halbmast und Wachen außerhalb offizieller Gebäude trägt umgekehrte Arme.
<G-vec00241-001-s694><carry.tragen><en> From a number of fertilised egg cells that one is selected which does not carry the disease-causing gene.
<G-vec00241-001-s694><carry.tragen><de> Aus einer Auswahl von mehreren befruchteten Eizellen wird diejenige ausgewählt, die das entsprechende krankmachende Gen nicht trägt.
<G-vec00241-001-s695><carry.tragen><en> There is hardly a path left that doesn't already carry his tire print.
<G-vec00241-001-s695><carry.tragen><de> Es gibt kaum noch einen Pfad der nicht schon seinen Reifenabdruck trägt.
<G-vec00241-001-s696><carry.tragen><en> If the function is successful carry flag is clear, else carry flag is set and AX register returns status code and drive will not be in emulation mode.
<G-vec00241-001-s696><carry.tragen><de> Wenn die Funktion tragen Markierungsfahne ist frei erfolgreich ist, trägt sonst Markierungsfahne ist gesetzt und AXT-Registerrückkehrstatus code und -antrieb sind nicht im Emulation Modus.
<G-vec00241-001-s697><carry.tragen><en> And it is the new generation of the world proletariat, which raises the torch of the world socialist revolution, and which will carry it towards victory.
<G-vec00241-001-s697><carry.tragen><de> Es ist die neue Generation des Weltproletariats, die die Fackel der sozialistischen Weltrevolution übernimmt, um sie zum Sieg trägt.
<G-vec00241-001-s698><carry.tragen><en> This is particularly true of the components WEISS has specialised in. Indeed, rotary indexing tables, linear systems and handling units often form the basis of a special machine, the foundations that carry all other components.
<G-vec00241-001-s698><carry.tragen><de> Das gilt besonders für Komponenten, auf die sich WEISS spezialisiert hat: Rundschalttische, Linearsysteme und Handlingeinheiten sind oft genug die Basis einer Sondermaschine, das Fundament, das alle anderen Bauteile trägt.
<G-vec00241-001-s699><carry.tragen><en> In the second year the woody stems carry flowers, and now, berries that ripen unevenly; so one stem can be harvested many times.
<G-vec00241-001-s699><carry.tragen><de> Im zweiten Jahr trägt der holzige Stiel Blüten, Beeren können unregelmäßig reifen; so kann von einem Stiel viele Male geerntet werden.
<G-vec00241-001-s700><carry.tragen><en> Some of the trees carry fruits this month, and to avoid that they are harvested by monkeys or neighbors, our boys from Hilltop and Bawani have gone to Buttala and picked more than 3000 mangoes.
<G-vec00241-001-s700><carry.tragen><de> Ein Teil der Bäume trägt in diesem Monat Früchte und damit die weder von Affen noch von Nachbarn geerntet werden sind unsere Jungs aus Hilltop mit Bawani nach Buttala gefahren und haben mehr als 3000 Früchte gepflückt.
<G-vec00241-001-s701><carry.tragen><en> All the Saints of God are there to protect me, to sustain me and to carry me.
<G-vec00241-001-s701><carry.tragen><de> Die Schar der Heiligen Gottes schützt und stützt und trägt mich.
<G-vec00241-001-s702><carry.tragen><en> Not only does this steroid carry no estrogenic activity, but it can actually act as an anti-estrogen in the body.
<G-vec00241-001-s702><carry.tragen><de> Nicht nur trägt dieses Steroid keine estrogenic Tätigkeit, aber es kann als ein Antiöstrogen im Körper wirklich auftreten.
<G-vec00241-001-s798><carry.übernehmen><en> We will carry out the printing of your wedding cards in our usual first-class quality.
<G-vec00241-001-s798><carry.übernehmen><de> Den Druck der Hochzeitskarte übernehmen wir in gewohnter, erstklassiger Qualität.
<G-vec00241-001-s799><carry.übernehmen><en> It was hauled to the west coast of America, where, as theÂ Clipper V,Â it will carry traffic between Seattle in the USA and Victoria on Vancouver Island (Canada).
<G-vec00241-001-s799><carry.übernehmen><de> "Er wurde an die amerikanische Westküste verholt, wo er zukünftig als ""Clipper V"" den Verkehr zwischen Seattle und Victoria auf Vancouver Island (Kanada) übernehmen wird."
<G-vec00241-001-s800><carry.übernehmen><en> When democracies are failing, or have failed, it is the institutions of civil society that can carry an added burden to help sustain improvements in quality of life.
<G-vec00241-001-s800><carry.übernehmen><de> Wenn Demokratien scheitern oder gescheitert sind, sind es die Institutionen der Zivilgesellschaft, die eine zusätzliche Last übernehmen können, um dazu beizutragen, Verbesserungen in der Lebensqualität zu erhalten.
<G-vec00241-001-s801><carry.übernehmen><en> They must carry the tent and everything that belongs to it.
<G-vec00241-001-s801><carry.übernehmen><de> Sie sollen auch die Weiterbeförderung der Wohnung und ihrer sämtlichen Geräte übernehmen.
<G-vec00241-001-s802><carry.übernehmen><en> If special material tests are required for the calculation task, we will be pleased to carry out the test for you in cooperation with external partners.
<G-vec00241-001-s802><carry.übernehmen><de> Sind spezielle Werkstoffprüfungen für die gestellte Berechnungsaufgabe erforderlich, so übernehmen wir für Sie gerne die Testdurchführung in Zusammenarbeit mit externen Partnern.
<G-vec00241-001-s803><carry.übernehmen><en> The foam projectiles carry out the actual cleaning: They are 15 per cent larger than the inner diameter of the tube or hose to be cleaned.
<G-vec00241-001-s803><carry.übernehmen><de> Die Schaumstoffprojektile übernehmen die eigentliche Reinigung: Da sie rund 15 Prozent größer ausgelegt sind als die Innendurchmesser der zu reinigenden Leitungen, entsteht Reibung, welche Verschmutzungen wirkungsvoll ablöst.
<G-vec00241-001-s804><carry.übernehmen><en> Today's robots can only carry out the same tasks in the same environment.
<G-vec00241-001-s804><carry.übernehmen><de> Heutige Roboter können nur die gleichen Aufgaben im stets gleichen Umfeld übernehmen.
<G-vec00241-001-s805><carry.übernehmen><en> In this case, we might offer to carry a part of the development expenses or alternative license models.
<G-vec00241-001-s805><carry.übernehmen><de> In diesem Fall ist es möglich, dass wir Teile des Entwicklungsaufwands übernehmen oder alternative Lizensierungsformen finden.
<G-vec00241-001-s806><carry.übernehmen><en> The foam projectiles carry out the actual cleaning: They are 15 per cent larger than the inner diameter of the tube or hose to be cleaned. This creates friction which effectively releases contaminations.
<G-vec00241-001-s806><carry.übernehmen><de> Die Schaumstoffprojektile übernehmen die eigentliche Reinigung: Da sie rund 15 Prozent größer ausgelegt sind als die Innendurchmesser der zu reinigenden Leitungen, entsteht Reibung, welche Verschmutzungen wirkungsvoll ablöst.
<G-vec00241-001-s807><carry.übernehmen><en> You carry never buy Dianabol simply by itself, bear in mind to buy an anti – estrogen along with clomid for the pct, and if you desire a appropriate hardcore pattern then increase Testosterone and perhaps also Deca to your order.
<G-vec00241-001-s807><carry.übernehmen><de> Sie übernehmen nie kaufen Dianabol nur auf seine eigene, denken Sie daran, eine Anti kaufen – Östrogen zusammen mit clomid für die PCT, und wenn Sie eine entsprechende hardcore Muster wünschen, dann gehören Testosteron und vielleicht sogar Deca auf Ihre Bestellung.
<G-vec00241-001-s808><carry.übernehmen><en> During the many years of the persecution that Ms. Zhang has suffered, her husband Chen Dongming had to carry on the tasks of both father and mother.
<G-vec00241-001-s808><carry.übernehmen><de> Während der vielen Jahre an Verfolgung, die Frau Zhang erlitten hat, musste ihre Mann Chen Dongming die Aufgabe übernehmen, gleichzeitig Vater und Mutter zu sein.
<G-vec00241-001-s809><carry.übernehmen><en> We carry out transportation of liquid chemicals in road tankers, capacity from 24,000 to 37,000 litres, in single and triple chamber configuration, with breakwaters.
<G-vec00241-001-s809><carry.übernehmen><de> Wir übernehmen den Transport von Flüssigchemikalien in Tanklastwagen mit einem Fassungsvermögen zwischen 24.000 und 37.000 Litern in Ein- bis Dreikammerkonfiguration mit Schwallwänden.
<G-vec00241-001-s810><carry.übernehmen><en> Beyond enumerating rights, the Commission argued for a new clarity about who should carry out the corresponding duties, and how.
<G-vec00241-001-s810><carry.übernehmen><de> Neben der Neuanordnung der Rechte sprach sich die Kommission für eine Klärung dessen aus, wer die damit zusammenhängenden Pflichten übernehmen soll und wie sie erfüllt werden müssen.
<G-vec00241-001-s811><carry.übernehmen><en> So two spokes carry out the function of one, slackening and torsion are extremely limited, and the transmission of power from the athlete is much more effective.
<G-vec00241-001-s811><carry.übernehmen><de> Auf diese Weise übernehmen hier zwei Speichen die Funktion einer einzelnen, die Lockerung und Torsion sind extrem gering und die Übertragung der Energie des Athleten ist sehr viel wirksamer.
<G-vec00241-001-s812><carry.übernehmen><en> In most cases, companies carry out distribution of the email themselves. However, some also leave this to HRS too, because transmission via HRS enables valuable analyses, for example how often a training video was viewed or a particular link was clicked.
<G-vec00241-001-s812><carry.übernehmen><de> In den meisten Fällen übernehmen die Firmen den Versand selbst, manche überlassen dies allerdings auch HRS, weil der Versand über HRS wertvolle Auswertungen ermöglicht, etwa wie oft ein Schulungsvideo angesehen oder ein bestimmter Link geklickt wurde.
<G-vec00241-001-s813><carry.übernehmen><en> We carry out intensive preliminary research, work with you to prepare for the negotiations and train your negotiators.
<G-vec00241-001-s813><carry.übernehmen><de> Wir übernehmen die intensive Vorfeld-Recherche, bereiten mit Ihnen gemeinsam die Verhandlungen vor und trainieren Ihre Verhandlungsführer.
<G-vec00241-001-s814><carry.übernehmen><en> As the largest employer in Reinbek, Almirall Hermal GmbH primarily supports municipal organisations or projects that carry out social tasks.
<G-vec00241-001-s814><carry.übernehmen><de> Als größter Arbeitgeber am Standort Reinbek unterstützt die Almirall Hermal GmbH in erster Linie kommunale Einrichtungen oder Projekte, die soziale Aufgaben übernehmen.
<G-vec00241-001-s815><carry.übernehmen><en> Although soils carry out many important tasks in the natural balance and for the supply and nutrition of humans, their protection receives little attention.
<G-vec00241-001-s815><carry.übernehmen><de> Obwohl Böden viele wichtige Aufgaben im Naturhaushalt und für die Versorgung und Ernährung der Menschen übernehmen, wird ihrem Schutz wenig Aufmerksamkeit geschenkt.
<G-vec00241-001-s816><carry.übernehmen><en> Through our solutions we can guarantee you not only efficient warehousing and reliable handling, but we carry out different professional modification work and the maintenance of your machinery, too.
<G-vec00241-001-s816><carry.übernehmen><de> Durch unsere Lösungen garantieren wir Ihnen nicht nur effiziente Lagerhaltung und zuverlässiges Handling, sondern übernehmen auch diverse fachmännische Umbauarbeiten und die Wartung Ihrer Maschinen.
<G-vec00241-002-s570><carry.(sich)_nehmen><en> We carry out an Environmental Product Declaration (EPD) to assess the impact of wind projects.
<G-vec00241-002-s570><carry.(sich)_nehmen><de> Wir nehmen eine Umweltproduktdeklaration (EPD) vor, um die Auswirkungen von Windprojekten zu beurteilen.
<G-vec00241-002-s571><carry.(sich)_nehmen><en> Each passenger can carry 1 piece of Hand Luggage of 10 kilos (max. measurements of 55 x 35 x 25 centimetres).
<G-vec00241-002-s571><carry.(sich)_nehmen><de> Jeder Passagier darf 1x Handgepäckstück von 10Kg mit an Bord nehmen (maximale Maße 55 x 35 x 25).
<G-vec00241-002-s572><carry.(sich)_nehmen><en> The Dual Panel Charger is very lightweight (only 120gr) and easy to carry.
<G-vec00241-002-s572><carry.(sich)_nehmen><de> Das Dual-Panel Solar Charger ist vom Gewicht her sehr leicht (120gr) und einfach mit zu nehmen, wohin Sie auch gehen.
<G-vec00241-002-s573><carry.(sich)_nehmen><en> And when you are among them and lead them in prayer, let a group of them stand [in prayer] with you and let them carry their arms.
<G-vec00241-002-s573><carry.(sich)_nehmen><de> Und wenn du unter ihnen bist und nun für sie das Gebet anfuhrst, dann soll sich ein Teil von ihnen mit dir aufstellen, doch sollen sie ihre Waffen nehmen.
<G-vec00241-002-s574><carry.(sich)_nehmen><en> Also carry enough tape with you.
<G-vec00241-002-s574><carry.(sich)_nehmen><de> Nehmen Sie auch genügend Videobänder mit.
<G-vec00241-002-s575><carry.(sich)_nehmen><en> Specialists from the respective branches of industry carry out risk assessments and situational analyses and use these to plan the control measures to be taken and assist in their implementation if necessary.
<G-vec00241-002-s575><carry.(sich)_nehmen><de> Fachleute aus den betroffenen Branchen nehmen Risikobeurteilungen und Lageanalysen vor, planen darauf basierend die Bewirtschaftungsmassnahmen und wirken im Ernstfall bei deren Umsetzung mit.
<G-vec00241-002-s576><carry.(sich)_nehmen><en> One bedroom has a cot aanwezig.Ook a high chair in the house aanwezig.U need your own bedding and linen to carry.
<G-vec00241-002-s576><carry.(sich)_nehmen><de> Ein Schlafzimmer verfügt über ein Kinderbett aanwezig.Ook einen Hochstuhl im Haus aanwezig.U brauchen Ihre eigene Bettwäsche und Handtücher zu nehmen.
<G-vec00241-002-s577><carry.(sich)_nehmen><en> If you would like to assign the translation of the updated document to another translator, switch to the Tasks module and carry out the new assignment.
<G-vec00241-002-s577><carry.(sich)_nehmen><de> Möchten Sie die Bearbeitung des aktualisierten Dokuments einem anderen Übersetzer zuweisen, wechseln Sie bitte in das Aufgaben-Modul und nehmen Sie dort die neue Zuweisung vor.
<G-vec00241-002-s578><carry.(sich)_nehmen><en> Member States shall carry out the administrative and control tasks required pursuant to the provisions of the special measures to enhance maritime security of the SOLAS Convention and of the ISPS Code.
<G-vec00241-002-s578><carry.(sich)_nehmen><de> (1) Die Mitgliedstaaten nehmen die Verwaltungs- und Kontrollaufgaben wahr, die sich aus den Bestimmungen der besonderen Maßnahmen des SOLAS-Übereinkommens zur Erhöhung der Gefahrenabwehr in der Schifffahrt und des ISPS-Code ergeben.
<G-vec00241-002-s579><carry.(sich)_nehmen><en> We carry out redesigns in close agreement with our customers to whom we submit proposals for solutions at an early stage.
<G-vec00241-002-s579><carry.(sich)_nehmen><de> Redesigns nehmen wir in enger Absprache mit unseren Kunden vor, frühzeitig unterbreiten wir angemessene Lösungsvorschläge.
<G-vec00241-002-s580><carry.(sich)_nehmen><en> We have all the necessary knowledge, experience and technological support of ServiceNow, to provide top quality services – we carry out comprehensive implementations and extensions and deliver maintenance services of the ServiceNow platform.
<G-vec00241-002-s580><carry.(sich)_nehmen><de> Wir haben das nötige Wissen, die Erfahrung sowie die technologische Unterstützung von ServiceNow, um Dienstleistungen von erstklassiger Qualität zu erbringen – wir nehmen umfassende Implementierungen und Erweiterungen vor und leisten Instandhaltungsdienste für die ServiceNow-Plattform.
<G-vec00241-002-s581><carry.(sich)_nehmen><en> For security reasons, the passenger is requested to obtain a letter from physician that he/she has a medical need to carry the syringe into the cabin.
<G-vec00241-002-s581><carry.(sich)_nehmen><de> Aus Sicherheitsgründen muss der Fluggast ein Schreiben seines Arztes mitführen, dass er aus medizinischen Gründen eine Spritze mit in die Kabine nehmen muss.
<G-vec00241-002-s582><carry.(sich)_nehmen><en> Together with global partners, the experts carry out detailed technical evaluations in advance and check whether the cans or glass bottles can be filled without difficulty on customer machines.
<G-vec00241-002-s582><carry.(sich)_nehmen><de> Dabei nehmen die Experten gemeinsam mit globalen Partnern im Vorfeld detaillierte technische Bewertungen vor und prüfen, ob sich Dosen oder Glasflaschen ohne Probleme auf den vorhandenen Maschinen des Kunden abfüllen lassen.
<G-vec00241-002-s583><carry.(sich)_nehmen><en> 1 The Federal Office and the other statistics generators carry out special data analyses for the administrative units of the Confederation and, where they have the capacity, for third parties.
<G-vec00241-002-s583><carry.(sich)_nehmen><de> 1 Das Bundesamt und die übrigen Statistikproduzenten nehmen besondere Auswertungen für die Verwaltungseinheiten des Bundes und, im Rahmen ihrer Möglichkeiten, für Dritte vor.
<G-vec00241-002-s584><carry.(sich)_nehmen><en> We would like to offer you several payment methods and will carry out analyses to find out what payment options are available to you, including your payment history and credit checks.
<G-vec00241-002-s584><carry.(sich)_nehmen><de> Wir möchten Ihnen mehrere Zahlungsarten anbieten und nehmen Analysen vor, um herauszufinden, welche Zahlungsmöglichkeiten Ihnen zur Verfügung stehen, einschließlich Ihrer Zahlungshistorie und Bonitätsprüfungen.
<G-vec00241-002-s585><carry.(sich)_nehmen><en> Licence holders shall also demonstrate compliance with conditions. (2) If the person required to provide information manufactures or deals in weapons or operates a shooting range or security firm, the persons assigned by the competent authorities to monitor the business shall have the right to enter the business property and premises during business and working hours in order to carry out checks and inspections, take samples and examine business records.
<G-vec00241-002-s585><carry.(sich)_nehmen><de> (2) Betreibt der Auskunftspflichtige Waffenherstellung, Waffenhandel, eine Schießstätte oder ein Bewachungsunternehmen, so sind die von der zuständigen Behörde mit der Überwachung des Betriebs beauftragten Personen berechtigt, Betriebsgrundstücke und Geschäftsräume während der Betriebs- und Arbeitszeit zu betreten, um dort Prüfungen und Besichtigungen vorzunehmen, Proben zu entnehmen und Einsicht in die geschäftlichen Unterlagen zu nehmen; zur Abwehr dringender Gefahren für die öffentliche Sicherheit oder Ordnung dürfen diese Arbeitsstätten auch außerhalb dieser Zeit sowie die Wohnräume des Auskunftspflichtigen gegen dessen Willen besichtigt werden.
<G-vec00241-002-s586><carry.(sich)_nehmen><en> The project is in its early days, so you'll need to come back in a few years' time to test it out...In the meantime, you'll have to carry on using your car...A good opportunity to stop off at one of the Ottrott wine cellars to sample the "Rouge d'Ottrott", typical local vineyard wine that you won't find anywhere else.
<G-vec00241-002-s586><carry.(sich)_nehmen><de> Dieses Projekt steckt noch in den Kinderschuhen, Sie sollten in ein paar Jahren wiederkommen, um in dessen Genuss zu kommen... Bis dahin müssen Sie weiterhin das Auto nehmen... Nutzen Sie die Gelegenheit zu einem Halt in einem der Keller von Ottrott und verkosten Sie den „Rouge d'Ottrott", einen typischen Wein dieser Gegend, den Sie nirgendwo sonst finden werden.
<G-vec00241-002-s587><carry.(sich)_nehmen><en> [So that] they go about naked without clothing, And being hungry they carry the sheaves.
<G-vec00241-002-s587><carry.(sich)_nehmen><de> Den Nackten lassen sie ohne Kleider gehen, und den Hungrigen nehmen sie die Garben.
<G-vec00241-002-s588><carry.(sich)_nehmen><en> Relating to solid units Amazone rely primarily on BPW axles, in order to ensure reliable service to its customers and because the stresses on the vehicles are enormous: They have to be able to withstand dynamic loads on paths and in the fields and carry many times their own weight in terms of load.
<G-vec00241-002-s588><carry.(sich)_nehmen><de> Amazone vertraut bei gezogenen Einheiten primär auf BPW-Achsen, um zuverlässigen Service für seine Kunden sicherzustellen und weil die Belastungen der Fahrzeuge enorm sind: Sie müssen auf Feldwegen und im Acker dynamische La- sten tragen und nehmen oft auch ein Viel- faches ihres Eigengewichts an Zuladung auf.
<G-vec00241-002-s038><carry.ausführen><en> Scientists from universities, schools of technology, and research institutes of the member countries, and exceptionally from other countries, can carry out research in the laboratories and observatories provided by the Foundation.
<G-vec00241-002-s038><carry.ausführen><de> Wissenschafter von Universitäten, technischen Hochschulen und Forschungsinstituten der Mitgliedländer, und bei Nachfrage auch von anderen Staaten, können in den von der Stiftung zur Verfügung gestellten Infrastrukturen nach dem Gästeprinzip Forschungsprojekte ausführen.
<G-vec00241-002-s039><carry.ausführen><en> As in any band of gangsters, there are always those who order the crime, and those who carry it out.
<G-vec00241-002-s039><carry.ausführen><de> Wie in jeder Gangsterbande gibt es immer diejenigen, die das Verbrechen, die Tat befehlen, und diejenigen, die sie ausführen.
<G-vec00241-002-s040><carry.ausführen><en> The Q5 allows you to carry out many of the secondary processes, alongside the more traditional punching and nibbling, on the same machine.
<G-vec00241-002-s040><carry.ausführen><de> Die Q5 bietet also den Vorteil, dass man neben dem traditionellen Stanzen und Nibbeln mehrere sekundäre Bearbeitungen auf ein und derselben Maschine ausführen kann.
<G-vec00241-002-s041><carry.ausführen><en> Another advantage of the SBZ 137‘s ergonomic design is that all cleaning and maintenance tasks are very simple to carry out.
<G-vec00241-002-s041><carry.ausführen><de> Zum ergonomischen Konzept des kompakten SBZ 137 gehört, dass sich alle Reinigungs- und Wartungsarbeiten einfach ausführen lassen.
<G-vec00241-002-s042><carry.ausführen><en> The fact that we have our own offices in our production countries makes it easy for us to carry out these checks at various stages of production.
<G-vec00241-002-s042><carry.ausführen><de> Da wir in unseren Produktionsländern eigene Niederlassungen haben, lassen sich Qualitätskontrollen in jedem Produktionsstadium schnell und einfach ausführen.
<G-vec00241-002-s043><carry.ausführen><en> ‘It will be simpler, more effective and cheaper to carry out patent processing for Nordic companies.
<G-vec00241-002-s043><carry.ausführen><de> Es wird einfacher, effektiver und billiger für nordische Unternehmen Patentbearbeitungen ausführen zu lassen.
<G-vec00241-002-s044><carry.ausführen><en> Apsr.xyz may indeed be irritating, but can’t be related to any of the vicious actions that viruses or malware like Trojan Horses or Ransomware could carry out.
<G-vec00241-002-s044><carry.ausführen><de> Pusherism.com mag in der Tat irritierend sein, kann aber nicht mit einer der bösartigen Aktionen in Verbindung gebracht werden, die Viren oder Malware wie Trojaner oder Ransomware ausführen könnten.
<G-vec00241-002-s045><carry.ausführen><en> A forwarder is a company that organizes the transport of a good but does not carry the shipment itself.
<G-vec00241-002-s045><carry.ausführen><de> Nach den Bestimmungen des Handelsgesetzbuches (HGB) versteht man unter einer Spedition ein Unternehmen, das den Transport eines Gutes organisiert, diesen jedoch nicht selber ausführen muss.
<G-vec00241-002-s046><carry.ausführen><en> In sum, the earlier US application did not provide a disclosure sufficient for the skilled person to carry out the invention in claim 1.
<G-vec00241-002-s046><carry.ausführen><de> Die Erfindung in Anspruch 1 der früheren US-Anmeldung war also nicht so ausreichend offenbart, dass der Fachmann sie ausführen kann.
<G-vec00241-002-s047><carry.ausführen><en> With the help of the output signal of an encoder, a drive unit equipped with it can carry out reproducible movements and – in the case of an absolute encoder – move back exactly to the starting position (reference position) even after the machine has been switched off.
<G-vec00241-002-s047><carry.ausführen><de> Mit Hilfe des Ausgangssignals eines Kodierers kann eine damit ausgerüstete Antriebseinheit reproduzierbare Bewegungen ausführen und – im Falle eines Absolutwertgebers – auch nach Abschaltung der Maschine wieder genau in die Ausgangsposition (Referenzposition) fahren.
<G-vec00241-002-s048><carry.ausführen><en> Total acceptance of discipline and centralisation can result in the extreme case, where few, or only one, speak and take decisions, while others not completely convinced or resolute, obey and carry out the orders.
<G-vec00241-002-s048><carry.ausführen><de> Die unbedingte Annahme der Disziplin und der Zentralisation kann im äußersten Fall dazu führen, dass Wenige oder nur ein Einzelner das Sagen haben, während die anderen trotz Mangel an Überzeugung oder Entschlossenheit gehorchen und ausführen.
<G-vec00241-002-s049><carry.ausführen><en> In order to carry out the operation, you need to close other open files or programs.
<G-vec00241-002-s049><carry.ausführen><de> Um die Operation ausführen zu können, müssen erst andere offene Dateien oder Programme beendet werden.
<G-vec00241-002-s050><carry.ausführen><en> The exact point of time, when your character is ready can carry our another attack, is marked by the computer through a bell-like sound.
<G-vec00241-002-s050><carry.ausführen><de> Den exakten Zeitpunkt, ab dem Ihre Figur wieder einen Angriff ausführen kann, gibt der Computer durch einen glockenähnlichen Ton wieder.
<G-vec00241-002-s051><carry.ausführen><en> Everything, what is therefore to be made accessible to men as Gospel, is only allowed to aim to achieve the ennobling of men, a transformation to love, then it is a right vineyard work, which my servants on earth carry out.
<G-vec00241-002-s051><carry.ausführen><de> Alles, was den Menschen daher als Evangelium nahegebracht werden soll, darf nur die Veredelung des Menschen, ein Umgestalten zur Liebe bezwecken, dann ist es eine rechte Weinbergsarbeit, die Meine Knechte auf Erden ausführen.
<G-vec00241-002-s052><carry.ausführen><en> Under this account, the customer can add domain names and mailboxes, edit website content, and carry out other hosting management routines.
<G-vec00241-002-s052><carry.ausführen><de> In diesem Konto kann der Kunde dann Domainnamen und Postfächer hinzufügen, die Inhalte der Website bearbeiten und andere Aufgaben zur Hosting-Verwaltung ausführen.
<G-vec00241-002-s053><carry.ausführen><en> Im If we truly go to a lot of effort, we can, to a certain extent, make the pineal gland function again, and then slowly, very slowly yet successively, this organ will enlarge again and, accordingly, be able to carry out its function more powerfully.
<G-vec00241-002-s053><carry.ausführen><de> Wenn wir uns wirklich bemühen, können wir die Zirbeldrüse in einem gewissen Rahmen wieder zur Funktion bringen, und dann wird sich dieses Organ langsam, sehr langsam, doch sukzessive wieder vergrößern und seine Funktionen dementsprechend kraftvoller ausführen können.
<G-vec00241-002-s054><carry.ausführen><en> Create direction through a clear course of action so that each employee knows how to carry out their tasks.
<G-vec00241-002-s054><carry.ausführen><de> Schaffen Sie Orientierung durch klare Handlungsvorgaben – damit jeder Mitarbeiter weiß, wie er seine Tätigkeiten ausführen soll.
<G-vec00241-002-s055><carry.ausführen><en> After passing the farrier's exam they can carry out this work independently.
<G-vec00241-002-s055><carry.ausführen><de> Nach dem Ablegen der Hufschmiedeprüfung kann er selbstständig Huf- und Beschlagschmiedearbeiten ausführen.
<G-vec00241-002-s056><carry.ausführen><en> After you carry out this operation, the Mobile WiFi's personal configuration parameters will all be deleted.
<G-vec00241-002-s056><carry.ausführen><de> Hinweis: Nach Ausführen dieses Vorgangs werden alle persönlichen Konfigurationsparameter im Mobile WiFi gelöscht.
<G-vec00241-002-s095><carry.ausüben><en> Member States may reserve the right to participate in public contract award procedures to sheltered workshops or provide for such contracts to be performed in the context of sheltered employment programmes where most of the employees concerned are handicapped persons who, by reason of the nature or the seriousness of their disabilities, cannot carry on occupations under normal conditions.
<G-vec00241-002-s095><carry.ausüben><de> Die Mitgliedstaaten können im Rahmen von Programmen für geschützte Beschäftigungsverhältnisse vorsehen, dass nur geschützte Werkstätten an den Verfahren zur Vergabe öffentlicher Aufträge teilnehmen oder solche Aufträge ausführen dürfen, sofern die Mehrheit der Arbeitnehmer Behinderte sind, die aufgrund der Art oder der Schwere ihrer Behinderung keine Berufstätigkeit unter normalen Bedingungen ausüben können.
<G-vec00241-002-s096><carry.ausüben><en> With its modern facilities and secure, adapted equipment, you can carry out your chosen activity with confidence.
<G-vec00241-002-s096><carry.ausüben><de> In seinen modernen Räumlichkeiten und mit angepassten und sicheren Geräten können Sie die Aktivität Ihrer Wahl sicher ausüben.
<G-vec00241-002-s097><carry.ausüben><en> Journalists must be able to carry out their work freely, without fear of being intimidated or arrested.
<G-vec00241-002-s097><carry.ausüben><de> Journalisten müssen ihren Beruf in völliger Freiheit ausüben können, ohne befürchten zu müssen, eingeschüchtert oder festgenommen zu werden.
<G-vec00241-002-s098><carry.ausüben><en> Without prejudice to Article 31, the relevant provisions of Title II and Title IV, with the exception of Articles 35(1a) and 40, shall apply to the activities of entities directly or indirectly controlled, or owned in whole or in part, by collective management organisations provided that those entities carry out an activity which, if carried out by the collective management organisation, would be subject to the provisions of those Titles.
<G-vec00241-002-s098><carry.ausüben><de> (3) Die einschlägigen Bestimmungen dieser Richtlinie gelten für Einrichtungen, die sich direkt oder indirekt, vollständig oder teilweise, im Eigentum einer Organisation für die kollektive Rechtewahrnehmung befinden oder direkt oder indirekt, vollständig oder teilweise, von einer solchen beherrscht werden, sofern diese Einrichtungen eine Tätigkeit ausüben, die, würde sie von einer Organisation für die kollektive Rechtewahrnehmung ausgeführt, den Bestimmungen dieser Richtlinie unterläge.
<G-vec00241-002-s099><carry.ausüben><en> Web browsers are responsible for storing tools and the cookies from this site must carry out its right to removal or disabling them.
<G-vec00241-002-s099><carry.ausüben><de> Web-Browser sind die Werkzeuge zuständig zur Aufbewahrung von Cookies und von dieser Stelle aus können Sie Ihr Recht ausüben zur Entfernung oder Deaktivierung dieser.
<G-vec00241-002-s100><carry.ausüben><en> Jesus: I know, My daughter, that you understand it and that you do everything within your power. But write this for the many souls who are often worried because they do not have the material means with which to carry out an act of mercy.
<G-vec00241-002-s100><carry.ausüben><de> Jesus: Ich weiß, Meine Tochter, dass du sie verstehst und alles, was in deiner Macht ist, tust – aber schreibe das für viele Seelen auf, die sich manchmal grämen, weil sie keine materiellen Güter besitzen, durch die sie Barmherzigkeit ausüben könnten.
<G-vec00241-002-s101><carry.ausüben><en> The standard should be applicable by all types of organizations. (e.g. regardless of their size, location, the nature of their activities and products, and the culture, society and environment in which they carry out their activities.)
<G-vec00241-002-s101><carry.ausüben><de> Dieser Standard soll für alle Organisationen anwendbar sein, unabhängig von ihrer Größe, ihrem Sitz, der Art ihrer Tätigkeit und ihrer Produkte sowie von der Kultur, der Gesellschaft und dem Umfeld, in dem sie ihre Tätigkeiten ausüben.
<G-vec00241-002-s102><carry.ausüben><en> Operators – farming professionals who carry out activities linked to the application of pesticides, i.e.
<G-vec00241-002-s102><carry.ausüben><de> Anwender – Landwirte, die Tätigkeiten im Zusammenhang mit dem Einsatz von Pestiziden ausüben, z.
<G-vec00241-002-s103><carry.ausüben><en> You will carry out a major piece of independent work where you can apply what you have learned in the course to a business management issue which interests you.
<G-vec00241-002-s103><carry.ausüben><de> Sie werden eine größere selbständige Tätigkeit ausüben, bei der Sie das Gelernte auf ein betriebswirtschaftliches Thema anwenden können, das Sie interessiert.
<G-vec00241-002-s104><carry.ausüben><en> Help from the dark side: Using dark channel fluorescence, scientists can explain how biochemical substances carry out their function.
<G-vec00241-002-s104><carry.ausüben><de> Hilfe von der dunklen Seite: Wissenschaftler können dank Dark-Channel-Fluoreszenz aufklären, wie biochemische Stoffe ihre Funktion ausüben.
<G-vec00241-002-s105><carry.ausüben><en> The Bank and those subsidiaries which carry out licensable activities are authorized and regulated by regulatory authorities in their country of incorporation as well as, in some instances, by regulatory authorities in other jurisdictions.
<G-vec00241-002-s105><carry.ausüben><de> Die Bank sowie jene Tochtergesellschaften, die erlaubnispflichtige Tätigkeiten ausüben, sind durch Aufsichtsbehörden in ihrem Sitzland sowie in einigen Fällen durch Aufsichtsbehörden anderer Länder zugelassen und stehen unter deren Aufsicht.
<G-vec00241-002-s106><carry.ausüben><en> The first priority is to secure your family or your ability to work if you can no longer carry out your trading activity.
<G-vec00241-002-s106><carry.ausüben><de> Es gilt in erster Linie Ihre Arbeitskraft abzusichern, falls Sie Ihre Unternehmertätigkeit nicht mehr ausüben können.
<G-vec00241-002-s107><carry.ausüben><en> A document certifying the establishment or foundation of a legal entity that is to carry out the activities of a school or educational establishment.
<G-vec00241-002-s107><carry.ausüben><de> Beleg, der die Errichtung oder Gründung der juristischen Person, die die Tätigkeit der Schule oder der Schulanlage ausüben wird, bescheinigt.
<G-vec00241-002-s108><carry.ausüben><en> • Training courses and further training measures train and motivate our employees to carry out their tasks in a responsible way, in accordance with our environmental policies.
<G-vec00241-002-s108><carry.ausüben><de> • Durch gezielte Aus- und Weiterbildungsmaßnahmen, schulen und motivieren wir unsere Mitarbeiter so, dass sie ihre Tätigkeiten verantwortungsbewusst im Sinne unserer Umweltzielsetzung ausüben können.
<G-vec00241-002-s109><carry.ausüben><en> (iii) the structures, subjects and external companies the Data Controller uses to carry out connected instrumental operations or operations consequential to the execution of website services - including the cloud computing archival service - for sending the Newsletter;
<G-vec00241-002-s109><carry.ausüben><de> (ii) externen Einrichtungen, Personen und Unternehmen, denen sich die Verantwortliche für das Ausüben von zusammenhängenden, instrumentellen oder für die Ausübung der Serviceleistungen auf der Seite folgenden Aktivitäten - inklusive des Services Cloud Computing – bedient.
<G-vec00241-002-s110><carry.ausüben><en> Getting up early, the hustle and bustle of travelling, job stress and a long list of other activities we carry out every day cause us to lose strength as time passes by.
<G-vec00241-002-s110><carry.ausüben><de> Das frühe Aufstehen, der Stress im Verkehr, der Arbeitsalltag und eine lange Liste an Aktivitäten, die wir jeden Tag ausüben, lässt uns Energie verlieren, während die Stunden vergehen.
<G-vec00241-002-s111><carry.ausüben><en> Such a National Society must be open to all and must carry out its humanitarian work throughout its territory.
<G-vec00241-002-s111><carry.ausüben><de> Sie muss allen offen stehen und ihre humanitäre Tätigkeit im ganzen Gebiet ausüben.
<G-vec00241-002-s112><carry.ausüben><en> The conditions under which the consular agencies referred to in paragraph 1 of this Article may carry on their activities and the privileges and immunities which may be enjoyed by the consular agents in charge of them shall be determined by agreement between the sending State and the receiving State.
<G-vec00241-002-s112><carry.ausüben><de> (2) Die Bedingungen, unter denen Konsularagenturen im Sinne von Absatz 1 ihre Tätigkeit ausüben können, und die Vorrechte und Immunitäten, welche die ihnen vorstehenden Konsularagenten genießen sollen, werden in gegenseitigem Einvernehmen zwischen dem Entsendestaat und dem Empfangsstaat festgesetzt.
<G-vec00241-002-s113><carry.ausüben><en> ▌ (26) The ECB should carry out its tasks subject to and in compliance with relevant Union law ▌including the whole of primary and secondary Union law, Commission decisions in the area of State aids, competition rules and merger control and the single rulebook applying to all Member States.
<G-vec00241-002-s113><carry.ausüben><de> Die EZB sollte ihre Aufgaben gemäß und in Übereinstimmung mit dem einschlägigen Unionsrecht ausüben, einschließlich des gesamten Primär- und Sekundärrechts der Union, der Beschlüsse der Kommission zu staatlichen Beihilfen, der Wettbewerbsvorschriften und der Bestimmungen zur Fusionskontrolle sowie des für alle Mitgliedstaaten geltenden einheitlichen Regelwerks.
<G-vec00241-002-s114><carry.befördern><en> In former times they used an open pond, from which they had to carry their drinking water in canoa.
<G-vec00241-002-s114><carry.befördern><de> Früher haben sie einen offenen Brunnen benutzt, und mussten das Trinkwasser mit Kanus befördern.
<G-vec00241-002-s115><carry.befördern><en> The maximum one-time batch we will carry for you is 24 tons of material.
<G-vec00241-002-s115><carry.befördern><de> Die maximale einmalige Menge, die wir für Sie befördern, beträgt 24 Tonnen Material.
<G-vec00241-002-s116><carry.befördern><en> The human body is comprised of several different circulatory systems which carry substances vital for survival.
<G-vec00241-002-s116><carry.befördern><de> Der menschliche Körper enthält verschiedene Kreisläufe, welche Substanzen befördern, die lebenswichtig sind.
<G-vec00241-002-s117><carry.befördern><en> Allison Automatics are designed to carry more tonnage per gallon/liter of fuel and give you a choice of operating modes to best suit your driving conditions.
<G-vec00241-002-s117><carry.befördern><de> Unsere Getriebe werden entwickelt, um mehr Tonnen Ladung pro Liter Kraftstoff zu befördern und Ihnen die Möglichkeit zu geben, je nach Fahrbedingungen zwischen unterschiedlichen Betriebsarten zu wählen.
<G-vec00241-002-s118><carry.befördern><en> The aluminium bag hook offers you a safe way to carry your shopping bag or handbag without having to access other valuable storage space.
<G-vec00241-002-s118><carry.befördern><de> Der Aluminium Taschenhaken bietet Dir eine sichere Möglichkeit Deine Einkaufstasche oder Handtasche zu befördern, ohne auf anderen wertvollen Stauraum zurück zugreifen.
<G-vec00241-002-s119><carry.befördern><en> When booking and checking in for Aeroflot PJSC flights, the passenger must declare his/her intention to carry weapons as baggage.
<G-vec00241-002-s119><carry.befördern><de> Bei der Buchung und beim Check-in der Flüge mit Aeroflot PJSC muss der Passagier angeben, dass er beabsichtigt, Waffen im Gepäck zu befördern.
<G-vec00241-002-s121><carry.befördern><en> The 24 “summer lifts” of the family-friendly region carry you to the starting points of hiking trips, mountain bike tours, and joyful summer toboggan runs.
<G-vec00241-002-s121><carry.befördern><de> Beim “Sommerliftln” befördern euch 24 Bergbahnen der familienfreundlichen Region zu Ausgangspunkten für Wanderungen, Mountainbike-Touren und lustigen Sommerrodel-Partien.
<G-vec00241-002-s122><carry.befördern><en> We carry you to the airport and also pick you up again.
<G-vec00241-002-s122><carry.befördern><de> Wir befördern Sie Hin und holen Sie auch gerne wieder ab.
<G-vec00241-002-s123><carry.befördern><en> At subduction zones, slabs of oceanic lithosphere sink into the mantle and carry basaltic crust and H2O stored in hydrous minerals into Earth’s interior.
<G-vec00241-002-s123><carry.befördern><de> An Subduktionszonen sinken Platten ozeanischer Lithosphäre in den Erdmantel und befördern basaltische Erdkruste und in Mineralen gespeichertes Wasser ins Erdinnere.
<G-vec00241-002-s124><carry.befördern><en> 45 modern mountain railways carry you fast and comfortable from summit to summit.
<G-vec00241-002-s124><carry.befördern><de> 45 moderne Bergbahnen befördern Sie schnell und komfortabel von Gipfel zu Gipfel.
<G-vec00241-002-s125><carry.befördern><en> (d) TUIfly is unable to carry any animals on flights to and from the UK, owing to the country’s strict statutory requirements.
<G-vec00241-002-s125><carry.befördern><de> (d) Auf Flügen von/nach Großbritannien kann TUIfly auf Grund der strengen gesetzlichen Vorschriften keine Tiere befördern.
<G-vec00241-002-s126><carry.befördern><en> Thus, a monorail system with the highest transportation density of the world is being created, which will carry up to 48,000 passengers per hour in two directions.
<G-vec00241-002-s126><carry.befördern><de> Somit entsteht ein Monorail-System mit der höchsten Transportdichte der Welt, welches bis zu 48.000 Passagiere pro Stunde in zwei Richtungen befördern wird.
<G-vec00241-002-s127><carry.befördern><en> It had an aerodynamic body and could carry 42 passengers.
<G-vec00241-002-s127><carry.befördern><de> Es hatte eine aerodynamische Karosserie und konnte 42 Passagiere befördern.
<G-vec00241-002-s128><carry.befördern><en> Each year we carry more than one million private and corporate customers to the most attractive destinations throughout Europe!
<G-vec00241-002-s128><carry.befördern><de> Über 1 Million Privat- und Geschäftskunden befördern wir jährlich zu den attraktivsten Reisezielen innerhalb Europas.
<G-vec00241-002-s129><carry.befördern><en> 8.4.1 Subject to Articles 8.3.2 and 8.3.3, we will refuse to carry as Baggage the items described in Article 8.3, and we may refuse further carriage of any such items upon discovery.
<G-vec00241-002-s129><carry.befördern><de> 8.4.1 Vorbehaltlich Artikel 8.3.2 und 8.3.3 werden wir uns weigern, die in Artikel 8.3 beschriebenen Gegenstände als Gepäck zu befördern und können uns auch nach Entdeckung weigern, diese Gegenstände weiter als Gepäck zu befördern.
<G-vec00241-002-s131><carry.befördern><en> IEEE is now looking at ways to use wave division multiplexing (WDM) technology that will allow multiple wavelengths over the same fiber to carry signals, providing the potential to transmit 100 Gbps over a fiber pair where each fiber carries 25 Gbps on four different wavelengths.
<G-vec00241-002-s131><carry.befördern><de> IEEE untersucht jetzt Methoden, Wave Division Multiplexing-Technologie (WDM) einzusetzen, mit der mehrfache Wellenlängen über die gleiche Glasfaser Signale befördern können, mit dem Potential, 100 Gbit/s über ein Glasfaserpaar zu übertragen, wobei jede Faser 25 Gbit/s auf vier verschiedenen Wellenlängen überträgt.
<G-vec00241-002-s132><carry.befördern><en> We have specified maximum dimensions and weight for Baggage that you carry on to our aircraft.
<G-vec00241-002-s132><carry.befördern><de> Wir haben Höchstmaße und -gewicht für Gepäck festgelegt, das Sie in unserem Flugzeug befördern können.
<G-vec00241-002-s133><carry.betreiben><en> In order to carry out research efficiently, funding is needed which has to be requested from funding organisations by highly competitive applications.
<G-vec00241-002-s133><carry.betreiben><de> Um effizient Forschung betreiben zu können, werden Gelder benötigt, die bei Förderorganisationen im Wettbewerb beantragt werden müssen.
<G-vec00241-002-s134><carry.betreiben><en> See larger variant of the text Men usually work and carry on their affairs from the ordinary motives of the vital being, need, desire of wealth or success or position or power or fame or the push to activity and the pleasure of manifesting their capacities, and they succeed or fail according to their capability, power of work and the good or bad fortune which is the result of their nature and their Karma.
<G-vec00241-002-s134><carry.betreiben><de> Meist arbeiten die Menschen und betreiben ihre Geschäfte aus den üblichen Beweggründen des vitalen Wesens, weil es notwendig ist, weil sie nach Reichtum verlangen, nach Erfolg, Ansehen, Macht oder Ruhm, weil der Drang zur Aktivität in ihnen ist oder die Freude darüber, ihre Talente entfalten zu können; ihr Erfolg oder Misserfolg entspricht ihrer Begabung, ihrer Arbeitskraft und ihrem guten oder schlechten Geschick, welches das Ergebnis ihrer Natur und ihres karmas ist.
<G-vec00241-002-s135><carry.betreiben><en> As our partner, you can profit from our basic advertising activities, which we carry out for the destination as a whole, however you can also participate in selected individual advertising measures.
<G-vec00241-002-s135><carry.betreiben><de> Sie als unser Partner profitieren einerseits vom Basismarketing, welches wir für die ganze Destination betreiben, können sich aber auch ganz konkret an einzelnen Maßnahmen beteiligen.
<G-vec00241-002-s136><carry.betreiben><en> As an industrial businessperson, you will sell the products and services of our company and carry out marketing activities ranging from analysis of market potential to customer service.
<G-vec00241-002-s136><carry.betreiben><de> Industriekaufmann/frau Als Industriekaufmann/frau verkaufen Sie Produkte und Dienstleistungen unseres Unternehmens, betreiben Marketingaktivitäten von der Analyse der Marktpotenziale bis hin zum Kundenservice.
<G-vec00241-002-s137><carry.betreiben><en> Green’s colleagues at ITS carry out detailed reverse engineering and provide regular training to ensure that service engineers like Green are thoroughly experienced in a wide range of elevator systems.
<G-vec00241-002-s137><carry.betreiben><de> Kirstys Kollegen bei ITS betreiben umfassendes Reverse Engineering und führen regelmäßig Schulungen durch, um Wartungstechnikern gründliche Kenntnisse zu unterschiedlichsten Aufzugssystemen zu vermitteln.
<G-vec00241-002-s138><carry.betreiben><en> Until then we had not had at our disposal any organ in which we could voice our views, and so we had lacked the opportunity to carry on the effective political and social enlightenment of our followers, a thing that was needed very much.
<G-vec00241-002-s138><carry.betreiben><de> Wir hatten bis dahin kein Organ zur Verfügung gehabt, in dem wir unsere Ansichten vertreten konnten, damit war auch keine Möglichkeit gegeben, die politische und soziale Aufklärung unserer Anhänger genügend zu betreiben, und das tat vor allem not.
<G-vec00241-002-s139><carry.betreiben><en> The user orientation and relevance: You can only carry out successful content marketing if you truly know your target groups.
<G-vec00241-002-s139><carry.betreiben><de> Die Nutzerorientierung und -relevanz: Nur wer seine Zielgruppen kennt, kann auch erfolgreich Online-Marketing betreiben.
<G-vec00241-002-s140><carry.betreiben><en> The Turkish churches have shown the Christian Church worldwide that it is possible to carry out this mission in unity.
<G-vec00241-002-s140><carry.betreiben><de> Die türkischen Kirchen haben der weltweiten christlichen Kirche gezeigt, dass es möglich ist, diese Mission in Einigkeit zu betreiben.
<G-vec00241-002-s141><carry.betreiben><en> The group may also include legal entities which do not carry on a business, and individuals.
<G-vec00241-002-s141><carry.betreiben><de> In die Gruppe können auch Rechtsträger, die kein Unternehmen betreiben, und natürliche Personen einbezogen werden.
<G-vec00241-002-s142><carry.betreiben><en> ‘1. Member States may impose reasonable “must carry” obligations, for the transmission of specified radio and television broadcast channels and complementary services, particularly accessibility services to enable appropriate access for disabled end-users, on undertakings under their jurisdiction providing electronic communications networks used for the distribution of radio or television broadcast channels to the public where a significant number of end-users of such networks use them as their principal means to receive radio and television broadcast channels.
<G-vec00241-002-s142><carry.betreiben><de> „(1) Die Mitgliedstaaten können zur Übertragung bestimmter Hör- und Fernsehrundfunkkanäle und ergänzender, insbesondere zugangserleichternder Dienste, die behinderten Endnutzern einen angemessenen Zugang ermöglichen, den ihrer Rechtshoheit unterliegenden Unternehmen, die für die öffentliche Verbreitung von Hörfunk- und Fernsehrundfunkkanälen genutzte elektronische Kommunikationsnetze betreiben, zumutbare Übertragungspflichten auferlegen, wenn eine erhebliche Zahl von Endnutzern diese Netze als Hauptmittel zum Empfang von Hörfunk- und Fernsehrundfunkkanälen nutzt.
<G-vec00241-002-s143><carry.betreiben><en> ERC grants are open for researchers of any nationality and age who want to carry our frontier research in the EU or an associated county.
<G-vec00241-002-s143><carry.betreiben><de> ERC-Stipendien sind für Forschende jeglicher Nationalität und jeglichen Alters zugänglich, die in der EU oder in einem assoziierten Land Grundlagenforschung betreiben wollen.
<G-vec00241-002-s144><carry.betreiben><en> Because a large portion of our income is based on the US dollar, we carry out extensive hedging.
<G-vec00241-002-s144><carry.betreiben><de> Da ein großer Teil unserer Einnahmen US-Dollar-basiert ist, betreiben wir umfangreiche Sicherungsgeschäfte.
<G-vec00241-002-s145><carry.betreiben><en> Beyond this the seller is not entitled to carry out advertising in any form.
<G-vec00241-002-s145><carry.betreiben><de> Der Verkäufer ist nicht berechtigt, darüber hinausgehende Werbung in irgendeiner Form zu betreiben.
<G-vec00241-002-s146><carry.betreiben><en> This is the time we spend to carry out and manage our job as conference interpreter professionally - including our role as entrepreneurs.
<G-vec00241-002-s146><carry.betreiben><de> Hier geht es um den Aufwand, den wir betreiben, um unseren Beruf professionell auszuüben - auch in unserer Rolle als selbständige Unternehmer.
<G-vec00241-002-s147><carry.betreiben><en> In order to always be able to work according to the state of science and technology, we regularly carry out applied research and development.
<G-vec00241-002-s147><carry.betreiben><de> Um immer dem Stand von Wissenschaft und Technik entsprechend arbeiten zu können, betreiben wir regelmäßig angewandte Forschung und Entwicklung.
<G-vec00241-002-s148><carry.betreiben><en> Brokerage We carry out comprehensive research for you, and deliver in-depth financial analysis.
<G-vec00241-002-s148><carry.betreiben><de> Brokerage Wir betreiben für Sie ein umfassendes Research und verschaffen Ihnen vertiefte Finanzanalysen.
<G-vec00241-002-s149><carry.betreiben><en> For each of these awards, Frost & Sullivan analysts independently conduct interviews, analyse data, and carry out research in many different fields.
<G-vec00241-002-s149><carry.betreiben><de> Für jede dieser Auszeichnungen führen die Analysten von Frost & Sullivan Interviews durch, analysie-ren Daten und betreiben Forschung in verschiedenen Bereichen.
<G-vec00241-002-s150><carry.betreiben><en> A bank with an “A” licence, with permission to carry out banking transactions within and outwith the Cayman Islands, pays 400,000 KYD a year in official fees.
<G-vec00241-002-s150><carry.betreiben><de> Eine A-Bank-Lizenz, mit der Erlaubnis Bankgeschäfte innerhalb -und außerhalb Cayman Island zu betreiben, zahlt jährliche behördliche Gebühren von 400.000 CI$ (400.000 CI$ = 334.200 EUR gerundet).
<G-vec00241-002-s151><carry.betreiben><en> An attempt is made to simplify natural language and to translate it into a new language but not to the extent that the sense of the statement gets lost. It is just simplified enough so that a computer program can carry out combination theory n.
<G-vec00241-002-s151><carry.betreiben><de> Es wird also versucht die natürliche Sprache zu vereinfachen und in eine neue Sprache zu übersetzen, allerdings nur soweit, dass der Sinn der Aussage nicht verloren geht, aber doch soweit, dass ein Computerprogramm damit Kombinatorik betreiben kann.
<G-vec00241-002-s152><carry.bringen><en> With a certain satisfaction I reflected there was enough gin concealed about the house to carry me through that night and the next day.
<G-vec00241-002-s152><carry.bringen><de> Mit einer gewissen Befriedigung dachte ich daran, daß genug Gin im Hause versteckt war, um mich durch die Nacht und über den nächsten Tag zu bringen.
<G-vec00241-002-s153><carry.bringen><en> The Dutch-language media carry news broadcasts in Dutch on radio and TV, in newspapers and magazines.
<G-vec00241-002-s153><carry.bringen><de> Die niederländischsprachigen Medien bringen die Nachrichten im Radio und Fernsehen, in Zeitungen und Zeitschriften auf Niederländisch.
<G-vec00241-002-s154><carry.bringen><en> When workers at the Indianapolis GM plant voted down a wage-cutting deal and denounced UAW officials for accepting it, the SEP organized a rank-and-file committee to carry forward the rebellion.
<G-vec00241-002-s154><carry.bringen><de> Als die Arbeiter des GM-Werkes in Indianapolis gegen einen Tarifvertrag stimmten, durch den die Löhne gekürzt worden wären, und die UAW-Funktionäre dafür kritisierten, ihn akzeptiert zu haben, organisierte die SEP ein Basiskomitee, um die Rebellion vorwärts zu bringen.
<G-vec00241-002-s155><carry.bringen><en> Eight lifts will carry them back up into the mountains between the descents, and time can only be credited on the valley runs.
<G-vec00241-002-s155><carry.bringen><de> 8 Lifte bringen die Teilnehmer zwischen den Abfahrten immer wieder auf die Berge, nur in Richtung Tal kann wichtige Zeit gutgeschrieben werden.
<G-vec00241-002-s156><carry.bringen><en> Overview The highly complex technical equipment of data centers and other IT areas, as well as the materials used there, carry a particularly high risk of fire.
<G-vec00241-002-s156><carry.bringen><de> Überblick Die hochkomplexe technische Ausstattung von Data Centern und anderen IT-Bereichen und die dort eingesetzten Materialien bringen ein besonders hohes Brandrisiko mit sich.
<G-vec00241-002-s157><carry.bringen><en> 23:19 Thou shalt carry the firstfruits of the corn of thy ground to the house of the Lord thy God.
<G-vec00241-002-s157><carry.bringen><de> 23:19 Das Erstling von der ersten Frucht auf deinem Felde sollst du bringen in das Haus des HERRN, deines Gottes.
<G-vec00241-002-s158><carry.bringen><en> 3 When I arrive, I will send whoever you approve with letters to carry your gracious gift to Jerusalem.
<G-vec00241-002-s158><carry.bringen><de> 3Wenn ich aber gekommen bin, will ich die, die ihr für bewährt haltet, mit Briefen senden, damit sie eure Gabe nach Jerusalem bringen.
<G-vec00241-002-s159><carry.bringen><en> We want to inform, that we don't have an elevator - but of course we can help to carry your luggage into your room.
<G-vec00241-002-s159><carry.bringen><de> Wir möchten darauf hinweisen, dass wir in unserem Haus keinen Lift haben - aber selbstverständlich helfen wir Ihnen sehr gerne Ihr Gepäck in Ihr Zimmer oder Apartment zu bringen.
<G-vec00241-002-s160><carry.bringen><en> The first port is for the ferry boats that carry passengers to the islands.
<G-vec00241-002-s160><carry.bringen><de> Der erste Hafen dient Fähren, die Passagiere auf die Inseln bringen.
<G-vec00241-002-s161><carry.bringen><en> Calmly and sweetly ask him to carry your books or your backpack for you to the next class.
<G-vec00241-002-s161><carry.bringen><de> Bitte ihn ganz süß und ruhig darum, deine Bücher oder deinen Rucksack in das nächste Unterrichtszimmer zu bringen.
<G-vec00241-002-s162><carry.bringen><en> It is strictly forbidden to carry any kind of weapon or dangerous materials like explosives, gas, gasoline or other inflammable substances.
<G-vec00241-002-s162><carry.bringen><de> Es ist den Passagieren verboten, in jeglicher Art und Weise Waffen jeder Art und gefährliche Substanzen, wie Sprengstoffe, Gas, Treibstoffe oder andere entzündbare Substanzen, an Bord zu bringen.
<G-vec00241-002-s163><carry.bringen><en> Both choices carry their own set of consequences that you will need to know about.
<G-vec00241-002-s163><carry.bringen><de> Beide Wahlen bringen Konsequenzen mit sich, über die Sie Bescheid wissen sollten.
<G-vec00241-002-s164><carry.bringen><en> So Masters do not touch the outer labels when they come. The outer labels carry with them their own customs, their own ways of living and climatic influences.
<G-vec00241-002-s164><carry.bringen><de> Meister rühren nicht an äußeren Kennzeichen, wenn sie kommen, Die äußeren Kennzeichen bringen ihre eigenen Bräuche, ihre eigene Art zu leben mit sich, je nach den klimatischen Einflüssen.
<G-vec00241-002-s165><carry.bringen><en> CFDs and Forex are leveraged products and carry a high degree of risk to your capital and it is possible to lose more than your initial investment.
<G-vec00241-002-s165><carry.bringen><de> Risikohinweis CFDs und Forex sind Produkte mit Hebelwirkung, die ein hohes Risiko für Ihr Kapital mit sich bringen, so dass Sie möglicherweise mehr als Ihre ursprüngliche Investition verlieren können.
<G-vec00241-002-s166><carry.bringen><en> When our plant, by this process of the continued preservation or natural selection of more and more attractive flowers, had been rendered highly attractive to insects, they would, unintentionally on their part, regularly carry pollen from flower to flower; and that they can most effectually do this, I could easily show by many striking instances.
<G-vec00241-002-s166><carry.bringen><de> Wenn nun unsere Pflanze durch diesen Process der bestän-digen Erhaltung oder der natürlichen Auswahl immer gesuchtererBlüthen für die Insecten sehr anziehend geworden ist, so wer-den diese, ihrerseits ganz unabsichtlich, regelmäßig Pollen vonBlüthe zu Blüthe bringen: und dass sie dies sehr wirksamzu thun vermögen, konnte ich durch viele auffallende Beispielebelegen.
<G-vec00241-002-s167><carry.bringen><en> By the way, Untrue starts very promising: Human Being Human and Warmonger carry a satisfying energy that stays near to Entombed’s mangy sound.
<G-vec00241-002-s167><carry.bringen><de> Dabei fängt die Scheibe recht viel versprechend an: Human Being Human und Warmonger bringen eine gute Energie mit sich, die sich teilweise in den räudigen Entombed Gefilden aufhält.
<G-vec00241-002-s168><carry.bringen><en> Sweepingly applied colors and lines that run throughout the paintings, carry the tension to non-representational art.
<G-vec00241-002-s168><carry.bringen><de> Schwungvoll aufgetragene Farben und Linien, die die Gemälde durchziehen, bringen Spannung in die nicht gegenständliche Kunst.
<G-vec00241-002-s169><carry.bringen><en> Everything from high tech fishing vessels to small family boats carry fresh fish into the harbour.
<G-vec00241-002-s169><carry.bringen><de> Von high-tech Fischereifahrzeugen bis hin zu kleinen Booten aus dem Familienbetrieb bringen alle frischen Fisch in den Hafen.
<G-vec00241-002-s170><carry.bringen><en> Unfortunately, the tides don’t carry only good things for the wadden region.
<G-vec00241-002-s170><carry.bringen><de> Leider bringen die Gezeiten nicht nur gute Dinge in das Wattenmeer.
<G-vec00241-002-s247><carry.durchführen><en> In addition, there should be an obligation to carry out, after the resolution tools have been applied, an ex post comparison between the treatment that shareholders and creditors have actually been afforded and the treatment they would have received under normal insolvency proceedings.
<G-vec00241-002-s247><carry.durchführen><de> Darüber hinaus sollte — soweit nach dieser Richtlinie vorgeschrieben — nach Anwendung der Abwicklungsinstrumente ein Ex-post-Vergleich zwischen der Behandlung durchgeführt werden, die Anteilseigner und Gläubiger tatsächlich erfahren haben, und der, die sie im Rahmen eines regulären Insolvenzverfahrens erfahren hätten.
<G-vec00241-002-s248><carry.durchführen><en> To do this, we work with you to carry out the scoping phases as fit gap analyses on your system, then communicate the planned project results in an accessible manner.
<G-vec00241-002-s248><carry.durchführen><de> Dafür werden die Scoping-Phasen als Fit-Gap-Analysen mit Ihnen gemeinsam und am System durchgeführt und die geplanten Projektergebnisse greifbar vermittelt.
<G-vec00241-002-s249><carry.durchführen><en> Particularly if you taste one of the six Trappist beers, brewed in an abbey where monks carry out or oversee the production process.
<G-vec00241-002-s249><carry.durchführen><de> Vor allem, wenn Sie eines der sechs Trappistenbiere probieren, die in Abteien gebraut werden und deren Herstellung von Mönchen durchgeführt oder kontrolliert wird.
<G-vec00241-002-s250><carry.durchführen><en> Everybody who has ever used Word, Excel & Co. to carry out the organisation, documentation and follow-up work for these meetings knows how much administrative effort can be involved.
<G-vec00241-002-s250><carry.durchführen><de> Jeder, der die Organisation, Dokumentation und Nachbereitung dieser Gespräche schon einmal mit Word, Excel & Co durchgeführt hat, weiß welcher Administrationsaufwand dahinter stecken kann.
<G-vec00241-002-s251><carry.durchführen><en> Learn how to plan and implement operational workflows in accordance with GDPR guidelines, how automated workflows are used in personnel management at Wien Energy, and how to carry over a business process into an executable workflow, among other topics.
<G-vec00241-002-s251><carry.durchführen><de> Dabei erfahren Sie unter anderem wie die Planung und Umsetzung der operativen Workflows gemäß DSGVO Richtlinien durchgeführt wurde, wie automatisierte Workflows im Personalmanagement bei Wien Energie eingesetzt werden und wie der Geschäftsprozess in einen lauffähigen Workflow überführt wurde.
<G-vec00241-002-s252><carry.durchführen><en> To that end, they shall carry out an audit of work programmes and a control plan involving a sample determined on the basis of a risk analysis and comprising at least 30 % per year of producer organisations and all the other operators' organisations in receipt of Community funding under this Article.
<G-vec00241-002-s252><carry.durchführen><de> Zu diesem Zweck werden Prüfungen der Aktionsprogramme und Stichprobenkontrollen durchgeführt, die auf der Grundlage einer Risikoanalyse festgelegt werden und die in einem Jahr mindestens 30 % der Erzeugerorganisationen sowie die Gesamtheit der anderen Marktteilnehmerorganisationen umfassen, denen eine Gemeinschaftsfinanzierung im Rahmen dieses Artikels gewährt wird.
<G-vec00241-002-s253><carry.durchführen><en> Depending on the entries selected (service, Active Directory user, user account), it is necessary to carry out corresponding assignments in the Conversion Wizard for the passwords.
<G-vec00241-002-s253><carry.durchführen><de> Je nach Auswahl der Einträge (Dienst, Active Directory Benutzer, Benutzerkonto) müssen entsprechende Zuordnungen im Konvertierungs-Assistent für die Passwörter durchgeführt werden.
<G-vec00241-002-s254><carry.durchführen><en> And by showing you how content is discovered and accessed, this information can help you decide which devices and platforms to support and carry out video optimization for, what distribution strategies to employ and how to optimize ad placement, pricing structures and product portfolios.
<G-vec00241-002-s254><carry.durchführen><de> Indem Ihnen gezeigt wird, wie Inhalte gefunden werden und wie auf sie zugegriffen wird, können Sie leichter entscheiden, welche Geräte und Plattformen unterstützt, für welche davon die Videooptimierung durchgeführt und welche Vertriebsstrategien genutzt werden sollen.
<G-vec00241-002-s255><carry.durchführen><en> In other words, the problem is how to carry out automatically, without a massive data processing burden, a task which is not easy, even to a human being.
<G-vec00241-002-s255><carry.durchführen><de> Mit anderen Worten gehe es darum, wie eine auch für den Menschen nicht einfache Aufgabe ohne enormen Datenverarbeitungsaufwand maschinell durchgeführt werden könne.
<G-vec00241-002-s256><carry.durchführen><en> This is due to its wide range of loading functions, which it can carry out for an array of loading applications depending on the user and industry requirements.
<G-vec00241-002-s256><carry.durchführen><de> Dies liegt an der breiten Palette von Ladefunktionen, die je nach Anwender- und Branchenanforderungen für eine Vielzahl von Ladeanwendungen durchgeführt werden können.
<G-vec00241-002-s257><carry.durchführen><en> Most bishops are highly reluctant and timid to grant and carry out the major exorcism in general as well.
<G-vec00241-002-s257><carry.durchführen><de> Auch der Exorzismus im Allgemei- nen wird von den meisten Bischöfen nur noch äußerst zögernd und ängstlich zugestanden und durchgeführt.
<G-vec00241-002-s258><carry.durchführen><en> Detailed plan Once you have chosen the day from the reservation system, you will be contacted for more detailed information and to confirm whether or not to carry out the flight (the activity can only be carried out with good weather).
<G-vec00241-002-s258><carry.durchführen><de> Sobald Sie den Tag, für dieses Erlebnis entschieden haben, und die Reservierung getätigt haben, werden wir Sie für weitere Informationen kontaktieren und um zu bestätigen, ob der Flug durchgeführt (die Aktivität kann nur bei gutem Wetter durchgeführt werden) werden kann.
<G-vec00241-002-s259><carry.durchführen><en> The trainer has been designed so that it is possible to carry out a complete preheating as part of a practical experiment.
<G-vec00241-002-s259><carry.durchführen><de> Der Versuchsstand wurde so dimensioniert, dass ein kompletter Aufheizvorgang im Rahmen eines Praktikumsversuchs durchgeführt werden kann.
<G-vec00241-002-s260><carry.durchführen><en> You can also carry out the speed test in the Home app.
<G-vec00241-002-s260><carry.durchführen><de> Der Speedtest kann auch in der Home App durchgeführt werden.
<G-vec00241-002-s261><carry.durchführen><en> In order to develop an innovative, longer-term foresight process by and for the Fraunhofer-Gesellschaft, we will carry out another scanning process together with our project partners ISI, IAO, and INT, on the basis of available results and experience.
<G-vec00241-002-s261><carry.durchführen><de> Um einen innovativen, längerfristigen Foresight-Prozess von und für die Fraunhofer-Gesellschaft zu entwickeln, wird ausgehend von den vorliegenden Ergebnissen und Erfahrungen gemeinsam mit den Projektpartnern ISI, IAO und INT ein weiterer Scanning-Prozess durchgeführt, bei dem neue methodische Elemente entwickelt und erprobt werden sollen.
<G-vec00241-002-s262><carry.durchführen><en> We organise and carry out own cultural and educational events - also in cooperation with other institutions.
<G-vec00241-002-s262><carry.durchführen><de> Es werden eigene Kultur- und Bildungsveranstaltungen organisiert und durchgeführt – auch in Kooperation mit anderen Einrichtungen.
<G-vec00241-002-s263><carry.durchführen><en> This unity of the world proletariat is only possible with a single world organization; whose decisions all the Communist parties do carry out, to the best knowledge and belief.
<G-vec00241-002-s263><carry.durchführen><de> Diese Einheit des Weltproletariats kann nur durch eine einheitliche Weltorganisation verwirklicht werden, deren Beschlüsse von allen Kommunistischen Parteien nach bestem Wissen und Gewissen durchgeführt werden.
<G-vec00241-002-s264><carry.durchführen><en> We will carry out such reimbursement using the same means of payment as you used for the initial transaction, unless we have expressly agreed otherwise, in any event, you will not incur any fees as a result of such reimbursement.
<G-vec00241-002-s264><carry.durchführen><de> Eine solche Rückvergütung wird mit demselben Zahlungsmittel durchgeführt, das Sie für die ursprüngliche Transaktion verwendet haben, sofern wir nicht ausdrücklich etwas anderes vereinbart haben; auf keinen Fall jedoch werden sich für Sie Gebühren aus einer solchen Rückvergütung ergeben.
<G-vec00241-002-s265><carry.durchführen><en> Only a small number of centres in the world carry out research into the development and establishment of human pain models, and FAU is one of them.
<G-vec00241-002-s265><carry.durchführen><de> Die Entwicklung und Etablierung menschlicher Schmerzmodelle wird weltweit in nur sehr wenigen Zentren durchgeführt, eines davon ist die FAU.
<G-vec00241-002-s304><carry.erfüllen><en> g) A party member can be a sympathizer of the party on his/her own will when he/she is under strain to carry out the obligations of being a party member because his/her development is not in line with that of the Party.
<G-vec00241-002-s304><carry.erfüllen><de> g) ein Parteimitglied, dem es schwer fällt, die Pflichten eines Parteimitglieds zu erfüllen, da es nicht Schritt halten kann mit der Entwicklung der Partei, kann auf eigenen Wunsch Sympathisant der Partei werden.
<G-vec00241-002-s305><carry.erfüllen><en> Dr. Oliver Müller / Josef Mackert: Professor Wagner, the goal of synthetic biology is often defined as the production of tailor-made biological components which can carry out certain tasks.
<G-vec00241-002-s305><carry.erfüllen><de> Dr. Oliver Müller/Josef Mackert: Herr Prof. Wagner, nach einer üblichen Definition ist das Ziel der synthetischen Biologie die Produktion von maßgeschneiderten Bio-Bauteilen, die bestimmte Aufgaben erfüllen können.
<G-vec00241-002-s306><carry.erfüllen><en> With these sentiments, as I assure you of my remembrance in prayer, I willingly bless all consecrated persons and the Christian communities in which they are called to carry out their mission.
<G-vec00241-002-s306><carry.erfüllen><de> Mit diesen Gefühlen, während ich ein Gedenken im Gebet zusichere, segne ich alle geweihten Personen und die christlichen Gemeinschaften, in denen sie berufen sind, ihre Sendung zu erfüllen.
<G-vec00241-002-s307><carry.erfüllen><en> A Western organization can hardly carry out such a kind of work without own Indian Indian assistants.
<G-vec00241-002-s307><carry.erfüllen><de> Eine westliche Organisation kann eine solche Arbeit ohne eigene indische Mitarbeiter kaum erfüllen.
<G-vec00241-002-s308><carry.erfüllen><en> May she make every priest aware of the lofty mission he is called to carry out with a pure heart and docility to the action of the Holy Spirit, to pour out upon the world with the creativity and ardour of love the gift that he himself receives upon the altar.
<G-vec00241-002-s308><carry.erfüllen><de> Sie mache jedem Priester die hohe Sendung bewußt, die er seiner Berufung entsprechend mit reinem Herzen und im Gehorsam gegenüber dem Handeln des Heiligen Geistes erfüllen soll, damit er das Geschenk, das er selbst auf dem Altar empfängt, mit der Phantasie und dem Feuer der Liebe auf die Welt ausgießen kann.
<G-vec00241-002-s309><carry.erfüllen><en> 21 And when a man offers a sacrifice of peace offerings to Jehovah to carry out his vow, or a free-will offering in cattle or sheep, it shall be without blemish to be accepted. There shall be no blemish in them.
<G-vec00241-002-s309><carry.erfüllen><de> 21 Und wenn jemand dem Jehova ein Friedensopfer darbringt, um ein Gelübde zu erfüllen, oder als freiwillige Gabe vom Rind- oder Kleinvieh: ohne Fehl soll es sein, zum Wohlgefallen; keinerlei Gebrechen soll an ihm sein.
<G-vec00241-002-s310><carry.erfüllen><en> In order to carry out our customers’ translation projects quickly, reliably and with the highest quality, we are looking for qualified translators, editors and other language experts to join our team.
<G-vec00241-002-s310><carry.erfüllen><de> Um die Aufträge unserer Kunden schnell, zuverlässig und in höchster Qualität zu erfüllen, suchen wir qualifizierte Übersetzer, Lektoren und andere Fachspezialisten.
<G-vec00241-002-s311><carry.erfüllen><en> They live in the heavens, from which they descend to carry out the duties appointed to them.
<G-vec00241-002-s311><carry.erfüllen><de> Drittens: Sie leben in den Himmeln und von dort steigen sie herab, um die ihnen aufgetragenen Pflichten zu erfüllen.
<G-vec00241-002-s312><carry.erfüllen><en> While we carry out our mission we strive to be a responsible visitor on our planet.
<G-vec00241-002-s312><carry.erfüllen><de> Wir streben danach beim Erfüllen unserer Aufgaben ein verantwortungsbewusster Gast auf unserem Planeten zu sein.
<G-vec00241-002-s313><carry.erfüllen><en> When you enquire about or purchase one or more of these products, the relevant third-party product provider will use your details to provide you with information and carry out their obligations arising from any contracts you have entered into with them.
<G-vec00241-002-s313><carry.erfüllen><de> Wenn Sie eine Anfrage zu einem oder mehreren dieser Produkte haben oder einen Kauf abschließen, verwendet der zuständige Drittanbieter von Produkten Ihre Angaben, um Ihnen Informationen zur Verfügung zu stellen oder seine Verpflichtungen aus allen Verträgen, die Sie mit ihm abgeschlossen haben, zu erfüllen.
<G-vec00241-002-s314><carry.erfüllen><en> If a minister is temporarily unable to carry out his duties because of illness or other hindrances, the President of the Republic acting on the proposal of the Prime Minister transfers his duties to another minister.
<G-vec00241-002-s314><carry.erfüllen><de> Wenn ein Minister wegen Krankheit oder sonstiger Hindernisse zeitweilig seine Obliegenheiten nicht erfüllen kann, werden diese Obliegenheiten vom Präsidenten der Republik auf Vorschlag des Ministerpräsidenten einem anderen Minister übertragen.
<G-vec00241-002-s315><carry.erfüllen><en> Thus the Catholic community will be able to carry out its specific pastoral task with greater ease.
<G-vec00241-002-s315><carry.erfüllen><de> So wird die katholische Gemeinde die ihr wesenhafte pastorale Aufgabe leichter erfüllen.
<G-vec00241-002-s316><carry.erfüllen><en> Given the potentially devastating ecological impact and extremely high economic costs of pollution incidents, as well as the possible socioeconomic impact of such incidents on other sectors, such as tourism and fisheries, the Agency should have sufficient means to allow it to carry out its assigned tasks in relation to response to marine pollution by ships and oil and gas installations.
<G-vec00241-002-s316><carry.erfüllen><de> Angesichts der potenziell katastrophalen Auswirkungen auf die Umwelt und der sehr hohen wirtschaftlichen Kosten von Verschmutzungsereignissen sowie angesichts der möglichen sozialen und wirtschaftlichen Auswirkungen derartiger Ereignisse auf andere Wirtschaftsbereiche wie etwa Fremdenverkehr und Fischerei sollte die Agentur über ausreichende Mittel verfügen, um die ihr übertragenen Aufgaben in Bezug auf das Eingreifen bei Meeresverschmutzung durch Schiffe und durch Öl- und -Gasanlagen erfüllen zu können.
<G-vec00241-002-s317><carry.erfüllen><en> I do so with pride that our small country, our young democracy, its statehood so recently regained, has shown that it too can carry out the tasks of an EU Presidency as well as any other member state - large or small.
<G-vec00241-002-s317><carry.erfüllen><de> Ich bin stolz darauf, dass unser kleines Land, das noch nicht lange seine Unabhängigkeit genießt und somit eine junge Demokratie ist, bewiesen hat, dass es die Aufgaben der EU-Ratspräsidentschaft genauso gut erfüllen kann wie jeder anderer Mitgliedstaat auch, ganz gleich ob er groß oder klein ist.
<G-vec00241-002-s318><carry.erfüllen><en> They are normally not dangerous in their natural habitat, however, they do carry disease, so if you have a family of bats dwelling near your residence, the safest thing will be to deal with this infestation as soon as possible.
<G-vec00241-002-s318><carry.erfüllen><de> Sie sind normalerweise in ihrem natürlichen Habitat nicht gefährlich, wie sie wichtige ökologische Rollen erfüllen, indem sie Blumen bestäuben und Fruchtsamen verstreuen, sowie Pest verbrauchen.
<G-vec00241-002-s319><carry.erfüllen><en> We forward data to third parties, if this is necessary to carry out our services, for billing purposes or elsewhere, in order to carry out our contractual obligations versus the users.
<G-vec00241-002-s319><carry.erfüllen><de> Wir leiten die Daten an Dritte weiter, wenn dies für die Leistungserfüllung oder Abrechnungszwecke oder sonst notwendig ist, um unsere vertraglichen Pflichten den Nutzern gegenüber zu erfüllen.
<G-vec00241-002-s320><carry.erfüllen><en> The trainee asks one of the two people responsible for the viewing of the footage to give him access to view the video so that he could carry out the instructions he received.
<G-vec00241-002-s320><carry.erfüllen><de> Der Praktikant bittet einen der beiden Verantwortlichen im Überwachungsraum darum, ihm seinen Arbeitsplatz zu überlassen, damit er die Aufgabe erfüllen kann.
<G-vec00241-002-s321><carry.erfüllen><en> As our founder often stressed: if someone has tried to carry out his or her life’s task according to God’s will, they may continue to serve it in another way from eternity.
<G-vec00241-002-s321><carry.erfüllen><de> Wie unser Gründer es oft betont hat: wer hier auf Erden seine Lebensaufgabe nach Gottes Willen zu erfüllen bemüht war, darf sie vom Jenseits aus auf andere Weise weiterführen.
<G-vec00241-002-s322><carry.erfüllen><en> For all times it is helpful for the mission of the Church to make efforts to find new ways of evangelization to carry out its mission faithfully.
<G-vec00241-002-s322><carry.erfüllen><de> Zu jeder Zeit ist es nützlich für die Mission der Kirche, neue Wege der Evangelisierung zu suchen, um ihre Aufgabe treu zu erfüllen.
<G-vec00241-002-s342><carry.erledigen><en> You can carry out this task in a few days, no problem.
<G-vec00241-002-s342><carry.erledigen><de> Du kannst die Hausaufgaben in wenigen Tagen erledigen, überhaupt kein Problem.
<G-vec00241-002-s343><carry.erledigen><en> A look at the current situation with regard to global hotel sourcing shows that more than half (59 per cent) of all companies surveyed still carry out hotel negotiations internally.
<G-vec00241-002-s343><carry.erledigen><de> Ein Blick auf den Istzustand des weltweiten Hotel-Sourcing zeigt, dass noch immer mehr als die Hälfte (59 Prozent) aller befragten Unternehmen ihre Hotelverhandlungen intern erledigen.
<G-vec00241-002-s344><carry.erledigen><en> Apart from foil handling, the PIRANHA is also able to carry out "normal" marking and engraving tasks.
<G-vec00241-002-s344><carry.erledigen><de> Neben dem Folienhandling ist der PIRANHA auch in der Lage "normale" Beschriftungs- und Gravurjobs zu erledigen.
<G-vec00241-002-s345><carry.erledigen><en> Goods are delivered, services are performed and a large number of employees carry out their everyday work.
<G-vec00241-002-s345><carry.erledigen><de> Es werden Waren geliefert, Dienstleistungen erbracht und zahlreiche Mitarbeiter erledigen ihre tägliche Arbeit.
<G-vec00241-002-s346><carry.erledigen><en> Therefore, let the brothers take on and carry out their activities after suitable communal discernment and with the blessing of obedience, so that the work is always done as a mandate from the fraternity. 4.
<G-vec00241-002-s346><carry.erledigen><de> Darum sollen die Brüder ihre Tätigkeiten nach einer angemessenen Beratung in der Gemeinschaft und mit dem Segen des Gehorsams übernehmen und erledigen, so dass im Hintergrund ihrer Arbeit immer der Auftrag der ganzen Bruderschaft aufscheint.
<G-vec00241-002-s347><carry.erledigen><en> You send it to other countries that will carry out the torture.
<G-vec00241-002-s347><carry.erledigen><de> Man schickt Leute in andere Länder, die die Folter erledigen.
<G-vec00241-002-s348><carry.erledigen><en> And you can even use your smartphone to carry out your banking transactions on the move.
<G-vec00241-002-s348><carry.erledigen><de> Und mit Ihrem Smartphone erledigen Sie Bankgeschäfte sogar von unterwegs.
<G-vec00241-002-s349><carry.erledigen><en> We plan and carry out relocations within Switzerland and abroad; we can supply installation teams, provide transport vehicles to move new furniture and take on packing tasks for regional relocations or transport overseas.
<G-vec00241-002-s349><carry.erledigen><de> Wir planen und erledigen Umzüge im In- und Ausland; stellen Montageequipen oder Transportfahrzeuge für Büro- und Wohnmöbel, übernehmen Verpackungsarbeiten für Regionalumzüge oder für den Überseetransport.
<G-vec00241-002-s350><carry.erledigen><en> Duplicate file finding and remove duplicate is better to carry out by the instrumentality of the special program for duplicate files removing.
<G-vec00241-002-s350><carry.erledigen><de> Die Doppelte Dateien finden ist am besten mit Hilfe eines speziellen Programms zur Duplikate löschen zu erledigen.
<G-vec00241-002-s351><carry.erledigen><en> The IMMOTECH Management Tool enables those responsible to use a mobile tool that is free of charge for the customer so that they can carry out their work while on the move.
<G-vec00241-002-s351><carry.erledigen><de> Das IMMOTECH Management Tool ermöglicht somit den Verantwortlichen ein mobiles und für den Kunden kostenloses Tool, um von unterwegs aus seine Arbeiten erledigen zu können.
<G-vec00241-002-s352><carry.erledigen><en> With the Kärcher HV 1/1 Bp Fs Battery vacuum cleaner, building cleaners are always ideally placed to carry out minor suction work.
<G-vec00241-002-s352><carry.erledigen><de> Mit dem Akku-Handstaubsauger HV 1/1 Bp Fs von Kärcher sind Gebäudereiniger jederzeit bestens aufgestellt, um kleinere Saugarbeiten zu erledigen.
<G-vec00241-002-s353><carry.erledigen><en> Now you will get the job done faster by eliminating the need to carry an external battery for your small peristaltic pumps and always fearing that you may run the battery out during long sampling events (or even worse off forgetting the battery at the office).
<G-vec00241-002-s353><carry.erledigen><de> Jetzt erledigen Sie die Arbeit schneller, indem Sie keine externe Batterie für Ihre kleinen Peristaltische Pumpe mehr benötigen und immer befürchten, dass die Batterie bei langen Probenahmeveranstaltungen leer wird (oder noch schlimmer, wenn Sie die Batterie im Büro vergessen).
<G-vec00241-002-s354><carry.erledigen><en> We carry out small repairs quickly and directly on site.
<G-vec00241-002-s354><carry.erledigen><de> Kleine Reparaturen erledigen wir schnell und direkt vor Ort.
<G-vec00241-002-s355><carry.erledigen><en> With the XPace Scripting module, macros can be programmed and rules formulated that carry out standardized processes, right up to completely automated shelf loading.
<G-vec00241-002-s355><carry.erledigen><de> Mit dem Modul XPace Scripting können Makros programmiert und Regeln formuliert werden, die standardisierte Abläufe erledigen, bis hin zu einer komplett automatisierten Regalbestückung.
<G-vec00241-002-s356><carry.erledigen><en> By placing an Order on the Website, the Customer expressly instructs NV Gallery to carry out, or arrange to carry out, any customs clearance operations required under the terms of the Order as well as all related customs procedures, including payment of taxes and duties and, where applicable, any applications for the refund of taxes and duties (e.g. for return items).
<G-vec00241-002-s356><carry.erledigen><de> Indem er eine Bestellung über die Webseite aufgibt, ermächtigt der Kunde NV GALLERY ausdrücklich, im Namen des Kunden und auf seine Rechnung eventuelle durch die Bestellung ausgelöste Verzollungen und diesbezügliche Formalitäten bei den Zollbehörden, einschließlich der Bezahlung von Zöllen und Abgaben, sowie gegebenenfalls Anträge auf Erstattung von Zöllen und Abgaben (insbesondere für Rücksendungen) zu erledigen oder erledigen zu lassen.
<G-vec00241-002-s357><carry.erledigen><en> Whilst we have expanded our infrastructure and services, we have not forgotten our clients' need to carry out smaller reform work at times.
<G-vec00241-002-s357><carry.erledigen><de> Auch wenn wir unsere Infrastruktur und unser Leistungsangebot umfassend ausgebaut haben, haben wir nicht vergessen, dass unsere Kunden mitunter auch kleine Umbau- oder Renovierungsarbeiten erledigen müssen.
<G-vec00241-002-s358><carry.erledigen><en> Four asphalt finishers carry out the work.
<G-vec00241-002-s358><carry.erledigen><de> Vier Asphaltfertiger erledigen die Arbeit.
<G-vec00241-002-s359><carry.erledigen><en> If you have some experience with compression programs, then you could carry out this small step at the beginning.
<G-vec00241-002-s359><carry.erledigen><de> Habt Ihr bereits etwas Erfahrung mit Komprimierungsprogrammen, so könnt Ihr das bereits im ersten Schritt erledigen.
<G-vec00241-002-s360><carry.erledigen><en> Use it to carry out quick spot measurements at ventilation grilles (air outlets).
<G-vec00241-002-s360><carry.erledigen><de> Mit ihm erledigen Sie schnelle Spotmessungen am Lüftungsgitter (Luftauslass).
<G-vec00241-002-s380><carry.führen><en> Besides crafting his own instruments he will continue to offer Heiner’s models and carry out repair work.
<G-vec00241-002-s380><carry.führen><de> Neben seinen eigenen Instrumenten baut er dort auch weiterhin Heiners Modelle und führt Reparaturen aus.
<G-vec00241-002-s381><carry.führen><en> Then carry him out, and stone him to death.
<G-vec00241-002-s381><carry.führen><de> Und führt ihn hinaus und steinigt ihn, dass er sterbe.
<G-vec00241-002-s382><carry.führen><en> A notified body chosen by the installer shall carry out the final inspection of the lift about to be placed on the market in order to check the conformity of the lift with the applicable essential health and safety requirements set out in Annex I.
<G-vec00241-002-s382><carry.führen><de> Die Endabnahme des vor dem Inverkehrbringen stehenden Aufzugs führt eine vom Montagebetrieb ausgewählte notifizierte Stelle durch, um die Konformität des Aufzugs mit den anwendbaren wesentlichen Gesundheitsschutz- und Sicherheitsanforderungen nach Anhang I zu überprüfen.
<G-vec00241-002-s383><carry.führen><en> A notified body chosen by the manufacturer shall carry out appropriate examinations and tests to check the conformity of the instruments with the applicable requirements of this Directive.
<G-vec00241-002-s383><carry.führen><de> Eine vom Hersteller gewählte notifizierte Stelle führt die entsprechenden Untersuchungen und Prüfungen durch, um die Konformität der Geräte mit den anwendbaren Anforderungen dieser Richtlinie zu überprüfen.
<G-vec00241-002-s384><carry.führen><en> 3. The European Commission shall carry out broad consultations with parties concerned in order to ensure that the Union’s actions are coherent and transparent.
<G-vec00241-002-s384><carry.führen><de> (3) Um die Kohärenz und die Transparenz des Handelns der Union zu gewährleisten, führt die Europäische Kommission umfangreiche Anhörungen der Betroffenen durch.
<G-vec00241-002-s385><carry.führen><en> For instance, they carry multiple sensitivity to external stimuli, hierarchical structures which can be selectively activated, enhanced robustness and thermal stability.
<G-vec00241-002-s385><carry.führen><de> Dies führt zu hierarchischen Strukturen, deren unterschiedliche Sensitivität zu externen Stimuli separat aktiviert werden können, bei zusätzlicher Erhöhung der mechanischen und thermischen Stabilität.
<G-vec00241-002-s386><carry.führen><en> If suppliers and partners fail to comply with the contents of this declaration, Wilkhahn shall examine the facts and carry out appropriate measures in accordance with its possibilities.
<G-vec00241-002-s386><carry.führen><de> Wenn Zulieferer und Partner die Inhalte dieser Erklärung nicht einhalten, prüft Wilkhahn den Sachverhalt und führt die seinen Möglichkeiten entsprechende Maßnahmen durch.
<G-vec00241-002-s387><carry.führen><en> No customs declaration form needs to filled out if foreign visitors carry less than USD 10.000 or equivalent in other currencies.
<G-vec00241-002-s387><carry.führen><de> Eine Zolldeklaration muss nicht ausgefüllt werden, wenn ein ausländischer Reisender weniger als 10.000 US-Dollar (oder ein Äquivalent in anderen Währungen) mit sich führt.
<G-vec00241-002-s388><carry.führen><en> Alongside on-site technicians in the hotels, the team is responsible for all operative engineering projects, i.e. they carry out renovations and conversions, take care of all security-relevant systems, deal with technical problems, deal with negotiation proceedings for maintenance contracts and energy contracts, and implement measures for potential savings (water, electricity, gas).
<G-vec00241-002-s388><carry.führen><de> Das Team verantwortet gemeinsam mit den Technikern in den Hotels alle operativen Engineering Projekte, führt Renovierungen und Umbauten durch, kümmert sich um die sicherheitsrelevanten Anlagen, beseitigt technische Probleme, handelt Wartungs- und Energieverträge aus und realisiert Einsparmöglichkeiten (Wasser, Strom, Gas).
<G-vec00241-002-s389><carry.führen><en> See also[edit] Lacey V. Murrow Memorial Bridge and Homer M. Hadley Memorial Bridge, which carry I-90 over Lake Washington to Seattle.
<G-vec00241-002-s389><carry.führen><de> Über die Lacey V. Murrow Memorial Bridge führt seitdem nur noch der Verkehr nach Osten, während der Verkehr nach Westen die Homer M. Hadley Memorial Bridge benutzt.
<G-vec00241-002-s390><carry.führen><en> They identify complex practical issues in a changing environment, carry out independent and practice-based research and report on the results.
<G-vec00241-002-s390><carry.führen><de> Der Logopäde erkennt komplexe Fragen aus der Praxis in einem sich wandelnden Umfeld, führt selbstständig einen praxisbezogenen Forschungszyklus durch und erstattet darüber Bericht.
<G-vec00241-002-s391><carry.führen><en> And Moses took the bones of Joseph with him: for he had straitly sworn the children of Israel, saying, God will surely visit you; and ye shall carry up my bones away hence with you.
<G-vec00241-002-s391><carry.führen><de> Denn er hatte einen Eid von den Kindern Israel genommen und gesprochen: Gott wird euch heimsuchen; so führt meine Gebeine mit euch von hinnen.
<G-vec00241-002-s392><carry.führen><en> If you wish, our team will gladly carry out the update for you and advise you on the use of the new functions such as background synchronization.
<G-vec00241-002-s392><carry.führen><de> Auf Wunsch führt unser Team auch gerne das Update für Sie durch und berät Sie außerdem zum Einsatz der neuen Funktionen wie zum Beispiel der Hintergrundsynchronisation.
<G-vec00241-002-s393><carry.führen><en> It makes sense to carry out a partial water change after- wards, using a hose or the sera gravel washer to remove the water from the aquar- ium along with the algae.
<G-vec00241-002-s393><carry.führen><de> Sinnvollerweise führt man anschlie- ßend einen Teilwasserwechsel durch und saugt mit einem Schlauch oder mit dem sera Bodengrundreiniger das Wasser samt Algen aus dem Aquarium ab.
<G-vec00241-002-s394><carry.führen><en> One of our experts in property valuation will carry out a completely free valuation of your property orienting you on the market of Ibiza and Formentera.
<G-vec00241-002-s394><carry.führen><de> Einer unserer Experten für Immobilienbewertung führt eine völlig kostenlose Bewertung Ihrer Immobilie durch, die Sie auf den Markt von Ibiza und Formentera ausrichtet.
<G-vec00241-002-s395><carry.führen><en> It will certainly carry out within the body similarly tablet computer system or not.
<G-vec00241-002-s395><carry.führen><de> Er führt im Körper ähnlich wie Tablet-Computer-System oder nicht.
<G-vec00241-002-s396><carry.führen><en> Graduate is prepared to carry out economic, business management, commercial and administrative activities.
<G-vec00241-002-s396><carry.führen><de> Der Absolvent führt ökonomische, betriebswirtschaftliche, geschäftliche und administrative Tätigkeiten durch.
<G-vec00241-002-s397><carry.führen><en> The lance also extends the attack range of any ranged heroes who carry it to battle.
<G-vec00241-002-s397><carry.führen><de> Die Lanze erhöht zudem die Reichweite jedes Fernkämpfers, der sie in die Schlacht führt.
<G-vec00241-002-s398><carry.führen><en> He shall contribute by his proposals to the development of that policy, which he shall carry out as mandated by the Council.
<G-vec00241-002-s398><carry.führen><de> Er trägt durch seine Vorschläge zur Festlegung dieser Politik bei und führt sie im Auftrag des Rates durch.
<G-vec00241-002-s513><carry.mitführen><en> Riders should carry a passport or personal identity card with them.
<G-vec00241-002-s513><carry.mitführen><de> Reiter sollten einen Reisepaß oder Personalausweis mitführen.
<G-vec00241-002-s514><carry.mitführen><en> We no longer require a notification or a medical verification statement if you wish to carry and use your CPAP/PAP device in the aircraft cabin.
<G-vec00241-002-s514><carry.mitführen><de> Wenn Sie Ihr CPAP/PAP-Gerät in der Flugzeugkabine mitführen und verwenden möchten, benötigen wir keine Benachrichtigung oder medizinische Bestätigung mehr.
<G-vec00241-002-s515><carry.mitführen><en> You need to carry this card with you in the vehicle whenever you take your car abroad.
<G-vec00241-002-s515><carry.mitführen><de> Sie sollten diese Karte immer bei sich im Fahrzeug mitführen, wenn Sie Fahrten ins Ausland unternehmen.
<G-vec00241-002-s516><carry.mitführen><en> Transfers to other points along the track can also be arranged for those attempting a shortened version, and some companies also provide a luggage transfer service to accommodation along the route, so hikers need only carry a day pack.
<G-vec00241-002-s516><carry.mitführen><de> Transfers zu anderen Orten auf dem Track können auch für alle, die eine kürzere Variante bevorzugen, organisiert werden, und einige Firmen bieten auch eine Beförderung des Gepäcks zu den Unterkünften unterwegs an, so dass Wanderer nur die Dinge, die sie für den Tag brauchen mitführen müssen.
<G-vec00241-002-s517><carry.mitführen><en> It is also recommended to carry basic safety equipment (avalanche transceiver, probe, shovel).
<G-vec00241-002-s517><carry.mitführen><de> Zudem wird das Mitführen einer Basis Sicherheitsausrüstung (LVS, Sonde, Schaufel) empfohlen.
<G-vec00241-002-s518><carry.mitführen><en> The spacecraft will carry a German-French rover that will land on either Phobos or Deimos and explore the surface in detail for several months.
<G-vec00241-002-s518><carry.mitführen><de> Die Raumsonde wird einen deutsch-französischen Rover mitführen, der entweder auf Phobos oder auf Deimos landen wird, um die Oberfläche für mehrere Monate im Detail zu erforschen.
<G-vec00241-002-s519><carry.mitführen><en> Anyone wishing to export foods of animal origin to the EU must carry a commercial document.
<G-vec00241-002-s519><carry.mitführen><de> Wer Lebensmittel tierischer Herkunft in die EU exportieren will, muss ein Handelsdokument mitführen.
<G-vec00241-002-s520><carry.mitführen><en> For security reasons, you are not allowed to carry your backpacks, baby strollers or other luggage inside the attraction.
<G-vec00241-002-s520><carry.mitführen><de> Aus Sicherheitsgründen ist das Mitführen von Rucksäcken, Kinderwagen oder anderen Gepäckstücken in der Attraktion nicht gestattet.
<G-vec00241-002-s521><carry.mitführen><en> Because you don’t need to carry an additional boom suspension system, this will only increase the axle load slightly.
<G-vec00241-002-s521><carry.mitführen><de> Weil Sie keine zusätzliche Abspannung mitführen müssen, erhöhen sich die Achslasten in diesem Fall nur leicht.
<G-vec00241-002-s522><carry.mitführen><en> Plus, this compact adapter is portable enough for carrying as a tablet or laptop accessory while reducing the number of cables you need to carry around with you in order to charge all of your mobile devices.
<G-vec00241-002-s522><carry.mitführen><de> Zudem ist dieser kompakte Adapter mobil genug zum Mitführen als Tablet- oder Laptopzubehör und reduziert zudem die Anzahl von Kabeln, die Sie mitführen müssen, um alle Mobilgeräte zu laden.
<G-vec00241-002-s523><carry.mitführen><en> We're able to carry an assistance dog free of charge in the cabin of all our flights.
<G-vec00241-002-s523><carry.mitführen><de> Wir können auf all unseren Flügen Begleithunde kostenlos in der Kabine mitführen.
<G-vec00241-002-s524><carry.mitführen><en> Firstly, a mobile application that drivers and warehouse employees can carry around with them and a desktop application to support administrative processes in the office.
<G-vec00241-002-s524><carry.mitführen><de> Eine mobile Anwendung, die ein Fahrer oder ein Mitarbeiter im Lager mitführen kann und eine Desktopanwendung zur Unterstützung der administrativen Prozesse im Büro.
<G-vec00241-002-s525><carry.mitführen><en> In Austria, you must carry a first aid kit, a breakdown triangle and reflective vest with you.
<G-vec00241-002-s525><carry.mitführen><de> Grundsätzlich sind in Österreich das Mitführen von Verbandspaket, Warndreieck und Warnweste vorgeschrieben.
<G-vec00241-002-s526><carry.mitführen><en> Protects the product so that you can carry a single product around without it getting dirty
<G-vec00241-002-s526><carry.mitführen><de> Schützt das Produkt, so dass Sie ein einzelnes Produkt mitführen können, ohne dass es schmutzig wird.
<G-vec00241-002-s527><carry.mitführen><en> If you do not carry your own bicycles along, you can rent bikes and e-bikes in different versions at our camping site.
<G-vec00241-002-s527><carry.mitführen><de> Sollten Sie keine eigenen Fahrräder mitführen, können Sie am Platz Fahrräder in unterschiedlichen Ausführungen und E-Bikes entleihen und müssen so nicht auf Ihren Fahrradurlaub verzichten.
<G-vec00241-002-s528><carry.mitführen><en> A dust cap and the locking mechanism of the pump mechanism let you carry the pump unobtrusively and protected.
<G-vec00241-002-s528><carry.mitführen><de> Eine Staubkappe und die Verriegelung des Pumpmechanismus lassen Dich die Pumpe unauffällig und geschützt mitführen.
<G-vec00241-002-s529><carry.mitführen><en> Each passenger can carry one suitcase and one piece of hand luggage free of charge.
<G-vec00241-002-s529><carry.mitführen><de> Jeder Fahrgast kann kostenfrei einen Koffer sowie ein Handgepäckstück mitführen.
<G-vec00241-002-s530><carry.mitführen><en> Solaris has not yet provided any technical data on the new H2 bus, but have said that the fuel cell vehicle will carry hydrogen tanks on its roof and will also be equipped with its own “High Power Battery” as additional energy storage for 29.2 kWh.
<G-vec00241-002-s530><carry.mitführen><de> Technische Daten zum neuen H2-Bus nennt Solaris noch nicht, verkündet aber, dass das Fahrzeug Wasserstofffanks auf dem Dach mitführen und zudem mit einer unternehmenseigenen „High Power-Batterie“ ausgerüstet sein wird, die als zusätzlicher Energiespeicher dient.
<G-vec00241-002-s531><carry.mitführen><en> Make sure to carry enough water and/or water filter.
<G-vec00241-002-s531><carry.mitführen><de> Stellen Sie sicher, dass Sie ausreichend Wasser und / oder Wasserfilter mitführen.
<G-vec00241-002-s551><carry.mitnehmen><en> Packable design makes it easy to store and carry with you.
<G-vec00241-002-s551><carry.mitnehmen><de> Durch das kompakte Design ist die Jacke einfach zu lagern und mitzunehmen.
<G-vec00241-002-s552><carry.mitnehmen><en> To easily carry along the souvenir, JIAN’s jewelry ring is a great choice.
<G-vec00241-002-s552><carry.mitnehmen><de> Der JIAN Schmuckring ist eine gute Wahl, um das Mitbringsel mitzunehmen.
<G-vec00241-002-s553><carry.mitnehmen><en> The 10 zippered pockets, which are all accessible when the bag is on a cart, let you carry all of your extra gear and valuables while also organised.
<G-vec00241-002-s553><carry.mitnehmen><de> Die 10 Reißverschlusstaschen, die alle erreichbar sind, wenn sich die Tasche auf einem Golfwagen befindet, ermöglichen Ihnen, Ihre gesamte Zusatzausrüstung und Ihre Wertsachen mitzunehmen und zu organisieren.
<G-vec00241-002-s554><carry.mitnehmen><en> The US$ is the most commonly accepted foreign currency in Venezuela, so it is recommended to carry cash and traveller's cheques in US$.
<G-vec00241-002-s554><carry.mitnehmen><de> Es empfiehlt sich daher, eine ausreichende Menge Bargeld und Reiseschecks in US$ mitzunehmen.
<G-vec00241-002-s555><carry.mitnehmen><en> A bottle cage mount gives you an easy option to carry something to drink on your ride.
<G-vec00241-002-s555><carry.mitnehmen><de> Die Möglichkeit einen Flaschenhalter anzubringen gibt dir eine einfache Option Getränke auf Trainingsessions mitzunehmen.
<G-vec00241-002-s556><carry.mitnehmen><en> During the summer season there is the option on some routes to carry bicycles on the buses.
<G-vec00241-002-s556><carry.mitnehmen><de> Während der Saison besteht auf einigen Strecken die Möglichkeit, Fahrräder in den Bussen mitzunehmen.
<G-vec00241-002-s557><carry.mitnehmen><en> Hikers will need to carry enough water and food for the day, and remember to wear appropriate clothing for the time of year.
<G-vec00241-002-s557><carry.mitnehmen><de> Denke daran, ausreichend Wasser und Lebensmittel für einen Tag mitzunehmen, sowie passende Kleidung für die Jahreszeit.
<G-vec00241-002-s558><carry.mitnehmen><en> Folding design and dragging wheel design, convenient to store and portable to carry everywhere and use it anytime.
<G-vec00241-002-s558><carry.mitnehmen><de> Schnell faltbarer, leichter Aluminiumlegierungskörper mit Befestigungshaken, bequem zu verstauen und tragbar, um ihn überall hin mitzunehmen und jederzeit zu benutzen.
<G-vec00241-002-s559><carry.mitnehmen><en> In short, this leather shoulder bag from Chesterfield is the ideal bag to carry all your items with you every day.
<G-vec00241-002-s559><carry.mitnehmen><de> Kurz gesagt, diese Lederumhängetasche von Chesterfield ist die ideale Tasche, um alle Ihre Sachen täglich mitzunehmen.
<G-vec00241-002-s560><carry.mitnehmen><en> Be sure to carry cash in the form of Euros with you and ensure your driver turns on and resets the meter before you begin your journey. Convenience
<G-vec00241-002-s560><carry.mitnehmen><de> Es ist ratsam, bei der Fahrt mit dem Taxi immer Bargeld in Euro mitzunehmen und sicherzustellen, dass der Zähler vor Reiseantritt zurückgesetzt und eingeschaltet wird.
<G-vec00241-002-s561><carry.mitnehmen><en> On the way to our „High Alm“ is no restaurant, therefor we recommend to carry water and something to eat with you, because the way takes about one to two hours.
<G-vec00241-002-s561><carry.mitnehmen><de> Auf dem Weg zur Hochalm befindet sich allerdings keine Gaststätte, deshalb empfehlen wir, Wasser und eine Jause für den Weg mitzunehmen, da die Wanderung ein bis zwei Stunden andauert.
<G-vec00241-002-s562><carry.mitnehmen><en> Consequently, it seems wise to carry at least a machete to provide some protection.
<G-vec00241-002-s562><carry.mitnehmen><de> Trotzdem scheint es sinnvoll eine Machete mitzunehmen um wenigstens etwas Schutz zu haben.
<G-vec00241-002-s563><carry.mitnehmen><en> The fact that today’s established forms of science communication fail to reach some two thirds of the population is critical for Switzerland’s future in two respects: for one thing, it is the central task of any knowledge-based society to carry into the future as many people as possible at all educational levels of the value chain.
<G-vec00241-002-s563><carry.mitnehmen><de> Für die Zukunft der Schweiz ist die Tatsache, dass rund zwei Drittel der Bevölkerung mit den etablierten Formen der gängigen Wissenschaftskommunikation nicht erreicht werden, in zweierlei Hinsicht kritisch: Zum einen ist es die zentrale Aufgabe einer Wissensgesellschaft, möglichst viele Menschen ausbildungsmässig auf allen Stufen der Wertschöpfungskette in die Zukunft mitzunehmen.
<G-vec00241-002-s564><carry.mitnehmen><en> The unrivaled stopping power of disc brakes provides the confidence to carry speed in fast corners or tight quarters.
<G-vec00241-002-s564><carry.mitnehmen><de> Die unerreichte Bremspower der Scheibenbremsen gibt dir Sicherheit, die Geschwindigkeit in schnellen Kurven oder engen Passagen mitzunehmen.
<G-vec00241-002-s565><carry.mitnehmen><en> Ideal for guests travelling through Friesland on foot, on bicycle or by sloop and without the room to carry a tent.
<G-vec00241-002-s565><carry.mitnehmen><de> Ideal für Gäste, die zu Fuß, mit dem Fahrrad oder mit Boot durch Holland ziehen und keinen Platz haben um ein eigenes Zelt mitzunehmen.
<G-vec00241-002-s566><carry.mitnehmen><en> Whatever your plans, give yourself the freedom to carry whatever you need with you.
<G-vec00241-002-s566><carry.mitnehmen><de> Was immer Sie vorhaben, nehmen Sie sich die Freiheit, das mitzunehmen, was Sie brauchen.
<G-vec00241-002-s567><carry.mitnehmen><en> Your other hand is free to open the door for example, or carry something else, or serve your drinks. Serve easy
<G-vec00241-002-s567><carry.mitnehmen><de> Ihre andere Hand ist frei um beispielsweise die Türe zu öffnen, etwas anderes mitzunehmen oder um die Getränke zu servieren.
<G-vec00241-002-s568><carry.mitnehmen><en> 3000 Puzzle & Roll is the easy way to store or carry unfinished puzzles and loose jigsaw pieces.
<G-vec00241-002-s568><carry.mitnehmen><de> „Puzzle & Roll“ bietet eine komfortable Möglichkeit, unfertige Puzzles oder einzelne Puzzleteile aufzubewahren oder mitzunehmen.
<G-vec00241-002-s569><carry.mitnehmen><en> It is convenient to carry anywhere with a compact size.
<G-vec00241-002-s569><carry.mitnehmen><de> Es ist praktisch, mit einer kompakten Größe überall hin mitzunehmen.
<G-vec00241-002-s570><carry.nehmen><en> We carry out an Environmental Product Declaration (EPD) to assess the impact of wind projects.
<G-vec00241-002-s570><carry.nehmen><de> Wir nehmen eine Umweltproduktdeklaration (EPD) vor, um die Auswirkungen von Windprojekten zu beurteilen.
<G-vec00241-002-s571><carry.nehmen><en> Each passenger can carry 1 piece of Hand Luggage of 10 kilos (max. measurements of 55 x 35 x 25 centimetres).
<G-vec00241-002-s571><carry.nehmen><de> Jeder Passagier darf 1x Handgepäckstück von 10Kg mit an Bord nehmen (maximale Maße 55 x 35 x 25).
<G-vec00241-002-s572><carry.nehmen><en> The Dual Panel Charger is very lightweight (only 120gr) and easy to carry.
<G-vec00241-002-s572><carry.nehmen><de> Das Dual-Panel Solar Charger ist vom Gewicht her sehr leicht (120gr) und einfach mit zu nehmen, wohin Sie auch gehen.
<G-vec00241-002-s573><carry.nehmen><en> And when you are among them and lead them in prayer, let a group of them stand [in prayer] with you and let them carry their arms.
<G-vec00241-002-s573><carry.nehmen><de> Und wenn du unter ihnen bist und nun für sie das Gebet anfuhrst, dann soll sich ein Teil von ihnen mit dir aufstellen, doch sollen sie ihre Waffen nehmen.
<G-vec00241-002-s574><carry.nehmen><en> Also carry enough tape with you.
<G-vec00241-002-s574><carry.nehmen><de> Nehmen Sie auch genügend Videobänder mit.
<G-vec00241-002-s575><carry.nehmen><en> Specialists from the respective branches of industry carry out risk assessments and situational analyses and use these to plan the control measures to be taken and assist in their implementation if necessary.
<G-vec00241-002-s575><carry.nehmen><de> Fachleute aus den betroffenen Branchen nehmen Risikobeurteilungen und Lageanalysen vor, planen darauf basierend die Bewirtschaftungsmassnahmen und wirken im Ernstfall bei deren Umsetzung mit.
<G-vec00241-002-s576><carry.nehmen><en> One bedroom has a cot aanwezig.Ook a high chair in the house aanwezig.U need your own bedding and linen to carry.
<G-vec00241-002-s576><carry.nehmen><de> Ein Schlafzimmer verfügt über ein Kinderbett aanwezig.Ook einen Hochstuhl im Haus aanwezig.U brauchen Ihre eigene Bettwäsche und Handtücher zu nehmen.
<G-vec00241-002-s577><carry.nehmen><en> If you would like to assign the translation of the updated document to another translator, switch to the Tasks module and carry out the new assignment.
<G-vec00241-002-s577><carry.nehmen><de> Möchten Sie die Bearbeitung des aktualisierten Dokuments einem anderen Übersetzer zuweisen, wechseln Sie bitte in das Aufgaben-Modul und nehmen Sie dort die neue Zuweisung vor.
<G-vec00241-002-s578><carry.nehmen><en> Member States shall carry out the administrative and control tasks required pursuant to the provisions of the special measures to enhance maritime security of the SOLAS Convention and of the ISPS Code.
<G-vec00241-002-s578><carry.nehmen><de> (1) Die Mitgliedstaaten nehmen die Verwaltungs- und Kontrollaufgaben wahr, die sich aus den Bestimmungen der besonderen Maßnahmen des SOLAS-Übereinkommens zur Erhöhung der Gefahrenabwehr in der Schifffahrt und des ISPS-Code ergeben.
<G-vec00241-002-s579><carry.nehmen><en> We carry out redesigns in close agreement with our customers to whom we submit proposals for solutions at an early stage.
<G-vec00241-002-s579><carry.nehmen><de> Redesigns nehmen wir in enger Absprache mit unseren Kunden vor, frühzeitig unterbreiten wir angemessene Lösungsvorschläge.
<G-vec00241-002-s580><carry.nehmen><en> We have all the necessary knowledge, experience and technological support of ServiceNow, to provide top quality services – we carry out comprehensive implementations and extensions and deliver maintenance services of the ServiceNow platform.
<G-vec00241-002-s580><carry.nehmen><de> Wir haben das nötige Wissen, die Erfahrung sowie die technologische Unterstützung von ServiceNow, um Dienstleistungen von erstklassiger Qualität zu erbringen – wir nehmen umfassende Implementierungen und Erweiterungen vor und leisten Instandhaltungsdienste für die ServiceNow-Plattform.
<G-vec00241-002-s581><carry.nehmen><en> For security reasons, the passenger is requested to obtain a letter from physician that he/she has a medical need to carry the syringe into the cabin.
<G-vec00241-002-s581><carry.nehmen><de> Aus Sicherheitsgründen muss der Fluggast ein Schreiben seines Arztes mitführen, dass er aus medizinischen Gründen eine Spritze mit in die Kabine nehmen muss.
<G-vec00241-002-s582><carry.nehmen><en> Together with global partners, the experts carry out detailed technical evaluations in advance and check whether the cans or glass bottles can be filled without difficulty on customer machines.
<G-vec00241-002-s582><carry.nehmen><de> Dabei nehmen die Experten gemeinsam mit globalen Partnern im Vorfeld detaillierte technische Bewertungen vor und prüfen, ob sich Dosen oder Glasflaschen ohne Probleme auf den vorhandenen Maschinen des Kunden abfüllen lassen.
<G-vec00241-002-s583><carry.nehmen><en> 1 The Federal Office and the other statistics generators carry out special data analyses for the administrative units of the Confederation and, where they have the capacity, for third parties.
<G-vec00241-002-s583><carry.nehmen><de> 1 Das Bundesamt und die übrigen Statistikproduzenten nehmen besondere Auswertungen für die Verwaltungseinheiten des Bundes und, im Rahmen ihrer Möglichkeiten, für Dritte vor.
<G-vec00241-002-s584><carry.nehmen><en> We would like to offer you several payment methods and will carry out analyses to find out what payment options are available to you, including your payment history and credit checks.
<G-vec00241-002-s584><carry.nehmen><de> Wir möchten Ihnen mehrere Zahlungsarten anbieten und nehmen Analysen vor, um herauszufinden, welche Zahlungsmöglichkeiten Ihnen zur Verfügung stehen, einschließlich Ihrer Zahlungshistorie und Bonitätsprüfungen.
<G-vec00241-002-s585><carry.nehmen><en> Licence holders shall also demonstrate compliance with conditions. (2) If the person required to provide information manufactures or deals in weapons or operates a shooting range or security firm, the persons assigned by the competent authorities to monitor the business shall have the right to enter the business property and premises during business and working hours in order to carry out checks and inspections, take samples and examine business records.
<G-vec00241-002-s585><carry.nehmen><de> (2) Betreibt der Auskunftspflichtige Waffenherstellung, Waffenhandel, eine Schießstätte oder ein Bewachungsunternehmen, so sind die von der zuständigen Behörde mit der Überwachung des Betriebs beauftragten Personen berechtigt, Betriebsgrundstücke und Geschäftsräume während der Betriebs- und Arbeitszeit zu betreten, um dort Prüfungen und Besichtigungen vorzunehmen, Proben zu entnehmen und Einsicht in die geschäftlichen Unterlagen zu nehmen; zur Abwehr dringender Gefahren für die öffentliche Sicherheit oder Ordnung dürfen diese Arbeitsstätten auch außerhalb dieser Zeit sowie die Wohnräume des Auskunftspflichtigen gegen dessen Willen besichtigt werden.
<G-vec00241-002-s586><carry.nehmen><en> The project is in its early days, so you'll need to come back in a few years' time to test it out...In the meantime, you'll have to carry on using your car...A good opportunity to stop off at one of the Ottrott wine cellars to sample the "Rouge d'Ottrott", typical local vineyard wine that you won't find anywhere else.
<G-vec00241-002-s586><carry.nehmen><de> Dieses Projekt steckt noch in den Kinderschuhen, Sie sollten in ein paar Jahren wiederkommen, um in dessen Genuss zu kommen... Bis dahin müssen Sie weiterhin das Auto nehmen... Nutzen Sie die Gelegenheit zu einem Halt in einem der Keller von Ottrott und verkosten Sie den „Rouge d'Ottrott", einen typischen Wein dieser Gegend, den Sie nirgendwo sonst finden werden.
<G-vec00241-002-s587><carry.nehmen><en> [So that] they go about naked without clothing, And being hungry they carry the sheaves.
<G-vec00241-002-s587><carry.nehmen><de> Den Nackten lassen sie ohne Kleider gehen, und den Hungrigen nehmen sie die Garben.
<G-vec00241-002-s588><carry.nehmen><en> Relating to solid units Amazone rely primarily on BPW axles, in order to ensure reliable service to its customers and because the stresses on the vehicles are enormous: They have to be able to withstand dynamic loads on paths and in the fields and carry many times their own weight in terms of load.
<G-vec00241-002-s588><carry.nehmen><de> Amazone vertraut bei gezogenen Einheiten primär auf BPW-Achsen, um zuverlässigen Service für seine Kunden sicherzustellen und weil die Belastungen der Fahrzeuge enorm sind: Sie müssen auf Feldwegen und im Acker dynamische La- sten tragen und nehmen oft auch ein Viel- faches ihres Eigengewichts an Zuladung auf.
<G-vec00241-002-s589><carry.realisieren><en> Another successful project which we have been able to carry out with our partner Kardex in the Czech Republic.
<G-vec00241-002-s589><carry.realisieren><de> Ein weiteres gelungenes Projekt welches wir mit unserem Partner Kardex in Tschechien realisieren konnten.
<G-vec00241-002-s590><carry.realisieren><en> For reading and writing of transponders, RFID read/write devices (read/write interfaces or just readers) are used, which carry out the communication between RFID transponders and HOST computers.
<G-vec00241-002-s590><carry.realisieren><de> Zum Lesen und Beschreiben von Transpondern werden RFID Schreib-Lese-Geräte (Read/Write Interfaces oder einfach Reader) verwendet, welche die Kommunikation zwischen RFID-Transpondern und HOST Computern realisieren.
<G-vec00241-002-s591><carry.realisieren><en> Barth Fruit is there to plan, co-ordinate and carry out our activities close to the supplier's market for the satisfaction of our customers.
<G-vec00241-002-s591><carry.realisieren><de> Barth Fruit ist dort, um zur Zufriedenheit unserer Kunden marktnah unsere Aktivitäten zu planen, zu koordinieren und zu realisieren.
<G-vec00241-002-s592><carry.realisieren><en> Place ads on Google Search, Facebook, Instagram or YouTube, and carry out retargeting directly from the Marketing Cloud, without having to use a specialist agency.
<G-vec00241-002-s592><carry.realisieren><de> Schalten Sie Anzeigen auf Google Search, Facebook, Instagram sowie Youtube und realisieren Sie auch das Retargeting direkt aus der Marketing Cloud heraus, ohne eine spezialisierte Agentur.
<G-vec00241-002-s593><carry.realisieren><en> We carry out complete processes of recycling, from audits through development of procedures and documentation up to the collection of waste and its recovery.
<G-vec00241-002-s593><carry.realisieren><de> Wir realisieren komplette Recyclingprozesse, angefangen von den Audits über die Ausarbeitung von Prozeduren und Unterlagen bis hin zur Einsammlung und Wiederverwertung von Abfällen.
<G-vec00241-002-s594><carry.realisieren><en> Find out which clients we have been able to carry out exciting projects for.
<G-vec00241-002-s594><carry.realisieren><de> Service Finden Sie heraus, für welche Kunden wir spannende Projekte realisieren durften.
<G-vec00241-002-s595><carry.realisieren><en> Thanks to our commitment many companies were able to develop, and individual persons were able to carry their plans out.
<G-vec00241-002-s595><carry.realisieren><de> Durch unser Engagement konnten sich mehrere Firmen entwickeln und die Privatpersonen konnten ihre Pläne realisieren.
<G-vec00241-002-s596><carry.realisieren><en> This is where the production flexibility of Lamineries MATTHEY plays a decisive role, because we are able to carry out what others cannot.
<G-vec00241-002-s596><carry.realisieren><de> Hier spielt die Produktionsflexibilität der Lamineries MATTHEY eine entscheidende Rolle, denn wir sind in der Lage, das zu realisieren, was andere nicht können.
<G-vec00241-002-s597><carry.realisieren><en> We provide solutions from one single source and, depending on the customer’s requirements, carry out all stages of the rough machining and finishing work.
<G-vec00241-002-s597><carry.realisieren><de> Wir bieten Lösungen aus einer Hand und realisieren, je nach Anforderung des Kunden, sämtliche Schritte der mechanischen Vor- und Fertigbearbeitung.
<G-vec00241-002-s598><carry.realisieren><en> And all this together has allowed us to carry out wonderful works, save ourselves a lot of time, a lot of money and a lot of trouble.
<G-vec00241-002-s598><carry.realisieren><de> All das zusammen genommen hat dazu geführt, dass wir großartige Arbeiten realisieren und sehr viel Geld und Ärger sparen konnten.
<G-vec00241-002-s599><carry.realisieren><en> The late founder of the Legion of Good Will replied, “Paiva, only a great friend could carry out a work of this magnitude.
<G-vec00241-002-s599><carry.realisieren><de> Der viel vermisste Gründer der Legion des Guten Willens antwortete ihm: „Paiva, nur ein großer Freund wäre in der Lage ein Werk diesen Umfangs zu realisieren.
<G-vec00241-002-s600><carry.realisieren><en> We carry out a viability study based on real production data of your factory, and in 3 weeks we calculate the cost of changing from a horizontal system to vertical storage.
<G-vec00241-002-s600><carry.realisieren><de> Wir realisieren eine Durchführbarkeitsstudie basierend auf realen Daten der Produktion und Ihrer Fabrik, und in 3 Wochen berechnen wir die Kosten für die Änderung des Flachlagers in ein Hochregallager.
<G-vec00241-002-s601><carry.realisieren><en> This investment means that, at just ONE site, we can now carry out all the stages of synthesis necessary to manufacture the complex product for a Syngenta fungicide.
<G-vec00241-002-s601><carry.realisieren><de> Denn mit Hilfe dieser Investition können wir jetzt an EINEM Standort alle Synthesestufen realisieren, die notwendig sind, um das komplexe Produkt für ein Syngenta-Fungizid herzustellen.
<G-vec00241-002-s602><carry.realisieren><en> We can say that we carry out the “Technical Mission Impossible” – difficult projects are our speciality.
<G-vec00241-002-s602><carry.realisieren><de> Über uns selbst sagen wir, dass wir auch eine „Technical Mission Impossible” realisieren können – herausfordernde Projekte sind nämlich unsere Spezialität.
<G-vec00241-002-s603><carry.realisieren><en> With COMOS software, Siemens is the only supplier worldwide to carry out integrated plant asset management projects over the entire lifecycle of an industrial plant.
<G-vec00241-002-s603><carry.realisieren><de> Als einziger Anbieter weltweit realisieren wir mit unserer COMOS Software ganzheitliche Anlagenmanagement-Projekte über den gesamten Lebenszyklus einer Industrieanlage oder Maschine.
<G-vec00241-002-s604><carry.realisieren><en> Being part of the MCI Group, our global network, along with our many years of experience in international project logistics, enables us to carry out short-term studies in a multitude of countries and in almost every language.
<G-vec00241-002-s604><carry.realisieren><de> Die Zugehörigkeit zur MCI Group, unser weltweites Netzwerk sowie unsere langjährige Erfahrung in internationaler Projektlogistik ermöglichen es uns, selbst kurzfristig Studien in einer Vielzahl von Ländern und in nahezu jeder Sprache zu realisieren.
<G-vec00241-002-s605><carry.realisieren><en> In my day-to-day work it is also important for me to carry out new projects again and again.
<G-vec00241-002-s605><carry.realisieren><de> In meiner täglichen Arbeit ist es für mich auch wichtig, immer wieder eigene Projekte zu realisieren.
<G-vec00241-002-s606><carry.realisieren><en> I hope you enjoy reading this edition and, on behalf of all the staff at Kaba AG, I would like to thank all our customers and partners for allowing us to carry out projects successfully, both in the past and in future.
<G-vec00241-002-s606><carry.realisieren><de> Ich wünsche Ihnen viel Spass beim Lesen dieser Ausgabe und bedanke mich stellvertretend für alle Mitarbeiter der Kaba AG bei allen unseren Kunden und Partnern dafür, erfolgreich Projekte realisiert zu haben und weitere realisieren zu dürfen.
<G-vec00241-002-s607><carry.realisieren><en> We plan and carry out demanding and innovative shop and store projects all over the world for our national and international clients.
<G-vec00241-002-s607><carry.realisieren><de> Für unsere nationalen und internationalen Kunden planen und realisieren wir weltweit anspruchsvolle und innovative Shop- und Storeprojekte.
<G-vec00241-002-s608><carry.schleppen><en> Despite my frail health, they ordered inmates to carry me by the arms and drag me to the courtyard.
<G-vec00241-002-s608><carry.schleppen><de> Trotz meiner angeschlagenen Gesundheit befahlen sie Insassen, mich an den Armen zum Hof zu schleppen.
<G-vec00241-002-s609><carry.schleppen><en> I'm just glad that I was already pregnant when we moved last month, and our helpers had to carry box after box down the stairs that were labeled "Diapers", "Baby Books", "Boy Clothes", "Gender-neutral Items" and "Toys".
<G-vec00241-002-s609><carry.schleppen><de> Ich bin froh, dass ich bereits schwanger war, als wir letzten Monat umgezogen sind, denn unsere Helfer mussten Kiste für Kiste nach unten schleppen, auf denen "Windeln", "Babybücher", "Jungensachen"und "Spielzeug" stand.
<G-vec00241-002-s610><carry.schleppen><en> Solo travellers have a "palace" with this model without having to carry unnecessarily much. Optionally available
<G-vec00241-002-s610><carry.schleppen><de> Solo-Reisende haben mit diesem Modell einen "Palast", ohne unnötig viel schleppen zu müssen.
<G-vec00241-002-s611><carry.schleppen><en> I will never forget his answer: „We are ready!“ He didn’t just offer his own help immediately, no, he even calls several friends to come and help on the very same day to carry boxes and furniture on a hot summer day.
<G-vec00241-002-s611><carry.schleppen><de> Seine Antwort werde ich nie vergessen: „Wir sind bereit!“ Er bietet nicht nur ohne Umschweife selbst seine Hilfe an, nein, er organisiert auch noch etliche Bekannte, die nun an dem besagten Tag erscheinen und bei brütender Hitze Kisten und Möbel schleppen.
<G-vec00241-002-s612><carry.schleppen><en> Or you put colour on your wall strip by strip - evenly, quickly and without having to carry buckets of paint or mix colours first.
<G-vec00241-002-s612><carry.schleppen><de> Oder Sie bringen Bahn für Bahn frische Farbe auf die Wand – gleichmäßig, rasch und ohne vorher Farbeimer schleppen oder Farben anmischen zu müssen.
<G-vec00241-002-s613><carry.schleppen><en> The beach is easily accessible by car so you don't have to carry your gear too far.
<G-vec00241-002-s613><carry.schleppen><de> Da der Strand leicht mit dem Wagen zu erreichen ist, brauchen Sie Ihre Ausrüstung auch nicht zu weit schleppen.
<G-vec00241-002-s614><carry.schleppen><en> On the other hand, he didn’t have to carry as much as I did.
<G-vec00241-002-s614><carry.schleppen><de> Immerhin musste er nicht so viel schleppen wie ich.
<G-vec00241-002-s615><carry.schleppen><en> „If I only had less stuff to carry...“ - that was yesterday.
<G-vec00241-002-s615><carry.schleppen><de> „Hätt‘ ich bloß nicht so viel zu schleppen...“ war gestern.
<G-vec00241-002-s616><carry.schleppen><en> It’s cold and wet as they cut the huge reeds, gather them in massive bunches and carry them across ice channels.
<G-vec00241-002-s616><carry.schleppen><de> Bei Kälte und Feuchtigkeit schneiden sie das riesige Schilf, packen es zu mächtigen Bündeln und schleppen es über Eisrinnen.
<G-vec00241-002-s617><carry.schleppen><en> had to carry a heavy load according to testimonies, since he had a complete train in his luggage.
<G-vec00241-002-s617><carry.schleppen><de> Der Weihnachtsmann hatte laut Zeugenaussagen ordentlich zu schleppen, hatte er doch einen ganzen Zug im Gepaeck.
<G-vec00241-002-s618><carry.schleppen><en> “Water is such a precious resource that women walked many miles to the Niger River to collect it and carry it back to the village.
<G-vec00241-002-s618><carry.schleppen><de> "Die Frauen mussten das kostbare Nass kilometerweit vom Fluss Niger ins Dorf schleppen.
<G-vec00241-002-s619><carry.schleppen><en> Two of them offered to carry my things up to the dance hall.
<G-vec00241-002-s619><carry.schleppen><de> Zweie boten sich an, meine Sachen nach oben zu schleppen.
<G-vec00241-002-s620><carry.schleppen><en> I wish I had to carry less and regret the decision to travel with hand luggage.
<G-vec00241-002-s620><carry.schleppen><de> Ich wünschte, ich hätte nicht so viel zum Schleppen und bedaure die Entscheidung, mit Handgepäck zu reisen.
<G-vec00241-002-s621><carry.schleppen><en> To avoid escapes on the way, the traders cuffed the right arm of slaves with an iron cramp to a heavy log of wood which the helpless slaves had to carry.
<G-vec00241-002-s621><carry.schleppen><de> Um zu verhindern, dass unterwegs jemand verloren ging, befestigten die Händler den rechten Arm des Sklaven mit einer eisernen Krampe an einen schweren Holzklotz, den der Sklave schleppen musste.
<G-vec00241-002-s622><carry.schleppen><en> If you like your mineral water or soft drink with a bit of carbonic acid, there are many reasons for soda ash: on the one hand you do not need to carry heavy packs with bottles or aluminum cans anymore and place them in your storage room.
<G-vec00241-002-s622><carry.schleppen><de> Wenn Sie Ihr Mineralwasser oder Erfrischungsgetränk mit etwas Kohlensäure mögen, sprechen zahlreiche Gründe für SodaStream: Einerseits brauchen Sie keine schweren Packungen mit Flaschen oder Aludosen mehr zu schleppen und in Ihrem Vorratsraum unterzubringen.
<G-vec00241-002-s623><carry.schleppen><en> After all I feel very comfortable with the bass and I do have to carry less.
<G-vec00241-002-s623><carry.schleppen><de> Unterm Strich fühle ich mich am Bass auch am wohlsten und muss weniger schleppen.
<G-vec00241-002-s624><carry.schleppen><en> It is considered that the name of this fishermen‘s village originated from the process of boats‘ carry.
<G-vec00241-002-s624><carry.schleppen><de> Es wird angenommen, dass der Name dieses Dörfchens von der Handlung, d.h. dem Schleppen von Booten stammt.
<G-vec00241-002-s625><carry.schleppen><en> Some like the people from Lorrain had only very little luggage, other again brought as much as they could carry.
<G-vec00241-002-s625><carry.schleppen><de> Einige wie die Lothringer hatten nur sehr wenig Gepäck, andere wiederum brachten mit soviel sie nur schleppen konnten.
<G-vec00241-002-s626><carry.schleppen><en> So a towel is no longer necessary, so no more fabric folds and no more slipping and you don't have to carry unnecessary weight.
<G-vec00241-002-s626><carry.schleppen><de> So ist ein Handtuch nicht mehr notwendig, also keine Stofffalten und kein Verrutschen mehr und du musst nicht unnötiges Gewicht mit dir rum schleppen.
<G-vec00241-002-s741><carry.tragen><en> You carry me home
<G-vec00241-002-s741><carry.tragen><de> Trägst du mich, zu jedem Ort.
<G-vec00241-002-s742><carry.tragen><en> You carry responsibility for others right from the start of your studies.
<G-vec00241-002-s742><carry.tragen><de> Du trägst Verantwortung für andere – und das bereits ab Beginn Deines Studiums.
<G-vec00241-002-s743><carry.tragen><en> Once you found your Self, you carry a living love (to yourself and others) within you.
<G-vec00241-002-s743><carry.tragen><de> Hast du dich selbst gefunden, so trägst du die lebendige Liebe (zu dir und dem Anderen) in dir.
<G-vec00241-002-s744><carry.tragen><en> Under your flag, You carry me everywhere.
<G-vec00241-002-s744><carry.tragen><de> Unter deiner Flagge, Trägst Du mich, zu jedem Ort.
<G-vec00241-002-s745><carry.tragen><en> You carry these problems about with yourself.
<G-vec00241-002-s745><carry.tragen><de> Diese Probleme trägst du mit dir herum.
<G-vec00241-002-s746><carry.tragen><en> You carry it around with you.
<G-vec00241-002-s746><carry.tragen><de> Du trägst sie mit dir herum.
<G-vec00241-002-s747><carry.tragen><en> If not, you either are not one with her - or you just happen to carry her with you through your world.
<G-vec00241-002-s747><carry.tragen><de> Wenn nicht, dann bist Du entweder nicht eins mit ihr - oder Du trägst sie gerade mit Dir durch Deine Welt.
<G-vec00241-002-s748><carry.tragen><en> You carry the colors and the badges of where youíve been and what youíve done everywhere you go.
<G-vec00241-002-s748><carry.tragen><de> Du trägst die Farben und Abzeichen, von wo du warst und was du überall dort tust, wo du hingehst.
<G-vec00241-002-s749><carry.tragen><en> Keen to get out for the day and enjoy the countryside? You can get everything you need for a day’s hiking in the ORBIT 26 and carry it all in comfort.
<G-vec00241-002-s749><carry.tragen><de> Einfach mal für einen Tag raus und die Natur genießen: Im ORBIT 26 PACK trägst du auf deinen Touren alles, was du unterwegs brauchst, gut organisiert und ganz bequem auf dem Rücken.
<G-vec00241-002-s750><carry.tragen><en> Furthermore you carry the responsibility, and not City Contrast, that your contributions, articles, pictures, information, images etc. do not violate the rights of third parties since these are to everyone and globally accessible.
<G-vec00241-002-s750><carry.tragen><de> Ferner trägst Du die Verantwortung dafür und nicht City Contrast, das deine Beiträge, Bilder, Informationen und Videos keine Rechte Dritter verletzen, da diese für jedermann zugänglich und Weltweit zugreifbar sind.
<G-vec00241-002-s751><carry.tragen><en> Lord Jesus Christ, you have borne all our burdens and you continue to carry us.
<G-vec00241-002-s751><carry.tragen><de> GEBET Herr Jesus Christus, du hast unsere Last getragen und trägst uns immerfort.
<G-vec00241-002-s752><carry.tragen><en> God the Son, in your eyes I am like a poor, helpless sheep whom you gently pick up and carry when I’m worn out from my sins.
<G-vec00241-002-s752><carry.tragen><de> Gott Sohn, in deinen Augen bin ich ein armes, hilfloses Schaf, das du liebevoll auf deine Schultern hebst und trägst, wenn ich wegen meiner Sünden ganz erschöpft bin.
<G-vec00241-002-s753><carry.tragen><en> The loops can be placed around your belt when you carry the sheath in your waistband.
<G-vec00241-002-s753><carry.tragen><de> Wenn Du die Scheide in Deinem Hosenbund trägst, kannst Du die Schlaufen einfach um den Gürtel gelegt werden.
<G-vec00241-002-s754><carry.tragen><en> "I will give you a green bouquet That you may carry at your wedding feast."
<G-vec00241-002-s754><carry.tragen><de> Ich schenke dir einen grünen Strauß, Den trägst du bei deinem Hochzeitsschmaus.
<G-vec00241-002-s755><carry.tragen><en> You feel personally connected to us as a ministry - maybe you've been to one of our Awakenings - and you carry the same vision and have a heart to be more personally connected to us.
<G-vec00241-002-s755><carry.tragen><de> Du fühlst dich persönlich mit unserem Dienst verbunden - vielleicht warst du bei einem unserer Awakenings dabei - und du trägst die gleiche Vision und hast den Wunsch, mehr mit uns persönlich verbunden zu sein.
<G-vec00241-002-s756><carry.tragen><en> It is small and light enough for you to carry it comfortably in your pocket or belt.
<G-vec00241-002-s756><carry.tragen><de> Sie ist klein und leicht genug, dass du sie bequem in deiner Hosentasche oder am Gürtel trägst.
<G-vec00241-002-s757><carry.tragen><en> ACCEPTANCE By wearing this bracelet you always carry your individual birthstone close to you.
<G-vec00241-002-s757><carry.tragen><de> Mit diesem Armband trägst Du Deinen individuellen Geburtsstein oder den Deines/Deiner Lieblingsmenschen und verleihst somit Deiner persönlichen Verbundenheit Ausdruck.
<G-vec00241-002-s758><carry.tragen><en> WF: Everyone will talk to you about your father, you also carry his name.
<G-vec00241-002-s758><carry.tragen><de> WF: Jeder wird Dich natürlich auf Deinen Vater ansprechen, zudem trägst Du seinen Namen.
<G-vec00241-002-s759><carry.tragen><en> You will know as fact the light you carry and brighten the world with indelibly.
<G-vec00241-002-s759><carry.tragen><de> Du wirst das Licht, das du trägst und mit dem du die Welt unauslöschlich erhellst, als Tatsache kennen.
<G-vec00241-002-s722><carry.transportieren><en> The second layer - the dermis - contains blood vessels, which carry oxygen and vital nutrients around the body and take waste products away.
<G-vec00241-002-s722><carry.transportieren><de> Die zweite Schicht – die Dermis – enthält Blutgefäße, die Sauerstoff und lebenswichtige Nährstoffe im Körper transportieren und Abfallprodukte abtransportieren.
<G-vec00241-002-s723><carry.transportieren><en> This makes it easy to carry and means there are no caps to lose.
<G-vec00241-002-s723><carry.transportieren><de> So ist es leicht zu transportieren, und es können keine Kappen verloren gehen.
<G-vec00241-002-s724><carry.transportieren><en> This green screen amazon product is light in weight and thus easy to carry around.
<G-vec00241-002-s724><carry.transportieren><de> Dieses Greenscreen-Amazon-Produkt ist leicht im Gewicht und somit leicht zu transportieren.
<G-vec00241-002-s725><carry.transportieren><en> She was already an agreement with Lufthansa, which has undertaken to carry 8o kg of these drugs every day.
<G-vec00241-002-s725><carry.transportieren><de> Ich hatte bereits einen Vertrag mit der Lufthansa in der Tasche, Lufthansa verpflichtete sich, täglich 80 kg Medikamente zu transportieren.
<G-vec00241-002-s726><carry.transportieren><en> First aid kit box is Compact and light weight, easy to carry, equipped with bandage, Tweezers and so on.
<G-vec00241-002-s726><carry.transportieren><de> Erste Hilfe Kit Box ist kompakt und geringes Gewicht, leicht zu transportieren, ausgestattet mit Bandage, Pinzette und So weiter.
<G-vec00241-002-s727><carry.transportieren><en> The power then flows through transmission lines which carry electricity over long distances at extremely high voltages, eventually (well, in nanoseconds) to charging stations which supply it to the customers.
<G-vec00241-002-s727><carry.transportieren><de> Er fließt dann durch Übertragungsleitungen, die ihn bei extrem hohen Spannungen über große Entfernungen transportieren, und gelangt schließlich (na gut: in Nanosekunden) zu Ladestationen, von denen aus die Kunden beliefert werden.
<G-vec00241-002-s728><carry.transportieren><en> With this equipment, you can maintain your skis or board more efficiently with higher finish quality. We also have tons of tools available like screwdrivers, spare buckles and outsoles for Rossignol boots, easy carry systems for your skis and poles and even high precision thermometers to help you use the right wax depending on the snow temperature.
<G-vec00241-002-s728><carry.transportieren><de> Zum Pflege- und Werkzeug-Bereich gehören auch simple, aber nützliche Werkzeuge wie etwa Schraubendreher, Ösen und Wechselsohlen für Rossignol-Boots, Skibat-Clips, mit denen ihr eure Ski und Skistöcke besser transportieren könnt, und Thermometer für Wettkämpfer, mittels derer sie die Schneetemperatur bestimmen und ihr Wachs entsprechend anpassen können.
<G-vec00241-002-s729><carry.transportieren><en> The pen is easy to slide together so it is easy to carry.
<G-vec00241-002-s729><carry.transportieren><de> Der Stift ist einfach zusammen zu schieben, so ist es leicht zu transportieren.
<G-vec00241-002-s730><carry.transportieren><en> So it is easy to carry and perfect for laboratory and field application.
<G-vec00241-002-s730><carry.transportieren><de> So ist es einfach zu transportieren und perfekt für Labor- und Feldanwendungen geeignet.
<G-vec00241-002-s731><carry.transportieren><en> Well, this micro version might be much smaller in size, but you could still use it to carry your washing to the machine...albeit one sock at a time.
<G-vec00241-002-s731><carry.transportieren><de> Gut, diese Miniversion des beliebten Kübels, mag ein wenig klein sein, aber Ihre Wäsche können Sie dennoch zur Waschmaschine damit transportieren - Wenn auch nur Socke für Socke.
<G-vec00241-002-s732><carry.transportieren><en> These are reached via a central staircase and a lift that is able to carry heavy loads.
<G-vec00241-002-s732><carry.transportieren><de> Erreichen kann man diese über ein zentrales Treppenhaus sowie einen Fahrstuhl, der auch größere Lasten transportieren kann.
<G-vec00241-002-s734><carry.transportieren><en> ITRL conducts its testing on a 400 kg research concept vehicle (RCV), which can carry two passengers and reach a speed of 70 km/h.
<G-vec00241-002-s734><carry.transportieren><de> Das ITRL führt seine Tests an einem 400 kg schweren Konzeptfahrzeug (KF) durch, das zwei Personen transportieren und eine Geschwindigkeit von 70 km/h erreichen kann.
<G-vec00241-002-s735><carry.transportieren><en> We will carry your wheelchair or mobility aid free of charge.
<G-vec00241-002-s735><carry.transportieren><de> Wir transportieren Ihren Rollstuhl oder Ihre Mobilitätshilfe für Sie kostenfrei.
<G-vec00241-002-s736><carry.transportieren><en> Ask question Description The cork tray has a light edge so you can carry items well.
<G-vec00241-002-s736><carry.transportieren><de> Beschreibung Das Kork Tablett hat einen leichten Rand, sodass man Gegenstände gut transportieren kann.
<G-vec00241-002-s737><carry.transportieren><en> • Easy to carry it, and safe the place.
<G-vec00241-002-s737><carry.transportieren><de> • Leicht zu transportieren und den Ort zu sichern.
<G-vec00241-002-s738><carry.transportieren><en> With its small size, it is light and easy to carry.
<G-vec00241-002-s738><carry.transportieren><de> Mit seiner geringen Größe ist es leicht und einfach zu transportieren.
<G-vec00241-002-s739><carry.transportieren><en> • Carry information across pages of our Website and maintain your preferred language throughout the session.
<G-vec00241-002-s739><carry.transportieren><de> - Informationen auf unterschiedliche Seiten unserer Website zu transportieren und Ihre bevorzugte Sprache während der gesamten Sitzung beizubehalten.
<G-vec00241-002-s740><carry.transportieren><en> Try to avoid the Cool down or slow down at least by you wear the Smartphone close to the body, for example, in the inside pockets of coat and jacket – and the Smartphone is not in the coat or jacket pockets on the outside carry.
<G-vec00241-002-s740><carry.transportieren><de> Versuchen Sie das Auskühlen zu vermeiden oder zumindest zu verlangsamen, indem Sie das Smartphone eng am Körper tragen, beispielsweise in den Innentaschen von Mantel und Jacke – und das Smartphone nicht in den Mantel- oder Jackenaußentaschen transportieren.
<G-vec00241-002-s779><carry.verrichten><en> So those who carry out this service, in faith and in solitude, are really the ones who are the “first” according to the promise made by the Lord:
<G-vec00241-002-s779><carry.verrichten><de> Jene, die diesen Dienst in der Abgeschiedenheit und im Glauben verrichten, sind daher nach der Verheißung des Herrn die wirklichen "Ersten".
<G-vec00241-002-s780><carry.verrichten><en> By preventing him from taking international assignments, management ensures that he cannot inspect working conditions of the international drivers who mostly carry out their tasks abroad.
<G-vec00241-002-s780><carry.verrichten><de> Indem ihm keine Fahrten ins Ausland mehr zugewiesen werden, sorgt das Management dafür, dass er die Arbeitsbedingungen der internationalen Fahrer, die ihre Arbeit größtenteils im Ausland verrichten, nicht kontrollieren kann.
<G-vec00241-002-s781><carry.verrichten><en> While the machine performs the processing work, our people can carry out logistics tasks, for example, deal with the material preparation or read schedules, clamp ex-changeable staple magazines and refill nails.
<G-vec00241-002-s781><carry.verrichten><de> Während der laufenden Bearbeitungsvorgänge der Maschine können unsere Leute logistische Arbeiten verrichten, sich zum Beispiel um die Materialbereitstellung kümmern oder Pläne lesen, Wechselmagazine verklammern und Nägel nachfüllen.
<G-vec00241-002-s782><carry.verrichten><en> Now carry out a strenuous activity that lasts the whole day and that you have wanted to do since long time.
<G-vec00241-002-s782><carry.verrichten><de> Verrichten Sie jetzt eine anstrengende Tätigkeit, die Sie den ganzen Tag in Anspruch nimmt, und die Sie schon lange machen wollten.
<G-vec00241-002-s783><carry.verrichten><en> They carry out their tasks by binding to each other and building interaction networks.
<G-vec00241-002-s783><carry.verrichten><de> Ihre Aufgaben verrichten sie unter anderem dadurch, dass sie miteinander interagieren und Netzwerke bilden.
<G-vec00241-002-s784><carry.verrichten><en> If you use a program to carry out activities in your life, your freedom depends on your having control over the program.
<G-vec00241-002-s784><carry.verrichten><de> Wenn man ein Programm verwendet, um damit Aktivitäten in Ihrem Leben zu verrichten, hängt Ihre Freiheit davon ab, dass man die Kontrolle über das Programm hat.
<G-vec00241-002-s785><carry.verrichten><en> The blades in the compressor and the turbine thus carry out opposing tasks: The diagonally positioned blades in the compressor exert force on the gas and "push" it forward; in the case of expansion in the turbine, the gas exerts a force on the blades and drives them, which causes the shaft to which the blades are attached to rotate.
<G-vec00241-002-s785><carry.verrichten><de> Die Schaufelräder in Verdichter und Turbine haben entgegengesetzte Aufgaben zu verrichten: Im Verdichter üben die schrägstehenden Schaufeln einen Druck auf das Gas aus und „schieben“ es an; bei der Expansion in der Turbine übt das Gas einen Druck auf die Schaufeln aus und schiebt diese an, so dass die Achse (Welle), auf der die Schaufelräder befestigt sind, zu rotieren beginnt.
<G-vec00241-002-s786><carry.verrichten><en> 4 weeks later you are fully recovered and can also carry out heavy physical work.
<G-vec00241-002-s786><carry.verrichten><de> 4 Wochen später sind Sie wieder völlig hergestellt und können auch schwere, körperliche Arbeit verrichten.
<G-vec00241-002-s787><carry.verrichten><en> We carry out our service in the society not only because of economical or sociopolitical reasons, but by remembering Jesus’ sacrifice on the cross and his sending words we do know: we have a mission in the world, which is to serve by the gospel among those in need.
<G-vec00241-002-s787><carry.verrichten><de> Wir verrichten unsere Arbeit in der Gesellschaft nicht nur aus wirtschaftlichen oder sozialpolitischen Gründen, sondern weil wir wissen, dass Jesus uns in die Welt gesandt hat und dass wir in der Welt eine Mission haben: wir müssen gemäß dem Evangelium den Menschen in Not dienen.
<G-vec00241-002-s788><carry.verrichten><en> Workers are exposed to the elements for hours and a time and sometimes carry out particularly exhausting and demanding work.
<G-vec00241-002-s788><carry.verrichten><de> Die Arbeiter sind stundenlang der Witterung ausgesetzt und verrichten zum Teil besonders anstrengende Arbeiten.
<G-vec00241-002-s789><carry.verrichten><en> Frame building, upholstery, cutting and stitching require experienced specialists who are excellently trained to carry out their trade with passion for the product.
<G-vec00241-002-s789><carry.verrichten><de> Gestellbau, Polsterei, Zuschnitt und Näherei bedürfen erfahrener Spezialisten, die exzellent ausgebildet sind und ihre Arbeit mit Liebe zum Produkt verrichten.
<G-vec00241-002-s790><carry.verrichten><en> In addition, pregnant women may not work for more than 8 ½ hours per day, and may not carry out any strenuous physical work.
<G-vec00241-002-s790><carry.verrichten><de> Außerdem dürfen Schwangere nicht mehr als 8,5 Stunden pro Tag arbeiten und keine schwere körperliche Arbeit verrichten.
<G-vec00241-002-s791><carry.verrichten><en> Communists must carry out their preparatory revolutionary work in every situation and always be on combat footing, because it is often almost impossible to predict the alternation between a period of upheaval and a period of quiescence; and even in cases where such foresight is possible it cannot generally be used to reorganize the party, because the change usually occurs in a very short time, indeed often quite suddenly.
<G-vec00241-002-s791><carry.verrichten><de> Kommunisten müssen ihre vorbereitende revolutionäre Arbeit in jeder Situation verrichten und stets auf Kampfbereitschaft gestellt sein, weil es oft beinahe unmöglich ist, den Wechsel der Erhebungsperiode und der Periode der Stille vorauszusehen; und auch in den Fällen, wo es möglich wäre, kann diese Voraussicht meist nicht mehr zur Neuorganisierung der Partei ausgenützt werden, weil der Wechsel gewöhnlich in sehr kurzer Zeit, ja oft sogar ganz überraschend eintritt.
<G-vec00241-002-s792><carry.verrichten><en> He rises ideally one in the frequency range where the bookshelf speakers or floor speakers no longer carry out their work, because they can not reproduce those frequencies.
<G-vec00241-002-s792><carry.verrichten><de> Dabei steigt er optimalerweise bei dem Frequenzbereich ein, bei dem Regallautsprecher oder Standlautsprecher ihre Arbeit nicht mehr verrichten, weil sie diese Frequenzen nicht wiedergeben können.
<G-vec00241-002-s793><carry.verrichten><en> The free movement of workers needs to be distinguished from the freedom to provide services, which includes the right of undertakings to provide services in another Member State, for which they may post their own workers to another Member State temporarily in order for them to carry out the work necessary to provide services in that Member State.
<G-vec00241-002-s793><carry.verrichten><de> Die Freizügigkeit der Arbeitnehmer ist nicht zu verwechseln mit der Dienstleistungsfreiheit, die das Recht von Unternehmen umfasst, Dienstleistungen in einem anderen Mitgliedstaat zu erbringen und zu diesem Zweck ihre Arbeitnehmer vorübergehend in diesen anderen Mitgliedstaat zu entsenden, damit diese dort die für die Erbringung der Dienstleistungen erforderlichen Arbeiten verrichten.
<G-vec00241-002-s794><carry.verrichten><en> The production and quality of the Denomination of Origin Vinos de Madrid, which brings together about 50 wineries in the region where 3,200 winegrowers carry out their work, is still strong.
<G-vec00241-002-s794><carry.verrichten><de> Die Produktion und Qualität der Herkunftsbezeichnung Vinos de Madrid, die etwa 50 Weingüter in der Region zusammenbringt, in der 3.200 Winzer ihre Arbeit verrichten, ist nach wie vor stark.
<G-vec00241-002-s795><carry.verrichten><en> I encourage you to carry out your important work with sentiments of harmony and unity.
<G-vec00241-002-s795><carry.verrichten><de> Ich ermutige euch, eure wichtige Arbeit in der Haltung der Eintracht und Einheit zu verrichten.
<G-vec00241-002-s796><carry.verrichten><en> Therefore, it is clear that such a discriminatory dismissal was a violation of the right to freedom of association freedom of association The right to form and join the trade union of one’s choosing as well as the right of unions to operate freely and carry out their activities without undue interference.
<G-vec00241-002-s796><carry.verrichten><de> Es ist somit offensichtlich, dass diese diskriminierenden Entlassungen einen klaren Verstoß gegen das Recht auf Vereinigungsfreiheit Vereinigungsfreiheit Das Recht auf die Gründung von und den Beitritt zu Gewerkschaften nach eigener Wahl sowie das Recht der Gewerkschaften, ungehindert zu arbeiten und ihre Aktivitäten ohne unzulässige Eingriffe zu verrichten.
<G-vec00241-002-s797><carry.verrichten><en> In Hellenic historical sources they are portrayed as old men who have to carry out hard labour.
<G-vec00241-002-s797><carry.verrichten><de> In hellenistischen Schriftquellen werden sie als alte Männer geschildert, die harte Arbeit verrichten müssen.
<G-vec00241-002-s817><carry.vornehmen><en> It is forbidden to wash cars, change engine oil and carry out similar activities at the Campsite without the permission of the Campsite management.
<G-vec00241-002-s817><carry.vornehmen><de> Es ist verboten, im Camping eine Fahrzeugwäsche oder einen Motorölwechsel oder ähnliche Tätigkeiten ohne Genehmigung der Campingleitung vorzunehmen.
<G-vec00241-002-s818><carry.vornehmen><en> Nature Bike points out to the fact that it is forbidden to change a leasehold bicycle, to carry out important repair in him, to sublet the bicycles, to go on the beach, to transport another passenger, apart from a child transported in a seat admitted for.
<G-vec00241-002-s818><carry.vornehmen><de> Nature Bike weist darauf hin, dass es verboten ist, ein gemietetes Fahrradzu verändern, bedeutende Reparaturen an ihm vorzunehmen, das Fahrrad unterzuvermieten, am Strand zu fahren, einen weiteren Mitfahrer zu transportieren, abgesehen von Kindern, die in einem dafür zugelassenen Sitz transportiert werden.
<G-vec00241-002-s819><carry.vornehmen><en> On average, we advise you to carry out this inspection every three months.
<G-vec00241-002-s819><carry.vornehmen><de> Wir empfehlen, diese Prüfung durchschnittlich alle drei Monate vorzunehmen.
<G-vec00241-002-s820><carry.vornehmen><en> In registering third parties for the event, you thereby explicitly declare that you are authorised to carry out the said registration and give an appropriate declaration of consent to data processing and to receiving e-mails.
<G-vec00241-002-s820><carry.vornehmen><de> Für den Fall, dass Sie dritte Personen zur Veranstaltung anmelden, erklären Sie damit ausdrücklich, dass Sie berechtigt sind, diese Anmeldung vorzunehmen und eine entsprechende Zustimmungserklärung zur Datenverarbeitung und zum E-Mail-Empfang abzugeben.
<G-vec00241-002-s821><carry.vornehmen><en> S1 Optics GmbH reserves the right, without prior notification, to carry out alterations or additions to the information provided.
<G-vec00241-002-s821><carry.vornehmen><de> S1 Optics GmbH behält sich das Recht vor, ohne vorherige Ankündigung, Änderungen oder Ergänzungen an den bereitgestellten Informationen vorzunehmen.
<G-vec00241-002-s822><carry.vornehmen><en> The Bauhaus Dessau Foundation, represented by the management of the respective property, is entitled to close all exits, except the main exit, in the event of a theft alarm in order to carry out controls when visitors leave the premises.
<G-vec00241-002-s822><carry.vornehmen><de> Die Stiftung Bauhaus Dessau, vertreten durch die anwesende Hausleitung, ist berechtigt, bei Diebstahlalarm sämtliche Ausgänge, außer dem Hauptausgang, zu schließen, um dort eine Kontrolle beim Auslass der Besucher vorzunehmen.
<G-vec00241-002-s823><carry.vornehmen><en> Likewise, it is essential to train managers for developing countries and to carry out technological transfers towards these countries.
<G-vec00241-002-s823><carry.vornehmen><de> Ebenso ist es wichtig, fähige Gruppen für die Entwicklungsländer auszubilden und zugunsten dieser Länder technologische Transfers vorzunehmen.
<G-vec00241-002-s824><carry.vornehmen><en> 6.2 PwC is entitled to service and maintain the software and/or hardware systems at regular intervals and to carry out data backups.
<G-vec00241-002-s824><carry.vornehmen><de> 6.2 PwC ist berechtigt, die Software und/oder Hardware-Systeme in regelmäßigen Abständen zu warten, zu pflegen und Datensicherungen vorzunehmen.
<G-vec00241-002-s825><carry.vornehmen><en> Sebuyo is entitled, but not obligated, to carry out a supplementary distribution of the set content via cooperating marketplaces and other partners online.
<G-vec00241-002-s825><carry.vornehmen><de> 8.2 Sebuyo ist berechtigt, aber nicht verpflichtet, eine ergänzende Verbreitung des eingestellten Inhalts auch über kooperierende Marktplätze und andere Partner online vorzunehmen.
<G-vec00241-002-s826><carry.vornehmen><en> The objective of the joint research project MiWa is to carry out a first replicable and comprehensive assessment of the problem “microplastics in the anthropogenically influenced water cycle”, addressing the implications of the legal requirements (German directives on wastewater, surface water, groundwater, and drinking water).
<G-vec00241-002-s826><carry.vornehmen><de> Das Ziel des Verbundprojektes MiWa ist, eine erste, nachvollziehbare, übergreifende und für die verschiedenen rechtlichen Anforderungen (AbwasserVo, OberflächengewVO, GrundwasserVO, TrinkwVO) notwendige Bewertung des erkannten Problembereichs "Mikroplastik im anthropogen geprägten Wasserkreislauf" vorzunehmen.
<G-vec00241-002-s827><carry.vornehmen><en> The various possibilities for cultivation in combination with the range of shins and points mean that TopDown can carry out many different tasks without a change of tractor.
<G-vec00241-002-s827><carry.vornehmen><de> Die vielfältigen Bearbeitungsvarianten in Kombination mit der breiten Palette an Scharen und Leitblechen machen TopDown zu einer Maschine, die viele Aufgaben übernehmen kann, ohne dass dabei ein Wechsel des Schleppers vorzunehmen ist.
<G-vec00241-002-s828><carry.vornehmen><en> The Client shall provide all materials and operating supplies and carry out all actions free of charge that are required for regulating the repaired object and for executing tests.
<G-vec00241-002-s828><carry.vornehmen><de> Vom Auftraggeber sind auf seine Kosten alle Materialien und Betriebsstoffe bereitzustellen und alle sonstigen Handlungen vorzunehmen, die zur Einregulierung des Reparaturgegenstandes und zur Durchführung der Erprobung notwendig sind.
<G-vec00241-002-s829><carry.vornehmen><en> This makes it all the more important for you to carry out therapeutic procedures at a compact workplace that corresponds to your complete spectrum of services and medical requirements.
<G-vec00241-002-s829><carry.vornehmen><de> Umso wichtiger ist es für Sie, Ihre therapeutischen Maßnahmen an einem Kompaktarbeitsplatz vorzunehmen, der Ihrem spezifischen Leistungsspektrum und Ihren ärztlichen Anforderungen in besonderer Weise entspricht.
<G-vec00241-002-s830><carry.vornehmen><en> Disputes involved clubs, whether still liabilities from a transfer contract and to carry out is an appropriate entry in the TMS, would be those referred to in article 22 f.) the case-law of the FIFA and here according to article 23 paragraph 1 FIFA transfer Statute of the Commission on the status of players drops to.
<G-vec00241-002-s830><carry.vornehmen><de> Streitigkeiten der beteiligten Vereine, ob noch Verbindlichkeiten aus einem Transfervertrag bestehen und eine entsprechende Eintragung im TMS vorzunehmen ist, wären solche, die gemäß Artikel 22 f.) der Rechtsprechung der FIFA und hier gemäß Artikel 23 Absatz 1 FIFA Transfer Statut der Kommission für den Status von Spielern zufällt.
<G-vec00241-002-s831><carry.vornehmen><en> The publisher reserves the right to carry out changes or enlargements of the information provided without prior notice.
<G-vec00241-002-s831><carry.vornehmen><de> Die Herausgeber behalten sich das Recht vor, ohne vorherige Ankündigung Änderungen oder Ergänzungen an den bereitgestellten Informationen vorzunehmen.
<G-vec00241-002-s832><carry.vornehmen><en> But of course, any garage will be able to carry out the installation.
<G-vec00241-002-s832><carry.vornehmen><de> Natürlich ist auch jede Werkstatt in der Lage, den Einbau vorzunehmen.
<G-vec00241-002-s833><carry.vornehmen><en> CSM Production reserves the right to carry out changes or completions of the provided information and the prices without a previous announcement.
<G-vec00241-002-s833><carry.vornehmen><de> CSM Production behält sich das Recht vor, ohne vorherige Ankündigung Änderungen oder Ergänzungen der bereitgestellten Informationen und der Preise vorzunehmen.
<G-vec00241-002-s834><carry.vornehmen><en> As a result, we can carry out perforation work on a host of pipes of different diameters and thicknesses, with different patterns of perforation and adapting to customers’ requirements.
<G-vec00241-002-s834><carry.vornehmen><de> Deshalb sind wir in der Lage Bohrarbeiten an unzähligen Rohrarten, mit verschiedenen Durchmessern und Dicken, und mit verschiedenen Bohrvorlagen vorzunehmen, um uns dadurch an den Kundenbedarf anpassen zu können.
<G-vec00241-002-s835><carry.vornehmen><en> Based on urban planning, traffic planning and economic and landscape considerations, this is a good opportunity to determine new uses for the site and to carry out a qualitative and quantitative process to establish future use.
<G-vec00241-002-s835><carry.vornehmen><de> Auf der Grundlage von städtebaulichen, verkehrsplanerischen, ökonomischen, und landschaftlichen Überlegungen sind die Chancen für eine Neunutzung zu bestimmen und eine qualitative und quantitative Nutzungsfestlegung vorzunehmen.
<G-vec00241-002-s855><carry.übernehmen><en> No, deposits and withdrawals are free for users, and Casino Joy will carry the fees for them.
<G-vec00241-002-s855><carry.übernehmen><de> Einzahlungen und Auszahlungen kosten die Nutzer keine Gebühren und Casino Joy wird diese Gebühren für die Spieler übernehmen.
<G-vec00241-002-s856><carry.übernehmen><en> We carry out the complete design work, delivery and assembly of crushing, screening, mixing and batching processes as well as the realization of rail car discharge stations, landfill sites, reloading points and terminals for trucks and rail cars.
<G-vec00241-002-s856><carry.übernehmen><de> Wir übernehmen die gesamte Konzipierung, Lieferung und Montage von Zerkleinerungs-, Sieb-, Misch- und Dosierprozessen sowie die Realisierung von Waggonentladestationen, Deponie- und Hafenumschlagplätzen und Verladestationen für LKWs und Waggons.
<G-vec00241-002-s857><carry.übernehmen><en> Compared with special machines, robots are characterized by much greater flexibility: They are economical even for small automation solutions and can alternatively carry out different tasks.
<G-vec00241-002-s857><carry.übernehmen><de> Im Vergleich zu Sondermaschinen zeichnen sich Roboter durch deutlich höhere Flexibilität aus: Sie sind schon bei kleinen Automatisierungslösungen wirtschaftlich und können abwechselnd verschiedene Aufgaben übernehmen.
<G-vec00241-002-s858><carry.übernehmen><en> With more than 1,200 translators distributed all over the world, we can carry out any translation project for you in any language and any area of expertise.
<G-vec00241-002-s858><carry.übernehmen><de> Mit mehr als 1.200 Übersetzern auf der ganzen Welt sind wir in der Lage, jedes Übersetzungsprojekt in jeder Sprache und auf jedem Fachgebiet für Sie zu übernehmen.
<G-vec00241-002-s859><carry.übernehmen><en> Drilling rigs of this type are operated by service companies which are contracted by oil companies to carry out drilling operations.
<G-vec00241-002-s859><carry.übernehmen><de> Derartige Anlagen werden von Dienstleistungsunternehmen betrieben, die für Ölkonzerne die Bohrarbeiten übernehmen.
<G-vec00241-002-s860><carry.übernehmen><en> Please note that according to Article 2, if we issue a Ticket containing the Airline Designator Code of another Carrier (not SK) in the Carrier box of the Ticket for that flight or flight segment, or if we check Baggage for Carriage on another Carrier, we do so only as an agent for the other Carrier, and we carry no liability for this Carriage.
<G-vec00241-002-s860><carry.übernehmen><de> Bitte beachten Sie, dass wir gemäß Paragraph 2, wenn wir ein Ticket mit dem Airline-Code eines anderen Flugunternehmens (nicht SK) in der Spalte „Fluggesellschaft“ („Carrier“) für diesen Flug oder dieses Flugsegment ausstellen, oder wenn wir Gepäck für die Beförderung mit einer anderen Fluggesellschaft aufgeben, dies nur als Bevollmächtigter der anderen Fluggesellschaft tun und keine Haftung für diese Beförderung übernehmen.
<G-vec00241-002-s861><carry.übernehmen><en> After successful completion, you may teach theoretical lessons under the supervision of a dive instructor, demonstrate skills to students in confined water, as well as carry out some of the dive instructors tasks in open water.
<G-vec00241-002-s861><carry.übernehmen><de> Nach erfolgreichem Abschluß darfst du unter Supervision eines Tauchlehrers Theorielektionen leiten, Skills in der Halle den Tauchschülern demonstrieren und auch im Freiwasser teilweise Aufgaben des Tauchlehrers übernehmen.
<G-vec00241-002-s862><carry.übernehmen><en> Following this experience Simone returned to Italy to carry out several advisory mandates, e.g. the acquisition of an Italian coffee roasting company for an Austrian client or the restructuring of companies in the coffee sector for Cogeco S.p.a.
<G-vec00241-002-s862><carry.übernehmen><de> Nach dieser Erfahrung kehrte Simone Marzaroli wieder nach Italien zurück um einige Beratungsmandate zu übernehmen, wie beispielsweise den Ankauf einer italienischen Kaffeerösterei für einen österreichischen Kunden, oder die Unternehmensrestrukturierungen im Kaffeesektor für Cogeco S.p.a.
<G-vec00241-002-s863><carry.übernehmen><en> Featuring PI controllers and an integrated PLC, they can carry out logical sequences and take care of process control on their own.
<G-vec00241-002-s863><carry.übernehmen><de> Dank PI-Regler und einer integrierten PLC können sie komplette Ablaufsteuerungen übernehmen und Prozesse autark regeln.
<G-vec00241-002-s865><carry.übernehmen><en> Maintenance & inspection Our maintenance teams perform periodic inspections of the condition of your installation and carry out maintenance on the entire installation on site.
<G-vec00241-002-s865><carry.übernehmen><de> Wartung und Inspektion Unsere Wartungsteams machen regelmäßige Bestandsaufnahmen vom Zustand Ihrer Anlage und übernehmen die Wartung Ihrer gesamten Anlage vor Ort.
<G-vec00241-002-s866><carry.übernehmen><en> If after the concept phase more complex measures require a greater level of planning, such as the preparation for the approval of planning permission, we carry out these task for you.
<G-vec00241-002-s866><carry.übernehmen><de> Falls für einzelne komplexere Maßnahmen nach der Konzeptphase noch weitere Planungsleistungen wie die Ausführungs- oder Genehmigungsplanung erforderlich sind, übernehmen wir diese Aufgaben gerne für Sie.
<G-vec00241-002-s867><carry.übernehmen><en> Rollers subsequently carry out final compaction.
<G-vec00241-002-s867><carry.übernehmen><de> Walzen übernehmen anschließend die finale Verdichtung.
<G-vec00241-002-s868><carry.übernehmen><en> As part of corporate finance activities our specialists carry out reviews of completion accounts prepared in connection with company acquisitions and disposals.
<G-vec00241-002-s868><carry.übernehmen><de> Im Rahmen von Unternehmenstransaktionen übernehmen unsere Spezialisten die Prüfung von Abschlüssen, die im Rahmen von Unternehmenskäufen und -verkäufen erstellt werden.
<G-vec00241-002-s870><carry.übernehmen><en> As a media partner we carry out editorial work and produce moving pictures.
<G-vec00241-002-s870><carry.übernehmen><de> Als Medienpartner übernehmen wir Redaktion und Produktion von bewegten Bildern.
<G-vec00241-002-s871><carry.übernehmen><en> You receive clear action recommendations, we carry the responsibility.
<G-vec00241-002-s871><carry.übernehmen><de> Sie bekommen klare Handlungsempfehlungen, wir übernehmen die Verantwortung.
<G-vec00241-002-s872><carry.übernehmen><en> Where We enter into a partnership with a third party whereby they carry out certain functions for Us or We operate under the brand of a third party, We may share and/or transfer your Personal Information and any other data relating to your use of the Facility with such third party.
<G-vec00241-002-s872><carry.übernehmen><de> Sofern wir mit Dritten eine Partnerschaft eingehen, in der diese für uns bestimmte Funktionen übernehmen oder wir unter ihrer Marke agieren, können wir Ihre persönlichen Daten und alle weiteren Daten in Bezug auf Ihre Nutzung der Einrichtung bei solchen Dritten mit diesen teilen und/oder an sie übertragen.
<G-vec00241-002-s873><carry.übernehmen><en> This is down to one simple reason: only a specialist dealer can provide you with detailed advice, recommend the best bike for you, and then carry out the service work later.
<G-vec00241-002-s873><carry.übernehmen><de> Aus einem einfachen Grund: nur der Fachhändler kann Sie ausführlich beraten, Ihnen das für Sie beste Rad empfehlen und später den Service dafür übernehmen.
<G-vec00241-002-s874><carry.übertragen><en> “A self-sovereign blockchain based identity is well-suited for this use case because workers should be able to carry over their identity from one company to another and no specific company should own or manage it.
<G-vec00241-002-s874><carry.übertragen><de> „Eine selbstsouveräne, auf Blockchain basierende Identität ist für diesen Anwendungsfall gut geeignet, da die Mitarbeiter in der Lage sein sollten, ihre Identität von einem Unternehmen auf ein anderes zu übertragen, und kein bestimmtes Unternehmen sollte es besitzen oder verwalten.
<G-vec00241-002-s875><carry.übertragen><en> Companies hand over their project work to students who carry it out under the supervision of university lecturers.
<G-vec00241-002-s875><carry.übertragen><de> Unternehmen übertragen ihre Projektaufgaben an Studierenden, die sie unter der Betreuung von Hochschullehrern verwirklichen.
<G-vec00241-002-s876><carry.übertragen><en> They do not carry any diseases.
<G-vec00241-002-s876><carry.übertragen><de> Kopfläuse übertragen keine Krankheiten.
<G-vec00241-002-s877><carry.übertragen><en> We do not carry over negative balances from one month to the next one.
<G-vec00241-002-s877><carry.übertragen><de> Jedoch übertragen wir diesen negativen Kontostand nicht von einem auf das andere Monat.
<G-vec00241-002-s878><carry.übertragen><en> On the other side, Tesla wanted to build the energetic system, which was supposed to carry the electricity over the whole world without any costs.
<G-vec00241-002-s878><carry.übertragen><de> Tesla wiederum wollte ein Energiesystem bauen, das kostenlos Strom in alle Welt übertragen sollte.
<G-vec00241-002-s879><carry.übertragen><en> For He will set Your Mind at rest at last and carry It with You unto Your God.
<G-vec00241-002-s879><carry.übertragen><de> Denn Er wird Euren Verstand letztendlich beruhigen und Ihn mit Euch zu Eurem Gott übertragen.
<G-vec00241-002-s880><carry.übertragen><en> It is widely used across the web and all data is anonymised meaning the cookies carry no personally identifiable information.
<G-vec00241-002-s880><carry.übertragen><de> Es wird im Web weithin verwendet, und alle Daten werden anonymisiert; das bedeutet, dass die Cookies keine Informationen für eine mögliche Identifizierung von Personen übertragen.
<G-vec00241-002-s881><carry.übertragen><en> If you multiplied the 4 by a number larger than 2 in the ones place, you'd get an answer larger than 9 and would have to carry the number in the tens place of the result over the number in the tens place of the top number.
<G-vec00241-002-s881><carry.übertragen><de> Wenn du die 4 mit einer Zahl größer als 2 in der Einerziffer multiplizierst, dann erhältst du ein Ergebnis, das größer als 9 ist und du müsstest die Zehnerziffer des Ergebnisses übertragen zur Zehnerziffer der oberen Zahl.
<G-vec00241-002-s882><carry.übertragen><en> Nerve fibers are surrounded by a protective sheath of myelin, which helps to insulate them and ensure that the messages they carry – the nerve impulses – travel quickly and correctly.
<G-vec00241-002-s882><carry.übertragen><de> Die Nervenfasern sind von einer Schutzschicht aus Myelin umhüllt, die die Fasern isoliert und dafür sorgt, dass die Signale, die sie übermitteln, die Nervenimpulse, schnell und fehlerfrei übertragen werden.
<G-vec00241-002-s883><carry.übertragen><en> Foxes also carry some other parasites dangerous for man, one of them the tapeworm Echinococcus multilocularis.
<G-vec00241-002-s883><carry.übertragen><de> Füchse übertragen auch einige andere für den Menschen gefährliche Parasiten, einer von ihnen der Bandwurm Echinococcus multilocularis.
<G-vec00241-002-s884><carry.übertragen><en> B channels B channels or “Bearer” channels carry the data, whether voice or internet data.
<G-vec00241-002-s884><carry.übertragen><de> B-Kanäle oder "Bearer"-Kanäle übertragen die Daten, ob Sprach- oder Internetdaten.
<G-vec00241-002-s885><carry.übertragen><en> Both techniques have drawbacks: the former is time-consuming and requires advanced programming skills, and the latter does not enable the robot to re-use what it has learned to carry out other tasks.
<G-vec00241-002-s885><carry.übertragen><de> Beide haben Nachteile: die erste Methode ist sehr zeitaufwändig und erfordert einen versierten Programmierer, bei der zweiten ist der Roboter nicht in der Lage, das Gelernte auf andere Aufgaben zu übertragen.
<G-vec00241-002-s886><carry.übertragen><en> Their legs...and wings...seem to carry some contagion.
<G-vec00241-002-s886><carry.übertragen><de> Ihre Beine... und Flügel... scheinen eine Krankheit zu übertragen.
<G-vec00241-002-s887><carry.übertragen><en> Eizo EV2736W Digital inputs carry a binary digital signal, instead of an analog signal.
<G-vec00241-002-s887><carry.übertragen><de> Eizo EV2736W Digitale Eingänge übertragen binäre Signale anstatt analoger Signale.
<G-vec00241-002-s888><carry.übertragen><en> "It's therefore better not to carry over old habits into the new partnership."
<G-vec00241-002-s888><carry.übertragen><de> Alte Gewohnheiten werden deshalb besser nicht auf die neue Partnerschaft übertragen.
<G-vec00241-002-s889><carry.übertragen><en> Cookies cannot harm your computer or carry viruses.
<G-vec00241-002-s889><carry.übertragen><de> Cookies können Ihrem Rechner nicht schaden oder Viren übertragen.
<G-vec00241-002-s890><carry.übertragen><en> PoE uses your network's wired Ethernet connection to carry electrical currents to devices such as phones, security cameras, and Wi-Fi access points—passing electricity through their data cables rather than power cords or AC adapters.
<G-vec00241-002-s890><carry.übertragen><de> PoE nutzt die kabelgebundene Ethernetverbindung Ihres Netzwerks, um elektrischen Strom auf Ihre Geräte wie Handys, Sicherheitskameras und WLAN Access Points zu übertragen, wobei Elektrizität über die Datenkabel und nicht über Stromkabel oder Netzteile übertragen wird.
<G-vec00241-002-s891><carry.übertragen><en> With no air to carry sound, you’d never hear an atomic bomb going off directly behind you.
<G-vec00241-002-s891><carry.übertragen><de> Ohne eine Atmosphäre, durch die Schallwellen übertragen werden, könnte man nicht einmal die Explosion einer Atombombe direkt hinter sich hören.
<G-vec00241-002-s892><carry.übertragen><en> If you want to convert SWF files to a playable format to your Mac so that you can play and carry it as you wish, then you need professional software to convert the SWF files to MP4 or other Mac supported formats.
<G-vec00241-002-s892><carry.übertragen><de> Wenn Du SWF-Dateien in ein abspielbares Format für Deinen Mac konvertieren möchtest, um sie nach Belieben abspielen und übertragen zu können, brauchst Du eine professionelle Software, um SWF-Dateien in MP4 oder andere Mac-kompatible Formate zu konvertieren.
<G-vec00546-002-s418><carry.haben><en> We used MIT’s Condor software to carry out a multi-step betweenness centrality analysis for each company in Crypto Valley working with blockchain.
<G-vec00546-002-s418><carry.haben><de> Methode Wir haben eine mehrstufige Betweenness-Centrality-Analyse für diejenigen Unternehmen durchgeführt, die im Crypto Valley mit Blockchain-Bezug tätig sind.
<G-vec00546-002-s419><carry.haben><en> / 2 A small saddlebag - for those rides where you only want to carry the essentials
<G-vec00546-002-s419><carry.haben><de> / 2 Eine kleine aber feine Satteltasche für alle Fahrten, auf denen Sie immer das Wichtigste dabei haben wollen.
<G-vec00546-002-s420><carry.haben><en> You wouldn´t believe the amount of people who forget personal documents at home, so this is our first recommendation, check it twice if you carry everything necessary before your trip.
<G-vec00546-002-s420><carry.haben><de> Persönliche Dokumente Die Anzahl der Reisenden, die ihre persönlichen Dokumente zuhause vergessen, ist erstaunlich; dies ist somit unsere erste Empfehlung, überprüfen Sie vor dem Reisantritt ob Sie alles Notwendige dabei haben.
<G-vec00546-002-s421><carry.haben><en> The next step was to subject the system to electrical and hydraulic tests and carry out optimisations as necessary.
<G-vec00546-002-s421><carry.haben><de> Wir haben dann noch elektrische und hydraulische Tests durchgeführt und in der Folge die entsprechenden Optimierungen vorgenommen.
<G-vec00546-002-s422><carry.haben><en> Many paid parking spots accept credit card payments, but it’s best to always carry coins just in case.
<G-vec00546-002-s422><carry.haben><de> An vielen kostenpflichtigen Parkplätzen kann man mit Kreditkarte zahlen, doch es ist besser, immer ein paar Münzen dabei zu haben.
<G-vec00546-002-s423><carry.haben><en> I said, knowing the prayers of pure souls carry much weight with the Father.
<G-vec00546-002-s423><carry.haben><de> Denn ich weiß, dass die Gebete reiner Seelen viel Gewicht haben beim Vater.
<G-vec00546-002-s424><carry.haben><en> 6 being confident of this, that he who began a good work in you will carry it on to completion until the day of Christ Jesus.
<G-vec00546-002-s424><carry.haben><de> 6 und ich bin dessen gewiss, dass er, der das gute Werk in euch angefangen hat, es bis zum Tag Christi Jesu auch vollendet haben wird.
<G-vec00546-002-s425><carry.haben><en> The section titles in the Terms of Use are for your convenience only and carry no contractual or legal effect whatsoever.
<G-vec00546-002-s425><carry.haben><de> 17.6 Überschriften Die Abschnittsüberschriften in diesen Nutzungsbedingungen dienen nur der besseren Übersichtlichkeit und haben keine rechtliche oder vertragliche Wirkung.
<G-vec00546-002-s426><carry.haben><en> All of our 925 Sterling silver individual bracelets carry the desired designer tag, along with a unique charm of Ø 2cm.
<G-vec00546-002-s426><carry.haben><de> Alle unsere 18 Karat Vermeil Gold-Armbänder haben das beliebte Designer-Label, zusammen mit einem bedeutungsvollen Charme von Ø 2cm.
<G-vec00546-002-s427><carry.haben><en> We carry a water filter for this.
<G-vec00546-002-s427><carry.haben><de> Dazu haben wir einen Wasserfilter.
<G-vec00546-002-s428><carry.haben><en> Positive liberty asserts that freedom is found in a person's ability to exercise agency, particularly in the sense of having the power and resources to carry out their own will, without being inhibited by the structural inhibitions from society.
<G-vec00546-002-s428><carry.haben><de> Positive Freiheit versichert, dass Freiheit zu finden ist in einer persönlichen Fähigkeit, um Handlungsfähigkeit auszuüben, insbesondere in dem Sinn, die Macht und die Mittel zu haben, den eigenen Willen umzusetzen ohne Hemmungen durch strukturelle Hemmnisse seitens der Gesellschaft.
<G-vec00546-002-s429><carry.haben><en> Features 16, 32 or 64 GB hardware-encrypted storage to carry your files with you securely.
<G-vec00546-002-s429><carry.haben><de> Funktionen 16, 32 oder 64 GB Hardware-verschlüsselter Speicher erlaubt es Ihre Dateien immer sicher dabei zu haben.
<G-vec00546-002-s430><carry.haben><en> The big, proud mountains carry oil, gold and fire inside.
<G-vec00546-002-s430><carry.haben><de> Öl, Gold und Feuer haben die großen, stolzen Berge in sich.
<G-vec00546-002-s431><carry.haben><en> The trader shall carry out the reimbursement referred to in the first sentence using the same means of payment as the consumer used for the initial transaction, unless the consumer has expressly agreed otherwise and provided that the consumer does not incur any fees as a result of such reimbursement.
<G-vec00546-002-s431><carry.haben><de> Für diese Rückzahlung verwenden wir dasselbe Zahlungsmittel, das Sie bei der ursprünglichen Transaktion eingesetzt haben, es sei denn, mit Ihnen wurde ausdrücklich etwas anderes vereinbart; in keinem Fall werden Ihnen wegen dieser Rückzahlung Entgelte berechnet.
<G-vec00546-002-s432><carry.haben><en> Two short words that carry terrible weight and power.
<G-vec00546-002-s432><carry.haben><de> Zwei kurze Worte, die schreckliches Gewicht und Macht haben.
<G-vec00546-002-s433><carry.haben><en> ■ If you are successful and accept the role we will use your personal information provided during the online application process to carry out pre-employment screening (further details of which will be provided to you at the time) and this information will also form part of your employment file.
<G-vec00546-002-s433><carry.haben><de> ■ Wenn Sie erfolgreich sind und die Position akzeptieren, werden wir Ihre personenbezogenen Daten, die Sie während des Online-Bewerbungsprozesses zur Verfügung gestellt haben, für ein Screening vor der Einstellung (weitere Einzelheiten werden Ihnen zu diesem Zeitpunkt mitgeteilt) und für Ihre Personalakte verwenden.
<G-vec00546-002-s434><carry.haben><en> The purple wire on the solenoid should carry power if the ignition is in run, and the power should go away if the brake pedal is depressed.
<G-vec00546-002-s434><carry.haben><de> Das rosa Kabel sollte 12V haben, wenn die Zündung an ist, und die 12V sollten verschwinden, wenn das Bremspedal betätigt wird.
<G-vec00546-002-s435><carry.haben><en> The Adityas are soft and carry the knowledge; they bring forth in us the divine qualities.
<G-vec00546-002-s435><carry.haben><de> Die Adityas sind sanft und haben das Wissen; sie bringen in uns die göttlichen Qualitäten hervor.
<G-vec00546-002-s436><carry.haben><en> 8.3 You agree to carry out quality assurance in accordance with the latest state of the art appropriate for the type and scope and to pro-vide us with proof of this upon request.
<G-vec00546-002-s436><carry.haben><de> 8.3 Sie haben eine nach Art und Umfang geeignete, dem neuesten Stand der Technik entsprechende Qualitätssicherung durchzuführen und uns diese nach Aufforderung nachzuweisen.
<G-vec00546-002-s475><carry.machen><en> These institutions, and the people who carry out their research in them, are at the visual and textual heart of this publication.
<G-vec00546-002-s475><carry.machen><de> Diese Wissenszentren und die Menschen, die an ihnen forschen, vorzustellen und auch visuell lebendig zu machen, ist das Ziel dieser umfassenden Publikation.
<G-vec00546-002-s476><carry.machen><en> The idea is to carry out genuine therapeutic research, with the horse blood being made compatible and having a protective effect.
<G-vec00546-002-s476><carry.machen><de> Dabei handelt es sich um ernsthafte therapeutische Forschung mit dem Ziel, das Pferdeblut für den Menschen verträglich und zu medizinischen Zwecken nutzbar zu machen.
<G-vec00546-002-s477><carry.machen><en> We carry out simple programming exercises using Scratch, a graphical user interface developed specifically to help young people get started in programming.
<G-vec00546-002-s477><carry.machen><de> Wir machen erste Programmierübungen mit Scratch, einer grafischen Oberfläche, die speziell für den Einstieg Jugendlicher in die Programmierung entwickelt wurde.
<G-vec00546-002-s478><carry.machen><en> With our help. the production company was able to carry out an efficient and praiseworthy job.
<G-vec00546-002-s478><carry.machen><de> Dank unserer Hilfe war die Produktionsfirma in der Lage einen effizienten und guten Job zu machen.
<G-vec00546-002-s479><carry.machen><en> We will gladly carry out a preliminary analysis, create a forcast of energy savings and profits and organis a visit to one of our customers – all this with no obligation for you whatsoever.
<G-vec00546-002-s479><carry.machen><de> Gerne machen wir für Sie eine Voranalyse, erstellen eine Einsparprognose mit Gewinnvorteilen und organisieren Referenzbesuche bei Kunden – und das Ganze für Sie unverbindlich.
<G-vec00546-002-s480><carry.machen><en> After all almost 10,000 visitors during the first year and positive response by the musicians encourage me to carry on this way.
<G-vec00546-002-s480><carry.machen><de> Immerhin fast 10.000 Besucher gleich im ersten Jahr und die positive Resonanz von den fotografierten Musikern bestärken mich darin, weiter zu machen.
<G-vec00546-002-s481><carry.machen><en> No matter how many times they fall, they get up again and carry on, an attitude that is also valuable for everyday life.
<G-vec00546-002-s481><carry.machen><de> Ganz gleich, wie oft sie hinfliegen – sie stehen wieder auf und machen weiter, eine Haltung, die auch für den Alltag wertvoll ist.
<G-vec00546-002-s482><carry.machen><en> 20:25 So Jehoshaphat and his men went to carry off their plunder, and they found among them a great amount of equipment and clothing and also articles of value-more than they could take away.
<G-vec00546-002-s482><carry.machen><de> 20:25 Und Josaphat kam mit seinem Volk, um unter ihnen Beute zu machen, und sie fanden dort eine Menge Fahrhabe und Kleider und kostbare Geräte, und sie raubten so viel, daß sie es nicht tragen konnten.
<G-vec00546-002-s483><carry.machen><en> Whether you're a developer that needs to carry out tests or a user interested in having Android applications on Windows, Andy is the ideal option.
<G-vec00546-002-s483><carry.machen><de> Andy ist eine ideale Option für Entwickler, die Proben machen müssen, aber auch für normale Anwender, die Android-Apps auf Windows haben möchten.
<G-vec00546-002-s484><carry.machen><en> On the basis of these inquiries – which were, as I told, very intensive – our opinion is that we carry out these projects in accordance with the applicable law.
<G-vec00546-002-s484><carry.machen><de> Wir sind der Auffassung auf der Basis dieser Erkundungen, die wie gesagt sehr intensiv waren, dass wir nach anwendbarem Recht hier zulässig diese Projekte auch machen.
<G-vec00546-002-s485><carry.machen><en> Download QuickBooks Simple Start free, it will allow you to carry out book keeping for small companies.
<G-vec00546-002-s485><carry.machen><de> Downloaden Sie QuickBooks Simple Start gratis, um die Buchhaltung von kleinen Unternehmen zu machen.
<G-vec00546-002-s486><carry.machen><en> Media Central's editorial video productions will support and carry the respective independent voices of its publications to millions of new digital Canadian viewers.
<G-vec00546-002-s486><carry.machen><de> Die redaktionellen Videoproduktionen von MediaCentral werden die jeweiligen unabhängigen Stimmen seiner Publikationen stärken und Millionen neuer kanadischer Nutzer von digitalen Medien zugänglich machen.
<G-vec00546-002-s487><carry.machen><en> 11.8 The Seller shall be entitled to carry out the supplementary performance owed dependent on the Buyer paying the purchase price due.
<G-vec00546-002-s487><carry.machen><de> 11.8 Der Verkäufer ist berechtigt, die geschuldete Nacherfüllung davon abhängig zu machen, dass der Käufer den fälligen Kaufpreis bezahlt.
<G-vec00546-002-s488><carry.machen><en> After receiving the assignment, we carry out a site survey to verify the proposed building specifications and submit a proposal for implementation.
<G-vec00546-002-s488><carry.machen><de> Nach Erhalt des Auftrags machen wir einen Site Survey, um die bauseitigen Vorgaben zu prüfen und schlagen eine Umsetzungslösung vor.
<G-vec00546-002-s489><carry.machen><en> • This diet is very easy to carry and gives fast results and safe.
<G-vec00546-002-s489><carry.machen><de> • Diese Diät ist sehr leicht zu machen und bietet schnelle und sichere Ergebnisse.
<G-vec00546-002-s490><carry.machen><en> I want to use this medium to plead with you pastors; if you want to carry out any event in your church, whatever they bring for the ceremony, ensure you give yourself time to pray over it.
<G-vec00546-002-s490><carry.machen><de> Ich will diesen Weg benutzen, um Sie inständig zu bitten, Pastoren; wenn Sie eine Zeremonie oder einen Konvent in Ihrer Kirche machen wollen, egal, was sie für die Zeremonie bringen, stellen Sie sicher, dass Sie Ihre Zeit nehmen, um darauf zu beten.
<G-vec00546-002-s491><carry.machen><en> Performance and fashion standard at the highest level: thanks to innovative, water-repellent materials, the padded ski pants remain pleasantly soft and elastic and carry along all movement sequences.
<G-vec00546-002-s491><carry.machen><de> Performance- und Fashion-Standard auf höchstem Niveau: Durch innovative, wasserabweisende Materialien bleiben die wattierten Skihosen angenehm weich sowie elastisch und machen alle Bewegungsabläufe mit.
<G-vec00546-002-s492><carry.machen><en> We can arrange to collect your bike and carry out the required service for you.
<G-vec00546-002-s492><carry.machen><de> Nach Vereinbahrung holen wir dein Bike ab und machen den nötigen Service.
<G-vec00546-002-s493><carry.machen><en> Satan's agents put in all their efforts to carry out abominable practices on the food that we consume.
<G-vec00546-002-s493><carry.machen><de> Die Diener satans machen alles Mögliche, um auf die Lebensmitteln, die wir verbrauchen, abscheuliche Praktiken zu machen.
<G-vec00011-002-s532><carry.mitnehmen><en> Purchase of an additional ticket allows you to carry an additional 1 piece from the aforementioned sports equipment.
<G-vec00011-002-s532><carry.mitnehmen><de> Mit dem Kauf eines zusätzlichen Tickets können Sie zusätzlich 1 Stück aus dem oben genannten Sportgerät mitnehmen.
<G-vec00011-002-s533><carry.mitnehmen><en> Shade may be scarce on sunny days, in which case you should either wear a hat or carry an umbrella.
<G-vec00011-002-s533><carry.mitnehmen><de> An sonnigen Tagen kann wenig Schatten geben und in dem Fall solltest du entweder einen Hut tragen oder einen Sonnenschirm mitnehmen.
<G-vec00011-002-s534><carry.mitnehmen><en> So, for example, if you have laptops that your employees carry out of your office, this doesn’t mean these laptops are outside of your scope – they should be included in your scope if through these laptops the employees can access your local network and all the sensitive information and services located there.
<G-vec00011-002-s534><carry.mitnehmen><de> Wenn Sie daher Laptops haben, die Ihre Mitarbeiter aus dem Büro mitnehmen, bedeutet das nicht, dass diese Laptops außerhalb Ihres Anwendungsbereichs sind – sie sollten in Ihren Anwendungsbereich miteinbezogen werden, wenn Ihre Mitarbeiter über diese Laptops auf Ihr lokales Netzwerk und alle darin vorhandenen sensiblen Daten und Services Zugriff haben.
<G-vec00011-002-s535><carry.mitnehmen><en> Automotive stocks were able to carry over their momentum from the previous year at the beginning of 2018, but this changed in early February in the wake of price corrections on the German stock market. The Daimler share was significantly impacted by this development.
<G-vec00011-002-s535><carry.mitnehmen><de> Nachdem die Automobilwerte den Schwung aus dem vergangenen Jahr zu Jahresbeginn noch mitnehmen konnten, begann ab Anfang Februar eine Preiskorrektur am deutschen Aktienmarkt, von der auch die Daimler-Aktie signifikant betroffen war.
<G-vec00011-002-s536><carry.mitnehmen><en> It has only one ferry Express Skopelitis that can carry 340 passengers and a limited number of vehicles.
<G-vec00011-002-s536><carry.mitnehmen><de> Sie hat nur eine Expressfähre, „Skopelitis“, die mehr als 340 Passagiere und eine limitierte Anzahl an Fahrzeugen mitnehmen kann.
<G-vec00011-002-s537><carry.mitnehmen><en> Designed to keep all organized and big enough to carry your everyday essentials, laptop and more if you're out for the night.
<G-vec00011-002-s537><carry.mitnehmen><de> Entwickelt um Ordnung zu gewährleisten und groß genug, um alles was Sie täglich brauchen mitnehmen zu können, Laptops und vieles mehr, auch wenn Sie eine Nacht wegbleiben.
<G-vec00011-002-s538><carry.mitnehmen><en> Description A spacious and trendy tote bag to help you carry around everything that matters.
<G-vec00011-002-s538><carry.mitnehmen><de> Beschreibung Eine geräumige und trendige Einkaufstasche, mit der Du alles Wichtige mitnehmen kannst.
<G-vec00011-002-s539><carry.mitnehmen><en> High gloss casing, classic and compact Design: The DigitRadio 220 combines the best DAB+ and VHF radio reception in a beautifully designed digital radio which is easy to carry on its metal handle.
<G-vec00011-002-s539><carry.mitnehmen><de> Klassische Bauform, Hochglanzgehäuse, kompaktes Design: Das DIGITRADIO 220 packt besten DAB+ und UKW-Radioempfang in ein schickes Radiogerät, das sich mit dem schwenkbaren Metallgriff auch spontan mitnehmen lässt.
<G-vec00011-002-s540><carry.mitnehmen><en> GHD Styler Carry Case and Heat Mat Now you never need to be parted from your ghd IV styler you can carry it everywhere.
<G-vec00011-002-s540><carry.mitnehmen><de> GHD Styler Carry Case & Heat Mat Jetzt müssen Sie nie von Ihrem ghd IV Styler getrennt werden, kann man überallhin mitnehmen.
<G-vec00011-002-s541><carry.mitnehmen><en> Learned Lewko said uneasily, “I don't think we can carry it out with us now.
<G-vec00011-002-s541><carry.mitnehmen><de> Der Gelehrte Lewko stellte unbehaglich fest: »Ich glaube nicht, dass wir ihn jetzt mitnehmen können.
<G-vec00011-002-s542><carry.mitnehmen><en> Dried fruit has one major advantage, especially when you are on the go: it’s not only easy to carry, it’s also easy to eat – you don’t need to bring a knife to peel or chop up the fruit into small pieces.
<G-vec00011-002-s542><carry.mitnehmen><de> Getrocknetes Obst hat gerade unterwegs einen großen Vorteil: Es lässt sich nicht nur leicht mitnehmen, sondern auch direkt snacken, ohne dass ein Messer zum Schälen oder Kleinschneiden benötigt wird.
<G-vec00011-002-s543><carry.mitnehmen><en> If you enjoy shooting in places far from your home, you will probably need to carry a gun (and ammunition) on an airplane to get to your destination.
<G-vec00011-002-s543><carry.mitnehmen><de> Wenn du gerne an Orten schießt, die weit von zuhause weg sind, musst du wahrscheinlich eine Waffe (und Munition) in ein Flugzeug mitnehmen, um an dein Ziel zu gelangen.
<G-vec00011-002-s544><carry.mitnehmen><en> This all-in-one case has a slim and light design that makes it easy to use and carry around, all whilst keeping your iPad safe from bumps, scratches and spills.
<G-vec00011-002-s544><carry.mitnehmen><de> Dieses multifunktionale Case kommt in einem dünnen und leichten Design, das du einfach nutzen und mitnehmen kannst, und schützt dabei dein iPad vor Stößen, Kratzern und Flüssigkeiten.
<G-vec00011-002-s545><carry.mitnehmen><en> Travel pouch: VisaPure Advanced facial cleansing brush comes with a travel pouch so you can carry it conveniently when you are travelling.
<G-vec00011-002-s545><carry.mitnehmen><de> Reisetasche: VisaPure Advanced wird mit einer Reisetasche geliefert, die Sie auf Reisen bequem mitnehmen können.
<G-vec00011-002-s546><carry.mitnehmen><en> You’ll receive your ShadowProtect IT Edition preloaded onto a USB key so that you can easily carry it with you whenever you need to back up or restore a machine or, with our PRO version, recover Microsoft Exchange data.
<G-vec00011-002-s546><carry.mitnehmen><de> Sie erhalten ShadowProtect IT-Edition vorinstalliert auf einem USB-Stick, sodass Sie sie einfach mitnehmen können, wenn Sie einen Computer sichern oder wiederherstellen müssen, oder mit unserer PRO-Version Daten aus Microsoft Exchange wiederherstellen müssen.
<G-vec00011-002-s547><carry.mitnehmen><en> According to rules implemented by the German Federal Aviation Office LBA together with the German transport ministry, certified private pilots are allowed to carry passengers for money but only for the amount they would have to pay themselves for the flight.
<G-vec00011-002-s547><carry.mitnehmen><de> Das Luftfahrtbundesamt und auch das übergeordnete Bundesverkehrsministerium hatten schon zuvor betont, dass Privatpiloten Passagiere auch gegen Geld mitnehmen dürfen - zum Selbstkostenpreis.
<G-vec00011-002-s548><carry.mitnehmen><en> Additionally, you can also carry with you one hand baggage or one laptop / tablet without any charge.
<G-vec00011-002-s548><carry.mitnehmen><de> Zusätzlich zum Handgepäck ist das kostenlose Mitnehmen einer Handtasche oder ein Laptop/ Tablet erlaubt.
<G-vec00011-002-s549><carry.mitnehmen><en> With its integrated GPS function, it allows you to track your progress in real time, without the need to carry your mobile phone with you.
<G-vec00011-002-s549><carry.mitnehmen><de> Durch die integrierte GPS-Funktion können Sie Ihre Route in Echtzeit verfolgen, ohne Ihr Handy unbedingt mitnehmen zu müssen.
<G-vec00011-002-s550><carry.mitnehmen><en> SIGG Hot & Cold Mugs are the ideal accessory for anyone who would like to carry tea or coffee 'to go' every day without any leaking or spillage.
<G-vec00011-002-s550><carry.mitnehmen><de> Die SIGG Hot & Cold Flasche ist das ideale Zubehör für alle, die im täglichen Gebrauch Tee und Kaffee „to go“ mitnehmen möchten.
<G-vec00011-002-s665><carry.tragen><en> I carry you.
<G-vec00011-002-s665><carry.tragen><de> Ich trage euch.
<G-vec00011-002-s666><carry.tragen><en> Always carry a valid ID-card with you.
<G-vec00011-002-s666><carry.tragen><de> Trage immer eine Art der Identifikation bei Dir.
<G-vec00011-002-s667><carry.tragen><en> [GGJ 4.165.12] But who is or want to be a true messenger of heaven, should not carry a stick, nor any other weapon, he should also not carry a bag with him to put something into it; since I Myself will awaken friends for him, and they will to him what he needs as a person of flesh and blood.
<G-vec00011-002-s667><carry.tragen><de> [GEJ 4.165.12] Wer da aber ein rechter Himmelsbote ist oder sein will, der trage keinen Stock, noch irgendeine andere Waffe, auch habe er keinen Sack bei sich, um etwas einzustecken; denn Ich Selbst werde ihm schon Freunde erwecken, und diese werden ihm geben, dessen er als Fleisch- und Blutmensch benötigt.
<G-vec00011-002-s668><carry.tragen><en> Do not carry more cash you need and leave your valuables to the hotel, because there are many pickpocketing thieves and scammers in the area.
<G-vec00011-002-s668><carry.tragen><de> Trage einfach das Geld das du brauchst bei dir, und lass deine Wertsachen im Hotel, weil es viele Taschendiebe und Betrüger in der Gegend gibt.
<G-vec00011-002-s669><carry.tragen><en> 1 Carry your Green Card with you at all times.
<G-vec00011-002-s669><carry.tragen><de> 1 Trage deine Green Card jederzeit bei dir.
<G-vec00011-002-s670><carry.tragen><en> And as this blog is like the heart that I carry on my tongue here are my very own five personal blog posts over the five past years.
<G-vec00011-002-s670><carry.tragen><de> Und weil ich in diesem Blog immer mein Herz auf der Zunge trage sind hier meine 5 persönlichsten Posts der letzten 5 Jahre.
<G-vec00011-002-s671><carry.tragen><en> 20:40 Then Jonathan gave his weapons to the boy and said, "Go, carry them back to town." <
<G-vec00011-002-s671><carry.tragen><de> 20:40 Da gab Jonatan seine Waffen dem Knaben, den er bei sich hatte, und sprach zu ihm: Geh und trage sie in die Stadt.
<G-vec00011-002-s672><carry.tragen><en> Right now I carry, in my view, the 10 greatest skateboards for daily use.
<G-vec00011-002-s672><carry.tragen><de> Im Moment trage ich, meiner Meinung nach, die 10 größten Skateboard für den täglichen Gebrauch.
<G-vec00011-002-s673><carry.tragen><en> Carry her books and backpack for her between classes or after school.
<G-vec00011-002-s673><carry.tragen><de> Trage zwischen den Schulstunden oder nach der Schule ihre Bücher und ihren Rucksack für sie.
<G-vec00011-002-s674><carry.tragen><en> Due to these diverse, deep-rooted life experiences, I emotionally carry a very wide and intensive range of facets that I can and want to express authentically in my roles as an actor.
<G-vec00011-002-s674><carry.tragen><de> Aufgrund dieser vielseitigen, tiefsitzenden Lebenserfahrungen trage ich emotional eine sehr große und intensive Bandbreite an Facetten in mir, die ich in meinen Rollen als Schauspieler authentisch zum Ausdruck bringen kann und will.
<G-vec00011-002-s675><carry.tragen><en> Carry a lucky symbol with you.
<G-vec00011-002-s675><carry.tragen><de> Trage ein Glückssymbol bei dir.
<G-vec00011-002-s676><carry.tragen><en> 32As they were marching forth, they came upon a man of Cyrene named Simon; this man they forced to carry the cross of Jesus.
<G-vec00011-002-s676><carry.tragen><de> Als sie aber herauskamen, fanden sie einen Menschen, einen Kyrenäer namens Simon, den zwangen sie, dass er sein Kreuz trage.
<G-vec00011-002-s677><carry.tragen><en> To Love i carry your heart with me (i carry it in
<G-vec00011-002-s677><carry.tragen><de> Ich trage Dein Herz bei mir, ich trage es in meinem Herzen.
<G-vec00011-002-s679><carry.tragen><en> The earth burden has been taken from me but one burden I still carry with me, that I have not grasped the miracle of divine love in time – that I searched, brooded and doubted where I had to feel God’s love – that I have not proved myself and accepted the gift of favour with a heart full of thanks.
<G-vec00011-002-s679><carry.tragen><de> Die Erdenlast ist von mir genommen, doch eine Last trage ich gleichfort mit mir, daß ich nicht rechtzeitig erfaßt habe das Wunder göttlicher Liebe - daß ich forschte, grübelte und zweifelte, wo ich die Liebe Gottes spüren musste - daß ich mich nicht bewährt habe und das Gnadengeschenk annahm mit dankerfülltem Herzen.
<G-vec00011-002-s680><carry.tragen><en> I carry size 7 in this ring.
<G-vec00011-002-s680><carry.tragen><de> Ich trage Größe 7 in diesem Ring.
<G-vec00011-002-s681><carry.tragen><en> Do not carry much money around in your handbag and take only a copy of your passport with you.
<G-vec00011-002-s681><carry.tragen><de> Trage nicht viel Bargeld mit dir herum, und behalte nur eine Kopie deines Ausweises in deiner Tasche.
<G-vec00011-002-s682><carry.tragen><en> I know the risks and hazards during my volunteer work and carry full responsibility for it.
<G-vec00011-002-s682><carry.tragen><de> Ich kenne die Risiken und Gefahren während meines freiwilligen Einsatzes und trage alleinige Verantwortung dafür.
<G-vec00011-002-s683><carry.tragen><en> I catch Charlot in my hands and carry him back into the garden.
<G-vec00011-002-s683><carry.tragen><de> Den schnappe ich mir mit der bloßen Hand und trage ihn zurück in den Garten.
<G-vec00011-002-s684><carry.tragen><en> X-rays are also photons, but carry less energy than gammas.
<G-vec00011-002-s684><carry.tragen><de> Röntgenstrahlen werden auch Photonen, aber tragen weniger Energie als Gammas.
<G-vec00011-002-s685><carry.tragen><en> Now it can carry a candle or some sweets.
<G-vec00011-002-s685><carry.tragen><de> Das Deckelchen soll eine Kerze oder auch ein paar Pralinen tragen.
<G-vec00011-002-s686><carry.tragen><en> This crime is of deep concern to us all, because these girls are also our children, for whom we all carry responsibility and whom we are obligated to protect and rescue through concerted international action.
<G-vec00011-002-s686><carry.tragen><de> Dieses Verbrechen geht uns alle an, denn diese Mädchen sind auch unsere Kinder, für die wir alle Verantwortung tragen und die wir gemeinsam behüten und retten müssen.
<G-vec00011-002-s687><carry.tragen><en> It is so small that you can carry it to any place where you want
<G-vec00011-002-s687><carry.tragen><de> Es ist so klein, dass Sie es an jeden Ort tragen können, wo Sie wollen.
<G-vec00011-002-s688><carry.tragen><en> I.e., man must want to be helped; he must feel his trouble and strive to get out of it; he must feel the spiritual state as inadequate and carry desire to remedy it, then the spiritual guides are ready and also entitled by God to assist him.
<G-vec00011-002-s688><carry.tragen><de> D.h., es muss der Mensch sich helfen lassen wollen, er muss seine Not empfinden und herauszukommen trachten, er muss also den Geisteszustand als mangelhaft empfinden und Verlangen tragen nach Hebung dessen, dann sind die geistigen Führer bereit und auch von Gott aus berechtigt, ihm beizustehen.
<G-vec00011-002-s689><carry.tragen><en> The traders who carry the label STEP commit themselves to provide good terms of employment and living conditions in the production plants of their handmade carpets.
<G-vec00011-002-s689><carry.tragen><de> Händler, die das Label STEP tragen, verpflichten sich, in den Produktionsstätten ihrer handgemachten Teppiche für gute Arbeits- und Lebensbedingungen zu sorgen.
<G-vec00011-002-s690><carry.tragen><en> Jesus will not only save you, He will "carry" you when you feel you can't go on.
<G-vec00011-002-s690><carry.tragen><de> Jesus wird dich nicht nur retten, er wird dich sogar tragen, wenn du nicht mehr weiter kannst.
<G-vec00011-002-s691><carry.tragen><en> Beyond this period we have no obligation to carry replacement parts that are no longer in production, since a product was discontinued.
<G-vec00011-002-s691><carry.tragen><de> Über diesen Zeitraum hinaus haben wir keine Verpflichtung, Ersatzteile zu tragen, die nicht mehr in Produktion sind, da ein Produkt abgebrochen wurde.
<G-vec00011-002-s692><carry.tragen><en> Nini Stool & Side Table by Schönbuch Isolated product image of the Nini stool & side table by Schönbuch: The four solid wooden legs carry the sitting surface without any problems, so it is very resilient.
<G-vec00011-002-s692><carry.tragen><de> Nini Hocker & Beistelltisch von Schönbuch Nini Hocker & Beistelltisch von Schönbuch: Die vier massiven Holzbeine tragen die rechteckige Sitzfläche ohne Probleme, sodass sie sehr belastbar ist.
<G-vec00011-002-s693><carry.tragen><en> Mini and lightweight design makes it easy to carry.
<G-vec00011-002-s693><carry.tragen><de> Mini und leichtes Design macht es einfach zu tragen.
<G-vec00011-002-s694><carry.tragen><en> If Good Friday is a day full of sorrow, it is therefore at the same time a particularly propitious day to reawaken our faith, to consolidate our hope and courage so that each one of us may carry our cross with humility, trust and abandonment in God, certain of his support and his victory.
<G-vec00011-002-s694><carry.tragen><de> Wenn der Karfreitag ein Tag voller Traurigkeit ist, so ist er dennoch gleichzeitig ein Tag, der sehr dazu geeignet ist, unseren Glauben neu zu wecken, unsere Hoffnung zu stärken sowie den Mut, unser Kreuz zu tragen in Demut, mit Vertrauen und Hingabe an Gott, während wir seiner Hilfe und seines Sieges gewiß sind.
<G-vec00011-002-s695><carry.tragen><en> Also, it is lightweight for convenient carry.
<G-vec00011-002-s695><carry.tragen><de> Außerdem ist es leicht für bequemes Tragen.
<G-vec00011-002-s696><carry.tragen><en> any purpose for which it was not intended, e.g. to carry the device, to hang up the device or to pull the mains plug out of the mains socket.
<G-vec00011-002-s696><carry.tragen><de> Tragen Sie das Elektrowerkzeug niemals an der Anschlussschnur, ziehen Sie es nicht damit heran und ziehen Sie den Stecker nicht an der Anschlussschnur aus der Steckdose.
<G-vec00011-002-s697><carry.tragen><en> Also that I should see the distractions as little crosses that I am asked to carry and when I accept to carry them they can become doorways of grace for me and for others.
<G-vec00011-002-s697><carry.tragen><de> Der Herr sagte auch, ich solle die Ablenkungen als kleine Kreuze sehen, die ich tragen soll, und wenn ich annehme, sie zu tragen, können sie für mich und für andere zu einem Einlass für Gnaden werden.
<G-vec00011-002-s699><carry.tragen><en> The consequence of this is that every product containing glyphosate in California must carry a warning label that it could cause cancer.
<G-vec00011-002-s699><carry.tragen><de> Die Konsequenz daraus ist, dass jedes Produkt, das Glyphosat enthält, in Kalifornien einen Warnhinweis tragen muss, dass es Krebs verursachen könnte.
<G-vec00011-002-s700><carry.tragen><en> The panoramic windows to the north and south create a transparent, open impression and carry a sunshade system that is unique in the world: The approximately 400,000 slats give the building a face that changes according to the incidence of sunlight.
<G-vec00011-002-s700><carry.tragen><de> Die gläsernen Panoramafronten nach Norden und Süden vermitteln einen offenen, transparenten Eindruck und tragen ein weltweit einzigartiges Sonnenschutzsystem: 400.000 Lamellen, alle um ihre vertikale Achse schwenkbar, ermöglichen stufenloses Ausrichten am Sonnenstand.
<G-vec00011-002-s701><carry.tragen><en> Last year we connected the 80 households to a water source 2 km away, and the inhabitants no longer need to carry the heavy pots on the long way.
<G-vec00011-002-s701><carry.tragen><de> Letztes Jahr haben wir die 80 Haushalte mit einer 2 Km entfernten Wasserquelle verbunden, und die Bewohner brauchen nicht mehr die schweren Töpfe auf dem langen Weg zu tragen.
<G-vec00011-002-s702><carry.tragen><en> The Week for Life has the aim "to pass on Jesus' invitation to all who are troubled and have to carry heavy burdens, to all that labour and are heavily laden".
<G-vec00011-002-s702><carry.tragen><de> Die Woche für das Leben habe das Ziel "Jesu Einladung weiterzugeben an alle, die sich plagen und schwere Lasten zu tragen haben, an alle Mühseligen und Beladenen".
<G-vec00011-002-s760><carry.tragen><en> Most people carry “healthy” BRCA variants – so their repair enzymes are in working order.
<G-vec00011-002-s760><carry.tragen><de> Die Mehrheit der Bevölkerung trägt «gesunde» BRCA-Genvarianten – ihre Reparaturenzyme sind funktionsfähig.
<G-vec00011-002-s761><carry.tragen><en> Delay guitars carry this atmospheric track.
<G-vec00011-002-s761><carry.tragen><de> Beschreibung: Ein Teppich aus Delay-Gitarren trägt diesen atmosphärischen Track.
<G-vec00011-002-s762><carry.tragen><en> 14:27 No one who does not carry his own cross and come after me can be a disciple of mine.
<G-vec00011-002-s762><carry.tragen><de> 14:27 Und wer nicht sein Kreuz trägt und mir nachfolget, der kann nicht mein Jünger sein.
<G-vec00011-002-s763><carry.tragen><en> In some cases, they swallow the bacteria and carry them around inside them; in others, the bacteria live on their outer casing.
<G-vec00011-002-s763><carry.tragen><de> In manchen Fällen frisst der Wurm die Bakterien und trägt sie im Innern, in anderen Fällen leben sie auf seiner Außenhaut.
<G-vec00011-002-s764><carry.tragen><en> Insiders therefore suppose that ADIDAS is going to carry the costs for the trial, direct or indirect.
<G-vec00011-002-s764><carry.tragen><de> Insider vermuten deshalb, dass ADIDAS die Kosten für den Prozess, sei es direkt oder indirekt, trägt.
<G-vec00011-002-s765><carry.tragen><en> All mothers have to develop a feeling for the best way to touch, carry and put down this delicate new person.
<G-vec00011-002-s765><carry.tragen><de> Jede Mutter muss erst ein Gefühl dafür entwickeln, wie man dieses zarte Wesen am besten anfasst, trägt und ablegt.
<G-vec00011-002-s766><carry.tragen><en> The common stingray can reach a diameter of about 2.5m and the tail spines carry a potent venom.
<G-vec00011-002-s766><carry.tragen><de> Der häufige Stechrochen kann einen Durchmesser von 2.5 m erreichen und der Schwanzstachel trägt ein starkes Gift.
<G-vec00011-002-s767><carry.tragen><en> Build me a boat that can carry two,
<G-vec00011-002-s767><carry.tragen><de> Bau mir ein Boot - das trägt uns zwei.
<G-vec00011-002-s768><carry.tragen><en> No doubt this may also take place after a peace, but that shows nothing more than that every war does not carry in itself the elements for a complete decision and final settlement.
<G-vec00011-002-s768><carry.tragen><de> Freilich kann dies auch nach dem Frieden geschehen, aber dies beweist weiter nichts, als daß nicht jeder Krieg eine vollkommene Entscheidung und Erledigung in sich trägt.
<G-vec00011-002-s769><carry.tragen><en> In that case one has to carry then two or more tanks instead of one to the water or has to trust the technology of a rebreather.
<G-vec00011-002-s769><carry.tragen><de> Man trägt dann nicht mehr eine, sondern zwei oder noch mehr Flaschen zum Wasser oder vertraut der Technik von Kreislaufgeräten.
<G-vec00011-002-s770><carry.tragen><en> He likes to carry his home all in one backpack and just moves as long as he finds a beautiful spot to set up. He is also like a donkey and carries all the heavy stuffs from his sweety.
<G-vec00011-002-s770><carry.tragen><de> Er trägt sein Haus sowie alle schweren Dinge von seinem Schatz auf dem Rücken bis er einen schönen Platz zum Campen findet.
<G-vec00011-002-s771><carry.tragen><en> The whole setup makes a lot of sense for its purpose, but it also makes for a different carry than backpacks (or running vests) that are more common.
<G-vec00011-002-s771><carry.tragen><de> Diese ganze Organisation macht für den geplanten Einsatzzweck eine Menge Sinn, aber sie bedeutet auch, dass sich der Fastpack 35 ziemlich anders trägt als ein Wanderrucksack (oder eine Laufweste).
<G-vec00011-002-s772><carry.tragen><en> And by the way, as if others did not like the fact that the doggies carry their toys in their teeth...
<G-vec00011-002-s772><carry.tragen><de> Und übrigens, als hätten andere nicht die Tatsache, dass der Hund sein Spielzeug in den Zähnen trägt...
<G-vec00011-002-s774><carry.tragen><en> If, in the worst case, we carry such a burden without resolution through life and take it with us across the threshold of death, then this burden appears in the following life on earth as a basic soul mood which has not been acquired in this life but which one “brings along” from before.
<G-vec00011-002-s774><carry.tragen><de> Trägt man eine solche Belastung schlimmstenfalls unverarbeitet, unaufgelöst durch sein Leben und nimmt sie mit über die Todesschwelle, so erscheint diese Belastung im folgenden Erdenleben als Seelengrundstimmung, die man nicht in diesem Leben erworben hat, sondern von vorneherein »mitbringt«.
<G-vec00011-002-s775><carry.tragen><en> If additional costs for Au Bouquet are connected with later orders/contract changes, the customer will carry these according to the then valid terms and conditions of the Blumen Au Bouquet AG.
<G-vec00011-002-s775><carry.tragen><de> Sind mit späteren Bestellungs-/Vertragsänderungen Zusatzkosten für Au Bouquet verbunden, trägt diese der Kunde gemäß den damals gültigen Ansätzen der Blumen Au Bouquet AG.
<G-vec00011-002-s776><carry.tragen><en> This transmission is managed with APECS, a strategy that provides an exceptionally smooth ride and allows power to carry through the shift points for excellent performance and speed on grades.
<G-vec00011-002-s776><carry.tragen><de> Dieses Getriebe wird von APECS gesteuert, einer Strategie, die für ein außerordentlich ruhiges Fahrverhalten sorgt und die Leistung auch über die Schaltpunkte hinweg trägt und damit eine hervorragende Leistung und Drehzahl auf Steigungen gewährleistet.
<G-vec00011-002-s777><carry.tragen><en> It is also very unusual that a dwarven warrior will carry an elven longbow...
<G-vec00011-002-s777><carry.tragen><de> Auch wäre es höchst unwahrscheinlich, dass ein Zwerg einen elfischen Langbogen trägt...
<G-vec00011-002-s778><carry.tragen><en> Each of the video monitors V1-Vn carry a camera C1-Cn which may variously facilitate dynamic motion images and still images.
<G-vec00011-002-s778><carry.tragen><de> Jeder der Videomonitore V1–Vn trägt eine Kamera C1–Cn, die in verschiedener Weise dynamisch bewegte Bilder sowie Festbilder erleichtern.
<G-vec00172-002-s361><carry.führen><en> Experts use a detailed checklist to carry out this inspection before shipment.
<G-vec00172-002-s361><carry.führen><de> Fachleute führen anhand einer ausführlichen Checkliste diese Kontrolle vor dem Versand durch.
<G-vec00172-002-s362><carry.führen><en> Since 2003 she has been authorized to carry the professional title of „Family Law Specialist”.
<G-vec00172-002-s362><carry.führen><de> Seit 2003 ist sie berechtigt, die Berufsbezeichnung „Fachanwältin für Familienrecht” zu führen.
<G-vec00172-002-s363><carry.führen><en> We carry all the food in the two trailers with us.
<G-vec00172-002-s363><carry.führen><de> Wir führen alle Nahrung in den beiden Anhängern mit uns.
<G-vec00172-002-s364><carry.führen><en> As part of our cooperation, we develop sport development concepts, carry out local sport development training sessions, and create manuals for sport development practitioners.
<G-vec00172-002-s364><carry.führen><de> Im Rahmen unserer Kooperation erarbeiten wir Sportentwicklungskonzepte, führen lokale Sportentwicklungstrainings durch und erstellen Handbücher für die Sportentwicklungspraxis.
<G-vec00172-002-s365><carry.führen><en> They produce electronic devices or installations, carry out gauging and testing, commissioning or maintenance.
<G-vec00172-002-s365><carry.führen><de> Sie fertigen elektronische Geräte oder Anlagen, führen Mess- und Prüfarbeiten, Inbetriebsetzungen oder Instandhaltungsarbeiten aus.
<G-vec00172-002-s366><carry.führen><en> We carry out our projects on our clients’ premises with expertise and passion.
<G-vec00172-002-s366><carry.führen><de> Wir führen unsere Projekte mit Expertise und Leidenschaft beim Kunden vor Ort durch.
<G-vec00172-002-s367><carry.führen><en> We carry out repairs and assembly for marine engines and offer advice and preparation for the ITB (Technical Inspection for Boats).
<G-vec00172-002-s367><carry.führen><de> Wir führen alle Arten von Reparaturen aus, montieren Schiffsmotoren und beraten und bereiten auf die ITB (technische Bootsprüfung) vor.
<G-vec00172-002-s368><carry.führen><en> We carry replacement glasses in 5 different sizes.
<G-vec00172-002-s368><carry.führen><de> Wir führen verschiedene Größen an Ersatzgläsern.
<G-vec00172-002-s369><carry.führen><en> — Comments US Air force B-52 bombers carry out airstrikes against Islamic State group, while Peshmerga troops advance on ground.
<G-vec00172-002-s369><carry.führen><de> Comments US-Luftwaffe B-52 Bombers führen Luftangriffe gegen die islamische Staatsgruppe, während Peshmerga-Truppen auf dem Boden vorankommen.
<G-vec00172-002-s370><carry.führen><en> Please carry out the installation.
<G-vec00172-002-s370><carry.führen><de> Führen Sie die Installation durch.
<G-vec00172-002-s371><carry.führen><en> These infected computers can later be used to carry out devastating cyber-attacks against public and private IT systems, as happened in Estonia in 2007 where most online public services, as well as government, parliament and police servers were made temporarily inoperative.
<G-vec00172-002-s371><carry.führen><de> Diese infizierten Computer können später benutzt werden, um vernichtende Cyberangriffe gegen öffentliche und private IT-Systeme zu führen - so geschehen in Estland im Jahre 2007, als die meisten öffentlichen Online-Dienste ebenso wie die Server der Regierung, des Parlaments und der Polizei vorübergehend außer Betrieb gesetzt wurden.
<G-vec00172-002-s372><carry.führen><en> There we are consciously invested in the currency and do not carry out any hedging.
<G-vec00172-002-s372><carry.führen><de> Dort sind wir bewusst in der Währung investiert und führen keine Absicherung durch.
<G-vec00172-002-s373><carry.führen><en> When the architect told the Prophet that there was no room for the oval windows he wanted, Joseph said, “I wish you to carry out my designs.
<G-vec00172-002-s373><carry.führen><de> Als der Architekt dem Propheten sagte, daß es für die von ihm gewünschten ovalen Fenster nicht genug Platz gäbe, antwortete Joseph: „Bitte führen Sie meine Pläne aus.
<G-vec00172-002-s374><carry.führen><en> We carry rentals for up to 20 people.
<G-vec00172-002-s374><carry.führen><de> Wir führen Ferienhäuser auf Mallorca für bis zu 12 Personen.
<G-vec00172-002-s375><carry.führen><en> Every year we carry out a thorough maintenance of the cleaning and filtering machines and there is a daily protocol of revision, disinfection and cleaning.
<G-vec00172-002-s375><carry.führen><de> Jedes Jahr führen wir eine gründliche Wartung der Reinigungs- und Filtermaschinen durch, und es gibt ein tägliches Protokoll der Revision, Desinfektion und Reinigung.
<G-vec00172-002-s376><carry.führen><en> The corporation Kyocera guarantees high quality – for this reason, we carry their assortment of toners, drums, developers and further print and copy supplies.
<G-vec00172-002-s376><carry.führen><de> Der Konzern Kyocera garantiert hohe Qualität – daher führen wir auch sein Sortiment an Tonern, Trommeln, Developers und sonstigem Druck- und Kopierzubehör.
<G-vec00172-002-s377><carry.führen><en> We carry out program reviews, every semester to ensure the quality of our lessons.
<G-vec00172-002-s377><carry.führen><de> Um die Qualität der Lehre zu gewährleisten, führen wir in jedem Semester studentische Veranstaltungskritiken durch.
<G-vec00172-002-s378><carry.führen><en> The Lawyer must carry out representation entrusted to him according to the law and must represent the rights and interests of the Client towards any party with diligence, loyalty and conscientiousness.
<G-vec00172-002-s378><carry.führen><de> Der Rechtsanwalt hat die ihm anvertraute Vertretung gemäß dem Gesetz zu führen und die Rechte und Interessen des Mandanten gegenüber jedermann mit Eifer, Treue und Gewissenhaftigkeit zu vertreten.
<G-vec00172-002-s379><carry.führen><en> We carry a wide variety of RC transmitters / Radios for every application.
<G-vec00172-002-s379><carry.führen><de> Wir führen eine Vielzahl von EDF Einheiten, Teile und Zubehör für EDF Einheiten.
