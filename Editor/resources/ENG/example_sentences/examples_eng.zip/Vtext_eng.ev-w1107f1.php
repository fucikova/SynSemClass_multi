<EnglishT-wsj_1619-s31#EnglishT-wsj_1619-s31-t2><ev-w1107f1.v-w7186f2> Time <start_vs>eluded<end_vs> Paramount by acquiring Warner Communications Inc<start_vauxs>.<end_vauxs> 
<EnglishT-wsj_2431-s16#EnglishT-wsj_2431-s16-t2><ev-w1107f1.v-w9104f1> But <start_vs>eluding<end_vs> parliamentary probe was the case of millions of drachmas Mr. Koskotas funneled into New Democracy coffers. 
