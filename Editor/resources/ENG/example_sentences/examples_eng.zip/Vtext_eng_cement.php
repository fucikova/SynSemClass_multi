<G-vec00539-002-s122><cement.festigen><en> A new international design project is set to cement Iceland’s position as the new creative centre of the world.
<G-vec00539-002-s122><cement.festigen><de> Mit diesem neuen internationalen Designprojekt soll die Stellung Islands als kreatives Zentrum der Welt gefestigt werden.
<G-vec00539-002-s123><cement.festigen><en> Trudeau hoped that the promotion of bilingualism would cement Quebec's place in confederation, and counter growing calls for an independent Quebec.
<G-vec00539-002-s123><cement.festigen><de> Trudeau hoffte, dass der Platz Québecs in der Konföderation so gefestigt werde und Rufen nach einer Unabhängigkeit dieser Provinz begegnet werden könnten.
<G-vec00539-002-s124><cement.festigen><en> This enabled us to cement our position as a major international supplier and the number three overall in the Chinese market.
<G-vec00539-002-s124><cement.festigen><de> Damit haben wir unsere Position als größter ausländischer Anbieter und Nummer drei im chinesischen Markt gefestigt.
<G-vec00539-002-s125><cement.festigen><en> Since Need for Speed No Limits’ launch in October 2015, we’ve seen the game evolve to cement its position as the premier mobile arcade racing game.
<G-vec00539-002-s125><cement.festigen><de> Seit seiner Veröffentlichung im Oktober 2015 hat Need for Speed No Limits seine Position als das führende Mobile-Arcade-Rennspiel immer weiter gefestigt.
