<G-vec00132-002-s024><complain.aussetzen><en> When my teacher for classical Japanese who has high standards and demands approves of my attempt of translating a sentence and has no complain of my wording.
<G-vec00132-002-s024><complain.aussetzen><de> Wenn meine Dozentin für klassisches Japanisch, die sehr hohe Ansprüche hat, einen von mir übersetzten Satz gut findet und an meiner Formulierung nichts auszusetzen hat.
<G-vec00132-002-s025><complain.aussetzen><en> All in all we had, and as we agreed, absolutely nothing to complain about.
<G-vec00132-002-s025><complain.aussetzen><de> Alles in allem hatten wir, und da waren wir uns einig, absolut nichts auszusetzen.
<G-vec00132-002-s026><complain.aussetzen><en> At their offer but there is nothing to complain about.
<G-vec00132-002-s026><complain.aussetzen><de> An ihrem Angebot gibt es aber nichts auszusetzen.
<G-vec00132-002-s027><complain.aussetzen><en> So far there's nothing to complain about.
<G-vec00132-002-s027><complain.aussetzen><de> Bisher gibt es nichts auszusetzen.
<G-vec00132-002-s028><complain.aussetzen><en> I have to say it was just great - nothing to complain about.
<G-vec00132-002-s028><complain.aussetzen><de> Ich muss sagen, es war einfach prima - nichts auszusetzen.
<G-vec00132-002-s029><complain.aussetzen><en> The leather is very sturdy and when it comes to the workmanship, there’s nothing to complain about.
<G-vec00132-002-s029><complain.aussetzen><de> Das Leder ist sehr stabil und an der Verarbeitung ist nichts auszusetzen.
<G-vec00132-002-s030><complain.aussetzen><en> The apartment is equipped with everything you need, there is nothing to complain about:-).
<G-vec00132-002-s030><complain.aussetzen><de> Die Wohnung ist mit allem ausgestattet was man braucht, es gibt nichts auszusetzen:-).
<G-vec00132-002-s031><complain.aussetzen><en> Especially “Face Everything and Rise”, “Skeletons”, “Fear Over Me” and “Fear Hate Love” are tracks that don ´t let one sit still and there is nothing to complain about them.
<G-vec00132-002-s031><complain.aussetzen><de> Besonders „Face Everything And Rise“, „Skeletons“, „War Over Me“ und „Fear Hate Love“ sind Stücke, die einen nicht still sitzen bleiben lassen und an denen es nichts auszusetzen gibt.
<G-vec00132-002-s032><complain.aussetzen><en> There is nothing to complain about regarding milk production (RZM 135, +1,362 kg milk, +0.11 % fat, -0.01 % protein) and the breeding values for the functional traits.
<G-vec00132-002-s032><complain.aussetzen><de> An der Milchleistung (RZM 135, +1.362 kg Milch, +0,11 % Fett, -0,01 % Eiweiß) und den Zuchtwerten für die funktionalen Merkmale gibt es nichts auszusetzen.
<G-vec00132-002-s033><complain.aussetzen><en> The had nothing to complain about in the elections, in which Assad won 85 percent approval.
<G-vec00132-002-s033><complain.aussetzen><de> Die hatten an den Wahlen, bei denen Assad 85 Prozent Zustimmung errang, nichts auszusetzen.
<G-vec00132-002-s034><complain.aussetzen><en> The cleanliness was absolutely nothing to complain about (unfortunately this was in our other holiday accommodation rarely / almost never as clean as here).
<G-vec00132-002-s034><complain.aussetzen><de> An der Sauberkeit war absolut gar nichts auszusetzen (leider war dies in unseren anderen Urlaubsunterkünften nur selten/fast nie so sauber, wie hier).
<G-vec00132-002-s035><complain.aussetzen><en> You agree with the gracious behavior and with the inner kindness towards you and have nothing to complain about.
<G-vec00132-002-s035><complain.aussetzen><de> Du bist mit dem liebenswürdige Verhalten und mit der inneren wohlwollenden Geneigtheit Dir gegenüber einverstanden und hast nichts auszusetzen.
<G-vec00132-002-s036><complain.beanstanden><en> We have nothing to complain about and would love to come back again.
<G-vec00132-002-s036><complain.beanstanden><de> Wir haben nichts zu beanstanden und würden gerne wieder kommen.
<G-vec00132-002-s037><complain.beanstanden><en> We spent 4 nights at home and nothing to complain about.
<G-vec00132-002-s037><complain.beanstanden><de> Wir verbrachten 4 Nächte zu Hause und nichts zu beanstanden.
<G-vec00132-002-s038><complain.beanstanden><en> About deposits, there is nothing to complain about the payment process of Roxy Palace Casino in the test.
<G-vec00132-002-s038><complain.beanstanden><de> Über Einzahlungen gibt es nichts zu beanstanden über den Zahlungsprozess des Roxy Palace Casinos im Test.
<G-vec00132-002-s039><complain.beanstanden><en> With the Rules the one or others will still change what with the last cup complain became.
<G-vec00132-002-s039><complain.beanstanden><de> Bei den Rules wird sich noch das ein oder andre ändern, was beim letzten Cup beanstanden wurde.
<G-vec00132-002-s040><complain.beanstanden><en> Friendly landlord, there was nothing to complain about.
<G-vec00132-002-s040><complain.beanstanden><de> Freundliche Vermieter, es gab nichts zu beanstanden.
<G-vec00132-002-s041><complain.beanstanden><en> Fazit: The ultra-X360S works fine, here is almost nothing to complain about, and anyone who wants to use his eSATA hard drive to play Xbox 360 Game Backups will truly not be disappointed.
<G-vec00132-002-s041><complain.beanstanden><de> Fazit: Der Wasabi360 Ultra X360S funktioniert einwandfrei, hier gibt es so gut wie nichts zu beanstanden, jeder der seine ESATA Festplatten zum laden von Xbox 360 Sicherheistkopien nutzen möchte wird mit diesem Produkt wahrlich nicht enttäuscht.
<G-vec00132-002-s042><complain.beanstanden><en> There was absolutely nothing to complain about.
<G-vec00132-002-s042><complain.beanstanden><de> Es gab absolut nichts zu beanstanden.
<G-vec00132-002-s043><complain.beanstanden><en> Never have anything to complain about as a long-term tenant.
<G-vec00132-002-s043><complain.beanstanden><de> Habe als Langzeitmieter noch nie etwas zu beanstanden.
<G-vec00132-002-s044><complain.beanstanden><en> There’s nothing to complain about in terms of performance: AMD's Radeon HD 6970M easily deals with most current games.
<G-vec00132-002-s044><complain.beanstanden><de> Bei der Leistung gibt es ebenfalls nichts zu beanstanden: AMDs Radeon HD 6970M stemmt aktuelle Titel meist ohne Probleme.
<G-vec00132-002-s045><complain.beanstanden><en> We have absolutely nothing to complain and can definitely recommend the place.
<G-vec00132-002-s045><complain.beanstanden><de> Wir haben absolut nichts zu beanstanden und das Hotel auf jeden Fall empfehlen.
<G-vec00132-002-s046><complain.beanstanden><en> Moreover, we require your email address in case we need to contact you should third parties complain that your comment is illegal.
<G-vec00132-002-s046><complain.beanstanden><de> Ihre E-Mail-Adresse benötigen wir darüber hinaus für den Fall, um mit Ihnen in Kontakt zu treten, falls Dritte Ihren Kommentar als rechtswidrig beanstanden sollten.
<G-vec00132-002-s047><complain.beanstanden><en> If there is anything at all to complain about, the pillows are a bit soft and you sink into them.
<G-vec00132-002-s047><complain.beanstanden><de> Wenn es überhaupt etwas zu beanstanden gibt, die Kissen sind ein bisschen zu weich und tauchen Sie in diese ein.
<G-vec00132-002-s048><complain.beanstanden><en> For the rest, nothing to complain.
<G-vec00132-002-s048><complain.beanstanden><de> Im übrigen nichts zu beanstanden.
<G-vec00132-002-s049><complain.beanstanden><en> Due to the fact that the panel uses IPS technology, that was to be expected, but there is truly nothing to complain about here.
<G-vec00132-002-s049><complain.beanstanden><de> Aufgrund der verwendeten IPS-Technologie war das zu erwarten, hier gibt es wirklich nichts zu beanstanden.
<G-vec00132-002-s050><complain.beanstanden><en> Absolutely nothing to complain about, we'd come back any time.
<G-vec00132-002-s050><complain.beanstanden><de> Absolut nichts zu beanstanden, wir würden jederzeit wiederkommen.
<G-vec00132-002-s051><complain.beanstanden><en> Laura and Angela were more than friendly and there was nothing to complain or worry about.
<G-vec00132-002-s051><complain.beanstanden><de> Laura und Angela waren mehr als freundlich und es gab nichts zu beanstanden oder zu befürchten.
<G-vec00132-002-s052><complain.beanstanden><en> We liked it very well and there is nothing to complain about.
<G-vec00132-002-s052><complain.beanstanden><de> Es hat uns sehr gut gefallen und es gibt nichts zu beanstanden.
<G-vec00132-002-s053><complain.beanstanden><en> The rooms were absolutely clean and there was nothing to complain about.
<G-vec00132-002-s053><complain.beanstanden><de> Die Zimmer waren absolut sauber und es gab nichts zu beanstanden.
<G-vec00132-002-s054><complain.beanstanden><en> There was nothing to complain about and we felt very comfortable.
<G-vec00132-002-s054><complain.beanstanden><de> Es gab nichts zu beanstanden und wir haben uns sehr wohl gefühlt.
<G-vec00132-002-s069><complain.beklagen><en> While some say that German companies are well prepared, others complain that the country will not wake up in time for digitalisation.
<G-vec00132-002-s069><complain.beklagen><de> Während die einen behaupten, deutsche Unternehmen seien gut gerüstet, beklagen andere, die Digitalisierung werde hierzulande komplett verschlafen.
<G-vec00132-002-s070><complain.beklagen><en> This abundance is not inspired, but rather annoying. Four out of five US decision-makers complain they get too much information, and on top of that it is useless and therefore, after a brief scan, lands right in the trash.
<G-vec00132-002-s070><complain.beklagen><de> Diese Fülle inspiriert nicht, sondern nervt: Vier von fünf US-Entscheidern beklagen, sie würden viel zu viele Informationsangebote bekommen, die obendrein unbrauchbar seien und deshalb, nach einem kurzen Scan, direkt im Papierkorb landen.
<G-vec00132-002-s071><complain.beklagen><en> As far as speed is concerned, the Panasonic Lumix FZ7 user has no reason to complain.
<G-vec00132-002-s071><complain.beklagen><de> In Bezug auf die Geschwindigkeit der Panasonic Lumix FZ7 wird sich der Benutzer nicht beklagen können.
<G-vec00132-002-s072><complain.beklagen><en> Citizens who complain about this failure and denounce the deplorable state of affairs are at best appointed as “scums”, at worst scolded as “Nazis”.
<G-vec00132-002-s072><complain.beklagen><de> Die Bürger, die das Versagen beklagen und die Missstände anprangern, werden bestenfalls als «Pack», schlimmstenfalls als «Nazi» beschimpft.
<G-vec00132-002-s073><complain.beklagen><en> And the noise is due to the fact that the Europeans, in particular the Germans – since in the meantime maudlin sentimentality has of course become the new German virtue – do nothing but complain about Europe, instead of taking pleasure and rejoicing in Europe.
<G-vec00132-002-s073><complain.beklagen><de> Und der Lärm entsteht deshalb, weil die Europäer, vor allem die Deutschen – weil Larmoyanz ja die neue deutsche Tugend geworden ist – sich über Europa nur noch beklagen, statt sich an Europa und über Europa zu freuen.
<G-vec00132-002-s074><complain.beklagen><en> Leon Frim: So, then my son started to complain that he had pain in the area of the kidneys.
<G-vec00132-002-s074><complain.beklagen><de> Leon Frim: Also damals hat sich mein Sohn angefangen schon zu beklagen, dass er Schmerzen in der Gegend von der Niere hat.
<G-vec00132-002-s075><complain.beklagen><en> Although we had been looking forward but at the ultra-modern facilities and the huge balcony we got instead we could complain on a cute little, typical Mallorcan apartment us in any case.
<G-vec00132-002-s075><complain.beklagen><de> Zwar hatten wir uns auf ein süßes, kleines, typisch mallorquinisches Apartment gefreut aber bei der ultramodernen Ausstattung und dem Riesen Balkon den wir stattdessen bekamen konnten wir uns auf keinen Fall beklagen.
<G-vec00132-002-s076><complain.beklagen><en> Citizens complain of an imbalance in terms of fairness: In one survey conducted by opinion and market research institution Institut für Demoskopie Allensbach this year, nearly 70 percent of respondents stated that economic conditions are unfair, and 64 percent believed the imbalance was going to increase.
<G-vec00132-002-s076><complain.beklagen><de> Die Bürger beklagen eine Gerechtigkeitslücke: In einer Umfrage des Instituts Demoskopie Allensbach von diesem Jahr gaben fast 70 Prozent der Befragten an, dass die wirtschaftlichen Verhältnisse ungerecht seien, und 64 Prozent waren der Ansicht, die Schieflage würde sich verstärken.
<G-vec00132-002-s077><complain.beklagen><en> When sacrificing a little more for the family, I often felt unbalanced and began to complain.
<G-vec00132-002-s077><complain.beklagen><de> Wenn ich für die Familie etwas mehr opferte, fühlte ich mich oft unausgeglichen und begann, mich zu beklagen.
<G-vec00132-002-s078><complain.beklagen><en> During pregnancy, the intensity of metabolic processes in the body increases, which leads, on the one hand, to excessive sweating, and on the other - to a decrease in the sensitivity of pregnant women to cold: they often complain that they are hot, less likely to freeze, which to some extent increases the probability of freezing .
<G-vec00132-002-s078><complain.beklagen><de> Während der Schwangerschaft nimmt die Intensität der Stoffwechselvorgänge im Körper zu, was einerseits zu übermäßigem Schwitzen und andererseits zu einer Abnahme der Kälteempfindlichkeit der Schwangeren führt: Sie beklagen oft, dass sie heiß sind, weniger gefrieren, was die Einfrierwahrscheinlichkeit erhöht .
<G-vec00132-002-s079><complain.beklagen><en> “Many women complain about the loss of volume, shape and stability of their breasts after pregnancy.
<G-vec00132-002-s079><complain.beklagen><de> „Viele Frauen beklagen nach einer Schwangerschaft den Verlust an Brustvolumen, Form und Stabilität.
<G-vec00132-002-s080><complain.beklagen><en> It is true, we will constantly direct our attention mainly to the spiritual well-being of the nation entrusted to us by God for leadership, but also in the natural respect no-one should have to complain about any pressing need, particularly if he is spiritually in good order.
<G-vec00132-002-s080><complain.beklagen><de> Zwar werden wir stets unsere Aufmerksamkeit hauptsächlich auf das geistige Wohl der uns von Gott zur Leitung anvertrauten Völker richten, aber auch in naturmäßiger Hinsicht soll sich niemand über irgendeine drückende Not zu beklagen haben, besonders, wenn er einmal geistig in der Ordnung ist.
<G-vec00132-002-s081><complain.beklagen><en> In actual fact, Karl Wehner, who is responsible for increasing the number of collaborations, can’t complain about having too little to do.
<G-vec00132-002-s081><complain.beklagen><de> Tatsächlich kann sich Karl Wehner, dessen Aufgabe der Ausbau der Kooperationen ist, nicht über zu wenig Arbeit beklagen.
<G-vec00132-002-s082><complain.beklagen><en> Companies frequently complain about the onerous and divergent documentation obligations with which they have to comply in such cases in the different Member States involved.
<G-vec00132-002-s082><complain.beklagen><de> Die Unternehmen beklagen häufig die kostenaufwendigen und unterschiedlichen Dokumentationspflichten, die sie in solchen Fällen in den einzelnen beteiligten Mitgliedstaaten erfüllen müssen.
<G-vec00132-002-s083><complain.beklagen><en> However, Geisel knows no qualms when it comes to Russia boycotts, a country that had to complain thanks to our “help” 27 million war dead.
<G-vec00132-002-s083><complain.beklagen><de> Allerdings kennt Geisel keine Skrupel, wenn es um Russland-Boykotte geht, einem Land, dass dank unserer „Hilfe“ 27 Millionen Kriegstote zu beklagen hatte.
<G-vec00132-002-s084><complain.beklagen><en> But countries with external borders, such as Greece and Italy, naturally complain that this puts an unfair burden on them.
<G-vec00132-002-s084><complain.beklagen><de> Aber Länder mit Außengrenzen wie Griechenland und Italien beklagen natürlich, dass dies eine unzumutbare Belastung für sie darstellt.
<G-vec00132-002-s085><complain.beklagen><en> We have complained enough that we are locked inside our own language; it is time to not just complain but to do something about it.
<G-vec00132-002-s085><complain.beklagen><de> Wir haben uns genug darüber beklagt, dass wir in unsere eigene Sprache eingesperrt sind, es ist an der Zeit, uns nicht mehr nur zu beklagen, sondern auch etwas zu tun.
<G-vec00132-002-s086><complain.beklagen><en> We’ve been cooperating for over 3 years now and I really can’t complain.
<G-vec00132-002-s086><complain.beklagen><de> Wir arbeiten seit über 3 Jahren zusammen und ich kann mich wirklich nicht beklagen.
<G-vec00132-002-s087><complain.beklagen><en> Critics complain that anything original loses its contents and form, since we live in an age where almost everything is possible so the impossible becomes possible.
<G-vec00132-002-s087><complain.beklagen><de> Kritiker beklagen, dass das Ursprüngliche seine Inhalte und Formen verliert, da wir in einer Zeit leben in der fast alles möglich ist und auch das Unmögliche möglich wird.
<G-vec00132-002-s088><complain.beklagen><en> Also, many complain about the lack of time for cooking individual, low-calorie meals (especially when the rest of the family dine with borscht and cutlets), as well as the banal lack of willpower to limit oneself in a chocolate bar at night.
<G-vec00132-002-s088><complain.beklagen><de> Außerdem beklagen sich viele über den Mangel an Zeit für das Kochen von individuellen, kalorienarmen Mahlzeiten (vor allem, wenn der Rest der Familie mit Borschtsch und Schnitzel diniert), sowie die banale Willensnot, sich in einer Schokoriegel in der Nacht zu beschränken.
<G-vec00132-002-s089><complain.beklagen><en> Many murmur and complain.
<G-vec00132-002-s089><complain.beklagen><de> Viele murren und beklagen sich.
<G-vec00132-002-s090><complain.beklagen><en> During the battle of Elli the Barbaros Hayreddin was damaged, had to complain 7 dead and 14 wounded and the Ottoman ships were forced to retreat to the Greek ships.
<G-vec00132-002-s090><complain.beklagen><de> Während des Gefechtes von Elli wurde die Barbaros Hayreddin beschädigt, hatte 7 Tote und 14 Verwundete zu beklagen und die osmanischen Schiffe mussten sich gegenüber den griechischen Schiffen zurückziehen.
<G-vec00132-002-s091><complain.beklagen><en> Aghast at the scenes of armored vehicles and cops pointing M-16 assault rifles at residents in the Ferguson war zone (where journalists have been among those treated like enemies, tear-gassed and arrested), liberals complain about “excessive” force.
<G-vec00132-002-s091><complain.beklagen><de> Liberale, bestürzt über Szenen von Panzerfahrzeugen und Bullen, die in der Kriegszone von Ferguson M-16-Sturmgewehre auf Bewohner richten (wo auch Journalisten wie Feinde behandelt, mit Tränengas beschossen und verhaftet werden), beklagen sich über „exzessive“ Gewalt.
<G-vec00132-002-s092><complain.beklagen><en> A "ban on spam" has been part of EU law since 2003, but 65% of Europeans still complain about "excessive spam".
<G-vec00132-002-s092><complain.beklagen><de> Ein „Spam-Verbot“ ist seit 2003 Bestandteil des EU-Rechts, aber 65 % der Europäer beklagen sich noch immer über zu viel unerwünschte Werbezusendungen.
<G-vec00132-002-s093><complain.beklagen><en> “Many companies complain about a shortage of IT specialists, engineers and high potentials.
<G-vec00132-002-s093><complain.beklagen><de> „Viele Unternehmen beklagen sich über einen Mangel an IT-Spezialisten, Ingenieuren und High Potentials.
<G-vec00132-002-s094><complain.beklagen><en> [People usually complain that music is so ambiguous; it is so problematic that they don't know what to think of it, but that words can each be understood.
<G-vec00132-002-s094><complain.beklagen><de> "Die Leute beklagen sich gewöhnlich, die Musik sei so vieldeutig; es sei so zweifelhaft, was sie sich dabei zu denken hätten, und die Worte verstände doch ein jeder.
<G-vec00132-002-s095><complain.beklagen><en> - Don't complain if he's late home for dinner or even if he stays out all night.
<G-vec00132-002-s095><complain.beklagen><de> Beklagen Sie sich nicht, wenn er spät heimkommt oder selbst wenn er die ganze Nacht ausbleibt.
<G-vec00132-002-s096><complain.beklagen><en> JF: Some organisers do complain about the increasing age of the audience in concert halls.
<G-vec00132-002-s096><complain.beklagen><de> JF: Einige Veranstalter beklagen sich, dass das Publikum in den Konzertsälen immer älter wird.
<G-vec00132-002-s097><complain.beklagen><en> Controllers who create Report Books on a regular basis (and that is the majority) complain that 80% of their time is taken up with assembling the figures and the components and producing the final layout.
<G-vec00132-002-s097><complain.beklagen><de> Die Controller, die revolvierend Report Books erstellen (und dies ist die überwiegende Anzahl), beklagen sich, dass ihre Arbeit zu 80% aus dem Zusammenbringen der Zahlen und der Komponenten und dem finalen Layout besteht.
<G-vec00132-002-s099><complain.beklagen><en> They complain of excessive sexual thoughts and impulses and enquire whether it will be an impediment in their spiritual path.
<G-vec00132-002-s099><complain.beklagen><de> Sie beklagen sich über exzessive sexuelle Gedanken und Impulse und wollen wissen, ob diese ein Hindernis für ihren spirituellen Weg wären.
<G-vec00132-002-s100><complain.beklagen><en> According to the Swiss bureau of statistics over 40% of Swiss workers complain that there are not enough sources of fresh, healthy food available at work.
<G-vec00132-002-s100><complain.beklagen><de> Gemäss Bundesamt für Statistik beklagen sich nämlich über 40% der Schweizer, dass es keine geeigneten Verpflegungsmöglichkeiten gibt am Arbeitsplatz.
<G-vec00132-002-s101><complain.beklagen><en> Like Küppers, educators and teachers across the country complain about the lack of support and understanding from political leaders.
<G-vec00132-002-s101><complain.beklagen><de> Wie Küppers beklagen sich bundesweit Pädagogen und Lehrer über mangelnde Unterstützung und Verständnis seitens der Politik.
<G-vec00132-002-s102><complain.beklagen><en> Situated in a shopping centre, the Confédération Centre, this bistro restaurant in Geneva cannot complain about a lack of visitors; its menu is therefore accordingly diverse.
<G-vec00132-002-s102><complain.beklagen><de> Untergebracht in einem Einkaufszentrum, dem Confédération Centre, kann sich das Bistro-Restaurant in Genf nicht über Besuchermangel beklagen; dementsprechend vielseitig präsentiert sich seine Speisekarte.
<G-vec00132-002-s103><complain.beklagen><en> But Ann didn’t complain.
<G-vec00132-002-s103><complain.beklagen><de> Aber Ann beklagte sich nicht.
<G-vec00132-002-s104><complain.beklagen><en> In those letters he would, e.g., complain about not being able to get his hands on scholarly journals (Bänninger 1941, Hs 931: 1679) and how the war in general made collecting more difficult for him (Bänninger 1944, Hs 931: 1788).
<G-vec00132-002-s104><complain.beklagen><de> In den Briefen aus jener Zeit beklagte sich Bänninger beispielsweise darüber, dass er bestimmte wissenschaftliche Zeitschriften nicht bekommen könne (Bänninger 1941, Hs 931: 1679) und dass ihm durch den Krieg das Sammeln allgemein schwergemacht werde (Bänninger 1944, Hs 931: 1788).
<G-vec00132-002-s320><complain.beklagen><en> This field is not the easiest in the insurance industry, therefore I cannot complain about any lack of tasks and challenges.
<G-vec00132-002-s320><complain.beklagen><de> Dieses Gebiet ist nicht das einfachste innerhalb der Versicherungsbranche, daher kann ich mich über einen Mangel an Aufgaben und Herausforderungen nicht beklagen.
<G-vec00132-002-s321><complain.beklagen><en> I can’t really complain about too many tourists, as I’m one of them.
<G-vec00132-002-s321><complain.beklagen><de> Ich kann mich nicht wirklich über zu viele Touristen beklagen, schließlich bin ich ja eine von ihnen.
<G-vec00132-002-s322><complain.beklagen><en> I used up a fair amount of my Polaroid films but I shouldn’t complain.
<G-vec00132-002-s322><complain.beklagen><de> Ich habe eine ganze Menge meiner Polaroid-Filme, aber ich sollte mich nicht beklagen.
<G-vec00132-002-s323><complain.beklagen><en> As a rider I try not to complain too much because at the end of the day a race is a race and it should be the same for everyone.
<G-vec00132-002-s323><complain.beklagen><de> Als Fahrer versuche ich, mich nicht allzu viel zu beklagen, denn schlussendlich ist es einfach ein Rennen, und es sollte für alle das gleiche sein.
<G-vec00132-002-s324><complain.beklagen><en> But as a Frenchman I can’t complain.
<G-vec00132-002-s324><complain.beklagen><de> Aber als Franzose kann ich mich nicht beklagen.
<G-vec00132-002-s384><complain.beklagen><en> 36 And they came to a place which was named Gethsemane, which was a garden; and the disciples began to be sore amazed, and to be very heavy, and to complain in their hearts, wondering if this be the Messiah.
<G-vec00132-002-s384><complain.beklagen><de> 36 Und sie kamen an einen Ort, der Getsemani genannt wurde und ein Garten war; und die Jünger fingen an, sehr bestürzt zu sein und sehr geängstigt zu sein und sich in ihrem Herzen zu beklagen und sich zu fragen, ob dies der Messias sei.
<G-vec00132-002-s385><complain.beklagen><en> So great an undertaking can not complain about the lack of interest in its products.
<G-vec00132-002-s385><complain.beklagen><de> Ein so großes Unternehmen kann sich nicht über ein mangelndes Interesse an seinen Produkten beklagen.
<G-vec00132-002-s386><complain.beklagen><en> (6) Like to complain about others without looking inward.
<G-vec00132-002-s386><complain.beklagen><de> (6) Sich über andere zu beklagen, ohne nach innen zu schauen.
<G-vec00132-002-s387><complain.beklagen><en> And TukTuk Factory has no reason to complain about a lack of demand.
<G-vec00132-002-s387><complain.beklagen><de> Und die TukTuk Factory kann sich über mangelnde Nachfrage nicht beklagen.
<G-vec00132-002-s388><complain.beklagen><en> Zedler and his team have no reason to complain about a lack of acknowledgement and awards.
<G-vec00132-002-s388><complain.beklagen><de> Über einen Mangel an Anerkennung und Auszeichnungen können Zedler und sein Team sich kaum beklagen.
<G-vec00132-002-s389><complain.beklagen><en> So Gerlinde can not complain about a lack of work.
<G-vec00132-002-s389><complain.beklagen><de> Über mangelnde Arbeit kann sich Gerlinde also nicht beklagen.
<G-vec00132-002-s390><complain.beklagen><en> He is clearly positioned in the business and therefore does not have to complain about a lack of jobs as a sideman.
<G-vec00132-002-s390><complain.beklagen><de> Er ist klar im Geschäft positioniert und muss sich daher nicht über fehlende Jobs als Sideman beklagen.
<G-vec00132-002-s391><complain.beklagen><en> The construction company founded in Dorsten/Germany in 1902 is today mainly active in multi-storey residential and industrial construction and can not complain about a lack of demand.
<G-vec00132-002-s391><complain.beklagen><de> Die 1902 in Dorsten gegründete Baufirma ist heute überwiegend im Geschosswohnungs- und Industriebau tätig und kann sich über mangelnde Nachfrage nicht beklagen.
<G-vec00132-002-s392><complain.beklagen><en> Many bloggers that complain about the new generation of influencers see themselves in the role of the old guard.
<G-vec00132-002-s392><complain.beklagen><de> Viele der Blogger, die sich über die neue Generation der Influencer beklagen, sehen sich selbst in der Rolle der alteingesessenen Hasen.
<G-vec00132-002-s393><complain.beklagen><en> Schooling is part of the reason many reasonable players complain that they are unable to beat loose games.
<G-vec00132-002-s393><complain.beklagen><de> Schooling ist teilweise der Grund für viele vernünftige Spieler sich zu beklagen, dass Sie unfähig sind Loose-Games (Spiele mit vielen Händen) zu schlagen.
<G-vec00132-002-s394><complain.beklagen><en> Regiobahn cannot complain about a lack of passengers.
<G-vec00132-002-s394><complain.beklagen><de> Über Fahrgastmangel kann sich die Regiobahn nicht beklagen.
<G-vec00132-002-s395><complain.beklagen><en> If anyone has a right to complain about the evil in the world, it is God.
<G-vec00132-002-s395><complain.beklagen><de> Wenn es jemanden gibt, der das Recht hat, sich über das Böse in der Welt zu beklagen, dann ist es Gott.
<G-vec00132-002-s396><complain.beklagen><en> Nor does the pianist have reason to complain of any lack of technical demands and soloistic brilliance.
<G-vec00132-002-s396><complain.beklagen><de> In den hier eingespielten Werken für Viola und Klavier kann sich auch der Pianist nicht über einen Mangel an technischen Anforderungen und solistischem Glanz beklagen.
<G-vec00132-002-s397><complain.beklagen><en> We are human beings, and humans love to complain.
<G-vec00132-002-s397><complain.beklagen><de> Wir sind Menschen, und Menschen lieben es, sich zu beklagen.
<G-vec00132-002-s398><complain.beklagen><en> One or two colleagues also went to the boss to complain about me.
<G-vec00132-002-s398><complain.beklagen><de> Es gingen auch ein oder zwei Kollegen zum Boss, um sich über mich zu beklagen.
<G-vec00132-002-s399><complain.beklagen><en> To complain about special Franco-German agreements – actual or feared - is irrelevant and can give rise to negative consequences.
<G-vec00132-002-s399><complain.beklagen><de> Sich über – bereits abgeschlossene oder befürchtete – deutsch-französische Sonderabkommen zu beklagen, ist nicht nur irreführend, sondern könnte auch negative Folgen haben.
<G-vec00132-002-s400><complain.beklagen><en> When clients complain about ‚restlessness‘ after a change in their social panorama, one should first check if new double representations have occurred.
<G-vec00132-002-s400><complain.beklagen><de> Wenn sich Klienten nach einer Verschiebung in ihrem Sozialen Panorama über eine „Unruhe“ beklagen, dann achte besonders darauf, ob doppelte Repräsentationen einer Person aufgetreten sind.
<G-vec00132-002-s401><complain.beklagen><en> After all, they will not complain and whine, on the contrary, they will try to entertain the interlocutor.
<G-vec00132-002-s401><complain.beklagen><de> Schließlich werden sie sich nicht beklagen und jammern, im Gegenteil, sie werden versuchen, den Gesprächspartner zu unterhalten.
<G-vec00132-002-s402><complain.beklagen><en> They are the same people who then complain, because the Lord - they say! - has abandoned them.
<G-vec00132-002-s402><complain.beklagen><de> Es sind dieselben, die sich dann beklagen, der Herrgott lasse sie im Stich.
<G-vec00132-002-s433><complain.beklagen><en> Of course it's not personal, so before I start apologies to you and all the other men and women that look after us and take it in the neck while we sit at home and complain.
<G-vec00132-002-s433><complain.beklagen><de> Natürlich ist es nicht persönlich, also bevor ich mit Entschuldigungen anfange an dich und all die anderen Männer und Frauen, die für uns sorgen und den Hintern hinhalten während wir daheim sitzen und uns beklagen.
<G-vec00132-002-s434><complain.beklagen><en> We have no reason to complain about the variety of species, nor about the number of birds, and years are not twin copies of each other.
<G-vec00132-002-s434><complain.beklagen><de> Wir haben keinen Grund, uns über die Vielfalt der Arten zu beklagen, noch über die Anzahl der Vögel, und die Jahre entsprechen auch nicht eines dem anderen.
<G-vec00132-002-s435><complain.beklagen><en> We can not really complain, top location, top top apartment and landlord.
<G-vec00132-002-s435><complain.beklagen><de> Wir können uns wirklich nicht beklagen, Top Lage, Top Wohnung und Top Vermieter.
<G-vec00132-002-s436><complain.beklagen><en> For we young people who often complain about the superficiality of people our age, here we can find all the answers and a sense of encouragement that exceeds all expectations.
<G-vec00132-002-s436><complain.beklagen><de> Wir Jugendliche, die wir uns oft über die Oberflächlichkeit unserer Altersgenossen beklagen, finden hier alle Antworten und man findet eine Ermutigung, die jede Erwartung übersteigt.
<G-vec00132-002-s105><complain.bemängeln><en> In terms of the graphics menu, there's nothing to complain about.
<G-vec00132-002-s105><complain.bemängeln><de> Beim Grafikmenü gibt es nichts zu bemängeln.
<G-vec00132-002-s106><complain.bemängeln><en> Otherwise, there's not much to complain about the M17x, except the extremely reflective display.
<G-vec00132-002-s106><complain.bemängeln><de> Ansonsten gibt es nur wenig am M17x zu bemängeln; uns hat lediglich die stark reflektierende Displayoberfläche gestört.
<G-vec00132-002-s107><complain.bemängeln><en> Obvious defects must be from the buyer within two weeks from delivery of the subject matter in writing to complain to the seller.
<G-vec00132-002-s107><complain.bemängeln><de> Offensichtliche Mängel sind von dem Käufer innerhalb von zwei Wochen ab Ablieferung des Vertragsgegenstandes schriftlich gegenüber dem Verkäufer zu bemängeln.
<G-vec00132-002-s108><complain.bemängeln><en> I have to complain directly to the beginning, unfortunately, because the reader learns nothing about Bree’s life as a human person.
<G-vec00132-002-s108><complain.bemängeln><de> Direkt den Anfang muss ich leider bemängeln, denn der Leser erfährt nichts über Brees Leben als menschliche Person.
<G-vec00132-002-s109><complain.bemängeln><en> The house is more than comfortable even for two families, in fact we were two couples with a child and one of the three large bedrooms has remained vuota.Insomma into our stay we had nothing to complain about, in fact thank the host halina for his kindness and availability, with the assurance that if you ever ricapiteremo in the area again in this beautiful penthouse, a bit secluded but still close to all amenities with a short drive.
<G-vec00132-002-s109><complain.bemängeln><de> Das Haus ist mehr als komfortabel, auch für zwei Familien, in der Tat waren wir zwei Paare mit einem Kind und einer der drei großen Schlafzimmern vuota.Insomma in unseren Aufenthalt geblieben hatten wir nichts zu bemängeln, in der Tat die Gastgeber halina für seine Güte danken und Verfügbarkeit, mit der Gewissheit, dass, wenn Sie jemals ricapiteremo wieder in der Gegend in diesem schönen Penthouse, ein bisschen abgelegen, aber immer noch nah an allen Annehmlichkeiten mit einer kurzen Fahrt.
<G-vec00132-002-s110><complain.bemängeln><en> So there is nothing to complain about.
<G-vec00132-002-s110><complain.bemängeln><de> Hier gibt es also nichts zu bemängeln.
<G-vec00132-002-s111><complain.bemängeln><en> We had nothing to complain about.
<G-vec00132-002-s111><complain.bemängeln><de> Wir hatten nichts zu bemängeln.
<G-vec00132-002-s112><complain.bemängeln><en> I really have nothing to complain about.
<G-vec00132-002-s112><complain.bemängeln><de> Ich habe wirklich nichts zu bemängeln.
<G-vec00132-002-s113><complain.bemängeln><en> To complain I have the bathroom, because there is no reasonable shower there.
<G-vec00132-002-s113><complain.bemängeln><de> Zu bemängeln habe ich das Bad, da es dort keine vernünftige Dusche gibt.
<G-vec00132-002-s114><complain.bemängeln><en> Certain songs will never be my favorites, but I had nothing to complain about this evening 😉 .
<G-vec00132-002-s114><complain.bemängeln><de> Gewisse Songs werden sicher auch nie meine Favoriten, aber ich hatte an diesem Abend nichts zu bemängeln 😉 .
<G-vec00132-002-s115><complain.bemängeln><en> End of November, 2013, Pinnacle Point is presented in good condition, the greens are a little slower than expected, but that's about all there is to complain about.
<G-vec00132-002-s115><complain.bemängeln><de> Ende Nov. 2013, Pinnacle Point präsentiert sich in gutem Zustand, die Grüns sind etwas langsamer als erwartet, das ist aber auch schon alles, was es zu bemängeln gibt.
<G-vec00132-002-s116><complain.bemängeln><en> Is nothing to complain about.
<G-vec00132-002-s116><complain.bemängeln><de> Nichts zu bemängeln.
<G-vec00132-002-s117><complain.bemängeln><en> Also in terms of cleanliness we have nothing to complain about.
<G-vec00132-002-s117><complain.bemängeln><de> Auch in Sachen Sauberkeit haben wir nichts zu bemängeln.
<G-vec00132-002-s118><complain.bemängeln><en> Also the price-performance ratio, there is nothing to complain about.
<G-vec00132-002-s118><complain.bemängeln><de> Auch am Preis-Leistungsverhältnis gibt es nichts zu bemängeln.
<G-vec00132-002-s119><complain.bemängeln><en> At the cleanliness there is nothing to complain about.
<G-vec00132-002-s119><complain.bemängeln><de> An der Sauberkeit gibt es nichts zu bemängeln.
<G-vec00132-002-s120><complain.bemängeln><en> The only thing we have to complain about is that there is no pharmacy for this you had to drive to the neighboring village.
<G-vec00132-002-s120><complain.bemängeln><de> Das Einzige was wir zu bemängeln haben ist, dass es keine Apotheke gibt dafür musste man in den Nachbarort fahren.
<G-vec00132-002-s121><complain.bemängeln><en> There is absolutely nothing to complain about.
<G-vec00132-002-s121><complain.bemängeln><de> Es gibt aber auch gar nichts zu bemängeln.
<G-vec00132-002-s122><complain.bemängeln><en> Green indicates that the server is online and there is nothing to complain about.
<G-vec00132-002-s122><complain.bemängeln><de> Grün zeigt an das der Server online ist und es nichts zu bemängeln gibt.
<G-vec00132-002-s123><complain.bemängeln><en> Before that one could have warned us calmly. So we Umag did not have a good memory. What I also have to complain about are the inflated prices in the restaurants rather cheap pubs.
<G-vec00132-002-s123><complain.bemängeln><de> Davor hätte man uns ruhig warnen können.So blieb uns Umag in keiner guten Erinnerung .Was ich auch bemängeln muss sind die überhöhten Preise in den Gaststätten die eher an billig Kneipen erinnern.
<G-vec00132-002-s182><complain.beschweren><en> Whenever I get cramps, I complain.
<G-vec00132-002-s182><complain.beschweren><de> Wann immer ich Krämpfe kriege, beschwere ich mich.
<G-vec00132-002-s183><complain.beschweren><en> I do not complain about the behavior of friends and colleagues, but accept that they act differently and react as I do.
<G-vec00132-002-s183><complain.beschweren><de> Ich beschwere mich nicht über das Verhalten von Freunden und Kollegen, sondern akzeptiere, dass sie anders handeln und reagieren als ich.
<G-vec00132-002-s184><complain.beschweren><en> "Though I don't complain: I have chosen this way.
<G-vec00132-002-s184><complain.beschweren><de> "Aber ich beschwere mich nicht: Ich habe diesen Weg gewählt.
<G-vec00132-002-s185><complain.beschweren><en> And yes there are times when I hate you but I don't complain 'Cause I've been afraid that you would walk away
<G-vec00132-002-s185><complain.beschweren><de> Und ja, es gibt Zeiten in denen ich dich hasse, aber ich beschwere mich nicht, weil ich Angst habe, dass du weggehen würdest.
<G-vec00132-002-s186><complain.beschweren><en> I do not complain about it, and I appreciate the work of digital stabilization, smoothness, sharpness and nice sound.
<G-vec00132-002-s186><complain.beschweren><de> Ich beschwere mich nicht, ich schätze den reibungslosen Betrieb der digitalen Stabilisierung, die Schärfe des Bildes und den guten Ton.
<G-vec00132-002-s187><complain.beschweren><en> First I resist to accept it as my problem and complain at the airline company who had informed me about what is needed.
<G-vec00132-002-s187><complain.beschweren><de> Ich weigere mich zuerst und beschwere mich bei der Fluggesellschaft wo ich mich ja vorher erkundigt hatte was erforderlich ist.
<G-vec00132-002-s188><complain.beschweren><en> I wouldn´t make a complain, but after all the trouble I had with the England trip, I thought Easter will be managed by an other dog, it wouldn´t.
<G-vec00132-002-s188><complain.beschweren><de> 27.03.2016 Frohe Ostern Ich will mich ja nicht beschweren, aber nach der ganzen Englandreise habe ich gedacht, Ostern würde an mir vorbei gehen, aber nichts.
<G-vec00132-002-s189><complain.beschweren><en> We guarantee that If you do not feel that your purchase has lived up to your expectations, you can complain within 15days after you receive the products.
<G-vec00132-002-s189><complain.beschweren><de> Wir garantieren, dass, wenn Sie nicht glauben, dass Ihr Kauf bis zu Ihren Erwartungen gelebt hat, Sie innerhalb 15days dich beschweren können, nachdem Sie die Produkte empfangen.
<G-vec00132-002-s190><complain.beschweren><en> So I should not complain when I meet people who are suspicious of Eastern Europeans dabbling with the performing arts.)
<G-vec00132-002-s190><complain.beschweren><de> Deswegen dürfte ich mich eigentlich nicht beschweren, wenn ich Leute kennen lerne, die misstrauisch werden, wenn Osteuropäer auf dem Gebiet der darstellenden Künste herumstümpern.
<G-vec00132-002-s191><complain.beschweren><en> There’s a saying in this country that if you don’t vote, you don’t get to to complain.
<G-vec00132-002-s191><complain.beschweren><de> Es gibt ein Spruch in diesem Land, der besagt, dass wenn du nicht wählen gehst, dann darfst du dich nicht beschweren.
<G-vec00132-002-s192><complain.beschweren><en> I have to realize that I need more time for my daily activities and I have to accept some restrictions, but there is no real reason to complain as long as my brain still works fine.
<G-vec00132-002-s192><complain.beschweren><de> Ich werde zwar langsamer und muss mich bei einigen Dingen etwas einschränken, aber solange der Kopf noch fit ist, möchte ich mich nicht beschweren.
<G-vec00132-002-s193><complain.beschweren><en> Personally I prefer AMOLED panels but I can't complain about this screen because of the wonderful rendering and the really nice calibration Apple has done with the colors.
<G-vec00132-002-s193><complain.beschweren><de> Ich persönlich präferiere AMOLED-Panels, aber ich kann mich über die Qualität dieses Displays dank der guten Performance und der tollen Farbwiedergabe nicht beschweren.
<G-vec00132-002-s194><complain.beschweren><en> But since it was very cheap to rent, I can't really complain..
<G-vec00132-002-s194><complain.beschweren><de> Aber da es sehr billig war zu mieten, kann ich nicht wirklich beschweren ..
<G-vec00132-002-s195><complain.beschweren><en> They often request to see the property again and then complain about things that they were okay with at the time of signing the Offer to Purchase.
<G-vec00132-002-s195><complain.beschweren><de> Sie verlangen oft, das Eigentum wieder zu sehen und dann über die Dinge zu beschweren, dass sie mit dem Zeitpunkt der Unterzeichnung des Angebots zum Kauf in Ordnung waren.
<G-vec00132-002-s196><complain.beschweren><en> The client has the right to complain about any shortcomings of the services provided.
<G-vec00132-002-s196><complain.beschweren><de> Der Kunde hat das Recht, über etwaige Mängel der erbrachten Leistungen zu beschweren.
<G-vec00132-002-s197><complain.beschweren><en> I should not complain.
<G-vec00132-002-s197><complain.beschweren><de> Ich sollte nicht beschweren.
<G-vec00132-002-s198><complain.beschweren><en> Stupid brother, I’m so going to out-level you and I’m going to leave you with absolutely no room to complain.
<G-vec00132-002-s198><complain.beschweren><de> Blöder Bruder, ich werde dich leveltechnisch so weit hinter mir lassen, dass du keinen Raum zum Beschweren hast.
<G-vec00132-002-s200><complain.beschweren><en> An example: When the LED displays on the Tiananmen square, which also hosted a massacre, show a blue sky with white clouds in the midst of smog, it is easy to understand how manipulation by word and image works and we complain about "ideology."
<G-vec00132-002-s200><complain.beschweren><de> Beispiel: Wenn auf dem „Platz des Himmlischen Friedens“, der auch ein Platz des Massakers ist, bei Smog LED-Bildschirme blauen Himmel und weiße Wolken zeigen, begreifen wir leicht, wie mit Worten und Bildern manipuliert wird, und beschweren uns über „Ideologie“.
<G-vec00132-002-s201><complain.beschweren><en> Should you want to complain about the processing of your personal data, you may contact us via email or letter as indicated above.
<G-vec00132-002-s201><complain.beschweren><de> Wenn Sie sich über die Verarbeitung Ihrer personenbezogenen Daten beschweren möchten, können Sie uns wie oben beschrieben per E-Mail oder Brief kontaktieren.
<G-vec00132-002-s202><complain.beschweren><en> At the appetite but never complain, like meat and salty foods.
<G-vec00132-002-s202><complain.beschweren><de> Am Appetit aber nie beschweren, wie Fleisch und salzige Lebensmittel.
<G-vec00132-002-s203><complain.beschweren><en> While some guests complain about mediocre food, this resort does offer a gigantic pool with plenty of space to sunbathe.
<G-vec00132-002-s203><complain.beschweren><de> Während einige Gäste über mittelmäßiges Essen beschweren, bietet dieses Resort einen gigantischen Pool mit viel Platz zum Sonnenbaden.
<G-vec00132-002-s204><complain.beschweren><en> stephan2016-05-18T00:00:00Z Everything has been said in the comments! Hard to find something to complain about: kindness, attention and communication Yaelle, cleanness, equipment, close Chartreuse hikes and Grenoble (15 minutes to go to the movies or shopping, like to stroll to the Dent de Crolles) rapid familiarization with the apartment, quiet (no noise from neighbors to us), 2 terraces, food for breakfast dèj...
<G-vec00132-002-s204><complain.beschweren><de> Yaelle erkundigte sich mehrmals ob alles zur Zufriedenheit war, gab Empfehlungen für Restaurants und Ausflüpge - wir haben bei ihr eine schön erholsame Woche zu beschweren: Freundlichkeit, Aufmerksamkeit und Kommunikation Yaelle, Sauberkeit, Ausstattung, in der Nähe Kartäuserkloster Wanderungen und Grenoble (15 Minuten ins Kino oder zum Einkaufen zu gehen, wie zum Dent de Crolles zum Flanieren) schnelle Einarbeitung in die Wohnung, ruhig (kein Lärm von Nachbarn zu uns), 2 Terrassen, Speisen zum Frühstück dèj...
<G-vec00132-002-s205><complain.beschweren><en> This is another reason why I ask you to never complain.
<G-vec00132-002-s205><complain.beschweren><de> Dies stellt einen weiteren Grund dafür dar, weswegen Ich euch bitte, euch niemals zu beschweren.
<G-vec00132-002-s206><complain.beschweren><en> I mean, there’s nothing to complain about it.
<G-vec00132-002-s206><complain.beschweren><de> Da gibt’s nichts zu beschweren.
<G-vec00132-002-s207><complain.beschweren><en> They complain that Zapatero is too soft and gives in to pressure.
<G-vec00132-002-s207><complain.beschweren><de> Sie beschweren sich, dass Zapatero zu weich sei und jedem Druck nachgebe.
<G-vec00132-002-s208><complain.beschweren><en> The other girls complain about clogged pores.
<G-vec00132-002-s208><complain.beschweren><de> Andere Mädchen beschweren sich über verstopfte Poren.
<G-vec00132-002-s209><complain.beschweren><en> Do not complain in-topic about the subject being too far off-topic or otherwise breaking rules.
<G-vec00132-002-s209><complain.beschweren><de> Beschweren Sie sich nicht im Thema, wenn das Thema zu weit vom Thema entfernt ist oder andere Regeln verletzt werden.
<G-vec00132-002-s210><complain.beschweren><en> Then they complain that you are not giving out anything from you anymore.
<G-vec00132-002-s210><complain.beschweren><de> Dann beschweren sie sich, dass du nichts mehr von dir preisgibst.
<G-vec00132-002-s211><complain.beschweren><en> employees complain that they must log in several times a day using different user IDs.
<G-vec00132-002-s211><complain.beschweren><de> Mitarbeiter beschweren sich, dass sie sich mehrmals täglich mit unterschiedlichen Benutzerkennungen anmelden müssen.
<G-vec00132-002-s212><complain.beschweren><en> Coupon Companion Ads is not a malicious program, but computer users frequently complain of similar extensions and their intrusive behavior.
<G-vec00132-002-s212><complain.beschweren><de> Coupon Companion Ads ist kein bösartiges Programm, aber Computernutzer beschweren sich häufig über ähnliche Erweiterungen und ihr aufdringliches Verhalten.
<G-vec00132-002-s213><complain.beschweren><en> People frequently complain of the long time between Debian's stable releases, but this caution also ensures Debian's legendary reliability: long months of testing are indeed necessary for the full distribution to receive the “stable” label.
<G-vec00132-002-s213><complain.beschweren><de> Oft beschweren sich Leute über den langen Zeitraum zwischen Debians stabilen Versionen, aber diese Sorgfalt gewährleistet auch seine legendäre Zuverlässigkeit: In der Tat sind monatelange Überprüfungen erforderlich, bevor die vollständige Distribution das Etikett „stabil“ erhält.
<G-vec00132-002-s214><complain.beschweren><en> Also, some guests complain about the glass bathroom doors that could pose privacy issues.
<G-vec00132-002-s214><complain.beschweren><de> Manche Gäste beschweren sich darüber, dass die Glas-Badezimmertüren Probleme mit dem Datenschutz darstellen.
<G-vec00132-002-s215><complain.beschweren><en> Many males complain that they don't understand females.
<G-vec00132-002-s215><complain.beschweren><de> Viele Männer beschweren sich, daß sie nicht Frauen verstehen.
<G-vec00132-002-s216><complain.beschweren><en> Firstly, many participants in the crowdfunding campaigns complain that they have not yet received the promised toothbrush in return.
<G-vec00132-002-s216><complain.beschweren><de> Zum einen beschweren sich viele Teilnehmer an den Crowdfunding-Aktionen, dass sie die als Gegenleistung versprochene Zahnbürste bislang nicht geliefert bekommen haben.
<G-vec00132-002-s217><complain.beschweren><en> A lot of people, pro players included, often complain about FIFA.
<G-vec00132-002-s217><complain.beschweren><de> Viele Leute, auch Profispieler, beschweren sich häufig über die FIFA.
<G-vec00132-002-s218><complain.beschweren><en> Hawaii residents often times complain about the islands’ high cost of living.
<G-vec00132-002-s218><complain.beschweren><de> Menschen die auf Hawaii leben beschweren sich oft über die hohen Lebenshaltungskosten.
<G-vec00132-002-s219><complain.beschweren><en> Some users complain about painful sensations after prolonged usage.
<G-vec00132-002-s219><complain.beschweren><de> Einige Benutzer beschweren sich über schmerzhafte Empfindungen nach längerem Gebrauch.
<G-vec00132-002-s220><complain.beschweren><en> I’m not sure how the animals would react to me singing, but my three mutts often hear me and don’t seem to complain.
<G-vec00132-002-s220><complain.beschweren><de> Ich weiß nicht, wie die Zootiere auf meinen Gesang reagieren würden, aber meine drei Hunde hören mich oft singen, und sie beschweren sich nicht.
<G-vec00132-002-s221><complain.beschweren><en> Complain (politely) to any store that sells real fur and inform CAFT
<G-vec00132-002-s221><complain.beschweren><de> Beschweren Sie sich höflich bei allen Geschäften, die echten Pelz verkaufen, und informieren Sie CAFT.
<G-vec00132-002-s222><complain.beschweren><en> You complain.
<G-vec00132-002-s222><complain.beschweren><de> Sie beschweren sich.
<G-vec00132-002-s223><complain.beschweren><en> Teenagers may complain and appear bored or annoyed, but deep down they really appreciate these moments together.
<G-vec00132-002-s223><complain.beschweren><de> Teenager beschweren sich vielleicht und scheinen gelangweilt oder genervt zu sein, aber tief in ihnen drin genießen sie diese Momente zusammen sehr.
<G-vec00132-002-s224><complain.beschweren><en> These people are the “troopers” of society; they get things done well and don’t complain much.
<G-vec00132-002-s224><complain.beschweren><de> Diese Leute sind die “Soldaten” der Gesellschaft; sie machen ihre Sache gut und beschweren sich nicht viel.
<G-vec00132-002-s225><complain.beschweren><en> Residents complain of massive noise caused by a "drunken Turkish immigrant" (26).
<G-vec00132-002-s225><complain.beschweren><de> Anwohner beschweren sich über massiven Lärm, verursacht durch einen "betrunkenen türkischen Zuwanderer" (26).
<G-vec00132-002-s226><complain.beschweren><en> We complain about faceless corporations, of the tyranny of the contact form over the direct dial.
<G-vec00132-002-s226><complain.beschweren><de> Wir beschweren uns über gesichtslose Konzerne, über Kontaktformulare statt direkter Durchwahl.
<G-vec00132-002-s227><complain.beschweren><en> Drowning in the routine, we often complain that we do not have enough time for games: computer, card, desktop, in the fresh air - it does not matter.
<G-vec00132-002-s227><complain.beschweren><de> Ertrinken in der Routine, wir beschweren uns oft, dass wir nicht genug Zeit für Spiele haben: Computer, Karte, Desktop, an der frischen Luft - es spielt keine Rolle.
<G-vec00132-002-s228><complain.beschweren><en> We complain bitterly about our lives and the lack of respect we feel at home and at work.
<G-vec00132-002-s228><complain.beschweren><de> Wir beschweren uns bitterlich über unsere Leben und den mangelnden Respekt, den wir zuhause und bei der Arbeit zu spüren bekommen.
<G-vec00132-002-s229><complain.beschweren><en> Because it is not easy to find a conditioner that does not complain the hair.
<G-vec00132-002-s229><complain.beschweren><de> Denn es ist nicht einfach eine Pflegespülung zu finden, welche die Haare nicht beschwert.
<G-vec00132-002-s230><complain.beschweren><en> If this is the case, please do us both a favour and close the tab or click the back button, but please do not complain if you find content, particularly of the fannish nature, that you dislike.
<G-vec00132-002-s230><complain.beschweren><de> Sollte das der Fall sein, tut euch und mir einen Gefallen und verlaßt diese Seite, aber beschwert euch bitte nicht über den Inhalt.
<G-vec00132-002-s231><complain.beschweren><en> Active care to improve condition of the hair significantly, does not complain of the hair.
<G-vec00132-002-s231><complain.beschweren><de> Aktive Pflege, um Zustand der Haare deutlich zu verbessern, beschwert nicht das Haar.
<G-vec00132-002-s232><complain.beschweren><en> Generally, when it suffers, it doesn't complain: it calls....
<G-vec00132-002-s232><complain.beschweren><de> Normalerweise beschwert er sich nicht, wenn er leidet: er ruft...
<G-vec00132-002-s233><complain.beschweren><en> Also, SmartScreen filter in recent versions of Internet Explorer (IE) or Microsoft Edge may complain that Audacity is not "commonly downloaded" or say that "Windows has protected your PC" and ask you to confirm the download.
<G-vec00132-002-s233><complain.beschweren><de> Auch der SmartScreen Filter in aktuellen Versionen von Internet Explorer (IE) beschwert sich möglicherweise, dass Audacity nicht "häufig heruntergeladen" wird und fragt Sie danach, das Herunterladen zu bestätigen.
<G-vec00132-002-s234><complain.beschweren><en> She behaves like a good sex slave and doesn't complain when she's forced to watch how Asa Akira and Jessica Drake swap partners and even enjoy double penetrations.
<G-vec00132-002-s234><complain.beschweren><de> Sie benimmt sich wie eine brave Sexsklavin und beschwert sich nicht, als sie dabei zusehen muss, wie Asa Akira und Jessica Drake die Partner tauschen und sogar in den Genuss von DPs kommen.
<G-vec00132-002-s235><complain.beschweren><en> The Modul can be loaded without problems and doesn't complain about a missing device.
<G-vec00132-002-s235><complain.beschweren><de> Das Modul läßt sich ohne Probleme laden und beschwert sich nicht über ein fehlendes Device.
<G-vec00132-002-s236><complain.beschweren><en> pc ps4 Radio operator may complain that he can not use the radio as it needs more power even though the required amount of power is provided.
<G-vec00132-002-s236><complain.beschweren><de> pc ps4 Der Funker beschwert sich, dass er das Radio nicht nutzen kann, weil es mehr Strom braucht, obwohl genügend Energie vorhanden ist.
<G-vec00132-002-s237><complain.beschweren><en> Those practitioners who played the roles of policemen and victims in the exhibition had to stay in position for many hours, but they didn’t complain.
<G-vec00132-002-s237><complain.beschweren><de> Die Praktizierenden, die die Rollen der Polizisten und Folteropfer bei der Ausstellung spielten, mussten viele Stunden in derselben Position verharren, doch sie beschwerten sich nicht.
<G-vec00132-002-s238><complain.beschweren><en> "Average but big rooms with wonderful views, and okay beds." Guests complain about cleanliness, maintenance, and furnishing.
<G-vec00132-002-s238><complain.beschweren><de> 2.7/5 97 Bewertungen „Moderne Zimmer mit ausgezeichneten Betten.“ Die Gäste beschwerten sich über Sauberkeit, Instandhaltung und Ausstattung.
<G-vec00132-002-s239><complain.beschweren><en> In the eyes of the occupying authorities, however, the Jewish DPs were developing increasingly into a disruptive influence on regular administrative procedures, as they would not fit into the scheme that the military had earmarked for solving the DP problem: they would complain incessantly, they were in the eyes of the army undisciplined, and they insisted that they should be recognised as having a separate nationality and be housed in separate camps with special treatment.
<G-vec00132-002-s239><complain.beschweren><de> In den Augen der Besatzungsbehörden entwickelten sich die jüdischen DPs zunehmend zu Störfaktoren eines geregelten Verwaltungsablaufs, da sie sich nicht in das Schema einpassen wollten, das vom Militär für die Lösung des DP-Problems vorgesehen war: sie beschwerten sich laufend, waren aus Sicht der Armee undiszipliniert und bestanden darauf, als eigene Nationalität anerkannt und in separaten Lagern mit einer besonderen Betreuung untergebracht zu werden.
<G-vec00132-002-s245><complain.beschweren><en> We're not going to complain about that.
<G-vec00132-002-s245><complain.beschweren><de> Wir werden uns nicht darüber beschweren.
<G-vec00132-002-s246><complain.beschweren><en> You have the right to complain to ICO if you believe there is a problem with the way we are handling your personal data.
<G-vec00132-002-s246><complain.beschweren><de> Bei dem Verdacht, dass Ihre Daten nicht entsprechend behandelt werden, haben Sie das Recht sich bei der Datenschutzbehörde darüber zu beschweren.
<G-vec00132-002-s325><complain.beschweren><en> Well, I can not complain.
<G-vec00132-002-s325><complain.beschweren><de> Gut, kann ich nicht mich beschweren.
<G-vec00132-002-s326><complain.beschweren><en> I cannot complain about the price for 4 towels.
<G-vec00132-002-s326><complain.beschweren><de> Ich kann mich nicht über den Preis für 4 Handtücher beschweren.
<G-vec00132-002-s327><complain.beschweren><en> I would like to complain about my neighbor.
<G-vec00132-002-s327><complain.beschweren><de> Ich möchte mich über meinen Nachbarn beschweren.
<G-vec00132-002-s328><complain.beschweren><en> I can’t complain about a 7 hour nap in a train at night.
<G-vec00132-002-s328><complain.beschweren><de> Über ein 7 stündiges Nickerchen in der Nacht möchte ich mich nicht beschweren.
<G-vec00132-002-s329><complain.beschweren><en> Weird, but I can't complain.
<G-vec00132-002-s329><complain.beschweren><de> Komisch, aber ich will mich nicht beschweren.
<G-vec00132-002-s330><complain.beschweren><en> Can't complain about anything.
<G-vec00132-002-s330><complain.beschweren><de> Ich kann mich über nichts beschweren.
<G-vec00132-002-s331><complain.beschweren><en> I do not want to complain…not at all…I am thankful…thankful for this past year…despite all the pain it has brought us…how could I not…this past year did have 6 months…6 months in which I was able to be a big sister to Tina…in which I could let her know how much she was loved and wanted…in which I was able to enjoy her in my life…even tho it wasn´t easy at times…I feel beyond blessed I did have those 6 months…6 last months with my beloved baby sister. Tina will forever be in our hearts…in our minds…in our lives…she will be with us this christmas…especially now…watching us from above…knowing how much she is loved
<G-vec00132-002-s331><complain.beschweren><de> Ich möchte mich nicht beschweren…in keinster Weise…ich bin dankbar…dankbar für das letzte Jahr…trotz der undenkbaren Schmerzen die es uns gebracht hat…wie könnte ich nicht…dieses letzte Jahr hat mir 6 Monate gegeben…6 ganze Monate in denen ich eine große Schwester für Tina sein durfte…ich welchen ich sie wissen lassen durfte wie sehr sie gebraucht wird und wie sehr ich sie liebe…ich welchen ich es genießen durfte sie in meinem Leben zu haben…auch wenn es oft nicht einfach war…ich fühle mich gesegnet für diese 6 Monate…6 letzte Monate mit meiner geliebten kleinen Schwester.
<G-vec00132-002-s332><complain.beschweren><en> No, I don’t want to complain about that half.
<G-vec00132-002-s332><complain.beschweren><de> Nun, ich möchte mich nicht über diesen Teil beschweren.
<G-vec00132-002-s333><complain.beschweren><en> I could complain about the nasty cold outside, but hey, I complain every time haha.
<G-vec00132-002-s333><complain.beschweren><de> Und ich könnte mich ja √ľber diese elende Kälte beschweren, aber das tue ich irgendwie immer haha.
<G-vec00132-002-s334><complain.beschweren><en> I do not want to complain...not at all...I am thankful...thankful for this past year...despite all the pain it has brought us...how could I not...this past year did have 6 months...6 months in which I was able to be a big sister to Tina...in which I could let her know how much she was loved and wanted...in which I was able to enjoy her in my life...even tho it wasn´t easy at times...I feel beyond blessed I did have those 6 months...6 last months with my beloved baby sister.
<G-vec00132-002-s334><complain.beschweren><de> Ich möchte mich nicht beschweren...in keinster Weise...ich bin dankbar...dankbar für das letzte Jahr...trotz der undenkbaren Schmerzen die es uns gebracht hat...wie könnte ich nicht...dieses letzte Jahr hat mir 6 Monate gegeben...6 ganze Monate in denen ich eine große Schwester für Tina sein durfte...ich welchen ich sie wissen lassen durfte wie sehr sie gebraucht wird und wie sehr ich sie liebe...ich welchen ich es genießen durfte sie in meinem Leben zu haben...auch wenn es oft nicht einfach war...ich fühle mich gesegnet für diese 6 Monate...6 letzte Monate mit meiner geliebten kleinen Schwester.
<G-vec00132-002-s335><complain.beschweren><en> Can't really complain.
<G-vec00132-002-s335><complain.beschweren><de> Ich kann mich nicht wirklich beschweren.
<G-vec00132-002-s403><complain.beschweren><en> If you want to complain about information and materials uploaded by other users, please contact kundenservice@dfb-fanshop.com.
<G-vec00132-002-s403><complain.beschweren><de> Wenn Sie sich über Informationen und Materialien beschweren möchten, die von anderen Nutzern hochgeladen wurden, wenden Sie sich bitte an kundenservice@dfb-fanshop.de.
<G-vec00132-002-s404><complain.beschweren><en> The ArgoUML critics will complain about attribute names that do not have an initial lower case letter.
<G-vec00132-002-s404><complain.beschweren><de> Die ArgoUML-Kritiken werden sich über Attributnamen beschweren, die nicht mit einem Kleinbuchstaben beginnen.
<G-vec00132-002-s405><complain.beschweren><en> Don't wait for your users to complain.
<G-vec00132-002-s405><complain.beschweren><de> Warten Sie nicht, bis sich Ihre Nutzer beschweren.
<G-vec00132-002-s406><complain.beschweren><en> He must not complain over trifles, and he must not eat with the musicians, for then they will lose respect for him.
<G-vec00132-002-s406><complain.beschweren><de> Er darf sich nicht über Bagatellen beschweren und darf nicht mit den Musikern zusammen essen, da sie sonst den Respekt vor ihm verlieren würden.
<G-vec00132-002-s407><complain.beschweren><en> You should never complain or try to rush things.
<G-vec00132-002-s407><complain.beschweren><de> Sie sollten sich nie beschweren oder versuchen, Dinge zu überstürzen.
<G-vec00132-002-s408><complain.beschweren><en> Honestly, we are a very quiet family and I am not one to complain.
<G-vec00132-002-s408><complain.beschweren><de> Ehrlich gesagt, sind wir eine sehr ruhige Familie und ich bin nicht einer, sich zu beschweren.
<G-vec00132-002-s409><complain.beschweren><en> But let us go to the recipe of this soon to be famous Keto farmers Bread, so you do not complain I do write too much.
<G-vec00132-002-s409><complain.beschweren><de> Aber lassen Sie uns zu dem Rezept gehen, damit Sie sich nicht beschweren, dass ich zu viel schreibe.
<G-vec00132-002-s410><complain.beschweren><en> The data protection officer is obliged to keep your identity secret if you wish to complain about the processing of your data by us.
<G-vec00132-002-s410><complain.beschweren><de> Der Datenschutzbeauftragte ist verpflichtet, Ihre Identität geheim zu halten, wenn Sie sich über die Verarbeitung Ihrer Daten durch uns beschweren wollen.
<G-vec00132-002-s411><complain.beschweren><en> When community folks in Cross River began to complain about this company’s activities, they recruited a bunch of community people who supported the company and even staged a demonstration during which they carried signs saying ‘we want factories, not monkeys.’
<G-vec00132-002-s411><complain.beschweren><de> Als die Bewohner in Cross River sich über die Aktivitäten der Firma zu beschweren begannen, heuerte die Firma zur Unterstützung eine Gruppe von Leuten an, die eine Demo veranstalteten mit Schildern, auf denen es hieß: Wir wollen Fabriken, keine Affen.
<G-vec00132-002-s412><complain.beschweren><en> The bosses will complain that this will reduce their profits and have a negative effect on their incentive to invest.
<G-vec00132-002-s412><complain.beschweren><de> Die Bosse werden sich beschweren, dass dies ihre Profite schmälern und negative Auswirkungen auf ihre Investitionsanreize haben wird.
<G-vec00132-002-s413><complain.beschweren><en> No need to complain about the lack of comfort when driving.
<G-vec00132-002-s413><complain.beschweren><de> Sie müssen sich nicht über den mangelnden Komfort beim Fahren beschweren.
<G-vec00132-002-s414><complain.beschweren><en> As one striking worker explained, there are no jobs, no money, no food, and those who complain about it are thrown in prison.
<G-vec00132-002-s414><complain.beschweren><de> Wie ein streikender Arbeiter erklärte, gibt es keine Arbeitsplätze, kein Geld, keine Nahrungsmittel, und diejenigen, die sich darüber beschweren, werden ins Gefängnis geworfen.
<G-vec00132-002-s415><complain.beschweren><en> In addition, you have the right to complain to a supervisory authority in case of privacy breaches.
<G-vec00132-002-s415><complain.beschweren><de> Darüber hinaus haben Sie das Recht, sich im Falle von Daten-schutzverletzungen bei einer Aufsichtsbehörde zu beschweren.
<G-vec00132-002-s416><complain.beschweren><en> Gannuschkina says, „People are very cautious, no one wants to complain. The victims don’t want to talk to us.“ Many victims prefer not to talk in order to avoid any further problems.
<G-vec00132-002-s416><complain.beschweren><de> Gannuschkina sagt: „Die Menschen reden sehr vorsichtig, niemand will sich beschweren, die Opfer wollen nicht mit uns sprechen.“ Viele Opfer schweigen lieber, um sich nicht einer zusätzlichen Gefahr auszusetzen.
<G-vec00132-002-s417><complain.beschweren><en> The number of men and women who complain about the condition of their hair and scalp keeps increasing.
<G-vec00132-002-s417><complain.beschweren><de> Die Anzahl der Frauen und Männer, die sich über Kondition ihres Haars und ihrer Kopfhaut beschweren, ist immer größer.
<G-vec00132-002-s418><complain.beschweren><en> I just think it's pointless to complain about such things, if they can't be changed anyway, and that a complaint is a paradox when one himself very often acts according to the same standards.
<G-vec00132-002-s418><complain.beschweren><de> Ich finde nur, dass es sinnlos ist, sich über derartige Dinge zu beschweren, wenn sie doch nicht geändert werden können; und dass eine Beschwerde ein Paradoxum darstellt, wenn man selbst sehr oft nach gleichen Normen handelt.
<G-vec00132-002-s419><complain.beschweren><en> Please do not be taken in by the false argument that it was the Germans who started the bombing of civilian targets and therefore have nothing to complain about.
<G-vec00132-002-s419><complain.beschweren><de> Man sollte sich auch nicht von dem falschen Argument beeinflussen lassen, die Deutschen hätten immerhin die Bombardierung ziviler Ziele angefangen und dürften sich deshalb gar nicht beschweren.
<G-vec00132-002-s420><complain.beschweren><en> You cannot go to the swimming pool and later complain that you do not know how you got wet.
<G-vec00132-002-s420><complain.beschweren><de> Man kann nicht ins Schwimmbad gehen und sich dann später beschweren, man wüsste nicht, wie man nass geworden ist.
<G-vec00132-002-s421><complain.beschweren><en> The two apartments were prepared for 11 people and you brought in more people without my knowledge; then there is no reason to complain that the two apartments did not have enough of everything.
<G-vec00132-002-s421><complain.beschweren><de> Die zwei Wohnungen waren für 11 Leute vorbereitet und Sie brachten ohne mein Wissen mehr Leute mit; dann gibt es keinen Grund sich zu beschweren, dass es nicht genug von allem in den beiden Wohnungen gab.
<G-vec00132-002-s437><complain.beschweren><en> When we share only doubt, unease, suffering and sorrow, perhaps complain and maybe even whine on occasion, this creates a totally different atmosphere.
<G-vec00132-002-s437><complain.beschweren><de> Wenn wir nur Zweifel, Unbehagen, Leiden und Unglück kommunizieren, uns eventuell beschweren und vielleicht sogar auch etwas meckern, entsteht eine ganz andere Stimmung.
<G-vec00132-002-s438><complain.beschweren><en> Hard work is something we can complain about and at the same time it makes us valuable members of our community.
<G-vec00132-002-s438><complain.beschweren><de> Harte Arbeit – darüber können wir uns beschweren und gleichzeitig sind wir dann wertvolle Mitglieder unserer Gesellschaft.
<G-vec00132-002-s439><complain.beschweren><en> The sun is burning down, but we do not want to complain.
<G-vec00132-002-s439><complain.beschweren><de> Die Sonne brennt runter, aber wir wollen uns nicht beschweren.
<G-vec00132-002-s124><complain.einlegen><en> We may require you to provide further information about your complaint to duly assess your complaint. If for any reason you do not wish to complain to us initially or if you are unhappy with how we propose to resolve your complain then complaint may also be made to the Office of the Australian Information Commissioner.
<G-vec00132-002-s124><complain.einlegen><de> Wenn Sie Ihre Beschwerde aus irgendeinem Grund nicht direkt an uns richten möchten oder nicht mit unserem Lösungsvorschlag für Ihre Beschwerde einverstanden sind, können Sie Ihre Beschwerde auch an einen unabhängigen Datenschutzbeauftragten in Australien beim Office of the Australian Information Commissioner (OAIC) richten.
<G-vec00132-002-s125><complain.einlegen><en> If you believe that the processing of your personal data by us violates the applicable data protection law or your data protection claims have been violated in another way, it is possible to complain to the competent supervisory authority.
<G-vec00132-002-s125><complain.einlegen><de> Wenn Sie der Meinung sind, dass die Verarbeitung Ihrer personenbezogenen Daten anwendbare Datenschutzgesetze verletzt oder dass Ihre Datenschutzrechte anderweitig verletzt wurden, besteht die Möglichkeit der Beschwerde an die zuständige Behörde.
<G-vec00132-002-s126><complain.einlegen><en> e) Right to Complaints at a Regulatory Authority: Notwithstanding other administrative or legal relief, you have the right to complain at a regulatory authority, particularly in the member state of your location or residence, your workplace or the location of the alleged violation, if you are of the opinion that the processing of personal data concerning you infringes upon the GDPR.
<G-vec00132-002-s126><complain.einlegen><de> e) Recht auf Beschwerde bei einer Aufsichtsbehörde Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat ihres Aufenthaltsorts, ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00132-002-s127><complain.einlegen><en> • Right to complain under Art.
<G-vec00132-002-s127><complain.einlegen><de> Recht auf Beschwerde gemäß Art.
<G-vec00132-002-s128><complain.einlegen><en> The only thing my former landlady found to complain about was the claw marks in the couch left by Boris the she-cat.
<G-vec00132-002-s128><complain.einlegen><de> Meine ehemalige Vermieterin fand nur einen Grund zur Beschwerde – die Krallenspuren, die Boris im Sofa hinterlassen hatte.
<G-vec00132-002-s129><complain.einlegen><en> Complain: You can complain to the UK Information Commissioner’s Office or your country’s data protection authority.
<G-vec00132-002-s129><complain.einlegen><de> Beschwerde: Sie können sich bei der britischen Datenschutzbehörde oder der Datenschutzbehörde Ihres Landes beschweren.
<G-vec00132-002-s130><complain.einlegen><en> You have the right to complain as outlined in paragraph 4.5 below.: 4.5 COMPLAINTS
<G-vec00132-002-s130><complain.einlegen><de> Falls erforderlich, haben Sie das Recht, eine Beschwerde gemäß nachstehendem Absatz einzureichen.
<G-vec00132-002-s131><complain.einlegen><en> You are entitled to complain to the competent authorities (Integrity Protection Authority) of improper handling of personal data performed by SSTS.
<G-vec00132-002-s131><complain.einlegen><de> Sie haben das Recht, eine Beschwerde wegen fehlerhafter Verarbeitung personenbezogener Daten durch SSTS einzureichen.
<G-vec00132-002-s132><complain.einlegen><en> 2) The right to complain lapses as soon as the goods are used defectively or have been stored.
<G-vec00132-002-s132><complain.einlegen><de> 2) Das Recht auf Beschwerde erlischt, sobald die Waren in defektem Zustand verwendet werden oder gelagert worden sind.
<G-vec00132-002-s134><complain.einlegen><en> However, if you are someone buying this product, it is one of the reasons why you complain about having to pay so much for it.
<G-vec00132-002-s134><complain.einlegen><de> Wenn Sie allerdings ein Käufer bestimmter Produkte sind, dann ist es vielmehr einer der Hauptgründe für Ihre Beschwerde, warum es denn so viel kostet.
<G-vec00132-002-s135><complain.einlegen><en> That's the only complain I have about this book.
<G-vec00132-002-s135><complain.einlegen><de> Das ist die einzige Beschwerde, die ich hierbei habe.
<G-vec00132-002-s136><complain.einlegen><en> NetBet will respond to the complainants or to the Authority with respect to complaints with the results of the inquiry within 21 days from the date of the lodgement of the complain.
<G-vec00132-002-s136><complain.einlegen><de> NetBet wird wird auf Beschwerden oder auf die Behörde in Bezug auf Beschwerden innerhalb von 21 Tagen ab Datum der eingereichten Beschwerde mit den Ergebnissen der Untersuchung antworten.
<G-vec00132-002-s137><complain.einlegen><en> Affected rights You have a right to information, rectification, erasure or restriction of the processing of your stored data, a right of objection to the processing as well as a right to data portability and a right to complain in accordance with the requirements of data protection law.
<G-vec00132-002-s137><complain.einlegen><de> Sie haben jederzeit ein Recht auf Auskunft, Berichtigung, Löschung oder Einschränkung der Verarbeitung Ihrer gespeicherten Daten, ein Widerspruchsrecht gegen die Verarbeitung sowie ein Recht auf Datenübertragbarkeit und auf Beschwerde gemäß den Voraussetzungen des Datenschutzrechts.
<G-vec00132-002-s138><complain.einlegen><en> Each data subject has the right to complain to a supervisory authority if the data subject considers that the processing of personal data concerning them is contrary to the GDPR.
<G-vec00132-002-s138><complain.einlegen><de> Jede betroffene Person hat das Recht auf Beschwerde bei einer Aufsichtsbehörde, wenn die betroffene Person der Ansicht ist, dass die Verarbeitung der sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00132-002-s139><complain.einlegen><en> If you feel your data has not been handled securely and would like to complain to David Austin Roses, please contact us on [email protected] or call 800 328 8893. 14.
<G-vec00132-002-s139><complain.einlegen><de> Wenn Sie glauben, dass Ihre Daten nicht ausreichend geschützt wurden und eine Beschwerde bei David Austin Roses einreichen möchten, kontaktieren Sie uns bitte unter [email protected] oder per Telefon unter 0044 1902 376371.
<G-vec00132-002-s140><complain.einlegen><en> Irrespective of another judicial remedy or a remedy under administration law, you have the right to complain to a supervisory authority in particular in the member state of your country of residence or work, or the location of the alleged breach provided you believe that the processing of the personal data about you contravenes the GDPR.
<G-vec00132-002-s140><complain.einlegen><de> Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat ihres Aufenthaltsorts, ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00132-002-s141><complain.einlegen><en> Right to complain to a supervisory authority You have the right to complain to a supervisory authority, in particular in the Member State of your place of residence, your place of work or the place of the alleged infringement, if you believe that the processing of your personal data is unlawful.
<G-vec00132-002-s141><complain.einlegen><de> Sie haben das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat Ihres Aufenthaltsorts, Ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten rechtswidrig ist.
<G-vec00132-002-s145><complain.einlegen><en> In addition, you have the right to complain to a regulator.
<G-vec00132-002-s145><complain.einlegen><de> Darüber hinaus haben Sie das Recht auf Beschwerde bei einer Aufsichtsbehörde.
<G-vec00132-002-s146><complain.einlegen><en> You also have the right to complain to the supervisory authority.
<G-vec00132-002-s146><complain.einlegen><de> Weiters haben Sie das Recht auf Beschwerde bei der Aufsichtsbehörde.
<G-vec00132-002-s147><complain.einlegen><en> Notwithstanding any other administrative legal or court remedy, you have the right to complain to the authorities, especially in the Member State of your place of residence, your workplace, or the site of the suspected breach if you are of the view that the work which we undertake to process your personal data violates the GDPR. 23.
<G-vec00132-002-s147><complain.einlegen><de> Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat Ihres Aufenthaltsorts, Ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die von uns vorgenommene Verarbeitung Ihrer personenbezogenen Daten gegen die DS-GVO verstößt.
<G-vec00132-002-s149><complain.einlegen><en> complain to the supervisory organ:if you believe that we process your data in an unlawful way, you can file a complaint to the Chairman of the Personal Data Protection Office or to another relevant supervisory body.
<G-vec00132-002-s149><complain.einlegen><de> Beschwerde bei der Aufsichtsbehörde: Wenn Sie der Meinung sind, dass wir Ihre Daten unrechtmäßig verarbeiten, können Sie sich beim Präsidenten des Amtes für den Schutz personenbezogener Daten oder bei einer anderen zuständigen Aufsichtsbehörde beschweren.
<G-vec00132-002-s151><complain.einlegen><en> Without prejudice to an available administrative or extrajudicial remedy, including the right to complain to a supervisory authority under Article 77 of the GDPR, you have the right to an effective judicial remedy if you feel that the processing of your personal data breaches this regulation.
<G-vec00132-002-s151><complain.einlegen><de> Sie haben unbeschadet eines verfügbaren verwaltungsrechtlichen oder außergerichtlichen Rechtsbehelfs einschließlich des Rechts auf Beschwerde bei einer Aufsichtsbehörde gemäß Artikel 77 DSGVO das Recht auf einen wirksamen gerichtlichen Rechtsbehelf, wenn sie der Ansicht ist, dass die ihr aufgrund dieser Verordnung zustehenden Rechte infolge einer nicht im Einklang mit dieser Verordnung stehenden Verarbeitung ihrer personenbezogenen Daten verletzt wurden.
<G-vec00132-002-s153><complain.einlegen><en> You have the right to complain to a Data Protection Authority (in Poland: President of the Personal Data Protection Office) about our collection and use of your Personal Data.
<G-vec00132-002-s153><complain.einlegen><de> Sie haben das Recht, in Bezug auf die Erfassung und Nutzung Ihrer personenbezogenen Daten eine Beschwerde bei einer Datenschutzbehörde einzulegen.
<G-vec00132-002-s154><complain.einlegen><en> In addition, you have the right to complain to the regulatory authorities (Austrian Data Protection Authority, Wickenburggasse 8, 1080 Vienna, dsb@dsb.gv.at).
<G-vec00132-002-s154><complain.einlegen><de> Weiters haben Sie das Recht auf Beschwerde bei der Aufsichtsbehörde (Österreichische Datenschutzbehörde, Barichgasse 40-42, 1030 Wien, dsb@dsb.gv.at).
<G-vec00132-002-s155><complain.einlegen><en> Without prejudice to an available administrative or extrajudicial remedy, including the right to complain to a supervisory authority under Article 77 of the GDPR, it shall have the right to an effective judicial remedy if it considers that the rights conferred on it by that Regulation are not satisfied by that Regulation concerning the processing of their personal data. General Data Protection Regulation
<G-vec00132-002-s155><complain.einlegen><de> Sie haben unbeschadet eines verfügbaren verwaltungsrechtlichen oder außergerichtlichen Rechtsbehelfs einschließlich des Rechts auf Beschwerde bei einer Aufsichtsbehörde gemäß Artikel 77 DSGVO das Recht auf einen wirksamen gerichtlichen Rechtsbehelf, wenn sie der Ansicht ist, dass Ihre, aufgrund dieser Verordnung zustehenden Rechte, infolge einer nicht im Einklang mit dieser Verordnung stehenden Verarbeitung Ihrer personenbezogenen Daten verletzt wurden.
<G-vec00132-002-s157><complain.einlegen><en> If you believe that the Company has not complied with your data protection rights, you can complain to the Information Commissioner.
<G-vec00132-002-s157><complain.einlegen><de> Wenn Sie der Ansicht sind, dass das Unternehmen Ihre Datenschutzrechte nicht beachtet hat, können Sie beim Information Commissioner Beschwerde einlegen.
<G-vec00132-002-s158><complain.einlegen><en> “The new Protocol sends a strong signal from the international community that children too, are rights holders and that they have the right to complain internationally when no effective remedies are available to them in their country”, said Ms Goh.
<G-vec00132-002-s158><complain.einlegen><de> «Das neue Protokoll ist ein starkes Signal der internationalen Gemeinschaft, dass auch Kinder Rechtsinhaber sind und international Beschwerde einlegen können, wenn ihnen in ihrem Heimatland keine wirksamen Rechtsmittel zur Verfügung stehen», erklärte Frau Goh.
<G-vec00132-002-s159><complain.einlegen><en> Please note: This form is intended solely to complain about or report serious incidents, mainly off pitch.
<G-vec00132-002-s159><complain.einlegen><de> Bitte beachten: Dieses Formular is ausschließlich für Beschwerden oder Meldungen ernster Vorfälle, hauptsächlich abseits des Spielfeldes, vorgesehen.
<G-vec00132-002-s160><complain.einlegen><en> Get more information, askquestions or complain about disruptions in work can be done through the "hotline": 8-800-500-47-28.
<G-vec00132-002-s160><complain.einlegen><de> Holen Sie weitere Informationen, fragen SieFragen oder Beschwerden über Arbeitsunterbrechungen können über die "Hotline" 0800-500-47-28 gestellt werden.
<G-vec00132-002-s161><complain.einlegen><en> It was the pumps in particular that were a nuisance; the neighbours started to complain...
<G-vec00132-002-s161><complain.einlegen><de> Vor allem durch die Pumpen entstand Lärmbelästigung; es gab auch Beschwerden aus der Umgebung....
<G-vec00132-002-s252><complain.jammern><en> You should never unpack romanticism and complain that so many traditional things are dying out.
<G-vec00132-002-s252><complain.jammern><de> Man sollte nirgendwo einen Romantizismus auspacken und jammern, dass so viele althergebrachte Sachen aussterben.
<G-vec00132-002-s253><complain.jammern><en> Normally I try not to complain when I’m ill, but it’s really been a long time since I felt so bad physically.
<G-vec00132-002-s253><complain.jammern><de> Normalerweise versuche ich nicht zu jammern, wenn ich mich krank fühle, aber ich glaube so schlecht ging es mir körperlich schon lange nicht mehr.
<G-vec00132-002-s254><complain.jammern><en> Takeaway: We complain because it's a habit.
<G-vec00132-002-s254><complain.jammern><de> Wir jammern, weil es eine Gewohnheit geworden ist.
<G-vec00132-002-s255><complain.jammern><en> Then they eat and complain that they should have ordered something else.
<G-vec00132-002-s255><complain.jammern><de> Dann essen sie und jammern, dass sie doch etwas anderes hätten bestellen sollen.
<G-vec00132-002-s256><complain.jammern><en> In these days many complain and rant, but few try to change something.
<G-vec00132-002-s256><complain.jammern><de> Viele jammern und schimpfen, aber die wenigsten ändern etwas.
<G-vec00132-002-s257><complain.jammern><en> We could easily complain, as the Apostles did to Jesus: ''Where are we to get bread enough in the desert to feed so great a crowd?'' (Mt 15:33).
<G-vec00132-002-s257><complain.jammern><de> Wir könnten jammern, wie es die Apostel gegenüber Jesus getan haben: »Wo sollen wir in dieser unbewohnten Gegend so viel Brot hernehmen, um so viele Menschen satt zu machen?« (Mt 15, 33).
<G-vec00132-002-s258><complain.klagen><en> If a people no longer wants to respect the Nature-given qualities of its being which root in its blood, it has no further right to complain over the loss of its earthly existence.
<G-vec00132-002-s258><complain.klagen><de> Wenn ein Volk die ihm von der Natur gegebenen und in seinem Blute wurzelnden Eigenschaften seines Wesens nicht mehr achten will, hat es kein Recht mehr zur Klage über den Verlust seines irdischen Daseins.
<G-vec00132-002-s259><complain.klagen><en> I do not complain, I do not complain.
<G-vec00132-002-s259><complain.klagen><de> Ich klage nicht, ich klage nicht.
<G-vec00132-002-s261><complain.klagen><en> In the calorie traffic light green marked food does not help when removing and nevertheless must anybody about hunger complain, clarifies to Mueller Nothmann the conclusive concept, which is behind the calorie traffic light.
<G-vec00132-002-s261><complain.klagen><de> In der Kalorien-Ampel grün gekennzeichnete Lebensmittel helfen beim Abnehmen und dennoch muss niemand über Hunger klagen, verdeutlich Müller-Nothmann das schlüssige Konzept, das hinter der Kalorien-Ampel steckt.
<G-vec00132-002-s262><complain.klagen><en> 7:11 Therefore I will not restrain my mouth: I will speak in the anguish of my spirit; I will complain in the bitterness of my soul.
<G-vec00132-002-s262><complain.klagen><de> 11 So will auch ich meinen Mund nicht zurückhalten, will reden in der Bedrängnis meines Geistes, will klagen in der Verbitterung meiner Seele.
<G-vec00132-002-s263><complain.klagen><en> 11“Therefore I will not restrain my mouth; I will speak in the anguish of my spirit; I will complain in the bitterness of my soul.
<G-vec00132-002-s263><complain.klagen><de> 11So will auch ich meinen Mund nicht zurückhalten, will reden in der Bedrängnis meines Geistes, will klagen in der Bitterkeit meiner Seele.
<G-vec00132-002-s264><complain.klagen><en> 27/10/15 |originally published in zooplus.de Can't complain Does what it promises.
<G-vec00132-002-s264><complain.klagen><de> 27.10.15 |ursprünglich veröffentlicht in zooplus.de Kann nicht klagen Hält was es verspricht und hat mich definitiv überzeugt.
<G-vec00132-002-s265><complain.klagen><en> Before we ever complain and protest again – (Protest against unjust politics is, by the way, correct.
<G-vec00132-002-s265><complain.klagen><de> Bevor wir jemals wieder klagen und protestieren – (Protest gegen ungerechte Politik ist, nebenbei bemerkt, richtig.
<G-vec00132-002-s266><complain.klagen><en> With its high contrast and deep blacks there really is not much to complain about.
<G-vec00132-002-s266><complain.klagen><de> Dank hohem Kontrast und tiefen Schwarztönen gibt es nicht viel zu klagen.
<G-vec00132-002-s267><complain.klagen><en> In the course of business with buyers as area of jurisdiction for all law cases, including change and cheque complaints, resulting in from the contract, Bayreuth is agreed upon, we are also justified to complain at the seat of the customer.
<G-vec00132-002-s267><complain.klagen><de> Im Geschäftsverkehr mit Kaufleuten wird als Gerichtsstand für alle aus dem Vertrag sich ergebenden Rechtsstreitigkeiten, einschließlich Wechsel- und Scheckklagen, Bayreuth vereinbart, wir sind auch berechtigt, am Sitz des Kunden zu klagen.
<G-vec00132-002-s268><complain.klagen><en> Many parents would take advantage of your legal protection insurance and over long periods of time complain.
<G-vec00132-002-s268><complain.klagen><de> Viele Eltern würden ihre Rechtsschutzversicherung ausnutzen und über lange Zeiträume hinweg klagen.
<G-vec00132-002-s269><complain.klagen><en> Ten to 25 percent of the companies also complain about insufficient software support and inadequate system performance.
<G-vec00132-002-s269><complain.klagen><de> Zehn bis 25 Prozent der Unternehmen klagen zudem über eine unzureichende Softwareunterstützung sowie unzureichende Leistungsfähigkeit der Systeme.
<G-vec00132-002-s270><complain.klagen><en> But sometimes men after taking the pills complain of headache, allergic rhinitis, dyspepsia.
<G-vec00132-002-s270><complain.klagen><de> Aber manchmal klagen Männer nach der Einnahme der Pillen über Kopfschmerzen, allergische Rhinitis, Dyspepsie.
<G-vec00132-002-s271><complain.klagen><en> Girls openly complain about wearing heels.
<G-vec00132-002-s271><complain.klagen><de> Mädchen offen klagen über Heels.
<G-vec00132-002-s272><complain.klagen><en> Thus, 57% of women during pregnancy and 30% after childbirth complain of difficulty in relieving the intestines (quite simply, constipation).
<G-vec00132-002-s272><complain.klagen><de> So klagen 57% der Frauen während der Schwangerschaft und 30% nach der Geburt über Schwierigkeiten bei der Entlastung des Darms (ganz einfach, Verstopfung).
<G-vec00132-002-s273><complain.klagen><en> Again, both cars were involved in collisions in Saturday’s qualifying race even though all teams complain that this has to be reduced in order to avoid expensive damages.
<G-vec00132-002-s273><complain.klagen><de> Im Qualifying Rennen am Samstag wurden beide Fahrzeuge des Teams erneut in Kollisionen verwickelt, obwohl alle Teams klagen, dass das reduziert werden muss, um kostspielige Schäden zu vermeiden.
<G-vec00132-002-s274><complain.klagen><en> I will never again complain that my tiny, two-kilo notebook is heavy!
<G-vec00132-002-s274><complain.klagen><de> Nie wieder werde ich darüber klagen, dass mein Arbeitsgerät, ein Notebook, zwei Kilo wiegt.
<G-vec00132-002-s275><complain.klagen><en> People suffering from Splenda side effects often complain about headaches and migraines.
<G-vec00132-002-s275><complain.klagen><de> Menschen, die über Splenda Nebenwirkungen leiden, klagen oft über Kopfschmerzen und Migräne.
<G-vec00132-002-s276><complain.klagen><en> About half of the women in labor usually complain of chills and the fact that their teeth chatter during childbirth.
<G-vec00132-002-s276><complain.klagen><de> Etwa die Hälfte der Frauen in der Arbeit klagen in der Regel über Schüttelfrost und die Tatsache, dass ihre Zähne während der Geburt klappern.
<G-vec00132-002-s277><complain.klagen><en> Busy people often complain, though, about the lack of time and the difficulties of being able to integrate a seminar into their work and family life.
<G-vec00132-002-s277><complain.klagen><de> Vielbeschäftige klagen jedoch häufig über Zeitmangel und die Schwierigkeit, ein Seminar in ihren Arbeits- und Familienalltag integrieren zu können.
<G-vec00132-002-s278><complain.klagen><en> The armor is now in use for 3 months and I can not complain.
<G-vec00132-002-s278><complain.klagen><de> Die Rüstung ist mittlerweile seit 3 Monaten im Einsatz und ich kann nicht klagen.
<G-vec00132-002-s279><complain.klagen><en> They grumble and complain and reject a creator and sustainer of all things because they have no capacity to recognize God in that misery that followed the work of destruction.
<G-vec00132-002-s279><complain.klagen><de> Sie murren und klagen und lehnen einen Schöpfer und Erhalter aller Dinge ab, denn sie vermögen Gott nicht zu erkennen in jener Not, die durch das Vernichtungswerk eingetreten ist.
<G-vec00132-002-s280><complain.klagen><en> While the Hmong in the rain forest are being hunted by the military other members of this people complain of massive discrimination.
<G-vec00132-002-s280><complain.klagen><de> Während die Hmong im Regenwald vom Militär gejagt werden, klagen andere Angehörige dieser Volksgruppe über massive Diskriminierung.
<G-vec00132-002-s281><complain.klagen><en> For example, mountain bikers often complain of numb feet after a downhill race.
<G-vec00132-002-s281><complain.klagen><de> So klagen Mountainbiker oftmals über taube Füße nach einer Downhill-Tour.
<G-vec00132-002-s282><complain.klagen><en> Many parents complain of long queues in front of the waiting room of the dentist.
<G-vec00132-002-s282><complain.klagen><de> Viele Eltern Klagen über lange Schlangen vor dem Wartezimmer eines Zahnarztes.
<G-vec00132-002-s283><complain.klagen><en> Patients affected complain of dyspnoea and a deterioration in capacity.
<G-vec00132-002-s283><complain.klagen><de> Die Betroffenen klagen über Leistungseinschränkung und Atemnot.
<G-vec00132-002-s284><complain.klagen><en> Often after the start of use of such drugs, consumers complain of insomnia, heart pain and irritation.
<G-vec00132-002-s284><complain.klagen><de> Oft nach dem Beginn der Verwendung solcher Medikamente Käufer klagen über Schlaflosigkeit, Herzschmerzen und Irritation.
<G-vec00132-002-s285><complain.klagen><en> Patients complain of morning fatigue, defecation with the release of blood and mucus, anemia (with the loss of large amounts of blood), soreness of the joints.
<G-vec00132-002-s285><complain.klagen><de> Die Patienten klagen über morgendliche Müdigkeit, Defäkation mit Freisetzung von Blut und Schleim, Anämie (mit dem Verlust großer Blutmengen), Gelenkschmerzen.
<G-vec00132-002-s286><complain.klagen><en> In some cases, exacerbation of the diseaseaccompanied by a deterioration of well-being - patients complain of weakness, increased fatigue.
<G-vec00132-002-s286><complain.klagen><de> In einigen Fällen Verschlimmerung der Krankheitbegleitet von einer Verschlechterung des Wohlbefindens - Patienten klagen über Schwäche, erhöhte Müdigkeit.
<G-vec00132-002-s287><complain.klagen><en> Many people who try intermittent fasting complain about hunger pains, fatigue, exhaustion and cravings, which makes sense considering that you skip meals.
<G-vec00132-002-s287><complain.klagen><de> Viele Menschen, die intermittierendes Fasten ausprobieren, klagen über großes Hungergefühl, Müdigkeit, Erschöpfung aber auch über Heißhungerattacken.
<G-vec00132-002-s288><complain.klagen><en> Children's homes, day care centers, or other similar establishments complain about the lack of staff and financial resources and are dependent on the help of national or international volunteers.
<G-vec00132-002-s288><complain.klagen><de> Kinderheime, Tagesstätten oder ähnliche Einrichtungen klagen über zu wenig Personal oder Geldmittel und sind auf die Hilfe von Freiwilligen aus dem In- und Ausland angewiesen.
<G-vec00132-002-s289><complain.klagen><en> Many pregnant women complain of “swollen legs”, especially in summer.
<G-vec00132-002-s289><complain.klagen><de> Gerade im Sommer klagen viele Schwangere über „dicke Beine“.
<G-vec00132-002-s290><complain.klagen><en> In some cases, women complain of discharge, pain during sexual intercourse and small bleeding after it.
<G-vec00132-002-s290><complain.klagen><de> In einigen Fällen klagen Frauen über Entlassung, Schmerzen beim Geschlechtsverkehr und kleine Blutungen danach.
<G-vec00132-002-s291><complain.klagen><en> This disease occurs in almost half of future mothers: they complain of weakness, fatigue.
<G-vec00132-002-s291><complain.klagen><de> Diese Krankheit tritt bei fast der Hälfte der zukünftigen Mütter auf: Sie klagen über Schwäche, Müdigkeit.
<G-vec00132-002-s292><complain.klagen><en> Chronic fatigue syndrome: in our performance oriented world, many people complain of the so-called chronic fatigue syndrome.
<G-vec00132-002-s292><complain.klagen><de> Chronisches Erschöpfungssyndrom: In unserer leistungsorientierten Welt klagen viele Menschen über das sogenannte chronische Erschöpfungssyndrom.
<G-vec00132-002-s293><complain.klagen><en> About 80% of patients complain of heartburn, belching, pain in the right upper quadrant, flatulence, diarrhea and constipation.
<G-vec00132-002-s293><complain.klagen><de> Etwa 80% der Patienten klagen über Sodbrennen, Aufstoßen, Schmerzen im rechten oberen Quadranten, Blähungen, Durchfall und Verstopfung.
<G-vec00132-002-s294><complain.klagen><en> Fishermen complain of rising costs and declining catches.
<G-vec00132-002-s294><complain.klagen><de> Fischer klagen über steigende Kosten und sinkende Fänge.
<G-vec00132-002-s295><complain.klagen><en> Also, sick people often complain of burning the genitals.
<G-vec00132-002-s295><complain.klagen><de> Auch kranke Menschen klagen oft über brennende Genitale.
<G-vec00132-002-s296><complain.klagen><en> In other cases, patients complain of massive symptoms, for which a doctor using his diagnostic procedures is pretty much unable to recognize any causes.
<G-vec00132-002-s296><complain.klagen><de> In anderen Fällen klagen Patienten über massive Beschwerden, für die der Arzt mithilfe seiner diagnostischen Maßnahmen kaum Ursachen erkennen kann.
<G-vec00132-002-s297><complain.klagen><en> Children often complain of headache, drowsiness and apathy.
<G-vec00132-002-s297><complain.klagen><de> Kinder klagen häufig über Kopfschmerzen, Schläfrigkeit und Apathie.
<G-vec00132-002-s298><complain.klagen><en> Patients often complain of back pain and less about pain in the leg.
<G-vec00132-002-s298><complain.klagen><de> Patienten klagen häufig über Rückenschmerzen und weniger über Schmerzen im Bein.
<G-vec00132-002-s299><complain.klagen><en> Therefore submit to God's will when you are affected by adversity and suffering, don't grumble and complain, bow down to His orders and lift your eyes up only to Him.
<G-vec00132-002-s299><complain.klagen><de> Darum ergebet euch in den Willen Gottes, so ihr betroffen werdet von Not und Leid, murret und klaget nicht, beuget euer Haupt unter Seine Anordnungen, und richtet eure Augen nur auf zu Ihm.
<G-vec00132-002-s300><complain.klagen><en> Unfortunately you don’t very often take advantage of My help, and thus you complain about your burden and frequently protest its weight....
<G-vec00132-002-s300><complain.klagen><de> Aber ihr nehmet Meine Hilfe leider nicht oft in Anspruch, und darum klaget ihr ob der Last und murret oft, daß es für euch zu schwer sei....
<G-vec00132-002-s443><complain.klagen><en> Certain movements and activities over a longer period of time cause many people to complain of dizziness, cold sweats, nausea, and headaches.
<G-vec00132-002-s443><complain.klagen><de> Bestimmte Bewegungsabläufe und Tätigkeiten über einen längeren Zeitraum sorgen dafür, dass viele Menschen über Schwindel, kalten Schweiß, Übelkeit und Kopfschmerz klagen.
<G-vec00132-002-s444><complain.klagen><en> This treatment with Orthomol Arthro has proven itself mainly in marathon runners, who often complain of cartilage pain as a result of high levels of exertion – but also in patients who I have to operate on with cartilage damage.
<G-vec00132-002-s444><complain.klagen><de> Die Therapie mit Orthomol Arthro hat sich vor allem bei Marathonläufern bewährt, die oft über Knorpelschmerzen infolge der hohen Belastung klagen – aber auch bei den Patienten, die ich mit Knorpelschäden operieren musste.
<G-vec00132-002-s301><complain.meckern><en> Facilities and location are perfect, the approach could be a bit better, but that's in Iceland so, therefore no real reason to complain.
<G-vec00132-002-s301><complain.meckern><de> Einrichtung und Lage sind perfekt, die Zufahrt könnte etwas besser sein, aber das ist halt in Island so, also kein wirklicher Grund zum Meckern.
<G-vec00132-002-s302><complain.meckern><en> We do have something to complain about, though. If the ports were marked on the case's uppers side, you wouldn't have to twist your neck every time you're looking for an USB port.
<G-vec00132-002-s302><complain.meckern><de> Zu meckern haben wir aber doch noch was: Wenn die Ports an der Oberseite des Gehäuses beschriftet wären, müsste man sich nicht jedes Mal den Hals auf der Suche nach einem USB-Port verrenken.
<G-vec00132-002-s303><complain.meckern><en> We don't have anything to complain about - we will come back again.
<G-vec00132-002-s303><complain.meckern><de> Wir haben nichts zu meckern - wir werden wieder kommen.
<G-vec00132-002-s304><complain.meckern><en> Footballers always complain about it being tiring.
<G-vec00132-002-s304><complain.meckern><de> Fußballer meckern immer, dass es so anstrengend ist.
<G-vec00132-002-s305><complain.meckern><en> The look of the angular Nukeproof Neutron stem is a matter of taste, but there is nothing to complain about regarding the cockpit dimensions (50 mm stem / 780 mm bars).
<G-vec00132-002-s305><complain.meckern><de> Die Optik des kantigen Nukeproof Neutron-Vorbaus ist Geschmackssache, an den Abmessungen des Cockpits (50 mm lang/780 mm breit) gibt es dagegen nichts zu meckern.
<G-vec00132-002-s306><complain.meckern><en> No, we surely can't complain about the live qualities of the former Babys and Bad English singer, who belongs to those oversea musicians, who still think, Germany is the Mekka of Music.
<G-vec00132-002-s306><complain.meckern><de> Nein, man kann wieder einmal durchaus nicht meckern über die Live Qualitäten des ehemaligen Babys and Bad English Sängers, der genauso wie etliche andere Oversea Musiker zu denen zählt, die denken, dass Deutschland für ihre Musik immer noch das Schlaraffenland wäre.
<G-vec00132-002-s307><complain.meckern><en> There is really nothing to complain about, except that sometimes there are simply too many possibilities.
<G-vec00132-002-s307><complain.meckern><de> Es gibt eigentlich nichts zu meckern, außer dass es manchmal einfach zu viele Möglichkeiten gibt.
<G-vec00132-002-s308><complain.meckern><en> Everything was great and well priced you can not complain.
<G-vec00132-002-s308><complain.meckern><de> Es war alles super und auch preislich kann man nicht meckern.
<G-vec00132-002-s309><complain.meckern><en> Frankly, nothing to complain about, especially as Sanjaya and his wife do all this with the means at hand but they compensate with a rare kindness....
<G-vec00132-002-s309><complain.meckern><de> Ehrlich gesagt, nichts zu meckern, zumal Sanjaya und seine Frau tun dies alles mit den Mitteln zur Hand, aber sie mit einer seltenen Güte kompensieren....
<G-vec00132-002-s310><complain.meckern><en> And for those who complain about the file size, the Skins need to hold a lot MB reasonably look good.
<G-vec00132-002-s310><complain.meckern><de> Und für alle die über die Dateigröße meckern, die Skins brauchen halt viel MB um einigermaßen gut auszusehen.
<G-vec00132-002-s311><complain.meckern><en> Load Temperature There isn't anything to complain about in terms of temperature development, at least not in idle mode.
<G-vec00132-002-s311><complain.meckern><de> Last Temperatur Bei der Temperaturentwicklung gibt es zumindest im Idle-Betrieb nichts zu meckern.
<G-vec00132-002-s312><complain.meckern><en> No, there is actually nothing to complain about.
<G-vec00132-002-s312><complain.meckern><de> Nein, im Prinzip kann man nicht meckern.
<G-vec00132-002-s313><complain.meckern><en> This doesn't come as a surprise; after all, with her staggering potency and out-of-this-world resin production, there's not much to complain about.
<G-vec00132-002-s313><complain.meckern><de> Das sollte jedoch niemanden ĂĽberraschen; aufgrund ihrer unglaublichen Potenz und der nicht von dieser Welt stammenden Harzproduktion gibt es nicht viel zu meckern.
<G-vec00132-002-s314><complain.meckern><en> Musically speaking there's still nothing to complain about with Hubert von Goisern.
<G-vec00132-002-s314><complain.meckern><de> Musikalisch gab es bei Hubert von Goisern eh wieder nichts zu meckern.
<G-vec00132-002-s315><complain.meckern><en> As he himself was an extreme athlete he would not have liked the topic but technically he wouldn’t have anything to complain about.
<G-vec00132-002-s315><complain.meckern><de> Da er selbst Extremsportler war, hätte ihm zwar das Thema nicht gefallen, technisch hätte er aber nichts zu meckern gehabt.
<G-vec00132-002-s316><complain.meckern><en> Friendly welcome; nothing to complain about.
<G-vec00132-002-s316><complain.meckern><de> Freundlicher Empfang; nichts zu meckern.
<G-vec00132-002-s317><complain.meckern><en> We have little to complain about the processing.
<G-vec00132-002-s317><complain.meckern><de> Bei der Verarbeitung haben wir nur wenig zu meckern.
<G-vec00132-002-s318><complain.meckern><en> By far the best place to stay... there is absolutely nothing to complain about.
<G-vec00132-002-s318><complain.meckern><de> Mit Abstand die Beste Unterkunft... da gibt es absolut nichts zu meckern.
<G-vec00132-002-s319><complain.meckern><en> Be called for showers 10 Crowns, what I overpriced see as something that is the only thing would be to complain about it so far.
<G-vec00132-002-s319><complain.meckern><de> Für Duschen werden 10 Kronen aufgerufen, was ich als etwas überteuert ansehe, ist das Einzige was es bisher zu meckern gäbe.
<G-vec00132-002-s336><complain.monieren><en> Some users at a site complain that “the Wi-Fi Network sometime is slow”.
<G-vec00132-002-s336><complain.monieren><de> Einige Benutzer an einem Standort monieren, dass „das Wi-Fi-Netzwerk manchmal langsam ist“.
<G-vec00132-002-s337><complain.monieren><en> Some respondents complain about “changing values” in management.
<G-vec00132-002-s337><complain.monieren><de> Manche Befragte monieren einen „Wertewandel“ im Management.
<G-vec00132-002-s338><complain.monieren><en> At this point, it is but to complain that the FIFA “Tolerated the particularities of the transfer system in South America despite deviations from the own principles” (rain), reportedly to prevent a bleed out of the market.
<G-vec00132-002-s338><complain.monieren><de> An dieser Stelle ist aber zu monieren, dass die FIFA „Besonderheiten des Transfersystems in Südamerika trotz Abweichungen von den eigenen Grundsätzen toleriert“ (Rain), angeblich um ein Ausbluten des Marktes zu verhindern.
<G-vec00132-002-s065><complain.reklamieren><en> Damaged goods caused by transport is to immediately complain to access the supplier.
<G-vec00132-002-s065><complain.reklamieren><de> Beschädigte Ware, die durch Transport verursacht wurde, ist sofort bei Zugang beim Lieferanten zu reklamieren.
<G-vec00132-002-s066><complain.reklamieren><en> 7.2 The Customer is asked to complain the delivery company about delivered goods with obvious transport damage and to notify the Seller thusly.
<G-vec00132-002-s066><complain.reklamieren><de> 7.2 Der Kunde wird gebeten, angelieferte Waren mit offensichtlichen Transportschäden bei dem Zusteller zu reklamieren und den Verkäufer hiervon in Kenntnis zu setzen.
<G-vec00132-002-s339><complain.reklamieren><en> Finally, complain in a written form.
<G-vec00132-002-s339><complain.reklamieren><de> Reklamieren Sie schließlich schriftlich.
<G-vec00132-002-s340><complain.reklamieren><en> What you will do with the Russian Dragoon Officer Shashka Sabre – this is on your own responsibility and without any possibility to complain.
<G-vec00132-002-s340><complain.reklamieren><de> Was Sie auch mit der Schaschka tun werden, das geht auf eigene Verantwortung und ohne einer Möglichkeit sie zu reklamieren.
<G-vec00132-002-s341><complain.reklamieren><en> For consumers applies: If goods are delivered with obvious transport damage, so please complain such errors, if possible immediately to the deliverer and please contact us immediately.
<G-vec00132-002-s341><complain.reklamieren><de> Für Verbraucher gilt: Werden Waren mit offensichtlichen Transportschäden angeliefert, so reklamieren Sie solche Fehler bitte möglichst sofort beim Zusteller und nehmen Sie bitte unverzüglich Kontakt zu uns auf.
<G-vec00132-002-s342><complain.reklamieren><en> If products are damaged, we directly send them back to the manufacturer and complain to them.
<G-vec00132-002-s342><complain.reklamieren><de> Weisen Artikel Fehler auf, werden wir diese direkt an den Hersteller zurücksenden und reklamieren.
<G-vec00132-002-s343><complain.reklamieren><en> The warranty means that you as a customer can complain about defects in the goods that have occurred within 24 months after purchase.
<G-vec00132-002-s343><complain.reklamieren><de> Das Reklamationsrecht bedeutet, dass Sie als Kunde Fehler und Mängel an der Ware reklamieren können, die innerhalb von 24 Monaten nach dem Kauf aufgetreten sind.
<G-vec00132-002-s428><complain.reklamieren><en> If goods are delivered with obvious transport damage, please complain about such damage immediately to the deliverer and contact us as soon as possible.
<G-vec00132-002-s428><complain.reklamieren><de> Werden Waren mit offensichtlichen Transportschäden angeliefert, so reklamieren Sie solche Schäden bitte sofort bei dem Zusteller und nehmen Sie schnellstmöglich Kontakt zu uns auf.
<G-vec00132-002-s429><complain.reklamieren><en> Delivered § 9.1 If goods with obvious shipping damage, please complain such errors immediately to the deliverer, and please do not hesitate to contact us as soon as possible.
<G-vec00132-002-s429><complain.reklamieren><de> § 9.1 Werden Waren mit offensichtlichen Transportschäden angeliefert, so reklamieren Sie solche Fehler bitte sofort bei dem Zusteller, und nehmen Sie bitte schnellstmöglich Kontakt zu uns.
<G-vec00132-002-s430><complain.reklamieren><en> If our goods are supplied with obvious transport damage, please complain about this immediately to the freight forwarder and get in touch with us without delay.
<G-vec00132-002-s430><complain.reklamieren><de> Sollte unsere Ware mit offensichtlichen Transportschäden angeliefert werden, so reklamieren Sie dies bitte sofort beim Zusteller und nehmen Sie unverzüglich Kontakt zu uns auf.
<G-vec00132-002-s431><complain.reklamieren><en> If goods are delivered with obvious transportation damages, please complain about such errors to the delivery service as soon as possible and please contact us immediately.
<G-vec00132-002-s431><complain.reklamieren><de> Werden Waren mit offensichtlichen Transportschäden angeliefert, so reklamieren Sie solche Fehler bitte möglichst sofort beim Zusteller und nehmen Sie bitte unverzüglich Kontakt zu uns auf.
<G-vec00132-002-s432><complain.reklamieren><en> § 10.2 If goods are delivered with evident transport damage, please complain of such faults immediately to the forwarding agent and get in touch with us as quickly as possible (+49 2041 / 777-2 777).
<G-vec00132-002-s432><complain.reklamieren><de> § 10.2 Werden Waren mit offensichtlichen Transportschäden angeliefert, so reklamieren Sie solche Fehler bitte sofort bei dem Zusteller und nehmen Sie bitte schnellstmöglich Kontakt zu uns auf unter +49 2041 / 777-2 777.
<G-vec00132-002-s344><complain.schimpfen><en> Of course it would be unfair to do nothing but complain.
<G-vec00132-002-s344><complain.schimpfen><de> Unfair wäre es natürlich, nur zu schimpfen.
<G-vec00132-002-s345><complain.schimpfen><en> Germany has forced this meeting with the troika and is demanding impossible reforms, some commentators complain.
<G-vec00132-002-s345><complain.schimpfen><de> Deutschland hat Athen zu dem Treffen mit der Troika gezwungen und verlangt unerfüllbare Reformen, schimpfen einige Kommentatoren.
<G-vec00132-002-s069><complain.sich_beklagen><en> While some say that German companies are well prepared, others complain that the country will not wake up in time for digitalisation.
<G-vec00132-002-s069><complain.sich_beklagen><de> Während die einen behaupten, deutsche Unternehmen seien gut gerüstet, beklagen andere, die Digitalisierung werde hierzulande komplett verschlafen.
<G-vec00132-002-s070><complain.sich_beklagen><en> This abundance is not inspired, but rather annoying. Four out of five US decision-makers complain they get too much information, and on top of that it is useless and therefore, after a brief scan, lands right in the trash.
<G-vec00132-002-s070><complain.sich_beklagen><de> Diese Fülle inspiriert nicht, sondern nervt: Vier von fünf US-Entscheidern beklagen, sie würden viel zu viele Informationsangebote bekommen, die obendrein unbrauchbar seien und deshalb, nach einem kurzen Scan, direkt im Papierkorb landen.
<G-vec00132-002-s071><complain.sich_beklagen><en> As far as speed is concerned, the Panasonic Lumix FZ7 user has no reason to complain.
<G-vec00132-002-s071><complain.sich_beklagen><de> In Bezug auf die Geschwindigkeit der Panasonic Lumix FZ7 wird sich der Benutzer nicht beklagen können.
<G-vec00132-002-s072><complain.sich_beklagen><en> Citizens who complain about this failure and denounce the deplorable state of affairs are at best appointed as “scums”, at worst scolded as “Nazis”.
<G-vec00132-002-s072><complain.sich_beklagen><de> Die Bürger, die das Versagen beklagen und die Missstände anprangern, werden bestenfalls als «Pack», schlimmstenfalls als «Nazi» beschimpft.
<G-vec00132-002-s073><complain.sich_beklagen><en> And the noise is due to the fact that the Europeans, in particular the Germans – since in the meantime maudlin sentimentality has of course become the new German virtue – do nothing but complain about Europe, instead of taking pleasure and rejoicing in Europe.
<G-vec00132-002-s073><complain.sich_beklagen><de> Und der Lärm entsteht deshalb, weil die Europäer, vor allem die Deutschen – weil Larmoyanz ja die neue deutsche Tugend geworden ist – sich über Europa nur noch beklagen, statt sich an Europa und über Europa zu freuen.
<G-vec00132-002-s074><complain.sich_beklagen><en> Leon Frim: So, then my son started to complain that he had pain in the area of the kidneys.
<G-vec00132-002-s074><complain.sich_beklagen><de> Leon Frim: Also damals hat sich mein Sohn angefangen schon zu beklagen, dass er Schmerzen in der Gegend von der Niere hat.
<G-vec00132-002-s075><complain.sich_beklagen><en> Although we had been looking forward but at the ultra-modern facilities and the huge balcony we got instead we could complain on a cute little, typical Mallorcan apartment us in any case.
<G-vec00132-002-s075><complain.sich_beklagen><de> Zwar hatten wir uns auf ein süßes, kleines, typisch mallorquinisches Apartment gefreut aber bei der ultramodernen Ausstattung und dem Riesen Balkon den wir stattdessen bekamen konnten wir uns auf keinen Fall beklagen.
<G-vec00132-002-s076><complain.sich_beklagen><en> Citizens complain of an imbalance in terms of fairness: In one survey conducted by opinion and market research institution Institut für Demoskopie Allensbach this year, nearly 70 percent of respondents stated that economic conditions are unfair, and 64 percent believed the imbalance was going to increase.
<G-vec00132-002-s076><complain.sich_beklagen><de> Die Bürger beklagen eine Gerechtigkeitslücke: In einer Umfrage des Instituts Demoskopie Allensbach von diesem Jahr gaben fast 70 Prozent der Befragten an, dass die wirtschaftlichen Verhältnisse ungerecht seien, und 64 Prozent waren der Ansicht, die Schieflage würde sich verstärken.
<G-vec00132-002-s077><complain.sich_beklagen><en> When sacrificing a little more for the family, I often felt unbalanced and began to complain.
<G-vec00132-002-s077><complain.sich_beklagen><de> Wenn ich für die Familie etwas mehr opferte, fühlte ich mich oft unausgeglichen und begann, mich zu beklagen.
<G-vec00132-002-s078><complain.sich_beklagen><en> During pregnancy, the intensity of metabolic processes in the body increases, which leads, on the one hand, to excessive sweating, and on the other - to a decrease in the sensitivity of pregnant women to cold: they often complain that they are hot, less likely to freeze, which to some extent increases the probability of freezing .
<G-vec00132-002-s078><complain.sich_beklagen><de> Während der Schwangerschaft nimmt die Intensität der Stoffwechselvorgänge im Körper zu, was einerseits zu übermäßigem Schwitzen und andererseits zu einer Abnahme der Kälteempfindlichkeit der Schwangeren führt: Sie beklagen oft, dass sie heiß sind, weniger gefrieren, was die Einfrierwahrscheinlichkeit erhöht .
<G-vec00132-002-s079><complain.sich_beklagen><en> “Many women complain about the loss of volume, shape and stability of their breasts after pregnancy.
<G-vec00132-002-s079><complain.sich_beklagen><de> „Viele Frauen beklagen nach einer Schwangerschaft den Verlust an Brustvolumen, Form und Stabilität.
<G-vec00132-002-s080><complain.sich_beklagen><en> It is true, we will constantly direct our attention mainly to the spiritual well-being of the nation entrusted to us by God for leadership, but also in the natural respect no-one should have to complain about any pressing need, particularly if he is spiritually in good order.
<G-vec00132-002-s080><complain.sich_beklagen><de> Zwar werden wir stets unsere Aufmerksamkeit hauptsächlich auf das geistige Wohl der uns von Gott zur Leitung anvertrauten Völker richten, aber auch in naturmäßiger Hinsicht soll sich niemand über irgendeine drückende Not zu beklagen haben, besonders, wenn er einmal geistig in der Ordnung ist.
<G-vec00132-002-s081><complain.sich_beklagen><en> In actual fact, Karl Wehner, who is responsible for increasing the number of collaborations, can’t complain about having too little to do.
<G-vec00132-002-s081><complain.sich_beklagen><de> Tatsächlich kann sich Karl Wehner, dessen Aufgabe der Ausbau der Kooperationen ist, nicht über zu wenig Arbeit beklagen.
<G-vec00132-002-s082><complain.sich_beklagen><en> Companies frequently complain about the onerous and divergent documentation obligations with which they have to comply in such cases in the different Member States involved.
<G-vec00132-002-s082><complain.sich_beklagen><de> Die Unternehmen beklagen häufig die kostenaufwendigen und unterschiedlichen Dokumentationspflichten, die sie in solchen Fällen in den einzelnen beteiligten Mitgliedstaaten erfüllen müssen.
<G-vec00132-002-s083><complain.sich_beklagen><en> However, Geisel knows no qualms when it comes to Russia boycotts, a country that had to complain thanks to our “help” 27 million war dead.
<G-vec00132-002-s083><complain.sich_beklagen><de> Allerdings kennt Geisel keine Skrupel, wenn es um Russland-Boykotte geht, einem Land, dass dank unserer „Hilfe“ 27 Millionen Kriegstote zu beklagen hatte.
<G-vec00132-002-s084><complain.sich_beklagen><en> But countries with external borders, such as Greece and Italy, naturally complain that this puts an unfair burden on them.
<G-vec00132-002-s084><complain.sich_beklagen><de> Aber Länder mit Außengrenzen wie Griechenland und Italien beklagen natürlich, dass dies eine unzumutbare Belastung für sie darstellt.
<G-vec00132-002-s085><complain.sich_beklagen><en> We have complained enough that we are locked inside our own language; it is time to not just complain but to do something about it.
<G-vec00132-002-s085><complain.sich_beklagen><de> Wir haben uns genug darüber beklagt, dass wir in unsere eigene Sprache eingesperrt sind, es ist an der Zeit, uns nicht mehr nur zu beklagen, sondern auch etwas zu tun.
<G-vec00132-002-s086><complain.sich_beklagen><en> We’ve been cooperating for over 3 years now and I really can’t complain.
<G-vec00132-002-s086><complain.sich_beklagen><de> Wir arbeiten seit über 3 Jahren zusammen und ich kann mich wirklich nicht beklagen.
<G-vec00132-002-s087><complain.sich_beklagen><en> Critics complain that anything original loses its contents and form, since we live in an age where almost everything is possible so the impossible becomes possible.
<G-vec00132-002-s087><complain.sich_beklagen><de> Kritiker beklagen, dass das Ursprüngliche seine Inhalte und Formen verliert, da wir in einer Zeit leben in der fast alles möglich ist und auch das Unmögliche möglich wird.
<G-vec00132-002-s088><complain.sich_beklagen><en> Also, many complain about the lack of time for cooking individual, low-calorie meals (especially when the rest of the family dine with borscht and cutlets), as well as the banal lack of willpower to limit oneself in a chocolate bar at night.
<G-vec00132-002-s088><complain.sich_beklagen><de> Außerdem beklagen sich viele über den Mangel an Zeit für das Kochen von individuellen, kalorienarmen Mahlzeiten (vor allem, wenn der Rest der Familie mit Borschtsch und Schnitzel diniert), sowie die banale Willensnot, sich in einer Schokoriegel in der Nacht zu beschränken.
<G-vec00132-002-s089><complain.sich_beklagen><en> Many murmur and complain.
<G-vec00132-002-s089><complain.sich_beklagen><de> Viele murren und beklagen sich.
<G-vec00132-002-s090><complain.sich_beklagen><en> During the battle of Elli the Barbaros Hayreddin was damaged, had to complain 7 dead and 14 wounded and the Ottoman ships were forced to retreat to the Greek ships.
<G-vec00132-002-s090><complain.sich_beklagen><de> Während des Gefechtes von Elli wurde die Barbaros Hayreddin beschädigt, hatte 7 Tote und 14 Verwundete zu beklagen und die osmanischen Schiffe mussten sich gegenüber den griechischen Schiffen zurückziehen.
<G-vec00132-002-s091><complain.sich_beklagen><en> Aghast at the scenes of armored vehicles and cops pointing M-16 assault rifles at residents in the Ferguson war zone (where journalists have been among those treated like enemies, tear-gassed and arrested), liberals complain about “excessive” force.
<G-vec00132-002-s091><complain.sich_beklagen><de> Liberale, bestürzt über Szenen von Panzerfahrzeugen und Bullen, die in der Kriegszone von Ferguson M-16-Sturmgewehre auf Bewohner richten (wo auch Journalisten wie Feinde behandelt, mit Tränengas beschossen und verhaftet werden), beklagen sich über „exzessive“ Gewalt.
<G-vec00132-002-s092><complain.sich_beklagen><en> A "ban on spam" has been part of EU law since 2003, but 65% of Europeans still complain about "excessive spam".
<G-vec00132-002-s092><complain.sich_beklagen><de> Ein „Spam-Verbot“ ist seit 2003 Bestandteil des EU-Rechts, aber 65 % der Europäer beklagen sich noch immer über zu viel unerwünschte Werbezusendungen.
<G-vec00132-002-s093><complain.sich_beklagen><en> “Many companies complain about a shortage of IT specialists, engineers and high potentials.
<G-vec00132-002-s093><complain.sich_beklagen><de> „Viele Unternehmen beklagen sich über einen Mangel an IT-Spezialisten, Ingenieuren und High Potentials.
<G-vec00132-002-s094><complain.sich_beklagen><en> [People usually complain that music is so ambiguous; it is so problematic that they don't know what to think of it, but that words can each be understood.
<G-vec00132-002-s094><complain.sich_beklagen><de> "Die Leute beklagen sich gewöhnlich, die Musik sei so vieldeutig; es sei so zweifelhaft, was sie sich dabei zu denken hätten, und die Worte verstände doch ein jeder.
<G-vec00132-002-s095><complain.sich_beklagen><en> - Don't complain if he's late home for dinner or even if he stays out all night.
<G-vec00132-002-s095><complain.sich_beklagen><de> Beklagen Sie sich nicht, wenn er spät heimkommt oder selbst wenn er die ganze Nacht ausbleibt.
<G-vec00132-002-s096><complain.sich_beklagen><en> JF: Some organisers do complain about the increasing age of the audience in concert halls.
<G-vec00132-002-s096><complain.sich_beklagen><de> JF: Einige Veranstalter beklagen sich, dass das Publikum in den Konzertsälen immer älter wird.
<G-vec00132-002-s097><complain.sich_beklagen><en> Controllers who create Report Books on a regular basis (and that is the majority) complain that 80% of their time is taken up with assembling the figures and the components and producing the final layout.
<G-vec00132-002-s097><complain.sich_beklagen><de> Die Controller, die revolvierend Report Books erstellen (und dies ist die überwiegende Anzahl), beklagen sich, dass ihre Arbeit zu 80% aus dem Zusammenbringen der Zahlen und der Komponenten und dem finalen Layout besteht.
<G-vec00132-002-s099><complain.sich_beklagen><en> They complain of excessive sexual thoughts and impulses and enquire whether it will be an impediment in their spiritual path.
<G-vec00132-002-s099><complain.sich_beklagen><de> Sie beklagen sich über exzessive sexuelle Gedanken und Impulse und wollen wissen, ob diese ein Hindernis für ihren spirituellen Weg wären.
<G-vec00132-002-s100><complain.sich_beklagen><en> According to the Swiss bureau of statistics over 40% of Swiss workers complain that there are not enough sources of fresh, healthy food available at work.
<G-vec00132-002-s100><complain.sich_beklagen><de> Gemäss Bundesamt für Statistik beklagen sich nämlich über 40% der Schweizer, dass es keine geeigneten Verpflegungsmöglichkeiten gibt am Arbeitsplatz.
<G-vec00132-002-s101><complain.sich_beklagen><en> Like Küppers, educators and teachers across the country complain about the lack of support and understanding from political leaders.
<G-vec00132-002-s101><complain.sich_beklagen><de> Wie Küppers beklagen sich bundesweit Pädagogen und Lehrer über mangelnde Unterstützung und Verständnis seitens der Politik.
<G-vec00132-002-s102><complain.sich_beklagen><en> Situated in a shopping centre, the Confédération Centre, this bistro restaurant in Geneva cannot complain about a lack of visitors; its menu is therefore accordingly diverse.
<G-vec00132-002-s102><complain.sich_beklagen><de> Untergebracht in einem Einkaufszentrum, dem Confédération Centre, kann sich das Bistro-Restaurant in Genf nicht über Besuchermangel beklagen; dementsprechend vielseitig präsentiert sich seine Speisekarte.
<G-vec00132-002-s103><complain.sich_beklagen><en> But Ann didn’t complain.
<G-vec00132-002-s103><complain.sich_beklagen><de> Aber Ann beklagte sich nicht.
<G-vec00132-002-s104><complain.sich_beklagen><en> In those letters he would, e.g., complain about not being able to get his hands on scholarly journals (Bänninger 1941, Hs 931: 1679) and how the war in general made collecting more difficult for him (Bänninger 1944, Hs 931: 1788).
<G-vec00132-002-s104><complain.sich_beklagen><de> In den Briefen aus jener Zeit beklagte sich Bänninger beispielsweise darüber, dass er bestimmte wissenschaftliche Zeitschriften nicht bekommen könne (Bänninger 1941, Hs 931: 1679) und dass ihm durch den Krieg das Sammeln allgemein schwergemacht werde (Bänninger 1944, Hs 931: 1788).
<G-vec00132-002-s320><complain.sich_beklagen><en> This field is not the easiest in the insurance industry, therefore I cannot complain about any lack of tasks and challenges.
<G-vec00132-002-s320><complain.sich_beklagen><de> Dieses Gebiet ist nicht das einfachste innerhalb der Versicherungsbranche, daher kann ich mich über einen Mangel an Aufgaben und Herausforderungen nicht beklagen.
<G-vec00132-002-s321><complain.sich_beklagen><en> I can’t really complain about too many tourists, as I’m one of them.
<G-vec00132-002-s321><complain.sich_beklagen><de> Ich kann mich nicht wirklich über zu viele Touristen beklagen, schließlich bin ich ja eine von ihnen.
<G-vec00132-002-s322><complain.sich_beklagen><en> I used up a fair amount of my Polaroid films but I shouldn’t complain.
<G-vec00132-002-s322><complain.sich_beklagen><de> Ich habe eine ganze Menge meiner Polaroid-Filme, aber ich sollte mich nicht beklagen.
<G-vec00132-002-s323><complain.sich_beklagen><en> As a rider I try not to complain too much because at the end of the day a race is a race and it should be the same for everyone.
<G-vec00132-002-s323><complain.sich_beklagen><de> Als Fahrer versuche ich, mich nicht allzu viel zu beklagen, denn schlussendlich ist es einfach ein Rennen, und es sollte für alle das gleiche sein.
<G-vec00132-002-s324><complain.sich_beklagen><en> But as a Frenchman I can’t complain.
<G-vec00132-002-s324><complain.sich_beklagen><de> Aber als Franzose kann ich mich nicht beklagen.
<G-vec00132-002-s384><complain.sich_beklagen><en> 36 And they came to a place which was named Gethsemane, which was a garden; and the disciples began to be sore amazed, and to be very heavy, and to complain in their hearts, wondering if this be the Messiah.
<G-vec00132-002-s384><complain.sich_beklagen><de> 36 Und sie kamen an einen Ort, der Getsemani genannt wurde und ein Garten war; und die Jünger fingen an, sehr bestürzt zu sein und sehr geängstigt zu sein und sich in ihrem Herzen zu beklagen und sich zu fragen, ob dies der Messias sei.
<G-vec00132-002-s385><complain.sich_beklagen><en> So great an undertaking can not complain about the lack of interest in its products.
<G-vec00132-002-s385><complain.sich_beklagen><de> Ein so großes Unternehmen kann sich nicht über ein mangelndes Interesse an seinen Produkten beklagen.
<G-vec00132-002-s386><complain.sich_beklagen><en> (6) Like to complain about others without looking inward.
<G-vec00132-002-s386><complain.sich_beklagen><de> (6) Sich über andere zu beklagen, ohne nach innen zu schauen.
<G-vec00132-002-s387><complain.sich_beklagen><en> And TukTuk Factory has no reason to complain about a lack of demand.
<G-vec00132-002-s387><complain.sich_beklagen><de> Und die TukTuk Factory kann sich über mangelnde Nachfrage nicht beklagen.
<G-vec00132-002-s388><complain.sich_beklagen><en> Zedler and his team have no reason to complain about a lack of acknowledgement and awards.
<G-vec00132-002-s388><complain.sich_beklagen><de> Über einen Mangel an Anerkennung und Auszeichnungen können Zedler und sein Team sich kaum beklagen.
<G-vec00132-002-s389><complain.sich_beklagen><en> So Gerlinde can not complain about a lack of work.
<G-vec00132-002-s389><complain.sich_beklagen><de> Über mangelnde Arbeit kann sich Gerlinde also nicht beklagen.
<G-vec00132-002-s390><complain.sich_beklagen><en> He is clearly positioned in the business and therefore does not have to complain about a lack of jobs as a sideman.
<G-vec00132-002-s390><complain.sich_beklagen><de> Er ist klar im Geschäft positioniert und muss sich daher nicht über fehlende Jobs als Sideman beklagen.
<G-vec00132-002-s391><complain.sich_beklagen><en> The construction company founded in Dorsten/Germany in 1902 is today mainly active in multi-storey residential and industrial construction and can not complain about a lack of demand.
<G-vec00132-002-s391><complain.sich_beklagen><de> Die 1902 in Dorsten gegründete Baufirma ist heute überwiegend im Geschosswohnungs- und Industriebau tätig und kann sich über mangelnde Nachfrage nicht beklagen.
<G-vec00132-002-s392><complain.sich_beklagen><en> Many bloggers that complain about the new generation of influencers see themselves in the role of the old guard.
<G-vec00132-002-s392><complain.sich_beklagen><de> Viele der Blogger, die sich über die neue Generation der Influencer beklagen, sehen sich selbst in der Rolle der alteingesessenen Hasen.
<G-vec00132-002-s393><complain.sich_beklagen><en> Schooling is part of the reason many reasonable players complain that they are unable to beat loose games.
<G-vec00132-002-s393><complain.sich_beklagen><de> Schooling ist teilweise der Grund für viele vernünftige Spieler sich zu beklagen, dass Sie unfähig sind Loose-Games (Spiele mit vielen Händen) zu schlagen.
<G-vec00132-002-s394><complain.sich_beklagen><en> Regiobahn cannot complain about a lack of passengers.
<G-vec00132-002-s394><complain.sich_beklagen><de> Über Fahrgastmangel kann sich die Regiobahn nicht beklagen.
<G-vec00132-002-s395><complain.sich_beklagen><en> If anyone has a right to complain about the evil in the world, it is God.
<G-vec00132-002-s395><complain.sich_beklagen><de> Wenn es jemanden gibt, der das Recht hat, sich über das Böse in der Welt zu beklagen, dann ist es Gott.
<G-vec00132-002-s396><complain.sich_beklagen><en> Nor does the pianist have reason to complain of any lack of technical demands and soloistic brilliance.
<G-vec00132-002-s396><complain.sich_beklagen><de> In den hier eingespielten Werken für Viola und Klavier kann sich auch der Pianist nicht über einen Mangel an technischen Anforderungen und solistischem Glanz beklagen.
<G-vec00132-002-s397><complain.sich_beklagen><en> We are human beings, and humans love to complain.
<G-vec00132-002-s397><complain.sich_beklagen><de> Wir sind Menschen, und Menschen lieben es, sich zu beklagen.
<G-vec00132-002-s398><complain.sich_beklagen><en> One or two colleagues also went to the boss to complain about me.
<G-vec00132-002-s398><complain.sich_beklagen><de> Es gingen auch ein oder zwei Kollegen zum Boss, um sich über mich zu beklagen.
<G-vec00132-002-s399><complain.sich_beklagen><en> To complain about special Franco-German agreements – actual or feared - is irrelevant and can give rise to negative consequences.
<G-vec00132-002-s399><complain.sich_beklagen><de> Sich über – bereits abgeschlossene oder befürchtete – deutsch-französische Sonderabkommen zu beklagen, ist nicht nur irreführend, sondern könnte auch negative Folgen haben.
<G-vec00132-002-s400><complain.sich_beklagen><en> When clients complain about ‚restlessness‘ after a change in their social panorama, one should first check if new double representations have occurred.
<G-vec00132-002-s400><complain.sich_beklagen><de> Wenn sich Klienten nach einer Verschiebung in ihrem Sozialen Panorama über eine „Unruhe“ beklagen, dann achte besonders darauf, ob doppelte Repräsentationen einer Person aufgetreten sind.
<G-vec00132-002-s401><complain.sich_beklagen><en> After all, they will not complain and whine, on the contrary, they will try to entertain the interlocutor.
<G-vec00132-002-s401><complain.sich_beklagen><de> Schließlich werden sie sich nicht beklagen und jammern, im Gegenteil, sie werden versuchen, den Gesprächspartner zu unterhalten.
<G-vec00132-002-s402><complain.sich_beklagen><en> They are the same people who then complain, because the Lord - they say! - has abandoned them.
<G-vec00132-002-s402><complain.sich_beklagen><de> Es sind dieselben, die sich dann beklagen, der Herrgott lasse sie im Stich.
<G-vec00132-002-s433><complain.sich_beklagen><en> Of course it's not personal, so before I start apologies to you and all the other men and women that look after us and take it in the neck while we sit at home and complain.
<G-vec00132-002-s433><complain.sich_beklagen><de> Natürlich ist es nicht persönlich, also bevor ich mit Entschuldigungen anfange an dich und all die anderen Männer und Frauen, die für uns sorgen und den Hintern hinhalten während wir daheim sitzen und uns beklagen.
<G-vec00132-002-s434><complain.sich_beklagen><en> We have no reason to complain about the variety of species, nor about the number of birds, and years are not twin copies of each other.
<G-vec00132-002-s434><complain.sich_beklagen><de> Wir haben keinen Grund, uns über die Vielfalt der Arten zu beklagen, noch über die Anzahl der Vögel, und die Jahre entsprechen auch nicht eines dem anderen.
<G-vec00132-002-s435><complain.sich_beklagen><en> We can not really complain, top location, top top apartment and landlord.
<G-vec00132-002-s435><complain.sich_beklagen><de> Wir können uns wirklich nicht beklagen, Top Lage, Top Wohnung und Top Vermieter.
<G-vec00132-002-s436><complain.sich_beklagen><en> For we young people who often complain about the superficiality of people our age, here we can find all the answers and a sense of encouragement that exceeds all expectations.
<G-vec00132-002-s436><complain.sich_beklagen><de> Wir Jugendliche, die wir uns oft über die Oberflächlichkeit unserer Altersgenossen beklagen, finden hier alle Antworten und man findet eine Ermutigung, die jede Erwartung übersteigt.
<G-vec00132-002-s182><complain.sich_beschweren><en> Whenever I get cramps, I complain.
<G-vec00132-002-s182><complain.sich_beschweren><de> Wann immer ich Krämpfe kriege, beschwere ich mich.
<G-vec00132-002-s183><complain.sich_beschweren><en> I do not complain about the behavior of friends and colleagues, but accept that they act differently and react as I do.
<G-vec00132-002-s183><complain.sich_beschweren><de> Ich beschwere mich nicht über das Verhalten von Freunden und Kollegen, sondern akzeptiere, dass sie anders handeln und reagieren als ich.
<G-vec00132-002-s184><complain.sich_beschweren><en> "Though I don't complain: I have chosen this way.
<G-vec00132-002-s184><complain.sich_beschweren><de> "Aber ich beschwere mich nicht: Ich habe diesen Weg gewählt.
<G-vec00132-002-s185><complain.sich_beschweren><en> And yes there are times when I hate you but I don't complain 'Cause I've been afraid that you would walk away
<G-vec00132-002-s185><complain.sich_beschweren><de> Und ja, es gibt Zeiten in denen ich dich hasse, aber ich beschwere mich nicht, weil ich Angst habe, dass du weggehen würdest.
<G-vec00132-002-s186><complain.sich_beschweren><en> I do not complain about it, and I appreciate the work of digital stabilization, smoothness, sharpness and nice sound.
<G-vec00132-002-s186><complain.sich_beschweren><de> Ich beschwere mich nicht, ich schätze den reibungslosen Betrieb der digitalen Stabilisierung, die Schärfe des Bildes und den guten Ton.
<G-vec00132-002-s187><complain.sich_beschweren><en> First I resist to accept it as my problem and complain at the airline company who had informed me about what is needed.
<G-vec00132-002-s187><complain.sich_beschweren><de> Ich weigere mich zuerst und beschwere mich bei der Fluggesellschaft wo ich mich ja vorher erkundigt hatte was erforderlich ist.
<G-vec00132-002-s188><complain.sich_beschweren><en> I wouldn´t make a complain, but after all the trouble I had with the England trip, I thought Easter will be managed by an other dog, it wouldn´t.
<G-vec00132-002-s188><complain.sich_beschweren><de> 27.03.2016 Frohe Ostern Ich will mich ja nicht beschweren, aber nach der ganzen Englandreise habe ich gedacht, Ostern würde an mir vorbei gehen, aber nichts.
<G-vec00132-002-s189><complain.sich_beschweren><en> We guarantee that If you do not feel that your purchase has lived up to your expectations, you can complain within 15days after you receive the products.
<G-vec00132-002-s189><complain.sich_beschweren><de> Wir garantieren, dass, wenn Sie nicht glauben, dass Ihr Kauf bis zu Ihren Erwartungen gelebt hat, Sie innerhalb 15days dich beschweren können, nachdem Sie die Produkte empfangen.
<G-vec00132-002-s190><complain.sich_beschweren><en> So I should not complain when I meet people who are suspicious of Eastern Europeans dabbling with the performing arts.)
<G-vec00132-002-s190><complain.sich_beschweren><de> Deswegen dürfte ich mich eigentlich nicht beschweren, wenn ich Leute kennen lerne, die misstrauisch werden, wenn Osteuropäer auf dem Gebiet der darstellenden Künste herumstümpern.
<G-vec00132-002-s191><complain.sich_beschweren><en> There’s a saying in this country that if you don’t vote, you don’t get to to complain.
<G-vec00132-002-s191><complain.sich_beschweren><de> Es gibt ein Spruch in diesem Land, der besagt, dass wenn du nicht wählen gehst, dann darfst du dich nicht beschweren.
<G-vec00132-002-s192><complain.sich_beschweren><en> I have to realize that I need more time for my daily activities and I have to accept some restrictions, but there is no real reason to complain as long as my brain still works fine.
<G-vec00132-002-s192><complain.sich_beschweren><de> Ich werde zwar langsamer und muss mich bei einigen Dingen etwas einschränken, aber solange der Kopf noch fit ist, möchte ich mich nicht beschweren.
<G-vec00132-002-s193><complain.sich_beschweren><en> Personally I prefer AMOLED panels but I can't complain about this screen because of the wonderful rendering and the really nice calibration Apple has done with the colors.
<G-vec00132-002-s193><complain.sich_beschweren><de> Ich persönlich präferiere AMOLED-Panels, aber ich kann mich über die Qualität dieses Displays dank der guten Performance und der tollen Farbwiedergabe nicht beschweren.
<G-vec00132-002-s194><complain.sich_beschweren><en> But since it was very cheap to rent, I can't really complain..
<G-vec00132-002-s194><complain.sich_beschweren><de> Aber da es sehr billig war zu mieten, kann ich nicht wirklich beschweren ..
<G-vec00132-002-s195><complain.sich_beschweren><en> They often request to see the property again and then complain about things that they were okay with at the time of signing the Offer to Purchase.
<G-vec00132-002-s195><complain.sich_beschweren><de> Sie verlangen oft, das Eigentum wieder zu sehen und dann über die Dinge zu beschweren, dass sie mit dem Zeitpunkt der Unterzeichnung des Angebots zum Kauf in Ordnung waren.
<G-vec00132-002-s196><complain.sich_beschweren><en> The client has the right to complain about any shortcomings of the services provided.
<G-vec00132-002-s196><complain.sich_beschweren><de> Der Kunde hat das Recht, über etwaige Mängel der erbrachten Leistungen zu beschweren.
<G-vec00132-002-s197><complain.sich_beschweren><en> I should not complain.
<G-vec00132-002-s197><complain.sich_beschweren><de> Ich sollte nicht beschweren.
<G-vec00132-002-s198><complain.sich_beschweren><en> Stupid brother, I’m so going to out-level you and I’m going to leave you with absolutely no room to complain.
<G-vec00132-002-s198><complain.sich_beschweren><de> Blöder Bruder, ich werde dich leveltechnisch so weit hinter mir lassen, dass du keinen Raum zum Beschweren hast.
<G-vec00132-002-s200><complain.sich_beschweren><en> An example: When the LED displays on the Tiananmen square, which also hosted a massacre, show a blue sky with white clouds in the midst of smog, it is easy to understand how manipulation by word and image works and we complain about "ideology."
<G-vec00132-002-s200><complain.sich_beschweren><de> Beispiel: Wenn auf dem „Platz des Himmlischen Friedens“, der auch ein Platz des Massakers ist, bei Smog LED-Bildschirme blauen Himmel und weiße Wolken zeigen, begreifen wir leicht, wie mit Worten und Bildern manipuliert wird, und beschweren uns über „Ideologie“.
<G-vec00132-002-s201><complain.sich_beschweren><en> Should you want to complain about the processing of your personal data, you may contact us via email or letter as indicated above.
<G-vec00132-002-s201><complain.sich_beschweren><de> Wenn Sie sich über die Verarbeitung Ihrer personenbezogenen Daten beschweren möchten, können Sie uns wie oben beschrieben per E-Mail oder Brief kontaktieren.
<G-vec00132-002-s202><complain.sich_beschweren><en> At the appetite but never complain, like meat and salty foods.
<G-vec00132-002-s202><complain.sich_beschweren><de> Am Appetit aber nie beschweren, wie Fleisch und salzige Lebensmittel.
<G-vec00132-002-s203><complain.sich_beschweren><en> While some guests complain about mediocre food, this resort does offer a gigantic pool with plenty of space to sunbathe.
<G-vec00132-002-s203><complain.sich_beschweren><de> Während einige Gäste über mittelmäßiges Essen beschweren, bietet dieses Resort einen gigantischen Pool mit viel Platz zum Sonnenbaden.
<G-vec00132-002-s204><complain.sich_beschweren><en> stephan2016-05-18T00:00:00Z Everything has been said in the comments! Hard to find something to complain about: kindness, attention and communication Yaelle, cleanness, equipment, close Chartreuse hikes and Grenoble (15 minutes to go to the movies or shopping, like to stroll to the Dent de Crolles) rapid familiarization with the apartment, quiet (no noise from neighbors to us), 2 terraces, food for breakfast dèj...
<G-vec00132-002-s204><complain.sich_beschweren><de> Yaelle erkundigte sich mehrmals ob alles zur Zufriedenheit war, gab Empfehlungen für Restaurants und Ausflüpge - wir haben bei ihr eine schön erholsame Woche zu beschweren: Freundlichkeit, Aufmerksamkeit und Kommunikation Yaelle, Sauberkeit, Ausstattung, in der Nähe Kartäuserkloster Wanderungen und Grenoble (15 Minuten ins Kino oder zum Einkaufen zu gehen, wie zum Dent de Crolles zum Flanieren) schnelle Einarbeitung in die Wohnung, ruhig (kein Lärm von Nachbarn zu uns), 2 Terrassen, Speisen zum Frühstück dèj...
<G-vec00132-002-s205><complain.sich_beschweren><en> This is another reason why I ask you to never complain.
<G-vec00132-002-s205><complain.sich_beschweren><de> Dies stellt einen weiteren Grund dafür dar, weswegen Ich euch bitte, euch niemals zu beschweren.
<G-vec00132-002-s206><complain.sich_beschweren><en> I mean, there’s nothing to complain about it.
<G-vec00132-002-s206><complain.sich_beschweren><de> Da gibt’s nichts zu beschweren.
<G-vec00132-002-s207><complain.sich_beschweren><en> They complain that Zapatero is too soft and gives in to pressure.
<G-vec00132-002-s207><complain.sich_beschweren><de> Sie beschweren sich, dass Zapatero zu weich sei und jedem Druck nachgebe.
<G-vec00132-002-s208><complain.sich_beschweren><en> The other girls complain about clogged pores.
<G-vec00132-002-s208><complain.sich_beschweren><de> Andere Mädchen beschweren sich über verstopfte Poren.
<G-vec00132-002-s209><complain.sich_beschweren><en> Do not complain in-topic about the subject being too far off-topic or otherwise breaking rules.
<G-vec00132-002-s209><complain.sich_beschweren><de> Beschweren Sie sich nicht im Thema, wenn das Thema zu weit vom Thema entfernt ist oder andere Regeln verletzt werden.
<G-vec00132-002-s210><complain.sich_beschweren><en> Then they complain that you are not giving out anything from you anymore.
<G-vec00132-002-s210><complain.sich_beschweren><de> Dann beschweren sie sich, dass du nichts mehr von dir preisgibst.
<G-vec00132-002-s211><complain.sich_beschweren><en> employees complain that they must log in several times a day using different user IDs.
<G-vec00132-002-s211><complain.sich_beschweren><de> Mitarbeiter beschweren sich, dass sie sich mehrmals täglich mit unterschiedlichen Benutzerkennungen anmelden müssen.
<G-vec00132-002-s212><complain.sich_beschweren><en> Coupon Companion Ads is not a malicious program, but computer users frequently complain of similar extensions and their intrusive behavior.
<G-vec00132-002-s212><complain.sich_beschweren><de> Coupon Companion Ads ist kein bösartiges Programm, aber Computernutzer beschweren sich häufig über ähnliche Erweiterungen und ihr aufdringliches Verhalten.
<G-vec00132-002-s213><complain.sich_beschweren><en> People frequently complain of the long time between Debian's stable releases, but this caution also ensures Debian's legendary reliability: long months of testing are indeed necessary for the full distribution to receive the “stable” label.
<G-vec00132-002-s213><complain.sich_beschweren><de> Oft beschweren sich Leute über den langen Zeitraum zwischen Debians stabilen Versionen, aber diese Sorgfalt gewährleistet auch seine legendäre Zuverlässigkeit: In der Tat sind monatelange Überprüfungen erforderlich, bevor die vollständige Distribution das Etikett „stabil“ erhält.
<G-vec00132-002-s214><complain.sich_beschweren><en> Also, some guests complain about the glass bathroom doors that could pose privacy issues.
<G-vec00132-002-s214><complain.sich_beschweren><de> Manche Gäste beschweren sich darüber, dass die Glas-Badezimmertüren Probleme mit dem Datenschutz darstellen.
<G-vec00132-002-s215><complain.sich_beschweren><en> Many males complain that they don't understand females.
<G-vec00132-002-s215><complain.sich_beschweren><de> Viele Männer beschweren sich, daß sie nicht Frauen verstehen.
<G-vec00132-002-s216><complain.sich_beschweren><en> Firstly, many participants in the crowdfunding campaigns complain that they have not yet received the promised toothbrush in return.
<G-vec00132-002-s216><complain.sich_beschweren><de> Zum einen beschweren sich viele Teilnehmer an den Crowdfunding-Aktionen, dass sie die als Gegenleistung versprochene Zahnbürste bislang nicht geliefert bekommen haben.
<G-vec00132-002-s217><complain.sich_beschweren><en> A lot of people, pro players included, often complain about FIFA.
<G-vec00132-002-s217><complain.sich_beschweren><de> Viele Leute, auch Profispieler, beschweren sich häufig über die FIFA.
<G-vec00132-002-s218><complain.sich_beschweren><en> Hawaii residents often times complain about the islands’ high cost of living.
<G-vec00132-002-s218><complain.sich_beschweren><de> Menschen die auf Hawaii leben beschweren sich oft über die hohen Lebenshaltungskosten.
<G-vec00132-002-s219><complain.sich_beschweren><en> Some users complain about painful sensations after prolonged usage.
<G-vec00132-002-s219><complain.sich_beschweren><de> Einige Benutzer beschweren sich über schmerzhafte Empfindungen nach längerem Gebrauch.
<G-vec00132-002-s220><complain.sich_beschweren><en> I’m not sure how the animals would react to me singing, but my three mutts often hear me and don’t seem to complain.
<G-vec00132-002-s220><complain.sich_beschweren><de> Ich weiß nicht, wie die Zootiere auf meinen Gesang reagieren würden, aber meine drei Hunde hören mich oft singen, und sie beschweren sich nicht.
<G-vec00132-002-s221><complain.sich_beschweren><en> Complain (politely) to any store that sells real fur and inform CAFT
<G-vec00132-002-s221><complain.sich_beschweren><de> Beschweren Sie sich höflich bei allen Geschäften, die echten Pelz verkaufen, und informieren Sie CAFT.
<G-vec00132-002-s222><complain.sich_beschweren><en> You complain.
<G-vec00132-002-s222><complain.sich_beschweren><de> Sie beschweren sich.
<G-vec00132-002-s223><complain.sich_beschweren><en> Teenagers may complain and appear bored or annoyed, but deep down they really appreciate these moments together.
<G-vec00132-002-s223><complain.sich_beschweren><de> Teenager beschweren sich vielleicht und scheinen gelangweilt oder genervt zu sein, aber tief in ihnen drin genießen sie diese Momente zusammen sehr.
<G-vec00132-002-s224><complain.sich_beschweren><en> These people are the “troopers” of society; they get things done well and don’t complain much.
<G-vec00132-002-s224><complain.sich_beschweren><de> Diese Leute sind die “Soldaten” der Gesellschaft; sie machen ihre Sache gut und beschweren sich nicht viel.
<G-vec00132-002-s225><complain.sich_beschweren><en> Residents complain of massive noise caused by a "drunken Turkish immigrant" (26).
<G-vec00132-002-s225><complain.sich_beschweren><de> Anwohner beschweren sich über massiven Lärm, verursacht durch einen "betrunkenen türkischen Zuwanderer" (26).
<G-vec00132-002-s226><complain.sich_beschweren><en> We complain about faceless corporations, of the tyranny of the contact form over the direct dial.
<G-vec00132-002-s226><complain.sich_beschweren><de> Wir beschweren uns über gesichtslose Konzerne, über Kontaktformulare statt direkter Durchwahl.
<G-vec00132-002-s227><complain.sich_beschweren><en> Drowning in the routine, we often complain that we do not have enough time for games: computer, card, desktop, in the fresh air - it does not matter.
<G-vec00132-002-s227><complain.sich_beschweren><de> Ertrinken in der Routine, wir beschweren uns oft, dass wir nicht genug Zeit für Spiele haben: Computer, Karte, Desktop, an der frischen Luft - es spielt keine Rolle.
<G-vec00132-002-s228><complain.sich_beschweren><en> We complain bitterly about our lives and the lack of respect we feel at home and at work.
<G-vec00132-002-s228><complain.sich_beschweren><de> Wir beschweren uns bitterlich über unsere Leben und den mangelnden Respekt, den wir zuhause und bei der Arbeit zu spüren bekommen.
<G-vec00132-002-s229><complain.sich_beschweren><en> Because it is not easy to find a conditioner that does not complain the hair.
<G-vec00132-002-s229><complain.sich_beschweren><de> Denn es ist nicht einfach eine Pflegespülung zu finden, welche die Haare nicht beschwert.
<G-vec00132-002-s230><complain.sich_beschweren><en> If this is the case, please do us both a favour and close the tab or click the back button, but please do not complain if you find content, particularly of the fannish nature, that you dislike.
<G-vec00132-002-s230><complain.sich_beschweren><de> Sollte das der Fall sein, tut euch und mir einen Gefallen und verlaßt diese Seite, aber beschwert euch bitte nicht über den Inhalt.
<G-vec00132-002-s231><complain.sich_beschweren><en> Active care to improve condition of the hair significantly, does not complain of the hair.
<G-vec00132-002-s231><complain.sich_beschweren><de> Aktive Pflege, um Zustand der Haare deutlich zu verbessern, beschwert nicht das Haar.
<G-vec00132-002-s232><complain.sich_beschweren><en> Generally, when it suffers, it doesn't complain: it calls....
<G-vec00132-002-s232><complain.sich_beschweren><de> Normalerweise beschwert er sich nicht, wenn er leidet: er ruft...
<G-vec00132-002-s233><complain.sich_beschweren><en> Also, SmartScreen filter in recent versions of Internet Explorer (IE) or Microsoft Edge may complain that Audacity is not "commonly downloaded" or say that "Windows has protected your PC" and ask you to confirm the download.
<G-vec00132-002-s233><complain.sich_beschweren><de> Auch der SmartScreen Filter in aktuellen Versionen von Internet Explorer (IE) beschwert sich möglicherweise, dass Audacity nicht "häufig heruntergeladen" wird und fragt Sie danach, das Herunterladen zu bestätigen.
<G-vec00132-002-s234><complain.sich_beschweren><en> She behaves like a good sex slave and doesn't complain when she's forced to watch how Asa Akira and Jessica Drake swap partners and even enjoy double penetrations.
<G-vec00132-002-s234><complain.sich_beschweren><de> Sie benimmt sich wie eine brave Sexsklavin und beschwert sich nicht, als sie dabei zusehen muss, wie Asa Akira und Jessica Drake die Partner tauschen und sogar in den Genuss von DPs kommen.
<G-vec00132-002-s235><complain.sich_beschweren><en> The Modul can be loaded without problems and doesn't complain about a missing device.
<G-vec00132-002-s235><complain.sich_beschweren><de> Das Modul läßt sich ohne Probleme laden und beschwert sich nicht über ein fehlendes Device.
<G-vec00132-002-s236><complain.sich_beschweren><en> pc ps4 Radio operator may complain that he can not use the radio as it needs more power even though the required amount of power is provided.
<G-vec00132-002-s236><complain.sich_beschweren><de> pc ps4 Der Funker beschwert sich, dass er das Radio nicht nutzen kann, weil es mehr Strom braucht, obwohl genügend Energie vorhanden ist.
<G-vec00132-002-s237><complain.sich_beschweren><en> Those practitioners who played the roles of policemen and victims in the exhibition had to stay in position for many hours, but they didn’t complain.
<G-vec00132-002-s237><complain.sich_beschweren><de> Die Praktizierenden, die die Rollen der Polizisten und Folteropfer bei der Ausstellung spielten, mussten viele Stunden in derselben Position verharren, doch sie beschwerten sich nicht.
<G-vec00132-002-s238><complain.sich_beschweren><en> "Average but big rooms with wonderful views, and okay beds." Guests complain about cleanliness, maintenance, and furnishing.
<G-vec00132-002-s238><complain.sich_beschweren><de> 2.7/5 97 Bewertungen „Moderne Zimmer mit ausgezeichneten Betten.“ Die Gäste beschwerten sich über Sauberkeit, Instandhaltung und Ausstattung.
<G-vec00132-002-s239><complain.sich_beschweren><en> In the eyes of the occupying authorities, however, the Jewish DPs were developing increasingly into a disruptive influence on regular administrative procedures, as they would not fit into the scheme that the military had earmarked for solving the DP problem: they would complain incessantly, they were in the eyes of the army undisciplined, and they insisted that they should be recognised as having a separate nationality and be housed in separate camps with special treatment.
<G-vec00132-002-s239><complain.sich_beschweren><de> In den Augen der Besatzungsbehörden entwickelten sich die jüdischen DPs zunehmend zu Störfaktoren eines geregelten Verwaltungsablaufs, da sie sich nicht in das Schema einpassen wollten, das vom Militär für die Lösung des DP-Problems vorgesehen war: sie beschwerten sich laufend, waren aus Sicht der Armee undiszipliniert und bestanden darauf, als eigene Nationalität anerkannt und in separaten Lagern mit einer besonderen Betreuung untergebracht zu werden.
<G-vec00132-002-s245><complain.sich_beschweren><en> We're not going to complain about that.
<G-vec00132-002-s245><complain.sich_beschweren><de> Wir werden uns nicht darüber beschweren.
<G-vec00132-002-s246><complain.sich_beschweren><en> You have the right to complain to ICO if you believe there is a problem with the way we are handling your personal data.
<G-vec00132-002-s246><complain.sich_beschweren><de> Bei dem Verdacht, dass Ihre Daten nicht entsprechend behandelt werden, haben Sie das Recht sich bei der Datenschutzbehörde darüber zu beschweren.
<G-vec00132-002-s325><complain.sich_beschweren><en> Well, I can not complain.
<G-vec00132-002-s325><complain.sich_beschweren><de> Gut, kann ich nicht mich beschweren.
<G-vec00132-002-s326><complain.sich_beschweren><en> I cannot complain about the price for 4 towels.
<G-vec00132-002-s326><complain.sich_beschweren><de> Ich kann mich nicht über den Preis für 4 Handtücher beschweren.
<G-vec00132-002-s327><complain.sich_beschweren><en> I would like to complain about my neighbor.
<G-vec00132-002-s327><complain.sich_beschweren><de> Ich möchte mich über meinen Nachbarn beschweren.
<G-vec00132-002-s328><complain.sich_beschweren><en> I can’t complain about a 7 hour nap in a train at night.
<G-vec00132-002-s328><complain.sich_beschweren><de> Über ein 7 stündiges Nickerchen in der Nacht möchte ich mich nicht beschweren.
<G-vec00132-002-s329><complain.sich_beschweren><en> Weird, but I can't complain.
<G-vec00132-002-s329><complain.sich_beschweren><de> Komisch, aber ich will mich nicht beschweren.
<G-vec00132-002-s330><complain.sich_beschweren><en> Can't complain about anything.
<G-vec00132-002-s330><complain.sich_beschweren><de> Ich kann mich über nichts beschweren.
<G-vec00132-002-s331><complain.sich_beschweren><en> I do not want to complain…not at all…I am thankful…thankful for this past year…despite all the pain it has brought us…how could I not…this past year did have 6 months…6 months in which I was able to be a big sister to Tina…in which I could let her know how much she was loved and wanted…in which I was able to enjoy her in my life…even tho it wasn´t easy at times…I feel beyond blessed I did have those 6 months…6 last months with my beloved baby sister. Tina will forever be in our hearts…in our minds…in our lives…she will be with us this christmas…especially now…watching us from above…knowing how much she is loved
<G-vec00132-002-s331><complain.sich_beschweren><de> Ich möchte mich nicht beschweren…in keinster Weise…ich bin dankbar…dankbar für das letzte Jahr…trotz der undenkbaren Schmerzen die es uns gebracht hat…wie könnte ich nicht…dieses letzte Jahr hat mir 6 Monate gegeben…6 ganze Monate in denen ich eine große Schwester für Tina sein durfte…ich welchen ich sie wissen lassen durfte wie sehr sie gebraucht wird und wie sehr ich sie liebe…ich welchen ich es genießen durfte sie in meinem Leben zu haben…auch wenn es oft nicht einfach war…ich fühle mich gesegnet für diese 6 Monate…6 letzte Monate mit meiner geliebten kleinen Schwester.
<G-vec00132-002-s332><complain.sich_beschweren><en> No, I don’t want to complain about that half.
<G-vec00132-002-s332><complain.sich_beschweren><de> Nun, ich möchte mich nicht über diesen Teil beschweren.
<G-vec00132-002-s333><complain.sich_beschweren><en> I could complain about the nasty cold outside, but hey, I complain every time haha.
<G-vec00132-002-s333><complain.sich_beschweren><de> Und ich könnte mich ja √ľber diese elende Kälte beschweren, aber das tue ich irgendwie immer haha.
<G-vec00132-002-s334><complain.sich_beschweren><en> I do not want to complain...not at all...I am thankful...thankful for this past year...despite all the pain it has brought us...how could I not...this past year did have 6 months...6 months in which I was able to be a big sister to Tina...in which I could let her know how much she was loved and wanted...in which I was able to enjoy her in my life...even tho it wasn´t easy at times...I feel beyond blessed I did have those 6 months...6 last months with my beloved baby sister.
<G-vec00132-002-s334><complain.sich_beschweren><de> Ich möchte mich nicht beschweren...in keinster Weise...ich bin dankbar...dankbar für das letzte Jahr...trotz der undenkbaren Schmerzen die es uns gebracht hat...wie könnte ich nicht...dieses letzte Jahr hat mir 6 Monate gegeben...6 ganze Monate in denen ich eine große Schwester für Tina sein durfte...ich welchen ich sie wissen lassen durfte wie sehr sie gebraucht wird und wie sehr ich sie liebe...ich welchen ich es genießen durfte sie in meinem Leben zu haben...auch wenn es oft nicht einfach war...ich fühle mich gesegnet für diese 6 Monate...6 letzte Monate mit meiner geliebten kleinen Schwester.
<G-vec00132-002-s335><complain.sich_beschweren><en> Can't really complain.
<G-vec00132-002-s335><complain.sich_beschweren><de> Ich kann mich nicht wirklich beschweren.
<G-vec00132-002-s403><complain.sich_beschweren><en> If you want to complain about information and materials uploaded by other users, please contact kundenservice@dfb-fanshop.com.
<G-vec00132-002-s403><complain.sich_beschweren><de> Wenn Sie sich über Informationen und Materialien beschweren möchten, die von anderen Nutzern hochgeladen wurden, wenden Sie sich bitte an kundenservice@dfb-fanshop.de.
<G-vec00132-002-s404><complain.sich_beschweren><en> The ArgoUML critics will complain about attribute names that do not have an initial lower case letter.
<G-vec00132-002-s404><complain.sich_beschweren><de> Die ArgoUML-Kritiken werden sich über Attributnamen beschweren, die nicht mit einem Kleinbuchstaben beginnen.
<G-vec00132-002-s405><complain.sich_beschweren><en> Don't wait for your users to complain.
<G-vec00132-002-s405><complain.sich_beschweren><de> Warten Sie nicht, bis sich Ihre Nutzer beschweren.
<G-vec00132-002-s406><complain.sich_beschweren><en> He must not complain over trifles, and he must not eat with the musicians, for then they will lose respect for him.
<G-vec00132-002-s406><complain.sich_beschweren><de> Er darf sich nicht über Bagatellen beschweren und darf nicht mit den Musikern zusammen essen, da sie sonst den Respekt vor ihm verlieren würden.
<G-vec00132-002-s407><complain.sich_beschweren><en> You should never complain or try to rush things.
<G-vec00132-002-s407><complain.sich_beschweren><de> Sie sollten sich nie beschweren oder versuchen, Dinge zu überstürzen.
<G-vec00132-002-s408><complain.sich_beschweren><en> Honestly, we are a very quiet family and I am not one to complain.
<G-vec00132-002-s408><complain.sich_beschweren><de> Ehrlich gesagt, sind wir eine sehr ruhige Familie und ich bin nicht einer, sich zu beschweren.
<G-vec00132-002-s409><complain.sich_beschweren><en> But let us go to the recipe of this soon to be famous Keto farmers Bread, so you do not complain I do write too much.
<G-vec00132-002-s409><complain.sich_beschweren><de> Aber lassen Sie uns zu dem Rezept gehen, damit Sie sich nicht beschweren, dass ich zu viel schreibe.
<G-vec00132-002-s410><complain.sich_beschweren><en> The data protection officer is obliged to keep your identity secret if you wish to complain about the processing of your data by us.
<G-vec00132-002-s410><complain.sich_beschweren><de> Der Datenschutzbeauftragte ist verpflichtet, Ihre Identität geheim zu halten, wenn Sie sich über die Verarbeitung Ihrer Daten durch uns beschweren wollen.
<G-vec00132-002-s411><complain.sich_beschweren><en> When community folks in Cross River began to complain about this company’s activities, they recruited a bunch of community people who supported the company and even staged a demonstration during which they carried signs saying ‘we want factories, not monkeys.’
<G-vec00132-002-s411><complain.sich_beschweren><de> Als die Bewohner in Cross River sich über die Aktivitäten der Firma zu beschweren begannen, heuerte die Firma zur Unterstützung eine Gruppe von Leuten an, die eine Demo veranstalteten mit Schildern, auf denen es hieß: Wir wollen Fabriken, keine Affen.
<G-vec00132-002-s412><complain.sich_beschweren><en> The bosses will complain that this will reduce their profits and have a negative effect on their incentive to invest.
<G-vec00132-002-s412><complain.sich_beschweren><de> Die Bosse werden sich beschweren, dass dies ihre Profite schmälern und negative Auswirkungen auf ihre Investitionsanreize haben wird.
<G-vec00132-002-s413><complain.sich_beschweren><en> No need to complain about the lack of comfort when driving.
<G-vec00132-002-s413><complain.sich_beschweren><de> Sie müssen sich nicht über den mangelnden Komfort beim Fahren beschweren.
<G-vec00132-002-s414><complain.sich_beschweren><en> As one striking worker explained, there are no jobs, no money, no food, and those who complain about it are thrown in prison.
<G-vec00132-002-s414><complain.sich_beschweren><de> Wie ein streikender Arbeiter erklärte, gibt es keine Arbeitsplätze, kein Geld, keine Nahrungsmittel, und diejenigen, die sich darüber beschweren, werden ins Gefängnis geworfen.
<G-vec00132-002-s415><complain.sich_beschweren><en> In addition, you have the right to complain to a supervisory authority in case of privacy breaches.
<G-vec00132-002-s415><complain.sich_beschweren><de> Darüber hinaus haben Sie das Recht, sich im Falle von Daten-schutzverletzungen bei einer Aufsichtsbehörde zu beschweren.
<G-vec00132-002-s416><complain.sich_beschweren><en> Gannuschkina says, „People are very cautious, no one wants to complain. The victims don’t want to talk to us.“ Many victims prefer not to talk in order to avoid any further problems.
<G-vec00132-002-s416><complain.sich_beschweren><de> Gannuschkina sagt: „Die Menschen reden sehr vorsichtig, niemand will sich beschweren, die Opfer wollen nicht mit uns sprechen.“ Viele Opfer schweigen lieber, um sich nicht einer zusätzlichen Gefahr auszusetzen.
<G-vec00132-002-s417><complain.sich_beschweren><en> The number of men and women who complain about the condition of their hair and scalp keeps increasing.
<G-vec00132-002-s417><complain.sich_beschweren><de> Die Anzahl der Frauen und Männer, die sich über Kondition ihres Haars und ihrer Kopfhaut beschweren, ist immer größer.
<G-vec00132-002-s418><complain.sich_beschweren><en> I just think it's pointless to complain about such things, if they can't be changed anyway, and that a complaint is a paradox when one himself very often acts according to the same standards.
<G-vec00132-002-s418><complain.sich_beschweren><de> Ich finde nur, dass es sinnlos ist, sich über derartige Dinge zu beschweren, wenn sie doch nicht geändert werden können; und dass eine Beschwerde ein Paradoxum darstellt, wenn man selbst sehr oft nach gleichen Normen handelt.
<G-vec00132-002-s419><complain.sich_beschweren><en> Please do not be taken in by the false argument that it was the Germans who started the bombing of civilian targets and therefore have nothing to complain about.
<G-vec00132-002-s419><complain.sich_beschweren><de> Man sollte sich auch nicht von dem falschen Argument beeinflussen lassen, die Deutschen hätten immerhin die Bombardierung ziviler Ziele angefangen und dürften sich deshalb gar nicht beschweren.
<G-vec00132-002-s420><complain.sich_beschweren><en> You cannot go to the swimming pool and later complain that you do not know how you got wet.
<G-vec00132-002-s420><complain.sich_beschweren><de> Man kann nicht ins Schwimmbad gehen und sich dann später beschweren, man wüsste nicht, wie man nass geworden ist.
<G-vec00132-002-s421><complain.sich_beschweren><en> The two apartments were prepared for 11 people and you brought in more people without my knowledge; then there is no reason to complain that the two apartments did not have enough of everything.
<G-vec00132-002-s421><complain.sich_beschweren><de> Die zwei Wohnungen waren für 11 Leute vorbereitet und Sie brachten ohne mein Wissen mehr Leute mit; dann gibt es keinen Grund sich zu beschweren, dass es nicht genug von allem in den beiden Wohnungen gab.
<G-vec00132-002-s437><complain.sich_beschweren><en> When we share only doubt, unease, suffering and sorrow, perhaps complain and maybe even whine on occasion, this creates a totally different atmosphere.
<G-vec00132-002-s437><complain.sich_beschweren><de> Wenn wir nur Zweifel, Unbehagen, Leiden und Unglück kommunizieren, uns eventuell beschweren und vielleicht sogar auch etwas meckern, entsteht eine ganz andere Stimmung.
<G-vec00132-002-s438><complain.sich_beschweren><en> Hard work is something we can complain about and at the same time it makes us valuable members of our community.
<G-vec00132-002-s438><complain.sich_beschweren><de> Harte Arbeit – darüber können wir uns beschweren und gleichzeitig sind wir dann wertvolle Mitglieder unserer Gesellschaft.
<G-vec00132-002-s439><complain.sich_beschweren><en> The sun is burning down, but we do not want to complain.
<G-vec00132-002-s439><complain.sich_beschweren><de> Die Sonne brennt runter, aber wir wollen uns nicht beschweren.
