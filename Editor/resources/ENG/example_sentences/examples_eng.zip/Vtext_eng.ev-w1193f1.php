<EnglishT-wsj_0584-s19#EnglishT-wsj_0584-s19-t8><ev-w1193f1.v-w10006f1> Analysts said they expect McCaw <start_vauxs>to<end_vauxs> <start_vs>escalate<end_vs> the bidding again. 
