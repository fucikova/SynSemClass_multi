<G-vec00426-002-s032><cry.aufschreien><en> Extraordinary things will come to pass in the Church and the world causing you to cry out in uncertainty and despair.
<G-vec00426-002-s032><cry.aufschreien><de> Ausserordentliche Dinge werden geschehen in Kirche und Welt, sodass ihr in Unsicherheit und Verzweiflung aufschreien werdet.
<G-vec00426-002-s033><cry.aufschreien><en> And, all cry out to be emancipated, I love porn.
<G-vec00426-002-s033><cry.aufschreien><de> Und, alle Emanzen werden aufschreien, ich liebe Pornos.
<G-vec00426-002-s034><cry.aufschreien><en> Why, the whole womanhood of England must cry out against such a thing.
<G-vec00426-002-s034><cry.aufschreien><de> Warum, alle Frauen von England müssten aufschreien gegen so eine Sache.
<G-vec00426-002-s035><cry.aufschreien><en> Sometimes, this aching throb hurts; it can make me want to cry out in the middle of the night, bury my head in my pillow and wish for a new life.
<G-vec00426-002-s035><cry.aufschreien><de> Manchmal tut mir das schmerzhafte Pochen weh; ich will mitten in der Nacht aufschreien, meinen Kopf in den Polster graben und mir ein neues Leben wünschen.
<G-vec00426-002-s036><cry.aufschreien><en> But the expected pain didn't come, he heard the guard's cry instead.
<G-vec00426-002-s036><cry.aufschreien><de> Doch der erwartete Schmerz blieb aus, statt dessen hörte er den Wächter aufschreien.
<G-vec00426-002-s095><cry.heulen><en> Well, not really, but since the record had been produced before (and I suppose with a very low budget) SIGH end up with an underground production that makes me want to cry.
<G-vec00426-002-s095><cry.heulen><de> Prinzipiell ja, aber da die Aufnahme bereits davor produziert worden war (und ich vermute - in Anbetracht eines fehlenden Labels - mit niedrigem Budget), muss sich der Hörer nun mit einer Underground-Produktion begnügen, die zum Heulen ist.
<G-vec00426-002-s096><cry.heulen><en> I do not know, I should be happy or rather cry.
<G-vec00426-002-s096><cry.heulen><de> Ich weiß nicht, soll ich mich freuen oder eher heulen.
<G-vec00426-002-s097><cry.heulen><en> And on the other hand, for example, we have the case of British Nobel Prize-winning biochemist Tim Hunt who at a conference in early June argued (whether in jest or seriously is not quite clear) that women and men should be assigned to separate laboratories because otherwise men would fall in love with female scientists “and if you criticise them they start to cry”.
<G-vec00426-002-s097><cry.heulen><de> Und auf der anderen Seite haben wir etwa den Fall des bri- tischen Biochemie-Nobelpreisträgers Tim Hunt, der auf einer Konferenz Anfang Juni dafür plädiert hatte (ob im Scherz oder ernsthaft ist nicht ganz klar), Frauen und Männern getrennte Labore zuzuweisen, weil man sich sonst eh in die Wissenschaftlerinnen verliebe, „und wenn du sie kritisierst, fangen sie an zu heulen“.
<G-vec00426-002-s098><cry.heulen><en> I did it and could cry for joy.
<G-vec00426-002-s098><cry.heulen><de> Ich habe es geschafft und könnte heulen vor Freude.
<G-vec00426-002-s099><cry.heulen><en> Evening, and morning, and at noon, will I pray, and cry aloud: and he shall hear my voice.
<G-vec00426-002-s099><cry.heulen><de> Des Abends, Morgens und Mittags will ich klagen und heulen, so wird er meine Stimme hören.
<G-vec00426-002-s100><cry.heulen><en> The dismayed audience in the Kulturbrauerei did not know whether they should be happy or rather cry when Jeff Hanneman received the award in the category God of Riffs.
<G-vec00426-002-s100><cry.heulen><de> Die betretene Menge in der Kulturbrauerei wusste nicht ob sie sich freuen oder lieber heulen sollte, als Jeff Hanneman posthum den Award in der Kategorie God Of Riffs erhielt.
<G-vec00426-002-s189><cry.rufen><en> Therefore, my dear children, with hearts open and full of love, cry out the name of the Heavenly Father that He may illuminate you with the Holy Spirit.
<G-vec00426-002-s189><cry.rufen><de> Darum, meine lieben Kinder, ruft mit offenem Herzen und voller Liebe den Namen des himmlischen Vaters an, damit Er euch mit dem heiligen Geiste erleuchte.
<G-vec00426-002-s190><cry.rufen><en> Though I use her now to cry out to the Bride, as a voice will cry out to the five wise virgins, do not compromise, be prepared for your bridegroom doth come for HIS Bride on a Rosh Hashanah and a Shabbat.
<G-vec00426-002-s190><cry.rufen><de> ICH benutze sie nun um zur Braut zu schreien, so wie eine Stimme die zu den fünf klugen Jungfrauen ruft, macht keine Kompromisse, seid bereit, denn euer Bräutigam kommt for SEINE Braut an einem Rosh Ha Shanah und am Sabbat.
<G-vec00426-002-s191><cry.rufen><en> “Even as you listen to this message, cry out to Me and I shall grant you the grace of profound thankfulness.
<G-vec00426-002-s191><cry.rufen><de> “Während ihr dieser Botschaft zuhört, ruft zu Mir hinaus und Ich werde euch die Gnade tiefgreifender Dankbarkeit gewähren.
<G-vec00426-002-s192><cry.rufen><en> UNIFY is a prophetic voice of the ashes of Auschwitz, which cry out for vengeance, but instead we cry for “Holy Vengeance”.
<G-vec00426-002-s192><cry.rufen><de> UNIFY ist eine prophetische Stimme der Asche von Auschwitz, die nach Vergeltung ruft – statt dessen aber rufen wir nach „Heiliger Vergeltung“.
<G-vec00426-002-s193><cry.rufen><en> 15 (John testified to him with the cry, 'This was he of whom I said, my successor has taken precedence of me, for he preceded me.')
<G-vec00426-002-s193><cry.rufen><de> 15 Johannes zeugt von ihm, ruft und spricht: Dieser war es, von dem ich gesagt habe: Nach mir wird kommen, der vor mir gewesen ist; denn er war eher als ich.
<G-vec00426-002-s091><cry.schreien><en> But more than this, Isabella, now 3, can sometimes wake to go to the toilet, or because she’s having a night terror or even cry out in her sleep.
<G-vec00426-002-s091><cry.schreien><de> Und daneben wacht auch Isabella, die inzwischen drei ist, manchmal auf, weil sie auf die Toilette muss oder einen Albtraum gehabt oder einfach nur im Schlaf geschrien hat.
<G-vec00426-002-s092><cry.schreien><en> Says Tyrone: “He didn’t cry, he just glared at me, full of hate.
<G-vec00426-002-s092><cry.schreien><de> Tyrone: „Er hat nicht geschrien, er schaute mich nur an, voller Hass.
<G-vec00426-002-s093><cry.schreien><en> 24 You shall bring both of them out to the gate of that city and stone them with stones so that they die, the girl because she did not cry out in the city, and the man because he humbled his neighbor's wife.
<G-vec00426-002-s093><cry.schreien><de> 5Mo 22,24 dann sollt ihr sie beide zum Tor jener Stadt hinausführen und sie steinigen, dass sie sterben; das Mädchen deshalb, weil es in der Stadt nicht geschrien hat, und den Mann deshalb, weil er der Frau seines Nächsten Gewalt angetan hat.
<G-vec00426-002-s094><cry.schreien><en> When parents hear about infant sleep training, they often think of babies left alone in their cribs to cry themselves to sleep.
<G-vec00426-002-s094><cry.schreien><de> Wenn Eltern von Schlaf-Training hören, denken viele dass sie ihr armes Baby alleine in seinem Bettchen liegen lassen müssen bis es sich in den Schlaf geschrien hat.
<G-vec00426-002-s336><cry.weinen><en> Hear my cry, hear my cry
<G-vec00426-002-s336><cry.weinen><de> Höre mein Weinen, höre mein Weinen.
<G-vec00426-002-s337><cry.weinen><en> You make me cry
<G-vec00426-002-s337><cry.weinen><de> Sie machen mich weinen.
<G-vec00426-002-s338><cry.weinen><en> I won't cry for you
<G-vec00426-002-s338><cry.weinen><de> Ich würde nicht um dich weinen.
<G-vec00426-002-s339><cry.weinen><en> Got no more tears to cry
<G-vec00426-002-s339><cry.weinen><de> Hab keine Tränen mehr zu weinen.
