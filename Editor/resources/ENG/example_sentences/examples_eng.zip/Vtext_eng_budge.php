<G-vec00022-002-s004><budge.bewegen><en> Making the object budge without fully moving it from its place: a thullaccaya.
<G-vec00022-002-s004><budge.bewegen><de> Den Gegenstand bewegen, ohne ihn gänzlich von seinem Platz zu bringen: Ein thullaccaya.
<G-vec00022-002-s005><budge.bewegen><en> Here is a wooden box, which is easy to budge.
<G-vec00022-002-s005><budge.bewegen><de> Hier ist eine Holzkiste, die leicht zu bewegen ist.
<G-vec00022-002-s006><budge.bewegen><en> The Palestinians not only refused to budge but ridiculed the very idea.
<G-vec00022-002-s006><budge.bewegen><de> Die Palästinenser lehnten nicht nur ab sich zu bewegen, sondern verhöhnten die Idee.
<G-vec00022-002-s007><budge.bewegen><en> But Excalibur still did not budge.
<G-vec00022-002-s007><budge.bewegen><de> Aber Excalibur bewegte sich nicht.
<G-vec00022-002-s029><budge.bewegen><en> And it happens that the baby, being sufficiently developed, can not budge.
<G-vec00022-002-s029><budge.bewegen><de> Und es kommt vor, dass das Baby, wenn es ausreichend entwickelt ist, sich nicht bewegen kann.
<G-vec00022-002-s004><budge.sich_bewegen><en> Making the object budge without fully moving it from its place: a thullaccaya.
<G-vec00022-002-s004><budge.sich_bewegen><de> Den Gegenstand bewegen, ohne ihn gänzlich von seinem Platz zu bringen: Ein thullaccaya.
<G-vec00022-002-s005><budge.sich_bewegen><en> Here is a wooden box, which is easy to budge.
<G-vec00022-002-s005><budge.sich_bewegen><de> Hier ist eine Holzkiste, die leicht zu bewegen ist.
<G-vec00022-002-s006><budge.sich_bewegen><en> The Palestinians not only refused to budge but ridiculed the very idea.
<G-vec00022-002-s006><budge.sich_bewegen><de> Die Palästinenser lehnten nicht nur ab sich zu bewegen, sondern verhöhnten die Idee.
<G-vec00022-002-s007><budge.sich_bewegen><en> But Excalibur still did not budge.
<G-vec00022-002-s007><budge.sich_bewegen><de> Aber Excalibur bewegte sich nicht.
<G-vec00022-002-s029><budge.sich_bewegen><en> And it happens that the baby, being sufficiently developed, can not budge.
<G-vec00022-002-s029><budge.sich_bewegen><de> Und es kommt vor, dass das Baby, wenn es ausreichend entwickelt ist, sich nicht bewegen kann.
