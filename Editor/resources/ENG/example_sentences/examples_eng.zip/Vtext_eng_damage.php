<G-vec00372-002-s057><damage.beschädigen><en> Hygienic CeramicSteel will not incur damage from repeated cleaning and disinfecting, even using highly potent cleaning solutions.
<G-vec00372-002-s057><damage.beschädigen><de> Hygienic CeramicSteel wird auch durch die Verwendung hochwirksamer Reinigungslösungen bei wiederholter Reinigung und Desinfektion nicht beschädigt.
<G-vec00372-002-s058><damage.beschädigen><en> If there is damage to the package, or if merchandise is missing, please keep the original shipping carton and contact us immediately so we can issue a damage claim with the carrier.
<G-vec00372-002-s058><damage.beschädigen><de> Falls die Verpackung beschädigt ist, oder Ware fehlt, behalten Sie bitte den ursprünglichen Transportkarton und nehmen Sie sofort mit uns Kontakt auf, so dass wir eine Schadenersatzklage mit dem Versanddienst erstellen können.
<G-vec00372-002-s059><damage.beschädigen><en> This is the only way to ensure that the passive layer in the processed areas rebuilds and the other surfaces are prevented from sustaining damage from pitting corrosion or intercrystalline corrosion.
<G-vec00372-002-s059><damage.beschädigen><de> Nur so kann sichergestellt werden, dass sich die Passivschicht in den bearbeiteten Bereichen neu ausbildet und die anderen Flächen nicht durch Lochkorrosion oder interkristalline Korrosion beschädigt werden.
<G-vec00372-002-s060><damage.beschädigen><en> The introduction of particles into your system can lead to the damage of sensitive components, such as hydraulic valves, motors or pumps.
<G-vec00372-002-s060><damage.beschädigen><de> Durch das Eintreten von Partikeln in Ihr System können empfindliche Komponente wie Hydraulikventile, Motoren oder Pumpen beschädigt werden.
<G-vec00372-002-s061><damage.beschädigen><en> If in the reasonable opinion of the Rental Agent, the Client behaves in such a way as to cause danger, upset or distress to any third party or damage to the Villa, the Rental Agent is entitled, without prior notice, to terminate the Client´s occupancy of the Villa.
<G-vec00372-002-s061><damage.beschädigen><de> Falls sich der Kunde nach begründeter Ansicht des Vermieters so verhält, dass er dritte Personen gefährdet, beleidigt oder verletzt oder die Villa beschädigt, ist der Vermieter berechtigt, den Kunden ohne vorherige Ankündigung den Mietvertrag zu kündigen.
<G-vec00372-002-s062><damage.beschädigen><en> If you lose or damage the return label, please contact our Customer Care team, who will email you a copy.
<G-vec00372-002-s062><damage.beschädigen><de> Falls das Rücksendeetikett verloren geht oder beschädigt wird, dann wenden Sie sich bitte an unseren Kundenservice, der Ihnen eine Kopie per E-Mail zusenden wird.
<G-vec00372-002-s063><damage.beschädigen><en> Assuming that the limiting cable has been correctly laid around flower beds, trees, shrubs or other objects, the TANGO E5 will not enter those areas and thus will not damage flowers, trees, shrubs, etc.
<G-vec00372-002-s063><damage.beschädigen><de> Solange der Begrenzungsdraht korrekt um Blumenbeete, Bäume, Büsche und andere Objekte verlegt wurde, umfährt der TANGO E5 Serie II die jeweiligen Gebiete und beschädigt daher keine Blumen, Bäume oder Büsche.
<G-vec00372-002-s064><damage.beschädigen><en> Be careful not to touch the LCD with the tweezers, as you may damage the display.
<G-vec00372-002-s064><damage.beschädigen><de> Achte darauf das LCD nicht mit der Pinzette zu berühren, es könnte beschädigt werden.
<G-vec00372-002-s065><damage.beschädigen><en> Safe to use and will not damage or discolor fabrics.
<G-vec00372-002-s065><damage.beschädigen><de> Sicher in der Anwendung und beschädigt oder verfärbt die Textilien nicht.
<G-vec00372-002-s066><damage.beschädigen><en> That’s deliberate so that should they fall, they will not damage the mausoleum.
<G-vec00372-002-s066><damage.beschädigen><de> Sie tun dies absichtlich, denn sollten sie jemals herunterfallen, wird das Mausoleum dadurch nicht beschädigt werden.
<G-vec00372-002-s067><damage.beschädigen><en> It is completely non-destructive in nature and does not modify or damage the original Word document and creates a fresh healthy Word file by recovering all its attributes.
<G-vec00372-002-s067><damage.beschädigen><de> Es ist völlig zerstörungsfrei in der Natur und ändert oder beschädigt nicht das ursprüngliche Worddokument und erzeugt eine neue gesunde Word Datei, indem alle seine Attribute wiederhergestellt werden.
<G-vec00372-002-s068><damage.beschädigen><en> The air filter should be replaced at least every six months or if there are signs of damage.
<G-vec00372-002-s068><damage.beschädigen><de> Der Luftfilter muss erneuert werden, wenn er beschädigt ist, spätestens jedoch nach 6 Monaten.
<G-vec00372-002-s069><damage.beschädigen><en> Both soothe skin but patting doesn’t damage the skin barrier.
<G-vec00372-002-s069><damage.beschädigen><de> Beides beruhigt die Haut, aber Klopfen beschädigt nicht die Hautbarriere.
<G-vec00372-002-s070><damage.beschädigen><en> It is very important that you pack the products properly to avoid damage to the products or the original packaging.
<G-vec00372-002-s070><damage.beschädigen><de> Dabei ist unbedingt darauf zu achten, dass die Waren gut verpackt sind und weder die Artikel noch die Originalverpackung beschädigt werden.
<G-vec00372-002-s071><damage.beschädigen><en> However, this PC infection does not damage the Windows computer, but delete the System Restore points and Shadow Volume copies on the machine as well.
<G-vec00372-002-s071><damage.beschädigen><de> Diese PC-Infektion beschädigt jedoch nicht den Windows-Computer, sondern löscht auch die Systemwiederherstellungspunkte und die Shadow-Volume-Kopien auf dem Computer.
<G-vec00372-002-s072><damage.beschädigen><en> You can also apply bleach after the tattoo is done, it will not make any damage to the tattoo.
<G-vec00372-002-s072><damage.beschädigen><de> Bleiche kann auch verwendet werden, nachdem das Tattoo fertig ist – keine Sorge, das Tattoo wird dadurch nicht beschädigt.
<G-vec00372-002-s073><damage.beschädigen><en> Debian GNU/kFreeBSD should be shut down in a controlled manner, otherwise files might get lost and/or disk damage might occur.
<G-vec00372-002-s073><damage.beschädigen><de> Debian GNU/kFreeBSD sollte auf kontrollierte Art und Weise heruntergefahren werden, andernfalls können Dateien verloren gehen und/oder die Festplatte könnte beschädigt werden.
<G-vec00372-002-s074><damage.beschädigen><en> Es The storms caused some damage to my garden – several of the tomato plants fell – on top of the eggplant plants.
<G-vec00372-002-s074><damage.beschädigen><de> Die Stürme haben den Garten beschädigt – die Tomaten Pflanzen sind umgefallen (trotz dem Gerüst); und sie sind auf die Auberginen gefallen.
<G-vec00372-002-s075><damage.beschädigen><en> A gate repeatedly bangs against the wall to which it’s attached, causing increasing damage.
<G-vec00372-002-s075><damage.beschädigen><de> Ein Gittertor schlägt immer wieder an die Wand, an der es befestigt ist und beschädigt diese zunehmend.
<G-vec00372-002-s190><damage.schaden><en> Aluminium/Buna construction Pump Specifications: Nominal Flow Rate: 50L/MIN Discharge Head: 6.0m Suction Lift: 7.5m Solid Size: 35mm Motor Size: 0.75kw Approximate Displacement Per Stroke: 1.5L Weight: 42kg Maximum outside dimensions: 400mm x 335mm x 410mm (LxWxH) Suction lifts to 7.5m Rapid self priming Will run dry without damage Will operate on snore Will handle abrasive liquids Will pass solids up to 80% of port size Heavy duty, compact construction TEFC electric motors fitted as standard Special electric motor enclosures as an option
<G-vec00372-002-s190><damage.schaden><de> Nenndurchfluss: 50L / MIN-Kopf Entlastung: 6,0 m Saughöhe: 7.5m Solid Größe: 35mm Motor Größe: 0,75 kW Ungefähre Verdrängung pro Hub: 1,5 l Gewicht: 42 kg Maximale Außenabmessungen: 400mm x 335mm x 410mm (LxBxH) Saughöhen bis 7,5 m Schnelle selbstansaugende Wird ohne Schaden trocken laufen Wird auf schnarchen arbeitet abrasiven Flüssigkeiten handhaben werden Feststoffe bis zu 80% der Anschlussgröße Schwerlast-, kompakte Bauweise TEFC Elektromotoren passieren als Standard für spezielle Elektromotor-Remko .
<G-vec00372-002-s191><damage.schaden><en> Weakened enemies deal 30% less damage over a duration of 6 seconds.
<G-vec00372-002-s191><damage.schaden><de> Verschwächerte Feinde verursachen 6 Sekunden lang 30% weniger Schaden.
<G-vec00372-002-s192><damage.schaden><en> It makes little sense, for example, to purchase video equipment for € 20,000 when the maximum possible damage only amounts to € 1,000.
<G-vec00372-002-s192><damage.schaden><de> So ist es wenig sinnvoll, Videotechnik für 20.000€ anzuschaffen, wenn ein Schaden sich maximal auf 1.000€ belaufen kann.
<G-vec00372-002-s193><damage.schaden><en> If damage occurs, the tenant must contact the landlord immediately.
<G-vec00372-002-s193><damage.schaden><de> Bei einem Schaden hat sich der Mieter umgehend mit dem Vermieter in Kontakt zu setzen.
<G-vec00372-002-s194><damage.schaden><en> It is specified reasons for it gladly that the Schabrackentapire attack the cornfields at night and prepared big damage, which should be, however, very exaggerated surely, since tapirs avoid themselves mutually and therefore never appear in large groups.
<G-vec00372-002-s194><damage.schaden><de> Als Grund dafür wird gerne angeführt, daß die Schabrackentapire nachts über die Maisfelder herfallen und großen Schaden anrichteten, was aber sicherlich sehr übertrieben sein dürfte, da sich Tapire gegenseitig meiden und deshalb niemals in großen Gruppen auftreten.
<G-vec00372-002-s195><damage.schaden><en> Affected enemy units, monsters and heroes cause 90% less damage for 30 seconds.
<G-vec00372-002-s195><damage.schaden><de> Getroffene feindliche Einheiten, Helden und Monster verursachen für 30 Sekunden 90% weniger Schaden.
<G-vec00372-002-s196><damage.schaden><en> They failed, but great damage was done.
<G-vec00372-002-s196><damage.schaden><de> Das Vorhaben scheiterte, richtete jedoch großen Schaden an.
<G-vec00372-002-s197><damage.schaden><en> • No cut on the skin and no damage of muscles around the lachrymal sac are the other advantages.
<G-vec00372-002-s197><damage.schaden><de> • Kein Schnitt auf der Haut und kein Schaden von Muskeln um den tränenreichen Beutel sind die anderen Vorteile.
<G-vec00372-002-s198><damage.schaden><en> Magma Orb: Increased the damage by 33%.
<G-vec00372-002-s198><damage.schaden><de> Magma-Kugel: Schaden wurde um 33% erhöht.
<G-vec00372-002-s199><damage.schaden><en> The risk is that they increase the damage of landing heads, is too large.
<G-vec00372-002-s199><damage.schaden><de> Die Gefahr, dass Sie den Schaden über aufsetzende Köpfe noch vergrößern, ist zu groß.
<G-vec00372-002-s200><damage.schaden><en> It is possible to repeatedly re-trigger the effect by healing yourself above 20% and then taking enough damage to drop back down below 20% health.
<G-vec00372-002-s200><damage.schaden><de> Es ist möglich den Effekt immer wieder auszulösen indem man sich gerade so über 20% Gesundheit heilt und dann genug Schaden nimmt um wieder unter die Grenze zu fallen.
<G-vec00372-002-s201><damage.schaden><en> In all cases – unless dealing with personal injuries or in the presence of compulsory statutory provisions stating otherwise – liability shall be limited to the foreseeable, typically occurring damage.
<G-vec00372-002-s201><damage.schaden><de> In sämtlichen Fällen ist – sofern es sich nicht um Personenschäden handelt oder zwingende rechtliche Gründe entgegenstehen – die Haftung auf den vorhersehbaren, typischerweise eintretenden Schaden begrenzt.
<G-vec00372-002-s202><damage.schaden><en> Once per turn, you can remove 1 of this card's Xyz Material Monster to select 1 face-up monster your opponent controls. Destroy the selected monster, and inflict damage to your opponent's Life Points equal to the original ATK of the destroyed monster.
<G-vec00372-002-s202><damage.schaden><de> Falls diese Karte angreift, Spielzug: Du kannst 1 Xyz-Material von dieser Karte abhängen, um 1 offenes Monster zu wählen, das dein Gegner kontrolliert; zerstöre das Monster deines Gegners und falls du dies tust, füge deinem Gegner Schaden in Höhe der Grund-ATK des zerstörten Monsters zu.
<G-vec00372-002-s203><damage.schaden><en> Note: Unarmed weapons do double normal damage in V.A.T.S. Durability Edit
<G-vec00372-002-s203><damage.schaden><de> Hinweis: "Unbewaffnet" Waffen machen doppelten Schaden im V.A.T.S.
<G-vec00372-002-s204><damage.schaden><en> Reimbursement of the losses shall be limited to a foreseeable damage, typical for this kind of contracts.
<G-vec00372-002-s204><damage.schaden><de> Der Schadensersatz ist auf den vertragstypischen, vorhersehbaren Schaden begrenzt.
<G-vec00372-002-s205><damage.schaden><en> All damage on any of the active shields generates static charges for Istok.
<G-vec00372-002-s205><damage.schaden><de> Jeder Schaden an einem der aktiven Schilde erzeugt eine statische Aufladung für Istok.
<G-vec00372-002-s206><damage.schaden><en> This can be done, for example, through plans, defined roles, training, communication to quickly detect an attack and effectively mitigate the damage.
<G-vec00372-002-s206><damage.schaden><de> Dies kann zum Beispiel durch Pläne, definierte Rollen, Training, Kommunikation erfolgen, um einen Angriff schnell zu entdecken und den Schaden effektiv einzudämmen.
<G-vec00372-002-s207><damage.schaden><en> One thing works perfectly – always when we try too hard at the same time we push away our desired things and cause more damage than success.
<G-vec00372-002-s207><damage.schaden><de> Eine Sache funktioniert aber immer ausgezeichnet: wenn wir uns zu viel bemühen, treiben wir es zugleich weg von uns und oft verursachen wir so mehr Schaden als Nutzen.
<G-vec00372-002-s208><damage.schaden><en> 11.2 Liability for breach of a cardinal obligation or an essential obligation is limited to the damage which could have been foreseen.
<G-vec00372-002-s208><damage.schaden><de> 11.2 Haftung bei Verletzung einer Kardinalpflicht oder einer wesentlichen Vertragspflicht ist auf den vorhersehbaren Schaden begrenzt.
<G-vec00372-002-s285><damage.schädigen><en> Bad news about a company can damage not just its reputation, but also that of the whole sector over the long term, as the emissions scandal has shown.
<G-vec00372-002-s285><damage.schädigen><de> Schlechte Nachrichten über ein Unternehmen können nicht nur dessen Ruf, sondern den einer ganzen Branche nachhaltig schädigen, wie unter anderem der Abgasskandal gezeigt hat.
<G-vec00372-002-s286><damage.schädigen><en> As they can do massive damage to houses, you should turn to a specialist in such cases.
<G-vec00372-002-s286><damage.schädigen><de> Da sie Häuser massiv schädigen können, sollten Sie sich in einem solchen Fall an einen Fachmann wenden.
<G-vec00372-002-s287><damage.schädigen><en> This phenomenon, known as "high speed stall", results in changing loads that can damage the structure and affect flight stability.
<G-vec00372-002-s287><damage.schädigen><de> Dieses als „High Speed Stall“ bezeichnete Phänomen hat wechselnde Lasten zur Folge, welche die Struktur schädigen und die Flugstabilität beeinflussen können.
<G-vec00372-002-s288><damage.schädigen><en> Free radicals, which are produced in great amounts during intense physical exertions, like merciless battles, can damage the DNA of your cells and are linked to a variety of diseases, ranging from cancer to heart disease.
<G-vec00372-002-s288><damage.schädigen><de> Frei Radikale, die besonders während intensiver körperlicher Anstrengungen, wie sie bei gnadenlosen Schlachten zwangsläufig zustande kommen, in verstärktem Umfang produziert werden, können die DNA Deiner Zellen schädigen und werden mit einer Vielzahl von Erkrankungen in Verbindung gebracht, die von Krebs bis hin zu Herz-Kreislauf Erkrankungen reichen.
<G-vec00372-002-s289><damage.schädigen><en> Even the broadly defined Section 129a (membership of a terrorist organisation) requires that the acts are meant to "damage a state or international body considerably through their nature or their effects."
<G-vec00372-002-s289><damage.schädigen><de> Immerhin setzt selbst der weite Straftatbestand des § 129a StGB voraus, dass die Straftaten bestimmt sind, „durch die Art ihrer Begehung oder ihre Auswirkungen einen Staat oder eine internationale Organisation erheblich zu schädigen“.
<G-vec00372-002-s290><damage.schädigen><en> Sun rays do not only damage the skin.
<G-vec00372-002-s290><damage.schädigen><de> Doch Sonnenstrahlen können die Haut nicht nur direkt schädigen.
<G-vec00372-002-s291><damage.schädigen><en> Poor oral hygiene allows these microorganisms to enter the bloodstream through tooth abscesses, cavities and gingivitis, where they can damage every organ and every cell (focal infections).
<G-vec00372-002-s291><damage.schädigen><de> Durch die schlechte Mundhygiene können diese Mikroorganismen über Zahnabszesse, Löcher und Zahnfleischentzündungen in die Blutbahn gelangen, wo sie die Organe und Zellen schädigen können (Herdinfektionen).
<G-vec00372-002-s292><damage.schädigen><en> Over time, high heels can damage your joints and cause chronic back pain.
<G-vec00372-002-s292><damage.schädigen><de> Das Tragen von hochhackigen Schuhen kann deine Gelenke mit der Zeit schädigen und zu chronischen Rückenschmerzen führen.
<G-vec00372-002-s293><damage.schädigen><en> Common combs have burrs on and between the teeth and damage the hair.
<G-vec00372-002-s293><damage.schädigen><de> Gewöhnliche Kämme haben Grate auf und zwischen den Zähnen und schädigen das Haar.
<G-vec00372-002-s294><damage.schädigen><en> It could damage your hair and cause split ends.
<G-vec00372-002-s294><damage.schädigen><de> Sie könnte dein Haar schädigen und zu gespaltenen Spitzen führen.
<G-vec00372-002-s295><damage.schädigen><en> In chronic gingivitis, the bacteria have already penetrated from the gingival margin of the jaw and damage there the entire periodontium.
<G-vec00372-002-s295><damage.schädigen><de> Bei der chronischen Zahnfleischentzündung sind die Bakterien bereits vom Zahnfleischsaum zum Kiefer vorgedrungen und schädigen dort den gesamten Zahnhalteapparat.
<G-vec00372-002-s296><damage.schädigen><en> Intense UV radiation can damage the skin and eyes – that much we know.
<G-vec00372-002-s296><damage.schädigen><de> Intensive UV-Strahlung kann Haut und Augen schädigen – so viel ist bekannt.
<G-vec00372-002-s297><damage.schädigen><en> You may link to our home page, provided you do so in a way that is fair and legal and does not damage our reputation or take advantage of it, but you must not establish a link in such a way as to suggest any form of association, approval or endorsement on our part where none exists.
<G-vec00372-002-s297><damage.schädigen><de> Sie dürfen auf unsere Homepage verlinken, sofern Sie dies auf faire und legale Weise tun und unseren Ruf nicht schädigen oder ausnutzen, aber Sie dürfen keine Verbindung in einer Weise herstellen, die eine Form der Verbindung, Genehmigung oder Billigung durch uns nahelegt, wo es keine gibt.
<G-vec00372-002-s298><damage.schädigen><en> The larvae can also attack living plant material and therefore damage roots.
<G-vec00372-002-s298><damage.schädigen><de> Die Larven können auch lebendes Pflanzengewebe angreifen und daher Wurzeln schädigen.
<G-vec00372-002-s299><damage.schädigen><en> Because the World Bank is not by any means determined to compete with the private banks and damage it.
<G-vec00372-002-s299><damage.schädigen><de> Denn die Weltbank ist keineswegs gewillt, mit den privaten Banken zu konkurrieren und sie zu schädigen.
<G-vec00372-002-s300><damage.schädigen><en> Instead the projectiles really damage only the target which they hit.
<G-vec00372-002-s300><damage.schädigen><de> Stattdessen schädigen Projektile nur das Ziel, das sie auch treffen.
<G-vec00372-002-s301><damage.schädigen><en> Bulking material of cardboard packaging such as calcium carbonate damage the acid mantle of the skin in the case of long-term exposure.
<G-vec00372-002-s301><damage.schädigen><de> Füllstoffe von Kartonagen wie Calciumcarbonat schädigen bei Dauerkontakt den Säuremantel der Haut.
<G-vec00372-002-s302><damage.schädigen><en> The donor area of each person has a limited capacity; therefore, it is possible to damage the donor area in case this capacity is exceeded.
<G-vec00372-002-s302><damage.schädigen><de> Der Spenderbereich jeder Person hat eine Kapazität und es ist möglich den Spenderbereich zu schädigen, falls diese Kapazität überschritten wird.
<G-vec00372-002-s303><damage.schädigen><en> Do not use the hair dryer or curling iron all too often - frequent exposure to high temperatures can damage your hair.
<G-vec00372-002-s303><damage.schädigen><de> Verwenden Sie den Haartrockner oder Lockenstab nicht allzu oft - häufige Einwirkung hoher Temperaturen kann Ihr Haar schädigen.
<G-vec00372-002-s209><damage.verursachen><en> In particular, the Company remains responsible and liable under the Privacy Shield Principles if thirdparty agents that it engages to process the personal data on its behalf do so in a manner inconsistent with the Privacy Shield Principles, unless the Company proves that it is not responsible for the event giving rise to the damage.
<G-vec00372-002-s209><damage.verursachen><de> Das Unternehmen ist gemäß den Grundsätzen der Datenschutzschilder insbesondere auch dann verantwortlich und haftbar, wenn Beauftragte von Dritten, die in seinem Auftrag die personenbezogenen Daten nutzen, diese nicht in Überstimmung mit den Grundsätzen der Datenschutzschilder verarbeiten, solange das Unternehmen nicht nachweisen kann, dass es für den Vorgang, der den Schaden verursacht hat, nicht verantwortlich ist.
<G-vec00372-002-s210><damage.verursachen><en> If a player applies a status effect that already exists on a target, but the new status effect has a higher damage than the existing one, the damage will now scale to that higher value.
<G-vec00372-002-s210><damage.verursachen><de> Wenn ein Spieler ein Ziel mit einem Statuseffekt belegt, das zuvor schon unter diesem litt, der neue Statuseffekt allerdings mehr Schaden verursacht, dann entspricht der Schaden nun dem höheren Wert.
<G-vec00372-002-s211><damage.verursachen><en> We reserve the right to suspend this service in individual cases, if we determine that the damage was done on purpose.
<G-vec00372-002-s211><damage.verursachen><de> Wir behalten uns das Recht zur Aussetzung der Dienstleistung aufgrund individueller Fälle vor, wenn wir feststellen werden, dass der Schaden vorsätzlich verursacht wurde.
<G-vec00372-002-s212><damage.verursachen><en> Developer Comments: Nazeebo was dealing a little more damage than we’d like, specifically when looking at his spiders.
<G-vec00372-002-s212><damage.verursachen><de> Kommentar der Entwickler: Nazeebo hat ein bisschen mehr Schaden verursacht, als uns lieb war, vor allem mit seinen Spinnen.
<G-vec00372-002-s213><damage.verursachen><en> Shred Shreds targets, doing an additional 50% damage over 5 seconds.
<G-vec00372-002-s213><damage.verursachen><de> Belegt Ziele mit einem Feuereffekt, der 6 Sekunden lang 50% zusätzlichen Schaden verursacht.
<G-vec00372-002-s214><damage.verursachen><en> Reinhardt’s Rocket Hammer is an exemplary melee weapon, able to deal punishing damage in a wide arc with every swing.
<G-vec00372-002-s214><damage.verursachen><de> Reinhardts Raketenhammer ist eine eindrucksvolle Nahkampfwaffe, die mit jedem Schlag in einem weiten Bogen verheerenden Schaden verursacht.
<G-vec00372-002-s215><damage.verursachen><en> Combat Reserves will become available after performing effective actions in battle: dealing damage and destroying enemies.
<G-vec00372-002-s215><damage.verursachen><de> Luftangriff Gefechtsreserven werden verfügbar, nachdem ihr Schaden verursacht und Gegner zerstört habt.
<G-vec00372-002-s216><damage.verursachen><en> That way, the enemy’s counterstrikes will be less likely to do damage.
<G-vec00372-002-s216><damage.verursachen><de> Auf diese Art ist es unwahrscheinlicher, dass der Gegenschlag des Gegners Schaden verursacht.
<G-vec00372-002-s217><damage.verursachen><en> Enhance War Engine: Increases damage dealt by ranged siege weapons.
<G-vec00372-002-s217><damage.verursachen><de> Kriegsmaschine verbessern: Erhöht Schaden, der von Fernkampf-Belagerungswaffen verursacht wird.
<G-vec00372-002-s218><damage.verursachen><en> Active: Vladimir drains the lifeforce of his target, dealing magic damage and healing himself.
<G-vec00372-002-s218><damage.verursachen><de> Aktiv: Vladimir entzieht seinem Ziel die Lebenskraft, wodurch er magischen Schaden verursacht und Leben zurückerhält.
<G-vec00372-002-s219><damage.verursachen><en> If you attack while the eye is partially closed, your attack is considered a Sneak Attack and does additional damage.
<G-vec00372-002-s219><damage.verursachen><de> Wenn das Auge während eines Angriffs teilweise geschlossen ist, zählt dies als Schleichattacke, die zusätzlichen Schaden verursacht.
<G-vec00372-002-s220><damage.verursachen><en> Sends a wave of force in front of the caster, causing 6930 to 8470 damage and stunning all enemy targets within 15 yards in a frontal cone for 2 sec.
<G-vec00372-002-s220><damage.verursachen><de> Sendet vom Zaubernden aus eine Schockwelle nach vorne, die 6930 to 8470 Schaden verursacht und alle feindlichen Ziele innerhalb von 15 Metern in einem kegelförmigen Bereich vor dem Zaubernden 2 sec lang betäubt.
<G-vec00372-002-s221><damage.verursachen><en> Brand launches a ball of fire forward that deals 80/110/140/170/200 (+55% Ability Power) magic damage.
<G-vec00372-002-s221><damage.verursachen><de> Brand schleudert einen Feuerball, der 80/110/140/170/200 (+55% Fähigkeitsstärke) magischen Schaden verursacht.
<G-vec00372-002-s222><damage.verursachen><en> Angela targets the enemy who deals the highest damage, lowering their Physical and Magical Attack, and their skill effects.
<G-vec00372-002-s222><damage.verursachen><de> Angela zielt auf den Feind, der den höchsten Schaden verursacht, ihren physischen und magischen Angriff verringert und ihre Fähigkeiten verbessert.
<G-vec00372-002-s223><damage.verursachen><en> When you deal damage you heal the 3 nearest allies for 175% of all damage done.
<G-vec00372-002-s223><damage.verursachen><de> Wenn Ihr Schaden verursacht, heilt Ihr die 3 nächsten Verbündeten um 175% des gesamten verursachten Schadens.
<G-vec00372-002-s224><damage.verursachen><en> There is a huge amount of damage done by these ‘vaccines’ and in some cases electronic devices.
<G-vec00372-002-s224><damage.verursachen><de> Da wird ein riesiger Schaden verursacht durch diese ‘Impfungen’ und in einigen Fällen auch von elektronischen Vorrichtungen.
<G-vec00372-002-s225><damage.verursachen><en> Throw a demonic glaive at the target, dealing 170% Physical damage.
<G-vec00372-002-s225><damage.verursachen><de> Schleudert eine dämonische Gleve nach dem Ziel, die 170% körperlichen Schaden verursacht.
<G-vec00372-002-s226><damage.verursachen><en> Corpse Spiders Hurl a jar of spiders that deals 50 damage.
<G-vec00372-002-s226><damage.verursachen><de> Leichenspinnen Wirft ein Glas mit Spinnen, das beim Aufprall 50 Schaden verursacht.
<G-vec00372-002-s227><damage.verursachen><en> Wraith King sears an enemy unit with spectral fire, dealing damage and stunning, then dealing damage over time and slowing the target.
<G-vec00372-002-s227><damage.verursachen><de> Wraith King verbrennt eine gegnerische Einheit mit geisterhafter Flamme, die Schaden verursacht und betäubt, danach das Ziel verlangsamt und Schaden über Zeit zufügt.
