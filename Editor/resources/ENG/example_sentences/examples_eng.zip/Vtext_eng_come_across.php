<G-vec00164-002-s209><come_across.haben><en> The girl's shorts come with a textile side stripe and ensure freedom of movement thanks to the supple viscose material - perfect companions for the next summer!
<G-vec00164-002-s209><come_across.haben><de> Die Mädchen Shorts haben seitlich einen farblich passenden Besatz und machen aufgrund der angenehmen Viskose-Qualität jede Bewegung mit – ein toller Begleiter für den nächsten Sommer.
<G-vec00164-002-s210><come_across.haben><en> They come with a black leather upper and a removable insole for hygiene and practicality.
<G-vec00164-002-s210><come_across.haben><de> Sie haben ein Obermaterial aus schwarzem Leder und eine hygienische und praktische herausnehmbare sohle.
<G-vec00164-002-s211><come_across.haben><en> Come and find our new presentation of the wonderful smelling incense sticks from Paris in our store in the Belgian quarter in Cologne.
<G-vec00164-002-s211><come_across.haben><de> Wir haben Parfums, Keramik, Räucherstäbchen, Duftkerzen und Papeterie bei uns im Store in Köln.
<G-vec00164-002-s212><come_across.haben><en> Passengers really do come first here! Travel in the VIP seats above the driver's cab on the GoldenPass SuperPanoramic train from Montreux to Zweisimmen, and you'll feel like you are flying!
<G-vec00164-002-s212><come_across.haben><de> Hier haben Passagiere die Nase vorn: Wer im GoldenPass SuperPanoramic von Montreux nach Zweisimmen die VIP-Plätze bucht, hat das Gefühl zu fliegen, denn sie befinden sich hoch über dem Führerstand ganz vorne im Zug.
<G-vec00164-002-s213><come_across.haben><en> © direktbroker-FX, Alle wing: CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage.
<G-vec00164-002-s213><come_across.haben><de> Adresse: direktbroker.de AG, Risikohinweis: CFDs sind komplexe Instrumente und haben ein hohes Risiko, durch Hebelwirkung schnell Geld zu verlieren.
<G-vec00164-002-s214><come_across.haben><en> It is not clear why the ESM or this debt repayment fund should come up with any different results – they are in effect the same.
<G-vec00164-002-s214><come_across.haben><de> Es ist nicht ersichtlich, warum ESM und dieser Schuldentilgungsfonds verschiedene Ergebnisse haben sollten – sie entsprechen einander.
<G-vec00164-002-s215><come_across.haben><en> And because Mac, iPhone, iPad and iPod touch all come equipped with FaceTime, you can talk to iOS and macOS users across the street or across the globe.
<G-vec00164-002-s215><come_across.haben><de> Und weil Mac, iPhone, iPad und iPod touch alle FaceTime haben, kannst du überall mit Benutzern von iOS und macOS sprechen.
<G-vec00164-002-s216><come_across.haben><en> The bathrooms come with a bathtub, a shower and free toiletries for more comfort.
<G-vec00164-002-s216><come_across.haben><de> Die Badezimmer haben eine Badewanne, eine Dusche und kostenlose Pflegeprodukte für mehr Komfort.
<G-vec00164-002-s217><come_across.haben><en> Some hotel rooms come with a wonderful view over the city.
<G-vec00164-002-s217><come_across.haben><de> Gäste haben die Möglichkeit, einen wunderbaren Blick auf den Hafen zu bewundern.
<G-vec00164-002-s218><come_across.haben><en> The expensive models come with a built-in sensor that lets the drone steer clear of large and small objects.
<G-vec00164-002-s218><come_across.haben><de> De kostspieligeren Modelle haben einen eingebauten Sensor, der die Drohnen um große Gegenstände herum steuern lässt.
<G-vec00164-002-s219><come_across.haben><en> The luxury rooms are 40 m², and all come with balconies and terraces with a pool, sea or garden view.
<G-vec00164-002-s219><come_across.haben><de> Die Luxuszimmer sind 40 qm groß und haben Balkon oder Terrasse mit Ausblick auf den Pool, das Meer oder den Garten.
<G-vec00164-002-s220><come_across.haben><en> Most units come with a balcony.
<G-vec00164-002-s220><come_across.haben><de> Die meisten Unterkünfte haben einen Balkon.
<G-vec00164-002-s221><come_across.haben><en> The truth is, I think, that Patrick wants to put a girl in his park who looks like the girls in his magazine, which only proves once again his remote controlled nature, and there’s more to come, because Patrick wants a girl to make him come who is sexually competent but has never had sex and this, I think, is where Patrick’s remote-controlled nature reaches its limitlessly stupid climax.
<G-vec00164-002-s221><come_across.haben><de> Tatsächlich, denke ich weiter, will Patrick sich ein Mädchen in sein Gehege stellen, das so aussieht wie die Mädchen aus seinem Magazin, was sein Ferngesteuertsein einmal mehr auf den Punkt bringt und es erreicht noch seinen unglaublichen Höhepunkt, denn seinen Höhepunkt, denke ich, will Patrick von einem Mädchen verschafft haben, das sexuell kompetent ist, aber noch nie Sex hatte und an dieser Stelle, denke ich, erreicht Patricks Ferngesteuertsein in seiner ganzen unbegrenzten Dummheit seinen Höhepunkt.
<G-vec00164-002-s222><come_across.haben><en> The right images on the web may come with copyright restrictions.
<G-vec00164-002-s222><come_across.haben><de> Die richtigen Bilder im Web haben möglicherweise Copyright Beschränkungen.
<G-vec00164-002-s223><come_across.haben><en> Both of them come with a Full HD display, but only the HP comes with a contrast-rich IPS panel with wide viewing angles.
<G-vec00164-002-s223><come_across.haben><de> Beide haben eine Full-HD-Anzeige, doch nur HP setzt auf ein blickwinkelstabiles und kontraststarkes IPS-Panel.
<G-vec00164-002-s224><come_across.haben><en> There is a statement in the "Remarks" to the effect that society is not powerless against the laws of science, that man, having come to know economic laws, can utilize them in the interests of society.
<G-vec00164-002-s224><come_across.haben><de> In den „Bemerkungen“ ist der bekannte Leitsatz enthalten, dass die Gesellschaft den Gesetzen der Wissenschaft gegenüber nicht machtlos ist, dass die Menschen, wenn sie die ökonomischen Gesetze erkannt haben, dieselben im Interesse der Gesellschaft ausnutzen können.
<G-vec00164-002-s225><come_across.haben><en> The rooms come with en suite bathrooms featuring a shower, a hairdryer and complimentary toiletries.
<G-vec00164-002-s225><come_across.haben><de> Die Zimmer haben einen modernen Dekor und En-suite-Badezimmer mit einer Dusche, Morgenmänteln und einem Fön.
<G-vec00164-002-s226><come_across.haben><en> 2014 will be a crucial year in deciding who will come out ahead in future years.
<G-vec00164-002-s226><come_across.haben><de> 2014 entscheidet sich, wer in den kommenden Jahren die Nase vorn haben wird.
<G-vec00164-002-s227><come_across.haben><en> Most models come with three or four shelves; exceptions to this are the double door freezer and double door bakery freezer.
<G-vec00164-002-s227><come_across.haben><de> Die meisten Gefrierschränke haben drei oder vier Fächer; eine Ausnahme stellen hier der zweitürige Gefrierschrank sowie der zweitürige Bäckerei-Gefrierschrank dar.
<G-vec00164-002-s266><come_across.vorkommen><en> It was a feature of the UK implementation of the EMD that KYC measures did not come into play until a client had developed a material level of activity.
<G-vec00164-002-s266><come_across.vorkommen><de> Ein Merkmal der Umsetzung der EGR im Vereinigten Königreich bestand darin, dass das KYC-Prinzip erst zum Tragen kam, wenn ein Kunde beachtliche Aktivitäten entfaltete.
<G-vec00164-002-s267><come_across.vorkommen><en> I've come to understand the inner logic of the Tech. It is expressed in the Factors, the Axioms, and the Class VIII materials.
<G-vec00164-002-s267><come_across.vorkommen><de> Ich kam zum Verständnis der inneren Logik der Tech, die in den Faktoren, den Axiomen und den Class VIII Materialien ausgedrückt ist.
<G-vec00164-002-s268><come_across.vorkommen><en> No one has seen you come but you have come to stay.
<G-vec00164-002-s268><come_across.vorkommen><de> Niemand sah ihn kommen, aber er kam, um zu bleiben.
<G-vec00164-002-s269><come_across.vorkommen><en> Twice it has come with no tidings from abroad, but now finally with its return the knight and his servant ride back from Rome, bearing a papal ban against the widow who dared oppose the pious Bishop.
<G-vec00164-002-s269><come_across.vorkommen><de> Zweimal kam er, nun endlich ruft er den Rittern und Knechten ein Willkommen entgegen, die mit einem päpstlichen Briefe von Rom heimkehren, mit einem Bannbriefe über die Witwe, die den frommen Bischof zu beleidigen wagte.
<G-vec00164-002-s270><come_across.vorkommen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00164-002-s270><come_across.vorkommen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00164-002-s271><come_across.vorkommen><en> I was wearing a white gown but when reached where I was going, I come upon at least eight people sitting in chairs in half horseshoe shape.
<G-vec00164-002-s271><come_across.vorkommen><de> Ich trug ein weißes Gewand, aber als ich den Ort erreichte, zu dem ich hinstrebte, kam ich auf mindestens 8 Personen, die in Sesseln saßen, die hufeisenförmig aufgestellt waren.
<G-vec00164-002-s272><come_across.vorkommen><en> I'd come home off the road sometimes and find my wife crying.
<G-vec00164-002-s272><come_across.vorkommen><de> Ich kam einmal nach unserem Konzert nach Hause und fand meine Frau weinend zu Hause.
<G-vec00164-002-s273><come_across.vorkommen><en> Go, and you shall proceed, and come to the man of God to mount Carmel.
<G-vec00164-002-s273><come_across.vorkommen><de> 25 Also zog sie hin und kam zu dem Mann Gottes auf den Berg Karmel.
<G-vec00164-002-s274><come_across.vorkommen><en> The Term "summary" has come to us from the Latin language.
<G-vec00164-002-s274><come_across.vorkommen><de> Der Begriff "Zusammenfassung" kam zu uns aus der lateinischen Sprache.
<G-vec00164-002-s275><come_across.vorkommen><en> If Clara, who has been living in Jerusalem for years, remembers the joy of a year when she accompanied the person closest to her in the Basilica, her mother who had come to visit her, Elena waits for her parents and Sara remembers the joy of when she celebrated her Easter with his colleagues in a family atmosphere.
<G-vec00164-002-s275><come_across.vorkommen><de> Clara, die seit Jahren in Jerusalem wohnt, erinnert sich an die Freude des Jahres, als sie die Person, die ihr am meisten am Herzen liegt, nämlich ihre Mutter, die sie besuchen kam, in die Basilika begleitete, und so erwartet auch Elena ihre Eltern und Sara ist die Freude beim Feiern des Osterfestes mit ihren Kollegen in einer vertrauten Atmosphäre in Erinnerung geblieben.
<G-vec00164-002-s276><come_across.vorkommen><en> Despondent, we waited for someone from the team to come rescue us.
<G-vec00164-002-s276><come_across.vorkommen><de> Niedergeschlagen warteten wir darauf, dass jemand vom Team kam, um uns abzuholen.
<G-vec00164-002-s277><come_across.vorkommen><en> He did not realise where it had come from, though the servants who had drawn the water knew.
<G-vec00164-002-s277><come_across.vorkommen><de> Er wusste nicht, woher der Wein kam; die Diener aber, die das Wasser geschöpft hatten, wussten es.
<G-vec00164-002-s278><come_across.vorkommen><en> Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.
<G-vec00164-002-s278><come_across.vorkommen><de> Dennoch gewährte Ich diesen und ihren Vätern Versorgung in Fülle, bis die Wahrheit und ein offenkundiger Gesandter zu ihnen kam.
<G-vec00164-002-s279><come_across.vorkommen><en> They follow nothing but conjecture and what the souls desire!- Even though there has already come to them Guidance from their Lord!
<G-vec00164-002-s279><come_across.vorkommen><de> Sie folgen einem bloßen Wahn und dem Wunsche (ihres) Ichs, obwohl doch Weisung von ihrem Herrn zu ihnen kam.
<G-vec00164-002-s280><come_across.vorkommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec00164-002-s280><come_across.vorkommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec00164-002-s281><come_across.vorkommen><en> Dear children, I am your Mom and come from Heaven to lead you to My Lord.
<G-vec00164-002-s281><come_across.vorkommen><de> Ich bin eure Mutter und kam vom Himmel um euch zum Himmel zu fuehren.
<G-vec00164-002-s282><come_across.vorkommen><en> But because the Holy Spirit has come to dwell within us, and because of the promises in John 14, Jesus makes it very plain that Our Authentic Christian faith is not an esoteric religion, secret elite society, New Age or Buddhist doctrine.
<G-vec00164-002-s282><come_across.vorkommen><de> Aber weil der Heilige Geist kam, um in uns zu wohnen und aufgrund der Verheissungen in Johannes 14, macht es Jesus sehr deutlich, dass unser authentischer, christlicher Glaube keine esoterische Religion, keine geheime, elitäre Gesellschaft, kein New Age und keine buddhistische Lehre ist.
<G-vec00164-002-s283><come_across.vorkommen><en> But through their trespass salvation has come to the Gentiles, so as to make Israel jealous.
<G-vec00164-002-s283><come_across.vorkommen><de> Vielmehr kam durch ihr Versagen das Heil zu den Heiden, um sie selbst eifersüchtig zu machen.
<G-vec00164-002-s284><come_across.vorkommen><en> I saw her last one 16 months ago before I come to Germany.
<G-vec00164-002-s284><come_across.vorkommen><de> Ich habe sie zuletzt vor 16 Monaten gesehen, bevor ich nach Deutschland kam.
<G-vec00164-002-s285><come_across.vorkommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00164-002-s285><come_across.vorkommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00164-002-s286><come_across.vorkommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00164-002-s286><come_across.vorkommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00164-002-s287><come_across.vorkommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00164-002-s287><come_across.vorkommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00164-002-s288><come_across.vorkommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00164-002-s288><come_across.vorkommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00164-002-s289><come_across.vorkommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00164-002-s289><come_across.vorkommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00164-002-s290><come_across.vorkommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00164-002-s290><come_across.vorkommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00164-002-s291><come_across.vorkommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00164-002-s291><come_across.vorkommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00164-002-s292><come_across.vorkommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00164-002-s292><come_across.vorkommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00164-002-s293><come_across.vorkommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00164-002-s293><come_across.vorkommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00164-002-s294><come_across.vorkommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00164-002-s294><come_across.vorkommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00164-002-s295><come_across.vorkommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00164-002-s295><come_across.vorkommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00164-002-s296><come_across.vorkommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00164-002-s296><come_across.vorkommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00164-002-s297><come_across.vorkommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00164-002-s297><come_across.vorkommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00164-002-s298><come_across.vorkommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00164-002-s298><come_across.vorkommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00164-002-s299><come_across.vorkommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00164-002-s299><come_across.vorkommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00164-002-s300><come_across.vorkommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00164-002-s300><come_across.vorkommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00164-002-s301><come_across.vorkommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00164-002-s301><come_across.vorkommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00164-002-s302><come_across.vorkommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00164-002-s302><come_across.vorkommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00164-002-s303><come_across.vorkommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00164-002-s303><come_across.vorkommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00164-002-s304><come_across.vorkommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec00164-002-s304><come_across.vorkommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec00164-002-s305><come_across.vorkommen><en> All your wishes - come true here.
<G-vec00164-002-s305><come_across.vorkommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec00164-002-s306><come_across.vorkommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec00164-002-s306><come_across.vorkommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec00164-002-s307><come_across.vorkommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00164-002-s307><come_across.vorkommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00164-002-s308><come_across.vorkommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec00164-002-s308><come_across.vorkommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec00164-002-s309><come_across.vorkommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00164-002-s309><come_across.vorkommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00164-002-s310><come_across.vorkommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec00164-002-s310><come_across.vorkommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec00164-002-s311><come_across.vorkommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec00164-002-s311><come_across.vorkommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec00164-002-s312><come_across.vorkommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec00164-002-s312><come_across.vorkommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec00164-002-s313><come_across.vorkommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec00164-002-s313><come_across.vorkommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec00164-002-s314><come_across.vorkommen><en> Come wherever you are unknown.
<G-vec00164-002-s314><come_across.vorkommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec00164-002-s315><come_across.vorkommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec00164-002-s315><come_across.vorkommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec00164-002-s316><come_across.vorkommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec00164-002-s316><come_across.vorkommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec00164-002-s317><come_across.vorkommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec00164-002-s317><come_across.vorkommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec00164-002-s318><come_across.vorkommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec00164-002-s318><come_across.vorkommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec00164-002-s319><come_across.vorkommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec00164-002-s319><come_across.vorkommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec00164-002-s320><come_across.vorkommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec00164-002-s320><come_across.vorkommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec00164-002-s321><come_across.vorkommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec00164-002-s321><come_across.vorkommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec00164-002-s322><come_across.vorkommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec00164-002-s322><come_across.vorkommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec00164-002-s323><come_across.vorkommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec00164-002-s323><come_across.vorkommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec00164-002-s324><come_across.vorkommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00164-002-s324><come_across.vorkommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00164-002-s325><come_across.vorkommen><en> – English translation: I come from Britain.
<G-vec00164-002-s325><come_across.vorkommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec00164-002-s326><come_across.vorkommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00164-002-s326><come_across.vorkommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00164-002-s327><come_across.vorkommen><en> Will definitely come back if headed to this area again.
<G-vec00164-002-s327><come_across.vorkommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec00164-002-s328><come_across.vorkommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec00164-002-s328><come_across.vorkommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec00164-002-s329><come_across.vorkommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec00164-002-s329><come_across.vorkommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec00164-002-s330><come_across.vorkommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec00164-002-s330><come_across.vorkommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00164-002-s331><come_across.vorkommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec00164-002-s331><come_across.vorkommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00164-002-s332><come_across.vorkommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec00164-002-s332><come_across.vorkommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec00164-002-s333><come_across.vorkommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec00164-002-s333><come_across.vorkommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec00164-002-s334><come_across.vorkommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec00164-002-s334><come_across.vorkommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec00164-002-s335><come_across.vorkommen><en> I come from the picturesque city of brides, Sumy.
<G-vec00164-002-s335><come_across.vorkommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec00164-002-s336><come_across.vorkommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec00164-002-s336><come_across.vorkommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec00164-002-s337><come_across.vorkommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec00164-002-s337><come_across.vorkommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec00164-002-s338><come_across.vorkommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec00164-002-s338><come_across.vorkommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec00164-002-s339><come_across.vorkommen><en> And so I come to a second reflection.
<G-vec00164-002-s339><come_across.vorkommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec00164-002-s340><come_across.vorkommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec00164-002-s340><come_across.vorkommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec00164-002-s341><come_across.vorkommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec00164-002-s341><come_across.vorkommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec00164-002-s342><come_across.vorkommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec00164-002-s342><come_across.vorkommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec00164-002-s343><come_across.vorkommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec00164-002-s343><come_across.vorkommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec00164-002-s344><come_across.vorkommen><en> I love this country so it has been nice to be forced to come home.
<G-vec00164-002-s344><come_across.vorkommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec00164-002-s345><come_across.vorkommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec00164-002-s345><come_across.vorkommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec00164-002-s346><come_across.vorkommen><en> These now come from the cold stores.
<G-vec00164-002-s346><come_across.vorkommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec00164-002-s347><come_across.vorkommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec00164-002-s347><come_across.vorkommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec00164-002-s348><come_across.vorkommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec00164-002-s348><come_across.vorkommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec00164-002-s349><come_across.vorkommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec00164-002-s349><come_across.vorkommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec00164-002-s350><come_across.vorkommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec00164-002-s350><come_across.vorkommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec00164-002-s351><come_across.vorkommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec00164-002-s351><come_across.vorkommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec00164-002-s352><come_across.vorkommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec00164-002-s352><come_across.vorkommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec00164-002-s353><come_across.vorkommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00164-002-s353><come_across.vorkommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00164-002-s354><come_across.vorkommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec00164-002-s354><come_across.vorkommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec00164-002-s355><come_across.vorkommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec00164-002-s355><come_across.vorkommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec00164-002-s356><come_across.vorkommen><en> The artists come from Frohnau or other places.
<G-vec00164-002-s356><come_across.vorkommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec00164-002-s357><come_across.vorkommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec00164-002-s357><come_across.vorkommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec00164-002-s358><come_across.vorkommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec00164-002-s358><come_across.vorkommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec00164-002-s359><come_across.vorkommen><en> It looks like the babies all come in "twos" this spring.
<G-vec00164-002-s359><come_across.vorkommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec00164-002-s360><come_across.vorkommen><en> Come, see, hear, and marvel.
<G-vec00164-002-s360><come_across.vorkommen><de> Kommen, schauen, hören, staunen.
<G-vec00164-002-s361><come_across.vorkommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec00164-002-s361><come_across.vorkommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec00164-002-s362><come_across.vorkommen><en> Come to us, and you will not regret.
<G-vec00164-002-s362><come_across.vorkommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec00164-002-s363><come_across.vorkommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec00164-002-s363><come_across.vorkommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec00164-002-s364><come_across.vorkommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec00164-002-s364><come_across.vorkommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec00164-002-s365><come_across.vorkommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec00164-002-s365><come_across.vorkommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec00164-002-s366><come_across.vorkommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec00164-002-s366><come_across.vorkommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec00164-002-s367><come_across.vorkommen><en> Come and have a look or check our website.
<G-vec00164-002-s367><come_across.vorkommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec00164-002-s368><come_across.vorkommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec00164-002-s368><come_across.vorkommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec00164-002-s369><come_across.vorkommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec00164-002-s369><come_across.vorkommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec00164-002-s370><come_across.vorkommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec00164-002-s370><come_across.vorkommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec00164-002-s371><come_across.vorkommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec00164-002-s371><come_across.vorkommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec00164-002-s372><come_across.vorkommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec00164-002-s372><come_across.vorkommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec00164-002-s373><come_across.vorkommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec00164-002-s373><come_across.vorkommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec00164-002-s374><come_across.vorkommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec00164-002-s374><come_across.vorkommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec00164-002-s375><come_across.vorkommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec00164-002-s375><come_across.vorkommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec00164-002-s376><come_across.vorkommen><en> Come to Ulm – it will make a difference in your life.
<G-vec00164-002-s376><come_across.vorkommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec00164-002-s377><come_across.vorkommen><en> Just come, book it now and you will see for yourself.
<G-vec00164-002-s377><come_across.vorkommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec00164-002-s378><come_across.vorkommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec00164-002-s378><come_across.vorkommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec00164-002-s379><come_across.vorkommen><en> Here come easily in 4 steps to your desired server.
<G-vec00164-002-s379><come_across.vorkommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec00164-002-s399><come_across.vorkommen><en> Lights turn on when you come home.
<G-vec00164-002-s399><come_across.vorkommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec00164-002-s400><come_across.vorkommen><en> From there you will not come back.
<G-vec00164-002-s400><come_across.vorkommen><de> Von da kommst du nicht zurück.
<G-vec00164-002-s401><come_across.vorkommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec00164-002-s401><come_across.vorkommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec00164-002-s402><come_across.vorkommen><en> Will you come over and play for me.
<G-vec00164-002-s402><come_across.vorkommen><de> Kommst du rüber und spielst für mich.
<G-vec00164-002-s403><come_across.vorkommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec00164-002-s403><come_across.vorkommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec00164-002-s404><come_across.vorkommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec00164-002-s404><come_across.vorkommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec00164-002-s405><come_across.vorkommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec00164-002-s405><come_across.vorkommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec00164-002-s406><come_across.vorkommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec00164-002-s406><come_across.vorkommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec00164-002-s407><come_across.vorkommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec00164-002-s407><come_across.vorkommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec00164-002-s408><come_across.vorkommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec00164-002-s408><come_across.vorkommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00164-002-s409><come_across.vorkommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec00164-002-s409><come_across.vorkommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec00164-002-s410><come_across.vorkommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec00164-002-s410><come_across.vorkommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec00164-002-s411><come_across.vorkommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec00164-002-s411><come_across.vorkommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec00164-002-s412><come_across.vorkommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec00164-002-s412><come_across.vorkommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec00164-002-s413><come_across.vorkommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec00164-002-s413><come_across.vorkommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec00164-002-s414><come_across.vorkommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec00164-002-s414><come_across.vorkommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00164-002-s415><come_across.vorkommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec00164-002-s415><come_across.vorkommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec00164-002-s416><come_across.vorkommen><en> Moving forward is more like the platform you come from.
<G-vec00164-002-s416><come_across.vorkommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec00164-002-s417><come_across.vorkommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec00164-002-s417><come_across.vorkommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec00164-002-s418><come_across.vorkommen><en> The color must have come from cocoa powder.
<G-vec00164-002-s418><come_across.vorkommen><de> Die Farbe kommt von Kakaopulver.
<G-vec00164-002-s419><come_across.vorkommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec00164-002-s419><come_across.vorkommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec00164-002-s420><come_across.vorkommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec00164-002-s420><come_across.vorkommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec00164-002-s421><come_across.vorkommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec00164-002-s421><come_across.vorkommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec00164-002-s422><come_across.vorkommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec00164-002-s422><come_across.vorkommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec00164-002-s423><come_across.vorkommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec00164-002-s423><come_across.vorkommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec00164-002-s424><come_across.vorkommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec00164-002-s424><come_across.vorkommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec00164-002-s425><come_across.vorkommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00164-002-s425><come_across.vorkommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00164-002-s426><come_across.vorkommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec00164-002-s426><come_across.vorkommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec00164-002-s427><come_across.vorkommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec00164-002-s427><come_across.vorkommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec00164-002-s428><come_across.vorkommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec00164-002-s428><come_across.vorkommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec00164-002-s429><come_across.vorkommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec00164-002-s429><come_across.vorkommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec00164-002-s430><come_across.vorkommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec00164-002-s430><come_across.vorkommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec00164-002-s431><come_across.vorkommen><en> Come and see the place where the Lord was laid.
<G-vec00164-002-s431><come_across.vorkommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec00164-002-s432><come_across.vorkommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec00164-002-s432><come_across.vorkommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec00164-002-s433><come_across.vorkommen><en> Run up till you come to the snapping doors.
<G-vec00164-002-s433><come_across.vorkommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec00164-002-s434><come_across.vorkommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec00164-002-s434><come_across.vorkommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec00164-002-s435><come_across.vorkommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec00164-002-s435><come_across.vorkommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec00164-002-s436><come_across.vorkommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec00164-002-s436><come_across.vorkommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
