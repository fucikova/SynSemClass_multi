<G-vec00418-002-s026><crow.auftrumpfen><en> The notebook computer can crow also with his extensive security features like Fingerprint reader, TPM chip and SmartCard reader.
<G-vec00418-002-s026><crow.auftrumpfen><de> Auftrumpfen kann das Notebook auch mit seinen umfangreichen Sicherheitsfeatures wie Fingerprint Reader, TPM-Chip und SmartCard Reader.
<G-vec00418-002-s166><crow.krähen><en> And Peter remembered the words of the Lord, how he said unto him, before the cock crow thou shalt deny me thrice.
<G-vec00418-002-s166><crow.krähen><de> Und Petrus gedachte an des HERRN Wort, das er zu ihm gesagt hatte: Ehe denn der Hahn krähet, wirst du mich dreimal verleugnen.
<G-vec00418-002-s167><crow.krähen><en> 26:34 Jesus said to him, Verily I say to thee, that this night, before the cock shall crow, thou wilt deny me thrice.
<G-vec00418-002-s167><crow.krähen><de> 26:34 Jesus sprach zu ihm: Wahrlich, ich sage dir, in dieser Nacht, ehe der Hahn krähet, wirst du mich dreimal verleugnen.
<G-vec00418-002-s222><crow.rühmen><en> Many ski resorts crow about their steep slopes and deep powdery snow, but the phrase ‘steep and deep’ must have been coined at Jackson Hole Mountain Resort in the Grand Tetons.
<G-vec00418-002-s222><crow.rühmen><de> Viele Skigebiete rühmen sich ihrer steilen Abfahrten und des tiefen Pulverschnees, aber die Begriffe „steil und tief“ müssen im Jackson Hole Mountain Resort in den Grand Tetons erfunden worden sein.
