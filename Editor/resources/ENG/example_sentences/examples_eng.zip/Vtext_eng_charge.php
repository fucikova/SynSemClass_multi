<G-vec00272-001-s057><charge.aufladen><en> The wireless companies want to charge heavy users more.
<G-vec00272-001-s057><charge.aufladen><de> Die Telekommunikationsfirmen möchten schwere Benutzer mehr aufladen.
<G-vec00272-001-s058><charge.aufladen><en> The batteries provide 550Â kWh usable capacity, a range of up to 250 miles and have the ability to charge up to 80Â percent (providing a range of 200 miles) in about 90 minutes.
<G-vec00272-001-s058><charge.aufladen><de> Die Batterien liefern mit 550 kWh genug Energie für eine Reichweite bis zu 400 km (250 Meilen) und lassen sich innerhalb von 90 Minuten auf rund 80 Prozent aufladen – um weitere 320 km (200 Meilen) zurückzulegen.
<G-vec00272-001-s059><charge.aufladen><en> Although many offer as good a rate as a credit card would, it’s worth remembering that the rate is taken at the date you charge the card up rather than the day you spend money on it.
<G-vec00272-001-s059><charge.aufladen><de> Obwohl viele so gute Rate als eine Kreditkarte bieten würde, es ist daran zu erinnern, dass der Kurs am Tag Sie die Karte aufladen genommen wird, anstatt den Tag, den Sie Geld dafür ausgeben.
<G-vec00272-001-s060><charge.aufladen><en> If lost after that we would have to charge to reload a new engine map.
<G-vec00272-001-s060><charge.aufladen><de> Wenn verlor danach müssten wir aufladen, um einen neuen Motor Karte neu zu laden.
<G-vec00272-001-s061><charge.aufladen><en> The long flight time is possible thanks to the use of carbon fibers, a new battery technology, and ultra-light solar cells, which charge the batteries through the day sufficiently to allow it to remain in operation overnight.
<G-vec00272-001-s061><charge.aufladen><de> Möglich wird die lange Flugdauer durch die Verwendung von Karbonfasern, eine neue Batterietechnik sowie ultraleichte Solarzellen, welche die Akkus tagsüber so weit aufladen, dass die Drohne über Nacht einsatzfähig bleibt.
<G-vec00272-001-s062><charge.aufladen><en> Sibenik will from next week is the function of a solar tree on which citizens will be able to charge mobile phones, laptops and other gadgets.
<G-vec00272-001-s062><charge.aufladen><de> Sibenik wird ab nächster Woche ist die Funktion einer Solarbaum auf dem die Bürger in der Lage sein Handy aufladen, Laptops und andere Geräte.
<G-vec00272-001-s063><charge.aufladen><en> Emits lightning and may charge and shelter units in order to increase its intensity.
<G-vec00272-001-s063><charge.aufladen><de> Schießt Blitze, kann sich aufladen und kann Einheiten aufnehmen und dadurch seine Intensität erhöhen.
<G-vec00272-001-s064><charge.aufladen><en> A 7500 mAh battery offers up to 20 km range, a maximum climb angle of up to 25 ° and a maximum speed of 20 km / h, and only 2.5 hours to fully charge.
<G-vec00272-001-s064><charge.aufladen><de> Ein 7500 mAh-Akku bietet eine Reichweite von bis zu 20 km, einen maximalen Steigwinkel von bis zu 25 ° und eine Höchstgeschwindigkeit von 20 km / h und nur 2,5 Stunden zum vollständigen Aufladen.
<G-vec00272-001-s065><charge.aufladen><en> Never set aside the possibility of paying thousands of dollars when buying from a dealer or a specific car company, where in the end, they charge you more for the interest which takes years to pay off.
<G-vec00272-001-s065><charge.aufladen><de> Die Möglichkeit des Zahlens von Tausenden Dollar nie beiseite setzen, wenn Kaufen von einem Händler oder von einer spezifischen Autofirma, in der im Ende, sie dich mehr für das Interesse aufladen, dem Jahre zu auszahlen dauert.
<G-vec00272-001-s066><charge.aufladen><en> Two front-facing USB 3.0 ports make it super convenient to charge your controllers and mobile devices.
<G-vec00272-001-s066><charge.aufladen><de> Über die zwei frontal ausgerichteten USB-3.0-Anschlüsse lassen sich Ihre Controller und Mobilgeräte ganz einfach aufladen.
<G-vec00272-001-s067><charge.aufladen><en> For best initial performance, charge battery before first use.
<G-vec00272-001-s067><charge.aufladen><de> Die Batterie vor dem ersten Gebrauch zunächst aufladen, um gleich die beste Leistung zu erzielen.
<G-vec00272-001-s068><charge.aufladen><en> Airwheel E3 smart electric bike has a high-efficiency USB connector that can charge the phone anytime and anywhere.
<G-vec00272-001-s068><charge.aufladen><de> Airwheel E3 smart e-Bike hat einen Hochleistungs-USB-Anschluss, der das Handy jederzeit und überall aufladen kann.
<G-vec00272-001-s069><charge.aufladen><en> START/STOP is optimized for use with 12 V EFB (Enhanced Flooded Battery) and AGM batteries, but it can charge ordinary 12 V lead-acid batteries as well.
<G-vec00272-001-s069><charge.aufladen><de> Das START/STOP wurde speziell für 12V-EFB- (Enhanced Flooded Battery) und AGM-Batterien optimiert, kann aber auch herkömmliche 12V-Bleibatterien aufladen.
<G-vec00272-001-s070><charge.aufladen><en> Now I’m without a phone, and AT&T is going to charge me $500 for termination of contract + new phone + new 2 year contract.
<G-vec00272-001-s070><charge.aufladen><de> Jetzt bin ich ohne Telefon, und AT&T wird mich aufladen $500 zur Kündigung des Vertrags + neues Handy + neue 2 Jahres-Vertrag.
<G-vec00272-001-s071><charge.aufladen><en> 1) 2.5*0.7(outside diameter*inside diameter, similarly hereinafter), for short DC2507, mostly used for small size electronic products, such as panel computer that is due to volume limitations, at present, famous brand panel computer almost adopt MicroUSB connectors to charge.
<G-vec00272-001-s071><charge.aufladen><de> 1) 2,5 * 0,7 (Außendurchmesser * Innendurchmesser, ähnlich im Folgenden), kurz DC2507, vor allem für kleine elektronische Produkte, wie Panel-Computer, der aufgrund der Volumenbeschränkungen, derzeit bekannten Marke Panel Computer fast MicroUSB-Anschlüsse verwenden aufladen.
<G-vec00272-001-s072><charge.aufladen><en> For example, if you charge your iPhone at night, in the first stage it will charge up to approximately 80% (enough that you can remove iPhone from charging), followed by the rest up to 100% its loading is very slow.
<G-vec00272-001-s072><charge.aufladen><de> Wenn Sie beispielsweise Ihr iPhone nachts aufladen, wird es in der ersten Phase ungefähr aufgeladen 80% (genug, dass Sie das iPhone vom Aufladen entfernen können), gefolgt vom Rest bis zu 100% Das Laden ist sehr langsam.
<G-vec00272-001-s073><charge.aufladen><en> With a fully charged PowerBar in your bags, you can ensure that you will always be able to charge your devices anywhere anytime without having to depend on a power socket.
<G-vec00272-001-s073><charge.aufladen><de> Mit einer voll aufgeladenen PowerBar in Ihrer Tasche können Sie sicher sein, dass Sie Ihre Geräte immer und überall aufladen können - ohne dass Sie dabei von einer Steckdose abhängig sind.
<G-vec00272-001-s074><charge.aufladen><en> During your sleep you can charge your electric bike for free.
<G-vec00272-001-s074><charge.aufladen><de> Wenn Sie schlafen können sie ihren Electrisches Fahrrad kostenloss aufladen.
<G-vec00272-001-s075><charge.aufladen><en> We offer charge and hydrostatic sale.
<G-vec00272-001-s075><charge.aufladen><de> Aufladen angebot und den verkauf von feuerlöschern aller art,.
<G-vec00272-001-s114><charge.auföaden><en> The Spark Portable Charging Station is designed to wirelessly charge up to three Spark Intelligent Flight Batteries on the go.
<G-vec00272-001-s114><charge.auföaden><de> Die mobile Ladestation für die Spark ist in der Lage bis zu drei Spark Intelligent Flight Batteries unterwegs aufzuladen.
<G-vec00272-001-s115><charge.auföaden><en> The base is called “Starkiller” because it literally drains the power from stars to charge its cannon.
<G-vec00272-001-s115><charge.auföaden><de> "Die Basis wird ""Starkiller"" genannt, weil sie buchstäblich den Sternen die Energie entzieht, um ihre Kanone aufzuladen."
<G-vec00272-001-s116><charge.auföaden><en> However, if you consider how natural it has become to charge smartphones overnight, for example, the charging cycle is practically no longer an argument to be made against e-mobility in the commercial vehicle sector.
<G-vec00272-001-s116><charge.auföaden><de> Wenn man allerdings bedenkt, wie selbstverständlich es inzwischen geworden ist, etwa Smartphones über Nacht aufzuladen, ist der Ladezyklus quasi kein Argument mehr gegen eMobility im Nutzfahrzeugbereich.
<G-vec00272-001-s117><charge.auföaden><en> The Power Bank Vidvie with a capacity of 8000 mAh is manufactured with high quality materials to quickly charge the battery of your smartphone, it is, in fact, equipped with a fast charging technology.
<G-vec00272-001-s117><charge.auföaden><de> Das Power Bank Vidvie mit einer Kapazität von 8000 mAh ist aus hochwertigen Materialien gefertigt, um den Akku Ihres Smartphones schnell aufzuladen, es ist sogar mit einer Schnellladetechnologie ausgestattet.
<G-vec00272-001-s118><charge.auföaden><en> Your own bike you covered stables and also charge the battery if necessary.
<G-vec00272-001-s118><charge.auföaden><de> Ihr eigenes Fahrrad Sie bedeckten Ställe und auch die Batterie aufzuladen, wenn nötig.
<G-vec00272-001-s119><charge.auföaden><en> Electric car owners are encouraged to stop by our resort and charge their car while dining.
<G-vec00272-001-s119><charge.auföaden><de> Besitzer von Elektroautos sind herzlich eingeladen, in unserem Resort essen zu gehen und in der Zwischenzeit ihr Fahrzeug aufzuladen.
<G-vec00272-001-s120><charge.auföaden><en> Featuring a USB-C cable and enough power to charge your phone quickly and easily, you can be certain that this car charger is compatible with your Motorola One.
<G-vec00272-001-s120><charge.auföaden><de> Mit einem USB-C-Kabel und genügend Strom, um Ihr Handy schnell und einfach aufzuladen, können Sie sicher sein, dass dieses Autoladegerät mit Ihrem Motorola One kompatibel ist.
<G-vec00272-001-s121><charge.auföaden><en> You can also connect a charging cable to the USB-C port to charge your MacBook.
<G-vec00272-001-s121><charge.auföaden><de> Sie können auch ein Ladekabel an den USB-C-Anschluss anschließen, um Ihr MacBook aufzuladen.
<G-vec00272-001-s122><charge.auföaden><en> This quality cable allows you to connect your Motorola Moto G6 to your laptop or desktop, in order to charge your phone and exchange / sync data simultaneously.
<G-vec00272-001-s122><charge.auföaden><de> Mit diesem Qualitätskabel können Sie Ihr Motorola One an Ihren Laptop oder Desktop anschließen, um Ihr Telefon aufzuladen und gleichzeitig Daten auszutauschen / zu synchronisieren.
<G-vec00272-001-s123><charge.auföaden><en> You may want to leave the battery slow charging overnight to fully charge it if it has been dead for some time.
<G-vec00272-001-s123><charge.auföaden><de> Du solltest die Batterie eventuell über Nacht langsam aufladen, um sie voll aufzuladen, falls sie einige Zeit leer war.
<G-vec00272-001-s124><charge.auföaden><en> You should also try to be on top of your competitor's prices, to undercut an existing photographer is one choice, but to neglect to value your skills and not charge enough to cover your overheads is another matter entirely.
<G-vec00272-001-s124><charge.auföaden><de> Sie sollten auch versuchen, auf Preise Ihres Konkurrenten zu sein, einen vorhandenen Photographen ist zu unterschneiden eine Wahl, aber zu vernachlässigen, Ihre Fähigkeiten zu bewerten und genug nicht aufzuladen, um Ihre overheads zu umfassen ist eine andere Angelegenheit völlig.
<G-vec00272-001-s125><charge.auföaden><en> He concentrated and used extremely rare techniques of energy modification to charge himself to full power.
<G-vec00272-001-s125><charge.auföaden><de> Er konzentrierte sich mit Hilfe seltener Techniken der Energiemodulation, um sich auf das höchste Niveau aufzuladen.
<G-vec00272-001-s126><charge.auföaden><en> So, if you choose a cordless screwdriver, then before you start working, you need to charge it.
<G-vec00272-001-s126><charge.auföaden><de> Also, wenn Sie einen Akkuschrauber wählen, dann, bevor Sie anfangen zu arbeiten, müssen Sie es aufzuladen.
<G-vec00272-001-s127><charge.auföaden><en> With his portable sculptures, Bruno Munari opened up the possibility to personalize a hotel room or any other anonymous place and thus charge it with culture.
<G-vec00272-001-s127><charge.auföaden><de> Bruno Munari dachte bei den tragbaren Kunstwerken an die Möglichkeit, ein Hotelzimmer oder einen anderen anonymen Ort zu individualisieren und mit Kultur aufzuladen.
<G-vec00272-001-s128><charge.auföaden><en> Printed solar panels could be incorporated into the tent fabric and save energy – for lamps (possibly also printed into the tent fabric), the cooker and to charge mobile phones.
<G-vec00272-001-s128><charge.auföaden><de> So könnten in den Zeltstoff eingearbeitete, gedruckte Solarpanels Energie spenden - für Lampen (möglicherweise auch in gedruckter Form in den Zeltstoff integriert), den Kocher, oder um das Handy aufzuladen.
<G-vec00272-001-s129><charge.auföaden><en> AC dynamo charger: Winding the dynamo crank can charge mobile phone, MP3, iPod and installed rechargeable battery.
<G-vec00272-001-s129><charge.auföaden><de> AC Dynamo -Ladegerät: Winding der Dynamo Kurbel können Handy, MP3, iPod und eingebauter wiederaufladbarer Akku aufzuladen.
<G-vec00272-001-s130><charge.auföaden><en> Though most bars will charge you for larger portions such as sandwiches, many tapas in the southern regions of the country come free when ordering a drink.
<G-vec00272-001-s130><charge.auföaden><de> Obwohl die meisten Bars werden Sie für größere Teile wie Sandwiches aufzuladen, vielen Tapas in den südlichen Regionen des Landes kommen kostenlos bei der Bestellung ein Getränk.
<G-vec00272-001-s131><charge.auföaden><en> Therefore it is better to charge with efforts firm where you have decided to get a cloth.
<G-vec00272-001-s131><charge.auföaden><de> Deshalb ist es besser, die Bemühungen auf die Firma aufzuladen, wo Sie sich entschieden haben, das Leinen zu erwerben.
<G-vec00272-001-s132><charge.auföaden><en> Inductive Charging Wireless charging is proving to be a popular and convenient way to charge mobile devices.
<G-vec00272-001-s132><charge.auföaden><de> Mehr Informationen Induktives Laden Induktives Laden bietet eine einfache und bequeme Methode um mobile Geräte aufzuladen.
<G-vec00272-001-s133><charge.belasten><en> You agree and reaffirm that Three Rings is authorized to charge your credit card each month, quarter, or year according to the terms of your subscription.
<G-vec00272-001-s133><charge.belasten><de> Du stimmst zu und bestätigst, dass Three Rings autorisiert ist, deine Kreditkarte gemäß deiner Abonnementbedingungen monatlich, im Quartal oder einmal jährlich zu belasten.
<G-vec00272-001-s134><charge.belasten><en> Please note Disney Vacation Homes reserves the right to charge guest credit cards in the event of damages to the property.
<G-vec00272-001-s134><charge.belasten><de> Bitte beachten Sie, dass die Disney Vacation Homes sich das Recht vorbehalten, Ihre Kreditkarten im Falle von Schäden an der Unterkunft zu belasten.
<G-vec00272-001-s135><charge.belasten><en> If the customer does not pay the deposit and/or the balance in accordance with the agreed due dates, although Velociped is willing and able to deliver the contractual services properly and has met their legal information obligations, and no legal or contractual customer right of retention exists, Velociped is entitled to withdraw from the package travel contract after a warning with a notice period, and to charge the customer cancellation fees as per point 6.
<G-vec00272-001-s135><charge.belasten><de> Leistet der Kunde die Anzahlung und/oder die Restzahlung nicht entsprechend den vereinbarten Zahlungsfälligkeiten, obwohl Velociped zur ordnungsgemäßen Erbringung der vertraglichen Leistungen bereit und in der Lage ist, seine gesetzlichen Informationspflichten erfüllt hat und kein gesetzliches oder vertragliches Zurückbehaltungsrecht des Kunden besteht, so ist Velociped berechtigt, nach Mahnung mit Fristsetzung vom Pauschalreisevertrag zurückzutreten und den Kunden mit Rücktrittskosten gemäß Ziffer 6 zu belasten.
<G-vec00272-001-s136><charge.belasten><en> If Apple is unable to successfully charge your credit card or payment account for fees due, Apple reserves the right to revoke or restrict access to your stored Content, delete your stored Content, or terminate your Account.
<G-vec00272-001-s136><charge.belasten><de> Wenn es Apple nicht möglich ist, deine Kreditkarte oder dein Zahlungskonto für die fälligen Gebühren erfolgreich zu belasten, behält sich Apple das Recht vor, deinen Zugang zu den gespeicherten Inhalten zu beenden oder zu beschränken, deine gespeicherten Inhalte zu löschen oder deinen Account zu kündigen.
<G-vec00272-001-s137><charge.belasten><en> We reserve the right to charge You a fee to cover Our reasonable costs for doing this.
<G-vec00272-001-s137><charge.belasten><de> Wir behalten uns das Recht vor, Ihnen eine Gebühr zu belasten, um unsere angemessenen Kosten in diesem Zusammenhang zu decken.
<G-vec00272-001-s138><charge.belasten><en> Additional details: The Hotel will charge your card in Swiss franc based on the exchange rate of the transaction date.
<G-vec00272-001-s138><charge.belasten><de> Weitere Details: Das Hotel wird Ihre Kreditkarte in Schweizer Franken belasten – zum am Tag der Buchung gültigen Wechselkurs.
<G-vec00272-001-s139><charge.belasten><en> "These lawsuits charge former Chinese president Jiang Zemin and the heads of the ""610 office"" [a Chinese Gestapo-like organisation set up by Jiang to implement the persecution of Falun Gong] with genocide and crimes against humanity."
<G-vec00272-001-s139><charge.belasten><de> Diese Klagen belasten den ehemaligen chinesischen Präsidenten Jiang Zemin und die Leiter des Büro 610 (einer chinesischen Gestapo- ähnlichen Organisation, von Jiang Zemin gebildet, um die Verfolgung von Falun Gong durchzuführen) mit Völkermord und Verbrechen gegen die Menschlichkeit.
<G-vec00272-001-s140><charge.belasten><en> 7 Payment We will charge your credit card or debit your bank account or send you a weekly invoice
<G-vec00272-001-s140><charge.belasten><de> 7 Zahlung Wir belasten Ihre Kreditkarte oder Ihr Bankkonto oder senden Ihnen wöchentlich eine Rechnung.
<G-vec00272-001-s141><charge.belasten><en> In the event of default by the consumer, the entrepreneur has the right, subject to legal restrictions, to charge the reasonable costs made known to the consumer beforehand.
<G-vec00272-001-s141><charge.belasten><de> Im Fall des Verzuges durch die Verbraucher, der Unternehmer unterliegt gesetzliche Einschränkungen, das Recht, die angemessen Kosten für die Verbraucher zu belasten.
<G-vec00272-001-s142><charge.belasten><en> Payment Virtual Terminal is used when you wish to charge your guest's credit card manually.
<G-vec00272-001-s142><charge.belasten><de> Payment Virtual Terminal verwendet wird, wenn Sie möchten, manuell Ihres Gastes Kreditkarte zu belasten.
<G-vec00272-001-s143><charge.belasten><en> The hotel will charge your credit card.
<G-vec00272-001-s143><charge.belasten><de> Das Hotel wird dann Ihre Kreditkarte belasten.
<G-vec00272-001-s144><charge.belasten><en> Once you have requested a Badoo premium service, you authorise Badoo to charge your chosen payment method.
<G-vec00272-001-s144><charge.belasten><de> Mit dem Kauf einer Premiumfunktion gibst du Badoo die Erlaubnis, deine ausgewählte Zahlungsmethode zu belasten.
<G-vec00272-001-s145><charge.belasten><en> If Members choose to furnish credit card information to Enterprise, Members: (a) represent that they are the individual whose name appears on the card or that they are the authorised user of the card; (b) direct Enterprise to store all such information in accordance with the applicable Enterprise Rent-A-Car Privacy Policy; and (c) authorise and instruct Enterprise to charge any rental car charges incurred by the Member to that credit card.
<G-vec00272-001-s145><charge.belasten><de> Wenn sich Mitglieder zur Übermittlung der Kreditkartendaten an Enterprise entschließen, dann (a) sichern sie zu, dass sie die Person sind, deren Name auf der Kreditkarte angegeben ist, oder dass sie der berechtigte Nutzer der Karte sind, (b) weisen sie Enterprise an, diese Daten gemäß der geltenden Datenschutzrichtlinie von Enterprise Rent-A-Car zu speichern, und (c) ermächtigen und weisen sie Enterprise an, diese Kreditkarte mit allen anfallenden Mietwagengebühren zu belasten.
<G-vec00272-001-s146><charge.belasten><en> If the credit card holder is not staying in the hotel, written permission of the owner of the card is required in order to charge the card.
<G-vec00272-001-s146><charge.belasten><de> Wenn sich der Inhaber der Kreditkarte nicht im Hotel aufhält, wird eine schriftliche Genehmigung des Karteninhabers benötigt, um die Karte zu belasten.
<G-vec00272-001-s147><charge.belasten><en> Condor Ocean View Apartments Surfers Paradise will charge the total amount of your reservation to your credit card as a security deposit 7 days prior to your arrival date.
<G-vec00272-001-s147><charge.belasten><de> Die Condor Ocean View Apartments Surfers Paradise werden Ihre Kreditkarte mit dem Gesamtbuchungsbetrag 7 Tage vor Ihrer Ankunft als Kaution belasten.
<G-vec00272-001-s148><charge.belasten><en> The hotel reserves the right to charge the total amount to the credit card provided in case the amount exceeds EUR 800
<G-vec00272-001-s148><charge.belasten><de> Das Hotel behält sich das Recht vor, die Kreditkarte mit dem kompletten Betrag zu belasten, falls die Gesamtbuchungssumme den Betrag von EUR 800 übersteigt.
<G-vec00272-001-s149><charge.belasten><en> He may also purchase goods and services whilst overseas and his credit card company has to convert those sales back into his base currency in order to charge him.
<G-vec00272-001-s149><charge.belasten><de> Er kann im Ausland auch Waren und Dienste kaufen, und seine Kreditkartengesellschaft muss diese Käufe in seine Basiswährung konvertieren, um seine Karte damit zu belasten.
<G-vec00272-001-s150><charge.belasten><en> If you fail to return the replaced product, part or accessory as instructed or return a replaced product, part or accessory that is ineligible for service, Apple will charge the credit card for the authorized amount.
<G-vec00272-001-s150><charge.belasten><de> Falls Sie das ausgetauschte Produkt, Teil oder Zubehör nicht gemäß den Anweisungen zurückgeben oder wenn Sie ein ausgetauschtes Produkt, Teil oder Zubehör zurückgeben, für das die Serviceleistung nicht beansprucht werden kann, wird Apple die Kreditkarte mit dem autorisierten Betrag belasten.
<G-vec00272-001-s151><charge.belasten><en> "At first, the police tried to charge him with ""subverting the government."""
<G-vec00272-001-s151><charge.belasten><de> Zuerst versuchte die Polizei, ihn zu belasten, indem sie behaupteten, dass er „die Regierung untergraben“ hätte.
<G-vec00272-001-s152><charge.berechnen><en> For cancellations received within 7 days of your scheduled arrival date, we will charge one-half of the total room charges for your reservation.
<G-vec00272-001-s152><charge.berechnen><de> Bei Stornierungen innerhalb von 7 Tagen nach Anreise berechnen wir die Hälfte der Gesamtfläche des Zimmers Gebühren für Ihre Reservierung.
<G-vec00272-001-s153><charge.berechnen><en> Dogs are welcome in our hotel. We will charge CHF 15.00 per day & pet.
<G-vec00272-001-s153><charge.berechnen><de> Hunde sind bei uns willkommen, wir berechnen Ihnen CHF 15.00 pro Tag für Ihren Vierbeiner.
<G-vec00272-001-s154><charge.berechnen><en> We only charge based on the amount of emails you send.
<G-vec00272-001-s154><charge.berechnen><de> Wir berechnen nur nach der Anzahl der gesendeten E-Mails.
<G-vec00272-001-s155><charge.berechnen><en> From figuring out which rate to charge which customer to dealing with complicated sales tax filing forms, it's understandable that you want to shove “sales tax” to number 39 on your massive to-do list.
<G-vec00272-001-s155><charge.berechnen><de> "Von herauszufinden, die rate zu berechnen, die der Kunde für den Umgang mit komplizierten Umsatz-Steuer-ausfüllen von Formularen, es ist verständlich, dass Sie möchten, um zu schieben ""sales tax"" an die Nummer 39 auf Ihre riesige to-do-Liste."
<G-vec00272-001-s156><charge.berechnen><en> If your hold luggage weighs more than your allowance when you arrive at the airport we charge you a fee for each 1kg of excess weight.
<G-vec00272-001-s156><charge.berechnen><de> Wenn Sie am Flughafen ankommen und Ihr Gepäck mehr als Ihre Freigepäckgrenze wiegt, berechnen wir Ihnen eine Gebühr für jedes Kilogramm Übergewicht.
<G-vec00272-001-s157><charge.berechnen><en> (2) If we suffer a loss due to the belated purchase, we are entitled to charge a lump sum of 10% of the value of the not rendered service as compensation, unless the customer can prove the damage is worth less.
<G-vec00272-001-s157><charge.berechnen><de> (2) Entsteht uns durch die verspätete Abnahme ein Schaden, so sind wir berechtigt, pauschal 10 % des für die nicht abgenommene Leistung vereinbarten Entgelts als Schadensersatz zu berechnen, sofern uns der Kunde keinen niedrigeren Schaden nachweist.
<G-vec00272-001-s158><charge.berechnen><en> Dispatch costs (inclusive of legally applicable VAT) Domestic deliveries (Germany): We charge a flat shipping fee of 4,95 € per order.
<G-vec00272-001-s158><charge.berechnen><de> Versandkosten (inklusive gesetzliche Mehrwertsteuer) Lieferungen im Inland (Deutschland): Wir berechnen die Versandkosten pauschal mit 4,95 € pro Bestellung.
<G-vec00272-001-s159><charge.berechnen><en> In this case we will transfer money to your account charging you 10% of the order’s amount and the minimum charge is € 5, -.
<G-vec00272-001-s159><charge.berechnen><de> Um Ihr Geld wieder Ihrem Konto gutzuschreiben, berechnen wir 10% Kosten mit einem Mindestbetrag von € 5,-.
<G-vec00272-001-s160><charge.berechnen><en> Failure to notify us will result in a day-use charge of EUR 20.– .
<G-vec00272-001-s160><charge.berechnen><de> Bei keiner Rückmeldung sehen wir uns leider gezwungen Ihnen ein day-use von EUR 20,– zu berechnen.
<G-vec00272-001-s161><charge.berechnen><en> 3.2 The following shall apply to orders which are to be delivered more than four months after conclusion of the contract: should our purchase prices and/or our applicable wages and salaries increase until the time the contract is executed, we shall be entitled to charge a higher price on a pro rata basis as a percentage of the purchase price and/or the labour costs.
<G-vec00272-001-s161><charge.berechnen><de> 3.2 Erhöhen sich bei Aufträgen, die später als vier Monate nach Abschluss ausgeliefert werden sollen, unsere Einkaufspreise und/oder der für uns gültige Lohn- und Gehaltstarif bis zur Ausführung des Auftrags, dürfen wir einen im Rahmen des prozentualen Anteils des Einkaufspreises und/oder der Lohnkosten am vereinbarten Preis verhältnismäßig entsprechend erhöhten Preis berechnen.
<G-vec00272-001-s162><charge.berechnen><en> While app design companies would charge you expensive developer and designer fees, none of that is required with Phorest Salon Software’s proposition.
<G-vec00272-001-s162><charge.berechnen><de> Und während App-Design-Firmen dir teure Entwickler- und Designergebühren berechnen würden, ist nichts davon mit dem Angebot von Phorest Salon Software erforderlich.
<G-vec00272-001-s163><charge.berechnen><en> If you cancel later than the accommodation establishes as a deadline or does not notify of the cancellation of the reservation, the accommodation may charge you an amount which in most cases is equivalent to the amount of the first night.
<G-vec00272-001-s163><charge.berechnen><de> Wenn Sie später stornieren, als die Unterkunft als Termin festlegt oder nicht über die Stornierung der Reservierung informiert, kann die Unterkunft Ihnen einen Betrag berechnen, der in den meisten Fällen der Höhe der ersten Nacht entspricht.
<G-vec00272-001-s164><charge.berechnen><en> Our arrangement for a cancellation is as follows: If you cancel more than ten days in advance, we will not charge you anything.
<G-vec00272-001-s164><charge.berechnen><de> Unser Arrangement für eine Stornierung ist wie folgt: Wenn Sie mehr als zehn Tage im Voraus kündigen, wird nicht berechnen wir Ihnen nichts.
<G-vec00272-001-s165><charge.berechnen><en> The prices we charge 1 EUR City tax per person per night.
<G-vec00272-001-s165><charge.berechnen><de> Die Preise berechnen wir 1 € Kurtaxe pro Person pro Nacht.
<G-vec00272-001-s166><charge.berechnen><en> We charge a one time handling fee of € 14.90 per booking.
<G-vec00272-001-s166><charge.berechnen><de> Wir berechnen eine einmalige Bearbeitungs- und Versandpauschale von 14,90 € pro Buchung.
<G-vec00272-001-s167><charge.berechnen><en> If release order dates are not adhered to by the customer then we are entitled to delivery and to charge in full four weeks after the written announcement with reference to the consequences of the release order which was not carried out.
<G-vec00272-001-s167><charge.berechnen><de> Werden vom Kunden Abruftermine nicht eingehalten, so sind wir berechtigt, vier Wochen nach schriftlicher Ankündigung unter Hinweis auf die Folgen des unterbliebenen Abrufes, die Gesamtmenge vollständig zu liefern und zu berechnen.
<G-vec00272-001-s168><charge.berechnen><en> In the event of delayed payment TUNZE Aquarientechnik GmbH is entitled to charge interest on arrears amounting to 1% above our rate of discount.
<G-vec00272-001-s168><charge.berechnen><de> Bei Zahlungsverzug ist Firma TUNZE Aquarientechnik GmbH, berechtigt, Verzugszinsen in Höhe von 1 % über dem jeweiligen Eigendiskontsatz zu berechnen.
<G-vec00272-001-s169><charge.berechnen><en> A note, such as “plus the usual ancillary charges” entitles the freight forwarder, Special charges and to charge for supplements.
<G-vec00272-001-s169><charge.berechnen><de> Ein Vermerk, wie etwa „zuzüglich der üblichen Nebenspesen“ berechtigt den Spediteur, Sondergebühren und Sonderauslagen zusätzlich zu berechnen.
<G-vec00272-001-s170><charge.berechnen><en> We charge a shipping fee of EUR 2.95 for all deliveries within Germany, regardless of the number of items ordered or the amount of the order value.
<G-vec00272-001-s170><charge.berechnen><de> Wir berechnen eine Versandkostenpauschale in Höhe von 2,95 Euro für alle Lieferungen innerhalb von Deutschland und unabhängig von der Anzahl der bestellten Artikel oder der Höhe des Bestellwertes.
<G-vec00272-001-s171><charge.berechnen><en> If you cancel less than 48 hours in advance, or in the case of a no show, we.ll charge you the full amount.
<G-vec00272-001-s171><charge.berechnen><de> Wenn Sie weniger als 48 Stunden im voraus, oder im Falle eines no-Show abbrechen, we.ll berechnet Ihnen den vollen Betrag.
<G-vec00272-001-s172><charge.berechnen><en> For all reservations of 7 nights or more, the hotel will charge a non-refundable deposit equivalent to 3 nights.
<G-vec00272-001-s172><charge.berechnen><de> Bei allen Buchungen von 7 Nächten oder mehr berechnet das Hotel eine nicht erstattbare Anzahlung in der Höhe von 3 Übernachtungen.
<G-vec00272-001-s173><charge.berechnen><en> Please note that in case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s173><charge.berechnen><de> Bitte beachten Sie, dass das Hotel im Falle einer vorzeitigen Abreise den gesamten Betrag des gebuchten Aufenthalts berechnet.
<G-vec00272-001-s174><charge.berechnen><en> Please note that extra charge will apply if guests upgrade the breakfast.
<G-vec00272-001-s174><charge.berechnen><de> Bitte beachten Sie, dass für die Buchung des Frühstücks ein Aufpreis berechnet wird.
<G-vec00272-001-s175><charge.berechnen><en> Please note there is an extra charge for using the sauna.
<G-vec00272-001-s175><charge.berechnen><de> Bitte beachten Sie, dass für die Nutzung der Sauna ein Aufpreis berechnet wird.
<G-vec00272-001-s176><charge.berechnen><en> In case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s176><charge.berechnen><de> Reisen Sie vor dem gebuchten Zeitpunkt ab, berechnet das Hotel den Betrag für den gesamten Aufenthalt.
<G-vec00272-001-s177><charge.berechnen><en> Room service and use of the conference hall are free of any surplus charge.
<G-vec00272-001-s177><charge.berechnen><de> Für den Zimmerservice und die Nutzung des Konferenzraums wird kein Aufschlag berechnet.
<G-vec00272-001-s178><charge.berechnen><en> The hotel provides WiFi internet; spacious and bright rooms; a restaurant and a bar; a pretty terrace with fabulous views of the lake and gardens; a large, well-lit hall, outdoor parking (additional charge); 3 meeting rooms with natural light, air conditioning and a maximum capacity for up to 140 people.
<G-vec00272-001-s178><charge.berechnen><de> WLAN-Internetzugang; geräumige, helle Zimmer; ein Restaurant und eine Bar; eine wunderschöne Sommerterrasse mit Blick auf den See und den Garten; eine große, helle Lobby, Parkplatz (wird extra berechnet); 3 Konferenzräume mit Tageslichteinfall, Klimaanlage und Platz für bis zu 140 Teilnehmer.
<G-vec00272-001-s179><charge.berechnen><en> Cancellations must be made no later than 2 weeks prior to arrival or a cancellation charge applies.
<G-vec00272-001-s179><charge.berechnen><de> Stornierungen müssen bis spätestens 2 Wochen vor der Ankunft erfolgen, andernfalls werden Stornierungsgebühren berechnet.
<G-vec00272-001-s180><charge.berechnen><en> [1] Withdrawing cash through the DKB-card is in practice free of charge in more than 99 per cent of cases, because the DKB does not charge its customers any fees and takes the fees of foreign ATMs automatically.
<G-vec00272-001-s180><charge.berechnen><de> [1] Das Abheben von Bargeld über die DKB-Karten ist in der Praxis zu über 99 Prozent kostenlos, weil die DKB ihren Kunden keine Gebühren berechnet und die Gebühren der Fremdautomaten automatisch übernimmt.
<G-vec00272-001-s181><charge.berechnen><en> No additional night charge is made for journeys abroad.
<G-vec00272-001-s181><charge.berechnen><de> Bei Auslandsfahrten wird kein Nachtzuschlag berechnet.
<G-vec00272-001-s182><charge.berechnen><en> Please note that the property will charge a 25% deposit at the moment of booking.
<G-vec00272-001-s182><charge.berechnen><de> Bitte beachten Sie, dass die Unterkunft bei der Buchung eine Anzahlung von 25 % des Gesamtpreises berechnet.
<G-vec00272-001-s183><charge.berechnen><en> If you use a credit or debit card to fully or partially fund international personal payments, PayPal will charge a cross border fee, which can range from 2.9% to 7.4% plus an additional fixed fee.
<G-vec00272-001-s183><charge.berechnen><de> Wenn Sie eine Kredit- oder Debitkarte für die vollständige oder teilweise Finanzierung von internationalen persönlichen Zahlungen verwenden, berechnet PayPal eine Auslandsgebühr, die zwischen 2,9 % und 7,4 % zuzüglich einer festen Gebühr betragen kann.
<G-vec00272-001-s184><charge.berechnen><en> • Credit card companies usually charge an additional fee for purchases in foreign currencies (foreign currency fee).
<G-vec00272-001-s184><charge.berechnen><de> • Das Kreditkarteninstitut berechnet in der Regel bei Käufen in fremder Währung eine zusätzliche Gebühr (Fremdwährungszuschlag).
<G-vec00272-001-s185><charge.berechnen><en> with kitchenette, coffee maker, toaster, electric kettle, terrace, bed linen is available, towels and tea towels are not themselves or rent (extra charge) .
<G-vec00272-001-s185><charge.berechnen><de> mit Küchenzeile, Kaffeemaschine, Toaster, Wasserkocher,Terrasse, Bettwäsche ist vorhanden, Handtücher und Geschirrtücher sind selber mitzubringen oder zu mieten (wird extra berechnet).
<G-vec00272-001-s186><charge.berechnen><en> Please note that NÃ1⁄4rnbergMesse GmbH will charge a fee of EUR 800 in the event of a contravention of this.
<G-vec00272-001-s186><charge.berechnen><de> Bitte beachten Sie, dass die NürnbergMesse GmbH im Falle von Zuwiderhandlung eine Gebühr von EUR 800 berechnet.
<G-vec00272-001-s187><charge.berechnen><en> Please note that there is an extra charge and these requests are based on availability.
<G-vec00272-001-s187><charge.berechnen><de> Bitte beachten Sie, dass ein Aufpreis berechnet wird und diese Anfragen der Verfügbarkeit unterliegen.
<G-vec00272-001-s188><charge.berechnen><en> There will be an extra charge per dog per night.
<G-vec00272-001-s188><charge.berechnen><de> Pro Hund und Nacht wird ein Aufpreis berechnet.
<G-vec00272-001-s189><charge.berechnen><en> 2.7 For the processing of mere supply contracts without set-up with an invoice amount of 50,00€, ABASS GmbH shall charge a processing fee of 5,00€ plus value-added tax.
<G-vec00272-001-s189><charge.berechnen><de> 2.7 Für die Abwicklung bloßer Lieferaufträge ohne Montage mit einem Rechnungswert bis zu 50,00 € netto berechnet ABASS GMBH eine Bearbeitungspauschale von 5,00 € zuzüglich Mehrwertsteuer.
<G-vec00272-001-s209><charge.erheben><en> 8.2.8 We will not typically charge you a fee to deposit or withdraw funds. However, if we suspect that you are misusing the deposit and/or withdrawal functionality, we reserve the right to charge you a fee to reflect any costs incurred by us in connection with such misuse.
<G-vec00272-001-s209><charge.erheben><de> Wenn wir allerdings vermuten, dass Sie die Funktionalität der Ein- und/oder Auszahlung missbrauchen, behalten wir uns das Recht vor, eine Gebühr zu erheben, um jegliche Kosten, die im Zusammenhang mit solchem Missbrauch entstanden sind, zu begleichen.
<G-vec00272-001-s210><charge.erheben><en> Some banks charge additional fees for international transfers to Germany.
<G-vec00272-001-s210><charge.erheben><de> Bei internationalen Überweisungen nach Deutschland erheben einige Banken zusätzliche Gebühren.
<G-vec00272-001-s211><charge.erheben><en> We charge a standard commission rate of 50 USD per 1 million USD traded, with the benefit of increasing discounts for larger cumulative trading volume, i.e. the more volume traded, the cheaper trading costs (commission) become.
<G-vec00272-001-s211><charge.erheben><de> Wir erheben eine Standardkommission von 50 USD pro gehandelter Million USD bei steigenden Preisnachlässen für umfangreichere Gesamthandelsvolumen, d.h. je größer das Handelsvolumen ausfällt, umso günstiger werden die Handelskosten (Kommissionen).
<G-vec00272-001-s212><charge.erheben><en> Those pipelines were very important for all the American oil majors, which had invested a great deal of money into Kazakhstan, Turkmenistan, and they were in a situation where they were developing the oil and gas and controlled them, but the only ways they had to get it out there were through Russia, and Russia was in a position to charge quite exorbitant rates on the pipelines.
<G-vec00272-001-s212><charge.erheben><de> Diese Pipelines waren sehr wichtig für alle großen amerikanischen Ölkonzerne, die sehr viel Geld in Kasachstan und Turkmenistan investiert hatten, und sie waren in einer Situation, wo sie das Öl- und Gas entwickelten und es kontrollierten, aber die einzigen Wege, um es von dort rauszubekommen, gingen durch Russland, und Russland war in der Lage, recht hohe Gebühren auf die Pipelines zu erheben.
<G-vec00272-001-s213><charge.erheben><en> If someone violates our rules or regulations, we charge a supervision fee of 1000 SEK.
<G-vec00272-001-s213><charge.erheben><de> Verstößt jemand gegen unsere Regeln oder Vorschriften, erheben wir eine Überwachungsgebühr von 1000 SEK.
<G-vec00272-001-s214><charge.erheben><en> Eventbrite reserves the right to charge fees for future use of or access to the Eventbrite APIs in Eventbrite's discretion.
<G-vec00272-001-s214><charge.erheben><de> Eventbrite behält sich das Recht vor, nach eigenem Ermessen Gebühren für die Nutzung oder den künftigen Zugriff auf die Eventbrite-APIs zu erheben.
<G-vec00272-001-s215><charge.erheben><en> *In case of no show or cancellation within 24Hrs of arrival, will incur a cancellation charge for 50% the entire length of stay.
<G-vec00272-001-s215><charge.erheben><de> * Im Falle von No Show oder Stornierung innerhalb von 24 Stunden der Anreise erfolgen, erheben wir eine Stornogebühr von 50% der gesamten Dauer des Aufenthalts.
<G-vec00272-001-s216><charge.erheben><en> 44% of hotels charge a premium for including an LRA clause.
<G-vec00272-001-s216><charge.erheben><de> 44 Prozent der Hotels erheben einen Zuschlag für die Einbindung einer Klausel zur Last Room Availability.
<G-vec00272-001-s217><charge.erheben><en> We charge a small fee for the courses, usually in the amount of 15 Euro per course day (exceptions are possible).
<G-vec00272-001-s217><charge.erheben><de> Wir erheben eine geringe Gebühr für die Kurse, die in der Regel bei 15 € pro Kurstag liegt (Ausnahmen sind möglich).
<G-vec00272-001-s218><charge.erheben><en> We charge our hearts with the best will spingiamoci and at the foot of Christ to ask him the tenderness of his understanding, the strength of His Omnipotence and the triumph of His grace.
<G-vec00272-001-s218><charge.erheben><de> Wir erheben unsere Herzen mit dem besten Willen spingiamoci und am Fuße des Christus zu bitten, ihm die Zärtlichkeit seines Verstehens, die Stärke seiner Allmacht und den Triumph seiner Gnade.
<G-vec00272-001-s219><charge.erheben><en> 2 A Contracting Party shall not impose on nationals of any other Party any residence charge not required of its own nationals.
<G-vec00272-001-s219><charge.erheben><de> 2 Ein Vertragstaat wird von den Staatsangehörigen eines anderen Vertragstaates keine Aufenthaltsgebühren erheben, die nicht auch von den eigenen Staatsangehörigen gefordert werden.
<G-vec00272-001-s220><charge.erheben><en> Until the Delhi Supreme Court decides on the validity of the patent, Monsanto may charge royalties on Bt cotton in India.
<G-vec00272-001-s220><charge.erheben><de> Bis der oberste Gerichtshofs von Delhi über die Gültigkeit des Patents entscheidet, kann Monsanto in Indien Lizenzgebühren für Bt-Baumwolle erheben.
<G-vec00272-001-s221><charge.erheben><en> We charge a flat weekly rate, don’t limit the number of users or amount of data and you can reach a real human in case you’re going to need help.
<G-vec00272-001-s221><charge.erheben><de> Wir erheben einen flachen Wochenpreis, nicht die Anzahl der Benutzer oder Datenmenge begrenzen, und Sie können ein echter Mensch in Fall erreichen Sie Hilfe brauchen.
<G-vec00272-001-s222><charge.erheben><en> Online shops may no longer charge a little extra if you pay by credit card.
<G-vec00272-001-s222><charge.erheben><de> Beispielsweise kann ein Online-Shop keinen kleinen Aufpreis erheben, wenn Sie mit der Kreditkarte bezahlen möchten.
<G-vec00272-001-s223><charge.erheben><en> Plarium may also provide links to other websites or third party services, some of which may charge separate fees, which are not included in any fees that you may pay to Plarium.
<G-vec00272-001-s223><charge.erheben><de> Des Weiteren kann Plarium Links zu anderen Webseiten oder Drittparteidienstleistungen anbieten, von denen einige separate Gebühren erheben, welche nicht in den von Ihnen an Plarium gezahlten Gebühren inbegriffen sind.
<G-vec00272-001-s224><charge.erheben><en> For payments by cash on delivery, we charge an additional processing fee of EUR 5.00 in Germany, together with the transfer fee of Deutsche Post AG, which you must pay the postman.
<G-vec00272-001-s224><charge.erheben><de> Für Zahlungen per Nachnahme erheben wir im Inland eine zusätzliche Bearbeitungsgebühr von EUR 5.00, nebst Übermittlungsentgeld der Deutschen Post AG, die Sie beim Postboten bezahlen müssen.
<G-vec00272-001-s225><charge.erheben><en> Even in hotel reservations, we always charge a performance-based commission only, which additionally is comparable, if not even below, the market standard.
<G-vec00272-001-s225><charge.erheben><de> Auch in der Hotelvermittlung erheben wir immer nur eine leistungsbezogene Kommission, die darüber hinaus vergleichbar mit dem, wenn nicht gar unter dem Marktstandard liegt.
<G-vec00272-001-s226><charge.erheben><en> Also similarly, some casinos may charge a withdrawal fee.
<G-vec00272-001-s226><charge.erheben><de> Einige Casinos erheben auch eine Auszahlungsgebühr.
<G-vec00272-001-s227><charge.erheben><en> In the case of placing claims that are unfounded or excessive, we reserve the right to charge a reasonable fee or refuse to act upon the request, which we will notify you in advance.
<G-vec00272-001-s227><charge.erheben><de> Im Falle von offensichtlich unbegründeten oder übertriebenen Anträgen, behalten wir das Recht ein berechtigtes Entgelt zu erheben oder abzulehnen nach dem Antrag zu handeln, worüber wir Sie in voraus benachrichtigen werden.
<G-vec00272-001-s456><charge.stellen><en> Should you decide not to make a reservation after receiving the offers, we reserve the right to charge an administrative fee of CHF 50.00.
<G-vec00272-001-s456><charge.stellen><de> Bei einer Absage nach der Zustellung von Offerten erlauben wir uns, Ihnen eine Bearbeitungsgebühr von CHF 50.00 in Rechnung zu stellen.
<G-vec00272-001-s457><charge.stellen><en> If a device provided for the purpose of bridging a repair period is returned in an improper condition, KARL STORZ reserves the right to charge up to 30% of the new value for the restoration of the device.
<G-vec00272-001-s457><charge.stellen><de> Sollte ein Reparaturüberbrückungsgerät in einem nicht ordnungsgemäßen Zustand retourniert werden, behält sich KARL STORZ vor, bis zu 30% des Neuwarenwertes für die Instandsetzung des Gerätes in Rechnung zu stellen.
<G-vec00272-001-s458><charge.stellen><en> If you, as the trainer, have to cancel or curtail the seminar because you unexpectedly indisposed, the service provider can charge you the costs of booked seminar rooms and seminar equipment, of accommodation and board, in accordance with its conditions of business.
<G-vec00272-001-s458><charge.stellen><de> Wenn Sie als Trainer das Seminar absagen oder abbrechen müssen, weil Sie unerwartet ausfallen, kann Ihnen der Leistungsträger Stornokosten für gebuchte Seminarräume und Seminarausstattung, für Übernachtungen und Verpflegung entsprechend seiner Geschäftsbedingungen in Rechnung stellen.
<G-vec00272-001-s459><charge.stellen><en> In the event of late clearing of the room, ACHAT may charge 50% of the regular room rate (list price) until 6 pm for the additional use of the room, from 6 pm onwards 100% of the full valid regular room rate (list price).
<G-vec00272-001-s459><charge.stellen><de> Bei verspäteter Räumung kann das Hotel über den ihm dadurch entstehenden Schaden hinaus für die zusätzliche Nutzung des Zimmers bis 18.00 Uhr 50 % des regulären Übernachtungspreises (Listenpreises) in Rechnung stellen, ab 18.00 Uhr 100% des vollen gültigen regulären Übernachtungspreis (Listenpreis).
<G-vec00272-001-s460><charge.stellen><en> If you damage the rented equipment in such a way that we can no longer rent it out, we will have to charge you the current value.
<G-vec00272-001-s460><charge.stellen><de> Sollten Sie die gemietete Ausrüstung so beschädigen, dass wir diese nicht mehr weiter vermieten können, müssen wir Ihnen den Zeitwert in Rechnung stellen.
<G-vec00272-001-s461><charge.stellen><en> You accept that TomTom may charge you for any shipping or postage costs incurred directly associated with returning the Product.
<G-vec00272-001-s461><charge.stellen><de> Sie akzeptieren, dass TomTom Ihnen Versand- oder Portokosten, die direkt mit der Rücksendung des Produkts in Verbindung stehen, in Rechnung stellen kann.
<G-vec00272-001-s462><charge.stellen><en> If the customer returns one or more of these multiple goods, the Supplier will be entitled to withdraw the discount and nevertheless charge the amount corresponding to this to the customer.
<G-vec00272-001-s462><charge.stellen><de> Sendet der Kunde von diesen mehreren Artikeln einen oder mehrere zurück, dann ist der Lieferant berechtigt, die Ermäßigung zurückzuziehen und den sich daraus ergebenden Betrag dem Kunden nachträglich in Rechnung zu stellen.
<G-vec00272-001-s463><charge.stellen><en> TIP: The fees we charge you (regardless of whether you choose to absorb or pass the fees to your attendees) are considered to be a separate transaction from the price you charge your attendees.
<G-vec00272-001-s463><charge.stellen><de> TIPP: Unabhängig davon, ob Sie die Gebühren in den Ticketpreis einrechnen oder an die Teilnehmer übertragen, gelten die anfallenden Gebühren als eigenständige Transaktion, die von dem Preis, den Sie Teilnehmern in Rechnung stellen, unabhängig ist.
<G-vec00272-001-s464><charge.stellen><en> If the delivery mistake is due to the Buyer, this cannot not imply any financial disadvantage for P.P.S, and P.P.S reserves itself the right to charge the client the costs of his/her mistake.
<G-vec00272-001-s464><charge.stellen><de> Handelt es sich um einen Fehler des Käufers, dürfen P.P.S daraus keine finanziellen Nachteile entstehen, und P.P.S behält sich das Recht vor, den Kunden die durch den Fehler des Käufers entstandenen Kosten in Rechnung zu stellen.
<G-vec00272-001-s465><charge.stellen><en> CrazyBulk also supplies complimentary worldwide shipping that lots of other supplement business generally charge.
<G-vec00272-001-s465><charge.stellen><de> CrazyBulk liefert auch kostenlosen weltweiten Versand, die viele anderen Ergänzung Geschäft im Allgemeinen Rechnung zu stellen .
<G-vec00272-001-s466><charge.stellen><en> However, as reported, the firm wrote on its website that it has “no plans to change” its business model and will not charge fees for any of its services.
<G-vec00272-001-s466><charge.stellen><de> jedoch, wie berichtet, Die Firma schrieb auf seiner Website, dass es hat “keine Pläne zu ändern” ihr Geschäftsmodell und wird nicht Gebühren für eine ihrer Dienstleistungen in Rechnung stellen.
<G-vec00272-001-s467><charge.stellen><en> If a grace period notification for a rectification of defects is not reasonable for the purchaser due to time reasons, the purchaser has the right to have the defects repaired and to charge the required expenses after having informed the supplier.
<G-vec00272-001-s467><charge.stellen><de> Sollte eine Nachfristsetzung für eine Nachbesserung aus terminlichen Gründen für den Besteller nicht zumutbar sein, behält sich dieser nach vorheriger Information des Lieferanten das Recht vor, selbst nachbessern zu lassen und die hierfür erforderlichen Aufwendungen in Rechnung zu stellen.
<G-vec00272-001-s468><charge.stellen><en> They can only charge fees for their legal services which are 10 per cent less than those which lawyers who have law offices in Berlin or the old Länder can charge their clients.
<G-vec00272-001-s468><charge.stellen><de> Sie können für ihre Berufstätigkeit als Rechtsanwalt nur Gebühren verlangen, die um zehn Prozent niedriger sind als diejenigen, die Rechtsanwälte mit Kanzleisitz in Berlin und den alten Bundesländern ihren Mandanten in Rechnung stellen dürfen.
<G-vec00272-001-s469><charge.stellen><en> You expressly grant Shutterstock the right to charge you for each automatic renewal until you timely disable automatic renewal.
<G-vec00272-001-s469><charge.stellen><de> Sie gewähren Shutterstock ausdrücklich das Recht, Ihnen jede automatische Verlängerung in Rechnung zu stellen, bis Sie die automatische Verlängerung rechtzeitig deaktivieren.
<G-vec00272-001-s470><charge.stellen><en> There is no fee charged for requesting access to your personal information, however we may charge you for the reasonable cost of processing your request.
<G-vec00272-001-s470><charge.stellen><de> Für den Zugang zu Ihren persönlichen Daten werden keine Gebühren erhoben, es kann jedoch sein, dass wir Ihnen in angemessenem Umfang die Bearbeitung Ihrer Anfrage in Rechnung stellen.
<G-vec00272-001-s471><charge.stellen><en> He must not charge a fee directly related to the outcome of the services he provides.
<G-vec00272-001-s471><charge.stellen><de> Es soll keine Honorare in Rechnung stellen, die unmittelbar vom Ergebnis der von ihm besorgten Dienste abhängen.
<G-vec00272-001-s472><charge.stellen><en> In the case of late arrivals or early departures, we do charge for the room.
<G-vec00272-001-s472><charge.stellen><de> Bei verspäteter Anreise oder verfrühter Abreise erlauben wir uns das Zimmer in Rechnung zu stellen.
<G-vec00272-001-s473><charge.stellen><en> With such device you can charge your digital products any time and any where.
<G-vec00272-001-s473><charge.stellen><de> Mit einem solchen Gerät können Sie Ihre digitalen Produkte jederzeit und überall, wo in Rechnung stellen.
<G-vec00272-001-s474><charge.stellen><en> If the alternative accommodation unit price is higher than the accommodation unit reserved by the client, the Agency is entitled to charge the client for the price difference.
<G-vec00272-001-s474><charge.stellen><de> Falls der Preis der alternativen Unterkunft höher ist als der der stornierten Unterkunft, behält sich die Agentur das Recht vor, diese Differenz in Rechnung zu stellen.
<G-vec00272-001-s589><charge.verlangen><en> Other competitors charge very high fees for similar reports.
<G-vec00272-001-s589><charge.verlangen><de> Andere Anbieter verlangen für vergleichbare Reports hohe Gebühren.
<G-vec00272-001-s590><charge.verlangen><en> a) In case of an increase attributable to a single seat Velociped can charge the amount of increase.
<G-vec00272-001-s590><charge.verlangen><de> a) Bei einer auf den Sitzplatz bezogenen Erhöhung kann Velociped vom Kunden den Erhöhungsbetrag verlangen.
<G-vec00272-001-s591><charge.verlangen><en> These organizations will charge higher fees, because they offer preparation services and added support.
<G-vec00272-001-s591><charge.verlangen><de> Diese Organisationen werden höheren Gebühren verlangen, weil sie Zubereitungsleistungen und zusätzliche Unterstützung bieten.
<G-vec00272-001-s592><charge.verlangen><en> You just have to bring the best, not to charge more than what you deliver, but to know the price of your service in order to keep the quality.
<G-vec00272-001-s592><charge.verlangen><de> Sie müssen nur das Beste zu liefern, nicht mehr verlangen als das, was Sie zu liefern, aber der Preis für Ihren Service zu kennen, um die Qualität zu halten.
<G-vec00272-001-s593><charge.verlangen><en> Business partners and visitors of our webpages have at any time the right to inquire about the origins, kind of storage and the extent of use of his or her personal data free of charge.
<G-vec00272-001-s593><charge.verlangen><de> Kunden, Kooperationspartner und Seitenbesucher haben jederzeit das Recht, kostenlos Auskunft über die Herkunft ihrer personenbezogenen Daten zu verlangen sowie über Art und Umfang der Speicherung und Nutzung dieser Daten.
<G-vec00272-001-s594><charge.verlangen><en> An expert can charge more when the time is right.
<G-vec00272-001-s594><charge.verlangen><de> Ein Experte kann mehr verlangen wenn die Zeit reif ist.
<G-vec00272-001-s595><charge.verlangen><en> Some may charge placement fees of 2,000-6,000 CZK for finding a regular sitter; other agencies charge no fee.
<G-vec00272-001-s595><charge.verlangen><de> Einige können Vermittlungsgebühren von 2,000-6,000 CZK für die Suche nach einem regelmäßigen Babysitter kostenlos; andere Agenturen verlangen keine Gebühr.
<G-vec00272-001-s596><charge.verlangen><en> If you request the direct transfer of the data to another person in charge, this will only take place if it is technically feasible.
<G-vec00272-001-s596><charge.verlangen><de> Sofern Sie die direkte Übertragung der Daten an einen anderen Verantwortlichen verlangen, erfolgt dies nur, soweit es technisch machbar ist.
<G-vec00272-001-s597><charge.verlangen><en> Avoid suppliers that charge an ongoing monthly fee to do business with them.
<G-vec00272-001-s597><charge.verlangen><de> Vermeiden Sie Anbieter, die verlangen eine laufende monatliche Gebühr mit Ihnen Geschäfte machen.
<G-vec00272-001-s598><charge.verlangen><en> On the other hand, private companies will normally charge more but offer door to door transfers for fixed prices.
<G-vec00272-001-s598><charge.verlangen><de> Auf der anderen Seite werden private Unternehmen in der Regel mehr verlangen, bieten aber Haus-zu-Haus-Transfers zu Festpreisen an.
<G-vec00272-001-s599><charge.verlangen><en> Gohlke, his co-authors, and his publisher are of course free to charge whatever they wish for their book.
<G-vec00272-001-s599><charge.verlangen><de> Gohlke, seine Mitautoren und sein Verleger können natürlich für ihr Buch verlangen, was sie wollen.
<G-vec00272-001-s600><charge.verlangen><en> We will therefore charge premium margin to ensure that sufficient account value is available to close the short position and additional margin to cover overnight shifts in the underlying value.
<G-vec00272-001-s600><charge.verlangen><de> Wir werden daher eine Premium Margin verlangen, um sicherzustellen, dass genügend Mittel zur Glattstellung der Short-Position vorhanden sind, und eine zusätzliche Margin, sich gegen Preisverschiebungen des Basiswerts über Nacht abzusichern.
<G-vec00272-001-s601><charge.verlangen><en> The accommodation provider shall be entitled to charge as a minimum the remuneration corresponding to the price usually charged in the low season.
<G-vec00272-001-s601><charge.verlangen><de> Der Beherberger ist berechtigt, mindestens jenes Entgelt zu verlangen, das dem gewöhnlich verrechneten Preis in der Nebensaison entspricht.
<G-vec00272-001-s602><charge.verlangen><en> Except for one special situation, the GNU General Public License (GNU GPL) has no requirements about how much you can charge for distributing a copy of free software.
<G-vec00272-001-s602><charge.verlangen><de> Mit Ausnahme einer bestimmten Situation beinhaltet die GNU General Public License (GPL) keinerlei Bedingungen darüber, wie viel man für den Vertrieb von Freie-Software-Kopien verlangen kann.
<G-vec00272-001-s603><charge.verlangen><en> (3) Where permissible under the relevant national law, a company may charge a fee for supplying the relevant information.
<G-vec00272-001-s603><charge.verlangen><de> (3) Die Unternehmen können für die Auskunftserteilung eine Gebühr verlangen, wenn und soweit dies nach Maßgabe des jeweiligen Landesrechts zulässig ist.
<G-vec00272-001-s604><charge.verlangen><en> Brennan could easily charge for something like this and people would still buy it.
<G-vec00272-001-s604><charge.verlangen><de> Brennan könnte glatt Geld dafür verlangen und die Leute würden den Kurs trotzdem kaufen.
<G-vec00272-001-s605><charge.verlangen><en> In the event of default in payment, the Company is entitled to charge interest on arrears in the amount of 10 percentage points above the base interest rate (§ 247 German Civil Code (BGB)).
<G-vec00272-001-s605><charge.verlangen><de> Im Falle des Zahlungsverzuges ist die Firma berechtigt, Verzugszinsen in Höhe von 10 Prozentpunkten über dem Basiszinssatz (§ 247 BGB) zu verlangen.
<G-vec00272-001-s606><charge.verlangen><en> They can only charge fees for their legal services which are 10 per cent less than those which lawyers who have law offices in Berlin or the old Länder can charge their clients.
<G-vec00272-001-s606><charge.verlangen><de> Sie können für ihre Berufstätigkeit als Rechtsanwalt nur Gebühren verlangen, die um zehn Prozent niedriger sind als diejenigen, die Rechtsanwälte mit Kanzleisitz in Berlin und den alten Bundesländern ihren Mandanten in Rechnung stellen dürfen.
<G-vec00272-001-s607><charge.verlangen><en> If you don’t charge admission, the licence fees are lower.
<G-vec00272-001-s607><charge.verlangen><de> Wenn Sie keinen Eintritt verlangen, kostet Sie die Urheberrechtsentschädigung weniger.
<G-vec00230-002-s095><charge.aufladen><en> The new application allows you to monitor the battery level of your smartphone by indicating when to put the device on to charge in good time to prevent it from shutting down automatically.
<G-vec00230-002-s095><charge.aufladen><de> Diese neue App ermöglicht das Überwachen des Ladestands des eigenen Smartphones und zeigt an, wann es nötig ist, das Gerät rechtzeitig wieder aufzuladen, um die automatische Abschaltung zu verhindern.
<G-vec00230-002-s096><charge.aufladen><en> Micro USB: Connect to an AC adapter to charge the battery.
<G-vec00230-002-s096><charge.aufladen><de> Mikro-USB: Schließen Sie an einen Wechselstrom-Adapter an, um die Batterie aufzuladen.
<G-vec00230-002-s097><charge.aufladen><en> • Avoid using your device while it's charging to help it charge faster.
<G-vec00230-002-s097><charge.aufladen><de> • Vermeiden Sie eine Verwendung des Geräts während des Ladevorgangs, um es schneller aufzuladen.
<G-vec00230-002-s098><charge.aufladen><en> To charge the battery, simply open the zipper on the side of the pillow to connect the charger cable to the USB port in the pillow.
<G-vec00230-002-s098><charge.aufladen><de> Um den Akku aufzuladen, öffnen Sie einfach den Reißverschluss seitlich am Kissen, um das Kabel des Ladegerätes an die USB-Buchse im Kissen anzuschließen.
<G-vec00230-002-s099><charge.aufladen><en> With this technology you do not need a charging cable anymore to charge your mobile device.
<G-vec00230-002-s099><charge.aufladen><de> Dank der Qi-Technologie brauchen Sie kein Ladekabel, um Ihr mobiles Gerät aufzuladen.
<G-vec00230-002-s100><charge.aufladen><en> Utilising innovative pass-through technology, this charging dock allows you to connect your Galaxy S8 to the cradle via a USB-C connection and use a USB port on a computer or laptop to charge your device as well as synchronise your data.
<G-vec00230-002-s100><charge.aufladen><de> Diese Ladestation ermöglicht es Ihnen, Ihr Galaxy Note 8 über einen USB-C-Anschluss an die Ladestation anzuschließen und über einen USB-Anschluss an einem Computer oder Laptop Ihr Gerät aufzuladen sowie Ihre Daten zu synchronisieren.
<G-vec00230-002-s101><charge.aufladen><en> 10,000 mAh is a much chosen capacity because it is sufficient to charge a smartphone several times.
<G-vec00230-002-s101><charge.aufladen><de> 10.000 mAh sind eine häufig gewählte Kapazität, da dies ausreicht, um ein Smartphone mehrmals aufzuladen.
<G-vec00230-002-s102><charge.aufladen><en> 50 Place the handset on the base to charge for at least 24 hours.
<G-vec00230-002-s102><charge.aufladen><de> WANDSTECKDOSE mindestens 24 Stunden in die Basisstation, um den Akku vollständig aufzuladen.
<G-vec00230-002-s103><charge.aufladen><en> San Martino di Castrozza, Passo Rolle, Primiero and Vanoi have chosen to reward you, offering the possibility to charge your car for free...
<G-vec00230-002-s103><charge.aufladen><de> San Martino di Castrozza, Passo Rolle, Primiero und Vanoi geben Ihnen die Möglichkeit, Ihr Auto kostenlos aufzuladen.
<G-vec00230-002-s104><charge.aufladen><en> It provides up to 32 hours of battery life and allows you to charge via power bank while recording. TrainingPeaks Workout
<G-vec00230-002-s104><charge.aufladen><de> Mit einer Akkulaufzeit von bis zu 32 Stunden und der Möglichkeit während der Aufzeichnung per Powerbank aufzuladen bietet er genug Laufzeit sogar fü die längsten Ausfahrten.
<G-vec00230-002-s105><charge.aufladen><en> Also designed with Qi Inductive Charging capabilities, the speaker allows you to simply place your Qi compatible device on the speaker system for a wireless charge.
<G-vec00230-002-s105><charge.aufladen><de> Zudem verfügt der Lautsprecher über den Qi-Standard zum induktiven Laden, sodass Sie Ihr Qi-kompatibles Gerät nur auf den Lautsprecher zu legen brauchen, um es kabellos aufzuladen.
<G-vec00230-002-s106><charge.aufladen><en> Support fast charging, quick to charge your phone.
<G-vec00230-002-s106><charge.aufladen><de> Unterstützen Sie schnelles Aufladen, schnell, um Ihr Telefon aufzuladen.
<G-vec00230-002-s107><charge.aufladen><en> It is recommended to charge the battery with the standard number of Ah as shown in the Battery Data.
<G-vec00230-002-s107><charge.aufladen><de> Wir empfehlen die Batterie mit der Standardanzahl von Ah (in den Batterie-Daten zu finden) aufzuladen.
<G-vec00230-002-s108><charge.aufladen><en> This quality cable allows you to connect your Sony Xperia XZ2 to your laptop or desktop, in order to charge your phone and exchange / sync data simultaneously.
<G-vec00230-002-s108><charge.aufladen><de> Mit diesem Qualitätskabel können Sie Ihr Oppo RX17 Pro an Ihren Laptop oder Desktop anschließen, um Ihr Telefon aufzuladen und gleichzeitig Daten auszutauschen / zu synchronisieren.
<G-vec00230-002-s109><charge.aufladen><en> External USB Business Laptop Bag interface with built - in charging cable:easy for you to charge your cell phone, tablet and other devices without opening up the backpack.
<G-vec00230-002-s109><charge.aufladen><de> Externe USB- Business-Laptop-Tasche Schnittstelle mit integriertem Ladekabel: einfach für Sie, um Ihr Handy, Tablet und andere Geräte aufzuladen, ohne den Rucksack zu öffnen.
<G-vec00230-002-s110><charge.aufladen><en> Researchers have found a way to naturally "super charge" coffee and dramatically increase its healthy polyphenol content.12 This means people can obtain more of coffee's unique beneficial compounds while drinking less coffee.
<G-vec00230-002-s110><charge.aufladen><de> Forscher haben einen Weg gefunden, Kaffee natürlich "aufzuladen" und seinen gesunden Polyphenolgehalt bedeutend zu erhöhen.12 Dies bedeutet, dass Menschen mehr von den einzigartigen vorteilhaften Verbindungen des Kaffees erhalten können, während sie weniger Kaffee trinken.
<G-vec00230-002-s111><charge.aufladen><en> Only 45 minutes of charging via USB dock is enough to fully charge the product.
<G-vec00230-002-s111><charge.aufladen><de> Nur 45 Minuten Aufladen über die USB - Ladestation reichen aus um das Produkt vollständig aufzuladen.
<G-vec00230-002-s112><charge.aufladen><en> Connect the dock to your computer with the USB cable included with your iPad to sync iPad and charge its battery.
<G-vec00230-002-s112><charge.aufladen><de> Schließe das Dock über das im Lieferumfang des iPad enthaltene USB-Kabel an deinen Computer an, um das iPad zu synchronisieren und seinen Akku aufzuladen.
<G-vec00230-002-s113><charge.aufladen><en> The car cigarette powered dual USB adapter is very useful and convenient to charge your devices in the car.
<G-vec00230-002-s113><charge.aufladen><de> Die Auto-Zigarette powered Dual-USB-Adapter ist sehr nützlich und bequem, um Ihre Geräte im Auto aufzuladen.
<G-vec00230-002-s114><charge.belasten><en> In order to guarantee your reservation we require a valid credit card number and we charge your credit card at the time of your booking.
<G-vec00230-002-s114><charge.belasten><de> Um Ihnen Ihre Reservierung garantieren zu können, benötigen wir eine gültige Kreditkartennummer, die wir zum Zeitpunkt Ihrer Buchung belasten.
<G-vec00230-002-s115><charge.belasten><en> Please note that the hotel reserves the right to charge the credit card received upon check in if it receives notification of a credit card charge back.
<G-vec00230-002-s115><charge.belasten><de> Bitte beachten Sie, dass das Hotel sich das Recht vorbehält, die beim Check-in erhaltene Kreditkarte zu belasten, wenn es eine Mitteilung über eine Kreditkartenrückbuchung erhält.
<G-vec00230-002-s116><charge.belasten><en> We reserve the right and you hereby authorise us to charge your credit or debit card for any damage incurred to your room or the Hotel during your stay (including without limitation specialist cleaning) or for any items that are missing when you leave.
<G-vec00230-002-s116><charge.belasten><de> Wir behalten uns das Recht vor und erhalten hiermit Ihre Genehmigung, Ihre Kredit- oder Debitkarte in Bezug auf jeglichen Schäden an Ihrem Zimmer oder dem Hotel während Ihres Aufenthalts (insbesondere Spezialreinigung) oder Artikel, die nach Ihrer Abreise fehlen, zu belasten.
<G-vec00230-002-s117><charge.belasten><en> 3.5 If down-payment and/or residual payment are not done punctually, AC can withdraw from the contract following a reminder setting a period for payment and charge the client the costs of withdrawal pursuant to Section 7.
<G-vec00230-002-s117><charge.belasten><de> 3.5 Erfolgen Anzahlung und/oder Restzahlung nicht fristgemäß, kann AC nach Mahnung mit Fristsetzung vom Vertrag zurücktreten und den Kunden mit Rücktrittskosten nach Ziffer 7. belasten.
<G-vec00230-002-s118><charge.belasten><en> If within this period the customer does not file a damage notification, the accident can not be handled by the insurance company and emmy reserves the right to charge all accidental costs to the customer.
<G-vec00230-002-s118><charge.belasten><de> Geht innerhalb dieser Frist keine Schadensmeldung bei emmy ein, so kann der Unfall nicht von der Versicherung bearbeitet werden und emmy behält sich vor, alle unfallbedingten Kosten dem Kunden zu belasten.
<G-vec00230-002-s120><charge.belasten><en> Charges for Taxes and Service Fees: In connection with facilitating your hotel transaction, we will charge your method of payment for Taxes and Fees.
<G-vec00230-002-s120><charge.belasten><de> Belastungen für Steuern und Servicegebühren: Im Zusammenhang mit der Durchführung Ihrer Hotel-Buchung belasten wir Sie mittels der von Ihnen gewählten Zahlungsmethode mit Steuern und Gebühren.
<G-vec00230-002-s121><charge.belasten><en> If you do not have enough balance in your e-wallet, you can request Click and Buy to immediately charge you on your credit card or on your bank account.
<G-vec00230-002-s121><charge.belasten><de> Wenn Sie nicht genug Balance in Ihrer E-Brieftasche haben, kann man Click and Buy bitten, Sie auf der Kreditkarte oder auf dem Bankkonto sofort zu belasten.
<G-vec00230-002-s122><charge.belasten><en> If we fail to charge your credit card (or any other associated payment method) for the next billing cycle of the subscription, we'll inform you about this via email.
<G-vec00230-002-s122><charge.belasten><de> Wenn wir Deine Kreditkarte oder Deine ausgewählte Bezahlmethode nicht für die kommende Spielperiode belasten können, dann informieren wir Dich umgehend darüber via E-Mail.
<G-vec00230-002-s123><charge.belasten><en> 19.2 You may not transfer, assign, charge or otherwise dispose of the Contract, or any of your rights or obligations arising under it, without our prior written consent.
<G-vec00230-002-s123><charge.belasten><de> Sie sind nicht berechtigt, ohne unsere vorherige schriftliche Zustimmung einen Vertrag oder irgendwelche Ihrer Rechte oder Pflichten im Rahmen eines solchen Vertrages zu übertragen, abzutreten, zu belasten oder anderweitig darüber zu verfügen.
<G-vec00230-002-s124><charge.belasten><en> If the customer does not settle the payment of the travel price within the period agreed upon, the tour operator has the right to withdraw from the travel contract provided he has issued a warning in which a withdrawal deadline has been specified and to charge the customer withdrawal fees according to paragraph 5.
<G-vec00230-002-s124><charge.belasten><de> Leistet der Kunde den Reisepreis nicht entsprechend den vereinbarten Zahlungsfälligkeiten, so ist der Reiseveranstalter berechtigt, nach Mahnung mit Fristsetzung vom Reisevertrag zurückzutreten und den Kunden mit Rücktrittskosten gemäß Ziffer 5 belasten.
<G-vec00230-002-s125><charge.belasten><en> I'm used to identify from an early age, things to myself and no one else to charge them.
<G-vec00230-002-s125><charge.belasten><de> Ich bin es von klein auf gewohnt die Dinge mit mir selbst auszumachen und niemanden anders damit zu belasten.
<G-vec00230-002-s126><charge.belasten><en> VAT can be a charge on a business's finances if regulations are not adhered to.
<G-vec00230-002-s126><charge.belasten><de> UnternehmensinformaDie Umsatzsteuer kann das Finanzwesen eines Unternehmens belasten, wenn Regelungen und Verpflichtungen nicht eingehalten werden.
<G-vec00230-002-s127><charge.belasten><en> 2.2 If the Customer or the Traveler fails to pay the remaining payment in accordance with the agreed payment terms, the Tour Operator shall be entitled to withdraw from the travel contract after a reminder with a deadline, and to charge the Customer / Travelers with cancellation costs in accordance with section 4.2 sentence 2 to section 4.4.
<G-vec00230-002-s127><charge.belasten><de> 2.2 Leistet der Kunde die Anzahlung und/oder die Restzahlung nicht entsprechend den vereinbarten Zahlungsfälligkeiten, so ist der Reiseveranstalter berechtigt, nach Mahnung mit Fristsetzung vom Reisevertrag zurückzutreten und den Kunden mit Rücktrittskosten gemäß Ziffer 4.2 Satz 2 bis 4.4 zu belasten.
<G-vec00230-002-s128><charge.belasten><en> In case we have not received the down and / or final payment within the indicated periods, we have the right to withdraw from the travel contract after sending a reminder with a given deadline and to charge cancellation fees according to our terms & conditions.
<G-vec00230-002-s128><charge.belasten><de> Liegen Anzahlung und/oder Restzahlung nicht entsprechend den vereinbarten Fälligkeiten vor, so sind wir berechtigt, nach Mahnung mit Fristsetzung vom Reisevertrag zurückzutreten und Sie mit den Rücktrittskosten laut unseren Reisebedingungen zu belasten.
<G-vec00230-002-s129><charge.belasten><en> Any such charges will give j2 Global the right to immediately terminate or suspend your eReceptionist Account without notice and you further understand and agree that j2 Global can immediately charge your credit card or other payment method you use to pay for the Services for these products or services.
<G-vec00230-002-s129><charge.belasten><de> Jegliche derartigen Gebühren geben j2 Global das Recht, Ihr eReceptionist-Konto ohne vorherige Benachrichtigung sofort zu kündigen oder zu sperren, und Sie verstehen und stimmen zu, dass j2 Global Ihre Kreditkarte oder eine andere Zahlungsmethode, die Sie zur Bezahlung der Dienste für diese Produkte oder Dienstleistungen verwenden, sofort belasten kann.
<G-vec00230-002-s130><charge.belasten><en> We will not charge you any reservation fees for making this booking, nor charge your credit card.
<G-vec00230-002-s130><charge.belasten><de> Wir berechnen weder Reservierungsgebuehren, noch belasten wir Ihre Kreditkarte.
<G-vec00230-002-s131><charge.belasten><en> If TI Traben-Trarbach is willing and able to provide the contractual services and the traveller fails to pay the deposit or balance or fails to do so in full on the agreed dates despite having no contractual or statutory right to withhold payment, then, after issuing a warning which specifies a period within which payment must be made, TI Traben-Trarbach shall be entitled to cancel the contract and to charge the traveller cancellation costs in accordance with clause 4 of these terms and conditions.
<G-vec00230-002-s131><charge.belasten><de> Soweit kein vertragliches oder gesetzliches Rücktrittsrecht des Kunden besteht und die TI-TT zur Erbringung der vertraglichen Leistungen bereit und in der Lage ist, gilt: a) Leistet der Reisegast Anzahlung oder Restzahlung bei Vorliegen der Fälligkeitsvoraussetzungen nicht oder nicht vollständig zu den vereinbarten Terminen, so ist die TI-TT berechtigt, nach Mahnung mit Fristsetzung vom Vertrag zurückzutreten und den Reisegast mit Rücktrittskosten gemäß Ziff.4 dieser Bedingungen zu belasten.
<G-vec00230-002-s132><charge.belasten><en> We do not charge your card until after your order has been sent out to you.
<G-vec00230-002-s132><charge.belasten><de> Wir belasten Ihre Karte erst dann, wenn die Ware an Sie versandt wurde.
<G-vec00230-002-s152><charge.berechnen><en> Cathay Pacific does not charge any booking fees or card fees for making an offer.
<G-vec00230-002-s152><charge.berechnen><de> Cathay Pacific berechnet für die Abgabe eines Angebots keine Buchungs- oder Kartengebühren.
<G-vec00230-002-s153><charge.berechnen><en> Please note that if guests check-in with extra person not mentioned on the original booking, the additional charge will be applied.
<G-vec00230-002-s153><charge.berechnen><de> Gästerichtlinien Bitte beachten Sie, dass für Gäste, die nicht auf der ursprünglichen Buchungsbestätigung aufgeführt sind, beim Check-in eine Zusatzgebühr berechnet wird.
<G-vec00230-002-s154><charge.berechnen><en> Our partner bank, FinTech Group Bank AG, may charge fees for additional account services and account inactivity.
<G-vec00230-002-s154><charge.berechnen><de> Unsere Partnerbank, die FinTech Group Bank AG, berechnet für zusätzliche Kontodienstleistungen und Inaktivität möglicherweise Gebühren.
<G-vec00230-002-s155><charge.berechnen><en> TUI Villas will only charge a commission when you have confirmed a booking.
<G-vec00230-002-s155><charge.berechnen><de> Erst wenn Sie eine Buchung bestätigt haben, berechnet TUI Villas eine Vermittlungsprovision.
<G-vec00230-002-s156><charge.berechnen><en> Please note that there is a 1.4% charge when you pay with a Visa or MasterCard credit card and a 3.3% charge when you pay with an American Express credit card.
<G-vec00230-002-s156><charge.berechnen><de> Bitte beachten Sie, dass bei Zahlungen mit Kreditkarten von Visa oder Mastercard eine Gebühr von 1,4 % und bei Zahlungen mit Kreditkarten von American Express eine Gebühr von 3,3 % berechnet wird.
<G-vec00230-002-s157><charge.berechnen><en> Every year or at the end of a contract period, the linen lease company/laundry firm will do a settlement and charge you for the napkins that you have not returned.
<G-vec00230-002-s157><charge.berechnen><de> Jedes Jahr am Ende einer Vertragslaufzeit berechnet Ihre Miet-/Reinigungsfirma Ihnen einen Betrag für den natürlichen Schwund an Servietten.
<G-vec00230-002-s158><charge.berechnen><en> The platform does not charge a transaction fee and will solicit you to tip a free amount.
<G-vec00230-002-s158><charge.berechnen><de> Die Plattform berechnet keine Transaktionsgebühr und bittet Sie, einen freien Betrag zu kippen.
<G-vec00230-002-s159><charge.berechnen><en> If you send or receive an international personal payment using your PayPal balance or bank account, PayPal will charge a cross border fee, which can range from 0.5% to 2% of the payment amount.
<G-vec00230-002-s159><charge.berechnen><de> Wenn Sie eine internationale persönliche Zahlung mithilfe Ihres PayPal-Guthabens oder Bankkontos überweisen oder empfangen, berechnet PayPal eine Auslandsgebühr, die zwischen 0,5 % und 2 % des Zahlungsbetrags betragen kann.
<G-vec00230-002-s160><charge.berechnen><en> For children from 12-16 years we charge € 40 per nights including breakfast.
<G-vec00230-002-s160><charge.berechnen><de> Für jedes Kind von 12 Jahren bis 16 Jahren werden pro Übernachtung € 40,00 inklusive Frühstück berechnet.
<G-vec00230-002-s161><charge.berechnen><en> For each additional minute we charge 1 Euro.
<G-vec00230-002-s161><charge.berechnen><de> Jede weitere Minute wird mit 1,00 Euro berechnet.
<G-vec00230-002-s162><charge.berechnen><en> 4.We will charge the buyer cost price of spare parts beyond 2 years and provide long-term technical guide.
<G-vec00230-002-s162><charge.berechnen><de> 4.We berechnet den Käuferselbstkostenpreis von Ersatzteilen über 2 Jahren hinaus und liefert langfristigen technischen Führer.
<G-vec00230-002-s163><charge.berechnen><en> In the case of private locations we always accompany the first inspection and charge it by hours.
<G-vec00230-002-s163><charge.berechnen><de> Im Falle von Privatlocations ist Johannes Adler bei der Erstbesichtigung immer anwesend und berechnet diese stundenweise.
<G-vec00230-002-s164><charge.berechnen><en> An extra charge is applicable in this case.
<G-vec00230-002-s164><charge.berechnen><de> In diesem Fall wird eine Zusatzgebühr berechnet.
<G-vec00230-002-s165><charge.berechnen><en> Reeltastic Casino does not charge a fee for processing withdrawals.
<G-vec00230-002-s165><charge.berechnen><de> Reeltastic Casino berechnet keine Gebühren für Auszahlungen.
<G-vec00230-002-s166><charge.berechnen><en> For two adults and two children in the high season we charge 295 Euro – all other rates are in between.
<G-vec00230-002-s166><charge.berechnen><de> Für zwei Erwachsene und zwei Kinder in der Hauptsaison werden 295 Euro berechnet – alle anderen Tarife liegen dazwischen.
<G-vec00230-002-s167><charge.berechnen><en> If you cancel your reservation after this time or you do not show up at the property on the day of arrival, the property will charge 30.00% of the booking value.
<G-vec00230-002-s167><charge.berechnen><de> Wenn Sie Ihre Reservierung nach dieser Zeit stornieren oder am Anreisetag nicht in der Unterkunft erscheinen, berechnet die Unterkunft 30,00% des Buchungswerts.
<G-vec00230-002-s168><charge.berechnen><en> If you cancel your reservation after this time or you do not show up at the property on the day of arrival, the guest will charge 50.00% of the booking value.
<G-vec00230-002-s168><charge.berechnen><de> Wenn Sie Ihre Reservierung nach dieser Zeit stornieren oder am Anreisetag nicht in der Unterkunft erscheinen, berechnet der Gast 50% des Buchungswertes.
<G-vec00230-002-s169><charge.berechnen><en> Electricity is charge of 6 Baht kWp, water is 60 Baht per m³.
<G-vec00230-002-s169><charge.berechnen><de> Strom wird bei 6 Baht pro kw, Wasser bei 60 Baht pro m³ berechnet.
<G-vec00230-002-s170><charge.berechnen><en> If Germania bears the costs of the packaging on the basis of a contractual arrangement, the supplier shall charge Germania for these costs at cost price.
<G-vec00230-002-s170><charge.berechnen><de> Sofern Germania aufgrund der vertraglichen Vereinbarung die Kosten der Verpackung trägt, berechnet der Lieferant Germania diese Kosten zum Selbstkostenpreis.
<G-vec00230-002-s190><charge.erheben><en> We reserve the right to charge a penalty fee of 3,00 € per day for late returns.
<G-vec00230-002-s190><charge.erheben><de> Wir behalten uns vor, bei verspäteter Rückgabe einen Säumniszuschlag von 3,00 € pro Tag zu erheben.
<G-vec00230-002-s191><charge.erheben><en> The SME status will be checked by ECHA and, if wrongly claimed, an additional administrative charge will be levied.
<G-vec00230-002-s191><charge.erheben><de> Die ECHA wird den KMU-Status überprüfen und eine zusätzliche Verwaltungsgebühr erheben, wenn dieser fälschlicherweise geltend gemacht wurde.
<G-vec00230-002-s192><charge.erheben><en> In the case of storage (from two days before and after the event), the HOTEL is entitled to charge a fee for the storage costs incurred based on the size and number of items.
<G-vec00230-002-s192><charge.erheben><de> Im Falle einer Einlagerung (ab 2 Tage vor und nach einer Veranstaltung) behält sich das HOTEL vor, für die entstanden Lagerkosten eine Gebühr in Abhängigkeit von Größe und Menge der Artikel zu erheben.
<G-vec00230-002-s193><charge.erheben><en> We do not charge any reservation and cancellation fees.
<G-vec00230-002-s193><charge.erheben><de> Reservierungs- und Stornogebühren erheben wir nicht.
<G-vec00230-002-s194><charge.erheben><en> 4 The Agency and the cantons may, free of charge, take samples, request essential information and documents, and ask for any help necessary for this purpose.
<G-vec00230-002-s194><charge.erheben><de> 4 Das Institut und die anderen mit dem Vollzug dieses Gesetzes betrauten Behörden können die dazu notwendigen Muster erheben, die erforderlichen Auskünfte oder Unterlagen verlangen und jede andere erforderliche Unterstützung anfordern.
<G-vec00230-002-s195><charge.erheben><en> Importantly, make sure you understand the different payment methods, as some may charge transaction fees.
<G-vec00230-002-s195><charge.erheben><de> Wichtig ist, dass du die verschiedenen Zahlungsmethoden verstehst, da einige von ihnen Transaktionsgebühren erheben können.
<G-vec00230-002-s196><charge.erheben><en> In this case, the course will not be exclusively for you, but we do not charge an extra one-on-one fee.
<G-vec00230-002-s196><charge.erheben><de> In diesem Fall ist die Schulung natürlich nicht exklusiv für Sie, aber wir erheben auch keinen Einzelschulungsaufpreis.
<G-vec00230-002-s197><charge.erheben><en> Also, a broker may charge a transaction fee for deposits and withdrawals.
<G-vec00230-002-s197><charge.erheben><de> Ein Broker kann auch eine Transaktionsgebühr für Ein- und Auszahlungen erheben.
<G-vec00230-002-s199><charge.erheben><en> Contractors (Publisher) we charge a fee.
<G-vec00230-002-s199><charge.erheben><de> Von Auftragnehmern(Publisher) erheben wir eine Gebühr.
<G-vec00230-002-s200><charge.erheben><en> NEW: Student jobs and internship ads are generally free of charge. Universities, academic institutions, companies are able to publish their job offers or programs for 150 Dollar (100 Euro) per item.
<G-vec00230-002-s200><charge.erheben><de> Für die Veröffentlichung von Studentenjobs und Praktika erheben wir eine einmalige Schutzgebühr von 50,00 Euro, danach sind diese generell kostenfrei.
<G-vec00230-002-s201><charge.erheben><en> Water tariff reforms implemented in the early 1990s to charge the "full price of water" in Denmark and the Czech Republic preceded reductions in water consumption.
<G-vec00230-002-s201><charge.erheben><de> Auch die Wassertarifreformen, welche in den frühen 1990er Jahren in Dänemark und der Tschechischen Republik eingeführt wurden, um den "vollen Preis des Wassers" zu erheben, führten zu Wassereinsparungen.
<G-vec00230-002-s202><charge.erheben><en> In order for us to be able to ship goods on a cost-covering basis, we now have to charge shipping costs.
<G-vec00230-002-s202><charge.erheben><de> Damit wir kostendeckend Ware versenden können, müssen wir nun Versandkosten erheben.
<G-vec00230-002-s203><charge.erheben><en> The entrepreneur running the dismantling station may charge a fee for accepting a part of passenger cars that are waste, while according to art.
<G-vec00230-002-s203><charge.erheben><de> Der Unternehmer, der die Demontagestation betreibt, kann eine Gebühr für die Annahme eines Teils der Pkw erheben, bei denen es sich um Abfälle handelt.
<G-vec00230-002-s204><charge.erheben><en> In case of a second reminder, TeamViewer shall be entitled to charge a reasonable dunning fee.
<G-vec00230-002-s204><charge.erheben><de> Im Falle einer zweiten Mahnung ist TeamViewer berechtigt eine angemessene Mahngebühr zu erheben.
<G-vec00230-002-s206><charge.erheben><en> We may change any fees that we charge for WeChat (or any parts of WeChat) at any time upon publication within WeChat.
<G-vec00230-002-s206><charge.erheben><de> Wir können die Gebühren, die wir für unsere Dienstleistungen (oder andere Teile von WeChat) erheben, jederzeit nach Veröffentlichung innerhalb von WeChat ändern.
<G-vec00230-002-s207><charge.erheben><en> The lessee shall indemnify the lessor from all fines and custodial fees, fees, surcharges and other costs that the authorities charge the lessor for such breaches.
<G-vec00230-002-s207><charge.erheben><de> Die Mieterin stellt die Vermieterin von sämtlichen Buß- und Verwarnungsgeldern, Gebühren, Zuschlägen und sonstigen Kosten frei, die Behörden anlässlich solcher Verstöße von der Vermieterin erheben.
<G-vec00230-002-s208><charge.erheben><en> For orders from Austria, Switzerland and England, we charge a shipping fee of 3.60 EUR.
<G-vec00230-002-s208><charge.erheben><de> Bei Bestellungen aus den Ländern Österreich, Schweiz und England erheben wir eine Versandkostenpauschale in Höhe von 3.60 EUR.
<G-vec00230-002-s228><charge.gebühren><en> Regular improvements and statutory compliance updates at no charge to the client, who is always provided with the latest and best version available.
<G-vec00230-002-s228><charge.gebühren><de> Für regelmäßige Verbesserungen und Compliance-Updates fallen keine Gebühren für die Kunden an, sie erhalten stets die aktuellste und beste Version.
<G-vec00230-002-s229><charge.gebühren><en> You can select one or more countries (70+ countries available) for premium audio at no charge.
<G-vec00230-002-s229><charge.gebühren><de> Sie können ein oder mehrere Länder (70+ Länder verfügbar) für Premium-Audio ohne Gebühren auswählen.
<G-vec00230-002-s230><charge.gebühren><en> Invalidation requests No additional charge for the first 1,000 paths requested for invalidation each month.
<G-vec00230-002-s230><charge.gebühren><de> Auf die ersten 1 000 Pfade in der Aufhebungsanforderung in jedem Monat entfallen keine zusätzlichen Gebühren.
<G-vec00230-002-s231><charge.gebühren><en> Prices include: Accommodation, bed linen, towels, household linen (bathmat + dish towel), cleaning kit, end-of-stay cleaning (excepted dishes and kitchen corner), basic WiFi access (up to 5 devices to navigate the web, read emails and search), charge and tax (except tourism tax and application fee).
<G-vec00230-002-s231><charge.gebühren><de> Die Preise beinhalten: Unterkunft, Bettwäsche, Handtücher, Haushaltswäsche (Badematte + Geschirrtuch), Reinigungsset, Endreinigungsgebühr (ausgenommen Geschirr und Küchenbereich), Basic WLAN (maximal 5 Geräte zum Lesen von E-Mails und Recherchieren), Gebühren und Steuern (außer Tourismusabgabe und Bearbeitungsgebühren).
<G-vec00230-002-s232><charge.gebühren><en> There are no hidden costs, no charge for appraisals, photos or online listings.
<G-vec00230-002-s232><charge.gebühren><de> Es gibt keine versteckten Kosten, keine Gebühren für Schätzungen, Fotos oder Online-Listungen.
<G-vec00230-002-s233><charge.gebühren><en> 1. De Requested supervisory authorities shall not charge a fee for any action taken by them pursuant to a request for mutual assistance.
<G-vec00230-002-s233><charge.gebühren><de> (7) Ersuchte Aufsichtsbehörden verlangen für Maßnahmen, die sie aufgrund eines Amtshilfeersuchens getroffen haben, keine Gebühren.
<G-vec00230-002-s234><charge.gebühren><en> Select Windows 7 systems (excluding POS 7 systems) are preinstalled with Windows 7 and come with a license for Windows 10 at no additional charge.
<G-vec00230-002-s234><charge.gebühren><de> Bestimmte Windows 7-Systeme (POS 7 nicht mit inbegriffen) sind vorinstalliert mit Windows 7 und haben auch eine Windows 10 Lizenz ohne zusätzliche Gebühren.
<G-vec00230-002-s235><charge.gebühren><en> Groups will be exempt from any charge if cancelations amounting to more than 10% of the booking up to the entire booking are made at least 61 days prior to arrival.
<G-vec00230-002-s235><charge.gebühren><de> - Gruppen werden von jeglichen Gebühren befreit, wenn Stornierungen von mehr als 10 % der Buchung bis zur gesamten Buchung mindestens 41 Tage vor der Ankunft erfolgen.
<G-vec00230-002-s236><charge.gebühren><en> There is also a minibar and a direct dial telephone for an extra charge.
<G-vec00230-002-s236><charge.gebühren><de> Gegen zusätzliche Gebühren gibt es auch eine Minibar und ein Direktwahltelefon.
<G-vec00230-002-s237><charge.gebühren><en> There's no charge if the issue is covered under warranty, AppleCare Protection Plan, or consumer law.
<G-vec00230-002-s237><charge.gebühren><de> Wenn das Problem von der Garantie, einem AppleCare-Vertrag oder den Verbraucherschutzgesetzen abgedeckt ist, fallen keine Gebühren an.
<G-vec00230-002-s238><charge.gebühren><en> Amazon Neptune database instances outside VPC: For data transferred between an Amazon EC2 instance and Amazon Neptune database instance in different Availability Zones of the same Region, there is no Data Transfer charge for traffic in or out of the Amazon Neptune database instance.
<G-vec00230-002-s238><charge.gebühren><de> Amazon Neptune-Datenbank-Instances außerhalb der VPC: Für Datenübertragungen zwischen einer Amazon EC2-Instance und einer Amazon Neptune-Datenbank-Instance in verschiedenen Availability Zones derselben Region fallen keine Gebühren für den ein- oder ausgehenden Datenverkehr für die Amazon Neptune-Datenbank-Instance an.
<G-vec00230-002-s239><charge.gebühren><en> By providing Microsoft with a payment method, you (i) represent that you are authorised to use the payment method that you provided and that any payment information you provide is true and accurate; (ii) authorise Microsoft to charge you for the services using your payment method; and (iii) authorise Microsoft to charge you for any paid feature of the services that you choose to sign up for or use while this agreement is in force.
<G-vec00230-002-s239><charge.gebühren><de> Indem Sie Microsoft eine Zahlungsmethode bereitstellen, (i) sichern Sie zu, dass Sie autorisiert sind, die von Ihnen bereitgestellte Zahlungsmethode zu verwenden, und dass alle von Ihnen bereitgestellten Zahlungsinformationen wahr und richtig sind; (ii) autorisieren Sie Microsoft, Ihnen die Gebühren für die Dienste unter Verwendung Ihrer Zahlungsmethode in Rechnung zu stellen; und (iii) autorisieren Sie Microsoft, Ihnen die Gebühren für alle kostenpflichtigen Features der Dienste in Rechnung zu stellen, für die Sie sich angemeldet haben oder die Sie verwenden, während dieser Vertrag Gültigkeit hat.
<G-vec00230-002-s240><charge.gebühren><en> No additional charge on top of the booking price is billed to the guest.
<G-vec00230-002-s240><charge.gebühren><de> Dem Gast werden, abgesehen vom Buchungsbetrag, keine zusätzliche Gebühren belastet.
<G-vec00230-002-s241><charge.gebühren><en> Unlike other SEO companies, who charge fixed fees for their campaign work regardless of whether they're producing results or not, we only charge after achieving concrete improvements of the search terms you want to be found under.
<G-vec00230-002-s241><charge.gebühren><de> Im Gegensatz zu anderen Unternehmen, die eine Suchmaschinenoptimierung (SEO) anbieten und unabhängig von erzielten Ergebnissen feste Gebühren für ihre Arbeit erheben, erheben wir nur dann Gebühren, wenn wir eine nachweisbare Verbesserung der mit den von Ihnen gewünschten Suchbegriffen erzielten Trefferliste erreicht haben.
<G-vec00230-002-s242><charge.gebühren><en> The charge for the most popular destinations is predetermined.
<G-vec00230-002-s242><charge.gebühren><de> Die Gebühren für die beliebtesten Reiseziele sind festgelegt.
<G-vec00230-002-s243><charge.gebühren><en> Tips: It is normal if there is slight difference in charge than the one listed at check out.
<G-vec00230-002-s243><charge.gebühren><de> Tipps: Es ist normal, dass die Gebühren geringfügig von den beim Auschecken angegebenen abweichen.
<G-vec00230-002-s244><charge.gebühren><en> No matter if quick 5 holes or rather a whole round of golf, the chipping green or the driving range - it's all included - there is no extra charge for you.
<G-vec00230-002-s244><charge.gebühren><de> Ob schnelle 5 Löcher oder doch die ganze Runde, das Chipping Grün oder die Drivingrange > Alles Inklusive > Es fallen keine extra Gebühren mehr für Sie an.
<G-vec00230-002-s245><charge.gebühren><en> Crypto Engine does not charge anything whatsoever to access its powerful trading software.
<G-vec00230-002-s245><charge.gebühren><de> Crypto Engine erhebt keinerlei Gebühren für den Zugriff auf seine leistungsstarke Handelssoftware.
<G-vec00230-002-s246><charge.gebühren><en> Fares do not include ground transport service between airports, and between airports and town terminals unless provided by Carrier without additional charge.
<G-vec00230-002-s246><charge.gebühren><de> Flugpreise beinhalten keine Bodenbeförderungsdienstleistungen zwischen Flughäfen und zwischen Flughäfen und Stadtterminals, sofern diese nicht von der Fluggesellschaft ohne zusätzliche Gebühren erbracht werden.
<G-vec00230-002-s323><charge.kosten><en> This is for the recycling of the water and is paid yearly at the town hall or through your bank, it is a small charge of 15 €
<G-vec00230-002-s323><charge.kosten><de> Basura bedeutet Abfall und diese Kosten sind für die Sammlung und die Beseitigung Ihres Abfalls, jährlich bei dem örtlichen Gemeindeamt / Rathaus zu bezahlen.
<G-vec00230-002-s324><charge.kosten><en> Parking Private parking for extra charge is possible on site (reservation is needed).
<G-vec00230-002-s324><charge.kosten><de> Fitness-Private Parkplätze stehen für extra Kosten am Hotel (Reservierung ist erforderlich).
<G-vec00230-002-s325><charge.kosten><en> The ECC (Elliptic Curve Cryptography) algorithm, a new encryption method that offers faster and more secure connections, is available at no extra charge and is suitable for mobile devices (smartphones, tablets…). Contact us to find out more.
<G-vec00230-002-s325><charge.kosten><de> Der ECC (Elliptic Curve Cryptography) algorithm), eine Verschlüsselungsmethode, die schnellere und sicherere Verbindungen bietet, steht ohne zusätzliche Kosten zur Verfügung und eignet sich für Mobilgeräte (smartphones, tablets…).Kontaktieren Sie uns für weitere Informationen.
<G-vec00230-002-s326><charge.kosten><en> Mac OS and Apple hardware self-paced training for recertification is provided online without additional charge via our service provider portal, Global Service Exchange.
<G-vec00230-002-s326><charge.kosten><de> Eine im selbstbestimmten Tempo durchzuführende Schulung bezüglich Mac OS- und Apple-Hardware für die Rezertifizierung steht online ohne zusätzliche Kosten über unser Service-Provider-Portal Global Service Exchange zur Verfügung.
<G-vec00230-002-s327><charge.kosten><en> Attend the specialized lecture programme in the open Forum:Energietechnik, which is tailored to your interests and held directly in the exhibition area, free of charge.
<G-vec00230-002-s327><charge.kosten><de> Dazu dient ein thematisch maßgeschneidertes Fachprogramm im Forum: Energietechnik, das Ihnen ohne zusätzliche Kosten direkt in der Messehalle angeboten wird.
<G-vec00230-002-s328><charge.kosten><en> The benefits of studying English Courses includes small class sizes, experienced & supportive teachers and the ability to take part in additional conversational English at no extra charge.
<G-vec00230-002-s328><charge.kosten><de> Die Vorteile unserer Englischkurse sind kleine Unterrichtsgruppen, erfahrene und kooperative Lehrer und die Möglichkeit an zusätzlichen Englisch-Konversationen ohne weitere Kosten teilnehmen zu können.
<G-vec00230-002-s329><charge.kosten><en> If customers don't improve their storage capacity on competitive storage systems by at least 35% with NetApp V-Series and deduplication (and after following established best practices implemented by NetApp Professional Services), NetApp will provide the additional storage capacity needed to meet customers' shortfall, valued up to 35% of the original controller purchased, at no additional charge*.
<G-vec00230-002-s329><charge.kosten><de> Sollten Kunden die Kapazität ihrer Storage-Systeme von Mitbewerbern mithilfe von NetApp V-Serie und Deduplizierung sowie unter Einhaltung der von den NetApp Professional Services vorgeschriebenen Best Practices nicht um mindestens 35% verbessern, stellt NetApp die darüber hinaus gehende Kapazität in einem Umfang von bis zu 35% der ursprünglich erworbenen Kapazität ohne weitere Kosten* bereit.
<G-vec00230-002-s330><charge.kosten><en> Charge for proofreading varies from language to language (Panorama only uses experienced native proof readers).
<G-vec00230-002-s330><charge.kosten><de> Die Kosten für die Kontrolle der Richtigkeit differieren nach Sprache (Panorama arbeitet nur mit erfahrenen Muttersprachlern zusammen).
<G-vec00230-002-s331><charge.kosten><en> AWS Management Portal for vCenter is available at no additional charge. Customers will be charged for AWS services consumed using the portal.
<G-vec00230-002-s331><charge.kosten><de> Das AWS Management Portal for vCenter steht ohne zusätzliche Kosten zur Verfügung.Kunden werden AWS-Services in Rechnung gestellt, die über das Portal genutzt werden.
<G-vec00230-002-s332><charge.kosten><en> The customer then has the right to cancel the order free of charge and has right to a potential damage claim.
<G-vec00230-002-s332><charge.kosten><de> Der Verbraucher hat in diesem Fall das Recht, den Vertrag ohne Kosten zu aufzulösen und hat gegebenenfalls Anspruch auf Schadenersatz.
<G-vec00230-002-s333><charge.kosten><en> Color label needs additional charge, production can not print logo at small quantity .
<G-vec00230-002-s333><charge.kosten><de> Farbetikett benötigt zusätzliche Kosten, Produktion kann nicht Logo in kleinen Mengen drucken.
<G-vec00230-002-s334><charge.kosten><en> As a member of Over 50s Dating, your profile will automatically be shown on related mature dating sites or to related users in the Online Connections network at no additional charge.
<G-vec00230-002-s334><charge.kosten><de> Als Mitglied von Transsexuelle Kontakt wird dein Profil automatisch auf verwandten transsexual Datingseiten oder für relevante Mitglieder im Infinite Connections Netzwerk ohne zusätzliche Kosten sichtbar gemacht.
<G-vec00230-002-s335><charge.kosten><en> BoonHost.com reserves the right to charge the holder of the account used to send any unsolicited e-mail a cleanup fee or any charges incurred for blacklist removal at our sole discretion.
<G-vec00230-002-s335><charge.kosten><de> VIVANET behält sich vor, von dem Benutzer eines Kontos, das für den Versand von unerwünschten E-Mails verwendet wurde, eine Bereinigungsgebühr zu verrechnen, um die Kosten der Entfernung aus einer schwarzen Liste erstattet zu bekommen.
<G-vec00230-002-s336><charge.kosten><en> There is no extra charge or application for this service.
<G-vec00230-002-s336><charge.kosten><de> Es gibt keine zusätzlichen Kosten oder Anforderungen für diesen Service.
<G-vec00230-002-s337><charge.kosten><en> The Client shall provide all materials and operating supplies and carry out all actions free of charge that are required for regulating the repaired object and for executing tests.
<G-vec00230-002-s337><charge.kosten><de> Vom Auftraggeber sind auf seine Kosten alle Materialien und Betriebsstoffe bereitzustellen und alle sonstigen Handlungen vorzunehmen, die zur Einregulierung des Reparaturgegenstandes und zur Durchführung der Erprobung notwendig sind.
<G-vec00230-002-s338><charge.kosten><en> Very plain, clean,lamanite wood floor,charge for ice.
<G-vec00230-002-s338><charge.kosten><de> Sehr einfach, sauber, lamanite Holzboden, Kosten für Eis.
<G-vec00230-002-s339><charge.kosten><en> The amount of the charge can be found in the rental information of the respective FLIZZR country.
<G-vec00230-002-s339><charge.kosten><de> Die Höhe der Kosten findest Du in den Anmietinformationen des jeweiligen FLIZZR-Landes.
<G-vec00230-002-s340><charge.kosten><en> There is no additional charge for transporting your pet but it must be placed in your pet transporting box.
<G-vec00230-002-s340><charge.kosten><de> Nein, es treten keine zusätzlichen Kosten an, aber die Tiere müssen in ihrer Reise Box sein.
<G-vec00230-002-s341><charge.kosten><en> Children are welcome and childcare will be provided at no extra charge. Children's activities will be included as part of the workshop and participants will have the opportunity to try out co-leading a new mindfulness based exercise learned in the workshop.
<G-vec00230-002-s341><charge.kosten><de> Kinder sind an diesem Wochenende willkommen und werden ohne zusätzliche Kosten betreut – Aktivitäten mit ihnen sind Bestandteil des Workshops und Teilnehmer/innen werden die Möglichkeit haben, erlernte Achtsamkeitsübungen direkt anzuwenden.
<G-vec00230-002-s418><charge.laden><en> The user-friendly USB Type-C port allows you to charge your USB Type-C devices more easily.
<G-vec00230-002-s418><charge.laden><de> Mit dem benutzerfreundlichen USB-Typ-C-Anschluss können Sie Ihre USB-Typ-C-Geräte einfacher laden.
<G-vec00230-002-s419><charge.laden><en> How to Charge the Fujitsu LifeBook S7020 Series battery?
<G-vec00230-002-s419><charge.laden><de> Laden Sie Fujitsu LifeBook E8020 Batterie vor dem Aufbewahren auf.
<G-vec00230-002-s420><charge.laden><en> Charge the headset overnight or for at least 8 hours before first use.
<G-vec00230-002-s420><charge.laden><de> Laden Sie das Headset vor der ersten Verwendung über Nacht oder mindestens 8 Stunden auf.
<G-vec00230-002-s421><charge.laden><en> The hybrid system in the transporters is set for a fully electric range of more than 50 km, using a 1.0 litre gas engine as a range extender to charge the liquid cooled 14 kWh battery.
<G-vec00230-002-s421><charge.laden><de> Das Hybrid-System des Transporters ist auf eine rein elektrische Reichweite von mehr als 50 Kilometern ausgelegt und nutzt als Range Extender einen 1,0-Liter-Benziner zum Laden des flüssigkeitsgekühlten 14 kWh-Akkus.
<G-vec00230-002-s422><charge.laden><en> USB charger to charge spare batteries without the device.
<G-vec00230-002-s422><charge.laden><de> Ladegerät zum Laden von Ersatzakkus außerhalb des Geräts.
<G-vec00230-002-s423><charge.laden><en> Leitz Complete Multicharger XL for 1 tablet and 3 smartphones Charge your tablet, smartphones, and other devices simultaneously.
<G-vec00230-002-s423><charge.laden><de> Mit 4 USB Ladestation XL für 1 Tablet und 3 Smartphones Laden Sie gleichzeitig Ihr Tablet PC, Smartphone und andere Geräte.
<G-vec00230-002-s424><charge.laden><en> Charge the battery immediately.
<G-vec00230-002-s424><charge.laden><de> Laden Sie den Bereich sofort wieder auf.
<G-vec00230-002-s425><charge.laden><en> With this option, you can charge the battery at a charging station or wallbox from 10 to 80% in less than 45 minutes.
<G-vec00230-002-s425><charge.laden><de> Damit laden Sie die Batterie an der Ladesäule oder Wallbox in unter 40 MinutenDie Werte variieren in Abhängigkeit der gewählten Sonderausstattungen.
<G-vec00230-002-s426><charge.laden><en> Charge your Huawei P9 and any other USB device quickly and conveniently with this compatible 2.4A high power USB-C EU charging kit.
<G-vec00230-002-s426><charge.laden><de> Laden Sie Ihr Huawei Honor 8 oder anderes USB Gerät mit dem Olixar High Power 2.4A EU Ladeadapter und USB-C Kabel in einem Set.
<G-vec00230-002-s427><charge.laden><en> Be sure to charge the battery as it is not charged at the time of purchase.
<G-vec00230-002-s427><charge.laden><de> Laden Sie den Akku auf, da er zum Zeitpunkt des Erwerbs nicht geladen ist.
<G-vec00230-002-s428><charge.laden><en> Charge the battery only up to a maximum of 4.2V per cell, this also corresponds to the cut-off voltage of common chargers.
<G-vec00230-002-s428><charge.laden><de> Laden sie den Akku immer nur bis maximal 4,2V pro Zelle, dies entspricht auch der Abschaltspannung der gängigen Ladegeräte.
<G-vec00230-002-s429><charge.laden><en> Leading-edge connectivity: The Thunderbolt™ 3 multi-use Type-C™ ports allow you to charge your laptop, connect to multiple devices (including support for up to two 4K displays) and enjoy data transfers up to 40Gbps—8 times that of a USB 3.0*.
<G-vec00230-002-s429><charge.laden><de> Modernste Konnektivität: Die vielfach nutzbaren ThunderBolt™ 3 Typ-C-Anschlüsse erlauben Ihnen, Ihr Notebook zu laden, an mehrere Geräte anzuschließen (einschließlich Unterstützung für bis zu zwei 4-K-Displays) und sich über Datenübertragungen mit bis zu 40 Gbit/s zu freuen – achtmal schneller als USB 3.0*.
<G-vec00230-002-s430><charge.laden><en> Please charge the console in a place where the temperature is between 5 and 35°C.
<G-vec00230-002-s430><charge.laden><de> Bitte laden Sie die Konsole an einem Ort auf, an dem die Umgebungstemperatur zwischen 5 °C und 35 °C beträgt.
<G-vec00230-002-s431><charge.laden><en> With this DYX-0009 1-to-5 Multiple Ports Charge Cable for JJRC/DFD, you are able to charge 5 independent batteries at the same time.
<G-vec00230-002-s431><charge.laden><de> Mit diesem Ladekabel DYX-0009-1-5-mehrere Ports für JJRC/DFD können Sie 5 unabhängige Batterien gleichzeitig laden.
<G-vec00230-002-s432><charge.laden><en> Charge or sync your Micro-B USB devices with the cable out of the way
<G-vec00230-002-s432><charge.laden><de> Laden oder synchronisieren Sie Ihre Micro USB-Geräte mit diesem hochwertigen weißen USB 2.0-Ersatzkabel.
<G-vec00230-002-s433><charge.laden><en> Utilising innovative pass-through technology, this charging dock allows you to connect your Google Pixel smartphone to the cradle via a USB connection and simultaneously use the computer port to charge your phone as well as synchronise your data simultaneously.
<G-vec00230-002-s433><charge.laden><de> Produktbeschreibung Laden und synchronisieren Sie Ihr Gerät Nutzen Sie innovative Pass-Through-Technologie, die ermöglicht diese Ladestation für Ihr OnePlus 3T / 3 Smartphone über einen USB-Anschluss anzuschließen und gleichzeitig zu laden sowie Ihre Daten gleichzeitig zu synchronisieren.
<G-vec00230-002-s434><charge.laden><en> You can use your iPhone 5C/5/5S, charge it, sync or put it on a "dock" without removing it from the case.
<G-vec00230-002-s434><charge.laden><de> Sie können Ihr iPhone 6 Plus /6S Plus 5.5" nutzen, laden, synchronisieren oder auf ein ""Dock"" legen, ohne es seinem Lederetui entnehmen zu müssen.
<G-vec00230-002-s435><charge.laden><en> Want to charge your Renault Z.E. at home?
<G-vec00230-002-s435><charge.laden><de> Es gibt viele Lösungen zum Laden Ihres Renault Z.E.
<G-vec00230-002-s436><charge.laden><en> Although it is still not possible to charge an electric car with a flash, engineers are already one step closer to the vision of lightning-fast charging.
<G-vec00230-002-s436><charge.laden><de> Zwar lässt sich ein Elektroauto auch heute noch nicht mit einem Blitz laden, doch sind die Ingenieure der Vision des blitzschnellen Aufladens bereits einen Schritt näher gekommen.
<G-vec00230-002-s494><charge.nutzen><en> WiFi is available in all areas free of charge.
<G-vec00230-002-s494><charge.nutzen><de> WLAN können Sie in allen Bereichen kostenlos nutzen.
<G-vec00230-002-s495><charge.nutzen><en> As charging technology currently has a huge influence on how effortlessly and conveniently drivers can charge their electric vehicles as part of their daily routine, Continental is presenting global innovations for this area of electromobility for the first time.
<G-vec00230-002-s495><charge.nutzen><de> Da gerade die Ladetechnik großen Einfluss darauf hat, wie mühelos und komfortabel ein Fahrer ein Elektrofahrzeug im Alltag nutzen kann, zeigt Continental weltweit erstmals auch für diesen Teil der Elektromobilität Innovationen.
<G-vec00230-002-s496><charge.nutzen><en> The Directory of Open Access Journals (DOAJ) lists specialist journals that have been published online in full under the principles of open access and can be accessed free of charge.
<G-vec00230-002-s496><charge.nutzen><de> Im Directory of Open Access Journals (DOAJ) finden Sie Fachzeitschriften, deren Volltexte Sie nach den Prinzipien des Open Access im Internet kostenfrei nutzen können.
<G-vec00230-002-s497><charge.nutzen><en> Guests can enjoy the onsite facilities include an all-year round swimming pool, a fitness centre and sauna, all free of charge.
<G-vec00230-002-s497><charge.nutzen><de> Zu den Annehmlichkeiten der Unterkunft gehören ein ganzjährig geöffneter Pool, ein Fitnesscenter und eine Sauna, die Sie alle kostenfrei nutzen können.
<G-vec00230-002-s498><charge.nutzen><en> Passengers in Business Class and Premium Class can use our extensive Premium Entertainment programme at no extra charge.
<G-vec00230-002-s498><charge.nutzen><de> Gäste der Business Class sowie Premium Class können unser umfangreiches Premium Entertainment Angebot ohne Aufpreis nutzen.
<G-vec00230-002-s499><charge.nutzen><en> On request and upon availability, a covered private car park is available free of charge.
<G-vec00230-002-s499><charge.nutzen><de> Auf Anfrage und je nach Verfügbarkeit können Sie überdachte Privatparkplätze kostenfrei nutzen.
<G-vec00230-002-s500><charge.nutzen><en> As well as being able to access the fine sandy beach free of charge, guests can also choose to spend a relaxing day outside beside the outdoor pools.
<G-vec00230-002-s500><charge.nutzen><de> Neben der Möglichkeit, kostenlos den feinsandigen Strand zu nutzen, können unsere Gäste einen Entspannungstag in unseren Außen-Pool verbringen.
<G-vec00230-002-s501><charge.nutzen><en> You can try the full, unlimited version of PRTG for 30 days free of charge.
<G-vec00230-002-s501><charge.nutzen><de> Sie können PRTG die ersten 30 Tage kostenlos und unbegrenzt nutzen.
<G-vec00230-002-s502><charge.nutzen><en> You are welcome to download our informative product sheets free of charge and without obligation.
<G-vec00230-002-s502><charge.nutzen><de> Nutzen Sie die Möglichkeit, sich kostenlos und unverbindlich unsere Produktblätter herunterzuladen.
<G-vec00230-002-s503><charge.nutzen><en> All guests are allowed touse a washing machine and a rowing boat free of charge.
<G-vec00230-002-s503><charge.nutzen><de> Alle Gäste können eine Waschmaschine und ein Ruderboot kostenlos nutzen.
<G-vec00230-002-s504><charge.nutzen><en> During the 2021 WARSAW YACHT SHOWROOM, each exhibitor and buyer will be able to take advantage of the possibility of individual, dedicated meetings with potential foreign partners free of charge.
<G-vec00230-002-s504><charge.nutzen><de> Während des WARSAW YACHT SHOWROOM 2021 kann jeder Aussteller und Käufer kostenlose, individuelle und engagierte Treffen mit potenziellen ausländischen Partnern nutzen.
<G-vec00230-002-s505><charge.nutzen><en> Whether it’s a meeting in the city, a trip around town or lunch at your favourite restaurant, you can charge your car at a variety of public charging pedestals.
<G-vec00230-002-s505><charge.nutzen><de> Ob Meeting, Stadtbummel oder Mittagessen in der Stadt: Während Sie Ihre Zeit für Ihren Alltag nutzen, können Sie an vielen öffentlichen Ladesäulen Ihr Fahrzeug laden.
<G-vec00230-002-s506><charge.nutzen><en> The areas marked with "P" in the following overview plan can be used free of charge during your stay.
<G-vec00230-002-s506><charge.nutzen><de> Die mit "P" gekennzeichnetetn Flächen in diesem Übersichtsplan können Sie während Ihres Aufenthalts jederzeit gratis nutzen.
<G-vec00230-002-s507><charge.nutzen><en> Interlaken’s vibrant center can be reached in just a few minutes by boat or regular bus - both of which are free of charge with your guest card.
<G-vec00230-002-s507><charge.nutzen><de> Per Kursschiff oder Linienbus - beides können Sie mit Ihrer Gästekarte gratis nutzen - erreichen Sie das lebhafte Zentrum Interlakens in wenigen Minuten.
<G-vec00230-002-s508><charge.nutzen><en> This property features a garden with an outdoor pool and spacious spa facilities, available for an extra charge.
<G-vec00230-002-s508><charge.nutzen><de> Freuen Sie sich in dieser Unterkunft auf einen Garten mit Außenpool und geräumige Spa-Einrichtungen, die Sie gegen einen Aufpreis nutzen.
<G-vec00230-002-s509><charge.nutzen><en> Wi-Fi is available in all areas of the hotel for a small daily charge.
<G-vec00230-002-s509><charge.nutzen><de> Gegen eine geringe Tagesgebühr nutzen Sie das WLAN in allen Bereichen des Hotels.
<G-vec00230-002-s510><charge.nutzen><en> Even during the winter, you can take part in one of the guided snowshoeing and rent the snowshoes free of charge.
<G-vec00230-002-s510><charge.nutzen><de> Auch im Winter können Sie an einer der geführten Schneeschuhwanderungen teilnehmen und Schneeschuhe nutzen.
<G-vec00230-002-s511><charge.nutzen><en> Guests staying a minimum of 5 nights can use the windmill hot tub for 1 hour free of charge.
<G-vec00230-002-s511><charge.nutzen><de> Bei einem Mindestaufenthalt von 5 Nächten können Sie den Windmühlen-Whirlpool 1 Stunde lang kostenfrei nutzen.
<G-vec00230-002-s512><charge.nutzen><en> As a hotel guest you can use the swimming pool free of charge.
<G-vec00230-002-s512><charge.nutzen><de> Unsere Gäste können das Schwimmbad, die Parkplätze und die unbegrenzte WiFi-Netzwerk kostenlos nutzen.
<G-vec00230-002-s627><charge.verlangen><en> If this would be a commercial website, I had to charge much more.
<G-vec00230-002-s627><charge.verlangen><de> Wenn diese Seite auf Kommerz aus wäre, dann müsste ich viel mehr verlangen.
<G-vec00230-002-s628><charge.verlangen><en> You have the right to require us to correct any inaccuracies in your data free of charge.
<G-vec00230-002-s628><charge.verlangen><de> Sie haben das Recht, von uns die Korrektur aller Unrichtigkeiten in Ihren Daten zu verlangen.
<G-vec00230-002-s629><charge.verlangen><en> Many payment service providers charge monthly fees for using their services.
<G-vec00230-002-s629><charge.verlangen><de> Viele Payment Service Provider verlangen monatliche Gebühren für die Nutzung ihrer Dienstleistung.
<G-vec00230-002-s630><charge.verlangen><en> Instead, whenever someone buys a ticket to your New Year's party, we charge a small booking fee.
<G-vec00230-002-s630><charge.verlangen><de> Wir verlangen stattdessen eine kleine Bearbeitungsgebühr von allen, die ein Ticket für Deine Silvesterparty kaufen.
<G-vec00230-002-s631><charge.verlangen><en> To prevent fraud we charge a small fee of €0.50 to change your payment method.
<G-vec00230-002-s631><charge.verlangen><de> Um Betrug zu verhindern, verlangen wir für die Änderung einen kleinen Betrag von 0.50€.
<G-vec00230-002-s632><charge.verlangen><en> Where you request additional copies, the controller is entitled to charge an appropriate fee based on administrative costs.
<G-vec00230-002-s632><charge.verlangen><de> Für alle weiteren Kopien, die Sie beantragen, kann der Verantwortliche ein angemessenes Entgelt auf der Grundlage der Verwaltungskosten verlangen.
<G-vec00230-002-s633><charge.verlangen><en> We do not charge you any booking fees, administration fees, or cancellation fees.
<G-vec00230-002-s633><charge.verlangen><de> Wir verlangen weder Buchungs-, Bearbeitungs- noch Stornierungsgebühren.
<G-vec00230-002-s634><charge.verlangen><en> You may ask the person in charge to confirm if personal data about you is processed by us.
<G-vec00230-002-s634><charge.verlangen><de> Sie können von dem Verantwortlichen eine Bestätigung darüber verlangen, ob personenbezogene Daten, die Sie betreffen, von uns verarbeitet werden.
<G-vec00230-002-s635><charge.verlangen><en> Due to an increase of not cancelled but not taken appointments we have to charge a prepayment of 50% of the booked spa services of our external guests.
<G-vec00230-002-s635><charge.verlangen><de> Bitte beachten Sie, dass wir aufgrund zahlreicher Terminausfälle für Buchungen von externen Gästen eine Anzahlung in Höhe von 50% der gebuchten Leistungen verlangen.
<G-vec00230-002-s636><charge.verlangen><en> Some banks charge a monthly fee for having below a certain amount of money in your account.
<G-vec00230-002-s636><charge.verlangen><de> Manche Banken verlangen eine monatliche Gebühr, wenn das Geld auf deinem Konto unter eine bestimmte Grenze fällt.
<G-vec00230-002-s637><charge.verlangen><en> If the customer requires an invoice to be sent to him by post, the provider is entitled to charge EUR 2.50 per administrative fee per invoice.
<G-vec00230-002-s637><charge.verlangen><de> Verlangt der Kunde eine Rechnung, die ihm auf dem Postweg zugestellt werden soll, so ist der Anbieter berechtigt, für den Verwaltungsaufwand pro Rechnung EUR 2,50 zu verlangen.
<G-vec00230-002-s638><charge.verlangen><en> You may charge a fee for the physical act of transferring a copy.
<G-vec00230-002-s638><charge.verlangen><de> Sie dürfen für den physikalischen Vorgang des Zugänglichmachens einer Kopie eine Gebühr verlangen.
<G-vec00230-002-s639><charge.verlangen><en> In less competitive markets, for instance, banks can charge higher interest rates.
<G-vec00230-002-s639><charge.verlangen><de> An weniger wettbewerbsorientierten Märkten können Banken beispielsweise höhere Zinssätze verlangen.
<G-vec00230-002-s640><charge.verlangen><en> However, an increasing number of banks charge identical fees regardless of the investment vehicles used.
<G-vec00230-002-s640><charge.verlangen><de> Allerdings gibt es immer mehr Banken, die unabhängig von der Strategie gleich viel verlangen.
<G-vec00230-002-s641><charge.verlangen><en> They charge 10€ per day and it has sauna, hot tub and all other amenities for shaping.
<G-vec00230-002-s641><charge.verlangen><de> Sie verlangen 10 € pro Tag und es hat eine Sauna, einen Whirlpool und alle anderen Annehmlichkeiten für die Gestaltung.
<G-vec00230-002-s643><charge.verlangen><en> In the case of a withdrawal from the contract, or a cancellation by the Seller, or if the Buyer does not accept the goods, we shall be entitled, irrespective of any other claims, to charge a cancellation fee of 20 % of the contract total in order to cover our expenses.
<G-vec00230-002-s643><charge.verlangen><de> Für den Fall des Vertragsrücktrittes oder der Stornierung durch den Verkäufer oder der Nichtannahme der Ware durch den Käufer, sind wir unbeschadet aller sonstigen Ansprüche berechtigt, zur Deckung unserer Aufwendungen einen Betrag in der Höhe von 20 % der Auftragssumme als Stornogebühr zu verlangen.
<G-vec00230-002-s644><charge.verlangen><en> When you charge purchases in foreign currencies to Swiss credit cards, card issuers charge you foreign transaction fees.
<G-vec00230-002-s644><charge.verlangen><de> Bei Transaktionen in Fremdwährungen verlangen Schweizer Kreditkartenherausgeber (Issuer) häufig happige Gebühren.
<G-vec00230-002-s645><charge.verlangen><en> You are entitled under the Federal Data Protection Act (BDSG) to request an information about your stored data free of charge.
<G-vec00230-002-s645><charge.verlangen><de> Sie sind nach dem Bundesdatenschutzgesetz (BDSG) berechtigt, eine unentgeltliche Auskunft über Ihre gespeicherten Daten zu verlangen.
<G-vec00230-002-s646><charge.verrechnen><en> Exceptions are only permitted to the extent that data is still required to charge or collect fees, to process complaints or to comply with other legal obligations.
<G-vec00230-002-s646><charge.verrechnen><de> Ausnahmen sind nur soweit zulässig, als diese Daten noch benötigt werden, um Entgelte zu verrechnen oder einzubringen, Beschwerden zu bearbeiten oder sonstige gesetzliche Verpflichtungen zu erfüllen.
<G-vec00230-002-s647><charge.verrechnen><en> If, on the other hand, the cancellation takes place at a later point in time, the Ski & Snowboard School is entitled to charge 100% of the booked service.
<G-vec00230-002-s647><charge.verrechnen><de> Erfolgt die Stornierung hingegen erst zu einem späteren Zeitpunkt, ist die Ski & Snowboardschule berechtigt 100% der gebuchten Leistung zu verrechnen.
<G-vec00230-002-s648><charge.verrechnen><en> We are not an intermediary - we bring buyer and provider together, which means we do not charge provisions, neither to you nor to your provider, and you can use your usual contracts and payroll services.
<G-vec00230-002-s648><charge.verrechnen><de> Wir sind kein Vermittler - wir bringen Auftraggeber und Auftragnehmer direkt zusammen, das heißt wir verrechnen keine Provisionen, weder dir noch deinem Auftraggeber, und du kannst eure gewohnten Verträge und Payroll Dienstleistungen einsetzen.
<G-vec00230-002-s649><charge.verrechnen><en> We charge up to € 12,00 per day for dogs without food.
<G-vec00230-002-s649><charge.verrechnen><de> Für Hunde verrechnen wir bis € 12,–/Tag ohne Futter.
<G-vec00230-002-s650><charge.verrechnen><en> Austrian clients, whether private or corporate, we have to charge VAT.
<G-vec00230-002-s650><charge.verrechnen><de> Österreichischen Kunden, egal ob privat oder Firma, müssen wir die Mehrwertsteuer verrechnen.
<G-vec00230-002-s651><charge.verrechnen><en> If you want to cancel your booking for whatever reason, we don’t charge any additional costs and look forward to welcoming you back as a customer next time. 8.
<G-vec00230-002-s651><charge.verrechnen><de> Wenn Sie aus welchem Grund auch immer von Ihrer Canazei Buchung zurücktreten wollen, verrechnen wir keine zusätzlichen Kosten und freuen uns, Sie das nächste Mal liebend gerne wieder als Kunde zu begrüßen.
<G-vec00230-002-s652><charge.verrechnen><en> Please check what we charge for the desired performance in advance.
<G-vec00230-002-s652><charge.verrechnen><de> Bitte fragen Sie im Vorfeld, was wir für die gewünschte Leistung verrechnen.
<G-vec00230-002-s653><charge.verrechnen><en> If you opt for partial shipment we will unfortunately be forced to charge you shipping fees for each shipment.
<G-vec00230-002-s653><charge.verrechnen><de> Sollten Sie sich für Teillieferungen entscheiden, müssen wir Ihnen für jede Lieferung die Versandkosten verrechnen.
<G-vec00230-002-s654><charge.verrechnen><en> For a stay of up to three days we charge a 10 % short stay surcharge.
<G-vec00230-002-s654><charge.verrechnen><de> Bei einem Aufenthalt bis zu drei Tage verrechnen wir 10 % Kurzaufenthaltszuschlag.
<G-vec00230-002-s655><charge.verrechnen><en> We charge for extra beds € 25,00 per day.
<G-vec00230-002-s655><charge.verrechnen><de> Extrabetten verrechnen wir für Erwachsene mit € 25,00 pro Tag.
<G-vec00230-002-s656><charge.verrechnen><en> If you cancel your holiday less then 5 weeks prior, we will have to charge the deposit you have already paid as cancellation fee.
<G-vec00230-002-s656><charge.verrechnen><de> Für Stornierungen ab 5 Wochen vor Anreise behalten wir es uns vor die Anzahlung als Stornogebühr zu verrechnen.
<G-vec00230-002-s657><charge.verrechnen><en> If your stay is less than 4 days, we charge you an addition of 10 %.
<G-vec00230-002-s657><charge.verrechnen><de> Bei einem Aufenthalt bis vier Tagen verrechnen wir einen Zuschlag von 10 %.
<G-vec00230-002-s658><charge.verrechnen><en> As you have probably already seen, we do not charge any extra fees for the cancellation of your booking from Innsbruck Airport to Canazei.
<G-vec00230-002-s658><charge.verrechnen><de> Wie bereits hunderte unserer Kunden erfahren durften, verrechnen wir bei der Stornierung Ihrer Buchung vom Airport Innsbruck nach Canazei keine Stornogebühren.
<G-vec00230-002-s659><charge.verrechnen><en> There are network operators that already charge termination fees.
<G-vec00230-002-s659><charge.verrechnen><de> Es existieren viele Mobilfunkanbieter, welche anderen Anbietern Terminierungsgebühren verrechnen.
<G-vec00230-002-s660><charge.verrechnen><en> We also do not charge extra for cancellations or changes to bookings.
<G-vec00230-002-s660><charge.verrechnen><de> Auch für Stornierungen oder Buchungsänderungen verrechnen wir keine Extragebühren.
<G-vec00230-002-s661><charge.verrechnen><en> In case of default by the purchaser, we are entitled to charge default interest at the rate of 5 % per year, thus claims to compensation for higher interest rates are not affected.
<G-vec00230-002-s661><charge.verrechnen><de> Bei Zahlungsverzug durch den Besteller sind wir berechtigt, Verzugszinsen in der Höhe von 5 % jährlich zu verrechnen, hierdurch werden Ansprüche auf Ersatz höherer Zinsen nicht beeinträchtigt.
<G-vec00230-002-s662><charge.verrechnen><en> We offer free cancellation up to 24 hours before your pickup time with most of our suppliers and we never charge credit card fees.
<G-vec00230-002-s662><charge.verrechnen><de> Wir bieten für die meisten unserer Anbieter eine gratis Stornomöglichkeit bis zu 24 Stunden vor Ihrer Abholzeit und verrechnen niemals Kreditkartengebühren.
<G-vec00230-002-s663><charge.verrechnen><en> Upon any violation of this behavior the organizer is entitled to charge a penalty fee amounting to 5.000 € (in words: five thousand euros) and to exclude the participant from the event.
<G-vec00230-002-s663><charge.verrechnen><de> Sollte gegen dieses Verhalten verstoßen werden, so ist der Veranstalter berechtigt eine Konventionalstrafe in der Höhe 5.000.- € (in Wortend: fünftausend Euro) zu verrechnen und den Teilnehmer von der Veranstaltung auszuschließen.
<G-vec00230-002-s664><charge.verrechnen><en> We just charge a part of the real shipping cost with a small flat rate for shipping.
<G-vec00230-002-s664><charge.verrechnen><de> Wir verrechnen lediglich einen Teil der Versandkosten in Form einer Versandkostenpauschale.
<G-vec00347-002-s133><charge.berechnen><en> Example For example, you charge DKK 500 for your event, you pay the following to use our payment module: 500 * 0.016 = 8 DKK ex.
<G-vec00347-002-s133><charge.berechnen><de> Beispiel Wenn Sie beispielsweise 150 € für Ihre Veranstaltung berechnen, kostet die Nutzung unseres Zahlungsmoduls: 150 * 0,016 = 2,40 € (ohne MwSt).
<G-vec00347-002-s134><charge.berechnen><en> For overnight stays shorter than 2 nights we charge a surcharge of € 7.50 per person.
<G-vec00347-002-s134><charge.berechnen><de> Bei Übernachtungen kürzer als 2 Nächte berechnen wir pro Person einen Zuschlag von 7,50 €.
<G-vec00347-002-s135><charge.berechnen><en> GER: For mailing to Germany and Switzerland the flat charge for packaging and mailing costs is Eur 7,00.
<G-vec00347-002-s135><charge.berechnen><de> D: nach Deutschland und in die Schweiz berechnen wir eine Pauschale von 7,00 Euro.
<G-vec00347-002-s136><charge.berechnen><en> If the period allowed for payment is exceeded, we must charge reminder and handling fees.
<G-vec00347-002-s136><charge.berechnen><de> Bei Überschreiten der vereinbarten Zahlungsfristen müssen wir Mahn- und Bearbeitungsgebühren berechnen.
<G-vec00347-002-s137><charge.berechnen><en> Dogs and cats are welcome: we charge € 9.00 per day excluding food.
<G-vec00347-002-s137><charge.berechnen><de> Hunde und Katzen sind willkommen: wir berechnen € 9,00 pro Tag ohne Futter.
<G-vec00347-002-s138><charge.berechnen><en> § 4.1 For delivery within Germany we charge a flat rate of € 4.95 per order for standard delivery.
<G-vec00347-002-s138><charge.berechnen><de> § 4.1 Für die Lieferung innerhalb Deutschlands berechnen wir pauschal 4,95 Euro pro Bestellung für den Standardversand.
<G-vec00347-002-s139><charge.berechnen><en> We do not charge any booking fees, groups may get discounts.
<G-vec00347-002-s139><charge.berechnen><de> Für die Reservierung berechnen wir keine Gebühren und bieten Gruppen Rabatte.
<G-vec00347-002-s140><charge.berechnen><en> We have the right to charge the supplier a standard rate of 10 Euros – plus packaging and forwarding expenses – for handling costs incurred.
<G-vec00347-002-s140><charge.berechnen><de> Für den uns entstehenden Bearbeitungsaufwand sind wir berechtigt, dem Lieferanten –zuzüglich Verpackung und Versendungsauslagen- eine Pauschale von 10 Euro zu berechnen.
<G-vec00347-002-s141><charge.berechnen><en> For deliveries to Austria, Switzerland, Liechtenstein, the Netherlands, Belgium, UK, Ireland, France, Italy, Poland, Czech Republic, Denmark and Sweden we charge for delivery of parcels up to 31 kg overall 12.50 €, and for Speergut- and forwarding consignments 95.00 € per order.
<G-vec00347-002-s141><charge.berechnen><de> Für Lieferungen nach Österreich, Niederlande, Belgien, Vereinigtes Königreich, Irland, Frankreich, Italien, Polen, Tschechische Republik, Dänemark und Schweden berechnen wir für die Lieferung von Paketsendungen bis 10 kg pauschal 69,00 €, sowie für Speergut- und Speditionssendungen bis 20 kg 99,00 € pro Bestellung.
<G-vec00347-002-s142><charge.berechnen><en> We don't charge artists any sales fees or commissions.
<G-vec00347-002-s142><charge.berechnen><de> Wir berechnen unseren Künstlern keine Gebühren, wenn sie etwas verkaufen.
<G-vec00347-002-s143><charge.berechnen><en> If your order is shipped to a country outside of the European Union (EU), then we will not charge you VAT.
<G-vec00347-002-s143><charge.berechnen><de> Wenn Ihre Bestellung in ein Land außerhalb der Europäischen Union (EU) geliefert wird, werden wir Ihnen keine Mehrwertsteuer berechnen.
<G-vec00347-002-s144><charge.berechnen><en> For breakfast we charge € 8.50 per person
<G-vec00347-002-s144><charge.berechnen><de> Hierfür berechnen wir jeweils € 8,50 p.P.
<G-vec00347-002-s145><charge.berechnen><en> Regardless of how high the cost of postage and packaging are, actually we charge (depending on the country) for the delivery costs a flat fee.
<G-vec00347-002-s145><charge.berechnen><de> Unabhängig davon, wie hoch die Kosten für Porto und Verpackung tatsächlich sind, berechnen wir für die Versandkosten eine Kostenpauschale abhängig vom Land.
<G-vec00347-002-s146><charge.berechnen><en> 7.2 In addition to the prices quoted, we shall charge shipping costs for delivery.
<G-vec00347-002-s146><charge.berechnen><de> 7.2 Zusätzlich zu den angegebenen Preisen berechnen wir für die Lieferung Versandkosten.
<G-vec00347-002-s147><charge.berechnen><en> To cover expenses we will charge an amount from each of the participants.
<G-vec00347-002-s147><charge.berechnen><de> Um die Kosten zu decken, berechnen wir einen Betrag von jedem der Teilnehmer.
<G-vec00347-002-s148><charge.berechnen><en> We do not charge a monthly or recurring fee to view the site.
<G-vec00347-002-s148><charge.berechnen><de> Wir berechnen keine monatliche oder wiederkehrende Gebühr, um die Website anzusehen.
<G-vec00347-002-s149><charge.berechnen><en> If you would like us to present your house at our site, we will only charge you a small amount for every booking we generate in order to cover our variable costs.
<G-vec00347-002-s149><charge.berechnen><de> Wenn Sie uns Ihr Haus auf unserer Website präsentieren möchten, nur berechnen wir Ihnen eine kleine Menge für jede Buchung, die wir erzeugen, um unsere Variable Kosten zu decken.
<G-vec00347-002-s150><charge.berechnen><en> If the travel time amounts to more than 4 hours, we charge a fixed rate of 1/3 of our daily rate.
<G-vec00347-002-s150><charge.berechnen><de> Beträgt die Reisezeit mehr als 4 Stunden berechnen wir pauschal 1/3 unseres Tagessatzes.
<G-vec00347-002-s151><charge.berechnen><en> We reserve the right to charge extra for some heavy or large items (like consoles or big studio monitors).
<G-vec00347-002-s151><charge.berechnen><de> Wir behalten uns das Recht vor, für extra große oder extra schwere Lieferungen wie zum Beispiel Mischpulte und Monitore/Lautsprecher eine zusätzliche Liefergebühr zu berechnen.
<G-vec00347-002-s570><charge.verantwortlichen><en> The data is processed in the operational offices of the Responsible and the Person in Charge of the Treatment and in any other place where the parties involved in the treatment are.
<G-vec00347-002-s570><charge.verantwortlichen><de> Die Daten werden in den Geschäftsräumen des Verantwortlichen und der für die Behandlung verantwortlichen Person sowie an jedem anderen Ort verarbeitet, an dem sich die an der Behandlung beteiligten Parteien befinden.
<G-vec00347-002-s571><charge.verantwortlichen><en> With his help and the guide of the official in charge, I could look around the fire train for the first time.
<G-vec00347-002-s571><charge.verantwortlichen><de> Mit seiner Hilfe und der Auskunft des Verantwortlichen konnte ich glücklich den Zug zum ersten Mal gucken.
<G-vec00347-002-s572><charge.verantwortlichen><en> Those in charge didn't allow her family to visit her.
<G-vec00347-002-s572><charge.verantwortlichen><de> Die Verantwortlichen erlaubten ihren Familienangehörigen nicht, sie zu besuchen.
<G-vec00347-002-s573><charge.verantwortlichen><en> This is why the Fürstenfeldbruck Hospital in Germany calculated very tightly, and the persons in charge opted for the adiabatic state-of-the-art ADC dry coolers from JAEGGI as the life cycle costs were ultimately decisive for the investment.
<G-vec00347-002-s573><charge.verantwortlichen><de> Im Klinikum Fürstenfeldbruck, Deutschland, wurde daher scharf kalkuliert und die Verantwortlichen haben sich für die adiabatischen „State-of-the-Art“-Rückkühler ADC von JAEGGI entschieden, da die Life-Cycle-Costs bei der Investition letztendlich den Ausschlag gegeben haben.
<G-vec00347-002-s574><charge.verantwortlichen><en> The basic information of the technical submission template shall include, but is not limited to, the title of the invention creation, the type of application expected, and the contact information of the technical person in charge.
<G-vec00347-002-s574><charge.verantwortlichen><de> Die Basisinformationen der Vorlage für technische Einreichungen umfassen unter anderem den Titel der Erfindungserstellung, die Art der erwarteten Anwendung und die Kontaktinformationen der verantwortlichen technischen Person.
<G-vec00347-002-s575><charge.verantwortlichen><en> He spoke to the colonel in charge of the special branch of Military Intelligence and vouched for her.
<G-vec00347-002-s575><charge.verantwortlichen><de> Er sprach mit dem verantwortlichen Colonel und bürgte für sie.
<G-vec00347-002-s576><charge.verantwortlichen><en> If the limitation of the processing after the o.g. If conditions are restricted, you will be informed by the person in charge before the restriction is lifted.
<G-vec00347-002-s576><charge.verantwortlichen><de> Wurde die Einschränkung der Verarbeitung nach den oben genannten Voraussetzungen eingeschränkt, werden Sie von dem Verantwortlichen unterrichtet bevor die Einschränkung aufgehoben wird.
<G-vec00347-002-s577><charge.verantwortlichen><en> In addition to the Owner, in some cases, the Data may be accessible to certain types of persons in charge, involved with the operation of this Application (administration, sales, marketing, legal, system administration) or external parties (such as third-party technical service providers, mail carriers, hosting providers, IT companies, communications agencies) appointed, if necessary, as Data Processors by the Owner.
<G-vec00347-002-s577><charge.verantwortlichen><de> Neben dem Datenverantwortlichen wird möglicherweise auch bestimmten Kategorien von Verantwortlichen Zugriff auf die Daten gewährt, die an der Betreibung der Website beteiligt sind (Personalverwaltung, Vertrieb, Marketing, Rechtsabteilung, Systemadministratoren) oder externen Parteien (wie Fremdanbietern technischer Dienstleistungen, Zustellunternehmen, Hosting-Anbietern, IT-Unternehmen oder Kommunikationsagenturen), die, falls notwendig, vom Eigentümer als Datenverarbeiter eingesetzt werden.
<G-vec00347-002-s578><charge.verantwortlichen><en> d) the essential information to identify the holder, the persons in charge of processing, and the appointed representative in accordance with art.5, paragraph 2; e) the subjects (or categories of subjects) to whom the personal data may be
<G-vec00347-002-s578><charge.verantwortlichen><de> d) die wichtigsten Daten zur Identifizierung des Rechtsinhabers, der Verantwortlichen und des im Sinne von Artikel 5 Absatz 2 namhaft gemachten Vertreters; e) die Personen oder Kategorien von Personen, denen die personenbezogenen Daten übermittelt werden können oder die als im Staatsgebiet namhaft gemachte Vertreter, als Verantwortliche oder als Beauftragte davon Kenntnis erlangen können.
<G-vec00347-002-s579><charge.verantwortlichen><en> In addition to the Data Controller, in some cases, the Data may be accessible to certain types of persons in charge, involved with the operation of the service (administration, support, sales, marketing, legal, system administration, financial) or external parties (such as third party service providers, mail carriers, communications agencies) appointed, if necessary, as Data Processors by the Owner.
<G-vec00347-002-s579><charge.verantwortlichen><de> Zusätzlich zum Datenverantwortlichen sind in einigen Fällen die Daten auch für bestimmte Arten von Verantwortlichen zugänglich, die mit dem Betrieb des Dienstes befasst sind (Verwaltung, Support, die gegebenenfalls vom Eigentümer als Datenverarbeiter ernannt werden.
<G-vec00347-002-s580><charge.verantwortlichen><en> Not to mention the essential role of control and validation provided by the people in charge of these solutions.
<G-vec00347-002-s580><charge.verantwortlichen><de> Ohne die wichtige Rolle der Überwachung und Validierung der Verantwortlichen für diese Lösungen zu vergessen.
<G-vec00347-002-s581><charge.verantwortlichen><en> The authorities of the patriarchate of Moscow are aware of this, and when they invoke the principle of “sister Churches” they do so in reference to the attitude with which the decisions were taken by the Catholics in charge, that is without previous information and consultation with the Orthodox side.
<G-vec00347-002-s581><charge.verantwortlichen><de> Die Behördenvertreter des Patriarchats Moskau sind sich dessen bewußt, und wenn sie auf dem Prinzip der „Schwesterkirchen“ beharren, dann beziehen sie sich dabei auf die Art und Weise, wie die Entscheidungen von den katholischen Verantwortlichen getroffen worden sind, und zwar ohne Rücksprache und Miteinbeziehung der Orthodoxen.
<G-vec00347-002-s582><charge.verantwortlichen><en> Despite all of this, those in charge have to use common sense, otherwise exactly this will happen, what is commonly referred to as insanity.
<G-vec00347-002-s582><charge.verantwortlichen><de> Bei alldem darf der gesunde Menschenverstand die Verantwortlichen aber nicht verlassen, denn sonst tritt genau das ein, was gemeinhin unter dem Wort Wahnsinn verstanden wird.
<G-vec00347-002-s583><charge.verantwortlichen><en> Please note that trolley and buggies are not allowed frequently when a course is wet and are determined by those in charge of the golf course.
<G-vec00347-002-s583><charge.verantwortlichen><de> Bitte beachten Sie auch, dass Trolleys und Buggies häufig nicht erlaubt sind, wenn der Platz nass ist, dies wird von den Verantwortlichen der Golfplätze bestimmt.
<G-vec00347-002-s584><charge.verantwortlichen><en> After communion, those in charge directed themselves to the new couples to give them a little letter of cordial welcome, telling them how proud they were to have them at their side, in the their prayers and in their Heart Shrines.
<G-vec00347-002-s584><charge.verantwortlichen><de> Nach der Eucharistiefeier richteten sich die Verantwortlichen an die neuen Paare und gaben ihnen einen kleinen Brief, der sagte, wie stolz sie auf sie sind, dass sie sich ihnen anschließen, mit ihnen beten und über ihre Herzensheiligtümern verbunden sein möchten.
<G-vec00347-002-s585><charge.verantwortlichen><en> The persons in charge of the amicable recovery acting for the account of the establishments of consumer credit have for mission to listen and to contact the customer in order to reach an amicable solution to the difficulties of payment that it meets and, as far as to make can, maintain the business relationship with him.
<G-vec00347-002-s585><charge.verantwortlichen><de> Die für die gütliche Rückerstattung verantwortlichen Personen, die für Rechnung der Einrichtungen des Verbraucherkredits tätig sind, haben die Pflicht, den Kunden anzuhören und sich mit ihm in Verbindung zu setzen, um eine gütliche Lösung für die Zahlungsschwierigkeiten, die er trifft, zu erreichen kann, pflegen die Geschäftsbeziehung mit ihm.
<G-vec00347-002-s586><charge.verantwortlichen><en> With the necessary tact we, the ones in charge, led the faithful to understand that the Eucharistic celebration, far from breaking their mourning, supported it and clarified it.
<G-vec00347-002-s586><charge.verantwortlichen><de> Mit dem nötigen Taktgefühl haben wir, die Verantwortlichen, die Gläubigen dazu gebracht zu verstehen, dass die Eucharistiefeier, die Trauer, anstatt sie zu durchbrechen, sie unterstützte und erhellte.
<G-vec00347-002-s587><charge.verantwortlichen><en> To the IS specialists in charge of the corporate network, it all appears as communication with a safe website from a known CDN via an encrypted channel because they treat the CDN, the client of which is their company, as part of the trusted network.
<G-vec00347-002-s587><charge.verantwortlichen><de> Für die für das Unternehmensnetzwerk verantwortlichen IS-Spezialisten erscheint dies als Kommunikation mit einer sicheren Website von einem bekannten CDN durch einen verschlüsselten Kanal, da sie das CDN als Teil des vertrauenswürdigen Netzwerks behandeln.
<G-vec00347-002-s588><charge.verantwortlichen><en> We are accompanied by mining technician Pietro Piras and Nicola Muller, in charge of the rescue squads that take care of safety in the galleries.
<G-vec00347-002-s588><charge.verantwortlichen><de> Wir befinden uns in Begleitung von dem Bergbautechniker Pietro Piras, und Nicola Muller, dem Verantwortlichen für die Rettungsteams, die sich um die Sicherheit im Stollen kümmern.
