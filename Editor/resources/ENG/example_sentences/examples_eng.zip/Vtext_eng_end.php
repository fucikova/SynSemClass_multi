<G-vec00213-002-s133><end.beenden><en> At the end of the exhibition, a lady working in a pharmacy brought hot drinks for the practitioners.
<G-vec00213-002-s133><end.beenden><de> Als die Ausstellung beendet wurde, kam eine Frau, die in einer Apotheke arbeitete, vorbei und bot den Praktizierenden heiße Getränke an.
<G-vec00213-002-s134><end.beenden><en> Mitch Gerber from the USA: The ongoing persecution against Falun Gong must truly end.
<G-vec00213-002-s134><end.beenden><de> Mitchy Gerber, USA Die Verfolgung von Falun Gong muss beendet werden.
<G-vec00213-002-s135><end.beenden><en> The Finn wound up his Formula One career at the end of the 2001 season.
<G-vec00213-002-s135><end.beenden><de> Nach der Saison 2001 beendet der Finne seine Formel-1-Karriere.
<G-vec00213-002-s136><end.beenden><en> If you are ending a contract because we have told you about an error in the price of the product you have ordered and you do not wish to proceed the contract will end immediately and we will refund you in full for any products which have not been provided.
<G-vec00213-002-s136><end.beenden><de> Wenn Sie einen Vertrag stornieren, weil wir Sie über einen Fehler bei der Preisangabe des von Ihnen bestellten Produkts benachrichtigt haben und Sie möchten den Kauf nicht durchführen, wird der Vertrag sofort beendet und wir erstatten Ihnen den vollen Preis für jegliche Produkte, die nicht geliefert wurden.
<G-vec00213-002-s137><end.beenden><en> System Password You can assign a System Password for the configuration environment of your Gigaset SE551 WLAN dsl/cable, and specify the period after which a session is to end automatically if no further entry is made.
<G-vec00213-002-s137><end.beenden><de> Systemkennwort Sie können ein Systemkennwort für die Bedienoberfläche des Gigaset SX762 WLAN dsl zuweisen und die Zeitdauer angeben, nach der eine Sitzung automatisch beendet wird, wenn keine Eingabe mehr vorgenommen wurde.
<G-vec00213-002-s138><end.beenden><en> According to the news appeared in press, while the activity was going on with participation of the expelled academics and CHP Ankara MP Murat Emir, riot police came to Cebeci Campus and told the students to end the activity.
<G-vec00213-002-s138><end.beenden><de> Während die Veranstaltung, an der auch entlassene Akademiker und der Abgeordnete der CHP Ankara, Murat Emir, teilnahmen, kamen Polizisten der Schnellen Eingreiftruppe auf den Cebeci-Campus und sagte, die Veranstaltung solle auf Anordnung des Rektors der Universität Ankara beendet werden.
<G-vec00213-002-s139><end.beenden><en> Menopause: a term used to describe the permanent cessation of the primary functions of the human ovaries, signalling the end of the fertile phase of a woman's life.
<G-vec00213-002-s139><end.beenden><de> Die Menopause ist der Zeitpunkt der letzten spontanen Menstruation im Leben einer Frau, womit auch die Fruchtbarkeit der Frau beendet ist.
<G-vec00213-002-s140><end.beenden><en> With the end of the season in California, the price is also on a falling trend.
<G-vec00213-002-s140><end.beenden><de> In Florda, Georgia, North Carolina und Kalifornien ist die Saison so gut wie beendet.
<G-vec00213-002-s141><end.beenden><en> ENGLISH At the end of the programme The display shows 0 and the end indicator comes on.
<G-vec00213-002-s141><end.beenden><de> 15 Am Programmende Wenn das Programm beendet ist, leuchtet die Kontrolllampe „Programmende“ und das Display zeigt 0 an.
<G-vec00213-002-s142><end.beenden><en> Unless Assad goes, neither the war nor the wave of refugees will end.
<G-vec00213-002-s142><end.beenden><de> Ohne Assads Abgang werden weder der Krieg beendet noch die Flüchtlingswelle gestoppt werden.
<G-vec00213-002-s143><end.beenden><en> 1928 - Jørgen Jørgensen decides to start up for himself and end the cooperation in Polar.
<G-vec00213-002-s143><end.beenden><de> 1928: Jørgen Jørgensen entschließt sich zur Gründung eines eigenen Unternehmens und beendet seine Teilhaberschaft an Polar.
<G-vec00213-002-s144><end.beenden><en> They are initiated with "/*" and end with "*/".
<G-vec00213-002-s144><end.beenden><de> Diese werden mit "/*" eingeleitet und "*/" beendet.
<G-vec00213-002-s145><end.beenden><en> The Pisoni family has come a long way, over 3 centuries of history, overcoming two world wars, a serious financial crisis in the 1930s and one that is just as serious, which started in 2007 and has not yet come to an end.
<G-vec00213-002-s145><end.beenden><de> Die Familie Pisoni hat über 3 Jahrhunderte Geschichte hinweg viel Weg zurückgelegt, zwei Weltkriege, eine schwere Wirtschaftskrise in den 30er Jahren des vergangenen Jahrhunderts und eine ebenso schwere Wirtschaftskrise überstanden, die 2007 begonnen hat und noch nicht beendet ist.
<G-vec00213-002-s146><end.beenden><en> e. In Shootout and Heads-Up events, if all players at a table are disconnected and / or sitting out for a large number of hands (typically 250 hands or more in real money tournaments), the match will end and the player with the most chips will advance to the next round.
<G-vec00213-002-s146><end.beenden><de> e. Wenn bei Shootout- oder Heads-up-Turnieren die Verbindung aller Spieler an einem Tisch abbricht und/oder alle Spieler für eine große Anzahl an Händen (bei Echtgeld-Turnieren üblicherweise 250 Hände oder mehr) aussetzen, wird das Match beendet und der Spieler mit den meisten Chips rückt in die nächste Runde vor.
<G-vec00213-002-s147><end.beenden><en> The conversation has come to an end once circumstances show that the matter concerned has been dealt with conclusively.
<G-vec00213-002-s147><end.beenden><de> Beendet ist die Konversation dann, wenn sich aus den Umständen entnehmen lässt, dass der betroffene Sachverhalt abschließend geklärt ist.
<G-vec00213-002-s148><end.beenden><en> To see an end to our sweet little baby’s suffering is priceless.
<G-vec00213-002-s148><end.beenden><de> Das Leiden unseres süßen kleinen Babys beendet zu haben, ist unbezahlbar.
<G-vec00213-002-s149><end.beenden><en> 1 And it came to pass, when Jesus had made an end of commanding his twelve disciples, he departed thence to teach and to preach in their cities.
<G-vec00213-002-s149><end.beenden><de> 1 Und es begab sich, als Jesus diese Gebote an seine zwölf Jünger beendet hatte, ging er von dort weiter, zu lehren und zu predigen in ihren Städten.
<G-vec00213-002-s150><end.beenden><en> At the end of the row, we will have a total of 34 stitches, the same number as when we started the project.
<G-vec00213-002-s150><end.beenden><de> Sobald du die Reihe beendet hast, haben wir insgesamt 34 Maschen, also genauso viele, wie zum Beginn deines Projekts.
<G-vec00213-002-s151><end.beenden><en> This is day that always remind us, it is the end of riding horse for the little Big Horn Memorial Horse Ride 2014.
<G-vec00213-002-s151><end.beenden><de> Dieser Tag bleibt uns immer im Gedächtnis, er beendet unseren Ritt zu Ehren des Kampfes am Little Big Horn 2014.
<G-vec00213-002-s285><end.enden><en> Of course, our service does not end as soon as you have found a suitable venue, because a successful event also includes equipment, a culinary framework and decoration elements.
<G-vec00213-002-s285><end.enden><de> Natürlich endet unser Service aber nicht, sobald Sie einen passenden Austragungsort gefunden haben, denn eine gelungene Veranstaltung beinhaltet auch die Ausstattung, einen kulinarischen Rahmen und Dekorationselemente.
<G-vec00213-002-s286><end.enden><en> Hitting the ground will end your flight.
<G-vec00213-002-s286><end.enden><de> Auf dem Boden endet Ihr Flug.
<G-vec00213-002-s287><end.enden><en> If the dealer’s second card results in a blackjack, your entire wager will be collected by the dealer and the game will come to an end.
<G-vec00213-002-s287><end.enden><de> Wenn die zweite Karte des Gebers zu einem Blackjack führt, wird Ihr gesamter Einsatz vom Geber eingezogen, und das Spiel endet.
<G-vec00213-002-s288><end.enden><en> And that is terrible, it could give rise to a war that will never end,” he said at the European premiere.
<G-vec00213-002-s288><end.enden><de> Und das ist furchtbar, denn es könnte einen Krieg heraufbeschwören, der nie endet“, erklärt er anlässlich der Uraufführung von „Three Posters“ in Europa.
<G-vec00213-002-s289><end.enden><en> But our program philosophy doesn't end there.
<G-vec00213-002-s289><end.enden><de> Unsere Programmphilosophie endet damit aber nicht.
<G-vec00213-002-s290><end.enden><en> The building process will end by the end of Summer 2017.
<G-vec00213-002-s290><end.enden><de> Der Bauprozess endet bis zum Ende des Sommers 2017.
<G-vec00213-002-s291><end.enden><en> Pleasure doesn’t need to end when you leave the Gasthof Brandstätter to return home. You can also take some delicious items home with you.
<G-vec00213-002-s291><end.enden><de> Damit der Genuss nicht endet, wenn Sie den Gasthof Brandstätter in Salzburg wieder verlassen müssen, können Sie die Köstlichkeiten auch gerne mit nach Hause nehmen.
<G-vec00213-002-s292><end.enden><en> The cancellation proceedings before OHIM end with a decision, with which the opposed trademark is cancelled or partially cancelled or with which the request for cancellation is rejected.
<G-vec00213-002-s292><end.enden><de> Das Löschungsverfahren vor dem Harmonisierungsamt endet mit einem Beschluss, mit dem die angegriffene Marke gelöscht oder teilweise gelöscht wird oder mit dem der Antrag auf Löschung zurückgewiesen wird.
<G-vec00213-002-s293><end.enden><en> The conception phase will end in September 2020.
<G-vec00213-002-s293><end.enden><de> Im September 2020 endet die Konzeptionsphase.
<G-vec00213-002-s294><end.enden><en> Conditions IMPORTANT NOTIFICATION All those high speed departures from Madrid, or those that pass through Madrid to Castellón or Oropesa del Mar, will be affected until further notice with the end of the line being Valencia.
<G-vec00213-002-s294><end.enden><de> Conditions WICHTIGE MITTEILUNG Alle Bahnfahrten ab Madrid, oder die über Madrid gehen, mit Ankunft in Castellón de la Plana oder Oropesa Del Mar sind betroffen, und die Fahrt endet bis auf weiteres in Valencia; wir benachrichtigen Sie sofort, falls RENFE uns Änderungen mitteilen sollte.
<G-vec00213-002-s295><end.enden><en> For over 100 cows, calves and sheep this event marks the end of their stay in altitude where they enjoyed the fresh mountain air, tasty grass and cool nights.
<G-vec00213-002-s295><end.enden><de> Almabtrieb mit Herbstfest Für die Kühe, Kälber und Schafe endet damit der Aufenthalt in luftiger Höhe, bei frischer Bergluft, würzigem Gras und kühlen Nächten.
<G-vec00213-002-s296><end.enden><en> But to depart entirely without faith from earth is a hopeless state and will end with renewed banishment, because the gates of the beyond will close the moment the old earth is dissolved.
<G-vec00213-002-s296><end.enden><de> Doch ganz ohne Glauben abzuscheiden von der Erde ist hoffnungslos und endet mit der Neubannung, weil das Jenseits die Tore geschlossen hat mit dem Moment des Auflösens der alten Erde.
<G-vec00213-002-s297><end.enden><en> As a sentient being, all the thoughts you have in life will end with death.
<G-vec00213-002-s297><end.enden><de> Als fühlendes Wesen, alle Gedanken, die Sie im Leben haben, wird mit dem Tod endet.
<G-vec00213-002-s298><end.enden><en> That's really hard to cope with, because I tend to get carried away by it, and end up being hurt myself.
<G-vec00213-002-s298><end.enden><de> Es ist wirklich schwer, dies zu bewältigen, weil ich dazu neige, es mit mir mitzutragen und es endet damit, daß ich mir selbst wehtue.
<G-vec00213-002-s299><end.enden><en> Therefore, their terms of office end with the conclusion of the Annual General Meeting that decides on discharge for the 2013 financial year.
<G-vec00213-002-s299><end.enden><de> Ihre Amtszeit endet daher mit Beendigung der Hauptversammlung, die über die Entlastung für das Geschäftsjahr 2013 beschließt.
<G-vec00213-002-s300><end.enden><en> The prayer of Psalm 40, however, does not end against such a dark background.
<G-vec00213-002-s300><end.enden><de> Doch das Gebet des Psalm 40 endet nicht mit diesem finsteren Gedanken.
<G-vec00213-002-s301><end.enden><en> Preparation does not end with registration and booking your trip.
<G-vec00213-002-s301><end.enden><de> Die Vorbereitung endet nicht mit der Registrierung und der Buchung Ihrer Reise.
<G-vec00213-002-s302><end.enden><en> The deadline for accepting the offer begins on the day following the dispatch of the offer by the customer immediately and shall end with the end of the fifth day, which follows the dispatch of the offer.
<G-vec00213-002-s302><end.enden><de> Die Frist zur Annahme des Angebots beginnt am Tag nach der Absendung des Angebots durch den Kunden zu laufen und endet mit dem Ablauf des fünften Tages, welcher auf die Absendung des Angebots folgt.
<G-vec00213-002-s303><end.enden><en> 1. When the ECB determines that direct supervision by the ECB of a supervised entity or a supervised group will end, the ECB shall issue an ECB decision to each supervised entity concerned specifying the date and reasons why the direct supervision will end.
<G-vec00213-002-s303><end.enden><de> (1) Bestimmt die EZB, dass die direkte Beaufsichtigung eines beaufsichtigten Unternehmens oder einer beaufsichtigten Gruppe durch die EZB endet, erlässt die EZB für jedes betroffene beaufsichtigte Unternehmen einen Beschluss, in dem der Tag festgelegt wird, an dem die direkte Beaufsichtigung endet, und die Gründe für die Beendigung.
<G-vec00213-002-s304><end.endkunden><en> To this end, in the reporting year the previously separate sales structures of Zumtobel and Thorn were merged to form a single sales organisation structured according to three sales channels: project business, end customer and wholesale.
<G-vec00213-002-s304><end.endkunden><de> Dazu wurden im Berichtsjahr die bislang getrennten Vertriebe von Zumtobel und Thorn in eine gemeinsame Vertriebsorganisation zusammengeführt und diese nach drei Vertriebskanälen – Projektgeschäft, Endkunden und Großhandel – strukturiert.
<G-vec00213-002-s305><end.endkunden><en> If, despite appropriate collection measures, the respective provider is unable to collect debts outstanding for the use of your 0900, 0901 or 0906 number from the end customer (the person who is calling your 0900, 0901 or 0906 number), the respective provider may reclaim the amount already paid to Sunrise for the respective Sunrise provided service.
<G-vec00213-002-s305><end.endkunden><de> Alle Informationen Charge-Back Wenn der jeweilige Provider die Forderungen für die Inanspruchnahme Ihrer 0900-, 0901- oder 0906-Nummern gegenüber dem Endkunden (auf Ihre 0900-, 0901- oder 0906-Nummer anrufende Person) trotz entsprechender Inkassomassnahmen nicht einbringen kann, kann der jeweilige Provider den für diese Leistungen an Sunrise ausbezahlten Betrag von Sunrise zurückfordern.
<G-vec00213-002-s306><end.endkunden><en> Whether in the healthcare industry, marketing or for the end customer, data analysis personalises experiences, increases efficiency and, thanks to data-driven decision making, offers companies competitive advantages.
<G-vec00213-002-s306><end.endkunden><de> Ob in Health Care, im Marketing oder beim Endkunden: Die Datenanalyse personalisiert Erlebnisse, steigert die Effizienz und verschafft Unternehmen aufgrund der datenbasierten Entscheidungsfindung Wettbewerbsvorteile.
<G-vec00213-002-s307><end.endkunden><en> In your daily operations, this translates into dedicated account managers who have full oversight of your entire logistic chain, from supplier to end customer.
<G-vec00213-002-s307><end.endkunden><de> In der Praxis bedeutet das, dass Sie einen festen Ansprechpartner haben, der einen umfassenden Überblick über Ihre gesamte Lieferkette hat, vom Lieferanten bis zum Endkunden.
<G-vec00213-002-s308><end.endkunden><en> Light current (data) StakoHome distributor is ready to meet the demand of 99 percent of end users and developers, and the remaining one percent is on an extensive and demanding installations with multiple data ports and a number of active elements that the Stakohome distributor is not designed for.
<G-vec00213-002-s308><end.endkunden><de> Der Stakohome Schwachstrom-(Daten-)Verteiler ist dafür ausgelegt, die Anfrage von 99 Prozent der Endkunden und Developer zu befriedigen; das verbleibende Prozent stellen umfangreiche und anspruchsvolle Installationen mit einer höheren Anzahl an Datenports und einer Vielzahl aktiver Elemente dar, für die der Stakohome Verteiler nicht dimensioniert ist.
<G-vec00213-002-s309><end.endkunden><en> Market sales have increased to 63 billion euros in 2018, an increase of around ten percent compared to 2017.1 "The demand for modern and innovative logistics concepts in this area is high, because the goods are to be delivered to the end customer as quickly, cost-effectively and efficiently as possible.
<G-vec00213-002-s309><end.endkunden><de> Der Marktumsatz wird sich 2018 voraussichtlich auf 63 Milliarden Euro erhöhen und damit eine Steigerung von rund zehn Prozent im Vergleich zu 2017 vorweisen können.1 „Der Bedarf an modernen und innovativen Logistikkonzepten in diesem Bereich ist groß, denn die Ware soll möglichst schnell, kostengünstig und effizient an den Endkunden geliefert werden.
<G-vec00213-002-s310><end.endkunden><en> With the presentation of your studio, you will reach customers and end clients in print media and online in market research agencies and industry for a whole year.
<G-vec00213-002-s310><end.endkunden><de> Mit Ihrer Studio-Präsentation erreichen Sie in Print und Online Auftraggeber und Endkunden in Instituten und Industrie - ein ganzes Jahr lang.
<G-vec00213-002-s311><end.endkunden><en> GPS Tracking & Anti-and endorsements from Kronings end customers and professional users.
<G-vec00213-002-s311><end.endkunden><de> Lesen Sie Meinungen und Empfehlungen von Kronings Endkunden und professionelle Anwendern.
<G-vec00213-002-s312><end.endkunden><en> Web2Print is above all an ideal channel for the production of on-demand marketing and advertising materials, business stationery and reports or conference documents, and as a system solution for direct end users.
<G-vec00213-002-s312><end.endkunden><de> Web2Print eignet sich vor allem für die Produktion bedarfsgerechter Marketing- und Werbedruckerzeugnisse, für Geschäftsausstattungen und -berichte, Tagungsunterlagen und als Systemlösung für den direkten Endkunden.
<G-vec00213-002-s313><end.endkunden><en> Time programs and scenes can be created by the end customer.
<G-vec00213-002-s313><end.endkunden><de> Zeitprogramme und Szenen können durch den Endkunden erstellt werden.
<G-vec00213-002-s314><end.endkunden><en> With its new online shop, LIQUI MOLY is for the first time also addressing end customers, adding a B2C orientation to its website.
<G-vec00213-002-s314><end.endkunden><de> Durch den neuen Onlineshop spricht LIQUI MOLY nun erstmals auch Endkunden an und erweitert so seine Onlinepräsenz um eine B2C-Ausrichtung.
<G-vec00213-002-s315><end.endkunden><en> Next was creating a user interface that is very intuitive, designed to help the end client easily withdraw data needed for regulatory compliance audits.
<G-vec00213-002-s315><end.endkunden><de> Danach wurde eine sehr intuitive Benutzeroberfläche erstellt, die dem Endkunden dabei helfen sollte, für regulatorische Compliance-Audits benötigte Daten einfach zu entnehmen.
<G-vec00213-002-s316><end.endkunden><en> Since 1995, Mannesmann Line Pipe has been organizing technical customer conferences which have quickly developed into a successful information platform for interested employees of public utilities, pipe-laying companies, engineering offices and end customers.
<G-vec00213-002-s316><end.endkunden><de> Seit 1995 führt Mannesmann Line Pipe Kundenfachtagungen durch, die sich schnell zu einer erfolgreichen Informationsplattform interessierter Mitarbeiter von Stadtwerken, Verlegeunternehmen, Ingenieurbüros und Endkunden entwickelt haben.
<G-vec00213-002-s317><end.endkunden><en> For this, we conduct deep research into real-life problems that end customers and farmers face in vertical and indoor farming software development.
<G-vec00213-002-s317><end.endkunden><de> Zu diesem Zweck führen wir tief greifende Untersuchungen zu realen Problemen durch, mit denen Endkunden und Landwirte bei der Softwareentwicklung für vertikale und Indoor-Landwirtschaft konfrontiert sind.
<G-vec00213-002-s318><end.endkunden><en> End customers need to activate their servers with Lenovo by providing the address of the server location to ensure coverage and service delivery for 4 or 8 Hour Service.
<G-vec00213-002-s318><end.endkunden><de> Endkunden müssen ihre Server bei Lenovo aktivieren, indem sie die Adresse des Serverstandorts angeben, um für die Verfügbarkeit und die Bereitstellung von 4-Stunden-Service zu sorgen.
<G-vec00213-002-s319><end.endkunden><en> A distributor is responsible for selling the product to end customers through the retailers and wholesalers.
<G-vec00213-002-s319><end.endkunden><de> Ein Distributor ist für den Verkauf des Produkts an Endkunden durch Einzelhändler und Großhändler verantwortlich.
<G-vec00213-002-s320><end.endkunden><en> Rogac produces exclusively for industrial clients who demand a professional and reliable partner for the ever increasing expectations of their end customers.
<G-vec00213-002-s320><end.endkunden><de> Rogac produziert exklusiv für Industriekunden, die einen professionellen und zuverlässigen Partner für die steigenden Erwartungen der Endkunden verlangen.
<G-vec00213-002-s321><end.endkunden><en> Needs are increasing The need for faster data transmission to network operators’ end customers is growing.
<G-vec00213-002-s321><end.endkunden><de> Der Bedarf an schneller Datenübertragung zu den Endkunden der Netzbetreiber wächst.
<G-vec00213-002-s322><end.endkunden><en> The ISO standard 9241-307 defines quality classes in this respect and thus ensures transparency with regard to the warranty and guarantee claims of end customers, dealers and wholesalers against manufacturers.
<G-vec00213-002-s322><end.endkunden><de> Die ISO-Norm 9241-307 legt diesbezüglich Qualitätsklassen fest und sorgt damit für Transparenz in Bezug auf Gewährleistungs- und Garantieansprüche von Endkunden, Händlern und Großhändlern gegenüber den Herstellern.
<G-vec00213-002-s494><end.landen><en> The pharmaceuticals we flush down the toilet end up in rivers and eventually into the oceans.
<G-vec00213-002-s494><end.landen><de> Die Arzneimittel, die wir in der Toilette hinunterspülen, landen in Flüssen und schließlich im Meer.
<G-vec00213-002-s495><end.landen><en> Second, we explain why certain groups of entrants and young employees might be more likely to end up in precarious jobs than others.
<G-vec00213-002-s495><end.landen><de> Dann wird gezeigt, warum einige Gruppen von Berufsanfängern und jungen Beschäftigten mit größerer Wahrscheinlichkeit in prekären Jobs landen als andere.
<G-vec00213-002-s496><end.landen><en> The nutrients stored in the plant are not really lost, but end up in biowaste, liquid manure and fermentation residues as well as in wastewater via the food chain.
<G-vec00213-002-s496><end.landen><de> Dabei gehen die in der Pflanze gespeicherten Nährstoffe nicht wirklich verloren, sondern landen über die Nahrungskette in Bioabfällen, Gülle und Gärresten sowie im Abwasser.
<G-vec00213-002-s497><end.landen><en> Many of them end up in prostitution and, according to human rights organizations, exploited under unimaginable conditions.
<G-vec00213-002-s497><end.landen><de> Viele von ihnen landen in der Prostitution und werden nach Aussagen von Menschenrechtsorganisationen unter unvorstellbaren Bedingungen ausgebeutet.
<G-vec00213-002-s498><end.landen><en> So a number of individuals win but lots of them end up on the losing side.
<G-vec00213-002-s498><end.landen><de> Daher ist eine Anzahl von Spielern zu gewinnen, aber viele von ihnen landen auf der Seite der Verlierer.
<G-vec00213-002-s499><end.landen><en> (My boss is on vacation, which means the strangest things happen at work right now and all of them end up on my desk *roles eyes*)
<G-vec00213-002-s499><end.landen><de> (Mein Chef ist gerade in Urlaub, da passieren grundsätzlich immer die wunderlichsten Dinge und alle landen sie bei mir *augenroll*)...
<G-vec00213-002-s500><end.landen><en> The Clark International Airport, which is located approximately 75 km further to the north, is mainly used to start and end domestic flights of low-cost airlines.
<G-vec00213-002-s500><end.landen><de> Am etwa 75 km weiter nördlich gelegenen Clark International Airport starten und landen hauptsächlich Inlandsflüge der Billigfluggesellschaften.
<G-vec00213-002-s501><end.landen><en> Please also check your spam folder, because unfortunately often answers from us end up there. Contact Form
<G-vec00213-002-s501><end.landen><de> Bitte kontrollieren Sie auch Ihren Spam Ordner da leider oft Antworten von uns dort landen.
<G-vec00213-002-s502><end.landen><en> Whether it is a VW Golf or Mazda MX5, they all have one thing in common; sooner or later they end up at the scrap yard.
<G-vec00213-002-s502><end.landen><de> Von VW Golf bis Mazda MX5, eines haben sie alle gemeinsam – früher oder später landen sie am Schrottplatz.
<G-vec00213-002-s503><end.landen><en> Since outdoor products are made for a very long service life, jackets with a PTFE membrane often do not end up with normal household waste.
<G-vec00213-002-s503><end.landen><de> Da Outdoor-Produkte ja für eine sehr lange Nutzungsdauer gemacht sind, landen Jacken mit PTFE-Membran häufig gar nicht im Restmüll.
<G-vec00213-002-s504><end.landen><en> The hope is that this trend will continue gathering momentum and that fewer valuable prototypes will end up plummeting into the Valley of Death.
<G-vec00213-002-s504><end.landen><de> Die Hoffnung ist groß, dass sich dieser Trend noch verstärkt und in Zukunft immer weniger der wertvollen Prototypen im Valley of Death landen.
<G-vec00213-002-s505><end.landen><en> Help to ensure that PET bottles no longer end up in the sea to save valuable raw materials.
<G-vec00213-002-s505><end.landen><de> Helfen Sie mit, dass PET-Flaschen nicht im Meer landen und damit wertvolle Rohstoffe eingespart werden können.
<G-vec00213-002-s506><end.landen><en> These particles accumulate in cleaning water, are emptied unfiltered into sink or toilette and end up in nature.
<G-vec00213-002-s506><end.landen><de> Diese Partikel sammeln sich beim Putzen im Schmutzwasser an, werden ungefiltert in Waschbecken oder Toiletten entleert und landen so in der Natur.
<G-vec00213-002-s507><end.landen><en> At the Bunker Trail and Etsch Trail, we will experience a lot of driving pleasure and end up at the end directly on the Reschensee, on the banks of which we comfortably reach the next ascent assistance, the Schönebenbahn.
<G-vec00213-002-s507><end.landen><de> Am Bunker Trail und Etsch Trail erfahren wir im Anschluss jede Menge Fahrspaß und landen am Ende direkt am Reschensee, an dessen Ufer wir gemütlich zur nächsten Aufstiegshilfe, der Schönebenbahn, gelangen.
<G-vec00213-002-s508><end.landen><en> When drug metabolites are in the blood, they'll end up in the blood vessels, including those in the head.
<G-vec00213-002-s508><end.landen><de> Die vom Körper verstoffwechselten Drogen werden in den Blutgefäßen und demnach auch auf dem Kopf landen.
<G-vec00213-002-s509><end.landen><en> We end up at the hotel Central, eat wild bear and will certainly soon be in our beds.
<G-vec00213-002-s509><end.landen><de> Wir landen im Hotel Central, gehen noch mal Wildschwein speisen und dann bestimmt bald ins Bett.
<G-vec00213-002-s510><end.landen><en> In cushions you end up a bit far behind and the sheath wants the nasal sling to swing short turns by itself, so it tends to almost shovel the snow in front of you if you take out the turns, almost flooding.
<G-vec00213-002-s510><end.landen><de> In Kissen landen Sie ein bisschen weit hinten und die Scheide möchte, dass die Nasalschlinge kurze Schwünge von selbst schwingt, so dass sie den Schnee fast vor sich hin schaufeln wird, wenn Sie die Wendungen herausnehmen, fast überschwemmen.
<G-vec00213-002-s511><end.landen><en> Many such particles, known as microplastics, end up in aquatic systems and eventually in the oceans.
<G-vec00213-002-s511><end.landen><de> Viele solcher als Mikroplastik bezeichneten Teilchen landen in aquatischen Systemen und schließlich in den Ozeanen.
<G-vec00213-002-s512><end.landen><en> Win-Win In a Win-Win scenario, both parties end up, at minimum, within their target ranges.
<G-vec00213-002-s512><end.landen><de> Win-Win In einem Win-Win-Szenario landen beide Parteien mindestens innerhalb ihrer Zielbereiche.
<G-vec00113-002-s228><end.enden><en> An intense and productive fishing activities has been developping around our harbour at the end of the Uso river; our fishermen provide the local restaurants with fresh fish from the Adriatic sea daily.
<G-vec00113-002-s228><end.enden><de> Auch der Hafen, am Ende des Flusses Uso, ist seit langer Zeit das Ergebnis der Hingabe und der schweren Arbeit der Seemänner, die frischen Fisch zu den lokalen Restaurants jeden Tag liefern.
<G-vec00113-002-s229><end.enden><en> At the end the rum tastes like bitter herbs and mild spices.
<G-vec00113-002-s229><end.enden><de> Am Ende schmeckt der Rum leicht pflanzlich und nach herben Kräutern.
<G-vec00113-002-s230><end.enden><en> Trotsky was assassinated before the end of the war, and Russia ended in the victorious camp alongside the “democracies”.
<G-vec00113-002-s230><end.enden><de> Trotzki wurde lange vor dem Ende des Krieges ermordet; Russland stand wieder auf der Seite der Gewinner, zusammen mit den "demokratischen" Ländern.
<G-vec00113-002-s231><end.enden><en> ‘But you can be sure that, at the end of your stay, if the balance is in your favour, it will be our pleasure - although it is, alas, a rather rare pleasure - to reimburse the difference.’
<G-vec00113-002-s231><end.enden><de> „Sie können sicher sein, dass, falls am Ende Ihres Aufenthaltes ein Überschuss zu Ihren Gunsten entsteht, wir Ihnen diesen mit (uns leider zu selten gegönntem) Vergnügen auszahlen werden.“ Greg beschloss, sich zu fügen.
<G-vec00113-002-s232><end.enden><en> After this, the storage system continues running until the end of its own life is reached (EOL/End of Life).
<G-vec00113-002-s232><end.enden><de> Danach läuft das Storage-System weiter bis es an das Ende seines eigenen Lebens gelangt (EOL/End of Life).
<G-vec00113-002-s233><end.enden><en> There is a link for termination of the newsletter at the end of each newsletter.
<G-vec00113-002-s233><end.enden><de> Einen Link zur Kündigung des Newsletters finden Sie am Ende eines jeden Newsletters.
<G-vec00113-002-s234><end.enden><en> A war that would bring those swinging sixties to an end.
<G-vec00113-002-s234><end.enden><de> Ein Krieg, der diese "Swinging Sixties" zu einem bitteren Ende bringen würde.
<G-vec00113-002-s235><end.enden><en> At the end of the day, your shoes need to be cleaned.
<G-vec00113-002-s235><end.enden><de> Am Ende eines Tages müssen Ihre Schuhe dann gereinigt werden.
<G-vec00113-002-s236><end.enden><en> In the end, they still don’t have a conclusion.
<G-vec00113-002-s236><end.enden><de> Am Ende haben sie trotzdem keine Schlussfolgerung.
<G-vec00113-002-s237><end.enden><en> The events of the downward spiral of the Euro weigh heavily: At the end of March 2014, decisions are expected on the legality of the OMT Programme and the ESM.
<G-vec00113-002-s237><end.enden><de> Die Ereignisse des Sinkflugs des Euro wiegen: Ende März 2014 werden Entscheidungen um die Rechtmäßigkeit des OMT-Programms und zur Rechtmäßigkeit des ESM erwartet.
<G-vec00113-002-s238><end.enden><en> At the end of the pier is also a haven for ships.
<G-vec00113-002-s238><end.enden><de> Am Ende des Piers ist auch ein Paradies für Schiffe.
<G-vec00113-002-s239><end.enden><en> The effect of the Pseudo Translation can be clearly seen in the comparative image above: Texts, which can be edited in memoQ, are labelled with # at the beginning and $ at the end.
<G-vec00113-002-s239><end.enden><de> Hier kann man im obigen Vergleichsbild sehr schön sehen, was die Pseudo Translations bewirkt: Texte, die in memoQ bearbeitet werden können sind mit # für den Anfang und $ für das Ende gekennzeichnet.
<G-vec00113-002-s240><end.enden><en> Follow the passage to a wooden board at the end.
<G-vec00113-002-s240><end.enden><de> Folgt dem Gang bis zu einem Brett am Ende.
<G-vec00113-002-s241><end.enden><en> * Players will now correctly receive a Battleground Mark message for the marks that are received at the end of a battle.
<G-vec00113-002-s241><end.enden><de> * Spieler erhalten nun am Ende einer Partie auf einem Schlachtfeld wie vorgesehen eine Meldung, die sie über den Erhalt einer Schlachtfeldmarke informiert.
<G-vec00113-002-s242><end.enden><en> Hrana do tja From city center: by trum N°3 to Kőbánya-Kispest Trum Station, after airplane bus to„ airplane D port” named busstop after go across the railway and there are a little street, and at the end of street there a big building named „Hertz” and there turn right, go 100m to the hotel.
<G-vec00113-002-s242><end.enden><de> Von der Stadtmitte: von Spektrum N ° 3 bis Kőbánya-Kispest Trum Station, nach Flugzeug-Bus zum "Flugzeug D-Port" genannt Bushaltestelle nach gehen über die Gleise und es gibt eine kleine Straße, und am Ende der Straße gibt es ein großes Gebäude namens "Hertz" und dort rechts abbiegen, fahren 100m bis zum Hotel.
<G-vec00113-002-s243><end.enden><en> But the new position did not put an end to his extensive travelling.
<G-vec00113-002-s243><end.enden><de> Der neue Dienst brachte aber kein Ende seiner vielen Reisen mit sich.
<G-vec00113-002-s244><end.enden><en> However, sometimes at the beginning or end of the MP3 file there are advertising jingles or a presenter's voice, these parts can be cut out with MP3 SPLTvery easily and without any quality loss.
<G-vec00113-002-s244><end.enden><de> Allerdings befinden sich am Anfang oder Ende der MP3 Datei manchmal noch Werbejingles oder eine Moderatorstimme, dieser Teil lässt sich mit Mp3-Splt sehr leicht und ohne Qualitätsverlust rausschneiden.
<G-vec00113-002-s245><end.enden><en> Modern infrastructure and modern rolling stock have been fulfilling even the most demanding requirements of visitors since the end of 2006.
<G-vec00113-002-s245><end.enden><de> Moderne Infrastrukturen und modernes Rollmaterial erfüllen seit Ende 2006 die gehobenen Ansprüche der Gäste.
<G-vec00113-002-s246><end.enden><en> In addition, cucumbers will be protected from parasites until the end of the growing season.
<G-vec00113-002-s246><end.enden><de> Darüber hinaus werden Gurken bis zum Ende der Vegetationsperiode vor Parasiten geschützt.
<G-vec00113-002-s247><end.enden><en> If sinners do not repent and believe the Gospel, they will surely end up here.
<G-vec00113-002-s247><end.enden><de> Wenn Sünder keine Buße tun und nicht an das Evangelium glauben, werden sie in der Hölle enden.
<G-vec00113-002-s248><end.enden><en> Blend the cream gently around the eyes and end by pressing the Qingming acupressure point.
<G-vec00113-002-s248><end.enden><de> Verteilen Sie diese mit sanftem Druck um das Auge und enden Sie an dem Akupressurpunkt Seimei.
<G-vec00113-002-s249><end.enden><en> We look down a long corridor and nobody knows where our gaze will end.
<G-vec00113-002-s249><end.enden><de> Wir schauen in einen langen Flur, niemand weiß, wo unser Blick enden wird.
<G-vec00113-002-s250><end.enden><en> The winter must never end with the shoe.
<G-vec00113-002-s250><end.enden><de> Mit dem Schuh darf der Winter nie enden.
<G-vec00113-002-s251><end.enden><en> David Lane hopes the brutality in China will end soon.
<G-vec00113-002-s251><end.enden><de> David Lane hofft, dass die Brutalität in China bald enden wird.
<G-vec00113-002-s252><end.enden><en> And, of course, the holiday should end with a sweet treat.
<G-vec00113-002-s252><end.enden><de> Und natürlich sollte der Urlaub mit einem süßen Leckerbissen enden.
<G-vec00113-002-s253><end.enden><en> Please consider for the installation: Loops with tensioning device and pull cords have to end at least 150 cm from the ground.
<G-vec00113-002-s253><end.enden><de> Bei Montage zu beachten: Die Schlaufe mit Spannvorrichtung und Zugschnüre enden mindestens 150 cm vom Boden entfernt.
<G-vec00113-002-s254><end.enden><en> The IELTS preparation courses at GLS take 1 week and end with the Academic IELTS test at the British Council.
<G-vec00113-002-s254><end.enden><de> Die IELTS Vorbereitungskurse bei GLS dauern 1 Woche und enden mit dem IELTS Academic Test am British Council.
<G-vec00113-002-s255><end.enden><en> To change where it starts or ends, drag the opaque object where you want the path to begin, or drag the transparent object where you want the path to end.
<G-vec00113-002-s255><end.enden><de> Um den Anfang oder das Ende des Pfads zu ändern, ziehen Sie das undurchsichtige Objekt an die Stelle, an der der Pfad beginnen soll, oder ziehen Sie das transparente Objekt an die Stelle, an der der Pfad enden soll.
<G-vec00113-002-s256><end.enden><en> Instead of winglets at the end of the wings, it is now only a slightly raked wing tip that ensures additional reductions in fuel consumption.As expected, it flies like a legendFlight qualityEvery pilot probably dreams about it: one day being able to fly the legendary Jumbo.
<G-vec00113-002-s256><end.enden><de> An den Enden der Flügel sorgt anstelle von Winglets nun eine nur leicht abgeknickte Spitze für zusätzliche Verbrauchsreduzierung.Fliegt sich gewohnt legendärFlugeigenschaftenWohl jeder Pilot träumt davon, einmal den legendären Jumbo fliegen zu können.
<G-vec00113-002-s257><end.enden><en> During the Potato Famine people would commit crimes so they would end up in this prison.
<G-vec00113-002-s257><end.enden><de> Während der Großen Hungersnot haben manche Menschen Verbrechen begangen, nur damit sie dadurch in diesem Gefängnis enden würden.
<G-vec00113-002-s258><end.enden><en> In any case, what can't be overemphasized here is that none of the tiny girls on this page need to end up as porn star.
<G-vec00113-002-s258><end.enden><de> Auf jeden Fall kann hier nicht genug betont werden, dass keines der winzigen Luder auf dieser Seite als Pornostar enden muss.
<G-vec00113-002-s259><end.enden><en> “Unique locations, amazing artists, après-ski in the pool, intense parties, which luckily end early, because tomorrow you have to get back on the pistes, because the spring snow won’t wait”.
<G-vec00113-002-s259><end.enden><de> „Einzigartige Locations, enthusiastische Künstler, Après-Ski am Pool und ausgelassene Partys, die glücklicherweise früh enden, denn am nächsten Tag geht es wieder auf die Pisten.
<G-vec00113-002-s260><end.enden><en> Our group courses always start on monday and end on friday.
<G-vec00113-002-s260><end.enden><de> Grundsätzlich starten unsere Gruppenkurse immer Montags und enden Freitags.
<G-vec00113-002-s261><end.enden><en> The news is disturbing; Creon returns with a message from the oracle saying that the plague will end when the murderer of Laius (former king of Thebes) is caught and expelled, and that the murderer is within the city.
<G-vec00113-002-s261><end.enden><de> Die Nachricht ist störend; Creon kehrt mit einer Botschaft aus dem Orakel zurück, die sagt, dass die Pest enden wird, wenn der Mörder von Laius (ehemaliger König von Theben) gefangen und vertrieben wird und dass der Mörder in der Stadt ist.
<G-vec00113-002-s262><end.enden><en> But this is precisely the criterion for sustainable success of cost reduction programs, which are in practice often setup too late or without specific reference to the value of the company and therefore regularly end with a boomerang effect: forced savings postulated under high pressure come back as disproportionate cost increases in later periods.
<G-vec00113-002-s262><end.enden><de> Doch gerade dadurch unterscheidet sich der nachhaltige Erfolg von Kostensenkungsprogrammen, die in der Praxis oft zu spät oder ohne konkreten Bezug zur Wertschöpfung des Unternehmens aufgesetzt werden und damit oft mit einem Bumerang-Effekt enden: Unter hohem Druck erzwungene Einsparungen kommen als überproportionale Kostensteigerungen in späteren Perioden zurück.
<G-vec00113-002-s263><end.enden><en> Especially when they end this time together, they will have a very nice harmony.
<G-vec00113-002-s263><end.enden><de> Besonders wenn sie dieses Mal zusammen enden, haben sie eine sehr schöne Harmonie.
<G-vec00113-002-s264><end.enden><en> Sioen sells technical products, primarily to businesses and to governmental and quasi-governmental institutions — police, fire services, emergency services —, although certain products, such as garments and colouring solutions, end up in retail stores under other brand names.
<G-vec00113-002-s264><end.enden><de> Sioen verkauft technische Produkte, vordergründig an Unternehmen und staatliche sowie fast-staatliche Einrichtungen - Polizei, Feuerwehr, Rettungswesen -, obwohl bestimmte Produkte, wie Kleidungsstücke und Einfärbelösungen, in Einzelhandelsgeschäften unter anderen Markennamen enden.
<G-vec00113-002-s265><end.enden><en> It consists of several metal rods, which are joined end-to-end by rings to form a flexible chain.
<G-vec00113-002-s265><end.enden><de> Sie besteht aus mehreren Metall-Gestängen, deren Enden mit Ringen verbunden sind und somit eine flexible Kette bilden.
