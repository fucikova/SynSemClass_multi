<G-vec00389-002-s019><destroy.abbrechen><en> 14:57 Some stood up and gave this false testimony against him: 5 14:58 “We heard him say, ‘I will destroy this temple made with hands and in three days build another not made with hands.’”
<G-vec00389-002-s019><destroy.abbrechen><de> 57Und etliche standen auf und gaben falsches Zeugnis wider ihn und sprachen: 58Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s020><destroy.abbrechen><en> But last of all 2 false witnesses came forward, 61 and said, "This Man said, 'I am able to destroy the Temple of God, and to rebuild it after 3 days.'
<G-vec00389-002-s020><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen, und sprachen: Er hat gesagt: Ich kann den Tempel Gottes abbrechen, und in drei Tagen denselben bauen.
<G-vec00389-002-s021><destroy.abbrechen><en> 14:58 "We heard him say, 'I will destroy this man-made temple and in three days will build another, not made by man.' "
<G-vec00389-002-s021><destroy.abbrechen><de> 14:58 Wir haben gehört, daß er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s022><destroy.abbrechen><en> 58 We heard him say, I will destroy this temple that is made with hands, and within three days I will build another made without hands.
<G-vec00389-002-s022><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen 61 und sprachen: Er hat gesagt: Ich kann den Tempel Gottes abbrechen und in drei Tagen ihn bauen.
<G-vec00389-002-s023><destroy.abbrechen><en> "We heard him say, 'I will destroy this temple that is made with hands, and in three days I will build another made without hands.'"
<G-vec00389-002-s023><destroy.abbrechen><de> Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s024><destroy.abbrechen><en> In front of Christ hanging on the Cross some people, taunting him, referred to these same words: "You who would destroy the temple and build it in three days, save yourself!" (Mt 27: 40).
<G-vec00389-002-s024><destroy.abbrechen><de> Vor dem am Kreuz hängenden Christus beziehen sich Spötter auf das gleiche Wort und rufen ihm zu: „Der du den Tempel abbrechen und in drei Tagen wieder aufbauen kannst, rette dich selbst“ (Mt 27, 40).
<G-vec00389-002-s027><destroy.abbrechen><en> 57 And some stood up and bore false witness against him, saying, 58 “We heard him say, ‘I will destroy this temple that is made with hands, and in three days I will build another, not made with hands.’”
<G-vec00389-002-s027><destroy.abbrechen><de> Und einige standen auf und gaben falsches Zeugnis ab gegen ihn und sprachen: Wir haben gehört, daß er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s028><destroy.abbrechen><en> Finally, two men came forward 61 who declared, "This man said, 'I am able to destroy the Temple of God and rebuild it in three days.'"
<G-vec00389-002-s028><destroy.abbrechen><de> Zuletzt traten herzu zwei falsche Zeugen 61 und sprachen: Er hat gesagt: Ich kann den Tempel GOttes abbrechen und in dreien Tagen denselben bauen.
<G-vec00389-002-s029><destroy.abbrechen><en> 57Some stood up and began to give false testimony against Him, saying, 58“We heard Him say, ‘I will destroy this temple made with hands, and in three days I will build another made without hands.’”
<G-vec00389-002-s029><destroy.abbrechen><de> 14:57 Und etliche standen auf und gaben falsches Zeugnis wider ihn und sprachen: 14:58 Wir hörten ihn sagen: Ich werde diesen Tempel, der mit Händen gemacht ist, abbrechen, und in drei Tagen werde ich einen anderen aufbauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s030><destroy.abbrechen><en> 58 “We heard him say, ‘I will destroy this temple made with human hands and in three days will build another, not made with hands.’ ”
<G-vec00389-002-s030><destroy.abbrechen><de> 58 Wir haben gehört, dass er gesagt hat: Ich will diesen Tempel, der mit Händen gemacht ist, abbrechen und in drei Tagen einen andern bauen, der nicht mit Händen gemacht ist.
<G-vec00389-002-s031><destroy.auflösen><en> “Do not think that I came to destroy the law or the prophets.
<G-vec00389-002-s031><destroy.auflösen><de> Ihr sollt nicht meinen, das ich gekommen sei, um das Gesetz oder die Propheten aufzulösen.
<G-vec00389-002-s032><destroy.auflösen><en> In his sermon on the mount he declared: "Think not that I am come to destroy the law or the prophets; I am not come to destroy, but to fulfill.
<G-vec00389-002-s032><destroy.auflösen><de> In der Bergpredigt sagt er: „Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s034><destroy.auflösen><en> Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil.
<G-vec00389-002-s034><destroy.auflösen><de> Ihr sollt nicht meinen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s036><destroy.auflösen><en> 17 Don't think that I came to destroy the law or the prophets. I didn't come to destroy, but to fulfill.
<G-vec00389-002-s036><destroy.auflösen><de> 17 Meint nicht, daß ich gekommen sei, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s038><destroy.auflösen><en> I am not come to destroy, but to fulfil.
<G-vec00389-002-s038><destroy.auflösen><de> Ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s039><destroy.auflösen><en> ●WATER: Select 1 Spell/Trap Card on the field, and destroy it.
<G-vec00389-002-s039><destroy.auflösen><de> Diese Karte muss offen auf dem Spielfeld liegen, um diesen Effekt zu aktivieren und aufzulösen.
<G-vec00389-002-s040><destroy.auflösen><en> Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfill.
<G-vec00389-002-s040><destroy.auflösen><de> Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s042><destroy.auflösen><en> ”17 Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfil.
<G-vec00389-002-s042><destroy.auflösen><de> „17 Ihr sollt nicht meinen, dass ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s044><destroy.auflösen><en> I am not come to destroy, but to fulfill. For verily I say unto you, till heaven and earth pass, one jot or one tittle shall in no wise pass from the law, till all be fulfilled.”
<G-vec00389-002-s044><destroy.auflösen><de> Bis Himmel und Erde vergehen... Dann wies mich der Mann auf einen Text hin: "Ihr sollt nicht meinen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s045><destroy.auflösen><en> 5.17 Ne Think not that I am come to destroy the law, or the prophets: I am not come to destroy, but to fulfill.
<G-vec00389-002-s045><destroy.auflösen><de> 5:16 Ihr sollt nicht wähnen, daß ich gekommen bin, das Gesetz oder die Propheten aufzulösen; ich bin nicht gekommen, aufzulösen, sondern zu erfüllen.
<G-vec00389-002-s109><destroy.löschen><en> If you have received it in error, please return it to the sender and destroy the message and/or copies in your possession.
<G-vec00389-002-s109><destroy.löschen><de> Falls Sie im Besitz von Irrläufern sind, senden Sie diese Nachrichten bitte zurück und löschen Sie die Nachricht und/oder Kopien, die in Ihrem Besitz sind.
<G-vec00389-002-s110><destroy.löschen><en> Caution - Be very careful when you destroy a pool.
<G-vec00389-002-s110><destroy.löschen><de> Achtung - Seien Sie beim Löschen von Pools äußerst vorsichtig.
<G-vec00389-002-s111><destroy.löschen><en> Warning: Make sure you use the correct drive letter as the output target, or you may overwrite and destroy existing data.
<G-vec00389-002-s111><destroy.löschen><de> Warnung: Stellen Sie unbedingt sicher, dass Sie im folgenden Schritt den korrekten Laufwerkbuchstaben für Ihren USB-Stick angeben, da Sie ansonsten unbeabsichtigt Daten löschen könnten.
<G-vec00389-002-s112><destroy.löschen><en> Therefore, you have the possibility to refuse or destroy them.
<G-vec00389-002-s112><destroy.löschen><de> Da Sie auf jeden Fall die Kontrolle über die Cookies haben, können Sie diese ablehnen oder löschen.
<G-vec00389-002-s113><destroy.löschen><en> When this period has expired BVBA Kasteel Brouwerij Vanhonsebrouck will destroy or anonymize all your personal data.
<G-vec00389-002-s113><destroy.löschen><de> Nach Ablauf dieser Frist wird BVBA Kasteel Brouwerij Vanhonsebrouck alle Ihre persönlichen Daten löschen oder anonymisieren.
<G-vec00389-002-s114><destroy.löschen><en> In such event, you must destroy all copies of the Software Product and any component parts.
<G-vec00389-002-s114><destroy.löschen><de> In diesem Fall müssen Sie alle Kopien des Softwareprodukts sowie aller zugehörigen Einzelkomponenten unwiderruflich löschen.
<G-vec00389-002-s115><destroy.löschen><en> Since the EU – the model of the NWO one world state – has long ago decided to destroy and here the white race and make Europeans multicultural nongrels (Coudenhove Khalergi and Nicolas Sarkozy) the EU must do something to pull the wool over the eyes of white EU citizens.
<G-vec00389-002-s115><destroy.löschen><de> Da die EU – das Modell des NWO-Eine-Weltstaats – sich schon vor langer Zeit beschlossen hat, die weiße Rasse zu löschen und hier und somit die Europäer zu Vielvölker-Mischlingen zu machen (Coudenhove Khalergi und Nicolas Sarkozy), muss die EU etwas tun, um den weißen EU-Bürgern inzwischen einen blauen Dunst vorzumachen.
<G-vec00389-002-s116><destroy.löschen><en> Generally speaking, the goal isn’t to permanently damage or destroy your files or even to steal your identity, but to convince you to pay for the decryption key.
<G-vec00389-002-s116><destroy.löschen><de> Das Ziel ist im Allgemeinen nicht, Deine Daten zu beschädigen oder zu löschen, und auch nicht, Deine Identität zu stehlen, sondern Dich zur Zahlung für die Herausgabe des Entschlüsselungsschlüssels zu bewegen.
<G-vec00389-002-s117><destroy.löschen><en> In particular, you agree that you will not use the Site to send or upload any material containing software, viruses or other codes, programs or files designed to interrupt, destroy, damage or limit the functionality of any computer software, hardware or telecommunications equipment or in any other manner which would interfere with or disrupt the Site.
<G-vec00389-002-s117><destroy.löschen><de> Insbesondere sind Sie damit einverstanden, diese Seite nicht zum Versenden oder Hochladen von Material zu verwenden, das Software, Viren oder sonstige Codes, Programme oder Dateien enthält, die dazu vorgesehen sind, die Funktionsfähigkeit von Computersoftware, Hardware oder Telekommunikationsanlagen zu stören, zu löschen, zu beschädigen oder einzuschränken oder auf andere Weise zu verwenden, die diese Seite beeinträchtigen oder zum Erliegen bringen würde.
<G-vec00389-002-s118><destroy.löschen><en> Make sure that you have permission to create or destroy any temporary files.
<G-vec00389-002-s118><destroy.löschen><de> Stellen Sie sicher, dass Sie zum Erstellen und Löschen temporärer Dateien berechtigt sind.
<G-vec00389-002-s119><destroy.löschen><en> In this case, the only option is to destroy the pool and re-create the configuration, restoring your data in the process.
<G-vec00389-002-s119><destroy.löschen><de> In einem solchen Fall besteht nur die Möglichkeit, den Pool zu löschen, die Konfiguration neu zu erstellen und die Daten aus einer Sicherungskopie wiederherzustellen.
<G-vec00389-002-s120><destroy.löschen><en> If you are not an intended recipient, please contact the sender by reply email and destroy the original message and any copies of the message as well as any attachments to the original message.
<G-vec00389-002-s120><destroy.löschen><de> Falls Sie nicht der angegebene Empfänger sind oder falls diese E-Mail irrtümlich an Sie adressiert wurde, benachrichtigen Sie uns bitte sofort durch Antwort-E-Mail und löschen Sie diese E-Mail nebst etwaigen Anlagen von Ihrem System.
<G-vec00389-002-s164><destroy.töten><en> Mat 27:20 But the chief priests and elders persuaded the multitude that they should ask Barabbas, and destroy Jesus.
<G-vec00389-002-s164><destroy.töten><de> 20 Allein die Oberpriester und Ältesten beredeten die Volksmassen, den Barabbas loszubitten, Jesus aber töten zu lassen.
<G-vec00389-002-s165><destroy.töten><en> There are armies of aliens in Derp that will follow you to destroy all the humans and capture the territory.
<G-vec00389-002-s165><destroy.töten><de> Abgesehen von den Horden Aliens, die dir folgen und die versuchen, alle Menschen zu töten und das Gebiet einzunehmen.
<G-vec00389-002-s166><destroy.töten><en> Joseph's brothers went down into Egypt, driven by a devastating famine (Gn 42:1-3); the people of Judah, defeated in war, were "taken into exile out of their land" (2 K 25:21); Joseph took Jesus and his mother and fled by night to Egypt because king Herod was searching for the child to destroy him (cf.
<G-vec00389-002-s166><destroy.töten><de> Die Brüder Josefs gingen hinunter nach Ägypten (Gen 42, 1–3), durch eine verheerende Hungersnot gedrängt; der Stamm Juda, im Krieg besiegt, wurde „von seiner Heimat“ weg in die Verbannung geführt (2 Kön 25, 21); Josef nahm Jesus und seine Mutter und floh in der Nacht nach Ägypten, „denn Herodes wird das Kind suchen, um es zu töten“ (Mt 2, 13–15); „An jenem Tag brach eine schwere Verfolgung über die Kirche in Jerusalem herein.
<G-vec00389-002-s167><destroy.töten><en> The Sith unleashed a torrent of Force lightning upon the Jedi, determined to destroy him for this outrage.
<G-vec00389-002-s167><destroy.töten><de> Der Sith beschoss den Jedi mit einer Kanonade von Machtblitzen und war entschlossen, ihn für diesen Frevel zu töten.
<G-vec00389-002-s168><destroy.töten><en> 13 And when they were departed, behold, the angel of the Lord appeareth to Joseph in a dream, saying, Arise, and take the young child and his mother, and flee into Egypt, and be thou there until I bring thee word: for Herod will seek the young child to destroy him.
<G-vec00389-002-s168><destroy.töten><de> 13 Und als sie fortgingen, siehe, da erschien der Engel des Herrn Joseph im Traum und sprach: Stehe auf, nimm das Kindlein und seine Mutter und fliehe nach Ägypten und sei dort, bis ich dir das Wort bringe: denn Herodes wird das junge Kind suchen, um es zu töten.
<G-vec00389-002-s169><destroy.töten><en> A newborn army also appeared in Eclipse, created by a vengeful vampire named Victoria to destroy the Cullen coven and Bella Swan.
<G-vec00389-002-s169><destroy.töten><de> Eine neugeborene Armee erschien auch in Eclipse, erschaffen von einem rachsüchtigen Vampir namens Victoria, um den Cullen-Zirkel und Bella Swan zu töten.
<G-vec00389-002-s170><destroy.töten><en> 24 For Haman the Agagite, the son of Hammedatha, the enemy of all the Jews, had plotted against the Jews to destroy them, and had cast Pur (that is, cast lots), to crush and to destroy them.
<G-vec00389-002-s170><destroy.töten><de> 24 Haman, der Sohn Hammedatas aus Agag, der Feind aller Juden, hatte die Ausrottung der Juden geplant und das 'Pur', das ist das Los werfen lassen, um sie zu töten und zu vernichten.
<G-vec00389-002-s171><destroy.töten><en> As part of the body's immune response mechanism, NK cells have the ability to destroy virus-infected cells & tumour cells.
<G-vec00389-002-s171><destroy.töten><de> Bei den NK-Zellen handelt es sich um einer Untergruppe der weißen Blutzellen, die in der Lage sind, entartete Zellen wie Tumorzellen, Tumorstammzellen und virusinfizierte Zellen zu erkennen und zu töten.
<G-vec00389-002-s172><destroy.töten><en> But Jehu did it with cunning in order to destroy the worshipers of Baal.
<G-vec00389-002-s172><destroy.töten><de> Sein Plan war, alle Diener Baals zu töten.
<G-vec00389-002-s173><destroy.töten><en> When the white blood cells determine how to destroy it, they create "memory cells" to handle future attacks of that same pathogen.
<G-vec00389-002-s173><destroy.töten><de> Wenn die weißen Blutzellen einen Weg gefunden haben, die Bakterien zu töten, werden Gedächtniszellen gebildet, um zukünftigen Infektionen mit den gleichen Bakterien effizient begegnen zu können.
<G-vec00389-002-s174><destroy.töten><en> Oblivion is a zombie game, in which you will have to destroy all zombies.
<G-vec00389-002-s174><destroy.töten><de> In diesem Spiel machst du dein eigenes Gerät, mit dem du die Zombies töten musst.
<G-vec00389-002-s175><destroy.töten><en> That was the occasion of another message from an angel of the Lord to Joseph in a dream: “Arise and take the Child and His mother, and flee to Egypt, and remain there until I tell you; for Herod is going to search for the Child to destroy Him” (Matt. 2:13).
<G-vec00389-002-s175><destroy.töten><de> Wir lesen dort: „Als die Sterndeuter wieder gegangen waren, erschien dem Josef im Traum ein Engel des Herrn und sagte: Steh auf, nimm das Kind und seine Mutter, und flieh nach Ägypten; dort bleibe, bis ich dir etwas anderes auftrage; denn Herodes wird das Kind suchen, um es zu töten“ (Mt 2,13).
<G-vec00389-002-s176><destroy.töten><en> Forms part of an elite unit whose objective is to destroy terrorists.
<G-vec00389-002-s176><destroy.töten><de> Teil einer Elite-Einheit, deren Ziel es ist, Terroristen zu töten.
<G-vec00389-002-s177><destroy.töten><en> “The Lord will destroy him with the breath of His mouth and will annihilate him with His glorious appearance at His coming.” (2 Thessalonians 2,8)
<G-vec00389-002-s177><destroy.töten><de> Jesus, der Herr, wird ihn durch den Hauch seines Mundes töten und durch seine Ankunft und Erscheinung vernichten” (2 Thessalonicher 2,8)”.
<G-vec00389-002-s178><destroy.töten><en> It was his personal intent to destroy as many of them as he could, and one way was to wipe out as many prisoners of war as possible.
<G-vec00389-002-s178><destroy.töten><de> Es war seine persönliche Absicht, so viele von ihnen zu töten, wie er konnte, und ein Weg dazu, sie auszulöschen, war, so viele Kriegsgefangene wie möglich zu machen und sie so auszulöschen.
<G-vec00389-002-s179><destroy.töten><en> Military theory gave them the necessary discipline of thought, but did not destroy the audacity awakened by the dramatic operations of the civil war.
<G-vec00389-002-s179><destroy.töten><de> Die Kriegstheorie hat ihnen die notwendige Denkdisziplin vermittelt, ohne aber ihren in den dramatischen Operationen des Bürgerkriegs geweckten Wagemut zu töten.
<G-vec00389-002-s180><destroy.töten><en> Destroy 40 units with a single unit in a single League game. More Achievements
<G-vec00389-002-s180><destroy.töten><de> Töten Sie in “In der Höhle des Löwen" auf “Schwer” 50 Einheiten mit einem einzigen Schuss Durchschlagsmunition.
<G-vec00389-002-s181><destroy.töten><en> Hera was furiously jealous of this and sent two snakes to destroy the infants.
<G-vec00389-002-s181><destroy.töten><de> Hera war auf dieses Kind fürchterlich eifersüchtig und sie schickte zwei Schlangen, um Herakles zu töten.
<G-vec00389-002-s182><destroy.töten><en> 13 As soon as they had gone, an angel of the Lord appeared to Joseph in a dream, and said, “Rise up, take with thee, the child and his mother, and flee to Egypt; there remain, until I give thee word. For Herod will soon be making search for the child, to destroy him.”
<G-vec00389-002-s182><destroy.töten><de> 13 Als die Sterndeuter wieder gegangen waren, erschien dem Josef im Traum ein Engel des Herrn und sagte: Steh auf, nimm das Kind und seine Mutter, und flieh nach Ägypten; dort bleibe, bis ich dir etwas anderes auftrage; denn Herodes wird das Kind suchen, um es zu töten.
<G-vec00389-002-s202><destroy.umbringen><en> As we do not want to destroy our saw, we decided not to saw the steel frame.
<G-vec00389-002-s202><destroy.umbringen><de> Da wir unsere Säge nicht auch noch umbringen wollten, haben wir auf das Zersägen des Rohrrahmens verzichtet.
<G-vec00389-002-s203><destroy.umbringen><en> On account of these things the Jews, having seized me in the temple, attempted to lay hands on and destroy me.
<G-vec00389-002-s203><destroy.umbringen><de> Allein deswegen haben mich die Juden im Tempel ergriffen, und deswegen wollen sie mich umbringen.
<G-vec00389-002-s204><destroy.umbringen><en> 14 But the Pharisees went out and conspired against him, how to destroy him. God’s Chosen Servant
<G-vec00389-002-s204><destroy.umbringen><de> 14 Da gingen die Pharisäer hinaus und hielten Rat gegen ihn, wie sie ihn umbringen könnten.
<G-vec00389-002-s205><destroy.umbringen><en> 10 Their fruit shall you destroy from the earth, and their seed from among the children of men.
<G-vec00389-002-s205><destroy.umbringen><de> 11 Ihre Frucht wirst du umbringen vom Erdboden und ihren Samen von den Menschenkindern.
<G-vec00389-002-s206><destroy.umbringen><en> 10 You will destroy their descendants from the eretz, Their posterity from among the children of men.
<G-vec00389-002-s206><destroy.umbringen><de> 10 Ihre Frucht wirst du umbringen vom Erdboden und ihren Samen von den Menschenkindern.
<G-vec00389-002-s207><destroy.umbringen><en> He will come and destroy the cultivators, and will give the vineyard to others.
<G-vec00389-002-s207><destroy.umbringen><de> Kommen wird er, die Winzer umbringen und den Weinberg andern geben.
<G-vec00389-002-s208><destroy.umbringen><en> Their fruit will you destroy from the earth, and their seed from among the children of men.
<G-vec00389-002-s208><destroy.umbringen><de> KJV + EL = Ps 21,10 Ihre Frucht wirst du umbringen vom Erdboden und ihren Samen von den Menschenkindern.
<G-vec00389-002-s209><destroy.umbringen><en> He will come and destroy the tenants and give the vineyard to others.
<G-vec00389-002-s209><destroy.umbringen><de> Er wird kommen und die WeingärtnerWeingärtner umbringen und den WeinbergWeinberg anderen geben.
<G-vec00389-002-s210><destroy.umbringen><en> 41 They say to him, He will miserably destroy those wicked men, and will let out his vineyard to other farmers, which shall render him the fruits in their seasons.
<G-vec00389-002-s210><destroy.umbringen><de> 41 Sie sagen zu ihm: Er wird jene Übeltäter übel umbringen, und den Weinberg wird er an andere Weingärtner verdingen, die ihm die Früchte abgeben werden zu ihrer Zeit.
<G-vec00389-002-s211><destroy.umbringen><en> 12:17 But if they will not obey, I will utterly pluck up and destroy that nation, says the Jehovah.
<G-vec00389-002-s211><destroy.umbringen><de> 12:17 Wo sie aber nicht hören wollen, so will ich solches Volk ausreißen und umbringen, spricht der HERR.
<G-vec00389-002-s212><destroy.umbringen><en> 49:38 And I will set my throne in Elam, and destroy kings and princes from thence, saith the Lord.
<G-vec00389-002-s212><destroy.umbringen><de> 49:38 Meinen Stuhl will ich in Elam setzen und will beide, den König und die Fürsten, daselbst umbringen, spricht der HERR.
<G-vec00389-002-s213><destroy.umbringen><en> 13 He will stretch out his hand against the north and destroy Assyria, leaving Nineveh utterly desolate and dry as the desert.
<G-vec00389-002-s213><destroy.umbringen><de> 13 Und er wird seine Hand ausstrecken nach Norden und Assur umbringen.
<G-vec00389-002-s214><destroy.umbringen><en> 13and letters to be sent by the hand of the runners unto all provinces of the king, to cut off, to slay, and to destroy all the Jews, from young even unto old, infant and women, on one day, on the thirteenth of the twelfth month -- it [is] the month of Adar -- and their spoil to seize,
<G-vec00389-002-s214><destroy.umbringen><de> 13 Und die Schreiben wurden gesandt durch die Läufer in alle Provinzen des Königs, man sollte vertilgen, töten und umbringen alle Juden, Jung und Alt, Kinder und Frauen, auf einen Tag, nämlich am dreizehnten Tag des zwölften Monats, das ist der Monat Adar, und ihr Hab und Gut plündern.
<G-vec00389-002-s215><destroy.umbringen><en> 17 But if they will not obey, then I will utterly pluck up and destroy this people, says the LORD.
<G-vec00389-002-s215><destroy.umbringen><de> 17 Wo sie aber nicht hören wollen, so will ich solches Volk ausreißen und umbringen, spricht der HERR.
<G-vec00389-002-s216><destroy.umbringen><en> 18 The chief priests and the scribes heard it, and sought how they might destroy him. For they feared him, for all the multitude was astonished at his teaching.
<G-vec00389-002-s216><destroy.umbringen><de> 18 Als die Oberpriester und die Schriftgelehrten dies hörten, trachteten sie, wie sie ihn umbringen könnten; sie hatten nämlich Furcht vor ihm; denn das ganze Volk war erstaunt über seine Lehre.
<G-vec00389-002-s217><destroy.umbringen><en> 18 And the chief priests and the scribes heard it and sought a way to destroy him; for they feared him, because all the multitude was astonished at his teaching.
<G-vec00389-002-s217><destroy.umbringen><de> Und die Hohenpriester und die Schriftgelehrten hörten es und suchten, wie sie ihn umbringen könnten; sie fürchteten ihn nämlich, denn die ganze Volksmenge geriet außer sich über seine Lehre.
<G-vec00389-002-s218><destroy.umbringen><en> The chief priests and the scribes and the principal men of the people were seeking to destroy him, 48 but they did not find anything they could do, for all the people were hanging on his words.
<G-vec00389-002-s218><destroy.umbringen><de> 18 Und die Schriftgelehrten und die Hohenpriester hörten es und suchten, wie sie ihn umbringen könnten; denn sie fürchteten ihn, weil alles Volk staunte über seine Lehre.
<G-vec00389-002-s219><destroy.umbringen><en> He shall come and destroy the farmers, and give the vineyard to others.
<G-vec00389-002-s219><destroy.umbringen><de> Er wird kommen und die Weingärtner umbringen und den Weinberg anderen geben.
<G-vec00389-002-s220><destroy.umbringen><en> If you leave the Lord, and serve strange gods, he will turn, and will afflict you, and will destroy you after all the good he hath done you.
<G-vec00389-002-s220><destroy.umbringen><de> Wenn ihr aber den HERRN verlaßt und fremden Göttern dient, so wird er sich wenden und euch plagen und euch umbringen, nachdem er euch Gutes getan hat.
<G-vec00389-002-s240><destroy.verderben><en> I will recall the covenant I have made between me and you and all living beings, so that the waters shall never again become a flood to destroy all mortal beings.
<G-vec00389-002-s240><destroy.verderben><de> 15 Alsdann will ich gedenken an meinen Bund zwischen mir und euch und allen lebendigen Seelen in allerlei Fleisch, daß nicht mehr hinfort eine Sintflut komme, die alles Fleisch verderbe.
<G-vec00389-002-s241><destroy.verderben><en> 11 And I will establish My covenant with you: never again shall all flesh die by the water of the flood, and never again shall there be a flood of water to destroy all the earth.
<G-vec00389-002-s241><destroy.verderben><de> 11 Und richte meinen Bund also mit euch auf, daß hinfort nicht mehr alles Fleisch verderbt werden soll mit dem Wasser der Sintflut, und soll hinfort keine Sintflut mehr kommen, die die Erde verderbe.
<G-vec00389-002-s242><destroy.verderben><en> {9:11} I will establish my covenant with you, and no longer will all that is flesh be put to death by the waters of a great flood, and, henceforth, there will not be a great flood to utterly destroy the earth.”
<G-vec00389-002-s242><destroy.verderben><de> »Und ich richte meinen Bund so mit euch auf, daß hinfort nicht mehr alles Fleisch verderbt werden soll durch die Wasser der Sintflut und hinfort keine Sintflut mehr kommen soll, die die Erde verderbe.« Der Bund geht immer von Gott aus, und er gibt auch ein Zeichen des Bundes.
<G-vec00389-002-s245><destroy.verderben><en> and I will remember my covenant, which is between me and you and every living creature of all flesh; and the waters shall no more become a flood to destroy all flesh.
<G-vec00389-002-s245><destroy.verderben><de> 15Alsdann will ich gedenken an meinen Bund zwischen mir und euch und allem lebendigen Getier unter allem Fleisch, dass hinfort keine Sintflut mehr komme, die alles Fleisch verderbe.
<G-vec00389-002-s246><destroy.verderben><en> You must cease from [opposing] God, who [is] with me, so that He does not destroy you.
<G-vec00389-002-s246><destroy.verderben><de> Laß ab von deinem Widerstand gegen Gott, der mit mir ist, damit er dich nicht verderbe.
<G-vec00389-002-s247><destroy.verderben><en> 14 And I will dash them one against another, even the fathers and the sons together, says LORD. I will not pity, nor spare, nor have compassion, that I should not destroy them.
<G-vec00389-002-s247><destroy.verderben><de> 14 Und ich werde sie zerschmettern einen gegen den anderen, die Väter und die Kinder allzumal, spricht Jahwe; ich werde nicht Mitleid haben, noch schonen, noch mich erbarmen, dass ich sie nicht verderbe.
<G-vec00389-002-s248><destroy.verderben><en> [13] And the blood shall be to you for a token upon the houses where you are: and when I see the blood, I will pass over you, and the plague shall not be upon you to destroy you, when I smite the land of Egypt.
<G-vec00389-002-s248><destroy.verderben><de> 13 Und das Blut soll euer Zeichen sein an den Häusern, darin ihr seid, daß, wenn ich das Blut sehe, an euch vorübergehe und euch nicht die Plage widerfahre, die euch verderbe, wenn ich Ägyptenland schlage.
<G-vec00389-002-s249><destroy.verderben><en> 11I will rebuke the devourer for you, so that it will not destroy the fruits of your soil, and your vine in the field shall not fail to bear, says the Lord of hosts.
<G-vec00389-002-s249><destroy.verderben><de> 11Und ich werde um euretwillen den Fresser schelten, daß er euch die Frucht des Bodens nicht verderbe; und der Weinstock auf dem Felde wird euch nicht mehr fehltragen, spricht Jehova der Heerscharen.
<G-vec00389-002-s250><destroy.verderben><en> 15 H2142 [H8804] And I will remember H1285 my covenant H2416, which is between me and you and every living H5315 creature H1320 of all flesh H4325; and the waters H5750 shall no more H3999 become a flood H7843 [H8763] to destroy H1320 all flesh.
<G-vec00389-002-s250><destroy.verderben><de> 15 H2142 Alsdann will ich gedenken H1285 an meinen Bund H2416 zwischen mir und euch und allen lebendigen H5315 Seelen H1320 in allerlei Fleisch H5750, daß nicht mehr H3999 H4325 hinfort eine Sintflut H1320 komme, die alles Fleisch H7843 verderbe .
<G-vec00389-002-s308><destroy.vernichten><en> Aegwynn attacked the avatar, but the dark Titan held back so as to let her destroy his physical form.
<G-vec00389-002-s308><destroy.vernichten><de> Doch der Dunkle Titan hatte sich zurückgehalten und ließ zu, dass sein Körper vernichtet wird.
<G-vec00389-002-s309><destroy.vernichten><en> You must not knowingly destroy or discard information that is subject to a legal hold.
<G-vec00389-002-s309><destroy.vernichten><de> Informationen, die einer rechtlichen Sperrfrist unterliegen, dürfen nicht wissentlich vernichtet oder weggeworfen werden.
<G-vec00389-002-s310><destroy.vernichten><en> Please destroy Tiamat's Shelter completely.
<G-vec00389-002-s310><destroy.vernichten><de> Bitte vernichtet Tiamats Unterschlupf vollständig.
<G-vec00389-002-s311><destroy.vernichten><en> Or the heavy oil from the cruise ships that haunt us every week will destroy the last coral forests beforehand.
<G-vec00389-002-s311><destroy.vernichten><de> Oder das Schweröl der Kreuzfahrtschiffe, die uns jede Woche heimsuchen, vernichtet schon vorher die letzten Korallenwälder.
<G-vec00389-002-s312><destroy.vernichten><en> Destroy all your clones and create a rift in the space-time continuum.
<G-vec00389-002-s312><destroy.vernichten><de> Vernichtet alle Euer Klone und erschafft einen Riss im Raum-Zeit-Kontinuum.
<G-vec00389-002-s313><destroy.vernichten><en> WHAT: The New York State Department of Environmental Conservation (DEC) will destroy more than one ton [update: nearly two tons] of illegal ivory confiscated through state enforcement efforts.
<G-vec00389-002-s313><destroy.vernichten><de> Hamburg Heute um 10.30 Uhr Ortszeit vernichtet die Umweltbehörde des Staates New York (DEC) fast zwei Tonnen beschlagnahmtes, illegales Elfenbein.
<G-vec00389-002-s314><destroy.vernichten><en> Your goal is to position the pills correctly to destroy all viruses in the flask.
<G-vec00389-002-s314><destroy.vernichten><de> Dein Ziel ist es, die Pillen korrekt zu positionieren, damit alle Viren im Kolben vernichtet werden.
<G-vec00389-002-s315><destroy.vernichten><en> RUST (Rusting): A successful attack of the monster will immediately destroy a treasure of the hero.
<G-vec00389-002-s315><destroy.vernichten><de> ROST (Rost): Bei einem erfolgreichen Angriff des Monsters wird sofort ein Schatz des Helden vernichtet.
<G-vec00389-002-s316><destroy.vernichten><en> When we no longer need your information for our purposes or legal obligations, we will destroy, delete or erase that information or convert it into an anonymous form.
<G-vec00389-002-s316><destroy.vernichten><de> Wenn wir Ihre Daten nicht mehr für unsere Zwecke oder gesetzlichen Pflichten benötigen, werden diese Informationen von uns vernichtet, gelöscht oder entfernt oder in eine anonymisierte Form umgewandelt.
<G-vec00389-002-s317><destroy.vernichten><en> But a site-wide disaster will destroy those backups.
<G-vec00389-002-s317><destroy.vernichten><de> Aber eine standortweite Katastrophe vernichtet auch diese Backups.
<G-vec00389-002-s318><destroy.vernichten><en> He was hunted like the wild beasts that they might destroy him.
<G-vec00389-002-s318><destroy.vernichten><de> Er wurde gejagt wie ein wildes Tier, um vernichtet zu werden.
<G-vec00389-002-s319><destroy.vernichten><en> Unless the proceedings are the subject of litigation, the organiser shall destroy all statements of support received for a given citizens' initiative and any copies thereof at the latest two months after the publication of the Commission communication referred to in point (b) of Article 11(1).
<G-vec00389-002-s319><destroy.vernichten><de> Sofern die Verfahren nicht Gegenstand eines Rechtsstreits sind, vernichtet der Organisator alle im Zusammenhang mit einer bestimmten Bürgerinitiative erhaltenen Unterstützungsbekundungen sowie etwaige Kopien davon spätestens zwei Monate nach der Veröffentlichung der Mitteilung der Kommission gemäß Artikel 11 Absatz 1 Buchstabe b.
<G-vec00389-002-s320><destroy.vernichten><en> The following material describes the dangers of some things that weaken and destroy chastity.
<G-vec00389-002-s320><destroy.vernichten><de> Im folgenden werden die Gefahren dessen geschildert, was die Keuschheit schwächt und vernichtet.
<G-vec00389-002-s321><destroy.vernichten><en> When that Monster is destroyed, destroy this card. RARE ASN-112
<G-vec00389-002-s321><destroy.vernichten><de> Wird das mit dieser Karte ausgerüstete Monster zerstört, so werden beide Monster vernichtet.
<G-vec00389-002-s322><destroy.vernichten><en> If a halt is not ordered, he will destroy all men.
<G-vec00389-002-s322><destroy.vernichten><de> Wenn ihm nicht Halt geboten wird, vernichtet er sie.
<G-vec00389-002-s323><destroy.vernichten><en> AMERICA/PERU - “I am deeply saddened and deplore these acts which dispose of human life as an object to destroy for political or ideological reasons”, said Cardinal Juan Cipriani Primate of Peru commenting the July 7 terrorist attacks on London Vatican City (Fides Service) - Appalled by the latest acts of violence on innocent civilians which provoke grief, fear, indignation and many queries, Fides spoke with Cardinal Juan Luis Cipriani Thorne, Archbishop of Lim...
<G-vec00389-002-s323><destroy.vernichten><de> AMERIKA/PERU - Ich empfinde großen Schmerz und eine Ablehnung gegen alles, was das Menschenleben als Ware betrachtet, die aus politischen und ideologischen Gründen vernichtet werden kann“, so der Kardinalprimas von Peru, Juan Cipriani, nach den Attentaten in London Vatikanstadt (Fidesdienst) - Über der Gewalt, die ein weiteres Mal unschuldige und wehrlose Menschen getroffen hat, und Schmerz, Angst, Entsetzen und viele offene Fragen mit sich brachte, sprach der Fidesdienst mit Kard...
<G-vec00389-002-s324><destroy.vernichten><en> But you human can not estimate the meaning of the ending of a redeeming epoch, for the taking place of a transformation on this earth is unimaginable to you, which will destroy all creature, in which all creation, every life, will be dissolved and wiped out....
<G-vec00389-002-s324><destroy.vernichten><de> Ihr Menschen aber könnt es nicht ermessen, was das Beenden einer Erlösungsepoche bedeutet, denn niemals könnt ihr euch davon eine Vorstellung machen, daß sich eine Umwandlung vollzieht auf der Erde, die alle Kreatur vernichtet, wo alles Geschöpfliche, alles Leben, aufgelöst und ausgelöscht wird....
<G-vec00389-002-s325><destroy.vernichten><en> He is not afraid to confront the questions and great themes of the Christian faith, even those most hostile to reason, grounding these on the principle that “Faith does not destroy Nature, but brings it to perfection” .
<G-vec00389-002-s325><destroy.vernichten><de> Er hat keine Angst die Fragen und Themen des christlichen Glaubens anzugehen, auch die für den Verstand schwierigsten, die auf dem Prinzip basierend, dass „der Glaube vernichtet nicht die Natur, sondern bringt sie zur Perfektion“.
<G-vec00389-002-s326><destroy.vernichten><en> Destroy them, [%userclass].
<G-vec00389-002-s326><destroy.vernichten><de> Vernichtet sie, [%userclass].
<G-vec00389-002-s378><destroy.vertilgen><en> The Lord watches over all who love him, but all the wicked he will destroy.
<G-vec00389-002-s378><destroy.vertilgen><de> Es hütet der Ewige alle, die ihn lieben, und alle Frevler vertilgt er.
<G-vec00389-002-s379><destroy.vertilgen><en> For it was of Yahweh to harden their hearts, to come against Israel in battle, that he might utterly destroy them, that they might have no favor, but that he might destroy them, as Yahweh commanded Moses.
<G-vec00389-002-s379><destroy.vertilgen><de> Und das alles geschah also von dem HERRN, daß ihr Herz verstockt würde, mit Streit zu begegnen den Kindern Israel, auf daß sie verbannt würden und ihnen keine Gnade widerführe, sondern vertilgt würden, wie der HERR dem Mose geboten hatte.
<G-vec00389-002-s380><destroy.vertilgen><en> 15 for the Lord your God in your midst is a jealous God—lest the anger of the Lord your God be kindled against you, and he destroy you from off the face of the earth.
<G-vec00389-002-s380><destroy.vertilgen><de> 15 — denn der HERR, dein Gott, der in deiner Mitte wohnt, ist ein eifersüchtiger Gott —, damit nicht der Zorn des HERRN, deines Gottes, gegen dich entbrennt und er dich von der Erde vertilgt.
<G-vec00389-002-s381><destroy.vertilgen><en> 31 But, because of your great compassion, you did not destroy them completely nor abandon them, for you are a gracious, compassionate God.
<G-vec00389-002-s381><destroy.vertilgen><de> 31 In deiner großen Barmherzigkeit aber hast du sie nicht völlig vertilgt und sie nicht verlassen, denn du bist ein gnädiger und barmherziger Gott.
<G-vec00389-002-s382><destroy.vertilgen><en> 26 But the judgment shall be set, and they shall take away his dominion, to consume and to destroy it to the end.
<G-vec00389-002-s382><destroy.vertilgen><de> 26 Darnach wird das Gericht gehalten werden; da wird dann seine Gewalt weggenommen werden, daß er zu Grund vertilgt und umgebracht werde.
<G-vec00389-002-s383><destroy.vertilgen><en> 20The LORD preserveth all them that love him: but all the wicked will he destroy.
<G-vec00389-002-s383><destroy.vertilgen><de> 20 Der HERR bewahrt alle, die ihn lieben, aber alle Gottlosen vertilgt er.
<G-vec00389-002-s385><destroy.vertilgen><en> 20 for from Jehovah it hath been to strengthen their heart, to meet in battle with Israel, in order to devote them, so that they have no grace, but in order to destroy them, as Jehovah commanded Moses.
<G-vec00389-002-s385><destroy.vertilgen><de> 20So geschah es von dem HERRN, dass ihr Herz verstockt wurde, im Kampf Israel zu begegnen, damit sie mit dem Bann geschlagen würden und ihnen keine Gnade widerführe, sondern sie vertilgt würden, wie der HERR dem Mose geboten hatte.
<G-vec00389-002-s386><destroy.vertilgen><en> Jer 15:3 "I will appoint over them four kinds of doom," declares the LORD: "the sword to slay, the dogs to drag off, and the birds of the sky and the beasts of the earth to devour and destroy.
<G-vec00389-002-s386><destroy.vertilgen><de> 3Denn ich will sie heimsuchen mit viererlei Plagen, spricht der HERR: mit dem Schwert, dass sie getötet werden; mit Hunden, die sie fortschleifen sollen; mit den Vögeln des Himmels und mit den Tieren des Feldes, dass sie gefressen und vertilgt werden sollen.
<G-vec00389-002-s387><destroy.vertilgen><en> 20 The LORD preserveth all them that love him: but all the wicked will he destroy.
<G-vec00389-002-s387><destroy.vertilgen><de> 20 Der HERR bewahrt alle, die ihn lieben, und alle Gottlosen vertilgt er.
<G-vec00389-002-s389><destroy.vertilgen><en> 2 Ye shall utterly destroy all the places, wherein the nations which ye shall possess served their gods, upon the high mountains, and upon the hills, and under every green tree:* 3 And ye shall overthrow their altars, and break their pillars, and burn their groves with fire; and ye shall hew down the graven images of their gods, and destroy the names of them out of that place.† 4 Ye shall not do so unto the LORD your God.
<G-vec00389-002-s389><destroy.vertilgen><de> 2 Verstört alle Orte, da die Heiden, die ihr vertreiben werdet, ihren Göttern gedient haben, es sei auf hohen Bergen, auf Hügeln oder unter grünen Bäumen, 3 und reißt um ihre Altäre und zerbrecht ihre Säulen und verbrennt mit Feuer ihre Haine, und die Bilder ihrer Götter zerschlagt, und vertilgt ihren Namen aus demselben Ort.
<G-vec00389-002-s390><destroy.vertilgen><en> was of the LORD to harden their hearts, that they should come against Israel in battle, that he might destroy them utterly, and that they might have no favour, but that he might destroy them, as the LORD commanded Moses. 21
<G-vec00389-002-s390><destroy.vertilgen><de> 11,20 So geschah es von dem HERRN, daß ihr Herz (a) verstockt wurde, im Kampf Israel zu begegnen, damit sie mit dem (b) Bann geschlagen würden und ihnen keine Gnade widerführe, sondern sie vertilgt würden, wie der HERR dem Mose geboten hatte.
<G-vec00389-002-s429><destroy.zerstören><en> Destroy all slingshot targets in 3 attempts.
<G-vec00389-002-s429><destroy.zerstören><de> Zerstören Sie alle Schleuderziele mit 3 Schüssen.
<G-vec00389-002-s430><destroy.zerstören><en> Distribute appropriately the dynamite and destroy the bridges when the red train goes by.
<G-vec00389-002-s430><destroy.zerstören><de> Verteilen Sie entsprechend das Dynamit und zerstören Sie die Brücken, wenn der rote Zug passieren wird.
<G-vec00389-002-s431><destroy.zerstören><en> Destroy entire worlds with terrifying new planet-killer weapons, fight against (or alongside) ruthless space pirates, and maybe discover a few non-violent game features as well.
<G-vec00389-002-s431><destroy.zerstören><de> Zerstören Sie ganze Welten mit furchterregenden neuen Planetenkiller-Waffen, kämpfen Sie gegen (oder mit) gnadenlosen Weltraumpiraten, und entdecken Sie vielleicht auch ein paar nicht-gewalttätige neue Spielfeatures.
<G-vec00389-002-s432><destroy.zerstören><en> Destroy 50 enemies with the cannon in multiplayer matches.
<G-vec00389-002-s432><destroy.zerstören><de> Zerstören Sie 50 Gegner mit dem Geschütz im Mehrspielermodus.
<G-vec00389-002-s433><destroy.zerstören><en> Shooting Pizza Madness Destroy the pizza slices.
<G-vec00389-002-s433><destroy.zerstören><de> Schießen der Pizza-Wahnsinn Zerstören Sie die Pizza Slices.
<G-vec00389-002-s434><destroy.zerstören><en> Destroy 8 tiles on the reels and win a random coin win of anything between 5x and 100x your bet level for each destroyed symbol.
<G-vec00389-002-s434><destroy.zerstören><de> Zerstören Sie 8 Kacheln auf den Walzen und gewinnen Sie einen zufälligen Münzbetrag zwischen 5x und 100x Ihres Wettlevels, pro zerstörtem Symbol.
<G-vec00389-002-s435><destroy.zerstören><en> Description Destroy the enemy tank.
<G-vec00389-002-s435><destroy.zerstören><de> Beschreibung Zerstören Sie die feindlichen Panzer.
<G-vec00389-002-s436><destroy.zerstören><en> Destroy The City Mission: Destroy as many cars and traffic signs as possible in Manhattan before the time runs out.
<G-vec00389-002-s436><destroy.zerstören><de> Mission "Vernichtung der Stadt": Zerstören Sie so viele Autos und Verkehrsschilder in Manhattan wie möglich, bevor die Zeit abläuft.
<G-vec00389-002-s437><destroy.zerstören><en> Destroy all Mr. Raccoons.
<G-vec00389-002-s437><destroy.zerstören><de> Zerstören Sie alle Mr. Raccoons.
<G-vec00389-002-s438><destroy.zerstören><en> Jump, collect coins or destroy the dangerous turtles. Avoid all carnivorous flowers.
<G-vec00389-002-s438><destroy.zerstören><de> Springen Sie, Sammeln Sie die Münzen, zerstören Sie die gefährlichen Schildkröten, vermeiden Sie die fleischfressende Blumen.
<G-vec00389-002-s439><destroy.zerstören><en> Destroy the rivals on the roads and flip their ashes into the air.
<G-vec00389-002-s439><destroy.zerstören><de> Zerstören Sie die Rivalen auf den Straßen und schlagen Sie ihre Asche in die Luft.
<G-vec00389-002-s440><destroy.zerstören><en> Destroy anything in your path.
<G-vec00389-002-s440><destroy.zerstören><de> Zerstören Sie alles in Ihrem Weg.
<G-vec00389-002-s441><destroy.zerstören><en> Destroy enemy positions and escape the perils of the jungle.
<G-vec00389-002-s441><destroy.zerstören><de> Zerstören Sie feindliche Positionen und flüchten Sie aus den Fängen des Dschungels.
<G-vec00389-002-s442><destroy.zerstören><en> Destroy a legion of robots before they kill you.
<G-vec00389-002-s442><destroy.zerstören><de> Zerstören Sie eine Legion von Robotern, bevor sie dich töten.
<G-vec00389-002-s443><destroy.zerstören><en> Destroy the garbage bags.
<G-vec00389-002-s443><destroy.zerstören><de> Zerstören Sie die Müllsäcke.
<G-vec00389-002-s444><destroy.zerstören><en> Fly your helicopter and destroy enemies.
<G-vec00389-002-s444><destroy.zerstören><de> Fliegen Sie Ihren Hubschrauber und zerstören Sie Feinde.
<G-vec00389-002-s445><destroy.zerstören><en> Sabotage and Destroy and earn your spot on the Leaderboards
<G-vec00389-002-s445><destroy.zerstören><de> Sabotieren und zerstören Sie, um sich einen Platz auf den Ranglisten zu sichern.
<G-vec00389-002-s446><destroy.zerstören><en> Damage and destroy an enemy ship.
<G-vec00389-002-s446><destroy.zerstören><de> Beschädigen und zerstören Sie ein gegnerisches Schiff.
<G-vec00389-002-s447><destroy.zerstören><en> Destroy the helicopter without defeating any other enemies
<G-vec00389-002-s447><destroy.zerstören><de> Zerstören Sie den Hubschrauber, ohne andere Gegner zu erledigen.
