<G-vec00279-002-s019><defeat.bekämpfen><en> They offer the organizational skills to limit and defeat diseases and to achieve crop renewal.
<G-vec00279-002-s019><defeat.bekämpfen><de> Sie bieten Organisation an, um Krankheiten zu begrenzen und zu bekämpfen und die Kulturen zu erneuern.
<G-vec00279-002-s020><defeat.bekämpfen><en> You and up to 20 other Trainers can work together to defeat the Raid Boss.
<G-vec00279-002-s020><defeat.bekämpfen><de> Bis zu 20 Trainer können sich zusammenschließen, um den Raid-Boss gemeinsam zu bekämpfen.
<G-vec00279-002-s021><defeat.bekämpfen><en> Therefore please write messages @verdi too (info(at)verdi(dot)de). The German administrations should stop to fight against refugees, but have to defeat the Nazi terrorism!
<G-vec00279-002-s021><defeat.bekämpfen><de> Schreibt also bitte auch an verdi (info(at)verdi(dot)de), damit sie ebenfalls das Innenministerium auffordern, anstatt gegen Flüchtlinge vorzugehen, den Nazi-Terror zu bekämpfen.
<G-vec00279-002-s022><defeat.bekämpfen><en> They should be able to recognise safety risks, prevent incidents and defeat cybercrime.
<G-vec00279-002-s022><defeat.bekämpfen><de> Auf diese Weise können sie Sicherheitsrisiken erkennen, sicherheitsrelevante Vorfälle verhindern und Cyberkriminalität effektiv bekämpfen.
<G-vec00279-002-s023><defeat.bekämpfen><en> After the confrontation with Darth Vader on Malachor, Ezra secretly worries if he is powerful enough to defeat the dark side. See More
<G-vec00279-002-s023><defeat.bekämpfen><de> Nach der Konfrontation mit Darth Vader auf Malachor zweifelt Ezra jedoch im Geheimen daran, ob er stark genug ist, die dunkle Seite zu bekämpfen.
<G-vec00279-002-s024><defeat.bekämpfen><en> Arm yourself with weapons of legend to defeat underpants gnomes, hippies and other forces of evil.
<G-vec00279-002-s024><defeat.bekämpfen><de> Rüste dich mit legendären Waffen aus, um Krebsmenschen, Unterhosenwichtel, Hippies und andere Mächte des Bösen zu bekämpfen.
<G-vec00279-002-s025><defeat.bekämpfen><en> Guide the doctor safely through 10 challenging levels where you have to defeat birds, activate fans, navigate bees and collect stars.
<G-vec00279-002-s025><defeat.bekämpfen><de> Führe ihn sicher durch 10 anspruchsvolle Level, in denen du Vögel bekämpfen, Ventilatoren benutzen, Bienen lenken und Sterne einsammeln musst.
<G-vec00279-002-s026><defeat.bekämpfen><en> To assist both individuals and governments not only to maintain stability, but to defeat their real enemies—disease, the elements and Man’s own unreason—Mr. Hubbard sets out a humanitarian program vital to all.
<G-vec00279-002-s026><defeat.bekämpfen><de> Um sowohl den Einzelnen als auch den Regierungen zu helfen, nicht nur ihre Stabilität zu bewahren, sondern auch ihre wahren Feinde zu bekämpfen – Krankheit, die Elemente und den eigenen Unverstand des Menschen – stellt L. Ron Hubbard ein humanitäres Programm auf, das für uns alle lebenswichtig ist.
<G-vec00279-002-s027><defeat.bekämpfen><en> Immune+++ contains powerful antioxidants to defeat destructive free radicals.
<G-vec00279-002-s027><defeat.bekämpfen><de> Immune+++ enthält starke Antioxidantien, um zerstörerische freie Radikale zu bekämpfen.
<G-vec00279-002-s028><defeat.bekämpfen><en> And you decide to tell the story of how your product went on a crusade to defeat the mediocrity of existing products that were doing similar things but with less efficiency.
<G-vec00279-002-s028><defeat.bekämpfen><de> Das werde ich einsetzen.“ Und Sie entscheiden sich, eine Geschichte darüber zu erzählen, darüber, wie Ihr Produkt eine Odyssee durchleben musste, um die Mittelmässigkeit existierender Produkte zu bekämpfen, die einen ähnlichen aber weniger effizienten Nutzen liefern.
<G-vec00279-002-s029><defeat.bekämpfen><en> We also now know that rather than defeat terrorism the war in Iraq has actually helped fan the fire.
<G-vec00279-002-s029><defeat.bekämpfen><de> Wir wissen jetzt auch, dass der Krieg im Irak tatsächlich geholfen hat, das Feuer anzufachen, anstatt den Terrorismus zu bekämpfen.
<G-vec00279-002-s030><defeat.bekämpfen><en> She had the weapon, she just needed th courage to face the nightmare and defeat it.
<G-vec00279-002-s030><defeat.bekämpfen><de> Sie hatte die Waffe und sie brauchte jetzt den Mut, sich dem Albtraum zu stellen und ihn zu bekämpfen.
<G-vec00279-002-s031><defeat.bekämpfen><en> By adopting this policy of backing a right-wing candidate supported by the PS, supposedly in order to defeat the danger of authoritarianism and fascism posed by the FN, all three parties made clear that they had no intention of posing an alternative to the capitalist system.
<G-vec00279-002-s031><defeat.bekämpfen><de> Mit dieser Unterstützung eines rechten Kandidaten, um angeblich gemeinsam mit der PS die vom FN ausgehende Gefahr von Diktatur und Faschismus zu bekämpfen, gaben alle drei Parteien deutlich zu erkennen, dass sie nicht die Absicht hatten, eine Alternative zum Kapitalismus zu vertreten.
<G-vec00279-002-s032><defeat.bekämpfen><en> Rukia forces Ichigo to defeat a Hollow, all the while chastising him, and forces him to apologize to Orihime.
<G-vec00279-002-s032><defeat.bekämpfen><de> Rukia, die unter den sechs Shinigami ist, die von Toshiro Hitsugaya angeführt werden, zwingt Ichigo, einen Hollow zu bekämpfen und scheltet ihn dabei die ganze Zeit über.
<G-vec00279-002-s033><defeat.bekämpfen><en> Skilled players sometimes team up, trying to defeat the Chaser and receive bonus points.
<G-vec00279-002-s033><defeat.bekämpfen><de> S4-Veteranen allerdings greifen lieber an und bekämpfen den "Chaser" gemeinsam, um Bonuspunkte zu kassieren.
<G-vec00279-002-s034><defeat.bekämpfen><en> While powerful, the dogs will not be hard to defeat with a team of 6 Pokémon.
<G-vec00279-002-s034><defeat.bekämpfen><de> Auch wenn sie stark sind, sind die Hunde mit einem Team aus sechs Pokémon nicht schwer zu bekämpfen.
<G-vec00279-002-s035><defeat.bekämpfen><en> We will only defeat terrorism by working together. ---
<G-vec00279-002-s035><defeat.bekämpfen><de> Wir werden Terrorismus nur dann wirksam bekämpfen, wenn wir zusammen arbeiten.
<G-vec00279-002-s036><defeat.bekämpfen><en> You can defeat the Legendary Ships without upgrading everything to the Elite level, but it is highly recommended that you have the Elite Hull upgrade.
<G-vec00279-002-s036><defeat.bekämpfen><de> Du kannst die Legendären Schiffe bekämpfen, ohne alles auf das Elite-Level hochzurüsten, aber es ist sehr zu empfehlen, dass du das Elite-Schiffskörper-Upgrade hast.
<G-vec00279-002-s037><defeat.bekämpfen><en> For such purpose, you have to get hold of the best players and lineup the best starting eleven possible to defeat your rivals.
<G-vec00279-002-s037><defeat.bekämpfen><de> Zu diesem Zweck müssen Sie sich die besten Spieler holen und die bestmögliche Startelf aufstellen, um Ihre Rivalen zu bekämpfen.
<G-vec00279-002-s076><defeat.besiegen><en> Start with a x2 multiplier and battle for victory for extra spins as you defeat enemies.
<G-vec00279-002-s076><defeat.besiegen><de> Beginne mit einem x2-Multiplikator und kämpfe um den Sieg, um zusätzliche Spins zu aktivieren, wenn du Gegner besiegst.
<G-vec00279-002-s077><defeat.besiegen><en> As a famous arena fighter, you also defeat lions, bears and villains on the Party theme.
<G-vec00279-002-s077><defeat.besiegen><de> Als berühmter Arenakämpfer besiegst Du auch auf der Motto Party Löwen, Bären und Schurken.
<G-vec00279-002-s078><defeat.besiegen><en> Set on the mysterious planet Draco, "Crimson Dragon: Side Story" is a shooter in which you control dragons to defeat enemies.
<G-vec00279-002-s078><defeat.besiegen><de> „Crimson Dragon: Side Story“ ist ein Shooter, der auf dem geheimnisvollen Planeten Draco spielt und in dem du mit deinen Drachen Gegner besiegst.
<G-vec00279-002-s079><defeat.besiegen><en> Defeat your enemies faster with special combinations of melee, magic and ranged traits to cause maximum damage.
<G-vec00279-002-s079><defeat.besiegen><de> Mit besonderen Kombinationen von Nahkampf-, Magie- und Fernkampffertigkeiten richtest du maximalen Schaden an und besiegst deine Feinde schneller.
<G-vec00279-002-s080><defeat.besiegen><en> Win bonuses as you defeat opponents and beat your friends in the Ranking.
<G-vec00279-002-s080><defeat.besiegen><de> Gewinne Preise, indem du deine Gegner besiegst und im Ranking besser bist als deine Freunde.
<G-vec00279-002-s100><defeat.bezwingen><en> Defeat Austria’s second biggest river, the Mur, and fight with your paddle against the rapids and the white water.
<G-vec00279-002-s100><defeat.bezwingen><de> Bezwingen Sie den zweitgrößten Fluss Österreichs, die Mur, und kämpfen Sie gemeinsam mit dem Paddel gegen Stromschnellen und das wilde Wasser.
<G-vec00279-002-s101><defeat.bezwingen><en> Following that, she went on to defeat Lucie Šafářová in the second round (marking her first back-to-back victory in 2013) before falling to Victoria Azarenka in the third round.[citation needed]
<G-vec00279-002-s101><defeat.bezwingen><de> Beim anschließenden Turnier in Peking schied sie in der dritten Runde gegen Peng Shuai aus, nachdem sie zuvor Asaranka in einem längeren Match hatte bezwingen können.
<G-vec00279-002-s102><defeat.bezwingen><en> No need to be online to defeat the shadows.
<G-vec00279-002-s102><defeat.bezwingen><de> Du brauchst also nicht online zu sein, um die Schatten zu bezwingen.
<G-vec00279-002-s103><defeat.bezwingen><en> My goal is to destroy this ship, not defeat one human in combat.
<G-vec00279-002-s103><defeat.bezwingen><de> Mein Ziel ist es, das Schiff zu zerstören, nicht einen Menschling im Zweikampf zu bezwingen.
<G-vec00279-002-s104><defeat.bezwingen><en> Dragons roam the skies above the ancestral home of the Khajiit, and it’ll take everything you’ve got to defeat them.
<G-vec00279-002-s104><defeat.bezwingen><de> Drachen bevölkern den Himmel über der angestammten Heimat der Khajiit, und ihr werdet alles geben müssen, um sie zu bezwingen.
<G-vec00279-002-s105><defeat.bezwingen><en> He was tragically reforged into an instrument of the Scourge, the evil he had once sworn to defeat.
<G-vec00279-002-s105><defeat.bezwingen><de> Er wurde in tragischer Weise zu einem Instrument der Geißel, genau dem Übel, das er einst zu bezwingen geschworen hatte.
<G-vec00279-002-s106><defeat.bezwingen><en> Use your strategic skills to place your starships and space constructions and defeat your enemy.
<G-vec00279-002-s106><defeat.bezwingen><de> Setze deine strategischen Fähigkeiten ein, um Raumschiffe und Konstruktionen zu platzieren, damit du deine Gegner bezwingen kannst.
<G-vec00279-002-s107><defeat.bezwingen><en> Nonetheless, Tóta hopes that after securing a majority in the European Parliament, his centrist adversaries will use their power to defeat and weaken the Hungarian Prime Minister.
<G-vec00279-002-s107><defeat.bezwingen><de> Dennoch äußert Tóta die Hoffnung, dass die in der politischen Mitte angesiedelten Gegner Orbáns nach Gewinn einer Mehrheit im Europäischen Parlament ihre Macht dazu nutzen würden, den ungarischen Ministerpräsidenten zu bezwingen und zu schwächen.
<G-vec00279-002-s108><defeat.bezwingen><en> If you defeat it, you’ll complete the trial.
<G-vec00279-002-s108><defeat.bezwingen><de> Wenn du es bezwingen kannst, gilt die Prüfung als bestanden.
<G-vec00279-002-s109><defeat.bezwingen><en> Tahiti earned their first victory at the FIFA Beach Soccer World Cup Bahamas 2017 in dramatic fashion, surviving a late fightback to defeat Japan 4-3 in their second Group D encounter.
<G-vec00279-002-s109><defeat.bezwingen><de> Nachdem es nach drei Dritteln 6:6 stand, konnte Tahiti Italien im Neunmeterschießen mit 3:1 bezwingen und den Finaleinzug bei der FIFA Beach-Soccer-Weltmeisterschaft Portugal 2015 feiern.
<G-vec00279-002-s110><defeat.bezwingen><en> To defeat the enemies at the end you have to walk between the left and right side two and fro.
<G-vec00279-002-s110><defeat.bezwingen><de> Um die Gegner am Ende zu bezwingen, muss man zwischen linker und rechter Seite hin und herlaufen.
<G-vec00279-002-s111><defeat.bezwingen><en> Your goal is to help Arthur create and command an army to defeat 7 kings and queens who rule the land.
<G-vec00279-002-s111><defeat.bezwingen><de> Hilf ihm, eine Armee aufzustellen und zu führen, um 7 Könige und Königinnen zu bezwingen, die das Land regieren.
<G-vec00279-002-s112><defeat.bezwingen><en> Police and army cannot defeat the robot.
<G-vec00279-002-s112><defeat.bezwingen><de> Polizei und Armee können den Roboter nicht bezwingen.
<G-vec00279-002-s113><defeat.bezwingen><en> That’s of course, IF you are able to defeat the adventurer.
<G-vec00279-002-s113><defeat.bezwingen><de> Selbstverständlich müsst Ihr dafür zuerst den gegnerischen Abenteurer bezwingen.
<G-vec00279-002-s114><defeat.bezwingen><en> In order to defeat us, the forces of Capital are still using the same tactics, trying to divide us across old nation-state borders, and the new internal borders caused by the latest wave of migration.
<G-vec00279-002-s114><defeat.bezwingen><de> Die Kräfte des Kapitals nutzen noch immer dieselben Taktiken, um uns zu bezwingen: Sie versuchen uns auseinanderzubringen, uns nach den alten national-staatlichen Grenzen und nach den neuen inneren Grenzen, die durch die jüngste Migrationswellen entstanden sind, zu trennen.
<G-vec00279-002-s115><defeat.bezwingen><en> If it was an enemy i would defeat him with my bare hands, i was sure of this.
<G-vec00279-002-s115><defeat.bezwingen><de> Würde es ein Gegner sein, ich würde ihn auch mit bloßen Händen bezwingen, dessen war ich mir sicher.
<G-vec00279-002-s116><defeat.bezwingen><en> Since then, nothing and no one has been able or ever will be able to defeat our people.
<G-vec00279-002-s116><defeat.bezwingen><de> Seitdem gibt es nichts und niemanden, was ein Volk wie das unsere bezwingen könnte.
<G-vec00279-002-s117><defeat.bezwingen><en> The game casts players as Joey, a lone survivor pit against a herd of writhing, unrelenting zombies - to defeat the undead masses, players must use their fingers to flick and smash them until they're un-undead.
<G-vec00279-002-s117><defeat.bezwingen><de> Der Spieler schlüpft in die Rolle des Joey, ein einsamer Überlebender, der gegen eine Horde modriger, unerbittlicher Zombies antreten muss – um die untoten Massen zu bezwingen müssen die Spieler ihre Finger einsetzen, um sie zu schlenzen und zu zerschmettern, bis sie un-untot sind.
<G-vec00279-002-s118><defeat.bezwingen><en> Use the gold to train warriors and defeat your enemy.
<G-vec00279-002-s118><defeat.bezwingen><de> Verwende dein Gold, um Soldaten zu trainieren und Gegner zu bezwingen.
<G-vec00279-002-s178><defeat.erledigen><en> If you can defeat many Pokémon simultaneously, it’s a great chance to give your Pokémon a growth spurt.
<G-vec00279-002-s178><defeat.erledigen><de> Gelingt es, viele Pokémon gleichzeitig zu erledigen, dann ist das eine hervorragende Gelegenheit, Ihrem Pokémon einen Wachstumsschub zu ermöglichen.
<G-vec00279-002-s179><defeat.erledigen><en> However, there is no requirement to finish any of these objectives, so you can feel free to just fish or defeat whatever monsters you find.
<G-vec00279-002-s179><defeat.erledigen><de> Es gibt allerdings keine Notwendigkeit irgendwelche dieser Ziele abzuschließen, also könnt ihr auch fischen oder ein Monster eurer Wahl erledigen.
<G-vec00279-002-s180><defeat.erledigen><en> You will then have to follow the Mechanist and help him defeat her and her ants.
<G-vec00279-002-s180><defeat.erledigen><de> Man muss dann dem Mechanisten folgen und ihre Ameisen erledigen.
<G-vec00279-002-s181><defeat.erledigen><en> In the first days they are easy to defeat.
<G-vec00279-002-s181><defeat.erledigen><de> In den ersten Tagen sind sie leicht zu erledigen.
<G-vec00279-002-s182><defeat.erledigen><en> The activities of the deeply eurosceptic Mr Klaus, and the controversy caused on his recent state visit to Ireland, have alarmed supporters of Lisbon, who fear the Czech president may plunge his country into a constitutional crisis to delay or defeat the treaty.
<G-vec00279-002-s182><defeat.erledigen><de> Die Aktivitäten des tief euroskeptischen Klaus sowie die Kontroverse, die von seinem jüngsten Staatsbesuch in Irland verursacht wurden, haben Lissabon-Anhänger alarmiert, die befürchten, dass der tschechische Präsident sein Land in eine Verfassungskrise stürzen wolle, um den Vertrag zu verzögern oder ganz zu erledigen.
<G-vec00279-002-s252><defeat.niederlagen><en> Matchmaking Fixed a bug where "Loss Prevented" was showing up as Defeat in the post-game lobby and in the Match History.
<G-vec00279-002-s252><defeat.niederlagen><de> Matchmaking Ein Fehler wurde behoben, durch den Vergebene Niederlagen in der Lobby nach Spielende und im Spielverlauf als Verloren angezeigt wurden.
<G-vec00279-002-s253><defeat.niederlagen><en> But sports also include defeat and recognition when the opponents were better.
<G-vec00279-002-s253><defeat.niederlagen><de> Aber zum Sport gehören auch Niederlagen und das Anerkennen, wenn die Gegner besser waren.
<G-vec00279-002-s254><defeat.niederlagen><en> In this context of physical, and above all political defeat, expressions of working class combativity were easily derailed by the bourgeoisie onto the rotten terrain of anti-fascism, in other words the preparation for the second imperialist massacre.
<G-vec00279-002-s254><defeat.niederlagen><de> Auf diesem Hintergrund der physischen und vor allem politischen Niederlagen des Proletariats konnten die Ausdrucke an Kampfbereitschaft leicht von der herrschenden Klasse auf das Terrain des Antifaschismus abgeleitet werden, d.h. auf das Terrain der Vorbereitung des zweiten imperialistischen weltweiten Abschlachtens.
<G-vec00279-002-s255><defeat.niederlagen><en> (ATTENTION: Technical Defeat or leaving the clan will not break the winning streak.)
<G-vec00279-002-s255><defeat.niederlagen><de> Technische Niederlagen oder Verlassen des Clans unterbrechen die Serie nicht.
<G-vec00279-002-s256><defeat.niederlagen><en> Even the truly righteous man “falls seven times”!9 Christian experience always involves excruciating defeat as part of the process of learning to “walk in the Spirit.”
<G-vec00279-002-s256><defeat.niederlagen><de> Selbst der Gerechte „fällt siebenmal“!9 Die Erfahrungen des Christen beinhalten immer schmerzhafte Niederlagen, als Teil des Lernprozesses, um „im Geist zu wandeln“.
<G-vec00279-002-s257><defeat.niederlagen><en> After its defeat and exile, the reversion to the old lordships and borders took place, but Austria secured control of the northern region of Lombardy-Veneto and 3 smaller areas.
<G-vec00279-002-s257><defeat.niederlagen><de> Nach dessen Niederlagen und Verbannung erfolgte die Zurücksetzung auf die alten Herrschaften und Grenzen, wobei sich Österreich jedoch die Herrschaft über das nördliche Gebiet Lombardei-Venetien und 3 kleinere Gebiete sicherte.
<G-vec00279-002-s258><defeat.niederlagen><en> However this may be, Comrade, and from what motives you may act, if you go on with these tactics, you will suffer the most terrible defeat, and you will lead the proletariat into the most terrible defeat.
<G-vec00279-002-s258><defeat.niederlagen><de> Aber wie dem auch sei, Genosse, aus welchen Gründen Sie auch handeln, Sie werden die furchtbarste Niederlage erleiden und das Proletariat zu den fürchterlichsten Niederlagen führen, wenn Sie mit dieser Taktik weitergehen.
<G-vec00279-002-s259><defeat.niederlagen><en> Beating FC Barcelona 34:30 on Sunday was the revenge for the defeat in the 2015 final and the placement match defeat in 2014.
<G-vec00279-002-s259><defeat.niederlagen><de> Das 34:30 gegen Barcelona am Sonntag war somit die Revanche für die Niederlagen im Finale 2015 und dem „kleinen Finale“ von 2014.
<G-vec00279-002-s260><defeat.niederlagen><en> The debacle of 1806, the frightful defeat of the Prussian armies at Jena and Auerstadt, the shameful surrender of the fortresses to the French without even an attempt at any real resistance by the noble defenders, the flight of the king to the Russian frontier, the wretched machinations of the Prussian junkers (who in the midst of this gruesome catastrophe thought of nothing but to preserve their miserable prerogatives)-sufficiently characterise the then prevailing conditions in Prussia.
<G-vec00279-002-s260><defeat.niederlagen><de> Der Zusammenbruch von 1806: die furchtbaren Niederlagen der preußischen Heere bei Jena und Auerstedt, die schmachvolle Übergabe der Festungen an die Franzosen, ohne daß die adligen Befehlshaber auch nur einen ernsthaften Widerstand geleistet hätten, die Flucht des Königs bis an die russische Grenze und die wüsten Quertreibereien der preußischen Junker, die inmitten dieser grauenvollen Katastrophe an nichts anderes dachten, als ihre elenden Vorrechte zu retten, kennzeichnen die damaligen preußischen Zustände zur Genüge.
<G-vec00279-002-s261><defeat.niederlagen><en> It is only through the perspectives of the affected groups and individuals that we can access and understand the ways in which defeat or loss is experienced and communicated.
<G-vec00279-002-s261><defeat.niederlagen><de> Wie Niederlagen oder Verluste erfahren und kommuniziert werden, ist nur aus der Perspektive der betroffenen Gruppen und Individuen zu erschließen.
<G-vec00279-002-s262><defeat.niederlagen><en> Whether in individual or team competition, on small grounds or in the really large arenas of our world: that symbiosis between horse and rider, jointly overcoming challenging obstacles, and the overwhelming emotions associated with victory and defeat – all these things define what makes show jumping so compelling.
<G-vec00279-002-s262><defeat.niederlagen><de> Ob in Einzel- oder Mannschaftsbewerben, auf kleinen Plätzen oder in den ganz großen Arenen der Erde: Die Symbiose zwischen Pferd und Reiter, das gemeinsame Überwinden anspruchsvoller Hindernisse und die unbändigen Emotionen nach Siegen und Niederlagen – all das macht die Faszination Springreitsport aus.
<G-vec00279-002-s263><defeat.niederlagen><en> But these were usually isolated explosions, followed by defeat and demoralisation.
<G-vec00279-002-s263><defeat.niederlagen><de> Es waren aber in der Regel isolierte Ausbrüche, gefolgt von Niederlagen und Demoralisierung.
<G-vec00279-002-s264><defeat.niederlagen><en> Nothing but failure and defeat, not even a single reform to ameliorate the economic and social stress of the people.
<G-vec00279-002-s264><defeat.niederlagen><de> Nichts als Versagen und Niederlagen, nicht eine einzige Reform, die die wirtschaftlichen und sozialen Belastungen der Menschen gelockert hätte.
<G-vec00279-002-s265><defeat.niederlagen><en> The fact that they succumbed to defeat or to internal degeneration in no way detracts from their fundamental contribution to that struggle.
<G-vec00279-002-s265><defeat.niederlagen><de> Die Tatsache, dass sie an Niederlagen oder innerem Verfall zugrunde gingen, schmälert nicht ihren grundsätzlichen Beitrag zu diesem Kampf.
<G-vec00279-002-s266><defeat.niederlagen><en> Learn from resistance and defeat.
<G-vec00279-002-s266><defeat.niederlagen><de> Lernt aus Widerstand und Niederlagen.
<G-vec00279-002-s267><defeat.niederlagen><en> Unfortunately, they could not continue the victory-run and had to take a clear defeat against Spartak and Dynamo Moscow.
<G-vec00279-002-s267><defeat.niederlagen><de> Leider konnten sie die Siegesserie nach kurzer Zeit nicht mehr fortsetzen und mussten deutliche Niederlagen gegen sowohl Spartak, als auch Dynamo Moskau hinnehmen.
<G-vec00279-002-s268><defeat.niederlagen><en> For the president, third and fifth generation shrimp fishermen and oyster gatherers are one thing above all: typical local editions of the shining hero, the hard-working American that honestly fights against others for his success, caring for himself, getting over each defeat, and carrying out, together with others who do the same with their means, the principle of life that has made America great.
<G-vec00279-002-s268><defeat.niederlagen><de> Krabbenfischer und Austernsammler in der dritten bis fünften Generation – das sind für den Präsidenten vor allem eines: Die lokaltypische Ausgabe der Lichtgestalt, die als hard working American redlich gegen andere um ihren Erfolg kämpft, sich um sich selbst kümmert, alle Niederlagen wegsteckt und zusammen mit allen anderen, die mit den Mitteln, die sie haben, dasselbe tun, das Lebensprinzip exekutiert, das Amerika groß gemacht hat.
<G-vec00279-002-s269><defeat.niederlagen><en> Sadness is a natural response to loss, defeat, disappointment, trauma, or catastrophe.
<G-vec00279-002-s269><defeat.niederlagen><de> Trauer ist eine natürliche Reaktion auf Verluste, Niederlagen, Enttäuschungen, Traumata oder Katastrophen.
<G-vec00279-002-s275><defeat.scheitern><en> The European Research Group (ERG), whose opposition to May’s deal helped defeat it three times in parliament, said Britain should not propose revising the agreement.
<G-vec00279-002-s275><defeat.scheitern><de> Sie bilden die einflussreiche Gruppierung European Research Group (ERG), deren Stimmen zum mehrfachen Scheitern von Premierministerin Theresa Mays Brexit-Abkommen mit der Europäischen Union (EU) im britischen Parlament beitrugen.
<G-vec00279-002-s276><defeat.scheitern><en> This constant defeat can be overcome immediately by chanting this Hare Kṛṣṇa mantra.
<G-vec00279-002-s276><defeat.scheitern><de> Dieses ständige Scheitern kann sofort durch das Chanten des Hare Kṛṣṇa-Mantra überwunden werden.
<G-vec00279-002-s277><defeat.scheitern><en> However, the house may be dissolved upon defeat of major legislation proposed by the executive branch of the government.
<G-vec00279-002-s277><defeat.scheitern><de> Die Kammer kann jedoch nach dem Scheitern wichtiger Gesetzesvorlagen auf Antrag der Exekutive vorzeitig aufgelöst werden.
<G-vec00279-002-s278><defeat.scheitern><en> What we have witnessed is the defeat of a particular type of bourgeois socialism and of the state-capitalist model which formed its basis.
<G-vec00279-002-s278><defeat.scheitern><de> Es ist das Scheitern und das Ende einer bestimmten Prägung des Bourgeois-Sozialismus, der die Grundlage des staatskapitalistischen Modells gewesen ist.
<G-vec00279-002-s279><defeat.scheitern><en> Che'n Tu-hsiu, the founder of the Chinese Communist Party, who joined Trotskyism after the defeat of the Chinese Revolution in 1927, could have been another exception.
<G-vec00279-002-s279><defeat.scheitern><de> Chen Duxiu, Gründer der Kommunistischen Partei Chinas, der nach dem Scheitern der Revolution 1937 zum Trotzkismus übertrat, hätte eine weitere Ausnahme sein können, doch er wurde von Tschiang Kai-schek verhaftet und saß anschließend in dem von den Japanern besetzten China fest, wo er bald sterben sollte.
<G-vec00279-002-s280><defeat.scheitern><en> His struggle was with the blockade of deep longing by the limitations of our senses, with defeat at the hands of the concept of infinity given the spatiality at our disposal, with the evocation of a beauty that goes beyond classicism and antiquity, opening itself up to the sound of the universe and believing that this sound resonates in the spiritual life of mankind.
<G-vec00279-002-s280><defeat.scheitern><de> Womit er rang, war die Blockade der Tiefensehnsucht durch die Begrenztheit unserer Sinne, das Scheitern am Begriff der Unendlichkeit in der zur Verfügung stehenden Räumlichkeit, das Beschwören einer Schönheit, die sich jenseits von Klassik und Antike dem Klang des Universums öffnet und an dessen Widerhall im Seelenleben des Menschen glaubt.
<G-vec00279-002-s281><defeat.scheitern><en> Mansoor Hekmat: As far as worker-communism and Marxism are concerned, these developments show neither the defeat of socialism nor the end of communism.
<G-vec00279-002-s281><defeat.scheitern><de> Mansour Hekmat: Soweit es den Sozialismus und den Arbeiterkornmunismus als auch den Marxismus als deren ideologische und theoretische Rahmenbedingung angeht, stellen diese Ereignisse weder das Scheitern des Sozialismus noch das Ende des Kommunismus dar.
<G-vec00279-002-s282><defeat.scheitern><en> Indeed a liberation which does not take into account the personal freedom of those who fight for it is condemned in advance to defeat. III.
<G-vec00279-002-s282><defeat.scheitern><de> Dagegen ist eine Befreiung, die der persönlichen Freiheit derer, die für sie kämpfen, keine Rechnung trägt, schon im voraus zum Scheitern verurteilt.
<G-vec00279-002-s283><defeat.scheitern><en> The Iranian people overthrew the empire and imposed defeat on the great military and political might of American and world imperialism.
<G-vec00279-002-s283><defeat.scheitern><de> Das iranische Volk stürzte das Kaiserreich und brachte die große militärische und politische Macht des amerikanischen Imperialismus, des Weltimperialismus zum Scheitern.
<G-vec00279-002-s284><defeat.schlagen><en> The gambling dens have made it basically impossible to defeat the game.
<G-vec00279-002-s284><defeat.schlagen><de> Die Casinos haben es sehr schwer, das Spiel zu schlagen.
<G-vec00279-002-s285><defeat.schlagen><en> Jesus will defeat the antichrist, and all people will accept the true religion of God.
<G-vec00279-002-s285><defeat.schlagen><de> Er wird den Antichristen schlagen und alle Menschen werden die wahre Religion Gottes annehmen.
<G-vec00279-002-s286><defeat.schlagen><en> If Islam succeeded in regaining its place of respect and glory in the recently and violently anti-religious society of Ataturk, if the Orthodoxy made it in Lenin’s land, the Christian Church may achieve the same in the US, by siding with people, and the people can defeat their enemy, by siding with the church.
<G-vec00279-002-s286><defeat.schlagen><de> Wenn der Islam dabei Erfolg hatte, seinen Platz des Respekts und des Ruhmes in der jüngsten und gewaltsam antireligiösen Gesellschaft von Atatürk wieder zu gewinnen, wenn die Orthodoxie es in Lenins Land schaffte, dann kann die Christliche Kirche dasselbe in den USA erreichen, indem sie sich den Menschen zur Seite stellt, und das Volk kann seinen Feind schlagen, indem es sich an die Seite der Kirche stellt.
<G-vec00279-002-s287><defeat.schlagen><en> Defeat your human opponents in battle or on the market place, seize or destroy whole worlds, forge alliances and trade successfully.
<G-vec00279-002-s287><defeat.schlagen><de> Schlagen Sie Ihre menschlichen Gegner im Kampf oder auf dem Marktplatz, erobern oder zerstören Sie Welten, schließen Sie Bündnisse und treiben Sie erfolgreich Handel.
<G-vec00279-002-s288><defeat.schlagen><en> Back in Nanimori, Daisy is confronted by Dino and Hibari, with the latter managing to defeat him with his Vongola Box.
<G-vec00279-002-s288><defeat.schlagen><de> Nachdem der Kampf begonnen hat, nimmt er Tsuna mit Torikabuto auf und kann diesen mit seiner Vongola Box schlagen.
<G-vec00279-002-s289><defeat.schlagen><en> If they hadn't played like this, it wouldn't have been possible to defeat Manchester United.
<G-vec00279-002-s289><defeat.schlagen><de> Wenn man nicht so spielt, dann ist es schwer, Manchester United zu schlagen.
<G-vec00279-002-s290><defeat.schlagen><en> It won't be easy because we'll have to beat the Algerians on their own turf, but despite the defeat we mustn't forget that we had lots of chances.
<G-vec00279-002-s290><defeat.schlagen><de> Das wird nicht leicht, zumal wir die Algerier ja auf ihrem Territorium schlagen müssen.
<G-vec00279-002-s291><defeat.schlagen><en> Training Tools Goal Talk to shaman Simar the Forester, ask him to summon a pet and defeat the powerful goblin in combat.
<G-vec00279-002-s291><defeat.schlagen><de> Sprecht mit dem Schamanen, Sikar dem Naturverbundenen, und bittet ihn, einen Begleiter zu beschwören und den mächtigen Goblin im Kampf zu schlagen.
<G-vec00279-002-s292><defeat.schlagen><en> This objective should be achieved on the basis of a simple slogan: you can't defeat the far-right parties by adopting their discourse.
<G-vec00279-002-s292><defeat.schlagen><de> Dieses Ziel muss auf einem einfachen Motto beruhen: Man kann die rechtsextremen Parteien nicht schlagen, indem man ihren Diskurs nachahmt.
<G-vec00279-002-s293><defeat.schlagen><en> And he is still good enough to defeat van Gerwen - he proved that in the World Matchplay impressively as well.
<G-vec00279-002-s293><defeat.schlagen><de> Und er ist auch gut immer noch genug um Michael van Gerwen zu schlagen - auch das hat er beim World Matchplay eindrucksvoll unter Beweis gestellt.
<G-vec00279-002-s294><defeat.schlagen><en> The employee can defeat the offender by using pepper spray.
<G-vec00279-002-s294><defeat.schlagen><de> Die Mitarbeiterin kann den Täter durch den Einsatz von Pfefferspray in die Flucht schlagen.
<G-vec00279-002-s295><defeat.schlagen><en> But now you will defeat it only three times.”
<G-vec00279-002-s295><defeat.schlagen><de> Jetzt aber wirst du sie nur dreimal schlagen.
<G-vec00279-002-s296><defeat.schlagen><en> The fact that the Red Army managed to meet this attack head-on and was able to defeat the German forces and prevent them from breaking through to Baku and the Volga Delta was due to “Kent’s” work.
<G-vec00279-002-s296><defeat.schlagen><de> Dass die Rote Armee diesem Angriff so gut vorbereitet begegnen konnte, die Hauptstoßkräfte der deutschen Armee vernichtend zu schlagen vermochte und so den Durchbruch nach Baku verhinderte, war „Kents“ größter Verdienst.
<G-vec00279-002-s297><defeat.schlagen><en> While some complain that Poland's opposition is failing to capitalise on the PiS's defeat, others voice their anger at Warsaw.
<G-vec00279-002-s297><defeat.schlagen><de> Während einige bedauern, dass Polens Opposition kein Kapital aus der PiS-Niederlage schlagen kann, sind andere richtig sauer auf Warschau.
<G-vec00279-002-s298><defeat.schlagen><en> He hoped that the Austrian army would arrive to help the fortress and the Prussians would defeat them in a great battle at the site of his choosing.
<G-vec00279-002-s298><defeat.schlagen><de> Er hoffte, das österreichische Heer würde der Festung zu Hilfe eilen und die Preußen würden es in einer großen Schlacht am Ort ihrer Wahl schlagen.
<G-vec00279-002-s299><defeat.schlagen><en> This is not the strength required to defeat a Position.
<G-vec00279-002-s299><defeat.schlagen><de> Dies beinhaltet nicht die Stärke, die erforderlich ist, um eine Position zu schlagen.
<G-vec00279-002-s300><defeat.schlagen><en> And in a similar manner are the Persians so incompetent that they need a Spartan traitor to defeat the Spartans, what should have never happened based on the numbers the Persians they had at their disposal.
<G-vec00279-002-s300><defeat.schlagen><de> Und genauso sind die Perser schlicht so unfähig dass sie einen spartanischen Verräter brauchen um die Spartaner zu schlagen, was bei diesen Zahlen an Persern niemals passieren würde.
<G-vec00279-002-s301><defeat.schlagen><en> Safina went on to defeat Serena Williams for the first time in the quarterfinals, ending Williams's 17-match winning streak. She then defeated Elena Dementieva in the final to win the first Tier I title of her career.
<G-vec00279-002-s301><defeat.schlagen><de> Etwas überraschend gewann sie daraufhin ihr Heimatturnier in Moskau; nach Siegen über Wiktoryja Asaranka und Dinara Safina konnte sie im Finale erstmals Serena Williams schlagen.
<G-vec00279-002-s302><defeat.schlagen><en> The true meaning of mastering martial arts in the work of sound spiritual schools consists not in gaining the ability to defeat enemies, but in overcoming one’s own weaknesses and shortcomings.
<G-vec00279-002-s302><defeat.schlagen><de> Der wahre Sinn und Zweck des Erlernens von Kampfkünsten in der Tradition gesunder spiritueller Schulen besteht nicht darin, die Gegner schlagen zu können, sondern darin, die eigenen Schwächen und Mängel zu überwinden.
<G-vec00279-002-s322><defeat.vereiteln><en> You can use your laser guns and rocket launchers to defeat the enemy.
<G-vec00279-002-s322><defeat.vereiteln><de> Sie können Ihre Laserpistolen und Raketenwerfer verwenden, um den Feind zu vereiteln.
<G-vec00279-002-s323><defeat.vereiteln><en> Many will be scared or confused but if the majority persists in demanding DD no minority can defeat it.
<G-vec00279-002-s323><defeat.vereiteln><de> Viele werden verwirrt und geängstigt, aber wenn die Mehrheit durchhält in ihrer Forderung nach DD, kann keine Minderheit dies vereiteln.
<G-vec00279-002-s324><defeat.vereiteln><en> (3) If the shared home has been surrendered in whole or in part to one life partner, the other life partner must refrain from everything that is suitable to render more difficult or defeat the exercise of this right of use.
<G-vec00279-002-s324><defeat.vereiteln><de> (3) Wurde einem Lebenspartner die gemeinsame Wohnung ganz oder zum Teil überlassen, so hat der andere alles zu unterlassen, was geeignet ist, die Ausübung dieses Nutzungsrechts zu erschweren oder zu vereiteln.
<G-vec00279-002-s325><defeat.vereiteln><en> The great controversy between Christ and Satan, that has been carried forward for nearly six thousand years, is soon to close; and the wicked one redoubles his efforts to defeat the work of Christ in man's behalf and to fasten souls in his snares.
<G-vec00279-002-s325><defeat.vereiteln><de> Gefährliche Schlingen Der große Streit zwischen Christo und Satan, der beinahe 6000 Jahre lang unterhalten worden ist, wird bald zu Ende gehen, und der Boshafte verdoppelt seine Bemühungen, Christi Werk für die Menschen zu vereiteln und Seelen in seinen Schlingen zu verstricken.
<G-vec00279-002-s326><defeat.vereiteln><en> Accepting is not defeat, although you have thought so.
<G-vec00279-002-s326><defeat.vereiteln><de> Bejahen ist nicht vereiteln, obschon du so gedacht hast.
<G-vec00279-002-s327><defeat.vereiteln><en> You must defeat the aliens before they invade the planet earth.
<G-vec00279-002-s327><defeat.vereiteln><de> Sie müssen die Aliens vereiteln, bevor sie in den Erdball einfallen.
<G-vec00279-002-s328><defeat.vereiteln><en> Whoso hath recognized Me will arise and serve Me with such determination that the powers of earth and heaven shall be unable to defeat his purpose.
<G-vec00279-002-s328><defeat.vereiteln><de> Wer Mich erkannt hat, wird aufstehen und Mir mit solcher Entschlossenheit dienen, daß die Mächte von Erde und Himmel sein Vorhaben nicht vereiteln können.
<G-vec00279-002-s329><defeat.vereiteln><en> (3)If one spouse has been permitted the use of the matrimonial home in whole or in part, the other spouse must refrain from everything that is suitable to render more difficult or defeat the exercise of this right of use.
<G-vec00279-002-s329><defeat.vereiteln><de> (3) Wurde einem Ehegatten die Ehewohnung ganz oder zum Teil überlassen, so hat der andere alles zu unterlassen, was geeignet ist, die Ausübung dieses Nutzungsrechts zu erschweren oder zu vereiteln.
<G-vec00279-002-s330><defeat.vernichten><en> Use your amazing powers to produce more batallions, defend your node with an awesome shield, boost the rage of your reptile warriors to defeat the enemy troops or to capture the enemy node faster, destroy your enemies with a big blast or freeze them to suffer a brutal impact in their scales.
<G-vec00279-002-s330><defeat.vernichten><de> Benutze deine unglaublichen Zauberkräfte, um mehr Kampftruppen zu schaffen, um deine Festung mit einem unglaublichen Schutzwall zu verteidigen, um die Wut deiner Reptilien zu erhöhen, um die Feindestruppen schneller zu vernichten oder die gegnerischen Festungen schneller zu erobern, um deine Gegner mit einer Riesenexplosion zu vernichten oder sie zeitweise einzufrieren, um eine brutale Auswirkung auf ihre Hautschuppen zu erwirken.
<G-vec00279-002-s331><defeat.vernichten><en> His aim is to defeat the boss of the aggressors applying different weapons and leaving heaps of bodies behind.
<G-vec00279-002-s331><defeat.vernichten><de> Er benutzt verschiedene Waffen und hinterlässt Berge von Leichen und strebt danach, die Anführer der Eindringlinge zu vernichten.
<G-vec00279-002-s332><defeat.vernichten><en> By downloading the APK of this game to your smartphone or tablet, you'll relive the adventures in which you used to take part playing with Sonic and his inseparable Tails in order to defeat the evil Dr. Eggman and dozens of new final bosses created specifically for the occasion in this Sonic The Hedgehog 2 for mobile devices.
<G-vec00279-002-s332><defeat.vernichten><de> Indem Sie sich die APK des Spiels auf Ihr Smartfone oder Tablet downloaden, erleben Sie die Abenteuer neu, in denen Sie mit Sonic und seinem unzertrennlichen Tails gespielt haben, um den bösen Dr Eggman und Dutzende von Endbossen zu vernichten, die speziell für den Anlass in diesem Sonic The Hedgehog 2 für Mobilgeräte kreiert wurden.
<G-vec00279-002-s333><defeat.vernichten><en> Create alliances with other ninjas to defeat your enemies.
<G-vec00279-002-s333><defeat.vernichten><de> Gründen Sie Allianzen mit anderen Ninjas, um Ihre Feinde zu vernichten.
<G-vec00279-002-s334><defeat.vernichten><en> - Forge an alliance, cooperate with teammates and devise strategies to defeat your rivals.
<G-vec00279-002-s334><defeat.vernichten><de> - Schließe eine Allianz, kooperiere mit Kameraden und plant gemeinsam Strategien, um eure Rivalen zu vernichten.
<G-vec00279-002-s335><defeat.vernichten><en> In this occasion both Harry as well as his mentor Dumbledore will have to face a series of very dangerous challenges while they search for a way to defeat Voldemort.
<G-vec00279-002-s335><defeat.vernichten><de> Bei dieser Gelegenheit müssen sowohl Harry als auch sein Mentor Dumbledore eine Reihe von Herausforderungen bestehen, während sie nach einem Weg suchen, um Voldemort zu vernichten.
<G-vec00279-002-s336><defeat.vernichten><en> Lead your squad to defeat the Fallen Nun and restore balance to the World in this epic tactical action game!
<G-vec00279-002-s336><defeat.vernichten><de> Führe Deine Einheit in dieses epische, taktische Action-Spiel, um die gefallene Nonne zu vernichten und das Gleichgewicht auf der Welt wieder herzustellen.
<G-vec00279-002-s349><defeat.überwinden><en> Your men were not able to defeat the fiendish bandits of Wild Mary.
<G-vec00279-002-s349><defeat.überwinden><de> Euren Männern war es nicht möglich, Waltrauts hinterhältige Schurken zu überwinden.
<G-vec00279-002-s350><defeat.überwinden><en> Why we can be discouraged, and how we can defeat it.
<G-vec00279-002-s350><defeat.überwinden><de> Wie wir entmutig werden können und wie wir sie überwinden können.
<G-vec00279-002-s351><defeat.überwinden><en> Only by joining forces will we be able to defeat gender-based violence.
<G-vec00279-002-s351><defeat.überwinden><de> Nur wenn wir unsere Anstrengungen bündeln, wird es uns möglich sein, die Gewalt gegen Frauen zu überwinden.
<G-vec00279-002-s352><defeat.überwinden><en> Also, we live to be able to forgive and defeat grudges and let love win.
<G-vec00279-002-s352><defeat.überwinden><de> Wir leben, um vergeben zu können, um Groll zu überwinden und um die Liebe siegen zu lassen.
<G-vec00279-002-s353><defeat.überwinden><en> Indeed, the work of public historians should not only be reactive, that is, aiming to defeat the construction of national legends.
<G-vec00279-002-s353><defeat.überwinden><de> In der Tat sollte die Arbeit von Public Historians nicht bloß reaktiv sein, d. h. die Konstruktion von nationalen Legenden überwinden.
<G-vec00279-002-s354><defeat.überwinden><en> However, on the just same day, DVDFab finds its way to defeat the strongest BD+ to support Avatar.
<G-vec00279-002-s354><defeat.überwinden><de> Aber am gleichen Tag fand DVDFab die Lösung, diesen stärksten BD+ zu überwinden und damit Avatar zu unterstützen.
<G-vec00279-002-s355><defeat.überwinden><en> These three simple daily practices will help you defeat those negative thoughts so that you can connect back with Happy You.
<G-vec00279-002-s355><defeat.überwinden><de> Diese simplen drei Techniken helfen dir, negative Gedanken zu überwinden sodass Du Dich wieder mit Deinem Happy You verbinden kannst.
<G-vec00279-002-s356><defeat.überwinden><en> Notwithstanding such measures, the Internet is an open system and we cannot guarantee that unauthorized third parties will never be able to defeat those measures or use your personal information for improper purposes.
<G-vec00279-002-s356><defeat.überwinden><de> Ungeachtet solcher Maßnahmen stellt das Internet ein offenes System dar und wir können nicht garantieren, dass unberechtigte Dritte es niemals schaffen werden, diese Maßnahmen zu überwinden oder Ihre personenbezogenen Informationen für missbräuchliche Zwecke zu nutzen.
<G-vec00279-002-s357><defeat.überwinden><en> The Socialists and Democrats in the European Parliament are organising a conference to discuss how Europe can defeat rising extremism by increasing openness in its societies.
<G-vec00279-002-s357><defeat.überwinden><de> Die Sozialdemokratische Fraktion im Europäischen Parlament veranstaltet eine Konferenz, um über die Frage zu diskutieren, wie Europa den zunehmenden Extremismus durch mehr Offenheit in seinen Gesellschaften überwinden kann.
<G-vec00279-002-s358><defeat.überwinden><en> Thus let us scatter over every people the treasured gems of the recognition of God, and with the decisive blade of the tongue, and the sure arrows of knowledge, let us defeat the hosts of self and passion, and hasten onward to the site of martyrdom, to the place where we die for the Lord.
<G-vec00279-002-s358><defeat.überwinden><de> So laßt uns die Juwelenschätze der Gotterkenntnis über alle Völker ausstreuen, mit der scharfen Klinge der Zunge, mit des Wissens zielsicheren Pfeilen laßt uns die Scharen des Selbstes und der Leidenschaft überwinden und vorwärtsstürmen zur Stätte des Martyriums, dem Ort, wo wir für den Herrn sterben.
<G-vec00279-002-s359><defeat.überwinden><en> Knowledge is an important way to reassure yourself that depression is real, that it is a concern to be treated with seriousness, and that there are many ways to defeat it.
<G-vec00279-002-s359><defeat.überwinden><de> Das gesammelte Fachwissen gibt dir persönlich auch die Sicherheit, dass deine Depressionen real sind, dass es sich bei ihnen um einen schwierigen Zustand handelt, der man mit aller Ernsthaftigkeit behandelt werden muss, und dass es viele Möglichkeiten gibt, um diesen Zustand zu überwinden.
