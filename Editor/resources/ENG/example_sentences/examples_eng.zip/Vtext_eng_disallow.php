<G-vec00050-002-s011><disallow.ablehnen><en> If you do not want your computer to be recognized on your next visit, you can also disallow the use of cookies by changing the settings in your browser to ‘do not allow cookies’.
<G-vec00050-002-s011><disallow.ablehnen><de> Wenn Sie nicht möchten, dass Ihr Computer beim nächsten Besuch wiedererkannt wird können Sie die Verwendung von Cookies auch ablehnen indem Sie die Einstellungen in Ihrem Browser auf „Cookies ablehnen" ändern.
<G-vec00050-002-s014><disallow.ablehnen><en> Thus, in front of a strong opposition of this one, President Roosevelt and the Congress disallow a proposal aiming, in 1939, to accommodate 20 000 European Jewish children.
<G-vec00050-002-s014><disallow.ablehnen><de> So vor einer starken Opposition derselben lehnen Präsident Roosevelt und der Kongreß einen Vorschlag ab, der darauf abzielt, im Jahre 1939, 20.000 europäische jüdische Kinder zu empfangen.
<G-vec00050-002-s024><disallow.ablehnen><en> You can accept or reject cookies on a case by case basis, or disallow all cookies.
<G-vec00050-002-s024><disallow.ablehnen><de> Sie können Cookies jeweils im Einzelfall annehmen oder ablehnen oder alle Cookies ablehnen.
<G-vec00050-002-s035><disallow.verweigern><en> When you disallow 'image' you will disallow all types of images like 'image/jpeg' or 'image/vasa'.
<G-vec00050-002-s035><disallow.verweigern><de> Wenn man 'image' verweigert, werden alle Typen von Bildern verweigert wie 'image/jpeg' oder 'image/vasa'.
