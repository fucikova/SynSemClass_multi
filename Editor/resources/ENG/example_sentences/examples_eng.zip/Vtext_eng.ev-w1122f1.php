<EnglishT-wsj_1927-s14#EnglishT-wsj_1927-s14-t16><ev-w1122f1.v-w8800f5_ZU> Sen. Kennedy, never mind his dubious credentials for the moral high ground, <start_vs>emoted<end_vs> brilliantly. 
