<G-vec00514-002-s023><conceal.abdecken><en> Gather the tools and makeup required to conceal these problem areas.
<G-vec00514-002-s023><conceal.abdecken><de> Besorge dir die nötigen Hilfsmittel, um diese Problemzonen abzudecken.
<G-vec00514-002-s047><conceal.geheimhalten><en> The agent's threat was an attempt to conceal the illegal detainment and interrogation of a U.S. citizen.
<G-vec00514-002-s047><conceal.geheimhalten><de> Die Drohung des Agenten war ein Versuch, die illegale Festnahme und das Verhör einer US Bürgerin geheim zu halten.
<G-vec00514-002-s061><conceal.hinwegtäuschen><en> The drop in the number of anti-Semitic acts in recent years can't conceal the hatred of Jews that has long been prevalent in many mosques, schools and neighbourhoods.
<G-vec00514-002-s061><conceal.hinwegtäuschen><de> Der jüngst verzeichnete Rückgang antisemitischer Taten kann nicht über den Judenhass hinwegtäuschen, der seit langem in vielen Moscheen, Schulen und Vierteln herrscht.
<G-vec00514-002-s029><conceal.kaschieren><en> If you tend to conceal skin imperfections using foundation, BB cream is the best choice for you.
<G-vec00514-002-s029><conceal.kaschieren><de> Wenn Sie bisher eine Grundierung verwendet haben, um Hautunebenheiten zu kaschieren, ist die BB-Creme für Sie am besten geeignet.
<G-vec00514-002-s085><conceal.lagern><en> The pigments build up on the hair's surface with each wash to conceal first grey hairs and lighter roots and also nourish the hair structure.
<G-vec00514-002-s085><conceal.lagern><de> Bei jeder Haarwäsche lagern sich Farbstoffe an der Haaroberfläche an und sorgen so dafür, dass erste graue Haare kaschiert werden und die Haarstruktur zusätzlich gepflegt wird.
<G-vec00514-002-s086><conceal.lassen><en> If you have very short hair, you may contemplate to grow them a little longer over a transition period in order to conceal the scars until they’re fully faded and healed.
<G-vec00514-002-s086><conceal.lassen><de> Wenn Sie sehr kurze Haare haben, sollten Sie überlegen, ob Sie diese übergangsweise ein wenig länger wachsen lassen, bis die Narben verblasst und verheilt sind.
<G-vec00514-002-s087><conceal.lassen><en> These types of loans attract the attention of tax investigators because they are often used to conceal income or gifts by cloaking them in the form of loans to sneak them past the fiscal authorities.
<G-vec00514-002-s087><conceal.lassen><de> Solche Kredite lassen Steuerfahnder hellhörig werden, denn sie sind ein Hinweis darauf, dass Einkünfte oder Geschenke als Darlehen getarnt und damit an der Steuer vorbeigeschleust werden sollen.
<G-vec00514-002-s088><conceal.lassen><en> Any hypertext link to the website and using the technique of "framing" (Technical programming with the ability to split a browser window into multiple autonomous frames in order to display the content of external sites) or "in-line linking" process (to appear on a web page to extract just one element to another site, which saves storage space on the hard disk of the machine that hosts the site, which has the effect to conceal from an unsuspecting user's original environment to which this element belongs) is strictly prohibited.
<G-vec00514-002-s088><conceal.lassen><de> Jede Art von Hypertext-Link, der auf die Webseite führt und die Technik des „Framing“ verwendet (eine Programmierungstechnik mit der Möglichkeit das Webbrowserfenster in mehrere autonome Rahmen zu zerlegen, um den Inhalt einer außenstehenden Webseite anzuzeigen) oder die Technik des „In-line-Linking“ (Verfahren, um auf einer Webseite ein einziges Elemente aus einer anderen Webseite erscheinen zu lassen, was Speicherplatz auf der Festplatte des Computer spart, auf dem die Webseite gehostet wird.
<G-vec00514-002-s143><conceal.sich_verbergen><en> Intuitive user guidance and ergonomics conceal the complex interaction of software with mechanical systems and electronics.
<G-vec00514-002-s143><conceal.sich_verbergen><de> Hinter intuitiver Bedienerführung und Ergonomie verbirgt sich ein Zusammenspiel von Software mit komplexer Mechanik und Elektronik.
<G-vec00514-002-s100><conceal.stecken><en> They learned that errors and deviations from the norm always conceal an opportunity.
<G-vec00514-002-s100><conceal.stecken><de> Sie lernten, dass in Fehlern, in Abweichungen von der Norm, immer auch eine Chance steckt.
<G-vec00514-002-s101><conceal.stecken><en> The modules with drawers and doors might instantly catch the eye, but they still carefully conceal their contents.
<G-vec00514-002-s101><conceal.stecken><de> So fallen die Module mit Schublade und Tür sofort auf, zeigen aber trotzdem nicht, was alles in ihnen steckt.
<G-vec00514-002-s102><conceal.stecken><en> Packaging items often conceal a great deal of expertise that is not apparent at first sight.
<G-vec00514-002-s102><conceal.stecken><de> Oft steckt in Verpackungen eine Menge Know-how, die auf den ersten Blick nicht ersichtlich ist.
<G-vec00514-002-s103><conceal.umgehen><en> But these formulas, which became known as "welfare state", despite their successes, failed to prevent even for a moment or to reverse the structural trends of the system, and even, although they achieved to regulate or conceal them, generated new contradictions.
<G-vec00514-002-s103><conceal.umgehen><de> Aber diese Formeln, die als "Sozialstaat" bekannt geworden sind, vermochten es, trotz ihrer Erfolge, zu keiner Zeit, die strukturellen Tendenzen des Systems zu umgehen oder rückgängig zu machen und erzeugten sogar neue Widersprüche, wenngleich sie diese auch zu regulieren und zu vertuschen vermochten.
<G-vec00514-002-s104><conceal.unterschlagen><en> These images conceal nothing of a reality that’s mixed, imperfect, fleeting when it’s joyous.
<G-vec00514-002-s104><conceal.unterschlagen><de> Diese Bilder unterschlagen nichts von einer Wirklichkeit, die gemischt, unvollkommen, flüchtig ist, wenn sie beglückt.
<G-vec00514-002-s105><conceal.unterschlagen><en> This is how we differentiate ourselves from the populists who conceal the idea that the majority of existing problems can be better solved on the national, regional or local level.
<G-vec00514-002-s105><conceal.unterschlagen><de> Darin unterscheiden wir uns von den Populisten, die unterschlagen, dass ein Großteil der bestehenden Probleme besser auf nationaler, regionaler oder kommunaler Ebene gelöst werden kann.
<G-vec00514-002-s282><conceal.verbergen><en> Lamellae configured in parallel or as a grid also conceal luminaires.
<G-vec00514-002-s282><conceal.verbergen><de> Lamellen – parallel oder als Raster – verbergen ebenfalls die Leuchten.
<G-vec00514-002-s155><conceal.verdecken><en> Kalypso means “she that conceals” and “she who hides” (from Greek “kalypto/to conceal/to cover).
<G-vec00514-002-s155><conceal.verdecken><de> Kalypso bedeutet “die sich Verbergende”, “die Versteckerin” (von griechisch “kalypto/verdecken/bedecken/verbergen).
<G-vec00514-002-s169><conceal.verhehlen><en> To Him is the arrival. [64.4] He knows whatever is in the heavens and the earth and He knows all what you conceal and what you reveal.
<G-vec00514-002-s169><conceal.verhehlen><de> [64.4] Er wei├č, was in den Himmeln und auf Erden ist, und Er wei├č, was ihr verhehlt und was ihr offenbart; und Allah kennt alles, was in den Herzen ist.
<G-vec00514-002-s170><conceal.verhehlen><en> When you go to fight for My cause and seek My pleasure, you secretly express your love of them. I know best what you reveal or conceal.
<G-vec00514-002-s170><conceal.verhehlen><de> Wenn ihr ausgezogen seid zum Kampf für Meine Sache und im Trachten nach Meinem Wohlgefallen, sendet ihr ihnen insgeheim Botschaften der Liebe, wenn Ich doch am besten weiß, was ihr verhehlt und was ihr offenbart.
<G-vec00514-002-s171><conceal.verheimlichen><en> I have never concealed this and do not conceal it now.
<G-vec00514-002-s171><conceal.verheimlichen><de> Ich habe das nicht verheimlicht und verheimliche es nicht.
<G-vec00514-002-s194><conceal.verhüllen><en> Every evening, when the sun rays conceal its shine, the outdoor pool complex opens its doors to charm its guests with its beauty and night glamour.
<G-vec00514-002-s194><conceal.verhüllen><de> Jeden Abend, wenn die Sonnenstrahlen ihren Glanz verhüllen, öffnet der Schwimmbadkomplex seine Pforten und begeistert die Besucher mit all seiner Schönheit und seinem Nachtglamour.
<G-vec00514-002-s195><conceal.verhüllen><en> The same applies to the images in which prosthetic limbs and masks replace or conceal presence.
<G-vec00514-002-s195><conceal.verhüllen><de> Ebenso verhält es sich mit den Bildern, in welchen Prothesen und Masken die Anwesenheit ersetzen oder verhüllen.
<G-vec00514-002-s210><conceal.verschleiern><en> They also conceal the agreements to install optional downloads under the traditional ”standard” or ”default” installation settings.
<G-vec00514-002-s210><conceal.verschleiern><de> Verschleiern Sie auch die Vereinbarungen zum installieren von optionalen downloads im Rahmen der traditionellen “standard” oder “default” – installation Einstellungen.
<G-vec00514-002-s230><conceal.verschweigen><en> Although I tried to conceal them, the doctor noticed the marks on my body even after such a long time.
<G-vec00514-002-s230><conceal.verschweigen><de> Obwohl ich es verschwieg, stellte der Arzt nach so langer Zeit an meinem Körper Markierungen fest.
<G-vec00514-002-s252><conceal.verstecken><en> These conceal underlying content, significantly diminishing the web browsing experience.
<G-vec00514-002-s252><conceal.verstecken><de> Daher verstecken sie gewöhnlich darunterliegende Inhalte von Webseiten, wodurch sich die Surferfahrung verringert.
<G-vec00514-002-s259><conceal.verstellen><en> We may take it, therefore, that the letter was composed by an educated man who wished to pose as an uneducated one, and his effort to conceal his own writing suggests that that writing might be known, or come to be known, by you.
<G-vec00514-002-s259><conceal.verstellen><de> Deshalb können wir davon ausgehen, dass der Brief von einem gebildeten Menschen verfasst wurde, der den Anschein erwecken wollte, als sei er ungebildet, und die Mühe, seine Handschrift zu verstellen, lässt vermuten, dass die Handschrift Ihnen bekannt ist oder werden könnte.
<G-vec00514-002-s129><conceal.vertuschen><en> An additive is absolutely not to be used in order to conceal defective processing or cover up any bad qualities of raw materials.
<G-vec00514-002-s129><conceal.vertuschen><de> Schon gar nicht darf ein Zusatzstoff verwendet werden, um eine fehlerhafte Verarbeitung zu verbergen oder schlechte Qualitäten der Rohstoffe zu vertuschen.
<G-vec00514-002-s099><conceal.verwischen><en> All e-mails sent by the virus are deleted to conceal its movements.
<G-vec00514-002-s099><conceal.verwischen><de> Um alle Spuren zu verwischen werden alle vom Virus versendeten E-mails gelöscht.
<G-vec00514-002-s273><conceal.vorenthalten><en> Many such persons are motivated by a wish to conceal from the rest of us the relatively recent events which have created the world as it is today.
<G-vec00514-002-s273><conceal.vorenthalten><de> Viele sind dabei von dem Wunsch erfüllt, uns jene verhältnismäßig neuen Vorgänge vorzuenthalten, die die Welt von heute geformt haben.
<G-vec00514-002-s274><conceal.wegreden><en> Hence the discontent, the grave crisis that the leaders of the fascist union movement have been unable to conceal at their recent meetings.
<G-vec00514-002-s274><conceal.wegreden><de> Daher die Unzufriedenheit, die schwere Krise, die die Führer der faschistischen Gewerkschaftsbewegung in den Versammlungen der letzten Zeit nicht mehr weg reden konnten.
<G-vec00514-002-s278><conceal.überdecken><en> Environment Fifty to a hundred years ago, people used to use something called whitewash on their outside walls, to conceal dirt and cracks and make it all look better.
<G-vec00514-002-s278><conceal.überdecken><de> Greenwashing und wie man über Siegel besser Bescheid weiß Umwelt Vor 50-100 Jahren haben Leute Kalkanstrich, auf Englisch „whitewash“, an ihren Außenwänden benutzt, um Dreck und Risse zu überdecken, damit sie besser aussiehen.
<G-vec00514-002-s279><conceal.überspielen><en> Since this is only acceptable in the case of inexperienced speakers (as one could frequently observe at the DNC), all the others must try to conceal their natural anxiety and tension in this situation.
<G-vec00514-002-s279><conceal.überspielen><de> Da das allerdings nur bei ungeübten SprecherInnen akzeptiert wird (wie bei der DNC des öfteren zu beobachten), müssen alle anderen versuchen, ihre natürliche Angst und Angespanntheit in dieser Situation zu überspielen.
