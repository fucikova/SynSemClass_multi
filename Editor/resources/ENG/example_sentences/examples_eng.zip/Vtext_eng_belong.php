<G-vec00366-002-s057><belong.angehören><en> They insisted that I was a dangerous socialist. The whole business was so offensive, so clearly a discrimination against the Russian revolutionaries, in contrast to the treatment accorded other passengers not so unfortunate as to belong to a nation allied to England, that some of the Russians sent a violent protest to the British authorities.
<G-vec00366-002-s057><belong.angehören><de> Die ganze Untersuchung trug einen so entwürdigenden Charakter und stellte die russischen Revolutionäre so offensichtlich unter einen Ausnahmezustand im Vergleich zu den anderen Passagieren, die nicht das Unglück hatten, einer England verbündeten Nation anzugehören, daß einige der Verhörten an Ort und Stelle an die englische Regierung einen energischen Protest gegen das Benehmen der englischen Polizeiagenten absandten.
<G-vec00366-002-s058><belong.angehören><en> A: You must know that our crime is being Palestinian, to belong to Palestine.
<G-vec00366-002-s058><belong.angehören><de> A: Natürlich, unser Verbrechen besteht darin, Palästinenser zu sein und Palästina anzugehören.
<G-vec00366-002-s059><belong.angehören><en> And I’m happy to belong to a community that doesn’t want to be silent.
<G-vec00366-002-s059><belong.angehören><de> Und ich bin glücklich, einer Community anzugehören, die nicht schweigen will.
<G-vec00366-002-s060><belong.angehören><en> The 'Universal Declaration of Human Rights' (UDHR), valid in Andorra, clearly states: “No one may be compelled to belong to an association.“ But that's what the law demands, namely the compulsory establishment of associations.
<G-vec00366-002-s060><belong.angehören><de> Die in Andorra gültige 'Allgemeine Erklärung der Menschenrechte' (AEMR) legt eindeutig fest: „Niemand darf gezwungen werden, einer Vereinigung anzugehören.“ Aber genau das fordert das Gesetz, nämlich die Gründung von Zwangsassoziationen.
<G-vec00366-002-s061><belong.angehören><en> Varieties of coloured light bound up with matter appear in many places to communicate with each other, belong to a cycle or determine the orientation of the painting.
<G-vec00366-002-s061><belong.angehören><de> Verschieden farbiges Licht, gebunden an die Materie, scheint vielerorts miteinander zu kommunizieren, einem Kreislauf anzugehören oder eine Richtung im Bild zu bestimmen.
<G-vec00366-002-s062><belong.angehören><en> But you need not to lose; you can defend yourselves any time through your free will to belong to me forever; and any time you can call on me for help.
<G-vec00366-002-s062><belong.angehören><de> Aber ihr brauchet nicht zu unterliegen, ihr könnet euch wehren jederzeit durch euren freien Willen, Mir anzugehören auf ewig, und ihr könnet jederzeit Mich um Beistand anrufen.
<G-vec00366-002-s063><belong.angehören><en> 3 Every person has the right to join or to belong to a religious community, and to follow religious teachings.
<G-vec00366-002-s063><belong.angehören><de> 3 Jede Person hat das Recht, einer Religionsgemeinschaft beizutreten oder anzugehören und religiösem Unterricht zu folgen.
<G-vec00366-002-s064><belong.angehören><en> In the history of mankind, we are the first people lucky enough to belong to a generation that can realise this human dream in its simplest and purest form.
<G-vec00366-002-s064><belong.angehören><de> Doch gerade wir haben das Glück, der ersten Generation anzugehören, die sich diesen Menschheitstraum in seiner einfachsten und reinsten Form erfüllen kann.
<G-vec00366-002-s065><belong.angehören><en> The wish to overcome death may seem unrealistic or belong to the sphere of religion, rather than serious science.
<G-vec00366-002-s065><belong.angehören><de> Der Wunsch nach Überwindung des Todes mag unrealistisch erscheinen oder eher dem Bereich der Religion und des Glaubens anzugehören als der seriösen Wissenschaft.
<G-vec00366-002-s066><belong.angehören><en> The members of the Protestant Free Church refuse to belong to a “state church”, they are the defenders of a clear separation of church and state and deny also the financing of the church over the church tax.
<G-vec00366-002-s066><belong.angehören><de> Die Mitglieder der evangelischen Freikirche lehnen es ab, einer „Staatskirche“ anzugehören, sie sind die Verfechter einer klaren Trennung von Kirche und Staat und verneinen auch die Finanzierung der Kirche über die Kirchensteuer.
<G-vec00366-002-s067><belong.angehören><en> As it is not a crime in Sweden to belong to, or support, a terrorist organization, Austrian authorities decided to keep the 17-year-old in custody in Austria and charge her there.
<G-vec00366-002-s067><belong.angehören><de> Da es in Schweden kein Verbrechen ist einer Terrororganisation anzugehören oder sie zu unterstützen, entschieden die österreichischen Behörden die 17-jährige in Österreich in Haft zu behalten und sie anzuklagen.
<G-vec00366-002-s068><belong.angehören><en> You confirm your order to belong to this group of customers
<G-vec00366-002-s068><belong.angehören><de> Sie bestätigen mit Ihrer Bestellung, diesem Kundenkreis anzugehören.
<G-vec00366-002-s069><belong.angehören><en> “I am entirely yours, most Holy Virgin, that I may more perfectly belong to God.”
<G-vec00366-002-s069><belong.angehören><de> « Ich bin ganz dein, o heilige Jungfrau, um noch vollkommener Gott anzugehören ».
<G-vec00366-002-s070><belong.angehören><en> Through the eyes of Torsten, we get to experience all facets of what it truly means to belong to a skate crew.
<G-vec00366-002-s070><belong.angehören><de> Durch Torstens Blick erfahren wir in allen Facetten, was es bedeutet und wie es sich anfühlt, einer Skate Crew anzugehören.
<G-vec00366-002-s071><belong.angehören><en> It may well be the case that they are even anxious not to belong to such parties or even to discuss with the leaders of such parties the kind of things that they and their movements no longer find attractive.
<G-vec00366-002-s071><belong.angehören><de> Möglicherweise sind die politischen Aktivisten sogar darauf bedacht, solchen Parteien eben gerade nicht anzugehören, ja nicht einmal mit ihrer jeweiligen Führung über deren für sie und ihre Bewegung nicht mehr relevanten Ideen und Ziele zu sprechen.
<G-vec00366-002-s072><belong.angehören><en> Consequently, Hesse's "Glass Bead Game" again tells us about the revolt of an individual, finding his truth far from all truths and religions. 83 year old Hesse wrote: "For the majority of people it's very useful to belong to a church or a religion.
<G-vec00366-002-s072><belong.angehören><de> Hesses Glasperlenspiel handelt darum wiederum von der Revolte eines einzelnen, der seine eigene Wahrheit, fern aller Kollektive, auch der Konfessionen und Religionen, findet: „Für die Mehrheit der Menschen ist es sehr gut, einer Kirche und einem Glauben anzugehören.
<G-vec00366-002-s073><belong.angehören><en> Represented in the first-born is the people of the covenant, ransomed from slavery in order to belong to God.
<G-vec00366-002-s073><belong.angehören><de> Im Erstgeborenen war das Volk des Alten Bundes verkörpert, das aus der Sklaverei freigekauft worden war, um Gott anzugehören.
<G-vec00366-002-s100><belong.dazugehören><en> She calls her education the „darkness of serious music“ where she first tried to belong, then to break free with the help of lo-fi synth pop.
<G-vec00366-002-s100><belong.dazugehören><de> Ihre Ausbildung bezeichnet sie als "darkness of serious music", zu der sie zunächst dazugehören wollte, sie dann aber als Ketten empfand, die sie mit ihrem Lofi Synth Pop abzuwerfen vesuchte.
<G-vec00366-002-s101><belong.dazugehören><en> I used the website to learn more about the history of the EU and which countries belong to it.
<G-vec00366-002-s101><belong.dazugehören><de> Ich habe hier ziemlich viel über die Geschichte der EU gelernt - und welche Länder dazugehören.
<G-vec00366-002-s102><belong.dazugehören><en> In the end, about 40 students from different disciplines will belong to the team.
<G-vec00366-002-s102><belong.dazugehören><de> Etwa 40 Studierende unterschiedlicher Fachrichtungen werden letztlich dazugehören.
<G-vec00366-002-s103><belong.dazugehören><en> It is not just immensely painful to live in this reality, it also prevents us from creating the world we want to live in by being who we really are, giving what we have to give, asking for what we need, enjoying the gifts that we get and trusting that we belong,
<G-vec00366-002-s103><belong.dazugehören><de> Sie ist nicht nur extrem schmerzhaft, sie hält uns auch davon ab, die Welt zu kreieren, in der wir leben wollen - indem wir ganz wir selber sind, geben, was wir zu geben haben, um das bitten, was wir brauchen, die Geschenke genießen, die wir bekommen und vertrauen, dass wir dazugehören.
<G-vec00366-002-s104><belong.dazugehören><en> Maybe because I left Israel, maybe because after you leave borders, family and friends behind, you want to be belong to something.
<G-vec00366-002-s104><belong.dazugehören><de> Vielleicht, weil ich Israel verlassen habe, vielleicht deshalb, du zu etwas dazugehören willst, nachdem du Grenzen, Familie und FreundInnen hinter dir gelassen hast.
<G-vec00366-002-s105><belong.dazugehören><en> But there are constantly little everyday moments that make me doubt whether I'm really allowed to belong here.
<G-vec00366-002-s105><belong.dazugehören><de> Es sind aber immer wieder die kleinen Momente im Alltag, die mich daran zweifeln lassen, dass ich wirklich dazugehören darf.
<G-vec00366-002-s106><belong.dazugehören><en> It is clear that masculine jewellery accessories today simply belong to the styling of many men.
<G-vec00366-002-s106><belong.dazugehören><de> Fest steht, dass maskuline Schmuck-Accessoires heute zum Styling vieler Männer einfach dazugehören.
<G-vec00366-002-s107><belong.dazugehören><en> Homophobia and Transphobia are redefined as the problems of youth of colour who apparently don’t speak proper German, whose Germanness is always questioned, and who simply don’t belong.
<G-vec00366-002-s107><belong.dazugehören><de> Homophobie und Transphobie werden hier als Probleme von Jugendlichen of Colour umdefiniert, die anscheinend nicht richtig Deutsch können, deren Deutschsein immer hinterfragt bleibt, und die schlicht nicht dazugehören.
<G-vec00366-002-s108><belong.dazugehören><en> And want to belong.
<G-vec00366-002-s108><belong.dazugehören><de> Und dazugehören wollen.
<G-vec00366-002-s109><belong.dazugehören><en> Now I wanted to risk it again, wanted to belong to somewhere, to contribute time, energy, skills for God’s ministry.
<G-vec00366-002-s109><belong.dazugehören><de> Nun wollte ich es noch einmal wagen, wollte zu etwas dazugehören, Zeit, Energie, Können für Gottes Dienst einbringen.
<G-vec00366-002-s110><belong.dazugehören><en> Any ever so small publication always includes, aside from the prospect of fulfilment of certain wishes and longings, a certain amount of defamation of other offers, what is more, the exclusiveness of the offer shows the difference between those few fortunate enough to belong, and the many pitiable package tourists.
<G-vec00366-002-s110><belong.dazugehören><de> Jede noch so kleine Veröffentlichung beinhaltet neben der Aussicht auf Erfüllung bestimmter Wünsche und Sehnsüchte immer auch eine gewisse Diffamierung anderer Angebote, darüber hinaus verweist die Exklusivität des Angebots auf das Gefälle zwischen den wenigen glücklichen, die dazugehören und den vielen bedauernswerten Pauschaltouristen.
<G-vec00366-002-s111><belong.dazugehören><en> Because I am deeply convinced that I am a child of God, I also have a lot of motivation to do my work well and to tackle even unloved tasks, which belong everywhere.
<G-vec00366-002-s111><belong.dazugehören><de> Weil ich zutiefst davon überzeugt bin, ein Kind Gottes zu sein, habe ich auch viel Motivation, meine Arbeit gut zu machen und selbst ungeliebte Aufgaben, die ja überall dazugehören, in Angriff zu nehmen.
<G-vec00366-002-s112><belong.dazugehören><en> Belong: Having a sense of belonging is probably one of the most gratifying human experience.
<G-vec00366-002-s112><belong.dazugehören><de> Dazugehören: Das Gefühl von Zugehörigkeit ist wahrscheinlich eine der befriedigendsten Erfahrungen des Menschen.
<G-vec00366-002-s244><belong.gehören><en> Ozawa and Aida (picture) both belong to the Group 1965, whose name refers to the members' year of birth (more here and here).
<G-vec00366-002-s244><belong.gehören><de> Ozawa und Aida (Bild) gehörten beide der Gruppe 1965 an, deren Name auf das Geburtsjahr der Mitglieder verwies (mehr hier und hier).
<G-vec00366-002-s245><belong.gehören><en> It's very likely that these domains used to belong to shoe brands and/or sellers.
<G-vec00366-002-s245><belong.gehören><de> Es ist sehr wahrscheinlich, dass diese Domains früher zu Schuhmarken und/oder Verkäufern gehörten.
<G-vec00366-002-s246><belong.gehören><en> They actually belong to the first ever artists to play this kinda music.
<G-vec00366-002-s246><belong.gehören><de> Sie gehörten zu den ersten Künstlern, die diesen Trend ins Leben gerufen haben Anfang der Neunziger Jahre.
<G-vec00366-002-s247><belong.gehören><en> To frame it drastically, you could say that behind all this is the fear of dying, because this is exactly what happened in former times, when people did not belong to a tribe and were not surrounded by tribe brothers and sisters.
<G-vec00366-002-s247><belong.gehören><de> Drastisch ausgedrückt könnte man sagen, dahinter steckt die Angst zu sterben, denn das ist genau das, was früher passierte, wenn wir Menschen nicht zu einem Stamm gehörten und von Stammesbrüdern- und Schwestern umgeben waren.
<G-vec00366-002-s248><belong.gehören><en> One night we had an argument and Karl said that once the party takes over the government, if we did not belong to the Nazi party, we would starve.
<G-vec00366-002-s248><belong.gehören><de> Eine Nacht hatten wir ein Argument, und Karl sagte, dass sobald die Partei die Regierung übernimmt, wenn wir nicht zur Nazipartei gehörten, würden wir hungern.
<G-vec00366-002-s249><belong.gehören><en> But also the shady tricks and the paradoxes of history, including the history of the Church belong to the facts.
<G-vec00366-002-s249><belong.gehören><de> Aber zu den Fakten gehörten ebenfalls die Winkelzüge und Paradoxien der Geschichte, auch der Kirchengeschichte.
<G-vec00366-002-s250><belong.gehören><en> Therefore, in the minds of Amnesty International, forensic experts coming to different conclusions than eyewitnesses do indeed belong in jail.
<G-vec00366-002-s250><belong.gehören><de> Daher gehörten nach Ansicht von Amnesty International Gerichtsgutachter, die zu anderen Schlussfolgerungen kommen als Augenzeugen, tatsächlich ins Gefängnis.
<G-vec00366-002-s251><belong.gehören><en> Most of those ministers did not belong to the most fortunate classes that would resort to painters and engravers, and photography was not available yet.
<G-vec00366-002-s251><belong.gehören><de> Die meisten von ihnen gehörten nicht zu den obersten Schichten der Gesellschaft, in denen man gerne und leicht auf Maler und Graveure Zugriff hatte, und die erschwinglichere Photographie stand noch nicht zur Verfügung.
<G-vec00366-002-s252><belong.gehören><en> Stealing, deception, and racketeering belong to the past.
<G-vec00366-002-s252><belong.gehören><de> Diebstahl, Betrug und Gaunereien gehörten der Vergangenheit an.
<G-vec00366-002-s253><belong.gehören><en> Therefore, questions about the way economic resources were to be allocated did not belong to the public realm[60], except to the extent that they referred to the setting of social controls to regulate the limited market or to the financing of "public" spending.
<G-vec00366-002-s253><belong.gehören><de> Daher gehörten (wie Aristoteles explizit bemerkte[119]) Fragen nach der wünschenswerten Art der Ressourcenallokation nicht in den öffentlichen Bereich, sofern es dabei nicht um die Etablierung sozialer Kontrollmechanismen zur Regulierung des begrenzten Marktes oder die Finanzierung „öffentlicher“ Ausgaben ging.
<G-vec00366-002-s254><belong.gehören><en> People, from whom it becomes known only after their accession, that they either already belong to the excluded group of people or have been added afterwards, subsequently must be removed after written consultation by removal from the membership.
<G-vec00366-002-s254><belong.gehören><de> Personen, von denen erst nach erfolgtem Beitritt bekannt wird, dass sie entweder bereits zum Zeitpunkt ihres Beitritts zu dem ausgeschlossenen Personenkreis gehörten oder danach hinzugekommen sind, sind nach schriftlicher Anhörung durch Streichung aus der Mitgliederliste zu entfernen.
<G-vec00366-002-s255><belong.gehören><en> But it's not just Western pro-Palestinians who have double standards but also many Muslims who argue they have the right to emigrate where ever they wish but who argue vehemently that the Jews don't belong in Palestine.
<G-vec00366-002-s255><belong.gehören><de> Doch es sind nicht gerade nur westliche Pro-Palästinenser, die eine Doppelmoral haben, sondern auch viele Muslime, die argumentieren, sie hätten das Recht, wohin immer sie wollten einzuwandern, die jedoch vehement argumentieren, dass die Juden nicht nach Palästina gehörten.
<G-vec00366-002-s256><belong.handeln><en> LA Confidential cannabis seeds by DNA Genetics belong to a feminised Indica-dominant cannabis strain derived from the cross between OG LA Affie and Afghani #1.
<G-vec00366-002-s256><belong.handeln><de> Bei den LA Confidential Hanfsamen von DNA Genetics handelt es sich um eine feminisierte Cannabissorte mit Indica-Dominanz, die aus der Kreuzung zweier 100%iger Indicas hervorgegangen ist, einer OG LA Affie und einer Afghani.
<G-vec00366-002-s257><belong.handeln><en> €27.00 €27.00 Amnesia Kush · Dinafem Seeds Amnesia Kush cannabis seeds by Dinafem Seeds belong to a Sativa-dominant feminized...
<G-vec00366-002-s257><belong.handeln><de> €27.00 €27.00 Amnesia Kush · Dinafem Seeds Bei den Hanfsamen der Amnesia Kush von Dinafem Seeds handelt es sich um eine...
<G-vec00366-002-s258><belong.handeln><en> Durban cannabis seeds by Sensi Seeds belong to a feminised Sativa-dominant cannabis strain derived from a selected South African genetics.
<G-vec00366-002-s258><belong.handeln><de> Bei den Durban Hanfsamen von Sensi Seeds handelt es sich um eine feminisierte Cannabissorte mit Sativa-Dominanz, deren ausgesuchte Genetik direkt aus Südafrika stammt.
<G-vec00366-002-s259><belong.handeln><en> Amnesia XXL Autoflowering Feminised Seeds Amnesia XXL Auto cannabis seeds by Dinafem Seeds belong to a feminized autoflowering Sativa-dominant cannabis strain that comes from the cross between a Original Amnesia and an Original Amnesia Autoflowering.
<G-vec00366-002-s259><belong.handeln><de> Bei den Marihuana-Samen Amnesia XXL Auto von Dinafem Seeds handelt es sich um eine selbstblühende, feminisierte Marihuana-Varietät mit Sativa-Dominanz, die aus der Verbindung einer Original Amnesia und einer Original Amnesia Autoflowering entstanden ist.
<G-vec00366-002-s260><belong.handeln><en> In addition to human control, an automatic system analyzes all the photos of the certified profiles to make sure they do not belong to another girl on the internet.
<G-vec00366-002-s260><belong.handeln><de> Zusätzlich zur Kontrolle durch unsere Mitarbeiter, kontrolliert ein automatisches System alle Bilder von Zertifizierten Profilen, um sicher zu sein, dass es sich nicht um Bilder anderer Mädchen aus dem Internet handelt.
<G-vec00366-002-s261><belong.handeln><en> Liberty Haze cannabis seeds by Barney's Farm belong to a feminized cannabis strain derived from the cross between a G13 male and a Chem Dawg 91.
<G-vec00366-002-s261><belong.handeln><de> Bei den Liberty Haze Hanfsamen von Barney's Farm handelt es sich um eine feminisierte Cannabissorte, die aus der Kreuzung einer männlichen G13 und der superschnellen Chem Dawg 91 hervorgegangen ist.
<G-vec00366-002-s262><belong.handeln><en> If the user would like to use the software on several portable storage media at the same time, this is covered by an individual licence as long as the storage media do not belong to third parties or another user.
<G-vec00366-002-s262><belong.handeln><de> Möchte der Anwender die Software auf mehreren portablen Speichermedien gleichzeitig verwenden, so ist dies durch eine Einzellizenz gedeckt, solange es sich nicht um Speichermedien Dritter oder das Speichermedium eines anderen Anwenders (User) handelt.
<G-vec00366-002-s263><belong.handeln><en> Select Option+ Add to Wishlist+ seeds by Dinafem Seeds belong to a feminized autoflowering...
<G-vec00366-002-s263><belong.handeln><de> Hersteller: Dinafem Seeds Auswählen Option+ Add to Wishlist+ Auf die Dinafem Seeds handelt es sich um eine feminiserte...
<G-vec00366-002-s265><belong.handeln><en> Delivery guarantee Tracking number Crystal Candy cannabis seeds by Sweet Seeds belong to a feminized, Indica-dominant marijuana plant with unknown origins.
<G-vec00366-002-s265><belong.handeln><de> Bei den Crystal Candy Hanfsamen von Sweet Seeds handelt es sich um eine feminisierte Cannabissorte mit Indica-Dominanz, deren genetische Ursprünge nicht bekannt gegeben wurden.
<G-vec00366-002-s266><belong.handeln><en> Reduced price! Cheese Autoflowering CBD cannabis seeds by Dinafem Seeds belong to a feminized CBD-rich cannabis strain derived from the cross between a Cheese XXL Autoflowering and an Auto CBD.
<G-vec00366-002-s266><belong.handeln><de> Bei den Marihuana-Samen Cheese Autoflowering CBD von Dinafem Seeds handelt es sich um eine selbstblühende, feminisierte Cannabis-Sorte mit einem hohen CBD-Gehalt, die aus der Kreuzung einer Cheese XXL Autoflowering und einer Auto CBD hervorgegangen ist.
<G-vec00366-002-s267><belong.handeln><en> Big Bud cannabis seeds by Sensi Seeds belong to a regular Indica-dominant cannabis strain derived from the cross between a Skunk #1 and a (Northern Lights x Big Bud).
<G-vec00366-002-s267><belong.handeln><de> Bei den Big Bud Hanfsamen von Sensi Seeds handelt es sich um eine reguläre Cannabissorte mit Indica-Dominanz, die aus der Kreuzung einer Skunk #1 mit einer (Northern Lights x Big Bud) hervorgegangen ist.
<G-vec00366-002-s268><belong.handeln><en> Passion #1 cannabis seeds by Dutch Passion belong to a regular cannabis strain regarded as one of the best strains available now for growing outdoors.
<G-vec00366-002-s268><belong.handeln><de> Bei den Passion #1 Hanfsamen von Dutch Passion handelt es sich um eine reguläre Cannabissorte, die in den 70er Jahren in Kalifornien entwickelt wurden.
<G-vec00366-002-s269><belong.handeln><en> Pineapple Skunk cannabis seeds by Humboldt Seed Organization belong to a feminized cannabis strain derived from an elite skunk phenotype.
<G-vec00366-002-s269><belong.handeln><de> Bei den Pineapple Skunk Hanfsamen von Humboldt Seed Organization handelt es sich um eine feminisierte Cannabissorte, die auf einen Skunk-Elite-Phänotyp zurückgeht.
<G-vec00366-002-s270><belong.handeln><en> Early Amnesia CBD cannabis seeds by Dinafem Seeds belong to a feminized CBD-rich cannabis strain derived from the cross between an Original Amnesia and an Auto CBD.
<G-vec00366-002-s270><belong.handeln><de> Bei den Marihuana-Samen Early Amnesia CBD von Dinafem Seeds handelt es sich um eine feminisierte Cannabis-Sorte mit einem hohen CBD-Gehalt, die aus der Kreuzung einer Original Amnesia und einer Auto CBD hervorgegangen ist.
<G-vec00366-002-s271><belong.handeln><en> Blue Dream Auto cannabis seeds by Humboldt Seeds Organization belong to a feminized autoflowering Sativa/Indica/Ruderalis cannabis strain derived from the cross between a Blue Dream and a Ruderalis.
<G-vec00366-002-s271><belong.handeln><de> Bei den Blue Dream Auto Hanfsamen von Humboldt Seed Organization handelt es sich um eine feminisierte Autoflowering-Marihuanasorte (Sativa/Indica/Ruderalis), die aus der Verbindung einer Blue Dream und einer Ruderalis hervorgegangen ist.
<G-vec00366-002-s272><belong.handeln><en> Hollands Hope cannabis seeds by Dutch Passion belong to a feminised cannabis strain that originates from the cross of a Viking and a Skunk #1.
<G-vec00366-002-s272><belong.handeln><de> Bei den Hollands Hope Hanfsamen von Dutch Passion handelt es sich um eine feminisierte Cannabissorte, die auf die Kreuzung einer Viking mit einer Skunk #1 zurückgeht.
<G-vec00366-002-s273><belong.handeln><en> Pineapple Express cannabis seeds by Barney's Farm belong to a feminized autoflowering Indica-dominant marijuana strain that derives from the cross of a Skunk #1, a Cheese, a Pineapple Chunk and a Ruderalis.
<G-vec00366-002-s273><belong.handeln><de> Bei den Pineapple Express Hanfsamen von Barney's Farm handelt es sich um eine feminisierte Autoflowering-Cannabissorte mit Indica-Dominanz, die aus der Kreuzung einer Ruderalis, einer Skunk #1, einer Cheese und einer Pineapple Chunk hervorgegangen ist.
<G-vec00366-002-s274><belong.handeln><en> The remaining artificial intelligence stocks belong to companies that provide the hardware, components, intellectual property or services that make up an A.I. platform.
<G-vec00366-002-s274><belong.handeln><de> Bei den verbleibenden künstliche Intelligenz Aktien handelt es sich um Unternehmen, die die Hardware, Komponenten, geistiges Eigentum oder Dienstleistungen bereitstellen, die eine K.I.-Plattform ausmachen.
<G-vec00366-002-s294><belong.hingehören><en> An entire industry is expanding into an area where it doesn’t belong.
<G-vec00366-002-s294><belong.hingehören><de> Eine ganze Industrie breitet sich da aus, wo sie nicht hingehört.
<G-vec00366-002-s295><belong.hingehören><en> There is no doubt that vitamin K2 is highly effective at directing calcium into your bones, where it is needed, and away from your arteries, where it does not belong.
<G-vec00366-002-s295><belong.hingehören><de> Es besteht kein Zweifel, dass Vitamin K2 hochwirksam Kalzium in die Knochen leitet und weg von den Arterien, wo es nicht hingehört, führt.
<G-vec00366-002-s296><belong.hingehören><en> So you ask: “What is that?” It’s the simple cleaning of the body of everything that does not belong in there.
<G-vec00366-002-s296><belong.hingehören><de> Ich frage – „Was ist das?“ – nun, einfach eine Säuberung des Körpers von allem, was da nicht hingehört.
<G-vec00366-002-s297><belong.hingehören><en> Smears on the tail in the ass and in the throat give security to find everything that does not belong there.
<G-vec00366-002-s297><belong.hingehören><de> Abstriche am Schwanz im Arsch und im Rachen geben Sicherheit, alles zu finden, was nicht dort hingehört.
<G-vec00366-002-s298><belong.hingehören><en> Looming danger lurks as well in a sick, alien culture that seeps into and pollutes all families, and emanates from an omnipotent, trigger-happy State itching to stick its snout where it does not belong and jail spouses and seize children.
<G-vec00366-002-s298><belong.hingehören><de> Drohende Gefahr lauert ebenso auch in der kranken und fremden Kultur, die immer mehr einsickert und alle Familien betrifft: Sie geht von einem allmächtigen und schießwütigen Staat aus, der darauf aus ist, seine Nase überall dorthin zu stecken, wo sie nicht hingehört, Ehegatten inhaftiert und Eltern ihre Kinder nimmt.
<G-vec00366-002-s299><belong.hingehören><en> It explains by means of a very innocent example that I have used the wrong gender — i.e. that I have put " he," the word denoting the sex or the sexual, where it does not belong.
<G-vec00366-002-s299><belong.hingehören><de> Sie erläutert an einem möglichst unschuldigen Beispiel, daß ich das Geschlechtswort am unrechten Platze gebrauche, also das Geschlechtliche (he) dort anbringe, wo es nicht hingehört.
<G-vec00366-002-s300><belong.hingehören><en> Every G Adventures tour puts good back into the world by helping you keep your travel dollars where they belong: with the local businesses that earn them.
<G-vec00366-002-s300><belong.hingehören><de> Jede G Adventures Reise macht die Welt ein Stück besser, da das Geld, das du unterwegs ausgibst, dort bleibt, wo es hingehört: Bei den lokalen Unternehmen vor Ort.
<G-vec00366-002-s301><belong.hingehören><en> A place to belong.
<G-vec00366-002-s301><belong.hingehören><de> Einen Ort, wo man hingehört.
<G-vec00366-002-s302><belong.hingehören><en> Afterwards it is difficult to remove if it gets to a place where it does not belong.
<G-vec00366-002-s302><belong.hingehören><de> Anschließend lässt es sich nur schlecht entfernen, falls es einmal an eine Stelle gelangt, wo es nicht hingehört.
<G-vec00366-002-s303><belong.hingehören><en> To impose 'I' where 'I' does not belong is ahankar (ego).
<G-vec00366-002-s303><belong.hingehören><de> Das 'Ich' einzuführen, wo 'Ich' nicht hingehört, ist Ego (Ahamkar).
<G-vec00366-002-s304><belong.hingehören><en> The climbing community has learned nothing insofar as they still climb up to altitudes where a human being doesn’t really belong.
<G-vec00366-002-s304><belong.hingehören><de> Die Bergsteigerwelt hat insofern nichts gelernt, dass sie immer noch dort hinaufsteigt, wo der Mensch eigentlich nicht hingehört.
<G-vec00366-002-s305><belong.liegen><en> rights belong exclusively to the author of the website.
<G-vec00366-002-s305><belong.liegen><de> Alle Rechte liegen ausschließlich bei dem Autor der Webseite.
<G-vec00366-002-s306><belong.liegen><en> The Rights to the game belong to XS Software JSCo.
<G-vec00366-002-s306><belong.liegen><de> Alle Rechte des Spiels liegen bei XS Software Ltd.
<G-vec00366-002-s307><belong.liegen><en> The rights to all mentioned and employed brands and trademarks belong exclusively to their owners.
<G-vec00366-002-s307><belong.liegen><de> Die Rechte aller erwähnten und benutzten Marken- und Warenzeichen liegen ausschließlich bei deren Besitzern.
<G-vec00366-002-s308><belong.liegen><en> Please note that the rights to these product trademarks belong to the manufacturer.
<G-vec00366-002-s308><belong.liegen><de> Bitte beachten Sie, dass die Rechte bei den Herstellern der jeweiligen Produkte liegen.
<G-vec00366-002-s309><belong.liegen><en> The copyrights belong to uvex group and remain undiminished if the pictures are incorporated into an archive, either electronically or manually.
<G-vec00366-002-s309><belong.liegen><de> Die Urheberrechte liegen bei der uvex Gruppe und bleiben auch in vollem Umfang bestehen, wenn Bilder elektronisch / händisch in ein Archiv übernommen werden.
<G-vec00366-002-s310><belong.liegen><en> Copyrights: All rights to images and texts belong to Kai Treude.
<G-vec00366-002-s310><belong.liegen><de> Urheberrechte: Alle Rechte auf Bilder und Texte liegen bei Kai Treude.
<G-vec00366-002-s311><belong.liegen><en> All rights belong exclusively to the Agency.
<G-vec00366-002-s311><belong.liegen><de> Sämtliche Rechte liegen ausschließlich bei der Agentur.
<G-vec00366-002-s312><belong.liegen><en> There exists a set of four points, no three of which belong to the same line.
<G-vec00366-002-s312><belong.liegen><de> Ein wichtiger Begriff in diesem Zusammenhang ist das Doppelverhältnis von vier Punkten, die auf einer Geraden liegen.
<G-vec00366-002-s313><belong.liegen><en> All music rights belong to the owner of this.
<G-vec00366-002-s313><belong.liegen><de> Alle Musikrechte liegen beim Besitzer dieser.
<G-vec00366-002-s314><belong.liegen><en> All copyrights for this website belong to BARTH GMBH. Liability
<G-vec00366-002-s314><belong.liegen><de> Die Urheberrechte dieser Website liegen vollständig bei BARTH GMBH.
<G-vec00366-002-s315><belong.liegen><en> Trained at Munich's Academy of Music, his musical beginnings belong to a late Romantic category of Brahmsian provenance.
<G-vec00366-002-s315><belong.liegen><de> Seine musikalischen Anfänge liegen freilich im Bereich spätromantischen Komponierens Brahms’scher Provenienz, wie sie ihm in München an der Akademie der Tonkunst vermittelt wurden.
<G-vec00366-002-s316><belong.liegen><en> All rights of the contents, offers, and images belong to the owners.
<G-vec00366-002-s316><belong.liegen><de> Alle Rechte dieser Seite bezüglich des Inhalts, der Angebote und der Bilder liegen bei den Urhebern.
<G-vec00366-002-s317><belong.liegen><en> Quelle: elegantvienna.com) Copyright for texts, graphics, design, photographs and source code published in elegantvienna.com belong to ElegantVienna.
<G-vec00366-002-s317><belong.liegen><de> Das Urheberrecht und die Nutzungsrechte für Texte, Grafiken, Design und Quellcode liegen bei ElegantVienna, sowie das Nutzungsrecht für die Bilder.
<G-vec00366-002-s318><belong.liegen><en> Moreover, those who come for the first time will be surprised by well-protected natural areas, some of which are far away from the towns while the others belong to them.
<G-vec00366-002-s318><belong.liegen><de> Einige befinden sich weit weg von den Küstenstädten, andere liegen mittendrin, und markieren sogenannte urbane Schnittstellen.
<G-vec00366-002-s319><belong.liegen><en> Most already belong to the constellation of Sagittarius.
<G-vec00366-002-s319><belong.liegen><de> Die meisten liegen im Feld des Sternbildes Sagittarius.
<G-vec00366-002-s320><belong.liegen><en> The German expellees remember places that have long since ceased to be German, in just the same way that Polish expellees refer to places that today belong to Ukraine or Lithuania.
<G-vec00366-002-s320><belong.liegen><de> Die deutschen Vertriebenen erinnern sich heute an Orte, die längst nicht mehr deutsch sind, genauso wie sich die polnischen Vertriebenen auf Orte beziehen, die heute in der Ukraine und Litauen liegen.
<G-vec00366-002-s322><belong.liegen><en> The content of the website is published for World-Wide-Web-usage only. Copyright and legal right of use for texts, graphics, design, and source code belong to the Free University of Bozen-Bolzano, so does the legal right for the photos.
<G-vec00366-002-s322><belong.liegen><de> Die Inhalte der Website sind im World-Wide-Web für den Online-Zugriff veröffentlicht, das Urheberrecht und die Nutzungsrechte (Copyright) für Texte, Graphiken, Design, Fotos und Quellcode liegen bei der Freien Universität Bozen, außer anders angegeben.
<G-vec00366-002-s323><belong.liegen><en> The rights belong to the Swiss Confederation, as represented by the Federal Office for Buildings and Logistics (FOBL).
<G-vec00366-002-s323><belong.liegen><de> Die Rechte liegen bei der Schweizerischen Eidgenossenschaft, vertreten durch das Bundesamt für Bauten und Logistik BBL.
<G-vec00366-002-s362><belong.stammen><en> According to the coroner the bones have been buried only for a couple of decades and belong to a small woman.
<G-vec00366-002-s362><belong.stammen><de> Laut dem Gerichtsmediziner wurden die Knochen erst vor wenigen Jahrzehnten vergraben und stammen von einer kleinen Frau.
<G-vec00366-002-s363><belong.stammen><en> All of the photographs on display belong to the collection of CAMERA WORK AG. They not only serve as a means of historically documenting Jackie's life, but are also impressive due to their iconography, composition, and aesthetics.
<G-vec00366-002-s363><belong.stammen><de> Alle gezeigten Photographien stammen aus dem Eigenbestand der CAMERA WORK AG und dienen nicht nur als Mittel der historischen Nachzeichnung des Lebens von Jackie, sondern beeindrucken zudem in ihrer Bildsprache, Komposition und Ästhetik.
<G-vec00366-002-s364><belong.stammen><en> The collection contains more than 3000 exclusive wood species and is solely composed of varieties which belong to our climate zone.
<G-vec00366-002-s364><belong.stammen><de> Auf der gesamten Anlage stehen weit über 3000 exklusive Gehölze, die ausschließlich aus Arten unserer Klimazone stammen.
<G-vec00366-002-s365><belong.stammen><en> If it assumes the role of teacher, it hampers the propagation of truth and tends to prepare the minds and the hearts of the young to become either ruthless tyrants or docile slaves, according to the class to which they belong.
<G-vec00366-002-s365><belong.stammen><de> Wenn sie Schulen gründet und erhält, so tut sie dies auch nur darum, um die Verbreitung der unabhängig gelehrten Wahrheit zu verhindern und den Geist der jungen Leute so zu erziehen, daß sie zu müßigen Tyrannen und gehorsamen Sklaven heranwachsen — je nach der Klasse, aus der sie stammen.
<G-vec00366-002-s366><belong.stammen><en> In accordance with accepted international standards, 3% of the parquet strips in a batch may belong to other grading classes - to accommodate unavoidable differences in the classes.
<G-vec00366-002-s366><belong.stammen><de> Laut international anerkannter Norm dürfen 3% der Parkettstäbe in einem Los aus anderen Sortierungsklassen stammen, um unvermeidbare Unterschiede in den Sortierklassen zu erlauben.
<G-vec00366-002-s367><belong.stammen><en> The paintings, sculptures, and ceramics belong to a private collection. They have not been shown before in this combination.
<G-vec00366-002-s367><belong.stammen><de> Sämtliche Bilder, Skulpturen und Keramiken stammen aus einer Privatsammlung und sind, in dieser Kombination, zum ersten Mal zu sehen.
<G-vec00366-002-s368><belong.stammen><en> Thetavern table and the other furniture shown on the pictures belong to our range of products.
<G-vec00366-002-s368><belong.stammen><de> Der Wirtshaustisch und die Bank, sowie die anderen Möbel auf den Fotos stammen aus unserem Sortiment.
<G-vec00366-002-s369><belong.stammen><en> The tapestries belong to an age of splendour in Flemish tapestry and were made in the best workshops in Brussels.
<G-vec00366-002-s369><belong.stammen><de> Die Wandteppiche stammen aus der Glanzzeit der flämischen Bildwirkerei und wurden in den besten Werkstätten Brüssels hergestellt.
<G-vec00366-002-s370><belong.stammen><en> With the richly decorated carriages and the coachmen with their high hats, they seem to belong to another period of time.
<G-vec00366-002-s370><belong.stammen><de> Mit den geschmückten Kutschen und den Kutschern mit den hohen Zylindern, scheinen sie aus einer anderen Zeit zu stammen.
<G-vec00366-002-s371><belong.stammen><en> But not all Swiss billionaires belong to the leisure class: around a third of Switzerland’s richest hail from average middle-class backgrounds and built their fortunes from scratch.
<G-vec00366-002-s371><belong.stammen><de> Allerdings stammen auch rund ein Drittel der reichsten Schweizer aus eher durchschnittlichen Mittelklasse-Verhältnissen und haben sich ihren Reichtum von Grund auf selbst erarbeitet.
<G-vec00366-002-s372><belong.stammen><en> This contextualization of the diverse minimalist tendencies is one of the most characteristic aspects of the DaimlerChrysler Corporation’s collection, to which belong all of the works exhibited here.
<G-vec00366-002-s372><belong.stammen><de> Diese Kontextualisierung der verschiedenen minimalistischen Tendenzen ist einer der herausragenden Aspekte der Sammlung DaimlerChrysler, aus der alle Werke dieser Ausstellung stammen.
<G-vec00366-002-s373><belong.stammen><en> More and more visitors belong to the group of people that are stimulated by emotions created by nature and art.
<G-vec00366-002-s373><belong.stammen><de> Die Besucher stammen aus der immer größer werdenden Schicht der Ausflügler und der Kategorie der Personen, die aus der Natur und der Kunst intensive Emotionen, Botschaften und Anreize gewinnen.
<G-vec00366-002-s374><belong.stammen><en> The works on display belong to Carlos Gross’s private collection, one of the largest set of lithographs by Giacometti worldwide.
<G-vec00366-002-s374><belong.stammen><de> Die Werke stammen aus der Privatsammlung von Carlos Gross, der eine der größten Sammlungen von Lithografien Giacomettis weltweit besitzt.
<G-vec00366-002-s375><belong.stammen><en> However, the most important remains, due to their good condition, found in the area belong to the Roman civilisation.
<G-vec00366-002-s375><belong.stammen><de> Die wichtigsten Fundstücke, aufgrund ihres Erhaltungsgrades, stammen jedoch aus der römischen Zeit.
<G-vec00366-002-s442><belong.zählen><en> All other African countries belong to the Sub-Saharan region.
<G-vec00366-002-s442><belong.zählen><de> Alle anderen afrikanischen Staaten zählen zur Region Subsahara.
<G-vec00366-002-s443><belong.zählen><en> and CSFV belong to genus Pestivirus, a group of pathogens comprising solely animal viruses.
<G-vec00366-002-s443><belong.zählen><de> BVDV und CSFV zählen zum Genus Pestivirus, das ausschließlich tierpathogene Erreger beinhaltet.
<G-vec00366-002-s444><belong.zählen><en> Also cultural institutions, IHKs, international chambers of commerce and associations belong to our members.
<G-vec00366-002-s444><belong.zählen><de> Auch kulturelle Einrichtungen, IHKs, internationale Handelskammern und Verbände zählen zu unseren Mitgliedern.
<G-vec00366-002-s445><belong.zählen><en> I look forward to assist you in all aspects of travel arrangements for hunting and fly fishing. I would highly appreciate if I you belong soon to my elite clients circle. Partner
<G-vec00366-002-s445><belong.zählen><de> Ich freue mich darauf Sie vielleicht schon bald zum Kreis meines elitären Kundenkreises zählen zu dürfen und Ihnen in allen Belangen der Reiseorganisation rund um Jagd und Fliegenfischen professionell mit Rat und Tat zur Seite stehen.
<G-vec00366-002-s446><belong.zählen><en> Fineness, length, cross-section, stiffness, and, referring to the synthetic, the fiber finish belong to the most important parameters for spinning effects of the fiber / water suspension.
<G-vec00366-002-s446><belong.zählen><de> Zu den bedeutenden Einflussgrößen für das Auftreten von Verspinnungen in der Faser/ Wassersuspension zählen die Faserparameter Feinheit, Länge, Querschnitt, Steifheit und bei Synthesefasern das Faserfinish.
<G-vec00366-002-s447><belong.zählen><en> Every car, city, home, and woman smells differently, and these sensations often belong to our most precious memories.
<G-vec00366-002-s447><belong.zählen><de> Jede Blume, jeder Wald, jedes Zuhause als auch jede Frau duften anders und diese Sinneseindrücke zählen oft zu unseren tiefsten Erinnerungen.
<G-vec00366-002-s448><belong.zählen><en> Both of them belong to the top drivers of the KF-class and are getting in on the forefront of the European Championship.
<G-vec00366-002-s448><belong.zählen><de> Beide zählen zu den Topfahrern in der KF-Kategorie und mischen in der Europameisterschaft ganz vorne mit.
<G-vec00366-002-s449><belong.zählen><en> The sea buckthorn berries belong to the most vitamin-packed fruits of our flora. They have in addition many valuable substances for nutrition purposes.
<G-vec00366-002-s449><belong.zählen><de> Die Sanddornbeeren zählen zu den vitaminreichsten Früchten unserer Flora und weisen eine Vielzahl weiterer ernährungsphysiologisch wertvoller Substanzen auf.
<G-vec00366-002-s450><belong.zählen><en> Packing lists belong to the sales documents.
<G-vec00366-002-s450><belong.zählen><de> Packscheine zählen zu den Vertriebsbelegen.
<G-vec00366-002-s451><belong.zählen><en> The awarded companies belong to the pacemakers in their industries.
<G-vec00366-002-s451><belong.zählen><de> Die ausgezeichneten Unternehmen zählen in ihren Branchen zu den Schrittmachern.
<G-vec00366-002-s452><belong.zählen><en> Also with their album "5: The Gray Chapter" they proved again they belong to the biggest in the Metal scene.
<G-vec00366-002-s452><belong.zählen><de> Auch mit ihrem Album „5: The Gray Chapter“ haben sie mal wieder bewiesen, dass sie zu den bedeutendsten Größen in der Metalszene zählen.
<G-vec00366-002-s453><belong.zählen><en> kN centrifugal force belong to the class of versatile all around plates, which are ideal for compacting paving stones, horticulture and landscaping, and the maintenance of roads, paths and parking lots.
<G-vec00366-002-s453><belong.zählen><de> Die DPU-Modelle mit einer Zentrifugalkraft von 30 kN zählen zu den vielseitigen Allroundern für Pflasterarbeiten, den Garten- und Landschaftsbau sowie für Instandhaltungsarbeiten an Straßen, Wegen und Parkplätzen.
<G-vec00366-002-s454><belong.zählen><en> Posting periods belong to the master files.
<G-vec00366-002-s454><belong.zählen><de> Buchungsperioden zählen zu den Stammdaten.
<G-vec00366-002-s455><belong.zählen><en> Nosocomial infections nowadays belong to the most common infections during hospitalization, because they are developed with a problem germ additionally to already existing illnesses. Moreover, problem germs tend to occur after discharge from a hospital.
<G-vec00366-002-s455><belong.zählen><de> Nosokomiale Infektionen zählen heute zu den häufigsten Infektionen während eines Krankenhausaufenthaltes, da diese zusätzlich zu einer bereits bestehenden Grunderkrankung mit einem Problemkeim erworben werden oder sich erst nach der Entlassung aus einem Krankenhaus manifestieren.
<G-vec00366-002-s456><belong.zählen><en> Also information about preferences, hobbies, memberships or which websites have been called up – all these belong to personal data.
<G-vec00366-002-s456><belong.zählen><de> Aber auch Daten über Vorlieben, Hobbys, Mitgliedschaften oder welche Webseiten von jemandem angesehen wurden zählen zu personenbezogenen Daten.
<G-vec00366-002-s457><belong.zählen><en> The four artists belong to a generation that experienced the most significant period of changes in Indonesia’s contemporary social and political situation first-hand.
<G-vec00366-002-s457><belong.zählen><de> Die vier ausstellenden Künstler zählen zu einer Generation, die eine Zeit wichtiger politischen Reformen und grundlegender sozialer und politischer Veränderungen in der zeitgenössischen Gesellschaft unmittelbar erlebt hat.
<G-vec00366-002-s458><belong.zählen><en> Its sister restaurants, which belong to Europe’s best steak houses are known by the name Surf´n Turf and are also recommended. They are located in Frankfurt’s West end.
<G-vec00366-002-s458><belong.zählen><de> Empfehlenswert sind auch die beiden Schwesterrestaurants, die seit langem zu den besten Steakhäusern Europas zählen und unter dem Namen Surf´n Turf im Frankfurter Westend zu finden sind.
<G-vec00366-002-s459><belong.zählen><en> Unreconciled cash accounts (checks) belong to the balance sheet accounts.
<G-vec00366-002-s459><belong.zählen><de> Zwischenkonten (Schecks) zählen zu den Bilanzkonten.
<G-vec00366-002-s460><belong.zählen><en> Countries such as England, Czech Republic, Croatia, Poland, Estonia and Hong Kong belong to the company's loyal customers.
<G-vec00366-002-s460><belong.zählen><de> So zählen heute Staaten wie England, Tschechien, Kroatien, Polen, Estland und Hong Kong zu treuen Kunden der Firma.
