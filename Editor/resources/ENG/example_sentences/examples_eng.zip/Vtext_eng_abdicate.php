<G-vec00380-002-s002><abdicate.abdanken><en> But Miguel began a reign of terror that lasted until he was forced to abdicate in 1834.
<G-vec00380-002-s002><abdicate.abdanken><de> Aber Miguel begann ein Terrorregime, bis er 1834 abdanken musste.
<G-vec00380-002-s003><abdicate.abdanken><en> In the short time while he was away from Paris, both Delavau and Duplessis had to resign their posts, and the July Revolution of 1830 forced Charles X to abdicate.
<G-vec00380-002-s003><abdicate.abdanken><de> Polizeipräfekt Delavau und Polizeichef Duplessis mussten in seiner Abwesenheit zurücktreten und Karl X. während der Julirevolution 1830 abdanken.
<G-vec00380-002-s004><abdicate.abdanken><en> In March 1814 Paris was occupied and Napoleon was forced to abdicate.
<G-vec00380-002-s004><abdicate.abdanken><de> Im März 1814 wurde Paris besetzt und Napoleon wurde zum Abdanken gezwungen.
<G-vec00380-002-s005><abdicate.abdanken><en> Sun Yatsen became the first president of China after the emperor had to abdicate in 1912.
<G-vec00380-002-s005><abdicate.abdanken><de> Sun Yatsen wurde der erste Präsident Chinas, nachdem der Kaiser 1912 abdanken musste.
<G-vec00380-002-s009><abdicate.abgeben><en> 1567 Mary, Queen of Scots, is forced to abdicate the throne.
<G-vec00380-002-s009><abdicate.abgeben><de> 1567 Mary, Königin der Schotten, wird gezwungen, den Thron abzugeben.
<G-vec00380-002-s010><abdicate.abschwören><en> Like those Christians horribly slandered to justify the crimes, we who are as slandered as they were, we choose a thousand times death rather than abdicate our convictions.
<G-vec00380-002-s010><abdicate.abschwören><de> So wie jene ChristInnen, die furchtbar verleumdet wurden, um die Verbrechen zu rechtfertigen, so wählen auch wir ebenso Verleumdeten lieber tausendmal den Tod, als von unseren Überzeugungen abzuschwören.
<G-vec00380-002-s013><abdicate.entziehen><en> Yet parents can't abdicate all responsibility.
<G-vec00380-002-s013><abdicate.entziehen><de> Und dennoch können Eltern sich nicht der Verantwortung entziehen.
<G-vec00380-002-s017><abdicate.verzichten><en> The best known are probably the "Schöne Münchnerin" (the Beauty of Munich) Helene Sedlmayr, daughter of a shoemaker, and the "Spanish" dancer Lola Montez, cause of the revolution in 1848, when Ludwig I was forced to abdicate.
<G-vec00380-002-s017><abdicate.verzichten><de> Am bekanntesten sind wohl die "Schöne Münchnerin" Helene Sedlmayr, Tochter eines Schuhmachermeisters, und die "spanische" Tänzerin Lola Montez, Anlass zur Revolution von 1848, durch die Ludwig I. gezwungen wurde, auf den Thron zu verzichten.
<G-vec00380-002-s016><abdicate.zurücklegen><en> Since he considered his duty as a mandate from God, he could not abdicate his office.
<G-vec00380-002-s016><abdicate.zurücklegen><de> Da er seine Aufgabe als einen Auftrag Gottes sah, konnte er sein Amt nicht zurücklegen.
