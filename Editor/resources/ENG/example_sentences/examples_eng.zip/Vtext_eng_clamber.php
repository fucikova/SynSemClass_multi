<G-vec00218-002-s001><clamber.durchsteigen><en> Ice climbing promises pure adrenaline as you clamber up a frozen waterfall.
<G-vec00218-002-s001><clamber.durchsteigen><de> Eisklettern verspricht Adrenalin pur beim Durchsteigen eines gefrorenen Wasserfalls.
<G-vec00218-002-s003><clamber.erklimmen><en> Clamber up Saxon St. George's Tower, one of the oldest buildings in Oxford, and enjoy panoramic views over the historic city.
<G-vec00218-002-s003><clamber.erklimmen><de> Erklimmen Sie den Saxon St. George's Tower, eines der ältesten Gebäude in Oxford, und genießen Sie einen Panoramablick über die Stadt.
<G-vec00218-002-s005><clamber.hangeln><en> At the Iris Parc Le Grand Dague campsite you can go horse riding, mountain biking, play golf or clamber about in the climbing woods for a fee.
<G-vec00218-002-s005><clamber.hangeln><de> Auf dem Camping Iris Parc Le Grand Dague können Sie gegen Gebühr reiten, Mountainbike fahren, Golf spielen oder sich im Kletterwald durch die Baumkronen hangeln.
<G-vec00218-002-s006><clamber.hochklettern><en> For example, in a children's room: it is desirable to also provide the window with a secure ajar stand holder in order to clamber up.
<G-vec00218-002-s006><clamber.hochklettern><de> Zum Beispiel in einem Kinderzimmer: Es ist wünschenswert, das Fenster auch mit einem sicheren angelehnten Ständerhalter auszustatten, um hochzuklettern.
<G-vec00218-002-s008><clamber.klettern><en> Next to the waterfalls is a small park where the kids can play: ‘abseilen’,clamber and walk over suspension bridges.
<G-vec00218-002-s008><clamber.klettern><de> In der Nähe der Wasserfälle befindet sich ein kleiner Park, in dem die Kinder sich von Felsenwänden abseilen, klettern und über Hängebrücken laufen können.
<G-vec00218-002-s009><clamber.klettern><en> NOEstep helps make the use of NOEtop formwork even easier. By fitting NOEsteps on the lower two transverse profiles, the operatives can reach tie bar holes, stabilizer connections and other connectors without having to clamber up the formwork itself or use a ladder.
<G-vec00218-002-s009><clamber.klettern><de> Der NOEstep dient der einfacheren Bedienbarkeit der NOEtop Schalung, eingesetzt innerhalb der unteren 2 Querprofillagen erreicht man mittels des NOEsteps Spannstellen, Richtstützenanschlüsse und Verbindungsmittel ohne an der Schalung selbst zu klettern oder eine Leiter benutzen zu müssen.
<G-vec00218-002-s010><clamber.klettern><en> The dramatic dashcam video shows trucks being forced to steam through the blaze so the determined men can’t clamber aboard the vehicle.
<G-vec00218-002-s010><clamber.klettern><de> Das dramatische Video einer Amaturenbrettkamera zeigt Lastwagen, die gezwungen werden, durch lodernde Flammen zu eilen, damit die entschlossenen Männer nicht auf die Fahrzeuge klettern können.
<G-vec00218-002-s011><clamber.kraxeln><en> Climbing, clamber, playing and discovering...
<G-vec00218-002-s011><clamber.kraxeln><de> Klettern, Kraxeln, Spielen und Entdecken...
<G-vec00218-002-s012><clamber.relaxen><en> BALUBA world of indoor games Your children will have hours of fun in the BALUBA, the incredible indoor games world: they can climb, clamber onto the giant hen coops, drive the mini-karts and loads more!
<G-vec00218-002-s012><clamber.relaxen><de> Ihre Kinder vergnügen sich über Stunden im BALUBA, dem ultimativen Klettergerüst und wer davon noch nicht genug hat fährt eine Runde mit den kostenpflichtigen Mini-Karts um das BALUBA herum während Sie auf der Terrasse des BALUBA relaxen.
<G-vec00218-002-s013><clamber.steigen><en> Christian opens the passenger door to the black Audi SUV, and I clamber in.
<G-vec00218-002-s013><clamber.steigen><de> Christian öffnet die Beifahrertür des schwarzen Audi SUV, und ich steige ein.
<G-vec00218-002-s014><clamber.steigen><en> My contempt and my longing increase together; the higher I clamber, the more do I despise him who clambereth.
<G-vec00218-002-s014><clamber.steigen><de> Meine Verachtung und meine Sehnsucht wachsen mit einander; je höher ich steige, um so mehr verachte ich Den, der steigt.
