<G-vec00185-001-s057><arrest.festnehmen><en> Ms. Liu's elderly father is not aware of her arrest.
<G-vec00185-001-s057><arrest.festnehmen><de> Liu Ronghua's älterer Vater weiß nicht, dass sie festgenommen wurde.
<G-vec00185-001-s058><arrest.festnehmen><en> If you attend a Christian church meeting without fear of harassment, arrest, torture, or death, you are more blessed than almost three billion people in the world.
<G-vec00185-001-s058><arrest.festnehmen><de> Wenn du einen christlichen Gottesdienst besuchst, ohne dich fürchten zu müssen, belästigt, festgenommen, gefoltert oder getötet zu werden, dann geht es dir besser als fast drei Milliarden Menschen in dieser Welt.
<G-vec00185-001-s059><arrest.festnehmen><en> The complaint was based on the UN Convention Against Torture, which France signed in 1984 and which allows it to arrest and prosecute any person guilty of torture.
<G-vec00185-001-s059><arrest.festnehmen><de> Die Anzeige beruht auf der UN-Konvention gegen Folter, die Frankreich 1984 ratifiziert hat und der zufolge jeder, der sich des Verbrechens von Folter schuldig gemacht hat, festgenommen und angeklagt werden kann.
<G-vec00185-001-s060><arrest.festnehmen><en> He was temporarily placed under arrest last December.
<G-vec00185-001-s060><arrest.festnehmen><de> Er wurde vorübergehend im letzten Dezember festgenommen.
<G-vec00185-001-s061><arrest.festnehmen><en> During the brief conversa tion, the chairman (he did not give his name) stated that he was familiar with Vitkūnaitė's case which will be prosecuted, but would not arrest Marytė until the trial and she could therefore continue attending medical school. Marytė Vitkūnaitė was released at 6:00 P.M.
<G-vec00185-001-s061><arrest.festnehmen><de> In einem kurzen Gespräch hat der Chef (seinen Namen hat er nicht genannt) erklärt, er habe sich mit dem Pro zeß von Vitkūnaite beschäftigt und er würde weiter fortgesetzt, aber bis zur Ge richtsverhandlung würde Marytė nicht festgenommen; sie dürfe weiterhin die Medizinschule besuchen.
<G-vec00185-001-s062><arrest.festnehmen><en> He had to leave home to avoid arrest.
<G-vec00185-001-s062><arrest.festnehmen><de> Um nicht festgenommen zu werden, musste er sein Zuhause verlassen.
<G-vec00185-001-s063><arrest.festnehmen><en> He bombed Afghanistan, sent soldiers to wage war against whole nations, but did not arrest the people that he set out to arrest.
<G-vec00185-001-s063><arrest.festnehmen><de> Er hat Afghanistan bombardieren lassen, er hat seine Soldaten in einen Krieg gegen ganze Völker geschickt, aber er hat nicht die Personen festgenommen, die er festnehmen wollte.
<G-vec00185-001-s064><arrest.festnehmen><en> Because of that, Chenzhou police illegally arrested Ms. Yang with a blank arrest warrant.
<G-vec00185-001-s064><arrest.festnehmen><de> Daraufhin wurde Frau Yang von der Polizei in Chenzhou mit einem leeren Haftbefehl festgenommen.
<G-vec00185-001-s065><arrest.festnehmen><en> Several female riders rode completely naked while all men were threatened with arrest by Police if they did not wear pants.
<G-vec00185-001-s065><arrest.festnehmen><de> Mehrere Reiterinnen fuhren völlig nackt, während alle Männer von der Polizei festgenommen wurden, wenn sie keine Hosen trugen.
<G-vec00185-001-s066><arrest.festnehmen><en> For the sake of such actions, there exists the fear among the inhabitants, that anyone being in contact to external people or media, is in danger of arrest.
<G-vec00185-001-s066><arrest.festnehmen><de> Aufgrund solcher Aktionen bestehen mittlerweile unter den BewohnerInnen Ängste, dass alle, die Kontakt zu Außenstehenden oder gar Medien aufnehmen, Gefahr laufen, festgenommen zu werden.
<G-vec00185-001-s067><arrest.festnehmen><en> In the following pages, we document the names and details of the arrest of over 10,000 Falun Gong practitioners in the name of the Beijing Olympics' security.
<G-vec00185-001-s067><arrest.festnehmen><de> Auf den folgenden Seiten dokumentieren wir die Namen und Einzelheiten von mehr als 10.000 Falun Gong-Praktizierenden, die im Namen der Sicherheit für die Pekinger Olympischen Spiele festgenommen wurden.
<G-vec00185-001-s068><arrest.festnehmen><en> Daqing police not only arrest practitioners, but also confiscate their houses.
<G-vec00185-001-s068><arrest.festnehmen><de> Die Polizisten der Stadt Daqing haben nicht nur Praktizierende festgenommen sondern auch ihre Häuser konfisziert.
<G-vec00185-001-s069><arrest.festnehmen><en> The Thai government imposed martial law and made 30 arrests including the arrest of two Muslim teachers.
<G-vec00185-001-s069><arrest.festnehmen><de> Die thailändische Regierung hatte das Kriegsrecht ausgerufen und 30 Personen festgenommen, darunter auch zwei muslimische Lehrer.
<G-vec00185-001-s070><arrest.festnehmen><en> Three months later, Governor Ulises Ruiz sent 700 police officers to terminate the blockade which led to the arrest of 23 people.
<G-vec00185-001-s070><arrest.festnehmen><de> Drei Monate später schickte der Gouverneur Ulises Ruiz 700 Polizisten in den Ort, um die Blockade aufzulösen, wobei 23 Personen festgenommen wurden.
<G-vec00185-001-s071><arrest.festnehmen><en> The military operation seeks to arrest the police on the charge of belonging to the EPR.
<G-vec00185-001-s071><arrest.festnehmen><de> Die Polizisten werden festgenommen und beschuldigt, zur Revolutionären Armee des Volkes (EPR) zu gehören.
<G-vec00185-001-s072><arrest.festnehmen><en> He made every effort to share his experience and help others see through the regime's slanderous propaganda, but doing so led to his arrest and detention in Wujiabao Forced Labour Camp in Fushun City three times.
<G-vec00185-001-s072><arrest.festnehmen><de> Er bemühte sich sehr, seine Erfahrungen weiterzuerzählen und half anderen, die verleumderische Propaganda des Regimes zu durchschauen, weshalb er drei Mal festgenommen und ins Zwangsarbeitslager Wujiabao in der Stadt Fushun gesperrt wurde.
<G-vec00185-001-s073><arrest.festnehmen><en> (d) Shall not be subjected to arbitrary arrest or detention, and shall not be deprived of his or her liberty except on such grounds and in accordance with such procedures as are established in this Statute.
<G-vec00185-001-s073><arrest.festnehmen><de> d) darf eine Person nicht willkürlich festgenommen oder in Haft gehalten werden und darf einer Person nur dann die Freiheit entzogen werden, wenn dies nach dem Statut begründet ist und im Einklang mit den in diesem Statut festgelegten Verfahren geschieht.
<G-vec00185-001-s074><arrest.festnehmen><en> Divjak is currently not allowed to leave Austria, after he was briefly held under arrest there in March on the basis of a Serbian warrant.
<G-vec00185-001-s074><arrest.festnehmen><de> Divjak darf zurzeit Österreich nicht verlassen, nachdem er dort aufgrund eines serbischen Haftbefehls Anfang März kurzzeitig festgenommen worden war.
<G-vec00185-001-s075><arrest.festnehmen><en> In November 1995, the German Police arrested Gudelj at the Frankfurt Airport, based on an Interpol arrest warrant, and subsequently extradited him to Croatia in February 1996.
<G-vec00185-001-s075><arrest.festnehmen><de> Im November 1995 wurde Gudelj durch die Deutsche Polizei aufgrund eines Interpol Haftbefehls am Frankfurter Flughafen festgenommen und anschließend im Februar 1996 nach Kroatien ausgeliefert.
<G-vec00185-001-s095><arrest.festnehmen><en> "The arrest of Falun Gong practitioners in ""preparation"" for the Olympics is happening not only in Beijing, but throughout the country, including twenty-nine provinces, cities and autonomous regions."
<G-vec00185-001-s095><arrest.festnehmen><de> "Diese Festnahmen von Praktizierenden in ""Vorbereitung"" auf die Olympischen Spiele geschieht nicht nur in Peking, sondern im ganzen Land, einschließlich 29 Provinzen, Städten und autonomen Regionen."
<G-vec00185-001-s096><arrest.festnehmen><en> "Following the arrest of top Fifa functionaries suspected of corruption and ties with organised crime, the association must finally be compelled to ensure transparency in its dealings, the liberal daily Upsala Nya Tidning urges: ""One can only imagine how Qatar, a country where football is practically non-existent and where the heat makes games impossible during the day, was selected to host the World Cup in 2022."
<G-vec00185-001-s096><arrest.festnehmen><de> "Nach den Festnahmen führender Funktionäre wegen des Verdachts der Korruption und des organisierten Verbrechens muss von der Fifa endlich Transparenz eingefordert werden, drängt die liberale Tageszeitung Upsala Nya Tidning: ""Man ahnt, wie Katar, ein Land in dem Fußball kaum existiert und wo die Hitze Spiele während des Tages unmöglich macht, den Zuschlag für die WM 2022 erhalten hat."
<G-vec00185-001-s097><arrest.festnehmen><en> They went to her home several times a day and often took her away to fulfil arrest quotas so they could earn bonus money from the ruling regime.
<G-vec00185-001-s097><arrest.festnehmen><de> Sie erschienen mehrere Male täglich, und oft nahmen sie sie mit, um ihre Quote an Festnahmen zu erfüllen für die sie vom herrschenden Regime Geldzulagen bekamen.
<G-vec00185-001-s098><arrest.festnehmen><en> """It is not worthy of a democratic country to arbitrarily arrest protesters who are merely making use of their right to freedom of expression."
<G-vec00185-001-s098><arrest.festnehmen><de> """Die willkürlichen Festnahmen von Demonstranten, die nur von ihrem Recht auf Meinungsfreiheit Gebrauch machen, sind einer Demokratie nicht würdig."
<G-vec00185-001-s099><arrest.festnehmen><en> Ms. Zhao regained her freedom, but she did not return home to avoid further arrest.
<G-vec00185-001-s099><arrest.festnehmen><de> Frau Zhao erhielt ihre Freiheit Kraft ihrer aufrichtigen Gedanken zurück, doch ging sie nicht nach Hause, weil sie weitere Festnahmen vermeiden wollte.
<G-vec00185-001-s100><arrest.festnehmen><en> Arrest, public shaming, extortion of and discrimination against individuals based on their sexual orientation were reported in several parts of the country.
<G-vec00185-001-s100><arrest.festnehmen><de> Aus mehreren Landesteilen trafen Berichte über Festnahmen, öffentliche Beschimpfungen, Erpressungen und Diskriminierungen von Personen aufgrund ihrer sexuellen Orientierung ein.
<G-vec00185-001-s101><arrest.festnehmen><en> Resistance often results in banning, arbitrary arrest, detention without trial, and sometimes deaths under imprisonment.
<G-vec00185-001-s101><arrest.festnehmen><de> Widerstand führt oft zu Verbannungen, willkürlichen Festnahmen, Inhaftierung ohne Gerichtsverfahren und zuweilen zu mysteriösen Todesfällen in der Haft.
<G-vec00185-001-s102><arrest.festnehmen><en> The report especially mentioned that China continues to arrest, incarcerate and sentence Falun Gong practitioners.
<G-vec00185-001-s102><arrest.festnehmen><de> Im Bericht wurde betont, dass China mit den Festnahmen, Inhaftierungen und Verurteilungen von Falun Gong Praktizierenden fortfährt.
<G-vec00185-001-s103><arrest.festnehmen><en> In response, police intensified their harassment and arrest of local residents.
<G-vec00185-001-s103><arrest.festnehmen><de> Im Gegenzug intensivierte die Polizei ihre Schikanen und Festnahmen von Ortsbewohnern.
<G-vec00185-001-s104><arrest.festnehmen><en> The perpetrator responsible for their arrest is Li Jun, captain of the national security team.
<G-vec00185-001-s104><arrest.festnehmen><de> Hauptverantwortlich für ihre Festnahmen ist Li Jun, Kommandant des Teams für Nationale Sicherheit.
<G-vec00185-001-s105><arrest.festnehmen><en> The report documents the arrest of 173 women and 51 men on account of their religious attachment to Falun Gong.
<G-vec00185-001-s105><arrest.festnehmen><de> In dem Report werden die Festnahmen von 173 Frauen und 51 Männern aufgrund ihres religiösen Bekenntnisses zu Falun-Gong dokumentiert.
<G-vec00185-001-s106><arrest.festnehmen><en> No one wanted to arrest him.
<G-vec00185-001-s106><arrest.festnehmen><de> Niemand wollte ihn festnehmen.
<G-vec00185-001-s107><arrest.festnehmen><en> Once the door was opened, seven to eight police forced their way into her home and tried to arrest her.
<G-vec00185-001-s107><arrest.festnehmen><de> Als die Tür geöffnet wurde, stürmten sieben bis acht Polizisten in ihre Wohnung und wollten sie festnehmen.
<G-vec00185-001-s108><arrest.festnehmen><en> The larger the group, the less willing the police are to arrest peaceful naked people.
<G-vec00185-001-s108><arrest.festnehmen><de> Je größer die Gruppe ist, desto weniger will die Polizei friedliche, nackte Menschen festnehmen.
<G-vec00185-001-s109><arrest.festnehmen><en> 2 Kings 1:1-4 Ahaziah got the message but was not happy and wanted to arrest Elijah with the intent to torture and kill him.
<G-vec00185-001-s109><arrest.festnehmen><de> Könige 1:1-4 Ahasja verstand die Botschaft, war jedoch nicht glücklich darüber und wollte Elia festnehmen, mit der Absicht, in zu foltern und umzubringen.
<G-vec00185-001-s110><arrest.festnehmen><en> "At last the police admitted, ""We didn't want to arrest you."
<G-vec00185-001-s110><arrest.festnehmen><de> Zum Schluss gaben die Polizisten auch zu: „Wir wollten euch eigentlich nicht festnehmen.
<G-vec00185-001-s111><arrest.festnehmen><en> "He stressed that the ""No one in the state has the power of law enforcement officers can not arrest a person without the permission of the prosecution, and in the case of communications to the effect absenteeism person, the prosecutor at the time to open an investigation into the incident through 24 Hour, but that does not happen""."
<G-vec00185-001-s111><arrest.festnehmen><de> "Er betonte, dass die ""Niemand in den Staat hat die Macht der Strafverfolgungsbehörden können eine Person nicht festnehmen, ohne die Erlaubnis der Staatsanwaltschaft, und im Falle der Kommunikation dahingehend Fehl Person, der Staatsanwalt an der Zeit, um eine Untersuchung des Vorfalls durch öffnen 24 Stunde, aber das nicht passiert""."
<G-vec00185-001-s113><arrest.festnehmen><en> One morning in May 2002, seven to eight plainclothes officers pounded on their door, but they failed in their attempt to arrest them.
<G-vec00185-001-s113><arrest.festnehmen><de> Eines Morgens im Mai 2002 hämmerten sieben bis acht Zivilpolizisten gegen ihre Tür, blieben jedoch erfolglos in ihrem Versuch, sie festnehmen.
<G-vec00185-001-s114><arrest.festnehmen><en> The police would arrest me for expressing myself politically against genocide.
<G-vec00185-001-s114><arrest.festnehmen><de> Die Polizei würde mich dort festnehmen, da ich mich politisch gegen den Genozid ausgesprochen habe.
<G-vec00185-001-s115><arrest.festnehmen><en> For me actually, because I'm not a big person, I'm pretty slender, so sometimes when I have to arrest somebody or get in a physical altercation it's a challenge to believe that I could actually arrest this person.
<G-vec00185-001-s115><arrest.festnehmen><de> Insbesondere für mich, weil ich nicht sonderlich groß bin, ich bin sehr schmächtig, und manchmal, wenn ich jemanden festnehmen soll oder es sogar zu Handgreiflichkeiten kommt, ist es eine Herausforderung, es glaubhaft rüberzubringen, dass ich diese Person wirklich festnehmen könnte.
<G-vec00185-001-s117><arrest.festnehmen><en> If the parents or other relatives of this child practised Falun Gong, and if the police couldn't find and arrest the adults, they would repeatedly harass the child.
<G-vec00185-001-s117><arrest.festnehmen><de> Wenn die Eltern oder andere Verwandten eines Kindes Falun Gong üben, die Polizei diese aber nicht finden und festnehmen kann, dann belästigen sie das Kind wiederholt.
<G-vec00185-001-s118><arrest.festnehmen><en> I left my relative's home when I heard that the police were going to arrest me and send me to prison.
<G-vec00185-001-s118><arrest.festnehmen><de> Schnell verließ ich das Haus meiner Verwandten, als ich erfuhr, dass die Polizei mich festnehmen und ins Gefängnis bringen wollte.
<G-vec00185-001-s119><arrest.festnehmen><en> He issued the order that the police had to monitor a number of locations and arrest any practitioners who were spreading truth-clarifying materials.
<G-vec00185-001-s119><arrest.festnehmen><de> Er erteilte den Befehl, dass die Polizei mehrere Plätze überwachen und Praktizierende festnehmen musste, die Infomaterialien über Falun Gong verteilten.
<G-vec00185-001-s120><arrest.festnehmen><en> """The people in power can arrest and hurt people at any time, anywhere."
<G-vec00185-001-s120><arrest.festnehmen><de> """Die Machthaber können die Menschen jederzeit und überall festnehmen und verletzen."
<G-vec00185-001-s121><arrest.festnehmen><en> State prosecutors in the German states of Saxony and Bavaria ordered the arrest of seven people on Monday on suspicion of forming a right-wing terrorist organisation.
<G-vec00185-001-s121><arrest.festnehmen><de> Am Montag hat die Bundesanwaltschaft in Sachsen und Bayern sieben Personen wegen des Verdachts der Bildung einer rechtsterroristischen Vereinigung festnehmen lassen.
<G-vec00185-001-s122><arrest.festnehmen><en> "When Policewoman Sun Shuqin was asked, ""What do you do every day?"" she answered, ""Our daily job is to arrest Falun Gong practitioners."
<G-vec00185-001-s122><arrest.festnehmen><de> Als die Polizistin Sun Shuqin gefragt wurde, was sie jeden Tag zu tun habe, antwortete sie: „Unsere tägliche Arbeit besteht im Festnehmen von Falun Gong-Praktizierenden.
<G-vec00185-001-s123><arrest.festnehmen><en> In order to arrest people who practise Falun Gong, on the streets, the police forced people to curse Falun Gong.
<G-vec00185-001-s123><arrest.festnehmen><de> Um Falun Gong Praktizierende festnehmen zu können, zwingt die Polizei die Menschen auf der Straße, Falun Gong zu verfluchen.
<G-vec00185-001-s124><arrest.festnehmen><en> There are many many ways that people can in fact as... points out in his book - if you are naive about this, creating a facebook page to start organizing a protest is just a great way to let the secret police know who to arrest.
<G-vec00185-001-s124><arrest.festnehmen><de> Es gibt da viele, viele Arten und Weisen, auf die die Leute wirklich, wie... in seinem Buch aufzeigt... Wenn man naiv darangeht beim Aufbau einer Facebook-Seite, um damit anzufangen, einen Protest zu organisieren, dann hat man eine tolle Methode geschaffen, mit der man der Geheimpolizei mitteilen kann, wen sie (die Geheimpolizei) festnehmen soll.
<G-vec00185-001-s125><arrest.festnehmen><en> During the session of the Two Congresses, the Mudanjiang Municipal Commission for Politics and Law and the local 610 Office (an organisation of special agents just for persecuting Falun Gong) directed the police and the domestic security division to harass and arrest local Falun Gong practitioners.
<G-vec00185-001-s125><arrest.festnehmen><de> "Während der Sitzung der Zwei Kongresse leiteten die Mudanjiang Selbstverwaltungskommission für Politik und Recht und das örtliche ""Büro 610""(1) die Polizei und die Abteilung für innere Sicherheit an, um die Falun Gong-Praktizierenden der Region zu schikanieren und festzunehmen."
<G-vec00185-001-s126><arrest.festnehmen><en> The Dandong police ordered the Fengcheng police to arrest him.
<G-vec00185-001-s126><arrest.festnehmen><de> Die Polizei Dandong befahl der Polizei in Fengcheng, ihn festzunehmen.
<G-vec00185-001-s127><arrest.festnehmen><en> Sometimes, when the police arrived and tried to arrest one person, several people would stand up in order to protect that person, and then all of them were arrested.
<G-vec00185-001-s127><arrest.festnehmen><de> Manchmal, wenn die Polizei ankam, um jemand festzunehmen, stellten sich mehrere Menschen auf, um diesen Menschen zu schützen; dann wurden sie alle zusammen festgenommen.
<G-vec00185-001-s128><arrest.festnehmen><en> The police probed into Ms. Jin Guanghua's whereabouts and tried to arrest her.
<G-vec00185-001-s128><arrest.festnehmen><de> So erkundigte sich die Polizei überall nach dem Verbleib von Jin Guanghua, um sie festzunehmen.
<G-vec00185-001-s129><arrest.festnehmen><en> A few months after her death, a group of police officers brought a big pile of falsified documents and went to Guo Henghong's brother's home in Luosiwan Village to arrest her again.
<G-vec00185-001-s129><arrest.festnehmen><de> Ein paar Monate, nachdem sie gestorben war, ging eine Gruppe von Polizisten mit einem großen Stapel gefälschter Papiere zum Haus des Bruders von Guo Henghong in Luosiwan, um sie wieder festzunehmen.
<G-vec00185-001-s130><arrest.festnehmen><en> Following a long hunt, the police managed to arrest a fleeing suspect, Yvan Colonna, son of a Socialist deputy.
<G-vec00185-001-s130><arrest.festnehmen><de> Nach einer langen Verfolgungsjagd gelingt es der Polizei, einen fliehenden Verdächtigen festzunehmen, Yvan Colonna, Sohn eines sozialistischen Parlamentariers.
<G-vec00185-001-s131><arrest.festnehmen><en> She called on the Canadian government and police to investigate, arrest and deport Lin Yanzhi according to Canada's Crimes Against Humanity and War Crimes Programme.
<G-vec00185-001-s131><arrest.festnehmen><de> Sie rief die kanadische Regierung und Polizei dazu auf, Lin Yanzhi zu überprüfen, festzunehmen und auszuweisen in Bezug auf das kanadische Programm zur Bekämpfung von Verbrechen gegen die Menschlichkeit und Kriegsverbrechen“.
<G-vec00185-001-s132><arrest.festnehmen><en> When the 2000 Chinese New Year was approaching, a few school leaders cooperated with agents from the Jinan 610 Office1 to arrest Zhou Ning again.
<G-vec00185-001-s132><arrest.festnehmen><de> "Als sich das chinesische Neujahrsfest 2000 näherte, arbeiteten ein paar Agenten des ""Büros 610"" von Jinan mit ein paar Schulleitern zusammen, um Zhou Ning festzunehmen."
<G-vec00185-001-s133><arrest.festnehmen><en> Our division began preparing for the emergency in July, and we were ready to go to Beijing and arrest Falun Gong practitioners at any time.
<G-vec00185-001-s133><arrest.festnehmen><de> Unsere Abteilung begann, sich auf den Notfall im Juli vorzubereiten, und wir waren jederzeit bereit, nach Peking zu gehen und Falun Gong Praktizierende festzunehmen.
<G-vec00185-001-s134><arrest.festnehmen><en> They tried to arrest us, but we didn't co-operate.
<G-vec00185-001-s134><arrest.festnehmen><de> Sie versuchten uns festzunehmen, aber wir kooperierten nicht mit ihnen.
<G-vec00185-001-s135><arrest.festnehmen><en> A month later, a source indicated that officials were planning another attempt to arrest her.
<G-vec00185-001-s135><arrest.festnehmen><de> Einen Monat später wurde bekannt, dass Beamte einen weiteren Versuch planten, sie festzunehmen.
<G-vec00185-001-s136><arrest.festnehmen><en> Being the first on the scene, Gibson shepherds a shell-shocked Eastwood outside and learns that Breedlove shot himself when Eastwood tried to arrest him for being involved in illegal activity at Aaron Monroe's party.
<G-vec00185-001-s136><arrest.festnehmen><de> Gibson, als Erste am Schauplatz, umsorgt den verstörten Eastwood draußen und erfährt, dass Breedlove sich selbst erschossen hat, als Eastwood versuchte, diesen wegen seiner Beteiligung an einer rechtswidrigen Handlung bei Aaron Monroes Party festzunehmen.
<G-vec00185-001-s137><arrest.festnehmen><en> 4 They planned to arrest Jesus by stealth and kill him.
<G-vec00185-001-s137><arrest.festnehmen><de> Mat 26:4 Sie kamen überein, Jesus mit List festzunehmen und zu töten.
<G-vec00185-001-s138><arrest.festnehmen><en> When the relatives asked which law Falun Gong violated, Liang threatened to arrest them.
<G-vec00185-001-s138><arrest.festnehmen><de> Als die Verwandten fragten welches Gesetz Falun Gong verletzt habe, drohte Liang sie festzunehmen.
<G-vec00185-001-s139><arrest.festnehmen><en> And now the Jharkhand Police comes to arrest me nine years after the incident.
<G-vec00185-001-s139><arrest.festnehmen><de> Und jetzt kommt die Polizei Jharkhands, um mich neun Jahre nach dem Vorfall festzunehmen.
<G-vec00185-001-s140><arrest.festnehmen><en> In the latter half of January 2005, Shiyan City's 610 Office and a policeman named Zhu Bangyi directed policemen to arrest and send a large number of Falun Gong practitioners in the area to a brainwashing centre.
<G-vec00185-001-s140><arrest.festnehmen><de> Ende Januar 2005 befahlen das Shiyan Stadt „Büro 610“ (2) und ein Polizeibeamter namens Zhu Bangyi, Polizeibeamte, eine große Anzahl von Falun Gong Praktizierenden festzunehmen und sie in ein Gehirnwäschezentrum zu bringen.
<G-vec00185-001-s141><arrest.festnehmen><en> They tried to arrest her again but failed.
<G-vec00185-001-s141><arrest.festnehmen><de> Der Versuch, sie ein weiteres Mal festzunehmen, scheiterte.
<G-vec00185-001-s142><arrest.festnehmen><en> In May 2003 at around 10:00 p.m., police from the Liangjiadian Police Station broke into Qu Ping's home to arrest her.
<G-vec00185-001-s142><arrest.festnehmen><de> Im Mai 2003 drangen gegen 22 Uhr Polizisten von der Liangjiadian Polizeistation in die Wohnung von Qu Ping ein, um sie festzunehmen.
<G-vec00185-001-s143><arrest.festnehmen><en> About 20 police officers burst into my home threatening to arrest me.
<G-vec00185-001-s143><arrest.festnehmen><de> Etwa 20 Polizisten drangen in meine Wohnung und drohten mir, mich festzunehmen.
<G-vec00185-001-s244><arrest.inhaftieren><en> """To investigate the incident and identify, arrest and prosecute the perpetrator."
<G-vec00185-001-s244><arrest.inhaftieren><de> """Den Vorfall zu ermitteln und zu identifizieren, den Täter zu inhaftieren und strafrechtlich zu verfolgen."
<G-vec00185-001-s245><arrest.inhaftieren><en> Ms. Huang Guixian's work unit deceived her in the name of checking her salary, while they actually planned to arrest her as soon as she arrived at work.
<G-vec00185-001-s245><arrest.inhaftieren><de> Frau Huang Guixian wurde von ihrer Einheit unter dem Vorwand ihren Lohn zu überprüfen, in das Arbeitsgebäude gerufen, aber stattdessen wollten sie sie inhaftieren, sobald sie dort ankam.
<G-vec00185-001-s246><arrest.inhaftieren><en> At the same time he ordered the arrest and torture of anyone suspected of being a Falun Dafa practitioner.
<G-vec00185-001-s246><arrest.inhaftieren><de> Gleichzeitig ordnete er an, jeden zu inhaftieren und zu foltern, der unter dem Verdacht stand, ein Falun Gong Praktizierender zu sein.
<G-vec00185-001-s247><arrest.inhaftieren><en> According information from an internal meeting of Chinese Communist Party (CCP) officials, the police will follow, monitor and arrest Falun Gong practitioners on a larger scale during the period leading up to the Olympic Games.
<G-vec00185-001-s247><arrest.inhaftieren><de> Laut Informationen einer internen Versammlung von Beamten der Kommunistischen Partei Chinas wird die Polizei während der Olympischen Spiele Falun Gong-Praktizierenden im großen Umfang folgen, sie überwachen und inhaftieren.
<G-vec00185-001-s248><arrest.inhaftieren><en> and arrest them in its own prisons.
<G-vec00185-001-s248><arrest.inhaftieren><de> und sie in ihren eigenen Gefängnissen inhaftieren.
<G-vec00185-001-s249><arrest.inhaftieren><en> The security forces conduct searches, arrest their brothers or fathers and interrogate them about their relatives that have fled to Germany.
<G-vec00185-001-s249><arrest.inhaftieren><de> Die Sicherheitskräfte führen Durchsuchungen durch, inhaftieren Brüder oder Väter und fragen nach den nach Deutschland geflohenen Personen.
<G-vec00185-001-s250><arrest.inhaftieren><en> Deputy Prime Minister and Minister of Interior Ivica Dacic has stated the police never arrest on political basis, and that in the future everybody who endangers the constitutional order of Serbia will be arrested.
<G-vec00185-001-s250><arrest.inhaftieren><de> Der stellvertretende Premier und Innenminister Serbiens, Ivica Dacic, hat erklärt, die Polizei würde niemals aus politischen Gründen inhaftieren, und hat darauf hingewiesen, dass künftig jedermann festgenommen werde, der die verfassungsmäßige Ordnung von Serbien unter Gefahr setzt.
<G-vec00185-001-s251><arrest.inhaftieren><en> The Chinese government's persecution of Falun Gong practitioners, which has resulted in the deaths in custody of nearly 600 practitioners, and the arrest and subsequent torture of thousands more in prisons, forced labour camps and mental hospitals across China, represents a policy of such outrageous violence that it has rightly provoked condemnation from all corners of the globe.
<G-vec00185-001-s251><arrest.inhaftieren><de> Die Verfolgung der chinesischen Regierung von Falun Gong Praktizierenden, welche mehr als 600 Todesfälle im Polizeigewahrsam forderte, und die Inhaftierung und anschließende Folter von tausenden weiteren in Gefängnissen, Zwangsarbeitslagern und psychiatrischen Anstalten in ganz China, zeigt eine Politik von solch verabscheuenswürdigen Gewaltanwendung, dass sie verdientermaßen Verurteilungen von allen Teilen des Erdballs hervorgerufen hat.
<G-vec00185-001-s252><arrest.inhaftieren><en> The action is supposed to be taking place in the early 1960s, as there is mention of the forthcoming arrest of a barrister member of the ANC, named Nelson Mandela.
<G-vec00185-001-s252><arrest.inhaftieren><de> Die Geschichte spielt wohl zu Beginn der 60er Jahre, denn es wird die bevorstehende Inhaftierung eines Anwalts und ANC-Mitglieds namens Nelson Mandela erwähnt.
<G-vec00185-001-s253><arrest.inhaftieren><en> Around this time, and especially after Jacob Cohn's arrest, they began to explore the possibility of emigrating – even if they had to leave all of their possessions and their entire fortune behind.
<G-vec00185-001-s253><arrest.inhaftieren><de> Parallel bemühten sie sich seit dieser Zeit – und besonders nach der Inhaftierung Jacob Cohns – dann um Auswanderungsmöglichkeiten – auch um den Preis, all ihren Besitz und ihr gesamtes Vermögen zurücklassen zu müssen.
<G-vec00185-001-s254><arrest.inhaftieren><en> The IRA-chairman and winner of the Weimar Human Rights Prize of 2011 fell seriously ill during custody and had lost more than 15 kiolograms in weight since his arrest.
<G-vec00185-001-s254><arrest.inhaftieren><de> Der Vorsitzende der IRA und Träger des Weimarer Menschenrechtspreises 2011 war in der Haft schwer erkrankt und hat seit seiner Inhaftierung mehr als 15 Kilogramm Gewicht verloren.
<G-vec00185-001-s255><arrest.inhaftieren><en> Differently than in the remand after three months no obligation lawyer is placed to them, so that they can hardly control whether their arrest is legal.
<G-vec00185-001-s255><arrest.inhaftieren><de> Anders als in der Untersuchungshaft wird ihnen nach drei Monaten kein Pflichtanwalt gestellt, so dass sie kaum kontrollieren können, ob ihre Inhaftierung rechtens ist.
<G-vec00185-001-s256><arrest.inhaftieren><en> At that time, more than ten policemen waited at the steps of Ms. Zhang's home and participated in trying to arrest her.
<G-vec00185-001-s256><arrest.inhaftieren><de> Damals warteten mehr als zehn Polizisten an der Treppe zu ihrer Wohnung und beteiligten sich an der Inhaftierung.
<G-vec00185-001-s257><arrest.inhaftieren><en> At the close of her post, Belmkaddem reflects on the significance of the arrest for political activists in Morocco today:
<G-vec00185-001-s257><arrest.inhaftieren><de> Zum Schluss ihres Beitrags denkt Bekmkaddem über die Bedeutsamkeit nach, die diese Inhaftierung für politische Aktivisten des heutigen Marokkos hat.
<G-vec00185-001-s258><arrest.inhaftieren><en> On the subject of the Hungarian Jews, a certain amount was going on between March and October 1944, but whatever it was, the events which began in October 1944 after the arrest of Horthy were the most severe.
<G-vec00185-001-s258><arrest.inhaftieren><de> Was die ungarischen Juden anbetrifft, so startete ein gewisser Anteil zwischen März und Oktober 1944, doch waren, aus welchem Grunde auch immer, die Ereignisse, die im Oktober 1944 nach der Inhaftierung von Horthy begannen, äußerst ernst.
<G-vec00185-001-s259><arrest.inhaftieren><en> "This protest is also against the arrest of hundreds of Hizb ut Tahrir members in Russia under the pretext of belonging to a ""terrorist organization."""
<G-vec00185-001-s259><arrest.inhaftieren><de> "Dieser Protest richtet sich auch gegen die Inhaftierung Hunderter Anhänger von Hizb-ut-Tahrir in Russland unter der verlogenen Anklage, Mitglieder einer ""terroristischen Vereinigung"" zu sein."
<G-vec00185-001-s260><arrest.inhaftieren><en> "Their arrest became possible only via the dubious construct of ""forming a terrorist alliance""."
<G-vec00185-001-s260><arrest.inhaftieren><de> Ihre Inhaftierung ist nur aufgrund der Konstruktion einer terroristischen Vereinigung möglich geworden.
<G-vec00185-001-s261><arrest.inhaftieren><en> The laws which served during the military dictatorship of Pinochet to justify the persecution, arrest and murder of thousands of Chileans, are still being used to justify the legal persecution and arrest of any person whose words or deeds can be seen as a disturbance of the public order or criticism of the government.
<G-vec00185-001-s261><arrest.inhaftieren><de> Mit den Gesetzen, die unter der Militärdiktatur Pinochets der Rechtfertigung von Verfolgung, Inhaftierung und Ermordung Tausender von Chilenen dienten, wird noch immer die juristische Verfolgung und Inhaftierung jedweder Person, deren Worte oder Taten als Störung der öffentlichen Ordnung oder Kritik an der Regierung gewertet werden kann, gerechtfertigt.
<G-vec00185-001-s263><arrest.inhaftieren><en> "By the time we were seized and taken to the detention center, the search ""warrant"" that authorized our arrest was well over its time limit, according to Ethiopian law."
<G-vec00185-001-s263><arrest.inhaftieren><de> Zu der Zeit, als unsere Sachen konfisziert wurden und wir im Untersuchungsgefängnis ankamen, war der Haftbefehl, der die Inhaftierung nach äthiopischem Gesetz autorisierte, längst überfällig.
<G-vec00185-001-s264><arrest.inhaftieren><en> Since defeating then president Jadranka Kosor in the race for party leadership in May 2012, Karamarko has been attempting to re-consolidate a HDZ weakened by the fall and arrest of its one-time ‘moderniser’ Ivo Sanader on corruption charges by appealing to the party’s ostensible ‘core values’.
<G-vec00185-001-s264><arrest.inhaftieren><de> Seit seiner siegreichen Auseinandersetzung mit der damaligen Vorsitzenden Jadranka Kosor im Kampf um den Parteivorsitz im Mai 2012 hat Karamarko Versuche unternommen, die durch den Sturz und die Inhaftierung ihres einstigen „Modernisierers“ Ivo Sanader aufgrund von Korruptionsvorwürfen geschwächte HDZ zu rekonsolidieren, indem er an die angeblichen „Kernwerte“ der Partei appellierte.
<G-vec00185-001-s265><arrest.inhaftieren><en> Government of Russia has filed a lawsuit against Swiss company Noga with a requirement to compensate the significant damage caused by the wrongful arrest of Russia’s assets in France.
<G-vec00185-001-s265><arrest.inhaftieren><de> Regierung von Russland hat eine Klage gegen die Schweizer Firma Noga mit einer Forderung eingereicht, um die erheblichen Schäden durch die unrechtmäßige Inhaftierung von Vermögenswerten Russland in Frankreich zu kompensieren.
<G-vec00185-001-s266><arrest.inhaftieren><en> "The Sheikh forewarns the Kuwaiti government and demands it to perform an immediate arrest of those who publicly incite the slaughtering of Shi'a in Syria, such as the Wahhabi terrorist, the so-called ""Shafi al-Ajmi""."
<G-vec00185-001-s266><arrest.inhaftieren><de> "Der Scheich warnt auch die kuwaitische Regierung und verlangt die sofortige Inhaftierung jener welche öffentlich zu diesen Morden aufrufen, wie zum Beispiel den sogenannten ""Shafi al-Ajmi""."
<G-vec00185-001-s267><arrest.inhaftieren><en> After serving as Vice Minister of Defence he became Interior Affairs Minister for Sierra Leone up until the time of his arrest.
<G-vec00185-001-s267><arrest.inhaftieren><de> Er war ehemals Vizeverteidigungsminister und hatte bis zu seiner Inhaftierung den Posten des Ministers für innere Angelegenheiten in Sierra Leone inne.
<G-vec00185-001-s268><arrest.inhaftieren><en> On that night, following Christ meant possible arrest and execution.
<G-vec00185-001-s268><arrest.inhaftieren><de> Die Nachfolge Jesu bedeutet in dieser Nacht mögliche Inhaftierung und Hinrichtung.
<G-vec00185-001-s269><arrest.inhaftieren><en> During the two months he was held in the detention centre, Mr. Li filed seven complaint letters with regard to his detention and arrest.
<G-vec00185-001-s269><arrest.inhaftieren><de> Während der zwei Monate im Untersuchungsgefängnis, reichte Herr Li, im Hinblick auf seine Festnahme und Inhaftierung, sieben Beschwerdebriefe ein.
<G-vec00185-001-s277><arrest.verhaften><en> "The report on CIA torture methods is a lesson in humility faced with the power of terror, the liberal daily De Standaard warns: ""A constitutional state that gives its intelligence agency a legal basis for the arrest, unlimited detention and torture of suspects is no longer in control of the terrorist machine that it itself set in motion."
<G-vec00185-001-s277><arrest.verhaften><de> "Der Bericht über die Foltermethoden des CIA ist eine Lektion in Bescheidenheit gegenüber der Macht des Terrors, mahnt die liberale Tageszeitung De Standaard: ""Ein Rechtsstaat, der seinem Geheimdienst eine gesetzliche Grundlage gibt, Verdächtige ohne Kontrolle zu verhaften, unbegrenzt festzuhalten und zu foltern, ist nicht mehr Herr über die Terrormaschine, die er in Gang gesetzt hat."
<G-vec00185-001-s278><arrest.verhaften><en> They only waited for a movement of his eyebrows to arrest Yudina.
<G-vec00185-001-s278><arrest.verhaften><de> Man wartete nur auf eine Bewegung seiner Brauen, um Judina zu verhaften.
<G-vec00185-001-s279><arrest.verhaften><en> After less than a week, the management violently concluded the strike, bringing in police forces under the pretext of a “counter-demonstration” of those who were “willing to work” who started to arrest the “ringleaders”—in other words, the strike committee.
<G-vec00185-001-s279><arrest.verhaften><de> Die Geschäftsleitung beendete schließlich nach knapp einer Woche den Streik gewaltsam, indem unter dem Schutz einer „Gegendemonstration“ von so genannten Arbeitswilligen in Meisterkitteln Polizeikräfte auf das Werksgelände eindrangen und damit begannen, „Rädelsführer“, d.h. die Streikleitung, zu verhaften.
<G-vec00185-001-s280><arrest.verhaften><en> The plan of action has been to amass enough evidence to arrest these criminals.
<G-vec00185-001-s280><arrest.verhaften><de> Der Aktionsplan besteht darin, genügend Beweise anzuhäufen, um diese Verbrecher zu verhaften.
<G-vec00185-001-s281><arrest.verhaften><en> He noted that Mr. Snowden was not a wanted man in Russia where he had committed no crime and that there was no reason to arrest him.
<G-vec00185-001-s281><arrest.verhaften><de> Er hat betont, dass Herr Snowden in Russland nicht gesucht würde, da er kein Verbrechen begangen habe und es keinen Grund gäbe, ihn zu verhaften.
<G-vec00185-001-s282><arrest.verhaften><en> There are already equal to the Russians come, have said they arrest us if we are quiet immediately.
<G-vec00185-001-s282><arrest.verhaften><de> Da sind gleich schon die Russen gekommen, haben gesagt, sie verhaften uns, wenn wir nicht sofort ruhig sind.
<G-vec00185-001-s283><arrest.verhaften><en> (Ramallah) – The Fatah-led Palestinian Authority in the West Bank and Hamas authorities in Gaza routinely arrest and torture peaceful critics and opponents, Human Rights Watch said in a report released today.
<G-vec00185-001-s283><arrest.verhaften><de> (Ramallah) - Die von der Fatah geführte Palästinensische Behörde im Westjordanland und die Hamas-Behörden im Gazastreifen verhaften und foltern routinemäßig friedliche Kritiker und Gegner, so Human Rights Watch in einem heute veröffentlichten Bericht.
<G-vec00185-001-s284><arrest.verhaften><en> Army and police can now enter a house without any search warrant; they can grab all the money they want and arrest people arbitrarily.
<G-vec00185-001-s284><arrest.verhaften><de> Armee und Polizei dürfen jederzeit ohne Durchsuchungsbefehl in alle Häuser eindringen, Geld an sich nehmen und Menschen verhaften.
<G-vec00185-001-s285><arrest.verhaften><en> The police searched his relatives' homes in an attempt to arrest him.
<G-vec00185-001-s285><arrest.verhaften><de> Polizisten durchsuchten die Wohnungen seiner Verwandten, um ihn verhaften zu können.
<G-vec00185-001-s286><arrest.verhaften><en> "Although I and Kin Gungaku have not committed any crime, to arrest, detain and interrogate and conduct a trial is ""a crime of special public officer's abuse of the office ""."
<G-vec00185-001-s286><arrest.verhaften><de> "Ich und Kin Gungaku haben nichts gesündigt,Zu verhaften, einen Prozess durch Befragung und Haft zu führen, ist ""Verbrechen des Missbrauchs der Autorität des speziellen öffentlichen Offiziers""."
<G-vec00185-001-s287><arrest.verhaften><en> At the same time prostitution is rated as illegal, too, and in cases of doubt the criminal Thai police has always the freedom to arrest any foreigner when he had been in a brothel.
<G-vec00185-001-s287><arrest.verhaften><de> Gleichzeitig gilt Prostitution aber immer noch als illegal und im Zweifelsfall hat die kriminelle, thailändische Polizei immer die Freiheit, jeden Ausländer zu verhaften, wenn er in einem Bordell war.
<G-vec00185-001-s288><arrest.verhaften><en> He wanted to arrest her, but Ms. Lu refused to go with him.
<G-vec00185-001-s288><arrest.verhaften><de> Er wollte sie verhaften, aber Frau Lu weigerte sich, mitzugehen.
<G-vec00185-001-s289><arrest.verhaften><en> The police reported this conversation to their superiors, and the Xiangtan City 610 Office and Xiang Steel Police Department immediately ordered the police to arrest Mr. Wang and take him away.
<G-vec00185-001-s289><arrest.verhaften><de> Die Polizisten meldeten diese Unterhaltung an ihre Vorgesetzten und das Büro 610 der Stadt Xiangtan und das Polizeidezernat der Xiang Stahlwerke befahlen den Polizisten, Herrn Wang sofort zu verhaften und ihn mitzunehmen.
<G-vec00185-001-s290><arrest.verhaften><en> On the other hand Dupleix opposed and let La Bourdonnais arrest.
<G-vec00185-001-s290><arrest.verhaften><de> Auf der anderen Seite Dupleix dagegen und ließ La Bourdonnais verhaften.
<G-vec00185-001-s291><arrest.verhaften><en> They cooperated with police to intercept and arrest the Falun Gong practitioners who went to appeal.
<G-vec00185-001-s291><arrest.verhaften><de> Sie arbeiteten mit der Polizei zusammen, um die Falun Gong-Praktizierenden, die eine Petition einreichen wollten, abzufangen oder zu verhaften.
<G-vec00185-001-s292><arrest.verhaften><en> Shortly after Stephen's martyrdom, Saul, still driven by zeal against the Christians, went to Damascus to arrest those he would find there.
<G-vec00185-001-s292><arrest.verhaften><de> Kurz nach dem Martyrium des Stephanus begab sich Saulus, immer angetrieben vom Eifer gegen die Christen, nach Damaskus, um jene zu verhaften, die er dort antreffen würde.
<G-vec00185-001-s293><arrest.verhaften><en> In November 2000, police went to his house to arrest him, but Tian Tingfu was not at home at the time.
<G-vec00185-001-s293><arrest.verhaften><de> Im November 2000 gingen Herr Zhao Hongtao, Leute vom Xiaonan Straßenbüro und Beamte der Shenhe Bezirkspolizeiabteilung zu ihm nach Hause und wollten ihn verhaften.
<G-vec00185-001-s294><arrest.verhaften><en> They want to arrest her again.
<G-vec00185-001-s294><arrest.verhaften><de> Sie wollten sie wieder verhaften.
<G-vec00185-001-s295><arrest.verhaften><en> He tried to arrest Ms. Li Hongxi, who was working at that time, but he failed to do so.
<G-vec00185-001-s295><arrest.verhaften><de> Er versuchte, Frau Li Hongxia, die zu dieser Zeit arbeitete, zu verhaften, scheiterte jedoch.
<G-vec00185-001-s296><arrest.verhaften><en> Then you find, arrest and deport illegal immigrants in an operation that conflates their circumstances with criminality.
<G-vec00185-001-s296><arrest.verhaften><de> Dann sucht, verhaftet und deportiert man illegale Einwanderer in einer Operation, im Rahmen derer deren Lebenssituation mit Kriminalität assoziiert wird.
<G-vec00185-001-s297><arrest.verhaften><en> Union leaders have endured arrest, prison and blacklisting.
<G-vec00185-001-s297><arrest.verhaften><de> Die Anführer der Gewerkschaft wurden verhaftet, eingesperrt und auf eine schwarze Liste gesetzt.
<G-vec00185-001-s298><arrest.verhaften><en> Incidentally, I was never told that I was under arrest.
<G-vec00185-001-s298><arrest.verhaften><de> Mitgeteilt, dass ich verhaftet bin, wurde mir übrigens nie.
<G-vec00185-001-s299><arrest.verhaften><en> Her brother Julius escaped arrest because he had fought in the German army and been injured in the First World War.
<G-vec00185-001-s299><arrest.verhaften><de> Ediths Bruder Julius wird nicht verhaftet, weil er im Ersten Weltkrieg in der deutschen Armee gekämpft hat und dabei verwundet wurde.
<G-vec00185-001-s300><arrest.verhaften><en> There is intimidation, different kinds of violence, driving people out of their jobs, arrest and all kinds of co-option.
<G-vec00185-001-s300><arrest.verhaften><de> Es gibt Einschüchterung, unterschiedliche Formen von Gewalt, Leute verlieren ihren Job, werden verhaftet, und es gibt alle Arten von Kooptierung.
<G-vec00185-001-s301><arrest.verhaften><en> So soldiers or militia working together with government forces arbitrarily arrest and torture civilians, rape women and steal aid material.
<G-vec00185-001-s301><arrest.verhaften><de> So werden Zivilisten von Soldaten oder von regierungsfreundlichen Milizen willkürlich verhaftet, gefoltert, Frauen vergewaltigt und Hilfsgüter unterschlagen.
<G-vec00185-001-s302><arrest.verhaften><en> 10) Northern Province police arrest five sangomas (herbal doctors) in as many months for sexually assaulting teenagers and forcing female clients to submit to sex to be cured of their illnesses.
<G-vec00185-001-s302><arrest.verhaften><de> v 10) Die Polizei der Northern Province hat in sechs Monaten ebenso viele Sangomas (Kräuterheiler) verhaftet, weil sie sich an Teenagern sexuell vergangen und Kundinnen zum Beischlaf gezwungen hatten, wollten diese von ihren Krankheiten geheilt werden.
<G-vec00185-001-s303><arrest.verhaften><en> Declaring that “we killed Mirbach, the Sovnarkom is under arrest,” Proshian ordered all telegrams signed by Lenin, Trotsky or Sverdlov suppressed as dangerous to “the presently governing party, in particular the Left SRs” (quoted in The Bolsheviks in Power).
<G-vec00185-001-s303><arrest.verhaften><de> Proschjan erklärte: „Wir haben Mirbach getötet, der Sownarkom ist verhaftet.“ Er ordnete an, alle von Lenin, Trotzki oder Swerdlow unterzeichneten Telegramme aufzuhalten, da sie für „die augenblickliche Regierungspartei, insbesondere die Linken Sozialrevolutionäre, gefährlich sind“ (Zitate aus Die Sowjetmacht – Das Erste Jahr).
<G-vec00185-001-s304><arrest.verhaften><en> "He acknowledged the risks involved in doing such work, including the possibility of arrest and imprisonment; however, he added, ""More people will step forward and speak out against the Party for the sake of China's future and the long-lasting prosperity of the Chinese people."""
<G-vec00185-001-s304><arrest.verhaften><de> "Er war sich des Risikos bewusst, das diese Arbeit mit sich bringt, einschließlich der Möglichkeit, verhaftet zu werden; aber er fügte hinzu: ""Immer mehr Menschen werden heraustreten und sich für Chinas Zukunft und einen dauerhaften Wohlstand und gegen die Partei stellen."
<G-vec00185-001-s305><arrest.verhaften><en> A man came in and told her he was a police officer from Shenyang and would arrest and shoot her if they were in China.
<G-vec00185-001-s305><arrest.verhaften><de> Ein Mann trat herein und sagte zu ihr, dass er ein Polizeibeamter aus Shenyang sei und sie verhaftet und erschossen hätte, wenn sie in China wären.
<G-vec00185-001-s306><arrest.verhaften><en> The arrest happened while he was at his workplace and was perpetrated by employees from Baoding City's organised team and Yi County's public security bureau, who were specifically targeting Falun Gong practitioners.
<G-vec00185-001-s306><arrest.verhaften><de> Er wurde direkt an seinem Arbeitsplatz verhaftet, dies war organisiert von den Mitarbeitern der Baoding Stadtverwaltung und der Sicherheitsbehörde des Bezirks Yi, welche darauf spezialisiert sind, Falun Gong-Praktizierende zu verfolgen.
<G-vec00185-001-s307><arrest.verhaften><en> Rong Rong's mother Zhang Yunhe was forced to leave home and go into hiding in May of 2001 after she was discovered while distributing materials containg the truth about Falun Gong and the realtiy of the persecution and faced impending arrest.
<G-vec00185-001-s307><arrest.verhaften><de> Rong Rong's Mutter, Zhang Yunhe, war gezwungen das Zuhause zu verlassen und sich vor der Polizei zu verstecken, nachdem sie im Mai 2001 beim Verteilen von Infomaterial über Falun Gong entdeckt worden war und verhaftet werden sollte.
<G-vec00185-001-s308><arrest.verhaften><en> Marcel's attachment to Adolphe and Emma outweighed his fear of arrest.
<G-vec00185-001-s308><arrest.verhaften><de> Marcels Zuneigung zu Adolphe und Emma war größer als seine Furcht davor verhaftet zu werden.
<G-vec00185-001-s309><arrest.verhaften><en> "And I was right across the street and I walked over to the car, opened the door, and said ""You're under arrest, you son of a bitch""."
<G-vec00185-001-s309><arrest.verhaften><de> Und ich war genau auf der anderen Straßenseite und ging zum Auto hinüber, öffnete die Tür und sagte, “Du bist verhaftet, Du Hurensohn”.
<G-vec00185-001-s311><arrest.verhaften><en> They are under arrest.
<G-vec00185-001-s311><arrest.verhaften><de> Sie sind verhaftet.
<G-vec00185-001-s312><arrest.verhaften><en> The Government of Ukraine has reported the arrest of Russian intelligence agents, including one yesterday who it says was responsible for establishing secure communications allowing Russia to coordinate destabilizing activities in Ukraine.
<G-vec00185-001-s312><arrest.verhaften><de> Die ukrainische Regierung berichtete, russische Geheimdienstler verhaftet zu haben, inklusive einen, gestern, der den Behörden zufolge für die sichere Kommunikationssysteme verantwortlich war, um den Russen zu erlauben, destabilisierende Aktivitäten in der Ukraine zu koordinieren.
<G-vec00185-001-s313><arrest.verhaften><en> In spite of the torments he had already endured, Bishop Sloskans wrote his parents: «You must have learned of my arrest from the newspapers.
<G-vec00185-001-s313><arrest.verhaften><de> Trotz der erlittenen Qualen schrieb Bischof Sloskans an seine Eltern: «Bestimmt habt Ihr aus den Zeitungen erfahren, dass ich verhaftet worden bin.
<G-vec00185-001-s314><arrest.verhaften><en> No member of the Reichstag or of a Landtag may, without the consent of the house of which he is a member, be subjected to investigation or arrest during the session for a penal offense unless he is apprehended in the commission of the act, or at latest in the course of the following day.
<G-vec00185-001-s314><arrest.verhaften><de> Kein Mitglied des Reichstags oder eines Landtags kann ohne Genehmigung des Hauses, dem der Abgeordnete angehört, während der Sitzungsperiode wegen einer mit Strafe bedrohten Handlung zur Untersuchung gezogen oder verhaftet werden, es sei denn, daß das Mitglied bei Ausübung der Tat oder spätestens im Laufe des folgenden Tages festgenommen ist.
<G-vec00185-002-s143><arrest.(sich)_nehmen><en> Liu Xia is married to the Nobel Peace Prize winner Liu Xiaobo, who is under arrest in China since 2010.
<G-vec00185-002-s143><arrest.(sich)_nehmen><de> Liu Xia ist mit dem Friedensnobelpreisträger Liu Xiaobo verheiratet, der seit 2010 in China in Haft ist.
<G-vec00185-002-s144><arrest.(sich)_nehmen><en> HOUDINI – Escape arrest three times as Jodie.
<G-vec00185-002-s144><arrest.(sich)_nehmen><de> HOUDINI – Entkommen Sie als Jodie 3 Mal aus der Haft.
<G-vec00185-002-s145><arrest.(sich)_nehmen><en> Step by step, we follow Schiele through his life - from childhood to his happy interlude in Krummau, from the crisis of his arrest to the artistic triumph that came only shortly before his death aged just 28
<G-vec00185-002-s145><arrest.(sich)_nehmen><de> Schritt für Schritt folgt es dem Lebensweg Schieles - von der Kindheit zu den glücklichen Tagen von Krummau, von der Krise der Haft zum künstlerischen Triumph kurz vor dem Tod mit nur 28 Jahren.
<G-vec00185-002-s146><arrest.(sich)_nehmen><en> Then the Lubei District Procuratorate informed Ma Lili's family that they had authorised the arrest.
<G-vec00185-002-s146><arrest.(sich)_nehmen><de> Dann informierte die Staatsanwaltschaft des Bezirkes Lubei Frau Mas Familienangehörige über die Bestätigung der Haft.
<G-vec00185-002-s147><arrest.(sich)_nehmen><en> He spent over a week under arrest and was released on bail for the sum of 125 million euro, a record in Austrian history.
<G-vec00185-002-s147><arrest.(sich)_nehmen><de> Mehr als eine Woche blieb er in Haft und kam erst gegen die in Österreich noch nie dagewesene Rekordkautionssumme von 125 Millionen Euro frei.
<G-vec00185-002-s148><arrest.(sich)_nehmen><en> 417 were injured by the police or custody staff, 130 of them during arrest,
<G-vec00185-002-s148><arrest.(sich)_nehmen><de> 417 wurden durch Polizei oder Bewachungspersonal verletzt, davon 130 Flüchtlinge in Haft.
<G-vec00185-002-s149><arrest.(sich)_nehmen><en> The two young men are currently under arrest and are awaiting trial, which will probably end with a pronouncement of the death penalty.
<G-vec00185-002-s149><arrest.(sich)_nehmen><de> Die beiden Jugendlichen befinden sich in Haft und erwarten ein Gerichtsverfahren, das mit großer Wahrscheinlichkeit mit der Verkündung der Todesstrafe enden wird.
<G-vec00185-002-s150><arrest.(sich)_nehmen><en> Mostly unnoticed by the world, 1,200,000 Tibetans have been killed by starvation, forced labour, arrest, torture, and execution in the following decades.
<G-vec00185-002-s150><arrest.(sich)_nehmen><de> Von der Weltöffentlichkeit weitestgehend unbemerkt sind in den darauf folgenden Jahrzehnten 1.200.000 Tibeter durch Hunger, Zwangsarbeit, Haft, Folter und Hinrichtungen ums Leben gekommen.
<G-vec00185-002-s151><arrest.(sich)_nehmen><en> (3) Every person arrested or detained shall be taken before the competent judge within 48 hours, who shall decide on the arrest or detention.
<G-vec00185-002-s151><arrest.(sich)_nehmen><de> (3) Jeder Verhaftete oder Festgenommene ist binnen 48 Stunden dem zuständigen Richter zur Entscheidung über die Haft oder Festnahme vorzuführen.
<G-vec00185-002-s152><arrest.(sich)_nehmen><en> At the moment 7 people targeted in the investigation of “the anarchists’ case” are staying under arrest.
<G-vec00185-002-s152><arrest.(sich)_nehmen><de> Momentan sind sieben Personen Zielscheibe der Ermittlungen im “Verfahren gegen AnarchistInnen” und befinden sich in Haft.
<G-vec00185-002-s153><arrest.(sich)_nehmen><en> In addition, the authorities have opened a criminal case on mass disorder and the night policy raided the offices of opposition candidates and human rights organisations such as “Viasna” (which had conducted local election observation) to arrest people, conduct searches and confiscate computer equipment and archives.
<G-vec00185-002-s153><arrest.(sich)_nehmen><de> Darüber hinaus haben die Behörden Strafverfahren wegen nächtlicher Ruhestörung und Massenversammlung eingeleitet, Büros der Oppositions-Kandidaten durchsucht und Mitglieder von Menschenrechtsorganisationen wie „Viasna“ (die lokale Wahlbeobachtungen durchgeführt hatten) in Haft genommen.
<G-vec00185-002-s250><arrest.(sich)_nehmen><en> The alerted police arrest the burglar and the three Turks are charged with dangerous bodily injury.
<G-vec00185-002-s250><arrest.(sich)_nehmen><de> Die alarmierte Polizei nimmt den Einbrecher fest, die drei Türken erhalten Strafanzeige wegen gefährlicher Körperverletzung.
<G-vec00185-002-s251><arrest.(sich)_nehmen><en> The police arrest one Afghan (23) for drug trafficking.
<G-vec00185-002-s251><arrest.(sich)_nehmen><de> Die Polizei nimmt einen Afghanen (23) wegen Drogenhandels fest.
<G-vec00185-002-s252><arrest.(sich)_nehmen><en> The police arrest the quintet and confiscate money, weapons, fake passports and electronic devices.
<G-vec00185-002-s252><arrest.(sich)_nehmen><de> Die Polizei nimmt das Quintett fest und beschlagnahmt Geld, Waffen, gefälschte Pässe und elektronische Geräte.
<G-vec00185-002-s253><arrest.(sich)_nehmen><en> Federal police arrest a 19-year-old Ghanaian with 25 ready-to-buy drug packets and promptly run him again Police speaks of \ [machine translation]
<G-vec00185-002-s253><arrest.(sich)_nehmen><de> Bundespolizei nimmt einen 19-jährigen Ghanaer mit 25 verkaufsfertigen Drogenpäckchen fest und lässt ihn umgehend wieder laufen.
<G-vec00185-002-s035><arrest.ergreifen><en> Every day I sat in the temple courts teaching, and you did not arrest me.
<G-vec00185-002-s035><arrest.ergreifen><de> Täglich bin ich bei euch lehrend im Tempel gesessen, und ihr habt mich nicht ergriffen.
<G-vec00185-002-s036><arrest.ergreifen><en> Every day I sat in the temple courts teaching, and you did not arrest me.
<G-vec00185-002-s036><arrest.ergreifen><de> Täglich bin ich bei euch im Tempel gesessen und habe gelehrt, und ihr habt mich nicht ergriffen.
<G-vec00185-002-s037><arrest.ergreifen><en> 49 I was daily with you in the temple teaching, and you didn't arrest me.
<G-vec00185-002-s037><arrest.ergreifen><de> 49Ich bin täglich bei euch im Tempel gewesen und habe gelehrt, und ihr habt mich nicht ergriffen.
<G-vec00185-002-s038><arrest.ergreifen><en> 49 Every day I was with you, teaching in the temple courts, and you did not arrest me.
<G-vec00185-002-s038><arrest.ergreifen><de> 49 Täglich war ich bei euch im Tempel und lehrte, und ihr habt mich nicht ergriffen.
<G-vec00185-002-s051><arrest.festnehmen><en> 46 but though they would have liked to arrest him they were afraid of the crowds, who looked on him as a prophet.
<G-vec00185-002-s051><arrest.festnehmen><de> 46 darum hätten sie ihn am liebsten festgenommen, fürchteten sich aber vor der Volksmenge, weil die ihn für einen Propheten hielt.
<G-vec00185-002-s052><arrest.festnehmen><en> Every day I sat in the temple courts teaching, and you did not arrest me.
<G-vec00185-002-s052><arrest.festnehmen><de> Tag für Tag saß ich im Tempel und lehrte, und ihr habt mich nicht festgenommen.
<G-vec00185-002-s053><arrest.festnehmen><en> If criminal proceedings are instituted against such a consular officer, the proceedings shall, except when he is under arrest or detention, be conducted in a manner which will hamper the exercise of consular functions as little as possible.
<G-vec00185-002-s053><arrest.festnehmen><de> Wird gegen einen solchen Konsularbeamten ein Strafverfahren eingeleitet, so ist dieses, außer wenn der Betroffene festgenommen oder inhaftiert ist, in einer Weise zu führen, welche die Wahrnehmung der konsularischen Aufgaben möglichst wenig behindert.
<G-vec00185-002-s054><arrest.festnehmen><en> The Marburg arrest is the culmination of a secret, weeks-long effort by German security authorities to hunt down suspected Russian agents.
<G-vec00185-002-s054><arrest.festnehmen><de> Hamburg - Die deutschen Sicherheitsbehörden haben zwei mutmaßliche Mitglieder eines ausländischen Nachrichtendienstes festgenommen.
<G-vec00185-002-s055><arrest.festnehmen><en> These expulsions follow the arrest of two people suspected of spying for Syria.
<G-vec00185-002-s055><arrest.festnehmen><de> Die Ausweisung erfolgt nachdem zwei Personen festgenommen wurden, die der Spionage für Syrien verdächtigt werden.
<G-vec00185-002-s056><arrest.festnehmen><en> If you did not arrest my father and take him to a forced labour camp, his leg would not have been broken.
<G-vec00185-002-s056><arrest.festnehmen><de> Hätten Sie meinen Vater nicht festgenommen und ins Zwangsarbeitslager gebracht, wäre auch sein Bein nicht gebrochen worden.
<G-vec00185-002-s058><arrest.festnehmen><en> Finally, a policeman arrest him at the entrance of the shop.
<G-vec00185-002-s058><arrest.festnehmen><de> Schließlich wird er am Ausgang des Geschäfts von einem Polizisten festgenommen.
<G-vec00185-002-s059><arrest.festnehmen><en> That, to her mind, was far more courageous than driving a car against the instructions of the government, than arrest and imprisonment.
<G-vec00185-002-s059><arrest.festnehmen><de> Das war ihrer Meinung nach viel mutiger, als gegen die Anweisungen der Regierung ein Auto zu lenken, als festgenommen und eingesperrt zu werden.
<G-vec00185-002-s079><arrest.festnehmen><en> As a lion she repressed the most rebellious parts of the movement (murder of Semira Adamu (3) who was resisting unflinchingly in the centres; house searches and arrest of comrades active in this struggle).
<G-vec00185-002-s079><arrest.festnehmen><de> Wie ein Löwe ließ er seine Repression gegen die aufständischsten Teile der Bewegung los (Mord an Semira Adamu[3], welche in den Zentren hartnäckig gekämpft hat; Hausdurchsuchungen und Festnahmen von Gefährten, welche sich aktiv an diesem Kampf beteiligten).
<G-vec00185-002-s080><arrest.festnehmen><en> The operations of independent media outlets have been increasingly undermined, and those who report on sensitive subjects – in particular the situation of the Rohingya minority – can face intimidation and harassment and at times arrest, detention, prosecution and even imprisonment.
<G-vec00185-002-s080><arrest.festnehmen><de> Die Aktivitäten unabhängiger Medienkanäle werden zunehmend untergraben, und diejenigen, die über sensible Themen berichten – vor allem über die Situation der Rohingya-Minderheit –, sehen sich Schikanen und Einschüchterungen ausgesetzt und sind zum Teil von Festnahmen, Inhaftierungen, Strafverfolgung und sogar Gefängnisstrafen bedroht.
<G-vec00185-002-s082><arrest.festnehmen><en> Many have suffered arbitrary arrest, torture, violence, abuse, unfair trials and neglect.
<G-vec00185-002-s082><arrest.festnehmen><de> Viele haben willkürliche Festnahmen, Folter, Gewalt, unfaire Prozesse und Vernachlässigung erlebt.
<G-vec00185-002-s083><arrest.festnehmen><en> Right before the 2008 New Year, officials from Jiaohe City "610 Office" passed on the CCP's order during a secret meeting to further arrest and persecute practitioners in "preparation for the Olympics."
<G-vec00185-002-s083><arrest.festnehmen><de> Direkt vor dem Neujahr 2008 führten Beamte des „Büro 610“ der Stadt Jiaohe geheime Treffen durch, um weitere Festnahmen und die Verfolgung von Falun Gong-Praktizierenden anzuordnen, als Maßnahme zur „Vorbereitung der Olympischen Spiele”.
<G-vec00185-002-s084><arrest.festnehmen><en> Studying the arrest and search warrants the same passages found in the text of the law are used, the alleged crimes were just added - vaguely described, without any apparent reason justifying the suspicion that they had committed the crimes, without concrete allegations.
<G-vec00185-002-s084><arrest.festnehmen><de> Beim Durchlesen der Anordnung der Festnahmen sowie der Durchsuchungen finden sich die genauen Textstellen des Gesetzes wieder, die angelasteten Delikte wurden - wage umschrieben, ohne offensichtlich begründetem Tatverdacht, ohne genaue Vorwürfe - einfach eingefügt.
<G-vec00185-002-s085><arrest.festnehmen><en> The country must also cooperate with the UN and its officials in efforts to monitor human rights compliance. „This resolution is a powerful testimony to the degree to which all Iranians – not just a few minorities or dissidents – are living under a state of siege, where harassment, arbitrary arrest and imprisonment, torture and the threat of death have become daily concerns,“ said Ms. Dugal.
<G-vec00185-002-s085><arrest.festnehmen><de> Die Regierung muss ebenso mit den Vereinten Nationen und ihren Beauftragten bei den Bemühungen, die Einhaltung der Menschenrechte zu überwachen, kooperieren.”Diese Resolution ist ein starkes Zeugnis über die Ausmaße des Belagerungszustands, unter dem alle Iraner – nicht nur ein paar Minderheiten oder Dissidenten – leben müssen, wo Schikanen, willkürliche Festnahmen und Inhaftierungen, Folter und die Androhung des Todes zu den täglichen Sorgen gehören”, so Bani Dugal.
<G-vec00185-002-s087><arrest.festnehmen><en> On the basis of testimonies, the federal police could arrest the thief on the train.
<G-vec00185-002-s087><arrest.festnehmen><de> Auf Grund von Zeugenaussagen konnte die Bundespolizei den Dieb noch im Zug festnehmen.
<G-vec00185-002-s088><arrest.festnehmen><en> The oncoming police were able to arrest a man of Albanian origin (19) with fake Greek papers and secure the stolen property.
<G-vec00185-002-s088><arrest.festnehmen><de> Die anrückende Polizei konnte einen Mann albanischer Herkunft (19) mit gefälschten griechischen Papieren festnehmen und das Diebesgut sicherstellen.
<G-vec00185-002-s089><arrest.festnehmen><en> Our answer to that is simple. We’re not hiding in a cave in Afghanistan, and our accusers can either arrest us or give the rhetoric a rest before they dilute the language and potency of such a word.
<G-vec00185-002-s089><arrest.festnehmen><de> Unsere Antwort darauf ist einfach: Wir verstecken uns nicht in afghanischen Höhlen, und unsere Ankläger können uns entweder festnehmen oder die Phrasendrescherei einfach sein lassen, bevor sie die Sprache und die Aussagekraft eines solchen Wortes komplett verwässern.
<G-vec00185-002-s090><arrest.festnehmen><en> If I see the words 'Truth, Compassion and Forbearance' written on currency, I'll arrest those people too.” He repeated this several times.
<G-vec00185-002-s090><arrest.festnehmen><de> Sollte ich die Worte Wahrhaftigkeit, Barmherzigkeit und Nachsicht auf Geldscheinen geschrieben sehen, werde ich diese Leute auch festnehmen.“ Er wiederholte diese Worte mehrere Male.
<G-vec00185-002-s091><arrest.festnehmen><en> 26:4 They 4 planned to arrest Jesus by stealth and kill him.
<G-vec00185-002-s091><arrest.festnehmen><de> 4Sie berieten darüber, wie sie Jesus heimlich festnehmen und umbringen lassen könnten.
<G-vec00185-002-s092><arrest.festnehmen><en> Ben secretly sneaked in and made some shots before security staff could arrest him.
<G-vec00185-002-s092><arrest.festnehmen><de> Ben schlich sich heimlich rein und machte einige Aufnahmen, bevor der Sicherheitsdienst ihn festnehmen konnte.
<G-vec00185-002-s093><arrest.festnehmen><en> "We know who will arrest, blackmail, hit or even kill us.
<G-vec00185-002-s093><arrest.festnehmen><de> "Wir wissen, wer uns festnehmen, erpressen, schlagen oder gar töten wird.
<G-vec00185-002-s094><arrest.festnehmen><en> The police were able to arrest a 40-year-old Romanian after a brief persecution.
<G-vec00185-002-s094><arrest.festnehmen><de> Die Polizei konnte nach kurzer Verfolgung einen 40-jährigen Rumänen festnehmen.
<G-vec00185-002-s095><arrest.festnehmen><en> For example if we have to face the fact that the police might arrest us during a demonstration, we can try to control fear by deciding in advance what our behaviour will be when confronted by police officers.
<G-vec00185-002-s095><arrest.festnehmen><de> Wenn wir uns zum Beispiel der Tatsache gegenübersehen, dass die Polizei uns während einer Demonstration festnehmen könnte, können wir versuchen, die Angst dadurch zu kontrollieren, dass wir im voraus entscheiden, wie wir uns verhalten werden, wenn wir mit PolizeibeamtInnen konfrontiert werden.
<G-vec00185-002-s096><arrest.festnehmen><en> Thanks to the hospital leader (Anjaan Srivastav) Durga survives, and police officer Ramnarayan Bharadwaj (Jackie Shroff) can identify and arrest the culprits.
<G-vec00185-002-s096><arrest.festnehmen><de> Dank des Einsatzes des Hospitalleiters (Anjaan Srivastav) überlebt Durga, und Police Officer Ramnarayan Bharadwaj (Jackie Shroff) kann die beiden Täter ermitteln und festnehmen.
<G-vec00185-002-s097><arrest.festnehmen><en> Not only did he want to arrest everyone who knew of his mistreatment of Ms. Li Ji'nan, but he also wanted to take their money.
<G-vec00185-002-s097><arrest.festnehmen><de> Er wollte nicht nur jeden festnehmen, der seine Missetaten kannte, sondern er wollte auch noch ihr Geld.
<G-vec00185-002-s098><arrest.festnehmen><en> Investigators are following several leads to arrest a suspect.
<G-vec00185-002-s098><arrest.festnehmen><de> Wir konnten einen Tatverdächtigen festnehmen.
<G-vec00185-002-s099><arrest.festnehmen><en> After taking a quick search, the police can use the photos to stop the vehicle and arrest the inmates, one adult woman and two adolescent men of foreign nationality.
<G-vec00185-002-s099><arrest.festnehmen><de> Mit den Fotos kann die Polizei nach kurzer Fahndung das Fahrzeug stellen und die Insassen, eine erwachsene Frau und zwei jugendliche Männer mit ausländischer Staatsangehörigkeit, festnehmen.
<G-vec00185-002-s100><arrest.festnehmen><en> The next night the SS came to his house and wanted to arrest him for helping the enemy.
<G-vec00185-002-s100><arrest.festnehmen><de> In der nächsten Nacht kam die SS in sein Haus und wollte ihn festnehmen, weil er den Amerikanern geholfen hätte.
<G-vec00185-002-s102><arrest.festnehmen><en> Despite Sweden's decision to drop a rape investigation, British police say that Julian Assange still faces arrest if he leaves Ecuador's London embassy.
<G-vec00185-002-s102><arrest.festnehmen><de> Die britische Polizei teilte aber umgehend mit, sie werde Assange festnehmen, sollte er die Botschaft verlassen.
<G-vec00185-002-s103><arrest.festnehmen><en> The president can now globally arrest or kill any unwanted person with drones.
<G-vec00185-002-s103><arrest.festnehmen><de> Der Präsident kann nun weltweit jede beliebige unerwünschte Person festnehmen oder mit Dronen töten lassen.
<G-vec00185-002-s104><arrest.festnehmen><en> Why do you want to arrest her?" The police showed their IDs and said, "We have IDs.
<G-vec00185-002-s104><arrest.festnehmen><de> Warum wollt Ihr sie festnehmen?“ Die Polizisten zeigten ihnen ihre Marken und sagten: „Wir haben Ausweise.
<G-vec00185-002-s105><arrest.festnehmen><en> According to two Italian Interpol officers, Batista approached Mauss, who was about to arrest him, when suddenly Batista drew two revolvers from his coat pocket and opened fire.
<G-vec00185-002-s105><arrest.festnehmen><de> Batista ging auf Mauss zu, bemerkte zwei italienische Interpolbeamte, die ihn festnehmen wollten und feuerte sofort mit zwei Revolvern aus seiner Manteltasche auf Mauss und die Kriminalbeamten.
<G-vec00185-002-s106><arrest.festnehmen><en> The ability to arrest cells instantly can also provide a window into very rapid processes like filopodial protrusion.
<G-vec00185-002-s106><arrest.festnehmen><de> Die Fähigkeit, Zellen festzunehmen kann ein Fenster in sehr schnelle Prozesse wie filopodial Vorsprung sofort auch zur Verfügung stellen.
<G-vec00185-002-s107><arrest.festnehmen><en> A border guard descended the tower to arrest him, but Leo Lis had already moved beyond the signal fence and the guard was unable to find him in the dark.
<G-vec00185-002-s107><arrest.festnehmen><de> Ein Grenzposten verlässt den Turm, um ihn festzunehmen, kann ihn aber, da er den Signalzaun inzwischen hinter sich gelassen hat, in der Dunkelheit zunächst nicht finden.
<G-vec00185-002-s108><arrest.festnehmen><en> At that time Jesus said to the multitudes, "Have you come out with swords and clubs to arrest Me as against a robber?
<G-vec00185-002-s108><arrest.festnehmen><de> Da sagte Jesus zu ihnen: + Wie gegen einen Räuber seid ihr mit Schwertern und Knüppeln ausgezogen, um mich festzunehmen.
<G-vec00185-002-s109><arrest.festnehmen><en> The local government officials sent out dozens of people, travelled several thousand miles, and spent hundreds of thousands of yuan (2) trying to arrest him, but to no avail.
<G-vec00185-002-s109><arrest.festnehmen><de> Die Regierungsbeamten schickten Dutzende von Menschen los, reisten viele tausend Meilen und gaben Hunderte und Tausende von Yuan aus, um ihn festzunehmen; aber es gelang ihnen nicht.
<G-vec00185-002-s110><arrest.festnehmen><en> The police attempted to arrest a few young people who were sightseeing on Tiananmen Square.
<G-vec00185-002-s110><arrest.festnehmen><de> Die Polizei versuchte einige Jugendliche festzunehmen, die den Tiananmen Platz besichtigten.
<G-vec00185-002-s111><arrest.festnehmen><en> In Shandong, police made a total of 860 attempts to arrest Falun Gong practitioners in 2014.
<G-vec00185-002-s111><arrest.festnehmen><de> In Shandong unternahm die Polizei 2014 insgesamt 860 Versuche, Falun Gong-Praktizierende festzunehmen.
<G-vec00185-002-s113><arrest.festnehmen><en> Afterwards, the police attempted to arrest him again.
<G-vec00185-002-s113><arrest.festnehmen><de> Hinterher versuchte die Polizei ihn erneut festzunehmen.
<G-vec00185-002-s114><arrest.festnehmen><en> In September 2000, the chief of Number One Langfang City Public Security Department, Hebei Province, Yang Hua (female, aged about thirty years) ordered male policeman Yan Zhen and another policeman with the surname of Feng to arrest Cui Yulan from her home in Langfang City, Hebei Province.
<G-vec00185-002-s114><arrest.festnehmen><de> Im September 2000 befahl die Chefin Yang Hua, 30, der ersten Öffentlichen Sicherheitsabteilung der Stadt Langfang, Provinz Hebei, dem Polizisten Yang Zhen und einem anderen Polizisten mit dem Nachnamen Feng, Frau Cui Yulan in ihrem Haus in Langfang festzunehmen.
<G-vec00185-002-s115><arrest.festnehmen><en> Sanhe Police Station officers tried to locate him and arrest him.
<G-vec00185-002-s115><arrest.festnehmen><de> Die Polizei von Sanhe versuchte, ihn ausfindig zu machen und ihn festzunehmen.
<G-vec00185-002-s116><arrest.festnehmen><en> In February 2003, the Guan County 610 Office (an organisation of special agents just for persecuting Falun Gong) issued instructions to arrest three Falun Gong practitioners from every town under its jurisdiction.
<G-vec00185-002-s116><arrest.festnehmen><de> Im Februar 2003 gab das Büro 610 im Landkreis Guan, Instruktionen heraus, um Falun Gong-Praktizierende in jeder Stadt seines Zuständigkeitsbereichs festzunehmen.
<G-vec00185-002-s117><arrest.festnehmen><en> All of a sudden, the Police officers throw one of the masked individuals to the ground to arrest them.
<G-vec00185-002-s117><arrest.festnehmen><de> Plötzlich reißen die Polizisten einen der Vermummten nieder, um ihn festzunehmen.
<G-vec00185-002-s119><arrest.festnehmen><en> Archives are to be handed over to the SS. As soon as possible, officials are to arrest as many Jews - especially wealthy ones - in all districts as can be accommodated in existing cells.
<G-vec00185-002-s119><arrest.festnehmen><de> Sobald der Ablauf der Ereignisse dieser Nacht die Verwendung der eingesetzten Beamten hierfür zuläßt, sind in allen Bezirken so viele Juden - insbesondere wohlhabende - festzunehmen, als in den vorhandenen Hafträumen untergebracht werden können.
<G-vec00185-002-s120><arrest.festnehmen><en> When Ms. Han did not go to pay the money on the following day, Wang Jiquan, head of the police station, and officers Li Qiang, Meng Qinglong, Wang Mingjun, Pan Yushan, Zhang Qian, and others went to her home to arrest her again.
<G-vec00185-002-s120><arrest.festnehmen><de> Als Han Jixiang am nächsten Tag nicht kam, um die Strafgebühr zu bezahlen, gingen der Leiter der Polizeiwache namens Wang Jiquan und die Polizisten Li Qiang, Meng Qinglong, Wang Mingjun, Pan Yushan, Zhang Qian und andere zu ihrer Wohnung, um sie festzunehmen.
<G-vec00185-002-s121><arrest.festnehmen><en> Wang Yongkang, director of the 610 Office (an organisation of special agents just for persecuting Falun Gong) in Changde City, recently dispatched several hundred officers to arrest more than 30 practitioners and ransack their homes.
<G-vec00185-002-s121><arrest.festnehmen><de> Der Leiter des „Büro 610“ der Stadt Changde, Herr Wang Yongkang, arrangierte kürzlich hunderte Polizisten, um über 30 Falun Gong Praktizierende illegal festzunehmen und ihre Wohnungen zu durchsuchen.
<G-vec00185-002-s122><arrest.festnehmen><en> Washington - After a Block of houses has been safed,the police was able to arrest a 43 years old murder.
<G-vec00185-002-s122><arrest.festnehmen><de> Washington - Nach der Evakuierung eines Häuserblocks gelang es der Polizei, einen 43jährigen Mörder festzunehmen.
<G-vec00185-002-s123><arrest.festnehmen><en> When the 2000 Chinese New Year was approaching, a few school leaders cooperated with agents from the Jinan 610 Office1 to arrest Zhou Ning again.
<G-vec00185-002-s123><arrest.festnehmen><de> Als sich das chinesische Neujahrsfest 2000 näherte, arbeiteten ein paar Agenten des „Büros 610“ von Jinan mit ein paar Schulleitern zusammen, um Zhou Ning festzunehmen.
<G-vec00185-002-s124><arrest.festnehmen><en> In the tape you can see the woman running outside to get away, and police officers there to arrest Thompson.
<G-vec00185-002-s124><arrest.festnehmen><de> Auf dem Band ist zu sehen, wie die Frau nach draußen läuft, um wegzukommen, und Polizeibeamte dort sind, um Thompson festzunehmen.
<G-vec00185-002-s229><arrest.inhaftieren><en> He gave order to arrest both of them.
<G-vec00185-002-s229><arrest.inhaftieren><de> Er gab den Befehl beide zu inhaftieren.
<G-vec00185-002-s232><arrest.inhaftieren><en> The summary jurisdiction of the so-called "Peoples' Courts" gave legitimacy to wide ranging powers of arrest, detention and torture that was exercised most harshly against the workers and especially the workers' leaders.
<G-vec00185-002-s232><arrest.inhaftieren><de> Der Sammelgerichtsbarkeit der so genannten "Volksgerichte" wurde das Recht zugestanden, Festnahmen anzuordnen, Menschen zu inhaftieren und zu foltern, was in erster Linie gegen die ArbeiterInnen und besonders ihre Führer umgesetzt wurde.
<G-vec00185-002-s143><arrest.nehmen><en> Liu Xia is married to the Nobel Peace Prize winner Liu Xiaobo, who is under arrest in China since 2010.
<G-vec00185-002-s143><arrest.nehmen><de> Liu Xia ist mit dem Friedensnobelpreisträger Liu Xiaobo verheiratet, der seit 2010 in China in Haft ist.
<G-vec00185-002-s144><arrest.nehmen><en> HOUDINI – Escape arrest three times as Jodie.
<G-vec00185-002-s144><arrest.nehmen><de> HOUDINI – Entkommen Sie als Jodie 3 Mal aus der Haft.
<G-vec00185-002-s145><arrest.nehmen><en> Step by step, we follow Schiele through his life - from childhood to his happy interlude in Krummau, from the crisis of his arrest to the artistic triumph that came only shortly before his death aged just 28
<G-vec00185-002-s145><arrest.nehmen><de> Schritt für Schritt folgt es dem Lebensweg Schieles - von der Kindheit zu den glücklichen Tagen von Krummau, von der Krise der Haft zum künstlerischen Triumph kurz vor dem Tod mit nur 28 Jahren.
<G-vec00185-002-s146><arrest.nehmen><en> Then the Lubei District Procuratorate informed Ma Lili's family that they had authorised the arrest.
<G-vec00185-002-s146><arrest.nehmen><de> Dann informierte die Staatsanwaltschaft des Bezirkes Lubei Frau Mas Familienangehörige über die Bestätigung der Haft.
<G-vec00185-002-s147><arrest.nehmen><en> He spent over a week under arrest and was released on bail for the sum of 125 million euro, a record in Austrian history.
<G-vec00185-002-s147><arrest.nehmen><de> Mehr als eine Woche blieb er in Haft und kam erst gegen die in Österreich noch nie dagewesene Rekordkautionssumme von 125 Millionen Euro frei.
<G-vec00185-002-s148><arrest.nehmen><en> 417 were injured by the police or custody staff, 130 of them during arrest,
<G-vec00185-002-s148><arrest.nehmen><de> 417 wurden durch Polizei oder Bewachungspersonal verletzt, davon 130 Flüchtlinge in Haft.
<G-vec00185-002-s149><arrest.nehmen><en> The two young men are currently under arrest and are awaiting trial, which will probably end with a pronouncement of the death penalty.
<G-vec00185-002-s149><arrest.nehmen><de> Die beiden Jugendlichen befinden sich in Haft und erwarten ein Gerichtsverfahren, das mit großer Wahrscheinlichkeit mit der Verkündung der Todesstrafe enden wird.
<G-vec00185-002-s150><arrest.nehmen><en> Mostly unnoticed by the world, 1,200,000 Tibetans have been killed by starvation, forced labour, arrest, torture, and execution in the following decades.
<G-vec00185-002-s150><arrest.nehmen><de> Von der Weltöffentlichkeit weitestgehend unbemerkt sind in den darauf folgenden Jahrzehnten 1.200.000 Tibeter durch Hunger, Zwangsarbeit, Haft, Folter und Hinrichtungen ums Leben gekommen.
<G-vec00185-002-s151><arrest.nehmen><en> (3) Every person arrested or detained shall be taken before the competent judge within 48 hours, who shall decide on the arrest or detention.
<G-vec00185-002-s151><arrest.nehmen><de> (3) Jeder Verhaftete oder Festgenommene ist binnen 48 Stunden dem zuständigen Richter zur Entscheidung über die Haft oder Festnahme vorzuführen.
<G-vec00185-002-s152><arrest.nehmen><en> At the moment 7 people targeted in the investigation of “the anarchists’ case” are staying under arrest.
<G-vec00185-002-s152><arrest.nehmen><de> Momentan sind sieben Personen Zielscheibe der Ermittlungen im “Verfahren gegen AnarchistInnen” und befinden sich in Haft.
<G-vec00185-002-s153><arrest.nehmen><en> In addition, the authorities have opened a criminal case on mass disorder and the night policy raided the offices of opposition candidates and human rights organisations such as “Viasna” (which had conducted local election observation) to arrest people, conduct searches and confiscate computer equipment and archives.
<G-vec00185-002-s153><arrest.nehmen><de> Darüber hinaus haben die Behörden Strafverfahren wegen nächtlicher Ruhestörung und Massenversammlung eingeleitet, Büros der Oppositions-Kandidaten durchsucht und Mitglieder von Menschenrechtsorganisationen wie „Viasna“ (die lokale Wahlbeobachtungen durchgeführt hatten) in Haft genommen.
<G-vec00185-002-s250><arrest.nehmen><en> The alerted police arrest the burglar and the three Turks are charged with dangerous bodily injury.
<G-vec00185-002-s250><arrest.nehmen><de> Die alarmierte Polizei nimmt den Einbrecher fest, die drei Türken erhalten Strafanzeige wegen gefährlicher Körperverletzung.
<G-vec00185-002-s251><arrest.nehmen><en> The police arrest one Afghan (23) for drug trafficking.
<G-vec00185-002-s251><arrest.nehmen><de> Die Polizei nimmt einen Afghanen (23) wegen Drogenhandels fest.
<G-vec00185-002-s252><arrest.nehmen><en> The police arrest the quintet and confiscate money, weapons, fake passports and electronic devices.
<G-vec00185-002-s252><arrest.nehmen><de> Die Polizei nimmt das Quintett fest und beschlagnahmt Geld, Waffen, gefälschte Pässe und elektronische Geräte.
<G-vec00185-002-s253><arrest.nehmen><en> Federal police arrest a 19-year-old Ghanaian with 25 ready-to-buy drug packets and promptly run him again Police speaks of \ [machine translation]
<G-vec00185-002-s253><arrest.nehmen><de> Bundespolizei nimmt einen 19-jährigen Ghanaer mit 25 verkaufsfertigen Drogenpäckchen fest und lässt ihn umgehend wieder laufen.
<G-vec00185-002-s258><arrest.verhaften><en> They insulted my cousin and then tried to arrest him.
<G-vec00185-002-s258><arrest.verhaften><de> Sie haben meinen Cousin beschimpft und dann versucht, ihn zu verhaften.
<G-vec00185-002-s259><arrest.verhaften><en> The workers and soldiers who had risen in revolt began to arrest tsarist ministers and generals and to free revolutionaries from jail.
<G-vec00185-002-s259><arrest.verhaften><de> Die aufständischen Arbeiter und Soldaten begannen, zaristische Minister und Generäle zu verhaften und Revolutionäre aus dem Gefängnis zu befreien.
<G-vec00185-002-s261><arrest.verhaften><en> When the harvesting group gets menaced with weapons the soldiers do not intervene, on the contrary, they threat to arrest the harvesters.
<G-vec00185-002-s261><arrest.verhaften><de> Als die Erntegruppe mit Waffen bedroht wird, schreiten die Soldaten nicht ein, im Gegenteil, die drohen damit, die Erntegruppe zu verhaften.
<G-vec00185-002-s262><arrest.verhaften><en> The police had unsuccessfully attempted to arrest Mr. Zhao Chuanwen twice in November 2000.
<G-vec00185-002-s262><arrest.verhaften><de> Im November 2000 hatte die Polizei zweimal erfolglos versucht, Zhao Chuanwen zu verhaften.
<G-vec00185-002-s263><arrest.verhaften><en> Commenting on the information that an arrest warrant has been issued against him and that he will be arrested if he enters Kosovo again, Vulin said that he had already experiences similar things and that it is interesting that Pristina is not able to shed light on attacks mounted on Serbs, but is ready to arrest him at any time.
<G-vec00185-002-s263><arrest.verhaften><de> Im Kommentar auf die Information, dass ein Haftbefehl gegen ihn ausgestellt worden ist und dass er, wenn er das Kosovo wieder betritt, verhaftet wird, sagte Vulin, dass er bereits ähnliche Dinge erlebt hat, und dass es interessant ist, dass Priština nicht in der Lage ist, Angriffe auf Serben zu lösen, jedoch bereit ist, ihn jederzeit zu verhaften.
<G-vec00185-002-s264><arrest.verhaften><en> 14 And he has come here with authority from the chief priests to arrest all who call on your name.”
<G-vec00185-002-s264><arrest.verhaften><de> Auch hier hat er Vollmacht von den Hohenpriestern, alle zu verhaften, die deinen Namen anrufen“.
<G-vec00185-002-s265><arrest.verhaften><en> Sun Yihe also threatened to arrest Ms. Wang's mother and make her younger brother and father lose their jobs if Ms. Wang could not explain the whereabouts of the phantom printer.
<G-vec00185-002-s265><arrest.verhaften><de> Sun Yihe drohte auch, Frau Wangs Mutter zu verhaften und dafür zu sorgen, dass ihr jüngerer Bruder und ihre Vater ihre Jobs verlieren, wenn Frau Wang nicht erklären könne, wo der Drucker sich befinde.
<G-vec00185-002-s266><arrest.verhaften><en> I was very worried that the Gestapo would arrest me again.
<G-vec00185-002-s266><arrest.verhaften><de> Ich war sehr in Sorge, dass die Gestapo mich wieder verhaften könnte.
<G-vec00185-002-s267><arrest.verhaften><en> It led to several attacks lately and now it is your task to find and arrest the troublemaker Suspect X.
<G-vec00185-002-s267><arrest.verhaften><de> Doch es führte zu mehreren Angriffen und nun ist es Deine Aufgabe, den Unruhestifter „Suspect X“ zu finden und zu verhaften.
<G-vec00185-002-s268><arrest.verhaften><en> When another suicide bomber cripples the power infrastructure and kills numerous Cylons and humans, police forces storm through the city and arrest numerous people, including Roslin.
<G-vec00185-002-s268><arrest.verhaften><de> Nachdem bei einem weiteren Selbstmordanschlag die Energieinfrastruktur der Stadt lahm gelegt wird und zahlreiche Zylonen und Menschen getötet werden, stürmen Polizeikräfte durch die Stadt und verhaften 200 verdächtigte Widerstands-Mitglieder, einschließlich Tom Zarek, Cally Tyrol und Roslin.
<G-vec00185-002-s269><arrest.verhaften><en> Speak with characters, investigate crime scenes, guess who lies, look at your dreams to find clues and try to arrest the killer before it’s too late.
<G-vec00185-002-s269><arrest.verhaften><de> Sprich mit den Charakteren, untersuche Tatorte, überlege, wer lügt, sieh dir deine Träume an, um Hinweise zu erhalten und versuche, den Mörder zu verhaften, bevor es zu spät ist.
<G-vec00185-002-s270><arrest.verhaften><en> They attempted to break into her home to arrest her, but they were unable to open the anti-theft iron gate.
<G-vec00185-002-s270><arrest.verhaften><de> Sie wollten in ihre Wohnung einbrechen, um sie zu verhaften, konnten jedoch das diebstahlgesicherte Eisengitter nicht öffnen.
<G-vec00185-002-s271><arrest.verhaften><en> When asked why the 610 Office would arrest Mr. Yu, the teacher said, "There is an article on the Minghui website [Chinese version of Clearwisdom.net] exposing how Yu Yaou and his wife were persecuted because of their belief in Falun Gong.
<G-vec00185-002-s271><arrest.verhaften><de> Auf die Frage, warum das „Büro 610“ Herrn Yu verhaften würde, sagte der Lehrer: „Es gibt einen Artikel auf der Minghui-Webseite, der darlegt, wie Yu Yaou und seine Frau wegen ihres Glaubens an Falun Gong verfolgt wurden.
<G-vec00185-002-s272><arrest.verhaften><en> Natural News 14 Nov. 2016: The discussion covers the truth of how Hillary Clinton had planned to arrest, silence or execute all the conservatives in the media in order to eliminate opposition and create a one-party state run as a totalitarian leftist regime.
<G-vec00185-002-s272><arrest.verhaften><de> 2016: Die Diskussion verhüllt die Wahrheit, wie Hillary Clinton geplant hatte, alle Konservativen in den Medien zu verhaften, zum Schweigen zu bringen oder zu ermorden, um die Opposition zu eliminieren und einen Einparteienstaat als totalitäres linkes Regime zu schaffen.
<G-vec00185-002-s273><arrest.verhaften><en> Nor will I allow you to arrest them, as all of what you've done is against heavenly principles.
<G-vec00185-002-s273><arrest.verhaften><de> Noch werde ich euch erlauben, sie zu verhaften, denn alles was ihr getan habt, ist gegen die himmlischen Prinzipien gerichtet.
<G-vec00185-002-s274><arrest.verhaften><en> My husband was afraid that they would arrest me.
<G-vec00185-002-s274><arrest.verhaften><de> Mein Mann hatte Angst, dass sie mich verhaften würden.
<G-vec00185-002-s275><arrest.verhaften><en> The National Security Squadron police knew if they came to my house to arrest me, all my family members and neighbours would criticise and stop them, and they would not succeed.
<G-vec00185-002-s275><arrest.verhaften><de> Die nationale Sicherheitsgruppe der Polizei wusste, dass alle meine Familienmitglieder und Nachbarn sie kritisieren und hindern würden, wenn sie in mein Haus kämen, um mich zu verhaften.
<G-vec00185-002-s276><arrest.verhaften><en> At the press conference, Pang Jin said that the Chinese Communist Party is using the Olympics as an excuse to arrest Falun Gong practitioners.
<G-vec00185-002-s276><arrest.verhaften><de> Bei der Pressekonferenz sagte Pang Jin, dass die Kommunistische Partei Chinas (KPCh) die Olympischen Spiele als Vorwand benutze, um Falun Gong-Praktizierende zu verhaften.
<G-vec00185-002-s277><arrest.verhaften><en> Today, after the arrest of all the first-rate mafia bosses, their close and distant relatives still live in Corleone, the place that functioned as the bloody brawn and the brain of the Mafia.
<G-vec00185-002-s277><arrest.verhaften><de> Heute, nachdem alle wichtigen Mafiabosse verhaftet sind, leben in Corleone noch die Familien derer, die das Hirn und gleichzeitig auch der bewaffnete Arm der Mafia waren.
<G-vec00185-002-s278><arrest.verhaften><en> Elam declared that the arrest of the Christians would not have been ordered if they had stopped praying and accepted the fact that Jesus can only be freed from the prison at the appointed time.
<G-vec00185-002-s278><arrest.verhaften><de> Elam sagte mir, dass die Christen nicht verhaftet worden wären, wenn sie aufgehört hätten zu beten, und wenn sie akzeptiert hätten, dass Jesus zu dem vom Astralgericht festgelegten Zeitpunkt aus dem Gefängnis entlassen werden könnte.
<G-vec00185-002-s279><arrest.verhaften><en> Day after day I was with you in the temple teaching, and you did not arrest me. But let the scriptures be fulfilled.”
<G-vec00185-002-s279><arrest.verhaften><de> Tag für Tag war ich bei euch im Tempel und lehrte und ihr habt mich nicht verhaftet; aber (das ist geschehen), damit die Schrift in Erfüllung geht.
<G-vec00185-002-s280><arrest.verhaften><en> However, Chang still continues to arrest and participate in the persecution of practitioners.
<G-vec00185-002-s280><arrest.verhaften><de> Chang jedoch verhaftet weiterhin Praktizierende und beteiligt sich an deren Verfolgung.
<G-vec00185-002-s281><arrest.verhaften><en> Police arrest them solely on a complaint of a husband or relative.
<G-vec00185-002-s281><arrest.verhaften><de> Die Polizei verhaftet sie bereits aufgrund einer einfachen Beschwerde durch den Ehemann oder Verwandte.
<G-vec00185-002-s282><arrest.verhaften><en> 49 I was daily with you in the temple teaching, and you didn’t arrest me. But this is so that the Scriptures might be fulfilled.”
<G-vec00185-002-s282><arrest.verhaften><de> 49 Tag für Tag war ich bei euch im Tempel und lehrte und ihr habt mich nicht verhaftet; aber (das ist geschehen), damit die Schrift in Erfüllung geht.
<G-vec00185-002-s283><arrest.verhaften><en> His rants against the Girondins in 1793 were instrumental in their inciting their arrest.
<G-vec00185-002-s283><arrest.verhaften><de> Seine Beschimpfungen gegen die Girondins im Jahr 1793 trugen maßgeblich dazu bei, dass sie verhaftet wurden.
<G-vec00185-002-s285><arrest.verhaften><en> My son and I had to spend the Spring Festival at a relative's home in order to avoid arrest.
<G-vec00185-002-s285><arrest.verhaften><de> Mein Sohn und ich mussten das Frühjahrsfest bei einem Verwandten verbringen, um nicht verhaftet zu werden.
<G-vec00185-002-s286><arrest.verhaften><en> If opposition candidates have been allowed to run and were actually elected, as occurred in Burma in 1990 and Nigeria in 1993, results may simply be ignored and the victors subjected to intimidation, arrest, or even execution.
<G-vec00185-002-s286><arrest.verhaften><de> Wenn Vertreter der Opposition kandidieren durften und auch tatsächlich gewählt wurden wie etwa 1990 in Birma und 1993 in Nigeria, werden die Ergebnisse einfach ignoriert und die «Sieger» eingeschüchtert, verhaftet oder gar hingerichtet.
<G-vec00185-002-s287><arrest.verhaften><en> Back to Paris, Armand was put under arrest at the airport and kept in custody for 17 hours.
<G-vec00185-002-s287><arrest.verhaften><de> Bei seiner Rückkehr in Paris wurde Armand am Flughafen verhaftet und während 17 Stunden in Gewahrsam genommen.
<G-vec00185-002-s288><arrest.verhaften><en> Beyond this, Mexico's migratory policy stresses the arrest and deportation of migrants, leading to the possibility of further human rights violations.
<G-vec00185-002-s288><arrest.verhaften><de> Auf der anderen Seite werden Migrant_innen von der Grenzpolizei verhaftet und deportiert, was zu einer weiteren Reihe von Menschenrechtsverletzungen führen kann.
<G-vec00185-002-s289><arrest.verhaften><en> Miss Suu Kyi was charged on Thursday May 14th with having violated the terms of her house arrest by having abetted an uninvited intruder, John Yettaw, an American man.
<G-vec00185-002-s289><arrest.verhaften><de> Im Mai 2009 wurde Aung San Suu Kyi wenige Tage vor Auslaufen ihres Hausarrestes verhaftet und wegen Missachtung der Hausarrest-Bestimmungen in das Insein-Gefängnis in Rangun gebracht.
<G-vec00185-002-s291><arrest.verhaften><en> If private citizens dare own arms for self-defense against Israeli attackers and use them, the IDF and Shin Bet security service will arrest them.
<G-vec00185-002-s291><arrest.verhaften><de> Falls private Bürger es wagen, eigene Waffen zur Selbstverteidigung gegen die israelischen Angreifer zu besitzen und zu nutzen, werden sie von den israelischen Verteidigungskräften oder vom israelischen Geheimdienst Shin Bet verhaftet.
<G-vec00185-002-s292><arrest.verhaften><en> Since Adolphe’s arrest, Emma had always worn a medical corset. In it was an air pocket, where she carried a tiny Bible.
<G-vec00185-002-s292><arrest.verhaften><de> Seit Adolphe verhaftet worden war, hatte Emma ständig ein medizinisches Mieder mit einem Luftloch getragen, in dem sie eine kleine Bibel bei sich trug.
<G-vec00185-002-s293><arrest.verhaften><en> They claim the dead stranger has given them a secret message. When Franz disputes this, they summarily arrest him.
<G-vec00185-002-s293><arrest.verhaften><de> Sie behaupten, der tote Fremde habe eine geheime Botschaft überbracht, als Franz das bestreitet, wird er kurzerhand verhaftet.
<G-vec00185-002-s294><arrest.verhaften><en> This also partially explains why the police have a quota for the number of people they have to arrest.
<G-vec00185-002-s294><arrest.verhaften><de> Dies erklärt auch teilweise, warum die Polizei eine Quote für Menschen hat, die verhaftet werden müssen.
<G-vec00185-002-s295><arrest.verhaften><en> Her healthy and happy days, however, came to a halt following her arrest in 2014.
<G-vec00185-002-s295><arrest.verhaften><de> Ihr guter Gesundheitszustand und ihr glückliches Leben kamen jedoch zu einem abrupten Ende, als sie 2014 verhaftet wurde.
