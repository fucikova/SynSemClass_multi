<G-vec00045-002-s021><dodge.ausweichen><en> When a player is in danger of being shot, a time bubble appears around them, giving them enough time to dodge the bullets.
<G-vec00045-002-s021><dodge.ausweichen><de> Wenn ein Spieler in Gefahr ist, bildet sich eine Zeitblase um die Figur, in der sie in Zeitlupe den gegnerischen Projektilen ausweichen kann.
<G-vec00045-002-s022><dodge.ausweichen><en> Run, jump, dodge, look for secrets - all this in the game Forest Adventures! Torrent Download
<G-vec00045-002-s022><dodge.ausweichen><de> Laufen, springen, ausweichen, nach Geheimnissen suchen - all das im Spiel ist ein aufregendes Spiel.
<G-vec00045-002-s023><dodge.ausweichen><en> Dodge flying projectiles and shoot down the enemy, clearing the sky of the aggressor.
<G-vec00045-002-s023><dodge.ausweichen><de> Ausweichen fliegenden Projektilen und den Gegner abzuschießen, den Himmel des Angreifers zu löschen.
<G-vec00045-002-s024><dodge.ausweichen><en> Blessing of Sanctuary: Now only grants mana on dodge/parry/block.
<G-vec00045-002-s024><dodge.ausweichen><de> Segen des Refugiums: Gewährt nun nur Mana bei Ausweichen/Parieren/Blocken.
<G-vec00045-002-s025><dodge.ausweichen><en> The user must instruct the character to jump, slide, dodge, and pick up coins.
<G-vec00045-002-s025><dodge.ausweichen><de> Der Benutzer muss anweisen, den Charakter zu springen, gleiten, ausweichen und abholen Münzen.
<G-vec00045-002-s026><dodge.ausweichen><en> Make him dodge obstacles, let him collect coins and shoot the ball through the box to continue to a higher level.
<G-vec00045-002-s026><dodge.ausweichen><de> Lass ihn Hindernissen ausweichen, Münzen sammeln und den Ball durch das Tor hindurch schießen um stets wieder ein Level höher zu kommen.
<G-vec00045-002-s027><dodge.ausweichen><en> Players can bombard the enemy from a distance or close the gap and dodge shells point blank - all in an immersive first person perspective.
<G-vec00045-002-s027><dodge.ausweichen><de> Spieler können Gegener aus der Ferne attackieren oder die Distanz verkleinern und den Geschossen geschickt ausweichen und entpsrechend antworten - alles aus einer fesselnden 'First Person' Perspektive.
<G-vec00045-002-s028><dodge.ausweichen><en> There is a possibility that sites may route one to malicious malware, and one must dodge them.
<G-vec00045-002-s028><dodge.ausweichen><de> Es besteht die Möglichkeit, dass Websites eine zu böswilliger Malware leiten können, und man muss ihnen ausweichen.
<G-vec00045-002-s029><dodge.ausweichen><en> Our girls were especially happy about the overnight stay in the Prinzessinnen- / Hexenturm:) Unfortunately, the restaurant was not open in the evening and we had to dodge in one of the many restaurants in the area.
<G-vec00045-002-s029><dodge.ausweichen><de> Unsere Mädchen freuten sich besonders über die Übernachtung im Prinzessinnen-/ Hexenturm:) Leider war das Restaurant abends nicht geöffnet und wir mussten in eines der vielen Restaurants der Umgebung ausweichen.
<G-vec00045-002-s030><dodge.ausweichen><en> Penta can dodge, move slower or faster, and jump to avoid seals and cracks in the ice.
<G-vec00045-002-s030><dodge.ausweichen><de> Penta kann ausweichen, langsamer werden oder auch schneller und über Risse und Spalten im Eis springen.
<G-vec00045-002-s031><dodge.ausweichen><en> Sail your own boat like a real captain and choose whether you’ll bump’em or dodge’em!… Next to this attraction are the trampolines, the mini golf course and the Matterhorn.
<G-vec00045-002-s031><dodge.ausweichen><de> Lenke dein eigenes Boot wie ein echter Kapitän hin und her und entscheide dich zwischen zusammenstoßen mit den anderen oder ausweichen...
<G-vec00045-002-s032><dodge.ausweichen><en> Learn to Master each Superstar's method of triggering their abilities including Dodge, Parry, Pin Break and more
<G-vec00045-002-s032><dodge.ausweichen><de> Meistere das Auslösen der Fähigkeiten jedes Superstars, darunter Ausweichen, Parieren, Pin Break und mehr.
<G-vec00045-002-s033><dodge.ausweichen><en> Requires Shoulders Permanently adds 5 dodge and 4 Stamina to a shoulder slot item.
<G-vec00045-002-s033><dodge.ausweichen><de> Fügt einem Gegenstand für den Schulterplatz dauerhaft 7 Ausweichen und 3 Parieren hinzu.
<G-vec00045-002-s034><dodge.ausweichen><en> His most powerful attack, but also one of the easiest to dodge.
<G-vec00045-002-s034><dodge.ausweichen><de> Dies ist seine stärkste Attacke, aber auch die einfachste zum Ausweichen.
<G-vec00045-002-s035><dodge.ausweichen><en> Dodge: Rogues now roll 50% farther when dodging in combat and their dodge cost has been reduced to 30% of their stamina (down from 50%).
<G-vec00045-002-s035><dodge.ausweichen><de> Ausweichen: Beim Abrollen bewegen sich Trickserschurken jetzt 50% weiter weg, dies verbraucht nun 30% Ausdauer (dies war vorher 50% Ausdauer).
<G-vec00045-002-s036><dodge.ausweichen><en> You can also dodge the defending Pokémon's attacks by swiping left and right.
<G-vec00045-002-s036><dodge.ausweichen><de> Du kannst den Attacken des verteidigenden Pokémon ausweichen, indem du im Kampf nach links oder rechts streichst.
<G-vec00045-002-s037><dodge.ausweichen><en> Increases dodge by 210 for 20 sec.
<G-vec00045-002-s037><dodge.ausweichen><de> Erhöht das Ausweichen 20 sec lang um 210.
<G-vec00045-002-s038><dodge.ausweichen><en> Run, jump, dodge, look for secrets - all this in the game Swamp Adventures.
<G-vec00045-002-s038><dodge.ausweichen><de> Laufen, springen, ausweichen, nach Geheimnissen suchen - lustiges Spiel.
<G-vec00045-002-s039><dodge.ausweichen><en> A veteran leading a treated victim may dodge with that treated victim.
<G-vec00045-002-s039><dodge.ausweichen><de> Ein Veteran, der ein behandeltes Opfer führt, kann mit diesem behandelten Opfer ausweichen.
<G-vec00045-002-s045><dodge.ausweichen><en> Dodge bullets while typing exorcisms at the very same time: turn on both sides of your brain and jump into the adventure of Ray Bibbia, a private exorcist who's going to face the threats of a demonic outbreak and deal with his dark and sinful past at the same time!
<G-vec00045-002-s045><dodge.ausweichen><de> Es geht darum, den Kugeln auszuweichen, während Exorzismen einzutippen sind: beide Gehirnhälften einschalten und rein ins Abenteuer von Ray Bibbia, einem privaten Exorzist, der sich der Gefahr eines Dämonenausbruchs stellen muss, während er sich seiner eigenen dunklen und sündigen Vergangenheit stellen muss.
<G-vec00045-002-s046><dodge.ausweichen><en> Use this to dodge an incoming enemy attack.
<G-vec00045-002-s046><dodge.ausweichen><de> Verwende dies, um einem ankommenden feindlichen Angriff auszuweichen.
<G-vec00045-002-s047><dodge.ausweichen><en> It is not uncommon for a scout with high Evasion to dodge five or six shots in a row purely based on their build's focus on that stat.
<G-vec00045-002-s047><dodge.ausweichen><de> Als Scout ist es nicht ungewöhnlich fünf oder sechs Schüssen in Folge auszuweichen, nur basierend auf den Werten in Ausweichen.
<G-vec00045-002-s048><dodge.ausweichen><en> It was headed for Tenshinhan, who was unable to dodge it as Kulilin did due to his fatigue... It cut him cleanly through the torso diagonally.
<G-vec00045-002-s048><dodge.ausweichen><de> Er zielte auf Tenshinhan, der aufgrund seiner Müdigkeit nicht mehr im Stande war auszuweichen, wie es Krilin getan hatte… die Scheibe durchtrennte seinen Körper diagonal auf der Höhe seines Brustkorbes.
<G-vec00045-002-s049><dodge.ausweichen><en> The perfect way to dodge the traffic jams and have fun as you pedal before plunging into the cool waters!
<G-vec00045-002-s049><dodge.ausweichen><de> Ideal, um dem Verkehrschaos auszuweichen und sich vor dem Sprung ins kühle Nass bei Spiel und Spass zu erholen.
<G-vec00045-002-s050><dodge.ausweichen><en> Each player has 8 chances to try to land a hit and 8 changes to dodge the attack from the other player.
<G-vec00045-002-s050><dodge.ausweichen><de> Jeder der Spieler hat acht Chancen den anderen zu treffen und acht Chancen auszuweichen.
<G-vec00045-002-s051><dodge.ausweichen><en> Evasion Rating determines the Chance to Dodge [Stat] attacks directed at the Hero.
<G-vec00045-002-s051><dodge.ausweichen><de> Die Ausweichwertung bestimmt welche Chance der Held hat,gegen ihn gerichteten Angriffen auszuweichen.
<G-vec00045-002-s052><dodge.ausweichen><en> Help him jump on the platforms and dodge obstacles. Solve spacial puzzles.
<G-vec00045-002-s052><dodge.ausweichen><de> Hilf ihm über Plattformen zu springen, Hindernissen auszuweichen und große Puzzles zu lösen.
<G-vec00045-002-s053><dodge.ausweichen><en> Jump as high and as much as needed to dodge the deadly knives.
<G-vec00045-002-s053><dodge.ausweichen><de> Springen, so oft und so hoch wie nur möglich um die tödlichen Messern auszuweichen.
<G-vec00045-002-s054><dodge.ausweichen><en> Each one gives him unique abilities - for example, Aisha allows him to dodge through enemies with a stylish dash, while Wil can set up a defensive wall to block attacks.
<G-vec00045-002-s054><dodge.ausweichen><de> Jeder verleiht ihm einzigartige Fähigkeiten – Aisha beispielsweise erlaubt ihm, mit einem stilvollen Sprint Gegnern auszuweichen, während Wil einen Verteidigungswall zum Abblocken von Angriffen erschaffen kann.
<G-vec00045-002-s055><dodge.ausweichen><en> Prepare to run, jump, slide, dodge and fight your way through each level in your quest to become the...
<G-vec00045-002-s055><dodge.ausweichen><de> Bereite dich darauf vor zu laufen, zu springen, zu rutschen, auszuweichen und dich durch jedes Level...
<G-vec00045-002-s056><dodge.ausweichen><en> Show your skills by helping Quark to dodge the scrap piles, cranes and wrecking balls.
<G-vec00045-002-s056><dodge.ausweichen><de> Beweise deine Fähigkeiten, indem du Quark dabei hilfst, den Schrotthaufen, Kränen und Abrissbirnen auszuweichen.
<G-vec00045-002-s057><dodge.ausweichen><en> Plan, dodge attacks and kill.
<G-vec00045-002-s057><dodge.ausweichen><de> Plan, Angriffen auszuweichen und töten.
<G-vec00045-002-s058><dodge.ausweichen><en> Well, here we'll have to draw the tracks to dodge all the obstacles we come across.
<G-vec00045-002-s058><dodge.ausweichen><de> Naja, hier müssen wir die Schienen zeichnen, um allen Hindernissen auszuweichen, auf die wir stoßen.
<G-vec00045-002-s059><dodge.ausweichen><en> Evil monsters will attack the main character, so she needs your help to dodge in time.
<G-vec00045-002-s059><dodge.ausweichen><de> Böse Monster werden die Hauptfigur angreifen, also braucht sie Ihre Hilfe, um rechtzeitig auszuweichen.
<G-vec00045-002-s060><dodge.ausweichen><en> The goal of the game is to dodge the rotating baton by jumping up over it and landing back on your pedestal.
<G-vec00045-002-s060><dodge.ausweichen><de> Das Ziel des Spiels ist es, den rotierenden Taktstock auszuweichen, indem er über ihn hinaufspringt und auf deinem Sockel zurückkommt.
<G-vec00045-002-s061><dodge.ausweichen><en> Use it to break enemy shields or dodge fatal attacks.
<G-vec00045-002-s061><dodge.ausweichen><de> Nutze es, um feindliche Schilde zu durchbrechen und tödlichen Angriffen auszuweichen.
<G-vec00045-002-s062><dodge.ausweichen><en> Shield system "VAS" pursued Forme which is smoother and easier to dodge by lowering its mounting part by 24mm, using Snel standard testLine as a guide.
<G-vec00045-002-s062><dodge.ausweichen><de> Shield-System "VAS" verfolgt Forme, die glatter und leichter auszuweichen ist, indem sie ihr Montageteil um 24mm senkt, indem sie den Snel-Standard testLine als Richtlinie verwendet.
<G-vec00045-002-s063><dodge.ausweichen><en> Videl had seen it all, realized it too late, and could do nothing; if she let go of the sword in order to dodge the next blow, Cold would never let her recover her weapon.
<G-vec00045-002-s063><dodge.ausweichen><de> Videl hatte das sehr wohl gesehen, konnte aber nichts dagegen machen: würde sie ihr Schwert loslassen, um dem Schlag auszuweichen, würde Cold es ihr niemals erlauben, sich ihre Waffe zurückzuholen.
<G-vec00045-002-s123><dodge.ausweichen><en> Explore huge levels, swing between buildings and skillfully dodge traps.
<G-vec00045-002-s123><dodge.ausweichen><de> Erkunde enorme Level, schwinge von Gebäude zu Gebäude und weiche geschickt Fallen aus.
<G-vec00045-002-s124><dodge.ausweichen><en> KO as many opponents as you can, but dodge their attacks.
<G-vec00045-002-s124><dodge.ausweichen><de> Schlage möglichst viele Gegner KO und weiche dabei ihren Angriffen aus.
<G-vec00045-002-s125><dodge.ausweichen><en> Dual with bosses, dodge opponents, drink, smoke, and try to survive.
<G-vec00045-002-s125><dodge.ausweichen><de> Kombiniere dich mit Bossen, weiche deinen Gegnern aus, trinke, rauche und versuche zu überleben.
<G-vec00045-002-s126><dodge.ausweichen><en> Dodge obstacles across different landscapes and cityscapes in this mash-up between a endless runner and stunt-based skateboard games.
<G-vec00045-002-s126><dodge.ausweichen><de> Weiche in diesem Mashup aus Endless-Runner und Skateboard-Spiel Hindernissen aus, während du verschiedenste Landschaften und Städte bereist.
<G-vec00045-002-s127><dodge.ausweichen><en> Dodge Fenris’ huge paws and the Berserkers' blades.
<G-vec00045-002-s127><dodge.ausweichen><de> Weiche Fenris‘ gewaltigen Pfoten und den Klingen der Berserker aus.
<G-vec00045-002-s128><dodge.ausweichen><en> Dodge the giant eggs launched from the tank’s dual catapult.
<G-vec00045-002-s128><dodge.ausweichen><de> Weiche den Rieseneiern aus, die von dem Doppelkatapult des Gefährts losgeschleudert werden.
<G-vec00045-002-s129><dodge.ausweichen><en> Run, jump and dodge your way through a cavalcade of cannon balls, flame traps, laser beams and wild animals - the crowd rooting for your demise every step of
<G-vec00045-002-s129><dodge.ausweichen><de> Renne, springe und weiche aus auf deinem Weg durch eine Kavalkade von Kanonenkugeln, Flammenfallen, Laserstrahlen und wilden Tieren – die Menge freut sich währenddessen bei jedem deiner Schritte auf deinen Untergang.
<G-vec00045-002-s130><dodge.ausweichen><en> Parry incoming attacks, dodge out of danger, and finish the Empire’s forces before they finish you.
<G-vec00045-002-s130><dodge.ausweichen><de> Pariere Angriffe, weiche der Gefahr aus, und besiege die Truppen des Imperiums, bevor sie dich besiegen.
<G-vec00045-002-s131><dodge.ausweichen><en> Dodge the red ennemies and their arrows, grab the red flag and come back to your blue base.
<G-vec00045-002-s131><dodge.ausweichen><de> Weiche den roten Gegner und ihren Pfeilen aus, sammle die rote Flage ein und kehre damit zu deiner blauen Basis zurück.
<G-vec00045-002-s132><dodge.ausweichen><en> Attack, dodge, block, and utilize various super powers including flight, super speed, and heat vision to defeat Zod and his evil forces.
<G-vec00045-002-s132><dodge.ausweichen><de> - Greife an, weiche aus, blocke und nutze verschiedene Superkräfte wie Supermans Flugfähigkeit, Supergeschwindigkeit und Hitzeblick, um Zod und seine bösen Mächte zu besiegen.
<G-vec00045-002-s133><dodge.ausweichen><en> Dodge moving obstacles and fly over jumps by tilting and turning your device.
<G-vec00045-002-s133><dodge.ausweichen><de> Weichen Sie beweglichen Hindernissen aus und fliegen Sie über Abgründe, indem Sie Ihr Gerät neigen und drehen.
<G-vec00045-002-s134><dodge.ausweichen><en> Race through a marina, speed across super-slippy ice and dodge flying tomatoes in this brand new F1 RACE STARS circuit!
<G-vec00045-002-s134><dodge.ausweichen><de> Weichen Sie auf dieser brandneuen F1 RACE STARS-Strecke den mürrischen Murmeltieren aus und rasen Sie über einen zugefrorenen Fluss.
<G-vec00045-002-s135><dodge.ausweichen><en> Dodge some attacks by jumping.
<G-vec00045-002-s135><dodge.ausweichen><de> Weichen Sie einige Angriffe durch einen Sprung aus.
<G-vec00045-002-s136><dodge.ausweichen><en> You run through the level, avoiding collisions with blocks and spikes, jump over the pits and dodge sharp saw blades.
<G-vec00045-002-s136><dodge.ausweichen><de> Sie rennen durch das Level, vermeiden Kollisionen mit Blöcken und Stacheln, springen über die Gruben und weichen scharfen Sägeblättern aus.
<G-vec00045-002-s137><dodge.ausweichen><en> Make your way through the colourful areas and dodge all the other players and the dangerous obstacles you come across.
<G-vec00045-002-s137><dodge.ausweichen><de> Machen Sie Ihren Weg durch die bunten Gebiete und weichen alle anderen Spieler und die gefährlichen Hindernisse aus, auf die Sie stoßen.
<G-vec00045-002-s138><dodge.ausweichen><en> In Infinite Dribble, tilt your phone or tablet to dodge defenders and roadblocks.
<G-vec00045-002-s138><dodge.ausweichen><de> Weicht in Infinite Dribble mit eurem Handy oder Tablet Verteidigern und Hindernissen aus.
<G-vec00045-002-s139><dodge.ausweichen><en> Dodge all incoming projectiles, but only while not attacking.
<G-vec00045-002-s139><dodge.ausweichen><de> Weicht allen Projektilen aus, jedoch nur, wenn man nicht angreift.
<G-vec00045-002-s140><dodge.ausweichen><en> Dodge the mummies by clever control of your balloon and decide for yourselves how high you want to go.
<G-vec00045-002-s140><dodge.ausweichen><de> Weicht den Mumien durch geschickte Steuerung eures Ballons aus und entscheidet selbst, wie hoch ihr fliegen wollt.
<G-vec00045-002-s107><dodge.entgehen><en> For theme parks, head to Disneyland®, Universal Studios Hollywood, SeaWorld, San Diego Zoo (and its sister Wild Animal Park), Legoland, Monterey Bay Aquarium, and other attractions—go mid-week to dodge crowds.
<G-vec00045-002-s107><dodge.entgehen><de> Oder besuchen Sie Kaliforniens Freizeitparks: Disneyland ® natürlich, die Universal Studios in Hollywood, und andere Attraktionen; am besten unter der Woche, um den großen Besuchermassen zu entgehen.
<G-vec00045-002-s108><dodge.entgehen><en> Halflings can be used with all classes and introduce the new Luck mechanic which allows them to dodge incoming attack while they're in good spirits.
<G-vec00045-002-s108><dodge.entgehen><de> Halblinge können mit allen Klassen genutzt werden und ihre neue Glücks-Mechanik ermöglicht es ihnen, Angriffen zu entgehen, solange sie guter Stimmung sind.
<G-vec00045-002-s111><dodge.entziehen><en> When artificial intelligence makes all offers completely interchangeable, the winners will be those who manage to dodge this factual interchangeability.
<G-vec00045-002-s111><dodge.entziehen><de> Wenn die Künstliche Intelligenz alle Angebote total vergleichbar macht, werden jene gewinnen, die sich dieser faktischen Vergleichbarkeit entziehen.
<G-vec00045-002-s112><dodge.entziehen><en> When MEPs lift Le Pen's immunity and the decision is notified to judges, the far-right leader could still be in a position to dodge the judges' summons.
<G-vec00045-002-s112><dodge.entziehen><de> Wenn die Europaabgeordneten Le Pens Immunität aufheben und die Entscheidung den Richtern mitgeteilt wurde, dann könnte die rechtsextreme Anführerin immer noch in der Lage sein sich der Vorladung der Richter zu entziehen.
<G-vec00045-002-s121><dodge.vermeiden><en> In platform games player has to collect prizes, jump over obstacles or run around them and dodge enemies.
<G-vec00045-002-s121><dodge.vermeiden><de> Das Ziel ist die Preise zu sammeln, über Hindernisse zu springen und die Feinde zu vermeiden.
<G-vec00045-002-s122><dodge.vermeiden><en> Undeniably, those who willfully shut out God from their hearts and try to dodge religious questions are not following the dictates of their consciences, and hence are not free of blame; yet believers themselves frequently bear some responsibility for this situation.
<G-vec00045-002-s122><dodge.vermeiden><de> Gewiß sind die, die in Ungehorsam gegen den Spruch ihres Gewissens absichtlich Gott von ihrem Herzen fernzuhalten und religiöse Fragen zu vermeiden suchen, nicht ohne Schuld; aber auch die Gläubigen selbst tragen daran eine gewisse Verantwortung.
