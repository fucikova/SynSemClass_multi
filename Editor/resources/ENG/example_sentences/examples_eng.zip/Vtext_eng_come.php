<G-vec00078-001-s019><come.besuchen><en> Contact Activities Come and meet us at Bauma 2019 in Munich.
<G-vec00078-001-s019><come.besuchen><de> Kontakt Aktivitäten Besuchen Sie uns auf der Bauma 2019 in München.
<G-vec00078-001-s020><come.besuchen><en> You should not want to pick the first lawyer you come across.
<G-vec00078-001-s020><come.besuchen><de> You suchen sollte, wie die Wahl der ersten Anwalt Rausfinden vielleicht das Gefühl, die Sie besuchen.
<G-vec00078-001-s021><come.besuchen><en> Come and talk to us at one of our branches or contact KBC Live.
<G-vec00078-001-s021><come.besuchen><de> Besuchen Sie eine unserer Filialen oder kontaktieren Sie KBC Live.
<G-vec00078-001-s022><come.besuchen><en> Come to the Bike Library in Civic Park anytime 11am - 4pm for a workshop on fixing a bike.
<G-vec00078-001-s022><come.besuchen><de> Besuchen Sie die Bike Library im Civic Park jederzeit zwischen 11 und 16 Uhr, um einen Workshop zum Reparieren eines Fahrrads zu erhalten.
<G-vec00078-001-s023><come.besuchen><en> 29:10 For this is what the Lord has said: When seventy years are ended for Babylon, I will have pity on you and give effect to my good purpose for you, causing you to come back to this place.
<G-vec00078-001-s023><come.besuchen><de> 29:10 Denn so spricht der HERR: Wenn zu Babel siebenzig Jahre aus sind, so will ich euch besuchen und will mein gnädiges Wort über euch erwecken, daß ich euch wieder an diesen Ort bringe.
<G-vec00078-001-s024><come.besuchen><en> Take a break from the usual sightseeing and shopping and come Play In The Clay with a 3-4 hour introductory Pottery Wheel Class.
<G-vec00078-001-s024><come.besuchen><de> Machen Sie eine Pause von den üblichen Sightseeing- und Shopping-Touren und besuchen Sie Play In The Clay mit einer 3-4-stündigen Einführung in die Töpferscheibe.
<G-vec00078-001-s025><come.besuchen><en> It’s so important to see and touch products and to get to know the people behind them – come and meet us at our next events.
<G-vec00078-001-s025><come.besuchen><de> Produkte zu sehen und anzufassen und die Menschen hinter dem Produkt zu kennen ist wichtig - Besuchen Sie uns auf unseren Messeständen.
<G-vec00078-001-s026><come.besuchen><en> Come see us soon and get into the fun and the sun.
<G-vec00078-001-s026><come.besuchen><de> Besuchen Sie uns bald und sich in dem Spaß und der Sonne.
<G-vec00078-001-s027><come.besuchen><en> Come see us at stall D16 and get to know our new products.
<G-vec00078-001-s027><come.besuchen><de> Besuchen Sie uns an unserem Messestand D16 und machen Sie sich mit unseren Neuheiten vertraut.
<G-vec00078-001-s028><come.besuchen><en> "Come to the exhibition Motorrader 2014 and learn all about the ""iron horses"" feel the real drive and thirst for speed."
<G-vec00078-001-s028><come.besuchen><de> "Besuchen Sie die Ausstellung Motorräder 2014 und erfahren Sie alles über den ""Eisernen Pferde"" fühlen die echte Laufwerk und Durst nach Geschwindigkeit."
<G-vec00078-001-s029><come.besuchen><en> If you're interested in the comfort of your dropshipping shop customers, come to BigBuy and purchase our range of wellbeing products, like the fun Big Tribe Snug Snug blanket with sleeves, at wholesale price.
<G-vec00078-001-s029><come.besuchen><de> Wenn Ihnen der Komfort der Kunden Ihres Dropshipping-Shops am Herzen liegt, dann besuchen Sie BigBuy und kaufen Sie unsere große Auswahl an Wohlfühl-Produkten wie die Big Tribe Snug Snug Decke mit Ärmeln zum Großhandelspreis.
<G-vec00078-001-s030><come.besuchen><en> So come join us for a game of Innocence or Temptation online slots.
<G-vec00078-001-s030><come.besuchen><de> Besuchen Sie uns also und spielen Sie den Online Spielautomaten Innocence or Temptation.
<G-vec00078-001-s031><come.besuchen><en> It will be record-breaking appearance for David in Denver, as he will come back to the best NHL town in the USA for the fifth time.
<G-vec00078-001-s031><come.besuchen><de> Für David wird es ein neuer Eurolanche Rekord, da er bereits das fünfte mal die beste NHL Stadt der USA besuchen wird.
<G-vec00078-001-s032><come.besuchen><en> The islet of Paolina owes its fame and its name to the sister of Napoleon Bonaparte (Paolina Borghese), who during the period of exile of his brother Emperor, liked to come to this place to sunbathe and swim.
<G-vec00078-001-s032><come.besuchen><de> Die Isolotto della Paolina verdankt ihren Ruhm und ihren Nahmen der Schwester von Napoleon Bonaparte (Paolina Borghese), die es während des Exils ihres Bruders liebte, diesen Ort zum sonnen und schwimmen gehen zu besuchen.
<G-vec00078-001-s033><come.besuchen><en> Come check us out, we're waiting to meet you!Please Note: Though we make every attempt to do so, we cannot guarantee that everyone in your party will be able to stay in the same room.
<G-vec00078-001-s033><come.besuchen><de> Besuchen Sie uns noch, wir warten auf Sie!Bitte beachten Sie: Obwohl wir jeden Versuch, dies zu tun zu machen, knnen wir nicht garantieren, dass jeder in Ihrer Partei in der Lage, im selben Raum bleiben.
<G-vec00078-001-s034><come.besuchen><en> “We have come to the exhibition to share our information on the latest Snack trends and to exchange information between snack producers and suppliers”, says Charlotte Huggins, Business Development Director at Symrise.
<G-vec00078-001-s034><come.besuchen><de> “Wir besuchen die Messe, um über aktuelle Snack-Trends zu informieren und Informationen zwischen Snack-Herstellern und -anbietern auszutauschen“, erklärt Charlotte Huggins, Business Development Director bei Symrise.
<G-vec00078-001-s035><come.besuchen><en> Come to this city in Andalusia and make your business meeting into something unforgettable.
<G-vec00078-001-s035><come.besuchen><de> Besuchen Sie diese Stadt in Andalusien und machen Sie Ihre geschäftliche Sitzung zu etwas Unvergesslichem.
<G-vec00078-001-s036><come.besuchen><en> Come and try out this unique two-story indoor kart racing track in Olomouc.
<G-vec00078-001-s036><come.besuchen><de> Besuchen Sie die außergewöhnliche überdachte zweigeschossige Kartrennbahn in Olomouc.
<G-vec00078-001-s037><come.besuchen><en> If you end up near this area, you should certainly come to Honeymoon Valley; trust us - you will not regret it.
<G-vec00078-001-s037><come.besuchen><de> Wenn Sie verursachen in diesem Bereich setzen, achten Sie darauf das Honey Valley besuchen, vertrauen Sie, werden Sie nicht bereuen.
<G-vec00078-001-s171><come.gehen><en> < 6:6 All the days that he separateth himself unto Jehovah he shall not come near to a dead body.
<G-vec00078-001-s171><come.gehen><de> < 6:6 Während der ganzen Zeit, für welche er sich dem HERRN geweiht hat, soll er zu keinem Toten gehen.
<G-vec00078-001-s172><come.gehen><en> 7:12 And the king arose in the night, and said unto his servants, I will now shew you what the Syrians have done to us. They know that we be hungry; therefore are they gone out of the camp to hide themselves in the field, saying, When they come out of the city, we shall catch them alive, and get into the city.
<G-vec00078-001-s172><come.gehen><de> 7:12 Und der König stand in der Nacht auf und sprach zu seinen Knechten: Ich will euch doch sagen, was die Syrer mit uns vorhaben: Sie wissen, daß wir Hunger leiden, und sind aus dem Lager gegangen, um sich im Felde zu verbergen, und denken: Wenn die aus der Stadt gehen, wollen wir sie lebendig fangen und in die Stadt eindringen.
<G-vec00078-001-s173><come.gehen><en> Significantly reduced charging times will come with the introduction of fast charging by the Combined Charging System (CCS).
<G-vec00078-001-s173><come.gehen><de> Deutlich reduzierte Ladezeiten gehen mit der Einführung des Schnellladens via Combined Charging System (CCS) einher.
<G-vec00078-001-s174><come.gehen><en> "Calling for a ""People's Democratic Revolution"", founding leader Charu Mazumdar wrote in 1970 that ""the majority of the business community will come with us."
<G-vec00078-001-s174><come.gehen><de> "In seinem Aufruf zu einer ""Demokratischen Volksrevolution"" schrieb ihr Gründer und Führer Charu Mazumdar 1970, dass ""die Mehrheit der Geschäftswelt mit uns gehen wird."
<G-vec00078-001-s175><come.gehen><en> That will enable the transition from the old system to the new to come about without the dam breaking, so to say.
<G-vec00078-001-s175><come.gehen><de> Das wird den Übergang vom alten in das neue System sozusagen ohne Dammbruch vonstatten gehen lassen.
<G-vec00078-001-s176><come.gehen><en> From the medium quality elements and a second churning, come the seven golden mountains.
<G-vec00078-001-s176><come.gehen><de> Aus den Elemente mittlerer Qualität und einem zweiten Prozess des Aufwühlens gehen die sieben goldenen Bergketten hervor.
<G-vec00078-001-s177><come.gehen><en> Bahr once stated that his policies were based on the core axiom that “people have to come first” and that “every conceivable and responsible attempt” must be made to improve their lives and their prospects for the future.
<G-vec00078-001-s177><come.gehen><de> Bahr hatte als Grundaxiom seiner Politik einmal festgehalten – und ich zitiere – dass es „zunächst um die Menschen zu gehen“ hat „und um die Ausschöpfung jedes denkbar und verantwortbaren Versuchs“, deren Leben und deren Zukunftschancen zu verbessern.
<G-vec00078-001-s178><come.gehen><en> It's important to me that my co-workers like to come to work and enjoy it.
<G-vec00078-001-s178><come.gehen><de> Mir ist es wichtig, dass meine Mitarbeiter gerne zur Arbeit gehen und Spaß daran haben.
<G-vec00078-001-s179><come.gehen><en> If one day, large spectacular festivals of world music were jointly organized, then a great dream would have come true.
<G-vec00078-001-s179><come.gehen><de> Wenn es eines Tages spektakuläre, gemeinsam veranstaltete größere Festivals der Weltmusik geben könnte, würde ein großer Traum in Erfüllung gehen.
<G-vec00078-001-s180><come.gehen><en> If you save and restart at this point, you don ́t even have to bother, you can deliver your photo, come back and you will find her at the front door of this room.
<G-vec00078-001-s180><come.gehen><de> Wenn du an dieser Stelle speicherst und neu startest ist es noch einfacher, du kannst das Foto abliefern gehen und findest sie anschließend an der Tür von diesem Raum wieder.
<G-vec00078-001-s181><come.gehen><en> Walk between the Bijenkorf and River Island, through the Chinese gate. Follow this road for 450 m until you come to the canal, where you will turn right.
<G-vec00078-001-s181><come.gehen><de> Gehen Sie zwischen dem Kaufhaus Bijenkorf und River Island unter dem chinesischen Tor hindurch und folgen Sie diesem Weg 450 Meter bis an die Gracht, wo Sie nach rechts gehen.
<G-vec00078-001-s182><come.gehen><en> Superior protection doesn't have to come at the cost of comfort or control.
<G-vec00078-001-s182><come.gehen><de> Überlegener Schutz muss nicht auf Kosten von Komfort und Kontrolle gehen.
<G-vec00078-001-s183><come.gehen><en> With the right financing, your dream of owning your own home can come true faster than you can imagine.
<G-vec00078-001-s183><come.gehen><de> Ihre Hypothek Mit der passenden Finanzierung kann der Traum vom Eigenheim schneller in Erfüllung gehen, als Sie es sich vorstellen.
<G-vec00078-001-s184><come.gehen><en> Now we come to the most spectacular features.
<G-vec00078-001-s184><come.gehen><de> Wir gehen nun auf die spektakulärsten Eigenschaften ein.
<G-vec00078-001-s185><come.gehen><en> However, with that the Merkel era will also come to an end .
<G-vec00078-001-s185><come.gehen><de> Damit wird aber auch die Ära Merkel zu Ende gehen.
<G-vec00078-001-s186><come.gehen><en> A wish that, at least on vacation in Salzburg come true, because there are several castle hotels.
<G-vec00078-001-s186><come.gehen><de> Ein Wunsch, der zumindest im Urlaub in Salzburg in Erfüllung gehen kann, denn hier gibt es gleich mehrere Schlosshotels.
<G-vec00078-001-s187><come.gehen><en> It is advisable to start looking as soon as possible and before you come to Germany.
<G-vec00078-001-s187><come.gehen><de> Deswegen raten wir Ihnen möglichst vor Beginn Ihres Aufenthalts in Deutschland auf Wohnungssuche zu gehen.
<G-vec00078-001-s188><come.gehen><en> Unmarried, but not lonely female Maidens come this year to the long-awaited, deserved final stage of check on durability with the beloved.
<G-vec00078-001-s188><come.gehen><de> Unverheiratet, aber die nicht einsamen Frauen-Jungfrauen gehen in diesem Jahr auf die langersehnte, verdiente abschließende Etappe der Prüfung auf die Haltbarkeit mit den Geliebten hinaus.
<G-vec00078-001-s189><come.gehen><en> My holidays come to an end.
<G-vec00078-001-s189><come.gehen><de> Meine Ferien gehen zu Ende.
<G-vec00042-001-s190><come.kommen><en> 21 Then they said one to another, We are indeed guilty concerning our brother, whose anguish of soul we saw when he besought us, and we did not hearken; therefore this distress is come upon us.
<G-vec00042-001-s190><come.kommen><de> 21 Da sprachen sie einer zum anderen: Fürwahr, wir sind schuldig (O. wir büßen) wegen unseres Bruders, dessen Seelenangst wir sahen, als er zu uns flehte, und wir hörten nicht; darum ist diese Drangsal über uns gekommen.
<G-vec00042-001-s191><come.kommen><en> Since I previously had a questionable customers on ebay, it seems likely that it is so come to my account number ran.
<G-vec00042-001-s191><come.kommen><de> Da ich zuvor einen fragwürdigen Kunden bei ebay hatte, liegt die Vermutung nahe, dass man so an meine Kontonummer ran gekommen ist.
<G-vec00042-001-s192><come.kommen><en> The day has come when the dead arose from their graves and started roaming the lands.
<G-vec00042-001-s192><come.kommen><de> Der Tag ist gekommen, wenn die Toten aus ihren Gräbern stand auf und begann durch die Lande.
<G-vec00042-001-s193><come.kommen><en> Through symbols and prophecies, God shows how and when the infilling of the Holy Spirit would take place; and also what would happen when this wonderful Spirit has come - His signs, His work in the people through HIM.
<G-vec00042-001-s193><come.kommen><de> Durch Symbole und Weissagungen zeigt Gott, wie und wann die Erfüllung durch den heiligen Geist geschehen würde und was geschehen wird, wenn dieser wunderbare Geist gekommen ist, Seine Zeichen, Seine Arbeit in den Menschen durch IHN.
<G-vec00042-001-s194><come.kommen><en> The time has come for religious leaders to cooperate more effectively in the work of healing wounds, resolving conflicts and pursuing peace.
<G-vec00042-001-s194><come.kommen><de> Die Zeit ist gekommen, dass die Religionsführer wirksamer zusammenarbeiten, um die Wunden zu heilen, Konflikte zu lösen und Frieden zu suchen.
<G-vec00042-001-s195><come.kommen><en> Now therefore, behold, the cry of the children of Israel is come unto me: and I have also seen the oppression wherewith the Egyptians oppress them. Come now therefore, and I will send thee unto Pharaoh, that thou mayest bring forth my people the children of Israel out of Egypt.
<G-vec00042-001-s195><come.kommen><de> Weil nun das Geschrei der Kinder Israel vor mich gekommen ist, und ich auch dazu ihre Angst gesehen habe, wie die Aegypter sie aengsten, so gehe nun hin, ich will dich zu Pharao senden, dass du mein Volk, die Kinder Israel, aus Aegypten fuehrest.
<G-vec00042-001-s196><come.kommen><en> 43a I have come in my Father's name,...
<G-vec00042-001-s196><come.kommen><de> 43a Ich bin gekommen in meines Vaters Namen...
<G-vec00042-001-s197><come.kommen><en> "So, now it seems that we have come to the last layer when we hear: ""If there are indeed people who are being persecuted, I will feel sympathetic."""
<G-vec00042-001-s197><come.kommen><de> "Nun scheint es so, dass wir zu der letzten Schicht gekommen sind, wenn wir hören: ""Wenn es in der Tat Menschen gibt, die verfolgt werden, werde ich Mitgefühl empfinden""."
<G-vec00042-001-s198><come.kommen><en> Solitude is one of the blessings that have come to characterise this, the sunniest island in the Mediterranean.
<G-vec00042-001-s198><come.kommen><de> Einsamkeit ist eines des Segens, das gekommen ist, um die sonnigste Insel im Mittelmeer zu charakterisieren.
<G-vec00042-001-s199><come.kommen><en> """Space Opera has again come to a planet on which we live."
<G-vec00042-001-s199><come.kommen><de> """Die Weltraumoper ist wieder einmal zu einem Planeten gekommen, auf dem wir leben."
<G-vec00042-001-s200><come.kommen><en> I wish you carry these flags back to your own countries, and tell them the message that the time has come for our resurrection, that we have to rise.
<G-vec00042-001-s200><come.kommen><de> Es ist mein Wunsch, dass ihr diese Fahnen in eure Länder zurückbringt und ihnen die Botschaft vermittelt, dass wir wachsen müssen, denn die Zeit der Auferstehung ist gekommen.
<G-vec00042-001-s201><come.kommen><en> The response to this initiative has proved so positive, that we are going to prepare many more channelers in different countries, so that human beings who are still doubtful about this new reality, cannot have but the best evidence that we are here and we have come to help in the healing process of Gaia and the ascension of all the kingdoms that are present on her.
<G-vec00042-001-s201><come.kommen><de> Die Antwort auf diese Initiative hat sich so positiv erwiesen, dass wir noch viel mehr Channels in verschiedenen Laendern vorbereiten, damit Menschen, die immer noch diese neue Realitaet anzweifeln, nur den allerbesten Beweis dafuer haben, dass wir hier sind und dass wir gekommen sind, um beim Heilungsprozess von Gaia und dem Aufstieg all der Reiche, die auf ihr existieren, zu helfen.
<G-vec00042-001-s202><come.kommen><en> Thus you know that your life on earth is limited and that no-one can prevent his body's death when his hour has come....
<G-vec00042-001-s202><come.kommen><de> Also das eine wisset ihr, daß euer Sein auf Erden begrenzt ist und daß keiner sich wehren kann gegen den Leibestod, wenn seine Stunde gekommen ist....
<G-vec00042-001-s203><come.kommen><en> "For if those words of Christ and Peter are to be understood figuratively, they are not to be made to bear the meaning those people claim, but they are to be related to the meaning of that sword of which Matthew writes in this way: ""Think not that I am come to send peace on earth: I came not to send peace, but a sword."
<G-vec00042-001-s203><come.kommen><de> Will man jene Worte Christi und Petri sinnbildlich nehmen, so sind sie doch nicht auf Das, was meine Gegner sagen, zu beziehen, sondern auf die Bedeutung jenes Schwertes, von welchem Matthäus schreibt: Glaubet nicht, daß ich in die Welt gekommen bin, den Frieden zu bringen: nicht bin ich gekommen, den Frieden zu bringen, sondern das Schwert.
<G-vec00042-001-s204><come.kommen><en> "47:4 They also said to him, ""We have come to live here awhile, because the famine is severe in Canaan and your servants' flocks have no pasture."
<G-vec00042-001-s204><come.kommen><de> 47:4 Und sagten weiter zum Pharao: Wir sind gekommen, bei euch zu wohnen im Lande; denn deine Knechte haben nicht Weide für ihr Vieh, so hart drückt die Hungersnot das Land Kanaan.
<G-vec00042-001-s205><come.kommen><en> "Even before his title ""So wie du"" Anka had come into contact with the German language: The soundtrack to the movie of the same name contains the song ""Verboten""."
<G-vec00042-001-s205><come.kommen><de> "Schon vor seinem Titel ""So wie du"" war Anka mit der deutschen Sprache in Berührung gekommen: Aus dem Soundtrack zum gleichnamigen Kinofilm stammt der Song ""Verboten""."
<G-vec00042-001-s206><come.kommen><en> Now that we have a booted system, the time has come to start the actual installation.
<G-vec00042-001-s206><come.kommen><de> Jetzt nach dem Neustart des Systems ist die Zeit gekommen, die Installation zu starten.
<G-vec00042-001-s207><come.kommen><en> I knew this was the book I had come in to buy.
<G-vec00042-001-s207><come.kommen><de> Ich wußte, daß ich gekommen war, um dieses Buch zu kaufen.
<G-vec00042-001-s208><come.kommen><en> Sanguinetti had come to California in the early 1850’s during the gold rush.
<G-vec00042-001-s208><come.kommen><de> Sanguinetti war in den frühen 1850er Jahren während des Goldrausches nach Kalifornien gekommen..
<G-vec00042-001-s266><come.kommen><en> And, of course, the Japanese company's icon wasn't going to be left out and come along in the form of the above-mentioned Super Mario 64 that has eventually become a classic and has been copied time after time on PC but now with an online version to be able to play in multiplayer mode.
<G-vec00042-001-s266><come.kommen><de> Und natÃ1⁄4rlich wurde die Ikone des japanischen Unternehmens nicht ausgelassen und kam in Form des oben erwähnten Super Mario 64, der schließlich zu einem Klassiker geworden ist und zeitweise auf dem PC kopiert wurde, aber jetzt mit einem Online-Version, um im Multiplayer-Modus spielen zu können.
<G-vec00042-001-s267><come.kommen><en> "The Net, or rather the counter-Net, assumes the promise of an integral aspect of the TAZ, an addition that will multiply its potential, a ""quantum jump"" (odd how this expression has come to mean a big leap) in complexity and significance."
<G-vec00042-001-s267><come.kommen><de> Das Netz, oder vielmehr das Gegen-Netz, wird zu einem integralen Aspekt der TAZ, einer Bereicherung zur Entfaltung ihres Potentials, einem »Quantensprung« (seltsam, wie dieser Begriff zur Bedeutung großer Sprung kam) in Komplexität und Signifikanz.
<G-vec00042-001-s268><come.kommen><en> There was also a chapel here, but there was little morality in this place, and the population did not come to holy mass or confession, nor did they marry each other or let the children be baptized, so the priest who had been here at first, to avoid starvation, had been forced to leave the place.
<G-vec00042-001-s268><come.kommen><de> Es existierte hier auch eine Kapelle da aber an diesem Orte wenig Moral herrschte und die Bevölkerung weder zur Messe noch zur Beichte kam noch sich trauen oder die Kinder taufen ließ, so hatte sich der anfangs hier weilende Pater, um nicht zu verhungern, gezwungen gesehen, den Ort wieder zu verlassen.
<G-vec00042-001-s269><come.kommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec00042-001-s269><come.kommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec00042-001-s270><come.kommen><en> Just as the time has finally come when in individual States a system of private vendetta and reprisal has given way to the rule of law, so too a similar step forward is now urgently needed in the international community.
<G-vec00042-001-s270><come.kommen><de> Wie in den einzelnen Staaten endlich der Zeitpunkt kam, wo an die Stelle des Systems der persönlichen Rache und Vergeltung die Herrschaft des Gesetzes trat, so ist es jetzt dringend notwendig, daß in der internationalen Völkergemeinschaft ein ähnlicher Fortschritt stattfindet.
<G-vec00042-001-s271><come.kommen><en> in mind, convinced by that time that I had come here, into this material world, with a number of cards in my hand, and that I had the duty to do something with them.In the years that followed, I started playing music again, I started writing, and I became a visual artist.
<G-vec00042-001-s271><come.kommen><de> "Nach meiner Erfahrung, behielt ich immer diesen Satz im Kopf, ""Was hast du mit deinen Talenten gemacht?, inzwischen überzeugt dass ich hierher in diese materielle Welt kam mit einer Anzahl von Karten in der Hand, und dass ich die Pflicht hatte etwas damit anzufangen."
<G-vec00042-001-s272><come.kommen><en> and when she was come to King Solomon, she told him all that was in her heart.
<G-vec00042-001-s272><come.kommen><de> Und als sie zu Salomo kam, sagte sie ihm alles, was sie auf dem Herzen hatte.
<G-vec00042-001-s273><come.kommen><en> Sport should evolve and computer sports based on computer gaming becoming commonplace should not come as a surprise.
<G-vec00042-001-s273><come.kommen><de> Der Sport sollte sich weiterentwickeln, und es kam nicht überraschend, dass Computer Sport basierend auf Computerspielen zur Normalität wurde.
<G-vec00042-001-s274><come.kommen><en> If a girl readily agrees to the meeting, and leaves them happy and inspired, so, the time has come of the proposal.
<G-vec00042-001-s274><come.kommen><de> Wenn ein Mädchen leicht erklärt und geht auf die treffen mit Ihnen glücklich und beflügelt, also, kam zum Zeitpunkt der Angebotserstellung.
<G-vec00042-001-s275><come.kommen><en> The demand of students, who had come to talk about their future, was first rejected.
<G-vec00042-001-s275><come.kommen><de> Der Dorfschützer Murat Ücgül kam dabei ums Leben, Yilmaz Kaya wurde schwer verletzt.
<G-vec00042-001-s276><come.kommen><en> Drummer Martin gave his glass to him, when he had to quickly come to solve a technical problem.
<G-vec00042-001-s276><come.kommen><de> Drummer Martin drückte ihm seins in die Hände, als er kurz ein technisches Problem lösen kam.
<G-vec00042-001-s277><come.kommen><en> There did come a Man on the earth greater than Moses, and His greatness was superior greatness even to that of Moses.
<G-vec00042-001-s277><come.kommen><de> Da kam ein Mann auf diese Erde, der größer war als Mose, und seine Größe übertraf selbst diejenige von Moses.
<G-vec00042-001-s278><come.kommen><en> When Uriah had come to him, David asked how Joab was doing, and how the people were doing, and how the war prospered.
<G-vec00042-001-s278><come.kommen><de> Und Uria kam zu ihm, und David fragte nach dem Wohlergehen Joabs und nach dem Wohlergehen des Volkes und nach der Kriegslage.
<G-vec00042-001-s279><come.kommen><en> I had come to terms with the fact that once I, my ego consciousness, left the body, my mind-created world also disappeared.
<G-vec00042-001-s279><come.kommen><de> "Ich kam zu den Bedingungen mit der Tatsache, daß einmal – ich, mein ""EGO-Bewußtsein"" meinen Körper verläßt, meine Geist-erschaffene Welt aber genauso verschwinden wird....."
<G-vec00042-001-s280><come.kommen><en> And when the hour was come, he placed himself at table, and the [twelve] apostles with him.
<G-vec00042-001-s280><come.kommen><de> Und da die Stunde kam, setzte er sich nieder und die zwölf Apostel mit ihm.
<G-vec00042-001-s281><come.kommen><en> 23 And it happened when Joseph had come to his brothers, they stripped Joseph out of his tunic, the tunic reaching to the soles of his feet that was on him. 24 And they took him and threw him into a pit. And the pit was empty, with no water in it.
<G-vec00042-001-s281><come.kommen><de> 23 Und es geschah, als Joseph zu seinen Brüdern kam, da zogen sie Joseph seinen Leibrock aus, den langen Leibrock, den er anhatte; 24 und sie nahmen ihn und warfen ihn in die Grube; die Grube aber war leer, es war kein Wasser darin.
<G-vec00042-001-s282><come.kommen><en> I had the good fortune of having my success come very late and you've stabilised a bit by then.
<G-vec00042-001-s282><come.kommen><de> Ich hatte ja das Glück, dass mein Erfolg sehr spät kam und da ist man dann schon ein bisschen gefestigt.
<G-vec00042-001-s283><come.kommen><en> And when he was come into the house from the multitude, his disciples asked him the parable.
<G-vec00042-001-s283><come.kommen><de> Und da er von dem Volk ins Haus kam, fragten ihn seine Jünger um dies Gleichnis.
<G-vec00042-001-s284><come.kommen><en> The invite had come from Algis Kizys, the former bassist of the Swans and Vincent Signorelli, Unsane's drummer.
<G-vec00042-001-s284><come.kommen><de> Die Einladung kam von Algis Kizys, dem ehemaligen Bassisten der Swans und Vincent Signorelli, Unsane's Schlagzeuger.
<G-vec00042-001-s285><come.kommen><en> Many pharisees come from poor sectors of the population.
<G-vec00042-001-s285><come.kommen><de> Viele Pharisäer kamen aus den armen Schichten der Bevölkerung.
<G-vec00042-001-s286><come.kommen><en> Speakers and researchers from all over the world come here to present their findings.
<G-vec00042-001-s286><come.kommen><de> Sprecher und Forscher aus der ganzen Welt kamen her um ihre Forschungsergebnisse zu präsentieren.
<G-vec00042-001-s287><come.kommen><en> Only small rests have kept from the trees, which were cemented so that they did not come apart and so that they are preserved for future generations.
<G-vec00042-001-s287><come.kommen><de> Nur kleine Reste haben von den Bäumen gehalten, die zementiert waren, damit sie nicht auseinander kamen und damit sie für zukünftige Erzeugungen konserviert werden.
<G-vec00042-001-s288><come.kommen><en> As always we are grateful to all the birds who have come to eat and all bird watchers who engaged themselves in the doings of the birds.
<G-vec00042-001-s288><come.kommen><de> Wie immer sind wir allen Vögeln die zum Fressen kamen dankbar und allen Vogelbeobachtern die sich mit dem Verhalten der Vögel beschäftigt haben.
<G-vec00042-001-s289><come.kommen><en> We come to the city with our team of three people as guests of Şanlıurfa Governorate and learn that 2011 excavation works have been cancelled.
<G-vec00042-001-s289><come.kommen><de> Wir kamen als Gäste des Gouverneurs im Team von drei Personen und mussten erfahren, das die Ausgrabungen für 2011 gestrichen worden waren.
<G-vec00042-001-s290><come.kommen><en> 5 The isles have seen, and fear; the ends of the earth tremble; they draw near, and come.
<G-vec00042-001-s290><come.kommen><de> 5 Da das die Inseln sahen, fürchteten sie sich, und die Enden der Erde erschraken; sie naheten und kamen herzu.
<G-vec00042-001-s291><come.kommen><en> From the early centuries of Christianity the real reason that urged pilgrims to come to Rome was the desire to pray at the tombs of the apostles.
<G-vec00042-001-s291><come.kommen><de> Seit der ersten Jahrhunderte des Christentums waren die Pilger, die nach Rom kamen, von dem Wunsch getrieben, an den Gräbern der Apostel zu beten.
<G-vec00042-001-s292><come.kommen><en> After a visit to the first cigar trade JJ Fox Cigar Merachant, where we're happy they made the annual cigars, Hoyo de Monterrey, We will come to the end of the street 9 St. James or. its crossing with Pall Mall, where was dounítkový shop devoted to the brand Alfred Dunhill.
<G-vec00042-001-s292><come.kommen><de> Nach dem Besuch der ersten Zigarren-Shop JJ-Fox Zigarre Merachant, Wo bekommen wir das Vergnügen gemacht Hoyo de Monterrey Zigarren jährliche, Wir kamen bis zum Ende der Straße 9 St. James bzw.. die Kreuzung mit der Pall Mall, Wo war der Dounítkový-Shop der Marke Alfred Dunhill gewidmet.
<G-vec00042-001-s293><come.kommen><en> Near Sabunike is situated a famous Nin Lagoon which is explored by lots of people who come to convince in recovering characteristics of the mud.
<G-vec00042-001-s293><come.kommen><de> Nahe Sabunike liegt die berühmte Nin Lagoon, die von vielen Menschen besucht wird, die kamen, um sich von der heilenden Wirkung des Schlamms zu überzeugen.
<G-vec00042-001-s294><come.kommen><en> They had come from thousands of miles away.
<G-vec00042-001-s294><come.kommen><de> Sie kamen von Tausenden von Meilen entfernt.
<G-vec00042-001-s295><come.kommen><en> """ 38:27 All the officials did come to Jeremiah and question him, and he told them everything the king had ordered him to say."
<G-vec00042-001-s295><come.kommen><de> 38:27 Da kamen alle Oberen zu Jeremia und fragten ihn, und er antwortete ihnen, wie ihm der König befohlen hatte.
<G-vec00042-001-s296><come.kommen><en> The few could see it as the officer ordered that in large quantities did not come.
<G-vec00042-001-s296><come.kommen><de> Wenige konnten es sehen, da der Offizier befohlen hat, dass in großen Mengen nicht kamen.
<G-vec00042-001-s297><come.kommen><en> We used to come here with our goats, there would be fish in the sea and dates on the trees for the Bedouins.
<G-vec00042-001-s297><come.kommen><de> Wir kamen mit unseren Ziegen her, für die Beduinen waren immer Fische im Meer und Datteln an den Bäumen.
<G-vec00042-001-s298><come.kommen><en> 20 They are ashamed because they were confident; they come there and are disappointed.
<G-vec00042-001-s298><come.kommen><de> 20 Sie wurden beschämt, weil sie auf sie vertraut hatten, sie kamen hin und wurden zuschanden.
<G-vec00042-001-s299><come.kommen><en> 21:17 And when we had come to Jerusalem, the brethren received us gladly.
<G-vec00042-001-s299><come.kommen><de> 21:17 Da wir nun gen Jerusalem kamen, nahmen uns die Brüder gerne auf.
<G-vec00042-001-s300><come.kommen><en> No wonder, since all of its principal conductors have come from the Old World.
<G-vec00042-001-s300><come.kommen><de> Wen wundert’s, kamen doch sämtliche Chefdirigenten aus der Alten Welt.
<G-vec00042-001-s301><come.kommen><en> The first Greeks to come into contact with the Iranians were the Ionians, who lived on the coast of Asia Minor and were constantly threatened by the Persians, the most important of the Iranian peoples.
<G-vec00042-001-s301><come.kommen><de> Die ersten Griechen, die mit den Iranern in Kontakt kamen, waren die Ionier, die an der Küste Kleinasiens lebten und ständig von den Persern, einem der bedeutendsten Völker der Iraner, bedroht wurden.
<G-vec00042-001-s302><come.kommen><en> The soldiers had got wet through on the way and were tired; they had come from Krasnoe Selo.
<G-vec00042-001-s302><come.kommen><de> Die Soldaten waren unterwegs durchnäßt worden und müde: sie kamen aus Krassnoje Selo.
<G-vec00042-001-s303><come.kommen><en> It is important to mention that the participants come from sectors where multinational companies are present and they have some experience in the area of CSR.
<G-vec00042-001-s303><come.kommen><de> Alle Teilnehmer des Seminars kamen aus Branchen, in denen multinationale Unternehmen tätig sind, und brachten eigene Erfahrungen im Umgang mit CSR mit.
<G-vec00042-001-s323><come.kommen><en> What's the best gift for people in winter.the answer must be Moncler Men Jacket Design Multi Pockets With Cap Black.They come with luxurious styles and in line with fashion.various styles and colors to choose from.People dont like the winter for the cold,even there are a lot of interesting things in the season,but if you with the Moncler Mens Jackets in hands,everything will be different,you will have different impression about winter,come on,come to our wesbite and get your own style.
<G-vec00042-001-s323><come.kommen><de> Was ist das beste Geschenk für die Menschen in winter.The Antwort muss seinMoncler Herren Jacke Design Multi Taschen mit Cap Black.Sie Mit luxuriösen Designs und im Einklang mit fashion.various Stilen und Farben kommen, um zu wählen from.People nicht wie der Winter für die kalte, auch gibt es eine Menge interessanter Dinge in der Saison, aber wenn man mit derMoncler Herren Jackenin den Händen, wird alles anders sein, Sie werden anderen Eindruck über den Winter haben, komm schon, komm zu unserem wesbite und erhalten Sie Ihren eigenen Stil .
<G-vec00042-001-s325><come.kommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00042-001-s325><come.kommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00042-001-s326><come.kommen><en> “Come on, it’s only a game.
<G-vec00042-001-s326><come.kommen><de> “Komm schon, ist doch bloß ‘n Spiel.
<G-vec00042-001-s327><come.kommen><en> Come on, we stuff wax in our ears and close our eyes, than, nothing will happen to us.
<G-vec00042-001-s327><come.kommen><de> Komm wir stopfen uns Wachs in die Ohren und schließen die Augen, dann kann uns bestimmt nichts passiern - dann reißt die Wolkendecke.
<G-vec00042-001-s328><come.kommen><en> 28 Say not to your neighbour, Go, and come again, and tomorrow I will give; when you have it by you at the time.
<G-vec00042-001-s328><come.kommen><de> 28 Sprich nicht zu deinem Nächsten: “Geh hin und komm wieder; morgen will ich dir geben”, so du es wohl hast.
<G-vec00042-001-s329><come.kommen><en> Come with me and go back to your home.
<G-vec00042-001-s329><come.kommen><de> Komm mit mir und geh zurück zu deinem Haus.
<G-vec00042-001-s330><come.kommen><en> Do you want to know more, come to me if you're curious and want more experience.
<G-vec00042-001-s330><come.kommen><de> Wollen Sie mehr wissen, komm zu mir, wenn Sie sind neugierig und wollen mehr erleben wollen.
<G-vec00042-001-s331><come.kommen><en> Description Come with this trendy original vintage DJ PLAYER baggy jeans of the brand OLD SCHOOL really big out.
<G-vec00042-001-s331><come.kommen><de> Beschreibung Komm mit dieser modischen Original Vintage DJ PLAYER Baggy Jeans der Marke OLD SCHOOL ganz groß raus.
<G-vec00042-001-s332><come.kommen><en> Come Holy Spirit, and make ever more fruitful the charisms you have bestowed on us.
<G-vec00042-001-s332><come.kommen><de> Komm, Heiliger Geist und mache die Charismen, die du uns anvertraut hast, immer fruchtbarer.
<G-vec00042-001-s333><come.kommen><en> Come and chill if you'd like.
<G-vec00042-001-s333><come.kommen><de> Komm und entspann dich, wenn du willst.
<G-vec00042-001-s334><come.kommen><en> 7:11 Come, my beloved, let us go forth into the field. Let us lodge in the villages.
<G-vec00042-001-s334><come.kommen><de> 7:11 Komm, mein Geliebter, laß uns aufs Feld hinausgehen, in den Dörfern übernachten.
<G-vec00042-001-s335><come.kommen><en> To those for whom the griefs of yesterday or the fear of tomorrow is just too much, come Lord Jesus.
<G-vec00042-001-s335><come.kommen><de> Für diejenigen, für die die Leiden von gestern oder die Angst vor der Zukunft ist einfach zu viel, Komm, Herr Jesus.
<G-vec00042-001-s336><come.kommen><en> There, Felgen met the Beatles, who recorded their two German titles She Loves You and Come, Give Me Your Hand.
<G-vec00042-001-s336><come.kommen><de> Dort traf sich Felgen mit den Beatles, die ihre beiden deutschsprachigen Titel Sie liebt dich und Komm, gib mir deine Hand aufnahmen.
<G-vec00042-001-s337><come.kommen><en> Submissive or dominant, come to me - I`m yours, kisses, Kessi.
<G-vec00042-001-s337><come.kommen><de> Devot oder dominant, komm zu mir, ich bin Dein, Bussi Kessi.
<G-vec00042-001-s338><come.kommen><en> That’s why Jesus does not say to Matthew when he converts – you will see it in the Gospel: “Well, this is good, I congratulate you, come with me”. No, he says to him: “Let us celebrate in your home”, and he invites all his friends, who with Matthew had been condemned by the society, to celebrate.
<G-vec00042-001-s338><come.kommen><de> Bei der Bekehrung des Matthäus – ihr findet das im Evangelium – sagt Jesus deswegen zu ihm nicht: „Gut, einverstanden, Kompliment, komm mit.“ Nein, er sagt zu ihm: „Lass uns zu dir nach Hause gehen und feiern“, und er lädt zu diesem Fest alle Freunde des Matthäus ein, die wie er von der Gesellschaft verurteilt wurden.
<G-vec00042-001-s339><come.kommen><en> "This happened and ORO, the hunter said: ""Come back to my flesh."""
<G-vec00042-001-s339><come.kommen><de> "Dies geschah so und ORO, der Jäger, sagte: ""komm zurück zu meinem Fleisch""."
<G-vec00042-001-s340><come.kommen><en> “While I understand what she wants and has the jokes, has this repetition, but her then I say 'Come on little taught the word.
<G-vec00042-001-s340><come.kommen><de> “Ich verstehe zwar, was sie will und hat die Witze, hat diese Wiederholung, aber sie dann sage ich ‚wenig Komm das Wort gelehrt.
<G-vec00042-001-s341><come.kommen><en> Is quite difficultly to there to come.
<G-vec00042-001-s341><come.kommen><de> Is schon schwierig bis da hin zu komm'n.
<G-vec00042-001-s342><come.kommen><en> “John came preaching repentance to prepare you for the kingdom; now have I come proclaiming faith, the gift of God, as the price of entrance into the kingdom of heaven.
<G-vec00042-001-s342><come.kommen><de> Johannes kam und predigte Buße, um euch auf das Königreich vorzubereiten; jetzt komme ich und verkündige den Glauben, dieses Gottesgeschenk, als Preis für den Eintritt ins Königreich des Himmels.
<G-vec00042-001-s343><come.kommen><en> Come close to love, for love is the heart of you.
<G-vec00042-001-s343><come.kommen><de> Komme näher, um zu lieben, denn Liebe ist das Herz von dir.
<G-vec00042-001-s344><come.kommen><en> """I was about to go to university, when my father said to me: Look, Giorgio, I need you, come join the company."
<G-vec00042-001-s344><come.kommen><de> """Ich sollte zur Universität gehen, doch mein Vater sagte zu mir: hör mal, Giorgio, ich brauche dich, komme in die Firma."
<G-vec00042-001-s345><come.kommen><en> In spite of all the alienation, he understood: This is where I come from, these are my people.
<G-vec00042-001-s345><come.kommen><de> Bei allem Befremden hat er verstanden: Hier komme ich her, das sind meine Leute.
<G-vec00042-001-s346><come.kommen><en> "14 Jesus answered, ""Even if I bear witness of myself, my testimony is true, for I know where I came from and where I am going; but you do not know where I come from and where I am going."
<G-vec00042-001-s346><come.kommen><de> 14 Jesus antwortete und sprach zu ihnen: Auch wenn ich von mir selbst zeuge, ist mein Zeugnis wahr, weil ich weiß, woher ich gekommen bin und wohin ich gehe; ihr aber wißt nicht, woher ich komme und wohin ich gehe.
<G-vec00042-001-s347><come.kommen><en> No, I come only out of love for My children, whom I wish to see filled with light and peace.
<G-vec00042-001-s347><come.kommen><de> Nein, Ich komme nur aus Liebe zu meinen Kindern, die ich voll Licht und Frieden sehen möchte.
<G-vec00042-001-s348><come.kommen><en> However, I come just by time, when As I Lay Dying, start their set and I'm trying desperately to catch the vibe with my camera
<G-vec00042-001-s348><come.kommen><de> Wie auch immer, ich komme gerade rechtzeitig zum Anpfiff von As I Lay Dying, und versuche mit schierer Verzweiflung deren Vibe per Bild einzufangen.
<G-vec00042-001-s349><come.kommen><en> Berlin as a business location come forward only, when good connections there existed, where economically at the time “the liven”.
<G-vec00042-001-s349><come.kommen><de> Berlin komme als Wirtschaftsstandort nur dann voran, wenn gute Verkehrsverbindungen dorthin existierten, wo zur Zeit wirtschaftlich „die Post abgeht“.
<G-vec00042-001-s350><come.kommen><en> "Hubert brought out the laughs again as he talked between songs: ""I come from the Salzkammergut... we are Austria."
<G-vec00042-001-s350><come.kommen><de> "Hubert brachte wieder die Lacher auf seine Seite als er zwischen den Titel'n erklärte: ""Ich komme aus dem Salzkammergut... wir sind Österreich."
<G-vec00042-001-s351><come.kommen><en> My name is Cécile and I come from Biberach in Germany.
<G-vec00042-001-s351><come.kommen><de> Ich heiße Cécile und komme aus Biberach in Deutschland.
<G-vec00042-001-s352><come.kommen><en> Ball Chain - Come to find ball chain retail you like.
<G-vec00042-001-s352><come.kommen><de> - Komme zu Kugel Kette Einzelhandel zu finden, die Sie mögen.
<G-vec00042-001-s353><come.kommen><en> This is evident from the next two verses, Nehemiah 2:7,8: “Moreover, I said unto the king, If it please the king, let letters be given me to the governors beyond the river, that they may convey me over, till I come to Judah; and a letter to Asaph, the keeper of the king’s forest, that he may give me timber to make beams for the gates of the palace which appertained to the house, and for the wall of the city, and for the house that I shall enter into.
<G-vec00042-001-s353><come.kommen><de> Dies ist auch aus den nächsten beiden Versen ersichtlich: „Und ich sprach zum dem König: wenn es den König gut dünkt, so gebe man mir Briefe an die Landpfleger jenseits des Stromes, daß sie mich durchziehen lassen, bis ich nach Juda komme; und einen Brief an Asaph, den Hüter, des königlichen Forstes, daß er mir Holz gebe, um die Tore der Burg zu bälken, welche zum Hause gehört, und für die Mauer der Stadt, und für das Haus, in welches ich ziehen werde.
<G-vec00042-001-s354><come.kommen><en> "In order for a world civilization to come about,... Christianity must be reconceived to conform with ""global"" values and shed its ""divisive"" attributes."
<G-vec00042-001-s354><come.kommen><de> "Damit eine Welt-Zivilisation zustande komme,... müsse das Christentum neu konzipiert werden, um ""globalen"" Werten zu entsprechen und seine ""spaltende"" Attribute abzuwerfen."
<G-vec00042-001-s355><come.kommen><en> Hello, I come Towards You as I heard about your site, and I would like to know more.
<G-vec00042-001-s355><come.kommen><de> Hallo, Ich komme zu Ihnen, wie ich über Ihre Website zu hören, und ich möchte mehr wissen.
<G-vec00042-001-s356><come.kommen><en> By now I come, or my Bridegroom, to admire Your glory, That since me riempie the soul of joy, Where the whole sky sinks in adoration in front of You.
<G-vec00042-001-s356><come.kommen><de> Ich komme nunmehr, oder mein Bräutigam, zu Deinen Ruhm bewundern Der von jetzt an ich riempie die Seele von Freude, Wo der ganze Himmel in Anbetung vor Du sinkt.
<G-vec00042-001-s357><come.kommen><en> "Come back next Monday with your husband."""
<G-vec00042-001-s357><come.kommen><de> Komme nächsten Montag zurück mit deinem Mann.
<G-vec00042-001-s358><come.kommen><en> I come to my first memory of her from, I think, Christmas 1930.
<G-vec00042-001-s358><come.kommen><de> Ich komme an meine erste Erinnerung an ihr aus, ich glaube, Weihnachten 1930.
<G-vec00042-001-s359><come.kommen><en> As this character, Kaufman would appear on the stage of comedy clubs, play a recording of the theme from the Mighty Mouse cartoon show while standing perfectly still, and lip-sync only the line “Here I come to save the day” with great enthusiasm .
<G-vec00042-001-s359><come.kommen><de> Als dieses Zeichen, Kaufman erscheint auf der Bühne des Comedy-clubs, Spielen Sie eine Aufnahme des Themas von der Mighty Mouse Cartoon Show stehen perfekt noch, und nur die Linie lippensynchron “Hier komme ich zu den Tag retten” mit großer Begeisterung.
<G-vec00042-001-s360><come.kommen><en> I am Assana and come from Cameroon.
<G-vec00042-001-s360><come.kommen><de> ich bin Assana und komme aus Kamerun.
<G-vec00042-001-s361><come.kommen><en> Many visitors come to the island every year to participate in the souma festival, held at a different distillery each year.
<G-vec00042-001-s361><come.kommen><de> Viele Besucher kommen jedes Jahr auf die Insel, um am Souma-Fest teilzunehmen, das jedes Jahr in einer anderen Destillerie stattfindet.
<G-vec00042-001-s362><come.kommen><en> There are literally hundreds of magnificent things to see and many visitors come back year after year.
<G-vec00042-001-s362><come.kommen><de> Die Zahl der zu bewundernden Dinge geht in die Hunderte, so dass viele Besucher Jahr für Jahr wieder kommen.
<G-vec00042-001-s363><come.kommen><en> Many surfers come and learn Spanish in Bocas del Toro because of its surf .
<G-vec00042-001-s363><come.kommen><de> Viele Surfer kommen und lernen Spanisch in Bocas del Toro wegen der Brandung.
<G-vec00042-001-s364><come.kommen><en> Sensitivity increases, especially in women, who not only use a lot of cosmetic products but also come into contact with scented household cleaners and detergents.
<G-vec00042-001-s364><come.kommen><de> Vor allem bei Frauen, die nicht nur viele Kosmetika benutzen, sondern auch im Haushalt mit parfümierten Reinigungs- und Waschmitteln in Berührung kommen, nimmt die Empfindlichkeit zu.
<G-vec00042-001-s365><come.kommen><en> Enlightenment can come only through a conscious relationship with cosmic energies.
<G-vec00042-001-s365><come.kommen><de> Erleuchtung kann nur durch eine bewußte Beziehung mit kosmischen Energien kommen.
<G-vec00042-001-s366><come.kommen><en> But ye shall receive power, after that the Holy Ghost is come upon you: and ye shall be witnesses unto me both in Jerusalem, and in all Judaea, and in Samaria, and unto the uttermost part of the earth.
<G-vec00042-001-s366><come.kommen><de> sondern ihr werdet die Kraft des Heiligen Geistes empfangen, welcher auf euch kommen wird, und werdet meine Zeugen sein zu Jerusalem und in ganz Judäa und Samarien und bis an das Ende der Erde.
<G-vec00042-001-s368><come.kommen><en> Choosing fine linens for your bed and bath can be initially costly, but as with any purchase of quality made items you will enjoy fine linen sheets and towels for years to come.
<G-vec00042-001-s368><come.kommen><de> Wählende feine Leinen für Ihr Bett und Bad können teuer zuerst sein, aber, wie mit jedem möglichem Erwerb der Qualität Einzelteile bildete, die Sie feine Leinenblätter und Tücher genießen, damit Jahre kommen.
<G-vec00042-001-s369><come.kommen><en> Just Come To Our Website And Place Your Order To Buy buy ultimate team coins Coins Then You Will Feel What An First-Class Service In The World .We Are An Experienced And Professional Team Of Cheap buy ultimate team coins Coins For Sale.
<G-vec00042-001-s369><come.kommen><de> Kommen Sie einfach auf unserer Website und Ihre Bestellung zu kaufen how to buy ultimate team coins Münzen dann werden Sie spüren, was ein First-Class-Dienst in der Welt Wir sind ein erfahrenes und professionelles Team von Billig how to buy ultimate team coins Münzen zum Verkauf.
<G-vec00042-001-s370><come.kommen><en> But do not walk past the source of life I opened up for you.... Listen when I speak to you and think about it.... keep coming back to hear My Word and soon you will no longer want to accept any other food and drink, you will constantly come to My table, you will accept My invitation for Supper and I will offer it to you with all the love a Host can grant to His guest, who will always come to Him in order to replenish themselves....
<G-vec00042-001-s370><come.kommen><de> Aber gehet nicht an dem Lebensquell vorüber, den Ich für euch erschlossen habe.... Höret, wenn Ich zu euch rede, denket darüber nach.... kommet immer wieder, um Meine Ansprache zu vernehmen, und ihr werdet bald keine andere Speise und keinen anderen Trank mehr entgegennehmen wollen, ihr werdet euch dann ständig einfinden an Meinem Tisch, ihr werdet Meiner Einladung folgen, zum Abendmahl zu kommen, und Ich werde es euch darreichen mit aller Liebe, die der Gastgeber Seinen Gästen schenken wird, die sich immer bei Ihm einfinden, um sich sättigen zu lassen....
<G-vec00042-001-s371><come.kommen><en> And maybe those who often come to this site to pray may begin to see certain aspects of their religion somewhat differently.
<G-vec00042-001-s371><come.kommen><de> Und womöglich beginnen diejenigen, die oft zum Gebet an diesen Ort kommen, gewisse Aspekte ihrer Religion etwas anders zu sehen.
<G-vec00042-001-s372><come.kommen><en> It will come through people; and if we blame the people and focus our attention on them, we have missed the point.
<G-vec00042-001-s372><come.kommen><de> Er wird durch Leute kommen; und wenn wir den Leuten die Schuld geben und unsere Aufmerksamkeit auf sie lenken, haben wir das Entscheidende verpasst.
<G-vec00042-001-s373><come.kommen><en> Generally speaking, the EU will be the most affected partner among all those targeted by the measures, as 73% of imports that are banned come from the EU.
<G-vec00042-001-s373><come.kommen><de> Da 73 % der nun verbotenen Einfuhren aus der EU kommen, lässt sich sagen, dass sie von den russischen Maßnahmen am stärksten betroffen sein wird.
<G-vec00042-001-s374><come.kommen><en> She needs a friend like you to come along and help her decide how to do her nails.
<G-vec00042-001-s374><come.kommen><de> Sie braucht einen Freund, wie Sie zu kommen und Hilf ihr entscheiden, wie ihre Nägel zu tun.
<G-vec00042-001-s375><come.kommen><en> I have covered in great detail these facts in at least ten other books and new facts in support of my theories come in every month if not more often.
<G-vec00042-001-s375><come.kommen><de> Ich habe ausführlich großes diese Tatsachen in mindestens 10 anderen Büchern umfaßt und neue Tatsachen zur Unterstützung meiner Theorien kommen in jeden Monat wenn nicht häufig.
<G-vec00042-001-s376><come.kommen><en> And Moses said,: «« Hovtwa accuracy, de militiamen and armed terrorist Daash, ahi Arab safety and which come and saw her..
<G-vec00042-001-s376><come.kommen><de> Und Mose sprach:: «« Hovtwa Richtigkeit, de Milizen und bewaffneten terroristischen Daash, ahi arabischen Sicherheit und die kommen und sah sie..
<G-vec00042-001-s377><come.kommen><en> The other side of the vise tells you that you can't come to Him on your own.
<G-vec00042-001-s377><come.kommen><de> Die andere Seite des Schraubstocks sagt dir, du kannst nicht aus eigener Kraft zu ihm kommen.
<G-vec00042-001-s378><come.kommen><en> Klara is just hot! We were more than please when she agreed to come to our atelier.
<G-vec00042-001-s378><come.kommen><de> Wir waren mehr als zufrieden, als sie zustimmte, in unser Atelier zu kommen.
<G-vec00042-001-s379><come.kommen><en> It is possible to come to be your personal supervisor, and work when you wish.
<G-vec00042-001-s379><come.kommen><de> So kommen Sie zu uns und überzeugen Sie sich von der Qualität unserer Druckererzeugnisse.
<G-vec00042-001-s399><come.kommen><en> "And he said, ""Jesus, remember me when you come into your kingdom."""
<G-vec00042-001-s399><come.kommen><de> Dann sagte er: Jesus, denk an mich, wenn du in dein Reich kommst.
<G-vec00042-001-s400><come.kommen><en> A very special energy will arise within you as soon as you come into contact with the sexy fabric of Modus Vivendi's Wolf Brief.
<G-vec00042-001-s400><come.kommen><de> Sobald du mit dem sexy Stoff des Wolf Brief von Modus Vivendi in Berührung kommst, wird eine ganz spezielle Energie in dir aufsteigen.
<G-vec00042-001-s401><come.kommen><en> SS: If you come here from Berlin or Beirut, you first lose your frame of reference, your work is suddenly just your work without a particular network, without particular codes and references.
<G-vec00042-001-s401><come.kommen><de> SS: Wenn du aus Berlin oder Beirut hierher kommst, verlierst du erstmal dein Referenzsystem, deine Arbeit ist plötzlich nur noch deine Arbeit, ohne ein bestimmtes Netzwerk, ohne bestimmte Codes und Referenzen.
<G-vec00042-001-s402><come.kommen><en> That’s where you come in.
<G-vec00042-001-s402><come.kommen><de> Hier kommst du ins Spiel.
<G-vec00042-001-s403><come.kommen><en> They will beg Jesus Christ Mr. and his Saint Spirit to illuminate them saying,: «Mr., that I see», or: «What I know myself», or still: «You come, Spirit Saint», and they will say every day the litanies of the Spirit Saint and the prayer that it follows, you bring in the first part of this book.
<G-vec00042-001-s403><come.kommen><de> Jesus Christus Herr und sein Sankt werden Geist bitten, ihnen sagend, zu beleuchten: «Herr das ich sehe», oder: «, Daß ich ich derselbe kenne», oder noch: «Du kommst, Geist Sankt», und sie werden alle Tage die Litaneien des Geistes Sankt und die Rede sagen, die folgt, ihr bringt wieder zum ersten Teil von diesem Buch.
<G-vec00042-001-s404><come.kommen><en> Yes That once you loose what you love your awareness is heightened of that love and you come back with a stronger love.
<G-vec00042-001-s404><come.kommen><de> Ja Dass wenn man einmal das verliert was man liebt, deine Bewusstheit von jener Liebe erhöht ist, und du kommst mit einer stärkeren Liebe zurück.
<G-vec00042-001-s405><come.kommen><en> And he went again into the Praetorium and said to Jesus, Where do you come from? But Jesus gave him no answer.
<G-vec00042-001-s405><come.kommen><de> Er ging wieder in den Palast zurück und fragte Jesus: »Woher kommst du?« Doch Jesus antwortete nichts.
<G-vec00042-001-s406><come.kommen><en> The closer you come to Dusty the less you will fear her and the more warmth you feel.
<G-vec00042-001-s406><come.kommen><de> Je näher du Dusty kommst, desto weniger fürchtest du sie, und desto mehr Wärme fühlst du.
<G-vec00042-001-s407><come.kommen><en> And if you come home angry, they feel it, and their mood may be dampened.
<G-vec00042-001-s407><come.kommen><de> Und wenn du ärgerlich nachhause kommst, so spüren sie das, und ihre Stimmung wird gedämpft.
<G-vec00042-001-s408><come.kommen><en> Or if you come here I shall speak to you about it.
<G-vec00042-001-s408><come.kommen><de> Oder, wenn Du hierher kommst, kann ich mit Dir darüber sprechen.
<G-vec00042-001-s409><come.kommen><en> After playing with the data for a while, you’ll probably come up with some mobile optimization ideas.
<G-vec00042-001-s409><come.kommen><de> Wenn Du ein bisschen mit den Einstellungen herumgespielt hast, kommst Du bestimmt auf ein paar nützliche Ideen zur Optimierung Deiner Seite.
<G-vec00042-001-s410><come.kommen><en> Alnwick in Northumberland is one of those places where you feel like you've REALLY come away from the hustle and bustle of everyday life.
<G-vec00042-001-s410><come.kommen><de> Alnwick in Northumberland ist einer dieser Orte, an dem es sich anfühlt, als kommst du wirklich weg vom hektischen Treiben des täglichen Lebens.
<G-vec00042-001-s411><come.kommen><en> Many people suffer from allergic dermatitis and not know, If you come into con...
<G-vec00042-001-s411><come.kommen><de> Viele Menschen leiden unter allergischen Dermatitis und nicht wissen, kommst du in Kontakt...
<G-vec00042-001-s412><come.kommen><en> When Abu Bakr saw him, he asked: “Do you come as an emir or with a special commission?” Ali answered: “With a special commission.” They then continued on together.
<G-vec00042-001-s412><come.kommen><de> Als Abu Bakr ihn sah, fragte er: “Kommst du als Emir oder mit einem besonderen Auftrag?” Ali antwortete: “Mit einem besonderen Auftrag.” Sie zogen dann zusammen weiter.
<G-vec00042-001-s413><come.kommen><en> Well the left of the two balls you come first, if the whole structure is already half down.
<G-vec00042-001-s413><come.kommen><de> Na die linke von den beiden Kugeln kommst Du erst, wenn das ganze Gerüst schon halb unten ist .
<G-vec00042-001-s414><come.kommen><en> Instead of standing outside, like the older son, you come into fellowship with God, like the prodigal son who was converted.
<G-vec00042-001-s414><come.kommen><de> Anstatt außen zu stehen, wie der ältere Sohn, kommst du in die Gemeinschaft mit Gott, wie der verlorene Sohn, der bekehrt wurde.
<G-vec00042-001-s415><come.kommen><en> you come back from the dead.
<G-vec00042-001-s415><come.kommen><de> du von den Toten zurück kommst.
<G-vec00042-001-s416><come.kommen><en> Other places to see: If you come from the west, there's a use to stop in Transylvania.
<G-vec00042-001-s416><come.kommen><de> Andere sehenswerte Orte: Wenn du vom Westen kommst, lohnt es sich auf jeden Fall in Transsylvanien anzuhalten.
<G-vec00042-001-s417><come.kommen><en> 5 “After that you will come to the hill of God, where the garrison of the Philistines is; and it will happen, when you have come there to the city, that you will meet a band of prophets coming down from the high place with a lute, a tambourine, a pipe, and a harp before them; and they will be prophesying.
<G-vec00042-001-s417><come.kommen><de> 5 Danach wirst du kommen auf den Hügel GOttes, da der Philister Lager ist; und wenn du daselbst in die Stadt kommst, wird dir begegnen ein Haufe Propheten von der Höhe herabkommend und vor ihnen her ein Psalter und Pauken und Pfeifen und Harfen, und sie weissagend.
<G-vec00042-001-s418><come.kommen><en> Should you wish them above all else, and be willing to make use of our experience, we are sure they will come.
<G-vec00042-001-s418><come.kommen><de> Wenn dieser Wunsch für dich an erster Stelle steht, und wenn du dir unsere Erfahrung zu eigen machen willst, sind wir sicher, daß es so kommt.
<G-vec00042-001-s419><come.kommen><en> And after I had come back to earth after the realisation, I knew: This is an influence of Mars, that one of Jupiter, that of the Sun, Moon.
<G-vec00042-001-s419><come.kommen><de> Und als ich auf die Erde nach der Realisation zurückkam, wusste ich: Dies ist der Einfluss vom Mars, das kommt vom Jupiter, das von der Sonne und das vom Mond.
<G-vec00042-001-s420><come.kommen><en> The blue pad is meant for dishes used for milk, the red for utensils for meat, and the green for dishes that come into contact with food containing neither meat nor milk.
<G-vec00042-001-s420><come.kommen><de> Der grüne Schrubber ist für Geschirr bestimmt, das mit Lebensmitteln in Berührung kommt, die weder Fleisch noch Milch enthalten.
<G-vec00042-001-s421><come.kommen><en> I do not know how to do it and how do I come to you.
<G-vec00042-001-s421><come.kommen><de> Ich sah es schon er seit langem nicht kommt sehr selten an.
<G-vec00042-001-s422><come.kommen><en> "Of course, this development does not come ""out of nowhere"", but has social causes."
<G-vec00042-001-s422><come.kommen><de> "Natürlich kommt diese Entwicklung nicht ""aus dem Nichts"", sondern hat gesellschaftliche Ursachen."
<G-vec00042-001-s423><come.kommen><en> "This is the ""I"" that will eventually lead you to practice meditation, for you see the long-term benefits that come from training your powers of mindfulness, concentration, and discernment."
<G-vec00042-001-s423><come.kommen><de> "Dieses ist das ""Ich"", welches Sie letztlich zur Meditation führt, denn Sie sehen einen langfristigen Nutzen, der aus dem Üben Ihrer Kraft an Achtsamkeit, Konzentration und Einsicht kommt."
<G-vec00042-001-s424><come.kommen><en> Irresistible grace argues that when God calls a person to salvation, that person will inevitably come to salvation.
<G-vec00042-001-s424><come.kommen><de> Unwiderstehliche Gnade argumentiert, das, wenn Gott eine Person zur Erloesung beruft, das diese Person dann auch unweigerlich zur Erloesung kommt.
<G-vec00042-001-s425><come.kommen><en> But when he discovered that it didn't originally come from Switzerland, he took it on.
<G-vec00042-001-s425><come.kommen><de> Aber als er erfahren hat, dass es ursprünglich gar nicht aus der Schweiz kommt, hat er sich seiner angenommen.
<G-vec00042-001-s426><come.kommen><en> Later in the evening, a mosquito will come for a visit and enjoy my blood.
<G-vec00042-001-s426><come.kommen><de> Abends kommt dann eine Mücke zu Besuch und labt sich an meinem Blut.
<G-vec00042-001-s427><come.kommen><en> They must prophesy again that the purpose of our Lord for this world in the end times is for everyone to come into God's blessings by believing in the gospel of the water and the Spirit.
<G-vec00042-001-s427><come.kommen><de> Sie müssen wieder prophezeien, dass der Zweck unseres Herrn für diese Welt in der Endzeit ist, dass jeder zum Segen Gottes durch den Glauben an das Evangelium von Wasser und Geist kommt.
<G-vec00042-001-s428><come.kommen><en> While news about constantly increasing numbers of Toyotas and cars of other manufacturers recalled into shops come thick and fast and all kinds of technical reasons are discussed publicly, the pivotal question, what is going awry with the economy overall, is missing out.
<G-vec00042-001-s428><come.kommen><de> Während sich die Meldungen über die ständig steigende Anzahl der in die Werkstätten zurückgerufenen Autos von Toyota und anderen Autoherstellern in den Medien überschlagen und alle möglichen technischen Ursachen öffentlich diskutiert werden, kommt die zentrale Frage, was denn in der Wirtschaft insgesamt schief läuft, viel zu kurz.
<G-vec00042-001-s429><come.kommen><en> If any man come to me, and hate not his father, and mother, and wife, and children, and brethren, and sisters, yea, and his own life also, he cannot be my disciple.
<G-vec00042-001-s429><come.kommen><de> So jemand zu mir kommt und haßt nicht seinen Vater, Mutter, Weib, Kinder, Brüder, Schwestern, auch dazu sein eigen Leben, der kann nicht mein Jünger sein.
<G-vec00042-001-s430><come.kommen><en> “Grace to you and peace from him who is and who was and who is to come, and from the seven spirits who are before his throne, and from Jesus Christ the faithful witness, the first-born of the dead, and the ruler of kings on earth” (Rev 1:4-5).
<G-vec00042-001-s430><come.kommen><de> »Gnade sei mit euch und Friede von Ihm, der ist und der war und der kommt, und von den sieben Geistern vor seinem Thron, und von Jesus Christus; er ist der treue Zeuge, der Erstgeborene der Toten, der Herrscher über die Könige der Erde« (Offb 1,4–5).
<G-vec00042-001-s431><come.kommen><en> Of course we first regain our innocence in baptism, but rarely does it come to full fruition.
<G-vec00042-001-s431><come.kommen><de> Natürlich erhalten wir zuerst unsere Unschuld bei der Taufe zurück, aber selten kommt es zur vollen Erfüllung.
<G-vec00042-001-s432><come.kommen><en> 3.1 The lodging agreement shall come into being by means of acceptance of the contractual partner’s booking by the host.
<G-vec00042-001-s432><come.kommen><de> 3.1 Der Beherbergungsvertrag kommt durch die Annahme der Bestellung des Vertragspartners durch den Beherberger zustande.
<G-vec00042-001-s433><come.kommen><en> He looked back out the rear window again like he was expecting mom to come walking around the corner any minute.
<G-vec00042-001-s433><come.kommen><de> Er sah wieder aus dem Heckfenster, als ob er erwarten würde, dass Mama jeden Moment um die Ecke kommt.
<G-vec00042-001-s434><come.kommen><en> If a woman feels the movement of menstrual blood inside her, but is does not come out until after the sun has set, her fast is valid and she does not have to make the day up later.
<G-vec00042-001-s434><come.kommen><de> Fühlt eine Frau die Bewegung des Menstruationsblutes in sich, es kommt jedoch bis zum Sonnenuntergang nicht heraus, so ist ihr Fasten ebenfalls gültig und sie muss den Tag nicht nachholen.
<G-vec00042-001-s435><come.kommen><en> People from enemy trenches will be interested in you as a mediator because you will come from the other side with the smell of these people on your clothes.
<G-vec00042-001-s435><come.kommen><de> Die Bewohner feindlicher Schützengräben werden sich für einen interessieren, weil man von der anderen Seite kommt und den Geruch der anderen in seinen Kleidern trägt.
<G-vec00042-001-s436><come.kommen><en> When you come to the very end of the breath, naturally, without thinking, the inhalation will follow and your belly will fill up and expand in front of you.
<G-vec00042-001-s436><come.kommen><de> Wenn man zu dem Ende des Atems kommt, dann folgt das Einatmen ganz natürlich, ohne dass man darüber nachzudenken brauchte und der Bauch füllt sich wieder.
<G-vec00078-001-s532><come.stammen><en> The advantages of Decaduro potentially come from the high levels of an amino-acid component.
<G-vec00078-001-s532><come.stammen><de> Die Vorteile der Decaduro vielleicht stammen aus den hohen Niveaus einer Aminosäure Wirkstoff.
<G-vec00078-001-s533><come.stammen><en> So when such scientists find bones and teeth which they think come from men then they most probably just come from animal-like men and therefore tell them nothing about the history of man and therefore there is no contradiction to what the Bible tells us about the history of man.
<G-vec00078-001-s533><come.stammen><de> Wenn solche Wissenschaftler also Knochen und Zähne finden, von denen sie annehmen, sie stammen von Menschen, dann kommen sie höchstwahrscheinlich nur von menschenähnlichen Tieren und erzählen ihnen überhaupt nichts über die Geschichte des Menschen und daher gibt es keine Widersprüche zu dem, was die Bibel uns über die Geschichte des Menschen sagt.
<G-vec00078-001-s534><come.stammen><en> Two chmafu productions come from the composer and media artist Elizabeth Schimana: on the one hand, her composition for the original synthesizer by Max Brand (“Höllenmaschine”), played by the incomparable performer of new composed and experimental music, Manon-Liu Winter, as well as Gregor Ladenhauf; and on the other hand, Schimana’s collaboration with the electronic musician and DJ Gernot Tutner, whose club nights in Graz and Ljubljana “Digitaler Rosengarten” (Schimana) and “Heavy Dope Beats” (Tutner) led to their co-production “Dope Beat Rosengarten”.
<G-vec00078-001-s534><come.stammen><de> Zwei chmafu-Produktionen stammen von der Komponistin und Medienkünstlerin Elisabeth Schimana, einerseits ihre Komposition für den Ur-Synthesizer von Max Brand („Höllenmaschine“), gespielt von der unvergleichlichen Interpretin neuer komponierter und experimenteller Musik, Manon-Liu Winter, sowie von Gregor Ladenhauf; und andererseits Schimanas Zusammenarbeit mit dem Elektroniker und DJ Gernot Tutner, deren differente Clubabende in Graz und Ljubljana „Digitaler Rosengarten“ (Schimana) und „Heavy Dope Beats“ (Tutner) auf ihrer Koproduktion in den „Dope Beat Rosengarten“ mündeten.
<G-vec00078-001-s535><come.stammen><en> Also from these works come Scientology technologies to rear children, repair families, educate, organize and provide relief in times of illness orsuffering.
<G-vec00078-001-s535><come.stammen><de> Aus diesen Werken stammen auch Scientology Lehren zum Großziehen von Kindern, Wiederherstellen von Familienbeziehungen, Ausbilden, Organisieren und Schaffen von Erleichterung in Zeiten von Krankheit oderLeiden.
<G-vec00078-001-s536><come.stammen><en> The families have come from a different region, as there was no more food for the cattle where they lived.
<G-vec00078-001-s536><come.stammen><de> Diese Familien stammen aus weit entfernten Regionen, wo es kein Futter mehr für ihr Vieh, von dem sie leben, gibt.
<G-vec00078-001-s537><come.stammen><en> All of the cards held by the ITS come from the second phase of the camp, between its reopening in May 1943 and the liberation in April/May 1945.
<G-vec00078-001-s537><come.stammen><de> Alle beim ITS erhaltenen Karten stammen aus der zweiten Phase des Lagers, also von der Wiedereröffnung im Mai 1943 bis zur Befreiung im April/Mai 1945.
<G-vec00078-001-s538><come.stammen><en> The data come from the GPS of the phone.
<G-vec00078-001-s538><come.stammen><de> Die Daten stammen aus den GPS des Telefons.
<G-vec00078-001-s539><come.stammen><en> For example, authorities in some major importing countries still fail to apply robust checks even where consignments come from countries that have been warned by the EU for having inadequate measures in place to prevent and deter illegal fishing.
<G-vec00078-001-s539><come.stammen><de> So versäumen es die Behörden einiger der großen einführenden Länder noch immer, sorgfältige Kontrollen vorzunehmen, selbst wenn die Ladungen aus Ländern stammen, die aufgrund ihrer unzureichenden Maßnahmen zur Verhinderung und Bekämpfung illegaler Fischerei bereits von der EU verwarnt wurden.
<G-vec00078-001-s540><come.stammen><en> On this and other occasions, the Salvis cuisine will prove itself. The Salvis VisionPRO stove is polished and some of Martina Strobel's specialities come from the Salvis Vario Cooker.
<G-vec00078-001-s540><come.stammen><de> Bei dieser und anderen Gelegenheiten bewährt sich die neue Salvis-Küche Der Salvis VisionPRO ist hochglanzpoliert und einige der Spezialitäten von Martina Strobel stammen vom Salvis Vario Bräter.
<G-vec00078-001-s541><come.stammen><en> At Löffler 99 percent of production is done in Europe while 80 percent of the value creation takes place in Austria and 70 percent of materials come from their own knitting factories.
<G-vec00078-001-s541><come.stammen><de> Bei Löffler erfolgen nicht nur 99 Prozent der Produktion in Europa, auch 80 Prozent der Wertschöpfung findet in Österreich statt, und 70 Prozent der Stoffe stammen aus der eigenen Strickerei.
<G-vec00078-001-s542><come.stammen><en> The organic search results come from the index database, while PPC's sponsored links are based on your bid and total investment.
<G-vec00078-001-s542><come.stammen><de> Organic Search Results stammen aus der Index-Datenbank, während die Sponsored Links von PPC auf Deinem Gebot und Deiner Gesamtinvestition basieren.
<G-vec00078-001-s543><come.stammen><en> In general, most of the entries come from the summer of 1943, specifically between May and August 1943.
<G-vec00078-001-s543><come.stammen><de> Generell stammen die meisten Einträge aus dem Sommer 1943, genauer von Mai bis August 1943.
<G-vec00078-001-s544><come.stammen><en> God promises Abraham three things here: Abraham would have many descendants, this nation would own and occupy a land, and a universal blessing will come to all mankind out of Abraham's line (the Jews).
<G-vec00078-001-s544><come.stammen><de> Gott versprich Abraham hier drei Dinge: dass Abraham viele Nachkommen haben wird, dass diese Nation ein Land besitzen und bewohnen wird, und eine universale Segnung allen Menschen zu Teil wird, die aus Abrahams Linie stammen (die Juden).
<G-vec00078-001-s545><come.stammen><en> The figures come from the EuroTrak surveys which were carried out in 2015 by EHIMA (European Hearing Instrument Manufacturers Association).
<G-vec00078-001-s545><come.stammen><de> Die Zahlen stammen aus der EuroTrak Studie, die im Jahr 2015 von EHIMA (European Hearing Instrument Manufacturers Association) durchgeführt wurde.
<G-vec00078-001-s546><come.stammen><en> And the cherry on the cake is that most of our mystical slots come from NOVOMATIC.
<G-vec00078-001-s546><come.stammen><de> Dass die meisten unserer Mystik-Slots von NOVOMATIC stammen, setzt dem Spielvergnügen die Krone auf.
<G-vec00078-001-s547><come.stammen><en> The originals for Lükenwerk's drawings come from every nook and cranny of the printed sphere, from magazines and catalogues, from advertising, science and fashion.
<G-vec00078-001-s547><come.stammen><de> Die Vorlagen zu ihren Zeichnungen stammen aus allen Ecken und Enden der gedruckten Welt, aus Magazinen und Katalogen, aus den Welten der Werbung, der Wissenschaft, der Mode.
<G-vec00078-001-s548><come.stammen><en> These approximately 5-6 cm long growing killifishes come from Guinea in West-Africa.
<G-vec00078-001-s548><come.stammen><de> Diese rund 5-6 cm lang werdenden Killifische stammen aus Guinea in Westafrika.
<G-vec00078-001-s549><come.stammen><en> My parents come from a small village in Senegal, in the northwest of Africa.
<G-vec00078-001-s549><come.stammen><de> Meine Eltern stammen aus einem kleinen Dorf im Senegal im Nordwesten Afrikas.
<G-vec00078-001-s550><come.stammen><en> In the health sector, over 70% of goods come from abroad.
<G-vec00078-001-s550><come.stammen><de> Im Gesundheitssektor stammen über 70% der Güter aus dem Ausland.
<G-vec00217-002-s019><come.bieten><en> Many rooms come with a spectacular view over the hills.
<G-vec00217-002-s019><come.bieten><de> Viele Zimmer bieten eine tolle Ausblick auf die Berge an.
<G-vec00217-002-s020><come.bieten><en> Some rooms come with a view of Battery Park.
<G-vec00217-002-s020><come.bieten><de> Die modernen Hotelzimmer bieten einen Blick auf die Skyline.
<G-vec00217-002-s021><come.bieten><en> Rooms come with the garden view.
<G-vec00217-002-s021><come.bieten><de> Die Zimmer bieten einen wunderbaren Ausblick auf den Garten.
<G-vec00217-002-s022><come.bieten><en> Non-smoking rooms come with an in-room safe, climate control, flat-screen TV, a dining area and a closet. The property offers a bathroom with a shower and a bidet.
<G-vec00217-002-s022><come.bieten><de> Die En-suite Zimmer bieten einen Zimmersafe, eine Minibar, Kabelfernsehen mit Video-on-demand, einen Wohnbereich und einen Schreibtisch sowie eine tolle Aussicht auf das Meer.
<G-vec00217-002-s023><come.bieten><en> Rooms in Hotel Garni Elba come with a coffee/tea maker.
<G-vec00217-002-s023><come.bieten><de> Die Zimmer im Hotel Garni Elba mit einer Küche bieten Kaffeemaschine/Teekocher.
<G-vec00217-002-s024><come.bieten><en> Classic-style rooms at the Il Corallo bed and breakfast come with a TV and a private bathroom including a hairdryer.
<G-vec00217-002-s024><come.bieten><de> Die Doppelzimmer sind im klassischen Stil eingerichtet, und bieten Ihnen einen Flachbild-TV und ein eigenes Bad mit einem Haartrockner und Handtüchern.
<G-vec00217-002-s025><come.bieten><en> Some rooms come with a stunning view of Arabian Gulf.
<G-vec00217-002-s025><come.bieten><de> Die Zimmer bieten einen tollen Blick auf die Lagune.
<G-vec00217-002-s026><come.bieten><en> Guest units come with air conditioning, tiled floors and a private terrace with serene ocean views.
<G-vec00217-002-s026><come.bieten><de> Die Unterkünfte bieten eine Klimaanlage, Fliesenböden und eine private Terrasse mit ruhigem Meerblick.
<G-vec00217-002-s027><come.bieten><en> With astonishing brightness, incomparable contrast and captivating color, images come to life with much greater brightness while also featuring much deeper, more nuanced darks.
<G-vec00217-002-s027><come.bieten><de> Mithilfe punktueller Dimmfunktion und hoher maximaler Helligkeit bis zu 600 Nit werden Bilder mit sichtbaren Höhepunkten zum Leben erweckt, die tiefere, nuanciertere Schwarztöne bieten.
<G-vec00217-002-s028><come.bieten><en> World of Judaica's Israeli Bookmarks come in a variety of styles and shapes.
<G-vec00217-002-s028><come.bieten><de> Wir bieten eine Vielfalt an Mesusas,Tallitot, Jüdischem Schmuck und weiteren Dingen an.
<G-vec00217-002-s029><come.bieten><en> Certain rooms come with a balcony.
<G-vec00217-002-s029><come.bieten><de> Einige Zimmer bieten einen Balkon.
<G-vec00217-002-s030><come.bieten><en> Rooms come with a private bathroom equipped with a bath or shower.
<G-vec00217-002-s030><come.bieten><de> Die Zimmer bieten Ihnen ein eigenes Bad mit einer Badewanne oder einer Dusche.
<G-vec00217-002-s031><come.bieten><en> The rooms come with en suite bathrooms featuring a shower, free toiletries and a hairdryer.
<G-vec00217-002-s031><come.bieten><de> Sie bieten private Badezimmer, die über eine Dusche, einen Fön und eine Badewanne verfügen.
<G-vec00217-002-s032><come.bieten><en> All rooms come with a seating area and a toilet with shower, hairdryer and free toiletries.
<G-vec00217-002-s032><come.bieten><de> Alle Zimmer bieten einen Sitzbereich sowie ein Bad mit Dusche, Haartrockner und kostenlosen Pflegeprodukten.
<G-vec00217-002-s033><come.bieten><en> Quality materials and thorough workmanship guarantee a long service life and a reflection of excellence for years to come.
<G-vec00217-002-s033><come.bieten><de> Qualitativ hochwertige Materialien und solide Ausführung bieten die Gewähr für lange Lebensdauer und ein auf Dauer attraktives Erscheinungsbild.
<G-vec00217-002-s034><come.bieten><en> The apartments come with a kitchen, a dining area and a private bathroom.
<G-vec00217-002-s034><come.bieten><de> Die Apartments bieten Ihnen eine Küche, einen Essbereich und ein eigenes Bad.
<G-vec00217-002-s035><come.bieten><en> Some hotel rooms come with a panoramic view over the sea.
<G-vec00217-002-s035><come.bieten><de> Die Zimmer bieten einen tollen Ausblick auf das Meer.
<G-vec00217-002-s036><come.bieten><en> Room description The spacious rooms each come with a bath/ shower, a hairdryer, a direct dial telephone, a satellite TV, a radio and high speed Internet access.
<G-vec00217-002-s036><come.bieten><de> Zimmerbeschreibung Die Hotelzimmer bieten ein eigenes Badezimmer mit Dusche/Badewanne und Haartrockner sowie ein Direktwahltelefon, ein TV-Gerät mit Sat.-Kanälen, ein Radio und DSL-Internetzugang.
<G-vec00217-002-s037><come.bieten><en> These comfortable rooms come with a hairdryer and a Jacuzzi supplied in a designer bathroom.
<G-vec00217-002-s037><come.bieten><de> Die Zimmer bieten En-suite-Badezimmer mit einer Badewanne, einem Fön und einem Jacuzzi.
<G-vec00217-002-s076><come.entstehen><en> Something Great will come of it...
<G-vec00217-002-s076><come.entstehen><de> Es wird Großartiges daraus entstehen...
<G-vec00217-002-s077><come.entstehen><en> The basis for peace of mind is self-confidence and inner strength, which come from the practice of love and compassion, with a sense of respect for others and concern for their well-being.
<G-vec00217-002-s077><come.entstehen><de> Die Grundlage für geistigen Frieden ist Selbstvertrauen und innere Stärke, die durch die Praxis von Liebe und Mitgefühl, mit einem Gefühl des Respekts gegenüber anderen und einer Sorge um ihr Wohlergehen, entstehen.
<G-vec00217-002-s078><come.entstehen><en> My works come about in Hamburg Altona and Großenwörden in the inspiring Osteland.
<G-vec00217-002-s078><come.entstehen><de> Meine Arbeiten entstehen in Hamburg Altona und in Großenwörden im inspirierenden Osteland.
<G-vec00217-002-s079><come.entstehen><en> Combined with khaki, gold, thistle and indigo blue, interesting cold/warm contrasts come to light.
<G-vec00217-002-s079><come.entstehen><de> Kombiniert mit Khaki, Gold, Distelgrün und Indigo Blue entstehen interessante Kalt-Warm-Kontraste.
<G-vec00217-002-s080><come.entstehen><en> This is how the best services come about.
<G-vec00217-002-s080><come.entstehen><de> Auf diese Weise entstehen die besten Services.
<G-vec00217-002-s081><come.entstehen><en> An alternative approach may come from the potential therapeutic qualities of CBD.
<G-vec00217-002-s081><come.entstehen><de> Ein alternativer Ansatz könnte aus den potenziell therapeutischen Qualitäten von CBD entstehen.
<G-vec00217-002-s082><come.entstehen><en> Everything actually needs to come into being from nothing.
<G-vec00217-002-s082><come.entstehen><de> Alles muss eigentlich aus dem Nichts entstehen.
<G-vec00217-002-s083><come.entstehen><en> They come as well when the priesthood service is to members within the quorum.
<G-vec00217-002-s083><come.entstehen><de> Sie entstehen auch, wenn das Kollegium durch das Priestertum den Mitgliedern in seinen eigenen Reihen dient.
<G-vec00217-002-s084><come.entstehen><en> Or we can provide a complete team so the aforementioned problems don’t come up in the first place.
<G-vec00217-002-s084><come.entstehen><de> Oder wir stellen gleich ein komplettes Team, damit die oben beschriebenen Probleme erst gar nicht entstehen können.
<G-vec00217-002-s085><come.entstehen><en> And when a group unites against something, an amazingly powerful strength can come out of it.
<G-vec00217-002-s085><come.entstehen><de> Und wenn sich eine Gruppe gegen etwas vereinigt, kann daraus eine mächtige Energie entstehen.
<G-vec00217-002-s086><come.entstehen><en> It is important for self-confidence, but it can only come from someone else.
<G-vec00217-002-s086><come.entstehen><de> Sie ist wichtig für das Selbstbewusstsein, kann aber nicht aus dem eigenen Ich heraus entstehen.
<G-vec00217-002-s087><come.entstehen><en> At least I was able to sense, how his manipulated photographs could come into being.
<G-vec00217-002-s087><come.entstehen><de> Zumindest erahne ich gerade, wie seine manipulierte Fotografie entstehen könnte.
<G-vec00217-002-s088><come.entstehen><en> The object of much of today’s humanities research and cultural criticism is to demonstrate how an imaginary geography or an imagined community develops permanence and boundaries and ultimately replaces reality itself, and how this happens through identification processes in which some elements are discarded in order for that community’s identity to come into being, be it Swedish, Nordic, European or global.
<G-vec00217-002-s088><come.entstehen><de> Gegenstand der geisteswissenschaftlichen Forschung und Kulturkritik ist heute häufig, aufzuzeigen, wie eine imaginäre Geographie oder imaginäre Gemeinschaft Stabilität und Grenzen erhält und am Ende selbst den Platz der Wirklichkeit einnimmt, und wie dies durch Identifikationsprozesse geschieht, in denen manches aussortiert wird, damit die eigene Identität entstehen kann, ganz gleich ob schwedisch, nordisch, europäisch oder global.
<G-vec00217-002-s089><come.entstehen><en> Netflix also reported that more than 60% of its rentals come from recommendations that are based off of hyper personalization data. **
<G-vec00217-002-s089><come.entstehen><de> Auch Netflix berichtet, dass 60% ihrer Verkäufe aus Vorschlägen entstehen, die Kunden aufgrund ihrer personalisierten Daten erhalten.
<G-vec00217-002-s090><come.entstehen><en> You need creativity and skill to make Bronze Age decorations from metal and let the Middle Ages come to life with self decorated beads.
<G-vec00217-002-s090><come.entstehen><de> Kreativität und Geschick sind gefragt, wenn aus Metall bronzezeitliche Geschmeide entstehen und selbst verzierte Perlen das Mittelalter auferstehen lassen.
<G-vec00217-002-s091><come.entstehen><en> I’m not quite sure how the pictures come about, and why they are what they are.
<G-vec00217-002-s091><come.entstehen><de> Ich weiß nicht genau, wie die Bilder entstehen, und woran es liegt, wie sie sind.
<G-vec00217-002-s092><come.entstehen><en> Yet we all have long known that extraordinary ideas seldom come from nowhere.
<G-vec00217-002-s092><come.entstehen><de> Dabei wissen wir längst, dass außergewöhnliche Einfälle selten aus einem Vakuum heraus entstehen.
<G-vec00217-002-s093><come.entstehen><en> The relevant research is in the tradition of the resource-based basis and has not yet decided sufficiently what exactly dynamical capabilities are, where they are rooted in the organization, how they come into being, and how their advantage can be unfolded.
<G-vec00217-002-s093><come.entstehen><de> Die in der Tradition des ressourcen-orientierten Ansatzes stehende einschlägige Forschung hat bislang jedoch noch nicht hinreichend bestimmt, was genau unter dynamischen Fähigkeiten zu verstehen ist, wo in der Organisation sie zu verorten sind, wodurch sie entstehen und wie genau sich ihr Nutzen entfaltet.
<G-vec00217-002-s094><come.entstehen><en> Time and again almost magical moments come up - so great is the intimacy between the protagonists on stage and the audience.
<G-vec00217-002-s094><come.entstehen><de> So entstehen auch immer wieder fast schon magische Momente - so groß wird die Innigkeit zwischen den Akteuren auf der Bühne und dem Publikum.
<G-vec00217-002-s114><come.finden><en> "Players like him are hard to come by.
<G-vec00217-002-s114><come.finden><de> "Es ist sehr schwer, einen Spieler wie ihn zu finden.
<G-vec00217-002-s115><come.finden><en> You’ll hardly come across a model that is prettier and better.
<G-vec00217-002-s115><come.finden><de> Ein Exemplar, das schöner oder besser ist, werden Sie mit Sicherheit nicht finden.
<G-vec00217-002-s116><come.finden><en> Right in the center of Rotterdam, next to Blaak Station, you will come across this chocolate paradise in the Markthal.
<G-vec00217-002-s116><come.finden><de> Mitten im Zentrum von Rotterdam, neben der Blaak Station, finden Sie dieses Schokoladenparadies in der Markthal.
<G-vec00217-002-s117><come.finden><en> Our team is made up of people from various backgrounds who together can come up with an answer to any question.
<G-vec00217-002-s117><come.finden><de> Es besteht aus Menschen verschiedener Hintergrunds, die gemeinsam für jede Frage eine Antwort finden können.
<G-vec00217-002-s118><come.finden><en> It is a humanitarian imperative that the suffering, hunger and deaths finally come to an end.
<G-vec00217-002-s118><come.finden><de> Es ist ein Gebot der Menschlichkeit, dass Leiden, Hungern und Sterben endlich ein Ende finden.
<G-vec00217-002-s119><come.finden><en> In practice, work opportunities are rather more limited, although there is some seasonal tourist industry work available during the summer if you have the requisite skills and language abilities (Norwegian will come in handy).
<G-vec00217-002-s119><come.finden><de> In der Praxis ist die Arbeitserlaubnis trotzdem erschwert, obwohl du sehr schnell in der saisonalen Tourismusbranche eine Arbeit finden kannst, vorausgesetzt, du besitzt die nötigen Anforderungen und Sprachkenntnisse in Norwegisch.
<G-vec00217-002-s120><come.finden><en> If you want to learn English, make friends, have fun and explore the UK come and join us in the July and/or August.
<G-vec00217-002-s120><come.finden><de> Wenn Sie Englisch lernen, Freunde finden, Spaß haben und das Vereinigte Königreich erkunden möchten, besuchen Sie uns im Juli und / oder August.
<G-vec00217-002-s121><come.finden><en> It had saved his ears more then once to be able to come up with a believable explanation why some disaster was not at all related to the fact that he had been close.
<G-vec00217-002-s121><come.finden><de> Damit hatte er seine Ohren mehr als einmal retten können, wenn es darum ging eine glaubhaften Erklärung zu finden für die Tatsache, warum irgendeine Katastrophe ganz sicher nichts mit seiner Anwesenheit zu tun hatte.
<G-vec00217-002-s122><come.finden><en> It seems like it should be fairly easy for the two sides to come together.
<G-vec00217-002-s122><come.finden><de> Es scheint, als sollte es für die beiden Seiten relativ leicht sein, eine Einigung zu finden.
<G-vec00217-002-s123><come.finden><en> My immune system has crashed completely, I welcome each bacteria and virus I come across.
<G-vec00217-002-s123><come.finden><de> Mein Immunsystem ist so im Eimer, dass ich jede Bakterie und jeden Virus mitnehmen, den ich finden kann.
<G-vec00217-002-s124><come.finden><en> True unicorns that meet all of our criteria are hard to come by.
<G-vec00217-002-s124><come.finden><de> Wahre Unicorns, die alle unsere Kriterien erfüllen, sind jedoch schwer zu finden.
<G-vec00217-002-s125><come.finden><en> I, therefore, do not believe anybody could come up with a universal “sufficient condition” based on which you can always tell whether or not an enterprise has been acting ethically or not.
<G-vec00217-002-s125><come.finden><de> So glaube ich nicht, dass es genügt und gelingt, eine allgemeine „hinreichende Bedingung“ zu finden, an der gemessen werden kann, ob ein Unternehmen ethisch handelt oder nicht.
<G-vec00217-002-s126><come.finden><en> At that point the Iranian professor believed he’d come up with another argument.
<G-vec00217-002-s126><come.finden><de> In diesem Augenblick glaubte der Professor, ein anderes Argument zu finden.
<G-vec00217-002-s127><come.finden><en> One more fascinating variation you may come across web is Pontoon.
<G-vec00217-002-s127><come.finden><de> Eine andere interessante Internet-basierte Varianz Sie finden könnte, ist Pontoon.
<G-vec00217-002-s128><come.finden><en> The very goal of our industry is to come up with a smart and effective solution for these challenges.
<G-vec00217-002-s128><come.finden><de> Genau dies ist das Ziel unserer Branche: intelligente und effektive Lösungen für diese Herausforderungen zu finden.
<G-vec00217-002-s129><come.finden><en> Currently, there is not enough data and evidence to come up with a solution for that.
<G-vec00217-002-s129><come.finden><de> Gegenwärtig gibt es nicht genügend Daten und Beweise, um eine Lösung dafür zu finden.
<G-vec00217-002-s130><come.finden><en> Talking to other singles who have similar interests is a great way to come up with ideas to do on a first date.
<G-vec00217-002-s130><come.finden><de> Triff andere,die ähnliche Interessen haben, das ist ein perfekter Weg, um Ideen zu finden für gemeinsame Unternehmungen beim ersten Treffen.
<G-vec00217-002-s131><come.finden><en> Being a flexible co-packer, we would like to think along with you to come to your personal packaging solution.
<G-vec00217-002-s131><come.finden><de> Als flexibler Copacker arbeiten wir gerne mit Ihnen zusammen, um die für Sie ideale Verpackungslösung zu finden.
<G-vec00217-002-s132><come.finden><en> He added that he had been waiting for a lifetime to come up with a character together with his dad.
<G-vec00217-002-s132><come.finden><de> Er fügte hinzu, dass er auf ein Leben lang gewartet habe, um zusammen mit seinem Vater eine Figur zu finden.
<G-vec00217-002-s171><come.gelangen><en> The customer hereby grants the Bank a lien on valuables of any kind which, in the course of banking business, may come into the possession or power of disposition of the Bank through acts of the customer or of third parties for account of the customer.
<G-vec00217-002-s171><come.gelangen><de> Der Kunde räumt hiermit der BayernLB ein Pfandrecht ein an Werten jeder Art, die im bankmäßigen Geschäftsverkehr durch den Kunden oder durch Dritte für seine Rechnung in ihren Besitz oder ihre sonstige Verfügungsmacht gelangen.
<G-vec00217-002-s172><come.gelangen><en> And we need to make the bridge between the results of research on one hand and the potential investors on the other, for innovation to come out of the lab and onto the market.
<G-vec00217-002-s172><come.gelangen><de> Und wir müssen Brücken bauen zwischen den Forschungsergebnissen einerseits und potentiellen Investoren andererseits, damit die Innovation vom Labor auf den Markt gelangen kann.
<G-vec00217-002-s173><come.gelangen><en> 9 If they say thus to us, Stand still until we come to you, then we will stay in our place, and will not go up to them.
<G-vec00217-002-s173><come.gelangen><de> 9 Wenn sie dann zu uns sagen: «Steht stille, bis wir zu euch gelangen!» so wollen wir an unserm Ort stehenbleiben und nicht zu ihnen hinaufsteigen.
<G-vec00217-002-s174><come.gelangen><en> The parties will subsequently consult and try to come to an agreement.
<G-vec00217-002-s174><come.gelangen><de> Die Parteien werden sich daraufhin beraten und versuchen, zu einer Einigung zu gelangen.
<G-vec00217-002-s175><come.gelangen><en> After around 30 minutes, you will come to the clearing with the Ellmau Stone Circle.
<G-vec00217-002-s175><come.gelangen><de> Nach circa 30 Minuten gelangen Sie an die Lichtung mit dem Ellmauer Steinkreis.
<G-vec00217-002-s176><come.gelangen><en> You will look for me; and as I said to the Jews so now I say to you, “Where I am going, you cannot come.”
<G-vec00217-002-s176><come.gelangen><de> Ihr werdet mich suchen, und was ich den Juden gesagt habe, sage ich jetzt auch euch: Wohin ich gehe, dorthin könnt ihr nicht gelangen.
<G-vec00217-002-s177><come.gelangen><en> If you come to our website via a Google advert, Google AdWords will place a cookie on your device ("conversion cookie").
<G-vec00217-002-s177><come.gelangen><de> Wenn Sie über eine Googleanzeige auf unsere Webseite gelangen, setzt Google Adwords einen Cookie auf Ihrem Gerät („Conversion Cookie“).
<G-vec00217-002-s178><come.gelangen><en> The works resulting from this experience address our frequently ambiguous attitude to what is foreign to us: whereas “exotic” luxury items and food such as tropical fruit are regarded as positive and precious, people who come to us as refugees from the same countries are often rejected as being “foreign,” and their “exotic” nature is sometimes even perceived as a threat.
<G-vec00217-002-s178><come.gelangen><de> Die in der Folge entstandene Arbeiten thematisieren unser oft zwiespältiges Verhältnis zum Fremden: so wird das ‚Exotische‘ in Form von Luxusgütern und Essen, etwa den geschätzten Südfrüchten, als positiv und begehrenswert empfunden, während Menschen, die aus denselben Regionen der Erde als Geflüchtete zu uns gelangen, aufgrund ihrer ‚Fremdheit‘ Ablehnung erfahren, oder das ‚Exotische‘ gar als Bedrohung empfunden wird.
<G-vec00217-002-s179><come.gelangen><en> Over the past weeks, frequent interactions took place to come to a common understanding on the way forward for a long-term, strategic ESA–EU partnership, building on the successes so far: Galileo and EGNOS already provide world-class navigation services and Copernicus is the most complete Earth observation system in the world.
<G-vec00217-002-s179><come.gelangen><de> In den letzten Wochen haben zahlreiche Gespräche stattgefunden, um zu einem gemeinsamen Verständnis über das weitere Vorgehen im Hinblick auf eine langfristige strategische Partnerschaft zwischen der ESA und der EU zu gelangen, die auf den bisherigen Erfolgen aufbaut: Galileo und EGNOS bieten bereits Navigationsdienste der Spitzenklasse, und Copernicus ist das umfassendste Erdbeobachtungssystem der Welt.
<G-vec00217-002-s180><come.gelangen><en> Let the inner joy within you come to the surface.
<G-vec00217-002-s180><come.gelangen><de> Lasst die innere Freude inwendig in euch an die Oberfläche gelangen.
<G-vec00217-002-s181><come.gelangen><en> In a further advantageous embodiment of the invention, an impermeable immersion liquid protective layer is at least one surface of the terminating element, which can come into contact with immersion liquid, is applied.
<G-vec00217-002-s181><come.gelangen><de> Bei einer weiteren vorteilhaften Ausgestaltung der Erfindung ist auf wenigstens eine Oberfläche des Abschlußelements, die mit Immersionsflüssigkeit in Berührung gelangen kann, eine für Immersionsflüssigkeit undurchlässige Schutzschicht aufgebracht.
<G-vec00217-002-s182><come.gelangen><en> “Through your prayer, night and day, you bring before God the lives of so many of our brothers and sisters who for various reasons cannot come to him to experience his healing mercy, even as he patiently waits for them.
<G-vec00217-002-s182><come.gelangen><de> Durch euer Gebet tragt ihr Tag und Nacht das Leben vieler Brüder und Schwestern vor den Herrn, die aus verschiedenen Gründen nicht zu ihm gelangen und die Erfahrung seiner heilenden Barmherzigkeit machen können, während er sie erwartet, um ihnen Gnade zu erweisen.
<G-vec00217-002-s183><come.gelangen><en> See what we come to.
<G-vec00217-002-s183><come.gelangen><de> Seht, wozu wir gelangen.
<G-vec00217-002-s184><come.gelangen><en> This affects your health and energy (apart from the fact that plastic residues come into your food).
<G-vec00217-002-s184><come.gelangen><de> Dies ist negativ für Ihre Gesundheit und Energie (neben der Tatsache, dass Plastikreste ins Essen gelangen).
<G-vec00217-002-s185><come.gelangen><en> In Stage 2 of the Product Backlog, Items come exclusively from Stage 3.
<G-vec00217-002-s185><come.gelangen><de> In die Stufe 2 des Product Backlogs gelangen Items ausschließlich aus der Stufe 3.
<G-vec00217-002-s186><come.gelangen><en> From here, the path follows the stream bank and a little further on we come to the narrow part of the stream, where the gorge virtually begins.
<G-vec00217-002-s186><come.gelangen><de> Von hier aus folgt der Pfad dem Flussufer und ein bisschen weiter gelangen wir zur Enge des Flusslaufes, an der die Schlucht eigentlich beginnt.
<G-vec00217-002-s187><come.gelangen><en> With the help of this Upper Force, the world can come to the correct condition.
<G-vec00217-002-s187><come.gelangen><de> Mit Hilfe dieser Höheren Kraft kann die Welt zum richtigen Zustand gelangen.
<G-vec00217-002-s188><come.gelangen><en> We use the information to compile reports and to help us improve the website. The cookies collect information in an anonymous form, including the number of visitors to the websites, where visitors have come to the website from and the pages they visited.
<G-vec00217-002-s188><come.gelangen><de> Wir verwenden diese Daten, um Berichte zu erstellen und unsere Website zu verbessern Die Cookies erfassen Daten anonymisiert; es wird beispielsweise die Anzahl der Website-Besucher registriert, von wo aus Besucher auf die Websites gelangen sowie die Seiten, die sie besuchen.
<G-vec00217-002-s189><come.gelangen><en> Going past St. Johann im Pongau you will finally come to the region of Zell am See-Kaprun and to the Seehotel Bellevue, which is located in Thumersbach on the eastern lakeshore.
<G-vec00217-002-s189><come.gelangen><de> Über St. Johann im Pongau gelangen Sie schließlich in die Region Zell am See-Kaprun und zum Seehotel Bellevue, welches sich bei Thumersbach am östlichen Ufer des Zeller Sees befindet.
<G-vec00217-002-s285><come.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00217-002-s285><come.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00217-002-s286><come.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00217-002-s286><come.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00217-002-s287><come.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00217-002-s287><come.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00217-002-s288><come.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00217-002-s288><come.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00217-002-s289><come.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00217-002-s289><come.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00217-002-s290><come.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00217-002-s290><come.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00217-002-s291><come.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00217-002-s291><come.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00217-002-s292><come.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00217-002-s292><come.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00217-002-s293><come.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00217-002-s293><come.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00217-002-s294><come.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00217-002-s294><come.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00217-002-s295><come.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00217-002-s295><come.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00217-002-s296><come.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00217-002-s296><come.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00217-002-s297><come.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00217-002-s297><come.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00217-002-s298><come.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00217-002-s298><come.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00217-002-s299><come.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00217-002-s299><come.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00217-002-s300><come.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00217-002-s300><come.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00217-002-s301><come.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00217-002-s301><come.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00217-002-s302><come.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00217-002-s302><come.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00217-002-s303><come.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00217-002-s303><come.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00217-002-s551><come.stammen><en> But where does this Life come from to raise the dead?
<G-vec00217-002-s551><come.stammen><de> Woher stammt aber dieses Leben, das die Toten auferstehen lässt.
<G-vec00217-002-s552><come.stammen><en> 93.30% 97.80% The majority of visitors come from United States.
<G-vec00217-002-s552><come.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Deutschland, Reino Unido, Kanada, Indien & Vereinigte Staaten.
<G-vec00217-002-s553><come.stammen><en> Fun fact: Welsh ponies come from Wales and date back to the time of the Celts.
<G-vec00217-002-s553><come.stammen><de> Interessante Tatsache: Das Welsh-Pony stammt aus Wales und hat seine Ursprünge in der Zeit der Kelten.
<G-vec00217-002-s554><come.stammen><en> The majority of visitors come from United States, Italy, Greece, Spain, Poland & Chile.
<G-vec00217-002-s554><come.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Türkei, Polen, Spanien, Niederlande, Schweiz und Deutschland.
<G-vec00217-002-s555><come.stammen><en> Most of our clients come from the creative sector.
<G-vec00217-002-s555><come.stammen><de> Ein Großteil unserer KundInnen stammt aus dem Kreativbereich.
<G-vec00217-002-s556><come.stammen><en> The majority of visitors come from Germany, France, Indonesia, United Kingdom, Austria & Uruguay. City City Rank
<G-vec00217-002-s556><come.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Spanien, Deutschland, Australien, Vietnam, Reino Unido und Schweiz.
<G-vec00217-002-s557><come.stammen><en> Approximately half of all fossil resources now come from sources lying below the sea floor.
<G-vec00217-002-s557><come.stammen><de> Inzwischen stammt rund die Hälfte der fossilen Bodenschätze aus unter dem Meeresgrund liegenden Quellen.
<G-vec00217-002-s558><come.stammen><en> Even his Fleur de Sel does not just come from anywhere, rather he produces it himself.
<G-vec00217-002-s558><come.stammen><de> Auch sein Fleur de Sel stammt nicht von irgendwo, sondern aus seiner eigenen Produktion.
<G-vec00217-002-s559><come.stammen><en> A web analysis service collects, inter alia, data about the website from which a person has come (the so-called referrer), which sub-pages were visited, or how often and for what duration a sub-page was viewed.
<G-vec00217-002-s559><come.stammen><de> Ein Webanalysedienst erhebt unter anderem Daten über die Website, von der eine Person stammt (sogenannter Referrer), welche Unterseiten besucht wurden oder wie oft und für wie lange eine Unterseite aufgerufen wurde.
<G-vec00217-002-s560><come.stammen><en> Those who come from Eritrea and ask for asylum in Switzerland will have higher hurdles in the future.
<G-vec00217-002-s560><come.stammen><de> Wer aus Eritrea stammt und in der Schweiz um Asyl ersucht, hat künftig höhere Hürden.
<G-vec00217-002-s561><come.stammen><en> This is quite correct; but the proletariat must also recognize that the ‘national' element does not come from the oppressed and exploited masses, but from their oppressors and exploiters - the bourgeoisie.
<G-vec00217-002-s561><come.stammen><de> Dies ist ganz richtig, aber das Proletariat muss auch anerkennen, dass das nationale Element nicht von den unterdrückten und ausgebeuteten Massen stammt, sondern von ihren Unterdrückern und Ausbeutern - die Bourgeoisie.
<G-vec00217-002-s562><come.stammen><en> Many of the best grapes come from the limestone Arrábida hills high over the peninsula’s southern coast.
<G-vec00217-002-s562><come.stammen><de> Ein Großteil der besten Trauben stammt aus dem kalksteinhaltigen Arrábida Hügelland, das sich hoch über der südlichen Küste der Halbinsel erstreckt.
<G-vec00217-002-s563><come.stammen><en> Approximately one third of the members come from the fields of administration and education and approximately two thirds from the world of business, from bank institutes to medium-sized companies to global corporations.
<G-vec00217-002-s563><come.stammen><de> Rund ein Drittel der Mitglieder stammt aus dem Verwaltungs- und Bildungsbereich, etwa zwei Drittel aus der Wirtschaft, vom Bankinstitut über das mittelständische Unternehmen bis hin zum Weltkonzern.
<G-vec00217-002-s564><come.stammen><en> The basic prerequisites are that the ingredients come from the region, that production is regional, and that the products are firmly rooted in regional gastronomy.
<G-vec00217-002-s564><come.stammen><de> Grundvoraussetzungen sind, dass der Rohstoff aus der Region stammt, die Produktion örtlich erfolgt und die Produkte in der regionalen Gastronomie verankert sind.
<G-vec00217-002-s565><come.stammen><en> Authentication is a security measure implemented by NTP to ensure that the time signal that is sent comes from where it claims to come from.
<G-vec00217-002-s565><come.stammen><de> Die Authentifizierung ist eine Sicherheitsmaßnahme, die von NTP implementiert wird, um sicherzustellen, dass das gesendete Zeitsignal von der Stelle kommt, von der es angeblich stammt.
<G-vec00217-002-s566><come.stammen><en> The essential oils come from organic farming.
<G-vec00217-002-s566><come.stammen><de> Oliven-ätherische Öl stammt aus kontrolliert biologischem Anbau.
<G-vec00217-002-s567><come.stammen><en> The majority of international clients come from Venezuela, Jordan and China.
<G-vec00217-002-s567><come.stammen><de> Der Großteil der internationalen Kunden stammt aus Venezuela und Jordanien sowie aus China.
<G-vec00217-002-s568><come.stammen><en> Smartly Dressed Games is the name of the company that was created by Nelson and this probably isn’t the last title to come from them.
<G-vec00217-002-s568><come.stammen><de> Smartly Dressed Games ist der Name der Firma, die von Nelson gegründet wurde, und das ist wahrscheinlich nicht der letzte Titel, der von ihnen stammt.
<G-vec00217-002-s569><come.stammen><en> It’s name come from the work “Skufos” which namastea dating means giant cup in ancient Greek, and it is because it looks like one morphologically as it is surrounded from the higher mountain tops of Lefka Ori.
<G-vec00217-002-s569><come.stammen><de> Der Name stammt von “Skufos”, was auf Altgriechisch große Tasse bedeutet: und das aufgrund dessen, weil der Ort von den höheren Berggipfeln von Lefka Ori umgeben ist.
<G-vec00217-002-s570><come.treffen><en> In the process, people can come together who work in various forms of the care sector: professional care providers, caregivers in family and neighbour contexts, and those in self-care situations.
<G-vec00217-002-s570><come.treffen><de> Dabei treffen Menschen zusammen, die in verschiedener Form Arbeitende in diesem Bereich sind: Beruflich Sorgearbeitende, Sorgearbeitende in familiären und nachbarschaftlichen Zusammenhängen und in der Selbstsorge Tätige.
<G-vec00217-002-s571><come.treffen><en> Here you will come across a lot of young people and probably for the first time in a long time feel that there is something happening in the South Island!
<G-vec00217-002-s571><come.treffen><de> Hier wirst du viele junge Menschen treffen und vermutlich zum ersten Mal seit längerer Zeit das Gefühl haben, dass in Neuseeland ja doch etwas los ist.
<G-vec00217-002-s572><come.treffen><en> All the Syrians, as the UN Security Council resolution says, must sit down and come to an agreement.
<G-vec00217-002-s572><come.treffen><de> Alle Syrer sollten in Übereinstimmung mit der Resolution des UN-Sicherheitsrats am Verhandlungstisch zusammenkommen und eine Vereinbarung treffen.
<G-vec00217-002-s573><come.treffen><en> The prophet Isaiah brings to view the fearful deception which will come upon the wicked, causing them to count themselves secure from the judgments of God: "We have made a covenant with death, and with hell are we at agreement. When the overflowing scourge shall pass through, it shall not come unto (378) us; for we have made lies our refuge, and under falsehood have we hid ourselves." Isa.
<G-vec00217-002-s573><come.treffen><de> Der Prophet Jesaja weist auf die furchtbare Täuschung hin, welche über die Gottlosen kommen wird, so daß sie sich vor den Gerichten Gottes sicher fühlen: „Wir haben mit dem Tode einen Bund und mit der Hölle einen Vertrag gemacht; wenn eine Flut dahergeht, wird sie uns nicht treffen; denn wir haben die Lüge zu unserer Zuflucht und Heuchelei zu unserem Schirm gemacht.“ (Jes.
<G-vec00217-002-s574><come.treffen><en> Things often come to me with time, so a day later I sat on the beach and cried.
<G-vec00217-002-s574><come.treffen><de> Einen Tag später – manchmal treffen mich Dinge mit Zeitverzögerung – habe ich dann am Strand gesessen und geweint.
<G-vec00217-002-s575><come.treffen><en> If you cannot manage to come from Sunday to Sunday, try and come from Thursday or Friday evening until Sunday.
<G-vec00217-002-s575><come.treffen><de> Wer nicht von Sonntag bis Sonntag an den Treffen teilnehmen kann, sollte am Donnerstag- oder spätestens Freitagabend ankommen und bis Sonntag bleiben.
<G-vec00217-002-s576><come.treffen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00217-002-s576><come.treffen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00217-002-s577><come.treffen><en> As in the best tradition, the workshop is the natural place in which craftsmanship and design come together, inextricably linking production and design.
<G-vec00217-002-s577><come.treffen><de> Wie in der besten Tradition ist die Werkstatt der Ort, an dem sich Handwerk und Design treffen und dabei Produktion und Planung unlösbar miteinander verbinden.
<G-vec00217-002-s578><come.treffen><en> Numerous national and international representatives from business and politics will come together for this first-class event in order to discuss the most current topics.
<G-vec00217-002-s578><come.treffen><de> Anlässlich des hochkarätigen Anlasses treffen sich zahlreiche nationale und internationale Vertreter aus Wirtschaft und Politik in Vaduz, um topaktuelle Themen zu diskutieren.
<G-vec00217-002-s579><come.treffen><en> Then we pass through the gates of Heaven and come across the proud people who humbly pray the Pater Noster.
<G-vec00217-002-s579><come.treffen><de> Dann werden wir durch die Pforte des Himmels gehen und treffen die Stolzen die demütig das Pater Noster beten.
<G-vec00217-002-s580><come.treffen><en> Digitalisation and sustainability – two key “mega trends” come together.
<G-vec00217-002-s580><come.treffen><de> Digitalisierung und Nachhaltigkeit – hier treffen zwei Megatrends aufeinander.
<G-vec00217-002-s581><come.treffen><en> Schedule of events You can come and get to know the JBL team personally at the following events in April 2018.
<G-vec00217-002-s581><come.treffen><de> Auf folgenden Veranstaltungen können Sie uns im Juni 2018 treffen und das JBL Team persönlich kennenlernen.
<G-vec00217-002-s582><come.treffen><en> Wherever you go, you will come across open-minded people who will be happy to speak English with you.
<G-vec00217-002-s582><come.treffen><de> Überall werden Sie auf aufgeschlossene Menschen treffen, die gerne mit Ihnen Englisch plaudern.
<G-vec00217-002-s583><come.treffen><en> If these high-stakes talks come to pass, they would be the first between a sitting US president and a North Korean leader.
<G-vec00217-002-s583><come.treffen><de> Eine Reise des nordkoreanischen Außenministers nach Schweden nährt nun Spekulationen über den Austragungsort für dieses erste Treffen zwischen einem amtierenden US-Präsidenten und einem nordkoreanischen Machthaber.
<G-vec00217-002-s584><come.treffen><en> Because particular bodily organs correspond to every point, it is possible to come to the conclusion about state of this organs.
<G-vec00217-002-s584><come.treffen><de> Weil es jedem Punkt bestimmte Körperorgane entsprechen, ist auf Grund des gemessenen Widerstandes den Beschluss über den Stand dieser Organe zu treffen.
<G-vec00217-002-s585><come.treffen><en> Graduates of the Master of Science in International Cooperation in Urban Development come upon a broad field of work which has a strong demand for professionals in international projects about urban development.
<G-vec00217-002-s585><come.treffen><de> Absolventen und Absolventinnen des Master of Science International Cooperation in Urban Development treffen auf ein weites Arbeitsfeld mit einer starken Nachfrage nach Fachkräften für internationale Projekte im Bereich der Stadtentwicklung.
<G-vec00217-002-s586><come.treffen><en> Divers, snorkelers and musicians dressed in whimsical nautical costumes come together every year in Florida for the Underwater Music Festival.
<G-vec00217-002-s586><come.treffen><de> Taucher, Schnorchler und Musiker treffen sich Jahr für Jahr in Florida für das Unterwasser-Musik-Festival.
<G-vec00217-002-s587><come.treffen><en> The event aims to create a space in which different voices come together to start dialogue and find solutions and answers to the social, emotional and health problems that women face in today's society. The Forum is an open event, free of charge, with an open debate on women's issues.
<G-vec00217-002-s587><come.treffen><de> Mit diesem Forum will versucht werden ein Raum zu schaffen, in welchem sich verschiedene Stimmen treffen, unterschiedliche Meinungen ausgetauscht werden um so einen Dialog anzuregen und Lösungen und Antworten auf die soziale, emotionale und gesundheitliche Problematik zu finden, mit welcher sich die Frau tagtäglich in der Gesellschaft konfrontiert sieht.
<G-vec00217-002-s588><come.treffen><en> In the living room, family and friends come together for mutual hours.
<G-vec00217-002-s588><come.treffen><de> Im Wohnzimmer treffen sich Familie und Freunde für gemeinsame Stunden.
<G-vec00217-002-s589><come.treten><en> Also the cooperation with students regarding bachelor’s and master’s theses as well as compulsory internships, new findings come to light that are included in further product development.
<G-vec00217-002-s589><come.treten><de> Auch bei der Zusammenarbeit mit Studierenden in Hinblick auf Bachelor- und Masterarbeiten sowie Pflichtpraktika treten regelmäßig neue Erkenntnisse zu Tage, die in die weitere Produktentwicklung miteinfließen.
<G-vec00217-002-s590><come.treten><en> Lung cancer typically develops slowly and symptoms often come on gradually.
<G-vec00217-002-s590><come.treten><de> Lungenkrebs entwickelt sich gewöhnlich langsam und die Symptome treten oft schrittweise auf.
<G-vec00217-002-s591><come.treten><en> They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.
<G-vec00217-002-s591><come.treten><de> Und sie sollen hineingehen in mein Heiligtum und vor meinen Tisch treten, mir zu dienen und meine Sitten zu halten.
<G-vec00217-002-s592><come.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which lie outside the area of responsibility of the author, a liability obligation would come into force only in the case in which the contents are aware and technically possible and reasonable, the Use in case of illegal content.
<G-vec00217-002-s592><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s593><come.treten><en> In the case of direct or indirect references to third-party websites ("hyperlinks"), which are outside the responsibility of the author, a liability obligation would only come into force in the case in which the author is aware of the contents and is technically possible and reasonable, To prevent the use in the case of unlawful content.
<G-vec00217-002-s593><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten (“Hyperlinks”), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s594><come.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which are beyond the scope of responsibility of Ryf Sports, a liability obligation would only come into effect in the case in which Ryf Sports is aware of the content and it technically possible and reasonable to prevent the use of illegal content.
<G-vec00217-002-s594><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches von Ryf Sports liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem Ryf Sports von den Inhalten Kenntnis hat und es technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s595><come.treten><en> emmerich exclusivbrillen GmbH & Co. reserves the right to amend the conditions of the present agreement in part or in full at any time and any such amendments come into force immediately following their publication on the website.
<G-vec00217-002-s595><come.treten><de> emmerich exclusivbrillen GmbH & Co.KG behält sich das Recht vor, die Bestimmungen dieses Vertrages jederzeit, ganz oder teilweise abzuändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Webseite in Kraft.
<G-vec00217-002-s596><come.treten><en> The resolutions passed at the Extraordinary General Meeting of Kaba will come into effect upon completion of the merger.
<G-vec00217-002-s596><come.treten><de> Die Beschlüsse der außerordentlichen Generalversammlung von Kaba treten mit dem Vollzug des Zusammenschlusses in Kraft.
<G-vec00217-002-s597><come.treten><en> Any provision of the Contract that expressly or by implication is intended to come into or continue in force on or after termination shall remain in full force and effect.
<G-vec00217-002-s597><come.treten><de> 8.6 Jedwede Bestimmung des Vertrags, die ausdrücklich oder stillschweigend in Kraft treten oder bei oder nach Kündigung in Kraft bleiben soll, bleibt in Kraft.
<G-vec00217-002-s600><come.treten><en> If amendments are merely insignificant, they shall come into force immediately.
<G-vec00217-002-s600><come.treten><de> Sollte es sich lediglich um unwesentliche Änderungen handeln, treten diese umgehend in Kraft.
<G-vec00217-002-s601><come.treten><en> Everybody shall come in touch with their own greatness, their own divinity.
<G-vec00217-002-s601><come.treten><de> Jeder soll vielmehr mit seiner eigenen Größe, seiner eigenen Göttlichkeit in Verbindung treten.
<G-vec00217-002-s602><come.treten><en> All direct or indirect references to other Internet sites (links), which lie outside the area of responsibility of the author, any liability obligation would only come into effect if the author is aware of the contents, and it would be technically possible and reasonable for him to prevent the use in the event of illegal contents.
<G-vec00217-002-s602><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s603><come.treten><en> Straight line projection of the zone upwards indicates that it will come to surface (likely under till cover) very near the north boundary of the Burns Block.
<G-vec00217-002-s603><come.treten><de> Die geradlinige Weiterführung der Zone nach oben weist darauf hin, dass sie sehr nahe an der nördlichen Grenze des Burns Blocks zu Tage treten wird (wahrscheinlich unterhalb einer Geschiebemergelschicht).
<G-vec00217-002-s604><come.treten><en> The changed terms and conditions come in the place of the previous version of the General Terms and Conditions.
<G-vec00217-002-s604><come.treten><de> Die geänderten Bedingungen treten an die Stelle der vorhergehenden allgemeinen Geschäftsbedingungen.
<G-vec00217-002-s605><come.treten><en> In the case of direct or indirect references to external websites („links“), which are outside the responsibility of the website operator, a liability obligation would only come into force in the case where the website operator is aware of the contents and it is technically possible for him And it would be reasonable to prevent the use of illegal contents.
<G-vec00217-002-s605><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s607><come.treten><en> The new prices will come into force from the announcement of the regulation. The cost of transport and other expenses are calculated separately.
<G-vec00217-002-s607><come.treten><de> Die neuen Preise treten mit der Bekanntgabe der Verordnung in Kraft, die Kosten für Transport und Sonstiges werden gesondert berechnet.
<G-vec00217-002-s627><come.verfügen><en> The rooms, suites and apartments at Garni Anni come with a balcony with mountain views and a bathroom with shower or bath.
<G-vec00217-002-s627><come.verfügen><de> Die Zimmer, Suiten und Apartments im Garni Anni verfügen über einen Balkon mit Bergblick und ein Badezimmer mit einer Dusche oder Badewanne.
<G-vec00217-002-s628><come.verfügen><en> All of our products come with a 100 percent guarantee of customer satisfaction.
<G-vec00217-002-s628><come.verfügen><de> Alle unsere Produkte verfügen über eine 100-prozentige Garantie der Zufriedenheit unserer Kunden.
<G-vec00217-002-s629><come.verfügen><en> Rooms come with flat-screen TVs and tea/coffee making facilities.
<G-vec00217-002-s629><come.verfügen><de> Die Zimmer verfügen über einen Flachbild-TV sowie Tee- und Kaffeezubehör.
<G-vec00217-002-s630><come.verfügen><en> The welcoming rooms come with a bathroom with a hairdryer, a direct dial telephone, a hire safe and a minibar.
<G-vec00217-002-s630><come.verfügen><de> Die freundlich eingerichteten Zimmer verfügen über Bad/WC, Haartrockner, Minibar, Mietsafe und Direktwahltelefon.
<G-vec00217-002-s631><come.verfügen><en> Rooms at Sheraton Sopot come with air conditioning and a flat-screen satellite TV.
<G-vec00217-002-s631><come.verfügen><de> Die Zimmer im Sheraton Colonia Golf And Spa Resort verfügen über eine Minibar, einen TV und ein eigenes Bad.
<G-vec00217-002-s632><come.verfügen><en> All these pickups come with 25K pots, stereo jack, battery clip and other mounting hardware.
<G-vec00217-002-s632><come.verfügen><de> Alle AHB-1 Tonabnehmer verfügen über 25K Töpfe, Klinkenstecker, Batterie-Clip und andere Montage-Hardware.
<G-vec00217-002-s633><come.verfügen><en> Divná pani Luxury Gallery Rooms provides certain rooms with garden views, and all rooms come with a private bathroom.
<G-vec00217-002-s633><come.verfügen><de> Das Divná pani Luxury Gallery Rooms bietet Zimmer mit Gartenblick und alle Zimmer verfügen über ein eigenes Bad.
<G-vec00217-002-s634><come.verfügen><en> All units come with a terrace, a kitchenette with a fridge, and a private bathroom with bath or shower.
<G-vec00217-002-s634><come.verfügen><de> Die modernen Zimmer verfügen über Holzböden, Kabel/Sat-TV, einen Wasserkocher sowie ein eigenes Bad mit einer Warmwasserdusche.
<G-vec00217-002-s635><come.verfügen><en> They come with a microwave, an electric kettle and a fridge as well as bathrooms with a shower, a spa bathtub and dressing gowns.
<G-vec00217-002-s635><come.verfügen><de> Sie verfügen über eine Mikrowelle, einen Wasserkocher und eine Kaffee-/Teemaschine sowie über private Badezimmer mit einer Dusche, einem Jacuzzi und kostenlosen Pflegeprodukten.
<G-vec00217-002-s636><come.verfügen><en> The rooms come with a private or shared bathroom.
<G-vec00217-002-s636><come.verfügen><de> Alle Zimmer verfügen über ein eigenes Bad oder bieten Zugang zu einem Gemeinschaftsbad.
<G-vec00217-002-s637><come.verfügen><en> Thus they are virtually maintenance-free, very rarely prone to malfunctions, require no lubricants, may be positioned exactly, have a constant stroke speed, and come with a mechanical self-locking mechanism.
<G-vec00217-002-s637><come.verfügen><de> So sind sie nahezu wartungsfrei, wenig fehleranfällig, schmiermittelfrei, exakt positionierbar und verfügen über eine konstante Hubgeschwindigkeit sowie über eine mechanische Selbsthemmung.
<G-vec00217-002-s638><come.verfügen><en> All units come with a patio, a kitchen with an oven and a microwave, and a private bathroom with bidet.
<G-vec00217-002-s638><come.verfügen><de> Alle Unterkünfte verfügen über eine Terrasse, eine Küche mit einem Backofen und einer Mikrowelle sowie ein eigenes Bad mit einem Bidet.
<G-vec00217-002-s639><come.verfügen><en> Bathrooms come with a shower, complimentary toiletries and towels.
<G-vec00217-002-s639><come.verfügen><de> Badezimmer verfügen über eine Dusche, einen Fön und Handtücher.
<G-vec00217-002-s640><come.verfügen><en> All rooms at the Cinco Calderas come with en suite bathroom complete with amenities.
<G-vec00217-002-s640><come.verfügen><de> Alle Zimmer im Cinco Calderas verfügen über ein eigenes Bad mit Pflegeprodukten.
<G-vec00217-002-s641><come.verfügen><en> rooms at the Linne come with satellite TV, tea/coffee facilities and a private bathroom with a shower.
<G-vec00217-002-s641><come.verfügen><de> Die hellen Zimmer im Linne verfügen über Sat-TV, Kaffee- und Teezubehör sowie ein eigenes Bad mit einer Dusche.
<G-vec00217-002-s642><come.verfügen><en> Featuring a balcony with outdoor furniture, the bright apartments come with tiled floors and a kitchenette.
<G-vec00217-002-s642><come.verfügen><de> Die hellen Apartments verfügen über einen Balkon mit Gartenmöbeln sowie Fliesenböden und eine Küchenzeile.
<G-vec00217-002-s643><come.verfügen><en> All wooden furnished, rooms here come with Satellite television, a fan, and a desk.
<G-vec00217-002-s643><come.verfügen><de> Alle mit Holz eingerichteten Zimmer verfügen über Sat-TV, einen Ventilator und einen Schreibtisch.
<G-vec00217-002-s644><come.verfügen><en> The non-smoking apartments and studios at the Cathedral all come with a private bathroom with a shower or a bathtub, a fully equipped kitchenette, and a satellite TV.
<G-vec00217-002-s644><come.verfügen><de> Die rauchfreien Apartments und Studios im Cathedral verfügen alle über ein eigenes Bad mit einer Dusche oder einer Badewanne, eine komplett ausgestattete Küchenzeile und Sat-TV.
<G-vec00217-002-s645><come.verfügen><en> Newer DVD players often come with a high definition upconversion feature as well.
<G-vec00217-002-s645><come.verfügen><de> Neuere DVD-Player verfügen häufig auch über eine Funktion zur Konvertierung in High Definition.
<G-vec00218-002-s133><come.gehen><en> There are breathtaking film sets where visitors can come into close contact with the jaws of a great white shark, look underneath Marilyn Monroe's skirt or learn about fear at Jurassic Park.
<G-vec00218-002-s133><come.gehen><de> In atemberaubenden Filmkulissen können Besucher auf Tuchfühlung mit dem weißen Hai gehen, Marilyn Monroe unter den Rock schauen oder im Jurassic Park das Fürchten lernen.
<G-vec00218-002-s134><come.gehen><en> 44:25 And they shall come at no dead person to become unclean; but for father, or for mother, or for son, or for daughter, for brother, or for sister that hath had no husband, they may become unclean.
<G-vec00218-002-s134><come.gehen><de> 44:25 Und keiner soll zu dem Leichnam eines Menschen gehen, daß er unrein werde; nur allein wegen Vater und Mutter, und wegen Sohn und Tochter, wegen eines Bruders und wegen einer Schwester, die keines Mannes gewesen ist, dürfen sie sich verunreinigen.
<G-vec00218-002-s135><come.gehen><en> This is where interfaces and the single responsibility principle can come to work hand in hand.
<G-vec00218-002-s135><come.gehen><de> Hier können Schnittstellen und das Prinzip der einheitlichen Verantwortung Hand in Hand gehen.
<G-vec00218-002-s136><come.gehen><en> May your dream will come true this year.
<G-vec00218-002-s136><come.gehen><de> Möge Eure Wünsche auch in diesem Jahr in Erfüllung gehen.
<G-vec00218-002-s137><come.gehen><en> I hope you have a wonderful new year, and all your dreams and wished come true next year.
<G-vec00218-002-s137><come.gehen><de> Ich hoffe ihr habt ein wunderschönes neues Jahr und all eure Wünsche und Träume gehen dieses Jahr in Erfüllung.
<G-vec00218-002-s138><come.gehen><en> Sport has always played an important role in my life, in part because I come from a family of athletes.
<G-vec00218-002-s138><come.gehen><de> Auch Sport spielte schon immer eine wichtige Rolle in meinem Leben, egal ob Fußball spielen mit meinen Freunden oder einfach im Morgengrauen joggen gehen.
<G-vec00218-002-s139><come.gehen><en> Bishops should encourage priests to come to Medjugorje, to Our Lady's school.
<G-vec00218-002-s139><come.gehen><de> Die Bischöfe sollten die Menschen ermutigen, nach Medjugorje zu gehen, in die Schule der Muttergottes.
<G-vec00218-002-s140><come.gehen><en> 29 Let no evil talk come out of your mouths, but only what is useful for building up, as there is need, so that your words may give grace to those who hear.
<G-vec00218-002-s140><come.gehen><de> 29 Lasset kein faul Geschwätz aus eurem Munde gehen, sondern was nützlich zur Besserung ist, wo es not tut, daß es holdselig sei zu hören.
<G-vec00218-002-s141><come.gehen><en> It's just necessary to come to a doctor and pick up that medicine, which, according to the dose and type of hormone, will suit you.
<G-vec00218-002-s141><come.gehen><de> Es ist nur notwendig, zu einem Arzt zu gehen und die Medizin zu holen, die je nach Dosis und Art des Hormons zu Ihnen passt.
<G-vec00218-002-s142><come.gehen><en> Numerous performers, musicians, actors and entertainers come out onto the streets, and the entire city operates as a public space for the presentation of Croatian tradition.
<G-vec00218-002-s142><come.gehen><de> Viele Darsteller, Musiker, Performance-Künstler, Schauspieler und Unterhalter gehen auf die Straßen, während die ganze Stadt den Eindruck erweckt, ein öffentlicher Raum für die Vorstellung der kroatischen Tradition zu sein.
<G-vec00218-002-s143><come.gehen><en> The gift certificates of Ferienart Resort & Spa are always welcome and make small and bigger dreams come true.
<G-vec00218-002-s143><come.gehen><de> Die Geschenkgutscheine des Ferienart Resort & Spa sind immer willkommen und lassen kleine und größere Wünsche in Erfüllung gehen.
<G-vec00218-002-s144><come.gehen><en> But these privileges also come with duties.
<G-vec00218-002-s144><come.gehen><de> Diese Privilegien gehen jedoch mit Pflichten einher.
<G-vec00218-002-s145><come.gehen><en> They remind you that difficult moments and things that come to an end are signs of something beautiful and new that will soon arise.
<G-vec00218-002-s145><come.gehen><de> Sie erinnern daran, dass schwierige Momente und Dinge, die zu Ende gehen, Zeichen von etwas Schönem und Neuem sind, das bald auftauchen wird.
<G-vec00218-002-s146><come.gehen><en> Who listens to me, he has won much, because what I promise a man will indeed come true.
<G-vec00218-002-s146><come.gehen><de> Wer Mich anhöret, der hat viel gewonnen, denn was Ich einem Menschen verspreche, wird wahrlich in Erfüllung gehen.
<G-vec00218-002-s147><come.gehen><en> Thus, you will never come up empty and your apartment is always visitors fit, no matter what happens.
<G-vec00218-002-s147><come.gehen><de> Somit gehen Sie nie leer aus und Ihre Wohnung ist immer besuchertauglich, egal was auch passiert.
<G-vec00218-002-s148><come.gehen><en> Legend has it that if you want something while you ring the church bell, your wish might come true.
<G-vec00218-002-s148><come.gehen><de> Die Legende besagt es, wenn Sie etwas wünschen, während Sie die Kirchenglocke läuten, könnte Ihr Wunsch in Erfüllung gehen.
<G-vec00218-002-s149><come.gehen><en> 20 And now you will be silent and not able to speak until the day this happens, because you did not believe my words, which will come true at their appointed time.” (Luke 1:13-20)
<G-vec00218-002-s149><come.gehen><de> 1:20 Aber weil du meinen Worten nicht geglaubt hast, die in Erfüllung gehen, wenn die Zeit dafür da ist, sollst du stumm sein und nicht mehr reden können bis zu dem Tag, an dem all das eintrifft.
<G-vec00218-002-s150><come.gehen><en> They pleaded with me not to come.
<G-vec00218-002-s150><come.gehen><de> Sie haben auf mich eingeredet, nicht zu gehen.
<G-vec00218-002-s151><come.gehen><en> Because every Theum virtual expert knows about the others, users can query across them transparently and in parallel as new ones come online—without having to know where to look.
<G-vec00218-002-s151><come.gehen><de> Weil jeder virtuelle Experte von Theum jeden anderen „kennt“, können Anwender Abfragen über alle virtuellen Experten hinweg transparent und parallel ausführen, sobald neue virtuellen Experten online gehen – ohne deren Adresse zu kennen.
<G-vec00516-002-s190><come.geben><en> Surf boots come in different thicknesses such as 0.5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm or even 7 mm thick.
<G-vec00516-002-s190><come.geben><de> Surfschuhe gibt es in verschiedenen Stärken wie 0,5 mm, 1 mm, 2 mm, 3 mm, 5 mm, 6 mm oder sogar 7 mm.
<G-vec00516-002-s191><come.geben><en> Chatbots come in different shapes and forms.
<G-vec00516-002-s191><come.geben><de> Chatbots gibt es in verschiedenen Formen und Arten.
<G-vec00516-002-s192><come.geben><en> Beacons come in all kinds of different formats, are scalable and highly portable. Benefits:
<G-vec00516-002-s192><come.geben><de> Beacons gibt es in den unterschiedlichsten Formen, sie sind skalierbar und sehr portabel.
<G-vec00516-002-s193><come.geben><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Wiko Sunny You'll never have to buy another screen protector for the life of your phone with the Olixar 2-in-1 screen protector pack
<G-vec00516-002-s193><come.geben><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Galaxy A5 2017 haben.
<G-vec00516-002-s194><come.geben><en> The Nucleus 6 sound processors come in a variety of colours designed to blend in with hair and skin tones.
<G-vec00516-002-s194><come.geben><de> Den Nucleus 6 Soundprozessor gibt es in verschiedenen Farbtönen, die zu Haut- und Haarfarben passen.
<G-vec00516-002-s195><come.geben><en> Olixar screen protectors now come in packs of 2, so you've got 2 times the protection for your Huawei P8 Lite.
<G-vec00516-002-s195><come.geben><de> Olixar Displayschutzfolien gibt es in zwei Packungen, so dass Sie 2 mal den Schutz für Ihr Samsung Gear S3 Smartwatch haben.
<G-vec00516-002-s196><come.geben><en> PCs come in all shapes and sizes, and the exact same tweaks might have different effects on different PC setups.
<G-vec00516-002-s196><come.geben><de> PCs gibt es in allen Farben und Formen, und exakt gleiche Anpassungen können verschiedene Auswirkungen auf verschiedenen PCs haben.
<G-vec00516-002-s197><come.geben><en> These garments come in a wide variety of styles: Tops which create a wasp waist under A-line dresses, high-waisted panties which optimally slim the stomach, upper thighs and bottom for skinny trousers, and undergarments which form a slim silhouette from chest to knee under tight-fitting knitted dresses.
<G-vec00516-002-s197><come.geben><de> Die Formwäsche gibt es in den unterschiedlichsten Varianten: Tops, die eine Wespentaille unter A-Linien-Kleider zaubern, Highwaist-Panties, die Bauch, Oberschenkel und Po optimal für Skinny Hosen schmälern, und Unterkleider, die von Brust bis Knie eine schlanke Silhouette unter anliegenden Strickkleidern formen.
<G-vec00516-002-s198><come.geben><en> Progressive Slots come in all shapes and sizes in the world of Online Gambling.
<G-vec00516-002-s198><come.geben><de> Progressive Slots Gibt es in allen Formen und Größen in der Welt der Online-Glücksspiel.
<G-vec00516-002-s199><come.geben><en> Cap constructions come in many shapes and sizes.
<G-vec00516-002-s199><come.geben><de> Diese Kappenkonstruktionen gibt es in vielen Formen und Größen.
<G-vec00516-002-s200><come.geben><en> Short-term trades come in three varieties, the typical 60 second options and the newest addition called the 2 and 5-minute expiries.
<G-vec00516-002-s200><come.geben><de> Kurzfristige Trades gibt es in drei Sorten, die typischen 60 Sekunden Optionen und die neueste Ergänzung genannt die 2 und 5-Minuten-Abläufe.
<G-vec00516-002-s201><come.geben><en> Lens filters generally come in two varieties: screw-on and front filters.
<G-vec00516-002-s201><come.geben><de> In der Regel gibt es Linsenfilter in zwei Varianten: Anschraub- und Frontfilter.
<G-vec00516-002-s202><come.geben><en> Nacho trays come in black / large with 2 cups for nachos...
<G-vec00516-002-s202><come.geben><de> Nachoschalen gibt es in der Ausführung schwarz / groß mit...
<G-vec00516-002-s203><come.geben><en> Coins come in 50 øre as well as 1, 2, 5, 10 and 20 Kroner.
<G-vec00516-002-s203><come.geben><de> Münzen gibt es in 50 Öre sowie 1, 2, 5, 10 und 20 Kronen.
<G-vec00516-002-s204><come.geben><en> All three series come with matching leggings, which are not a only a sexy accessory for the beach, but also the perfect garment for any type of beach activity – from beach volleyball to yoga workouts.
<G-vec00516-002-s204><come.geben><de> Zu allen drei Serien gibt es die passende Hose im Leggins-Style, die nicht nur ein sexy Strand-Accessoire ist, sondern auch der ideale Begleiter für jede Form von Strandaktivität – von Beachvolleyball bis zum Yoga-Workout.
<G-vec00516-002-s205><come.geben><en> Themes come in many different shapes, from blank themes with only the bare necessities, to more advanced themes with tons of features.
<G-vec00516-002-s205><come.geben><de> Themes gibt es in vielen verschiedenen Formen, von leeren Themes mit nur dem Nötigsten bis hin zu fortgeschritteneren Themes mit unzähligen Funktionen.
<G-vec00516-002-s206><come.geben><en> Heart rate monitors come in a variety of different models, with varying levels of functionality.
<G-vec00516-002-s206><come.geben><de> Herzfrequenzmesser gibt es in verschiedenen Modellen mit unterschiedlichen Funktionen.
<G-vec00516-002-s208><come.geben><en> Hotels in Germany come in all price ranges and equipments.
<G-vec00516-002-s208><come.geben><de> Hotels in Deutschland gibt es in allen Preisklassen und Ausstattungen.
<G-vec00516-002-s209><come.haben><en> The girl's shorts come with a textile side stripe and ensure freedom of movement thanks to the supple viscose material - perfect companions for the next summer!
<G-vec00516-002-s209><come.haben><de> Die Mädchen Shorts haben seitlich einen farblich passenden Besatz und machen aufgrund der angenehmen Viskose-Qualität jede Bewegung mit – ein toller Begleiter für den nächsten Sommer.
<G-vec00516-002-s210><come.haben><en> They come with a black leather upper and a removable insole for hygiene and practicality.
<G-vec00516-002-s210><come.haben><de> Sie haben ein Obermaterial aus schwarzem Leder und eine hygienische und praktische herausnehmbare sohle.
<G-vec00516-002-s211><come.haben><en> Come and find our new presentation of the wonderful smelling incense sticks from Paris in our store in the Belgian quarter in Cologne.
<G-vec00516-002-s211><come.haben><de> Wir haben Parfums, Keramik, Räucherstäbchen, Duftkerzen und Papeterie bei uns im Store in Köln.
<G-vec00516-002-s212><come.haben><en> Passengers really do come first here! Travel in the VIP seats above the driver's cab on the GoldenPass SuperPanoramic train from Montreux to Zweisimmen, and you'll feel like you are flying!
<G-vec00516-002-s212><come.haben><de> Hier haben Passagiere die Nase vorn: Wer im GoldenPass SuperPanoramic von Montreux nach Zweisimmen die VIP-Plätze bucht, hat das Gefühl zu fliegen, denn sie befinden sich hoch über dem Führerstand ganz vorne im Zug.
<G-vec00516-002-s213><come.haben><en> © direktbroker-FX, Alle wing: CFDs are complex instruments and come with a high risk of losing money rapidly due to leverage.
<G-vec00516-002-s213><come.haben><de> Adresse: direktbroker.de AG, Risikohinweis: CFDs sind komplexe Instrumente und haben ein hohes Risiko, durch Hebelwirkung schnell Geld zu verlieren.
<G-vec00516-002-s214><come.haben><en> It is not clear why the ESM or this debt repayment fund should come up with any different results – they are in effect the same.
<G-vec00516-002-s214><come.haben><de> Es ist nicht ersichtlich, warum ESM und dieser Schuldentilgungsfonds verschiedene Ergebnisse haben sollten – sie entsprechen einander.
<G-vec00516-002-s215><come.haben><en> And because Mac, iPhone, iPad and iPod touch all come equipped with FaceTime, you can talk to iOS and macOS users across the street or across the globe.
<G-vec00516-002-s215><come.haben><de> Und weil Mac, iPhone, iPad und iPod touch alle FaceTime haben, kannst du überall mit Benutzern von iOS und macOS sprechen.
<G-vec00516-002-s216><come.haben><en> The bathrooms come with a bathtub, a shower and free toiletries for more comfort.
<G-vec00516-002-s216><come.haben><de> Die Badezimmer haben eine Badewanne, eine Dusche und kostenlose Pflegeprodukte für mehr Komfort.
<G-vec00516-002-s217><come.haben><en> Some hotel rooms come with a wonderful view over the city.
<G-vec00516-002-s217><come.haben><de> Gäste haben die Möglichkeit, einen wunderbaren Blick auf den Hafen zu bewundern.
<G-vec00516-002-s218><come.haben><en> The expensive models come with a built-in sensor that lets the drone steer clear of large and small objects.
<G-vec00516-002-s218><come.haben><de> De kostspieligeren Modelle haben einen eingebauten Sensor, der die Drohnen um große Gegenstände herum steuern lässt.
<G-vec00516-002-s219><come.haben><en> The luxury rooms are 40 m², and all come with balconies and terraces with a pool, sea or garden view.
<G-vec00516-002-s219><come.haben><de> Die Luxuszimmer sind 40 qm groß und haben Balkon oder Terrasse mit Ausblick auf den Pool, das Meer oder den Garten.
<G-vec00516-002-s220><come.haben><en> Most units come with a balcony.
<G-vec00516-002-s220><come.haben><de> Die meisten Unterkünfte haben einen Balkon.
<G-vec00516-002-s221><come.haben><en> The truth is, I think, that Patrick wants to put a girl in his park who looks like the girls in his magazine, which only proves once again his remote controlled nature, and there’s more to come, because Patrick wants a girl to make him come who is sexually competent but has never had sex and this, I think, is where Patrick’s remote-controlled nature reaches its limitlessly stupid climax.
<G-vec00516-002-s221><come.haben><de> Tatsächlich, denke ich weiter, will Patrick sich ein Mädchen in sein Gehege stellen, das so aussieht wie die Mädchen aus seinem Magazin, was sein Ferngesteuertsein einmal mehr auf den Punkt bringt und es erreicht noch seinen unglaublichen Höhepunkt, denn seinen Höhepunkt, denke ich, will Patrick von einem Mädchen verschafft haben, das sexuell kompetent ist, aber noch nie Sex hatte und an dieser Stelle, denke ich, erreicht Patricks Ferngesteuertsein in seiner ganzen unbegrenzten Dummheit seinen Höhepunkt.
<G-vec00516-002-s222><come.haben><en> The right images on the web may come with copyright restrictions.
<G-vec00516-002-s222><come.haben><de> Die richtigen Bilder im Web haben möglicherweise Copyright Beschränkungen.
<G-vec00516-002-s223><come.haben><en> Both of them come with a Full HD display, but only the HP comes with a contrast-rich IPS panel with wide viewing angles.
<G-vec00516-002-s223><come.haben><de> Beide haben eine Full-HD-Anzeige, doch nur HP setzt auf ein blickwinkelstabiles und kontraststarkes IPS-Panel.
<G-vec00516-002-s224><come.haben><en> There is a statement in the "Remarks" to the effect that society is not powerless against the laws of science, that man, having come to know economic laws, can utilize them in the interests of society.
<G-vec00516-002-s224><come.haben><de> In den „Bemerkungen“ ist der bekannte Leitsatz enthalten, dass die Gesellschaft den Gesetzen der Wissenschaft gegenüber nicht machtlos ist, dass die Menschen, wenn sie die ökonomischen Gesetze erkannt haben, dieselben im Interesse der Gesellschaft ausnutzen können.
<G-vec00516-002-s225><come.haben><en> The rooms come with en suite bathrooms featuring a shower, a hairdryer and complimentary toiletries.
<G-vec00516-002-s225><come.haben><de> Die Zimmer haben einen modernen Dekor und En-suite-Badezimmer mit einer Dusche, Morgenmänteln und einem Fön.
<G-vec00516-002-s226><come.haben><en> 2014 will be a crucial year in deciding who will come out ahead in future years.
<G-vec00516-002-s226><come.haben><de> 2014 entscheidet sich, wer in den kommenden Jahren die Nase vorn haben wird.
<G-vec00516-002-s227><come.haben><en> Most models come with three or four shelves; exceptions to this are the double door freezer and double door bakery freezer.
<G-vec00516-002-s227><come.haben><de> Die meisten Gefrierschränke haben drei oder vier Fächer; eine Ausnahme stellen hier der zweitürige Gefrierschrank sowie der zweitürige Bäckerei-Gefrierschrank dar.
<G-vec00516-002-s456><come.sein><en> Biofuel can come in solid, liquid, or gaseous form.
<G-vec00516-002-s456><come.sein><de> Biobrennstoffe können fester, flüssiger oder gasförmiger Natur sein.
<G-vec00516-002-s457><come.sein><en> It is very common for such potentially unwanted applications to come bundled with freeware and adware.
<G-vec00516-002-s457><come.sein><de> Es ist durchaus üblich, dass solche potenziell unerwünschten Anwendungen mit Freeware und Adware gebündelt sein.
<G-vec00516-002-s458><come.sein><en> 13 And seeing a fig-tree afar off, having leaves, he came, if haply he might find any thing on it: and when he came to it, he found nothing but leaves: for the time of figs had not yet come.
<G-vec00516-002-s458><come.sein><de> 13 Und er sah einen Feigenbaum von ferne, der Blätter hatte; da trat er hinzu, ob er etwas darauf fände, und da er hinzukam, fand er nichts denn nur Blätter, denn es war noch nicht Zeit, daß Feigen sein sollten.
<G-vec00516-002-s459><come.sein><en> The end of the Italian Grand Prix also marked the end of an epoch: After 16 years, Formel Schumi should come to an end for the time being, the end of the season also meaning the end of an era for Ferrari, the most successful epoch a Formula 1 driver ever had together with his team.
<G-vec00516-002-s459><come.sein><de> Dass Ende des Großen Preises von Italien markiert auch das rasende Ende einer Epoche: Nach 16 Jahren soll vorerst Schluss sein mit der Formel Schumi, geht zum Saisonende auch eine Zeitrechnung von Ferrari zu Ende, die erfolgreichste Epoche, die je ein Formel-1-Fahrer mit seinem Team hatte.
<G-vec00516-002-s460><come.sein><en> The embossed wax must come from organic farming.
<G-vec00516-002-s460><come.sein><de> Das Imprägnierwachs muss aus kontrolliert biologischem Anbau sein.
<G-vec00516-002-s461><come.sein><en> Therefore, it should come as no surprise that the background of the game shows a vast, barren landscape.
<G-vec00516-002-s461><come.sein><de> Daher sollte es keine Überraschung sein, dass der Hintergrund des Spiels eine weite, öde Landschaft zeigt.
<G-vec00516-002-s462><come.sein><en> Another example when the “nofollow" attribute can come handy are widget links.
<G-vec00516-002-s462><come.sein><de> Ein weiteres Beispiel für einen Fall, in dem das Attribut "nofollow" praktisch sein kann, sind Widget-Links.
<G-vec00516-002-s463><come.sein><en> 13:14 And it shall come to pass, that as the chased roe, and as sheep that no man gathereth, they shall turn every man to his own people, and shall flee every man to his own land.
<G-vec00516-002-s463><come.sein><de> 13:14 Und es wird wie mit einer verscheuchten Gazelle sein und wie mit einer Herde, die niemand sammelt: jeder wird sich zu seinem Volk wenden und jeder in sein Land fliehen.
<G-vec00516-002-s464><come.sein><en> Today the rule is: anyone can come in who earns their living in the sports business and who has a relevant business relationship with at least one of the exhibitors.
<G-vec00516-002-s464><come.sein><de> Heute gilt: Zugelassen ist, wer sein Geld im Sport Business verdient und mit mindestens einem Aussteller eine einschlägige Geschäftsbeziehung hat.
<G-vec00516-002-s465><come.sein><en> The Ability quickly to tie around the waist can come in handy always.
<G-vec00516-002-s465><come.sein><de> Die Fähigkeit, schnell binden Sie sich um die eigene Taille kann immer nützlich sein.
<G-vec00516-002-s466><come.sein><en> Its Facebook messenger block feature can come in handy for the parents to ensure that their kids don’t engage in inappropriate activities.
<G-vec00516-002-s466><come.sein><de> Die Facebook-Messenger-Block -Funktion kann für die Eltern nützlich sein, um sicherzustellen, dass ihre Kinder keine unangemessenen Aktivitäten ausführen.
<G-vec00516-002-s467><come.sein><en> INTRODUCTION Jesus tells us: “Whoever wishes to come after me must deny himself, take up his cross each day and follow me”. This is an invitation addressed to everyone: to those who are married and those who are single, to young people, adults and the elderly, to the rich and poor, and to people of every nationality.
<G-vec00516-002-s467><come.sein><de> EINFÜHRUNG Jesus sagt: „Wer mein Jünger sein will, der verleugne sich selbst, nehme täglich sein Kreuz auf sich und folge mir nach.“ Das ist eine Aufforderung, die allen gilt, Ledigen und Verheirateten, Jugendlichen, Erwachsenen und alten Menschen, Reichen und Armen, Menschen aller Nationalitäten.
<G-vec00516-002-s468><come.sein><en> The LTE and 3G model should come out by the end of November.
<G-vec00516-002-s468><come.sein><de> Die Version mit LTE- und 3G-fähigem Mobilfunkmodul soll bis Ende November lieferbar sein.
<G-vec00516-002-s469><come.sein><en> And we though thought that we must had come decent far.
<G-vec00516-002-s469><come.sein><de> Und wir meinten schon, dass wir ganz ordentlich vorangekommen sein muessten.
<G-vec00516-002-s470><come.sein><en> You’ll come to your own conclusions.
<G-vec00516-002-s470><come.sein><de> Sie werden dann in der Lage sein, eigene Schlüsse zu ziehen.
<G-vec00516-002-s471><come.sein><en> When making a green smoothie I can rest assure it’ll come out silky smooth, every time.
<G-vec00516-002-s471><come.sein><de> Wenn ich grüne Smoothies herstelle, dann kann ich mir sicher sein, dass jedes Mal ein seidig weicher flüssiger Smoothie entsteht.
<G-vec00516-002-s472><come.sein><en> 8 And David saith on that day, 'Any one smiting the Jebusite, (let him go up by the watercourse), and the lame and the blind -- the hated of David's soul,' -- because the blind and lame say, 'He doth not come into the house.'
<G-vec00516-002-s472><come.sein><de> 8Da sprach David an diesem Tage: Wer die Jebusiter schlägt und durch den Schacht hinaufsteigt und die Lahmen und Blinden erschlägt, die David verhasst sind, der soll Hauptmann und Oberster sein.
<G-vec00516-002-s473><come.sein><en> At the same time, there is debate as to whether tighter capital requirements could come with a longer-term cost for the real economy.
<G-vec00516-002-s473><come.sein><de> Gleichzeitig gibt es eine Debatte darüber, ob höhere Kapitalanforderungen mit längerfristigen Kosten für die Realwirtschaft verbunden sein könnten.
<G-vec00516-002-s474><come.sein><en> As the oil acts on the sensitive oral mucosa for 10 to 20 minutes, the oil seeds and nuts should come from certified organic farming.
<G-vec00516-002-s474><come.sein><de> Da das Öl 10 bis 20 Minuten auf die empfindliche Mundschleimhaut einwirkt, sollte die Auswahl eines dafür bevorzugten Öles unbedingt auf Bio-Pflanzenöle ausgerichtet sein, die aus Ölsaaten und Nüssen aus kontrolliert biologischem Anbau und kalt gepresst werden.
<G-vec00516-002-s665><come.werden><en> These working groups are thematically orientated towards those future technologies that are relevant for the future of German industry and that the startups are active in: materials technologies, pharma, biotechnology and genetic technology, medical technology, energy technologies, digital business models/smart services and Industry 4.0 as well as integrated mobility (with more to come).
<G-vec00516-002-s665><come.werden><de> Die Arbeitsgruppen orientieren sich dabei thematisch an den für die Zukunft der deutschen Industrie relevanten Zukunftstechnologien, in denen die Startups aktiv sind: Materialtechnologien, integrierte Mobilität (die Liste wird schrittweise erweitert).
<G-vec00516-002-s666><come.werden><en> Come and see the ice kingdom at night when the spotlights light up the ice.
<G-vec00516-002-s666><come.werden><de> Besonders faszinierend – das Eiskönigreich in der Nacht, wenn es von Scheinwerfern angeleuchtet wird.
<G-vec00516-002-s667><come.werden><en> First, take the time to visit the Roman ruins on the Sirmione peninsula, a touristy and lively little town located on a promontory surrounded by water, where the singer Maria Callas liked to come to relax.
<G-vec00516-002-s667><come.werden><de> Nehmen Sie sich zuerst die Zeit, um die Ruinen aus römischer Zeit auf der Halbinsel Sirmione zu besuchen, einer lebendigen kleinen Stadt, die gerne von Touristen besucht wird und sich auf einem Felsen befindet, der von Wasser umgeben wird und wo die Sängerin Maria Callas sich gerne erholte.
<G-vec00516-002-s668><come.werden><en> All products in the Anal Fantasy range come with an anal pleasure preparation kit, including: 2 small finger sleeves, a desensitising anal cream, a lubricant especially designed for anal penetration as well as some sex toy cleaning fluid.
<G-vec00516-002-s668><come.werden><de> Jedes Produkt der „Anal Fantasy“ Modelle wird mit einem Sortiment zur Vorbereitung für das anale Vergnügen geliefert, einschließlich: 2 kleine Gummimanschetten für Finger, eine anale Desensibilisierungs-Creme, ein spezielles Gleitmittel für die anale Penetration und ein Sexspielzeugreiniger.
<G-vec00516-002-s669><come.werden><en> Most fitness trackers today come with a heart rate monitor built in.
<G-vec00516-002-s669><come.werden><de> Die Herzfrequenz wird bei beiden Fitness Trackern auch in gleicher Frequenz gemessen.
<G-vec00516-002-s670><come.werden><en> Should a significant deterioration in the Buyer’s financial circumstances occur or be expected to occur in future for objective reasons which does not come to our knowledge until after conclusion of the contract, we are entitled to demand cash pre-payments for future deliveries, or temporarily refuse delivery and invoice the goods on notification of readiness for shipment.
<G-vec00516-002-s670><come.werden><de> Für den Fall, dass in den Vermögensverhältnissen des Käufers eine wesentliche Verschlechterung eingetreten ist oder aufgrund objektiver Umstände für die Zukunft erwartet wird und wir hiervon erst nach dem Abschluss Kenntnis bekommen, können wir für weitere Lieferungen Vorauszahlungen in bar verlangen oder aber die Lieferungen einstweilen verweigern und die Ware bei Versandbereitschaft in Rechnung stellen.
<G-vec00516-002-s671><come.werden><en> Bass Drums are one of the most important parts of the drum kit, and come in various depths and diameters to produce different tones and pitches.
<G-vec00516-002-s671><come.werden><de> Die Bassdrum ist eines der wichtigsten Teile des Drum Kits und wird in verschiedenen Tiefen und Durchmessern produziert, sodass unterschiedliche Klänge und Tonhöhen entstehen.
<G-vec00516-002-s672><come.werden><en> Another reason is the tradition how they raise them animals, a way to come generations by generations.
<G-vec00516-002-s672><come.werden><de> Ein weiterer Grund ist die traditionelle Art der Tierzucht, die von Generation zu Generation weitergegeben wird.
<G-vec00516-002-s673><come.werden><en> It’s a holiday fantasy for parents of young football fans come true: a luxurious beach resort for them and a summer soccer camp for the kids.
<G-vec00516-002-s673><come.werden><de> Eine Urlaubsfantasie für Eltern von jungen Fußballfans wird wahr: ein luxuriöses Strandresort für sie und ein Fußball-Sommercamp für die Kids.
<G-vec00516-002-s674><come.werden><en> Binoculars come with a pouch, strap and optics cleaning cloth. The Scalpel
<G-vec00516-002-s674><come.werden><de> Das Fernglas wird mit einer Tasche, einem Riemen und einem Optikreinigungstuch geliefert.
<G-vec00516-002-s675><come.werden><en> Essential oils come from plants, while fragrance oils are usually artificially created and often contain synthetic chemicals.
<G-vec00516-002-s675><come.werden><de> Ersteres wird aus Pflanzen gewonnen, während Duftöle normalerweise künstlich hergestellt sind und häufig synthetische Chemikalien enthalten.
<G-vec00516-002-s676><come.werden><en> While Dean distracts Amara, Sam, Metatron and the Prophet Donatello Redfield come to Lucifer's rescue.
<G-vec00516-002-s676><come.werden><de> In Die Familie der Finsternis wird Luzifer von Amara durch ihre Macht gefoltert, aber er wird später von Sam, Metatron und Donatello Redfield gerettet.
<G-vec00516-002-s677><come.werden><en> The headphones come with a generous amount of accessories such as an extra pair of leatherette cushions and an airplane adapter.
<G-vec00516-002-s677><come.werden><de> Die Ausstattung wird mit dem üppigen Lieferumfang abgerundet, der ein zusätzliches Paar Velours-Ohrpolster und einen Flugzeug-Adapter beinhaltet.
<G-vec00516-002-s678><come.werden><en> Making the dream come true.
<G-vec00516-002-s678><come.werden><de> Damit der Traum wahr wird.
<G-vec00516-002-s679><come.werden><en> In the book of Galatians it happens to come under the brand name of circumcision and mosaic legalism.
<G-vec00516-002-s679><come.werden><de> Im Brief an die Galater wird das unter dem Namen „Beschneidung“ und „mosaischer Legalismus“ beschrieben.
<G-vec00516-002-s680><come.werden><en> The message that a continuation of the mission of Christianity would come can be found in Jesus’ predictions about the comforter, the holy spirit: "I have yet many things to say unto you, but ye cannot bear them now."
<G-vec00516-002-s680><come.werden><de> Die Botschaft, dass es eine Fortsetzung der Mission des Christentums geben wird, findet man in Jesu Voraussagen über den Sprecher, den Heiligen Geist: ”Ich habe euch noch Vieles zu sagen, aber ihr könnt es jetzt nicht tragen”.
<G-vec00516-002-s681><come.werden><en> The unique design and maximum functionality come together in a perfect symbiosis between the lines of the blade and the handle.
<G-vec00516-002-s681><come.werden><de> Die hochwertige Ausstrahlung des Natur-materials wird durch einen Mosaik-Pin in der Griff-mitte und die dekorative Endkappe aus Stahl zusätz-lich unterstrichen.
<G-vec00516-002-s682><come.werden><en> The new system is also significantly more energy-efficient and less labor-intensive than the previous lighting system, allowing it to inspire visitors for years to come.
<G-vec00516-002-s682><come.werden><de> Das neue System ist wesentlich energiesparender als das vorige und gleichzeitig auch weniger arbeitsintensiv – Eine Inspiration für jeden Besucher, die noch über Jahre hin faszinieren wird.
<G-vec00516-002-s683><come.werden><en> Moses said to Yahweh, ‘The people can’t come up to Mount Sinai, for you warned us, saying, “Set bounds around the mountain, and sanctify it.”’
<G-vec00516-002-s683><come.werden><de> 23 Und Mose sprach zu Jehova: Das Volk wird den Berg Sinai nicht ersteigen können; denn du hast uns ja gewarnt und gesagt: Mache eine Grenze um den Berg und heilige ihn.
<G-vec00071-002-s152><come.kommen><en> Then you have come to the right place.
<G-vec00071-002-s152><come.kommen><de> Dann sind Sie zum rechten Platz gekommen.
<G-vec00071-002-s153><come.kommen><en> You have come to the right page.
<G-vec00071-002-s153><come.kommen><de> Sie sind zur rechten Seite gekommen.
<G-vec00071-002-s154><come.kommen><en> "The hour is come that the Son of man should be glorified" (John 12:23).
<G-vec00071-002-s154><come.kommen><de> "Die Stunde ist gekommen, dass der Menschensohn verherrlicht werden sollte" (Johannes 12:23).
<G-vec00071-002-s155><come.kommen><en> The Spirit had come upon him powerfully, and he had broken down, weeping.
<G-vec00071-002-s155><come.kommen><de> Der Geist war mächtig auf ihn gekommen, und er war weinend zusammengebrochen.
<G-vec00071-002-s156><come.kommen><en> “For judgment I have come into this world, so that the blind will see and those who see will become blind.”
<G-vec00071-002-s156><come.kommen><de> 39Und Jesus sprach: Ich bin zum Gericht auf diese Welt gekommen, auf daß, die da nicht sehen, sehend werden, und die da sehen, blind werden.
<G-vec00071-002-s157><come.kommen><en> SHAKIR: Certainly a Messenger has come to you from among yourselves; grievous to him is your falling into distress, excessively solicitous respecting you; to the believers (he is) compassionate, 009.129
<G-vec00071-002-s157><come.kommen><de> Wahrlich, ein Gesandter ist zu euch gekommen aus eurer Mitte; schmerzlich ist es ihm, daß ihr in Unheil geraten solltet; eure Wohlfahrt begehrt er eifrig; gegen die Gläubigen ist er gütig, barmherzig.
<G-vec00071-002-s158><come.kommen><en> I twisted around and ran back the way I had come.
<G-vec00071-002-s158><come.kommen><de> Ich drehte mich weg und lief den Weg zurück, den wir gekommen waren.
<G-vec00071-002-s159><come.kommen><en> Make a photo of the defect and make photos that show how the product was installed and how it has come to the damage if possible.
<G-vec00071-002-s159><come.kommen><de> Fotografieren Sie den Defekt und versuchen Sie dabei, auf den Fotos deutlich zu machen, wie das Produkt eingebaut war und wie es zu dem Schaden gekommen ist.
<G-vec00071-002-s160><come.kommen><en> Gehazi answered, “Yes, but my master sent me to say, ‘Two young men who are members of a group of prophets have just now come to me from the hills of Ephraim.
<G-vec00071-002-s160><come.kommen><de> Mein Herr sendet mich und lässt sagen: Siehe, eben jetzt sind vom Gebirge Ephraim zwei junge Männer von den Söhnen der Propheten zu mir gekommen.
<G-vec00071-002-s161><come.kommen><en> 12 "But I tell you: Elijah has already come, and they didn't recognize him. On the contrary, they did whatever they pleased to him.
<G-vec00071-002-s161><come.kommen><de> 13 Aber ich sage euch, daß auch Elias gekommen ist, und sie haben ihm getan, was irgend sie wollten, so wie über ihn geschrieben steht.
<G-vec00071-002-s162><come.kommen><en> But I am sure I have always thought of Christmas-time, when it has come round—apart from the veneration due to its sacred name and origin, if anything belonging to it can be apart from that—as a good time; a kind, forgiving, charitable, pleasant time; the only time I know of, in the long calendar of the year, when men and women seem by one consent to open their shut-up hearts freely, and to think of people below them as if they really were fellow-passengers to the grave, and not another race of creatures bound on other journeys.
<G-vec00071-002-s162><come.kommen><de> Aber das weiß ich bestimmt, daß ich Weihnachten, wenn es gekommen ist, abgesehen von der Verehrung, die wir seinem heiligen Namen und Ursprung schuldig sind, immer als eine gute Zeit angeschaut habe, als eine liebe Zeit, als die Zeit der Vergebung und des Erbarmens, als die einzige Zeit, die ich im langen Kalenderjahr kenne, wo die Menschen einträchtig ihre verschlossenen Herzen auftun und die andern Menschen betrachten, als wenn sie wirklich Reisegenossen nach dem Grabe wären und nicht eine ganz andere Art von Lebewesen, die für einen ganz andern Weg vorgesehen sind.
<G-vec00071-002-s163><come.kommen><en> But I have also come to share with you the joys and hopes, efforts and commitments, ideals and aspirations of this diocesan community.
<G-vec00071-002-s163><come.kommen><de> Doch ich bin auch gekommen, um mit euch Freuden und Hoffnungen, Mühen und Anstrengungen, Ideale und Wünsche dieser Diözesangemeinschaft zu teilen.
<G-vec00071-002-s164><come.kommen><en> It’s a funny story that just goes to show how far both our businesses have come.
<G-vec00071-002-s164><come.kommen><de> Es ist eine lustige Geschichte, die zeigt, wie weit unsere beiden Unternehmen gekommen sind.
<G-vec00071-002-s165><come.kommen><en> 27She said to Him, Yes, Lord, I have believed [I do believe] that You are the Christ (the Messiah, the Anointed One), the Son of God, [even He] Who was to come into the world.
<G-vec00071-002-s165><come.kommen><de> 27Sie spricht zu ihm: HERR, ja, ich glaube, daß du bist Christus, der Sohn Gottes, der in die Welt gekommen ist.
<G-vec00071-002-s166><come.kommen><en> Acts 1, verse 8 and 9 “But you will receive power when the Holy Spirit has come upon you. You will be witnesses to me in Jerusalem, in all Judea and Samaria, and to the uttermost parts of the earth.”
<G-vec00071-002-s166><come.kommen><de> Apostelgeschichte 1, Vers 8 und 9 Aber ihr werdet Kraft empfangen, wenn der Heilige Geist auf euch gekommen ist; und ihr werdet meine Zeugen sein, sowohl in Jerusalem als auch in ganz Judäa und Samaria und bis an das Ende der Erde.
<G-vec00071-002-s167><come.kommen><en> 13Thou wilt rise up, thou wilt have mercy upon Zion: for it is the time to be gracious to her, for the set time is come. 14For thy servants take pleasure in her stones, and favour her dust.
<G-vec00071-002-s167><come.kommen><de> 13Du wirst aufstehen, wirst dich Zions erbarmen; denn es ist Zeit, es zu begnadigen, denn gekommen ist die bestimmte Zeit; 14Denn deine Knechte haben Gefallen an seinen Steinen und haben Mitleid mit seinem Schutt.
<G-vec00071-002-s168><come.kommen><en> And he said, No; but I have come as captain of the armies of the Lord.
<G-vec00071-002-s168><come.kommen><de> Er sprach: Nein, sondern ich bin ein Fürst über das Heer des HERRN und bin jetzt gekommen.
<G-vec00071-002-s169><come.kommen><en> 47 “If anyone hears my words but does not keep them, I do not judge that person. For I did not come to judge the world, but to save the world.
<G-vec00071-002-s169><come.kommen><de> 47 Und wenn jemand meine Worte hört und nicht glaubt, so richte ich ihn nicht; denn ich bin nicht gekommen, um die Welt zu richten, sondern damit ich die Welt rette.
<G-vec00071-002-s170><come.kommen><en> Today, mankind has once again come to the crossroads of the transformation of the transportation energy power system.
<G-vec00071-002-s170><come.kommen><de> Heute ist die Menschheit wieder an den Scheideweg der Transformation des Verkehrsenergiesystems gekommen.
<G-vec00071-002-s266><come.kommen><en> It was a feature of the UK implementation of the EMD that KYC measures did not come into play until a client had developed a material level of activity.
<G-vec00071-002-s266><come.kommen><de> Ein Merkmal der Umsetzung der EGR im Vereinigten Königreich bestand darin, dass das KYC-Prinzip erst zum Tragen kam, wenn ein Kunde beachtliche Aktivitäten entfaltete.
<G-vec00071-002-s267><come.kommen><en> I've come to understand the inner logic of the Tech. It is expressed in the Factors, the Axioms, and the Class VIII materials.
<G-vec00071-002-s267><come.kommen><de> Ich kam zum Verständnis der inneren Logik der Tech, die in den Faktoren, den Axiomen und den Class VIII Materialien ausgedrückt ist.
<G-vec00071-002-s268><come.kommen><en> No one has seen you come but you have come to stay.
<G-vec00071-002-s268><come.kommen><de> Niemand sah ihn kommen, aber er kam, um zu bleiben.
<G-vec00071-002-s269><come.kommen><en> Twice it has come with no tidings from abroad, but now finally with its return the knight and his servant ride back from Rome, bearing a papal ban against the widow who dared oppose the pious Bishop.
<G-vec00071-002-s269><come.kommen><de> Zweimal kam er, nun endlich ruft er den Rittern und Knechten ein Willkommen entgegen, die mit einem päpstlichen Briefe von Rom heimkehren, mit einem Bannbriefe über die Witwe, die den frommen Bischof zu beleidigen wagte.
<G-vec00071-002-s270><come.kommen><en> Local practitioner Gisela said, "Today I come here to draw attention to the Olympic spirit and values.
<G-vec00071-002-s270><come.kommen><de> “Gisela, eine ortsansässige Praktizierende sagte: „Ich kam heute hierher, um auf den Olympischen Geist und Olympische Werte aufmerksam zu machen.
<G-vec00071-002-s271><come.kommen><en> I was wearing a white gown but when reached where I was going, I come upon at least eight people sitting in chairs in half horseshoe shape.
<G-vec00071-002-s271><come.kommen><de> Ich trug ein weißes Gewand, aber als ich den Ort erreichte, zu dem ich hinstrebte, kam ich auf mindestens 8 Personen, die in Sesseln saßen, die hufeisenförmig aufgestellt waren.
<G-vec00071-002-s272><come.kommen><en> I'd come home off the road sometimes and find my wife crying.
<G-vec00071-002-s272><come.kommen><de> Ich kam einmal nach unserem Konzert nach Hause und fand meine Frau weinend zu Hause.
<G-vec00071-002-s273><come.kommen><en> Go, and you shall proceed, and come to the man of God to mount Carmel.
<G-vec00071-002-s273><come.kommen><de> 25 Also zog sie hin und kam zu dem Mann Gottes auf den Berg Karmel.
<G-vec00071-002-s274><come.kommen><en> The Term "summary" has come to us from the Latin language.
<G-vec00071-002-s274><come.kommen><de> Der Begriff "Zusammenfassung" kam zu uns aus der lateinischen Sprache.
<G-vec00071-002-s275><come.kommen><en> If Clara, who has been living in Jerusalem for years, remembers the joy of a year when she accompanied the person closest to her in the Basilica, her mother who had come to visit her, Elena waits for her parents and Sara remembers the joy of when she celebrated her Easter with his colleagues in a family atmosphere.
<G-vec00071-002-s275><come.kommen><de> Clara, die seit Jahren in Jerusalem wohnt, erinnert sich an die Freude des Jahres, als sie die Person, die ihr am meisten am Herzen liegt, nämlich ihre Mutter, die sie besuchen kam, in die Basilika begleitete, und so erwartet auch Elena ihre Eltern und Sara ist die Freude beim Feiern des Osterfestes mit ihren Kollegen in einer vertrauten Atmosphäre in Erinnerung geblieben.
<G-vec00071-002-s276><come.kommen><en> Despondent, we waited for someone from the team to come rescue us.
<G-vec00071-002-s276><come.kommen><de> Niedergeschlagen warteten wir darauf, dass jemand vom Team kam, um uns abzuholen.
<G-vec00071-002-s277><come.kommen><en> He did not realise where it had come from, though the servants who had drawn the water knew.
<G-vec00071-002-s277><come.kommen><de> Er wusste nicht, woher der Wein kam; die Diener aber, die das Wasser geschöpft hatten, wussten es.
<G-vec00071-002-s278><come.kommen><en> Yea, I have given the good things of this life to these (men) and their fathers, until the Truth has come to them, and a messenger making things clear.
<G-vec00071-002-s278><come.kommen><de> Dennoch gewährte Ich diesen und ihren Vätern Versorgung in Fülle, bis die Wahrheit und ein offenkundiger Gesandter zu ihnen kam.
<G-vec00071-002-s279><come.kommen><en> They follow nothing but conjecture and what the souls desire!- Even though there has already come to them Guidance from their Lord!
<G-vec00071-002-s279><come.kommen><de> Sie folgen einem bloßen Wahn und dem Wunsche (ihres) Ichs, obwohl doch Weisung von ihrem Herrn zu ihnen kam.
<G-vec00071-002-s281><come.kommen><en> Dear children, I am your Mom and come from Heaven to lead you to My Lord.
<G-vec00071-002-s281><come.kommen><de> Ich bin eure Mutter und kam vom Himmel um euch zum Himmel zu fuehren.
<G-vec00071-002-s282><come.kommen><en> But because the Holy Spirit has come to dwell within us, and because of the promises in John 14, Jesus makes it very plain that Our Authentic Christian faith is not an esoteric religion, secret elite society, New Age or Buddhist doctrine.
<G-vec00071-002-s282><come.kommen><de> Aber weil der Heilige Geist kam, um in uns zu wohnen und aufgrund der Verheissungen in Johannes 14, macht es Jesus sehr deutlich, dass unser authentischer, christlicher Glaube keine esoterische Religion, keine geheime, elitäre Gesellschaft, kein New Age und keine buddhistische Lehre ist.
<G-vec00071-002-s283><come.kommen><en> But through their trespass salvation has come to the Gentiles, so as to make Israel jealous.
<G-vec00071-002-s283><come.kommen><de> Vielmehr kam durch ihr Versagen das Heil zu den Heiden, um sie selbst eifersüchtig zu machen.
<G-vec00071-002-s284><come.kommen><en> I saw her last one 16 months ago before I come to Germany.
<G-vec00071-002-s284><come.kommen><de> Ich habe sie zuletzt vor 16 Monaten gesehen, bevor ich nach Deutschland kam.
<G-vec00071-002-s304><come.kommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec00071-002-s304><come.kommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec00071-002-s305><come.kommen><en> All your wishes - come true here.
<G-vec00071-002-s305><come.kommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec00071-002-s306><come.kommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec00071-002-s306><come.kommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec00071-002-s308><come.kommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec00071-002-s308><come.kommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec00071-002-s309><come.kommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00071-002-s309><come.kommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00071-002-s310><come.kommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec00071-002-s310><come.kommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec00071-002-s311><come.kommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec00071-002-s311><come.kommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec00071-002-s312><come.kommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec00071-002-s312><come.kommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec00071-002-s313><come.kommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec00071-002-s313><come.kommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec00071-002-s314><come.kommen><en> Come wherever you are unknown.
<G-vec00071-002-s314><come.kommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec00071-002-s315><come.kommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec00071-002-s315><come.kommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec00071-002-s316><come.kommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec00071-002-s316><come.kommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec00071-002-s317><come.kommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec00071-002-s317><come.kommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec00071-002-s318><come.kommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec00071-002-s318><come.kommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec00071-002-s319><come.kommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec00071-002-s319><come.kommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec00071-002-s320><come.kommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec00071-002-s320><come.kommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec00071-002-s321><come.kommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec00071-002-s321><come.kommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec00071-002-s322><come.kommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec00071-002-s322><come.kommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec00071-002-s323><come.kommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec00071-002-s323><come.kommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec00071-002-s324><come.kommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00071-002-s324><come.kommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00071-002-s325><come.kommen><en> – English translation: I come from Britain.
<G-vec00071-002-s325><come.kommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec00071-002-s326><come.kommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00071-002-s326><come.kommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00071-002-s327><come.kommen><en> Will definitely come back if headed to this area again.
<G-vec00071-002-s327><come.kommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec00071-002-s328><come.kommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec00071-002-s328><come.kommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec00071-002-s329><come.kommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec00071-002-s329><come.kommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec00071-002-s330><come.kommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec00071-002-s330><come.kommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00071-002-s331><come.kommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec00071-002-s331><come.kommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00071-002-s332><come.kommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec00071-002-s332><come.kommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec00071-002-s333><come.kommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec00071-002-s333><come.kommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec00071-002-s334><come.kommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec00071-002-s334><come.kommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec00071-002-s335><come.kommen><en> I come from the picturesque city of brides, Sumy.
<G-vec00071-002-s335><come.kommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec00071-002-s336><come.kommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec00071-002-s336><come.kommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec00071-002-s337><come.kommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec00071-002-s337><come.kommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec00071-002-s338><come.kommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec00071-002-s338><come.kommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec00071-002-s339><come.kommen><en> And so I come to a second reflection.
<G-vec00071-002-s339><come.kommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec00071-002-s340><come.kommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec00071-002-s340><come.kommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec00071-002-s341><come.kommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec00071-002-s341><come.kommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec00071-002-s342><come.kommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec00071-002-s342><come.kommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec00071-002-s343><come.kommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec00071-002-s343><come.kommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec00071-002-s344><come.kommen><en> I love this country so it has been nice to be forced to come home.
<G-vec00071-002-s344><come.kommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec00071-002-s345><come.kommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec00071-002-s345><come.kommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec00071-002-s346><come.kommen><en> These now come from the cold stores.
<G-vec00071-002-s346><come.kommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec00071-002-s347><come.kommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec00071-002-s347><come.kommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec00071-002-s348><come.kommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec00071-002-s348><come.kommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec00071-002-s349><come.kommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec00071-002-s349><come.kommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec00071-002-s350><come.kommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec00071-002-s350><come.kommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec00071-002-s351><come.kommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec00071-002-s351><come.kommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec00071-002-s352><come.kommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec00071-002-s352><come.kommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec00071-002-s353><come.kommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00071-002-s353><come.kommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00071-002-s354><come.kommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec00071-002-s354><come.kommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec00071-002-s355><come.kommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec00071-002-s355><come.kommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec00071-002-s356><come.kommen><en> The artists come from Frohnau or other places.
<G-vec00071-002-s356><come.kommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec00071-002-s357><come.kommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec00071-002-s357><come.kommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec00071-002-s358><come.kommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec00071-002-s358><come.kommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec00071-002-s359><come.kommen><en> It looks like the babies all come in "twos" this spring.
<G-vec00071-002-s359><come.kommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec00071-002-s360><come.kommen><en> Come, see, hear, and marvel.
<G-vec00071-002-s360><come.kommen><de> Kommen, schauen, hören, staunen.
<G-vec00071-002-s361><come.kommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec00071-002-s361><come.kommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec00071-002-s362><come.kommen><en> Come to us, and you will not regret.
<G-vec00071-002-s362><come.kommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec00071-002-s363><come.kommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec00071-002-s363><come.kommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec00071-002-s364><come.kommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec00071-002-s364><come.kommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec00071-002-s365><come.kommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec00071-002-s365><come.kommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec00071-002-s366><come.kommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec00071-002-s366><come.kommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec00071-002-s367><come.kommen><en> Come and have a look or check our website.
<G-vec00071-002-s367><come.kommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec00071-002-s368><come.kommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec00071-002-s368><come.kommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec00071-002-s369><come.kommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec00071-002-s369><come.kommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec00071-002-s370><come.kommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec00071-002-s370><come.kommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec00071-002-s371><come.kommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec00071-002-s371><come.kommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec00071-002-s372><come.kommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec00071-002-s372><come.kommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec00071-002-s373><come.kommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec00071-002-s373><come.kommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec00071-002-s374><come.kommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec00071-002-s374><come.kommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec00071-002-s375><come.kommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec00071-002-s375><come.kommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec00071-002-s376><come.kommen><en> Come to Ulm – it will make a difference in your life.
<G-vec00071-002-s376><come.kommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec00071-002-s377><come.kommen><en> Just come, book it now and you will see for yourself.
<G-vec00071-002-s377><come.kommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec00071-002-s378><come.kommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec00071-002-s378><come.kommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec00071-002-s379><come.kommen><en> Here come easily in 4 steps to your desired server.
<G-vec00071-002-s379><come.kommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec00071-002-s399><come.kommen><en> Lights turn on when you come home.
<G-vec00071-002-s399><come.kommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec00071-002-s400><come.kommen><en> From there you will not come back.
<G-vec00071-002-s400><come.kommen><de> Von da kommst du nicht zurück.
<G-vec00071-002-s401><come.kommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec00071-002-s401><come.kommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec00071-002-s402><come.kommen><en> Will you come over and play for me.
<G-vec00071-002-s402><come.kommen><de> Kommst du rüber und spielst für mich.
<G-vec00071-002-s403><come.kommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec00071-002-s403><come.kommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec00071-002-s404><come.kommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec00071-002-s404><come.kommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec00071-002-s405><come.kommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec00071-002-s405><come.kommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec00071-002-s406><come.kommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec00071-002-s406><come.kommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec00071-002-s407><come.kommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec00071-002-s407><come.kommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec00071-002-s408><come.kommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec00071-002-s408><come.kommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00071-002-s409><come.kommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec00071-002-s409><come.kommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec00071-002-s410><come.kommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec00071-002-s410><come.kommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec00071-002-s411><come.kommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec00071-002-s411><come.kommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec00071-002-s412><come.kommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec00071-002-s412><come.kommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec00071-002-s413><come.kommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec00071-002-s413><come.kommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec00071-002-s414><come.kommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec00071-002-s414><come.kommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00071-002-s415><come.kommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec00071-002-s415><come.kommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec00071-002-s416><come.kommen><en> Moving forward is more like the platform you come from.
<G-vec00071-002-s416><come.kommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec00071-002-s417><come.kommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec00071-002-s417><come.kommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec00071-002-s418><come.kommen><en> The color must have come from cocoa powder.
<G-vec00071-002-s418><come.kommen><de> Die Farbe kommt von Kakaopulver.
<G-vec00071-002-s419><come.kommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec00071-002-s419><come.kommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec00071-002-s420><come.kommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec00071-002-s420><come.kommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec00071-002-s421><come.kommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec00071-002-s421><come.kommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec00071-002-s422><come.kommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec00071-002-s422><come.kommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec00071-002-s423><come.kommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec00071-002-s423><come.kommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec00071-002-s424><come.kommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec00071-002-s424><come.kommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec00071-002-s425><come.kommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00071-002-s425><come.kommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00071-002-s426><come.kommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec00071-002-s426><come.kommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec00071-002-s427><come.kommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec00071-002-s427><come.kommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec00071-002-s428><come.kommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec00071-002-s428><come.kommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec00071-002-s429><come.kommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec00071-002-s429><come.kommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec00071-002-s430><come.kommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec00071-002-s430><come.kommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec00071-002-s431><come.kommen><en> Come and see the place where the Lord was laid.
<G-vec00071-002-s431><come.kommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec00071-002-s432><come.kommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec00071-002-s432><come.kommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec00071-002-s433><come.kommen><en> Run up till you come to the snapping doors.
<G-vec00071-002-s433><come.kommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec00071-002-s434><come.kommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec00071-002-s434><come.kommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec00071-002-s435><come.kommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec00071-002-s435><come.kommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec00071-002-s436><come.kommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec00071-002-s436><come.kommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
<G-vec00071-002-s247><come.sein><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00071-002-s247><come.sein><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00071-002-s248><come.sein><en> Featuring a shower, shared bathrooms also come with a bath and a bath or shower.
<G-vec00071-002-s248><come.sein><de> Das eigene Bad ist mit einer Badewanne oder einer Dusche ausgestattet.
<G-vec00071-002-s249><come.sein><en> Many tourists come here everyday to start for many mountain hikings and walks in the fabulous and magic Fanes region....
<G-vec00071-002-s249><come.sein><de> Es ist ein vielbesuchter Ausgangspunkt für eine Reihe von Bergbesteigungen und herrlichen Höhenwanderungen im sagenumworbenen...
<G-vec00071-002-s250><come.sein><en> The Race Control System bar sizes come in 45cm, 50cm and 55cm.
<G-vec00071-002-s250><come.sein><de> Die Race Controlsystembar ist in 45cm, 50cm und 55cm erhältlich.
<G-vec00071-002-s251><come.sein><en> Notably, the revised mine plan and the associated cost benefits started to come into effect in March.
<G-vec00071-002-s251><come.sein><de> Bemerkenswert ist, dass der überarbeitete Minenplan und die damit verbundenen Kostenvorteile im März in Kraft traten.
<G-vec00071-002-s252><come.sein><en> They come well-appointed with full modern amenities including free Wi-Fi, flat-screen TVs and mini bars.
<G-vec00071-002-s252><come.sein><de> Es ist mit modernen Annehmlichkeiten ausgestattet, die kostenfreies Wifi, einen Flachbildschirmfernseher und eine Minibar einschließen.
<G-vec00071-002-s253><come.sein><en> The latest generation of ROG motherboards, desktops and laptops come pre-installed with GameFirst V, powerful software that automatically prioritizes gaming and streaming network traffic.
<G-vec00071-002-s253><come.sein><de> Die neueste Generation der ROG-Mainboards, Desktops und Notebooks ist mit GameFirst V vorinstalliert, einer leistungsstarken Software, die Spiele und Streaming-Netzwerkverkehr automatisch priorisiert.
<G-vec00071-002-s254><come.sein><en> Featuring a walk-in shower, private bathrooms also come with a hairdryer and free toiletries.
<G-vec00071-002-s254><come.sein><de> Das angrenzende Bad ist mit einer Dusche und kostenfreien Pflegeprodukten ausgestattet.
<G-vec00071-002-s255><come.sein><en> Rooms and dormitories in Home Made House come with shared bathroom facilities.
<G-vec00071-002-s255><come.sein><de> Jedes Zimmer im Fabrika ist minimalistisch eingerichtet und bietet Zugang zum Gemeinschaftsbad.
<G-vec00071-002-s256><come.sein><en> These skinny fit maternity jeans by Queen mum come in a classic 5-pocket style.
<G-vec00071-002-s256><come.sein><de> Diese Umstandsjeans von Queen Mum ist eine klassische 5-Pocket-Slim-Jeans mit dunkler Waschung.
<G-vec00071-002-s257><come.sein><en> Instead we’re still fighting demons from the past that we thought we had long since exorcised — religious fundamentalism, nationalism — but they’ve all come back to haunt us.
<G-vec00071-002-s257><come.sein><de> Stattdessen bekämpfen wir Gespenster der Vergangenheit, die wir längst exorziert glaubten, religiösen Fundamentalismus, Nationalismus – alles ist wieder da.
<G-vec00071-002-s258><come.sein><en> Come, see the place where He was lying.
<G-vec00071-002-s258><come.sein><de> Seht, hier ist die Stelle, wo man ihn hingelegt hatte.
<G-vec00071-002-s259><come.sein><en> The rooms in Hotel Baudin come with a private toilet, a work desk, a closet, a dressing area and TV.
<G-vec00071-002-s259><come.sein><de> Dieses Hotel ist mit Heizung, einem Flachbildschirm-TV, einem Wandschrank, einem Ankleidebereich und eigener Toilette in jedem Gästezimmer ausgestattet.
<G-vec00071-002-s260><come.sein><en> riese und müller (ww.r-m.de) have presented their first e-bikes last year, and now they have come up with a new model: the Avenue hybrid, a comfy full suspension touring bike with a powerful TranzX support engine integrated into the front hub.
<G-vec00071-002-s260><come.sein><de> Die im letzten Jahr eingeführte E-Bike-Produktpalette von riese und müller (www.r-m.de) wird um ein Modell erweitert: Als komfortables Tourenrad mit Elektrounterstützung ist in der kommenden Saison das Avenue hybrid am Start.
<G-vec00071-002-s261><come.sein><en> From the blood of the dead, from the fat of the strong, the bow of Jonathan was not turned back, the sword of Saul did not come back unused.
<G-vec00071-002-s261><come.sein><de> 22 Der Bogen Jonathans hat nie gefehlt, und das Schwert Sauls ist nie leer wiedergekommen von dem Blut der Erschlagenen und vom Fett der Helden.
<G-vec00071-002-s262><come.sein><en> All rooms come with a flat-screen TV with satellite channels.
<G-vec00071-002-s262><come.sein><de> Die Unterkunft ist mit einem Flachbild-Sat-TV ausgestattet.
<G-vec00071-002-s263><come.sein><en> The private bathrooms come with a bath or shower and a toilet.
<G-vec00071-002-s263><come.sein><de> Das eigene Bad ist mit einer Badewanne oder Dusche und einem WC ausgestattet.
<G-vec00071-002-s264><come.sein><en> Hebrews 9:11: But Christ being come an high priest of good things to come, by a greater and more perfect tabernacle, not made with hands, that is to say, not of this building;
<G-vec00071-002-s264><come.sein><de> Unser gegenwärtiges Verhältnis zu Christus ist jedoch ein himmlisches; Er ist Hoherpriester in einer besseren und vollkommeneren Hütte, die nicht mit Händen gemacht ist, d. h. nicht zu dieser Schöpfung gehört; Er ist im Himmel, und wir haben dort unsern Platz.
<G-vec00071-002-s265><come.sein><en> The Pro versions come with more high-end parts than the other Xenon models, and the visual design has been upgraded as well.
<G-vec00071-002-s265><come.sein><de> Die Pro-Version ist mit mehr High-End-Teilen ausgestattet als die anderen Xenon-Modelle und auch das visuelle Design wurde verbessert.
<G-vec00071-002-s532><come.stammen><en> Most of the clothes on offer at the moment come from the fashion houses of the West.
<G-vec00071-002-s532><come.stammen><de> Die meisten derzeit erhältlichen Kleidungsstücke stammen aus westlichen Modehäusern.
<G-vec00071-002-s533><come.stammen><en> The following pictures come from a public FTP-server of an American university which have been passed to me by a friend to whom I am gratefully for it.
<G-vec00071-002-s533><come.stammen><de> Die folgenden Bilder stammen von einem öffentlichen FTP-Server einer amerikanischen Universität, die mir von einem Freund zugespielt worden sind, dem ich dankbar dafür bin.
<G-vec00071-002-s534><come.stammen><en> In early 1974, the 133 appeared as the successor to the Seat 850, from the floor group and engine come.
<G-vec00071-002-s534><come.stammen><de> Anfang 1974 erschien der 133 als Nachfolger des Seat 850, von dem auch Bodengruppe und Motor stammen.
<G-vec00071-002-s535><come.stammen><en> The animal products used by our suppliers come from unobjectionable sources.
<G-vec00071-002-s535><come.stammen><de> Die von unseren Lieferanten eingesetzten tierischen Produkte stammen aus unbedenklichen Quellen.
<G-vec00071-002-s536><come.stammen><en> Fat binders have active components that spread throughout the intestine and bind a proportion of the fat molecules that come from taken in meals.
<G-vec00071-002-s536><come.stammen><de> Fett Bindemittel haben Wirkstoffe der Zerstreuung in den Darm und binden einen Teil der Fettmoleküle, die von aufgenommener Nahrung stammen.
<G-vec00071-002-s537><come.stammen><en> The grapes come from the majestic Viña Tondonia estate. The well-known Riojan estate spans across 100 hectares and borders the river Ebro as it passes through Haro, and is crowned by the Tondonia castle.
<G-vec00071-002-s537><come.stammen><de> Die Trauben stammen von der majestätischen Finca Viña Tondonia, die mit 100 Hektar an Weinberg auf einer vom Fluss Ebro umarmten und durch die Burg Tondonia gekrönte Halbinsel liegt.
<G-vec00071-002-s538><come.stammen><en> With stacking and layering, you usually succeed in very nice combinations even if not all the pieces of jewellery come from the same set.
<G-vec00071-002-s538><come.stammen><de> Beim Stacking und Layering gelingen Ihnen in der Regel auch dann sehr schöne Kombinationen, wenn nicht sämtliche Schmuckstücke aus ein und demselben Set stammen.
<G-vec00071-002-s539><come.stammen><en> The forms of nature come from human thoughts.
<G-vec00071-002-s539><come.stammen><de> Die Formen der Natur stammen aus menschlichen Gedanken.
<G-vec00071-002-s540><come.stammen><en> The objects on display come mainly from Merchant citizens who make the exhibits available as donations or loans.
<G-vec00071-002-s540><come.stammen><de> Die ausgestellten Gegenstände stammen hauptsächlich von Merchinger Bürgern, die die Exponate als Spenden oder Leihgaben zur Verfügung stellen.
<G-vec00071-002-s541><come.stammen><en> Swallows (Hirundinidae) come from the family of sparrow birds, subordination songbirds.
<G-vec00071-002-s541><come.stammen><de> Schwalben (Hirundinidae) stammen aus der Familie der Sperlingsvögel, Unterordnung Singvögel.
<G-vec00071-002-s542><come.stammen><en> The raw materials used preferably come from certified organic farms.
<G-vec00071-002-s542><come.stammen><de> Die verwendeten Rohstoffe stammen bevorzugt aus kontrolliert biologischem Anbau.
<G-vec00071-002-s543><come.stammen><en> All our raw materials come from French pharmaceutical laboratories meeting the standards of AFSSAPS (BPF).
<G-vec00071-002-s543><come.stammen><de> Alle unsere Rohstoffe stammen aus französischen pharmazeutischen Laboratorien, die die Standards von AFSSAPS (BPF) erfüllen.
<G-vec00071-002-s544><come.stammen><en> — they come from other countries (other than Croatia, the Faeroe Islands, Greenland, or Iceland) and their combined weight does not exceed 2 kg per person.
<G-vec00071-002-s544><come.stammen><de> Die betreffenden Erzeugnisse stammen aus anderen Ländern (also nicht aus Kroatien, den Färöern, Grönland oder Island), und ihr Gewicht übersteigt zusammengenommen nicht 2 kg pro Person.
<G-vec00071-002-s545><come.stammen><en> These data come from interest-related advertising by Google and from visitor data supplied by third-party providers.
<G-vec00071-002-s545><come.stammen><de> Diese Daten stammen aus interessenbezogener Werbung von Google sowie aus Besucherdaten von Drittanbietern.
<G-vec00071-002-s546><come.stammen><en> NOTONE (About Us: We are a DHT resource search engine based on the Torrents protocol, all the resources come from the DHT web crawler for 24 hours.
<G-vec00071-002-s546><come.stammen><de> Über uns: Wir sind eine DHT-Ressource-Suchmaschine basierend auf dem Protokoll Torrents, alle Ressourcen stammen aus der DHT-Webcrawler für 24 Stunden.
<G-vec00071-002-s547><come.stammen><en> Signature effects come from Nathan East, Mark King, Duff McKagan, Richard Bona and more.
<G-vec00071-002-s547><come.stammen><de> Die Signatur-Effekte stammen von Nathan East, Mark King, Duff McKagan, Richard Bona und vielen mehr.
<G-vec00071-002-s548><come.stammen><en> It utilizes terms which were sent from God to Muhammad by the Angel Gabriel and recorded on the Quran… It is clear to me that these statements must have come to Muhammad from God because almost none of this knowledge was discovered until many centuries later.
<G-vec00071-002-s548><come.stammen><de> Sie benutzt Bezeichnungen, die von Gott zu Muhammad über den Engel Gabriel gesandt und im Qurân aufgezeichnet wurden… Ich bin davon überzeugt, dass diese Aussagen Muhammads von Gott stammen müssen, denn all dieses Wissen wurde erst viele Jahrhunderte später entdeckt.
<G-vec00071-002-s549><come.stammen><en> The floral decorations that adorn the Concert Hall where the Nobel Prizes are awarded come from the Flower Riviera.
<G-vec00071-002-s549><come.stammen><de> Was viele nicht wissen ist, dass die Blumendekorationen, die das Konzerthaus schmücken, in welchem die Nobelpreise verliehen werden, von der Blumenriviera stammen.
<G-vec00071-002-s550><come.stammen><en> The offers come from the clusters Management & Entrepreneurship, Governance, Sustainability & Law as well as Education, Health & Social Affairs.
<G-vec00071-002-s550><come.stammen><de> Die Angebote stammen aus den Clustern Management & Entrepreneurship, Governance, Nachhaltigkeit & Recht sowie Bildung, Gesundheit & Soziales.
<G-vec00086-002-s285><come.herauskommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00086-002-s285><come.herauskommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00086-002-s286><come.herauskommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00086-002-s286><come.herauskommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00086-002-s287><come.herauskommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00086-002-s287><come.herauskommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00086-002-s288><come.herauskommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00086-002-s288><come.herauskommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00086-002-s289><come.herauskommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00086-002-s289><come.herauskommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00086-002-s290><come.herauskommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00086-002-s290><come.herauskommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00086-002-s291><come.herauskommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00086-002-s291><come.herauskommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00086-002-s292><come.herauskommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00086-002-s292><come.herauskommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00086-002-s293><come.herauskommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00086-002-s293><come.herauskommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00086-002-s294><come.herauskommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00086-002-s294><come.herauskommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00086-002-s295><come.herauskommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00086-002-s295><come.herauskommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00086-002-s296><come.herauskommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00086-002-s296><come.herauskommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00086-002-s297><come.herauskommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00086-002-s297><come.herauskommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00086-002-s298><come.herauskommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00086-002-s298><come.herauskommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00086-002-s299><come.herauskommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00086-002-s299><come.herauskommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00086-002-s300><come.herauskommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00086-002-s300><come.herauskommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00086-002-s301><come.herauskommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00086-002-s301><come.herauskommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00086-002-s302><come.herauskommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00086-002-s302><come.herauskommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00086-002-s303><come.herauskommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00086-002-s303><come.herauskommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00086-002-s304><come.herauskommen><en> Locate a position on the rail and put your money down in front of you in the "come" area.
<G-vec00086-002-s304><come.herauskommen><de> Suchen Sie eine Posición auf der Schiene und legen Ihr Geld auf den Tisch vor IHNEN in der "Komm"-Bereich.
<G-vec00086-002-s305><come.herauskommen><en> All your wishes - come true here.
<G-vec00086-002-s305><come.herauskommen><de> Komm, ich erfülle Dir Deine Wünsche.
<G-vec00086-002-s306><come.herauskommen><en> One day Jonathan the son of Saul said to the young man who bore his armor, "Come, let us go over to the Philistine garrison on yonder side."
<G-vec00086-002-s306><come.herauskommen><de> Eines Tages sagte Jonatan, der Sohn Sauls, zu seinem Waffenträger: Komm, wir wollen zu dem Posten der Philister hinübergehen, der da drüben steht.
<G-vec00086-002-s307><come.herauskommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00086-002-s307><come.herauskommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00086-002-s308><come.herauskommen><en> 12 The Lord said to Moses, "Come up to me on the mountain, and stay here, and I will give you the tables of stone with the law and the commands that I have written, that you may teach them."
<G-vec00086-002-s308><come.herauskommen><de> 12 Und der HERR sprach zu Mose: Komm herauf zu mir auf den Berg und bleib daselbst, daß ich dir gebe steinerne Tafeln und Gesetze und Gebote, die ich geschrieben habe, die du sie lehren sollst.
<G-vec00086-002-s309><come.herauskommen><en> Perhaps only because her mother was there, she remained calm, bent her face to her so that she would not look round and said, albeit hurriedly and with a tremor in her voice: “Come on, let’s go back in the living room for a while?” Gregor could see what Grete had in mind, she wanted to take her mother somewhere safe and then chase him down from the wall.
<G-vec00086-002-s309><come.herauskommen><de> Wohl nur infolge der Gegenwart der Mutter behielt sie ihre Fassung, beugte ihr Gesicht zur Mutter, um diese vom Herumschauen abzuhalten, und sagte, allerdings zitternd und unüberlegt: »Komm, wollen wir nicht lieber auf einen Augenblick noch ins Wohnzimmer zurückgehen?« Die Absicht Gretes war für Gregor klar, sie wollte die Mutter in Sicherheit bringen und dann ihn von der Wand hinunterjagen.
<G-vec00086-002-s310><come.herauskommen><en> ‘Veni sponsa Christi’ is the text of this ostinato; ‘Come, bride of Christ’ leaves no doubt that Guerrero had no thought that the Song of Songs was just Hebrew love poetry.
<G-vec00086-002-s310><come.herauskommen><de> Der Text dieses Ostinato heißt „Veni sponsa Christi“—„Komm, Braut Christi“—und zweifellos war für Guerrero das Hohelied mehr als lediglich hebräische Liebeslyrik.
<G-vec00086-002-s311><come.herauskommen><en> 27 And Balak said to him: "Come and I will lead you to another place. If perhaps it may please God, then you may curse them from there."
<G-vec00086-002-s311><come.herauskommen><de> 27Und Balak sprach zu Bileam: Komm doch, ich will dich an einen anderen Ort mitnehmen; vielleicht wird es in den Augen Gottes recht sein, daß du es mir von dort aus verwünschest.
<G-vec00086-002-s312><come.herauskommen><en> 18 While hee thus spake vnto them, beholde, there came a certaine ruler, and worshipped him, saying, My daughter is now deceased, but come and laie thine hande on her, and shee shall liue.
<G-vec00086-002-s312><come.herauskommen><de> 18 Während er dies zu ihnen redete, siehe, da kam ein Vorsteher herein und warf sich vor ihm nieder und sprach: Meine Tochter ist eben jetzt verschieden; aber komm und lege deine Hand auf sie, und sie wird leben.
<G-vec00086-002-s313><come.herauskommen><en> Come and experience the very thing that the Lord has said is of “most worth” (D&C 15:6) to you at this time in your life.
<G-vec00086-002-s313><come.herauskommen><de> Komm und erfahre, was der Herr meinte, als er sagte, es sei zu dieser Zeit deines Lebens für dich „von größtem Wert“ (LuB 15:6).
<G-vec00086-002-s314><come.herauskommen><en> Come wherever you are unknown.
<G-vec00086-002-s314><come.herauskommen><de> Komm dorthin, wo du unbekannt bist.
<G-vec00086-002-s315><come.herauskommen><en> 22 Just then Barak came by in pursuit of Sisera, and Jael went out to meet him. “Come,” she said, “I will show you the man you’re looking for.”
<G-vec00086-002-s315><come.herauskommen><de> 22 Und sieh, Barak hatte Sisera verfolgt, und Jael trat heraus, ihm entgegen, und sagte zu ihm: Komm, ich will dir den Mann zeigen, den du suchst.
<G-vec00086-002-s316><come.herauskommen><en> When I shall send Artemas to thee, or Tychicus, use diligence to come to me to Nicopolis; for I have decided to winter there.
<G-vec00086-002-s316><come.herauskommen><de> 12 Wenn ich dir senden werde Artemas oder Tychikus, so komm eilend zu mir nach Nikopolis; denn ich habe beschlossen, daselbst den Winter zu bleiben.
<G-vec00086-002-s317><come.herauskommen><en> Don't believe me? Come and find it out, you won't regret.
<G-vec00086-002-s317><come.herauskommen><de> Glaub mir nicht Komm und finde es heraus, du wirst es nicht bereuen.
<G-vec00086-002-s318><come.herauskommen><en> 21 Jesus saith to him: If thou desirest to be perfect, go, sell thy property, and give to the poor; and there shall be for thee a treasure in heaven; and come thou after me.
<G-vec00086-002-s318><come.herauskommen><de> 21 Jesus sprach zu ihm: Wenn du vollkommen sein willst, so gehe hin, verkaufe deine Habe und gib den Armen, und du wirst einen Schatz im Himmel haben; und komm, folge mir nach.
<G-vec00086-002-s319><come.herauskommen><en> Because that’s where the famous Club of Astronomers meets: come along and hear what Isaac Newton told them about his pioneering thoughts on the force of gravity and planetary orbits.
<G-vec00086-002-s319><come.herauskommen><de> Denn dort tagt der berühmte Club der Astronomen: Komm mit und erfahre, was Isaac Newton dort von seinen bahnbrechenden Gedanken über Gravitationskraft und Planetenbahnen erzählt.
<G-vec00086-002-s320><come.herauskommen><en> Come to my chat and see for yourself)) Ik hou niet do not like rude or when they consider me small and stupid.
<G-vec00086-002-s320><come.herauskommen><de> Komm zu meinem Chat und überzeuge dich selbst))I Ich mag es nicht unhöflich oder wenn sie mich für klein und dumm halten.
<G-vec00086-002-s321><come.herauskommen><en> 6 And they said to Jephthah, Come, and be our captain, that we may fight with the children of Ammon.
<G-vec00086-002-s321><come.herauskommen><de> 6 und sprachen zu ihm: Komm und sei unser Hauptmann, daß wir streiten wider die Kinder Ammon.
<G-vec00086-002-s322><come.herauskommen><en> I would never have done it myself, but he said, 'Come, Hubert, you take it.
<G-vec00086-002-s322><come.herauskommen><de> Ich hätte es von mir aus nie gemacht, aber er hat gesagt: ‚Komm Hubert, das nimmst du.
<G-vec00086-002-s323><come.herauskommen><en> Wow, I come from a background of jazz, funk and all this kind of music.
<G-vec00086-002-s323><come.herauskommen><de> Wow, ich komme aus einem Hintergrund von Jazz, Funk und all dieser Art von Musik.
<G-vec00086-002-s324><come.herauskommen><en> I come to My Own to give them this strength in order to defy the onslaught which penetrates them from outside.
<G-vec00086-002-s324><come.herauskommen><de> Ich komme zu den Meinen, um ihnen diese Kraft zu bringen, auf daß sie dem Ansturm trotzen, der von außen auf sie eindringt.
<G-vec00086-002-s325><come.herauskommen><en> – English translation: I come from Britain.
<G-vec00086-002-s325><come.herauskommen><de> – Deutsche Bedeutung: Ich komme aus Deutschland.
<G-vec00086-002-s326><come.herauskommen><en> And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves: For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.
<G-vec00086-002-s326><come.herauskommen><de> Und er nahm den Kelch, dankte und sprach: Nehmet ihn und teilet ihn unter euch; denn ich sage euch: Ich werde nicht trinken von dem Gewaechs des Weinstocks, bis das Reich Gottes komme.
<G-vec00086-002-s327><come.herauskommen><en> Will definitely come back if headed to this area again.
<G-vec00086-002-s327><come.herauskommen><de> Ich komme auf jeden Fall für einen weiteren Besuch zurück.
<G-vec00086-002-s328><come.herauskommen><en> 27 Only let your conversation be as it becomes the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that all of you stand fast in one spirit, (o. pneuma) with one mind striving together for the faith of the gospel; 28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.
<G-vec00086-002-s328><come.herauskommen><de> 27 Wandelt nur würdig des Evangeliums des Christus, auf daß, sei es daß ich komme und euch sehe, oder abwesend bin, ich von euch höre, daß ihr feststehet in einem Geiste, indem ihr mit einer Seele mitkämpfet mit dem Glauben des Evangeliums, 28 und in nichts euch erschrecken lasset von den Widersachern; was für sie ein Beweis des Verderbens ist, aber eures Heils, und das von Gott.
<G-vec00086-002-s329><come.herauskommen><en> 25But until I come, you must hold firmly to what you have.
<G-vec00086-002-s329><come.herauskommen><de> 25Haltet nur unerschütterlich an dem fest, was ihr habt, bis ich komme.
<G-vec00086-002-s330><come.herauskommen><en> 10 Therefore, if I come, I will call attention to his deeds which he does, unjustly accusing us with wicked words. Not content with this, neither does he himself receive the brothers, and those who would, he forbids and throws out of the church.
<G-vec00086-002-s330><come.herauskommen><de> 10 Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00086-002-s331><come.herauskommen><en> 10 Wherefore, if I come, I will remember his deeds which he doeth, prating against us with malicious words: and not content therewith, neither doth he himself receive the brethren, and forbiddeth them that would, and casteth them out of the church.
<G-vec00086-002-s331><come.herauskommen><de> Deshalb, wenn ich komme, will ich seiner Werke gedenken, die er tut, indem er mit bösen Worten wider uns schwatzt; und sich hiermit nicht begnügend, nimmt er selbst die Brüder nicht an und wehrt auch denen, die es wollen, und stößt sie aus der Versammlung.
<G-vec00086-002-s332><come.herauskommen><en> 6 O my soul, do not come into their council, do not be united to their assembly, my heart, for in their anger they have killed men, and for pleasure they have hamstrung oxen.
<G-vec00086-002-s332><come.herauskommen><de> 6 Meine Seele komme nicht in ihren Rat, und meine Ehre sei nicht in ihrer Versammlung; denn in ihrem Zorn haben sie den Mann erwürgt, und in ihrem Mutwillen haben sie den Ochsen verlähmt.
<G-vec00086-002-s333><come.herauskommen><en> Today I know: I come from the angels and that's where I'll return.
<G-vec00086-002-s333><come.herauskommen><de> Heute weiß ich: Ich komme von den Engeln und kehre auch wieder dorthin zurück.
<G-vec00086-002-s334><come.herauskommen><en> 7Then said I, Lo, I come: in the volume of the book it is written of me,
<G-vec00086-002-s334><come.herauskommen><de> 7Da sprach ich: Siehe, ich komme; in der Rolle des Buches steht von mir geschrieben.
<G-vec00086-002-s335><come.herauskommen><en> I come from the picturesque city of brides, Sumy.
<G-vec00086-002-s335><come.herauskommen><de> Ich komme aus der malerischen Stadt der Bräute, Sumy.
<G-vec00086-002-s336><come.herauskommen><en> "I come now to beg from my friend, may I say my scholar——" "You may," answered the Queen, softened.
<G-vec00086-002-s336><come.herauskommen><de> »Jetzt komme ich, von meiner vieljährigen Freundin, ich darf sagen, meiner Schülerin—« »Du darfst es sagen,« sprach Amalaswintha weicher.
<G-vec00086-002-s337><come.herauskommen><en> 20For I fear lest perhaps coming I find you not such as I wish, and that I be found by you such as ye do not wish: lest there might be strifes, jealousies, angers, contentions, evil speakings, whisperings, puffings up, disturbances; 21lest my God should humble me as to you when I come again, and that I shall grieve over many of those who have sinned before, and have not repented as to the uncleanness and fornication and licentiousness which they have practised.
<G-vec00086-002-s337><come.herauskommen><de> 20Denn ich fürchte, daß, wenn ich komme, ich euch etwa nicht als solche finde, wie ich will, und daß ich von euch als solcher erfunden werde, wie ihr nicht wollet: daß etwa Streitigkeiten, Neid, Zorn, Zänkereien, Verleumdungen, Ohrenbläsereien, Aufgeblasenheit, Unordnungen vorhanden seien; 21daß, wenn ich wiederkomme, mein Gott mich eurethalben demütige, und ich über viele trauern müsse, die zuvor gesündigt und nicht Buße getan haben über die Unreinigkeit und Hurerei und Unzucht, die sie getrieben haben.
<G-vec00086-002-s338><come.herauskommen><en> The invocation “thy kingdom come” encourages conversion and reminds us that man’s earthly day must be marked by the daily search for the Kingdom of God before and above all other things.
<G-vec00086-002-s338><come.herauskommen><de> Die Anrufung "dein Reich komme" fordert zur Umkehr auf und erinnert daran, daß der irdische Alltag des Menschen vor und über allem anderen von der tagtäglichen Suche nach dem Reich Gottes geprägt sein muss.
<G-vec00086-002-s339><come.herauskommen><en> And so I come to a second reflection.
<G-vec00086-002-s339><come.herauskommen><de> Ich komme zu einer zweiten Überlegung.
<G-vec00086-002-s340><come.herauskommen><en> If you call me, I come to you and we will spend together the best time of your life.
<G-vec00086-002-s340><come.herauskommen><de> Wenn du mich anrufst, komme ich zu dir und wir werden gemeinsam die schönste Zeit deines Lebens verbringen.
<G-vec00086-002-s341><come.herauskommen><en> 27Only let your manner of life be worthy[H]Greek Only behave as citizens worthy of the gospel of Christ, so that whether I come and see you or am absent, I may hear of you that you are standing firm in one spirit, with one mind striving side by side for the faith of the gospel, 28and not frightened in anything by your opponents. This is a clear sign to them of their destruction, but of your salvation, and that from God.
<G-vec00086-002-s341><come.herauskommen><de> 27Wandelt nur würdig dem Evangelium Christi, auf daß, ob ich komme und sehe euch oder abwesend von euch höre, ihr steht in einem Geist und einer Seele und samt uns kämpfet für den Glauben des Evangeliums 28und euch in keinem Weg erschrecken lasset von den Widersachern, welches ist ein Anzeichen, ihnen der Verdammnis, euch aber der Seligkeit, und das von Gott.
<G-vec00086-002-s342><come.herauskommen><en> Leaving La Palazza Restaurant on the right, you will come to a junction (on the left) with indications for La Martina (via Casoni di Romagna).
<G-vec00086-002-s342><come.herauskommen><de> Wenn Sie das Restaurant La Palazza auf der rechten Seite verlassen, kommen Sie zu einer Abzweigung (links) mit Hinweisen nach La Martina (über Casoni di Romagna).
<G-vec00086-002-s343><come.herauskommen><en> Imagine this: you come home to find perfectly heated rooms and the best possible light settings.
<G-vec00086-002-s343><come.herauskommen><de> Stellen Sie sich vor: Sie kommen heim und finden perfekt temperierte Räume und optimale Lichteinstellungen.
<G-vec00086-002-s344><come.herauskommen><en> I love this country so it has been nice to be forced to come home.
<G-vec00086-002-s344><come.herauskommen><de> Ich liebe dieses Land, also war es schön, dazu gezwungen zu sein, nach Hause zu kommen.
<G-vec00086-002-s345><come.herauskommen><en> Game facts: The Holly Jolly Penguins come to you with 5 rocking reels, 45 prancing paylines and an RTP of 96.01%.
<G-vec00086-002-s345><come.herauskommen><de> Fakten zum Spiel: Die Holly Jolly Penguins kommen mit 5 Walzen, 45 tänzelnden Gewinnlinien und einem RTP von 96.01% zu dir.
<G-vec00086-002-s346><come.herauskommen><en> These now come from the cold stores.
<G-vec00086-002-s346><come.herauskommen><de> Diese kommen jetzt aus den Kühlzellen.
<G-vec00086-002-s347><come.herauskommen><en> In the photo optics of the Nokia 8, the first fruits of the cooperation of HMD with the optics specialist Zeiss come to bear.
<G-vec00086-002-s347><come.herauskommen><de> Bei der Fotooptik des Nokia 8 kommen die ersten Früchte der Kooperation von HMD mit dem Optikspezialisten Zeiss zum Tragen.
<G-vec00086-002-s348><come.herauskommen><en> You have to be a cop-out or a wash-out or a dropout to come to our college.
<G-vec00086-002-s348><come.herauskommen><de> Man muss Drückeberger, Niete, oder Schulabbrecher sein, um an unser College zu kommen.
<G-vec00086-002-s349><come.herauskommen><en> 9 species are described from there, well-known species like M. boesemani, angfa and parva come from there and more than 20 undescribed species have been collected by expeditions.
<G-vec00086-002-s349><come.herauskommen><de> 9 Arten sind von dort beschrieben, bekannte Arten wie M. boesemani, angfa und parva kommen von dort und es wurden von Expeditionen über 20 noch unbeschriebene Arten entdeckt.
<G-vec00086-002-s350><come.herauskommen><en> No one wants to end their holiday early and come home on a medical transport.
<G-vec00086-002-s350><come.herauskommen><de> Denn keiner möchte vorzeitig mit einem Krankenrücktransport nach Hause kommen.
<G-vec00086-002-s351><come.herauskommen><en> He takes us on a visceral journey to the physical intimacy of the self. Hidden emotions come to the fore, take possession of the body, tear it apart.
<G-vec00086-002-s351><come.herauskommen><de> Er führt uns auf emotionale Art und Weise die leibliche Intimität des Ichs vor Augen: Versteckte Emotionen kommen zum Vorschein, nehmen Besitz von seinem Körper, zerreißen ihn.
<G-vec00086-002-s352><come.herauskommen><en> I invited my husband to come to the Agnihotra two times.
<G-vec00086-002-s352><come.herauskommen><de> Ich habe meinen Ehemann zweimal eingeladen, zum Agnihotra zu kommen.
<G-vec00086-002-s353><come.herauskommen><en> 10 For the prophets who gave the news of the grace which would come to you, made search with all care for knowledge of this salvation; 11 Attempting to see what sort of time the Spirit of Christ which was in them was pointing to, when it gave witness to the pains which Christ would undergo and the glories which would come after them.
<G-vec00086-002-s353><come.herauskommen><de> 10 Nach dieser Seligkeit haben gesucht und geforscht die Propheten, die von der Gnade geweissagt haben, so auf euch kommen sollte, 11 und haben geforscht, auf welche und welcherlei Zeit deutete der Geist Christi, der in ihnen war und zuvor bezeugt hat die Leiden, die über Christus kommen sollten, und die Herrlichkeit darnach; 12 welchen es offenbart ist.
<G-vec00086-002-s354><come.herauskommen><en> Peter shuddered at the thought of the Master’s dying — it was too disagreeable an idea to entertain — and fearing that James or John might ask some question relative to this statement, he thought best to start up a diverting conversation and, not knowing what else to talk about, gave expression to the first thought coming into his mind, which was: “Master, why is it that the scribes say that Elijah must first come before the Messiah shall appear?” And Jesus, knowing that Peter sought to avoid reference to his death and resurrection, answered: “Elijah indeed comes first to prepare the way for the Son of Man, who must suffer many things and finally be rejected.
<G-vec00086-002-s354><come.herauskommen><de> Und da ihm gerade nichts anderes einfiel, drückte er den erstbesten Gedanken aus, der ihm durch den Kopf ging, nämlich: „Meister, warum sagen die Schriftgelehrten, zuerst müsse Elija kommen, bevor der Messias erscheint?“ Und Jesus, der wusste, dass Petrus eine Anspielung auf seinen Tod und seine Auferstehung vermeiden wollte, gab zur Antwort: „Elija kommt in der Tat zuerst, um den Weg für den Menschensohn zu bereiten, der vieles erdulden muss und schließlich abgelehnt werden wird.
<G-vec00086-002-s355><come.herauskommen><en> But will surely follow, as we would like to come again to Cologne and then would like to again have the room.
<G-vec00086-002-s355><come.herauskommen><de> Wird aber sicherlich nachgeholt, da wir gerne noch einmal nach Köln kommen würden und dann gerne das Zimmer wiederhaben möchten.
<G-vec00086-002-s356><come.herauskommen><en> The artists come from Frohnau or other places.
<G-vec00086-002-s356><come.herauskommen><de> Die Künstler kommen aus Frohnau und ganz Deutschland.
<G-vec00086-002-s357><come.herauskommen><en> With hope and virtue, let us brave once more the icy currents, and endure what storms may come.
<G-vec00086-002-s357><come.herauskommen><de> Mit Hoffnung und Tugend lasst uns einmal mehr den eisigen Strömungen widerstehen und den Stürmen trotzen, die kommen mögen.
<G-vec00086-002-s358><come.herauskommen><en> The choice we will make will come only from ourselves, that is the choice of freedom.
<G-vec00086-002-s358><come.herauskommen><de> Unsere Wahl kann nur von uns selbst kommen, es ist jene der Freiheit.
<G-vec00086-002-s359><come.herauskommen><en> It looks like the babies all come in "twos" this spring.
<G-vec00086-002-s359><come.herauskommen><de> Es sieht aus, dass unsere Fohlen dieses Jahr als "Zweier" kommen.
<G-vec00086-002-s360><come.herauskommen><en> Come, see, hear, and marvel.
<G-vec00086-002-s360><come.herauskommen><de> Kommen, schauen, hören, staunen.
<G-vec00086-002-s361><come.herauskommen><en> These are ignored now, and if attempted to implement, often come back ONTO the implementer, the elite themselves.
<G-vec00086-002-s361><come.herauskommen><de> Diese werden nun ignoriert, und bei versuchter Anwendung kommen sie oft zu dem Anwender, der Elite selber, zurück.
<G-vec00086-002-s362><come.herauskommen><en> Come to us, and you will not regret.
<G-vec00086-002-s362><come.herauskommen><de> Kommen Sie zu uns an, und Sie werden nicht bemitleiden.
<G-vec00086-002-s363><come.herauskommen><en> Come and stay on our organic farm, where peace and quiet is.Midden in a bird-rich area, beautiful Wande and bike paths, fishing water nearby and a half hour drive to Groningen and Leeuwarden.
<G-vec00086-002-s363><come.herauskommen><de> Kommen Sie und bleiben auf unserem Bio-Bauernhof, wo Frieden und Ruhe is.Midden in einem Vogelreichen Gebiet, schöne Wande und Radwege, Fischwasser in der Nähe und eine halbe Stunde Fahrt nach Groningen und Leeuwarden.
<G-vec00086-002-s364><come.herauskommen><en> Come and see a classical concert performed by young musicians of the Amsterdam City Orchestra and he...
<G-vec00086-002-s364><come.herauskommen><de> Mobile Voucher Accepted Kommen Sie und sehen Sie ein klassisches Konzert von jungen Musikern des Amsterdamer Stadt...
<G-vec00086-002-s365><come.herauskommen><en> Like the quality of beer, 100% natural, come and discover the range of Saint Martin Mill: White Bio, Bio Blonde,...
<G-vec00086-002-s365><come.herauskommen><de> Wie die Qualität des Bieres, 100% natürlich, kommen Sie und entdecken Sie den Bereich von Saint Martin Mill:...
<G-vec00086-002-s366><come.herauskommen><en> Come and laugh at the clubs where Jerry Seinfeld, Jay Leno and Jim Carrey got their starts.
<G-vec00086-002-s366><come.herauskommen><de> Kommen Sie und lachen in einem der Klubs, wo Jerry Seinfeld, Jay Leno und Jim Carrey ihre Karriere begannen.
<G-vec00086-002-s367><come.herauskommen><en> Come and have a look or check our website.
<G-vec00086-002-s367><come.herauskommen><de> Kommen Sie und schauen Sie, oder besuchen Sie unsere Website.
<G-vec00086-002-s368><come.herauskommen><en> COME AND TAKE IT AND START WRITING YOUR STORY.....
<G-vec00086-002-s368><come.herauskommen><de> KOMMEN SIE UND NEHMEN SIE ES UND SCHREIBEN SIE IHRE GESCHICHTE.....
<G-vec00086-002-s369><come.herauskommen><en> Come and enjoy with your family and friends at Villa Silvana.
<G-vec00086-002-s369><come.herauskommen><de> Kommen Sie und genießen Sie mit Ihrer Familie und Freunden in der Villa Silvana.
<G-vec00086-002-s370><come.herauskommen><en> If you are a Spanish teacher and want to improve your teaching skills, come and achieve all you need to learn in our seminars and share your experiences with other people in the education industry.
<G-vec00086-002-s370><come.herauskommen><de> Wenn Sie ein Spanischlehrer sind und Ihre Lehrfähigkeiten verbessern möchten, kommen Sie und erreichen Sie alles, was Sie brauchen, um in unseren Seminaren zu lernen und Ihre Erfahrungen mit anderen Menschen in der Bildungsbranche zu teilen.
<G-vec00086-002-s371><come.herauskommen><en> Come to our office (Rent a car Makarska - center) and find out all about the great deals for rental cars from our fleet of over 1000 vehicles.
<G-vec00086-002-s371><come.herauskommen><de> Kommen Sie zu unseren Filialen (Rent a car Makarska - Zentrum) und erfahren alles über das hervorragende Angebot an Mietwagen aus unserer Flotte mit mehr als 1000 Fahrzeugen.
<G-vec00086-002-s372><come.herauskommen><en> Come to order China Mould earlier, it will evident that you are wiser.
<G-vec00086-002-s372><come.herauskommen><de> Kommen Sie China Mould bestellen, und es wird evident, dass Sie klüger sind.
<G-vec00086-002-s373><come.herauskommen><en> Come to the European Academy of Otzenhausen to engage in discussion and enjoy hospitality near the French and Luxembourg borders.
<G-vec00086-002-s373><come.herauskommen><de> Diskutieren Sie mit, kommen Sie an die Europäische Akademie nach Otzenhausen und genießen Sie die Gastfreundschaft in Grenznähe zu Frankreich und Luxemburg.
<G-vec00086-002-s374><come.herauskommen><en> Come with us to one of the most famous regions in Portugal for Food and Wine production.
<G-vec00086-002-s374><come.herauskommen><de> Kommen Sie mit uns in eine der berühmtesten Regionen Portugals für die Lebensmittel- und Weinproduktion.
<G-vec00086-002-s375><come.herauskommen><en> Come and eat with the family and enjoy a delicious Italian pizza while the children enjoy playing.
<G-vec00086-002-s375><come.herauskommen><de> Kommen Sie und essen Sie mit der Familie und genießen Sie eine leckere italienische Pizza, während die Kinder gerne spielen.
<G-vec00086-002-s376><come.herauskommen><en> Come to Ulm – it will make a difference in your life.
<G-vec00086-002-s376><come.herauskommen><de> Kommen Sie nach Ulm, es wird in Ihrem Leben einen Unterschied bewirken.
<G-vec00086-002-s377><come.herauskommen><en> Just come, book it now and you will see for yourself.
<G-vec00086-002-s377><come.herauskommen><de> Kommen Sie einfach, buchen Sie es jetzt und werden Sie selbst sehen.
<G-vec00086-002-s378><come.herauskommen><en> As Iris Mitteraere, Miss Universe France, would say “come taste the beef bourguignon”.
<G-vec00086-002-s378><come.herauskommen><de> Wie Iris Mitteraere, die Miss Universe aus Frankreich, sagen würde: “Kommen Sie und kosten Sie das Beef Bourguignon”.
<G-vec00086-002-s379><come.herauskommen><en> Here come easily in 4 steps to your desired server.
<G-vec00086-002-s379><come.herauskommen><de> Hier kommen Sie bequem in 4 Schritten zu Ihrem Wunschserver.
<G-vec00086-002-s399><come.herauskommen><en> Lights turn on when you come home.
<G-vec00086-002-s399><come.herauskommen><de> Die Lichter gehen an, wenn Du nach Hause kommst.
<G-vec00086-002-s400><come.herauskommen><en> From there you will not come back.
<G-vec00086-002-s400><come.herauskommen><de> Von da kommst du nicht zurück.
<G-vec00086-002-s401><come.herauskommen><en> 9When you have come into the land which Yahweh your God gives you, you shall not learn to imitate the abominations of those nations.
<G-vec00086-002-s401><come.herauskommen><de> 9Wenn du in das Land kommst, das Jehova, dein Gott, dir gibt, so sollst du nicht lernen, nach den Greueln dieser Nationen zu tun.
<G-vec00086-002-s402><come.herauskommen><en> Will you come over and play for me.
<G-vec00086-002-s402><come.herauskommen><de> Kommst du rüber und spielst für mich.
<G-vec00086-002-s403><come.herauskommen><en> If you come with 2 or 3 friends, you get a 10% discount.
<G-vec00086-002-s403><come.herauskommen><de> Wenn Du mit 2 oder 3 Freunden kommst, erhälst Du 10% Rabatt.
<G-vec00086-002-s404><come.herauskommen><en> 5Now is the light of hope reborn in you, for now you come without defense, to learn the part for you within the plan of God.
<G-vec00086-002-s404><come.herauskommen><de> 5Jetzt ist das Licht der Hoffnung in dir wiedergeboren, denn jetzt kommst du ohne Abwehr, um die Rolle für dich innerhalb von Gottes Plan zu lernen.
<G-vec00086-002-s405><come.herauskommen><en> Kill the few guys in the next part, until you come to the gate with the Goal Ring behind it.
<G-vec00086-002-s405><come.herauskommen><de> Erledige die Krabbe und setze deinen Weg nach oben fort, bis du zu den Haien kommst.
<G-vec00086-002-s406><come.herauskommen><en> When you review your life and you come to the conclusion that you are failing you need to change yourself that you pass the test.
<G-vec00086-002-s406><come.herauskommen><de> Wenn du auf dein Leben zurückblickst und du kommst zu dem Schluss dass du versagst musst du dich ändern damit du den Test bestehst.
<G-vec00086-002-s407><come.herauskommen><en> You can't always know if the people you come into contact with have a cold or the flu.
<G-vec00086-002-s407><come.herauskommen><de> Du kannst nicht immer wissen, ob die Personen, mit denen du in Kontakt kommst, eine Erkältung oder die Grippe haben.
<G-vec00086-002-s408><come.herauskommen><en> 31:8 33So my honesty will answer for me later, when you come to look into my wages with you. Every one that is not speckled and spotted among the goats and black among the lambs, if found with me, shall be counted stolen.”
<G-vec00086-002-s408><come.herauskommen><de> 33So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: Was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00086-002-s409><come.herauskommen><en> This is just a sign that Our Lord Jesus wants you to come to Him in humility and ask for help.
<G-vec00086-002-s409><come.herauskommen><de> Dies ist nur ein Zeichen, dass Jesus sich wünscht, dass du demütig zu Ihm kommst und Ihn um Hilfe bittest.
<G-vec00086-002-s410><come.herauskommen><en> When you come and check out the hot European girls on CameraLux, we guarantee it won’t be the only time you...cum.
<G-vec00086-002-s410><come.herauskommen><de> Wenn du kommst und dir die heißen europäischen Flottchen auf CameraLux anschaust, garantieren wir dir, dass es nicht das einzige Mal ist, dass du... kommst.
<G-vec00086-002-s411><come.herauskommen><en> When you do accept My offer, you come to Me in an instant.
<G-vec00086-002-s411><come.herauskommen><de> Sobald du Mein Angebot annimmst, kommst du im Handumdrehen zu Mir.
<G-vec00086-002-s412><come.herauskommen><en> "But it shall come to pass, if you do not obey the voice of the LORD your God, to observe carefully all his commandments and his statutes which I command you today, that all these curses will come upon you and overtake you. "Cursed shall you be in the city, and cursed shall you be in the country.
<G-vec00086-002-s412><come.herauskommen><de> Indem ich dir heute gebiete, den HERRN, deinen Gott, zu lieben, auf seinen Wegen zu gehen und seine Gebote, seine Ordnungen und seine Rechtsbestimmungen zu bewahren, damit du lebst und zahlreich wirst und der HERR, dein Gott, dich segnet in dem Land, wohin du kommst, um es in Besitz zu nehmen.
<G-vec00086-002-s413><come.herauskommen><en> Then, when you cultivate by yourself without a very good environment, the only environment you come into contact with is that type of environment. Then in reality you are being influenced by it, and so it抯 very hard for you to improve.
<G-vec00086-002-s413><come.herauskommen><de> Wenn du dich selbst kultivierst und keine gute Umgebung hast und nur mit solcher Umgebung in Berührung kommst, bist du im Grunde genommen unter dem Einfluss solcher Umgebung, es ist sehr schwer für dich sich zu erhöhen.
<G-vec00086-002-s414><come.herauskommen><en> So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me. to thy word.
<G-vec00086-002-s414><come.herauskommen><de> 30,33 So wird meine Redlichkeit morgen für mich zeugen, wenn du kommst wegen meines Lohnes, den ich von dir nehmen soll: was nicht gefleckt oder bunt unter den Ziegen und nicht schwarz sein wird unter den Lämmern, das sei ein Diebstahl, wenn es sich bei mir findet.
<G-vec00086-002-s415><come.herauskommen><en> Do we that: We proclaim your Death, O Lord, and profess your Resurrection until you come again.
<G-vec00086-002-s415><come.herauskommen><de> Tun wir dies: Deinen Tod - O Herr - verkünden wir, und Deine Auferstehung preisen wir, bis Du kommst in Herrlichkeit.
<G-vec00086-002-s416><come.herauskommen><en> Moving forward is more like the platform you come from.
<G-vec00086-002-s416><come.herauskommen><de> Vorankommen ist mehr wie die Plattform, woher du kommst.
<G-vec00086-002-s417><come.herauskommen><en> I’m so tired… If you come home from work tired, stressed and overwhelmed, data overload could be your problem.
<G-vec00086-002-s417><come.herauskommen><de> Wenn Du von der Arbeit nach Hause kommst und erschöpft, gestresst und überfordert bist, könnte eine Datenüberlastung Dein Problem sein.
<G-vec00086-002-s418><come.herauskommen><en> The color must have come from cocoa powder.
<G-vec00086-002-s418><come.herauskommen><de> Die Farbe kommt von Kakaopulver.
<G-vec00086-002-s419><come.herauskommen><en> Not only because the prophet at that time was called Jmmanuel and not Jesus, but because it is absolutely impossible that the same personality can come into the world twice.
<G-vec00086-002-s419><come.herauskommen><de> Nicht nur, weil der damalige Prophet Jmmanuel und nicht Jesus hieß, sondern weil es absolut unmöglich ist, dass zweimal die gleiche Persönlichkeit auf die Welt kommt.
<G-vec00086-002-s420><come.herauskommen><en> Note, however, that your Roku player does not come with an HDMI cable, so that cable will need to be purchased separately.
<G-vec00086-002-s420><come.herauskommen><de> Beachte jedoch, dass dein Roku Player ohne HDMI-Kabel kommt, du musst es also separat kaufen.
<G-vec00086-002-s421><come.herauskommen><en> There they find relief, refreshment and protection., A Church that is the exemplary disciple of Christ in this too, so that She is eventually able to say to all the nations on earth: come to me, all of you... learn from me, for I am gentle and humble... you will find rest and the yoke will become light.
<G-vec00086-002-s421><come.herauskommen><de> Das Ideal der Kirche besetht darin, daß sie beispielhafte Jüngerin Christi wird, bis zu dem Punkt, an dem sie allen Völkern sagen kann: kommt alle zu mir… lernt von mir, denn ich bin gütig und demütig … ihr werdet Ruhe finden, und das Joch wird leicht werden.
<G-vec00086-002-s422><come.herauskommen><en> The long arm shrimp is about 203 mm long and does come with both sides.
<G-vec00086-002-s422><come.herauskommen><de> Der Krebs ist etwa 203 mm lang und kommt mit beiden Seiten.
<G-vec00086-002-s423><come.herauskommen><en> Because Kṛṣṇa wants to fight, therefore some of His devotees come down to become His enemy.
<G-vec00086-002-s423><come.herauskommen><de> Weil Kṛṣṇa kämpfen will, kommt einer seiner Geweihten herunter, um sein Feind zu werden.
<G-vec00086-002-s424><come.herauskommen><en> This must have been a powerful moment, however the reaction of the shepherds is also quite marvellous: “Let us now go to Bethlehem and see this thing that has come to pass” (cf. Luke 2: 11-15). In their trust in God, they had understood this message.
<G-vec00086-002-s424><come.herauskommen><de> Aber großartig ist die Reaktion der Hirten: „Kommt, lasst uns sehen die Geschichte, die da geschehen ist.“ Sie haben diese Botschaft verstanden in ihrem Vertrauen in Gott.
<G-vec00086-002-s425><come.herauskommen><en> Come along now, stop flirting with the world, return to My Pure Embrace, leave your self-seeking and striving behind you.
<G-vec00086-002-s425><come.herauskommen><de> Kommt jetzt mit, hört auf, mit der Welt zu flirten, kehrt zu Meiner reinen Umarmung zurück, lasst euren Egoismus und euer Streben hinter euch.
<G-vec00086-002-s426><come.herauskommen><en> A professional chef from the VLET will come laden with the finest ingredients and wines to your home to prepare a sophisticated three-course meal of regional dishes using regional produce for you and up to 20 guests.
<G-vec00086-002-s426><come.herauskommen><de> Ein Profikoch des VLET kommt mit edelsten Zutaten und besten Weinen zu Ihnen nach Hause und bereitet für Sie und bis zu 20 Gäste ein regionales hochwertiges Drei-Gänge-Menü zu.
<G-vec00086-002-s427><come.herauskommen><en> Then the adventure continues come back to Cita Shopping Center with different stops to enjoy the beautiful viewpoints of Playa del Inglés.
<G-vec00086-002-s427><come.herauskommen><de> Dann kommt das Abenteuer wieder zum Cita Shopping Center mit verschiedenen Haltestellen, um die herrlichen Aussichtspunkte von Playa del Inglés zu genießen.
<G-vec00086-002-s428><come.herauskommen><en> And the LORD spake unto Moses in mount Sinai, saying, Speak unto the children of Israel, and say unto them, When ye come into the land which I give you, then shall the land keep a sabbath unto the LORD. Six years thou shalt sow thy field, and six years thou shalt prune thy vineyard, and gather in the fruit thereof; But in the seventh year shall be a sabbath of rest unto the land, a sabbath for the LORD: thou shalt neither sow thy field, nor prune thy vineyard.
<G-vec00086-002-s428><come.herauskommen><de> Und der HERR redete mit Mose auf dem Berge Sinai und sprach: Rede mit den Kindern Israel und sprich zu ihnen: Wenn ihr in das Land kommt, das ich euch geben werde, so soll das Land seinen Sabbat dem HERRN feiern, daß du sechs Jahre dein Feld besäest und sechs Jahre deinen Weinberg beschneidest und sammelst die Früchte ein; aber im siebenten Jahr soll das Land seinen großen Sabbat dem HERRN feiern, darin du dein Feld nicht besäen noch deinen Weinberg beschneiden sollst.
<G-vec00086-002-s429><come.herauskommen><en> You're a Shadow Judge come to tell me to pay my alimony....
<G-vec00086-002-s429><come.herauskommen><de> Ihr seid ein Schattenrichter und kommt, um mir zu befehlen, meinen Unterhalt zu bezahlen...
<G-vec00086-002-s430><come.herauskommen><en> Come to visit us daily from 3pm on in the SEZ sports centre, and use the diversity of our offer.
<G-vec00086-002-s430><come.herauskommen><de> Kommt uns täglich ab 15:00 Uhr im SEZ Sportzentrum besuchen, und nutzt die Vielfalt unseres Angebots.
<G-vec00086-002-s431><come.herauskommen><en> Come and see the place where the Lord was laid.
<G-vec00086-002-s431><come.herauskommen><de> Kommt und seht euch die Stelle an, wo er gelegen hat.
<G-vec00086-002-s432><come.herauskommen><en> Therefore, he adds, a reader who does not come from this tradition can find it difficult to understand the original intention of the words.
<G-vec00086-002-s432><come.herauskommen><de> Deshalb, fügt er hinzu, fällt es einem Leser, der nicht aus diesem Traditionskreis kommt, zuweilen schwer, die ursprüngliche Intention der Worte zu verstehen.
<G-vec00086-002-s433><come.herauskommen><en> Run up till you come to the snapping doors.
<G-vec00086-002-s433><come.herauskommen><de> Nach oben laufen bis man zu den zuschnappenden Türen kommt.
<G-vec00086-002-s434><come.herauskommen><en> But the others said, "Wait, let us see whether Elijah will come to save him."
<G-vec00086-002-s434><come.herauskommen><de> Die anderen aber sagten: Lass doch, wir wollen sehen, ob Elija kommt und ihm hilft.
<G-vec00086-002-s435><come.herauskommen><en> The limited edition will come with a Blu-ray disc featuring live and documentary footage from their 2016 RIZE IS BACK tour.
<G-vec00086-002-s435><come.herauskommen><de> Die Limited Edition kommt mit einer Blu-ray Disc, die Livemitschnitte und Dokumentationsmaterial von ihrer RIZE IS BACK-Tour 2016 beinhaltet.
<G-vec00086-002-s436><come.herauskommen><en> 18 But those things which proceed out of the mouth come from the heart, and they defile a man.
<G-vec00086-002-s436><come.herauskommen><de> 18 Was aber aus dem Mund herauskommt, das kommt aus dem Herzen, und das macht den Menschen unrein.
<G-vec00086-002-s589><come.hervortreten><en> Also the cooperation with students regarding bachelor’s and master’s theses as well as compulsory internships, new findings come to light that are included in further product development.
<G-vec00086-002-s589><come.hervortreten><de> Auch bei der Zusammenarbeit mit Studierenden in Hinblick auf Bachelor- und Masterarbeiten sowie Pflichtpraktika treten regelmäßig neue Erkenntnisse zu Tage, die in die weitere Produktentwicklung miteinfließen.
<G-vec00086-002-s590><come.hervortreten><en> Lung cancer typically develops slowly and symptoms often come on gradually.
<G-vec00086-002-s590><come.hervortreten><de> Lungenkrebs entwickelt sich gewöhnlich langsam und die Symptome treten oft schrittweise auf.
<G-vec00086-002-s591><come.hervortreten><en> They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.
<G-vec00086-002-s591><come.hervortreten><de> Und sie sollen hineingehen in mein Heiligtum und vor meinen Tisch treten, mir zu dienen und meine Sitten zu halten.
<G-vec00086-002-s592><come.hervortreten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which lie outside the area of responsibility of the author, a liability obligation would come into force only in the case in which the contents are aware and technically possible and reasonable, the Use in case of illegal content.
<G-vec00086-002-s592><come.hervortreten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00086-002-s593><come.hervortreten><en> In the case of direct or indirect references to third-party websites ("hyperlinks"), which are outside the responsibility of the author, a liability obligation would only come into force in the case in which the author is aware of the contents and is technically possible and reasonable, To prevent the use in the case of unlawful content.
<G-vec00086-002-s593><come.hervortreten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten (“Hyperlinks”), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00086-002-s594><come.hervortreten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which are beyond the scope of responsibility of Ryf Sports, a liability obligation would only come into effect in the case in which Ryf Sports is aware of the content and it technically possible and reasonable to prevent the use of illegal content.
<G-vec00086-002-s594><come.hervortreten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches von Ryf Sports liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem Ryf Sports von den Inhalten Kenntnis hat und es technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00086-002-s595><come.hervortreten><en> emmerich exclusivbrillen GmbH & Co. reserves the right to amend the conditions of the present agreement in part or in full at any time and any such amendments come into force immediately following their publication on the website.
<G-vec00086-002-s595><come.hervortreten><de> emmerich exclusivbrillen GmbH & Co.KG behält sich das Recht vor, die Bestimmungen dieses Vertrages jederzeit, ganz oder teilweise abzuändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Webseite in Kraft.
<G-vec00086-002-s596><come.hervortreten><en> The resolutions passed at the Extraordinary General Meeting of Kaba will come into effect upon completion of the merger.
<G-vec00086-002-s596><come.hervortreten><de> Die Beschlüsse der außerordentlichen Generalversammlung von Kaba treten mit dem Vollzug des Zusammenschlusses in Kraft.
<G-vec00086-002-s597><come.hervortreten><en> Any provision of the Contract that expressly or by implication is intended to come into or continue in force on or after termination shall remain in full force and effect.
<G-vec00086-002-s597><come.hervortreten><de> 8.6 Jedwede Bestimmung des Vertrags, die ausdrücklich oder stillschweigend in Kraft treten oder bei oder nach Kündigung in Kraft bleiben soll, bleibt in Kraft.
<G-vec00086-002-s600><come.hervortreten><en> If amendments are merely insignificant, they shall come into force immediately.
<G-vec00086-002-s600><come.hervortreten><de> Sollte es sich lediglich um unwesentliche Änderungen handeln, treten diese umgehend in Kraft.
<G-vec00086-002-s601><come.hervortreten><en> Everybody shall come in touch with their own greatness, their own divinity.
<G-vec00086-002-s601><come.hervortreten><de> Jeder soll vielmehr mit seiner eigenen Größe, seiner eigenen Göttlichkeit in Verbindung treten.
<G-vec00086-002-s602><come.hervortreten><en> All direct or indirect references to other Internet sites (links), which lie outside the area of responsibility of the author, any liability obligation would only come into effect if the author is aware of the contents, and it would be technically possible and reasonable for him to prevent the use in the event of illegal contents.
<G-vec00086-002-s602><come.hervortreten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00086-002-s603><come.hervortreten><en> Straight line projection of the zone upwards indicates that it will come to surface (likely under till cover) very near the north boundary of the Burns Block.
<G-vec00086-002-s603><come.hervortreten><de> Die geradlinige Weiterführung der Zone nach oben weist darauf hin, dass sie sehr nahe an der nördlichen Grenze des Burns Blocks zu Tage treten wird (wahrscheinlich unterhalb einer Geschiebemergelschicht).
<G-vec00086-002-s604><come.hervortreten><en> The changed terms and conditions come in the place of the previous version of the General Terms and Conditions.
<G-vec00086-002-s604><come.hervortreten><de> Die geänderten Bedingungen treten an die Stelle der vorhergehenden allgemeinen Geschäftsbedingungen.
<G-vec00086-002-s605><come.hervortreten><en> In the case of direct or indirect references to external websites („links“), which are outside the responsibility of the website operator, a liability obligation would only come into force in the case where the website operator is aware of the contents and it is technically possible for him And it would be reasonable to prevent the use of illegal contents.
<G-vec00086-002-s605><come.hervortreten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00086-002-s607><come.hervortreten><en> The new prices will come into force from the announcement of the regulation. The cost of transport and other expenses are calculated separately.
<G-vec00086-002-s607><come.hervortreten><de> Die neuen Preise treten mit der Bekanntgabe der Verordnung in Kraft, die Kosten für Transport und Sonstiges werden gesondert berechnet.
