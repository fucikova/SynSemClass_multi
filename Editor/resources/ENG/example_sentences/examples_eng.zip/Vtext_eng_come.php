<G-vec00078-001-s019><come.besuchen><en> Contact Activities Come and meet us at Bauma 2019 in Munich.
<G-vec00078-001-s019><come.besuchen><de> Kontakt Aktivitäten Besuchen Sie uns auf der Bauma 2019 in München.
<G-vec00078-001-s020><come.besuchen><en> You should not want to pick the first lawyer you come across.
<G-vec00078-001-s020><come.besuchen><de> You suchen sollte, wie die Wahl der ersten Anwalt Rausfinden vielleicht das Gefühl, die Sie besuchen.
<G-vec00078-001-s021><come.besuchen><en> Come and talk to us at one of our branches or contact KBC Live.
<G-vec00078-001-s021><come.besuchen><de> Besuchen Sie eine unserer Filialen oder kontaktieren Sie KBC Live.
<G-vec00078-001-s022><come.besuchen><en> Come to the Bike Library in Civic Park anytime 11am - 4pm for a workshop on fixing a bike.
<G-vec00078-001-s022><come.besuchen><de> Besuchen Sie die Bike Library im Civic Park jederzeit zwischen 11 und 16 Uhr, um einen Workshop zum Reparieren eines Fahrrads zu erhalten.
<G-vec00078-001-s023><come.besuchen><en> 29:10 For this is what the Lord has said: When seventy years are ended for Babylon, I will have pity on you and give effect to my good purpose for you, causing you to come back to this place.
<G-vec00078-001-s023><come.besuchen><de> 29:10 Denn so spricht der HERR: Wenn zu Babel siebenzig Jahre aus sind, so will ich euch besuchen und will mein gnädiges Wort über euch erwecken, daß ich euch wieder an diesen Ort bringe.
<G-vec00078-001-s024><come.besuchen><en> Take a break from the usual sightseeing and shopping and come Play In The Clay with a 3-4 hour introductory Pottery Wheel Class.
<G-vec00078-001-s024><come.besuchen><de> Machen Sie eine Pause von den üblichen Sightseeing- und Shopping-Touren und besuchen Sie Play In The Clay mit einer 3-4-stündigen Einführung in die Töpferscheibe.
<G-vec00078-001-s025><come.besuchen><en> It’s so important to see and touch products and to get to know the people behind them – come and meet us at our next events.
<G-vec00078-001-s025><come.besuchen><de> Produkte zu sehen und anzufassen und die Menschen hinter dem Produkt zu kennen ist wichtig - Besuchen Sie uns auf unseren Messeständen.
<G-vec00078-001-s026><come.besuchen><en> Come see us soon and get into the fun and the sun.
<G-vec00078-001-s026><come.besuchen><de> Besuchen Sie uns bald und sich in dem Spaß und der Sonne.
<G-vec00078-001-s027><come.besuchen><en> Come see us at stall D16 and get to know our new products.
<G-vec00078-001-s027><come.besuchen><de> Besuchen Sie uns an unserem Messestand D16 und machen Sie sich mit unseren Neuheiten vertraut.
<G-vec00078-001-s028><come.besuchen><en> "Come to the exhibition Motorrader 2014 and learn all about the ""iron horses"" feel the real drive and thirst for speed."
<G-vec00078-001-s028><come.besuchen><de> "Besuchen Sie die Ausstellung Motorräder 2014 und erfahren Sie alles über den ""Eisernen Pferde"" fühlen die echte Laufwerk und Durst nach Geschwindigkeit."
<G-vec00078-001-s029><come.besuchen><en> If you're interested in the comfort of your dropshipping shop customers, come to BigBuy and purchase our range of wellbeing products, like the fun Big Tribe Snug Snug blanket with sleeves, at wholesale price.
<G-vec00078-001-s029><come.besuchen><de> Wenn Ihnen der Komfort der Kunden Ihres Dropshipping-Shops am Herzen liegt, dann besuchen Sie BigBuy und kaufen Sie unsere große Auswahl an Wohlfühl-Produkten wie die Big Tribe Snug Snug Decke mit Ärmeln zum Großhandelspreis.
<G-vec00078-001-s030><come.besuchen><en> So come join us for a game of Innocence or Temptation online slots.
<G-vec00078-001-s030><come.besuchen><de> Besuchen Sie uns also und spielen Sie den Online Spielautomaten Innocence or Temptation.
<G-vec00078-001-s031><come.besuchen><en> It will be record-breaking appearance for David in Denver, as he will come back to the best NHL town in the USA for the fifth time.
<G-vec00078-001-s031><come.besuchen><de> Für David wird es ein neuer Eurolanche Rekord, da er bereits das fünfte mal die beste NHL Stadt der USA besuchen wird.
<G-vec00078-001-s032><come.besuchen><en> The islet of Paolina owes its fame and its name to the sister of Napoleon Bonaparte (Paolina Borghese), who during the period of exile of his brother Emperor, liked to come to this place to sunbathe and swim.
<G-vec00078-001-s032><come.besuchen><de> Die Isolotto della Paolina verdankt ihren Ruhm und ihren Nahmen der Schwester von Napoleon Bonaparte (Paolina Borghese), die es während des Exils ihres Bruders liebte, diesen Ort zum sonnen und schwimmen gehen zu besuchen.
<G-vec00078-001-s033><come.besuchen><en> Come check us out, we're waiting to meet you!Please Note: Though we make every attempt to do so, we cannot guarantee that everyone in your party will be able to stay in the same room.
<G-vec00078-001-s033><come.besuchen><de> Besuchen Sie uns noch, wir warten auf Sie!Bitte beachten Sie: Obwohl wir jeden Versuch, dies zu tun zu machen, knnen wir nicht garantieren, dass jeder in Ihrer Partei in der Lage, im selben Raum bleiben.
<G-vec00078-001-s034><come.besuchen><en> “We have come to the exhibition to share our information on the latest Snack trends and to exchange information between snack producers and suppliers”, says Charlotte Huggins, Business Development Director at Symrise.
<G-vec00078-001-s034><come.besuchen><de> “Wir besuchen die Messe, um über aktuelle Snack-Trends zu informieren und Informationen zwischen Snack-Herstellern und -anbietern auszutauschen“, erklärt Charlotte Huggins, Business Development Director bei Symrise.
<G-vec00078-001-s035><come.besuchen><en> Come to this city in Andalusia and make your business meeting into something unforgettable.
<G-vec00078-001-s035><come.besuchen><de> Besuchen Sie diese Stadt in Andalusien und machen Sie Ihre geschäftliche Sitzung zu etwas Unvergesslichem.
<G-vec00078-001-s036><come.besuchen><en> Come and try out this unique two-story indoor kart racing track in Olomouc.
<G-vec00078-001-s036><come.besuchen><de> Besuchen Sie die außergewöhnliche überdachte zweigeschossige Kartrennbahn in Olomouc.
<G-vec00078-001-s037><come.besuchen><en> If you end up near this area, you should certainly come to Honeymoon Valley; trust us - you will not regret it.
<G-vec00078-001-s037><come.besuchen><de> Wenn Sie verursachen in diesem Bereich setzen, achten Sie darauf das Honey Valley besuchen, vertrauen Sie, werden Sie nicht bereuen.
<G-vec00078-001-s171><come.gehen><en> < 6:6 All the days that he separateth himself unto Jehovah he shall not come near to a dead body.
<G-vec00078-001-s171><come.gehen><de> < 6:6 Während der ganzen Zeit, für welche er sich dem HERRN geweiht hat, soll er zu keinem Toten gehen.
<G-vec00078-001-s172><come.gehen><en> 7:12 And the king arose in the night, and said unto his servants, I will now shew you what the Syrians have done to us. They know that we be hungry; therefore are they gone out of the camp to hide themselves in the field, saying, When they come out of the city, we shall catch them alive, and get into the city.
<G-vec00078-001-s172><come.gehen><de> 7:12 Und der König stand in der Nacht auf und sprach zu seinen Knechten: Ich will euch doch sagen, was die Syrer mit uns vorhaben: Sie wissen, daß wir Hunger leiden, und sind aus dem Lager gegangen, um sich im Felde zu verbergen, und denken: Wenn die aus der Stadt gehen, wollen wir sie lebendig fangen und in die Stadt eindringen.
<G-vec00078-001-s173><come.gehen><en> Significantly reduced charging times will come with the introduction of fast charging by the Combined Charging System (CCS).
<G-vec00078-001-s173><come.gehen><de> Deutlich reduzierte Ladezeiten gehen mit der Einführung des Schnellladens via Combined Charging System (CCS) einher.
<G-vec00078-001-s174><come.gehen><en> "Calling for a ""People's Democratic Revolution"", founding leader Charu Mazumdar wrote in 1970 that ""the majority of the business community will come with us."
<G-vec00078-001-s174><come.gehen><de> "In seinem Aufruf zu einer ""Demokratischen Volksrevolution"" schrieb ihr Gründer und Führer Charu Mazumdar 1970, dass ""die Mehrheit der Geschäftswelt mit uns gehen wird."
<G-vec00078-001-s175><come.gehen><en> That will enable the transition from the old system to the new to come about without the dam breaking, so to say.
<G-vec00078-001-s175><come.gehen><de> Das wird den Übergang vom alten in das neue System sozusagen ohne Dammbruch vonstatten gehen lassen.
<G-vec00078-001-s176><come.gehen><en> From the medium quality elements and a second churning, come the seven golden mountains.
<G-vec00078-001-s176><come.gehen><de> Aus den Elemente mittlerer Qualität und einem zweiten Prozess des Aufwühlens gehen die sieben goldenen Bergketten hervor.
<G-vec00078-001-s177><come.gehen><en> Bahr once stated that his policies were based on the core axiom that “people have to come first” and that “every conceivable and responsible attempt” must be made to improve their lives and their prospects for the future.
<G-vec00078-001-s177><come.gehen><de> Bahr hatte als Grundaxiom seiner Politik einmal festgehalten – und ich zitiere – dass es „zunächst um die Menschen zu gehen“ hat „und um die Ausschöpfung jedes denkbar und verantwortbaren Versuchs“, deren Leben und deren Zukunftschancen zu verbessern.
<G-vec00078-001-s178><come.gehen><en> It's important to me that my co-workers like to come to work and enjoy it.
<G-vec00078-001-s178><come.gehen><de> Mir ist es wichtig, dass meine Mitarbeiter gerne zur Arbeit gehen und Spaß daran haben.
<G-vec00078-001-s179><come.gehen><en> If one day, large spectacular festivals of world music were jointly organized, then a great dream would have come true.
<G-vec00078-001-s179><come.gehen><de> Wenn es eines Tages spektakuläre, gemeinsam veranstaltete größere Festivals der Weltmusik geben könnte, würde ein großer Traum in Erfüllung gehen.
<G-vec00078-001-s180><come.gehen><en> If you save and restart at this point, you don ́t even have to bother, you can deliver your photo, come back and you will find her at the front door of this room.
<G-vec00078-001-s180><come.gehen><de> Wenn du an dieser Stelle speicherst und neu startest ist es noch einfacher, du kannst das Foto abliefern gehen und findest sie anschließend an der Tür von diesem Raum wieder.
<G-vec00078-001-s181><come.gehen><en> Walk between the Bijenkorf and River Island, through the Chinese gate. Follow this road for 450 m until you come to the canal, where you will turn right.
<G-vec00078-001-s181><come.gehen><de> Gehen Sie zwischen dem Kaufhaus Bijenkorf und River Island unter dem chinesischen Tor hindurch und folgen Sie diesem Weg 450 Meter bis an die Gracht, wo Sie nach rechts gehen.
<G-vec00078-001-s182><come.gehen><en> Superior protection doesn't have to come at the cost of comfort or control.
<G-vec00078-001-s182><come.gehen><de> Überlegener Schutz muss nicht auf Kosten von Komfort und Kontrolle gehen.
<G-vec00078-001-s183><come.gehen><en> With the right financing, your dream of owning your own home can come true faster than you can imagine.
<G-vec00078-001-s183><come.gehen><de> Ihre Hypothek Mit der passenden Finanzierung kann der Traum vom Eigenheim schneller in Erfüllung gehen, als Sie es sich vorstellen.
<G-vec00078-001-s184><come.gehen><en> Now we come to the most spectacular features.
<G-vec00078-001-s184><come.gehen><de> Wir gehen nun auf die spektakulärsten Eigenschaften ein.
<G-vec00078-001-s185><come.gehen><en> However, with that the Merkel era will also come to an end .
<G-vec00078-001-s185><come.gehen><de> Damit wird aber auch die Ära Merkel zu Ende gehen.
<G-vec00078-001-s186><come.gehen><en> A wish that, at least on vacation in Salzburg come true, because there are several castle hotels.
<G-vec00078-001-s186><come.gehen><de> Ein Wunsch, der zumindest im Urlaub in Salzburg in Erfüllung gehen kann, denn hier gibt es gleich mehrere Schlosshotels.
<G-vec00078-001-s187><come.gehen><en> It is advisable to start looking as soon as possible and before you come to Germany.
<G-vec00078-001-s187><come.gehen><de> Deswegen raten wir Ihnen möglichst vor Beginn Ihres Aufenthalts in Deutschland auf Wohnungssuche zu gehen.
<G-vec00078-001-s188><come.gehen><en> Unmarried, but not lonely female Maidens come this year to the long-awaited, deserved final stage of check on durability with the beloved.
<G-vec00078-001-s188><come.gehen><de> Unverheiratet, aber die nicht einsamen Frauen-Jungfrauen gehen in diesem Jahr auf die langersehnte, verdiente abschließende Etappe der Prüfung auf die Haltbarkeit mit den Geliebten hinaus.
<G-vec00078-001-s189><come.gehen><en> My holidays come to an end.
<G-vec00078-001-s189><come.gehen><de> Meine Ferien gehen zu Ende.
<G-vec00042-001-s190><come.kommen><en> 21 Then they said one to another, We are indeed guilty concerning our brother, whose anguish of soul we saw when he besought us, and we did not hearken; therefore this distress is come upon us.
<G-vec00042-001-s190><come.kommen><de> 21 Da sprachen sie einer zum anderen: Fürwahr, wir sind schuldig (O. wir büßen) wegen unseres Bruders, dessen Seelenangst wir sahen, als er zu uns flehte, und wir hörten nicht; darum ist diese Drangsal über uns gekommen.
<G-vec00042-001-s191><come.kommen><en> Since I previously had a questionable customers on ebay, it seems likely that it is so come to my account number ran.
<G-vec00042-001-s191><come.kommen><de> Da ich zuvor einen fragwürdigen Kunden bei ebay hatte, liegt die Vermutung nahe, dass man so an meine Kontonummer ran gekommen ist.
<G-vec00042-001-s192><come.kommen><en> The day has come when the dead arose from their graves and started roaming the lands.
<G-vec00042-001-s192><come.kommen><de> Der Tag ist gekommen, wenn die Toten aus ihren Gräbern stand auf und begann durch die Lande.
<G-vec00042-001-s193><come.kommen><en> Through symbols and prophecies, God shows how and when the infilling of the Holy Spirit would take place; and also what would happen when this wonderful Spirit has come - His signs, His work in the people through HIM.
<G-vec00042-001-s193><come.kommen><de> Durch Symbole und Weissagungen zeigt Gott, wie und wann die Erfüllung durch den heiligen Geist geschehen würde und was geschehen wird, wenn dieser wunderbare Geist gekommen ist, Seine Zeichen, Seine Arbeit in den Menschen durch IHN.
<G-vec00042-001-s194><come.kommen><en> The time has come for religious leaders to cooperate more effectively in the work of healing wounds, resolving conflicts and pursuing peace.
<G-vec00042-001-s194><come.kommen><de> Die Zeit ist gekommen, dass die Religionsführer wirksamer zusammenarbeiten, um die Wunden zu heilen, Konflikte zu lösen und Frieden zu suchen.
<G-vec00042-001-s195><come.kommen><en> Now therefore, behold, the cry of the children of Israel is come unto me: and I have also seen the oppression wherewith the Egyptians oppress them. Come now therefore, and I will send thee unto Pharaoh, that thou mayest bring forth my people the children of Israel out of Egypt.
<G-vec00042-001-s195><come.kommen><de> Weil nun das Geschrei der Kinder Israel vor mich gekommen ist, und ich auch dazu ihre Angst gesehen habe, wie die Aegypter sie aengsten, so gehe nun hin, ich will dich zu Pharao senden, dass du mein Volk, die Kinder Israel, aus Aegypten fuehrest.
<G-vec00042-001-s196><come.kommen><en> 43a I have come in my Father's name,...
<G-vec00042-001-s196><come.kommen><de> 43a Ich bin gekommen in meines Vaters Namen...
<G-vec00042-001-s197><come.kommen><en> "So, now it seems that we have come to the last layer when we hear: ""If there are indeed people who are being persecuted, I will feel sympathetic."""
<G-vec00042-001-s197><come.kommen><de> "Nun scheint es so, dass wir zu der letzten Schicht gekommen sind, wenn wir hören: ""Wenn es in der Tat Menschen gibt, die verfolgt werden, werde ich Mitgefühl empfinden""."
<G-vec00042-001-s198><come.kommen><en> Solitude is one of the blessings that have come to characterise this, the sunniest island in the Mediterranean.
<G-vec00042-001-s198><come.kommen><de> Einsamkeit ist eines des Segens, das gekommen ist, um die sonnigste Insel im Mittelmeer zu charakterisieren.
<G-vec00042-001-s199><come.kommen><en> """Space Opera has again come to a planet on which we live."
<G-vec00042-001-s199><come.kommen><de> """Die Weltraumoper ist wieder einmal zu einem Planeten gekommen, auf dem wir leben."
<G-vec00042-001-s200><come.kommen><en> I wish you carry these flags back to your own countries, and tell them the message that the time has come for our resurrection, that we have to rise.
<G-vec00042-001-s200><come.kommen><de> Es ist mein Wunsch, dass ihr diese Fahnen in eure Länder zurückbringt und ihnen die Botschaft vermittelt, dass wir wachsen müssen, denn die Zeit der Auferstehung ist gekommen.
<G-vec00042-001-s201><come.kommen><en> The response to this initiative has proved so positive, that we are going to prepare many more channelers in different countries, so that human beings who are still doubtful about this new reality, cannot have but the best evidence that we are here and we have come to help in the healing process of Gaia and the ascension of all the kingdoms that are present on her.
<G-vec00042-001-s201><come.kommen><de> Die Antwort auf diese Initiative hat sich so positiv erwiesen, dass wir noch viel mehr Channels in verschiedenen Laendern vorbereiten, damit Menschen, die immer noch diese neue Realitaet anzweifeln, nur den allerbesten Beweis dafuer haben, dass wir hier sind und dass wir gekommen sind, um beim Heilungsprozess von Gaia und dem Aufstieg all der Reiche, die auf ihr existieren, zu helfen.
<G-vec00042-001-s202><come.kommen><en> Thus you know that your life on earth is limited and that no-one can prevent his body's death when his hour has come....
<G-vec00042-001-s202><come.kommen><de> Also das eine wisset ihr, daß euer Sein auf Erden begrenzt ist und daß keiner sich wehren kann gegen den Leibestod, wenn seine Stunde gekommen ist....
<G-vec00042-001-s203><come.kommen><en> "For if those words of Christ and Peter are to be understood figuratively, they are not to be made to bear the meaning those people claim, but they are to be related to the meaning of that sword of which Matthew writes in this way: ""Think not that I am come to send peace on earth: I came not to send peace, but a sword."
<G-vec00042-001-s203><come.kommen><de> Will man jene Worte Christi und Petri sinnbildlich nehmen, so sind sie doch nicht auf Das, was meine Gegner sagen, zu beziehen, sondern auf die Bedeutung jenes Schwertes, von welchem Matthäus schreibt: Glaubet nicht, daß ich in die Welt gekommen bin, den Frieden zu bringen: nicht bin ich gekommen, den Frieden zu bringen, sondern das Schwert.
<G-vec00042-001-s204><come.kommen><en> "47:4 They also said to him, ""We have come to live here awhile, because the famine is severe in Canaan and your servants' flocks have no pasture."
<G-vec00042-001-s204><come.kommen><de> 47:4 Und sagten weiter zum Pharao: Wir sind gekommen, bei euch zu wohnen im Lande; denn deine Knechte haben nicht Weide für ihr Vieh, so hart drückt die Hungersnot das Land Kanaan.
<G-vec00042-001-s205><come.kommen><en> "Even before his title ""So wie du"" Anka had come into contact with the German language: The soundtrack to the movie of the same name contains the song ""Verboten""."
<G-vec00042-001-s205><come.kommen><de> "Schon vor seinem Titel ""So wie du"" war Anka mit der deutschen Sprache in Berührung gekommen: Aus dem Soundtrack zum gleichnamigen Kinofilm stammt der Song ""Verboten""."
<G-vec00042-001-s206><come.kommen><en> Now that we have a booted system, the time has come to start the actual installation.
<G-vec00042-001-s206><come.kommen><de> Jetzt nach dem Neustart des Systems ist die Zeit gekommen, die Installation zu starten.
<G-vec00042-001-s207><come.kommen><en> I knew this was the book I had come in to buy.
<G-vec00042-001-s207><come.kommen><de> Ich wußte, daß ich gekommen war, um dieses Buch zu kaufen.
<G-vec00042-001-s208><come.kommen><en> Sanguinetti had come to California in the early 1850’s during the gold rush.
<G-vec00042-001-s208><come.kommen><de> Sanguinetti war in den frühen 1850er Jahren während des Goldrausches nach Kalifornien gekommen..
<G-vec00042-001-s266><come.kommen><en> And, of course, the Japanese company's icon wasn't going to be left out and come along in the form of the above-mentioned Super Mario 64 that has eventually become a classic and has been copied time after time on PC but now with an online version to be able to play in multiplayer mode.
<G-vec00042-001-s266><come.kommen><de> Und natÃ1⁄4rlich wurde die Ikone des japanischen Unternehmens nicht ausgelassen und kam in Form des oben erwähnten Super Mario 64, der schließlich zu einem Klassiker geworden ist und zeitweise auf dem PC kopiert wurde, aber jetzt mit einem Online-Version, um im Multiplayer-Modus spielen zu können.
<G-vec00042-001-s267><come.kommen><en> "The Net, or rather the counter-Net, assumes the promise of an integral aspect of the TAZ, an addition that will multiply its potential, a ""quantum jump"" (odd how this expression has come to mean a big leap) in complexity and significance."
<G-vec00042-001-s267><come.kommen><de> Das Netz, oder vielmehr das Gegen-Netz, wird zu einem integralen Aspekt der TAZ, einer Bereicherung zur Entfaltung ihres Potentials, einem »Quantensprung« (seltsam, wie dieser Begriff zur Bedeutung großer Sprung kam) in Komplexität und Signifikanz.
<G-vec00042-001-s268><come.kommen><en> There was also a chapel here, but there was little morality in this place, and the population did not come to holy mass or confession, nor did they marry each other or let the children be baptized, so the priest who had been here at first, to avoid starvation, had been forced to leave the place.
<G-vec00042-001-s268><come.kommen><de> Es existierte hier auch eine Kapelle da aber an diesem Orte wenig Moral herrschte und die Bevölkerung weder zur Messe noch zur Beichte kam noch sich trauen oder die Kinder taufen ließ, so hatte sich der anfangs hier weilende Pater, um nicht zu verhungern, gezwungen gesehen, den Ort wieder zu verlassen.
<G-vec00042-001-s269><come.kommen><en> Rather quickly he had come to the conclusion that his company could survive only by adapting to the new market conditions.
<G-vec00042-001-s269><come.kommen><de> Und binnen kurzem kam er zu der Einsicht, dass sein Unternehmen nur überleben konnte, wenn er sich den Marktgegebenheiten stellte.
<G-vec00042-001-s270><come.kommen><en> Just as the time has finally come when in individual States a system of private vendetta and reprisal has given way to the rule of law, so too a similar step forward is now urgently needed in the international community.
<G-vec00042-001-s270><come.kommen><de> Wie in den einzelnen Staaten endlich der Zeitpunkt kam, wo an die Stelle des Systems der persönlichen Rache und Vergeltung die Herrschaft des Gesetzes trat, so ist es jetzt dringend notwendig, daß in der internationalen Völkergemeinschaft ein ähnlicher Fortschritt stattfindet.
<G-vec00042-001-s271><come.kommen><en> in mind, convinced by that time that I had come here, into this material world, with a number of cards in my hand, and that I had the duty to do something with them.In the years that followed, I started playing music again, I started writing, and I became a visual artist.
<G-vec00042-001-s271><come.kommen><de> "Nach meiner Erfahrung, behielt ich immer diesen Satz im Kopf, ""Was hast du mit deinen Talenten gemacht?, inzwischen überzeugt dass ich hierher in diese materielle Welt kam mit einer Anzahl von Karten in der Hand, und dass ich die Pflicht hatte etwas damit anzufangen."
<G-vec00042-001-s272><come.kommen><en> and when she was come to King Solomon, she told him all that was in her heart.
<G-vec00042-001-s272><come.kommen><de> Und als sie zu Salomo kam, sagte sie ihm alles, was sie auf dem Herzen hatte.
<G-vec00042-001-s273><come.kommen><en> Sport should evolve and computer sports based on computer gaming becoming commonplace should not come as a surprise.
<G-vec00042-001-s273><come.kommen><de> Der Sport sollte sich weiterentwickeln, und es kam nicht überraschend, dass Computer Sport basierend auf Computerspielen zur Normalität wurde.
<G-vec00042-001-s274><come.kommen><en> If a girl readily agrees to the meeting, and leaves them happy and inspired, so, the time has come of the proposal.
<G-vec00042-001-s274><come.kommen><de> Wenn ein Mädchen leicht erklärt und geht auf die treffen mit Ihnen glücklich und beflügelt, also, kam zum Zeitpunkt der Angebotserstellung.
<G-vec00042-001-s275><come.kommen><en> The demand of students, who had come to talk about their future, was first rejected.
<G-vec00042-001-s275><come.kommen><de> Der Dorfschützer Murat Ücgül kam dabei ums Leben, Yilmaz Kaya wurde schwer verletzt.
<G-vec00042-001-s276><come.kommen><en> Drummer Martin gave his glass to him, when he had to quickly come to solve a technical problem.
<G-vec00042-001-s276><come.kommen><de> Drummer Martin drückte ihm seins in die Hände, als er kurz ein technisches Problem lösen kam.
<G-vec00042-001-s277><come.kommen><en> There did come a Man on the earth greater than Moses, and His greatness was superior greatness even to that of Moses.
<G-vec00042-001-s277><come.kommen><de> Da kam ein Mann auf diese Erde, der größer war als Mose, und seine Größe übertraf selbst diejenige von Moses.
<G-vec00042-001-s278><come.kommen><en> When Uriah had come to him, David asked how Joab was doing, and how the people were doing, and how the war prospered.
<G-vec00042-001-s278><come.kommen><de> Und Uria kam zu ihm, und David fragte nach dem Wohlergehen Joabs und nach dem Wohlergehen des Volkes und nach der Kriegslage.
<G-vec00042-001-s279><come.kommen><en> I had come to terms with the fact that once I, my ego consciousness, left the body, my mind-created world also disappeared.
<G-vec00042-001-s279><come.kommen><de> "Ich kam zu den Bedingungen mit der Tatsache, daß einmal – ich, mein ""EGO-Bewußtsein"" meinen Körper verläßt, meine Geist-erschaffene Welt aber genauso verschwinden wird....."
<G-vec00042-001-s280><come.kommen><en> And when the hour was come, he placed himself at table, and the [twelve] apostles with him.
<G-vec00042-001-s280><come.kommen><de> Und da die Stunde kam, setzte er sich nieder und die zwölf Apostel mit ihm.
<G-vec00042-001-s281><come.kommen><en> 23 And it happened when Joseph had come to his brothers, they stripped Joseph out of his tunic, the tunic reaching to the soles of his feet that was on him. 24 And they took him and threw him into a pit. And the pit was empty, with no water in it.
<G-vec00042-001-s281><come.kommen><de> 23 Und es geschah, als Joseph zu seinen Brüdern kam, da zogen sie Joseph seinen Leibrock aus, den langen Leibrock, den er anhatte; 24 und sie nahmen ihn und warfen ihn in die Grube; die Grube aber war leer, es war kein Wasser darin.
<G-vec00042-001-s282><come.kommen><en> I had the good fortune of having my success come very late and you've stabilised a bit by then.
<G-vec00042-001-s282><come.kommen><de> Ich hatte ja das Glück, dass mein Erfolg sehr spät kam und da ist man dann schon ein bisschen gefestigt.
<G-vec00042-001-s283><come.kommen><en> And when he was come into the house from the multitude, his disciples asked him the parable.
<G-vec00042-001-s283><come.kommen><de> Und da er von dem Volk ins Haus kam, fragten ihn seine Jünger um dies Gleichnis.
<G-vec00042-001-s284><come.kommen><en> The invite had come from Algis Kizys, the former bassist of the Swans and Vincent Signorelli, Unsane's drummer.
<G-vec00042-001-s284><come.kommen><de> Die Einladung kam von Algis Kizys, dem ehemaligen Bassisten der Swans und Vincent Signorelli, Unsane's Schlagzeuger.
<G-vec00042-001-s285><come.kommen><en> Many pharisees come from poor sectors of the population.
<G-vec00042-001-s285><come.kommen><de> Viele Pharisäer kamen aus den armen Schichten der Bevölkerung.
<G-vec00042-001-s286><come.kommen><en> Speakers and researchers from all over the world come here to present their findings.
<G-vec00042-001-s286><come.kommen><de> Sprecher und Forscher aus der ganzen Welt kamen her um ihre Forschungsergebnisse zu präsentieren.
<G-vec00042-001-s287><come.kommen><en> Only small rests have kept from the trees, which were cemented so that they did not come apart and so that they are preserved for future generations.
<G-vec00042-001-s287><come.kommen><de> Nur kleine Reste haben von den Bäumen gehalten, die zementiert waren, damit sie nicht auseinander kamen und damit sie für zukünftige Erzeugungen konserviert werden.
<G-vec00042-001-s288><come.kommen><en> As always we are grateful to all the birds who have come to eat and all bird watchers who engaged themselves in the doings of the birds.
<G-vec00042-001-s288><come.kommen><de> Wie immer sind wir allen Vögeln die zum Fressen kamen dankbar und allen Vogelbeobachtern die sich mit dem Verhalten der Vögel beschäftigt haben.
<G-vec00042-001-s289><come.kommen><en> We come to the city with our team of three people as guests of Şanlıurfa Governorate and learn that 2011 excavation works have been cancelled.
<G-vec00042-001-s289><come.kommen><de> Wir kamen als Gäste des Gouverneurs im Team von drei Personen und mussten erfahren, das die Ausgrabungen für 2011 gestrichen worden waren.
<G-vec00042-001-s290><come.kommen><en> 5 The isles have seen, and fear; the ends of the earth tremble; they draw near, and come.
<G-vec00042-001-s290><come.kommen><de> 5 Da das die Inseln sahen, fürchteten sie sich, und die Enden der Erde erschraken; sie naheten und kamen herzu.
<G-vec00042-001-s291><come.kommen><en> From the early centuries of Christianity the real reason that urged pilgrims to come to Rome was the desire to pray at the tombs of the apostles.
<G-vec00042-001-s291><come.kommen><de> Seit der ersten Jahrhunderte des Christentums waren die Pilger, die nach Rom kamen, von dem Wunsch getrieben, an den Gräbern der Apostel zu beten.
<G-vec00042-001-s292><come.kommen><en> After a visit to the first cigar trade JJ Fox Cigar Merachant, where we're happy they made the annual cigars, Hoyo de Monterrey, We will come to the end of the street 9 St. James or. its crossing with Pall Mall, where was dounítkový shop devoted to the brand Alfred Dunhill.
<G-vec00042-001-s292><come.kommen><de> Nach dem Besuch der ersten Zigarren-Shop JJ-Fox Zigarre Merachant, Wo bekommen wir das Vergnügen gemacht Hoyo de Monterrey Zigarren jährliche, Wir kamen bis zum Ende der Straße 9 St. James bzw.. die Kreuzung mit der Pall Mall, Wo war der Dounítkový-Shop der Marke Alfred Dunhill gewidmet.
<G-vec00042-001-s293><come.kommen><en> Near Sabunike is situated a famous Nin Lagoon which is explored by lots of people who come to convince in recovering characteristics of the mud.
<G-vec00042-001-s293><come.kommen><de> Nahe Sabunike liegt die berühmte Nin Lagoon, die von vielen Menschen besucht wird, die kamen, um sich von der heilenden Wirkung des Schlamms zu überzeugen.
<G-vec00042-001-s294><come.kommen><en> They had come from thousands of miles away.
<G-vec00042-001-s294><come.kommen><de> Sie kamen von Tausenden von Meilen entfernt.
<G-vec00042-001-s295><come.kommen><en> """ 38:27 All the officials did come to Jeremiah and question him, and he told them everything the king had ordered him to say."
<G-vec00042-001-s295><come.kommen><de> 38:27 Da kamen alle Oberen zu Jeremia und fragten ihn, und er antwortete ihnen, wie ihm der König befohlen hatte.
<G-vec00042-001-s296><come.kommen><en> The few could see it as the officer ordered that in large quantities did not come.
<G-vec00042-001-s296><come.kommen><de> Wenige konnten es sehen, da der Offizier befohlen hat, dass in großen Mengen nicht kamen.
<G-vec00042-001-s297><come.kommen><en> We used to come here with our goats, there would be fish in the sea and dates on the trees for the Bedouins.
<G-vec00042-001-s297><come.kommen><de> Wir kamen mit unseren Ziegen her, für die Beduinen waren immer Fische im Meer und Datteln an den Bäumen.
<G-vec00042-001-s298><come.kommen><en> 20 They are ashamed because they were confident; they come there and are disappointed.
<G-vec00042-001-s298><come.kommen><de> 20 Sie wurden beschämt, weil sie auf sie vertraut hatten, sie kamen hin und wurden zuschanden.
<G-vec00042-001-s299><come.kommen><en> 21:17 And when we had come to Jerusalem, the brethren received us gladly.
<G-vec00042-001-s299><come.kommen><de> 21:17 Da wir nun gen Jerusalem kamen, nahmen uns die Brüder gerne auf.
<G-vec00042-001-s300><come.kommen><en> No wonder, since all of its principal conductors have come from the Old World.
<G-vec00042-001-s300><come.kommen><de> Wen wundert’s, kamen doch sämtliche Chefdirigenten aus der Alten Welt.
<G-vec00042-001-s301><come.kommen><en> The first Greeks to come into contact with the Iranians were the Ionians, who lived on the coast of Asia Minor and were constantly threatened by the Persians, the most important of the Iranian peoples.
<G-vec00042-001-s301><come.kommen><de> Die ersten Griechen, die mit den Iranern in Kontakt kamen, waren die Ionier, die an der Küste Kleinasiens lebten und ständig von den Persern, einem der bedeutendsten Völker der Iraner, bedroht wurden.
<G-vec00042-001-s302><come.kommen><en> The soldiers had got wet through on the way and were tired; they had come from Krasnoe Selo.
<G-vec00042-001-s302><come.kommen><de> Die Soldaten waren unterwegs durchnäßt worden und müde: sie kamen aus Krassnoje Selo.
<G-vec00042-001-s303><come.kommen><en> It is important to mention that the participants come from sectors where multinational companies are present and they have some experience in the area of CSR.
<G-vec00042-001-s303><come.kommen><de> Alle Teilnehmer des Seminars kamen aus Branchen, in denen multinationale Unternehmen tätig sind, und brachten eigene Erfahrungen im Umgang mit CSR mit.
<G-vec00042-001-s323><come.kommen><en> What's the best gift for people in winter.the answer must be Moncler Men Jacket Design Multi Pockets With Cap Black.They come with luxurious styles and in line with fashion.various styles and colors to choose from.People dont like the winter for the cold,even there are a lot of interesting things in the season,but if you with the Moncler Mens Jackets in hands,everything will be different,you will have different impression about winter,come on,come to our wesbite and get your own style.
<G-vec00042-001-s323><come.kommen><de> Was ist das beste Geschenk für die Menschen in winter.The Antwort muss seinMoncler Herren Jacke Design Multi Taschen mit Cap Black.Sie Mit luxuriösen Designs und im Einklang mit fashion.various Stilen und Farben kommen, um zu wählen from.People nicht wie der Winter für die kalte, auch gibt es eine Menge interessanter Dinge in der Saison, aber wenn man mit derMoncler Herren Jackenin den Händen, wird alles anders sein, Sie werden anderen Eindruck über den Winter haben, komm schon, komm zu unserem wesbite und erhalten Sie Ihren eigenen Stil .
<G-vec00042-001-s325><come.kommen><en> Come up to us quickly, and save us, and help us; for all the kings of the Amorites that dwell in the hill country have gathered together against us.”
<G-vec00042-001-s325><come.kommen><de> Komm zu uns herauf eilend, rette und hilf uns; denn es haben sich wider uns zusammengeschlagen alle Könige der Amoriter, die auf dem Gebirge wohnen.
<G-vec00042-001-s326><come.kommen><en> “Come on, it’s only a game.
<G-vec00042-001-s326><come.kommen><de> “Komm schon, ist doch bloß ‘n Spiel.
<G-vec00042-001-s327><come.kommen><en> Come on, we stuff wax in our ears and close our eyes, than, nothing will happen to us.
<G-vec00042-001-s327><come.kommen><de> Komm wir stopfen uns Wachs in die Ohren und schließen die Augen, dann kann uns bestimmt nichts passiern - dann reißt die Wolkendecke.
<G-vec00042-001-s328><come.kommen><en> 28 Say not to your neighbour, Go, and come again, and tomorrow I will give; when you have it by you at the time.
<G-vec00042-001-s328><come.kommen><de> 28 Sprich nicht zu deinem Nächsten: “Geh hin und komm wieder; morgen will ich dir geben”, so du es wohl hast.
<G-vec00042-001-s329><come.kommen><en> Come with me and go back to your home.
<G-vec00042-001-s329><come.kommen><de> Komm mit mir und geh zurück zu deinem Haus.
<G-vec00042-001-s330><come.kommen><en> Do you want to know more, come to me if you're curious and want more experience.
<G-vec00042-001-s330><come.kommen><de> Wollen Sie mehr wissen, komm zu mir, wenn Sie sind neugierig und wollen mehr erleben wollen.
<G-vec00042-001-s331><come.kommen><en> Description Come with this trendy original vintage DJ PLAYER baggy jeans of the brand OLD SCHOOL really big out.
<G-vec00042-001-s331><come.kommen><de> Beschreibung Komm mit dieser modischen Original Vintage DJ PLAYER Baggy Jeans der Marke OLD SCHOOL ganz groß raus.
<G-vec00042-001-s332><come.kommen><en> Come Holy Spirit, and make ever more fruitful the charisms you have bestowed on us.
<G-vec00042-001-s332><come.kommen><de> Komm, Heiliger Geist und mache die Charismen, die du uns anvertraut hast, immer fruchtbarer.
<G-vec00042-001-s333><come.kommen><en> Come and chill if you'd like.
<G-vec00042-001-s333><come.kommen><de> Komm und entspann dich, wenn du willst.
<G-vec00042-001-s334><come.kommen><en> 7:11 Come, my beloved, let us go forth into the field. Let us lodge in the villages.
<G-vec00042-001-s334><come.kommen><de> 7:11 Komm, mein Geliebter, laß uns aufs Feld hinausgehen, in den Dörfern übernachten.
<G-vec00042-001-s335><come.kommen><en> To those for whom the griefs of yesterday or the fear of tomorrow is just too much, come Lord Jesus.
<G-vec00042-001-s335><come.kommen><de> Für diejenigen, für die die Leiden von gestern oder die Angst vor der Zukunft ist einfach zu viel, Komm, Herr Jesus.
<G-vec00042-001-s336><come.kommen><en> There, Felgen met the Beatles, who recorded their two German titles She Loves You and Come, Give Me Your Hand.
<G-vec00042-001-s336><come.kommen><de> Dort traf sich Felgen mit den Beatles, die ihre beiden deutschsprachigen Titel Sie liebt dich und Komm, gib mir deine Hand aufnahmen.
<G-vec00042-001-s337><come.kommen><en> Submissive or dominant, come to me - I`m yours, kisses, Kessi.
<G-vec00042-001-s337><come.kommen><de> Devot oder dominant, komm zu mir, ich bin Dein, Bussi Kessi.
<G-vec00042-001-s338><come.kommen><en> That’s why Jesus does not say to Matthew when he converts – you will see it in the Gospel: “Well, this is good, I congratulate you, come with me”. No, he says to him: “Let us celebrate in your home”, and he invites all his friends, who with Matthew had been condemned by the society, to celebrate.
<G-vec00042-001-s338><come.kommen><de> Bei der Bekehrung des Matthäus – ihr findet das im Evangelium – sagt Jesus deswegen zu ihm nicht: „Gut, einverstanden, Kompliment, komm mit.“ Nein, er sagt zu ihm: „Lass uns zu dir nach Hause gehen und feiern“, und er lädt zu diesem Fest alle Freunde des Matthäus ein, die wie er von der Gesellschaft verurteilt wurden.
<G-vec00042-001-s339><come.kommen><en> "This happened and ORO, the hunter said: ""Come back to my flesh."""
<G-vec00042-001-s339><come.kommen><de> "Dies geschah so und ORO, der Jäger, sagte: ""komm zurück zu meinem Fleisch""."
<G-vec00042-001-s340><come.kommen><en> “While I understand what she wants and has the jokes, has this repetition, but her then I say 'Come on little taught the word.
<G-vec00042-001-s340><come.kommen><de> “Ich verstehe zwar, was sie will und hat die Witze, hat diese Wiederholung, aber sie dann sage ich ‚wenig Komm das Wort gelehrt.
<G-vec00042-001-s341><come.kommen><en> Is quite difficultly to there to come.
<G-vec00042-001-s341><come.kommen><de> Is schon schwierig bis da hin zu komm'n.
<G-vec00042-001-s342><come.kommen><en> “John came preaching repentance to prepare you for the kingdom; now have I come proclaiming faith, the gift of God, as the price of entrance into the kingdom of heaven.
<G-vec00042-001-s342><come.kommen><de> Johannes kam und predigte Buße, um euch auf das Königreich vorzubereiten; jetzt komme ich und verkündige den Glauben, dieses Gottesgeschenk, als Preis für den Eintritt ins Königreich des Himmels.
<G-vec00042-001-s343><come.kommen><en> Come close to love, for love is the heart of you.
<G-vec00042-001-s343><come.kommen><de> Komme näher, um zu lieben, denn Liebe ist das Herz von dir.
<G-vec00042-001-s344><come.kommen><en> """I was about to go to university, when my father said to me: Look, Giorgio, I need you, come join the company."
<G-vec00042-001-s344><come.kommen><de> """Ich sollte zur Universität gehen, doch mein Vater sagte zu mir: hör mal, Giorgio, ich brauche dich, komme in die Firma."
<G-vec00042-001-s345><come.kommen><en> In spite of all the alienation, he understood: This is where I come from, these are my people.
<G-vec00042-001-s345><come.kommen><de> Bei allem Befremden hat er verstanden: Hier komme ich her, das sind meine Leute.
<G-vec00042-001-s346><come.kommen><en> "14 Jesus answered, ""Even if I bear witness of myself, my testimony is true, for I know where I came from and where I am going; but you do not know where I come from and where I am going."
<G-vec00042-001-s346><come.kommen><de> 14 Jesus antwortete und sprach zu ihnen: Auch wenn ich von mir selbst zeuge, ist mein Zeugnis wahr, weil ich weiß, woher ich gekommen bin und wohin ich gehe; ihr aber wißt nicht, woher ich komme und wohin ich gehe.
<G-vec00042-001-s347><come.kommen><en> No, I come only out of love for My children, whom I wish to see filled with light and peace.
<G-vec00042-001-s347><come.kommen><de> Nein, Ich komme nur aus Liebe zu meinen Kindern, die ich voll Licht und Frieden sehen möchte.
<G-vec00042-001-s348><come.kommen><en> However, I come just by time, when As I Lay Dying, start their set and I'm trying desperately to catch the vibe with my camera
<G-vec00042-001-s348><come.kommen><de> Wie auch immer, ich komme gerade rechtzeitig zum Anpfiff von As I Lay Dying, und versuche mit schierer Verzweiflung deren Vibe per Bild einzufangen.
<G-vec00042-001-s349><come.kommen><en> Berlin as a business location come forward only, when good connections there existed, where economically at the time “the liven”.
<G-vec00042-001-s349><come.kommen><de> Berlin komme als Wirtschaftsstandort nur dann voran, wenn gute Verkehrsverbindungen dorthin existierten, wo zur Zeit wirtschaftlich „die Post abgeht“.
<G-vec00042-001-s350><come.kommen><en> "Hubert brought out the laughs again as he talked between songs: ""I come from the Salzkammergut... we are Austria."
<G-vec00042-001-s350><come.kommen><de> "Hubert brachte wieder die Lacher auf seine Seite als er zwischen den Titel'n erklärte: ""Ich komme aus dem Salzkammergut... wir sind Österreich."
<G-vec00042-001-s351><come.kommen><en> My name is Cécile and I come from Biberach in Germany.
<G-vec00042-001-s351><come.kommen><de> Ich heiße Cécile und komme aus Biberach in Deutschland.
<G-vec00042-001-s352><come.kommen><en> Ball Chain - Come to find ball chain retail you like.
<G-vec00042-001-s352><come.kommen><de> - Komme zu Kugel Kette Einzelhandel zu finden, die Sie mögen.
<G-vec00042-001-s353><come.kommen><en> This is evident from the next two verses, Nehemiah 2:7,8: “Moreover, I said unto the king, If it please the king, let letters be given me to the governors beyond the river, that they may convey me over, till I come to Judah; and a letter to Asaph, the keeper of the king’s forest, that he may give me timber to make beams for the gates of the palace which appertained to the house, and for the wall of the city, and for the house that I shall enter into.
<G-vec00042-001-s353><come.kommen><de> Dies ist auch aus den nächsten beiden Versen ersichtlich: „Und ich sprach zum dem König: wenn es den König gut dünkt, so gebe man mir Briefe an die Landpfleger jenseits des Stromes, daß sie mich durchziehen lassen, bis ich nach Juda komme; und einen Brief an Asaph, den Hüter, des königlichen Forstes, daß er mir Holz gebe, um die Tore der Burg zu bälken, welche zum Hause gehört, und für die Mauer der Stadt, und für das Haus, in welches ich ziehen werde.
<G-vec00042-001-s354><come.kommen><en> "In order for a world civilization to come about,... Christianity must be reconceived to conform with ""global"" values and shed its ""divisive"" attributes."
<G-vec00042-001-s354><come.kommen><de> "Damit eine Welt-Zivilisation zustande komme,... müsse das Christentum neu konzipiert werden, um ""globalen"" Werten zu entsprechen und seine ""spaltende"" Attribute abzuwerfen."
<G-vec00042-001-s355><come.kommen><en> Hello, I come Towards You as I heard about your site, and I would like to know more.
<G-vec00042-001-s355><come.kommen><de> Hallo, Ich komme zu Ihnen, wie ich über Ihre Website zu hören, und ich möchte mehr wissen.
<G-vec00042-001-s356><come.kommen><en> By now I come, or my Bridegroom, to admire Your glory, That since me riempie the soul of joy, Where the whole sky sinks in adoration in front of You.
<G-vec00042-001-s356><come.kommen><de> Ich komme nunmehr, oder mein Bräutigam, zu Deinen Ruhm bewundern Der von jetzt an ich riempie die Seele von Freude, Wo der ganze Himmel in Anbetung vor Du sinkt.
<G-vec00042-001-s357><come.kommen><en> "Come back next Monday with your husband."""
<G-vec00042-001-s357><come.kommen><de> Komme nächsten Montag zurück mit deinem Mann.
<G-vec00042-001-s358><come.kommen><en> I come to my first memory of her from, I think, Christmas 1930.
<G-vec00042-001-s358><come.kommen><de> Ich komme an meine erste Erinnerung an ihr aus, ich glaube, Weihnachten 1930.
<G-vec00042-001-s359><come.kommen><en> As this character, Kaufman would appear on the stage of comedy clubs, play a recording of the theme from the Mighty Mouse cartoon show while standing perfectly still, and lip-sync only the line “Here I come to save the day” with great enthusiasm .
<G-vec00042-001-s359><come.kommen><de> Als dieses Zeichen, Kaufman erscheint auf der Bühne des Comedy-clubs, Spielen Sie eine Aufnahme des Themas von der Mighty Mouse Cartoon Show stehen perfekt noch, und nur die Linie lippensynchron “Hier komme ich zu den Tag retten” mit großer Begeisterung.
<G-vec00042-001-s360><come.kommen><en> I am Assana and come from Cameroon.
<G-vec00042-001-s360><come.kommen><de> ich bin Assana und komme aus Kamerun.
<G-vec00042-001-s361><come.kommen><en> Many visitors come to the island every year to participate in the souma festival, held at a different distillery each year.
<G-vec00042-001-s361><come.kommen><de> Viele Besucher kommen jedes Jahr auf die Insel, um am Souma-Fest teilzunehmen, das jedes Jahr in einer anderen Destillerie stattfindet.
<G-vec00042-001-s362><come.kommen><en> There are literally hundreds of magnificent things to see and many visitors come back year after year.
<G-vec00042-001-s362><come.kommen><de> Die Zahl der zu bewundernden Dinge geht in die Hunderte, so dass viele Besucher Jahr für Jahr wieder kommen.
<G-vec00042-001-s363><come.kommen><en> Many surfers come and learn Spanish in Bocas del Toro because of its surf .
<G-vec00042-001-s363><come.kommen><de> Viele Surfer kommen und lernen Spanisch in Bocas del Toro wegen der Brandung.
<G-vec00042-001-s364><come.kommen><en> Sensitivity increases, especially in women, who not only use a lot of cosmetic products but also come into contact with scented household cleaners and detergents.
<G-vec00042-001-s364><come.kommen><de> Vor allem bei Frauen, die nicht nur viele Kosmetika benutzen, sondern auch im Haushalt mit parfümierten Reinigungs- und Waschmitteln in Berührung kommen, nimmt die Empfindlichkeit zu.
<G-vec00042-001-s365><come.kommen><en> Enlightenment can come only through a conscious relationship with cosmic energies.
<G-vec00042-001-s365><come.kommen><de> Erleuchtung kann nur durch eine bewußte Beziehung mit kosmischen Energien kommen.
<G-vec00042-001-s366><come.kommen><en> But ye shall receive power, after that the Holy Ghost is come upon you: and ye shall be witnesses unto me both in Jerusalem, and in all Judaea, and in Samaria, and unto the uttermost part of the earth.
<G-vec00042-001-s366><come.kommen><de> sondern ihr werdet die Kraft des Heiligen Geistes empfangen, welcher auf euch kommen wird, und werdet meine Zeugen sein zu Jerusalem und in ganz Judäa und Samarien und bis an das Ende der Erde.
<G-vec00042-001-s368><come.kommen><en> Choosing fine linens for your bed and bath can be initially costly, but as with any purchase of quality made items you will enjoy fine linen sheets and towels for years to come.
<G-vec00042-001-s368><come.kommen><de> Wählende feine Leinen für Ihr Bett und Bad können teuer zuerst sein, aber, wie mit jedem möglichem Erwerb der Qualität Einzelteile bildete, die Sie feine Leinenblätter und Tücher genießen, damit Jahre kommen.
<G-vec00042-001-s369><come.kommen><en> Just Come To Our Website And Place Your Order To Buy buy ultimate team coins Coins Then You Will Feel What An First-Class Service In The World .We Are An Experienced And Professional Team Of Cheap buy ultimate team coins Coins For Sale.
<G-vec00042-001-s369><come.kommen><de> Kommen Sie einfach auf unserer Website und Ihre Bestellung zu kaufen how to buy ultimate team coins Münzen dann werden Sie spüren, was ein First-Class-Dienst in der Welt Wir sind ein erfahrenes und professionelles Team von Billig how to buy ultimate team coins Münzen zum Verkauf.
<G-vec00042-001-s370><come.kommen><en> But do not walk past the source of life I opened up for you.... Listen when I speak to you and think about it.... keep coming back to hear My Word and soon you will no longer want to accept any other food and drink, you will constantly come to My table, you will accept My invitation for Supper and I will offer it to you with all the love a Host can grant to His guest, who will always come to Him in order to replenish themselves....
<G-vec00042-001-s370><come.kommen><de> Aber gehet nicht an dem Lebensquell vorüber, den Ich für euch erschlossen habe.... Höret, wenn Ich zu euch rede, denket darüber nach.... kommet immer wieder, um Meine Ansprache zu vernehmen, und ihr werdet bald keine andere Speise und keinen anderen Trank mehr entgegennehmen wollen, ihr werdet euch dann ständig einfinden an Meinem Tisch, ihr werdet Meiner Einladung folgen, zum Abendmahl zu kommen, und Ich werde es euch darreichen mit aller Liebe, die der Gastgeber Seinen Gästen schenken wird, die sich immer bei Ihm einfinden, um sich sättigen zu lassen....
<G-vec00042-001-s371><come.kommen><en> And maybe those who often come to this site to pray may begin to see certain aspects of their religion somewhat differently.
<G-vec00042-001-s371><come.kommen><de> Und womöglich beginnen diejenigen, die oft zum Gebet an diesen Ort kommen, gewisse Aspekte ihrer Religion etwas anders zu sehen.
<G-vec00042-001-s372><come.kommen><en> It will come through people; and if we blame the people and focus our attention on them, we have missed the point.
<G-vec00042-001-s372><come.kommen><de> Er wird durch Leute kommen; und wenn wir den Leuten die Schuld geben und unsere Aufmerksamkeit auf sie lenken, haben wir das Entscheidende verpasst.
<G-vec00042-001-s373><come.kommen><en> Generally speaking, the EU will be the most affected partner among all those targeted by the measures, as 73% of imports that are banned come from the EU.
<G-vec00042-001-s373><come.kommen><de> Da 73 % der nun verbotenen Einfuhren aus der EU kommen, lässt sich sagen, dass sie von den russischen Maßnahmen am stärksten betroffen sein wird.
<G-vec00042-001-s374><come.kommen><en> She needs a friend like you to come along and help her decide how to do her nails.
<G-vec00042-001-s374><come.kommen><de> Sie braucht einen Freund, wie Sie zu kommen und Hilf ihr entscheiden, wie ihre Nägel zu tun.
<G-vec00042-001-s375><come.kommen><en> I have covered in great detail these facts in at least ten other books and new facts in support of my theories come in every month if not more often.
<G-vec00042-001-s375><come.kommen><de> Ich habe ausführlich großes diese Tatsachen in mindestens 10 anderen Büchern umfaßt und neue Tatsachen zur Unterstützung meiner Theorien kommen in jeden Monat wenn nicht häufig.
<G-vec00042-001-s376><come.kommen><en> And Moses said,: «« Hovtwa accuracy, de militiamen and armed terrorist Daash, ahi Arab safety and which come and saw her..
<G-vec00042-001-s376><come.kommen><de> Und Mose sprach:: «« Hovtwa Richtigkeit, de Milizen und bewaffneten terroristischen Daash, ahi arabischen Sicherheit und die kommen und sah sie..
<G-vec00042-001-s377><come.kommen><en> The other side of the vise tells you that you can't come to Him on your own.
<G-vec00042-001-s377><come.kommen><de> Die andere Seite des Schraubstocks sagt dir, du kannst nicht aus eigener Kraft zu ihm kommen.
<G-vec00042-001-s378><come.kommen><en> Klara is just hot! We were more than please when she agreed to come to our atelier.
<G-vec00042-001-s378><come.kommen><de> Wir waren mehr als zufrieden, als sie zustimmte, in unser Atelier zu kommen.
<G-vec00042-001-s379><come.kommen><en> It is possible to come to be your personal supervisor, and work when you wish.
<G-vec00042-001-s379><come.kommen><de> So kommen Sie zu uns und überzeugen Sie sich von der Qualität unserer Druckererzeugnisse.
<G-vec00042-001-s399><come.kommen><en> "And he said, ""Jesus, remember me when you come into your kingdom."""
<G-vec00042-001-s399><come.kommen><de> Dann sagte er: Jesus, denk an mich, wenn du in dein Reich kommst.
<G-vec00042-001-s400><come.kommen><en> A very special energy will arise within you as soon as you come into contact with the sexy fabric of Modus Vivendi's Wolf Brief.
<G-vec00042-001-s400><come.kommen><de> Sobald du mit dem sexy Stoff des Wolf Brief von Modus Vivendi in Berührung kommst, wird eine ganz spezielle Energie in dir aufsteigen.
<G-vec00042-001-s401><come.kommen><en> SS: If you come here from Berlin or Beirut, you first lose your frame of reference, your work is suddenly just your work without a particular network, without particular codes and references.
<G-vec00042-001-s401><come.kommen><de> SS: Wenn du aus Berlin oder Beirut hierher kommst, verlierst du erstmal dein Referenzsystem, deine Arbeit ist plötzlich nur noch deine Arbeit, ohne ein bestimmtes Netzwerk, ohne bestimmte Codes und Referenzen.
<G-vec00042-001-s402><come.kommen><en> That’s where you come in.
<G-vec00042-001-s402><come.kommen><de> Hier kommst du ins Spiel.
<G-vec00042-001-s403><come.kommen><en> They will beg Jesus Christ Mr. and his Saint Spirit to illuminate them saying,: «Mr., that I see», or: «What I know myself», or still: «You come, Spirit Saint», and they will say every day the litanies of the Spirit Saint and the prayer that it follows, you bring in the first part of this book.
<G-vec00042-001-s403><come.kommen><de> Jesus Christus Herr und sein Sankt werden Geist bitten, ihnen sagend, zu beleuchten: «Herr das ich sehe», oder: «, Daß ich ich derselbe kenne», oder noch: «Du kommst, Geist Sankt», und sie werden alle Tage die Litaneien des Geistes Sankt und die Rede sagen, die folgt, ihr bringt wieder zum ersten Teil von diesem Buch.
<G-vec00042-001-s404><come.kommen><en> Yes That once you loose what you love your awareness is heightened of that love and you come back with a stronger love.
<G-vec00042-001-s404><come.kommen><de> Ja Dass wenn man einmal das verliert was man liebt, deine Bewusstheit von jener Liebe erhöht ist, und du kommst mit einer stärkeren Liebe zurück.
<G-vec00042-001-s405><come.kommen><en> And he went again into the Praetorium and said to Jesus, Where do you come from? But Jesus gave him no answer.
<G-vec00042-001-s405><come.kommen><de> Er ging wieder in den Palast zurück und fragte Jesus: »Woher kommst du?« Doch Jesus antwortete nichts.
<G-vec00042-001-s406><come.kommen><en> The closer you come to Dusty the less you will fear her and the more warmth you feel.
<G-vec00042-001-s406><come.kommen><de> Je näher du Dusty kommst, desto weniger fürchtest du sie, und desto mehr Wärme fühlst du.
<G-vec00042-001-s407><come.kommen><en> And if you come home angry, they feel it, and their mood may be dampened.
<G-vec00042-001-s407><come.kommen><de> Und wenn du ärgerlich nachhause kommst, so spüren sie das, und ihre Stimmung wird gedämpft.
<G-vec00042-001-s408><come.kommen><en> Or if you come here I shall speak to you about it.
<G-vec00042-001-s408><come.kommen><de> Oder, wenn Du hierher kommst, kann ich mit Dir darüber sprechen.
<G-vec00042-001-s409><come.kommen><en> After playing with the data for a while, you’ll probably come up with some mobile optimization ideas.
<G-vec00042-001-s409><come.kommen><de> Wenn Du ein bisschen mit den Einstellungen herumgespielt hast, kommst Du bestimmt auf ein paar nützliche Ideen zur Optimierung Deiner Seite.
<G-vec00042-001-s410><come.kommen><en> Alnwick in Northumberland is one of those places where you feel like you've REALLY come away from the hustle and bustle of everyday life.
<G-vec00042-001-s410><come.kommen><de> Alnwick in Northumberland ist einer dieser Orte, an dem es sich anfühlt, als kommst du wirklich weg vom hektischen Treiben des täglichen Lebens.
<G-vec00042-001-s411><come.kommen><en> Many people suffer from allergic dermatitis and not know, If you come into con...
<G-vec00042-001-s411><come.kommen><de> Viele Menschen leiden unter allergischen Dermatitis und nicht wissen, kommst du in Kontakt...
<G-vec00042-001-s412><come.kommen><en> When Abu Bakr saw him, he asked: “Do you come as an emir or with a special commission?” Ali answered: “With a special commission.” They then continued on together.
<G-vec00042-001-s412><come.kommen><de> Als Abu Bakr ihn sah, fragte er: “Kommst du als Emir oder mit einem besonderen Auftrag?” Ali antwortete: “Mit einem besonderen Auftrag.” Sie zogen dann zusammen weiter.
<G-vec00042-001-s413><come.kommen><en> Well the left of the two balls you come first, if the whole structure is already half down.
<G-vec00042-001-s413><come.kommen><de> Na die linke von den beiden Kugeln kommst Du erst, wenn das ganze Gerüst schon halb unten ist .
<G-vec00042-001-s414><come.kommen><en> Instead of standing outside, like the older son, you come into fellowship with God, like the prodigal son who was converted.
<G-vec00042-001-s414><come.kommen><de> Anstatt außen zu stehen, wie der ältere Sohn, kommst du in die Gemeinschaft mit Gott, wie der verlorene Sohn, der bekehrt wurde.
<G-vec00042-001-s415><come.kommen><en> you come back from the dead.
<G-vec00042-001-s415><come.kommen><de> du von den Toten zurück kommst.
<G-vec00042-001-s416><come.kommen><en> Other places to see: If you come from the west, there's a use to stop in Transylvania.
<G-vec00042-001-s416><come.kommen><de> Andere sehenswerte Orte: Wenn du vom Westen kommst, lohnt es sich auf jeden Fall in Transsylvanien anzuhalten.
<G-vec00042-001-s417><come.kommen><en> 5 “After that you will come to the hill of God, where the garrison of the Philistines is; and it will happen, when you have come there to the city, that you will meet a band of prophets coming down from the high place with a lute, a tambourine, a pipe, and a harp before them; and they will be prophesying.
<G-vec00042-001-s417><come.kommen><de> 5 Danach wirst du kommen auf den Hügel GOttes, da der Philister Lager ist; und wenn du daselbst in die Stadt kommst, wird dir begegnen ein Haufe Propheten von der Höhe herabkommend und vor ihnen her ein Psalter und Pauken und Pfeifen und Harfen, und sie weissagend.
<G-vec00042-001-s418><come.kommen><en> Should you wish them above all else, and be willing to make use of our experience, we are sure they will come.
<G-vec00042-001-s418><come.kommen><de> Wenn dieser Wunsch für dich an erster Stelle steht, und wenn du dir unsere Erfahrung zu eigen machen willst, sind wir sicher, daß es so kommt.
<G-vec00042-001-s419><come.kommen><en> And after I had come back to earth after the realisation, I knew: This is an influence of Mars, that one of Jupiter, that of the Sun, Moon.
<G-vec00042-001-s419><come.kommen><de> Und als ich auf die Erde nach der Realisation zurückkam, wusste ich: Dies ist der Einfluss vom Mars, das kommt vom Jupiter, das von der Sonne und das vom Mond.
<G-vec00042-001-s420><come.kommen><en> The blue pad is meant for dishes used for milk, the red for utensils for meat, and the green for dishes that come into contact with food containing neither meat nor milk.
<G-vec00042-001-s420><come.kommen><de> Der grüne Schrubber ist für Geschirr bestimmt, das mit Lebensmitteln in Berührung kommt, die weder Fleisch noch Milch enthalten.
<G-vec00042-001-s421><come.kommen><en> I do not know how to do it and how do I come to you.
<G-vec00042-001-s421><come.kommen><de> Ich sah es schon er seit langem nicht kommt sehr selten an.
<G-vec00042-001-s422><come.kommen><en> "Of course, this development does not come ""out of nowhere"", but has social causes."
<G-vec00042-001-s422><come.kommen><de> "Natürlich kommt diese Entwicklung nicht ""aus dem Nichts"", sondern hat gesellschaftliche Ursachen."
<G-vec00042-001-s423><come.kommen><en> "This is the ""I"" that will eventually lead you to practice meditation, for you see the long-term benefits that come from training your powers of mindfulness, concentration, and discernment."
<G-vec00042-001-s423><come.kommen><de> "Dieses ist das ""Ich"", welches Sie letztlich zur Meditation führt, denn Sie sehen einen langfristigen Nutzen, der aus dem Üben Ihrer Kraft an Achtsamkeit, Konzentration und Einsicht kommt."
<G-vec00042-001-s424><come.kommen><en> Irresistible grace argues that when God calls a person to salvation, that person will inevitably come to salvation.
<G-vec00042-001-s424><come.kommen><de> Unwiderstehliche Gnade argumentiert, das, wenn Gott eine Person zur Erloesung beruft, das diese Person dann auch unweigerlich zur Erloesung kommt.
<G-vec00042-001-s425><come.kommen><en> But when he discovered that it didn't originally come from Switzerland, he took it on.
<G-vec00042-001-s425><come.kommen><de> Aber als er erfahren hat, dass es ursprünglich gar nicht aus der Schweiz kommt, hat er sich seiner angenommen.
<G-vec00042-001-s426><come.kommen><en> Later in the evening, a mosquito will come for a visit and enjoy my blood.
<G-vec00042-001-s426><come.kommen><de> Abends kommt dann eine Mücke zu Besuch und labt sich an meinem Blut.
<G-vec00042-001-s427><come.kommen><en> They must prophesy again that the purpose of our Lord for this world in the end times is for everyone to come into God's blessings by believing in the gospel of the water and the Spirit.
<G-vec00042-001-s427><come.kommen><de> Sie müssen wieder prophezeien, dass der Zweck unseres Herrn für diese Welt in der Endzeit ist, dass jeder zum Segen Gottes durch den Glauben an das Evangelium von Wasser und Geist kommt.
<G-vec00042-001-s428><come.kommen><en> While news about constantly increasing numbers of Toyotas and cars of other manufacturers recalled into shops come thick and fast and all kinds of technical reasons are discussed publicly, the pivotal question, what is going awry with the economy overall, is missing out.
<G-vec00042-001-s428><come.kommen><de> Während sich die Meldungen über die ständig steigende Anzahl der in die Werkstätten zurückgerufenen Autos von Toyota und anderen Autoherstellern in den Medien überschlagen und alle möglichen technischen Ursachen öffentlich diskutiert werden, kommt die zentrale Frage, was denn in der Wirtschaft insgesamt schief läuft, viel zu kurz.
<G-vec00042-001-s429><come.kommen><en> If any man come to me, and hate not his father, and mother, and wife, and children, and brethren, and sisters, yea, and his own life also, he cannot be my disciple.
<G-vec00042-001-s429><come.kommen><de> So jemand zu mir kommt und haßt nicht seinen Vater, Mutter, Weib, Kinder, Brüder, Schwestern, auch dazu sein eigen Leben, der kann nicht mein Jünger sein.
<G-vec00042-001-s430><come.kommen><en> “Grace to you and peace from him who is and who was and who is to come, and from the seven spirits who are before his throne, and from Jesus Christ the faithful witness, the first-born of the dead, and the ruler of kings on earth” (Rev 1:4-5).
<G-vec00042-001-s430><come.kommen><de> »Gnade sei mit euch und Friede von Ihm, der ist und der war und der kommt, und von den sieben Geistern vor seinem Thron, und von Jesus Christus; er ist der treue Zeuge, der Erstgeborene der Toten, der Herrscher über die Könige der Erde« (Offb 1,4–5).
<G-vec00042-001-s431><come.kommen><en> Of course we first regain our innocence in baptism, but rarely does it come to full fruition.
<G-vec00042-001-s431><come.kommen><de> Natürlich erhalten wir zuerst unsere Unschuld bei der Taufe zurück, aber selten kommt es zur vollen Erfüllung.
<G-vec00042-001-s432><come.kommen><en> 3.1 The lodging agreement shall come into being by means of acceptance of the contractual partner’s booking by the host.
<G-vec00042-001-s432><come.kommen><de> 3.1 Der Beherbergungsvertrag kommt durch die Annahme der Bestellung des Vertragspartners durch den Beherberger zustande.
<G-vec00042-001-s433><come.kommen><en> He looked back out the rear window again like he was expecting mom to come walking around the corner any minute.
<G-vec00042-001-s433><come.kommen><de> Er sah wieder aus dem Heckfenster, als ob er erwarten würde, dass Mama jeden Moment um die Ecke kommt.
<G-vec00042-001-s434><come.kommen><en> If a woman feels the movement of menstrual blood inside her, but is does not come out until after the sun has set, her fast is valid and she does not have to make the day up later.
<G-vec00042-001-s434><come.kommen><de> Fühlt eine Frau die Bewegung des Menstruationsblutes in sich, es kommt jedoch bis zum Sonnenuntergang nicht heraus, so ist ihr Fasten ebenfalls gültig und sie muss den Tag nicht nachholen.
<G-vec00042-001-s435><come.kommen><en> People from enemy trenches will be interested in you as a mediator because you will come from the other side with the smell of these people on your clothes.
<G-vec00042-001-s435><come.kommen><de> Die Bewohner feindlicher Schützengräben werden sich für einen interessieren, weil man von der anderen Seite kommt und den Geruch der anderen in seinen Kleidern trägt.
<G-vec00042-001-s436><come.kommen><en> When you come to the very end of the breath, naturally, without thinking, the inhalation will follow and your belly will fill up and expand in front of you.
<G-vec00042-001-s436><come.kommen><de> Wenn man zu dem Ende des Atems kommt, dann folgt das Einatmen ganz natürlich, ohne dass man darüber nachzudenken brauchte und der Bauch füllt sich wieder.
<G-vec00078-001-s532><come.stammen><en> The advantages of Decaduro potentially come from the high levels of an amino-acid component.
<G-vec00078-001-s532><come.stammen><de> Die Vorteile der Decaduro vielleicht stammen aus den hohen Niveaus einer Aminosäure Wirkstoff.
<G-vec00078-001-s533><come.stammen><en> So when such scientists find bones and teeth which they think come from men then they most probably just come from animal-like men and therefore tell them nothing about the history of man and therefore there is no contradiction to what the Bible tells us about the history of man.
<G-vec00078-001-s533><come.stammen><de> Wenn solche Wissenschaftler also Knochen und Zähne finden, von denen sie annehmen, sie stammen von Menschen, dann kommen sie höchstwahrscheinlich nur von menschenähnlichen Tieren und erzählen ihnen überhaupt nichts über die Geschichte des Menschen und daher gibt es keine Widersprüche zu dem, was die Bibel uns über die Geschichte des Menschen sagt.
<G-vec00078-001-s534><come.stammen><en> Two chmafu productions come from the composer and media artist Elizabeth Schimana: on the one hand, her composition for the original synthesizer by Max Brand (“Höllenmaschine”), played by the incomparable performer of new composed and experimental music, Manon-Liu Winter, as well as Gregor Ladenhauf; and on the other hand, Schimana’s collaboration with the electronic musician and DJ Gernot Tutner, whose club nights in Graz and Ljubljana “Digitaler Rosengarten” (Schimana) and “Heavy Dope Beats” (Tutner) led to their co-production “Dope Beat Rosengarten”.
<G-vec00078-001-s534><come.stammen><de> Zwei chmafu-Produktionen stammen von der Komponistin und Medienkünstlerin Elisabeth Schimana, einerseits ihre Komposition für den Ur-Synthesizer von Max Brand („Höllenmaschine“), gespielt von der unvergleichlichen Interpretin neuer komponierter und experimenteller Musik, Manon-Liu Winter, sowie von Gregor Ladenhauf; und andererseits Schimanas Zusammenarbeit mit dem Elektroniker und DJ Gernot Tutner, deren differente Clubabende in Graz und Ljubljana „Digitaler Rosengarten“ (Schimana) und „Heavy Dope Beats“ (Tutner) auf ihrer Koproduktion in den „Dope Beat Rosengarten“ mündeten.
<G-vec00078-001-s535><come.stammen><en> Also from these works come Scientology technologies to rear children, repair families, educate, organize and provide relief in times of illness orsuffering.
<G-vec00078-001-s535><come.stammen><de> Aus diesen Werken stammen auch Scientology Lehren zum Großziehen von Kindern, Wiederherstellen von Familienbeziehungen, Ausbilden, Organisieren und Schaffen von Erleichterung in Zeiten von Krankheit oderLeiden.
<G-vec00078-001-s536><come.stammen><en> The families have come from a different region, as there was no more food for the cattle where they lived.
<G-vec00078-001-s536><come.stammen><de> Diese Familien stammen aus weit entfernten Regionen, wo es kein Futter mehr für ihr Vieh, von dem sie leben, gibt.
<G-vec00078-001-s537><come.stammen><en> All of the cards held by the ITS come from the second phase of the camp, between its reopening in May 1943 and the liberation in April/May 1945.
<G-vec00078-001-s537><come.stammen><de> Alle beim ITS erhaltenen Karten stammen aus der zweiten Phase des Lagers, also von der Wiedereröffnung im Mai 1943 bis zur Befreiung im April/Mai 1945.
<G-vec00078-001-s538><come.stammen><en> The data come from the GPS of the phone.
<G-vec00078-001-s538><come.stammen><de> Die Daten stammen aus den GPS des Telefons.
<G-vec00078-001-s539><come.stammen><en> For example, authorities in some major importing countries still fail to apply robust checks even where consignments come from countries that have been warned by the EU for having inadequate measures in place to prevent and deter illegal fishing.
<G-vec00078-001-s539><come.stammen><de> So versäumen es die Behörden einiger der großen einführenden Länder noch immer, sorgfältige Kontrollen vorzunehmen, selbst wenn die Ladungen aus Ländern stammen, die aufgrund ihrer unzureichenden Maßnahmen zur Verhinderung und Bekämpfung illegaler Fischerei bereits von der EU verwarnt wurden.
<G-vec00078-001-s540><come.stammen><en> On this and other occasions, the Salvis cuisine will prove itself. The Salvis VisionPRO stove is polished and some of Martina Strobel's specialities come from the Salvis Vario Cooker.
<G-vec00078-001-s540><come.stammen><de> Bei dieser und anderen Gelegenheiten bewährt sich die neue Salvis-Küche Der Salvis VisionPRO ist hochglanzpoliert und einige der Spezialitäten von Martina Strobel stammen vom Salvis Vario Bräter.
<G-vec00078-001-s541><come.stammen><en> At Löffler 99 percent of production is done in Europe while 80 percent of the value creation takes place in Austria and 70 percent of materials come from their own knitting factories.
<G-vec00078-001-s541><come.stammen><de> Bei Löffler erfolgen nicht nur 99 Prozent der Produktion in Europa, auch 80 Prozent der Wertschöpfung findet in Österreich statt, und 70 Prozent der Stoffe stammen aus der eigenen Strickerei.
<G-vec00078-001-s542><come.stammen><en> The organic search results come from the index database, while PPC's sponsored links are based on your bid and total investment.
<G-vec00078-001-s542><come.stammen><de> Organic Search Results stammen aus der Index-Datenbank, während die Sponsored Links von PPC auf Deinem Gebot und Deiner Gesamtinvestition basieren.
<G-vec00078-001-s543><come.stammen><en> In general, most of the entries come from the summer of 1943, specifically between May and August 1943.
<G-vec00078-001-s543><come.stammen><de> Generell stammen die meisten Einträge aus dem Sommer 1943, genauer von Mai bis August 1943.
<G-vec00078-001-s544><come.stammen><en> God promises Abraham three things here: Abraham would have many descendants, this nation would own and occupy a land, and a universal blessing will come to all mankind out of Abraham's line (the Jews).
<G-vec00078-001-s544><come.stammen><de> Gott versprich Abraham hier drei Dinge: dass Abraham viele Nachkommen haben wird, dass diese Nation ein Land besitzen und bewohnen wird, und eine universale Segnung allen Menschen zu Teil wird, die aus Abrahams Linie stammen (die Juden).
<G-vec00078-001-s545><come.stammen><en> The figures come from the EuroTrak surveys which were carried out in 2015 by EHIMA (European Hearing Instrument Manufacturers Association).
<G-vec00078-001-s545><come.stammen><de> Die Zahlen stammen aus der EuroTrak Studie, die im Jahr 2015 von EHIMA (European Hearing Instrument Manufacturers Association) durchgeführt wurde.
<G-vec00078-001-s546><come.stammen><en> And the cherry on the cake is that most of our mystical slots come from NOVOMATIC.
<G-vec00078-001-s546><come.stammen><de> Dass die meisten unserer Mystik-Slots von NOVOMATIC stammen, setzt dem Spielvergnügen die Krone auf.
<G-vec00078-001-s547><come.stammen><en> The originals for Lükenwerk's drawings come from every nook and cranny of the printed sphere, from magazines and catalogues, from advertising, science and fashion.
<G-vec00078-001-s547><come.stammen><de> Die Vorlagen zu ihren Zeichnungen stammen aus allen Ecken und Enden der gedruckten Welt, aus Magazinen und Katalogen, aus den Welten der Werbung, der Wissenschaft, der Mode.
<G-vec00078-001-s548><come.stammen><en> These approximately 5-6 cm long growing killifishes come from Guinea in West-Africa.
<G-vec00078-001-s548><come.stammen><de> Diese rund 5-6 cm lang werdenden Killifische stammen aus Guinea in Westafrika.
<G-vec00078-001-s549><come.stammen><en> My parents come from a small village in Senegal, in the northwest of Africa.
<G-vec00078-001-s549><come.stammen><de> Meine Eltern stammen aus einem kleinen Dorf im Senegal im Nordwesten Afrikas.
<G-vec00078-001-s550><come.stammen><en> In the health sector, over 70% of goods come from abroad.
<G-vec00078-001-s550><come.stammen><de> Im Gesundheitssektor stammen über 70% der Güter aus dem Ausland.
<G-vec00217-002-s019><come.bieten><en> Many rooms come with a spectacular view over the hills.
<G-vec00217-002-s019><come.bieten><de> Viele Zimmer bieten eine tolle Ausblick auf die Berge an.
<G-vec00217-002-s020><come.bieten><en> Some rooms come with a view of Battery Park.
<G-vec00217-002-s020><come.bieten><de> Die modernen Hotelzimmer bieten einen Blick auf die Skyline.
<G-vec00217-002-s021><come.bieten><en> Rooms come with the garden view.
<G-vec00217-002-s021><come.bieten><de> Die Zimmer bieten einen wunderbaren Ausblick auf den Garten.
<G-vec00217-002-s022><come.bieten><en> Non-smoking rooms come with an in-room safe, climate control, flat-screen TV, a dining area and a closet. The property offers a bathroom with a shower and a bidet.
<G-vec00217-002-s022><come.bieten><de> Die En-suite Zimmer bieten einen Zimmersafe, eine Minibar, Kabelfernsehen mit Video-on-demand, einen Wohnbereich und einen Schreibtisch sowie eine tolle Aussicht auf das Meer.
<G-vec00217-002-s023><come.bieten><en> Rooms in Hotel Garni Elba come with a coffee/tea maker.
<G-vec00217-002-s023><come.bieten><de> Die Zimmer im Hotel Garni Elba mit einer Küche bieten Kaffeemaschine/Teekocher.
<G-vec00217-002-s024><come.bieten><en> Classic-style rooms at the Il Corallo bed and breakfast come with a TV and a private bathroom including a hairdryer.
<G-vec00217-002-s024><come.bieten><de> Die Doppelzimmer sind im klassischen Stil eingerichtet, und bieten Ihnen einen Flachbild-TV und ein eigenes Bad mit einem Haartrockner und Handtüchern.
<G-vec00217-002-s025><come.bieten><en> Some rooms come with a stunning view of Arabian Gulf.
<G-vec00217-002-s025><come.bieten><de> Die Zimmer bieten einen tollen Blick auf die Lagune.
<G-vec00217-002-s026><come.bieten><en> Guest units come with air conditioning, tiled floors and a private terrace with serene ocean views.
<G-vec00217-002-s026><come.bieten><de> Die Unterkünfte bieten eine Klimaanlage, Fliesenböden und eine private Terrasse mit ruhigem Meerblick.
<G-vec00217-002-s027><come.bieten><en> With astonishing brightness, incomparable contrast and captivating color, images come to life with much greater brightness while also featuring much deeper, more nuanced darks.
<G-vec00217-002-s027><come.bieten><de> Mithilfe punktueller Dimmfunktion und hoher maximaler Helligkeit bis zu 600 Nit werden Bilder mit sichtbaren Höhepunkten zum Leben erweckt, die tiefere, nuanciertere Schwarztöne bieten.
<G-vec00217-002-s028><come.bieten><en> World of Judaica's Israeli Bookmarks come in a variety of styles and shapes.
<G-vec00217-002-s028><come.bieten><de> Wir bieten eine Vielfalt an Mesusas,Tallitot, Jüdischem Schmuck und weiteren Dingen an.
<G-vec00217-002-s029><come.bieten><en> Certain rooms come with a balcony.
<G-vec00217-002-s029><come.bieten><de> Einige Zimmer bieten einen Balkon.
<G-vec00217-002-s030><come.bieten><en> Rooms come with a private bathroom equipped with a bath or shower.
<G-vec00217-002-s030><come.bieten><de> Die Zimmer bieten Ihnen ein eigenes Bad mit einer Badewanne oder einer Dusche.
<G-vec00217-002-s031><come.bieten><en> The rooms come with en suite bathrooms featuring a shower, free toiletries and a hairdryer.
<G-vec00217-002-s031><come.bieten><de> Sie bieten private Badezimmer, die über eine Dusche, einen Fön und eine Badewanne verfügen.
<G-vec00217-002-s032><come.bieten><en> All rooms come with a seating area and a toilet with shower, hairdryer and free toiletries.
<G-vec00217-002-s032><come.bieten><de> Alle Zimmer bieten einen Sitzbereich sowie ein Bad mit Dusche, Haartrockner und kostenlosen Pflegeprodukten.
<G-vec00217-002-s033><come.bieten><en> Quality materials and thorough workmanship guarantee a long service life and a reflection of excellence for years to come.
<G-vec00217-002-s033><come.bieten><de> Qualitativ hochwertige Materialien und solide Ausführung bieten die Gewähr für lange Lebensdauer und ein auf Dauer attraktives Erscheinungsbild.
<G-vec00217-002-s034><come.bieten><en> The apartments come with a kitchen, a dining area and a private bathroom.
<G-vec00217-002-s034><come.bieten><de> Die Apartments bieten Ihnen eine Küche, einen Essbereich und ein eigenes Bad.
<G-vec00217-002-s035><come.bieten><en> Some hotel rooms come with a panoramic view over the sea.
<G-vec00217-002-s035><come.bieten><de> Die Zimmer bieten einen tollen Ausblick auf das Meer.
<G-vec00217-002-s036><come.bieten><en> Room description The spacious rooms each come with a bath/ shower, a hairdryer, a direct dial telephone, a satellite TV, a radio and high speed Internet access.
<G-vec00217-002-s036><come.bieten><de> Zimmerbeschreibung Die Hotelzimmer bieten ein eigenes Badezimmer mit Dusche/Badewanne und Haartrockner sowie ein Direktwahltelefon, ein TV-Gerät mit Sat.-Kanälen, ein Radio und DSL-Internetzugang.
<G-vec00217-002-s037><come.bieten><en> These comfortable rooms come with a hairdryer and a Jacuzzi supplied in a designer bathroom.
<G-vec00217-002-s037><come.bieten><de> Die Zimmer bieten En-suite-Badezimmer mit einer Badewanne, einem Fön und einem Jacuzzi.
<G-vec00217-002-s076><come.entstehen><en> Something Great will come of it...
<G-vec00217-002-s076><come.entstehen><de> Es wird Großartiges daraus entstehen...
<G-vec00217-002-s077><come.entstehen><en> The basis for peace of mind is self-confidence and inner strength, which come from the practice of love and compassion, with a sense of respect for others and concern for their well-being.
<G-vec00217-002-s077><come.entstehen><de> Die Grundlage für geistigen Frieden ist Selbstvertrauen und innere Stärke, die durch die Praxis von Liebe und Mitgefühl, mit einem Gefühl des Respekts gegenüber anderen und einer Sorge um ihr Wohlergehen, entstehen.
<G-vec00217-002-s078><come.entstehen><en> My works come about in Hamburg Altona and Großenwörden in the inspiring Osteland.
<G-vec00217-002-s078><come.entstehen><de> Meine Arbeiten entstehen in Hamburg Altona und in Großenwörden im inspirierenden Osteland.
<G-vec00217-002-s079><come.entstehen><en> Combined with khaki, gold, thistle and indigo blue, interesting cold/warm contrasts come to light.
<G-vec00217-002-s079><come.entstehen><de> Kombiniert mit Khaki, Gold, Distelgrün und Indigo Blue entstehen interessante Kalt-Warm-Kontraste.
<G-vec00217-002-s080><come.entstehen><en> This is how the best services come about.
<G-vec00217-002-s080><come.entstehen><de> Auf diese Weise entstehen die besten Services.
<G-vec00217-002-s081><come.entstehen><en> An alternative approach may come from the potential therapeutic qualities of CBD.
<G-vec00217-002-s081><come.entstehen><de> Ein alternativer Ansatz könnte aus den potenziell therapeutischen Qualitäten von CBD entstehen.
<G-vec00217-002-s082><come.entstehen><en> Everything actually needs to come into being from nothing.
<G-vec00217-002-s082><come.entstehen><de> Alles muss eigentlich aus dem Nichts entstehen.
<G-vec00217-002-s083><come.entstehen><en> They come as well when the priesthood service is to members within the quorum.
<G-vec00217-002-s083><come.entstehen><de> Sie entstehen auch, wenn das Kollegium durch das Priestertum den Mitgliedern in seinen eigenen Reihen dient.
<G-vec00217-002-s084><come.entstehen><en> Or we can provide a complete team so the aforementioned problems don’t come up in the first place.
<G-vec00217-002-s084><come.entstehen><de> Oder wir stellen gleich ein komplettes Team, damit die oben beschriebenen Probleme erst gar nicht entstehen können.
<G-vec00217-002-s085><come.entstehen><en> And when a group unites against something, an amazingly powerful strength can come out of it.
<G-vec00217-002-s085><come.entstehen><de> Und wenn sich eine Gruppe gegen etwas vereinigt, kann daraus eine mächtige Energie entstehen.
<G-vec00217-002-s086><come.entstehen><en> It is important for self-confidence, but it can only come from someone else.
<G-vec00217-002-s086><come.entstehen><de> Sie ist wichtig für das Selbstbewusstsein, kann aber nicht aus dem eigenen Ich heraus entstehen.
<G-vec00217-002-s087><come.entstehen><en> At least I was able to sense, how his manipulated photographs could come into being.
<G-vec00217-002-s087><come.entstehen><de> Zumindest erahne ich gerade, wie seine manipulierte Fotografie entstehen könnte.
<G-vec00217-002-s088><come.entstehen><en> The object of much of today’s humanities research and cultural criticism is to demonstrate how an imaginary geography or an imagined community develops permanence and boundaries and ultimately replaces reality itself, and how this happens through identification processes in which some elements are discarded in order for that community’s identity to come into being, be it Swedish, Nordic, European or global.
<G-vec00217-002-s088><come.entstehen><de> Gegenstand der geisteswissenschaftlichen Forschung und Kulturkritik ist heute häufig, aufzuzeigen, wie eine imaginäre Geographie oder imaginäre Gemeinschaft Stabilität und Grenzen erhält und am Ende selbst den Platz der Wirklichkeit einnimmt, und wie dies durch Identifikationsprozesse geschieht, in denen manches aussortiert wird, damit die eigene Identität entstehen kann, ganz gleich ob schwedisch, nordisch, europäisch oder global.
<G-vec00217-002-s089><come.entstehen><en> Netflix also reported that more than 60% of its rentals come from recommendations that are based off of hyper personalization data. **
<G-vec00217-002-s089><come.entstehen><de> Auch Netflix berichtet, dass 60% ihrer Verkäufe aus Vorschlägen entstehen, die Kunden aufgrund ihrer personalisierten Daten erhalten.
<G-vec00217-002-s090><come.entstehen><en> You need creativity and skill to make Bronze Age decorations from metal and let the Middle Ages come to life with self decorated beads.
<G-vec00217-002-s090><come.entstehen><de> Kreativität und Geschick sind gefragt, wenn aus Metall bronzezeitliche Geschmeide entstehen und selbst verzierte Perlen das Mittelalter auferstehen lassen.
<G-vec00217-002-s091><come.entstehen><en> I’m not quite sure how the pictures come about, and why they are what they are.
<G-vec00217-002-s091><come.entstehen><de> Ich weiß nicht genau, wie die Bilder entstehen, und woran es liegt, wie sie sind.
<G-vec00217-002-s092><come.entstehen><en> Yet we all have long known that extraordinary ideas seldom come from nowhere.
<G-vec00217-002-s092><come.entstehen><de> Dabei wissen wir längst, dass außergewöhnliche Einfälle selten aus einem Vakuum heraus entstehen.
<G-vec00217-002-s093><come.entstehen><en> The relevant research is in the tradition of the resource-based basis and has not yet decided sufficiently what exactly dynamical capabilities are, where they are rooted in the organization, how they come into being, and how their advantage can be unfolded.
<G-vec00217-002-s093><come.entstehen><de> Die in der Tradition des ressourcen-orientierten Ansatzes stehende einschlägige Forschung hat bislang jedoch noch nicht hinreichend bestimmt, was genau unter dynamischen Fähigkeiten zu verstehen ist, wo in der Organisation sie zu verorten sind, wodurch sie entstehen und wie genau sich ihr Nutzen entfaltet.
<G-vec00217-002-s094><come.entstehen><en> Time and again almost magical moments come up - so great is the intimacy between the protagonists on stage and the audience.
<G-vec00217-002-s094><come.entstehen><de> So entstehen auch immer wieder fast schon magische Momente - so groß wird die Innigkeit zwischen den Akteuren auf der Bühne und dem Publikum.
<G-vec00217-002-s114><come.finden><en> "Players like him are hard to come by.
<G-vec00217-002-s114><come.finden><de> "Es ist sehr schwer, einen Spieler wie ihn zu finden.
<G-vec00217-002-s115><come.finden><en> You’ll hardly come across a model that is prettier and better.
<G-vec00217-002-s115><come.finden><de> Ein Exemplar, das schöner oder besser ist, werden Sie mit Sicherheit nicht finden.
<G-vec00217-002-s116><come.finden><en> Right in the center of Rotterdam, next to Blaak Station, you will come across this chocolate paradise in the Markthal.
<G-vec00217-002-s116><come.finden><de> Mitten im Zentrum von Rotterdam, neben der Blaak Station, finden Sie dieses Schokoladenparadies in der Markthal.
<G-vec00217-002-s117><come.finden><en> Our team is made up of people from various backgrounds who together can come up with an answer to any question.
<G-vec00217-002-s117><come.finden><de> Es besteht aus Menschen verschiedener Hintergrunds, die gemeinsam für jede Frage eine Antwort finden können.
<G-vec00217-002-s118><come.finden><en> It is a humanitarian imperative that the suffering, hunger and deaths finally come to an end.
<G-vec00217-002-s118><come.finden><de> Es ist ein Gebot der Menschlichkeit, dass Leiden, Hungern und Sterben endlich ein Ende finden.
<G-vec00217-002-s119><come.finden><en> In practice, work opportunities are rather more limited, although there is some seasonal tourist industry work available during the summer if you have the requisite skills and language abilities (Norwegian will come in handy).
<G-vec00217-002-s119><come.finden><de> In der Praxis ist die Arbeitserlaubnis trotzdem erschwert, obwohl du sehr schnell in der saisonalen Tourismusbranche eine Arbeit finden kannst, vorausgesetzt, du besitzt die nötigen Anforderungen und Sprachkenntnisse in Norwegisch.
<G-vec00217-002-s120><come.finden><en> If you want to learn English, make friends, have fun and explore the UK come and join us in the July and/or August.
<G-vec00217-002-s120><come.finden><de> Wenn Sie Englisch lernen, Freunde finden, Spaß haben und das Vereinigte Königreich erkunden möchten, besuchen Sie uns im Juli und / oder August.
<G-vec00217-002-s121><come.finden><en> It had saved his ears more then once to be able to come up with a believable explanation why some disaster was not at all related to the fact that he had been close.
<G-vec00217-002-s121><come.finden><de> Damit hatte er seine Ohren mehr als einmal retten können, wenn es darum ging eine glaubhaften Erklärung zu finden für die Tatsache, warum irgendeine Katastrophe ganz sicher nichts mit seiner Anwesenheit zu tun hatte.
<G-vec00217-002-s122><come.finden><en> It seems like it should be fairly easy for the two sides to come together.
<G-vec00217-002-s122><come.finden><de> Es scheint, als sollte es für die beiden Seiten relativ leicht sein, eine Einigung zu finden.
<G-vec00217-002-s123><come.finden><en> My immune system has crashed completely, I welcome each bacteria and virus I come across.
<G-vec00217-002-s123><come.finden><de> Mein Immunsystem ist so im Eimer, dass ich jede Bakterie und jeden Virus mitnehmen, den ich finden kann.
<G-vec00217-002-s124><come.finden><en> True unicorns that meet all of our criteria are hard to come by.
<G-vec00217-002-s124><come.finden><de> Wahre Unicorns, die alle unsere Kriterien erfüllen, sind jedoch schwer zu finden.
<G-vec00217-002-s125><come.finden><en> I, therefore, do not believe anybody could come up with a universal “sufficient condition” based on which you can always tell whether or not an enterprise has been acting ethically or not.
<G-vec00217-002-s125><come.finden><de> So glaube ich nicht, dass es genügt und gelingt, eine allgemeine „hinreichende Bedingung“ zu finden, an der gemessen werden kann, ob ein Unternehmen ethisch handelt oder nicht.
<G-vec00217-002-s126><come.finden><en> At that point the Iranian professor believed he’d come up with another argument.
<G-vec00217-002-s126><come.finden><de> In diesem Augenblick glaubte der Professor, ein anderes Argument zu finden.
<G-vec00217-002-s127><come.finden><en> One more fascinating variation you may come across web is Pontoon.
<G-vec00217-002-s127><come.finden><de> Eine andere interessante Internet-basierte Varianz Sie finden könnte, ist Pontoon.
<G-vec00217-002-s128><come.finden><en> The very goal of our industry is to come up with a smart and effective solution for these challenges.
<G-vec00217-002-s128><come.finden><de> Genau dies ist das Ziel unserer Branche: intelligente und effektive Lösungen für diese Herausforderungen zu finden.
<G-vec00217-002-s129><come.finden><en> Currently, there is not enough data and evidence to come up with a solution for that.
<G-vec00217-002-s129><come.finden><de> Gegenwärtig gibt es nicht genügend Daten und Beweise, um eine Lösung dafür zu finden.
<G-vec00217-002-s130><come.finden><en> Talking to other singles who have similar interests is a great way to come up with ideas to do on a first date.
<G-vec00217-002-s130><come.finden><de> Triff andere,die ähnliche Interessen haben, das ist ein perfekter Weg, um Ideen zu finden für gemeinsame Unternehmungen beim ersten Treffen.
<G-vec00217-002-s131><come.finden><en> Being a flexible co-packer, we would like to think along with you to come to your personal packaging solution.
<G-vec00217-002-s131><come.finden><de> Als flexibler Copacker arbeiten wir gerne mit Ihnen zusammen, um die für Sie ideale Verpackungslösung zu finden.
<G-vec00217-002-s132><come.finden><en> He added that he had been waiting for a lifetime to come up with a character together with his dad.
<G-vec00217-002-s132><come.finden><de> Er fügte hinzu, dass er auf ein Leben lang gewartet habe, um zusammen mit seinem Vater eine Figur zu finden.
<G-vec00217-002-s171><come.gelangen><en> The customer hereby grants the Bank a lien on valuables of any kind which, in the course of banking business, may come into the possession or power of disposition of the Bank through acts of the customer or of third parties for account of the customer.
<G-vec00217-002-s171><come.gelangen><de> Der Kunde räumt hiermit der BayernLB ein Pfandrecht ein an Werten jeder Art, die im bankmäßigen Geschäftsverkehr durch den Kunden oder durch Dritte für seine Rechnung in ihren Besitz oder ihre sonstige Verfügungsmacht gelangen.
<G-vec00217-002-s172><come.gelangen><en> And we need to make the bridge between the results of research on one hand and the potential investors on the other, for innovation to come out of the lab and onto the market.
<G-vec00217-002-s172><come.gelangen><de> Und wir müssen Brücken bauen zwischen den Forschungsergebnissen einerseits und potentiellen Investoren andererseits, damit die Innovation vom Labor auf den Markt gelangen kann.
<G-vec00217-002-s173><come.gelangen><en> 9 If they say thus to us, Stand still until we come to you, then we will stay in our place, and will not go up to them.
<G-vec00217-002-s173><come.gelangen><de> 9 Wenn sie dann zu uns sagen: «Steht stille, bis wir zu euch gelangen!» so wollen wir an unserm Ort stehenbleiben und nicht zu ihnen hinaufsteigen.
<G-vec00217-002-s174><come.gelangen><en> The parties will subsequently consult and try to come to an agreement.
<G-vec00217-002-s174><come.gelangen><de> Die Parteien werden sich daraufhin beraten und versuchen, zu einer Einigung zu gelangen.
<G-vec00217-002-s175><come.gelangen><en> After around 30 minutes, you will come to the clearing with the Ellmau Stone Circle.
<G-vec00217-002-s175><come.gelangen><de> Nach circa 30 Minuten gelangen Sie an die Lichtung mit dem Ellmauer Steinkreis.
<G-vec00217-002-s176><come.gelangen><en> You will look for me; and as I said to the Jews so now I say to you, “Where I am going, you cannot come.”
<G-vec00217-002-s176><come.gelangen><de> Ihr werdet mich suchen, und was ich den Juden gesagt habe, sage ich jetzt auch euch: Wohin ich gehe, dorthin könnt ihr nicht gelangen.
<G-vec00217-002-s177><come.gelangen><en> If you come to our website via a Google advert, Google AdWords will place a cookie on your device ("conversion cookie").
<G-vec00217-002-s177><come.gelangen><de> Wenn Sie über eine Googleanzeige auf unsere Webseite gelangen, setzt Google Adwords einen Cookie auf Ihrem Gerät („Conversion Cookie“).
<G-vec00217-002-s178><come.gelangen><en> The works resulting from this experience address our frequently ambiguous attitude to what is foreign to us: whereas “exotic” luxury items and food such as tropical fruit are regarded as positive and precious, people who come to us as refugees from the same countries are often rejected as being “foreign,” and their “exotic” nature is sometimes even perceived as a threat.
<G-vec00217-002-s178><come.gelangen><de> Die in der Folge entstandene Arbeiten thematisieren unser oft zwiespältiges Verhältnis zum Fremden: so wird das ‚Exotische‘ in Form von Luxusgütern und Essen, etwa den geschätzten Südfrüchten, als positiv und begehrenswert empfunden, während Menschen, die aus denselben Regionen der Erde als Geflüchtete zu uns gelangen, aufgrund ihrer ‚Fremdheit‘ Ablehnung erfahren, oder das ‚Exotische‘ gar als Bedrohung empfunden wird.
<G-vec00217-002-s179><come.gelangen><en> Over the past weeks, frequent interactions took place to come to a common understanding on the way forward for a long-term, strategic ESA–EU partnership, building on the successes so far: Galileo and EGNOS already provide world-class navigation services and Copernicus is the most complete Earth observation system in the world.
<G-vec00217-002-s179><come.gelangen><de> In den letzten Wochen haben zahlreiche Gespräche stattgefunden, um zu einem gemeinsamen Verständnis über das weitere Vorgehen im Hinblick auf eine langfristige strategische Partnerschaft zwischen der ESA und der EU zu gelangen, die auf den bisherigen Erfolgen aufbaut: Galileo und EGNOS bieten bereits Navigationsdienste der Spitzenklasse, und Copernicus ist das umfassendste Erdbeobachtungssystem der Welt.
<G-vec00217-002-s180><come.gelangen><en> Let the inner joy within you come to the surface.
<G-vec00217-002-s180><come.gelangen><de> Lasst die innere Freude inwendig in euch an die Oberfläche gelangen.
<G-vec00217-002-s181><come.gelangen><en> In a further advantageous embodiment of the invention, an impermeable immersion liquid protective layer is at least one surface of the terminating element, which can come into contact with immersion liquid, is applied.
<G-vec00217-002-s181><come.gelangen><de> Bei einer weiteren vorteilhaften Ausgestaltung der Erfindung ist auf wenigstens eine Oberfläche des Abschlußelements, die mit Immersionsflüssigkeit in Berührung gelangen kann, eine für Immersionsflüssigkeit undurchlässige Schutzschicht aufgebracht.
<G-vec00217-002-s182><come.gelangen><en> “Through your prayer, night and day, you bring before God the lives of so many of our brothers and sisters who for various reasons cannot come to him to experience his healing mercy, even as he patiently waits for them.
<G-vec00217-002-s182><come.gelangen><de> Durch euer Gebet tragt ihr Tag und Nacht das Leben vieler Brüder und Schwestern vor den Herrn, die aus verschiedenen Gründen nicht zu ihm gelangen und die Erfahrung seiner heilenden Barmherzigkeit machen können, während er sie erwartet, um ihnen Gnade zu erweisen.
<G-vec00217-002-s183><come.gelangen><en> See what we come to.
<G-vec00217-002-s183><come.gelangen><de> Seht, wozu wir gelangen.
<G-vec00217-002-s184><come.gelangen><en> This affects your health and energy (apart from the fact that plastic residues come into your food).
<G-vec00217-002-s184><come.gelangen><de> Dies ist negativ für Ihre Gesundheit und Energie (neben der Tatsache, dass Plastikreste ins Essen gelangen).
<G-vec00217-002-s185><come.gelangen><en> In Stage 2 of the Product Backlog, Items come exclusively from Stage 3.
<G-vec00217-002-s185><come.gelangen><de> In die Stufe 2 des Product Backlogs gelangen Items ausschließlich aus der Stufe 3.
<G-vec00217-002-s186><come.gelangen><en> From here, the path follows the stream bank and a little further on we come to the narrow part of the stream, where the gorge virtually begins.
<G-vec00217-002-s186><come.gelangen><de> Von hier aus folgt der Pfad dem Flussufer und ein bisschen weiter gelangen wir zur Enge des Flusslaufes, an der die Schlucht eigentlich beginnt.
<G-vec00217-002-s187><come.gelangen><en> With the help of this Upper Force, the world can come to the correct condition.
<G-vec00217-002-s187><come.gelangen><de> Mit Hilfe dieser Höheren Kraft kann die Welt zum richtigen Zustand gelangen.
<G-vec00217-002-s188><come.gelangen><en> We use the information to compile reports and to help us improve the website. The cookies collect information in an anonymous form, including the number of visitors to the websites, where visitors have come to the website from and the pages they visited.
<G-vec00217-002-s188><come.gelangen><de> Wir verwenden diese Daten, um Berichte zu erstellen und unsere Website zu verbessern Die Cookies erfassen Daten anonymisiert; es wird beispielsweise die Anzahl der Website-Besucher registriert, von wo aus Besucher auf die Websites gelangen sowie die Seiten, die sie besuchen.
<G-vec00217-002-s189><come.gelangen><en> Going past St. Johann im Pongau you will finally come to the region of Zell am See-Kaprun and to the Seehotel Bellevue, which is located in Thumersbach on the eastern lakeshore.
<G-vec00217-002-s189><come.gelangen><de> Über St. Johann im Pongau gelangen Sie schließlich in die Region Zell am See-Kaprun und zum Seehotel Bellevue, welches sich bei Thumersbach am östlichen Ufer des Zeller Sees befindet.
<G-vec00217-002-s285><come.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00217-002-s285><come.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00217-002-s286><come.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00217-002-s286><come.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00217-002-s287><come.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00217-002-s287><come.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00217-002-s288><come.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00217-002-s288><come.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00217-002-s289><come.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00217-002-s289><come.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00217-002-s290><come.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00217-002-s290><come.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00217-002-s291><come.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00217-002-s291><come.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00217-002-s292><come.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00217-002-s292><come.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00217-002-s293><come.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00217-002-s293><come.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00217-002-s294><come.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00217-002-s294><come.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00217-002-s295><come.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00217-002-s295><come.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00217-002-s296><come.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00217-002-s296><come.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00217-002-s297><come.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00217-002-s297><come.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00217-002-s298><come.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00217-002-s298><come.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00217-002-s299><come.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00217-002-s299><come.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00217-002-s300><come.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00217-002-s300><come.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00217-002-s301><come.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00217-002-s301><come.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00217-002-s302><come.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00217-002-s302><come.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00217-002-s303><come.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00217-002-s303><come.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00217-002-s551><come.stammen><en> But where does this Life come from to raise the dead?
<G-vec00217-002-s551><come.stammen><de> Woher stammt aber dieses Leben, das die Toten auferstehen lässt.
<G-vec00217-002-s552><come.stammen><en> 93.30% 97.80% The majority of visitors come from United States.
<G-vec00217-002-s552><come.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Deutschland, Reino Unido, Kanada, Indien & Vereinigte Staaten.
<G-vec00217-002-s553><come.stammen><en> Fun fact: Welsh ponies come from Wales and date back to the time of the Celts.
<G-vec00217-002-s553><come.stammen><de> Interessante Tatsache: Das Welsh-Pony stammt aus Wales und hat seine Ursprünge in der Zeit der Kelten.
<G-vec00217-002-s554><come.stammen><en> The majority of visitors come from United States, Italy, Greece, Spain, Poland & Chile.
<G-vec00217-002-s554><come.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Türkei, Polen, Spanien, Niederlande, Schweiz und Deutschland.
<G-vec00217-002-s555><come.stammen><en> Most of our clients come from the creative sector.
<G-vec00217-002-s555><come.stammen><de> Ein Großteil unserer KundInnen stammt aus dem Kreativbereich.
<G-vec00217-002-s556><come.stammen><en> The majority of visitors come from Germany, France, Indonesia, United Kingdom, Austria & Uruguay. City City Rank
<G-vec00217-002-s556><come.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Spanien, Deutschland, Australien, Vietnam, Reino Unido und Schweiz.
<G-vec00217-002-s557><come.stammen><en> Approximately half of all fossil resources now come from sources lying below the sea floor.
<G-vec00217-002-s557><come.stammen><de> Inzwischen stammt rund die Hälfte der fossilen Bodenschätze aus unter dem Meeresgrund liegenden Quellen.
<G-vec00217-002-s558><come.stammen><en> Even his Fleur de Sel does not just come from anywhere, rather he produces it himself.
<G-vec00217-002-s558><come.stammen><de> Auch sein Fleur de Sel stammt nicht von irgendwo, sondern aus seiner eigenen Produktion.
<G-vec00217-002-s559><come.stammen><en> A web analysis service collects, inter alia, data about the website from which a person has come (the so-called referrer), which sub-pages were visited, or how often and for what duration a sub-page was viewed.
<G-vec00217-002-s559><come.stammen><de> Ein Webanalysedienst erhebt unter anderem Daten über die Website, von der eine Person stammt (sogenannter Referrer), welche Unterseiten besucht wurden oder wie oft und für wie lange eine Unterseite aufgerufen wurde.
<G-vec00217-002-s560><come.stammen><en> Those who come from Eritrea and ask for asylum in Switzerland will have higher hurdles in the future.
<G-vec00217-002-s560><come.stammen><de> Wer aus Eritrea stammt und in der Schweiz um Asyl ersucht, hat künftig höhere Hürden.
<G-vec00217-002-s561><come.stammen><en> This is quite correct; but the proletariat must also recognize that the ‘national' element does not come from the oppressed and exploited masses, but from their oppressors and exploiters - the bourgeoisie.
<G-vec00217-002-s561><come.stammen><de> Dies ist ganz richtig, aber das Proletariat muss auch anerkennen, dass das nationale Element nicht von den unterdrückten und ausgebeuteten Massen stammt, sondern von ihren Unterdrückern und Ausbeutern - die Bourgeoisie.
<G-vec00217-002-s562><come.stammen><en> Many of the best grapes come from the limestone Arrábida hills high over the peninsula’s southern coast.
<G-vec00217-002-s562><come.stammen><de> Ein Großteil der besten Trauben stammt aus dem kalksteinhaltigen Arrábida Hügelland, das sich hoch über der südlichen Küste der Halbinsel erstreckt.
<G-vec00217-002-s563><come.stammen><en> Approximately one third of the members come from the fields of administration and education and approximately two thirds from the world of business, from bank institutes to medium-sized companies to global corporations.
<G-vec00217-002-s563><come.stammen><de> Rund ein Drittel der Mitglieder stammt aus dem Verwaltungs- und Bildungsbereich, etwa zwei Drittel aus der Wirtschaft, vom Bankinstitut über das mittelständische Unternehmen bis hin zum Weltkonzern.
<G-vec00217-002-s564><come.stammen><en> The basic prerequisites are that the ingredients come from the region, that production is regional, and that the products are firmly rooted in regional gastronomy.
<G-vec00217-002-s564><come.stammen><de> Grundvoraussetzungen sind, dass der Rohstoff aus der Region stammt, die Produktion örtlich erfolgt und die Produkte in der regionalen Gastronomie verankert sind.
<G-vec00217-002-s565><come.stammen><en> Authentication is a security measure implemented by NTP to ensure that the time signal that is sent comes from where it claims to come from.
<G-vec00217-002-s565><come.stammen><de> Die Authentifizierung ist eine Sicherheitsmaßnahme, die von NTP implementiert wird, um sicherzustellen, dass das gesendete Zeitsignal von der Stelle kommt, von der es angeblich stammt.
<G-vec00217-002-s566><come.stammen><en> The essential oils come from organic farming.
<G-vec00217-002-s566><come.stammen><de> Oliven-ätherische Öl stammt aus kontrolliert biologischem Anbau.
<G-vec00217-002-s567><come.stammen><en> The majority of international clients come from Venezuela, Jordan and China.
<G-vec00217-002-s567><come.stammen><de> Der Großteil der internationalen Kunden stammt aus Venezuela und Jordanien sowie aus China.
<G-vec00217-002-s568><come.stammen><en> Smartly Dressed Games is the name of the company that was created by Nelson and this probably isn’t the last title to come from them.
<G-vec00217-002-s568><come.stammen><de> Smartly Dressed Games ist der Name der Firma, die von Nelson gegründet wurde, und das ist wahrscheinlich nicht der letzte Titel, der von ihnen stammt.
<G-vec00217-002-s569><come.stammen><en> It’s name come from the work “Skufos” which namastea dating means giant cup in ancient Greek, and it is because it looks like one morphologically as it is surrounded from the higher mountain tops of Lefka Ori.
<G-vec00217-002-s569><come.stammen><de> Der Name stammt von “Skufos”, was auf Altgriechisch große Tasse bedeutet: und das aufgrund dessen, weil der Ort von den höheren Berggipfeln von Lefka Ori umgeben ist.
<G-vec00217-002-s570><come.treffen><en> In the process, people can come together who work in various forms of the care sector: professional care providers, caregivers in family and neighbour contexts, and those in self-care situations.
<G-vec00217-002-s570><come.treffen><de> Dabei treffen Menschen zusammen, die in verschiedener Form Arbeitende in diesem Bereich sind: Beruflich Sorgearbeitende, Sorgearbeitende in familiären und nachbarschaftlichen Zusammenhängen und in der Selbstsorge Tätige.
<G-vec00217-002-s571><come.treffen><en> Here you will come across a lot of young people and probably for the first time in a long time feel that there is something happening in the South Island!
<G-vec00217-002-s571><come.treffen><de> Hier wirst du viele junge Menschen treffen und vermutlich zum ersten Mal seit längerer Zeit das Gefühl haben, dass in Neuseeland ja doch etwas los ist.
<G-vec00217-002-s572><come.treffen><en> All the Syrians, as the UN Security Council resolution says, must sit down and come to an agreement.
<G-vec00217-002-s572><come.treffen><de> Alle Syrer sollten in Übereinstimmung mit der Resolution des UN-Sicherheitsrats am Verhandlungstisch zusammenkommen und eine Vereinbarung treffen.
<G-vec00217-002-s573><come.treffen><en> The prophet Isaiah brings to view the fearful deception which will come upon the wicked, causing them to count themselves secure from the judgments of God: "We have made a covenant with death, and with hell are we at agreement. When the overflowing scourge shall pass through, it shall not come unto (378) us; for we have made lies our refuge, and under falsehood have we hid ourselves." Isa.
<G-vec00217-002-s573><come.treffen><de> Der Prophet Jesaja weist auf die furchtbare Täuschung hin, welche über die Gottlosen kommen wird, so daß sie sich vor den Gerichten Gottes sicher fühlen: „Wir haben mit dem Tode einen Bund und mit der Hölle einen Vertrag gemacht; wenn eine Flut dahergeht, wird sie uns nicht treffen; denn wir haben die Lüge zu unserer Zuflucht und Heuchelei zu unserem Schirm gemacht.“ (Jes.
<G-vec00217-002-s574><come.treffen><en> Things often come to me with time, so a day later I sat on the beach and cried.
<G-vec00217-002-s574><come.treffen><de> Einen Tag später – manchmal treffen mich Dinge mit Zeitverzögerung – habe ich dann am Strand gesessen und geweint.
<G-vec00217-002-s575><come.treffen><en> If you cannot manage to come from Sunday to Sunday, try and come from Thursday or Friday evening until Sunday.
<G-vec00217-002-s575><come.treffen><de> Wer nicht von Sonntag bis Sonntag an den Treffen teilnehmen kann, sollte am Donnerstag- oder spätestens Freitagabend ankommen und bis Sonntag bleiben.
<G-vec00217-002-s576><come.treffen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00217-002-s576><come.treffen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00217-002-s577><come.treffen><en> As in the best tradition, the workshop is the natural place in which craftsmanship and design come together, inextricably linking production and design.
<G-vec00217-002-s577><come.treffen><de> Wie in der besten Tradition ist die Werkstatt der Ort, an dem sich Handwerk und Design treffen und dabei Produktion und Planung unlösbar miteinander verbinden.
<G-vec00217-002-s578><come.treffen><en> Numerous national and international representatives from business and politics will come together for this first-class event in order to discuss the most current topics.
<G-vec00217-002-s578><come.treffen><de> Anlässlich des hochkarätigen Anlasses treffen sich zahlreiche nationale und internationale Vertreter aus Wirtschaft und Politik in Vaduz, um topaktuelle Themen zu diskutieren.
<G-vec00217-002-s579><come.treffen><en> Then we pass through the gates of Heaven and come across the proud people who humbly pray the Pater Noster.
<G-vec00217-002-s579><come.treffen><de> Dann werden wir durch die Pforte des Himmels gehen und treffen die Stolzen die demütig das Pater Noster beten.
<G-vec00217-002-s580><come.treffen><en> Digitalisation and sustainability – two key “mega trends” come together.
<G-vec00217-002-s580><come.treffen><de> Digitalisierung und Nachhaltigkeit – hier treffen zwei Megatrends aufeinander.
<G-vec00217-002-s581><come.treffen><en> Schedule of events You can come and get to know the JBL team personally at the following events in April 2018.
<G-vec00217-002-s581><come.treffen><de> Auf folgenden Veranstaltungen können Sie uns im Juni 2018 treffen und das JBL Team persönlich kennenlernen.
<G-vec00217-002-s582><come.treffen><en> Wherever you go, you will come across open-minded people who will be happy to speak English with you.
<G-vec00217-002-s582><come.treffen><de> Überall werden Sie auf aufgeschlossene Menschen treffen, die gerne mit Ihnen Englisch plaudern.
<G-vec00217-002-s583><come.treffen><en> If these high-stakes talks come to pass, they would be the first between a sitting US president and a North Korean leader.
<G-vec00217-002-s583><come.treffen><de> Eine Reise des nordkoreanischen Außenministers nach Schweden nährt nun Spekulationen über den Austragungsort für dieses erste Treffen zwischen einem amtierenden US-Präsidenten und einem nordkoreanischen Machthaber.
<G-vec00217-002-s584><come.treffen><en> Because particular bodily organs correspond to every point, it is possible to come to the conclusion about state of this organs.
<G-vec00217-002-s584><come.treffen><de> Weil es jedem Punkt bestimmte Körperorgane entsprechen, ist auf Grund des gemessenen Widerstandes den Beschluss über den Stand dieser Organe zu treffen.
<G-vec00217-002-s585><come.treffen><en> Graduates of the Master of Science in International Cooperation in Urban Development come upon a broad field of work which has a strong demand for professionals in international projects about urban development.
<G-vec00217-002-s585><come.treffen><de> Absolventen und Absolventinnen des Master of Science International Cooperation in Urban Development treffen auf ein weites Arbeitsfeld mit einer starken Nachfrage nach Fachkräften für internationale Projekte im Bereich der Stadtentwicklung.
<G-vec00217-002-s586><come.treffen><en> Divers, snorkelers and musicians dressed in whimsical nautical costumes come together every year in Florida for the Underwater Music Festival.
<G-vec00217-002-s586><come.treffen><de> Taucher, Schnorchler und Musiker treffen sich Jahr für Jahr in Florida für das Unterwasser-Musik-Festival.
<G-vec00217-002-s587><come.treffen><en> The event aims to create a space in which different voices come together to start dialogue and find solutions and answers to the social, emotional and health problems that women face in today's society. The Forum is an open event, free of charge, with an open debate on women's issues.
<G-vec00217-002-s587><come.treffen><de> Mit diesem Forum will versucht werden ein Raum zu schaffen, in welchem sich verschiedene Stimmen treffen, unterschiedliche Meinungen ausgetauscht werden um so einen Dialog anzuregen und Lösungen und Antworten auf die soziale, emotionale und gesundheitliche Problematik zu finden, mit welcher sich die Frau tagtäglich in der Gesellschaft konfrontiert sieht.
<G-vec00217-002-s588><come.treffen><en> In the living room, family and friends come together for mutual hours.
<G-vec00217-002-s588><come.treffen><de> Im Wohnzimmer treffen sich Familie und Freunde für gemeinsame Stunden.
<G-vec00217-002-s589><come.treten><en> Also the cooperation with students regarding bachelor’s and master’s theses as well as compulsory internships, new findings come to light that are included in further product development.
<G-vec00217-002-s589><come.treten><de> Auch bei der Zusammenarbeit mit Studierenden in Hinblick auf Bachelor- und Masterarbeiten sowie Pflichtpraktika treten regelmäßig neue Erkenntnisse zu Tage, die in die weitere Produktentwicklung miteinfließen.
<G-vec00217-002-s590><come.treten><en> Lung cancer typically develops slowly and symptoms often come on gradually.
<G-vec00217-002-s590><come.treten><de> Lungenkrebs entwickelt sich gewöhnlich langsam und die Symptome treten oft schrittweise auf.
<G-vec00217-002-s591><come.treten><en> They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.
<G-vec00217-002-s591><come.treten><de> Und sie sollen hineingehen in mein Heiligtum und vor meinen Tisch treten, mir zu dienen und meine Sitten zu halten.
<G-vec00217-002-s592><come.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which lie outside the area of responsibility of the author, a liability obligation would come into force only in the case in which the contents are aware and technically possible and reasonable, the Use in case of illegal content.
<G-vec00217-002-s592><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s593><come.treten><en> In the case of direct or indirect references to third-party websites ("hyperlinks"), which are outside the responsibility of the author, a liability obligation would only come into force in the case in which the author is aware of the contents and is technically possible and reasonable, To prevent the use in the case of unlawful content.
<G-vec00217-002-s593><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten (“Hyperlinks”), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s594><come.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which are beyond the scope of responsibility of Ryf Sports, a liability obligation would only come into effect in the case in which Ryf Sports is aware of the content and it technically possible and reasonable to prevent the use of illegal content.
<G-vec00217-002-s594><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches von Ryf Sports liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem Ryf Sports von den Inhalten Kenntnis hat und es technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s595><come.treten><en> emmerich exclusivbrillen GmbH & Co. reserves the right to amend the conditions of the present agreement in part or in full at any time and any such amendments come into force immediately following their publication on the website.
<G-vec00217-002-s595><come.treten><de> emmerich exclusivbrillen GmbH & Co.KG behält sich das Recht vor, die Bestimmungen dieses Vertrages jederzeit, ganz oder teilweise abzuändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Webseite in Kraft.
<G-vec00217-002-s596><come.treten><en> The resolutions passed at the Extraordinary General Meeting of Kaba will come into effect upon completion of the merger.
<G-vec00217-002-s596><come.treten><de> Die Beschlüsse der außerordentlichen Generalversammlung von Kaba treten mit dem Vollzug des Zusammenschlusses in Kraft.
<G-vec00217-002-s597><come.treten><en> Any provision of the Contract that expressly or by implication is intended to come into or continue in force on or after termination shall remain in full force and effect.
<G-vec00217-002-s597><come.treten><de> 8.6 Jedwede Bestimmung des Vertrags, die ausdrücklich oder stillschweigend in Kraft treten oder bei oder nach Kündigung in Kraft bleiben soll, bleibt in Kraft.
<G-vec00217-002-s600><come.treten><en> If amendments are merely insignificant, they shall come into force immediately.
<G-vec00217-002-s600><come.treten><de> Sollte es sich lediglich um unwesentliche Änderungen handeln, treten diese umgehend in Kraft.
<G-vec00217-002-s601><come.treten><en> Everybody shall come in touch with their own greatness, their own divinity.
<G-vec00217-002-s601><come.treten><de> Jeder soll vielmehr mit seiner eigenen Größe, seiner eigenen Göttlichkeit in Verbindung treten.
<G-vec00217-002-s602><come.treten><en> All direct or indirect references to other Internet sites (links), which lie outside the area of responsibility of the author, any liability obligation would only come into effect if the author is aware of the contents, and it would be technically possible and reasonable for him to prevent the use in the event of illegal contents.
<G-vec00217-002-s602><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s603><come.treten><en> Straight line projection of the zone upwards indicates that it will come to surface (likely under till cover) very near the north boundary of the Burns Block.
<G-vec00217-002-s603><come.treten><de> Die geradlinige Weiterführung der Zone nach oben weist darauf hin, dass sie sehr nahe an der nördlichen Grenze des Burns Blocks zu Tage treten wird (wahrscheinlich unterhalb einer Geschiebemergelschicht).
<G-vec00217-002-s604><come.treten><en> The changed terms and conditions come in the place of the previous version of the General Terms and Conditions.
<G-vec00217-002-s604><come.treten><de> Die geänderten Bedingungen treten an die Stelle der vorhergehenden allgemeinen Geschäftsbedingungen.
<G-vec00217-002-s605><come.treten><en> In the case of direct or indirect references to external websites („links“), which are outside the responsibility of the website operator, a liability obligation would only come into force in the case where the website operator is aware of the contents and it is technically possible for him And it would be reasonable to prevent the use of illegal contents.
<G-vec00217-002-s605><come.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00217-002-s607><come.treten><en> The new prices will come into force from the announcement of the regulation. The cost of transport and other expenses are calculated separately.
<G-vec00217-002-s607><come.treten><de> Die neuen Preise treten mit der Bekanntgabe der Verordnung in Kraft, die Kosten für Transport und Sonstiges werden gesondert berechnet.
<G-vec00217-002-s627><come.verfügen><en> The rooms, suites and apartments at Garni Anni come with a balcony with mountain views and a bathroom with shower or bath.
<G-vec00217-002-s627><come.verfügen><de> Die Zimmer, Suiten und Apartments im Garni Anni verfügen über einen Balkon mit Bergblick und ein Badezimmer mit einer Dusche oder Badewanne.
<G-vec00217-002-s628><come.verfügen><en> All of our products come with a 100 percent guarantee of customer satisfaction.
<G-vec00217-002-s628><come.verfügen><de> Alle unsere Produkte verfügen über eine 100-prozentige Garantie der Zufriedenheit unserer Kunden.
<G-vec00217-002-s629><come.verfügen><en> Rooms come with flat-screen TVs and tea/coffee making facilities.
<G-vec00217-002-s629><come.verfügen><de> Die Zimmer verfügen über einen Flachbild-TV sowie Tee- und Kaffeezubehör.
<G-vec00217-002-s630><come.verfügen><en> The welcoming rooms come with a bathroom with a hairdryer, a direct dial telephone, a hire safe and a minibar.
<G-vec00217-002-s630><come.verfügen><de> Die freundlich eingerichteten Zimmer verfügen über Bad/WC, Haartrockner, Minibar, Mietsafe und Direktwahltelefon.
<G-vec00217-002-s631><come.verfügen><en> Rooms at Sheraton Sopot come with air conditioning and a flat-screen satellite TV.
<G-vec00217-002-s631><come.verfügen><de> Die Zimmer im Sheraton Colonia Golf And Spa Resort verfügen über eine Minibar, einen TV und ein eigenes Bad.
<G-vec00217-002-s632><come.verfügen><en> All these pickups come with 25K pots, stereo jack, battery clip and other mounting hardware.
<G-vec00217-002-s632><come.verfügen><de> Alle AHB-1 Tonabnehmer verfügen über 25K Töpfe, Klinkenstecker, Batterie-Clip und andere Montage-Hardware.
<G-vec00217-002-s633><come.verfügen><en> Divná pani Luxury Gallery Rooms provides certain rooms with garden views, and all rooms come with a private bathroom.
<G-vec00217-002-s633><come.verfügen><de> Das Divná pani Luxury Gallery Rooms bietet Zimmer mit Gartenblick und alle Zimmer verfügen über ein eigenes Bad.
<G-vec00217-002-s634><come.verfügen><en> All units come with a terrace, a kitchenette with a fridge, and a private bathroom with bath or shower.
<G-vec00217-002-s634><come.verfügen><de> Die modernen Zimmer verfügen über Holzböden, Kabel/Sat-TV, einen Wasserkocher sowie ein eigenes Bad mit einer Warmwasserdusche.
<G-vec00217-002-s635><come.verfügen><en> They come with a microwave, an electric kettle and a fridge as well as bathrooms with a shower, a spa bathtub and dressing gowns.
<G-vec00217-002-s635><come.verfügen><de> Sie verfügen über eine Mikrowelle, einen Wasserkocher und eine Kaffee-/Teemaschine sowie über private Badezimmer mit einer Dusche, einem Jacuzzi und kostenlosen Pflegeprodukten.
<G-vec00217-002-s636><come.verfügen><en> The rooms come with a private or shared bathroom.
<G-vec00217-002-s636><come.verfügen><de> Alle Zimmer verfügen über ein eigenes Bad oder bieten Zugang zu einem Gemeinschaftsbad.
<G-vec00217-002-s637><come.verfügen><en> Thus they are virtually maintenance-free, very rarely prone to malfunctions, require no lubricants, may be positioned exactly, have a constant stroke speed, and come with a mechanical self-locking mechanism.
<G-vec00217-002-s637><come.verfügen><de> So sind sie nahezu wartungsfrei, wenig fehleranfällig, schmiermittelfrei, exakt positionierbar und verfügen über eine konstante Hubgeschwindigkeit sowie über eine mechanische Selbsthemmung.
<G-vec00217-002-s638><come.verfügen><en> All units come with a patio, a kitchen with an oven and a microwave, and a private bathroom with bidet.
<G-vec00217-002-s638><come.verfügen><de> Alle Unterkünfte verfügen über eine Terrasse, eine Küche mit einem Backofen und einer Mikrowelle sowie ein eigenes Bad mit einem Bidet.
<G-vec00217-002-s639><come.verfügen><en> Bathrooms come with a shower, complimentary toiletries and towels.
<G-vec00217-002-s639><come.verfügen><de> Badezimmer verfügen über eine Dusche, einen Fön und Handtücher.
<G-vec00217-002-s640><come.verfügen><en> All rooms at the Cinco Calderas come with en suite bathroom complete with amenities.
<G-vec00217-002-s640><come.verfügen><de> Alle Zimmer im Cinco Calderas verfügen über ein eigenes Bad mit Pflegeprodukten.
<G-vec00217-002-s641><come.verfügen><en> rooms at the Linne come with satellite TV, tea/coffee facilities and a private bathroom with a shower.
<G-vec00217-002-s641><come.verfügen><de> Die hellen Zimmer im Linne verfügen über Sat-TV, Kaffee- und Teezubehör sowie ein eigenes Bad mit einer Dusche.
<G-vec00217-002-s642><come.verfügen><en> Featuring a balcony with outdoor furniture, the bright apartments come with tiled floors and a kitchenette.
<G-vec00217-002-s642><come.verfügen><de> Die hellen Apartments verfügen über einen Balkon mit Gartenmöbeln sowie Fliesenböden und eine Küchenzeile.
<G-vec00217-002-s643><come.verfügen><en> All wooden furnished, rooms here come with Satellite television, a fan, and a desk.
<G-vec00217-002-s643><come.verfügen><de> Alle mit Holz eingerichteten Zimmer verfügen über Sat-TV, einen Ventilator und einen Schreibtisch.
<G-vec00217-002-s644><come.verfügen><en> The non-smoking apartments and studios at the Cathedral all come with a private bathroom with a shower or a bathtub, a fully equipped kitchenette, and a satellite TV.
<G-vec00217-002-s644><come.verfügen><de> Die rauchfreien Apartments und Studios im Cathedral verfügen alle über ein eigenes Bad mit einer Dusche oder einer Badewanne, eine komplett ausgestattete Küchenzeile und Sat-TV.
<G-vec00217-002-s645><come.verfügen><en> Newer DVD players often come with a high definition upconversion feature as well.
<G-vec00217-002-s645><come.verfügen><de> Neuere DVD-Player verfügen häufig auch über eine Funktion zur Konvertierung in High Definition.
<G-vec00218-002-s133><come.gehen><en> There are breathtaking film sets where visitors can come into close contact with the jaws of a great white shark, look underneath Marilyn Monroe's skirt or learn about fear at Jurassic Park.
<G-vec00218-002-s133><come.gehen><de> In atemberaubenden Filmkulissen können Besucher auf Tuchfühlung mit dem weißen Hai gehen, Marilyn Monroe unter den Rock schauen oder im Jurassic Park das Fürchten lernen.
<G-vec00218-002-s134><come.gehen><en> 44:25 And they shall come at no dead person to become unclean; but for father, or for mother, or for son, or for daughter, for brother, or for sister that hath had no husband, they may become unclean.
<G-vec00218-002-s134><come.gehen><de> 44:25 Und keiner soll zu dem Leichnam eines Menschen gehen, daß er unrein werde; nur allein wegen Vater und Mutter, und wegen Sohn und Tochter, wegen eines Bruders und wegen einer Schwester, die keines Mannes gewesen ist, dürfen sie sich verunreinigen.
<G-vec00218-002-s135><come.gehen><en> This is where interfaces and the single responsibility principle can come to work hand in hand.
<G-vec00218-002-s135><come.gehen><de> Hier können Schnittstellen und das Prinzip der einheitlichen Verantwortung Hand in Hand gehen.
<G-vec00218-002-s136><come.gehen><en> May your dream will come true this year.
<G-vec00218-002-s136><come.gehen><de> Möge Eure Wünsche auch in diesem Jahr in Erfüllung gehen.
<G-vec00218-002-s137><come.gehen><en> I hope you have a wonderful new year, and all your dreams and wished come true next year.
<G-vec00218-002-s137><come.gehen><de> Ich hoffe ihr habt ein wunderschönes neues Jahr und all eure Wünsche und Träume gehen dieses Jahr in Erfüllung.
<G-vec00218-002-s138><come.gehen><en> Sport has always played an important role in my life, in part because I come from a family of athletes.
<G-vec00218-002-s138><come.gehen><de> Auch Sport spielte schon immer eine wichtige Rolle in meinem Leben, egal ob Fußball spielen mit meinen Freunden oder einfach im Morgengrauen joggen gehen.
<G-vec00218-002-s139><come.gehen><en> Bishops should encourage priests to come to Medjugorje, to Our Lady's school.
<G-vec00218-002-s139><come.gehen><de> Die Bischöfe sollten die Menschen ermutigen, nach Medjugorje zu gehen, in die Schule der Muttergottes.
<G-vec00218-002-s140><come.gehen><en> 29 Let no evil talk come out of your mouths, but only what is useful for building up, as there is need, so that your words may give grace to those who hear.
<G-vec00218-002-s140><come.gehen><de> 29 Lasset kein faul Geschwätz aus eurem Munde gehen, sondern was nützlich zur Besserung ist, wo es not tut, daß es holdselig sei zu hören.
<G-vec00218-002-s141><come.gehen><en> It's just necessary to come to a doctor and pick up that medicine, which, according to the dose and type of hormone, will suit you.
<G-vec00218-002-s141><come.gehen><de> Es ist nur notwendig, zu einem Arzt zu gehen und die Medizin zu holen, die je nach Dosis und Art des Hormons zu Ihnen passt.
<G-vec00218-002-s142><come.gehen><en> Numerous performers, musicians, actors and entertainers come out onto the streets, and the entire city operates as a public space for the presentation of Croatian tradition.
<G-vec00218-002-s142><come.gehen><de> Viele Darsteller, Musiker, Performance-Künstler, Schauspieler und Unterhalter gehen auf die Straßen, während die ganze Stadt den Eindruck erweckt, ein öffentlicher Raum für die Vorstellung der kroatischen Tradition zu sein.
<G-vec00218-002-s143><come.gehen><en> The gift certificates of Ferienart Resort & Spa are always welcome and make small and bigger dreams come true.
<G-vec00218-002-s143><come.gehen><de> Die Geschenkgutscheine des Ferienart Resort & Spa sind immer willkommen und lassen kleine und größere Wünsche in Erfüllung gehen.
<G-vec00218-002-s144><come.gehen><en> But these privileges also come with duties.
<G-vec00218-002-s144><come.gehen><de> Diese Privilegien gehen jedoch mit Pflichten einher.
<G-vec00218-002-s145><come.gehen><en> They remind you that difficult moments and things that come to an end are signs of something beautiful and new that will soon arise.
<G-vec00218-002-s145><come.gehen><de> Sie erinnern daran, dass schwierige Momente und Dinge, die zu Ende gehen, Zeichen von etwas Schönem und Neuem sind, das bald auftauchen wird.
<G-vec00218-002-s146><come.gehen><en> Who listens to me, he has won much, because what I promise a man will indeed come true.
<G-vec00218-002-s146><come.gehen><de> Wer Mich anhöret, der hat viel gewonnen, denn was Ich einem Menschen verspreche, wird wahrlich in Erfüllung gehen.
<G-vec00218-002-s147><come.gehen><en> Thus, you will never come up empty and your apartment is always visitors fit, no matter what happens.
<G-vec00218-002-s147><come.gehen><de> Somit gehen Sie nie leer aus und Ihre Wohnung ist immer besuchertauglich, egal was auch passiert.
<G-vec00218-002-s148><come.gehen><en> Legend has it that if you want something while you ring the church bell, your wish might come true.
<G-vec00218-002-s148><come.gehen><de> Die Legende besagt es, wenn Sie etwas wünschen, während Sie die Kirchenglocke läuten, könnte Ihr Wunsch in Erfüllung gehen.
<G-vec00218-002-s149><come.gehen><en> 20 And now you will be silent and not able to speak until the day this happens, because you did not believe my words, which will come true at their appointed time.” (Luke 1:13-20)
<G-vec00218-002-s149><come.gehen><de> 1:20 Aber weil du meinen Worten nicht geglaubt hast, die in Erfüllung gehen, wenn die Zeit dafür da ist, sollst du stumm sein und nicht mehr reden können bis zu dem Tag, an dem all das eintrifft.
<G-vec00218-002-s150><come.gehen><en> They pleaded with me not to come.
<G-vec00218-002-s150><come.gehen><de> Sie haben auf mich eingeredet, nicht zu gehen.
<G-vec00218-002-s151><come.gehen><en> Because every Theum virtual expert knows about the others, users can query across them transparently and in parallel as new ones come online—without having to know where to look.
<G-vec00218-002-s151><come.gehen><de> Weil jeder virtuelle Experte von Theum jeden anderen „kennt“, können Anwender Abfragen über alle virtuellen Experten hinweg transparent und parallel ausführen, sobald neue virtuellen Experten online gehen – ohne deren Adresse zu kennen.
