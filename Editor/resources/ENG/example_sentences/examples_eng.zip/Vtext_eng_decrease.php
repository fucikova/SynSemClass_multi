<G-vec00028-002-s076><decrease.abnehmen><en> It is not surprising that the discussions around the topic AI don’t decrease.
<G-vec00028-002-s076><decrease.abnehmen><de> Es ist also nicht verwunderlich, dass die Diskussionen um KI nicht abnehmen.
<G-vec00028-002-s077><decrease.abnehmen><en> Do not rule out toxicity based on a normal CO level because levels can decrease rapidly, particularly after treatment with supplemental O2.
<G-vec00028-002-s077><decrease.abnehmen><de> Eine Toxizität sollte nicht aufgrund eines normalen CO-Wertes ausgeschlossen werden, weil die Werte schnell abnehmen, insbesondere nach einer Behandlung mit O2.
<G-vec00028-002-s078><decrease.abnehmen><en> However, with the introduction of complementary foods, the need for breast milk and the mixture will decrease, and in parallel with this, and spending money.
<G-vec00028-002-s078><decrease.abnehmen><de> Mit der Einführung von Ergänzungsnahrung wird jedoch der Bedarf an Muttermilch und der Mischung abnehmen und parallel dazu Geld ausgeben.
<G-vec00028-002-s079><decrease.abnehmen><en> Decrease before the 1 edge stitch in garter stitch when the next to last stitch on the row is in garter stitch as follows: Work until there are 3 stitches left on the row, slip 1 stitch as if to knit, knit 1 and pass the slipped stitch over the knitted stitch.
<G-vec00028-002-s079><decrease.abnehmen><de> Vor 1 kraus rechten Rand-Masche, wenn die vorletzte Masche kraus rechts gestrickt wird, wie folgt abnehmen: Stricken bis noch 3 Maschen auf der Nadel sind, 1 Masche wie zum Rechtsstricken abheben, 1 Masche rechts, die abgehobene Masche über die gestrickte ziehen.
<G-vec00028-002-s080><decrease.abnehmen><en> The development project “Wollerau Park” in Switzerland will be completed in the first quarter of 2018 and the proportion of development projects will further decrease significantly.
<G-vec00028-002-s080><decrease.abnehmen><de> Anfang 2018 wird dann das derzeit im Bau befindliche Entwicklungsprojekt „Wollerau Park“ in der Schweiz abgeschlossen und der Anteil der Entwicklungsprojekte nochmals deutlich abnehmen.
<G-vec00028-002-s081><decrease.abnehmen><en> Decrease 1 stitch after the 5 band stitches as follows (applies to right front piece): Work 5 band stitches in garter stitch, slip 1 stitch as if to knit, knit 1, pass the slipped stitch over (= 1 stitch decreased).
<G-vec00028-002-s081><decrease.abnehmen><de> 1 Masche nach 5 Blenden-Maschen wie folgt abnehmen (gilt für das rechte Vorderteil): 5 Blenden-Maschen kraus rechts, 1 Masche wie zum Rechtsstricken abheben, 1 Masche rechts, die abgehobene Masche überziehen (= 1 Masche abgenommen).
<G-vec00028-002-s082><decrease.abnehmen><en> In scenario A2, an annual rise in temperature by 3.2-4.8 °C can be expected, with a 21-28 % decrease in precipitation in the summer months.
<G-vec00028-002-s082><decrease.abnehmen><de> Beim Szenario A2 wird eine jährliche Temperaturzunahme um 3,2-4,8 °C erwartet, die Niederschlagsmenge im Sommer dürfte um 21-28 % abnehmen.
<G-vec00028-002-s083><decrease.abnehmen><en> A grain in the balance will determine which individual shall live and which shall die,—which variety or species shall increase in number, and which shall decrease, or finally become extinct.
<G-vec00028-002-s083><decrease.abnehmen><de> Ein Gran in der Wage kann den Ausschlag geben, welches Individuum fortleben und welches zu Grunde gehen soll, welche Art oder Abart sich vermehren und welche abnehmen und endlich erlogenen muss.
<G-vec00028-002-s084><decrease.abnehmen><en> For example, the characteristic resistance of a fastening may decrease with increasing embedment depth of the anchor.
<G-vec00028-002-s084><decrease.abnehmen><de> Zum Beispiel kann der charakteristische Widerstand einer Befestigung mit zunehmender Verankerungstiefe der Dübel abnehmen.
<G-vec00028-002-s085><decrease.abnehmen><en> While Lord Flight stated that no one knew the answer to this question, Lord Davies affirmed that if the UK would leave the EU, European investments would decrease immensely.
<G-vec00028-002-s085><decrease.abnehmen><de> Laut Lord Flight kenne niemand eine Antwort auf diese Frage und Lord Davies beteuerte, dass wenn Großbritannien die EU verlasse, europäische Investitionen stark abnehmen würden.
<G-vec00028-002-s086><decrease.abnehmen><en> Research has shown that as the number of layers increases, spoilage and losses decrease, and nutritional content can improve.
<G-vec00028-002-s086><decrease.abnehmen><de> Die Forschung hat gezeigt, dass mit steigender Anzahl Folienlagen Verluste abnehmen und der Nährstoffgehalt verbessert werden kann.
<G-vec00028-002-s087><decrease.abnehmen><en> Gradually, this need will decrease, but it is also unknown when your child will refuse to suck at all - perhaps by the year, and maybe a little later.
<G-vec00028-002-s087><decrease.abnehmen><de> Allmählich wird dieses Bedürfnis abnehmen, aber es ist auch nicht bekannt, wann sich Ihr Kind überhaupt weigert zu saugen - vielleicht nach dem Jahr und vielleicht ein wenig später.
<G-vec00028-002-s088><decrease.abnehmen><en> The authors also found out that the number of nuclear power plants will decrease worldwide over the next decades.
<G-vec00028-002-s088><decrease.abnehmen><de> Die Autoren der Studie stellen außerdem fest, dass die Anzahl der Atomkraftwerke in den nächsten Jahrzehnten weltweit abnehmen wird.
<G-vec00028-002-s089><decrease.abnehmen><en> Although near-term production mining activities will continue to support the mine plan, we expect our average GEO grades to remain at second half 2015 levels (or decrease) until more historical mining areas and the recently discovered 505 vein are brought into production.
<G-vec00028-002-s089><decrease.abnehmen><de> Obwohl die kurzfristigen Abbauaktivitäten den Minenplan weiterhin unterstützen, so erwarten wir, dass unsere durchschnittlichen GEO-Gehalte auf den Niveaus der zweiten Jahreshälfte 2015 verbleiben (oder abnehmen) bis weitere historische Abbaubereiche und der vor Kurzem entdeckte Erzgang 505 zur Produktion gebracht wird.
<G-vec00028-002-s090><decrease.abnehmen><en> Ocean pH will continue to decrease in response to increasing CO2 concentrations in the atmosphere; coral reefs in Europe´s overseas territories, centres of biodiversity, are threatened by both increasing temperatures and acidification. European Policies
<G-vec00028-002-s090><decrease.abnehmen><de> Der pH-Wert der Ozeane wird als Reaktion auf die steigenden CO2-Konzentrationen in der Atmosphäre weiterhin abnehmen; die Korallenriffe als Zentren der biologischen Vielfalt in den europäischen Überseegebieten sind durch steigende Temperaturen und Versauerung bedroht.
<G-vec00028-002-s091><decrease.abnehmen><en> Drying time may suddenly increase or decrease time to time.
<G-vec00028-002-s091><decrease.abnehmen><de> Die Trocknungszeit kann von Zeit zu Zeit plötzlich zunehmen oder abnehmen.
<G-vec00028-002-s092><decrease.abnehmen><en> He must increase, but I must decrease.
<G-vec00028-002-s092><decrease.abnehmen><de> Er muss steigen, aber ich muss abnehmen.
<G-vec00028-002-s093><decrease.abnehmen><en> John 3/30 He must increase, but I must decrease.
<G-vec00028-002-s093><decrease.abnehmen><de> Johannes 3/30 Er muss wachsen, ich aber abnehmen.
<G-vec00028-002-s094><decrease.abnehmen><en> If we add milder winters due to climate change to this scenario, the double-whammy effect should cause this circulation to decrease, according to our estimations, by about 30 percent.
<G-vec00028-002-s094><decrease.abnehmen><de> Wenn dann noch mildere Winter im Klimawandel hinzukommen, führen die beiden Effekte zusammen dazu, dass nach unseren Schätzungen diese Zirkulation um 30 Prozent abnehmen wird.
<G-vec00028-002-s095><decrease.abnehmen><en> The body of a pregnant woman is weakened, more vulnerable and defenseless, so there is a decrease in immunity.
<G-vec00028-002-s095><decrease.abnehmen><de> Der Körper einer schwangeren Frau ist geschwächt, verletzlicher und wehrloser, so dass die Immunität abnimmt.
<G-vec00028-002-s096><decrease.abnehmen><en> When the revs decrease, the springs will retract and disengage, nice and smooth.
<G-vec00028-002-s096><decrease.abnehmen><de> Wenn die Drehzahl abnimmt, zieht sich die Feder zusammen und kuppelt angenehm und sanft aus.
<G-vec00028-002-s097><decrease.abnehmen><en> Battery Charge State: as the battery voltage does decrease over its discharge cycle you can choose the state of your battery at measurement for better comparison:
<G-vec00028-002-s097><decrease.abnehmen><de> Da die von der Batterie abgegebene Spannung über einen Entladezyklus sukzessive abnimmt, wird sie auch je nach Ladezustand einen unterschiedlichen Messungwert liefern.
<G-vec00028-002-s098><decrease.abnehmen><en> This means that the number of times you must restart the system in order to apply an update will decrease with Windows Vista.
<G-vec00028-002-s098><decrease.abnehmen><de> Das bedeutet, dass die Anzahl der erforderlichen Neustarts des Systems zum Anwenden eines Updates mit Windows Vista abnimmt.
<G-vec00028-002-s099><decrease.abnehmen><en> If the sodium level in blood continues to decrease or does not increase despite restriction of fluid intake, doctors may prescribe drugs such as demeclocycline or lithium, which decrease the effect of vasopressin on the kidneys, or newer drugs such as conivaptan and tolvaptan, which block vasopressin receptors and prevent the kidneys from responding to vasopressin.
<G-vec00028-002-s099><decrease.abnehmen><de> Wenn der Natriumspiegel im Blut weiter abnimmt oder trotz Beschränkung der Flüssigkeitszufuhr nicht zunimmt, können Arzneimittel wie Demeclocyclin und Lithium, die die Wirkung des antidiuretischen Hormons auf die Nieren reduzieren, oder neuere Arzneimittel wie Conivaptan und Tolvaptan, die die Rezeptoren für antidiuretisches Hormon blockieren und die Reaktion der Nieren auf das antidiuretische Hormon verhindern, angewendet werden.
<G-vec00028-002-s100><decrease.abnehmen><en> The expected side effects with ABSTRAL are the typical adverse effects of opioids that will decrease in intensity with continued treatment.
<G-vec00028-002-s100><decrease.abnehmen><de> Die erwarteten Nebenwirkungen von ABSTRAL sind die typischen Nebenwirkungen von Opioiden, deren Intensität mit fortgesetzter Behandlung abnimmt.
<G-vec00028-002-s101><decrease.abnehmen><en> The treatment aims to relax tense, knotted and cramping muscles, to increase blood supply. The effect is the decrease of muscular pain and the increase of muscular strength.
<G-vec00028-002-s101><decrease.abnehmen><de> Die Behandlung zielt darauf ab, angespannt, krampfhafte Muskeln zu entspannen, Blutversorgung zu erhöhen, durch die die Muskelschmerzen abnimmt und die Stärke der Muskeln erhöht.
<G-vec00028-002-s102><decrease.abnehmen><en> Many young mothers notice that as soon as the crumbs are half a year old, the amount of milk begins to decrease.
<G-vec00028-002-s102><decrease.abnehmen><de> Viele junge Mütter bemerken, dass die Milchmenge abnimmt, sobald die Krümel ein halbes Jahr alt sind.
<G-vec00028-002-s103><decrease.abnehmen><en> In patients with periodontitis, a decrease in the diversity of the oral flora coincides with an increase in the frequency of E. gingivalis.
<G-vec00028-002-s103><decrease.abnehmen><de> Während die bakterielle Vielfalt der Mundhöhle abnimmt, steigt die Häufigkeit von Entamoeba gingivalis (E. gingivalis) bei einer schweren Parodontitis sehr stark an.
<G-vec00028-002-s104><decrease.abnehmen><en> The green color palette indicates the 50% municipalities with the lowest increase or even a decrease of poverty rates by using the relative approach.
<G-vec00028-002-s104><decrease.abnehmen><de> Grün eingefärbt sind jene 50% der Gemeinden, in denen die Armutsquote durch den regionalen Ansatz nur sehr wenig ansteigt oder sogar abnimmt.
<G-vec00028-002-s105><decrease.abnehmen><en> CONSTANT LIGHTING: ensures that the light intensity does not decrease constantly.
<G-vec00028-002-s105><decrease.abnehmen><de> KONSTANTE BELEUCHTUNG: Stellt sicher, dass die Lichtintensität nicht ständig abnimmt.
<G-vec00028-002-s106><decrease.abnehmen><en> Although the remaining reduction potential continues to decrease, it is however exploited.
<G-vec00028-002-s106><decrease.abnehmen><de> Obwohl das verbleibende Reduktionspotential immer weiter abnimmt, wird es dennoch ausgeschöpft.
<G-vec00028-002-s107><decrease.abnehmen><en> But sometimes people themselves are to blame for the fact that the amount of this useful substance starts to decrease steadily.
<G-vec00028-002-s107><decrease.abnehmen><de> Aber manchmal sind die Menschen selbst dafür verantwortlich, dass die Menge dieser nützlichen Substanz stetig abnimmt.
<G-vec00028-002-s108><decrease.abnehmen><en> In this case, you can wash your eyes with a decoction of chamomile, but if the discharge from the eyes does not decrease, it is better to consult a doctor.
<G-vec00028-002-s108><decrease.abnehmen><de> In diesem Fall können Sie Ihre Augen mit einer Abkochung von Kamille waschen, aber wenn die Entladung aus den Augen nicht abnimmt, ist es besser, einen Arzt zu konsultieren.
<G-vec00028-002-s109><decrease.abnehmen><en> Removing these items can drastically decrease your unintentional arousal, leading to a decrease in your impulse to masturbate.
<G-vec00028-002-s109><decrease.abnehmen><de> Indem du diese Dinge aus deinem Umfeld entfernst, kannst du eine ungewollte Erregung drastisch reduzieren, wodurch dein Impuls zu masturbieren abnimmt.
<G-vec00028-002-s110><decrease.abnehmen><en> But there are frequent situations when there is a decrease in lactation during breastfeeding, the milk suddenly starts to burn out.
<G-vec00028-002-s110><decrease.abnehmen><de> Aber es gibt häufige Situationen, in denen die Stillzeit während des Stillens abnimmt, die Milch beginnt plötzlich zu brennen.
<G-vec00028-002-s111><decrease.abnehmen><en> It simply is not bringing enough profit anymore, due to the human-caused decrease of biodiversity in the Baltic Sea.
<G-vec00028-002-s111><decrease.abnehmen><de> Sie bringt einfach nicht mehr genug Gewinn, weil die Artenvielfalt in der Ostsee durch den Menschen abnimmt.
<G-vec00028-002-s112><decrease.abnehmen><en> As ceramide levels decrease with age, fine lines and wrinkles appear.
<G-vec00028-002-s112><decrease.abnehmen><de> Wenn die Konzentration an Ceramiden mit zunehmendem Alter abnimmt, treten Falten und Fältchen auf.
<G-vec00028-002-s113><decrease.abnehmen><en> In France, where temperatures broke records in July, the heatwave is expected to cause one of the country’s biggest exports, wine, to decrease by up to 13%.
<G-vec00028-002-s113><decrease.abnehmen><de> In Frankreich, wo die Temperaturen im Juli Rekordhöhen erreichten, dürfte die Hitzewelle dazu führen, dass die Weinproduktion, eines der wichtigsten Exportgüter des Landes, um bis zu 13 % abnimmt.
<G-vec00028-002-s114><decrease.absinken><en> The main cause of joint problems is a decrease in the level of hyaluronic acid in the cartilage and joint fluid.
<G-vec00028-002-s114><decrease.absinken><de> Die Hauptursache der Gelenkprobleme ist das Absinken des Hyaluronsäurepegels im Knorpel und in der Gelenkflüssigkeit.
<G-vec00028-002-s115><decrease.absinken><en> The Company expects revenue in the Commercial Vehicles business area to decrease slightly by up to five percent while revenue in the Power Engineering business area is likely to increase by five percent.
<G-vec00028-002-s115><decrease.absinken><de> Demnach rechnet das Unternehmen mit einem leichten Absinken des Umsatzes im Geschäftsfeld Commercial Vehicles um bis zu fünf Prozent, während der Umsatz im Geschäftsfeld Power Engineering um fünf Prozent zulegen dürfte.
<G-vec00028-002-s116><decrease.absinken><en> This increase of wages means widened domestic markets without a decrease in the rate and amount of profit, in other words, without weakening the motive of capitalist production.
<G-vec00028-002-s116><decrease.absinken><de> Diese Lohnerhöhung bedeutet erweiterte Binnenmärkte ohne Absinken von Profitrate und -menge, d.h. ohne Schwächung des Antriebs der kapitalistischen Produktionsweise.
<G-vec00028-002-s117><decrease.absinken><en> Inelastic collisions would lead to a steady decrease of the particle speed and therefore a decrease of the gravitational force.
<G-vec00028-002-s117><decrease.absinken><de> Unelastische Kollisionen würden, selbst wenn keine normale Materie anwesend ist, zu einem ständigen Absinken der Geschwindigkeit führen und deswegen ebenfalls die Gravitationskraft schwächen.
<G-vec00028-002-s118><decrease.absinken><en> A parallel administration of coenzyme Q10 Burgerstein along with cholesterol-lowering agents (statins) prevents the decrease in the body's own Coenzyme Q10 memory.
<G-vec00028-002-s118><decrease.absinken><de> Eine parallele Einnahme von Burgerstein Coenzym Q10 zusammen mit Cholesterinsenkern (Statine) verhindert das Absinken der körpereigenen Coenzym Q10-Speicher.
<G-vec00028-002-s119><decrease.absinken><en> In conjunction with an up-to-date opinion of a linguistics expert [2] the corresponding DIN working group has also come to the conclusion that “towards the lower frequencies a linear characteristic or even a decrease of the reverberation is advantageous”.
<G-vec00028-002-s119><decrease.absinken><de> Zusammen mit der aktuellen Stellungnahme eines Sprachwissenschaftlers [2] kommt inzwischen auch der Norm-Ausschuss zu der Überzeugung, dass “zu tiefen Frequenzen ein linearer Verlauf oder sogar ein Absinken der Nachhallzeit von Vorteil“ sei.
<G-vec00028-002-s120><decrease.absinken><en> Even on the premise – to be discussed further below – that telematics vehicle monitoring can significantly decrease claims expenditure, at best the current price leaders would be able to generate an unbeatable competitive advantage.
<G-vec00028-002-s120><decrease.absinken><de> Selbst unter der noch zu diskutierenden Prämisse, dass telematische Fahrzeugüberwachung den Schadenbedarf signifikant absinken lässt, wäre ein unschlagbarer Wettbewerbsvorteil allenfalls für derzeitige Preisführer ableitbar.
<G-vec00028-002-s121><decrease.absinken><en> E-cadherin plays a primary role in the maintenance of epithelial integrity where its decrease or loss of expression is reported to be strictly associated with neoplastic progression in a variety of human carcinomas. Need Help?
<G-vec00028-002-s121><decrease.absinken><de> E-Cadherin spielt eine wichtige Rolle für die Erhaltung der epithelialen Integrität, und sein Absinken oder ein Wegfall der Expression scheint in einem engen Zusammenhang mit der neoplastischen Progression zahlreicher humaner Karzinome, einschließlich Blasenkarzinom, zu stehen.
<G-vec00028-002-s122><decrease.absinken><en> In respect of a Call Warrant, a small decrease in the value of the reference asset can lead to a proportionately greater decrease in the value of the Call Warrant.
<G-vec00028-002-s122><decrease.absinken><de> Im Hinblick auf einen Call-Optionsschein führt ein geringes Absinken des Werts des Referenzwerts zu einem entsprechend größeren Absinken des Wertes des Call-Optionsscheines.
<G-vec00028-002-s124><decrease.absinken><en> Thus in Germany, the statutory pension level has been forecast to decrease to 42% by 2045.
<G-vec00028-002-s124><decrease.absinken><de> So wird für Deutschland ein Absinken des gesetzlichen Rentenniveaus auf 42% im Jahr 2045 prognostiziert.
<G-vec00028-002-s188><decrease.fallen><en> A decrease or increase in the reference asset typically has a disproportionately great effect on the price of the Mini Futures.
<G-vec00028-002-s188><decrease.fallen><de> Ein Fallen oder Steigen des Referenzwerts hat in der Regel einen überproportional großen Effekt auf den Preis der Mini Futures.
<G-vec00028-002-s189><decrease.fallen><en> Risks The value of fund shares as well as the resulting income may increase or decrease in particular by changes in the capital markets.
<G-vec00028-002-s189><decrease.fallen><de> Risiken Der Wert von Fondsanteilen sowie die daraus entstehenden Erträge können insbesondere durch Veränderungen an den Kapitalmärkten fallen oder steigen.
<G-vec00028-002-s190><decrease.fallen><en> In Cantabria the prices are stable and in the remaining areas there is a decrease.
<G-vec00028-002-s190><decrease.fallen><de> In Cantabria stabilisieren sich die Preise, während anderswo die Preise fallen.
<G-vec00028-002-s191><decrease.fallen><en> Unnecessary clicks for adding questions and answer possibilities decrease.
<G-vec00028-002-s191><decrease.fallen><de> Unnötige Klicks für das Hinzufügen von Frage und Antwortmöglichkeiten fallen weg.
<G-vec00028-002-s192><decrease.fallen><en> Changes in one of these parameters will either cause the outlet temperature to increase or to decrease.
<G-vec00028-002-s192><decrease.fallen><de> Die Änderung eines dieser Parameter lässt die Ausgangstemperatur steigen oder fallen.
<G-vec00028-002-s193><decrease.fallen><en> Depending on the product concerned, premiums might increase or decrease for certain categories of consumers.
<G-vec00028-002-s193><decrease.fallen><de> Je nach Produktkategorie können die Beiträge für bestimmte Verbraucherkreise fallen oder steigen.
<G-vec00028-002-s194><decrease.fallen><en> As a result of currency fluctuations, returns can increase or decrease.
<G-vec00028-002-s194><decrease.fallen><de> Infolge von Währungsschwankungen können die Renditen steigen oder fallen.
<G-vec00028-002-s195><decrease.fallen><en> Marketing Could be reduced but revenues would as a consequence most likely decrease more than what would be saved with marketing.
<G-vec00028-002-s195><decrease.fallen><de> Marketing: Könnte reduziert werden, aber die Umsätze würden als Konsequenz sehr wahrscheinlich stärker fallen, als mit Marketing gespart würde.
<G-vec00028-002-s385><decrease.senken><en> Accompanied by a unique wide product range, we help you to increase productivity and quality and to decrease costs.
<G-vec00028-002-s385><decrease.senken><de> Begleitet von einem einzigartigen Produktspektrum helfen wir Ihnen die Produktivität und Qualität zu erhöhen und die Kosten zu senken.
<G-vec00028-002-s386><decrease.senken><en> Similarly to vitamin E, beta-carotene has been shown to decrease the risk of blood clotting.
<G-vec00028-002-s386><decrease.senken><de> Ähnlich wie Vitamin E ist Beta-Carotin in der Lage, das Risiko für Blutgerinnsel zu senken.
<G-vec00028-002-s387><decrease.senken><en> The Millennium Development Goals envisioned moreover, a decrease in child mortality, an improvement in mothers’ health care, safeguarding of ecological sustainability and formation of a global partnership for development.
<G-vec00028-002-s387><decrease.senken><de> Die Millenniums-Entwicklungsziele sahen außerdem vor, die Kindersterblichkeit zu senken, die Gesundheitsversorgung der Mütter zu verbessern, ökologische Nachhaltigkeit sicherzustellen und eine globale Partnerschaft für Entwicklung aufzubauen.
<G-vec00028-002-s388><decrease.senken><en> Benefits of such a situation: Increase tax revenues, decrease tax costs, either more money for the government or lower tax rates for everybody.
<G-vec00028-002-s388><decrease.senken><de> Vorteile einer solchen Situation: Erhöhen Sie Steuereinnahmen, senken Sie die Steuerkosten, entweder mehr Geld für die Regierung oder niedrigere Steuersätze für alle.
<G-vec00028-002-s389><decrease.senken><en> High amounts (3x250 mg/day) will decrease blood pressure without negative side-effects.
<G-vec00028-002-s389><decrease.senken><de> Hohe Mengen (3x250 mg/Tag) senken den Blutdruck ohne negative Nebenwirkungen.
<G-vec00028-002-s390><decrease.senken><en> International exchange of experiences within the Gardner Denver group and system-neutral consultation enable us to provide the beverage industry and filling technology with new stimulus and decrease resource consumption in a lasting way.
<G-vec00028-002-s390><decrease.senken><de> Der internationale Erfahrungsaustausch im Gardner Denver-Verbund und die systemneutrale Beratung machen es möglich, der Getränkeindustrie und der Abfülltechnik neue Impulse zu geben und den Ressourcenverbrauch nachhaltig zu senken.
<G-vec00028-002-s391><decrease.senken><en> Since 2011, efforts by the G20 to significantly decrease the costs of remittances caused a decrease of mid-tier transaction costs to 8 percent.
<G-vec00028-002-s391><decrease.senken><de> Bemühungen der G20 seit 2011, die Kosten für Rücküberweisungen entscheidend zu senken, bewirkten immerhin einen Rückgang der mittleren Transaktionskosten auf 8 Prozent.
<G-vec00028-002-s392><decrease.senken><en> Open Value Subscription: Get the benefits of Open Value with lower up-front costs and the ability to increase or decrease license count on an annual basis to accommodate changes in desktop PC count.
<G-vec00028-002-s392><decrease.senken><de> Open Value Subscription Erhalten Sie die Mehrwerte von Open Value mit niedrigeren Einstiegskosten und der Möglichkeit, die Lizenzanzahl am Jahrestag des Vertrages zu erhöhen oder zu senken.
<G-vec00028-002-s393><decrease.senken><en> Decrease costs, improve profits, grow your business, and keep your guests coming back for top
<G-vec00028-002-s393><decrease.senken><de> Senken Sie Kosten, erhöhen Sie Ihren Gewinn, fördern Sie das Wachstum Ihres Unternehmens und stärken Sie die Kundenbindung.
<G-vec00028-002-s394><decrease.senken><en> The results are remarkable: the participants are able to decrease their energy and resource costs and, at the same time, to reduce their environmental impact.
<G-vec00028-002-s394><decrease.senken><de> Die Ergebnisse sind beachtlich: Die Teilnehmer senken ihre Energie- und Ressourcenkosten und entlasten gleichzeitig die Umwelt.
<G-vec00028-002-s395><decrease.senken><en> In the long term, the biomass action plan will also help to decrease CO2 emissions and better exploit the economic potential of biomass in Germany.
<G-vec00028-002-s395><decrease.senken><de> Langfristig soll der Biomasse-Aktionsplan die CO2-Emissionen weiter senken helfen und das wirtschaftliche Potenzial der Biomasse in Deutschland stärker nutzen.
<G-vec00028-002-s396><decrease.senken><en> Once you discontinue taking MAOIs, it's important not to stop abruptly, but rather to slowly decrease your dosage.
<G-vec00028-002-s396><decrease.senken><de> Unterbrichst Du die Einnahme von MAOH, ist es wichtig, sie nicht abrupt abzusetzen, sondern die Dosis langsam zu senken.
<G-vec00028-002-s397><decrease.senken><en> Some herbs and spices, in particular, can actually help you decrease your blood pressure.
<G-vec00028-002-s397><decrease.senken><de> Manche Kräuter und Gewürze können sogar helfen, deinen Blutdruck zu senken.
<G-vec00028-002-s398><decrease.senken><en> Clonidine Clonidine Clonidine is an alpha-agonist hypotensive agent to decrease blood pressure employed alone or in combination...
<G-vec00028-002-s398><decrease.senken><de> Clonidine Clonidine Clonidine ist ein blutdrucksenkender Alpha-Agonist, der dafür angewendet wird, um Blutdruck zu senken...
<G-vec00028-002-s399><decrease.senken><en> Higher fat percentages decrease hormone levels and your body becomes less able to deal with nutrients, which increases the chance that you store fat.
<G-vec00028-002-s399><decrease.senken><de> Höhere Fettanteile senken den Hormonspiegel und Ihr Körper wird weniger in der Lage, mit Nährstoffen umzugehen, was die Wahrscheinlichkeit erhöht, dass Sie Fett speichern.
<G-vec00028-002-s400><decrease.senken><en> It is designed to decrease construction cost and create ease of maintenance.
<G-vec00028-002-s400><decrease.senken><de> Es wurde entwickelt, um die Baukosten zu senken und Wartungsfreundlichkeit zu schaffen.
<G-vec00028-002-s401><decrease.senken><en> Avoid milk and dairy products for at least an hour after taking iron because the calcium in dairy products may decrease iron absorption.
<G-vec00028-002-s401><decrease.senken><de> Meide mindestens eine Stunde, nachdem du Eisen eingenommen hast, Milch und Milchprodukte, weil das Kalzium in Molkereiprodukten die Eisenaufnahme senken könnte.
<G-vec00028-002-s402><decrease.senken><en> The objective of this report is to show how Spain can decrease their transport emissions from a broad range of European and national measures.
<G-vec00028-002-s402><decrease.senken><de> Ziel dieser Studie ist es, zu zeigen, wie Spanien seine Verkehrsemissionen durch ein breites Spektrum europäischer und nationaler Maßnahmen senken kann.
<G-vec00028-002-s403><decrease.senken><en> However, this additive is controversial because it might further decrease the lifetime of the solar cells.
<G-vec00028-002-s403><decrease.senken><de> Doch dieser Zusatz ist umstritten, weil er die Lebensdauer der Solarzellen weiter senken kann.
<G-vec00028-002-s404><decrease.senken><en> It also helps to decrease false alarms.
<G-vec00028-002-s404><decrease.senken><de> Außerdem senkt sie die Fehlalarmquote.
<G-vec00028-002-s405><decrease.senken><en> It will involve a simplified selection, monitoring and evaluation procedure, which will decrease the workload on both the NGOs and the Commission.
<G-vec00028-002-s405><decrease.senken><de> Sie umfasst ein vereinfachtes Auswahl-, Überwachungs- und Bewertungsverfahren, das den Arbeitsaufwand sowohl seitens der NRO als auch der Kommission senkt.
<G-vec00028-002-s406><decrease.senken><en> Filtering may decrease your FPS unless you have a good graphics card.
<G-vec00028-002-s406><decrease.senken><de> Dies senkt normalerweise die Geschwindigkeit drastisch, es sei denn du hast eine sehr schnelle Grafikkarte.
<G-vec00028-002-s407><decrease.senken><en> It is a very useful mechanical property that the generator will increase or decrease its speed slightly if the torque varies.
<G-vec00028-002-s407><decrease.senken><de> Es ist eine recht nützliche mechanische Eigenschaft, daß der Generator seine Drehzahl leicht erhöht oder senkt, wenn sich das Drehmoment ändert.
<G-vec00028-002-s408><decrease.senken><en> The additional elements have been designed to decrease combustion air noise by 6 dB and any associated pump noise by 10 dB.
<G-vec00028-002-s408><decrease.senken><de> Das Design der zusätzlichen Elemente senkt den Luftschall um 6 dB und zugehörige Pumpengeräusche um 10 dB.
<G-vec00028-002-s409><decrease.senken><en> Lighting CO2. To reach its sustainability goals, the Buenos Aires government called for a new public lighting system to significantly decrease energy consumption and ensure the well-being and safety of citizens.
<G-vec00028-002-s409><decrease.senken><de> Um seine Nachhaltigkeitsziele zu erreichen, hat die Regierung von Buenos Aires ein neues öffentlichen Beleuchtungssystem gefordert, das den Energieverbrauch drastisch senkt und das Wohlergehen und die Sicherheit der Bewohner sicherstellt.
<G-vec00028-002-s410><decrease.senken><en> These concepts increase plant uptime and decrease maintenance costs.
<G-vec00028-002-s410><decrease.senken><de> Das Konzept erhöht die Nutzungszeiten der Anlagen und senkt die Wartungskosten.
<G-vec00028-002-s411><decrease.senken><en> This helps to save fuel and decrease CO2 emissions day in day, out.
<G-vec00028-002-s411><decrease.senken><de> Das spart Kraftstoff und senkt die CO2-Emissionen.
<G-vec00028-002-s213><decrease.sinken><en> This means that the inflation rate as measured by the consumer price index was slightly up, following a decrease to 1.5% in May 2017 (April 2017: +2.0%).
<G-vec00028-002-s213><decrease.sinken><de> Damit zog die Inflationsrate − gemessen am Verbraucherpreisindex – wieder leicht an, nachdem sie im Mai 2017 auf 1,5 % gesunken war (April 2017: + 2,0 %).
<G-vec00028-002-s214><decrease.sinken><en> This latest figure marked a slight decrease in the dependency rate, which had peaked at 54.5 % in 2008.
<G-vec00028-002-s214><decrease.sinken><de> Damit ist die Abhängigkeitsquote gegenüber ihrem Höchststand von 54,5 % im Jahr 2008 aber auch wieder leicht gesunken.
<G-vec00028-002-s215><decrease.sinken><en> 389 Lastly, as regards the exact scale of those price changes, the applicants claim that Chiquita’s statement that it was common knowledge that prices vary by a range of EUR 0.50, with the result that Mr C1’s indication could be understood as meaning that the prices would increase or decrease by EUR 0.50 or stay at the same level is not grounded in reality since an analysis of the actual weekly price movements show that the prices did not increase or decrease only by EUR 0.50 and that there was certainly no trend in prices moving in bands of EUR 0.50.
<G-vec00028-002-s215><decrease.sinken><de> 389 Was schließlich die genaue Größenordnung dieser Preisschwankungen angeht, führen die Klägerinnen aus, dass die Erklärung von Chiquita, dass auf dem Bananenmarkt öffentlich bekannt sei, dass die Preise in Sprüngen von 0,5 Euro schwankten, so dass die Angaben von C1 dahin hätten verstanden werden können, dass sie bedeuteten, die Preise würden um 0,5 Euro sinken oder steigen oder auf gleicher Höhe bleiben, nicht auf den Tatsachen beruhten, da eine Untersuchung der tatsächlichen wöchentlichen Preisbewegungen ergebe, dass die Preise nicht nur um 0,5 Euro gestiegen oder gesunken seien und dass bestimmt keine Tendenz der Preisentwicklung in Sprüngen von je 0,5 Euro bestanden habe.
<G-vec00028-002-s216><decrease.sinken><en> Where your fat percentage may decrease by 2% in the first month, it will probably take longer for you to go down another 2% of fat percentage.
<G-vec00028-002-s216><decrease.sinken><de> Wenn dein Körperfettanteil im ersten Monat um 2% gesunken ist, kann es in der Folgezeit länger dauern, bevor dein Körperfettanteil um mehr als 2% weiter sinkt.
<G-vec00028-002-s217><decrease.sinken><en> And the good news is that the ‘good‘ HDL cholesterol did not decrease.
<G-vec00028-002-s217><decrease.sinken><de> Eine weitere gute Nachricht ist, dass das ‚gute’ HDL-Cholesterin nicht gesunken ist.
<G-vec00028-002-s218><decrease.sinken><en> This is one cause of the percentage decrease to 93% in 2015.
<G-vec00028-002-s218><decrease.sinken><de> Das ist der eine Grund dafür, dass der Anteil im Jahr 2015 auf 93 % gesunken ist.
<G-vec00028-002-s219><decrease.sinken><en> This is the cause of the decrease to 90% (electricity) and 93% (heating) in 2015.
<G-vec00028-002-s219><decrease.sinken><de> Das ist der Grund dafür, dass der Anteil im Jahr 2015 auf 90 % (Strom) gesunken ist.
<G-vec00028-002-s220><decrease.sinken><en> Spain is in breach of the EU Water Framework Directive, given the dramatic decrease in the levels of temporary ground and surface water in Doñana, and the poor state of the water due to nitrate pollution from intensive agriculture for the production of strawberries and red fruits.
<G-vec00028-002-s220><decrease.sinken><de> Spanien verstößt gegen die EU-Wasserrahmenrichtlinie, da der Wasserspiegel in Doñana drastisch gesunken ist und die intensive Landwirtschaft für die Produktion von Erdbeeren zu einer hohen Nitratbelastung des Wassers führt.
<G-vec00028-002-s431><decrease.sinken><en> The value of all investments and the income from them can decrease as well as increase and investors may not receive back the full amount invested.
<G-vec00028-002-s431><decrease.sinken><de> Der Wert aller Anlagen und die Erträge daraus können sowohl sinken als auch steigen und die Anleger erhalten möglicherweise nicht den gesamten investierten Betrag zurück.
<G-vec00028-002-s432><decrease.sinken><en> The similarity index percentage may decrease if a repository option is deselected.
<G-vec00028-002-s432><decrease.sinken><de> Wenn eine Ablageoption deaktiviert wird, kann der Prozentsatz für den Ähnlichkeitsindex u. U. sinken.
<G-vec00028-002-s433><decrease.sinken><en> At excess nitric food winter hardiness of plants can decrease.
<G-vec00028-002-s433><decrease.sinken><de> Bei einer überschüssigen Stickstoffernährung kann die Winterfestigkeit der Pflanzen sinken.
<G-vec00028-002-s434><decrease.sinken><en> The number of obese people would decrease by an eighth from approximately 16 million to 14 million cases.
<G-vec00028-002-s434><decrease.sinken><de> Die Zahl der Adipösen würde um ein Achtel von rund 16 Millionen auf 14 Millionen Betroffene sinken.
<G-vec00028-002-s435><decrease.sinken><en> With the best will in the world -- though in his own luminous way -- Herr Dühring can only repeat his predecessors' errors concerning Hume's actual theory of money, according to which money is a mere token of value, and therefore, other things being equal, commodity prices rise in proportion to the increase in the volume of money in circulation and fall in proportion to its decrease.
<G-vec00028-002-s435><decrease.sinken><de> Was die wirkliche Geldtheorie Humes angeht, wonach das Geld bloß Wertzeichen ist, und deshalb, unter sonst gleichbleibenden Umständen, die Warenpreise sinken im Verhältnis, wie die zirkulierende Geldmenge wächst, und steigen im Verhältnis, wie sie fällt, so kann Herr Dühring beim besten Willen - ob auch in der ihm eignen lichtvollen Weise - nur seinen irrtümlichen Vorgängern nachreden.
<G-vec00028-002-s436><decrease.sinken><en> But this ignores the facts that a lack of chromium is widespread in the western world, and that chromium levels can decrease as a result of severe physical exertion and the natural aging process.
<G-vec00028-002-s436><decrease.sinken><de> Hierbei wird jedoch außer acht gelassen, dass ein Mangel an Chrom in der westlichen Welt weit verbreitet ist und dass die Chromspiegel durch starke körperliche Anstrengungen beim Sport und im Alter sinken.
<G-vec00028-002-s437><decrease.sinken><en> Furthermore, the rest rate will decrease.
<G-vec00028-002-s437><decrease.sinken><de> Weiter wird die Ruhefrequenz sinken.
<G-vec00028-002-s438><decrease.sinken><en> In terms of state (and hence taxpayers), then decrease the cost of reducing CO2 emissions and develop renewable energy.
<G-vec00028-002-s438><decrease.sinken><de> Aus Sicht des Landes (und damit der Steuerzahler) sinken dann die Kosten für die Senkung der CO2-Emissionen und der Entwicklung erneuerbarer Energien.
<G-vec00028-002-s439><decrease.sinken><en> The logical consequence: acceptance and response rates increase while postage and advertising material costs simultaneously decrease, and all the addresses you have are correct.
<G-vec00028-002-s439><decrease.sinken><de> Die logische Folge: Akzeptanz und Responsequoten steigen, gleichzeitig sinken die Kosten für Porto und Werbemittel und Sie haben nur noch richtige Anschriften.
<G-vec00028-002-s440><decrease.sinken><en> For the sector to reach its full potential, however, the key is verification, standardization and anonymization of customer data – this is the only way to make them useful for advertisers.“ Once the worries of users about data protection issues decrease, ranges and subsequently campaign performance will increase.
<G-vec00028-002-s440><decrease.sinken><de> Damit der Sektor allerdings sein Potenzial voll erfüllen kann, liegt der Schlüssel in der Verifizierung, Standardisierung und Anonymisierung der Kundendaten – nur so werden sie für den Werbenden nutzbar gemacht.“ Sofern also die Bedenken der Nutzer gegenüber Datenschutzfragen sinken, werden auch die Reichweiten und somit die Kampagnenvolumina steigen.
<G-vec00028-002-s441><decrease.sinken><en> Therefore, it is expected that international shipping costs decrease, that the creation of a unified cashless payment area is widespread (SEPA), and that transparency, efficiency and quality of cross-border parcel services are properly installed in the years to come.
<G-vec00028-002-s441><decrease.sinken><de> Daher wird erwartet, dass die internationalen Versandkosten sinken, dass die Schaffung einer einheitlichen, bargeldlosen Flächenzahlung weitverbreitet sein wird (SEPA) und dass Transparenz, Effizienz und Qualität von grenzüberschreitenden Lieferdiensten in den kommenden Jahren Realität werden.
<G-vec00028-002-s442><decrease.sinken><en> In contrast, the demobilization scenario anticipates that first-time voter participation will decrease by roughly a third if the voting age is not lowered to 16.
<G-vec00028-002-s442><decrease.sinken><de> Das Demobilisierungsszenario hingegen geht davon aus, dass die Erstwählerbeteiligung ohne Wählen ab 16 um etwa ein Drittel sinken würde.
<G-vec00028-002-s443><decrease.sinken><en> For example, if the DAX 30 was to rise in value by 5% on a particular day, the product would decrease in value by 15% on that day (before fees, expenses and adjustments).
<G-vec00028-002-s443><decrease.sinken><de> Wenn der DAX 30® beispielsweise an einem Tag um 5% zulegt, würde der Wert des Produkts an diesem Tag um 15% sinken (vor Gebühren, Aufwendungen und Anpassungen).
<G-vec00028-002-s444><decrease.sinken><en> Additional fees may apply when upgrading to a version significantly enhanced with features previously not existing in your license, and vice-versa, fees may decrease if IceWarp decides to discontinue or replace previously paid features.
<G-vec00028-002-s444><decrease.sinken><de> Es können zusätzliche Gebühren anfallen, wenn Sie auf eine Version upgraden, die erheblich durch Funktionen verbessert wurde, die zuvor nicht in Ihrer Lizenz enthalten waren, und umgekehrt können die Gebühren sinken, wenn IceWarp beschließt, zuvor bezahlte Funktionen einzustellen oder zu ersetzen.
<G-vec00028-002-s445><decrease.sinken><en> The Keyword Rankingtracker records changes when keywords increase, decrease, or remain constant in the rankings.
<G-vec00028-002-s445><decrease.sinken><de> Der Keyword-Rankingtracker im ShopDoc Amazon Tool zeichnet Veränderungen auf, wenn Keywörter im Ranking steigen, sinken oder konstant bleiben.
<G-vec00028-002-s446><decrease.sinken><en> One can assume that these circumcision rates will further decrease in the coming years.
<G-vec00028-002-s446><decrease.sinken><de> Es ist davon auszugehen, dass die Beschneidungsraten in den nächsten Jahren weiter sinken werden.
<G-vec00028-002-s447><decrease.sinken><en> Especially in the new countries the labor supply will decrease and age dramatically.
<G-vec00028-002-s447><decrease.sinken><de> Insbesondere in den neuen Ländern wird das Arbeitskräfteangebot dramatisch sinken und altern.
<G-vec00028-002-s448><decrease.sinken><en> In the course of this, the costs for the development and production of these documents goes up while, at the same time, there is a decrease in efficiency and flexibility due to the longer processing times.
<G-vec00028-002-s448><decrease.sinken><de> Dabei steigen die Kosten für die Entwicklung und Erstellung dieser Dokumente, gleichzeitig sinken Effizienz und Flexibilität durch längere Durchlaufzeiten.
<G-vec00028-002-s449><decrease.sinken><en> In the 1980’s sales of Krugerrands began to decrease.
<G-vec00028-002-s449><decrease.sinken><de> In den 1980er Jahren begann der Verkauf von Krügerrands zu sinken.
<G-vec00028-002-s450><decrease.sinken><en> For example, if the DAX 30 was to rise in value by 5% on a particular day, the product would decrease in value by 15% on that day (before fees, expenses and adjustments).
<G-vec00028-002-s450><decrease.sinken><de> Steigt der Index beispielsweise an einem Tag um 5 %, so sinkt der Wert des Produkts an diesem Tag um 5 % (vor Gebühren und Ausgaben).
<G-vec00028-002-s451><decrease.sinken><en> The depreciation period is the period during which the value of the asset will decrease.
<G-vec00028-002-s451><decrease.sinken><de> Der Abschreibungszeitraum ist der Zeitraum, in dem der Wert eines Vermögensgegenstandes sinkt.
<G-vec00028-002-s452><decrease.sinken><en> If no egg is fertilized, the ovaries gradually decrease production of progesterone and estrogen.
<G-vec00028-002-s452><decrease.sinken><de> Wurde die Eizelle nicht befruchtet, sinkt die Konzentration von Progesteron und Östrogen im Blut.
<G-vec00028-002-s453><decrease.sinken><en> The number of fatalities will decrease by 12.1 %. The number of severe injuries decreases by 11.7 %.
<G-vec00028-002-s453><decrease.sinken><de> Die Zahl der Unfallgetöteten sinkt um 12,1 %, die Zahl der Schwerverletzten kann um 11,7 % gesenkt werden.
<G-vec00028-002-s454><decrease.sinken><en> Therefore, the quality of our Spanish courses do not decrease depending on the number of Spanish students.
<G-vec00028-002-s454><decrease.sinken><de> Daher sinkt die Kursequalität nicht je nach der Studentenszahl.
<G-vec00028-002-s455><decrease.sinken><en> As a Group policy, held-to-maturity and available-for-sale debt securities and loans and receivables are assessed for impairment when a significant decrease in market value related to credit risk arises, namely after a downgrade of a debtor’s rating below single B– after initial recognition (i.e. CCC or lower according to Standard and Poor’s or equivalent) or when payments of principal and/or interest are overdue by more than 90 days. Impairment of available-for-sale equity instruments
<G-vec00028-002-s455><decrease.sinken><de> Gruppenweit gilt, dass bis zum Verfall gehaltene und jederzeit verkäufliche Zinspapiere sowie Darlehen und Forderungen grundsätzlich auf Wertminderungen überprüft werden, wenn der Marktwert aufgrund von Ausfallrisiken deutlich sinkt, insbesondere nachdem das Rating eines Schuldners nach der Ersterfassung unter B– herabgestuft wurde (also CCC oder tiefer nach Standard & Poor’s oder gleichwertigem Rating), oder wenn die Zahlung des Nominalbetrags und/oder der Zinsen seit mehr als 90 Tagen überfällig ist.
<G-vec00028-002-s456><decrease.sinken><en> Between 30 and 40 years the physical and mental vitality starts to decrease.
<G-vec00028-002-s456><decrease.sinken><de> Man sagt, dass zwischen 30 und 40 Jahren die körperliche und geistige Vitalität spürbar sinkt.
<G-vec00028-002-s457><decrease.sinken><en> When you set the CPU limit of a single processor virtual machine, the overall ESXi utilization might decrease due to a defect in the ESXi scheduler.
<G-vec00028-002-s457><decrease.sinken><de> Wenn Sie den CPU-Grenzwert einer virtuellen Maschine mit Einzelprozessor festlegen, sinkt die Gesamtnutzung von ESXi möglicherweise aufgrund eines Defekts des ESXi-Schedulers.
<G-vec00028-002-s458><decrease.sinken><en> Taken as a whole, state indebtedness whose base amount does not decrease, or does not appreciably decrease, when the economic situation is good, and again and again increases markedly when the economic situation is bad, insidiously endangers the practical possibility of observing important principles of state structure.
<G-vec00028-002-s458><decrease.sinken><de> Insgesamt gefährdet eine Staatsverschuldung, die im Sockel bei guter Konjunktur nicht oder nicht nennenswert sinkt und bei schlechter konjunktureller Lage immer wieder deutlich steigt, schleichend die praktische Möglichkeit zur Beachtung wichtiger Staatsstrukturprinzipien.
<G-vec00028-002-s460><decrease.sinken><en> Your blood pressure will also decrease as a result of new blood vessels forming.
<G-vec00028-002-s460><decrease.sinken><de> Auch Ihr Blutdruck sinkt durch die Bildung neuer Blutgefäße.
<G-vec00028-002-s461><decrease.sinken><en> By letting your employees work from home or even have a work from home day a week, you will decrease the chance of people taking day off because of ‘sickness’.
<G-vec00028-002-s461><decrease.sinken><de> Erlaubt man ihnen von zu Hause aus zu arbeiten oder integriert man sogar einen festen Home-Office-Tag in die Arbeitswoche, sinkt die Wahrscheinlichkeit, dass sie eine Krankheit vortäuschen.
<G-vec00028-002-s462><decrease.sinken><en> The demand for whale meat continues to decrease, while the number of animals killed continues to rise.
<G-vec00028-002-s462><decrease.sinken><de> Die Anfrage für Walfleisch sinkt mit jedem Jahr, doch die Anzahl der getöteten Tiere steigt.
<G-vec00028-002-s463><decrease.sinken><en> The doors of physicians close and the influence of the HCPs on regulations decrease.
<G-vec00028-002-s463><decrease.sinken><de> Die Türen zum Arzt gehen zu, so wie auch der Verordnungseinfluss der HCPs sinkt.
<G-vec00028-002-s464><decrease.sinken><en> If an item is in low demand with high supply, the guide price will decrease.
<G-vec00028-002-s464><decrease.sinken><de> Wenn die Nachfrage für einen Gegenstand niedrig ist, das Angebot jedoch hoch, sinkt der Richtpreis.
<G-vec00028-002-s465><decrease.sinken><en> After menopause, estrogen levels decrease, weakening many tissues, including bone, muscles (such as those of the bladder), and tissues around the vagina and urethra.
<G-vec00028-002-s465><decrease.sinken><de> Nach der Menopause sinkt der Östrogenspiegel, wodurch viele Gewebearten geschwächt werden, einschließlich der Knochen, Muskeln (wie die der Blase), und das Gewebe um die Scheide und den Harnleiter herum.
<G-vec00028-002-s466><decrease.sinken><en> Sales decrease 5.5% organically to CHF 1'915 million
<G-vec00028-002-s466><decrease.sinken><de> Umsatz sinkt organisch um 5,5% auf CHF 1'915 Mio.
<G-vec00028-002-s467><decrease.sinken><en> Cold Temperatures will cause a Status Effect that increases the rate at which a player's Food stat will decrease.
<G-vec00028-002-s467><decrease.sinken><de> Niedrige Temperaturen verursachen einen Statuseffekt, der die Rate erhöht mit der der Nahrungs-Status eines Spielers sinkt.
<G-vec00028-002-s468><decrease.sinken><en> On Saturday, the avalanche danger levels will decrease somewhat.
<G-vec00028-002-s468><decrease.sinken><de> Am Samstag sinkt die Lawinengefahr leicht.
<G-vec00028-002-s543><decrease.vermindern><en> The incredible levels of antioxidants in Acai help you feel younger, and may also decrease medical problems.
<G-vec00028-002-s543><decrease.vermindern><de> Die unglaublichen Mengen Antioxidantien in Acai helfen Ihnen, sich jünger zu fühlen und können auch gesundheitliche Probleme vermindern.
<G-vec00028-002-s544><decrease.vermindern><en> Points The points that you get decrease the longer you take and are raised by bonus points for good execution.
<G-vec00028-002-s544><decrease.vermindern><de> Punkte Die Punkte, die man erhält, vermindern sich je länger man braucht und erhöhen sich durch Bonuspunkte bei guter Ausführung.
<G-vec00028-002-s545><decrease.vermindern><en> When they accumulate themselves, all these technical problems considerably decrease the output or the efficiency of the machine that become very lower to those of Carnot.
<G-vec00028-002-s545><decrease.vermindern><de> Wenn sie sich ansammeln, vermindern all diese technischen Probleme die Ausgabe oder die Effizienz der Maschine, genau weit weg vom Optimalen von Carnot.
<G-vec00028-002-s546><decrease.vermindern><en> As a strategy and control measure the society can accept, decrease, transfer or avoid risks. Monitoring of risks
<G-vec00028-002-s546><decrease.vermindern><de> Als Risikostrategie und Steuerungsmaßnahme kann das Unternehmen grundsätzlich die Risiken akzeptieren, vermindern, übertragen und vermeiden.
<G-vec00028-002-s547><decrease.vermindern><en> Positive thoughts and attitudes are able to prompt changes in your body that strengthen your immune system, boost positive emotions, decrease pain and chronic disease, and provide stress relief.
<G-vec00028-002-s547><decrease.vermindern><de> Positive Gedanken und Einstellungen haben die Fähigkeit, Veränderungen in Ihrem Körper hervorzurufen, die das Immunsystem stärken, positive Emotionen fördern, Schmerzen und chronische Krankheiten vermindern und Stress abbauen.
<G-vec00028-002-s548><decrease.vermindern><en> You can remove or decrease the size of wagers by right-clicking on them.
<G-vec00028-002-s548><decrease.vermindern><de> Sie können entfernen oder die Größe von Wetten durch das Recht-Klicken auf ihnen vermindern.
<G-vec00028-002-s549><decrease.vermindern><en> Relaxation and breath give stability, decrease stress and bring us in touch with our inner strength.
<G-vec00028-002-s549><decrease.vermindern><de> Entspannung und Atmung geben Stabilität, vermindern Stress und bringen uns in Kontakt mit innerer Stärke.
<G-vec00028-002-s550><decrease.vermindern><en> Pulmonary compliance may decrease, progressing to acute respiratory distress syndrome (ARDS) and respiratory muscle failure.
<G-vec00028-002-s550><decrease.vermindern><de> Die Lungen-Compliance kann sich vermindern und zu einem akuten Atemnotsyndrom (ARDS) und zu einer muskulären Ateminsuffizienz entwickeln.
<G-vec00028-002-s551><decrease.vermindern><en> The information on previous performance is no indication of the future performance of investments, i.e. their value may increase or decrease.
<G-vec00028-002-s551><decrease.vermindern><de> Die zukünftige Entwicklung von Anlagevermögen lässt sich nicht aus der aufgezeigten Kursentwicklung ableiten, d. h. der Anlagewert kann sich vergrößern oder vermindern.
<G-vec00028-002-s552><decrease.vermindern><en> Companies just starting out with international business can easily overlook critical approaches, but a strong partnership can dramatically decrease that margin for error.
<G-vec00028-002-s552><decrease.vermindern><de> Firmen, die gerade die ersten Schritte ins international Geschäft machen, können kritische Ansätze leicht übersehen, aber eine starke Partnerschaft kann das Fehlerrisiko drastisch vermindern.
<G-vec00028-002-s553><decrease.vermindern><en> The municipalities should be able to increase their offers of building land in condensed construction and should therefore decrease their costs for infrastructure in a sustainable way.
<G-vec00028-002-s553><decrease.vermindern><de> Die Gemeinden sollen das Angebot von Wohnbauland in verdichteter Bebauung vermehren können und damit auch die Kosten ihrer Infrastruktur nachhaltig vermindern.
<G-vec00028-002-s554><decrease.vermindern><en> Debits increase asset or expense accounts and decrease liability or equity.
<G-vec00028-002-s554><decrease.vermindern><de> Soll-Posten erhöhen Aktiv- oder Aufwandskonten und vermindern Verbindlichkeiten und Eigenkapital.
<G-vec00028-002-s555><decrease.vermindern><en> Last but not least, the reduction of the payroll and other overheads as well as, in many countries, the use of cheaper regional airports also made possible the decrease of the fares of those flights.
<G-vec00028-002-s555><decrease.vermindern><de> Und zu guter Letzt machten die Verringerung der Lohn- und Gemeinkosten sowie, in vielen Ländern, die Verwendung von billigen regionalen Flughäfen es auch möglich, die Flugpreise zu vermindern.
<G-vec00028-002-s556><decrease.vermindern><en> In the context of a research project modular system solutions and sample statistics have been developed, which do not only decrease the system costs but also the planning costs.
<G-vec00028-002-s556><decrease.vermindern><de> Im Rahmen eines Forschungsprojektes wurden modulare Systemlösungen und Musterstatistiken entwickelt, die nicht nur die Systemkosten, sondern auch die Planungskosten vermindern lassen.
<G-vec00028-002-s557><decrease.vermindern><en> If any base station sends a power control indicator commanding the mobile station to decrease power, the mobile station will decrease power.
<G-vec00028-002-s557><decrease.vermindern><de> Wenn irgendeine Basisstation einen Leistungssteuerindikator sendet, der die mobile Station anweist, ihre Leistung zu vermindern, so wird die mobile Station ihre Leistung vermindern.
<G-vec00028-002-s559><decrease.vermindern><en> Dehumidifiers decrease this risk by lowering humidity levels of the air and stop mould infestation.
<G-vec00028-002-s559><decrease.vermindern><de> Luftentfeuchter vermindern dieses Risiko, denn sie senken die Luftfeuchtigkeit und unterbinden den Schimmelbefall.
<G-vec00028-002-s560><decrease.vermindern><en> Differences of temperature in the atmosphere bring about a difference of atmospheric pressure in different places, create air currents from warmer to colder regions, increase or decrease humidity, bring forth cloud formations and precipitation.
<G-vec00028-002-s560><decrease.vermindern><de> Die Temperaturunterschiede in der Atmosphäre bewirken eine Verschiedenheit des Luftdrucks an verschiedenen Orten, erzeugen Luftströmungen von wärmeren nach kälteren Gebieten, vermehren oder vermindern den Feuchtigkeitsgehalt, bringen Wolkenbildungen und Niederschläge hervor.
<G-vec00028-002-s561><decrease.vermindern><en> Concurrently with the achievement of a high image quality at the initial stage, the use of the above two-component type developer makes the toner have less change in charge quantity inside the developing assembly, and can well bring out the effect of the present invention that no decrease in image density may occur even when copied on a large number of sheets.
<G-vec00028-002-s561><decrease.vermindern><de> Die Anwendung des Zweikomponentenentwicklers gemäß der vorliegenden Erfindung ist zusätzlich zu der hohen Bildqualität in einem Anfangsstadium der Bilderzeugung wirksam, um die Scherkraft, die auf den Entwickler ausgeübt wird, zu vermindern und auch bei einer kontinuierlichen Erzeugung von Bildern auf einer großen Zahl von Blättern eine Vermindeung der Bildqualität zu vermeiden.
<G-vec00028-002-s562><decrease.vermindern><en> Thus, the bogie coupling system helps to reduce wear on both wheels and tracks, and also to decrease noise emissions.
<G-vec00028-002-s562><decrease.vermindern><de> Die Radsatzsteuerung reduziert den Verschleiß an Rädern sowie den Gleisen und vermindert die Geräuschemission.
<G-vec00028-002-s563><decrease.vermindern><en> Some abilities have effects which deal damage to units directly, while some abilities, items, and buffs have effects which increase or decrease the amount of damage a unit inflicts.
<G-vec00028-002-s563><decrease.vermindern><de> Manche Fähigkeiten haben Effekte, die Einheiten direkt Schaden zufügen, während manche Fähigkeiten, Gegenstände und Verbesserungen Effekte haben, die die Schadensmenge, die eine Einheit zufügt, erhöht oder vermindert.
<G-vec00028-002-s564><decrease.vermindern><en> This is most evident in car headlights; glare from headlights is a recognized cause of roadway accidents and LEDs do nothing to decrease this danger.
<G-vec00028-002-s564><decrease.vermindern><de> Am deutlichsten wird das bei Autoscheinwerfern1 - Blendung im Autoverkehr gehört zu den anerkannten Unfallursachen und wird durch LEDs sicher nicht vermindert.
<G-vec00028-002-s565><decrease.vermindern><en> It will not decrease by any conscious decisions of mortals, but will be a factor, not of earthquakes, not of floods, not of tsunamis, not of rain or hail or avalanches, or any of these mechanical means, though those will certainly and surely startle you.
<G-vec00028-002-s565><decrease.vermindern><de> Die Bevölkerung wird nicht vermindert durch irgendwelche bewußten Entscheidungen von Sterblichen und auch nicht durch Erdbeben, Fluten oder Tsunamis, auch nicht durch Regen, Hagel oder Lawinen oder durch diese mechanischen Mitteln, obwohl dies alles Euch sicher und gewiß erschrecken wird.
<G-vec00028-002-s566><decrease.vermindern><en> Light diffusion (how light is spread) can significantly decrease dazzle and glare from the different surfaces and objects in a room.
<G-vec00028-002-s566><decrease.vermindern><de> Durch die Lichtdiffusion (Streuung des Lichts) können Glanz- und Blendeffekte von den unterschiedlichen Oberflächen und Gegenständen in einem Raum deutlich vermindert werden.
<G-vec00028-002-s567><decrease.vermindern><en> By contrast, there was a decrease in materials and supplies of 5.1 per cent.
<G-vec00028-002-s567><decrease.vermindern><de> Gegenläufig hat sich der Bestand an Roh-, Hilfs- und Betriebsstoffen um 5,1 Prozent vermindert.
<G-vec00028-002-s568><decrease.vermindern><en> If you keep the quiet persistently, then this instability will begin to decrease, the Mother's Force will get in everywhere and, though there will still be much to do, there will be a firm foundation for what has to be done.
<G-vec00028-002-s568><decrease.vermindern><de> Wenn du beharrlich die Ruhe bewahrst, vermindert sich diese Unstetigkeit, die Kraft der Mutter gelangt überall hin und es wird eine feste Grundlage geschaffen für das, was noch getan werden muss.
<G-vec00028-002-s569><decrease.vermindern><en> Splash, water and dust resistance are not permanent conditions and resistance might decrease as a result of normal wear.
<G-vec00028-002-s569><decrease.vermindern><de> Spritzwasser- und Staubschutz ist kein dauerhafter Zustand und kann infolge von normalem Verschleiß vermindert werden.
<G-vec00028-002-s570><decrease.vermindern><en> Improved driving behaviour will not only reduce the risk of accidents in your warehouse, but also decrease repetitive strain injuries of your employees and lower their stress levels.
<G-vec00028-002-s570><decrease.vermindern><de> Die Verbesserung des Fahrverhaltens trägt nicht nur zur Reduzierung von Unfällen in Ihrem Lager bei, sondern vermindert auch die gesundheitliche Belastung Ihrer Mitarbeiter aufgrund eines niedrigeren Stresslevels.
<G-vec00028-002-s571><decrease.vermindern><en> A desktop CPU would certainly not function correctly, if Windows didn't activate special functions when recognizing a notebook, which sort of switch the CPU off during pauses, and so decrease the heat development noticeably.
<G-vec00028-002-s571><decrease.vermindern><de> Eine Desktop-CPU würde in einem Notebook aber sicher nicht funktionieren, wenn Windows bei Erkennen eines Notebooks nicht spezielle Funktionen aktivieren würde, welche die CPU in Ruhepausen quasi abschaltet, und damit die Wärmeentwicklung deutlich vermindert.
<G-vec00028-002-s714><decrease.zurückgehen><en> Nemtsov said that in the short term, however, McDonald’s sales in Russia could decrease.
<G-vec00028-002-s714><decrease.zurückgehen><de> Kurzfristig jedoch könnten die Umsätze des Unternehmens zurückgehen.
<G-vec00028-002-s715><decrease.zurückgehen><en> The company anticipates that revenues in its automotive business will decrease slightly compared to the fourth quarter of the 2006 financial year, as a result of typical seasonal weakness, as well as anticipated volume reductions at U.S. car manufacturers.
<G-vec00028-002-s715><decrease.zurückgehen><de> Infineon rechnet damit, dass der Umsatz im Geschäft mit Automobilelektronik auf Grund der typischen saisonalen Nachfrageschwäche sowie der erwarteten Volumenreduzierungen bei US-amerikanischen Automobilherstellern gegenüber dem Vorquartal leicht zurückgehen wird.
<G-vec00028-002-s716><decrease.zurückgehen><en> Owing to demographic development, in the near future, the number of school leavers available to the vocational and training market in Hesse will decrease by more than 25%.
<G-vec00028-002-s716><decrease.zurückgehen><de> In den nächsten Jahren wird die Zahl der Schulabsolventinnen und Schulabsolventen, die dem hessischen Ausbildungsmarkt insgesamt zur Verfügung stehen, demografiebedingt um mehr als 25% zurückgehen.
<G-vec00028-002-s717><decrease.zurückgehen><en> We think China’s energy and metal consumption is more likely to increase than decrease over the long term given the tremendous growth and improvement in infrastructure that is still needed in China compared with developed countries.
<G-vec00028-002-s717><decrease.zurückgehen><de> Wir denken, dass Chinas Energie- und Metallverbrauch langfristig eher steigen als zurückgehen wird, weil China noch sehr viel mehr Wachstum und Ausbau der Infrastruktur brauchen wird als die Industrieländer.
<G-vec00028-002-s718><decrease.zurückgehen><en> Travel times will be reduced by 2.5 million hours per year and the number of road fatalities will decrease allowing for increased development in the region.
<G-vec00028-002-s718><decrease.zurückgehen><de> Die Fahrzeiten werden sich um 2,5 Millionen Stunden pro Jahr verringern und die Zahl der Verkehrstoten wird zurückgehen, was eine verstärkte Entwicklung in der Region ermöglichen wird.
<G-vec00028-002-s719><decrease.zurückgehen><en> According to the outlook that has been delineated for us by Allah's favor and thanks to the determination our faithful people, the year 1392 will be the year of progress, dynamism and experience for the Iranian nation, not in the sense that the enmity of the enemies will decrease, rather in the sense that the Iranian people will be more prepared and their presence will be more effective. They will be better and more promising at building the future of this nation with their hands and with their effective efforts.
<G-vec00028-002-s719><decrease.zurückgehen><de> Das Jahr 1392 lässt mit Gottes Gnade und dank der Entschlossenheit und dem Einsatz der muslimischen Bevölkerung eine optimistische Aussicht zu und wird ein Jahr des Fortschrittes, der Dynamik und Erfahrung der iranischen Nation sein; allerdings nicht in dem Sinne, dass die Aggressionen der Feinde zurückgehen werden, sondern in dem Sinne, dass die iranische Bevölkerung noch mehr Bereitschaft beweist, noch effektiver mitwirkt und die Zukunft dieses Volkes mit eigenen Händen und aufgrund eigener kompetenter Anstrengungen – so Gott will –besser und hoffungsfroher gestalten wird.
<G-vec00028-002-s720><decrease.zurückgehen><en> If a customer without entitled reason refuses the acceptance of an ordered goods delivery or if it lets an ordered cash-on-delivery item decrease/go back, then it owes nevertheless the agreed upon purchase price in full height.
<G-vec00028-002-s720><decrease.zurückgehen><de> Verweigert ein Kunde ohne berechtigten Grund die Annahme einer bestellten Warenlieferung oder läßt er eine bestellte Nachnahmesendung zurückgehen, so schuldet er gleichwohl den vereinbarten Kaufpreis in voller Höhe.
<G-vec00028-002-s721><decrease.zurückgehen><en> For 2016, investments should decrease significantly.
<G-vec00028-002-s721><decrease.zurückgehen><de> Im Jahr 2016 sollen die Investitionen deutlich zurückgehen.
<G-vec00028-002-s722><decrease.zurückgehen><en> In the coming years, they are expected to decrease to 22 and 16 nanometers.
<G-vec00028-002-s722><decrease.zurückgehen><de> In den kommenden Jahren werden sie aber voraussichtlich auf 22 und dann auf 16 Nanometer zurückgehen.
<G-vec00028-002-s723><decrease.zurückgehen><en> Frost and snow will steadily diminish and thus decrease considerably due to climate change, and this is estimated to occur at lower altitudes below 900 metres.
<G-vec00028-002-s723><decrease.zurückgehen><de> Frost und Schnee werden stetig weniger werden und also aufgrund des Klimawandels erheblich zurückgehen, und zwar schätzungsweise bis in tiefere Lagen unter 900 Meter.
<G-vec00028-002-s724><decrease.zurückgehen><en> The aviation market, which has been relatively stable so far, is likely to decline later this year as passenger and cargo miles flown decrease.
<G-vec00028-002-s724><decrease.zurückgehen><de> Das Luftfahrtsegment, das bisher relativ stabil war, wird im weiteren Jahresverlauf wahrscheinlich nachlassen, da die geflogenen Passagier- und Frachtkilometer zurückgehen.
<G-vec00028-002-s725><decrease.zurückgehen><en> The EU population in total will increase by 10 million people in the next 50 years, while the EU workforce will decrease by 50 million.
<G-vec00028-002-s725><decrease.zurückgehen><de> Die EU-Bevölkerung wird insgesamt um 10 Millionen Menschen in den nächsten 50 Jahren zunehmen, während die EU-Erwerbstätigen um 50 Millionen zurückgehen werden.
<G-vec00118-002-s221><decrease.mindern><en> All our demands become due immediately independent of the running time of credited draft if a payment appointment is not kept or the buyer offends against other contractual agreements or circumstances confessed, that are suited to decrease the credit worthiness of the buyer.
<G-vec00118-002-s221><decrease.mindern><de> Alle unsere Forderungen werden unabhängig von der Laufzeit etwa hereingenommener und gutgeschriebener Wechsel sofort fällig, wenn ein Zahlungstermin nicht eingehalten wird oder der Käufer gegen sonstige vertragliche Vereinbarungen verstößt oder uns Umstände bekannt werden, die geeignet sind, die Kreditwürdigkeit des Käufers zu mindern.
<G-vec00118-002-s222><decrease.mindern><en> Redness from dry skin will significantly decrease if you keep your body hydrated.
<G-vec00118-002-s222><decrease.mindern><de> Rötungen durch trockene Haut werden sich signifikant mindern, wenn du deinem Körper genügend Flüssigkeit zuführst.
<G-vec00118-002-s223><decrease.mindern><en> You need to follow a few simple steps to increase your good cholesterol (HDL) in order to decrease the risk of heart disease.
<G-vec00118-002-s223><decrease.mindern><de> Eine Person muss sowohl darauf abzielen, LDL zu senken als auch HDL zu erhöhen, um Risiken von Herzkrankheiten zu mindern.
<G-vec00118-002-s224><decrease.mindern><en> They decrease, steal your beauty.
<G-vec00118-002-s224><decrease.mindern><de> Sie mindern, stehlen euere Schönheit.
<G-vec00118-002-s225><decrease.mindern><en> If Jesus and his mother, who both were Jews and died as Jews, could not decrease the influence of hell, to say nothing of destroying it, how can we hope to divert the atomic danger with the traditional means of the Church?
<G-vec00118-002-s225><decrease.mindern><de> Wenn Jesus oder seine Mutter, die beide Juden waren und als Juden starben, den Einfluß der Hölle nicht mindern, geschweige denn abschaffen konnten, wie können wir hoffen, mit den traditionellen Mitteln der Kirche, die atomare Gefahr abzuwenden.
<G-vec00118-002-s226><decrease.mindern><en> Henry Kowalczyk, secretary of the group, said that recent studies showed that Sunday closures would not increase unemployment or decrease economic development.
<G-vec00118-002-s226><decrease.mindern><de> Der Sekretär dieser Gruppe, Henry Kowalczyk, sagte, kürzliche Studien hätten aufgezeigt, dass die sonntägliche Geschäftsschließung weder die Arbeitslosigkeit erhöhen noch die wirtschaftliche Entwicklung mindern würde.
<G-vec00118-002-s227><decrease.mindern><en> Construction of houses from the whole and lined thermally treated beam reduces the cost price and the construction terms decrease.
<G-vec00118-002-s227><decrease.mindern><de> Der Hausbau aus dem ganzheitlichen und dem verklebten thermobearbeiteten Holzes reduziert den Selbstkostenpreis, die Baufristen mindern sich.
<G-vec00118-002-s228><decrease.mindern><en> Drag the slider to the right or left to increase or decrease the speed of the multimedia animations used during the games.
<G-vec00118-002-s228><decrease.mindern><de> Spielgeschwindigkeit Ziehen Sie den Schieber nach rechts oder links, um die Geschwindigkeit der Multimediaanimationen, die während der Spiele benutzt werden, zu erhöhen oder zu mindern.
<G-vec00118-002-s229><decrease.mindern><en> In case the improvement fails or the exchanged product is also unsatisfactory, you can either give back the product against refund of the full selling price or decrease the selling price.
<G-vec00118-002-s229><decrease.mindern><de> Schlägt die Nachbesserung fehl oder ist die nachgelieferte Ware ebenfalls mangelhaft, so können Sie nach Ihrer Wahl die Ware gegen Rückerstattung des vollen Kaufpreises zurückgeben oder den Kaufpreis mindern.
<G-vec00118-002-s230><decrease.mindern><en> Also consider reading E-books must increase our freedom, not decrease it.
<G-vec00118-002-s230><decrease.mindern><de> Bitte lesen Sie auch Elektronische Bücher müssen unsere Freiheit erweitern, nicht mindern.
<G-vec00118-002-s231><decrease.mindern><en> The geometry of computation was simplified comparing to the real combustion chamber in order to decrease the computational effort.
<G-vec00118-002-s231><decrease.mindern><de> Die Berechnungsgeometrie wurde gegenüber der realen Brennkammer vereinfacht, um den Rechenaufwand zu mindern.
<G-vec00118-002-s232><decrease.mindern><en> If the wound swells too much, you may need to decrease the pressure of the splint.
<G-vec00118-002-s232><decrease.mindern><de> Wenn die Wunde zu stark anschwillt, musst du vielleicht den Druck auf die Schiene mindern.
<G-vec00118-002-s275><decrease.reduzieren><en> Evidence is growing that daily use of supplements can decrease national healthcare costs.
<G-vec00118-002-s275><decrease.reduzieren><de> Immer mehr Belege bestätigen, dass eine tägliche Nahrungsergänzung die Kosten der nationalen Gesundheitssysteme reduzieren kann.
<G-vec00118-002-s276><decrease.reduzieren><en> We aim to use this plan to decrease our impact on the environment in long term.
<G-vec00118-002-s276><decrease.reduzieren><de> Mittels dieses Plans möchten wir unsere Auswirkung auf die Umwelt reduzieren, und dies langfristig.
<G-vec00118-002-s277><decrease.reduzieren><en> On the other hand, if the polybutene in the follower has a high molecular weight, or if the gelatinizer is added in an increased amount, the ink follower that should follow the ink with the ink consumption tends to be too hard to follow or be adhered to the inner wall of the ink tube and decrease in amount as it moves with the ink consumption, resulting in adverse influences on various performance properties.
<G-vec00118-002-s277><decrease.reduzieren><de> Wenn andererseits das Polybuten in dem Nachfolgemittel ein hohes Molekulargewicht hat oder wenn das Geliermittel in erhöhter Menge zugesetzt wird, neigt das Tintennachfolgemittel, das der Tinte mit dem Tintenverbrauch folgen sollte, dazu, zu hart zu werden um zu folgen oder an der Innenwand des Tintenrohrs zu haften und die Menge zu reduzieren, die sich mit dem Tintenverbrauch bewegt, was zu nachteiligen Einflüssen auf verschiedene Leistungen führt.
<G-vec00118-002-s278><decrease.reduzieren><en> Dramatically decrease your consumption of sugar (particularly fructose), grains and processed foods. (In addition to being high in sugar and grains, processed foods also contain a variety of additives that can affect your brain function and mental state, especially MSG and artificial sweeteners such as aspartame.)
<G-vec00118-002-s278><decrease.reduzieren><de> Reduzieren Sie Ihren Verzehr von Zucker (vor allem Fruktose), Getreide und verarbeiteten Lebensmitteln (Neben dem hohen Zucker- und Getreidegehalt enthalten verarbeitete Lebensmittel auch eine Vielzahl von Zusatzstoffen, die Ihre Gehirnfunktion und Ihren psychischen Zustand beeinflussen können, insbesondere Natriumglutamat und künstliche Süßstoffe wie Aspartam).
<G-vec00118-002-s279><decrease.reduzieren><en> The answer is relatively simple: if you follow a mild hypocaloric diet, you will effectively decrease the possible side effects of Xenical, which can be heavy.
<G-vec00118-002-s279><decrease.reduzieren><de> Die Antwort ist relativ simpel: Wenn Sie eine leicht kalorienarme Ernährung befolgen, reduzieren Sie die möglichen Nebenwirkungen von Xenical, die schwer sein können.
<G-vec00118-002-s280><decrease.reduzieren><en> Beta blockers decrease the force and rate of heart contractions, thereby reducing the demand for oxygen and lowering blood pressure.
<G-vec00118-002-s280><decrease.reduzieren><de> Beta-Blocker reduzieren die Kraft und die Geschwindigkeit der Herzkontraktionen, wodurch die Nachfrage nach Sauerstoff und der Blutdruck sinkt.
<G-vec00118-002-s281><decrease.reduzieren><en> Decrease your charge times and make sure your mobile devices are ready whenever you need them while you’re on the road.
<G-vec00118-002-s281><decrease.reduzieren><de> Reduzieren Sie Ihre Ladezeiten und sorgen Sie dafür, dass Ihre mobilen Geräte dann einsatzbereit sind, wenn Sie sie unterwegs benötigen.
<G-vec00118-002-s282><decrease.reduzieren><en> It had actually exposed the overweight folks in Leoben Austria to the world of chance where they could possibly decrease their excessive fatty tissue very easily.
<G-vec00118-002-s282><decrease.reduzieren><de> Es hatte die fettleibigen Menschen in Leoben Österreich der Welt Gelegenheit ausgesetzt, wo sie ihr übermäßiges Fett sehr leicht reduzieren könnte.
<G-vec00118-002-s283><decrease.reduzieren><en> Together with AWS, you can run these jobs with greater scale and elasticity, improve performance by leveraging the latest-generation of computing hardware, and decrease costs with flexible payment models.
<G-vec00118-002-s283><decrease.reduzieren><de> Zusammen mit AWS können Sie diese Jobs mit größerer Skalierung und Elastizität durchführen, die Leistung durch die Nutzung der aktuellsten Generation von Computing-Hardware verbessern und Kosten mit flexiblen Zahlungsmodellen reduzieren.
<G-vec00118-002-s284><decrease.reduzieren><en> Repeaters used in simple line topology decrease the maximum bitrate due to their internal propagation delay.
<G-vec00118-002-s284><decrease.reduzieren><de> Repeater, die in einfachen Busstrukturen verwendet werden reduzieren die Bitrate aufgrund ihrer internen Sperrzeit.
<G-vec00118-002-s285><decrease.reduzieren><en> You can pause the subscription at any time, increase or decrease order frequency, change address or cancel.
<G-vec00118-002-s285><decrease.reduzieren><de> Du kannst das Abo jederzeit pausieren, Bestellrhythmus erhöhen oder reduzieren, Adresse ändern oder kündigen.
<G-vec00118-002-s286><decrease.reduzieren><en> Decrease the backlight time.
<G-vec00118-002-s286><decrease.reduzieren><de> Reduzieren Sie die Displaybeleuchtungsdauer.
<G-vec00118-002-s287><decrease.reduzieren><en> Continued use of GPS in the background can drastically decrease the battery runtime.
<G-vec00118-002-s287><decrease.reduzieren><de> Die Nutzung von GPS im Hintergrund kann die Akkulaufzeit drastisch reduzieren.
<G-vec00118-002-s288><decrease.reduzieren><en> If you delete that file, your zoom level settings will be reset, but it should decrease CPU usage.
<G-vec00118-002-s288><decrease.reduzieren><de> Wenn Sie diese Datei löschen, werden Ihre Zoom-Einstellungen zurückgesetzt, aber es sollte den CPU-Verbrauch reduzieren.
<G-vec00118-002-s289><decrease.reduzieren><en> Using Tyvek® to protect perishables during air transportation and transit (a typical example is asparagus shipped from Peru to the world) can extend shelf life and decrease your loss rates dramatically and thereby increase profitability.
<G-vec00118-002-s289><decrease.reduzieren><de> Die Verwendung von Tyvek® zum Schutz von verderblichen Waren beim Transport am Boden oder in der Luft (ein typisches Beispiel ist die Lieferung von peruanischem Spargel in alle Welt) kann ihre Haltbarkeit verlängern, die Verluste deutlich reduzieren und so die Wirtschaftlichkeit steigern.
<G-vec00118-002-s290><decrease.reduzieren><en> Recipes can be tagged according to the nutritional composition of the resulting dish, in terms of recommended to increase or decrease specific nutrients, for example #increasecalcium, #increasefat, #decreasesugar.
<G-vec00118-002-s290><decrease.reduzieren><de> Rezepte können gemäß der Nährstoffzusammensetzung des fertigen Gerichts dahingehend gekennzeichnet werden, ob sie sich dafür eignen bestimmte Nährstoffe laut Empfehlung zu erhöhen oder zu reduzieren, zum Beispiel #erhöhekalzium, #erhöhefett, #reduzierezucker.
<G-vec00118-002-s291><decrease.reduzieren><en> PC TuneUp tools like Program Deactivator, Startup Manager, Uninstall Manager or Turbo Mode can all help you decrease this activity and make your PC run smooth again.
<G-vec00118-002-s291><decrease.reduzieren><de> PC TuneUp Tools wie Program Deactivator, Startup Manager, Uninstall Manager oder Turbo-Modus können Ihnen dabei helfen, diese Aktivität zu reduzieren und Ihren PC wieder flüssig laufen zu lassen.
<G-vec00118-002-s292><decrease.reduzieren><en> If so decrease the D-value of the Pitch slightly or change Motor power value of Pitch.
<G-vec00118-002-s292><decrease.reduzieren><de> Reduzieren Sie leicht den D-Wert des vibrierenden Motors (Pitch) und/oder ändern Sie leicht den Wert der Motorleistung.
<G-vec00118-002-s293><decrease.reduzieren><en> Particularly the late complications of this disease decrease the expectancy and the quality of life and lead to a higher mortality.
<G-vec00118-002-s293><decrease.reduzieren><de> Besonders die auftretenden Spätkomplikationen reduzieren sowohl die Lebenserwartung als auch die Lebensqualität diabetischer Patienten erheblich.
<G-vec00118-002-s294><decrease.reduzieren><en> The outstanding results of "Progetto Infortuni 0" – Zero Accidents Project – bear witness to this: 80% decrease in the rate of accidents per hour worked in 5 years (13 accidents vs. 80 per 1,000,000 hours) and a remarkable reduction in injury severity.
<G-vec00118-002-s294><decrease.reduzieren><de> Besonders die Ergebnisse des "Null-Unfall" - Projekts stechen hervor, denn dadurch konnte die Anzahl der Arbeitsunfälle in den letzten 5 Jahren um 80% reduziert werden (von 80 auf 13 Unfälle pro 1.000.000 Arbeitsstunden), und auch die Schwere der Unfälle nahm deutlich ab.
<G-vec00118-002-s295><decrease.reduzieren><en> You'll see the repair laser hitting the target ship, and the hull damage will slowly decrease.
<G-vec00118-002-s295><decrease.reduzieren><de> Du wirst sehen, wie der Reparaturlaser das Schiff trifft und sich der Hüllenschaden reduziert.
<G-vec00118-002-s296><decrease.reduzieren><en> There is also a decrease in stress hormones, like adrenaline.
<G-vec00118-002-s296><decrease.reduzieren><de> Auch die Stresshormone, beispielsweise Adrenalin, werden reduziert.
<G-vec00118-002-s297><decrease.reduzieren><en> If you’re only seeking the most beautiful ladies, your chances on having a successful meeting will decrease.
<G-vec00118-002-s297><decrease.reduzieren><de> Wenn Sie nur auf der Suche der schönsten Damen sind, werden Ihre Chancen für ein erfolgreiches Treffen reduziert.
<G-vec00118-002-s298><decrease.reduzieren><en> Decrease administrative costs by keeping all patient records in a single case.
<G-vec00118-002-s298><decrease.reduzieren><de> Administrative Kosten werden reduziert, da Patientendaten in einer Akte aufbewahrt werden.
<G-vec00118-002-s299><decrease.reduzieren><en> This quintessential component of our Anti-Aging Eye Cream has been clinically proven to decrease the appearance of crow’s feet and other signs of wear.
<G-vec00118-002-s299><decrease.reduzieren><de> Es ist klinisch erwiesen, dass dieser wesentliche Bestandteil unserer Anti-Aging-Augencreme das Auftreten von Krähenfüßen und anderen Abnutzungserscheinungen reduziert.
<G-vec00118-002-s300><decrease.reduzieren><en> The new breakthroughs of spin casting and forging make wheel intensity increase by 15% and weight decrease by 20%.
<G-vec00118-002-s300><decrease.reduzieren><de> So kann durch Flowforming oder Schmieden die Festigkeit der Räder gegenüber gegossenen Produkten um 15% erhöht und das Gewicht gleichzeitig um 20% reduziert werden.
<G-vec00118-002-s301><decrease.reduzieren><en> Its main advantage is given by the fact that it reduces the Hughes phenomenon (performance decrease due to high dimensionality) because it abstains from raising dimensionality in the feature space.
<G-vec00118-002-s301><decrease.reduzieren><de> Ihr Hauptvorteil besteht darin, dass dadurch das Hughes Phänomen (Performanzverlust durch hohe Dimensionalität) reduziert wird, indem sie es vermeidet, die Dimensionalität des Merkmalsraums zu erhöhen.
<G-vec00118-002-s302><decrease.reduzieren><en> Moreover, the arguments of monetary policy makers are, in some regards, circular: If the output shortfall does not decrease and inflation does not increase, despite lower interest rates, this can – according to this logic – only mean that the natural rate of interest must be even lower.
<G-vec00118-002-s302><decrease.reduzieren><de> Außerdem ist die Argumentation der Geldpolitiker in gewisser Weise zirkulär: Wenn die Outputlücke sich trotz niedriger Zinsen nicht reduziert und die Inflation nicht steigt, kann das in dieser Logik nur bedeuten, dass der natürliche Zins eben noch niedriger liegen muss.
<G-vec00118-002-s303><decrease.reduzieren><en> The other use for PHP Processor is to optimize PHP source code and considerably decrease size of your source code files.
<G-vec00118-002-s303><decrease.reduzieren><de> Außerdem kann mithilfe des Programms PHP Quellencode optimiziert und die Größe Eurer Quelldateien wesentlich reduziert werden.
<G-vec00118-002-s304><decrease.reduzieren><en> Anyway it’s a welcome act of Microsoft and also the Upload for free will decrease a part of the costs.
<G-vec00118-002-s304><decrease.reduzieren><de> Auf alle Fälle ist es ein begrüßenswerter Zug von Microsoft und auch mit dem “kostenlosen” Upload wird ein Teil der Kosten reduziert.
<G-vec00118-002-s305><decrease.reduzieren><en> Given that guarana supports the breakdown of lactic acid, which helps to decrease muscle soreness, making it a favorite among athletes.
<G-vec00118-002-s305><decrease.reduzieren><de> Da Guarana den Milchsäureabbau unterstützt und somit Muskelermüdung reduziert, ist sie auch bei Sportlern sehr beliebt.
<G-vec00118-002-s306><decrease.reduzieren><en> As a result you decrease your chances of rust.
<G-vec00118-002-s306><decrease.reduzieren><de> Dadurch wird die Rostbildung auf ein Minimum reduziert.
<G-vec00118-002-s307><decrease.reduzieren><en> As a result, the company experienced a decrease of customer complaints and credit notes generated by these complaints; this subsequently increased the overall profits of the security company.
<G-vec00118-002-s307><decrease.reduzieren><de> So konnten Kundenbeschwerden und dadurch auszustellende Gutschriften reduziert werden, was den Reinerlös des Sicherheitsdienstes erhöhte.
<G-vec00118-002-s308><decrease.reduzieren><en> Continued use of GPS running in the background can dramatically decrease battery life.
<G-vec00118-002-s308><decrease.reduzieren><de> Bitte beachten, dass die kontinuierliche Verwendung von GPS im Hintergrund die Akkulaufzeit reduziert.
<G-vec00118-002-s309><decrease.reduzieren><en> We have worked to reduce the thickness of polybags (used for packaging PUMA apparel and accessories) to decrease the use of polyethylene.
<G-vec00118-002-s309><decrease.reduzieren><de> Wir haben zudem die Stärke unserer Polybags (zum Verpacken von PUMA-Textilien und -Accessoires) und damit den Verbrauch von Polyethylen reduziert.
<G-vec00118-002-s310><decrease.reduzieren><en> Advertising content that is clearly and recognisably separated from editorial content is on the decrease, or appears in the form of a banner on different Internet platforms.
<G-vec00118-002-s310><decrease.reduzieren><de> Eindeutig erkennbare Werbung reduziert sich immer weiter oder erscheint als Banner auf Internetplattformen.
<G-vec00118-002-s311><decrease.reduzieren><en> Beta-blockers improve the heart's ability to relax, decrease the production of harmful substances produced by the body in response to heart failure and slow the heart rate.
<G-vec00118-002-s311><decrease.reduzieren><de> Weiterhin wird die Produktion schädlicher Substanzen reduziert, die im Körper bei Herzschwäche vermehrt produziert werden.
<G-vec00118-002-s312><decrease.reduzieren><en> This eliminates the need to back up each time the attachment and message are referenced and can significantly decrease the size of your backups.
<G-vec00118-002-s312><decrease.reduzieren><de> Dadurch muss nicht immer eine Sicherung erfolgen, wenn auf Anhang und Nachricht verwiesen wird, wodurch die Größe der Sicherung wesentlich reduziert werden kann.
<G-vec00118-002-s500><decrease.verkleinern><en> After all, you can still decrease a file, while enlarging on the other hand, is a lot more difficult.
<G-vec00118-002-s500><decrease.verkleinern><de> Verkleinern kann man später immer noch, das Vergrößern wird erheblich schwieriger.
<G-vec00118-002-s501><decrease.verkleinern><en> Increase or decrease the size of your text or change its font using the buttons in the upper right corner.
<G-vec00118-002-s501><decrease.verkleinern><de> Mit den Schaltflächen in der oberen rechten Ecke vergrößern oder verkleinern Sie die Größe Ihres Textes oder verändern den Font.
<G-vec00118-002-s502><decrease.verkleinern><en> This causes the formation of gas-filled cavities between the vanes and the surface of the liquid. The cavities increase and decrease alternately.
<G-vec00118-002-s502><decrease.verkleinern><de> Dadurch bilden sich zwischen den Schaufeln und der Flüssigkeitsoberfläche gasgefüllte Hohlräume, die sich abwechselnd vergrößern und verkleinern.
<G-vec00118-002-s503><decrease.verkleinern><en> With the flexibility to increase or decrease capacity depending on demand, KSA is only paying for what they need and can grow with confidence.
<G-vec00118-002-s503><decrease.verkleinern><de> Mit der Flexibilität, die Kapazität je nach Bedarf zu vergrößern oder zu verkleinern, bezahlt das KSA nur das, was auch benötigt wird, und kann ohne Sorgen weiter wachsen.
<G-vec00118-002-s504><decrease.verkleinern><en> When the dotted sizing arrow appears in the corner hold your left mouse button down and drag left or right to increase or decrease the size.
<G-vec00118-002-s504><decrease.verkleinern><de> Wenn der gepunktete Pfeil in der Ecke angezeigt wird, drücken und halten Sie die linke Maustaste und ziehen nach links oder rechts, um das Berichtsfenster zu verkleinern oder zu vergrößern.
<G-vec00118-002-s505><decrease.verkleinern><en> You can also move the slider by clicking on the date/time bar and using the wheel on your mouse to increase or decrease the interval.
<G-vec00118-002-s505><decrease.verkleinern><de> Alternativ können Sie auch auf den Datum-/Uhrzeitbalken klicken und die Zeitintervalle mithilfe des Scrollrads vergrößern oder verkleinern.
<G-vec00118-002-s506><decrease.verkleinern><en> Increase or decrease the view by using the right side Zoom slider.
<G-vec00118-002-s506><decrease.verkleinern><de> Mit dem Zoom-Slider vergrößern Sie die Ansicht und mit dem Point Size-Slider vergrößern oder verkleinern Sie die Messpunkte.
<G-vec00118-002-s507><decrease.verkleinern><en> To make an image darker decrease the value.
<G-vec00118-002-s507><decrease.verkleinern><de> Um ein Bild dunkler zu machen, verkleinern Sie diesen Wert.
<G-vec00118-002-s508><decrease.verkleinern><en> Drag the Continuous Zoom tool (also called Dynamic Zoom) up to increase the magnification and down to decrease magnification.
<G-vec00118-002-s508><decrease.verkleinern><de> Ziehen Sie mit dem Werkzeug Kontinuierlicher Zoom (auch „Dynamischer Zoom“ genannt) nach oben, um zu vergrößern, oder nach unten, um zu verkleinern.
<G-vec00118-002-s509><decrease.verkleinern><en> Apart from, moving in a horizontal position we can increase or decrease the depth level. Underwater destruction gear
<G-vec00118-002-s509><decrease.verkleinern><de> Neben der horizontalen Bewegung können wir – dies ist endlich etwas Neues – die Tiefe vergrößern oder verkleinern.
<G-vec00118-002-s510><decrease.verkleinern><en> We will decrease the size of the combustion engine (downsizing).
<G-vec00118-002-s510><decrease.verkleinern><de> Wir verkleinern den Verbrennungsmotor (Downsizing).
<G-vec00118-002-s511><decrease.verkleinern><en> You can increase or decrease the design up to 20% from the original size to fit your project.
<G-vec00118-002-s511><decrease.verkleinern><de> Die Größe eines Designs können Sie im Vergleich zum Original um bis zu 20 % vergrößern oder verkleinern.
<G-vec00118-002-s512><decrease.verkleinern><en> Since this increases the size of the menu item significantly, it is possible to use the command M_Command Entry,$1D to decrease the size of the item to 16 x 16 pixels.
<G-vec00118-002-s512><decrease.verkleinern><de> Da dadurch der Menüeintrag sehr gross wird, besteht die Möglichkeit, das Icon mit dem Befehl M_Command Entry,$1D auf 16 x 16 Pixel zu verkleinern.
<G-vec00118-002-s513><decrease.verkleinern><en> Other numerical zoom options let you increase or decrease magnification of this view.
<G-vec00118-002-s513><decrease.verkleinern><de> Mit anderen numerischen Zoomoptionen können Sie die Ansicht verkleinern oder vergrößern.
<G-vec00118-002-s514><decrease.verkleinern><en> You may transport it without problems as Travel Hoop because with a few simple steps you can easily decrease the size.
<G-vec00118-002-s514><decrease.verkleinern><de> Transportieren können Sie diesen Hip Hop Hula Hoop leicht, denn mit wenigen Handgriffen können Sie die Größe leicht verkleinern.
<G-vec00118-002-s515><decrease.verkleinern><en> For example, if you are printing a large banner that is made up of many horizontal pages, you can increase or decrease the margin between the pages so that you can tape the pages together without covering some of the printed area.
<G-vec00118-002-s515><decrease.verkleinern><de> Wenn Sie beispielsweise ein großes Banner drucken, das aus vielen horizontalen Seiten besteht, können Sie den Rand zwischen den Seiten vergrößern oder verkleinern, sodass Sie die Seiten aneinanderkleben können, ohne irgendeinen bedruckten Bereich zu verdecken.
<G-vec00118-002-s516><decrease.verkleinern><en> Increase or decrease Boot Camp partitions in minutes.
<G-vec00118-002-s516><decrease.verkleinern><de> Vergrößern oder verkleinern Sie Boot-Camp-Partitionen in wenigen Minuten.
<G-vec00118-002-s517><decrease.verkleinern><en> Increase or decrease the white space between sentences and paragraphs to improve readability.
<G-vec00118-002-s517><decrease.verkleinern><de> Vergrößern oder verkleinern Sie den Leerraum zwischen Sätzen und Absätzen ein.
<G-vec00118-002-s518><decrease.verkleinern><en> Align paragraphs left, right, or centered; run text right-to-left or left-to-right; increase or decrease indentation; adjust line spacing; format paragraphs as a bulleted or numbered list.
<G-vec00118-002-s518><decrease.verkleinern><de> Ausrichten von Absätzen nach links, rechts oder zentriert; textausrichtung von rechts-nach-links- oder links-nach-rechts; Vergrößern oder Einzug verkleinern; Formatieren Sie Absätze als Aufzählung oder nummerierte Liste.
<G-vec00118-002-s527><decrease.verkürzen><en> Note: Continued use of GPS running in the background can dramatically decrease battery life.
<G-vec00118-002-s527><decrease.verkürzen><de> Hinweis: Eine ständige Nutzung von GPS im Hintergrund kann die Akkulaufzeit stark verkürzen.
<G-vec00118-002-s528><decrease.verkürzen><en> Note: Continued use of GPS running in the background can dramatically decrease battery life.
<G-vec00118-002-s528><decrease.verkürzen><de> Hinweis: Eine lange im Hintergrund laufende GPS-Nutzung kann die Akkulaufzeit stark verkürzen.
<G-vec00118-002-s529><decrease.verkürzen><en> Say that we can increase the three first factors by 2 % and decrease sales cycle by the same value.
<G-vec00118-002-s529><decrease.verkürzen><de> Nehmen wir an, wir erhöhen die Zähler um 2 % und verkürzen den Vertriebszyklus mit dem selben Wert.
<G-vec00118-002-s530><decrease.verkürzen><en> - Continued use of GPS running in the background can dramatically decrease battery life.
<G-vec00118-002-s530><decrease.verkürzen><de> - Die fortgesetzte Verwendung von GPS im Hintergrund kann die Batterielebensdauer drastisch verkürzen.
<G-vec00118-002-s531><decrease.verkürzen><en> The precise scan will hugely decrease the time of hunting for lost data.
<G-vec00118-002-s531><decrease.verkürzen><de> Der präzise Scan wird die Zeit der Suche nach verlorenen Daten erheblich verkürzen.
<G-vec00118-002-s532><decrease.verkürzen><en> Companies that partner with Furmanite and execute PSIM are able to reduce fugitive emissions and the related testing costs, reallocate resources (including personnel and equipment), and decrease downtime.
<G-vec00118-002-s532><decrease.verkürzen><de> Die Unternehmen, die mit Furmanite zusammenarbeiten und PSIM durchführen, sind in der Lage, durch eine Neuverteilung der Betriebsmittel (einschlieβlich Personal und Ausrüstung) diffuse Emissionen und die damit verbundenen Prüfkosten zu reduzieren und Stillstandszeiten zu verkürzen.
<G-vec00118-002-s533><decrease.verkürzen><en> Use the PXI platform to reduce test time, decrease cost by 75 percent, and perform process experiments that were previously impossible.
<G-vec00118-002-s533><decrease.verkürzen><de> Mithilfe der PXI-Plattform können Sie Prüfzeiten verkürzen, Kosten um 75 % senken und Prozessexperimente durchführen, die zuvor nicht möglich waren.
<G-vec00118-002-s534><decrease.verkürzen><en> Organization of in-house heat generation ensures significant saving of expenses for energy resources due to the decrease of expenses for maintenance of heating mains, decrease of loss of heat and heat-transfer liquid to the consumer, and current regulation of heat power of the boiler according to particular conditions. Application of modular boilers houses
<G-vec00118-002-s534><decrease.verkürzen><de> Die Organisierung der eigenen Wärmegewinnung ermöglicht, wesentlich die Kosten auf die Energieressourcen zu verkürzen, infolge der Kostensenkung auf die Fernheizleitungen, der Senkung der Wärmeverluste und Wärmeträgers bei der Transportierung zum Verbraucher, der Ausführung der operativen Regelung der Wärmeleistung des Heizraumes nach den konkreten Bedingungen.
<G-vec00118-002-s535><decrease.verkürzen><en> Note: Continued use of GPS running in the background can dramatically decrease battery life.
<G-vec00118-002-s535><decrease.verkürzen><de> Ständiger Betrieb des GPS im Hintergrund kann die Nutzungsdauer der Batterie dramatisch verkürzen.
<G-vec00118-002-s536><decrease.verkürzen><en> Once created, you can easily edit a time period by clicking on a time schedule and dragging the border to increase or decrease the scheduled length of time.
<G-vec00118-002-s536><decrease.verkürzen><de> Nachdem der Zeitraum erstellt ist, können Sie ihn ganz einfach bearbeiten, indem Sie auf einen Zeitplan klicken und den Rand ziehen, um den geplanten Zeitraum zu verlängern oder zu verkürzen.
<G-vec00118-002-s537><decrease.verkürzen><en> The items contained within will increase travel speeds, decrease travel times, and allow for easier access to frequently visited areas.
<G-vec00118-002-s537><decrease.verkürzen><de> Die enthaltenen Gegenstände erhöhen Reisegeschwindigkeiten, verkürzen Reisezeiten und ermöglichen einfacheren Zugang zu oft besuchten Bereichen.
<G-vec00118-002-s538><decrease.verkürzen><en> "Quick draw" is a command developed especially to decrease the modeling time.
<G-vec00118-002-s538><decrease.verkürzen><de> "Schnellzeichnen" ist ein Befehl, der speziell entwickelt wurde, um die Modellierungszeit zu verkürzen.
<G-vec00118-002-s539><decrease.verkürzen><en> To increase the performance of your list, you could decrease its membership duration to get only the most recent visitors.
<G-vec00118-002-s539><decrease.verkürzen><de> Sie können die Leistung Ihrer Liste steigern, indem Sie die Mitgliedschaftsdauer verkürzen, sodass die Liste nur die neuesten Besucher umfasst.
<G-vec00118-002-s540><decrease.verkürzen><en> When these companies faced challenges reaching and engaging specific audiences, they used headless implementations to decrease time to market and empower marketers with control over content.
<G-vec00118-002-s540><decrease.verkürzen><de> Als diese Unternehmen vor der Herausforderung standen, bestimmte Zielgruppen zu erreichen und anzusprechen, konnten sie mit Headless-Implementierungen die Time-to-Market verkürzen und ihren Marketingexperten mehr Kontrolle über den Content geben.
<G-vec00118-002-s541><decrease.verkürzen><en> Moreover, they represent a major issue in health care: a large number of these diseases lead to a significant decrease of life expectancy and most of them cause chronic illnesses with a large impact on quality of life and the health care system.
<G-vec00118-002-s541><decrease.verkürzen><de> Darüber hinaus stellen sie eine große Herausforderung für die Gesundheitssysteme dar, denn viele von ihnen verkürzen die Lebenserwartung und gehen mit chronischen Begleiterkrankungen einher, die die Lebensqualität der Betroffenen stark beeinträchtigen.
<G-vec00118-002-s542><decrease.verkürzen><en> Attention: Continued use of GPS running in the background can dramatically decrease battery life. Read more
<G-vec00118-002-s542><decrease.verkürzen><de> Bei Nutzung der App im Hintergrund mit aktiviertem GPS-Empfang kann sich die Akkulaufzeit drastisch verkürzen.
<G-vec00118-002-s591><decrease.verringern><en> Decrease the ATK and DEF of this card by 400 points for every card in your hand.
<G-vec00118-002-s591><decrease.verringern><de> Verringere die ATK und DEF dieser Karte für jede Karte in deiner Hand um 400 Punkte.
<G-vec00118-002-s592><decrease.verringern><en> A pre-irradiation with infrared light Decrease the percentage of destruction of 15%.
<G-vec00118-002-s592><decrease.verringern><de> Eine Vorbestrahlung mit Infrarotlicht verringere den Anteil der Zerstörung auf 15%.
<G-vec00118-002-s593><decrease.verringern><en> Fallenkarte Decrease the ATK of 1 attacking monster by 700 points until the end of the turn.
<G-vec00118-002-s593><decrease.verringern><de> Wähle 1 angreifendes Monster und verringere die ATK des gewählten Monsters um 700 Punkte in dem Spielzug, in dem diese Karte aktiviert wurde.
<G-vec00118-002-s594><decrease.verringern><en> If middle tire hotter than both sides decrease tire pressure
<G-vec00118-002-s594><decrease.verringern><de> Wenn die Mitte heißer als beide Seitenflächen ist, verringere den Druck.
<G-vec00118-002-s595><decrease.verringern><en> Decrease the ATK and DEF of all monsters on your opponent's side of the field by 500 points until the end of the turn this card is activated.
<G-vec00118-002-s595><decrease.verringern><de> Verringere die ATK und DEF aller Monster auf der Spielfeidseite deines Gegners um 500 Punkte bis zum Ende dieses Spielzugs.
<G-vec00118-002-s596><decrease.verringern><en> Decrease the ATK of this card by 400 points, then during battle between this attacking card and a Defense Position monster whose DEF is lower than the ATK of this card, inflict the difference as Battle Damage to your opponent's Life Points.
<G-vec00118-002-s596><decrease.verringern><de> Verringere die ATK dieser Karte um 400 Punkte und in jedem Kampf von dieser Karte und einem Monster in Verteidigungsposition, dessen DEF niedriger sind als die ATK dieser Karte, füge die Differenz den Life Points deines Gegners als Kampfschaden zu.
<G-vec00118-002-s597><decrease.verringern><en> Decrease the ATK of 1 attacking monster by 700 points until the end of the turn.
<G-vec00118-002-s597><decrease.verringern><de> Verringere die ATK von 1 angreifenden Monster bis zum Ende des Spielzugs um 700 Punkte.
<G-vec00118-002-s598><decrease.verringern><en> Karta Spell Equip Decrease the ATK of a monster equipped with this card by 1000 points.
<G-vec00118-002-s598><decrease.verringern><de> Karta Spell Equip Verringere die ATK des Monsters, das mit dieser Karte ausgerüstet ist, um 1000 Punkte.
<G-vec00118-002-s599><decrease.verringern><en> Trap Card Decrease the ATK of 1 of your opponent's monsters by 400 points for each "Hero Kid" in your Graveyard, until the End Phase.
<G-vec00118-002-s599><decrease.verringern><de> Fallenkarte Verringere die ATK von 1 Monster deines Gegners bis zur End Phase um 400 Punkte für jede "Heldenkind"-Karte in deinem Friedhof.
<G-vec00118-002-s600><decrease.verringern><en> Investigate which programs and files decrease the disk space.
<G-vec00118-002-s600><decrease.verringern><de> Untersuche, welche Programme und Dateien den Speicher verringern.
<G-vec00118-002-s601><decrease.verringern><en> The controller allows you to hang on tight while you cycle through the 5 incredible vibration speeds and 5 pulsations, but it also detaches via a retractable coil so that you can increase or decrease the speed, even as you flail in ecstasy!
<G-vec00118-002-s601><decrease.verringern><de> Die Fernbedienung ermöglicht, dass Sie einen festen Sitz erhalten, durch die 5 unglaublichen Vibrationsgeschwindigkeiten und 5 Pulsationsstärken, aber es kann auch abgenommen werden dank der entfernbaren Spirale, sodass Sie die Geschwindigkeit erhöhen oder verringern können.
<G-vec00118-002-s602><decrease.verringern><en> \n'+ '\"The amount of features that the Synology NAS includes, along with its powerful security, intuitive new web interface and fast throughput, has helped us to decrease our downtime and increase our productivity,\" says CTO Alberto Sánchez.
<G-vec00118-002-s602><decrease.verringern><de> \n'+ '„Dank der zahlreichen Leistungsmerkmale aus dem Lieferumfang des Synology NAS, der leistungsstarken Sicherheit, der intuitiven neuen Webschnittstelle und des schnellen Durchsatzes konnten wir unsere Ausfallzeiten verringern und unsere Produktivität erhöhen“, erklärte CTO Alberto Sánchez.
<G-vec00118-002-s603><decrease.verringern><en> It can decrease the fees of tensioning systems in many application occasions.
<G-vec00118-002-s603><decrease.verringern><de> Es kann die Gebühren der Spannkette Systeme in vielen Fällen der Anwendung verringern.
<G-vec00118-002-s604><decrease.verringern><en> To decrease the risk of AMS, strenuous exercise and over-exertion should be avoided immediately after rapid ascent to high altitude. Pre-acclimatizing
<G-vec00118-002-s604><decrease.verringern><de> Um die Gefahr von AMS zu verringern, sollten fleißige Übung und Überanstrengung sofort nach schnellem Aufstieg zur großen Höhe vermieden werden.
<G-vec00118-002-s605><decrease.verringern><en> To reduce CO2 emissions, it is therefore necessary to increase the fraction of surrogate fuels from biogenic sources and decrease the amount of fuel from fossil resources.
<G-vec00118-002-s605><decrease.verringern><de> Um den CO2-Ausstoß zu reduzieren, ist es daher notwendig, den Anteil von Ersatzbrennstoffen aus biogenen Quellen zu erhöhen und die Brennstoffmenge aus fossilen Ressourcen zu verringern.
<G-vec00118-002-s606><decrease.verringern><en> Sheath is made of woven nylon 6 fibers, to protect the inner core, decrease the overall abrasion, and to increase the strength.
<G-vec00118-002-s606><decrease.verringern><de> Die Hülle besteht aus gewebten Nylon-6-Fasern, um den inneren Kern zu schützen, den Gesamtabrieb zu verringern und die Festigkeit zu erhöhen.
<G-vec00118-002-s607><decrease.verringern><en> used to decrease problems due to a certain type of bleeding in the brain (subarachnoid hemorrhage).
<G-vec00118-002-s607><decrease.verringern><de> Nimotop verwendet, um Probleme wegen eines bestimmten Typs der Blutung im Gehirn (Subarachnoidalblutung) zu verringern.
<G-vec00118-002-s608><decrease.verringern><en> It is recommended to re-evaluate the selected antimicrobial regimen every 48–72 hours based on clinical and microbiological criteria in order to narrow the antimicrobial spectrum and thereby decrease the risk of resistance, toxicity and costs.
<G-vec00118-002-s608><decrease.verringern><de> Es wird empfohlen, das gewählte antimikrobielle Regime alle 48–72 Stunden anhand klinischer und mikrobiologischer Kriterien neu zu evaluieren, um das antimikrobielle Spektrum zu verengen und damit das Risiko von Resistenzen, die Toxizität und die Kosten zu verringern.
<G-vec00118-002-s609><decrease.verringern><en> Depending on the connected devices, some functions and display indications do not work. • When the temperature inside the unit rises, the volume may decrease momentarily.
<G-vec00118-002-s609><decrease.verringern><de> HINWEIS Wenn die Temperatur im Inneren des Geräts ansteigt, kann sich die Lautstärke kurzfristig verringern.
<G-vec00118-002-s610><decrease.verringern><en> After 4 weeks to six weeks you will begin to see an essential modification, then you may decrease the quantity of your dosage.
<G-vec00118-002-s610><decrease.verringern><de> Nach 4 Wochen bis sechs Wochen werden Sie beginnen eine wesentliche Änderung zu sehen, dann können Sie die Anzahl Ihrer Dosierung verringern.
<G-vec00118-002-s611><decrease.verringern><en> Human agency and oversight: AI systems should enable equitable societies by supporting human agency and fundamental rights, and not decrease, limit or misguide human autonomy.
<G-vec00118-002-s611><decrease.verringern><de> • Vorrang menschlichen Handelns und menschlicher Aufsicht: KI-Systeme sollten gerechten Gesellschaften dienen, indem sie das menschliche Handeln und die Wahrung der Grundrechte unterstützen‚ keinesfalls aber sollten sie die Autonomie der Menschen verringern, beschränken oder fehlleiten.
<G-vec00118-002-s612><decrease.verringern><en> Bet - This enables you to choose the value of the coin you want to bet by pressing the "+" sign to increase and the "-" sign to decrease the value.
<G-vec00118-002-s612><decrease.verringern><de> Wetten - Dies ermöglicht Ihnen, den Wert der Münze die Sie wollen durch drücken der "+" zeichen zu erhöhen und das "-" zeichen um den Wert der Münze zu verringern.
<G-vec00118-002-s613><decrease.verringern><en> During starvation, leptin levels markedly decrease, whilst increased leptin levels are observed in overfed and obese states.
<G-vec00118-002-s613><decrease.verringern><de> Während des Verhungerns verringern sich Leptinstände deutlich, während erhöhte Leptinstände in überfütterten und beleibten Zuständen beobachtet werden.
<G-vec00118-002-s614><decrease.verringern><en> You can also adjust the volume and decrease the echo effect.
<G-vec00118-002-s614><decrease.verringern><de> Sie können auch die Lautstärke anpassen oder den Halleffekt verringern.
<G-vec00118-002-s615><decrease.verringern><en> These changes decrease the efficacy of bowel excretory function and lead to further retention.
<G-vec00118-002-s615><decrease.verringern><de> Diese Veränderungen verringern die Effektivität der Darmausscheidung und führen zur weiteren Darmverhaltung.
<G-vec00118-002-s616><decrease.verringern><en> Symptoms should decrease within 30 to 40 days.
<G-vec00118-002-s616><decrease.verringern><de> Die Symptome sollen innerhalb von 30 bis 40 Tage verringern.
<G-vec00118-002-s617><decrease.verringern><en> You can increase or decrease the time period as per your recommendation.
<G-vec00118-002-s617><decrease.verringern><de> Sie können den Zeitraum entsprechend Ihrer Empfehlung erhöhen oder verringern.
<G-vec00118-002-s618><decrease.verringern><en> Please keep in mind that heavy (fat) meals and large amounts of alcohol can decrease Kamagra’s effect.
<G-vec00118-002-s618><decrease.verringern><de> Bitte beachten Sie, dass schwere (fettige) Mahlzeiten und große Mengen an Alkohol die Wirkung von Kamagra verringern können.
<G-vec00118-002-s619><decrease.verringern><en> If the second phase of the menstrual cycle is less than 10 days, the temperature rises near the end of the cycle and does not decrease before menstruation - this means a lack of progesterone.
<G-vec00118-002-s619><decrease.verringern><de> Wenn die zweite Phase des Menstruationszyklus von weniger als 10 Tagen, wobei die Temperatur gegen Ende des Zyklus erhöht wird und vor der Menstruation nicht verringert wird - bedeutet dies einen Mangel an Progesteron.
<G-vec00118-002-s620><decrease.verringern><en> Darker bottles are better, because exposing vitamin C to light will decrease its potency and oxidize it quickly, making it less effective.
<G-vec00118-002-s620><decrease.verringern><de> Dunklere Flaschen sind besser, weil die Stärke des Vitamin C's verringert wird und es schnell oxidiert, wenn es dem Licht ausgesetzt wird; dies verringert die Wirksamkeit.
<G-vec00118-002-s621><decrease.verringern><en> Also try not to use additional cabling; otherwise you are risking to decrease the quality of signal transmission, which will influence mobile connection.
<G-vec00118-002-s621><decrease.verringern><de> Versuchen Sie auch nicht, zusätzliche Verkabelungen zu verwenden; Ansonsten riskieren Sie die Qualität der Signalübertragung, das verringert wiederum die mobile Verbindung.
<G-vec00118-002-s622><decrease.verringern><en> 15 Signal Filter 1 To decrease the slightly shadowed images or characters p.
<G-vec00118-002-s622><decrease.verringern><de> Kissen-Balance — Einstellung des Movie-Modus S. 17 Signalfilter 1 Verringert leicht schattige Bilder oder Zeichen.
<G-vec00118-002-s623><decrease.verringern><en> Decrease/increase volume.
<G-vec00118-002-s623><decrease.verringern><de> Verringert/erhöht die Lautstärke.
<G-vec00118-002-s624><decrease.verringern><en> Pressing the upper end will increase the volume, and pressing the lower end will decrease it.
<G-vec00118-002-s624><decrease.verringern><de> Ein Druck auf das obere Ende erhöht die Lautstärke, ein Druck auf das untere Ende verringert sie entsprechend.
<G-vec00118-002-s625><decrease.verringern><en> The ‘multiplicative’ cooperation of causal factors thus not merely fails to decrease, but increases total responsibility.
<G-vec00118-002-s625><decrease.verringern><de> Durch das „multiplikative“ Zusammenwirken von Kausalfaktoren wird die Gesamtverantwortung nicht nur nicht verringert, sondern im Gegenteil sogar vergrößert.
<G-vec00118-002-s626><decrease.verringern><en> Decrease the ATK and DEF of a monster equipped with this card by 500 points.
<G-vec00118-002-s626><decrease.verringern><de> Diese Karte verringert die ATK und DEF des Monsters um 500 Punkte.
<G-vec00118-002-s627><decrease.verringern><en> By comparing the measured value with the level setpoint entered by the customer, the controller dictates the valve to increase or decrease the liquid flow to or from the reservoir.
<G-vec00118-002-s627><decrease.verringern><de> Durch den Vergleich vom Messwert mit dem Sollwert, der vom Kunden eingegeben wird, bestimmt der Regler, ob der Ventil den Flüssigkeitsstrom in oder aus dem Behälter erhöht oder verringert.
<G-vec00118-002-s628><decrease.verringern><en> Taking it with food may decrease its bioavailability.
<G-vec00118-002-s628><decrease.verringern><de> Das Nehmen er mit Nahrung verringert möglicherweise seine Lebenskraft.
<G-vec00118-002-s629><decrease.verringern><en> There has always been an important deal in banned (illegal) steroid, decrease in their use as a result of the lot of adverse reactions that they can always trigger.
<G-vec00118-002-s629><decrease.verringern><de> Es ist schon immer ein wichtiger Teil in verboten (illegaler) Steroid gewesen, verringert in ihrer Verwendung als Folge der vielen Nebenwirkungen, die sie immer auslösen können.
<G-vec00118-002-s630><decrease.verringern><en> It is common to count on a substitution rate of 0.5 – 0.8kg DM, which means that for each kg DM of concentrate you decrease, the roughage intake is increased by 0.5 – 0.8kg DM.
<G-vec00118-002-s630><decrease.verringern><de> Gewöhnlich rechnet man mit einer Substitutionsrate von 0,5-0,8kg TM, d.h. dass für jedes Kilo TM Konzentrat, das man verringert, die Raufutteraufnahme um 0,5-0,8kg TM steigt.
<G-vec00118-002-s631><decrease.verringern><en> The main reason is that AlN particle has poor wettability with Cu at high temperature, which obstructs the flowing liquid copper and causes the segregation and density decrease.
<G-vec00118-002-s631><decrease.verringern><de> Der Hauptgrund dafür ist, dass AlN-Partikel eine schlechte Benetzbarkeit mit Cu bei hoher Temperatur aufweisen, was das fließende flüssige Kupfer behindert und die Segregation und Dichte verringert.
<G-vec00118-002-s632><decrease.verringern><en> Because the narrowed arteries may no longer supply enough blood for normal-sized kidneys, kidney size may decrease.
<G-vec00118-002-s632><decrease.verringern><de> Da die verengten Arterien normal große Nieren möglicherweise nicht mehr ausreichend mit Blut versorgen können, verringert sich die Größe der Nieren unter Umständen.
<G-vec00118-002-s633><decrease.verringern><en> It means that depending on the type of PCB that you require, the price will increase or decrease.
<G-vec00118-002-s633><decrease.verringern><de> Dies bedeutet, dass sich der Preis je nach Art der von Ihnen benötigten Leiterplatte erhöht oder verringert.
<G-vec00118-002-s634><decrease.verringern><en> 2 (15) in mix/mono operation 20 Plug for connecting the earphones to the corresponding jack (24) 21 Button + for selecting a menu item, for switching over a function, or for increasing a value in the adjusting menu; when the button is kept pressed, the value will increase continuously 22 Button - for selecting a menu item, for switching over a function, or for decreasing a value in the adjusting menu; when the button is kept pressed, the value will decrease continuously 23 LC display (chapter 1.3) mm stereo jack for connecting the earphones supplied 25 Belt clip 26 Button SET for calling the adjusting menu, for confirming the menu item selected, and for confirming the adjustments made 27 Unlatching device for the battery compartment; for unlatching, see fig.
<G-vec00118-002-s634><decrease.verringern><de> 2 (15) im Mix/Mono-Betrieb 20 Stecker der Ohrhörer zum Anschluss an die Ohrhörerbuchse (24) 21 Taste + zur Anwahl eines Menüpunktes, zum Umschalten einer Funktion oder zum Erhöhen eines Wertes im Einstellmenü; bei gedrückt gehaltener Taste erhöht sich der Wert kontinuierlich 22 Taste - zur Anwahl eines Menüpunktes, zum Umschalten einer Funktion oder zum Verringern eines Wertes im Einstellmenü; bei gedrückt gehaltener Taste verringert sich der Wert kontinuierlich 23 LC-Display (Kapitel 1.3) 24 3,5-mm-Stereo-Klinkenbuchse zum Anschluss der beiliegenden Ohrhörer 25 Gürtelklemme 26 Taste SET zum Aufrufen des Einstellmenüs, zur Bestätigung eines angewählten Menüpunktes und zur Bestätigung durchgeführter Einstellungen 27 Entriegelung für das Batteriefach; Handhabung siehe Abb.
<G-vec00118-002-s635><decrease.verringern><en> Whereas, in a study conducted in 2016 it was concluded that it actually does decrease the frequency of migraine attacks that are experienced.
<G-vec00118-002-s635><decrease.verringern><de> In einer Studie aus dem Jahr 2016 wurde festgestellt, dass die Häufigkeit von Migräneanfällen tatsächlich verringert werden könnte.
<G-vec00118-002-s636><decrease.verringern><en> + and - - Increase or decrease the number of spins played in the auto spin mode
<G-vec00118-002-s636><decrease.verringern><de> + und - – Erhöht oder verringert die Anzahl der Runden, die im Auto-Spin-Modus gespielt werden.
<G-vec00118-002-s637><decrease.verringern><en> By the way: during the life-time of your battery, which encompasses 800 or more load cycles, the battery‘s capacity will inevitably decrease.
<G-vec00118-002-s637><decrease.verringern><de> Übrigens: Im Laufe eines Akku-Lebens von 800 oder mehr Ladezyklen verringert sich zwangsläufig die Aufnahmekapazität an Energie.
