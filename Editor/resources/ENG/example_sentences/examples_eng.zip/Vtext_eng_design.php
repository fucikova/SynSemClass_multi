<G-vec00040-002-s190><design.entwerfen><en> We are confident that we can create a system that is tightly scoped to our needs that will not be complex to design, build and deploy.
<G-vec00040-002-s190><design.entwerfen><de> Wir sind zuversichtlich, dass wir ein System erschaffen können, welches sich fest an unsere Bedingungen anpasst und dabei einfach zu entwerfen, bauen und einzusetzen ist.
<G-vec00040-002-s191><design.entwerfen><en> Important: If you are a software developer, you can use this procedure to install or remove an automation program before you design installation and removal programs for your add-in.
<G-vec00040-002-s191><design.entwerfen><de> Wichtig: Wenn Sie Softwareentwickler sind, können Sie dieses Verfahren zum Installieren oder deinstallieren ein Automatisierungsprogramm, bevor Sie die Installation entwerfen und Programme zum Entfernen für Ihr Add-in verwenden.
<G-vec00040-002-s192><design.entwerfen><en> Goal of this thesis is to design a protection circuit which is capable of protecting the electronic sources and sinks against various errors.
<G-vec00040-002-s192><design.entwerfen><de> Ziel dieser Aufgabe ist es daher eine Schutzschaltung zu entwerfen, welche die elektronischen Geräte im Teststand vor verschiedenen Fehlern schützen soll.
<G-vec00040-002-s193><design.entwerfen><en> To design innovative products that are easy to manufacture, of quality and at the best cost while reducing development time, Vignal Group generalizes the organization into Project Teams and the simultaneous study of products and processes.
<G-vec00040-002-s193><design.entwerfen><de> Um innovative Produkte zu entwerfen, die einfach herzustellen, von hoher Qualität und kostenoptimiert sind und gleichzeitig die Entwicklungszeiten verkürzen, hat die Vignal Group die Organisation in Projektteams und die gleichzeitige Untersuchung von Produkten und Prozessen verallgemeinert.
<G-vec00040-002-s194><design.entwerfen><en> Consequently, teaching at the Associate Professorship of Architectural Design and Conservation concentrates exclusively on projects for the conversion, adaptation and renovation of existing built substance.
<G-vec00040-002-s194><design.entwerfen><de> Vor diesem Hintergrund bearbeiten die Studenten an der Professur für Entwerfen, Umbau und Denkmalpflege ausschließlich Projekte bei denen es um Umbau, Anpassung im Bestand und Sanierung geht.
<G-vec00040-002-s195><design.entwerfen><en> Though parametric design is still in its infancy, there is already greater collaboration.
<G-vec00040-002-s195><design.entwerfen><de> Zwar steckt das parametrische Entwerfen noch in ihren Anfängen, doch schreitet die verstärkte Zusammenarbeit bereits gut voran.
<G-vec00040-002-s196><design.entwerfen><en> Jeans Specifications:1) Composition: 75% cotton, 22% polyester, 3% spandex2) Weight: 11oz.3) Finish: enzyme grinding, sand spraying, and washing4) We can design and produce any styles of garments according
<G-vec00040-002-s196><design.entwerfen><de> 3) Finish: Enzym Schleifen, Sand-Spritzen, Waschen und 4) Wir entwerfen und produzieren alle Arten Jeans Technische Daten: 1) Zusammensetzung: 75% Baumwolle, 22% Polyester, 3% Elasthan 2) Gewicht: 11oz.
<G-vec00040-002-s197><design.entwerfen><en> We can help you to design shop interior design and hardware accessory in your store, including cabinet, wall board, cash counter, display stand, fitting room if you supply the dimension.
<G-vec00040-002-s197><design.entwerfen><de> Wir können Ihnen helfen, Innenarchitektur des Geschäftes und Hardware-Zusatz in Ihrem Speicher, einschließlich Schrank zu entwerfen, Wandbrett, Zahlschalter, Ausstellungsstand, passender Raum, wenn Sie das Maß liefern.
<G-vec00040-002-s198><design.entwerfen><en> Set your strategy: Design a detailed vision of the customer experience you want.
<G-vec00040-002-s198><design.entwerfen><de> Legen Sie Ihre Strategie fest: Entwerfen Sie eine detaillierte Vision der gewünschten Customer Experience.
<G-vec00040-002-s199><design.entwerfen><en> Messages that originate from the report server and reports that you design in Report Designer are available only in the languages supported by SQL Server 2012.
<G-vec00040-002-s199><design.entwerfen><de> Meldungen, die vom Berichtsserver stammen, und Berichte, die Sie im Berichts-Designer entwerfen, stehen nur in den von SQL Server 2012 unterstützten Sprachen zur Verfügung.
<G-vec00040-002-s200><design.entwerfen><en> We design, develop and manufacture the panels in Denmark – from local materials and under state-of-the-art and eco-friendly conditions.
<G-vec00040-002-s200><design.entwerfen><de> Wir entwerfen, entwickeln und produzieren die Platten in Dänemark aus lokalen Rohstoffen sowie unter hochmodernen und umweltfreundlichen Bedingungen.
<G-vec00040-002-s201><design.entwerfen><en> We work closely with you and your employees to design a tailored solution.
<G-vec00040-002-s201><design.entwerfen><de> In enger Zusammenarbeit mit Ihnen und Ihren Mitarbeitenden entwerfen wir ein für Sie massgeschneidertes Angebot.
<G-vec00040-002-s202><design.entwerfen><en> Together we will look for the best solution for your situation and we will look into all possibilities to design the perfect slide.
<G-vec00040-002-s202><design.entwerfen><de> Gemeinsam suchen wir die beste Lösung für Ihr Projekt und entwerfen wir die passende Rutschbahn für Sie.
<G-vec00040-002-s203><design.entwerfen><en> RCDC Perform robust concrete design and analysis of columns, beams, walls, and floors in compliance with global design standards. Learn More
<G-vec00040-002-s203><design.entwerfen><de> RCDC Realisieren Sie robuste Betonkonstruktionen und analysieren Sie Säulen, Balken, Wände und Entwerfen Sie nahezu beliebige Fundamente, von einfachen Gründungen bis hin zu höchst komplexen Fundamenten.
<G-vec00040-002-s204><design.entwerfen><en> The results of the focus group discussions show a strong interest in using the three-dimensional space as a medium for conceptual design.
<G-vec00040-002-s204><design.entwerfen><de> Die Ergebnisse der Fokusgruppe zeigten ein starkes Interesse der avisierten Nutzer am Gebrauch des dreidimensionalen Raums als eines Mediums für das konzeptionelle Entwerfen.
<G-vec00040-002-s205><design.entwerfen><en> We are creative, we shape technology, we design products, we improve methods, we break new paths.
<G-vec00040-002-s205><design.entwerfen><de> Wir sind kreativ, wir gestalten Technik, wir entwerfen Produkte, wir verbessern Verfahren, wir eröffnen neue Wege.
<G-vec00040-002-s206><design.entwerfen><en> What's more, our free tools allowed their graphic designer to easily design an annual report that's as modern and provocative as the brand itself.
<G-vec00040-002-s206><design.entwerfen><de> Außerdem konnten die Grafiker unsere kostenlosen Tools nutzen, um problemlos einen Jahresbericht zu entwerfen, der ebenso trendig und provokant ist wie die Marke.
<G-vec00040-002-s207><design.entwerfen><en> Since is creation, Bergerault S.A has taken the greatest care in choosing the best raw material to design all his instruments.
<G-vec00040-002-s207><design.entwerfen><de> Von Anfang an hat Bergerault S.A. mit größter Sorgfalt stets nur die besten Materialien ausgewählt, um die Instrumente zu entwerfen.
<G-vec00040-002-s208><design.entwerfen><en> We create and design unique and custom made pieces .
<G-vec00040-002-s208><design.entwerfen><de> Wir kreieren und entwerfen einzigartige und maßgefertigte Stücke.
<G-vec00040-002-s209><design.entwickeln><en> Since original parts - even used - are no longer available we decided to design a new PTO for Toyota vehicles.
<G-vec00040-002-s209><design.entwickeln><de> Nachdem Originalteile auch gebraucht nicht mehr erhältlich sind, haben wir uns entschlossen, einen PTO für den symmetrischen Toyota 6-Loch-Flansch zu entwickeln.
<G-vec00040-002-s210><design.entwickeln><en> If equipment or projects require specific and customized protection, Pelican has a team of engineers and partners to design, produce, and test the perfect transportation and packaging solution.
<G-vec00040-002-s210><design.entwickeln><de> Wenn Geräte oder Projekte einen spezifischen und maßgefertigten Schutz benötigen, hat Pelican ein Team mit Ingenieuren und Partnern, die die perfekte Transport- und Verpackungslösung entwickeln, fertigen und testen.
<G-vec00040-002-s211><design.entwickeln><en> We partner with you to design, deploy, support, optimize and manage a solution that delivers a superior experience in every workspace with an easy to use and consistent workflow.
<G-vec00040-002-s211><design.entwickeln><de> Wir arbeiten mit Ihnen zusammen, um gemeinsam eine Lösung zu entwickeln, bereitzustellen, zu unterstützen, zu optimieren und zu verwalten, die mit einem benutzerfreundlichen und konsistenten Arbeitsablauf an jedem Arbeitsplatz für ein überragendes Nutzererlebnis sorgt.
<G-vec00040-002-s212><design.entwickeln><en> Do not forget to share and love our reference to help further Bar Top Design Ideas
<G-vec00040-002-s212><design.entwickeln><de> Vergessen Sie nicht, unsere Referenz zu teilen und zu lieben, um unsere Website weiter zu entwickeln.
<G-vec00040-002-s213><design.entwickeln><en> If you are a fan of roller coasters, with RollerCoaster Tycoon you have the opportunity to design your own amusement park.
<G-vec00040-002-s213><design.entwickeln><de> Wenn Sie gern Achterbahn fahren, haben Sie mit RollerCoaster Tycoon die Möglichkeit, Ihren eigenen Vergnügungspark zu entwickeln.
<G-vec00040-002-s214><design.entwickeln><en> We design wires for wide variety of welding applications.
<G-vec00040-002-s214><design.entwickeln><de> Wir entwickeln Drähte für eine Vielzahl von Schweißanwendungen.
<G-vec00040-002-s215><design.entwickeln><en> To give our customers a competitive advantage, we design more efficient, lighter, more connected solutions.
<G-vec00040-002-s215><design.entwickeln><de> Um unseren Kunden auf dem Markt einen Wettbewerbsvorteil zu verschaffen, entwickeln wir Lösungen, die leistungsfähiger, von geringerem Gewicht und stärker vernetzt sind.
<G-vec00040-002-s216><design.entwickeln><en> So, we take the time to understand your workloads and business goals to design an optimized solution that gets you to results, faster.
<G-vec00040-002-s216><design.entwickeln><de> Deshalb nehmen wir uns die Zeit, Ihre Workloads und Geschäftsziele zu verstehen, und entwickeln eine optimierte Lösung, mit der Sie Ihre Ziele schneller erreichen.
<G-vec00040-002-s217><design.entwickeln><en> RSA always acts in the best interest of its customers and under no circumstances does RSA design or enable any backdoors in our products.
<G-vec00040-002-s217><design.entwickeln><de> RSA handelt stets im besten Interesse unserer Kunden und unter keinen Umständen würde RSA Hintertüren für unsere Produkte entwickeln oder aktivieren.
<G-vec00040-002-s218><design.entwickeln><en> In addition we design and build entire shops, from the idea to the completion. Development of branded displays, with special and individual design, is also a service from concept-s.
<G-vec00040-002-s218><design.entwickeln><de> Wir planen und realisieren zusätzlich komplette Objekte vom Entwurf bis zur Fertigstellung, darüber hinaus entwickeln wir spezielle und individuelle Markendisplays.
<G-vec00040-002-s219><design.entwickeln><en> Although the actual production of power electronic modules may be low in the US, it is a clear target market for the applications of these power modules, which in the end helps us to design new solutions to meet those needs.
<G-vec00040-002-s219><design.entwickeln><de> Auch wenn die tatsächliche Produktion von Leistungselektronikmodulen in den USA gering sein mag, so ist sie doch ein klarer Zielmarkt für die Anwendungen dieser Leistungsmodule, was uns letztlich hilft, neue Lösungen zu entwickeln, die dessen Bedürfnissen gerecht werden.
<G-vec00040-002-s220><design.entwickeln><en> SOLIDWORKS Student Edition lets you sharpen your skills outside the classroom as you learn to design better products.
<G-vec00040-002-s220><design.entwickeln><de> Die einfach zu verwendenden SOLIDWORKS Student Edition lässt Sie zudem Ihre Konstruktionsfähigkeiten verbessern und ermöglicht Ihnen so, bessere Produkte zu entwickeln.
<G-vec00040-002-s221><design.entwickeln><en> No matter how big or small your project, we can design and implement customized systems and solutions, resulting in a complete research or phytotron facility completely in tune with your most stringent requirements.
<G-vec00040-002-s221><design.entwickeln><de> Egal wie groß oder klein Ihr Projekt ist, wir entwickeln und bauen individuelle Systeme und Lösungen und liefern Ihnen komplette Forschungs- oder Phytotronanlagen, die Ihren hohen Ansprüchen bis ins kleinste Detail gerecht werden.
<G-vec00040-002-s222><design.entwickeln><en> They design and manufacture all their products in Italy with their hand-picked team of experts.
<G-vec00040-002-s222><design.entwickeln><de> Sie entwickeln und fertigen ihre Produkte in Italien mit ihrer handverlesenen Team von Experten.
<G-vec00040-002-s223><design.entwickeln><en> We will design one just for you.
<G-vec00040-002-s223><design.entwickeln><de> Wir entwickeln maßgeschneiderte Lösungen für Sie.
<G-vec00040-002-s224><design.entwickeln><en> Cradle to Cradle® Vision: Since 2008, we have maintained our focus on having all our products designed according to the Cradle to Cradle design principles by 2020.
<G-vec00040-002-s224><design.entwickeln><de> Cradle to Cradle®-Vision: Seit 2008 setzen wir alles daran, unsere gesamte Produktpalette bis zum Jahr 2020 nach den Cradle to Cradle®-Designprinzipien zu entwickeln.
<G-vec00040-002-s225><design.entwickeln><en> They asked us to design an alternative – a temporary, large-capacity system that would keep the produce in perfect condition during the harvest, which we could then dismantle and take away, saving costs for the rest of the year. Project fact file
<G-vec00040-002-s225><design.entwickeln><de> Wir wurden beauftragt, eine Alternative zu entwickeln – ein temporäres System mit großer Kapazität, das die Früchte während der Ernte in einem perfekten Zustand halten, und das wir dann wieder abbauen und einlagern würden, um Kosten für den Rest des Jahres einzusparen.
<G-vec00040-002-s226><design.entwickeln><en> The topic of system integration was particularly interesting to partners that design vehicles beyond just bicycles for professional use.
<G-vec00040-002-s226><design.entwickeln><de> Das Thema Systemintegration war besonders interessant für Partner, die Fahrzeuge über das Fahrrad hinaus für den professionellen Einsatz entwickeln.
<G-vec00040-002-s227><design.entwickeln><en> Whatever way Adobe will go with Experience Design, the other tools will also move towards support for collaborative working, which is not yet fully implemented in any visual design tool.
<G-vec00040-002-s227><design.entwickeln><de> Unabhängig von Adobe werden sich auch die anderen Tools zunehmend in die Richtung des kollaborativen Arbeitens entwickeln, denn diese Funktion unterstützt bisher noch kein Visual-Design-Werkzeug vollständig.
<G-vec00040-002-s266><design.gestalten><en> You can also design your flyer with images much smaller than the recommended sizes and place them Of course not.
<G-vec00040-002-s266><design.gestalten><de> Du kannst Deine Fotokarten auch mit Bildern gestalten, die deutlich kleiner sind als die empfohlenen Größen und diese an beliebigen Stellen auf den Fotokarten platzieren.
<G-vec00040-002-s267><design.gestalten><en> and design processes using RFID / NFC / Auto-ID.
<G-vec00040-002-s267><design.gestalten><de> Wir optimieren und gestalten Prozesse mit Hilfe von RFID / NFC / Auto-ID.
<G-vec00040-002-s268><design.gestalten><en> Click HERE to create your own souvenir key tag design
<G-vec00040-002-s268><design.gestalten><de> Klicken Sie HIER, um Ihren eigenen Souvenir-Acrylschlüsselanhänger zu gestalten.
<G-vec00040-002-s269><design.gestalten><en> We also offer conference facilities in various configurations, design themes and sizes to accommodate your needs.
<G-vec00040-002-s269><design.gestalten><de> Außerdem bieten wir Konferenzräume in verschiedenen Konfigurationen, gestalten Themen und Größe nach Ihren Bedürfnissen.
<G-vec00040-002-s270><design.gestalten><en> • Step 1: Design and print out album page.
<G-vec00040-002-s270><design.gestalten><de> • Schritt 1: Albumseite gestalten und ausdrucken.
<G-vec00040-002-s271><design.gestalten><en> TOTO is leading the way in terms of technological developments in attractive and convenient product design.
<G-vec00040-002-s271><design.gestalten><de> Toto treibt technologische Entwicklungen voran, um Produkte noch angenehmer und komfortabler zu gestalten.
<G-vec00040-002-s272><design.gestalten><en> Although we love to upload stories spontaneously, we also take a lot of time to design them, just as we do for editing our Instagram feed photos.
<G-vec00040-002-s272><design.gestalten><de> Obwohl wir es lieben, auch mal Stories spontan hochzuladen, nehmen wir uns – genauso wie für die Bearbeitung unserer Instagram Feed Fotos – sehr viel Zeit, diese zu gestalten.
<G-vec00040-002-s273><design.gestalten><en> With Colibrico Design Studio, you automate the creation of icon sets and design icons in your desired colors.
<G-vec00040-002-s273><design.gestalten><de> Mit Colibrico Design Studio automatisieren Sie die Erstellung von Icon Sets und gestalten Icons in Ihren Wunschfarben.
<G-vec00040-002-s274><design.gestalten><en> If you are accidentally attempting to design or use a form template without having the access privileges to do so, you will be informed by a system message.
<G-vec00040-002-s274><design.gestalten><de> Wenn Sie irrtümlich eine Formularvorlage gestalten oder verwenden wollen, für die Sie keine Zugriffsrechte haben, dann werden Sie in einer Systemmeldung informiert.
<G-vec00040-002-s275><design.gestalten><en> Shop policies "Night Wanderer" Digital Stamp design by Ching-Chou Kuik.
<G-vec00040-002-s275><design.gestalten><de> "Blütenblätter des Regenbogens" digitale Briefmarke gestalten von Ching-Chou Kuik.
<G-vec00040-002-s276><design.gestalten><en> We endeavour to use optimum raw materials and intermediate products and design our products so that they can be recycled to the greatest possible extent after use and contribute to the reduction of energy consumption when used by our customers.
<G-vec00040-002-s276><design.gestalten><de> Wir streben nach Einsatz von optimalen Rohstoffen und Zwischenprodukten und gestalten unsere Produkte so, dass sie nach Gebrauch im größtmöglichen Umfang einer Verwertung zugeführt werden können und im Einsatz bei unseren Kunden dazu beitragen, den Verbrauch von Energieressourcen zu reduzieren.
<G-vec00040-002-s277><design.gestalten><en> His last blueprint was aimed at the optimum design of the thermal behavior of the façades and the way daylight entered the building.
<G-vec00040-002-s277><design.gestalten><de> Sein letzter Entwurf zielte darauf ab, das thermische Verhalten der Fassaden und den Tageslichteinfall optimal zu gestalten.
<G-vec00040-002-s278><design.gestalten><en> Whether as a voucher for an overnight stay at the hotel, a romantic candle light dinner (or both!), or a treat for the whole family, we will design and pack your gift with love and care.
<G-vec00040-002-s278><design.gestalten><de> Ganz gleich ob eine Übernachtung im Hotel, einen Abend zu Zweit bei Candlelight & Menü oder beides als Arrangement kombiniert, wir gestalten und verpacken Ihre Geschenkidee mit Liebe.
<G-vec00040-002-s279><design.gestalten><en> We design and create your Corporate Design and care for a uniform appearance of your company, including prospectus material, letters, and business cards, according to your wishes.
<G-vec00040-002-s279><design.gestalten><de> Wir gestalten und kreieren Ihr Firmenlogo (Corporate Design) für Sie neu und sorgen für ein einheitliches Erscheinungsbild Ihres Unternehmens inklusive Prospektmaterial, Briefschaft, Visitenkarten gemäß Ihren Wünschen.
<G-vec00040-002-s280><design.gestalten><en> Plan Presto - Design your business Model using the business model canvas.
<G-vec00040-002-s280><design.gestalten><de> Plan Presto - Gestalten Sie Ihr Geschäftsmodell mit dem Geschäftsmodell Leinwand.
<G-vec00040-002-s281><design.gestalten><en> We design logistics processes so that they are immediately interrupted if there is an error and they can only continue when the employee has corrected the error.
<G-vec00040-002-s281><design.gestalten><de> Logistische Prozesse gestalten wir so, dass der Ablauf im Falle eines Fehlers unmittelbar unterbrochen wird und erst weitergeht, wenn Ihr Mitarbeiter den Fehler korrigiert hat.
<G-vec00040-002-s282><design.gestalten><en> In this process, the design philosophy of sensuous clarity that formally defines modern luxury plays an important role.
<G-vec00040-002-s282><design.gestalten><de> Mit dieser Philosophie gestalten die Designer nicht nur Automobile sondern eine ganze Welt des modernen Luxus.
<G-vec00040-002-s283><design.gestalten><en> Design your home according to these premises with a high-quality canvas picture in green by Lana KK®.
<G-vec00040-002-s283><design.gestalten><de> Gestalten Sie Ihr Zuhause nach diesen Prämissen mit einem hochwertigen Leinwandbild in Grün von Lana KK.
<G-vec00040-002-s284><design.gestalten><en> In this course, the meaning of social work in and with groups and teams as a goal oriented instrument for individual learning, and for the design of social learning processes will be communicated.
<G-vec00040-002-s284><design.gestalten><de> Lehrinhalte In dieser Lehrveranstaltung wird die Bedeutung der Sozialen Arbeit in und mit Gruppen und Teams als zielgerichtetesInstrumentarium für individuelles Lernen, für das Gestalten sozialer Lernprozesse vermittelt.
<G-vec00040-002-s285><design.gestalten><en> Our in-house Home Styling Team design all our products to ensure the highest quality and the best style.
<G-vec00040-002-s285><design.gestalten><de> Unser PartyLite Style Team gestaltet alle unsere Produkte, um höchste Qualität und stilsicheres Design zu garantieren.
<G-vec00040-002-s286><design.gestalten><en> Featuring Italian design freestanding bathtubs, the large bathroom boasts Carrara marble or mosaic flooring and antique mirrors.
<G-vec00040-002-s286><design.gestalten><de> Die Bäder sind mit Carrara-Marmor oder Mosaikböden und antiken Spiegeln gestaltet.
<G-vec00040-002-s287><design.gestalten><en> The house has an open design and consists of a large living/dining area with an open fireplace as well as a fully fitted open kitchen.
<G-vec00040-002-s287><design.gestalten><de> Das Haus ist sehr offen gestaltet und besteht aus dem großen Wohn / Esszimmer mit offenem Kamin sowie einer kompletten, ebenfalls offenen Küche.
<G-vec00040-002-s288><design.gestalten><en> Edwin Lowe Ltd is the first company internationally to commercially design and develop the first practical prefabricated roller bearing housing assembly, for welded steel conveyor rollers.
<G-vec00040-002-s288><design.gestalten><de> Kürzere Lieferzeiten Geringerer Kostenaufwand Bei der Edwin Lowe Ltd handelt es sich um das erste Unternehmen weltweit, das praktische, vorgefertigte Lagergehäuse (Patronen) kommerziell für Schweißstahl-Förderbandrollen gestaltet und entwickelt.
<G-vec00040-002-s289><design.gestalten><en> In line with tradition, as Artist in Residence he will also design a chamber music evening with musicians from the orchestra, with works by Debussy, Ravel and Schumann.
<G-vec00040-002-s289><design.gestalten><de> Wie seine Vorgänger als Artist in Residence gestaltet auch Thibaudet gemeinsam mit Musikerinnen und Musikern aus dem Orchester als weiteren Saisonhöhepunkt einen Abend mit Kammermusik.
<G-vec00040-002-s290><design.gestalten><en> The car is missing turn signal mountings on the fenders. They had very special design and are now to be reconstructed by means of 3D scanning and reverse engineering.
<G-vec00040-002-s290><design.gestalten><de> Hier fehlen an den Kotflügeln die Blinkerhalterungen, die sehr schmuckvoll gestaltet waren und nun mittels Scan und Reverse Engineering rekonstruiert werden sollen.
<G-vec00040-002-s291><design.gestalten><en> Based on the technical specification and the user map, an app design is created, each element of which is carefully worked out both as a separate detail and as a part of the overall creative concept.
<G-vec00040-002-s291><design.gestalten><de> Erstellen eines Designkonzepts Auf Basis der technischen Aufgabenstellung und der Sitemap wird ein App-Design erstellt, wobei jedes Element sowohl im einzelnen als auch im kreativen Gesamtkonzept akribisch gestaltet wird.
<G-vec00040-002-s292><design.gestalten><en> Via the design template package you can design content even faster and more attractive.
<G-vec00040-002-s292><design.gestalten><de> Durch das Designvorlagenpaket können Ihre Inhalte noch schneller und schöner gestaltet werden.
<G-vec00040-002-s293><design.gestalten><en> They make every model into a special timepiece, independent of the design of the watch face.
<G-vec00040-002-s293><design.gestalten><de> Sie machen jedes dieser Modelle zu einem ganz besonderen Zeitmesser, unabhängig davon, wie das Zifferblatt gestaltet wurde.
<G-vec00040-002-s294><design.gestalten><en> All hotel rooms enjoy an artistic design and are equipped with solid wooden furniture.
<G-vec00040-002-s294><design.gestalten><de> Alle Hotelzimmer sind mit Massivholzmöbeln ausgestattet und wurden von Künstlern gestaltet.
<G-vec00040-002-s295><design.gestalten><en> This project – although only small – showed that a simple utility building can fit aesthetically into its immediate surroundings with just a small amount of carefully applied design flair.
<G-vec00040-002-s295><design.gestalten><de> So zeigt sich bei diesem – wenn auch kleinen Projekt –, dass mit wenigen sinnvoll eingesetzten Gestaltungsmitteln auch ein Gebäude ästhetisch dem örtlichen Umfeld entsprechend gestaltet werden kann.
<G-vec00040-002-s296><design.gestalten><en> Featuring Creole design, the accommodation will provide you with a TV, air conditioning, ceiling fan and a furnished verandah.
<G-vec00040-002-s296><design.gestalten><de> Die Unterkunft ist im kreolischen Stil gestaltet und bietet Ihnen einen TV, eine Klimaanlage, einen Deckenventilator und eine möblierte Veranda.
<G-vec00040-002-s297><design.gestalten><en> The floors and seat cushions represent the coloured aspects, while the white side walls and grey handrails have a more subtle design.
<G-vec00040-002-s297><design.gestalten><de> Boden und Sitzpolster setzen die Farbakzente während die Seitenwände in Weiß und die Haltestangen in grau eher dezent gestaltet sind.
<G-vec00040-002-s298><design.gestalten><en> This baby two-piece with lovely design offers high wearing comfort.
<G-vec00040-002-s298><design.gestalten><de> Der Baby Zweiteiler ist liebevoll gestaltet und überzeugt mit hohem Tragekomfort.
<G-vec00040-002-s299><design.gestalten><en> Along with the sophisticated classic design, all premium rooms consist of double glazed floor to ceiling windows offering natural light overlooking the City Botanic Gardens.
<G-vec00040-002-s299><design.gestalten><de> Die Premium Zimmer sind alle klassisch-elegant gestaltet und bieten raumhohe Doppelglasfenster, durch die viel Tageslicht fällt und die eine Aussicht auf den Botanischen Garten der Stadt bieten.
<G-vec00040-002-s300><design.gestalten><en> The exterior design of the ŠKODA VisionS reflects the brand’s new emotional appeal: All the edges and lines are clear, precise and sharp; crystalline design elements accentuate the exterior.
<G-vec00040-002-s300><design.gestalten><de> Das Außendesign des ŠKODA VisionS spiegelt die neue emotionale Ausstrahlung der Marke wider: Alle Kanten und Schnitte sind klar, präzise und scharf gestaltet.
<G-vec00040-002-s301><design.gestalten><en> While the Field type and formatting are different in Design View, the concepts are the same as in the Wizard.
<G-vec00040-002-s301><design.gestalten><de> Während das Feld und die Formatierung in der Entwurfsansicht anders gestaltet sind, sind die Konzepte die gleichen wie im Assistenten.
<G-vec00040-002-s302><design.gestalten><en> The opening at the bottom of the perforated fabric gives you easy access to the inside of the bag, allowing you to create your own design by embroidering the perforated outer material.
<G-vec00040-002-s302><design.gestalten><de> Die Öffnung an der Unterseite des gelochten Aussenmaterials bietet leichten Zugriff zur Innenseite, wordurch das gelochte Aussenmaterial bestickt und der Beutel damit selbst gestaltet werden kann.
<G-vec00040-002-s303><design.gestalten><en> However, the design of this school is more traditional than the aforementioned Vesna, mainly due to the plot and limited resources.
<G-vec00040-002-s303><design.gestalten><de> Das letztendlich realisierte Gebäude wurde jedoch in Hinblick auf die Parzelle und die begrenzten finanziellen Möglichkeiten der Stadt auf traditionellere Art als die erwähnte ältere Vesna-Schule gestaltet.
<G-vec00040-002-s361><design.konzipieren><en> We design systems from a single source and cover all areas of paper manufacturing.
<G-vec00040-002-s361><design.konzipieren><de> Wir konzipieren Anlagen aus einer Hand und decken alle Bereiche der Papierherstellung ab.
<G-vec00040-002-s362><design.konzipieren><en> We support payers, providers and companies in the healthcare industry in their digitization strategies, design and develop digital products and services and assist in the transformation from existing analog to digital-based processes.
<G-vec00040-002-s362><design.konzipieren><de> Wir unterstützen Kostenträger, Leistungserbringer und Unternehmen in der Gesundheitswirtschaft in ihren Digitalisierungsstrategien, konzipieren und entwickeln digitale Produkte sowie Services und helfen bei der Transformation von existierenden analogen in digital gestützte Prozesse.
<G-vec00040-002-s363><design.konzipieren><en> Our many years of experience enable us to offer highly specialised individual solutions that we will be happy to design, produce and assemble in accordance with your ideas and conceptions.
<G-vec00040-002-s363><design.konzipieren><de> Auf Grund unserer langjährigen Erfahrungen können wir Ihnen auch hochspezielle Individuallösungen anbieten, die wir entsprechend Ihrer Ideen und Vorstellungen gern für Sie konzipieren, produzieren und montieren.
<G-vec00040-002-s364><design.konzipieren><en> We’ll design a solution that’s perfect for your application.
<G-vec00040-002-s364><design.konzipieren><de> Und wir konzipieren für Ihren Anwendungsfall die optimale Lösung.
<G-vec00040-002-s365><design.konzipieren><en> Framery allows you to design your pod.
<G-vec00040-002-s365><design.konzipieren><de> Framery bietet Ihnen die Möglichkeit, Ihre eigene Kabine zu konzipieren.
<G-vec00040-002-s366><design.konzipieren><en> They design new products according to the customer’s ideas, they optimize existing products and they support the sales and production departments as well as the customers with their technical expertise.
<G-vec00040-002-s366><design.konzipieren><de> Sie konzipieren neue Produkte nach den Vorstellungen der Kunden, optimieren bereits Bestehendes und unterstützen Vertrieb, Produktion und Kunden mit ihrem Fachwissen.
<G-vec00040-002-s367><design.konzipieren><en> We strive not to make any assumptions regarding your privacy preferences and aim to design our services so that you can choose whether to share your personal data with us. Balance of interests
<G-vec00040-002-s367><design.konzipieren><de> Wir sind bestrebt, Ihnen keinerlei Präferenzen in Bezug auf Ihre Privatsphäre zu unterstellen und unsere Dienste so zu konzipieren, dass es Ihnen freisteht, Ihre personenbezogenen Daten mit uns zu teilen oder nicht.
<G-vec00040-002-s368><design.konzipieren><en> preferences of private households in India and In order to design electricity markets to simultaneously reduce the share of fossil fuels in energy production and meet the increasing demand for electricity, knowledge on consumer preferences is necessary.
<G-vec00040-002-s368><design.konzipieren><de> Um Strommärkte so zu konzipieren damit sie sowohl zur Verringerung der Nutzung fossiler Brennstoffe als auch zur Deckung des steigenden Energiebedarfes beitragen, ist Wissen über die Präferenzen der Konsumenten notwendig.
<G-vec00040-002-s369><design.konzipieren><en> Our experienced experts design and build optimum systems for high security areas, retail outlets, industrial premises, public administration and the whole of the commercial field.
<G-vec00040-002-s369><design.konzipieren><de> Unsere erfahrenen Fachleute konzipieren und bauen optimale Anlagen für Hochsicherheitsbereiche, Handel, Industrie, Verwaltung und den kompletten gewerblichen Bereich.
<G-vec00040-002-s370><design.konzipieren><en> Get the most proven, full-featured digital commerce solution on the market with rich, self-service tools to actively design your global selling experience.
<G-vec00040-002-s370><design.konzipieren><de> Sie erhalten die bewährteste, voll ausgestattete digitale Commerce-Lösung auf dem Markt mit umfassenden Selfservice-Tools, um Ihre globale Verkaufserfahrung zu konzipieren.
<G-vec00040-002-s371><design.konzipieren><en> In addition, they design novel security mechanisms meant to protect such devices from attacks.
<G-vec00040-002-s371><design.konzipieren><de> Außerdem konzipieren sie neue Sicherheitsmechanismen, die solche Geräte vor Angriffen schützen sollen.
<G-vec00040-002-s372><design.konzipieren><en> The design and development of a complete set of industrial automation elements has always been the strategic choice made by MCM.
<G-vec00040-002-s372><design.konzipieren><de> Es war seit jeher eine strategische Entscheidung von MCM, eine Serie einschließlich industrieller Automationselemente zu konzipieren und zu entwickeln.
<G-vec00040-002-s373><design.konzipieren><en> We design for you one (or more) individual, surprising and exciting staged flash mobs.
<G-vec00040-002-s373><design.konzipieren><de> Wir konzipieren für Sie einen (oder mehrere) individuelle, überraschende und mitreißend inszenierte Flashmobs.
<G-vec00040-002-s374><design.konzipieren><en> To ensure that the desks and workplace systems can combine all these functions in the preferred manner, the manufacturers are constantly coming up with innovative solutions to design the chairs and tables, worktops and keyboard drawers, and many other components to be an even better fit for everyday work.
<G-vec00040-002-s374><design.konzipieren><de> Damit die Schreibtische und Arbeitsplatzsysteme all diese Funktionen in gewünschter Weise in sich vereinen können, lassen sich die Hersteller immer wieder innovative Lösungen einfallen, um Stühle und Tische, Arbeitsplatten und Tastaturschubfächer sowie viele weitere Teilkomponenten noch passgenauer für den Arbeitsalltag zu konzipieren.
<G-vec00040-002-s375><design.konzipieren><en> Use FileMaker Pro Advanced to design and create custom apps for mobile, cloud, and on-premise environments.
<G-vec00040-002-s375><design.konzipieren><de> Verwenden Sie FileMaker Pro Advanced, um eigene Apps für mobile, Cloud- und On-Premise-Umgebungen zu konzipieren und zu erstellen.
<G-vec00040-002-s376><design.konzipieren><en> We are your competent partner in the area of exhibition stand construction – we design and implement your trade fair appearance: whatever sector your company belongs to, whatever budget you have in mind, and whatever direction you want to take in terms of trade fair design – we advise you professionally and create a perfect appearance for your company at the next trade fair.
<G-vec00040-002-s376><design.konzipieren><de> Wir sind Ihr kompetenter Ansprechpartner im Bereich Messebau – wir konzipieren und realisieren Ihren Messeauftritt: Egal welcher Branche Ihr Unternehmen angehört, egal welches Budget Ihnen dabei vorschwebt oder in welche Richtung Sie in Sachen Messedesign gehen wollen – wir beraten Sie professionell und kreieren einen perfekten Auftritt für Ihr Unternehmen auf der nächsten Messe.
<G-vec00040-002-s377><design.konzipieren><en> According to your needs, we design, plan, and build the event hall and take care of all associated aspects.
<G-vec00040-002-s377><design.konzipieren><de> Nach Ihren Bedürfnissen konzipieren, planen und realisieren wir die Eventhalle mit allem Drum und Dran.
<G-vec00040-002-s378><design.konzipieren><en> The design, construction and management of halls, office buildings and parking facilities is our core competence.
<G-vec00040-002-s378><design.konzipieren><de> Das Konzipieren, Bauen und Betreuen von Hallen, Bürogebäuden und Parkhäusern ist unsere Kernkompetenz.
<G-vec00040-002-s379><design.konzipieren><en> Within a group of companies specialized in environmental engineering, we can design, construct and implement efficient and trend-setting plant solutions for the waste disposal industry.
<G-vec00040-002-s379><design.konzipieren><de> Innerhalb einer Unternehmensgruppe, die sich auf Umwelttechnik spezialisiert hat, konzipieren, konstruieren und realisieren wir starke, richtungweisende Anlagenlösungen für Aufgaben innerhalb der Entsorgung.
