<G-vec00218-002-s019><enter.angeben><en> If you enter your departure point and destination on the website of Swiss Federal Railways (SBB), you'll be shown the best connection as well as the fare.
<G-vec00218-002-s019><enter.angeben><de> Wenn Sie auf der Website der SBB (Schweizerische Bundesbahnen) Ihren Abfahrtsort und Zielort angeben, wird Ihnen nicht nur die beste Verbindung angezeigt, sondern auch der Fahrpreis.
<G-vec00218-002-s020><enter.angeben><en> If you enter a folder name that does not yet exist, then a directory with that name is created.
<G-vec00218-002-s020><enter.angeben><de> Der Auschecken-Dialog Wenn Sie einen Ordnernamen angeben, der noch nicht existiert, wird dieser Ordner angelegt.
<G-vec00218-002-s021><enter.angeben><en> To use the app correctly, you'll first have to enter your weight and height.
<G-vec00218-002-s021><enter.angeben><de> Damit die App brauchbare Daten liefert, muss man zuerst Gewicht und Körpergröße angeben.
<G-vec00218-002-s022><enter.angeben><en> We take the burden from you and simplify the process. All you need to do is enter your flight details in our easy-to-use compensation checker and we’ll take care of the rest.
<G-vec00218-002-s022><enter.angeben><de> Sie müssen lediglich Ihre Forderung einreichen, die Daten Ihres Fluges angeben und sich entspannt zurücklehnen, während wir den Rest für Sie erledigen.
<G-vec00218-002-s023><enter.angeben><en> Therefore you have to enter further personal data which will be needed for the respective service.
<G-vec00218-002-s023><enter.angeben><de> Dazu müssen Sie in der Regel weitere personenbezogene Daten angeben, die wir zur Erbringung der jeweiligen Leistung nutzen und für die zuvor genannten Grundsätze zur Datenverarbeitung gelten.
<G-vec00218-002-s024><enter.angeben><en> The payment page on which you enter your card details is entirely secure.
<G-vec00218-002-s024><enter.angeben><de> Die Seite auf der Sie die Daten für Ihre Zahlung angeben ist 100% sicher.
<G-vec00218-002-s025><enter.angeben><en> With a customer account you must not enter your personal data every time you use our online shop, but you may log on to your customer account before or during an order with your e-mail address and the password, which you have chosen during the registration process.
<G-vec00218-002-s025><enter.angeben><de> Als angemeldeter Benutzer müssen Sie nicht jedes Mal Ihre persönlichen Daten angeben, sondern Sie können sich vor oder im Rahmen einer Bestellung einfach mit Ihrer E-Mail-Adresse und dem von Ihnen bei Registrierung frei gewählten Passwort in Ihrem Kundenkonto anmelden.
<G-vec00218-002-s026><enter.angeben><en> Should you use the asset over a shorter period and you can prove this, then you are allowed to enter a shorter service life.
<G-vec00218-002-s026><enter.angeben><de> Solltest du das Wirtschaftsgut aber über einen kürzeren Zeitraum nutzen und du kannst dies auch nachweisen, so darfst du auch eine kürzere Nutzungsdauer angeben.
<G-vec00218-002-s027><enter.angeben><en> As a rule this requires that you enter further personal data which we then use in order to provide the respective service for which the above named regulations on data processing are valid.
<G-vec00218-002-s027><enter.angeben><de> Dazu müssen Sie in der Regel weitere personenbezogene Daten angeben, die wir zur Erbringung der jeweiligen Leistung nutzen und für die die zuvor genannten Grundsätze zur Datenverarbeitung gelten.
<G-vec00218-002-s028><enter.angeben><en> Please enter a time in common format and choose the unit for the output.
<G-vec00218-002-s028><enter.angeben><de> Bitte eine Zeit in üblicher Form angeben und die gewünschte Einheit zur Ausgabe auswählen.
<G-vec00218-002-s029><enter.angeben><en> On the Delivery Controller page, choose how you want to enter the addresses of installed Controllers.
<G-vec00218-002-s029><enter.angeben><de> Wählen Sie auf der Seite Delivery Controller, wie Sie die Adressen der installierten Controller angeben möchten.
<G-vec00218-002-s030><enter.angeben><en> Once the trip has been completed, the fare is automatically charged to the bank card which the user is required to enter when signing up to the application.
<G-vec00218-002-s030><enter.angeben><de> Am Ende der Fahrt wird der Fahrpreis automatisch von der Kreditkarte abgebucht, deren Daten der Nutzer bei seiner Anmeldung zu der App angeben muss.
<G-vec00218-002-s031><enter.angeben><en> At the top of the Repository Browser Window you can enter the URL of the repository and the revision you want to browse.
<G-vec00218-002-s031><enter.angeben><de> In der Adresszeile können Sie die URL des Projektarchivs sowie die Revision, die Sie betrachten wollen, angeben.
<G-vec00218-002-s032><enter.angeben><en> When buying a voucher, the total amount will be multiples of CHF 20 which you have to enter on the order form as «number × CHF 20».
<G-vec00218-002-s032><enter.angeben><de> Im Bestellformular können Sie als «Anzahl × CHF 20.-» angeben, wie hoch der Gutscheinbetrag sein soll; es wird ein Gutschein über den Gesamtbetrag zugestellt (min.
<G-vec00218-002-s033><enter.angeben><en> If you want to enter your own texts, click Yes for Enter your own texts, which will open additional fields and an overview of placeholders for your individual payment plan text.
<G-vec00218-002-s033><enter.angeben><de> Wenn Sie eigene Texte angeben möchten, klicken Sie bei Eigene Texte angeben auf Ja, wodurch sich weitere Felder und eine Übersicht an Platzhaltern für Ihren individuellen Zahlungsplan-Text öffnen.
<G-vec00218-002-s035><enter.angeben><en> Additionally, here you only need to enter the instance's SID and the version of the database on which the instance is located.
<G-vec00218-002-s035><enter.angeben><de> Zusätzlich müssen Sie hier nur noch die SID der Instanz angeben und die Version der Datenbank, auf dem sich diese Instanz befindet.
<G-vec00218-002-s036><enter.angeben><en> Depending on the service bundle, you may have to enter the exact mileage (km) to identify your vehicle. Otherwise, you will receive an 8-digit registration code that you will have to enter into the navigation system of your vehicle.
<G-vec00218-002-s036><enter.angeben><de> Je nach Dienstepaket müssen Sie zur Identifikation noch den exakten Kilometerstand angeben oder erhalten einen 8-stelligen Registrierungscode, welchen Sie im Navigationssystem Ihres Fahrzeugs eingeben müssen.
<G-vec00218-002-s037><enter.angeben><en> For this purpose, the user creates a user profile (e-mail and password), but the user can also enter a title and/or his or her full name.
<G-vec00218-002-s037><enter.angeben><de> Dazu legt der User ein Nutzerprofil an (E-Mail und Passwort) an, zusätzlich kann man aber auch eine Anrede und seinen vollständigen Namen angeben.
<G-vec00218-002-s057><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Suit fighting.
<G-vec00218-002-s057><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Kampfanzug .
<G-vec00218-002-s058><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Heater air.
<G-vec00218-002-s058><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Lufterhitzer .
<G-vec00218-002-s059><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Development of documentation.
<G-vec00218-002-s059><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Dokumentationszertifizierung .
<G-vec00218-002-s060><enter.betreten><en> Enter the world of exquisite sadism and Trans supremacy with an aristocratic touch.
<G-vec00218-002-s060><enter.betreten><de> Betreten Sie die Welt des exquisiten Sadismus und der Trans-Vorherrschaft mit einer aristokratischen Note.
<G-vec00218-002-s061><enter.betreten><en> Enter into the realm of your download mode.
<G-vec00218-002-s061><enter.betreten><de> Betreten Sie den Bereich Ihres Download-Modus.
<G-vec00218-002-s062><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Rigging scaffolding.
<G-vec00218-002-s062><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Gerüstausarbeitung .
<G-vec00218-002-s063><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Arrangement floor UP
<G-vec00218-002-s063><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Kanaleinrichtung .
<G-vec00218-002-s064><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Press vertical.
<G-vec00218-002-s064><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Vertikalpresse .
<G-vec00218-002-s065><enter.betreten><en> Enter the room which is designed similarly to a walk-in picture book, and read her thoughts about Sitemap . Imprint . Privacy
<G-vec00218-002-s065><enter.betreten><de> Betreten Sie einen Raum, der ähnlich einem begehbaren Bilderbuch gestaltet ist und lesen Sie Gedanken der Äbtissin zu den Eigenschaften von Steinen und Pflanzen.
<G-vec00218-002-s066><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Cologne hygienic.
<G-vec00218-002-s066><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Kölnischwasser hygienisches.
<G-vec00218-002-s067><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Tool diagnostic.
<G-vec00218-002-s067><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Azidogastrometer diagnostisch.
<G-vec00218-002-s068><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Certification glass block.
<G-vec00218-002-s068><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Glassziegelzertifizierung .
<G-vec00218-002-s069><enter.betreten><en> Enter the world of the eleventh series of fun games Battlefield 4.
<G-vec00218-002-s069><enter.betreten><de> Betreten Sie die Welt der elften Reihe von lustigen Spielen Battlefield 4.
<G-vec00218-002-s070><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Mounting shaft.
<G-vec00218-002-s070><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Aufgabevibrator .
<G-vec00218-002-s071><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Slab calcareous.
<G-vec00218-002-s071><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Kalksteinplatte .
<G-vec00218-002-s072><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Machine milling.
<G-vec00218-002-s072><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Fräsmaschine .
<G-vec00218-002-s073><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Valve protective.
<G-vec00218-002-s073><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Abfallverwertungsanlage .
<G-vec00218-002-s074><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Oilcloth heat-resistant.
<G-vec00218-002-s074><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Schlackenportlandzement sulfatbeständig.
<G-vec00218-002-s075><enter.betreten><en> Enter the section and learn detailed description of the available trademarks and modifications of the goods/services - Brisket pork.
<G-vec00218-002-s075><enter.betreten><de> Betreten Sie die Spalte und lernen Sie eine ausführliche Beschreibung von vorhandenen Marken und Ausführungen von Produkten / Leistungen - Schweinekonserven .
<G-vec00218-002-s627><enter.eingeben><en> · help make this Site easier for you to use by not having to enter information more than once.
<G-vec00218-002-s627><enter.eingeben><de> •diese Webseite für Sie einfacher machen, indem Sie Informationen nicht mehr als einmal eingeben.
<G-vec00218-002-s628><enter.eingeben><en> We may collect and store any personal information you enter on our website or on a mobile application, or provide to us in some other manner.
<G-vec00218-002-s628><enter.eingeben><de> Daten, die Sie uns bereitstellen: Wir erfassen und speichern alle Daten, die Sie auf unseren Websites eingeben oder uns im Zusammenhang mit der Nutzung unserer Websites, Anwendungen, Dienstleistungen oder Tools bereitstellen.
<G-vec00218-002-s629><enter.eingeben><en> Alternatively, enter an XPath expression that selects the required node in the schema.
<G-vec00218-002-s629><enter.eingeben><de> Alternativ dazu können Sie einen XPath-Ausdruck eingeben, mit dem der gewünschte Node im Schema ausgewählt wird.
<G-vec00218-002-s630><enter.eingeben><en> When restoring a volume header from the backup file, you will need to enter the correct password (and/or to supply the correct keyfiles) that was/were valid when the volume header backup was created.
<G-vec00218-002-s630><enter.eingeben><de> Wenn Volume-Kopfdaten aus der Sicherungsdatei wiederhergestellt werden, dann müssen Sie das korrekte Passwort eingeben, welches gültig war als die Volume-Kopfdatensicherung erstellt wurde (und/oder die richtigen Schlüsseldateien bereitstellen).
<G-vec00218-002-s631><enter.eingeben><en> Namely, when you create jobs that send AS2 messages, you will be able to select the partner from a list of trading partners already defined (instead of having to enter the partner details for each FlowForce job).
<G-vec00218-002-s631><enter.eingeben><de> Wenn Sie Aufträge erstellen, mit denen AS2-Nachrichten versendet werden, können Sie den Partner aus einer Liste von bereits definierten Handelspartnern auswählen (statt dass Sie die Partnerdaten für jeden FlowForce-Auftrag eigens eingeben müssen).
<G-vec00218-002-s632><enter.eingeben><en> G r Pn o Use the number buttons to enter numbers and values.
<G-vec00218-002-s632><enter.eingeben><de> G r Pn o Zifferntasten Verwenden Sie die Zifferntasten zum Eingeben von Nummern und Werten.
<G-vec00218-002-s633><enter.eingeben><en> To ensure a full hotel listing for a particular geographical area, do not enter your travel dates.
<G-vec00218-002-s633><enter.eingeben><de> Damit eine vollständige Liste mit Hotels in einer bestimmten Region angezeigt wird, dürfen Sie keine Reisedaten eingeben.
<G-vec00218-002-s634><enter.eingeben><en> Cookies save you time by eliminating the need to repeatedly enter the same information.
<G-vec00218-002-s634><enter.eingeben><de> Cookies sparen auch Zeit, da Sie nicht immer wieder dieselben Informationen eingeben müssen.
<G-vec00218-002-s635><enter.eingeben><en> You can enter placeholder text Roman, Arabic, Hebrew, Chinese among others.
<G-vec00218-002-s635><enter.eingeben><de> So können Sie Platzhaltertext u. a. lateinisch, arabisch, hebräisch und chinesisch eingeben.
<G-vec00218-002-s636><enter.eingeben><en> You may be required to enter your billing information in order to sign up for the Free Trial.
<G-vec00218-002-s636><enter.eingeben><de> Unter Umständen müssen Sie Ihre Zahlungsinformationen eingeben, um sich für die kostenlose Testversion anzumelden.
<G-vec00218-002-s637><enter.eingeben><en> A solution is a file or set of files containing database tables, layouts, and scripts, and the associated data that you enter and work with.
<G-vec00218-002-s637><enter.eingeben><de> Eine eigene App ist eine Datei oder eine Menge von Dateien, die Datenbanktabellen, Layouts, Scripts und Beziehungen sowie die zugehörigen Daten enthält, die Sie eingeben und mit denen Sie arbeiten.
<G-vec00218-002-s638><enter.eingeben><en> - If you are a member of the InstaHe!p affiliate program, enter your ID here to show all links with your id.
<G-vec00218-002-s638><enter.eingeben><de> - Wenn Sie ein Mitglied des InstaHe!p Affiliate Programmes sind können Sie hier Ihre ID eingeben.
<G-vec00218-002-s639><enter.eingeben><en> If you need more detailed information on getting to Labin by car, enter your starting point and click on "Get Directions" button below.
<G-vec00218-002-s639><enter.eingeben><de> Eine ausführliche Beschreibung für die Reise nach Poreč mit dem Auto erhalten Sie, indem Sie ihren Abfahrtsort eingeben und auf die Schaltfläche "Wegbeschreibung anfordern" weiter unten klicken.
<G-vec00218-002-s640><enter.eingeben><en> However, your payment information is not stored in your customer account and you will have to enter it again for each purchase.
<G-vec00218-002-s640><enter.eingeben><de> Deine Zahlungsinformationen werden aber nicht in deinem Kundenkonto gespeichert und du musst sie bei jedem Einkauf wieder neu eingeben.
<G-vec00218-002-s641><enter.eingeben><en> You can enter search terms directly into the free text search.
<G-vec00218-002-s641><enter.eingeben><de> Natürlich können Sie auch Suchbegriffe direkt in der Freitext-Suche eingeben.
<G-vec00218-002-s642><enter.eingeben><en> These cookies help us to remember data, such as your username and language preference to save you having to enter them again next time you visit.
<G-vec00218-002-s642><enter.eingeben><de> Sie helfen uns, Daten wie Ihren Benutzernamen und Spracheinstellungen zu speichern, so dass Sie diese beim nächsten Besuch nicht erneut eingeben müssen.
<G-vec00218-002-s643><enter.eingeben><en> Simply enter your planned dates of stay in our search box to find the best hotel deals Hotels
<G-vec00218-002-s643><enter.eingeben><de> Finden Sie die besten Hotelschnäppchen in Kucukcekmece, indem Sie Ihre Reisedaten in das Suchfeld eingeben.
<G-vec00218-002-s644><enter.eingeben><en> Please enter your email address below. You will receive a link to reset your password.
<G-vec00218-002-s644><enter.eingeben><de> Über folgenden Link können Sie Ihre Benutzer-ID (E-Mail-Adresse) eingeben, um Ihr Passwort zurückzusetzen.
<G-vec00218-002-s645><enter.eingeben><en> We collect some data about the users they enter during registration and when using our service.
<G-vec00218-002-s645><enter.eingeben><de> Wir erfassen einige Daten über die Benutzer, die sie bei der Registrierung und bei der Nutzung unseres Dienstes eingeben.
<G-vec00218-002-s285><enter.eingehen><en> They recognise how important it is to enter into partnerships with the countries of origin of migrants and the transit states they use.
<G-vec00218-002-s285><enter.eingehen><de> Sie erkennen an, wie wichtig es ist, Partnerschaften mit Herkunfts- und Transitländern einzugehen.
<G-vec00218-002-s286><enter.eingehen><en> Since Christ’s Death on the Cross and his Resurrection constitute the content of the daily life of the Church (25) and the pledge of his eternal Passover, (26) the Liturgy has as its first task to lead us untiringly back to the Easter pilgrimage initiated by Christ, in which we accept death in order to enter into life. 7.
<G-vec00218-002-s286><enter.eingehen><de> Da der Tod Christi am Kreuze und seine Auferstehung den Inhalt des täglichen Lebens der Kirche[25] und das Unterpfand ihres ewigen Ostern[26] bilden, hat die Liturgie als erste Aufgabe, uns unermüdlich auf den österlichen Weg zu führen, den uns Christus eröffnet hat und auf dem man es annimmt zu sterben, um in das Leben einzugehen.
<G-vec00218-002-s287><enter.eingehen><en> Artists are invited to respond to the building’s architecture or to even enter into a symbiosis with it.
<G-vec00218-002-s287><enter.eingehen><de> Die Künstler/innen sind eingeladen, auf die Architektur zu reagieren beziehungsweise eine Symbiose mit ihr einzugehen.
<G-vec00218-002-s288><enter.eingehen><en> Searching for an updated toolbox and an analytic approach, we chose to enter an open cooperation with an external partner to run and manage our process.
<G-vec00218-002-s288><enter.eingehen><de> Um den Prozess voranzutreiben, haben wir uns dazu entschlossen, eine offene Zusammenarbeit mit einem externen Partner einzugehen, der über ein zukunftsorientiertes Know-how und einen analytischen Blickwinkel (Situation/Aufgaben) verfügt.
<G-vec00218-002-s289><enter.eingehen><en> If the entrepreneur on the basis of this investigation has good reasons not to enter into the agreement, he is entitled to refuse an order or request motivated or to attach special conditions to the execution.
<G-vec00218-002-s289><enter.eingehen><de> Falls der Unternehmer aufgrund dieser Nachforschung gute Gründe hat die Vereinbarung nicht einzugehen, ist er berechtigt eine Bestellung oder Anfrage nicht anzunehmen oder die Durchführung an besondere Bedingungen zu knüpfen.
<G-vec00218-002-s290><enter.eingehen><en> I am sure you will understand that I do not want to close this section of my letter without taking the opportunity to enter into my personal and most central key concern once again.
<G-vec00218-002-s290><enter.eingehen><de> Sie haben gewiß Verständnis dafür, dass ich diesen Abschnitt meines Briefes nicht schließen möchte, ohne die Gelegenheit wahrzunehmen, nochmals auf mein persönliches zentralstes Kernanliegen einzugehen.
<G-vec00218-002-s291><enter.eingehen><en> If based on this research the supplier has good reasons not to enter the agreement, he is legally justified to refuse an order or request or add appropriate terms and conditions to the agreement.
<G-vec00218-002-s291><enter.eingehen><de> Wenn der Unternehmer auf Grund dieser Prüfung gute Gründe hat, den Vertrag nicht einzugehen, ist er berechtigt, eine Bestellung oder Anfrage unter Angabe von Gründen abzulehnen oder mit der Erfüllung besondere Voraussetzungen zu verbinden.
<G-vec00218-002-s292><enter.eingehen><en> It’s better for you to enter into life crippled or lame than, having two hands or two feet, to be thrown into fiery Gehenna.
<G-vec00218-002-s292><enter.eingehen><de> Es ist dir besser, lahm oder als Krüppel in das Leben einzugehen, als mit zwei Händen oder mit zwei Füßen in das ewige Feuer geworfen zu werden.
<G-vec00218-002-s293><enter.eingehen><en> If the operator under this investigation was justified in order not to enter into the agreement, he is entitled to refuse or to bind its implementation to special conditions an order or request. 5.
<G-vec00218-002-s293><enter.eingehen><de> Wenn der Unternehmer auf der Grundlage dieser Nachforschung gute Gründe hat, die Vereinbarung nicht einzugehen, ist er berechtigt, einen Auftrag oder eine Anfrage zu verweigern oder mit der Ausführung besondere Bedingungen zu verknüpfen.
<G-vec00218-002-s294><enter.eingehen><en> BY ACCESSING OR USING THE SITE OR BUSINESS SERVICES, YOU ACCEPT THIS AGREEMENT AND YOU REPRESENT AND WARRANT THAT YOU HAVE THE RIGHT, AUTHORITY, AND CAPACITY TO ENTER INTO THIS AGREEMENT.
<G-vec00218-002-s294><enter.eingehen><de> Indem Sie auf die Dienstleistungen zugreifen oder diese nutzen, akzeptieren Sie diese Vereinbarung, und Sie versichern, dass Sie das Recht, die Befugnis und die Fähigkeit haben um diese Vereinbarung einzugehen.
<G-vec00218-002-s295><enter.eingehen><en> If Apollyon is justified, based on this investigation, not to enter into the contract, he is entitled to refuse an order or to attach special conditions.
<G-vec00218-002-s295><enter.eingehen><de> Wenn der Unternehmer auf Grund dieser Untersuchung vernünftige Gründe hat, den Vertrag nicht einzugehen, ist er berechtigt, die Ausführung einer Bestellung oder Anfrage zu verweigern oder diese an besondere Bedingungen zu knüpfen.
<G-vec00218-002-s296><enter.eingehen><en> Let us, therefore, make every effort to enter that rest, so that no one will perish by following their example of disobedience.
<G-vec00218-002-s296><enter.eingehen><de> So lasst uns nun bemüht sein, in diese Ruhe einzugehen, damit nicht jemand zu Fall komme wie in diesem Beispiel des desobediencia.
<G-vec00218-002-s297><enter.eingehen><en> NIV 11 Let us, therefore, make every effort to enter that rest, so that no one will perish by following their example of disobedience.
<G-vec00218-002-s297><enter.eingehen><de> 11 Laßt uns nun eifrig sein, in jene Ruhe einzugehen, damit nicht jemand nach demselben Beispiel des Ungehorsams falle.
<G-vec00218-002-s298><enter.eingehen><en> If the operator under this investigation was justified in order not to enter into the agreement, he is entitled to refuse or to bind its implementation to special conditions an order or request.
<G-vec00218-002-s298><enter.eingehen><de> Wenn der Unternehmer aufgrund dieser Informationen gute Gründe hat, die Vereinbarung nicht einzugehen, ist er berechtigt motiviert, eine Bestellung zu verweigern oder mit besonderen Bedingungen zu verbinden.
<G-vec00218-002-s300><enter.eingehen><en> It is better for you to enter into life lame, or crippled, than having two hands or two feet to be cast into the eternal fire.
<G-vec00218-002-s300><enter.eingehen><de> Es ist besser für dich, verstümmelt oder lahm ins Leben einzugehen, als mit zwei Händen und zwei Füßen in das ewige Feuer geworfen zu werden.
<G-vec00218-002-s302><enter.eingehen><en> If you decide to enter into a longer term partnership with us, we will regularly screen your activities to identify those that are eligible for subsidy.
<G-vec00218-002-s302><enter.eingehen><de> Wenn Sie sich dazu entschließen, eine langfristige Partnerschaft mit uns einzugehen, werden wir uns regelmäßig Ihre Aktivitäten anschauen, um förderfähige Projekte rechtzeitig zu identifizieren.
<G-vec00218-002-s303><enter.eingehen><en> It is impossible for me here to enter on details, but I may specify a few of the points of difference.
<G-vec00218-002-s303><enter.eingehen><de> Es ist mir unmöglich, hier auf Einzelnheiten einzugehen; ich will indessen einige wenige Differenzpunkte anführen.
<G-vec00218-002-s228><enter.eintragen><en> Using the mouse, transfer the measured value from the display instrument U into the prepared table, and enter the value of the resistance R1 manually.
<G-vec00218-002-s228><enter.eintragen><de> Den Messwert mit der Maus aus dem Anzeigeinstrument U in die vorbereitete Tabelle schieben und Widerstandswert R1 manuell eintragen.
<G-vec00218-002-s229><enter.eintragen><en> On the bottom of the window, click the Enter activation code button.
<G-vec00218-002-s229><enter.eintragen><de> Klicken Sie unten im Fenster auf die Schaltfläche Aktivierungscode eintragen.
<G-vec00218-002-s230><enter.eintragen><en> For this you will receive an appropriate form in which you can enter your measurements.
<G-vec00218-002-s230><enter.eintragen><de> Dafür bekommst du ein entsprechendes Formular, in das du deine Werte eintragen kannst.
<G-vec00218-002-s231><enter.eintragen><en> Enter your details The next step is to fill in personal details like your name, address and telephone number.
<G-vec00218-002-s231><enter.eintragen><de> Der nächste Schritt ist das Eintragen Ihrer persönlichen Daten, wie Name, Adresse und Telefonnummer.
<G-vec00218-002-s232><enter.eintragen><en> To use the My Cafe: Recipes & Stories Hack you just have to enter your username and do a small task.
<G-vec00218-002-s232><enter.eintragen><de> Um den My Cafe Recipes Stories Hack zu nutzen musst Du nur Deinen Username eintragen und eine kleine Aufgabe erfüllen.
<G-vec00218-002-s233><enter.eintragen><en> You always have to enter your Skype ID.
<G-vec00218-002-s233><enter.eintragen><de> Deine Skype ID musst du immer eintragen.
<G-vec00218-002-s234><enter.eintragen><en> First make yourself aware of your main tasks and then enter these as fixed times in a diary.
<G-vec00218-002-s234><enter.eintragen><de> Zunächst sollte man sich seine Hauptaufgaben bewusst machen und diese dann zu fixen Zeiten in einen Kalender eintragen.
<G-vec00218-002-s235><enter.eintragen><en> You can enter a note which will be displayed in the upper left corner of this section.
<G-vec00218-002-s235><enter.eintragen><de> Du kannst einen Hinweistext eintragen, der oben links in diesem Bereich angezeigt wird.
<G-vec00218-002-s236><enter.eintragen><en> Dies Please enter the SMS verification code below.
<G-vec00218-002-s236><enter.eintragen><de> Gleich loslegen und E-Mail-Adresse eintragen.
<G-vec00218-002-s237><enter.eintragen><en> To use the Deluxe Jigsaw Puzzles USA Tour Hack you just have to enter your username and do a small task.
<G-vec00218-002-s237><enter.eintragen><de> Um den Horizon Chase World Tour Hack zu nutzen musst Du nur Deinen Username eintragen und eine kleine Aufgabe erfüllen.
<G-vec00218-002-s238><enter.eintragen><en> 1) Personal information that you voluntarily enter by registering for our newsletter, placing an order or using similar services.
<G-vec00218-002-s238><enter.eintragen><de> 1) personenbezogene Daten, die Sie freiwillig eintragen, indem Sie sich für unsere Newsletter registrieren, eine Bestellung aufgeben oder ähnliche Dienste in Anspruch nehmen.
<G-vec00218-002-s239><enter.eintragen><en> The clan creator can enter a Clan Motto in the corresponding field.
<G-vec00218-002-s239><enter.eintragen><de> Der Clanersteller kann ein Clanmotto ins entsprechende Feld eintragen.
<G-vec00218-002-s240><enter.eintragen><en> *If you are signing the agreement on behalf of a company, you may enter the company’s name in the Full Name field.
<G-vec00218-002-s240><enter.eintragen><de> *Wenn Sie die Vereinbarung im Auftrag eines Unternehmens unterzeichnen, sollten Sie den Unternehmensnamen in das Feld "Name" eintragen.
<G-vec00218-002-s241><enter.eintragen><en> Please do not enter anything in this field, it only helps to prevent spam.
<G-vec00218-002-s241><enter.eintragen><de> In diesem Feld bitte nichts eintragen, es dient nur der Verhinderung von Spam.
<G-vec00218-002-s242><enter.eintragen><en> You also have to enter the code referred to above after the keyword “token.”
<G-vec00218-002-s242><enter.eintragen><de> Zusätzlich müssen Sie heute aber auch den eben erwähnten Code hinter dem Stichwort token eintragen.
<G-vec00218-002-s243><enter.eintragen><en> With the app, shift supervisors can easily and efficiently enter transport orders into the system via smartphone or tablet and at the same time assign an urgency to the order.
<G-vec00218-002-s243><enter.eintragen><de> Mit der App können Schichtleiter Fahraufträge einfach und effizient per Smartphone oder Tablet in das System eintragen und gleichzeitig dem Auftrag eine Dringlichkeit zuweisen.
<G-vec00218-002-s244><enter.eintragen><en> If necessary please adapt the file /etc/apt/apt.conf to your network configuration (enter the correct proxy or comment/delete unnecessary lines).
<G-vec00218-002-s244><enter.eintragen><de> Sofern für Ihren Internet-Zugang erforderlich, passen Sie die Datei /etc/apt/apt.conf an Ihre Netzwerkgegebenheiten an (richtigen Proxy eintragen oder Zeile auskommentieren / löschen).
<G-vec00218-002-s245><enter.eintragen><en> With this module, you can easily enter the necessary information about the tool life detection.
<G-vec00218-002-s245><enter.eintragen><de> Mit diesem Modul können Sie einfach die notwendigen Informationen zur Standzeiterfassung des Werkzeuges eintragen.
<G-vec00218-002-s246><enter.eintragen><en> If you enter WEBSAFE in the subject of an email, this email will be encrypted via the Websafe.
<G-vec00218-002-s246><enter.eintragen><de> Wenn sie in den Betreff einer E-Mail WEBSAFE eintragen, wird diese E-Mail über den Websafe verschlüsselt.
<G-vec00218-002-s304><enter.eintreten><en> I could not wait to enter the place!
<G-vec00218-002-s304><enter.eintreten><de> Ich konnte es kaum erwarten einzutreten.
<G-vec00218-002-s305><enter.eintreten><en> In obligations to third parties, which go beyond the contract period, the customer has to enter.
<G-vec00218-002-s305><enter.eintreten><de> 5.4 In Verpflichtungen gegenüber Dritten, die über die Vertragslaufzeit hinausgehen, hat der Kunde einzutreten.
<G-vec00218-002-s306><enter.eintreten><en> We must strive in these few years to understand the ten aspects of the truth and enter into the reality of God’s words.
<G-vec00218-002-s306><enter.eintreten><de> Wir müssen uns in diesen wenigen Jahren darum bemühen, die zehn Aspekte der Wahrheit zu verstehen und in die Wirklichkeit von Gottes Worten einzutreten.
<G-vec00218-002-s307><enter.eintreten><en> This leads to the creation of another level, with which the audience can connect to better – like a door, through which one passes in order to enter a world of sound or art.
<G-vec00218-002-s307><enter.eintreten><de> Dadurch entsteht eine andere Ebene, mit der sich das Publikum oft besser verbinden kann – wie eine Tür, durch die man gehen kann, um in eine Klang- oder Kunstwelt einzutreten.
<G-vec00218-002-s308><enter.eintreten><en> After her father and her brothers liable for military service had returned home from the war and from captivity, her long-standing wish to enter the Congregation of the Sisters of Notre Dame was fulfilled on October 15, 1945.
<G-vec00218-002-s308><enter.eintreten><de> Nachdem ihr Vater und die wehrpflichtigen Brüder aus Krieg und Gefangenschaft heimgekehrt waren, erfüllte sich am 15.10.1945 ihr langjähriger Wunsch, bei den Schwestern Unserer Lieben Frau einzutreten.
<G-vec00218-002-s309><enter.eintreten><en> A Spanish Inquisitor, a witch burn and a psychopathic doctor and many more await you, if you are brave enough to enter.
<G-vec00218-002-s309><enter.eintreten><de> Ein spanischer Inquisitor, ein Hexenverbrenner und ein psychopathischer Arzt und vieles mehr erwarten Sie, wenn Sie mutig genug sind, um einzutreten.
<G-vec00218-002-s310><enter.eintreten><en> When we begin to enter into the Buddhic plane, the negative reaction will be very rapidly eliminated.
<G-vec00218-002-s310><enter.eintreten><de> Wenn wir beginnen in die buddhische Ebene einzutreten, wird die negative Reaktion sehr schnell aufgelöst.
<G-vec00218-002-s311><enter.eintreten><en> The focus of our 11:11 Master Cylinder is to form an invincible One Being and to enter the Lotus World, not to advance our personal agendas, so please don't bring your ego or old baggage.
<G-vec00218-002-s311><enter.eintreten><de> Der Fokus unseres 11:11 Meisterzylinders liegt darauf, ein unbezwingbares Eines Sein darzustellen und in die Lotus-Welt einzutreten, und nicht, unsere persönlichen Pläne zu forcieren, deswegen bringe bitte dein Ego und dein altes Gepäck nicht mit.
<G-vec00218-002-s312><enter.eintreten><en> May she, who at sunrise on Sunday, was sleepless with hope and unafraid of joy, accompany us on our pilgrimage, calling everyone to get up, lay aside our paralysis, to enter together into the peace and joy that Jesus, the Risen Lord, promises
<G-vec00218-002-s312><enter.eintreten><de> Sie – die in der Morgendämmerung des ersten Tags der Woche, schlaflos durch die Hoffnung, keine Angst hatte vor der Freude – möge uns auf unserem Pilgerweg begleiten, da sie alle einlädt, aufzustehen, die Lähmung hinter uns zu lassen, um gemeinsam in den Frieden und die Freude einzutreten, die Jesus, der auferstandene Herr, uns verheißt.
<G-vec00218-002-s313><enter.eintreten><en> The Holy Spirit guides Christ’s followers to invite the unbelievers to leave the world of Satan and enter into the church of Jesus.
<G-vec00218-002-s313><enter.eintreten><de> Christen sollen Ungläubige rufen, aus der Welt Satans heraus in die Gemeinde Jesu einzutreten.
<G-vec00218-002-s314><enter.eintreten><en> But it would be nonsense to consider trying to make other people become anarchists and suggest that they enter our groups during the struggle.
<G-vec00218-002-s314><enter.eintreten><de> Es wäre jedoch ein Widersinn, zu denken, die Leute zu Anarchisten werden zu lassen, indem man vorschlägt, in unsere Gruppen einzutreten, zu dem Zweck, den Kampf auf anarchistische Weise anzugehen.
<G-vec00218-002-s315><enter.eintreten><en> You acknowledge and agree that you are fully capable and authorized to enter into this binding agreement on behalf or yourself and any organization on whose behalf you may act.
<G-vec00218-002-s315><enter.eintreten><de> Sie erklären hiermit ausdrücklich, dass Sie vollständig in der Lage und bevollmächtigt sind, in Ihrem oder im Namen einer Organisation, in deren Auftrag Sie handeln, in diese verbindliche Vereinbarung einzutreten.
<G-vec00218-002-s316><enter.eintreten><en> Obviously was the doorman, which preserved the wild Renate from overly boring or male audience, I would therefore deserves, enter ….
<G-vec00218-002-s316><enter.eintreten><de> Offensichtlich fand der Türsteher, der die wilde Renate vor übermäßig männlichen oder langweiligem Publikum bewahrte, dass ich es somit verdient hätte, einzutreten ….
<G-vec00218-002-s317><enter.eintreten><en> Once we see deviations, that’s the moment for us to enter the market.
<G-vec00218-002-s317><enter.eintreten><de> Einmal sehen wir Abweichungen, das ist der moment für uns, um in den Markt einzutreten.
<G-vec00218-002-s318><enter.eintreten><en> This is a subtle blockage which hinders us to enter into the realms of light.
<G-vec00218-002-s318><enter.eintreten><de> Dies ist eine subtile Blockade, die uns daran hindert, in die Bereiche des Lichts einzutreten.
<G-vec00218-002-s319><enter.eintreten><en> IMPORTANT NOTICE: pre-booked tickets allow to enter the Museums without waiting in line.
<G-vec00218-002-s319><enter.eintreten><de> WICHTIGER HINWEIS: die gebuchten Eintrittskarten gestatten es Ihnen ohne Warteschlange in die Museen einzutreten.
<G-vec00218-002-s320><enter.eintreten><en> For instance, it may be that the airline operating the flight element of your booking will not be able to operate the flight because of the loss or restriction of air traffic or transit rights or the right of the airline to enter any airspace.
<G-vec00218-002-s320><enter.eintreten><de> Zum Beispiel kann es sein, dass die für den Fluganteil Ihrer Reise verantwortliche Fluggesellschaft Ihren Flug aufgrund eines Verlustes oder einer Einschränkung von Flugverkehrs- oder Transitrechten oder des Rechts, in einen bestimmten Luftraum einzutreten, nicht durchführen kann.
<G-vec00218-002-s321><enter.eintreten><en> But when the torch glanced upon the lofty crest and golden spurs of the knight, who stood without, the hermit, altering probably his original intentions, repressed the rage of his auxiliaries, and, changing his tone to a sort of churlish courtesy, invited the knight to enter his hut, making excuse for his unwillingness to open his lodge after sunset, by alleging the multitude of robbers and outlaws who were abroad, and who gave no honour to Our Lady or St Dunstan, nor to those holy men who spent life in their service.
<G-vec00218-002-s321><enter.eintreten><de> Als aber die Fackel auf der Rüstung des Ritters widerstrahlte, änderte der Eremit offenbar seinen Plan und hielt die Wuth seiner Bundestruppen zurück; zugleich lud er den Ritter im Tone kirchlicher Höflichkeit ein, in seine Zelle einzutreten, indem er sein früheres Betragen damit entschuldigte, daß oft nach Sonnenuntergang Räuber und Geächtete umherstreiften, welche unsere Frau und den heiligen Dunstan und diejenigen, die ihr Leben dem Dienste derselben gewidmet hätten, gar wenig in Ehren hielten.
<G-vec00218-002-s322><enter.eintreten><en> A new administration that has the ability to radically shift policy direction can be reason to enter or exit a market.
<G-vec00218-002-s322><enter.eintreten><de> Eine neue Regierung, die imstande ist, die Richtung der Politik radikal zu ändern, kann der Grund sein, in einen Markt einzutreten oder ihn zu verlassen.
<G-vec00218-002-s361><enter.erfassen><en> For multi-column output, you enter the desired number of columns when defining the page format.
<G-vec00218-002-s361><enter.erfassen><de> Für die mehrspaltige Ausgabe erfassen Sie beim Festlegen des Blattformats die gewünschte Anzahl von Spalten.
<G-vec00218-002-s362><enter.erfassen><en> This is where you can enter your payment information.
<G-vec00218-002-s362><enter.erfassen><de> Hier erfassen Sie Ihre Zahlungsinformationen.
<G-vec00218-002-s363><enter.erfassen><en> The Service Article Module expands your EULANDA® inventory management system by the possibility to enter a new class of articles independently of the normal articles, including a separate input mask with fields for serial number, manufacturer, model and many more.
<G-vec00218-002-s363><enter.erfassen><de> Service-Artikel Service-Artikel Das Service-Artikel Modul erweitert Ihre EULANDA®-Warenwirtschaft um die Möglichkeit unabhängig von den normalen Artikeln eine neue Klasse von Artikeln zu erfassen.
<G-vec00218-002-s364><enter.erfassen><en> In price lists, you enter the list prices (unit prices) of goods and services your company sells to customers.
<G-vec00218-002-s364><enter.erfassen><de> In Preislisten erfassen Sie Listenpreise (Einzelpreise) für Waren und Dienstleistungen, die Ihr Unternehmen an Kunden verkauft.
<G-vec00218-002-s365><enter.erfassen><en> You may enter a percentage surcharge or discount for a group total.
<G-vec00218-002-s365><enter.erfassen><de> Zu einer Gruppensumme können Sie einen prozentualen Zu- oder Abschlag erfassen.
<G-vec00218-002-s366><enter.erfassen><en> Self Check-In With the Self check-in your visitors can enter their data themselves.
<G-vec00218-002-s366><enter.erfassen><de> Self Check-In Mit dem Self Check-In erfassen Ihre Besucher Ihre Daten selbst.
<G-vec00218-002-s367><enter.erfassen><en> Click the line of the participant for whom you want to enter a mapping.
<G-vec00218-002-s367><enter.erfassen><de> Klicken Sie auf die Zeile des Teilnehmers, für den Sie ein Mapping erfassen wollen.
<G-vec00218-002-s368><enter.erfassen><en> When you use certain areas of our website we ask you, as the user, to enter some data that can be assigned specifically to you as an individual.
<G-vec00218-002-s368><enter.erfassen><de> Bei der Nutzung einiger Bereiche unseres Internet-Auftritts bitten wir Sie als Benutzer, einige Daten zu erfassen, die eindeutig Ihrer Person zugeordnet werden können.
<G-vec00218-002-s369><enter.erfassen><en> In the window you can enter and update notes for the folder file.
<G-vec00218-002-s369><enter.erfassen><de> In dem Fenster können Sie Notizen zu der Ordnerdatei erfassen und pflegen.
<G-vec00218-002-s370><enter.erfassen><en> You manually enter e-mail templates.
<G-vec00218-002-s370><enter.erfassen><de> E-Mail-Vorlagen erfassen Sie manuell.
<G-vec00218-002-s371><enter.erfassen><en> You delete the zero stock in the posting history and then enter the correct actual stock.
<G-vec00218-002-s371><enter.erfassen><de> Sie löschen den Nullbestand in der Buchungshistorie und erfassen anschließend den korrekten Istbestand.
<G-vec00218-002-s372><enter.erfassen><en> In input fields, you can enter, edit and view values.
<G-vec00218-002-s372><enter.erfassen><de> In Eingabefeldern können Sie Werte erfassen, bearbeiten und einsehen.
<G-vec00218-002-s373><enter.erfassen><en> In the base catalog, you enter the valid descriptions for the first description field.
<G-vec00218-002-s373><enter.erfassen><de> Im Basiskatalog erfassen Sie die zulässigen Bezeichnungen für das erste Bezeichnungsfeld.
<G-vec00218-002-s374><enter.erfassen><en> Cost Savings: E-commerce, even in it’s most basic and rudimentary form, addresses the cost-savings issue simply by eliminating the time and resources needed to take and manually enter offline sales orders.
<G-vec00218-002-s374><enter.erfassen><de> Kosteneinsparungen: E-Commerce, selbst in seiner einfachsten und rudimentärsten Form, löst das Problem der Kosteneinsparungen, indem ganz einfach Zeit und Ressourcen eliminiert werden, die erforderlich sind, um Offline-Aufträge anzunehmen und manuell zu erfassen.
<G-vec00218-002-s375><enter.erfassen><en> For these parts, you can only assign or enter CRO numbers that have been created in the CRO master files in the documents mentioned.
<G-vec00218-002-s375><enter.erfassen><de> Für diese Teile können Sie in den genannten Belegen nur Kommissionsnummern zuordnen oder erfassen, die in den Stammdaten der Kommissionen angelegt sind.
<G-vec00218-002-s376><enter.erfassen><en> Technicians can now enter extensive data during the job, for example on the system status via meter readings and notifications.
<G-vec00218-002-s376><enter.erfassen><de> Während des Einsatzes können die Monteure jetzt zahlreiche Daten erfassen, zum Beispiel zum Zustand der Anlage durch Messwerte und Meldungen.
<G-vec00218-002-s377><enter.erfassen><en> Value You manually enter the value.
<G-vec00218-002-s377><enter.erfassen><de> Wert Den Wert erfassen Sie manuell.
<G-vec00218-002-s378><enter.erfassen><en> For this purpose, you enter the quantity to be stocked in for each combination of storage area section, storage location and stock-in date (Reserved field).
<G-vec00218-002-s378><enter.erfassen><de> Dazu erfassen Sie zu jeder Kombination aus Lagerbereich, Lagerplatz und Einlagerungsdatum die einzulagernde Menge (Feld Reserviert).
<G-vec00218-002-s379><enter.erfassen><en> A proficient writer will be able to enter longer texts via a conventional keyboard much faster.
<G-vec00218-002-s379><enter.erfassen><de> Längere Texte wird ein geübter Datenerfasser via üblicher Tastatur bei weitem schneller erfassen können.
<G-vec00218-002-s380><enter.geben><en> There was this message that I play translated: "Good day, please enter in the Wikipedia is not content propagandistic character, or links to your personal page or pages that you are connected to Wikipedia is not a means for propaganda or publicity, no .
<G-vec00218-002-s380><enter.geben><de> Dort war folgende Nachricht, die ich übersetzt wiedergebe: "Guten Tag, geben Sie bitte in die Wikipedia keinen Inhalt propagandistischen Charakters oder Links auf Ihre private Seite oder Seiten, mit denen Sie verbunden sind.
<G-vec00218-002-s381><enter.geben><en> For a route-planning please click the appropriate link in the info-window and enter your location.
<G-vec00218-002-s381><enter.geben><de> Für eine Routenplanung klicken Sie bitte auf den entsprechenden Link im kleinen Infofenster und geben Ihren Standort an.
<G-vec00218-002-s382><enter.geben><en> If you want to exclude individual contact channels, please enter it in free text field.
<G-vec00218-002-s382><enter.geben><de> Falls Sie einzelne Kontaktwege ausschließen möchten, geben Sie diese bitte im Freitextfeld ein.
<G-vec00218-002-s383><enter.geben><en> If you send missing files or replacement files for an already running project, please enter a new version number in the zip file name (Artist_Name_V2 or Artist_Name_V3).
<G-vec00218-002-s383><enter.geben><de> Wenn Sie fehlende Dateien oder Ersatzdateien für ein bereits laufendes Projekt senden, geben Sie bitte eine neue Versionsnummer im Zip-Dateinamen an (Artist_Name_V2 oder Artist_Name_V3).
<G-vec00218-002-s384><enter.geben><en> There, you enter your access data as well as the password and confirm the payment amount, whereupon your money is transferred to SunExpress via a secure connection. You receive your ticket as well as the travel confirmation by e-mail.
<G-vec00218-002-s384><enter.geben><de> Dort geben Sie Ihre Zugangsdaten sowie das Passwort ein und bestätigen den Zahlbetrag, woraufhin Ihr Geld über eine sichere Verbindung an SunExpress überwiesen wird und Sie umgehend Ihr Ticket sowie die Reisebestätigung per E-Mail erhalten.
<G-vec00218-002-s385><enter.geben><en> You only need to enter the IP address of your DIY DNS server and save the settings.
<G-vec00218-002-s385><enter.geben><de> Als IP-Adresse geben Sie ausschließlich die IP-Adresse Ihres DIY DNS Servers an und sichern die Einstellung.
<G-vec00218-002-s386><enter.geben><en> Enter you personal details requested and we will get in contact with you right away to solve your doubts
<G-vec00218-002-s386><enter.geben><de> Geben Sie Ihre persönlichen Daten gebeten, und wir werden in Kontakt mit Ihnen sofort, um Ihre Zweifel zu lösen.
<G-vec00218-002-s387><enter.geben><en> If you wish to use a separate email address from the Administrative e-mail address for the delivery of the invoice, please enter the email address for invoice delivery in the field Finance e-mail address.
<G-vec00218-002-s387><enter.geben><de> Sollten Sie für die Rechnungsversendung eine spezielle E-Mail-Adresse wünschen, geben Sie diese bitte im Feld E-Mail-Adresse Finanzen an.
<G-vec00218-002-s388><enter.geben><en> Set wheel locks £ 32.90 * To determine the matching parts, please enter your VIN on the product page.
<G-vec00218-002-s388><enter.geben><de> Satz Radschraubensicherung 33,00 € * Zur Ermittlung der passenden Teile geben Sie bitte auf der Produktseit...
<G-vec00218-002-s389><enter.geben><en> By ordering our goods, you enter into a binding contract offer.
<G-vec00218-002-s389><enter.geben><de> Mit der Bestellung unserer Ware geben Sie ein verbindliches Vertragsangebot ab.
<G-vec00218-002-s390><enter.geben><en> Enter you FastBill Email and API Key.
<G-vec00218-002-s390><enter.geben><de> Geben Sie Ihre FastBill Email-Adresse und Ihren API-Schlüssel ein.
<G-vec00218-002-s391><enter.geben><en> From the end of 2020, passengers will use the smartphone app developed by ioki to enter their starting point and destination and receive the shuttle’s departure and arrival times.
<G-vec00218-002-s391><enter.geben><de> Ab Ende 2020 geben die Fahrgäste über die von ioki entwickelte Smartphone App Start- und Zielort ein und erhalten die Abfahrts- und Ankunftszeiten des Shuttles.
<G-vec00218-002-s392><enter.geben><en> Enter your Choeur de La Prêle username.
<G-vec00218-002-s392><enter.geben><de> Geben Sie Ihren Sportfischerverein Kraichgau e.V.-Benutzernamen ein.
<G-vec00218-002-s393><enter.geben><en> If you would like to receive the latest Henderson Global Dividend Study and other updates from Henderson Global Investors, please enter your email address below.
<G-vec00218-002-s393><enter.geben><de> Wenn Sie weitere Kommentare zum Henderson Global Dividend Index erhalten möchten, geben Sie bitte nachstehend Ihre E-Mail-Adresse an.
<G-vec00218-002-s394><enter.geben><en> If you choose to, enter a new hostname and username.
<G-vec00218-002-s394><enter.geben><de> (Optional) Geben Sie eine neue Hostname und Benutzername.
<G-vec00218-002-s395><enter.geben><en> The reactivation code will be sent to you by post. When you receive it, sign in again as usual with your e-mail address and password and then enter the reactivation code.
<G-vec00218-002-s395><enter.geben><de> Sobald Sie den Reaktivierungscode per Post erhalten haben, melden Sie sich wieder wie gewohnt mit Ihrer E-Mail-Adresse und dem Passwort an und geben danach den Reaktivierungscode ein.
<G-vec00218-002-s396><enter.geben><en> For more information about personalized animation please enter the projects section.
<G-vec00218-002-s396><enter.geben><de> Für weitere Informationen über personalisierte Animationen geben Sie bitte den Abschnitt Projekte.
<G-vec00218-002-s397><enter.geben><en> To view prices and availability, please enter Kerekegyháza Stars
<G-vec00218-002-s397><enter.geben><de> Für Preise und Verfügbarkeiten geben Sie bitte Ihre Reisedaten ein.
<G-vec00218-002-s398><enter.geben><en> Please select the category you are interested in below or enter a search word.
<G-vec00218-002-s398><enter.geben><de> Bitte treffen Sie unten in den Kategorien Ihre Auswahl oder geben einen Suchbegriff an.
<G-vec00218-002-s437><enter.gehen><en> 45 But he went out, and began to proclaim it much, and to publish the matter abroad, so that he was no longer able to enter a city openly, but was without in desert places: and they came to him from every quarter.
<G-vec00218-002-s437><enter.gehen><de> 45 Er aber ging weg und fing an, es viel kundzumachen und die Sache auszubreiten, so daß er nicht mehr öffentlich in die Stadt gehen konnte; sondern er war draußen in öden Örtern, und sie kamen von allen Seiten zu ihm.
<G-vec00218-002-s438><enter.gehen><en> Sherlock Holmes (Jonny Lee Miller) previously worked at Scotland Yard in London but then developed a drug addiction problem which made him move to New York and enter rehab.
<G-vec00218-002-s438><enter.gehen><de> Sherlock Holmes (Jonny Lee Miller) hat früher bei Scotland Yard in London gearbeitet, bekam dann aber ein Problem mit Drogenabhängigkeit, was ihn dazu zwang, nach New York zu gehen und dort eine Entziehungskur zu machen.
<G-vec00218-002-s439><enter.gehen><en> The day of the Solemnity of the Transfiguration remains linked to the memory of my venerable Predecessor, Servant of God Paul VI, who in 1978 completed his mission in this very place, here at Castel Gandolfo, and was called to enter the house of the Heavenly Father.
<G-vec00218-002-s439><enter.gehen><de> Der Tag des Festes der Verklärung bleibt eng verbunden mit der Erinnerung an meinen verehrten Vorgänger, den Diener Gottes Paul VI., der im Jahr 1978 gerade hier in Castelgandolfo seine Sendung vollendete und gerufen wurde, in das Haus des himmlischen Vaters zu gehen.
<G-vec00218-002-s440><enter.gehen><en> A separate toilet room can be used by you or your guest without having to enter one of the bedrooms.
<G-vec00218-002-s440><enter.gehen><de> Eine separate Toilette kann von Ihnen oder den Gästen benutzt werden ohne durch die Schlafzimmer gehen zu müssen.
<G-vec00218-002-s441><enter.gehen><en> If you then enter into a conversation with a concrete and current financing commitment from a bank, this underlines both your serious intention and your seriousness.
<G-vec00218-002-s441><enter.gehen><de> Wenn Sie dann mit einer konkreten und aktuellen Finanzierungszusage einer Bank ins Gespräch gehen, unterstreicht das Ihre ernste Absicht und Ihre Seriosität gleichermaßen.
<G-vec00218-002-s442><enter.gehen><en> A press release issued earlier today by Schecter Guitar Research revealed that AVENGED SEVENFOLD is scheduled to enter the studio in February to begin recording the follow-up to its 2013 album “Hail To The King”.
<G-vec00218-002-s442><enter.gehen><de> Laut einer Pressemitteilung von Schecter Guitar Research werden AVENGED SEVENFOLD ab Februar ins Studio gehen, um den Nachfolger zu ihrem 2013er Erfolgsalbum Hail To The King aufzunehmen.
<G-vec00218-002-s443><enter.gehen><en> Therefore, we need to learn to do some rethinking, and, by so doing, enter into school with Paul and John and even with Jesus Himself.
<G-vec00218-002-s443><enter.gehen><de> Wir sollten deshalb umdenken lernen und bei Paulus, Johannes und bei Jesus selbst in die Schule gehen.
<G-vec00218-002-s444><enter.gehen><en> 3 For we which have believed do enter into rest, as he said, As I have sworn in my wrath, if they shall enter into my rest: although the works were finished from the foundation of the world.
<G-vec00218-002-s444><enter.gehen><de> 3 Denn wir, die wir glauben, gehen in die Ruhe, wie er spricht:Daß ich schwur in meinem Zorn, sie sollten zu meiner Ruhe nicht kommen.
<G-vec00218-002-s446><enter.gehen><en> 44:21 Neither shall any of the priests drink wine, when they enter into the inner court.
<G-vec00218-002-s446><enter.gehen><de> 44:21 Und kein Priester soll Wein trinken, wenn sie in den inneren Vorhof gehen.
<G-vec00218-002-s447><enter.gehen><en> Formal childcare services can only help parents enter and stay in employment if they are affordable and of good quality. Further information
<G-vec00218-002-s447><enter.gehen><de> Offizielle Kinderbetreuungsdienste können die Eltern nur dabei unterstützen, einen Arbeitsplatz zu erhalten oder weiter arbeiten zu gehen, wenn sie bezahlbar und von guter Qualität sind.
<G-vec00218-002-s448><enter.gehen><en> We enter through the Zion Gate into the Armenian Quarter of the Old City and continue on to the Byzantine Cardo.
<G-vec00218-002-s448><enter.gehen><de> Wir gehen durch das Ziontor in das Armenische Viertel der Altstadt und weiter auf den byzantinischen Cardo.
<G-vec00218-002-s449><enter.gehen><en> Do not forget the indispensable plastic shoes to enter the water.
<G-vec00218-002-s449><enter.gehen><de> Vergessen Sie nicht, die unentbehrlichen Plastikschuhe ins Wasser zu gehen.
<G-vec00218-002-s450><enter.gehen><en> CityU MBA degree in Global Management is, on the other hand, valuable to people who are already holding an executive position in management, or who, as a next step in their careers, are looking to enter into an executive management position in this industry.
<G-vec00218-002-s450><enter.gehen><de> Das MBA Programm im Global Management der CityU ist von Vorteil für Menschen, die bereits im Besitz einer leitenden Position im Management sind, oder dabei sind einen weiteren Schritt in ihrer Karriere zu gehen, um später in eine leitende Management-Position zu wechseln.
<G-vec00218-002-s451><enter.gehen><en> The side doors also have a special rain rain canopy so that you are able to enter the tent dry in bad weather.
<G-vec00218-002-s451><enter.gehen><de> Die Seitentüren verfügen außerdem über ein spezielles Regenmarkise, sodass Sie bei schlechtem Wetter trocken ins Zelt gehen können.
<G-vec00218-002-s452><enter.gehen><en> Arrive at the north entrance to enter the Vatican Museums.
<G-vec00218-002-s452><enter.gehen><de> Komme am Nordeingang an, um in die vatikanischen Museen zu gehen.
<G-vec00218-002-s453><enter.gehen><en> Passing through an archway at the base of the bell tower you reach a small courtyard from which you enter the church.
<G-vec00218-002-s453><enter.gehen><de> Um ins Kloster einzutreten, muss man unter den Bogen des Glockenturms gehen.
<G-vec00218-002-s454><enter.gehen><en> This allows you to enter into price negotiations in a relaxed manner and achieve well-founded results.
<G-vec00218-002-s454><enter.gehen><de> Somit können Sie ganz entspannt in die Preisverhandlungen gehen und fundierte Ergebnisse erzielen.
<G-vec00218-002-s455><enter.gehen><en> LuvSide aimed to individuals, businesses and organizations that want to use the wind energy for its electricity production – and doesn’t want to enter into disputes with its neighbors because of the noise and shadow casts of their generator.
<G-vec00218-002-s455><enter.gehen><de> LuvSide richtet sich an Privatpersonen, Unternehmen und Organisationen, die Windenergie für ihre Stromproduktion nutzen möchten – und dabei Auseinandersetzungen mit ihren Nachbarn wegen Lärmemissionen und Schattenwurfs aus dem Weg gehen wollen.
<G-vec00218-002-s570><enter.gelangen><en> If animals eat bales of contaminated feed, the by-products can enter the human food chain via milk or meat down the road.
<G-vec00218-002-s570><enter.gelangen><de> Wenn die Tiere Ballen mit belastendem Futter fressen, können die Nebenprodukte im weiteren Verlauf über Milch oder Fleisch in die Nahrungskette des Menschen gelangen.
<G-vec00218-002-s571><enter.gelangen><en> As soon as a tube is opened, various germs can enter the tube opening just by moving through the air.
<G-vec00218-002-s571><enter.gelangen><de> Schon wenn eine Tube geöffnet wird, können alleine über die Luft verschiedene Keime in die Tubenöffnung gelangen.
<G-vec00218-002-s572><enter.gelangen><en> However, even with oil-free compressors small quantities of hydrocarbons in aerosol or gas form may enter the compressed air.
<G-vec00218-002-s572><enter.gelangen><de> Aber selbst bei ölfreien Kompressoren können geringe Mengen an Kohlenwasserstoffe in Aerosol- oder Gasform in die Druckluft gelangen.
<G-vec00218-002-s573><enter.gelangen><en> The winemaker It is responsible for the entire process of making the wine since the grapes enter, until the final product is bottled.
<G-vec00218-002-s573><enter.gelangen><de> Es ist für den gesamten Herstellungsprozess des Weines verantwortlich, da die Trauben in den Wein gelangen, bis das Endprodukt abgefüllt ist.
<G-vec00218-002-s574><enter.gelangen><en> That is why vitamin D should regularly enter the body of a pregnant woman.
<G-vec00218-002-s574><enter.gelangen><de> Deshalb sollte Vitamin D regelmäßig in den Körper einer schwangeren Frau gelangen.
<G-vec00218-002-s575><enter.gelangen><en> And with them useful substances and vitamins, which are constantly lacking, will enter the body.
<G-vec00218-002-s575><enter.gelangen><de> Und mit ihnen werden nützliche Substanzen und Vitamine, die ständig fehlen, in den Körper gelangen.
<G-vec00218-002-s576><enter.gelangen><en> Keep your phone close to your helmet, then tap the ‘helmet’ column on the app device page to enter searching mode, you will then be prompted to go to Bluetooth settings to find the helmet to connect.
<G-vec00218-002-s576><enter.gelangen><de> Halten Sie das Smartphone nahe an den Helm, tippen Sie auf das Helmsymbol in der App um in den „Scanning“-Modus zu gelangen und wählen Sie die Bluetooth-Verbindung des Smartphones sobald Sie dazu aufgefordert werden.
<G-vec00218-002-s577><enter.gelangen><en> Environmental precautions Do not let product enter drains.
<G-vec00218-002-s577><enter.gelangen><de> Produkt nicht unkontrolliert in die Umwelt gelangen lassen.
<G-vec00218-002-s578><enter.gelangen><en> In addition, Ninja Ransomware can easily enter a system if a user opens a spam email attachment or has other malicious applications installed on the computer.
<G-vec00218-002-s578><enter.gelangen><de> Außerdem kann Ninja Ransomware ganz einfach in ein System gelangen, wenn ein Benutzer einen Spam-E-Mail-Anhang öffnet oder andere bösartige Anwendungen auf dem Computer installiert hat.
<G-vec00218-002-s579><enter.gelangen><en> It helps to quickly break down fats that enter the body with food, and also speeds up the metabolism in the body.
<G-vec00218-002-s579><enter.gelangen><de> Es hilft, Fette, die mit Nahrung in den Körper gelangen, schnell abzubauen und beschleunigt auch den Stoffwechsel im Körper.
<G-vec00218-002-s580><enter.gelangen><en> Before the plants enter the tube, the crops are sprayed.
<G-vec00218-002-s580><enter.gelangen><de> Bevor die Pflanzen in die Röhre gelangen, werden die Pflanzen besprüht.
<G-vec00218-002-s581><enter.gelangen><en> In this case, a small amount of medicine can enter the systemic circulation.
<G-vec00218-002-s581><enter.gelangen><de> In diesem Fall kann eine kleine Menge Arzneimittel in den systemischen Kreislauf gelangen.
<G-vec00218-002-s582><enter.gelangen><en> It can quickly and accurately identify evasive threats before they enter your network.
<G-vec00218-002-s582><enter.gelangen><de> Die Technologie erkennt evasive Malware schnell und zuverlässig, bevor diese in Ihr Netzwerk gelangen kann.
<G-vec00218-002-s583><enter.gelangen><en> With a third filter specification, MEYLE offers another solution for even cleaner air inside the vehicle: A special coating on the new biofunctional MEYLE-ORIGINAL cabin filter ensures that the driver and passengers are not only protected from dust, pollen, soot and gases, but also that bacteria do not enter the cabin.
<G-vec00218-002-s583><enter.gelangen><de> Mit einer dritten Filterspezifikation bietet MEYLE eine weitere Lösung für noch reinere Luft im Fahrzeuginneren: Eine spezielle Schicht sorgt beim neuen biofunktionalen MEYLE-ORIGINAL-Innenraumfilter dafür, dass Fahrer und Insassen nicht nur vor Staub, Pollen, Ruß und Gasen geschützt werden, sondern zudem auch Bakterien nicht in den Innenraum gelangen.
<G-vec00218-002-s584><enter.gelangen><en> Most of these energies can only enter the physical body through the heart chakra.
<G-vec00218-002-s584><enter.gelangen><de> Die meisten dieser Energien können nur durch das Herzchakra in den physischen Körper gelangen.
<G-vec00218-002-s585><enter.gelangen><en> CAUTION: Ensure that Primary Recreation Soft Remover does not enter the eyes! Storage:
<G-vec00218-002-s585><enter.gelangen><de> ACHTUNG: Primary Recreation Soft Remover darf nicht in das Augeninnere gelangen.
<G-vec00218-002-s586><enter.gelangen><en> This is why Jesus had to tell the chief priests, “who did not understand these things”, that “a harlot would enter the kingdom of God before them”.
<G-vec00218-002-s586><enter.gelangen><de> Gerade aus diesem Grund musste Jesus den Hohenpriestern, die »diese Dinge nicht verstanden«, sagen, dass »Dirnen eher in das Reich Gottes gelangen als sie«.
<G-vec00218-002-s587><enter.gelangen><en> The level gauge and the hollow screw are designed in a manner that flames may not enter the measured space between them.
<G-vec00218-002-s587><enter.gelangen><de> Messstab und Verschraubung sind so gestaltet, dass Flammen nicht in den gemessenen Raumbereich gelangen können.
<G-vec00218-002-s588><enter.gelangen><en> These toxic substances then enter our food chain.
<G-vec00218-002-s588><enter.gelangen><de> Deshalb kann auch der häufig giftige Abfall in unsere Nahrungskette gelangen.
<G-vec00218-002-s589><enter.kommen><en> 38 I will purge out the rebels from among you, and those who transgress against me; I will bring them out of the land where they sojourn, but they shall not enter the land of Israel. Then you will know that I am the LORD.
<G-vec00218-002-s589><enter.kommen><de> Ich führe sie zwar aus dem Land, in dem sie als Fremde leben, heraus, in das Land Israel aber werden sie nicht kommen; dann werdet ihr erkennen, daß ich der Herr bin.
<G-vec00218-002-s590><enter.kommen><en> We were not permitted to enter the barracks during the day.
<G-vec00218-002-s590><enter.kommen><de> Wir durften nicht wÃhrend des Tages in die Baracken kommen.
<G-vec00218-002-s591><enter.kommen><en> In these cases we talk about health threatening contaminants, which enter the food chain unintentionally, while during food processing the same compound are sometimes added deliberately.
<G-vec00218-002-s591><enter.kommen><de> In diesen Fällen spricht man über gesundheits- bedrohenden Kontaminanten, also über Verschmutzungsstoffe, welche ungewollt in unsere Lebensmittelkette kommen.
<G-vec00218-002-s592><enter.kommen><en> 11 Let us labour therefore to enter into that rest, lest any man fall after the same example of unbelief.
<G-vec00218-002-s592><enter.kommen><de> 11 Bemühen wir uns also, in jenes Land der Ruhe zu kommen, damit niemand aufgrund des gleichen Ungehorsams zu Fall kommt.
<G-vec00218-002-s593><enter.kommen><en> Schools, offices and shops are closed, since students and workers cannot enter the center", say Fides sources. "Demonstrations continue in the suburbs.
<G-vec00218-002-s593><enter.kommen><de> Schulen, Büros und Geschäfte sind geschlossen, da viele Schuler und Angestellte nicht ins Zentrum kommen können“, so der Beobachter weiter, “Die Demonstrationen werden in den Stadtrandgebieten fortgesetzt.
<G-vec00218-002-s594><enter.kommen><en> After the final blessing those in attendance made a long line and patiently waited their turn to enter the Shrine to greet Mary.
<G-vec00218-002-s594><enter.kommen><de> Nach dem Schluss-Segen bildeten sich sofort lange Schlangen, in denen die Menschen geduldig darauf warteten, ins Heiligtum zu kommen und die Gottesmutter zu grüßen.
<G-vec00218-002-s595><enter.kommen><en> Finally, the workshop will look at the “hidden back door” through which GMOs enter Europe, as animal feed.
<G-vec00218-002-s595><enter.kommen><de> Schliesslich wird im Workshop auch die „versteckte Hintertür“ betrachtet, durch die GVOs – als Tierfutter – nach Europa kommen.
<G-vec00218-002-s596><enter.kommen><en> The oppressor has stretched out his hand on all her desirable things: for she has seen the Gentiles entering into her sanctuary, concerning whom you did command that they should not enter into your congregation.
<G-vec00218-002-s596><enter.kommen><de> 10 Der Feind hat seine Hand an alle ihre Kleinode gelegt; denn sie musste zusehen, daß die Heiden in ihr Heiligtum gingen, von denen du geboten hast, sie sollen nicht in die Gemeinde kommen.
<G-vec00218-002-s597><enter.kommen><en> Better. It’s extremely disappointing to enter a hostel that looks really nice from the outside and looked very promising online, only to find that it lacks certain very necessary things.
<G-vec00218-002-s597><enter.kommen><de> Es ist so enttäuschend, in ein Hostel zu kommen, dass von außen einen tollen Eindruck macht und wunderbar sauber ist und die Mitarbeiter freundlich sind, nur um dann festzustellen, dass die Schlafzimmer eine Katastrophe sind.
<G-vec00218-002-s598><enter.kommen><en> And your eyes will see the eyes of the king of Babylon, and his mouth will speak with your mouth, and you will enter into Babylon.
<G-vec00218-002-s598><enter.kommen><de> Auge in Auge wirst du den König von Babel sehen und von Mund zu Mund wird er mit dir reden und nach Babel wirst du kommen.
<G-vec00218-002-s599><enter.kommen><en> We enter mortality not to float with the moving currents of life but with the power to think, to reason, and to achieve.
<G-vec00218-002-s599><enter.kommen><de> Wir kommen nicht in die Welt, um uns in den unruhigen Strömungen des Lebens treiben zu lassen, sondern mit einem Denkvermögen, Vernunftbegabung und der Fähigkeit, etwas zu leisten.
<G-vec00218-002-s600><enter.kommen><en> 2 A bastard shall not enter into the assembly of Yahweh; even to the tenth generation shall none of his enter into the assembly of Yahweh.
<G-vec00218-002-s600><enter.kommen><de> 2 Einer, dem die Hoden zerstoßen sind oder die Harnröhre abgeschnitten ist, darf nicht in die Versammlung des HERRN kommen.
<G-vec00218-002-s601><enter.kommen><en> If you don’t require a visa to enter Canada, you will still need to meet specific requirements.
<G-vec00218-002-s601><enter.kommen><de> Wenn du kein Visum benötigst, um nach Kanada zu kommen, musst du noch spezifische Anforderungen erfüllen.
<G-vec00218-002-s602><enter.kommen><en> 1 He that is wounded in the stones, or hath his privy member cut off, shall not enter into the assembly of the LORD.
<G-vec00218-002-s602><enter.kommen><de> 1 23:2 Es soll kein Zerstoßener noch Verschnittener in die Gemeinde des HERRN kommen.
<G-vec00218-002-s603><enter.kommen><en> When glucose can’t enter the cells, it builds up in the blood.
<G-vec00218-002-s603><enter.kommen><de> Im weiteren Verlauf kann es sogar zur vollständigen Zerstörung der Zellen und damit zum Insulinmangel kommen.
<G-vec00218-002-s604><enter.kommen><en> Wait a few seconds and you will enter the final configuration screens. Choose your language, timezone and a hostname for your Raspberry Pi (default is “osmc”).
<G-vec00218-002-s604><enter.kommen><de> Warten Sie einige Sekunden und Sie kommen zu den letzten Schritten der OSMC-Einstellungen: Wählen Sie Ihre Sprache, Zeitzone und einen Hostnamen für Ihren Raspberry Pi (Der Standard ist „osmc“).
<G-vec00218-002-s605><enter.kommen><en> The filling is usually done in a closed filling equipment, and it is required that all media and packaging which enter the filling equipment must be aseptically treated, and the surface of the filling equipment must be aseptically processed to ensure whole filling environment is aseptic.
<G-vec00218-002-s605><enter.kommen><de> Die Füllung wird normalerweise in einer geschlossenen füllenden Ausrüstung getan, und es wird angefordert, dass alle Medien und das Verpacken, die die füllende Ausrüstung kommen, aseptisch behandelt werden müssen, und die Oberfläche der füllenden Ausrüstung muss aseptisch verarbeitet werden, um sicherzustellen, dass ganze füllende Umwelt aseptisch ist.
<G-vec00218-002-s607><enter.kommen><en> The fake goods often enter the country as individual consignments, rather than in containers.
<G-vec00218-002-s607><enter.kommen><de> Anstatt ganzer Container kommen die Fälschungen heute oft als Einzelsendung ins Land.
<G-vec00218-002-s665><enter.tragen><en> Click on “Forgot Your Password” or “Forgot Your Username” on the login page and enter the requested data.
<G-vec00218-002-s665><enter.tragen><de> Klicken Sie auf "Forgot Your Password" or "Forgot Your Username" auf der Login-Seite und tragen Sie die angeforderten Daten ein.
<G-vec00218-002-s666><enter.tragen><en> Please enter your address
<G-vec00218-002-s666><enter.tragen><de> Bitte tragen Sie Ihre E-Mail Adresse ein.
<G-vec00218-002-s667><enter.tragen><en> password, please enter your email address or username below
<G-vec00218-002-s667><enter.tragen><de> Um ein neues Passwort zu erhalten, tragen Sie unten bitte Ihren Benutzernamen ein.
<G-vec00218-002-s668><enter.tragen><en> Forgotten your password? To reset your password, please enter your username or email address below.
<G-vec00218-002-s668><enter.tragen><de> Wenn Sie Ihr Passwort ändern wollen tragen Sie bitte Ihre aktuellen Logindaten sowie das neue Passwort ein.
<G-vec00218-002-s669><enter.tragen><en> Open your web browser and enter the IP address of your D-Link access point in the address bar.
<G-vec00218-002-s669><enter.tragen><de> Öffnen Sie Ihren Internet-Browser und tragen Sie die IP-Adresse des kabellosen Routers oder Access Points ein.
<G-vec00218-002-s670><enter.tragen><en> Group attribute: Enter the LDAP attribute that maps to a group’s name.
<G-vec00218-002-s670><enter.tragen><de> Tragen Sie das LDAP-Attribut ein, das mit den Gruppenbezeichnungen abgeglichen wird.
<G-vec00218-002-s671><enter.tragen><en> Simply enter your email address in the form field and click "Subscribe".
<G-vec00218-002-s671><enter.tragen><de> Tragen Sie einfach Ihre E-Mail-Adresse in das Formularfeld ein und klicken dann auf "Abonnieren".
<G-vec00218-002-s672><enter.tragen><en> Choose one of the four airports above, then enter your travel details and we will immediately receive your parking space reservation.
<G-vec00218-002-s672><enter.tragen><de> Wählen Sie einfach in den oberen Buttons einen der vier Flughäfen aus, tragen Sie Ihre Reisedaten ein und sofort landet Ihre Parkplatzreservierung direkt bei uns.
<G-vec00218-002-s673><enter.tragen><en> Please enter a valid e-mail address under “Meine Weiterleitungsadresse”.
<G-vec00218-002-s673><enter.tragen><de> Bitte tragen Sie eine gültige E-Mailadresse unter „Meine Weiterleitungsadresse" ein.
<G-vec00218-002-s674><enter.tragen><en> If you have objects to move which are not on the list, then please enter this on your own, and describe as well as possible, giving dimensions.
<G-vec00218-002-s674><enter.tragen><de> Wenn Sie Umzugsgut haben, welches nicht auf der Liste steht, dann tragen Sie es bitte selbst ein und beschreiben es so gut wie möglich mit Maßangaben.
<G-vec00218-002-s675><enter.tragen><en> Please fill in the application for admission as a guest student and the guest student certificate (important: be sure to give your email address) and enter the courses you wish to attend.
<G-vec00218-002-s675><enter.tragen><de> Antrag auf Gasthörerschaft: Bitte füllen Sie den Antrag auf Gasthörerschaft und den Gasthörerschein aus (wichtig: Email-Adresse) und tragen Sie die Kurse ein, die Sie besuchen möchten.
<G-vec00218-002-s676><enter.tragen><en> Enter your Perfect Privacy login credentials, optionally check Remember this password and click on Create.
<G-vec00218-002-s676><enter.tragen><de> Tragen Sie Ihre Perfect Privacy Zugangsdaten ein und aktivieren Sie die Checkbox Dieses Kennwort speichern und klicken Sie auf Erstellen.
<G-vec00218-002-s677><enter.tragen><en> Please enter your username and password and click Login. Welcome, please login
<G-vec00218-002-s677><enter.tragen><de> Tragen Sie bitte die Kombination aus Partner-Nummer und Passwort ein und klicken anschließend auf Einloggen.
<G-vec00218-002-s678><enter.tragen><en> Please enter the result in the text box.
<G-vec00218-002-s678><enter.tragen><de> Bitte tragen Sie das Ergebnis in das Textfeld ein.
<G-vec00218-002-s679><enter.tragen><en> Enter your e-mail address in the field which displayed there and click on "Request a Password".
<G-vec00218-002-s679><enter.tragen><de> Tragen Sie Ihre E-Mail-Adresse in das dort angezeigte Formular ein und klicken Sie auf „Passwort anforden“.
<G-vec00218-002-s680><enter.tragen><en> Please enter your username or email address.
<G-vec00218-002-s680><enter.tragen><de> Tragen Sie Ihren Benutzernamen oder Ihre bestätigte E-Mail-Adresse ein.
<G-vec00218-002-s681><enter.tragen><en> If you want to use this service, simply enter your email address and your name and address.
<G-vec00218-002-s681><enter.tragen><de> Wenn Sie diesen Service nutzen möchten, tragen Sie einfach Ihre E-Mail-Adresse sowie Ihren Namen und Adresse ein.
<G-vec00218-002-s682><enter.tragen><en> Enter a url to a logo image.
<G-vec00218-002-s682><enter.tragen><de> Tragen Sie eine Logo-URl ein.
<G-vec00218-002-s683><enter.tragen><en> Then enter the name, postcode or town in the search mask.
<G-vec00218-002-s683><enter.tragen><de> Dann tragen Sie den Namen in die Suchmaske ein.
<G-vec00218-002-s684><enter.treten><en> Furthermore, the EU adopted stricter rules on pesticide approval in November 20092 and they will enter into force in June 2011.
<G-vec00218-002-s684><enter.treten><de> Außerdem erließ die EU im November 2009 strengere Vorschriften für die Zulassung von Pestiziden2, die im Juni 2011 in Kraft treten werden.
<G-vec00218-002-s685><enter.treten><en> With direct or indirect references to stranger InterNet sides ("links"), which outside of the area of responsibility of the author lies, an adhesion obligation exclusively in the case would enter into force, in which the author of the contents of knowledge has and it him technically possible and reasonable would be to prevent the use in the case of illegal contents.
<G-vec00218-002-s685><enter.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00218-002-s686><enter.treten><en> Every individual human being in said community has a right to recognition, by the community, of her or his social rights, which are necessary for the realization of her or his dignity and for the possibility to enter into contact with any Other.
<G-vec00218-002-s686><enter.treten><de> Jeder individuelle Mensch in dieser Gemeinschaft hat Recht auf Anerkennung, durch die Gemeinschaft, von ihren oder seinen sozialen Rechten, die notwendig sind für die Verwirklichung ihrer oder seiner Würde und für die Möglichkeit, mit jedwedem Anderen in Verbindung zu treten.
<G-vec00218-002-s687><enter.treten><en> And some women enter into the image of the patient and, in spite of everything, remain in bed for a long time.
<G-vec00218-002-s687><enter.treten><de> Und manche Frauen treten in das Bild des Patienten ein und bleiben trotz allem lange im Bett.
<G-vec00218-002-s688><enter.treten><en> Be as open as the sky so that nothing that wants to enter you is left hanging inside you.
<G-vec00218-002-s688><enter.treten><de> Sei himmelweit offen, dass nichts in dir hängen bleibt, was in dich treten will.
<G-vec00218-002-s689><enter.treten><en> The amendments shall enter into force after being ratified by all the Member States in accordance with their respective constitutional requirements.
<G-vec00218-002-s689><enter.treten><de> Diese Bestimmungen treten nach Zustimmung der Mitgliedstaaten im Einklang mit ihren jeweiligen verfassungsrechtlichen Vorschriften in Kraft.
<G-vec00218-002-s690><enter.treten><en> Biemann’s artistic approach creates a new way of organizing knowledge and provides a platform for all actors upon which they can leave aside their classical roles as victim and enter into a differentiated dialogue on a par with the beholders.
<G-vec00218-002-s690><enter.treten><de> Biemanns künstlerische Vorgehensweise schafft eine neue Wissensorganisation und ermöglicht einen Blick auf das Geschehen, so dass „Involvierten“ eine Plattform eröffnet wird, auf der sie als Akteure die klassisch zugeschriebenen „Opferrollen“ verlassen und mit den BetrachterInnen in einen gleichwertigen differenzierten Dialog treten können.
<G-vec00218-002-s691><enter.treten><en> In case of direct or indirect references to external websites (‘hyper-links’) that lie outside WuB’s sphere of responsibility, a liability obligation would only enter into effect if WuB is aware of the contents in question, and if it would have been technically possible and feasible for WuB to prevent usage, with regard to illegal contents.
<G-vec00218-002-s691><enter.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches der WuB liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem die WuB von den Inhalten Kenntnis hat und es der WuB technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00218-002-s692><enter.treten><en> But there are times – especially when it coincides with a revolt of adverse forces who don't want to give up their domain and enter into battle with all their might – when I must admit it's hard....
<G-vec00218-002-s692><enter.treten><de> Doch manchmal – besonders wenn es mit einer Aufruhr der gegnerischen Kräfte zusammenfällt, die nicht wollen, daß man sie ihres Gebiets beraubt, und die mit aller Macht in den Kampf treten –, dann, muss ich gestehen, ist es hart...
<G-vec00218-002-s693><enter.treten><en> Adam will never be worthy to enter into the Holiest of All.
<G-vec00218-002-s693><enter.treten><de> Adam wird nie ehrenswert sein in das Allerheiligste zu treten.
<G-vec00218-002-s694><enter.treten><en> However, the users enter into a direct contractual relationship with DISQUS, in the context of which DISQUS processes the comments of the users and is a contact for any deletion of the user’s data.
<G-vec00218-002-s694><enter.treten><de> Die Nutzer treten jedoch in eine unmittelbare Vertragsbeziehung mit DISQUS, in deren Rahmen DISQS die Kommentare der Nutzer verarbeitet und ein Ansprechpartner für etwaige Löschung der Daten der Nutzer ist.
<G-vec00218-002-s695><enter.treten><en> 3Any amendment to Articles 1 to 25 shall enter into force, in respect of those Parties which have accepted it, on the first day of the month following the expiration of a period of one month after the date on which three Parties, including at least two member States of the Council of Europe, have informed the Secretary General that they have accepted it.
<G-vec00218-002-s695><enter.treten><de> 3Änderungen der Artikel 1 bis 25 treten für die Vertragsparteien, die sie angenommen haben, am ersten Tag des Monats in Kraft, der auf einen Zeitabschnitt von einem Monat nach dem Tag folgt, an dem drei Vertragsparteien, darunter mindestens zwei Mitgliedstaaten des Europarats, dem Generalsekretär mitgeteilt haben, daß sie sie angenommen haben.
<G-vec00218-002-s696><enter.treten><en> Through their direct gaze out of the picture we enter into a dialogue with them.
<G-vec00218-002-s696><enter.treten><de> Durch ihren direkten Blick aus dem Bild heraus, treten wir mit ihnen in ein Zwiegespräch.
<G-vec00218-002-s697><enter.treten><en> Children like pinscher, but when there is a struggle for the attention of the owners, dogs enter into an open confrontation, pulling the blanket over themselves.
<G-vec00218-002-s697><enter.treten><de> Kinder wie Pinscher, aber wenn es einen Kampf für die Aufmerksamkeit der Besitzer gibt, treten Hunde in eine offene Konfrontation und ziehen die Decke über sich selbst.
<G-vec00218-002-s698><enter.treten><en> 4.4 These T&C enter into force on 1 October 2014.
<G-vec00218-002-s698><enter.treten><de> 4.4 Diese AGB treten ab 1.10.2014 in Kraft.
<G-vec00218-002-s699><enter.treten><en> These funding regulations will enter into force on the day of their publication in the Federal Gazette (Bundesanzeiger).
<G-vec00218-002-s699><enter.treten><de> Diese Förderrichtlinien treten mit dem Tage der Veröffentlichung im Bundesanzeiger in Kraft.
<G-vec00218-002-s700><enter.treten><en> In May 2002, an amendment was made to the law on technical requirements for products, some elements of which enter into force on accession.
<G-vec00218-002-s700><enter.treten><de> Im Mai 2002 wurde das Gesetz über die technischen Anforderungen an Produkte geändert, von dem bestimmte Elemente zum Zeitpunkt des Beitritts in Kraft treten.
<G-vec00218-002-s701><enter.treten><en> The close coordination of perception and the imbuing and supplementing of potential semantic meaning allows sensual abilities and conceptual thinking/imagining to enter into a relationship of osmotic transfer.
<G-vec00218-002-s701><enter.treten><de> Die Engführung von Wahrnehmung und potentieller semantischer Aufladung und Ergänzung lässt sinnliches Vermögen und begriffliches Denken/Vorstellen in ein osmotisches Verhältnis treten.
<G-vec00218-002-s702><enter.treten><en> Subsequently the Company intends to enter into discussions with the common representative about a restructuring of the bond.
<G-vec00218-002-s702><enter.treten><de> Im Anschluss daran plant die Gesellschaft mit dem gemeinsamen Vertreter der Anleihegläubiger in Verhandlungen über die Restrukturierung der Anleihe zu treten.
<G-vec00239-002-s076><enter.betreten><en> E Enter - you enter a town, castle etc.
<G-vec00239-002-s076><enter.betreten><de> E Eintreten - Man betritt eine Stadt, Burg etc.
<G-vec00239-002-s077><enter.betreten><en> Walk to the right and climb up the ladder to enter the building.
<G-vec00239-002-s077><enter.betreten><de> Dort klettert man die Feuerleiter hoch und betritt das Gebäude.
<G-vec00239-002-s078><enter.betreten><en> From the streets you enter each shop or house.
<G-vec00239-002-s078><enter.betreten><de> Von den Straßen aus betritt man einzelne Geschäfte oder Wohnhäuser.
<G-vec00239-002-s079><enter.betreten><en> Yet when visitors enter the white cube, the first thing they see is, well, nothing.
<G-vec00239-002-s079><enter.betreten><de> Betritt man den White Cube sieht man allerdings erst einmal – nichts.
<G-vec00239-002-s080><enter.betreten><en> We enter it by the district of San Roque, with a charming hermitage on our left, until we reach the old district.
<G-vec00239-002-s080><enter.betreten><de> Man betritt sie durch das Stadtviertel San Roque, das auf der linken Seite eine hübsche Einsiedelei besitzt und kommt in die Altstadt.
<G-vec00239-002-s081><enter.betreten><en> At the beginning you enter through a light wall, a sterile world, concreted, laid out with astroturf and restricted by a transparent plastic wall.
<G-vec00239-002-s081><enter.betreten><de> Anfangs betritt man durch eine Lichtwand eine sterile Welt, zubetoniert, mit Kunstrasen ausgelegt und durch eine transparente Plastikwand begrenzt.
<G-vec00239-002-s082><enter.betreten><en> Enter the Bronze Age with this armor accessory.
<G-vec00239-002-s082><enter.betreten><de> Betritt die Bronzezeit mit diesem Rüstungszubehör.
<G-vec00239-002-s083><enter.betreten><en> When you enter this home, one can immediately notice the well planned architecture, with its many good and modern space solutions.
<G-vec00239-002-s083><enter.betreten><de> Betritt man ihr neues Haus spürt man in den guten und klugen Raumlösungen sofort, wie geschickt es geplant wurde.
<G-vec00239-002-s084><enter.betreten><en> Hack computer terminals: Enter a virtual world to escape mazes, battle in arenas, and race to find the code.
<G-vec00239-002-s084><enter.betreten><de> • Hacke Computerterminals – Betritt eine virtuelle Welt, um aus Labyrinthen zu entkommen, kämpfe in Arenen, und finde so schnell wie möglich den Code.
<G-vec00239-002-s085><enter.betreten><en> From the comfortable and high-quality living room/kitchen (designer kitchen of Bruno Berger) you enter the south-facing loggia, from where you can enjoy the sun above the roofs of the beautiful city of Freilassing.
<G-vec00239-002-s085><enter.betreten><de> Von der gemütlichen und hochwertig eingerichteten Wohnküche (Designerküche von Bruno Berger) betritt man die südseitig gelegene Loggia, von der aus man die Sonne über den Dächern der schönen Stadt Freilassing genießen kann.
<G-vec00239-002-s086><enter.betreten><en> 8And when the prince shall enter, he shall go in by the way of the porch of the gate, and he shall go forth by the way thereof.
<G-vec00239-002-s086><enter.betreten><de> 8 Wenn der Fürst den Torbau betritt, soll er ihn durch die Vorhalle betreten und auf dem gleichen Weg muss er wieder hinausgehen.
<G-vec00239-002-s087><enter.betreten><en> From here there are four steps down the the first floor of the villa, you enter into a large l-shaped covered naya with lovely views and ample space for relaxing and alfresco dining.
<G-vec00239-002-s087><enter.betreten><de> Von hier aus gibt es vier Schritte im ersten Stock der Villa, man betritt eine große l-förmige überdachte Naya mit schöner Aussicht und reichlich Platz zum Entspannen und Essen im Freien.
<G-vec00239-002-s088><enter.betreten><en> But then, enter The Gaia Effect.
<G-vec00239-002-s088><enter.betreten><de> Doch nun betritt der Gaia Effekt die Szene.
<G-vec00239-002-s089><enter.betreten><en> There are also MMO Racing games in which you have to take on other players in all kinds of motor and car racing championships, and MMO first-person shooter games in which you enter a dangerous arena and shoot down your opponents alone or as part of a team.
<G-vec00239-002-s089><enter.betreten><de> Es gibt auch MMO-Rennspiele, in denen man sich mit anderen Spielern in Motor- und Autorennen messen muss, und MMO-Ego-Shooterspiele, in denen man eine gefährliche Arena betritt und seine Gegner allein oder als Teil eines Teams abschießt.
<G-vec00239-002-s090><enter.betreten><en> And then you enter a restaurant and almost freeze to death.
<G-vec00239-002-s090><enter.betreten><de> Dann betritt man ein Restaurant und erfriert wieder fast.
<G-vec00239-002-s091><enter.betreten><en> Enter the magic world.
<G-vec00239-002-s091><enter.betreten><de> Betritt die magische Welt.
<G-vec00239-002-s092><enter.betreten><en> Description Deep in the wilds of Siberia lies a forest that no man will enter, where a Soviet expedition vanished without a trace.
<G-vec00239-002-s092><enter.betreten><de> Xbox One Beschreibung Tief in der Wildnis Sibiriens liegt ein Wald, den niemand betritt und in dem eine sowjetische Expedition verschwunden ist.
<G-vec00239-002-s093><enter.betreten><en> When you enter the cozy lounges in the family farm just makes you feel relaxed and at ease.
<G-vec00239-002-s093><enter.betreten><de> Schon wenn man die gemütlichen Stuben im Erbhof betritt fühlt man sich einfach entspannt und wohl.
<G-vec00239-002-s094><enter.betreten><en> This ensures that if the software has been automated, it will only enter or exit trades that match the preferences as set out by the trader.
<G-vec00239-002-s094><enter.betreten><de> Dies stellt sicher, dass die Software, wenn sie automatisiert wurde, nur Trades betritt oder beendet, die den vom Trader festgelegten Präferenzen entsprechen.
<G-vec00239-002-s286><enter.eingehen><en> Since Christ’s Death on the Cross and his Resurrection constitute the content of the daily life of the Church (25) and the pledge of his eternal Passover, (26) the Liturgy has as its first task to lead us untiringly back to the Easter pilgrimage initiated by Christ, in which we accept death in order to enter into life. 7.
<G-vec00239-002-s286><enter.eingehen><de> Da der Tod Christi am Kreuze und seine Auferstehung den Inhalt des täglichen Lebens der Kirche[25] und das Unterpfand ihres ewigen Ostern[26] bilden, hat die Liturgie als erste Aufgabe, uns unermüdlich auf den österlichen Weg zu führen, den uns Christus eröffnet hat und auf dem man es annimmt zu sterben, um in das Leben einzugehen.
<G-vec00239-002-s240><enter.eintragen><en> *If you are signing the agreement on behalf of a company, you may enter the company’s name in the Full Name field.
<G-vec00239-002-s240><enter.eintragen><de> *Wenn Sie die Vereinbarung im Auftrag eines Unternehmens unterzeichnen, sollten Sie den Unternehmensnamen in das Feld "Name" eintragen.
<G-vec00239-002-s388><enter.geben><en> Set wheel locks £ 32.90 * To determine the matching parts, please enter your VIN on the product page.
<G-vec00239-002-s388><enter.geben><de> Satz Radschraubensicherung 33,00 € * Zur Ermittlung der passenden Teile geben Sie bitte auf der Produktseit...
<G-vec00509-002-s532><enter.in><en> Through a glass door you enter the open plan living-dining-kitchen area with big sliding glass doors allowing an unobstructed view out onto the lake and far out over the gentle landscape.
<G-vec00509-002-s532><enter.in><de> Durch eine Glastür gelangt man in den offenen Wohn-Ess-Küchenbereich, der über die gesamte Länge des Raums durch Glasschiebetüren den Blick auf den See frei gibt.
<G-vec00509-002-s533><enter.in><en> According to a decree by President Alexander Lukaschenko, the new bank notes and coins, which have been stored in the national bank’s safes since 2008, will enter circulation on this date.
<G-vec00509-002-s533><enter.in><de> Gemäß dem entsprechenden Erlass von Präsident Alexander Lukaschenko kommen ab diesem Zeitpunkt jene neuen Banknoten und Münzen in Umlauf, die seit 2008 in den Speichern der Nationalbank auf ihren Einsatz warten.
<G-vec00509-002-s534><enter.in><en> Back then, the most accurate timekeeping devices were mechanical stopwatches, but technological advances have seen electronic clocks, crystal oscillators, atomic clocks and GPS timing enter the world of Olympic timekeeping enabling it to become ever more accurate and precise.
<G-vec00509-002-s534><enter.in><de> Damals waren die genauesten Zeitmesser mechanische Stoppuhren, aber technologische Fortschritte haben elektronische Uhren, Quarzoszillatoren, Atomuhren und GPS-Timing in die Welt der olympischen Zeitmessung ermöglicht es, immer genauer und präziser zu sehen.
<G-vec00509-002-s535><enter.in><en> Traditional print finishing companies, wishing to enter new markets, have comfort and confidence in the Presto II, because of its future proofed design and capabilities.
<G-vec00509-002-s535><enter.in><de> Wer bis heute mehr in der traditionellen Weiterverarbeitung tätig ist, aber in die neuen, attraktiven Märkte einsteigen will, hat mit dem Presto II ideale Voraussetzungen.
<G-vec00509-002-s536><enter.in><en> 7 And when they came to the border of Mysia, they tried to enter Bithynia, but the Spirit of Jesus would not permit them.
<G-vec00509-002-s536><enter.in><de> Apg 16,7 Auch als sie in die Nähe von Mysien kamen und weiter nach Norden in die Provinz Bithynien reisen wollten, erlaubte es ihnen der Geist Jesu nicht.
<G-vec00509-002-s537><enter.in><en> Empirical studies recurrently show that applicants with a migration background (thus also third-country nationals) are subject to discrimi-nation when they enter the labour market or look for a new job.
<G-vec00509-002-s537><enter.in><de> Wiederholt weisen Studien nach, dass Bewerberinnen und Bewerber mit Migrationshintergrund (also auch Drittstaatsangehörige) beim Eintritt in den Arbeitsmarkt oder bei der Suche nach einem neuen Arbeitsplatz Diskriminierung erfahren.
<G-vec00509-002-s538><enter.in><en> If you’re connecting to a secure server you must enter the server address according to the following syntax:
<G-vec00509-002-s538><enter.in><de> Wenn Sie eine Verbindung mit einem sicheren Server herstellen, müssen Sie die Portnummer in der Serveradresse angeben.
<G-vec00509-002-s539><enter.in><en> Per the Visa Waiver Program (VWP) requirements, all VWP travelers must obtain an electronic travel authorization prior to boarding a travel carrier to enter the United States.
<G-vec00509-002-s539><enter.in><de> Gemäß den Bestimmungen des Visa Waiver Program (VWP) müssen alle Reisenden vor Antritt der Reise eine elektronische Reisegenehmigung erhalten, um in die Vereinigten Staaten einreisen zu dürfen.
<G-vec00509-002-s540><enter.in><en> The Pentagon said the incident happened at 10 a.m. local time Thursday in international waters while the Boxer was transiting the waterway to enter the Persian Gulf.
<G-vec00509-002-s540><enter.in><de> Das Pentagon teilte mit, dass der Vorfall um 10 Uhr Ortszeit am Donnerstag in internationalen Gewässern geschah, während der USS-Boxer die Wasserstraße passierte, um in den Golf einzudringen.
<G-vec00509-002-s541><enter.in><en> 5Jesus answered, ‘Very truly, I tell you, no one can enter the kingdom of God without being born of water and Spirit.
<G-vec00509-002-s541><enter.in><de> Wahrlich, wahrlich, ich sage dir: Es sei denn, dass jemand geboren wird aus Wasser und Geist, so kann er nicht in das Reich Gottes hineinkommen.
<G-vec00509-002-s542><enter.in><en> They themselves did not enter the praetorium to avoid being defiled, since they wanted to eat the paschal supper.
<G-vec00509-002-s542><enter.in><de> Sie selbst gingen nicht in das Gebäude hinein, um nicht unrein zu werden, sondern das Paschalamm essen zu können.
<G-vec00509-002-s543><enter.in><en> The fact is that people who have psychological inhibitions about seeking to (re-)enter the church in their own local parish, have the alternative of going to one of the reception points.
<G-vec00509-002-s543><enter.in><de> Fakt ist: Menschen, für die es eine Hemmschwelle ist, in ihrer Ortsgemeinde (wieder) in die Kirche einzutreten, können sich stattdessen an eine Eintrittsstelle wenden.
<G-vec00509-002-s544><enter.in><en> When you cross the road from JR Shibuya Station and enter the narrow street to the left of Starbucks, you are on Shibuya Center Street.
<G-vec00509-002-s544><enter.in><de> Wenn Sie die Kreuzung vom JR-Bahnhof Shibuya aus überqueren und in die schmale Straße links von Starbucks gehen, befinden Sie sich auf der Shibuya Center Street.
<G-vec00509-002-s545><enter.in><en> At the same time, it is crucial that innovations in Germany enter the market more quickly.
<G-vec00509-002-s545><enter.in><de> Entscheidend sei zugleich, dass Innovationen in Deutschland schneller in den Markt kämen.
<G-vec00509-002-s546><enter.in><en> You are eligible to apply for ESTA if you are a citizen of a Visa Waiver Program country planning to enter the United States by air or sea, on an approved carrier.
<G-vec00509-002-s546><enter.in><de> Sie sind berechtigt, einen ESTA Antrag zu stellen, wenn Sie Bürger eines Landes sind, das am Visa Waiver Programm teilnimmt, und in die Vereinigten Staaten mit einem bestätigten Transportunternehmen auf dem Luft- oder Seeweg einreisen möchten.
<G-vec00509-002-s547><enter.in><en> In the first year of his stay in the team, Kerzhakov was able to win the silver medals of the championship and enter the list of 33 best footballers of the Russian Federation.
<G-vec00509-002-s547><enter.in><de> Im ersten Jahr seines Aufenthalts in der Mannschaft konnte Kerzhakov die Silbermedaillen der Meisterschaft gewinnen und in die Liste der 33 besten Fußballer der Russischen Föderation aufgenommen werden.
<G-vec00509-002-s548><enter.in><en> Approach Enter the lighted bay of Novigrad (mind fairway buoy and isolated danger mark), leaving the outer breakwater and the customs pier to stb.
<G-vec00509-002-s548><enter.in><de> In die befeuerte Bucht von Novigrad (Fahrwassertonne und Einzelgefahrenstelle beachten), dabei den äußeren Wellenbrecher und die Zollpier an Stb lassen.
<G-vec00509-002-s549><enter.in><en> With a watchful and open-hearted attitude let us enter the Holy Week knowing that we need to embrace Jesus ’s suffering on the cross.
<G-vec00509-002-s549><enter.in><de> Lasst uns wachsam und offenherzig in diese Karwoche gehen, wissend, dass wir das Leiden Jesu am Kreuz völlig annehmen müssen.
<G-vec00509-002-s550><enter.in><en> When creating a poll you need to enter a poll question and at least two options for the poll.
<G-vec00509-002-s550><enter.in><de> Sie sollten einen Titel und mindestens zwei Antwortmöglichkeiten in die entsprechenden Felder eingeben und dabei sicherstellen, dass jede Antwortmöglichkeit in einer eigenen Zeile steht.
