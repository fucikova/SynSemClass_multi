<G-vec00296-003-s171><break_down.(sich)_brechen><en> HSL break the body fat shops within your cells.
<G-vec00296-003-s171><break_down.(sich)_brechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00296-003-s172><break_down.(sich)_brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00296-003-s172><break_down.(sich)_brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00296-003-s173><break_down.(sich)_brechen><en> Q Right – but you don’t break his nose.
<G-vec00296-003-s173><break_down.(sich)_brechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00296-003-s174><break_down.(sich)_brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00296-003-s174><break_down.(sich)_brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00296-003-s175><break_down.(sich)_brechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00296-003-s175><break_down.(sich)_brechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00296-003-s176><break_down.(sich)_brechen><en> The part could break without warning (see figure 80).
<G-vec00296-003-s176><break_down.(sich)_brechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00296-003-s177><break_down.(sich)_brechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00296-003-s177><break_down.(sich)_brechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00296-003-s178><break_down.(sich)_brechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00296-003-s178><break_down.(sich)_brechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00296-003-s179><break_down.(sich)_brechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00296-003-s179><break_down.(sich)_brechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00296-003-s180><break_down.(sich)_brechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00296-003-s180><break_down.(sich)_brechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00296-003-s181><break_down.(sich)_brechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00296-003-s181><break_down.(sich)_brechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00296-003-s182><break_down.(sich)_brechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00296-003-s182><break_down.(sich)_brechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00296-003-s183><break_down.(sich)_brechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00296-003-s183><break_down.(sich)_brechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00296-003-s184><break_down.(sich)_brechen><en> HSL break the fat stores within your cells.
<G-vec00296-003-s184><break_down.(sich)_brechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00296-003-s185><break_down.(sich)_brechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00296-003-s185><break_down.(sich)_brechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00296-003-s186><break_down.(sich)_brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00296-003-s186><break_down.(sich)_brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00296-003-s187><break_down.(sich)_brechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00296-003-s187><break_down.(sich)_brechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00296-003-s188><break_down.(sich)_brechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00296-003-s188><break_down.(sich)_brechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00296-003-s189><break_down.(sich)_brechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
<G-vec00296-003-s189><break_down.(sich)_brechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00296-003-s019><break_down.abbrechen><en> Some people suggest if the United States would just break ties with Israel, all our problems in the Middle East would go away.
<G-vec00296-003-s019><break_down.abbrechen><de> Einige Leute legen nahe, dass alle unsere Probleme im Nahen Osten verschwinden würden, wenn die Vereinigten Staaten nur ihre Verbindungen mit Israel abbrechen würden.
<G-vec00296-003-s020><break_down.abbrechen><en> Branches and twigs may break off and fall down.
<G-vec00296-003-s020><break_down.abbrechen><de> Äste und Zweige können abbrechen und herunterfallen.
<G-vec00296-003-s021><break_down.abbrechen><en> Mostly after a short time you have the feeling that nothing is working anymore and that is precisely the point at which many people break with their resolutions.
<G-vec00296-003-s021><break_down.abbrechen><de> Meist nach kurzer Zeit habt ihr das Gefühl nicht mehr voranzukommen und das ist genau der Punkt, an dem viele Leute ihre Vorsätze abbrechen.
<G-vec00296-003-s022><break_down.abbrechen><en> Do not try to pry the top edge of the display away from the rear case, as it is held in place by plastic clips that may break.
<G-vec00296-003-s022><break_down.abbrechen><de> Versuche nicht, die obere Seite des Displays abzuheben, denn diese wird zusätzlich mit Kunststoffclips in Position gehalten, die dann abbrechen könnten.
<G-vec00296-003-s023><break_down.abbrechen><en> 26:12 And they shall make a spoil of thy riches, and make a prey of thy wares; and they shall break down thy walls, and destroy thy pleasant houses; and they shall lay thy stones and thy timber and thy dust in the midst of the waters.
<G-vec00296-003-s023><break_down.abbrechen><de> 12 Und sie werden dein Vermögen rauben und deinen Handelsgewinn plündern und deine Mauern abbrechen und deine prächtigen Häuser niederreißen; und deine Steine und dein Holz und deinen Schutt werden sie mitten ins Wasser schütten.
<G-vec00296-003-s024><break_down.abbrechen><en> The V-shaped arrangement of the Cleanliner Mega cleaning and loading machine intake table means that it not only grabs the beets from the ends but the design also enables it to break down the conical pile of beets from the sides, guiding them towards the intake table.
<G-vec00296-003-s024><break_down.abbrechen><de> Der Aufnahmetisch der Reinigungs- und Verlademaschine Cleanliner Mega greift durch die V-förmige Anordnung nicht nur stirnseitig auf die Rüben zu, sondern unterstützt durch seine Konstruktion das seitliche Abbrechen des Rüben-Schüttkegels in Richtung der Aufnahmetische.
<G-vec00296-003-s025><break_down.abbrechen><en> If there is a risk that parts of the packaged goods may distort, bend or break under the influence of mechanical transport stresses, they must be supported or dismantled in consultation with the manufacturer.
<G-vec00296-003-s025><break_down.abbrechen><de> Besteht die Gefahr, dass sich Packgutteile durch die Einwirkung der mechanischen Transportbelastungen verziehen, durchbiegen oder abbrechen, sind diese Teile abzustützen oder in Abstimmung mit dem Hersteller zu demontieren.
<G-vec00296-003-s026><break_down.abbrechen><en> It may deflect the needle causing it to break.
<G-vec00296-003-s026><break_down.abbrechen><de> Dadurch kann sich die Nadel verbiegen und schlie.lich abbrechen.
<G-vec00296-003-s027><break_down.abbrechen><en> He shall break down the house, the stones of it, and the timber of it, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.
<G-vec00296-003-s027><break_down.abbrechen><de> 45 Darum soll man das Haus abbrechen, Steine und Holz und alle Tünche am Hause, und soll's hinausführen vor die Stadt an einen unreinen Ort.
<G-vec00296-003-s028><break_down.abbrechen><en> If another stitch is selected, the needle will strike the presser foot, causing the needle to break, possibly leading to injury.
<G-vec00296-003-s028><break_down.abbrechen><de> Wenn ein anderer Stich gewählt wird, berührt die Nadel den Nähfuß, wodurch sie abbrechen und zu Verletzungen führen kann.
<G-vec00296-003-s029><break_down.abbrechen><en> Because of the short length Is an accidental break or bend virtually hardly possible.
<G-vec00296-003-s029><break_down.abbrechen><de> Aufgrund der geringen Länge ist nämlich ein versehentliches abbrechen oder verbiegen praktisch kaum möglich.
<G-vec00296-003-s030><break_down.abbrechen><en> This requires a fine feeling because the vines should not be break through and fixed to the wire in a nice flat bow.
<G-vec00296-003-s030><break_down.abbrechen><de> Hierfür ist Fingerspitzengefühl gefragt, denn die Reben sollen natürlich nicht abbrechen und in einem schönen Flachbogen am Draht fixiert werden.
<G-vec00296-003-s031><break_down.abbrechen><en> The result: The eyelashes are going to brittle and they can even break off.
<G-vec00296-003-s031><break_down.abbrechen><de> Die Folge: Die Wimpern werden immer spröder und können sogar abbrechen.
<G-vec00296-003-s032><break_down.abbrechen><en> It is important that we don't let the chain of memories break off."
<G-vec00296-003-s032><break_down.abbrechen><de> Wichtig ist, dass wir die Kette der Erinnerung nicht abbrechen lassen.
<G-vec00296-003-s033><break_down.abbrechen><en> Children's ties to their grandparents may be so strong that not even the latter's death can break them. Abstract in German:
<G-vec00296-003-s033><break_down.abbrechen><de> Die kindlichen Bindungen an die Großeltern können so stark sein, dass selbst der Tod der Großeltern diese nicht abbrechen.
<G-vec00296-003-s034><break_down.abbrechen><en> It will take a bit of elbow grease to get it all pulled away from the tree, and there will probably be pieces that break off from the roots, but don’t worry about it just yet.
<G-vec00296-003-s034><break_down.abbrechen><de> Es wird etwas Schweiß kosten, den ganzen Efeu von dem Stamm zu ziehen und es wird wahrscheinlich ein paar Stücke geben, die an den Wurzeln abbrechen, aber es ist unnötig, sich darüber Sorgen zu machen.
<G-vec00296-003-s035><break_down.abbrechen><en> Global warming causes large areas of the Arctic ice shelf to break off and melt, meaning that the Atlantic ocean is diluted by large amounts of fresh water.
<G-vec00296-003-s035><break_down.abbrechen><de> Globale Klimaerwärmung bewirkt das Abbrechen und Schmelzen von großen Teilen der arktischen Eisdecke, was bedeutet, dass der Atlantische Ozean durch große Süßwassermengen verdünnt wird.
<G-vec00296-003-s036><break_down.abbrechen><en> Since we use untreated natural amber for our chains and this is a little more brittle than treated amber, it can happen that individual stones can break off.
<G-vec00296-003-s036><break_down.abbrechen><de> Da wir für unsere Ketten unbehandelten Naturbernstein verwenden und dieser etwas brüchiger ist als behandelter Bernstein, kann es vorkommen, das einzelne Steinchen auch abbrechen können.
<G-vec00296-003-s037><break_down.abbrechen><en> Do not continue sewing without lengthening the stitch length, otherwise the needle may break and cause injury. Reverse sewing lever
<G-vec00296-003-s037><break_down.abbrechen><de> Nähen Sie nicht weiter, ohne eine größere Stichlänge gewählt zu haben, da die Nadel sonst abbrechen und Verletzungen verursachen kann.
<G-vec00296-003-s038><break_down.aufbrechen><en> We needed to break it up, without breaking it.
<G-vec00296-003-s038><break_down.aufbrechen><de> Wir mussten sie aufbrechen, ohne sie zu zerbrechen.
<G-vec00296-003-s039><break_down.aufbrechen><en> Ralf Heinrich, a headmaster, states, “Music can be used to break down an awful lot of barriers and some topics, which are serious, can be given a very different impetus.
<G-vec00296-003-s039><break_down.aufbrechen><de> Ralf Heinrich, Schulleiter, erklärt: „Mit Musik kann man wirklich vieles aufbrechen und auch manche Themen, die ernst sind, kann man mit ganz anderem Schwung versehen.
<G-vec00296-003-s040><break_down.aufbrechen><en> So to make it easier for companies and the humans that work there, some of the standards group have issued further guidelines that break the huge list of controls into more achievable goals.
<G-vec00296-003-s040><break_down.aufbrechen><de> Um es Unternehmen und ihren Mitarbeitern einfacher zu machen, haben einige der Normungsgremien weitere Richtlinien herausgegeben, die die riesige Liste der Kontrollen in erreichbare Ziele aufbrechen.
<G-vec00296-003-s041><break_down.aufbrechen><en> The inviting café with a sun terrace guarantees a successful start to the day, before active holidaymakers break into the numerous adventures of the region.
<G-vec00296-003-s041><break_down.aufbrechen><de> Das einladende Café mit Sonnenterrasse garantiert einen gelungenen Start in den Tag, bevor aktive Urlauber in die zahlreichen Abenteuer der Region aufbrechen.
<G-vec00296-003-s042><break_down.aufbrechen><en> So it happens that people break up.
<G-vec00296-003-s042><break_down.aufbrechen><de> So kommt es, dass Menschen Aufbrechen.
<G-vec00296-003-s043><break_down.aufbrechen><en> The new online postal codes are valid as pioneers for the “Internet of things” and are to break open the shortage of IP addresses for the connection of PCs and cell phones to the data net.
<G-vec00296-003-s043><break_down.aufbrechen><de> Die neuen Online-Postleitzahlen gelten als Wegbereiter für das „Internet der Dinge“ und sollen die Knappheit an IP-Adressen für den Anschluss von PCs und Handys an das Datennetz aufbrechen.
<G-vec00296-003-s044><break_down.aufbrechen><en> To break open the binding of the wheel of rebirth depends mainly on our being earnest and intent: That's what will clear our way. This is why living beings don't want to touch that binding, don't want to break it open.
<G-vec00296-003-s044><break_down.aufbrechen><de> Die Bindung an das Rad der Wiedergeburt aufzubrechen hängt hauptsächlich von unserer Ernsthaftigkeit und Entschlossenheit ab: Das ist es nämlich, was uns den Weg frei macht und warum auch die Lebewesen diese Bindung nicht anrühren und nicht aufbrechen wollen.
<G-vec00296-003-s045><break_down.aufbrechen><en> To help get the formatting correct, TortoiseSVN presents edit dialogs for some particular properties which show the possible values or break the property into its individual components.
<G-vec00296-003-s045><break_down.aufbrechen><de> Um Ihnen die Formatierung zu vereinfachen, stellt TortoiseSVN Dialoge für einige Eigenschaften zur Verfügung, die die Auswahlmöglichkeiten anzeigen oder die Eigenschaft in ihre individuellen Komponenten aufbrechen.
<G-vec00296-003-s046><break_down.aufbrechen><en> They yelled that they would break in if we refused to open the door.
<G-vec00296-003-s046><break_down.aufbrechen><de> Sie schrien, dass sie die Tür aufbrechen würden, wenn wir nicht öffneten.
<G-vec00296-003-s047><break_down.aufbrechen><en> The intention behind it was always to break up the familiar and stimulate the positive charge of (public) space and a lasting memory for the community.
<G-vec00296-003-s047><break_down.aufbrechen><de> Die Intention dahinter blieb immer das Aufbrechen von Bekanntem, die positive Aufladung des (öffentlichen) Raums sowie eine bleibende Erinnerung an das gemeinschaftliche Zusammenarbeiten zu erschaffen.
<G-vec00296-003-s048><break_down.aufbrechen><en> On the basis of the spectra, which correspond to the individual images of a film, it can thus be revealed – essentially in slow motion – how the iron complex deforms under pulsed laser illumination over several stages, the bonds break up and finally the radical is formed.
<G-vec00296-003-s048><break_down.aufbrechen><de> Anhand der Spektren – die den Einzelbildern eines Films entsprechen – lässt sich deshalb gleichsam in Zeitlupe nachweisen, wie sich der Eisenkomplex unter Laserbeschuss über mehrere Stufen verformt, die Bindungen aufbrechen und schließlich das Radikal entsteht.
<G-vec00296-003-s049><break_down.aufbrechen><en> Even if you are in a state of denial, you can see that there are issues and at least some part of you is gearing up for the break up.
<G-vec00296-003-s049><break_down.aufbrechen><de> Auch wenn Sie in einem Zustand der Verleugnung sind, können Sie sehen, dass es Fragen gibt, und zumindest einige Teil von euch rüstet sich für das Aufbrechen.
<G-vec00296-003-s050><break_down.aufbrechen><en> You also want to break up the old potting soil before using it, as it can get dry and compacted over time.
<G-vec00296-003-s050><break_down.aufbrechen><de> Sie möchten auch die alte Blumenerde aufbrechen, bevor Sie sie verwenden, da sie mit der Zeit trocken und verdichtet werden kann.
<G-vec00296-003-s051><break_down.aufbrechen><en> “Sam, is there a way to break the bond?”
<G-vec00296-003-s051><break_down.aufbrechen><de> „Sam, kann man die Bindung aufbrechen?“ fragte ich.
<G-vec00296-003-s052><break_down.aufbrechen><en> On the same day Cut the eggs lightly in the middle with a serrated knife and break them into two halves.
<G-vec00296-003-s052><break_down.aufbrechen><de> Am Tag: Die Eier mit einem Sägemesser leicht mittig anschneiden und in zwei Hälften aufbrechen.
<G-vec00296-003-s053><break_down.aufbrechen><en> When there is enough humidity in the air, wind can break the balls of water particles and thus create ions.
<G-vec00296-003-s053><break_down.aufbrechen><de> Wenn es genug Luftfeuchtigkeit gibt, kann Wind die Ballungen von Wasser-Partikel aufbrechen und so Ionen erzeugen.
<G-vec00296-003-s054><break_down.aufbrechen><en> Much of the paint is applied using stencils that break up the images into layers.
<G-vec00296-003-s054><break_down.aufbrechen><de> Ein großer Teil des Bildes wird mit Hilfe von Schablonen angelegt, die das Bild in Schichten aufbrechen.
<G-vec00296-003-s055><break_down.aufbrechen><en> Cellulose enzymes first have to break down the material and process it.
<G-vec00296-003-s055><break_down.aufbrechen><de> Zellulasen müssen das Material erst „aufbrechen“ und aufbereiten.
<G-vec00296-003-s056><break_down.aufbrechen><en> THE WIND CAN GET WILD IN CAPE TOWN AND WILL BREAK THE DOOR OPEN WHEN THAT HAPPENS.
<G-vec00296-003-s056><break_down.aufbrechen><de> Der Wind kann WILD IN KAPSTADT auftanken und die Tür aufbrechen, wenn das passiert.
<G-vec00296-003-s095><break_down.ausbrechen><en> Wanting to break away from outdated thought patterns and the paternalism and despotism they have had to endure ad nauseam, these youth have become the voice of a new era, and the imaginative use of new media has carried their message.
<G-vec00296-003-s095><break_down.ausbrechen><de> Das Ausbrechen aus veralteten Denkstrukturen und der Überdruss an Bevormundung und Despotie, nicht zuletzt mittels eines selbstverständlichen und phantasievollen Umgangs mit neuen Medien, ließen besonders die Jugend in den arabischen Ländern zum Sprachrohr einer neuen Zeit werden.
<G-vec00296-003-s096><break_down.ausbrechen><en> Today, should total war ever break out again, no matter how, our two countries would become the primary targets.
<G-vec00296-003-s096><break_down.ausbrechen><de> Sollte heute jemals wieder ein totaler Krieg ausbrechen, wären unsere beiden Länder die primären Ziele.
<G-vec00296-003-s097><break_down.ausbrechen><en> With the abundance of volatility we have seen, it is expected that the AUD/USD will break out of its range soon (hopefully to the downside).
<G-vec00296-003-s097><break_down.ausbrechen><de> Mit der reichlichen Volatilität, die wir sehen, wird der AUD/USD wohl bald aus seiner Range ausbrechen (hoffentlich abwärts).
<G-vec00296-003-s098><break_down.ausbrechen><en> You must break out of thoughts about yourself because they are fruitless and they keep you away from larger fields of greater thought.
<G-vec00296-003-s098><break_down.ausbrechen><de> Du musst aus den Gedanken über dich selbst ausbrechen, weil sie fruchtlos sind und dich von umfassenderen Gefilden erhabeneren Denkens abhalten.
<G-vec00296-003-s099><break_down.ausbrechen><en> He could not break free
<G-vec00296-003-s099><break_down.ausbrechen><de> Er konnte nicht ausbrechen.
<G-vec00296-003-s100><break_down.ausbrechen><en> Break out of the prison... physically, mentally, spiritually.
<G-vec00296-003-s100><break_down.ausbrechen><de> Ausbrechen aus dem Gefängnis... körperlich, seelisch, geistig.
<G-vec00296-003-s101><break_down.ausbrechen><en> Because it makes it clear that men, differently from apes, could break out of the point of view in their relation to self, steered by own interests.
<G-vec00296-003-s101><break_down.ausbrechen><de> Mache sie doch klar, dass Menschen, anders als Affen, aus den Schranken ihrer selbstbezogenen, von eigenen Interessen gesteuerten Sicht ausbrechen könnten.
<G-vec00296-003-s102><break_down.ausbrechen><en> The chrooted users will be jailed in a specific directory where they can't break out.
<G-vec00296-003-s102><break_down.ausbrechen><de> Die gechrooteten Benutzer werden in einem speziellen Verzeichnis eingesperrt, aus dem sie nicht ausbrechen können.
<G-vec00296-003-s103><break_down.ausbrechen><en> Asian elephants, however, cannot develop anti-bodies and that is why the viral illness can break out in them.
<G-vec00296-003-s103><break_down.ausbrechen><de> Asiatische Elefanten aber können keine Antikörper bilden und darum kann bei ihnen die Viruserkrankung ausbrechen.
<G-vec00296-003-s104><break_down.ausbrechen><en> At the time of its construction, no one suspected that a few years later an even worse war would break out.
<G-vec00296-003-s104><break_down.ausbrechen><de> Zur Zeit der Erbauung ahnte keiner, dass wenige Jahre später ein noch schlimmerer Krieg ausbrechen sollte.
<G-vec00296-003-s105><break_down.ausbrechen><en> As a result they are caught up in their own life and to break out of this captivity they have to ask God for help because one can’t manage it on one’s own.
<G-vec00296-003-s105><break_down.ausbrechen><de> Als Ergebnis sind sie in ihrem eigenen Leben gefangen und können nicht aus eigener Kraft ausbrechen, sondern benötigen dafür Gottes Hilfe.
<G-vec00296-003-s106><break_down.ausbrechen><en> But the border between narrated dream and narrated reality can also be transcended, figures or elements can break out of dreams or break into dreams of others.
<G-vec00296-003-s106><break_down.ausbrechen><de> Im Comic kann die Grenze zwischen erzählter Realität und erzähltem Traum durchbrochen werden; Figuren und andere Elemente können aus dem Traum ausbrechen oder in fremde Träume gelangen.
<G-vec00296-003-s107><break_down.ausbrechen><en> Our bullish view will be invalidated if the bulls fail to break out of the overhead resistance.
<G-vec00296-003-s107><break_down.ausbrechen><de> Unsere optimistische Einschätzung ist hinfällig, wenn die Bullen nicht über den Überkopfwiderstand ausbrechen.
<G-vec00296-003-s108><break_down.ausbrechen><en> Let me give you the good news now: what could demonstrate more clearly that institutional critique is still possible and very much alive than the fact that individuals and communities still step aside from the society, pass judgment on it, and break free from the bonds of ideology.
<G-vec00296-003-s108><break_down.ausbrechen><de> Lassen Sie mich jetzt die guten Neuigkeiten bringen: Was könnte deutlicher zeigen, dass Institutionskritik noch immer möglich und sehr lebendig ist, als die Tatsache, dass Individuen und Gemeinschaften noch immer neben die Gesellschaft treten, sie beurteilen und aus den Fesseln der Ideologie ausbrechen.
<G-vec00296-003-s109><break_down.ausbrechen><en> Individual and corporate greed will lead to more plagues of disease and famines that will break out when chemically dependent, genetically manipulative agribusiness implodes leaving behind sterile soil and feral crops.
<G-vec00296-003-s109><break_down.ausbrechen><de> Individuelle und kollektive Habgier werden zur Zunahme von Seuchen und Hungersnöten führen, die dann ausbrechen, wenn das von der Chemie abhängende Geschäft mit genetisch manipulierten landwirtschaftlichen Erzeugnissen in sich zusammenbricht und nichts weiter übriglässt als unfruchtbar gewordenen Boden und den Ertrag verwilderter Pflanzen.
<G-vec00296-003-s110><break_down.ausbrechen><en> This may help them to get a better job later in life, so that they can break out of the vicious circle of poverty.
<G-vec00296-003-s110><break_down.ausbrechen><de> Dieser wird ihnen hoffentlich helfen, in Zukunft einen qualifizierten Beruf auszuüben, damit sie aus dem Teufelskreis der Armut ausbrechen können.
<G-vec00296-003-s111><break_down.ausbrechen><en> 14 Then the LORD said to me, Out of the north an evil shall break forth on all the inhabitants of the land.
<G-vec00296-003-s111><break_down.ausbrechen><de> 14 Und der HERR sprach zu mir: Von Mitternacht wird das Unglück ausbrechen über alle, die im Lande wohnen.
<G-vec00296-003-s112><break_down.ausbrechen><en> Especially if you want to break free from your routine with like-minded people and take a timeout together in a beautiful environment.
<G-vec00296-003-s112><break_down.ausbrechen><de> Besonders, wenn du aus dem Alltag ausbrechen und mit gleichgesinnten Menschen eine Auszeit in einer schönen Umgebung verbringen willst.
<G-vec00296-003-s113><break_down.ausbrechen><en> I surround myself with positive people and show others who want to break out how easy it now is to start again with an unrivalled philosophy.
<G-vec00296-003-s113><break_down.ausbrechen><de> Ich umgebe mich mit positiven Menschen und zeige anderen, die ausbrechen wollen, wie einfach es heutzutage ist, mit einer konkurrenzlosen Philosophie durchzustarten.
<G-vec00296-003-s171><break_down.brechen><en> HSL break the body fat shops within your cells.
<G-vec00296-003-s171><break_down.brechen><de> HSL bricht die Fettgewebe Geschäfte in den Zellen nach unten.
<G-vec00296-003-s172><break_down.brechen><en> In such times hatred, anger and brutish, animalistic tendencies in us humans break free bluntly, encouraged and feeling comfortable in the great wave of like-minded people, forcing those who are undecided and insecure to leave their comfort zones, letting themselves be swept away into the new, big, alleged whole.
<G-vec00296-003-s172><break_down.brechen><de> Der Hass, die Wut, das tierisch Brutale in uns Menschen bricht in solchen Zeiten wie der aktuellen unverblümt heraus, weiß sich plötzlich geborgen in einer großen Woge Gleichgesinnter und lässt den Unentschlossenen, weil Unsicheren, herausgerissen aus seiner bisherigen Komfortzone, lässt sich mitreißen ins neue große vermeintliche Ganze.
<G-vec00296-003-s173><break_down.brechen><en> Q Right – but you don’t break his nose.
<G-vec00296-003-s173><break_down.brechen><de> Q Richtig – Aber man bricht ihm nicht die Nase.
<G-vec00296-003-s174><break_down.brechen><en> In this unit, the interplay of shot composition and sound design break with the preceding simulation of future experiences of pain.
<G-vec00296-003-s174><break_down.brechen><de> In diesem Abschnitt der Szene bricht das Zusammenspiel von Bildkomposition und Akustik mit der vorangegangenen visuellen Simulation zukünftiger Schmerzerfahrung.
<G-vec00296-003-s175><break_down.brechen><en> For instance, at the beginning of your military service, you break into a Palestinian house in the middle of the night and you wake up the whole family.
<G-vec00296-003-s175><break_down.brechen><de> Zum Beispiel: Man bricht zu Beginn seines Militärdienstes mitten in der Nacht in ein palästinensisches Haus ein und weckt die gesamte Familie auf.
<G-vec00296-003-s176><break_down.brechen><en> The part could break without warning (see figure 80).
<G-vec00296-003-s176><break_down.brechen><de> Das Bauteil bricht ohne Vorankündigung (siehe Bild 80).
<G-vec00296-003-s177><break_down.brechen><en> The easiest way to determine is wait for price to break above resistance or below support.
<G-vec00296-003-s177><break_down.brechen><de> Am einfachsten ist es zu warten, bis der Kurs über den Widerstand oder unter die Unterstützung bricht.
<G-vec00296-003-s178><break_down.brechen><en> An advantage of mirror acrylic is that it does not break as quickly as normal mirrors.
<G-vec00296-003-s178><break_down.brechen><de> Ein Vorteil von Acrylglasspiegel ist, daß es nicht so schnell bricht wie normaler Spiegel.
<G-vec00296-003-s179><break_down.brechen><en> Made of environmentally friendly material, it is so elastic and tough at the same time that it is very stable and does not break quickly.
<G-vec00296-003-s179><break_down.brechen><de> Aus umweltfreundlichem Material hergestellt, ist so elastisch und gleichzeitig zäh, dass es sehr stabil ist und nicht schnell bricht.
<G-vec00296-003-s180><break_down.brechen><en> Open backs break with the classic romanticism typical of this dress style and add an unexpectedly seductive touch that really brings your femininity to the fore.
<G-vec00296-003-s180><break_down.brechen><de> Ein freier Rücken bricht mit dem klassischen Romantikflair dieser Art von Kleid und verleiht ihm eine unerwartete und verführerische Note, die Ihre Weiblichkeit wundervoll zur Geltung bringt.
<G-vec00296-003-s181><break_down.brechen><en> Black will break the stigma that keeps it out of the bathroom to bring a large dose of elegance and relaxation.
<G-vec00296-003-s181><break_down.brechen><de> Die schwarze Farbe bricht das Stigma, das sie lange Zeit aus dem Badezimmer verbannte, und sorgt für eine große Dosis Eleganz und Entspannung.
<G-vec00296-003-s182><break_down.brechen><en> As autumn rolls over the land, the forests break out into a spectacular colour show and savouring some of the South Tyrolean specialities during the traditional “Törggelen” period of winemaking will make your stay truly memorable.
<G-vec00296-003-s182><break_down.brechen><de> Bricht der Herbst ins Land, so färben sich die Wälder in spektakuläre Farben und der Genuss von Südtiroler Spezialitäteten beim traditionellen „Törggelen“ macht Ihren Aufenthalt unvergesslich.
<G-vec00296-003-s183><break_down.brechen><en> Visual inspection is often not sufficient to determine how far the humidity damage has spread and in the worst case, your horse might break through the rotten trailer floor.
<G-vec00296-003-s183><break_down.brechen><de> Wie weit sich der Feuchtigkeitsschaden ausgebreitet hat, lässt sich mit dem bloßen Auge meist nicht erkennen, im schlimmsten Fall bricht das Pferd durch den morschen Anhängerboden.
<G-vec00296-003-s184><break_down.brechen><en> HSL break the fat stores within your cells.
<G-vec00296-003-s184><break_down.brechen><de> HSL bricht die Fettspeicher in den Zellen nach unten.
<G-vec00296-003-s185><break_down.brechen><en> Modern ways of approaching theatre break down all the classical divisions – between art disciplines, between the actor/performer and the viewers, or between the stage and the audience.
<G-vec00296-003-s185><break_down.brechen><de> Modernes Denken über das Theater bricht alle klassischen Teilungen - zwischen den Disziplinen der Kunst, zwischen dem Schauspieler-Darsteller und dem Publikum, oder der Bühne und dem Zuschauerraum.
<G-vec00296-003-s186><break_down.brechen><en> 6 Before their face the people shall be much pained: all faces shall gather blackness. 7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:
<G-vec00296-003-s186><break_down.brechen><de> 7 Wie Helden rennen sie, wie Kriegsleute ersteigen sie die Mauer; und sie ziehen, jeder auf seinem Weg, und ihre Pfade verlassen sie nicht; 8 und keiner drängt den anderen, sie ziehen, jeder auf seiner Bahn; und sie stürzen zwischen den Waffen hindurch, [ihr Zug] bricht nicht ab.
<G-vec00296-003-s187><break_down.brechen><en> If you later try to push the display into an opening that is too small, there is a high probability that the display will break.
<G-vec00296-003-s187><break_down.brechen><de> Wird später versucht, das Display in eine zu kleine Öffnung zu drücken, besteht eine große Wahrscheinlichkeit, dass das Display bricht.
<G-vec00296-003-s188><break_down.brechen><en> The shampoo is ideal for thin hair that is quick to break or fall out during shampooing.
<G-vec00296-003-s188><break_down.brechen><de> Beschreibung Dieses Shampoo ist ideal für dünnes Haar, das während des Waschens bricht oder ausfällt.
<G-vec00296-003-s189><break_down.brechen><en> After curing, a sturdy, marginally elastic coating is formed, one that will not break very easily.
<G-vec00296-003-s189><break_down.brechen><de> Nach dem Aushärten ergibt sich eine stabile, geringfügig elastische Schicht, die nicht zu schnell bricht.
<G-vec00296-003-s209><break_down.durchbrechen><en> 24 And Jehovah said unto him, Go, get thee down; and thou shalt come up, thou, and Aaron with thee: but let not the priests and the people break through to come up unto Jehovah, lest he break forth upon them.
<G-vec00296-003-s209><break_down.durchbrechen><de> 24Und der HERR sprach zu ihm: Geh hin, steig hinab und komm wieder herauf, du und Aaron mit dir; aber die Priester und das Volk sollen nicht durchbrechen, dass sie hinaufsteigen zu dem HERRN, damit er sie nicht zerschmettere.
<G-vec00296-003-s210><break_down.durchbrechen><en> The steps help break what I might call the "public language barrier" so that the source of one's own thinking is found and spoken from.
<G-vec00296-003-s210><break_down.durchbrechen><de> Die Schritte helfen zu durchbrechen, was ich die "allgemeine öffentliche Sprachbarriere" nennen würde, damit die Quelle des eigenen Denkens gefunden und daraus gesprochen wird.
<G-vec00296-003-s211><break_down.durchbrechen><en> The aim is to develop a platform for internal and external “visionaries”, start-ups and free thinkers, in order to break the daily work routine and come up with fresh new ideas.
<G-vec00296-003-s211><break_down.durchbrechen><de> Das Ziel ist es, eine Plattform für interne und externe „Visionäre“, Startups und Freigeister zu schaffen, um den Arbeitsalltag zu durchbrechen und für frischen Wind zu sorgen.
<G-vec00296-003-s212><break_down.durchbrechen><en> Eye-catching advertisement Place your advertisement conspicuously in the search results list and break the user's searching habits.
<G-vec00296-003-s212><break_down.durchbrechen><de> Platzieren Sie Ihr Inserat auffällig in der Suchergebnisliste und durchbrechen Sie die Nutzergewohnheit der Suchenden.
<G-vec00296-003-s213><break_down.durchbrechen><en> Use madness to break through the enemies.
<G-vec00296-003-s213><break_down.durchbrechen><de> Verwenden Sie Wahnsinn, um die Feinde durchbrechen.
<G-vec00296-003-s214><break_down.durchbrechen><en> Uninvited visitors come up against an almost insuperable resistancethe trying to break through one of our doors.
<G-vec00296-003-s214><break_down.durchbrechen><de> Ungebetene Besucher stoßen schon bei dem Versuch, eine unserer Türen zu durchbrechen auf nahezu unüberwindbaren Widerstand.
<G-vec00296-003-s215><break_down.durchbrechen><en> 19:24 And the LORD said unto him, Away, get you down, and you shall come up, you, and Aaron with you: but let not the priests and the people break through to come up unto the LORD, lest he break forth upon them.
<G-vec00296-003-s215><break_down.durchbrechen><de> 24 Und der HERR sprach zu ihm: Geh hin, steig hinab und komm wieder herauf, du und Aaron mit dir; aber die Priester und das Volk sollen nicht durchbrechen, daß sie hinaufsteigen zu dem HERRN, damit er sie nicht zerschmettere.
<G-vec00296-003-s216><break_down.durchbrechen><en> We envision to break social and physical poverty of any rural Indian by several ways.
<G-vec00296-003-s216><break_down.durchbrechen><de> Wir beabsichtigen, die soziale und physische Armut eines jeden ländlichen Indianers auf verschiedene Weise zu durchbrechen.
<G-vec00296-003-s217><break_down.durchbrechen><en> However, cunning enemies want to break the race placing everywhere numerous obstacles.
<G-vec00296-003-s217><break_down.durchbrechen><de> Schlaue Gegner wollen jedoch das Rennen durchbrechen und stellen überall zahlreiche Hindernisse auf.
<G-vec00296-003-s218><break_down.durchbrechen><en> It is an attempt to break through the borders of the ordinary, known and profane in a search for bliss and freedom, but still knowing this is only a (beautiful) illusion.
<G-vec00296-003-s218><break_down.durchbrechen><de> Es ist ein Versuch die Grenzen des Gewöhnlichen, Bekannten, Profanen zu durchbrechen, auf der Suche nach Glückseligkeit und Freiheit, jedoch mit dem Wissen, dass dies nur eine (schöne) Illusion ist.
<G-vec00296-003-s219><break_down.durchbrechen><en> Actually, nothing would improve. Those people could never break through the stage of illness healing and health maintenance, that is, the level of harnessing qi.
<G-vec00296-003-s219><break_down.durchbrechen><de> In Wirklichkeit kann nichts erhöht werden, er kann nie die Ebene der Krankheitsbeseitigung und Gesundheitserhaltung, also des Übens des Qi durchbrechen.
<G-vec00296-003-s220><break_down.durchbrechen><en> The product and packaging have to break through these routines whilst nevertheless docking on to consumers’ existing expectations and needs.
<G-vec00296-003-s220><break_down.durchbrechen><de> Produkt und Verpackung müssen diese Routinen durchbrechen, gleichzeitig aber dann doch wieder an bestehende Erwartungen und Bedürfnisse der Konsumenten andocken.
<G-vec00296-003-s221><break_down.durchbrechen><en> Micah 2:13: “… 13 The One who breaks open the way will go up before them; they will break through the gate and go out.
<G-vec00296-003-s221><break_down.durchbrechen><de> Micha 2,13: 13 Er wird als ein Durchbrecher vor ihnen heraufziehen; sie werden durchbrechen und durchs Tor hinausziehen, und ihr König wird vor ihnen hergehen und der HERR an ihrer Spitze.
<G-vec00296-003-s222><break_down.durchbrechen><en> The cover of the forest was dense, though the sun still tried to break through, speckling the ground in patches.
<G-vec00296-003-s222><break_down.durchbrechen><de> Die Decke des Waldes war dicht, obwohl die Sonne immer noch versuchte zu durchbrechen und den Boden in Flecken zu sprießen.
<G-vec00296-003-s223><break_down.durchbrechen><en> Together with our European partners, we will therefore consider incentives to help encourage Asmara to finally break this logic, which has resulted in major human rights violations.
<G-vec00296-003-s223><break_down.durchbrechen><de> Deshalb werden wir uns gemeinsam mit unseren europäischen Partnern Gedanken über Anreize gegenüber Asmara machen, die helfen sollen, um diese Logik, die in ganz erheblichen Menschenrechtsverletzungen endet, endlich zu durchbrechen.
<G-vec00296-003-s224><break_down.durchbrechen><en> Whether you’re just getting over a breakup or trying to break negative relationship patterns, there may come a time when you simply don’t want to fall in love.
<G-vec00296-003-s224><break_down.durchbrechen><de> Es wird eine Zeit geben, in der du dich einfach nicht verlieben willst, beispielsweise weil du gerade eine Trennung verarbeitest oder negative Beziehungsmuster durchbrechen willst.
<G-vec00296-003-s225><break_down.durchbrechen><en> The traditional doctrine may be more solid and hard to break down than I think.
<G-vec00296-003-s225><break_down.durchbrechen><de> Die traditionelle Lehre scheint doch fester etabliert und schwieriger zu durchbrechen zu sein, als mir lieb ist.
<G-vec00296-003-s226><break_down.durchbrechen><en> Fight against child exploitation – Tdh fights against the sexual exploitation of children by putting into place reception centres, in order to help young girls and boys emancipate themselves and break the chains of exploitation.
<G-vec00296-003-s226><break_down.durchbrechen><de> Kampf gegen die Ausbeutung der Kinder – Tdh bekämpft die sexuelle Ausbeutung von Kindern, indem sich die Organisation gegen die Empfangszentren auflehnt und Mädchen und Jungen dabei hilft, die Emanzipation zu erreichen um somit die Ausbeutungskette zu durchbrechen.
<G-vec00296-003-s227><break_down.durchbrechen><en> We cordially invite you to break the taboos of the „foul" language and to rethink the meaning of the offensive words that became a part of our everydayness.
<G-vec00296-003-s227><break_down.durchbrechen><de> Wir laden Sie herzlich ein, die Tabus der "schmutzigen" Sprache zu durchbrechen und ihre Bedeutung in unserem alltäglichen Sprachgebrauch neu zu überdenken.
<G-vec00296-003-s361><break_down.einlegen><en> Whether you are on a gap year, career break, or looking for a meaningful experience during a vacation, volunteering with Projects Abroad gives you the chance to live and work alongside a diverse and friendly people.
<G-vec00296-003-s361><break_down.einlegen><de> Du kannst mit Projects Abroad nach Belize reisen, wenn du gerade ein Sabbatjahr machst, eine Pause von deinem Job einlegen möchtest oder nach einer sinnvollen Aufgabe während eines Urlaubs suchst.
<G-vec00296-003-s362><break_down.einlegen><en> There is a limit to how many stages you can play through without taking a break.
<G-vec00296-003-s362><break_down.einlegen><de> Nach einer begrenzten Anzahl von Stufen musst du jedoch eine Pause einlegen.
<G-vec00296-003-s363><break_down.einlegen><en> The fact that Forex markets are closed over weekends might be one of the advantages in this respect, for even the hard-core workaholics have to take a break.
<G-vec00296-003-s363><break_down.einlegen><de> Die Tatsache, dass die Devisenmärkte an Wochenenden geschlossen sind, könnte einer der Vorteile in dieser Hinsicht sein, denn selbst die Hardcore-Workaholics müssen eine Pause einlegen.
<G-vec00296-003-s364><break_down.einlegen><en> Time-out period If you wish to take a break, a time-out period facility is available online here when logged in or by contacting our Customer Service team.
<G-vec00296-003-s364><break_down.einlegen><de> Wenn Du eine Pause einlegen möchtest, ist eine Auszeit-Funktion verfügbar, die Du nach dem Login hier online oder auch über unseren Kundenservice erreichen kannst.
<G-vec00296-003-s365><break_down.einlegen><en> We keep on descending until we reach a hidden natural pond, where we take our second break.
<G-vec00296-003-s365><break_down.einlegen><de> Wir steigen weiter ab, bis wir einen versteckten natürlichen Teich erreichen, wo wir unsere zweite Pause einlegen.
<G-vec00296-003-s366><break_down.einlegen><en> We just enjoy having a short break after a few hours and saving on the ticket costs.
<G-vec00296-003-s366><break_down.einlegen><de> Es tut uns einfach gut, nach wenigen Stunden eine (Raucher) Pause einlegen zu können.
<G-vec00296-003-s367><break_down.einlegen><en> Snacks and drinks were on hand for those wishing to take a break and listen to the interviews held with the company’s current apprentices.
<G-vec00296-003-s367><break_down.einlegen><de> Wer eine Pause einlegen wollte, konnte bei Snacks und Getränken den Interviews mit aktuellen Azubis lauschen.
<G-vec00296-003-s368><break_down.einlegen><en> The motto is hot and cold: work hard, then take a break again.
<G-vec00296-003-s368><break_down.einlegen><de> Die Devise heißt heiß und kalt: intensiv arbeiten und dann wieder eine Pause einlegen.
<G-vec00296-003-s369><break_down.einlegen><en> In the short term you can just take a break a few minutes after the poor exercise.
<G-vec00296-003-s369><break_down.einlegen><de> Kurzfristig können Sie nur wenige Minuten nach dem schlechten Training eine Pause einlegen.
<G-vec00296-003-s370><break_down.einlegen><en> Watching TV (18%), relaxing at home, listening to music or reading (15%), having breakfast (15%) and taking a break (14%) are the occasions which index higher in the research.
<G-vec00296-003-s370><break_down.einlegen><de> Laut Marktanalysen belegen dabei Fernsehen (18 %), zu Hause beim Musikhören oder Lesen entspannen (15 %), Frühstücken (15 %) oder eine Pause einlegen (14 %) die oberen Stellen im Index.
<G-vec00296-003-s371><break_down.einlegen><en> You can take a break by requesting a 24 hr Time-Out period be applied to your Customer account.
<G-vec00296-003-s371><break_down.einlegen><de> Sie können eine Pause einlegen, indem Sie eine Auszeit von 24 Stunden für Ihr Kundenkonto anfordern.
<G-vec00296-003-s372><break_down.einlegen><en> We pass Stella Point again and reach Barafu Camp, where we have a short well deserved break.
<G-vec00296-003-s372><break_down.einlegen><de> Wir passieren nochmal den Stella Point und erreichen das Barafu Camp, wo wir eine kurze wohlverdiente Pause einlegen.
<G-vec00296-003-s373><break_down.einlegen><en> Sure, this will pass but we have to re-think our habits and take this break to change our attitudes towards the place we call Home.
<G-vec00296-003-s373><break_down.einlegen><de> Sicher, das wird vergehen, aber wir müssen unsere Gewohnheiten überdenken und diese Pause einlegen, um unsere Einstellung gegenüber dem Ort zu ändern, den wir zu Hause anrufen.
<G-vec00296-003-s374><break_down.einlegen><en> Whether you have just finished school, are in the middle of your university studies, or just want a break from your work routine, our Working Holiday programs are ideal for people of all ages and professional backgrounds.
<G-vec00296-003-s374><break_down.einlegen><de> Ganz gleich, ob du gerade die Schule abgeschlossen hast, dich mitten im Studium befindest, oder im Berufsalltag eine Pause einlegen möchtest, unsere Working Holiday Programme in Südamerika oder Mittelamerika sind für Teilnehmer aller Altersstufen und beruflicher Backgrounds geeignet.
<G-vec00296-003-s375><break_down.einlegen><en> Using our ‘Take a break’ feature on site will ensure the temporary closure of your Mr Green account for a selected time period of your choosing.
<G-vec00296-003-s375><break_down.einlegen><de> Wenn Sie die "Pause einlegen" -Funktion von Mr Green nutzen, schließen Sie Ihr Konto vorübergehend für einen ausgewählten Zeitraum Ihrer Wahl.
<G-vec00296-003-s376><break_down.einlegen><en> Here you can take a break and toilets are free for use.
<G-vec00296-003-s376><break_down.einlegen><de> Außerdem gibt es normalerweise einen „Autogrill“, an dem Sie eine Pause einlegen können.
<G-vec00296-003-s377><break_down.einlegen><en> We provide garden furniture so that you can take a relaxing break.
<G-vec00296-003-s377><break_down.einlegen><de> Wir stellen Ihnen Gartenmöbel zur Verfügung, damit Sie eine entspannende Pause einlegen können.
<G-vec00296-003-s378><break_down.einlegen><en> If you’d like to take a break for Facebook, but aren’t quite ready to say a final farewell just yet (or you still want access to Messenger), deactivating your account is a decent alternative to permanent deletion.
<G-vec00296-003-s378><break_down.einlegen><de> Willst Du nur eine Pause in Sachen Facebook einlegen, Dich aber noch nicht komplett verabschieden (oder Du willst den Messenger weiterhin nutzen), dann ist ein Deaktivieren Deines Kontos eine gute Lösung.
<G-vec00296-003-s379><break_down.einlegen><en> Nevertheless, you should also take a break and enjoy the wonderful weather.
<G-vec00296-003-s379><break_down.einlegen><de> Trotzdem sollten Sie auch mal eine Pause einlegen und das herrliche Wetter genießen.
<G-vec00296-003-s247><break_down.gehen><en> Konny’s congeniality, his courage to break new ground and his craftsmanship, which he impressively and repeatedly demonstrates with new DIY constructions, fit the SPAX brand perfectly.
<G-vec00296-003-s247><break_down.gehen><de> Konnys sympathisches Auftreten, sein Mut, neue Wege zu gehen, und sein handwerkliches Können, das er eindrucksvoll mit immer neuen Eigenbauten unter Beweis stellt, passen zur Marke SPAX.
<G-vec00296-003-s248><break_down.gehen><en> 16:38 I will judge you, as women who break wedlock and shed blood are judged; and I will bring on you the blood of wrath and jealousy.
<G-vec00296-003-s248><break_down.gehen><de> 16:38 Und will das Recht der Ehebrecherinnen und Blutvergießerinnen über dich gehen lassen und will dein Blut stürzen mit Grimm und Eifer.
<G-vec00296-003-s249><break_down.gehen><en> I break out the puck and the hockey stick and play a little one-on-wall.
<G-vec00296-003-s249><break_down.gehen><de> Um ganz sicher zu gehen, hole ich den Hockeyschlaeger aus dem Spind und uebe ein bisschen Einer-gegen-die-Wand.
<G-vec00296-003-s250><break_down.gehen><en> They work really hard, then have a quick break for lunch and just continue working hard later.
<G-vec00296-003-s250><break_down.gehen><de> Die arbeiten richtig hart, gehen dann kurz in die Mittagspause und arbeiten danach einfach weiter.
<G-vec00296-003-s251><break_down.gehen><en> D. G.: EurekaKids is our attempt to break new ground with a franchise system in the retail sector.
<G-vec00296-003-s251><break_down.gehen><de> D. G.: EurekaKids ist unser Versuch, mit einem Franchise System im EZH neue Wege zu gehen.
<G-vec00296-003-s252><break_down.gehen><en> Our motto is to break new grounds and to arrange highlights.
<G-vec00296-003-s252><break_down.gehen><de> Neue, eigene Wege gehen und Highlights setzen, das ist unser Motto.
<G-vec00296-003-s253><break_down.gehen><en> After a lunch break and walk through the Old City bazaar we travel to new Jerusalem.
<G-vec00296-003-s253><break_down.gehen><de> Nach einer Mittagspause gehen wir über den Basar der Altstadt und begeben uns ins neue Jerusalem.
<G-vec00296-003-s254><break_down.gehen><en> A creative person wants to break new ground, develop ideas, use his imagination, apply his knowledge, employ network thinking and have the courage to make new experiences.
<G-vec00296-003-s254><break_down.gehen><de> Ein kreativer Mensch will neue Wege gehen, kann Ideen entwickeln, seine Fantasie nutzen, sein Wissen anwenden, vernetzt denken und hat den Mut, neue Erfahrungen zu machen.
<G-vec00296-003-s255><break_down.gehen><en> As already mentioned, Martin Meadows challenges common clichés about successful entrepreneurs and encourages people to try and break new ground.
<G-vec00296-003-s255><break_down.gehen><de> Wie bereits erwähnt fordert Martin Meadows gängige Klischees über erfolgreiche Unternehmer heraus und regt dazu an neue Wege auszuprobieren und zu gehen.
<G-vec00296-003-s256><break_down.gehen><en> Shopping, cinema, culture, events, parties, dining, exhibitions - perfect for a short break for the whole family, as entertainment is taken care of here. more...
<G-vec00296-003-s256><break_down.gehen><de> Shopping, Kino, Kultur, Veranstaltungen, Party, Essen gehen, Ausstellungen - genau das Richtige für einen Kurztrip für die ganze Familie, denn hier ist für Unterhaltung gesorgt.mehr...
<G-vec00296-003-s257><break_down.gehen><en> It is best to break the package with your fingers.
<G-vec00296-003-s257><break_down.gehen><de> Am einfachsten geht es, wenn Sie in die Hocke gehen.
<G-vec00296-003-s258><break_down.gehen><en> I do not want to go into that in detail here, but I will say that we are constantly guided by this principle: it is only when we are able to break new ground, it is only when we are willing to leave well-trodden paths behind – and encourage others to do so – that can we maintain and improve our prosperity.
<G-vec00296-003-s258><break_down.gehen><de> Das will ich hier im Einzelnen nicht tun, sondern nur sagen, dass uns immer wieder der Gedanke leitet: Nur wenn wir neue Wege gehen, nur wenn wir bereit sind, eingefahrene Spuren zu verlassen, und Menschen ermutigen, dies zu tun, dann werden wir unseren Wohlstand erhalten und mehren können.
<G-vec00296-003-s259><break_down.gehen><en> “In the future, I do not only want to spend more time with my family, but I also want to break new ground professionally as an industrial engineer.
<G-vec00296-003-s259><break_down.gehen><de> In Zukunft will ich nicht nur mehr Zeit mit meiner Familie verbringen, sondern auch beruflich als Wirtschaftsingenieur neue Wege gehen.
<G-vec00296-003-s260><break_down.gehen><en> Innovative WE break new ground and provide creative ideas.
<G-vec00296-003-s260><break_down.gehen><de> Innovativ WIR gehen neue Wege und sind kreative Ideengeber.
<G-vec00296-003-s261><break_down.gehen><en> With the Industrie 4.0 Award, ROI Management Consulting honors companies that break new ground in Smart Factory or Smart Supply Chain.
<G-vec00296-003-s261><break_down.gehen><de> Mit dem Industrie 4.0 Award zeichnet ROI Unternehmen aus, die mit ihren Lösungen neue Wege in der Smart Factory oder im Supply Chain Management gehen.
<G-vec00296-003-s262><break_down.gehen><en> Sometimes you just have to be brave and break new ground.
<G-vec00296-003-s262><break_down.gehen><de> Manchmal muss man einfach mutig sein und neue Wege gehen.
<G-vec00296-003-s263><break_down.gehen><en> In order to make managers fit for the challenges of the working world 4.0, continuing education must also break new ground: Both new training contents and new training formats are needed. Our Mission statements
<G-vec00296-003-s263><break_down.gehen><de> Um Führungskräfte für die Herausforderungen der Arbeitswelt 4.0 fit zu machen, muss auch die Weiterbildung neue Wege gehen: Sowohl neue Weiterbildungsinhalte als auch neue Weiterbildungsformate sind gefragt.
<G-vec00296-003-s264><break_down.gehen><en> Optimize your business with embedded intelligence, extend your processes with guided outcomes, or break new ground with open innovation.
<G-vec00296-003-s264><break_down.gehen><de> Optimieren Sie Ihr Unternehmen mit integrierter Intelligenz, erweitern Sie Ihre Prozesse unter Anleitung oder gehen Sie neue Wege mithilfe offener Innovationen.
<G-vec00296-003-s265><break_down.gehen><en> Nature and environment break down, whilst the majority of people in the corridors of power (in politics, economics and media), the so-called elites, are still pouring oil into the fire of irrationality with their prayer-wheel manner of shouting "growth, growth, growth".
<G-vec00296-003-s265><break_down.gehen><de> Natur und Umwelt gehen zur Sau, während der Großteil der Personen an den Schaltstellen der Macht (in Politik, Wirtschaft und Medien), die sogenannten Eliten, noch Öl ins Feuer der Unvernunft giessen mit ihrem gebetsmühlenartigen Ruf nach «Wachstum, Wachstum, Wachstum».
<G-vec00296-003-s304><break_down.lösen><en> At the University of St. Gallen, we have always taught students to break away from a pure model perspective, to factor in the underlying assumptions and to even question those assumptions.
<G-vec00296-003-s304><break_down.lösen><de> An der Universität St. Gallen bringen wir den Studenten seit jeher bei, sich von der reinen Modelloptik zu lösen, die zugrundeliegenden Annahmen einzubeziehen – und auch zu hinterfragen.
<G-vec00296-003-s305><break_down.lösen><en> We systematically enable you to break free of conventional patterns of thinking and expand your perspective on your business
<G-vec00296-003-s305><break_down.lösen><de> Wir ermöglichen Ihnen auf systematische Weise, sich von konventionellen Denkmustern zu lösen und eine völlig neue Perspektive auf Ihr Geschäft einzunehmen.
<G-vec00296-003-s306><break_down.lösen><en> (4) The provider reserves the right to break away from the obligation to fulfill the contract, if the goods are to be delivered by his supplier to the date of delivery and the delivery remains undone entirely or partially.
<G-vec00296-003-s306><break_down.lösen><de> (4) Der Anbieter behält sich vor, sich von der Verpflichtung zur Erfüllung des Vertrages zu lösen, wenn die Ware durch einen Lieferanten zum Tag der Auslieferung anzuliefern ist und die Anlieferung ganz oder teilweise unterbleibt.
<G-vec00296-003-s307><break_down.lösen><en> Press the card in at several points if necessary to break up the adhesive behind the battery.
<G-vec00296-003-s307><break_down.lösen><de> Drücke die Karte weiter rein, um den ganzen Kleber zu lösen.
<G-vec00296-003-s308><break_down.lösen><en> If God holds us, there's no power that can break His hold...none.
<G-vec00296-003-s308><break_down.lösen><de> Wenn Gott uns in seiner Hand hält, gibt es keine Kraft, die diesen Griff lösen kann... keine.
<G-vec00296-003-s309><break_down.lösen><en> The oils in peanut butter will break down many adhesives.
<G-vec00296-003-s309><break_down.lösen><de> Die Öle in Erdnussbutter, ob du es glaubst oder nicht, lösen viele Klebstoffe.
<G-vec00296-003-s310><break_down.lösen><en> In addition, deformation of the sleeve during the closing process causes any incrustations inside the sleeve to break away.
<G-vec00296-003-s310><break_down.lösen><de> Zudem lösen sich Verkrustungen am Inneren der Manschette während des Schließvorgangs durch die Verformung.
<G-vec00296-003-s311><break_down.lösen><en> It comes from knowing that you have achieved your goals, and have been able to break your bonds with the earthly links that no longer serve you.
<G-vec00296-003-s311><break_down.lösen><de> Das kommt so – aus dem Wissen heraus, dass ihr eure Ziele erreicht habt und fähig gewesen seid, eure Bindung an irdische Verknüpfungen zu lösen, die euch nicht länger dienlich sind.
<G-vec00296-003-s312><break_down.lösen><en> The light is the go-ahead for the process: The electrons are stimulated, break away from their atoms and become free movable.
<G-vec00296-003-s312><break_down.lösen><de> Das Licht ist der Startschuss für den Prozess: Die Elektronen werden angeregt, lösen sich von ihren Atomen und werden frei beweglich.
<G-vec00296-003-s313><break_down.lösen><en> Seek to break away from it; make yourselves free of that, what is your ruin; you have overcome hard matter already a long time ago – do not let yourselves be anew captured by it, but seek to become free of all form.
<G-vec00296-003-s313><break_down.lösen><de> Suchet euch zu lösen von ihr, machet euch frei von dem, was euer Verderben ist, Ihr habt die harte Materie schon vor langer Zeit überwunden - lasset euch nicht von ihr aufs neue gefangennehmen, sondern suchet frei zu werden von jeglicher Form.
<G-vec00296-003-s314><break_down.lösen><en> - Urging them to dismantle paramilitary groups and break their links with the security forces in line with repeated United Nations human rights recommendations.
<G-vec00296-003-s314><break_down.lösen><de> - Bitte lösen Sie paramilitärische Gruppen auf und lösen Sie deren Verbindungen zu den Sicherheitskräften, wie es die Vereinten Nationen in ihren Empfehlungen zum Schutz der Menschenrechte mehrfach ausgesprochen haben.
<G-vec00296-003-s315><break_down.lösen><en> Similarly, pieces of the plaque can break off and travel through the bloodstream and block an artery elsewhere.
<G-vec00296-003-s315><break_down.lösen><de> In ähnlicher Weise können sich Plaquefragmente lösen und auf ihrem Weg durch den Blutstrom eine Arterie an einer anderen Stelle blockieren.
<G-vec00296-003-s316><break_down.lösen><en> As of Gods and Monsters, Caroline and Alaric break off their engagement being Caroline still wants to be with Stefan.
<G-vec00296-003-s316><break_down.lösen><de> In Götter und Monster lösen Caroline und Alaric ihre Verlobung auf, weil Caroline immer noch Gefühle für Stefan hat.
<G-vec00296-003-s317><break_down.lösen><en> They were so caught up in the lust of the moment, to break from it is painfully annoying.
<G-vec00296-003-s317><break_down.lösen><de> Sie waren so in der Lust des Augenblicks gefangen, sich davon zu lösen war schmerzlich und lästig.
<G-vec00296-003-s318><break_down.lösen><en> Break away from static patterns and rigid layout thinking.
<G-vec00296-003-s318><break_down.lösen><de> Lösen Sie sich von statischen Mustern und starrem Layout-Denken.
<G-vec00296-003-s319><break_down.lösen><en> Only then man fashions himself so that he is suitable to work for me and my kingdom that he therefore can accomplish real vineyard work, without respect for persons and for class to put the same aim before the eyes of fellowmen and to bring them so far through enlightenment about me myself that they carry out at themselves the same – to again break away from the earthly world and to take up the fight against matter.
<G-vec00296-003-s319><break_down.lösen><de> Dann erst gestaltet sich der Mensch selbst so, daß er tauglich ist, für Mich und Mein Reich zu arbeiten, daß er also rechte Weinbergsarbeit verrichten kann, ohne Ansehen der Person und des Standes den Mitmenschen das gleiche Ziel vor Augen zu stellen und sie durch Aufklärungen über Mich Selbst so weit zu bringen, daß sie an sich selbst das gleiche vollziehen - wieder sich zu lösen von der irdischen Welt und den Kampf gegen die Materie aufzunehmen.
<G-vec00296-003-s320><break_down.lösen><en> The Scorpions break up shortly, but founder and guitarist Rudolf Schenker has already found a good sideline.
<G-vec00296-003-s320><break_down.lösen><de> Die Scorpions lösen sich demnächst auf, doch Band-Gründer Rudolf Schenker hat schon eine gute Nebenbeschäftigung gefunden.
<G-vec00296-003-s321><break_down.lösen><en> Once you've listened to AVEC's sounds, it's hard to break away from them.
<G-vec00296-003-s321><break_down.lösen><de> Hat man AVECs Klängen einmal gelauscht, kann man sich nur mehr schwer davon lösen.
<G-vec00296-003-s322><break_down.lösen><en> CAUSE During normal braking small particles of the rotor surface break off.
<G-vec00296-003-s322><break_down.lösen><de> URSACHE Beim normalen Bremsvorgang lösen sich Metallpartikel von der Bremsscheibe.
<G-vec00296-003-s323><break_down.machen><en> Around noon we have our lunch break at a small hut.
<G-vec00296-003-s323><break_down.machen><de> Gegen 12 Uhr machen wir an einer Hütte Halt und legen unsere wohlverdiente Mittagspause ein.
<G-vec00296-003-s324><break_down.machen><en> No matter what the police tells you – they will always try to intimidate you and to break possible resistance.
<G-vec00296-003-s324><break_down.machen><de> Egal was die BeamtInnen sagen oder wie, sie werden versuchen, dir Angst zu machen, dich einzuschüchtern, dich klein zu kriegen.
<G-vec00296-003-s325><break_down.machen><en> During a break for lunch, Iris and Emolga have an unpleasant encounter with a group of three well-dressed and snooty girls, who throw around some insults about their appearance and then flounce away laughing.
<G-vec00296-003-s325><break_down.machen><de> Als sie aber auf ihrer Reise eine Essenspause einlegen, haben Lilia und Emolga eine unerfreuliche Begegnung mit drei hochnäsigen Mädchen, die mit Beleidigungen über ihr „unattraktives“ Aussehen nur so um sich werfen und sich lachend aus dem Staub machen.
<G-vec00296-003-s326><break_down.machen><en> London's a favourite spot of mine for a city break, but I have to say Barcelona is a very easy city to come home to.
<G-vec00296-003-s326><break_down.machen><de> London ist für mich einer der schönsten Orte, um eine Städtreise zu machen, aber in Barcelona ist sehr einfach sich schnell zu Hause zu fühlen.
<G-vec00296-003-s327><break_down.machen><en> Whatever your reason for visiting Milan, the Antares Accademia Hotel is the perfect venue for an exhilarating and exciting break away.
<G-vec00296-003-s327><break_down.machen><de> Die exzellenten Einrichtungen und die fantastische Lage machen das Antares Accademia Hotel zur perfekten Basis für die Erkundung von Mailand.
<G-vec00296-003-s328><break_down.machen><en> Getting a bit hungry I decide to walk for another hour and then take a lunch break.
<G-vec00296-003-s328><break_down.machen><de> Ich nehme mir vor, noch ein knappes Stündchen zu gehen und will dann Mittagspause machen.
<G-vec00296-003-s329><break_down.machen><en> Property and mortgage related Savings couple realized not only that they fit together to 12 % but also what date they will break up, and why.
<G-vec00296-003-s329><break_down.machen><de> Vor kurzem: Ein Päarchen hat realisiert das sie nicht nur zusammen passen zum 61 % aber auch an welchem Datum Sie miteinander Schluß machen und wieso.
<G-vec00296-003-s330><break_down.machen><en> Incl. 1h lunch break and a shorter break in the morning and afternoon.
<G-vec00296-003-s330><break_down.machen><de> Wir machen eine einstündige Mittagspause sowie kurze Pausen am Vormittag und Nachmittag.
<G-vec00296-003-s331><break_down.machen><en> The father told me that I should come again at 14.30 o'clock, just when they have their 30 minute lunch/afternoon break.
<G-vec00296-003-s331><break_down.machen><de> Der Vater sagte mir, dass ich noch mal um 14.30 Uhr kommen solle, gerade dann wenn die ihre 30 minütige Mittags-/Nachmittagspause machen.
<G-vec00296-003-s332><break_down.machen><en> But at more than 4000 metres above sea level, shovelling sand is so tiring that we break for lunch instead.
<G-vec00296-003-s332><break_down.machen><de> Auf über 4000 Metern ist das Sandschaufeln aber so anstrengend, dass wir lieber Mittagspause machen.
<G-vec00296-003-s333><break_down.machen><en> Whatever your reason for visiting Dubai, the Dubai Youth Hotel is the perfect venue for an exhilarating and exciting break away.
<G-vec00296-003-s333><break_down.machen><de> Wenn Sie nach einer komfortablen und günstig gelegenen Unterkunft in Dubai suchen, machen Sie doch das Dubai Youth Hotel zu Ihrem Zuhause weg von Zuhause.
<G-vec00296-003-s334><break_down.machen><en> There will be a lunch break of 90 minutes.
<G-vec00296-003-s334><break_down.machen><de> Wir machen etwa 90 Minuten Mittagspause.
<G-vec00296-003-s335><break_down.machen><en> Those who simply want to rest and have cheap food should have their break in Tejeda.
<G-vec00296-003-s335><break_down.machen><de> Wer einfach ausruhen und günstig speisen möchte, der sollte im Ort Tejeda Rast machen.
<G-vec00296-003-s336><break_down.machen><en> December 2017 counseling break Between Christmas and Sylvester will be no counseling at BASTA!.
<G-vec00296-003-s336><break_down.machen><de> Beratungspause Zwischen Weihnachten und Silvester machen wir keine Beratungen.
<G-vec00296-003-s337><break_down.machen><en> Afterwards, we will take a walk through the city to see its historic monuments, taking a break at a coffee shop decorated with pictures from The Godfather, the film that made Corleone world-famous.
<G-vec00296-003-s337><break_down.machen><de> Danach lernen wir auf einem Spaziergang die Stadt mit ihren historischen Monumenten kennen und machen Halt in einem Café, geschmückt mit Bildern aus dem Film „Der Pate“, durch den Corleone weltweit bekannt wurde.
<G-vec00296-003-s338><break_down.machen><en> Whatever your reason for visiting Saint-Malo, the Hotel De La Cite is the perfect venue for an exhilarating and exciting break away.
<G-vec00296-003-s338><break_down.machen><de> Die exzellenten Einrichtungen und die fantastische Lage machen das Hotel De La Cite zum perfekten Ausgangspunkt für die Erkundung von Saint-Malo.
<G-vec00296-003-s339><break_down.machen><en> For the tour “”confirmed””riders leave towards the hill and after you have followed the river you continue in direction to the village of Ghazoua, then down by the dunes for picnic break in a lovely forest .
<G-vec00296-003-s339><break_down.machen><de> Der Parcours für “”Erfahrene”” Reiter geht den Berg hinauf, um danach dem Fluss entlang und in Richtung des Dorfes Ghazoua zu reiten, dann geht es bergab durch die Dünen um Picknick-Pause in einem schönen Waldstück zu machen.
<G-vec00296-003-s340><break_down.machen><en> No matter how heavy the workload, it’s always more manageable when you break them up into chunks… Visualizing everything that needs to be done through that list allows you to break down the bigger tasks into smaller achievable ones, which also means you can start right now.
<G-vec00296-003-s340><break_down.machen><de> Egal wie viel du machen musst, es hilft immer das große Ganze in kleine Teile runter zu brechen… Die kleinen Aufgaben sind einfacher zu überschauen und bedeutet auch meist, dass du gleich beginnen kannst.
<G-vec00296-003-s341><break_down.machen><en> But we also had just a few minutes to take a break – as soon as we were up it went down to go to eat again.
<G-vec00296-003-s341><break_down.machen><de> Wir hatten aber auch kaum Zeit da groß was zu machen – gleich nachdem wir oben waren ging es wieder runter um Essen zu gehen.
<G-vec00296-003-s380><break_down.pausen><en> These sweet dumplings are served not only as snacks, but also to break the fast during Ramadan.
<G-vec00296-003-s380><break_down.pausen><de> Diese süßen Klöße werden nicht nur als Snack serviert, sondern auch in den Pausen des Ramadan gegessen.
<G-vec00296-003-s381><break_down.pausen><en> Play faster: This option lets you play faster than usual by reducing the break time.
<G-vec00296-003-s381><break_down.pausen><de> Play faster: Mit dieser Option können Sie schneller als normal spielen, da die Pausen verkürzt sind.
<G-vec00296-003-s382><break_down.pausen><en> The Technische Informationsbibliothek (TIB) – German National Library of Science and Technology offers facilities tailored to your different needs: group study rooms for shared learning, quiet reading desks for individual learning, as well as sufficient space to enjoy a well-earned break.
<G-vec00296-003-s382><break_down.pausen><de> Die Technische Informationsbibliothek (TIB) bietet Ihnen auf unterschiedliche Bedürfnisse zugeschnittene Räumlichkeiten: Gruppenarbeitsräume für gemeinsames Lernen, ruhige Arbeitsplätze für individuelles Lernen sowie Platz für entspannte Pausen.
<G-vec00296-003-s383><break_down.pausen><en> The reliable, forgery proof nature of Kelio software solutions improved traceability and impartiality in managing statutory working hours, overtime, break times, etc.
<G-vec00296-003-s383><break_down.pausen><de> Die Zuverlässigkeit und Fälschungssicherheit der Kelio-Softwarelösungen sorgen für eine verbesserte Nachweisbarkeit und Neutralität beim Umgang mit der gesetzlichen Arbeitszeit, Überstunden, Pausen usw.
<G-vec00296-003-s384><break_down.pausen><en> Baroque-style castles, forts and picturesque villages invite to a relaxing cycle break.
<G-vec00296-003-s384><break_down.pausen><de> Barocke Schlösser, Burgen und malerische Dörfer säumen den Weg und laden zu kulturellen Pausen ein.
<G-vec00296-003-s385><break_down.pausen><en> Or at work, the schedules, how often you can take a break, or certain tasks that you maybe manage differently than others would do it.
<G-vec00296-003-s385><break_down.pausen><de> Oder im Beruf, die Arbeitszeiten, wie oft es Pausen gibt, oder auch bestimmte Aufgaben des Jobs, die du vielleicht ein wenig anders erledigst als es andere machen würden.
<G-vec00296-003-s386><break_down.pausen><en> Take a break, have a glass of wine with friends, have a scoop of ice cream or go for a walk to clear your head but come back to it feeling refreshed and with a clear sense of purpose.
<G-vec00296-003-s386><break_down.pausen><de> Nimm dir deine Zeit und mach Pausen, trink ein Glas Wein mit Freunden, iss einen Becher Eis oder geh eine Runde spazieren, um deinen Kopf frei zu bekommen.
<G-vec00296-003-s387><break_down.pausen><en> 21 ski huts, mountain restaurants and sun terraces await you on your ski break in Flachau.
<G-vec00296-003-s387><break_down.pausen><de> 21 Skihütten, Bergrestaurants und Sonnenterrassen erwarten Sie in Ihren Pausen vom Skifahren.
<G-vec00296-003-s388><break_down.pausen><en> Complex exercises such as dumbbell bench presses, dumbbell presses on inclined benches, or dumbbell shoulder presses can be more easily executed with an exercise station; the dumbbell rod can be stored close to where you are exercising when it is time for a break.
<G-vec00296-003-s388><break_down.pausen><de> Komplexe Übungen wie Langhantelbankdrücken, Langhantelschrägbankdrücken oder Langhantelschulterdrücken sind mit einer Trainingsstation einfacher durchführbar, da die Hantelstange in den Pausen übungsnah abgelegt werden kann.
<G-vec00296-003-s389><break_down.pausen><en> Have a little break at the popular snow bar at the Blombergtenne (a great place for night owls) or warm up
<G-vec00296-003-s389><break_down.pausen><de> Daneben lädt die viel besuchte Schneebar an der Blombergtenne (ein echter Tipp für Nachtschwärmer) zu kurzen Pausen ein, während man sich im Gastraum stärken und aufwärmen kann.
<G-vec00296-003-s390><break_down.pausen><en> Incl. 1h lunch break and a shorter break in the morning and afternoon.
<G-vec00296-003-s390><break_down.pausen><de> Wir machen eine einstündige Mittagspause sowie kurze Pausen am Vormittag und Nachmittag.
<G-vec00296-003-s391><break_down.pausen><en> We are scheduled for 18 days without a break.
<G-vec00296-003-s391><break_down.pausen><de> Wir werden für 18 Tage ohne Pausen eingeteilt.
<G-vec00296-003-s392><break_down.pausen><en> If you are permanently under stress, plan on taking a break and try to really switch off during this time.
<G-vec00296-003-s392><break_down.pausen><de> Wenn Sie dauerhaft unter Strom stehen, planen Sie sich feste Pausen ein und versuchen Sie in dieser Zeit wirklich abzuschalten.
<G-vec00296-003-s393><break_down.pausen><en> She’s enjoying the sun in her leisure time and wears the glasses, when she is having a break for a coffee in a nice chic cafe.
<G-vec00296-003-s393><break_down.pausen><de> Sie genießt die Sonne in ihrer Freizeit und trägt eine Time For Wood Sonnenbrille, wenn sie in die Pausen geht und ihren Kaffee in einem süßen, chicen Café schlürft.
<G-vec00296-003-s394><break_down.pausen><en> Our students’ café, which also sells sweets and soft drinks, is also open at break times.
<G-vec00296-003-s394><break_down.pausen><de> In diesen Pausen ist auch unser Schülercafé geöffnet, wo es kleine Süßigkeiten und Erfrischungsgetränke zu kaufen gibt.
<G-vec00296-003-s395><break_down.pausen><en> The terrace and the balcony that encircles the building on the sixth floor are perfect for taking a break and networking under the open sky.
<G-vec00296-003-s395><break_down.pausen><de> Die Terrasse des Gebäudes und den umlaufenden Balkon im sechsten Stock können Sie für Pausen und Netzwerken im Freien nutzen.
<G-vec00296-003-s396><break_down.pausen><en> There will be break for food and drinks for the meeting.
<G-vec00296-003-s396><break_down.pausen><de> Es wird Pausen zum Essen und Trinken geben.
<G-vec00296-003-s397><break_down.pausen><en> Players are encouraged to study the break schedule for each tournament they wish to play, as break length and timing may vary from one event to the next.
<G-vec00296-003-s397><break_down.pausen><de> Die Spieler sind gehalten, sich den Pausenplan für jedes Turnier anzusehen, an dem sie teilnehmen wollen, denn Länge und Abstand der Pausen können je nach Event unterschiedlich ausfallen.
<G-vec00296-003-s398><break_down.pausen><en> This gave everyone the opportunity to take a short collective break, share a joke, wipe away the sweat and maybe even sing a song.
<G-vec00296-003-s398><break_down.pausen><de> Dieses geschah bei gemeinsamen Pausen, beim gemeinsamen Scherzen, wenn man sich den Schweiß abwischte und vielleicht gemeinsam ein Lied sang.
<G-vec00296-003-s475><break_down.unterbrechen><en> Also, do not post extremely large pictures, which may break the advanced layouts used.
<G-vec00296-003-s475><break_down.unterbrechen><de> Bitte auch keine extrem großen Bilder posten, die die erweiterten Layouts unterbrechen könnten.
<G-vec00296-003-s476><break_down.unterbrechen><en> STRIPED FAN BLADES The striped fan blades break the flow of air into smaller channels enabling a more optimized flow and quieter rotation while the deep angled blade increases downward pressure.
<G-vec00296-003-s476><break_down.unterbrechen><de> Die gestreiften Lüfterflügel unterbrechen den Luftstrom in kleinere Kanäle, was eine optimierte Strömung und eine ruhigere Rotation ermöglicht, während der tief geneigte Flügel den Druck nach unten erhöht.
<G-vec00296-003-s477><break_down.unterbrechen><en> Right there is a rest area where we take a break.
<G-vec00296-003-s477><break_down.unterbrechen><de> Genau dort ist ein Rastplatz, auf dem wir die Fahrt unterbrechen.
<G-vec00296-003-s478><break_down.unterbrechen><en> Break up your conference and be inspired by the beautiful views of the outdoor gym!
<G-vec00296-003-s478><break_down.unterbrechen><de> Unterbrechen Sie die Konferenz, und lassen Sie sich von der schönen Aussicht im Outdoor-Fitnessbereich inspirieren.
<G-vec00296-003-s479><break_down.unterbrechen><en> She wants to break the cycle of war and exclusion; she wants to liberate children from generations of hatred.
<G-vec00296-003-s479><break_down.unterbrechen><de> Sie will nun den Kreis von Krieg und Ausgrenzung unterbrechen; sie will Kinder von Generationen des Hasses befreien.
<G-vec00296-003-s480><break_down.unterbrechen><en> This can prove to be a disruptive factor, which is why, in the case of rather powerful engines, clutches can be installed which, if the engine decelerates too much, partially break the frictional connection.
<G-vec00296-003-s480><break_down.unterbrechen><de> Der kann sich als Störfaktor erweisen, weshalb bei eher starken Motoren Kupplungen eingebaut werden können, die bei zu viel Verzögerung durch den Motor die kraftschlüssige Verbindung teilweise unterbrechen.
<G-vec00296-003-s481><break_down.unterbrechen><en> (ATTENTION: Technical Defeat or leaving the clan will not break the winning streak.)
<G-vec00296-003-s481><break_down.unterbrechen><de> Technische Niederlagen oder Verlassen des Clans unterbrechen die Serie nicht.
<G-vec00296-003-s482><break_down.unterbrechen><en> Between 12.30h and 13.30h, I'll put bread and spreads on the table and we will break for coffee/tea in the morning and the afternoon.
<G-vec00296-003-s482><break_down.unterbrechen><de> Von 12:30 Uhr bis 13:30 Uhr stelle ich Ihnen eine Brotzeit auf den Tisch und morgens und nachmittags unterbrechen wir für eine Kaffee/Tee-Pause.
<G-vec00296-003-s483><break_down.unterbrechen><en> Managers can no longer break the referee’s count out by entering and exiting the ring while two competitors are outside the ring
<G-vec00296-003-s483><break_down.unterbrechen><de> Manager können nicht mehr durch Betreten und Verlassen des Rings das Anzählen des Ringrichters unterbrechen, solange sich beide Gegner außerhalb des Rings befinden.
<G-vec00296-003-s484><break_down.unterbrechen><en> We would like to offer to the healthy and the sick children the chance to break out of this vicious circle.
<G-vec00296-003-s484><break_down.unterbrechen><de> Den gesunden und den kranken Kindern wünschen wir die Möglichkeit, diesen Kreislauf zu unterbrechen.
<G-vec00296-003-s485><break_down.unterbrechen><en> However in a modern sporting environment these are distractions that break flow.
<G-vec00296-003-s485><break_down.unterbrechen><de> Aber in der modernen Sport-Umgebung sind es Ablenkungen, die den Flow unterbrechen.
<G-vec00296-003-s486><break_down.unterbrechen><en> Added a sub-menu on the Pause Breaks command in the Break menu, to enable pausing for a specified interval.
<G-vec00296-003-s486><break_down.unterbrechen><de> Im Pause-Menü gibt es jetzt ein Untermenü zum Kommando Pausen unterbrechen, um Pausen für eine bestimmte Zeitdauer zu unterbrechen.
<G-vec00296-003-s487><break_down.unterbrechen><en> Rest the pointer on the folder, document, or list item on which you want to break inheritance, click the arrow that appears, and then click Manage Permissions.
<G-vec00296-003-s487><break_down.unterbrechen><de> Positionieren Sie den Mauszeiger auf dem Ordner, Dokument oder Listenelement, für das Sie die Vererbung unterbrechen möchten, klicken Sie auf den Pfeil, der angezeigt wird, und klicken Sie dann auf Berechtigungen verwalten.
<G-vec00296-003-s488><break_down.unterbrechen><en> 4 Select whether to Reset inheritance or Break inheritance, then click Save.
<G-vec00296-003-s488><break_down.unterbrechen><de> 4 Aktivieren Sie Vererbung zurücksetzen oder Vererbung unterbrechen, und klicken Sie dann auf Speichern.
<G-vec00296-003-s489><break_down.unterbrechen><en> The treatment focuses on reducing muscle tension in order to break the increasing pain produced in the vicious circle.
<G-vec00296-003-s489><break_down.unterbrechen><de> Die Behandlung konzentriert sich daher auf die Reduktion der Muskelanspannung, um den schmerzaufschaukelnden Teufelskreis zu unterbrechen.
<G-vec00296-003-s490><break_down.unterbrechen><en> A: I can hear you between my signals; break in on my transmission.
<G-vec00296-003-s490><break_down.unterbrechen><de> QSK Ich kann Sie zwischen meinen Zeichen hören; Sie dürfen mich während meiner Übermittlung unterbrechen.
<G-vec00296-003-s491><break_down.unterbrechen><en> After 12 weeks of use, take a break for at least 4 weeks.
<G-vec00296-003-s491><break_down.unterbrechen><de> Bitte unterbrechen Sie die Anwendung des Produktes nach 12 Wochen regelmäßiger Nutzung für mindestens 4 Wochen.
<G-vec00296-003-s492><break_down.unterbrechen><en> Our professional physical trainer invites you to break away from your desk for a 10-minute office exercise that will help you relieve tension and promote a sense of wellbeing.
<G-vec00296-003-s492><break_down.unterbrechen><de> Unser professioneller Fitness-Trainer lädt Sie ein, Ihre Schreibtischarbeit mit zehn Minuten Übungen im Büro zu unterbrechen, mit denen Sie Spannung abbauen und Ihr Wohlbefinden fördern können.
<G-vec00296-003-s493><break_down.unterbrechen><en> To avoid this, consider taking a short break from the conversation when you feel like you're about to start yelling.
<G-vec00296-003-s493><break_down.unterbrechen><de> Vermeide dies, indem du erwägst, euer Gespräch kurz zu unterbrechen, wenn du das Gefühl hast, gleich vor Wut zu platzen.
<G-vec00296-003-s570><break_down.zerbrechen><en> Let them understand how much it will cost them if they want to break us.
<G-vec00296-003-s570><break_down.zerbrechen><de> Sollen sie begreifen, wieviel es sie kostet, wenn sie uns zerbrechen wollen.
<G-vec00296-003-s571><break_down.zerbrechen><en> It's good to develop a sense of dispassion and disenchantment for the body, to develop a sense of samvega, so that when it breaks down we don't break down, too.
<G-vec00296-003-s571><break_down.zerbrechen><de> Es ist gut, einen gewissen Gleichmut, eine gewisse Ernüchterung gegenüber dem Körper zu entwickeln, ein Gefühl von Samvega zu entwickeln, so dass wir, wenn er zerbricht, nicht auch zerbrechen.
<G-vec00296-003-s572><break_down.zerbrechen><en> And it shall come to pass at that day, that I will break the bow of Israel, in the valley of Jezreel.
<G-vec00296-003-s572><break_down.zerbrechen><de> Und es wird geschehen an jenem Tage, da werde ich den Bogen Israels zerbrechen im Tale Jisreel.
<G-vec00296-003-s573><break_down.zerbrechen><en> And it shall come to pass at that day, that I will break the bow of Israel, in the valley of Jezreel.”
<G-vec00296-003-s573><break_down.zerbrechen><de> 5 Zur selben Zeit will ich den Bogen Israels zerbrechen im Tal Jesreel.
<G-vec00296-003-s574><break_down.zerbrechen><en> If the artificial eye should break, please keep as many fragments as possible as a template for a new production.
<G-vec00296-003-s574><break_down.zerbrechen><de> Sollte das künstliche Auge einmal zerbrechen, dann heben Sie bitte möglichst alle Bruchstücke als Vorlage für eine Neuanfertigung auf.
<G-vec00296-003-s575><break_down.zerbrechen><en> Titanium heaters are virtually unbreakable, they will not shatter if they are knocked while the element is hot, but if they are dropped from a height then they can break up.
<G-vec00296-003-s575><break_down.zerbrechen><de> Titanheizer sind praktisch unverwüstlich, sie zerbrechen nicht wenn sie einen Schlag erhalten während das Heizelement noch heiß ist, allerdings bedeutet das nicht, dass sie nicht zerbrechen können, wenn sie aus einer größeren Höhe fallen gelassen werden.
<G-vec00296-003-s576><break_down.zerbrechen><en> 6 You shall break it in pieces and pour oil on it; it is a grain offering.
<G-vec00296-003-s576><break_down.zerbrechen><de> 6 du sollst es in Stücke zerbrechen und Öl darauf gießen: es ist ein Speisopfer.
<G-vec00296-003-s577><break_down.zerbrechen><en> The change from crystalline to amorphous, referred to as reset herein, is generally a higher current operation, which includes a short high current density pulse to melt or break down the crystalline structure, after which the phase change material cools quickly, quenching the phase change process and allowing at least a portion of the phase change structure to stabilize in the amorphous state.
<G-vec00296-003-s577><break_down.zerbrechen><de> Die Änderung von kristallin zu amorph, die hierin als Zurücksetzung bezeichnet wird, findet im Allgemeinen bei starkem Strom statt und schließt einen kurzen Impuls hoher Stromdichte ein, um die Kristallstruktur zu zerschmelzen oder zu zerbrechen, wonach das Phasenänderungsmaterial schnell abkühlt, wobei der Phasenänderungsprozess gequencht wird, was ermöglicht, dass zumindest ein Teil der Phasenänderungsstruktur sich im amorphen Zustand stabilisiert.
<G-vec00296-003-s578><break_down.zerbrechen><en> Lots of relationships break down because of the stress of the social background.
<G-vec00296-003-s578><break_down.zerbrechen><de> Viele Beziehungen würden zerbrechen durch den Stress des Milieus.
<G-vec00296-003-s579><break_down.zerbrechen><en> 10 "Then you are to break the jar in the sight of the men who accompany you 11 and say to them, 'Thus says the LORD of hosts, "Just so will I break this people and this city, even as one breaks a potter's vessel, which cannot again be repaired; and they will bury in Topheth because there is no other place for burial.
<G-vec00296-003-s579><break_down.zerbrechen><de> 10 Und du sollst den Krug vor den Augen der Männer zerbrechen, die mit dir gegangen sind, 11 und zu ihnen sagen: So spricht der HERR der Heerscharen: Ebenso werde ich dieses Volk und diese Stadt zerbrechen, wie man ein Gefäß des Töpfers zerbricht, das nicht wiederhergestellt werden kann.
<G-vec00296-003-s581><break_down.zerbrechen><en> 20 A bruised reed shall he not break, and smoking flax shall he not quench, till he send forth judgment unto victory.
<G-vec00296-003-s581><break_down.zerbrechen><de> Matthaeus 12.20 20 A geknickte Rohr wird er nicht zerbrechen, und den glimmenden Docht wird er nicht auslöschen, bis er Sendest Urteil zum Sieg.
<G-vec00296-003-s582><break_down.zerbrechen><en> Luminaires in sports halls needs to be impact resistant so they do not break when balls hit them.
<G-vec00296-003-s582><break_down.zerbrechen><de> Die Leuchten in Sporthallen müssen schlagfest sein, damit sie nicht zerbrechen, wenn sie von Bällen getroffen werden.
<G-vec00296-003-s583><break_down.zerbrechen><en> *) In gas-fracking, chemicals and water are pressed with high pressure into deeply-lying strata of rock containing gases, in order to break them up and extract the gas contained.
<G-vec00296-003-s583><break_down.zerbrechen><de> *) Beim Gas-Fracking werden Chemie und Wasser unter hohem Druck in zum Teil tief liegende gashaltige Gesteinsschichten, gepresst, um sie zu zerbrechen und das darin enthaltene Gase zu fördern.
<G-vec00296-003-s584><break_down.zerbrechen><en> The beautifully crafted figure is made of artificial stone and should not necessarily fall to the ground, otherwise it can break.
<G-vec00296-003-s584><break_down.zerbrechen><de> Die toll gearbeitete Figur ist aus Kunststein hergestellt und sollte nicht unbedingt auf den Boden fallen, da sie sonst zerbrechen kann.
<G-vec00296-003-s585><break_down.zerbrechen><en> The military vehicles will crack and break up on impact with incoming projectiles.
<G-vec00296-003-s585><break_down.zerbrechen><de> Die Militärfahrzeuge werden beim Aufprall von Geschosse knacken und zerbrechen.
<G-vec00296-003-s586><break_down.zerbrechen><en> Jonah 1:4-5 “Then the LORD sent a great wind on the sea, and such a violent storm arose that the ship threatened to break up.
<G-vec00296-003-s586><break_down.zerbrechen><de> Da ließ der HERR einen großen Wind aufs Meer kommen, und es erhob sich ein großes Ungewitter auf dem Meer, daß man meinte, das Schiff würde zerbrechen.
<G-vec00296-003-s587><break_down.zerbrechen><en> The current economic upswing could break down due to the high level of debt worldwide.
<G-vec00296-003-s587><break_down.zerbrechen><de> An der weltweit hohen Verschuldung könnte der gegenwärtige Konjunkturaufschwung zerbrechen.
<G-vec00296-003-s588><break_down.zerbrechen><en> In one house shall it be eaten; thou shalt not carry forth any of the flesh abroad out of the house; neither shall ye break a bone thereof.
<G-vec00296-003-s588><break_down.zerbrechen><de> 46 In einem Hause soll man's essen; ihr sollt nichts von seinem Fleisch hinaus vor das Haus tragen und sollt kein Bein an ihm zerbrechen.
<G-vec00599-002-s152><break_down.(sich)_brechen><en> They remain in the jaw covered by bone (referred to as impaction) or break through only partially (partial impaction).
<G-vec00599-002-s152><break_down.(sich)_brechen><de> Sie verbleiben entweder vom Knochen bedeckt im Kiefer (Retention) oder brechen teilweise durch (Teilretention).
<G-vec00599-002-s153><break_down.(sich)_brechen><en> Those who are not ready or who resist, are put through the painful process of breaking, for „bend or break” is the keynote of the Aquarian energy.
<G-vec00599-002-s153><break_down.(sich)_brechen><de> Wer nicht dazu geneigt ist oder gar widersteht, macht den schmerzhaften Prozess durch, gebrochen zu werden, denn „biegen oder brechen“ ist die Schlüsselnote der Wassermann-Energie.
<G-vec00599-002-s154><break_down.(sich)_brechen><en> You cared about us, trust us, and we will not break our promise.
<G-vec00599-002-s154><break_down.(sich)_brechen><de> Sie sorgen sich um uns, vertrauen uns und so werden wir unser Versprechen nicht brechen.
<G-vec00599-002-s155><break_down.(sich)_brechen><en> When you damage a carbon fiber part, it could break or it could conceal damage from the naked eye.
<G-vec00599-002-s155><break_down.(sich)_brechen><de> Wenn du ein Carbonfaser-Teil beschädigst, könnte es brechen oder die Beschädigung nicht auf den ersten Blick zu erkennen sein.
<G-vec00599-002-s156><break_down.(sich)_brechen><en> Behold, thou shalt sleep with thy fathers; and this people will rise up, and go a whoring after the gods of the strangers of the land, whither they go to be among them, and will forsake me, and break my covenant which I have made with them.
<G-vec00599-002-s156><break_down.(sich)_brechen><de> 31,16 Und der HERR sprach zu Mose: Siehe, du wirst schlafen bei deinen Vätern, und dies Volk wird sich erheben und nachlaufen den fremden Göttern des Landes, in das sie kommen, und wird mich verlassen und den Bund brechen, den ich mit ihm geschlossen habe.
<G-vec00599-002-s157><break_down.(sich)_brechen><en> It’s well known that there are a series of potential limitations of CRISPR that can cause what we call “off-target effects”—where basically in addition to breaking what you want to break, it can break something else in your genome.
<G-vec00599-002-s157><break_down.(sich)_brechen><de> Es ist bekannt, dass es eine Reihe von möglichen Einschränkungen von CRISPR gibt, die das verursachen können, was wir "Off-Target-Effekte" nennen - wo es im Grunde genommen nicht nur das, was man brechen will, sondern auch etwas anderes in seinem Genom brechen kann.
<G-vec00599-002-s159><break_down.(sich)_brechen><en> The attempt is not to break Burt’s record, but to appreciate his legacy.
<G-vec00599-002-s159><break_down.(sich)_brechen><de> Der Versuch geht nicht darum, Burts Rekord zu brechen, sondern darum sein Erbe zu würdigen.
<G-vec00599-002-s160><break_down.(sich)_brechen><en> The impact hammers conduct energy into the component and break up the core.
<G-vec00599-002-s160><break_down.(sich)_brechen><de> Die Schlaghämmer leiten die Energie in das Bauteil und brechen den Kern.
<G-vec00599-002-s161><break_down.(sich)_brechen><en> Attach a glass needle onto the microinjector and use your forceps to break the tip of the needle to the desired width.
<G-vec00599-002-s161><break_down.(sich)_brechen><de> Bringen Sie ein Glas Nadel auf die Mikroinjektor und nutzen Sie Ihre Zange an der Spitze der Nadel auf die gewünschte Breite zu brechen.
<G-vec00599-002-s162><break_down.(sich)_brechen><en> It signals that the installation of a package will “break” another package (or particular versions of it).
<G-vec00599-002-s162><break_down.(sich)_brechen><de> Sie deutet darauf hin, dass die Installation eines Paketes ein anderes Paket (oder bestimmte Versionen davon) „brechen“ wird.
<G-vec00599-002-s163><break_down.(sich)_brechen><en> Do not crush, chew, or break the tablet.
<G-vec00599-002-s163><break_down.(sich)_brechen><de> Zerquetschen Sie es, kauen Sie es, oder brechen Sie die Pillen nicht.
<G-vec00599-002-s164><break_down.(sich)_brechen><en> Hamas spokesman Hazem Qassem said that with the approach of the first anniversary of the “return marches,” the Palestinian people were planning to break [into Israeli territory] with the “million-man march” on Land Day to stress the main objectives of the marches.
<G-vec00599-002-s164><break_down.(sich)_brechen><de> Hazem Kassem, ein Sprecher im Namen der Hamas, sagte, dass das palästinensische Volk vor dem ersten Jahrestag der “Prozessionen” vorhatte, anlässlich des “Tag der Erde” mit der “Prozession der Millionen” an Land zu brechen, um die Hauptziele der “Prozessionen der großen Rückkehr” zu erfüllen.
<G-vec00599-002-s165><break_down.(sich)_brechen><en> At the same time, the hammer energy introduced into the component is used to break up the core sand in the component, so this can subsequently be shaken out.
<G-vec00599-002-s165><break_down.(sich)_brechen><de> Zeitgleich wird die in das Bauteil eingebrachte Hammerenergie dazu verwendet, den Kernsand im Bauteil zu brechen, um diesen anschließend herausrütteln zu können.
<G-vec00599-002-s166><break_down.(sich)_brechen><en> It is organized in more or less radical Marxist movements, determined to break all spiritual resistance by the power of violence.
<G-vec00599-002-s166><break_down.(sich)_brechen><de> Sie ist in mehr oder minder radikalmarxistischen Bewegungen zusammengefaßt, entschlossen, jeden geistigen Widerstand durch die Macht der Gewalt zu brechen.
<G-vec00599-002-s167><break_down.(sich)_brechen><en> Wotan tells him that he comes only to watch, since he cannot, as Alberich reminds him, break his agreement with Fafner, who had been given the ring and other treasure in return for the release of the goddess Freia.
<G-vec00599-002-s167><break_down.(sich)_brechen><de> Nur zu schauen sei er gekommen, antwortet Wotan, nicht zu schaffen – und Alberich erinnert seinerseits daran, daß er den Vertrag mit Fafner nicht brechen dürfe, der ja den Ring und den gesamten Schatz als Bezahlung für die Errichtung Walhalls und die Freilassung der Göttin Freia erhalten habe.
<G-vec00599-002-s168><break_down.(sich)_brechen><en> We hope to avoid a new break of the wireline by running it a little bit slower.
<G-vec00599-002-s168><break_down.(sich)_brechen><de> Wir hoffen ein neues Brechen des Bohrkabels durch langsameres Bohren verhindern zu können.
<G-vec00599-002-s169><break_down.(sich)_brechen><en> He would do anything, anything, to break what he calls the superstition of the Cross.
<G-vec00599-002-s169><break_down.(sich)_brechen><de> Er würde alles tun, alles, um das zu brechen, was er den Aberglauben des Kreuzes nennt.
<G-vec00599-002-s170><break_down.(sich)_brechen><en> Do not crush, chew, break, or open an extended-release capsule.
<G-vec00599-002-s170><break_down.(sich)_brechen><de> Zerquetschen Sie nicht, kauen Sie, brechen Sie, oder öffnen Sie eine Kapsel der verlängerten Ausgabe.
