<G-vec00098-002-s022><arouse.anregen><en> Each crystal, intentionally placed to inspire and arouse the senses, are combined with graceful curves of steel and glittering Swarovski Crystal Lighting.
<G-vec00098-002-s022><arouse.anregen><de> Swarovski Kristalle wurden bewusst platziert, um zu inspirieren und die Sinne anzuregen, und mit anmutenden Kurven aus Stahl und funkelnden Swarovski Crystal Lighting Komponenten kombiniert.
<G-vec00098-002-s092><arouse.anregen><en> There will be a greater attempt in the future to arouse those who would wish to know of our purpose.
<G-vec00098-002-s092><arouse.anregen><de> Es wird einen größeren Versuch in der Zukunft geben, um jene anzuregen, die etwas über unser Ziel erfahren möchten.
<G-vec00098-002-s114><arouse.anregen><en> As an allegory of exhibition space, Locus attempts to arouse curiosity in an audience through the artworks and provoke imagination of the possible scenarios, which the artworks have already responded to.
<G-vec00098-002-s114><arouse.anregen><de> Als Allegorie des Ausstellungsorts versucht Locus, das Publikum durch Kunstwerke neugierig zu machen, sie anzuregen, sich die Situationen vorzustellen, auf die die Kunstwerke reagiert haben.
<G-vec00098-002-s108><arouse.machen><en> The glass façades arouse curiosity, attract the attention of passers-by to the parish centre, and appear inviting.
<G-vec00098-002-s108><arouse.machen><de> Die Glasfassaden machen neugierig, rücken das Pfarrzentrum in das Blickfeld der Passanten und laden zum Besuch ein.
<G-vec00098-002-s109><arouse.machen><en> The biggest names in jazz give concerts here and regular jam sessions arouse the curiosity of guests for something new.
<G-vec00098-002-s109><arouse.machen><de> Die ganz Großen des Jazz geben hier Konzerte, regelmäßige Jamsessions machen neugierig auf Neues.
<G-vec00098-002-s110><arouse.machen><en> Even though bratwurst and mulled wine remain absolutely indispensable, it is the typical Ore Mountain dishes and their idiosyncratic names that arouse curiosity.
<G-vec00098-002-s110><arouse.machen><de> Auch wenn Bratwurst und Glühwein nicht fehlen dürfen, sind es die typisch erzgebirgischen Speisen und ihre eigenwilligen Namen, die neugierig machen.
<G-vec00098-002-s111><arouse.machen><en> They signal “attention, important information”, arouse curiosity and lead to a quick reaction.
<G-vec00098-002-s111><arouse.machen><de> Sie signalisieren „Achtung, wichtige Info“, machen neugierig und führen zu einer schnellen Reaktion.
<G-vec00098-002-s112><arouse.machen><en> But if my informant is to be believed, Ivan will only invite the Elves or the Dwarves, so I presume not to arouse Seamus’s suspicions.
<G-vec00098-002-s112><arouse.machen><de> Doch wenn man meinem Informanten Glauben schenken darf, wird Iwan entweder die Elfen oder die Zwerge einladen, aber nicht beide, wohl um Seamus nicht argwöhnisch zu machen.
<G-vec00098-002-s113><arouse.machen><en> Creative names for unknown dishes arouse the curiosity of the smallest family members.
<G-vec00098-002-s113><arouse.machen><de> Kreative Namen für unbekannte Speisen machen auch die Kleinsten neugierig.
<G-vec00098-002-s119><arouse.machen><en> To inspire, to arouse interest and to invite you to join the next Walk of Glam.
<G-vec00098-002-s119><arouse.machen><de> Um zu inspirieren, neugierig zu machen und aufzufordern, beim nächsten Walk of Glam dabei zu sein.
<G-vec00098-002-s130><arouse.stimulieren><en> You'll only have to wait 3-4 minutes and you will be filled with a pleasant warmth, that together with the vibration is going to arouse you in a whole new way.
<G-vec00098-002-s130><arouse.stimulieren><de> Hierfür musst du nur 3-4 Minuten warten und schon wirst du von einer wohligen Wärme erfüllt, die dich gemeinsam mit der Vibration auf ganz neue Art und Weise stimuliert.
