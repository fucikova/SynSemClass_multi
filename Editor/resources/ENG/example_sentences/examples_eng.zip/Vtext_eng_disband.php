<G-vec00198-002-s002><disband.auflösen><en> Actually, the problem is that when Euromaidan came to an end, and it was time to deal with political aspects, all these formations, alas, did not disband, but quite the opposite – began to gain momentum, popularizing in fact Nazi ideology.
<G-vec00198-002-s002><disband.auflösen><de> Tatsächlich besteht das Problem darin, dass sich Euromaidan nach seinem Ende und der Zeit, sich mit politischen Aspekten zu befassen, alle diese Formationen leider nicht aufgelöst hat, sondern ganz im Gegenteil — er gewann an Fahrt und gewann in der Nazi-Ideologie populär.
<G-vec00198-002-s003><disband.auflösen><en> You can also disband troops or other units if you wish to quickly get peasants into your village, and therefore have immediately-available workers.
<G-vec00198-002-s003><disband.auflösen><de> Außerdem kannst du Truppen oder andere Einheiten auflösen, wenn du schnell an Bauern kommen möchtest, damit dir rasch Arbeiter zur Verfügung stehen.
<G-vec00198-002-s004><disband.auflösen><en> If you didn't find the unit useful, or if it fails to match your playstyle, or you simply need an empty slot, you can disband the unit via the barracks screen.
<G-vec00198-002-s004><disband.auflösen><de> Wenn ihr eine Einheit nicht für nützlich befindet, sie nicht eurem Spielstil entspricht oder ihr einfach nur einen leeren Platz benötigt, könnt ihr die Einheit über das Fenster Kaserne auflösen.
<G-vec00198-002-s005><disband.auflösen><en> The “patriotic version” has it that Ramanauskas’s squad served as an impediment to German plundering, and that was the reason why the Germans wanted to disarm and disband them.
<G-vec00198-002-s005><disband.auflösen><de> Die „patriotische Version“ dagegen sagt, dass Ramanauskas’s Truppe zum Schutz gegen die Plünderei durch die Deutschen diente, was auch der Grund war, weshalb die Deutschen sie entwaffnen und auflösen wollten.
<G-vec00198-002-s006><disband.auflösen><en> The sad reality of loving the music of the 1980's is that line-ups change, bands disband or the traditional press ignores their new output.
<G-vec00198-002-s006><disband.auflösen><de> Die traurige Wirklichkeit des Liebens der Musik der achtziger Jahre ist, daß Anordnungen ändern, Bänder auflösen, oder die traditionelle Presse ignoriert ihren neuen Ausgang.
<G-vec00198-002-s010><disband.auflösen><en> For two years I have been thinking about this, slowly, carefully, patiently, and I have now decided to disband the Order, as I happen to be its Head.
<G-vec00198-002-s010><disband.auflösen><de> Seit zwei Jahren habe ich darüber nachgedacht, langsam, gründlich, geduldig, und ich habe mich nun entschlossen, den Orden, dessen Haupt ich nun einmal bin, aufzulösen.
<G-vec00198-002-s011><disband.auflösen><en> When his attempt at reconciliation broke down because – as he himself stated – the Mensheviks refused to disband their faction and get rid of the Liquidators, Trotsky did not condemn them but “suspended judgement”.
<G-vec00198-002-s011><disband.auflösen><de> Als sein Versöhnungsversuch zusammenbrach, weil – wie er selbst erklärte – die Menschewiki es ablehnten, ihre Fraktion aufzulösen und die Liquidatoren zu entfernen, verurteilte Trotzki sie nicht, sondern „enthielt sich des Urteils“.
<G-vec00198-002-s012><disband.auflösen><en> They have even declared that they will disband their illegal assault troops as soon as the other parties have done the same.
<G-vec00198-002-s012><disband.auflösen><de> Ja, er erklärte sogar, seine illegalen Sturmtruppen aufzulösen, sobald andere Parteien desgleichen getan hätten.
<G-vec00198-002-s013><disband.auflösen><en> Whatever arises, we know it correctly — and things disband.
<G-vec00198-002-s013><disband.auflösen><de> Was immer aufkommt, wir verstehen es korrekt - und die Dinge lösen sich auf.
<G-vec00198-002-s014><disband.auflösen><en> After numerous live performances Chris Maico Schmidt, aka Mike S., Milan Zemanec and Daniel Varga separated in 1994 and disband the group.
<G-vec00198-002-s014><disband.auflösen><de> Nach zahlreichen Liveauftritten trennten sich Chris Maico Schmidt, aka Mike S., Milan Zemanec und Daniel Varga 1994 und lösten die Gruppe auf.
<G-vec00198-002-s017><disband.auflösen><en> The post stated the group will disband so that the members can each pursue their individual goals and dreams and so they can walk their individual paths.
<G-vec00198-002-s017><disband.auflösen><de> Die Post erklärte, dass die Gruppe sich auflösen werde, so dass die Mitglieder ihre individuellen Ziele und Träume verfolgen können und so ihre individuellen Wege gehen können.
<G-vec00198-002-s018><disband.auflösen><en> Nevertheless, the group began to disband.
<G-vec00198-002-s018><disband.auflösen><de> Doch die Gruppe begann sich aufzulösen.
<G-vec00198-002-s019><disband.auflösen><en> After purchasing products the consumer has the possibility to disband the agreement without giving reasons during 14 days.
<G-vec00198-002-s019><disband.auflösen><de> Beim Kauf von Produkten hat der Verbaucher die Möglichkeit die Vereinbarung, ohne Angabe von Gründen, innerhalb von 30 Werktagen aufzulösen.
<G-vec00198-002-s016><disband.kündigen><en> After purchasing a product, the consumer has the possibility to disband the agreement without giving reasons during 14 days (cooling off period).
<G-vec00198-002-s016><disband.kündigen><de> Bei der Lieferung von Produkten: Beim Kauf von Produkten kann der Verbraucher den Vertrag ohne Angabe von Gründen innerhalb von 14 Tagen kündigen.
