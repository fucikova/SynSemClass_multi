<EnglishT-wsj_1571-s4#EnglishT-wsj_1571-s4-t14><ev-w1164f1.v-w5120f2> The plan is talking about applicants admitted , not students who <start_vs>enroll<end_vs>. 
