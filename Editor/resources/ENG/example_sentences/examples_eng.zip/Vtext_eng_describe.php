<G-vec00417-002-s019><describe.berichten><en> Timo Stürmer and Klara Maria Keller, bachelor students at Cologne University, describe the process and the experiences they gained.
<G-vec00417-002-s019><describe.berichten><de> Timo Stürmer und Klara Maria Keller, Bachelorstudenten der TH Köln, berichten über den Prozess und dabei gewonnene Erfahrungen.
<G-vec00417-002-s020><describe.berichten><en> I want to now describe what I heard from a speaker in 1969, which in several weeks will now be 20 years ago.
<G-vec00417-002-s020><describe.berichten><de> Ich möchte nun berichten, was ich 1969 von einem Redner gehört habe und was in ein paar Wochen bereits 20 Jahre her sein wird.
<G-vec00417-002-s021><describe.berichten><en> Given that the number of people who can describe these events first-hand is steadily declining, it is now more important than ever to preserve and pass on their memories and knowledge.
<G-vec00417-002-s021><describe.berichten><de> Umso wichtiger ist es jetzt – da die Menschen, die von den damaligen Ereignissen aus eigener Erinnerung berichten können, immer weniger werden –, diese Erinnerungen und dieses Wissen zu bewahren und weiterzugeben.
<G-vec00417-002-s022><describe.berichten><en> Case Report: We describe a 53-year-old patient with broken-heart syndrome, who developed serious tizanidine withdrawal symptoms after high-dosed long-term treatment within the framework of stress cardiomyopathy.
<G-vec00417-002-s022><describe.berichten><de> Kasuistik: Wir berichten über eine 53-jährige Patientin, die nach langjähriger, hochdosierter Einnahme von Tizanidin ein schweres Absetzsyndrom vor dem Hintergrund einer Stress-Kardiomyopathie entwickelte.
<G-vec00417-002-s023><describe.berichten><en> At the same time, however, they are much more than that because people describe their persecution and their families.
<G-vec00417-002-s023><describe.berichten><de> Sie sind aber zugleich viel mehr, weil die Menschen von ihrer Verfolgung und von ihren Familien berichten.
<G-vec00417-002-s024><describe.berichten><en> We describe two patients with isolated ptosis in whom pathological changes of mitochondria of the levator muscle could be observed.
<G-vec00417-002-s024><describe.berichten><de> Wir berichten über zwei Patientinnen mit einer isolierten Ptosis bei denen pathologische Veränderungen der Mitochondrien im M. levator palpebrae nachgewiesen werden konnten.
<G-vec00417-002-s025><describe.berichten><en> They describe how they fled their home country, what their new life is like, the bureaucratic hurdles they face and the culture shocks they experience.
<G-vec00417-002-s025><describe.berichten><de> Sie berichten über ihre Flucht, über ihren Start in ein neues Leben, über bürokratische Hürden und über Kulturschocks.
<G-vec00417-002-s026><describe.berichten><en> Obert’s question to himself ‘What drives me to this adventure?’ and his reflection on his childhood are so aptly woven into his story that the reader must never ask himself what is most important to the author—to describe this unfamiliar world and its people.
<G-vec00417-002-s026><describe.berichten><de> Oberts Selbstbefragung ‚Was treibt mich zu diesem Abenteuer?‘ und Rückblenden in die eigene Kindheit sind so dezent eingewoben, dass sie nie den Blick auf das verstellen, was ihm das Wichtigste ist: von dieser fremden Welt und ihren Menschen zu berichten.
<G-vec00417-002-s027><describe.berichten><en> This question shows that you know you'll be working in a team environment and might lead to ways in which you can describe how well you have worked with others in the past.
<G-vec00417-002-s027><describe.berichten><de> „Könnten Sie mir etwas zu dem Team erzählen, in dem ich arbeiten werde?“ Diese Frage zeigt, dass du weißt, dass von dir erwartet wird, dass du in Teams arbeiten kannst und bietet dir die Möglichkeit, darüber zu berichten, wie du in der Vergangenheit bereits erfolgreich mit anderen Menschen zusammengearbeitet hast.
<G-vec00417-002-s028><describe.berichten><en> They include a great many Native American myths that describe the event side by side with their own scientific work on the evidence.
<G-vec00417-002-s028><describe.berichten><de> Sie erwähnen eine Vielzahl von uramerikanischen Mythen, die von diesem Geschehen parallel zu ihrer eigenen wissenschaftlichen Arbeit berichten.
<G-vec00417-002-s029><describe.berichten><en> So if you know that you are allowed to unhesitatingly accept all Gospels as being conveyed by My spirit, as long as you merely assign different periods of time to the process of the transfer, then the Gospel of John was the first one given by Me, because John more or less witnessed everything and was therefore able to describe it in greatest detail.
<G-vec00417-002-s029><describe.berichten><de> Und wenn ihr nun wisset, daß ihr bedenkenlos auch alle Evangelien als von Meinem Geist vermittelt annehmen dürfet, wenn ihr nur den Vorgang der Vermittlung in verschiedene Zeiträume verlegt, so ist wohl das Evangelium des Johannes das von Mir als erstes gegebene, weil Johannes gleichsam alles miterlebt hat und darüber auch am ausführlichsten berichten konnte.
<G-vec00417-002-s030><describe.berichten><en> As you walk along the beach at the foot of the cliff, they will describe how Møns Klint came about and tell you all about the unique flora and fauna in the area.
<G-vec00417-002-s030><describe.berichten><de> Auf dem Ausflug am Klippenstrand erzählen sie davon, wie Møns Klint entstanden ist, und berichten von der einzigartigen Flora und Fauna der Umgebung.
<G-vec00417-002-s031><describe.berichten><en> In the paper, the authors describe their observations of the so-called Bose-Einstein condensation, an extreme state close to absolute zero, in which matter forms a macroscopic wave.
<G-vec00417-002-s031><describe.berichten><de> Die Autorinnen und Autoren berichten darin über die Erzeugung und Beobachtung der sogenannten Bose-Einstein-Kondensation, einem extremen Zustand nahe dem Temperatur-Nullpunkt in dem Materie eine Welle formt.
<G-vec00417-002-s032><describe.berichten><en> Other companies that report or describe similarly titled supplemental financial measures may calculate them differently.
<G-vec00417-002-s032><describe.berichten><de> Andere Unternehmen, die Finanzkennzahlen mit einer ähnlichen Bezeichnung darstellen oder berichten, können diese anders berechnen.
<G-vec00417-002-s033><describe.berichten><en> Four performers describe their struggle to live feminine lives their own way.
<G-vec00417-002-s033><describe.berichten><de> Vier Darsteller*innen berichten von ihrem Kampf, Weiblichkeit auf ihre individuelle Weise leben zu können.
<G-vec00417-002-s034><describe.berichten><en> Look out for the information signs along the route that describe life in the age of iron.
<G-vec00417-002-s034><describe.berichten><de> Am Weg stehen Schilder mit Illustrationen, die aus der Zeit des Eisens berichten.
<G-vec00417-002-s036><describe.berichten><en> Meet our people who describe what personal and professional career they have done and why they ha...
<G-vec00417-002-s036><describe.berichten><de> Lernen Sie einige unserer Mitarbeiter kennen: Sie berichten über ihre persönliche und berufliche...
<G-vec00417-002-s094><describe.beschreiben><en> In an album cover design contest, you describe what kind of art you’re interested in and designers from all over the world create designs based on what you’ve described.
<G-vec00417-002-s094><describe.beschreiben><de> Bei einem Designwettbewerb für ein Albumcover beschreibst du, welche Art Kunst dich interessiert, und Designer aus der ganzen Welt erstellen anhand deiner Beschreibung Designs.
<G-vec00417-002-s095><describe.beschreiben><en> You often speak so cruelly objectively when you describe human beings and their qualities.
<G-vec00417-002-s095><describe.beschreiben><de> Du sprichst oft so grausam objektiv, wenn du Menschen und ihre Eigenschaften beschreibst.
<G-vec00417-002-s096><describe.beschreiben><en> Both options are possible: You either propose what you want to learn, or describe what you could teach.
<G-vec00417-002-s096><describe.beschreiben><de> Beides ist möglich: Du schlägst vor, was du gern lernen willst, oder beschreibst, was du unterrichten könntest.
<G-vec00417-002-s097><describe.beschreiben><en> You describe yourself as a feminist and a Muslim.
<G-vec00417-002-s097><describe.beschreiben><de> Du beschreibst Dich als Feministin und Muslima.
<G-vec00417-002-s098><describe.beschreiben><en> But no matter, our Damian is lonely top and as you describe him otherwise, I think the nail on the head.
<G-vec00417-002-s098><describe.beschreiben><de> Nun aber nichts destotrotz, unser Damian ist einsame Spitze und wie Du ihn ansonsten beschreibst, trifft glaube ich auch den Nagel auf den Kopf.
<G-vec00417-002-s099><describe.beschreiben><en> Simply pull out your smartphone and describe the defect or damage in our app.
<G-vec00417-002-s099><describe.beschreiben><de> Bei Schadensfällen zückst Du einfach Dein Smartphone und beschreibst den Mangel oder Schaden in unserer eigenen App.
<G-vec00417-002-s100><describe.beschreiben><en> For example, you can use the metaphor to describe the experience of telling your mother a secret.
<G-vec00417-002-s100><describe.beschreiben><de> Zum Beispiel könntest du eine Metapher verwenden, wenn du das Erlebnis beschreibst, als du deiner Mutter erzähltest, dass du schwul bist.
<G-vec00417-002-s101><describe.beschreiben><en> The way you describe it makes it sound like it would be fun, though.” This lets the other person know you really were listening, rather than mentally checking your shopping list or something else.
<G-vec00417-002-s101><describe.beschreiben><de> Aber so wie du es beschreibst, scheint es eine Menge Spaß zu machen.“ Das zeigt der Person, dass du wirklich zugehört und währenddessen nicht nur im Kopf deine Einkaufsliste oder sonst was durchgegangen bist.
<G-vec00417-002-s102><describe.beschreiben><en> What you describe does not correspond to this process; it seems to be an endeavour to build the gods in yourself in the Vedic sense and the Vedic manner.
<G-vec00417-002-s102><describe.beschreiben><de> Was du beschreibst, stimmt mit diesem Vorgang nicht überein; es scheint sich um ein Bemühen zu handeln, die Götter im vedischen Sinn und auf die vedische Weise in dir zu formen.
<G-vec00417-002-s103><describe.beschreiben><en> How do you describe yourself?» – «I am the one with the commercial ear for the right hit, who knows how you have to market yourself and – do you still need something negative?» – «Needn’t be the case.» – «And endless will to arrive at the top.
<G-vec00417-002-s103><describe.beschreiben><de> Wie beschreibst du dich?» – «Ich bin der mit dem kommerziellen Gehör für den richtigen Hit, der weiß, wie man sich vermarkten muss und – brauchst du noch was Negatives?» – «Muss nicht sein.» – «Und endlosem Biss, an der Spitze anzukommen.
<G-vec00417-002-s104><describe.beschreiben><en> The whole book touches on the same Jewish fable of the dream about a buried treasure that you also describe in your fourth book of the Master as the search for the true I Am.
<G-vec00417-002-s104><describe.beschreiben><de> Das ganze Buch beruht auf der gleichen jüdischen Lehrgeschichte von dem Traum über einen vergrabenen Schatz, mit der du in deinem vierten Buch der Meister, die Suche nach dem Wahren ICHSELBST beschreibst.
<G-vec00417-002-s105><describe.beschreiben><en> Of course one can surround it and pass through it, but at the same time you also describe here your idea of time that leads from life to death, and from death to life.
<G-vec00417-002-s105><describe.beschreiben><de> Sicherlich kann man es umkreisen und durchschreiten, aber zur gleichen Zeit beschreibst du auch hier deine Vorstellung von Zeit, die vom Leben zum Tod führt und nach dem Tod wieder zum Leben.
<G-vec00417-002-s270><describe.erklären><en> Therefore, current solutions produce community models that supply only a part of community stakeholders with information that can hardly describe community success and failure.
<G-vec00417-002-s270><describe.erklären><de> Daher führen bestehende Lösungen zu Gemeinschaftsmodellen, die nur einen Ausschnitt der Interessengruppen mit notwendigen Informationen versorgen und kaum hinreichend sind, um Erfolg und Scheitern von Gemeinschaften zu erklären.
<G-vec00417-002-s271><describe.erklären><en> In the sutra ‚Tune of Brahma’ one finds ten points, which describe the karmic advantages that such actions bear.
<G-vec00417-002-s271><describe.erklären><de> Im Sutra „Tune of Brahma“ finden sich zehn Punkte, die erklären, welche karmischen Vorteile eine solche Handlung mit sich bringt.
<G-vec00417-002-s272><describe.erklären><en> In this video some suppliers of STEMMER IMAGING describe what they see as the added value that STEMMER IMAGING as Europe's largest imaging technology provider can give to its customers.
<G-vec00417-002-s272><describe.erklären><de> In diesem Video erklären einige Lieferanten von STEMMER IMAGING, welchen zusätzlichen Nutzen Kunden von STEMMER IMAGING als dem größten Anbieter von Bildverarbeitungstechnologien in Europa erwarten können.
<G-vec00417-002-s273><describe.erklären><en> We describe which personal data we process, how we meet privacy principles and data subject rights.
<G-vec00417-002-s273><describe.erklären><de> Wir erklären, welche personenbezogenen Daten wir verarbeiten und wie wir die Datenschutzgrundsätze und die Rechte des Betroffenen einhalten gemäß der gültigen EU-DSGVO.
<G-vec00417-002-s274><describe.erklären><en> Within our Cookie Policy we describe what cookies are and how they are used in our website.
<G-vec00417-002-s274><describe.erklären><de> n unseren Cookies-Richtlinien erklären wir was Cookies sind und wie sie auf unserer Webseite benutzt werden.
<G-vec00417-002-s275><describe.erklären><en> It’s difficult to describe but staying in Indonesia feels like a second home to us.
<G-vec00417-002-s275><describe.erklären><de> Es ist schwer zu erklären, wie sehr uns Indonesien zur zweiten Heimat geworden ist.
<G-vec00417-002-s276><describe.erklären><en> For instance, if a text is intended to describe the operation of technical equipment, it must be logically structured, use precise wording and correctly convey the technical content.
<G-vec00417-002-s276><describe.erklären><de> Soll zum Beispiel ein Text die Bedienung technischer Geräte erklären, kommt es auf eine logische Gliederung, eine präzise Ausdrucksweise und die korrekte Wiedergabe technischer Inhalte an.
<G-vec00417-002-s277><describe.erklären><en> Hitler confirmed this and asked me to describe the origin and treatment of this ear complaint.
<G-vec00417-002-s277><describe.erklären><de> Hitler bejahte und ließ sich dann von mir die Entstehung und Behandlung dieses Ohrleidens erklären.
<G-vec00417-002-s278><describe.erklären><en> The purpose of this document is to describe how to setup a working custom button pointing to the Radio Monitor website.
<G-vec00417-002-s278><describe.erklären><de> Dieses Dokument soll erklären, wie man selbstständig einen Button erstellt, mit dem man aus MusicMaster auf Radio Monitor zugreifen kann.
<G-vec00417-002-s279><describe.erklären><en> We use personal data for the purposes described in the section “For which purposes and on which legal basis do we use your personal data?” above, as well as to provide you with information you request, process online job applications, and for other purposes which we would describe to you at the point where it is collected.
<G-vec00417-002-s279><describe.erklären><de> Wir nutzen die personenbezogenen Daten zu den Zwecken, die im Abschnitt „Zu welchem Zweck und auf welcher Rechtsgrundlage nutzen wir Ihre personenbezogenen Daten?” zuvor dargestellt wurden sowie zur Bereitstellung der von Ihnen angeforderten Informationen, zur Bearbeitung von Online-Stellenbewerbungen und für sonstige Zwecke, die wir Ihnen im Moment der Datenerhebung erklären.
<G-vec00417-002-s280><describe.erklären><en> Let me describe the basics of EVM with a very simple example.
<G-vec00417-002-s280><describe.erklären><de> Lassen Sie mich die Basics von EVM mittels eines einfachen Beispiels erklären.
<G-vec00417-002-s281><describe.erklären><en> A relationship that is hard to describe.
<G-vec00417-002-s281><describe.erklären><de> Eine Beziehung, die nur schwer zu erklären ist.
<G-vec00417-002-s282><describe.erklären><en> Your kid will be more aware and more sensitive for the big worlds’ issues, sometimes very difficult to describe.
<G-vec00417-002-s282><describe.erklären><de> Dein Kind wird sensibler für die großen Geschehnisse auf der Welt sein, jene, die so schwierig zu erklären sind.
<G-vec00417-002-s283><describe.erläutern><en> Rather than attempting to describe all the different hardware configurations which are supported for Mips, this section contains general information and pointers to where additional information can be found.
<G-vec00417-002-s283><describe.erläutern><de> Dieser Abschnitt versucht nicht, all die verschiedenen Hardware-Konfigurationen zu erläutern, die auf der Mips-Architektur unterstützt werden, sondern bietet vielmehr allgemeine Informationen und Verweise, wo zusätzliche Informationen zu finden sind.
<G-vec00417-002-s284><describe.erläutern><en> Accordingly, Cellap Laboratoire has developed this Statement to describe how and what type of data will be collected from users of the World.cellcosmet-cellmen Website and the purposes for which Cellap Laboratoire may collect, share or disclose the data.
<G-vec00417-002-s284><describe.erläutern><de> In diesem Sinne hat Cellap Laboratoire diese Datenschutzerklärung erarbeitet, um zu erläutern, welche Art von Daten wir von den Nutzern der Cellcosmet-Cellmen-Website erheben und wie wir dabei vorgehen sowie zu welchen Zwecken wir sie erheben, teilen oder weitergeben können.
<G-vec00417-002-s285><describe.erläutern><en> In this document, we meet our obligation to describe the information that we collect during your visit to our website and how we use this data.
<G-vec00417-002-s285><describe.erläutern><de> Nachfolgend werden wir Ihnen entsprechend unserer Pflicht erläutern, welche Informationen wir während Ihres Besuchs auf unserer Internetseite erfassen und wie diese genutzt werden.
<G-vec00417-002-s286><describe.erläutern><en> This page will describe management of our web site as regards processing the personal data of users that visit us.
<G-vec00417-002-s286><describe.erläutern><de> Auf dieser Seite erläutern wir unsere Modalitäten zur Verarbeitung personenbezogener Daten von allen Benutzern, die diese Webseite aufsuchen.
<G-vec00417-002-s287><describe.erläutern><en> In our seminar “The ECJ decision concerning articles and its consequences for economic operators” will describe which obligations arise from the new legal situation for various members of the value creation chain.
<G-vec00417-002-s287><describe.erläutern><de> Welche Verpflichtungen sich aus der neuen Rechtslage für die verschiedenen Akteure der Wertschöpfungskette ergeben, erläutern wir Ihnen in unserem Seminar „Das EuGH-Urteil zu Erzeugnissen und die Konsequenzen für Wirtschaftsakteure“.
<G-vec00417-002-s288><describe.erläutern><en> Because some of these services cover very complex topics, we hope you will understand that we are unable to describe on our website the finest details of everything that we do.
<G-vec00417-002-s288><describe.erläutern><de> Da es sich bei diesen Dienstleistungen um teilweise sehr komplexe Themenbereiche handelt, bitten wir Sie um Verständnis dafür, dass wir auf unseren Webseiten nicht sämtliche Angebote bis in die feinsten Details erläutern können.
<G-vec00417-002-s289><describe.erläutern><en> Naturally, we are happy to advise you and to describe each location in detail.
<G-vec00417-002-s289><describe.erläutern><de> Natürlich beraten wir Sie gerne und erläutern Ihnen die Details jeder Location.
<G-vec00417-002-s290><describe.erläutern><en> Remains difficult to describe this the owner of the patient impressive.
<G-vec00417-002-s290><describe.erläutern><de> Schwierig bleibt, dies dem Besitzer des Patienten eindrücklich zu erläutern.
<G-vec00417-002-s291><describe.erläutern><en> Many other references, including Apache's own documentation, describe the process.
<G-vec00417-002-s291><describe.erläutern><de> Viele andere Bücher, darunter Apaches eigene Dokumentation, erläutern diese Aufgabe.
<G-vec00417-002-s292><describe.erläutern><en> The fact that equations can describe things would not want to deny, which extract themselves from the opinion, because the evolution did not prepare our Hirne seize subatomic or spaciously cosmic circumstances intuitively the critics of stringer physics.
<G-vec00417-002-s292><describe.erläutern><de> Daß Gleichungen Dinge erläutern können, die sich der Anschauung entziehen, weil die Evolution unsere Hirne nicht dafür gerüstet hat, subatomare oder großräumig kosmische Sachverhalte intuitiv zu erfassen, würden die Kritiker der Stringphysik nicht bestreiten wollen.
<G-vec00417-002-s293><describe.erläutern><en> The files named “custom_*” describe the rules and how to enable them.
<G-vec00417-002-s293><describe.erläutern><de> Die Dateien mit dem Namen custom_* erläutern die Regeln und wie sie aktiviert werden.
<G-vec00417-002-s294><describe.erläutern><en> With reference to Article 15, please indicate the extent to which any particular conditions are attached to labour market access for applicants, and describe such restrictions in detail.
<G-vec00417-002-s294><describe.erläutern><de> Bitte geben Sie unter Bezugnahme auf Artikel 15 an, inwieweit an den Arbeitsmarktzugang für Antragsteller bestimmte Bedingungen geknüpft sind, und erläutern Sie solche Beschränkungen im Einzelnen.
<G-vec00417-002-s295><describe.erläutern><en> Could you please describe some of the similarities and differences which you have encountered in your work?
<G-vec00417-002-s295><describe.erläutern><de> Bitte erläutern Sie einige Ähnlichkeiten und Unterschiede, auf die Sie bei Ihrer Arbeit gestoßen sind.
<G-vec00417-002-s296><describe.erläutern><en> We show and describe the essential features for dressing correctly and for the most diverse occasions.
<G-vec00417-002-s296><describe.erläutern><de> Wir zeigen und erläutern die essentielle Ausstattung, um bei verschiedensten Anlässen richtig gekleidet zu sein.
<G-vec00417-002-s297><describe.erläutern><en> ‘Short Presentation’ will be a brief presentation whereby students will describe the topic they have chosen for their research paper, and link their choice to themes in the course that they have found interesting.
<G-vec00417-002-s297><describe.erläutern><de> Für die “kurze Präsentation” werden die Studierenden das von ihnen für die Hausarbeit gewählte Thema erläutern und mit Themen des Kurses in Verbindung bringen, die für sie von Interesse sind.
<G-vec00417-002-s298><describe.erläutern><en> In this article we would like to explain the component parts which make up bookingkit, and describe the most important concepts used in our software.
<G-vec00417-002-s298><describe.erläutern><de> In diesem Artikel möchten wir dir erklären, mit welchen Komponenten bookingkit aufgebaut ist und dir einmal die wichtigsten Begriffe rund um unsere Software erläutern.
<G-vec00417-002-s299><describe.erläutern><en> Accordingly, elipsLife has developed this Notice to describe how and what type of data will be collected from users of the elipsLife Website and the purposes for which elipsLife may collect, share or disclose the data.
<G-vec00417-002-s299><describe.erläutern><de> Aus diesem Grund hat elipsLife diese Erklärung verfasst, um zu erläutern, wie und welche Arten von Daten wir von Nutzern der elipsLife-Website sammeln und für welche Zwecke elipsLife die Daten sammeln, weitergeben oder offenlegen darf.
<G-vec00417-002-s300><describe.erläutern><en> After concluding the process the competent authority must describe how it took account of the environmental report and the comments and opinions submitted when taking its decision, and why a specific plan has been chosen after weighing it up against the other assessed alternatives.
<G-vec00417-002-s300><describe.erläutern><de> Nach Abschluss des Verfahrens muss die zuständige Behörde erläutern, wie sie den Umweltbericht und die abgegebenen Stellungnahmen bei ihrer Entscheidung berücksichtigt hat und weshalb der konkrete Plan bei einer Abwägung mit den geprüften Alternativen gewählt worden ist.
<G-vec00417-002-s301><describe.erläutern><en> We really want to describe the true extent of the disease for our peers, the surgeons, the oncologists, the pathologists.
<G-vec00417-002-s301><describe.erläutern><de> Wir möchten unseren Kollegen – den Chirurgen, den Onkologen und den Pathologen – wirklich die wahren Ausmaße der Krankheit erläutern.
<G-vec00417-002-s316><describe.schildern><en> A number of essays describe the founding and the history of the biennial, which is closely associated with the fate of Brazilian Modernism.
<G-vec00417-002-s316><describe.schildern><de> Eigene Essays schildern die Gründung und die Geschichte der Biennale, die eng mit dem Schicksal der brasilianischen Moderne verbunden ist.
<G-vec00417-002-s317><describe.schildern><en> Regardless of the futile efforts of Jean-Claude Pressac to prove this thesis of mass extermination by documents, it is up to this day based exclusively on statements of alleged eye witnesses, and Pressac himself had to make use of those when he tried to describe the first alleged homicidal gassing in crematorium II of Birkenau.
<G-vec00417-002-s317><describe.schildern><de> Trotz der vergeblichen Bemühungen Jean-Claude Pressacs, diese These dokumentarisch zu beweisen, beruht sie bis zum heutigen Tage einzig und allein auf den Aussagen vorgeblicher Augenzeugen, und Pressac selbst musste notgedrungen auf eine solche zurückgreifen, als er die erste angebliche Menschenvergasung im Krematorium II von Birkenau zu schildern versuchte.
<G-vec00417-002-s318><describe.schildern><en> No language suffices to describe the splendour of the males of some tropical species.
<G-vec00417-002-s318><describe.schildern><de> Es ist unmöglich den Glanz der Männchen einiger tropischer Species mit Worten zu schildern.
<G-vec00417-002-s319><describe.schildern><en> The highlights Besides my personal highlights which I will describe below, it was quite diversified.
<G-vec00417-002-s319><describe.schildern><de> Neben meinen persönlichen Highlights, die ich unten schildern werde, war es auch sonst sehr abwechslungsreich.
<G-vec00417-002-s320><describe.schildern><en> If we try to describe them when we have reached the age of thirty-seven, we discover that we are in touch with them spiritually in the awakened consciousness of sleep.
<G-vec00417-002-s320><describe.schildern><de> Versucht man sie zu schildern, wenn man 37 Jahre alt geworden ist, dann hat man von ihnen folgendes erfahren: Sie stehen da in der Geisteswelt.
<G-vec00417-002-s321><describe.schildern><en> Rare film footage from Soviet war correspondents as well as 100 interviews with eyewitnesses who describe their most harrowing experiences above and below ground for the first time serve as the basis for the well-cast screenplay.
<G-vec00417-002-s321><describe.schildern><de> Als Grundlage des Drehbuchs und der prominent besetzten Spielszenen dienten unter anderem rund 100 Interviews mit Zeitzeugen, die zumeist ihre erschütternden Erlebnisse über und unter der Erde zum ersten Mal öffentlich schildern sowie seltene dokumentarische Einblicke aus sowjetischen Kriegsberichter-Kameras.
<G-vec00417-002-s322><describe.schildern><en> Please describe your concern for us.
<G-vec00417-002-s322><describe.schildern><de> Bitte schildern Sie uns Ihr Anliegen.
<G-vec00417-002-s323><describe.schildern><en> A boat builder, a fisherman, an award-winning chef, a villa owner, water skiers from the Pörtschach water sports club and many others describe their fascination for the Wörthersee in varying ways and from very different perspectives.
<G-vec00417-002-s323><describe.schildern><de> Ein Bootsbauer, ein Fischer, ein Haubenkoch, eine Villenbesitzerin, die Wasserskiläufer des Wassersport-Clubs Pörtschach und viele andere schildern abwechslungsreich und aus sehr unterschiedlicher Perspektive ihre Faszination für den Wörthersee.
<G-vec00417-002-s324><describe.schildern><en> In both cases you are advised to contact an eye care professional urgently and describe the symptoms.
<G-vec00417-002-s324><describe.schildern><de> In beiden Fällen lautet der dringende Rat, sich mit einem Augenarzt in Verbindung zu setzen und die Probleme zu schildern.
<G-vec00417-002-s325><describe.schildern><en> On and on mumbled Dr. Glaub, and gradually she began to build up an idea of the situation which he was trying to describe.
<G-vec00417-002-s325><describe.schildern><de> Dr. Glaub plapperte immer weiter, und allmählich begann sie eine Vorstellung von der Lage zu entwickeln, die er zu schildern versuchte.
<G-vec00417-002-s326><describe.schildern><en> In the application, you must describe the incident and the health consequences, and attach physician's statements.
<G-vec00417-002-s326><describe.schildern><de> In dem Antrag musst du das Tatgeschehen und die gesundheitlichen Folgen schildern und du musst ärztliche Atteste beilegen.
<G-vec00417-002-s327><describe.schildern><en> Describe your request here Your consultant
<G-vec00417-002-s327><describe.schildern><de> Schildern Sie uns Ihr Anliegen hier.
<G-vec00417-002-s328><describe.schildern><en> Please describe your request briefly, if possible.
<G-vec00417-002-s328><describe.schildern><de> Schildern Sie uns darin bitte, wenn möglich, kurz Ihr Anliegen.
<G-vec00417-002-s329><describe.schildern><en> It can only remain an attempt, an attempt resembling the kind that would hope to describe the Beauty, richness, and sublimity of the waves of the sea.
<G-vec00417-002-s329><describe.schildern><de> Immer nur kann es ein Versuch bleiben, ein Versuch, der dem gleicht, Schönheit, Reichtum und Erhabenheit der Wellen des Meeres schildern zu wollen.
<G-vec00417-002-s330><describe.schildern><en> Please describe your request by e-mail to Beratung-Barrierefrei@zuv.fu-berlin.de and, if possible, include a callback number.
<G-vec00417-002-s330><describe.schildern><de> Bitte schildern Sie Ihr Anliegen per E-Mail an Beratung-Barrierefrei@zuv.fu-berlin.de und geben möglichst auch eine Rückrufnummer an.
<G-vec00417-002-s332><describe.schildern><en> The more precisely you describe your concern, the better and faster we can help you.
<G-vec00417-002-s332><describe.schildern><de> Je präziser Sie Ihr Anliegen schildern, desto besser und schneller können wir Ihnen helfen.
<G-vec00417-002-s333><describe.schildern><en> Bernhard Hetzenauer gives one of the survivors the opportunity to describe the harrowing events, contrasting the account with tranquil, cleverly arranged black-and-white shots of the village, its inhabitants, and the surrounding landscape.
<G-vec00417-002-s333><describe.schildern><de> Bernhard Hetzenauer lässt einen Überlebenden die erschütternden Ereignisse schildern und zeigt dazu ruhige, klug arrangierte Schwarz-Weiß-Aufnahmen des Dorfs, seiner BewohnerInnen und der umliegenden Landschaft.
<G-vec00417-002-s334><describe.schildern><en> A moderator motivated the testers to describe their impressions.
<G-vec00417-002-s334><describe.schildern><de> Ein Moderator motivierte die Tester, ihre Eindrücke zu schildern.
