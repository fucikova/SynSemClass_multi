<G-vec00418-001-s019><boast.angeben><en> If by my cooperation with the Spirit of God I remain faithful to the end, I can boast (a little) about how I was able to stay the course and finish the race.
<G-vec00418-001-s019><boast.angeben><de> Wenn es allein durch meine gute Beziehung zum Heiligen Geist Gottes möglich wäre, bis zum Ende treu zu bleiben, dann kann ich darüber angeben, wie ich es geschafft habe auf Kurs zu bleiben und am Glauben festzuhalten.
<G-vec00418-001-s020><boast.angeben><en> We don't like to boast, but when it comes to places to visit, Scotland has some mighty fine options indeed.
<G-vec00418-001-s020><boast.angeben><de> Wir wollen ja nicht angeben, aber wenn es um Orte zum Besuchen geht, hat Schottland einiges zu bieten.
<G-vec00418-001-s021><boast.angeben><en> We are not to boast about ourselves; if we want to boast, then we are to proclaim the glories of God.
<G-vec00418-001-s021><boast.angeben><de> Wir sollen nicht angeben; wenn wir angeben wollen, denn über die Herrlichkeit von Gott.
<G-vec00418-001-s023><boast.angeben><en> """So, no man may boast before Me."
<G-vec00418-001-s023><boast.angeben><de> """Also, kein Mensch kann vor Mir angeben."
<G-vec00418-001-s195><boast.sich_rühmen><en> "How many politicians, how many businessmen swear that they create jobs and then boast of having reduced their payroll!», says Viviane Forrester in his denunciation of ""The economic horror"", published by Polity."
<G-vec00418-001-s195><boast.sich_rühmen><de> "Wie viele Politiker und Unternehmer schwören, dass die Schaffung von Arbeitsplätzen und dann mit ihren reduzierter Dienstplan rühmen!», Viviane Forrester sagt in ihrer Beschwerde von ""Der Terror der Ökonomie"", editiert von Goldmann Verlag."
<G-vec00418-001-s196><boast.sich_rühmen><en> With an area of over 80,000 square kilometres divided into nine states and a population of 8.5 million, Austria can boast of being one of the richest countries not only in Europe but also in the rest of the world.
<G-vec00418-001-s196><boast.sich_rühmen><de> Mit einer Gesamtfläche von mehr als 80.000 Quadratkilometern, unterteilt in neun Bundesländer und mit einer Bevölkerung von 8,5 Millionen Menschen, kann sich Österreich nicht nur als eines der reichsten Länder Europas, sondern sogar der Erde rühmen.
<G-vec00418-001-s197><boast.sich_rühmen><en> Modern developed cities can not boast the absence of human parasites.
<G-vec00418-001-s197><boast.sich_rühmen><de> Moderne entwickelte Städte können sich nicht mit dem Fehlen menschlicher Parasiten rühmen.
<G-vec00418-001-s198><boast.sich_rühmen><en> Every Jewish mother wants to boast of “my son, the doctor” or “my son, the lawyer”.
<G-vec00418-001-s198><boast.sich_rühmen><de> Jede jüdische Mutter möchte sich gerne mit „mein Sohn, der Doktor“ oder „Mein Sohn, der Anwalt“ rühmen.
<G-vec00418-001-s199><boast.sich_rühmen><en> You might find that there are just a few internet casinos that are able to actually boast of having an absolute combination of superb quality software, methodical protection, wide variety of games, outstanding customer support and most significantly, a long and reputable history that is required to be considered as a first-rate online casino.
<G-vec00418-001-s199><boast.sich_rühmen><de> Sie können feststellen, dass es nur ein paar Internet-Kasinos, die in der Lage sind, tatsächlich mit der absoluten Kombination von hervorragender Qualität Software, methodische Schutz, große Auswahl an Spielen rühmen, einen hervorragenden Support und was am wichtigsten ist, eine lange und angesehene Geschichte, die erforderlich ist als ein erstklassiges Online-Casino in Betracht gezogen werden.
<G-vec00418-001-s200><boast.sich_rühmen><en> Parts of the area consist of a nature reserve with low mountain nature, which can boast of Åseles highest mountain, 668 meters above sea level. The view from the top is breathtaking.
<G-vec00418-001-s200><boast.sich_rühmen><de> Teile des Gebiets bestehen aus einem Naturschutzgebiet mit niedriger Gebirgsnatur, das mit dem höchsten Berg von Åseles (668 m) über dem Meeresspiegel rühmen kann und die Aussicht von oben atemberaubend ist.
<G-vec00418-001-s204><boast.prahlen><en> After the young woman caught in the street has sucked his cock the boy strategically placed the camera so he can record with a hidden camera sex that we boast so much that you will see in this video.
<G-vec00418-001-s204><boast.prahlen><de> Nachdem die junge Frau auf der Straße seinen Schwanz gelutscht hat, hat der Junge die Kamera strategisch platziert, damit er mit einer versteckten Kamera Sex aufnehmen kann, den wir so prahlen, dass Sie in diesem Video sehen werden.
<G-vec00418-001-s205><boast.prahlen><en> In the afternoon coffee becomes a tea room and can boast well 100 types of tea and herbal teas from different countries of the world that can be accompanied by sweets and handicrafts.
<G-vec00418-001-s205><boast.prahlen><de> Am Nachmittag wird Kaffee zum Tea Room und kann prahlen Sie gut 100 Arten von Tee und Kräutertees aus verschiedenen Ländern der Welt, die von Süßigkeiten und Kunsthandwerk begleitet werden können.
<G-vec00418-001-s206><boast.prahlen><en> Me Same I will defend them in the time of the death as My glory and even if the sins of the souls were black as the night, when a sinner turns to My Mercy, the greatest glory makes Me and is a boast of My Passion.
<G-vec00418-001-s206><boast.prahlen><de> Ich Selbst werde sie in der Stunde des toten, wie Meinen Ruhmes verteidigen und selbst wenn die Sünden der Seelen so schwarz wie die Nacht wären, wenn ein Sünder sich an Meine Barmherzigkeit wendet, macht es Mir den größten Ruhm und es ist ein Prahlen von Meiner Leidenschaft.
<G-vec00418-001-s207><boast.prahlen><en> Not a few countries can also boast of their own achievements in the field of folding paper figures of the whole leaf.
<G-vec00418-001-s207><boast.prahlen><de> Nicht wenige Länder können auch ihre eigenen Errungenschaften prahlen im Bereich des Papierfaltens Zahlen des ganzen Blattes.
<G-vec00418-001-s208><boast.prahlen><en> Engine makers like Infiniti have responded to this by adding a non-stick coating such as Teflon to the surface of the head gasket.Infiniti head gasket may have added endurance to the automobile line’s performance, but without a good suspension system, Infiniti could not boast of its luxurious cars.
<G-vec00418-001-s208><boast.prahlen><de> Engine Entscheidungsträger wie Infiniti müssen diese durch Zugabe einer Antihaftbeschichtung Teflon wie an der Oberfläche des Kopfes gasket.Infiniti Zylinderkopfdichtung reagiert zugesetzt Ausdauer, um die Automobil-line die Leistung haben, aber ohne eine gute Federung, Infiniti konnte nicht von seinem luxuriösen Autos prahlen.
<G-vec00418-001-s209><boast.prahlen><en> In video mode, the webcam can boast a resolution of 1280 x 720 dpi.
<G-vec00418-001-s209><boast.prahlen><de> Im Modus Video-Web-Kamera kann prahlen einer Auflösung von 1280 x 720 dpi.
<G-vec00418-001-s210><boast.prahlen><en> At BettingWays, we boast about having extremely fast deposits and withdrawals as these are essential for all players who require to withdraw their winnings to their bank accounts as soon as possible.
<G-vec00418-001-s210><boast.prahlen><de> Bei BettingWays, wir prahlen mit extrem schnellen Einzahlungen und Auszahlungen wie diese sind essentiell für alle Spieler, die eine Aberkennung der Gewinne auf Ihren Konten so bald wie möglich.
<G-vec00418-001-s211><boast.prahlen><en> Personalize the word LOVE with your four favourite photos, and boast of your beautiful love story with your second half.
<G-vec00418-001-s211><boast.prahlen><de> Personifizieren Sie das Wort LIEBE mit Ihren vier Lieblingsfotos und prahlen Sie von Ihrer schönen Liebesgeschichte mit Ihrer bessere Hälfte.
<G-vec00418-001-s212><boast.prahlen><en> It is not the only image that stood out in the manifestations of extravagance and excessive spending in the Arab and Muslim world, the desire to cry mixed with another laugh, when I see a rich Arab possess his car studded with diamonds, or I see some wealthy Arabs boast about to sit on the largest (Dining table of some sort) in the world.
<G-vec00418-001-s212><boast.prahlen><de> Es ist nicht das einzige Bild, das in den Manifestationen der Extravaganz und übermäßige Ausgaben in der arabischen und muslimischen Welt stand der Wunsch, mit einem weiteren Lachen gemischt weinen, wenn ich sehe, eine reiche arabische besitzen sein Auto mit Diamanten besetzt, oder sehe ich einige wohlhabende Araber prahlen, um auf dem größten sitzen (Esstisch irgendeiner Art) in der Welt.
<G-vec00418-001-s213><boast.prahlen><en> Jewish leaders boast that given enough MTV even radical Moslem youths can be turned into docile pop-addicts like western youths.
<G-vec00418-001-s213><boast.prahlen><de> Jüdische Führer prahlen heute, selbst radikale moslemische Jugendliche könnten mit genügend MTV genau so in manipulierbare Popmusik-Süchtige verwandelt werden wie junge Menschen in den westlichen Ländern.
<G-vec00418-001-s214><boast.prahlen><en> "Other examples of not intending to misrepresent the truth appear in a series of cases in the Vinita-vatthu where bhikkhus are absolved of an offense under this rule because they ""did not intend to boast."""
<G-vec00418-001-s214><boast.prahlen><de> "Ein anderes Beispiel von mit absehen die Wahrheit fehldarzustellen, scheint in einer Reihe von Fällen im Vinita-Vatthu auf, wo Bhikkhus einem Vergehen, unter dieser Regel, entbunden werden, weil diese ""nicht absahen zu prahlen""."
<G-vec00418-001-s215><boast.prahlen><en> In addition to the standard non-offenses, the Vibhaṅga lists two that we have already covered in connection with perception and intention: There is no offense if one makes a claim out of a mistaken and exaggerated understanding of one's attainment; and no offense if one is not intending to boast, i.e., one makes a claim that may sound like an implicit reference to a superior human state but is not intended as such.
<G-vec00418-001-s215><boast.prahlen><de> In Ergänzung zu den Standardnichtvergehen, führt das Vibhaṅga zwei an, die bereits in Verbindung mit Vorstellung und Absicht abgedeckt sind: Da ist keine Vergehen, wenn einer einen Anspruch aus einem fehlerhaften und übertreibendem Verständnis der eigenen Errungenschaften macht, und da ist kein Vergehen, wenn einer nicht absieht, zu Prahlen, d.h. man macht einen Anspruch, der wie eine einschließende Bezugnahme, zu einem erhabenen menschlichen Zustand, erscheinen mag, aber nicht als solcher beabsichtigt wird.
<G-vec00418-001-s216><boast.prahlen><en> "Tuanhe Labour Camp tried every trick to boast that what they were doing exemplified ""civilized management."""
<G-vec00418-001-s216><boast.prahlen><de> Das Tuanhe Arbeitslager versuchte jeden Trick, um damit zu prahlen, dass was sie machen „zivilisierte Leitung“ ist.
<G-vec00418-001-s234><boast.sich_rühmen><en> The same situation is with daffodils, which can also boast of their own foliage.
<G-vec00418-001-s234><boast.sich_rühmen><de> Die gleiche Situation ist mit Narzissen, die auch von ihren eigenen Laub rühmen kann.
<G-vec00418-001-s235><boast.sich_rühmen><en> International schools are very expensive, but usually offer high standards of learning, boast smaller class sizes, first-rate facilities, and extracurricular's.
<G-vec00418-001-s235><boast.sich_rühmen><de> Internationale Schulen sind sehr teuer, aber bieten in der Regel ein hohes Maß an Lern-, rühmen kleinere Klassen, erstklassigen Einrichtungen und außerschulischen ist.
<G-vec00418-001-s236><boast.sich_rühmen><en> Olivier Charlier may, rightly, claim membership in the French school of violin - that of Jacques Thibaud, Ginette Neveu, Christian Ferras... and boast the shine on stages around the world.
<G-vec00418-001-s236><boast.sich_rühmen><de> Olivier Charlier kann zu Recht, Anspruch Mitgliedschaft in der Französisch Schule des Geigen - das von Jacques Thibaud, Ginette Neveu, Christian Ferras... und rühmen den Glanz auf den Bühnen der ganzen Welt.
<G-vec00418-001-s237><boast.sich_rühmen><en> 5 On behalf of such a one I will boast, but on my own behalf I will not boast, except in my weaknesses.
<G-vec00418-001-s237><boast.sich_rühmen><de> 5 Über einen solchen werde ich mich rühmen; über mich selbst aber werde ich mich nicht rühmen, es sei denn meiner Schwachheiten.
<G-vec00418-001-s239><boast.sich_rühmen><en> 12 We are not commending ourselves to you again but giving you cause to boast about us, so that you may be able to answer those who boast about outward appearance and not about what is in the heart.
<G-vec00418-001-s239><boast.sich_rühmen><de> 12 Wir empfehlen uns nicht abermals selbst, sondern wir geben euch Gelegenheit, von uns zu rühmen, damit ihr es denen entgegenhalten könnt, die sich des Äußern rühmen, aber nicht des Herzens.
<G-vec00418-001-s240><boast.sich_rühmen><en> If we have a living faith in God we shall always make our boast in Him.
<G-vec00418-001-s240><boast.sich_rühmen><de> Wenn wir einen lebendigen Glauben an Gott haben, werden wir uns immer seiner rühmen.
<G-vec00418-001-s241><boast.sich_rühmen><en> 9:16 Yet when I preach the gospel, I cannot boast, for I am compelled to preach.
<G-vec00418-001-s241><boast.sich_rühmen><de> 9:16 Denn daß ich das Evangelium predige, darf ich mich nicht rühmen; denn ich muss es tun.
<G-vec00418-001-s242><boast.sich_rühmen><en> Seeing that many boast after the flesh, I will also boast.
<G-vec00418-001-s242><boast.sich_rühmen><de> Sintemal viele sich rühmen nach dem Fleisch, will ich mich auch rühmen.
<G-vec00418-001-s243><boast.sich_rühmen><en> Relaxation and stunning simplicity and ease of the body and muscles, it is the effects of which can boast of Black Jack auto.
<G-vec00418-001-s243><boast.sich_rühmen><de> Entspannung und einen atemberaubenden Einfachheit und Leichtigkeit des Körpers und der Muskeln, es ist die Wirkung von denen von Black Jack Auto rühmen kann.
<G-vec00418-001-s244><boast.sich_rühmen><en> Deserves particular mention of Montoro copper onions that besides having a high cooking resistance can boast unique organoleptic qualities that give almost all the traditional dishes of the bell, as the onion gets a little 'everywhere, aromas inimitable.
<G-vec00418-001-s244><boast.sich_rühmen><de> "Besondere Erwähnung verdient der Montoro Kupfer Zwiebeln, die neben einer hohen Kochen Widerstand kann einzigartigen organoleptischen Qualitäten rühmen, dass fast alle traditionellen Gerichte der Glocke geben, wie die Zwiebel wird ein wenig ""überall, Aromen unnachahmlich."
<G-vec00418-001-s245><boast.sich_rühmen><en> There is a possibility that one of two of them can just boast, but it is impossible to imagine that all of them are of this kind.
<G-vec00418-001-s245><boast.sich_rühmen><de> Es besteht die Möglichkeit, die eine der zwei von ihnen nur rühmen kann, aber es ist unmöglich, sich vorzustellen, dass alle von ihnen dieser Art sind.
<G-vec00418-001-s246><boast.sich_rühmen><en> 14 But may it never be that I would boast, except in the cross of our Lord Jesus Christ, through which the world has been crucified to me, and I to the world.
<G-vec00418-001-s246><boast.sich_rühmen><de> 14 Von mir aber sei es ferne, mich zu rühmen, als nur des Kreuzes unseres Herrn Jesus Christus, durch das mir die Welt gekreuzigt ist und ich der Welt.
<G-vec00418-001-s247><boast.sich_rühmen><en> And this communization is also necessary nowadays because somehow must be opposed the individualism that is good for the business yet not enough good for the people, because I am convinced that people not so much want to boast with new sparkling things as they want to be valued well by the others (I am convinced in this because even the home animals want this, providing they are kept well satiated, they want company).
<G-vec00418-001-s247><boast.sich_rühmen><de> Und diese Kommunisierung ist auch heutzutage notwendig, weil irgendwie dem Individualismus entgegengewirkt werden muss, denn der ist gut für die Geschäfte, aber ist nicht gut genug für die Menschen, da ich überzeugt bin, dass die Leute nicht so sehr mit neuen funkelnden Dingen rühmen wollen, wie sie von den anderen gut geschätzt werden wollen (davon bin ich überzeugt, denn auch die Heimtiere wollen das, vorausgesetzt sie sind gut gesättigt, sie wollen Gesellschaft).
<G-vec00418-001-s248><boast.sich_rühmen><en> While the resource is still young and can not boast of a wide information base or an abundance of experts, but time will put everything in its place.
<G-vec00418-001-s248><boast.sich_rühmen><de> Während der Ressource ist noch jung und kann nicht von einer breiten Informationsbasis oder eine Fülle von Experten rühmen, aber die Zeit wird alles an seinen Platz gebracht.
<G-vec00418-001-s249><boast.sich_rühmen><en> The success of NTP stems from its constant development (version 4 is currently in progress) and the accuracy that an NTP time server can boast in the synchronisation of networks.
<G-vec00418-001-s249><boast.sich_rühmen><de> Der Erfolg von NTP stammt aus seiner ständigen Entwicklung (Version 4 ist derzeit im Gange) und die Genauigkeit, die ein NTP-Zeitserver bei der Synchronisation von Netzwerken rühmen kann.
<G-vec00418-001-s250><boast.sich_rühmen><en> But if you do, then at least accept me as a fool, so that I too may boast a little.
<G-vec00418-001-s250><boast.sich_rühmen><de> Andernfalls aber nehmt mich als einen Törichten an, damit auch ich mich ein wenig rühmen kann.
<G-vec00418-001-s251><boast.sich_rühmen><en> High number of visitors boast Pilsen Zoological and Botanical Garden in Plzeň, which is considered one of the most beautiful zoo in the Czech Republic.
<G-vec00418-001-s251><boast.sich_rühmen><de> Hohe Anzahl von Besuchern rühmen Pilsen Zoologischen und Botanischen Garten in Pilsen, das als eines der schönsten Zoos in der Tschechischen Republik ist.
<G-vec00418-001-s252><boast.sich_rühmen><en> Nel segment of megayacht the Fincantieri can boast the delivery in 2011 of the Serene ones, of 134 meters, the greater, luxurious boat and technologically advanced never constructed in Italy and between the first ten to the world, winner of the prize “World Superyacht Awards” 2012.
<G-vec00418-001-s252><boast.sich_rühmen><de> Nel kann Segment von den Fincantieri megayacht, von 134 Metern, das sehr große, luxuriöse Boot, und technologisch nie vorankommt baut in Italien und erst zehn die Welt, gewinn von dem Preis „World Superyacht Awards“ 2012 die Lieferung in 2011 von Gelassenen rühmen.
<G-vec00418-001-s253><boast.sich_rühmen><en> The signatories to the Schengen Agreement of 1985 and 1990 boast to have reduced border controls at their common borders.
<G-vec00418-001-s253><boast.sich_rühmen><de> Die Unterzeichnerstaaten der Schengener Abkommen von 1985 und 1990 rühmen sich, die Grenzkontrollen an ihren gemeinsamen Grenzen abgebaut zu haben.
<G-vec00418-001-s254><boast.sich_rühmen><en> All units boast spectacular views of Banderas Bay, and are equipped with the highest quality appliances.
<G-vec00418-001-s254><boast.sich_rühmen><de> Alle Maßeinheiten rühmen sich großartige Ansichten der Banderas Bucht und werden mit den hochwertigsten Geräten ausgerüstet.
<G-vec00418-001-s255><boast.sich_rühmen><en> If attention is to strengthen the ego and affirm the narcissism, compete without scruples, Excel and boast of being superior, both better is to give back to the Mindfulnes.
<G-vec00418-001-s255><boast.sich_rühmen><de> Aufmerksamkeit auf das Ego zu stärken und den Narzissmus zu bekräftigen, konkurrieren, ohne Skrupel, Excel und rühmen sich überlegen, beide besser ist, die Mindfulnes zurückzugeben.
<G-vec00418-001-s256><boast.sich_rühmen><en> Senior suites are slightly larger and boast the same features as Junior Suites.
<G-vec00418-001-s256><boast.sich_rühmen><de> Ältere Suiten sind etwas größer und rühmen sich die gleichen Eigenschaften wie Juniorsuiten.
<G-vec00418-001-s257><boast.sich_rühmen><en> All rooms boast a balcony looking out to the Bucegi Mountains or/and Piatra Craiului.
<G-vec00418-001-s257><boast.sich_rühmen><de> Alle Räume rühmen sich einen Balkon, der heraus zu den Bucegi Bergen und/oder zum Piatra Craiului schaut.
<G-vec00418-001-s258><boast.sich_rühmen><en> "Today the wines of Montefalco, in particular the Sagrantino (in a dry and sweet version) are decorated with the recognition of the Denominazione d'origine controllata e garantita (D.O.C.G.) (Denomination of origin, controlled and guaranteed), a type of ""superdoc"" which not many Italian oenological areas can boast about."
<G-vec00418-001-s258><boast.sich_rühmen><de> "Heute rühmen sich die Weine von Montefalco, insbesondere der Sagrantino (in trockener Version und Likörversion) der Anerkennung der Denominazione d'origine controllata e garantita (Garantierte kontrollierte Herkunftsbezeichnung), einer Art ""superdoc"", die nur wenige italienische Weingebiete aufweisen können."
<G-vec00418-001-s259><boast.sich_rühmen><en> While other opportunists offer the occasional criticism of Chávez, Woods and his outfit actually boast of being “Trotskyist” advisers to the left-talking caudillo .
<G-vec00418-001-s259><boast.sich_rühmen><de> "Während andere Opportunisten gelegentlich Kritik an Chávez anbringen, rühmen sich Woods und seine Gruppierung tatsächlich, ""trotzkistische"" Berater des sich links gebenden Caudillos zu sein."
<G-vec00418-001-s260><boast.sich_rühmen><en> They boast of their success.
<G-vec00418-001-s260><boast.sich_rühmen><de> Sie rühmen sich auf ihre Leistungen.
<G-vec00418-001-s261><boast.sich_rühmen><en> In recent years, many 5-reel slots boast a certain number of “ways to win”.
<G-vec00418-001-s261><boast.sich_rühmen><de> In den letzten Jahren rühmen sich viele 5-Reel-Slots mit einer bestimmten Anzahl von „Gewinnmöglichkeiten“.
<G-vec00418-001-s262><boast.sich_rühmen><en> Those who live according to the flesh still boast of their churches and of having been materially blessed by attending their large churches.
<G-vec00418-001-s262><boast.sich_rühmen><de> Diejenigen, die nach dem Fleisch leben, rühmen sich immer noch ihrer Kirchen, und dass sie materiellen Segen erhalten haben, indem sie in große Kirchen gehen.
<G-vec00418-001-s263><boast.sich_rühmen><en> They boast of it before men and Angels, before an unbelieving world, and before fallen spirits; with no confusion of face, but with a reverent boldness they confess this miracle of grace, and cherish it in their creed, though it gains them but the contempt and derision of the proud and ungodly.
<G-vec00418-001-s263><boast.sich_rühmen><de> Sie rühmen sich seiner vor Men­schen und Engeln, vor einer ungläubigen Welt und vor gefallenen Geistern; nicht verschämten Gesich­tes, sondern mit ehrfürchtiger Kühnheit bekennen sie dieses Wunder der Gnade und behüten es in ihrem Credo, obwohl es ihnen die Verachtung und den Spott der Stolzen und Unheiligen einbringt.
<G-vec00418-001-s264><boast.sich_rühmen><en> Our innovative handling robot also boast an human-machine interface of last generation, integrated directly on the mobile console of the robot in order to facilitate the complete control of the plant (setting the parameters of production, diagnostics, maintenance, manual controls, etc.
<G-vec00418-001-s264><boast.sich_rühmen><de> Die innovatorischen Behandlungslösungen rühmen sich auch einer Schnittstelle letzter Entwicklung, die direkt auf die bewegliche Konsole des Roboters integriert wird, um die vollständige Kontrolle der Installation zu erleichtern (das Setzen von den Parametern der Produktion, Diagnostik, Pflege, Handsteuerungen, und so weiter.
<G-vec00418-001-s265><boast.sich_rühmen><en> I am certain that they [the martyrs] do not boast of what they have experienced, because they know that it was the Lord who sustained them.
<G-vec00418-001-s265><boast.sich_rühmen><de> Sie rühmen sich nicht dessen, was sie erlebt haben, des bin ich sicher, denn sie wissen, dass es der Herr war, der sie vorangebracht hat.
<G-vec00418-001-s266><boast.sich_rühmen><en> Do not show off or boast to your peers or friends outside.
<G-vec00418-001-s266><boast.sich_rühmen><de> Stellen Sie nicht weg dar oder rühmen Sie sich zu Ihren Gleichen oder zu Freunden draußen.
<G-vec00418-001-s267><boast.sich_rühmen><en> International activists boast they have blocked more than 200 hydroelectric dams in the developing world and are campaigning to tear down existing dams.
<G-vec00418-001-s267><boast.sich_rühmen><de> Internationale Aktivisten rühmen sich, in den Entwicklungsländern mehr als 200 Staudämme blockiert zu haben, und kämpfen darum, bestehende Dämme abzureißen.
<G-vec00418-001-s268><boast.sich_rühmen><en> Today, not a few of the villas and hotel palaces along the French Riviera boast owning one of only 23 classified growths of the Côtes de Provence Riviera, some of the early broad-based stemmed Burgundy bottles of Chateau minuty.
<G-vec00418-001-s268><boast.sich_rühmen><de> Noch heute rühmen sich nicht wenige der Villen und Hotelpaläste entlang der Côte d'Azur, einige der frühen dickbauchigen Burgunderflaschen von Chateau Minuty, einem der nur 23 klassifizierten Gewächs der Côtes de Provence zu besitzen.
<G-vec00418-001-s269><boast.sich_rühmen><en> PH between 7 and 8 can boast of good health.
<G-vec00418-001-s269><boast.sich_rühmen><de> Ein pH-Wert zwischen 7 und 8 rühmt sich guter Gesundheit.
<G-vec00418-001-s270><boast.sich_rühmen><en> All 94 air-conditioned rooms and suites are luxuriously furnished with light contemporary décor and views of the Alfred Basin or Piazza and boast all modern amenities and comforts.
<G-vec00418-001-s270><boast.sich_rühmen><de> Alle 94 klimatisierte Zimmer und Zimmerfluchten sind Luxus mit leichtem zeitgenössischem décor und Blicken von dem Alfred Becken oder Platz ausgestattet und rühmt sich alle modernen öffentlichen Einrichtung und Trost.
<G-vec00418-001-s271><boast.sich_rühmen><en> In addition to its natural heritage, Zagorje can also boast a cultural one.
<G-vec00418-001-s271><boast.sich_rühmen><de> Neben dem Naturerbe, rühmt sich Zagorje auch seines Kulturerbes.
<G-vec00418-001-s272><boast.sich_rühmen><en> It boast a new jackpot feature assuring that players will be enable to win huge amounts of cash.
<G-vec00418-001-s272><boast.sich_rühmen><de> Es rühmt sich einer neuen Jackpot Eigenschaft die versichert, dass es Spieler möglich sein wird, riesige Beträge an Bargeldes zu gewinnen.
<G-vec00418-001-s303><boast.sich_rühmen><en> "He says in the Epistle to the Ephesians, ""For by grace are ye saved through faith; and that not of yourselves: it is the gift of God not of works, lest any man should boast."""
<G-vec00418-001-s303><boast.sich_rühmen><de> "Er sagt in dem Brief an die Epheser, ""Denn aus Gnade seid ihr selig geworden durch den Glauben, und das nicht aus euch: Gottes Gabe ist es, nicht aus den Werken, auf daß sich nicht jemand rühme""."
<G-vec00418-001-s304><boast.sich_rühmen><en> For having said to a tyrant of a provincial capital, to a „national benefactor“, that he is „criminal and depraved“ to boast about the murder of four peasants who wanted to steal some bottles of wine from him, Krležas sacriligious hero, a lawyer who up till then had lived his whole life „like a tidy zero in a crowd of tidy zeros“, sees a scandal break out which will make him lose his position, his family, his belongings, and which will lead him from prison to prison, from hospital to a lunatic asylum.
<G-vec00418-001-s304><boast.sich_rühmen><de> Dafür daß er einem omnipotenten „nationalen Wohltäter“ einer Provinzhauptstadt gesagt hat, daß er ein »Krimineller und Verderbterx sei, da er sich rühme vier Bauern, die versucht hatten ein paar Flaschen Wein zu stehlen, umgebracht zu haben, sieht sich der sakrilegierte Held Krležas, ein Advokat, der bis dahin ein Leben als wohlgeordnete Null unter wohlgeordneten Nullen gelebt hatte, einen Skandal entfesseln, der ihn um seine Stellung, seine Familie, Hab und Gut bringen, von Gefängnis zu Gefängnis führen und schließlich vom Krankenhaus in eine „Nervenklinik“ schicken wird.
<G-vec00418-001-s305><boast.sich_rühmen><en> 27 But God chose the foolish things of the world to shame the wise; God chose the weak things of the world to shame the strong. 28 God chose the lowly things of this world and the despised things – and the things that are not – to nullify the things that are, 29 so that no one may boast before him.
<G-vec00418-001-s305><boast.sich_rühmen><de> 27 Sondern was töricht ist vor der Welt, das hat Gott erwählt, damit er die Weisen zuschanden mache; und was schwach ist vor der Welt, das hat Gott erwählt, damit er zuschanden mache, was stark ist; 28 und das Geringe vor der Welt und das Verachtete hat Gott erwählt, das, was nichts ist, damit er zunichte mache, was etwas ist, 29 damit sich kein Mensch vor Gott rühme.
<G-vec00418-001-s306><boast.sich_rühmen><en> 9 not as a result of works, so that no one may boast.
<G-vec00418-001-s306><boast.sich_rühmen><de> 9nicht aus Werken, damit niemand sich rühme.
<G-vec00418-001-s307><boast.sich_rühmen><en> Some try to show that faith alone is sufficient for salvation by citing Saint Paul’s letter to the Ephesians, 2:8-9: “For by grace you have been saved through faith; and this is not your own doing, it is the gift of God—not because of works, lest any man should boast.”
<G-vec00418-001-s307><boast.sich_rühmen><de> Einige versuchen zu zeigen, dass der Glaube allein ausreichend ist für die Rettung von unter Berufung auf Paulus 'Brief an die Epheser, 2:8-9: „Denn durch die Gnade seid ihr durch den Glauben gerettet; und das ist nicht Ihr eigenes Werk, es ist die Gabe Gottes, nicht wegen der Arbeiten, Doch damit sich nicht jemand rühme.“, dieser Satz soll im Kontext gelesen werden.
<G-vec00418-001-s308><boast.sich_rühmen><en> that no flesh should boast before God.
<G-vec00418-001-s308><boast.sich_rühmen><de> daß sich vor Gott kein Fleisch rühme.
<G-vec00418-001-s309><boast.sich_rühmen><en> Ephesians 2:8-10 2:8 For by grace you have been saved through faith, and that not of yourselves; it is the gift of God, not of works, lest anyone should boast.
<G-vec00418-001-s309><boast.sich_rühmen><de> "Epheser 2:8-10 8 ""Denn aus Gnade seid ihr selig geworden durch Glauben, und das nicht aus euch: Gottes Gabe ist es, 9 nicht aus Werken, damit sich nicht jemand rühme."
<G-vec00418-001-s310><boast.sich_rühmen><en> 29 so that no flesh should boast before God.
<G-vec00418-001-s310><boast.sich_rühmen><de> 29 damit sich vor Gott kein Fleisch rühme.
<G-vec00418-001-s311><boast.sich_rühmen><en> For it is by grace you have been saved, through faith—and this not from yourselves, it is the gift of God— not by works, so that no one can boast.
<G-vec00418-001-s311><boast.sich_rühmen><de> „Denn aus Gnade seid ihr errettet durch Glauben, und das nicht aus euch, Gottes Gabe ist es; nicht aus Werken, damit niemand sich rühme.
<G-vec00418-001-s312><boast.sich_rühmen><en> For by grace are you saved through faith; and that not of yourselves: it is the gift of God: not of works, lest any man should boast.
<G-vec00418-001-s312><boast.sich_rühmen><de> Denn aus Gnaden seid ihr selig geworden durch Glauben, und das nicht aus euch: Gottes Gabe ist es, nicht aus Werken, damit sich nicht jemand rühme.
<G-vec00418-001-s313><boast.sich_rühmen><en> There is no justification through any kind of works, salvation is just the gift of God ‒ giving no one any call to boast.
<G-vec00418-001-s313><boast.sich_rühmen><de> Es gibt keine Rechtfertigung durch irgendwelche Werke, sondern es ist die Gabe Gottes, damit sich niemand rühme.
<G-vec00418-001-s314><boast.sich_rühmen><en> """For by grace are ye saved through faith... not of works, lest any man should boast"" (Eph."
<G-vec00418-001-s314><boast.sich_rühmen><de> """Denn aus Gnade seid ihr gerettet worden durch den Glauben... nicht aus den Werken, auf das sich nicht jemand rühme"" (Eph."
<G-vec00418-001-s315><boast.sich_rühmen><en> """For it is by grace you have been saved, through faith - and this not of yourselves, it is the gift of God - not by works, so that no one can boast"" (Ephesians 2:8-9)."
<G-vec00418-001-s315><boast.sich_rühmen><de> „Denn aus Gnade seid ihr selig geworden durch Glauben, und das nicht aus euch: Gottes Gabe ist es, nicht aus Werken, damit sich nicht jemand rühme.“ (Epheser 2,8-9).
<G-vec00418-001-s317><boast.sich_rühmen><en> not of works, that no one would boast.
<G-vec00418-001-s317><boast.sich_rühmen><de> nicht aus Werken, damit niemand sich rühme.
<G-vec00418-001-s318><boast.sich_rühmen><en> 9 Not of works, lest any man should boast.
<G-vec00418-001-s318><boast.sich_rühmen><de> 9 Nicht aus Werken, damit niemand sich rühme.
<G-vec00418-001-s319><boast.sich_rühmen><en> The “Romantik Hotel Furno” can boast a splendid garden which, with its gazebos, patios and lake, surrounds the entire complex.
<G-vec00418-001-s319><boast.sich_rühmen><de> Das Romantik Hotel Furno darf sich einen herrlicher Garten rühmen, der mit seinem Gazebo, seinem Dehor und der kleiner See, die ganze Struktur einfriedet.
<G-vec00418-001-s320><boast.sich_rühmen><en> Ultra 85/100 can boast excellent low-noise levels thanks to the suction motor fitted inside a double-wall tank made of insulating polyethylene.
<G-vec00418-001-s320><boast.sich_rühmen><de> Ultra 85/100 kann sich großer Geräuscharmut rühmen, dank der Installation des Saugmotors innerhalb des Tanks aus doppelwandigem Polyäthylen.
<G-vec00418-001-s321><boast.sich_rühmen><en> As we remember from the lessons of biology, a born girl can boast that her father and mother borrowed two X-chromosomes, which in some way provides the probability that the baby can be similar to both mom and dad.
<G-vec00418-001-s321><boast.sich_rühmen><de> Wie wir uns aus den Lehren der Biologie erinnern, kann ein geborenes Mädchen sich rühmen, dass sich Vater und Mutter zwei X-Chromosomen geliehen haben, was in gewisser Weise die Wahrscheinlichkeit bietet, dass das Baby Mutter und Vater ähnlich sein kann.
<G-vec00418-001-s322><boast.sich_rühmen><en> 2 My soul shall boast in the Lord. The humble shall hear of it, and be glad.
<G-vec00418-001-s322><boast.sich_rühmen><de> 2 Meine Seele soll sich rühmen des HERRN, daß es die Elenden hören und sich freuen.
<G-vec00418-001-s324><boast.sich_rühmen><en> Though the Sprint Galaxy Nexus won’t surf on 4G LTE straight out of the gate, it will immediately boast a feature the Verizon Galaxy Nexus can’t match: support for Google Wallet.
<G-vec00418-001-s324><boast.sich_rühmen><de> Obwohl die Sprint Galaxy Nexus nicht auf zu surfen 4G LTE gerade aus dem Tor, es wird sofort ein Feature, das sich rühmen Verizon Galaxy Nexus nicht mithalten können: Unterstützung für Google Wallet.
<G-vec00418-001-s325><boast.sich_rühmen><en> The Sophists could, with some fairness, boast of being the teachers of the Athenians.
<G-vec00418-001-s325><boast.sich_rühmen><de> Die Sophisten konnten sich zu Recht rühmen, daß sie die Lehrer der Athener waren.
<G-vec00418-001-s327><boast.sich_rühmen><en> In the wake of the rediscovery in the seventies of the Cammino di Santiago, one realised that also Italy could boast a similar route for pilgrimages: the Via Francigena.
<G-vec00418-001-s327><boast.sich_rühmen><de> In Nachahmung der Wiederentdeckung in den Siebziger Jahren des Cammino di Santiago entdeckt man, dass auch Italien sich eines ähnlichen Pilgerweges rühmen konnte: der Frankenweg.
<G-vec00418-001-s328><boast.sich_rühmen><en> Only one small space in Europe, anyhow, can boast of a complete civilization.
<G-vec00418-001-s328><boast.sich_rühmen><de> Nur ein kleiner Raum in Europa kann allenfalls einer ganzen Kultur sich rühmen.
<G-vec00418-001-s329><boast.sich_rühmen><en> And this is a feature which only few rippers on the market can boast.
<G-vec00418-001-s329><boast.sich_rühmen><de> Und dies ist ein Feature, der sich nur wenige Ripper auf dem Markt rühmen können.
<G-vec00418-001-s330><boast.sich_rühmen><en> The prefecture can boast of the largest number of ancient theatres.
<G-vec00418-001-s330><boast.sich_rühmen><de> Die Präfektur kann sich einer großen Anzahl von Theatern rühmen.
<G-vec00418-001-s331><boast.sich_rühmen><en> For the Neapolitans, the master pastry chefs of Carraturo, and their sfogliatelle, represent a real heritage for the city, an inestimable fortune to boast all over the world.
<G-vec00418-001-s331><boast.sich_rühmen><de> Für die Neapolitaner sind die Konditormeister von Carraturo und ihre Sfogliatelle eine echte Spezialität Erbe für die Stadtein unschätzbares Vermögen, um sich auf der ganzen Welt zu rühmen.
<G-vec00418-001-s332><boast.sich_rühmen><en> This tour combines two winemaking areas that are well known to wine connoisseurs: Colli Orientali and the Collio, which boast celebrities such as Tocai Friulano, Ribolla Gialla and the rare Picolit.
<G-vec00418-001-s332><boast.sich_rühmen><de> Diese Tour geht durch zwei Weingebiete, die den Weinkennern sehr bekannt sind: Colli Orientali und Collio, die sich bekannter Namen wie Tocai Friulano, Ribolla Gialla und des seltenen Picolit rühmen dürfen.
<G-vec00418-001-s333><boast.sich_rühmen><en> This public company can boast good business results and resolve to, despite the crisis, increase the level of investments in railway infrastructure modernization.
<G-vec00418-001-s333><boast.sich_rühmen><de> Dieses öffentliche Unternehmen kann sich auch damit rühmen, dass es auch neben der Krise das Niveau der Investitionen in die Modernisierung der Bahninfrastruktur erhöhen möchte.
<G-vec00418-001-s334><boast.sich_rühmen><en> And thus the Apostle continues, “let no one boast of men”.
<G-vec00418-001-s334><boast.sich_rühmen><de> Daher, so fahre der Apostel fort, »soll sich niemand eines Menschen rühmen«.
<G-vec00418-001-s335><boast.sich_rühmen><en> The baseball begins to boast more and more fans also in Italy.
<G-vec00418-001-s335><boast.sich_rühmen><de> Das baseball beginnt, sich rühmen, immer mehr fans auch in Deutschland.
<G-vec00418-001-s336><boast.sich_rühmen><en> No other motorsport event can boast more than 100 years of such illustrious history, rich in tradition and legends, and to have your name inscribed on a TT trophy is to sit with the gods.
<G-vec00418-001-s336><boast.sich_rühmen><de> Keine andere Motorsport-Veranstaltung kann sich rühmen, mehr als 100 Jahren von so illustren Geschichte, reich an Tradition und Legenden, und Ihren Namen auf einem TT-Trophäe eingeschrieben ist, um mit den Göttern zu sitzen.
<G-vec00418-001-s337><boast.sich_rühmen><en> It has pleased your benevolence to govern your family well through such a man, so that the sublimity of your power may be seen and not that of man, so that the wise may not boast of their wisdom or the just of their justice or the strong of their strength. For when the latter govern your people well, it is not they who sustain them but you.
<G-vec00418-001-s337><boast.sich_rühmen><de> Es hat deiner Güte gefallen, deine Familie durch einen solchen Menschen gut zu leiten, so daß man die Erhabenheit deiner Macht erkenne, nicht die des Menschen, auf daß sich der Weise nicht seiner Weisheit, der Gerechte seiner Gerechtigkeit, noch der Starke seiner Stärke rühmen mögen: denn wenn diese dein Volk gut leiten, bist du es, der es trägt, und nicht sie.
<G-vec00418-001-s370><boast.sich_rühmen><en> 2 For if Abraham has been justified on the principle of works, he has whereof to boast: but not before God;
<G-vec00418-001-s370><boast.sich_rühmen><de> 2 Denn wenn Abraham aus Werken (O. auf dem Grundsatz der Werke) gerechtfertigt worden ist, so hat er etwas zum Rühmen, aber nicht vor Gott.
<G-vec00418-001-s371><boast.sich_rühmen><en> Seeing that many boast according to the flesh, I also will boast.
<G-vec00418-001-s371><boast.sich_rühmen><de> Weil viele sich nach dem Fleisch rühmen, so will auch ich mich rühmen.
<G-vec00418-001-s372><boast.sich_rühmen><en> Since many boast according to flesh, *I* also will boast.
<G-vec00418-001-s372><boast.sich_rühmen><de> Weil viele sich nach dem Fleisch rühmen, so will auch ich mich rühmen.
<G-vec00418-001-s373><boast.sich_rühmen><en> But if you have bitter envy and self-seeking in your hearts, do not boast and lie against the truth.
<G-vec00418-001-s373><boast.sich_rühmen><de> Habt ihr aber bitteren Neid und Zank in eurem Herzen, so rühmt euch nicht und lügt nicht wider die Wahrheit.
<G-vec00418-001-s374><boast.sich_rühmen><en> but if ye have bitter emulation and strife in your hearts, do not boast and lie against the truth.
<G-vec00418-001-s374><boast.sich_rühmen><de> Habt ihr aber bitteren Neid und Zank in eurem Herzen, so rühmt euch nicht und lügt nicht wider die Wahrheit.
<G-vec00418-001-s375><boast.sich_rühmen><en> 16 But now you boast in your arrogance.
<G-vec00418-001-s375><boast.sich_rühmen><de> Jam 4:16 So aber rühmt ihr euch in euren Prahlereien.
<G-vec00418-001-s376><boast.sich_rühmen><en> 14 But if you have bitter jealousy and selfish ambition in your heart, don't boast and don't lie against the truth.
<G-vec00418-001-s376><boast.sich_rühmen><de> 14 Habt ihr aber bitteren Neid und Zank in eurem Herzen, so rühmt euch nicht und lügt nicht wider die Wahrheit.
<G-vec00418-001-s388><boast.verfügen><en> As well as being much quieter, the 22 Duplex trainsets financed boast a passenger capacity up to 40% higher than standard trains, depending on the layout of seating.
<G-vec00418-001-s388><boast.verfügen><de> Neben dem Vorteil, dass sie deutlich weniger Lärm verursachen, verfügen diese 22 Duplex-Zuggarnituren je nach Sitzausstattung über bis zu 40% mehr Fahrgastkapazität als herkömmliche Züge.
<G-vec00418-001-s389><boast.verfügen><en> There is a brand new entry in the form of MOMO (IVB), owned by Dieter Schoen, while the crews of Sir Peter Ogden’s Jethou (GBR) and Roberto Tomasini Grinover’s Robertissima III (ITA) – the former Rán 2 – boast rich Porto Cervo experience.
<G-vec00418-001-s389><boast.verfügen><de> Ganz neu dabei ist die MOMO des deutschen Eigners Dieter Schön, während die Crews der Jethou von Sir Peter Ogden (Großbritannien) und der Robertissima III von Roberto Tomasini (Italien) – der früheren Rán 2 – bereits über reichlich Reviererfahrung verfügen.
<G-vec00418-001-s390><boast.verfügen><en> All rooms boast a flat-screen...
<G-vec00418-001-s390><boast.verfügen><de> Alle Zimmer verfügen...
<G-vec00418-001-s391><boast.verfügen><en> Featuring a private bathroom with a shower and free toiletries, some rooms at Halpins Town House also boast a river view.
<G-vec00418-001-s391><boast.verfügen><de> Einige Zimmer im Halpins Town House verfügen über ein eigenes Bad mit einer Dusche und kostenlosen Pflegeprodukten und bieten zudem Flussblick.
<G-vec00418-001-s392><boast.verfügen><en> Companies such as Adolf Würth GmbH, MAHLE GmbH, Schuler AG, STO AG, LÄPPLE AG and fischerwerke GmbH, which today boast locations all over the world and have established themselves successfully on international markets, hail from Baden-Württemberg.
<G-vec00418-001-s392><boast.verfügen><de> Unternehmen wie Adolf Würth GmbH, MAHLE GmbH, Schuler AG, STO AG, LÄPPLE AG und fischerwerke GmbH, die heute über weltweite Standorte verfügen und sich erfolgreich auf den internationalen Märkten etabliert haben, stammen aus Baden-Württemberg.
<G-vec00418-001-s393><boast.verfügen><en> Michel Therrien’s troops also boast the third-best power play among all teams that took part in the NHL playoffs behind the Blue Jackets (33.3%) and Lightning (33.3%).
<G-vec00418-001-s393><boast.verfügen><de> Michel Therrien Truppen verfügen auch die drittbeste Machtspiel unter allen Teams, die in den NHL-Playoffs hinter den Blue Jackets (33,3%) und Lightning (33,3%) fand.
<G-vec00418-001-s394><boast.verfügen><en> If you can not boast of their presence, and it is not necessary to undertake such a rather complex operation.
<G-vec00418-001-s394><boast.verfügen><de> Wenn Sie nicht ihrer Anwesenheit verfügen, und es ist nicht notwendig, eine solche eher komplexe Operation durchzuführen.
<G-vec00418-001-s395><boast.verfügen><en> All divisions boast air conditioning, French oak wardrobes and wooden floors....
<G-vec00418-001-s395><boast.verfügen><de> Alle Divisionen verfügen über Klimaanlage, französische Eichen Schränke und...
<G-vec00418-001-s396><boast.verfügen><en> Simply furnished, the rooms of the Hotel Brasil Milan boast high ceilings and parquet floors.
<G-vec00418-001-s396><boast.verfügen><de> Einfach eingerichtet, verfügen die Zimmer des Hotel Brasil Milan hohen Decken und Parkettboden.
<G-vec00418-001-s397><boast.verfügen><en> All boast air conditioning and heating, flat-screen TV and direct-dial telephone.
<G-vec00418-001-s397><boast.verfügen><de> Alle verfügen über Klimaanlage und Heizung, Flachbildfernseher und Direkttelefon.
<G-vec00418-001-s398><boast.verfügen><en> The boys boast about their hobbies war, football, sports games, and completely do not understand girls who prefer a more creative activities.
<G-vec00418-001-s398><boast.verfügen><de> Die Jungs verfügen über ihre Hobbys Krieg, Fußball, Sport-Spiele, und ganz verstehe nicht, Mädchen, die eine kreative Aktivitäten bevorzugen.
<G-vec00418-001-s399><boast.verfügen><en> Some of them already boast four stars, offering Wellness centers and swimming pools with heated sea water, while others are transformed into smaller family hotels and guest houses.
<G-vec00418-001-s399><boast.verfügen><de> Einige von ihnen verfügen bereits vier Sterne und bietet Wellness-Center und Pools mit beheiztem Meerwasser, während andere in kleinere Familienhotels und Pensionen umgewandelt.
<G-vec00418-001-s403><boast.verfügen><en> Elegant and traditionally furnished, rooms at Baytree all boast an en suite bathroom.
<G-vec00418-001-s403><boast.verfügen><de> Die eleganten und traditionell eingerichteten Zimmer im Baytree verfügen alle über ein eigenes Bad.
<G-vec00418-001-s404><boast.verfügen><en> The hotel has 24 beautiful rooms, soundproofed, equipped with air conditioning, flat screen cable TV and private bathroom with shower; all rooms also boast a private balcony.
<G-vec00418-001-s404><boast.verfügen><de> Das Hotel hat 24 schöne Zimmer, schallisoliert, mit Klimaanlage, Flachbildschirm Kabel-TV und eigenem Bad mit Dusche; alle Zimmer verfügen auch über einen privaten Balkon.
<G-vec00418-001-s405><boast.verfügen><en> The air-conditioned modern cabins boast a patio or balcony, a fully equipped kitchen and a flat-screen TV.
<G-vec00418-001-s405><boast.verfügen><de> Die klimatisierten, modernen Hütten verfügen über eine Veranda oder einen Balkon, eine voll ausgestattete Küche und einen Flachbild-TV.
<G-vec00418-001-s406><boast.verfügen><en> All rooms boast their own terrace, with outdoor patio sets, and are fully connected to free Wi-Fi.
<G-vec00418-001-s406><boast.verfügen><de> Alle Zimmer verfügen über eine eigene Terrasse, Mit Terrasse Sets sind voll angeschlossen Gratis Wi-Fi.
<G-vec00418-001-s407><boast.verfügen><en> Classic Room... from US$203 The comfortable standard double rooms boast balconies with views of a unique virgin landscape, rarely glimpsed in these modern times.
<G-vec00418-001-s407><boast.verfügen><de> Klassisch Zimmer... ab US$203 Die komfortablen Standard-Doppelzimmer verfügen über Balkons mit Ausblick auf eine unberührte Landschaft.
<G-vec00418-001-s408><boast.verfügen><en> Some apartments boast a terrace.
<G-vec00418-001-s408><boast.verfügen><de> Einige Apartments verfügen über eine Terrasse.
<G-vec00418-001-s409><boast.verfügen><en> All apartments boast a balcony or a terrace.
<G-vec00418-001-s409><boast.verfügen><de> Alle Wohnungen verfügen über einen Balkon oder eine Terrasse.
<G-vec00418-001-s410><boast.verfügen><en> 62% of users boast net household income of €2,000 or more, and 49% of users have an income of over €3,000 per month.
<G-vec00418-001-s410><boast.verfügen><de> 62% der User verfügen über ein Haushaltsnettoeinkommen von mindestens 2000 Euro, 49% der User stehen sogar mehr als 3000 Euro pro Monat zur Verfügung.
<G-vec00418-001-s411><boast.verfügen><en> The spacious rooms at the Smithfield Hotel boast a TV, a safe and either floor-to-ceiling windows or balconies with panoramic views of the city.
<G-vec00418-001-s411><boast.verfügen><de> Die geräumigen Zimmer im Smithfield Hotel verfügen über einen TV, einen Safe und entweder raumhohe Fenster oder einen Balkon mit Panoramablick auf die Stadt.
<G-vec00418-001-s412><boast.verfügen><en> All conference rooms boast the most up-to-date technology, plenty of daylight and air-conditioning.
<G-vec00418-001-s412><boast.verfügen><de> Alle Konferenzräume verfügen über die neueste Tagungstechnik, über Tageslicht und Klimaanlage.
<G-vec00418-001-s413><boast.verfügen><en> As part of the nature network®, we boast this wealth of experience and will provide you with reliable support in assessing and validating your findings.
<G-vec00418-001-s413><boast.verfügen><de> Als Teil des the nature network® verfügen wir über diesen umfangreichen Erfahrungsschatz und unterstützen Sie zuverlässig bei der Beurteilung und Absicherung der Befunde.
<G-vec00418-001-s414><boast.verfügen><en> Some hotels in the collection boast exceptional locations within close proximity to a golf course.
<G-vec00418-001-s414><boast.verfügen><de> Golf Einige Hotels der Kollektion verfügen über einen außergewöhnlichen Standort in der Nähe von Golfplätzen.
<G-vec00418-001-s415><boast.verfügen><en> All rooms boast a large seating area and walk-in wardrobe with abundant closet and luggage space.
<G-vec00418-001-s415><boast.verfügen><de> Alle Zimmer verfügen über einen großen Sitzbereich und einen begehbaren Kleiderschrank mit reichlich Platz im Schrank und für Koffer.
<G-vec00418-001-s416><boast.verfügen><en> The Staterooms also boast large bathrooms and some include pedestal claw baths.
<G-vec00418-001-s416><boast.verfügen><de> Die Staterooms verfügen zudem über große Badezimmer und einige bieten Podestklauen.
<G-vec00418-001-s417><boast.verfügen><en> All air-conditioned rooms boast beach inspired décor.
<G-vec00418-001-s417><boast.verfügen><de> Alle klimatisierten Zimmer verfügen über Stranddekor.
<G-vec00418-001-s418><boast.verfügen><en> Stylish rooms at Rocco Forte Brown's Hotel each boast an interactive LCD TV, air conditioning and seating area.
<G-vec00418-001-s418><boast.verfügen><de> Die stilvollen Zimmer im Rocco Forte Brown's Hotel verfügen über einen interaktiven LCD-TV, eine Klimaanlage und eine Sitzecke.
<G-vec00418-001-s419><boast.verfügen><en> Its community areas are designed for leisure and pleasure and boast modern pools with wooden decks and solarium, wonderful landscaped gardens with mature trees, well-groomed lawns, flowerbeds and natural stone wall creating a magical and unique Mediterranean setting.
<G-vec00418-001-s419><boast.verfügen><de> Die Gemeinschaftsbereiche sind für Freizeit und Vergnügen konzipiert und verfügen über moderne Pools mit Holzdecks und Solarium, wunderschöne angelegte Gärten mit altem Baumbestand, gepflegte Rasenflächen, Blumenbeete und Natursteinmauern, die eine magische und einzigartige mediterrane Umgebung schaffen.
<G-vec00418-001-s420><boast.verfügen><en> Some apartments also boast a balcony.
<G-vec00418-001-s420><boast.verfügen><de> Einige Apartments verfügen über einen Balkon.
<G-vec00418-001-s421><boast.verfügen><en> Not only do all SBC products meet the toughest demands for quality, they also boast a long service life and enable reliable operation.
<G-vec00418-001-s421><boast.verfügen><de> Alle SBC-Produkte genügen nicht nur höchsten Qualitätsansprüchen: Sie verfügen außerdem über einen langen Lebenszyklus und ermöglichen einen zuverlässigen Betrieb.
<G-vec00418-001-s422><boast.verfügen><en> The Prestige Suites boast a chic lounge and marble bathroom, while the Opera Suite with 2 bedrooms offers exceptional space. Rooms
<G-vec00418-001-s422><boast.verfügen><de> Die Prestige-Suite verfügt über eine schicke Lounge und ein Marmorbad, während die Opera-Suite mit 2 Schlafzimmern außergewöhnliches Ambiente bietet.
<G-vec00418-001-s423><boast.verfügen><en> A lovely, spacious, bright and light apt just off the trendy Emek Refaim this second floor apt boast two very large double bedrooms, 1.5 bathrooms, and a large living room, dining room/kitchen . view of trees from all windows The decor in muted beige and blues makes for a calm atmosphere Great...
<G-vec00418-001-s423><boast.verfügen><de> Alle Bewertungen anzeigen Über dieses Unternehmen Eine schöne, geräumige, helle und helle Wohnung direkt an der trendigen Emek Refaim diese zweite Etage verfügt über zwei sehr große Schlafzimmer, 1,5 Badezimmer und ein großes Wohnzimmer, Esszimmer / Küche.
<G-vec00418-001-s424><boast.verfügen><en> With over 50,000 customers, the Bank can now boast of over EUR 3,3 million clients' deposits.
<G-vec00418-001-s424><boast.verfügen><de> Mit mehr als 50000 Kunden verfügt die ABL jetzt über Einlagen von mehr als 3,3 Mio EUR.
<G-vec00418-001-s425><boast.verfügen><en> The company has longstanding experience in the development of new therapeutic applications and can boast a worldwide production and marketing network.
<G-vec00418-001-s425><boast.verfügen><de> Das Unternehmen hat langjährige Erfahrung in der Entwicklung neuer therapeutischer Anwendungen und verfügt über ein weltweites Produktions- und Vertriebsnetzwerk.
<G-vec00418-001-s426><boast.verfügen><en> With the acetate gently curving around the decorative pin detail, these lenses boast a unique and feminine shape.
<G-vec00418-001-s426><boast.verfügen><de> Mit dem sanft geschwungenen Acetat rund um das dekorative pin Detail, verfügt diese Brille über eine einzigartige, feminine Form.
<G-vec00418-001-s427><boast.verfügen><en> The Spanish Synagoge is the oldest Jewish building in Prague and boast stunning golden and geometric decorations, with a domed ceiling, Islamic motifs and stained glass.
<G-vec00418-001-s427><boast.verfügen><de> Die Spanische Synagoge ist das älteste jüdische Gebäude Prags und verfügt über atemberaubende goldene und geometrische Dekorationen mit Kuppelhimmel, islamischen Motiven und Glasmalerei.
<G-vec00418-001-s428><boast.verfügen><en> Nearly all rooms boast a balcony.
<G-vec00418-001-s428><boast.verfügen><de> Beinahe jedes Zimmer verfügt über einen Balkon.
<G-vec00418-001-s429><boast.verfügen><en> The hotel’s 204 newly refurbished, elegant rooms scream comfort and boast deep bathtubs for relaxing soaks, with free WiFi throughout for all guests.
<G-vec00418-001-s429><boast.verfügen><de> Das Hotel verfügt über insgesamt 204 frisch renovierte, elegante Zimmer, die absoluten Komfort und extratiefe Badewannen zum Entspannen, sowie kostenfreies WLAN in allen Bereichen bieten.
<G-vec00418-001-s430><boast.verfügen><en> The resort boast a luxury Spa and 5 swimming pools set in landscaped gardens.
<G-vec00418-001-s430><boast.verfügen><de> Das Resort verfügt über ein luxuriöses Spa und 5 Pools, die sich in einem Landschaftsgarten befinden.
<G-vec00418-001-s431><boast.können><en> Apart from its huge historical patrimony, the exclusive Villa boast a magnificent Italian garden, a modern well-being centre with swimming pool, sauna, gym, Spa treatments, acupuncture and even a ‘day clinic’ for beauty surgery.
<G-vec00418-001-s431><boast.können><de> Außer seinem immensen kulturellen Erbe kann das Gut auch einen prächtigen Garten, ein modernes Wellness-Centre mit Schwimmbad, Sauna, Fitnessraum, Spa-Behandlungen, Akupunktur und sogar eine Tagesklinik für Schönheitschirurgie vorweisen.
<G-vec00418-001-s432><boast.können><en> """No other party in Turkey could boast of a similar membership of women."
<G-vec00418-001-s432><boast.können><de> """Keine andere türkische Partei konnte eine vergleichbare Zahl an weiblichen Mitgliedern vorweisen."
<G-vec00418-001-s433><boast.können><en> Today it is a recreational area and sanctuary for numerous animal and plant species of a kind that not many towns can boast of.
<G-vec00418-001-s433><boast.können><de> Heute ist es ein Naherholungsgebiet und Ruhegebiet für zahlreiche Tier- und Pflanzenarten, wie es nur wenige Städte vorweisen können.
<G-vec00418-001-s434><boast.können><en> Though the Racing Speed XLR is a young entry, it can already boast an unparalleled array of victories.
<G-vec00418-001-s434><boast.können><de> Auch wenn das Racing Speed XLR noch eine junge Radgeneration ist, kann es ein noch nie da gewesenes Palmares an Siegen vorweisen.
<G-vec00418-001-s435><boast.können><en> Productions can suffer from poor screenplays or boast literary masterpieces.
<G-vec00418-001-s435><boast.können><de> Die Produktionen können unter schlechten Drehbüchern leiden oder literarische Meisterwerke vorweisen.
<G-vec00418-001-s436><boast.können><en> They are at home and abroad in the fields of IT, Management, Technology & Environment, Health Care & Social Sciences, and many of them can boast enviable careers.
<G-vec00418-001-s436><boast.können><de> Sie sind im In- und Ausland in den Bereichen IT, Management, Technik & Umwelt, Gesundheit & Soziales beruflich tätig, und viele von ihnen können beachtliche Karrieren vorweisen.
<G-vec00418-001-s437><boast.können><en> Thanks to these spokes, the new Racing 1™ wheels boast a considerable reduction in weight while maintaining the same values of resistance as the previous version.
<G-vec00418-001-s437><boast.können><de> Dank der neuen Speichen können die neuen Racing 1™ Modelle ein beachtlich vermindertes Gewicht vorweisen, den-noch entspricht ihre Beständigkeit der vorherigen Version.
<G-vec00418-001-s438><boast.können><en> He is acting very successfully in the markets and can boast an impressive performance.
<G-vec00418-001-s438><boast.können><de> Er agiert außerordentlich erfolgreich an den Märkten und kann eine beeindruckende Performance vorweisen.
<G-vec00418-001-s439><boast.können><en> ISW can also boast almost 20 years of experience in solving complex machine vision tasks.
<G-vec00418-001-s439><boast.können><de> Fast 20 Jahre Erfahrung in der Lösung von komplexen Aufgabenstellungen der Bildverarbeitung kann auch ISW vorweisen.
<G-vec00418-001-s440><boast.können><en> The city of love can boast some of the most famous buildings in the world with Notre Dame, the Louvre, the Arc de Triomphe and of course the Eiffel Tower.
<G-vec00418-001-s440><boast.können><de> Die Stadt der Liebe kann mit Notre Dame, Louvre, Triumphbogen und natÃ1⁄4rlich dem Eiffelturm einige der berÃ1⁄4hmtesten Bauwerke der Welt vorweisen.
<G-vec00418-001-s444><boast.aufweisen><en> Together they boast more than 100 Nobel laureates.
<G-vec00418-001-s444><boast.aufweisen><de> Gemeinsam weisen die beiden Institute mehr als 100 Nobelpreisträger auf.
<G-vec00418-001-s445><boast.aufweisen><en> In combination with the LED headlights, the taillights also boast a new design.
<G-vec00418-001-s445><boast.aufweisen><de> In Verbindung mit den LED-Scheinwerfern weisen auch die Heckleuchten ein neues Design auf.
<G-vec00418-001-s446><boast.aufweisen><en> Low household debt: In an international comparison, Germany’s households boast a low degree of debt relative to the country’s economic strength.
<G-vec00418-001-s446><boast.aufweisen><de> Geringe Verschuldung privater Haushalte: Deutschlands Haushalte weisen im internationalen Vergleich einen niedrigen Verschuldungsgrad relativ zur Wirtschaftskraft auf.
<G-vec00418-001-s463><boast.verfügen><en> In 3Soft, we are open to cooperate both with people who can boast extensive professional experience, as well as freshly baked graduates of technical colleges.
<G-vec00418-001-s463><boast.verfügen><de> Bei 3Soft sind wir offen auf die Zusammenarbeit sowohl mit Personen, die über große Berufserfahrung verfügen, als auch mit frischgebackenen Absolventen der technischen Hochschulen.
<G-vec00418-001-s464><boast.verfügen><en> Congratulations to those of you who can handle tiny electrical connections. In our opinion, a 2000+ Euros keyboard (a pro-instrument, so to speak), should boast an internal PSU with a standard power cable.
<G-vec00418-001-s464><boast.verfügen><de> "Unserer Meinung nach sollte ein 2000+ Euro Keyboard, ein Profi-Instrument sozusagen, ""zumindest"" über ein internes Netzteil samt Standard-3-Pol- (oder bei Roland: -2-Pol-) Stromstecker verfügen."
<G-vec00418-001-s465><boast.verfügen><en> In our opinion, a 2000+ Euros keyboard (a pro-instrument, so to speak), should boast an internal PSU with a standard power cable.
<G-vec00418-001-s465><boast.verfügen><de> Unserer Meinung nach sollte ein 2000+ Euro Keyboard, ein Profi-Instrument sozusagen, “zumindest” über ein internes Netzteil samt Standard-3-Pol- (oder bei Roland: -2-Pol-) Stromstecker verfügen.
<G-vec00418-001-s466><boast.verfügen><en> Nature is concerned not only to ensure the survival of one’s own particular species, but takes a much broader view of the matter, as may be seen from the example of bees, which also boast a similar collective intelligence to ants (just think of how bees build honeycomb, where every bee knows exactly what to do without having to be told).
<G-vec00418-001-s466><boast.verfügen><de> Dass die Natur nicht nur für die eigene Arterhaltung sorgt, sondern viel umfassender angelegt ist, zeigt sich etwa am Beispiel der Bienen, die übrigens auch über eine ähnliche kollektive Intelligenz verfügen; man denke nur an den Wabenbau, wo jede Biene unabgesprochen genau weiß, was ihre Aufgaben sind.
<G-vec00418-001-s467><boast.verfügen><en> As for the meat and potatoes of the e bike, Airwheel will boast a wide range of safety and convenience technologies.
<G-vec00418-001-s467><boast.verfügen><de> Was das Fleisch und die Kartoffeln des E-Bikes anbelangt, wird Airwheel über eine breite Palette von Sicherheits- und Komforttechnologien verfügen.
<G-vec00418-001-s468><boast.verfügen><en> Alongside charging points for electric cars, the depot will also boast a heat pump and a waste management system.
<G-vec00418-001-s468><boast.verfügen><de> Umweltfreundliche Elemente Das Depot wird neben Anschlüssen für Elektroautos auch über eine Wärmepumpenheizung sowie ein Abfallwirtschaftskonzept verfügen.
<G-vec00418-001-s469><boast.verfügen><en> And because not all She's Mercedes readers can boast Olympic form, the exercise intensity can be adapted to suit any level of fitness from beginner to advanced.
<G-vec00418-001-s469><boast.verfügen><de> Und weil natürlich nicht alle She's Mercedes Leserinnen über olympische Fitness verfügen, sind die Übungen gestaffelt vom Anfängerniveau bis hin zu den Profis.
<G-vec00418-002-s215><boast.prahlen><en> Tags: Streets and Squares Lugansk Stone Sculpture Park There are few museums, which can boast of the exhibits, which age is more than a thousand years.
<G-vec00418-002-s215><boast.prahlen><de> Tags: Straßen und Plätze Der Park der Steinstatuen in Lugansk Wenige Museen können mit den Exponaten prahlen, die mehr als Tausend Jahre alt sind.
<G-vec00418-002-s216><boast.prahlen><en> The very thing that should shame them, they boast in it. It's incredible.
<G-vec00418-002-s216><boast.prahlen><de> Genau die Sache, die eine Schande für sie sein sollte, ist die, mit der sie prahlen.
<G-vec00418-002-s217><boast.prahlen><en> Unfortunately, very few of us can boast of a perfectly healthy child, that's why it will be calmer, of course, when a knowledgeable person is next to the baby.
<G-vec00418-002-s217><boast.prahlen><de> Leider können nur sehr wenige von uns mit einem vollkommen gesunden Kind prahlen, deshalb wird es natürlich ruhiger, wenn neben dem Baby eine sachkundige Person ist.
<G-vec00418-002-s218><boast.prahlen><en> In contrast to its former neighbors Macedonia is landlocked and can not boast of the luxurious beaches of the Adriatic.
<G-vec00418-002-s218><boast.prahlen><de> Im Gegensatz zu seinen ehemaligen Nachbarländern hat Makedonien keinen Meerzugang und kann mit keinen luxuriösen Stränden von Adria prahlen.
<G-vec00418-002-s219><boast.prahlen><en> Unfortunately, Agios Nikolaos can not boast of such good beaches as some of the cities of Crete.
<G-vec00418-002-s219><boast.prahlen><de> Leider kann Agios Nikolaos nicht mit so guten Stränden wie einige der Städte von Kreta prahlen.
<G-vec00418-002-s246><boast.rühmen><en> 30 If I must boast, I will boast of the things that show my weakness.
<G-vec00418-002-s246><boast.rühmen><de> 30 Wenn denn gerühmt sein muss, will ich mich meiner Schwachheiten rühmen.
<G-vec00418-002-s247><boast.rühmen><en> [...] credit for the salvation of man was given, not to the one who was saved, but to the Lord Jesus Christ, the only Savior; that man could boast of nothing, that his works were but filthy rags, that eternal life could be received within the heart only as a free gift, that it was not a reward in exchange for merits that had been acquired but was an unmerited gift given by God to whosoever repents of his sins and receives Jesus Christ into neikung.de
<G-vec00418-002-s247><boast.rühmen><de> [...] sprachen und betonten, dass alle Ehre für die Errettung eines Menschen nicht dem Erretteten zusteht, sondern dem Herrn Jesus Christus, dem einzigen Retter, und dass der Mensch sich wegen nichts rühmen kann, auch dass seine Werke nichts als schmutzige Kleider sind; dass das ewige Leben im Herzen nur als ein freies Geschenk angenommen werden kann und nicht eine Belohnung für erworbene Verdienste ist, sondern ein unverdientes Geschenk, das Gott all denen gibt, die von ihren Sünden Busse tun und irgendwann einmal auszuprobieren, zu sagen, ok, wir haben eine Sendung und wir machen eine Einleitung und die nächsten 45 Minuten werden eine Schweigemeditation sein.
<G-vec00418-002-s248><boast.rühmen><en> Wonderful cliff on excellent limestone with paths that can boast even 5 rope lengths and a great variety of routes.
<G-vec00418-002-s248><boast.rühmen><de> Superb Klippe aus Kalkstein mit guten Wegen, die auch fünf Seillängen und eine Vielzahl von Routen rühmen können.
<G-vec00418-002-s249><boast.rühmen><en> I say again, let no man think me a fool; if otherwise, yet as a fool receive me, that I may boast myself a little.
<G-vec00418-002-s249><boast.rühmen><de> Wiederum sage ich: Niemand halte mich für töricht; wenn aber doch, so nehmt mich doch an als einen Törichten, damit auch ich mich ein wenig rühmen kann.
<G-vec00418-002-s250><boast.rühmen><en> The AX.25/NetRom/Rose support itself is quite significant, because no other operating system can boast standard native support for these protocols beside Linux.
<G-vec00418-002-s250><boast.rühmen><de> Damit war Linux das einzige System, das sich rühmen konnte, von Haus aus AX.25/NetRom zu unterstützen.
<G-vec00418-002-s251><boast.rühmen><en> 13 For those who are circumcised do not obey the law themselves, but they want you to be circumcised so that they can boast about your flesh.#tn Or “boast about you in external matters,” “in the outward rite” (cf. v. 12).
<G-vec00418-002-s251><boast.rühmen><de> 13Denn auch sie, die beschnitten sind, beobachten selbst das Gesetz nicht, sondern sie wollen, daß ihr beschnitten werdet, auf daß sie sich eures Fleisches rühmen.
<G-vec00418-002-s252><boast.rühmen><en> 1 Therefore having been justified on the principle of faith, we have peace towards °God through our Lord Jesus Christ; 2 by whom we have also access by faith into this favour in which we stand, and we boast in hope of the glory of °God.
<G-vec00418-002-s252><boast.rühmen><de> 1 Nun wir denn sind gerecht geworden durch den Glauben, so haben wir Frieden mit Gott durch unsern HERRN Jesus Christus, 2 durch welchen wir auch den Zugang haben im Glauben zu dieser Gnade, darin wir stehen, und rühmen uns der Hoffnung der zukünftigen Herrlichkeit, die Gott geben soll.
<G-vec00418-002-s253><boast.rühmen><en> And the king of Israel answered and said, Tell him, Let not him that girdeth on [his armor] boast himself as he that putteth it off.
<G-vec00418-002-s253><boast.rühmen><de> Aber der König Israels antwortete und sprach: Sagt: Der den Harnisch anlegt, soll sich nicht rühmen wie der, der ihn hat abgelegt.
<G-vec00418-002-s254><boast.rühmen><en> And only 7% of people who could boast of a high level of mental well-being, eat less than 1 portion of fresh plant products every day.
<G-vec00418-002-s254><boast.rühmen><de> Und nur 7% der Menschen, die sich eines hohen psychischen Wohlbefindens rühmen können, essen täglich weniger als 1 Portion frischer Pflanzenprodukte.
<G-vec00418-002-s255><boast.rühmen><en> For lovers of sweets, we offer cakes of own production, such as fritters, kroštule and other delicacies whose quality will boast every gourmand.
<G-vec00418-002-s255><boast.rühmen><de> Für die Liebhaber von Süßigkeiten, bieten wir Kuchen aus eigener Herstellung, wie Krapfen, Kroštule und andere Köstlichkeiten, deren Qualität wird jeden Feinschmecker rühmen.
<G-vec00418-002-s256><boast.rühmen><en> 61:6 But you shall be named the priests of Yahweh; men will call you the ministers of our God: you will eat the wealth of the nations, and you will boast in their glory.
<G-vec00418-002-s256><boast.rühmen><de> 61:6 Ihr aber sollt Priester des HERRN heißen, und man wird euch Diener unsers Gottes nennen; und werdet der Heiden Güter essen und über ihrer HERRLIchkeit euch rühmen.
<G-vec00418-002-s257><boast.rühmen><en> If, in fact, Abraham was justified by works, he had something to boast about--but not before God.
<G-vec00418-002-s257><boast.rühmen><de> Denn wenn Abraham aus Werken gerechtfertigt worden ist, so hat er etwas zum Rühmen, aber nicht vor Gott.
<G-vec00418-002-s258><boast.rühmen><en> 12 We are not commending ourselves to you again but giving you cause to boast about us, so that you may be able to answer those who boast about outward appearance and not about what is in the heart.
<G-vec00418-002-s258><boast.rühmen><de> 12 Denn wir empfehlen uns nicht nochmals selbst euch gegenüber, sondern wir geben euch Gelegenheit, euch unsretwegen zu rühmen, damit ihr es denen entgegenhalten könnt, die sich des Äußeren rühmen, aber nicht des Herzens.
<G-vec00418-002-s259><boast.rühmen><en> I say again, let no man think me a fool; if otherwise, yet as a fool receive me, that I may boast myself a little.
<G-vec00418-002-s259><boast.rühmen><de> Wiederum sage ich: Niemand halte mich für töricht; wenn aber nicht, so nehmet mich doch auf als einen Törichten, auf daß auch ich mich ein wenig rühmen möge.
<G-vec00418-002-s260><boast.rühmen><en> I say again, let no one think me a fool. If otherwise, at least receive me as a fool, that I also may boast a little.
<G-vec00418-002-s260><boast.rühmen><de> 16Ich sage abermals, niemand halte mich für töricht; wollt ihr aber doch, nun, so nehmet an, ich sei töricht, damit auch ich mich ein wenig rühmen möge.
<G-vec00418-002-s261><boast.rühmen><en> Puerto Pollensa and Alcudia boast sandy beaches and restaurants.
<G-vec00418-002-s261><boast.rühmen><de> Puerto Pollensa und Alcudia rühmen Sandstrände und Restaurants.
<G-vec00418-002-s262><boast.rühmen><en> Covering an area of 30000 square meters, we now have over 100 employees and boast an annual sales figure that exceeds USD2,000,000.
<G-vec00418-002-s262><boast.rühmen><de> Einen Bereich von 30000 Quadratmetern abdeckend, haben wir jetzt über 100 Angestellten und rühmen uns eine jährliche Verkaufszahl, die USD2,000,000 übersteigt.
<G-vec00418-002-s263><boast.rühmen><en> ' Many sports production cars have roots in racing, but the '12 Mustang Boss 302 is one of few that can boast such lineage on both sides of its family tree.
<G-vec00418-002-s263><boast.rühmen><de> ' Viele Sportwagen sind vom Rennsport inspiriert, doch der '12 Mustang Boss 302 ist einer der wenigen, der sich solcher Einflüsse von beiden Seiten seines Stammbaums rühmen kann.
<G-vec00418-002-s264><boast.rühmen><en> There are not many tourist destinations on a world scale which can boast such a felicitous ascent on the international scene of the elite sport which is most in vogue: golf.
<G-vec00418-002-s264><boast.rühmen><de> Es gibt nicht viele touristische Zielgebiete auf weltweiter Ebene, die sich eines derartig geglückten Aufstieges in der Szene der internationalen Trend-Elitesportarten rühmen können: das Golf.
<G-vec00418-002-s243><boast.sich_rühmen><en> 30 He is the source of your life in Christ Jesus, who became for us wisdom from God, and righteousness and sanctification and redemption, 31 in order that, as it is written, "Let the one who boasts, boast in the Lord."
<G-vec00418-002-s243><boast.sich_rühmen><de> 30Aus ihm aber habt ihr das Sein in Christus Jesus, der uns geworden ist Weisheit von Gott, Gerechtigkeit und Heiligung und Erlösung, 31damit es sei wie geschrieben steht: Wer sich rühmet, rühme sich des Herrn.
<G-vec00418-002-s244><boast.sich_rühmen><en> Er is er But, “Let the one who boasts boast in the Lord.”
<G-vec00418-002-s244><boast.sich_rühmen><de> »Wer sich aber rühmt, der rühme sich des Herrn«.
<G-vec00418-002-s245><boast.sich_rühmen><en> 30It is because of him that you are in Christ Jesus, who has become for us wisdom from God—that is, our righteousness, holiness and redemption. 31Therefore, as it is written: "Let the one who boasts boast in the Lord."
<G-vec00418-002-s245><boast.sich_rühmen><de> 30Aus ihm aber seid ihr in Christo Jesu, der uns geworden ist Weisheit von Gott und Gerechtigkeit und Heiligkeit und Erlösung; 31auf daß, wie geschrieben steht: "Wer sich rühmt, der rühme sich des Herrn".
