<G-vec00407-001-s022><append.anhängen><en> If no section title is found, the default is to append new entries to the end of the file.
<G-vec00407-001-s022><append.anhängen><de> Falls kein Abschnittstitel gefunden wird, ist die Voreinstellung, neue Einträge an das Ende der Datei anzuhängen.
<G-vec00407-001-s028><append.anfügen><en> Added the possibility to append date/time to the exported file name.
<G-vec00407-001-s028><append.anfügen><de> Hinzufügen der Möglichkeit zum Anfügen von Datum/Zeit zum exportierten Dateinamen.
<G-vec00407-001-s029><append.anfügen><en> Check Append to Existing (default) to append the hyphenation exceptions to an existing list.
<G-vec00407-001-s029><append.anfügen><de> Markieren Sie An Vorhandene anfügen (Standard), um die Trennausnahmen einer existierenden Liste hinzuzufügen.
<G-vec00407-001-s030><append.anfügen><en> New ransomware has been recently discovered by security researchers to append the .xcry7684 file extension on the computers of victims.
<G-vec00407-001-s030><append.anfügen><de> New Ransomware wurde von Sicherheitsexperten vor kurzem entdeckt, die anfügen .xcry7684 Dateierweiterung auf den Computern der Opfer.
<G-vec00407-001-s031><append.anfügen><en> • Append: When applying the same setting in more than one policy, you can append the settings with this rule.
<G-vec00407-001-s031><append.anfügen><de> • Anfügen: Wenn Sie dieselbe Einstellung in mehr als einer Policy anwenden, können Sie die Einstellungen mit dieser Regel anfügen.
<G-vec00407-001-s032><append.anfügen><en> • Append: When applying the same setting in more than one policy, you can append the settings with this rule.
<G-vec00407-001-s032><append.anfügen><de> • Anfügen: Wenn Sie dieselbe Einstellung in mehr als einer Policy anwenden, können Sie die Einstellungen mit dieser Regel anfügen.
<G-vec00407-001-s033><append.anfügen><en> Sidenote: You can append .rss to virtually any submission group on Reddit, not only domain submissions, to get a RSS Feed url right away that you can subscribe to in a feed reader of your choosing.
<G-vec00407-001-s033><append.anfügen><de> Nebenbei bemerkt: Sie können den anfügen .rss-nahezu alle Veröffentlichungen der Gruppe auf Reddit, nicht nur domain-Veröffentlichungen, um sich einen RSS-Feed-url sofort, dass Sie können, abonnieren Sie in einem feed-reader Ihrer Wahl.
<G-vec00407-001-s034><append.anfügen><en> A list of DNS suffixes to be appended for use in completing unqualified DNS names that are used for searching and submitting DNS queries at the client for resolution. For DHCP clients, this can be set on the DHCP server by assigning the DNS domain name option (option 15) and providing a single DNS suffix for the client to append and use in searches.
<G-vec00407-001-s034><append.anfügen><de> Eine Liste der DNS-Suffixe, die zur Vervollständigung von nicht qualifizierten DNS-Namen angefügt werden, die für die Suche und die Übermittlung von DNS-Abfragen auf dem Client für die Auflösung verwendet werden Für DHCP-Clients kann diese auf dem DHCP-Server durch Zuweisung der DNS-Domänennamenoption (Option 15) und Bereitstellung eines einzelnen DNS-Suffixes, das der Client anfügen und für Suchen verwenden kann, festgelegt werden.
<G-vec00407-001-s035><append.anfügen><en> To append the current location, it uses a Get-Location command, which runs when the prompt function is called.
<G-vec00407-001-s035><append.anfügen><de> "Zum Anfügen des aktuellen Speicherorts wird der Befehl ""Get-Location"" verwendet, der beim Aufrufen der prompt-Funktion ausgeführt wird."
<G-vec00407-001-s036><append.anfügen><en> The following article just append to, give thanks for the many good wishes, a lot of praise and encouraging words, which in recent months, I had.
<G-vec00407-001-s036><append.anfügen><de> Der folgende Artikel nur anfügen, danke für die vielen guten Wünsche, viel Lob und aufmunternde Worte, die in den letzten Monaten hatte ich.
<G-vec00407-001-s037><append.anfügen><en> Orphaned PST File – this option make it possible to select the existing PST file to append.
<G-vec00407-001-s037><append.anfügen><de> Verwaiste PST-Datei – dieser Möglichkeit Gebrauch machen es möglich, die vorhandenen PST-Datei auszuwählen anfügen.
<G-vec00407-001-s038><append.anfügen><en> Just like the “site:” operator, you can append a search after the colon.
<G-vec00407-001-s038><append.anfügen><de> Genau wie beim „site:“ – Operator, kannst Du einfach einen Suchbegriff nach dem Doppelpunkt anfügen.
<G-vec00407-001-s039><append.anfügen><en> append_domain <domain> With append_domain, specify which domain to append automatically when none is given.
<G-vec00407-001-s039><append.anfügen><de> append_domain <Domaene> Mit append_domain können Sie angeben, welche Domäne automatisch angefügt wird, wenn keine angegeben wurde.
<G-vec00407-001-s040><append.anfügen><en> append_domain DOMAIN Use append_domain to specify which domain to append automatically when none is given.
<G-vec00407-001-s040><append.anfügen><de> append_domain DOMÄNE Verwenden Sie append_domain, um anzugeben, welche Domäne automatisch angefügt wird, wenn keine angegeben wurde.
<G-vec00407-001-s041><append.anfügen><en> Use append_domain to specify which domain to append automatically when none is given.
<G-vec00407-001-s041><append.anfügen><de> Verwenden Sie append_domain, um anzugeben, welche Domäne automatisch angefügt wird, wenn keine angegeben wurde.
<G-vec00407-001-s043><append.anhängen><en> 1.2 Calculate age from given birth date or difference between two dates.TaskRun Week Planner 2015.3 Plan your week on a seven day calendar grid.Join Multiple RTF Files Into One Software 7.0 Vertically append many RTF files, save result as a new RTF file.Byte Converter 1.6 Convert numeric values between different digital information units.Target Sum Finder 1.0 Find solutions to hit target sum for a set of data.STIMS Buffer 1.0 Calculate recipes for biological buffers.Free Jetico Scientific Calculator 1.0 Perform scientific, engineering, and mathematical calculations.Rupees to Words Finder 1.0 Convert Indian Rupees or US Dollars numerals to words.1833 programs in this category / 92 pages.1...
<G-vec00407-001-s043><append.anhängen><de> 9.0 Erstellen und Textdokumente bearbeiten.Age Date Diff Calculator 1.2 Berechnen Alter von bestimmten Geburtsdatum oder Differenz zwischen zwei Daten.TaskRun Week Planner 2015.3 Planen Sie Ihre Woche auf einer 7 Tage Kalender Raster.Join Multiple RTF Files Into One Software 7.0 Vertikal angehängt viele RTF-Dateien, speichern Ergebnis als neue RTF-Datei.Byte Converter 1.6 Konvertieren numerische Werte zwischen verschiedenen digitalen Informationseinheiten.Target Sum Finder 1.0 Lösungen zu finden, um die Zielsumme für eine Menge von Daten zu treffen.STIMS Buffer 1.0 Berechnen Sie Rezepte für biologische Puffer.Free Jetico Scientific Calculator 1.0 Führen wissenschaftliche, technische und mathematische Berechnungen.Rupees to Words Finder 1.0 Konvertieren Indische Rupien oder US-Dollar Zahlen, Worte.1833 Programme in dieser Kategorie / 92 Seiten.1...
<G-vec00407-001-s044><append.anhängen><en> "We found three bonus tracks from long out-of-print albums to append to the original album to make this The Complete Coral Christmas Recordings: ""Be a Santa"" comes from the album The McGuire Sisters Sing ""Subways Are for Sleeping,"" ""Peace"" is from May You Always, and ""Ave Maria"" comes from In Harmony with Him."
<G-vec00407-001-s044><append.anhängen><de> "Wir haben drei Bonustracks von langen vergriffenen Alben gefunden, die an das Originalalbum angehängt wurden, um diese The Complete Coral Christmas Recordings zu machen: ""Be a Santa"" kommt aus dem Album The McGuire Sisters Sing ""Subways Are for Sleeping"", ""Peace"" ist von May You Always und ""Ave Maria"" kommt von In Harmony with Him."
<G-vec00407-001-s045><append.anhängen><en> Most commonly, you will probably use the append (-A) and delete (-D) commands.
<G-vec00407-001-s045><append.anhängen><de> Meistens wirst Du vermutlich den Befehl zum Anhaengen (-A) oder Loeschen (-D) einer Regel verwenden.
<G-vec00407-001-s047><append.anhängen><en> If you select Use List of Values, you can insert, append, edit, and delete any number of entries for the drop-down list of the combo box as well as for the corresponding XML values.
<G-vec00407-001-s047><append.anhängen><de> "Bei Auswahl der Option "" Werteliste verwenden "" können Sie beliebig viele Einträge für die Dropdown-Liste der Auswahlliste sowie für die zugehörigen XML-Werte einfügen, anhängen, bearbeiten und löschen."
<G-vec00407-001-s048><append.anhängen><en> -a Append output to existing binary file.
<G-vec00407-001-s048><append.anhängen><de> -a Ausgabe an vorhandene Binärdatei anhängen.
<G-vec00407-001-s049><append.anhängen><en> 0 means append; 1 means don't append.
<G-vec00407-001-s049><append.anhängen><de> 0 bedeutet anhängen, 1 bedeutet nicht anhängen.
<G-vec00407-001-s050><append.anhängen><en> 0 means append; 1 means don't append.
<G-vec00407-001-s050><append.anhängen><de> 0 bedeutet anhängen, 1 bedeutet nicht anhängen.
<G-vec00407-001-s051><append.anhängen><en> When you load a CSV or fixed length (FLF) flat file into a MapForce data mapping design, you can append, insert, and remove fields as well as change field header names and values as required before importing the file.
<G-vec00407-001-s051><append.anhängen><de> Wenn Sie eine CSV- oder FLF (fixed length)-Datei in ein Mapforce Datenmapping laden, können Sie Felder anhängen, einfügen und entfernen und vor dem Import der Datei die Namen der Feldüberschriften sowie die Werte bei Bedarf ändern.
<G-vec00407-001-s052><append.anhängen><en> If a certificate is specified, the certificate's key information can be saved with the signature by checking the Append Keyinfo checkbox (at the bottom of the XML Signature Settings dialog); this obviates the need for the Authentic View user to specify a certificate during verification.
<G-vec00407-001-s052><append.anhängen><de> "Wird ein Zertifikat definiert, so können die Schlüsselinformationen des Zertifikats durch Aktivieren des Kontrollkästchens Keyinfo anhängen (am unteren Rend des Dialogfelds ""Signatureinstellungen"") mit der Signatur gespeichert werden; dadurch muss der Benutzer der Authentic-Ansicht kein Zertifikat bei der Überprüfung angeben."
<G-vec00407-001-s053><append.anhängen><en> After getting your computer infected by the Marlboro .oops threat, the virus begins to append XOR encryption mode to render the important files on the compromised computer no longer openable.
<G-vec00407-001-s053><append.anhängen><de> Nachdem sie durch den Marlboro infiziert Ihren Computer .oops Bedrohung, das Virus beginnt XOR-Verschlüsselungsmodus anhängen, die wichtigen Dateien auf dem infizierten Computer zu machen, nicht mehr geöffnet werden kann,.
<G-vec00407-001-s054><append.anhängen><en> Click Append Field several times to create seven CSV fields.
<G-vec00407-001-s054><append.anhängen><de> Klicken Sie mehrmals auf Feld anhängen, um sieben CSV-Felder zu erstellen.
<G-vec00407-001-s055><append.anhängen><en> Cerber 4.1.4 uses the computer’s MachineGuid value to append a new extension, so you may expect a file named ‘picture.img’ to become ‘picture.img.k8d1’.
<G-vec00407-001-s055><append.anhängen><de> Cerber 4.1.4 nutzt die MachineGuid Wert des Computers eine neue Erweiterung anhängen, so können Sie eine Datei erwarten namens ‚picture.img’ zu werden ‚picture.img.k8d1‘.
<G-vec00407-001-s056><append.anhängen><en> And if we append .xml to the URL we'll get the XML response.
<G-vec00407-001-s056><append.anhängen><de> Und wenn wir .xml an die URL anhängen, bekommen wir die XML-Antwort.
<G-vec00407-001-s057><append.anhängen><en> If you for instance want to lock down a Docker container to the first CPU core, you'd append --cpuset-cpus=0 to your docker run command.
<G-vec00407-001-s057><append.anhängen><de> Wenn Sie beispielsweise einen Docker-Container auf dem ersten CPU-Kern sperren möchten, müssen Sie --cpuset-cpus=0 an Ihren Docker-Startbefehl docker run anhängen.
<G-vec00407-001-s058><append.anhängen><en> When you hover the mouse cursor over a highlighted area an Append button also display highlighted area of the pane.
<G-vec00407-001-s058><append.anhängen><de> Wenn Sie den Mauszeiger über einen markierten Bereich halten wird der Schalter Anhängen auch im markierten Bereich des Fensters angezeigt.
<G-vec00407-001-s059><append.anhängen><en> To resolve an unqualified name by appending the suffixes from a list of configured suffixes, click Append these DNS suffixes (in order), and then click Add to add suffixes to the list.
<G-vec00407-001-s059><append.anhängen><de> Um einen unvollständigen Namen durch das Anhängen von Suffixen aus einer Liste konfigurierter Suffixe aufzulösen, klicken Sie auf Diese DNS-Suffixe anhängen (in Reihenfolge) und dann auf Hinzufügen, um Suffixe der Liste hinzuzufügen.
<G-vec00407-001-s060><append.anhängen><en> Options are the same as mentioned above: Replace, Append, Prepend .
<G-vec00407-001-s060><append.anhängen><de> Die Optionen sind dieselben wie oben beschrieben: ersetzen, anhängen, voranstellen .
<G-vec00407-001-s061><append.anhängen><en> In order to simplify the evaluation, select Measurement → Append new Measurement Series before measuring the conductivity of a new substance.
<G-vec00407-001-s061><append.anhängen><de> Zur einfacheren Auswertung vor Beginn der Leitfähigkeitsmessung mit einem neuen Stoff Messung → Neue Messreihe anhängen auswählen.
<G-vec00407-001-s062><append.anhängen><en> The Insert Node(s) and Append Node(s) actions have an option to remove the inserted/appended node/s from their original locations in a project's page sources.
<G-vec00407-001-s062><append.anhängen><de> Die Aktionen Node(s) einfügen und Node(s) anhängen verfügen über eine Option, um den/die eingefügten/angehängten Node(s) von der ursprünglichen Stelle in den Projektseitenquellen zu entfernen.
<G-vec00407-001-s063><append.anhängen><en> The molecular probe developed by the HZI researchers is based on a siderophore conjugate to which they can append functional units.
<G-vec00407-001-s063><append.anhängen><de> Die von den HZI-Forschern entwickelte molekulare Sonde basiert auf einem Siderophor-Konjugat, an welche sie funktionelle Einheiten anhängen können.
<G-vec00407-001-s064><append.anhängen><en> You have to use A Quickscanner's Paper as a starting point and append a good quickscanner.
<G-vec00407-001-s064><append.anhängen><de> Du mußt A Quickscanner's Paper als Ausgangspunkt benutzen und einen möglist guten Quickscanner anhängen.
<G-vec00407-001-s065><append.anhängen><en> "Move the mouse pointer approximately into the vicinity of the way point desired, click the right mouse button (for Mac: option key and the mouse button), and choose ""Insert"" or ""Append""."
<G-vec00407-001-s065><append.anhängen><de> "Schieben Sie den Mauszeiger ungefähr in die Nähe des gewünschten Wegpunktes, drücken Sie die rechte Maustaste (beim Mac: Wahltaste und Maustaste) und wählen Sie ""Einfügen"" oder ""Anhängen""."
<G-vec00407-001-s066><append.anhängen><en> Click the Append or Insert icons (located in the pane's toolbar) to add a line to the list.
<G-vec00407-001-s066><append.anhängen><de> Klicken Sie (in der Symbolleiste des Fensters) auf das Anhängen oder Einfügen -Symbol, um eine Zeile zur Liste hinzuzufügen.
<G-vec00407-001-s067><append.anhängen><en> If you choose the Append option, the item you have selected lately will be added to the end of the cell value;
<G-vec00407-001-s067><append.anhängen><de> Wenn Sie die Anhängen Wenn Sie diese Option wählen, wird das zuletzt ausgewählte Element an das Ende des Zellenwerts angehängt.
<G-vec00407-001-s068><append.anhängen><en> Click the Append AND or Append OR button.
<G-vec00407-001-s068><append.anhängen><de> Klicken Sie auf eine der Schaltflächen AND anhängen oder OR anhängen .
<G-vec00407-001-s069><append.anhängen><en> Furthermore, the table below the chart allows new trading data to be entered for the two companies (right-click in a row and append or insert a Day element).
<G-vec00407-001-s069><append.anhängen><de> Zusätzlich dazu können Sie (durch Rechtsklick in eine Zeile und Anhängen oder Einfügen eines Day -Elements) in der Tabelle unterhalb des Diagramms neue Kursdaten für die beiden Unternehmen eingeben.
<G-vec00407-001-s072><append.anhängen><en> For component lists, the dialog additionally delivers the possibility to prepend or append the components of the source document.
<G-vec00407-001-s072><append.anhängen><de> Bei Komponentenlisten besteht neben dem vollständigen Ersetzen der enthaltenen Komponenten auch die Möglichkeit, die Komponenten des Quelldokuments an die Komponentenliste des Zieldokuments voranzustellen oder anzuhängen.
<G-vec00407-001-s073><append.anhängen><en> Ability to add, append, and delete any WSDL element visible in the graphical view (context sensitive menu).
<G-vec00407-001-s073><append.anhängen><de> Die Möglichkeit, WSDL-Elemente, die in der grafischen Ansicht zu sehen sind, hinzuzufügen, anzuhängen und zu löschen (kontextsensitives Menü).
<G-vec00407-001-s074><append.anhängen><en> You can use formula to append text from one cell to another as follows.
<G-vec00407-001-s074><append.anhängen><de> Sie können Formeln verwenden, um Text von einer Zelle an eine andere wie folgt anzuhängen.
<G-vec00407-001-s097><append.beifügen><en> Please do not forget to append them to your contracts.
<G-vec00407-001-s097><append.beifügen><de> Vergessen Sie bitte nicht, diese Ihren Verträgen beizufügen.
<G-vec00407-001-s098><append.d.h._erweitern><en> As each valid query you make during a session is saved in the History you can manipulate (append, replace or delete) previous queries.
<G-vec00407-001-s098><append.d.h._erweitern><de> Da während der gesamten Sitzung jede Ihrer gültigen Abfragen in der Historie gespeichert wird, können Sie Ihre früheren Abfragen bearbeiten, d.h. erweitern, ersetzen oder löschen.
<G-vec00407-001-s099><append.hinzufügen><en> Nancy’s list of the various names under which this problem can be recognized should be taken seriously, not only because “art is only one element of a series in it; we should also append the name “critique to this list, especially in the sense of the practical critique articulated by Marx or Benjamin, for example.
<G-vec00407-001-s099><append.hinzufügen><de> Wir sollten Nancys Aufzählung der verschiedenen Namen, unter denen sich diese Problematik zu erkennen gibt, nicht nur dahingehend ernst nehmen, dass die Kunst“ sich in ihr nur als ein Element einer Serie darstellt; wir sollten dieser Aufzählung auch den Namen Kritik“ hinzufügen, insbesondere im Sinne jener praktischen Kritik, die sich beispielsweise bei Marx oder Benjamin artikuliert findet.
<G-vec00407-001-s100><append.datenbank-menü_erweitern><en> You can now append and alter both data bases in the data base menu.
<G-vec00407-001-s100><append.datenbank-menü_erweitern><de> Im Datenbank-Menü können Sie nun beide Datenbanken erweitern und verändern.
<G-vec00407-001-s102><append.anhängen><en> Your autoresponder software must append the GET parameter to the thank you page URL.
<G-vec00407-001-s102><append.anhängen><de> Ihre Autoresponder-Software muss dazu den GET-Parameter an die Danke-Seite-Url anhängen.
<G-vec00407-001-s104><append.ergänzen><en> FED1+ contains a database with spring manufacturer catalogues, which you can append with your own springs.
<G-vec00407-001-s104><append.ergänzen><de> Federdatenbank FED1+ enthält eine Datenbank mit Katalogen von Federherstellern, die Sie mit eigenen Federn ergänzen können.
<G-vec00407-001-s105><append.erweitern><en> Append additional matrices (channels) to the image.
<G-vec00407-001-s105><append.erweitern><de> Erweitern des Bildes um zusätzliche Matrizen (Kanäle).
<G-vec00407-001-s106><append.erweitern><en> Append new records of the update database to your current dbf files.
<G-vec00407-001-s106><append.erweitern><de> Die bisherigen dbf-Dateien mit eigenen Datensätzen um die neuen Datensätze vom Update erweitern.
<G-vec00407-001-s107><append.erweitern><en> In many ways a tuple is like a list, but with the significant difference that tuples are immutable which is to say that you canít change them nor append to them once created.
<G-vec00407-001-s107><append.erweitern><de> In vielen Fällen ist ein Tuple wie eine Liste, aber mit dem signifikanten Unterschied, dass Tuples unveränderlich sind; was bedeutet, dass du sie weder verändern noch erweitern kannst, sobald sie einmal erzeugt sind.
<G-vec00407-001-s125><append.anhängen><en> One way to do that would be to open the file for input, read the data into a list, append the data to the list and then write the whole list out to a new version of the old file.
<G-vec00407-001-s125><append.anhängen><de> Eine Art, dies zu tun, ist das File für die Eingabe zu öffnen, Lesen der Daten in eine Liste hinein, die Daten an die Liste anhängen und dann die ganze Liste rausschreiben auf eine neue Version der alten Datei.
<G-vec00407-001-s126><append.hinzufügen><en> This is the second comment which, with your permission, Mihály, I would like to append to your presentation.
<G-vec00407-001-s126><append.hinzufügen><de> Dies ist die zweite Bemerkung, die ich, wenn Du erlaubst, Mihály, Deinem Vortrag hinzufügen wollte.
<G-vec00407-001-s127><append.hinzufügen><en> Do this by right-clicking nodes in the tree (starting with $XML1) and using the Add Child, Append, and Insert context menu commands.
<G-vec00407-001-s127><append.hinzufügen><de> Klicken Sie dazu mit der rechten Maustaste auf Nodes in der Struktur (beginnend mit $XML1) und verwenden Sie die Kontextmenübefehle Child hinzufügen, und Einfügen .
<G-vec00407-001-s128><append.hinzufügen><en> If <verbose_file> exists, IBEScript will append message to this file.
<G-vec00407-001-s128><append.hinzufügen><de> Wenn <verbose_file> bereits existiert, wird IBEScript die Nachricht in diese Datei hinzufügen.
<G-vec00407-001-s129><append.hinzufügen><en> If we are to understand this claim correctly, we must once more append the information that the reference to a “period” implies the fulfillment - in addition, and in particular - of all the Old Testament prophecies.
<G-vec00407-001-s129><append.hinzufügen><de> Zum richtigen Verständnis dieser Aussage muss man wieder hinzufügen: wenn hier von „Abschluss” die Rede ist, ist damit auch und insbesondere die Erfüllung aller alttestamentlichen Prophezeiungen gemeint.
<G-vec00407-001-s130><append.hinzufügen><en> The Auto Append dialog.
<G-vec00407-001-s130><append.hinzufügen><de> Der Dialog Automatisch hinzufügen.
<G-vec00407-001-s131><append.hinzufügen><en> "[2222] Added HTML support in CF ""Append a corporate signature"" action."
<G-vec00407-001-s131><append.hinzufügen><de> [2222] Die Aktion des Inhaltsfilters zum Hinzufügen von Signaturen unterstützt jetzt HTML-Kode.
<G-vec00407-001-s132><append.hinzufügen><en> On SGI machines you can append boot parameters to the bootp(): command in the command monitor.
<G-vec00407-001-s132><append.hinzufügen><de> Bei SGI-Maschinen können Sie Boot-Parameter zum bootp(): -Befehl im Kommandomonitor hinzufügen.
<G-vec00407-001-s133><append.hinzufügen><en> Append document data - To merge any number of documents into a single new file, keeping the original file structure of each file.
<G-vec00407-001-s133><append.hinzufügen><de> Hinzufügen von Dokumentendaten – führt eine beliebige Anzahl von Dokumenten in eine einzige, neue Datei zusammen, wobei die ursprüngliche Dateistruktur jeder Datei erhalten bleibt.
<G-vec00407-001-s134><append.hinzufügen><en> Specify that Append/Delete controls are added automatically to the rendered table (only in repeating tables and tables with dynamic rows).
<G-vec00407-001-s134><append.hinzufügen><de> Sie können definieren, dass automatisch Hinzufügen/Entfernen-Schaltflächen zur dargestellten Tabelle hinzugefügt werden (nur in sich wiederholenden Tabellen und in Tabellen mit dynamischen Zeilen).
<G-vec00407-001-s135><append.hinzufügen><en> The Append User dialog will appear.
<G-vec00407-001-s135><append.hinzufügen><de> Der hinzugefügte Benutzer wird in der Liste erscheinen.
<G-vec00407-001-s136><append.hinzufügen><en> For this reason, there would also be little use in starting from the aforementioned and other names of the existing canonizations to append yet another one denoting a certain “tendency in art history (histories).
<G-vec00407-001-s136><append.hinzufügen><de> Es wäre daher auch wenig damit gewonnen, ausgehend von den genannten und anderen Namen den bestehenden Kanonisierungen eine weitere hinzuzufügen, die eine bestimmte Strömung“ der Kunstgeschichte(n) festhält.
<G-vec00407-001-s137><append.hinzufügen><en> Check Append to Existing (default) to append the hyphenation exceptions to an existing list.
<G-vec00407-001-s137><append.hinzufügen><de> Markieren Sie An Vorhandene anfügen (Standard), um die Trennausnahmen einer existierenden Liste hinzuzufügen.
<G-vec00407-001-s138><append.hinzufügen><en> Can I export the mailbox into an existing PST file? Yes, Stellar Converter for MBOX allows you to append the converted mailbox into an existing PST file.
<G-vec00407-001-s138><append.hinzufügen><de> Ja, Stellar Converter for MBOX ermöglicht es Ihnen die konvertierten Postfächer zu einer existierenden PST Datei hinzuzufügen.
<G-vec00407-001-s139><append.hinzufügen><en> Share To add an article, image, or category to this category, append [[Category:Category]] to the end of its page.
<G-vec00407-001-s139><append.hinzufügen><de> Um einen Artikel, ein Bild oder eine Kategorie zu dieser Kategorie hinzuzufügen, füge [[Kategorie:Kategorie]] am Ende der Seite ein.
<G-vec00407-001-s152><append.anfügen><en> At this point, you can write the results to a file and then append the newly received results as they arrive.
<G-vec00407-001-s152><append.anfügen><de> Zu diesem Zeitpunkt können Sie die Ergebnisse in eine Datei schreiben und die später empfangenen Ergebnisse dann jeweils anfügen.
<G-vec00407-001-s154><append.anhängen><en> In order to make these additional parameters appear in the path info part, we should append /* to the rule.
<G-vec00407-001-s154><append.anhängen><de> Um diese zusätzlichen Parameter in der Pfadangabe erscheinen zu lassen, kann man /* an eine Regel anhängen.
<G-vec00407-001-s155><append.erweitern><en> SCP-3355 is usually active year-round, occasionally rebooting to clear its limited memory and to append its operating system with updated protocols.
<G-vec00407-001-s155><append.erweitern><de> Üblicherweise ist SCP-3355 das ganze Jahr über aktiv, gelegentlich startet es sich neu, um seinen begrenzten Arbeitsspeicher zu leeren und sein Betriebssystem mit aktualisierten Protokollen zu erweitern.
<G-vec00407-001-s156><append.anhängen><en> If a password has not been set, the Oracle listener program can be configured to append log information to a file.
<G-vec00407-001-s156><append.anhängen><de> Die Folge ist, dass das Oracle Listener Programm auch so konfiguriert werden kann, Loginformationen an eine Datei anzuhängen.
<G-vec00407-001-s157><append.anhängen><en> "- Contents in Multiple line of text column with ""Append Changes to Existing Text"" enabled cannot be saved in some situations."
<G-vec00407-001-s157><append.anhängen><de> "- Inhalte in Multizeilen einer Textspalte mit "" Änderungen an vorhandenen Text anhängen"" aktiviert, kann in bestimmten Situationen nicht gespeichert werden."
<G-vec00407-001-s167><append.anfügen><en> To append the warnings to the variable content, instead of replacing any warnings that might already be stored there, type a plus sign (+) before the variable name.
<G-vec00407-001-s167><append.anfügen><de> Wenn Sie die Warnungen an den Variableninhalt anfügen möchten, anstatt bereits dort gespeicherte Warnungen zu ersetzen, geben Sie vor dem Variablennamen ein Pluszeichen (+) ein.
<G-vec00407-001-s171><append.hinzufügen><en> To append Resources from a project file or from a Job Jackets file, choose Other, and then click Select and navigate to the target file.
<G-vec00407-001-s171><append.hinzufügen><de> Wenn Sie Ressourcen aus einer Projektdatei oder aus einer Job Jackets Datei hinzufügen möchten, klicken Sie auf Andere Datei, dann auf Auswählen und navigieren anschließend zur Zieldatei.
<G-vec00407-001-s173><append.anhängen><en> Ability to remove, append and add records to banned list.
<G-vec00407-001-s173><append.anhängen><de> Fähigkeit, umzuziehen, um anzuhängen und Aufzeichnungen zur verbotenen Liste hinzuzufügen.
<G-vec00407-001-s174><append.anfügen><en> "The following options are available. Append data (insert): When this option is checked the data is added with an ""insert"" into the temporary InMemory table."
<G-vec00407-001-s174><append.anfügen><de> "Es stehen folgende Optionen zur Verfügung.Daten anfügen (Insert): Ist diese Option aktiv werden die Daten an die ""temporäre"" InMemory Tabelle angefügt."
<G-vec00407-001-s175><append.anfügen><en> "To have the bumper automatically included in new projects, turn on the option ""Append Video Bumper."""
<G-vec00407-001-s175><append.anfügen><de> "Damit der Bumper automatisch in neue Projekte eingefügt wird, aktivieren Sie die Option ""Video-Bumper anfügen""."
<G-vec00407-001-s180><append.anhängen><en> If Yes, the selected regions append to the previously edited regions.
<G-vec00407-001-s180><append.anhängen><de> Falls Ja, werden die ausgewählten Regionen an die vorher bearbeiteten Regionen angehängt.
<G-vec00407-001-s181><append.anhängen><en> If the client accepts cookies: does not append information
<G-vec00407-001-s181><append.anhängen><de> Der Client akzeptiert Cookies: Es werden keine Informationen angehängt.
<G-vec00407-001-s182><append.anhängen><en> Turn on automatic logging, i.e. append logs of all games to filename (- means stdout).
<G-vec00407-001-s182><append.anhängen><de> Schalte automatische Protokollierung ein, d.h. Protokolle aller Spiele werden an die Datei (- bedeutet Standard-Ausgabe) angehängt.
