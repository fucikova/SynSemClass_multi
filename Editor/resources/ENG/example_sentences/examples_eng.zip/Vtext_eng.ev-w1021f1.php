<EnglishT-wsj_0578-s5#EnglishT-wsj_0578-s5-t8><ev-w1021f1.v-w5655f1> That's where the two scripts <start_vauxs>would<end_vauxs> <start_vs>diverge<end_vs> . 
