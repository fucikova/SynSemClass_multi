<G-vec00097-001-s038><arrive.ankommen><en> Of course, you can help (grandchild), to arrive and to transcend shock energies from her last transition.
<G-vec00097-001-s038><arrive.ankommen><de> Natürlich kannst du (Enkel) helfen, gerne angekommen zu sein und die Schockenergien von ihrem letzten Übergang zu transzendieren.
<G-vec00097-001-s039><arrive.ankommen><en> After a while, the priest gave Li Linfu a bamboo pole and said: “Ride on the pole. It will stop when we arrive at the destination.
<G-vec00097-001-s039><arrive.ankommen><de> Nach einer Weile gab der Weise Li Linfu einen Bambusstab und sagte: „Reite weiter auf dem Stab, er hält an wenn wir am Bestimmungsort angekommen sind.
<G-vec00097-001-s040><arrive.ankommen><en> Once there, getting around is quick and easy thanks to the Mass Rapid Transit metro system which services all main parts of the city. When you first arrive in the city and are not sure of directions, a taxi is a good option for getting around, and they are good value too.
<G-vec00097-001-s040><arrive.ankommen><de> Einmal dort angekommen findet man sich schnell und leicht in der Stadt zurecht, denn die öffentlichen Verkehrsmittel, vor allem die U-Bahnen des sogenannten Maß Rapid Transit, bringen Touristen schnell und verlässlich in die anderen Teile der Stadt.
<G-vec00097-001-s041><arrive.ankommen><en> I didn’t arrive in Basel yet, when I had decided that I’d definitively got to go to this showcase.
<G-vec00097-001-s041><arrive.ankommen><de> Ich war noch nicht in Basel angekommen, als ich mich entschied, dass ich definitiv an dieses Showcase gehen musste.
<G-vec00097-001-s042><arrive.ankommen><en> "Once you arrive to Ponte Milvio (Olympic Stadium) continue along side the river side until you reach the stop light in ""Piazza della cinque giornate""."
<G-vec00097-001-s042><arrive.ankommen><de> An der Brücke Ponte Milvio (Olympiastadium) angekommen, fahren Sie weiter bis zum Lungotevere, wobei Sie bis zur Ampel der Piazza delle Cinque Giornate direkt am Fluss entlangfahren.
<G-vec00097-001-s043><arrive.ankommen><en> As the long awaited winter holidays arrive, Christmas spirit builds up.
<G-vec00097-001-s043><arrive.ankommen><de> Die lang erwartete Winterurlaub angekommen, baut Weihnachtsstimmung.
<G-vec00097-001-s044><arrive.ankommen><en> If your order does not arrive within 30 business days or arrives damaged in any way, we guarantee to give you a free reshipment, just Contact us so that we may reship.
<G-vec00097-001-s044><arrive.ankommen><de> Im Falle wenn Ihre Bestellung innerhalb von 30 Werktagen nicht angekommen ist oder in irgendeiner Form beschädigt angekommen ist, garantieren wir Ihnen eine kostenlose Rücksendung, setzen Sie nur mit uns in Verbindung (Kontakt), damit wir Ihre Bestellung wieder versenden können.
<G-vec00097-001-s045><arrive.ankommen><en> "When you arrive to the main coast street you will see the sign “Essaouira""."
<G-vec00097-001-s045><arrive.ankommen><de> "Wenn du an der Hauptküstenstrasse angekommen siehst du schon den Wegweiser “Essaouira""."
<G-vec00097-001-s046><arrive.ankommen><en> Yet after you arrive, your friends back home receive word that you're not being used of God at all.
<G-vec00097-001-s046><arrive.ankommen><de> Kurz nachdem du angekommen bist, erhalten deine Freunde zu Hause die Nachricht, daß du überhaupt nicht von Gott gebraucht wirst.
<G-vec00097-001-s047><arrive.ankommen><en> X arrive you have to travel 1km of dirt road that can lead you back... but do not do it... continue towards the goal and you will be rewarded by the delicious food and unforgettable scenery.
<G-vec00097-001-s047><arrive.ankommen><de> X angekommen, müssen Sie 1 km Feldweg zurücklegen, der Sie zurückführen kann... aber tun Sie es nicht... fahren Sie weiter zum Ziel und Sie werden mit dem köstlichen Essen und der unvergesslichen Landschaft belohnt.
<G-vec00097-001-s048><arrive.ankommen><en> Once you arrive at the Clock Tower, the imposing structure invites you to discover it.
<G-vec00097-001-s048><arrive.ankommen><de> Wenn Sie am Uhrturm angekommen sind, lädt Sie die imposante Struktur ein, sie zu entdecken.
<G-vec00097-001-s049><arrive.ankommen><en> »For the honorary doctorate in Almaty the papers proving when the recipient met the dissidents didn't arrive in time.
<G-vec00097-001-s049><arrive.ankommen><de> »Zu dem Ehrendoktorat in Almata sind Nachweispapiere nicht angekommen, wann der Beehrte die Dissidenten getroffen hat.
<G-vec00097-001-s050><arrive.ankommen><en> When you arrive in Essaouira you take the coast street with the ocean on your left side. Follow this road till you see the Club Mistral and Skyriders Center.
<G-vec00097-001-s050><arrive.ankommen><de> Wenn du in Essaouira angekommen bist, fährst du die Küstenstrasse entlang, das Meer auf deiner linken Seite und folgst der Straße bis du das Club Mistral und Skyriders Center linker Hand siehst.
<G-vec00097-001-s051><arrive.ankommen><en> We didn’t even quite arrive in Mohacs yet, when they already organized a way to transport our bicycles.
<G-vec00097-001-s051><arrive.ankommen><de> Wir waren noch nicht einmal richtig in Mohacs angekommen, da wurde bereits eine Transportmöglichkeit für unsere Fahrräder organisiert.
<G-vec00097-001-s052><arrive.ankommen><en> As soon as you arrive, you will know you are in tropical paradise unique to Andalucia.
<G-vec00097-001-s052><arrive.ankommen><de> Sobald Sie hier angekommen sind, wissen Sie, dass Sie sich in einem tropischen Paradies befinden – einzigartig für Andalusien.
<G-vec00097-001-s053><arrive.ankommen><en> Should the customer not arrive at the booked accommodation unit before midnight on the arrival date, and the customer has not informed Tourist agency PUNTARKA NOVA or the host, the reservation is considered to be cancelled, and therefore the cancellation costs will be charged as described above.
<G-vec00097-001-s053><arrive.ankommen><de> Sollte der Gast ohne Rücksprache mit Reisebüro PUNTARKA NOVA oder dem Anbieter der Dienstleistung am Tag des Nutzungsbeginns bei der gebuchten Unterkunft bis Mitternacht nicht angekommen sein, gilt die Buchung als gekündigt.
<G-vec00097-001-s054><arrive.ankommen><en> Luckily, she and her friend survive and they arrive to their destination.
<G-vec00097-001-s054><arrive.ankommen><de> Sie und ihre Freunde haben überlebt und sie sind an ihrem Zielort angekommen.
<G-vec00097-001-s055><arrive.ankommen><en> It is still early in the afternoon as we arrive at the campsite.
<G-vec00097-001-s055><arrive.ankommen><de> Dort angekommen ist es noch früh am Nachmittag.
<G-vec00097-001-s056><arrive.ankommen><en> Once you arrive, stroll along the promenade with an ice cream or jump aboard the ferry and take the short crossing to the Isle of Cumbrae .
<G-vec00097-001-s056><arrive.ankommen><de> Sobald Sie angekommen sind, können Sie mit einem Eis in der Hand an der Promenade entlang spazieren, oder an Bord einer Fähre gehen und die kurze Überfahrt zur Insel Cumbrae machen.
<G-vec00097-001-s057><arrive.ankommen><en> We are located only 3 blocks from the train station where you will arrive.
<G-vec00097-001-s057><arrive.ankommen><de> Wir sind nur 3 Blocks vom Bahnhof entfernt, wo Sie ankommen werden entfernt.
<G-vec00097-001-s058><arrive.ankommen><en> Nevertheless, this particular factor is difficult to measure as also the individual skin layer would have to be determined in which the active agent is supposed to arrive in order to trigger the desired effects.
<G-vec00097-001-s058><arrive.ankommen><de> Sie ist allerdings eine schwierig zu messende Größe, da jeweils zu definieren wäre, in welcher Hautschicht der Wirkstoff ankommen muss, um die gewünschten Effekte auszulösen.
<G-vec00097-001-s059><arrive.ankommen><en> Your Rize flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s059><arrive.ankommen><de> Ihre Rize Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s060><arrive.ankommen><en> Your Dasarahalli flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s060><arrive.ankommen><de> Ihre Dasarahalli Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s061><arrive.ankommen><en> When you arrive, please request a map/guide that has 3 itineraries and fun facts.
<G-vec00097-001-s061><arrive.ankommen><de> Wenn Sie ankommen, fordern Sie bitte eine Karte / einen Führer mit 3 Reiserouten und amüsanten Fakten an.
<G-vec00097-001-s062><arrive.ankommen><en> Your Kukatpalle flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s062><arrive.ankommen><de> Ihre Kukatpalle Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s063><arrive.ankommen><en> If you arrive by train to Burgas then you have to get on the bus to Sozopol.
<G-vec00097-001-s063><arrive.ankommen><de> Wenn Sie mit Zug bis Burgas ankommen, müssen Sie in den Bus bis Sozopol einsteigen.
<G-vec00097-001-s064><arrive.ankommen><en> If you arrive earlier, please book a hotel/hostel room for the first nights.
<G-vec00097-001-s064><arrive.ankommen><de> Wenn Sie früher ankommen, bitte verbringen Sie die ersten Nächte in einem Hotel oder einer Jugendherberge.
<G-vec00097-001-s065><arrive.ankommen><en> If you get on at Yawatahama, it will take just over two hours to arrive at Matsuyama.
<G-vec00097-001-s065><arrive.ankommen><de> Wenn Sie in Yawatahama einsteigen, dauert es etwas mehr als zwei Stunden, bis Sie in Matsuyama ankommen.
<G-vec00097-001-s066><arrive.ankommen><en> Your Almus flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s066><arrive.ankommen><de> Ihre Almus Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s067><arrive.ankommen><en> The compact design allows riders to weave through the sideways making them arrive at the destination more quickly.
<G-vec00097-001-s067><arrive.ankommen><de> Die kompakte Bauweise erlaubt es dem Fahrer zu schlängeln sich durch die seitlich so dass sie schneller am Ziel ankommen.
<G-vec00097-001-s068><arrive.ankommen><en> Your Rajkot flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s068><arrive.ankommen><de> Ihre Rajkot Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s069><arrive.ankommen><en> Your Govurdak flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s069><arrive.ankommen><de> Ihre Govurdak Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s070><arrive.ankommen><en> If your hold luggage weighs more than your allowance when you arrive at the airport we charge you a fee for each 1kg of excess weight.
<G-vec00097-001-s070><arrive.ankommen><de> Wenn Sie am Flughafen ankommen und Ihr Gepäck mehr als Ihre Freigepäckgrenze wiegt, berechnen wir Ihnen eine Gebühr für jedes Kilogramm Übergewicht.
<G-vec00097-001-s071><arrive.ankommen><en> Your Baklan flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s071><arrive.ankommen><de> Ihre Baklan Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s072><arrive.ankommen><en> Your NewcastleuponTyne flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s072><arrive.ankommen><de> Ihre NewcastleuponTyne Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s073><arrive.ankommen><en> Your Angren flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s073><arrive.ankommen><de> Ihre Angren Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s074><arrive.ankommen><en> Your Muridke flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s074><arrive.ankommen><de> Ihre Muridke Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s075><arrive.ankommen><en> Your Tagum flowers delivery will be special to both you and the recipient, and it's imperative that they arrive on time and in truly stunning form.
<G-vec00097-001-s075><arrive.ankommen><de> Ihre Tagum Blumenlieferung wird speziell für Sie und den Empfänger, und es ist zwingend notwendig, dassSie pünktlich ankommen und in wirklich atemberaubender Form.
<G-vec00097-001-s076><arrive.ankommen><en> As Diätassistent I confessed in the kitchen and know on which it arrive.
<G-vec00097-001-s076><arrive.ankommen><de> Als Diätassistent habe ich selbst in der Küche gestanden und weiß worauf es ankommt.
<G-vec00097-001-s077><arrive.ankommen><en> It’s the path we walk to get to where we’re going, the ancient wisdom that in leaving you arrive and the ultimate end of the road.
<G-vec00097-001-s077><arrive.ankommen><de> Es ist der Pfad, auf dem wir gehen, um dorthin zu kommen, wohin wir gehen wollen; ausgedrückt in der überlieferten Weisheit, dass nur ankommt, wer auch aufbricht – bis zum ultimativen Ende der Straße.
<G-vec00097-001-s078><arrive.ankommen><en> To have a successful Astroploatation, you must keep in mind the Asteroid's speed and current location and time needed for your fleet to arrive thus sending the flight to such coordinates that it would intersect the Asteroid.
<G-vec00097-001-s078><arrive.ankommen><de> Um einen Asteroiden erfolgreich abbauen zu können, muss man beachten, dass die Geschwindigkeit und Position des Asteroiden beachtet werden müssen, bevor man den Flug versendet, damit man zum richtigen Zeitpunkt ankommt.
<G-vec00097-001-s079><arrive.ankommen><en> I know how they order system works and when my package is a bit late I do not worry because I know that it will arrive no matter what.
<G-vec00097-001-s079><arrive.ankommen><de> Ich weiß genau, wie das Bestellungssystem funktioniert und ich bin nicht besorgt, wenn das Paket ein wenig zu spät ist, da ich genau weiß, dass es ankommt.
<G-vec00097-001-s080><arrive.ankommen><en> Sometimes it just takes time for the email to arrive.
<G-vec00097-001-s080><arrive.ankommen><de> Manchmal braucht es Zeit, bis die E-Mail ankommt.
<G-vec00097-001-s081><arrive.ankommen><en> Of course, it is a very comfortable thing to arrive to the common main station of Zermatt and have only to cross the street in order to take then the next train in direction to the peak.
<G-vec00097-001-s081><arrive.ankommen><de> Es ist natürlich eine bequeme Sache, wenn man am normalen Bahnhof von Zermatt ankommt, nur die Straße überqueren muss und sich in den nächsten Zug in Richtung Gipfel setzen kann.
<G-vec00097-001-s082><arrive.ankommen><en> LINEA, a system developed by the Hub, informs customers by email or text message if their baggage won't arrive as planned.
<G-vec00097-001-s082><arrive.ankommen><de> Mit LINEA entwickelte der Hub ein System, das Kunden per E-Mail oder SMS informiert, wenn ihr Gepäck nicht wie geplant ankommt.
<G-vec00097-001-s083><arrive.ankommen><en> It always can happen that a package doesn´t arrive.
<G-vec00097-001-s083><arrive.ankommen><de> Es ist immer möglich, dass eine Packung nicht ankommt.
<G-vec00097-001-s084><arrive.ankommen><en> First you want, that the computer is ready before the user (or your employees) arrive at work.
<G-vec00097-001-s084><arrive.ankommen><de> Zunächst möchten Sie, dass der Computer bereit ist, bevor der Benutzer (oder Ihr Mitarbeiter) bei der Arbeit ankommt.
<G-vec00097-001-s085><arrive.ankommen><en> The return of such items is the full responsibility of the customer, and the goods must be securely packaged to ensure that they arrive back to us undamaged.
<G-vec00097-001-s085><arrive.ankommen><de> Die Rücksendung solcher Ware liegt in der Verantwortung des Kunden und er muss Sorge tragen, dass die Ware materialgerecht verpackt und unbeschädigt bei uns ankommt.
<G-vec00097-001-s086><arrive.ankommen><en> Keeping the blood flow active — even partially — extends the opportunity for a successful resuscitation once trained medical staff arrive on site.
<G-vec00097-001-s086><arrive.ankommen><de> Die Aufrechterhaltung des Blutflusses - auch teilweise - bietet die Möglichkeit einer erfolgreichen Wiederbelebung, sobald geschultes medizinisches Personal vor Ort ankommt.
<G-vec00097-001-s087><arrive.ankommen><en> I am waiting for the parcel to arrive by mail.
<G-vec00097-001-s087><arrive.ankommen><de> Ich warte darauf, dass das Paket per Post ankommt.
<G-vec00097-001-s088><arrive.ankommen><en> Prepayment serves for the company as a guarantee that the client will arrive and will pay for the booked period in full, and for the client as a guarantee that he or she will receive the agreed apartment for the agreed booked period.
<G-vec00097-001-s088><arrive.ankommen><de> Die Vorauszahlung dient dem Unternehmen als Garantie dafür, dass der Kunde ankommt und den gebuchten Zeitraum vollständig bezahlt, und dem Kunden als Garantie dafür, dass er die vereinbarte Wohnung für den vereinbarten gebuchten Zeitraum erhält.
<G-vec00097-001-s089><arrive.ankommen><en> A tsunami can only be noticed by the coast once it arrives, or is about to arrive.
<G-vec00097-001-s089><arrive.ankommen><de> Ein Tsunami kann in den Küstenregionen erst wahrgenommen werden, wenn er tatsächlich schon ankommt.
<G-vec00097-001-s090><arrive.ankommen><en> So he competed in coming closer to God, and he took the necessary means to ensure that he would arrive at the promised destination.
<G-vec00097-001-s090><arrive.ankommen><de> Dieser strengt sich an, um Gott näher zu kommen und er hat die notwendigen Mittel ergriffen, um sich abzusichern, dass er an dem versprochenen Reiseziel ankommt.
<G-vec00097-001-s091><arrive.ankommen><en> Now we're sure that our budget will arrive directly at the proper place.
<G-vec00097-001-s091><arrive.ankommen><de> Dadurch wissen wir, dass unser Budget direkt an der richtigen Stelle ankommt.
<G-vec00097-001-s092><arrive.ankommen><en> We are a company that provides the service of development of hydraulic hoses for construction machines, agricultural and other equipment that have hydraulics, with the added value that we consist More... with a mobile computer that is fully equipped with the necessary materials, which makes us arrive to where you have your computer and requires our service immediately.
<G-vec00097-001-s092><arrive.ankommen><de> Wir sind ein Unternehmen, das den Dienst der Entwicklung von Hydraulikschläuchen für Baumaschinen, landwirtschaftlichen und anderen Geräten, die Hydraulik zu haben, mit dem Mehrwert, den wir aus mit einem mobilen Mehr... Computer, die vollständig mit den notwendigen Materialien ausgestattet ist, die es uns ankommt macht bietet um, wo Sie Ihren Computer und erfordert unseren Service sofort.
<G-vec00097-001-s093><arrive.ankommen><en> Unfortunately, it happens again and again that checked luggage does not arrive at its destination or that it is damaged.
<G-vec00097-001-s093><arrive.ankommen><de> Leider kommt es immer wieder vor, dass aufgegebenes Reisegepäck am Zielort nicht ankommt oder beschädigt wird.
<G-vec00097-001-s094><arrive.ankommen><en> So, if your period doesn’t arrive, check to make sure it’s not actually a baby on the way.
<G-vec00097-001-s094><arrive.ankommen><de> Also, wenn Ihre Zeit nicht ankommt, überprüfen Sie, um sicherzustellen, dass es nicht wirklich ein Baby auf dem Weg ist.
<G-vec00097-001-s133><arrive.anreisen><en> Important information If you expect to arrive outside check-in hours, please inform the property in advance.
<G-vec00097-001-s133><arrive.anreisen><de> Wichtige Informationen Falls Sie voraussichtlich außerhalb der Check-in-Zeiten anreisen, informieren Sie die Unterkunft bitte vorab.
<G-vec00097-001-s134><arrive.anreisen><en> Students doing the internship during regular semester dates and arrive at the beginning of the semester (October, April), might be able to join the Erasmus Welcome Week for enrolment and orientation.
<G-vec00097-001-s134><arrive.anreisen><de> Studierende, die zu den regulären Semesterzeiten ihr Praktikum absolvieren und zu Semesterbeginn (Oktober, April) anreisen, können im Rahmen der Erasmus Welcome Week eingeschrieben und betreut werden.
<G-vec00097-001-s135><arrive.anreisen><en> If you expect to arrive outside reception opening hours, please inform the property in advance in order to arrange check-in.
<G-vec00097-001-s135><arrive.anreisen><de> Wenn Sie außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Unterkunft bitte im Voraus, um den Check-in zu arrangieren.
<G-vec00097-001-s136><arrive.anreisen><en> If you expect to arrive outside reception opening hours, please inform the property in advance and within 19:00.
<G-vec00097-001-s136><arrive.anreisen><de> Wenn Sie außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie bitte das Hotel im Voraus und vor 19:00 Uhr.
<G-vec00097-001-s137><arrive.anreisen><en> Those of you who arrive by car can take advantage of the garage with special rates for hotel residents and you can then move around the city with the use of public transport system. For tourist information and bookings, for excursions and guided visits the courteous and professional staff will be happy to provide you with any useful advice you may require.
<G-vec00097-001-s137><arrive.anreisen><de> Für Jene, die mit dem Auto anreisen, gibt es eine vertragsgebundene Garage, des weiteren steht unser professionelles und freundliches Hotelteam für sämtliche touristischen Informationen, Buchungen für Ausflüge, Führungen und für Auskünfte über Fahrpläne der öffentlichen Verkehrsmittel zur kompletten Verfügung der Kunden.
<G-vec00097-001-s138><arrive.anreisen><en> If you think you may arrive later than 10:30pm, please let us know before making your booking.If any guest within your booking is under the age of 18 you MUST contact us before making the reservation onlineIf you arrive before 2.30pm you can store your bags in our luggage storage area for free.We do not accept stag or hens parties. Check Availability Reviews & Ratings
<G-vec00097-001-s138><arrive.anreisen><de> Wenn Sie denken, dass Sie nach 22:30 Uhr anreisen können, teilen Sie uns dies bitte vor der Buchung mit.Wenn ein Gast in Ihrer Buchung unter 18 Jahre alt ist, MÜSSEN Sie sich vor der Online-Reservierung mit uns in Verbindung setzenWenn Sie vor 14.30 Uhr anreisen, können Sie Ihre Koffer in unserem Gepäckraum kostenlos abstellen.Wir akzeptieren keine Junggesellenabschiede.
<G-vec00097-001-s140><arrive.anreisen><en> Please contact Pension Regenbogen in advance if you expect to arrive after 18:00.
<G-vec00097-001-s140><arrive.anreisen><de> Bitte kontaktieren Sie die Pension Regenbogen vorab, wenn Sie nach 18:00 Uhr anreisen sollten.
<G-vec00097-001-s141><arrive.anreisen><en> If you are intending to arrive after outside the reception opening times, you must notify the property in advance.
<G-vec00097-001-s141><arrive.anreisen><de> Wenn Sie voraussichtlich außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Unterkunft bitte vorab.
<G-vec00097-001-s142><arrive.anreisen><en> This lets you book your parking space quickly and easily so that you arrive relaxed and, after a short shuttle transfer, you can check in at your leisure.
<G-vec00097-001-s142><arrive.anreisen><de> So können Sie sich schnell und unkompliziert Ihren Parkplatz buchen, entspannt anreisen und nach dem Shuttle-Transfer bequem einchecken.
<G-vec00097-001-s143><arrive.anreisen><en> If you are planning to arrive later than this, please let us know in advance.
<G-vec00097-001-s143><arrive.anreisen><de> Falls Sie später anreisen möchten, bitte melden Sie es uns vorzeitig.
<G-vec00097-001-s144><arrive.anreisen><en> If you expect to arrive outside of office hours, please contact the property in advance to arrange key collection, using the contact details found on the booking confirmation.
<G-vec00097-001-s144><arrive.anreisen><de> Falls Sie voraussichtlich außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Unterkunft bitte im Voraus, um die Schlüsselübergabe zu arrangieren.
<G-vec00097-001-s145><arrive.anreisen><en> Please contact the hotel in advance if you intend to arrive outside these times.
<G-vec00097-001-s145><arrive.anreisen><de> Bitte informieren Sie das Hotel im Voraus, falls Sie außerhalb dieser Zeiten anreisen.
<G-vec00097-001-s146><arrive.anreisen><en> If you expect to arrive outside check-in hours, please inform the property in advance. Photo album
<G-vec00097-001-s146><arrive.anreisen><de> Falls Sie voraussichtlich außerhalb der Check-in-Zeiten anreisen, informieren Sie die Unterkunft bitte im Voraus.
<G-vec00097-001-s147><arrive.anreisen><en> Especially if you arrive to Aegviidu by train, you can walk this nature trail to Jäneda.
<G-vec00097-001-s147><arrive.anreisen><de> Vor allem dann, wenn Sie mit dem Zug anreisen, Aegviidu, können Sie zu Fuß das nature Trail zu Jäneda.
<G-vec00097-001-s148><arrive.anreisen><en> Important information If you expect to arrive later than 18:00, a late check-in fee of 150 DKK will apply.
<G-vec00097-001-s148><arrive.anreisen><de> Wichtige Informationen Wenn Sie nach 18:00 Uhr anreisen, wird eine Gebühr für einen späten Check-in in der Höhe von 150 DKK berechnet.
<G-vec00097-001-s149><arrive.anreisen><en> Please contact the hotel in advance if you arrive after 18:00.
<G-vec00097-001-s149><arrive.anreisen><de> Bitte kontaktieren Sie das Hotel im Voraus, falls Sie nach 18:00 Uhr anreisen.
<G-vec00097-001-s150><arrive.anreisen><en> Important information If you expect to arrive outside reception opening hours, please inform Emporio Prague Apartments in advance.
<G-vec00097-001-s150><arrive.anreisen><de> Wichtige Informationen Sollten Sie außerhalb der Öffnungszeiten der Rezeption anreisen, informieren Sie die Emporio Prague Apartments bitte im Voraus.
<G-vec00097-001-s151><arrive.anreisen><en> If you are expecting to arrive after 19:00 please let the property know 3 days in advance.
<G-vec00097-001-s151><arrive.anreisen><de> Wenn Sie nach 19:00 Uhr anreisen, informieren Sie die Unterkunft bitte 3 Tage im Voraus darüber.
<G-vec00097-001-s152><arrive.ankommen><en> We are punctual so we advise that you arrive a few minutes early
<G-vec00097-001-s152><arrive.ankommen><de> Wir sind pünktlich, daher empfehlen wir Ihnen, einige Minuten im Voraus anzukommen.
<G-vec00097-001-s153><arrive.ankommen><en> Free shipping requires no transportation taxes but takes longer to arrive and the value of the order has to exceed $50 and the standard shipping can take significantly less to arrive but will require additional fees.
<G-vec00097-001-s153><arrive.ankommen><de> Kostenloser Versand erfordert keine Transport Steuern, aber es dauert länger, um anzukommen und den Wert der Bestellung übersteigt $50 und die standard-Versand dauert wesentlich weniger, um anzukommen, sondern erfordern zusätzliche Gebühren.
<G-vec00097-001-s155><arrive.ankommen><en> It is recommended to arrive 10 minutes prior to departure.
<G-vec00097-001-s155><arrive.ankommen><de> Es wird empfohlen, 10 Minuten vor Abreise anzukommen.
<G-vec00097-001-s156><arrive.ankommen><en> He said: “This result is very important because I extend three points on Jorge, but especially to arrive in front of him in the race is important and to have a small advantage at the end of the first part of the championship.
<G-vec00097-001-s156><arrive.ankommen><de> "Er sagte:""Dieses Ergebnis ist sehr wichtig, denn ich habe meine Führung auf Jorge um drei Punkte ausgebaut, aber es ist besonders wichtig vor ihm im Rennen anzukommen und mit einem kleinen Vorsprung den ersten Teil der Meisterschaft abzuschließen."
<G-vec00097-001-s157><arrive.ankommen><en> What an ease to arrive in Laos after the very hectic and crowded Vietnam.
<G-vec00097-001-s157><arrive.ankommen><de> Welche Wohltat, nach dem doch sehr hektischen und überfüllten Vietnam in Laos anzukommen.
<G-vec00097-001-s158><arrive.ankommen><en> Rome's Tiburtina Station is a junction for national and international trains, as well as the departure point for many of the city's bus and subway lines – not just the perfect place to arrive, but the best starting point for your 360-degree exploration of Rome.
<G-vec00097-001-s158><arrive.ankommen><de> Der Bahnhof Tiburtina von Rom ist ein Knotenpunkt für nationale und internationale Züge, aber auch Ausgangspunkt für zahlreiche Autobusse der Stadtlinie und der Metro – somit der perfekte Ort, um anzukommen, aber auch um aufzubrechen, um Rom wirklich zu 360 Grad zu erleben.
<G-vec00097-001-s159><arrive.ankommen><en> Moreover, the researchers found that they leave their nest earlier (and often in the dark when leopards are more likely to attack) for these fruits in order to arrive before others, especially when the breakfast sites were far away.
<G-vec00097-001-s159><arrive.ankommen><de> Darüber hinaus zeigen die Forscher, dass die Schimpansen für den Erwerb dieser Früchte ihre Nester morgens früher verlassen (oft noch im Dunkeln, wenn Leoparden auf der Jagd sind), um vor allen anderen am Frühstücksort anzukommen.
<G-vec00097-001-s160><arrive.ankommen><en> So, for example, if you want to see a match on a Sunday then you ideally would book your journey to arrive Friday and to return Tuesday.
<G-vec00097-001-s160><arrive.ankommen><de> Wenn Sie beispielsweise ein Spiel an einem Sonntag sehen möchten, würden Sie idealerweise Ihre Reise buchen, um am Freitag anzukommen und am Dienstag abreisen.
<G-vec00097-001-s161><arrive.ankommen><en> Emmer's event started at 3 p.m. We had intended to arrive early but, because Bob had to make copies of literature at a photocopying shop, we arrived around the time the event started.
<G-vec00097-001-s161><arrive.ankommen><de> Emmers Ereignis begann mit 3 P.M. Wir hatten beabsichtigt, früh anzukommen, aber, weil Bob Kopien von der Literatur an einem photokopierenden Geschäft erstellen musste, kamen wir um die Zeit an, die das Ereignis begann.
<G-vec00097-001-s162><arrive.ankommen><en> I had to complain several times that the shipment has been slow to arrive.
<G-vec00097-001-s162><arrive.ankommen><de> Ich musste mehrmals, dass die Sendung nur langsam anzukommen beschweren.
<G-vec00097-001-s163><arrive.ankommen><en> Take somme manage of your penis related concerns and make a hugely constructive change that you and your associate will undoubtedly gain from now and for several many years to arrive.
<G-vec00097-001-s163><arrive.ankommen><de> Nehmen somme Ihres Penis bezogenen Anliegen zu verwalten und machen eine äußerst konstruktive Änderung, die Sie und Ihre Mitarbeiter werden zweifellos von jetzt und für mehrere vielen Jahren anzukommen zu gewinnen.
<G-vec00097-001-s164><arrive.ankommen><en> It is then normal to find it in the rate of unionization, in the practice to put the professionals at the head of the companies, in the development of the training directed by the old ones, the fact that the company begins to recruit these apprentices and allow them for the best to arrive at the general direction.
<G-vec00097-001-s164><arrive.ankommen><de> Es ist dann normal, es im Syndikalisierungsatz, in der Gewohnheit wiederzufinden, die Fachleute an der Spitze der Unternehmen zu stellen in der Entwicklung der Lehre, die durch die alten gelenkt wurde, die Tatsache, daß das Unternehmen sich verpflichtet, diese Lehrlinge zu rekrutieren und ihnen für die besten erlaubt, in der Generaldirektion anzukommen.
<G-vec00097-001-s165><arrive.ankommen><en> In 1988 this yearning deep in my heart took me to the Alsace to realize my dream and rebuild an idyllic cottage together with my former husband and thus to finally arrive home.
<G-vec00097-001-s165><arrive.ankommen><de> Diese Sehnsucht, tief in meinem Herzen verankert, trieb mich 1988 ins Elsass, um mit meinem damaligen Ehemann meinen Traum zu verwirklichen, ein idyllisches Landhaus umzubauen, um so endlich anzukommen.
<G-vec00097-001-s166><arrive.ankommen><en> To avoid expensive downtime and to arrive at destinations safely, drivers and fleets must be equipped adequately to also deal with harsh winter conditions.
<G-vec00097-001-s166><arrive.ankommen><de> Fahrer und Flotten müssen auch für härteste Winterbedingungen gerüstet sein, um teure Ausfallzeiten zu vermeiden und sicher am Ziel anzukommen.
<G-vec00097-001-s167><arrive.ankommen><en> "And it is possible to try ""to refresh feelings"": to arrive to club separately, to play casual acquaintance, to dance to the heart's content much, and then to leave home (having pretended, of course, that is the house someone one of you)."
<G-vec00097-001-s167><arrive.ankommen><de> "Und man kann zu erfrischen die Gefühle »versuchen"": zum Klub getrennt anzukommen, die zufällige Bekanntschaft, natanzewatsja genug, und später zu spielen, nach Hause abzufahren (natürlich den Anschein gegeben, was das Haus jemand einen von Ihnen sind)."
<G-vec00097-001-s168><arrive.ankommen><en> The order to arrive to force staff was transmitted to command of this group through coherent.
<G-vec00097-001-s168><arrive.ankommen><de> Dem Kommando dieser Abteilung durch die Zusammenhängenden war die Verfügung übergeben, im Stab der Vereinigung anzukommen.
<G-vec00097-001-s169><arrive.ankommen><en> Over bike paths, we will get into the frenetic life of the “city porteña” to arrive in the heart of downtown, where May Square is located.
<G-vec00097-001-s169><arrive.ankommen><de> "Über Radwege kommen wir in das hektische Leben der ""Stadt Porteña"", um im Herzen der Innenstadt anzukommen, wo sich der May Square befindet."
<G-vec00097-001-s170><arrive.ankommen><en> • Please make sure you are at home when packages are expected to arrive.
<G-vec00097-001-s170><arrive.ankommen><de> Bitte stellen Sie sicher, dass Sie zu Hause sind, wenn Pakete werden erwartet, um anzukommen.
<G-vec00097-001-s171><arrive.anreisen><en> Please contact CityHotel Kempten in advance if you expect to arrive late.
<G-vec00097-001-s171><arrive.anreisen><de> Bitte wenden Sie sich im Voraus an das CityHotel Kempten, wenn Sie erwarten, spät anzureisen.
<G-vec00097-001-s172><arrive.anreisen><en> If you expect to arrive outside check-in hours, please inform the property at least 1 week in advance.
<G-vec00097-001-s172><arrive.anreisen><de> Sollten Sie planen außerhalb der Check-in-Zeiten anzureisen, informieren Sie die Unterkunft bitte mindestens 1 Woche im Voraus.
<G-vec00097-001-s174><arrive.anreisen><en> You might want to arrive a day or so early, if possible, to allow you time to recover from jet lag.
<G-vec00097-001-s174><arrive.anreisen><de> Es ist gut, ungefähr einen Tag früher anzureisen, wenn es möglich ist, um dir Zeit zur Erholung vom Jetlag zu gewährleisten.
<G-vec00097-001-s175><arrive.anreisen><en> If you plan to arrive after 22:00, please contact the residence in advance to obtain access codes.
<G-vec00097-001-s175><arrive.anreisen><de> Planen Sie, nach 22:00 Uhr anzureisen, so kontaktieren sie die Unterkunft bitte vorab, um den Zugangscode zu erhalten.
<G-vec00097-001-s176><arrive.anreisen><en> Guests planning to arrive outside of these hours must contact the hotel in advance for further information.
<G-vec00097-001-s176><arrive.anreisen><de> Falls Sie planen, außerhalb dieser Zeiten anzureisen, müssen Sie das Hotel für weitere Informationen kontaktieren.
<G-vec00097-001-s177><arrive.anreisen><en> If you are planning to arrive later than you have booked, please inform our customer service so that the owner does not have to wait for you unnecessarily.
<G-vec00097-001-s177><arrive.anreisen><de> Wenn Sie planen sollten später anzureisen als gebucht, weisen Sie unseren Kundenservice bitte darauf hin, damit der Vermieter nicht vergebens auf Sie warten muss.
<G-vec00097-001-s178><arrive.anreisen><en> Please contact the hotel in advance if you plan to arrive later than 22:00.
<G-vec00097-001-s178><arrive.anreisen><de> Sollten Sie planen, nach 22:00 Uhr anzureisen, informieren Sie bitte das Hotel im Voraus.
<G-vec00097-001-s179><arrive.anreisen><en> However, it is also possible to arrive by train or by car.
<G-vec00097-001-s179><arrive.anreisen><de> Selbstverständlich ist es auch möglich mit der Bahn oder dem eigenen Auto anzureisen.
<G-vec00097-001-s180><arrive.anreisen><en> If planning to arrive later than this, please contact the boarding house in advance.
<G-vec00097-001-s180><arrive.anreisen><de> Planen Sie, nach diesem Zeitpunkt anzureisen, kontaktieren Sie das Hotel bitte vor der Anreise.
<G-vec00097-001-s181><arrive.anreisen><en> Those visitors who are planning to arrive at Malaga by cruise or by train and want to hire a car, well now's the time.
<G-vec00097-001-s181><arrive.anreisen><de> Jene Besucher, die planen, in Málaga mit dem Kreuzfahrtschiff oder dem Zug anzureisen und einen Mietwagen mieten möchten, liegen hier genau richtig.
<G-vec00097-001-s182><arrive.anreisen><en> Kindly call the hotel in advance if you intend to arrive late.
<G-vec00097-001-s182><arrive.anreisen><de> Bitte rufen Sie das Hotel im Voraus an, wenn Sie beabsichtigen, später anzureisen.
<G-vec00097-001-s183><arrive.anreisen><en> We'd advise you to arrive by train; transportation hubs in Nice or Marseilles will connect you to the local lines leading to Menton.
<G-vec00097-001-s183><arrive.anreisen><de> Wir empfehlen Ihnen, mit dem Zug anzureisen; in Nizza oder Marseille können Sie in regionale Transportmittel umsteigen, die Sie nach Menton bringen.
<G-vec00097-001-s184><arrive.anreisen><en> Our yoga weeks always start on Monday, which is why we recommend that you arrive on Sunday.
<G-vec00097-001-s184><arrive.anreisen><de> Unsere Yoga-Woche beginnt immer montags, darum empfehlen wir, bereits am Sonntag anzureisen.
<G-vec00097-001-s185><arrive.anreisen><en> It is advisable to arrive by car.
<G-vec00097-001-s185><arrive.anreisen><de> Es wird empfohlen, mit dem Auto anzureisen.
<G-vec00097-001-s186><arrive.anreisen><en> Please inform the hotel if you intend to arrive after 24:00.
<G-vec00097-001-s186><arrive.anreisen><de> Bitte informieren Sie das Hotel, falls Sie planen, nach Mitternacht anzureisen.
<G-vec00097-001-s187><arrive.anreisen><en> If you come to the clinic Buchinger for the first time, we recommend to arrive between 2 pm and 5 pm: at this time our entire reception team is complete and can take care of you.
<G-vec00097-001-s187><arrive.anreisen><de> Wenn Sie zum ersten Mal zu Buchinger kommen, empfehlen wir Ihnen, zwischen 15.00 Uhr und 17.00 Uhr anzureisen: da ist unser Empfangsteam komplett für Sie da.
<G-vec00097-001-s188><arrive.anreisen><en> If you plan to arrive after 20:00 (not later than 23:00), please contact us in advance via e-mail or telephone.
<G-vec00097-001-s188><arrive.anreisen><de> Bitte kontaktieren Sie das Hotel via e-mail oder telefonisch, falls Sie planen, nach 20:00 Uhr anzureisen.
<G-vec00097-001-s189><arrive.anreisen><en> If you plan to arrive between November and March, between 14:30 and 17:30, please contact the hotel in advance, as the hotel reception will not be manned. Contact details will be included in your confirmation e-mail. Area information
<G-vec00097-001-s189><arrive.anreisen><de> Wenn Sie planen, zwischen November und März von 14:30 bis 17:30 Uhr anzureisen, kontaktieren Sie bitte das Hotel im Voraus, da die Rezeption in dieser Zeit nicht besetzt ist.
<G-vec00097-001-s190><arrive.eintreffen><en> It is usually arranged for such persons to arrive in surroundings closely imitating those that they left on Earth.
<G-vec00097-001-s190><arrive.eintreffen><de> Normalerweise wird für diese Personen angeordnet, dass sie in einer Umgebung eintreffen, die der Irdischen sehr ähnelt.
<G-vec00097-001-s191><arrive.eintreffen><en> This represents approximately a two month delay due to delays created by the late delivery of some critical equipment such as the precipitates filters presses that are now scheduled to arrive on-site in late July.
<G-vec00097-001-s191><arrive.eintreffen><de> Dies stellt eine Verzögerung von etwa zwei Monaten dar und ist auf Verzögerungen infolge der späten Lieferung von wichtigem Equipment, wie etwa Präzipitatfilterpressen, die nun Ende Juli am Standort eintreffen sollen, zurückzuführen.
<G-vec00097-001-s192><arrive.eintreffen><en> The press which will produce alloy wheels for private cars will arrive in Kaohsiung/Taiwan in early march.
<G-vec00097-001-s192><arrive.eintreffen><de> Die hydraulische Presse, auf der zukünftig Alufelgen für PKW hergestellt werden, wird Anfang März in Kaohsiung/Taiwan eintreffen.
<G-vec00097-001-s193><arrive.eintreffen><en> The import permit can usually be applied for before the goods arrive if you ask your supplier for the correct documents in due time.
<G-vec00097-001-s193><arrive.eintreffen><de> Die Einfuhrerlaubnis kann für gewöhnlich beantragt werden, bevor die Waren eintreffen, wenn Sie bei Ihrem Lieferanten rechtzeitig die entsprechenden Dokumente abfordern.
<G-vec00097-001-s194><arrive.eintreffen><en> Should you arrive sooner or later as the prescribed check in time, we ask for a short notice.
<G-vec00097-001-s194><arrive.eintreffen><de> Sollten Sie früher oder später als die vorgeschriebene Check-In Zeit eintreffen so bitten wir Bekanntgabe.
<G-vec00097-001-s195><arrive.eintreffen><en> Falcon Crest Victorian Mansion interior set - inconsistency: When the Giobertis arrive in front of the mansion at the end of the episode, the front door is ajar and offers a view of the window in the library of the real Villa Miravalle in the background.
<G-vec00097-001-s195><arrive.eintreffen><de> Ungereimtheit im Bühnenbild des viktorianischen Herrenhauses von Falcon Crest: Als die Giobertis am Ende der Folge vor dem Haus eintreffen, sieht man durch die offen stehende Eingangstür, dass sich in der Bibliothek der echten Villa Miravalle im oberen Bereich des Fensters bunte Bleiglaselemente befinden.
<G-vec00097-001-s196><arrive.eintreffen><en> You hear a different mix at each node of the network, as streams arrive at different times and mix in unpredictable ways.
<G-vec00097-001-s196><arrive.eintreffen><de> An jedem Netzwerkknoten bekommt man einen anderen Mix zu hören, weil die Streams zu unterschiedlichen Zeiten eintreffen und sich in unvorhersehbarer Weise mischen.
<G-vec00097-001-s197><arrive.eintreffen><en> Sometimes it can therefore be worthwhile to get up really early and be at a famous site before the masses arrive.
<G-vec00097-001-s197><arrive.eintreffen><de> Manchmal kann es sich deshalb lohnen, ganz früh aufzustehen und an einer Sehenswürdigkeit zu sein, bevor die Massen eintreffen.
<G-vec00097-001-s198><arrive.eintreffen><en> The delivery notes can be transmitted to customers electronically, so that they are already informed of the quantity, content and arrival time of the delivery before the goods arrive, allowing them to control further processing perfectly.
<G-vec00097-001-s198><arrive.eintreffen><de> Die Lieferscheine können per DFÜ an den Kunden übertragen werden, so dass dieser schon vor Eintreffen der Ware genauestens über Menge, Inhalt und Ankunftszeit informiert ist und somit den Weiterverarbeitungsprozess perfekt steuern kann.
<G-vec00097-001-s199><arrive.eintreffen><en> Heading towards Germany, the bananas are still green, then they are stored in ripening chambers, until they finally arrive a week before the BMW BERLIN MARATHON.
<G-vec00097-001-s199><arrive.eintreffen><de> Unterwegs sind die Bananen noch grÃ1⁄4n, dann werden sie in Reifekammern gelagert, bis sie schließlich eine Woche vor dem BMW BERLIN MARATHON beim Verpflegungsdienstleister eintreffen.
<G-vec00097-001-s200><arrive.eintreffen><en> Please ensure that you have provided an accurate e-mail and that you have added orders@internetflorist.biz to your address book so that our e-mails do not arrive in the junk mail.
<G-vec00097-001-s200><arrive.eintreffen><de> Bitte stellen Sie sicher, dass Sie eine korrekte E-mail angegeben haben und dass Sie orders@internetflorist.biz zu Ihrem Adressbuch hinzugefügt haben, so dass unsere E-mails nicht in den Junk-Mail eintreffen.
<G-vec00097-001-s201><arrive.eintreffen><en> And even with Standard shipping, it’s only 5 to 8 working days before your photo collages arrive.
<G-vec00097-001-s201><arrive.eintreffen><de> Im Standardverfahren vergehen aber auch nur 5 bis 8 Arbeitstage, bis Ihre Fotocollagen bei Ihnen eintreffen.
<G-vec00097-001-s202><arrive.eintreffen><en> And now, as the systems one by one become settled in light by virtue of the progress of their component worlds, the time comes when the last system in a given constellation attains stabilization, and the universe administrators—the Master Son, the Union of Days, and the Bright and Morning Star—arrive on the capital of the constellation to proclaim the Most Highs the unqualified rulers of the newly perfected family of one hundred settled systems of inhabited worlds.
<G-vec00097-001-s202><arrive.eintreffen><de> Und jetzt, da die Systeme dank den Fortschritten der sie bildenden Welten eines nach dem anderen die Lichtära betreten, kommt die Zeit, da auch das letzte System einer gegebenen Konstellation zur Stabilisierung gelangt und die Universumsverwalter – der Meistersohn, der Einiger der Tage und der Helle Morgenstern – auf der Kapitale der Konstellation eintreffen, um die Allerhöchsten zu unbeschränkten Herrschern über diese eben vervollkommnete Familie von einhundert gefestigten Systemen bewohnter Welten auszurufen.
<G-vec00097-001-s203><arrive.eintreffen><en> If you are located in another country, your package will arrive in 10-12 days. .
<G-vec00097-001-s203><arrive.eintreffen><de> Wenn Sie sich in einem anderen Land aufhalten, wird Ihr Paket in 10-12 Tagen eintreffen.
<G-vec00097-001-s204><arrive.eintreffen><en> Sticky and spiky, hollow and so it breaks easily. Asif told us that he arrived that day; he was supposed to arrive the day before but couldn't as he was filming.
<G-vec00097-001-s204><arrive.eintreffen><de> Asif erzählte uns, dass er erst an diesem Tag angekommen sei; er hätte eigentlich schon tags zuvor eintreffen sollen, aber er war noch mit Filmarbeiten beschäftigt.
<G-vec00097-001-s205><arrive.eintreffen><en> The processing of the purchase is continually accompanied by friendly mails of the Baunat employees, so that I was exactly informed when the jewellery would arrive.
<G-vec00097-001-s205><arrive.eintreffen><de> Die Abwicklung des Kaufs wurde kontinuierlich begleitet durch freundliche Mails der Baunat-Mitarbeiterinnen, so dass ich genau informiert war, wann das Schmuckstück bei mir eintreffen würde.
<G-vec00097-001-s206><arrive.eintreffen><en> Our mission is to provide services to ensure that all deliveries of chilled food arrive to your place of operation in uncompromising quality, properly packaged, in the required quantity, and especially on time.
<G-vec00097-001-s206><arrive.eintreffen><de> Unsere Berufung ist es, solche Dienstleistungen zu gewähren, dass alle Lieferungen von gekühlten Lebensmitteln in kompromissloser Qualität, richtig verpackt, in der verlangten Menge und vor allem rechtzeitig in Ihrer Betriebsstätte eintreffen.
<G-vec00097-001-s207><arrive.eintreffen><en> Still used to Swiss punctuality, we belong to the first ones to arrive and are greeted by Alois.
<G-vec00097-001-s207><arrive.eintreffen><de> Immer noch an Schweizer Pünktlichkeit gewöhnt, gehören wir zu den ersten, die eintreffen und die von Alois begrüsst werden.
<G-vec00097-001-s208><arrive.eintreffen><en> As nearly as I can remember they stated that a special transport would arrive from Auschwitz and that the people on this transport were to be killed and their bodies sent to Strassburg to Professor Hirt.
<G-vec00097-001-s208><arrive.eintreffen><de> So gut wie ich mich annähernd erinnern kann, besagten sie, daß ein Sondertransport aus Auschwitz eintreffen würde und daß die Personen aus diesem Transport getötet und ihre Leichen nach Straßburg zu Professor Hirt verbracht werden sollten.
<G-vec00097-001-s209><arrive.erreichen><en> "We need to arrive at a ""tipping point"" for the BPO, at which investment begins to match rising demand for innovation."
<G-vec00097-001-s209><arrive.erreichen><de> Die BPO muss den sogenannten Tipping Point erreichen, an dem sich Investitionen und die steigende Nachfrage nach Innovationen decken.
<G-vec00097-001-s210><arrive.erreichen><en> This is one of the chief dangers of the spiritual life and to be on one’s guard against it is a necessity for the seeker if he wishes to arrive at his goal.
<G-vec00097-001-s210><arrive.erreichen><de> Dies ist eine der Hauptgefahren des spirituellen Lebens, und vor ihr auf der Hut zu sein, ist für den Suchenden, der sein Ziel erreichen will, unbedingt erforderlich.
<G-vec00097-001-s211><arrive.erreichen><en> Climbing stairs, we arrive at an impressive dining room known as the Glory, where you can see fantastic formations resembling angels groups white clouds scattered over the high walls of the room.
<G-vec00097-001-s211><arrive.erreichen><de> Treppensteigen, erreichen Sie eine beeindruckende Speisesaal als Ehre, wo man sehen kann fantastischen Formationen ähneln Gruppen von Engeln auf weißen Wolken über die hohen Wände des Raumes verstreut bekannt.
<G-vec00097-001-s212><arrive.erreichen><en> Starting in Florence you will ride past the gentle hills towards the west and then with stopovers in Lucca and Montecatini Terme you will arrive at the seaside resort of Viareggio on the Liguria Sea.
<G-vec00097-001-s212><arrive.erreichen><de> Von Florenz aus fahren Sie durch die sanfte Hügellandschaft gen Westen und erreichen nach Zwischenstopps am Monte Albano, in Lucca und Montecatini Terme das Seebad Viareggio am Ligurischen Meer.
<G-vec00097-001-s213><arrive.erreichen><en> Each year, network proposals focusing on subject areas and themes not extensively covered by networks already being funded under this action are particularly encouraged, in order to arrive at an optimal coverage of academic disciplines.
<G-vec00097-001-s213><arrive.erreichen><de> Jedes Jahr werden Vorschläge für Netze mit Schwerpunkt auf Fachbereichen und Themen, die von bereits über diese Maßnahme finanzierten Netzen nicht umfassend abgedeckt sind, besonders gefördert, um eine optimale Abdeckung der akademischen Disziplinen zu erreichen.
<G-vec00097-001-s214><arrive.erreichen><en> In our estimation, it is a time that took too long to arrive.
<G-vec00097-001-s214><arrive.erreichen><de> Nach unserer Einschätzung hat es viel zu lange gedauert, diesen Tag zu erreichen.
<G-vec00097-001-s215><arrive.erreichen><en> On September 15th, 1999, DRGW 5409 and two other SD40T-2 of the former Denver, Rio Grande & Wetsern arrive at Soldier Summit with a manifest train from Denver to Roper.
<G-vec00097-001-s215><arrive.erreichen><de> DRGW 5409 und zwei weitere SD40T-2 der ehemaligen DRGW erreichen am 15.9.1999 mit ihrem gemischten Güterzug von Denver nach Roper den Scheitelbahnhof des Soldier Summit.
<G-vec00097-001-s216><arrive.erreichen><en> soon we arrive at timia.
<G-vec00097-001-s216><arrive.erreichen><de> bald erreichen wir wieder timia.
<G-vec00097-001-s217><arrive.erreichen><en> We arrive at the chapel, where some old ladies are praying the rosary fervently.
<G-vec00097-001-s217><arrive.erreichen><de> Wir erreichen die Kapelle, in der einige alte Damen inbrünstig den Rosenkranz beten.
<G-vec00097-001-s218><arrive.erreichen><en> To visit the world's most extensive and significant exhibition on the history and technology behind the Zeppelin airship you can arrive by road, rail or even water.
<G-vec00097-001-s218><arrive.erreichen><de> Die weltweit umfangreichste und bedeutendste Sammlung zur Geschichte und Technik der Zeppelin-Luftschifffahrt in Friedrichshafen können Sie auf Straße, Schiene oder per Schiff direkt erreichen.
<G-vec00097-001-s219><arrive.erreichen><en> You arrive at the bus station of La Paz around 6.30 hrs.
<G-vec00097-001-s219><arrive.erreichen><de> Sie erreichen den Busbahnhof von La Paz gegen 6.30 Uhr.
<G-vec00097-001-s220><arrive.erreichen><en> Shortly after, at km 35,5 / 22 miles you will arrive at El Dorado.
<G-vec00097-001-s220><arrive.erreichen><de> Kurz danach, bei km 35,5, erreichen Sie die Tankstelle El Dorado.
<G-vec00097-001-s221><arrive.erreichen><en> In short, women of Macedonia, be they artists, curators, or from other professional backgrounds, have a long road ahead of them and many battles to win if they are to arrive at a stage where they can discuss the events of 'becoming woman' and female subjectivity.
<G-vec00097-001-s221><arrive.erreichen><de> Kurz gesagt haben Frauen in Mazedonien als Künstlerinnen, Kuratorinnen oder aus anderen beruflichen Verhältnissen einen langen Weg vor sich und noch zahlreiche Kämpfe zu gewinnen, wenn sie ein Stadium erreichen wollen, in dem sie die Ereignisse des,Frau werdens' und der weiblichen Subjektivität erörtern können.
<G-vec00097-001-s222><arrive.erreichen><en> When you arrive at the chapel on the top after a 30-minute walk, admire the magnificent 360° view.
<G-vec00097-001-s222><arrive.erreichen><de> Wenn Sie auf der Oberseite nach einem 30-minütigen Spaziergang erreichen die Kapelle, bewundern die herrlichen 360 °-Ansicht.
<G-vec00097-001-s223><arrive.erreichen><en> The first pipes for constructing the pipeline are due to arrive in Mukran in April 2008 and in Kotka in June 2008 at the latest.
<G-vec00097-001-s223><arrive.erreichen><de> Die ersten Rohre für die Pipeline sollen Mukran im April 2008 und Kotka spätestens im Juni 2008 erreichen.
<G-vec00097-001-s224><arrive.erreichen><en> The results not long to arrive, and were far beyond all expectation: the amaranth not even lost a match, suffering only 7 goals in the league, a record still unbeaten.
<G-vec00097-001-s224><arrive.erreichen><de> Die Ergebnisse nicht allzu langer Zeit zu erreichen, und wurden weit über alle Erwartungen: Die Amaranth nicht einmal ein Spiel verloren, leiden nur 7 Tore in der Liga, ein Rekord noch ungeschlagen.
<G-vec00097-001-s225><arrive.erreichen><en> A round table (community discussion group) is a process built on consensus: in a procedure accompanied by a professional moderator the participants, who as far as possible represent all interests relevant to the particular issue, endeavour as equal and cooperative partners to arrive at a result which is acceptable to all concerned.
<G-vec00097-001-s225><arrive.erreichen><de> Ein Runder Tisch ist einen auf Konsens angelegter Prozess: In einem professionell moderierten Verfahren bemühen sich die Teilnehmer/innen, die nach Möglichkeit alle für das jeweilige Thema relevanten Interessen repräsentieren, gleichberechtigt und kooperativ ein für alle akzeptables Ergebnis zu erreichen.
<G-vec00097-001-s226><arrive.erreichen><en> You will be charged ones you arrive to the Hotel.
<G-vec00097-001-s226><arrive.erreichen><de> Sie werden diejenigen, die Sie erreichen das Hotel in Rechnung gestellt.
<G-vec00097-001-s227><arrive.erreichen><en> Capacity- To arrive at a rough estimate.
<G-vec00097-001-s227><arrive.erreichen><de> Kapazitäten zu erreichen, eine grobe Schätzung.
<G-vec00097-001-s228><arrive.erreichen><en> When a sun-spot is visual at middle of sun, its sun-wind (starting from there) is forward redirected so far, it can no longer arrive at earth but will pass by (see dotted curve with arrow).
<G-vec00097-001-s228><arrive.erreichen><de> Wenn der Sonnenfleck mittig auf der Sonnenscheibe zu sehen ist, wird der von dort ausgehende Sonnenwind so weit nach vorn verfrachtet, dass er die Erde nicht mehr erreicht (siehe gestrichelte Kurve mit Pfeil).
<G-vec00097-001-s229><arrive.erreichen><en> After a pleasant drive through the villages of the Omiš hinterland we finally arrive at the starting point foto 2 of our rafting adventure.
<G-vec00097-001-s229><arrive.erreichen><de> Nach Durchquerung der im omiser Hinterland liegenden Dörfer erreicht man den Startpunkt foto 2, an welchem unser Rafting – Abenteuer den Anfang hat.
<G-vec00097-001-s230><arrive.erreichen><en> The Hotel is on the right when you just arrive the Republic Square and Ataturk Statue.
<G-vec00097-001-s230><arrive.erreichen><de> Wenn Sie den Cumhuriyet-Platz der Republik mit dem Atatürk-Denkmal erreicht haben, befindet sich das Hotel auf der rechten Seite.
<G-vec00097-001-s231><arrive.erreichen><en> Tomorrow we'll arrive in Iceland and during the passage the Westman Islands will be visible.
<G-vec00097-001-s231><arrive.erreichen><de> Morgen wird Island erreicht sein und auch auf der Durchfahrt die Westmänner-Inseln in Sichtweite.
<G-vec00097-001-s232><arrive.erreichen><en> When the Danish police arrive at the illegal chicken farm, the building is burning brightly.
<G-vec00097-001-s232><arrive.erreichen><de> Registrieren Anmelden Als die dänische Polizei die illegale Hühnerfarm erreicht, steht das Gebäude in Flammen.
<G-vec00097-001-s233><arrive.erreichen><en> Just 5 minutes further, crossing Mercerie, you reach the alleys full of Italian and international designer boutiques and then you arrive to the splendid St. Mark’s Square.
<G-vec00097-001-s233><arrive.erreichen><de> Nur 5 Minuten weiter, überqueren Mercerie, erreicht man die Gassen voll von italienischen und internationalen Designer-Boutiquen und dann erreicht man die herrlichen Markusplatz.
<G-vec00097-001-s234><arrive.erreichen><en> Down about 10 steps you arrive at the living room with kitchenette, dining table and chairs and a sofa bed.
<G-vec00097-001-s234><arrive.erreichen><de> Down über 10 Stufen erreicht man den Wohnraum mit Küchenzeile, Esstisch und Stühlen und einem Sofa-Bett.
<G-vec00097-001-s235><arrive.erreichen><en> Flight LH 482 will leave Lufthansa’s Frankfurt hub and arrive in Tampa in the afternoon (local time) after a flight of nearly eleven hours.
<G-vec00097-001-s235><arrive.erreichen><de> LH 482 verlässt jeweils vormittags das Lufthansa-Drehkreuz Frankfurt und erreicht Tampa am Nachmittag (Ortszeit) nach einer Reisezeit von fast elf Stunden.
<G-vec00097-001-s236><arrive.erreichen><en> If you decide to get here by car, leave the highway A10 at Imperia West, take the Via Aurelia towards Ventimiglia and after a few kilometers you will arrive at San Lorenzo.
<G-vec00097-001-s236><arrive.erreichen><de> Wenn man mit dem Auto anreist, sollte man die Autobahn A10 bei Imperia West verlassen, dann weiter auf die Via Aurelia in Richtung Ventimiglia und nach ein paar Kilometern erreicht man San Lorenzo.
<G-vec00097-001-s237><arrive.erreichen><en> At some point you will enter the forest and arrive at the crossroad.
<G-vec00097-001-s237><arrive.erreichen><de> Bald einmal kommt man in den Wald und erreicht eine Abzweigung.
<G-vec00097-001-s238><arrive.erreichen><en> You finally arrive at the point where you don’t have to eschew or deny the self and all its experiences--however illusory in retrospect--in order to experience an enormous spiritual presence.
<G-vec00097-001-s238><arrive.erreichen><de> Ihr erreicht schließlich einen Punkt, wo ihr das Selbst und alle seine Erfahrungen nicht scheuen oder bestreiten müsst – wie illusorisch auch immer in der Rückschau -, um eine ungeheure geistige Präsenz zu erfahren.
<G-vec00097-001-s239><arrive.erreichen><en> Whether you arrive in La Paz by air or road, you will come through the urban sprawl of the El Alto neighborhood, formed as the city spilled over the edges of the deep valley in which it is located.
<G-vec00097-001-s239><arrive.erreichen><de> Egal, ob man La Paz über den Luft- oder den Landweg erreicht, man kommt durch das zersiedelte Gebiet des El Alto Viertels, das entstand, als sich die Stadt über die Kanten des tiefen Tales, in dem sie sich befindet, ausdehnte.
<G-vec00097-001-s240><arrive.erreichen><en> So if something they are trying to reach cannot be arrived at by moving in a straight line (forwards, backwards, to left or to right), they will have to move in a zigzag - first in a straight line to the front, then again in a straight line to the side - until they arrive at their intended destination.
<G-vec00097-001-s240><arrive.erreichen><de> Wenn ein bestimmtes Ziel nicht geradlinig nach vorne, nach rückwärts, rechts oder links zu erreichen ist, bewegen sie sich daher also im Zickzackkurs voran - ein Stück gerade nach vorne, dann wieder gerade zur Seite - bis sie das angestrebte Ziel erreicht haben.
<G-vec00097-001-s241><arrive.erreichen><en> "After Cherasco, 7 century of story and art, we arrive in Bra, the capital of gourmet, where there is ""Slow Food"" organization."
<G-vec00097-001-s241><arrive.erreichen><de> Nach Cherasco, sieben Jahrhunderte voller Geschichte und Kunst, erreicht man Bra, wo die Organisation „Slow Food“ ihren Sitz hat.
<G-vec00097-001-s242><arrive.erreichen><en> After machine arrive the destination, by the request of the buyer, we will provide 1 technical engineer to guide installation and training.
<G-vec00097-001-s242><arrive.erreichen><de> Nachdem die Maschine das Ziel erreicht hat, stellen wir auf Wunsch des Käufers einen technischen Ingenieur zur Verfügung, der die Installation und Schulung leitet.
<G-vec00097-001-s243><arrive.erreichen><en> Somewhen he would arrive at the blackness.
<G-vec00097-001-s243><arrive.erreichen><de> Irgendwann hätte er das Schwarz erreicht.
<G-vec00097-001-s244><arrive.erreichen><en> He plays a big role since most goods arrive to Madeira by sea route.
<G-vec00097-001-s244><arrive.erreichen><de> Er spielt eine wichtige Rolle, da die Mehrzahl der Waren in Madeira per Schiff erreicht.
<G-vec00097-001-s245><arrive.erreichen><en> 31 but Israel, following after a law of righteousness, did not arrive at that law.
<G-vec00097-001-s245><arrive.erreichen><de> Rom 9:31 Israel aber hat dem Gesetz der Gerechtigkeit nachgetrachtet, und hat das Gesetz der Gerechtigkeit nicht erreicht.
<G-vec00097-001-s246><arrive.erreichen><en> "Romans 7, according to this view, teaches only that ""the Christian's reach always exceeds his grasp"" and that during this lifetime the Christian ""cannot arrive at perfection."""
<G-vec00097-001-s246><arrive.erreichen><de> "Nach dieser Ansicht lehrt Römer 7 nur, dass ""was der Christ anstrebt, liegt immer außerhalb seiner Reichweite"", und dass während seiner Lebenszeit der Christ ""nie die Perfektion"" erreicht."
<G-vec00097-001-s247><arrive.erscheinen><en> You are advised to allow plenty of time and not arrive at the last minute, as these checks may take several minutes to complete.
<G-vec00097-001-s247><arrive.erscheinen><de> Sie werden darauf hingewiesen sich etwas Zeit dafür zu nehmen und nicht in der letzten Minute zu erscheinen, da diese Überprüfungen einige Minuten dauern können.
<G-vec00097-001-s248><arrive.erscheinen><en> A:Once you successfully complete a purchase, your Token should arrive in your inventory (or mailbox, if your inventory is full) almost immediately.
<G-vec00097-001-s248><arrive.erscheinen><de> A: Sobald ihr den Kauf erfolgreich abgeschlossen habt, sollte eure Marke nahezu umgehend in eurem Inventar erscheinen (oder im Briefkasten, wenn euer Inventar voll ist).
<G-vec00097-001-s249><arrive.erscheinen><en> Please arrive 15-20 minutes in advance to secure your seat.
<G-vec00097-001-s249><arrive.erscheinen><de> Bitte erscheinen Sie 15-20 Minuten im Voraus, um Ihren Sitzplatz zu sichern.
<G-vec00097-001-s250><arrive.erscheinen><en> Please arrive about 15 minutes before the departure of the boat.
<G-vec00097-001-s250><arrive.erscheinen><de> Bitte erscheinen Sie etwa 15 Minuten vor der Abfahrt an den Booten.
<G-vec00097-001-s251><arrive.erscheinen><en> We kindly ask you to arrive: 90 minutes before the scheduled departure time – if you are travelling individually;
<G-vec00097-001-s251><arrive.erscheinen><de> Wenn Sie allein reisen und einen besonderen Service in Anspruch nehmen möchten, erscheinen Sie bitte spätestens 90 Minuten vor der planmäßigen Abflugzeit.
<G-vec00097-001-s252><arrive.erscheinen><en> It is our intention to continue these until Spirit and the Galactic Federation openly arrive on the scene.
<G-vec00097-001-s252><arrive.erscheinen><de> Wir möchten dies noch so lange beibehalten, bis die geistige Welt (Spirit) und die Galaktische Föderation offen auf der Szene erscheinen.
<G-vec00097-001-s253><arrive.erscheinen><en> Arrive at the airport 3 hours before the departure of your domestic or international flight.
<G-vec00097-001-s253><arrive.erscheinen><de> Erscheinen Sie 3 Stunden vor Abflug Ihres nationalen oder internationalen Fluges am Flughafen.
<G-vec00097-001-s254><arrive.erscheinen><en> At an important meeting, which a job interview undoubtedly is, it is essential to arrive rested and able to concentrated.
<G-vec00097-001-s254><arrive.erscheinen><de> Bei einem wichtigen Gespräch, wozu ein Bewerbungsgespräch unzweifelhaft zählt, ist es ungeheuer wichtig, dass Sie gut ausgeruht und voll konzentrationsfähig erscheinen.
<G-vec00097-001-s255><arrive.erscheinen><en> For departures from London and Paris, passengers are obliged to arrive at check-in 1 hour before the scheduled departure time.
<G-vec00097-001-s255><arrive.erscheinen><de> Im Falle der Linien aus London und Paris sind die Passagiere verpflichtet, 1 Stunde vor der veröffentlichten Abfahrtszeit zum Check-In zu erscheinen.
<G-vec00097-001-s256><arrive.erscheinen><en> The course participant undertakes to participate personally at the lessons and to arrive punctually.
<G-vec00097-001-s256><arrive.erscheinen><de> Der Kursteilnehmer ist verpflichtet, persönlich an den Lektionen teilzunehmen und pünktlich zu erscheinen.
<G-vec00097-001-s257><arrive.erscheinen><en> We ask you to arrive punctually, as the basement closes again after entry.
<G-vec00097-001-s257><arrive.erscheinen><de> Wir bitten Sie pünktlich zu erscheinen, da der Keller nach Einlass wieder geschlossen wird.
<G-vec00097-001-s258><arrive.erscheinen><en> At that moment Trinity forces arrive and Lara hides away inside the coffin.
<G-vec00097-001-s258><arrive.erscheinen><de> In dem Moment erscheinen die Trinity-Söldner und Lara versteckt sich im Sarg.
<G-vec00097-001-s259><arrive.erscheinen><en> Passengers shall arrive to the departure point 20 minutes before departure.
<G-vec00097-001-s259><arrive.erscheinen><de> Der Fahrgast muss 20 Minuten vor Abfahrt am Ort der Abreise erscheinen.
<G-vec00097-001-s260><arrive.erscheinen><en> Security controls can slow the access to the Palace, so it is highly recommended to arrive some time before the planned schedule.
<G-vec00097-001-s260><arrive.erscheinen><de> Die Sicherheitskontrollen könnten den Eintritt in den Palazzo möglicherweise verlangsamen, daher wird empfohlen, einige Zeit vor dem geplanten Termin zu erscheinen.
<G-vec00097-001-s261><arrive.erscheinen><en> In the event your checked bags do not arrive on your flight, reasonable efforts will be made to ensure that the bag is returned to you within 24 hours for flights within Venezuela.
<G-vec00097-001-s261><arrive.erscheinen><de> Im Falle Ihrer Gepäckstücke nicht auf Ihrem Flug nicht erscheinen, kann zumutbaren Anstrengungen zu unternehmen, um sicherzustellen, dass die Tasche, um Ihnen innerhalb von 24 Stunden für Flüge innerhalb Venezuela zurück.
<G-vec00097-001-s262><arrive.erscheinen><en> You make an appointment and arrive with an empty stomach.
<G-vec00097-001-s262><arrive.erscheinen><de> Sie vereinbaren einen Termin und erscheinen mit leerem Magen.
<G-vec00097-001-s263><arrive.erscheinen><en> Please arrive punctually, especially for guided tours outside opening times, as we cannot guarantee the tour in the case of a delay of over 15 minutes.
<G-vec00097-001-s263><arrive.erscheinen><de> Bitte erscheinen Sie insbesondere zu Führungen außerhalb der Öffnungzeiten pünktlich, da wir bei einer Verspätung von mehr als 15 Minuten die Führung nicht garantieren können.
<G-vec00097-001-s264><arrive.erscheinen><en> By the time the mother of the bride and the best man’s actual girlfriend arrive chaos reigns.
<G-vec00097-001-s264><arrive.erscheinen><de> Bis die Brautmutter und die tatsächliche Freundin des Trauzeugen auf der Bildfläche erscheinen, ist das Chaos umfassend.
<G-vec00097-001-s265><arrive.erscheinen><en> But then the long stay in the former Celestial Empire was postponed: «The Pope’s letter to the Chinese Catholics is about to arrive, and I didn’t want some storm to break over my head while I was there…».
<G-vec00097-001-s265><arrive.erscheinen><de> Dann aber wurde die Reise ins ehemalige Reich der Mitte und der Besuch bei den christlichen Gemeinschaften der Scheut-Missionare verschoben: „Der Brief des Papstes an die chinesischen Katholiken wird bald erscheinen, und ich wollte vermeiden, dass sich vielleicht über meinem Kopf ein Gewitter zusammenbraut, während ich gerade dort bin…“.
<G-vec00097-001-s323><arrive.gelangen><en> If we but ponder upon just what suppresses the higher concepts, we inevitably arrive at a consciousness which compares everything with the lower manifestations.
<G-vec00097-001-s323><arrive.gelangen><de> Wenn wir nur darüber nachdenken, was eigentlich die höheren Begriffe unterdrückt, gelangen wir unfehlbar zu einem Bewußtsein, das alles mit den niedrigen Erscheinungen vergleicht.
<G-vec00097-001-s324><arrive.gelangen><en> Fron of the church is a medieval tower, a rarity for Montepulciano, decorated on top by a Pulcinella which marks the hours sull'orologio of the city.After 100 meters you arrive at the Renaissance Loggia in the market and a fork, then left to continue the course and to the right you will arrive in Piazza Grande.
<G-vec00097-001-s324><arrive.gelangen><de> Grenzen der Kirche ist ein mittelalterlicher Turm, eine Rarität für Montepulciano, dekoriert auf eine Pulcinella, die Marken die Stunden sull'orologio der Stadt.Nach 100 Metern gelangen Sie zu den Renaissance-Loggia auf dem Markt und einer Gabel, dann links, um den Kurs und auf der rechten Seite gelangen Sie auf der Piazza Grande.
<G-vec00097-001-s325><arrive.gelangen><en> The object of the game is to arrive as close to 21 as possible and not going over.
<G-vec00097-001-s325><arrive.gelangen><de> Das Ziel des Spiels ist es, so nah wie möglich an 21 zu gelangen und nicht zu überschreiten.
<G-vec00097-001-s326><arrive.gelangen><en> He should try, with synthetical propensity, i.e. building up rather than tearing down, to arrive at an interpretation of the claim which is technically sensible and takes into account the whole disclosure of the patent.
<G-vec00097-001-s326><arrive.gelangen><de> Er sollte versuchen, durch Synthese, also eher aufbauend als zerlegend, zu einer Auslegung des Anspruchs zu gelangen, die technisch sinnvoll ist und bei der die gesamte Offenbarung des Patents berücksichtigt wird.
<G-vec00097-001-s327><arrive.gelangen><en> """[vi] After this discussion we arrive at the issue of original and copy, or production and reproduction."
<G-vec00097-001-s327><arrive.gelangen><de> """[vi] Hier gelangen wir zur Diskussion der Begriffe von Original und Kopie, oder Produktion und Reproduktion."
<G-vec00097-001-s328><arrive.gelangen><en> Following the Vis shoreline another 3 miles to the east, we will arrive to an archipelago of 8 small islands.
<G-vec00097-001-s328><arrive.gelangen><de> 3 Meilen östlich entlang der Küstenlinie von Vis, gelangen wir zu einem Archipel von 8 kleinen Inseln.
<G-vec00097-001-s329><arrive.gelangen><en> --First, this path starts from Christ’s humanity to arrive at his divinity, from history to arrive at his pre-existence. It is thus an ascending path.
<G-vec00097-001-s329><arrive.gelangen><de> - Erstens nimmt diese Betrachtung ihren Ausgang vom Menschsein Christi, um zu seiner Göttlichkeit zu gelangen; sie schließt von der Geschichte auf die Präexistenz.
<G-vec00097-001-s330><arrive.gelangen><en> Projecting all these technologies into the present, we arrive at one of the next big trends in the IT business environment, the cloud desktop.
<G-vec00097-001-s330><arrive.gelangen><de> Werden all diese Technologien in die Gegenwart projiziert, gelangen wir zu einem der nächsten großen Trends im IT-Unternehmensumfeld, den Cloud-Desktops.
<G-vec00097-001-s331><arrive.gelangen><en> It is about going through successive deaths to arrive at the summit.
<G-vec00097-001-s331><arrive.gelangen><de> Es geht darum mehrere Male zu Sterben um auf den Gipfel zu gelangen.
<G-vec00097-001-s332><arrive.gelangen><en> "Schopenhauer rightly speaks against such ""dogmatists who assume that if they only go straight forward long enough they would arrive at the end of the world""."
<G-vec00097-001-s332><arrive.gelangen><de> "Gegen solche ""Dogmatiker, welche meinen, dass, wenn sie nur recht lange geradeaus gingen, sie zu der Welt Ende gelangen würden"", kehrt sich Schopenhauer mit vollem Recht."
<G-vec00097-001-s333><arrive.gelangen><en> In order to arrive at realistic results when evaluating supra-regional freight RFQs, different capacity limits must be taken into account for different regions.
<G-vec00097-001-s333><arrive.gelangen><de> Um bei der Auswertung überregionaler Frachtausschreibungen zu realistischen Ergebnissen zu gelangen, müssen daher unterschiedliche Kapazitätsgrenzen für verschiedene Relationsbündel berücksichtigt werden.
<G-vec00097-001-s334><arrive.gelangen><en> Therefore, even if the skilled person considered applying the teaching given in the DE citation to the known shaft seal in the US citation, it would not arrive at the claimed teaching.
<G-vec00097-001-s334><arrive.gelangen><de> Folglich würde der Fachmann, selbst wenn er die Lehre dieser Entgegenhaltung auf die aus der US-Entgegenhaltung bekannte Wellendichtung anwenden würde, nicht zu der erfindungsgemäßen Lehre gelangen.
<G-vec00097-001-s335><arrive.gelangen><en> If are travelling by car, with your family or as a solo foot passenger book a ferry crossing with Linda Line Express and arrive at your destination refreshed, relaxed and happy.
<G-vec00097-001-s335><arrive.gelangen><de> Wenn Anreise mit dem Auto, mit Ihrer Familie oder als Solo-Fuß Passagier Buch eine Fährverbindung mit Linda Line Express und gelangen an Ihr Ziel aktualisiert, entspannt und glücklich.
<G-vec00097-001-s336><arrive.gelangen><en> At the midlife threshold, we arrive at a crossroads - at which stands the god of change and the god of stasis.
<G-vec00097-001-s336><arrive.gelangen><de> An der Schwelle zum mittleren Alter gelangen wir an einen Scheideweg, an dem sowohl der Gott der Veränderung als auch der Gott des Stillstandes stehen.
<G-vec00097-001-s337><arrive.gelangen><en> The dialogical way of proceeding is the path to arrive where paradigms, ways of feeling, symbols, and representations of individuals and of peoples are formed.
<G-vec00097-001-s337><arrive.gelangen><de> Die dialogische Vorgehensweise ist der Weg, um dorthin zu gelangen, wo die Paradigmen, die Empfindungsweisen, die Symbole, die Vorstellungen der Menschen und Völker Gestalt annehmen.
<G-vec00097-001-s338><arrive.gelangen><en> Our horses have the instinctive and natural behaviours that enable us to quickly arrive at what leadership is all about.
<G-vec00097-001-s338><arrive.gelangen><de> Unsere Pferde haben diejenigen instinktiven und natürlichen Verhaltensweisen, die es uns ermöglichen schnell zum Kern dessen, was Führung bedeutet, zu gelangen.
<G-vec00097-001-s339><arrive.gelangen><en> Via a long driveway, lined with trees on both sides, you arrive at camping site Les Portes du Beaujolais.
<G-vec00097-001-s339><arrive.gelangen><de> Über eine lange Auffahrt, auf beiden Seiten bewaldet, gelangen Sie auf den Camping Les Portes du Beaujolais.
<G-vec00097-001-s340><arrive.gelangen><en> The afferents from the labyrinth arrive at the vestibular nuclei of the brainstem, which also receive visual and proprioceptive input and are connected with the vestibulocerebellum (27).
<G-vec00097-001-s340><arrive.gelangen><de> Die Afferenzen aus dem Labyrinth gelangen zu den Vestibulariskernen des Hirnstamms, die auch visuelle und propriozeptive Eingänge erhalten und mit dem Vestibulocerebellum verbunden sind (27).
<G-vec00097-001-s341><arrive.gelangen><en> "In this way, the Pope said, ""we arrive at a new encounter"", one which could be called the ""encounter of gratitude"", in which we could pray in this way: ""Thank you Lord for the company you have given me, for this journey you have made with me!"". We could also ask forgiveness for the sins and mistakes that we may be aware of, knowing that God ""walks with us and is not afraid of our malevolence""; he is ""always there!""."
<G-vec00097-001-s341><arrive.gelangen><de> Auf diese Art und Weise, so sagte der Papst, »gelangen wir zu einer weiteren Begegnung«, derjenigen, die man als die »Begegnung der Dankbarkeit« bezeichnen könne, bei der man folgendermaßen beten könne: »Ich danke dir, Herr, für deine Begleitung, für diesen Weg, den du mit mir gegangen bist!«, und dabei könne man auch um Vergebung der Sünden und der Fehler bitten, deren man sich bewusst sei, der Tatsache bewusst, dass Gott »mit uns geht und sich durch unsere Gemeinheiten nicht abschrecken lässt«, dass er »immer da« sei.
<G-vec00097-001-s342><arrive.gelangen><en> From the very first moments after the triumph of the Revolution, the United States took in hundreds of dictator Fulgencio Batista's henchmen, torturers and murderers fleeing from revolutionary justice. In the more than four decades that have since passed, it has maintained the policy of protecting and sheltering any criminals who arrive in U.S. territory after committing crimes against Cuba and its people.
<G-vec00097-001-s342><arrive.gelangen><de> Die Vereinigten Staaten haben nicht nur in den ersten Augenblicken des Revolutionären Sieges Hunderte von Schergen, Folterknechten und Mördern der Batista-Tyrannei aufgenommen, die vor der revolutionären Justiz flüchteten, sondern haben während mehr als vier Jahrzehnten die Politik aufrecht erhalten, jeglichen Kriminellen, der, nachdem er Delikte gegen Kuba und sein Volk begangen hat, in nordamerikanisches Gebiet gelangt, zu schützen und ihm Unterschlupf zu gewähren.
<G-vec00097-001-s343><arrive.gelangen><en> For the determination of the obviousness or non-obviousness of claimed subject-matter, it is not decisive that teachings are known - it must be decided whether or not the skilled person would have combined the known teachings such as to arrive at the claimed subject-matter when attempting to solve the underlying technical problem.
<G-vec00097-001-s343><arrive.gelangen><de> Für die Frage, ob der beanspruchte Gegenstand naheliegend ist, kommt es nicht darauf an, ob die Lehren bekannt sind; vielmehr muss entschieden werden, ob der Fachmann beim Versuch, die zugrunde liegende technische Aufgabe zu lösen, die bekannten Lehren so miteinander kombiniert hätte, dass er zu dem beanspruchten Gegenstand gelangt wäre.
<G-vec00097-001-s344><arrive.gelangen><en> When you follow the third link in the navigation bar you arrive at a site where all members in alphabetical order [14] are listed.
<G-vec00097-001-s344><arrive.gelangen><de> Dem dritten Link in der Navigationsleiste folgend gelangt man auf eine Seite, auf der sämtliche Mitglieder in alphabetischer Reihenfolge [14] aufgelistet sind.
<G-vec00097-001-s345><arrive.gelangen><en> Rather, most cookies collect general information, such as how users arrive at and use the Sites, or a user's general location.
<G-vec00097-001-s345><arrive.gelangen><de> Die meisten Cookies erfassen vielmehr allgemeine Informationen, zum Beispiel wie ein Benutzer zur Website gelangt ist und diese verwendet, oder den allgemeinen Standort des Benutzers.
<G-vec00097-001-s346><arrive.gelangen><en> A part of the water samples taken in the Nuremberg conurbation arrive at the team led by Peter Daum in the Municipal Water Treatment and Environmental Analysis Laboratory Nuremberg, Germany.
<G-vec00097-001-s346><arrive.gelangen><de> Ein Teil der im Großraum Nürnberg entnommenen Wasserproben gelangt zum Team von Peter Daum bei der Stadtentwässerung und Umweltanalytik Nürnberg.
<G-vec00097-001-s347><arrive.gelangen><en> Continuing along Via Po we arrive at the Mole Antonelliana, symbolic monument of Turin home to the National Cinema Museum. We’ll take the glass lift for a panoramic view from the top.
<G-vec00097-001-s347><arrive.gelangen><de> Der Via Po’ folgend, gelangt man zur Mole Antonelliana, einem gewaltigen Turm, der zum Symbol Turins wurde und in dem sich heute das Nationale Kinomuseum befindet.
<G-vec00097-001-s348><arrive.gelangen><en> All this arrive at the worst one moment, when the world feels more and more difficulty increasing its capacities of oil production due to the lack of new discoveries.
<G-vec00097-001-s348><arrive.gelangen><de> All dies gelangt zu schlechtestem Zeitpunkt, wenn die Welt immer mehr Schwierigkeit hat, ihre Kapazitäten von ölproduktion in Ermangelung neuer Entdeckungen zu erhöhen.
<G-vec00097-001-s349><arrive.gelangen><en> To reach Cozumel you must take a ferry from Playa del Carmen, which will arrive in just forty minutes.
<G-vec00097-001-s349><arrive.gelangen><de> Um hierher zu gelangen, muss man eine Fähre von Playa del Carmen nehmen, die in nur vierzig Minuten ans Ziel gelangt.
<G-vec00097-001-s350><arrive.gelangen><en> Go through the door to arrive in another room.
<G-vec00097-001-s350><arrive.gelangen><de> Durch den Geheimgang gelangt sie auf den Dachboden.
<G-vec00097-001-s351><arrive.gelangen><en> Still looking at the sea, you arrive at the old Casino, which has been converted into the City Hall.
<G-vec00097-001-s351><arrive.gelangen><de> Stets mit Blick auf das Meer gelangt man zum früheren Casino, in dem heute das Rathaus untergebracht ist.
<G-vec00097-001-s352><arrive.gelangen><en> People arrive at the head of the port by passing a sequence of squares with small shops and cafes.
<G-vec00097-001-s352><arrive.gelangen><de> "Über eine Sequenz von Plätzen mit kleinen Geschäften und Cafés gelangt man zum Hafenkopf, der vom Solitärbau des ""Wissen-Wasser-Zentrums"" dominiert wird."
<G-vec00097-001-s353><arrive.gelangen><en> "The installation under Windows ME for both parts runs automatically and smoothly and you arrive in the ""character selction"" menu."
<G-vec00097-001-s353><arrive.gelangen><de> "Die Installation unter Windows ME läuft bei beiden Teilen automatisch und reibungslos ab und man gelangt ins Menü ""Charakter wählen""."
<G-vec00097-001-s354><arrive.gelangen><en> Heading west from here, after about four kilometres you arrive at the little square and the entrance to the famous Blue Grotto, a marine gem, a ravine with a magical atmosphere, which was known to the ancient Romans.
<G-vec00097-001-s354><arrive.gelangen><de> Von hier aus gelangt man über den Westhang der Insel nach etwa vier Kilometern auf den Platz, wo sich der Eingang zur berühmten Blauen Grotte befindet, einem Juwel des Meeres, einer Kluft mit einer zauberhaften Atmosphäre, die bereits den alten Römern bekannt war.
<G-vec00097-001-s355><arrive.gelangen><en> but Israel, following after a law of righteousness, didn't arrive at the law of righteousness.
<G-vec00097-001-s355><arrive.gelangen><de> Israel aber, das einem Gesetz der Gerechtigkeit nachstrebte, ist nicht zum Gesetz gelangt.
<G-vec00097-001-s356><arrive.gelangen><en> From the refuge, you arrive quickly on the site of the Etang du Devin, unusual peat bog.
<G-vec00097-001-s356><arrive.gelangen><de> Von der Hütte, gelangt man schnell auf dem Gelände des Etang du Devin, ungewöhnliche Moor.
<G-vec00097-001-s357><arrive.gelangen><en> The entrance leads to a presentation depot with an area of around 600 m² after which visitors arrive in the painting and sculpture section.
<G-vec00097-001-s357><arrive.gelangen><de> Das formal anspruchsvolle, stringente Architekturkonzept von querkraft besteht aus vier markanten Baukörpern: Der Zugang führt an einem Schaudepot mit einer Fläche von rund 600 m² entlang, danach gelangt der Besucher in den Trakt für Malerei und Plastik.
<G-vec00097-001-s358><arrive.gelangen><en> The Trojan is known to arrive as a randomly named .dll file.
<G-vec00097-001-s358><arrive.gelangen><de> Es ist bekannt, dass der Trojaner als eine willkürlich benannte .dll-Datei ins System gelangt.
<G-vec00097-001-s359><arrive.gelangen><en> This means that if you arrive at our website via a Microsoft Bing ad, a cookie will be placed on your computer.
<G-vec00097-001-s359><arrive.gelangen><de> Dabei wird von Microsoft Bing Ads ein Cookie auf Ihrem Rechner gesetzt, sofern Sie über eine Microsoft Bing Anzeige auf unsere Website gelangt sind.
<G-vec00097-001-s360><arrive.gelangen><en> There is a tendency, though, to limit the debate to the legislative aspect of the question of crime and punishment or to the judicial process – how best to arrive swiftly at a sentence that corresponds as closely as possible to the true facts.
<G-vec00097-001-s360><arrive.gelangen><de> Es gibt jedoch eine Tendenz, die Debatte auf den legislativen Aspekt der Frage nach Verbrechen und Strafe oder auf den Gerichtsprozeß zu beschränken, das heißt wie man am besten zu einem raschen Urteil gelangt, das den wahren Tatsachen weitestgehend entspricht.
<G-vec00097-001-s380><arrive.kommen><en> But I arrive well in La Paz with all my luggage, including 1 Kg of cheese and lots of dried meet...
<G-vec00097-001-s380><arrive.kommen><de> Aber ich komme gut in La Paz an, inklusive allem Gepäck, unter anderem 1 Kg Käse und viel Trockenfleisch... .
<G-vec00097-001-s381><arrive.kommen><en> FAQ – bus and transport from Dublin airport Q: I arrive late at the airport.
<G-vec00097-001-s381><arrive.kommen><de> HGF – Busse und Transporte vom Flughafen Dublin F: Ich komme spät am Flughafen an.
<G-vec00097-001-s382><arrive.kommen><en> 10:38 [628] I arrive at the visitor parking space at SRI International in Menlo Park.
<G-vec00097-001-s382><arrive.kommen><de> 10:38 [628] Ich komme am Besucherparkplatz von SRI International in Menlo Park an.
<G-vec00097-001-s383><arrive.kommen><en> And yet I will arrive suddenly and unexpected even for My Own....
<G-vec00097-001-s383><arrive.kommen><de> Und doch komme Ich plötzlich und unerwartet auch für die Meinen....
<G-vec00097-001-s384><arrive.kommen><en> "First, the bus was supposed to arrive in five minutes, then it was three minutes, then eight minutes and there were no further announcements"" one of the passengers says."
<G-vec00097-001-s384><arrive.kommen><de> "Der Bus komme in fünf Minuten, dann wieder in drei Minuten, dann nochmal acht Minuten später, ohne jede weitere Ansage"", erzählt eine Passagierin dem Abendblatt."
<G-vec00097-001-s385><arrive.kommen><en> I arrive at the principle of Lavoisier on the conservation of mass.
<G-vec00097-001-s385><arrive.kommen><de> Ich komme jetzt zu dem Prinzip von Lavoisier über die Erhaltung der Massen.
<G-vec00097-001-s386><arrive.kommen><en> Their traditionalist opponents think there is no rush, and it should be done by the Jewish Messiah of Vengeance, whenever he will arrive.
<G-vec00097-001-s386><arrive.kommen><de> Ihre traditionalistischen Gegner sind der Ansicht, es eile nicht und dies solle durch den jüdischen Messias der Rache erledigt werden, wann auch immer dieser komme.
<G-vec00097-001-s387><arrive.kommen><en> FAQ – bus and transport from Beauvais–Tillé airport Q: I arrive late at the airport.
<G-vec00097-001-s387><arrive.kommen><de> Häufig gestellte Fragen – Bus und Transport vom Flughafen Beauvais-Tillé Frage: Ich komme spät am Flughafen an.
<G-vec00097-001-s388><arrive.kommen><en> 13 Until I arrive, attend to reading, to exhortation, and to doctrine.
<G-vec00097-001-s388><arrive.kommen><de> 13 Halte an mit Lesen, mit Ermahnen, mit Lehren, bis ich komme.
<G-vec00097-001-s389><arrive.kommen><en> Arrive home some time before and usually open up a bottle of beer while cooking.
<G-vec00097-001-s389><arrive.kommen><de> Ungefähr um diese Zeit komme ich zu Hause an und öffne meistens während des Kochens eine Flasche Bier.
<G-vec00097-001-s390><arrive.kommen><en> """Without these, I arrive at no form."
<G-vec00097-001-s390><arrive.kommen><de> """Ohne sie komme ich zu keiner Form."
<G-vec00097-001-s391><arrive.kommen><en> FAQ – bus and transport from Chopin Airport Q: I arrive late at the airport.
<G-vec00097-001-s391><arrive.kommen><de> HGF: Bus und andere Verkehrsmittel vom Chopin- Flughafen Warschau F: Ich komme spät am Flughafen an.
<G-vec00097-001-s392><arrive.kommen><en> A description of how I arrive there I spare you.
<G-vec00097-001-s392><arrive.kommen><de> Eine Beschreibung wie ich dort dann angekrochen komme, erspare ich euch.
<G-vec00097-001-s393><arrive.kommen><en> 11:58 [142] I arrive at the NBC Studios and buy a tour ticket for the 13:00 tour.
<G-vec00097-001-s393><arrive.kommen><de> 11:58 [142] Ich komme an den NBC-Studios an und kaufe ein Ticket für die Studiotour um 13:00.
<G-vec00097-001-s394><arrive.kommen><en> FAQ – bus and transport from Verona airport Q: I arrive late at the airport.
<G-vec00097-001-s394><arrive.kommen><de> Häufig gestellte Fragen- Bus und andere Verkehrsmittel vom Flughafen Verona Frage: Ich komme spät am Flughafen an.
<G-vec00097-001-s395><arrive.kommen><en> I arrive in Arboga on a sunny Sunday morning in late August.
<G-vec00097-001-s395><arrive.kommen><de> Ich komme in Arboga an einem sonnigen Sonntagmorgen Ende August.
<G-vec00097-001-s396><arrive.kommen><en> I arrive at the venue at 9 or 10 o´clock in the morning and I leave the venue at 10.30 when I’m finished.
<G-vec00097-001-s396><arrive.kommen><de> Ich komme um 9 oder 10 Uhr am Morgen beim Club an und verlasse den Club um 10:30 Uhr, wenn ich fertig bin.
<G-vec00097-001-s397><arrive.kommen><en> Each morning, before I arrive at the stables, I make a plan for the whole day which outlines the team’s responsibilities.
<G-vec00097-001-s397><arrive.kommen><de> Jeden Morgen bevor ich in den Stall komme erstelle ich einen Tagesplan, der die einzelnen Aufgaben und Verantwortungsbereiche des Teams enthält.
<G-vec00097-001-s398><arrive.kommen><en> The traffic is usable, after less than an hour I arrive at the Dewitt Hotels&Suites near the Hancock Tower.
<G-vec00097-001-s398><arrive.kommen><de> Der Verkehr ist brauchbar, nach einer knappen Stunde komme ich bei den Dewitt Hotels&Suites in der Nähe des Hancock Towers an.
<G-vec00097-001-s399><arrive.kommen><en> For I will not leave you, My faithful Own, without help, and in order that you will remain strong I announce this light, this voice, in advance, and then you will know that I will soon arrive in order to fetch you, in order to put an end to My adversary's activity, in order to help truth achieve its final victory....
<G-vec00097-001-s399><arrive.kommen><de> Denn Ich lasse euch, Meine Getreuen, nicht ohne Hilfe, und auf daß ihr stark bleibet, künde Ich euch dieses Licht, diesen Rufer, an, und dann wisset ihr auch, daß Ich bald kommen werde, um euch zu holen, um dem Treiben Meines Gegners ein Ende zu bereiten, um der Wahrheit zum endgültigen Siege zu verhelfen....
<G-vec00097-001-s400><arrive.kommen><en> We arrive at the monument to Unamuno by taking the FV-10 road towards Puerto del Rosario and then branching off on the FV-207 road to Betancuria .
<G-vec00097-001-s400><arrive.kommen><de> Wir kommen am Denkmal für Unamuno durch die FV-10 Straße in Richtung nehmen Puerto del Rosario und dann auf der FV-207 Straße zum Abzweigen Betancuria .
<G-vec00097-001-s401><arrive.kommen><en> If you arrive by plane
<G-vec00097-001-s401><arrive.kommen><de> Wenn Sie mit dem Flugzeug kommen...
<G-vec00097-001-s402><arrive.kommen><en> After several sharp hills, we arrive in Ravna Gora (40.0 km).
<G-vec00097-001-s402><arrive.kommen><de> Nach einigen sehr steilen Steigungen und ebensolchen Gefällen kommen wir wieder nach Ravna Gora (40,0 km).
<G-vec00097-001-s403><arrive.kommen><en> Even the advanced sections of the class had no clear idea by which roads it was possible to arrive at the power.
<G-vec00097-001-s403><arrive.kommen><de> Nicht einmal der fortgeschrittene Teil der Klasse gab sich Rechenschaft darüber, auf welchem Wege man zur Macht kommen könne.
<G-vec00097-001-s404><arrive.kommen><en> After all, you see the trends of the sporting goods industry here long before they arrive in the shops – and as a non-trade visitor, you don't usually make it to the business trade fair.
<G-vec00097-001-s404><arrive.kommen><de> Schließlich sieht man hier die Trends der Sportartikel-Industrie, lange bevor sie in die Läden kommen – und als Nicht-Fachbesucher schafft man es normalerweise nicht auf die Business-Messe.
<G-vec00097-001-s405><arrive.kommen><en> Thousands arrive in every month.
<G-vec00097-001-s405><arrive.kommen><de> Weitere Tausende kommen jeden Monat an.
<G-vec00097-001-s406><arrive.kommen><en> When we contact the pulsating principle of expansion and contraction, we arrive at the bisyllabic sound of OM.
<G-vec00097-001-s406><arrive.kommen><de> Wenn wir das pulsierende Prinzip von Ausdehnung und Zusammenziehung berühren, kommen wir zu dem zweisilbigen Klang des OM.
<G-vec00097-001-s407><arrive.kommen><en> Train trips arrive in Hazlehurst at 1 stations, depending on which train line you are travelling with.
<G-vec00097-001-s407><arrive.kommen><de> Zug Verbindungen kommen in Hazlehurst an 1 Haltestellen an, je nachdem mit welchem zug Anbieter du reist.
<G-vec00097-001-s408><arrive.kommen><en> Train trips arrive in Munster at 1 stations, depending on which train line you are travelling with.
<G-vec00097-001-s408><arrive.kommen><de> Zug Verbindungen kommen in Munster an 1 Haltestellen an, je nachdem mit welchem zug Anbieter du reist.
<G-vec00097-001-s409><arrive.kommen><en> During the night, thousands of local pilgrims, who traditionally come on foot, continued to arrive from Herzegovina and from Croatia.
<G-vec00097-001-s409><arrive.kommen><de> Während der ganzen Nacht drängten einheimische Pilger, die traditionell zur Jahresfeier in Fußwallfahrten kommen, aus Kroatien und Herzegowina herbei.
<G-vec00097-001-s410><arrive.kommen><en> Bus trips arrive in Vienna at 5 stations, depending on which bus line you are traveling with.
<G-vec00097-001-s410><arrive.kommen><de> Bus Verbindungen kommen in Wien an 5 Haltestellen an, je nachdem mit welchem Bus -Anbieter du reist.
<G-vec00097-001-s411><arrive.kommen><en> Morten & Magne arrive from Oslo, Paul flies in from New York.
<G-vec00097-001-s411><arrive.kommen><de> Morten & Magne kommen von Oslo, Paul fliegt von New York ein.
<G-vec00097-001-s412><arrive.kommen><en> When the innkeeper heard such, he hurried outside to his people and drew their attention to it; and they now paid attention, if the guest would arrive.
<G-vec00097-001-s412><arrive.kommen><de> Als der Wirt solches vernahm, da eilte er alsbald hinaus zu seinen Leuten und machte sie darauf aufmerksam; und die gaben nun acht, ob wohl Gäste kommen möchten.
<G-vec00097-001-s413><arrive.kommen><en> We arrive in Copiapo, where everything was going to arrive ralye DAKAR.
<G-vec00097-001-s413><arrive.kommen><de> Wir kommen in Copiapo, wo alles wollte ralye DAKAR ankommen.
<G-vec00097-001-s414><arrive.kommen><en> Overseas visitors arrive by air via Halifax, NS and Toronto, ON.
<G-vec00097-001-s414><arrive.kommen><de> Besucher aus Übersee kommen meist über Halifax, NS oder Toronto, ON an.
<G-vec00097-001-s415><arrive.kommen><en> Train trips arrive in Lancaster at 1 stations, depending on which train line you are travelling with.
<G-vec00097-001-s415><arrive.kommen><de> Zug Verbindungen kommen in Lancaster an 1 Haltestellen an, je nachdem mit welchem zug Anbieter du reist.
<G-vec00097-001-s416><arrive.kommen><en> Train trips arrive in Opheusden at 1 stations, depending on which train line you are traveling with.
<G-vec00097-001-s416><arrive.kommen><de> Zug Verbindungen kommen in Opheusden an 1 Haltestellen an, je nachdem mit welchem zug Anbieter du reist.
<G-vec00097-001-s417><arrive.kommen><en> When we go to Mass, perhaps we arrive five minutes early and begin to chat with the person next to us.
<G-vec00097-001-s417><arrive.kommen><de> Und wenn wir in die Messe gehen, dann kommen wir vielleicht fünf Minuten vorher und beginnen mit unserem Nachbarn zu schwatzen.
<G-vec00097-001-s418><arrive.kommen><en> It only proves that SaverAddon does not arrive onto your computer alone.
<G-vec00097-001-s418><arrive.kommen><de> Es beweist nur, dass SaverAddon kommt nicht auf Ihren Computer allein.
<G-vec00097-001-s419><arrive.kommen><en> After passing under the railway, you arrive at a traffic light.
<G-vec00097-001-s419><arrive.kommen><de> Nach dem Passieren unter der Bahn kommt man an einer Ampel.
<G-vec00097-001-s420><arrive.kommen><en> It is a totally different possibility to receive people. You arrive, sit down and have a drink together.
<G-vec00097-001-s420><arrive.kommen><de> Eine ganz andere Möglichkeit, Menschen zu empfangen: Man kommt an, setzt sich und trinkt erst einmal etwas zusammen.
<G-vec00097-001-s421><arrive.kommen><en> Continuing towards Roncoferraro, you`ll arrive at the small village of Villa Garibaldi with the nineteenth century Villa Nuvolari, and Villa Ramaschi from the sixteenth century.
<G-vec00097-001-s421><arrive.kommen><de> Fährt man weiter in Richtung Roncoferraro, kommt man in Villa Garibaldi an, wo sich die Nuvolari-Villa aus dem neunzehnten Jahrhundert, sowie die Ramaschi-Villa aus dem sechzehnten Jahrhundert befinden.
<G-vec00097-001-s422><arrive.kommen><en> In fact arriving to Naples, it means to arrive in the capital of the Kingdom of Two Sicilies, which, with its fortifications 4 (Castelnuovo Male or Angevin, Castel dell 'Ovo, Castel Capuano and Castel Sant' Elmo) and 4 royal palaces (Palazzo Reale, Reggia di Capodimonte, Royal Palace of Portici and Reggia di Caserta), dazzle us with its beauties.
<G-vec00097-001-s422><arrive.kommen><de> In der Tat wenn man in Neapel ankommt kommt man, mit seine vier Befestigungsanlagen (der Castelnuovo oder der Maschio Angioino, Castel dell'Ovo, Castel Capuano und Castel Sant'Elmo) und seine vier königlichen Paläste (der Palazzo Reale, die Reggia von Capodimonte, die Reggia von Portici und die Reggia von Caserta), in die Hauptstadt des Königreichs beider Sizilien an.
<G-vec00097-001-s423><arrive.kommen><en> The next delegation, which will arrive here tomorrow from the United States of America, will conduct a talk with you on economic cooperation between our countries.
<G-vec00097-001-s423><arrive.kommen><de> Und die nächste Delegation, die morgen aus den USA kommt, wird mit Ihnen ein Gespräch zum Thema wirtschaftlicher Zusammenarbeit zwischen unseren Ländern führen.
<G-vec00097-001-s424><arrive.kommen><en> In August the second generation of migrants arrive or the first generation of imagos of our young admirals hatch, having developed on nettle leaves.
<G-vec00097-001-s424><arrive.kommen><de> Im August kommt die zweite Generation der Migranten an oder die erste Generation der Imagines unserer jungen Admirale schlüpft, nachdem sie sich auf Brennnesselblättern entwickelt haben.
<G-vec00097-001-s425><arrive.kommen><en> For you can always know yourselves loved by Him, Who through suffering and adversity only wants to win you for Himself, Who wants to purify your soul and time and again provides it with the opportunity to practise patience and gentleness, so that God's help will then visibly arrive, so that His love will visibly intervene and also heal all wounds when the time is right....
<G-vec00097-001-s425><arrive.kommen><de> Denn ihr könnet euch immer geliebt wissen von Ihm, Der nur durch Leid und Not euch selbst gewinnen will für Sich, Der eure Seele läutern will und ihr immer wieder Gelegenheit gibt, sich in Geduld und Sanftmut zu erproben, auf daß dann die Hilfe Gottes sichtlich kommt, auf daß Seine Liebe sichtlich eingreifet und Er auch alle Wunden heilet zur rechten Zeit....
<G-vec00097-001-s426><arrive.kommen><en> There is a short climb and at another junction you take the right; beside you there is an enormous hole. You cross a small football field and join a path on the left to arrive at the church in Verezzi (which has a water fountain).
<G-vec00097-001-s426><arrive.kommen><de> Dem Weg folgen, der nach Borgio ansteigt, sich rechts haltend, nach einem kurzen Anstieg kommt eine Abzweigung, an der man rechts fährt Am Rande des Fussballfeldes den linken Weg einschlagen, der zur Kirche von Verezzi führt.
<G-vec00097-001-s427><arrive.kommen><en> A scenario which you do not even want to think about: you arrive home from doing sport, go to the refrigerator because you are extremely thirsty and take a bottle of fruit juice.
<G-vec00097-001-s427><arrive.kommen><de> Ein Szenario, das man sich gar nicht vorstellen möchte: Man kommt vom Sport, hat geschwitzt und um den ersten Durst zu stillen, geht man zum Kühlschrank und greift sich die Flasche mit dem Fruchtsaft.
<G-vec00097-001-s428><arrive.kommen><en> You arrive at the end of the tow lift at the Schneeflucht.
<G-vec00097-001-s428><arrive.kommen><de> Man kommt am Ende des Schlepplifts an der Schneeflucht an.
<G-vec00097-001-s429><arrive.kommen><en> """In astroparticle physics, we mostly have to rely on assumptions and indications. For the first time now, it is significant that a preferred direction exists from which the rays arrive. This is a very important step in our research,"" says Dr. Markus Roth, Deputy Head of the Pierre Auger Group of KIT's Institute for Nuclear Physics."
<G-vec00097-001-s429><arrive.kommen><de> """In der Astroteilchenphysik sind wir zumeist auf Vermutungen und Indizien angewiesen, jetzt ist erstmals signifikant, dass es eine Vorzugsrichtung gibt, aus der die Strahlung kommt, das bedeutet einen sehr großen Schritt für unsere Forschung"", betont Dr. Markus Roth, stellvertretender Leiter der Gruppe Pierre Auger am Institut für Kernphysik des KIT."
<G-vec00097-001-s430><arrive.kommen><en> You arrive on the island and get a really harsh welcome..
<G-vec00097-001-s430><arrive.kommen><de> Ihr kommt auf dieser Insel an und werdet sehr unfreundlich willkommen geheißen.
<G-vec00097-001-s431><arrive.kommen><en> At the moment only birds that have been breeding here gather in Estonia, but in September great numbers arrive from the north as well as from the northeast.
<G-vec00097-001-s431><arrive.kommen><de> Zur Zeit sammeln sich hier in Estland nur die Vögel, die hier gebrütet haben, aber im September kommt eine große Anzahl aus dem Norden sowie aus dem Nordosten.
<G-vec00097-001-s432><arrive.kommen><en> A small number arrive in addition from the north and east, sometimes also roaming individuals from the south – the greater part are young birds, they have a greater appetite for roaming about: the world waits to be discovered.
<G-vec00097-001-s432><arrive.kommen><de> Eine kleine Zahl kommt zusätzlich aus dem Norden und Osten, manchmal auch umherziehende Individuen aus dem Süden - der größere Teil sind junge Vögel, sie haben einen größeren Appetit herumzuziehen: die Welt wartet darauf entdeckt zu werden.
<G-vec00097-001-s433><arrive.kommen><en> That with the colours is curious: We asked a producer for some prototypes forour own madunish productline and they promise to deliver in two weeks - we arranged everything for tests and than nothing arrive.
<G-vec00097-001-s433><arrive.kommen><de> Also das mit der Farbe ist seltsam, da fordert man von einem Herrsteller extra Prototypen für die eigene madunische Produktserie an und die Versprechen inzwei Wochen zu liefern - man bereitet alles für Tests vor und dann kommt nichts.
<G-vec00097-001-s434><arrive.kommen><en> I wish pure thought be the language with which you communicate with your brothers who dwell in the spiritual; that it be in that form, that you understand each other, and that your merits and good works be truly useful to them, as well as that the influence of those of My children, their inspiration and protection of you, be a powerful assistance in your journey to arrive united to Me.
<G-vec00097-001-s434><arrive.kommen><de> Ich will, dass reine Gedanken die Sprache sein sollen, in der ihr euch mit euren Geschwistern verständigt, die im Geistigen wohnen, dass ihr euch auf diese Weise versteht, und wahrlich, eure Verdienste und eure guten Werke werden für sie von Nutzen sein; ebenso wie der Einfluss jener meiner Kinder, ihre Inspirationen und ihr Schutz für euch eine machtvolle Hilfe auf eurem Lebensweg sein werden, damit ihr gemeinsam zu Mir kommt.
<G-vec00097-001-s435><arrive.kommen><en> And the third biggest group arrive from the British islands adding up to 900.000 travellers per year after all.
<G-vec00097-001-s435><arrive.kommen><de> Und die drittgrößte Gruppe kommt von den britischen Inseln, was immerhin 900.000 Reisende pro Jahr ausmacht.
<G-vec00097-001-s436><arrive.kommen><en> It’s still very difficult to make contact with people when you arrive in Austria.
<G-vec00097-001-s436><arrive.kommen><de> Es ist immer noch so schwierig, Kontakt zu haben, wenn man nach Österreich kommt.
<G-vec00097-001-s437><arrive.landen><en> Flights Frankfurt — Marrakech arrive at the following airports: Marrakech .
<G-vec00097-001-s437><arrive.landen><de> Flüge Frankfurt-am-Main – Marrakesch landen in den folgenden Flughäfen: Marrakesch-Menara.
<G-vec00097-001-s438><arrive.landen><en> Flights Perm — Ufa arrive at the following airports: Ufa .
<G-vec00097-001-s438><arrive.landen><de> Flüge Perm – Schardscha landen in den folgenden Flughäfen: Schardscha.
<G-vec00097-001-s439><arrive.landen><en> Flights Warsaw — Malaga arrive at the following airports: Malaga .
<G-vec00097-001-s439><arrive.landen><de> Flüge Warschau – Malaga landen in den folgenden Flughäfen: Internacional de Malaga.
<G-vec00097-001-s440><arrive.landen><en> Flights London — Pisa arrive at the following airports: Pisa .
<G-vec00097-001-s440><arrive.landen><de> Flüge London – Pisa landen in den folgenden Flughäfen: Galileo Galilei.
<G-vec00097-001-s441><arrive.landen><en> Flights Nizhniy Novgorod — Frankfurt arrive at the following airports: Frankfurt .
<G-vec00097-001-s441><arrive.landen><de> Flüge Nizhniy Novgorod – Ajman City landen in den folgenden Flughäfen: Ajman City.
<G-vec00097-001-s442><arrive.landen><en> Flights Jinan — Guangzhou arrive at the following airports: Guangzhou .
<G-vec00097-001-s442><arrive.landen><de> Flüge Jinan – Guangzhou landen in den folgenden Flughäfen: Guangzhou Baiyun International.
<G-vec00097-001-s443><arrive.landen><en> Flights Portland, Oregon — Amsterdam arrive at the following airports: Amsterdam .
<G-vec00097-001-s443><arrive.landen><de> Flüge Portland, Oregon – Amsterdam landen in den folgenden Flughäfen: Schiphol.
<G-vec00097-001-s444><arrive.landen><en> Flights Stuttgart — Barnaul arrive at the following airports: Barnaul .
<G-vec00097-001-s444><arrive.landen><de> Flüge Alicante – Barnaul landen in den folgenden Flughäfen: Barnaul.
<G-vec00097-001-s445><arrive.landen><en> Flights Simferopol — Nizhniy Novgorod arrive at the following airports: Nizhniy Novgorod .
<G-vec00097-001-s445><arrive.landen><de> Flüge Simferopol – Nizhniy Novgorod landen in den folgenden Flughäfen: Strigino.
<G-vec00097-001-s446><arrive.landen><en> Flights Hangzhou — Chongqing arrive at the following airports: Chongqing .
<G-vec00097-001-s446><arrive.landen><de> Flüge Hangzhou – Chongqing landen in den folgenden Flughäfen: Chongqing.
<G-vec00097-001-s447><arrive.landen><en> Airports where Buenos Aires - London flights land Flights Buenos Aires — London arrive at the following airports: London .
<G-vec00097-001-s447><arrive.landen><de> Ankunftsflughäfen, für Flüge Buenos Aires – London Flüge Buenos Aires – London landen in den folgenden Flughäfen: London City, Gatwick, Heathrow, Stansted.
<G-vec00097-001-s448><arrive.landen><en> Flights Alicante — Dresden arrive at the following airports: Dresden .
<G-vec00097-001-s448><arrive.landen><de> Flüge Alicante – Dresden landen in den folgenden Flughäfen: Dresden.
<G-vec00097-001-s449><arrive.landen><en> Flights Long Beach — Las Vegas, Nevada arrive at the following airports: Las Vegas, Nevada .
<G-vec00097-001-s449><arrive.landen><de> Flüge Long Beach – Las Vegas, Nevada landen in den folgenden Flughäfen: Las Vegas, North Las Vegas Air Terminal.
<G-vec00097-001-s450><arrive.landen><en> Flights Dusseldorf — Olbia arrive at the following airports: Olbia .
<G-vec00097-001-s450><arrive.landen><de> Flüge Düsseldorf – Antalya landen in den folgenden Flughäfen: Costa Smeralda.
<G-vec00097-001-s451><arrive.landen><en> Flights Duisburg — Vilnius arrive at the following airports: Vilnius .
<G-vec00097-001-s451><arrive.landen><de> Flüge Adler Sotschi – Wilna landen in den folgenden Flughäfen: Vilnius.
<G-vec00097-001-s452><arrive.landen><en> Flights Stuttgart — Sochi arrive at the following airports: Sochi .
<G-vec00097-001-s452><arrive.landen><de> Flüge Kirov Pobedilovo – Adler Sotschi landen in den folgenden Flughäfen: Flughafen Sotschi.
<G-vec00097-001-s453><arrive.landen><en> Flights Ekaterinburg — Bratislava arrive at the following airports: Bratislava .
<G-vec00097-001-s453><arrive.landen><de> Flüge Sankt Petersburg – Breslau landen in den folgenden Flughäfen: Wroclaw.
<G-vec00097-001-s454><arrive.landen><en> Flights Dusseldorf — Birmingham arrive at the following airports: Birmingham .
<G-vec00097-001-s454><arrive.landen><de> Flüge Düsseldorf – Birmingham landen in den folgenden Flughäfen: Birmingham International.
<G-vec00097-001-s455><arrive.landen><en> Flights Almaty — Zhezkazgan arrive at the following airports: Zhezkazgan .
<G-vec00097-001-s455><arrive.landen><de> Flüge Almaty – Zhezkazgan landen in den folgenden Flughäfen: Zhezkazgan.
<G-vec00217-002-s095><arrive.ankommen><en> If you survive and arrive at Sutter’s Fort, the adventure is still only half over!
<G-vec00217-002-s095><arrive.ankommen><de> Wenn du überlebst und in Sutter’s Fort ankommst, ist das Abenteuer aber noch nicht zu Ende.
<G-vec00217-002-s096><arrive.ankommen><en> Another option is you book a bed or a room at a hostel in the city so you have somewhere to stay when you arrive.
<G-vec00217-002-s096><arrive.ankommen><de> Eine weitere Möglichkeit ist, ein Bett oder ein Zimmer in einem Hostel in der Stadt zu buchen, damit du eine Unterkunft hast, wenn du ankommst.
<G-vec00217-002-s097><arrive.ankommen><en> And this is how it works: As soon as you arrive the girls will present themselves (sometimes even by standing up) and you tell the manager which one you would like.
<G-vec00217-002-s097><arrive.ankommen><de> Und so läuft es ab: Sobald du ankommst, präsentieren sich die Girls (manchmal sogar, in dem sie sich der Reihe nach aufstellen) und du sagst dem Manager, welche du gerne hättest.
<G-vec00217-002-s098><arrive.ankommen><en> If you arrive early there are plenty of things to see and do in this amazing city.
<G-vec00217-002-s098><arrive.ankommen><de> Falls du frühzeitig ankommst, warten in dieser atemberaubenden Stadt unzählige Sehenswürdigkeiten und Aktivitäten auf dich.
<G-vec00217-002-s099><arrive.ankommen><en> The immensity is overwhelming, even from the plane before you arrive.
<G-vec00217-002-s099><arrive.ankommen><de> Die Unermesslichkeit ist überwältigend, selbst vom Flugzeug aus, bevor du ankommst.
<G-vec00217-002-s100><arrive.ankommen><en> When you arrive someone might chat to you and ask if you have been to a meeting before.
<G-vec00217-002-s100><arrive.ankommen><de> Wenn du ankommst kann es sein, dass du angesprochen und gefragt wirst, ob das dein erstes Meeting ist.
<G-vec00217-002-s101><arrive.ankommen><en> If you arrive early, take some time to explore the city, known for its pleasant, friendly atmosphere.
<G-vec00217-002-s101><arrive.ankommen><de> Wenn du frühzeitig ankommst, nimm dir etwas Zeit, um die Stadt zu erkunden, die für ihre schöne, freundliche Atmosphäre bekannt ist.
<G-vec00217-002-s102><arrive.ankommen><en> The more times you get it, the more coins you will receive and the more hours you will spend jumping, until the sun goes down or you arrive the same night.
<G-vec00217-002-s102><arrive.ankommen><de> Je öfter du es bekommst, desto mehr Münzen erhältst du und desto mehr Stunden wirst du verbringen, bis die Sonne untergeht oder du in derselben Nacht ankommst.
<G-vec00217-002-s103><arrive.ankommen><en> Once you arrive at a yoga or Pilates studio you're interested in trying out, talk to the instructor about your goals and what you're looking for in a class.
<G-vec00217-002-s103><arrive.ankommen><de> Rede mit dem Lehrer über deine Ziele und wonach du in einem Kurs suchst, wenn du in einem Yoga- oder Pilates-Studio ankommst, das du ausprobieren möchtest.
<G-vec00217-002-s104><arrive.ankommen><en> 2 reviews Whenever you arrive expecting you fully equipped accommodation.
<G-vec00217-002-s104><arrive.ankommen><de> Wann auch immer du ankommst erwartet dich eine voll ausgestattete Unterkunft.
<G-vec00217-002-s105><arrive.ankommen><en> If you don’t have one, you can just grab one when you arrive.
<G-vec00217-002-s105><arrive.ankommen><de> Wenn du keinen hast, besorg dir einen wenn du ankommst.
<G-vec00217-002-s106><arrive.ankommen><en> Tell your prospective hosts when you'll arrive, why you'd like to meet them, and how long you'll be staying.
<G-vec00217-002-s106><arrive.ankommen><de> Sage deinem zukünftigen Gastgeber, wann du ankommst, warum du ihn treffen willst und wie lange du bleibst.
<G-vec00217-002-s107><arrive.ankommen><en> Before the participants arrive to Spain, they should check which services are covered by the EHIC in Spain.
<G-vec00217-002-s107><arrive.ankommen><de> Bevor Du in Spanien ankommst, solltest Du überprüfen, welche Leistungen von der EHIC abgedeckt werden.
<G-vec00217-002-s108><arrive.ankommen><en> When you arrive, the front desk will direct you to the Welcome Center just to the right of the main entrance.
<G-vec00217-002-s108><arrive.ankommen><de> Wenn du ankommst, leitet dich die Person an der Rezeption in das Welcome Center, das gleich rechts neben dem Haupteingang liegt.
<G-vec00217-002-s109><arrive.ankommen><en> Now follow this map north till you arrive at the ruined building.
<G-vec00217-002-s109><arrive.ankommen><de> Nun folge dieser Karte Richtung Norden bis du bei einer Ruine ankommst.
<G-vec00217-002-s110><arrive.ankommen><en> Ireland smiles when you arrive and cries when you leave.
<G-vec00217-002-s110><arrive.ankommen><de> Irland lächelt, wenn du ankommst und weint wenn du gehst.
<G-vec00217-002-s111><arrive.ankommen><en> If you arrive early enough in Bastia, you should directly drive to Cap Corse, and spend your 1st night in Macinaggio, an hour-drive from Bastia.
<G-vec00217-002-s111><arrive.ankommen><de> Wenn du früh genug in Bastia ankommst, solltest du direkt zum Cap Corse fahren und deine erste Nacht in Macinaggio verbringen, eine Autostunde von Bastia entfernt.
<G-vec00217-002-s112><arrive.ankommen><en> When you arrive at the apartment, an attractive woman/man (your partner) opens the door.
<G-vec00217-002-s112><arrive.ankommen><de> Als du bei der Wohnung ankommst, öffnet dir eine knapp bekleidete Frau / Mann (dein Partner) die Tür.
<G-vec00217-002-s113><arrive.ankommen><en> With PADI eLearning you can complete the study for many dive courses dive at your own pace, at home before you arrive in paradise.
<G-vec00217-002-s113><arrive.ankommen><de> Mit PADI eLearning kannst du viele Tauchkurse in deinem eigenen Tempo absolvieren, bevor du im Paradies ankommst.
<G-vec00217-002-s209><arrive.anreisen><en> Please contact the property in advance if you expect to arrive after 19:00.
<G-vec00217-002-s209><arrive.anreisen><de> Bitte setzen Sie sich vorab mit der Unterkunft in Verbindung, falls Sie planen, nach 19:00 Uhr anzureisen.
<G-vec00217-002-s210><arrive.anreisen><en> We recommend all visitors to arrive by public transport (10 minutes walking distance to Zurich main station or to the tram stop Central).
<G-vec00217-002-s210><arrive.anreisen><de> Wir empfehlen allen Besucher*innen, mit den öffentlichen Verkehrsmitteln anzureisen (10 Minuten Gehdistanz zum Hauptbahnhof Zürich oder zur Tramhaltestelle Central).
<G-vec00217-002-s211><arrive.anreisen><en> Important note: Due to our flexible reservation system, it is also possible to arrive on weekdays other than Saturday, in consultation with the Holidays High Season
<G-vec00217-002-s211><arrive.anreisen><de> Wichtiger Hinweis: Aufgrund unseres flexiblen Reservierungssystems besteht die Möglichkeit, nach Rücksprache mit der Rezeption auch an anderen Wochentagen als Samstag anzureisen.
<G-vec00217-002-s212><arrive.anreisen><en> If you plan to arrive outside these hours, please follow the instructions provided by email in order to enter the building with a personalized code.
<G-vec00217-002-s212><arrive.anreisen><de> Wenn Sie planen, außerhalb dieser Zeiten anzureisen, folgen Sie bitte den Anweisungen, die Ihnen per E-Mail zugesandt werden, um das Gebäude mit einem personalisierten Code zu betreten.
<G-vec00217-002-s213><arrive.anreisen><en> Due to its central location it is of course worthwhile to arrive by train.
<G-vec00217-002-s213><arrive.anreisen><de> Aufgrund der zentralen Lage lohnt es sich natürlich, mit der Bahn anzureisen.
<G-vec00217-002-s214><arrive.anreisen><en> Please inform the hotel should you wish to arrive later than 18:00.
<G-vec00217-002-s214><arrive.anreisen><de> Bitte teilen Sie dem Hotel vorab mit, falls Sie nach 18:00 Uhr anzureisen gedenken.
<G-vec00217-002-s215><arrive.anreisen><en> Therefore, I would advise you to plan generously, if you want to use the flight ticket and if necessary, arrive the evening before.
<G-vec00217-002-s215><arrive.anreisen><de> Daher rate ich Euch großzügig zu planen, wenn Ihr das Flugticket in Anspruch nehmen möchtet und gegebenen falls schon am Vorabend anzureisen.
<G-vec00217-002-s216><arrive.anreisen><en> You can also arrive by plane and land at the gateway to the Vosges at EuroAirport Basel Mulhouse Freiburg, Strasbourg Airport or Lorraine Airport, located between Metz and Nancy.
<G-vec00217-002-s216><arrive.anreisen><de> Zögern Sie auch nicht, mit dem Flugzeug anzureisen, um vor den Toren der Vogesen ab den Flughäfen Basel-Mulhouse-Freiburg, Straßburg-Entzheim und Lorraine Airport zwischen Metz und Nancy zu landen.
<G-vec00217-002-s218><arrive.anreisen><en> However, you can also opt to arrive by a “taxi boat”, plan a day trip with a company that will take you to the island via speedboat or catamaran (these are usually part of a day trip package which also includes a few activities and lunch) or if you really want to arrive in style, you can do so by helicopter (the helicopter pad is located close to the Ile aux Cerfs Golf Club).
<G-vec00217-002-s218><arrive.anreisen><de> Sie können sich aber auch dafür entscheiden, mit einem "Taxi-Boot" anzureisen, einen Tagesausflug mit einer Firma zu planen, die Sie per Speedboot oder Katamaran auf die Insel bringt (diese sind normalerweise Teil eines Tagesausflugspakets, das auch ein paar Aktivitäten und Mittagessen beinhaltet) oder wenn Sie wirklich stilvoll ankommen wollen, können Sie dies mit dem Hubschrauber tun (der Hubschrauberplatz befindet sich in der Nähe des Ile aux Cerfs Golf Club).
<G-vec00217-002-s219><arrive.anreisen><en> Guests who expect to arrive outside of the stated check-in times must contact the property directly as soon as possible.
<G-vec00217-002-s219><arrive.anreisen><de> Sollten Sie vorhaben, außerhalb der angegebenen Check-in-Zeiten anzureisen, kontaktieren Sie das Hotel bitte direkt und so bald wie möglich.
<G-vec00217-002-s220><arrive.anreisen><en> You have the opportunity to arrive comfortably and easily by train.
<G-vec00217-002-s220><arrive.anreisen><de> Sie haben die Möglichkeit, bequem und einfach mit dem Zug anzureisen.
<G-vec00217-002-s221><arrive.anreisen><en> In order to allow the homestay host time to prepare for the arrival of their next students, we ask all students to try to arrive on Sunday and leave on Saturday.
<G-vec00217-002-s221><arrive.anreisen><de> Um der Gastfamilie die Möglichkeit zu geben, sich auf die nächsten Schüler vorzubereiten, bitten wir alle Schüler, sonntags anzureisen und samstags abzureisen.
<G-vec00217-002-s222><arrive.anreisen><en> If you are planning to arrive after 21:00, please contact the hotel directly.
<G-vec00217-002-s222><arrive.anreisen><de> Wenn Sie planen, nach 21:00 Uhr anzureisen, kontaktieren Sie bitte das Hotel direkt.
<G-vec00217-002-s223><arrive.anreisen><en> After many phone calls, emails and consulting with the locals, our crew made the decision to arrive in Christchurch, New Zealand early August (2013), head to the small village of Methven and do our best in the Arrowsmith Mountain Range.
<G-vec00217-002-s223><arrive.anreisen><de> Nach vielen Telefonaten, E-Mails und Rücksprachen mit den Ortsansässigen, beschloss unsere Crew, Anfang August (2013) in Christchurch, Neuseeland, anzureisen, in die kleine Stadt Methven aufzubrechen und in der Arrowsmith-Bergkette unser Bestes zu versuchen.
<G-vec00217-002-s225><arrive.anreisen><en> Please contact the hostel in advance if you wish to arrive after 23:00.
<G-vec00217-002-s225><arrive.anreisen><de> Bitte kontaktieren Sie das Hostel im Voraus, wenn Sie planen, nach 23:00 Uhr anzureisen.
<G-vec00217-002-s226><arrive.anreisen><en> The hosts were very nice and flexible with regard to check-in, so it was already possible to arrive us at noon.
<G-vec00217-002-s226><arrive.anreisen><de> Die Gastgeber waren sehr nett und flexibel was den Check-in betrifft, so war es uns möglich bereits Mittags anzureisen.
<G-vec00217-002-s227><arrive.anreisen><en> To our joy Nadja (Ambassador of the Slovenian WRWR group) together with 2 companions had managed to arrive from the Slovenian side and so it came to a memorable photo that will surely go down in the annals of the WRWR.
<G-vec00217-002-s227><arrive.anreisen><de> Zu unserer Freude hatte es Nadja (Ambassador der Slowenischen WRWR Gruppe) zusammen mit 2 Begleitern geschafft von der Slowenischen Seite anzureisen und so kam es zu einem denkwürdigen Foto, dass ganz sicher in die Annalen des WRWR eingehen wird.
<G-vec00217-002-s247><arrive.eintreffen><en> You and four friends are all that stands between an invading force and holding the fort before reinforcements can arrive.
<G-vec00217-002-s247><arrive.eintreffen><de> Nur ihr und eure Freunde steht zwischen einer angreifenden Streitmacht und dem Fort, das ihr verteidigen müsst, bevor Verstärkung eintrifft.
<G-vec00217-002-s248><arrive.eintreffen><en> This way we can ensure that your PC system undamaged arrive.
<G-vec00217-002-s248><arrive.eintreffen><de> So können wir gewährleisten das Ihr PC-System unbeschädigt bei Ihnen eintrifft.
<G-vec00217-002-s249><arrive.eintreffen><en> When the police arrive, they try to hide the cash.
<G-vec00217-002-s249><arrive.eintreffen><de> Als die Polizei eintrifft, versuchen sie, das Bargeld zu verstecken.
<G-vec00217-002-s250><arrive.eintreffen><en> Also, when Claire ends up in a car accident, Mrs. Bennet is first to arrive at the emergency room.
<G-vec00217-002-s250><arrive.eintreffen><de> Auch als Claire in einen Autounfall verwickelt wird, ist es Sandra, die als erste in der Notaufnahme eintrifft.
<G-vec00217-002-s251><arrive.eintreffen><en> It could take a couple minutes for the email to arrive.
<G-vec00217-002-s251><arrive.eintreffen><de> Es könnte einige Minuten dauern, bis die E-Mail bei dir eintrifft.
<G-vec00217-002-s252><arrive.eintreffen><en> The payment periods run from the receipt of a proper invoice or, if the goods arrive after receipt of the invoice, from arrival of the goods.
<G-vec00217-002-s252><arrive.eintreffen><de> Die Zahlungsfristen beginnen mit dem Eingang einer ordnungsgemässen Rechnung oder, falls die Ware nach der Rechnung eintrifft, mit dem Wareneingang.
<G-vec00217-002-s253><arrive.eintreffen><en> Presentation: The reservation that does not arrive on the scheduled day, will be kept for 24 hours.
<G-vec00217-002-s253><arrive.eintreffen><de> Präsentation: Die Reservierung, die nicht am geplanten Tag eintrifft, wird 24 Stunden aufbewahrt.
<G-vec00217-002-s254><arrive.eintreffen><en> Sometimes you have to order it and it takes a few days before it will arrive.
<G-vec00217-002-s254><arrive.eintreffen><de> Manchmal muss man diese bestellen, und es kann ein paar Tage dauern, bevor sie eintrifft.
<G-vec00217-002-s255><arrive.eintreffen><en> Although it might look like the pressing issue is escaping the scene of crime in time before the police arrive, Keepsake quickly turns into a game of mild surrealism.
<G-vec00217-002-s255><arrive.eintreffen><de> Die erste Aufgabe scheint es zu sein, schnell dem Tatort zu entfliehen, bevor die Polizei eintrifft, doch Keepsake wird praktisch sofort vorsichtig surreal.
<G-vec00217-002-s256><arrive.eintreffen><en> 11.4 Whilst all reasonable efforts will be made by the supplier, there is no guarantee that the vehicle will arrive on time in order to begin the period of hire nor that it will reach its destination on time.
<G-vec00217-002-s256><arrive.eintreffen><de> Es gibt jedoch weder eine Garantie, dass das Fahrzeug rechtzeitig zum vereinbarten Mietbeginn eintrifft, noch dass es pünktlich den Zielort erreicht.
<G-vec00217-002-s257><arrive.eintreffen><en> If you order now, you will get the reduced price and once the goods arrive, we will send you your new Escada on the same day.
<G-vec00217-002-s257><arrive.eintreffen><de> Wenn Du jetzt bestellst, sicherst Du Dir den günstigen Preis und sobald die Ware eintrifft, schicken wir Deine neue Furla noch am selben Tag an Dich weiter.
<G-vec00217-002-s258><arrive.eintreffen><en> If the predicted traffic does not arrive, it is possible to determine this by comparing actual driving progress, imputed drive progress. In deviation of the real parameters of the determined parameters of the optimum route can then be reacted in order to increase the quality of the route guidance, and / or to increase the acceptance to the driver.
<G-vec00217-002-s258><arrive.eintreffen><de> Wenn das prognostizierte Verkehrsgeschehen nicht eintrifft, ist es möglich, dies über den Vergleich tatsächlicher Fahrtfortschritt, unterstellter Fahrtfortschritt Bei Abweichung der realen Parameter von den ermittelten Parametern der optimalen Route kann dann reagiert werden, um die Qualität der Zielführung zu erhöhen, und/oder um die Akzeptanz beim Fahrer zu erhöhen.
<G-vec00217-002-s259><arrive.eintreffen><en> All you have to do is to wait for the opportunity for it to arrive.
<G-vec00217-002-s259><arrive.eintreffen><de> Alles, was du tun musst, ist auf die Gelegenheit zu warten, dass es eintrifft.
<G-vec00217-002-s260><arrive.eintreffen><en> If you order now, you will get the reduced price and once the goods arrive, we will send you your new Elle on the same day.
<G-vec00217-002-s260><arrive.eintreffen><de> Wenn Du jetzt bestellst, sicherst Du Dir den günstigen Preis und sobald die Ware eintrifft, schicken wir Deine neue LineArt noch am selben Tag an Dich weiter.
<G-vec00217-002-s261><arrive.eintreffen><en> In addition, there are delivery dates the customer needs to be able to choose (so the fresh items also definitely arrive when the customer is at home).
<G-vec00217-002-s261><arrive.eintreffen><de> Zudem gibt es Lieferzeitpunkte, welche der Kunde wählen können muss (damit die frische Ware auch auf jeden Fall eintrifft, wenn er zu Hause ist).
<G-vec00217-002-s262><arrive.eintreffen><en> Once the team of ESA and Thales Alenia Space engineers arrive, work will begin preparing the satellite for launch.
<G-vec00217-002-s262><arrive.eintreffen><de> Sobald das Ingenieursteam der ESA und Thales Alenia Space vor Ort eintrifft, beginnen die Arbeiten zur Startvorbereitung des Satelliten.
<G-vec00217-002-s263><arrive.eintreffen><en> We offer you a variety of fast and convenient payment methods, so that your order will arrive as soon as possible.
<G-vec00217-002-s263><arrive.eintreffen><de> Wir bieten Ihnen eine Vielzahl von schnellen und bequemen Zahlungsarten an, damit Ihre Bestellung auch so bald wie möglich bei Ihnen eintrifft.
<G-vec00217-002-s264><arrive.eintreffen><en> We offer custom packaging on all orders to ensure your order will arrive ready to be installed and without any problems.
<G-vec00217-002-s264><arrive.eintreffen><de> Wir bieten bei allen Bestellungen eine individuelle Verpackung an, um sicherzustellen, dass Ihre Bestellung ohne Probleme und ohne Installation eintrifft.
<G-vec00217-002-s265><arrive.eintreffen><en> So it can happen under circumstances that your order did not arrive completely in one day with you.
<G-vec00217-002-s265><arrive.eintreffen><de> So kann es unter Umständen vorkommen, dass Ihre Bestellung nicht komplett an einem Tag bei Ihnen eintrifft.
<G-vec00217-002-s266><arrive.erhalten><en> Book a Deluxe Room and when you check in you will be upgraded to an Ocean Deluxe Room or book a Ocean Deluxe Room and when you arrive you will be upgraded to a Palm Beach Deluxe Room.
<G-vec00217-002-s266><arrive.erhalten><de> Wenn Sie ein Deluxe-Zimmer buchen, erhalten Sie beim Einchecken ein Upgrade auf ein Ocean Deluxe-Zimmer, bei Buchung eines Ocean Deluxe-Zimmers ein Upgrade auf ein Palm Beach Deluxe-Zimmer.
<G-vec00217-002-s267><arrive.erhalten><en> The Industry Desk is your main port of call for information and picking up your accreditation when you arrive.
<G-vec00217-002-s267><arrive.erhalten><de> Am Industry Desk können Sie ihre Tickets für die Screenings abholen und Informationen zu allen Industry Veranstaltungen erhalten.
<G-vec00217-002-s268><arrive.erhalten><en> Most orders arrive within 4-10 business days for in-stock items.
<G-vec00217-002-s268><arrive.erhalten><de> Die meisten Aufträge erhalten Sie innerhalb von 4-10 Werktage für in-Lager Produkte.
<G-vec00217-002-s269><arrive.erhalten><en> This is multiplied by the industry multiplier of 9.5 to arrive at an exit value in Year 6.
<G-vec00217-002-s269><arrive.erhalten><de> Dieses wird mit dem Branchenmultiplikator von 9,5 multipliziert um den Exit-Wert im Jahr 6 zu erhalten.
<G-vec00217-002-s270><arrive.erhalten><en> All purchases arrive in the renowned Tiffany Blue Box, been added to your shopping bag.
<G-vec00217-002-s270><arrive.erhalten><de> Sie erhalten alle Käufe in der charakteristischen Tiffany Blue Box mit einer weißen Satinschleife.
<G-vec00217-002-s271><arrive.erhalten><en> To Greece, it takes about 10 days for the product to arrive.
<G-vec00217-002-s271><arrive.erhalten><de> Nach Griechenland dauert es ungefähr 10 Tage, bis Sie die Ware erhalten.
<G-vec00217-002-s272><arrive.erhalten><en> The method of withdrawal you choose determines how your money will arrive.
<G-vec00217-002-s272><arrive.erhalten><de> Die von Ihnen gewählte Auszahlungsmethode bestimmt, wie Sie Ihr Geld erhalten werden.
<G-vec00217-002-s273><arrive.erhalten><en> Once you arrive at the exhibition halls our staff will point out where you can stop to drop off your passengers.
<G-vec00217-002-s273><arrive.erhalten><de> An den Messehallen erhalten Sie von unserem Personal Instruktionen wo Sie halten und Ihre Passagiere absetzen können.
<G-vec00217-002-s274><arrive.erhalten><en> For orders from France or Spain, your selection of quality products will arrive within 5 working days.
<G-vec00217-002-s274><arrive.erhalten><de> Bei Bestellungen aus Frankreich oder Spanien erhalten Sie Ihre Auswahl von Qualitätsprodukten innerhalb von 5 Werktagen.
<G-vec00217-002-s275><arrive.erhalten><en> Our programs have rolling deadlines, which means we evaluate applications as they arrive.
<G-vec00217-002-s275><arrive.erhalten><de> Unsere Programme haben fortlaufende Fristen, das heißt, dass wir Bewerbungen bearbeiten, sobald wir sie erhalten.
<G-vec00217-002-s276><arrive.erhalten><en> My order didn't arrive.
<G-vec00217-002-s276><arrive.erhalten><de> Ich habe meine Bestellung nicht erhalten.
<G-vec00217-002-s277><arrive.erhalten><en> @14#to arrive at the various blends that we need, in this case, Lipton Yellow Label.
<G-vec00217-002-s277><arrive.erhalten><de> @14#um die Mischungen zu erhalten, die wir brauchen, in diesem Fall Lipton Yellow Label.
<G-vec00217-002-s278><arrive.erhalten><en> Stay informed! Receive email notifications as soon as new products from this label arrive.
<G-vec00217-002-s278><arrive.erhalten><de> Sobald wir neue Produkte dieses Labels erhalten, benachrichtigen wir Sie per Mail.
<G-vec00217-002-s279><arrive.erhalten><en> Students start with foundations in mathematics and computer science, continue with programming and security tools and arrive at the understanding of the full range of current cyber threats, enterprise security architecture as well as legal and ethical aspects of security. PROGRAMME STRUCTURE
<G-vec00217-002-s279><arrive.erhalten><de> Die Studierenden beginnen mit Grundlagen in Mathematik und Informatik, fahren mit Programmier- und Sicherheitswerkzeugen fort und erhalten ein Verständnis für die gesamte Bandbreite aktueller Cyber-Bedrohungen, Sicherheitsarchitekturen im Unternehmen sowie rechtliche und ethische Aspekte der Sicherheit.
<G-vec00217-002-s280><arrive.erhalten><en> Stay informed! Receive email notifications as soon as new products from this label arrive.
<G-vec00217-002-s280><arrive.erhalten><de> Sobald wir neue Produkte dieses Labels erhalten, benachrichtigen wir Sie per Lässigkeit mit britischem Dandytum.
<G-vec00217-002-s281><arrive.erhalten><en> Try to understand the table below and after a bit of experimenting, you'll arrive at the colour of your choosing
<G-vec00217-002-s281><arrive.erhalten><de> Versuchen Sie unten die Tabellen zu verstehen und Sie werden nach etwas Experimentieren Ihre Wunschfarbe erhalten.
<G-vec00217-002-s282><arrive.erhalten><en> The viewer can only guess at the number of photographs taken in order to arrive at the final “Type 42” Polaroid.
<G-vec00217-002-s282><arrive.erhalten><de> Man kann nur erahnen wie viele Fotos gemacht wurden um das finale „Type 42“ - Polaroid zu erhalten.
<G-vec00217-002-s283><arrive.erhalten><en> Do not allow macros to run in documents that arrive by e-mail unless you’re certain that you have to.
<G-vec00217-002-s283><arrive.erhalten><de> Lassen Sie das Ausführen von Makros in Dokumenten, die Sie per E-Mail erhalten, nur dann zu, wenn Sie sich sicher sind, dass dies unbedingt erforderlich ist.
<G-vec00217-002-s284><arrive.erhalten><en> Au and Ag values for Stellar Resources were converted from Oz/Ton by multiplying troy ounces/short ton by 34.28 to arrive at g/tonne.
<G-vec00217-002-s284><arrive.erhalten><de> Die Gold- und Silberwerte von Stellar Resources wurden von Feinunzen pro amerikanische Tonne durch eine Multiplikation mit 34,28 umgewandelt, um einen Wert in Gramm pro Tonne zu erhalten.
<G-vec00217-002-s304><arrive.erreichen><en> After a couple of zigzags due to the slope, climbers arrive at a terrace to bivouac at 4500 meters above sea level. Then to reach the large towers, it is necessary to climb an approximately 500 meter high wall of III and V degrees of difficulty, going through ice and canals (this is undoubtedly one of the biggest obstacles in the route).
<G-vec00217-002-s304><arrive.erreichen><de> Nach einigen durch das Gefälle entstandenen Zickzackwegen erreicht man eine Terrasse, wo man auf 4.500 m. ü. d. M. biwakieren kann.Um die großen Felstürme zu erreichen, muss man danach über eine Wand von ungefähr 500 m mit Schwierigkeitsgraden von III und V klettern, über Eis und Spalten (ohne Zweifel mit die schlimmsten Hindernisse auf dieser Route).
<G-vec00217-002-s305><arrive.erreichen><en> Around 10 pm the ship will arrive in Reykjavik.
<G-vec00217-002-s305><arrive.erreichen><de> Gegen 22 Uhr wird Reykjavik erreicht sein.
<G-vec00217-002-s306><arrive.erreichen><en> The camp site _Le Pré Coulet_ is perfectly situated and in only 20 minutes you arrive at the beautiful valley Eyrieux.
<G-vec00217-002-s306><arrive.erreichen><de> Der Campingplatz _Le Pré Coulet_ ist gut gelegen und in 20 Minuten erreicht man das Tal Eyrieux.
<G-vec00217-002-s307><arrive.erreichen><en> This all ensures that your goods in-transit arrive clean and dry at their destination, even under the harshest of conditions.
<G-vec00217-002-s307><arrive.erreichen><de> So ist auch unter widrigen Umständen gewährleistet, dass Ihr Transportgut trocken und sauber seinen Bestimmungsort erreicht.
<G-vec00217-002-s308><arrive.erreichen><en> In 20 minutes you arrive at Pian della Regina to do some walking to the source of the Po.
<G-vec00217-002-s308><arrive.erreichen><de> In 20 Minuten erreicht man Pian della Regina, einige zu Fuß zu der Quelle des Po zu tun.
<G-vec00217-002-s309><arrive.erreichen><en> Travelers prone to motion sickness may be less thrilled, but once you arrive you can reward yourself with a well-deserved “I survived the road to Pai” T-shirt.
<G-vec00217-002-s309><arrive.erreichen><de> Aber sobald das Dorf erreicht ist, kann die eigene Leistung mit einem „I survived the road to Pai“-T-Shirt belohnt werden.
<G-vec00217-002-s310><arrive.erreichen><en> It is only when you arrive at the large pasture, where you will perhaps have the chance to observe the local game, that you will be able to let out a sigh of relief.
<G-vec00217-002-s310><arrive.erreichen><de> Erst wenn Sie die große Weide erreicht haben, auf der Sie vielleicht auch die Gelegenheit bekommen, Wildtiere zu beobachten, können Sie einen Schrei der Erleichterung loslassen.
<G-vec00217-002-s311><arrive.erreichen><en> The algorithm organizes the data throughout the exhibition to arrive at a final ordered state at the end of the exhibition.
<G-vec00217-002-s311><arrive.erreichen><de> Während der Dauer der Ausstellung organisiert der Algorithmus das Datenmaterial, so dass am Ende der Ausstellung letztlich ein geordneter Status erreicht wird.
<G-vec00217-002-s312><arrive.erreichen><en> Above all, we want your goods to arrive at their destination safely and on time.
<G-vec00217-002-s312><arrive.erreichen><de> Denn wir wollen vor allem eines: dass Ihre Ware sicher und pünktlich ihr Ziel erreicht.
<G-vec00217-002-s313><arrive.erreichen><en> That is why we have seen in 1Sam 15 this morning that to believe with all your heart to be ready when you are not, you must first deceive yourself, and when we choose to deceive ourselves, we arrive at the point where we end up believing that our seduction is a good thing, and this is rather dangerous for us.
<G-vec00217-002-s313><arrive.erreichen><de> Deshalb haben wir heute Morgen in 1.Samuel 15 gesehen, dass um von ganzem Herzen zu glauben, dass man bereit ist, wenn man es nicht ist, muss man sich zuerst selbst verführen, und wenn man sich selbst verführen will, erreicht man den Punkt, an dem man schließlich glaubt, dass die Verführung eine gute Sache ist, und das ist ziemlich gefährlich für uns.
<G-vec00217-002-s314><arrive.erreichen><en> Within the enchanting scenery, a long procession lit by torches travels the nearby mountain slopes to then arrive at the Sanctuary of the Madonna delle Grazie by dawn.
<G-vec00217-002-s314><arrive.erreichen><de> Vor einer faszinierenden Kulisse zieht sich eine lange Prozession im Fackelschein die Steilhänge des Gebirges hinauf und erreicht in der Morgendämmerung das Heiligtum Madonna delle Grazie.
<G-vec00217-002-s315><arrive.erreichen><en> Passengers traveling with Ferry Sardinia will arrive at the second biggest island in the Mediterranean Sea.
<G-vec00217-002-s315><arrive.erreichen><de> Wenn man mit Fähren Sardinen anfährt, erreicht man die zweitgrößte Insel im Mittelmeer.
<G-vec00217-002-s316><arrive.erreichen><en> The most convenient way to arrive is to take the local (S-bahn) train to Berlin Messe-Süd or Berline Messe Nord/ICC.
<G-vec00217-002-s316><arrive.erreichen><de> Am besten erreicht man das Messegelände über die S-Bahn-Linien nach Berlin Messe Süd (Eichkamp) oder Berlin Messe Nord/ICC.
<G-vec00217-002-s317><arrive.erreichen><en> More of that in the next days, when we arrive in Cuenca, third largest city of Ecuador.
<G-vec00217-002-s317><arrive.erreichen><de> Mehr dazu in den nächsten Tagen, wenn wir Ecuadors drittgrößte Stadt Cuenca erreicht haben.
<G-vec00217-002-s318><arrive.erreichen><en> Once you arrive at the southern end of the island, you will then board the vaporetto to Chioggia.
<G-vec00217-002-s318><arrive.erreichen><de> Nachdem wir den südlichsten Punkt der Insel erreicht haben, besteigen wir das Vaporetto nach Chioggia.
<G-vec00217-002-s319><arrive.erreichen><en> Leaving the hotel, and after a two minute walk, we arrive at the Bahía de la Concha, needless to say the Playa de la Concha is a great place for having fun with all the family, weather permitting.
<G-vec00217-002-s319><arrive.erreichen><de> Vom Hotel aus erreicht man die Playa de La Concha in nur 2 Gehminuten, hier kann man an schönen Sommertagen Sonne und Strand satt genießen.
<G-vec00217-002-s321><arrive.erreichen><en> At the end of the competition the Palio di San Donato will arrive in the square escorted by drummers, soldiers, nobles and commoners to be awarded to the winning neighbourhood.
<G-vec00217-002-s321><arrive.erreichen><de> Am Ende des Wettbewerbs erreicht der Palio von San Donato den Platz, begleitet von Trommeln und Soldaten, Adligen und einfachem Stadtvolk, um dem Sieger-Stadtviertel zuerkannt zu werden.
<G-vec00217-002-s322><arrive.erreichen><en> After a crossing a path on the left, you will arrive at the first houses, near a waste dump, where you turn left to arrive at the City council.
<G-vec00217-002-s322><arrive.erreichen><de> Nachdem man an einem von links kommenden Weg vorbeigekommen ist, erreicht man die ersten Häuser in der Nähe einer Müllhalde, wo man nach links zum Rathaus abbiegt.
<G-vec00217-002-s323><arrive.erscheinen><en> • It is recommended that you arrive at least 10 minutes early so that you can unwind in the right area and go in for your
<G-vec00217-002-s323><arrive.erscheinen><de> • Es wird empfohlen, mindestens 10 Minuten vor der Behandlung zu erscheinen, um sich in den entsprechenden Räumlichkeiten entspannen zu können und in einem optimal entspannten Zustand die Behandlung zu beginnen.
<G-vec00217-002-s324><arrive.erscheinen><en> Poor people are found in pre-agrarian and agrarian societies on every continent; if they are not poor enough to be willing to sell their labor when the capitalists arrive, they are impoverished by the activities of the capitalists themselves.
<G-vec00217-002-s324><arrive.erscheinen><de> Arme Menschen können in vorlandwirtschaftlichen und landwirtschaftlichen Gesellschaften auf jedem Kontinent gefunden werden; wenn sie nicht arm genug sind, um ihre Arbeit freiwillig zu verkaufen, wenn die Kapitalisten erscheinen, dann werden sie durch die Aktivitäten der Kapitalisten selbst verarmt.
<G-vec00217-002-s325><arrive.erscheinen><en> If you do not arrive during a long time, the car rent company has the right to cancel your order.
<G-vec00217-002-s325><arrive.erscheinen><de> Wenn Sie eine lange Zeit nicht erscheinen, kann der Autovermieter Ihre Bestellung stornieren.
<G-vec00217-002-s326><arrive.erscheinen><en> But important findings don’t have to arrive in the form of news.
<G-vec00217-002-s326><arrive.erscheinen><de> Aber wichtige Untersuchungsergebnisse müssen nicht in Form von Nachrichten erscheinen.
<G-vec00217-002-s327><arrive.erscheinen><en> When Sora, Donald Duck and Goofy arrive. He tells them of the enemies that they will face in the near future (Heartless, Nobodies, and Organization XIII).
<G-vec00217-002-s327><arrive.erscheinen><de> Als Sora, Donald Duck und Goofy im Turm erscheinen, erklärt Yen Sid den dreien, was sie in naher Zukunft antreffen werden, wobei es sich dabei um die Herzlosen, die Niemande und die Organisation XIII handelt.
<G-vec00217-002-s328><arrive.erscheinen><en> To meet its pre-boarding safety requirements, Germania recommends that all passengers arrive at the check-in counter no later than 90 minutes prior to the planned time of departure.
<G-vec00217-002-s328><arrive.erscheinen><de> Wir empfehlen, zur Erfüllung der bestehenden Sicherheitsanforderungen zur Abfertigung mindestens 90 Minuten vor planmäßiger Abflugzeit am Check‐in zu erscheinen.
<G-vec00217-002-s329><arrive.erscheinen><en> It is therefore advisable to arrive early to get a feeling not just for the wedding party but also the various locations.
<G-vec00217-002-s329><arrive.erscheinen><de> Es ist daher ratsam, frühzeitig zu erscheinen, um ein Gefühl nicht nur für die Hochzeitsgesellschaft sondern auch für die verschiedenen Locations zu bekommen.
<G-vec00217-002-s330><arrive.erscheinen><en> REMOTE DIAGNOSTICS Before you visit your Scania workshop, your vehicle’s status report can be uploaded before you arrive.
<G-vec00217-002-s330><arrive.erscheinen><de> Noch bevor Sie zum Termin in Ihrer Scania Werkstatt erscheinen, kann der Statusbericht für das Fahrzeug an uns übertragen werden.
<G-vec00217-002-s331><arrive.erscheinen><en> by If there is an appointment entry in the calendar where the place was indicated with, you will be informed in due time based on your position and taking into account the travel time to the appointment, when you have to leave to arrive punctually.
<G-vec00217-002-s331><arrive.erscheinen><de> Wenn es einen Termineintrag im Kalender gibt wo der Ort mit angegeben wurde, Wird dir anhand deiner Position und unter Beruecksichtigung der Fahrzeit zum Termin rechtzeitig Bescheid gesagt, wann du losfahren musst um puenktlich zu erscheinen.
<G-vec00217-002-s332><arrive.erscheinen><en> The full amount of your stay in the case of a cancellation less than 30 days before your planned date of arrival, or if you did not arrive on this date.
<G-vec00217-002-s332><arrive.erscheinen><de> Der Gesamtbetrag Ihres Aufenthaltes bei einer Stornierung weniger als 30 Tage vor Ihrem Anreisedatum oder wenn Sie an diesem Datum nicht erscheinen.
<G-vec00217-002-s333><arrive.erscheinen><en> Please arrive latest 30 minutes before the official start time.
<G-vec00217-002-s333><arrive.erscheinen><de> Bitte erscheinen Sie spätestens 30 Minuten vor dem Testbeginn.
<G-vec00217-002-s334><arrive.erscheinen><en> We recommend that you arrive at the Teide Cable Car facilities half an hour prior to the boarding time specified on your Teide Cable Car ticket.
<G-vec00217-002-s334><arrive.erscheinen><de> Wir empfehlen Ihnen, eine halbe Stunde vor der auf Ihrem Online Ticket angegebenen Uhrzeit an der Anlage der Seilbahn auf dem Teide zu erscheinen.
<G-vec00217-002-s335><arrive.erscheinen><en> Teams are kindly requested to arrive on-time for start time of the game.
<G-vec00217-002-s335><arrive.erscheinen><de> Die Teilnehmer müssen pünktlich für den Spielbeginn erscheinen.
<G-vec00217-002-s337><arrive.erscheinen><en> For this reason, we request you to arrive a few minutes before the start of the course.
<G-vec00217-002-s337><arrive.erscheinen><de> Wir bitten Sie daher schon ein paar Minuten vor Kursbeginn zu erscheinen.
<G-vec00217-002-s338><arrive.erscheinen><en> Please arrive well in advance of final check-in time.
<G-vec00217-002-s338><arrive.erscheinen><de> Bitte erscheinen Sie rechtzeitig zum Check-in.
<G-vec00217-002-s339><arrive.erscheinen><en> NOTE: You have to arrive on time (at very very last by 8:55am) in order to be able to take the class.
<G-vec00217-002-s339><arrive.erscheinen><de> BEACHTE: Da die LED Klasse einheitlich in der Gruppe im Vinyasa geübt wird, must du hier pünktlich (allerspätestens 8:55 Uhr) erscheinen, um mitüben zu können.
<G-vec00217-002-s340><arrive.erscheinen><en> 3 Christmas spirits arrive and will give him a chance to change his life.
<G-vec00217-002-s340><arrive.erscheinen><de> 3 Weihnachtsgeister erscheinen ihm und geben ihm die Chance sein Leben zu ändern.
<G-vec00217-002-s341><arrive.erscheinen><en> Please arrive at least 30 minutes prior to departure.
<G-vec00217-002-s341><arrive.erscheinen><de> Erscheinen Sie bitte 30 Minuten vor Abfahrt.
<G-vec00217-002-s342><arrive.fahren><en> We arrive at the rodeo grounds after lunch.
<G-vec00217-002-s342><arrive.fahren><de> Nach der Mittagspause fahren wir zum Rodeo.
<G-vec00217-002-s343><arrive.fahren><en> bus trips arrive in Aosta at 1 stations, depending on which bus line you are travelling with.
<G-vec00217-002-s343><arrive.fahren><de> Die meisten bus -Verbindungen nach Turin fahren in Turin an 3 Haltestellen an, je nachdem mit welchem bus -Anbieter du reist.
<G-vec00217-002-s344><arrive.fahren><en> All trains from the south arrive via Hamar, while trains that are going north stay on the Røros line to Trondheim.
<G-vec00217-002-s344><arrive.fahren><de> Alle Züge aus dem Süden fahren über Hamar, während die Züge nach Norden über die Rørosbahn nach Trondheim fahren.
<G-vec00217-002-s345><arrive.fahren><en> After too short a night we arrive at the ferry terminal early.
<G-vec00217-002-s345><arrive.fahren><de> Nach einer viel zu kurzen Nacht fahren wir zum Fährhafen.
<G-vec00217-002-s346><arrive.fahren><en> We leave the bikes safely at Reed Valley Inn and arrive at Woodbury in time for the afternoon Game Drive. where our qualified ranger will bring the African bush a little closer and we can spot some of Africa’s wildlife from an open safari vehicle.
<G-vec00217-002-s346><arrive.fahren><de> Wir lassen die Motorräder beim Reed Valley Inn und fahren mit 4×4 Fahrzeugen zu dem Woodbury Camp, rechtzeitig für die erste Pirschfahrt, auf der ein qualifizierte Ranger uns den afrikanischen Busch ein bisschen näher bringt und wo wir die Gelegenheit haben afrikanische Wildtiere aus nächster Nähe zu sehen.
<G-vec00217-002-s347><arrive.fahren><en> After leaving the port of Civitavecchia (Rome) you will arrive to the port of Tunis without any stopovers.
<G-vec00217-002-s347><arrive.fahren><de> Nachdem Sie den Hafen von Civitavecchia (Rom) verlassen haben, fahren Sie ohne Zwischenstops zu den Hafen von Tunis über.
<G-vec00217-002-s348><arrive.fahren><en> Eight new mooring buoys enable customers to arrive at the restaurant directly on your own boat.
<G-vec00217-002-s348><arrive.fahren><de> Acht neue Anlegebojen ermöglichen es den Gästen, mit dem Boot direkt zum Restaurant zu fahren.
<G-vec00217-002-s349><arrive.fahren><en> In the morning you arrive in Ulaanbaatar (Ulan Bator), the capital of Mongolia.
<G-vec00217-002-s349><arrive.fahren><de> Am Vormittag fahren Sie in Ulaan Baatar, Hauptstadt der Mongolei, ein.
<G-vec00217-002-s350><arrive.fahren><en> From Naples, the hydrofoils depart from Moro Beverello or from Mergellina, and arrive at the ports of Forio, Ischia, and Casamicciola.
<G-vec00217-002-s350><arrive.fahren><de> In Neapel legen die Tragflügelboote am Molo Beverello oder von Mergellina ab und fahren die Häfen von Forio, Ischia und Casamicciola an.
<G-vec00217-002-s351><arrive.fahren><en> Rick and Morgan arrive at the scene of the shootout.
<G-vec00217-002-s351><arrive.fahren><de> Rick und Morgan fahren den Leichnam abzulegen.
<G-vec00217-002-s352><arrive.fahren><en> You can arrive by car directly in front of the hotel.
<G-vec00217-002-s352><arrive.fahren><de> Sie können mit dem Auto bis vor das Hotel fahren.
<G-vec00217-002-s353><arrive.fahren><en> The ferries arrive at Langesund or Oslo in Norway or Gothenburg in Sweden.
<G-vec00217-002-s353><arrive.fahren><de> Die Fähren fahren nach Langesund und Oslo in Norwegen sowie nach Göteborg in Schweden.
<G-vec00217-002-s354><arrive.fahren><en> We arrive to the region of Mounts Ovcar and Kablar, where a number of old monasteries were built in Turkish times, and visit the Nikolje monastery (dedicated to St. Nicolas) on the left bank of the Morava river.
<G-vec00217-002-s354><arrive.fahren><de> Wir fahren in den Bereich der Bergen Ovcar und Kablar, wo eine Reihe von alten Klöster in der Türkenzeit gebaut wurden, und besichtigen das Kloster Nikolje (zu St. Nikolaus gewidmet) am linken Ufer des Flusses Morava.
<G-vec00217-002-s355><arrive.fahren><en> From everywhere, you will arrive at the Santa Lucia railway station of Venice.
<G-vec00217-002-s355><arrive.fahren><de> Aus allen Richtungen fahren Sie bis zum Bahnhof von Venedig Santa Lucia.
<G-vec00217-002-s356><arrive.fahren><en> After leaving the port of Civitavecchia (Rome) you will arrive to the port of Termini Imerese without any stopovers.
<G-vec00217-002-s356><arrive.fahren><de> Nachdem Sie den Hafen von Civitavecchia (Rom) verlassen haben, fahren Sie ohne Zwischenstops zu den Hafen von Termini Imerese auf Sizilien über.
<G-vec00217-002-s357><arrive.fahren><en> As the trains depart and arrive in strict accordance with a fixed schedule, our customers pre-order the transportation and receive the goods at the agreed time.
<G-vec00217-002-s357><arrive.fahren><de> Da Züge fahrplangemäß fahren, können unsere Kunden im Voraus den Transport bestellen und die Sendung zu vereinbartem Termin erhalten.
<G-vec00217-002-s358><arrive.fahren><en> - When you arrive at Dame Street, continue past the Bank of Ireland on the left.
<G-vec00217-002-s358><arrive.fahren><de> Fahren Sie weiter geradeaus, an der Bank of Ireland (auf der linken Straßenseite) vorbei.
<G-vec00217-002-s359><arrive.fahren><en> We cross the Danube on the Margaret Bridge, passing by the Margaret Island, arrive to the Buda side and admire the oldest Turkish Thermal Spa (Király Fürdő), the Funicular, and climb to the Castle District and take a walk to see the Matthias Church, the Fisherman's Bastion, the Royal Palace courtyards and so much more....
<G-vec00217-002-s359><arrive.fahren><de> Über die Donau auf der Margareten-Brücke, vorbei an der Margareteninsel fahren wir nach Buda, wo Sie den Königspalast und seine Umgebung mit der Fischerbastei und der Matthiaskirche besuchen können.
<G-vec00217-002-s360><arrive.fahren><en> 38,000 railroad cars arrive at and leave our mills every day.
<G-vec00217-002-s360><arrive.fahren><de> In unseren Werken fahren tagtäglich 38.000 Eisenbahnwaggons ein und aus.
<G-vec00217-002-s361><arrive.finden><en> It is therefore important that this meeting could take place this year, and I am pleased that we have all taken the trouble to build bridges, arrive at compromises and ensure that our differences of opinion do not gnaw at this, the heart of the human dimension of the OSCE.
<G-vec00217-002-s361><arrive.finden><de> Daher ist es wichtig, dass dieses HDIM auch in diesem Jahr stattfinden konnte und ich bin froh, dass wir alle uns der Mühe unterzogen haben, Brücken zu bauen, Kompromisse zu finden und unsere Meinungsverschiedenheiten nicht zu Lasten dieses Herzstücks der menschlichen Dimension der OSZE gehen zu lassen.
<G-vec00217-002-s362><arrive.finden><en> Arrive the terminal 30 minutes prior to departure for check in
<G-vec00217-002-s362><arrive.finden><de> Finden Sie sich 30 Minuten vor Abflug am Terminal zum Check-In ein.
<G-vec00217-002-s363><arrive.finden><en> This is where Allgaier carries out series of scientific experiments and practical tests in order to arrive at made-to-measure solutions for customers all over the world.
<G-vec00217-002-s363><arrive.finden><de> Hier führt Allgaier wissenschaftliche Versuchsreihen und praxisnahe Tests durch, um passgenaue Lösungen für Kunden auf der ganzen Welt zu finden.
<G-vec00217-002-s364><arrive.finden><en> For your taxi to arrive whenever you need one, you have to download Hailo, the taxi app that is already working in over 16 cities.
<G-vec00217-002-s364><arrive.finden><de> Damit Sie immer ein Taxi finden können, müssen Sie Hailo herunterladen, die Taxi-App, die schon in mehr als 16 Städte funktioniert.
<G-vec00217-002-s365><arrive.finden><en> Our customers frequently come to us to help them compare discounts on ‘real’, specification adjusted vehicles to arrive at a Dealer Net Net price they can trust, which is well sourced, well organised and reliable.
<G-vec00217-002-s365><arrive.finden><de> Unsere Kunden bitten uns regelmäßig um Hilfe beim Vergleich von tatsächlichen, spezifikationsangepassten Fahrzeugen, um einen Händler-Netto-Preis zu finden, dem sie vertrauen können und der fundiert, ausgewogen und verlässlich ist.
<G-vec00217-002-s366><arrive.finden><en> The first week of the summer break has begun in Berlin and ten excited children between the ages of 6 and 10 arrive at the Fox & Sheep office.
<G-vec00217-002-s366><arrive.finden><de> In Berlin ist die erste Woche der Sommerferien angebrochen und im Fox & Sheep Büro finden sich zehn gespannte Kinder zwischen 6 und 10 Jahren ein.
<G-vec00217-002-s367><arrive.finden><en> Other deportation flights, rarer, for example with Royal Air Maroc, arrive very early in the morning.
<G-vec00217-002-s367><arrive.finden><de> Auch andere Abschiebeflüge, zum Beispiel mit Royal Air Maroc, finden in den frühen Morgenstunden statt und sind seltener.
<G-vec00217-002-s368><arrive.finden><en> Before making use of these alternatives, we highly recommend that a user first contact Botis directly in order to arrive at a solution.
<G-vec00217-002-s368><arrive.finden><de> Bevor diese Alternativen verwendet werden, empfehlen wir, dass sich ein Benutzer zunächst an Botis wendet, um eine Lösung zu finden.
<G-vec00217-002-s369><arrive.finden><en> Please check website for operation days and arrive at least 30 minutes before the start of the tour.
<G-vec00217-002-s369><arrive.finden><de> Bitte informieren Sie sich auf der Webseite über Termine und finden Sie sich spätestens 30 Minuten vor Beginn der Führung ein.
<G-vec00217-002-s370><arrive.finden><en> Since the Oslo agreement, these governments especially undertook great efforts to arrive at a lasting peace settlement.
<G-vec00217-002-s370><arrive.finden><de> Seit der Vereinbarung von Oslo, 1983 [SIC, should be 1993], haben ebendiese Regierungen sehr große Anstrengungen unternommen, eine dauerhafte Regelung für den Frieden zu finden.
<G-vec00217-002-s371><arrive.finden><en> Please arrive punctually at the meeting point.
<G-vec00217-002-s371><arrive.finden><de> Bitte finden Sie sich pünktlich am Treffpunkt ein.
<G-vec00217-002-s372><arrive.finden><en> Because of our complex environment, there is so much information containing just as many risks and it is therefore extremely important to communicate risks correctly in order to arrive at the correct response to handling risk.
<G-vec00217-002-s372><arrive.finden><de> Wegen unserer komplexen Umwelt gibt es so viele Informationen, die ebenso viele Risiken enthalten, und es ist also extrem wichtig, Risiken richtig zu kommunizieren, um die richtige Antwort zum Umgang mit dem Risiko zu finden.
<G-vec00217-002-s373><arrive.finden><en> See other months For our children, coming to the "Resi" is to arrive home.
<G-vec00217-002-s373><arrive.finden><de> Andere Monate zur Ansicht In die Resi einzuziehen, ist für unsere Kinder, wie ein Heim zu finden.
<G-vec00217-002-s374><arrive.finden><en> We remind you that it is preferable to arrive 5 minutes in advance of the treatment time to allow maximum efficiency.
<G-vec00217-002-s374><arrive.finden><de> Bitte finden Sie sich 5 Minuten vor dem vereinbarten Termin ein, um maximale Effizienz zu gewährleisten.
<G-vec00217-002-s375><arrive.finden><en> Thereby, the efficiency of all commodity flows is focused in order that they arrive at the recipient as fast, secure, and economical as possible.
<G-vec00217-002-s375><arrive.finden><de> Die Effizienz aller Warenströme steht dabei im Fokus, damit diese so schnell, sicher und günstig wie möglich ihren Weg zum Empfänger finden.
<G-vec00217-002-s376><arrive.finden><en> In many industries, we already have well-known references, but we also arrive quickly into new markets.
<G-vec00217-002-s376><arrive.finden><de> In vielen Branchen verfügen wir bereits über namhafte Referenzen, finden uns aber auch schnell in neue Märkte ein.
<G-vec00217-002-s377><arrive.finden><en> Please arrive at the airport at least 120 minutes before departure if checking additional bags, or overweight or oversized pieces.
<G-vec00217-002-s377><arrive.finden><de> Finden Sie sich bitte mindestens 2 Stunden vor dem Abflug am Flughafen ein, wenn Sie zusätzliche, zu große oder zu schwere Gepäckstücke aufgeben möchten.
<G-vec00217-002-s378><arrive.finden><en> Ross and Rachel arrive at the hospital.
<G-vec00217-002-s378><arrive.finden><de> Sowohl Ross als auch Joey finden Gefallen an ihr.
<G-vec00217-002-s379><arrive.finden><en> If our understanding is correct, we arrive at peace.
<G-vec00217-002-s379><arrive.finden><de> Wenn wir das richtige Verständnis haben, finden wir Frieden.
<G-vec00217-002-s399><arrive.gelangen><en> Going down a narrow alley, you'll arrive at the family vault and the boats the General used during his stay in Caprera.
<G-vec00217-002-s399><arrive.gelangen><de> Folgt man einem kurzen Pfad, gelangt man zu den Gräbern der Familie Garibaldi und zu den vom General während seines Aufenthaltes auf Caprera benutzten Booten.
<G-vec00217-002-s400><arrive.gelangen><en> Materials arrive at the rotor via a belt conveyor.
<G-vec00217-002-s400><arrive.gelangen><de> Über ein Gurtförderband gelangt das Schüttgut zum Rotor.
<G-vec00217-002-s401><arrive.gelangen><en> Referral data: If you arrive at our site from an external source (such as a link on another website or in an email), we record information about the source that referred you to us.
<G-vec00217-002-s401><arrive.gelangen><de> Verweisdaten: Falls Sie auf unsere Webseite durch einen externen Verweis gelangt sind (wie über einen Link von einer anderen Webseite oder einer E-Mail) speichern wir Informationen über die Quelle, die Sie an uns weitergeleitet hat.
<G-vec00217-002-s402><arrive.gelangen><en> The most popular way for the rogue to arrive at your computer is through fake online malware scanners.
<G-vec00217-002-s402><arrive.gelangen><de> Die beliebteste Methode wie dieser Parasit auf Ihren Computer gelangt ist durch falsche Online-Prüfungsprogramme gegen bösartige Software.
<G-vec00217-002-s403><arrive.gelangen><en> In the back of all the rooms, you arrive to the kitchen with a long wooden table.
<G-vec00217-002-s403><arrive.gelangen><de> Nach den Räumen gelangt man in die Küche mit ihrem langen, hölzernen Tisch.
<G-vec00217-002-s404><arrive.gelangen><en> Anyone who attempts to achieve socialism by any other route without passing through the stage of political democracy, will inevitably arrive at the most absurd and reactionary conclusions, both economic and political.
<G-vec00217-002-s404><arrive.gelangen><de> Wer auf einem anderen Weg als dem des politischen Demokratismus zum Sozialismus kommen will, der gelangt unvermeidlich zu Schlußfolgerungen, die sowohl im ökonomischen als auch im politischen Sinne absurd und reaktionär sind.
<G-vec00217-002-s405><arrive.gelangen><en> Following this route, you’ll arrive at Topographie des Terrors (“The Topography of Terror” museum), where a large portion of the original Berlin Wall is still on display.
<G-vec00217-002-s405><arrive.gelangen><de> Auf diesem Wege gelangt man zu der Topographie des Terrors, wo sich noch ein großer Teil der originalen Mauer befindet.
<G-vec00217-002-s406><arrive.gelangen><en> You arrive at a clearing that represents the current centre of the Bali Bike Park.
<G-vec00217-002-s406><arrive.gelangen><de> Man gelangt zu einer Lichtung, die das derzeitige Zentrum des Bali Bike Park darstellt.
<G-vec00217-002-s407><arrive.gelangen><en> You will pass the dam wall of the water reservoir and then arrive at the beach of the lake.
<G-vec00217-002-s407><arrive.gelangen><de> Zwischen Waldrand und Ufer des Gewässers gelangt man zur Staumauer.
<G-vec00217-002-s408><arrive.gelangen><en> UET enables us to track your activities on our website when you arrive at our website via advertisements from bing Ads and enables us to improve our services.
<G-vec00217-002-s408><arrive.gelangen><de> UET ermöglicht uns, Ihre Aktivitäten auf unseren Webseiten nachzuverfolgen, wenn Sie über Anzeigen von Bing Ads auf unsere Webseiten gelangt sind und ermöglichen uns, unser Angebot zu verbessern.
<G-vec00217-002-s409><arrive.gelangen><en> Through this gate, you’ll arrive at a large square, opposite the Hall of Supreme Harmony, which is where the emperors were crowned, where they granted audiences to visitors, and where other important ceremonies were celebrated throughout the year.
<G-vec00217-002-s409><arrive.gelangen><de> Durch dieses Tor gelangt man an einen großen Platz gegenüber der Halle der höchsten Harmonie, wo die Kaiser gekrönt und Audienzen sowie andere Zeremonien abgehalten wurden.
<G-vec00217-002-s410><arrive.gelangen><en> By applying this tool the customer can easily arrive at the preheating temperature recommended for the steel grade used.
<G-vec00217-002-s410><arrive.gelangen><de> Mit Hilfe dieses Online-Tools gelangt der Kunde in wenigen Schritten zu der für seine Stahlgüte empfohlenen Brennschneid-Vorwärmtemperatur.
<G-vec00217-002-s411><arrive.gelangen><en> If you walk along the Adalbert Stifter hiking trail, you will automatically arrive at the castle.
<G-vec00217-002-s411><arrive.gelangen><de> Wer den Adalbert-Stifter-Wanderweg entlangläuft, gelangt automatisch zum Schloss.
<G-vec00217-002-s412><arrive.gelangen><en> Irrespective of the delivery method, the goods arrive in the warehouse via closed conveyor belts.
<G-vec00217-002-s412><arrive.gelangen><de> In allen Fällen gelangt die Ware über geschlossene Förderbänder in das Silo.
<G-vec00217-002-s413><arrive.gelangen><en> After a short hike up and down again you´ll arrive at the amazing sandy beach of Petite Anse.
<G-vec00217-002-s413><arrive.gelangen><de> Nach ein paar Minuten hoch und wieder runter gelangt Ihr in die Petite Anse.
<G-vec00217-002-s414><arrive.gelangen><en> In this way it will arrive intact "at its destination" without disturbing the gastrointestinal mucosa.
<G-vec00217-002-s414><arrive.gelangen><de> Auf diese Weise gelangt es intakt „an seinen Bestimmungsort“, ohne die Magen-Darm-Schleimhäute zu beeinträchtigen.
<G-vec00217-002-s415><arrive.gelangen><en> The upper and lower halves of the component arrive at a manual workstation on a workpiece carrier where a worker uses four screws to fasten a PCB which has been prefitted onto the lower half.
<G-vec00217-002-s415><arrive.gelangen><de> Die obere und untere Hälfte des Bauteils gelangt mit einem Werkstückträger zunächst zu einem Handarbeitsplatz, wo ein Werker eine auf dem Unterteil vormontierte Leiterplatine mit vier Schrauben manuell verschraubt.
<G-vec00217-002-s416><arrive.gelangen><en> Our packing boxes are three layer of corrugated board boxes,ensure that the product can arrive safely to your hands.
<G-vec00217-002-s416><arrive.gelangen><de> Unsere Verpackungskartons bestehen aus drei Wellpappe-Schachteln, die sicherstellen, dass das Produkt sicher in Ihre Hände gelangt.
<G-vec00217-002-s417><arrive.gelangen><en> When you arrive at the village of Gletsch, the road splits between the Furka Pass to your right and the Grimsel Pass to your left.
<G-vec00217-002-s417><arrive.gelangen><de> Man gelangt zum kleinen Dorf Gletsch, wo sich die Straße zwischen dem Furkapass rechts und dem Grimselpass links teilt.
<G-vec00217-002-s475><arrive.kommen><en> Or your driveway lights turn on at the moment you arrive home.
<G-vec00217-002-s475><arrive.kommen><de> Oder wie sich Deine Einfahrtbeleuchtung einschaltet, sobald Du nach Hause kommst.
<G-vec00217-002-s476><arrive.kommen><en> Arrive in Inverness for 2pm, where you can either be picked up in the city centre or at the airport, and meet your guide and fellow adventurers.
<G-vec00217-002-s476><arrive.kommen><de> Du kommst in Inverness an, wo man dich entweder im Stadtzentrum oder am Flughafen abholt, und triffst deinen Guide und die anderen Flashpacker.
<G-vec00217-002-s477><arrive.kommen><en> You can also make an emergency call yourself when you arrive at an accident.
<G-vec00217-002-s477><arrive.kommen><de> Du kannst auch selbst einen Notruf starten wenn du zu einem Unfall als Helfer kommst.
<G-vec00217-002-s478><arrive.kommen><en> For us, the undisputed champion among all these pretty, experienced and concluded, spatial and local structures, where everything is better than here, is Europe. A Europe virtually impossible to grasp, both territorially and conceptually, a Europe where almost everyone has been at least once; it’s there as soon as you cross the border – and you arrive in a place where everything is great.
<G-vec00217-002-s478><arrive.kommen><de> Den ersten Platz unter all diesen hübschen, erlebten und beendeten, räumlichen und lokalen Strukturen, wo alles besser als hier ist, besitzt bei uns zweifellos Europa, kaum zu fassend, territorial und geistig, ein Europa, in dem fast jeder schon einmal war; es ist da, sobald du die Grenze passiert hast – und du kommst an einen Ort, wo alles bestens ist.
<G-vec00217-002-s479><arrive.kommen><en> But Jesus wants you to arrive at the finishing line in victory.
<G-vec00217-002-s479><arrive.kommen><de> Aber Jesus möchte, dass Du siegreich ans Ziel kommst.
<G-vec00217-002-s480><arrive.kommen><en> Take a 20 minute drive in the car and you'll arrive in Verbier - 4 Vallées, home to the largest ski area that's entirely within Swiss borders that boasts 92 lifts, 412 km of slopes at altitudes ranging from 1350 to 3400 meters. Accommodation
<G-vec00217-002-s480><arrive.kommen><de> Fährst du allerdings 20 Minuten von Liddes weg, so kommst du nach Verbier - 4 Vallées (4 Täler), dem größten Wintersportgebiet komplett innerhalb der Schweizer Grenzen, mit 92 Skiliften, 412 km Piste und Höhenunterschieden von 1350 bis 3400m ü.
<G-vec00217-002-s481><arrive.kommen><en> On the day of our appointment, I put everything together, change my clothes, make a elaborately make up + hairdo and then drive much earlier to the meeting place to prepare everything there for our game so that we can start right away when you arrive...
<G-vec00217-002-s481><arrive.kommen><de> Am Tag unserer Verabredung packe ich alles zusammen, ziehe mich um, mache mich aufwendig zurecht und fahre dann deutlich früher zum abgemachten Treffpunkt um auch dort alles für unser Spiel vorzubereiten, damit wir gleich starten können, wenn du kommst...
<G-vec00217-002-s482><arrive.kommen><en> If you arrive early you can avoid the 3 euro booking fee charged for online reservations.
<G-vec00217-002-s482><arrive.kommen><de> Wenn du früh genug kommst, sparst du dir die Online-Buchungsgebühr von 3 €.
<G-vec00217-002-s483><arrive.kommen><en> As you finally arrive she takes you with to several outdoor locations, such as a playground as well. Finally she shows you her class room, too.
<G-vec00217-002-s483><arrive.kommen><de> Als du endlich kommst, nimmt sie dich mit an verschiedene Outdoorlocations, darunter auch ein Spielplatz, und schließlich zeigt sie dir auch ihr Klassenzimmer.
<G-vec00217-002-s484><arrive.kommen><en> When you arrive back in Heaven, you must repent for your actions on earth and we all fail on earth.
<G-vec00217-002-s484><arrive.kommen><de> Wenn du zurück in den Himmel kommst musst du deine Handlungen auf der Erde bereuen, und wir alle versagen auf der Erde.
<G-vec00217-002-s485><arrive.kommen><en> 41. But you will be innocent of my curse, if, when you will arrive at my close relatives, they will not grant this to you.’
<G-vec00217-002-s485><arrive.kommen><de> 41 Von dem Eid, den du mir geleistet hast, sollst du dann entbunden sein, wenn du zu meinen Verwandten kommst und sie dir keine Frau geben.
<G-vec00217-002-s486><arrive.kommen><en> And even knowing what it means to be neatly dressed, as the ads say, you arrive half an 305 TOM CORREIA hour early to the interview and everyone in the waiting room looks suspicious, everyone evaluating each other, trying to guess who has better chances of getting the job, the only job, because of their clothes, their seeming intelligence, their nice thighs.
<G-vec00217-002-s486><arrive.kommen><de> Und obwohl du weiβt, was „seriöses Auftreten“ in der Stellenanzeige sagen will, kommst du eine halbe Stunde vor Beginn des Vorstellungsgesprächs und im Warteraum beäugen sich alle misstrauisch bei dem Versuch die anderen abzuschätzen, wer wohl die besseren Chancen hat die freie Stelle zu bekommen, die einzige freie Stelle, sei es aufgrund der Kleidung, wegen des inteligenten Aussehens, oder wegen der muskulösen Gestalt.
<G-vec00217-002-s487><arrive.kommen><en> You’re rarely late and often arrive to meetings earlier than everyone else.
<G-vec00217-002-s487><arrive.kommen><de> Du kommst selten zu spät und bist häufig zu früh bei Meetings.
<G-vec00217-002-s488><arrive.kommen><en> After crossing the bridge connecting the island to the “mainland”, you’ll arrive in Sant’Antioco, the main city of the island.
<G-vec00217-002-s488><arrive.kommen><de> Nachdem du die Brücke überquert hast, die die Insel mit dem „Festland“ verbindet, kommst du in Sant’Antioco an, der Hauptstadt der Insel.
<G-vec00217-002-s489><arrive.kommen><en> You arrive at your office in the morning and your colleagues are already sitting with a cup of coffee in front of their screens.
<G-vec00217-002-s489><arrive.kommen><de> Du kommst morgens in Dein Büro und die Kollegen sitzen bereits mit einem Becher Kaffee vor ihren Bildschirmen.
<G-vec00217-002-s490><arrive.kommen><en> And when you arrive to Africa, watch... but most of all, listen... after all, we were given two ears and eyes and only one mouth for a good reason.
<G-vec00217-002-s490><arrive.kommen><de> Wenn du nach Afrika kommst, mach die Augen auf und noch wichtiger hör gut zu – schlieβlich haben wir nicht umsonst zwei Ohren und zwei Augen und nur einen Mund.
<G-vec00217-002-s491><arrive.kommen><en> You arrive at the office after a nice morning workout, you’re feeling good and relaxed until your colleagues begin teasing you for being “obsessed with sports”?
<G-vec00217-002-s491><arrive.kommen><de> Du kommst nach einem schönen Morgen-Workout ins Büro, fühlst dich gut und bist entspannt, bis einer deiner Kollegen sagt, dass „du es mit dem Sport schon etwas übertreibst”.
<G-vec00217-002-s492><arrive.kommen><en> Then you arrive at the castle and are led into the brightly lit ballroom.
<G-vec00217-002-s492><arrive.kommen><de> Dann kommst du zum Schloß und wirst in den hellerleuchteten Festsaal hineingeführt.
<G-vec00217-002-s493><arrive.kommen><en> When you arrive in Jena, you will be enchanted by its nature and location.
<G-vec00217-002-s493><arrive.kommen><de> Kommst du nach Jena, wirst du von der Natur und der Lage verzaubert sein.
<G-vec00217-002-s513><arrive.landen><en> Flights Karlovy Vary — Ekaterinburg arrive at the following airports: Ekaterinburg.
<G-vec00217-002-s513><arrive.landen><de> Flüge Karlsbad – Jekaterinburg landen in den folgenden Flughäfen: Jekaterinburg.
<G-vec00217-002-s514><arrive.landen><en> Flights Naberezhnye Chelny — Ekaterinburg arrive at the following airports: Ekaterinburg.
<G-vec00217-002-s514><arrive.landen><de> Flüge Naberezhnye Chelny – Wien landen in den folgenden Flughäfen: Wien-Schwechat.
<G-vec00217-002-s515><arrive.landen><en> Flights Athens — Tbilisi arrive at the following airports: Tbilisi.
<G-vec00217-002-s515><arrive.landen><de> Flüge Athen – Tiflis landen in den folgenden Flughäfen: Internationale Flughafen Tiflis.
<G-vec00217-002-s516><arrive.landen><en> Flights Istanbul — Salzburg arrive at the following airports: Salzburg.
<G-vec00217-002-s516><arrive.landen><de> Flüge Istanbul – Salzburg landen in den folgenden Flughäfen: Salzburg.
<G-vec00217-002-s517><arrive.landen><en> Flights Oslo — Vienna arrive at the following airports: Vienna.
<G-vec00217-002-s517><arrive.landen><de> Flüge Oslo – Wien landen in den folgenden Flughäfen: Wien-Schwechat.
<G-vec00217-002-s518><arrive.landen><en> Flights Leipzig — Vienna arrive at the following airports: Vienna.
<G-vec00217-002-s518><arrive.landen><de> Flüge Leipzig – Wien landen in den folgenden Flughäfen: Wien-Schwechat.
<G-vec00217-002-s519><arrive.landen><en> Flights Guanare — Schwyz arrive at the following airports: Schwyz.
<G-vec00217-002-s519><arrive.landen><de> Flüge Guanare – Ikast landen in den folgenden Flughäfen: Ikast.
<G-vec00217-002-s520><arrive.landen><en> Flights Pescara — Milan arrive at the following airports: Milan.
<G-vec00217-002-s520><arrive.landen><de> Flüge Pescara – Mailand landen in den folgenden Flughäfen: Linate, Malpensa.
<G-vec00217-002-s521><arrive.landen><en> Flights Aswan — Cairo arrive at the following airports: Cairo.
<G-vec00217-002-s521><arrive.landen><de> Flüge Assuan – Kairo landen in den folgenden Flughäfen: Kairo.
<G-vec00217-002-s522><arrive.landen><en> Flights Warsaw — Helsinki arrive at the following airports: Helsinki.
<G-vec00217-002-s522><arrive.landen><de> Flüge Warschau – Helsinki landen in den folgenden Flughäfen: Helsinki-Vantaa.
<G-vec00217-002-s523><arrive.landen><en> Flights Bourgas — Riga arrive at the following airports: Riga.
<G-vec00217-002-s523><arrive.landen><de> Flüge Burgas – Riga landen in den folgenden Flughäfen: Riga (Spilve).
<G-vec00217-002-s524><arrive.landen><en> Flights Guangzhou — Hanoi arrive at the following airports: Hanoi.
<G-vec00217-002-s524><arrive.landen><de> Flüge Guangzhou – Hanoi landen in den folgenden Flughäfen: Internationaler N?i Bai.
<G-vec00217-002-s525><arrive.landen><en> Flights Berlin — Zurich arrive at the following airports: Zurich.
<G-vec00217-002-s525><arrive.landen><de> Flüge Nowokusnezk – Zürich landen in den folgenden Flughäfen: Zurich (Kloten).
<G-vec00217-002-s526><arrive.landen><en> Flights Ivano Frankovsk — Moscow arrive at the following airports: Moscow.
<G-vec00217-002-s526><arrive.landen><de> Flüge Ivano Frankovsk – Moskau landen in den folgenden Flughäfen: Domodedowo, Scheremetjewo, Wnukowo, Zhukovskiy.
<G-vec00217-002-s527><arrive.landen><en> Flights Innsbruck — Berlin arrive at the following airports: Berlin.
<G-vec00217-002-s527><arrive.landen><de> Flüge Innsbruck – Berlin landen in den folgenden Flughäfen: Brandenburg, Schonefeld, Tegel.
<G-vec00217-002-s528><arrive.landen><en> Flights Hanover — Warsaw arrive at the following airports: Warsaw.
<G-vec00217-002-s528><arrive.landen><de> Flüge Kemerowo – Warschau landen in den folgenden Flughäfen: Warschau (Frederic Chopin).
<G-vec00217-002-s529><arrive.landen><en> Flights Los Angeles — Zurich arrive at the following airports: Zurich.
<G-vec00217-002-s529><arrive.landen><de> Flüge Los Angeles – Zürich landen in den folgenden Flughäfen: Zurich (Kloten).
<G-vec00217-002-s530><arrive.landen><en> Flights Dubai — Singapore arrive at the following airports: Singapore.
<G-vec00217-002-s530><arrive.landen><de> Flüge Dubai – Singapur landen in den folgenden Flughäfen: Changi International.
<G-vec00217-002-s531><arrive.landen><en> Flights Bangkok — Surat Thani arrive at the following airports: Surat Thani.
<G-vec00217-002-s531><arrive.landen><de> Flüge Bangkok – Surat Thani landen in den folgenden Flughäfen: Surat Thani.
<G-vec00217-002-s586><arrive.treffen><en> Next, the fresh produce and ready prepared ingredients you have ordered will arrive.
<G-vec00217-002-s586><arrive.treffen><de> Als nächstes treffen die bestellten frischen und fertig vorbereiteten Produkte ein.
<G-vec00217-002-s587><arrive.treffen><en> Invoices must be verified and then paid, orders arrive by fax and delivery receipts must be balanced with purchase orders.
<G-vec00217-002-s587><arrive.treffen><de> Rechnungen müssen geprüft und dann beglichen werden, Bestellungen treffen per Fax ein, Lieferscheine müssen mit Bestellungen abgeglichen werden und Schadensmeldungen sind zur weiteren Abwicklung aufzunehmen.
<G-vec00217-002-s588><arrive.treffen><en> Please arrive at our school at 08.00 on the first morning of your course.
<G-vec00217-002-s588><arrive.treffen><de> Bitte treffen Sie an Ihrem ersten Kurstag um 08.00 Uhr in unserer Schule ein.
<G-vec00217-002-s589><arrive.treffen><en> Non-U.S. orders placed with International Economy Monday-Friday (excluding holidays) are processed within 2 business days, pending credit card authorization and verification, and typically arrive in approximately 5 business days.
<G-vec00217-002-s589><arrive.treffen><de> Internationale Bestellungen (außerhalb der USA) mit International Economy, die Montag - Freitag (mit Ausnahme von Feiertagen) aufgegeben wurden, werden innerhalb von 2 Geschäftstagen vorbehaltlich der Kreditkartenautorisierung und -bestätigung bearbeitet und treffen in der Regel in etwa 5 Geschäftstagen ein.
<G-vec00217-002-s590><arrive.treffen><en> The last 15 km the drive goes over a quite narrow and bumpy road, and at 6.45 p.m. we arrive at the park.
<G-vec00217-002-s590><arrive.treffen><de> Die letzten 15 km geht es über eine recht enge und holprige Straße, und um 18.45 Uhr treffen wir am Park ein.
<G-vec00217-002-s591><arrive.treffen><en> Each and every morning, new travellers will arrive at your oasis with their own specific wants and needs.
<G-vec00217-002-s591><arrive.treffen><de> Jeden Morgen treffen neue Reisende mit ihren eigenen Wünschen und Bedürfnissen in deiner Oase ein.
<G-vec00217-002-s592><arrive.treffen><en> However, some of these trains arrive a bit later than 5:00 am depending on the distance between the target station and the terminal station.
<G-vec00217-002-s592><arrive.treffen><de> Einige dieser Züge treffen jedoch etwas später als 5:00 Uhr morgens ein, abhängig von der Entfernung zwischen der Zielstation und der Endstation.
<G-vec00217-002-s593><arrive.treffen><en> Every week, another 1,500 new refugees arrive in the camps.
<G-vec00217-002-s593><arrive.treffen><de> Jede Woche treffen zurzeit bis zu 1.500 neue Flüchtlinge in den Lagern ein.
<G-vec00217-002-s594><arrive.treffen><en> After 25 days, the containers arrive in Rotterdam.
<G-vec00217-002-s594><arrive.treffen><de> Nach 25 Tagen treffen die Container in Rotterdam ein.
<G-vec00217-002-s595><arrive.treffen><en> When our guests arrive in Alice Springs it is already dark. They are very tired and decide to stay in a hotel for the night.
<G-vec00217-002-s595><arrive.treffen><de> Diese treffen aber erst am Abend ein und sind so müde, dass sie beschliessen in einem Hotel in Alice Springs zu übernachten.
<G-vec00217-002-s596><arrive.treffen><en> Every month new extraordinary furnishings arrive by container.
<G-vec00217-002-s596><arrive.treffen><de> Jeden Monat treffen Container aus Thailand mit neuen außergewöhnlichen Möbeln ein.
<G-vec00217-002-s597><arrive.treffen><en> Allison, Scott and Isaac arrive at the Beacon Hills Preserve.
<G-vec00217-002-s597><arrive.treffen><de> Chris, Allison und Isaac treffen am Krankenhaus ein.
<G-vec00217-002-s598><arrive.treffen><en> Kindly arrive 30 minutes before departure.
<G-vec00217-002-s598><arrive.treffen><de> Treffen Sie bitte 30 Minuten vor Abflug ein.
<G-vec00217-002-s599><arrive.treffen><en> In a large service center, a CCTV camera captures the license plate of cars entering the area. If (existing) customers arrive, the responsible employees receive a message and can make preparations to ensure an optimal client experience.
<G-vec00217-002-s599><arrive.treffen><de> Wird in einem großen Service Center das Kennzeichen eines (Bestands-)Kunden bei der Einfahrt von einer CCTV Kamera erfasst, erhalten zuständige Mitarbeiter eine Nachricht und können alle Vorbereitungen für die optimale Betreuung des Kunden treffen.
<G-vec00217-002-s600><arrive.treffen><en> Mares arrive 30 minutes early, check their clothes and are led to the “stable” after being blindfolded.
<G-vec00217-002-s600><arrive.treffen><de> Die Stuten treffen 30 Minuten früher ein, ziehen sich aus und bekommen einen Sichtschutz aufgesetzt.
<G-vec00217-002-s601><arrive.treffen><en> Orders arrive later and later and your geographic area expands.
<G-vec00217-002-s601><arrive.treffen><de> Bestellungen treffen später ein und die zu beliefernde Region wächst.
<G-vec00217-002-s602><arrive.treffen><en> Below, we will highlight the questions to ask in order to arrive at a fact-based decision in favour of a laser application.
<G-vec00217-002-s602><arrive.treffen><de> Wir zeigen Ihnen nachfolgend auf, welche Fragen Sie sich stellen sollten, um daraufhin eine fundierte Aussage für eine CO2-Laserapplikation zu treffen.
<G-vec00217-002-s603><arrive.treffen><en> March: The first soldiers of the UNO Peace Force arrive.
<G-vec00217-002-s603><arrive.treffen><de> März: Die ersten Soldaten der UNO-Friedenstruppe treffen ein.
<G-vec00217-002-s604><arrive.treffen><en> Six motorised convoys of the US army with troop reinforcements, some 1,500 men, arrive in the city.
<G-vec00217-002-s604><arrive.treffen><de> Sechs Kfz-Konvois der US-Armee mit Truppenverstärkungen, rund 1.500 Mann, treffen in der Stadt ein.
<G-vec00218-002-s210><arrive.anreisen><en> We recommend all visitors to arrive by public transport (10 minutes walking distance to Zurich main station or to the tram stop Central).
<G-vec00218-002-s210><arrive.anreisen><de> Wir empfehlen allen Besucher*innen, mit den öffentlichen Verkehrsmitteln anzureisen (10 Minuten Gehdistanz zum Hauptbahnhof Zürich oder zur Tramhaltestelle Central).
<G-vec00218-002-s370><arrive.finden><en> Since the Oslo agreement, these governments especially undertook great efforts to arrive at a lasting peace settlement.
<G-vec00218-002-s370><arrive.finden><de> Seit der Vereinbarung von Oslo, 1983 [SIC, should be 1993], haben ebendiese Regierungen sehr große Anstrengungen unternommen, eine dauerhafte Regelung für den Frieden zu finden.
