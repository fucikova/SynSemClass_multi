<G-vec00380-003-s019><clean_up.bereinigen><en> This helps to clean up the edges around the Keyed image.
<G-vec00380-003-s019><clean_up.bereinigen><de> Dies hilft, die Ränder um das kodierte Bild zu bereinigen.
<G-vec00380-003-s020><clean_up.bereinigen><en> It has the ability to clean your junk file.
<G-vec00380-003-s020><clean_up.bereinigen><de> Es hat die Fähigkeit, Ihre Junk-Datei zu bereinigen.
<G-vec00380-003-s021><clean_up.bereinigen><en> Correct, clean up and enrich your product data to create tailored, optimized data feeds.
<G-vec00380-003-s021><clean_up.bereinigen><de> Verbessern, bereinigen und reichern Sie Ihre Produktdaten an, um perfekt optimierte Daten-Feeds zu erstellen.
<G-vec00380-003-s022><clean_up.bereinigen><en> It's your responsibility to clean your email lists outside of SurveyMonkey before using them on the site.
<G-vec00380-003-s022><clean_up.bereinigen><de> Sie sind dafür verantwortlich, Ihre E-Mail-Listen außerhalb von SurveyMonkey zu bereinigen, bevor Sie sie auf der Website verwenden.
<G-vec00380-003-s023><clean_up.bereinigen><en> HTML based documentation formats (CHM, HTML, ePub, Kindle and Qt Help) can now optionally clean the output directory before generating the documentation, making it easier to create perfectly clean documentation without any deleted or outdated content: you can choose between “Never clean”, “Always clean” or “Ask before cleaning” from the build settings to make sure that it fits your specific workflow.
<G-vec00380-003-s023><clean_up.bereinigen><de> Die HTML-basierten Dokumentationsformate (CHM, HTML, ePub, Kindle und Qt-Hilfe) können jetzt das Ausgabeverzeichnis optional vor der Generierung der Dokumentation bereinigen, sodass Sie auf einfache Weise eine einwandfrei saubere Dokumentation ohne gelöschte oder veraltete Inhalte erstellen können: Sie können unter den Build-Einstellungen zwischen “Nie bereinigen”, “Immer bereinigen” oder “Vor dem Bereinigen fragen” auswählen und so die für Ihren spezifischen Arbeitsablauf passende Einstellung auswählen.
<G-vec00380-003-s026><clean_up.bereinigen><en> Clean up the neighborhood by destroying the goos with Koala Koala and his arsenal of magic potions.
<G-vec00380-003-s026><clean_up.bereinigen><de> Bereinigen Sie die Nachbarschaft durch die Zerstörung der Goos mit Koala Koala und seinem Arsenal von Zaubertränken.
<G-vec00380-003-s027><clean_up.bereinigen><en> Jean Marie clean up the rooms every day.
<G-vec00380-003-s027><clean_up.bereinigen><de> Jean Marie bereinigen die Zimmer jeden Tag.
<G-vec00380-003-s028><clean_up.bereinigen><en> Over 30 one-touch tools—clean your drive, secure private files, take screenshots, or download a video all with just a single click.
<G-vec00380-003-s028><clean_up.bereinigen><de> Mehr als 30 One-Touch-Tools: Laufwerke bereinigen, private Dateien sichern, Screenshots erstellen oder Videos herunterladen – alles mit nur einem Klick.
<G-vec00380-003-s029><clean_up.bereinigen><en> 3×02 Phoenix – Clark has to clean up his mess, including the providing of another blood sample.
<G-vec00380-003-s029><clean_up.bereinigen><de> 3×02 Phoenix – Clark muss das Chaos bereinigen, welches er hinterlassen hat, was eine neue Blutprobe einschließt.
<G-vec00380-003-s030><clean_up.bereinigen><en> And this also happens on iPhone and iPad, but you can get hold of an application that helps you to clean iOS and improve its performance.
<G-vec00380-003-s030><clean_up.bereinigen><de> Und das passiert auch auf iPhone und iPad, aber Sie können sich aber eine Anwendung holen, die Ihnen hilft, Ihr iOS zu bereinigen und die Leistung zu verbessern.
<G-vec00380-003-s031><clean_up.bereinigen><en> This is a requirement because customers typically clean up and architect their SharePoint solutions again as part of the upgrade, which we recommend.
<G-vec00380-003-s031><clean_up.bereinigen><de> Dies ist erforderlich, da Kunden im Rahmen des Upgrades ihre SharePoint-Lösungen meist bereinigen und neu gestalten, was wir empfehlen.
<G-vec00380-003-s032><clean_up.bereinigen><en> With Autodesk ReCap you can also access a wide range of tools and, for instance, clean the unwanted objects to work more specifically on a precise object!
<G-vec00380-003-s032><clean_up.bereinigen><de> Mit Autodesk ReCap haben Sie Zugriff auf eine Vielzahl von Werkzeugen und können beispielsweise unerwünschte Objekte bereinigen, um ein präzises 3D-Modell zu erhalten.
<G-vec00380-003-s033><clean_up.bereinigen><en> Clean up all of your files that include your account passwords, messages and photos.
<G-vec00380-003-s033><clean_up.bereinigen><de> Bereinigen Sie alle Dateien, die Ihre Passwörter, Nachrichten und Fotos enthalten.
<G-vec00380-003-s034><clean_up.bereinigen><en> Select the type of contacts you want to clean out.
<G-vec00380-003-s034><clean_up.bereinigen><de> Wählen Sie auf der nächsten Seite diejenigen Kontakte, die Sie bereinigen möchten.
<G-vec00380-003-s035><clean_up.bereinigen><en> You can clean up these lists.
<G-vec00380-003-s035><clean_up.bereinigen><de> Sie können diese Listen bereinigen.
<G-vec00380-003-s036><clean_up.bereinigen><en> The program integrates into most modern browsers, can clean their visiting history, temporary files and data, includes a window with detailed connection statistics, can record and export logs in txt format.
<G-vec00380-003-s036><clean_up.bereinigen><de> Das Programm lässt sich in die meisten modernen Browser integrieren, kann den Besuchsverlauf bereinigen, temporäre Dateien und Daten bereinigen, enthält ein Fenster mit detaillierten Verbindungsstatistiken, kann Protokolle im TXT-Format aufzeichnen und exportieren.
<G-vec00380-003-s037><clean_up.bereinigen><en> Scan and clean your computer from PUPs periodically with our the Free Emsisoft Emergency Kit.
<G-vec00380-003-s037><clean_up.bereinigen><de> Prüfen Sie Ihren Computer auf PUPs und bereinigen Sie ihn regelmäßig, zum Beispiel auch mit dem kostenlosen Emsisoft Emergency Kit.
<G-vec00380-003-s228><clean_up.putzen><en> She continued to frequent the church with three of her companions, clean it and decorate the altar.
<G-vec00380-003-s228><clean_up.putzen><de> Sie ging also weiterhin mit ihren drei Freundinnen zur Pfarrkirche, um sie zu putzen und den Altar zu schmücken.
<G-vec00380-003-s229><clean_up.putzen><en> Just as our tenants should have no problems with pets - even if we can before we left to clean the house, of course, you can not eliminate all traces of the animals living here.
<G-vec00380-003-s229><clean_up.putzen><de> Genauso sollten unsere Mieter keine Probleme mit Haustieren haben - auch wenn wir natürlich vor unserer Abreise das Haus putzen kann man nicht alle Spuren der hier lebenden Tiere beseitigen.
<G-vec00380-003-s230><clean_up.putzen><en> Clean the spring onion and cut it into fine rings.
<G-vec00380-003-s230><clean_up.putzen><de> Die Frühlingszwiebel putzen und in feine Ringe schneiden.
<G-vec00380-003-s231><clean_up.putzen><en> The brush can clean your teeth, whiten your teeth, massage your gums, prevent tooth decay, remove plaque and coffee stain.
<G-vec00380-003-s231><clean_up.putzen><de> Die Bürste kann Ihre Zähne putzen, Ihre Zähne bleichen, Ihr Zahnfleisch massieren, Karies vorbeugen, Plaque und Kaffeeflecken entfernen.
<G-vec00380-003-s232><clean_up.putzen><en> Clean, wash and cut spring onions into rings.
<G-vec00380-003-s232><clean_up.putzen><de> Lauchzwiebeln putzen, waschen und in Ringe schneiden.
<G-vec00380-003-s233><clean_up.putzen><en> If you attend regular appointments for dental care and prophylaxis at your dentist and also clean your teeth regularly at home, you are unlikely to be affected.
<G-vec00380-003-s233><clean_up.putzen><de> Wenn Sie regelmäßig die Nachsorge- und Prophylaxetermine wahrnehmen und auch zu Hause regelmäßig die Zähne putzen, sollten Sie diesbezüglich auf der sicheren Seite sein.
<G-vec00380-003-s234><clean_up.putzen><en> Well, she already has a lot of work with four lawyers and an apprentice. And then when she comes home she has to clean the house that we all make dirty.
<G-vec00380-003-s234><clean_up.putzen><de> Nun, als hätte sie mit den anderen vier Anwälten und dem Lehrling nicht schon genug zu tun...Und wenn sie dann heimkommt, muss sie noch den Dreck, den wir alle machen, putzen.
<G-vec00380-003-s235><clean_up.putzen><en> After Christian had cut open the diesel tank 2 years ago in the boatyard (in order to clean out the goo that had accumulated over 25 years) he resealed the tank with red silicone which now started to dissolve.
<G-vec00380-003-s235><clean_up.putzen><de> Nachdem Christian den Tank vor 2 Jahren in der Werft aufgeschnitten hatte (um den Dreck von 25 Jahren raus zu putzen), versiegelte er den Tank mit rotem Silikon, das jetzt begann sich aufzulösen.
<G-vec00380-003-s236><clean_up.putzen><en> Meanwhile, wash the rhubarb, clean and remove the threads.
<G-vec00380-003-s236><clean_up.putzen><de> Inzwischen den Rhabarber waschen, putzen, entfädeln.
<G-vec00380-003-s237><clean_up.putzen><en> AC: I ask people, “Would you clean a rental car before you return it?” Most people say they wouldn’t because it’s not theirs and they don’t really care about it.
<G-vec00380-003-s237><clean_up.putzen><de> AC: Ich stelle Menschen häufig die Frage: „Würden Sie einen Mietwagen putzen, bevor Sie ihn zurückgeben?“ Die meisten Menschen verneinen dies, weil das Auto nicht ihnen gehört und sie sich nichts daraus machen.
<G-vec00380-003-s238><clean_up.putzen><en> The young girl seems to be a faithful soul, only she needs to learn to clean better.
<G-vec00380-003-s238><clean_up.putzen><de> Das junge Mädchen ist scheinbar eine treue Seele nur muss sie noch ordentlicher putzen lernen.
<G-vec00380-003-s239><clean_up.putzen><en> Clean the peppers, potatoes and root and cut into small cubes.
<G-vec00380-003-s239><clean_up.putzen><de> Paprikaschoten, Kartoffeln und Wurzel putzen und in kleine Würfel schneiden.
<G-vec00380-003-s240><clean_up.putzen><en> Again, you have free choice to "clean the window" of your soul to see whatever part you need to.
<G-vec00380-003-s240><clean_up.putzen><de> Nochmals, ihr habt freie Wahl „das Fenster eurer Seele zu putzen“ um jedweden Teil zu sehen den {zu sehen} ihr nötig habt.
<G-vec00380-003-s241><clean_up.putzen><en> Being an oil-based paint, and very thick at that, it is a hassle to clean up.
<G-vec00380-003-s241><clean_up.putzen><de> Da es eine Farbe auf Ölbasis ist, und noch dazu eine sehr zähe, ist das Putzen äußerst mühsam.
<G-vec00380-003-s242><clean_up.putzen><en> On the issue of cleanliness, we do our best to clean the apartment thoroughly before a guest's arrival but it can be difficult to thoroughly clean everything when it has been a month or more since the last turnover.
<G-vec00380-003-s242><clean_up.putzen><de> Was die Sauberkeit betrifft, so tun wir unser Bestes, die Wohnung vor der Ankunft eines Gastes gründlich zu putzen, aber das kann schwierig werden, wenn der letzte Mieterwechsel bereits einen Monat, oder länger zurückliegt.
<G-vec00380-003-s243><clean_up.putzen><en> Richie tries to explain himself intimidated, but the young dominant lady of the house orders what to him only in pungent tone as he has to clean.
<G-vec00380-003-s243><clean_up.putzen><de> Richie versucht sich eingeschüchtert zu erklären, doch die junge dominante Hausherrin befiehlt ihm nur in strengem Ton was er wie zu putzen hat.
<G-vec00380-003-s244><clean_up.putzen><en> Let yourself be tied up, clean and like to go for a walk.
<G-vec00380-003-s244><clean_up.putzen><de> Lasst sich brav anbinden, putzen und geht gern spazieren.
<G-vec00380-003-s245><clean_up.putzen><en> Besides, writing in a café keeps you safe from the desire to clean your apartment instead of working on your novel.
<G-vec00380-003-s245><clean_up.putzen><de> Außerdem garantiert die Schreibarbeit im Kaffeehaus, dass einen nicht das plötzliche und dringende Bedürfnis überfällt, die Wohnung zu putzen, anstatt am Roman zu arbeiten.
<G-vec00380-003-s246><clean_up.putzen><en> Don't forget to clean the tables and pick up tips.
<G-vec00380-003-s246><clean_up.putzen><de> Vergiss nicht, nach jedem Kunden den Tisch zu putzen und Trinkgeld einzukassieren.
<G-vec00380-003-s133><clean_up.reinigen><en> Using fingertips, apply evenly on clean skin.
<G-vec00380-003-s133><clean_up.reinigen><de> Mit den Fingerspitzen gleichmäßig auf die gereinigte Haut auftragen.
<G-vec00380-003-s134><clean_up.reinigen><en> The ultrasonic humidifier B 6 E humidifies the room air - and, if required, ensures clean and fragrant air.
<G-vec00380-003-s134><clean_up.reinigen><de> Der Ultraschall-Luftbefeuchter B 5 E befeuchtet die Raumluft - und sorgt auf Wunsch für gereinigte Luft.
<G-vec00380-003-s135><clean_up.reinigen><en> Use: Apply on clean skin once or twice daily, according to each case.
<G-vec00380-003-s135><clean_up.reinigen><de> Benutzen: Bewerben auf die gereinigte Haut einmal oder zweimal täglich, je nach Fall.
<G-vec00380-003-s136><clean_up.reinigen><en> Application: apply the gel to clean skin after shaving or waxing and massage gently.
<G-vec00380-003-s136><clean_up.reinigen><de> Anwendung: das Gel auf die gereinigte Haut nach dem Rasieren oder Depilation auftragen und sanft einmassieren.
<G-vec00380-003-s137><clean_up.reinigen><en> Application: Apply to clean skin once to three times a week.
<G-vec00380-003-s137><clean_up.reinigen><de> Anwendung: 1-3 mal wöchentlich auf die gereinigte Haut auftragen.
<G-vec00380-003-s138><clean_up.reinigen><en> Gently apply to clean skin.
<G-vec00380-003-s138><clean_up.reinigen><de> Sanft auf die gereinigte Haut auftragen.
<G-vec00380-003-s139><clean_up.reinigen><en> Application: Apply with the massaging movements to clean skin 3-4 times daily.
<G-vec00380-003-s139><clean_up.reinigen><de> Anwendung: Tragen Sie mit den massierenden Bewegungen auf die gereinigte Haut 3-4-mal täglich.
<G-vec00380-003-s140><clean_up.reinigen><en> - Apply a thick layer of HYDRA BEAUTY Mask to clean, dry skin, avoiding the eye area.
<G-vec00380-003-s140><clean_up.reinigen><de> - Die Maske großzügig auf die gereinigte und trockene Haut auftragen, dabei die Augenkontur aussparen.
<G-vec00380-003-s141><clean_up.reinigen><en> Apply on clean skin before your moisturizer.
<G-vec00380-003-s141><clean_up.reinigen><de> Morgens und abends vor der Feuchtigkeitscreme auf die gereinigte Haut auftragen.
<G-vec00380-003-s142><clean_up.reinigen><en> Sparingly apply polish with the help of the polishing fleece which is included in the scope of delivery to the clean and dry surface and rub in for 1-2 minutes using slight pressure.
<G-vec00380-003-s142><clean_up.reinigen><de> Sparsam die Politur mit dem mitgelieferten Poliervlies auf die gereinigte und trockene Oberfläche auftragen und mit leichtem Druck 1-2 Minuten einpolieren.
<G-vec00380-003-s143><clean_up.reinigen><en> Massage the cream on clean skin of the face, neck and décolleté every morning and evening.
<G-vec00380-003-s143><clean_up.reinigen><de> Anwendung: Jeden Morgen und Abend auf die gereinigte Haut der Augenpartie und Lider auftragen.
<G-vec00380-003-s144><clean_up.reinigen><en> Usage tips Apply Supremÿa Cream to clean dry skin, in the evening to face, neck and décolleté by massaging gently until the product has become completely absorbed.
<G-vec00380-003-s144><clean_up.reinigen><de> Tragen Sie Supremÿa Baume abends mit leichten Massagebewegungen auf die gereinigte, trockene Haut von Gesicht, Hals und Dekolleté auf, bis das Produkt vollständig eingezogen ist.
<G-vec00380-003-s145><clean_up.reinigen><en> Use: Apply as a regular moisturizer on clean skin.
<G-vec00380-003-s145><clean_up.reinigen><de> Anwendung: als normale Feuchtigkeitscreme auf die gereinigte Haut.
<G-vec00380-003-s146><clean_up.reinigen><en> Directions for use: Apply a generous amount onto clean skin and massage until absorbed. Marca: DECLEOR
<G-vec00380-003-s146><clean_up.reinigen><de> Gebrauchsanweisung: Trage eine großzügige Menge auf die gereinigte Haut auf und massiere die Creme ein, bis sie völlig eingezogen ist.
<G-vec00380-003-s147><clean_up.reinigen><en> Apply on clean skin over all the face, neck and cleavage in a light ascending massage until the product has been completely absorbed.
<G-vec00380-003-s147><clean_up.reinigen><de> Serum mit sanften, aufwärts strebenden Effleurage-Bewegungen auf die gereinigte Haut an Gesicht, Hals und Dekolleté auftragen, bis das Produkt vollständig eingezogen ist.
<G-vec00380-003-s148><clean_up.reinigen><en> Usage Massage 1-2 pumps into clean, dry face, neck, and décolleté once daily.
<G-vec00380-003-s148><clean_up.reinigen><de> Einmal täglich 1-2 Pumpstöße auf die gereinigte Haut von Gesicht, Hals und Dekolleté auftragen.
<G-vec00380-003-s149><clean_up.reinigen><en> To efficiently combat ingrown hairs, shaving rash and irritations, Cool Fix should be regularly applied twice a day, once directly after shaving and once in the evening before going to bed (on clean, dry skin).
<G-vec00380-003-s149><clean_up.reinigen><de> Um eingewachsene Haare, Rasurbrand und Irritation effizient den Kampf anzusagen, sollte The Cool fix zweimal am Tag angewendet werden, einmal direkt nach der Rasur und einmal abends vor dem Schlafen gehen (auf gereinigte, trockene Haut).
<G-vec00380-003-s150><clean_up.reinigen><en> Description Enjoy the Dermalogica Cleanse & Tone Duo for Oily Skin and remove the day’s impurities to reveal fresh clean skin.
<G-vec00380-003-s150><clean_up.reinigen><de> Beschreibung Genieße das Dermalogica Cleanse & Tone Duo für fettige Haut und entferne die Verunreinigungen des Tages, um frisch gereinigte Haut zum Vorschein zu bringen.
<G-vec00380-003-s151><clean_up.reinigen><en> The filters we clean achieve normally the same performance as new ones.
<G-vec00380-003-s151><clean_up.reinigen><de> Von uns gereinigte Filter haben in der Regel die gleiche Performance wie neue.
<G-vec00380-003-s551><clean_up.säubern><en> One thought behind this is that it exposes the water to more surface area allowing naturally occurring bacteria to help clean the water.
<G-vec00380-003-s551><clean_up.säubern><de> Der Gedanke dahinter ist, dass das Wasser dadurch einer größeren Oberfläche ausgesetzt wird, wodurch die natürlichen Bakterien dabei helfen können, es zu säubern.
<G-vec00380-003-s552><clean_up.säubern><en> Use that to clean the rope and then rinse with another damp cloth with water only.
<G-vec00380-003-s552><clean_up.säubern><de> Mit diesem Tuch die schmutzigen Bänder säubern und mit einem anderen, nur mit Wasser befeuchteten Tuch, abwischen.
<G-vec00380-003-s553><clean_up.säubern><en> Disinfect and clean the balloon regularly.
<G-vec00380-003-s553><clean_up.säubern><de> Desinfizieren Sie und säubern Sie den Ballon regelmäßig.
<G-vec00380-003-s554><clean_up.säubern><en> Clean the cod and cut into small cubes, turn in a bowl with lime juice, salt, pepper and chopped coriander.
<G-vec00380-003-s554><clean_up.säubern><de> Säubern Sie den Kabeljau und schneiden ihn in kleine Würfel, dann in einer Schüssel mit Limettensaft, Salz, Pfeffer und gehacktem Koriander wenden.
<G-vec00380-003-s555><clean_up.säubern><en> According to his lawyer, when he "did not clean up the excrement, a large IRF team of 10 guards was ordered to his cell and beat him severely.
<G-vec00380-003-s555><clean_up.säubern><de> Als er sich weigerte, diese zu säubern, wurde seinem Anwalt zufolge "ein 10-köpfiges IRF-Team zu seiner Zelle beordert und verprügelte ihn massiv.
<G-vec00380-003-s556><clean_up.säubern><en> The selection of food was poor, the orange and apple juices didn't taste good, and the waiters used too much time to clean the tables.
<G-vec00380-003-s556><clean_up.säubern><de> Die Auswahl an Essen war schlecht, die Orangen- und Apfelsaft schmeckte nicht gut, und die Kellner haben viel Zeit die Tische zu säubern.
<G-vec00380-003-s557><clean_up.säubern><en> De Mercuur boasts a spacious fishing deck and large fishing tables, on which you can immediately clean your catch.
<G-vec00380-003-s557><clean_up.säubern><de> Das Deck der Mercuur bietet ausreichend Platz zum Angeln und Reinigungsstationen, an denen Sie Ihren Fang sofort säubern können.
<G-vec00380-003-s558><clean_up.säubern><en> To disinfect and clean wounds.
<G-vec00380-003-s558><clean_up.säubern><de> Um Wunden zu säubern und zu desinfizieren.
<G-vec00380-003-s559><clean_up.säubern><en> To enjoy your cufflinks for a lifetime, you have to clean and store them properly.
<G-vec00380-003-s559><clean_up.säubern><de> Um deine Manschettenknöpfe ein Leben lang genießen zu können, solltest du sie regelmäßig säubern und angemessen aufbewahren.
<G-vec00380-003-s560><clean_up.säubern><en> Easy to clean and reusable.
<G-vec00380-003-s560><clean_up.säubern><de> Einfach zu säubern und wiederverwendbar.
<G-vec00380-003-s561><clean_up.säubern><en> It is suggested to scan and clean your PC using AdwCleaner to eliminate malicious infection if any for better experience while surfing web.
<G-vec00380-003-s561><clean_up.säubern><de> Es wird vorgeschlagen, zu scannen und säubern Sie Ihren Computer mit AdwCleaner, um schädliche Infektionen für eine bessere Erfahrung zu beseitigen, während das Surfen im Web.
<G-vec00380-003-s562><clean_up.säubern><en> Around 800 Jews were kept in a barrack to clean the ghetto area.
<G-vec00380-003-s562><clean_up.säubern><de> Etwa 800 Juden wurden in Lodz zurück gehalten um das Ghetto zu säubern.
<G-vec00380-003-s563><clean_up.säubern><en> Always clean the accumulated dust and grease with a dry cloth to keep your SPC Stork clean.
<G-vec00380-003-s563><clean_up.säubern><de> Säubern Sie den Staub und das angesammelte Fett mit einem trockenen Tuch, damit Ihr SPC Stork stets frisch bleibt.
<G-vec00380-003-s564><clean_up.säubern><en> You have to clean her shoes with your weak tongue, lying on the dirty floor!
<G-vec00380-003-s564><clean_up.säubern><de> Auf dem dreckigen Boden liegend, hast du ihre Schuhe mit deiner kleinen schwächlichen Zunge zu säubern.
<G-vec00380-003-s565><clean_up.säubern><en> The advantage of this device lies in the combination of mechanical, chemical and thermal cleaning power: with the addition of a cleaning rod per pass clean rotating polishing needles the prosthesis.
<G-vec00380-003-s565><clean_up.säubern><de> Der Vorteil dieses Gerätes liegt in der Kombination von mechanischer, chemischer und thermischer Reinigungskraft: Unter der Zugabe eines Reinigungstabs pro Durchgang säubern rotierende Poliernadeln die Prothese.
<G-vec00380-003-s566><clean_up.säubern><en> Before I start colouring the image, I use the dodge and burn tool to clean the image further and get rid of extra colours using saturation.
<G-vec00380-003-s566><clean_up.säubern><de> Bevor ich anfange, das Bild einzufärben, benutze ich das Abwedler- und Brennwerkzeug, um das Bild weiter zu säubern und zusätzliche Farben durch Sättigung zu entfernen.
<G-vec00380-003-s567><clean_up.säubern><en> Click left to shoot and clean the table before your time is up.
<G-vec00380-003-s567><clean_up.säubern><de> Klicken Sie auf die Links um zu schießen und den Tisch zu säubern, bevor deine Zeit abgelaufen ist.
<G-vec00380-003-s568><clean_up.säubern><en> These planets then effectively spring clean their orbits, clearing them of gas and dust and herding the remaining material into well-defined bands.
<G-vec00380-003-s568><clean_up.säubern><de> Diese Planeten säubern dann sozusagen ihre Umlaufbahn, indem sie das dort befindliche Gas und den Staub vereinnahmen und das verbleibende Material in wohldefinierten Bändern ansammeln.
<G-vec00380-003-s569><clean_up.säubern><en> The design creates a space in which the user can concentrate on what he’s doing.” “It’s also worth noting the industrial nature of the design, the smooth, jointless surface, which is beautiful and easy to clean,” states Rianne Makkink, with Suvi Saloniemi adding: “In theory, this kitchen can be installed anywhere there’s a water connection, because it’s not mounted on the wall.
<G-vec00380-003-s569><clean_up.säubern><de> Der Entwurf schafft einen Ort, an dem man sich auf das, was man tut, konzentrieren kann.“ „Außerdem ist das industrielle Design hervorzuheben, die glatte, fugenlose Oberfläche, die schön und einfach zu säubern ist“, so Rianne Makkink, und Suvi Saloniemi ergänzt: „Diese Küche lässt sich theoretisch überall installieren, wo es einen Wasseranschluss gibt, da sie nicht an die Wand montiert ist.
<G-vec00552-002-s304><clean_up.reinigen><en> We hope we’ve answered the question, “How do I clean a steam cooker?”
<G-vec00552-002-s304><clean_up.reinigen><de> Wir hoffen, Ihre Frage „Wie reinige ich einen Dampfgarer?“ beantwortet zu haben.
<G-vec00552-002-s305><clean_up.reinigen><en> A bathroom (under tiled finish) with shower and bath, used by all, especially my children, I clean regularly, but I do not always reverts back my children. new toilet.
<G-vec00552-002-s305><clean_up.reinigen><de> Ein Badezimmer (unter Fliesen Finish) mit Dusche und Badewanne, von allen genutzt, vor allem die Kinder, reinige ich regelmäßig, aber ich kehrt nicht immer meine Kinder zurück.
<G-vec00552-002-s306><clean_up.reinigen><en> I get it out with a forceps and we clean the hole with iodine.
<G-vec00552-002-s306><clean_up.reinigen><de> Vorsichtig ziehe ich sie mit der Zange heraus und reinige das „Nest“ mit Jod.
<G-vec00552-002-s307><clean_up.reinigen><en> I usually clean my skin in the morning and in the evening.
<G-vec00552-002-s307><clean_up.reinigen><de> Ich reinige meine Haut normalerweise morgens und abends.
<G-vec00552-002-s308><clean_up.reinigen><en> Clean the vent on your clothes dryer about once a year.
<G-vec00552-002-s308><clean_up.reinigen><de> Reinige die Entlüftung deines Wäschetrockners einmal im Jahr.
<G-vec00552-002-s309><clean_up.reinigen><en> Using a fresh, sterile alcohol wipe, clean the injection site by gently wiping in a spiral motion from the center outward, being careful not to go back over already clean areas.
<G-vec00552-002-s309><clean_up.reinigen><de> Verwende einen frischen Alkoholtupfer und reinige die Stelle für die Injektion durch ein sanftes Reiben in einer spiralförmigen Bewegung von der Mitte nach außen.
<G-vec00552-002-s310><clean_up.reinigen><en> Clean the bottom of the hoof.
<G-vec00552-002-s310><clean_up.reinigen><de> Reinige die Unterseite des Hufs.
<G-vec00552-002-s311><clean_up.reinigen><en> So be sure to clean your wheels and brake pads regularly, especially when you have been cycling in the rain.
<G-vec00552-002-s311><clean_up.reinigen><de> Reinige daher deine Laufräder und Bremsbeläge regelmäßig, vor allem nach Regenfahrten.
<G-vec00552-002-s312><clean_up.reinigen><en> Clean and dry the base and the edges after each day.
<G-vec00552-002-s312><clean_up.reinigen><de> Reinige und trocknen Sie den Belag und Kanten nach jedem Skitag.
<G-vec00552-002-s313><clean_up.reinigen><en> Clean the walls thoroughly.
<G-vec00552-002-s313><clean_up.reinigen><de> Reinige die Wände gründlich.
<G-vec00552-002-s314><clean_up.reinigen><en> Clean out cupboards and trunks with baking soda or newspapers.
<G-vec00552-002-s314><clean_up.reinigen><de> Reinige Schränke und Kofferräume mit Backnatron oder Zeitungspapier.
<G-vec00552-002-s315><clean_up.reinigen><en> Clean your conscience Clear your thoughts with speyside
<G-vec00552-002-s315><clean_up.reinigen><de> Reinige dein Gewissen, leere deine Gedanken mit Whiskey.
<G-vec00552-002-s316><clean_up.reinigen><en> Clean it according to the type of surface.
<G-vec00552-002-s316><clean_up.reinigen><de> Reinige es entsprechend der Art der Oberfläche.
<G-vec00552-002-s317><clean_up.reinigen><en> 1 Clean your DE razor and splash your face with cold water.
<G-vec00552-002-s317><clean_up.reinigen><de> 1 Reinige deinen zweischneidigen Rasierer und dein Gesicht mit kaltem Wasser.
<G-vec00552-002-s318><clean_up.reinigen><en> Clean both surfaces of the plates with alcohol.
<G-vec00552-002-s318><clean_up.reinigen><de> Reinige beide Oberflächen der Platten mit Alkohol.
<G-vec00552-002-s319><clean_up.reinigen><en> Thoroughly clean your plate with hot water and dry well.
<G-vec00552-002-s319><clean_up.reinigen><de> Reinige deine Plate gründlich mit heißem Wasser und trockne sie gut ab.
<G-vec00552-002-s320><clean_up.reinigen><en> When it's time to put the machine away after the winter, clean it thoroughly and make sure it is completely dry before putting it away.
<G-vec00552-002-s320><clean_up.reinigen><de> Wenn es nach dem Winter Zeit wird, das Gerät wegzustellen, dann reinige es sorgfältig und achte darauf, dass es vollkommen trocken ist, bevor du es wegräumst.
<G-vec00552-002-s321><clean_up.reinigen><en> Having dried the mattress and pillow... the sitting cloth and sheet in the sun, clean them, shake them out, bring them back in, and place them where they were before.
<G-vec00552-002-s321><clean_up.reinigen><de> Die Matratze und Poster... das Sitztuch und das Laken in der Sonne getrocknet, reinige sie, schüttle sie aus, bringe sie zurück hinein und platziere sie dort, wo sie zuvor waren.
<G-vec00552-002-s322><clean_up.reinigen><en> Add several tablespoons of salt to a gallon of warm water and clean the windows in your house and car with it.
<G-vec00552-002-s322><clean_up.reinigen><de> Vermische mehrere Esslöffel Salz mit etwa 4 Liter warmem Wasser und reinige damit die Fenster im Haus und im Auto.
