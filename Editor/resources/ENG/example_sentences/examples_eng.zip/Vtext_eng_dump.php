<G-vec00555-002-s090><dump.entleeren><en> If you bale too slowly, the boat will sink lower; if you dump the water too quickly, you may rise above the desired level (which may or may not be a problem).
<G-vec00555-002-s090><dump.entleeren><de> Wenn Sie zu langsam emballieren, sinkt das Boot niedriger; wenn Sie das Wasser zu schnell entleeren, steigen möglicherweise Sie über das gewünschte Niveau (das ein Problem vielleicht ist).
<G-vec00555-002-s091><dump.entleeren><en> It would be desirable to dump everything in the script, it is necessary to work on many other elements.
<G-vec00555-002-s091><dump.entleeren><de> Es wäre wünschenswert, alles im Skript zu entleeren, ist es notwendig, auf vielen anderen Elementen zu arbeiten.
<G-vec00555-002-s092><dump.entsorgen><en> Insufficient amount of bicarbonates in our blood reduces our capabilities to manage (neutralize and dump) the acid our body produces.
<G-vec00555-002-s092><dump.entsorgen><de> Durch zu wenig Bicarbonate im Blut reduziert sich unsere Fähigkeiten die Säuren, die unser Körper produziert, zu verwalten, d.h. diese zu neutralisieren und zu entsorgen.
<G-vec00555-002-s093><dump.entsorgen><en> The 4.5 million residents of Nairobi, the capital of Kenya, burn their trash or dump it illegally in the city because adequate waste disposal is unaffordable.
<G-vec00555-002-s093><dump.entsorgen><de> Die 4,5 Millionen Einwohnerinnen und Einwohner der kenianischen Hauptstadt Nairobi verbrennen ihren Müll oder entsorgen ihn illegal in der Stadt, weil umweltverträgliche Abfallentsorgung zu teuer ist.
<G-vec00555-002-s164><dump.schütten><en> Don’t dump your unfiltered knowledge on me, I’m dumb.
<G-vec00555-002-s164><dump.schütten><de> Schütte mich nicht mit Deinem ungefilterten Wissen zu, ich bin dumm.
<G-vec00555-002-s165><dump.schütten><en> Dump any remaining vinegar solution in the reservoir in the sink.
<G-vec00555-002-s165><dump.schütten><de> Schütte alle verbliebene Essiglösung im Tank ins Spülbecken.
<G-vec00555-002-s183><dump.wegwerfen><en> More than a quarter of us are ready to dump all of our emails and start over.
<G-vec00555-002-s183><dump.wegwerfen><de> Über die Hälfte von uns sind bereit, alle ihre E-Mails wegzuwerfen und neu anzufangen.
<G-vec00555-002-s184><dump.wegwerfen><en> Also, a former post hoc student, Anja Zimmermann, was told to dump the questionnaires from previous years when moving into the offices at the UvA building in 2007 (by a different person).
<G-vec00555-002-s184><dump.wegwerfen><de> Zudem wurde eine frühere Kollegin, Dr. Anja Zimmermann, ebenfalls gebeten, ihre Fragebögen aus vorigen Jahren wegzuwerfen, als sie 2007 an die UvA kam.
<G-vec00555-002-s185><dump.zerstören><en> 1773 – American Revolution: Boston Tea Party – Members of the Sons of Liberty disguised as Mohawks dump crates of tea into Boston harbor as a protest against the Tea Act.
<G-vec00555-002-s185><dump.zerstören><de> 1773: Boston Tea Party 1773: Die Söhne der Freiheit, als Indianer verkleidete Bürger von Boston entern Schiffe der englischen East India Company und zerstören drei Ladungen Tee.
<G-vec00555-002-s186><dump.zerstören><en> We’ll dump the dollar.
<G-vec00555-002-s186><dump.zerstören><de> Wir werden den Dollar zerstören.
