<G-vec00092-001-s076><believe.glauben><en> 1:21)—those who believe into him—for we read that the wrath of God continues to abide on the unbeliever.—John 3:36
<G-vec00092-001-s076><believe.glauben><de> 1:21), zu denen, die an ihn glauben, denn wir lesen, dass der Zorn Gottes auf den Ungläubigen lasten bleibt (Joh.
<G-vec00092-001-s077><believe.glauben><en> However, because some people did not believe in success, he surrendered the leadership.
<G-vec00092-001-s077><believe.glauben><de> Doch wegen Mangels an Glauben bei einigen Personen in den Erfolg verzichtete er auf die Leitung.
<G-vec00092-001-s078><believe.glauben><en> They lump me in with people who believe in extraterrestrials and so on.
<G-vec00092-001-s078><believe.glauben><de> Sie scheren mich mit Menschen über einen Kamm, die an Außerirdische und so weiter glauben.
<G-vec00092-001-s079><believe.glauben><en> If you believe in love at first sight, then this is your wedding dress!
<G-vec00092-001-s079><believe.glauben><de> Wenn Sie an Liebe auf den ersten Blick glauben, ist dies das perfekte Brautkleid für Sie.
<G-vec00092-001-s080><believe.glauben><en> This call is, of course, closely related to the call to believe more firmly in God, because when we believe more firmly, then our heart is already in God.
<G-vec00092-001-s080><believe.glauben><de> Dieser Aufruf ist natürlich tief verbunden mit dem Aufruf, fester an Gott zu glauben, denn wenn wir fester an Gott glauben, dann ist unser Herz schon in Gott.
<G-vec00092-001-s081><believe.glauben><en> Because this Power is becoming more and more obvious – this Truth-Power – and naturally human thought, which is childish (it has the same attitude towards supramental thought as what we may call animal thought or sentiment has towards human thought or sentiment), has almost a need for superstition (“superstition” is an ugly word for something that's not ugly: it's an ignorant, ingenuous and very trusting faith), and, well, as soon as you feel the influence of a Power, that faith makes you believe in the miracle, it makes you believe that the Supramental is going to manifest now, that you are going to become supramental, and that...
<G-vec00092-001-s081><believe.glauben><de> Denn diese Kraft wird immer offensichtlicher – diese Kraft der Wahrheit –, und natürlich bedarf das menschliche Denken, das von kindlicher Beschaffenheit ist (es hat zum supramentalen Denken die gleiche Beziehung wie es das, was man als animalisches Denken oder Empfinden bezeichnen kann, dem menschlichen Empfinden und Denken gegenüber hegt), beinahe eines Aberglaubens (Aberglaube ist ein häßliches Wort für etwas, das nicht eigentlich häßlich, sondern ein unwissender, naiver und sehr vertrauensvoller Glaube ist), und genau dieser Glaube läßt einen dann an Wunder glauben, sobald man den Einfluß einer Kraft fühlt – er läßt einen denken, daß das Supramental sich bald manifestiert und man supramental wird und...
<G-vec00092-001-s082><believe.glauben><en> There are those who believe the self-same message that we do, the Israel Identity Truth and the ACTS 2:38 message of full salvation.
<G-vec00092-001-s082><believe.glauben><de> Es gibt welche, die an dieselbe Botschaft glauben wie wir, die Wahrheit über Israels Identität und die Botschaft von APOSTELGESCHICHTE 2:38 über die völlige Erlösung.
<G-vec00092-001-s083><believe.glauben><en> You don't know yours, or you won't believe it.
<G-vec00092-001-s083><believe.glauben><de> Du kennst den deinen nicht, oder du wirst an ihn nicht glauben.
<G-vec00092-001-s084><believe.glauben><en> You may not say that you believe in God and Jesus Christ if you continue in all your sins.
<G-vec00092-001-s084><believe.glauben><de> Sie dürfen nicht sagen, dass Sie an Gott und an Jesus Christus glauben, wenn Sie mit allen Ihren Sünden fortsetzen.
<G-vec00092-001-s085><believe.glauben><en> An outstanding aspect of the Islamic belief in prophethood is that Muslims believe in and respect all the messengers of God with no exceptions.
<G-vec00092-001-s085><believe.glauben><de> Eine herausragende Seite des Islamischen Glaubens an das Prophetentum ist, daß die Muslime an alle Gesandten Gottes ohne Ausnahme glauben und sie alle respektieren.
<G-vec00092-001-s086><believe.glauben><en> Mandela’s story reveals no social deviance but instead retells a story of camaraderie amongst men who believe in the same ideological cause, to destroy racial oppression, and further provides an in-depth account of the routine and regiment of prison life.
<G-vec00092-001-s086><believe.glauben><de> Mandelas Geschichte enthüllt kein sozial abweichendes Verhalten, sondern erzählt stattdessen eine Geschichte von Kameradschaft unter Männern, die an dieselbe Sache glauben, nämlich die Rassenunterdrückung zu überwinden, und vermittelt darüber hinaus eine eingehende Darstellung von Routine und Regiment des Lebens im Gefängnis.
<G-vec00092-001-s087><believe.glauben><en> While we believe God He goes on, no matter what He has to deal with.
<G-vec00092-001-s087><believe.glauben><de> Solange wir an Gott glauben, geht er weiter, ganz gleich, womit er verfahren muss.
<G-vec00092-001-s088><believe.glauben><en> He doesn't believe in coincidences, especially not when someone breaks into his apartment only shortly thereafter.
<G-vec00092-001-s088><believe.glauben><de> An einen Zufall kann er bei der ganzen Sache allerdings nicht glauben, vor allem nicht als dann auch noch in seine Wohnung eingebrochen wird.
<G-vec00092-001-s089><believe.glauben><en> Even now, God acknowledges those who believe in His righteousness.
<G-vec00092-001-s089><believe.glauben><de> Selbst jetzt erkennt Gott diejenigen an, die an Seine Gerechtigkeit glauben.
<G-vec00092-001-s090><believe.glauben><en> "The Lord tells us, who believe in the gospel Word of the water and the Spirit, ""You are saved."
<G-vec00092-001-s090><believe.glauben><de> Der Geist tritt in den Verstand all jener ein, die an das Evangelium aus Wasser und Geist glauben, und verweilt dort.
<G-vec00092-001-s091><believe.glauben><en> If you do not believe in what you say and do not agree with responsibility, then there is no point in self-deception.
<G-vec00092-001-s091><believe.glauben><de> Wenn Sie nicht an das glauben, was Sie sagen, und mit der Verantwortung nicht einverstanden sind, dann hat die Selbsttäuschung keinen Sinn.
<G-vec00092-001-s092><believe.glauben><en> Every day, Vassula and those thousands and thousands of people who believe in the True Life in God messages pray '...and lead us not into temptation, but deliver us from evil.'
<G-vec00092-001-s092><believe.glauben><de> "Jeden Tag beten Vassula und diese Tausenden und aber Tausende von Leuten, die an die Botschaften von ""Das Wahre Leben in Gott"" glauben: ""... und führe uns nicht in Versuchung, sondern Erlöse uns vom Bösen""."
<G-vec00092-001-s093><believe.glauben><en> By having allowed this to be so, the Lord has allowed those who believe in the ministry of John the Baptist and the ministry of Jesus to enter Heaven by receiving the cleansing of sins.
<G-vec00092-001-s093><believe.glauben><de> Dadurch, dem zugelassen zu haben, so zu sein, hat der Herr denjenigen erlaubt, die an den Dienst Johannes des Täufers und an das Wirken Jesu glauben, in den Himmel, indem sie das Reinigen der Sünden empfingen, einzugehen.
<G-vec00092-001-s094><believe.glauben><en> And, with the apostasy from faith, Satan's raging will also become progressively more evident, for people will lose their last sense of responsibility towards a righteous Judge because they don't believe in Him.
<G-vec00092-001-s094><believe.glauben><de> Und mit dem Abfall vom Glauben tritt auch das Wüten des Satans mehr und mehr in Erscheinung, denn die Menschen verlieren das letzte Verantwortungsgefühl einem gerechten Richter gegenüber, weil sie nicht an Ihn glauben.
<G-vec00345-001-s095><believe.annehmen><en> 1.Â Â Where the market surveillance authorities of one Member State have sufficient reason to believe that a product presents a risk to the health or safety of persons or to domestic animals or property, they shall carry out an evaluation in relation to the product concerned covering all relevant requirements laid down in this Directive.
<G-vec00345-001-s095><believe.annehmen><de> (1) Haben die Marktüberwachungsbehörden eines Mitgliedstaats hinreichenden Grund zu der Annahme, dass ein Produkt ein Risiko für die Gesundheit oder Sicherheit von Menschen oder für Haus- und Nutztiere oder Güter darstellt, so beurteilen sie, ob das betreffende Produkt alle in dieser Richtlinie festgelegten einschlägigen Anforderungen erfüllt.
<G-vec00345-001-s096><believe.annehmen><en> The hazard category of a tested production batch of a mixture can be assumed to be substantially equivalent to that of another untested production batch of the same commercial product, when produced by or under the control of the same supplier, unless there is reason to believe there is significant variation such that the hazard classification of the untested batch has changed.
<G-vec00345-001-s096><believe.annehmen><de> Chargenanalogie Es kann davon ausgegangen werden, dass die Gefahrenkategorie einer geprüften Produktionscharge eines Gemisches im Wesentlichen der einer anderen, ungeprüften Produktionscharge desselben Handelsprodukts entspricht, das vom selben Lieferanten oder unter seiner Kontrolle erzeugt wurde, sofern kein Anlass zu der Annahme besteht, dass sich bedingt durch eine relevante Veränderung die Einstufung der ungeprüften Charge geändert hat.
<G-vec00345-001-s097><believe.annehmen><en> Being a cleanser, this remedy purifies wounds if the patient has reason to believe that some poison has entered which must be drawn out.
<G-vec00345-001-s097><believe.annehmen><de> Als Reinigungsmittel säubert dieses Mittel Wunden, wenn der Patient Grund zu der Annahme hat, dass etwas Giftiges eingedrungen ist, das herausgezogen werden muss.
<G-vec00345-001-s098><believe.annehmen><en> f) DSGVO is required to assert, exercise or defend legal claims and there is no reason to believe that the data subject has an overriding interest in not disclosing their data, - for the transfer of data according to Art.
<G-vec00345-001-s098><believe.annehmen><de> f) DSGVO zur Geltendmachung, Ausübung oder Verteidigung von Rechtsansprüchen erforderlich ist und kein Grund zur Annahme besteht, dass die betroffene Person ein überwiegendes schutzwürdiges Interesse an der Nichtweitergabe ih-rer Daten hat, – für die Datenübermittlung nach Art.
<G-vec00345-001-s099><believe.annehmen><en> If you have reason to believe that this has occurred, please contact us at info@99roots.com, and we will delete all relevant information.
<G-vec00345-001-s099><believe.annehmen><de> Hast du Grund zu der Annahme, dass dies geschehen ist, kontaktiere uns bitte unter info@99roots.com, und wir werden alle relevanten Informationen löschen.
<G-vec00345-001-s100><believe.annehmen><en> e) to any person who we reasonably believe may apply to a court or other competent authority for disclosure of that personal information where, in our reasonable opinion, such court or authority would be reasonably likely to order disclosure of that personal information.
<G-vec00345-001-s100><believe.annehmen><de> (D) für jede Person, die wir Grund zur Annahme kann zu einem Gericht oder einer anderen zuständigen Behörde zur Offenlegung dieser Daten, wo sich aus unserer Sicht, wie Gericht oder die Behörde wäre mit großer Wahrscheinlichkeit Offenlegung dieser personenbezogenen Daten bestellen anzuwenden.
<G-vec00345-001-s101><believe.annehmen><en> As far as I know, there is very little reason to believe that no intelligent life will follow humans on Earth.
<G-vec00345-001-s101><believe.annehmen><de> Soweit ich weiß gibt es ziemlich wenig Grund zu der Annahme, dass nach dem Aussterben der Menschen keine intelligente Lebensform mehr auf der Erde möglich sein sollte.
<G-vec00345-001-s102><believe.annehmen><en> On the surface, this would lead us to believe that the only way to effectively trade breakouts, is to be at our trading terminals ready to act as soon as the candle closes in breakout territory.
<G-vec00345-001-s102><believe.annehmen><de> Auf den ersten Blick führt uns dies zur der Annahme, dass wir nur dann effektiv Breakouts traden können, wenn wir an unseren Tradingkonsolen sitzen und bereit zum Zuschlagen sind, sobald die Kerze im Breakout-Bereich schließt.
<G-vec00345-001-s103><believe.annehmen><en> There are reasons to believe that Aryabhata devised a particular method for finding this value.
<G-vec00345-001-s103><believe.annehmen><de> Es gibt Grund zu der Annahme, dass Aryabhata entwickelte eine besondere Methode zum Auffinden von diesem Wert.
<G-vec00345-001-s104><believe.annehmen><en> Apart from where you have consented or disclosure is necessary to achieve the purpose for which it was submitted, personal information may be disclosed in special situations where we have reason to believe that doing so is necessary to identify, contact or bring legal action against anyone damaging, injuring, or interfering (intentionally or unintentionally) with our rights or property, users, or anyone else who could be harmed by such activities.
<G-vec00345-001-s104><believe.annehmen><de> Abgesehen von denen Sie zugestimmt haben oder Weitergabe notwendig ist, um den Zweck, für den sie eingereicht zu erreichen, können persönliche Informationen in besonderen Situationen, wo wir Grund zur Annahme haben, dass dies notwendig ist, zu identifizieren, zu kontaktieren oder rechtliche Schritte gegen jeden zu beschädigen offen gelegt werden, zu verletzen oder stören (absichtlich oder unabsichtlich) unsere Rechte oder unser Eigentum, Benutzer oder alle anderen, die durch solche Aktivitäten geschädigt werden könnten.
<G-vec00345-001-s105><believe.annehmen><en> We reserve the right to void and withhold any or all winnings made by any person or group of persons and to void and withhold any Market Points or Casino Points (as that term is defined in our Casino Promotional Terms and Conditions) gained by any person or group of persons where We have reasonable grounds to believe that said person or group of persons is acting or has acted in liaison in an attempt to defraud or damage Us and/or the Group and/or the Services and/or the Platforms in any way.
<G-vec00345-001-s105><believe.annehmen><de> Wir behalten uns das Recht vor, einen oder sämtliche Gewinne, die durch eine Person oder eine Gruppe von Personen erzielt wurden, für ungültig zu erklären oder zurückzuhalten und sämtliche Standardspielerpunkte, die von einer Person oder einer Gruppe von Personen gewonnen wurden, für ungültig zu erklären oder zurückzuhalten, wenn wir berechtigte Gründe zu der Annahme haben, dass die besagte Person oder Gruppe von Personen an einem Versuch beteiligt ist oder war, uns und/oder die Gruppe und/oder die Services und/oder die Plattformen in irgendeiner Weise zu betrügen oder zu schädigen.
<G-vec00345-001-s106><believe.annehmen><en> The fact that POSCO can finally stop importing its core technologies from other advanced neighbouring steel producers is enough to lead the company to believe that its new technology will give it a competitive edge for decades to come.
<G-vec00345-001-s106><believe.annehmen><de> Die Tatsache, dass POSCO endlich darauf verzichten kann, Kerntechnologien fortschrittlicherer und benachbarter Stahlhersteller zu importieren, gibt dem Unternehmen ausreichend Grund zu der Annahme, dass die neue Technologie ihm für die nächsten Jahrzehnte einen Wettbewerbsvorteil verschaffen wird.
<G-vec00345-001-s107><believe.annehmen><en> You must never refer to Skype in a way that might mislead someone to believe that your use is sponsored, affiliated with, endorsed by Skype or otherwise economically linked to Skype or that might be interpreted to suggest that content displayed by you has been authorised by, or represents the views or opinions of, Skype unless you have received written acknowledgement of the same by Skype.
<G-vec00345-001-s107><believe.annehmen><de> Sie dürfen sich niemals auf eine Art und Weise auf Skype beziehen, die jemanden irrtümlich zu der Annahme bewegen könnte, dass Ihre Nutzung von Skype gesponsert, mit Skype verbunden oder von Skype gebilligt oder anderweitig wirtschaftlich an Skype geknüpft ist, oder so ausgelegt werden kann, dass der von Ihnen angezeigte Inhalt von Skype genehmigt wurde oder die Ansichten oder Meinungen von Skype wiedergibt, es sei denn, Skype hat Ihnen ein diesbezügliches schriftliches Zugeständnis erteilt.
<G-vec00345-001-s108><believe.annehmen><en> The large number of running events in Switzerland could lead one to believe that these are a lucrative activity for organisers.
<G-vec00345-001-s108><believe.annehmen><de> Die große Zahl von Volksläufen in der Schweiz könnte zur Annahme verleiten, dass diese Events für die Organisatoren eine lukrative Sache sind.
<G-vec00345-001-s109><believe.annehmen><en> If You have reason to believe that a third party has gained unauthorised access to Your credentials or to the App, You must immediately notify DeLaval.
<G-vec00345-001-s109><believe.annehmen><de> Wenn Sie Grund zur Annahme haben, dass ein Dritter unbefugt Zugriff auf Ihre Anmeldedaten oder die App erlangt hat, müssen Sie dies DeLaval unverzüglich mitteilen.
<G-vec00345-001-s110><believe.annehmen><en> m. If you have reason to believe that a person under the age of eighteen years is accessing our services, please contact us immediately.
<G-vec00345-001-s110><believe.annehmen><de> m. Wenn Grund zu der Annahme besteht, dass eine Person unter dem Alter von achtzehn Jahren auf unsere Dienste zugreifen kann, kontaktieren Sie uns bitte umgehend.
<G-vec00345-001-s111><believe.annehmen><en> There is some reason to believe that organisms high in the scale, change more quickly than those that are low: though there are exceptions to this rule.
<G-vec00345-001-s111><believe.annehmen><de> Es ist Grund zur Annahme vor- handen, dass solche Organismen, welche auf höherer Organisa- tionsstufe stehen, rascher als die unvollkommen entwickelten wechseln; doch gibt es Ausnahmen von dieser Regel.
<G-vec00345-001-s112><believe.annehmen><en> You should be aware that in addition to the circumstances described above, we may disclose your financial or personal information if required to do so by law, court order, as requested by other government or law enforcement authority, or in the good faith belief that disclosure is otherwise necessary or when We have reason to believe that disclosing the information is necessary to identify, contact or bring legal action against someone who may be causing interference with our rights or properties, whether intentionally or otherwise, or when anyone else could be harmed by such activities.
<G-vec00345-001-s112><believe.annehmen><de> Sie sollten wissen, dass wir zusätzlich zu den oben beschriebenen Umständen Ihre finanziellen oder persönlichen Daten offenlegen können, wenn dies gesetzlich vorgeschrieben oder gerichtlich angeordnet ist, wie es von anderen Behörden oder Strafverfolgungsbehörden verlangt wird, oder in gutem Glauben, dass die Offenlegung erfolgt ist andernfalls notwendig oder wenn wir Grund zu der Annahme haben, dass die Offenlegung der Informationen erforderlich ist, um Personen zu identifizieren, zu kontaktieren oder rechtliche Schritte gegen sie einzuleiten, die absichtlich oder anderweitig mit unseren Rechten oder Eigenschaften in Konflikt geraten könnten oder wenn jemand anderen Schaden zufügen könnte solche Aktivitäten.
<G-vec00345-001-s113><believe.annehmen><en> If there is reason to believe that such a requirement has not been met, the board shall include this ground in the proceedings.
<G-vec00345-001-s113><believe.annehmen><de> Besteht Anlaß zur Annahme, daß ein solches Patentierungserfordernis nicht erfüllt sein könnte, so bezieht die Beschwerdekammer diesen Grund in das Verfahren ein.
<G-vec00345-001-s133><believe.sind><en> Right to complain to a supervisory authority Without prejudice to any other administrative or judicial remedy, you shall have the right to complain to a supervisory authority, in particular in the Member State of your place of residence, employment or the place of alleged infringement, if you believe that the processing of the personal data concerning you violates the regulations of GDPR.
<G-vec00345-001-s133><believe.sind><de> Recht auf Beschwerde bei einer Aufsichtsbehörde Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat Ihres Aufenthaltsorts, Ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00345-001-s134><believe.sind><en> Complaint: You have the right, notwithstanding any other legal remedy under administrative law or in court, to complain to a supervisory authority if you believe that processing of the personal data concerning you violates the GDPR.
<G-vec00345-001-s134><believe.sind><de> Beschwerde: Sie haben das Recht, unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs, auf Beschwerde bei einer Aufsichtsbehörde, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00345-001-s135><believe.sind><en> We may take whatever action we deem appropriate, including (among other things) investigating allegations of improper activities, making reports to law enforcement authorities or terminating service to you, if we believe that there has been a violation of the terms and conditions of this statement or a breach of our agreement with you.
<G-vec00345-001-s135><believe.sind><de> Wir können jegliche Schritte einleiten, die wir für erforderlich halten, einschließlich (unter anderem) der Untersuchung angeblicher unangemessener Aktivitäten, der Anzeige bei den Strafverfolgungsbehörden oder der Beendigung der Dienstleistungen für Sie, wenn wir der Ansicht sind, dass ein Verstoß gegen die Bestimmungen und Bedingungen der vorliegenden Erklärung oder eine Verletzung unserer Vereinbarung mit Ihnen vorliegt.
<G-vec00345-001-s136><believe.sind><en> Without prejudice to any other administrative or judicial remedy, you shall have the right to complain to a supervisory authority, in particular in the Member State of your place of residence, employment or the place of alleged infringement, if you believe that the processing of the personal data concerning you violates the regulations of GDPR.
<G-vec00345-001-s136><believe.sind><de> Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat Ihres Aufenthaltsorts, Ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00345-001-s137><believe.sind><en> We may cancel any transaction if we believe that the transaction breaches these Terms or the Terms of Service, or if we believe that doing so may prevent financial loss.
<G-vec00345-001-s137><believe.sind><de> Wir können jedwede Transaktion widerrufen, wenn wir der Ansicht sind, dass sie gegen diese Bedingungen oder die Facebook-Nutzungsbedingungen verstößt oder dass wir dadurch einen finanziellen Verlust verhindern können.
<G-vec00345-001-s138><believe.sind><en> Although we believe that the beliefs, plans, expectations and intentions contained in this press release are reasonable, there can be no assurance that such beliefs, plans, expectations or intentions will prove to be accurate.
<G-vec00345-001-s138><believe.sind><de> Obwohl wir der Ansicht sind, dass die Annahmen, Pläne, Erwartungen und Absichten, die in dieser Pressemitteilung zum Ausdruck gebracht werden, vernünftig sind, gibt es keine Garantie, dass sich solche Annahmen, Pläne, Erwartungen oder Absichten als richtig herausstellen werden.
<G-vec00345-001-s139><believe.sind><en> Although we believe that the beliefs, plans, expectations and intentions contained in this press release are reasonable, there can be no assurance that such beliefs, plans, expectations or intentions will prove to be accurate. NEWSLETTER REGISTRIERUNG:
<G-vec00345-001-s139><believe.sind><de> Obwohl wir der Ansicht sind, dass die Annahmen, Pläne, Erwartungen und Absichten, die in dieser Pressemitteilung zum Ausdruck gebracht werden, vernünftig sind, gibt es keine Garantie, dass sich solche Annahmen, Pläne, Erwartungen oder Absichten als richtig herausstellen werden.
<G-vec00345-001-s140><believe.sind><en> Without prejudice to any other administrative or judicial remedy, you have the right to complain to a supervisory authority, in particular in the member State of its place of residence, employment or the place of the alleged infringement, if you believe that the processing of your personal data violates against GDPR.
<G-vec00345-001-s140><believe.sind><de> Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat ihres Aufenthaltsorts, ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DS-GVO verstößt.
<G-vec00345-001-s141><believe.sind><en> If you believe that the processing of your personal data violates applicable data protection regulations, you are entitled to file a complaint with a data protection regulatory authority.
<G-vec00345-001-s141><believe.sind><de> Sofern Sie der Ansicht sind, dass die Verarbeitung Ihrer personenbezogenen Daten gegen die geltenden Regelungen zum Datenschutz verstößt, haben das Recht, sich bei einer Aufsichtsbehörde für den Datenschutz über uns zu beschweren.
<G-vec00345-001-s142><believe.sind><en> Regardless of any other administrative or legal remedy, you have the right to file a complaint with a regulatory authority, particularly in the member state of your place of residence, your place of employment, or the place of the alleged violation, if you believe that the processing of the personal data concerning you violates the GDPR.
<G-vec00345-001-s142><believe.sind><de> Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat ihres Aufenthaltsorts, ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00345-001-s143><believe.sind><en> If you believe that anything on the Web Properties infringes your copyright, let us know .
<G-vec00345-001-s143><believe.sind><de> Wenn Sie der Ansicht sind, dass Inhalte von Web Properties Ihr Urheberrecht verletzen, teilen Sie uns dies bitte mit .
<G-vec00345-001-s144><believe.sind><en> If you believe that Mollie has used your personal data unlawfully or if you are not satisfied with Mollie's response to your request, you have the right to file a complaint with the Dutch Data Protection Authority or to take it to court.
<G-vec00345-001-s144><believe.sind><de> Wenn Sie der Ansicht sind, dass Mollie Ihre personenbezogenen Daten zu Unrecht verwendet hat, oder wenn Sie mit der Reaktion von Mollie auf Ihren Antrag nicht zufrieden sind, haben Sie das Recht, bei der niederländischen Datenschutzbehörde (Autoriteit Persoonsgegevens) eine Beschwerde einzureichen oder sich an ein Gericht zu wenden.
<G-vec00345-001-s145><believe.sind><en> If you believe that our processing of personal data relating to you infringes GDPR or generally the applicable data protection laws, please let us know.
<G-vec00345-001-s145><believe.sind><de> Wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO oder generell gegen geltendes Datenschutzrecht verstößt, zögern Sie bitte nicht, uns Ihre Bedenken mitzuteilen.
<G-vec00345-001-s146><believe.sind><en> Mr. Cupples has enquired from several great breeders of dogs, and finds that all without exception believe that females are produced in excess; but he suggests that this belief may have arisen from females being less valued, and from the consequent disappointment producing a stronger impression on the mind.
<G-vec00345-001-s146><believe.sind><de> Mr. CüPPLBS hat sich bei mehreren großen Hundezüchtern erkundigt und dabei erfahren, dass alle ohne Ausnahme der Ansicht sind, dass die Weib- chen in der Mehrzahl geboren werden; er vermuthet, diese Annahme könne wohl dadurch entstanden sein, dass die Weibchen weniger hoch geschätzt werden, uud die damit zusammenhängende Enttäuschung mache auf das Gemüth einen stärkeren Eindruck.
<G-vec00345-001-s147><believe.sind><en> And because we believe that the same data protection should apply to all our customers, we adopt the provisions of the DSGVO worldwide.
<G-vec00345-001-s147><believe.sind><de> Und weil wir der Ansicht sind, dass für alle unsere Kunden derselbe Datenschutz gelten sollte, übernehmen wir die Bestimmungen der DSGVO weltweit.
<G-vec00345-001-s148><believe.sind><en> EU Individuals also have the right to lodge a complaint with the relevant data protection authority if they believe that their personal data has been processed in violation of applicable data protection law.
<G-vec00345-001-s148><believe.sind><de> EU-Bürger haben zudem das Recht, bei der zuständigen Datenschutzbehörde eine Beschwerde einzureichen, wenn sie der Ansicht sind, dass ihre personenbezogenen Daten entgegen dem geltenden Datenschutzgesetz verarbeitet wurden.
<G-vec00345-001-s149><believe.sind><en> : 040/428 54 - 4040, Fax: 040/428 54 - 4000, E-mail: mailbox@datenschutz.hamburg.de) if you believe that the processing of your personal data violates the General Data Protection Regulation (GDPR).
<G-vec00345-001-s149><believe.sind><de> : 040 / 428 54 – 4040, Fax: 040 / 428 54 – 4000, E-Mail: mailbox@datenschutz.hamburg.de), wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die Datenschutzgrundverordnung verstößt.
<G-vec00345-001-s150><believe.sind><en> Without prejudice to any other administrative or judicial remedy, you have the right of appeal to a supervisory authority, in particular in the Member State where you reside, work or where the infringement is suspected, if you believe that the processing of personal data that concerns you is in contravention of GDPR.
<G-vec00345-001-s150><believe.sind><de> Unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs steht Ihnen das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat ihres Aufenthaltsorts, ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, zu, wenn Sie der Ansicht sind, dass die Verarbeitung der Sie betreffenden personenbezogenen Daten gegen die DSGVO verstößt.
<G-vec00345-001-s151><believe.sind><en> Regardless of any other administrative or judicial legal remedy, you have the right to complain at any time to a supervisory authority, especially in the Member State of your residence, your workplace or the location of the supposed breach, if you believe that the processing of your personal data breaches this Regulation.
<G-vec00345-001-s151><believe.sind><de> Sie haben jederzeit unbeschadet eines anderweitigen verwaltungsrechtlichen oder gerichtlichen Rechtsbehelfs das Recht auf Beschwerde bei einer Aufsichtsbehörde, insbesondere in dem Mitgliedstaat ihres Aufenthaltsorts, ihres Arbeitsplatzes oder des Orts des mutmaßlichen Verstoßes, wenn Sie der Ansicht sind, dass die Verarbeitung der sie betreffenden personenbezogenen Daten gegen diese Verordnung verstößt.
<G-vec00092-001-s171><believe.glauben><en> So no Catholic is obliged to believe that the Mother of God appeared in Lourdes and Fatima; but the Church states that the reports of the apparitions are worthy of belief and a Catholic may believe in them and cultivate a corresponding spirituality.
<G-vec00092-001-s171><believe.glauben><de> Kein Katholik ist also verpflichtet, daran zu glauben, dass die Muttergottes in Lourdes und Fatima erschienen ist; die Kirche erklärt aber, dass die Berichte über die Erscheinungen glaubwürdig sind und ein Katholik daran glauben und eine entsprechende Spiritualität pflegen darf.
<G-vec00092-001-s173><believe.glauben><en> Though the advertisement says it can be suitable for any weather conditions, you cannot be a naive child to totally believe in it.
<G-vec00092-001-s173><believe.glauben><de> Obwohl die Werbung, dass es für alle Wetterbedingungen geeignet sein kann sagt, können nicht Sie eine naive Kind völlig daran glauben sein.
<G-vec00092-001-s174><believe.glauben><en> We must believe that a life spreading the gospel of the water and the Spirit is the most beautiful life.
<G-vec00092-001-s174><believe.glauben><de> Wir müssen daran glauben, dass ein Leben, in dem wir das Evangelium von Wasser und Geist verbreiten, das wunderschönste Leben ist.
<G-vec00092-001-s175><believe.glauben><en> The clear truth is that those who know and believe in the love of God’s righteousness will be loved by Him, while those who reject and repudiate His love will be hated by God.
<G-vec00092-001-s175><believe.glauben><de> Die eindeutige Wahrheit ist, dass diejenigen, die die Liebe der Gerechtigkeit Gottes kennen und daran glauben, von Ihm geliebt werden, während diejenigen, die Seine Liebe von sich weisen und nicht anerkennen, von Gott gehasst werden.
<G-vec00092-001-s176><believe.glauben><en> This is why we firmly believe that retail success isn't about online vs. offline selling.
<G-vec00092-001-s176><believe.glauben><de> Dies ist der Grund, warum wir fest daran glauben, dass retail-Erfolg nicht über online-vs. offline-Verkauf.
<G-vec00092-001-s177><believe.glauben><en> However, practitioners believe that good will be rewarded and evil will be punished.
<G-vec00092-001-s177><believe.glauben><de> Die Praktizierenden würden jedoch daran glauben, dass Gutes mit Gutem vergolten und Böses bestraft werde.
<G-vec00092-001-s178><believe.glauben><en> There are for instance those that believe that the end date of the Mayan calendar only marks the end of a cycle and the beginning of a new.
<G-vec00092-001-s178><believe.glauben><de> Da gibt es beispielsweise jene, die daran glauben, dass das Enddatum des Mayakalenders nur das Ende eines Zyklus und den Beginn eines Neuen anzeigt.
<G-vec00092-001-s179><believe.glauben><en> We all should believe in mind that Jesus took away all our sins by His baptism and died on the Cross in order to be judged for our sins according to the righteous law of God.
<G-vec00092-001-s179><believe.glauben><de> Wir sollten alle von ganzem Herzen daran glauben, dass Jesus all unsere Sünden durch Seine Taufe von uns genommen hat und am Kreuz gestorben ist, um für unsere Sünden in Hinblick auf das rechtschaffende Gesetz von Gott bestraft zu werden.
<G-vec00092-001-s180><believe.glauben><en> This Islamic bhoots is going from bad to worse and people want to believe in it.
<G-vec00092-001-s180><believe.glauben><de> Diese Negativität des Islam wird immer schlimmer, und die Leute wollen daran glauben.
<G-vec00092-001-s181><believe.glauben><en> Or does it seem so merely because we believe it to be so?
<G-vec00092-001-s181><believe.glauben><de> Oder stimmt das nur deshalb, weil wir daran glauben?...
<G-vec00092-001-s182><believe.glauben><en> Employees who know what they are doing, and believe in why they are doing it, are happy while working, and will naturally create an increase in customer wallet share, positive feedback, referrals by customers, and customer loyalty.
<G-vec00092-001-s182><believe.glauben><de> Mitarbeiter, die wissen, was sie tun, und daran glauben, warum sie es tun, sind glücklich bei der Arbeit und werden eine Erhöhung des Umsatzes, positives Feedback, Empfehlungen von Kunden und Kundenloyalität schaffen.
<G-vec00092-001-s183><believe.glauben><en> That's what makes investors believe in the idea and the team.
<G-vec00092-001-s183><believe.glauben><de> Daran entscheidet sich, ob Investoren an die Idee und das Team glauben.
<G-vec00092-001-s184><believe.glauben><en> Thou dost well: the devils also believe and tremble. 20
<G-vec00092-001-s184><believe.glauben><de> Du tust recht daran; die Teufel glauben's auch und zittern.
<G-vec00092-001-s185><believe.glauben><en> I’m not saying that you can’t truly believe that one of these things is going to happen, and prepare yourself in whatever way you feel you need to be prepared so that you’re comfortable again.
<G-vec00092-001-s185><believe.glauben><de> Ich sage nicht, dass ihr nicht wahrhaft daran glauben könnt, dass eines dieser Dinge passieren wird, und ihr euch darauf vorbereitet, auf welche Art und Weise auch immer ihr euch vorbereiten wollt, damit ihr euch wieder wohl fühlt.
<G-vec00092-001-s186><believe.glauben><en> You need to believe that your business can create future value, and that may well involve a jump into the unknown.
<G-vec00092-001-s186><believe.glauben><de> Man muss daran glauben, dass ein Unternehmen einen Zukunftswert schaffen kann, auch wenn dies einen Sprung ins Ungewisse bedeutet.
<G-vec00092-001-s187><believe.glauben><en> 1 will turn away from My communications those who are unjustly proud in the earth; and if they see every sign they will not believe m It; and if they see the way of rectitude they do not take It for a way, and if they see the way of error. they take it for a way; this is because they rejected Our communications and were heedless of them.
<G-vec00092-001-s187><believe.glauben><de> Abwenden aber will Ich von Meinen Zeichen diejenigen, die sich hoffärtig im Lande gebärden wider alles Recht; und wenn sie auch alle Zeichen sehen, so wollen sie nicht daran glauben; und wenn sie den Weg der Rechtschaffenheit sehen, so wollen sie ihn nicht als Weg annehmen; sehen sie aber den Weg des Irrtums, so nehmen sie ihn als Weg an.
<G-vec00092-001-s188><believe.glauben><en> If you want to correctly understand Godís predestination, you need to throw away your own thinking and focus on the righteousness of God Because many people cannot think of and believe in the righteousness of God manifested through Jesus Christ, they tend to think of Godís love in whatever way that they may choose, and some even think that Godís love is not just.
<G-vec00092-001-s188><believe.glauben><de> Wenn Sie die Vorbestimmung Gottes richtig verstehen wollen, müssen Sie Ihre eigenen Gedanken ablegen und sich auf die Gerechtigkeit Gottes konzentrieren Weil viele Menschen nicht daran denken, dass die Gerechtigkeit Gottes sich durch Jesus Christus verfestigt hat, und nicht daran glauben, tendieren sie dazu, so an die Liebe Gottes zu denken, wie sie es wollen und einige denken sogar, dass die Liebe nicht gerecht sei.
<G-vec00092-001-s189><believe.glauben><en> Everything seems to indicate that this is a suicide, but Juno can't believe in that.
<G-vec00092-001-s189><believe.glauben><de> Alles deutet auf Selbstmord hin, doch Juno kann daran nicht glauben.
<G-vec00092-001-s209><believe.glauben><en> It’s a good job we believe in inner values.
<G-vec00092-001-s209><believe.glauben><de> Wie gut, dass wir an innere Werte glauben.
<G-vec00092-001-s210><believe.glauben><en> One visitor said people cannot believe and accept such a cruel persecution is still occurring.
<G-vec00092-001-s210><believe.glauben><de> Ein Besucher sagte, dass die Menschen nicht glauben könnten, dass solch eine grausame Verfolgung heutzutage noch abläuft.
<G-vec00092-001-s211><believe.glauben><en> I should also mention something which perhaps does not sound particularly special to a foreigner, but, believe me, here in Hungary is unprecedented, and I can't even remember the last time something like it happened: all parties in the Hungarian National Assembly united to support adoption of a resolution which condemns the persecution of Christians, supports the Government in providing help, condemns the activities of the organisation called Islamic State, and calls upon the International Criminal Court to launch proceedings in response to the persecution, oppression and murder of Christians.
<G-vec00092-001-s211><believe.glauben><de> Ich möchte noch erwähnen, dass das ungarische Parlament mit der Unterstützung aller Parteien – das mag sich für ausländische Ohren als nichts Besonderes anhören, aber glauben Sie mir, hier in Ungarn ist das beispiellos, ich erinnere mich gar nicht, wann so etwas zuletzt geschehen war – einen Beschluss angenommen hat, der die Verfolgung der Christen verurteilt und die Regierung dabei unterstützt, Hilfe zu leisten, der die Tätigkeit des Islamischen Staates verurteilt und den Internationalen Gerichtshof auffordert, ein Verfahren wegen der Verfolgung, der Unterdrückung und der Ermordung der Christen einzuleiten.
<G-vec00092-001-s212><believe.glauben><en> A dream come true for your lashes, this 3-in-1 mascara delivers next-generation drama for the look of lashes so amazing you'll have to experience it to believe it.
<G-vec00092-001-s212><believe.glauben><de> Ein Traum wird wahr für Ihre Wimpern: Dieser 3-in-1 Mascara liefert einen dramatischen Look, der so fantastisch ist, dass Sie es erleben müssen, um es zu glauben.
<G-vec00092-001-s213><believe.glauben><en> Men watching pornographic movies, where the actresses have multiple orgasms, believe that women also can have them in reality, but it is very unusual.
<G-vec00092-001-s213><believe.glauben><de> Männer gucken sich Pornofilme an, in denen die Schauspielerinnen multiple Orgasmen haben, so dass sie glauben, dass Frauen in Wirklichkeit auch multiple Orgasmen während des Geschlechsverkehrs haben können.
<G-vec00092-001-s214><believe.glauben><en> This last verse says God is angry with people who do not believe Jesus.
<G-vec00092-001-s214><believe.glauben><de> Dieser letzte Vers sagt, dass Gott ärgerlich ist mit Menschen die Jesus nicht glauben.
<G-vec00092-001-s215><believe.glauben><en> And they'll believe that anyone who isn't a Carinthian is a threat.
<G-vec00092-001-s215><believe.glauben><de> Und dass sie glauben, dass alle, die nicht Kärntner sind, seien eine Gefahr.
<G-vec00092-001-s216><believe.glauben><en> It is therefore not surprising that Russia later did not believe the US/NATO missile defense shield promoted by U.S. President George W. Bush was not intended to neutralize Russia's second strike capability.
<G-vec00092-001-s216><believe.glauben><de> Es erstaunt deshalb nicht, dass Russland später bei dem von U.S.-Präsident George W. Bush vorangetriebenen US/NATO-Raketenschutzschild der Zusicherung, dass dieses Projekt nicht zur Neutralisierung der russischen Zweitschlagfähigkeit gedacht sei, wenig Glauben schenkte.
<G-vec00092-001-s217><believe.glauben><en> "Their great sin is not to believe in a future that resembles the present"". This is what Mgr. Oswaldo Azuaje Pérez, O.C.D., Bishop of Trujillo said in his Twitter account."
<G-vec00092-001-s217><believe.glauben><de> "Ihre einzige Schuld ist, dass sie nicht an eine Zukunft glauben wollen, die der Gegenwart gleicht"", so Bischof Oswaldo Azuaje Pérez, O.C.D., von Trujillo bei der Plattform Twitter nach dem Tot eines weiteren jugendlichen Demonstranten in Venezuela."
<G-vec00092-001-s218><believe.glauben><en> Don't wait for others to believe in you.
<G-vec00092-001-s218><believe.glauben><de> Warte nicht auf Andere, dass sie an dich glauben.
<G-vec00092-001-s219><believe.glauben><en> From the one hundred and fifty movements on the list, fifty have confirmed they believe in its future.
<G-vec00092-001-s219><believe.glauben><de> Von den hundertfünfzig Bewegungen auf der Liste haben fünfzig bestätigt, dass sie an seine Zukunft glauben.
<G-vec00092-001-s220><believe.glauben><en> I have seen too many relationships breaking up among my friends to be able to believe in marriage.
<G-vec00092-001-s220><believe.glauben><de> Ich habe zu viele kaputte Beziehungen bei meinen Freunden gesehen, so dass ich nicht an die Ehe glauben kann.
<G-vec00092-001-s221><believe.glauben><en> Donna Elvira warns Zerlina not to believe anything Giovanni promises her.
<G-vec00092-001-s221><believe.glauben><de> Donna Elvira warnt sie, dass sie den Versprechungen Giovannis nicht glauben darf.
<G-vec00092-001-s222><believe.glauben><en> I also want you to believe and give thanks to Him with your heart.
<G-vec00092-001-s222><believe.glauben><de> Ich möchte auch, dass Sie glauben und Ihm von Herzen danken.
<G-vec00092-001-s223><believe.glauben><en> It makes you feel better, but just like your lucky charms, it doesn’t really do anything than helping you believe in your luck or yourself.
<G-vec00092-001-s223><believe.glauben><de> Es macht Sie sich besser fühlen, aber wie bringt Glück, dass es nicht etwas als zu helfen Sie in Ihrem Glück oder selbst glauben zu tun.
<G-vec00092-001-s224><believe.glauben><en> The failure of sexual intercourse due to insufficient erection can lead men to believe in their own inferiority, fear of future partners and the subconscious avoidance of sexual contact.
<G-vec00092-001-s224><believe.glauben><de> Das Versagen des Geschlechtsverkehrs aufgrund unzureichender Erektionen kann dazu führen, dass Männer an ihre eigene Minderwertigkeit, an die Angst vor zukünftigen Partnern und an die Unterbewusstsein des sexuellen Kontakts glauben.
<G-vec00092-001-s225><believe.glauben><en> This is because we believe in the same company purpose and share the absolute will to bring added value to our clients in each and every of our operations.
<G-vec00092-001-s225><believe.glauben><de> Das liegt daran, dass wir an den gleichen Unternehmenszweck glauben und den absoluten Willen teilen, unseren Kunden einen Mehrwert mit jedem unserer Services zu bieten.
<G-vec00092-001-s226><believe.glauben><en> Suspicion: There is one lie and another lie because Mr. Theodore Olson gives no further interviews (p.119). since 12 Sep. 2001 The Olson telephone call is the base for the conspiracy theory of the Bush regime against the alleged Muslim hijackers (p.120) General attorney Olson is mentioned in the media representatively (p.120) with a foto of his wife and with big folios in leather so any public will believe the story in TV (p.121).
<G-vec00092-001-s226><believe.glauben><de> Verdacht: Es wird gelogen und betrogen, denn Herr Theodore Olson gibt keine weiteren Interviews (S.119) ab 12.9.2001 Das Olson-Telefonat wird von der Bush-Administration zur Basis der Verschwörungstheorie gegen die angeblichen muslimischen Entführer (S.120) Generalbundesanwalt Olson wird in den Medien repräsentativ präsentiert (S.120) mit dem Bild seiner Frau und vor ledernen Gerichtsbänden, so dass alle Zuschauer dem Glauben schenken, was im Fernsehen gesagt wird (S.121).
<G-vec00092-001-s227><believe.glauben><en> It’s hard to believe, but originally, advent was a period of fasting.
<G-vec00092-001-s227><believe.glauben><de> Dass der Advent ursprünglich eine Fastenzeit war, ist heute kaum zu glauben.
<G-vec00345-001-s228><believe.überzeugen><en> We strongly believe, in accordance with the Universal Declaration of Human Rights, that all people have the right to raise their children according to their own religious beliefs and practices.
<G-vec00345-001-s228><believe.überzeugen><de> In Übereinstimmung mit der Allgemeinen Erklärung der Menschenrechte sind wir fest davon überzeugt, dass alle Menschen das Recht haben, ihre Kinder gemäß ihrem religiösen Glauben und ihrer religiösen Praxis zu erziehen.
<G-vec00345-001-s229><believe.überzeugen><en> So, we believe that adding preservatives in the smallest effective quantity makes sense.
<G-vec00345-001-s229><believe.überzeugen><de> Daher sind wir davon überzeugt, dass das Hinzufügen von Konservierungsmitteln in der kleinstmöglichen wirksamen Menge sinnvoll ist.
<G-vec00345-001-s230><believe.überzeugen><en> "On his new post for VOK DAMS North America, Stewart noted: ""We at VOK DAMS believe that, in today's experience economy, live campaigns are central to the success of integrated marketing strategies."
<G-vec00345-001-s230><believe.überzeugen><de> "Zu seiner neuen Position bei VOK DAMS North America merkt Stewart an: ""Wir von VOK DAMS sind davon überzeugt, dass Live Campaigns in der heutigen Erlebniswirtschaft von zentraler Bedeutung für den Erfolg integrierter Marketingstrategien sind."
<G-vec00345-001-s231><believe.überzeugen><en> I strongly believe that our long-standing, mutual co-operation will further strengthen with new projects in the coming years.”
<G-vec00345-001-s231><believe.überzeugen><de> Ich bin fest davon überzeugt, dass sich unsere langjährige Zusammenarbeit mit neuen Vorhaben in den kommenden Jahren noch weiter verbessern wird.
<G-vec00345-001-s232><believe.überzeugen><en> "As the main sponsor, we want the SpÃ1⁄4rnasenecke to have a particular focus on technology, as we firmly believe that the earlier you develop an enthusiasm for technology, the easier it is to find your way in our high-tech society,"" says Daniela Malata, W&H Vice President Human Resources."
<G-vec00345-001-s232><believe.überzeugen><de> "Als Hauptsponsor ist uns ein besonderer Technikfokus der Spürnasenecke wichtig, denn wir sind davon überzeugt: Je früher man sich für Technik begeistert, umso leichter kommt man in unserer hoch technisierten Gesellschaft zurecht,"" so Mag.a Daniela Malata, W&H Vice President Human Resources."
<G-vec00345-001-s233><believe.überzeugen><en> Things move forward at a faster clip. I believe that it helps to have individuals and teams involved in the decision-making process.
<G-vec00345-001-s233><believe.überzeugen><de> Ich bin davon überzeugt, dass es dabei sehr hilfreich ist, dass sowohl einzelne Mitarbeiter als auch Teams in den Entscheidungsprozess miteingebunden sind.
<G-vec00345-001-s234><believe.überzeugen><en> The author believe that if a reader can read to the end, majority of impromptu questions and doubts will be consecutively elucidated.
<G-vec00345-001-s234><believe.überzeugen><de> Der Autor ist davon überzeugt, dass wenn der Leser bis zum Ende durchhält, der größte Teil seiner entstandenen Zwischenfragen und Zweifel nacheinander eine befriedigende Antwort finden wird.
<G-vec00345-001-s235><believe.überzeugen><en> I firmly believe that a political solution to the crisis in Ukraine is possible.
<G-vec00345-001-s235><believe.überzeugen><de> Eine politische Lösung der Krise in der Ukraine ist möglich, davon bin ich überzeugt.
<G-vec00345-001-s236><believe.überzeugen><en> I believe that some of the current good practice in Iraq is directly and indirectly inspired by NYOI courses.
<G-vec00345-001-s236><believe.überzeugen><de> "Ich bin davon überzeugt, dass einige der laufenden ""Good practice""-Projekte im Irak durch das NYOI angeregt wurden."
<G-vec00345-001-s237><believe.überzeugen><en> All of them firmly believe that this is an optimum way to secure the future with an eye to free, innovative, and creative academic and research activities.
<G-vec00345-001-s237><believe.überzeugen><de> Sie sind davon überzeugt, dass auf diese Weise eine optimale Zukunftssicherung im Zeichen freier, innovativer und kreativer Wissenschaft gewährleistet werden kann.
<G-vec00345-001-s238><believe.überzeugen><en> Our vision is to bring the use of genetic information to mainstream healthcare, and we strongly believe that cost efficiency combined with uncompromised, high quality is the key to achieve this goal.
<G-vec00345-001-s238><believe.überzeugen><de> Unsere Vision ist es, die Nutzung genetischer Informationen in der allgemeinen Gesundheitsversorgung zu etablieren, und wir sind fest davon überzeugt, dass Kosteneffizienz gepaart mit hervorragender Qualität der Schlüssel zur Erreichung dieses Ziels ist.
<G-vec00345-001-s239><believe.überzeugen><en> In addition shortage of some key raw materials is of some concern, but we believe that we are well covered with our back-integration and our strong suppliers’ base.” Mr. Park continued: “On the positive side we continue to see a strong demand which we anticipate will continue in 2011, in spite of a still unstable global economic situation which is also driving a significant volatility on the currency side.
<G-vec00345-001-s239><believe.überzeugen><de> Einen gewissen Anlass zur Sorge gibt darüber hinaus eine Verknappung bestimmter Rohstoffe, aber wir sind davon überzeugt, dass wir dank unserer Rückwärtsintegration und unseres starken Lieferantenstamms bestens aufgestellt sind.“ Hinsichtlich der Zukunftsaussichten zeigt sich Jongho Park zuversichtlich: „Auf der positiven Seite sehen wir nach wie vor eine starke Nachfrage, die sich trotz einer immer noch unsicheren Lage der Weltwirtschaft und der ausgesprochen volatilen Währungssituation 2011 fortsetzen dürfte.
<G-vec00345-001-s240><believe.überzeugen><en> I truly believe that your study and discussion will bring about tremendous progress in accomplishing the ideal of God on earth.
<G-vec00345-001-s240><believe.überzeugen><de> Ich bin zutiefst davon überzeugt, dass Sie in Ihrem Studium und in Ihren Diskussionen in der Errichtung des Ideales Gottes auf Erden einen großen Schritt nach vorne machen werden.
<G-vec00345-001-s241><believe.überzeugen><en> We also firmly believe that there is substantial upside for additional high-grade, zinc-oxide mineralization along the six -kilometre long trend of the known mineralization from Mina Grande in the southeast to Charlotte Bongará to the northwest.
<G-vec00345-001-s241><believe.überzeugen><de> Wir sind auch fest davon überzeugt, dass beträchtliches Potenzial für eine zusätzliche hochgradige Zink-Oxid-Mineralisierung entlang des sechs Kilometer langen Abschnitts der bekannten Mineralisierung von Mina Grande im Südosten bis zu Charlotte Bongará im Nordwesten besteht.
<G-vec00345-001-s242><believe.überzeugen><en> """I believe that the production of a cannabinoid generic equivalent would allow a greater portion of the public in need of medical care to have access to more comprehensive care and that is why I believe in the clinic model."" States Dhaliwal."
<G-vec00345-001-s242><believe.überzeugen><de> "Ich bin davon überzeugt, dass es durch die Produktion eines generischen Cannabinoid -Äquivalents möglich wäre, einem größeren Teil der Bevölkerung, die medizinische Versorgung benötigt, Zugang zu einer umfassenderen Behandlung zu verschaffen, und das ist der Grund, weshalb ich an das Klinikmodell glaube "", sagte Dhaliwal."
<G-vec00345-001-s243><believe.überzeugen><en> We highly value the insights and expertise of other companies and academic laboratories and believe that they are necessary to complement our internal skills and knowledge.
<G-vec00345-001-s243><believe.überzeugen><de> Wir schätzen die Erkenntnisse anderer Unternehmen und deren wissenschaftliche Expertise sehr und sind davon überzeugt, dass wir sie benötigen, um unsere firmeninternen Fähigkeiten und Kenntnisse zu vervollständigen und zu ergänzen.
<G-vec00345-001-s244><believe.überzeugen><en> """I strongly believe that execution of our new strategy will allow Grupa Azoty to become the top producer in a chemical sector not only in Europe, but worldwide,"" said Pawel Jarczewski ."
<G-vec00345-001-s244><believe.überzeugen><de> """Ich bin felsenfest davon überzeugt, dass Grupa Azoty durch die Umsetzung unserer neuen Strategie zum größten Hersteller eines chemischen Sektors werden wird − nicht nur in Europa, sondern weltweit"", betonte Pawel Jarczewski ."
<G-vec00345-001-s245><believe.überzeugen><en> I truly believe: It's the duty of each and everyone of us to lead Switzerland in the era of Digitization, to affirm our position on the world map.
<G-vec00345-001-s245><believe.überzeugen><de> Ich bin fest davon überzeugt: Es ist die Pflicht eines jeden von uns, die Schweiz im Zeitalter der Digitalisierung anzuführen und als führendes digitales Land in der Welt zu positionieren.
<G-vec00345-001-s246><believe.überzeugen><en> Different people will see a large range of results, yet I strongly believe that there is not one person strolling this world that will certainly not lose weight using this item.
<G-vec00345-001-s246><believe.überzeugen><de> Verschiedene Leute werden sicherlich sehen eine große Auswahl an Ergebnissen, doch ich sehr davon überzeugt, dass es nicht eine einzelne schlendern dieser Welt, die nicht abnehmen, wird die Verwendung dieses Produkt.
<G-vec00345-001-s247><believe.denken><en> I don't know about the collapse of civilization but I do believe that for the last 40 years we in the west, western Europe, the United States and others, have leveraged the Internet for vast advances in national security, economic prosperity, social advances. And all of that is now at risk as the cyber threat grows.
<G-vec00345-001-s247><believe.denken><de> Ich weiß nicht, ob man direkt von einem Kollaps der Zivilisation sprechen kann, aber ich denke, dass wir in den letzten 40 Jahren hier im Westen, in Westeuropa, den Vereinigten Staaten und anderen Ländern, mithilfe des Internets große Fortschritte in Sachen nationale Sicherheit, wirtschaftlichem Wohlstand und sozialem Fortschritt erzielen konnten.
<G-vec00345-001-s248><believe.denken><en> I believe that the opposition, in its unrestrained agitation for democracy, which it so often makes into an absolute and a fetish, is unleashing petty-bourgeois elemental forces.
<G-vec00345-001-s248><believe.denken><de> Ich denke, dass die Opposition mit ihrer zügellosen Agitation für die Demokratie, die sie oft zu etwas Absolutem macht und zum Fetisch erhebt, die kleinbürgerliche Elementargewalt entfesselt.
<G-vec00345-001-s249><believe.denken><en> I believe, though, that here in Germany we’ll be up to world standard again within the next two years.
<G-vec00345-001-s249><believe.denken><de> Ich denke aber, dass wir in Deutschland innerhalb der nächsten zwei Jahre wieder auf Weltstandard sind.
<G-vec00345-001-s250><believe.denken><en> Sometimes I believe that enterprises should have an upper limit to the number of employees.
<G-vec00345-001-s250><believe.denken><de> Ab und zu denke ich mir, dass Unternehmen eine gewisse Obergrenze an Menschen haben sollten.
<G-vec00345-001-s251><believe.denken><en> I believe that the making of a biennale, or any exhibition of this magnitude, requires processes of critical thinking that need to be revisited constantly.
<G-vec00345-001-s251><believe.denken><de> Ich denke, eine Biennale oder Ausstellung von dieser Dimension zu realisieren, erfordert ein kritisches Denken, das ständig überprüft werden muss.
<G-vec00345-001-s252><believe.denken><en> Sure there are plenty more cities along the coast but these where the ones I visited and I believe are worth to have a look at.
<G-vec00345-001-s252><believe.denken><de> Sicher gibt es noch viel mehr Städte entlang der Küste aber das waren diejenigen die ich gesehen habe und denke man sollte sie nicht verpassen.
<G-vec00345-001-s253><believe.denken><en> But I believe that governments can only make decisions based on the resources they believe are available to them.
<G-vec00345-001-s253><believe.denken><de> Aber ich denke, dass Regierungen nur Entscheidungen treffen können, basierend auf den Ressourcen, die ihr zur Verfügung stehen.
<G-vec00345-001-s254><believe.denken><en> I believe that an affirmative answer must be given to this question.
<G-vec00345-001-s254><believe.denken><de> Ich denke, man muss diese Frage mit ja beantworten.
<G-vec00345-001-s255><believe.denken><en> Ken Hensley: I believe so, yes.
<G-vec00345-001-s255><believe.denken><de> Ken Hensley: I denke, ja.
<G-vec00345-001-s256><believe.denken><en> I believe that this criticism is inadequate; for the introduction itself is faulty and cannot stand up to criticism.
<G-vec00345-001-s256><believe.denken><de> Ich denke, diese Kritik reicht nicht aus, da auch die Einführung selbst unrichtig ist und keinerlei Kritik standhält.
<G-vec00345-001-s257><believe.denken><en> I believe all this variety is unique and always creates enthusiasm for our work.
<G-vec00345-001-s257><believe.denken><de> Ich denke diese Abwechslung ist einzigartig und erzeugt stets Begeisterung für unsere Arbeit.
<G-vec00345-001-s258><believe.denken><en> I believe that we are an excellent example of the development of a solid, regionally active, mid-size organ-building company in the maelstrom of time, who must first find its new face...
<G-vec00345-001-s258><believe.denken><de> Ich denke, wir sind ein gutes Beispiel für den Werdegang einer soliden, regional agierenden Orgelbaufirma mittlerer Größe im Strudel der Zeit, die erst ihr neues Gesicht finden musste.
<G-vec00345-001-s259><believe.denken><en> I believe so.
<G-vec00345-001-s259><believe.denken><de> Ich denke schon.
<G-vec00345-001-s260><believe.denken><en> That I still believe I can achieve all this due to the great job I'm doing.
<G-vec00345-001-s260><believe.denken><de> Dass ich trotzdem denke, ich erreiche das alles aufgrund meiner tollen Leistungen.
<G-vec00345-001-s261><believe.denken><en> [7] I do not believe that it is by chance that the ear is the organ of hearing but also of balance; and that the mouth is the organ of both taste and speech.
<G-vec00345-001-s261><believe.denken><de> [7] Ich denke, dass es kein Zufall ist, dass das Ohr das Hör-, sondern auch das Gleichgewichtsorgan ist; und der Mund das Organ zum Schmecken und Sprechen.
<G-vec00345-001-s262><believe.denken><en> Believe for losing weight for longer period and just except a month or so.
<G-vec00345-001-s262><believe.denken><de> Denke zum Abnehmen für längere Laufzeit und nicht nur für einen Monat oder so.
<G-vec00345-001-s263><believe.denken><en> That is what I believe this young man was doing.
<G-vec00345-001-s263><believe.denken><de> Und das war, denke ich, was der junge Mann hier tat.
<G-vec00345-001-s264><believe.denken><en> I believe that my great passion for Grappa history was born right there.
<G-vec00345-001-s264><believe.denken><de> Ich denke, meine große Leidenschaft für die Geschichte des Grappas, fing gerade dort an.
<G-vec00345-001-s265><believe.denken><en> I also believe that we (you and I) enjoyed a very good working relationship which contributed to these good results.
<G-vec00345-001-s265><believe.denken><de> Ich denke auch, daß wir Beide (Sie und ich) ein gutes Zusammenspiel, was Aufarbeitung und Zuarbeit betraf, hatten und somit zum positiven Ergebnis beigetragen hat.
<G-vec00345-001-s266><believe.denken><en> """Zvezda"" employees believe that 3D technology plays, without a doubt, an important role in the development of the space industry."
<G-vec00345-001-s266><believe.denken><de> "Die ""Zvezda"" Mitarbeiter denken, dass die 3D Technologie ohne Zweifel eine wichtige Rolle in der Entwicklung der Weltraumindustrie spielt."
<G-vec00345-001-s267><believe.denken><en> "We believe that Hamburg and its maritime players, as the ""gateway to the world"", can play a key role in the digitalisation of shipping ."
<G-vec00345-001-s267><believe.denken><de> "Wir denken, als ""Tor zur Welt"" kann Hamburg mit seinen maritimen Akteuren maßgeblich die Digitalisierung der Schifffahrt mitgestalten."
<G-vec00345-001-s268><believe.denken><en> Economic advice We believe that part of our the job of a real estate agency that provide services to the international client is to secure the financial feasibility of any purchase operation.
<G-vec00345-001-s268><believe.denken><de> Finanzielle Beratung Wir denken, dass ein Teil unserer Aufgabe als Immobilienagentur für internationale Kunden ist, dass wir die finanzielle Umsetzbarkeit des Projektes sichern.
<G-vec00345-001-s269><believe.denken><en> By supplementing with fish oils on a daily basis, you will certainly have the ability to believe more clear and also you can improve your memory.
<G-vec00345-001-s269><believe.denken><de> Durch die Ergänzung jeden Tag mit Fischölen, werden Sie sicherlich die Fähigkeit, klarer zu denken und auch können Sie Ihr Gedächtnis verbessern.
<G-vec00345-001-s270><believe.denken><en> If you believe that any information we are holding on you is incorrect or incomplete, please write to or email us as soon as possible, at enquiries@pertonmanor.co.uk .
<G-vec00345-001-s270><believe.denken><de> Wenn Sie denken dass die Informationen welche wir von ihnen besitzen falsch oder unvollständig sind, Schreiben Sie uns bitte so bald wie möglich eine E-Mail an die oben stehende Adresse..
<G-vec00345-001-s271><believe.denken><en> This way people would believe what I tell them is credible and the effect of encouraging the three withdrawals is better.
<G-vec00345-001-s271><believe.denken><de> Auf diese Weise denken die Menschen, was ich sage ist glaubhaft und der Effekt der Ermutigung für die drei Austritte ist besser.
<G-vec00345-001-s272><believe.denken><en> (8) These proposals emphasise civil disobedience since we believe that the best way to confront an unjust, oppresive and violent power system is to define ourselves in the same terms in which it defines us (in this case, as criminals) and to challenge it to accept the consequences of the public debate that we hope this debate will generate.
<G-vec00345-001-s272><believe.denken><de> (8) Wir schlagen zivilen Ungehorsam vor, weil wir denken, dass die beste Moeglichkeit ein ungerechtes, unterdrueckendes, gewalttaetiges Machtsystem anzugreifen die ist, sich in den selben Termini, die es uns zuschreibt zu definieren (in diesem fall als Kriminelle) und es dazu herauszufordern die Konsequenzen, die wie wir hoffen eine oeffentliche Debatte dazu ausloest zu akzeptieren.
<G-vec00345-001-s273><believe.denken><en> We believe that now we should conclude this stage, each take a position and define the Other Campaign.
<G-vec00345-001-s273><believe.denken><de> Wir denken, dass wir nun diese Etappe abschließen müssen, jede/r eine Position bezieht und wir eine Definition als Otra annehmen.
<G-vec00345-001-s274><believe.denken><en> You should not entertain the thought that you are perfect and have no need of mercy, you should humbly entrust yourselves to God’s love and always believe that your last hour has come.... you should listen to the admonitions of those who, as representatives of God, bring you His Word; you should know that the hour is not far away and always be ready.
<G-vec00345-001-s274><believe.denken><de> Ihr sollt euch nicht dem Glauben hingeben, vollkommen zu sein und kein Erbarmen nötig zu haben, ihr sollt euch demütig der Liebe Gottes anvertrauen und immer denken, euer letztes Stündlein sei gekommen.... ihr sollt den Mahnungen derer Gehör schenken, die als Vertreter Gottes euch Sein Wort bringen; ihr sollt wissen, daß die Stunde nicht mehr fern ist, und euch bereit halten.
<G-vec00345-001-s275><believe.denken><en> Of course, it is foolishness to believe that we can make God disappear.
<G-vec00345-001-s275><believe.denken><de> Natürlich ist es Unsinn zu denken wir Menschen könnten Gott verschwinden lassen.
<G-vec00345-001-s276><believe.denken><en> We do believe that it is important to have nice cooking pans which you should use with pleasure, which brings a plus of color and inspiration to your kitchen.
<G-vec00345-001-s276><believe.denken><de> Wir denken, es sei wichtig, dass du wunderschöne Töpfe hast, mit denen du sehr gerne arbeitest und welche ein Stück Farbe und Inspiration deiner Küche verleihen.
<G-vec00345-001-s277><believe.denken><en> With Penomet you do not should believe regarding surgeries which are pricey and uncomfortable, and tablets that you have the tendency to neglect.
<G-vec00345-001-s277><believe.denken><de> Mit Penomet tun sollten Sie nicht von chirurgischen Behandlungen denken, die teuer sind und auch unbequem, und Tabletten, die Sie die Tendenz zu vergessen haben.
<G-vec00345-001-s278><believe.denken><en> We believe that this difference is more strategic than ideological.
<G-vec00345-001-s278><believe.denken><de> Aber wir denken, dass all dies eher strategische als ideologische Konsequenzen hat.
<G-vec00345-001-s279><believe.denken><en> With Penomet you do not have to believe concerning surgical procedures which are expensive as well as agonizing, as well as medication that you have the tendency to forget.
<G-vec00345-001-s279><believe.denken><de> Mit Penomet müssen Sie nicht von chirurgischen Verfahren denken, die teuer sind und auch unangenehm, sowie Medizin, die Sie haben eine Tendenz, sich zu erinnern scheitern.
<G-vec00345-001-s280><believe.denken><en> They believe that Marxism is a description of reality, instead of a factor in changing reality.
<G-vec00345-001-s280><believe.denken><de> Sie denken, daß der Marxismus nur eine Beschreibung der Realität ist.
<G-vec00345-001-s281><believe.denken><en> He who does not penetrate in the humility of those words, will believe that Jesus was an ordinary man, but the truth is that He wanted to give you a lesson of humility.
<G-vec00345-001-s281><believe.denken><de> Wer nicht in die Demut dieser Worte eindringt, wird denken, dass Jesus ein Mensch wie jeder andere war; doch die Wahrheit ist, dass Er euch eine Lehre der Demut geben wollte.
<G-vec00345-001-s282><believe.denken><en> A statistic, shared by MarketingLand, shows that 86% of B2B marketers make use of content marketing, but only 38% believe that they’ve got the required skills to be good at it.
<G-vec00345-001-s282><believe.denken><de> MarketingLand teilte eine Statistik, die zeigte, dass 86 % der B2B-Marketer Content Marketing nutzen, aber nur 38 % denken, dass sie die nötigen Qualifikationen haben, um es auch gut zu machen.
<G-vec00345-001-s283><believe.denken><en> In contradiction to what many people believe, thoughts don't connect.
<G-vec00345-001-s283><believe.denken><de> Im Gegensatz zu dem was viele denken, machen Gedanken nicht wirklich Kontakt.
<G-vec00345-001-s284><believe.denken><en> It likewise methods your mind to believe that your tummy is currently complete.
<G-vec00345-001-s284><believe.denken><de> Es auch Verfahren deinen Geist zu denken, dass Ihr Magen ist derzeit voll.
<G-vec00092-001-s285><believe.glauben><en> At that time they had to stay in the desert for forty years until all people who did not believe in the Promised Land had died.
<G-vec00092-001-s285><believe.glauben><de> Damals mussten sie vierzig Jahre in der Wüste bleiben, bis alle, welche nicht an das verheißene Land geglaubt hatten, gestorben waren.
<G-vec00092-001-s286><believe.glauben><en> Indeed, Mary was the first, in a way which can never be equalled, to believe and experience that Jesus, the Incarnate Word, is the summit, the peak of man's encounter with God.
<G-vec00092-001-s286><believe.glauben><de> Als erste, und auf unübertreffliche Weise, hat Maria geglaubt und erfahren, daß Jesus, das fleischgewordene Wort, der Höhepunkt, der Gipfel der Begegnung des Menschen mit Gott ist.
<G-vec00092-001-s287><believe.glauben><en> There is no putting the Jews who knew Jesus and did not believe in him, or those who opposed the preaching of the apostles, on the same plane with Jews who came after or those of today.
<G-vec00092-001-s287><believe.glauben><de> F. Man kann die Juden, die Jesus gekannt und nicht an ihn geglaubt oder der Predigt der Apostel Widerstand geleistet haben, nicht mit den späteren und den heutigen Juden gleichsetzen.
<G-vec00092-001-s288><believe.glauben><en> I really didn't believe that an IT program is capable of translating complete sentences and entire documents.
<G-vec00092-001-s288><believe.glauben><de> Ich hätte wirklich nicht geglaubt, dass ein IT-Programm in der Lage ist, vollständige Sätze und ganze Dokumente zu übersetzen.
<G-vec00092-001-s289><believe.glauben><en> "In his defence, M. Trichet maintains that the central bank was ""fiercely and totally independent"", a statement that not many people believe these days."
<G-vec00092-001-s289><believe.glauben><de> "Trichet entgegnete, die Zentralbank sei ""aufs Schärfste und vollkommen unabhängig"", eine Aussage, die momentan nicht von vielen Leuten geglaubt wird."
<G-vec00092-001-s290><believe.glauben><en> [8.74] Those who believe and migrated from their homes and fought for the Way of Allah, and those who have sheltered them and helped them they are truly the believers.
<G-vec00092-001-s290><believe.glauben><de> [8.74] Die nun geglaubt haben und ausgewandert sind und gestritten haben f├╝r Allahs Sache, und jene, die (ihnen) Herberge und Hilfe gaben - diese sind in der Tat wahre Gl├Ąubige.
<G-vec00092-001-s291><believe.glauben><en> Jn 6:69 - And we believe and are sure that thou art that Christ, the Son of the living God.
<G-vec00092-001-s291><believe.glauben><de> Jn 6:69 - und wir haben geglaubt und erkannt, daß du der Heilige Gottes bist.
<G-vec00092-001-s292><believe.glauben><en> I did not believe it was a heart attack, and had no idea that it was until I was informed of it after an examination in the hospital complete with EKG.
<G-vec00092-001-s292><believe.glauben><de> Ich hatte nicht geglaubt es sein ein Herzanfall, und hatte keine Idee, daß es sei, bis ich nach einer Untersuchung im Krankenhaus, komplett mit EKG, davon informiert wurde.
<G-vec00092-001-s293><believe.glauben><en> But we didn't believe them – after all, they weren't ready to resolve the problem when everything was calm before the protests started!
<G-vec00092-001-s293><believe.glauben><de> Wir haben ihnen aber nicht geglaubt, schließlich waren sie ja nicht zu einer Lösung des Problems bereit gewesen, als alles ruhig war, bevor die Proteste anfingen.
<G-vec00092-001-s294><believe.glauben><en> We have come to believe and know that you are the Christ, the Son of the living God.'
<G-vec00092-001-s294><believe.glauben><de> und wir haben geglaubt und erkannt, daß du bist Christus, der Sohn des lebendigen Gottes.
<G-vec00092-001-s295><believe.glauben><en> 4:12 The kings of the earth didn't believe, neither all the inhabitants of the world, That the adversary and the enemy would enter into the gates of Jerusalem.
<G-vec00092-001-s295><believe.glauben><de> 4:12 Die Könige der Erde hätten es nicht geglaubt, noch alle Bewohner des Erdkreises, daß Bedränger und Feind in die Tore Jerusalems kommen würden.
<G-vec00092-001-s296><believe.glauben><en> Beloved, when I saw lucifer, I did not believe that that was the devil.
<G-vec00092-001-s296><believe.glauben><de> Geliebte, als ich Luzifer sah, hatte ich nicht geglaubt, dass er der Teufel war.
<G-vec00092-001-s297><believe.glauben><en> 1Kor 15:2 - By the Gospel, too, you are being saved, if you hold to the understanding that I preached to you, lest you believe in vain.
<G-vec00092-001-s297><believe.glauben><de> 1Kor 15:2 - durch welches ihr auch errettet werdet (wenn ihr an dem Worte festhaltet, das ich euch verkündigt habe), es sei denn, daß ihr vergeblich geglaubt habt.
<G-vec00092-001-s298><believe.glauben><en> [But this is a big lie, because the people of Basel public prosecution service simply did not believe anything].
<G-vec00092-001-s298><believe.glauben><de> [Das ist eigentlich eher gelogen, denn die Leute von der Stawa Basel haben einfach lange nichts geglaubt].
<G-vec00092-001-s299><believe.glauben><en> "If I did not firmly believe in ""Truthfulness, Compassion, Tolerance"", I might have been tortured to death or suffered a mental collapse long ago."
<G-vec00092-001-s299><believe.glauben><de> "Wenn ich nicht fest an ""Wahrhaftigkeit, Barmherzigkeit und Nachsicht"" geglaubt hätte, hätte ich zu Tode gefoltert werden oder einen Nervenzusammenbruch davontragen können."
<G-vec00092-001-s300><believe.glauben><en> I had to explain this procedure in several phone calls, because the people in admin didn't believe me.
<G-vec00092-001-s300><believe.glauben><de> Diese Vorgehensweise musste ich in mehreren Telefonaten erklären, da mir die Bearbeiter nicht geglaubt haben.
<G-vec00092-001-s301><believe.glauben><en> Beatrice and Sidney Webb on their part assure us that Marx and Engels did not believe in the possibility of building an isolated socialist society only because neither of them “had ever dreamt” of such a powerful weapon as the monopoly of foreign trade.
<G-vec00092-001-s301><believe.glauben><de> Beatrice und Sidney Webb wollen uns ihrerseits weismachen, Marx und Engels hätten nur deshalb nicht an die Möglichkeit des Aufbaus einer isolierten sozialistischen Gesellschaft geglaubt, weil sie sich eine so mächtige Waffe wie das Außenhandelsmonopol nicht hatten träumen lassen („neither Marx nor Engels had ever dreamt“).
<G-vec00092-001-s302><believe.glauben><en> "You have the words of eternal life. 69 We have come to believe and to know that you are the Holy One of God."""
<G-vec00092-001-s302><believe.glauben><de> Du hast Worte des ewigen Lebens; 69 und wir haben geglaubt und erkannt, daß du bist Christus, der Sohn des lebendigen Gottes.
<G-vec00092-001-s303><believe.glauben><en> "20 ""And behold, you shall be silent and unable to speak until the day when these things take place, because you did not believe my words, which will be fulfilled in their proper time."""
<G-vec00092-001-s303><believe.glauben><de> 20Und siehe, du wirst stumm sein und nicht reden können bis zu dem Tage, da solches geschehen wird; darum, weil du meinen Worten nicht geglaubt hast, welche zu ihrer Zeit erfüllt werden sollen.
<G-vec00345-001-s304><believe.gehen><en> However, online shoppers perceive themselves differently: 72 per cent of surfers believe that they compare numerous offers on the Internet, and autonomously make the best choice.
<G-vec00345-001-s304><believe.gehen><de> Die Selbstwahrnehmung von Online-Shoppern ist jedoch eine andere: 72 Prozent der Surfer gehen davon aus, dass sie im Internet viele Angebote vergleichen und sich autonom für die beste Wahl entscheiden.
<G-vec00345-001-s305><believe.gehen><en> According to the results of the M&G YouGov Inflation Expectations Survey over the past two years, European consumers often believe that inflation in one and five years’ time will run well above the official inflation rate.
<G-vec00345-001-s305><believe.gehen><de> Den Ergebnissen der Umfrage zu den Inflationserwartungen zufolge, die M&G gemeinsam mit YouGov in den letzten zwei Jahren durchgeführt hat, gehen viele europäische Konsumenten davon aus, dass die Inflation auf 1- und 5-Jahressicht deutlich über der offiziellen Zielvorgabe liegen wird.
<G-vec00345-001-s306><believe.gehen><en> We believe that this draft should be discussed and resolved upon in the Peopleâ s Parliament (Volkskammer) after being publicly announced.
<G-vec00345-001-s306><believe.gehen><de> Wir gehen davon aus, dass dieser Entwurf nach öffentlicher Aussprache in der Volkskammer behandelt und beschlossen werden sollte.
<G-vec00345-001-s307><believe.gehen><en> We believe that you would like to travel independently, thus we only make proposals for the planning and preparation of your journey when you wish us to do so.
<G-vec00345-001-s307><believe.gehen><de> Wir gehen davon aus, dass Sie selbstständig Reisen wollen und bieten Ihnen uns von daher sowohl in der Planung und Vorbereitung als auch Durchführung Ihrer Reise nur da als Partner an, wo Sie es wünschen.
<G-vec00345-001-s308><believe.gehen><en> The researchers believe that the strong magnetic fields in the photosphere provide the necessary energy for the explosions.
<G-vec00345-001-s308><believe.gehen><de> Die Forscher gehen davon aus, dass die starken Magnetfelder in der Fotosphäre die notwendige Energie für die Hitzeausbrüche bereitstellen.
<G-vec00345-001-s309><believe.gehen><en> Experts believe that the economic growth of the past years was made possible by the free movement of people.
<G-vec00345-001-s309><believe.gehen><de> Experten gehen davon aus, dass das Wirt schafts wachs tum in den letzten Jahren nicht zuletzt dank des freien Per sonen ver kehrs mög lich wur de.
<G-vec00345-001-s310><believe.gehen><en> Physicists now believe, however, that the high-temperature superconductivity develops as a result of magnetic interactions.
<G-vec00345-001-s310><believe.gehen><de> Physiker gehen jedoch inzwischen davon aus, dass die Hochtemperatursupraleitung sich aufgrund von magnetischen Wechselwirkungen ausbildet.
<G-vec00345-001-s311><believe.gehen><en> We believe that demand for clean and sustainable energy in Japan will continue to increase and that solar energy will play a key role in the growing diversification of the country's energy mix.
<G-vec00345-001-s311><believe.gehen><de> Wir gehen davon aus, dass der Bedarf an sauberer, nachhaltiger Energie in Japan weiter zunimmt und dass Solarenergie eine Schlüsselrolle in der zunehmenden Diversifizierung des japanischen Energiemarktes spielen wird.
<G-vec00345-001-s312><believe.gehen><en> """We believe that these findings will have a major impact on future studies on the structure of our Galaxy,"" emphasises Prof. Klessen."
<G-vec00345-001-s312><believe.gehen><de> """Wir gehen davon aus, dass diese Erkenntnisse einen wesentlichen Einfluss auf künftige Untersuchungen zum Aufbau unserer Galaxie haben werden"", betont Prof. Klessen."
<G-vec00345-001-s313><believe.gehen><en> Obviously, these theologians also believe, as Thomas did, that there can be only one correct interpretation of nature and the Scriptures—the Catholic interpretation.
<G-vec00345-001-s313><believe.gehen><de> Thomas selbst, gehen diese Theologen davon aus, dass es nur eine einzige richtige Interpretation der Natur und der Heiligen Schrift geben kann - die Interpretation der Katholischen Kirche.
<G-vec00345-001-s314><believe.gehen><en> We believe that such information is accurate and reliable as of the date of this safety data sheet; but no representation, guarantee or warranty, expressed or implied, is made.
<G-vec00345-001-s314><believe.gehen><de> Wir gehen davon aus, dass diese Informationen bezogen auf das Datum dieses Sicherheitsdatenblattes korrekt und zuverlässig sind; für die Genauigkeit, Zuverlässigkeit und/oder Vollständigkeit dieser Informationen wird jedoch keine Gewährleistung, Garantie oder Bürgschaft, weder explizit noch implizit, übernommen.
<G-vec00345-001-s315><believe.gehen><en> Although there is no precise information regarding prevalence, experts believe that children suffer more frequently from mould allergies than adults.
<G-vec00345-001-s315><believe.gehen><de> Auch wenn keine genauen Verbreitungszahlen vorliegen, gehen Experten davon aus, dass Kinder häufiger von Schimmelpilzallergien betroffen sind als Erwachsene.
<G-vec00345-001-s316><believe.gehen><en> "Experts believe that the Internet contributes to the development of sex addiction - because it allows people to get instant access to ""free for all tastes and color"" .."
<G-vec00345-001-s316><believe.gehen><de> "Experten gehen davon aus, dass das Internet zur Entwicklung der Sexsucht trägt - weil es erlaubt, dass Menschen den sofortigen Zugriff auf ""frei für jeden Geschmack und Farbe"" zu bekommen .."
<G-vec00345-001-s317><believe.gehen><en> We believe that nobody knows your specific challenges and the details of your work better than you yourself.
<G-vec00345-001-s317><believe.gehen><de> Wir gehen davon aus, dass sich niemand mit den spezifischen Herausforderungen und Rahmenbedingungen in Ihrem Bereich so gut auskennt wie Sie selbst.
<G-vec00345-001-s318><believe.gehen><en> Some experts even believe that 90 percent of the world's data has been created in the past two years alone.
<G-vec00345-001-s318><believe.gehen><de> Einige Experten gehen davon aus, dass 90 Prozent der weltweit erzeugten Daten aus den beiden letzten Jahren stammen.
<G-vec00345-001-s320><believe.gehen><en> The organizations undersigned believe that the system the Ministry is in the process of procuring not only threatens the privacy of millions of Internet users by trying to monitor private and personal communications, such as those taking place on Viber and Whatsapp.
<G-vec00345-001-s320><believe.gehen><de> Die unterzeichnenden Organisationen gehen davon aus, dass die Beschaffung des geforderten Systems nicht nur die Privatsphäre von Millionen von Internetnutzerinnen und Nutzern bedroht, dadurch dass es versucht, private Telekommunikationsdienste wie Viber oder Whatsapp zu zensieren.
<G-vec00345-001-s321><believe.gehen><en> Currently, scientists believe that Philae is in sunlight for 1.3 hours.
<G-vec00345-001-s321><believe.gehen><de> Zurzeit gehen die Wissenschaftler davon aus, dass Philae 1,3 Stunden lang im Sonnenlicht steht.
<G-vec00345-001-s322><believe.gehen><en> We believe diversifying our global manufacturing capacity will allow us to better leverage resources more cost effectively, enhance our competitiveness in overseas markets and enable us to increase our global market share.
<G-vec00345-001-s322><believe.gehen><de> Wir gehen davon aus, dass wir unsere Ressourcen mithilfe einer Diversifizierung unserer weltweiten Fertigungskapazitäten kosteneffizienter nutzen, unsere internationale Wettbewerbsfähigkeit stärken und damit unseren globalen Marktanteil weiter ausbauen können.
<G-vec00092-001-s323><believe.glauben><en> Believe me, I value your life more than mine.
<G-vec00092-001-s323><believe.glauben><de> Glaub mir, ich schätz dein Leben mehr als meins.
<G-vec00092-001-s324><believe.glauben><en> Believe me, it really sets the tone for your night.
<G-vec00092-001-s324><believe.glauben><de> Glaub mir, es setzt wirklich den richtigen Ton für die Nacht.
<G-vec00092-001-s325><believe.glauben><en> But as you can see, he made his way and is recently touring with his band and the new studio album (I believe it’s his fifth) “Leichtigkeit des Seins” through Germany, Austria and Switzerland.
<G-vec00092-001-s325><believe.glauben><de> Aber wie man sieht, ging er seinen Weg und tourt nun aktuell mit seiner Band und dem neusten Studioalbum (ich glaub, es ist in etwa das fünfte) „Leichtigkeit des Seins“ durch Deutschland, Österreich und die Schweiz.
<G-vec00092-001-s326><believe.glauben><en> Believe me, there is nothing more beautiful than that.
<G-vec00092-001-s326><believe.glauben><de> Glaub mir, es gibt nichts Schöneres als das.
<G-vec00092-001-s327><believe.glauben><en> """Only I myself can still stand in the way, but I can't believe that."""
<G-vec00092-001-s327><believe.glauben><de> """Ich kann mir nur noch selbst im Weg stehen, aber das glaub' ich nicht""."
<G-vec00092-001-s328><believe.glauben><en> """Believe me without you, we Christians would not exist here anymore"" he keeps on repeating."
<G-vec00092-001-s328><believe.glauben><de> """Glaub mir – wir wiederholen ständig – ohne dich würden wir Christen hier nicht mehr existieren""."
<G-vec00092-001-s329><believe.glauben><en> Believe it or not, B2B organizations have almost no clue what they are doing when it comes to marketing and lead generation.
<G-vec00092-001-s329><believe.glauben><de> Glaub es oder nicht, B2B-Organisationen haben so gut wie keine Ahnung, was sie tun, wenn es um Marketing und Lead-Generierung kommt.
<G-vec00092-001-s330><believe.glauben><en> I’m here to fulfill these wicked desires and believe me (with protection), I like to do it.
<G-vec00092-001-s330><believe.glauben><de> Ich bin da um dir diese verruchten Wünsche zu erfüllen und glaub mir (mit Schutz), ich machs gern.
<G-vec00092-001-s331><believe.glauben><en> """I'd like to believe you, captain,"" I went on in a tone of some sarcasm."
<G-vec00092-001-s331><believe.glauben><de> – Ich glaub's gerne, Kapitän, fuhr ich etwas ironisch fort.
<G-vec00092-001-s332><believe.glauben><en> "Believe when I say this is only a glimpse of his true potential."" remarked the green giant."
<G-vec00092-001-s332><believe.glauben><de> Glaub mir, das hier ist nur ein Abklatsch seiner wahren Macht!“, schloss der grüne Riese.
<G-vec00092-001-s333><believe.glauben><en> "Fletch: ""Believe me, it's got an electoral roll of 107,000 and that's not including kids."
<G-vec00092-001-s333><believe.glauben><de> "Fletch: ""Glaub mir, aus einer Wählerliste ergeben sich 107.000, und das beinhaltet nicht die Kinder."
<G-vec00092-001-s334><believe.glauben><en> Believe me, Adia, we are still innocent.
<G-vec00092-001-s334><believe.glauben><de> Glaub mich, Adia, wir sind immer noch unschuldig.
<G-vec00092-001-s335><believe.glauben><en> I believe, I mainly know the Polo Hofer/Rumpelstilz songs because someone else has covered it
<G-vec00092-001-s335><believe.glauben><de> Ich glaub, ich kenne die meisten Polo Hofer bzw Rumpelstilz Songs, weil ich sie irgendwann mal als Cover bei jemandem gehört hab.
<G-vec00092-001-s336><believe.glauben><en> Believe it or not, rubbing a cut strawberry on your teeth can whiten them.
<G-vec00092-001-s336><believe.glauben><de> Glaub es oder nicht, einen Schnitt Erdbeere auf den Zähnen reiben können sie aufzuhellen.
<G-vec00092-001-s337><believe.glauben><en> Believe me they will gladly take your expert’s opinion.
<G-vec00092-001-s337><believe.glauben><de> Glaub mir, sie werden deine Expertenmeinung gerne hören.
<G-vec00092-001-s338><believe.glauben><en> There are leads on the internet that are of value in explaining parts of my story, believe it or not.
<G-vec00092-001-s338><believe.glauben><de> Da sind Spuren im Internet, die auf wertvolle Art, Teile meiner Geschichte erklären, glaub es oder nicht.
<G-vec00092-001-s339><believe.glauben><en> Believe it or not, this is often the case.
<G-vec00092-001-s339><believe.glauben><de> Glaub es oder nicht, Dies ist häufig der Fall,.
<G-vec00092-001-s340><believe.glauben><en> Believe me, I'm often tempted to ignore technical SEO.
<G-vec00092-001-s340><believe.glauben><de> Glaub mir, ich würde das technische SEO oft am liebsten ignorieren.
<G-vec00092-001-s341><believe.glauben><en> Believe me - it will NEVER happen again, and I wish that were not true.
<G-vec00092-001-s341><believe.glauben><de> Glaub mir, das wird NIEMALS wieder passieren und ich wünsche das wäre nicht wahr.
<G-vec00092-001-s342><believe.glauben><en> And I believe that your Volunteer Ministers are that army.
<G-vec00092-001-s342><believe.glauben><de> Ich glaube, dass Ihre Ehrenamtlichen Geistlichen dieses Heer sind.
<G-vec00092-001-s343><believe.glauben><en> """That's why there is a concept that is used really often, namely value-added budgets, which emerge in architecture, and I do believe that's where qualities can be found, although that does not exhaustively describe what the concept implies."
<G-vec00092-001-s343><believe.glauben><de> """Es gibt deshalb auch einen Begriff, der total oft verwendet wird, dass sind Mehrwertbudgets, die in der Architektur entstehen, wo ich schon glaube, wo Qualitäten zu finden sind, wobei das nicht erschöpft, was der Begriff ist."
<G-vec00092-001-s344><believe.glauben><en> "And saying this he implied ""Lord you can do everything"", ""and me, Lord, I believe in you""."
<G-vec00092-001-s344><believe.glauben><de> "Und das sagte er implizierte ""Herr Sie alles tun können"", ""Und ich, Lord, Ich glaube an dich ""."
<G-vec00092-001-s345><believe.glauben><en> I believe that in addition to Falun Gong practitioners, all righteous people will never turn a deaf ear to the Chinese regime's persecution, and instead they would help stop it.
<G-vec00092-001-s345><believe.glauben><de> Ich glaube, dass neben den Falun Gong-Übenden alle aufrichtigen Menschen der Verfolgung durch Chinas Regime niemals den Rücken kehren werden, sondern dabei helfen werden, diese zu stoppen.
<G-vec00092-001-s346><believe.glauben><en> This turning towards nature and study is, I believe, particularly gratifying, as it arouses the hope that Éva Nagy discovered the rare road to rejuvenation and serenity through contemplation of nature.
<G-vec00092-001-s346><believe.glauben><de> Diese Wendung zur Natur und Studie ist, glaube ich, ganz besonders erfreulich, weckt sie doch die Hoffnung, dass Éva Nagy den seltenen Weg der Verjüngung und des Heiter-Werdens durch die Betrachtung der Natur entdeckt hat.
<G-vec00092-001-s347><believe.glauben><en> I believe I should not have been brought back, that it was a mistake.
<G-vec00092-001-s347><believe.glauben><de> Ich glaube ich hätte nicht zurückgebracht werden sollen, dass es ein Irrtum war.
<G-vec00092-001-s348><believe.glauben><en> ← I believe that education is the civil rights issue of our generation.
<G-vec00092-001-s348><believe.glauben><de> ← Ich glaube, dass Bildung die Bürgerrechte Thema unserer Generation ist.
<G-vec00092-001-s349><believe.glauben><en> In fact, I believe that the practical wireless power supply system, offering non-contact electric power transmission, was first achieved using high-efficiency SiC power devices.
<G-vec00092-001-s349><believe.glauben><de> Tatsächlich glaube ich, dass das praktische drahtlose Stromversorgungssystem, das kontaktlose elektrische Energieübertragung bietet, unter Verwendung hocheffizienter SiC-Leistungshalbleiter erst ermöglicht wurde.
<G-vec00092-001-s350><believe.glauben><en> I believe that God wants this work.
<G-vec00092-001-s350><believe.glauben><de> Ich glaube, Gott will diese Arbeit.
<G-vec00092-001-s351><believe.glauben><en> I believe that the exchange program at Freie Universität opened the door to my internship, as it enabled me to gain experience in studying at a German university and to improve my German language skills.
<G-vec00092-001-s351><believe.glauben><de> Ich glaube, dass mir das Austauschprogramm an der Freien Universität die Tür zu dieser Praktikumsstelle geöffnet hat, da ich dadurch Erfahrung mit dem Studium an einer deutschen Universität sammeln konnte und meine Deutschkenntnisse sehr verbessern konnte.
<G-vec00092-001-s352><believe.glauben><en> I do not believe what the television has shown.
<G-vec00092-001-s352><believe.glauben><de> Sie antwortete mir: „Ich glaube Ihnen.
<G-vec00092-001-s353><believe.glauben><en> And here do not believe it, Esteemed Fratelli, We want to allude that the facts, however painful, of France, because these are largely offset by more expensive consolations: the wonderful union of the Venerable Episcopate, generous disinterest of the clergy, and compassionate firmness of Catholics willing to make any sacrifice for the protection of the faith and for the glory of their homeland; It has fulfilled a' Last time that persecution only serve to highlight and point to' universal admiration of the virtues of the persecuted and at most are like the waves of the sea, that in frangendosi storm on the rocks, li purificano, if it was necessary, the mud that had sullied them.
<G-vec00092-001-s353><believe.glauben><de> Und hier glaube es nicht, Verehrte Fratelli, Wir weisen darauf hin, dass die Fakten, aber schmerzlich, Frankreichs, da diese durch die liebste Tröstungen weitgehend ausgeglichen: die wunderbare Vereinigung des Ehrwürdigen Bischofs-, durch die großzügige Uneigennützigkeit des Klerus, und mitfühlend Festigkeit der Katholiken bereit, jedes Opfer zu bringen für den Schutz des Glaubens und für den Ruhm ihrer Heimat; Es hat sich erfüllt ein' andere Zeit, die Verfolgung nur zu markieren, und zeigen Sie auf' allgemeine Bewunderung der Tugenden der Verfolgten und die meisten sind wie die Wellen des Meeres, dass in frangendosi Sturm auf den Felsen, läutern, notfalls, aus dem Schlamm, der sie besudelt hatte.
<G-vec00092-001-s354><believe.glauben><en> I do not believe that I am crazy.
<G-vec00092-001-s354><believe.glauben><de> Ich glaube nicht dass ich verrückt bin.
<G-vec00092-001-s355><believe.glauben><en> A few of us are in the fifth. I believe that one way to develop our consciousness and get into a higher dimension is regular meditation.
<G-vec00092-001-s355><believe.glauben><de> Ich glaube, dass ein Weg unser Bewusstsein weiter zu entwickeln und in eine höhere Dimension aufzusteigen, regelmäßige Meditation ist.
<G-vec00092-001-s356><believe.glauben><en> I believe that the Ralls have always lived in Eningen only the family name has changed.
<G-vec00092-001-s356><believe.glauben><de> Ich glaube, daß die Ralls immer in Eningen gelebt haben.
<G-vec00092-001-s357><believe.glauben><en> "So this is atrocious, but I believe that when Lacan says: ""In a speech that is not appearing"", that is to say that its own logic abuts on a real."
<G-vec00092-001-s357><believe.glauben><de> "Also es ist schrecklich, aber ich glaube, dass, wenn Lacan sagt: ""In einer Rede, die nicht angezeigt"", das heißt, dass sie in ihrer eigenen Logik stößt sagen auf einem echten."
<G-vec00092-001-s358><believe.glauben><en> As an autonomous learner, finding that playground can be hard, but I believe in taking language out into the real world as soon as possible – even if it just means speaking to yourself while cooking during the first weeks of learning.
<G-vec00092-001-s358><believe.glauben><de> Für einen selbstständigen Lerner kann es sehr schwer sein, diese Spielwiese zu finden, aber ich glaube, man sollte die Sprache dennoch so schnell wie möglich mit hinaus in die reale Welt nehmen – auch wenn dies bedeutet, dass man in den ersten Wochen vielleicht nur beim Kochen mit sich selber spricht.
<G-vec00092-001-s359><believe.glauben><en> Credo is Latin and means: I believe.
<G-vec00092-001-s359><believe.glauben><de> Credo ist Latein und bedeutet: Ich glaube.
<G-vec00092-001-s360><believe.glauben><en> I believe that a process to address reconciliation is indeed imperative for this country... As President, this is one of my priorities for this young nation.
<G-vec00092-001-s360><believe.glauben><de> Ich glaube, ein Prozess, in dem Aussöhnung angesprochen wird, ist in der Tat für dieses Land unerlässlich...Als Präsident ist dies eine meiner Prioritäten für diese junge Nation.
<G-vec00092-001-s361><believe.glauben><en> I believe I really feel fine.
<G-vec00092-001-s361><believe.glauben><de> Ich glaube, ich habe es richtig gut.
<G-vec00092-001-s362><believe.glauben><en> I believe they saw something they shouldn't have seen (24'43'').
<G-vec00092-001-s362><believe.glauben><de> Ich glaube, die beiden haben da was gesehen, was sie nicht hätten sehen sollen (24'44'').
<G-vec00092-001-s363><believe.glauben><en> married him; yet I believe I was never really in love with him.
<G-vec00092-001-s363><believe.glauben><de> Ich hätte ihn heiraten können, und glaube, ich war nie in ihn verliebt.
<G-vec00092-001-s364><believe.glauben><en> Steinbach: We see it every day: I believe we can actually almost statistically measure how the American invasion of Iraq in 2002 has lead to an escalation – an escalation of violence that we've never seen the like of – in the entire region from Morocco to Indonesia.
<G-vec00092-001-s364><believe.glauben><de> Steinbach: Das erleben wir tagtäglich: Ich glaube, wir können tatsächlich fast statistisch ermessen, wie der Aufmarsch der Amerikaner seit 2002 gegen den Irak zu einer Eskalation, einer bis dahin nicht da gewesenen Eskalation der Gewalt gefÃ1⁄4hrt hat – und zwar im gesamten Raum zwischen Marokko und Indonesien.
<G-vec00092-001-s365><believe.glauben><en> I believe that these symptoms would be classified by modern-day medicine as epilepsy.
<G-vec00092-001-s365><believe.glauben><de> Ich glaube, dass die heutige Medizin diese Symptome als Epilepsie (Fallsucht) diagnostizieren würde.
<G-vec00092-001-s366><believe.glauben><en> I know it is tempting to respond to ads and buy the “latest and greatest” product from different companies, but I believe it is far better to use a complete line of products from one company.
<G-vec00092-001-s366><believe.glauben><de> "Ich weiß, es ist verlockend, auf Anzeigen zu reagieren und kaufen die ""neuesten und besten"" Produkt aus verschiedenen Unternehmen, aber ich glaube, es ist viel besser, eine komplette Linie von Produkten aus einer Hand zu benutzen."
<G-vec00092-001-s367><believe.glauben><en> I myself believe in full to the researchers.
<G-vec00092-001-s367><believe.glauben><de> Ich selbst glaube, in voller Höhe an die Forscher.
<G-vec00092-001-s368><believe.glauben><en> I believe it is quite simple.
<G-vec00092-001-s368><believe.glauben><de> Ich glaube, es ist ganz einfach.
<G-vec00092-001-s369><believe.glauben><en> This I believe may in some way be insightful; however, I have no earthly idea how.
<G-vec00092-001-s369><believe.glauben><de> Das glaube ich, mag auf eine Art - Inneneinsicht sein; auf jeden Fall habe ich keine irdische Idee, wie.
<G-vec00092-001-s370><believe.glauben><en> I know that what I believe I have received from God must be tested.
<G-vec00092-001-s370><believe.glauben><de> Ich weiß, dass was Ich glaube, von Gott empfangen zu haben, getestet werden muss.
<G-vec00092-001-s371><believe.glauben><en> I believe it is a political problem.
<G-vec00092-001-s371><believe.glauben><de> Ich glaube, das ist ein politisches Problem.
<G-vec00092-001-s372><believe.glauben><en> I believe the answer lies in the transparent, crystal-clear appearance of most Grappas, the younger ones.
<G-vec00092-001-s372><believe.glauben><de> Ich glaube, die Antwort ist im transparenten und kristallklaren Erscheinungsbild der meisten, d.h. der jungen Grappas zu suchen.
<G-vec00092-001-s373><believe.glauben><en> I believe you have certain expectations of me, and I intend to fulfill them all to the best of my ability,” I answer her, and she nearly convulses in her seat.
<G-vec00092-001-s373><believe.glauben><de> Ich glaube, du hast gewissen Erwartungen, die ich unter Aufbietung all meines Könnens zu erfüllen versuchen werde“, antworte ich und sie verkrampft sich auf ihrem Platz.
<G-vec00092-001-s374><believe.glauben><en> Roger Meier: I believe it comes from the combination of my different previous activities.
<G-vec00092-001-s374><believe.glauben><de> Roger Meier: Ich glaube, es ist das Resultat der Kombination meiner verschiedenen bisherigen Tätigkeiten.
<G-vec00092-001-s375><believe.glauben><en> As the message came to me, I believe it will use extreme heat to affect those two places, and change the magnetic condition of the Poles.
<G-vec00092-001-s375><believe.glauben><de> Als die Nachricht kam zu mir, ich glaube, es wird extremer Hitze zu verwenden, um diese beiden Orte zu beeinträchtigen, und ändern Sie den magnetischen Zustand der Polen.
<G-vec00092-001-s376><believe.glauben><en> This means that all third-party apps will potentially have access to the feature as well — or at least those sold through the Mac App Store, I believe.
<G-vec00092-001-s376><believe.glauben><de> Dies bedeutet, dass alle Apps von Drittanbietern werden möglicherweise Zugriff auf die Funktion als auch - oder zumindest jene, die durch den Mac App Store verkauft, Ich glaube,.
<G-vec00092-001-s377><believe.glauben><en> I believe she told me that she was taking “sick leave” to get away to apply for this different position.
<G-vec00092-001-s377><believe.glauben><de> "Ich glaube, sie hat mir gesagt, dass sie für diese andere Position ""Kranken"" wegzukommen anzuwenden fand."
<G-vec00092-001-s378><believe.glauben><en> I believe they have the right to expect some solidarity from us.
<G-vec00092-001-s378><believe.glauben><de> Ich glaube, die Kinder, haben das Recht von uns die Solidarität zu erwarten.
<G-vec00092-001-s379><believe.glauben><en> “I believe your time is up John,” I say pointedly.
<G-vec00092-001-s379><believe.glauben><de> „ Ich glaube, die Zeit ist um, John“, sage ich demonstrativ.
<G-vec00092-001-s380><believe.glauben><en> The thought would give you the greatest strength to escape from this fate but you lack to believe this and I cannot give you this faith but you have to obtain it yourself through a life of love.
<G-vec00092-001-s380><believe.glauben><de> Der Gedanke würde euch die größte Kraft verleihen, diesem Schicksal zu entgehen, doch euch fehlt der Glaube daran, und diesen Glauben kann Ich euch nicht geben, sondern ihr müsset ihn euch selbst erwerben durch ein Liebesleben.
<G-vec00092-001-s381><believe.glauben><en> I believe that people in Europe will largely judge all of us who represent Europe by whether during the coming decades we can continue to safeguard what has made Europe strong –a community of values, a community of people whose individual dignity is protected, which has brought people prosperity and social cohesion.
<G-vec00092-001-s381><believe.glauben><de> Ich glaube, die Menschen in Europa werden uns alle, die wir Europa vertreten, natürlich ganz wesentlich daran messen, ob wir das, was Europa stark gemacht hat eine Wertegemeinschaft, eine Gemeinschaft der Menschen, die in ihrer individuellen Würde leben können, die den Menschen Wohlstand und sozialen Zusammenhalt gebracht hat, auch für die nächsten Jahrzehnte weiter sichern können.
<G-vec00092-001-s382><believe.glauben><en> I strongly believe that high quality, sustainable management and use of forests is part of the solution.
<G-vec00092-001-s382><believe.glauben><de> Ich glaube fest daran, dass die gute Pflege und nachhaltige Nutzung der Wälder ein Bestandteil der Lösung sein werden.
<G-vec00092-001-s383><believe.glauben><en> My hypothesis may seem almost paradoxical, but I firmly believe that in the end, the superiority of our liberal democracy will not be proved by its sense of mission, but rather by its willingness to criticise and renew itself.
<G-vec00092-001-s383><believe.glauben><de> Meine These mag fast paradox erscheinen, aber ich glaube fest daran: Am Ende beweist sich die Überlegenheit unserer liberalen Demokratie nicht in ihrem Sendungsbewusstsein, sondern in ihrer Bereitschaft auch zu Selbstkritik und Selbsterneuerung.
<G-vec00092-001-s384><believe.glauben><en> People fail to realise and believe this and therefore do not evaluate earthly life in accordance with My Will.
<G-vec00092-001-s384><believe.glauben><de> Diese Erkenntnis, der Glaube daran, fehlt den Menschen, und darum werten sie das Erdenleben nicht aus, wie es Meinem Willen entspricht.
<G-vec00092-001-s385><believe.glauben><en> "The farewell ceremony was also a moving occasion for principal Laurence Nodder: ""Just like our former Honorary President Nelson Mandela, I continue to believe that education is the most powerful tool for changing the world."
<G-vec00092-001-s385><believe.glauben><de> "Auch für Rektor Laurence Nodder war der Abschied von den Pionieren ein bewegender Moment: ""Ebenso wie unser ehemaliger Ehrenpräsident Nelson Mandela glaube ich nach wie vor daran, dass Bildung das mächtigste Werkzeug ist, um die Welt zu verändern."
<G-vec00092-001-s386><believe.glauben><en> "I believe that the initialling of association agreements, especially the provisions of these agreements on the creation of a deep and comprehensive free trade area, and agreements with Moldova and Georgia during the Summit will open the way for new possibilities of political and economic relations with these countries,"" said Robertas Dargis, President of the Lithuanian Confederation of Industrialists."
<G-vec00092-001-s386><believe.glauben><de> "Ich glaube daran, dass wenn die Assoziierungsabkommen und vor allem die Bestimmungen der genannten Abkommen zur Errichtung eines umfassenden und vielseitigen Freihandelsraumes sowie die Verträge mit Moldawien und Georgien auf dem Gipfeltreffen paraphiert werden, dann werden wir den Weg für neue politische und wirtschaftliche Beziehungen mit diesen Ländern ebnen"", sagte der Präsident des litauischen Industrieverbandes Robertas Dargis."
<G-vec00092-001-s387><believe.glauben><en> Yes I believe that there is an afterlife now more than I believed before.
<G-vec00092-001-s387><believe.glauben><de> Ja Ich glaube jetzt mehr daran dass es ein Jenseits gibt, als ich vorher glaubte.
<G-vec00092-001-s388><believe.glauben><en> Unfortunately, the Palestinian Authority has moved away from these negotiations, but I believe, I remain committed to the idea that the only way we can achieve a lasting peace is through the concept of two states for two peoples – a demilitarized Palestinian state that recognizes the Jewish nation state of Israel.
<G-vec00092-001-s388><believe.glauben><de> Aber ich stehe weiterhin zu der Idee und glaube daran, dass der einzige Weg, dauerhaften Frieden zu erreichen, das Konzept von zwei Staaten für zwei Völker ist – das Konzept von einem entmilitarisierten palästinensischen Staat, der den jüdischen Nationalstaat Israel anerkennt.
<G-vec00092-001-s389><believe.glauben><en> "He continued: ""I firmly believe that freedom will be victorious."
<G-vec00092-001-s389><believe.glauben><de> "Er fuhr fort: ""Ich glaube fest daran, dass die Freiheit gewinnen wird."
<G-vec00092-001-s390><believe.glauben><en> I strongly believe that Europe can further develop its leadership in language technologies and deliver solutions that will benefit the European society and economy at large.
<G-vec00092-001-s390><believe.glauben><de> Ich glaube fest daran, dass Europa seine führende Rolle im Bereich der Sprachtechnologie weiter ausbauen und Lösungen liefern kann, die der gesamten europäischen Gesellschaft und Wirtschaft zugute kommen werden.
<G-vec00092-001-s391><believe.glauben><en> And since the process of the end has never taken place before, since people have no knowledge of this, it is also difficult for them to believe it, even though from the beginning of this earthly period I have indicated this end time and again.
<G-vec00092-001-s391><believe.glauben><de> Und da es sich am Ende um einen Vorgang handelt, der auf dieser Erde noch nicht stattgefunden hat, da die Menschen um nichts Derartiges wissen, fällt ihnen auch der Glaube daran schwer, wenngleich Ich von Beginn dieser Erdperiode an immer wieder auf dieses Ende hingewiesen habe.
<G-vec00092-001-s392><believe.glauben><en> """I firmly believe that together we will find ways to make abortion rare and, when needed, accessible and safe."
<G-vec00092-001-s392><believe.glauben><de> """Ich glaube fest daran, dass wir es gemeinsam schaffen werden, die Zahl der Schwangerschaftsabbrüche zu reduzieren, diese aber zugleich zugänglicher und sicherer zu machen."
<G-vec00092-001-s393><believe.glauben><en> I believe it is the result of faulty teaching to begin with.
<G-vec00092-001-s393><believe.glauben><de> Ich glaube, die Irrlehre ist daran schuld.
<G-vec00092-001-s394><believe.glauben><en> Yes, I believe that it can happen here.
<G-vec00092-001-s394><believe.glauben><de> Ja, ich glaube daran, dass es hier geschehen kann.
<G-vec00092-001-s395><believe.glauben><en> """I firmly believe that, in the not-too-distant future, origami methods will join other new technologies, such as 3D printing, as one more element of the designer's toolkit,"" Lang said."
<G-vec00092-001-s395><believe.glauben><de> """Ich glaube fest daran, dass die Origami-Methoden in nicht allzu ferner Zukunft auch neue Technologien, wie den 3D-Druck, erobern werden und den Designern damit ein weiteres Gestaltungselement zur Verfügung stehen wird"", sagt Lang."
<G-vec00092-001-s396><believe.glauben><en> I believe that glass is good for me, for my family, and for the environment.
<G-vec00092-001-s396><believe.glauben><de> Ich glaube daran, dass Glas gut für mich, für meine Familie und für die Umwelt ist.
<G-vec00092-001-s397><believe.glauben><en> But I do not believe that we come without drawbacks thereof.
<G-vec00092-001-s397><believe.glauben><de> Ich glaube aber nicht daran, dass wir ohne Nachteile davon kommen.
<G-vec00092-001-s398><believe.glauben><en> "Let me make one thing clear: I am not opposed to traditional marketing and certainly believe that mailings, e-mail newsletters and, where applicable, TV commercials and print ads and ""real"" events still have their place and can make sense."
<G-vec00092-001-s398><believe.glauben><de> "Um es an dieser Stelle klar zu sagen: Ich bin kein Feind des traditionellen Marketings, glaube durchaus daran, dass Postsendungen, E-Mail Newsletter, wo angebracht auch Fernseh- und Druckanzeigen sowie ""richtige"" Veranstaltungen ihren Platz haben und Sinn machen können."
<G-vec00092-001-s399><believe.glauben><en> Rather, I believe Jesus wept inside as Judas walked out of the Upper Room to betray Him.
<G-vec00092-001-s399><believe.glauben><de> Ich glaube vielmehr, dass Jesus innerlich weinte, als Judas den oberen Raum verlie, um Ihn zu verraten.
<G-vec00092-001-s400><believe.glauben><en> I believe the speed of earth is the factor.
<G-vec00092-001-s400><believe.glauben><de> Ich glaube, dass die Geschwindigkeit von Erde der Faktor ist.
<G-vec00092-001-s401><believe.glauben><en> Experience was definitely real I believe it is real because of unexplainable things that I have no explanation for or the sense of peace I feel inside despite the ordeal.
<G-vec00092-001-s401><believe.glauben><de> Erfahrung war definitiv real Ich glaube dass sie real ist, wegen unerklärlichen Dingen für die ich keine Erklärung habe, oder wegen dem empfinden von Frieden den ich innerlich fühle trotz der Tortur.
<G-vec00092-001-s402><believe.glauben><en> I believe it is going to be pleasant.
<G-vec00092-001-s402><believe.glauben><de> Ich glaube dass es angenehm sein wird.
<G-vec00092-001-s403><believe.glauben><en> Yes Now, I believe there is something out there after death.
<G-vec00092-001-s403><believe.glauben><de> Ja Jetzt glaube ich dass dort draußen etwas ist nach dem Tod.
<G-vec00092-001-s404><believe.glauben><en> Kieren: I believe he does.
<G-vec00092-001-s404><believe.glauben><de> Kieren: Ich glaube, dass er das tut.
<G-vec00092-001-s405><believe.glauben><en> However, I do believe that it is the obligation of all leaders in all countries to speak out forcefully against violence and extremism.
<G-vec00092-001-s405><believe.glauben><de> Allerdings glaube ich, dass die führenden Politiker aller Länder dazu verpflichtet sind, sich deutlich gegen Gewalt und Extremismus auszusprechen.
<G-vec00092-001-s406><believe.glauben><en> I believe the figure to be around eight feet tall.
<G-vec00092-001-s406><believe.glauben><de> Ich glaube dass die Gestalt so um acht Fuß hoch war.
<G-vec00092-001-s407><believe.glauben><en> Yes I believe you don't just die.
<G-vec00092-001-s407><believe.glauben><de> Ja Ich glaube dass man nicht einfach stirbt.
<G-vec00092-001-s408><believe.glauben><en> This is certainly an important topic and one that I believe will substantially differentiate both the wave technologies and the man-made surf venues in which they're installed.
<G-vec00092-001-s408><believe.glauben><de> Das ist tatsächlich ein heißes Thema und eines, wo ich glaube, dass sich sowohl bei der Wellentechnologie, wie auch in den Surf-Parks an sich, die Spreu vom Weizen trennen wird.
<G-vec00092-001-s409><believe.glauben><en> As a matter of facts, I do not believe we have a EURO crisis.
<G-vec00092-001-s409><believe.glauben><de> In der Tat glaube ich, dass wir keine EURO-Krise haben.
<G-vec00092-001-s410><believe.glauben><en> I truly believe this will benefit all sentient Souled beings.
<G-vec00092-001-s410><believe.glauben><de> Ich glaube wirklich, dass dies zum Vorteil aller fühlenden beseelten Wesen sein wird.
<G-vec00092-001-s411><believe.glauben><en> I do not believe I ever used a condescending tone or a confrontational approach with you, but if you felt I did, I am sorry and it was definitely not my intention to make you feel that way.
<G-vec00092-001-s411><believe.glauben><de> Ich glaube nicht, dass ich jemals einen herablassenden Umgangston oder eine konfrontative Haltung Ihnen gegenüber verwendet habe, aber wenn Sie das Gefühl hatten, dass es so war, dann tut es mir Leid und es war definitiv nicht meine Absicht Ihnen dieses Gefühl zu geben.
<G-vec00092-001-s412><believe.glauben><en> Yes I knew all the dead elderly people including the living which I believe was manipulated to bring me into the house that could have ended my life not to return to my earthly body in Germany.
<G-vec00092-001-s412><believe.glauben><de> Ja Ich kannte all die toten älteren Menschen einschließlich die Lebenden, wobei ich glaube dass ich manipuliert wurde, um mich ins Haus zu bringen was mein Leben beendet hätte, wenn ich nicht zu meinem irdischen Körper in Deutschland hätte zurückkehren können.
<G-vec00092-001-s413><believe.glauben><en> I believe the Pareto principle holds true, even while consuming content.
<G-vec00092-001-s413><believe.glauben><de> Ich glaube, dass das Pareto-Prinzip sogar auf das Konsumieren von Inhalten zutrifft.
<G-vec00092-001-s414><believe.glauben><en> I personally believe this verse provides us with a significant clue.
<G-vec00092-001-s414><believe.glauben><de> Ich glaube persönlich, dass uns dieser Vers einen bedeutenden Hinweiß gibt.
<G-vec00092-001-s415><believe.glauben><en> Nevertheless, I believe I have shown why Olympias remains the leading candidate with Roxane as a strong secondary possibility.
<G-vec00092-001-s415><believe.glauben><de> Dennoch, Ich glaube, dass ich gezeigt habe, warum Olympias Aussichtsreichster Kandidat mit Roxane als eine starke sekundäre Möglichkeit bleibt.
<G-vec00092-001-s416><believe.glauben><en> When I went under, I believe I left my body and went to another dimension.
<G-vec00092-001-s416><believe.glauben><de> Als ich bewusstlos wurde, glaube ich dass ich meinen Körper verließ und in eine andere Dimension gelangte.
<G-vec00092-001-s417><believe.glauben><en> "Although life after death has always been and remains a huge human preoccupation, I believe it is right to acknowledge that the greater overall focus has been ""The Future"" and life after death is merely one - perhaps the most important but still just one - aspect of that concern."
<G-vec00092-001-s417><believe.glauben><de> "Obwohl das Leben nach dem Tod immer eine große menschliche Hauptsorge war und bleibt, glaube ich dass es richtig ist anzuerkennen, dass der größere Gesamtfokus ""die Zukunft"" war und das Leben nach dem Tod bloß ein Aspekt - vielleicht der wichtigste aber trotzdem nur einer - dieses Anliegens ist."
<G-vec00092-001-s418><believe.glauben><en> »But I believe you'll find this interesting.« He waited for Pcherro to become fully awake and get up.
<G-vec00092-001-s418><believe.glauben><de> »Aber ich glaube, daß dich das hier interessieren wird.« Er wartete, bis Pcherro richtig wach war und sich aufgesetzt hatte.
<G-vec00092-001-s419><believe.glauben><en> I believe I made the right decision.
<G-vec00092-001-s419><believe.glauben><de> Ich glaube, daß ich die richtige Entscheidung traf.
<G-vec00092-001-s420><believe.glauben><en> I don't believe you; I bet you're lying to me about your precognition.
<G-vec00092-001-s420><believe.glauben><de> Ich glaube Ihnen nicht; ich wette, daß Sie mich, was Ihre Präkognition angeht, belügen.
<G-vec00092-001-s421><believe.glauben><en> I believe Canada has followed suit with advertisers on the web, if the USA and UK follow there example, then this site could end up being based in Timbuktu.
<G-vec00092-001-s421><believe.glauben><de> Ich glaube, daß Kanada Klage mit Inserenten auf dem Netz gefolgt hat, wenn die USA und Großbritannien dort Beispiel folgen, dann könnte dieser Aufstellungsort herauf in Timbuktu gegründet werden beenden.
<G-vec00092-001-s422><believe.glauben><en> I believe in healing; and I believe we will have afflictions.
<G-vec00092-001-s422><believe.glauben><de> Ich glaube an Heilung; und ich glaube, daß wir Leiden haben werden.
<G-vec00092-001-s423><believe.glauben><en> Therefore, I believe the Didache is the earliest Christian document we have.
<G-vec00092-001-s423><believe.glauben><de> Deshalb glaube ich, daß die Didache das früheste christliche Dokument ist, daß wir haben.
<G-vec00092-001-s424><believe.glauben><en> Emma Holly: The warning says that 'Black Lace novels contain sexual fantasies' which I believe is quite, quite true.
<G-vec00092-001-s424><believe.glauben><de> Emma Holly: Die Warnung besagt, daß „Black Lace Bücher sexuelle Phantasien enthalten“ wovon ich glaube, daß das sehr, sehr richtig ist.
<G-vec00092-001-s425><believe.glauben><en> In spite of their enormous effort of investigation to find invaluable fuel the reserves of these five oil companies one little increased, one does not risk the lack of petrol, but one little all the same asked the question on the beginning of a congestion of the world production of petroleum and I do not believe whether it is the exploitation of some expensive tar sand or offshore deposit in deep water which goes changed this situation.
<G-vec00092-001-s425><believe.glauben><de> Trotz ihrer gewaltigen Erforschungsanstrengung, um es zu finden wertvoller Brennstoff die Reserven dieser fünf ölgesellschaften man wenig riskiert man erhöhtes die trockene Panne nicht, aber man wenig trotzdem, das die Frage über den Beginn einer Stagnierung der weltweiten Erdölproduktion gestellt wurde, und ich glaube mich nicht, daß es der Betrieb einiger kostspieliger sei mit Sand bestreue bituminös oder Vorkommen off - shore aus tiefem Wasser, das geht gewechselt diese Lage.
<G-vec00092-001-s426><believe.glauben><en> I believe these great men continue to speak to us today and there are three important lessons they have to teach us.
<G-vec00092-001-s426><believe.glauben><de> Ich glaube, daß diese großen Männer fortfahren, mit uns heute zu sprechen und es drei wichtige Lektionen gibt, die sie uns unterrichten müssen.
<G-vec00092-001-s427><believe.glauben><en> I believe this can be very discouraging to you the consumer.
<G-vec00092-001-s427><believe.glauben><de> Ich glaube, daß dieses zu Ihnen den Verbraucher sehr entmutigen kann.
<G-vec00092-001-s428><believe.glauben><en> As someone who has seen quite a few hard drive crashes over the years, I believe that performing a full backup of your computer's hard drive should be an important part of your weekly (if not daily) routine.
<G-vec00092-001-s428><believe.glauben><de> Während jemand, das ziemlich viele Festplattenlaufwerk gesehen hat, über den Jahren zusammenstößt, glaube ich, daß das, eine volle Unterstützung des Festplattenlaufwerks Ihres Computers durchzuführen ein wichtiges Teil Ihres wöchentlichen (wenn nicht täglich) Programms sein sollte.
<G-vec00092-001-s429><believe.glauben><en> "He said, ""I believe all of these things are very meaningful."
<G-vec00092-001-s429><believe.glauben><de> "Er sagte: ""Ich glaube, daß all diese Dinge sehr bedeutungsvoll sind."
<G-vec00092-001-s430><believe.glauben><en> I shared it with an uncle who was a Lutheran minister, and he shared it my family through a newsletter, and I believe he also shared it with many of his friends.
<G-vec00092-001-s430><believe.glauben><de> Ich teilte sie mit einem Onkel, der ein evangelischer Priester war, und er teilte sie meiner Familie durch einen Newletter mit, und ich glaube auch, daß er sie mit vielen seiner Freunde teilte.
<G-vec00092-001-s431><believe.glauben><en> Based on this definition, I believe choice is the act of careful selection, identifying preferences and exploring quality alternatives that lead to freedom.
<G-vec00092-001-s431><believe.glauben><de> Gegründet auf dieser Definition, glaube ich, daß Wahl die Tat der sorgfältigen Vorwähler ist, Präferenzen kennzeichnet und Qualitätsalternativen erforscht, die zu Freiheit führen.
<G-vec00092-001-s432><believe.glauben><en> Liberal 'I believe ''God'' lives within each of us and we should be free to worship Him in whatever way we see fit.'
<G-vec00092-001-s432><believe.glauben><de> "Gemäßigt, ""ich glaube, daß Gott"" innerhalb eines jeden von uns wohnt und wir sollten so frei sein, Ihm auf jede mögliche Art und Weise zu dienen, auf welchen Weg auch immer, den wir finden."
<G-vec00092-001-s433><believe.glauben><en> I went for a while where I believe souls go.
<G-vec00092-001-s433><believe.glauben><de> Ich ging für eine Weile dorthin, wo ich glaube, daß die Seelen gehen werden.
<G-vec00092-001-s434><believe.glauben><en> I truly believe it has changed me for the better.
<G-vec00092-001-s434><believe.glauben><de> Ich glaube wirklich, daß mich das zum Besseren verändert hat.
<G-vec00092-001-s435><believe.glauben><en> In addition to this I wish to make the following remarks: I believe, if your displeasure really arose out of interest for the master class, that you would have shown a practical proof of this, if you had paved the way to an understanding with me before having recourse to a drastic resolution. You should have expressed a wish or even made a demand for the modification of the plan made by me.
<G-vec00092-001-s435><believe.glauben><de> Darauf erlaube ich mir zu bemerken: Ich glaube, daß Ihr Interesse für die Meisterklasse, falls es wirklich der Trieb Ihres Unmuthes war, am wirksamsten dadurch bethätigt worden wäre, daß Sie, bevor Sie zu einem gewaltsamen Beschlusse schritten, eine Verständigung mit mir angebahnt hätten, indem Sie den Wunsch und selbst die Forderung einer Modificirung des von mir mitgetheilten Planes an mich gerichtet hätten.
<G-vec00092-001-s436><believe.glauben><en> There is an obsession to outdo one another in magnificence, however I believe it is near its highest peak.
<G-vec00092-001-s436><believe.glauben><de> An Prachtsucht einer den anderen auszustechen, doch glaube ich, daß es seinem höchsten Gipfel nahe ist.
<G-vec00092-001-s437><believe.glauben><en> That the outer world, however, as it shines today and as it darkens tomorrow, often reaches into the innermost of the musician and poet, that one should believe, as well, and that there lies hidden in this symphony more than a merely beautiful song, more than mere suffering and joy as music has already expressed it a hundred times, nay, that it leads us into a region of which we cannot recall as ever having entered it, before; in order to admit this, one listen to such a symphony.
<G-vec00092-001-s437><believe.glauben><de> Aber daß die Außenwelt, wie sie heute strahlt, morgen dunkelt, oft hineingreift in das Innere des Dichters und Musikers, das wolle man nur auch glauben, und daß in dieser Symphnie mehr als ein bloßer schöner Gesang, mehr als ein bloßes Leid und Freud', wie es die Musik schon hundertfältig ausgesprochen, verborgen liegt, ja daß sie uns in eine Region führt, wo wir vorher gewesen zu sein uns nirgends erinnern könen, dies zuzugeben, höre man solche Symphonie.
<G-vec00092-001-s438><believe.glauben><en> We at IEMCA believe that people play the decisive role in the growth of our Company. If you feel you have the skill, attitude or talent that could be of interest to us and if you think you would like to join us please send your resume to IEMCA Human Resources Department:
<G-vec00092-001-s438><believe.glauben><de> Wenn Sie glauben, die richtige Einstellung, Ausbildung und Fähigkeiten zu besitzen, die für uns von Interesse sein könnten, und wenn Sie gerne für uns arbeiten würden, dann schicken Sie Ihren Lebenslauf an das Iemca Human Resources Department.
<G-vec00092-001-s439><believe.glauben><en> Many believe that even if fate goes against '84' that he will still wave goodbye to MX2; there are bigger fish in the fridge for this exceptional talent.
<G-vec00092-001-s439><believe.glauben><de> Viele glauben, dass auch wenn das Schicksal gegen die Nummer 84 spielt, sie sich trotzdem von der MX2 verabschieden wird; auf dieses außergewöhnliche Talent warten größere Möglichkeiten.
<G-vec00092-001-s440><believe.glauben><en> Many believe in the ability of a card deckpredict the future.
<G-vec00092-001-s440><believe.glauben><de> Viele glauben an der Fähigkeit des Kartendeckdie Zukunft vorhersagen.
<G-vec00092-001-s441><believe.glauben><en> The Vedic literature mentions the Matsyas and the Salvas as located near the river Saraswati and there is evidence to believe that by the close of the Vedic age Rajasthan had become fully colonized by the Vedic tribes.
<G-vec00092-001-s441><believe.glauben><de> Die vedischen Literatur erwähnt die Matsya und die Salvas als in der Nähe des Flusses Saraswati und es gibt Hinweise zu glauben, dass durch die enge des vedischen Zeitalters Rajasthan geworden war voll von den vedischen Stämmen besiedelt.
<G-vec00092-001-s442><believe.glauben><en> "Back to the rheinfalls: if the rheinfall is a point of interest for all those, who believe in the cosmic place ""Rheinfall"", then the thank of the tourism office will be guaranteed."
<G-vec00092-001-s442><believe.glauben><de> Wenn der Rheinfall zum Pilgerort für all jene wird, die an den Kraftort Rheinfall glauben, so ist Ihnen schon heute der Dank des Verkehrsvereins gewiss.
<G-vec00092-001-s443><believe.glauben><en> The Chinese believe that he has a mystical power, and, hanging it at home, you will be protected against evil spirits.
<G-vec00092-001-s443><believe.glauben><de> Die Chinesen glauben, daß er eine mystische Macht, und hängen es zu Hause, sehen Sie vor bösen Geistern zu schützen.
<G-vec00092-001-s444><believe.glauben><en> You may believe in them all, but you can't merely do that with Jesus.
<G-vec00092-001-s444><believe.glauben><de> An sie könnt ihr vielleicht gleichzeitig glauben, aber mit Jesus könnt ihr das nicht machen.
<G-vec00092-001-s445><believe.glauben><en> As we believe, Passper for Excel is the best tool so far to unprotect Excel workbook.
<G-vec00092-001-s445><believe.glauben><de> Wie wir glauben, Passper für Excel Bisher ist das beste Werkzeug zu Excel-Arbeitsmappe aufheben.
<G-vec00092-001-s446><believe.glauben><en> Heck, in this hard to believe, but we really have opened registration to everyone.
<G-vec00092-001-s446><believe.glauben><de> Heck, in das schwer zu glauben, aber wir haben wirklich Registrierung für jedermann geöffnet.
<G-vec00092-001-s447><believe.glauben><en> I would do one more mighty work for these Jews; I would give them one more chance to believe, even on their own terms—conditions of outward glory and the visible manifestation of the power of the Father and the love of the Son.
<G-vec00092-001-s447><believe.glauben><de> Ich möchte für diese Juden noch ein weiteres mächtiges Werk tun; ich möchte ihnen noch eine Chance mehr zum Glauben geben, sogar zu ihren eigenen Bedingungen – Bedingungen äußerer Herrlichkeit und sichtbarer Manifestation der Macht des Vaters und der Liebe des Sohnes.
<G-vec00092-001-s448><believe.glauben><en> "For the past six years, the evil CCP has used the most despicable means to brutally persecute Falun Gong practitioners who believe in ""Truthfulness, Compassion, Forbearance."""
<G-vec00092-001-s448><believe.glauben><de> "In den vergangenen sechs Jahren hat die KPC abscheulichste Mittel verwendet für die brutale Verfolgung von Falun Gong-Praktizierenden, die an die Prinzipien ""Wahrhaftigkeit, Barmherzigkeit, Nachsicht"" glauben."
<G-vec00092-001-s449><believe.glauben><en> With the panoramic views of the rocks, the multitude of birds, and the occasional glimpse of a deer, it is hard to believe that these magnificent Sedona Accommodations are only a quarter of a mile from the enchanting Uptown of Sedona.
<G-vec00092-001-s449><believe.glauben><de> Mit dem Panoramablick auf die Felsen, die Vielzahl der Vögel und den gelegentlichen Blick auf ein Reh, es ist schwer zu glauben, dass diese herrliche Sedona-Unterkünfte nur ein Viertel der eine Meile von der bezaubernden Uptown von Sedona.
<G-vec00092-001-s450><believe.glauben><en> Thus, people believe that six is a good sign (or date, or time, or any mode of measurement) for getting what they want with a minimum of fuss.
<G-vec00092-001-s450><believe.glauben><de> Deshalb glauben die Menschen, dass sechs ein gutes Zeichen (oder Datum oder Uhrzeit oder jede Art von Maßangabe) ist, um das zu bekommen, was sie mit einem Minimum an Aufwand erreichen möchten.
<G-vec00092-001-s451><believe.glauben><en> Through Jesus Christ and his work of reconciliation, the Holy Spirit comes to all who believe in Him.
<G-vec00092-001-s451><believe.glauben><de> Durch Jesus Christus und sein Versöhnungswerk kommt der Heilige Geist über alle, die an ihn glauben.
<G-vec00092-001-s452><believe.glauben><en> 2007-11-13 22:16:19 - Great relationship advice: dont be a darren stevens Q: I can't believe I'm asking this question, because I can't believe I'm even feeling this way.
<G-vec00092-001-s452><believe.glauben><de> 2007-11-13 22:16:19 - Großer Verhältnis-Rat: Seien Sie nicht ein Darren Stevens Q: Ich kann nicht glauben, ich diese Frage stelle, weil ich nicht glauben kann, daß ich gleichmäßiges Gefühl auf diese Weise bin.
<G-vec00092-001-s453><believe.glauben><en> - Although there are many theories, most researchers believe that pilonidal cysts are caused by penetration of the hair in the skin.
<G-vec00092-001-s453><believe.glauben><de> Obwohl es viele Theorien sind, glauben die meisten Forscher, dass pilonidalis Zysten durch das Eindringen von Haaren in die Haut verursacht werden.
<G-vec00092-001-s454><believe.glauben><en> We could hardly believe that the reactions of the fans were euphoric so.
<G-vec00092-001-s454><believe.glauben><de> Wir konnten kaum glauben, dass die Reaktionen der Fans dermaßen euphorisch waren.
<G-vec00092-001-s455><believe.glauben><en> The owners at Gili Lankanfushi care about people and believe in working together.
<G-vec00092-001-s455><believe.glauben><de> Die Besitzer sorgen sich um die Menschen und glauben an die Kraft der Zusammenarbeit.
<G-vec00092-001-s456><believe.glauben><en> We believe that openness increases the force that an idea appears to verify them in praxis, and also a failure may be a possibility – a possibility to gown and learn.
<G-vec00092-001-s456><believe.glauben><de> Wir glauben, dass die Aufgeschlossenheit die Kraft vermehrt, dass die Ideen entstehen, um sie in der Praxis zu prűfen, so wie auch Misserfolg kann zu einer Möglichkeit werden- Möglichkeit zum Wachstum und der Entwicklung.
<G-vec00092-001-s457><believe.glauben><en> Well, scusateci, but we believe it is not just.
<G-vec00092-001-s457><believe.glauben><de> Gut, scusateci, aber wir glauben, es ist nicht nur.
<G-vec00092-001-s458><believe.glauben><en> There are some people that believe antique cars should no longer be driven on our open roads.
<G-vec00092-001-s458><believe.glauben><de> Es gibt einige Leute, die glauben, mit antiken Autos sollten nicht mehr gefahren werden auf unsere offenen Straßen.
<G-vec00092-001-s459><believe.glauben><en> Could not believe how bright white the light was.
<G-vec00092-001-s459><believe.glauben><de> Konnte nicht glauben, wie hell das weiße Licht war.
<G-vec00092-001-s460><believe.glauben><en> It is a requirement of the full humanity of the believers themselves, first of all, because our belief is fully human and does not escape our thirst for knowledge and understanding, as deep and extensive as possible, of what we believe.
<G-vec00092-001-s460><believe.glauben><de> Es ist ein Gebot der vollen Menschlichkeit der Gläubigen, vor allem damit unser Gläubigsein ganz menschlich ist und den Durst nach Wissen und Verstehen, dem tiefsten und umfassendsten Verstehen dessen, was wir glauben, nicht außer Acht lässt.
<G-vec00092-001-s461><believe.glauben><en> Military experts believe the number of cases of “friendly fire” during peacekeeping operations suggests its absence.
<G-vec00092-001-s461><believe.glauben><de> Militärexperten glauben, dass gerade die Zahl der Fälle von „friendly fire“ bei Friedensoperationen von seiner Abwesenheit zeugen soll.
<G-vec00092-001-s462><believe.glauben><en> "[HG 2.215.19] ""'However, since she merely sends word through messengers informing us of how glorious she is, we mayor may not believe it."
<G-vec00092-001-s462><believe.glauben><de> [HG 2.215.19] Da sie aber nur durch Boten von sich aussagen läßt, wie herrlich sie sei, so können wir solches wohl glauben, aber auch ebensogut bleiben lassen.
<G-vec00092-001-s463><believe.glauben><en> """For one to believe in the enlightenment and clarity of the Bible is a heterodox dogma"" so claim our infallible leaders."
<G-vec00092-001-s463><believe.glauben><de> Denn es ist ein heterodoxes Dogma an die Erleuchtung und die Klarheit der Bibel zu glauben, behaupten unsere unfehlbaren Führer.
<G-vec00092-001-s464><believe.glauben><en> Dievmīlis believe in other people\'s murdziņiem, philosopher - your own.
<G-vec00092-001-s464><believe.glauben><de> Dievmīlis glauben, in anderer Leute murdziņiem, Philosoph - Ihre eigene.
<G-vec00092-001-s465><believe.glauben><en> Many people believe that wrestling is a sport.
<G-vec00092-001-s465><believe.glauben><de> Viele Leute glauben, dass das Catchen Sport ist.
<G-vec00092-001-s466><believe.glauben><en> But all this would make no sense now or eight centuries without the Church as a common denominator and the faith in which we believe without having seen: God, creator of heaven and Earth; Jesus Christ who was raised on the third day and ascended into heaven; I believe in the Holy Spirit, in the resurrection and eternal life.
<G-vec00092-001-s466><believe.glauben><de> Aber all dies wäre sinnlos jetzt oder acht Jahrhunderte ohne die Kirche als einen gemeinsamen Nenner und den Glauben an das wir glauben, ohne gesehen zu haben: Gott, Schöpfer der Himmel und Erde; Jesus Christus, der am dritten Tag wuchs und aufgefahren in den Himmel; Ich glaube an den Heiligen Geist, in die Auferstehung und das ewige Leben.
<G-vec00092-001-s467><believe.glauben><en> Despite its bitterly cold surface, scientists believe it could possess an underground liquid ocean.
<G-vec00092-001-s467><believe.glauben><de> Trotz seiner bitterkalten Oberfläche, Wissenschaftler glauben, es könnte eine unterirdische Flüssigkeit Ozean besitzen.
<G-vec00092-001-s468><believe.glauben><en> To only take on those clients we believe we can successfully match-we don’t take everyone on as an It’s Just Lunch Client.
<G-vec00092-001-s468><believe.glauben><de> So nehmen Sie nur an den Kunden, die wir glauben, können wir erfolgreich Match-wir nehmen alle nicht als es ist nur Lunch-Client.
<G-vec00092-001-s469><believe.glauben><en> Some of today's masters of Weiqi believe it symbolizes the universe, which is composed of 360 celestial bodies.
<G-vec00092-001-s469><believe.glauben><de> Einige der heutigen Meister des Weiqi glauben, es symbolisiere das Universum, welches aus 360 himmlischen Körpern zusammengesetzt ist.
<G-vec00092-001-s470><believe.glauben><en> Because we believe that consumers should always be sure to get more information from high-quality sites, we have provided some links below that are known to be very useful.
<G-vec00092-001-s470><believe.glauben><de> Da wir glauben, dass die Verbraucher immer sicher, dass zusätzliche Informationen aus, qualitativ hochwertige Websites erhalten, haben wir ein paar Links unter denen bekannt ist, ganz hilfreich sein, zur Verfügung gestellt.
<G-vec00092-001-s471><believe.glauben><en> However, neither you should undergo surgery nor should you opt for hormonal substitute therapies rather believe in the Gynexin for sale.
<G-vec00092-001-s471><believe.glauben><de> Weder sollten Sie operiert werden noch sollten Sie entscheiden sich für Hormonersatztherapien und nicht in der Gynexin glauben, zu verkaufen.
<G-vec00092-001-s472><believe.glauben><en> The simple answer is: Catholics believe Mary remained a virgin throughout her lifetime because it is true .
<G-vec00092-001-s472><believe.glauben><de> Die einfache Antwort ist: Katholiken glauben, Maria eine Jungfrau im Laufe ihres Lebens geblieben, weil es wahr ist.
<G-vec00092-001-s473><believe.glauben><en> He was implying, 'I came not to call those who believe they are righteous'.
<G-vec00092-001-s473><believe.glauben><de> Er meinte eigentlich, 'ich bin nicht gekommen, die zu berufen, die glauben, sie seien gerecht'.
<G-vec00092-001-s474><believe.glauben><en> Researchers at Berkeley Engineering believe they have found a novel way to monitor the brain waves from inside - and then translate the EEG waves into thoughts
<G-vec00092-001-s474><believe.glauben><de> Forscher am Berkeley Engineering glauben, sie haben einen neuen Weg gefunden, um die Gehirnwellen von innen zu überwachen - und dann die EEG-Wellen in Gedanken zu übersetzen.
<G-vec00092-001-s475><believe.glauben><en> First, many religious people just believe what their parents taught them anyway.
<G-vec00092-001-s475><believe.glauben><de> Erstens glauben viele religiöse Menschen ohnehin an das, was ihre Eltern sie gelehrt haben.
<G-vec00092-001-s476><believe.glauben><en> At CloudSigma we believe a happy team means happy customers.
<G-vec00092-001-s476><believe.glauben><de> Bei CloudSigma glauben wir an dem Leitbild „glückliches Team bedeutet zufriedene Kunden“.
<G-vec00092-001-s477><believe.glauben><en> Can you say any name and You believe the word.
<G-vec00092-001-s477><believe.glauben><de> Sagen können einen beliebigen Namen, und Sie glauben an das Wort.
<G-vec00092-001-s478><believe.glauben><en> """We believe that LNG is the fuel of the future,"" is the very clear message from AIDA."
<G-vec00092-001-s478><believe.glauben><de> """Wir glauben an die LNG-Wende"", heißt es sehr deutlich bei AIDA."
<G-vec00092-001-s479><believe.glauben><en> Deep “COMPASSION” with the “perpetrator” and total ACCEPTANCE for the decision of the “victims” are crystalline powers that will lift you and all others out of “fear-love”, “guilt-redemption” and out of the believe in “coincidence, fate and the unaccountable.
<G-vec00092-001-s479><believe.glauben><de> "Das zutiefste MITGEFÜHL mit ""Tätern"" und die zutiefste AKZEPTANZ der Entscheidung des ""Opfers"" sind kristalline Kräfte die dich, und euch alle, aus den Tiefen von ""Angst-Liebe"", ""Schuld-Sühne"" und aus dem Glauben an ""Zufälle, Schicksal und Unvermeidlichkeit"" herausheben, in der Tat."
<G-vec00092-001-s480><believe.glauben><en> 178 We must believe in no one but God: the Father, the Son and the Holy Spirit.
<G-vec00092-001-s480><believe.glauben><de> 178 Wir sollen an niemand anderen glauben als an Gott, den Vater, den Sohn und den Heiligen Geist.
<G-vec00092-001-s481><believe.glauben><en> We believe that our sensor portfolio, including our new BME280, will foster breakthroughs for the Internet of Things and Services.
<G-vec00092-001-s481><believe.glauben><de> Wir glauben, dass unser Angebot an Sensoren, einschließlich des neuen BME280, dem Internet der Dinge und Dienste zu weiteren Durchbrüchen verhelfen wird.
<G-vec00092-001-s482><believe.glauben><en> At Abel we believe... i n the power and beauty of scent. Its ability to enrich daily life in a way nothing else can.
<G-vec00092-001-s482><believe.glauben><de> Bei Abel glauben wir......an die Kraft und Schönheit von Gerüchen und deren Fähigkeit, den Tag auf eine einzigartige Art und Weise zu bereichern.
<G-vec00092-001-s483><believe.glauben><en> If you are to become righteous, confess your sins before God and believe the gospel of the water and the Spirit.
<G-vec00092-001-s483><believe.glauben><de> Wenn Sie rechtschaffen werden wollen, bekennen Sie Ihre Sünden vor Gott und glauben Sie an das Evangelium von Wasser und Geist.
<G-vec00092-001-s484><believe.glauben><en> Believe you can dance.
<G-vec00092-001-s484><believe.glauben><de> Glauben Sie an sich.
<G-vec00092-001-s485><believe.glauben><en> People create for death, not for life.... They are already poor on earth and enter the kingdom of the beyond, which they don't want to believe in on earth, even poorer.... they arrive naked and wretched in the beyond and immeasurable pain and darkness is their fate.
<G-vec00092-001-s485><believe.glauben><de> Die Menschen schaffen für den Tod, nicht für das Leben.... sie sind arm auf Erden schon und gehen noch ärmer in das jenseitige Reich ein, an das sie auf Erden nicht glauben wollten.... sie langen nackt und armselig im Jenseits an, und unermeßliche Qualen und Dunkelheit ist ihr Los.
<G-vec00092-001-s486><believe.glauben><en> Obviously these astute gentlemen believe their own fairy tale, namely, that revisionism is connected with rightwing ideology.
<G-vec00092-001-s486><believe.glauben><de> Offenbar glauben diese Herren selbst an das Märchen, der Revisionismus habe etwas mit rechter politischer Ideologie zu tun.
<G-vec00092-001-s487><believe.glauben><en> "This appears already in the second section, entitled ""A Word of Faith"" and subtitled ""We believe in one God, a good and just God."""
<G-vec00092-001-s487><believe.glauben><de> "Dies taucht schon im zweiten Teil mit dem Titel ""Ein Wort des Glaubens"" und dem Untertitel: "" Wir glauben an Gott, an einen gütigen und gerechten Gott"" auf."
<G-vec00092-001-s488><believe.glauben><en> We believe the Holy Spirit is given to every believer in Jesus as God's promise and seal of salvation.
<G-vec00092-001-s488><believe.glauben><de> Wir glauben an die volle Wirklichkeit der Erlösung durch und in Jesus Christus und auch an die Früchte der Erlösung: die neue Schöpfung und die Fülle des Heiligen Geistes.
<G-vec00092-001-s489><believe.glauben><en> we firmly believe in the use of solar.
<G-vec00092-001-s489><believe.glauben><de> wir glauben fest an die nutzung von solarenergie zur einsparung.
<G-vec00092-001-s490><believe.glauben><en> We believe in ourselves and what we do.
<G-vec00092-001-s490><believe.glauben><de> Wir glauben an uns und an das, was wir tun.
<G-vec00092-001-s491><believe.glauben><en> The person must believe that the behavior was intentionally performed.
<G-vec00092-001-s491><believe.glauben><de> Die Person muss glauben, dass das Verhalten absichtlich an den Tag gelegt wurde.
<G-vec00092-001-s492><believe.glauben><en> For instance, many Reformed Pastafarians believe in Automated Creationism, which is the idea that the FSM sparked the creation of the universe with a single event (the big boil), then let natural processes eventually create life.
<G-vec00092-001-s492><believe.glauben><de> So glauben, zum Beispiel, viele reformierte Pastafair an die automatische Schöpfung, in welcher das FSM die Schöpfung des Universums in einem einzelnem Event ausgelöst hat (das Urkochen) und danach die natürlichen Prozesse alles machen ließ.
<G-vec00092-001-s493><believe.glauben><en> Hard to believe, but there are days when even Mr. Robinson doesn't catch a trout. They are...
<G-vec00092-001-s493><believe.glauben><de> Kaum zu glauben aber es gibt tatsächlich Tage an denen noch nicht mal Ray Robinson eine Forelle...
<G-vec00092-001-s494><believe.glauben><en> We firmly believe that work should be fun.
<G-vec00092-001-s494><believe.glauben><de> Wir glauben nämlich fest daran, dass Arbeit Freude machen soll.
<G-vec00092-001-s495><believe.glauben><en> "And again there are those who regard it as virtue to say: ""Virtue is necessary""; but after all they believe only that policemen are necessary."
<G-vec00092-001-s495><believe.glauben><de> "Und wiederum gibt es Solche, die halten es für Tugend, zu sagen: ""Tugend ist nothwendig''; aber sie glauben im Grunde nur daran, dass Polizei nothwendig ist."
<G-vec00092-001-s496><believe.glauben><en> Sorana Cernea: We strongly believe that the international experience and the comprehensive knowledge of the group's consultants will be of great help in our endeavour to deliver the best solutions to our customers' requests.
<G-vec00092-001-s496><believe.glauben><de> Sorana Cernea: Wir glauben fest daran, dass die internationale Erfahrung und Fachkenntnis der Berater der Gruppe uns eine große Hilfe sein werden, für die Ansprüche unserer Kunden die besten Lösungen anbieten zu können.
<G-vec00092-001-s497><believe.glauben><en> "New York, Eugene O ́neill Theatre THE BOOK OF MORMON Peter Marks of The Washington Post says, ""Don't believe what they say. Money can buy happiness!"
<G-vec00092-001-s497><believe.glauben><de> "New York, Eugene O ́neill Theatre THE BOOK OF MORMON Peter Marks von der The Washington Post schreibt, ""Glauben Sie nicht daran, was Andere sagen."
<G-vec00092-001-s498><believe.glauben><en> We firmly believe that philosophy clothing perfection pursuit and customer letter on the quality assurance.
<G-vec00092-001-s498><believe.glauben><de> Wir glauben fest daran, dass Philosophie Kleidung Perfektion Streben und Kundenbrief auf die Qualitätssicherung.
<G-vec00092-001-s499><believe.glauben><en> Some researchers in business and companies believe that machines will someday act empathically.
<G-vec00092-001-s499><believe.glauben><de> Einige Forscher in Wissenschaft und Unternehmen glauben daran, dass Maschinen irgendwann empathisch handeln werden.
<G-vec00092-001-s500><believe.glauben><en> Press Poetry Events We believe that Poetry can make a better world.
<G-vec00092-001-s500><believe.glauben><de> Presse Poetry Events Wir glauben daran, dass Poetry die Welt verbessern kann.
<G-vec00092-001-s501><believe.glauben><en> We truly believe that working together we can turn challenges into opportunities, allowing us to always push boundaries to make business and the world better.
<G-vec00092-001-s501><believe.glauben><de> Wir glauben fest daran, dass die Zusammenarbeit aus Herausforderungen Möglichkeiten machen kann, mit denen wir die Grenzen weiter verschieben und das Geschäftsleben und die Welt ein Stückchen besser machen können.
<G-vec00092-001-s502><believe.glauben><en> We firmly believe that the criminals who are directly responsible for the persecution of Falun Gong in Mainland China will be brought to justice soon.
<G-vec00092-001-s502><believe.glauben><de> Wir glauben fest daran, daß die Kriminellen, welche direkt für die Verfolgung von Falun Gong in China verantwortlich sind, bald vor Gericht gestellt werden.
<G-vec00092-001-s503><believe.glauben><en> The Levites of that ancient time did not, and today's Zionists do not believe that the Israelites “vanished without leaving a trace” (as Dr. Kastein says).
<G-vec00092-001-s503><believe.glauben><de> Weder die Leviten des Altertums noch die heutigen Zionisten glauben ernsthaft daran, dass die Israeliten „spurlos verschwunden sind“ (auch diese Formulierung stammt von Dr. Kastein).
<G-vec00092-001-s504><believe.glauben><en> We believe that we have to go back to the most sincere original roots.
<G-vec00092-001-s504><believe.glauben><de> Wir glauben daran, dass man zu den ehrlichsten Grundlagen zurückkehren soll.
<G-vec00092-001-s505><believe.glauben><en> We deeply believe that every single client is participating in an important role for our business success.
<G-vec00092-001-s505><believe.glauben><de> Wir glauben fest daran, dass jeder einzelne Kunde ein wichtige Rolle bei unserem Geschäftserfolg spielt.
<G-vec00092-001-s506><believe.glauben><en> There is no perfect human work, but we believe in it, and if we did not believe in it, we would not be doing what we are doing, or what you are doing in such a noble manner.
<G-vec00092-001-s506><believe.glauben><de> Es gibt kein perfektes menschliches Werk, aber wir glauben daran, wenn wir das nicht glauben würden, dann würden wir heute nicht tun, was wir tun, und auch Sie würden nichts so Bemerkenswertes tun, wie es der Fall ist.
<G-vec00092-001-s507><believe.glauben><en> "Even some Christians don’t believe it."""
<G-vec00092-001-s507><believe.glauben><de> "Selbst einige Christen glauben nicht daran'""."
<G-vec00092-001-s508><believe.glauben><en> We believe that the God who created the universe is capable of writing a book.
<G-vec00092-001-s508><believe.glauben><de> Wir glauben daran, dass Gott, der das Universum geschaffen hat, auch fähig ist, ein Buch zu schreiben.
<G-vec00092-001-s509><believe.glauben><en> We believe that only the best people will create the best products and drive a company to success.
<G-vec00092-001-s509><believe.glauben><de> Wir glauben daran, dass nur die besten Talente die besten Produkte kreieren und so ein Unternehmen zum Erfolg führen.
<G-vec00092-001-s510><believe.glauben><en> We believe that a world of peace is possible.
<G-vec00092-001-s510><believe.glauben><de> Wir glauben daran, dass eine friedliche Welt möglich ist.
<G-vec00092-001-s511><believe.glauben><en> We believe that the concept of visual identification applied by LIDEX is appreciated by our Customers and encourages them to work with the LIDEX Graphics & Film Studio.
<G-vec00092-001-s511><believe.glauben><de> Wir glauben daran, dass das Konzept der visuellen Identifikation von LIDEX Ihnen gefallen wird und dass Sie sich in unseren Büros wohl und komfortabel fühlen werden, was Sie zur Zusammenarbeit mit unserem Grafik- und Filmstudio überzeugen wird.
<G-vec00092-001-s512><believe.glauben><en> We believe that the services provided with energetic work-flow, accurate counselling and enduring enthusiasm would serve as advantage for our clients.
<G-vec00092-001-s512><believe.glauben><de> Wir glauben daran dass unsere durch energische Arbeit, präzise Rechtsräte und ausdauernde Begeisterung gebotene Services dient unserer Mandante zum Nutzen.
<G-vec00092-001-s513><believe.glauben><en> Conversely to this, we believe as the commercial airline offering continues to experience over-demand, so the need for charter will increase, and with that increased understanding of the benefits that a broker can bring to a complex market.
<G-vec00092-001-s513><believe.glauben><de> Wir glauben auch, dass durch die Monopolisierung auf bestimmten Routen, die Preise so ansteigen werden, dass der Charterbedarf vor allem auf dicht beflogen Linien-Flugstrecken weiter steigen wird und somit die Erkenntnis der Vorteile der Zusammenarbeit mit einem Charterbroker in diesem komplexen Markt immer deutlicher werden.
<G-vec00092-001-s514><believe.glauben><en> Extension Activity: The extension activity for this lesson will require students to determine whether they believe primary or secondary sources are the stronger option for historians to use when studying the past.
<G-vec00092-001-s514><believe.glauben><de> Erweiterung Aktivität: Die Erweiterungsaktivität für diese Lektion erfordert, dass die Schüler bestimmen, ob sie glauben, dass primäre oder sekundäre Quellen die stärkere Option für Historiker sind, die beim Studieren der Vergangenheit verwendet werden sollen.
<G-vec00092-001-s515><believe.glauben><en> There are still many fans who believe Alan left the band because of Fletch.
<G-vec00092-001-s515><believe.glauben><de> Es gibt immer noch viele Fans, die glauben, dass Alan die Band wegen Fletch verließ.
<G-vec00092-001-s516><believe.glauben><en> """Naw."" ""They believe the bread and wine actually are the body and blood."
<G-vec00092-001-s516><believe.glauben><de> »Nein.« »Sie glauben, dass Brot und Wein wirklich das Fleisch und das Blut Jesu sind.
<G-vec00092-001-s517><believe.glauben><en> We believe this will help customers feel a lot more confident migrating capacity than before.
<G-vec00092-001-s517><believe.glauben><de> Wir glauben, dass sich unsere Kunden dadurch beim Migrieren von Kapazitäten viel sicherer fühlen werden als zuvor.
<G-vec00092-001-s518><believe.glauben><en> At the same time, 47% of all respondents believe they are late to implement changes, and 41% believe they are behind their competitors.
<G-vec00092-001-s518><believe.glauben><de> Gleichzeitig glauben 47 Prozent aller Befragten, dass sie mit ihren Änderungen spät dran sind, und 41 Prozent, dass sie im Vergleich zu ihrer Konkurrenz im Rückstand sind.
<G-vec00092-001-s519><believe.glauben><en> M-KATE is normally based in Moscow or Switzerland, but made numerous flights all over the US from August 2016 through November 2016, the peak season for last year's presidential campaign – right at the moment when American intelligence agencies believe Moscow was supposedly hijacking the election on Trump's behalf (No proof).
<G-vec00092-001-s519><believe.glauben><de> M-KATE ist in der Regel in Moskau oder der Schweiz geparkt, hat aber in den USA von August 2016 bis November 2016, der Hauptsaison der Präsidentschaftskampagne des Vorjahres, zahlreiche Flüge in die USA unternommen – gerade dann, als die amerikanischen Geheimdienste glauben, dass Moskau die Wahl zugunsten von Trump manipulierte (keine Beweise) .
<G-vec00092-001-s520><believe.glauben><en> We believe we have made progress in this area as well.
<G-vec00092-001-s520><believe.glauben><de> Wir glauben, dass wir auch in diesem Bereich einen Fortschritt erzielt haben.
<G-vec00092-001-s521><believe.glauben><en> The famous sculpture of the Sleeping Lady, arguably the most popular exhibit, depicts a rather corpulent woman resting on her side, who some believe to represent a culture of female divinity.
<G-vec00092-001-s521><believe.glauben><de> "Die berühmte Skulptur der ""Schlafenden Dame"", wohl das bekannteste Ausstellungsstück, stellt eine ziemlich korpulente Frau dar, die auf der Seite liegt und von der einige glauben, dass sie die weibliche Gottheit repräsentiert."
<G-vec00092-001-s522><believe.glauben><en> Since Samuelson’s “Economics” textbook has sold over four million copies since its introduction in 1948, countless economists have been conditioned to think that only simple-minded people, such as those one might find in factories or coal mines, could possibly believe the shorter-workweek argument.
<G-vec00092-001-s522><believe.glauben><de> "Seit Samuelson's ""Economics"" Lehrbuch verfügt über mehr als vier Millionen Mal seit seiner Einführung im Jahr 1948 verkauft wurden zahlreiche Ökonomen konditioniert zu glauben, dass nur einfältigen Menschen, wie könnte man in Fabriken oder Bergwerke zu finden, könnte glauben, dass die kürzere Arbeitswoche Argument."
<G-vec00092-001-s523><believe.glauben><en> Visitors sympathised with the victims of the persecution and said it was hard to believe this persecution exists today.
<G-vec00092-001-s523><believe.glauben><de> Die Besucher sympathisierten mit den Opfern der Verfolgung und sagten, es sei schwer zu glauben, dass diese Verfolgung heutzutage noch existiere.
<G-vec00092-001-s524><believe.glauben><en> People with IAD can have mild or no symptoms whatsoever, yet still believe themselves to have a serious or life-threatening illness.
<G-vec00092-001-s524><believe.glauben><de> Hypochondrische Patienten werden entweder schwache oder überhaupt keine Symptome aufweisen und dennoch glauben, dass sie an einer ernsten, lebensgefährlichen Krankheit leiden.
<G-vec00092-001-s525><believe.glauben><en> It’s hard to believe it can take just 15 minutes to descend more than 500 vertical metres.
<G-vec00092-001-s525><believe.glauben><de> Kaum zu glauben, dass man in 15 Minuten über 500 Höhenmeter hinunter gefahren ist.
<G-vec00092-001-s526><believe.glauben><en> We believe trustworthiness is the key to a successful business.
<G-vec00092-001-s526><believe.glauben><de> Wir glauben, dass Vertrauenswürdigkeit der Schlüssel zu einem erfolgreichen Geschäft ist.
<G-vec00092-001-s527><believe.glauben><en> And we believe we have a key role in helping to achieve this vision.
<G-vec00092-001-s527><believe.glauben><de> Und wir glauben, dass uns eine wichtige Rolle bei der Umsetzung dieser Vision zukommt.
<G-vec00092-001-s528><believe.glauben><en> You can object to any processing of your personal data which has our 'Legitimate Interests' as its legal basis (see Appendix 2 for further details), if you believe your fundamental rights and freedoms outweigh our Legitimate Interests.
<G-vec00092-001-s528><believe.glauben><de> Sie können gegen jegliche Verarbeitung Ihrer personenbezogenen Daten Widerspruch einlegen, die auf unserer berechtigten Interesses als Rechtsgrundlage erfolgt (Siehe Anhang 2 für Genaueres), wenn Sie glauben, dass Ihre Grundrechte und Freiheiten Vorrang vor unseren berechtigten Interessen haben.
<G-vec00092-001-s529><believe.glauben><en> We believe we need to create spaces in which people feel comfortable and at home, in which they can relax.
<G-vec00092-001-s529><believe.glauben><de> Wir glauben, dass wir Räume schaffen sollten, in denen sich die Menschen wohl und zuhause fühlen, in denen sie entspannen können.
<G-vec00092-001-s530><believe.glauben><en> "Comment In ""The Final Warning"", David Allen Rivera does his utmost to have us believe the Protocols are a fake to make Jews ""look bad""."
<G-vec00092-001-s530><believe.glauben><de> "Kommentar In ""The Final Warning"", macht David Allen Rivera sein Äußerstes, um uns glauben zu lassen, dass die Protokolle eine Fälschung seien, um Juden ""schlecht aussehen"" zu lasen."
<G-vec00092-001-s531><believe.glauben><en> If you believe your computer has been compromised, stop using it immediately and contact an expert as soon as possible. If you are at a live poker tournament, please notify hotel security.
<G-vec00092-001-s531><believe.glauben><de> Wenn Sie glauben, dass sich jemand unberechtigten Zugang zu Ihrem Computer verschafft hat, sollten Sie sofort aufhören, ihn zu benutzen und schnellstmöglich einen Fachmann hinzuziehen.
<G-vec00092-001-s533><believe.glauben><en> In fact, most folks believe Internet Explorer is the only option for reaching the Internet.
<G-vec00092-001-s533><believe.glauben><de> Tatsächlich glauben die meisten Völker, daß Internet Explorer die einzige Wahl für das Erreichen des Internets ist.
<G-vec00092-001-s534><believe.glauben><en> Equally obviously many people believe they are victims of a heart attack when it is Acid Reflux Disease, and sadly for some, they believe they have Acid reflux, when in fact they are suffering a heart attack, SO IF YOU ARE IN ANY DOUBT VISIT YOUR DOCTOR OR HOSPITAL IMMEDIATELY.
<G-vec00092-001-s534><believe.glauben><de> Gleichmäßig offensichtlich glauben viele Leute, sie Opfer eines Herzangriffs sind, wenn es saure Rückfluss-Krankheit ist, und traurig für einiges, glauben sie, daß sie sauren Rückfluß haben, wenn tatsächlich sie einen Herzangriff erleiden, ALSO WENN SIE IN IRGENDEINEM ZWEIFEL BESUCH IHR DOKTOR ODER KRANKENHAUS SOFORT SIND.
<G-vec00092-001-s535><believe.glauben><en> FBI AGENT: Based on the amalgam of forensic detail, facts such as time and place the murders were committed and the amount of force used, we believe the killer is a man in his mid-20's to late 40's, of average build and looks, who is driven by a rage stemming from a hatred of his mother from a very early age.
<G-vec00092-001-s535><believe.glauben><de> SPECIAL AGENT FORDYCE: Basierend auf den Ergebnissen aus der Gerichtsmedizin und den Daten wie Zeit und Ort der Morde und des Krafteinsatzes, glauben wir, daß der Mann Mitte 20 bis Ende 40 ist, von durchschnittlich Gestalt, getrieben vom ständiger Wut durch den Haß seiner Mutter in frühster Kindheit.
<G-vec00092-001-s536><believe.glauben><en> Does that mean pain or pleasure, and if it means pain, how can I avoid it.You might not believe me as it sounds too simple.
<G-vec00092-001-s536><believe.glauben><de> Tut diese Mittelschmerz oder Vergnügen und wenn es die Schmerz bedeutet, wie kann ich ihn vermeiden.Sie konnten nicht glauben, daß ich als er zu einfach klinge.
<G-vec00092-001-s537><believe.glauben><en> Today it does not suffice just to believe in the Christ; it is essential that men should now manifest the Christ in their deeds, in their work.
<G-vec00092-001-s537><believe.glauben><de> Es genügt heute nicht, daß die Menschen an den Christus glauben, sondern es ist heute notwendig, daß die Menschen den Christus in ihrem Handeln, in ihrem Wirken verwirklichen.
<G-vec00092-001-s538><believe.glauben><en> I have a feeling someone of the Christian faith would not believe such a place exists.
<G-vec00092-001-s538><believe.glauben><de> Ich habe ein Gefühl, daß irgend jemand eines christlichen Glaubens nicht glauben würde, daß ein solcher Ort existiert.
<G-vec00092-001-s539><believe.glauben><en> Disasters such as these are Allah’s warning to those who do not believe to not focus only on this world.
<G-vec00092-001-s539><believe.glauben><de> Katastrophen wie diese sind auch Allahs Warnung an all jene, die nicht glauben, daß sie sich nicht nur auf diese Welt konzentrieren.
<G-vec00092-001-s540><believe.glauben><en> While most whites profess to be free of racial prejudice, blacks often believe they are failing to disclose their true feelings.
<G-vec00092-001-s540><believe.glauben><de> Während das meiste Weiß erklärt, vom rassischen Vorurteil frei zu sein, glauben Schwarze häufig, daß sie ihre zutreffenden Gefühle freigeben nicht können.
<G-vec00092-001-s541><believe.glauben><en> "MY people ""I AM"" is instructing the RUACH ha KODESH to have those who believe ""I AM"" is a GOD that does not change and remains the same and will protect all that say what is MINE is thine, what is thine is MINE. Just don't bow to another god, Israel!"
<G-vec00092-001-s541><believe.glauben><de> "Mein Volk, ""ICH BIN"" unterweist den RUACH ha KODESH: Sage denen, die glauben, daß ""ICH BIN"" ein unwandelbarer Gott ist und der Gleiche bleibt und alle schützen wird, die sagen, was MEIN ist, ist dein, und was dein ist, ist MEIN: Verneigt euch nicht vor einem anderen Gott, Israel."
<G-vec00092-001-s542><believe.glauben><en> We clung to the vision of past greatness, and would not believe it could come to nought; but the Church in England has died, and the Church lives again.
<G-vec00092-001-s542><believe.glauben><de> Wir klammerten uns an das Bild vergangener Größe und wollten nicht glauben, daß es zunichte werden konnte; aber die Kirche in England ist ge­storben – und diese Kirche lebt wieder.
<G-vec00092-001-s543><believe.glauben><en> I still can't believe it but know it did.
<G-vec00092-001-s543><believe.glauben><de> Ich kann es immer noch nicht glauben, aber weiß, daß es geschah.
<G-vec00092-001-s544><believe.glauben><en> We believe the only real change that happens in the world occurs when people's hearts change.
<G-vec00092-001-s544><believe.glauben><de> Wir glauben, daß der einzige wahre Wandel in der Welt dann geschieht, wenn sich das Herz der Menschen ändert.
<G-vec00092-001-s545><believe.glauben><en> The only demand we make is that you, too, believe Islamization is harmful to our country and the rest of Europe.
<G-vec00092-001-s545><believe.glauben><de> Die einzige Forderung, die wir stellen, ist, daß Sie ebenfalls glauben, daß die Islamisierung schädlich für unser Land und den Rest Europas ist.
<G-vec00092-001-s546><believe.glauben><en> 2007-11-13 22:16:19 - Atkins diet - learn more The Atkins diet can be boring because of the limited choice and some believe it can be dangerous.
<G-vec00092-001-s546><believe.glauben><de> 2007-11-13 22:16:19 - Atkins Diät - Erlernen Sie Mehr Die Atkins Diät kann wegen der begrenzten Wahl bohren und einige glauben, daß es gefährlich sein kann.
<G-vec00092-001-s547><believe.glauben><en> And believe it or not they are more tender and delicious than the normal little ones.
<G-vec00092-001-s547><believe.glauben><de> Und glauben, daß er oder nicht sie zarter und köstlich als das normal wenig eine sind.
<G-vec00092-001-s548><believe.glauben><en> We used the above title, because it consists of the saying of George Lesier himself, while expressing his pain for his countrymen, himself being French, and because we believe this publication would also help those who have yet to know and taste the Grace of the Holy Spirit.
<G-vec00092-001-s548><believe.glauben><de> Wir wählen den obengenannten Titel, weil es sich um einen Ausspruch George Lesiers selbst handelt, mit dem er seinen Schmerz um seine Landsleute zum Ausdruck brachte - er selbst war Franzose - und weil wir glauben, daß diese Veröffentlichung auch denjenigen helfen möge, die die Gnade des Heiligen Geistes noch nicht kennengelernt und gekostet haben.
<G-vec00092-001-s549><believe.glauben><en> As I was under general anesthetic many believe your true psychic self is repressed and that is why I can't remember much more.
<G-vec00092-001-s549><believe.glauben><de> Viele glauben daß, als ich unter Vollnarkose war, dein wahres Ich verdrängt wird und darum kann ich mich nicht an mehr erinnern.
<G-vec00092-001-s550><believe.glauben><en> With a bold analogy, which we decline to believe was extorted by [the] judges . . ., Israel Wolfgang maintained that even the Biblical prohibition against human blood was absolute for Jews, and rigid when it involved blood extracted from the veins of Jews, but was permitted and even recommended when originating from the body of Christians, or Christian children in particular.
<G-vec00092-001-s550><believe.glauben><de> In einer kühnen Analogie, von der wir uns zu glauben weigern, daß sie von den Richtern erzwungen wurde..., behauptete Israel Wolfgang, daß sogar das biblische Verbot von Menschenblut für Juden absolut war, und unnachgiebig, wenn es Blut war, das den Adern von Juden entnommen war, aber erlaubt und sogar empfohlen war, wenn es aus dem Körper von Christen oder insbesondere christlichen Kindern stammte.
<G-vec00092-001-s551><believe.glauben><en> And therefore I call to you time and again: Believe that you are shortly facing the end.
<G-vec00092-001-s551><believe.glauben><de> Und immer wieder rufe Ich euch daher zu: Glaubet es, daß ihr kurz vor dem Ende steht.
<G-vec00092-001-s552><believe.glauben><en> And although I again and again present this hour to you – it goes past your ears without impression; you do not believe it.
<G-vec00092-001-s552><believe.glauben><de> Und ob Ich auch immer wieder euch diese Stunde vorstelle - es geht ohne Eindruck an euren Ohren vorüber, ihr glaubet es nicht.
<G-vec00092-001-s553><believe.glauben><en> And that is why you are not allowed to doubt at it that you have to fulfil a mission, and if you believe, you will also be eagerly active and miss no opportunity to work for God and his kingdom wherever it is just possible.
<G-vec00092-001-s553><believe.glauben><de> Und darum dürfet ihr nicht zweifeln daran, daß ihr eine Mission zu erfüllen habt, und so ihr glaubet, werdet ihr auch eifrig tätig sein und keine Gelegenheit versäumen, für Gott und Sein Reich zu wirken, wo immer es nur möglich ist.
<G-vec00092-001-s554><believe.glauben><en> And he who saw it bears witness, and his witness is true, and he knows that he says true that ye also may believe.
<G-vec00092-001-s554><believe.glauben><de> Und der das gesehen hat, der hat es bezeugt, und sein Zeugnis ist wahr; und dieser weiß, daß er die Wahrheit sagt, auf daß auch ihr glaubet.
<G-vec00092-001-s555><believe.glauben><en> Beloved, believe not every Spirit, but try the Spirits whether they are of God; because many false Prophets are gone out into the world.
<G-vec00092-001-s555><believe.glauben><de> """Geliebte, glaubet nicht jedem Geist, sondern prüfet die Geister, ob sie von Gott stammen; denn viele falsche Propheten sind in die Welt ausgegangen."
<G-vec00092-001-s556><believe.glauben><en> But do not believe that I am there where satisfaction is given to just the outer form – where you close your ear to my word, which reaches you from above, because he who does not listen to my word he also does not listen to myself; who refuses my word he refuses myself, and his soul will remain without food.
<G-vec00092-001-s556><believe.glauben><de> Aber glaubet nicht, daß Ich dort bin, wo nur der äußeren Form Genüge getan wird - wo ihr euer Ohr verschließet Meinem Wort, das euch aus der Höhe zugeht, denn wer Mein Wort nicht anhöret, der höret auch Mich Selbst nicht an; wer Mein Wort zurückweiset, der weiset Mich Selbst zurück, und seine Seele wird ohne Nahrung bleiben.
<G-vec00092-001-s557><believe.glauben><en> Believe it that no work is done in vain, which you carry out for me and my kingdom.
<G-vec00092-001-s557><believe.glauben><de> Glaubet es, daß keine Arbeit umsonst geleistet ist, die ihr ausführt für Mich und Mein Reich.
<G-vec00092-001-s558><believe.glauben><en> But these are written so that you may believe that Jesus is the Christ, the Son of God, and that by believing you may have life in his name (John 20:31).
<G-vec00092-001-s558><believe.glauben><de> Diese aber sind aufgeschrieben worden, damit ihr glaubet, dass Jesus der Christus ist, der Sohn Gottes, und dass ihr durch den Glauben in seinem Namen Leben habt (Johannes 20:31).
<G-vec00092-001-s559><believe.glauben><en> 35 And he who saw it (the eyewitness) gives this evidence, and his testimony is true; and he knows that he tells the truth, that you may believe also.
<G-vec00092-001-s559><believe.glauben><de> 35Und der das gesehen hat, der hat es bezeugt, und sein Zeugnis ist wahr, und er weiß, daß er die Wahrheit sagt, auf daß auch ihr glaubet.
<G-vec00092-001-s560><believe.glauben><en> and because I speak the truth, ye do not believe me.
<G-vec00092-001-s560><believe.glauben><de> Ich aber, weil ich die Wahrheit sage, so glaubet ihr mir nicht.
<G-vec00092-001-s561><believe.glauben><en> And no matter if I also speak through the mouth of awakened servants to you – you do not believe – that the end is near and with it the last judgement.
<G-vec00092-001-s561><believe.glauben><de> Und ob Ich auch durch den Mund erweckter Diener zu euch rede - ihr glaubet nicht - daß das Ende nahe ist und mit diesem das letzte Gericht.
<G-vec00092-001-s562><believe.glauben><en> You should believe that soon will come to pass what I already predicted long ago; you should believe that there is not much time left and no longer worry how to gain earthly profits, for this worry is futile, as you will very soon realise.
<G-vec00092-001-s562><believe.glauben><de> Glaubet es, daß sich bald erfüllet, was Ich schon lange euch vorausgesagt habe; glaubet es, daß nicht mehr viel Zeit ist, und sorget euch nicht mehr, wie ihr irdische Vorteile erringen könnet, denn diese Sorge ist unnütz, was ihr sehr bald erkennen werdet.
<G-vec00092-001-s564><believe.glauben><en> 13:19 Now I tell you before it come, that, when it is come to pass, ye may believe that I am he.
<G-vec00092-001-s564><believe.glauben><de> 13:19 Jetzt sage ich es euch, ehe es geschieht, damit, wenn es geschehen ist, ihr glaubet, daß ich es bin.
<G-vec00092-001-s565><believe.glauben><en> I always stay spiritually among you but your love can also cause me to approach you visibly and you prove to me your love that you believe in me.
<G-vec00092-001-s565><believe.glauben><de> Ich weile geistig zwar immer unter euch, doch eure Liebe kann Mich auch veranlassen, Mich euch sichtbar zu nahen, und eure Liebe beweiset ihr Mir, daß ihr an Mich glaubet.
<G-vec00092-001-s566><believe.glauben><en> 24 Therefore I say unto you, What things soever ye desire, when ye pray, believe that ye receive them, and ye shall have them.
<G-vec00092-001-s566><believe.glauben><de> 24 Darum sage ich euch:Alles, was ihr bittet in eurem Gebet, glaubet nur, daß ihr's empfangen werdet, so wird's euch werden.
<G-vec00092-001-s567><believe.glauben><en> Therefore: Do not believe every spirit.... and scrutinise it by taking notice of the gleam of light, of its intensity of light.... Because God is light.... what comes forth from God is light.... and therefore divine gifts of spirit categorically have to leave an effect of radiant light, otherwise they are Satan’s works of deception, which he will particularly use during the last days with the intention of dazzling people’s eyes as well as their souls in order to plunge them into even greater darkness and render them unable to recognise the true light....
<G-vec00092-001-s567><believe.glauben><de> Darum: Glaubet nicht jedem Geist.... und prüfet, indem ihr den Lichtschein beachtet, in welcher Stärke er aufleuchtet.... Denn Gott ist Licht.... was von Gott ausgeht, ist Licht.... und so müssen die göttlichen Geistesgaben unbedingt strahlendes Licht hinterlassen, ansonsten es Blendwerke des Satans sind, mit denen er besonders in der Endzeit die Augen der Menschen sowie deren Seelen blenden will, auf daß sie in noch größere Finsternis stürzen und unfähig sind, das rechte Licht zu erkennen....
<G-vec00092-001-s568><believe.glauben><en> Believe Me that I still have to correct many misconceptions if you are to live in truth and defend it.
<G-vec00092-001-s568><believe.glauben><de> Glaubet es Mir, daß Ich noch viele Irrtümer berichtigen muss, sollet ihr euch in der Wahrheit bewegen und auch für diese eintreten.
<G-vec00092-001-s569><believe.glauben><en> You humans, consider how presumptuous you are when you correct ‘the Word of God’, when you believe that you can offer more easily digestible nourishment to people by making changes to it which you are truly not entitled to do....
<G-vec00092-001-s569><believe.glauben><de> Bedenket doch, ihr Menschen, was ihr euch anmaßet, wenn ihr das „Wort Gottes“ korrigiert, wenn ihr glaubet, den Menschen eine besser verdauliche Speise darbieten zu können, indem ihr Änderungen daran vornehmet, wozu ihr wahrlich nicht berechtigt seid....
<G-vec00092-001-s570><believe.glauben><en> What I hope to achieve is to make you, the reader, think about what you believe and why.
<G-vec00092-001-s570><believe.glauben><de> Was ich zu erreichen hoffe, ist dich, den Leser, darüber zum Nachdenken zu bringen, was du glaubst und warum.
<G-vec00092-001-s571><believe.glauben><en> Tell the person who is afflicted that you have read and heard that a lot of children and teenagers are victims of abuse and violence and that you believe what they are telling you.
<G-vec00092-001-s571><believe.glauben><de> Sage Betroffenen, dass du gelesen oder gehört hast, dass es viele von Missbrauch und Gewalt betroffene Kinder und Jugendliche gibt, und du glaubst was dir erzählt worden ist.
<G-vec00092-001-s572><believe.glauben><en> And when those ideas are commonly agreed upon as being completely socially unacceptable, you will have to pay a very high price for standing up for something that you don't believe in at all.
<G-vec00092-001-s572><believe.glauben><de> Und wenn es sich dabei um Überzeugungen handelt, die allgemein als sozial inakzeptabel angesehen werden, dann musst Du einen verdammt hohen Preis dafür bezahlen, dass Du angeblich für etwas stehst, an das Du aber in Wirklichkeit keinen Meter glaubst.
<G-vec00092-001-s573><believe.glauben><en> "If you declare with your mouth, ""Jesus is Lord,"" and believe in your heart that God raised him from the dead, you will be saved."
<G-vec00092-001-s573><believe.glauben><de> Denn wenn du mit deinem Munde bekennst, dass Jesus der Herr ist, und glaubst in deinem Herzen, dass ihn Gott von den Toten auferweckt hat, so wirst du gerettet.
<G-vec00092-001-s574><believe.glauben><en> Even if you don´t believe it, if you learned and understand everything from the lessons up to here, then you are a programmer already, you know everything you need to write ANY kind of program.
<G-vec00092-001-s574><believe.glauben><de> Auch wenn du es nicht glaubst, wenn du aus den Lektionen bis hier alles gelernt und verstanden hast, dann bist du schon ein Programmierer, du weißt alles was man wissen muss um jedes beliebige Programm zu schreiben.
<G-vec00092-001-s575><believe.glauben><en> "{TR adds ""Philip said, 'If you believe with all your heart, you may.'"
<G-vec00092-001-s575><believe.glauben><de> Philippus aber sprach: Glaubst du von ganzem Herzen, so mag's wohl sein.
<G-vec00092-001-s576><believe.glauben><en> If you believe in the CCP and Jesus, you aren't devoted.
<G-vec00092-001-s576><believe.glauben><de> Wenn du an die KPCh und Jesus glaubst, bist du nicht ergeben.
<G-vec00092-001-s577><believe.glauben><en> But that is because you believe in anger and hurt and all those other things that consume your attention. Switch your attention.
<G-vec00092-001-s577><believe.glauben><de> Indessen dies deswegen - weil du an Ärger, Verletzung und alle jene anderen Dinge glaubst, die deine Aufmerksamkeit aufbrauchen.
<G-vec00092-001-s578><believe.glauben><en> What do you believe about the reality of your experience now?
<G-vec00092-001-s578><believe.glauben><de> Was glaubst du über die Realität deiner Erfahrung zum heutigen Zeitpunkt: Die Erfahrung war definitiv real.
<G-vec00092-001-s579><believe.glauben><en> “You might even believe it.
<G-vec00092-001-s579><believe.glauben><de> „Du glaubst das womöglich.
<G-vec00092-001-s580><believe.glauben><en> You better believe it.
<G-vec00092-001-s580><believe.glauben><de> Du glaubst es besser.
<G-vec00092-001-s581><believe.glauben><en> After all these years, these guys still do it together and whether you believe it or not, more intensively than usual.
<G-vec00092-001-s581><believe.glauben><de> Mehr Infos Nach all den Jahren treiben es diese Jungs immer noch zusammen und ob Du es glaubst oder nicht, intensiver als sonst schon.
<G-vec00092-001-s582><believe.glauben><en> Simply be sincere but make sure that you believe in what you're saying first and you will find that people come alive because they can't debate or argue when it truly comes from the heart.
<G-vec00092-001-s582><believe.glauben><de> Sei einfach aufrichtig, aber stell sicher, dass du das was du sagt zuerst selbst glaubst und du wirst herausfinden, wie Menschen lebendig werden, wenn sie nicht mehr debattieren oder streiten können, wenn es wirklich von Herzen kommt.
<G-vec00092-001-s583><believe.glauben><en> It is not flattering yourself to believe that I am yours; it is acknowledging truth.
<G-vec00092-001-s583><believe.glauben><de> Es ist kein dich Umschmeicheln, damit du glaubst, Ich sei dein; es ist Bestärken der Wahrheit.
<G-vec00092-001-s584><believe.glauben><en> It's just like brain-washing, as I say, when you start to admit to things you never did, you see, under torture, until you actually start to believe it, you're going through the same process.
<G-vec00092-001-s584><believe.glauben><de> Das ist genau wie Gehirnwaesche, wie schon gesagt, wenn du unter Folter anfaengst Dinge einzugestehen, die du nicht getan hast, und es schließlich selber glaubst, dann ist das der selbe Prozess.
<G-vec00092-001-s585><believe.glauben><en> Whether you believe in your worth or not, get up and dance.
<G-vec00092-001-s585><believe.glauben><de> Ob du nun an deine Wertigkeit glaubst oder nicht, stehe auf und tanze.
<G-vec00092-001-s586><believe.glauben><en> 'As long as you believe in a living God, you must have hope'.
<G-vec00092-001-s586><believe.glauben><de> ‘Solange du an einen lebendigen Gott glaubst, musst du hoffen’.
<G-vec00092-001-s588><believe.glauben><en> What did you believe about the reality of your experience shortly (days to weeks) after it happened? Experience was definitely real
<G-vec00092-001-s588><believe.glauben><de> Was glaubst du über die Realität deiner Erfahrung kurz nach dem sie geschah (Tage zu Wochen): Die Erfahrung war definitiv wahr.
<G-vec00092-001-s589><believe.glauben><en> Jesus prayed to the heavenly Father for all believers to be one “so that the world may believe” (John 17:21).
<G-vec00092-001-s589><believe.glauben><de> Jesus betete zum Vater im Himmel, damit die Gläubigen alle eins seien, “damit die Welt glaubt” (Joh 17,21).
<G-vec00092-001-s590><believe.glauben><en> Nobody who does not believe all His Word can please Him.
<G-vec00092-001-s590><believe.glauben><de> Niemand der nicht all Seinem Wort glaubt kann Ihm gefallen.
<G-vec00092-001-s591><believe.glauben><en> In an interview with the magazine RFID im Blick, he explains that it is wrong for users to believe that RFID will solve all problems.
<G-vec00092-001-s591><believe.glauben><de> In einem Interview der Zeitschrift „RFID im Blick“ sagte er, es sei ein Trugschluss, wenn der Anwender glaubt, dass RFID alleine das Problem löst.
<G-vec00092-001-s592><believe.glauben><en> If we believe that Christ died in our place and paid the price of our own sins, and rose again, then we are saved.
<G-vec00092-001-s592><believe.glauben><de> Wenn jemand glaubt, dass Christus an seiner Statt starb und den Preis für seine Sünden bezahlte und wieder auferstand, dann ist dieser Mensch errettet.
<G-vec00092-001-s593><believe.glauben><en> 103:8.4If you truly believe in Godˆ — by faithˆ know him and love him — do not permit the reality of such an experience to be in any way lessened or detracted from by the doubting insinuations of science, the caviling of logic, the postulates of philosophy, or the clever suggestions of well-meaning souls who would create a religion without Godˆ.
<G-vec00092-001-s593><believe.glauben><de> 103:8.4 (1140.4) Wenn ihr wahrhaft an Gott glaubt — ihn aufgrund eures Glaubens kennt und liebt — dann lasst nicht zu, dass die Realität einer solchen Erfahrung in irgendeiner Weise geschmälert oder herabgesetzt werde durch zweifelnde Andeutungen der Wissenschaft, Nörgeleien der Logik, Postulate der Philosophie oder geschickte Beeinflussungen wohlmeinender Seelen, die eine Religion ohne Gott schaffen möchten.
<G-vec00092-001-s594><believe.glauben><en> People will take me seriously, believe me and will also be prepared to do something for me.
<G-vec00092-001-s594><believe.glauben><de> Man nimmt mich ernst, glaubt mir und ist auch bereit, für mich etwas zu tun.
<G-vec00092-001-s595><believe.glauben><en> But who will believe this if he is informed of it?
<G-vec00092-001-s595><believe.glauben><de> Wer aber glaubt solches, wenn es ihm vorgetragen wird?....
<G-vec00092-001-s596><believe.glauben><en> He does not believe that the people that planned the terrorist attack in New York represent Islam.
<G-vec00092-001-s596><believe.glauben><de> Er glaubt nicht, dass die Urheber des Terroranschalgs in New York den Islam repräsentieren.
<G-vec00092-001-s597><believe.glauben><en> They live a facade in public but are often different at home, often trying to make up for the difference between what they believe in their legalism, and the reality of their life.
<G-vec00092-001-s597><believe.glauben><de> Sie lebt in der Öffentlichkeit mit einer Fassade, aber zu Hause ist sie oft anders und versucht oftmals den Unterschied zwischen dem was sie durch ihre Gesetzlichkeit glaubt und der Realität ihres Lebens auszugleichen.
<G-vec00092-001-s598><believe.glauben><en> Believe in the powers I have given you.
<G-vec00092-001-s598><believe.glauben><de> Glaubt an die Kräfte, die Ich euch gegeben habe.
<G-vec00092-001-s599><believe.glauben><en> All MY children who trust ME, will hear MY voice clearly, just believe, and keep asking ME.
<G-vec00092-001-s599><believe.glauben><de> Alle MEINE Kinder, die MIR vertrauen, werden MEINE Stimme klar und deutlich hören, glaubt nur und fragt MICH immerzu.
<G-vec00092-001-s600><believe.glauben><en> Of course worries about the forthcoming showdown with Greece cannot be ignored, since the Greek government still continues to believe that with its scorched earth policy in negotiations, it can still reach its defined goal.
<G-vec00092-001-s600><believe.glauben><de> Auch sind Sorgen um einen heranrückenden Showdown in Griechenland nicht von der Hand zu weisen, da die griechische Regierung nach wie vor glaubt, mit einer Verhandlungsstrategie der verbrannten Erde an ein wie immer definiertes Ziel zu kommen.
<G-vec00092-001-s601><believe.glauben><en> While Ajo is buoyed by the work ahead and the question marks that will arise he also doesn't believe that Moto2 will be turned on its head.
<G-vec00092-001-s601><believe.glauben><de> Obwohl die bevorstehende Arbeit und die vielen Fragezeichen Ajo auf Trab halten, glaubt er nicht, dass die Moto2 davon auf den Kopf gestellt werden wird.
<G-vec00092-001-s602><believe.glauben><en> And fear Allah, in Whomye believe.
<G-vec00092-001-s602><believe.glauben><de> Und fürchtet Allah, an Den ihr glaubt.
<G-vec00092-001-s603><believe.glauben><en> Merely watching the movements of our new heroine – which of course I did very closely - was rather fun and I didn't notice any edgy graphics anymore, those which bothered me in the screenshots, just believe me when I say that those freeze images tell nothing compared to the live game.
<G-vec00092-001-s603><believe.glauben><de> Es machte alleine schon Spaß, die Bewegungen unserer neuen Heldin zu verfolgen, was ich natürlich mit Argusaugen tat, und ich sah nichts mehr von der eckigen Grafik, die mich auf den Screens so gestört hatte, glaubt mir einfach, die Standbilder sagen nichts aus im Vergleich zum lebendigen Spiel.
<G-vec00092-001-s604><believe.glauben><en> 31 But these are recorded so that you may believe that Jesus is the Christ, the Son of God, and that by believing you may have life in his name.
<G-vec00092-001-s604><believe.glauben><de> Joh 20:31 Diese aber sind aufgezeichnet, damit ihr glaubt, daß Jesus der Messias ist, der Sohn Gottes, und damit ihr im Glauben das Leben habt in seinem Namen.
<G-vec00092-001-s605><believe.glauben><en> Dear children, be filled with hope and believe firmly in the power of God.
<G-vec00092-001-s605><believe.glauben><de> Geliebte Kinder, erfuellt euch mit Hoffnung und glaubt fest an die Macht Gottes.
<G-vec00092-001-s606><believe.glauben><en> He does not believe that he has to fight as the representative of an idea, but he fights because his instincts compel him to do so.
<G-vec00092-001-s606><believe.glauben><de> Er glaubt nicht als Vertreter irgend einer Idee kämpfen zu müssen, sondern er kämpft, weil ihn seine Instinkte dazu treiben.
<G-vec00092-001-s607><believe.glauben><en> Abahlali have said over and over that the majority of our people believe in a true democracy, a democracy that caters for every gogo and mkhulu's at home, a democracy that does not see people differently, a democracy that does not make few people better than the majority, a democracy that is not driven by the wealth that has torn our society apart.
<G-vec00092-001-s607><believe.glauben><de> Abahlali hat immer wieder gesagt, dass die Mehrheit der Menschen an eine echte Demokratie glaubt, eine Demokratie, die jedes Kind und jedeN AlteN daheim kümmert, eine Demokratie, die die Menschen nicht unterschiedlich betrachtet, eine Demokratie, die nicht einige wenige Menschen besser macht als die Mehrheit, eine Demokratie, die nicht vom Wohlstand getrieben wird, der unsere Gesellschaft gespalten hat.
<G-vec00092-001-s608><believe.glauben><en> There is hardly a child who, as a child, did not believe in Grandfather Frost.
<G-vec00092-001-s608><believe.glauben><de> Es gibt kaum ein Kind, das als Kind nicht an Großvater Frost glaubte.
<G-vec00092-001-s609><believe.glauben><en> I did believe that it was a wise decision since it was a strange place and everything different from my country.
<G-vec00092-001-s609><believe.glauben><de> Ich glaubte, dass es eine kluge Entscheidung war, da es ein seltsamer Ort und alles andere aus meinem Land war.
<G-vec00092-001-s610><believe.glauben><en> And his heart fainted, for he did not believe them.
<G-vec00092-001-s610><believe.glauben><de> Aber sein Herz blieb kalt, denn er glaubte ihnen nicht.
<G-vec00092-001-s611><believe.glauben><en> Yes Before I did believe in God but not the way I do now.
<G-vec00092-001-s611><believe.glauben><de> Ja, vorher glaubte ich an Gott, aber nicht auf die Art, wie ich es jetzt mache.
<G-vec00092-001-s612><believe.glauben><en> At this pharmacy, they helped me find the right treatment and delivered it so fast, I didn't even believe my eyes.
<G-vec00092-001-s612><believe.glauben><de> In dieser Apotheke half man mir die richtige Behandlung zu finden, und lieferte es so schnell, ich glaubte meine Augen nicht.
<G-vec00092-001-s613><believe.glauben><en> The Prince of Saiyans didn't believe that the monster had survived...not that he wouldn't fight if necessary, but he felt a little concern for the others, who would be easily slaughtered.
<G-vec00092-001-s613><believe.glauben><de> Der Prinz der Saiyajins glaubte nicht, dass das Monster überlebt hatte... nicht, dass er nicht kämpfen wollte, sollte es notwendig sein, aber er fühlte die Unsicherheit der anderen, die sicherlich mühelos abgeschlachtet werden würden.
<G-vec00092-001-s614><believe.glauben><en> To me it sounds more an excuse to fly ahead read the easy way, but, grabbing well for good, does not justify having then hired a psychologist so did believe the little Amanda's father was an unfortunate, nor hatred toward the ruthless girl.
<G-vec00092-001-s614><believe.glauben><de> Es klingt für mich mehr eine Entschuldigung, die sie packte, um den einfachen Weg zu nehmen, aber doch, Grabbing auch für eine gute, nicht rechtfertigt, die dann mieteten ein Psychologe, so glaubte die kleine Amandas Vater war ein unglücklicher, noch Hass gegen die rücksichtslose Mädchen.
<G-vec00092-001-s615><believe.glauben><en> I kept on clarifying the truth, even to those who didn't listen, because I believe that my words do have an effect on them and will lay the foundation for other practitioners' efforts talking to them in future.
<G-vec00092-001-s615><believe.glauben><de> Ich erklärte weiterhin die Wahrheit, sogar auch jenen, die nicht zuhörten, weil ich glaubte, dass meine Worte eine Wirkung auf sie ausüben und für die Bemühungen anderer Praktizierender eine Grundlage bilden, wenn sie in der Zukunft mit ihnen sprechen.
<G-vec00092-001-s616><believe.glauben><en> Yes It was a long time, no he didn't believe me.
<G-vec00092-001-s616><believe.glauben><de> Ja Es dauerte eine lange Zeit, nein er glaubte mir nicht.
<G-vec00092-001-s617><believe.glauben><en> As for me I believe to have heard a strong Bay Area influence.
<G-vec00092-001-s617><believe.glauben><de> Ich jedenfalls glaubte einen starken Bay Area Einschlag vernommen zu haben.
<G-vec00092-001-s618><believe.glauben><en> Ergo, Cord Meyer did not believe that Lee Harvey Oswald killed President Kennedy.
<G-vec00092-001-s618><believe.glauben><de> Ergo glaubte Schnur Meyer nicht, dass Lee Harvey Oswald Präsident Kennedy tötete.
<G-vec00092-001-s619><believe.glauben><en> I couldn't believe it.
<G-vec00092-001-s619><believe.glauben><de> Ich glaubte es nicht.
<G-vec00092-001-s620><believe.glauben><en> She was right even though I did not believe her at the time.
<G-vec00092-001-s620><believe.glauben><de> Sie sollte recht behalten, auch wenn ich ihr das in dem Moment nicht glaubte.
<G-vec00092-001-s621><believe.glauben><en> KC: I wanted to create a sober atmosphere, because I believe that the vocals must be more direct and warmer than the music.
<G-vec00092-001-s621><believe.glauben><de> KC: Ich wollte eine nüchterne Atmosphäre schaffen, denn ich glaubte, daß die Stimmen direkter und wärmer als die Musik sein müßten.
<G-vec00092-001-s622><believe.glauben><en> I was someone who didn't believe in God and where I was, was going to be ok, but that would have 'been it.'
<G-vec00092-001-s622><believe.glauben><de> Ich war jemand, der nicht an Gott glaubte und wo ich war, würde in Ordnung sein, aber das wäre es gewesen.
<G-vec00092-001-s623><believe.glauben><en> In short, if you were to believe those calling for “respect”, Muslims would like to demand a condition of apartheid.
<G-vec00092-001-s623><believe.glauben><de> Kurzum, glaubte man den Anhängern des „Respekts“, würden die Muslime am liebsten Apartheid fordern.
<G-vec00092-001-s624><believe.glauben><en> Of course, he did not immediately believe.
<G-vec00092-001-s624><believe.glauben><de> Natürlich glaubte er nicht sofort.
<G-vec00092-001-s625><believe.glauben><en> He, however, did not believe in Buddhism and once went into a rage and burnt his wife's Buddhist books when he caught her reciting scriptures.
<G-vec00092-001-s625><believe.glauben><de> Er glaubte jedoch nicht an den Buddhismus und geriet einmal in Rage und verbrannte die buddhistischen Bücher seiner Frau, als er sie beim Rezitieren der Schriften erwischte.
<G-vec00092-001-s626><believe.glauben><en> I did not 'believe' that such 'beings' as the Kachina existed yet seemed familiar with some of the theoretical concepts that enabled me to make sense of my experience better than I may have done in the absence of my background.
<G-vec00092-001-s626><believe.glauben><de> Ich 'glaubte' nicht dass solche 'Wesen' wie die Kachina existieren, schien jedoch vertraut zu sein mit einigen theoretischen Konzepten die mir ermöglichten einen Sinn in meiner Erfahrung zu sehen, besser als wenn mir dieser Hintergrund gefehlt hätte.
<G-vec00092-001-s627><believe.glauben><en> To conclude the matter, whoever is loved by God will enter the Abode of Heaven, and God bestows His Love and Grace upon the good doers, those who believe with true sincerity and who do works of righteousness.
<G-vec00092-001-s627><believe.glauben><de> Um das Thema zu beenden, wer von Gott geliebt wird, wird den Ewigen Aufenthalt im Himmel antreten und Gott gewährt ihm Seine Liebe und Gnade unter denen, die Gutes taten, denen, die mit wahrer Aufrichtigkeit glaubten und die Taten der Rechtschaffenheit verrichteten.
<G-vec00092-001-s628><believe.glauben><en> 9:18 The Jews therefore did not believe concerning him, that he had been blind, and had received his sight, until they called the parents of him who had received his sight,
<G-vec00092-001-s628><believe.glauben><de> 9:18 Es glaubten nun die Juden nicht von ihm, daß er blind war und sehend geworden, bis sie die Eltern dessen riefen, der sehend geworden war.
<G-vec00092-001-s629><believe.glauben><en> But those who did not really believe in their hearts laid their hands on their sick in vain and ran back to the bank again in order to seek advice from Me about what was lacking, why they could not succeed to do what their neighbors had done.
<G-vec00092-001-s629><believe.glauben><de> Aber jene, die nicht recht im Herzen glaubten, legten ihren Kranken vergeblich die Hände auf und liefen wieder ans Ufer, um sich mit Mir zu beraten, woran es fehle, darum ihnen nicht gelinge, was doch mehreren ihrer Nachbarn gelungen sei.
<G-vec00092-001-s630><believe.glauben><en> This man came for a witness, to give testimony of the light, that all men might believe through him.
<G-vec00092-001-s630><believe.glauben><de> Dieser kam zum Zeugnis, daß er von dem Licht zeugte, auf daß sie alle durch ihn glaubten.
<G-vec00092-001-s631><believe.glauben><en> Basically people who have fought for what they believe in and won.
<G-vec00092-001-s631><believe.glauben><de> Hauptsächlich Leute, die für das gekämpft haben, woran sie glaubten und gewonnen haben.
<G-vec00092-001-s632><believe.glauben><en> Because the Holy Spirit also gives patience”. Precisely “in this week of preparation for the Solemnity of Pentecost”, the Pope invited Christians to ask themselves if they truly believe in the Holy Spirit or if for them he is merely “a word”.
<G-vec00092-001-s632><believe.glauben><de> Denn auch die Geduld ist eine Gabe des Heiligen Geistes.« Gerade »in dieser Woche der Vorbereitung auf das Hochfest Pfingsten« lud der Papst die Christen ein, sich zu fragen, ob sie wirklich an den Heiligen Geist glaubten oder ob er für sie lediglich »ein Wort« sei.
<G-vec00092-001-s633><believe.glauben><en> 27 September 2018 State Management Academy hosts the book launch of: We did Believe in Azerbaijan's Independence
<G-vec00092-001-s633><believe.glauben><de> "27 September 2018 Die Präsentation des Buches ""Wir glaubten an die Unabhängigkeit von Aserbaidschan"" von Ə.Topçubaşov wurde durchgeführt."
<G-vec00092-001-s634><believe.glauben><en> "The Soviets had a complete set of tools for intimidation, deception and temptation, but they did not believe that ""criminals"" could be reformed into ""new people."""
<G-vec00092-001-s634><believe.glauben><de> "Tatsächlich verfügten sie auch über einen ganzen Maßnahmenkatalog zur Einschüchterung, Irreführung und Verführung, aber sie glaubten nicht, daß man ""Kriminelle"" zu ""neuen Menschen"" umformen könnte."
<G-vec00092-001-s635><believe.glauben><en> He came for witness, that he might witness concerning the light, that all might believe through him.
<G-vec00092-001-s635><believe.glauben><de> Dieser kam zum Zeugnis, daß er zeugte von dem Licht, damit alle durch ihn glaubten.
<G-vec00092-001-s636><believe.glauben><en> < 24:11 But they did not believe the women, because their words seemed to them like nonsense.
<G-vec00092-001-s636><believe.glauben><de> < 24:11 Und es erschienen ihnen diese Worte, als wär's Geschwätz, und sie glaubten ihnen nicht.
<G-vec00092-001-s637><believe.glauben><en> The policemen did not really believe, but they could not enter.
<G-vec00092-001-s637><believe.glauben><de> Die Polizisten glaubten ihn kaum, aber sie konnten nicht hineingehen.
<G-vec00092-001-s638><believe.glauben><en> And when there had been much disputing, Peter rose and said to them, Men, brethren, ye know that a good while ago, God made choice among us, that the Gentiles, by my mouth should hear the word of the gospel, and believe.
<G-vec00092-001-s638><believe.glauben><de> Da man sich aber lange gestritten hatte, stand Petrus auf und sprach zu ihnen: Ihr Männer, liebe Brüder, ihr wisset, das Gott lange vor dieser Zeit unter uns erwählt hat, daß durch meinen Mund die Heiden das Wort des Evangeliums hörten und glaubten.
<G-vec00092-001-s639><believe.glauben><en> "The mothers and women of Palestine believe, so the reporter, that death is a fitting price to pay for a free Palestine, compared with a ""life of humiliation under the boots of the occupiers""."
<G-vec00092-001-s639><believe.glauben><de> "Mütter und Frauen Palästinas glaubten, dass der Tod für ein freies Palästina ein angemessener Preis sei, verglichen mit einem ""Leben der Demütigung unter den Stiefeln der Besatzer""."
<G-vec00092-001-s640><believe.glauben><en> Rural Socialists believe that DK leader Ferenc Gyurcsány is a handicap for the Left, while urban ones think they can never win individual constituencies without his support.
<G-vec00092-001-s640><believe.glauben><de> Die Sozialisten auf dem Land glaubten, dass DK-Chef Ferenc Gyurcsány ein Handicap für die Linke sein, während ihre städtisch geprägten Genossen davon ausgingen, dass sie ohne dessen Unterstützung niemals einen Wahlkreis gewinnen könnten.
<G-vec00092-001-s641><believe.glauben><en> "15:7 After much discussion, Peter got up and addressed them: ""Brothers, you know that some time ago God made a choice among you that the Gentiles might hear from my lips the message of the gospel and believe."
<G-vec00092-001-s641><believe.glauben><de> 15:7 Als man sich aber lange gestritten hatte, stand Petrus auf und sprach zu ihnen: Ihr Männer, liebe Brüder, ihr wißt, daß Gott vor langer Zeit unter euch bestimmt hat, daß durch meinen Mund die Heiden das Wort des Evangeliums hörten und glaubten.
<G-vec00092-001-s642><believe.glauben><en> (As for) those who have lost their souls, they will not believe.
<G-vec00092-001-s642><believe.glauben><de> (Schaut; wie das Ende) derjenigen (war), die ihre Seelen verloren haben, denn sie glaubten nicht.
<G-vec00092-001-s643><believe.glauben><en> 18 But the Jews did not believe concerning him, that he had been blind, and received his sight, until they called the parents of him that had received his sight.
<G-vec00092-001-s643><believe.glauben><de> 18 Nun glaubten die Juden nicht von ihm, daß er blind gewesen und sehend geworden sei, bis sie die Eltern des Sehendgewordenen gerufen hatten.
<G-vec00092-001-s644><believe.glauben><en> These words seemed to them to be nonsense, and they didn't believe them.
<G-vec00092-001-s644><believe.glauben><de> Und ihre Reden schienen ihnen wie leeres Gerede, und sie glaubten ihnen nicht.
<G-vec00092-001-s645><believe.glauben><en> At the peak of the massive bombardments in 1992, not even the most optimistic of its residents could believe that Sarajevo would manage to resist – but it did.
<G-vec00092-001-s645><believe.glauben><de> Auf dem Höhepunkt des dauernden Beschusses im Jahr 1992 glaubten nicht einmal mehr die größten Optimisten der Stadt, dass Sarajewo widerstehen könnte – aber so war es.
<G-vec00345-001-s665><believe.halten><en> Polygraph examinations given to test subjects in this state have consistently indicated that the test subjects believe these accounts to be true.
<G-vec00345-001-s665><believe.halten><de> Lügendetektortests mit Testsubjekten, die sich in diesem Zustand befanden, haben ausnahmslos gezeigt, dass die Testpersonen diese Aussagen für wahr halten.
<G-vec00345-001-s666><believe.halten><en> Therefore scientists believe that physical exercise in itself trains the brain and has an effect on the creation of new brain cells.
<G-vec00345-001-s666><believe.halten><de> Dass schon Bewegung an sich das Gehirn trainiert und die Neubildung von Hirnzellen beeinflusst, halten Wissenschaftler daher für plausibel.
<G-vec00345-001-s667><believe.halten><en> In the medical area the three Berlin authorities believe that the targeted use of disinfectants and antiseptics in sufficiently high concentrations is essential.
<G-vec00345-001-s667><believe.halten><de> Im medizinischen Bereich halten die drei Berliner Behörden den gezielten Einsatz von Desinfektionsmitteln und Antiseptika in ausreichend hohen Anwendungskonzentrationen für unverzichtbar.
<G-vec00345-001-s668><believe.halten><en> In vain shall we call and believe ourselves Atheists, until we comprehend these causes, for, until then, we shall always suffer ourselves to be more or less governed by the clamours of this universal conscience whose secret we have not discovered; and, considering the natural weakness of even the strongest individual against the all-powerful influence of the social surroundings that trammel him, we are always in danger of relapsing sooner or later, in one way or another, into the abyss of religious absurdity.
<G-vec00345-001-s668><believe.halten><de> Wenn wir uns auch Atheisten nennen und für solche halten, solange wir diese Ursachen nicht verstanden haben, werden wir uns stets mehr oder weniger von dem Lärm dieses allgemeinen Gewissens beherrschen lassen, dessen Geheimnis wir nicht herausgefunden haben, und bei der natürlichen Schwäche selbst des Stärksten gegenüber dem allmächtigen Einfluß des sozialen Milieus, das ihn umgibt, riskieren wir stets früher oder später, auf die eine oder andere Art in den Abgrund der religiösen Sinnlosigkeit zurückzufallen.
<G-vec00345-001-s669><believe.halten><en> The spirits and powers that are coming from outside the church are the unclean spirits, the fallen angels, to kill and destroy the believers and followers of Christ who live according to the commandments of God. Beware of them and their tactics which can even deceive the elect! Do not believe in the new age brought to you by the leaders and ministers of the pagan religions.
<G-vec00345-001-s669><believe.halten><de> Die Geister und Mächte die von außerhalb der Kirche kommen, sind unreine Geister, die gefallenen Engel, die kommen um die Gläubigen und jenen die Christus nachfolgen, die sich an die Gebote Gottes halten, zu töten und zu zerstören.
<G-vec00345-001-s670><believe.halten><en> Unique Jackpot set up We believe in rewarding more players significant Jackpot wins instead of having a jackpot that falls out once a year.
<G-vec00345-001-s670><believe.halten><de> Einzigartiger Jackpot Wir halten es für besser, mehrere Spieler mit beachtlichen Jackpot-Gewinnen zu belohnen, anstatt einen Jackpot zu haben, der einmal jährlich ausgezahlt wird.
<G-vec00345-001-s671><believe.halten><en> For now, we believe the prospective returns on real estate debt looks more attractive than those from real estate equity.
<G-vec00345-001-s671><believe.halten><de> Derzeit halten wir die voraussichtlichen Renditen von Real Estate Debt für attraktiver als diejenigen von Immobilienaktien.
<G-vec00345-001-s672><believe.halten><en> "The investigators believe H. is the intellectual mastermind behind the group because his dissertation on urban renewal features the word ""gentrification,"" which also appears in the communiqués of the ""militante gruppe."""
<G-vec00345-001-s672><believe.halten><de> "Für den intellektuellen Kopf der Gruppe halten ihn die Ermittler, weil in H.'s Doktorarbeit über Stadterneuerung der Begriff ""gentrification"" auftaucht, der die Aufwertung von Stadtteilen beschreibt und auch von der ""militanten gruppe"" benutzt wurde."
<G-vec00345-001-s673><believe.halten><en> We believe it is extremely important to understand how to implement these laws and which is their ultimate goal.
<G-vec00345-001-s673><believe.halten><de> Wir halten es für äußerst wichtig zu verstehen wie die Anwendung dieser Gesetze gedacht ist und welches ihr Endziel ist.
<G-vec00345-001-s674><believe.halten><en> Though many believe it to be much less fashion-oriented than Milan, it remains an obligatory destination for all designer-label collectors.
<G-vec00345-001-s674><believe.halten><de> Dennoch halten viele Rom für viel weniger fashionorientiert als Mailand, welches ein obligatorisches Ziel für alle Liebhaber von Designlabels ist.
<G-vec00345-001-s675><believe.halten><en> There is no desire to believe yourself half saint, half angel, when you know that you’ve made some grievous mistakes.
<G-vec00345-001-s675><believe.halten><de> Man kann keine große Lust haben, sich für halbe Heilige zu halten, für halbe Engel, wenn man weiß, sich schwerer Verfehlungen schuldig gemacht zu haben.
<G-vec00345-001-s676><believe.halten><en> Acrylamide can cause cancer in animals and experts believe it could cause cancer in humans.
<G-vec00345-001-s676><believe.halten><de> Acrylamid kann bei Tieren Krebs erzeugen und Fachleute halten dies auch beim Menschen für möglich.
<G-vec00345-001-s677><believe.halten><en> They believe it’s a time capsule until it “pins” Jack onto the wall and something infects the basis from it.
<G-vec00345-001-s677><believe.halten><de> Ursprünglich halten sie es für eine Zeitkapsel, bis es Jack an die Wand “nagelt” und sich etwas daraus in der Basis ausbreitet.
<G-vec00345-001-s678><believe.halten><en> You will know instinctively what you must do to help those who are still hooked into the illusion they believe to be real.
<G-vec00345-001-s678><believe.halten><de> Ihr werdet instinktiv wissen, was zu tun ist, um denen zu helfen, die immer noch in der Illusion gefangen sind, die sie für die Wirklichkeit halten.
<G-vec00345-001-s679><believe.halten><en> Pilgrimage churches did attract worshippers from far away, but I wonder whether all the worshippers here were from Munich, or local folk imitating the citizens of the capital... or whether what we believe to be Munich Tracht was in fact in much wider use than we thought.
<G-vec00345-001-s679><believe.halten><de> Wallfahrtskirchen wurden natürlich auch von Gläubigen aus weiter entfernten Orten besucht, aber anhand der Zahl der Votivbilder muss man sich fragen, ob all diese Frauen aus München angereist waren - damals immerhin eine mehrtägige Reise -, ob sie aus der näheren Gegend stammten, aber zu diesem festlichen Anlaß die Tracht der Hauptstädterinnen nachahmten, oder ob gar das, was wir heute für Münchner Tracht halten, sehr viel weiter verbreitet war, als die Trachtenerneuerer uns glauben machen.
<G-vec00345-001-s680><believe.halten><en> We believe it to be of utmost importance for the future of Europe's democracies that dictatorships are not revalued and that antisemitism is outlawed in all its forms.
<G-vec00345-001-s680><believe.halten><de> Wir halten es für die Zukunft von Europas Demokratien für zentral, dass Diktaturen nicht aufgewertet werden und dass der Antisemitismus in all seinen Formen geächtet wird.
<G-vec00345-001-s681><believe.halten><en> That is usually why we believe we are attracted to another person: They seem to embody what we most admire and need.
<G-vec00345-001-s681><believe.halten><de> Dies halten wir gewöhnlich für den Grund, weshalb wir uns zu einer anderen Person hingezogen fühlen - sie scheint das zu verkörpern, was wir am meisten bewundern und brauchen.
<G-vec00345-001-s682><believe.halten><en> """We believe it is a clear advantage to have two channels into this demanding market,"" Arvid Sundblad concludes.Caption: ""We have great respect for Japanese business culture and are therefore only recruiting Japanese staff."
<G-vec00345-001-s682><believe.halten><de> """Wir halten es für einen eindeutigen Vorteil, zwei Vertriebskanäle für diesen anspruchsvollen Markt vorzuhalten"", fasst Arvid Sundblad abschließend zusammen.Bildunterschrift: ""Wir haben großen Respekt vor der japanischen Geschäftskultur und stellen daher nur japanische Mitarbeiter ein."
<G-vec00345-001-s683><believe.halten><en> But even this relatively aggressive tightening of fiscal policy (and the projections are based on GDP growth higher than many believe is possible, especially in light of that same fiscal tightening and a climate of austerity) doesn’t prevent debt/GDP from rising above 90% in 2013.
<G-vec00345-001-s683><believe.halten><de> Doch auch diese vergleichsweise aggressive Verschärfung der Fiskalpolitik (und die Prognosen basieren auf einem höheren Wirtschaftswachstum, als viele vor allem wegen eben dieser fiskalischen Verschärfung sowie aufgrund des allgemeinen Sparzwangs derzeit für möglich halten) wird nicht verhindern, dass die Schuldenquote relativ zum BIP 2013 auf über 90% ansteigen.
<G-vec00092-001-s684><believe.meinen><en> Some respondents of this majority, however, believe that such a wrongful trading rule should be restricted, very general or should (also) be dealt with in insolvency law.
<G-vec00092-001-s684><believe.meinen><de> Einige Stimmen meinen allerdings, dass eine derartige Insolvenzverschleppungshaftung eingeschränkt oder sehr allgemein sein sollte oder (auch) im Insolvenzrecht zu regeln sei.
<G-vec00092-001-s685><believe.meinen><en> Quite a few believe the most beautiful mosque in the country.
<G-vec00092-001-s685><believe.meinen><de> Nicht wenige meinen die schönste Moschee des Landes.
<G-vec00092-001-s686><believe.meinen><en> We believe that climate protection starts at the workplace.
<G-vec00092-001-s686><believe.meinen><de> Wir meinen, dass der Klimaschutz am Arbeitsplatz beginnt.
<G-vec00092-001-s687><believe.meinen><en> Other respondents believe that national law should regulate the subject.
<G-vec00092-001-s687><believe.meinen><de> Andere meinen, dass dieses Thema im nationalen Recht behandelt werden sollte.
<G-vec00092-001-s688><believe.meinen><en> Some linguists believe that the fact that all human communities use language is evidence that language is transmitted, for the most part, not culturally but genetically.
<G-vec00092-001-s688><believe.meinen><de> Manche LinguistInnen meinen, dass die Tatsache, dass sich Sprache in allen menschlichen Gemeinschaften findet, ein Beweis dafür ist, dass sie zum größten Teil nicht kulturell, sondern genetisch vermittelt wird.
<G-vec00092-001-s689><believe.meinen><en> Solar power and Kenya should go well together one would believe.
<G-vec00092-001-s689><believe.meinen><de> Solarstrom und Kenia, das passt doch wie die Faust auf's Auge – sollte man meinen.
<G-vec00092-001-s690><believe.meinen><en> We could believe that the achievement of democracy prevents large pendulum swings.
<G-vec00092-001-s690><believe.meinen><de> Wir könnten meinen, dass die Errungenschaft der Demokratie zu große Pendelausschläge verhindere.
<G-vec00092-001-s691><believe.meinen><en> We believe it is vital to emerge from the narrow confines of a purely Eurocentric perspective.
<G-vec00092-001-s691><believe.meinen><de> Wir meinen: Es gilt aus der Falle einer allein eurozentrischen Perspektive herauszukommen.
<G-vec00092-001-s692><believe.meinen><en> Many people believe that only very serious problems or mental disorders should be the cause for psychotherapeutic assistance.
<G-vec00092-001-s692><believe.meinen><de> Viele Menschen meinen, dass nur außergewöhnlich schwerwiegende Probleme oder psychiatrische Störungen Anlass für psychotherapeutische Hilfestellung sein sollten.
<G-vec00092-001-s693><believe.meinen><en> We believe that acting is one of the most spirited, joy-filled and effective ways to learn German and experience the language in all its facets.
<G-vec00092-001-s693><believe.meinen><de> Wir meinen, Theaterspielen ist eine der lebendigsten, freudvollsten und effektivsten Weisen, die deutsche Sprache zu erlernen und in all ihren Facetten zu erfahren.
<G-vec00092-001-s694><believe.meinen><en> We also believe that this strengthens the sense of community amongst the employees.
<G-vec00092-001-s694><believe.meinen><de> Auch meinen wir, dadurch das Gemeinschaftsgefühl unter den Mitarbeitern zu stärken.
<G-vec00092-001-s695><believe.meinen><en> Migration policy has become Orbán's nemesis, some commentators believe.
<G-vec00092-001-s695><believe.meinen><de> Orbán strauchelt über die Migrationspolitik, meinen einige Kommentatoren.
<G-vec00092-001-s696><believe.meinen><en> It has not been fully achieved in any part of the West, and there are good reasons to believe that it cannot be achieved.
<G-vec00092-001-s696><believe.meinen><de> Sie ist in keinem Teil der westlichen Welt voll umgesetzt worden, und wir haben guten Grund zu meinen, daß das auch gar nicht geschehen kann.
<G-vec00092-001-s697><believe.meinen><en> They believe that they are doing what they are doing because they have to.
<G-vec00092-001-s697><believe.meinen><de> Sie meinen, dass sie tun, was sie tun, weil sie ihre Not überwinden mussten.
<G-vec00092-001-s698><believe.meinen><en> Experts from different areas believe that new markets will open up, with an annual turnover of 100 billion euros.
<G-vec00092-001-s698><believe.meinen><de> Experten aus unterschiedlichen Bereichen meinen, dass sich neue Märkte mit einem Umsatz von 100 Milliarden Euro jährlich eröffnen werden.
<G-vec00092-001-s699><believe.meinen><en> When you are happy, you create and perceive what you believe you need to be happy,
<G-vec00092-001-s699><believe.meinen><de> Wenn Sie glücklich sind, fällt Ihnen Vieles zu, was Sie meinen zum Glücklichsein zu brauchen.
<G-vec00092-001-s700><believe.meinen><en> He has been flying for over 30 years and I believe he would be a good choice for the second half.
<G-vec00092-001-s700><believe.meinen><de> Er fliegt seit über 30 Jahren und ist nach meinen jetzigen Erfahrungen eine gute Besetzung für die zweite Hälfte.
<G-vec00092-001-s701><believe.meinen><en> Some believe that the crisis will further weld together the tandem, whereas others regard early presidential elections and Putin's return in the Kremlin as a settled thing.
<G-vec00092-001-s701><believe.meinen><de> Während die einen meinen, daß die Krise das Tandem noch weiter zusammenschweißen werde, sehen andere vorgezogene Präsidentschaftswahlen und die Rückkehr Putins in den Kreml als eine abgemachte Sache.
<G-vec00092-001-s702><believe.meinen><en> I believe that a lot of Christians want revival, because they believe that they won't have to labor any more.
<G-vec00092-001-s702><believe.meinen><de> "Ich glaube, viele Christen wollen Erweckung, weil sie meinen, sie müssen nicht mehr ""krampfen""."
<G-vec00345-001-s741><believe.sind><en> If you believe that any information about you is false or inaccurate, please inform us as soon as possible.
<G-vec00345-001-s741><believe.sind><de> Wenn sie der Meinung sind, dass irgendwelche Angaben über Sie unrichtig oder ungenau sind, bitte benachrichtigen Sie uns baldmöglichst.
<G-vec00345-001-s742><believe.sind><en> If you believe that any information we are holding on you is incorrect or incomplete, please email us as soon as possible.
<G-vec00345-001-s742><believe.sind><de> Falls Sie der Meinung sind, dass Informationen, die wir über Sie haben, unrichtig oder unvollständig sind, schreiben Sie uns bitte unverzüglich per Post oder E-Mail an die obengenannte Anschrift.
<G-vec00345-001-s743><believe.sind><en> I believe that there has been a gap that the Osstell Beacon now can fill because it's so intuitive and easy to use, and perhaps also speaks to newcomers to the method.
<G-vec00345-001-s743><believe.sind><de> Meiner Meinung nach füllt das Osstell Beacon eine Lücke, denn es ist überaus intuitiv und bedienerfreundlich und deswegen wird es vielleicht auch Neulinge ansprechen, die mit dem Verfahren noch nicht so vertraut sind.
<G-vec00345-001-s744><believe.sind><en> We hope that all gemlabs will start to apply this nomenclature and we fall in line with Dr. Peretti´s statement that ''Most of these stones are so heavily in-fused with lead-glass that many believe they should not even be associated with the name of ruby.''
<G-vec00345-001-s744><believe.sind><de> "Wir hoffen, dass alle gemmologischen Labors diese Nomenklatur übernehmen und können uns nur der Aussage von Dr. Peretti anschließen, der frei übersetzt sagte, ''Die meisten dieser Steine haben einen so hohen Bleiglas-Gehalt, dass viele der Meinung sind, der Name Rubin sollte damit gar nicht in Verbindung gebracht werden""."
<G-vec00345-001-s745><believe.sind><en> Although according to the feedbacks, we believe that we can assembly BGA in high quality, in fact, the proliferation of the lead-free technology has brought about new problems, which the usual testing methods cannot detect.
<G-vec00345-001-s745><believe.sind><de> Obwohl wir auf Grund der Feedbacks der Meinung sind, dass wir in guter Qualität BGAs bestücken konnten, ist es Fakt, dass die Verbreitung der bleifreien Technologie zu neuen Problemen geführt hat, welche mittels der gewöhnlichen Inspektionsmethoden nicht ermittelt werden können.
<G-vec00345-001-s746><believe.sind><en> Mensheviki. This party includes all shades of Socialists who believe that society must progress by natural evolution toward Socialism, and that the working-class must conquer political power first.
<G-vec00345-001-s746><believe.sind><de> Dieser Partei gehören Sozialisten aller Schattierungen an, die der Meinung sind, die Gesellschaft müsse durch eine natürliche Evolution zum Sozialismus gelangen und die Arbeiterklasse müsse zunächst die politische Macht erobern.
<G-vec00345-001-s747><believe.sind><en> Parents who believe that their child has submitted personal information to us and would like to have it deleted may contact us at privacy@fitbit.com .
<G-vec00345-001-s747><believe.sind><de> Eltern, die der Meinung sind, dass ihr Kind uns persönliche Daten hat zukommen lassen und diese löschen lassen möchten, kontaktieren uns bitte unter privacy@fitbit.com .
<G-vec00345-001-s748><believe.sind><en> Home Experiences Unusual Florence Unusual Florence Florence's long history surprises even those who believe they know all its secrets.
<G-vec00345-001-s748><believe.sind><de> Die lange Geschichte der Stadt Florenz hält Überraschungen auch für diejenigen parat, die der Meinung sind, bereits all ihre Geheimnisse zu kennen.
<G-vec00345-001-s749><believe.sind><en> You can also contact us if you believe that the personal information we have from you is incorrect, if you believe that we are no longer entitled to use your personal data or if you have any other questions about how your personal information is used or about the Privacy Statement.
<G-vec00345-001-s749><believe.sind><de> Sie können sich auch mit uns in Verbindung setzen, wenn Sie der Meinung sind, dass die persönlichen Daten, die wir über Sie speichern, falsch sind, wenn Sie der Meinung sind, dass wir nicht mehr das Recht haben, Ihre persönlichen Daten zu verwenden, oder wenn Sie andere Fragen dazu haben Ihre persönlichen Daten werden verwendet oder über die Datenschutzerklärung.
<G-vec00345-001-s750><believe.sind><en> BEUMER Group Training and Qualification normally take place at our customer's site as we believe that customers get the most out of training in person with on-site systems.
<G-vec00345-001-s750><believe.sind><de> Die Schulungen und Weiterbildungen der BEUMER Group finden normalerweise beim Kunden statt, da wir der Meinung sind, dass die Kunden die optimalsten Ergebnisse bei persönlichen Schulungen mit den Anlagen vor Ort erzielen.
<G-vec00345-001-s751><believe.sind><en> If you believe that your work has been copied in a way that constitutes copyright infringement, please follow our Notice and Procedure for Making Claims of Copyright Infringement.
<G-vec00345-001-s751><believe.sind><de> Wenn Sie der Meinung sind, dass Ihre Arbeit auf eine Weise kopiert wurde, die einen Verstoß gegen Urheberrechtsgesetze darstellt, befolgen Sie bitte die Bestimmungen in unserem Abschnitt: Meldung und Verfahren zur Geltendmachung von Ansprüchen bei Urheberrechtsverstößen.
<G-vec00345-001-s752><believe.sind><en> "Basically, if you believe that students learn better by actively participating in the learning process, generating their own ""theories"" about how language works, and practising language in collaboration with peers, then wikis are a tool you cannot neglect."
<G-vec00345-001-s752><believe.sind><de> "Wenn Sie grundsätzlich der Meinung sind, dass die Lernenden besser lernen, wenn sie aktiv am Lernprozess mitwirken, ihre eigenen ""Theorien"" darüber entwickeln, wie Sprache funktioniert, und in Zusammenarbeit mit den anderen Lernenden Fremdsprachen trainieren, kommen Sie an Wikis als Tool nicht vorbei."
<G-vec00345-001-s753><believe.sind><en> If you believe that the processing of your personal data has been carried out illegitimately, you can file a complaint with one of the supervisory authorities responsible for compliance with the rules on personal data protection.
<G-vec00345-001-s753><believe.sind><de> Wenn Sie der Meinung sind, dass Ihre personenbezogenen Daten unrechtmäßig verarbeitet wurden, können Sie eine Beschwerde bei einer der Aufsichtsbehörden einreichen, die für die Einhaltung der Vorschriften zum Schutz personenbezogener Daten zuständig ist.
<G-vec00345-001-s754><believe.sind><en> If we cancel The Owner or their Managing Agent reserves the right to cancel any booking where we believe that the information supplied to us concerning the identity of any or all persons listed on the booking form is incorrect or untrue.
<G-vec00345-001-s754><believe.sind><de> Wenn wir stornieren Der Eigentümer oder sein Agent behalten sich das Recht vor, eine Buchung zu stornieren, wenn wir der Meinung sind, dass die uns übergebenen Informationen bezüglich der Identität einer oder aller auf dem Buchungsformular aufgelisteten Personen falsch oder unwahr ist.
<G-vec00345-001-s755><believe.sind><en> In particular, we presented effective cooling systems and energy-saving systems for recuperating heat for livestock farms because we believe that these are two particularly important components of housing climate technology and we are one of the leading companies in this field.
<G-vec00345-001-s755><believe.sind><de> Speziell hier haben wir energiesparende Systeme für eine Wärme / rückgewinnung für Tier haltende Betriebe und effektive Kühlungssysteme vorgestellt, weil wir der Meinung sind, dass es sich um besonders wichtige Bestandteile des Stallklimas handelt, und nehmen in diesem Sektor eine der führenden Plätze ein.
<G-vec00345-001-s756><believe.sind><en> If you believe that any information we are holding on you is incorrect or incomplete, please email us as soon as possible, at the above address.
<G-vec00345-001-s756><believe.sind><de> Falls Sie der Meinung sind, dass Informationen, die wir über Sie haben, unrichtig oder unvollständig sind, schreiben Sie uns bitte unverzüglich per Post oder E-Mail an die obengenannte Anschrift.
<G-vec00345-001-s757><believe.sind><en> We reserve the right to disclose your personally identifiable information as required by law and when we believe that disclosure is necessary to protect our rights and/or to comply with a judicial proceeding, court order, or legal process served on our Site.
<G-vec00345-001-s757><believe.sind><de> Wir behalten uns das Recht vor, Ihre personenbezogenen Daten im Rahmen der gesetzlichen Bestimmungen offen zu legen und wenn wir der Meinung sind, dass die Offenlegung notwendig ist, um unsere Rechte zu schützen und/oder um einem Rechtsstreit, einem Gerichtsbeschluss oder einem Gerichtsverfahren, das gegen unsere Website durchgeführt wird, nachzukommen.
<G-vec00345-001-s758><believe.sind><en> It's a great community, where shoppers vote on the styles that they believe the site should sell more of in the future.
<G-vec00345-001-s758><believe.sind><de> Es ist eine große Community, bei der Käufer Ihre Lieblingsoutfits wählen, wovon sie der Meinung sind, dass die Webseite zukünftig mehr verkaufen sollte.
<G-vec00345-001-s759><believe.sind><en> You have the right to request that the processing be restricted if you believe that the data processed by us are inaccurate or if you need the data to assert, exercise or defend a legal claim.
<G-vec00345-001-s759><believe.sind><de> Sie haben das Recht, die Einschränkung der Verarbeitung zu verlangen, wenn Sie der Meinung sind, dass die von uns verarbeiteten Daten nicht richtig sind oder wenn Sie die Daten zur Geltendmachung, Ausübung oder Verteidigung eines Rechtsanspruches brauchen.
<G-vec00092-001-s760><believe.glauben><en> "Believe it or not, radio is ""delicate"" with the commands and buttons."
<G-vec00092-001-s760><believe.glauben><de> "Ob Sie es glauben oder nicht, ist das Radio ""delikat"" mit den Befehlen und Schaltflächen."
<G-vec00092-001-s761><believe.glauben><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00092-001-s761><believe.glauben><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00092-001-s762><believe.glauben><en> Believe it or not, but the greatest open rates are not reached with the latest in messaging innovations.
<G-vec00092-001-s762><believe.glauben><de> Ob Sie es glauben oder nicht, aber die höchsten Öffnungsraten werden nicht mit den neuesten Nachrichten-Innovationen erreicht.
<G-vec00092-001-s763><believe.glauben><en> Believe it or not, green cars were popular a century ago.
<G-vec00092-001-s763><believe.glauben><de> Ob Sie es glauben oder nicht, ökologische Autos waren vor einem Jahrhundert beliebt.
<G-vec00092-001-s764><believe.glauben><en> 2007-11-13 22:16:19 - Believe it or not I am often astounded at what and why people believe what they do.
<G-vec00092-001-s764><believe.glauben><de> 2007-11-13 22:16:19 - Ob Sie es glauben oder nicht Ich bin oft erstaunt, was und warum Menschen glauben, was sie tun.
<G-vec00092-001-s765><believe.glauben><en> Believe it, you will be the most beautiful bride.
<G-vec00092-001-s765><believe.glauben><de> Ob Sie es glauben, werden Sie die schönste Braut sein .
<G-vec00092-001-s766><believe.glauben><en> Believe it or not, you can also make wealth via the internet even if you do not possess a business.
<G-vec00092-001-s766><believe.glauben><de> Ob Sie es glauben oder nicht, können Sie auch Reichtum über das Internet vornehmen, auch wenn Sie kein Geschäft besitzen.
<G-vec00092-001-s767><believe.glauben><en> Epimedium Leaf – Believe it or not, this active ingredient is made use of in the major prescription brand names of impotence products.
<G-vec00092-001-s767><believe.glauben><de> Epimedium Blatt – Ob Sie es glauben oder nicht, ist diese Zutat Verwendung in den bedeutenden Rezept Marken der erektilen Dysfunktion Produkten.
<G-vec00092-001-s768><believe.glauben><en> Believe it or he returned anyway to Paris with the help of the people who wanted him back.
<G-vec00092-001-s768><believe.glauben><de> Ob Sie es glauben oder kehrte er nach Paris sowieso mit der Hilfe von Menschen, die ihn zurück haben wollte.
<G-vec00092-001-s769><believe.glauben><en> To boost magnesium in your diet, be sure to eat more dark leafy greens, nuts, seeds, oily fish, avocado, bananas, low fat yogurt and (believe it or not) dark chocolate.
<G-vec00092-001-s769><believe.glauben><de> Dieser wichtige Mineralstoff ist reichlich enthalten in dunkelgrünem Blattgemüse, Nüssen, Samen, Fettfische, Avocados, Bananen, fettarmem Jogurt und (ob sie es glauben oder nicht) dunkler Schokolade.
<G-vec00092-001-s770><believe.glauben><en> Epimedium Leaf – Believe it or not, this component is utilized in the major prescription brand names of impotence items.
<G-vec00092-001-s770><believe.glauben><de> Epimedium Blatt – Ob Sie es glauben oder nicht, wird diese Komponente Verwendung in den bedeutenden Rezept Marken von Impotenz Artikel gemacht.
<G-vec00092-001-s771><believe.glauben><en> Believe it or not, this natural wonder is twice as deep as the world-famous Grand Canyon.
<G-vec00092-001-s771><believe.glauben><de> Ob Sie es glauben oder nicht, dieses Naturwunder ist doppelt so tief wie der weltberühmte Grand Canyon.
<G-vec00092-001-s772><believe.glauben><en> Epimedium Leaf – Believe it or not, this component is used in the significant prescription brands of erectile dysfunction products.
<G-vec00092-001-s772><believe.glauben><de> Epimedium Blatt – Ob Sie es glauben oder nicht, wird diese Komponente in den bedeutenden Rezept Marken von Impotenz Produkten verwendet.
<G-vec00092-001-s773><believe.glauben><en> At that point reality hit me and the exact thought I had believe it or not was 'I have to get back down there' and my next memory is me taking a deep breath and seeing my cousin and paramedics. NDE from seizure.
<G-vec00092-001-s773><believe.glauben><de> An jenem Punkt traf mich die Erkenntnis und der genaue Gedanke, ob Sie mir glauben oder nicht, den ich hatte war: 'Ich muss zurück nach dort unten gelangen', und meine nächste Erinnerung ist dass ich einen tiefen Atemzug machte und meinen Vetter und Sanitäter sah.
<G-vec00092-001-s774><believe.glauben><en> Believe it or not, we’re extremely similar in all aspects.
<G-vec00092-001-s774><believe.glauben><de> Ob Sie es glauben oder nicht, wir sind uns in allen Aspekten sehr ähnlich.
<G-vec00092-001-s775><believe.glauben><en> Believe it or not, you must have a positive perspective and feel good about themselves, to be able to lose weight faster.
<G-vec00092-001-s775><believe.glauben><de> Ob Sie es glauben oder nicht, ist es notwendig, einen positiven Ausblick zu haben und ein gutes Gefühl über sich selbst in der Lage sein, Gewicht zu verlieren schneller.
<G-vec00092-001-s776><believe.glauben><en> Believe it or not, that’s not all, either.
<G-vec00092-001-s776><believe.glauben><de> Ob Sie es glauben oder nicht, das ist auch nicht alles.
<G-vec00092-001-s777><believe.glauben><en> Epimedium Leaf – Believe it or not, this component is utilized in the significant prescription brands of impotence products.
<G-vec00092-001-s777><believe.glauben><de> Epimedium Blatt – Ob Sie es glauben oder nicht, wird diese Komponente Verwendung in den bedeutenden Rezept Marken der erektilen Dysfunktion Produkte gemacht.
<G-vec00092-001-s778><believe.glauben><en> Believe it or not, one of many causes of prematurely having an orgasm is nervousness over a person’s capacity to give pleasure to your sexual partner.
<G-vec00092-001-s778><believe.glauben><de> Ob Sie es glauben oder nicht, ist eine von vielen Ursachen für vorzeitigen einen Orgasmus Nervosität über die Fähigkeit einer Person, Vergnügen, Ihre sexuellen Partner zu geben.
<G-vec00345-001-s779><believe.sehen><en> Parents believe that the reasons for this are a lack of time and not enough sports facilities in school and after-school care clubs. However, the importance of the parental role model function is far less identified.
<G-vec00345-001-s779><believe.sehen><de> Die Gründe hierfür sehen die Eltern vor allem im Zeitmangel und zu wenigen Sportangeboten in Schule und Hort, die Bedeutung der elterlichen Vorbildfunktion hingegen wird weit weniger erkannt.
<G-vec00345-001-s780><believe.sehen><en> We believe that investment in our employees is a substantial contribution to the social responsibility.
<G-vec00345-001-s780><believe.sehen><de> Als wesentlichen Beitrag zur gesellschaftlichen Verantwortung sehen wir die Investition in unsere Mitarbeiter.
<G-vec00345-001-s781><believe.sehen><en> This is where we can help, and we believe that there is strong growth potential in this area.
<G-vec00345-001-s781><believe.sehen><de> In diesem Bereich können wir helfen und sehen hier enormes Wachstumspotenzial“, erklärt Renate Kroboth.
<G-vec00345-001-s782><believe.sehen><en> And I believe that
<G-vec00345-001-s782><believe.sehen><de> Kann ich sehen,dass...
<G-vec00345-001-s783><believe.sehen><en> Some authors believe it to be as much the function of the reproductive system to produce individual differences, or slight deviations of structure, as to make the child like its parents.
<G-vec00345-001-s783><believe.sehen><de> Einige Schrift-steller sehen es ebensosehr für die Aufgabe des Reproductiv-systemes an, individuelle Verschiedenheiten oder ganz leichteAbweichungen des Baues hervorzubringen, als das Kind den El-tern gleich zu machen.
<G-vec00345-001-s784><believe.sehen><en> "We want to continue to generate profitable growth in this future market and believe that the combination of our analog chip expertise and microelectronic packaging expertise puts us in an excellent position to achieve this"", says CFO Dr. Mathias Gollwitzer."
<G-vec00345-001-s784><believe.sehen><de> "In diesem Zukunftsmarkt wollen auch wir weiter profitabel wachsen und sehen uns dafür über die Kombination unseres analogen Chip-Knowhows und unserer mikroelektronischen AVT-Kompetenz bestens aufgestellt"", so CFO Dr. Mathias Gollwitzer."
<G-vec00345-001-s785><believe.sehen><en> Some believe you to be in crisis, others are happy that some substance is at last to be seen.
<G-vec00345-001-s785><believe.sehen><de> Die einen sehen sie in der Krise, die anderen freuen sich, dass endlich Substanz sichtbar wird.
<G-vec00345-001-s786><believe.sehen><en> "We believe that lupinemeal has great potential in aquaculture"", says Christina Hörterer."
<G-vec00345-001-s786><believe.sehen><de> "Wir sehen ein großes Potenzial für die Verwendung von Lupinenmehl in der Aquakultur"", sagt Christina Hörterer."
<G-vec00345-001-s787><believe.sehen><en> Nihat Ay and Ralf Der believe that robots will become increasingly autonomous, willing to learn, flexible and natural.
<G-vec00345-001-s787><believe.sehen><de> Nihat Ay und Ralf Der sehen Roboter immer autonomer, lernwilliger, flexibler und natürlicher werden.
<G-vec00345-001-s788><believe.sehen><en> Therefore, we believe that one of our most important assets is our trained in-house support that guarantees competent advice, short reaction times and the will to do more than just the necessary.
<G-vec00345-001-s788><believe.sehen><de> Einen Grundpfeiler sehen wir daher im geschulten In-House-Support mit kompetenter Beratung, kurzen Reaktionszeiten und dem Willen, mehr als nur das Notwendige zu machen.
<G-vec00345-001-s789><believe.sehen><en> We believe the combined company will be very well positioned to tap the considerable long-term growth potential of the agricultural sector.
<G-vec00345-001-s789><believe.sehen><de> Wir sehen das kombinierte Unternehmen als sehr gut positioniert, um am Agrarsektor und dessen erheblichem langfristigem Wachstumspotenzial teilzuhaben.
<G-vec00345-001-s790><believe.sehen><en> Due to the ongoing deterioration in market conditions, the Board of Directors and Executive Board believe it is necessary to reinforce the restructuring programme.
<G-vec00345-001-s790><believe.sehen><de> Aufgrund der anhaltenden Verschlechterung der Marktbedingungen sehen der Verwaltungsrat und die Geschäftsleitung die Notwendigkeit, das laufende Restrukturierungsprogramm zu verstärken.
<G-vec00345-001-s791><believe.sehen><en> As a leading global technology company for design-oriented, multifunctional components and surfaces, we believe Nanogate is in a strong position.
<G-vec00345-001-s791><believe.sehen><de> Als ein international führendes Technologieunternehmen für designorientierte, multifunktionale Komponenten und Oberflächen sehen wir Nanogate gut aufgestellt.
<G-vec00345-001-s792><believe.sehen><en> Although the accuracy of planning achievable has not returned to pre-crisis levels, we believe that we are well equipped in the current situation to master this phase when the challenges of managing opportunities and risks are considerably greater.
<G-vec00345-001-s792><believe.sehen><de> Obgleich die erreichbare Planungssicherheit nicht wieder auf das Vorkrisenniveau zurückgekehrt ist, sehen wir uns in der aktuellen Situation gut gerüstet, diese Phase deutlich erhöhter Anforderungen an das Chancen- und Risikomanagement zu meistern.
<G-vec00345-001-s793><believe.sehen><en> The Executive Board and Supervisory Board of KION GROUP AG believe that an uncompromising commitment to rigorous corporate governance in accordance with the standards is essential to the Company’s long-term success.
<G-vec00345-001-s793><believe.sehen><de> Vorstand und Aufsichtsrat der KION GROUPAG sehen in einer kompromisslosen Verpflichtung gegenüber den Prinzipien einer anspruchsvollen, den Standards entsprechenden Corporate Governance eine wesentliche Voraussetzung für den nachhaltigen Unternehmenserfolg.
<G-vec00345-001-s794><believe.sehen><en> We believe the successful future of companies lies in the transition to the latest version of the ERP solution from Microsoft: Microsoft Dynamics 365 Enterprise Edition.
<G-vec00345-001-s794><believe.sehen><de> Wir sehen die erfolgreiche Zukunft der Unternehmen im Wechsel zur neuesten Version des ERP-Lösung von Microsoft: Microsoft Dynamics 365 Enterprise Edition.
<G-vec00345-001-s795><believe.sehen><en> We believe that the immigration to Europe not only poses economic and social challenges, but also still presents opportunities for the labor market and on the demand side for our customers and, as a result, for the Würth Group.
<G-vec00345-001-s795><believe.sehen><de> Die Zuwanderungen in Europa sehen wir – bei allen damit verbundenen wirtschaftlichen und gesellschaftlichen Herausforderungen – nach wie vor auch als Chance für den Arbeitsmarkt und für die Nachfragesteigerung bei unseren Kunden und damit auch bei der Würth-Gruppe.
<G-vec00345-001-s796><believe.sehen><en> As a major player in the world of secure electronic passports, we believe Gemalto's mission is also to contribute to informing our partners and the wider industry, sharing best practices and presenting expert analysis.
<G-vec00345-001-s796><believe.sehen><de> Als einer der führenden Anbieter im Bereich sichere elektronische Reisepässe sehen wir bei Gemalto unsere Aufgabe auch darin, unsere Partner und die gesamte Branche zu informieren, bewährte Praktiken weiterzugeben und Expertenanalysen zu präsentieren.
<G-vec00345-001-s797><believe.sehen><en> Personalized experiences make it delightful. We believe your customers are people, not devices.
<G-vec00345-001-s797><believe.sehen><de> Wir sehen Ihre Kunden als das, was sie sind: Alle sind Menschen, keine Geräte.
<G-vec00345-001-s836><believe.sind><en> We believe that the real goal of ESG integration is better capital allocation and investment decisions.
<G-vec00345-001-s836><believe.sind><de> Wir sind der Ansicht, dass das eigentliche Ziel bei der Integration von ESG-Faktoren darin besteht, eine bessere Kapitalallokation und bessere Anlageentscheidungen zu ermöglichen.
<G-vec00345-001-s837><believe.sind><en> We believe that content, messages and advertising are more relevant and valuable to you when they are based upon your interests, needs and demographics.
<G-vec00345-001-s837><believe.sind><de> Wir sind der Ansicht, dass Inhalte, Nachrichten und Werbung für Sie interessanter und wertvoller sind, wenn diese Ihre Interessen, Ihren Bedarf und Ihre demographischen Angaben betreffen.
<G-vec00345-001-s838><believe.sind><en> At SGS, we believe that long-term improvement in the management and verification of forest information contributes to better governance in the forest sector.
<G-vec00345-001-s838><believe.sind><de> Wir bei SGS sind der Ansicht, dass eine langfristige Optimierung des Managements und der Verifizierung der forstwirtschaftlichen Informationen zu einer besseren Kontrolle des Forstsektors beitragen.
<G-vec00345-001-s839><believe.sind><en> But many of us believe that you could only shop for one season.
<G-vec00345-001-s839><believe.sind><de> Doch viele sind der Ansicht, dass man nur saisonal das neue Must-Have shoppen kann.
<G-vec00345-001-s840><believe.sind><en> We believe that licenses and operating within the guidelines of the various regulatory bodies are key success factors for companies operating in the FINTECH sector .
<G-vec00345-001-s840><believe.sind><de> Wir sind der Ansicht, dass Lizenzen und die Beachtung d er Richtlinien der verschiedenen Aufsichtsbehörden maßgeblich für den Geschäftserfolg von Unternehmen in der FINTECH-Branche sind.
<G-vec00345-001-s841><believe.sind><en> Therefore, we believe that linking to other sites is legally permissible and consistent with the expectations of those who use the Internet.
<G-vec00345-001-s841><believe.sind><de> Wir sind daher der Ansicht, dass Verlinkungen zu anderen Websites gesetzlich zulässig sind und den Erwartungen der Internetnutzer entsprechen.
<G-vec00345-001-s842><believe.sind><en> Dr. Lifton and I believe that it was left out due to Nyiszli’s admitted involvement in the murders.
<G-vec00345-001-s842><believe.sind><de> Dr. Lifton und ich sind der Ansicht, Nyiszli habe nicht zugeben wollen, bei Morden mitgeholfen zu haben.
<G-vec00345-001-s843><believe.sind><en> Our vision on education We believe that education brings huge benefits to the individual in terms of personal development and well-being – and to society in terms of economic development and social cohesion.
<G-vec00345-001-s843><believe.sind><de> Unser Leitbild im Bereich Bildung Wir sind der Ansicht, dass Bildung die persönliche Entwicklung fördert und die Lebensqualität jedes Einzelnen verbessert.
<G-vec00345-001-s844><believe.sind><en> While volatility has heightened recently, we believe that emerging-market (EM) fundamentals remain sound.
<G-vec00345-001-s844><believe.sind><de> Obwohl die Volatilität jüngst gestiegen ist, sind wir der Ansicht, dass die Fundamentaldaten der Schwellenländer weiterhin solide sind.
<G-vec00345-001-s845><believe.sind><en> Pierre Philippe, in charge of Tdh’s programmes in West Africa, is confident: “On the basis of Tdh’s experience in the north-west of Burkina Faso, we believe that exemption of payment is an efficient and affordable solution to lessen the maternal/infant mortality rate.
<G-vec00345-001-s845><believe.sind><de> Pierre Philippe, Verantwortlicher der Tdh-Programme in Westafrika, zeigt sich zuversichtlich: «Von der Erfahrung ausgehend, die Tdh im Nordwesten Burkina Fasos gemacht hat, sind wir der Ansicht, dass die Zahlungsbefreiung eine wirksame und erschwingliche Lösung ist, um die Sterblichkeit von Müttern und Kindern zu reduzieren.
<G-vec00345-001-s846><believe.sind><en> We believe that there could be one, but in any case the V4 will prepare one, and the V4 will submit this as its joint proposal to the European Council.
<G-vec00345-001-s846><believe.sind><de> Wir sind der Ansicht, dies wäre aber durchaus möglich, jedenfalls bereiten die V4 eines vor und dies werden sie als gemeinsamen Vorschlag der V4 dem Europäischen Rat vorlegen.
<G-vec00345-001-s847><believe.sind><en> The S&Ds believe that the implementation proposal is detrimental to the overall aim of the directive, namely to reduce CO2 emissions and move towards a carbon-free energy supply in Europe.
<G-vec00345-001-s847><believe.sind><de> Die Sozialdemokraten sind der Ansicht, dass der Umsetzungsvorschlag dem übergeordneten Ziel der Richtlinie abträglich ist, die CO2-Emissionen zu verringern und zu einer kohlenstofffreien Energieversorgung in Europa überzugehen.
<G-vec00345-001-s848><believe.sind><en> The European Socialists and Democrats believe that the issue of rising energy poverty requires greater attention from all legislators.
<G-vec00345-001-s848><believe.sind><de> Die europäischen Sozialdemokraten sind der Ansicht, dass das Problem der zunehmenden Energiearmut mehr Beachtung von allen Gesetzgebern erfordert.
<G-vec00345-001-s849><believe.sind><en> We believe differently, and are ready to oust them from power.
<G-vec00345-001-s849><believe.sind><de> Wir sind da anderer Ansicht und stehen bereit, sie aus der Macht zu vertreiben.
<G-vec00345-001-s850><believe.sind><en> We believe that one of the key prerequisites for further development of each community is the education of young people.
<G-vec00345-001-s850><believe.sind><de> Wir sind der Ansicht, dass die Ausbildung junger Menschen eine der Schlüsselbedingungen für die Weiterentwicklung einer jeden Gemeinschaft darstellt.
<G-vec00345-001-s851><believe.sind><en> The directors believe, however, that commencing the winding up process at this time will provide the Company with the flexibility to wind up quickly upon completion of the litigation matters.
<G-vec00345-001-s851><believe.sind><de> Die Directors sind jedoch der Ansicht, dass die Einleitung des Liquidationsprozesses zum gegenwärtigen Zeitpunkt der Gesellschaft die nötige Flexibilität verleiht, rasch nach Beendigung der Rechtsstreitigkeiten eine Auflösung zu erreichen.
<G-vec00345-001-s852><believe.sind><en> We believe that Hillcrest has developed an attractive and substantial position within this emerging fairway.
<G-vec00345-001-s852><believe.sind><de> Wir sind der Ansicht, dass Hillcrest in diesem aufstrebenden Gebiet mittlerweile einen attraktiven und beachtlichen Grundbesitz aufgebaut hat.
<G-vec00345-001-s853><believe.sind><en> 80Â % of respondents in Indonesia, the Philippines and Turkey believe that most employers prioritise profits over safety of their workers;
<G-vec00345-001-s853><believe.sind><de> 80% der Befragten in Indonesien, den Philippinen und der TÃ1⁄4rkei sind der Ansicht, dass den meisten Arbeitgebern die Profite wichtiger sind als die Sicherheit ihrer Beschäftigten.
<G-vec00345-001-s854><believe.sind><en> We believe that every writer should have a good place to publish their works.
<G-vec00345-001-s854><believe.sind><de> Wir sind der Ansicht, dass jeder Schriftsteller und jede Schriftstellerin einen guten Ort zum Veröffentlichen haben sollte.
<G-vec00345-001-s855><believe.sind><en> Leading experts in neuropsychology believe that the sooner a child’s learning begins, the better will be the assimilation of new information in school, university and life in general.
<G-vec00345-001-s855><believe.sind><de> Führende Experten in der Neuropsychologie sind der Meinung, dass je früher das Lernen eines Kindes beginnt, desto besser werden neue Informationen in Schule, Universität und allgemeinem Leben erfasst.
<G-vec00345-001-s856><believe.sind><en> """We believe commerce experiences should be beautiful, and with Acquia, brands can bridge the content and commerce divide."
<G-vec00345-001-s856><believe.sind><de> """Wir sind der Meinung, Commerce-Erlebnisse sollten schön sein, und mit Acquia können Marken die Kluft zwischen Inhalten und Commerce überwinden."
<G-vec00345-001-s857><believe.sind><en> Moreover, according to the survey, 98% of the respondents believe being responsible is important in order to be successful.
<G-vec00345-001-s857><believe.sind><de> 98% der befragten Personen sind der Meinung, dass die Verantwortung gegenüber der eigenen Familie am stärksten ins Gewicht fällt.
<G-vec00345-001-s858><believe.sind><en> Some say that the image of the pelican pecking at its own breast symbolises the 18th degree of the freemasons, while others believe it is an ancient symbol for Jesus Christ . According to legend, the mother pelican would give her life for her chicks in the same way that Jesus sacrificed himself to save humanity.
<G-vec00345-001-s858><believe.sind><de> Während sich einige sicher sind, dass dieses Tier das Symbol der 18 Grad der Franco-Freimaurer ist, spezifischer noch wenn es sich mit dem Schnabel den Bauch öffnet (dieses Abbild befindet sich zum Beispiel in der Kirche), andere wiederum sind der Meinung, der Pelikan sei ein antikes Symbol für Jesus Christus .
<G-vec00345-001-s859><believe.sind><en> We believe that at this location, in the middle of this building that is very technically oriented in terms of content and looks, a cafeteria with a haptic and, let me say now, emotional surface would be very good.
<G-vec00345-001-s859><believe.sind><de> Wir sind der Meinung, dass an diesem Ort, inmitten dieser vom Inhalt und vom Aussehen her sehr technisch ausgerichteten Gebäude, eine Mensa mit einer haptischen und, ich sage jetzt einmal, emotionalen Oberfläche ganz gut wäre.
<G-vec00345-001-s860><believe.sind><en> We believe that this project speaks for itself - that all possible questions can be answered by the website.
<G-vec00345-001-s860><believe.sind><de> Wir sind der Meinung: Dieses Projekt spricht umfassend für sich selbst, so dass alle Fragen, die zu stellen wären, mit der Website beantwortet werden.
<G-vec00345-001-s861><believe.sind><en> Analysts believe that investors' interest in diamonds will continue to grow, mainly due to the increasing scarcity of the product.
<G-vec00345-001-s861><believe.sind><de> Analysten sind der Meinung, dass das Interesse der Anleger an Diamanten weiterhin wachsen wird, vor allem dank der zunehmenden Knappheit des Produkts.
<G-vec00345-001-s862><believe.sind><en> "We believe that our first and foremost ""mission "" is to provide code to any and all comers, and for whatever purpose, so that the code gets the widest possible use and provides the widest possible benefit."
<G-vec00345-001-s862><believe.sind><de> "Wir sind der Meinung, dass unsere ""Mission "" zuerst und insbesondere darin besteht, allen und jedem Kommenden Code für welchen Zweck auch immer zur Verfügung zu stellen, damit der Code möglichst weit eingesetzt wird und den größtmöglichen Nutzen liefert."
<G-vec00345-001-s863><believe.sind><en> On the contrary, some governments and members of a misinformed public believe that the Ottawa accord did enough on its own to make landmines no longer a problem.
<G-vec00345-001-s863><believe.sind><de> Im Gegenteil, einige Regierungen und eine desinformierte Öffentlichkeit sind der Meinung, daß mit dem Ottawa-Vertrag genug gegen Minen getan wurde.
<G-vec00345-001-s864><believe.sind><en> Many scientists believe that the human-induced increase in greenhouse gases in the atmosphere will lead to overall global warming over the next decades and centuries.
<G-vec00345-001-s864><believe.sind><de> Viele Wissenschaftler sind der Meinung, dass die vom Menschen verursachte Zunahme der Treibhausgase in der Atmosphäre in den nächsten Jahrzehnten und Jahrhunderten eine globale Erwärmung bewirken.
<G-vec00345-001-s865><believe.sind><en> Although a high gluten index leads to easier and more predictable pasta manufacturing, many believe this increase is due to higher concentrations of certain types of gliadin that also may be responsible for many of the sensitivity problems now experienced by many people.
<G-vec00345-001-s865><believe.sind><de> Zwar führt ein höherer Glutenindex zu einer vereinfachten und planbareren Nudelherstellung, doch so sind viele Experten der Meinung, dass durch eine höhere Konzentration des darin enthaltenen Gliadin verantwortlich dafür sein kann, dass mehr mehr Menschen diese Gluten-Sensibilität entwickelt haben.
<G-vec00345-001-s866><believe.sind><en> We believe that people come together or separate on the basis of principles.
<G-vec00345-001-s866><believe.sind><de> Wir sind der Meinung, dass Menschen auf Grundlage von Prinzipien zusammenkommen oder sich trennen.
<G-vec00345-001-s867><believe.sind><en> Many people believe that their value proposition and their USP are the same things.
<G-vec00345-001-s867><believe.sind><de> Viele Leute sind der Meinung, dass das Wertversprechung und das Alleinstellungsmerkmal ein und dasselbe sind.
<G-vec00345-001-s868><believe.sind><en> We Bolsheviks believe only from the outset that the masses of ALL nations will go their own way to socialist revolution, national and social liberation, and that the more they support each other and show solidarity with each other in doing so, the faster they all go their own way and reach their goal the easier, if they see their own socialist revolution as part of the whole world socialist revolution, if they understand their national and social liberation as a common task and subordinate it to the overall interests of the national and social liberation of all nations, regardless of the diversity of all nations, regardless of the different path of their individual liberation, regardless of the most diverse national forms of socialism.
<G-vec00345-001-s868><believe.sind><de> Wir Bolschewisten sind nur von Anfang an der Meinung, dass die Massen ALLER Nationen ihren eigenen Weg der sozialistischen Revolution, der nationalen und sozialen Befreiung gehen, und dass sie alle diesen Weg um so schneller beschreiten und ihr Ziel um so leichter erreichen, je mehr sie sich dabei gegenseitig unterstützen und sich miteinander solidarisieren, wenn sie ihre eigene sozialistische Revolution als Teil der ganzen weltsozialistischen Revolution begreifen, wenn sie ihre nationale und soziale Befreiung als eine gemeinsame Aufgabe verstehen und diese den Gesamtinteressen der nationalen und sozialen Befreiung aller Nationen unterordnen - unabhängig von der Verschiedenheit aller Nationen, unabhängig von dem unterschiedlichen Weg ihrer einzelnen Befreiung, unabhängig von den unterschiedlichsten nationalen Formen des Sozialismus.
<G-vec00345-001-s869><believe.sind><en> We believe that the legalization of marijuana's recreational use will have a positive impact on the medicinal side .
<G-vec00345-001-s869><believe.sind><de> Wir sind der Meinung, dass die Legalisierung von Marihuana als Genussmittel einen positiven Einfluss auf dessen Verwendung im medizinischen Bereich haben wird.
<G-vec00345-001-s870><believe.sind><en> But we believe that we have all we need to develop and produce electronics under competitive conditions here in Germany – today and in the future.” The success story of Appel Elektronik from Heuchelheim is excellent proof of this.
<G-vec00345-001-s870><believe.sind><de> Wir sind hingegen der Meinung, dass wir hier in Deutschland alle Voraussetzungen haben, um heute und in Zukunft Elektronik unter wettbewerbsfähigen Bedingungen zu entwickeln und zu produzieren.“ Die Erfolgsgeschichte von Appel Elektronik aus Heuchelheim liefert dafür den besten Beweis.
<G-vec00345-001-s871><believe.sind><en> The Portman Group: “Some people believe that if less alcohol were consumed by the population as a whole, there would be fewer alcohol-related problems.
<G-vec00345-001-s871><believe.sind><de> Die Portman Gruppe: “Einige Leute sind der Meinung, dass es weniger alkoholbedingte Probleme geben würde, wenn die Bevölkerung, global gesehen, weniger Alkohol trinken würde.
<G-vec00345-001-s872><believe.sind><en> Keeping this in mind we believe, that office furniture is something more than just furniture, this is an added value for every company.
<G-vec00345-001-s872><believe.sind><de> Aus diesem Hintergrund sind wir der Meinung, dass Büromöbel viel mehr ist als nur Möbel, sondern bedeutet ein Mehrwert eines Unternehmens.
<G-vec00345-001-s873><believe.sind><en> Many Berliners believe that the Gendarmenmarkt is the most beautiful place in Germany and indeed in all of Europe.
<G-vec00345-001-s873><believe.sind><de> Viele Berliner sind der Meinung, dass es sich bei dem Gendarmenmarkt in Berlin um den schönsten Platz in Deutschland, ja sogar in ganz Europa handelt.
<G-vec00345-001-s874><believe.sind><en> Only 35 percent of Japanese respondents believe in the quality of German products. Yes.
<G-vec00345-001-s874><believe.sind><de> Leider nein, im Gegenteil: Lediglich 35 Prozent der befragten Japaner sind von der Qualität deutscher Waren überzeugt.
<G-vec00345-001-s875><believe.sind><en> We believe that sustainability and profitability, the shop- ping experience and environmental awareness are not opposing forces. Long-term thinking is part of our strategy.
<G-vec00345-001-s875><believe.sind><de> Wir sind überzeugt, dass Nachhaltigkeit und Wirtschaft- lichkeit, Shoppingerlebnis und Umweltbewusstsein keine Gegensätze sind.
<G-vec00345-001-s876><believe.sind><en> Sustainable Learning We believe that the following insights gained from neuroscience, along with Coverdale’s almost 50 years of practical training experience, enhance the sustained continuing development of people and organizations.
<G-vec00345-001-s876><believe.sind><de> Coverdale steht für nachhaltiges Lernen Wir sind überzeugt, dass folgende Erkenntnisse aus der Neurowissenschaft und der über 50-jährigen Trainingspraxis von Coverdale die nachhaltige Weiterentwicklung von Menschen und Organisationen fördern.
<G-vec00345-001-s877><believe.sind><en> We believe that the Golden Medal will help us to become more visible and thanks to the interest we believe in our business success.
<G-vec00345-001-s877><believe.sind><de> Wir sind überzeugt, dass die Goldmedaille uns bei der PR hilft, und glauben angesichts des Interesses auch an geschäftlichen Erfolg.
<G-vec00345-001-s878><believe.sind><en> We believe that your skin must breathe in order to radiate in perfect beauty.
<G-vec00345-001-s878><believe.sind><de> Wir sind überzeugt, dass Ihre Haut atmen und perfekte Schönheit ausstrahlen muss.
<G-vec00345-001-s879><believe.sind><en> We believe that success can only be achieved if everything is in harmony and goals are only great and good if everyone involved – whether human or animal – can and want to live for them.
<G-vec00345-001-s879><believe.sind><de> Wir sind überzeugt, dass Erfolg nur in Harmonie zu erreichen ist und Ziele nur dann große und schöne Ziele sind, wenn alle Beteiligten – ob Mensch oder Tier – dafür leben können und wollen.
<G-vec00345-001-s880><believe.sind><en> We believe that individual support is essential in order to achieve this goal.
<G-vec00345-001-s880><believe.sind><de> Wir sind überzeugt von der Nowendigkeit, in einer kleinen Gruppe zu lernen, um dieses Ziel zu erreichen.
<G-vec00345-001-s881><believe.sind><en> “We believe that automated driving will help us achieve the vision of safe and accident-free driving.
<G-vec00345-001-s881><believe.sind><de> „Wir sind überzeugt, dass wir durch Automatisierung unsere Vision vom sicheren und unfallfreien Fahren verwirklichen können.
<G-vec00345-001-s882><believe.sind><en> """We strongly believe that all workers deserve and should have decent working conditions and a living wage in order to provide for themselves and their families."
<G-vec00345-001-s882><believe.sind><de> Wir sind fest überzeugt, dass alle Arbeitnehmer menschenwürdige Arbeitsbedingungen und ein existenzsicherndes Gehalt verdienen und haben sollten, um sich und ihre Familien versorgen zu können.
<G-vec00345-001-s883><believe.sind><en> We believe that by understanding the conditions of the working professionals, we can contribute to their performance, safety and well-being by dressing them according to whatever job they have at hand.
<G-vec00345-001-s883><believe.sind><de> Wir sind überzeugt, dass unser Verständnis für die Arbeit, die diese Menschen leisten, uns dabei hilft, nachhaltig zu ihrer Leistung, Sicherheit und ihrem Wohlbefinden beizutragen, indem wir ihnen die für ihre Aufgaben passende Kleidung bereitstellen.
<G-vec00345-001-s884><believe.sind><en> We believe that through partnering we can leverage today's scientific know-how and translate it into innovative medicines.
<G-vec00345-001-s884><believe.sind><de> Wir sind überzeugt, dass wir durch Partnerschaften das heute weltweit vorhandene wissenschaftliche Know-how optimal nutzen und in innovative Medikamente umsetzen können.
<G-vec00345-001-s885><believe.sind><en> The producers of the STYL and KABO fairs believe that the exhibitors will like this new system and that both the August 2011 fairs will get a fresh new look through the use of PREMIUM.
<G-vec00345-001-s885><believe.sind><de> Die Veranstalter der Modemessen STYL und KABO sind überzeugt, dass dieses neue System den Ausstellern gefallen und den beiden Brünner Messen im August 2011 ein neues, modisches Ambiente verleihen wird.
<G-vec00345-001-s886><believe.sind><en> At Nokia, we believe that small changes can add up and lead to betterÂ long-term health.
<G-vec00345-001-s886><believe.sind><de> Wir bei Withings sind fest davon überzeugt, dass auch kleine Veränderungen etwas bringen und sich langfristig positiv auf die Gesundheit auswirken können.
<G-vec00345-001-s887><believe.sind><en> We believe that our inclusive culture makes us a better company, a better global competitor, and a better corporate citizen in the many places where we do business.
<G-vec00345-001-s887><believe.sind><de> Wir sind überzeugt, dass unsere offene Kultur uns zu einem besseren Unternehmen macht, zu einem besseren globalen Wettbewerber und Corporate Citizen an den vielen Standorten, an denen wir präsent sind.
<G-vec00345-001-s888><believe.sind><en> Even with a war looming over our heads, we believe in the power of prayer; we believe that the Rosary is stronger then the atomic bomb.
<G-vec00345-001-s888><believe.sind><de> Auch angesichts drohender Kriege sind wir überzeugt, dass der Rosenkranz stärker ist als die Atombombe, wenn wir nur an die Kraft des Gebetes glauben.
<G-vec00345-001-s889><believe.sind><en> But we believe that these challenges can be overcome through working collaboratively with the key stakeholders in the health family.
<G-vec00345-001-s889><believe.sind><de> Wir sind jedoch überzeugt, dass diese Herausforderungen durch die Zusammenarbeit mit Stakeholdern aus dem Gesundheitssektor gemeistert werden können.
<G-vec00345-001-s890><believe.sind><en> We believe that VizQL represents a foundational advancement in the area of data analysis and visualisation.
<G-vec00345-001-s890><believe.sind><de> Wir sind überzeugt, dass VizQL ein grundsätzlicher Fortschritt im Bereich von Datenanalyse und Visualisierung ist.
<G-vec00345-001-s891><believe.sind><en> Diversity Our commitment We at Allianz believe that it is important to have a diverse and inclusive workforce.
<G-vec00345-001-s891><believe.sind><de> Diversity Unsere Verpflichtung Wir von der Allianz sind von der außerordentlichen Bedeutung einer vielfältigen und integrationsfreudigen Belegschaft überzeugt.
<G-vec00345-001-s892><believe.sind><en> Transparency We believe that transparency is essential to create long lasting relationships, built on trust and information.
<G-vec00345-001-s892><believe.sind><de> Transparenz Wir sind überzeugt, dass Transparenz unerlässlich für den Aufbau langfristiger Beziehungen ist, die auf Vertrauen und Information basieren.
<G-vec00345-001-s893><believe.überzeugen><en> “We firmly believe that our ‘Am Zirkus’ project will be a unique offer on the market.
<G-vec00345-001-s893><believe.überzeugen><de> „Wir sind überzeugt, mit dem Projekt „Am Zirkus“ ein einzigartiges Angebot zu schaffen.
<G-vec00345-001-s894><believe.überzeugen><en> The people believe that their mythical ancestor or creator is embodied in the totem.
<G-vec00345-001-s894><believe.überzeugen><de> Man ist überzeugt, dass ihr mythischer Urahn oder Schöpfer von dem Totem verkörpert wird.
<G-vec00345-001-s895><believe.überzeugen><en> A strong majority of economists believe that a robot tax would reduce innovation in our economy and end up hurting everyone.
<G-vec00345-001-s895><believe.überzeugen><de> Eine Robotersteuer, so ist die erdrückende Mehrheit der Ökonomen überzeugt, würde die Innovationkraft unserer Wirtschaft bremsen und uns so letztlich allen schaden.
<G-vec00345-001-s896><believe.überzeugen><en> I strongly believe that trust-based co-operation between the providers of market utilities and regulatory oversight authorities remains the key to the continued successful development of an efficient and secure financial system that can handle fast-changing needs in the future.
<G-vec00345-001-s896><believe.überzeugen><de> Ich bin überzeugt, dass eine Zusammenarbeit basierend auf Vertrauen zwischen den Erbringern dieser Finanzdienstleisungen und den Regulierungsaufsichtsbehörden der Schlüssel bleibt zur weiteren erfolgreichen Entwicklung eines effizienten und sicheren Finanzsystems, das in Zukunft schnell wechselnden Bedürfnissen gerecht werden kann.
<G-vec00345-001-s897><believe.überzeugen><en> They believe that the European Commission's predictions are based on the wrong fiscal multiplier, thereby underestimating the negative impact of further austerity measures on economic growth.
<G-vec00345-001-s897><believe.überzeugen><de> Sie sind überzeugt, dass die Prognosen der Kommission auf dem falschen Finanzmultiplikator beruhen und folglich die negativen Auswirkungen weiterer Sparmaßnahmen auf das Wirtschaftswachstum unterschätzen.
<G-vec00345-001-s898><believe.überzeugen><en> We firmly believe that people make the difference at Eckes-Granini.
<G-vec00345-001-s898><believe.überzeugen><de> Wir sind überzeugt: Menschen machen bei uns den Unterschied.
<G-vec00345-001-s899><believe.überzeugen><en> Melikshah, you strongly believe in the quality of your digital recruiting platform.
<G-vec00345-001-s899><believe.überzeugen><de> Melikshah, du bist ja ziemlich überzeugt von der Qualität eurer digitalen Recruiting-Plattform.
<G-vec00345-001-s900><believe.überzeugen><en> The realists believe in the coworking philosophy in general, but they complain about it’s practical implementation.
<G-vec00345-001-s900><believe.überzeugen><de> Die Realisten überzeugt die Coworking Philosophie im Allgemeinen, allerdings bemängeln sie die praktische Umsetzung.
<G-vec00345-001-s901><believe.überzeugen><en> I believe that Mr. Chan's actions were peaceful and did not cause any public disruption, nor could the message have offended anyone.
<G-vec00345-001-s901><believe.überzeugen><de> Ich bin überzeugt, dass Herrn Chans Taten friedlich waren und keine Störung der Öffentlichkeit bewirkt hatten, noch, das seine Botschaft irgendjemanden beleidigt hat.
<G-vec00345-001-s902><believe.überzeugen><en> At eÿeka, we believe in the collective intelligence and exponential creative power of crowds.
<G-vec00345-001-s902><believe.überzeugen><de> Wir bei eÿeka sind überzeugt von der Power kollektiver Intelligenz und den sich multiplizierenden kreativen Effekten von Crowds.
<G-vec00345-001-s903><believe.überzeugen><en> We firmly believe in the universality of these values, as do many of our closest partners: for example, Japan, South Korea, Australia and India.
<G-vec00345-001-s903><believe.überzeugen><de> Wir sind von der Universalität dieser Werte überzeugt, so wie viele unserer engsten Partner auch: Zum Beispiel Japan, Südkorea, Australien und Indien.
<G-vec00345-001-s904><believe.überzeugen><en> I believe that the ECARF Foundation has a significant contribution to make in these developments.
<G-vec00345-001-s904><believe.überzeugen><de> Ich bin überzeugt, dass die Stiftung ECARF dabei einen entscheidenden Beitrag leisten kann.
<G-vec00345-001-s905><believe.überzeugen><en> I believe that the military operation should have the exclusive aim of destroying ISIS and Al-Qaida-linked groups and should include all relevant regional players.
<G-vec00345-001-s905><believe.überzeugen><de> Ich bin überzeugt, dass die militärische Operation ausschließlich dem Ziel dienen sollte, ISIS und andere Gruppierungen mit Verbindungen zu Al-Kaida zu zerstören, und dass sie alle maßgeblichen regionalen Akteure einbeziehen sollte.
<G-vec00345-001-s906><believe.überzeugen><en> """We firmly believe, however, that it is also worth gaining a better understanding of the physical processes involved in inflammation,"" says Georg Schett."
<G-vec00345-001-s906><believe.überzeugen><de> """Wir sind aber überzeugt, dass es sich lohnt auch die physikalischen Prozesse von Entzündungen besser zu verstehen"", sagt Georg Schett."
<G-vec00345-001-s907><believe.überzeugen><en> With its low-cost production and significant expansion possibilities, we believe that Crowflight is well-positioned to benefit as nickel prices recover.
<G-vec00345-001-s907><believe.überzeugen><de> Angesichts der niedrigen Produktionskosten und des enormen Expansionspotenzials sind wir überzeugt, dass Crowflight gut positioniert ist und profitieren wird, sobald sich die Nickelpreise wieder erholen.
<G-vec00345-001-s908><believe.überzeugen><en> He does believe that our father was a perverse and strange man.
<G-vec00345-001-s908><believe.überzeugen><de> Er ist überzeugt, dass unser Vater ein perverser und sonderbarer Mann war.
<G-vec00345-001-s909><believe.überzeugen><en> And I believe that there are far more hybrids than those we can witness in the 3rd-dimensional, the physical world.
<G-vec00345-001-s909><believe.überzeugen><de> Ich bin überzeugt, dass es weit mehr Hybride gibt als die, die wir in unserer drei-dimensionalen, physischen Welt wahrnehmen.
<G-vec00345-001-s910><believe.überzeugen><en> We believe that will not be a problem for you, because you have been coming to Medjugorje for many years and have your friends and acquaintances here.
<G-vec00345-001-s910><believe.überzeugen><de> Da Sie bereits seit vielen Jahren nach Medjugorje kommen und hier viele Freunde und Bekannte haben, sind wir überzeugt, dass dies für Sie kein Problem sein wird.
<G-vec00345-001-s911><believe.überzeugen><en> Three-quarters of senior management and C 'Suite believe XaaS has positively influenced their business model, products and services
<G-vec00345-001-s911><believe.überzeugen><de> Drei Viertel der Befragten aus Vorstands- und Führungsebene von positivem Einfluss auf Geschäftsmodell, Produkte und Dienstleistungen überzeugt.
<G-vec00345-001-s912><believe.überzeugen><en> We believe that electricity is the future of the entire global energy supply.
<G-vec00345-001-s912><believe.überzeugen><de> Unsere Überzeugung: Strom ist die Zukunft der gesamten globalen Energieversorgung.
<G-vec00345-001-s913><believe.überzeugen><en> I believe that it is our people and the service they provide that makes us special and has driven our success.
<G-vec00345-001-s913><believe.überzeugen><de> Ich bin der Überzeugung, dass es unsere Leute und der von ihnen erbrachte Service sind, was uns so besonders macht und für unseren Erfolg ausschlaggebend war.
<G-vec00345-001-s914><believe.überzeugen><en> "We strongly believe that video entertainment, be it linear or non-linear, sports or fiction, music, with or without virtual reality, is one of the most important competitive differentiators today and in the future"", he says."
<G-vec00345-001-s914><believe.überzeugen><de> "Wir sind der festen Überzeugung, dass Video-Unterhaltung, ob linear oder nicht-linear, Sport oder Fiktion, mit oder ohne virtuelle Realität sowie Musik, heute und in Zukunft einer der wichtigsten Wettbewerbsvorteile ist "", sagt er."
<G-vec00345-001-s915><believe.überzeugen><en> Also we believe that our partners are giving a better service to this particular market.
<G-vec00345-001-s915><believe.überzeugen><de> Zudem sind wir der Überzeugung, dass unsere Partner auf diesem speziellen Markt einen besseren Service leisten.
<G-vec00345-001-s916><believe.überzeugen><en> Only where these three factors coexist in a balanced relationship, we believe, can truly good work be carried out.
<G-vec00345-001-s916><believe.überzeugen><de> Nur dort, wo diese drei Faktoren in einem ausgewogenen Verhältnis auftreten, so unsere Überzeugung, wird wirklich gute Arbeit geleistet.
<G-vec00345-001-s917><believe.überzeugen><en> Sustainable Banking We strongly believe that the principles of sustainability are fundamental to the responsibilities of a bank.It is only be assessing systemic forces – including environmental and social consequences – and the long-term picture that economic activity and bank lending can be healthy.
<G-vec00345-001-s917><believe.überzeugen><de> Nachhaltiges Bankgeschäft Wir sind der festen Überzeugung, dass sich eine Bank in der Erfüllung ihrer Funktion stets an Nachhaltigkeitsgrundsätzen orientieren muss.Nur wenn der systemischen Wirkung von Wirtschaftstätigkeit und Bankkrediten und damit u. a. den Auswirkungen auf Umwelt und Gesellschaft Rechnung getragen wird, auch in der Langzeitperspektive, kann es eine gesunde Entwicklung geben.
<G-vec00345-001-s918><believe.überzeugen><en> But the human inclination to divisiveness is accompanied, I deeply believe, by a profound human impulse to bridge divisions.
<G-vec00345-001-s918><believe.überzeugen><de> Doch die menschliche Neigung zur Uneinigkeit wird – dies ist meine feste Überzeugung – von einem zutiefst menschlichen Impuls begleitet, Trennendes zu überbrücken.
<G-vec00345-001-s919><believe.überzeugen><en> Sustainable Banking We strongly believe that the principles of sustainability are fundamental to the responsibilities of a bank.It is only by assessing systemic forces – including environmental, and social consequences – and the long-term picture that economic activity and bank lending can be healthy.
<G-vec00345-001-s919><believe.überzeugen><de> Nachhaltiges Bankgeschäft Wir sind der festen Überzeugung, dass sich eine Bank in der Erfüllung ihrer Funktion stets an Nachhaltigkeitsgrundsätzen orientieren muss.Nur wenn der systemischen Wirkung von Wirtschaftstätigkeit und Bankkrediten und damit u. a. den Auswirkungen auf Umwelt und Gesellschaft auch in der Langzeitperspektive Rechnung getragen wird, kann es eine gesunde Entwicklung geben.
<G-vec00345-001-s920><believe.überzeugen><en> We believe wealth management is one of the most attractive segments in banking, and global wealth is projected to continue to grow faster than GDP over the next several years.
<G-vec00345-001-s920><believe.überzeugen><de> Die Vermögensverwaltung ist nach unserer Überzeugung eines der attraktivsten Segmente im Bankgewerbe und Prognosen zufolge wird das weltweite Vermögen in den nächsten Jahren weiterhin höhere Zuwachsraten verzeichnen als das BIP.
<G-vec00345-001-s921><believe.überzeugen><en> We firmly believe that any infringement of our Code of Ethics can be best avoided in future, first and foremost through open cooperation in dealing with problems.
<G-vec00345-001-s921><believe.überzeugen><de> Wir sind der Überzeugung, dass Verletzungen des Code of Ethics vor allem durch ein offenes Miteinander bei der Behandlung von Problemfällen am besten für die Zukunft vermieden werden können.
<G-vec00345-001-s922><believe.überzeugen><en> This article is not intended for that kind of people, but for those who live in oppressive regimes, whether these Westerners or not; but I'm not going to be responsible for the misuse that can be given, because I strongly believe in free information.
<G-vec00345-001-s922><believe.überzeugen><de> Dieser Artikel ist nicht für diese Art von Menschen gedacht., aber für diejenigen, die in repressiven Regimes Leben, ob diese Westler oder nicht; aber Ich werde nicht für den Missbrauch verantwortlich, die gegeben werden kann, weil ich der festen in Kostenlose Informationen Überzeugung.
<G-vec00345-001-s923><believe.überzeugen><en> "Please consider them carefully because I believe that understanding them is required in order to answer the first ""W"":"
<G-vec00345-001-s923><believe.überzeugen><de> Denken Sie gründlich darüber nach, denn ich bin der Überzeugung, dass man sie verstehen muss, um das erste „W“ beantworten zu können.
<G-vec00345-001-s924><believe.überzeugen><en> I fundamentally believe that diversity of people enhances innovation.
<G-vec00345-001-s924><believe.überzeugen><de> Ich bin der festen Überzeugung, dass eine vielfältige Belegschaft Innovation fördert.
<G-vec00345-001-s925><believe.überzeugen><en> I firmly believe that today the role of librarians and their efforts should be better understood and appreciated.
<G-vec00345-001-s925><believe.überzeugen><de> Ich bin der festen Überzeugung, dass heutzutage größeres Verständnis und höhere Anerkennung für die Rolle von BibliothekarInnen und ihren Leistungen herrschen sollte.
<G-vec00345-001-s926><believe.überzeugen><en> I believe that there is absolutely no way back to a rigid and stone-walled separation between development and design activities.
<G-vec00345-001-s926><believe.überzeugen><de> Ausblick in die Zukunft Ich bin der festen Überzeugung, dass es keinen Weg zurück zu einer rigiden Abgrenzung zwischen Entwickler- und Designertätigkeiten.
<G-vec00345-001-s927><believe.überzeugen><en> Never once in my life have I had a headache, which fact leads me to believe that I was an alcoholic almost from the start.
<G-vec00345-001-s927><believe.überzeugen><de> Nicht ein einziges Mal in meinem Leben hatte ich Kopfschmerzen, eine Tatsache, die mich zu der Überzeugung führt, daß ich fast von Anfang an ein Alkoholiker war.
<G-vec00345-001-s928><believe.überzeugen><en> All in all, we believe that SOE reform in China is likely to progress quite rapidly and that the potential benefits both for China's economy and for investors could be considerable.
<G-vec00345-001-s928><believe.überzeugen><de> Insgesamt sind wir der Überzeugung, die SOE-Reformen in China werden aller Wahrscheinlichkeit nach recht schnell fortschreiten und der potenzielle Nutzen für die chinesische Wirtschaft und für Anleger dürfte erheblich sein.
<G-vec00345-001-s929><believe.überzeugen><en> We strongly believe that you can expect a little more.
<G-vec00345-001-s929><believe.überzeugen><de> Wir sind der festen Überzeugung, dass Sie ein bisschen mehr erwarten dürfen.
<G-vec00345-001-s930><believe.überzeugen><en> Given the developments observed in the German residential real-estate sector in the past few quarters, the TAG Management Board – as already communicated in previous quarterly reports – has come to believe that the market has now reached a level in some sectors and regions where holding certain assets can no longer be brought into congruence with the cost of equity.
<G-vec00345-001-s930><believe.überzeugen><de> Angesichts der in den vergangenen Quartalen zu beobachtenden Entwicklung im deutschen Wohnimmobiliensektor ist der Vorstand der TAG – wie bereits in den vergangenen Quartalsberichten kommuniziert – zu der Überzeugung gelangt, dass der Markt in einigen Segmenten und Regionen mittlerweile ein Niveau erreicht hat, auf dem eine langfristig orientierte Bestandsbewirtschaftung nicht mehr in Kongruenz zu den Eigenkapitalkosten gebracht werden kann.
<G-vec00345-002-s684><believe.(sich)_halten><en> I believe, however, that to bring out fully the Christological depth of the Rosary it would be suitable to make an addition to the traditional pattern which, while left to the freedom of individuals and communities, could broaden it to include the mysteries of Christ’s public ministry between His Baptism and His Passion.
<G-vec00345-002-s684><believe.(sich)_halten><de> Um den christologischen Gehalt dieses Gebetes deutlicher zu machen, halte ich es für angebracht, eine angemessene Ergänzung vorzunehmen, die auch die Geheimnisse des öffentlichen Lebens zwischen der Taufe und dem Leidensweg Christi einbezieht, wobei ich es dem Einzelnen und den Gemeinschaften überlasse, davon Gebrauch zu machen.
<G-vec00345-002-s685><believe.(sich)_halten><en> I believe that structured procedures are vital in oncology, for instance to create guidelines and establish systematic training programs.
<G-vec00345-002-s685><believe.(sich)_halten><de> Strukturierte Verfahren in der Onkologie halte ich für enorm wichtig, um beispielsweise Leitlinien zu kreieren und systematische Schulungen zu etablieren.
<G-vec00345-002-s686><believe.(sich)_halten><en> I believe that it is important to continue to enhance our systems and capabilities steadily, while keeping up with changes of situations of the time.
<G-vec00345-002-s686><believe.(sich)_halten><de> Ich halte es für wichtig, unsere Systeme und Fähigkeiten kontinuierlich zu verbessern und gleichzeitig mit den Veränderungen der jeweiligen Situation Schritt zu halten.
<G-vec00345-002-s687><believe.(sich)_halten><en> “I believe that the concept we have here is the best possible solution for hotel applications”, claims Ulrich Budde with conviction.
<G-vec00345-002-s687><believe.(sich)_halten><de> „Das hier umgesetzte Konzept halte ich für die beste Lösung für Hotelanwendungen“, ist Ulrich Budde überzeugt.
<G-vec00345-002-s688><believe.(sich)_halten><en> Personally, I believe this is one of the most serious failings in the church today.
<G-vec00345-002-s688><believe.(sich)_halten><de> Ich persönlich halte dies für eine der größten Schwachstellen der Gemeinden heut-zutage.
<G-vec00345-002-s689><believe.(sich)_halten><en> I believe there is considerable promise in strengthening the ESM.
<G-vec00345-002-s689><believe.(sich)_halten><de> Ich halte eine Stärkung des ESM für vielversprechend.
<G-vec00345-002-s690><believe.(sich)_halten><en> Of course, there are exceptions to this with certain new watches, but I believe the theory is generally true.
<G-vec00345-002-s690><believe.(sich)_halten><de> Natürlich gibt es in dieser Hinsicht bei bestimmten neuen Uhren Ausnahmen, aber im Allgemeinen halte ich diese Theorie für richtig.
<G-vec00345-002-s691><believe.(sich)_halten><en> These actions I believe to be very effective.
<G-vec00345-002-s691><believe.(sich)_halten><de> Diese Aktionen halte ich für sehr wirksam.
<G-vec00345-002-s692><believe.(sich)_halten><en> I believe it to be from the 1920s.
<G-vec00345-002-s692><believe.(sich)_halten><de> Ich halte es für aus den 1920er Jahren.
<G-vec00345-002-s693><believe.(sich)_halten><en> My city is under threat of destruction and this relic — if it is what I believe it to be — may offer the solution to a dilemma that grows more urgent by the day.
<G-vec00345-002-s693><believe.(sich)_halten><de> Meine Stadt droht, zerstört zu werden und dieses Relikt — wenn es sich dabei um das handelt, wofür ich es halte — könnte die Lösung für ein Dilemma anbieten, das mit jedem Tag dringlicher wird.
<G-vec00345-002-s694><believe.(sich)_halten><en> I believe that especially important is that people living and work here takle the problems themselves and that they try to solve their way.
<G-vec00345-002-s694><believe.(sich)_halten><de> Für besonders wichtig halte ich, dass die Menschen, die hier leben und arbeiten, die Probleme selbst anpacken und sie auf ihre Weise lösen versuchen.
<G-vec00345-002-s695><believe.(sich)_halten><en> During the subsequent panel on the same issue, he emphasised: “I believe that global change – so the question of climate change, rapid population growth on our planet and the associated question of food security – is the most important area for space applications in this century.
<G-vec00345-002-s695><believe.(sich)_halten><de> Im anschließenden Panel zu diesem Thema betonte er: "Ich halte das Thema Global Change - also die Frage des Klimawandels und des enormen Bevölkerungswachstums auf dieser Erde und die damit verbundene Ernährungssicherheit - für das wichtigste Anwendungsfeld der Raumfahrt in diesem Jahrhundert.
<G-vec00345-002-s696><believe.(sich)_halten><en> In view of the importance and particularities of this banking sector, I believe indirect European banking supervision to be necessary and appropriate.
<G-vec00345-002-s696><believe.(sich)_halten><de> Wegen der Bedeutung und den Besonderheiten dieses Bankensektors halte ich eine indirekte europäische Aufsicht für notwendig und angemessen.
<G-vec00345-002-s697><believe.(sich)_halten><en> For example, macro scenarios – in other words shocks involving shares, currencies or macro indices – can be directly interpreted, and I believe it is essential to be familiar with their impact on your own bank portfolio.
<G-vec00345-002-s697><believe.(sich)_halten><de> Beispielsweise Makroszenarien, das heißt Schocks auf Aktien, Währungen oder Makroindizes, sind unmittelbar interpretierbar, und ich halte es für unabdingbar, deren Wirkung auf das eigene Bankportfolio zu kennen.
<G-vec00345-002-s698><believe.(sich)_halten><en> I believe it is authentic.
<G-vec00345-002-s698><believe.(sich)_halten><de> Ich halte es für authentisch.
<G-vec00345-002-s699><believe.(sich)_halten><en> I believe it is urgently necessary for employers to formulate a strategy for digital transformation.
<G-vec00345-002-s699><believe.(sich)_halten><de> Ich halte es für dringend notwendig, dass die Arbeitgeber eine Vorstellung für die digitale Transformation formulieren.
<G-vec00345-002-s700><believe.(sich)_halten><en> And yet I believe these skills are indispensable if you want to forge a successful medical and scientific career in a position of leadership.
<G-vec00345-002-s700><believe.(sich)_halten><de> Ich halte diese Kompetenzen jedoch für eine erfolgreiche medizinisch-wissenschaftliche Karriere in einer Führungsposition für unabdingbar.
<G-vec00345-002-s701><believe.(sich)_halten><en> I believe your interpretation is wrong, but would not permit myself to accuse someone who in this tricky field took a different view from my own, of standing a biblical passage on its head, and I would ask you, reciprocally, to be a little more restrained with such utterances.
<G-vec00345-002-s701><believe.(sich)_halten><de> Ich halte Ihre Auslegung für falsch, würde mir aber nie den Vorwurf erlauben, dass bei diesem schwierigen Gebiet jemand, der nicht meinem Verständnis folgt, hier Bibeltexte verdrehen würde und bitte auch umgekehrt, mit solchen Äußerungen etwas zurückhaltend zu sein.
<G-vec00345-002-s702><believe.(sich)_halten><en> I believe that this is a positive sign.
<G-vec00345-002-s702><believe.(sich)_halten><de> Das alles halte ich für ein gutes Zeichen.
<G-vec00345-002-s266><believe.denken><en> We believe that the WTO should urge China to adhere to the conditions of the International Convention on Human Rights, of which it is a signatory.
<G-vec00345-002-s266><believe.denken><de> Wir denken, die WHO sollte China dazu drängen, die Bedingungen der Internationalen Konvention für Menschenrechte, die es auch unterzeichnet hat, einzuhalten.
<G-vec00345-002-s267><believe.denken><en> “She doesn’t necessarily believe in the superstitions of other tribes she encounters, who believe that some of the Machines are demons, but she knows that they’re things that have a function and purpose.
<G-vec00345-002-s267><believe.denken><de> „Sie glaubt nicht unbedingt an den Aberglauben der anderen Stämme, die denken, dass die Maschinen Dämonen sind, aber sie weiß, dass die Dinge eine Funktion und einen Zweck haben.
<G-vec00345-002-s268><believe.denken><en> We believe that this partnership with Baraka is an excellent opportunity to strengthen our brand’s positioning in Spain and in the world", affirmed Carmen and Luis Riu, the CEOs of RIU Hotels & Resorts.
<G-vec00345-002-s268><believe.denken><de> Wir denken, dass diese Allianz mit Baraka eine ausgezeichnete Chance ist, die Position unserer Marke in Spanien und in der Welt zu festigen“, erklären Carmen und Luis Riu, CEOs von RIU Hotels & Resorts.
<G-vec00345-002-s269><believe.denken><en> We become attached to our falls and we start to believe that they are stronger than the grace of Jesus.
<G-vec00345-002-s269><believe.denken><de> Wir binden uns an unsere Fehltritte und wir denken, dass sie stärker sind als die Gnade Jesu.
<G-vec00345-002-s270><believe.denken><en> An “eyeopener” for all who believe to be a human being, but in fact we are all still animals.
<G-vec00345-002-s270><believe.denken><de> Ein „eyeopener“ für alle, die denken, Mensch zu sein, aber in Wahrheit sind wir alle noch Tiere.
<G-vec00345-002-s271><believe.denken><en> We encourage reflections about social market economy because we believe that this economic model combines an efficient market with social equality.
<G-vec00345-002-s271><believe.denken><de> Wir regen Reflexionen über die Soziale Marktwirtschaft an, da wir denken, dass dieses Wirtschaftsmodell Markteffizienz mit sozialem Ausgleich verbindet.
<G-vec00345-002-s272><believe.denken><en> If you believe that the Site contains elements that infringe copyright in your work, please follow the procedures outlined in Section 12 of these Terms of Use.
<G-vec00345-002-s272><believe.denken><de> Wenn Sie denken, dass die Website Elemente enthält, die Ihr Urheberrecht verletzen, folgen Sie bitte den Anweisungen in Abschnitt 12 dieser Nutzungsbedingungen.
<G-vec00345-002-s273><believe.denken><en> Some of the most distinguished homin scholars believe that the resurrection done by the Powers, and especially the one offered by the Kamis, could be linked with a healing spell, such as the ones that homin mages use, but much more powerful, with the ability to repair damage that should normally be fatal.
<G-vec00345-002-s273><believe.denken><de> Einige der bedeutenden Gelehrten der Homins denken, die Wiederbelebung durch die Mächte, auch die von den Kamis angebotene, sei vergleichbar mit einem Heilzauber durch Magier der Homins, aber viel leistungsfähiger; geeignet, normalerweise tödlichen Schaden rückgängig zu machen.
<G-vec00345-002-s274><believe.denken><en> With our future EV plans, Formula E was the obvious choice and we believe that the benefits are enormous.
<G-vec00345-002-s274><believe.denken><de> Vor dem Hintergrund unserer künftigen Elektroauto-Pläne war die FIA Formel E die logische Wahl; wir denken, dass die Synergieeffekte und Vorteile immens sein werden.
<G-vec00345-002-s275><believe.denken><en> We believe that our interaction with nature and between humans shall be “clean” and responsible.
<G-vec00345-002-s275><believe.denken><de> Wir denken, dass unser Zusammenspiel mit der Natur und zwischen den Menschen “sauber” und verantwortungsbewusst sein sollte.
<G-vec00345-002-s276><believe.denken><en> No one is exempt failure, even those who believe being successful and were born with a good star had their difficult moments.
<G-vec00345-002-s276><believe.denken><de> Niemand kann das Versagen vermeiden, auch diejenigen die erfolgreich sind, und wir denken, sie seien mit einem guten Stern geboren, alle hatten ihre schwierigen Momente.
<G-vec00345-002-s277><believe.denken><en> And to believe, all of this from a tiny slightly diet pill.
<G-vec00345-002-s277><believe.denken><de> Und um zu denken, all dies von einem winzig kleinen Diät-Pille.
<G-vec00345-002-s278><believe.denken><en> Modularity We believe that modularity means flexibility – The versatile usability modular design guarantees individual adaptability.
<G-vec00345-002-s278><believe.denken><de> Wir denken Modularität heißt Flexibilität — denn durch die vielseitige Verwendbarkeit im Baukastenprinzip bleibt die individuelle Anpassungsfähigkeit garantiert.
<G-vec00345-002-s279><believe.denken><en> Instead, we believe that the yield on 10-year Treasuries will move towards 1-1.5% over the next 12 months.
<G-vec00345-002-s279><believe.denken><de> Wir denken eher, dass sich die Rendite der 10-jährigen Treasuries innerhalb der nächsten zwölf Monate in Richtung 1-1,5% entwickeln wird.
<G-vec00345-002-s280><believe.denken><en> We believe that both parties are aware of the negative effects of their aggressive tariff policies.
<G-vec00345-002-s280><believe.denken><de> Wir denken, dass sich beide Parteien der negativen Auswirkungen ihrer aggressiven Zollpolitik bewusst sind.
<G-vec00345-002-s281><believe.denken><en> We believe that this is only possible when you have an absolutely competent contact person at HKM.
<G-vec00345-002-s281><believe.denken><de> Wir denken, dass dies nur dann möglich ist, wenn Sie bei HKM einen rundum kompetenten Ansprechpartner haben.
<G-vec00345-002-s282><believe.denken><en> We believe the index creators will likely be very cautious in regards to putting a heavy weighting on Chinese A shares.
<G-vec00345-002-s282><believe.denken><de> Wir denken, Indexanbieter werden aller Wahrscheinlichkeit nach äußerst vorsichtig sein, chinesischen A-Aktien eine hohe Gewichtung zuzuweisen.
<G-vec00345-002-s283><believe.denken><en> You may believe that you love ice cream, but you really love your blast of dopamine.
<G-vec00345-002-s283><believe.denken><de> Sie denken vielleicht, Sie mögen Eiscrème, doch in Wirklichkeit mögen Sie den Dopamin-Kick.
<G-vec00345-002-s284><believe.denken><en> We don’t believe that our products need to look the same, but they do need to exude the same qualities.
<G-vec00345-002-s284><believe.denken><de> Wir denken nicht, dass unsere Produkte alle gleich aussehen müssen – aber sie müssen alle die gleichen Eigenschaften vorweisen.
<G-vec00345-002-s304><believe.fassen><en> I couldn’t believe how lucky I was.
<G-vec00345-002-s304><believe.fassen><de> Ich konnte es gar nicht fassen, welches Glück ich hatte.
<G-vec00345-002-s305><believe.fassen><en> Used to commanding others, and obedience, he can’t believe it when a hairdresser with tempting curves chops off a hunk of his precious mane.
<G-vec00345-002-s305><believe.fassen><de> Daran gewöhnt, dass ihm Gehorsam entgegengebracht wird, kann er es kaum fassen, als eine Friseurin mit verlockenden Kurven ihm ein zu großes Stück seiner edlen Mähne abschneidet.
<G-vec00345-002-s306><believe.fassen><en> Now that the days are getting shorter again and we can't even believe that the dream summer 2018 is actually already over, you might consider whether it would not be the right time to extend the summer again and a long-cherished island dream To make it come true.
<G-vec00345-002-s306><believe.fassen><de> Jetzt, wo die Tage wieder kürzer werden und wir es noch gar nicht fassen können, dass der Traumsommer 2018 tatsächlich schon vorbei sein soll, überlegen Sie vielleicht, ob nicht genau jetzt die richtige Zeit wäre, den Sommer nochmal zu verlängern und einen langgehegten Inseltraum wahr werden zu lassen.
<G-vec00345-002-s307><believe.fassen><en> I was already aware of Iceland’s beauty, but my friend and companion, Bartek from the group Die Orsons, was visiting Iceland for the first time and could hardly believe how beautiful it is here.
<G-vec00345-002-s307><believe.fassen><de> Ich kannte das ja schon, aber mein Freund und Begleiter Bartek von Die Orions war das erste Mal auf Island und konnte kaum fassen, wie schön es hier ist.
<G-vec00345-002-s308><believe.fassen><en> When they finally stand there, the stone bridge that seems to have been created only by erosion, the pair of mushroom-shaped rocks, the towering, phallic mountaintop, it's hard to believe that one has just seen workers creating all of this.
<G-vec00345-002-s308><believe.fassen><de> Wenn sie schließlich da stehen, die Steinbrücke, die nur durch Erosion entstanden zu sein scheint, das Paar pilzförmiger Felsen, die hoch aufragende, phallusförmige Bergspitze, kann man es kaum fassen, dass man gerade noch Arbeiter beobachtet hat, die all das gebaut haben.
<G-vec00345-002-s309><believe.fassen><en> I can't believe it's already April, and it's so long since my last post.
<G-vec00345-002-s309><believe.fassen><de> Ich kann es kaum fassen, schon ist es April, und mein letzter Post liegt Monate zurück.
<G-vec00345-002-s310><believe.fassen><en> Some of the parents can hardly believe that there are people out there that want to support and help them.
<G-vec00345-002-s310><believe.fassen><de> Manche Eltern können es kaum fassen, dass es Menschen gibt, die sie unterstützen und ihnen helfen wollen.
<G-vec00345-002-s311><believe.fassen><en> (Clare) Mother, I cannot believe that we are out of time.
<G-vec00345-002-s311><believe.fassen><de> (Clare) Mutter, ich kann es einfach nicht fassen, dass uns die Zeit ausgeht.
<G-vec00345-002-s312><believe.fassen><en> When he was announced as the winner of the „Leading Actor“ category, he simply couldn’t believe it.
<G-vec00345-002-s312><believe.fassen><de> Als er als Gewinner der “Bester Hauptdarsteller”-Kategorie enthüllt wurde, konnte er es selbst überhaupt nicht fassen.
<G-vec00345-002-s313><believe.fassen><en> Some look shocked, others laugh or can not believe it.
<G-vec00345-002-s313><believe.fassen><de> Manche schauen schockiert, andere lachen oder können es einfach nicht fassen.
<G-vec00345-002-s314><believe.fassen><en> Kathy and we both could not believe it.
<G-vec00345-002-s314><believe.fassen><de> Kathy und auch wir konnten es nicht fassen.
<G-vec00345-002-s315><believe.fassen><en> He can hardly believe it.
<G-vec00345-002-s315><believe.fassen><de> Er kann es kaum fassen.
<G-vec00345-002-s316><believe.fassen><en> He cannot believe that, for instance, the plastic waste on the Pazific Ocean has a total dimension of as much as the area of Central Europe.
<G-vec00345-002-s316><believe.fassen><de> Er kann es nicht fassen, dass zum Beispiel im Pazifik der Plastikmüll sich auf einer Fläche der Größe Mitteleuropas auftürmt.
<G-vec00345-002-s317><believe.fassen><en> I couldn’t believe how perfect she was.
<G-vec00345-002-s317><believe.fassen><de> Ich konnte kaum fassen, wie perfekt sie war.
<G-vec00345-002-s318><believe.fassen><en> It is so unique and surreal, you almost won’t believe your eyes!
<G-vec00345-002-s318><believe.fassen><de> Der Anblick ist einzigartig und geradezu surreal, Sie werden kaum fassen können, was sich da vor Ihren Augen darbietet.
<G-vec00345-002-s319><believe.fassen><en> Rustam Daudov can hardly believe the verdict of the German expert.
<G-vec00345-002-s319><believe.fassen><de> Rustam Daudow kann die Einschätzung der deutschen Expertin kaum fassen.
<G-vec00345-002-s320><believe.fassen><en> They could not believe what the Chinese Communist Party has done to this peaceful group of practitioners in China.
<G-vec00345-002-s320><believe.fassen><de> Sie konnten es nicht fassen, was die KPCh dieser friedlichen Gruppe von Praktizierenden in China angetan hat.
<G-vec00345-002-s321><believe.fassen><en> For a long time we could hardly believe our luck.
<G-vec00345-002-s321><believe.fassen><de> Lange konnten wir unser Glück nicht fassen.
<G-vec00345-002-s322><believe.fassen><en> It’s hard to believe that 11 years have gone by since the release of Consolers of the Lonely, the latest studio album of this band of four from Detroit which won a Grammy award for its outstanding production.
<G-vec00345-002-s322><believe.fassen><de> Hi-Res Es ist kaum zu fassen, dass elf Jahre vergangen sind seit dem Erscheinen von Consolers of the Lonely, dem letzten Studioalbum des Quartetts aus Detroit, das für seine makellose Produktion mit einem Grammy ausgezeichnet wurde.
<G-vec00345-002-s323><believe.finden><en> We believe that our premium products deserve to be sent in worthy packaging.
<G-vec00345-002-s323><believe.finden><de> Wir finden, dass unsere hochwertigen Produkte einen würdigen Rahmen benötigen.
<G-vec00345-002-s324><believe.finden><en> We believe that technology should lead to an end result — not be the end result. We seek a technology that strives to further define the essence of the piece — while at the same time creating a better relationship between object and person.
<G-vec00345-002-s324><believe.finden><de> Wir finden: Technologie sollte zu einem Ergebnis führen – und nicht schon das Ergebnis sein.Wir suchen nach einer Technologie, die das Wesen eines Werkstücks noch besser herausarbeitet – und zugleich die Beziehung zwischen Gegenstand und Mensch verbessert.
<G-vec00345-002-s325><believe.finden><en> We believe that insights from their research, which appeared in the International Journal of Research in Marketing in 2001, are interesting for both brand manufacturers and retailers.
<G-vec00345-002-s325><believe.finden><de> Wir finden, dass die Erkenntnisse aus ihrer Arbeit, die 2001 im International Journal of Research in Marketing erschienen sind, sowohl für Markenhersteller als auch für Händler interessant sind und möchten Ihnen diese gerne vorstellen.
<G-vec00345-002-s326><believe.finden><en> “In view of the lack of activity on the part of such historically Russian countries as Russia, Ukraine, Byelorussia, the Baltics, the participants of the Donetsk Russian Forum believe that in the existing situation we have to urgently resolve the issue of creating permanent Russian Centers in the countries occupying the originally Russian lands in order to join efforts towards the establishment of a new Universal Russian Space as the fundamental component of the Russian People liberation and joining our forces around the Russian Superethnos Idea.
<G-vec00345-002-s326><believe.finden><de> „Wenn man die Passivität von historisch russischen Staaten berücksichtigt, solchen wie Russland, Ukraine, Belarus, Baltikum, finden die Teilnehmer des Russischen Forums in Donezk, dass unter den heutigen Bedingungen schnellstens die Frage über die Erschaffung von Russischen Zentren in den Staaten gelöst werden muss, die urrussische Territorien zurzeit besetzen, um die Bemühungen bei der Erschaffung eines neuen weltweiten Russischen Raums als eines grundlegenden Teils des Befreiungskampfes des russischen Volkes zu vereinen und die eigenen Kräfte um die Russische Idee der Superethnie herum zu konsolidieren.
<G-vec00345-002-s327><believe.finden><en> Discerning men are used to considering their outfits with care; we believe the same consideration should be extended to accessories.
<G-vec00345-002-s327><believe.finden><de> Anspruchsvolle Männer sind daran gewöhnt, ihre Kleidung sorgfältig auszuwählen, und wir finden, dieselbe Sorgfalt sollte auch für Accessoires gelten.
<G-vec00345-002-s328><believe.finden><en> Some experts believe that this situation is only strengthening our solidarity.
<G-vec00345-002-s328><believe.finden><de> Manche Experten finden, dass diese Situation die Solidarität zwischen unseren Ländern fördern könnte.
<G-vec00345-002-s329><believe.finden><en> We believe that the Small Wallet is particularly suitable for people who value quality and functionality: commuters, travellers, family fathers and businessmen.
<G-vec00345-002-s329><believe.finden><de> Wir finden, dass sich das Small Wallet besonders für Menschen eignet, die auf Qualität achten und Funktionalität lieben: für Pendler, Reisende, Familienväter und Businessmänner.
<G-vec00345-002-s330><believe.finden><en> We believe that enterprise software shouldn’t look or feel any different than the applications we use every day.
<G-vec00345-002-s330><believe.finden><de> Wir finden: Unternehmenssoftware sollte nicht anders zu bedienen sein als die Anwendungen, die wir jeden Tag nutzen.
<G-vec00345-002-s331><believe.finden><en> In Italy, too, the Italians believe, foreign investors should rethink and focus on a long-term strategy.
<G-vec00345-002-s331><believe.finden><de> Auch in Italien sollten die ausländischen Investoren umdenken und auf Langfrist-Strategie setzen, finden die Italiener.
<G-vec00345-002-s332><believe.finden><en> We believe only by fully understanding your goals can we create the right way to help you.
<G-vec00345-002-s332><believe.finden><de> Nur wenn wir Ihre Ziele genau verstehen, können wir den richtigen Weg finden, Ihnen zu helfen.
<G-vec00345-002-s333><believe.finden><en> Believe it or not, it is not even that difficult play poker for fun either.
<G-vec00345-002-s333><believe.finden><de> Einen Platz zu finden um Poker zum Spaß zu spielen ist nicht unbedingt eine schwierige Aufgabe.
<G-vec00345-002-s334><believe.finden><en> However, if you believe that the optimizer missed a better query plan, then this option can be switched off (optimizer_prune_level=0) with the risk that query compilation may take much longer.
<G-vec00345-002-s334><believe.finden><de> Wenn Sie allerdings das Gefühl haben, dass der Optimierer einen besseren Abfrageplan hätte finden können, dann können Sie die Option auch abschalten (optimizer_prune_level=0); allerdings besteht dann das Risiko, dass die Abfragekompilierung deutlich länger dauert.
<G-vec00345-002-s335><believe.finden><en> We believe that this is the best way.
<G-vec00345-002-s335><believe.finden><de> Wir finden, das ist der beste Weg.
<G-vec00345-002-s336><believe.finden><en> We believe that you deserve to look and feel just as great as you are.
<G-vec00345-002-s336><believe.finden><de> Und wir finden, dass Ihr es verdient habt, Euch genauso großartig zu fühlen, wie Ihr seid.
<G-vec00345-002-s337><believe.finden><en> We believe that mobile applications are very important, which is why we spend a lot of energy on them.
<G-vec00345-002-s337><believe.finden><de> Wir finden die mobilen Apps sehr wichtig, entsprechend viel Energie legen wir da rein.
<G-vec00345-002-s338><believe.finden><en> It only takes a striking idea and quality materials – which, we believe, is the case of Marbet’s new collection, ideal for creating such wall and ceiling compositions,” says Łukasz Fragstein, designer of the Marbet Design collections.
<G-vec00345-002-s338><believe.finden><de> Alles, was es dazu braucht, ist eine interessante Idee und das richtige Material – wir finden, dass die neue Kollektion von Marbet genau das richtige Rohmaterial ist, um solche Wand- und Deckenkompositionen zu schaffen“, so Łukasz Fragstein, Designer der Kollektionen.
<G-vec00345-002-s339><believe.finden><en> We believe an occupation should ideally be a vocation.
<G-vec00345-002-s339><believe.finden><de> Wir finden, ein Beruf sollte idealerweise eine Berufung sein.
<G-vec00345-002-s340><believe.finden><en> We believe that online ordering should be even easier than shopping in the store.
<G-vec00345-002-s340><believe.finden><de> Wir finden, dass eine online Bestellung noch einfacher als der Einkauf in einem Geschäft sein muss.
<G-vec00345-002-s341><believe.finden><en> As a hotel marketing agency, we believe that we are only good if we can increase the revenue and profits of our customers, who are the most important resource we have.
<G-vec00345-002-s341><believe.finden><de> Als Hotelmarketing-Agentur finden wir, dass wir nur dann gut sind, wenn wir den Umsatz und Gewinn unserer Kunden steigern, die unsere wichtigste Ressource sind.
<G-vec00345-002-s798><believe.glauben><en> And believe it or not - the minimal load on the computer section also has a positive effect on sound.
<G-vec00345-002-s798><believe.glauben><de> Und ob Sie es glauben, oder nicht - die minimale Auslastung der Computersektion wirkt sich auch klanglich positiv aus.
<G-vec00345-002-s799><believe.glauben><en> Epimedium Leaf – Believe it or not, this component is utilized in the major prescription brands of impotence items.
<G-vec00345-002-s799><believe.glauben><de> Epimedium Blatt – Ob Sie es glauben oder nicht, wird diese Komponente in den wichtigsten verschreibungspflichtigen Marken von Impotenz Produkte verwendet.
<G-vec00345-002-s800><believe.glauben><en> Believe it or not, we're even lazier than that.
<G-vec00345-002-s800><believe.glauben><de> Ob Sie es glauben oder nicht: wir sind sogar noch fauler.
<G-vec00345-002-s801><believe.glauben><en> Driving around Barcelona: not as hard as you’d think in a city like this, with some big roads traversing the city from north to south, one giant one cutting it diagonally (called Diagonal, believe it or not) and a ring road running around it.
<G-vec00345-002-s801><believe.glauben><de> Durch Barcelona fahren: nicht so schwer wie man in einer Stadt wie dieser denken würde, mit einigen großen Straßen, die die Stadt von Norden nach Süden durchqueren, ein Riese schneidet sie diagonal (genannt Diagonal, ob Sie es glauben oder nicht) und eine Ringstraße umrunden.
<G-vec00345-002-s802><believe.glauben><en> You are their most meaningful mentor, and believe it or not, you are their hero in countless ways.
<G-vec00345-002-s802><believe.glauben><de> Sie sind seine bedeutendste Vertrauensperson und, ob Sie es glauben oder nicht, auf unzählige Weise sein Held.
<G-vec00345-002-s803><believe.glauben><en> Believe it or not, all these hours of repetitive training cardio is not the best way to lose fat and reveal your abs.
<G-vec00345-002-s803><believe.glauben><de> Ob Sie es glauben oder nicht, sind alle diese Stunde von sich wiederholenden Cardio-Training nicht der beste Weg, Körperfett zu verlieren und zeigen Sie Ihre Bauchmuskeln.
<G-vec00345-002-s804><believe.glauben><en> Believe it or not, food is one of the most effective ways to lose weight and stay healthy, if you make the right choices and stay consistent.
<G-vec00345-002-s804><believe.glauben><de> Ob Sie es glauben oder nicht, essen ist eine der effektivsten Möglichkeiten, um Gewicht zu verlieren und gesund zu bleiben, wenn Sie die richtigen Entscheidungen treffen und konsistent bleiben.
<G-vec00345-002-s805><believe.glauben><en> And believe it or not: I had already come into contact with electric mobility during my apprenticeship.
<G-vec00345-002-s805><believe.glauben><de> Und ob Sie es glauben oder nicht: Auch in meiner Ausbildung bin ich schon mit Elektromobilität in Berührung gekommen.
<G-vec00345-002-s806><believe.glauben><en> Believe it or not, this is normal – challenging and frustrating – but normal.
<G-vec00345-002-s806><believe.glauben><de> Ob Sie es glauben oder nicht, das ist normal – herausfordernd und frustrierend, aber normal.
<G-vec00345-002-s807><believe.glauben><en> Believe it or not, but since then I am always asked what makes my pastry so special.
<G-vec00345-002-s807><believe.glauben><de> Ob Sie es glauben oder nicht, aber man wird Sie immer fragen, was Ihr Gebäck so besonders macht.
<G-vec00345-002-s808><believe.glauben><en> Believe it or not, but when Rossella Vanon began her career she mainly shot nature macro and landscapes.
<G-vec00345-002-s808><believe.glauben><de> Ob Sie es glauben oder nicht, aber zu Beginn ihrer Karriere fotografierte Rossella Vanon vor allem Naturmakros und Landschaften.
<G-vec00345-002-s809><believe.glauben><en> Believe it or not, sometimes app developers write code that doesn’t work.
<G-vec00345-002-s809><believe.glauben><de> Ob Sie es glauben oder nicht, manchmal schreiben App-Entwickler Code, der nicht funktioniert.
<G-vec00345-002-s810><believe.glauben><en> Believe it or not, they are actually related to the popular pet guinea pig.
<G-vec00345-002-s810><believe.glauben><de> Ob Sie es glauben oder nicht, es handelt sich um Verwandte unserer Meerschweinchen.
<G-vec00345-002-s811><believe.glauben><en> Believe it or not, professional restoration can really add value to a rare antique, but amateur repairs often affect value negatively.
<G-vec00345-002-s811><believe.glauben><de> Ob Sie es glauben oder nicht, eine professionelle Restaurierung kann für eine seltene Antiquität einen Mehrwert bringen.
<G-vec00345-002-s812><believe.glauben><en> Believe it or not, men too go bonkers over these sparks.
<G-vec00345-002-s812><believe.glauben><de> Ob Sie es glauben oder nicht, auch Männer gehen BONKERS über diese Funken.
<G-vec00345-002-s813><believe.glauben><en> Believe it or not, Rakuten Japan is a great place to find Japan-exclusive K-Pop merchandise that you won’t find overseas.
<G-vec00345-002-s813><believe.glauben><de> Ob Sie es glauben oder nicht, aber Rakuten Japan ist eine gute Adresse für ausschließlich in Japan erhältlichen K-Pop-Merchandise, der im Ausland nicht erhältlich ist.
<G-vec00345-002-s815><believe.glauben><en> Level I measures how the learners felt about the training, i.e., did they like it? Did they believe they learned something?
<G-vec00345-002-s815><believe.glauben><de> Stufe 1 misst wie die Teilnehmer das Training empfunden haben, wie es ihnen gefallen hat und ob sie glauben, etwas gelernt zu haben.
<G-vec00345-002-s816><believe.glauben><en> Believe it or not, only 42% of the country’s population is Akan.
<G-vec00345-002-s816><believe.glauben><de> Ob Sie es glauben oder nicht, nur 42% der Bevölkerung des Landes sind Akan.
<G-vec00345-002-s684><believe.halten><en> I believe, however, that to bring out fully the Christological depth of the Rosary it would be suitable to make an addition to the traditional pattern which, while left to the freedom of individuals and communities, could broaden it to include the mysteries of Christ’s public ministry between His Baptism and His Passion.
<G-vec00345-002-s684><believe.halten><de> Um den christologischen Gehalt dieses Gebetes deutlicher zu machen, halte ich es für angebracht, eine angemessene Ergänzung vorzunehmen, die auch die Geheimnisse des öffentlichen Lebens zwischen der Taufe und dem Leidensweg Christi einbezieht, wobei ich es dem Einzelnen und den Gemeinschaften überlasse, davon Gebrauch zu machen.
<G-vec00345-002-s685><believe.halten><en> I believe that structured procedures are vital in oncology, for instance to create guidelines and establish systematic training programs.
<G-vec00345-002-s685><believe.halten><de> Strukturierte Verfahren in der Onkologie halte ich für enorm wichtig, um beispielsweise Leitlinien zu kreieren und systematische Schulungen zu etablieren.
<G-vec00345-002-s686><believe.halten><en> I believe that it is important to continue to enhance our systems and capabilities steadily, while keeping up with changes of situations of the time.
<G-vec00345-002-s686><believe.halten><de> Ich halte es für wichtig, unsere Systeme und Fähigkeiten kontinuierlich zu verbessern und gleichzeitig mit den Veränderungen der jeweiligen Situation Schritt zu halten.
<G-vec00345-002-s687><believe.halten><en> “I believe that the concept we have here is the best possible solution for hotel applications”, claims Ulrich Budde with conviction.
<G-vec00345-002-s687><believe.halten><de> „Das hier umgesetzte Konzept halte ich für die beste Lösung für Hotelanwendungen“, ist Ulrich Budde überzeugt.
<G-vec00345-002-s688><believe.halten><en> Personally, I believe this is one of the most serious failings in the church today.
<G-vec00345-002-s688><believe.halten><de> Ich persönlich halte dies für eine der größten Schwachstellen der Gemeinden heut-zutage.
<G-vec00345-002-s689><believe.halten><en> I believe there is considerable promise in strengthening the ESM.
<G-vec00345-002-s689><believe.halten><de> Ich halte eine Stärkung des ESM für vielversprechend.
<G-vec00345-002-s690><believe.halten><en> Of course, there are exceptions to this with certain new watches, but I believe the theory is generally true.
<G-vec00345-002-s690><believe.halten><de> Natürlich gibt es in dieser Hinsicht bei bestimmten neuen Uhren Ausnahmen, aber im Allgemeinen halte ich diese Theorie für richtig.
<G-vec00345-002-s691><believe.halten><en> These actions I believe to be very effective.
<G-vec00345-002-s691><believe.halten><de> Diese Aktionen halte ich für sehr wirksam.
<G-vec00345-002-s692><believe.halten><en> I believe it to be from the 1920s.
<G-vec00345-002-s692><believe.halten><de> Ich halte es für aus den 1920er Jahren.
<G-vec00345-002-s693><believe.halten><en> My city is under threat of destruction and this relic — if it is what I believe it to be — may offer the solution to a dilemma that grows more urgent by the day.
<G-vec00345-002-s693><believe.halten><de> Meine Stadt droht, zerstört zu werden und dieses Relikt — wenn es sich dabei um das handelt, wofür ich es halte — könnte die Lösung für ein Dilemma anbieten, das mit jedem Tag dringlicher wird.
<G-vec00345-002-s694><believe.halten><en> I believe that especially important is that people living and work here takle the problems themselves and that they try to solve their way.
<G-vec00345-002-s694><believe.halten><de> Für besonders wichtig halte ich, dass die Menschen, die hier leben und arbeiten, die Probleme selbst anpacken und sie auf ihre Weise lösen versuchen.
<G-vec00345-002-s695><believe.halten><en> During the subsequent panel on the same issue, he emphasised: “I believe that global change – so the question of climate change, rapid population growth on our planet and the associated question of food security – is the most important area for space applications in this century.
<G-vec00345-002-s695><believe.halten><de> Im anschließenden Panel zu diesem Thema betonte er: "Ich halte das Thema Global Change - also die Frage des Klimawandels und des enormen Bevölkerungswachstums auf dieser Erde und die damit verbundene Ernährungssicherheit - für das wichtigste Anwendungsfeld der Raumfahrt in diesem Jahrhundert.
<G-vec00345-002-s696><believe.halten><en> In view of the importance and particularities of this banking sector, I believe indirect European banking supervision to be necessary and appropriate.
<G-vec00345-002-s696><believe.halten><de> Wegen der Bedeutung und den Besonderheiten dieses Bankensektors halte ich eine indirekte europäische Aufsicht für notwendig und angemessen.
<G-vec00345-002-s697><believe.halten><en> For example, macro scenarios – in other words shocks involving shares, currencies or macro indices – can be directly interpreted, and I believe it is essential to be familiar with their impact on your own bank portfolio.
<G-vec00345-002-s697><believe.halten><de> Beispielsweise Makroszenarien, das heißt Schocks auf Aktien, Währungen oder Makroindizes, sind unmittelbar interpretierbar, und ich halte es für unabdingbar, deren Wirkung auf das eigene Bankportfolio zu kennen.
<G-vec00345-002-s698><believe.halten><en> I believe it is authentic.
<G-vec00345-002-s698><believe.halten><de> Ich halte es für authentisch.
<G-vec00345-002-s699><believe.halten><en> I believe it is urgently necessary for employers to formulate a strategy for digital transformation.
<G-vec00345-002-s699><believe.halten><de> Ich halte es für dringend notwendig, dass die Arbeitgeber eine Vorstellung für die digitale Transformation formulieren.
<G-vec00345-002-s700><believe.halten><en> And yet I believe these skills are indispensable if you want to forge a successful medical and scientific career in a position of leadership.
<G-vec00345-002-s700><believe.halten><de> Ich halte diese Kompetenzen jedoch für eine erfolgreiche medizinisch-wissenschaftliche Karriere in einer Führungsposition für unabdingbar.
<G-vec00345-002-s701><believe.halten><en> I believe your interpretation is wrong, but would not permit myself to accuse someone who in this tricky field took a different view from my own, of standing a biblical passage on its head, and I would ask you, reciprocally, to be a little more restrained with such utterances.
<G-vec00345-002-s701><believe.halten><de> Ich halte Ihre Auslegung für falsch, würde mir aber nie den Vorwurf erlauben, dass bei diesem schwierigen Gebiet jemand, der nicht meinem Verständnis folgt, hier Bibeltexte verdrehen würde und bitte auch umgekehrt, mit solchen Äußerungen etwas zurückhaltend zu sein.
<G-vec00345-002-s702><believe.halten><en> I believe that this is a positive sign.
<G-vec00345-002-s702><believe.halten><de> Das alles halte ich für ein gutes Zeichen.
<G-vec00345-002-s817><believe.sehen><en> Henner Schöneborn, CTO of SLM Solutions, adds: "We believe that we are excellently positioned for further growth with our multi-laser technology.
<G-vec00345-002-s817><believe.sehen><de> Henner Schöneborn, CTO von SLM Solutions, ergänzt: "Wir sehen uns mit unserer Multilaser-Technologie hervorragend aufgestellt für weiteres Wachstum.
<G-vec00345-002-s818><believe.sehen><en> The pride of an Englishman is his castle, most Daily Telegraph and Daily Mail readers believe that.
<G-vec00345-002-s818><believe.sehen><de> Der Engländer liebt sein Heim, es ist sein Schloss, die meisten Leser des "Daily Telegraph" und der "Daily Mail" sehen das so.
<G-vec00345-002-s819><believe.sehen><en> We believe in becoming a trusted partner and advisor with IMI Precision Engineering in order to help deliver a “Best In Class” online go to market offering for their complete product range,” announces Colin Johnson, Director of CADENAS UK.
<G-vec00345-002-s819><believe.sehen><de> Wir sehen uns als zuverlässigen Partner und Berater von IMI Precision Engineering bei der Entwicklung eines so genannten „Best-In-Class“ Onlineangebots für ihre gesamte Produktpalette“, so Colin Johnson, Niederlassungsleiter zur Verfügung zu stellen.
<G-vec00345-002-s820><believe.sehen><en> We believe this technology offers unbelievable potential for changing the entire sector as well as producing new business models and innovative products.
<G-vec00345-002-s820><believe.sehen><de> Wir sehen in der Technologie ein unglaubliches Potenzial, ganze Branchen zu verändern sowie neue Geschäftsmodelle und innovative Produkte hervorzubringen.
<G-vec00345-002-s821><believe.sehen><en> A number of long-term structural growth trends that we believe are underappreciated by the market continue to shape our strategy.
<G-vec00345-002-s821><believe.sehen><de> Wir sehen eine Reihe langfristiger struktureller Wachstumstrends, die der Markt unseres Erachtens unterschätzt und die unsere Strategie nach wie vor stark beeinflusst.
<G-vec00345-002-s822><believe.sehen><en> We believe that protecting the integrity of the financial system is a core responsibility of banks.
<G-vec00345-002-s822><believe.sehen><de> Wir sehen den Schutz der Integrität des Finanzsystems als eine der zentralen Aufgaben von Banken.
<G-vec00345-002-s823><believe.sehen><en> We believe we are in a very good position to succeed on the global growth markets with our issues of mobility and security and to keep increasing the business volume.
<G-vec00345-002-s823><believe.sehen><de> Wir sehen uns sehr gut aufgestellt, um mit unseren Themen Mobilität und Sicherheit in den weltweiten Wachstumsmärkten erfolgreich zu sein und das Geschäftsvolumen weiter zu steigern.
<G-vec00345-002-s824><believe.sehen><en> “We believe the positive development during the first six months of the year can be attributed to our successful innovation activities, the consistent alignment of our portfolio with global megatrends and our focus on the most attractive and most dynamic future markets,” says Prof. Dr. Michael Kaschke, ZEISS President and CEO, adding: “This has allowed us to achieve stronger growth than our relevant markets in almost all areas.”
<G-vec00345-002-s824><believe.sehen><de> „Die positive Entwicklung im ersten Halbjahr sehen wir als Ergebnis unserer erfolgreichen Innovationstätigkeit, der konsequenten Ausrichtung unseres Portfolios auf die globalen Megatrends sowie unserer Fokussierung auf die attraktivsten und dynamischsten Zukunftsmärkte“, sagte Prof. Dr. Michael Kaschke, Vorstandsvorsitzender von ZEISS, und ergänzte: „Damit ist es uns in fast allen Bereichen gelungen, stärker zu wachsen als die für uns von Zukäufen erfolgreich behaupten – sowohl in der industriellen Qualitätssicherung als auch bei Mikroskopielösungen für die Forschung.
<G-vec00345-002-s825><believe.sehen><en> This vision not only fuels the imagination of poets like the Kirghiz writer Chinghis Aitmatov but also of politicians of all kinds who believe this to have great economical potential.
<G-vec00345-002-s825><believe.sehen><de> Sie beflügelte nicht nur die Phantasie von Poeten wie den kirgisischen Dichter Chinghis Aitmatov, sondern auch Politiker verschiedenster Couleur, die darin ein großes wirtschaftliches Potential sehen.
<G-vec00345-002-s826><believe.sehen><en> However, there are some big differences between the countries, and not just in terms of the number of users; for example, we believe the US market is much more receptive to professional paid services.
<G-vec00345-002-s826><believe.sehen><de> Die Unterschiede zwischen den Ländern sind jedoch nicht nur bezüglich der Anzahl von Nutzern gross: so sehen wir beispielsweise in den USA einen Markt, der wesentlich empfänglicher ist für professionelle Bezahlangebote.
<G-vec00345-002-s827><believe.sehen><en> People believe the concept of Smart Cities is a major advantage for the cities themselves, as well as for private companies.
<G-vec00345-002-s827><believe.sehen><de> Die Menschen sehen im Smart Cities Konzept einen großen Vorteil für die Städte selbst und für private Unternehmen.
<G-vec00345-002-s828><believe.sehen><en> On the way back to Switzerland, we have stopped in Frankfurt to visit our Mr. Black – Mashona Armani Jendayi - who could hardly believe his eyes when meeting all of us again.
<G-vec00345-002-s828><believe.sehen><de> Auf dem Rückweg dann haben wir noch einen Stop in Frankfurt eingelegt bei unserem Herrn Schwarz - Mashona Armani Jendayi - der sein Glück kaum fassen konnte uns alle wieder zu sehen.
<G-vec00345-002-s829><believe.sehen><en> We do not seek unity with those that believe the armed bodies of the state (e.g., police, prison guards) are part of the workers' movement.
<G-vec00345-002-s829><believe.sehen><de> Wir suchen keine Einheit mit denen, die die bewaffneten Organe des Staates (wie Polizei, Gefängniswärter) als Teil der Arbeiterbewegung sehen.
<G-vec00345-002-s830><believe.sehen><en> The 2017 SME Review published by FHS St.Gallen, a university of applied sciences, investigates what Swiss SMEs understand digitisation to be and what challenges and opportunities they believe it presents.
<G-vec00345-002-s830><believe.sehen><de> Der KMU-Spiegel 2017 der Fachhochschule St.Gallen untersucht, was Schweizer KMU unter Digitalisierung verstehen und welche Chancen und Herausforderungen sie darin sehen.
<G-vec00345-002-s831><believe.sehen><en> We believe that our employees advancement in know-how, is the key factor for success in our company.
<G-vec00345-002-s831><believe.sehen><de> Die Förderung unserer Mitarbeiter sehen wir als wichtigen Erfolgsfaktor unseres Unternehmens.
<G-vec00345-002-s832><believe.sehen><en> We believe the noticeable slowdown in the growth rate this past quarter is tied specifically to uncertainty around tariffs and the business climate.
<G-vec00345-002-s832><believe.sehen><de> Die spürbare Verlangsamung des Wachstums im vergangenen Quartal sehen wir insbesondere in der Zollunsicherheit und im Geschäftsklima begründet.
<G-vec00345-002-s833><believe.sehen><en> We believe that the question still remains of whether and how we can talk of a common route towards democracy and freedom, judged from a single German standpoint which exists as a result of German's regained unity.
<G-vec00345-002-s833><believe.sehen><de> Für uns steht die Frage, ob und wie wir in der gesamtdeutschen Perspektive, die wir infolge der wiedergewonnenen Einheit Deutschlands jetzt sehen dürfen, von einem gemeinsamen Weg zu Demokratie und Freiheit sprechen können.
<G-vec00345-002-s834><believe.sehen><en> Being a technologically and environmentally oriented company, we believe it is our task to create sustainable benefits for our customers.
<G-vec00345-002-s834><believe.sehen><de> Als technologisch und ökologisch orientiertes Unternehmen sehen wir es als unsere Aufgabe, Kunden nachhaltig Vorteile zu verschaffen.
<G-vec00345-002-s969><believe.überzeugen><en> 1:03 In fact, I believe that if we want to survive the next century on this planet, we need to increase that total dramatically.
<G-vec00345-002-s969><believe.überzeugen><de> 1:03 Tatsächlich bin ich überzeugt, dass, wenn wir das nächste Jahrhundert auf diesem Planeten überleben wollen, wir diese Zeit drastisch erhöhen müssen.
<G-vec00345-002-s970><believe.überzeugen><en> Yes Our partner school strongly believe that your English learning experience in Malta or Gozo should be a fulfilling one in every aspect and that includes having a great time!
<G-vec00345-002-s970><believe.überzeugen><de> Ja Unsere Partnerschule ist überzeugt, dass Ihre Lernerfahrung der englischen Sprache auf Malta durch eine angenehme Freizeitgestaltung vervollständigt werden sollte.
<G-vec00345-002-s971><believe.überzeugen><en> O you who have believed, do not take My enemies and your enemies as allies, extending to them affection while they have disbelieved in what came to you of the truth, having driven out the prophet and yourselves because you believe in God, your Lord.
<G-vec00345-002-s971><believe.überzeugen><de> Oh ihr diejenigen, die überzeugt sind, nehmt nicht meinen Feind und euren Feind zu Beschützern, indem ihr ihnen werft Zuneigung, wo sie abgestritten haben die Wahrheit, die bei euch eingetroffen ist, und den Gesandten und euch selbst heraustreten lassen, da ihr überzeugt seid von Allah, euren Herrn.
<G-vec00345-002-s972><believe.überzeugen><en> For these reasons and many more, at FloraQueen we believe that Mother’s Day 2015 orchids are the finest gift you could bestow on your mum on her day.
<G-vec00345-002-s972><believe.überzeugen><de> Aus diesen und vielen anderen Gründen sind wir von FloraQueen überzeugt, dass Orchideen das beste Geschenk zum Muttertag 2015 sind, das Sie Ihrer Mutter an ihrem Ehrentag machen können.
<G-vec00345-002-s973><believe.überzeugen><en> With our in-depth knowledge, we firmly believe that the vehicle of the future will serve not only as a means of transport but also as an instrument of communication.
<G-vec00345-002-s973><believe.überzeugen><de> Gestützt von unserem profunden Fachwissen sind wir überzeugt, dass das Fahrzeug von morgen nicht nur als Transport-, sondern auch als Kommunikationsmittel dient.
<G-vec00345-002-s974><believe.überzeugen><en> We believe that skatewear and streetwear are not only limited to adults, and that’s why a lot of our most popular clothing and shoes are also available in kids sizes.
<G-vec00345-002-s974><believe.überzeugen><de> Wir sind auch fest davon überzeugt, dass Skatewear und Streetwear nicht nur Erwachsenen vorbehalten sein soll und haben daher viele unserer beliebtesten Skater-Klamotten & Schuhe in den gängigen Kindergrößen vorrätig.
<G-vec00345-002-s975><believe.überzeugen><en> I believe that as in Austria also in Slovakia the introduction of family passports will help families spend more time together.
<G-vec00345-002-s975><believe.überzeugen><de> Ich bin überzeugt, dass ähnlich wie in Österreich, auch in der Slowakei die Einführung der Familienpässe den Familien helfen kann, mehr Zeit gemeinsam zu verbringen.
<G-vec00345-002-s976><believe.überzeugen><en> So speaking of Christmas, I firmly believe that a set of these tools (the rougher, the shaper and the detailer) would be a great present for anyone who wants to get into woodturning.
<G-vec00345-002-s976><believe.überzeugen><de> Um also auf Weihnachten zurück zu kommen bin ich überzeugt, dass ein Satz dieser Werkzeuge (frei übersetzt der Schrupper, der Schlichter und der Detailierer) ein großartiges Geschenk für einen angehenden Drechsler (oder eine angehende Drechslerin) wären.
<G-vec00345-002-s977><believe.überzeugen><en> The Gerber fondue experts at Langnau in Emmental firmly believe that the new Mélange Maison will impress the most-demanding fresh fondue customers.
<G-vec00345-002-s977><believe.überzeugen><de> Die Fondue-Experten von Gerber in Langnau im Emmental sind überzeugt, mit der neuen Mélange Maison bei den anspruchsvollen Frisch-Fondue-Konsumenten punkten zu können.
<G-vec00345-002-s978><believe.überzeugen><en> About Fidella At Fidella® we believe that our children deserve the best - in every respect.
<G-vec00345-002-s978><believe.überzeugen><de> Wir von Fidella® sind davon überzeugt, dass unsere Kinder nur das Beste verdienen - in jeder Beziehung.
<G-vec00345-002-s979><believe.überzeugen><en> According to Alan Roberts, Senior Vice President at DCM, "our clients are looking for shorter runs and more customization on their labels. If we’re going to be a leader in short-run prime label business, we need the best piece of hybrid technology, and I believe we are going to receive it with the Heidelberg-Gallus Labelfire 340."
<G-vec00345-002-s979><believe.überzeugen><de> Wenn wir bei den Kleinauflagen im hochveredelten Etiketten-Segment führend sein wollen, dann brauchen wir die beste am Markt verfügbare Hybridtechnologie und ich bin überzeugt, wir erhalten diese mit der Gallus Labelfire von Heidelberg USA", erklärt Alan Roberts, Senior Vice President bei DCM.
<G-vec00345-002-s980><believe.überzeugen><en> Looking at the investment implications of my meetings, I continue to believe that a trade deal is important for equity markets.
<G-vec00345-002-s980><believe.überzeugen><de> Was die Schlussfolgerungen aus meinen Gesprächen für Investments angeht, bin ich weiterhin überzeugt, dass ein Handelsabkommen für die Aktienmärkte wichtig ist.
<G-vec00345-002-s981><believe.überzeugen><en> However, we believe the recent outflows are likely to prove temporary.
<G-vec00345-002-s981><believe.überzeugen><de> Wir sind jedoch überzeugt, dass sich die letzten Abflüsse als vorübergehend erweisen.
<G-vec00345-002-s982><believe.überzeugen><en> I firmly believe that beyond its financial strength, the social responsibility of a company and the sustainability of its business model are powerful drivers of economic growth in the long term.
<G-vec00345-002-s982><believe.überzeugen><de> Ich bin überzeugt, dass ein Unternehmen langfristig nicht nur von seiner finanziellen Stabilität profitiert, sondern dass auch ein nachhaltiges Geschäftsmodell und die Wahrnehmung der sozialen Verantwortung wichtige Performancetreiber sind.
<G-vec00345-002-s983><believe.überzeugen><en> As a leading system supplier for smart intralogistics solutions, we firmly believe that every company, whether it is a global player or a small or medium-sized enterprise, can benefit right now from connecting and conducting its processes perfectly.
<G-vec00345-002-s983><believe.überzeugen><de> Als führender Systemanbieter für intelligente Intralogistiklösungen sind wir überzeugt: Schon heute kann jedes Unternehmen, egal ob Global Player, mittlerer oder kleinerer Betrieb, seine Prozesse gewinnbringend vernetzen und perfekt dirigieren, und sich so Profitabilität und Zukunftsfähigkeit sichern.
<G-vec00345-002-s984><believe.überzeugen><en> Nevertheless, I do believe that together we can handle the situation well, the Czech Republic does not turn its back on the Czech farmers, we will manage to propose measures that will help our farmers overcome the difficult period and that this will also be assisted by the four trade fairs TECHAGRO, SILVA REGINA, ANIMAL VETEX and BIOMASS, which cover the whole spectrum of the agrarian sector,“ declared Minister Jurečka who also expressed his firm belief that all exhibitors as well as their potential clients will spend these days in Brno over constructive discussions.
<G-vec00345-002-s984><believe.überzeugen><de> Nichtsdestoweniger bin ich überzeugt, dass wir es gemeinsam schaffen, diese Situation zu meistern, dass die Tschechische Republik den tschechischen Landwirten nicht den Rücken zuwendet, dass wir wirklich Maßnahmen anbieten können, die unseren Landwirten helfen werden, diesen komplizierten Zeitraum zu überstehen, und dass hierzu auch die vier Branchenmessen TECHAGRO, SILVA REGINA, ANIMAL VETEX und BIOMASSE beitragen, die die ganze Breite des Agrarsektors abdecken“, erklärte Minister Jurečka und äußerte seine Überzeugung, dass alle Aussteller und ihre potenziellen Kunden diese Tage in Brünn mit konstruktiven Gesprächen verbringen werden.
<G-vec00345-002-s985><believe.überzeugen><en> If you believe that you have found a bug in Amadeus Pro, please report it to Martin@HairerSoft.com and I will make every attempt to correct it.
<G-vec00345-002-s985><believe.überzeugen><de> Sind Sie überzeugt, in Amadeus Pro einen Fehler gefunden zu haben, dann teilen Sie ihn Martin@HairerSoft.com mit und ich werde alles versuchen, ihn zu beheben.
<G-vec00345-002-s986><believe.überzeugen><en> I believe that all global citizens are eagerly looking toward the next decade - 2022 and beyond - as a time of great progress and striking change.
<G-vec00345-002-s986><believe.überzeugen><de> Ich bin überzeugt, dass alle Menschen der Welt mit großer Hoffnung auf das nächste Jahrzehnt blicken - bis 2022 und darüber hinaus - als eine Zeit großen Fortschritts und wichtiger Veränderungen.
<G-vec00345-002-s987><believe.überzeugen><en> I believe that the first six weeks of the Czech presidency have convincingly demonstrated our responsible attitude.
<G-vec00345-002-s987><believe.überzeugen><de> Ich bin überzeugt, dass die ersten sechs Wochen unseres Vorsitzes unseren verantwortlichen Ansatz in überzeugender Weise demonstriert haben.
