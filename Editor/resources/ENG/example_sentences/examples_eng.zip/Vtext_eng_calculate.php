<G-vec00322-002-s038><calculate.ausrechnen><en> Our prices are a guide only and should be used to calculate your rough overall budget; for competitive rates, please contact us directly for a quote
<G-vec00322-002-s038><calculate.ausrechnen><de> Unsere Preise sind alle nur Richtlinien und sollten benutzt werden, um ein ungefähres Budget auszurechnen; für wettbewerbsfähige Raten kontaktieren Sie uns bitte, um ein Preisangebot zu erhalten.
<G-vec00322-002-s039><calculate.ausrechnen><en> A final strategy is to calculate the exact probability of each square taking the entire game into consideration.
<G-vec00322-002-s039><calculate.ausrechnen><de> Als letzte Option verbleibt noch, sich die genaue Wahrscheinlichkeit für jedes Feld auszurechnen, indem man das ganze Spiel miteinbezieht.
<G-vec00322-002-s040><calculate.ausrechnen><en> You can use the nearby bench to calculate the final coordinates.
<G-vec00322-002-s040><calculate.ausrechnen><de> Du kannst die naheliegende Bank nutzen um die Endkoordinaten auszurechnen.
<G-vec00322-002-s041><calculate.ausrechnen><en> Use the table to small drawings or sketches and use the calculator for calculate something.
<G-vec00322-002-s041><calculate.ausrechnen><de> Benutzen Sie die Tafel um kleine Zeichnungen oder Skizzen anzufertigen und den Taschenrechner um etwas auszurechnen.
<G-vec00322-002-s042><calculate.ausrechnen><en> Given the antivirus product X detects 50% of all viruses active in the Internet at a given moment of time, the product Y detects 90%, and the product Z detects 99.9%, it is a trivial problem to calculate the probability of your computer remaining intact after N attacks.
<G-vec00322-002-s042><calculate.ausrechnen><de> Wenn man annimmt, Produkt X entdeckt 50 Prozent aller aktiven Viren im Internet, Produkt Y immerhin schon 90 Prozent und Produkt Z ganze 99,9 Prozent, ist es ein Leichtes, die Wahrscheinlichkeit auszurechnen, wann ein Computer nach N Angriffen nicht mehr intakt sein wird.
<G-vec00322-002-s043><calculate.ausrechnen><en> In order to calculate the mentioned limit you have to take in account the global value of the assets, independently of the degree of participation of each tax payer.
<G-vec00322-002-s043><calculate.ausrechnen><de> Um die erwähnte Grenze auszurechnen muss die globale Bewertung der Güter in Betracht genommen werden, egal welcher der Beteiligungsgrad jeder Person ist.
<G-vec00322-002-s044><calculate.ausrechnen><en> No attempt is made to calculate the day and the hour of the Coming of Jesus Christ, as it is required in the Scripture, but the length of the final crisis is determined here.
<G-vec00322-002-s044><calculate.ausrechnen><de> In der Broschüre wird nicht versucht – wie auch die Schrift es verlangt – den Tag und die Stunde der Wiederkunft Christi auszurechnen, sondern es wird die Dauer der End-Krise festgestellt.
<G-vec00322-002-s045><calculate.ausrechnen><en> A mine is more likely in L than K and more likely in H than D. A final strategy is to calculate the exact probability of each square taking the entire game into consideration.
<G-vec00322-002-s045><calculate.ausrechnen><de> Eine Mine befindet sich eher in L als in K, und eher in H als in D. Als letzte Option verbleibt noch, sich die genaue Wahrscheinlichkeit für jedes Feld auszurechnen, indem man das ganze Spiel miteinbezieht.
<G-vec00322-002-s046><calculate.ausrechnen><en> If you are in need of a currency computer in order to calculate what your order costs in your currency we can recommend the Yahoo currency calculator.
<G-vec00322-002-s046><calculate.ausrechnen><de> Währungsrechner Sollten Sie einen Währungsrechner benötigen, um auszurechnen, was Ihre Bestellung in Ihrer Währung kostet, so können wir Ihnen den Yahoo Währungsrechner empfehlen.
<G-vec00322-002-s047><calculate.ausrechnen><en> It might be feasible to calculate how much resources to put into "growing chocolate", but how could any centralized system decide how much to produce of the thousands of different kinds of chocolate candies, chocolate pastries, chocolate puddings.
<G-vec00322-002-s047><calculate.ausrechnen><de> Es mag zwar möglich sein, auszurechnen, wie viele Rohstoffe wir in einer „werdenden Schokolade“ benötigen, aber wie soll ein zentralisiertes System entscheiden, wie viele von den tausenden verschiedenen Arten an Schokoladenriegeln, Schokoladenpasten, Schokoladenpuddings hergestellt werden sollen.
<G-vec00322-002-s168><calculate.berechnen><en> The Windows programmer, Thomas F. Carroll helped the Classics For X programmer to calculate the Taipan statistics.
<G-vec00322-002-s168><calculate.berechnen><de> Der Programmierer der Windows-Version, Thomas F. Carroll, half dem Programmierer der Mac-Version, die Taipan-Statistiken zu berechnen.
<G-vec00322-002-s169><calculate.berechnen><en> EtherNet/IP Capacity Tool — Calculate resources used by a proposed EtherNet/IP™ network.
<G-vec00322-002-s169><calculate.berechnen><de> EtherNet/IP-Kapazitätstool – Die von einem vorgeschlagenen EtherNet/IP™-Netzwerk verwendeten Ressourcen berechnen.
<G-vec00322-002-s170><calculate.berechnen><en> Science can calculate time zero, which was the Big Bang.
<G-vec00322-002-s170><calculate.berechnen><de> Die Wissenschaft kann die Zeit null berechnen, das war der Big Bang.
<G-vec00322-002-s171><calculate.berechnen><en> The signals are obtained by GPS receivers, such as navigation devices and are used to calculate the exact position, speed and time at the vehicles location.
<G-vec00322-002-s171><calculate.berechnen><de> Die Signale werden von GPS-Geräten, wie beispielsweise Satellitennavigationsgeräten, empfangen und dazu verwendet, die exakte Position, die Geschwindigkeit des Empfängers sowie die genaue Zeit am Standort des Empfängers zu berechnen.
<G-vec00322-002-s172><calculate.berechnen><en> It collects job logs and is able to automatically calculate costs for a specific job, or over a longer period of time.
<G-vec00322-002-s172><calculate.berechnen><de> Sie sammelt Job-Protokolle und ist in der Lage, automatisch die Kosten über einen konkreten Auftrag oder über einen längeren Zeitraum zu berechnen.
<G-vec00322-002-s173><calculate.berechnen><en> If you use Barcodesoft EAN13 fonts to print bar code, please use our Encoder to calculate checksum for you.
<G-vec00322-002-s173><calculate.berechnen><de> Wenn Sie Barcodesoft Code 11 zum Drucken von Barcodes verwenden, verwenden Sie unseren Encoder, um die Prüfsumme zu berechnen.
<G-vec00322-002-s174><calculate.berechnen><en> In the newsletter 167 one year ago was shown how to calculate externally and internally toothed gear wheel for an eccentric gear by means of ZAR1+.
<G-vec00322-002-s174><calculate.berechnen><de> Im Infobrief 167 vor einem Jahr wurde gezeigt, wie man mit ZAR1+ die Zahnradpaarung für Exzenter-Abwälzgetriebe aus außen- und innenverzahntem Zahnrad berechnen kann.
<G-vec00322-002-s175><calculate.berechnen><en> It will also give users the ability to see what benefits the addition of new technologies and approaches could bring, using their own data to assess the opportunity and calculate return on investment.
<G-vec00322-002-s175><calculate.berechnen><de> Mit dieser Plattform können Anwender zudem sehen, welche Vorteile eine Ergänzung neuer Technologien und Ansätze bringen könnte, indem sie ihre eigenen Daten nutzen, um die Möglichkeit zu bewerten und die Kapitalrendite zu berechnen.
<G-vec00322-002-s176><calculate.berechnen><en> On this webpage you can calculate reactances with two coils, two capacitors and a capacitor and a coil.
<G-vec00322-002-s176><calculate.berechnen><de> Auf der Webseite können Sie die Blindwiderstände zweier Spulen, zweier Kondensatoren oder eines Kondensators zusammen mit einer Spule berechnen.
<G-vec00322-002-s159><calculate.bestimmen><en> In 2018, car importers, therefore, turned to Empa to calculate the cornerstones of a recycling system for car batteries.
<G-vec00322-002-s159><calculate.bestimmen><de> 2018 wandten sich die Auto-Importeure daher an die Empa, um die Eckpunkte eines Recyclingsystems für Antriebsbatterien zu bestimmen.
<G-vec00322-002-s160><calculate.bestimmen><en> A first step is to calculate simple statistical quantities like the mean or the variance of the data. In the case of discrete data one often needs the probability distribution of the data.
<G-vec00322-002-s160><calculate.bestimmen><de> Ein erster Schritt besteht darin, für die Daten einfache statistische Größen wie den Mittelwert und die Standardabweichung zu bestimmen, bei diskreten Daten die Häufigkeitsverteilung.
<G-vec00322-002-s161><calculate.bestimmen><en> The flowmeter then makes use of the flow data, the differential temperature and the specific heat capacity of the flowing medium in order to calculate the energy consumption.
<G-vec00322-002-s161><calculate.bestimmen><de> Um den Energieverbrauch zu bestimmen, wertet das Gerät die Durchflussraten und die Temperaturdifferenz unter Berücksichtigung der spezifischen Wärmekapazität des entsprechenden Mediums aus.
<G-vec00322-002-s162><calculate.bestimmen><en> For controlling and post production analysis it is difficult to calculate the exact energy cost for a production step or an article.
<G-vec00322-002-s162><calculate.bestimmen><de> Für das Controlling und die Nachkalkulation ist es schwierig, die genauen Energiekosten für einen Produktionsschritt oder einen Artikel zu bestimmen.
<G-vec00322-002-s163><calculate.bestimmen><en> Once added to your chart, the FXCM Risk Calculator, as depicted above, has the ability to help a trader calculate risk based off of trade size and stop levels.
<G-vec00322-002-s163><calculate.bestimmen><de> Wenn der FXCM Risk Calculator wie oben dargestellt auf Ihrem Chart hinzugefügt wurde, kann er Tradern helfen, das Risiko aufgrund der Trade-Größe und der Stop-Levels zu bestimmen.
<G-vec00322-002-s164><calculate.bestimmen><en> So far it has helped them to accurately calculate the level of THC in brownies and crackers, among other products.
<G-vec00322-002-s164><calculate.bestimmen><de> Bis jetzt hat diese Methode geholfen, den THC-Wert unter anderem in 'Brownies' und Keksen zu bestimmen.
<G-vec00322-002-s165><calculate.bestimmen><en> Performance cookies: These are cookies that are either processed by us or by third parties and allow us to calculate user numbers and measure and statistically analyse how users utilise the service provided.
<G-vec00322-002-s165><calculate.bestimmen><de> Analyse-Cookies: Anhand dieser entweder von uns oder von Dritten verarbeiteten Cookies können wir die Anzahl der Nutzer bestimmen und somit eine Messung und statistische Analyse der Nutzung der angebotenen Dienste durch die Benutzer durchführen.
<G-vec00322-002-s166><calculate.bestimmen><en> It was already possible to accurately calculate the coordinates of the atoms in simple materials at different temperatures with quantum mechanical molecular dynamics (MD) simulations.
<G-vec00322-002-s166><calculate.bestimmen><de> Für einfache Materialien ist es möglich, die Position ihrer Atome bei verschiedenen Temperaturen mit quantenmechanischen Molekulardynamik-(MD)-Simulationen genau zu bestimmen.
<G-vec00322-002-s167><calculate.bestimmen><en> 2), is able to autonomously calculate the optimal process set-up and the user can also determine the process window for production after just one calculation run.
<G-vec00322-002-s167><calculate.bestimmen><de> 2) und ist in der Lage autonom die optimalen Prozesseinstellungen zu bestimmen, sodass der Benutzer nach nur einer Berechnung das Prozessfenster für die Produktion festlegen kann.
<G-vec00322-002-s177><calculate.ermitteln><en> In order to calculate the rim size of the glasses, simply add together the width of the nose bridge (B) and the lens width (C).
<G-vec00322-002-s177><calculate.ermitteln><de> Um die Fassungsgrösse der Brille zu ermitteln, addieren Sie ganz einfach die Breite des Stegs (B) mit der Glasbreite(C).
<G-vec00322-002-s178><calculate.ermitteln><en> Nevertheless, it is not possible to calculate the house position of several planets, as can be seen in the planet table next to the chart, which shows "0" as house position for quite a few planets.
<G-vec00322-002-s178><calculate.ermitteln><de> Gleichwohl lässt sich die Hausposition etlicher Planeten nicht ermitteln, wie die Planetentabelle in der Grafik offenbart, die für viele Himmelskörper die Hausposition 0 angibt.
<G-vec00322-002-s179><calculate.ermitteln><en> They also file our tax returns and calculate values such as the trade tax owed and the amount to be paid.
<G-vec00322-002-s179><calculate.ermitteln><de> Außerdem fassen sie unsere Steuererklärungen ab und ermitteln Werte wie Gewerbesteuerschuld und –zahlungshöhe.
<G-vec00322-002-s180><calculate.ermitteln><en> Contact Intralox fruit and vegetable specialists and let them calculate the potential savings hidden in your conveyors.
<G-vec00322-002-s180><calculate.ermitteln><de> Wenden Sie sich an die Obst- und Gemüsespezialisten von Intralox, und lassen Sie das ungenutzte Einsparungspotenzial Ihrer Förderer ermitteln.
<G-vec00322-002-s181><calculate.ermitteln><en> We calculate the loads lifted by your hoist and the elapsed share of its theoretical duration of service, which enables us to guarantee the remaining safe working period (SWP).
<G-vec00322-002-s181><calculate.ermitteln><de> Wir ermitteln die Höhe der Belastungen Ihres Hebezeugs und den Verbrauch der theoretischen Nutzungsdauer – und gewährleisten dadurch sichere Betriebsperioden (Safe Working Period, SWP).
<G-vec00322-002-s182><calculate.ermitteln><en> With the scenario analyser you can calculate potential outcomes of the next street(s), calculate river cards and calculate outcomes against multiple ranges.
<G-vec00322-002-s182><calculate.ermitteln><de> Mit der Szenario-Analyse kannst du potenzielle Ergebnisse von nachfolgenden Streets kalkulieren, Riverkarten berechnen und Ergebnisse gegen mehrere Ranges ermitteln.
<G-vec00322-002-s183><calculate.ermitteln><en> We constantly monitor footfall because this allows us to calculate average values over longer periods of time.
<G-vec00322-002-s183><calculate.ermitteln><de> Die Frequenzen messen wir laufend, denn so können wir Durchschnittswerte über größere Zeiträume ermitteln.
<G-vec00322-002-s184><calculate.ermitteln><en> We calculate the weighted average cost of capital (WACC) of debt and equity capital on an annual basis using market values.
<G-vec00322-002-s184><calculate.ermitteln><de> Hierfür ermitteln wir jährlich auf Basis von Marktwerten die Kapitalkosten (Weighted Average Cost of Capital; WACC) als gewichteten Durchschnittswert aus risikoadäquaten Marktrenditen für Eigen- und Fremdkapital.
<G-vec00322-002-s185><calculate.ermitteln><en> For the potency test mice are immunized with different doses of Ixiaro® (in vivo part) and subsequently seroconversion rates of the mouse sera are determined by PRNT (PRNT part) to finally calculate an effective dose 50 (ED50).
<G-vec00322-002-s185><calculate.ermitteln><de> Der Potency Test beruht auf der Immunisierung von Mäusen mit verschiedenen Dosen von Ixiaro® (in vivo Teil) und der anschließenden Bestimmung der Serokonversionsraten der Mausseren mittels PRNT (PRNT Teil), um die Effektive Dosis 50 (ED50) des Impfstoffes zu ermitteln.
<G-vec00322-002-s186><calculate.ermitteln><en> In order to calculate the capital gains the transfer value is deducted from the acquisition value.
<G-vec00322-002-s186><calculate.ermitteln><de> Um den Vermögenszuwachs zu ermitteln, wird der Übertragungswert vom Anschaffungswert abgezogen.
<G-vec00322-002-s187><calculate.ermitteln><en> We calculate the monthly wages and salaries for your employees, the payroll tax and social insurance contributions to be paid to the respective authorities.
<G-vec00322-002-s187><calculate.ermitteln><de> Wir ermitteln für Ihre Mitarbeiter die monatlichen Löhne und Gehälter, die abzuführende Lohnsteuer und Sozialversicherungsbeiträge.
<G-vec00322-002-s188><calculate.ermitteln><en> To calculate, just type or paste any text with numbers into the field and press Calculate digit sums.
<G-vec00322-002-s188><calculate.ermitteln><de> Zum Errechnen einfach eine Zahl oder einen beliebigen Text mit Zahlen in das Feld eingeben oder kopieren und auf Quersummen ermitteln klicken.
<G-vec00322-002-s189><calculate.ermitteln><en> In order to assess the impact of taxation on the competitiveness of agricultural enterprises in different countries, it would therefore be useful to calculate the tax burden for specific forms of enterprises that have the same factor endowment and the same type of production.
<G-vec00322-002-s189><calculate.ermitteln><de> Um den Einfluß der Besteuerung auf die Wettbewerbsfähigkeit der landwirtschaftlichen Unternehmen verschiedener Länder erfassen zu können, wäre es deshalb zweckmäßig, für definierte Unternehmen mit gleicher Faktorausstattung und gleicher Produktion, die Steuerbelastung zu ermitteln.
<G-vec00322-002-s190><calculate.ermitteln><en> At the end of every season, the results of these audits are added to the results of the satisfaction questionnaires completed by our customers so as to calculate scores per criterion for each village.
<G-vec00322-002-s190><calculate.ermitteln><de> Am Ende jeder Saison addieren wir die Ergebnisse dieser Prüfungen zu den Ergebnissen der durch die Kunden ausgefüllten Zufriedenheitsfragebögen und ermitteln so für jedes Dorf die jeweiligen Noten in den einzelnen Kriterien.
<G-vec00322-002-s191><calculate.ermitteln><en> To calculate the cost of furniture for an unfurnished apartment, the local cost for a representative selection of furniture available from IKEA worldwide was calculated separately for the two size classes.
<G-vec00322-002-s191><calculate.ermitteln><de> Um die notwendigen Ausgaben zur Möblierung einer Wohnung zu ermitteln, wurden die örtlichen Kosten für eine repräsentative Auswahl an Möbeln von IKEA für beide Wohnungsgrößen berechnet.
<G-vec00322-002-s192><calculate.ermitteln><en> I use various different data sources of the Institute for Employment Research (IAB) to calculate worker flows and job flows as well as inflows into and outflows from unemployment.
<G-vec00322-002-s192><calculate.ermitteln><de> Es werden verschiedene Datenquellen des IAB verwendet, um die Fluktuation von Arbeitskräften (Worker Flows) und Arbeitsplätzen (Job Flows) sowie Zugänge in und Abgänge aus Arbeitslosigkeit zu ermitteln.
<G-vec00322-002-s193><calculate.ermitteln><en> The odds are easy enough to calculate, and the wager on is rather structured as you shall see.
<G-vec00322-002-s193><calculate.ermitteln><de> Die Glücksspiele sind einfach genug, um zu ermitteln, und das Spiel ist ein wenig strukturiert.
<G-vec00322-002-s194><calculate.ermitteln><en> As long as you know the temperature of your sample, and the temperature standard of your hydrometer, you can calculate the salinity.
<G-vec00322-002-s194><calculate.ermitteln><de> Solange du die Temperatur deiner Probe und den Temperaturbereich deines Hydrometers kennst, kannst du den Salzgehalt ermitteln.
<G-vec00322-002-s195><calculate.ermitteln><en> “Calculate special lengths” asks for, or determines special lengths.
<G-vec00322-002-s195><calculate.ermitteln><de> „Fixlängen ermitteln“ erfragt oder ermittelt Fixlängen.
<G-vec00322-002-s232><calculate.errechnen><en> The monitoring unit has a calculation program in order to calculate an ACTUAL value of a melt flow rate of the spinning pump and/or an ACTUAL value of a total titre of the strand.
<G-vec00322-002-s232><calculate.errechnen><de> In der Überwachungseinheit könn- te hierzu ein weiteres Berechnungsprogramm hinterlegt sein, das den IST- Wert des Gesamttiters aus der Masse des Fadens errechnet.
<G-vec00322-002-s233><calculate.errechnen><en> The Filling & Packaging Performance app uses the values to calculate overall equipment effectiveness, allowing customers to monitor the equipment’s performance at any time.
<G-vec00322-002-s233><calculate.errechnen><de> Aus den Werten errechnet Filling & Packaging Performance dann eine Overall Equipment Effectiveness, mit der die Leistung der Anlage jederzeit abrufbar ist.
<G-vec00322-002-s234><calculate.errechnen><en> A&K uses simulation in selected scenarios to calculate and rate your supply chain and logistical processes, value stream alternatives, management philosophies, methods and parameters.
<G-vec00322-002-s234><calculate.errechnen><de> Mit Hilfe der Simulation errechnet und bewertet A&K Supply-Chain- und Logistikprozesse, Wertstromalternativen, Steuerungsphilosophien, Methoden und Parameter in ausgewählten Szenarien.
<G-vec00322-002-s235><calculate.errechnen><en> The shop will calculate your exact shipping charges when you check out.
<G-vec00322-002-s235><calculate.errechnen><de> Ihren exakten Tarif errechnet der Shop während des Bestellvorgangs online.
<G-vec00322-002-s236><calculate.errechnen><en> For instance, EHS participates in the World Risk Index, which is used to calculate the risk of disasters for 171 countries.
<G-vec00322-002-s236><calculate.errechnen><de> Das EHS ist beispielsweise beteiligt am Weltrisikoindex, der das Katastrophenrisiko für 171 Länder errechnet.
<G-vec00322-002-s237><calculate.errechnen><en> Once the actual sums have been submitted, the city can calculate the difference.
<G-vec00322-002-s237><calculate.errechnen><de> Liegen die tatsächlichen Zahlen schließlich vor, errechnet die Stadt den Differenzbetrag.
<G-vec00322-002-s238><calculate.errechnen><en> Optimised gear shifts, lower fuel consumption – the engine electronics calculate the most efficient gear for each driving situation and engine speed.
<G-vec00322-002-s238><calculate.errechnen><de> Optimal schalten, Verbrauch senken – die Motorelektronik errechnet je nach Fahrsituation und Motordrehzahl den aktuell effizientesten Gang, und ein aufleuchtendes Pfeilsymbol zeigt im Info Display an, wenn das Fahrzeug in einem höheren oder niedrigeren Gang sparsamer unterwegs sein könnte.
<G-vec00322-002-s239><calculate.errechnen><en> The third step is to calculate the mean deviation from the moving average.
<G-vec00322-002-s239><calculate.errechnen><de> Im dritten und letzten Schritt wird die mittlere Abweichung vom zuvor ermittelten gleitenden Durchschnitt errechnet.
<G-vec00322-002-s240><calculate.errechnen><en> You calculate your surcharge for free holiday cancellation based on the information given above and add it to the amount of deposit and pay it with the deposit.
<G-vec00322-002-s240><calculate.errechnen><de> Zahlung Ihr errechnet euch nach obigen Angaben euren Aufschlag für den kostenlosen Urlaubsrücktritt und addiert diese zum zu zahlenden Anzahlungsbetrag einfach dazu.
<G-vec00322-002-s241><calculate.errechnen><en> The app will now calculate your net salary in seconds.
<G-vec00322-002-s241><calculate.errechnen><de> Die App errechnet nun in Sekundenschnelle Ihr Nettogehalt.
<G-vec00322-002-s242><calculate.errechnen><en> They can also communicate with other devices, such as the on-board computer, which uses the data from the cells to calculate how much remaining energy the entire battery still has, the so called state of charge.
<G-vec00322-002-s242><calculate.errechnen><de> Oder sie kommunizieren mit anderen Geräten, etwa dem Bordcomputer, der aus den Daten der Zellen errechnet, wie viel Restenergie die gesamte Batterie noch aufweist.
<G-vec00322-002-s243><calculate.errechnen><en> Since, in the phase of flight, it is important to know whether the airports can be reached at all, and not how fast, pocket*StrePla will calculate the optimum Mac Cready setting.
<G-vec00322-002-s243><calculate.errechnen><de> Da es in dieser Flugphase darauf ankommt, ob diese Flugplätze überhaupt erreicht werden und nicht ob sie möglichst schnell wie im Wettbewerb erreicht werden, errechnet pocket*StrePla die optimale Mc Cready Einstellung.
<G-vec00322-002-s244><calculate.errechnen><en> The consulting firm Front Economics has carried out a study, on behalf of Agora Verkehrswende and Agora Energiewende, to calculate the efficiency of Power-to-Gas technology applications: While an electric car uses almost 70 percent of the electricity, a fuel cell car, which runs on synthetic hydrogen, only uses around a quarter.
<G-vec00322-002-s244><calculate.errechnen><de> Die Beratungsfirma Front Economics hat im Auftrag von Agora Verkehrswende und Agora Energiewende in einer Studie die Wirkungsgrade von Anwendungen der Power-to-Gas-Technologie errechnet: Während ein E-Auto knapp 70 Prozent des Stroms nutzt, ist es beim Brennstoffzellen-Auto, das mit synthetischem Wasserstoff fährt, nur rund ein Viertel.
<G-vec00322-002-s245><calculate.errechnen><en> (4) The Operator shall calculate and charge the tax on gaming winnings at the moment of paying out the winning to the Player’s I-account.
<G-vec00322-002-s245><calculate.errechnen><de> (4) Der Betreiber errechnet die Gewinnsteuer und zieht diese im Moment der Auszahlung des Gewinns auf das virtuelle Konto (i-Konto) des Spielers ein.
<G-vec00322-002-s246><calculate.errechnen><en> The modular cutting optimisation software uses the material list to calculate the most economic cutting process taking the cutting times and amount of waste into consideration.
<G-vec00322-002-s246><calculate.errechnen><de> Schnittoptimierungs-Software Die modular aufgebaute Schnittoptimierungs-Software errechnet aus den Stücklisten die wirtschaftlichsten Zuschnittpläne unter Berücksichtigung von Zuschnittzeit und Verschnittmenge.
<G-vec00322-002-s247><calculate.errechnen><en> China Airlines will calculate and confirm your mileage after departure.
<G-vec00322-002-s247><calculate.errechnen><de> China Airlines errechnet und bestätigt Ihre Meilen nach Abflug.
<G-vec00322-002-s248><calculate.errechnen><en> Online casinos calculate their rollover requirements so that they don’t make any losses.
<G-vec00322-002-s248><calculate.errechnen><de> Ein Online Casino errechnet die Umsatzbedingungen so, dass es im Durchschnitt keine Verluste macht.
<G-vec00322-002-s249><calculate.errechnen><en> The system uses data from sensors to detect unstable driving conditions and calculate the correct counter-measure in a split second.
<G-vec00322-002-s249><calculate.errechnen><de> Anhand von Sensorik-Daten kann das elektronische Stabilisierungsprogramm einen instabilen Fahrzustand erkennen und errechnet in Sekundenbruchteilen die richtige Gegenmaßnahme.
<G-vec00322-002-s250><calculate.errechnen><en> A mobile phone picks up the three signals and can calculate the location from the time.
<G-vec00322-002-s250><calculate.errechnen><de> Das Mobiltelefon empfängt die drei Signale und errechnet aus den Zeiten den Standort.
<G-vec00322-002-s270><calculate.kalkulieren><en> Calculate your desired quantity of Folding boxes.
<G-vec00322-002-s270><calculate.kalkulieren><de> Kalkulieren Sie Ihre gewünschte Menge Faltschachteln.
<G-vec00322-002-s271><calculate.kalkulieren><en> Calculate quadratic equations with this excellent, visual, tool.
<G-vec00322-002-s271><calculate.kalkulieren><de> Kalkulieren Sie quadratische Formeln mit diesem tollen, visuellen Werkzeug.
<G-vec00322-002-s272><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Note pads.
<G-vec00322-002-s272><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Schreibunterlagen.
<G-vec00322-002-s273><calculate.kalkulieren><en> Although it is easy to order a new domain and redirect the old domain, you have to calculate at least 1 year until all the scales have settled.
<G-vec00322-002-s273><calculate.kalkulieren><de> Es ist zwar ein Leichtes eine neue Domain zu bestellen und die alte Domain umzuleiten, doch kalkulieren Sie mit mindestens 1 Jahr bis sich alle Wogen geglättet haben.
<G-vec00322-002-s274><calculate.kalkulieren><en> Budget report, calculate your project costs.
<G-vec00322-002-s274><calculate.kalkulieren><de> Kalkulieren Sie die Projektkosten.
<G-vec00322-002-s275><calculate.kalkulieren><en> In addition to that, we calculate the costs, check the profitability of your plan, and apply for patents and test certificates for you.
<G-vec00322-002-s275><calculate.kalkulieren><de> Außerdem kalkulieren wir für Sie die Kosten, prüfen die Rentabilität Ihres Vorhabens und holen Patente sowie Prüf-Zertifikate für Sie ein.
<G-vec00322-002-s276><calculate.kalkulieren><en> Calculate your desired quantity of Floor stickers.
<G-vec00322-002-s276><calculate.kalkulieren><de> Kalkulieren Sie Ihre gewünschte Menge Bodenaufkleber.
<G-vec00322-002-s277><calculate.kalkulieren><en> Second, calculate the value of the bond assuming the owner is subject to the maximum personal income tax rate.
<G-vec00322-002-s277><calculate.kalkulieren><de> Zweitens kalkulieren sie den Wert dieser Anleihe unter der Berücksichtigung, dass der Investor die höchste Steuerrate zu zahlen hat.
<G-vec00322-002-s278><calculate.kalkulieren><en> Take a look at projects we have completed or calculate the price yourself.
<G-vec00322-002-s278><calculate.kalkulieren><de> Schauen Sie sich einige unserer Projekte an oder kalkulieren Sie den Preis selbst.
<G-vec00322-002-s279><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Floor stickers.
<G-vec00322-002-s279><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Klebefolien.
<G-vec00322-002-s280><calculate.kalkulieren><en> Calculate your desired quantity of Magnetic sheets.
<G-vec00322-002-s280><calculate.kalkulieren><de> Kalkulieren Sie Ihre gewünschte Menge Magnetfolien.
<G-vec00322-002-s281><calculate.kalkulieren><en> Calculate the volume of all common geometrical shapes, such as cubes, spheres, pyramids, cones etc.
<G-vec00322-002-s281><calculate.kalkulieren><de> Kalkulieren Sie das Volumen von allen gängigen Fromen, sowie Würfel, Kugeln, Pyramiden usw.
<G-vec00322-002-s282><calculate.kalkulieren><en> Calculate how much you’re spending, even without realizing “what” you are spending it on.
<G-vec00322-002-s282><calculate.kalkulieren><de> Kalkulieren Sie, wie viel Sie ausgeben, auch ohne zu realisieren „wofür“ Sie es ausgeben.
<G-vec00322-002-s283><calculate.kalkulieren><en> Calculate safely and easily with a smart rate and no hidden costs.
<G-vec00322-002-s283><calculate.kalkulieren><de> Kalkulieren Sie einfach und sicher mit einer smarten Rate ohne zusätzliche Nebenkosten.
<G-vec00322-002-s284><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Folding boxes.
<G-vec00322-002-s284><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Kissenschachteln.
<G-vec00322-002-s285><calculate.kalkulieren><en> So make your mind, calculate your budget and find a venue which best suits your needs, before someone else books it.
<G-vec00322-002-s285><calculate.kalkulieren><de> Also denken Sie darüber nach, kalkulieren Sie Ihr Budget und finden Sie einen Veranstaltungsort, der Ihren Bedürfnissen am besten entspricht, bevor jemand anderes ihn bucht.
<G-vec00322-002-s286><calculate.kalkulieren><en> Quantity Calculate your desired quantity of Calendars.
<G-vec00322-002-s286><calculate.kalkulieren><de> Menge Kalkulieren Sie Ihre gewünschte Menge Schreibblocks.
<G-vec00322-002-s287><calculate.kalkulieren><en> Of course, you only pay for what you use, and can precisely calculate in advance how much the applications will cost.
<G-vec00322-002-s287><calculate.kalkulieren><de> Selbstverständlich bezahlen Sie nur das, was sie nutzen, und Sie können im Voraus genau kalkulieren, wie viel Sie für die Anwendungen ausgeben.
<G-vec00322-002-s288><calculate.kalkulieren><en> Configure and calculate your running rigging quick and easy with a few mouse clicks.
<G-vec00322-002-s288><calculate.kalkulieren><de> Konfigurieren und kalkulieren Sie sich Ihr Tauwerk schnell und einfach mit ein paar Mausklicks.
<G-vec00322-002-s308><calculate.rechnen><en> ∙ Calculate 3 times 8 minus root of tangent of 3.
<G-vec00322-002-s308><calculate.rechnen><de> ∙ Rechne 3 mal 8 minus Wurzel von Tanges 3.
<G-vec00322-002-s309><calculate.rechnen><en> If your account is denominated in a currency other than US dollar, then simply calculate the equivalent amount of US dollars in your account using the current exchange rate and base your position size on that.
<G-vec00322-002-s309><calculate.rechnen><de> Falls dein Trading-Konto in einer anderen Währung als US-Dollar geführt wird, rechne den Betrag einfach mit dem aktuellen Wechselkurs in US-Dollar um und lege darauf beruhend deine Positionsgröße fest.
<G-vec00322-002-s310><calculate.rechnen><en> Repeat this process 10 times and calculate the average of all 10 results.
<G-vec00322-002-s310><calculate.rechnen><de> Wiederhole diesen Prozess zehn Mal und rechne den Durchschnitt aller zehn Ergebnisse aus.
<G-vec00322-002-s311><calculate.rechnen><en> The distance is about four kilometers, so you should calculate with about one hour to get there from the station.
<G-vec00322-002-s311><calculate.rechnen><de> Die Distanz beträgt knapp vier Kilometer, rechne also mit einer guten Stunde Gehzeit.
<G-vec00322-002-s312><calculate.rechnen><en> Calculate the investments needed to reach your goals.
<G-vec00322-002-s312><calculate.rechnen><de> Rechne die erforderlichen Investitionen zum Erreichen deiner Ziele aus.
<G-vec00322-002-s313><calculate.rechnen><en> Calculate how much sugar is in a particular bottle or can: to do so look on the nutrition label for how many grams of sugar there are per serving.
<G-vec00322-002-s313><calculate.rechnen><de> Rechne aus, wie viel Zucker in einer bestimmten Flasche oder Dose ist: um dies zu tun, schau auf die Nährwertkennzeichnung und suche, wie viel Gramm Zucker pro Portion enthalten ist.
<G-vec00322-002-s314><calculate.rechnen><en> Calculate the squares.
<G-vec00322-002-s314><calculate.rechnen><de> Rechne die Quadrate aus.
<G-vec00322-002-s315><calculate.rechnen><en> Now, calculate some other problems like 4 + 7 or 329 + 12.
<G-vec00322-002-s315><calculate.rechnen><de> Rechne dann auch andere Aufgaben wie 4 + 7 oder 329 + 12.
<G-vec00322-002-s316><calculate.rechnen><en> Calculate the square footage.
<G-vec00322-002-s316><calculate.rechnen><de> Rechne die Fläche aus.
