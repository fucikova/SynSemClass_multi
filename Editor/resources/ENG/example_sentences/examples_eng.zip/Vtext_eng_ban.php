<G-vec00367-001-s108><ban.bannen><en> WARNING Some of the Fedora channels ban users that are logged into their system as root .
<G-vec00367-001-s108><ban.bannen><de> Anmerkung Gewisse Fedora Kanäle bannen Benutzer, welche an ihrem System als root eingeloggt sind.
<G-vec00367-001-s109><ban.bannen><en> If you can do this, I will not ban you from my heart but will keep you as I used to.
<G-vec00367-001-s109><ban.bannen><de> Kannst du solches, so will ich dich nicht aus meinem Herzen bannen, sondern dich behalten gleich wie ehedem.
<G-vec00367-001-s110><ban.bannen><en> At the moment, Control Warrior seems to be more suited for tournaments, where one is able to ban out a bad matchup and focus on countering aggressive decks such as Pirate Warrior and Aggro Shaman.
<G-vec00367-001-s110><ban.bannen><de> In Moment scheint Control Warrior deutlich besser für Turniere geeignet zu sein, wo es möglich ist ein schlechtes Matchup zu bannen und sich stattdessen darauf zu konzentrieren, aggressive Decks wie Pirate Warrior oder Aggro Shaman auszukontern.
<G-vec00367-001-s111><ban.bannen><en> 4. Finally the most important thing: a possible fraction of the head on the photo ban.
<G-vec00367-001-s111><ban.bannen><de> 4. zum Schluss das Wichtigste: einen möglichst kleinen Ausschnitt des Kopfes auf das Foto bannen.
<G-vec00367-001-s112><ban.bannen><en> Violating the rules above will result in a kick or ban.
<G-vec00367-001-s112><ban.bannen><de> Bei Verstoß gegen die genannten Regeln verwarnen, kicken und/oder bannen wir.
<G-vec00367-001-s113><ban.bannen><en> You can also add a timed ban where the ban you placed will be removed automatically after a number of seconds specified.
<G-vec00367-001-s113><ban.bannen><de> Du kannst außerdem zeitlich begrenzt bannen, das heißt Dein Ban wird nach einer von Dir bestimmten Anzahl Sekunden wieder automatisch entfernt.
<G-vec00367-001-s261><ban.sperren><en> 2008 The tightening of the law “On Gambling” – always an identity card, all visitors are fixed, the player may, at his own request to ban the casino let him (from Gamblers protection).
<G-vec00367-001-s261><ban.sperren><de> "2008 Die Verschärfung des Gesetzes ""On Gambling"" - immer ein Ausweis, alle Besucher sind festgelegt, der Spieler darf auf eigenen Wunsch das Casino sperren lassen (vom Gamblers-Schutz)."
<G-vec00367-001-s262><ban.sperren><en> Specifically if you breach the terms of service we will ban your account.
<G-vec00367-001-s262><ban.sperren><de> Insbesondere bei einem Verstoß gegen die Nutzungsbedingungen werden wir dein Konto sperren.
<G-vec00367-001-s263><ban.sperren><en> The administration of the BetVoyager portal reserves the right to exclude or ban any player that abuses the rules of the promotion.
<G-vec00367-001-s263><ban.sperren><de> Das Management des BetVoyager-Portals behält sich das Recht vor, Spieler, die die Regeln der Promotion missbrauchen, auszuschließen oder zu sperren.
<G-vec00367-001-s264><ban.sperren><en> Generally we only ever ban for the use of actual cheats/hacks or components of such hacks which are designed to intentionally bypass BE's protection.
<G-vec00367-001-s264><ban.sperren><de> Wir sperren generell nur, wenn tatsächliche Cheats/Hacks benutzt wurden oder Komponenten von solchen Hacks, die entwickelt wurden, um absichtlich BE's Schutzsystem zu umgehen.
<G-vec00367-001-s265><ban.sperren><en> Myanmar's internet regulation policy [14] has been identified as one of the draconian measures imposed by the ruling junta but its decision to ban two weekly journals [15] for posting photos of female models in short pants didn't draw the normal level of opposition from democracy groups.
<G-vec00367-001-s265><ban.sperren><de> Die Regulierung [14] in Myanmar wird als drakonische Maßnahme der regierenden Junta gesehen, doch der Beschluss, zwei wöchentliche Journale zu sperren [15], weil sie weibliche Modells in kurzen Hosen gezeigt hatten führte kaum zu Reaktionen der Demokratie-Aktivisten.
<G-vec00367-001-s266><ban.sperren><en> Such apps even offer to identify and ban cheaters, by detecting their IP Addresses.
<G-vec00367-001-s266><ban.sperren><de> Solche Apps bieten sogarIdentifizierung an und sperren Schwindler, indem sie deren IP-Adressen ausfindig machen.
<G-vec00367-001-s267><ban.sperren><en> Depending on the circumstances and severity, we may ban your in-game account for doing this.
<G-vec00367-001-s267><ban.sperren><de> Abhängig von den Umständen und der Schwere der Verstöße kann es passieren, dass wir Euer Spielkonto aus diesen Gründen sperren.
<G-vec00367-001-s268><ban.sperren><en> In case of an attack, you can manually block a specific IP address by searching the IP in the Logs tab: right click the event line, hold the mouse cursor over the Ban remote host and then select the preferred ban type (5 minutes, 30 minutes, 1 hour or permanent ban).
<G-vec00367-001-s268><ban.sperren><de> Im Falle eines Angriffs können Sie eine bestimmte IP-Adresse manuell sperren, indem Sie die IP-Adresse in der Registerkarte Logs suchen: Rechtsklicken Sie auf die Ereigniszeile, halten Sie den Mauszeiger über Remote Host sperren und wählen Sie die gewünschte Dauer der Sperre (5 Minuten, 30 Minuten, 1 Stunde oder Dauersperre).
<G-vec00367-001-s269><ban.sperren><en> Ban remote host: allows you to ban a remote host (IP) either temporarily or permanently.
<G-vec00367-001-s269><ban.sperren><de> Remote Host sperren: Damit können Sie einen Remote Host (IP) vorübergehend oder permanent blocken.
<G-vec00367-001-s270><ban.sperren><en> A Google whistleblower, meanwhile, says that Google has been using the “Russian agent” label to try to ban journalists and whistleblowers who go against their mind-control agenda.
<G-vec00367-001-s270><ban.sperren><de> Ein Google-Whistleblower sagt inzwischen, dass Google das „russischer Agent“-Etikett benutzt hat, um zu versuchen, Journalisten und Whistleblower zu sperren, die gegen ihre mind-control-Agenda agieren.
<G-vec00367-001-s271><ban.sperren><en> Casino will instantly ban the malicious User's account without a notice and refund.
<G-vec00367-001-s271><ban.sperren><de> Casino wird sofort das Konto böswilligen Benutzers ohne Vorankündigung und Erstattung sperren.
<G-vec00367-001-s281><ban.verbannen><en> The aim of the directive is to ban toxic and environmentally dangerous substances and components from electrical and electronic devices and to speed up the introduction of replacement products.
<G-vec00367-001-s281><ban.verbannen><de> Ziel der Richtlinie ist es, giftige und umweltgefährdende Substanzen und Bestandteile aus Elektro- und Elektronikgeräten zu verbannen und die Einführung entsprechender Ersatzprodukte zu beschleunigen.
<G-vec00367-001-s282><ban.verbannen><en> After the Brothers' War, Dominaria goes cold and dark, dominated by an overzealous church determined to ban magic.
<G-vec00367-001-s282><ban.verbannen><de> Nach dem Bruderkrieg wird Dominaria zu einem kalten und dunklen Ort, beherrscht von einer übereifrigen Kirche, die entschlossen ist, sämtliche Magie zu verbannen.
<G-vec00367-001-s283><ban.verbannen><en> Dr. Karl Cox has therefore launched a petition in the UK to ban e-cigarettes from public display in shops and treat them like conventional tobacco products.
<G-vec00367-001-s283><ban.verbannen><de> Dr. Karl Cox hat deshalb in Großbritannien eine Petition lanciert, um E-Zigaretten von der öffentlichen Auslage in Shops zu verbannen und sie wie herkömmliche Tabakprodukte zu behandeln.
<G-vec00367-001-s284><ban.verbannen><en> Turn off your phone and your computer an hour before bedtime, ban all electronic devices from the bedroom and get up at the same time on weekend mornings as you do during the week.
<G-vec00367-001-s284><ban.verbannen><de> Eine Stunde vor der Bettruhe Telefon und Computer ausschalten, Elektrogeräte aus dem Bett verbannen und auch am Wochenende immer zur gleichen Zeit aufstehen wie unter der Woche.
<G-vec00367-001-s285><ban.verbannen><en> Lucas Auer: I would ban all parts that can easily break off the car.
<G-vec00367-001-s285><ban.verbannen><de> Lucas Auer: Ich würde alle Teile, die leicht abbrechen können, vom Auto verbannen.
<G-vec00367-001-s286><ban.verbannen><en> The clergy and the conservative inhabitants do not like this at all and they would rather ban the colourful ado from the small town.
<G-vec00367-001-s286><ban.verbannen><de> Sehr zum Missfallen von Kirche und konservativen Bewohnern, die das bunte Treiben am liebsten aus dem Städtchen verbannen würden.
<G-vec00367-001-s287><ban.verbannen><en> New about this fatwa was mainly that Iran’s “Supreme Leader” brazenly extended his “right” to ban and kill beyond the borders of his country and beyond the borders of Islam’s “protectorate”.
<G-vec00367-001-s287><ban.verbannen><de> Neu an dieser Fatwa war im Wesentlichen, daß Irans “Höchster Führer” sein “Recht” zu verbannen und zu töten rotzfrech über die Grenzen seines Landen hinaus ausdehnte und über die Grenzen des islamischen Protektorates.
<G-vec00367-001-s288><ban.verbannen><en> However it often takes a good deal of detective instinct to identify the substances responsible for this reaction and to ban them from the individual life.
<G-vec00367-001-s288><ban.verbannen><de> Es gehört allerdings häufig langwieriger detektivischer Spürsinn dazu, die für die Reaktion verantwortlichen Stoffe einerseits zu identifizieren und andererseits aus dem individuellen Leben zu verbannen.
<G-vec00367-001-s289><ban.verbannen><en> A lot of money flowed in the sales of hotels and casinos, to successively ban in the 70s the Mafia gangs from the city.
<G-vec00367-001-s289><ban.verbannen><de> Viel Geld floss beim Verkauf von Hotels und Casinos, um in den 70er Jahren die Mafiagangs sukzessive aus der Stadt zu verbannen.
<G-vec00367-001-s290><ban.verbannen><en> A surefire way to stop adding those extra few shakes of salt to your dinner plate is to ban the salt shaker from the dinner table altogether.
<G-vec00367-001-s290><ban.verbannen><de> Eine todsichere Methode, um die überflüssigen Prisen Salz im Abendessen wegzulassen, ist den Salzstreuer ganz vom Esstisch zu verbannen.
<G-vec00367-001-s291><ban.verbannen><en> It was interesting to watch the debate over the French government's proposal to ban the hijab in schools.
<G-vec00367-001-s291><ban.verbannen><de> Es war interessant, die Debatte zu verfolgen über den Vorschlag der französischen Regierung, den Hijab aus den Schulen zu verbannen.
<G-vec00367-001-s292><ban.verbannen><en> The EU needs to adopt tough new laws to empower authorities to punish and ultimately ban banks involved in such dealings from operating in the European market.
<G-vec00367-001-s292><ban.verbannen><de> Die EU muss strenge neue Gesetze beschließen, um die Behörden zu ermächtigen, in derartige Geschäfte verwickelte Banken zu bestrafen und in letzter Konsequenz vom europäischen Markt zu verbannen.
<G-vec00367-001-s293><ban.verbannen><en> "All other gods, except for Zeus, have to obey him; in case of refusal he can ban them from earth for a hundred years ""which, however, never happens and would never happen because all the gods are too deeply convinced of the ineffable Greatness of the Pontifex maximus."
<G-vec00367-001-s293><ban.verbannen><de> Außer dem Zeus müßten ihm alle anderen Götter gehorchen; im Verweigerungsfalle könnte er sie auf hundert Jahre von der Erde verbannen, – was aber nie geschähe und nie geschehen werde, weil alle Götter von der unaussprechlichsten Hoheit des Pontifex maximus zu sehr und zu lebenstief überzeugt seien.
<G-vec00367-001-s294><ban.verbannen><en> The RoHS directive aims to ban harmful substances from electrical engineering.
<G-vec00367-001-s294><ban.verbannen><de> Die RoHS-Richtlinien verfolgen das Ziel, schädliche Substanzen aus der Elektrotechnik zu verbannen.
<G-vec00367-001-s295><ban.verbannen><en> The scholarship holders considered a variety of topics during an impressive discussion – from rebuilding the health care system through fighting corruption to calling for a ban on political and religious influences on universities.
<G-vec00367-001-s295><ban.verbannen><de> In einer beeindruckenden Diskussion behandelten die Stipendiaten unterschiedlichste Fragestellungen – vom Wiederaufbau des Gesundheitswesens über den Kampf gegen Korruption bis zur Forderung, politischen und religiösen Einfluss von den Hochschulen zu verbannen.
<G-vec00367-001-s296><ban.verbannen><en> "Hong Kong would be forced to ban any organization determined by China as a national security risk, which would seriously put at risk the freedom and democracy in Hong Kong, and thereby making a mockery of HK's autonomy and ""one country, two systems"" policy."
<G-vec00367-001-s296><ban.verbannen><de> "Hongkong würde dazu gezwungen jede Organisation zu verbannen, die China als eine Gefährdung der Nationalen Sicherheit betrachtet, welche ernsthaft die Freiheiten und die Demokratie in China gefährden und dadurch einen Hohn aus Hongkongs Autonomie und ""Ein Land, zwei Systeme"" machen würde."
<G-vec00367-001-s297><ban.verbannen><en> But before he would reach the cave he would have to ban some shadows from his consciousness.
<G-vec00367-001-s297><ban.verbannen><de> Doch bevor er die Höhle erreichen würde, musste er noch einige Schatten aus seinem Bewusstsein verbannen.
<G-vec00367-001-s298><ban.verbannen><en> "It is anyway a good idea to ""ban"" 0 as a normal ID value, to avoid any confusion with NULL and 0."
<G-vec00367-001-s298><ban.verbannen><de> "Es ist ohnehin eine gute Idee, die 0 als normalen ID-Wert zu ""verbannen"", allein schon um Verwechslungen zwischen NULL und 0 zu vermeiden."
<G-vec00367-001-s299><ban.verbannen><en> COMSOL Access moderators will remove any generally objectionable material as quickly as possible and may ban from any forum a contributor of objectionable content.
<G-vec00367-001-s299><ban.verbannen><de> COMSOL Access Moderatoren werden generell anstößiges Material so schnell wie möglich entfernen und können einen Verfasser von anstößigen Inhalten aus jedem Forum verbannen.
<G-vec00367-001-s300><ban.verbieten><en> Around two hundred women's rights groups last week called on the EU Parliament to ban prostitution across Europe.
<G-vec00367-001-s300><ban.verbieten><de> Rund zweihundert Aktionsgruppen für Frauenrechte haben in der vergangenen Woche das EU-Parlament aufgefordert, Prostitution in Europa flächendeckend zu verbieten.
<G-vec00367-001-s301><ban.verbieten><en> The campaign STOP THE BOMB calls on the German government to ban Hizbullah in Germany and to push for placing Hizbullah on the EU list of terrorist organizations.
<G-vec00367-001-s301><ban.verbieten><de> Die Kampagne STOP THE BOMB fordert die Bundesregierung auf, die Hisbollah in Deutschland zu verbieten und sich auf EU-Ebene dafür einzusetzen, dass die Organisation auf die EU Terrorliste gesetzt wird.
<G-vec00367-001-s302><ban.verbieten><en> """Also, member states will be able to limit or ban GMOs in their territory on environmental, agricultural or socio-economic grounds."
<G-vec00367-001-s302><ban.verbieten><de> Außerdem werden die Mitgliedsstaaten GVO auf ihrem Hoheitsgebiet aus ökologischen, landwirtschaftlichen oder sozioökonomischen Gründen einschränken oder verbieten können.
<G-vec00367-001-s303><ban.verbieten><en> According to the Convention, member states must not only refrain from committing acts of genocide but must also ban, prosecute and punish them.
<G-vec00367-001-s303><ban.verbieten><de> Gemäss der Konvention müssen Mitgliedstaaten nicht nur davon Abstand nehmen, Völkermord zu begehen, sondern ihn auch verbieten sowie die Täter strafrechtlich verfolgen und bestrafen.
<G-vec00367-001-s304><ban.verbieten><en> This could be an idea about a new rule or a new way of doing things: let's recycle and try to protect the environment, let's make it illegal for a husband to beat his wife, let's put public money together and create free health care, let's ban chemical weapons.
<G-vec00367-001-s304><ban.verbieten><de> Das könnte eine Idee für eine neue Regel oder eine neue Art und Weise sein, Dinge zu tun: Lasst uns recyceln und versuchen, die Umwelt zu schützen, lasst es uns für Ehemann illegal machen, ihre Frauen zu schlagen, lasst uns öffentliche Gelder zusammenlegen und eine kostenlose Gesundheitsfürsorge schaffen, lasst uns chemische Waffen verbieten.
<G-vec00367-001-s305><ban.verbieten><en> Although, there are always discussions in order to limit the cash or even to ban it completely, but it currently looks like that cash will remain active in Germany for a long time.
<G-vec00367-001-s305><ban.verbieten><de> Zwar gibt es immer wieder Diskussionen, das Bargeld einzuschränken oder gar ganz zu verbieten, aber so, wie es aktuell aussieht, wird es in Deutschland noch lange Bargeld geben.
<G-vec00367-001-s306><ban.verbieten><en> A theory or insight cannot be eliminated by attempts to suppress or even to ban it, by whatever means.
<G-vec00367-001-s306><ban.verbieten><de> Eine These oder Erkenntnis ist nicht damit aus der Welt zu schaffen, indem man versucht, sie mit irgendwelchen Mitteln zu unterdrücken oder gar zu verbieten.
<G-vec00367-001-s307><ban.verbieten><en> Nations starting to Ban Aspartame Both Indonesia and South Africa are leading the world in firmly moving towards prohibiting this chemical for medical reasons: aspartame is an excitotoxin and causes brain damage.
<G-vec00367-001-s307><ban.verbieten><de> Staaten beginnen, Aspartam zu verbieten Sowohl Indonesien, als auch Südafrika sind führend auf der Welt darin, dass sie stetig auf ein Verbot dieser chemischen Substanz für medizinische Zwecke hinarbeiten: Aspartam ist ein Exitotoxin und verursacht Gehirnschäden.
<G-vec00367-001-s308><ban.verbieten><en> It is impossible to stop or ban a compelling new idea; as Victor Hugo said, “Nothing is more powerful than an idea whose time has come.” We are on the cusp of an unstoppable explosion of innovation powered by advances in science, technology, venture capital and entrepreneurship.
<G-vec00367-001-s308><ban.verbieten><de> Es ist unmöglich, eine überzeugende neue Idee zu stoppen oder zu verbieten; wie Victor Hugo sagte: “”Nichts ist mächtiger als eine Idee, deren Zeit gekommen ist.”” Wir sind auf der Schwelle zu einer unaufhaltsamen Explosion der Innovation durch die Fortschritte in der Wissenschaft, Technologie, Risikokapital und Unternehmertum angetrieben sind.
<G-vec00367-001-s309><ban.verbieten><en> Therefore, we must continue to improve internal combustion engines, rather than wanting to ban them outright,” Welcker warned.
<G-vec00367-001-s309><ban.verbieten><de> Deshalb müssen wir auch weiterhin an der Verbesserung des Verbrennungsmotors arbeiten, statt ihn verbieten zu wollen“, mahnte Welcker.
<G-vec00367-001-s310><ban.verbieten><en> There are currently considerations to make the removal of copy protection into a punishable offence, or even to ban research and development work on algorithms that could achieve this, and trials are underway.
<G-vec00367-001-s310><ban.verbieten><de> Es gibt Überlegungen und Versuche, das Aufheben von Kopierschutz mit Strafen zu bewehren, oder sogar die Forschung und Entwicklung an Algorithmen zu verbieten.
<G-vec00367-001-s311><ban.verbieten><en> In their documents, it was made very clear that they would ban the practice first, then collect evidence to support the ban.
<G-vec00367-001-s311><ban.verbieten><de> In ihren Dokumenten stand ganz klar, dass sie zuerst das Praktizieren verbieten wollten und dann Beweise sammeln würden, um ihr Verbot zu unterstützen.
<G-vec00367-001-s312><ban.verbieten><en> This provision can be used to ban parties like the Kurdistan Democratic Party – Syria (PDK‐S), the sister party of Masʿud Barzani's Iraqi-Kurdish KDP.
<G-vec00367-001-s312><ban.verbieten><de> Diese Vorgabe kann dazu genutzt werden, Parteien wie die Demokratische Partei Kurdistans – Syrien (PDK‐S), die Schwesterpartei der irakischkurdischen KDP von Masʿud Barzani, zu verbieten.
<G-vec00367-001-s313><ban.verbieten><en> Hurt Help Help, but ban their ability to make political donations
<G-vec00367-001-s313><ban.verbieten><de> Helfen, aber man sollte ihre Fähigkeit politische Spenden zu machen verbieten.
<G-vec00367-001-s314><ban.verbieten><en> """It basically started in 1999 when the Chinese authorities decided to ban Falun Gong."
<G-vec00367-001-s314><ban.verbieten><de> """Es begann 1999, als die chinesischen Behörden beschlossen, Falun Gong zu verbieten."
<G-vec00367-001-s315><ban.verbieten><en> it should be noted that you COULD adjust the “name of the service” configuration line from sshd to ALL and then you would ban the offending IP address from ALL system services.
<G-vec00367-001-s315><ban.verbieten><de> ist darauf hinzuweisen, dass man das einstellen werden “Name des Dienstes” Konfiguration von sshd Linie an alle und dann würden die betroffenen IP-Adresse aus alle Systemdienste verbieten.
<G-vec00367-001-s316><ban.verbieten><en> Here it is: This week, the Brazilian prosecuting authorities are going to receive the organic farmers’ demand to ban Endosulfan immediately.
<G-vec00367-001-s316><ban.verbieten><de> Es ist soweit: Diese Woche erhält die Brasilianische Staatsanwaltschaft die Forderung der Biobauern, Endosulfan per sofort zu verbieten.
<G-vec00367-001-s317><ban.verbieten><en> They would filter out and ban anything that might cause a problem.
<G-vec00367-001-s317><ban.verbieten><de> Sie würden alles, was in irgendeiner Form ein Problem verursachen könnte, herausfiltern und verbieten.
<G-vec00367-001-s318><ban.verbieten><en> Decisive action of the Belarusian Ministry of Emergency Rosselkhoznadzor coincided with the decision to ban import of meat from the Brest and Gomel slaughterhouses.
<G-vec00367-001-s318><ban.verbieten><de> Entschlossenes Handeln der belarussischen Ministry of Emergency Rosselkhoznadzor fiel mit der Entscheidung Гjber die Einfuhr von Fleisch aus Brest und Gomel SchlachthГ¶fen zu verbieten.
