<EnglishT-wsj_1158-s31#EnglishT-wsj_1158-s31-t14><ev-w10f2.v-w3134f1> In one, birds are the dominant carnivores; in another the seas <start_vs>abound<end_vs> with ``little penises.'' 
