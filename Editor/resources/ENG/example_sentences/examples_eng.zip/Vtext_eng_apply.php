<G-vec00272-001-s019><apply.anwenden><en> You agree that the laws of Switzerland without regard to conflicts of law principles thereof, shall apply to all matters relating to the use of the Website and these Terms of Use.
<G-vec00272-001-s019><apply.anwenden><de> Sie erklären sich damit einverstanden, dass die belgischen Gesetze ohne Rücksicht auf Konflikte mit darin enthaltenen Gesetzesprinzipien auf sämtliche Belange der Nutzung dieser 'Website' angewendet werden.
<G-vec00272-001-s020><apply.anwenden><en> And the same principles apply here, on the meditative level, as apply in the Buddha's comments to Rahula on action in general.
<G-vec00272-001-s020><apply.anwenden><de> Das selbe Prinzip, hier auf der meditativen Ebene angewendet, paßt in Buddhas Bemerkungen, zu Rahulas Handlungen, im Generellen.
<G-vec00272-001-s021><apply.anwenden><en> We also apply simplified technique for sensor with lower precision.
<G-vec00272-001-s021><apply.anwenden><de> Für Sensoren mit geringerer Präzision werden vereinfachte Methoden angewendet.
<G-vec00272-001-s022><apply.anwenden><en> Whether you elect to earn Miles as your earning preference or decide instead to earn Points and later convert them into Miles, each Airline Program maintains its own rules, regulations, and program terms and conditions, all of which will apply to your use of any Miles.
<G-vec00272-001-s022><apply.anwenden><de> Jedes Vielfliegerprogramm hat seine eigenen Regeln, Vorschriften und Geschäftsbedingungen des Programms, welche alle auf Ihren Gebrauch von Meilen angewendet werden, unabhängig davon, ob Sie Meilen sammeln, oder Punkte sammeln und diese später in Meilen umwandeln.
<G-vec00272-001-s023><apply.anwenden><en> The Urban Sprawl Metrics (USM) Toolset allows to intuitively apply intuitvely possible to apply the method of Weighted Urban Proliferation.
<G-vec00272-001-s023><apply.anwenden><de> Mit dem Onlinetool (USM: Urban Sprawl Metrics tool) kann die Methode der gewichteten Zersiedelung intuitiv angewendet werden.
<G-vec00272-001-s024><apply.anwenden><en> Our experienced instructors apply years of service expertise to help your staff learn how to operate instruments properly and apply corrective and preventive maintenance of your measurement devices.
<G-vec00272-001-s024><apply.anwenden><de> Unsere erfahrenen Schulungsleiter stützen sich auf jahrelange Fachkompetenz im Bereich Services, um Ihren Mitarbeitern beizubringen, wie die Geräte korrekt bedient und korrigierende sowie vorbeugende Wartungsmaßnahmen auf Ihre Messgeräte angewendet werden.
<G-vec00272-001-s025><apply.anwenden><en> Note: If you defined several criteria on the same array attribute, the matched criteria will not necessarily apply to the same array element.
<G-vec00272-001-s025><apply.anwenden><de> Hinweis: Haben Sie im selben Array Attribut mehrere Kriterien definiert, wird das passende Kriterium nicht zwingend auf dasselbe Array Element angewendet.
<G-vec00272-001-s026><apply.anwenden><en> Since each of these events apply across the entire project, each event could be triggered by the audio on any channel.
<G-vec00272-001-s026><apply.anwenden><de> Da jedes dieser Ereignisse auf das gesamte Projekt angewendet wird, könnte jedes Ereignis vom Audio auf einem beliebigen Kanal ausgelöst werden.
<G-vec00272-001-s027><apply.anwenden><en> In these cases it is recommended to apply a cream layer, preventing the mask from drying, or using it after removing the mask.
<G-vec00272-001-s027><apply.anwenden><de> In diesem Fall ist es zweckmäßig, dass nicht zum vollen Maskenaustrocknen kommt und nach dem Entfernen die Creme angewendet wird.
<G-vec00272-001-s028><apply.anwenden><en> If any provision of these rules is invalid under the law, rules or regulations of a particular country, it will only apply to the extent permitted.
<G-vec00272-001-s028><apply.anwenden><de> Wenn eine Auslegung dieser Regeln nach den Gesetzen, Regeln oder Vorschriften eines bestimmten Landes ungültig ist, wird sie nur im zulässigen Umfang angewendet.
<G-vec00272-001-s029><apply.anwenden><en> Articles 163-171 apply to parliamentary investigation committees that are appointed after the date on which this Act comes into force.
<G-vec00272-001-s029><apply.anwenden><de> Die Artikel 163-171 werden auf die parlamentarischen Untersuchungskommissionen angewendet, die nach Inkrafttreten des Gesetzes eingesetzt werden.
<G-vec00272-001-s030><apply.anwenden><en> Multipliers of x1, x2, x3, x5 or up to x7 apply to every win occurring after every symbol dropping action.
<G-vec00272-001-s030><apply.anwenden><de> Multiplikatoren von x1, x2, x3, x5 oder bis x7 werden auf jeden Gewinn angewendet und treten nach jedem Symbolabwurf auf.
<G-vec00272-001-s031><apply.anwenden><en> "Under the Immigration Act's ""Purpose of Legislation"", punishment of ""assistance"" or ""promotion"" against illegal work must apply Article 73-2 of the Immigration Act ""Crime that promotes illegal labor""."
<G-vec00272-001-s031><apply.anwenden><de> "Im ""Gesetzgebungszweck"" des Zuwanderungsgesetzes wird die Bestrafung von ""Hilfe"" oder ""Beförderung"" gegen illegale Arbeit,Artikel 73-2 des Immigration Control Act ""Sin zur Förderung illegaler Arbeit"" muss angewendet werden."
<G-vec00272-001-s032><apply.anwenden><en> 4. Where, by reason or a special relationship between the payor and the beneficial owner or between both of them and some other person, the amount of the royalties, having regard to the use, right, or information for which they are paid, exceeds the amount that would have been agreed upon by the payor and the beneficial owner in the absence of such relationship, the provisions or this Article shall apply only to the last-mentioned amount.
<G-vec00272-001-s032><apply.anwenden><de> (4) Bestehen zwischen dem Schuldner und dem Nutzungsberechtigten oder zwischen jedem von ihnen und einem Dritten besondere Beziehungen und übersteigen deshalb die Lizenzgebühren, gemessen an der zugrundeliegenden Leistung, den Betrag, den Schuldner und Nutzungsberechtigter ohne diese Beziehungen vereinbart hätten, so wird dieser Artikel nur auf den letzteren Betrag angewendet.
<G-vec00272-001-s033><apply.anwenden><en> Opens the Application Defaults dialog box in which you can configure default settings that apply to all applications.
<G-vec00272-001-s033><apply.anwenden><de> Öffnet das Dialogfeld Anwendungsstandardwerte, in dem Sie Standardwerte konfigurieren können, die auf alle Anwendungen angewendet werden.
<G-vec00272-001-s034><apply.anwenden><en> Schwarzkopf Dandruff Control Fluid, after washing, apply to the scalp.
<G-vec00272-001-s034><apply.anwenden><de> Schwarzkopf Dandruff Control Fluid, nach dem Waschen angewendet auf die Kopfhaut.
<G-vec00272-001-s035><apply.anwenden><en> 3 Â Unless otherwise determined by an Ordinance issued by the Federal Assembly, these implementing provisions where appropriate apply to data relating to members of the Federal Assembly and the staff of the Parliamentary Services.
<G-vec00272-001-s035><apply.anwenden><de> 3 Soweit Daten von Mitgliedern der Bundesversammlung oder des Personals der Parlamentsdienste betroffen sind, werden diese Ausführungsbestimmungen angewendet, sofern nicht eine Verordnung der Bundesversammlung etwas anderes bestimmt.
<G-vec00272-001-s036><apply.anwenden><en> These principles should apply to all projects intended to help countries adapt to or mitigate the impact of climate change.
<G-vec00272-001-s036><apply.anwenden><de> Diese Prinzipien sollten auf alle Projekte angewendet werden, die den Ländern helfen, sich an die Folgen des Klimawandels anzupassen oder diese abzumildern.
<G-vec00272-001-s037><apply.anwenden><en> View the Precision 7530 Mobile Workstation Learn more about this family Other PC solutions can apply.
<G-vec00272-001-s037><apply.anwenden><de> Precision 7530 Mobile Workstation anzeigen Weitere Informationen über diese Produktreihe Andere PC-Lösungen können angewendet werden.
<G-vec00272-001-s057><apply.anwenden><en> You may apply this artificial lawn to your backyard, golf area, tennis court and even a huge football field and there are proper methods to apply.
<G-vec00272-001-s057><apply.anwenden><de> Sie können diese künstlichen Rasen zu Ihrem Hinterhof, Golfplatz, Tennisplatz und sogar ein großer Fußballplatz und gibt es richtige Methoden anwenden.
<G-vec00272-001-s058><apply.anwenden><en> JMP allows Cree's production teams to visualize and communicate issues in the process, collect data on those issues, apply models, study the effects of interactions and demonstrate improvement.
<G-vec00272-001-s058><apply.anwenden><de> Lösung Mit JMP können die Produktionsteams von Cree Probleme innerhalb des Prozesses visualisieren und kommunizieren, Daten zu diesen Problemen sammeln, Modelle anwenden, die Auswirkungen von Interaktionen untersuchen und Verbesserungen nachweisen.
<G-vec00272-001-s059><apply.anwenden><en> It works on ANY timeframe from M15 to D1… Trust me traders, once you apply this unique tool to your trading platform, you will never use anything else ever again.
<G-vec00272-001-s059><apply.anwenden><de> Es funktioniert auf jeden Zeitraum von M15 bis D1… Vertrauen Sie mir Händler, wenn Sie dieses einzigartige Tool Ihre Handelsplattform anwenden, Sie werden nie wieder etwas anderes verwenden.
<G-vec00272-001-s060><apply.anwenden><en> If you have Kutools for Outlook installed, you can apply its Safe Attachment Extensions option to unblock specified types of blocked attachments quickly, and then delete them easily.
<G-vec00272-001-s060><apply.anwenden><de> Wenn Sie Kutools für Outlook installiert haben, können Sie dessen anwenden Sichere Anhangserweiterungen Option, um bestimmte Typen gesperrter Anhänge schnell zu entsperren und sie dann einfach zu löschen.
<G-vec00272-001-s061><apply.anwenden><en> Note: If you check Don’t show me next time in the Synchronize Worksheets prompt box, this box will not appear when you apply this feature next time.
<G-vec00272-001-s061><apply.anwenden><de> Text: Wenn Sie überprüfen Zeig es mir beim nächsten Mal nicht schwimmen Arbeitsblätter synchronisieren Wenn Sie dieses Feature das nächste Mal anwenden, wird dieses Feld nicht angezeigt.
<G-vec00272-001-s062><apply.anwenden><en> Farmers, who have the status of agricultural producers, can receive and apply for all types of state support.
<G-vec00272-001-s062><apply.anwenden><de> Landwirte mit landwirtschaftlichem Zustand erhalten und für alle Arten von Staat anwenden können.
<G-vec00272-001-s063><apply.anwenden><en> If you have Kutools for Outlook installed, you can apply its Advanced Print feature to quickly print a sent email with all Bcc recipients at ease.
<G-vec00272-001-s063><apply.anwenden><de> Wenn Sie Kutools für Outlook installiert haben, können Sie dessen anwenden Erweiterter Druck Funktion zum schnellen Drucken einer gesendeten E-Mail mit allen Bcc-Empfängern.
<G-vec00272-001-s064><apply.anwenden><en> This online programme will develop students' intellectual, practical and critical-thinking skills to enable them to apply subject-related knowledge and solve problems, which would be expected of an entry-level accountant in an international practice.
<G-vec00272-001-s064><apply.anwenden><de> Dieses Online-Programm wird die intellektuellen, praktischen und kritischen Denkfähigkeiten der Schüler entwickeln, damit sie fachbezogenes Wissen anwenden und Probleme lösen können, die von einem Buchhalter in einer internationalen Praxis erwartet werden.
<G-vec00272-001-s065><apply.anwenden><en> At the end of the workshop participants were able to learn the effects of shock wave therapy Storz in his own body, and of course this also apply self-service benefit of a K-Active Tape.
<G-vec00272-001-s065><apply.anwenden><de> Am Ende des Workshops konnten die Teilnehmer die Wirkungen der Storz Stoßwellentherapie am eigenen Leib erfahren, diese auch selbst anwenden und natürlich begleitend in den Genuss eines K-Active Tapes kommen.
<G-vec00272-001-s066><apply.anwenden><en> Once we have defined the Roles in the Tag Type, we are ready to apply them.
<G-vec00272-001-s066><apply.anwenden><de> Sobald wir die Funktionen im Rahmen des jeweiligen Elementtyps definiert haben, können wir sie im Anschluß unmittelbar anwenden.
<G-vec00272-001-s067><apply.anwenden><en> The same rules as of it BK Powertool Dragracing apply.
<G-vec00272-001-s067><apply.anwenden><de> Die gleichen Regeln wie davon BK Powertool Dragracing anwenden.
<G-vec00272-001-s068><apply.anwenden><en> If you are first to act, you only need to look at the stack sizes of the players remaining to determine if you can apply the concept.
<G-vec00272-001-s068><apply.anwenden><de> Wenn du als erster an der Reihe bist musst du nur die Stacks der anderen Spieler in Betracht ziehen um zu entscheiden, ob du das Konzept anwenden kannst.
<G-vec00272-001-s069><apply.anwenden><en> If the object does not function with the hotspot, one can apply the selected object to another hotspot or put it back again with right-click.
<G-vec00272-001-s069><apply.anwenden><de> Falls das Objekt nicht mit dem Hotspot funktioniert, kann man das ausgewählte Objekt auf einen anderen Hotspot anwenden oder es mit Rechtsklick wieder ins Inventar legen.
<G-vec00272-001-s070><apply.anwenden><en> This formulation is superb since you do not have to apply anything to or around the anus.
<G-vec00272-001-s070><apply.anwenden><de> Diese Formulierung ist hervorragend, da Sie etwas oder um den Anus nicht anwenden müssen.
<G-vec00272-001-s071><apply.anwenden><en> When the Scripture says that we are to 'prove all things', we should apply that especially to the things which could serve the evil powers in their propaganda of suspicions, leading to divisions.
<G-vec00272-001-s071><apply.anwenden><de> Wenn die Schrift sagt, wir sollten «alles prüfen», sollten wir dies besonders auf die Dinge anwenden, die den bösen Mächten in ihrer Propaganda und ihrem Misstrauen helfen könnten, Trennungen zu verursachen.
<G-vec00272-001-s072><apply.anwenden><en> Since the start of the Advanced Clinical Courses, L.RonHubbard had been developing processes that could be taught, that auditors could apply.
<G-vec00272-001-s072><apply.anwenden><de> Seit dem Beginn der Fortgeschrittenen Wissenschaftlichen Kurse hatte L. Ron Hubbard Prozesse entwickelt, die gelehrt werden konnten und die Auditoren anwenden konnten.
<G-vec00272-001-s073><apply.anwenden><en> We may use your IP address in cooperation with your Internet access provider in order to identify you in the case of having to apply conditions of use to protect our services and clients, or in order to comply with laws in force.
<G-vec00272-001-s073><apply.anwenden><de> Wir können Ihre IP-Adresse in Zusammenarbeit mit Ihrem Internetanbieter für Ihre Identifizierung nutzen, für den Fall, dass wir die Nutzungsbedingungen zum Schutz unserer Dienste, Kunden oder für die Einhaltung der geltenden Gesetze anwenden müssen.
<G-vec00272-001-s074><apply.anwenden><en> And if worked out well, it will become a service that you can take, a product that is visible and a technology that we can apply.
<G-vec00272-001-s074><apply.anwenden><de> Und wenn es fertig ausgearbeitet ist, wird es eine Dienstleistung werden, die Ihr nehmen könnt, ein sichtbares Produkt und eine Technologie, die wir anwenden können.
<G-vec00272-001-s075><apply.anwenden><en> This lets you do editing by layer, apply different color palettes, modify RGB and grayscale values, among other tasks.
<G-vec00272-001-s075><apply.anwenden><de> Auf diese Weise können Sie durch die Ebenen bearbeiten, unterschiedliche Farbpaletten anwenden, RGB und Graustufen-Werte ändern, neben anderen Aufgaben.
<G-vec00272-001-s114><apply.anwenden><en> Therefore, varnished floorboard is recommended to periodically apply a protective coating.
<G-vec00272-001-s114><apply.anwenden><de> Daher wird lackierten Bodenplatte empfohlen, regelmäßig eine Schutzbeschichtung anzuwenden.
<G-vec00272-001-s115><apply.anwenden><en> The NCP also reminded the company of its responsibility for its supply chain and invited Devcot to carry out due diligence and to apply the recommendations of the OECD towards its trade partners.
<G-vec00272-001-s115><apply.anwenden><de> Die NKS weist das Unternehmen auf seine Verantwortung für die Zulieferkette hin und forderte es auf, eine sorgfältige Prüfung („due diligence“) durchzuführen und die OECD-Leitsätze auch im Verhältnis zu ihren Handelspartnern anzuwenden.
<G-vec00272-001-s116><apply.anwenden><en> As a result of a ruling by the German Federal Fiscal Court (BFH) published recently by the German Federal Ministry of Finance on page 367 of Part II of the Federal Tax Gazette 2011, there is a risk that Deutsche EuroShop AG may no longer be able to apply the above-mentioned tax treatment in future.
<G-vec00272-001-s116><apply.anwenden><de> Aufgrund eines kürzlich vom Bundesministerium der Finanzen im Bundessteuerblatt II 2011, Seite 367, veröffentlichten Urteils des Bundesfinanzhofes (BFH) besteht das Risiko, dass die o. g. steuerliche Handhabung für die Deutsche EuroShop AG zukünftig nicht mehr anzuwenden ist.
<G-vec00272-001-s117><apply.anwenden><en> In the English league rule apply inheritance and promotion.
<G-vec00272-001-s117><apply.anwenden><de> In der englischen Liga Regel anzuwenden Erbe und Förderung .
<G-vec00272-001-s118><apply.anwenden><en> To apply existing assistive technologies frameworks, sensors, and actuators, and furthermore to independently realize software components for the practical, simple integration of specific hardware control elements
<G-vec00272-001-s118><apply.anwenden><de> bestehende Assistive Technologies Frameworks, Sensoren und Aktoren anzuwenden und in weiterer Folge selbst Software-Komponenten zur einfachen Integration von spezifischen Hardware-Bedienelementen praktisch umzusetzen.
<G-vec00272-001-s119><apply.anwenden><en> The Bachelor's programme aims to provide an overview of the fundamental interrelationships in the renewable energy sector, to apply the acquired knowledge in the professional field and to be able to independently familiarise oneself with new tasks.
<G-vec00272-001-s119><apply.anwenden><de> Der Bachelorstudiengang zielt darauf, einen Überblick über die grundlegenden Zusammenhänge des Sektors der Erneuerbaren Energien zu bieten, die erworbenen Kenntnisse im Berufsfeld anzuwenden und in der Lage zu sein, sich selbstständig in neue Aufgabenstellungen einarbeiten zu können.
<G-vec00272-001-s120><apply.anwenden><en> The compound is anaerobic, sensor safe and very easy to apply.
<G-vec00272-001-s120><apply.anwenden><de> Das Produkt ist anaerob, thixotrop und sehr einfach anzuwenden.
<G-vec00272-001-s121><apply.anwenden><en> • In the columns of Il Giornale (Italy), Olan Micalessin denounces Hillary Clinton for wanting to apply the Libyan plan to Syria.
<G-vec00272-001-s121><apply.anwenden><de> • Olan Micalessin denunziert im Il Giornale den Willen von Hillary Clinton, ihren libyschen Plan auf Syrien anzuwenden.
<G-vec00272-001-s122><apply.anwenden><en> The ability to apply fundamental techniques and tools in the computing disciplines.
<G-vec00272-001-s122><apply.anwenden><de> Die Fähigkeit, grundlegende Techniken und Werkzeuge in den Computerdisziplinen anzuwenden.
<G-vec00272-001-s123><apply.anwenden><en> What's more, we provide support to our customers who want to apply virtual human simulation methods themselves.
<G-vec00272-001-s123><apply.anwenden><de> Darüber hinaus unterstützen wir unser Auftraggeber, Methoden der Virtual Human Simulation auch selbstständig anzuwenden.
<G-vec00272-001-s124><apply.anwenden><en> HEIMESS helps the very youngest children to discover the world through simple shapes and colours and to apply their newly acquired skills.
<G-vec00272-001-s124><apply.anwenden><de> HEIMESS hilft den allerkleinsten Kindern durch einfache Formen und Farben, die Welt zu entdecken und die neuerworbenen Fähigkeiten anzuwenden.
<G-vec00272-001-s125><apply.anwenden><en> Since all these settings are locating in separately in Word, it's not easy for us to remember and apply them when we need to.
<G-vec00272-001-s125><apply.anwenden><de> Da alle diese Einstellungen separat in Word gefunden werden, ist es für uns nicht einfach, sie zu speichern und sie bei Bedarf anzuwenden.
<G-vec00272-001-s126><apply.anwenden><en> In Mr. Nada's case, a man with perfect references, against whom no charge was found, to continue to apply the sanctions against him is simply to obey the diktat of the United States and to accept the reign of arbitrariness and lawlessness.
<G-vec00272-001-s126><apply.anwenden><de> Weiterhin gegen Herrn Nada, einen Mann mit ausgezeichneten Empfehlungen, gegen den kein belastendes Material vorliegt, Sanktionen anzuwenden, bedeutet ganz einfach sich dem Diktat der Vereinigten Staaten zu beugen und die Herrschaft der Willkür und der Rechtlosigkeit zu akzeptieren.
<G-vec00272-001-s127><apply.anwenden><en> An attempt was made to apply a matrix operation to two matrices of different data types.
<G-vec00272-001-s127><apply.anwenden><de> Es wurde versucht, eine Matrix-Operation auf zwei Matrizen unterschiedlichen Datentyps anzuwenden.
<G-vec00272-001-s128><apply.anwenden><en> If you are heading out after a tedious day, speedily apply matte powder to oily areas.
<G-vec00272-001-s128><apply.anwenden><de> Wenn Sie Position heraus nach einer langweiligen Tag, matte Pulver schnell auf öligen Bereichen anzuwenden.
<G-vec00272-001-s129><apply.anwenden><en> This principle, however, by definition does not apply to third parties so that it cannot be deduced from it that the EPO is under an obligation to apply the TRIPS Agreement, even if this might be desirable in the interest of international harmonisation of substantive patent law.
<G-vec00272-001-s129><apply.anwenden><de> Dieser Grundsatz gilt aber per definitionem nicht für Dritte, so daß daraus nicht abgeleitet werden kann, daß das EPA verpflichtet ist, das TRIPS-Übereinkommen anzuwenden, so wünschenswert dies im Interesse der internationalen Harmonisierung des materiellen Patentrechts wäre.
<G-vec00272-001-s130><apply.anwenden><en> We've trained our AI Style Engine for PowerDirector to analyze your footage frame by frame and intelligently apply brushstrokes so your video looks like moving Chinese traditional paintings.
<G-vec00272-001-s130><apply.anwenden><de> Wir haben unsere AI Style Engine für PowerDirector trainiert, um Ihr Filmmaterial Bild für Bild zu analysieren und Pinselstriche intelligent anzuwenden, damit Ihr Video wie bewegte chinesische Gemälde aussieht.
<G-vec00272-001-s131><apply.anwenden><en> Answer from such purpose that human experience of the priest does not need to apply their own horizon of the secular - economy, finance, militia, politics, family, technology, industry and commerce -, because it focuses on human values â â that are at the root and the purpose of existence, more relevant to the meaning of life and history, to the problem of suffering, of sin and salvation, the need for truth, of Justice, of peace, of freedom and happiness, the moral values, Religious and Spiritual, the relationship with God.
<G-vec00272-001-s131><apply.anwenden><de> Antwort von einem solchen Zweck dass die menschliche Erfahrung des Priesters muss nicht ihren eigenen Horizont der säkularen anzuwenden - Wirtschaft, Finanzen, Miliz, Politik, Familie, Technologie, Industrie und Handel -, weil es konzentriert sich auf menschliche Werte, die an der Wurzel und den Zweck der Existenz, mehr relevant für den Sinn des Lebens und der Geschichte, auf das Problem des Leidens, von Sünde und Erlösung, das Bedürfnis nach Wahrheit, der Gerechtigkeit, Frieden, von Freiheit und Glück, die moralischen Werte, Religiöse und spirituelle, die Beziehung zu Gott.
<G-vec00272-001-s132><apply.anwenden><en> “TAKT Academy enabled us, the young undergraduates, to practically apply our acquired theoretical knowledge.
<G-vec00272-001-s132><apply.anwenden><de> „Die TAKT Akademie hat uns, den jungen Diplomanden, ermöglicht, unsere erlangten theoretischen Kenntnisse jetzt auch in der Praxis anzuwenden.
<G-vec00272-001-s171><apply.auftragen><en> Clean the screws, apply GLEITMO 165 to the thread root and the contact surface of the screw head without excess using a paint brush or spray on.
<G-vec00272-001-s171><apply.auftragen><de> Schrauben reinigen, GLEITMO 165 mit Pinsel bis auf den Gewindegrund und auf der Auflagefläche des Schraubenkopfes ohne Überschuss auftragen oder aufsprühen.
<G-vec00272-001-s172><apply.auftragen><en> Apply Strobing Powder using the Eye Shadow Brush large and blend in.
<G-vec00272-001-s172><apply.auftragen><de> Strobing Powder mit dem Eye Shadow Brush large auftragen und verblenden.
<G-vec00272-001-s173><apply.auftragen><en> Use: Apply generously to clean, wet hair from roots to ends, massage in and leave for 3 to 5 minutes.
<G-vec00272-001-s173><apply.auftragen><de> Anwendung: Großzügig auf sauberes, feuchtes Haar von den Wurzeln bis zu den Spitzen auftragen, einmassieren und 3 bis 5 Minuten einwirken lassen.
<G-vec00272-001-s174><apply.auftragen><en> Apply a thin layer of the Nude Illusion Make Up and blend with the Camouflage Cream.
<G-vec00272-001-s174><apply.auftragen><de> Das Nude Illusion Make Up dünn auftragen und mit der Camouflage Cream verblenden.
<G-vec00272-001-s175><apply.auftragen><en> Keiki initiation will be better if: you apply KEIKIBOOST one week at least after the last flower fell, apply KEIKI on the lower nodes only or if you want to higher your chance for a flower spike, then apply KEIKIBOOST to the upper nodes.
<G-vec00272-001-s175><apply.auftragen><de> Keiki initiation ist höher: wenn Sie KEIKIBOOST eine Woche nach den Verlust der letzten Blüte auftragen, tragen Sie KEIKIBOOST auf den ersten Knoten auf, im falle das Sie neue Blüten möchten tragen Sie KEIKIBOOST auf den höhern Knoten auf.
<G-vec00272-001-s176><apply.auftragen><en> To treat various ailments apply the leaves of the culture, which knead before use or make from them juice.
<G-vec00272-001-s176><apply.auftragen><de> Zur Behandlung verschiedener Beschwerden die Blätter der Kultur auftragen, die vor Gebrauch kneten oder daraus Saft herstellen.
<G-vec00272-001-s177><apply.auftragen><en> Apply generously to clean, exfoliated skin.
<G-vec00272-001-s177><apply.auftragen><de> Großzügig auf die gereinigte, gepeelte Haut auftragen.
<G-vec00272-001-s178><apply.auftragen><en> Maintenance cleaning: dilute concentrate 1:50 (200 ml to 10 liters) and apply.
<G-vec00272-001-s178><apply.auftragen><de> Unterhaltsreinigung: Konzentrat 1:50 (200 ml auf 10 Liter) verdünnen und auftragen.
<G-vec00272-001-s179><apply.auftragen><en> Apply several times a day to hands and gently massage in.
<G-vec00272-001-s179><apply.auftragen><de> Mehrmals täglich auf die Hände auftragen und sanft einmassieren.
<G-vec00272-001-s180><apply.auftragen><en> For heavily soiled parts and surfaces: Apply concentrated product with a soft brush or spray.
<G-vec00272-001-s180><apply.auftragen><de> Bei stark verschmutzten Teilen und Oberflächen: Konzentriertes Produkt mit einer weichen Bürste oder einem Sprühgerät auftragen.
<G-vec00272-001-s181><apply.auftragen><en> It's important to powder the face first and then apply the Cream to Powder Blush as a colour highlight.
<G-vec00272-001-s181><apply.auftragen><de> Wichtig: Erst das Gesicht abpudern und danach den Cream To Powder Blush als farbliches Highlight auftragen.
<G-vec00272-001-s182><apply.auftragen><en> Apply to skin and massage unitl oil is completely absorbed.
<G-vec00272-001-s182><apply.auftragen><de> Haut auftragen und Massage unitl Öl wird vollständig resorbiert.
<G-vec00272-001-s183><apply.auftragen><en> Apply oil extracted from the shell of the cashew nuts.
<G-vec00272-001-s183><apply.auftragen><de> Extrahiert aus der Schale von Cashew-Nüssen Öl auftragen.
<G-vec00272-001-s184><apply.auftragen><en> For immediate glow, apply a thick layer of the Resurfacing Mask on a clean face.
<G-vec00272-001-s184><apply.auftragen><de> Für sofortiges Strahlen und Glanz eine dicke Schicht der Resurfacing Mask auf das gereinigte Gesicht auftragen.
<G-vec00272-001-s185><apply.auftragen><en> Apply generously to wet footwear; Spray-On (from a distance of 5cm) or Sponge-On.
<G-vec00272-001-s185><apply.auftragen><de> Großzügig auf nasse Schuhe auftragen; Spray (aus einer Entfernung von 5cm) oder Schwammapplikator.
<G-vec00272-001-s186><apply.auftragen><en> In the morning apply locally on the inflammatory areas.
<G-vec00272-001-s186><apply.auftragen><de> Morgens lokal auf die entzündlichen Partien auftragen.
<G-vec00272-001-s187><apply.auftragen><en> To facilitate procedure, the assistant who will apply paraffin can be necessary for you.
<G-vec00272-001-s187><apply.auftragen><de> Um die Prozedur zu erleichtern, kann sich Ihnen der Helfer benötigen, der das Paraffin auftragen wird.
<G-vec00272-001-s188><apply.auftragen><en> Apply onto the face with a puff or powder brush.
<G-vec00272-001-s188><apply.auftragen><de> Auf das Gesicht mit einer Quaste oder einem Pinsel auftragen.
<G-vec00272-001-s189><apply.auftragen><en> Nordson hot melt machines and adhesive dispensing systems apply adhesives, sealants and coatings in a variety of patterns to consumer and industrial products in packaging, product assembly and nonwoven applications.
<G-vec00272-001-s189><apply.auftragen><de> Die Klebstoffauftrags- und Schmelzklebstoffsysteme von Nordson dienen zum Auftragen von Klebstoffen, Dichtstoffen und Beschichtungen in verschiedensten Formen für Verbraucher- und Industrieprodukte bei Verpackungen, Anwendungen in der Produktmontage und Vliesstoffen.
<G-vec00272-001-s190><apply.auftragen><en> To get a decent result, it is enough to apply this mixture on your face every day for a month.
<G-vec00272-001-s190><apply.auftragen><de> Um ein anständiges Ergebnis zu erzielen, reicht es aus, diese Mischung jeden Monat jeden Tag auf Ihr Gesicht aufzutragen.
<G-vec00272-001-s191><apply.auftragen><en> The excellent quality of waxes used makes these crayons are easy to apply and perfect for all coloring techniques, including the graffiti.
<G-vec00272-001-s191><apply.auftragen><de> Die hervorragende Qualität der Wachse verwendet diese Stifte einfach aufzutragen und perfekt für alle Färbung-Techniken sind, einschließlich der Graffiti macht.
<G-vec00272-001-s192><apply.auftragen><en> It is a very special and very noble way to apply perfume: with the Kabuki brush, you can apply deliciously scented perfume powder to your skin.
<G-vec00272-001-s192><apply.auftragen><de> Es stellt eine spezielle und zugleich besonders noble Art dar, Parfum aufzutragen: Mit dem geschmeidigen Kabuki-Pinsel wird die Haut mit zart duftendem Parfum-Puder bestäubt.
<G-vec00272-001-s193><apply.auftragen><en> Before giving by liquid dark chocolate to apply drawing on a white surface.
<G-vec00272-001-s193><apply.auftragen><de> Vor der Abgabe von der flüssigen schwarzen Schokolade, auf die weiße Oberfläche die Zeichnung aufzutragen.
<G-vec00272-001-s194><apply.auftragen><en> "It is enough to first stretch the pavilion sideways like a harmonica, apply the material, and then pull up the corners upwards until it ""clicks"" the lock."
<G-vec00272-001-s194><apply.auftragen><de> Es reicht aus, den Pavillon zunächst wie eine Mundharmonika seitwärts zu strecken, das Material aufzutragen und dann die Ecken nach oben zu ziehen, bis das Schloss einrastet.
<G-vec00272-001-s195><apply.auftragen><en> Serrated scrapers are used to apply adhesives and paste glues to large areas when doing bonding work.
<G-vec00272-001-s195><apply.auftragen><de> Zahnspachtel werden eingesetzt, um Klebstoffe und Leime bei großflächigen Verklebungen aufzutragen.
<G-vec00272-001-s196><apply.auftragen><en> Generally, you won't need to apply conditioner higher than halfway up the length of your hair unless hair is noticeably dry near your scalp.
<G-vec00272-001-s196><apply.auftragen><de> Im Allgemeinen brauchst du die Spülung nicht weiter als bis zur Hälfte der Haarlänge aufzutragen, es sei denn, dein Haar ist auch nahe der Kopfhaut merklich trocken.
<G-vec00272-001-s197><apply.auftragen><en> Therefore, be careful not to apply it over a wide area, but only selectively or in (wave) lines.
<G-vec00272-001-s197><apply.auftragen><de> Achtet deshalb darauf, ihn nicht flächig, sondern nur punktuell oder in (Wellen-)Linien aufzutragen.
<G-vec00272-001-s198><apply.auftragen><en> It is easiest to apply glue with the pallet.
<G-vec00272-001-s198><apply.auftragen><de> Am meisten ist es leichter, den Leim schpatelem aufzutragen.
<G-vec00272-001-s199><apply.auftragen><en> Technical Sheet 1,000 ways to apply fragrance...
<G-vec00272-001-s199><apply.auftragen><de> 1000 Möglichkeiten, .Parfüm aufzutragen...
<G-vec00272-001-s200><apply.auftragen><en> When using barely opaque colour tones, after a corresponding flash time (matt stripped) it might be necessary to apply additional paint processes.
<G-vec00272-001-s200><apply.auftragen><de> Bei schwach deckenden Farbtönen kann es nach entsprechender Ablüftzeit (matt abgezogen) notwendig sein, weitere Spritzgänge aufzutragen.
<G-vec00272-001-s201><apply.auftragen><en> Heat resistance 316 stainless steel has good oxidation resistance in intermittent use below 1600 °C and continuous use below 1700 °C. In the range of 800-1575 degrees, it is preferable not to continuously apply 316 stainless steel, but when 316 stainless steel is continuously used outside this temperature range, the stainless steel has good heat resistance.
<G-vec00272-001-s201><apply.auftragen><de> Hitzebeständigkeit Edelstahl 316 hat eine gute Oxidationsbeständigkeit bei intermittierender Verwendung unter 1600 ° C und kontinuierlicher Verwendung unter 1700 ° C. Im Bereich von 800 bis 1575 Grad ist es bevorzugt, 316-Edelstahl nicht kontinuierlich aufzutragen, aber wenn 316-Edelstahl kontinuierlich außerhalb dieses Temperaturbereichs verwendet wird, weist der Edelstahl eine gute Wärmebeständigkeit auf.
<G-vec00272-001-s202><apply.auftragen><en> It is permissible to apply tincture of ginseng or eleutherococcus once before the arrival of the doctor.
<G-vec00272-001-s202><apply.auftragen><de> Es ist zulässig, einmal Ginseng oder Eleutherococcus Tinktur vor der Ankunft des Arztes aufzutragen.
<G-vec00272-001-s203><apply.auftragen><en> After drying of glue rather simply accurately to separate a snowflake from paper, to apply on it glue by means of a brush and to strew with spangles.
<G-vec00272-001-s203><apply.auftragen><de> Nach dem Austrocknen des Leims genug einfach akkurat, die Schneeflocke vom Papier abzutrennen, auf sie den Leim mit Hilfe des kleinen Pinsels aufzutragen und, blestkami zu bestreuen.
<G-vec00272-001-s204><apply.auftragen><en> At external use of sea-buckthorn oil it is necessary to clear the damaged skin site, to apply oil by means of a pipette and to apply a gauze bandage.
<G-vec00272-001-s204><apply.auftragen><de> Bei der äusserlichen Nutzung oblepichowogo die Öle muss man das beschädigte Grundstück der Haut reinigen, das Öl mit Hilfe der Pipette aufzutragen und, marlewuju die Binde aufzuerlegen.
<G-vec00272-001-s205><apply.auftragen><en> The natural colour lasts up to 24 hours and is easy to apply.
<G-vec00272-001-s205><apply.auftragen><de> Die natürliche Farbe hält bis zu 24 Stunden und ist einfach aufzutragen.
<G-vec00272-001-s206><apply.auftragen><en> A bulb guaranteed to contain no PVC Countless customization options 1,000 ways to apply fragrance...
<G-vec00272-001-s206><apply.auftragen><de> Ballonzerstäuber garantiert ohne PVC Zahllose individualisierbare Optionen 1000 Möglichkeiten, .Parfüm aufzutragen...
<G-vec00272-001-s207><apply.auftragen><en> Now to apply makeup, simply introduce a small amount of makeup onto beautyblender® top or bottom surface.
<G-vec00272-001-s207><apply.auftragen><de> Nun, um das Make-up aufzutragen, einfach eine kleine Menge von Make-up auf obere oder untere Oberfläche des beautyblender® oder direkt auf die Haut geben.
<G-vec00272-001-s208><apply.auftragen><en> There are three main ways of strengthening of eyelashes: to apply nutritious mix on eyelashes, on skin of eyelids and to do their massage.
<G-vec00272-001-s208><apply.auftragen><de> Es gibt drei Haupt- Weisen der Festigung der Wimpern: die nahrhafte Mischung auf die Wimpern aufzutragen, auf die Haut Jahrhundert und ihre Massage zu machen.
<G-vec00272-001-s209><apply.beantragen><en> If your child never lived in Germany but lived within the EU/EEA, you can still apply for the benefit if you worked in Germany.
<G-vec00272-001-s209><apply.beantragen><de> Wenn Ihr Kind nie in Deutschland gelebt hat, aber in einem EU / EWR Land, können Sie diese Vergünstigung beantragen, wenn Sie in Deutschland gearbeitet haben.
<G-vec00272-001-s210><apply.beantragen><en> Gueststudents from other countries generally need to apply for a visa before arrival.
<G-vec00272-001-s210><apply.beantragen><de> Gaststudierende aus anderen Ländern müssen in der Regel vor der Einreise ein Visum beantragen.
<G-vec00272-001-s211><apply.beantragen><en> Contact the local Swiss representative or consulate when you want to register or unregister as a resident, when you need a new pass, have moved or wish to apply for citizenship.
<G-vec00272-001-s211><apply.beantragen><de> Dienstleistungen Schliessen Dienstleistungen Wenden Sie sich an die zuständige Schweizer Vertretung, wenn Sie sich an- oder abmelden möchten, neue Ausweise benötigen, umgezogen sind oder das Bürgerrecht beantragen möchten.
<G-vec00272-001-s212><apply.beantragen><en> Anyone who is resident in Germany can apply for a library card in person by visiting ZB MED.
<G-vec00272-001-s212><apply.beantragen><de> Alle Personen, deren Wohnsitz in Deutschland liegt, können bei ZB MED vor Ort persönlich einen Bibliotheksausweis beantragen.
<G-vec00272-001-s213><apply.beantragen><en> As available in specified regions, if you choose to apply for a Choice Privileges Visa card, you will be linked from Choice's website to Barclays Bank Delaware's website and will be required to enter certain personally identifiable information as part of the credit application process.
<G-vec00272-001-s213><apply.beantragen><de> "Wenn Sie eine ""Choice Privileges Visa""-Karte beantragen, werden Sie in bestimmten Regionen, in denen dies möglich ist, von der Website von Choice an die Website der Barclays Bank Delaware weitergeleitet, wo Sie im Rahmen der Beantragung der Kreditkarte bestimmte personenbezogene Daten bereitstellen müssen."
<G-vec00272-001-s214><apply.beantragen><en> I also had to apply for holidays as it took place during the week.
<G-vec00272-001-s214><apply.beantragen><de> Ferientage musste ich auch beantragen, da es unter der Woche stattfand.
<G-vec00272-001-s215><apply.beantragen><en> You need to apply for a visa in person from the German representation abroad in the territory of which you live whilst still in your home country.
<G-vec00272-001-s215><apply.beantragen><de> Ein Visum müssen Sie noch in Ihrem Heimatland persönlich bei der deutschen Auslandsvertretung beantragen, in deren Amtsbezirk Sie leben.
<G-vec00272-001-s216><apply.beantragen><en> The Schleswig-Holstein parliament passed the Gaming Reform Act (GRA) in September of 2011, which allows online casinos and poker rooms (and possibly sportsbooks) to apply for a license to operate games of chance online in their state, provided they pay a fee of 20% of gross revenues for that right.
<G-vec00272-001-s216><apply.beantragen><de> Das Schleswig-Holstein Parlament verabschiedete den Gaming Reform Act (GRA) im September 2011, die erlaubt Online-Casinos und Poker Zimmer (und möglicherweise Macher) für eine Lizenz beantragen Glücksspiele Online in ihrem Zustand zu betreiben, sofern sie eine Gebühr von 20% der Bruttoeinnahmen für dieses Recht bezahlen.
<G-vec00272-001-s217><apply.beantragen><en> Send this form to the national employment services in the country where you wish to apply for benefits, so they can take account of any periods of social security cover or employment in other countries.
<G-vec00272-001-s217><apply.beantragen><de> Schicken Sie dieses Formular an die nationale Arbeitsvermittlungsstelle des Landes, in dem Sie Leistungen beantragen möchten, so dass sie Zeiten des Sozialversicherungsschutzes oder der Beschäftigung in anderen Ländern berücksichtigen kann.
<G-vec00272-001-s218><apply.beantragen><en> Employees should apply for membership with their ID card at the Academic Office.
<G-vec00272-001-s218><apply.beantragen><de> Mitarbeitende beantragen die Mitgliedschaft mit ihrem Personalausweis beim Studiensekretariat.
<G-vec00272-001-s219><apply.beantragen><en> While the student visa for entry (in a Schengen state) is valid, you must apply at the local immigration office for a residence permit for study purposes (§ 16).
<G-vec00272-001-s219><apply.beantragen><de> Innerhalb der Gültigkeit des Studienvisums zur Einreise (in ein Schengen-Staat) müssen Sie eine Aufenthaltsgenehmigung zu Studienzwecken (§ 16) bei der Ausländerbehörde vor Ort beantragen.
<G-vec00272-001-s220><apply.beantragen><en> However, if you only want to work with Adarvo over the Internet, without using the program itself, you can also apply for a new account via this link and access the theme in this way.
<G-vec00272-001-s220><apply.beantragen><de> Für den Fall, dass Sie nur via Internet mit Adarvo arbeiten möchten, ohne das Programm selbst zu verwenden, können Sie auch über diesen Link ein neues Konto beantragen und Zugang zum Thema erhalten.
<G-vec00272-001-s221><apply.beantragen><en> After his release, he no longer dared to apply for assistance, despite renewed unemployment.
<G-vec00272-001-s221><apply.beantragen><de> Nach seiner Entlassung traute er sich trotz erneuter Arbeitslosigkeit nicht mehr, Unterstützung zu beantragen.
<G-vec00272-001-s222><apply.beantragen><en> Before they can apply for a visa, they will need their future host family to apply at their regional immigration service for a B work permit and send it to their future Au Pair.
<G-vec00272-001-s222><apply.beantragen><de> Bevor das Au Pair allerdings ein Visum beantragen kann, muss die zukünftige Gastfamilie beim regionalen Immigrationsservice eine B-Work Arbeitserlaubnis einholen und dem Au Pair zu schicken.
<G-vec00272-001-s223><apply.beantragen><en> After the application deadline, we will send you additional useful information as well as the letter of acceptance which you might need in order to apply for a visa, etc.
<G-vec00272-001-s223><apply.beantragen><de> Nach Ablauf der Bewerbungsfrist erhalten Sie von uns weitere nützliche Informationen sowie die Annahmeerklärung, die Sie eventuell benötigen, um ein Visum zu beantragen.
<G-vec00272-001-s224><apply.beantragen><en> If no national technical approval is available for the intended application, itwill be necessary to apply for individual approval for using the VIPs.
<G-vec00272-001-s224><apply.beantragen><de> Liegt für die geplante Anwendung noch keine allgemeine bauaufsichtliche Zulassung vor, so ist für die Verwendung der VIP eine Zustimmung im Einzelfall zu beantragen.
<G-vec00272-001-s225><apply.beantragen><en> If you're not from any of the countries mentioned you should contact the Swedish consulate in your home country in order to apply for a work permit before you leave for Sweden.
<G-vec00272-001-s225><apply.beantragen><de> Wenn Sie sich nicht aus einem der genannten Länder wenden Sie sich bitte an die schwedische Konsulat in Ihrem Heimatland, um eine Arbeitserlaubnis beantragen, bevor Sie für Schweden.
<G-vec00272-001-s226><apply.beantragen><en> every place that you go to apply for a loan turns you down without a second thought.
<G-vec00272-001-s226><apply.beantragen><de> jeder Platz, dem Sie gehen, Umdrehungen eines Darlehens Sie unten zu beantragen ohne eine reifliche Überlegung.
<G-vec00272-001-s227><apply.beantragen><en> Those from countries outside the EU may need to apply for a visa in advance.
<G-vec00272-001-s227><apply.beantragen><de> Besucher aus Nicht-EU-Ländern müssen wahrscheinlich ein Visum im Voraus beantragen.
<G-vec00272-001-s247><apply.sich_bewerben><en> They encouraged me to apply for the position of environmental manager, after they saw how I took action against Lufthansa and how I stood up for the taxation of environmental pollution in air traffic and shifting subsidies to the train traffic.
<G-vec00272-001-s247><apply.sich_bewerben><de> Die regten es an, dass ich mich auf eine Stelle als Umweltmanager bewerben solle, da sie gesehen haben, wie ich gegen die Lufthansa vorgegangen bin und mich politisch für die Besteuerung der Umweltbelastungen im Flugverkehr und eine Entlastung der Bahn eingesetzt habe.
<G-vec00272-001-s248><apply.sich_bewerben><en> Applicants for the Millsaps MBA or MAcc programs should apply directly to the Graduate School.
<G-vec00272-001-s248><apply.sich_bewerben><de> Bewerber für die Millsaps MBA oder Macc Programme sollten direkt an die Graduate School bewerben.
<G-vec00272-001-s249><apply.sich_bewerben><en> Once parents have sufficiently informed themselves and decided for one establishment or the other, they can then simply apply online for a place of their choice.
<G-vec00272-001-s249><apply.sich_bewerben><de> Die Eltern wiederum können sich, nachdem sie sich ausreichend informiert und für eines oder mehrere Angebote entschieden haben, bei den gewünschten Einrichtungen ganz einfach online um einen Platz bewerben.
<G-vec00272-001-s250><apply.sich_bewerben><en> The whole experience was so enjoyable that Heather wanted to do it again so we did and we tried to get a certificate at the information centre in Hornsea, but they told us to apply to you.
<G-vec00272-001-s250><apply.sich_bewerben><de> Die ganze Erfahrung war so angenehm, dass Heather es tun wollte wieder so wir haben und wir haben versucht, ein Zertifikat im Informationszentrum in Hornsea zu erhalten, aber sie sagten uns, euch zu bewerben.
<G-vec00272-001-s251><apply.sich_bewerben><en> HireArt: Fill out one lengthy application (including video), and apply to multiple startup jobs with one application.
<G-vec00272-001-s251><apply.sich_bewerben><de> HireArt: Füllen Sie eine längere Anwendung (einschließlich Video), und mit einer Anwendung auf mehrere Start Jobs bewerben.
<G-vec00272-001-s252><apply.sich_bewerben><en> Hair Tip:Simply apply a handful of styling aerosol to your tresses and hold your head upside down whenever you enable the styling spray to dry.
<G-vec00272-001-s252><apply.sich_bewerben><de> Einfach bewerben eine Handvoll – styling sprühen, um Ihre locken und halten Ihre Kopf invertiert, wenn Sie lassen Sie die – styling sprühen trocken.
<G-vec00272-001-s253><apply.sich_bewerben><en> In order not to lose a whole year, I decided to apply to Hamburg University of Applied Sciences for the summer semester.
<G-vec00272-001-s253><apply.sich_bewerben><de> Um nicht ein ganzes Jahr zu verlieren, habe ich entschieden, mich bei der HAW Hamburg im Sommersemester zu bewerben.
<G-vec00272-001-s254><apply.sich_bewerben><en> Against this background, the teachers, pupils and their parents decided to apply to participate in the 'Inclusive School' pilot project.
<G-vec00272-001-s254><apply.sich_bewerben><de> "Auf dieser Grundlage entschieden sich Lehrer, Schüler und Eltern, sich für das Pilotprojekt ""Inklusive Schule"" zu bewerben."
<G-vec00272-001-s255><apply.sich_bewerben><en> But even if uni-assist is responsible for applications to the degree course, it might be possible that you have to apply directly to the university if you have to visit the preparatory German language course.
<G-vec00272-001-s255><apply.sich_bewerben><de> Aber auch wenn uni-assist für die Bewerbung zum Fachstudium zuständig ist, kann es sein, dass Sie sich trotzdem direkt an der Hochschule bewerben müssen, weil Sie vorab den studienvorbereitenden Deutsch-Kurs besuchen müssen.
<G-vec00272-001-s256><apply.sich_bewerben><en> When you are ready to submit your application, click the Apply button on the last page.
<G-vec00272-001-s256><apply.sich_bewerben><de> Wenn Ihre Bewerbung versandfertig ist, klicken Sie auf der letzten Seite auf Bewerben.
<G-vec00272-001-s257><apply.sich_bewerben><en> For domestic use Apply every evening to face and neck before applying the cream Dermagen GOLD.
<G-vec00272-001-s257><apply.sich_bewerben><de> Für den Hausgebrauch Bewerben jeden Abend auf Gesicht und Hals vor dem Auftragen der Creme Dermagen GOLD.
<G-vec00272-001-s258><apply.sich_bewerben><en> Women are therefore expressly invited to apply.
<G-vec00272-001-s258><apply.sich_bewerben><de> Frauen werden deshalb ausdrücklich aufgefordert, sich zu bewerben.
<G-vec00272-001-s259><apply.sich_bewerben><en> Why should I apply for the Data Analyst Bachelor's degree? You should enroll in the program because you will master the skills you need to establish a successful Data Science career.
<G-vec00272-001-s259><apply.sich_bewerben><de> Warum sollte ich mich für den Data Analyst Bachelor bewerben?Sie sollten sich für das Programm anmelden, weil Sie die Fähigkeiten beherrschen, die Sie für eine erfolgreiche Data Science-Karriere benötigen.
<G-vec00272-001-s260><apply.sich_bewerben><en> Students of philology programs (Bachelor and Master) can apply for two places in total through our cooperation program with the University of Leuven. The application can be for winter or summer semester in Belgium (Campus Antwerp).
<G-vec00272-001-s260><apply.sich_bewerben><de> Im Rahmen der Partnerschaft mit der KU Leuven können sich BA- und MA- Studierende philologischer Studiengänge der Heinrich-Heine-Universität für insgesamt zwei Plätze laufend zum Winter- sowie Sommersemester in Belgien (Campus Antwerpen) bewerben.
<G-vec00272-001-s261><apply.sich_bewerben><en> We would like to express an invitation to interested young members to apply and also ask all supervising members to address suitable doctoral candidates directly.
<G-vec00272-001-s261><apply.sich_bewerben><de> Wir möchten interessierte junge Mitglieder ausdrücklich auffordern sich zu bewerben und bitten zudem alle betreuenden Mitglieder geeignete Promovierende direkt anzusprechen.
<G-vec00272-001-s262><apply.sich_bewerben><en> Just apply with an email to info@caratart.de.
<G-vec00272-001-s262><apply.sich_bewerben><de> Einfach bewerben mit einer Email an info@caratart.de.
<G-vec00272-001-s263><apply.sich_bewerben><en> Apply Important information on your application for admission to a master's program We regularly receive incomplete applications that we cannot take into account.
<G-vec00272-001-s263><apply.sich_bewerben><de> Für den Studien­gang bewerben Wichtige Hinweise zu Ihrer Master­bewerbung Uns erreichen immer wieder unvollständige Bewerbungen, die wir nicht berücksichtigen können.
<G-vec00272-001-s264><apply.sich_bewerben><en> How do I apply? Interested parties should apply directly to the Permanent Representation in Paris.
<G-vec00272-001-s264><apply.sich_bewerben><de> InteressentInnen bewerben sich direkt bei der Ständigen Vertretung in Paris, wobei die Aufnahmekapazitäten aus finanziellen Gründen beschränkt sind.
<G-vec00272-001-s265><apply.sich_bewerben><en> Simply click on the 'Apply' button.
<G-vec00272-001-s265><apply.sich_bewerben><de> "Klicken Sie auf den Button ""Bewerben""."
<G-vec00272-001-s266><apply.sich_bewerben><en> You apply with a foreign certificate which you have acquired in a country outside Germany.
<G-vec00272-001-s266><apply.sich_bewerben><de> Sie bewerben sich mit einem ausländischen Zeugnis (Sekundarschulabschluss, Bachelor), das Sie in einem Land außerhalb Deutschlands erworben haben.
<G-vec00272-001-s267><apply.sich_bewerben><en> Please apply only online and add your CV, letter of motivation (online text field) and certificates to your application (max.
<G-vec00272-001-s267><apply.sich_bewerben><de> Bitte bewerben Sie sich ausschließlich online und fügen der Bewerbung Ihren Lebenslauf, ein Anschreiben im Motivationsfeld des Online-Formulars und Zeugnisse bei (max.
<G-vec00272-001-s268><apply.sich_bewerben><en> All those who have skills in relating to groups of people, experience in communicating complex subjects, and the will to be exposed to ideas, new experiences, artworks, and most important of all, to artists, please apply.
<G-vec00272-001-s268><apply.sich_bewerben><de> Wenn Sie Geschick im Umgang mit Gruppen und Erfahrung in der Vermittlung komplexer Inhalte haben, aufgeschlossen sind gegenüber Ideen, neuen Erfahrungen, Kunstwerken und vor allem auch Künstlerinnen und Künstlern – bitte bewerben Sie sich.
<G-vec00272-001-s269><apply.sich_bewerben><en> Please apply using our online application tool.
<G-vec00272-001-s269><apply.sich_bewerben><de> Bitte bewerben Sie sich über unser Online-Bewerbungstool.
<G-vec00272-001-s270><apply.sich_bewerben><en> Students apply through their university with an Erasmus Coordinator in their subject area.
<G-vec00272-001-s270><apply.sich_bewerben><de> Studenten bewerben sich über ihre Universität mit einem Erasmus-Koordinator in ihrem Fachgebiet.
<G-vec00272-001-s271><apply.sich_bewerben><en> Please apply via the C@MPUS Campus Management Portal .
<G-vec00272-001-s271><apply.sich_bewerben><de> Bitte bewerben Sie sich über das Campus-Management-Portal C@MPUS.
<G-vec00272-001-s272><apply.sich_bewerben><en> Please apply exclusively online.
<G-vec00272-001-s272><apply.sich_bewerben><de> Bitte bewerben Sie sich online.
<G-vec00272-001-s273><apply.sich_bewerben><en> Please apply under Place product and send us some information on your product.
<G-vec00272-001-s273><apply.sich_bewerben><de> Bitte bewerben Sie sich unter „Produkt eintragen“ und senden Sie uns vorab einige Infos zu Ihrem Produkt.
<G-vec00272-001-s274><apply.sich_bewerben><en> Time and again, pupils blossom during a radio week, many retain a passion for the media and some apply for an internship.
<G-vec00272-001-s274><apply.sich_bewerben><de> Denn immer wieder gibt es Schülerinnen und Schüler, die in einer solchen Woche richtig aufblühen – etliche behalten die Begeisterung fürs Medium, bewerben sich später für Praktika.
<G-vec00272-001-s275><apply.sich_bewerben><en> International Artists with a main working focus outside German-speaking countries apply via the local Goethe Institute.
<G-vec00272-001-s275><apply.sich_bewerben><de> International Künstlerinnen und Künstler mit Arbeitsschwerpunkt außerhalb der deutschsprachigen Länder bewerben sich über das Goethe-Institut ihres Herkunftslandes.
<G-vec00272-001-s276><apply.sich_bewerben><en> The nominated students apply independently as an Erasmus-exchange student at the partner university.
<G-vec00272-001-s276><apply.sich_bewerben><de> "Die nominierten Studierenden bewerben sich eigenständig an der Partnerhochschule als ""Erasmus-exchange student""."
<G-vec00272-001-s277><apply.sich_bewerben><en> Schools which fulfill the criteria and would like to be a partner in the new network can apply to the Goethe-Instituts in London (for England, Wales and Northern Ireland) and Glasgow (for Scotland).
<G-vec00272-001-s277><apply.sich_bewerben><de> Schulen, die die oben genannten Kriterien erfüllen und gerne ein Partner im neuen Netzwerk sein möchten, bewerben sich bei den Goethe-Instituten in London (für England, Wales, Nordirland) und Glasgow (für Schottland).
<G-vec00272-001-s278><apply.sich_bewerben><en> Please apply via our contact form .
<G-vec00272-001-s278><apply.sich_bewerben><de> Bitte bewerben Sie sich über unser Kontaktformular.
<G-vec00272-001-s279><apply.sich_bewerben><en> If you are interested in one of our advertised posts, please apply directly to the relevant location.
<G-vec00272-001-s279><apply.sich_bewerben><de> Wenn Sie sich für eine unserer ausgeschriebenenStellen interessieren, bewerben Sie sich bitte direkt am jeweiligen Standort.
<G-vec00272-001-s280><apply.sich_bewerben><en> Applicants with German or EU-citizenship please apply via the online portal of the KIT Studierendenservice (student services).
<G-vec00272-001-s280><apply.sich_bewerben><de> Bewerber mit deutscher oder EU-Staatsbürgerschaft bewerben sich bitte über das online-Portal des Studierendenservice am KIT.
<G-vec00272-001-s281><apply.sich_bewerben><en> However, particularly in the natural sciences and engineering sciences, far fewer women apply for a fellowship (25 percent and 15 percent respectively).
<G-vec00272-001-s281><apply.sich_bewerben><de> Jedoch bewerben sich vor allem in den Natur- und Ingenieurwissenschaften mit 25 beziehungsweise 15 Prozent weit weniger Frauen als Männer um ein Stipendium.
<G-vec00272-001-s282><apply.sich_bewerben><en> For most fields of study at the University of Freiburg, you can apply directly online .
<G-vec00272-001-s282><apply.sich_bewerben><de> Für die meisten Fächer bewerben Sie sich direkt bei der Universität Freiburg über das Online-Portal .
<G-vec00272-001-s283><apply.sich_bewerben><en> If you are interested in other positions at UBS, please apply separately for these openings as UBS will not necessarily automatically consider you for other openings.
<G-vec00272-001-s283><apply.sich_bewerben><de> Sollten Sie Interesse an anderen Stellen innerhalb der UBS haben, bewerben Sie sich bitte gesondert für diese offenen Stellen, da die UBS Sie nicht zwingend bei der Besetzung anderer offener Stellen berücksichtigen wird.
<G-vec00272-001-s284><apply.sich_bewerben><en> For example, applicants with a German Abitur often apply directly to the university.
<G-vec00272-001-s284><apply.sich_bewerben><de> Zum Beispiel bewerben sich Bewerberinnen und Bewerber mit einem deutschen Abitur oft direkt bei der Hochschule.
<G-vec00272-001-s285><apply.sich_bewerben><en> Many core courses in our information security degree program apply directly to industry standard certifications, such as CompTIA, Microsoft, Cisco and Computer Forensics Investigation.
<G-vec00272-001-s285><apply.sich_bewerben><de> Viele Kernfächer in unserem Informationssicherheit Studiengang bewerben Sie sich direkt an Industriestandard-Zertifizierungen wie CompTIA, Microsoft, Cisco und Computer Forensics Investigation.
<G-vec00272-001-s286><apply.sich_bewerben><en> Then apply for one of our national and international trainee programs.
<G-vec00272-001-s286><apply.sich_bewerben><de> Dann bewerben Sie sich für eines unserer nationalen und internationalen Traineeprogramme.
<G-vec00272-001-s287><apply.sich_bewerben><en> Apply directly to the eyelid and follow the lash line with the precision tip.
<G-vec00272-001-s287><apply.sich_bewerben><de> Bewerben Sie sich direkt auf dem Augenlid und folgen Sie den Wimpernrand mit precisietip.
<G-vec00272-001-s288><apply.sich_bewerben><en> Visitors must apply for a visa from the authorities diplomatic / consular Burkina Faso in their relative country.
<G-vec00272-001-s288><apply.sich_bewerben><de> Bewerben Sie sich für ein Visum wird von den Behörden diplomatische / konsularische Burkina Faso in ihrem Land erforderlich.
<G-vec00272-001-s289><apply.sich_bewerben><en> Apply for vacancies through our jobs portal, or take the initiative and try and sell us your idea for your university dissertation work.
<G-vec00272-001-s289><apply.sich_bewerben><de> Bewerben Sie sich über unser Stellenportal auf offene Stellen oder ergreifen Sie die Initiative und überzeugen uns von Ihrem Thema für eine akademische Abschlussarbeit.
<G-vec00272-001-s290><apply.sich_bewerben><en> Write your own KAEFER story and apply here .
<G-vec00272-001-s290><apply.sich_bewerben><de> Erzählen Sie Ihre Geschichte und bewerben Sie sich hier .
<G-vec00272-001-s291><apply.sich_bewerben><en> Family visa: Apply early for a visa (if necessary) for yourself and your family.
<G-vec00272-001-s291><apply.sich_bewerben><de> Familienvisum: Bewerben Sie sich frühzeitig für ein Visum (falls erforderlich) für Sie und Ihre Familie.
<G-vec00272-001-s292><apply.sich_bewerben><en> Apply with up to 5 of your most attractive domains and take advantage of even more exposure and especially high sales revenues. Apply now
<G-vec00272-001-s292><apply.sich_bewerben><de> Bewerben Sie sich mit bis zu 5 Ihrer attraktivsten Domains – und profitieren Sie von noch mehr Aufmerksamkeit und besonders hohen Verkaufserlösen.
<G-vec00272-001-s293><apply.sich_bewerben><en> Take the initiative and apply online right now.
<G-vec00272-001-s293><apply.sich_bewerben><de> Dann ergreifen Sie die Initiative und bewerben Sie sich gleich online.
<G-vec00272-001-s294><apply.sich_bewerben><en> Take the next step and apply online.
<G-vec00272-001-s294><apply.sich_bewerben><de> Machen Sie den nächsten Schritt und bewerben Sie sich online.
<G-vec00272-001-s295><apply.sich_bewerben><en> Apply to companies where grades are less important.
<G-vec00272-001-s295><apply.sich_bewerben><de> Bewerben Sie sich bei Firmen, denen Noten weniger wichtig sind.
<G-vec00272-001-s296><apply.sich_bewerben><en> Apply straight with one arm, built in 45 degrees y tulip crystal.
<G-vec00272-001-s296><apply.sich_bewerben><de> Bewerben Sie sich gerade mit einem Arm, in 45 Grad gebaut y Tulpenopal.
<G-vec00272-001-s297><apply.sich_bewerben><en> Then apply for work experience at HUMMEL.
<G-vec00272-001-s297><apply.sich_bewerben><de> Dann bewerben Sie sich für einen Praktikumsplatz bei HUMMEL.
<G-vec00272-001-s298><apply.sich_bewerben><en> Apply online now for one of our open positions with our career portal. Career portal
<G-vec00272-001-s298><apply.sich_bewerben><de> Bewerben Sie sich jetzt online auf eine unserer offenen Stellen auf unserem Karriereportal.
<G-vec00272-001-s299><apply.sich_bewerben><en> Apply to:Beer Dispensing,Water Treatment,Pollution Controll,Chemical Industry,Phatmaccutical Industry.
<G-vec00272-001-s299><apply.sich_bewerben><de> Bewerben Sie sich für: Bierdosierung, Wasseraufbereitung, Umweltschutz, Chemische Industrie, Phatmatikindustrie.
<G-vec00272-001-s300><apply.sich_bewerben><en> – Then apply now and become part of the Brand Ambassador Programme.
<G-vec00272-001-s300><apply.sich_bewerben><de> – Dann bewerben Sie sich und werden Sie Teil des Markenbotschafter Programms.
<G-vec00272-001-s301><apply.sich_bewerben><en> If you would like to be part of our team, simply apply below.
<G-vec00272-001-s301><apply.sich_bewerben><de> Wenn Sie Teil unseres Teams werden wollen, bewerben Sie sich unten.
<G-vec00272-001-s302><apply.sich_bewerben><en> Apply for financial support for rigorous research projects that set out to produce empirical evidence with relevant implications for policymakers and business in Europe.
<G-vec00272-001-s302><apply.sich_bewerben><de> Bewerben Sie sich um finanzielle Unterstützung für gezielte Forschungsprojekte, die aussagekräftige empirische Daten für politische Entscheidungsträger und die Wirtschaft in Europa erbringen sollen.
<G-vec00272-001-s303><apply.sich_bewerben><en> Team skills Start into the future with KUKA: apply online Â for your apprenticeship as mechatronics technician!
<G-vec00272-001-s303><apply.sich_bewerben><de> Starten Sie mit KUKA in die Zukunft: Bewerben Sie sich online für Ihre Ausbildung zum/zur Mechatroniker/in.
<G-vec00272-001-s456><apply.gelten><en> The above regulations apply accordingly in the case of delivery by third party haulage companies if it is possible to derive liability on our part as a result of their conduct.
<G-vec00272-001-s456><apply.gelten><de> Die vorstehenden Regelungen gelten entsprechend bei der Belieferung durch dritte Beförderungsunternehmen, soweit aus deren Verhalten eine Haftung für uns hergeleitet werden könnte.
<G-vec00272-001-s457><apply.gelten><en> (3) The liability limitations resulting from Para. 2 shall not apply insofar as we have maliciously failed to disclose a defect or have furnished a guarantee for the quality of the goods.
<G-vec00272-001-s457><apply.gelten><de> (3) Die sich aus Abs 2 ergebenden Haftungsbeschränkungen gelten nicht, soweit wir einen Mangel arglistig verschwiegen oder eine Garantie für die Beschaffenheit der Ware übernommen haben.
<G-vec00272-001-s458><apply.gelten><en> If INCOTERMS are agreed for export business, the definitions apply which are determined and published from time to time by the International Chamber of Commerce in Paris and which are in force when the contract is concluded.
<G-vec00272-001-s458><apply.gelten><de> Werden bei Auslandsgeschäften INCOTERMS vereinbart, so gelten die bei Vertragsschluss von der Internationalen Handelskammer in Paris jeweils festgelegten und veröffentlichten Definitionen.
<G-vec00272-001-s459><apply.gelten><en> Special rules apply to electronic communications services (e-Privacy Directive 14) which may need to be reassessed once the general EU rules on data protection are agreed, particularly since most of the articles of the current e-Privacy Directive apply only to providers of electronic communications services, i.e. traditional telecoms companies.
<G-vec00272-001-s459><apply.gelten><de> Für elektronische Kommunikationsdienste gelten besondere Regelungen (e-Datenschutz-Richtlinie 14), die möglicherweise zu überprüfen sein werden, sobald die allgemeinen EU-Datenschutzvorschriften beschlossen sind, insbesondere weil die meisten Artikel der derzeitigen e-Datenschutz-Richtlinie nur für Betreiber elektronischer Kommunikationsdienste (d. h. herkömmliche Telekommunikationsunternehmen) gelten.
<G-vec00272-001-s461><apply.gelten><en> For in-house staff coachings special conditions apply.
<G-vec00272-001-s461><apply.gelten><de> Für In-House-Fortbildungen in Ihrem Kollegium gelten gesonderte Bedingungen.
<G-vec00272-001-s462><apply.gelten><en> We are still able to accommodate rush orders, but charges starting at $75 will apply.
<G-vec00272-001-s462><apply.gelten><de> Wir sind immer noch in der Lage, Eilaufträge unterzubringen, aber Gebühren ab $ 75 gelten.
<G-vec00272-001-s463><apply.gelten><en> If you disagree with the changes that have been made, please contact us (by e-mail, using a website contact form, or in writing by mail), and any changes made to this policy will not apply to information we have collected from you prior to making the changes.
<G-vec00272-001-s463><apply.gelten><de> Wenn Sie mit den Änderungen nicht einverstanden, die vorgenommen wurden sind, kontaktieren Sie uns (per E-mail, über eine Website-Kontakt-Formular oder schriftlich per Post) und alle Änderungen dieser Datenschutzbestimmungen gelten nicht für Informationen, die wir von Ihnen erfasst haben, vor Durchführung der Änderungen.
<G-vec00272-001-s464><apply.gelten><en> Upon order placement, the current services, rates and General Terms and Conditions of theGeneral Overnight Express & Logistics (Austria) GmbH shall apply.
<G-vec00272-001-s464><apply.gelten><de> Bei Auftragserteilung gelten die aktuellen Services, Tarife und besonderen Geschäftsbedingungen der General Overnight Express & Logistics (Austria) GmbH.
<G-vec00272-001-s465><apply.gelten><en> as doable then pleasurable many occasions in a intercourse session to apply orgasm control.
<G-vec00272-001-s465><apply.gelten><de> als machbar dann angenehm vielen Gelegenheiten in einer Sitzung, um Geschlechtsverkehr Orgasmuskontrolle gelten.
<G-vec00272-001-s466><apply.gelten><en> For dung card fishing for fish, 4 noble fish apply.
<G-vec00272-001-s466><apply.gelten><de> Für das Dungkartenfischen auf Fische gelten 4 edle Fische.
<G-vec00272-001-s467><apply.gelten><en> "SCOPE, CONTRACTUAL RELATIONS 1.1. The present General Terms and Conditions (referred to hereinbelow as the ""General Terms and Conditions"") apply to concerts organized by MCT Agentur GmbH, Strausberger Platz 2, 10243 Berlin, Managing Director: Scumeck Sabottka, entered in the Commercial Register kept by the Amtsgericht (Local Court) of Berlin under the number HRB: 65613 (referred to hereinbelow as ""we"" or ""MCT""), with MCT acting as event organizer."
<G-vec00272-001-s467><apply.gelten><de> "Allgemeine Geschäftsbedingungen für Konzertveranstaltungen der MCT Agentur GmbH GELTUNGSBEREICH, VERTRAGSBEZIEHUNGEN 1.1 Diese Allgemeinen Geschäftsbedingungen (nachfolgend ""AGB"") gelten für Konzerte, bei denen die MCT Agentur GmbH, Strausberger Platz 2, 10243 Berlin, Geschäftsführer: Scumeck Sabottka, Registergericht: Amtsgericht Berlin, HRB: 65613 (nachfolgend ""wir"" oder ""MCT"") Veranstalter ist."
<G-vec00272-001-s468><apply.gelten><en> (a) enable the Bank of Greece or the public prosecutor to carry out audits of the funding of media enterprises, (b) apply to all public limited companies and provide that a loss-making company cannot continue operating without recapitalization. Public procurement:
<G-vec00272-001-s468><apply.gelten><de> Werden wir umgehend jene Gesetzesvorschriften aktivieren, die es der griechischen Zentralbank oder den zuständigen Staatsanwaltschaften erlauben, Kontrollen über die Herkunft der Finanzierung von Informationsunternehmen durchzuführen, und die für alle Aktiengesellschaften gelten und vorsehen, dass ein Verluste erwirtschaftendes Unternehmen nicht unbegrenzt betrieben werden kann, ohne rekapitalisiert zu werden.
<G-vec00272-001-s469><apply.gelten><en> The same methods of cooking other sunfish apply for fliers.
<G-vec00272-001-s469><apply.gelten><de> Die gleichen Methoden des Kochens anderen Mondfisch gelten für Flieger.
<G-vec00272-001-s470><apply.gelten><en> European standards apply as and when they are adopted and replace the various national standards.
<G-vec00272-001-s470><apply.gelten><de> Des Weiteren gelten die im Laufe der Zeit festgelegten europäischen Normen, die an die Stelle der verschiedenen nationalen Regelungen treten.
<G-vec00272-001-s471><apply.gelten><en> 2 shall not apply insofar as we have wilfully failed to disclose a defect or have given a guarantee of the nature of the goods.
<G-vec00272-001-s471><apply.gelten><de> 2 ergebenden Haftungsbeschränkungen gelten nicht, soweit wir einen Mangel arglistig verschwiegen oder eine Garantie für die Beschaffenheit der Ware übernommen haben.
<G-vec00272-001-s472><apply.gelten><en> These principles apply also to the organization of world trade, without containing finished political strategies.
<G-vec00272-001-s472><apply.gelten><de> Diese Prinzipien gelten auch für die Gestaltung des Welthandels, wobei sie keine fertigen politischen Strategien enthalten.
<G-vec00272-001-s473><apply.gelten><en> I think I’ve learned alot now that I’ve actually had some hands on time to apply my knowledge in the real world.
<G-vec00272-001-s473><apply.gelten><de> Ich glaube, ich habe viel gelernt, dass ich jetzt tatsächlich hatten einige Hände auf Zeit, um meine Kenntnisse in der realen Welt gelten.
<G-vec00272-001-s474><apply.gelten><en> These conditions of use apply to the use of Guest WiFi Basel.
<G-vec00272-001-s474><apply.gelten><de> Diese Nutzungsbedingungen gelten für die Nutzung des Guest WiFi Basel.
<G-vec00272-001-s475><apply.gelten><en> The following terms and conditions apply to shipments within the Federal Republic of Germany.
<G-vec00272-001-s475><apply.gelten><de> Die nachfolgenden Bedingungen gelten für den Versand innerhalb der Bundesrepublik Deutschland.
<G-vec00272-001-s476><apply.gelten><en> - Discount percentages do not apply to time overrun rates.
<G-vec00272-001-s476><apply.gelten><de> - Die Ermäßigungen gelten nicht für die Tarife der Zeitüberschreitungen.
<G-vec00272-001-s477><apply.gelten><en> The Globelynx camera and services are provided free of charge (normal satellite booking charges apply).
<G-vec00272-001-s477><apply.gelten><de> Die Globelynx-Kamera und -Leistungen sind kostenfrei (es gelten die regulären Buchungsgebühren für Satellitenverbindungen).
<G-vec00272-001-s478><apply.gelten><en> The rights and obligations identified in this contract apply to Buyer's purchase of the equipment, software license, and services identified in the MT order documents.
<G-vec00272-001-s478><apply.gelten><de> Die in diesen allgemeinen Geschäftsbedingungen aufgeführten Rechte und Pflichten gelten für den Erwerb, der in den Bestelldokumenten genannten Geräte, Software, Softwarelizenzen und/oder Dienstleistungen durch den Käufer.
<G-vec00272-001-s479><apply.gelten><en> Changes to the insurance contract of the fixed asset class only apply to fixed assets created after the change.
<G-vec00272-001-s479><apply.gelten><de> Änderungen am Versicherungsvertrag der Anlagenart gelten nur für Anlagengüter, die Sie nach der Änderung anlegen.
<G-vec00272-001-s480><apply.gelten><en> 2 Â Unless otherwise provided by law, the provisions governing share capital, shares and shareholders also apply to the participation capital, participation certificates and participation certificate holders.
<G-vec00272-001-s480><apply.gelten><de> 2 Die Bestimmungen über das Aktienkapital, die Aktie und den Aktionär gelten, soweit das Gesetz nichts anderes vorsieht, auch für das Partizipationskapital, den Partizipationsschein und den Partizipanten.
<G-vec00272-001-s481><apply.gelten><en> Article 35 – Federal or non-unitary constitutional systems The following provisions shall apply to States Parties which have a federal or non-unitary constitutional system: (a) with regard to the provisions of this Convention, the implementation of which comes under the legal jurisdiction of the federal or central legislative power, the obligations of the federal or central government shall be the same as for those States Parties which are not federal States; (b) with regard to the provisions of this Convention, the implementation of which comes under the jurisdiction of individual constituent States, countries, provinces or cantons which are not obliged by the constitutional system of the federation to take legislative measures, the federal government shall inform the competent authorities of such States, countries, provinces or cantons of the said provisions, with its recommendation for their adoption.
<G-vec00272-001-s481><apply.gelten><de> Folgende Bestimmungen gelten für Vertragsstaaten, die ein bundesstaatliches oder ein nicht einheitsstaatliches Verfassungssystem haben: a) Hinsichtlich derjenigen Bestimmungen dieses Übereinkommens, deren Durchführung in die Zuständigkeit des Bundes- oder Zentral-Gesetzgebungsorgans fällt, sind die Verpflichtungen der Bundes- oder Zentralregierung dieselben wie für diejenigen Vertragsstaaten, die nicht Bundesstaaten sind; b) hinsichtlich derjenigen Bestimmungen dieses Übereinkommens, deren Durchführung in die Zuständigkeit einzelner Bundesstaaten, Länder, Provinzen oder Kantone fällt, die nicht durch das Verfassungssystem des Bundes verpflichtet sind, gesetzgeberische Maßnahmen zu treffen, bringt die Bundesregierung den zuständigen Stellen dieser Bundesstaaten, Länder, Provinzen oder Kantone die genannten Bestimmungen zur Kenntnis und empfiehlt ihnen ihre Annahme.
<G-vec00272-001-s482><apply.gelten><en> The same rules apply where the Securities form part of a trade or business (Betriebsvermögen) subject to further requirements being met.
<G-vec00272-001-s482><apply.gelten><de> Dieselben Vorschriften gelten auch für den Fall, dass die Wertpapiere Teil eines Betriebsvermögens sind und weitere Anforderungen erfüllen.
<G-vec00272-001-s483><apply.gelten><en> Therefore, if a user is a part of a role, any permissions granted to the role will automatically apply to the user as well.
<G-vec00272-001-s483><apply.gelten><de> Wenn ein Benutzer daher einer Rolle angehört, gelten alle Berechtigungen, die dieser Rolle eingeräumt sind, automatisch auch für den Benutzer.
<G-vec00272-001-s484><apply.gelten><en> As a result, many of the existing agreements under which vendors use WorldCat data to provide services to OCLC member libraries apply only to services provided to one or more specific requesting libraries.
<G-vec00272-001-s484><apply.gelten><de> Daraus folgt, dass viele der bestehenden Verträge, in deren Rahmen Anbieter WorldCat-Daten zur Bereitstellung von Diensten für OCLC-Mitgliedsbibliotheken nutzen, nur für die entsprechenden Dienste gelten, die für die einzelnen Bibliotheken bereitgestellt werden.
<G-vec00272-001-s485><apply.gelten><en> These documents also apply to Vector Austria GmbH:
<G-vec00272-001-s485><apply.gelten><de> Diese Dokumente gelten auch für die Vector Austria GmbH.
<G-vec00272-001-s486><apply.gelten><en> Privacy Policy does not apply to services offered by other companies, including in cases where these services are accessible via services of eAgronom.
<G-vec00272-001-s486><apply.gelten><de> Die Datenschutzrichtlinien gelten nicht für Dienste, die von anderen Unternehmen angeboten werden, auch wenn diese Dienste über eAgronom-Dienste zugänglich sind.
<G-vec00272-001-s487><apply.gelten><en> The Indonesian visa process will change in 2019 (certain exceptions apply to Autumn 2018).
<G-vec00272-001-s487><apply.gelten><de> Der indonesische Visa-Prozess wird sich in 2019 ändern (einige Ausnahmen gelten auch für den Herbst 2018).
<G-vec00272-001-s488><apply.gelten><en> Equally strict hygiene regulations apply to transportation.
<G-vec00272-001-s488><apply.gelten><de> Ebenso strenge Hygienevorschriften gelten auch für den Transport.
<G-vec00272-001-s489><apply.gelten><en> All terms and conditions and policies of the Third Party Websites you visit will apply to you while on such websites and you should check them.
<G-vec00272-001-s489><apply.gelten><de> Alle Nutzungsbedingungen und Richtlinien solcher Websites Dritter, die Sie besuchen, gelten für Sie, solange Sie sich darauf befinden, und Sie sollten diese Bedingungen daher überprüfen.
<G-vec00272-001-s490><apply.gelten><en> Special rates only apply to certain offered time periods.
<G-vec00272-001-s490><apply.gelten><de> Sondertarife gelten nur für den angebotenen Zeitraum.
<G-vec00272-001-s491><apply.gelten><en> The conditions of the sale apply accordingly.
<G-vec00272-001-s491><apply.gelten><de> Die Bedingungen für die Versteigerung gelten für den Freiverkauf entsprechend.
<G-vec00272-001-s492><apply.gelten><en> If a reservation change is not possible and the Traveler gives up the confirmed reservation, the cancellation terms listed below apply.
<G-vec00272-001-s492><apply.gelten><de> Für den Fall, dass eine Veränderung der Buchung nicht möglich ist und der Gast deswegen von einer bereits bestätigten Buchung zurücktritt, gelten die unten genannten Bedingungen für die Buchungskündigung.
<G-vec00272-001-s493><apply.gelten><en> It's important to note a couple of things: First, these lists apply only to Constructed formats and not Limited formats.
<G-vec00272-001-s493><apply.gelten><de> Ein paar wichtige Dinge sollte man wissen: Erstens, diese Listen gelten nur für Constructed-Formate und nicht für Limited-Formate.
<G-vec00272-001-s494><apply.gelten><en> 1 The provisions of Article 14, sub-paragraph a, shall apply to members of the service staff of diplomatic missions or consular posts, and also to persons employed in the private service of officials of such missions or posts.
<G-vec00272-001-s494><apply.gelten><de> 1 Artikel 14 Buchstabe a gilt auch für Mitglieder des dienstlichen Hauspersonals diplomatischer Missionen und konsularischer Vertretungen sowie für private Hausangestellte im Dienste von Angehörigen dieser Missionen oder Vertretungen.
<G-vec00272-001-s495><apply.gelten><en> On discussion, this can also apply to your print components too, so that we can deliver your re-orders even more quickly.
<G-vec00272-001-s495><apply.gelten><de> Das gilt nach Absprache natürlich auch für Ihre Druckkomponenten, so dass wir bei Re-Ordern noch schneller liefern können.
<G-vec00272-001-s496><apply.gelten><en> For all these links apply: Messrs. Sakkara GmbH declares explicitly that they do not have any influence on design and content of the linked sites.
<G-vec00272-001-s496><apply.gelten><de> Für alle diese Links gilt: Die SAKKARA GmbH erklärt ausdrücklich, dass sie keinerlei Einfluss auf die Gestaltung und die Inhalte der verlinkten Seiten hat.
<G-vec00272-001-s497><apply.gelten><en> The traditional cheese of Spain requested to apply the flexibility of the rules of the European Union....
<G-vec00272-001-s497><apply.gelten><de> Traditionelle Käser von Spanien gefordert, dass die Flexibilität der Regeln der Europäischen Union gilt....
<G-vec00272-001-s498><apply.gelten><en> The limitation of liability shall further not apply in the cases in which there is liability for damage to persons or objects for privately used objects according to the Product Liability Act in defects of the goods delivered.
<G-vec00272-001-s498><apply.gelten><de> Die Haftungsbeschränkung gilt ferner nicht in den Fällen, in denen nach Produkthaftungsgesetz bei Fehlern der gelieferten Ware für Personen- oder Sachschäden an privat genutzten Gegenständen gehaftet wird.
<G-vec00272-001-s499><apply.gelten><en> § 9.4 The supplier's aforementioned obligations to save us harmless shall not apply if the supplier manufactured the items of delivery on the basis of drawings, models or identical descriptions or specifications made available by our company and the supplier doesn't know or - in context with the products he developed - doesn't need to know that they violate third-party rights.
<G-vec00272-001-s499><apply.gelten><de> § 9.4 Die vorstehende Einstandspflicht des Lieferanten gilt dann nicht, wenn der Lieferant die Liefergegenstände nach von uns übergebenen Zeichnungen, Modellen oder diesen gleich kommenden sonstigen Beschreibungen oder Angaben hergestellt hat und nicht weiß oder im Zusammenhang mit den von ihm entwickelten Erzeugnissen nicht wissen muss, dass dadurch Schutzrechte verletzt werden.
<G-vec00272-001-s500><apply.gelten><en> This does not apply if gigmit is responsible for the failed transaction.
<G-vec00272-001-s500><apply.gelten><de> Dies gilt nicht wenn gigmit für das Fehlschlagen verantwortlich ist.
<G-vec00272-001-s501><apply.gelten><en> This does not apply if this information and/or these documents are demonstrably already known to the public or if the supplier has designated them for resale by the purchaser.
<G-vec00272-001-s501><apply.gelten><de> Dies gilt nicht, wenn diese Informationen und/oder Dokumente nachweislich öffentlich bekannt sind oder vom Lieferer zur Weiterveräußerung durch den Käufer bestimmt wurden.
<G-vec00272-001-s502><apply.gelten><en> This fee will apply even if the item cannot be repaired or if it was not obtained from us.
<G-vec00272-001-s502><apply.gelten><de> Das gilt auch dann, wenn der Artikel irreparabel ist oder nicht von uns bezogen wurde.
<G-vec00272-001-s503><apply.gelten><en> This does not apply if the defect is not eliminated by us in a reasonable period.
<G-vec00272-001-s503><apply.gelten><de> Dies gilt nicht, wenn der Mangel durch uns nicht in angemessener Frist beseitigt wird.
<G-vec00272-001-s504><apply.gelten><en> With the surrender of things this does not apply if the deterioration is exclusively due to their inspection - is due - as would have been about you at our store.
<G-vec00272-001-s504><apply.gelten><de> Bei der Überlassung von Sachen gilt dies nicht, wenn die Verschlechterung der Sache ausschließlich auf deren Prüfung - wie sie Ihnen etwa im Ladengeschäft möglich gewesen wäre - zurückzuführen ist.
<G-vec00272-001-s505><apply.gelten><en> The requirementof approval shall apply in any case, even if e.g. we accept the seller's delivery without reservation being aware of his general terms and conditions.
<G-vec00272-001-s505><apply.gelten><de> Das Zustimmungserfordernis gilt in jedem Fall, beispielsweise auch dann, wenn wir in Kenntnis der Allgemeinen Geschäftsbedingungen des Verkäufers dessen Lieferung vorbehaltlos annehmen.
<G-vec00272-001-s506><apply.gelten><en> The same shall apply where there is good reason to assume that the receipt of an excise duty or the VAT is at risk; collateral may also be demanded in lieu of bringing the due date forward.
<G-vec00272-001-s506><apply.gelten><de> Das Gleiche gilt, wenn die Annahme begründet ist, dass der Eingang einer Verbrauchsteuer oder der Umsatzsteuer gefährdet ist; an Stelle der Vorverlegung der Fälligkeit kann auch Sicherheitsleistung verlangt werden.
<G-vec00272-001-s507><apply.gelten><en> If these preconditions are not fulfilled in good time, the delivery periods shall be extended by a reasonable amount of time; this does not apply if SAVVY can be held responsible for the delay.
<G-vec00272-001-s507><apply.gelten><de> Werden diese Voraussetzungen nicht rechtzeitig erfüllt, so verlängern sich die Fristen angemessen; dies gilt nicht, wenn die SAVVY die Verzögerung zu vertreten hat.
<G-vec00272-001-s508><apply.gelten><en> Insofar as the liability for damages towards Customer is excluded or limited, this shall also apply with respect to the personal liability for damage of employees, members of staff, co-operators, representatives and vicarious agents of Contractor.
<G-vec00272-001-s508><apply.gelten><de> Soweit die Schadenersatzhaftung gegenüber dem Kunden ausgeschlossen oder eingeschränkt ist, gilt dies auch im Hinblick auf die persönliche Schadenersatzhaftung der Angestellten, Arbeitnehmer, Mitarbeiter, Vertreter und Erfüllungsgehilfen des Auftragnehmers.
<G-vec00272-001-s509><apply.gelten><en> 17.2 For disagreements and disputes arising in connection with the Victorinox Online Shop, Swiss law shall apply to the exclusion of the UN Convention on Contracts for the International Sale of Goods (CISG).
<G-vec00272-001-s509><apply.gelten><de> 17.2 Bei Unstimmigkeiten und Streitigkeiten in Zusammenhang mit dem Online-Shop von Victorinox gilt unter Ausschluss aller Gesetze zu internationalen Käufen beweglicher Güter Schweizer Recht.
<G-vec00272-001-s510><apply.gelten><en> The same shall apply if the customer does not have a general jurisdiction in Germany or his domicile or ordinary residence are not know at the moment of filing an action.
<G-vec00272-001-s510><apply.gelten><de> Dasselbe gilt, wenn der Kunde keinen allgemeinen Gerichtsstand in Deutschland hat oder Wohnsitz oder gewöhnlicher Aufenthalt im Zeitpunkt der Klageerhebung nicht bekannt sind.
<G-vec00272-001-s511><apply.gelten><en> This shall not apply only if such relief is impossible or is refused by TO or if immediate termination of the contract is required by a particular interest of the client that is discernible to TO.
<G-vec00272-001-s511><apply.gelten><de> Dies gilt nur dann nicht, wenn Abhilfe unmöglich ist oder vom RV verweigert wird oder wenn die sofortige Kündigung des Vertrages durch ein besonderes, dem RV erkennbares Interesse des Kunden gerechtfertigt wird.
<G-vec00272-001-s512><apply.gelten><en> As the excess does, however, not apply to each insurance claim but to all insurance claims during an insurance year, bills (originals) should also be submitted if the amount of the doctors ́, laboratory or other medical bill or prescriptions is lower than the excess.
<G-vec00272-001-s512><apply.gelten><de> Da der Eigenanteil jedoch nicht je Versicherungsfall gilt, sondern sich auf alle Versicherungsfälle eines Versicherungsjahres erstreckt, bitten wir Sie, Rechnungen auch dann (im Original) bei uns einzureichen, wenn der Rechnungsbetrag von Arzt-, Labor oder sonstigen medizinischen Rechnungen oder Rezepten niedriger ausfällt.
<G-vec00272-001-s570><apply.sich_bewerben><en> However, all users who apply to Indeed Prime but are not accepted into the program will remain within the Indeed Prime database.
<G-vec00272-001-s570><apply.sich_bewerben><de> Allerdings werden alle Nutzer, die sich für Indeed Prime bewerben, jedoch nicht in das Programm aufgenommen werden, weiterhin in der Indeed-Prime-Datenbank geführt.
<G-vec00272-001-s571><apply.sich_bewerben><en> College of Business Scholarships are awarded in the semester(s) following the semester in which the scholarship applications are completed (e.g., students who apply for and are awarded scholarships in fall will receive financial support in the spring semester).
<G-vec00272-001-s571><apply.sich_bewerben><de> College of Business Stipendien werden im Semester vergeben (n) nach dem Semester, in dem die Stipendienanträgen abgeschlossen sind (zB Studenten, die sich bewerben und werden Stipendien im Herbst vergeben wird erhalten finanzielle Unterstützung im Frühlingssemester).
<G-vec00272-001-s572><apply.sich_bewerben><en> Refugees may register on the online platform cost-free and set up their applicant profile or directly apply for vacancies.
<G-vec00272-001-s572><apply.sich_bewerben><de> Flüchtlinge können sich auf der Online-Plattform kostenlos registrieren und ein Bewerberprofil erstellen oder sich direkt auf offene Stellenausschreibungen bewerben.
<G-vec00272-001-s573><apply.sich_bewerben><en> These terms and conditions might include a period of time when to be able to apply for the bonus after registering.
<G-vec00272-001-s573><apply.sich_bewerben><de> Diese Fristen und Bedingungen könnten eine Zeitspanne einschließen um im Stande zu sein, sich um den Bonus nach dem Registrieren zu bewerben.
<G-vec00272-001-s574><apply.sich_bewerben><en> Undergraduate political science majors may apply for admission to the political science master's program during their junior year.
<G-vec00272-001-s574><apply.sich_bewerben><de> Beschleunigter Bachelor-Master-Studiengang Bachelor-Politikwissenschaftler können sich während ihres Juniorjahres für die Zulassung zum Masterprogramm bewerben.
<G-vec00272-001-s575><apply.sich_bewerben><en> If, after completion of the online application procedure, you intend to apply for another job advertisement of FLG and if you have given your consent to the use of your data for this purpose, your data will be stored for the duration of this application procedure, as well.
<G-vec00272-001-s575><apply.sich_bewerben><de> Möchten Sie sich nach Abschluss des Online-Bewerbungsverfahrens auf eine weitere Stellenausschreibung der FLG bewerben und haben Sie der Verwendung ihrer Daten für diesen Zweck zugestimmt, werden Ihre Daten auch für die Dauer dieses Bewerbungsverfahrens gespeichert.
<G-vec00272-001-s576><apply.sich_bewerben><en> Your muscles volition transmute stronger as you apply.
<G-vec00272-001-s576><apply.sich_bewerben><de> Ihre Muskeln Volition verwandeln stärker als Sie sich bewerben.
<G-vec00272-001-s577><apply.sich_bewerben><en> Furthermore, they can actively browse through translation inquiries on the job board and actively apply for them.
<G-vec00272-001-s577><apply.sich_bewerben><de> Zusätzlich können sie aktiv Übersetzungsanfragen im Job Board sichten und sich darauf bewerben.
<G-vec00272-001-s578><apply.sich_bewerben><en> For any important FIFA tournaments, after the Futsal World Cup, the FA is trying to apply in future, she provably will fail.
<G-vec00272-001-s578><apply.sich_bewerben><de> Auf ein wichtiges FIFA-Turnier nach der Futsal-WM wird sich der Verband in Zukunft wahrscheinlich umsonst bewerben.
<G-vec00272-001-s579><apply.sich_bewerben><en> Fill in this online application form to apply for a job in a Søstrene Grene store that has not yet opened.
<G-vec00272-001-s579><apply.sich_bewerben><de> Füllen Sie dieses Online-Bewerbungsformular aus, um sich in einem Søstrene Grene Laden zu bewerben, der noch nicht eröffnet hat.
<G-vec00272-001-s580><apply.sich_bewerben><en> Additionally, you can also apply to us as a new supplier.
<G-vec00272-001-s580><apply.sich_bewerben><de> Ausserdem können Sie sich als neuer Lieferant bei uns bewerben.
<G-vec00272-001-s581><apply.sich_bewerben><en> You understand that if you apply for an open position on our website we will evaluate your background against the requirements of our client.
<G-vec00272-001-s581><apply.sich_bewerben><de> Sie verstehen, falls Sie sich für eine offene Stelle auf unserer Website bewerben, dass wir Ihr Profil hinsichtlich der Anforderungen unseres Kunden bewerten.
<G-vec00272-001-s582><apply.sich_bewerben><en> After that, they can apply for considerably greater venture capital financing from Telefónica S.A.
<G-vec00272-001-s582><apply.sich_bewerben><de> Anschließend können sie sich für eine erhebliche höhere Risikokapitalfinanzierung von Telefónica S. A. bewerben.
<G-vec00272-001-s583><apply.sich_bewerben><en> They ultimately ended up in Burghausen, where the local aid group recommended Fay to apply for work at WACKER.
<G-vec00272-001-s583><apply.sich_bewerben><de> Sie landen schließlich in Burghausen, wo der Helferkreis Fay empfiehlt, sich bei WACKER zu bewerben.
<G-vec00272-001-s584><apply.sich_bewerben><en> "That's why we not only look into which tailor studios you can apply for, but also in opera houses, theatres and in the independent scene, ""explains Claudia Grewe, who teaches the language."
<G-vec00272-001-s584><apply.sich_bewerben><de> Deshalb schauen wir nicht nur, in welchen Schneider-Ateliers man sich bewerben kann, sondern auch in Opernhäusern, Theatern und in der Freien Szene“, erklärt Claudia Grewe, die den Sprachunterricht gibt.
<G-vec00272-001-s585><apply.sich_bewerben><en> You need to apply as a doctoral student for the places available within these programmes and adhere to the relevant deadlines.
<G-vec00272-001-s585><apply.sich_bewerben><de> Sie müssen sich als Doktorand/in auf die in diesen Programmen zur Verfügung stehenden Plätze bewerben und die entsprechenden Fristen einhalten.
<G-vec00272-001-s586><apply.sich_bewerben><en> Graduates will be able to apply for further study at postgraduate level, including for a place on our full-time or part-time MSc Biomedical Engineering and Instrumentation or MSc Embedded and Distributed Systems.
<G-vec00272-001-s586><apply.sich_bewerben><de> Die Absolventen können sich für ein weiterführendes Studium auf postgradualer Ebene bewerben, einschließlich für einen Platz in unserem Vollzeit- oder Teilzeit-MSc Biomedizintechnik und Instrumentierung oder MSc Embedded and Distributed Systems.
<G-vec00272-001-s587><apply.sich_bewerben><en> However, various studies have shown that there is a significant discrepancy between the willingness of potential applicants to apply online and the online opportunities provided for this by companies.
<G-vec00272-001-s587><apply.sich_bewerben><de> Wie diverse Studien allerdings zeigen, besteht eine nicht unerhebliche Diskrepanz zwischen der Bereitschaft potenzieller Bewerber, sich online zu bewerben und den hierfür von Unternehmen im Internet gebotenen Möglichkeiten.
<G-vec00272-001-s588><apply.sich_bewerben><en> You can apply very easily at Ecologic Institute.
<G-vec00272-001-s588><apply.sich_bewerben><de> Bei uns können Sie sich ganz einfach bewerben.
<G-vec00272-001-s684><apply.verwenden><en> It is possible to apply an aluminium grid; copper or brass it is necessary to tin tin.
<G-vec00272-001-s684><apply.verwenden><de> Man kann das Aluminiumnetz verwenden; kupfern oder latunnuju ist es unbedingt ludit vom Zinn notwendig.
<G-vec00272-001-s685><apply.verwenden><en> As the product’s name states, it is an oil you apply directly to your penis to get the same results you get from taking male improvement tablets.
<G-vec00272-001-s685><apply.verwenden><de> Wie der Name schon sagt Stück, ist es ein Öl direkt an Ihrem Penis verwenden die gleichen Ergebnisse, die Sie von der Einnahme männlichen Verbesserung Tabletten erhalten zu bekommen.
<G-vec00272-001-s686><apply.verwenden><en> We apply the above criteria when awarding a customer card at Trends & Trade.
<G-vec00272-001-s686><apply.verwenden><de> Oben stehende Kriterien verwenden wir bei der Vergabe von Kundenkarten bei Trends & Trade.
<G-vec00272-001-s687><apply.verwenden><en> These concentration skills are something that one can then apply in meditation.
<G-vec00272-001-s687><apply.verwenden><de> Und diese Konzentrationsfähigkeit kann man dann in der Meditation verwenden.
<G-vec00272-001-s688><apply.verwenden><en> Especially advise to apply oil jojoba to the brittle hair injured with the whipped tips.
<G-vec00272-001-s688><apply.verwenden><de> Besonders beraten, das Öl schoschoba für das Haar brüchig, beschädigt, mit den geprügelten Spitzen zu verwenden.
<G-vec00272-001-s689><apply.verwenden><en> "In nebulizers at cold apply the same physical solution, and still alkaline mineral waters (mainly, ""Borjomi""), previously having exempted them from gases."
<G-vec00272-001-s689><apply.verwenden><de> "In nebulajserach beim Schnupfen verwenden selb fisrastwor, und noch die alkalischen Mineralwasser, (hauptsächlich, ""Borschomi""), vorläufig sie von den Gasen befreit."
<G-vec00272-001-s690><apply.verwenden><en> With that information, we apply the most innovative technologies in injection moulding that set our product apart from our competitors.
<G-vec00272-001-s690><apply.verwenden><de> Mit diesen Informationen verwenden wir die innovativsten Technologien im Spritzguss, die unser Produkt von der Konkurrenz unterscheiden.
<G-vec00272-001-s691><apply.verwenden><en> At repair work apply the same tool, as at performance of new products.
<G-vec00272-001-s691><apply.verwenden><de> Bei den Reparaturarbeiten verwenden das selbe Instrument, dass auch bei der Ausführung der neuen Erzeugnisse.
<G-vec00272-001-s692><apply.verwenden><en> We don't apply any hidden charges online or at our Kardjali car rental desk.
<G-vec00272-001-s692><apply.verwenden><de> Wir verwenden keine versteckte Kosten online am unseren KardjaliAutoverleih Schalter.
<G-vec00272-001-s693><apply.verwenden><en> A laying apply at building of buildings in height to four floors.
<G-vec00272-001-s693><apply.verwenden><de> Das Mauerwerk verwenden beim Bau der Gebäude in der Höhe bis zu vier Stockwerken.
<G-vec00272-001-s694><apply.verwenden><en> Do not hesitate to apply a little inspiration and to decorate the handle as it will want to you, having picked up some details independently - remember only that they have to keep strong on the places with what bolts and, as a last resort, a wire will help incomparably best of all even the most reliable glue.
<G-vec00272-001-s694><apply.verwenden><de> Genieren Sie sich nicht, ein wenig Eingebung zu verwenden und, den Griff zu schmücken so, wie es Ihnen wünschenswert ist, etwas Details selbständig ausgewählt - erinnern Sie sich nur daran, dass sie sich auf den Stellen, worin die Bolzen und, für den äußersten Fall fest halten sollen, der Draht werden unvergleichbar besser sogar des sichersten Leims helfen.
<G-vec00272-001-s695><apply.verwenden><en> We don't apply any hidden charges online or at our Bourgas car rental desk.
<G-vec00272-001-s695><apply.verwenden><de> Wir verwenden keine versteckte Kosten online am unseren BurgasAutoverleih Schalter.
<G-vec00272-001-s696><apply.verwenden><en> ”Our system can be seen as an extension of the advanced logistics solution that many industries already apply today”, says Mikael Karlsson, Vice President Autonomous Solutions, Volvo Trucks.
<G-vec00272-001-s696><apply.verwenden><de> „Man kann sich unser System als Erweiterung der ausgeklügelten Logistiklösung vorstellen, die viele Branchen heutzutage verwenden“, so Mikael Karlsson, Vice President Autonomous Solutions, Volvo Trucks.
<G-vec00272-001-s697><apply.verwenden><en> It is best of all to apply special means.
<G-vec00272-001-s697><apply.verwenden><de> Es ist am besten, die speziellen Mittel zu verwenden.
<G-vec00272-001-s698><apply.verwenden><en> This type of laying of a tile is recommended to apply in any rooms where many people will move.
<G-vec00272-001-s698><apply.verwenden><de> Diese Art des Verpackens der Fliese empfehlen, in beliebigen Räumen zu verwenden, wo sich viel Menschen bewegen werden.
<G-vec00272-001-s699><apply.verwenden><en> For measurements in areas such as neighborhood or traffic noise, private users can apply the sound level loggers that log the sound level with the set rating.
<G-vec00272-001-s699><apply.verwenden><de> Für Messungen in den Bereichen wie Nachbarschafts- oder Verkehrslärm können Privatanwender Schallpegellogger verwenden, die den Schallpegel mit der eingestellten Bewertung loggen.
<G-vec00272-001-s700><apply.verwenden><en> As the product’s name states, it is an oil you apply directly to your penis to get the very same outcomes you receive from taking male improvement pills.
<G-vec00272-001-s700><apply.verwenden><de> Wie der Name schon sagt das Produkt ist es ein Öl direkt an Ihrem Penis verwenden exakt die gleichen Ergebnisse, die Sie von der Einnahme männlichen Verbesserung Tabletten erhalten zu bekommen.
<G-vec00272-001-s701><apply.verwenden><en> For this keyframe you can apply the same keyframe assistant (Easy Ease) and change the speed in the graph editor, just like in the others layers.
<G-vec00272-001-s701><apply.verwenden><de> Für diesen Keyframe könnt ihr denselben Keyframe-Assistenten (Easy Ease) verwenden und die Geschwindigkeit im Diagrammeditor ändern, genau wie in den anderen Ebenen.
<G-vec00272-001-s702><apply.verwenden><en> In order to ease application, patients may use a cotton swab to apply it.
<G-vec00272-001-s702><apply.verwenden><de> Um die Anwendung zu erleichtern, können die Patienten einen Wattestäbchen verwenden.
<G-vec00272-001-s741><apply.zutreffen><en> At the end of this course, successful students will (i) have learned intermediate concepts from microeconomics, (ii) understand how these concepts apply to the world around them and to their own lives, and (iii) have constructed a fairly sophisticated basis from which to study other areas of economics.
<G-vec00272-001-s741><apply.zutreffen><de> Am Ende dieses Kurses werden erfolgreiche Studenten (i) Zwischenkonzepte aus der Mikroökonomie gelernt haben, (ii) verstehen, wie diese Konzepte auf die Welt um sie herum und auf ihr eigenes Leben zutreffen, und (iii) eine ziemlich ausgeklügelte Basis daraus konstruiert haben welches andere Bereiche der Wirtschaft studiert.
<G-vec00272-001-s742><apply.zutreffen><en> 4.Out of the window light:a light window is 1.0 cmX2.5 cm,the coated filter is used in the 610-1200nm wavelength,apply to depilation;another light window is 1.4 cmX3.4 cm,the coated filter is used in the 530-1200nm wavelength,apply to tender skin.
<G-vec00272-001-s742><apply.zutreffen><de> 4. aus dem Fensterlicht heraus: ein helles Fenster ist 1,0 cmX2.5 cm, der überzogene Filter wird verwendet in der Wellenlänge 610-1200nm, zutreffen auf Enthaarung; ein anderes helles Fenster ist 1,4 cmX3.4 cm, der überzogene Filter wird verwendet in der Wellenlänge 530-1200nm, zutreffen auf zarte Haut.
<G-vec00272-001-s744><apply.zutreffen><en> Some lenders will only process money during business days, which can be a problem if you apply on the weekend.
<G-vec00272-001-s744><apply.zutreffen><de> Einige kreditgebende Stellen verarbeiten nur Geld während der Werktage, die ein Problem sein können, wenn Sie am Wochenende zutreffen.
<G-vec00272-001-s745><apply.zutreffen><en> The rules that apply to the provision of tax from sales across states, let alone across continents, are still not that precise.
<G-vec00272-001-s745><apply.zutreffen><de> Die Richtlinien, die auf die Bestimmung der Steuer von den Verkäufen über Zuständen, geschweige denn über Kontinenten zutreffen, sind noch nicht exakte die.
<G-vec00272-001-s746><apply.zutreffen><en> A belief that we are so brilliant and innovative that the mundane rules of accounting, corporate governance, and even basic economics do not apply to us.
<G-vec00272-001-s746><apply.zutreffen><de> Eine Überzeugung, dass wir so brillant und erfinderisch sind, so dass die banalen Richtlinien der Buchhaltung, der Unternehmensführung und sogar der Volkswirtschaft nicht auf uns zutreffen.
<G-vec00272-001-s747><apply.zutreffen><en> Additional terms and conditions may apply to reservations, purchases of goods and services and other uses of portions of this site, and you agree to abide by such other terms and conditions.
<G-vec00272-001-s747><apply.zutreffen><de> Zusätzliche Bedingungen können auf Reservierungen, Einkäufe von Waren und Services und andere Gebräuche dieser Seite zutreffen, und Sie sind damit einverstanden, sich solche andere Bedingungen zu halten.
<G-vec00272-001-s748><apply.zutreffen><en> A: Yes, all our products are strictly apply with ISO, CE TUV or any other special requirements as customers.
<G-vec00272-001-s748><apply.zutreffen><de> A: Ja sind alle unsere Produkte zutreffen ausschließlich mit ISO, CER TUV oder allen anderen speziellen Anforderungen als Kunden.
<G-vec00272-001-s749><apply.zutreffen><en> His group will apply the magnet to the left side of the head in some patients, and the right side in others.
<G-vec00272-001-s749><apply.zutreffen><de> Seine Fraktion wird der Magnet auf der linken Seite des Kopfes bei einigen Patienten zutreffen, und die rechte Seite in andere.
<G-vec00272-001-s750><apply.zutreffen><en> They may or may not apply to your situation, but I think somebody may find them useful.
<G-vec00272-001-s750><apply.zutreffen><de> Sie können auf Deine Situation zutreffen oder nicht, doch ich hoffe, jemand findet sie nützlich.
<G-vec00272-001-s751><apply.zutreffen><en> They are basically all terms that apply to me, but they only represent a part of me.
<G-vec00272-001-s751><apply.zutreffen><de> Das sind im Grunde genommen alles Begriffe, die auf mich zutreffen, aber es macht nur einen Teil von mir aus.
<G-vec00272-001-s752><apply.zutreffen><en> If imponderables occur or if the assumptions on which the forward-looking statements are made do not apply, actual results may deviate materially from the statements made or the results implicitly expressed.
<G-vec00272-001-s752><apply.zutreffen><de> Sollten Unwägbarkeiten eintreten oder die den vorausschauenden Aussagen zugrunde liegenden Prämissen nicht zutreffen, könnten die tatsächlichen Ergebnisse wesentlich von den getroffenen Aussagen oder implizit zum Ausdruck gebrachten Ergebnissen abweichen.
<G-vec00272-001-s753><apply.zutreffen><en> Contribution to Free Software projects seems a slightly better choice, but as many Free Software projects have adopted a collaborative development model in which the users themselves drive development, that label would then also apply to companies that aren't Information Technology (IT) companies.
<G-vec00272-001-s753><apply.zutreffen><de> Die Mitwirkung an Freie-Software-Projekten scheint eine etwas bessere Wahl zu sein, aber da viele Freie-Software-Projekte ein kollaboratives Entwicklungsmodell übernommen haben, in dem die Benutzer selbst die Entwicklung vorantreiben, würde diese Bezeichnung dann auch auf Unternehmen zutreffen, die keine Unternehmen der Informationstechnik (IT) sind.
<G-vec00272-001-s754><apply.zutreffen><en> After you have received the documents from the school you apply to the embassy or consulate for a visa.
<G-vec00272-001-s754><apply.zutreffen><de> Nachdem Sie die Dokumente von der Schule empfangen, zutreffen Sie auf die Botschaft oder das Konsulat für ein Visum.
<G-vec00272-001-s755><apply.zutreffen><en> His seven rules for life and design happiness can (with some customizations) apply to everyone seeking more joy. Play
<G-vec00272-001-s755><apply.zutreffen><de> Seine sieben Regeln für das Leben und die Gestalt von Zufriedenheit kann (mit einigen Anpassungen) auf jeden zutreffen, der nach mehr Freude sucht.
<G-vec00272-001-s756><apply.zutreffen><en> In this case, the category or categories which do not apply to your product will not appear.
<G-vec00272-001-s756><apply.zutreffen><de> In diesem Fall werden Kategorien, die nicht auf Ihr Produkt zutreffen, nicht angezeigt.
<G-vec00272-001-s757><apply.zutreffen><en> Although it is important to scrutinize the teachings to see if they are valid, we need to think first in terms of how they would apply in our daily lives.
<G-vec00272-001-s757><apply.zutreffen><de> Obwohl es wichtig ist, die Lehren auf ihre Stichhaltigkeit zu untersuchen, müssen wir zuerst darüber nachdenken, wie sie hinsichtlich unseres Alltags zutreffen.
<G-vec00272-001-s758><apply.zutreffen><en> Also, when evaluating a data sheet, pay attention to the methods that apply to your situation.
<G-vec00272-001-s758><apply.zutreffen><de> Achten Sie außerdem beim Auswerten eines Produktdatenblatts auf die Methoden, die auf Ihre Situation zutreffen.
<G-vec00272-001-s759><apply.zutreffen><en> An authority can for instance search for persons with a specific religious affiliation and occupational qualification who regularly visit a certain meeting place. If there is a match, the requesting authority not only receives information about which authority has these data, but also the names, addresses and other basic information about all persons to whom the characteristics it inquired about apply.
<G-vec00272-001-s759><apply.zutreffen><de> So kann eine Behörde zum Beispiel nach Personen mit einer bestimmten Religionszugehörigkeit und Ausbildung, die einen bestimmten Treffpunkt frequentieren, suchen und erhält im Trefferfall nicht nur die Angabe, welche Behörde darüber Informationen besitzt, sondern auch die Namen, Adressen sowie weitere Grundinformationen von allen Personen, auf die die abgefragten Merkmale zutreffen.
<G-vec00272-001-s760><apply.übernehmen><en> After entering the 192.168.100.1 address and configuring telecomadmin / admintelecom or root / admin, you need to go to the WLAN section, enter the name of your own connection and the new PSK password in the SSID Name field with the obligatory click on the Apply button.
<G-vec00272-001-s760><apply.übernehmen><de> Nachdem Sie die 192.168.100.1-Adresse eingegeben und telecomadmin / admintelecom oder root / admin konfiguriert haben, müssen Sie in den WLAN-Bereich gehen, den Namen Ihrer eigenen Verbindung und das neue PSK-Passwort in das Feld SSID-Name eingeben und auf die Schaltfläche Übernehmen klicken.
<G-vec00272-001-s761><apply.übernehmen><en> Then click “Apply“ to save the settings.
<G-vec00272-001-s761><apply.übernehmen><de> Klicken Sie dann zum Speichern der Einstellungen auf „Übernehmen“.
<G-vec00272-001-s762><apply.übernehmen><en> Then drag the autofill handle down to apply cells with this formula.
<G-vec00272-001-s762><apply.übernehmen><de> Ziehen Sie dann den Autofüll-Handle nach unten, um Zellen mit dieser Formel zu übernehmen.
<G-vec00272-001-s763><apply.übernehmen><en> Click on OK to apply the change.
<G-vec00272-001-s763><apply.übernehmen><de> Klicken Sie auf OK, um die Änderungen zu übernehmen.
<G-vec00272-001-s764><apply.übernehmen><en> If you want to prevent subsequent files and subfolders of the original object from inheriting these audit entries, select the Apply these auditing entries to objects and/or containers within this container only check box.
<G-vec00272-001-s764><apply.übernehmen><de> Wenn diese Überwachungseinträge nicht an die nachfolgenden Dateien und Unterordner des ursprünglichen Objekts vererbt werden sollen, aktivieren Sie das Kontrollkästchen Überwachungseinträge nur für Objekte und/oder Container dieses Containers übernehmen.
<G-vec00272-001-s765><apply.übernehmen><en> "After changing the permissions, click ""Apply"" and then ""YES"" to confirm."
<G-vec00272-001-s765><apply.übernehmen><de> Klicken Sie nach dem Ändern der Berechtigungen auf „Übernehmen“ und anschließend zum Bestätigen auf „Ja“.
<G-vec00272-001-s766><apply.übernehmen><en> "In order to activate the change, click the button ""apply""."
<G-vec00272-001-s766><apply.übernehmen><de> "Um die Änderung zu aktivieren, klicken Sie auf die Schaltfläche ""Übernehmen""."
<G-vec00272-001-s767><apply.übernehmen><en> Click Apply, restart the PC and install SpyHunter.
<G-vec00272-001-s767><apply.übernehmen><de> Klicken Sie auf übernehmen, starten Sie den PC neu und installieren SpyHunter.
<G-vec00272-001-s768><apply.übernehmen><en> Social and Institutional Dimensions of Human Behavior courses allow students to apply critical thinking skills to the understanding of human behavior.
<G-vec00272-001-s768><apply.übernehmen><de> Soziale und institutionelle Dimensionen des menschlichen Verhaltens Kurse ermöglichen den Schülern Fähigkeiten zum kritischen Denken auf das Verständnis des menschlichen Verhaltens zu übernehmen.
<G-vec00272-001-s769><apply.übernehmen><en> Click the Preview button as needed to apply your settings and view the adjusted image before scanning.
<G-vec00272-001-s769><apply.übernehmen><de> Mit Erneute Vorschau lassen Sie die Einstellungen übernehmen und das angepasste Bild anzeigen, bevor der Scanvorgang endgültig gestartet wird.
<G-vec00272-001-s770><apply.übernehmen><en> We will cover travel and accommodation expenses for students coming from Bergen or Tromsø. How to apply:
<G-vec00272-001-s770><apply.übernehmen><de> Für Studenten, die aus Bergen oder Tromsø kommen, übernehmen wir die Reise- und Übernachtungskosten.
<G-vec00272-001-s771><apply.übernehmen><en> If there are dates with multiple formats you want to convert to standard date format, you can try to apply Convert to Date utility of Kutools for Excel .
<G-vec00272-001-s771><apply.übernehmen><de> Wenn Daten mit mehreren Formaten vorliegen, die Sie in das Standard-Datumsformat konvertieren möchten, können Sie versuchen, sie zu übernehmen Convert to Date Nutzen von Kutools for Excel .
<G-vec00272-001-s772><apply.übernehmen><en> Apply the settings and refresh the image in the Preview/Edit area.
<G-vec00272-001-s772><apply.übernehmen><de> Übernehmen der Einstellungen und Aktualisieren des Bildes im Vorschaubereich.
<G-vec00272-001-s773><apply.übernehmen><en> Click the Apply button.
<G-vec00272-001-s773><apply.übernehmen><de> Klicken Sie auf Übernehmen.
<G-vec00272-001-s774><apply.übernehmen><en> Apply to dry, unwashed hair, after the exposure time of 20 minutes.
<G-vec00272-001-s774><apply.übernehmen><de> Übernehmen, um trockene, ungewaschene Haare, nach einer Einwirkungszeit von 20 Minuten.
<G-vec00272-001-s775><apply.übernehmen><en> If you want to save the changes for all recipient lists, click Apply changes to all lists .
<G-vec00272-001-s775><apply.übernehmen><de> Wenn Sie die getroffenen Änderungen für alle Empfängerlisten speichern möchten, klicken Sie auf Änderungen in alle Empfängerlisten übernehmen .
<G-vec00272-001-s776><apply.übernehmen><en> Click on “Apply” button to proceed.
<G-vec00272-001-s776><apply.übernehmen><de> Wählen Sie zum Fortfahren „Übernehmen“.
<G-vec00272-001-s777><apply.übernehmen><en> You can change the state of all new file handlers with a click on the box and the selection of apply and then ok in the menu.
<G-vec00272-001-s777><apply.übernehmen><de> Sie können ändern Sie den Status aller neuen Datei-Handler mit einem Klick auf die box und die Auswahl übernehmen und dann auf ok in das Menü.
<G-vec00272-001-s778><apply.übernehmen><en> If you have previously worked with the Mailings Classic function, you can also select mailings here and apply the content created using this function.
<G-vec00272-001-s778><apply.übernehmen><de> Wenn Sie bisher mit der Funktion Mailings Classic gearbeitet haben, können Sie hier auch Mailings auswählen und deren Inhalte übernehmen, die mit dieser Funktion erstellt wurden.
<G-vec00272-002-s038><apply.anfallen><en> Depending on the rate, cancellation charges or alteration fees may apply.
<G-vec00272-002-s038><apply.anfallen><de> Je nach Tarif können Stornokosten oder Umbuchungsgebühren anfallen.
<G-vec00272-002-s039><apply.anfallen><en> * Data fees may apply.
<G-vec00272-002-s039><apply.anfallen><de> Es können Datengebühren anfallen.
<G-vec00272-002-s040><apply.anfallen><en> 1 than 5 rooms, different policies and additional supplements may apply.
<G-vec00272-002-s040><apply.anfallen><de> Bei Buchung von mehr als 5 Zimmern könnten andere Buchungsbestimmungen gelten und zusätzliche Gebühren anfallen.
<G-vec00272-002-s041><apply.anfallen><en> Additional charges may apply for Lounge Access where the guest count is greater than the Member plus one allowance (including children).
<G-vec00272-002-s041><apply.anfallen><de> Zusätzliche Kosten können für den Lounge-Zugang anfallen, wenn die Gästezahl die zulässige Belegung durch das Mitglied plus einen Gast (einschließlich Kindern) übersteigt.
<G-vec00272-002-s042><apply.anfallen><en> ISP fees may apply and additional requirements may apply over time for updates.
<G-vec00272-002-s042><apply.anfallen><de> Im Laufe der Zeit können Gebühren des Internetdienstanbieters anfallen und zusätzliche Anforderungen für Updates erforderlich sein.
<G-vec00272-002-s043><apply.anfallen><en> 5.2 You are responsible for the payment of any taxes or other duties which may apply in connection with this software license.
<G-vec00272-002-s043><apply.anfallen><de> 5.2 Sie sind für die Entrichtung aller Steuern und sonstigen Abgaben verantwortlich, die im Zusammenhang mit der Softwarelizenz anfallen.
<G-vec00272-002-s044><apply.anfallen><en> Please note that for reservation of more than 5 rooms, different policies and additional supplements may apply.
<G-vec00272-002-s044><apply.anfallen><de> Bitte beachten Sie, dass für Buchungen ab 6 Zimmern abweichende Hotelrichtlinien gelten und gegebenenfalls zusätzliche Gebühren anfallen.
<G-vec00272-002-s045><apply.anfallen><en> Wireless Internet access requires AirPort Card, AirPort Base Station, and Internet access (fees may apply).
<G-vec00272-002-s045><apply.anfallen><de> Der drahtlose Zugriff auf das Internet erfordert eine Basisstation oder einen anderen drahtlosen Zugangspunkt sowie Internetzugang (hierfür können Gebühren anfallen).
<G-vec00272-002-s046><apply.anfallen><en> Note: to change a booking via any method, a change fee may apply depending on the fare type purchased.
<G-vec00272-002-s046><apply.anfallen><de> Hinweis: Unabhängig von der Methode Ihrer Buchungsänderung, kann zusätzlich noch eine Änderungsgebühr laut Tarifbedingungen anfallen.
<G-vec00272-002-s047><apply.anfallen><en> Price based on 8 guests In case there are more than 8 guests an extra fee per guest may apply
<G-vec00272-002-s047><apply.anfallen><de> Preis basiert auf 8 Gäste Bei mehr als 8 Gästen kann eine Extra Gebühr anfallen.
<G-vec00272-002-s048><apply.anfallen><en> For single occupancy an additional single room surcharge may apply.
<G-vec00272-002-s048><apply.anfallen><de> Bei Einzelbelegung kann zusätzlich ein Einzelzimmeraufschlag anfallen.
<G-vec00272-002-s049><apply.anfallen><en> Depending on your preferred method of payment, a payment surcharge may apply.
<G-vec00272-002-s049><apply.anfallen><de> Abhängig von Ihrer bevorzugten Zahlungsmethode kann ein Zahlungszuschlag anfallen.
<G-vec00272-002-s050><apply.anfallen><en> Show more Show less Policies Guests are required to inform the property in advance of their estimated time of arrival and whether guests require a boat transfer (surcharges may apply) prior to arrival via the Special Request box or contact the property directly.
<G-vec00272-002-s050><apply.anfallen><de> Mehr zeigen Weniger anzeigen AGB Gäste müssen die Unterkunft im Voraus über ihre voraussichtliche Ankunftszeit unterrichten und darüber, ob ein Boottransfer benötigt wird (Extragebühren können anfallen).
<G-vec00272-002-s051><apply.anfallen><en> If you are calling from outside of Belgium, use the following telephone number: 00353 1 436 9006 (International call charges may apply).
<G-vec00272-002-s051><apply.anfallen><de> Falls Sie aus dem Ausland anrufen, wählen Sie bitte +353 1 436 9080 (entsprechende Auslandskosten können anfallen).
<G-vec00272-002-s052><apply.anfallen><en> For orders outside the EU, fees may apply for the customs clearance.
<G-vec00272-002-s052><apply.anfallen><de> Bei Bestellungen außerhalb der EU können Kosten bei der Verzollung anfallen.
<G-vec00272-002-s053><apply.anfallen><en> For a delivery in other countries as Germany, Austria, Switzerland, Liechtenstein, the Netherlands, Belgium, UK, Ireland, France, Italy, Poland, Czech Republic, Denmark and Sweden also taxes, duties and / or charges may apply that are not in are taken into account the prices.
<G-vec00272-002-s053><apply.anfallen><de> Bei einer Lieferung in andere Länder als Deutschland, Österreich, Schweiz, Liechtenstein, Niederlande, Belgien, Vereinigtes Königreich, Irland, Frankreich, Italien, Polen, Tschechische Republik, Dänemark und Schweden können zusätzlich Steuern, Zölle und/oder Kosten anfallen, die nicht in den Preisen berücksichtigt sind.
<G-vec00272-002-s054><apply.anfallen><en> Delivery outside the EU: We draw your attention, with a delivery to a delivery address outside the European Union still may apply for additional customs fees or other costs.
<G-vec00272-002-s054><apply.anfallen><de> Lieferung außerhalb der EU: Wir machen Sie darauf aufmerksam, bei einer Lieferung an eine Lieferanschrift außerhalb der Europäischen Union noch weitere Zollgebühren oder weitere Kosten anfallen können.
<G-vec00272-002-s055><apply.anfallen><en> When purchasing a licence to use and download certain Content from a Site charges in addition to the standard data charges referred to above may apply to such Content (“Additional Charges”).
<G-vec00272-002-s055><apply.anfallen><de> Beim Kauf einer Lizenz zur Nutzung und zum Download bestimmter Inhalte von einer Website können zusätzlich zu den oben genannten Standarddatenkosten weitere Gebühren anfallen („Zusätzliche Gebühren“).
<G-vec00272-002-s056><apply.anfallen><en> Amtrak doesn't charge a ticket change fee, but other fees may apply.
<G-vec00272-002-s056><apply.anfallen><de> Amtrak erhebt keine Änderungsgebühr für die Fahrkarte, allerdings können andere Gebühren anfallen.
<G-vec00272-002-s057><apply.anwenden><en> The roller position will be adjusted by spacer and motor adjustment to realize one set of the roller to apply for different size of pipe.
<G-vec00272-002-s057><apply.anwenden><de> Die Rollenposition wird durch Einstellung des Abstandhalters und des Motors eingestellt, um einen Satz der Rolle zu realisieren, der auf unterschiedliche Rohrgrößen angewendet werden kann.
<G-vec00272-002-s058><apply.anwenden><en> Fires NOTE: These settings will only apply to the browser and device you are currently using.
<G-vec00272-002-s058><apply.anwenden><de> C13420B – HINWEIS: Diese Einstellung wird nur auf den Browser und das Gerät angewendet, das Sie derzeit benutzen.
<G-vec00272-002-s059><apply.anwenden><en> The exemption option specifies that a first-time adopter may elect not to apply IFRS 3 “Business Combinations” to business combinations that occurred before the date of transition to IFRSs.
<G-vec00272-002-s059><apply.anwenden><de> Die Befreiungsvorschrift sieht vor, dass auf Unternehmenszusammenschlüsse, die vor dem Übergangszeitpunkt nach anderen Rechnungslegungsvorschriften abgebildet wurden, IFRS 3 „Unternehmenszusammenschlüsse“ nicht angewendet werden muss.
<G-vec00272-002-s060><apply.anwenden><en> The project partners apply the "Design for all" concept as part of the development efforts.
<G-vec00272-002-s060><apply.anwenden><de> Im Rahmen der Entwicklungsarbeiten wird dabei das Konzept des „Design for all“ angewendet.
<G-vec00272-002-s061><apply.anwenden><en> Any price and availability information displayed on Amazon at the time of purchase will apply to the purchase of this
<G-vec00272-002-s061><apply.anwenden><de> Jeder Preis und die Verfügbarkeits-Informationen bei AMAZON, die zum Zeitpunkt des Kaufs angezeigt werden, werden auf das Produkt angewendet.
<G-vec00272-002-s062><apply.anwenden><en> For example, you can specify what metadata profile and video encoding profile to apply to video assets that you upload.
<G-vec00272-002-s062><apply.anwenden><de> Beispielsweise können Sie angeben, welches Metadatenprofil und welches Videokodierungsprofil auf Video-Assets angewendet wird, die Sie hochladen.
<G-vec00272-002-s063><apply.anwenden><en> The rule (default or node function) will apply only to items that have this data type (or a derived data type).
<G-vec00272-002-s063><apply.anwenden><de> Die Regel (Standardwert oder Node-Funktion) wird nur auf Datenelemente dieses Datentyps (oder eines davon abgeleiteten Datentyps) angewendet.
<G-vec00272-002-s064><apply.anwenden><en> It automatically tracks specific parts of a subject in motion and apply an effect.
<G-vec00272-002-s064><apply.anwenden><de> Dabei werden automatisch bestimmte Teile eines beweglichen Objekts verfolgt und ein Effekt wird angewendet.
<G-vec00272-002-s065><apply.anwenden><en> Flag fabric fuses Ta NOTE: These settings will only apply to the browser and device you are currently using.
<G-vec00272-002-s065><apply.anwenden><de> Availability: Vorrätig HINWEIS: Diese Einstellung wird nur auf den Browser und das Gerät angewendet, das Sie derzeit benutzen.
<G-vec00272-002-s066><apply.anwenden><en> Apply a solution of castor oil can only be in the period of active flowering or growth.
<G-vec00272-002-s066><apply.anwenden><de> Eine Lösung aus Rizinusöl kann nur in der Zeit der aktiven Blüte oder des Wachstums angewendet werden.
<G-vec00272-002-s067><apply.anwenden><en> € NOTE: These settings will only apply to the browser and device you are currently using.
<G-vec00272-002-s067><apply.anwenden><de> PXB2218 – HINWEIS: Diese Einstellung wird nur auf den Browser und das Gerät angewendet, das Sie derzeit benutzen.
<G-vec00272-002-s068><apply.anwenden><en> If you apply a master page to a layout page, the items on the master page will affect only the Default layer of that layout page.
<G-vec00272-002-s068><apply.anwenden><de> Wenn eine Musterseite auf eine Layoutseite angewendet wird, wirken sich die Objekte der Musterseite nur auf die Ebene Standard der Layoutseite aus.
<G-vec00272-002-s069><apply.anwenden><en> In Berlin, we develop, found, test and apply.
<G-vec00272-002-s069><apply.anwenden><de> In Berlin wird entwickelt, gegründet, getestet und angewendet.
<G-vec00272-002-s070><apply.anwenden><en> Note: The connector is reverse polarity protected; please do not apply force when plugging it in.
<G-vec00272-002-s070><apply.anwenden><de> Hinweis: Der Stecker ist verpolungsgeschützt, es darf beim Einstecken keine Gewalt angewendet werden.
<G-vec00272-002-s071><apply.anwenden><en> Automated Updates mode does apply any Cumulative Updates that are available for a host.
<G-vec00272-002-s071><apply.anwenden><de> Im Modus „Automatisierte Updates “ werden alle kumulativen Updates angewendet, die für einen Host verfügbar sind.
<G-vec00272-002-s072><apply.anwenden><en> The issue causing the Skip scheduled tasks when running on battery power policy setting to apply to client computers incorrectly has been fixed.
<G-vec00272-002-s072><apply.anwenden><de> Das Problem, bei dem die Richtlinien-Einstellung „Geplante Aufgaben im Akkubetrieb nicht starten“ inkorrekt auf die Client-Computer angewendet wurde, wurde behoben.
<G-vec00272-002-s073><apply.anwenden><en> Pastaba: Many photo effects apply filters with modified values.
<G-vec00272-002-s073><apply.anwenden><de> Bei vielen Fotoeffekten werden Filter mit geänderten Werten angewendet.
<G-vec00272-002-s074><apply.anwenden><en> By carrying out a comprehensive project for a ¿mostly external ¿project owner, students apply and reflect project management tools.
<G-vec00272-002-s074><apply.anwenden><de> Studierende haben anhand eines umfangreichen Projektes für einen - meist FH-externen - Auftraggeber die Projektmanagement-Werkzeuge angewendet und reflektiert.
<G-vec00272-002-s075><apply.anwenden><en> In this way you can define rules that apply only to thirds or fifths of the current chord (see below).
<G-vec00272-002-s075><apply.anwenden><de> Sie können somit Regeln definieren, die nur auf Terzen oder Quinten des aktuellen Akkords angewendet werden (siehe unten).
<G-vec00272-002-s228><apply.auftragen><en> You may not need to apply anything to the underside of your arm, or to your upper arm.
<G-vec00272-002-s228><apply.auftragen><de> Du brauchst möglicherweise nichts auf die Unterseite deines Arms oder auf deinen Oberarm aufzutragen.
<G-vec00272-002-s230><apply.auftragen><en> Use a drywall knife to apply a liberal amount of mud to a seam.
<G-vec00272-002-s230><apply.auftragen><de> {Benutze ein Messer für Trockenbauwände, um eine großzügige Menge Spachtelmasse auf den Saum aufzutragen.
<G-vec00272-002-s231><apply.auftragen><en> Conclusion: SPF 25, pleasant smell, great texture, easy to apply, medium coverage and medium durability.
<G-vec00272-002-s231><apply.auftragen><de> Es macht auch einen großen Fazit: SPF 25, angenehmer Geruch, tolle Textur, leicht aufzutragen, mittlere Deckkraft und mittlere Haltbarkeit.
<G-vec00272-002-s232><apply.auftragen><en> Breathable, impact-resistant and easy to apply.
<G-vec00272-002-s232><apply.auftragen><de> Atmungsaktiv, stoßfest und einfach aufzutragen.
<G-vec00272-002-s233><apply.auftragen><en> It is super easy to apply and dries quickly.
<G-vec00272-002-s233><apply.auftragen><de> Der Nagellack ist sehr einfach aufzutragen und trocknet auch sehr schnell.
<G-vec00272-002-s234><apply.auftragen><en> How to Use Life begins at the end of your comfort zone mehr For best results, we recommend to first apply our vegan base coat, then 2-3 coats of nail polish and finish off with our vegan top coat.
<G-vec00272-002-s234><apply.auftragen><de> Damit Dir Dein Nagellack möglichst lange Freude bereitet, empfehlen wir Dir, zuerst unseren Vegan Base Coat aufzutragen, diesen dann mit 2-3 Schichten des normalen Nagellacks zu ergänzen und zum Abschluss den Vegan Top Coat zu verwenden.
<G-vec00272-002-s236><apply.auftragen><en> For a combination skin it is recommended to apply the PRIMER for dry skin on your dry areas, whereas the PRIMER for oily skin is recommended on Sublime Line (3) Ingredienti
<G-vec00272-002-s236><apply.auftragen><de> Bei Mischhaut empfehlen wir, die GRUNDIERUNG für trockene Haut auf trockene Gesichtsbereiche aufzutragen, und die GRUNDIERUNG für fettige Haut auf jene Hautbereiche, die aufgrund eines Talgüberschusses (T-Bereich) zu erhöhtem Glanz neigen.
<G-vec00272-002-s237><apply.auftragen><en> On an industrial scale, it will be more effective to apply fertilizer under arable land or locally at the time of planting.
<G-vec00272-002-s237><apply.auftragen><de> Im industriellen Maßstab wird es effektiver sein, Dünger unter Ackerland oder lokal zum Zeitpunkt der Pflanzung aufzutragen.
<G-vec00272-002-s238><apply.auftragen><en> In some special cases, it is possible to apply an anesthetic cream before treatment.
<G-vec00272-002-s238><apply.auftragen><de> Es besteht auch die Möglichkeit eine betäubende Salbe vor der Behandlung aufzutragen, um eine schmerzfreie Behandlung zu gewährleisten.
<G-vec00272-002-s239><apply.auftragen><en> These machines offer excellent performance and reliability and are designed to apply any type of coating with different levels of viscosity to semi-finished panels.
<G-vec00272-002-s239><apply.auftragen><de> Diese Anlagen bieten hervorragende Leistung und unübertroffene Zuverlässigkeit und sind in der Lage, alle Lacktypen mit verschiedenen Viskositätsstufen auf Halbzeuge aufzutragen.
<G-vec00272-002-s240><apply.auftragen><en> In the salon we recommend to apply the sealer directly after the eyelash extension.
<G-vec00272-002-s240><apply.auftragen><de> Im Salon empfehlen wir den Versiegler direkt nach der Wimpernverlängerung aufzutragen.
<G-vec00272-002-s241><apply.auftragen><en> The best time to apply the perfume is after a warm shower.
<G-vec00272-002-s241><apply.auftragen><de> Der beste Zeitpunkt um das Parfüm aufzutragen ist nach einer warmen Dusche.
<G-vec00272-002-s242><apply.auftragen><en> At present our staff have all the qualifications and skills to apply anti-corrosion, fireproof, heat-resistant and decorative coatings, which is confirmed by numerous trainings and experience acquired during previous projects.
<G-vec00272-002-s242><apply.auftragen><de> Zur Zeit verfügen unsere Mitarbeiter über alle Qualifikationen und Fähigkeiten, um Korrosionsschutz-, Brandschutz-, Hitzeschutz- und dekorative Beschichtungen aufzutragen, was durch zahlreiche Schulungen und Erfahrungen bei der Durchführung früherer Projekte bestätigt wird.
<G-vec00272-002-s243><apply.auftragen><en> Use a brush to apply a generous amount of the paint.
<G-vec00272-002-s243><apply.auftragen><de> Benutze einen Pinsel, um eine großzügige Menge Farbe aufzutragen.
<G-vec00272-002-s244><apply.auftragen><en> It could be necessary to apply it to the entire table top again.
<G-vec00272-002-s244><apply.auftragen><de> Es könnte notwendig sein, es auf die gesamte Tischplatte wieder aufzutragen.
<G-vec00272-002-s245><apply.auftragen><en> After using the shampoo, it is recommended to apply a rinse aid on the hair, which facilitates drying and combing, gives the hair elasticity.
<G-vec00272-002-s245><apply.auftragen><de> Nach der Verwendung des Shampoos wird empfohlen, einen Klarspüler auf das Haar aufzutragen, der das Trocknen und Kämmen erleichtert und dem Haar Elastizität verleiht.
<G-vec00272-002-s246><apply.auftragen><en> Quick and easy to apply and polish to a dull finish.
<G-vec00272-002-s246><apply.auftragen><de> Schnell und leicht aufzutragen und auf Mattglanz zu polieren.
<G-vec00272-002-s247><apply.beantragen><en> In order to apply for membership please send us the filled application form to mail(at)ahk-baku.de.
<G-vec00272-002-s247><apply.beantragen><de> Um die Mitgliedschaft zu beantragen schicken Sie bitte das ausgefüllte Formular per E-mail mail(at)ahk-baku.de an uns zurück.
<G-vec00272-002-s248><apply.beantragen><en> If you apply by paper, you’ll need to download and print the appropriate forms from the Department of Home Affairs website.
<G-vec00272-002-s248><apply.beantragen><de> Besuche die Website des Department of Home Affairs, um das richtige Visum zu beantragen, das deinen persönlichen Gegebenheiten entspricht.
<G-vec00272-002-s249><apply.beantragen><en> Major projects - individual researchers may apply for grants to locate relevant collections, to arrange their transfer to a suitable local archival home where possible, and to deliver copies to the British Library and a local institution for the benefit of researchers worldwide.
<G-vec00272-002-s249><apply.beantragen><de> Großprojekte – Einzelforscher können Zuschüsse beantragen, um relevante Sammlungen zu finden, ihren Transfer möglichst in ein geeignetes lokales Archiv zu organisieren und die Sammlungen der British Library und einer lokalen Institution zur Nutzung durch internationale Forscher zur Verfügung zu stellen.
<G-vec00272-002-s250><apply.beantragen><en> The International Office also advises graduates who complete internships abroad after they complete their programmes and who wish to apply for funding for an Erasmus+ graduate internship.
<G-vec00272-002-s250><apply.beantragen><de> Das International Office berät auch Absolventinnen und Absolventen, die nach Abschluss des Studiums ein Auslandspraktikum in der EU absolvieren und Fördermittel für ein Erasmus+ Graduiertenpraktikum beantragen möchten.
<G-vec00272-002-s251><apply.beantragen><en> Customers can apply for short-term and long-term loans from 50 to 2,500 Euros, credit cards, and other financial products in just a few minutes online or by mobile.
<G-vec00272-002-s251><apply.beantragen><de> Kunden können via Facebook, SMS, über Mobile-App oder die Kredito24-Portale in wenigen Minuten einen Onlinekredit beantragen.
<G-vec00272-002-s252><apply.beantragen><en> If you are planning on taking maternity/paternity/adoption leave you can apply to keep your BA Silver status even though you take fewer flights during this time.
<G-vec00272-002-s252><apply.beantragen><de> Wenn Sie einen Mutterschafts- oder Vaterschaftsurlaub oder die Adoption eines Kindes planen, können Sie beantragen, Ihren BA Bronze-Status zu behalten, obwohl Sie in dieser Zeit weniger fliegen.
<G-vec00272-002-s253><apply.beantragen><en> Apply for an A1 certificate prior to the employee’s departure.
<G-vec00272-002-s253><apply.beantragen><de> Man muss die Bescheinigung vor der Abreise beantragen.
<G-vec00272-002-s254><apply.beantragen><en> If you apply for legal aid, you will have to supply documentary evidence of your income and assets and documentation about the case (see question 4).
<G-vec00272-002-s254><apply.beantragen><de> Wenn Sie Prozesskostenhilfe beantragen, müssen Sie Belege für Ihr Einkommen und Ihr Vermögen sowie Unterlagen zur Streitsache vorlegen (siehe Frage 4).
<G-vec00272-002-s255><apply.beantragen><en> Any interested person can apply to the family court to obtain non-recognition of a decision given abroad.
<G-vec00272-002-s255><apply.beantragen><de> Betroffene Parteien können beim Familiengericht beantragen, dass eine im Ausland ergangene Entscheidung nicht anerkannt wird.
<G-vec00272-002-s256><apply.beantragen><en> Au Pairs from countries outside the European Union must apply for a visa in their homelands before they can start their adventure in Austria.
<G-vec00272-002-s256><apply.beantragen><de> Au Pairs aus Ländern außerhalb der Europäischen Union müssen ein Visum in ihrem Heimatland beantragen, bevor sie ihr Abenteuer in Österreich beginnen.
<G-vec00272-002-s257><apply.beantragen><en> Ausländerbehörde des Landkreises in Rotenburg (Wümme)) you can apply for the residence permit, since 2005 the residence permit is granted temporary (min. 6 months) and for special purposes (Purpose: Education, Employment, according to international law, humanitarian or political purposes, familial purposes etc..
<G-vec00272-002-s257><apply.beantragen><de> Aufenthaltserlaubnis Die Aufenthaltserlaubnis können Sie hier (Ausländerbehörde des Landkreises in Rotenburg (Wümme)) beantragen, sie wird seit 2005 grundsätzlich nur befristet (auf mindestens 6 Monate) und zweckgebunden erteilt (Zweck: Ausbildung, Erwerbstätigkeit, völkerrechtliche, humanitäre oder politische Gründe, familiäre Gründe etc..
<G-vec00272-002-s258><apply.beantragen><en> The supplier is obligated then to apply for a formal acceptance, of which a report must be drawn up and signed by both parties.
<G-vec00272-002-s258><apply.beantragen><de> Er ist verpflichtet, sodann eine förmliche Abnahme zu beantragen, über die ein Protokoll anzufertigen und von beiden Parteien zu unterzeichnen ist.
<G-vec00272-002-s259><apply.beantragen><en> Finally, when classifying the data, it should be borne in mind that many academic players in the knowledge market decide – as do many small and medium-sized companies – not to apply for protection of their intellectual property rights because of the high costs involved in patent applications, the issue of patents, and also the enforcement of patent rights.
<G-vec00272-002-s259><apply.beantragen><de> Schließlich bleibt bei der Einordnung der Daten zu beachten, dass aufgrund der hohen Kosten einer Patentanmeldung, -erteilung und auch Patentrechtsdurchsetzung sich viele akademisch orientierte Wissensakteure ähnlich wie Mittelständler dazu entscheiden, keinen Schutz auf ihre intellektuellen Eigentumsrechte zu beantragen.
<G-vec00272-002-s260><apply.beantragen><en> The sales conditions associated with the rate on another Internet site must be the same as the sales conditions of the rate booked on AccorHotels Internet sites in order for the Best Price Guarantee to apply.
<G-vec00272-002-s260><apply.beantragen><de> Schritt 1 Füllen Sie das Online-Formular aus und fügen Sie die erforderlichen Belege (Screenshot des günstigeren Tarifs und die dazugehörigen Verkaufsbedingungen) bei, um die Inanspruchnahme der Bestpreisgarantie zu beantragen.
<G-vec00272-002-s261><apply.beantragen><en> Getting a tourist Visa After You got an invitation, You need to submit it to the Russian consulate and apply for a visa to Russia.
<G-vec00272-002-s261><apply.beantragen><de> Getting ein Touristenvisum, nachdem Sie eine Einladung bekam, müssen Sie es auf das russische Konsulat einreichen und beantragen ein Visum für Russland.
<G-vec00272-002-s262><apply.beantragen><en> Citizens of most countries can apply for an Electronic Travel Authority (ETA) visa on-line or through the airline they booked their flight with.
<G-vec00272-002-s262><apply.beantragen><de> Die Bürger der meisten Länder können ein Electronic Travel Authority (ETA) Visum on-line oder über die Fluggesellschaft wo sie ihren Flug gebucht haben, beantragen.
<G-vec00272-002-s263><apply.beantragen><en> Learn more about My Bizerba products for which you can apply for training in the product catalog or directly at your service contact person.
<G-vec00272-002-s263><apply.beantragen><de> Erfahren Sie mehr zu den My Bizerba Produkten zu denen Sie Ihre Schulung beantragen können im Produktkatalog oder direkt bei Ihrem Service-Ansprechpartner.
<G-vec00272-002-s264><apply.beantragen><en> Everyone wanting to open a bank account, apply for a residence permit, get a health insurance, obtain a tax ID, subscribe to internet, etc.
<G-vec00272-002-s264><apply.beantragen><de> Alle, die ein Bankkonto eröffnen, eine Aufenthaltsgenehmigung beantragen, sich krankenversichern, eine Steuer-ID beantragen, Internet bestellen möchten usw.
<G-vec00272-002-s265><apply.beantragen><en> Young people from 18 to 26 years old can apply for an Au Pair visa to Germany.
<G-vec00272-002-s265><apply.beantragen><de> Junge Menschen von 18 bis 26 Jahren können ein Au Pair Visum für Deutschland beantragen.
<G-vec00272-002-s285><apply.bewerben><en> Joe: Well, I'll still apply, and then we'll see whether the company even wants me, and if yes, how much they're ready to pay as a salary.
<G-vec00272-002-s285><apply.bewerben><de> Joe: Na ja, ich werde mich eben bewerben, und dann sehen wir ja, ob die Firma mich überhaupt will, und wenn ja, wie viel Gehalt sie bereit ist zu zahlen.
<G-vec00272-002-s286><apply.bewerben><en> To help us be GDPR-compliant, please use our online form to apply (click the position you are interested in, then "Apply now").
<G-vec00272-002-s286><apply.bewerben><de> Um eine GDPR-konforme Datenverarbeitung zu gewährleisten, bitten wir dich, unser Onlineformular für deine Bewerbung zu benutzen (dafür wählst du die entsprechende Stelle aus und klickst dann auf "Jetzt bewerben").
<G-vec00272-002-s287><apply.bewerben><en> The Jury was impressed by how in Herzogenaurach, instead of creative chaos, a fresh supply of ideas is very systematically generated – for example by providing an innovation budget, for which project teams can apply internally at any time.
<G-vec00272-002-s287><apply.bewerben><de> Die Jury war beeindruckt, wie in Herzogenaurach statt kreativem Chaos ganz systematisch Ideennachschub generiert wird – zum Beispiel durch das Bereitstellen eines Innovationsetats, um den sich Projektteams intern jederzeit bewerben können.
<G-vec00272-002-s288><apply.bewerben><en> I guess they thought I had some good ideas because I was invited to apply for a design position that day.
<G-vec00272-002-s288><apply.bewerben><de> Sie fanden meine Ideen wohl nicht schlecht, denn am gleichen Tag wurde ich ermuntert, mich auf eine Position als Entwickler zu bewerben.
<G-vec00272-002-s289><apply.bewerben><en> Online job applications / publication of job advertisements We offer you the opportunity to apply for jobs with our company via our website.
<G-vec00272-002-s289><apply.bewerben><de> Wir bieten Ihnen die Möglichkeit an, sich bei uns über unseren Internetauftritt bewerben zu können.
<G-vec00272-002-s290><apply.bewerben><en> Alternatively, uni-assist offers the so-called VPD procedure. uni-assist issues a certificate ("Vorpruefungsdokumentation/ VPD) with which one can apply directly to the university.
<G-vec00272-002-s290><apply.bewerben><de> Für bestimmte Hochschulen stellt uni-assist dem Bewerber ein Zertifikat (eine Vorprüfungsdokumentation/ VPD) aus, mit dem er sich direkt an der Hochschule bewerben kann.
<G-vec00272-002-s291><apply.bewerben><en> Highly qualified scholars, who are distinguished by outstanding achievements in research and teaching, are encouraged to apply.
<G-vec00272-002-s291><apply.bewerben><de> Um die Forschungsstipendien können sich hochqualifizierte, durch herausragende Leistungen in Forschung und Lehre ausgewiesene Gelehrte bewerben.
<G-vec00272-002-s292><apply.bewerben><en> You can also apply for one of our double degree programmes or take part in a course at the HWR Berlin Summer & Winter School.
<G-vec00272-002-s292><apply.bewerben><de> Zudem können Sie sich für einen unserer Doppelabschlussprogramme bewerben oder an einem Kurs der HWR Berlin Winter & Summer School teilnehmen.
<G-vec00272-002-s293><apply.bewerben><en> But the government now claims that only the 189 people formally listed as applicants in that case, and their children up to the age of 18, are allowed free passage into the reserve – and that everyone else must apply for a one-month access permit.
<G-vec00272-002-s293><apply.bewerben><de> Doch die Regierung vertritt die Ansicht, dass nur die 189 offiziell aufgeführten Kläger im Fall sowie deren Kinder bis zum Alter von 16 Jahren, freien Zutritt zum CKGR haben – und dass alle anderen sich für einmonatige Genehmigungen bewerben müssen.
<G-vec00272-002-s294><apply.bewerben><en> The best way to proceed is different from case to case. More and more universities offer doctorate's programmes and graduate's courses that you can apply for.
<G-vec00272-002-s294><apply.bewerben><de> Immer mehr Hochschulen bieten aber mittlerweile auch Promotionsprogramme und Graduiertenkollegs an, auf die man sich bei einem Promotionsvorhaben bewerben kann.
<G-vec00272-002-s295><apply.bewerben><en> There are people who have been at home in the UK for decades who are now forced to apply if they want to stay.
<G-vec00272-002-s295><apply.bewerben><de> Es gibt Menschen, die seit Jahrzehnten im Vereinigten Königreich leben und sich jetzt bewerben müssen, wenn sie bleiben wollen.
<G-vec00272-002-s296><apply.bewerben><en> If everything fits – breeder, kennel, and health – it’s up to you whether you like the bitch and chosen stud dog visually, if you put your name on the waiting list and you wish to apply for a puppy from this litter.
<G-vec00272-002-s296><apply.bewerben><de> Wenn alles passt – Züchter, Zuchtstätte, Wesen und Gesundheit – liegt es an Ihnen, ob Ihnen die Hündin und der ausgewählte Deckrüde optisch gefallen, ob Sie sich auf die Warteliste setzen lassen und Sie sich um einen Welpen aus dieser Verpaarung bewerben möchten.
<G-vec00272-002-s297><apply.bewerben><en> Meet some of our brand ambassadors and click on “Apply Now” to learn more about the program and to submit your application.
<G-vec00272-002-s297><apply.bewerben><de> Treffe einige unserer Markenbotschafter und klicke auf „Jetzt bewerben“, um mehr über das Programm zu erfahren und Deine Bewerbung einzureichen.
<G-vec00272-002-s298><apply.bewerben><en> If a degree programme is subject to local admission restrictions (numerus clausus degree programme) you must apply to the relevant university by a set deadline.
<G-vec00272-002-s298><apply.bewerben><de> Ist ein Studiengang örtlich zulassungsbeschränkt, also ein sogenannter NC-Studiengang, müssen Sie sich fristgerecht bei der betreffenden Hochschule bewerben.
<G-vec00272-002-s299><apply.bewerben><en> You can apply online via Summerpreneurship 2017 at Impact Hub Zurich.
<G-vec00272-002-s299><apply.bewerben><de> Bewerben kannst Du Dich via Summerpreneurship 2017 bei Impact Hub Zurich.
<G-vec00272-002-s300><apply.bewerben><en> Important: please be advised that participating and completing the Welcome@FU courses DOES NOT secure your place at the FU Berlin for a degree program. After completing our courses, you must apply to the university degree program as a regular international student.
<G-vec00272-002-s300><apply.bewerben><de> Bitte beachten Sie: Nach dem erfolgreichen Abschluss des Deutsch- oder Vorbereitungskurses müssen Sie sich für das Fachstudium an der FU Berlin bewerben, das heißt, ein Studienplatz ist Ihnen nicht sicher.
<G-vec00272-002-s301><apply.bewerben><en> To overcome these deficits medical doctors are also welcome to apply to the RegenerAging network for a fulltime postdoc free of clinical duties.
<G-vec00272-002-s301><apply.bewerben><de> Um diese Lücke zu schließen, können sich auch Ärzte beim RegenerAging-Netzwerk um eine Vollzeitstelle als Postdoc bewerben, um frei von klinischen Pflichten forschen zu können.
<G-vec00272-002-s302><apply.bewerben><en> If you want to apply for several positions with us, you can use the information from your profile and adapt it for each job.
<G-vec00272-002-s302><apply.bewerben><de> Wenn Sie sich für mehrere Stellen bei uns bewerben möchten, können Sie hierzu Ihre einmal angelegten Daten verwenden und für jede Stelle individuell anpassen.
<G-vec00272-002-s303><apply.bewerben><en> Are you interested and do want to apply for this role, please fill out your application via the apply button below and contact Laura Hoekstra.
<G-vec00272-002-s303><apply.bewerben><de> Wenn Sie Interesse an dieser Position haben und sich bewerben wollen, füllen Sie das Bewerbungsformular aus, indem Sie auf die Schaltfläche unten drücken oder nehmen Sie Kontakt mit Anja Paetel auf.
<G-vec00272-002-s494><apply.finden><en> Apply now for Corporate Banking jobs in Perpignan. 1 positions are currently open at eFinancialCareers.
<G-vec00272-002-s494><apply.finden><de> Finden Sie 0 verfügbare(n) Corporate Banking-Job(s) bei PDJ Search auf eFinancialCareers.
<G-vec00272-002-s495><apply.finden><en> The Government of Canada’s official website to apply for an eTA. It only costs CAD.
<G-vec00272-002-s495><apply.finden><de> Informationen in deutscher Sprache und den Link zur Beantragung der eTA finden Sie auf der Seite des Government of Canada.
<G-vec00272-002-s496><apply.finden><en> Apply now for Asset Management jobs at Michael Page Financial Services..
<G-vec00272-002-s496><apply.finden><de> Finden Sie 0 verfügbare(n) Trading-Job(s) bei Michael Page auf eFinancialCareers.
<G-vec00272-002-s497><apply.finden><en> Apply now for Compliance/Legal jobs at Jefferies. 0 positions are currently open at eFinancialCareers.
<G-vec00272-002-s497><apply.finden><de> Finden Sie 246 verfügbare(n) Compliance / Recht Job(s) in Dorking auf eFinancialCareers.
<G-vec00272-002-s498><apply.finden><en> Apply now for jobs at Investigo Strategy. 0 positions are currently open at eFinancialCareers.
<G-vec00272-002-s498><apply.finden><de> Finden Sie 0 aktuelle(n) Job(s) bei Investigo Strategy auf eFinancialCareers, das Karriereportal für Finanzprofis.
<G-vec00272-002-s499><apply.finden><en> Apply now for Information Technology jobs at DHi. 0 positions are currently open at eFinancialCareers.
<G-vec00272-002-s499><apply.finden><de> Finden Sie 0 verfügbare(n) Information Technology-Job(s) bei Tradeweb LLC auf eFinancialCareers.
<G-vec00272-002-s500><apply.finden><en> Apply now for Risk Management jobs in Brighton. 2 positions are currently open at eFinancialCareers.
<G-vec00272-002-s500><apply.finden><de> Finden Sie 2 verfügbare(n) Asset Management-Job(s) bei Venquis auf eFinancialCareers.
<G-vec00272-002-s501><apply.finden><en> Apply now for jobs at innogy Innovation Hub. 0 positions are currently open at eFinancialCareers.
<G-vec00272-002-s501><apply.finden><de> Finden Sie 0 aktuelle(n) Job(s) bei innogy Innovation Hub auf eFinancialCareers, das Karriereportal für Finanzprofis.
<G-vec00272-002-s503><apply.finden><en> Apply now for Graduates & Internships jobs at Prometeia.
<G-vec00272-002-s503><apply.finden><de> Finden Sie 0 verfügbare(n) Absolventen & Praktika-Job(s) bei Prometeia auf eFinancialCareers.
<G-vec00272-002-s504><apply.finden><en> Apply now for Research jobs at Moody's. 113 positions are currently open at eFinancialCareers.
<G-vec00272-002-s504><apply.finden><de> Finden Sie 61 verfügbare(n) Compliance / Recht-Job(s) bei Moody's auf eFinancialCareers.
<G-vec00272-002-s505><apply.finden><en> Apply now for Information Technology jobs at Mizuho Bank Ltd. 0 positions are currently open at eFinancialCareers.
<G-vec00272-002-s505><apply.finden><de> Finden Sie 0 verfügbare(n) Accounting-Job(s) bei Mizuho Bank Ltd auf eFinancialCareers.
<G-vec00272-002-s506><apply.finden><en> Apply now for jobs at Tradeweb LLC. 36 positions are currently open at eFinancialCareers.
<G-vec00272-002-s506><apply.finden><de> Finden Sie 36 aktuelle(n) Job(s) bei Tradeweb LLC auf eFinancialCareers, das Karriereportal für Finanzprofis.
<G-vec00272-002-s507><apply.finden><en> Apply now for Corporate Banking jobs at Consorsbank. 0 positions are currently open at eFinancialCareers.
<G-vec00272-002-s507><apply.finden><de> Finden Sie 0 verfügbare(n) Information Technology-Job(s) bei Consorsbank auf eFinancialCareers.
<G-vec00272-002-s508><apply.finden><en> Apply now for Accounting & Finance jobs at Jon Michel Executive Search.
<G-vec00272-002-s508><apply.finden><de> Finden Sie 0 verfügbare(n) Kredit-Job(s) bei Jon Michel Executive Search auf eFinancialCareers.
<G-vec00272-002-s509><apply.finden><en> Apply now for Research jobs in CT-Stamford.
<G-vec00272-002-s509><apply.finden><de> Finden Sie 0 verfügbare(n) Research Job(s) in CT-Stamford auf eFinancialCareers.
<G-vec00272-002-s510><apply.finden><en> Apply now for Risk Management jobs in CT-Hartford.
<G-vec00272-002-s510><apply.finden><de> Finden Sie 0 verfügbare(n) Accounting Job(s) in CT-Hartford auf eFinancialCareers.
<G-vec00272-002-s511><apply.finden><en> Apply now for Accounting & Finance jobs at Deutsche Börse AG.
<G-vec00272-002-s511><apply.finden><de> Finden Sie 0 verfügbare(n) Accounting-Job(s) bei Deutsche Börse AG auf eFinancialCareers.
<G-vec00272-002-s512><apply.finden><en> Apply now for Accounting & Finance jobs at Alexander Ash Consulting. 13 positions are currently open at eFinancialCareers.
<G-vec00272-002-s512><apply.finden><de> Finden Sie 13 verfügbare(n) Accounting-Job(s) bei Alexander Ash Consulting auf eFinancialCareers.
<G-vec00272-002-s589><apply.gelten><en> By default, modifications made by this command apply only to the rendered images; they are not stored in the data source (internal DOM tree) and are lost when the picture is erased by programming or when the form is closed.
<G-vec00272-002-s589><apply.gelten><de> Standardmäßig gelten die durch diesen Befehl gemachten Änderungen nur für die gerenderten Bilder; sie werden nicht in der Datenquelle gespeichert (interner DOM Baum) und gehen verloren, wenn das Bild per Programmierung entfernt wird oder wenn das Formular geschlossen wird.
<G-vec00272-002-s590><apply.gelten><en> These Rules of Procedure shall apply in proceedings before the Enlarged Board of Appeal under Article 23, paragraph 1 EPC, first sentence, EPC, Article 112 EPC, and Article 112a EPC.
<G-vec00272-002-s590><apply.gelten><de> In den Verfahren vor der Großen Beschwerdekammer gemäß Artikel 23 Absatz 1 Satz 1 EPÜ, Artikel 112 EPÜ und Artikel 112a EPÜ gelten die Vorschriften dieser Verfahrensordnung.
<G-vec00272-002-s591><apply.gelten><en> If the object of a sale is deficient, the legal provisions shall apply.
<G-vec00272-002-s591><apply.gelten><de> Ist die Kaufsache mangelhaft, gelten die Vorschriften der gesetzlichen Mängelhaftung.
<G-vec00272-002-s592><apply.gelten><en> In this instance, agreements with the host or organizer apply.
<G-vec00272-002-s592><apply.gelten><de> Hier gelten die Vereinbarungen mit dem Veranstalter oder Organisator.
<G-vec00272-002-s593><apply.gelten><en> For bidirectional types (add suffix “C” or “CA”), electrical characteristics apply in both directions.
<G-vec00272-002-s593><apply.gelten><de> Für bidirektionale Dioden (ergänze Suffix “C” oder “CA”) gelten die elektrischen Werte in beiden Richtungen.
<G-vec00272-002-s594><apply.gelten><en> The conditions under www.sbb.ch also apply.
<G-vec00272-002-s594><apply.gelten><de> Des Weiteren gelten die Konditionen unter www.sbb.ch.
<G-vec00272-002-s595><apply.gelten><en> 2. Unless otherwise specified, Articles 10 to 15, 19, 20 and 25 to 27 shall apply only to products originating in the Contracting Parties.
<G-vec00272-002-s595><apply.gelten><de> (2) Soweit nichts anderes bestimmt ist, gelten die Artikel 10 bis 15, 19, 20, 25, 26 und 27 nur für Ursprungswaren der Vertragsparteien.
<G-vec00272-002-s596><apply.gelten><en> Free shipping and fabric discounts apply to all curtain orders.
<G-vec00272-002-s596><apply.gelten><de> Für alle Vorhangaufträge gelten die kostenlosen Versand- und Stoffrabatte.
<G-vec00272-002-s597><apply.gelten><en> We review the requirement every two years, and statutory archiving duties also apply.
<G-vec00272-002-s597><apply.gelten><de> Wir überprüfen die Erforderlichkeit alle zwei Jahre; Ferner gelten die gesetzlichen Archivierungspflichten.
<G-vec00272-002-s598><apply.gelten><en> For all orders in our online shop following terms and conditions shall apply. 2.
<G-vec00272-002-s598><apply.gelten><de> Für alle Bestellungen über unseren Online-Shop durch Verbraucher und Unternehmer gelten die nachfolgenden AGB.
<G-vec00272-002-s599><apply.gelten><en> 888casino Bonus policy terms and conditions apply.
<G-vec00272-002-s599><apply.gelten><de> Es gelten die Allgemeinen Bonusregelungen von 888casino.
<G-vec00272-002-s600><apply.gelten><en> If DaWanda organises competitions, the Terms and Conditions for competitions apply; DaWanda advises participants of this in advance.
<G-vec00272-002-s600><apply.gelten><de> Veranstaltet DaWanda Gewinnspiele, gelten die AGB für Gewinnspiele, über die DaWanda die Teilnehmer vorab informiert.
<G-vec00272-002-s601><apply.gelten><en> When using colour cameras, similar rules apply.
<G-vec00272-002-s601><apply.gelten><de> Bei der Verwendung von Farbkameras gelten die gleichen Regeln.
<G-vec00272-002-s602><apply.gelten><en> Otherwise, statutory provisions apply.
<G-vec00272-002-s602><apply.gelten><de> Im Übrigen gelten die gesetzlichen Bestimmungen.
<G-vec00272-002-s603><apply.gelten><en> To Win Division - NBA tie-break rules apply.
<G-vec00272-002-s603><apply.gelten><de> Division Sieger: Bei Gleichstand gelten die Tie-Break-Regeln der NBA.
<G-vec00272-002-s604><apply.gelten><en> European regulation and the regional regulation shall apply to the main regions Scotland and Ireland.
<G-vec00272-002-s604><apply.gelten><de> Für die Hauptregionen Schottland und Irland gelten die europäischen Verordnung sowie die regionale Verordnung.
<G-vec00272-002-s606><apply.gelten><en> In all other cases, juridical archiving obligations apply.
<G-vec00272-002-s606><apply.gelten><de> Ansonsten gelten die gesetzlichen Archivierungspflichten.
<G-vec00272-002-s607><apply.gelten><en> These are release tags, which have two effects. When set on a bug, the bug can only affect the particular release (though it may also affect other releases if other release tags are set) but otherwise normal buggy/fixed/absent rules apply.
<G-vec00272-002-s607><apply.gelten><de> Dies sind Release-abhängige Markierungen, die zwei verschiedene Auswirkungen haben: Wenn sie für einen Fehler gesetzt werden, ist dieser Fehler nur noch für die entsprechende Veröffentlichung relevant (obwohl es möglich ist, dass er auch andere Veröffentlichungen betrifft, wenn deren Markierungen gesetzt sind), aber ansonsten gelten die normalen fehlerhaft/behoben/nicht-zutreffend-Regeln.
<G-vec00272-002-s665><apply.setzen><en> We thereby apply investment strategies that have proven to function well and have their origins in academic research.
<G-vec00272-002-s665><apply.setzen><de> Dazu setzen wir Anlagestrategien ein, die nachweislich gut funktionieren und ihren Ursprung in der wissenschaftlichen Forschung haben.
<G-vec00272-002-s666><apply.setzen><en> On request, we are also able to apply other established loudness standards, if they are suitable for the music.
<G-vec00272-002-s666><apply.setzen><de> Auf Wunsch setzen wir beim Mastering auch andere etablierte Lautheitsstandards um, sofern diese für die jeweilige Musik geeignet ist.
<G-vec00272-002-s667><apply.setzen><en> We know current sensor technology and apply sensors wisely.
<G-vec00272-002-s667><apply.setzen><de> Wir kennen die aktuellste Sensorik und setzen diese optimal ein.
<G-vec00272-002-s668><apply.setzen><en> Together we apply our passions, talents and ideas.
<G-vec00272-002-s668><apply.setzen><de> Gemeinsam setzen wir unsere Leidenschaften, Talente und Ideen ein.
<G-vec00272-002-s669><apply.setzen><en> Refugees frequently know little about formats like resumes and cover letters, while German employers apply standards based on German educational levels.
<G-vec00272-002-s669><apply.setzen><de> Geflüchtete kennen oft Formate wie Lebenslauf und Anschreiben nicht, und Arbeitgeber etwa setzen Standards deutscher Bildungsabschlüsse voraus.
<G-vec00272-002-s670><apply.setzen><en> We apply cookies for the distribution of advertising and for counting page visits, in particular.
<G-vec00272-002-s670><apply.setzen><de> Wir setzen Cookies insbesondere für die Verteilung von Werbung und für die Zählung von Seitenaufrufen ein.
<G-vec00272-002-s671><apply.setzen><en> We test thousands of different components each year and we refer to the corresponding sets of regulations and apply them in a targeted manner each and every day.
<G-vec00272-002-s671><apply.setzen><de> Jährlich prüfen wir tausende unterschiedlicher Bauteile, täglich sichten wir die entsprechenden Regelwerke und setzen sie zielgerichtet um.
<G-vec00272-002-s672><apply.setzen><en> We have concluded a contract relating to contract data processing with Google and fully apply the strict requirements of German data protection authorities when using Google Analytics.
<G-vec00272-002-s672><apply.setzen><de> Wir haben mit Google einen Vertrag zur Auftragsverarbeitung abgeschlossen und setzen die strengen Vorgaben der deutschen Datenschutzbehörden bei der Nutzung von Google Analytics vollständig um.
<G-vec00272-002-s673><apply.setzen><en> Sabine: You yourself apply yoga practices in your therapy sessions.
<G-vec00272-002-s673><apply.setzen><de> Sabine: Sie selbst setzen in Ihren Therapien ebenfalls Yoga ein.
<G-vec00272-002-s674><apply.setzen><en> You can apply a filter to limit the records that are displayed to only those that match your criteria.
<G-vec00272-002-s674><apply.setzen><de> Sie können einen Filter setzen, um eine begrenzte Anzahl von Datensätzen anzuzeigen, wenn Sie nur an Datensätzen interessiert sind, die bestimmte Kriterien und Vergleichsoperatoren erfüllen.
<G-vec00272-002-s675><apply.setzen><en> With our master’s degree in nursing, you will make significant contributions to the field, apply your own expanded expertise to your nursing practice and help shape the development of the profession.
<G-vec00272-002-s675><apply.setzen><de> Pflege Mit dem Master-Abschluss in Pflege leisten Sie einen großen Beitrag in der Pflegewissenschaft, setzen Ihre erweiterte, fachliche Expertise in der Praxis ein und gestalten die Entwicklung der Pflege aktiv mit.
<G-vec00272-002-s676><apply.setzen><en> During construction of warehouses in Moscow and the Moscow region we apply the latest technologies, equipment and materials, process all stages of construction.
<G-vec00272-002-s676><apply.setzen><de> Beim Bau von Lagergebäuden in Moskau und Moskauer Gebiet setzen wir die modernsten Technologien, Ausrüstung, Maschinen und Baustoffe ein und führen alle notwendigen Bauarbeiten aus.
<G-vec00272-002-s677><apply.setzen><en> We apply temporary and permanent cookies, i.e. small files, that are saved to the device of the user (for explanation regarding the term and the function, please see the last chapter of this privacy policy).
<G-vec00272-002-s677><apply.setzen><de> Wir setzen temporäre und permanente Cookies, d.h. kleine Dateien, die auf den Geräten der Nutzer gespeichert werden ein (Erklärung des Begriffs und der Funktion, siehe letzter Abschnitt dieser Datenschutzerklärung).
<G-vec00272-002-s678><apply.setzen><en> We apply the latest advances in carbon fiber technology to the manufacture of tripods, ball heads and other accessories.
<G-vec00272-002-s678><apply.setzen><de> Wir setzen die neuesten Erkenntnisse der Kohlestofffasertechnologie bei der Fertigung von Stativen, Kugelköpfen und anderem Zubehör ein.
<G-vec00272-002-s679><apply.setzen><en> You will need to apply a maximum of knowledge in the field of design and creativity for the visual separation of zones while maintaining a single style in the interior.
<G-vec00272-002-s679><apply.setzen><de> Es wird notwendig sein, ein Maximum an Wissen auf dem Gebiet von Design und kreativen Fähigkeiten für die visuelle Trennung von Zonen mit der Bewahrung eines einheitlichen Stils in einem Interieur zu setzen.
<G-vec00272-002-s680><apply.setzen><en> Those machines apply a casting process whereat the melt is pressed from the bottom to the mould via a riser tube.
<G-vec00272-002-s680><apply.setzen><de> Diese Anlagen setzen ein Gießverfahren ein, bei dem die Schmelze über ein Steigrohr von unten in die Kokille gepresst wird.
<G-vec00272-002-s681><apply.setzen><en> With your help, we can jointly advance the vision of digital transformation and apply your skills and experience where they are needed.
<G-vec00272-002-s681><apply.setzen><de> Mit Ihrer Hilfe bringen wir die Vision der digitalen Transformation gemeinsam voran und setzen Ihre Kompetenzen und Erfahrungen da ein, wo sie gebraucht werden.
<G-vec00272-002-s682><apply.setzen><en> We also apply tracking pixels on our websites.
<G-vec00272-002-s682><apply.setzen><de> Zudem setzen wir Trackingpixel auf unserer Website ein.
<G-vec00272-002-s683><apply.setzen><en> If possible, we apply complex forms of anesthesia, combining techniques of local anesthesia, regional anesthesia (blocking single nerves, plexuses, central blockage) with general anesthesia.
<G-vec00272-002-s683><apply.setzen><de> Wir setzen nach Möglichkeit zusammengesetzte Anästhesieformen ein, indem wir Techniken der Lokalanästhesie (Blockierung einzelner Nerven, Nervenstränge, zentrale Blockierung) mit Vollanästhesie (Narkose) kombinieren.
<G-vec00272-002-s323><apply.sich_bewerben><en> Apply for one of the job openings listed below or send us a speculative application by email.
<G-vec00272-002-s323><apply.sich_bewerben><de> Bewerben Sie sich auf eine der unten ausgeschriebenen Stellen oder senden Sie uns Ihre Initiativbewerbung per Mail.
<G-vec00272-002-s324><apply.sich_bewerben><en> Since transparency and accessibility of informationis very important for any depositor, apply to the PF and learn about personal pension savings at any time.
<G-vec00272-002-s324><apply.sich_bewerben><de> Da Transparenz und Zugänglichkeit von Informationenist für jeden Einleger sehr wichtig, bewerben Sie sich bei der PK und erfahren Sie jederzeit mehr über die persönliche Altersvorsorge.
<G-vec00272-002-s325><apply.sich_bewerben><en> Make a fresh start in your career - apply today and convince our customer in Bremen of your skills.
<G-vec00272-002-s325><apply.sich_bewerben><de> Starten Sie beruflich neu durch - bewerben Sie sich noch heute und überzeugen Sie unseren Kunden in Bremen von Ihrem Können.
<G-vec00272-002-s326><apply.sich_bewerben><en> shapourbakhtiar.com, find and apply to jobs that match your skills, and connect with people to advance your career.
<G-vec00272-002-s326><apply.sich_bewerben><de> Erfahren Sie mehr über PRINTSTORE GROUP, finden und bewerben Sie sich um Jobs, die zu Ihren Fähigkeiten passen, und vernetzen Sie sich mit Personen, die Sie beruflich voranbringen.
<G-vec00272-002-s327><apply.sich_bewerben><en> Please apply here on „ITsax.de“ with the „Apply Now“ link/button at the top Open-Source Software
<G-vec00272-002-s327><apply.sich_bewerben><de> Bitte bewerben Sie sich hier auf „ITsax.de“ mit dem „Jetzt bewerben“ Link/Button rechts oben.
<G-vec00272-002-s328><apply.sich_bewerben><en> You can find out more about the various possibilities on our website and directly apply.
<G-vec00272-002-s328><apply.sich_bewerben><de> Informieren Sie sich auf unseren Seiten über die vielfältigen Möglichkeiten oder bewerben Sie sich direkt.
<G-vec00272-002-s329><apply.sich_bewerben><en> Ms. N. Ponzetta would be delighted to receive your application. Please apply via our Career Portal.
<G-vec00272-002-s329><apply.sich_bewerben><de> Frau F. Zimmermann freut sich über Ihre Bewerbung: Bitte bewerben Sie sich über unser Karriere-Portal.
<G-vec00272-002-s330><apply.sich_bewerben><en> If so, apply now to become a partner of the Healthy Workplaces for All Ages Campaign.
<G-vec00272-002-s330><apply.sich_bewerben><de> Wenn dem so ist, bewerben Sie sich jetzt als Partner der Kampagne „Gesunde Arbeitsplätze – für jedes Alter“.
<G-vec00272-002-s331><apply.sich_bewerben><en> If you’re qualified, but your desired job is not on the list, apply anyway by filling out our online application form.
<G-vec00272-002-s331><apply.sich_bewerben><de> Wenn Sie qualifiziert sind, Ihr gewünschter Job jedoch nicht auf der Liste steht, bewerben Sie sich trotzdem über unser Online-Bewerbungsformular.
<G-vec00272-002-s332><apply.sich_bewerben><en> Introduce yourself to us and apply through our application assistant with your complete application documents.
<G-vec00272-002-s332><apply.sich_bewerben><de> Stellen Sie sich vor und bewerben Sie sich über unseren Bewerbungsassistenten mit Ihren vollständigen Unterlagen.
<G-vec00272-002-s333><apply.sich_bewerben><en> Please apply here on „ITbawü.de“ with the „Apply Now“ link/button at the top right.
<G-vec00272-002-s333><apply.sich_bewerben><de> Bitte bewerben Sie sich hier auf „IThanse.de“ mit dem „Jetzt bewerben“ Link/Button rechts oben.
<G-vec00272-002-s334><apply.sich_bewerben><en> If you are not enrolled yet, please apply for a study place at the University of Mannheim.
<G-vec00272-002-s334><apply.sich_bewerben><de> Bitte bewerben Sie sich regulär bei der Universität Mannheim um einen Studienplatz, falls Sie nicht bereits eingeschrieben sind.
<G-vec00272-002-s335><apply.sich_bewerben><en> Upload your resume, and apply to schools online, after a phone screening with Footprints recruiters they will introduce you to the hiring schools, and after another interview, if you receive a job offer they will help you with the visa paperwork and moving abroad process.
<G-vec00272-002-s335><apply.sich_bewerben><de> Laden Sie Ihren Lebenslauf hoch und bewerben Sie sich bei Schulen online, nach einem Telefon-Screening mit Footprints-Rekrutierern werden sie Ihnen die Mietschulen vorstellen, und nach einem weiteren Gespräch, wenn Sie ein Stellenangebot erhalten, werden sie Ihnen bei der Bearbeitung der Visumformalitäten und dem Umzug ins Ausland helfen.
<G-vec00272-002-s336><apply.sich_bewerben><en> Apply for current jobs as Project Engineer, Technical Draftsman, Sales Engineer or Service Technician.
<G-vec00272-002-s336><apply.sich_bewerben><de> Bewerben Sie auf aktuelle Jobs als Projektingenieur, Technischer Zeichner, Vertriebsingenieur oder Servicetechniker.
<G-vec00272-002-s337><apply.sich_bewerben><en> Please apply here on „OFFICEmitte.de“ with the „Apply Now“ link/button at the top Schumacher, Head of Human Resources.
<G-vec00272-002-s337><apply.sich_bewerben><de> Bitte bewerben Sie sich hier auf „OFFICEmitte.de“ mit dem „Jetzt bewerben“ Link/Button rechts oben.
<G-vec00272-002-s338><apply.sich_bewerben><en> Apply for many industries like mold, motor, aerospace, national defense, electronic, wood, precision working, etc.
<G-vec00272-002-s338><apply.sich_bewerben><de> Bewerben Sie sich für viele Branchen wie Werkzeug, Motor, Luft-und Raumfahrt, Verteidigung, Elektronik, Holz-, Präzisions-Arbeiten, etc.
<G-vec00272-002-s339><apply.sich_bewerben><en> If you would like to become a part of Kuhn Special Steel, please feel free to find out more and apply via our website.
<G-vec00272-002-s339><apply.sich_bewerben><de> Wenn Sie ein Teil von Kuhn Edelstahl werden wollen, dann informieren und bewerben Sie sich gerne über unsere Homepage.
<G-vec00272-002-s340><apply.sich_bewerben><en> Apply not pc-retter.com with protected keywords or misspellings of our competitors, foreign designers and brands.
<G-vec00272-002-s340><apply.sich_bewerben><de> Bewerben Sie pc-retter.com nicht mit geschützten Keywords oder Falschschreibweisen unserer Mitbewerber, fremder Designer und Marken.
<G-vec00272-002-s341><apply.sich_bewerben><en> The best way to apply for the PhD program is to send your unsolicited application directly to the company of your choice or to apply for one of our PhD positions.
<G-vec00272-002-s341><apply.sich_bewerben><de> Am besten bewerben Sie sich initiativ beim Unternehmen Ihrer Wahl oder auf eine unserer freien Promotionsstellen.
<G-vec00272-002-s741><apply.tragen><en> When finished, rinse with cool water, pat dry and apply your favorite moisturizer.
<G-vec00272-002-s741><apply.tragen><de> Spüle danach den Rasierer mit kaltem Wasser ab, tupfe die Zone trocken und trage deine bevorzugte Feuchtigkeitspflege auf.
<G-vec00272-002-s742><apply.tragen><en> Apply a natural oil, such as olive or coconut oil[4], to restore the leather’s sheen.
<G-vec00272-002-s742><apply.tragen><de> Trage ein natürliches Öl auf, wie etwa Oliven- oder Kokosöl[4], um den Glanz des Leders wiederherzustellen.
<G-vec00272-002-s743><apply.tragen><en> Round faces: To slim a round face, apply blush to your cheekbones (which you can find by sucking your cheeks in like a fish) and blend outwards and upwards towards the temple.
<G-vec00272-002-s743><apply.tragen><de> Runde Gesichter: Um ein rundes Gesicht dünner aussehen zu lassen, trage Rouge auf deine Wangenknochen auf (die du finden kannst, wenn du ein Fischgesicht machst) und pinsle nach außen und oben, entlang deiner Schläfen.
<G-vec00272-002-s744><apply.tragen><en> Never apply deodorant, anti-perspirants, perfume, or anything that stings on just shaved skin.
<G-vec00272-002-s744><apply.tragen><de> Trage niemals Deodorant, Anti-Transpirant, Parfum oder etwas, das reizt auf die frisch rasierte Haut auf.
<G-vec00272-002-s745><apply.tragen><en> Apply rubbing alcohol to a cloth or cotton ball.
<G-vec00272-002-s745><apply.tragen><de> Trage Reinigungsalkohol auf ein Tuch oder einen Wattebausch auf.
<G-vec00272-002-s746><apply.tragen><en> Apply vinegar to neutralize the wood.
<G-vec00272-002-s746><apply.tragen><de> Trage Essig auf, um das Holz zu neutralisieren.
<G-vec00272-002-s747><apply.tragen><en> Wet the feet and apply the desired amount of Greenland Fruit Emotions foot scrub to the feet.
<G-vec00272-002-s747><apply.tragen><de> Trage eine großzügige Menge Greenland Fruit Emotions Duschgel auf die nasse Haut auf.
<G-vec00272-002-s748><apply.tragen><en> Scrape off the old thermal paste and apply a new layer.
<G-vec00272-002-s748><apply.tragen><de> Kratze die alte Wärmeleitpaste ab und trage eine neue Schicht auf.
<G-vec00272-002-s749><apply.tragen><en> Take some paint on the sponge, blot it on the paper, and apply it to your skin as before, but a little more lightly.
<G-vec00272-002-s749><apply.tragen><de> Nimm etwas Farbe auf, tupfe sie auf dem Papier ab und trage sie wie schon zuvor, nur noch etwas vorsichtiger, auf.
<G-vec00272-002-s750><apply.tragen><en> Apply a small drop to the nail area and massage in.
<G-vec00272-002-s750><apply.tragen><de> Trage einen kleinen Tropfen auf deinen Nagel auf und massiere das Öl gut ein.
<G-vec00272-002-s751><apply.tragen><en> Apply a small amount of toothpaste onto your bottom eyelids to make your eyes watery.
<G-vec00272-002-s751><apply.tragen><de> Trage ein wenig Zahnpasta auf deine unteren Augenlider auf, um deine Augen wässrig erscheinen zu lassen.
<G-vec00272-002-s752><apply.tragen><en> Apply antiperspirant in the morning.
<G-vec00272-002-s752><apply.tragen><de> Trage das Antitranspirant morgens auf.
<G-vec00272-002-s753><apply.tragen><en> Mix the two together until it forms a paste, and apply it to your face for 10 minutes and rinse with warm water.
<G-vec00272-002-s753><apply.tragen><de> Vermische die beiden, bis eine Paste entsteht und trage sie für 10 Minuten auf das Gesicht auf.
<G-vec00272-002-s754><apply.tragen><en> Apply the paste to your rash to pull the fluid out of the blisters.
<G-vec00272-002-s754><apply.tragen><de> Trage die Paste auf deinen Ausschlag auf, um die Flüssigkeit aus der Blase zu ziehen.
<G-vec00272-002-s755><apply.tragen><en> Apply retinol to your skin.
<G-vec00272-002-s755><apply.tragen><de> Trage Retinol auf deine Haut auf.
<G-vec00272-002-s756><apply.tragen><en> So, grab your heels, apply balm and head downtown.
<G-vec00272-002-s756><apply.tragen><de> Also zieh Deine High Heels an, trage den Lippenbalsam auf und los geht's in die Stadt.
<G-vec00272-002-s757><apply.tragen><en> Apply the sealer with a 3/8-inch-nap paint roller.
<G-vec00272-002-s757><apply.tragen><de> Trage die Versiegelung mit einem Felt-Roller auf, der eine Florhöhe von 10mm hat.
<G-vec00272-002-s758><apply.tragen><en> Apply a carpet stain removal solution to the stained area.
<G-vec00272-002-s758><apply.tragen><de> Trage die chemische Reinigungslösung auf den fleckigen Bereich auf.
<G-vec00272-002-s759><apply.tragen><en> Apply the paint thinly, allow it to dry completely, and then apply another thin layer.[7]
<G-vec00272-002-s759><apply.tragen><de> Trage die Farbe dünn auf, lasse sie vollständig trocknen und trage dann eine weitere dünne Schicht auf.
<G-vec00272-002-s779><apply.verwenden><en> In order to explore the metal grades of natural ores, researchers apply highly complex electronic devices like the SIMS facility.
<G-vec00272-002-s779><apply.verwenden><de> Um die Metallgehalte in einem Erz zu bestimmen, verwenden Forscher hoch komplexe, elektronische Geräte wie die SIMS-Anlage.
<G-vec00272-002-s780><apply.verwenden><en> The buttons have dual functions, yet are still easy to understand and apply.
<G-vec00272-002-s780><apply.verwenden><de> Die Tasten weisen häufig Doppelfunktionen auf, lassen sich aber trotzdem einfach überschauen und verwenden.
<G-vec00272-002-s781><apply.verwenden><en> The product has the ability to apply the necessary filters and sorting, aggregate data, perform calculations of any complexity.
<G-vec00272-002-s781><apply.verwenden><de> Die Software hat die Möglichkeit, verschiedene Filter und Sortierungen zu verwenden, Daten zusammenzufassen und Berechnungen von beliebiger Komplexität durchzuführen.
<G-vec00272-002-s782><apply.verwenden><en> See Create and apply patterns to learn how to define a custom pattern in Illustrator.
<G-vec00272-002-s782><apply.verwenden><de> Im Tutorial Muster erstellen und verwenden erfahren Sie, wie Sie mit Illustrator eigene Muster entwerfen können.
<G-vec00272-002-s783><apply.verwenden><en> The contributions apply and develop EC's core concepts as quality conventions, human agency, critique and justification, the incompleteness and plurality of rationalities, state conventions, investments in form, or bad conventions.
<G-vec00272-002-s783><apply.verwenden><de> Die 14 Beiträge in diesem HSR Special Issue verwenden und entwickeln die Kernkonzepte des EC weiter: Qualitäts-Konventionen, menschliches Handeln, Kritik und Rechtfertigung, die Unvollständigkeit und Vielzahl von Rationalitäten, Staatskonventionen, Investitionen in die Form oder schlechten Konventionen.
<G-vec00272-002-s784><apply.verwenden><en> It is necessary to apply the weatherproof paints specially intended for external works to external furnish of the house.
<G-vec00272-002-s784><apply.verwenden><de> Für die äusserliche Ausstattung des Hauses ist nötig es die wetterbeständigen Farben zu verwenden, die für die äusserlichen Arbeiten speziell vorbestimmt sind.
<G-vec00272-002-s785><apply.verwenden><en> Nails apply with wide hats - white or omednennymi.
<G-vec00272-002-s785><apply.verwenden><de> Die Nägel verwenden mit den breiten Hüten - die Weißen oder omednennymi.
<G-vec00272-002-s786><apply.verwenden><en> However at times it is better to waste time and efforts to working out of one own filter at once providing desirable result, than to apply to this purpose ten standard.
<G-vec00272-002-s786><apply.verwenden><de> Jedoch ist es manchmal besser, die Zeit und die Bemühungen auf die Entwicklung eines eigenen Filters, der sofort das erwünschte Ergebnis gewährleistet auszugeben, als für dieses Ziel zehn Standardmäßiger zu verwenden.
<G-vec00272-002-s787><apply.verwenden><en> [2] Member States may apply other values depending on the type of wood most used in the respective Member State.
<G-vec00272-002-s787><apply.verwenden><de> (3) Die Mitgliedstaaten können je nach der im jeweiligen Mitgliedstaat am meisten genutzten Holzsorte andere Werte verwenden.
<G-vec00272-002-s788><apply.verwenden><en> If companies apply the technical measure for transitional provisions, they must consistently reduce the valuation difference.
<G-vec00272-002-s788><apply.verwenden><de> Sofern Unternehmen das so genannte Rückstellungstransitional verwenden, müssen sie die Bewertungsdifferenz kontinuierlich zurückführen.
<G-vec00272-002-s789><apply.verwenden><en> On the other side we apply a Hydrophilic laminate that pulls moisture away from the body so it can be passed out through the exterior shell.
<G-vec00272-002-s789><apply.verwenden><de> Auf der anderen Seite verwenden wir ein hydrophiles Laminat, das Nässe vom Körper weg und durch den Bezug nach außen leitet.
<G-vec00272-002-s790><apply.verwenden><en> We don't apply any hidden charges online or at our Crete - Chania car rental desk.
<G-vec00272-002-s790><apply.verwenden><de> Wir verwenden keine versteckte Kosten online am unseren Kreta-ChaniaAutoverleih Schalter.
<G-vec00272-002-s791><apply.verwenden><en> Apply your final output settings when you pre-render the nested composition.
<G-vec00272-002-s791><apply.verwenden><de> Verwenden Sie beim Vorrendern der verschachtelten Komposition die endgültigen Ausgabeeinstellungen.
<G-vec00272-002-s792><apply.verwenden><en> TIP: Apply and review what you have learned.
<G-vec00272-002-s792><apply.verwenden><de> TIPP: Verwenden und überprüfen Sie, was Sie gelernt haben.
<G-vec00272-002-s793><apply.verwenden><en> Authorisation applications: industry must submit the authorisation applications to the ECHA and must in particular present an analysis of the alternative solutions and an alternative plan to either apply the alternatives or develop new ones.
<G-vec00272-002-s793><apply.verwenden><de> Zulassungsanträge: Die Industrie muss die Zulassungsanträge bei der ECHA einreichen und muss insbesondere eine Analyse der alternativen Lösungen und einen Alternativplan vorlegen, um entweder die Alternativen zu verwenden oder neue Alternativen zu entwickeln.
<G-vec00272-002-s794><apply.verwenden><en> Following this, the users apply these attributes and functions further in the 3D modelling of the system components because data generated once can be used several times over – for example for thermal calculation or pulsation studies.
<G-vec00272-002-s794><apply.verwenden><de> Anschließend verwenden die User diese Attribute und Funktionen in der 3D Modellierung der Anlagenkomponenten weiter, denn einmal generierte Daten können vielfach genutzt werden – etwa für die thermische Berechnung oder für Pulsationsstudien.
<G-vec00272-002-s795><apply.verwenden><en> At several places, our Internet pages apply so-called cookies.
<G-vec00272-002-s795><apply.verwenden><de> Unsere Internetseiten verwenden an mehreren Stellen so genannte Cookies.
<G-vec00272-002-s796><apply.verwenden><en> We don't apply any hidden charges online or at our Lozenets car rental desk.
<G-vec00272-002-s796><apply.verwenden><de> Wir verwenden keine versteckte Kosten online am unseren Flughafen Kreta ChaniaAutoverleih Schalter.
<G-vec00272-002-s797><apply.verwenden><en> Create channels for areas where you might want to apply a different spot color or varnish.
<G-vec00272-002-s797><apply.verwenden><de> Legen Sie vorausschauend Kanäle für Bereiche an, in denen Sie eine andere Volltonfarbe oder Spotlack verwenden möchten.
<G-vec00272-002-s798><apply.wenden><en> We apply the methods of organic agriculture.
<G-vec00272-002-s798><apply.wenden><de> Wir wenden die Methoden der ökologischen Landwirtschaft.
<G-vec00272-002-s799><apply.wenden><en> Many people apply this principle to the succeeding generations in mobile communication and their successive technology standards.
<G-vec00272-002-s799><apply.wenden><de> Viele Menschen wenden dieses Prinzip auch auf die Mobilfunkgenerationen und ihre jeweilige Technik an.
<G-vec00272-002-s800><apply.wenden><en> We apply this approach in a consistent, non-discriminatory manner; from our largest institutional investors to our smallest account holders.
<G-vec00272-002-s800><apply.wenden><de> Dieses Prinzip wenden wir – von unseren größten institutionellen Anlegern bis hin zu unseren kleinsten Kontoinhabern – konsequent und unterschiedslos an.
<G-vec00272-002-s801><apply.wenden><en> We also apply the method of repeatedly watering the weeds with steep boiling water.
<G-vec00272-002-s801><apply.wenden><de> Wir wenden auch die Methode der wiederholten Bewässerung der Unkräuter mit steilem kochendem Wasser an.
<G-vec00272-002-s802><apply.wenden><en> Without prejudice to any specific provisions which may be adopted by the Commission in accordance with Article 194, Member States shall check whether those products conform to those standards and shall apply penalties as appropriate.
<G-vec00272-002-s802><apply.wenden><de> Unbeschadet der spezifischen Bestimmungen, die die Kommission gemäß Artikel 194 erlassen kann, prüfen die Mitgliedstaaten, ob die Erzeugnisse diese Normen erfüllen, und wenden gegebenenfalls Sanktionen an.
<G-vec00272-002-s803><apply.wenden><en> Perhaps you would like to apply for several universities at the same time – but you are not obliged to apply centrally to the Foundation for Higher Education Admissions.
<G-vec00272-002-s803><apply.wenden><de> Es ist durchaus sinnvoll, sich bei mehreren Hochschulen gleichzeitig zu bewerben – sofern man sich nicht zentral an die Stiftung für Hochschulzulassung wenden muss.
<G-vec00272-002-s804><apply.wenden><en> We apply agile scaling models to all levels of companies of every size and industry to assist them in their agile transformations.
<G-vec00272-002-s804><apply.wenden><de> Wir wenden Agile Scaling Models auf allen Ebenen in Unternehmen jeder Größe und Branche an, um sie bei ihrer agilen Transformation zu unterstützen.
<G-vec00272-002-s805><apply.wenden><en> Manage a classification scheme or file plan, or apply multiple rules to a single classification and set term expiration. Taxonomy Management View settings, choose to apply an entire term set, subset of a term or set, or default term to an Office 365 location.
<G-vec00272-002-s805><apply.wenden><de> Verwalten Sie ein Klassifizierungsschema oder einen Dateiplan oder wenden Sie mehrere Regeln auf eine einzelne Klassifizierung an und legen Sie eine Ablauffrist Zeigen Sie die Einstellungen an und wenden Sie einen ganzen Ausdruckssatz, einen Teil eines Ausdrucks oder Satzes oder einen Standardausdruck auf einen Office 365-Standort an.
<G-vec00272-002-s806><apply.wenden><en> In some cases, we apply these learnings across our Services to improve and develop similar features or to better integrate the services you use.
<G-vec00272-002-s806><apply.wenden><de> In einigen Fällen wenden wir diese Erkenntnisse Service-übergreifend an, um diese zu verbessern und ähnliche Funktionen zu entwickeln oder um die Services, die du verwendest, besser zu integrieren.
<G-vec00272-002-s807><apply.wenden><en> As interested and pensioned or former Messer employee you are welcome to apply to Diana Buss, Vice President Communications, to receive also the Messer staff magazine "Messenger".
<G-vec00272-002-s807><apply.wenden><de> Bei Interesse an unserer Mitarbeiterzeitschrift "Messenger" können sich pensionierte oder ehemalige Messer Mitarbeiter gerne an Diana Buss, Vice President Communications, wenden.
<G-vec00272-002-s808><apply.wenden><en> We voluntarily apply comparable standards around the world, independent of the respective national legislation.
<G-vec00272-002-s808><apply.wenden><de> Unabhängig von der jeweiligen Landesgesetzgebung wenden wir weltweit freiwillig vergleichbare Standards an.
<G-vec00272-002-s809><apply.wenden><en> The institutions and persons covered by this Directive shall apply each of the customer due diligence requirements set out in paragraph 1, but may determine the extent of such measures on a risk-sensitive basis depending on the type of customer, business relationship, product or transaction.
<G-vec00272-002-s809><apply.wenden><de> (2) Die dieser Richtlinie unterliegenden Institute und Personen wenden alle in Absatz 1 genannten Sorgfaltspflichten gegenüber Kunden an, können dabei aber den Umfang dieser Maßnahmen auf risikoorientierter Grundlage je nach Art des Kunden, der Geschäftsbeziehung, des Produkts oder der Transaktion bestimmen.
<G-vec00272-002-s810><apply.wenden><en> They can’t be troubled to examine them earnestly, and although they hear what is offered to them as a most precious gift of grace they do not apply it to themselves and, therefore, do not perfect themselves according to My Will.
<G-vec00272-002-s810><apply.wenden><de> Sie machen sich nicht die Mühe einer ernsten Prüfung, sondern sie hören das, was ihnen als wertvollste Gnadengabe dargeboten wird, wenden es aber nicht auf sich selbst an und bilden sich daher auch nicht nach Meinem Willen.
<G-vec00272-002-s811><apply.wenden><en> Customize chart elements, apply a chart style and colors, and insert a linked Excel chart.
<G-vec00272-002-s811><apply.wenden><de> Dazu passen Sie Diagrammelemente an, wenden eine Diagrammformatvorlage und Farben an und fügen ein verknüpftes Excel-Diagramm ein.
<G-vec00272-002-s812><apply.wenden><en> FOR STAY LESS THAN 5 NIGHTS, WE APPLY AN EXTRA CHARGE OF 50 € TO THE TOTAL.
<G-vec00272-002-s812><apply.wenden><de> Bei einem Aufenthalt weniger als 5 Nächten, wenden wir einen Aufpreis von 50 € ZUM GESAMT.
<G-vec00272-002-s813><apply.wenden><en> We also use this modern architecture concept at 1&1 IONOS: As cloud providers, we use SDN not only to virtualise the control plane, but instead apply it to the entire network – providing you with a cost-efficient Software Defined Networking solution with a functional scope and speed that are noticeably superior to others.
<G-vec00272-002-s813><apply.wenden><de> Auch wir bei 1&1 IONOS setzen auf dieses moderne Architektur-Konzept: Als Cloud-Anbieter nutzen wir SDN nicht nur zur Virtualisierung der Steuerungsebene, sondern wenden es auf das gesamte Netzwerk an – und stellen Ihnen auf diese Weise eine kostengünstige Software-Defined-Networking-Lösung zur Verfügung, die anderen hinsichtlich Funktionsumfang und Geschwindigkeit deutlich überlegen ist.
<G-vec00272-002-s814><apply.wenden><en> We apply reasonable technical and physical measures to protect the information we collect through the Website.
<G-vec00272-002-s814><apply.wenden><de> Wir wenden angemessene technische und physische Maßnahmen an, um die Informationen, die wir über die Website sammeln, zu schützen.
<G-vec00272-002-s815><apply.wenden><en> • develop adequate communication strategies for the therapist/client relationship, interdisciplinary teams, and the general public and apply these strategies in group tasks.
<G-vec00272-002-s815><apply.wenden><de> • entwickeln adäquate Kommunikationsstrategien in der TherapeutIn-KlientIn-Beziehung, im interdisziplinären Team, in der Öffentlichkeit und wenden diese in Gruppenaufgaben an.
<G-vec00272-002-s816><apply.wenden><en> We apply our inner clarity to higher levels of life, and our interactions with others are based on universal love and openness.
<G-vec00272-002-s816><apply.wenden><de> Wir wenden unsere innere Klarheit auf höheren Lebensebenen an und unsere Begegnung mit anderen basiert auf universeller Liebe und Offenheit.
<G-vec00272-002-s875><apply.übernehmen><en> Click Finish to apply the task.
<G-vec00272-002-s875><apply.übernehmen><de> Klicken Sie auf Fertig stellen, um den Task zu übernehmen.
<G-vec00272-002-s876><apply.übernehmen><en> Click Save to apply your changes.
<G-vec00272-002-s876><apply.übernehmen><de> Klicken Sie auf Speichern, um Ihre Änderungen zu übernehmen.
<G-vec00272-002-s878><apply.übernehmen><en> Click Apply and OK to save changes.
<G-vec00272-002-s878><apply.übernehmen><de> Klicken Sie auf übernehmen und OK.
<G-vec00272-002-s879><apply.übernehmen><en> To apply a certain filter, drag its icon to the video fragment or image on the timeline.
<G-vec00272-002-s879><apply.übernehmen><de> Um einen bestimmten Filter zu übernehmen, ziehen Sie sein Symbol auf den Videoausschnitt oder das Bild in der Zeitleiste.
<G-vec00272-002-s880><apply.übernehmen><en> Uncheck all startup entries and press Apply.
<G-vec00272-002-s880><apply.übernehmen><de> Deaktivieren Sie alle Autostart-Einträge und drücken Sie übernehmen .
<G-vec00272-002-s881><apply.übernehmen><en> Click Save to apply your changes.
<G-vec00272-002-s881><apply.übernehmen><de> Klicken Sie auf Speichern, um die Änderungen zu übernehmen.
<G-vec00272-002-s882><apply.übernehmen><en> After making your edits, please save your new settings so that we can apply them.
<G-vec00272-002-s882><apply.übernehmen><de> Speichern Sie nach der Bearbeitung Ihrer Interessen bitte die neue Einstellung, damit wir diese übernehmen können.
<G-vec00272-002-s883><apply.übernehmen><en> Applying settings To apply the settings made in the individual tabs, proceed as follows for each tab: Ê Click the Apply button.
<G-vec00272-002-s883><apply.übernehmen><de> Einstellungen übernehmen Um die in den einzelnen Registerkarten vorgenommenen Einstellungen zu übernehmen, verfahren Sie pro Registerkarte wie folgt: Ê Klicken Sie auf die Schaltfläche Apply.
<G-vec00272-002-s884><apply.übernehmen><en> You can also edit the file in an editor or copy it to another document root to apply the same settings to other websites.
<G-vec00272-002-s884><apply.übernehmen><de> Sie können die Datei auch mit einem Editor bearbeiten oder sie in ein anderes Document Root kopieren, um die Einstellungen für andere Webseiten zu übernehmen.
<G-vec00272-002-s885><apply.übernehmen><en> Save/Apply / Cancel Click Save/Apply to apply the changes or Cancel to return previous settings.
<G-vec00272-002-s885><apply.übernehmen><de> Klicken Sie nach der Auswahl der Einstellungen auf Einstellungen speichern, um die Änderungen zu übernehmen, oder auf Änderungen stornieren, um den Vorgang abzubrechen.
<G-vec00272-002-s886><apply.übernehmen><en> The remote site should be able to apply the next download file.
<G-vec00272-002-s886><apply.übernehmen><de> Der entfernte Standort sollte in der Lage sein, die nächste Download-Datei zu übernehmen.
<G-vec00272-002-s887><apply.übernehmen><en> Click the Midtones radio button to apply color settings to the image's normal areas.
<G-vec00272-002-s887><apply.übernehmen><de> Klicken Sie auf Mitteltöne, um diese Farbeinstellungen auf dem gesamten Bild mit durchschnittlicher Intensität zu übernehmen.
<G-vec00272-002-s888><apply.übernehmen><en> Now you will deploy the plugins in a plugin set in order to apply the changes. The order property will be available in the Item view and the Shopping cart.
<G-vec00272-002-s888><apply.übernehmen><de> Nun stellen wir unser Plugin-Set noch einmal durch Klcik auf Speichern & Plugins bereitstellen bereit, um die Änderungen zu übernehmen, und erhalten das Bestellmerkmal in Artikelansicht und im Warenkorb.
<G-vec00272-002-s889><apply.übernehmen><en> After it close the dialog box and Restart your browser to apply the changes.
<G-vec00272-002-s889><apply.übernehmen><de> Nachdem Sie das Dialogfeld geschlossen haben und Ihren Browser neu starten, um die Änderungen zu übernehmen.
<G-vec00272-002-s890><apply.übernehmen><en> Select Apply to all if you want to apply these changes to all slideshows.
<G-vec00272-002-s890><apply.übernehmen><de> Wählen Sie Für alle übernehmen, wenn Sie diese Änderungen für alle Diashows übernehmen möchten.
<G-vec00272-002-s891><apply.übernehmen><en> Close the Services and Control Panel windows, then reboot your computer to apply changes.
<G-vec00272-002-s891><apply.übernehmen><de> Schließen Sie das Dienste- und Systemsteuerungs-Fenster und starten Sie Ihren Computer neu, um die Änderungen zu übernehmen.
<G-vec00272-002-s892><apply.übernehmen><en> Note:Only some of the items on a form template change color automatically when you apply a color scheme.
<G-vec00272-002-s892><apply.übernehmen><de> Hinweis: Nur einige Elemente auf der Formularvorlage ändern automatisch ihre Farbe, wenn Sie ein Farbschema übernehmen.
<G-vec00328-002-s133><apply.finden><en> Your application also includes personal data (hereinafter referred to as "data"), and for this reason data protection provisions and in particular the EU General Data Protection Regulation (hereinafter referred to as "GDPR") apply.
<G-vec00328-002-s133><apply.finden><de> Dabei um-fasst Ihre Bewerbung auch personenbezogene Daten (im Folgenden „Daten“), weshalb datenschutzrechtliche Vorschriften und insbesondere die EU Datenschutzgrundverordnung (im Folgenden „DSGVO“) Anwendung finden.
<G-vec00328-002-s134><apply.finden><en> 3.Persons to whom points (d) to (f) of paragraph 1 or paragraph 2 apply shall be entitled to rights set out in or similar to those set out in Articles 3, 4, 16, 22, 31, 32 and 33 of the Geneva Convention in so far as they are present in the Member State.
<G-vec00328-002-s134><apply.finden><de> (6) Personen, auf die die Absätze 4 oder 5 Anwendung finden, können die in den Artikeln 3, 4, 16, 22, 31, 32 und 33 der Genfer Flüchtlingskonvention genannten Rechte oder vergleichbare Rechte geltend machen, sofern sie sich in dem betreffenden Mitgliedstaat aufhalten.
<G-vec00328-002-s135><apply.finden><en> Based on the book The Problems of Work, this film contains the senior principles and laws which apply to every endeavor, every problem of work.
<G-vec00328-002-s135><apply.finden><de> Auf der Grundlage des Buches Die Probleme der Arbeit enthält dieser Film die übergeordneten Prinzipien und Gesetze, die auf jede Bemühung und jedes Problem in Bezug auf Arbeit Anwendung finden.
<G-vec00328-002-s136><apply.finden><en> All necessary documents: passport, itinerary, travel insurance, vaccine certificate and others that might apply.
<G-vec00328-002-s136><apply.finden><de> - Alle notwendigen Dokumente: Pass, Impfzertifikate und anderes, was Anwendung finden mag.
<G-vec00328-002-s137><apply.finden><en> All rights, obligations, offers, orders, agreements and deliveries to which these Terms and Conditions apply, granted to these Terms and Conditions, are exclusively governed by Dutch law.
<G-vec00328-002-s137><apply.finden><de> Alle Rechte, Verpflichtungen, Angebote, Aufträge, Vereinbarungen und Lieferungen, auf die diese Bedingungen Anwendung finden, sowie diese Bedingungen unterliegen ausschließlich dem niederländischen Recht.
<G-vec00328-002-s138><apply.finden><en> In the event that the accommodation would last longer than 60 days for one accommodated person, the rent adjustment according to the Czech Civil Code would still apply.
<G-vec00328-002-s138><apply.finden><de> Für den Fall, dass es sich um eine Unterkunft für mehr als 60 Tage pro Gast handeln sollte, würde immer noch die Regelung der Vermietung gemäß dem Bürgerlichen Gesetzbuch Anwendung finden.
<G-vec00328-002-s139><apply.finden><en> 11.1 All rights, obligations, offers, orders and contracts to which these Conditions apply, and also these Conditions themselves, are exclusively governed by Dutch law.
<G-vec00328-002-s139><apply.finden><de> 11.1 Alle Rechte, Verpflichtungen, Angebote, Bestellungen und Verträge, auf welche diese Bedingungen Anwendung finden, und auch die Bedingungen selbst unterliegen ausschließlich dem Recht der Niederlande.
<G-vec00328-002-s140><apply.finden><en> Financial incentives that apply exclusively to vehicles which comply with the emission limit values in Table 2 of Annex I may be granted for such new vehicles offered for sale on the market of a Member State from the dates set out in Article 10(3) in advance of the dates set out in Article 10(5); they shall cease on the dates set out in Article 10(5).
<G-vec00328-002-s140><apply.finden><de> Finanzielle Anreize, die ausschließlich auf Fahrzeuge Anwendung finden, die die Emissionsgrenzwerte in Anhang I Tabelle 2 erfüllen, können für neue Fahrzeuge, die in einem Mitgliedstaat zum Kauf angeboten werden, nach den in Artikel 10 Absatz 3 genannten Zeitpunkten, aber vor den in Artikel 10 Absatz 5 genannten Zeitpunkten geboten werden; diese Anreize dürfen nach diesen Zeitpunkten nicht mehr geboten werden.
<G-vec00328-002-s141><apply.finden><en> You also may be subject to additional terms and conditions that may apply when you use or purchase certain other ShopCity.com services, affiliate services, third-party content or third-party software.
<G-vec00328-002-s141><apply.finden><de> Die Nutzung der Plattform kann zusätzlichen Geschäftsbedingungen unterliegen, die bei der Verwendung von Partnerdiensten, Inhalten von Dritten oder Software von Dritten Anwendung finden.
<G-vec00328-002-s142><apply.finden><en> First, there must be a secondment according to the double tax treaty in order to be able to apply the European law and the regulation.
<G-vec00328-002-s142><apply.finden><de> Zunächst muss eine Entsendung nach den Doppelbesteuerungsabkommen vorliegen, damit das Europäische Recht und die Verordnung Anwendung finden.
<G-vec00328-002-s143><apply.finden><en> Thus any legal uncertainty arises merely because different provisions apply in different factual circumstances.
<G-vec00328-002-s143><apply.finden><de> Etwaige Rechtsunsicherheiten sind also allein darauf zurückzuführen, dass auf unterschiedliche Sachverhalte unterschiedliche Bestimmungen Anwendung finden.
<G-vec00328-002-s144><apply.finden><en> The assertion of the retention of title and the seizure of the goods delivered by maweco are not considered as withdrawal from the contract, unless the provisions of the consumer protection law apply or this is expressly declared in writing by maweco.
<G-vec00328-002-s144><apply.finden><de> Die Geltendmachung des Eigentumsvorbehaltes sowie die Pfändung der Liefergegenstände durch die Firma maweco gelten nicht als Rücktritt vom Vertrag, sofern nicht die Bestimmungen des Verbraucherschutzes Anwendung finden oder dies ausdrücklich durch die Firma maweco schriftlich erklärt wird.
<G-vec00328-002-s145><apply.finden><en> In the event that besides these general conditions also specific product or service conditions apply, it's second and third paragraph shall apply and the consumer in case of conflicting terms always rely on the applicable provision that is most favorable to him is.
<G-vec00328-002-s145><apply.finden><de> Für den Fall, dass nebst den AGBs zusätzliche produkt- oder dienstspezifische Bedingungen Anwendung finden, kann der Konsument sich bei Widerspruch zwischen diesen Bedingungen auf die Bestimmungen, die für Ihn die günstigsten sind, berufen.
<G-vec00328-002-s146><apply.finden><en> This provision provides that amended fee levels which are related to the use of a means of electronic communication or a document format will not apply until a date set by the President of the Office.
<G-vec00328-002-s146><apply.finden><de> Diese Vorschrift besagt, dass geänderte Gebührenbeträge, die an die Verwendung einer Einrichtung zur elektronischen Nachrichtenübermittlung oder eines Dokumentenformats geknüpft sind, erst ab einem vom Präsidenten des Amts festzulegenden Datum Anwendung finden.
<G-vec00328-002-s147><apply.finden><en> This Regulation should not, therefore, apply to processing activities for those purposes.
<G-vec00328-002-s147><apply.finden><de> Deshalb sollte diese Verordnung auf Verarbeitungstätigkeiten dieser Art keine Anwendung finden.
<G-vec00328-002-s148><apply.finden><en> You shall comply with applicable terms and conditions of third parties, in particular – if applicable – Facebook Terms and Conditions of Use, that apply with regard to the usage of Pirate Studio’s Video Content Services .
<G-vec00328-002-s148><apply.finden><de> 6.2 Der Nutzer wird die anwendbaren AGB der Dritter, insbesondere – sofern zutreffend – von Facebook, die im Zusammenhang mit der Nutzung von Video Content Services von Pirate Studios Anwendung finden, einhalten.
<G-vec00328-002-s149><apply.finden><en> Therefore, we recommend to thoroughly plan and analyse international M&A transactions, permanent establishment and financial structures very early in the development stage in order to check, whether and, if so, to which extent the new regulations may apply.
<G-vec00328-002-s149><apply.finden><de> Deshalb empfehlen wir jedenfalls eine frühzeitige und sehr sorgfältige Planung und Analyse grenzüberschreitender M&A-, Betriebsstätten- sowie Finanzierungskonzepte, um zu klären, ob und inwieweit die neuen Normen Anwendung finden.
<G-vec00328-002-s150><apply.finden><en> Therefore, the emission credits from the project-based mechanisms will be recognised for their use in this scheme subject to provisions adopted by the European Parliament and the Council on a proposal from the Commission, which should apply in parallel with the Community scheme in 2005.
<G-vec00328-002-s150><apply.finden><de> Die Emissionsgutschriften aus den projektbezogenen Mechanismen werden daher für eine Nutzung in diesem System nach Maßgabe der Vorschriften anerkannt, die das Europäische Parlament und der Rat auf Vorschlag der Kommission erlassen und die im Jahr 2005 parallel zum Gemeinschaftssystem Anwendung finden sollten.
<G-vec00328-002-s151><apply.finden><en> The annual pension contributions result in modules of what is, in principle, a lifelong pension in line with the arrangements that also apply to employees covered by collective agreements.
<G-vec00328-002-s151><apply.finden><de> Aus den jährlichen Versorgungsbeiträgen ergeben sich – nach Maßgabe der Regelungen, die auch für Tarifmitarbeiter Anwendung finden – Bausteine einer grundsätzlich lebenslangen Rentenzahlung.
<G-vec00328-002-s742><apply.tragen><en> Apply a natural oil, such as olive or coconut oil[4], to restore the leather’s sheen.
<G-vec00328-002-s742><apply.tragen><de> Trage ein natürliches Öl auf, wie etwa Oliven- oder Kokosöl[4], um den Glanz des Leders wiederherzustellen.
