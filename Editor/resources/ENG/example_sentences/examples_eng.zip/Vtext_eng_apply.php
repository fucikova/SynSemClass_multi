<G-vec00272-001-s019><apply.anwenden><en> You agree that the laws of Switzerland without regard to conflicts of law principles thereof, shall apply to all matters relating to the use of the Website and these Terms of Use.
<G-vec00272-001-s019><apply.anwenden><de> Sie erklären sich damit einverstanden, dass die belgischen Gesetze ohne Rücksicht auf Konflikte mit darin enthaltenen Gesetzesprinzipien auf sämtliche Belange der Nutzung dieser 'Website' angewendet werden.
<G-vec00272-001-s020><apply.anwenden><en> And the same principles apply here, on the meditative level, as apply in the Buddha's comments to Rahula on action in general.
<G-vec00272-001-s020><apply.anwenden><de> Das selbe Prinzip, hier auf der meditativen Ebene angewendet, paßt in Buddhas Bemerkungen, zu Rahulas Handlungen, im Generellen.
<G-vec00272-001-s021><apply.anwenden><en> We also apply simplified technique for sensor with lower precision.
<G-vec00272-001-s021><apply.anwenden><de> Für Sensoren mit geringerer Präzision werden vereinfachte Methoden angewendet.
<G-vec00272-001-s022><apply.anwenden><en> Whether you elect to earn Miles as your earning preference or decide instead to earn Points and later convert them into Miles, each Airline Program maintains its own rules, regulations, and program terms and conditions, all of which will apply to your use of any Miles.
<G-vec00272-001-s022><apply.anwenden><de> Jedes Vielfliegerprogramm hat seine eigenen Regeln, Vorschriften und Geschäftsbedingungen des Programms, welche alle auf Ihren Gebrauch von Meilen angewendet werden, unabhängig davon, ob Sie Meilen sammeln, oder Punkte sammeln und diese später in Meilen umwandeln.
<G-vec00272-001-s023><apply.anwenden><en> The Urban Sprawl Metrics (USM) Toolset allows to intuitively apply intuitvely possible to apply the method of Weighted Urban Proliferation.
<G-vec00272-001-s023><apply.anwenden><de> Mit dem Onlinetool (USM: Urban Sprawl Metrics tool) kann die Methode der gewichteten Zersiedelung intuitiv angewendet werden.
<G-vec00272-001-s024><apply.anwenden><en> Our experienced instructors apply years of service expertise to help your staff learn how to operate instruments properly and apply corrective and preventive maintenance of your measurement devices.
<G-vec00272-001-s024><apply.anwenden><de> Unsere erfahrenen Schulungsleiter stützen sich auf jahrelange Fachkompetenz im Bereich Services, um Ihren Mitarbeitern beizubringen, wie die Geräte korrekt bedient und korrigierende sowie vorbeugende Wartungsmaßnahmen auf Ihre Messgeräte angewendet werden.
<G-vec00272-001-s025><apply.anwenden><en> Note: If you defined several criteria on the same array attribute, the matched criteria will not necessarily apply to the same array element.
<G-vec00272-001-s025><apply.anwenden><de> Hinweis: Haben Sie im selben Array Attribut mehrere Kriterien definiert, wird das passende Kriterium nicht zwingend auf dasselbe Array Element angewendet.
<G-vec00272-001-s026><apply.anwenden><en> Since each of these events apply across the entire project, each event could be triggered by the audio on any channel.
<G-vec00272-001-s026><apply.anwenden><de> Da jedes dieser Ereignisse auf das gesamte Projekt angewendet wird, könnte jedes Ereignis vom Audio auf einem beliebigen Kanal ausgelöst werden.
<G-vec00272-001-s027><apply.anwenden><en> In these cases it is recommended to apply a cream layer, preventing the mask from drying, or using it after removing the mask.
<G-vec00272-001-s027><apply.anwenden><de> In diesem Fall ist es zweckmäßig, dass nicht zum vollen Maskenaustrocknen kommt und nach dem Entfernen die Creme angewendet wird.
<G-vec00272-001-s028><apply.anwenden><en> If any provision of these rules is invalid under the law, rules or regulations of a particular country, it will only apply to the extent permitted.
<G-vec00272-001-s028><apply.anwenden><de> Wenn eine Auslegung dieser Regeln nach den Gesetzen, Regeln oder Vorschriften eines bestimmten Landes ungültig ist, wird sie nur im zulässigen Umfang angewendet.
<G-vec00272-001-s029><apply.anwenden><en> Articles 163-171 apply to parliamentary investigation committees that are appointed after the date on which this Act comes into force.
<G-vec00272-001-s029><apply.anwenden><de> Die Artikel 163-171 werden auf die parlamentarischen Untersuchungskommissionen angewendet, die nach Inkrafttreten des Gesetzes eingesetzt werden.
<G-vec00272-001-s030><apply.anwenden><en> Multipliers of x1, x2, x3, x5 or up to x7 apply to every win occurring after every symbol dropping action.
<G-vec00272-001-s030><apply.anwenden><de> Multiplikatoren von x1, x2, x3, x5 oder bis x7 werden auf jeden Gewinn angewendet und treten nach jedem Symbolabwurf auf.
<G-vec00272-001-s031><apply.anwenden><en> "Under the Immigration Act's ""Purpose of Legislation"", punishment of ""assistance"" or ""promotion"" against illegal work must apply Article 73-2 of the Immigration Act ""Crime that promotes illegal labor""."
<G-vec00272-001-s031><apply.anwenden><de> "Im ""Gesetzgebungszweck"" des Zuwanderungsgesetzes wird die Bestrafung von ""Hilfe"" oder ""Beförderung"" gegen illegale Arbeit,Artikel 73-2 des Immigration Control Act ""Sin zur Förderung illegaler Arbeit"" muss angewendet werden."
<G-vec00272-001-s032><apply.anwenden><en> 4. Where, by reason or a special relationship between the payor and the beneficial owner or between both of them and some other person, the amount of the royalties, having regard to the use, right, or information for which they are paid, exceeds the amount that would have been agreed upon by the payor and the beneficial owner in the absence of such relationship, the provisions or this Article shall apply only to the last-mentioned amount.
<G-vec00272-001-s032><apply.anwenden><de> (4) Bestehen zwischen dem Schuldner und dem Nutzungsberechtigten oder zwischen jedem von ihnen und einem Dritten besondere Beziehungen und übersteigen deshalb die Lizenzgebühren, gemessen an der zugrundeliegenden Leistung, den Betrag, den Schuldner und Nutzungsberechtigter ohne diese Beziehungen vereinbart hätten, so wird dieser Artikel nur auf den letzteren Betrag angewendet.
<G-vec00272-001-s033><apply.anwenden><en> Opens the Application Defaults dialog box in which you can configure default settings that apply to all applications.
<G-vec00272-001-s033><apply.anwenden><de> Öffnet das Dialogfeld Anwendungsstandardwerte, in dem Sie Standardwerte konfigurieren können, die auf alle Anwendungen angewendet werden.
<G-vec00272-001-s034><apply.anwenden><en> Schwarzkopf Dandruff Control Fluid, after washing, apply to the scalp.
<G-vec00272-001-s034><apply.anwenden><de> Schwarzkopf Dandruff Control Fluid, nach dem Waschen angewendet auf die Kopfhaut.
<G-vec00272-001-s035><apply.anwenden><en> 3 Â Unless otherwise determined by an Ordinance issued by the Federal Assembly, these implementing provisions where appropriate apply to data relating to members of the Federal Assembly and the staff of the Parliamentary Services.
<G-vec00272-001-s035><apply.anwenden><de> 3 Soweit Daten von Mitgliedern der Bundesversammlung oder des Personals der Parlamentsdienste betroffen sind, werden diese Ausführungsbestimmungen angewendet, sofern nicht eine Verordnung der Bundesversammlung etwas anderes bestimmt.
<G-vec00272-001-s036><apply.anwenden><en> These principles should apply to all projects intended to help countries adapt to or mitigate the impact of climate change.
<G-vec00272-001-s036><apply.anwenden><de> Diese Prinzipien sollten auf alle Projekte angewendet werden, die den Ländern helfen, sich an die Folgen des Klimawandels anzupassen oder diese abzumildern.
<G-vec00272-001-s037><apply.anwenden><en> View the Precision 7530 Mobile Workstation Learn more about this family Other PC solutions can apply.
<G-vec00272-001-s037><apply.anwenden><de> Precision 7530 Mobile Workstation anzeigen Weitere Informationen über diese Produktreihe Andere PC-Lösungen können angewendet werden.
<G-vec00272-001-s057><apply.anwenden><en> You may apply this artificial lawn to your backyard, golf area, tennis court and even a huge football field and there are proper methods to apply.
<G-vec00272-001-s057><apply.anwenden><de> Sie können diese künstlichen Rasen zu Ihrem Hinterhof, Golfplatz, Tennisplatz und sogar ein großer Fußballplatz und gibt es richtige Methoden anwenden.
<G-vec00272-001-s058><apply.anwenden><en> JMP allows Cree's production teams to visualize and communicate issues in the process, collect data on those issues, apply models, study the effects of interactions and demonstrate improvement.
<G-vec00272-001-s058><apply.anwenden><de> Lösung Mit JMP können die Produktionsteams von Cree Probleme innerhalb des Prozesses visualisieren und kommunizieren, Daten zu diesen Problemen sammeln, Modelle anwenden, die Auswirkungen von Interaktionen untersuchen und Verbesserungen nachweisen.
<G-vec00272-001-s059><apply.anwenden><en> It works on ANY timeframe from M15 to D1… Trust me traders, once you apply this unique tool to your trading platform, you will never use anything else ever again.
<G-vec00272-001-s059><apply.anwenden><de> Es funktioniert auf jeden Zeitraum von M15 bis D1… Vertrauen Sie mir Händler, wenn Sie dieses einzigartige Tool Ihre Handelsplattform anwenden, Sie werden nie wieder etwas anderes verwenden.
<G-vec00272-001-s060><apply.anwenden><en> If you have Kutools for Outlook installed, you can apply its Safe Attachment Extensions option to unblock specified types of blocked attachments quickly, and then delete them easily.
<G-vec00272-001-s060><apply.anwenden><de> Wenn Sie Kutools für Outlook installiert haben, können Sie dessen anwenden Sichere Anhangserweiterungen Option, um bestimmte Typen gesperrter Anhänge schnell zu entsperren und sie dann einfach zu löschen.
<G-vec00272-001-s061><apply.anwenden><en> Note: If you check Don’t show me next time in the Synchronize Worksheets prompt box, this box will not appear when you apply this feature next time.
<G-vec00272-001-s061><apply.anwenden><de> Text: Wenn Sie überprüfen Zeig es mir beim nächsten Mal nicht schwimmen Arbeitsblätter synchronisieren Wenn Sie dieses Feature das nächste Mal anwenden, wird dieses Feld nicht angezeigt.
<G-vec00272-001-s062><apply.anwenden><en> Farmers, who have the status of agricultural producers, can receive and apply for all types of state support.
<G-vec00272-001-s062><apply.anwenden><de> Landwirte mit landwirtschaftlichem Zustand erhalten und für alle Arten von Staat anwenden können.
<G-vec00272-001-s063><apply.anwenden><en> If you have Kutools for Outlook installed, you can apply its Advanced Print feature to quickly print a sent email with all Bcc recipients at ease.
<G-vec00272-001-s063><apply.anwenden><de> Wenn Sie Kutools für Outlook installiert haben, können Sie dessen anwenden Erweiterter Druck Funktion zum schnellen Drucken einer gesendeten E-Mail mit allen Bcc-Empfängern.
<G-vec00272-001-s064><apply.anwenden><en> This online programme will develop students' intellectual, practical and critical-thinking skills to enable them to apply subject-related knowledge and solve problems, which would be expected of an entry-level accountant in an international practice.
<G-vec00272-001-s064><apply.anwenden><de> Dieses Online-Programm wird die intellektuellen, praktischen und kritischen Denkfähigkeiten der Schüler entwickeln, damit sie fachbezogenes Wissen anwenden und Probleme lösen können, die von einem Buchhalter in einer internationalen Praxis erwartet werden.
<G-vec00272-001-s065><apply.anwenden><en> At the end of the workshop participants were able to learn the effects of shock wave therapy Storz in his own body, and of course this also apply self-service benefit of a K-Active Tape.
<G-vec00272-001-s065><apply.anwenden><de> Am Ende des Workshops konnten die Teilnehmer die Wirkungen der Storz Stoßwellentherapie am eigenen Leib erfahren, diese auch selbst anwenden und natürlich begleitend in den Genuss eines K-Active Tapes kommen.
<G-vec00272-001-s066><apply.anwenden><en> Once we have defined the Roles in the Tag Type, we are ready to apply them.
<G-vec00272-001-s066><apply.anwenden><de> Sobald wir die Funktionen im Rahmen des jeweiligen Elementtyps definiert haben, können wir sie im Anschluß unmittelbar anwenden.
<G-vec00272-001-s067><apply.anwenden><en> The same rules as of it BK Powertool Dragracing apply.
<G-vec00272-001-s067><apply.anwenden><de> Die gleichen Regeln wie davon BK Powertool Dragracing anwenden.
<G-vec00272-001-s068><apply.anwenden><en> If you are first to act, you only need to look at the stack sizes of the players remaining to determine if you can apply the concept.
<G-vec00272-001-s068><apply.anwenden><de> Wenn du als erster an der Reihe bist musst du nur die Stacks der anderen Spieler in Betracht ziehen um zu entscheiden, ob du das Konzept anwenden kannst.
<G-vec00272-001-s069><apply.anwenden><en> If the object does not function with the hotspot, one can apply the selected object to another hotspot or put it back again with right-click.
<G-vec00272-001-s069><apply.anwenden><de> Falls das Objekt nicht mit dem Hotspot funktioniert, kann man das ausgewählte Objekt auf einen anderen Hotspot anwenden oder es mit Rechtsklick wieder ins Inventar legen.
<G-vec00272-001-s070><apply.anwenden><en> This formulation is superb since you do not have to apply anything to or around the anus.
<G-vec00272-001-s070><apply.anwenden><de> Diese Formulierung ist hervorragend, da Sie etwas oder um den Anus nicht anwenden müssen.
<G-vec00272-001-s071><apply.anwenden><en> When the Scripture says that we are to 'prove all things', we should apply that especially to the things which could serve the evil powers in their propaganda of suspicions, leading to divisions.
<G-vec00272-001-s071><apply.anwenden><de> Wenn die Schrift sagt, wir sollten «alles prüfen», sollten wir dies besonders auf die Dinge anwenden, die den bösen Mächten in ihrer Propaganda und ihrem Misstrauen helfen könnten, Trennungen zu verursachen.
<G-vec00272-001-s072><apply.anwenden><en> Since the start of the Advanced Clinical Courses, L.RonHubbard had been developing processes that could be taught, that auditors could apply.
<G-vec00272-001-s072><apply.anwenden><de> Seit dem Beginn der Fortgeschrittenen Wissenschaftlichen Kurse hatte L. Ron Hubbard Prozesse entwickelt, die gelehrt werden konnten und die Auditoren anwenden konnten.
<G-vec00272-001-s073><apply.anwenden><en> We may use your IP address in cooperation with your Internet access provider in order to identify you in the case of having to apply conditions of use to protect our services and clients, or in order to comply with laws in force.
<G-vec00272-001-s073><apply.anwenden><de> Wir können Ihre IP-Adresse in Zusammenarbeit mit Ihrem Internetanbieter für Ihre Identifizierung nutzen, für den Fall, dass wir die Nutzungsbedingungen zum Schutz unserer Dienste, Kunden oder für die Einhaltung der geltenden Gesetze anwenden müssen.
<G-vec00272-001-s074><apply.anwenden><en> And if worked out well, it will become a service that you can take, a product that is visible and a technology that we can apply.
<G-vec00272-001-s074><apply.anwenden><de> Und wenn es fertig ausgearbeitet ist, wird es eine Dienstleistung werden, die Ihr nehmen könnt, ein sichtbares Produkt und eine Technologie, die wir anwenden können.
<G-vec00272-001-s075><apply.anwenden><en> This lets you do editing by layer, apply different color palettes, modify RGB and grayscale values, among other tasks.
<G-vec00272-001-s075><apply.anwenden><de> Auf diese Weise können Sie durch die Ebenen bearbeiten, unterschiedliche Farbpaletten anwenden, RGB und Graustufen-Werte ändern, neben anderen Aufgaben.
<G-vec00272-001-s114><apply.anwenden><en> Therefore, varnished floorboard is recommended to periodically apply a protective coating.
<G-vec00272-001-s114><apply.anwenden><de> Daher wird lackierten Bodenplatte empfohlen, regelmäßig eine Schutzbeschichtung anzuwenden.
<G-vec00272-001-s115><apply.anwenden><en> The NCP also reminded the company of its responsibility for its supply chain and invited Devcot to carry out due diligence and to apply the recommendations of the OECD towards its trade partners.
<G-vec00272-001-s115><apply.anwenden><de> Die NKS weist das Unternehmen auf seine Verantwortung für die Zulieferkette hin und forderte es auf, eine sorgfältige Prüfung („due diligence“) durchzuführen und die OECD-Leitsätze auch im Verhältnis zu ihren Handelspartnern anzuwenden.
<G-vec00272-001-s116><apply.anwenden><en> As a result of a ruling by the German Federal Fiscal Court (BFH) published recently by the German Federal Ministry of Finance on page 367 of Part II of the Federal Tax Gazette 2011, there is a risk that Deutsche EuroShop AG may no longer be able to apply the above-mentioned tax treatment in future.
<G-vec00272-001-s116><apply.anwenden><de> Aufgrund eines kürzlich vom Bundesministerium der Finanzen im Bundessteuerblatt II 2011, Seite 367, veröffentlichten Urteils des Bundesfinanzhofes (BFH) besteht das Risiko, dass die o. g. steuerliche Handhabung für die Deutsche EuroShop AG zukünftig nicht mehr anzuwenden ist.
<G-vec00272-001-s117><apply.anwenden><en> In the English league rule apply inheritance and promotion.
<G-vec00272-001-s117><apply.anwenden><de> In der englischen Liga Regel anzuwenden Erbe und Förderung .
<G-vec00272-001-s118><apply.anwenden><en> To apply existing assistive technologies frameworks, sensors, and actuators, and furthermore to independently realize software components for the practical, simple integration of specific hardware control elements
<G-vec00272-001-s118><apply.anwenden><de> bestehende Assistive Technologies Frameworks, Sensoren und Aktoren anzuwenden und in weiterer Folge selbst Software-Komponenten zur einfachen Integration von spezifischen Hardware-Bedienelementen praktisch umzusetzen.
<G-vec00272-001-s119><apply.anwenden><en> The Bachelor's programme aims to provide an overview of the fundamental interrelationships in the renewable energy sector, to apply the acquired knowledge in the professional field and to be able to independently familiarise oneself with new tasks.
<G-vec00272-001-s119><apply.anwenden><de> Der Bachelorstudiengang zielt darauf, einen Überblick über die grundlegenden Zusammenhänge des Sektors der Erneuerbaren Energien zu bieten, die erworbenen Kenntnisse im Berufsfeld anzuwenden und in der Lage zu sein, sich selbstständig in neue Aufgabenstellungen einarbeiten zu können.
<G-vec00272-001-s120><apply.anwenden><en> The compound is anaerobic, sensor safe and very easy to apply.
<G-vec00272-001-s120><apply.anwenden><de> Das Produkt ist anaerob, thixotrop und sehr einfach anzuwenden.
<G-vec00272-001-s121><apply.anwenden><en> • In the columns of Il Giornale (Italy), Olan Micalessin denounces Hillary Clinton for wanting to apply the Libyan plan to Syria.
<G-vec00272-001-s121><apply.anwenden><de> • Olan Micalessin denunziert im Il Giornale den Willen von Hillary Clinton, ihren libyschen Plan auf Syrien anzuwenden.
<G-vec00272-001-s122><apply.anwenden><en> The ability to apply fundamental techniques and tools in the computing disciplines.
<G-vec00272-001-s122><apply.anwenden><de> Die Fähigkeit, grundlegende Techniken und Werkzeuge in den Computerdisziplinen anzuwenden.
<G-vec00272-001-s123><apply.anwenden><en> What's more, we provide support to our customers who want to apply virtual human simulation methods themselves.
<G-vec00272-001-s123><apply.anwenden><de> Darüber hinaus unterstützen wir unser Auftraggeber, Methoden der Virtual Human Simulation auch selbstständig anzuwenden.
<G-vec00272-001-s124><apply.anwenden><en> HEIMESS helps the very youngest children to discover the world through simple shapes and colours and to apply their newly acquired skills.
<G-vec00272-001-s124><apply.anwenden><de> HEIMESS hilft den allerkleinsten Kindern durch einfache Formen und Farben, die Welt zu entdecken und die neuerworbenen Fähigkeiten anzuwenden.
<G-vec00272-001-s125><apply.anwenden><en> Since all these settings are locating in separately in Word, it's not easy for us to remember and apply them when we need to.
<G-vec00272-001-s125><apply.anwenden><de> Da alle diese Einstellungen separat in Word gefunden werden, ist es für uns nicht einfach, sie zu speichern und sie bei Bedarf anzuwenden.
<G-vec00272-001-s126><apply.anwenden><en> In Mr. Nada's case, a man with perfect references, against whom no charge was found, to continue to apply the sanctions against him is simply to obey the diktat of the United States and to accept the reign of arbitrariness and lawlessness.
<G-vec00272-001-s126><apply.anwenden><de> Weiterhin gegen Herrn Nada, einen Mann mit ausgezeichneten Empfehlungen, gegen den kein belastendes Material vorliegt, Sanktionen anzuwenden, bedeutet ganz einfach sich dem Diktat der Vereinigten Staaten zu beugen und die Herrschaft der Willkür und der Rechtlosigkeit zu akzeptieren.
<G-vec00272-001-s127><apply.anwenden><en> An attempt was made to apply a matrix operation to two matrices of different data types.
<G-vec00272-001-s127><apply.anwenden><de> Es wurde versucht, eine Matrix-Operation auf zwei Matrizen unterschiedlichen Datentyps anzuwenden.
<G-vec00272-001-s128><apply.anwenden><en> If you are heading out after a tedious day, speedily apply matte powder to oily areas.
<G-vec00272-001-s128><apply.anwenden><de> Wenn Sie Position heraus nach einer langweiligen Tag, matte Pulver schnell auf öligen Bereichen anzuwenden.
<G-vec00272-001-s129><apply.anwenden><en> This principle, however, by definition does not apply to third parties so that it cannot be deduced from it that the EPO is under an obligation to apply the TRIPS Agreement, even if this might be desirable in the interest of international harmonisation of substantive patent law.
<G-vec00272-001-s129><apply.anwenden><de> Dieser Grundsatz gilt aber per definitionem nicht für Dritte, so daß daraus nicht abgeleitet werden kann, daß das EPA verpflichtet ist, das TRIPS-Übereinkommen anzuwenden, so wünschenswert dies im Interesse der internationalen Harmonisierung des materiellen Patentrechts wäre.
<G-vec00272-001-s130><apply.anwenden><en> We've trained our AI Style Engine for PowerDirector to analyze your footage frame by frame and intelligently apply brushstrokes so your video looks like moving Chinese traditional paintings.
<G-vec00272-001-s130><apply.anwenden><de> Wir haben unsere AI Style Engine für PowerDirector trainiert, um Ihr Filmmaterial Bild für Bild zu analysieren und Pinselstriche intelligent anzuwenden, damit Ihr Video wie bewegte chinesische Gemälde aussieht.
<G-vec00272-001-s131><apply.anwenden><en> Answer from such purpose that human experience of the priest does not need to apply their own horizon of the secular - economy, finance, militia, politics, family, technology, industry and commerce -, because it focuses on human values â â that are at the root and the purpose of existence, more relevant to the meaning of life and history, to the problem of suffering, of sin and salvation, the need for truth, of Justice, of peace, of freedom and happiness, the moral values, Religious and Spiritual, the relationship with God.
<G-vec00272-001-s131><apply.anwenden><de> Antwort von einem solchen Zweck dass die menschliche Erfahrung des Priesters muss nicht ihren eigenen Horizont der säkularen anzuwenden - Wirtschaft, Finanzen, Miliz, Politik, Familie, Technologie, Industrie und Handel -, weil es konzentriert sich auf menschliche Werte, die an der Wurzel und den Zweck der Existenz, mehr relevant für den Sinn des Lebens und der Geschichte, auf das Problem des Leidens, von Sünde und Erlösung, das Bedürfnis nach Wahrheit, der Gerechtigkeit, Frieden, von Freiheit und Glück, die moralischen Werte, Religiöse und spirituelle, die Beziehung zu Gott.
<G-vec00272-001-s132><apply.anwenden><en> “TAKT Academy enabled us, the young undergraduates, to practically apply our acquired theoretical knowledge.
<G-vec00272-001-s132><apply.anwenden><de> „Die TAKT Akademie hat uns, den jungen Diplomanden, ermöglicht, unsere erlangten theoretischen Kenntnisse jetzt auch in der Praxis anzuwenden.
<G-vec00272-001-s171><apply.auftragen><en> Clean the screws, apply GLEITMO 165 to the thread root and the contact surface of the screw head without excess using a paint brush or spray on.
<G-vec00272-001-s171><apply.auftragen><de> Schrauben reinigen, GLEITMO 165 mit Pinsel bis auf den Gewindegrund und auf der Auflagefläche des Schraubenkopfes ohne Überschuss auftragen oder aufsprühen.
<G-vec00272-001-s172><apply.auftragen><en> Apply Strobing Powder using the Eye Shadow Brush large and blend in.
<G-vec00272-001-s172><apply.auftragen><de> Strobing Powder mit dem Eye Shadow Brush large auftragen und verblenden.
<G-vec00272-001-s173><apply.auftragen><en> Use: Apply generously to clean, wet hair from roots to ends, massage in and leave for 3 to 5 minutes.
<G-vec00272-001-s173><apply.auftragen><de> Anwendung: Großzügig auf sauberes, feuchtes Haar von den Wurzeln bis zu den Spitzen auftragen, einmassieren und 3 bis 5 Minuten einwirken lassen.
<G-vec00272-001-s174><apply.auftragen><en> Apply a thin layer of the Nude Illusion Make Up and blend with the Camouflage Cream.
<G-vec00272-001-s174><apply.auftragen><de> Das Nude Illusion Make Up dünn auftragen und mit der Camouflage Cream verblenden.
<G-vec00272-001-s175><apply.auftragen><en> Keiki initiation will be better if: you apply KEIKIBOOST one week at least after the last flower fell, apply KEIKI on the lower nodes only or if you want to higher your chance for a flower spike, then apply KEIKIBOOST to the upper nodes.
<G-vec00272-001-s175><apply.auftragen><de> Keiki initiation ist höher: wenn Sie KEIKIBOOST eine Woche nach den Verlust der letzten Blüte auftragen, tragen Sie KEIKIBOOST auf den ersten Knoten auf, im falle das Sie neue Blüten möchten tragen Sie KEIKIBOOST auf den höhern Knoten auf.
<G-vec00272-001-s176><apply.auftragen><en> To treat various ailments apply the leaves of the culture, which knead before use or make from them juice.
<G-vec00272-001-s176><apply.auftragen><de> Zur Behandlung verschiedener Beschwerden die Blätter der Kultur auftragen, die vor Gebrauch kneten oder daraus Saft herstellen.
<G-vec00272-001-s177><apply.auftragen><en> Apply generously to clean, exfoliated skin.
<G-vec00272-001-s177><apply.auftragen><de> Großzügig auf die gereinigte, gepeelte Haut auftragen.
<G-vec00272-001-s178><apply.auftragen><en> Maintenance cleaning: dilute concentrate 1:50 (200 ml to 10 liters) and apply.
<G-vec00272-001-s178><apply.auftragen><de> Unterhaltsreinigung: Konzentrat 1:50 (200 ml auf 10 Liter) verdünnen und auftragen.
<G-vec00272-001-s179><apply.auftragen><en> Apply several times a day to hands and gently massage in.
<G-vec00272-001-s179><apply.auftragen><de> Mehrmals täglich auf die Hände auftragen und sanft einmassieren.
<G-vec00272-001-s180><apply.auftragen><en> For heavily soiled parts and surfaces: Apply concentrated product with a soft brush or spray.
<G-vec00272-001-s180><apply.auftragen><de> Bei stark verschmutzten Teilen und Oberflächen: Konzentriertes Produkt mit einer weichen Bürste oder einem Sprühgerät auftragen.
<G-vec00272-001-s181><apply.auftragen><en> It's important to powder the face first and then apply the Cream to Powder Blush as a colour highlight.
<G-vec00272-001-s181><apply.auftragen><de> Wichtig: Erst das Gesicht abpudern und danach den Cream To Powder Blush als farbliches Highlight auftragen.
<G-vec00272-001-s182><apply.auftragen><en> Apply to skin and massage unitl oil is completely absorbed.
<G-vec00272-001-s182><apply.auftragen><de> Haut auftragen und Massage unitl Öl wird vollständig resorbiert.
<G-vec00272-001-s183><apply.auftragen><en> Apply oil extracted from the shell of the cashew nuts.
<G-vec00272-001-s183><apply.auftragen><de> Extrahiert aus der Schale von Cashew-Nüssen Öl auftragen.
<G-vec00272-001-s184><apply.auftragen><en> For immediate glow, apply a thick layer of the Resurfacing Mask on a clean face.
<G-vec00272-001-s184><apply.auftragen><de> Für sofortiges Strahlen und Glanz eine dicke Schicht der Resurfacing Mask auf das gereinigte Gesicht auftragen.
<G-vec00272-001-s185><apply.auftragen><en> Apply generously to wet footwear; Spray-On (from a distance of 5cm) or Sponge-On.
<G-vec00272-001-s185><apply.auftragen><de> Großzügig auf nasse Schuhe auftragen; Spray (aus einer Entfernung von 5cm) oder Schwammapplikator.
<G-vec00272-001-s186><apply.auftragen><en> In the morning apply locally on the inflammatory areas.
<G-vec00272-001-s186><apply.auftragen><de> Morgens lokal auf die entzündlichen Partien auftragen.
<G-vec00272-001-s187><apply.auftragen><en> To facilitate procedure, the assistant who will apply paraffin can be necessary for you.
<G-vec00272-001-s187><apply.auftragen><de> Um die Prozedur zu erleichtern, kann sich Ihnen der Helfer benötigen, der das Paraffin auftragen wird.
<G-vec00272-001-s188><apply.auftragen><en> Apply onto the face with a puff or powder brush.
<G-vec00272-001-s188><apply.auftragen><de> Auf das Gesicht mit einer Quaste oder einem Pinsel auftragen.
<G-vec00272-001-s189><apply.auftragen><en> Nordson hot melt machines and adhesive dispensing systems apply adhesives, sealants and coatings in a variety of patterns to consumer and industrial products in packaging, product assembly and nonwoven applications.
<G-vec00272-001-s189><apply.auftragen><de> Die Klebstoffauftrags- und Schmelzklebstoffsysteme von Nordson dienen zum Auftragen von Klebstoffen, Dichtstoffen und Beschichtungen in verschiedensten Formen für Verbraucher- und Industrieprodukte bei Verpackungen, Anwendungen in der Produktmontage und Vliesstoffen.
<G-vec00272-001-s190><apply.auftragen><en> To get a decent result, it is enough to apply this mixture on your face every day for a month.
<G-vec00272-001-s190><apply.auftragen><de> Um ein anständiges Ergebnis zu erzielen, reicht es aus, diese Mischung jeden Monat jeden Tag auf Ihr Gesicht aufzutragen.
<G-vec00272-001-s191><apply.auftragen><en> The excellent quality of waxes used makes these crayons are easy to apply and perfect for all coloring techniques, including the graffiti.
<G-vec00272-001-s191><apply.auftragen><de> Die hervorragende Qualität der Wachse verwendet diese Stifte einfach aufzutragen und perfekt für alle Färbung-Techniken sind, einschließlich der Graffiti macht.
<G-vec00272-001-s192><apply.auftragen><en> It is a very special and very noble way to apply perfume: with the Kabuki brush, you can apply deliciously scented perfume powder to your skin.
<G-vec00272-001-s192><apply.auftragen><de> Es stellt eine spezielle und zugleich besonders noble Art dar, Parfum aufzutragen: Mit dem geschmeidigen Kabuki-Pinsel wird die Haut mit zart duftendem Parfum-Puder bestäubt.
<G-vec00272-001-s193><apply.auftragen><en> Before giving by liquid dark chocolate to apply drawing on a white surface.
<G-vec00272-001-s193><apply.auftragen><de> Vor der Abgabe von der flüssigen schwarzen Schokolade, auf die weiße Oberfläche die Zeichnung aufzutragen.
<G-vec00272-001-s194><apply.auftragen><en> "It is enough to first stretch the pavilion sideways like a harmonica, apply the material, and then pull up the corners upwards until it ""clicks"" the lock."
<G-vec00272-001-s194><apply.auftragen><de> Es reicht aus, den Pavillon zunächst wie eine Mundharmonika seitwärts zu strecken, das Material aufzutragen und dann die Ecken nach oben zu ziehen, bis das Schloss einrastet.
<G-vec00272-001-s195><apply.auftragen><en> Serrated scrapers are used to apply adhesives and paste glues to large areas when doing bonding work.
<G-vec00272-001-s195><apply.auftragen><de> Zahnspachtel werden eingesetzt, um Klebstoffe und Leime bei großflächigen Verklebungen aufzutragen.
<G-vec00272-001-s196><apply.auftragen><en> Generally, you won't need to apply conditioner higher than halfway up the length of your hair unless hair is noticeably dry near your scalp.
<G-vec00272-001-s196><apply.auftragen><de> Im Allgemeinen brauchst du die Spülung nicht weiter als bis zur Hälfte der Haarlänge aufzutragen, es sei denn, dein Haar ist auch nahe der Kopfhaut merklich trocken.
<G-vec00272-001-s197><apply.auftragen><en> Therefore, be careful not to apply it over a wide area, but only selectively or in (wave) lines.
<G-vec00272-001-s197><apply.auftragen><de> Achtet deshalb darauf, ihn nicht flächig, sondern nur punktuell oder in (Wellen-)Linien aufzutragen.
<G-vec00272-001-s198><apply.auftragen><en> It is easiest to apply glue with the pallet.
<G-vec00272-001-s198><apply.auftragen><de> Am meisten ist es leichter, den Leim schpatelem aufzutragen.
<G-vec00272-001-s199><apply.auftragen><en> Technical Sheet 1,000 ways to apply fragrance...
<G-vec00272-001-s199><apply.auftragen><de> 1000 Möglichkeiten, .Parfüm aufzutragen...
<G-vec00272-001-s200><apply.auftragen><en> When using barely opaque colour tones, after a corresponding flash time (matt stripped) it might be necessary to apply additional paint processes.
<G-vec00272-001-s200><apply.auftragen><de> Bei schwach deckenden Farbtönen kann es nach entsprechender Ablüftzeit (matt abgezogen) notwendig sein, weitere Spritzgänge aufzutragen.
<G-vec00272-001-s201><apply.auftragen><en> Heat resistance 316 stainless steel has good oxidation resistance in intermittent use below 1600 °C and continuous use below 1700 °C. In the range of 800-1575 degrees, it is preferable not to continuously apply 316 stainless steel, but when 316 stainless steel is continuously used outside this temperature range, the stainless steel has good heat resistance.
<G-vec00272-001-s201><apply.auftragen><de> Hitzebeständigkeit Edelstahl 316 hat eine gute Oxidationsbeständigkeit bei intermittierender Verwendung unter 1600 ° C und kontinuierlicher Verwendung unter 1700 ° C. Im Bereich von 800 bis 1575 Grad ist es bevorzugt, 316-Edelstahl nicht kontinuierlich aufzutragen, aber wenn 316-Edelstahl kontinuierlich außerhalb dieses Temperaturbereichs verwendet wird, weist der Edelstahl eine gute Wärmebeständigkeit auf.
<G-vec00272-001-s202><apply.auftragen><en> It is permissible to apply tincture of ginseng or eleutherococcus once before the arrival of the doctor.
<G-vec00272-001-s202><apply.auftragen><de> Es ist zulässig, einmal Ginseng oder Eleutherococcus Tinktur vor der Ankunft des Arztes aufzutragen.
<G-vec00272-001-s203><apply.auftragen><en> After drying of glue rather simply accurately to separate a snowflake from paper, to apply on it glue by means of a brush and to strew with spangles.
<G-vec00272-001-s203><apply.auftragen><de> Nach dem Austrocknen des Leims genug einfach akkurat, die Schneeflocke vom Papier abzutrennen, auf sie den Leim mit Hilfe des kleinen Pinsels aufzutragen und, blestkami zu bestreuen.
<G-vec00272-001-s204><apply.auftragen><en> At external use of sea-buckthorn oil it is necessary to clear the damaged skin site, to apply oil by means of a pipette and to apply a gauze bandage.
<G-vec00272-001-s204><apply.auftragen><de> Bei der äusserlichen Nutzung oblepichowogo die Öle muss man das beschädigte Grundstück der Haut reinigen, das Öl mit Hilfe der Pipette aufzutragen und, marlewuju die Binde aufzuerlegen.
<G-vec00272-001-s205><apply.auftragen><en> The natural colour lasts up to 24 hours and is easy to apply.
<G-vec00272-001-s205><apply.auftragen><de> Die natürliche Farbe hält bis zu 24 Stunden und ist einfach aufzutragen.
<G-vec00272-001-s206><apply.auftragen><en> A bulb guaranteed to contain no PVC Countless customization options 1,000 ways to apply fragrance...
<G-vec00272-001-s206><apply.auftragen><de> Ballonzerstäuber garantiert ohne PVC Zahllose individualisierbare Optionen 1000 Möglichkeiten, .Parfüm aufzutragen...
<G-vec00272-001-s207><apply.auftragen><en> Now to apply makeup, simply introduce a small amount of makeup onto beautyblender® top or bottom surface.
<G-vec00272-001-s207><apply.auftragen><de> Nun, um das Make-up aufzutragen, einfach eine kleine Menge von Make-up auf obere oder untere Oberfläche des beautyblender® oder direkt auf die Haut geben.
<G-vec00272-001-s208><apply.auftragen><en> There are three main ways of strengthening of eyelashes: to apply nutritious mix on eyelashes, on skin of eyelids and to do their massage.
<G-vec00272-001-s208><apply.auftragen><de> Es gibt drei Haupt- Weisen der Festigung der Wimpern: die nahrhafte Mischung auf die Wimpern aufzutragen, auf die Haut Jahrhundert und ihre Massage zu machen.
<G-vec00272-001-s209><apply.beantragen><en> If your child never lived in Germany but lived within the EU/EEA, you can still apply for the benefit if you worked in Germany.
<G-vec00272-001-s209><apply.beantragen><de> Wenn Ihr Kind nie in Deutschland gelebt hat, aber in einem EU / EWR Land, können Sie diese Vergünstigung beantragen, wenn Sie in Deutschland gearbeitet haben.
<G-vec00272-001-s210><apply.beantragen><en> Gueststudents from other countries generally need to apply for a visa before arrival.
<G-vec00272-001-s210><apply.beantragen><de> Gaststudierende aus anderen Ländern müssen in der Regel vor der Einreise ein Visum beantragen.
<G-vec00272-001-s211><apply.beantragen><en> Contact the local Swiss representative or consulate when you want to register or unregister as a resident, when you need a new pass, have moved or wish to apply for citizenship.
<G-vec00272-001-s211><apply.beantragen><de> Dienstleistungen Schliessen Dienstleistungen Wenden Sie sich an die zuständige Schweizer Vertretung, wenn Sie sich an- oder abmelden möchten, neue Ausweise benötigen, umgezogen sind oder das Bürgerrecht beantragen möchten.
<G-vec00272-001-s212><apply.beantragen><en> Anyone who is resident in Germany can apply for a library card in person by visiting ZB MED.
<G-vec00272-001-s212><apply.beantragen><de> Alle Personen, deren Wohnsitz in Deutschland liegt, können bei ZB MED vor Ort persönlich einen Bibliotheksausweis beantragen.
<G-vec00272-001-s213><apply.beantragen><en> As available in specified regions, if you choose to apply for a Choice Privileges Visa card, you will be linked from Choice's website to Barclays Bank Delaware's website and will be required to enter certain personally identifiable information as part of the credit application process.
<G-vec00272-001-s213><apply.beantragen><de> "Wenn Sie eine ""Choice Privileges Visa""-Karte beantragen, werden Sie in bestimmten Regionen, in denen dies möglich ist, von der Website von Choice an die Website der Barclays Bank Delaware weitergeleitet, wo Sie im Rahmen der Beantragung der Kreditkarte bestimmte personenbezogene Daten bereitstellen müssen."
<G-vec00272-001-s214><apply.beantragen><en> I also had to apply for holidays as it took place during the week.
<G-vec00272-001-s214><apply.beantragen><de> Ferientage musste ich auch beantragen, da es unter der Woche stattfand.
<G-vec00272-001-s215><apply.beantragen><en> You need to apply for a visa in person from the German representation abroad in the territory of which you live whilst still in your home country.
<G-vec00272-001-s215><apply.beantragen><de> Ein Visum müssen Sie noch in Ihrem Heimatland persönlich bei der deutschen Auslandsvertretung beantragen, in deren Amtsbezirk Sie leben.
<G-vec00272-001-s216><apply.beantragen><en> The Schleswig-Holstein parliament passed the Gaming Reform Act (GRA) in September of 2011, which allows online casinos and poker rooms (and possibly sportsbooks) to apply for a license to operate games of chance online in their state, provided they pay a fee of 20% of gross revenues for that right.
<G-vec00272-001-s216><apply.beantragen><de> Das Schleswig-Holstein Parlament verabschiedete den Gaming Reform Act (GRA) im September 2011, die erlaubt Online-Casinos und Poker Zimmer (und möglicherweise Macher) für eine Lizenz beantragen Glücksspiele Online in ihrem Zustand zu betreiben, sofern sie eine Gebühr von 20% der Bruttoeinnahmen für dieses Recht bezahlen.
<G-vec00272-001-s217><apply.beantragen><en> Send this form to the national employment services in the country where you wish to apply for benefits, so they can take account of any periods of social security cover or employment in other countries.
<G-vec00272-001-s217><apply.beantragen><de> Schicken Sie dieses Formular an die nationale Arbeitsvermittlungsstelle des Landes, in dem Sie Leistungen beantragen möchten, so dass sie Zeiten des Sozialversicherungsschutzes oder der Beschäftigung in anderen Ländern berücksichtigen kann.
<G-vec00272-001-s218><apply.beantragen><en> Employees should apply for membership with their ID card at the Academic Office.
<G-vec00272-001-s218><apply.beantragen><de> Mitarbeitende beantragen die Mitgliedschaft mit ihrem Personalausweis beim Studiensekretariat.
<G-vec00272-001-s219><apply.beantragen><en> While the student visa for entry (in a Schengen state) is valid, you must apply at the local immigration office for a residence permit for study purposes (§ 16).
<G-vec00272-001-s219><apply.beantragen><de> Innerhalb der Gültigkeit des Studienvisums zur Einreise (in ein Schengen-Staat) müssen Sie eine Aufenthaltsgenehmigung zu Studienzwecken (§ 16) bei der Ausländerbehörde vor Ort beantragen.
<G-vec00272-001-s220><apply.beantragen><en> However, if you only want to work with Adarvo over the Internet, without using the program itself, you can also apply for a new account via this link and access the theme in this way.
<G-vec00272-001-s220><apply.beantragen><de> Für den Fall, dass Sie nur via Internet mit Adarvo arbeiten möchten, ohne das Programm selbst zu verwenden, können Sie auch über diesen Link ein neues Konto beantragen und Zugang zum Thema erhalten.
<G-vec00272-001-s221><apply.beantragen><en> After his release, he no longer dared to apply for assistance, despite renewed unemployment.
<G-vec00272-001-s221><apply.beantragen><de> Nach seiner Entlassung traute er sich trotz erneuter Arbeitslosigkeit nicht mehr, Unterstützung zu beantragen.
<G-vec00272-001-s222><apply.beantragen><en> Before they can apply for a visa, they will need their future host family to apply at their regional immigration service for a B work permit and send it to their future Au Pair.
<G-vec00272-001-s222><apply.beantragen><de> Bevor das Au Pair allerdings ein Visum beantragen kann, muss die zukünftige Gastfamilie beim regionalen Immigrationsservice eine B-Work Arbeitserlaubnis einholen und dem Au Pair zu schicken.
<G-vec00272-001-s223><apply.beantragen><en> After the application deadline, we will send you additional useful information as well as the letter of acceptance which you might need in order to apply for a visa, etc.
<G-vec00272-001-s223><apply.beantragen><de> Nach Ablauf der Bewerbungsfrist erhalten Sie von uns weitere nützliche Informationen sowie die Annahmeerklärung, die Sie eventuell benötigen, um ein Visum zu beantragen.
<G-vec00272-001-s224><apply.beantragen><en> If no national technical approval is available for the intended application, itwill be necessary to apply for individual approval for using the VIPs.
<G-vec00272-001-s224><apply.beantragen><de> Liegt für die geplante Anwendung noch keine allgemeine bauaufsichtliche Zulassung vor, so ist für die Verwendung der VIP eine Zustimmung im Einzelfall zu beantragen.
<G-vec00272-001-s225><apply.beantragen><en> If you're not from any of the countries mentioned you should contact the Swedish consulate in your home country in order to apply for a work permit before you leave for Sweden.
<G-vec00272-001-s225><apply.beantragen><de> Wenn Sie sich nicht aus einem der genannten Länder wenden Sie sich bitte an die schwedische Konsulat in Ihrem Heimatland, um eine Arbeitserlaubnis beantragen, bevor Sie für Schweden.
<G-vec00272-001-s226><apply.beantragen><en> every place that you go to apply for a loan turns you down without a second thought.
<G-vec00272-001-s226><apply.beantragen><de> jeder Platz, dem Sie gehen, Umdrehungen eines Darlehens Sie unten zu beantragen ohne eine reifliche Überlegung.
<G-vec00272-001-s227><apply.beantragen><en> Those from countries outside the EU may need to apply for a visa in advance.
<G-vec00272-001-s227><apply.beantragen><de> Besucher aus Nicht-EU-Ländern müssen wahrscheinlich ein Visum im Voraus beantragen.
<G-vec00272-001-s247><apply.sich_bewerben><en> They encouraged me to apply for the position of environmental manager, after they saw how I took action against Lufthansa and how I stood up for the taxation of environmental pollution in air traffic and shifting subsidies to the train traffic.
<G-vec00272-001-s247><apply.sich_bewerben><de> Die regten es an, dass ich mich auf eine Stelle als Umweltmanager bewerben solle, da sie gesehen haben, wie ich gegen die Lufthansa vorgegangen bin und mich politisch für die Besteuerung der Umweltbelastungen im Flugverkehr und eine Entlastung der Bahn eingesetzt habe.
<G-vec00272-001-s248><apply.sich_bewerben><en> Applicants for the Millsaps MBA or MAcc programs should apply directly to the Graduate School.
<G-vec00272-001-s248><apply.sich_bewerben><de> Bewerber für die Millsaps MBA oder Macc Programme sollten direkt an die Graduate School bewerben.
<G-vec00272-001-s249><apply.sich_bewerben><en> Once parents have sufficiently informed themselves and decided for one establishment or the other, they can then simply apply online for a place of their choice.
<G-vec00272-001-s249><apply.sich_bewerben><de> Die Eltern wiederum können sich, nachdem sie sich ausreichend informiert und für eines oder mehrere Angebote entschieden haben, bei den gewünschten Einrichtungen ganz einfach online um einen Platz bewerben.
<G-vec00272-001-s250><apply.sich_bewerben><en> The whole experience was so enjoyable that Heather wanted to do it again so we did and we tried to get a certificate at the information centre in Hornsea, but they told us to apply to you.
<G-vec00272-001-s250><apply.sich_bewerben><de> Die ganze Erfahrung war so angenehm, dass Heather es tun wollte wieder so wir haben und wir haben versucht, ein Zertifikat im Informationszentrum in Hornsea zu erhalten, aber sie sagten uns, euch zu bewerben.
<G-vec00272-001-s251><apply.sich_bewerben><en> HireArt: Fill out one lengthy application (including video), and apply to multiple startup jobs with one application.
<G-vec00272-001-s251><apply.sich_bewerben><de> HireArt: Füllen Sie eine längere Anwendung (einschließlich Video), und mit einer Anwendung auf mehrere Start Jobs bewerben.
<G-vec00272-001-s252><apply.sich_bewerben><en> Hair Tip:Simply apply a handful of styling aerosol to your tresses and hold your head upside down whenever you enable the styling spray to dry.
<G-vec00272-001-s252><apply.sich_bewerben><de> Einfach bewerben eine Handvoll – styling sprühen, um Ihre locken und halten Ihre Kopf invertiert, wenn Sie lassen Sie die – styling sprühen trocken.
<G-vec00272-001-s253><apply.sich_bewerben><en> In order not to lose a whole year, I decided to apply to Hamburg University of Applied Sciences for the summer semester.
<G-vec00272-001-s253><apply.sich_bewerben><de> Um nicht ein ganzes Jahr zu verlieren, habe ich entschieden, mich bei der HAW Hamburg im Sommersemester zu bewerben.
<G-vec00272-001-s254><apply.sich_bewerben><en> Against this background, the teachers, pupils and their parents decided to apply to participate in the 'Inclusive School' pilot project.
<G-vec00272-001-s254><apply.sich_bewerben><de> "Auf dieser Grundlage entschieden sich Lehrer, Schüler und Eltern, sich für das Pilotprojekt ""Inklusive Schule"" zu bewerben."
<G-vec00272-001-s255><apply.sich_bewerben><en> But even if uni-assist is responsible for applications to the degree course, it might be possible that you have to apply directly to the university if you have to visit the preparatory German language course.
<G-vec00272-001-s255><apply.sich_bewerben><de> Aber auch wenn uni-assist für die Bewerbung zum Fachstudium zuständig ist, kann es sein, dass Sie sich trotzdem direkt an der Hochschule bewerben müssen, weil Sie vorab den studienvorbereitenden Deutsch-Kurs besuchen müssen.
<G-vec00272-001-s256><apply.sich_bewerben><en> When you are ready to submit your application, click the Apply button on the last page.
<G-vec00272-001-s256><apply.sich_bewerben><de> Wenn Ihre Bewerbung versandfertig ist, klicken Sie auf der letzten Seite auf Bewerben.
<G-vec00272-001-s257><apply.sich_bewerben><en> For domestic use Apply every evening to face and neck before applying the cream Dermagen GOLD.
<G-vec00272-001-s257><apply.sich_bewerben><de> Für den Hausgebrauch Bewerben jeden Abend auf Gesicht und Hals vor dem Auftragen der Creme Dermagen GOLD.
<G-vec00272-001-s258><apply.sich_bewerben><en> Women are therefore expressly invited to apply.
<G-vec00272-001-s258><apply.sich_bewerben><de> Frauen werden deshalb ausdrücklich aufgefordert, sich zu bewerben.
<G-vec00272-001-s259><apply.sich_bewerben><en> Why should I apply for the Data Analyst Bachelor's degree? You should enroll in the program because you will master the skills you need to establish a successful Data Science career.
<G-vec00272-001-s259><apply.sich_bewerben><de> Warum sollte ich mich für den Data Analyst Bachelor bewerben?Sie sollten sich für das Programm anmelden, weil Sie die Fähigkeiten beherrschen, die Sie für eine erfolgreiche Data Science-Karriere benötigen.
<G-vec00272-001-s260><apply.sich_bewerben><en> Students of philology programs (Bachelor and Master) can apply for two places in total through our cooperation program with the University of Leuven. The application can be for winter or summer semester in Belgium (Campus Antwerp).
<G-vec00272-001-s260><apply.sich_bewerben><de> Im Rahmen der Partnerschaft mit der KU Leuven können sich BA- und MA- Studierende philologischer Studiengänge der Heinrich-Heine-Universität für insgesamt zwei Plätze laufend zum Winter- sowie Sommersemester in Belgien (Campus Antwerpen) bewerben.
<G-vec00272-001-s261><apply.sich_bewerben><en> We would like to express an invitation to interested young members to apply and also ask all supervising members to address suitable doctoral candidates directly.
<G-vec00272-001-s261><apply.sich_bewerben><de> Wir möchten interessierte junge Mitglieder ausdrücklich auffordern sich zu bewerben und bitten zudem alle betreuenden Mitglieder geeignete Promovierende direkt anzusprechen.
<G-vec00272-001-s262><apply.sich_bewerben><en> Just apply with an email to info@caratart.de.
<G-vec00272-001-s262><apply.sich_bewerben><de> Einfach bewerben mit einer Email an info@caratart.de.
<G-vec00272-001-s263><apply.sich_bewerben><en> Apply Important information on your application for admission to a master's program We regularly receive incomplete applications that we cannot take into account.
<G-vec00272-001-s263><apply.sich_bewerben><de> Für den Studien­gang bewerben Wichtige Hinweise zu Ihrer Master­bewerbung Uns erreichen immer wieder unvollständige Bewerbungen, die wir nicht berücksichtigen können.
<G-vec00272-001-s264><apply.sich_bewerben><en> How do I apply? Interested parties should apply directly to the Permanent Representation in Paris.
<G-vec00272-001-s264><apply.sich_bewerben><de> InteressentInnen bewerben sich direkt bei der Ständigen Vertretung in Paris, wobei die Aufnahmekapazitäten aus finanziellen Gründen beschränkt sind.
<G-vec00272-001-s265><apply.sich_bewerben><en> Simply click on the 'Apply' button.
<G-vec00272-001-s265><apply.sich_bewerben><de> "Klicken Sie auf den Button ""Bewerben""."
<G-vec00272-001-s266><apply.sich_bewerben><en> You apply with a foreign certificate which you have acquired in a country outside Germany.
<G-vec00272-001-s266><apply.sich_bewerben><de> Sie bewerben sich mit einem ausländischen Zeugnis (Sekundarschulabschluss, Bachelor), das Sie in einem Land außerhalb Deutschlands erworben haben.
<G-vec00272-001-s267><apply.sich_bewerben><en> Please apply only online and add your CV, letter of motivation (online text field) and certificates to your application (max.
<G-vec00272-001-s267><apply.sich_bewerben><de> Bitte bewerben Sie sich ausschließlich online und fügen der Bewerbung Ihren Lebenslauf, ein Anschreiben im Motivationsfeld des Online-Formulars und Zeugnisse bei (max.
<G-vec00272-001-s268><apply.sich_bewerben><en> All those who have skills in relating to groups of people, experience in communicating complex subjects, and the will to be exposed to ideas, new experiences, artworks, and most important of all, to artists, please apply.
<G-vec00272-001-s268><apply.sich_bewerben><de> Wenn Sie Geschick im Umgang mit Gruppen und Erfahrung in der Vermittlung komplexer Inhalte haben, aufgeschlossen sind gegenüber Ideen, neuen Erfahrungen, Kunstwerken und vor allem auch Künstlerinnen und Künstlern – bitte bewerben Sie sich.
<G-vec00272-001-s269><apply.sich_bewerben><en> Please apply using our online application tool.
<G-vec00272-001-s269><apply.sich_bewerben><de> Bitte bewerben Sie sich über unser Online-Bewerbungstool.
<G-vec00272-001-s270><apply.sich_bewerben><en> Students apply through their university with an Erasmus Coordinator in their subject area.
<G-vec00272-001-s270><apply.sich_bewerben><de> Studenten bewerben sich über ihre Universität mit einem Erasmus-Koordinator in ihrem Fachgebiet.
<G-vec00272-001-s271><apply.sich_bewerben><en> Please apply via the C@MPUS Campus Management Portal .
<G-vec00272-001-s271><apply.sich_bewerben><de> Bitte bewerben Sie sich über das Campus-Management-Portal C@MPUS.
<G-vec00272-001-s272><apply.sich_bewerben><en> Please apply exclusively online.
<G-vec00272-001-s272><apply.sich_bewerben><de> Bitte bewerben Sie sich online.
<G-vec00272-001-s273><apply.sich_bewerben><en> Please apply under Place product and send us some information on your product.
<G-vec00272-001-s273><apply.sich_bewerben><de> Bitte bewerben Sie sich unter „Produkt eintragen“ und senden Sie uns vorab einige Infos zu Ihrem Produkt.
<G-vec00272-001-s274><apply.sich_bewerben><en> Time and again, pupils blossom during a radio week, many retain a passion for the media and some apply for an internship.
<G-vec00272-001-s274><apply.sich_bewerben><de> Denn immer wieder gibt es Schülerinnen und Schüler, die in einer solchen Woche richtig aufblühen – etliche behalten die Begeisterung fürs Medium, bewerben sich später für Praktika.
<G-vec00272-001-s275><apply.sich_bewerben><en> International Artists with a main working focus outside German-speaking countries apply via the local Goethe Institute.
<G-vec00272-001-s275><apply.sich_bewerben><de> International Künstlerinnen und Künstler mit Arbeitsschwerpunkt außerhalb der deutschsprachigen Länder bewerben sich über das Goethe-Institut ihres Herkunftslandes.
<G-vec00272-001-s276><apply.sich_bewerben><en> The nominated students apply independently as an Erasmus-exchange student at the partner university.
<G-vec00272-001-s276><apply.sich_bewerben><de> "Die nominierten Studierenden bewerben sich eigenständig an der Partnerhochschule als ""Erasmus-exchange student""."
<G-vec00272-001-s277><apply.sich_bewerben><en> Schools which fulfill the criteria and would like to be a partner in the new network can apply to the Goethe-Instituts in London (for England, Wales and Northern Ireland) and Glasgow (for Scotland).
<G-vec00272-001-s277><apply.sich_bewerben><de> Schulen, die die oben genannten Kriterien erfüllen und gerne ein Partner im neuen Netzwerk sein möchten, bewerben sich bei den Goethe-Instituten in London (für England, Wales, Nordirland) und Glasgow (für Schottland).
<G-vec00272-001-s278><apply.sich_bewerben><en> Please apply via our contact form .
<G-vec00272-001-s278><apply.sich_bewerben><de> Bitte bewerben Sie sich über unser Kontaktformular.
<G-vec00272-001-s279><apply.sich_bewerben><en> If you are interested in one of our advertised posts, please apply directly to the relevant location.
<G-vec00272-001-s279><apply.sich_bewerben><de> Wenn Sie sich für eine unserer ausgeschriebenenStellen interessieren, bewerben Sie sich bitte direkt am jeweiligen Standort.
<G-vec00272-001-s280><apply.sich_bewerben><en> Applicants with German or EU-citizenship please apply via the online portal of the KIT Studierendenservice (student services).
<G-vec00272-001-s280><apply.sich_bewerben><de> Bewerber mit deutscher oder EU-Staatsbürgerschaft bewerben sich bitte über das online-Portal des Studierendenservice am KIT.
<G-vec00272-001-s281><apply.sich_bewerben><en> However, particularly in the natural sciences and engineering sciences, far fewer women apply for a fellowship (25 percent and 15 percent respectively).
<G-vec00272-001-s281><apply.sich_bewerben><de> Jedoch bewerben sich vor allem in den Natur- und Ingenieurwissenschaften mit 25 beziehungsweise 15 Prozent weit weniger Frauen als Männer um ein Stipendium.
<G-vec00272-001-s282><apply.sich_bewerben><en> For most fields of study at the University of Freiburg, you can apply directly online .
<G-vec00272-001-s282><apply.sich_bewerben><de> Für die meisten Fächer bewerben Sie sich direkt bei der Universität Freiburg über das Online-Portal .
<G-vec00272-001-s283><apply.sich_bewerben><en> If you are interested in other positions at UBS, please apply separately for these openings as UBS will not necessarily automatically consider you for other openings.
<G-vec00272-001-s283><apply.sich_bewerben><de> Sollten Sie Interesse an anderen Stellen innerhalb der UBS haben, bewerben Sie sich bitte gesondert für diese offenen Stellen, da die UBS Sie nicht zwingend bei der Besetzung anderer offener Stellen berücksichtigen wird.
<G-vec00272-001-s284><apply.sich_bewerben><en> For example, applicants with a German Abitur often apply directly to the university.
<G-vec00272-001-s284><apply.sich_bewerben><de> Zum Beispiel bewerben sich Bewerberinnen und Bewerber mit einem deutschen Abitur oft direkt bei der Hochschule.
<G-vec00272-001-s285><apply.sich_bewerben><en> Many core courses in our information security degree program apply directly to industry standard certifications, such as CompTIA, Microsoft, Cisco and Computer Forensics Investigation.
<G-vec00272-001-s285><apply.sich_bewerben><de> Viele Kernfächer in unserem Informationssicherheit Studiengang bewerben Sie sich direkt an Industriestandard-Zertifizierungen wie CompTIA, Microsoft, Cisco und Computer Forensics Investigation.
<G-vec00272-001-s286><apply.sich_bewerben><en> Then apply for one of our national and international trainee programs.
<G-vec00272-001-s286><apply.sich_bewerben><de> Dann bewerben Sie sich für eines unserer nationalen und internationalen Traineeprogramme.
<G-vec00272-001-s287><apply.sich_bewerben><en> Apply directly to the eyelid and follow the lash line with the precision tip.
<G-vec00272-001-s287><apply.sich_bewerben><de> Bewerben Sie sich direkt auf dem Augenlid und folgen Sie den Wimpernrand mit precisietip.
<G-vec00272-001-s288><apply.sich_bewerben><en> Visitors must apply for a visa from the authorities diplomatic / consular Burkina Faso in their relative country.
<G-vec00272-001-s288><apply.sich_bewerben><de> Bewerben Sie sich für ein Visum wird von den Behörden diplomatische / konsularische Burkina Faso in ihrem Land erforderlich.
<G-vec00272-001-s289><apply.sich_bewerben><en> Apply for vacancies through our jobs portal, or take the initiative and try and sell us your idea for your university dissertation work.
<G-vec00272-001-s289><apply.sich_bewerben><de> Bewerben Sie sich über unser Stellenportal auf offene Stellen oder ergreifen Sie die Initiative und überzeugen uns von Ihrem Thema für eine akademische Abschlussarbeit.
<G-vec00272-001-s290><apply.sich_bewerben><en> Write your own KAEFER story and apply here .
<G-vec00272-001-s290><apply.sich_bewerben><de> Erzählen Sie Ihre Geschichte und bewerben Sie sich hier .
<G-vec00272-001-s291><apply.sich_bewerben><en> Family visa: Apply early for a visa (if necessary) for yourself and your family.
<G-vec00272-001-s291><apply.sich_bewerben><de> Familienvisum: Bewerben Sie sich frühzeitig für ein Visum (falls erforderlich) für Sie und Ihre Familie.
<G-vec00272-001-s292><apply.sich_bewerben><en> Apply with up to 5 of your most attractive domains and take advantage of even more exposure and especially high sales revenues. Apply now
<G-vec00272-001-s292><apply.sich_bewerben><de> Bewerben Sie sich mit bis zu 5 Ihrer attraktivsten Domains – und profitieren Sie von noch mehr Aufmerksamkeit und besonders hohen Verkaufserlösen.
<G-vec00272-001-s293><apply.sich_bewerben><en> Take the initiative and apply online right now.
<G-vec00272-001-s293><apply.sich_bewerben><de> Dann ergreifen Sie die Initiative und bewerben Sie sich gleich online.
<G-vec00272-001-s294><apply.sich_bewerben><en> Take the next step and apply online.
<G-vec00272-001-s294><apply.sich_bewerben><de> Machen Sie den nächsten Schritt und bewerben Sie sich online.
<G-vec00272-001-s295><apply.sich_bewerben><en> Apply to companies where grades are less important.
<G-vec00272-001-s295><apply.sich_bewerben><de> Bewerben Sie sich bei Firmen, denen Noten weniger wichtig sind.
<G-vec00272-001-s296><apply.sich_bewerben><en> Apply straight with one arm, built in 45 degrees y tulip crystal.
<G-vec00272-001-s296><apply.sich_bewerben><de> Bewerben Sie sich gerade mit einem Arm, in 45 Grad gebaut y Tulpenopal.
<G-vec00272-001-s297><apply.sich_bewerben><en> Then apply for work experience at HUMMEL.
<G-vec00272-001-s297><apply.sich_bewerben><de> Dann bewerben Sie sich für einen Praktikumsplatz bei HUMMEL.
<G-vec00272-001-s298><apply.sich_bewerben><en> Apply online now for one of our open positions with our career portal. Career portal
<G-vec00272-001-s298><apply.sich_bewerben><de> Bewerben Sie sich jetzt online auf eine unserer offenen Stellen auf unserem Karriereportal.
<G-vec00272-001-s299><apply.sich_bewerben><en> Apply to:Beer Dispensing,Water Treatment,Pollution Controll,Chemical Industry,Phatmaccutical Industry.
<G-vec00272-001-s299><apply.sich_bewerben><de> Bewerben Sie sich für: Bierdosierung, Wasseraufbereitung, Umweltschutz, Chemische Industrie, Phatmatikindustrie.
<G-vec00272-001-s300><apply.sich_bewerben><en> – Then apply now and become part of the Brand Ambassador Programme.
<G-vec00272-001-s300><apply.sich_bewerben><de> – Dann bewerben Sie sich und werden Sie Teil des Markenbotschafter Programms.
<G-vec00272-001-s301><apply.sich_bewerben><en> If you would like to be part of our team, simply apply below.
<G-vec00272-001-s301><apply.sich_bewerben><de> Wenn Sie Teil unseres Teams werden wollen, bewerben Sie sich unten.
<G-vec00272-001-s302><apply.sich_bewerben><en> Apply for financial support for rigorous research projects that set out to produce empirical evidence with relevant implications for policymakers and business in Europe.
<G-vec00272-001-s302><apply.sich_bewerben><de> Bewerben Sie sich um finanzielle Unterstützung für gezielte Forschungsprojekte, die aussagekräftige empirische Daten für politische Entscheidungsträger und die Wirtschaft in Europa erbringen sollen.
<G-vec00272-001-s303><apply.sich_bewerben><en> Team skills Start into the future with KUKA: apply online Â for your apprenticeship as mechatronics technician!
<G-vec00272-001-s303><apply.sich_bewerben><de> Starten Sie mit KUKA in die Zukunft: Bewerben Sie sich online für Ihre Ausbildung zum/zur Mechatroniker/in.
<G-vec00272-001-s456><apply.gelten><en> The above regulations apply accordingly in the case of delivery by third party haulage companies if it is possible to derive liability on our part as a result of their conduct.
<G-vec00272-001-s456><apply.gelten><de> Die vorstehenden Regelungen gelten entsprechend bei der Belieferung durch dritte Beförderungsunternehmen, soweit aus deren Verhalten eine Haftung für uns hergeleitet werden könnte.
<G-vec00272-001-s457><apply.gelten><en> (3) The liability limitations resulting from Para. 2 shall not apply insofar as we have maliciously failed to disclose a defect or have furnished a guarantee for the quality of the goods.
<G-vec00272-001-s457><apply.gelten><de> (3) Die sich aus Abs 2 ergebenden Haftungsbeschränkungen gelten nicht, soweit wir einen Mangel arglistig verschwiegen oder eine Garantie für die Beschaffenheit der Ware übernommen haben.
<G-vec00272-001-s458><apply.gelten><en> If INCOTERMS are agreed for export business, the definitions apply which are determined and published from time to time by the International Chamber of Commerce in Paris and which are in force when the contract is concluded.
<G-vec00272-001-s458><apply.gelten><de> Werden bei Auslandsgeschäften INCOTERMS vereinbart, so gelten die bei Vertragsschluss von der Internationalen Handelskammer in Paris jeweils festgelegten und veröffentlichten Definitionen.
<G-vec00272-001-s459><apply.gelten><en> Special rules apply to electronic communications services (e-Privacy Directive 14) which may need to be reassessed once the general EU rules on data protection are agreed, particularly since most of the articles of the current e-Privacy Directive apply only to providers of electronic communications services, i.e. traditional telecoms companies.
<G-vec00272-001-s459><apply.gelten><de> Für elektronische Kommunikationsdienste gelten besondere Regelungen (e-Datenschutz-Richtlinie 14), die möglicherweise zu überprüfen sein werden, sobald die allgemeinen EU-Datenschutzvorschriften beschlossen sind, insbesondere weil die meisten Artikel der derzeitigen e-Datenschutz-Richtlinie nur für Betreiber elektronischer Kommunikationsdienste (d. h. herkömmliche Telekommunikationsunternehmen) gelten.
<G-vec00272-001-s460><apply.gelten><en> Special rules apply to electronic communications services (e-Privacy Directive 14) which may need to be reassessed once the general EU rules on data protection are agreed, particularly since most of the articles of the current e-Privacy Directive apply only to providers of electronic communications services, i.e. traditional telecoms companies.
<G-vec00272-001-s460><apply.gelten><de> Für elektronische Kommunikationsdienste gelten besondere Regelungen (e-Datenschutz-Richtlinie 14), die möglicherweise zu überprüfen sein werden, sobald die allgemeinen EU-Datenschutzvorschriften beschlossen sind, insbesondere weil die meisten Artikel der derzeitigen e-Datenschutz-Richtlinie nur für Betreiber elektronischer Kommunikationsdienste (d. h. herkömmliche Telekommunikationsunternehmen) gelten.
<G-vec00272-001-s461><apply.gelten><en> For in-house staff coachings special conditions apply.
<G-vec00272-001-s461><apply.gelten><de> Für In-House-Fortbildungen in Ihrem Kollegium gelten gesonderte Bedingungen.
<G-vec00272-001-s462><apply.gelten><en> We are still able to accommodate rush orders, but charges starting at $75 will apply.
<G-vec00272-001-s462><apply.gelten><de> Wir sind immer noch in der Lage, Eilaufträge unterzubringen, aber Gebühren ab $ 75 gelten.
<G-vec00272-001-s463><apply.gelten><en> If you disagree with the changes that have been made, please contact us (by e-mail, using a website contact form, or in writing by mail), and any changes made to this policy will not apply to information we have collected from you prior to making the changes.
<G-vec00272-001-s463><apply.gelten><de> Wenn Sie mit den Änderungen nicht einverstanden, die vorgenommen wurden sind, kontaktieren Sie uns (per E-mail, über eine Website-Kontakt-Formular oder schriftlich per Post) und alle Änderungen dieser Datenschutzbestimmungen gelten nicht für Informationen, die wir von Ihnen erfasst haben, vor Durchführung der Änderungen.
<G-vec00272-001-s464><apply.gelten><en> Upon order placement, the current services, rates and General Terms and Conditions of theGeneral Overnight Express & Logistics (Austria) GmbH shall apply.
<G-vec00272-001-s464><apply.gelten><de> Bei Auftragserteilung gelten die aktuellen Services, Tarife und besonderen Geschäftsbedingungen der General Overnight Express & Logistics (Austria) GmbH.
<G-vec00272-001-s465><apply.gelten><en> as doable then pleasurable many occasions in a intercourse session to apply orgasm control.
<G-vec00272-001-s465><apply.gelten><de> als machbar dann angenehm vielen Gelegenheiten in einer Sitzung, um Geschlechtsverkehr Orgasmuskontrolle gelten.
<G-vec00272-001-s466><apply.gelten><en> For dung card fishing for fish, 4 noble fish apply.
<G-vec00272-001-s466><apply.gelten><de> Für das Dungkartenfischen auf Fische gelten 4 edle Fische.
<G-vec00272-001-s467><apply.gelten><en> "SCOPE, CONTRACTUAL RELATIONS 1.1. The present General Terms and Conditions (referred to hereinbelow as the ""General Terms and Conditions"") apply to concerts organized by MCT Agentur GmbH, Strausberger Platz 2, 10243 Berlin, Managing Director: Scumeck Sabottka, entered in the Commercial Register kept by the Amtsgericht (Local Court) of Berlin under the number HRB: 65613 (referred to hereinbelow as ""we"" or ""MCT""), with MCT acting as event organizer."
<G-vec00272-001-s467><apply.gelten><de> "Allgemeine Geschäftsbedingungen für Konzertveranstaltungen der MCT Agentur GmbH GELTUNGSBEREICH, VERTRAGSBEZIEHUNGEN 1.1 Diese Allgemeinen Geschäftsbedingungen (nachfolgend ""AGB"") gelten für Konzerte, bei denen die MCT Agentur GmbH, Strausberger Platz 2, 10243 Berlin, Geschäftsführer: Scumeck Sabottka, Registergericht: Amtsgericht Berlin, HRB: 65613 (nachfolgend ""wir"" oder ""MCT"") Veranstalter ist."
<G-vec00272-001-s468><apply.gelten><en> (a) enable the Bank of Greece or the public prosecutor to carry out audits of the funding of media enterprises, (b) apply to all public limited companies and provide that a loss-making company cannot continue operating without recapitalization. Public procurement:
<G-vec00272-001-s468><apply.gelten><de> Werden wir umgehend jene Gesetzesvorschriften aktivieren, die es der griechischen Zentralbank oder den zuständigen Staatsanwaltschaften erlauben, Kontrollen über die Herkunft der Finanzierung von Informationsunternehmen durchzuführen, und die für alle Aktiengesellschaften gelten und vorsehen, dass ein Verluste erwirtschaftendes Unternehmen nicht unbegrenzt betrieben werden kann, ohne rekapitalisiert zu werden.
<G-vec00272-001-s469><apply.gelten><en> The same methods of cooking other sunfish apply for fliers.
<G-vec00272-001-s469><apply.gelten><de> Die gleichen Methoden des Kochens anderen Mondfisch gelten für Flieger.
<G-vec00272-001-s470><apply.gelten><en> European standards apply as and when they are adopted and replace the various national standards.
<G-vec00272-001-s470><apply.gelten><de> Des Weiteren gelten die im Laufe der Zeit festgelegten europäischen Normen, die an die Stelle der verschiedenen nationalen Regelungen treten.
<G-vec00272-001-s471><apply.gelten><en> 2 shall not apply insofar as we have wilfully failed to disclose a defect or have given a guarantee of the nature of the goods.
<G-vec00272-001-s471><apply.gelten><de> 2 ergebenden Haftungsbeschränkungen gelten nicht, soweit wir einen Mangel arglistig verschwiegen oder eine Garantie für die Beschaffenheit der Ware übernommen haben.
<G-vec00272-001-s472><apply.gelten><en> These principles apply also to the organization of world trade, without containing finished political strategies.
<G-vec00272-001-s472><apply.gelten><de> Diese Prinzipien gelten auch für die Gestaltung des Welthandels, wobei sie keine fertigen politischen Strategien enthalten.
<G-vec00272-001-s473><apply.gelten><en> I think I’ve learned alot now that I’ve actually had some hands on time to apply my knowledge in the real world.
<G-vec00272-001-s473><apply.gelten><de> Ich glaube, ich habe viel gelernt, dass ich jetzt tatsächlich hatten einige Hände auf Zeit, um meine Kenntnisse in der realen Welt gelten.
<G-vec00272-001-s474><apply.gelten><en> These conditions of use apply to the use of Guest WiFi Basel.
<G-vec00272-001-s474><apply.gelten><de> Diese Nutzungsbedingungen gelten für die Nutzung des Guest WiFi Basel.
<G-vec00272-001-s475><apply.gelten><en> The following terms and conditions apply to shipments within the Federal Republic of Germany.
<G-vec00272-001-s475><apply.gelten><de> Die nachfolgenden Bedingungen gelten für den Versand innerhalb der Bundesrepublik Deutschland.
<G-vec00272-001-s476><apply.gelten><en> - Discount percentages do not apply to time overrun rates.
<G-vec00272-001-s476><apply.gelten><de> - Die Ermäßigungen gelten nicht für die Tarife der Zeitüberschreitungen.
<G-vec00272-001-s477><apply.gelten><en> The Globelynx camera and services are provided free of charge (normal satellite booking charges apply).
<G-vec00272-001-s477><apply.gelten><de> Die Globelynx-Kamera und -Leistungen sind kostenfrei (es gelten die regulären Buchungsgebühren für Satellitenverbindungen).
<G-vec00272-001-s478><apply.gelten><en> The rights and obligations identified in this contract apply to Buyer's purchase of the equipment, software license, and services identified in the MT order documents.
<G-vec00272-001-s478><apply.gelten><de> Die in diesen allgemeinen Geschäftsbedingungen aufgeführten Rechte und Pflichten gelten für den Erwerb, der in den Bestelldokumenten genannten Geräte, Software, Softwarelizenzen und/oder Dienstleistungen durch den Käufer.
<G-vec00272-001-s479><apply.gelten><en> Changes to the insurance contract of the fixed asset class only apply to fixed assets created after the change.
<G-vec00272-001-s479><apply.gelten><de> Änderungen am Versicherungsvertrag der Anlagenart gelten nur für Anlagengüter, die Sie nach der Änderung anlegen.
<G-vec00272-001-s480><apply.gelten><en> 2 Â Unless otherwise provided by law, the provisions governing share capital, shares and shareholders also apply to the participation capital, participation certificates and participation certificate holders.
<G-vec00272-001-s480><apply.gelten><de> 2 Die Bestimmungen über das Aktienkapital, die Aktie und den Aktionär gelten, soweit das Gesetz nichts anderes vorsieht, auch für das Partizipationskapital, den Partizipationsschein und den Partizipanten.
<G-vec00272-001-s481><apply.gelten><en> Article 35 – Federal or non-unitary constitutional systems The following provisions shall apply to States Parties which have a federal or non-unitary constitutional system: (a) with regard to the provisions of this Convention, the implementation of which comes under the legal jurisdiction of the federal or central legislative power, the obligations of the federal or central government shall be the same as for those States Parties which are not federal States; (b) with regard to the provisions of this Convention, the implementation of which comes under the jurisdiction of individual constituent States, countries, provinces or cantons which are not obliged by the constitutional system of the federation to take legislative measures, the federal government shall inform the competent authorities of such States, countries, provinces or cantons of the said provisions, with its recommendation for their adoption.
<G-vec00272-001-s481><apply.gelten><de> Folgende Bestimmungen gelten für Vertragsstaaten, die ein bundesstaatliches oder ein nicht einheitsstaatliches Verfassungssystem haben: a) Hinsichtlich derjenigen Bestimmungen dieses Übereinkommens, deren Durchführung in die Zuständigkeit des Bundes- oder Zentral-Gesetzgebungsorgans fällt, sind die Verpflichtungen der Bundes- oder Zentralregierung dieselben wie für diejenigen Vertragsstaaten, die nicht Bundesstaaten sind; b) hinsichtlich derjenigen Bestimmungen dieses Übereinkommens, deren Durchführung in die Zuständigkeit einzelner Bundesstaaten, Länder, Provinzen oder Kantone fällt, die nicht durch das Verfassungssystem des Bundes verpflichtet sind, gesetzgeberische Maßnahmen zu treffen, bringt die Bundesregierung den zuständigen Stellen dieser Bundesstaaten, Länder, Provinzen oder Kantone die genannten Bestimmungen zur Kenntnis und empfiehlt ihnen ihre Annahme.
<G-vec00272-001-s482><apply.gelten><en> The same rules apply where the Securities form part of a trade or business (Betriebsvermögen) subject to further requirements being met.
<G-vec00272-001-s482><apply.gelten><de> Dieselben Vorschriften gelten auch für den Fall, dass die Wertpapiere Teil eines Betriebsvermögens sind und weitere Anforderungen erfüllen.
<G-vec00272-001-s483><apply.gelten><en> Therefore, if a user is a part of a role, any permissions granted to the role will automatically apply to the user as well.
<G-vec00272-001-s483><apply.gelten><de> Wenn ein Benutzer daher einer Rolle angehört, gelten alle Berechtigungen, die dieser Rolle eingeräumt sind, automatisch auch für den Benutzer.
<G-vec00272-001-s484><apply.gelten><en> As a result, many of the existing agreements under which vendors use WorldCat data to provide services to OCLC member libraries apply only to services provided to one or more specific requesting libraries.
<G-vec00272-001-s484><apply.gelten><de> Daraus folgt, dass viele der bestehenden Verträge, in deren Rahmen Anbieter WorldCat-Daten zur Bereitstellung von Diensten für OCLC-Mitgliedsbibliotheken nutzen, nur für die entsprechenden Dienste gelten, die für die einzelnen Bibliotheken bereitgestellt werden.
<G-vec00272-001-s485><apply.gelten><en> These documents also apply to Vector Austria GmbH:
<G-vec00272-001-s485><apply.gelten><de> Diese Dokumente gelten auch für die Vector Austria GmbH.
<G-vec00272-001-s486><apply.gelten><en> Privacy Policy does not apply to services offered by other companies, including in cases where these services are accessible via services of eAgronom.
<G-vec00272-001-s486><apply.gelten><de> Die Datenschutzrichtlinien gelten nicht für Dienste, die von anderen Unternehmen angeboten werden, auch wenn diese Dienste über eAgronom-Dienste zugänglich sind.
<G-vec00272-001-s487><apply.gelten><en> The Indonesian visa process will change in 2019 (certain exceptions apply to Autumn 2018).
<G-vec00272-001-s487><apply.gelten><de> Der indonesische Visa-Prozess wird sich in 2019 ändern (einige Ausnahmen gelten auch für den Herbst 2018).
<G-vec00272-001-s488><apply.gelten><en> Equally strict hygiene regulations apply to transportation.
<G-vec00272-001-s488><apply.gelten><de> Ebenso strenge Hygienevorschriften gelten auch für den Transport.
<G-vec00272-001-s489><apply.gelten><en> All terms and conditions and policies of the Third Party Websites you visit will apply to you while on such websites and you should check them.
<G-vec00272-001-s489><apply.gelten><de> Alle Nutzungsbedingungen und Richtlinien solcher Websites Dritter, die Sie besuchen, gelten für Sie, solange Sie sich darauf befinden, und Sie sollten diese Bedingungen daher überprüfen.
<G-vec00272-001-s490><apply.gelten><en> Special rates only apply to certain offered time periods.
<G-vec00272-001-s490><apply.gelten><de> Sondertarife gelten nur für den angebotenen Zeitraum.
<G-vec00272-001-s491><apply.gelten><en> The conditions of the sale apply accordingly.
<G-vec00272-001-s491><apply.gelten><de> Die Bedingungen für die Versteigerung gelten für den Freiverkauf entsprechend.
<G-vec00272-001-s492><apply.gelten><en> If a reservation change is not possible and the Traveler gives up the confirmed reservation, the cancellation terms listed below apply.
<G-vec00272-001-s492><apply.gelten><de> Für den Fall, dass eine Veränderung der Buchung nicht möglich ist und der Gast deswegen von einer bereits bestätigten Buchung zurücktritt, gelten die unten genannten Bedingungen für die Buchungskündigung.
<G-vec00272-001-s493><apply.gelten><en> It's important to note a couple of things: First, these lists apply only to Constructed formats and not Limited formats.
<G-vec00272-001-s493><apply.gelten><de> Ein paar wichtige Dinge sollte man wissen: Erstens, diese Listen gelten nur für Constructed-Formate und nicht für Limited-Formate.
<G-vec00272-001-s494><apply.gelten><en> 1 The provisions of Article 14, sub-paragraph a, shall apply to members of the service staff of diplomatic missions or consular posts, and also to persons employed in the private service of officials of such missions or posts.
<G-vec00272-001-s494><apply.gelten><de> 1 Artikel 14 Buchstabe a gilt auch für Mitglieder des dienstlichen Hauspersonals diplomatischer Missionen und konsularischer Vertretungen sowie für private Hausangestellte im Dienste von Angehörigen dieser Missionen oder Vertretungen.
<G-vec00272-001-s495><apply.gelten><en> On discussion, this can also apply to your print components too, so that we can deliver your re-orders even more quickly.
<G-vec00272-001-s495><apply.gelten><de> Das gilt nach Absprache natürlich auch für Ihre Druckkomponenten, so dass wir bei Re-Ordern noch schneller liefern können.
<G-vec00272-001-s496><apply.gelten><en> For all these links apply: Messrs. Sakkara GmbH declares explicitly that they do not have any influence on design and content of the linked sites.
<G-vec00272-001-s496><apply.gelten><de> Für alle diese Links gilt: Die SAKKARA GmbH erklärt ausdrücklich, dass sie keinerlei Einfluss auf die Gestaltung und die Inhalte der verlinkten Seiten hat.
<G-vec00272-001-s497><apply.gelten><en> The traditional cheese of Spain requested to apply the flexibility of the rules of the European Union....
<G-vec00272-001-s497><apply.gelten><de> Traditionelle Käser von Spanien gefordert, dass die Flexibilität der Regeln der Europäischen Union gilt....
<G-vec00272-001-s498><apply.gelten><en> The limitation of liability shall further not apply in the cases in which there is liability for damage to persons or objects for privately used objects according to the Product Liability Act in defects of the goods delivered.
<G-vec00272-001-s498><apply.gelten><de> Die Haftungsbeschränkung gilt ferner nicht in den Fällen, in denen nach Produkthaftungsgesetz bei Fehlern der gelieferten Ware für Personen- oder Sachschäden an privat genutzten Gegenständen gehaftet wird.
<G-vec00272-001-s499><apply.gelten><en> § 9.4 The supplier's aforementioned obligations to save us harmless shall not apply if the supplier manufactured the items of delivery on the basis of drawings, models or identical descriptions or specifications made available by our company and the supplier doesn't know or - in context with the products he developed - doesn't need to know that they violate third-party rights.
<G-vec00272-001-s499><apply.gelten><de> § 9.4 Die vorstehende Einstandspflicht des Lieferanten gilt dann nicht, wenn der Lieferant die Liefergegenstände nach von uns übergebenen Zeichnungen, Modellen oder diesen gleich kommenden sonstigen Beschreibungen oder Angaben hergestellt hat und nicht weiß oder im Zusammenhang mit den von ihm entwickelten Erzeugnissen nicht wissen muss, dass dadurch Schutzrechte verletzt werden.
<G-vec00272-001-s500><apply.gelten><en> This does not apply if gigmit is responsible for the failed transaction.
<G-vec00272-001-s500><apply.gelten><de> Dies gilt nicht wenn gigmit für das Fehlschlagen verantwortlich ist.
<G-vec00272-001-s501><apply.gelten><en> This does not apply if this information and/or these documents are demonstrably already known to the public or if the supplier has designated them for resale by the purchaser.
<G-vec00272-001-s501><apply.gelten><de> Dies gilt nicht, wenn diese Informationen und/oder Dokumente nachweislich öffentlich bekannt sind oder vom Lieferer zur Weiterveräußerung durch den Käufer bestimmt wurden.
<G-vec00272-001-s502><apply.gelten><en> This fee will apply even if the item cannot be repaired or if it was not obtained from us.
<G-vec00272-001-s502><apply.gelten><de> Das gilt auch dann, wenn der Artikel irreparabel ist oder nicht von uns bezogen wurde.
<G-vec00272-001-s503><apply.gelten><en> This does not apply if the defect is not eliminated by us in a reasonable period.
<G-vec00272-001-s503><apply.gelten><de> Dies gilt nicht, wenn der Mangel durch uns nicht in angemessener Frist beseitigt wird.
<G-vec00272-001-s504><apply.gelten><en> With the surrender of things this does not apply if the deterioration is exclusively due to their inspection - is due - as would have been about you at our store.
<G-vec00272-001-s504><apply.gelten><de> Bei der Überlassung von Sachen gilt dies nicht, wenn die Verschlechterung der Sache ausschließlich auf deren Prüfung - wie sie Ihnen etwa im Ladengeschäft möglich gewesen wäre - zurückzuführen ist.
<G-vec00272-001-s505><apply.gelten><en> The requirementof approval shall apply in any case, even if e.g. we accept the seller's delivery without reservation being aware of his general terms and conditions.
<G-vec00272-001-s505><apply.gelten><de> Das Zustimmungserfordernis gilt in jedem Fall, beispielsweise auch dann, wenn wir in Kenntnis der Allgemeinen Geschäftsbedingungen des Verkäufers dessen Lieferung vorbehaltlos annehmen.
<G-vec00272-001-s506><apply.gelten><en> The same shall apply where there is good reason to assume that the receipt of an excise duty or the VAT is at risk; collateral may also be demanded in lieu of bringing the due date forward.
<G-vec00272-001-s506><apply.gelten><de> Das Gleiche gilt, wenn die Annahme begründet ist, dass der Eingang einer Verbrauchsteuer oder der Umsatzsteuer gefährdet ist; an Stelle der Vorverlegung der Fälligkeit kann auch Sicherheitsleistung verlangt werden.
<G-vec00272-001-s507><apply.gelten><en> If these preconditions are not fulfilled in good time, the delivery periods shall be extended by a reasonable amount of time; this does not apply if SAVVY can be held responsible for the delay.
<G-vec00272-001-s507><apply.gelten><de> Werden diese Voraussetzungen nicht rechtzeitig erfüllt, so verlängern sich die Fristen angemessen; dies gilt nicht, wenn die SAVVY die Verzögerung zu vertreten hat.
<G-vec00272-001-s508><apply.gelten><en> Insofar as the liability for damages towards Customer is excluded or limited, this shall also apply with respect to the personal liability for damage of employees, members of staff, co-operators, representatives and vicarious agents of Contractor.
<G-vec00272-001-s508><apply.gelten><de> Soweit die Schadenersatzhaftung gegenüber dem Kunden ausgeschlossen oder eingeschränkt ist, gilt dies auch im Hinblick auf die persönliche Schadenersatzhaftung der Angestellten, Arbeitnehmer, Mitarbeiter, Vertreter und Erfüllungsgehilfen des Auftragnehmers.
<G-vec00272-001-s509><apply.gelten><en> 17.2 For disagreements and disputes arising in connection with the Victorinox Online Shop, Swiss law shall apply to the exclusion of the UN Convention on Contracts for the International Sale of Goods (CISG).
<G-vec00272-001-s509><apply.gelten><de> 17.2 Bei Unstimmigkeiten und Streitigkeiten in Zusammenhang mit dem Online-Shop von Victorinox gilt unter Ausschluss aller Gesetze zu internationalen Käufen beweglicher Güter Schweizer Recht.
<G-vec00272-001-s510><apply.gelten><en> The same shall apply if the customer does not have a general jurisdiction in Germany or his domicile or ordinary residence are not know at the moment of filing an action.
<G-vec00272-001-s510><apply.gelten><de> Dasselbe gilt, wenn der Kunde keinen allgemeinen Gerichtsstand in Deutschland hat oder Wohnsitz oder gewöhnlicher Aufenthalt im Zeitpunkt der Klageerhebung nicht bekannt sind.
<G-vec00272-001-s511><apply.gelten><en> This shall not apply only if such relief is impossible or is refused by TO or if immediate termination of the contract is required by a particular interest of the client that is discernible to TO.
<G-vec00272-001-s511><apply.gelten><de> Dies gilt nur dann nicht, wenn Abhilfe unmöglich ist oder vom RV verweigert wird oder wenn die sofortige Kündigung des Vertrages durch ein besonderes, dem RV erkennbares Interesse des Kunden gerechtfertigt wird.
<G-vec00272-001-s512><apply.gelten><en> As the excess does, however, not apply to each insurance claim but to all insurance claims during an insurance year, bills (originals) should also be submitted if the amount of the doctors ́, laboratory or other medical bill or prescriptions is lower than the excess.
<G-vec00272-001-s512><apply.gelten><de> Da der Eigenanteil jedoch nicht je Versicherungsfall gilt, sondern sich auf alle Versicherungsfälle eines Versicherungsjahres erstreckt, bitten wir Sie, Rechnungen auch dann (im Original) bei uns einzureichen, wenn der Rechnungsbetrag von Arzt-, Labor oder sonstigen medizinischen Rechnungen oder Rezepten niedriger ausfällt.
<G-vec00272-001-s570><apply.sich_bewerben><en> However, all users who apply to Indeed Prime but are not accepted into the program will remain within the Indeed Prime database.
<G-vec00272-001-s570><apply.sich_bewerben><de> Allerdings werden alle Nutzer, die sich für Indeed Prime bewerben, jedoch nicht in das Programm aufgenommen werden, weiterhin in der Indeed-Prime-Datenbank geführt.
<G-vec00272-001-s571><apply.sich_bewerben><en> College of Business Scholarships are awarded in the semester(s) following the semester in which the scholarship applications are completed (e.g., students who apply for and are awarded scholarships in fall will receive financial support in the spring semester).
<G-vec00272-001-s571><apply.sich_bewerben><de> College of Business Stipendien werden im Semester vergeben (n) nach dem Semester, in dem die Stipendienanträgen abgeschlossen sind (zB Studenten, die sich bewerben und werden Stipendien im Herbst vergeben wird erhalten finanzielle Unterstützung im Frühlingssemester).
<G-vec00272-001-s572><apply.sich_bewerben><en> Refugees may register on the online platform cost-free and set up their applicant profile or directly apply for vacancies.
<G-vec00272-001-s572><apply.sich_bewerben><de> Flüchtlinge können sich auf der Online-Plattform kostenlos registrieren und ein Bewerberprofil erstellen oder sich direkt auf offene Stellenausschreibungen bewerben.
<G-vec00272-001-s573><apply.sich_bewerben><en> These terms and conditions might include a period of time when to be able to apply for the bonus after registering.
<G-vec00272-001-s573><apply.sich_bewerben><de> Diese Fristen und Bedingungen könnten eine Zeitspanne einschließen um im Stande zu sein, sich um den Bonus nach dem Registrieren zu bewerben.
<G-vec00272-001-s574><apply.sich_bewerben><en> Undergraduate political science majors may apply for admission to the political science master's program during their junior year.
<G-vec00272-001-s574><apply.sich_bewerben><de> Beschleunigter Bachelor-Master-Studiengang Bachelor-Politikwissenschaftler können sich während ihres Juniorjahres für die Zulassung zum Masterprogramm bewerben.
<G-vec00272-001-s575><apply.sich_bewerben><en> If, after completion of the online application procedure, you intend to apply for another job advertisement of FLG and if you have given your consent to the use of your data for this purpose, your data will be stored for the duration of this application procedure, as well.
<G-vec00272-001-s575><apply.sich_bewerben><de> Möchten Sie sich nach Abschluss des Online-Bewerbungsverfahrens auf eine weitere Stellenausschreibung der FLG bewerben und haben Sie der Verwendung ihrer Daten für diesen Zweck zugestimmt, werden Ihre Daten auch für die Dauer dieses Bewerbungsverfahrens gespeichert.
<G-vec00272-001-s576><apply.sich_bewerben><en> Your muscles volition transmute stronger as you apply.
<G-vec00272-001-s576><apply.sich_bewerben><de> Ihre Muskeln Volition verwandeln stärker als Sie sich bewerben.
<G-vec00272-001-s577><apply.sich_bewerben><en> Furthermore, they can actively browse through translation inquiries on the job board and actively apply for them.
<G-vec00272-001-s577><apply.sich_bewerben><de> Zusätzlich können sie aktiv Übersetzungsanfragen im Job Board sichten und sich darauf bewerben.
<G-vec00272-001-s578><apply.sich_bewerben><en> For any important FIFA tournaments, after the Futsal World Cup, the FA is trying to apply in future, she provably will fail.
<G-vec00272-001-s578><apply.sich_bewerben><de> Auf ein wichtiges FIFA-Turnier nach der Futsal-WM wird sich der Verband in Zukunft wahrscheinlich umsonst bewerben.
<G-vec00272-001-s579><apply.sich_bewerben><en> Fill in this online application form to apply for a job in a Søstrene Grene store that has not yet opened.
<G-vec00272-001-s579><apply.sich_bewerben><de> Füllen Sie dieses Online-Bewerbungsformular aus, um sich in einem Søstrene Grene Laden zu bewerben, der noch nicht eröffnet hat.
<G-vec00272-001-s580><apply.sich_bewerben><en> Additionally, you can also apply to us as a new supplier.
<G-vec00272-001-s580><apply.sich_bewerben><de> Ausserdem können Sie sich als neuer Lieferant bei uns bewerben.
<G-vec00272-001-s581><apply.sich_bewerben><en> You understand that if you apply for an open position on our website we will evaluate your background against the requirements of our client.
<G-vec00272-001-s581><apply.sich_bewerben><de> Sie verstehen, falls Sie sich für eine offene Stelle auf unserer Website bewerben, dass wir Ihr Profil hinsichtlich der Anforderungen unseres Kunden bewerten.
<G-vec00272-001-s582><apply.sich_bewerben><en> After that, they can apply for considerably greater venture capital financing from Telefónica S.A.
<G-vec00272-001-s582><apply.sich_bewerben><de> Anschließend können sie sich für eine erhebliche höhere Risikokapitalfinanzierung von Telefónica S. A. bewerben.
<G-vec00272-001-s583><apply.sich_bewerben><en> They ultimately ended up in Burghausen, where the local aid group recommended Fay to apply for work at WACKER.
<G-vec00272-001-s583><apply.sich_bewerben><de> Sie landen schließlich in Burghausen, wo der Helferkreis Fay empfiehlt, sich bei WACKER zu bewerben.
<G-vec00272-001-s584><apply.sich_bewerben><en> "That's why we not only look into which tailor studios you can apply for, but also in opera houses, theatres and in the independent scene, ""explains Claudia Grewe, who teaches the language."
<G-vec00272-001-s584><apply.sich_bewerben><de> Deshalb schauen wir nicht nur, in welchen Schneider-Ateliers man sich bewerben kann, sondern auch in Opernhäusern, Theatern und in der Freien Szene“, erklärt Claudia Grewe, die den Sprachunterricht gibt.
<G-vec00272-001-s585><apply.sich_bewerben><en> You need to apply as a doctoral student for the places available within these programmes and adhere to the relevant deadlines.
<G-vec00272-001-s585><apply.sich_bewerben><de> Sie müssen sich als Doktorand/in auf die in diesen Programmen zur Verfügung stehenden Plätze bewerben und die entsprechenden Fristen einhalten.
<G-vec00272-001-s586><apply.sich_bewerben><en> Graduates will be able to apply for further study at postgraduate level, including for a place on our full-time or part-time MSc Biomedical Engineering and Instrumentation or MSc Embedded and Distributed Systems.
<G-vec00272-001-s586><apply.sich_bewerben><de> Die Absolventen können sich für ein weiterführendes Studium auf postgradualer Ebene bewerben, einschließlich für einen Platz in unserem Vollzeit- oder Teilzeit-MSc Biomedizintechnik und Instrumentierung oder MSc Embedded and Distributed Systems.
<G-vec00272-001-s587><apply.sich_bewerben><en> However, various studies have shown that there is a significant discrepancy between the willingness of potential applicants to apply online and the online opportunities provided for this by companies.
<G-vec00272-001-s587><apply.sich_bewerben><de> Wie diverse Studien allerdings zeigen, besteht eine nicht unerhebliche Diskrepanz zwischen der Bereitschaft potenzieller Bewerber, sich online zu bewerben und den hierfür von Unternehmen im Internet gebotenen Möglichkeiten.
<G-vec00272-001-s588><apply.sich_bewerben><en> You can apply very easily at Ecologic Institute.
<G-vec00272-001-s588><apply.sich_bewerben><de> Bei uns können Sie sich ganz einfach bewerben.
<G-vec00272-001-s684><apply.verwenden><en> It is possible to apply an aluminium grid; copper or brass it is necessary to tin tin.
<G-vec00272-001-s684><apply.verwenden><de> Man kann das Aluminiumnetz verwenden; kupfern oder latunnuju ist es unbedingt ludit vom Zinn notwendig.
<G-vec00272-001-s685><apply.verwenden><en> As the product’s name states, it is an oil you apply directly to your penis to get the same results you get from taking male improvement tablets.
<G-vec00272-001-s685><apply.verwenden><de> Wie der Name schon sagt Stück, ist es ein Öl direkt an Ihrem Penis verwenden die gleichen Ergebnisse, die Sie von der Einnahme männlichen Verbesserung Tabletten erhalten zu bekommen.
<G-vec00272-001-s686><apply.verwenden><en> We apply the above criteria when awarding a customer card at Trends & Trade.
<G-vec00272-001-s686><apply.verwenden><de> Oben stehende Kriterien verwenden wir bei der Vergabe von Kundenkarten bei Trends & Trade.
<G-vec00272-001-s687><apply.verwenden><en> These concentration skills are something that one can then apply in meditation.
<G-vec00272-001-s687><apply.verwenden><de> Und diese Konzentrationsfähigkeit kann man dann in der Meditation verwenden.
<G-vec00272-001-s688><apply.verwenden><en> Especially advise to apply oil jojoba to the brittle hair injured with the whipped tips.
<G-vec00272-001-s688><apply.verwenden><de> Besonders beraten, das Öl schoschoba für das Haar brüchig, beschädigt, mit den geprügelten Spitzen zu verwenden.
<G-vec00272-001-s689><apply.verwenden><en> "In nebulizers at cold apply the same physical solution, and still alkaline mineral waters (mainly, ""Borjomi""), previously having exempted them from gases."
<G-vec00272-001-s689><apply.verwenden><de> "In nebulajserach beim Schnupfen verwenden selb fisrastwor, und noch die alkalischen Mineralwasser, (hauptsächlich, ""Borschomi""), vorläufig sie von den Gasen befreit."
<G-vec00272-001-s690><apply.verwenden><en> With that information, we apply the most innovative technologies in injection moulding that set our product apart from our competitors.
<G-vec00272-001-s690><apply.verwenden><de> Mit diesen Informationen verwenden wir die innovativsten Technologien im Spritzguss, die unser Produkt von der Konkurrenz unterscheiden.
<G-vec00272-001-s691><apply.verwenden><en> At repair work apply the same tool, as at performance of new products.
<G-vec00272-001-s691><apply.verwenden><de> Bei den Reparaturarbeiten verwenden das selbe Instrument, dass auch bei der Ausführung der neuen Erzeugnisse.
<G-vec00272-001-s692><apply.verwenden><en> We don't apply any hidden charges online or at our Kardjali car rental desk.
<G-vec00272-001-s692><apply.verwenden><de> Wir verwenden keine versteckte Kosten online am unseren KardjaliAutoverleih Schalter.
<G-vec00272-001-s693><apply.verwenden><en> A laying apply at building of buildings in height to four floors.
<G-vec00272-001-s693><apply.verwenden><de> Das Mauerwerk verwenden beim Bau der Gebäude in der Höhe bis zu vier Stockwerken.
<G-vec00272-001-s694><apply.verwenden><en> Do not hesitate to apply a little inspiration and to decorate the handle as it will want to you, having picked up some details independently - remember only that they have to keep strong on the places with what bolts and, as a last resort, a wire will help incomparably best of all even the most reliable glue.
<G-vec00272-001-s694><apply.verwenden><de> Genieren Sie sich nicht, ein wenig Eingebung zu verwenden und, den Griff zu schmücken so, wie es Ihnen wünschenswert ist, etwas Details selbständig ausgewählt - erinnern Sie sich nur daran, dass sie sich auf den Stellen, worin die Bolzen und, für den äußersten Fall fest halten sollen, der Draht werden unvergleichbar besser sogar des sichersten Leims helfen.
<G-vec00272-001-s695><apply.verwenden><en> We don't apply any hidden charges online or at our Bourgas car rental desk.
<G-vec00272-001-s695><apply.verwenden><de> Wir verwenden keine versteckte Kosten online am unseren BurgasAutoverleih Schalter.
<G-vec00272-001-s696><apply.verwenden><en> ”Our system can be seen as an extension of the advanced logistics solution that many industries already apply today”, says Mikael Karlsson, Vice President Autonomous Solutions, Volvo Trucks.
<G-vec00272-001-s696><apply.verwenden><de> „Man kann sich unser System als Erweiterung der ausgeklügelten Logistiklösung vorstellen, die viele Branchen heutzutage verwenden“, so Mikael Karlsson, Vice President Autonomous Solutions, Volvo Trucks.
<G-vec00272-001-s697><apply.verwenden><en> It is best of all to apply special means.
<G-vec00272-001-s697><apply.verwenden><de> Es ist am besten, die speziellen Mittel zu verwenden.
<G-vec00272-001-s698><apply.verwenden><en> This type of laying of a tile is recommended to apply in any rooms where many people will move.
<G-vec00272-001-s698><apply.verwenden><de> Diese Art des Verpackens der Fliese empfehlen, in beliebigen Räumen zu verwenden, wo sich viel Menschen bewegen werden.
<G-vec00272-001-s699><apply.verwenden><en> For measurements in areas such as neighborhood or traffic noise, private users can apply the sound level loggers that log the sound level with the set rating.
<G-vec00272-001-s699><apply.verwenden><de> Für Messungen in den Bereichen wie Nachbarschafts- oder Verkehrslärm können Privatanwender Schallpegellogger verwenden, die den Schallpegel mit der eingestellten Bewertung loggen.
<G-vec00272-001-s700><apply.verwenden><en> As the product’s name states, it is an oil you apply directly to your penis to get the very same outcomes you receive from taking male improvement pills.
<G-vec00272-001-s700><apply.verwenden><de> Wie der Name schon sagt das Produkt ist es ein Öl direkt an Ihrem Penis verwenden exakt die gleichen Ergebnisse, die Sie von der Einnahme männlichen Verbesserung Tabletten erhalten zu bekommen.
<G-vec00272-001-s701><apply.verwenden><en> For this keyframe you can apply the same keyframe assistant (Easy Ease) and change the speed in the graph editor, just like in the others layers.
<G-vec00272-001-s701><apply.verwenden><de> Für diesen Keyframe könnt ihr denselben Keyframe-Assistenten (Easy Ease) verwenden und die Geschwindigkeit im Diagrammeditor ändern, genau wie in den anderen Ebenen.
<G-vec00272-001-s702><apply.verwenden><en> In order to ease application, patients may use a cotton swab to apply it.
<G-vec00272-001-s702><apply.verwenden><de> Um die Anwendung zu erleichtern, können die Patienten einen Wattestäbchen verwenden.
<G-vec00272-001-s741><apply.zutreffen><en> At the end of this course, successful students will (i) have learned intermediate concepts from microeconomics, (ii) understand how these concepts apply to the world around them and to their own lives, and (iii) have constructed a fairly sophisticated basis from which to study other areas of economics.
<G-vec00272-001-s741><apply.zutreffen><de> Am Ende dieses Kurses werden erfolgreiche Studenten (i) Zwischenkonzepte aus der Mikroökonomie gelernt haben, (ii) verstehen, wie diese Konzepte auf die Welt um sie herum und auf ihr eigenes Leben zutreffen, und (iii) eine ziemlich ausgeklügelte Basis daraus konstruiert haben welches andere Bereiche der Wirtschaft studiert.
<G-vec00272-001-s742><apply.zutreffen><en> 4.Out of the window light:a light window is 1.0 cmX2.5 cm,the coated filter is used in the 610-1200nm wavelength,apply to depilation;another light window is 1.4 cmX3.4 cm,the coated filter is used in the 530-1200nm wavelength,apply to tender skin.
<G-vec00272-001-s742><apply.zutreffen><de> 4. aus dem Fensterlicht heraus: ein helles Fenster ist 1,0 cmX2.5 cm, der überzogene Filter wird verwendet in der Wellenlänge 610-1200nm, zutreffen auf Enthaarung; ein anderes helles Fenster ist 1,4 cmX3.4 cm, der überzogene Filter wird verwendet in der Wellenlänge 530-1200nm, zutreffen auf zarte Haut.
<G-vec00272-001-s743><apply.zutreffen><en> 4.Out of the window light:a light window is 1.0 cmX2.5 cm,the coated filter is used in the 610-1200nm wavelength,apply to depilation;another light window is 1.4 cmX3.4 cm,the coated filter is used in the 530-1200nm wavelength,apply to tender skin.
<G-vec00272-001-s743><apply.zutreffen><de> 4. aus dem Fensterlicht heraus: ein helles Fenster ist 1,0 cmX2.5 cm, der überzogene Filter wird verwendet in der Wellenlänge 610-1200nm, zutreffen auf Enthaarung; ein anderes helles Fenster ist 1,4 cmX3.4 cm, der überzogene Filter wird verwendet in der Wellenlänge 530-1200nm, zutreffen auf zarte Haut.
<G-vec00272-001-s744><apply.zutreffen><en> Some lenders will only process money during business days, which can be a problem if you apply on the weekend.
<G-vec00272-001-s744><apply.zutreffen><de> Einige kreditgebende Stellen verarbeiten nur Geld während der Werktage, die ein Problem sein können, wenn Sie am Wochenende zutreffen.
<G-vec00272-001-s745><apply.zutreffen><en> The rules that apply to the provision of tax from sales across states, let alone across continents, are still not that precise.
<G-vec00272-001-s745><apply.zutreffen><de> Die Richtlinien, die auf die Bestimmung der Steuer von den Verkäufen über Zuständen, geschweige denn über Kontinenten zutreffen, sind noch nicht exakte die.
<G-vec00272-001-s746><apply.zutreffen><en> A belief that we are so brilliant and innovative that the mundane rules of accounting, corporate governance, and even basic economics do not apply to us.
<G-vec00272-001-s746><apply.zutreffen><de> Eine Überzeugung, dass wir so brillant und erfinderisch sind, so dass die banalen Richtlinien der Buchhaltung, der Unternehmensführung und sogar der Volkswirtschaft nicht auf uns zutreffen.
<G-vec00272-001-s747><apply.zutreffen><en> Additional terms and conditions may apply to reservations, purchases of goods and services and other uses of portions of this site, and you agree to abide by such other terms and conditions.
<G-vec00272-001-s747><apply.zutreffen><de> Zusätzliche Bedingungen können auf Reservierungen, Einkäufe von Waren und Services und andere Gebräuche dieser Seite zutreffen, und Sie sind damit einverstanden, sich solche andere Bedingungen zu halten.
<G-vec00272-001-s748><apply.zutreffen><en> A: Yes, all our products are strictly apply with ISO, CE TUV or any other special requirements as customers.
<G-vec00272-001-s748><apply.zutreffen><de> A: Ja sind alle unsere Produkte zutreffen ausschließlich mit ISO, CER TUV oder allen anderen speziellen Anforderungen als Kunden.
<G-vec00272-001-s749><apply.zutreffen><en> His group will apply the magnet to the left side of the head in some patients, and the right side in others.
<G-vec00272-001-s749><apply.zutreffen><de> Seine Fraktion wird der Magnet auf der linken Seite des Kopfes bei einigen Patienten zutreffen, und die rechte Seite in andere.
<G-vec00272-001-s750><apply.zutreffen><en> They may or may not apply to your situation, but I think somebody may find them useful.
<G-vec00272-001-s750><apply.zutreffen><de> Sie können auf Deine Situation zutreffen oder nicht, doch ich hoffe, jemand findet sie nützlich.
<G-vec00272-001-s751><apply.zutreffen><en> They are basically all terms that apply to me, but they only represent a part of me.
<G-vec00272-001-s751><apply.zutreffen><de> Das sind im Grunde genommen alles Begriffe, die auf mich zutreffen, aber es macht nur einen Teil von mir aus.
<G-vec00272-001-s752><apply.zutreffen><en> If imponderables occur or if the assumptions on which the forward-looking statements are made do not apply, actual results may deviate materially from the statements made or the results implicitly expressed.
<G-vec00272-001-s752><apply.zutreffen><de> Sollten Unwägbarkeiten eintreten oder die den vorausschauenden Aussagen zugrunde liegenden Prämissen nicht zutreffen, könnten die tatsächlichen Ergebnisse wesentlich von den getroffenen Aussagen oder implizit zum Ausdruck gebrachten Ergebnissen abweichen.
<G-vec00272-001-s753><apply.zutreffen><en> Contribution to Free Software projects seems a slightly better choice, but as many Free Software projects have adopted a collaborative development model in which the users themselves drive development, that label would then also apply to companies that aren't Information Technology (IT) companies.
<G-vec00272-001-s753><apply.zutreffen><de> Die Mitwirkung an Freie-Software-Projekten scheint eine etwas bessere Wahl zu sein, aber da viele Freie-Software-Projekte ein kollaboratives Entwicklungsmodell übernommen haben, in dem die Benutzer selbst die Entwicklung vorantreiben, würde diese Bezeichnung dann auch auf Unternehmen zutreffen, die keine Unternehmen der Informationstechnik (IT) sind.
<G-vec00272-001-s754><apply.zutreffen><en> After you have received the documents from the school you apply to the embassy or consulate for a visa.
<G-vec00272-001-s754><apply.zutreffen><de> Nachdem Sie die Dokumente von der Schule empfangen, zutreffen Sie auf die Botschaft oder das Konsulat für ein Visum.
<G-vec00272-001-s755><apply.zutreffen><en> His seven rules for life and design happiness can (with some customizations) apply to everyone seeking more joy. Play
<G-vec00272-001-s755><apply.zutreffen><de> Seine sieben Regeln für das Leben und die Gestalt von Zufriedenheit kann (mit einigen Anpassungen) auf jeden zutreffen, der nach mehr Freude sucht.
<G-vec00272-001-s756><apply.zutreffen><en> In this case, the category or categories which do not apply to your product will not appear.
<G-vec00272-001-s756><apply.zutreffen><de> In diesem Fall werden Kategorien, die nicht auf Ihr Produkt zutreffen, nicht angezeigt.
<G-vec00272-001-s757><apply.zutreffen><en> Although it is important to scrutinize the teachings to see if they are valid, we need to think first in terms of how they would apply in our daily lives.
<G-vec00272-001-s757><apply.zutreffen><de> Obwohl es wichtig ist, die Lehren auf ihre Stichhaltigkeit zu untersuchen, müssen wir zuerst darüber nachdenken, wie sie hinsichtlich unseres Alltags zutreffen.
<G-vec00272-001-s758><apply.zutreffen><en> Also, when evaluating a data sheet, pay attention to the methods that apply to your situation.
<G-vec00272-001-s758><apply.zutreffen><de> Achten Sie außerdem beim Auswerten eines Produktdatenblatts auf die Methoden, die auf Ihre Situation zutreffen.
<G-vec00272-001-s759><apply.zutreffen><en> An authority can for instance search for persons with a specific religious affiliation and occupational qualification who regularly visit a certain meeting place. If there is a match, the requesting authority not only receives information about which authority has these data, but also the names, addresses and other basic information about all persons to whom the characteristics it inquired about apply.
<G-vec00272-001-s759><apply.zutreffen><de> So kann eine Behörde zum Beispiel nach Personen mit einer bestimmten Religionszugehörigkeit und Ausbildung, die einen bestimmten Treffpunkt frequentieren, suchen und erhält im Trefferfall nicht nur die Angabe, welche Behörde darüber Informationen besitzt, sondern auch die Namen, Adressen sowie weitere Grundinformationen von allen Personen, auf die die abgefragten Merkmale zutreffen.
<G-vec00272-001-s760><apply.übernehmen><en> After entering the 192.168.100.1 address and configuring telecomadmin / admintelecom or root / admin, you need to go to the WLAN section, enter the name of your own connection and the new PSK password in the SSID Name field with the obligatory click on the Apply button.
<G-vec00272-001-s760><apply.übernehmen><de> Nachdem Sie die 192.168.100.1-Adresse eingegeben und telecomadmin / admintelecom oder root / admin konfiguriert haben, müssen Sie in den WLAN-Bereich gehen, den Namen Ihrer eigenen Verbindung und das neue PSK-Passwort in das Feld SSID-Name eingeben und auf die Schaltfläche Übernehmen klicken.
<G-vec00272-001-s761><apply.übernehmen><en> Then click “Apply“ to save the settings.
<G-vec00272-001-s761><apply.übernehmen><de> Klicken Sie dann zum Speichern der Einstellungen auf „Übernehmen“.
<G-vec00272-001-s762><apply.übernehmen><en> Then drag the autofill handle down to apply cells with this formula.
<G-vec00272-001-s762><apply.übernehmen><de> Ziehen Sie dann den Autofüll-Handle nach unten, um Zellen mit dieser Formel zu übernehmen.
<G-vec00272-001-s763><apply.übernehmen><en> Click on OK to apply the change.
<G-vec00272-001-s763><apply.übernehmen><de> Klicken Sie auf OK, um die Änderungen zu übernehmen.
<G-vec00272-001-s764><apply.übernehmen><en> If you want to prevent subsequent files and subfolders of the original object from inheriting these audit entries, select the Apply these auditing entries to objects and/or containers within this container only check box.
<G-vec00272-001-s764><apply.übernehmen><de> Wenn diese Überwachungseinträge nicht an die nachfolgenden Dateien und Unterordner des ursprünglichen Objekts vererbt werden sollen, aktivieren Sie das Kontrollkästchen Überwachungseinträge nur für Objekte und/oder Container dieses Containers übernehmen.
<G-vec00272-001-s765><apply.übernehmen><en> "After changing the permissions, click ""Apply"" and then ""YES"" to confirm."
<G-vec00272-001-s765><apply.übernehmen><de> Klicken Sie nach dem Ändern der Berechtigungen auf „Übernehmen“ und anschließend zum Bestätigen auf „Ja“.
<G-vec00272-001-s766><apply.übernehmen><en> "In order to activate the change, click the button ""apply""."
<G-vec00272-001-s766><apply.übernehmen><de> "Um die Änderung zu aktivieren, klicken Sie auf die Schaltfläche ""Übernehmen""."
<G-vec00272-001-s767><apply.übernehmen><en> Click Apply, restart the PC and install SpyHunter.
<G-vec00272-001-s767><apply.übernehmen><de> Klicken Sie auf übernehmen, starten Sie den PC neu und installieren SpyHunter.
<G-vec00272-001-s768><apply.übernehmen><en> Social and Institutional Dimensions of Human Behavior courses allow students to apply critical thinking skills to the understanding of human behavior.
<G-vec00272-001-s768><apply.übernehmen><de> Soziale und institutionelle Dimensionen des menschlichen Verhaltens Kurse ermöglichen den Schülern Fähigkeiten zum kritischen Denken auf das Verständnis des menschlichen Verhaltens zu übernehmen.
<G-vec00272-001-s769><apply.übernehmen><en> Click the Preview button as needed to apply your settings and view the adjusted image before scanning.
<G-vec00272-001-s769><apply.übernehmen><de> Mit Erneute Vorschau lassen Sie die Einstellungen übernehmen und das angepasste Bild anzeigen, bevor der Scanvorgang endgültig gestartet wird.
<G-vec00272-001-s770><apply.übernehmen><en> We will cover travel and accommodation expenses for students coming from Bergen or Tromsø. How to apply:
<G-vec00272-001-s770><apply.übernehmen><de> Für Studenten, die aus Bergen oder Tromsø kommen, übernehmen wir die Reise- und Übernachtungskosten.
<G-vec00272-001-s771><apply.übernehmen><en> If there are dates with multiple formats you want to convert to standard date format, you can try to apply Convert to Date utility of Kutools for Excel .
<G-vec00272-001-s771><apply.übernehmen><de> Wenn Daten mit mehreren Formaten vorliegen, die Sie in das Standard-Datumsformat konvertieren möchten, können Sie versuchen, sie zu übernehmen Convert to Date Nutzen von Kutools for Excel .
<G-vec00272-001-s772><apply.übernehmen><en> Apply the settings and refresh the image in the Preview/Edit area.
<G-vec00272-001-s772><apply.übernehmen><de> Übernehmen der Einstellungen und Aktualisieren des Bildes im Vorschaubereich.
<G-vec00272-001-s773><apply.übernehmen><en> Click the Apply button.
<G-vec00272-001-s773><apply.übernehmen><de> Klicken Sie auf Übernehmen.
<G-vec00272-001-s774><apply.übernehmen><en> Apply to dry, unwashed hair, after the exposure time of 20 minutes.
<G-vec00272-001-s774><apply.übernehmen><de> Übernehmen, um trockene, ungewaschene Haare, nach einer Einwirkungszeit von 20 Minuten.
<G-vec00272-001-s775><apply.übernehmen><en> If you want to save the changes for all recipient lists, click Apply changes to all lists .
<G-vec00272-001-s775><apply.übernehmen><de> Wenn Sie die getroffenen Änderungen für alle Empfängerlisten speichern möchten, klicken Sie auf Änderungen in alle Empfängerlisten übernehmen .
<G-vec00272-001-s776><apply.übernehmen><en> Click on “Apply” button to proceed.
<G-vec00272-001-s776><apply.übernehmen><de> Wählen Sie zum Fortfahren „Übernehmen“.
<G-vec00272-001-s777><apply.übernehmen><en> You can change the state of all new file handlers with a click on the box and the selection of apply and then ok in the menu.
<G-vec00272-001-s777><apply.übernehmen><de> Sie können ändern Sie den Status aller neuen Datei-Handler mit einem Klick auf die box und die Auswahl übernehmen und dann auf ok in das Menü.
<G-vec00272-001-s778><apply.übernehmen><en> If you have previously worked with the Mailings Classic function, you can also select mailings here and apply the content created using this function.
<G-vec00272-001-s778><apply.übernehmen><de> Wenn Sie bisher mit der Funktion Mailings Classic gearbeitet haben, können Sie hier auch Mailings auswählen und deren Inhalte übernehmen, die mit dieser Funktion erstellt wurden.
