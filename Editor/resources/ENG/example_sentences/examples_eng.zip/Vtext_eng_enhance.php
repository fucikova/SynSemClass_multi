<G-vec00386-002-s038><enhance.aufwerten><en> If you would like to enhance your workplace occupier experience, contact Christian Praulich to learn how easy it is to get your building connected to ECN.
<G-vec00386-002-s038><enhance.aufwerten><de> Wenn Sie mehr dazu erfahren wollen, melden Sie sich bei Christian Praulich und Sie werden merken, wie einfach es sein kann, Büroimmobilien digital aufzuwerten.
<G-vec00386-002-s039><enhance.aufwerten><en> Using the 3D import function, you can not only create floor plans and visualize them in 3D, but also have the possibility to enhance the interior and exterior areas with modern 3D furniture from the Internet.
<G-vec00386-002-s039><enhance.aufwerten><de> Mit Hilfe der 3D Import-Funktion können sie nicht nur den Grundriss erstellen und in 3D visualisieren, sondern haben auch die Möglichkeit den Innen- und Außenbereich mit modernen 3D Möbeln aus dem Internet aufzuwerten.
<G-vec00386-002-s040><enhance.aufwerten><en> Colour is not only limited to highlighting novelties, but it also allows, for example, to (re)enhance basics and improve their sales.
<G-vec00386-002-s040><enhance.aufwerten><de> Doch Farbe beschränkt sich nicht darauf, Neuheiten ins rechte Licht zu rücken, sie ermöglicht zum Beispiel auch, Basisprodukte (erneut) aufzuwerten und deren Verkaufszahlen zu steigern.
<G-vec00386-002-s041><enhance.aufwerten><en> Pocket watches are associated with style and taste and are a noble way to enhance a costume.
<G-vec00386-002-s041><enhance.aufwerten><de> Taschenuhren werden mit Stil und Geschmack in Verbindung gebracht und sind eine edle Art Kostüme aufzuwerten.
<G-vec00386-002-s042><enhance.aufwerten><en> We’re dedicated to helping neurologists across the globe enhance their practice by offering the latest medical news, and information on topics such as primary care neurology and neurological disorders.
<G-vec00386-002-s042><enhance.aufwerten><de> Wir möchten Neurologen auf der ganzen Welt dabei helfen, das Angebot ihrer Praxis durch die neuesten medizinischen Nachrichten, Informationen und fachkundigen Hinweise zu Themen wie der neurologischen Grundversorgung und neurologischen Störungen aufzuwerten.
<G-vec00386-002-s043><enhance.aufwerten><en> The Bachelor of Interior Design offers students the opportunity to connect, collaborate, innovate and enhance the world around them through design.
<G-vec00386-002-s043><enhance.aufwerten><de> Der Bachelor of Interior Design bietet Studenten die Möglichkeit, die Welt um sie herum durch Design zu verbinden, zusammenzuarbeiten, zu erneuern und aufzuwerten.
<G-vec00386-002-s044><enhance.aufwerten><en> A beautiful piece for women who like to be the centre of attention and for women who like to enhance plain looks with impressive jewellery.
<G-vec00386-002-s044><enhance.aufwerten><de> Ein schönes Stück für Frauen, die gerne im Mittelpunkt stehen, und solche, die es mögen, schlichte Looks mit eindrucksvollem Schmuck aufzuwerten.
<G-vec00386-002-s045><enhance.aufwerten><en> President Emmanuel Macron had announced in the election campaign his intention to reduce the basic salary in the health sector by a maximum of 50 percent by the end of his five-year term in order to enhance quality and performance.
<G-vec00386-002-s045><enhance.aufwerten><de> Präsident Emmanuel Macron hatte im Wahlkampf bereits angekündigt, im Gesundheitswesen die Basisvergütung „per vollzogenem Akt“ bis zum Ende seiner fünfjährigen Amtszeit auf maximal 50 Prozent abzusenken, um qualitäts- und leistungsgerechtere Aspekte aufzuwerten.
<G-vec00386-002-s046><enhance.aufwerten><en> The ITRS Roadmap is our guideline - our central aim, however, is to enhance and expand the CMOS technologies it recommends with additional, special analog functions and modular options.
<G-vec00386-002-s046><enhance.aufwerten><de> Die ITRS-Roadmap ist natürlich unser Leitfaden – Hauptziel von X-FAB ist jedoch, die darin empfohlenen CMOS- und BiCMOS-Technologien mit zusätzlichen, speziellen analogen Funktionen und modularen Optionen aufzuwerten und zu erweitern.
<G-vec00386-002-s047><enhance.aufwerten><en> The flowers in a garden do not try to enhance themselves by stepping on other flowers.
<G-vec00386-002-s047><enhance.aufwerten><de> Die Blumen in einem Garten sind nicht bemüht, sich selbst aufzuwerten, indem sie auf anderen Blumen herumtreten.
<G-vec00386-002-s048><enhance.aufwerten><en> The excellent results that can be obtained on a national and international level through the enforcement of industrial property rights allow companies to effectively enhance their own intangible assets, both in Italy and in countries where most of the world output is now based.
<G-vec00386-002-s048><enhance.aufwerten><de> Die hervorragenden Ergebnisse, die auf nationaler und internationaler Ebene durch die Stärkung der gewerblichen Eigentumsrechte erzielt werden können, ermöglichen es den Unternehmen, ihre immateriellen Güter sowohl in Italien, als auch in jenen Ländern, wo sich ein Großteil der weltweiten Produktion konzentriert, wirksam aufzuwerten.
<G-vec00386-002-s049><enhance.aufwerten><en> To further enhance a plain engraved sign, color accents can be added by gluing on elements, for example made of TroLase ADA or other materials.
<G-vec00386-002-s049><enhance.aufwerten><de> Um ein einfach graviertes Schild noch weiter aufzuwerten, können durch das Aufkleben von Elementen, beispielsweise aus TroLase ADA oder anderen Materialien, Farbakzente gesetzt werden.
<G-vec00386-002-s050><enhance.aufwerten><en> Keep the background pictures free of clutter to enhance the design without stealing the attention from the main message.
<G-vec00386-002-s050><enhance.aufwerten><de> Halte die Hintergrundbilder frei von Unordnung, um das Design aufzuwerten, ohne den Fokus auf die Hauptbotschaft zu verlieren.
<G-vec00386-002-s051><enhance.aufwerten><en> At night, you can take wonderful advantage of that in order to enhance the your photos with so-called light trails, traces of light from passing vehicles.
<G-vec00386-002-s051><enhance.aufwerten><de> Nachts kann man das wunderbar ausnutzen, um seine Fotos mit sogenannten Light Trails, also den Lichtspuren der vorbeifahrenden Fahrzeuge, aufzuwerten.
<G-vec00386-002-s052><enhance.aufwerten><en> 41 of the Princes’ Hunting Pleasure, in America to use the same drawing for illustration of a translation of Löns’ “Warwolf” or elsewhere to enhance commodity labels by stag + boar – so all these are good market signs for a quite agreeable development of the degree of familiarity with the brand Ridinger.
<G-vec00386-002-s052><enhance.aufwerten><de> 41 der Fürstenlust-Folge an wieder aktuell werdende frühere Mitjäger zu erinnern, in Amerika dieselbe Zeichnung zur Illustrierung einer Übersetzung von Löns’ „Werwolf“ zu nutzen oder anderwärts mit Hirsch + Sau Warenetiketten aufzuwerten – so sind all dies gute Markt-Signale für eine sehr erfreuliche Weiterentwicklung des Bekanntheitsgrades der Marke Ridinger.
<G-vec00386-002-s053><enhance.aufwerten><en> Blue is utilized throughout to promote a calming and comfortable effect and to enhance the aquatic theme. Hotel Washington
<G-vec00386-002-s053><enhance.aufwerten><de> Die Farbe Blau ist überall zu sehen, um einen beruhigenden und angenehmen Effekt zu begünstigen und das Thema Wasser aufzuwerten.
<G-vec00386-002-s054><enhance.aufwerten><en> The Styled Text format allows you to enhance your text messages with styles such as bold, italic, underline, colors, fonts and sizes.
<G-vec00386-002-s054><enhance.aufwerten><de> 'Formatierter Text' erlaubt Ihnen, Ihre Nachricht mit Stilmitteln wie Fettdruck, Kursivschrift, Unterstreichen, Farbe, verschiedene Schriftarten und -größen aufzuwerten.
<G-vec00386-002-s055><enhance.aufwerten><en> It has been made with my old camera, but I tried to enhance the quality a bit.
<G-vec00386-002-s055><enhance.aufwerten><de> Die Qualität von meinem damaligen Fotoapparat war nicht sonderlich gut und ich habe versucht, das Video etwas aufzuwerten.
<G-vec00386-002-s056><enhance.aufwerten><en> We’re dedicated to helping gastroenterologists across the globe enhance their practice by offering the latest medical news, information, and expert advice on topics such as inflammatory bowel disease and pathology.
<G-vec00386-002-s056><enhance.aufwerten><de> Wir möchten Gastroenterologen auf der ganzen Welt dabei helfen, das Angebot ihrer Praxis durch die neuesten medizinischen Nachrichten, Informationen und fachkundigen Hinweise zu Themen wie entzündliche Darmerkrankungen und Pathologie aufzuwerten.
<G-vec00386-002-s057><enhance.ausbauen><en> The company’s robust fundamentals will serve as a catalyst to accelerate our product development and further enhance our service offerings.
<G-vec00386-002-s057><enhance.ausbauen><de> Die soliden Fundamentaldaten des Unternehmens werden als Katalysator wirken und uns in die Lage versetzen, unsere Produktentwicklung zu beschleunigen und unser Serviceangebot weiter auszubauen.
<G-vec00386-002-s058><enhance.ausbauen><en> We want to maintain and enhance this lead, even in the face of growing global competition.
<G-vec00386-002-s058><enhance.ausbauen><de> Diese gute Ausgangsposition gilt es auch in Zukunft gegenüber weltweit wachsender Konkurrenz zu halten und auszubauen.
<G-vec00386-002-s059><enhance.ausbauen><en> A wide variety of learning opportunities are provided through the CGI Leadership Institute to help you continuously develop your leadership abilities and enhance your knowledge in your area of expertise.
<G-vec00386-002-s059><enhance.ausbauen><de> Das CGI Leadership Institute bietet eine Vielzahl von Weiterbildungsmöglichkeiten, die Ihnen helfen, Ihre Führungskompetenzen kontinuierlich weiterzuentwickeln und Ihr Wissen in Ihrem Fachgebiet auszubauen.
<G-vec00386-002-s060><enhance.ausbauen><en> This tool is having a good acceptance, so our intention in the short and medium term is to enhance it further and include new features.
<G-vec00386-002-s060><enhance.ausbauen><de> Dieses Werkzeug hat eine gute Aufnahme gefunden; daher ist es unser Bestreben, es kurz- bis mittelfristig auszubauen und weitere Funktionalitäten hinzuzufügen.
<G-vec00386-002-s061><enhance.ausbauen><en> In partnership with Guggenheim Investments and Temasek, Eastdil Secured will be positioned to further enhance its leading role in the U.S. commercial real estate capital markets, while also strengthening its growing presence in both Europe and Asia.
<G-vec00386-002-s061><enhance.ausbauen><de> In Zusammenarbeit mit Guggenheim Investments und Temasek wird Eastdil Secured gut positioniert sein, um ihre führende Rolle auf den US-amerikanischen Kapitalmärkten für gewerbliche Immobilien weiter auszubauen und gleichzeitig ihre wachsende Präsenz in Europa und Asien zu stärken.
<G-vec00386-002-s062><enhance.ausbauen><en> The Federal Statistical Office has committed itself to assure and further enhance the level of quality achieved.
<G-vec00386-002-s062><enhance.ausbauen><de> Das Statistische Bundesamt hat sich verpflichtet, das erreichte Qualitätsniveau auch künftig zu gewährleisten und auszubauen.
<G-vec00386-002-s063><enhance.ausbauen><en> Any suggestion helps us to enhance our service and to better live up to our promise of quality.
<G-vec00386-002-s063><enhance.ausbauen><de> Jede Anregung hilft uns, unser Service auszubauen und unser Qualitätsversprechen an Sie noch besser umzusetzen.
<G-vec00386-002-s064><enhance.ausbauen><en> Far from moving toward disarmament, the intention seems to be to maintain and enhance every component of America’s current land, sea, and airborne nuclear capability.
<G-vec00386-002-s064><enhance.ausbauen><de> Weit entfernt von einer Abrüstung scheint es die Absicht zu sein, jede Komponente der aktuellen atomaren Kapazität der Vereinigten Staaten zu Lande, zu Wasser und in der Luft aufrechtzuerhalten und auszubauen.
<G-vec00386-002-s065><enhance.ausbauen><en> This gives them the chance to enhance their research and teaching profile, enabling them then to apply for full professorships.
<G-vec00386-002-s065><enhance.ausbauen><de> Sie erhalten damit die Möglichkeit, ihr Forschungs- und Lehrprofil auszubauen, um sich anschließend auf eine volle Professur zu bewerben.
<G-vec00386-002-s066><enhance.ausbauen><en> Uwaga: Adobe is not planning to further enhance this capability (Managing Leads and Lists).
<G-vec00386-002-s066><enhance.ausbauen><de> Hinweis: Adobe plant nicht, diese Funktionen (Lead- und Listenverwaltung) weiter auszubauen.
<G-vec00386-002-s067><enhance.ausbauen><en> Opmerking: Adobe is not planning to further enhance E-mail tracking of open/bounces (not deliverable) send by AEM SMTP service.
<G-vec00386-002-s067><enhance.ausbauen><de> Adobe plant nicht, die E-Mail-Verfolgung von über den AEM-SMTP-Dienst gesendeten offenen/zurückgesendeten (nicht zustellbaren) Nachrichten weiter auszubauen.
<G-vec00386-002-s068><enhance.ausbauen><en> In the wake of the US initiative, Western European imperialism and Australia similarly hope to enhance their positions in the region.
<G-vec00386-002-s068><enhance.ausbauen><de> In Gefolge der US-Initiative hoffen auch westeuropäische Großmächte und Australien, ihre Positionen in der Region auszubauen.
<G-vec00386-002-s069><enhance.ausbauen><en> - Timely progress must be made on the processes already begun with the Single European Sky to enhance the performance of the European air traffic management system.
<G-vec00386-002-s069><enhance.ausbauen><de> - Die Prozesse, die mit der Initiative für einen einheitlichen europäischen Luftraum begonnen haben, müssen zügig vorangetrieben werden, um das Europäische Luftverkehrsmanagementsystem auszubauen.
<G-vec00386-002-s070><enhance.ausbauen><en> The two-month capacity building program in Germany offers 30 START fellows the opportunity to enhance their applied knowledge in international cultural management.
<G-vec00386-002-s070><enhance.ausbauen><de> Das zweimonatige Fortbildungs- und Hospitationsprogramm in Deutschland ermöglicht 30 START Stipendiaten, ihre Fähigkeiten im internationalen Kulturmanagement auszubauen.
<G-vec00386-002-s071><enhance.ausbauen><en> In his new position with Uptrends, Mr. Nahnsen will enhance the visibility, customer reach and capabilities of the company and its service offerings.
<G-vec00386-002-s071><enhance.ausbauen><de> In seiner neuen Tätitgkeit bei Uptrends wird Herr Nahnsen intensiv daran arbeiten, die Sichtbarkeit von Uptrends im deutschen Markt stark auszubauen, sowie die Kundenansprache deutlich zu intensiviern.
<G-vec00386-002-s072><enhance.bereichern><en> New senior executives with external experience enhance our culture and widen our know-how.
<G-vec00386-002-s072><enhance.bereichern><de> Neue Führungskräfte mit externen Erfahrungen bereichern unsere Kultur und erweitern unser Know-how.
<G-vec00386-002-s073><enhance.bereichern><en> Guided tours offer variety, action and adventure, and thus enhance any holiday.
<G-vec00386-002-s073><enhance.bereichern><de> Geführte Touren bieten Abwechslung, Action und Abenteuer und bereichern somit jeden Urlaub.
<G-vec00386-002-s074><enhance.bereichern><en> We use cookies to let us know when you visit our website, how you interact with us, to enhance your user experience and to personalize your relationship with our website.
<G-vec00386-002-s074><enhance.bereichern><de> Wir verwenden Cookies, um uns zu informieren, ob Sie unsere Websites besuchen, wie Sie mit uns interagieren, um Ihre Nutzererfahrung zu bereichern und um Ihre Beziehung zu unserer Website anzupassen.
<G-vec00386-002-s075><enhance.bereichern><en> Each composition is a call to write unique and sincere melodies that enhance the storytelling experience.
<G-vec00386-002-s075><enhance.bereichern><de> Jede Komposition ist für ihn eine Gelegenheit, einzigartige und authentische Melodien zu schreiben, die das Geschichtenerzählen bereichern.
<G-vec00386-002-s076><enhance.bereichern><en> Ecological Focus Areas (EFA) enhance the landscape with their richly coloured flowers.
<G-vec00386-002-s076><enhance.bereichern><de> Die Biodiversitätsförderflächen (BFF) bereichern durch ihre farbenreichen Blüten das Landschaftsbild.
<G-vec00386-002-s077><enhance.bereichern><en> The ad network searches for a tool that can be easily integrated to the existing platform but would still enhance and improve the traffic filtering and targeting process.
<G-vec00386-002-s077><enhance.bereichern><de> Ad network sucht nach einem Werkzeug, welches leicht in eine bestehende Plattform integriert werden kann, aber dennoch den Prozess der Traffic-Filterung und des Targeting bereichern und verbessern würde.
<G-vec00386-002-s078><enhance.bereichern><en> You’ll cruise comfortably aboard one of the biggest boats operating from Exmouth on the Ningaloo Reef and the friendly and experienced skipper and crew are always on hand to assist and enhance your Whale Shark swim.
<G-vec00386-002-s078><enhance.bereichern><de> Sie fahren an Bord eines der größten zwischen Exmouth und dem Ningaloo-Riff operierenden Boote und der freundliche, erfahrene Skipper und seine Crew stehen Ihnen zur Seite und bereichern Ihre Walhaie-Begegnung.
<G-vec00386-002-s079><enhance.bereichern><en> Among other things, analyses of this exploding market in Asia will very much enhance our research.
<G-vec00386-002-s079><enhance.bereichern><de> Analysen von dem explodierenden Markt in Asien würden die Forschungen sehr bereichern.
<G-vec00386-002-s080><enhance.bereichern><en> This is why SATEL presents with even a greater pleasure further new solutions that significantly expand and enhance our product offering.
<G-vec00386-002-s080><enhance.bereichern><de> Desto größer ist unsere Freude, Ihnen weitere neue Lösungen darstellen zu können, die unser Produktsortiment erheblich bereichern.
<G-vec00386-002-s081><enhance.bereichern><en> To enhance your visit, 250 m² of exhibition built inside the fort.
<G-vec00386-002-s081><enhance.bereichern><de> Um Ihren Besuch zu bereichern, wurden 250 m² Ausstellungsfläche innerhalb der Festung gebaut.
<G-vec00386-002-s082><enhance.bereichern><en> Not only can they enhance a portrait but it just helps someone feel so much more comfortable as they then have something to actually do or they can play some kind of part and pretend to be someone else.
<G-vec00386-002-s082><enhance.bereichern><de> Sie können ein Porträt nicht nur bereichern, sondern den Menschen auch helfen, sich wohler zu fühlen, weil sie dann etwas zu tun haben oder in eine Rolle schlüpfen und so tun können, als wären sie jemand anders.
<G-vec00386-002-s083><enhance.bereichern><en> We are certain that this gadget will enhance your travel experience and add convenience to your trip.
<G-vec00386-002-s083><enhance.bereichern><de> Wir sind sicher, dass dieses Gadget Eure Reise extrem bereichern und vereinfachen wird.
<G-vec00386-002-s084><enhance.bereichern><en> With the 4-part kitchen helper set made of PEFC certified cherry wood from Biodora you enhance your eco-friendly kitchen.
<G-vec00386-002-s084><enhance.bereichern><de> Mit dem 4-teiligen Küchenhelfer-Set aus PEFC zertifiziertem Kirschholz von Biodora bereichern Sie Ihre Bio-Küche.
<G-vec00386-002-s085><enhance.bereichern><en> Fine materials enhance the classic lines of the lightweight sweater.
<G-vec00386-002-s085><enhance.bereichern><de> Die hochwertigen Materialien bereichern die klassischen Linien der leichten Pullover.
<G-vec00386-002-s086><enhance.bereichern><en> With the payment of your License charge, you have access to a set of valuable support services that enhance your experience with your 3DS solutions.
<G-vec00386-002-s086><enhance.bereichern><de> Nach Zahlung Ihrer Lizenzgebühr haben Sie Zugriff auf eine Reihe wertvoller Support-Services, die Ihre Erfahrungen mit den 3DS-Lösungen bereichern.
<G-vec00386-002-s087><enhance.bereichern><en> The Italo 900 team source items that they believe will enhance their customers' living spaces and will complement their lifestyle philosophies, both from named designers as well as unknown producers.
<G-vec00386-002-s087><enhance.bereichern><de> Das Team von Italo 900 trägt vor allem Stücke namenhafter Designer aber auch weniger bekannter Hersteller zusammen, von denen man überzeugt ist, dass sie den Wohnraum ihrer Kunden bereichern und deren Lifestyle-Philosophie ergänzen.
<G-vec00386-002-s088><enhance.bereichern><en> The readily available Perfect Doctor Icons will enhance the appearance of any healthcare application or medically related software.
<G-vec00386-002-s088><enhance.bereichern><de> Die sofort verfügbaren Medical Toolbar Icons bereichern den Auftritt jeder Gesundheitsanwendung oder medizinischen Software.
<G-vec00386-002-s089><enhance.bereichern><en> After having enjoyed the indoor pool where the walls display a stylized representation of the castle setting, enhance your wellness by a visit to our steam sauna or the Finnish sauna and a soothing fully body massage, thus making your wellness holiday in South Tyrol a perfect experience.
<G-vec00386-002-s089><enhance.bereichern><de> Nach einer Erfrischung im Hallenbad mit der stilisierten Schlosslandschaft an den Wänden, bereichern Sie ihren Wellnessurlaub in Südtirol mit einem Besuch der Dampfsauna oder der finnische Sauna und mit einer wohltuenden Ganzkörpermassage.
<G-vec00386-002-s090><enhance.bereichern><en> It is the perfect real-time personalization that fits seamlessly with our philosophy and has the potential to really enhance our business model,” says Max Wittrock, co-founder of mymuesli, speaking as the Heidelberg Omnifire is unveiled at the mymuesli store in Heidelberg.
<G-vec00386-002-s090><enhance.bereichern><de> Das ist perfekte Echtzeitindividualisierung, die hervorragend zu unserer Philosophie passt und das Potenzial hat, unser Geschäftsmodell zu bereichern“, so Max Wittrock, Mitgründer von mymuesli, beim Startschuss für die Heidelberg Omnifire im Heidelberger mymuesli Shop.
<G-vec00386-002-s167><enhance.ergänzen><en> Our partners enhance their own portfolio of solutions with the innovative Insiders products.
<G-vec00386-002-s167><enhance.ergänzen><de> Unsere Partner ergänzen ihr Lösungsportfolio um die innovativen Insiders Produkte.
<G-vec00386-002-s168><enhance.ergänzen><en> A nominally skilled webmaster can find schemas with the matching topic for your websites and can in turn enhance the side code with it.
<G-vec00386-002-s168><enhance.ergänzen><de> Webmaster finden dort Schemata mit dem passenden Thema zu ihren Websites und können den Code damit ergänzen.
<G-vec00386-002-s169><enhance.ergänzen><en> Personalise the appearance of your Land Rover with alloy wheels, and enhance them with styled and branded accessories.
<G-vec00386-002-s169><enhance.ergänzen><de> ZUBEHÖR – FELGEN Individualisieren Sie Ihren Land Rover mit Leichtmetallfelgen und ergänzen Sie diese durch weiteres attraktives Land Rover Zubehör.
<G-vec00386-002-s170><enhance.ergänzen><en> Two semi-automatic units for the quick change of synthetic brake fluids enhance the Hella Gutmann product range.
<G-vec00386-002-s170><enhance.ergänzen><de> Zwei halbautomatische Geräte für das schnelle Wechseln synthetischer Bremsflüssigkeiten ergänzen das Hella Gutmann-Produktprogramm.
<G-vec00386-002-s171><enhance.ergänzen><en> You can enhance your 3D data with drawing annotations, such as marks, dimensions and more.
<G-vec00386-002-s171><enhance.ergänzen><de> Sie können Ihre 3D-Daten durch Zeichnungsanmerkungen wie Anmerkungen, Maßlinien und mehr ergänzen.
<G-vec00386-002-s172><enhance.ergänzen><en> Cost-effective additional functions such as differential switching (rapid), pressure switch connections, function base plates and additional modules extend and enhance the range of applications.
<G-vec00386-002-s172><enhance.ergänzen><de> Kostengünstige Zusatzfunktionen wie Differentialschaltung (Eilgang), Druckschalteranschlüsse, Funktionsgrundplatten und Zusatzmodule erweitern und ergänzen die Einsatzmöglichkeiten.
<G-vec00386-002-s173><enhance.ergänzen><en> At the Indie Arena Booth numerous exciting new launches and creative titles await the visitors - further offers of independent developers will perfectly enhance the offerings in the new Indie section.
<G-vec00386-002-s173><enhance.ergänzen><de> Auf dem Indie Arena Booth werden wieder zahlreiche spannende Neuvorstellungen und kreative Titel auf die Besucher warten – weitere Angebote unabhängiger Entwickler werden das Angebot im neuen Indie Bereich perfekt ergänzen.
<G-vec00386-002-s174><enhance.ergänzen><en> In order to accommodate such complex operations and complementary functions in the input unit, our experts enhance the joysticks with individual functions by means of integrating special joystick buttons or rocker switches into the multi-purpose grip.
<G-vec00386-002-s174><enhance.ergänzen><de> Um solche komplexen Bedienvorgänge und Funktionserweiterungen im Eingabegerät unterzubringen, ergänzen unsere Experten die Joysticks individuell durch Integration von speziellen Joystick-Schaltern oder -Wippen im Multifunktionsgriff.
<G-vec00386-002-s175><enhance.ergänzen><en> The aggregated results enhance the enterprise´s comprehensive quality management system, which complies with German and international standards.
<G-vec00386-002-s175><enhance.ergänzen><de> Die so aggregierten Wirkungen ergänzen das umfassende Qualitätsmanagement der GIZ, das sich an nationalen und internationalen Standards orientiert.
<G-vec00386-002-s176><enhance.ergänzen><en> Gerresheimer, a worldwide leader in primary packaging solutions for the pharmaceutical industry, will enhance its portfolio by adding Gx RTF vials.
<G-vec00386-002-s176><enhance.ergänzen><de> Gerresheimer, ein führender globaler Hersteller von Primärverpackungen für die pharmazeutische Industrie, wird sein Produktangebot um Gx RTF Vials ergänzen.
<G-vec00386-002-s177><enhance.ergänzen><en> To enhance your demonstration you can add speech bubbles, animated GIFs, or magnifiers to guide viewers in your recording.
<G-vec00386-002-s177><enhance.ergänzen><de> Um die Aufnahme zu ergänzen, können Sprechblasen, animierte GIFs oder Lupen hinzugefügt werden, um zu kommentieren oder auf etwas hinzuweisen.
<G-vec00386-002-s178><enhance.ergänzen><en> Jeans in various fits and authentic washes enhance your outfit.
<G-vec00386-002-s178><enhance.ergänzen><de> Jeans in verschiedenen Fits und authentischen Waschungen ergänzen das Outfit.
<G-vec00386-002-s179><enhance.ergänzen><en> There are different components and modules which can enhance and extend the existing installation by upgrading with new functions and increasing performance.
<G-vec00386-002-s179><enhance.ergänzen><de> Zur Erweiterung mit neuen Funktionen und zur Erhöhung der Leistungsfähigkeit gibt es verschiedene Komponenten und Module, welche die bestehende Installation ergänzen und erweitern.
<G-vec00386-002-s180><enhance.ergänzen><en> A selection of decorative prints and a section with autographs of well-known personalities enhance our range.
<G-vec00386-002-s180><enhance.ergänzen><de> Eine Auswahl an dekorativer Graphik und eine Abteilung mit Autographen bedeutender Persönlichkeiten ergänzen unser Programm.
<G-vec00386-002-s181><enhance.ergänzen><en> As our largest technical project, Wikidata plays an important role in this program. We plan to develop a tagging system for Wikimedia Commons in order to enhance the existing categories system and to partly replace it.
<G-vec00386-002-s181><enhance.ergänzen><de> Als größtes technisches Projekt von Wikimedia Deutschland spielt Wikidata eine wichtige Rolle für diese Programmlinie: Geplant ist, ein Verschlagwortungssystem für Wikimedia Commons zu entwickeln, um das vorhandene Kategoriesystem zu ergänzen und teilweise zu ersetzen.
<G-vec00386-002-s182><enhance.ergänzen><en> athletes discovered that an impact-absorbing – but not soft – floor can perfectly enhance training: The floor as part of the three-dimensional functional workout.
<G-vec00386-002-s182><enhance.ergänzen><de> Unsere Athleten fanden vielmehr heraus, dass ein dämpfender – aber kein weicher – Boden das Training perfekt ergänzen kann: Der Boden als Teil des drei-dimensionalen Functional Workouts.
<G-vec00386-002-s183><enhance.ergänzen><en> Only 10 minutes from Oberstaufen, at the borders of Germany, Switzerland and Austria, man-made lakes enhance the beauty of the impressive scenery.
<G-vec00386-002-s183><enhance.ergänzen><de> Nur 10 Minuten von Oberstaufen entfernt im Dreiländereck zwischen Deutschland, der Schweiz und Österreich ergänzen künstliche Seen als Hindernisse die eindrucksvolle Natur.
<G-vec00386-002-s184><enhance.ergänzen><en> We enhance our product offering with goods and brands from all around the world – items which are both stylish and functionally impressive.
<G-vec00386-002-s184><enhance.ergänzen><de> Wir ergänzen unser Angebot durch Produkte und Marken aus aller Welt, die nicht nur stilistisch, sondern auch durch ihre Funktionalität überzeugen.
<G-vec00386-002-s185><enhance.ergänzen><en> An ellipse logo beneath the three-button placket and a bark logo at the back hem enhance the modern look of this Oakley golf polo.
<G-vec00386-002-s185><enhance.ergänzen><de> Ein Ellipse-Logo unterhalb der Zweiknopfleiste und ein Barkette-Logo am Rücken ergänzen den modernen Look dieses Golf-Polohemds von Oakley.
<G-vec00386-002-s205><enhance.erhöhen><en> The hubs with USB™ ceramic bearings (Ultra Smooth Bearings) further enhance the wheels’ smoothness and reduce weight and the need for maintenance.
<G-vec00386-002-s205><enhance.erhöhen><de> Die Naben mit den USB™ (Ultra Smooth Bearings) - Keramiklagern erhöhen die Leichtgängig der Räder weiter und verringern das Gewicht sowie den Wartungsaufwand.
<G-vec00386-002-s206><enhance.erhöhen><en> The Herrenknecht exploration systems enhance safety for personnel and machine, while at the same time making it possible to keep to schedule and budget and ensure rapid tunnelling operations.
<G-vec00386-002-s206><enhance.erhöhen><de> Die Herrenknecht-Vorauserkundungssysteme erhöhen die Sicherheit für Personal und Maschine und ermöglichen gleichzeitig, dass der Zeit- und Kostenrahmen eingehalten und ein zügiger Tunnelvortrieb gewährleistet wird.
<G-vec00386-002-s207><enhance.erhöhen><en> The specific abrasive properties of our cerium-based compounds enhance semiconductor performance and reduce manufacturing quality rejects.
<G-vec00386-002-s207><enhance.erhöhen><de> Die speziellen Abriebeigenschaften unserer Cer-basierten Compounds erhöhen die Leistung von Halbleitern und verringern den Ausschuss während der Fertigung.
<G-vec00386-002-s208><enhance.erhöhen><en> The well-engineered Liebherr components withstand these loads without problem and enhance work safety. Equipment examples
<G-vec00386-002-s208><enhance.erhöhen><de> Die ausgereiften Liebherr-Komponenten halten diesen Belastungen problemlos stand und erhöhen die Arbeitssicherheit.
<G-vec00386-002-s209><enhance.erhöhen><en> You save time and resources, and enhance system security.
<G-vec00386-002-s209><enhance.erhöhen><de> Sie sparen Zeit und Ressourcen und erhöhen die Systemsicherheit.
<G-vec00386-002-s210><enhance.erhöhen><en> Stretch elements enhance freedom of movement to ensure you feel good at all times during ascents and descents.
<G-vec00386-002-s210><enhance.erhöhen><de> Stretch-Elemente erhöhen die Bewegungsfreiheit, damit du dich bei Auf- und Abstiegen jederzeit wohlfühlst.
<G-vec00386-002-s211><enhance.erhöhen><en> A few thousand views enhance credibility and increase visibility.
<G-vec00386-002-s211><enhance.erhöhen><de> Ein paar tausend Aufrufe erhöhen die Glaubwürdigkeit und steigern die Sichtbarkeit.
<G-vec00386-002-s212><enhance.erhöhen><en> The notifications enable regular contact with the customer as well as enhance quality of service and positive awareness of the ISP.
<G-vec00386-002-s212><enhance.erhöhen><de> Sie ermöglichen regelmäßigen Kontakt zu den Kunden und erhöhen die Servicequalität und die positive Wahrnehmung des ISP.
<G-vec00386-002-s213><enhance.erhöhen><en> Hassle-Free hydraulic systems featuring Leak-free O-ring face seal fittings enhance reliability and non-mechanical, Hall-Effect sensors and switches are designed to outlast the life of the truck
<G-vec00386-002-s213><enhance.erhöhen><de> Unkomplizierte Hydrauliksysteme mit leckfreien ORFS-Anschlüssen erhöhen die Zuverlässigkeit und nicht mechanische Hall-Effekt-Sensoren und Schalter sind so konstruiert, dass sie den Stapler überdauern.
<G-vec00386-002-s214><enhance.erhöhen><en> The styling of the indoor station echoes the characteristic features of the Siedle design: The large speech button and limitation to just two operating elements simplifies intuitive operation; the clearly differentiated door release button, the spacing between the buttons and the self-explanatory symbols help prevent operating errors and so enhance security.
<G-vec00386-002-s214><enhance.erhöhen><de> > Galerie aufrufen Die Formgebung der Innenstationen übernimmt charakteristische Eigenschaften des Siedle-Designs: Die große Sprechtaste und die Beschränkung auf zwei Bedienelemente erleichtern die intuitive Bedienung; die klar unterscheidbare Türöffnertaste, der Abstand zwischen den Tasten und die eindeutige Symbolik vermeiden Fehlbedienungen und erhöhen die Sicherheit.
<G-vec00386-002-s215><enhance.erhöhen><en> 42Gears’ MEM tools enhance security and prevent email-based data loss by enforcing strict compliance policies and encrypting sensitive corporate data.
<G-vec00386-002-s215><enhance.erhöhen><de> Die MEM-Tools von 42Gears erhöhen die Sicherheit und verhindern E-Mail-basierten Datenverlust, indem Sie strikte Compliance-Richtlinien durchsetzen und sensible Unternehmensdaten verschlüsseln.
<G-vec00386-002-s216><enhance.erhöhen><en> Sensor-based assistants Driver of the ŠKODA OCTAVIA can count on many assistants – some of them enhance driving comfort, others safety.
<G-vec00386-002-s216><enhance.erhöhen><de> Wer einen ŠKODA Octavia Combi fährt, kann sich auf zahlreiche Assistenten verlassen – einige erhöhen den Fahrkomfort, andere die Sicherheit.
<G-vec00386-002-s217><enhance.erhöhen><en> The newly developed flat carbine enhance security with proven grip safety.
<G-vec00386-002-s217><enhance.erhöhen><de> Die neu entwickelten flachen Karabiner erhöhen die Sicherheit dank bewährter Handballensicherung.
<G-vec00386-002-s218><enhance.erhöhen><en> HPE storage options enhance server performance and reliability for demanding application workloads.
<G-vec00386-002-s218><enhance.erhöhen><de> HPE Speicheroptionen erhöhen die Serverleistung und Serverzuverlässigkeit für anspruchsvolle Anwendungsworkloads.
<G-vec00386-002-s219><enhance.erhöhen><en> In Ostrava, renovated tram stops enhance passenger security and a newly built trolley bus line closes a gap in the city's transport system.
<G-vec00386-002-s219><enhance.erhöhen><de> In Ostrava erhöhen sanierte Tramhaltestellen die Sicherheit der Fahrgäste und eine neu erstellte Trolley-Buslinie schließt eine Lücke im städtischen Verkehrsnetz.
<G-vec00386-002-s220><enhance.erhöhen><en> We support the securing of your investments in technological developments in the field of wind energy, improve time to market of innovative products and enhance certification processes.
<G-vec00386-002-s220><enhance.erhöhen><de> Damit sichern wir Ihre Investitionen in technologische Weiterentwicklungen ab, verkürzen Innovationszyklen, beschleunigen Zertifizierungsvorgänge und erhöhen die Planungssicherheit durch neuartige Messmethoden.
<G-vec00386-002-s221><enhance.erhöhen><en> They will increase visual appearance of the building and enhance architectural freedom during modernisation.
<G-vec00386-002-s221><enhance.erhöhen><de> Sie verbessern das Erscheinungsbild Ihres Gebäudes und erhöhen die architektonische Freiheit bei der Modernisierung.
<G-vec00386-002-s316><enhance.erweitern><en> Development Some applications can be enhance with templates, plug-ins and other files.
<G-vec00386-002-s316><enhance.erweitern><de> Weiterentwicklung Einige Programme können durch eigene Vorlagen, Plugins und sonstige Dateien erweitert werden.
<G-vec00386-002-s317><enhance.erweitern><en> Some games will integrate an AR portion into their game to enhance the current experience, which is cool and it’s what we are doing.
<G-vec00386-002-s317><enhance.erweitern><de> Einige werden einen AR-Anteil integrieren, der das aktuelle Erlebnis erweitert – das ist cool und auch der Ansatz, den wir verfolgen.
<G-vec00386-002-s318><enhance.erweitern><en> Comparing EVER CLOSER Innovative and perfectly tailored accessories not only enhance the capabilities and functionality of your SWAROVSKI OPTIK spotting scope, they also help to protect it.
<G-vec00386-002-s318><enhance.erweitern><de> Innovatives und perfekt auf SWAROVSKI OPTIK Teleskope abgestimmtes Zubehör erweitert nicht nur die Einsatzmöglichkeiten und die Funktionalität Ihrer Geräte, sondern trägt auch wesentlich zu deren Schutz bei.
<G-vec00386-002-s319><enhance.erweitern><en> Since our first GIS, implemented for a municipality in 1974, we have partnered with authorities at all levels to deliver capabilities that enhance vital government functions – from national mapping and national security to public works and public safety.
<G-vec00386-002-s319><enhance.erweitern><de> Seit der Entwicklung unseres ersten Infrastruktur-GIS im Jahr 1974 haben wir den Umfang und die Funktionen unserer Angebote stark erweitert, sodass heute nahezu alle Bereiche des Betriebs abgedeckt werden können.
<G-vec00386-002-s320><enhance.erweitern><en> This plugin will enhance your xt:Commerce (or folk) shop with the Piwik eCommerce Tracking.
<G-vec00386-002-s320><enhance.erweitern><de> Dieses Plugin erweitert Euren xt:Commerce-Shop um das Piwik eCommerce Tracking.
<G-vec00386-002-s321><enhance.erweitern><en> The internal UFS 2.1 memory has 128GB – but unfortunately we cannot enhance it with a card.
<G-vec00386-002-s321><enhance.erweitern><de> Der interne Speicher UFS 2.1 hat 128 GB – aber kann dank einer Karte nicht erweitert werden.
<G-vec00386-002-s322><enhance.erweitern><en> To deliver on these aims, Acquia is working with school staff to develop a new website that will enhance the user journey, optimise the digital experience on mobile devices and improve the CMS usability for the school.
<G-vec00386-002-s322><enhance.erweitern><de> Zur Realisierung dieser Ziele arbeitet Acquia mit den Institutsmitarbeitern an der Entwicklung einer neuen Website, die die User Journey erweitert, die Digital Experience auf Mobilgeräten optimiert und die CMS-Nutzbarkeit für das Institut verbessert.
<G-vec00386-002-s323><enhance.erweitern><en> From easy classification to embedded labels and permissions, enhance data protection at all times with Azure Information Protection – regardless of where it’s stored or who it’s shared with.
<G-vec00386-002-s323><enhance.erweitern><de> Von der einfachen Klassifizierung bis hin zu integrierten Bezeichnungen und Berechtigungen erweitert Azure Information Protection den Datenschutz zu jeder Zeit – unabhängig davon, wo die Daten gespeichert sind und für wen sie freigegeben werden.
<G-vec00386-002-s324><enhance.erweitern><en> While already feature rich and critical for productivity, Microsoft continues to improve and enhance Word with each new release.
<G-vec00386-002-s324><enhance.erweitern><de> Obwohl Word bereits über zahlreiche Funktionen verfügt und für die Produktivität unentbehrlich geworden ist, wird es mit jeder neuen Version verbessert und erweitert.
<G-vec00386-002-s326><enhance.erweitern><en> The intention is to enhance the theory and practice of mobile learning via the Internet.
<G-vec00386-002-s326><enhance.erweitern><de> Theorie und Praxis des mobilen Lernens sollen mittels des Internet erweitert werden.
<G-vec00386-002-s327><enhance.erweitern><en> Every print shop can enhance its product range by offering inline finishing. With this additional offer, the opportunity is created to set itself apart from its competitors.
<G-vec00386-002-s327><enhance.erweitern><de> Jede Druckerei erweitert durch Inlineveredelung ihr Angebotsspektrum und schafft sich mit diesem zu-sätzlichen Angebot die Möglichkeit, sich von Mit-bewerbern abzuheben.
<G-vec00386-002-s328><enhance.erweitern><en> We constantly enhance, refine, and renew our products so that you can benefit from even better quality every upcoming season.
<G-vec00386-002-s328><enhance.erweitern><de> Unsere Angebote werden ständig erweitert, weiterentwickelt und erneuert, sodass Sie in jeder neuen Saison von noch besserer Qualität profitieren können.
<G-vec00386-002-s329><enhance.erweitern><en> The Korea Civilization and Scenario Pack brings you both the Korea Civilization and the new Scenario: The Samurai Invasion of Korea, to further enhance your Civilization V experience.
<G-vec00386-002-s329><enhance.erweitern><de> Das Denmark Civilization und Scenario Paket enthält sowohl Denmark Civilization als auch das neue Szenarium, 1066: Year of Viking Destiny und erweitert Ihr Civilization V Erlebnis.
<G-vec00386-002-s331><enhance.erweitern><en> The goal is to enhance the knowledge in the programming language and the practical experiences with the programming environment.
<G-vec00386-002-s331><enhance.erweitern><de> Es erweitert die bisher erworbenen Kenntnisse im Umgang mit der Programmiersprache als auch mit der Entwicklungsumgebung von MATLAB.
<G-vec00386-002-s351><enhance.fördern><en> This year’s Focus section hones in on fundamental rights indicators – one of the tools that can be used to enhance the fundamental rights commitments of the EU and its Member States.
<G-vec00386-002-s351><enhance.fördern><de> Als Schwerpunktthema des diesjährigen Jahresberichts werden rechtebasierte Indikatoren untersucht – Instrumente, die dazu beitragen können, Grundrechtsverpflichtungen der EU und der EU-Mitgliedstaaten zu fördern.
<G-vec00386-002-s352><enhance.fördern><en> The foundation’s mission is to enhance the competitiveness of German companies, which it has been pursuing for 66 years now.
<G-vec00386-002-s352><enhance.fördern><de> Seit nunmehr 66 Jahren verfolgt die Stiftung das Ziel, die Wettbewerbsfähigkeit deutscher Unternehmen zu fördern.
<G-vec00386-002-s353><enhance.fördern><en> To further enhance the readability, the second time zone display has incorporated our Swiss micro gas light tubes.
<G-vec00386-002-s353><enhance.fördern><de> Um die Ablesbarkeit zu fördern, ist die Anzeige der zweiten Zeitzone mit unseren gasgefüllten Schweizer Mikroröhrchen ausgestattet.
<G-vec00386-002-s354><enhance.fördern><en> We will continue to enhance and ensure the highest standards of proficiency in determining the market and mortgage lending value of real estate.
<G-vec00386-002-s354><enhance.fördern><de> Wir fördern und sichern weiterhin höchste fachliche Standards in der Markt- und Beleihungswertermittlung von Immobilien.
<G-vec00386-002-s355><enhance.fördern><en> Approximately 15,000 passionate, talented and committed employees from a diversity of backgrounds are driven by Air Products’ higher purpose to create innovative solutions that benefit the environment, enhance sustainability and address the challenges facing customers, communities and the world.
<G-vec00386-002-s355><enhance.fördern><de> Etwa 16.000 kompetente, engagierte und motivierte Mitarbeiter mit vielfältigen Hintergründen sind von Air Products’ übergreifendem Ziel angetrieben, innovative Lösungen zu erschaffen, die der Umwelt dienen, Nachhaltigkeit fördern und sich den Herausforderungen von Kunden, Gemeinschaften und der Welt insgesamt widmen.
<G-vec00386-002-s356><enhance.fördern><en> Aids which enhance the self-confidence and Independency.
<G-vec00386-002-s356><enhance.fördern><de> Hilfsmittel, die das Selbstvertrauen fördern und unabhängig machen.
<G-vec00386-002-s357><enhance.fördern><en> Kunzite is said to enhance a person's capacity for devotion and understanding and to bestow inner peace and joie de vivre on its wearer.
<G-vec00386-002-s357><enhance.fördern><de> Kunzit soll die Hingabe und das Einfühlungsvermögen seiner Trägerin oder seines Trägers fördern und innere Ruhe und Lebensfreude schenken.
<G-vec00386-002-s358><enhance.fördern><en> We will do everything we can to enhance your knowledge, because the only person who can make you healthy and energetic is yourself.
<G-vec00386-002-s358><enhance.fördern><de> Wir wollen alles tun, um Ihr Wissen zu fördern, weil die einzige Person, die Sie vital und gesund machen kann, Sie selbst sind.
<G-vec00386-002-s359><enhance.fördern><en> It aims to raise awareness of existing Living Lab infrastructures, to highlight their potential for market realizations of new products and services, and to highlight appropriate measures that enhance their innovative capacity.
<G-vec00386-002-s359><enhance.fördern><de> Es zielt darauf ab, die bestehenden Living-Lab-Infrastrukturen bekannter zu machen, ihr Potenzial für Marktrealisierungen neuer Produkte und Dienstleistungen hervorzuheben und geeignete Maßnahmen herauszustellen, die deren Innovationskraft fördern.
<G-vec00386-002-s360><enhance.fördern><en> Neither an app or a tool, this website simply provides simple suggestions and exercises to help enhance creativity.
<G-vec00386-002-s360><enhance.fördern><de> Diese Website ist weder eine App noch ein Tool, sondern bietet einfache Vorschläge und Übungen, die helfen, Kreativität zu fördern.
<G-vec00386-002-s361><enhance.fördern><en> Healthy plants: Cats instinctively choose grasses and plants that enhance their vitality and well-being.
<G-vec00386-002-s361><enhance.fördern><de> Gesundheitsfördernde Pflanzen: Hunde wählen in der Natur instinktiv Gräser und Pflanzen aus, die ihr Wohlbefinden fördern.
<G-vec00386-002-s362><enhance.fördern><en> Many “Aha” moments, lots of information and good team spirit make the workshops into unforgettable experiences and enhance the working atmosphere.
<G-vec00386-002-s362><enhance.fördern><de> Viele Aha-Momente, viel Wissenswertes und vermittelter Teamspirit machen die Workshops zu Erlebnissen und fördern das Betriebsklima.
<G-vec00386-002-s363><enhance.fördern><en> For first-class images and promotional materials to enhance your business
<G-vec00386-002-s363><enhance.fördern><de> Für erstklassige Bilder und Werbematerial, um Ihr Unternehmen zu fördern.
<G-vec00386-002-s364><enhance.fördern><en> I continue to create with traditional mediums to enhance my creative evolution.
<G-vec00386-002-s364><enhance.fördern><de> Ich arbeite weiterhin mit traditionellen Medien, um meine kreative Entwicklung zu fördern.
<G-vec00386-002-s365><enhance.fördern><en> From the individual planets up through the morontia training worlds, these seraphim labor to enhance all sincere social contacts and to further the social evolution of universe creatures.
<G-vec00386-002-s365><enhance.fördern><de> Von den einzelnen Planeten bis hinauf zu den morontiellen Erziehungswelten arbeiten diese Seraphim daran, alle aufrichtigen sozialen Kontakte zu vertiefen und die gesellschaftliche Evolution der Universumsgeschöpfe zu fördern.
<G-vec00386-002-s366><enhance.fördern><en> From skills training to large account management to better CRM, these products will enhance your organization’s capabilities to win more customers while maintaining and growing relationships with the customers you already have.
<G-vec00386-002-s366><enhance.fördern><de> Vom Kompetenztraining über das Managen von Großkunden bis hin zu einem besseren CRM fördern diese Produkte die Fähigkeiten Ihrer Organisation, damit Sie mehr Kunden gewinnen und gleichzeitig die Beziehungen zu Ihren Bestandskunden aufrechterhalten und ausbauen können.
<G-vec00386-002-s367><enhance.fördern><en> The rapporteur believes that the CCCTB proposals represent an essential building block in the completion of the internal market and have the potential to enhance growth of the European economy.
<G-vec00386-002-s367><enhance.fördern><de> Der Berichterstatter ist der Ansicht, dass die GKKB-Vorschläge wichtige Bausteine für die Vollendung des Binnenmarktes sind und das Potenzial haben, das Wachstum der europäischen Wirtschaft zu fördern.
<G-vec00386-002-s368><enhance.fördern><en> Serum that incorporates in its formulation ingredients of vegetable origin such as squalene, soy and wheat hydrolysates that together with tripeptides enhance the synthesis of collagen, which also helps to restore the firmness of the skin.
<G-vec00386-002-s368><enhance.fördern><de> Serum, das in seiner Formulation pflanzliche Inhaltsstoffe wie Squalen-, Soja- und Weizenhydrolysate enthält, die zusammen mit Tripeptiden die Synthese von Kollagen fördern, was auch zur Wiederherstellung der Hautfestigkeit beiträgt.
<G-vec00386-002-s369><enhance.fördern><en> Today, psychedelics have emerged from the shadows in a new guise: instead of being used to “tune in, turn on, drop out”, many millenials and Gen Xers are using the drug to enhance their careers.
<G-vec00386-002-s369><enhance.fördern><de> Heutzutage sind Psychedelika in einem neuen Gewand aus dem Schatten wieder aufgetaucht: Anstatt "tune in, turn on, drop out", verwenden viele Leute der neuen Generation diese Droge, um ihre Karriere zu fördern.
<G-vec00386-002-s444><enhance.optimieren><en> This website uses cookies to enhance the user experience and help us to make this website better.
<G-vec00386-002-s444><enhance.optimieren><de> Diese Website verwendet Cookies, um die Benutzererfahrung zu optimieren und uns dabei zu helfen, diese Website zu verbessern.
<G-vec00386-002-s445><enhance.optimieren><en> Carriers are looking for ways to accelerate the delivery of leading-edge technology capabilities to enhance their core systems.
<G-vec00386-002-s445><enhance.optimieren><de> Versicherer sind ständig auf der Suche nach Möglichkeiten, mit der Hilfe von Spitzentechnologien ihre Kernsysteme zu optimieren und Prozesse zu beschleunigen.
<G-vec00386-002-s446><enhance.optimieren><en> Dual passive radiators work together with two full-range speakers to enhance low-end tones, giving your party that extra boost.
<G-vec00386-002-s446><enhance.optimieren><de> Duale Passivradiatoren optimieren tiefe Frequenzen und geben den beiden Breitbandlautsprechern einen ordentlichen Bass-Boost....
<G-vec00386-002-s447><enhance.optimieren><en> Expert users work with the advanced features of Word 2010 to enhance professional documents, create documents ready for publication and collaborate effectively on group editing projects.
<G-vec00386-002-s447><enhance.optimieren><de> Erfahrene Benutzer arbeiten mit den erweiterten Funktionen von Word 2010, um professionelle Dokumente zu optimieren, veröffentlichungsbereite Dokumente zu erstellen und in Gruppenarbeit effektiv an Projekten zusammenzuarbeiten.
<G-vec00386-002-s448><enhance.optimieren><en> “Game,” “Movie,” “Web,” “Text,” and “Mono” presets enhance gamma curve, color temperature, contrast, and brightness to deliver an optimized viewing experience for different screen applications.
<G-vec00386-002-s448><enhance.optimieren><de> Diese Voreinstellungen optimieren jeweils die Gammakurve, die Farbtemperatur, den Kontrast und die Helligkeit, um je nach wiedergegebenem Inhalt das beste Seherlebnis zu bieten.
<G-vec00386-002-s449><enhance.optimieren><en> Use Code Injection to add HTML and scripts that enhance specific parts of your site.
<G-vec00386-002-s449><enhance.optimieren><de> Verwenden Sie benutzerdefinierten Code, um HTML und Skripts hinzuzufügen, die bestimmte Teile Ihrer Website optimieren.
<G-vec00386-002-s450><enhance.optimieren><en> Seamlessly remove unwanted elements from photos, and easily crop, straighten, retouch and enhance images.
<G-vec00386-002-s450><enhance.optimieren><de> Entfernen Sie unerwünschte Elemente nahtlos aus Fotos und beschneiden, retuschieren, optimieren und richten Sie Bilder gerade.
<G-vec00386-002-s451><enhance.optimieren><en> Diffusers are an important component of turbochargers, which enhance engine efficiency and capacity by forcing more air, and proportionately more fuel, into the combustion chamber
<G-vec00386-002-s451><enhance.optimieren><de> Diffusoren stellen wichtige Komponenten von Turboladern dar, welche Wirkungsgrad und Leistung des Motors optimieren, indem mehr Luft und proportional mehr Kraftstoff in den Brennraum geleitet wird.
<G-vec00386-002-s452><enhance.optimieren><en> Structured Snippet Extensions enhance your ads with product and service highlights. You can add an extra line of text with up to 25 characters per word, and they will appear underneath the ad description.
<G-vec00386-002-s452><enhance.optimieren><de> Mit Snippet-Erweiterungen können Sie Ihre Anzeigen optimieren, indem Sie Produkte und Dienstleistungen hervorheben Sie können eine zusätzliche Textzeile mit bis zu 25 Zeichen pro Wort hinzufügen, die unter der Anzeigenbeschreibung eingeblendet wird.
<G-vec00386-002-s453><enhance.optimieren><en> Enhance your practice, clinic or hospital with the Nuclear Medicine 600 Series.
<G-vec00386-002-s453><enhance.optimieren><de> Optimieren Sie Ihre Arztpraxis, Ihre Klinik oder Ihr Krankenhaus mit der Nuclear Medicine 600 Series.
<G-vec00386-002-s454><enhance.optimieren><en> More than 400 employees at 15 locations, in 13 countries, in three divisions work on countless projects - they develop software, advise our customers, draw up concepts, implement systems and enhance processes.
<G-vec00386-002-s454><enhance.optimieren><de> Über 400 Mitarbeiter an 15 Standorten, in 13 Ländern, drei Geschäftsbereichen und unzähligen Projekten entwickeln Software, beraten unsere Kunden, erarbeiten Konzepte, implementieren Systeme und optimieren Abläufe.
<G-vec00386-002-s455><enhance.optimieren><en> As part of our online marketing consultancy service we enhance your digital communication, lay the right technology foundations and provide communications support via social media channels.
<G-vec00386-002-s455><enhance.optimieren><de> In unserer Online-Marketing-Beratung optimieren wir Ihre digitale Kommunikation, schaffen technisch optimale Voraussetzungen und unterstützen Sie bei der Kommunikation über die Social-Media-Kanäle.
<G-vec00386-002-s456><enhance.optimieren><en> We use cookies to track the interests of our users so that we can subsequently enhance their experience on our website.
<G-vec00386-002-s456><enhance.optimieren><de> Wir wenden die Cookies an, um die Interessen unserer Benutzer zu verfolgen, damit wir anschließend ihre Erfahrungen mit unserer Webseite optimieren können.
<G-vec00386-002-s457><enhance.optimieren><en> Avast Antivirus offers premium features and tools that further enhance your product.
<G-vec00386-002-s457><enhance.optimieren><de> Avast Antivirus bietet Premium-Funktionen und -Tools zum weiteren Optimieren des Produkts.
<G-vec00386-002-s458><enhance.optimieren><en> "Maureen's extensive experience in risk management will build upon and enhance the solid foundation of the new risk organization of UBS.
<G-vec00386-002-s458><enhance.optimieren><de> «Dank ihrer umfassenden Erfahrung im Risikomanagement wird Maureen Miskovic die soliden Grundlagen der neuen Risikoorganisation von UBS weiter festigen und optimieren.
<G-vec00386-002-s459><enhance.optimieren><en> The modifications that have been tested in the wind tunnel enhance both the downforce and the drag and thus improve the aerodynamic performance at the race track.
<G-vec00386-002-s459><enhance.optimieren><de> Die im Windkanal ausgetesteten Veränderungen optimieren sowohl Abtrieb als auch den Luftwiderstand und verbessern so die aerodynamische Rennstrecken-Performance.
<G-vec00386-002-s460><enhance.optimieren><en> SKG will also enhance the two businesses through the application of the Group’s best-in-class operating systems and design and innovation capability.
<G-vec00386-002-s460><enhance.optimieren><de> SKG wird beide Unternehmen zudem durch die Einrichtung fortschrittlichster Betriebssysteme sowie Design- und Innovationsfähigkeiten optimieren.
<G-vec00386-002-s461><enhance.optimieren><en> Transparent You have full control over the computational resources that execute your business logic, making it easy to enhance or debug your logic.
<G-vec00386-002-s461><enhance.optimieren><de> Transparent Sie haben die volle Kontrolle über die Datenverarbeitungsressourcen zur Ausführung Ihrer Geschäftslogik, wodurch das Optimieren oder Debuggen Ihrer Logik vereinfacht wird.
<G-vec00386-002-s462><enhance.optimieren><en> Games Games See how our fonts and technology help developers enhance the look, feel and appeal of their games.
<G-vec00386-002-s462><enhance.optimieren><de> Spiele Spiele Spiele Finden Sie heraus, wie Entwickler mit unseren Schriften den Look und Stil ihrer Spiele optimieren.
<G-vec00386-002-s482><enhance.sorgen><en> The memory modules are provided on a PCB with two bonded passive heatsinks (heatspreader), which are supposed to enhance the memory cooling also with higher frequencies and/or higher voltages.
<G-vec00386-002-s482><enhance.sorgen><de> Auf den Speicherbausteinen wurden zwei dünne Kühlkörper (Heat Spreader) aufgeklebt, die auch bei etwas höheren Spannungen und höheren Taktraten für eine geringere Temperatur der Speichermodule sorgen.
<G-vec00386-002-s483><enhance.sorgen><en> A large double bed, a bathroom with corner bath, a large shower and separate toilet to enhance your comfort.
<G-vec00386-002-s483><enhance.sorgen><de> Ein großes Doppelbett, ein Badezimmer mit Eckbadewanne, eine große Dusche und eine separate Toilette sorgen für zusätzlichen Komfort.
<G-vec00386-002-s484><enhance.sorgen><en> The memory ICs are provided on a green 8-layer PCB with two passive heatsink halves (heat spreader), which are supposed to enhance the memory cooling also with higher frequencies and/or higher voltages.
<G-vec00386-002-s484><enhance.sorgen><de> Auf der grünen 8 Layer Platine befinden sich die Speicher ICs, die mit zwei Kühlkörper Hälften (heat spreader) versehen wurden, die auch bei hohen Spannungen und höheren Taktraten für eine geringe Temperatur der Speichermodule sorgen.
<G-vec00386-002-s485><enhance.sorgen><en> To enhance productivity and print quality the press will also feature automatic ink feed plus colour and cut-off controls.
<G-vec00386-002-s485><enhance.sorgen><de> Die vollautomatische Farbversorgung sowie Farb- und Schnittregisterregelungen sorgen für eine hohe Produktivität und Druckqualität.
<G-vec00386-002-s486><enhance.sorgen><en> Fiery servers can also enhance the small, fine text and graphics often used on business cards.
<G-vec00386-002-s486><enhance.sorgen><de> Fiery Server sorgen auch für die optimale Ausgabe von Bild-, Text- und Grafikelementen geringer Qualität.
<G-vec00386-002-s487><enhance.sorgen><en> High ceilings with exposed wooden beams enhance the sense of space and comfort.
<G-vec00386-002-s487><enhance.sorgen><de> Die hohen Decken mit Holzbalken sorgen für ein großzügiges Raumgefühl.
<G-vec00386-002-s488><enhance.sorgen><en> Operators of Crown SH/SHR Series find them easy to use – even in tight spaces – since the innovative controls and compact design enhance maneuverability.
<G-vec00386-002-s488><enhance.sorgen><de> Die Bediener der Hochhubwagen der SH/SHR Serie schätzen deren Flexibilität: Die innovativen Bedienelemente und die kompakte Bauform sorgen selbst bei beschränkten Platzverhältnissen für eine hervorragende Manövrierbarkeit.
<G-vec00386-002-s489><enhance.sorgen><en> Protect your floors and enhance your image with Tennant floor coatings and Finished Concrete Systems
<G-vec00386-002-s489><enhance.sorgen><de> Schützen Sie Ihre Böden und sorgen Sie für eine hygienische Umgebung mit den chemikalienresistenten Beschichtungen von Tennant.
<G-vec00386-002-s490><enhance.sorgen><en> Our different teams work together to enhance the shopping experience, maximise sales and strengthen our brand:
<G-vec00386-002-s490><enhance.sorgen><de> Unsere verschiedenen Teams sorgen gemeinsam für ein optimales Einkaufserlebnis, maximale Umsätze und die Stärkung unserer Marke.
<G-vec00386-002-s491><enhance.sorgen><en> Form release agents facilitate the easy removal of the concrete from its formwork; at the same time, they also enhance the surface of precast concrete elements and cast in place concrete.
<G-vec00386-002-s491><enhance.sorgen><de> Gleichzeitig sorgen sie für eine verbesserte Betonoberfläche von Fertigteilen und vor Ort eingebautem Beton.
<G-vec00386-002-s492><enhance.sorgen><en> Learn how you can enhance safety through security when you bring industrial risk management into your connected enterprise strategy in our whitepaper.
<G-vec00386-002-s492><enhance.sorgen><de> Erfahren Sie in unserem Whitepaper, wie Sie durch Sicherheitsfunktionen für mehr Schutz sorgen können, indem Sie industrielles Risikomanagement für Ihr Connected Enterprise einführen.
<G-vec00386-002-s493><enhance.sorgen><en> Illustrations, practical examples and exercises enhance the reader's experience.
<G-vec00386-002-s493><enhance.sorgen><de> Zahlreiche Illustrationen, Beispiele und Übungsaufgaben mit nachvollziehbaren Musterlösungen sorgen dafür für bestmögliche Verständlichkeit.
<G-vec00386-002-s494><enhance.sorgen><en> Enhance your living room by putting an elegant armchair beside this console table.
<G-vec00386-002-s494><enhance.sorgen><de> Mit einem eleganten Sessel neben der Konsole sorgen Sie für eine strahlende Note im Wohnzimmer.
<G-vec00386-002-s495><enhance.sorgen><en> To enhance the realism even further, the day-night cycle also brings new challenges for off-road drivers. Newsletter
<G-vec00386-002-s495><enhance.sorgen><de> Um für noch mehr Realismus zu sorgen, haben wir nun einen Tag-Nacht-Zyklus, der seine eigenen neuen Herausforderungen bei Fahrten im Gelände mit sich bringt.
<G-vec00386-002-s496><enhance.sorgen><en> Plexiglass coffee tables Plexiglass coffee tables: These beautiful plexiglass tables enhance the natural light and offer excellent transparency, perfect for contemporary settings or to add a modern touch to more traditional environments.
<G-vec00386-002-s496><enhance.sorgen><de> Tischchen aus Plexiglass Plexiglas-Couchtische Plexiglas-Couchtische: Diese schönen Plexiglas-Couchtische sorgen für viel natürliches Licht und bieten eine hervorragende Transparenz.
<G-vec00386-002-s497><enhance.sorgen><en> WestinWORKOUT® Recharge and enhance your overall health at the WestinWORKOUT® Fitness Studio, where state-of-the-art fitness equipment and thoughtful amenities—from complimentary water to a steam room and sauna—leave you energized and invigorated.
<G-vec00386-002-s497><enhance.sorgen><de> Tanken Sie neue Energie und tun Sie Ihrer Gesundheit etwas Gutes im Fitnessstudio WestinWORKOUT®, in dem hochmoderne Fitnessgeräte und durchdachte Annehmlichkeiten – von kostenfreiem Wasser über ein Dampfbad bis hin zur Sauna – dafür sorgen, dass Sie sich erholt und frisch fühlen werden.
<G-vec00386-002-s517><enhance.steigern><en> Enhance the productivity of your loader and protect your investment in buckets with our Ground Engaging Tools (GET).
<G-vec00386-002-s517><enhance.steigern><de> Steigern Sie die Produktivität Ihres Laders und schützen Sie die Schaufel mit unseren Schneidwerkzeugen.
<G-vec00386-002-s518><enhance.steigern><en> - Brainwave frequencies: Enhance your experience and achieve faster results.
<G-vec00386-002-s518><enhance.steigern><de> - Gehirnwellenfrequenzen: Steigern Sie Ihr Erlebnis und erzielen Sie schnellere Ergebnisse.
<G-vec00386-002-s519><enhance.steigern><en> Enhance your business with SweTrack's corporate solutions.
<G-vec00386-002-s519><enhance.steigern><de> Steigern Sie Ihr Geschäft mit den Unternehmenslösungen von SweTrack.
<G-vec00386-002-s520><enhance.steigern><en> Enhance the efficiency of your machines through retrofits and modernizations.
<G-vec00386-002-s520><enhance.steigern><de> Steigern Sie die Effizienz Ihrer Maschinen: durch Umbau oder Modernisierung.
<G-vec00386-002-s521><enhance.steigern><en> Enhance your digital presence and make it easier to be found with a professional, responsive, mobile-friendly website from GlasWeld.
<G-vec00386-002-s521><enhance.steigern><de> Steigern Sie Ihre digitale Präsenz und machen Sie es einfacher, sie mit einer professionellen, reaktionsschnellen und mobilfreundlichen Website von GlasWeld zu finden.
<G-vec00386-002-s522><enhance.steigern><en> Enhance your well-being with our indoor pool, sauna with ice fountain, solarium and fitness area.
<G-vec00386-002-s522><enhance.steigern><de> Steigern Sie Ihr Wohlgefühl mit dem Haus-Pool, Sauna mit Eisbrunnen, Solarium und Fitness-Raum, bei verschiedenen Massagen.
<G-vec00386-002-s523><enhance.steigern><en> Enhance productivity and free up valuable space with the ARMSLIMDUO Dual-Monitor Arm.
<G-vec00386-002-s523><enhance.steigern><de> Steigern Sie die Produktivität und setzen Sie wertvollen Platz frei mit diesem Dual Monitor-Arm ARMSLIMDUO.
<G-vec00386-002-s524><enhance.steigern><en> Enhance the mobility of your Precision 2-in-1 with Dell-recommended accessories that can help you stay powered up, connected and protected on the go.
<G-vec00386-002-s524><enhance.steigern><de> Steigern Sie die Mobilität Ihres Dell Precision 2-in-1 Systems mit von Dell empfohlenem Zubehör, mit dem Sie auch unterwegs über Stromversorgung, Konnektivität und Schutz verfügen.
<G-vec00386-002-s525><enhance.steigern><en> Enhance daily performance and productivity with the Dell Premier Wireless Mouse - WM527, which features an elegant design that will fit into virtually any workspace.
<G-vec00386-002-s525><enhance.steigern><de> Steigern Sie Leistung und Produktivität mit der Dell Premier Wireless-Maus WM527, die über ein elegantes Design verfügt, das in jede Arbeitsumgebung passt.
<G-vec00386-002-s526><enhance.steigern><en> Modify the settings and properties of your web browser, configure the various options of Windows Media Player and enhance your systems performance by changing the logon options.
<G-vec00386-002-s526><enhance.steigern><de> Verändern Sie die Einstellungen und Eigenschaften Ihres Webbrowsers, konfigurieren Sie den Windows Media Player neu und steigern Sie die Leistungsfähigkeit Ihres Systems durch angepasste Anmeldeoptionen.
<G-vec00386-002-s527><enhance.steigern><en> Encourage user adoption, enforce firm governance policies and enhance productivity with a dynamic, intuitive interface that’s consistent across all access points.
<G-vec00386-002-s527><enhance.steigern><de> Erhöhen Sie die Benutzerakzeptanz, setzen Sie Governance-Richtlinien durch und steigern Sie Ihre Produktivität mit einer dynamischen, intuitiven und systemübergreifenden einheitlichen Benutzeroberfläche.
<G-vec00386-002-s528><enhance.steigern><en> Description: Discover the magic and secrets of wellness, its inner and outer beauty, and enhance your vitality, physical, mental and well-being in the luxurious Esplanade Spa & Golf Resort with relaxation in nature.
<G-vec00386-002-s528><enhance.steigern><de> Unterschrift: Entdecken Sie im luxuriösen Esplanade Spa & Golf Resort die Magie und Geheimnisse des Wohlbefindens, seine innere und äußere Schönheit und steigern Sie Ihre Vitalität, Körper, Geist und Wohlbefinden mit Entspannung in der Natur.
<G-vec00386-002-s529><enhance.steigern><en> Enhance your productivity with Goodyear tires.
<G-vec00386-002-s529><enhance.steigern><de> Steigern Sie mit den Reifen von Goodyear Ihre Produktivität.
<G-vec00386-002-s530><enhance.steigern><en> Improving student outcomes Improved productivity. Enhance the productivity of public-facing staff with call handling and routing that ensures better staff and student interaction.
<G-vec00386-002-s530><enhance.steigern><de> Höhere Produktivität: Steigern Sie die Produktivität Ihrer Kundenbetreuer durch Anrufverwaltung und -weiterleitung, die eine bessere Interaktion zwischen Mitarbeitern, Studenten und Interessenten sicherstellt.
<G-vec00386-002-s531><enhance.steigern><en> Make your HP Structured Light Scanner Pro S3 more robust and enhance its quality by attaching a second HP 3D HD Camera Pro to mitigate errors and produce higher-precision scans.
<G-vec00386-002-s531><enhance.steigern><de> Machen Sie Ihren HP Streifenlicht-Scanner Pro S3 robuster und steigern Sie die Qualität, indem Sie eine zweite HP 3D-HD-Kamera hinzufügen, um Fehler zu minimieren und Scans mit höherer Präzision zu erhalten.
<G-vec00386-002-s532><enhance.steigern><en> Enhance the quality of your software packages, effortlessly meet industry standards, and create packages in record time with Smart Package Studio.
<G-vec00386-002-s532><enhance.steigern><de> Steigern Sie die Qualität Ihrer Softwarepakete, erfüllen Sie mühelos Paketierungstandards und erstellen Sie mit Smart Package Studio Softwarepakete in Rekordzeit.
<G-vec00386-002-s533><enhance.steigern><en> Enhance the speed and efficiency of call handling and dispatching.
<G-vec00386-002-s533><enhance.steigern><de> Steigern Sie die Geschwindigkeit und Effizienz der Anruf-Bearbeitung und Ressourcen-Disponierung.
<G-vec00386-002-s923><enhance.stärken><en> The project is expected to safeguard and enhance the leading competitive position of an EU knowledge-based, R&D-driven enterprise Comments
<G-vec00386-002-s923><enhance.stärken><de> Das Projekt dürfte dazu beitragen, die führende Wettbewerbsposition eines wissensbasierten, auf Forschung und Entwicklung konzentrierten Unternehmens der EU zu wahren und zu stärken.
<G-vec00386-002-s924><enhance.stärken><en> Aeronautics Image Galleries The primary objective of DLR aerospace research activities is to enhance the competitiveness of Germany and Europe's aerospace and air transport industries and to achieve governmental and societal objectives.
<G-vec00386-002-s924><enhance.stärken><de> Vorrangiges Ziel der DLR-Luftfahrtforschung ist es, die Wettbewerbsfähigkeit der nationalen und der europäischen Luftfahrtindustrie und Luftverkehrswirtschaft zu stärken und den Anforderungen von Politik und Gesellschaft nachzukommen.
<G-vec00386-002-s925><enhance.stärken><en> It aims to promote innovations, improve the security of European payment services and enhance consumer protection.
<G-vec00386-002-s925><enhance.stärken><de> Sie verfolgt die Ziele Innovationen zu fördern, die Sicherheit europäischer Zahlungsdienste zu verbessern und den Verbraucherschutz bei Zahlungen zu stärken.
<G-vec00386-002-s926><enhance.stärken><en> This seminar focused on Target 2 of the Strategy, to maintain and enhance ecosystems and their services by establishing green infrastructure and restoring degraded ecosystems.
<G-vec00386-002-s926><enhance.stärken><de> In diesem Seminar wurde der Schwerpunkt auf das zweite Ziel der Strategie gelegt, Ökosysteme und ihre Leistungen durch Grüne Infrastruktur zu erhalten und zu stärken und zerstörte Ökosysteme wiederherzustellen.
<G-vec00386-002-s927><enhance.stärken><en> The rapporteur believes that the CCCTB proposals represent an essential building block in the completion of the internal market and have the potential to enhance growth of the European economy.
<G-vec00386-002-s927><enhance.stärken><de> Der Berichterstatter ist der Auffassung, dass die GKKB-Vorschläge einen wesentlichen Baustein für die Vollendung des Binnenmarktes darstellen und in der Lage sind, das Wachstum der europäischen Wirtschaft zu stärken.
<G-vec00386-002-s928><enhance.stärken><en> To further enhance the cultural appeal of Dortmund within the region and beyond, the foundation supports the renowned local Concert Hall in Dortmund and, in this way, helps to ensure that some outstanding musical events of the highest international standard are staged there.
<G-vec00386-002-s928><enhance.stärken><de> Um die kulturelle Attraktivität von Dortmund für die Region und darüber hinaus zu stärken, engagiert sich die Wilo-Foundation für das ansässige renommierte Konzerthaus Dortmund und ermöglicht herausragende Musikereignisse auf höchstem internationalem Niveau.
<G-vec00386-002-s929><enhance.stärken><en> The Lernort Stadion (Learning in Stadiums) project takes advantage of young people’s fascination with all things soccer in order to spark their enthusiasm for political education, as well as enhance their social skills.
<G-vec00386-002-s929><enhance.stärken><de> Das Projekt "Lernort Stadion" nutzt diese Faszination rund um den Fußball, um Jugendliche für politische Bildung zu begeistern und ihre sozialen Kompetenzen zu stärken.
<G-vec00386-002-s930><enhance.stärken><en> It aims to enhance the technical and methodological capacity of state actors.
<G-vec00386-002-s930><enhance.stärken><de> Ziel ist es, die Fach- und Methodenkompetenzen der staatlichen Akteure zu stärken.
<G-vec00386-002-s931><enhance.stärken><en> It is possible to derive the recommendation from this study, conducted by the ZEW and the IÖW, that companies can enhance their competitiveness by interlinking environmental and innovation management.
<G-vec00386-002-s931><enhance.stärken><de> Aus der Studie des ZEW und des IÖW lässt sich für Unternehmen die Handlungsempfehlung ableiten, durch Verzahnung von Umwelt- und Innovationsmanagement ihre Wettbewerbsfähigkeit zu stärken.
<G-vec00386-002-s932><enhance.stärken><en> The Habsburgs used the marriages as a strategic alliance tool to expand their influence and enhance their power.
<G-vec00386-002-s932><enhance.stärken><de> Die Habsburger nutzten die Ehen als strategisches Allianzwerkzeug, um ihren Einfluss auszubauen und ihre Macht zu stärken.
<G-vec00386-002-s933><enhance.stärken><en> You bring local stakeholders and NGOs together, one aim being to enhance the role of women in politics in Albania.
<G-vec00386-002-s933><enhance.stärken><de> Denn Sie bringen lokale Akteure und Nichtregierungs-organisationen an einen Tisch - unter anderem um die Rolle von Frauen in der albanischen Politik zu stärken.
<G-vec00386-002-s934><enhance.stärken><en> The strategic objective of PERN Capital Group is to enhance its position in the area of crude oil storage and transport and further development of fuels-related operations, including but not limited to expanding storage capacities and pipeline networks.
<G-vec00386-002-s934><enhance.stärken><de> Strategisches Ziel der PERN-Gruppe ist es, ihre Position im Bereich der Lagerung und des Transports von Erdöl zu stärken und sich im Bereich der Brennstoffe unter anderem durch den Ausbau ihrer Speicherkapazitäten und ihres Pipelinenetzes weiterzuentwickeln.
<G-vec00386-002-s935><enhance.stärken><en> The company' s continued investment in lifecycle management programs, including enhancing the Betaferon® application system as well as ongoing long term follow-up programs will further enhance the product.
<G-vec00386-002-s935><enhance.stärken><de> Kontinuierliche Investitionen in Life-Cycle-Management-Programme, unter anderem zur Weiterentwicklung des Betaferon-Applikationssystems und zur Weiterführung von Langzeit-Nachbeobachtungen, werden dazu beitragen, das Betaferon®-Geschäft weiter zu stärken.
<G-vec00386-002-s936><enhance.stärken><en> Text proposed by the Commission Amendment (19) To enhance the trust of rightholders, users and other collecting societies in the management services provided by collecting societies, each collecting society should be required to set up specific transparency measures.
<G-vec00386-002-s936><enhance.stärken><de> (34) Um das Vertrauen von Rechtsinhabern, Nutzern und anderen Organisationen für die kollektive Rechtewahrnehmung in die von Organisationen für die kollektive Rechtewahrnehmung erbrachte kollektive Rechtewahrnehmung zu stärken, sollte von jeder Organisation für die kollektive Rechtewahrnehmung verlangt werden, dass sie besondere Anforderungen an die Transparenz erfüllt.
<G-vec00386-002-s937><enhance.stärken><en> Find fitness products Leisure socks, food supplements or massage products? elSira - The health portal will help your Well-being and physical fitness to effectively improve and enhance your health.
<G-vec00386-002-s937><enhance.stärken><de> Fitnessprodukte, Freizeitstrümpfe, Nahrungsergänzungsmittel oder Massageprodukte - auch im Freizeitbereich hilft Ihnen unsere Produktauswahl dabei, Ihr Wohlbefinden und Ihre körperliche Fitness nachhaltig zu verbessern und Ihre Gesundheit zu stärken.
<G-vec00386-002-s938><enhance.stärken><en> We have joined forces with more than 60 local Dutch apparel companies, government, NGO’s, trade and labor unions to improve and enhance the sustainability of the international garment and textile supply chain.
<G-vec00386-002-s938><enhance.stärken><de> Zusammen mit mehr als 60 niederländischen Modemarken, der Regierung, NGO´s, Branchenorganisationen und Gewerkschaften, bündeln sie ihre Kräfte, um die Nachhaltigkeit in der internationalen Kleidungs- und Textilproduktionskette zu verbessern und zu stärken.
<G-vec00386-002-s939><enhance.stärken><en> The move is part of the Commission’s push to enhance trust in cloud computing services and unlock their potential for boosting economic productivity in Europe and is one of the key actions under the Commission's Cloud Computing Communication, which was adopted last year (IP/12/1025, MEMO/12/713).
<G-vec00386-002-s939><enhance.stärken><de> Die Einrichtung der Gruppe ist Teil der Bemühungen der Kommission, das Vertrauen in Cloud-Computing-Dienste zu stärken und ihr Potenzial zur Dynamisierung der Wirtschaftsproduktivität in Europa freizusetzen – eine der Schlüsselaktionen, die die Kommission in ihrer Mitteilung zum Cloud-Computing angekündigt hatte (IP/12/1025,MEMO/12/713).
<G-vec00386-002-s940><enhance.stärken><en> Get your phone to protect and enhance its life away from the socket.
<G-vec00386-002-s940><enhance.stärken><de> Holen Sie sich Ihr Telefon zu schützen und sein Leben zu stärken weg von der Steckdose.
<G-vec00386-002-s629><enhance.unterstreichen><en> The resulting earrings for women are at the ready to help enhance and elevate any woman's look with classic subtlety.
<G-vec00386-002-s629><enhance.unterstreichen><de> Die entstandenen Ohrringe unterstreichen den Look jeder Frau mit klassischer Finesse.
<G-vec00386-002-s630><enhance.unterstreichen><en> Due to their extremely slim design, the discreet batten luminaires enhance the building’s architecture and are particularly impressive in the art galleries, thanks to their unobtrusive design.
<G-vec00386-002-s630><enhance.unterstreichen><de> Die dezenten Lichtleisten unterstreichen dank ihrer extrem schlanken Bauform die Architektur des Hauses und wirken in den Galerien mit ihrem zurückhaltenden Design.
<G-vec00386-002-s631><enhance.unterstreichen><en> Made of the finest natural-synthetic hair blend as well as pure synthetic hair, the set offers a fantastic selection of six high-quality brushes to apply liquid and powder formulas like a pro and enhance your natural beauty.
<G-vec00386-002-s631><enhance.unterstreichen><de> Ideal für die Verwendung mit Puder-, Flüssig- und Creme-Texturen geeignet, bietet das Set eine professionelle Auswahl von sechs Gesichtspinseln aus purem Synthetikhaar sowie einem luxuriösen Echthaar-Synthetik-Mix, welche die individuelle Schönheit jedes Gesichtes unterstreichen.
<G-vec00386-002-s632><enhance.unterstreichen><en> Garments that enhance femininity to be perfect always, in every situation.
<G-vec00386-002-s632><enhance.unterstreichen><de> Unterstreichen der Weiblichkeit für eine stets perfekte Figur, in jeder Situation.
<G-vec00386-002-s633><enhance.unterstreichen><en> At the same time, elegant lever handles from the company’s Premium and Pure door furniture ranges discreetly enhance the overall appearance of the school.
<G-vec00386-002-s633><enhance.unterstreichen><de> Gleichzeitig unterstreichen elegante Türdrücker der Beschlagserien Premium und Pure dezent das Gesamterscheinungsbild der Schule.
<G-vec00386-002-s634><enhance.unterstreichen><en> At the time of the Roman Empire, fragrances and spices were used to enhance dining pleasure.
<G-vec00386-002-s634><enhance.unterstreichen><de> Im römischen Reich wurden Gewürze und Kräuter benutzt, um den Geschmack der Speisen zu unterstreichen.
<G-vec00386-002-s635><enhance.unterstreichen><en> Based on the Azure, the Azure T offers a range of discreet exterior cues that further enhance its powerful stance and hint at its increased performance potential.
<G-vec00386-002-s635><enhance.unterstreichen><de> Auf dem sportlichen Arnage T basierend, bietet der Final Series eine Fülle von diskreten Designelementen, die seinen kraftvollen Auftritt noch unterstreichen.
<G-vec00386-002-s636><enhance.unterstreichen><en> Muscular wheel arches with a sporty, short rear overhang, greater ground clearance and alloy wheels enhance the CR-V’s bold stance and attitude.
<G-vec00386-002-s636><enhance.unterstreichen><de> Muskulöse Radläufe mit einem sportlichen, kurzen Hecküberhang, mehr Bodenfreiheit und Leichtmetallräder unterstreichen die selbstbewusste Haltung und Persönlichkeit des CR-V.
<G-vec00386-002-s637><enhance.unterstreichen><en> Its high-quality, old-fashioned upholstery is perfectly maintained by upholstery nails that also enhance the beauty of this seat, with a solid wood frame.
<G-vec00386-002-s637><enhance.unterstreichen><de> Seine hochwertige, altmodische Polsterung wird durch Polsternägel perfekt gepflegt, die durch einen Massivholzrahmen auch die Schönheit dieses Sitzes unterstreichen.
<G-vec00386-002-s638><enhance.unterstreichen><en> accessories A selection of dedicated accessories to enhance your coffee experience.
<G-vec00386-002-s638><enhance.unterstreichen><de> Accessories Eine Auswahl speziell entwickelter Accessoires, um Ihr Kaffee-Erlebnis zu unterstreichen.
<G-vec00386-002-s639><enhance.unterstreichen><en> A stone-shaped handle, made entirely of DuPont™ Corian®, in order to enhance the tactile dimension.
<G-vec00386-002-s639><enhance.unterstreichen><de> Ein Hebelmischer in Form eines Steines, ausschließlich bestehend aus DuPont™ Corian®, um die taktile Dimension zu unterstreichen.
<G-vec00386-002-s640><enhance.unterstreichen><en> This shirt offers not only a large print design on the front side but also fabric insertions as striking embellishments and rhinestones and sequins in order to further enhance the look.
<G-vec00386-002-s640><enhance.unterstreichen><de> Dieses Shirt bietet nicht nur ein sehr großes gesticktes Muster auf der Vorderseite, sondern auch klare Strasssteine als auffällige Verzierung, um den Look noch zu unterstreichen.
<G-vec00386-002-s641><enhance.unterstreichen><en> This shirt offers not only large print designs on both sides but also flock details as striking embellishments and black embroidering along the shoulders in order to further enhance the look.
<G-vec00386-002-s641><enhance.unterstreichen><de> Dieses Shirt bietet nicht nur große Print Designs auf beiden Seiten, sondern auch Flockdetails als auffällige Verzierung und schwarze Stickereien auf den Schultern um den Look noch zu unterstreichen.
<G-vec00386-002-s642><enhance.unterstreichen><en> Enhance this further with a visit to our hairdresser.
<G-vec00386-002-s642><enhance.unterstreichen><de> Unterstreichen Sie Ihre Attraktivität mit einem Besuch beim Friseur.
<G-vec00386-002-s643><enhance.unterstreichen><en> The bathrobe, slippers, and Bulgari amenities provided enhance the sophisticated and elegant yet modern and casual style of La Sommità.
<G-vec00386-002-s643><enhance.unterstreichen><de> Der Bademantel, die Hausschuhe und die Pflegeprodukte von Bulgari unterstreichen den eleganten, modernen und ungezwungenen Stil von La Sommità.
<G-vec00386-002-s644><enhance.unterstreichen><en> To enhance the flavour of the cheeses, these are best accompanied by woodland or pinewood honey.
<G-vec00386-002-s644><enhance.unterstreichen><de> Um den Geschmack des Käses zu unterstreichen, sollte man ihn mit Wald- oder Pinienhonig genießen.
<G-vec00386-002-s645><enhance.unterstreichen><en> Team with natural wood furniture to enhance the rustic feel, or deep stained leather for a sophisticated feel.
<G-vec00386-002-s645><enhance.unterstreichen><de> Kombinieren Sie Möbel aus Naturholz, um die rustikale Atmosphäre zu unterstreichen, oder kreieren Sie einen eleganten Look mit dunklem Leder.
<G-vec00386-002-s646><enhance.unterstreichen><en> Diamond earrings subtly enhance an outfit, and while being discreet, they do stand out and will always give you a glamorous and elegant touch.
<G-vec00386-002-s646><enhance.unterstreichen><de> Diamantohrringe unterstreichen jedes Outfit auf subtile Art und Weise und obwohl sie diskret sind, heben sie sich doch ab und verleihen ihrer Trägerin immer einen glamourösen und eleganten Touch.
<G-vec00386-002-s647><enhance.unterstreichen><en> The essential geometric patterns inspired by the Thirties and the plastic volumes of the finest porcelain enhance the purity of the classic-contemporary style of a w.c. pan for close coupled cistern that fits harmoniously in any context.
<G-vec00386-002-s647><enhance.unterstreichen><de> Die von den 30er Jahren inspirierten Grundformen und die plastischen Volumen aus feinstem Porzellan unterstreichen die Reinheit des klassisch-zeitgemäßen Stils einer Toilette mit Blockspülkasten, die sich harmonisch in jeden Kontext einfügt.
<G-vec00386-002-s724><enhance.verbessern><en> For additional breathability and an especially smooth ride this crew sock features Air Channel Cushioning which uses an articulated foot bed to enhance airflow and padding.
<G-vec00386-002-s724><enhance.verbessern><de> Air Channel Cushioning nutzt eine vorgeformte Fußsohle für verbesserte Luftzirkulation und Polsterung, was für mehr Atmungsaktivität und einen geschmeidigen Lauf sorgt.
<G-vec00386-002-s725><enhance.verbessern><en> Cuts blinding glare while filtering blue light to enhance visual acuity and improve depth perception.
<G-vec00386-002-s725><enhance.verbessern><de> Reduziert blendende Reflexionen und filtert gleichzeitig Blaulicht für verbesserte Sehschärfe und Tiefenwahrnehmung.
<G-vec00386-002-s726><enhance.verbessern><en> Enhance Communication Students come together, stay focused and communicate to win.
<G-vec00386-002-s726><enhance.verbessern><de> Verbesserte Kommunikation Die Schüler bringen sich ein, konzentrieren sich und kommunizieren, um zu gewinnen.
<G-vec00386-002-s727><enhance.verbessern><en> Regularly and extensively stretched muscles are not only a factor for added mobility but they also enhance regenerative capacity and create a more efficient muscle metabolism.
<G-vec00386-002-s727><enhance.verbessern><de> Denn regelmäßig und ausgiebig gedehnte Muskeln sind nicht nur ein Faktor für mehr Beweglichkeit, sondern auch verbesserte Regenerationsfähigkeit und effizienteren Muskelmetabolismus.
<G-vec00386-002-s728><enhance.verbessern><en> Enhance integrated collaborative care with a web-based reporting platform for diagnostic reading.
<G-vec00386-002-s728><enhance.verbessern><de> Verbesserte integrierte gemeinschaftliche Patientenversorgung, durch eine webbasierte Plattform für diagnostische Befundung.
<G-vec00386-002-s729><enhance.verbessern><en> The Hyperlight shorts feature vented open mesh inserts across the thighs to enhance airflow.
<G-vec00386-002-s729><enhance.verbessern><de> Mesh-Einsätze, die quer über die Oberschenkel verlaufen, sorgen bei der Hyperlight Shorts für verbesserte Luftzirkulation.
<G-vec00386-002-s730><enhance.verbessern><en> Perfectly weighted for intermediates, this version of the Strike 100 retains the Hybrid Frame Construction (consisting of square and elliptical beam shapes) while also thickening key locations of the beam to enhance power, stability and precision.
<G-vec00386-002-s730><enhance.verbessern><de> Mit seiner Hybrid Frame Construction (bestehend aus quadratischen und elliptischen Strahlformen) und den verstärkten Schlüsselstellen am Rahmen für verbesserte Kraft, Stabilität und Präzision, ist die neue Version des Strike 100 perfekt auf ein fortgeschrittenes Spielerniveau zugeschnitten.
<G-vec00386-002-s731><enhance.verbessern><en> Enhance document security: Utilise Microsoft Active Directory or Microsoft Azure Rights Management Services to lock down confidential documents without passwords and apply customised protection for each recipient.
<G-vec00386-002-s731><enhance.verbessern><de> Verbesserte Dokumentensicherheit: Mit den Active-Directory- oder Azure-Rechteverwaltungsdiensten von Microsoft kontrollieren Sie ohne Kennwörter den Zugriff auf vertrauliche Unterlagen und können den Dokumentenschutz empfängerspezifisch handhaben.
<G-vec00386-002-s732><enhance.verbessern><en> Combining pull and push measures is necessary to stimulate the modal shift needed, but making the users pay the full cost of externalities will also enhance the possibilities to finance infrastructure.
<G-vec00386-002-s732><enhance.verbessern><de> Die Kombination von Push und Pull-Maßnahmen ist zur Stimulierung eines Wechsels der Verkehrsmodi unumgänglich, allerdings sorgt die Übernahme der externen Kosten durch die NutzerInnen für verbesserte Möglichkeiten zur Finanzierung von Infrastruktur.
<G-vec00386-002-s733><enhance.verbessern><en> The efforts aim to further enhance the aerodynamics and to develop new, lighter-weight and more temperature-resistant materials.
<G-vec00386-002-s733><enhance.verbessern><de> Es geht unter anderem um eine weiter verbesserte Aerodynamik sowie die Entwicklung neuer, leichterer und temperaturbeständigerer Werkstoffe.
<G-vec00386-002-s734><enhance.verbessern><en> Additionally, new administration features, tasks, notifications and self-service possibilities further enhance our clients experience.
<G-vec00386-002-s734><enhance.verbessern><de> Zudem stehen unseren Kunden neue, verbesserte Administrationsfunktionen, Tasks, Benachrichtigungen und Selbstbedienungsmöglichkeiten zur Verfügung.
<G-vec00386-002-s735><enhance.verbessern><en> For reasons that include, without limitation, system security, stability, and multiplayer interoperability, Steam may need to automatically update, pre-load, create new versions of or otherwise enhance the Content and Services and accordingly, the system requirements to use the Content and Services may change over time.
<G-vec00386-002-s735><enhance.verbessern><de> Steam nimmt aus verschiedenen Gründen, d. h. insbesondere aus Gründen der Sicherheit und Stabilität des Systems und der Mehrspieler-Interoperabilität hinsichtlich der vertragsgegenständlichen Inhalte und Leistungen gegebenenfalls automatische Updates und Pre-Loads vor und entwickelt neue Versionen oder anderweitig verbesserte Angebote der vertragsgegenständlichen Inhalte und Leistungen, sodass sich die Systemvoraussetzungen für die Nutzung der vertragsgegenständlichen Inhalte und Leistungen gegebenenfalls mit der Zeit verändern.
<G-vec00386-002-s736><enhance.verbessern><en> We use cookies on our website to support technical features that enhance your user experience.
<G-vec00386-002-s736><enhance.verbessern><de> Wir verwenden Cookies als technische Unterstützung für eine verbesserte Benutzererfahrung.
<G-vec00386-002-s737><enhance.verbessern><en> Greatly enhance scalability and performance of your retail POS system.
<G-vec00386-002-s737><enhance.verbessern><de> Deutlich verbesserte Skalierbarkeit und Leistungsfähigkeit Ihres Kassensystems.
<G-vec00386-002-s738><enhance.verbessern><en> Our mission is to eliminate Alzheimer's disease through the advancement of research; to provide and enhance care and support for all affected; and to reduce the risk of dementia through the promotion of brain health.
<G-vec00386-002-s738><enhance.verbessern><de> Das erklärte Ziel der Alzheimer's Association ist, die Alzheimer-Krankheit durch Fortschritte in der Forschung und durch verbesserte Pflegeangebote für Betroffene zu beseitigen und das Demenz-Risiko durch Förderung eines gesunden Gehirns zu mindern.
<G-vec00386-002-s758><enhance.verschönern><en> See some of the infinite ways you can use glass to enhance any space.
<G-vec00386-002-s758><enhance.verschönern><de> Schauen Sie sich einige der unendlichen Möglichkeiten an, wie man Glas nutzen kann, um jeden Raum zu verschönern.
<G-vec00386-002-s759><enhance.verschönern><en> Once you have made your reservation you have 4 exclusive packages to enhance your stay ..
<G-vec00386-002-s759><enhance.verschönern><de> Sobald Sie Ihre Reservierung gemacht haben, können Sie 2 exklusive Pakete wählen, um Ihren Aufenthalt zu verschönern..
<G-vec00386-002-s760><enhance.verschönern><en> Enhance your embroidery experience and make it easier than ever with the Embroidery Design Editing feature.
<G-vec00386-002-s760><enhance.verschönern><de> Einfacher denn je können Sie mit der Embroidery Design Editing Funktion Ihre Stickereien verschönern und erzielen traumhafte Ergebnisse.
<G-vec00386-002-s761><enhance.verschönern><en> Industrial coatings from ALTANA enhance, improve and protect.
<G-vec00386-002-s761><enhance.verschönern><de> Industrielacke von ALTANA verschönern, veredeln und schützen.
<G-vec00386-002-s762><enhance.verschönern><en> GAM Naked Cosmetics are designed to modify and enhance skin tones.
<G-vec00386-002-s762><enhance.verschönern><de> GAM Hautkosmetik wurde entwickelt, um Hautfarbtöne zu modifizieren und zu verschönern.
<G-vec00386-002-s763><enhance.verschönern><en> Its black colour and its delicate mixture of textile enhance your silhouette, to the delight of your partner.
<G-vec00386-002-s763><enhance.verschönern><de> Seine schwarze Farbe und seine zarte Mischung aus Textilien werden Ihre Silhouette, sehr zur Freude Ihres Partners, verschönern.
<G-vec00386-002-s764><enhance.verschönern><en> In addition to the first-class accommodation and luxurious details that await group members at this hotel, Gran Hotel Atlantis Bahía Real has devised numerous sporting activities and outings that will enhance their stay on this island.
<G-vec00386-002-s764><enhance.verschönern><de> Neben den erstklassigen Unterkünften und luxuriösen Details, die Gruppen in diesem Hotel erwarten, bietet das Gran Hotel Atlantis Bahía Real zahlreiche Sportaktivitäten und Ausflüge an, die Ihren Aufenthalt auf der Insel verschönern werden.
<G-vec00386-002-s765><enhance.verschönern><en> Log in to "MY TUI BLUE" and get all the benefits: Online check-in and booking of extras and experiences that will enhance your trip.
<G-vec00386-002-s765><enhance.verschönern><de> Loggen Sie sich bei "MEIN TUI BLUE" ein und nutzen Sie alle Vorteile: Online-Check-in und Buchung von Extras und Erlebnissen, die Ihre Reise verschönern.
<G-vec00386-002-s766><enhance.verschönern><en> Remember that makeup is meant to enhance your natural features, not to cover them up.
<G-vec00386-002-s766><enhance.verschönern><de> Denke immer daran, dass Makeup dazu gedacht ist, dich zu verschönern.
<G-vec00386-002-s767><enhance.verschönern><en> We are committed to supplying solutions which save money, enhance your environment and are environmentally considerate.
<G-vec00386-002-s767><enhance.verschönern><de> Wir wollen Lösungen bieten, die Geld sparen, Ihr Umfeld verschönern und Rücksicht auf die Umwelt nehmen.
<G-vec00386-002-s768><enhance.verschönern><en> These sensual stockings are the perfect choice to enhance a naughty outfit.
<G-vec00386-002-s768><enhance.verschönern><de> Diese sinnlichen Strümpfe sind perfekt, um ein sexy Outfit zu verschönern.
<G-vec00386-002-s769><enhance.verschönern><en> The products of our tesa® SMOOZ premium design line enhance every bathroom with unique design and smooth surfaces.
<G-vec00386-002-s769><enhance.verschönern><de> Unsere hochklassige Designlinie tesa® MOON steht für runde Formen und Edelstahl in tesa® SMOOZ verschönern mit ihrem einzigartigen Design und glatten Oberflächen jedes Badezimmer.
<G-vec00386-002-s770><enhance.verschönern><en> Choose from our stylish wall-mounted soap dispensers that enhance the beauty of every bathroom.
<G-vec00386-002-s770><enhance.verschönern><de> Wählen Sie unter unseren stilvollen Wandseifenspendern, die jedes Badezimmer verschönern.
<G-vec00386-002-s771><enhance.verschönern><en> This subtly see-through luxurious creation will unveil your charming assets, while its curved shape will enhance your silhouette.
<G-vec00386-002-s771><enhance.verschönern><de> Diese subtil transparente, luxuriöse Kreation wird Ihre Reize enthüllen, während seine taillierte Form Ihre Figur verschönern wird.
<G-vec00386-002-s772><enhance.verschönern><en> Available in four shades, Phyt’s Organic Make-Up Foundations offer fluid and silky, non-greasy, non-comedogenic textures which enhance the complexion and leave an infinitely soft and delicately powdery veil on the skin.
<G-vec00386-002-s772><enhance.verschönern><de> Die in 5 Farbtönen erhältliche Foundations von Phyt’s Organic Make-Up zeichnet sich durch flüssige, seidige, nicht fette und nicht komedogene Texturen aus, die den Teint verschönern und die Haut hauchzart und leicht pudrig überziehen.
<G-vec00386-002-s773><enhance.verschönern><en> Once you have made your reservation you have 4 exclusive packages to enhance your stay ..
<G-vec00386-002-s773><enhance.verschönern><de> Am Ende Ihrer Reservierung, können Sie 2 exklusive Pakete wählen, um Ihren Aufenthalt zu verschönern..
<G-vec00386-002-s774><enhance.verschönern><en> Sex is an important and beautiful part of our life and should as much as possible enhance our everyday life.
<G-vec00386-002-s774><enhance.verschönern><de> Sex ist ein wichtiger und wunderschöner Bestandteil unseres Lebens und sollte so häufig wie möglich unseren Alltag verschönern.
<G-vec00386-002-s775><enhance.verschönern><en> Our full range of genuine Aston Martin accessories, carefully designed to complement, enhance and personalise your Aston Martin.
<G-vec00386-002-s775><enhance.verschönern><de> Unsere gesamte Palette an Originalzubehör wurde sorgfältig ausgewählt, damit Sie Ihren Aston Martin perfekt ergänzen, verschönern und personalisieren können.
<G-vec00386-002-s776><enhance.verstärken><en> Contains light-diffusing particles and crushed pearl to enhance your natural radiance.
<G-vec00386-002-s776><enhance.verstärken><de> Enthält lichtstreuende Partikel und zerkleinerte Perlen, um Ihre natürliche Ausstrahlung zu verstärken.
<G-vec00386-002-s777><enhance.verstärken><en> Building further on existing legislation on irregular migration and the fight against human trafficking, the Commission wants to enhance its actions in this area.
<G-vec00386-002-s777><enhance.verstärken><de> Aufbauend auf den bestehenden Rechtsvorschriften zur irregulären Migration und zur Bekämpfung des Menschenhandels möchte die Kommission ihre Tätigkeit in diesem Bereich verstärken.
<G-vec00386-002-s778><enhance.verstärken><en> To further enhance this effect, Ultra Slim breaks down the excess fat into individual parts.
<G-vec00386-002-s778><enhance.verstärken><de> Um diesen Effekt noch zu verstärken, zerlegt Ultra Slim das überschüssige Fett in Einzelteile.
<G-vec00386-002-s779><enhance.verstärken><en> Equipped with opposite colored candles you can enhance the light-dark effect.
<G-vec00386-002-s779><enhance.verstärken><de> Mit entgegengesetzt farbigen Kerzen bestückt, können Sie den Hell-Dunkel-Effekt noch verstärken.
<G-vec00386-002-s780><enhance.verstärken><en> To enhance the effect, you can add to the grape a few drops of calendula oil, mint, lemon or other suitable for your skin.
<G-vec00386-002-s780><enhance.verstärken><de> Um den Effekt zu verstärken, können Sie der Traube ein paar Tropfen Ringelblumenöl, Minze, Zitrone oder anderes für Ihre Haut geeignetes Öl hinzufügen.
<G-vec00386-002-s781><enhance.verstärken><en> Both light and sound are intended to enhance the relaxing effect of the diffuser and, in addition to the sense of smell, also address the sense of sight and hearing.
<G-vec00386-002-s781><enhance.verstärken><de> Sowohl Licht als auch Klang sollen die entspannende Wirkung des Diffusors verstärken und neben dem Geruchssinn auch den Seh- sowie den Hörsinn ansprechen.
<G-vec00386-002-s782><enhance.verstärken><en> c. Can enhance human immunity and prevent coronary disease and cardiovascular sclerosis.
<G-vec00386-002-s782><enhance.verstärken><de> c. Kann menschliche Immunität verstärken und Koronarkrankheit und kardiovaskuläre Sklerose verhindern.
<G-vec00386-002-s783><enhance.verstärken><en> On colder days, the parka can also be combined with a short, quilted coat such as DIANA MULT to enhance the warming effect.
<G-vec00386-002-s783><enhance.verstärken><de> An kälteren Tagen kann man den Parka auch mit einem Steppkurzmantel wie zum Beispiel DIANA MULT kombinieren und so den wärmenden Effekt verstärken.
<G-vec00386-002-s784><enhance.verstärken><en> The outer pressure points enhance the perception of stimuli in the surrounding area and boost the joint function of the knee through a number of effects including faster muscle activation.
<G-vec00386-002-s784><enhance.verstärken><de> Die äußeren Druckpunkte verstärken die Reizwahrnehmung im umliegenden Bereich und beeinflussen positiv die Gelenkfunktion des Knies, unter anderem durch eine schnellere Muskelansteuerung.
<G-vec00386-002-s785><enhance.verstärken><en> Night creams and masks enhance this effect, as well as nourish and moisturize the skin.
<G-vec00386-002-s785><enhance.verstärken><de> Nachtcremes und -masken verstärken diesen Effekt und pflegen und befeuchten die Haut.
<G-vec00386-002-s786><enhance.verstärken><en> This one will give him the great sensation of vibration while holding his penis tightly to keep the blood in the head; this will help him stay rock hard and will enhance the feeling of every single thing you’re doing.
<G-vec00386-002-s786><enhance.verstärken><de> Das wird deinem Mann intensive Gefühle durch Vibrationen geben, er sollte währenddessen seinen Penis fest halten, um das Blut im Kopf zu halten; Dies wird ihm helfen, steinhart zu bleiben und wird das Gefühl verstärken.
<G-vec00386-002-s787><enhance.verstärken><en> Start with a set of one to two teaspoons per day for two or three weeks and you increase the amount if you want to enhance the effect.
<G-vec00386-002-s787><enhance.verstärken><de> Beginnen Sie mit einer Menge von ein bis zwei Teelöffel pro Tag für zwei oder drei Wochen und steigern Sie die Menge, wenn Sie die Wirkung verstärken möchten.
<G-vec00386-002-s788><enhance.verstärken><en> In the gaming and leisure business lighting effects enhance the fun with games.
<G-vec00386-002-s788><enhance.verstärken><de> In der Unterhaltungs- und Freizeitwirtschaft verstärken Lichteffekte den Spaß am Spiel.
<G-vec00386-002-s789><enhance.verstärken><en> They don’t however only complete each other to make a whole, they are at odds, disagree, respond with variances or enhance each other.
<G-vec00386-002-s789><enhance.verstärken><de> Ihre Bilder ergänzen sich aber nicht einfach zu einem Ganzen, sie reagieren aufeinander, verstärken sich, stoßen sich ab, verändern sich.
<G-vec00386-002-s790><enhance.verstärken><en> A coherent and coordinated EU-level action can add value and enhance the overall impact, whilst respecting the autonomy of national initiatives.
<G-vec00386-002-s790><enhance.verstärken><de> Eine kohärente, koordinierte Maßnahme auf EU-Ebene kann zusätzlichen Nutzen bringen und die Gesamtwirkung verstärken, bei gleichzeitiger Achtung der Unabhängigkeit nationaler Initiativen.
<G-vec00386-002-s791><enhance.verstärken><en> With the qualifying race carrying its name, Porsche is visible worldwide at every WTA tournament and will additionally enhance its presence at selected events.
<G-vec00386-002-s791><enhance.verstärken><de> Als Namensgeber des Qualifikationsrennens ist Porsche weltweit bei allen Turnieren der WTA sichtbar und wird seine Präsenz bei ausgewählten Events zusätzlich verstärken.
<G-vec00386-002-s792><enhance.verstärken><en> Scented oils enhance the feeling of wellness.
<G-vec00386-002-s792><enhance.verstärken><de> Wohlriechende Öle verstärken den Wellness-Effekt.
<G-vec00386-002-s793><enhance.verstärken><en> Make it foam well and thereby enhance the effect.
<G-vec00386-002-s793><enhance.verstärken><de> Es lässt sich gut aufschäumen und kann dadurch die Wirkung verstärken.
<G-vec00386-002-s794><enhance.verstärken><en> On the lower right, the number next to the Survivor icon tells you how many Shards are needed to Enhance your Survivor.
<G-vec00386-002-s794><enhance.verstärken><de> Unten rechts zeigt die Zahl neben dem Survivorssymbol an, wie viele Scherben erforderlich sind, um den Survivor zu verstärken.
<G-vec00386-002-s813><enhance.vertiefen><en> In the afternoon sessions we enhance the experience by becoming pilgrims.
<G-vec00386-002-s813><enhance.vertiefen><de> Nachmittags vertiefen wir das Erlebnis, indem wir Pilger werden.
<G-vec00386-002-s814><enhance.vertiefen><en> It will continue to broaden and enhance its political and trade relations with other countries and regions of the world, including by holding regular summits with its strategic partners such as the United States, Japan, Canada, Russia, India and China.
<G-vec00386-002-s814><enhance.vertiefen><de> Die EU wird auch in Zukunft ihre politischen Beziehungen und Handelsbeziehungen zu den anderen Ländern und Regionen der Welt erweitern und vertiefen, unter anderem durch regelmäßige Gipfeltreffen mit ihren strategischen Partnern wie den USA, Japan, Kanada, Russland, Indien und China.
<G-vec00386-002-s815><enhance.vertiefen><en> You will also spend academic holidays with us, which is a total of 12 weeks per year. This gives you the opportunity to enhance your theoretical knowledge with practical assignments while also receiving payment for your work.
<G-vec00386-002-s815><enhance.vertiefen><de> Außerdem werden Sie bei uns in den Semesterferien, insgesamt 12 Wochen pro Jahr, Ihre Studienkenntnisse praktisch vertiefen und erhalten dafür eine zusätzliche Praktikumsvergütung.
<G-vec00386-002-s816><enhance.vertiefen><en> In order to prepare graduates for their professional practice, the Bachelor’s program concludes with projects that give students the opportunity to test, enhance, and reflect their own skills in the field of IT-Systems Engineering.
<G-vec00386-002-s816><enhance.vertiefen><de> Um die Absolventen auf die Praxis vorzubereiten, werden zum Abschluss des Bachelorstudiums Projekte durchgeführt, in denen die Studenten ihre Fähigkeiten im IT-Systems Engineering erproben, vertiefen und reflektieren.
<G-vec00386-002-s817><enhance.vertiefen><en> You wish to be prepared for or enhance your knowledge of legal, accounting and tax requirements concerning subsidised housing and rental activity Our offering
<G-vec00386-002-s817><enhance.vertiefen><de> Sie möchten die rechtlichen, buchhalterischen und steuerlichen Besonderheiten in Bezug auf den Eigentumserwerb oder das Mietgeschäft im sozialen Wohnungsbau verstehen oder vertiefen.
<G-vec00386-002-s818><enhance.vertiefen><en> You will enhance your theoretical knowledge.
<G-vec00386-002-s818><enhance.vertiefen><de> Sie vertiefen Ihre theoretischen Kenntnisse.
<G-vec00386-002-s819><enhance.vertiefen><en> Course contents in detail In your studies at the FHNW Academy of Art and Design you enhance and enlarge upon your scientific, artistic and design-related skills and inquire into art and design education as well as artistic research.
<G-vec00386-002-s819><enhance.vertiefen><de> In den Studienanteilen an der Hochschule für Gestaltung und Kunst FHNW vertiefen und erweitern Sie Ihre bisher erworbenen wissenschaftlichen, gestalterischen und künstlerischen Kompetenzen und nähern sich den Bereichen Kunst- und Designvermittlung sowie künstlerischer Forschung an.
<G-vec00386-002-s820><enhance.vertiefen><en> We will furthermore enhance our ability to listen and to set positive goals.
<G-vec00386-002-s820><enhance.vertiefen><de> Ebenfalls werden wir unsere Fähigkeiten, zuzuhören und positive Ziele zu setzen, vertiefen.
<G-vec00386-002-s821><enhance.vertiefen><en> Brainstorm topics, storyboard presentations, enhance meeting discussions and improve white board sessions.
<G-vec00386-002-s821><enhance.vertiefen><de> Sammeln Sie Themen, skizzieren Präsentationen, vertiefen Meeting-Diskussionen und verbessern Whiteboard-Sessions.
<G-vec00386-002-s822><enhance.vertiefen><en> The course contains 5 lessons with numerous dialogues, specialised texts and a wide variety of interactive exercises with which you will be able to practice and enhance your knowledge.
<G-vec00386-002-s822><enhance.vertiefen><de> Der Kurs besteht aus 5 Lektionen mit Dialogen, Fachtexten und vielen interaktiven Übungen, durch die Sie lernen und Ihr Wissen vertiefen können.
<G-vec00386-002-s823><enhance.vertiefen><en> Between 1995-1997 she took an additional course “AMV” in order to enhance her skills in teaching children.
<G-vec00386-002-s823><enhance.vertiefen><de> Zwischen 1995 – 1997 hat sie einen Applikationskursus AMV gefolgt um sich im Unterricht von Kindern zu vertiefen.
<G-vec00386-002-s824><enhance.vertiefen><en> Therefore, on strategic matters, our member states must enhance their cooperation and act together.
<G-vec00386-002-s824><enhance.vertiefen><de> Darum müssen unsere Mitgliedstaaten in strategischen Angelegenheiten ihre Zusammenarbeit vertiefen und gemeinschaftlich handeln.
<G-vec00386-002-s825><enhance.vertiefen><en> In order to enhance each person’s experience, we were divided into small groups.
<G-vec00386-002-s825><enhance.vertiefen><de> Um die Erfahrung jedes einzelnen noch zu vertiefen, wurden wir in kleine Gruppen aufgeteilt.
<G-vec00386-002-s826><enhance.vertiefen><en> The journal aims to enhance the academic exchange between civil and common law and thus create a platform for jurists from both systems.
<G-vec00386-002-s826><enhance.vertiefen><de> Das Journal hat das Ziel den akademischen Austausch zwischen Vertretern der beiden Systeme zu vertiefen und soll so eine Plattform für Juristen aus beiden Systemen kreieren.
<G-vec00386-002-s827><enhance.vertiefen><en> During his incumbency as BND President (1998 - 2005), the current Interior Ministry State Secretary, August Hanning, had sought to enhance cooperation between Siemens and German foreign intelligence.
<G-vec00386-002-s827><enhance.vertiefen><de> Der Staatssekretär im Bundesinnenministerium August Hanning hat sich während seiner Amtszeit als BND-Präsident (1998 bis 2005) bemüht, die Kooperation zwischen der Auslandsspionage und Siemens zu vertiefen.
<G-vec00386-002-s828><enhance.vertiefen><en> During this time, you will enhance your knowledge in selected areas, such as project management, consultancy or quality management.
<G-vec00386-002-s828><enhance.vertiefen><de> Nun vertiefen Sie Ihr Wissen in ausgewählten Bereichen, zum Beispiel im Projektmanagement, in der Beratung oder im Qualitätsmanagement.
<G-vec00386-002-s829><enhance.vertiefen><en> The country-specific e-learning modules refresh the theoretical content of the seminar and enhance it in a targeted manner through selected case studies.
<G-vec00386-002-s829><enhance.vertiefen><de> Die länderbezogenen E-Learning Module greifen die vermittelte Theorie aus dem Training erneut auf und vertiefen diese gezielt durch ausgewählte Fallstudien.
<G-vec00386-002-s830><enhance.werten><en> Fully equipped bathrooms and living areas further enhance the comfort of your stay.
<G-vec00386-002-s830><enhance.werten><de> Voll ausgestattete Badezimmer und Sitzbereiche werten das Wohnerlebnis zusätzlich auf.
<G-vec00386-002-s831><enhance.werten><en> Luxurious accessories but also individual pieces of jewellery enhance any outfit and reflect the wearer’s personality.
<G-vec00386-002-s831><enhance.werten><de> Luxuriöse Accessoires, aber auch Einzelschmuckstücke werten jedes Outfit auf und spiegeln die eigene Persönlichkeit wieder.
<G-vec00386-002-s832><enhance.werten><en> Reviews Details Bring natural cosiness into your home: Wool rugs by benuta inspire with their simple elegance and enhance any living space.
<G-vec00386-002-s832><enhance.werten><de> Bewertungen Details Holen Sie sich natürliche Gemütlichkeit in Ihr Zuhause: Wollteppiche von benuta begeistern durch ihre schlichte Eleganz und werten jeden Wohnraum auf.
<G-vec00386-002-s833><enhance.werten><en> Enhance the look of your website with animated Gif's.
<G-vec00386-002-s833><enhance.werten><de> Werten Sie Ihre Homepage mit animierten Gif-Grafiken auf.
<G-vec00386-002-s834><enhance.werten><en> Ingo Maurer lamps also enhance a bedroom in an inimitable way.
<G-vec00386-002-s834><enhance.werten><de> Ingo Maurer Lampen werten auch ein Schlafzimmer in unnachahmlicher Weise auf.
<G-vec00386-002-s835><enhance.werten><en> Fehling "Crashbars" provide precision-fit, rock-solid quality "Made in Germany"; they are available in high-quality chrome or black powder-coated, and enhance the look of the motorcycle.
<G-vec00386-002-s835><enhance.werten><de> Fehling "Crashbars" bieten passgenaue, solide Qualität "made in Germany", sie sind hochwertig verchromt oder schwarz pulverbeschichtet, werten das Fahrzeug optisch auf.
<G-vec00386-002-s836><enhance.werten><en> These versatile candle accessories provide an easy way to enhance the look of any room, from modern to traditional.
<G-vec00386-002-s836><enhance.werten><de> Über dieses Accessoire Diese vielseitigen Kerzen-Accessoires werten jeden Raum stilvoll auf, egal, ob modern oder klassisch eingerichtet.
<G-vec00386-002-s837><enhance.werten><en> Additional practical presentations, several networking options and interactive components will enhance the event and provide the participants with a clear edge in their daily work.
<G-vec00386-002-s837><enhance.werten><de> Weitere Praxisvorträge, viele Möglichkeiten zum Netzwerken und interaktive Bestandteile werten die Veranstaltung auf und vermitteln den Teilnehmern einen großen Nutzen für Ihre tägliche Arbeit.
<G-vec00386-002-s838><enhance.werten><en> MAGNAT's systems are suitable for virtually all flatscreen TVs and will enhance the visual appearance of any living room.
<G-vec00386-002-s838><enhance.werten><de> Die MAGNAT Systeme sind geeignet für nahezu jeden Flachbildschirm und werten aus optischer Perspektive jedes Wohnzimmer auf.
<G-vec00386-002-s839><enhance.werten><en> These carbon parts perfectly fit standard carbon interior and enhance it additionally.
<G-vec00386-002-s839><enhance.werten><de> Diese Carbonteile passen optimal zum serienmäßigen Carbon-Interieur und werten den Innenraum zusätzlich auf.
<G-vec00386-002-s840><enhance.werten><en> The ads are related to what your users are looking for on your site, so they'll help you enhance your content pages while earning from them.
<G-vec00386-002-s840><enhance.werten><de> Da sich die Anzeigen auf die Informationen beziehen, die Nutzer auf Ihrer Website suchen, verdienen Sie damit nicht nur bares Geld, sondern werten Ihre Content-Seiten gleichzeitig auf.
<G-vec00386-002-s841><enhance.werten><en> Bekaert Textile’s innovative and intelligent mattress products enhance your mattress system as a whole, since they concentrate on complete solutions and packages.
<G-vec00386-002-s841><enhance.werten><de> Bekaert Textile’s innovative und intelligente Matratzenprodukte werten Ihre Matratze als Ganzes auf, da sie sich auf Komplettlösungen- und Pakete konzentrieren.
<G-vec00386-002-s842><enhance.werten><en> Give your Audi an especially sporty look and significantly enhance the vehicle interior.
<G-vec00386-002-s842><enhance.werten><de> Produktbeschreibung Verleihen Ihrem Audi eine sportliche Note und werten den Innenraum deutlich auf.
<G-vec00386-002-s843><enhance.werten><en> Achievements: Special occupational and non-occupational achievements enhance your CV.
<G-vec00386-002-s843><enhance.werten><de> Erfolge: Besondere berufliche und auch außerhalb der beruflichen Tätigkeit liegende Erfolge werten deinen CV auf.
<G-vec00386-002-s844><enhance.werten><en> Enhance your yoga practice and relax more intensively with pleasant aromas surrounding you.
<G-vec00386-002-s844><enhance.werten><de> Mit angenehmen Aromen werten Sie Ihre Yoga-Praxis auf und entspannen sich noch intensiver.
<G-vec00386-002-s845><enhance.werten><en> Whether bright or subtle green, shoes of this colour enhance simple outfits and should not be missing from the colour blocking trend.
<G-vec00386-002-s845><enhance.werten><de> Ob knalliges oder dezentes Grün, Schuhe dieser Farbe werten vor allem schlichte Outfits auf und dürfen beim Couleur-Blocking-Trend nicht fehlen.
<G-vec00386-002-s846><enhance.werten><en> These exclusive shower heads and shower systems enjoy increasing popularity and enhance the status of your bathroom; obtainable in oval and square formats.
<G-vec00386-002-s846><enhance.werten><de> Diese exklusiven Brausen und Duschsysteme erfreuen sich derzeit steigender Beliebtheit und werten jedes Badezimmer auf und sind sowohl in runder und ovaler als auch eckiger Ausführung erhältlich.
<G-vec00386-002-s847><enhance.werten><en> View this model HSE WITH DYNAMIC PACK Gloss Black exterior details enhance the dynamic design, while the interior features Oxford perforated leather seats and a 12,3” virtual instrument panel.
<G-vec00386-002-s847><enhance.werten><de> Hochwertige Sitze aus perforiertem Exterieur-Akzente in Gloss Black werten das dynamische Design noch zusätzlich auf, während der Innenraum mit Sitzen aus perforiertem Oxford-Leder und einer virtuellen 12,3-Zoll-Instrumententafel ausgestattet ist.
<G-vec00386-002-s848><enhance.werten><en> The beautiful laser details further enhance the leather.
<G-vec00386-002-s848><enhance.werten><de> Die schönen Laserdetails werten das Leder zusätzlich auf.
