<G-vec00109-002-s057><climb.klettern><en> If you have time, you can climb the Vereda da Boca do Risco, that guide hikers to a viewpoint which offers a breathtaking view of the north coast of the Island.
<G-vec00109-002-s057><climb.klettern><de> Wenn Sie Zeit haben, können Sie auf den Vereda da Boca do Risco klettern, der Wanderer auf einen Aussichtspunkt führt, der einen atemberaubenden Blick auf die Nordküste der Insel bietet.
<G-vec00109-002-s058><climb.klettern><en> In the museum, children can experience animals up close, romp in the waterhole on the adventure playground, climb trees, jump into hay, bake bread, make their own herbal ointments and learn everything about milk.
<G-vec00109-002-s058><climb.klettern><de> Im Museum können Kinder Tiere hautnah erleben, auf dem Abenteuerspielplatz in den Wasserstelle toben, auf Bäume klettern, ins Heu springen, Brot backen, Kräutersalben selbst herstellen und alles über die Milch erfahren.
<G-vec00109-002-s059><climb.klettern><en> You can freely explore the Diocletian's Palace, climb the St. Domnius Bell Tower, take a walk down Sustipan or have a coffee on the Riva promenade and enjoy the view of sea, boats and flying seagulls.
<G-vec00109-002-s059><climb.klettern><de> Sie haben Zeit auch den berühmten Diokletianpalast zu besichtigen und auf den Glockenturm St. Duje klettern, durch Sustipan spazieren und Kaffee an der Riva trinken und den Blick auf Meer und Boote, über welchen Seemöwen fliegen, genießen.
<G-vec00109-002-s060><climb.klettern><en> Dogs can't climb trees.
<G-vec00109-002-s060><climb.klettern><de> Hunde können nicht auf Bäume klettern.
<G-vec00109-002-s061><climb.klettern><en> Experience what it feels like to hike and climb a body of constantly-moving dense ice.
<G-vec00109-002-s061><climb.klettern><de> Erleben Sie, wie es sich anfühlt, zu wandern und auf einen sich ständig bewegenden dichten Eiskörper zu klettern.
<G-vec00109-002-s062><climb.klettern><en> Explore the forest, watch the animals, climb trees, recognize sounds.
<G-vec00109-002-s062><climb.klettern><de> Erkunden Sie die Wälder, Tiere beobachten, auf Bäume klettern, Klänge erkennen.
<G-vec00109-002-s063><climb.klettern><en> If they wrestle, climb a tree...I love that.
<G-vec00109-002-s063><climb.klettern><de> Wenn sie sich balgen, auf Bäume klettern..das mag ich.
<G-vec00109-002-s064><climb.klettern><en> For a small surcharge you can climb the Bear Rock.
<G-vec00109-002-s064><climb.klettern><de> Gegen eine geringe Gebühr können Sie auf den Fels klettern.
<G-vec00109-002-s065><climb.klettern><en> With children, who climb trees And pick bouquets of flowers.
<G-vec00109-002-s065><climb.klettern><de> Mit Kindern, die auf Bäume klettern Und Blumensträuße pflücken.
<G-vec00109-002-s279><climb.klettern><en> Explore the 20,000 square metre water park at the entrance to Ötztal – people don't swim and splash around here, no – from May through to September they blob, climb, slide at top speed and jump.
<G-vec00109-002-s279><climb.klettern><de> Entdecke den 20.000 Quadratmeter großen Wasserpark am Eingang des Ötztals: Hier wird nicht gebadet und geplanscht, sondern geblobbt, geklettert, mit Vollspeed gerutscht und gesprungen.
<G-vec00109-002-s280><climb.klettern><en> Most often, stairs are installed in the hallway or hall, thereby allowing without a long transition to superfluous rooms immediately from the threshold to climb to the desired floor.
<G-vec00109-002-s280><climb.klettern><de> Meistens werden Treppen im Flur oder in der Halle installiert, wodurch ohne einen langen Übergang zu überflüssigen Räumen unmittelbar von der Schwelle aus auf das gewünschte Stockwerk geklettert werden kann.
<G-vec00109-002-s281><climb.klettern><en> In a jam session you can climb on 30 different boulders from 4pm – 8pm.
<G-vec00109-002-s281><climb.klettern><de> Geklettert wird in einer Jam Session von 16h00 - 20h00 an 30 verschiedenen Bouldern.
<G-vec00109-002-s282><climb.klettern><en> Once you climb up the hill, once called “the picture”, you reach the old village.
<G-vec00109-002-s282><climb.klettern><de> Sobald man auf die höchste Erhebung des Hügels geklettert ist, einst ‘Bilder‘ genannt, erreichen Sie das alte Dorf.
<G-vec00109-002-s283><climb.klettern><en> In close vicinity you can climb, in winter you can enjoy playing ice hockey.
<G-vec00109-002-s283><climb.klettern><de> In naher Umgebung kann auch geklettert oder im Winter Eishockey gespielt werden.
<G-vec00109-002-s284><climb.klettern><en> We had to climb on a twenty year old wall, that was only about 8 meters high, vertical and with a bad surface.
<G-vec00109-002-s284><climb.klettern><de> Geklettert wurde auf einer 20 Jahre alten Wand, gerade einmal 8 m hoch, flach und mit einer lackierten Oberfläche.
<G-vec00109-002-s285><climb.klettern><en> I climb over with them, shedding my clothes and jump in the water.
<G-vec00109-002-s285><climb.klettern><de> Ich bin mit ihnen über den Zaun geklettert, habe mir die Kleider vom Leib gerissen und bin ins Wasser gesprungen.
<G-vec00109-002-s286><climb.klettern><en> Due to the shade of the surrounding trees, you can also climb there on hot summer days.
<G-vec00109-002-s286><climb.klettern><de> Das Gebiet ist von schattenspendenden Bäumen umgeben, sodass auch an heißen Sommertagen sehr gut geklettert werden kann.
<G-vec00109-002-s287><climb.klettern><en> Due to the south-facing location, it is often possible to climb here on sunny winter days.
<G-vec00109-002-s287><climb.klettern><de> Auf Grund der südseitigen Lage kann hier oft auch an sonnigen Wintertagen geklettert werden.
<G-vec00109-002-s288><climb.klettern><en> There is a tower to climb which I did but it was pretty dangerous as the steps were icy.
<G-vec00109-002-s288><climb.klettern><de> In dem Waldstück ist auch ein kleiner Aussichtsturm, auf den ich geklettert bin, allerdings waren die Stufen vereist, sodass es ganz schön gefährlich war.
<G-vec00109-002-s308><climb.klettern><en> In the wall bars climb, then climb in the next wall bars down.
<G-vec00109-002-s308><climb.klettern><de> An der Kletter-Wand hinauf klettern, dann an der nächsten Kletter-Wand hinunter klettern.
<G-vec00109-002-s309><climb.klettern><en> There you can climb up.
<G-vec00109-002-s309><climb.klettern><de> Dort könnt ihr hinauf klettern.
<G-vec00109-002-s310><climb.klettern><en> His DNA is rewritten and he becomes stronger, faster, he can climb walls and shoot spider threads from his wrists.
<G-vec00109-002-s310><climb.klettern><de> Seine DNA wird umgeschrieben und dadurch wird er stärker, schneller, er kann Wände hinauf klettern und Spinnfäden von seinen Handgelenken schießen.
<G-vec00109-002-s311><climb.klettern><en> Here you will find a thin column you can climb upon.
<G-vec00109-002-s311><climb.klettern><de> Hier könnt ihr eine dünne Säule hinauf klettern.
<G-vec00109-002-s312><climb.klettern><en> In the pole climb, jump off, further up climb, and open the ceiling hatch.
<G-vec00109-002-s312><climb.klettern><de> An der Stange hinauf klettern, abspringen, weiter hinauf klettern, und die Deckenluke öffnen.
<G-vec00109-002-s313><climb.klettern><en> Go to the right to the library, climb on the right in the shelve, and on the safe column jump.
<G-vec00109-002-s313><climb.klettern><de> Nach rechts in die Bibliothek gehen, rechts am Regal hinauf klettern, und auf die sichere Säule springen.
<G-vec00109-002-s314><climb.klettern><en> After a nice hour of walking, crossed one of the ski slopes that connect Ciampedie with Vigo di Fassa (we are in fact in a very famous ski area), you will regain the Rifugio Nigritella (m 1986), emerging from that path that, to left, we left at the beginning to climb up the steep one towards the Baita Pra Martin; still few steps and the green meadows will make us realize that we are now near the cable car, which we will resume to return to the valley.
<G-vec00109-002-s314><climb.klettern><de> Nach einer schönen Stunde zu Fuß, über eine der Skipisten, die Ciampedie mit Vigo di Fassa verbinden (wir sind in der Tat in einem sehr berühmten Skigebiet), werden Sie die Rifugio Nigritella (m 1986), aus dem Weg, der, um links, wir gingen am Anfang, um den steilen zum Baita Pra Martin hinauf zu klettern; Noch ein paar Schritte und die grünen Wiesen lassen uns vermuten, dass wir uns jetzt in der Nähe der Seilbahn befinden, die wir wieder ins Tal bringen werden.
<G-vec00109-002-s315><climb.klettern><en> Go towards the wall right of it and climb up.
<G-vec00109-002-s315><climb.klettern><de> Zu der Mauer rechts davon gehen und hinauf klettern.
<G-vec00109-002-s316><climb.klettern><en> In the water jump, and the ladder climb up to the time switch.
<G-vec00109-002-s316><climb.klettern><de> Ins Wasser springen, und die Leiter hinauf klettern zum Zeitschalter.
<G-vec00109-002-s317><climb.klettern><en> Go towards the crate in the right corner, but don't climb up yet.
<G-vec00109-002-s317><climb.klettern><de> Zu der Kiste in den rechten Ecke gehen, aber nicht hinauf klettern.
<G-vec00109-002-s318><climb.klettern><en> She then made every possible effort to climb up one of the legs of the table, but it was much too slippery; and finally, overcome by fatigue, the poor child sat down and wept.
<G-vec00109-002-s318><climb.klettern><de> Sie sah es ganz deutlich durch das Glas, und sie gab sich alle Mühe an einem der Tischfüße hinauf zu klettern, aber er war zu glatt; und als sie sich ganz müde gearbeitet hatte, setzte sich das arme, kleine Ding hin und weinte.
<G-vec00109-002-s319><climb.klettern><en> She told me to go to the barn, climb the ladder, and if I found her two hens, to shoo them out and bring any eggs I might find.
<G-vec00109-002-s319><climb.klettern><de> Sie sagte mir ich solle zur Scheune gehen, die Leiter hinauf klettern, und wenn ich ihre beiden Hennen finden würde, solle ich sie hinaus scheuchen und ihr alle Eier die ich finden könnte bringen.
<G-vec00109-002-s320><climb.klettern><en> In the ladder climb, to the middle part jump near the blue crystal, and over jump to the wolves.
<G-vec00109-002-s320><climb.klettern><de> An der Leiter hinauf klettern, zu dem mittleren Teil bei dem blauen Kristall springen, und hinüber zu den Wölfen springen.
<G-vec00109-002-s321><climb.klettern><en> You are afraid to climb the golden ladder to Heaven.
<G-vec00109-002-s321><climb.klettern><de> Du hast Angst, die goldene Leiter zum Himmel hinauf zu klettern.
<G-vec00109-002-s322><climb.klettern><en> The lever pull, then further go up, in the pole climb which combine two Eye Piece and insert.
<G-vec00109-002-s322><climb.klettern><de> Den Hebel ziehen, dann weiter hinauf gehen, an der Stange hinauf klettern, die zwei Eye Piece kombinieren und einsetzen.
<G-vec00109-002-s367><climb.klettern><en> Climb up over the movable block, walk on top to the right, jump down and enter next corridor.
<G-vec00109-002-s367><climb.klettern><de> Kletter bei dem Schiebeblock nach oben, lauf oben nach rechts, spring runter und geh durch den nächsten Gang.
<G-vec00109-002-s368><climb.klettern><en> Find a Gold Skulltula #45 left side in the corner, then climb up the ladders and go around the corner until you find some arrows painted on the ground.
<G-vec00109-002-s368><climb.klettern><de> Finde die Goldene Skulltula #45 links in der Ecke, dann kletter die Leitern rauf und geh um die Ecke, bis du Pfeile auf dem Boden aufgemalt findest.
<G-vec00109-002-s369><climb.klettern><en> Swim around the mines, avoid the stream from the side, climb up the ladder at rear end, step on the switch, stand left side on the grid, shoot the switch at the wall, let the fountain bring you upwards and jump off.
<G-vec00109-002-s369><climb.klettern><de> Schwimm um die Minen herum, hüte dich vor der Seitenströmung, kletter die Leiter am hinteren Ende rauf, stell dich auf den Schalter, stell dich links auf den Deckel, schieß auf den Schalter an der Wand, lass dich von der Fontäne nach oben bringen und spring ab.
<G-vec00109-002-s370><climb.klettern><en> Climb up the leaderboards. Collect all achievements.
<G-vec00109-002-s370><climb.klettern><de> Kletter die Besteliste herauf und sammel alle Erfolge.
<G-vec00109-002-s371><climb.klettern><en> Pull a block from the wall left side (you can´t do much against the Rats), climb up and take the Compass from the treasure chest.
<G-vec00109-002-s371><climb.klettern><de> Zieh links einen Block aus der Wand (gegen die Ratten kannst du nicht viel machen), kletter rauf und nimm den Kompass aus der Schatzkiste.
<G-vec00109-002-s372><climb.klettern><en> Use the Slingshot to shoot in down, jump down, climb up the ladder and go back to the climb wall Navi had shown you before.
<G-vec00109-002-s372><climb.klettern><de> Schieß mit der Schleuder darauf und sie fällt runter, spring runter, kletter die Leiter rauf und geh zurück zu der ersten Kletterwand die Navi dir vorher gezeigt hat.
<G-vec00109-002-s373><climb.klettern><en> Swim back to the beach, climb onto the lowest platform, jump over the platforms to the wall, pull yourself to the trees on the next platforms, until you reach a hole in the wall blocked by 2 big boulders, bomb them away, enter and get Double Life Energy from the Great Fairy of Courage.
<G-vec00109-002-s373><climb.klettern><de> Schwimm zurück zum Strand, kletter auf die kleinste Plattform, spring über die Plattformen zur Wand, zieh dich zu den Bäumen auf dem nächsten Plattformen, bis du ein Loch in der Wand erreichst, was von 2 großen Steinen blockiert ist, bomb sie aus dem Weg, geh hinein und hol dir Doppelte Lebensenergie von der Großen Fee des Mutes.
<G-vec00109-002-s374><climb.klettern><en> Use the elevator at the entrance again to go back to the room with the rotating stream, walk a few steps straight out, until you can jump onto the rotating platforms, let it bring you to rear side, climb up and shoot the waterfalls above with an Ice Arrow to freeze it, then climb up and enter the door.
<G-vec00109-002-s374><climb.klettern><de> Benutz nochmal den Fahrstuhl am Eingang, geh wieder in den Raum wo das Wasser rotiert, lauf etwas geradeaus, bis du auf die rotierenden Plattformen springen kannst, lass dich zum hinteren Ende bringen, kletter rauf und schieß mit einem Eispfeil auf den Wasserfall oben um ihn einzufrieren, dann kletter rauf und öffne die Tür.
<G-vec00109-002-s376><climb.klettern><en> do the puzzle and climb up on a chair.
<G-vec00109-002-s376><climb.klettern><de> Setze das Puzzle nun wieder zusammen und kletter auf einen Stuhl.
<G-vec00109-002-s377><climb.klettern><en> Climb back up, enter right side, jump into the huge pool, dive down to the treasure chest on the platform and get Stray Fairy #13.
<G-vec00109-002-s377><climb.klettern><de> Kletter wieder nach oben, geh rechts hinein, spring ins Wasser, tauch runter zu der Schatzkiste auf der Plattform und hol dir die verirrte Fee #13.
<G-vec00109-002-s378><climb.klettern><en> Leave the Windmill, climb right in front of the door onto the fence, use the Hookshot to pull yourself to the roof of the Potion Shop, talk to the guy sitting there and he gives you a Piece of Heart #20.
<G-vec00109-002-s378><climb.klettern><de> Spring Windmühle, kletter gleich vor der Tür auf den Zaun, benutz den Fanghaken um dich aufs Dach vom Hexenladen zu ziehen, rede mit dem Typ dort und er gibt dir ein Herzteil #20.
<G-vec00109-002-s379><climb.klettern><en> Enter the small hole, climb down the ladder, kill the Skulltula and walk straight out through the wall.
<G-vec00109-002-s379><climb.klettern><de> Kriech durch das kleine Loch, kletter die Leiter runter, kill die Skulltula und lauf geradeaus durch die Wand.
<G-vec00109-002-s380><climb.klettern><en> Jump down, walk around, get rid of a lot of Gohma Eggs and Gohma Larva, then climb back up to the entrance, step on the switch to raise the platforms in the middle and reach the corners straight out and left to kill some more of them.
<G-vec00109-002-s380><climb.klettern><de> Spring runter, lauf herum, kill eine Menge Gohma-Eier und Gohma-Babys, dann kletter wieder zum Eingang, stell dich auf den Schalter um in der Mitte die Plattformen zu heben und die Ecken geradeaus und links zu erreichen, um einige Weitere zu killen.
<G-vec00109-002-s381><climb.klettern><en> Pull and push the statue on the blue switch on the ground to open the rear door, climb up and enter there.
<G-vec00109-002-s381><climb.klettern><de> Zieh und schieb die Statue auf den blauen Schalter am Boden um die Tür zu öffnen, kletter rauf und geh hinein.
<G-vec00109-002-s382><climb.klettern><en> Slide over here, climb into my mouth now child
<G-vec00109-002-s382><climb.klettern><de> Hier rüber rutschen, kletter jetzt in meinen Mund Kind.
<G-vec00109-002-s383><climb.klettern><en> Climb back down the ladder, in the corridor walk direction northwest through 2 doors, go left side around the corner, climb up the ladder and disable the next searchlights.
<G-vec00109-002-s383><climb.klettern><de> Kletter zurück die Leiter runter, geh unten im Gang Richtung Nordwest durch 2 Türen, links um die Ecke, kletter die Leiter rauf und leg die nächsten Scheinwerfer lahm.
<G-vec00109-002-s385><climb.klettern><en> Shoot an Ice Arrow onto the top of the volcano and climb up.
<G-vec00109-002-s385><climb.klettern><de> Schieß einen Eispfeil oben auf den Vulkan und kletter rauf.
<G-vec00109-002-s386><climb.klettern><en> -Don’t try to outrun an angry boar, climb up a tree instead.
<G-vec00109-002-s386><climb.klettern><de> - Versuche niemals von einem wütenden Wildschwein davonzulaufen, sondern klettere auf einen Baum.
<G-vec00109-002-s387><climb.klettern><en> Climb down.
<G-vec00109-002-s387><climb.klettern><de> Klettere nach unten.
<G-vec00109-002-s388><climb.klettern><en> Slip on your racing overalls, climb into a state of the art Formula One car and line up on the grid for the most accurate recreation of F1(TM) racing there is.
<G-vec00109-002-s388><climb.klettern><de> Schlüpf in deinen Rennoverall, klettere in ein hochgezüchtetes "Formel 1(TM)"-Auto und nehme deine Startposition in der weltbesten "Formel 1"-Simulation ein.
<G-vec00109-002-s389><climb.klettern><en> Climb through ventilation shafts, crawl upside down along the ceiling and swing through different levels using your grappling hook.
<G-vec00109-002-s389><climb.klettern><de> Klettere durch Belüftungsschächte, hangele Dich kopfüber an der Decke entlang und schwinge mithilfe Deines Enterhakens durch die verschiedensten Level.
<G-vec00109-002-s390><climb.klettern><en> Find it out yourself and climb to the Baba-Jaga house.
<G-vec00109-002-s390><climb.klettern><de> Finde es selbst heraus und klettere auf das Baba-Jaga-Haus hinauf.
<G-vec00109-002-s391><climb.klettern><en> Walk for a moment, climb up the cliff overlooking the site and discover the desert...
<G-vec00109-002-s391><climb.klettern><de> Klettere auf die Klippe hinauf und entdecke die Wüste.
<G-vec00109-002-s392><climb.klettern><en> I climb and climb but never get the view.
<G-vec00109-002-s392><climb.klettern><de> Ich klettere und klettere und bekomme trotzdem keinen Durchblick.
<G-vec00109-002-s394><climb.klettern><en> I climb up in the cool freshness of the morning through heather and brushwood, past flocks of sheep, till I reach the stony core of the peak, and after a stiff ascent, its summit.
<G-vec00109-002-s394><climb.klettern><de> Ich klettere oben in der kühlen Frische des Morgens durch Heidekraut und Reisig, hinter Mengen der Schafe, bis ich den steinigen Kern der Spitze erreiche, und nach einem steifen Aufstieg, sein Gipfel.
<G-vec00109-002-s395><climb.klettern><en> So climb the gain access to ladder, band in and also prepare to recreate your very own terrific scenes from Star Wars: The Pressure Awakens!
<G-vec00109-002-s395><climb.klettern><de> Klettere also die Leiter zum Cockpit hinauf, schnall dich an und bereite dich darauf vor, deine eigenen tollen Lieblingsszenen aus Star Wars: Das Erwachen der Macht nachzustellen.
<G-vec00109-002-s396><climb.klettern><en> I come here every day now, make new friends, play, do handicrafts, climb and just have loads of fun.
<G-vec00109-002-s396><climb.klettern><de> Jeden Tag komme ich jetzt hierher, lerne neue Freunde kennen, spiele, bastle, klettere und habe einfach nur Spaß.
<G-vec00109-002-s397><climb.klettern><en> You can leave a ship, climb down a ladder, walk over the dock of a large space station into another ship you may have parked there and replace the pilot that was working for you just by clicking on his chair.
<G-vec00109-002-s397><climb.klettern><de> Verlasse einfach dein Schiff, klettere eine Leiter herunter und gehe über die Andockbucht einer großen Raumstation zu einem anderen Schiff, das du dort geparkt hast.
<G-vec00109-002-s398><climb.klettern><en> Help little caterpillar to climb up an enchanted beanstalk to find magic beans.
<G-vec00109-002-s398><climb.klettern><de> Klettere mit der kleinen Raupe die Bohnenranke hoch, um Zauberbohnen zu finden.
<G-vec00109-002-s399><climb.klettern><en> Climb in the second subway train you come to.
<G-vec00109-002-s399><climb.klettern><de> Klettere in die zweite Untergrundbahn die du erreichst.
<G-vec00109-002-s400><climb.klettern><en> Climb down 3D mountains, and slide across icy terrain.
<G-vec00109-002-s400><climb.klettern><de> Klettere 3D Berge hinab und rutsche über eisiges Terrain.
<G-vec00109-002-s401><climb.klettern><en> Run, climb, and glide your way through a dark Nordic forest and explore its living, breathing ecosystem filled with secrets and mystical creatures.
<G-vec00109-002-s401><climb.klettern><de> Renne, klettere und gleite durch einen düsteren nordischen Wald und erkunde seine pulsierende, lebendige Welt voller Geheimnisse, Legenden und mystischer Kreaturen.
<G-vec00109-002-s402><climb.klettern><en> So I climb, armed with binoculars and GoPro camera on the mast, backed up by Jens.
<G-vec00109-002-s402><climb.klettern><de> So klettere ich bewaffnet mit Fernglas und GoPro Kamera am Mast des Grossbaumes hoch, gesichert von Jens.
<G-vec00109-002-s403><climb.klettern><en> Now climb up to the ridge, shimmy right and on to the platform that sticks out of his lower back.
<G-vec00109-002-s403><climb.klettern><de> Das ist deine Chance, nutze diese und klettere nun an seinem Rücken hoch bis auf seine Schultern.
<G-vec00109-002-s404><climb.klettern><en> Grab weapons from the store, load the shooters, climb the access ladder into the cockpit and launch into space.
<G-vec00109-002-s404><climb.klettern><de> Hol dir deine Ausrüstung aus der Ausrüstungskammer, lade die Shooter, klettere die Zustiegsleiter hinauf ins Cockpit und flieg ins Weltall.
<G-vec00109-002-s415><climb.klettern><en> I recently found out that I can climb on the entertainment stand and hit the TV.
<G-vec00109-002-s415><climb.klettern><de> Ich fand vor kurzem heraus, dass ich auf dem Unterhaltungsstand klettern und das Fernsehen schlagen kann.
<G-vec00109-002-s416><climb.klettern><en> Couple of big rocks which come in your way and you have to climb and get to the other side to continue.
<G-vec00109-002-s416><climb.klettern><de> Ein paar große Felsen, die sich Ihnen in den Weg stellen, und Sie müssen auf die andere Seite klettern, um fortzufahren.
<G-vec00109-002-s417><climb.klettern><en> The first cats to be yes were forest animals and from the time also our domestic cats nor the ability to climb well.
<G-vec00109-002-s417><climb.klettern><de> Die ersten Katzen sollen ja Waldtiere gewesen sein und aus der Zeit haben auch unsere Hauskatzen noch die Fähigkeit, gut zu klettern.
<G-vec00109-002-s418><climb.klettern><en> However, you can only reach it if you are prepared to climb down 180 steep steps – and up again at the end – which in the desert-like climate of Uluwatu might cost you a few liters of sweat.
<G-vec00109-002-s418><climb.klettern><de> Diesen erreichst du allerdings nur, wenn du bereit bist, 180 steile Stufen runter – und am Ende wieder rauf – zu klettern, was in dem wüstenartigen Klima von Uluwatu auch gerne mal ein paar Literchen Schweiß kosten kann.
<G-vec00109-002-s419><climb.klettern><en> into some caving gear and get ready to crawl and climb around Budapest's famous caves for 2,5 hours with a guide.
<G-vec00109-002-s419><climb.klettern><de> Kriechen und klettern Sie 2,5 Stunden lang in Budapests berühmte Höhlen mit einem Führer.
<G-vec00109-002-s420><climb.klettern><en> Or climb into the pocket of his father's jacket for a mobile phone...
<G-vec00109-002-s420><climb.klettern><de> Oder für ein Handy in die Jackentasche seines Vaters klettern...
<G-vec00109-002-s421><climb.klettern><en> At airport perimeters, PTZ cameras capture persons approaching or attempting to climb the fences at any time of the day or night.
<G-vec00109-002-s421><climb.klettern><de> Zusätzlich erfassen PTZ Kameras jederzeit Personen, die sich Zäunen nähern oder versuchen, über Zäune zu klettern.
<G-vec00109-002-s422><climb.klettern><en> Children are born with an innate need to climb, jump, swing, balance, play ball or just to move about and not be able to sit still.
<G-vec00109-002-s422><climb.klettern><de> Das Bedürfnis zu klettern, zu springen, zu schwingen, zu balancieren, mit Bällen zu spielen oder auch nicht still sitzen zu können wird Kindern mit in die Wiege gelegt.
<G-vec00109-002-s423><climb.klettern><en> In the cave one can partly walk standing straight up, but often one has to crawl or climb through narrow passages. Visitors must not suffer from claustrophobia and be in quite good physical shape.
<G-vec00109-002-s423><climb.klettern><de> Zum Teil kann man in den Gängen aufrecht gehen, manchmal muss man aber auch durch enge Passagen kriechen oder klettern – Besucher sollten also keine Platzangst haben und eine gewisse Fitness mitbringen.
<G-vec00109-002-s424><climb.klettern><en> 65 elements and stations, with 12 Flying Foxes on a total of 850 metres length require you to climb, balance, slide and swing across a wide range of high ropes garden
<G-vec00109-002-s424><climb.klettern><de> 65 Elemente und Stationen mit 12 Flying Fox auf insgesamt 850m Länge erfordern ein Klettern, Balancieren, Rutschen und Hanteln über die unterschiedlichsten Seil- und Brückenkonstruktionen.
<G-vec00109-002-s425><climb.klettern><en> In the Piratenrestaurant children do not have to sit still on the table. They can climb, slide, and jump as much as they want.
<G-vec00109-002-s425><climb.klettern><de> Im Piratenrestaurant müssen die Kinder nicht still am Tisch sitzen, sondern können Klettern, Rutschen, Krabbeln, Springen und Hüpfen was das Zeug hält.
<G-vec00109-002-s426><climb.klettern><en> In some places the bush is so dense, that, as with this picture, one has to climb trees to get a view.
<G-vec00109-002-s426><climb.klettern><de> Oft ist er so dicht, dass man, so wie für dieses Foto, auf Bäume klettern muss um eine Aussicht zu haben.
<G-vec00109-002-s427><climb.klettern><en> The hero can climb vertical walls, clip along the ceillings, and shoou in all directions like the Rendering Ranger.
<G-vec00109-002-s427><climb.klettern><de> Die Spielfigur kann an Wänden klettern, und sich an der Decke entlanghangeln, und wie mit dem Rundumschuss von Turrican, nur mit den normalen Waffen, in alle Richtungen ballern.
<G-vec00109-002-s428><climb.klettern><en> Inning accordance with Lung.org, it is approximated that more compared to four hundred thousand (400,000+) individuals are living with lung cancer and also this number is expected to climb substantially.
<G-vec00109-002-s428><climb.klettern><de> Inning nach Lung.org wird angenähert, dass mehr im Vergleich zu vierhunderttausend (400.000+) Personen mit Lungenkrebs leben und auch diese Zahl wird voraussichtlich im Wesentlichen klettern.
<G-vec00109-002-s429><climb.klettern><en> Anyone who wants to go climb, be hedged.
<G-vec00109-002-s429><climb.klettern><de> Jeder der klettern geht, möchte auch abgesichert sein.
<G-vec00109-002-s430><climb.klettern><en> For, it is primarily women who take care of children and elderly or ill relatives at home while their full-time employed colleagues continue to climb up the career ladder.
<G-vec00109-002-s430><climb.klettern><de> Denn während vor allem Frauen Kinder betreuen und ältere oder kranke Verwandte zu Hause pflegen, klettern die Kollegen/-innen in Vollzeit inzwischen die Karriereleiter nach oben.
<G-vec00109-002-s431><climb.klettern><en> The Salta ladder is an ideal accessory to allow your children to climb safely on and off the trampoline.
<G-vec00109-002-s431><climb.klettern><de> Die Leiter für die Salta – Trampoline ist ein ideales Zubehör damit Ihre Kinder sicher auf das Trampolin klettern können.
<G-vec00109-002-s432><climb.klettern><en> Zwerger, from Bolzano, was unlucky in the final route when a lump of ice in which she had tried to secure her ice pick came loose during her climb.
<G-vec00109-002-s432><climb.klettern><de> Die Boznerin hatte auf der Finalroute Pech, denn beim Klettern löste sich ein Eisbrocken, in dem sie mit ihrem Pickel Halt gesucht hatte.
<G-vec00109-002-s434><climb.klettern><en> 2.4 km to Sydney Harbour Bridge Climb (Show map) Melrose Apartments Haymarket apartment is located around 1100 meters away from Darling Harbour and 1050 meters from Burwood Road.
<G-vec00109-002-s434><climb.klettern><de> 2.4 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Mit einem Hallenbad ausgerüstet, liegt das Apartment Myhoyoho Apartments Haymarket neben Rathaus Sydney.
<G-vec00109-002-s435><climb.klettern><en> 2.9 km to Sydney Harbour Bridge Climb (Show map) Excelsior Serviced apartment provides guests with a sun terrace, a designated area for smoking and an elevator.
<G-vec00109-002-s435><climb.klettern><de> 2.9 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) 20 Fußminuten vom Zentrum von Sydney gelegen, verfügt das Apartment Excelsior Serviced über eine Sonnenterrasse, eine ausgewiesene Raucherzone und einen Aufzug.
<G-vec00109-002-s436><climb.klettern><en> 2 km to Sydney Harbour Bridge Climb (Show map) Woolbrokers Hotel Darling Harbour is placed in the centre of Sydney and offers a courtyard and a shared lounge.
<G-vec00109-002-s436><climb.klettern><de> 2 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Woolbrokers Hotel Darling Harbour ist eine 2-Sterne Unterkunft, die mit einem Gepäckraum, einem Warenautomat und einem Kiosk eingerichtet ist.
<G-vec00109-002-s437><climb.klettern><en> 1.3 km to Sydney Harbour Bridge Climb (Show map) The elegant Vibe Hotel North Sydney is placed just a 5-minute walk to the beachfront.
<G-vec00109-002-s437><climb.klettern><de> 1.3 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Vibe Hotel North Sydney ist ein 4-Sterne Hotel, das einen tollen Blick auf die Lavender Bucht bietet.
<G-vec00109-002-s438><climb.klettern><en> 2.4 km to Sydney Harbour Bridge Climb (Show map) Conveniently located by Wynyard underground station, Apx World Square Aparthotel features a designated smoking area, a safety deposit box and an elevator.
<G-vec00109-002-s438><climb.klettern><de> 2.4 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Das 4-Sterne Aparthotel Apx World Square im Stadtteil Sydney Stadtzentrum CBD bietet seinen Gästen einen Nachtclub, ein Hallenbad und einen Golfplatz.
<G-vec00109-002-s439><climb.klettern><en> 2.3 km to Sydney Harbour Bridge Climb (Show map) Offering a tennis court and a golf course, Macleay Street apartment is situated in Sydney.
<G-vec00109-002-s439><climb.klettern><de> 2.3 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Mit einem Tennisplatz und einem Golfplatz ausgestattet, befindet sich das Apartment Macleay Street in Sydney.
<G-vec00109-002-s440><climb.klettern><en> Climb the Sydney Harbour Bridge with BridgeClimb Sydney and learn to surf with Lets Go Surfing at famous Bondi Beach.
<G-vec00109-002-s440><climb.klettern><de> Klettern Sie mit BridgeClimb Sydney auf die Sydney Harbour Bridge und lernen Sie bei Lets Go Surfing am berühmten Bondi Beach surfen.
<G-vec00109-002-s441><climb.klettern><en> You can climb the himlabadet tower and throw yourself down three different water slides, swim against or with the current in the circular pool, climb the climbing wall or try the water piste – a steep course with water spraying towards the middle.
<G-vec00109-002-s441><climb.klettern><de> Klettern Sie auf den Turm von Himlabad und rutschen Sie die drei Wasserrutschen hinunter, schwimmen Sie mit oder gegen die Strömung im kreisförmigen Pool, besteigen Sie die Kletterwand und wagen Sie sich auf die Wasserpiste- eine steile Bahn mit Wasser, das in die Mitte gespritzt wird.
<G-vec00109-002-s442><climb.klettern><en> 2.8 km to Sydney Harbour Bridge Climb (Show map) Situated in Mosman district, Raglan Street apartment offers accommodation with views of the sea.
<G-vec00109-002-s442><climb.klettern><de> 2.8 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Im Stadtteil Mosman von Sydney gelegen, ist das Apartment Raglan Street 15 km vom Flughafen Sydney.
<G-vec00109-002-s443><climb.klettern><en> In April 2015 I was able to climb like before on Kalymnos.
<G-vec00109-002-s443><climb.klettern><de> Und zum ersten Mal wieder richtig mit Vollgas Klettern konnte ich dann im April 2015 auf Kalymnos.
<G-vec00109-002-s444><climb.klettern><en> 2.2 km to Sydney Harbour Bridge Climb (Show map) Paxsafe Sydney Hyde Park Apt 909 apartment can host up to 4 guests providing them with a sauna and a lift.
<G-vec00109-002-s444><climb.klettern><de> 2.2 km zu Klettern auf der Sydney Harbour Bridge (Karte anzeigen) Das Apartment Paxsafe Sydney Hyde Park Apt 909 stellt einen komfortablen Aufenthalt in Sydney bereit.
<G-vec00109-002-s445><climb.klettern><en> If your cat likes to climb, consider building a tall cat tree with several perches.
<G-vec00109-002-s445><climb.klettern><de> Wenn sie gerne klettert, könntest du ihr einen hohen Baum mit vielen hohen Ebenen bauen.
<G-vec00109-002-s446><climb.klettern><en> Climb over the white box up to the ledge above.
<G-vec00109-002-s446><climb.klettern><de> Klettert über den weißen Kasten auf den Lüftungsschacht.
<G-vec00109-002-s447><climb.klettern><en> Climb around the corner to the left till Lara places her feet against the wall.
<G-vec00109-002-s447><climb.klettern><de> Klettert nach links um die Ecke bis Lara die Füße an die Wand stellt.
<G-vec00109-002-s448><climb.klettern><en> Drop back to the ground and then climb onto the hut again.
<G-vec00109-002-s448><climb.klettern><de> Lasst euch wieder zu Boden fallen und klettert erneut auf die Hütte.
<G-vec00109-002-s449><climb.klettern><en> On iron rides you climb high above the abyss towards the summit.
<G-vec00109-002-s449><climb.klettern><de> An Eisentritten klettert man hoch über dem Abgrund dem Gipfel entgegen.
<G-vec00109-002-s450><climb.klettern><en> Dive up into the chamber and climb out.
<G-vec00109-002-s450><climb.klettern><de> Taucht in der Kammer auf und klettert hinaus.
<G-vec00109-002-s451><climb.klettern><en> Dive up and climb out of the water.
<G-vec00109-002-s451><climb.klettern><de> Taucht dort nach oben und klettert aus dem Wasser.
<G-vec00109-002-s452><climb.klettern><en> Run down the stairs and climb over the crates.
<G-vec00109-002-s452><climb.klettern><de> Lauft nach unten und klettert über die Kisten.
<G-vec00109-002-s453><climb.klettern><en> Climb into the passage hidden behind.
<G-vec00109-002-s453><climb.klettern><de> Klettert in den dahinter versteckten Gang.
<G-vec00109-002-s454><climb.klettern><en> At the first stage, all participants rush to the mountain, who will climb first - that is the "king of the mountain".
<G-vec00109-002-s454><climb.klettern><de> In der ersten Etappe eilen alle Teilnehmer zum Berg, der zuerst klettert - das ist der "König des Berges".
<G-vec00109-002-s455><climb.klettern><en> Then climb up the ladder you find on the next floor.
<G-vec00109-002-s455><climb.klettern><de> Rennt an den Schwarzen Rittern vorbei und klettert dann die Leiter hoch.
<G-vec00109-002-s456><climb.klettern><en> Climb down the ladder.
<G-vec00109-002-s456><climb.klettern><de> Klettert die Leiter nach unten.
<G-vec00109-002-s457><climb.klettern><en> Climb onto the pillar underneath the slide.
<G-vec00109-002-s457><climb.klettern><de> Klettert auf den Pfeiler unter der Rutsche.
<G-vec00109-002-s458><climb.klettern><en> The more points you get, the higher you climb in the leader board.
<G-vec00109-002-s458><climb.klettern><de> Je mehr Punkte ihr bekommt, desto höher klettert ihr in der Rangliste.
<G-vec00109-002-s459><climb.klettern><en> Climb walls and more.
<G-vec00109-002-s459><climb.klettern><de> Klettert Wände und vieles mehr.
<G-vec00109-002-s460><climb.klettern><en> Climb up the small ladder.
<G-vec00109-002-s460><climb.klettern><de> Klettert die Leiter nach oben.
<G-vec00109-002-s461><climb.klettern><en> Turn around and climb up into the gap.
<G-vec00109-002-s461><climb.klettern><de> (Bild) Dreht euch um und klettert in den Spalt hoch.
<G-vec00109-002-s462><climb.klettern><en> But it can also cost quite a lot of skin, if you climb in cold temperatures (then the skin is brittle) or if you don’t master the technique very well (then you slide down faster).
<G-vec00109-002-s462><climb.klettern><de> Es kann aber auch einiges an Haut kosten, wenn man bei kalten Temperaturen klettert (dann ist die Haut spröde) oder die Technik nicht sauber beherrscht (dann rutscht man schneller ab).
<G-vec00109-002-s463><climb.klettern><en> Return to the ladder and climb back down. Take a running jump back to the other side.
<G-vec00109-002-s463><climb.klettern><de> Kehrt zur Leiter zurück und klettert wieder hinunter.Springt nun mit Anlauf wieder zurück auf die andere Seite.
<G-vec00109-002-s464><climb.klettern><en> There run into the right corner and climb through the opening.
<G-vec00109-002-s464><climb.klettern><de> Lauft dort in die rechte Ecke und klettert in die Öffnung hinauf.
<G-vec00109-002-s465><climb.klettern><en> Climb up the rope.
<G-vec00109-002-s465><climb.klettern><de> Klettert noch eine Kante hinauf.
<G-vec00109-002-s466><climb.klettern><en> Push the crate towards the platform next to the entrance. Climb up onto it.
<G-vec00109-002-s466><climb.klettern><de> Schiebt die Kiste zu der erhöhten Plattform neben dem Eingang und klettert hinauf.
<G-vec00109-002-s467><climb.klettern><en> Climb up and lower yourself to the place where the crate stood before.
<G-vec00109-002-s467><climb.klettern><de> Klettert hinauf und lasst euch auf der anderen Seite auf den Vorsprung wo die Kiste war, hinab.
<G-vec00109-002-s468><climb.klettern><en> Visitors can enjoy unforgettable sunrises and the sporty ones, can climb up on the dunes and enjoy a huge view that appears almost unreal.
<G-vec00109-002-s468><climb.klettern><de> Besucher können hier unvergessliche Sonnenaufgänge erleben und wer sportlich ist, klettert auf eine der Dünen hinauf und genießt einen gigantischen Blick, der einem fast unwirklich erscheinen kann.
<G-vec00109-002-s469><climb.klettern><en> Climb up into the opening in the wall.
<G-vec00109-002-s469><climb.klettern><de> Klettert in die Wandöffnung hinauf.
<G-vec00109-002-s470><climb.klettern><en> Climb up onto the red part.
<G-vec00109-002-s470><climb.klettern><de> Klettert auf den roten Teil hinauf.
<G-vec00109-002-s471><climb.klettern><en> Climb up and go to the other side.
<G-vec00109-002-s471><climb.klettern><de> Klettert hinauf und geht an die nächste Kante.
<G-vec00109-002-s472><climb.klettern><en> But ignore this for now and instead enter the passage and climb up.
<G-vec00109-002-s472><climb.klettern><de> Lauft aber in den Gang und klettert hinauf.
<G-vec00109-002-s473><climb.klettern><en> Climb up, onto the platform.
<G-vec00109-002-s473><climb.klettern><de> Klettert auf die Plattform hinauf.
<G-vec00109-002-s474><climb.klettern><en> Run back to the other end. On the left side you can climb back up to where the skeleton was.
<G-vec00109-002-s474><climb.klettern><de> Klettert dort am rechten Block hinauf und zurück zu dem Skelett des glücklosen Abenteurers.
<G-vec00109-002-s475><climb.klettern><en> This green, beautiful plant has a questionable personality when in the wild chooses to climb the nearby trees to reach the sunlight.
<G-vec00109-002-s475><climb.klettern><de> Diese grüne, schöne Pflanze hat eine fragwürdige Persönlichkeit, denn in freier Wildbahn klettert Sie die Bäume in ihrer Umgebung hinauf, um das Sonnenlicht zu erreichen.
<G-vec00109-002-s476><climb.klettern><en> Climb up, towards D. Now use the crank here to operate the winch.
<G-vec00109-002-s476><climb.klettern><de> Klettert hinauf, in Richtung der Seilwinde (D).
<G-vec00109-002-s477><climb.klettern><en> Climb onto it and pull up on the ledge ahead.
<G-vec00109-002-s477><climb.klettern><de> Klettert hinauf und lauft an der hinteren Wand hoch.
<G-vec00109-002-s478><climb.klettern><en> Run to the flag pole to the right of the main building, near the parked car, climb up.
<G-vec00109-002-s478><climb.klettern><de> Lauft dann zu der Fahnenstange rechts von der Kirche, vor dem geparkten Wagen, und klettert hinauf.
<G-vec00109-002-s479><climb.klettern><en> Jump onto the pillar and climb up.
<G-vec00109-002-s479><climb.klettern><de> Springt an den Pfeiler und klettert hinauf.
<G-vec00109-002-s480><climb.klettern><en> Jump towards the platform underneath the ladder and then climb the ladder to the top.
<G-vec00109-002-s480><climb.klettern><de> Springt zur Plattform unter der Leiter und klettert die Leiter nach oben hinauf.
<G-vec00109-002-s518><climb.steigen><en> When you exercise, serotonin levels climb, enhancing your perception of tiredness.
<G-vec00109-002-s518><climb.steigen><de> Wenn Sie trainieren, Serotonin-Spiegel steigen, Ihre Wahrnehmung von Müdigkeit zu verbessern.
<G-vec00109-002-s519><climb.steigen><en> Whoever searches or finds the sculpture can climb behind it and whisper, scream, proclaim or improvise love poems through this hole, anything is open to him.
<G-vec00109-002-s519><climb.steigen><de> Wer die Plastik aufsucht oder findet, kann dahinter steigen und durch das Loch flüstern, brüllen, proklamieren oder liebesdichten, das bleibt offen.
<G-vec00109-002-s520><climb.steigen><en> The reason is simple: AI-leader estimated the time it would take him to climb that high and realized that he would reach the necessary altitude too late, and the recon would escape to his home sector.
<G-vec00109-002-s520><climb.steigen><de> Der Grund dafür ist einfach: KI-Kommandanten schätzen die Zeit, die es brauchen würde, um ihn auf diese Flughöhe steigen zu lassen und merkt, dass er die benötigte Höhe erst zu spät erreicht und das Aufklärungsflugzeug schon in Richtung Heimsektor ihm entkommen ist.
<G-vec00109-002-s521><climb.steigen><en> Be sure to climb up to the top of the historic lighthouse and you'll be rewarded with an exceptionally beautiful view.
<G-vec00109-002-s521><climb.steigen><de> Steigen Sie auch auf den historischen Leuchtturm, um einen atemberaubenden Blick auf die Landschaft zu erhaschen.
<G-vec00109-002-s522><climb.steigen><en> The center of Tübingen can be reached on foot if you are ready to make some stairs to climb.
<G-vec00109-002-s522><climb.steigen><de> Das Stadtzentrum von Tübingen kann man gut zu Fuß erreichen, wenn man bereit ist, einige Treppen zu steigen.
<G-vec00109-002-s523><climb.steigen><en> Just load a project from the server, climb inside your submarine (or another means of transport without Wi-Fi), and beaver away on your project.
<G-vec00109-002-s523><climb.steigen><de> Das heißt auch hier laden Sie ein Projekt vom Server, steigen in ein U-Boot (oder in ein anderes Transportmittel ohne WLAN-Versorgung) und arbeiten fleissig am Projekt.
<G-vec00109-002-s524><climb.steigen><en> We didn't have to climb any stairs and it was very quiet even though we were on the street level.
<G-vec00109-002-s524><climb.steigen><de> Wir mussten Treppen steigen, und es war sehr ruhig, obwohl wir auf der Straßenebene waren.
<G-vec00109-002-s525><climb.steigen><en> After a few metres, leave the road and climb up on the right.
<G-vec00109-002-s525><climb.steigen><de> Nach wenigen Metern verlassen Sie die Straße und steigen auf der rechten Seite.
<G-vec00109-002-s526><climb.steigen><en> Climb the stairs in the city park. vídeos
<G-vec00109-002-s526><climb.steigen><de> Steigen Sie die Treppe im Stadtpark..
<G-vec00109-002-s527><climb.steigen><en> The life expectation is supposed to climb to more than a hundred years, even without any unpleasant side-effects such as dementia or the like.
<G-vec00109-002-s527><climb.steigen><de> Das Lebensalter soll weiter auf über 100 Jahre steigen und dies ohne lästige Begleiterscheinungen wie Altersverwirrtheit oder Ähnliches.
<G-vec00109-002-s528><climb.steigen><en> We climb up until we reach the alpine hut Alpe Hochried.
<G-vec00109-002-s528><climb.steigen><de> Wir steigen hinauf zur Alpe Hochried.
<G-vec00109-002-s529><climb.steigen><en> Despite a strictest ban many people try to climb the building, because of the imminent dilapidation a not entirely harmless venture.
<G-vec00109-002-s529><climb.steigen><de> Trotz eines strengsten Verbotes versuchen viele Personen auf das Gebäude zu steigen, wegen der drohenden Baufälligkeit ein nicht ganz ungefährliches Unterfangen.
<G-vec00109-002-s530><climb.steigen><en> Inning accordance with Lung.org, it is estimated that greater than four hundred thousand (400,000+) people are dealing with lung cancer and this number is anticipated to climb drastically.
<G-vec00109-002-s530><climb.steigen><de> Inning nach Lung.org, es wird geschätzt, dass mehr als vierhunderttausend (400.000+) Menschen beschäftigen sich mit Lungenkrebs und diese Zahl wird voraussichtlich drastisch steigen.
<G-vec00109-002-s531><climb.steigen><en> The astronauts climb into the capsule.
<G-vec00109-002-s531><climb.steigen><de> Die Astronauten steigen in die Kapsel.
<G-vec00109-002-s532><climb.steigen><en> Five km before the summit of the Col de la Croix de Fer I let my two helpers know that I couldn’t go on and that I would climb off my bike at the top.
<G-vec00109-002-s532><climb.steigen><de> Fünf Kilometer vor der Spitze des Col de la Croix de Fer habe ich meinen zwei Helfern signalisiert, dass es nicht mehr weitergeht und ich oben vom Rad steigen werde.
<G-vec00109-002-s533><climb.steigen><en> These measures are coming alongside projections that prices in the US will climb faster at the second half of 2018.
<G-vec00109-002-s533><climb.steigen><de> Diese Maßnahmen gehen mit Prognosen einher, die darauf hindeuten, dass die Preise in den USA im zweiten Halbjahr 2018 schneller steigen werden.
<G-vec00109-002-s534><climb.steigen><en> With crampons we can now climb towards the summit in a leisurely rhythm.
<G-vec00109-002-s534><climb.steigen><de> Mit Steigeisen können wir nun im gemächlichen Rhythmus dem Gipfel entgegen steigen.
<G-vec00109-002-s535><climb.steigen><en> Climb into the whirlpool with your sweetheart; enjoy the soothing warmth of the infrared cabin and cuddle up together in the four-poster bed.
<G-vec00109-002-s535><climb.steigen><de> Steigen Sie mit Ihrem Schatz in den Whirlpool, genießen Sie die wohltuende Wärme der Infrarotkabine und kuscheln Sie sich ins Himmelbett.
<G-vec00109-002-s536><climb.steigen><en> When both seats are converted into beds there is not too much space, but enough to climb over the corridor seat (which worked out fine in a test).
<G-vec00109-002-s536><climb.steigen><de> Wenn beide Sitze zu einem Bett umgebaut sind, dann ist auch hier zwischen den Sitzen nicht viel Platz, es reicht aber für den Fenstersitzenden zum drüber steigen, was bei einem kleinen Test gut funktioniert hat.
<G-vec00109-002-s537><climb.steigen><en> Climb Mont Faron (10 km) for a unique view over the city.
<G-vec00109-002-s537><climb.steigen><de> Für einen einzigartigen Ausblick über die Stadt steigen Sie auf den Mont Faron (10 km).
<G-vec00109-002-s538><climb.steigen><en> First there is a climb up to Fellilücke with a view across the Fellital valley, now lying behind the walker, and a further one of the Oberalp pass.
<G-vec00109-002-s538><climb.steigen><de> Zunächst steigen Sie von dort zur Fellilücke auf, wo Sie einen Ausblick sowohl ins dahinterliegende Fellital als auch zurück zum Oberalppass haben.
<G-vec00109-002-s539><climb.steigen><en> Get the scores of UEFA Euro 2016 games right to earn points and climb the league standings.
<G-vec00109-002-s539><climb.steigen><de> Tippen Sie die Ergbnisse Tippen Sie die richtigen Ergbnisse, sammeln Sie Punkte und steigen Sie auf in die Champions League.
<G-vec00109-002-s540><climb.steigen><en> Through the magnificent larch forest you climb another 300 metres and reach the Simplon Pass in the last descending part.
<G-vec00109-002-s540><climb.steigen><de> Durch den prächtigen Lärchenwald steigen Sie dann nochmal 300 Höhenmeter auf, und erreichen im letzten absteigenden Teil den Simplonpass.
<G-vec00109-002-s541><climb.steigen><en> Here you can climb the Arc de Triomphe (Triomfboog) for fantastic views over the city.
<G-vec00109-002-s541><climb.steigen><de> Steigen Sie auf den Arc de Triomphe (Triomfboog) und genießen Sie den herrlichen Blick über die Stadt.
<G-vec00109-002-s542><climb.steigen><en> From the Vatican, climb the Gianicolo hill between the Vatican and the Trastevere neighborhood.
<G-vec00109-002-s542><climb.steigen><de> Steigen Sie vom Vatikan aus auf den Janiculum-Hügel (Gianicolo) zwischen dem Vatikan und dem Trastevere Viertel.
<G-vec00109-002-s543><climb.steigen><en> Get the scores of Europa League games right to earn points and climb the league standings.
<G-vec00109-002-s543><climb.steigen><de> Tippen Sie die Ergbnisse Tippen Sie die richtigen Ergbnisse, sammeln Sie Punkte und steigen Sie auf in die FA Cup.
<G-vec00109-002-s545><climb.steigen><en> With Peter, James and John we too climb the Mount of the Transfiguration today and stop in contemplation of the face of Jesus to retrieve the message and translate it into our lives; for we too can be transfigured by Love.
<G-vec00109-002-s545><climb.steigen><de> Mit Petrus, Jakobus und Johannes steigen heute auch wir auf den Berg der Verklärung und verweilen in der Betrachtung des Antlitzes Jesu, um dessen Botschaft aufzunehmen und sie in unserem Leben umzusetzen; denn auch wir können von der Liebe verwandelt werden.
<G-vec00109-002-s546><climb.steigen><en> Day 7: We pass through the small settlement of Huayhuash where a few farming families live and then climb to yet another pass Portachuelo de Huayhuash 4750m.
<G-vec00109-002-s546><climb.steigen><de> Tag 7: Wir durchqueren die kleine Siedlung Huayhuash, wo nur wenige Bauernfamilien leben und steigen dann zu einem weiteren Pass hinauf, dem Portachuelo de Huayhuash auf 4750m.
<G-vec00109-002-s547><climb.steigen><en> Once you finish gaping at the stunning marble exterior of this leaning icon, climb inside the bell tower.
<G-vec00109-002-s547><climb.steigen><de> Sobald Sie die atemberaubende marmorne Außenseite dieser schiefen Ikone genug bewundert haben, steigen Sie hinauf in den Glockenturm.
<G-vec00109-002-s548><climb.steigen><en> Climb up to the old town centre in Buje and watch the sunset from the stone walls together with the locals.
<G-vec00109-002-s548><climb.steigen><de> Blick vom Glockenturm in Buje Sollten Sie in Buje vorbeikommen, steigen Sie die alten gepflasterten, engen Gassen bis zur Altstadt auf den Hügel hinauf.
<G-vec00109-002-s549><climb.steigen><en> After several bends, you will climb up to the weather cross at the Limo Pass, pass the Limo Lake hidden under ice and snow, and soon will reach the secluded, enchanting basin of Großfanes, the end point of the tour.
<G-vec00109-002-s549><climb.steigen><de> Sie meistern mehrere Kehren und steigen zum Wetterkreuz am Limojoch hinauf, passieren den unter Eis und Schnee verborgenen Limosee und befinden sich schon bald in dem einsamen, stimmungsvollen Kessel von Großfanes, dem Endpunkt der Tour.
<G-vec00109-002-s550><climb.steigen><en> Climb the steps to the Castle and discover its towers, walls and of course, its Archaeological Museum.
<G-vec00109-002-s550><climb.steigen><de> Steigen Sie auf die Burg hinauf und entdecken Sie ihre Türme, Mauern und selbstverständlich das archäologische Museum.
<G-vec00109-002-s551><climb.steigen><en> For an amazing view of Paris, climb the 700 steps of the Eiffel Tower.
<G-vec00109-002-s551><climb.steigen><de> Steigen Sie die 700 Stufen des Eiffelturms hinauf, um einen atemberaubenden Ausblick auf Paris zu genießen.
<G-vec00109-002-s552><climb.steigen><en> After that, climb the Netherlands tallest bell tower, ascending 465 steps to the top of the Dom Tower and enjoy the spectacular view.
<G-vec00109-002-s552><climb.steigen><de> Steigen Sie die 465 Stufen in den höchsten Kirchturm der Niederlande hinauf, und genießen Sie die spektakuläre Aussicht.
<G-vec00109-002-s553><climb.steigen><en> Visitors, accompanied by a volunteer tour guide, climb to the viewing platform which is 67 meters above the ground.
<G-vec00109-002-s553><climb.steigen><de> Begleitet von einem ehrenamtlichen Kirchenführer steigen die Besucher hinauf bis zur Aussichtsplattform in 67 m Höhe.
<G-vec00109-002-s554><climb.steigen><en> Climb the steps of Beverley Minster to the roofline for a unique perspective on this fascinating building, held by many as a gothic masterpiece.
<G-vec00109-002-s554><climb.steigen><de> Steigen Sie die Stufen des Beverley Minster hinauf zum Dach und genießen Sie die einzigartige Perspektive auf diesem faszinierenden gotischen Gebäude.
<G-vec00109-002-s555><climb.steigen><en> In the high design height, the driver can comfortably climb into the MAN cab using the four steps.
<G-vec00109-002-s555><climb.steigen><de> In die MAN-Kabine steigt der Fahrer bei der hohen Fahrzeugbauart bequem über vier Stufen ein.
<G-vec00109-002-s556><climb.steigen><en> Her through a tunnel, turns left on the balcony and climb the stairs down to the lowest floor to the bottom.
<G-vec00109-002-s556><climb.steigen><de> Ihr durchquert einen Tunnel, biegt auf dem Balkon links ab und steigt die Treppen bis ins unterste Geschoss nach unten.
<G-vec00109-002-s557><climb.steigen><en> Description From Rifugio Graffer (2263 m) you climb up in 35 minutes to Passo del Grostè (2442 m) and from here you follow the path SAT 301 that in 1:10 hours descends to Malga Spora passing by Rifugio Graffer m.
<G-vec00109-002-s557><climb.steigen><de> Streckebeschreibung Vom Rifugio Graffer (m. 2263) steigt man in 35 Minuten bis Passo del Grostè (m. 2442) und geht man weiter auf dem SAT-Weg 301 durch Sella del Turrion und bergauf in 1,10 Stunde bis Passo della Gaiarda (m. 2242).
<G-vec00109-002-s558><climb.steigen><en> Humps, bites and does not climb and is overall, except for the typical mare-zickerein during the horses, a completely balanced and calm lady.
<G-vec00109-002-s558><climb.steigen><de> Buckelt, beißt und steigt nicht und ist insgesamt, bis auf die typischen Stutenzickerein während der Rosse, eine ganz ausgeglichene und ruhige Lady.
<G-vec00109-002-s559><climb.steigen><en> From here, the trail continues to climb toward your destination, the Upper Schönalmsee (2,115 m).
<G-vec00109-002-s559><climb.steigen><de> Von dort steigt der Weg bis zum Ziel weiter an, dem Oberen Schönalmsee (2.115m).
<G-vec00109-002-s560><climb.steigen><en> Now climb through the windows in the wall ahead.
<G-vec00109-002-s560><climb.steigen><de> Steigt nun durch das Fenster an der Wand voraus.
<G-vec00109-002-s561><climb.steigen><en> Smoking intensity for women in their teens from 1990 to 1994 is projected to climb up to 9.6 years for the East and surpass the Western value, which falls to 9.3 years.
<G-vec00109-002-s561><climb.steigen><de> Der Tabakkonsum der Frauen, die in den Nachwendejahren (1990-94) Teenager waren, steigt im Osten auf 9,6 Jahre und überholt den im Westen, der auf 9,3 Jahre gefallen ist.
<G-vec00109-002-s562><climb.steigen><en> They should learn how to perform activities like jump, kick a ball or climb stairs if they have not already.
<G-vec00109-002-s562><climb.steigen><de> Sie sollten lernen, wie man Sprünge macht, einen Ball tritt oder Treppen steigt, wenn dies noch nicht der Fall ist.
<G-vec00109-002-s563><climb.steigen><en> Near the Golden Roof, you can climb 133 steps skywards above Innsbruck and enjoy a unique view of the city's squares and alleys.
<G-vec00109-002-s563><climb.steigen><de> Gleich neben dem Goldenen Dachl steigt man 133 Stufen in den Himmel über Innsbruck und wird mit einem einzigartigen Ausblick auf Gassen und Plätze belohnt.
<G-vec00109-002-s564><climb.steigen><en> While the airplane continues to climb into the air, its swallowed by a gray cloud curtain by the the end of the runway.
<G-vec00109-002-s564><climb.steigen><de> Behäbig steigt das Flugzeug langsam in den Himmel und verschwindet hinter einem grauen Wolkenvorhang am anderen Ende der Bahn.
<G-vec00109-002-s565><climb.steigen><en> Sweden's lowlands rapidly climb into highlands, so the tsunami will funnel up ravines, reaching as high and as far inland as Lake Vanern.
<G-vec00109-002-s565><climb.steigen><de> Schwedens Tiefland steigt schnell in Hochland, so dass der Tsunami wie durch Trichter Schluchten empor schnellt und so hoch und so weit ins Inland vordringen wird wie der Vänernsee.
<G-vec00109-002-s566><climb.steigen><en> Sales of vitamins, minerals and supplements continue to climb.
<G-vec00109-002-s566><climb.steigen><de> Der Absatz von Vitaminen, Mineralien und Nahrungsergänzungsprodukten steigt weiter.
<G-vec00109-002-s567><climb.steigen><en> After that he’ll climb out of the bath and lie down, accompanied by a lot of grumbling, to fall asleep immediately, producing a deep snore, which makes the whole house vibrate.
<G-vec00109-002-s567><climb.steigen><de> Danach steigt er aus dem Bad und legt sich mit viel Gebrummel hin, um gleich mit einem tiefen, das ganze Haus erschütternden, Schnarchen einzuschlafen.
<G-vec00109-002-s568><climb.steigen><en> There are no doors; you just climb over the side sills decorated with aluminium checker-plate strips and slide into the sports bucket seats.
<G-vec00109-002-s568><climb.steigen><de> Türen gibt es nicht, man steigt einfach über die mit Riffelblech-Aluminiumleisten verzierten Seitenschweller und gleitet in die sportlichen Schalensitze.
<G-vec00109-002-s569><climb.steigen><en> From the Algone Valley (Stenico – Giudicarie Valley) to the Ghedina Refuge and the Malga Nambi. Take path 341b to the right (a short distance further on it joins path 341) and climb up the Sacco Valley past the Dodici Apostoli Pass (2,620 m.) to reach the Dodici Apostoli Refuge.
<G-vec00109-002-s569><climb.steigen><de> Vom Val D’Algone (Stenico-Val Giudicarie) zur Ghedina Hütte und zur Malga Nambi: schlägt man dort rechter Hand Weg 341b ein (der etwas weiter oben mit Weg 341 zusammenläuft), steigt man das Val di Sacco auf, kommt über den Pass XII Apostoli (2620 m) und erreicht die gleichnamige Hütte.
