<G-vec00407-001-s032><attach.befestigen><en> Let's attach the sheet edge to a bottom an adhesive tape or glue.
<G-vec00407-001-s032><attach.befestigen><de> Wir werden den Rand des Blattes am Grund vom Klebeband oder dem Leim befestigen.
<G-vec00407-001-s033><attach.befestigen><en> Further it is necessary only to hide under decorative caps of a junction of threads and to attach a fastener to a ready necklace.
<G-vec00407-001-s033><attach.befestigen><de> Weiter bleibt es nur übrig, unter dekorativ kolpatschkami die Verbindungsstellen der Fäden zu verbergen und, am fertigen Kollier den Verschluss zu befestigen.
<G-vec00407-001-s034><attach.befestigen><en> When the connector is housed in the body, the cable becomes a loop that allows you to attach the power bank to a keychain or other accessories.
<G-vec00407-001-s034><attach.befestigen><de> Wenn der Stecker im Gehäuse untergebracht ist, wird das Kabel zu einer Schlaufe, mit der Sie das Netzteil am Schlüsselbund oder anderen Zubehörteilen befestigen können.
<G-vec00407-001-s035><attach.befestigen><en> With these you can attach this mysterious mask to your head.
<G-vec00407-001-s035><attach.befestigen><de> Mit diesen kannst du diese geheimnisvolle Maske gut am Kopf befestigen.
<G-vec00407-001-s036><attach.befestigen><en> The Basil Magnolia Saddle Cover is available in beautiful teal blue and is easy to attach to the saddle of your bike.
<G-vec00407-001-s036><attach.befestigen><de> Der Basil Magnolia Sattelüberzug ist in der Farbe blau erhältlich und lässt sich einfach am Sattel Ihres Fahrrads befestigen.
<G-vec00407-001-s037><attach.befestigen><en> Take advantage of a convenient and practical way to attach your phone to the car dashboard.
<G-vec00407-001-s037><attach.befestigen><de> Nutzen Sie die praktische und praktische Möglichkeit, Ihr Telefon am Armaturenbrett des Fahrzeugs zu befestigen.
<G-vec00407-001-s038><attach.befestigen><en> Good to know:Both bags are quick and easy to attach and remove again with the Legend Gear SLS Saddle Strap, which can be ordered separately.
<G-vec00407-001-s038><attach.befestigen><de> Gut zu wissen:Beide Taschen lassen sich mit dem separat erhältlichen Legend Gear Satteltaschen-Halter SLS mit wenigen Handgriffen am Motorrad befestigen und abnehmen.
<G-vec00407-001-s039><attach.befestigen><en> Comes complete with scabbard and button to attach to belt.
<G-vec00407-001-s039><attach.befestigen><de> Mit dem Knopf lässt sich das Schwert am Gürtel befestigen.
<G-vec00407-001-s040><attach.befestigen><en> "In particular, for fastening it is possible to use polyurethane foam, glue ""liquid nails"" or ""Dragon"". After material is reliably attached to a door cloth, from above it is possible to attach a piece of the laminated DVP of the corresponding size or to use any obivochny material."
<G-vec00407-001-s040><attach.befestigen><de> "Insbesondere kann man für die Befestigung den Montageschaum, den Leim «die flüssigen Nägel» oder ""der Drache"" verwenden., Nachdem das Material am Türleinen sicher befestigt ist, kann man das Stück laminirowannogo DWP des entsprechenden Umfanges oben befestigen oder, irgendwelchen obiwotschnyj das Material zu verwenden."
<G-vec00407-001-s041><attach.befestigen><en> You also get two stroller clips, so you can easily attach your new favorite bag to the stroller.
<G-vec00407-001-s041><attach.befestigen><de> Außerdem bekommt du noch zwei Kinderwagenclips, damit du deine neue Lieblingstasche ganz einfach am Kinderwagen befestigen kannst.
<G-vec00407-001-s042><attach.befestigen><en> You can either carry the bag with the padded shoulder strap or simply attach it to the i2 frame.
<G-vec00407-001-s042><attach.befestigen><de> Du kannst die Tasche entweder mit dem gepolsterten Schultergurt tragen oder diese auch einfach am Gestell des i2 befestigen.
<G-vec00407-001-s043><attach.befestigen><en> You can easily attach the basket to your handlebars with the Basil KF handlebar holder (sold separately).
<G-vec00407-001-s043><attach.befestigen><de> Auf unserer Webseite findest du den Basil KF Lenkerhalter, mit dem du den Korb einfach am Lenker befestigen kannst.
<G-vec00407-001-s044><attach.befestigen><en> To attach them to each other pins.
<G-vec00407-001-s044><attach.befestigen><de> Ihr Freund am Freund von den Stecknadeln zu befestigen.
<G-vec00407-001-s045><attach.befestigen><en> I sew historic bustle dresses and I was looking for a solution to gather up the top coat, where it is not necessary to attach it to the petticoat.
<G-vec00407-001-s045><attach.befestigen><de> Ich nähe historische Tournüren-Kleider und war auf der Suche nach einer Lösung zum Raffen des Überrocks, bei der es nicht nötig ist, den Überrock am Unterrock zu befestigen.
<G-vec00407-001-s065><attach.befestigen><en> The easiest way of sealing the screen is to attach stencils from papers or foils to it.
<G-vec00407-001-s065><attach.befestigen><de> Die einfachste Methode ist, an der Siebunterseite präparierte Papiere oder Schneidefilme zu befestigen, aus denen das Motiv scherenschnittartig herausgearbeitet wurde.
<G-vec00407-001-s066><attach.befestigen><en> Attach notices or photos quickly and easily to your pinboard or notice board with these pins.
<G-vec00407-001-s066><attach.befestigen><de> An einer Pinnwand oder einem Memoboard genutzt, lassen sich mit den Pins Notizzettel und Fotos schnell und einfach befestigen.
<G-vec00407-001-s067><attach.befestigen><en> Located in the grass or on the supports they attach to any corner of the earth charm.
<G-vec00407-001-s067><attach.befestigen><de> Das Hotel liegt im Gras oder auf den Stützen sie an jeder Ecke der Erde Charme befestigen.
<G-vec00407-001-s068><attach.befestigen><en> Finally, a special cement-based adhesive is used to attach the veneers.
<G-vec00407-001-s068><attach.befestigen><de> Am Ende werden wir mit einem speziellen Klebezement die Veneers an den Zähnen befestigen.
<G-vec00407-001-s069><attach.befestigen><en> Supported by new sensors Attach to the back of the back cover Watch 4 and a processor more powerful, applications dedicated to outdoor activities and sports have been greatly developed.
<G-vec00407-001-s069><attach.befestigen><de> Unterstützt von neue Sensoren An der Rückseite der hinteren Abdeckung befestigen Uhr 4 und ein Prozessor leistungsstärkere Anwendungen, die sich für Outdoor-Aktivitäten und Sportarten einsetzen, wurden stark entwickelt.
<G-vec00407-001-s070><attach.befestigen><en> This LED / LCD / Plasma TV wall bracket is supplied with all necessary materials to easily attach it to the wall.
<G-vec00407-001-s070><attach.befestigen><de> Diese LED / LCD / Plasma TV-Wandhalterung wird mit allen notwendigen Materialien geliefert, um sie einfach an der Wand zu befestigen.
<G-vec00407-001-s071><attach.befestigen><en> The bag is almost ready, it is necessary only to attach to it suitable handles.
<G-vec00407-001-s071><attach.befestigen><de> Die Tasche ist tatsächlich fertig, es bleibt nur übrig, an ihr die herankommenden Griffe zu befestigen.
<G-vec00407-001-s072><attach.befestigen><en> A favourite pastime for many seafaring scientists (worldwide), is to paint styrofoam cups, attach them to their equipment and to send everything to the bottom of the sea.
<G-vec00407-001-s072><attach.befestigen><de> Eine der Lieblingsbeschäftigungen vieler seefahrender Wissenschaftler*innen (weltweit) ist es Styroportrinkbecher zu bemalen, an den Geräten zu befestigen und in die Tiefsee hinab zu lassen.
<G-vec00407-001-s073><attach.befestigen><en> Thanks to the mount as a combination of eye and crook, you can attach the Trammel Hook to a tripod or at a crossbar over your fire cooking place.
<G-vec00407-001-s073><attach.befestigen><de> Dank der praktischen Aufhängung – einer Kombination aus Öse und einer Biegung – kannst du den Kesselhaken sowohl an deinem Dreibein als auch an der Querstange deiner Kochstelle über dem Feuer befestigen.
<G-vec00407-001-s074><attach.befestigen><en> That who hangs up posters or the similar materials, calculated that they can be changed, we recommend to attach to a wall a lath, using screws with shkantami (drawing in the middle on the right see), we bore through in a lath small apertures.
<G-vec00407-001-s074><attach.befestigen><de> Von dem, man wer die Plakate oder die ähnlichen Materialien, die auf berechnet sind hängt, dass sie ständig tauschen kann, wir empfehlen, an der Wand die Leiste zu befestigen, die Schrauben mit schkantami verwendend (siehe die Zeichnung Mitte rechts), durchbohren wir in der Leiste die kleinen Öffnungen.
<G-vec00407-001-s075><attach.befestigen><en> Self drilling screws used to attach drywall to heavy gauge metal.
<G-vec00407-001-s075><attach.befestigen><de> Bohrschrauben zur Trockenmauer an dickem Metall zu befestigen.
<G-vec00407-001-s076><attach.befestigen><en> With this Power Core interchangeable robot combination system, MINI-CONS and drone vehicles (sold separately) can attach to power up any Commander figure.
<G-vec00407-001-s076><attach.befestigen><de> Mit dieser Power Core austauschbar Kombination Roboter-System kann der Mini-Cons und drone Fahrzeuge (separat erhältlich) an die Macht bis alle Commander Figur befestigen.
<G-vec00407-001-s077><attach.befestigen><en> Each keyring figure is around 3.5cm tall and comes complete with a ring to attach to your keys, bag or other items.
<G-vec00407-001-s077><attach.befestigen><de> Jeder Schlüsselanhänger ist rund 3,5 cm groß und kommt mit einem Ring, um Ihre Schlüssel oder an einer Tasche oder an andere Gegenstände zu befestigen.
<G-vec00407-001-s078><attach.befestigen><en> This one is equipped with a carabiner, so you can easily attach the flask to your backpack.
<G-vec00407-001-s078><attach.befestigen><de> An diesem befindet sich ein Karabiner, sodass du das gute Stück problemlos an deinem Rucksack befestigen kannst.
<G-vec00407-001-s079><attach.befestigen><en> Nike + iPod collects workout data from a wireless sensor (sold separately) that you attach to your shoe.
<G-vec00407-001-s079><attach.befestigen><de> """Nike + iPod"" erhält die Trainingsdaten von einem drahtlosen Sensor (separat erhältlich), den Sie an Ihrem Schuh befestigen."
<G-vec00407-001-s080><attach.befestigen><en> This saddlebag has 2 Velcro strips that you attach to the rings on the front of your saddle.
<G-vec00407-001-s080><attach.befestigen><de> Diese Satteltasche hat 2 Klettbänder, die Sie an den Ringen an der Vorderseite Ihres Sattels befestigen.
<G-vec00407-001-s081><attach.befestigen><en> Wooden designs in design position lift slings for what them attach to designs, and then suspend to a hook of the elevating mechanism.
<G-vec00407-001-s081><attach.befestigen><de> Die hölzernen Konstruktionen in die Projektlage heben stropami, wofür sie an den Konstruktionen befestigen, und dann hängen zum Haken des Hebemechanismus auf.
<G-vec00407-001-s082><attach.befestigen><en> It could in fact assist to expand the breast by enhancing fatty tissue as well as ligaments giving support as well as form to the breast, while also lengthening the air ducts that attach to the nipple area, for fuller as well as stronger breasts.
<G-vec00407-001-s082><attach.befestigen><de> Es könnte in der Tat helfen, die Brust zu erweitern, indem Fettgewebe sowie Bänder zu verbessern sowie Form auf die Brust geben Unterstützung, während auch die Luftkanäle Verlängerung, die an der Brustwarze Bereich befestigen, für vollere sowie stärkere Brüste.
<G-vec00407-001-s083><attach.anbringen><en> Let the band air dry thoroughly before you attach it to your Apple Watch.
<G-vec00407-001-s083><attach.anbringen><de> Lassen Sie das Armband gründlich trocknen, bevor Sie es an Ihrer Apple Watch anbringen.
<G-vec00407-001-s084><attach.anbringen><en> In order to securely attach this decoration, it should be applied immediately after the nail polish.
<G-vec00407-001-s084><attach.anbringen><de> Um diese Dekoration sicher anbringen, sollte es unmittelbar nach dem Nagellack aufgetragen werden.
<G-vec00407-001-s085><attach.anbringen><en> You can attach the zipper wound to any body and get a realistic result.
<G-vec00407-001-s085><attach.anbringen><de> Du kannst die Sekret-Wunde an einer beliebigen Körperstelle anbringen und erhältst ein realistisches Ergebnis.
<G-vec00407-001-s086><attach.anbringen><en> Attach comprehensive, clear information to the product.
<G-vec00407-001-s086><attach.anbringen><de> Ausführliche Informationen übersichtlich am Produkt anbringen.
<G-vec00407-001-s087><attach.anbringen><en> Our advise: First attach a solid rubber band to the roller and connect the main line to it.
<G-vec00407-001-s087><attach.anbringen><de> Unser Rat: An die Rolle erst ein festes Gummiband anbringen und an ihm die Hauptschnur verbinden.
<G-vec00407-001-s088><attach.anbringen><en> Anyway, who like to reduce the SSD temperature, could perform an active SSD cooling by direct ventilation or attach commercially available silicone heat transfer pads to the top of the PCB.
<G-vec00407-001-s088><attach.anbringen><de> Wer die SSD Temperatur dennoch reduzieren möchte, könnte beispielsweise eine aktive SSD Kühlung durch direkte Belüftung vornehmen oder handelsübliche Silikon Wärmeleitpads zur Verteilung der Hitze auf der Platinenoberseite anbringen.
<G-vec00407-001-s089><attach.anbringen><en> You can attach the material either directly onto the wall or onto plywood attached to the wall.
<G-vec00407-001-s089><attach.anbringen><de> Sie können das Material entweder direkt auf der Wand oder auf einem Trägermaterial aus Sperrholz anbringen, das an der Wand befestigt wird.
<G-vec00407-001-s090><attach.anbringen><en> The devilishly good-looking Demon Horns are easy to attach and convince with their fantastic looks.
<G-vec00407-001-s090><attach.anbringen><de> Die teuflisch gut aussehenden Dämonen Hörner lassen sich einfach anbringen und überzeugen durch ihr fantastisches Aussehen.
<G-vec00407-001-s091><attach.anbringen><en> As a last step, copy the confirmed RMA form with the assigned RMA number twice: please attach one copy to a clearly visible position on the outside of the packaging on all your return consignments.
<G-vec00407-001-s091><attach.anbringen><de> Kopieren Sie als letzten Schritt das bestätigte RMA-Formular mit der erteilten RMA-Nummer zweimal: eine Ausfertigung bitte deutlich sichtbar an der Außenseite der Verpackung all Ihrer Rücksendungen anbringen, die zweite Ausfertigung dem Produkt beilegen.
<G-vec00407-001-s092><attach.anbringen><en> Tip: Who like to reduce the SSD temperature, for example can a) adjust the energy saving settings or b) perform an active SSD cooling by direct ventilation or c) attach commercially available silicone heat transfer pads to the top and bottom of the PCB.
<G-vec00407-001-s092><attach.anbringen><de> Tipp: Wer die SSD Temperatur reduzieren möchte, könnte beispielsweise a) den Energiesparmodus anpassen oder b) eine aktive SSD Kühlung durch direkte Belüftung vornehmen oder c) handelsübliche Silikon Wärmeleitpads zur Verteilung der Hitze auf der Platinen Ober- und Unterseite anbringen.
<G-vec00407-001-s093><attach.anbringen><en> as an option, you can attach brochure trays made of satin acrylic.
<G-vec00407-001-s093><attach.anbringen><de> optional können sie prospektablagen aus mattem acrylglas anbringen.
<G-vec00407-001-s094><attach.anbringen><en> The Creepy Wall Deco Flame monster is a foil that you can easily attach to the wall with zips or double-sided tape and reuse.
<G-vec00407-001-s094><attach.anbringen><de> Die Gruselige Wanddeko Flammenmonster ist eine Folie die du ganz leicht mit Reißzwecken oder doppelseitigen Klebeband an der Wand anbringen und wiederverwenden kannst.
<G-vec00407-001-s095><attach.anbringen><en> Choose between various sizes of your Keuco Edition 300 light mirror, regardless of whether you want attach it vertically or horizontally above the basin.
<G-vec00407-001-s095><attach.anbringen><de> Wählen Sie zwischen verschiedenen Größen, unabhängig davon, ob Sie Ihn vertikal oder horizontal über dem Waschtisch anbringen wollen.
<G-vec00407-001-s096><attach.anbringen><en> You can glue the wooden clips on picture frames or wooden baskets, so you can attach pictures or small pieces of paper.
<G-vec00407-001-s096><attach.anbringen><de> Sie können die Holzklammern auf Bilderrahmen oder Holzkörbe kleben, so lassen sich Bilder oder kleine Zettel anbringen.
<G-vec00407-001-s097><attach.anbringen><en> You can attach it wherever you want.
<G-vec00407-001-s097><attach.anbringen><de> Sie können ihn anbringen, wo Sie möchten.
<G-vec00407-001-s098><attach.anbringen><en> "Indeed, this unique BDSM device will allow you to attach an ultra powerful clitoral vibrator such as a ""Magic Wand"" while you linger on your partner by subjecting her to all kinds of sexual abuse..."
<G-vec00407-001-s098><attach.anbringen><de> "Mit diesem einzigartigen BDSM-Gerät können Sie einen ultra-leistungsfähigen Klitorisvibrator vom Typ ""Magic Wand"" anbringen, während Sie bei Ihrem Partner verweilen, indem Sie ihn allen Arten von sexuellem Missbrauch aussetzen....."
<G-vec00407-001-s099><attach.anbringen><en> has all functions of Stella 1 and offers additionally support brackets, in order to attach the system simply and fast at posts, bars and tubes.
<G-vec00407-001-s099><attach.anbringen><de> verfügt über alle Funktionen von Stella 1 und bietet eine zusätzliche Befestigungsmanschette, um das System einfach und schnell an Pfosten, Stangen und Rohren anbringen zu können.
<G-vec00407-001-s100><attach.anbringen><en> The scrubber has a handy ring to hang it on a keychain, attach it to a hook in the kitchen, etc.
<G-vec00407-001-s100><attach.anbringen><de> Der Wäscher hat ein handliches Ring auf einem Schlüsselbund zu hängen, es an einen Haken in der Küche anbringen, etc.
<G-vec00407-001-s101><attach.anbringen><en> You can either attach directly a wire to one of the entrances (as in the example below, in the small oscillating circuit above left), or a probe on a wire to pull.
<G-vec00407-001-s101><attach.anbringen><de> Sie können entweder einen Draht bis einen der Eingänge (wie im Beispiel unten, im kleinen Schwingungskreis über links) oder eine Prüfspitze auf einem Draht direkt anbringen, um zu ziehen.
<G-vec00407-001-s102><attach.anfügen><en> The Airwheel X3 comes with training wheels that you can attach via screws to the bottom of the foot platforms and a safety strap whilst you get the hang of things.
<G-vec00407-001-s102><attach.anfügen><de> Der Airwheel X3 kommt mit Stützrädern, die Sie anfügen können über Schrauben an den unteren Rand der Fuß-Plattformen und einem Sicherheitsriemen während Sie die Dinge hängen.
<G-vec00407-001-s103><attach.anfügen><en> For more information, see How to attach a data disk to a Windows virtual machine in the Azure portal .
<G-vec00407-001-s103><attach.anfügen><de> Weitere Informationen finden Sie unter Anfügen eines verwalteten Datenträgers an einen virtuellen Windows-Computer im Azure-Portal .
<G-vec00407-001-s104><attach.anfügen><en> Click on ‘Attach File’ (or similar option).
<G-vec00407-001-s104><attach.anfügen><de> "Klicken Sie auf ""Datei anfügen"" (oder die entsprechende Option)."
<G-vec00407-001-s105><attach.anfügen><en> This article is a tutorial about how to attach tasks to email in Microsoft Outlook.
<G-vec00407-001-s105><attach.anfügen><de> Dieser Artikel enthält ein Lernprogramm zum Anfügen von Aufgaben an E-Mails in Microsoft Outlook.
<G-vec00407-001-s106><attach.anfügen><en> 6 clothespins wood with black and white patterns pen, question mark, pea balls, snowflakes, to decorate a gift box or attach a note.
<G-vec00407-001-s106><attach.anfügen><de> 6 Wäscheklammern Holz mit schwarzen und weißen Muster Stift, Fragezeichen, Erbsen Bälle, Schneeflocken, ein Geschenk-Box zu dekorieren oder eine Notiz anfügen.
<G-vec00407-001-s107><attach.anfügen><en> Attach file Adds a file saved in MeXX as an attachment to the current e-mail.
<G-vec00407-001-s107><attach.anfügen><de> Datei anfügen Fügt eine in MeXX gespeicherte Datei als Anlage an die aktuelle E-Mail an.
<G-vec00407-001-s108><attach.anfügen><en> Secure Mail users can attach files from their Citrix Files repository without needing to download the file to the device.
<G-vec00407-001-s108><attach.anfügen><de> Benutzer von Secure Mail können Dateien aus ihrem Citrix Files-Repository anfügen, ohne die Datei auf das Gerät herunterzuladen.
<G-vec00407-001-s109><attach.anfügen><en> You can even import contacts from your e-mail address book in a few clicks and attach a message.
<G-vec00407-001-s109><attach.anfügen><de> Sie können auch Kontakte aus Ihrem E-Mail-Adressbuch mit ein paar Klicks importieren und eine Nachricht anfügen.
<G-vec00407-001-s110><attach.anfügen><en> A faster experience — Outlook.com Beta comes with a “more responsive web development framework”, an optimized look with a “modern conversation style”, and a new “design to let you see, read and attach files and photos faster”.
<G-vec00407-001-s110><attach.anfügen><de> Ein schneller Erfahrung — Outlook.com Beta kommt mit einem “mehr responsive web development framework”, einer optimierten Optik mit einem “modernen Konversation Stil”, und ein neues “design, damit Sie sehen, Lesen und anfügen von Dateien und Fotos schneller”.
<G-vec00407-001-s111><attach.anfügen><en> You can also attach one or several files to help us to reproduce your problem.
<G-vec00407-001-s111><attach.anfügen><de> Sie können andere Dateien anfügen, um uns die Reproduktion ihres Problems zu erleichtern.
<G-vec00407-001-s112><attach.anfügen><en> One must attach, however, that an amendment was never carried out since the beginning of the Bordelaise classification and furthermore either this would not be possible in opinion of all connoisseurs of win.
<G-vec00407-001-s112><attach.anfügen><de> Man muss jedoch anfügen, dass seit Beginn der Bordelaiser Klassifizierung noch nie eine Änderung vorgenommen wurde und dies nach Meinung aller Weinkenner auch weiterhin nicht möglich sein würde.
<G-vec00407-001-s113><attach.anfügen><en> Cut off the excess around the edges and attach as a crust.
<G-vec00407-001-s113><attach.anfügen><de> Überstehende Streifen abschneiden und als seitliche Ränder anfügen.
<G-vec00407-001-s114><attach.anfügen><en> Once created, you can check the Attach a signature box on the posting form to add your signature. You can also add a signature by default to all your posts by checking the appropriate radio button in the User Control Panel.
<G-vec00407-001-s114><attach.anfügen><de> Du kannst auch standardmäßig eine Signatur an alle Beiträge anhängen, indem Du im Profil die entsprechende Option auswählst (Du kannst das Anfügen einer Signatur immer noch verhindern, indem Du die Signaturoption beim Beitragsschreiben abschaltest).
<G-vec00407-001-s115><attach.anfügen><en> Microsoft Outlook 2016 supports to list the most recent items in the Recent Items drop down list, and then you can attach recent documents/items from it quickly.
<G-vec00407-001-s115><attach.anfügen><de> Microsoft Outlook 2016 unterstützt, um die neuesten Elemente in der Liste aufzulisten Neue Artikel Dropdown-Liste, und Sie können dann die letzten Dokumente / Elemente schnell anfügen.
<G-vec00407-001-s116><attach.anfügen><en> -- Collaborate -- Built for Office 365, Planner lets you work together on the same tasks, attach captured photos directly to them, and even have conversations around tasks without switching between apps.
<G-vec00407-001-s116><attach.anfügen><de> – Zusammenarbeit – Mit Planner, einem für Office 365 konzipierten Werkzeug, können Sie gemeinsam an den gleichen Aufgaben arbeiten, erfasste Fotos direkt an sie anfügen und sogar Gespräche rund um Ihre Aufgaben führen, ohne die Anwendung zu wechseln.
<G-vec00407-001-s117><attach.anfügen><en> Comes with manual and with an adhesive to attach to the table.
<G-vec00407-001-s117><attach.anfügen><de> Kommt mit Anleitung und mit einem Klebstoff an die Tabelle anfügen.
<G-vec00407-001-s118><attach.anfügen><en> "Probably, this is the reason for that thing called ""chemistry,"" but whatever label people attach to this kind of attraction, one thing is for sure: the effect that pheromones bring is not mere speculation but a proven fact."
<G-vec00407-001-s118><attach.anfügen><de> "Wahrscheinlich, dies ist der Grund für dieses Ding namens ""Chemie"", aber anfügen was Etikett die Menschen zu dieser Art von Anziehung, eine Sache ist sicher: die Wirkung, die Pheromone zu bringen ist nicht bloße Spekulation aber eine erwiesene Tatsache."
<G-vec00407-001-s119><attach.anfügen><en> "Then, when creating your label on FedEx Ship Manager, you can select ""Attach from Document Preparation Center"" to upload the document you previously created."
<G-vec00407-001-s119><attach.anfügen><de> "Wenn Sie dann Ihr Etikett im FedEx Ship Manager erstellen, können Sie die Option ""Vom Center Dokumentenvorbereitung anfügen"" auswählen, um Ihr zuvor erstelltes Dokument hochzuladen."
<G-vec00407-001-s120><attach.anfügen><en> If the Attach database filename box contains the name of a primary file, the database described by the primary file is attached as a database using the database name specified in the Change the default database to box.
<G-vec00407-001-s120><attach.anfügen><de> Wenn das Feld Datenbank-Dateinamen anfügen den Namen einer primären Datei enthält, wird die durch die primäre Datei beschriebene Datenbank als Datenbank mithilfe des im Feld Die Standarddatenbank ändern auf angegebenen Datenbanknamens angefügt.
<G-vec00407-001-s121><attach.anbringen><en> This means that it must be possible to attach and/or secure load securing materials to the cargo unit in such a way that the load can be adequately secured while remaining undamaged.
<G-vec00407-001-s121><attach.anbringen><de> Das heißt, dass Ladungssicherungsmaterialien so an der Ladeeinheit angebracht und/oder befestigt werden können, dass eine ausreichende Sicherung der Ladung möglich ist und die Ladung dabei unversehrt bleibt.
<G-vec00407-001-s122><attach.anbringen><en> Plywood or foam would need to be accordingly thick, to make them easier to attach to the frame.
<G-vec00407-001-s122><attach.anbringen><de> Sperrholz oder Schaumstoff müssen entsprechend dick sein, damit sie leichter an den Rahmen angebracht werden können.
<G-vec00407-001-s123><attach.anbringen><en> This item comes with the numbers 1?9 and the letters a?f that you can simply attach by sticking them on.
<G-vec00407-001-s123><attach.anbringen><de> Die mitgelieferten Zahlen von 1 - 9 und die Buchstaben von a - f können einfach durch Aufkleben angebracht werden.
<G-vec00407-001-s124><attach.anbringen><en> Easy assembly, simply attach the legs
<G-vec00407-001-s124><attach.anbringen><de> Einfache Montage, nur die Beine müssen angebracht werden.
<G-vec00407-001-s125><attach.anbringen><en> Use the anti-gravity device in front of the door, this will attach it to the underside of the door, allowing it to rise halfway.
<G-vec00407-001-s125><attach.anbringen><de> Benutze die Antigrav-Einheit vor der Tür, dadurch wird sie an die Unterseite der Tür angebracht und die Tür wird halb hochgehoben.
<G-vec00407-001-s126><attach.anbringen><en> This is a white iron sheet to which you can attach magnets.
<G-vec00407-001-s126><attach.anbringen><de> Es handelt sich hier um eine weiße Eisenfolie, auf der Magnete angebracht werden können.
<G-vec00407-001-s127><attach.anbringen><en> Description The pump is equipped with suction cups so that you can attach it to the bottom of the reservoir.
<G-vec00407-001-s127><attach.anbringen><de> Stück Beschreibung Die Pumpe ist mit Saugnäpfen ausgestattet, so dass sie am Boden eines Reservoirs angebracht werden kann.
<G-vec00407-001-s128><attach.anbringen><en> In the actual application of the research project, the aim is to attach an S3 label like an adhesive strip to a Festo pneumatic drive.
<G-vec00407-001-s128><attach.anbringen><de> Im konkreten Anwendungsfall des Forschungsprojekts soll ein S3-Label wie ein Klebestreifen auf einem pneumatischen Antrieb von Festo angebracht werden.
<G-vec00407-001-s129><attach.anbringen><en> On the other hand, girth hitches can also be used to fasten slings to trees and to attach a personal anchor sling to a harness and carabiner.
<G-vec00407-001-s129><attach.anbringen><de> Zum anderen können mittels Ankerstich Schlingen an Bäumen fixiert oder eine Selbstsicherungsschlinge am Gurt und in Karabinern angebracht werden.
<G-vec00407-001-s130><attach.anbringen><en> Assembly required, simply attach the legs
<G-vec00407-001-s130><attach.anbringen><de> Geringfügige Montage erforderlich, die Beine müssen angebracht werden.
<G-vec00407-001-s131><attach.anbringen><en> This package label will be sent to you via e-mail which you then will have to print out and attach to the package.
<G-vec00407-001-s131><attach.anbringen><de> Dieser Paketaufschriftzettelwird Ihnen dann per E-mail zugeschickt und muss ausgedruckt und auf dem Paket angebracht werden.
<G-vec00407-001-s132><attach.anbringen><en> They easily attach with velcro or magnets to the furniture and turn them into highly decorative acoustic surfaces.
<G-vec00407-001-s132><attach.anbringen><de> Sie werden einfach mit Magnetband oder Klettband auf den zu verblendeten Seiten der Möbel angebracht und machen aus diesen akustisch wirksame Oberflächen, die überdies sehr dekorativ aussehen.
<G-vec00407-001-s133><attach.anbringen><en> This item contains an universal accessory connector type #3 that can be used to attach accessories to the handlebar for the Bugaboo Bee or the Bugaboo Donkey.
<G-vec00407-001-s133><attach.anbringen><de> Artikelcode Dieser Artikel enthält ein Universal-Zubehör-Verbindungsstück vom Typ 3, mit dem Bugaboo Accessoires am Schiebebügel des Bugaboo Bee oder Bugaboo Donkey angebracht werden können.
<G-vec00407-001-s134><attach.anheften><en> These are hard, brown shields that attach themselves to the bottom of the leaves.
<G-vec00407-001-s134><attach.anheften><de> Dies sind harte, braune Schilder, die sich an der Unterseite der Blätter anheften.
<G-vec00407-001-s135><attach.anheften><en> That Passanten replace and attach the amber STIX elsewhere, with it a quite desired side effect is: „The viralen effects are unbelievable “, are pleased Karsten Warrink, managing director of AMBERME dia., „the funny motives provoke for carrying forward.
<G-vec00407-001-s135><attach.anheften><de> Dass Passanten die amber STIX ablösen und anderswo anheften, ist da-bei ein durchaus erwünschter Nebeneffekt: „Die viralen Effekte sind un-glaublich“, freut sich Karsten Warrink, Geschäftsführer von AMBERME-DIA, „Die witzigen Motive reizen zum Mitnehmen.
<G-vec00407-001-s136><attach.anheften><en> Mantis can possess people or attach closely to their energy system.
<G-vec00407-001-s136><attach.anheften><de> Mantis können Menschen besetzen oder sich nahe an Menschen anheften.
<G-vec00407-001-s137><attach.anheften><en> On the opposite side of the walker, they then unblock a separate row, to which the cylinder’s feet can now attach.
<G-vec00407-001-s137><attach.anheften><de> Auf der gegenüberliegenden Seite des Läufers wird wiederum eine bis dahin blockierte Reihe freigegeben – und die Füßchen des Zylinders können sich dort anheften.
<G-vec00407-001-s138><attach.anheften><en> Through folding and attachment of other helix molecules, capsules are developed that can attach themselves with embedded enzymes or other agents targeted on sick cells.
<G-vec00407-001-s138><attach.anheften><de> Durch Faltung und Anlagerung von anderen Helix-Molekülen entstehen daraus Kapseln, die sich mit eingeschlossenen Enzymen oder anderen Wirkstoffen gezielt an kranke Zellen anheften können.
<G-vec00407-001-s139><attach.anheften><en> - would attach itself.
<G-vec00407-001-s139><attach.anheften><de> – selbst anheften würde.
<G-vec00407-001-s140><attach.anheften><en> The live recordings document how, within hours of being transplanted, the hematopoietic stem cells attach themselves to the inner vessel walls in the bone marrow and start to migrate into the surrounding tissue – their niche.
<G-vec00407-001-s140><attach.anheften><de> Die live-Aufnahmen dokumentieren, wie sich die hämatopoetischen Stammzellen innerhalb von Stunden nach der Transplantation an die Gefäßinnenwand im Knochenmark anheften und anfangen, in das umliegende Gewebe – ihre Nische – zu migrieren.
<G-vec00407-001-s141><attach.anheften><en> You should attach it to the minutes after they're transcribed.
<G-vec00407-001-s141><attach.anheften><de> Du solltest diese an das Protokoll anheften, nachdem du es abgetippt hast.
<G-vec00407-001-s142><attach.anheften><en> That Passanten replace and attach the amber STIX elsewhere, with it a quite desired side effect is: „The viralen effects are unbelievable “, are pleased Karsten Warrink, managing director of AMBERME dia., „the funny motives provoke for carrying forward.
<G-vec00407-001-s142><attach.anheften><de> Dass Passanten die amber STIX ablösen und anderswo anheften, ist da-bei ein durchaus erwünschter Nebeneffekt: â Die viralen Effekte sind un-glaublichâ, freut sich Karsten Warrink, Geschäftsführer von AMBERME-DIA, â Die witzigen Motive reizen zum Mitnehmen.
<G-vec00407-001-s143><attach.anhängen><en> Note: The Insert > Attach File > Recent Item is new in Outlook 2016, therefore this method does not work in earlier Outlook versions.
<G-vec00407-001-s143><attach.anhängen><de> Text: Das Einsatz > Datei anhängen > Neuestes Objekt ist in Outlook 2016 neu, daher funktioniert diese Methode in früheren Outlook-Versionen nicht.
<G-vec00407-001-s144><attach.anhängen><en> Wallee allows you to fully customize order emails, invoices or any other document that you wish to attach to communications with your customers via our built in resource editor.
<G-vec00407-001-s144><attach.anhängen><de> Wallee ermöglicht es Ihnen, Bestell-E-Mails, Rechnungen oder andere Dokumente, die Sie an die Kommunikation mit Ihren Kunden über unseren integrierten Ressourcen-Editor anhängen möchten, vollständig anzupassen.
<G-vec00407-001-s145><attach.anhängen><en> The PowerPoint export can now attach slides to an existing PPTX file.
<G-vec00407-001-s145><attach.anhängen><de> Der PowerPoint-Export kann jetzt Folien an eine bestehende PPTX-Datei anhängen.
<G-vec00407-001-s146><attach.anhängen><en> "External files, text, HTML or image files can be imported in the same place with the button ""Instead, attach a file as a signature""."
<G-vec00407-001-s146><attach.anhängen><de> "Als externe Dateien können an gleicher Stelle über den Button ""Stattdessen eine Datei als Signatur anhängen"" Text-, HTML - oder Grafikdateien eingebunden werden."
<G-vec00407-001-s147><attach.anhängen><en> - The photograph you attach must be recent passport-size.
<G-vec00407-001-s147><attach.anhängen><de> - Das Foto, das Sie anhängen müssen neue Pass Größe sein.
<G-vec00407-001-s148><attach.anhängen><en> In the document that you attach you count some of the most significant changes.
<G-vec00407-001-s148><attach.anhängen><de> In dem Dokument, das Sie anhängen Sie zählen einige der wichtigsten Änderungen.
<G-vec00407-001-s149><attach.anhängen><en> You can then attach the new HTML document instead of your Word document.
<G-vec00407-001-s149><attach.anhängen><de> Sie können dann das neue HTML-Dokument anstelle Ihres Word-Dokumentes anhängen.
<G-vec00407-001-s150><attach.anhängen><en> 系 xì: (attach) is not used alone.
<G-vec00407-001-s150><attach.anhängen><de> 系 xì: (Anhängen) wird nicht alleine verwendet.
<G-vec00407-001-s151><attach.anhängen><en> Some items can be combined or used in attach.
<G-vec00407-001-s151><attach.anhängen><de> Einige Artikel können kombiniert oder benutzt werden anhängen.
<G-vec00407-001-s152><attach.anhängen><en> Add unique effects, apply different filters, place text on images, attach stickers, and much more with the Photo Editor tool accessed from the CraterTM Editor.
<G-vec00407-001-s152><attach.anhängen><de> Sie können einzigartige Effekte hinzufügen, verschiedene Filter anwenden, Texte auf Bildern platzieren, Sticker anhängen, und noch vieles mehr mit dem Photo Editor Werkzeug des CraterTM Editors.
<G-vec00407-001-s153><attach.anhängen><en> One can also attach an existing file that will serve as a signature.
<G-vec00407-001-s153><attach.anhängen><de> Man kann auch eine vorhandene Datei anhängen, die als Signatur dienen.
<G-vec00407-001-s154><attach.anhängen><en> Outgoing attachments [top] To send a file stored on your computer, click on Attach and then select Attachments .To send a file already stored in the Documents, click on Attach and then select Documents .
<G-vec00407-001-s154><attach.anhängen><de> Anlagen zum Versand [top] Um eine Datei, die auf Ihrem Computer gespeichert ist, zu versenden, klicken Sie auf Anhängen und wählen Sie dann Anhang .Um eine Datei zu senden, die bereits in den Dokumenten abgespeichert ist, klicken Sie auf Anhängen und wählen Sie dann Dokumente .
<G-vec00407-001-s155><attach.anhängen><en> Outgoing attachments [top] To send a file stored on your computer, click on Attach and then select Attachments .To send a file already stored in the Documents, click on Attach and then select Documents .
<G-vec00407-001-s155><attach.anhängen><de> Anlagen zum Versand [top] Um eine Datei, die auf Ihrem Computer gespeichert ist, zu versenden, klicken Sie auf Anhängen und wählen Sie dann Anhang .Um eine Datei zu senden, die bereits in den Dokumenten abgespeichert ist, klicken Sie auf Anhängen und wählen Sie dann Dokumente .
<G-vec00407-001-s156><attach.anhängen><en> And the Radical Universal Aero panniers are made to attach to a mesh seat.
<G-vec00407-001-s156><attach.anhängen><de> Die Radical Universal Aero-Taschen sind für's Anhängen an den Spannsitz gedacht.
<G-vec00407-001-s157><attach.anhängen><en> You can attach (or link) a Document to a Contact.
<G-vec00407-001-s157><attach.anhängen><de> Sie können ein Dokument einem Kontakt anhängen (oder mit ihm verlinken).
<G-vec00407-001-s158><attach.anhängen><en> Alternatively, you can attach an existing photo, video, or GIF by choosing from the thumbnails alongside the camera button or by tapping the gallery icon .
<G-vec00407-001-s158><attach.anhängen><de> Stattdessen kannst du ein vorhandenes Foto, Video oder GIF anhängen, indem du eines aus den Thumbnails neben dem Kamera-Button auswählst oder das Galeriesymbol antippst.
<G-vec00407-001-s159><attach.anhängen><en> To use our services, you don't even need to attach any credit card or other payment information.
<G-vec00407-001-s159><attach.anhängen><de> Um unsere Dienste nutzen zu können, müssen Sie nicht einmal Kreditkarten- oder andere Zahlungsinformationen anhängen.
<G-vec00407-001-s160><attach.anhängen><en> Select Attach a copy of the sent fax if you want to receive copies of the faxes that you send with the receipts.
<G-vec00407-001-s160><attach.anhängen><de> Aktivieren Sie Kopie des gesendeten Faxes anhängen, wenn Sie mit der Empfangsbestätigung eine Kopie der gesendeten Faxnachricht empfangen möchten.
<G-vec00407-001-s161><attach.anhängen><en> Hotmail doesn't want us to attach our pictures to the mails we are going to send and it takes dozens of connection- attempts before we can get our latest diary-update on the way to Dirk Borchers, our webmaster in Bremen.
<G-vec00407-001-s161><attach.anhängen><de> Hotmail wollte uns nicht Bilder an unsere Mail anhängen lassen und erst nach etlichen Einwahlversuchen konnten die letzten Tagebucheintragungen auf den Weg nach Bremen zu Dirk Borchers, unserem Webmaster und Dominique, unserer fleißigen Übersetzerin, gesendet werden.
<G-vec00407-001-s162><attach.anschließen><en> You can attach to our flow rate meter modules with its 16 digital inputs up to 8 flow rate meters with foam probes or alternatively barrel-empty detectors.
<G-vec00407-001-s162><attach.anschließen><de> An unsere Durchflusszählermodule (FRM: Flow Rate Meter) mit insgesamt 16digitalen Eingängen können Sie bis zu 8Durchflusszähler mit Schaumsonde oder alternativ Fassleermelder anschließen.
<G-vec00407-001-s163><attach.anschließen><en> So, for the sake of survival, alliances are useful; if you find a leader or group that serves your purpose then why not attach yourself for a while until your progeny is ready to challenge the ideological blood line.
<G-vec00407-001-s163><attach.anschließen><de> Also, um des Überlebens Willen sind Allianzen nützlich; wenn du einen Anführer oder eine Gruppe findest, die für deine Zwecke nützlich sind, warum sich nicht eine Weile anschließen, bis deine Nachkommenschaft dazu bereit ist, die ideologische Blutlinie herauszufordern.
<G-vec00407-001-s164><attach.anschließen><en> The Seneye Float is designed to be used with the Seneye Reef and offers flexibility for customers who do not wish to use the sucker to attach the Seneye device.
<G-vec00407-001-s164><attach.anschließen><de> Die Seneye Float ist entworfen, um mit dem Seneye Reef genutzt werden und bietet Flexibilität für Kunden, die nicht wollen, um den Sauger zu verwenden, um die Seneye Gerät anschließen.
<G-vec00407-001-s165><attach.anschließen><en> Attach the pump to the extension connector and pump about 50 times.
<G-vec00407-001-s165><attach.anschließen><de> Die Velopumpe ans Ventil anschließen und ungefähr 50 x pumpen.
<G-vec00407-001-s166><attach.anschließen><en> During the miner procedures the linked malware can attach to currently running Windows services and also third-party mounted applications.
<G-vec00407-001-s166><attach.anschließen><de> Während der miner Verfahren können die verknüpfte Malware aktuell laufenden Windows-Dienste anschließen und auch von Drittanbietern montiert Anwendungen.
<G-vec00407-001-s167><attach.anschließen><en> Their fresh look and superb quality will enable developers to attach a genuinely professional feel to their project interfaces.
<G-vec00407-001-s167><attach.anschließen><de> Ihre frischen Look und hervorragende Qualität ermöglicht es Entwicklern, eine wirklich professionellen Look zu ihrem Projekt-Schnittstellen anschließen.
<G-vec00407-001-s168><attach.anschließen><en> But you can also, of course, attach a hose for an external condensate drain.
<G-vec00407-001-s168><attach.anschließen><de> Natürlich können Sie aber auch einen Schlauch für einen externen Kondensatablauf anschließen.
<G-vec00407-001-s169><attach.anschließen><en> It can be even more perfect if we attach this USB drive to a nice lanyard.
<G-vec00407-001-s169><attach.anschließen><de> Es kann noch perfekter sein, wenn wir diesen USB-Stick an eine schöne Lanyard anschließen.
<G-vec00407-001-s170><attach.anschließen><en> You do not need to attach the All-In-One to a computer to make copies, to print photos stored on memory cards, or to print photos directly from a digital camera using PictBridge.
<G-vec00407-001-s170><attach.anschließen><de> Sie müssen den All-In-One nicht an einen Computer anschließen, um Kopien zu erstellen, um auf Ihren Speicherkarten gespeicherte Fotos zu drucken oder um Fotos mithilfe von PictBridge direkt von einer Digitalkamera zu drucken.
<G-vec00407-001-s171><attach.anschließen><en> The cars will attach themselves once you park correctly.
<G-vec00407-001-s171><attach.anschließen><de> Die Autos werden sich anschließen, wenn Sie richtig parken.
<G-vec00407-001-s172><attach.anschließen><en> Audio devices attach to the connector of the central unit, insert the plug into the player outputs are available on the left and the right.
<G-vec00407-001-s172><attach.anschließen><de> Audio-Geräte an den Anschluss der Zentraleinheit anschließen, stecken Sie den Stecker in die Spieler-Ausgänge sind auf der linken und der rechten Seite zur Verfügung.
<G-vec00407-001-s173><attach.anschließen><en> Of course, the new iPadOS will also allow you to attach a controller, gamepad or gaming joystick.
<G-vec00407-001-s173><attach.anschließen><de> Mit dem neuen iPadOS können Sie natürlich auch einen Controller, ein Gamepad oder einen Gaming-Joystick anschließen.
<G-vec00407-001-s174><attach.anschließen><en> To listen to the radio, you need to attach a compatible headset to the device.
<G-vec00407-001-s174><attach.anschließen><de> Um Radio zu hören, müssen Sie ein kompatibles Headset an das Gerät anschließen.
<G-vec00407-001-s175><attach.anschließen><en> "A Swiss study found out that ""...the users of Italian descent seem to attach more to certain persons than to institutions."
<G-vec00407-001-s175><attach.anschließen><de> "In einer Studie aus der Schweiz wurde herausgefunden, dass ""...sich Drogenkonsumenten italienischer Abstammung eher bestimmten Personen als Institutionen anschließen."
<G-vec00407-001-s176><attach.anschließen><en> Its slender housing measures only 11 cm long and 2 cm wide, including a connection to which you can attach your sensor directly, without a cable.
<G-vec00407-001-s176><attach.anschließen><de> Sein schlankes Gehäuse ist nur 11 cm lang und 2 cm breit – einschließlich eines Anschlusses, an den Sie Ihren Sensor direkt, also ohne Kabel, anschließen können.
<G-vec00407-001-s177><attach.anschließen><en> Galleon products range from Atomic clock that attach to a standalone PC's to Atomic Clocks that Attach to a Windows time Server.
<G-vec00407-001-s177><attach.anschließen><de> Galleon Produkte reichen von Atomuhr, die auf einem eigenständigen PC anschließen ist die Atomuhren, die ein Befestigen Windows-Zeit-Server.
<G-vec00407-001-s178><attach.anschließen><en> Afterwards simply attach the keyboard to the USB 3.0 port, in order to get into the UEFI Setup and to be able to setup all necessary settings.
<G-vec00407-001-s178><attach.anschließen><de> Danach einfach die Tastatur am USB 3.0 Port anschließen, um ins UEFI Setup zu gelangen und alle Einstellungen vornehmen zu können.
<G-vec00407-001-s179><attach.anschließen><en> If you need to work with the system disk, in order to get access to it, you will have to extract it from the machine and attach it to another computer as a secondary disk or boot your Mac in a safe environment using UFS Explorer Backup and Emergency Recovery CD.
<G-vec00407-001-s179><attach.anschließen><de> Wenn Sie mit dem Systemlaufwerk arbeiten, um Zugriff darauf zu erhalten, müssen Sie das vom Computer extrahieren und als sekundäre Festplatte an einen anderen Computer anschließen oder Ihren Mac in einer sicheren Umgebung mit UFS Explorer Backup and Emergency Recovery CD starten.
<G-vec00407-001-s180><attach.anschließen><en> You should attach the grass bag to the unit and you are ready to move the mower to perform the job.
<G-vec00407-001-s180><attach.anschließen><de> Sie sollten den Grassack an das Gerät anschließen und Sie sind bereit, den Mäher zu bewegen, um die Aufgabe zu erledigen.
<G-vec00407-001-s181><attach.anbringen><en> It is not necessary to attach the CE marking to an electrical device.
<G-vec00407-001-s181><attach.anbringen><de> Für elektrische Geräte und Apparate ist es nicht erforderlich, die CE-Kennzeichnung auf dem Produkt selbst anzubringen.
<G-vec00407-001-s182><attach.anbringen><en> Keep in mind that you will be allowed to attach pics when you have posted, at least, 15 messages on this forum.
<G-vec00407-001-s182><attach.anbringen><de> Im Verstand halten, daß dir erlaubt wirst, pics, wenn du mindestens bekanntgegeben hast 15 Anzeigen anzubringen auf diesem Forum.
<G-vec00407-001-s183><attach.anbringen><en> The optical selection of the sensor makes it possible to attach the sensor in any chosen geometry.
<G-vec00407-001-s183><attach.anbringen><de> Das optische Auslesen des Sensors erlaubt es, den Sensor in jeder beliebigen Geometrie anzubringen.
<G-vec00407-001-s184><attach.anbringen><en> Hang tags are cardboard blanks, which can be printed on front and back, and are equipped with hole punching to attach threads.
<G-vec00407-001-s184><attach.anbringen><de> weitere Infos Anhängeetiketten Anhängeetiketten sind auf der Vorder- und Rückseite bedruckbare Kartonzuschnitte, die mit einer Lochstanzung ausgestattet sind, um Fäden anzubringen.
<G-vec00407-001-s185><attach.anbringen><en> It is self-adhesive and easy to attach.
<G-vec00407-001-s185><attach.anbringen><de> Er ist selbstklebend und leicht anzubringen.
<G-vec00407-001-s186><attach.anbringen><en> 5.12 The seller is not entitled to attach links to external websites to his online-shop in any form.
<G-vec00407-001-s186><attach.anbringen><de> 5.12 Der Verkäufer ist in seinem Shop nicht dazu berechtigt, Links, die auf externe Webseiten verweisen, in irgendeiner Form anzubringen.
<G-vec00407-001-s187><attach.anbringen><en> The reduced tag size allows users to attach them even to small metallic carriers.
<G-vec00407-001-s187><attach.anbringen><de> Durch die reduzierte Größe des Datenträgers, ist es möglich, die Tags an kleine metallische Posten von außen anzubringen.
<G-vec00407-001-s188><attach.anbringen><en> You are then ready to attach your spanking implement.
<G-vec00407-001-s188><attach.anbringen><de> Sie sind dann bereit, Ihr Prügelgerät anzubringen.
<G-vec00407-001-s189><attach.anbringen><en> Segway Switzerland offers you the following handbooks and instructions for your records, to help you understand your Segway PT or to attach further or new components.
<G-vec00407-001-s189><attach.anbringen><de> Segway Switzerland bietet Ihnen die nachfolgenden Handbücher und Anleitungen, um Ihren Segway PT zu verstehen oder um weitere oder neue Bestandteile anzubringen.
<G-vec00407-001-s190><attach.anbringen><en> Even LEICA's included strap is the perfect length right out of the box, and much easier to attach, adjust and remove than anything else.
<G-vec00407-001-s190><attach.anbringen><de> Sogar der Leica-Gurt hat die perfekte Länge, so wie er aus der Box kommt, und er ist viel einfacher anzubringen, einzustellen und abzunehmen als jeder andere.
<G-vec00407-001-s191><attach.anbringen><en> This mount enables you to attach your Garmin VIRB Ultra 30 on your wrist or other round objects with a diameter up to 203 mm.
<G-vec00407-001-s191><attach.anbringen><de> Diese Halterung ermöglicht es Ihnen die Garmin VIRB Ultra 30 an Ihrem Hangelenk oder an runden Objekten mit einem Durchmesser von bis zu 203 mm anzubringen.
<G-vec00407-001-s192><attach.anbringen><en> For easy access to this little tool, you would need a golf hat clip to carry it along to attach on your hat.
<G-vec00407-001-s192><attach.anbringen><de> Für den einfachen Zugriff auf dieses kleine Werkzeug benötigen Sie einen Golfhutclip, um es an Ihrem Hut anzubringen.
<G-vec00407-001-s193><attach.anbringen><en> Easy to attach, long enough to keep the leash away from the wheel when the dog is not pulling and a 90 degree angle is no problem.
<G-vec00407-001-s193><attach.anbringen><de> Leicht anzubringen, lang genug um die Leine vom Rad weg zu halten wenn der Hund mal nicht so zieht und eine 90 Gradabwinkelung ist auch kein Problem.
<G-vec00407-001-s194><attach.anbringen><en> They are available in three quality levels Basixx, Axxent and Luxxus and are easy to attach.
<G-vec00407-001-s194><attach.anbringen><de> Sie sind in drei Qualitätsstufen Basixx, Axxent und Luxxus erhältlich und sind problemlos anzubringen.
<G-vec00407-001-s195><attach.anbringen><en> The process of free Christian ecard advertising allows Christians from all over the world to have access to information and products offered by a particular organization providing Christian ecards.In addition to a personalized text, a free Christian ecard allows a consumer to create different backgrounds, images and music to attach to their Christian ecards.
<G-vec00407-001-s195><attach.anbringen><de> Der Prozeß des freien christlichen ecard Annoncierens erlaubt Christen von auf der ganzen Erde, Zugang zu den Informationen und Produkte durch eine bestimmte Organisation anbieten zu lassen, die christliche ecards bereitstellt.Zusätzlich zu einem personifizierten Text erlaubt ein freies christliches ecard einem Verbraucher, unterschiedliche Hintergründe, Bilder und Musik zu verursachen, um zu ihren christlichen ecards anzubringen.
<G-vec00407-001-s196><attach.anbringen><en> The rings on each side of the ball allow you to attach a chain or other BDSM accessory.
<G-vec00407-001-s196><attach.anbringen><de> Die Ringe auf jeder Seite des Balls ermöglichen Ihnen, eine Kette oder anderes BDSM-Zubehör anzubringen.
<G-vec00407-001-s197><attach.anbringen><en> It was important not to put the magnets on too early, otherwise the metal chips could have loosened from the paint and attach to the magnets.
<G-vec00407-001-s197><attach.anbringen><de> Es war wichtig, die Magnete nicht zu früh anzubringen, da sich ansonsten die Metallspäne aus der Farbe gelöst und an die Magnete geheftet hätten.
<G-vec00407-001-s198><attach.anbringen><en> This would reduce their extension to less than an inch. I bought a packet of wood screws and of washers to attach the sign to the end of the broom and drilled four more holes at the bottom to provide additional strength.
<G-vec00407-001-s198><attach.anbringen><de> Ich kaufte ein Paket der hölzernen Schrauben und der Unterlegscheiben, um das Zeichen zum Ende des Besens anzubringen und bohrte vier weitere Löcher an der Unterseite, um zusätzliche Stärke zur Verfügung zu stellen.
<G-vec00407-001-s199><attach.anbringen><en> What I missed: A possibility to attach the mobile phone, because navigation is also necessary here.
<G-vec00407-001-s199><attach.anbringen><de> Was ich vermisst habe: Eine Möglichkeit das Handy anzubringen, denn Navigation ist auch hier nötig.
<G-vec00407-001-s200><attach.anhängen><en> Tags: The new configuration object class “Tag” allows to attach short texts to almost any other object.
<G-vec00407-001-s200><attach.anhängen><de> Tags: Die neue Konfigurations-Objektklasse „Tag“ erlaubt es, kurze Texte an fast alle anderen Objekte anzuhängen.
<G-vec00407-001-s201><attach.anhängen><en> To attach a data point to the trend log, press the Add... button and select the reg_1_Read register which was created previously.
<G-vec00407-001-s201><attach.anhängen><de> Um einen Datenpunkt an den Trendlog anzuhängen, drücken Sie auf die Schaltfläche Add... und wählen das vorher erzeugte Register reg_1_Read aus.
<G-vec00407-001-s202><attach.anhängen><en> If you want to add images that you found on the Web, you either have to download them or attach their link instead which may take quite some time as you need to open a web browser, open an image search site or a site images are hosted on, download the image or copy the link, and attach it to the message.
<G-vec00407-001-s202><attach.anhängen><de> Wenn Sie möchten, fügen Sie Bilder hinzu, die Sie auf dem Web gefunden werden, müssen Sie entweder herunterladen oder befestigen Sie Ihren link stattdessen kann einige Zeit dauern, wie Sie benötigen, öffnen Sie einen Webbrowser, öffnen Sie eine Bild-such-Website oder einer Website, die Bilder gehostet werden, laden Sie das Bild oder den link kopieren und es an die Nachricht anzuhängen.
<G-vec00407-001-s203><attach.anhängen><en> • Navigate to the folder where the PatXML document is saved and click Open to attach the document.
<G-vec00407-001-s203><attach.anhängen><de> • Gehen Sie zu dem Ordner, in dem das PatXML- Dokument gespeichert ist, und klicken Sie auf Öffnen, um das Dokument anzuhängen.
<G-vec00407-001-s204><attach.anhängen><en> Copy All Open Files: Copies all open Word documents and allows you paste them to any file location or to attach in emails.
<G-vec00407-001-s204><attach.anhängen><de> Kopiere alle geöffneten Dateien: Kopiert alle geöffneten Word-Dokumente und ermöglicht es Ihnen, sie an einem beliebigen Speicherort einzufügen oder in E-Mails anzuhängen.
<G-vec00407-001-s205><attach.anhängen><en> When it comes to Mac mind mapping software, you get what you pay for. Using MindView Mac as your mind mapping software brings you the power of 6 interchangeable views, the ability to take notes, attach files and add visuals to the branches.
<G-vec00407-001-s205><attach.anhängen><de> Bei Verwendung von MindView Mac als Ihre Mind Mapping-Software profitieren Sie von 6 frei wählbaren Ansichten, der Möglichkeit, Notizen zu machen, Dateien anzuhängen und den Zweigen Grafiken hinzuzufügen.
<G-vec00407-001-s206><attach.anhängen><en> From now on, there is no need to copy files back and forth between your PC and external devices or worry about the size of the files as you try to attach them to an email.
<G-vec00407-001-s206><attach.anhängen><de> Von nun an müssen Sie Dateien nicht mehr zwischen Ihrem PC und externen Geräten kopieren oder sich um die Größe von Dateien sorgen, wenn Sie versuchen, diese an eine eMail anzuhängen.
<G-vec00407-001-s207><attach.anhängen><en> You can attach cover letters, CVs, certificates and other attachments.
<G-vec00407-001-s207><attach.anhängen><de> Sie haben die Möglichkeit Anschreiben, Lebensläufe, Zeugnisse und andere Anlagen anzuhängen.
<G-vec00407-001-s208><attach.anhängen><en> It is now also possible to attach external files to a directory.
<G-vec00407-001-s208><attach.anhängen><de> Es ist jetzt auch möglich, externe Dateien an ein Verzeichnis anzuhängen.
<G-vec00407-001-s209><attach.anhängen><en> In the case of equipment self-made, the participants must attach the wiring diagram of the apparatus used .
<G-vec00407-001-s209><attach.anhängen><de> Bei geräten autocostruite die teilnehmer müssen anzuhängen, den schaltplan des gerätes verwendet .
<G-vec00407-001-s210><attach.anhängen><en> MAPI is a standard interface that allows WinZip and other programs (including Windows itself) to instruct your email program to create a new message, attach a file to it, etc.
<G-vec00407-001-s210><attach.anhängen><de> Die MAPI-Standardschnittstelle ermöglicht WinZip und anderen Anwendungen (einschließlich Windows selbst), Ihr E-Mail-Programm zu steuern und beispielsweise anzuweisen, eine neue Nachricht zu erstellen oder eine Datei anzuhängen.
<G-vec00407-001-s211><attach.anhängen><en> After you successfully attach the trailer, from that point on you get to drive a trailer truck.
<G-vec00407-001-s211><attach.anhängen><de> Nachdem Sie den Trailer erfolgreich anzuhängen, von da an um einen Anhänger LKW fahren zu bekommen.
<G-vec00407-001-s231><attach.befestigen><en> Heal the cat and attach the normal people.
<G-vec00407-001-s231><attach.befestigen><de> Heile die Katze und befestige die normalen Menschen.
<G-vec00407-001-s232><attach.befestigen><en> Sketch your design onto the stone directly using your wax pencil or marker, or attach the stencil to your stone.
<G-vec00407-001-s232><attach.befestigen><de> Skizziere mit deinem Wachsstift oder -marker dein Design direkt auf den Stein oder befestige die Schablone an deinem Stein.
<G-vec00407-001-s233><attach.befestigen><en> I like to attach it to almost every position I use my big dildo;) My fantasy knows no boundaries ..
<G-vec00407-001-s233><attach.befestigen><de> Ich befestige es gerne an fast jeder Position die ich mit meinem großen Dildo mache;) Meine Fantasie kennt keine Grenzen.
<G-vec00407-001-s234><attach.befestigen><en> Attach the bat house to the intended site.
<G-vec00407-001-s234><attach.befestigen><de> Befestige das Fledermaushäuschen an der vorgesehenen Stelle.
<G-vec00407-001-s235><attach.befestigen><en> Place Kai in the capsule, attach the blade and dragon wings, then pull the rip cord.
<G-vec00407-001-s235><attach.befestigen><de> Setz dann Kai in die Kapsel, befestige die Klinge und die Drachenflügel und zieh am Zugriemen.
<G-vec00407-001-s236><attach.befestigen><en> Attach the roof.
<G-vec00407-001-s236><attach.befestigen><de> Befestige das Dach.
<G-vec00407-001-s237><attach.befestigen><en> Attach a small cluster of feathers to the stick.
<G-vec00407-001-s237><attach.befestigen><de> Befestige ein kleines Bündel Federn am Stab.
<G-vec00407-001-s238><attach.befestigen><en> I mainly attach the leash on front to have more control (there are a lot of people complaining about the back hook wearing out nylon fast but it's too early to tell).
<G-vec00407-001-s238><attach.befestigen><de> Ich befestige die Leine hauptsächlich an der Front, um mehr Kontrolle zu haben (es gibt eine Menge Leute, die sich über den hinteren Haken beschweren, der das Nylon schnell abnutzt, aber es ist noch zu früh, um dies zu beurteilen).
<G-vec00407-001-s239><attach.befestigen><en> Please create your free Royal mail returns label here and attach this to the outside of your package.
<G-vec00407-001-s239><attach.befestigen><de> Drucke hier dein Etikett für kostenlose Rücksendung mit Royal Mail aus und befestige es an der Außenseite deiner Sendung.
<G-vec00407-001-s240><attach.befestigen><en> Attach the yarn to your crochet hook with a slipknot, then work up a foundation chain of 200 chain stitches.
<G-vec00407-001-s240><attach.befestigen><de> Befestige das Garn mit einem Slipknoten auf der Häkelnadel und häkle dann eine Luftmaschenkette aus 200 Luftmaschen.
<G-vec00407-001-s241><attach.befestigen><en> Attach the end of the string to a stick.
<G-vec00407-001-s241><attach.befestigen><de> Befestige das Ende der Schnur an einem Stab.
<G-vec00407-001-s242><attach.befestigen><en> Simply attach the minifigure to her LEGO Toy Tag and place her on the LEGO Toy Pad to bring her to life in the game.
<G-vec00407-001-s242><attach.befestigen><de> Befestige die Minifigur einfach an ihrem LEGO Tag und platziere sie auf dem LEGO Toypad, um sie im Spiel zum Leben zu erwecken.
<G-vec00407-001-s243><attach.befestigen><en> Attach the solar panel.
<G-vec00407-001-s243><attach.befestigen><de> Befestige das Solarpanel.
<G-vec00407-001-s244><attach.befestigen><en> Attach the bottom of the film.
<G-vec00407-001-s244><attach.befestigen><de> Befestige den unteren Teil der Folie.
<G-vec00407-001-s245><attach.befestigen><en> When you attach the base station to Isofix, this device provides more stability and greater security.
<G-vec00407-001-s245><attach.befestigen><de> Wenn Sie die Basisstation mit Isofix befestigen, sorgt diese Vorrichtung für mehr Stabilität und einer höheren Sicherheit.
<G-vec00407-001-s246><attach.befestigen><en> For this purpose it is necessary to plan a pencil a form and to attach wires in the relevant provision by means of thin tacks or stripes of an adhesive tape.
<G-vec00407-001-s246><attach.befestigen><de> Dazu muss man planen Bleistift die Form und die Leitungen in der entsprechenden Lage mit Hilfe fein gwosdikow oder polossotschek des Klebebandes befestigen.
<G-vec00407-001-s247><attach.befestigen><en> The saddle bagag has three karabiner hooks for easy, secure mounting to the saddle and a set of leather strings on each side to attach further luggage. (Jackets, blankets...)
<G-vec00407-001-s247><attach.befestigen><de> Die Tasche hat drei Karabinerhaken zur Befestigung am Sattel und pro Seite jeweils ein Paar Lederlaschen, um weiteres Gepäck (Jacke, Decke…) zu befestigen.
<G-vec00407-001-s248><attach.befestigen><en> The Selflock Hook Easy Wide is a fast and simple way to attach devices to a truss.
<G-vec00407-001-s248><attach.befestigen><de> Der Selflock Haken Easy Wide ist eine schnelle und einfache Möglichkeit, Geräte an einer Traverse zu befestigen.
<G-vec00407-001-s249><attach.befestigen><en> You are able to attach with YOOX through an range of social networking stations.
<G-vec00407-001-s249><attach.befestigen><de> Sie sind in der Lage, zu befestigen mit YOOX über eine Reihe von social-networking-Stationen.
<G-vec00407-001-s250><attach.befestigen><en> But at the seeming external simplicity such hairdresses are not always simple performed by: it is simple to comb hair and to attach a veil will be obviously insufficiently for creation of a beautiful wedding hairdress.
<G-vec00407-001-s250><attach.befestigen><de> Aber bei der scheinenden äußerlichen Einfachheit sind solche Frisuren nicht in der Erfüllung immer einfach: einfach wird rastschessat das Haar den Schleier offenbar ungenügend für die Bildung der schönen Hochzeitsfrisur eben befestigen.
<G-vec00407-001-s251><attach.befestigen><en> Easy to attach and operate . 3
<G-vec00407-001-s251><attach.befestigen><de> Einfach zu befestigen und zu betreiben.
<G-vec00407-001-s252><attach.befestigen><en> Gel extra strong, alcohol-free, to give form and attach hairstyles for a more defined look.
<G-vec00407-001-s252><attach.befestigen><de> Gel extra stark, alkoholfrei, nach Form zu geben und befestigen Frisuren für eine definierte Look.
<G-vec00407-001-s253><attach.befestigen><en> Construct a jumper on the floor and ceiling at the required distance from the wall and attach.
<G-vec00407-001-s253><attach.befestigen><de> Konstruieren Sie einen Jumper auf dem Boden und die Decke im erforderlichen Abstand von der Wand und befestigen.
<G-vec00407-001-s254><attach.befestigen><en> Critical has also included a magnetic mount with both tattoo power supplies, allowing artists to attach them to any magnetic surface, making them easy to reach while tattooing.
<G-vec00407-001-s254><attach.befestigen><de> Critical enthält auch eine Magnethalterung, die es Tätowierern ermöglicht, sie auf jeder magnetischen Oberfläche zu befestigen, sodass die beim Tätowieren leicht zu erreichen sind.
<G-vec00407-001-s255><attach.befestigen><en> The monster can attach a sticky thread to the wall and pull itself to move around, but it moves straight only, so you have to figure out how to navigate the level.
<G-vec00407-001-s255><attach.befestigen><de> Das Monster können einen sticky Thread an der Wand befestigen und ziehen sich bewegen, aber es bewegt sich gerade nur, Sie müssen also herausfinden, wie die Ebene navigieren.
<G-vec00407-001-s256><attach.befestigen><en> These silicone AirPod covers attach effortlessly to your earphones, providing a way to keep them safe, clean and looking great.
<G-vec00407-001-s256><attach.befestigen><de> Diese Silikon-AirPod-Abdeckungen lassen sich mühelos an Ihren Kopfhörern befestigen und bieten eine Möglichkeit, sie sicher, sauber und schön zu halten.
<G-vec00407-001-s257><attach.befestigen><en> It can also damage the lining of the bladder allowing the bacteria to attach more readily.
<G-vec00407-001-s257><attach.befestigen><de> Es kann auch die Auskleidung der die Bakterien ermöglicht Blase beschädigen leichter zu befestigen.
<G-vec00407-001-s258><attach.befestigen><en> This plate holder comes complete with stainless steel mounting material to attach your license plate to the plate holder.
<G-vec00407-001-s258><attach.befestigen><de> Dieser Plattenhalter wird komplett mit Edelstahl-Befestigungsmaterial geliefert, um Ihr Nummernschild am Plattenhalter zu befestigen.
<G-vec00407-001-s259><attach.befestigen><en> A possible application: Attach the inventory list directly on the steel shelf.
<G-vec00407-001-s259><attach.befestigen><de> Ein möglicher Einsatzbereich: Die Inventurliste direkt am Stahlregal befestigen.
<G-vec00407-001-s260><attach.befestigen><en> Velcro fasteners allow you to attach the RX-9T to the ceiling of a car, for example.
<G-vec00407-001-s260><attach.befestigen><de> Mit Klettverschlüssen können Sie das RX-9T beispielsweise an der Decke eines Autos befestigen.
<G-vec00407-001-s261><attach.befestigen><en> Sony Alpha A6300 Sony Alpha a6500 A hot shoe can be used to attach an external flash, as well as light meters, viewfinders, rangefinders and other attachments.
<G-vec00407-001-s261><attach.befestigen><de> Sony Alpha A6300 Sony Alpha a6500 Ein Zubehörschuh (Hot shoe) kann benutzt werden, um ein externes Blitzgerät zu befestigen, sowie Belichtungsmesser, Bildsucher, Entfernungsmesser und andere Geräte.
<G-vec00407-001-s262><attach.befestigen><en> This allows you to attach the battery adapter to your camera.
<G-vec00407-001-s262><attach.befestigen><de> Dadurch können sie den Batterieadapter an ihrer Kamera befestigen.
<G-vec00407-001-s263><attach.befestigen><en> I folded the butterfly wings where they attach to the body, using a ruler to make the fold straight.
<G-vec00407-001-s263><attach.befestigen><de> Ich gefaltet die Schmetterlingsflügel wo befestigen sie auf den Körper, mit einem Lineal die Falte gerade machen.
<G-vec00407-001-s264><attach.befestigen><en> • Locate the drain hose located in the installation kit and attach the fitting to the drain fitting on the back of the ADVANTAGE Plus.
<G-vec00407-001-s264><attach.befestigen><de> • Nehmen Sie den Ableitungsschlauch, der im Installationskit enthalten ist, und befestigen Sie in am Abflussanschluss auf der Rückseite des ADVANTAGE Plus.
<G-vec00407-001-s265><attach.befestigen><en> Also, the proper technique for carrying a canoe overland as well as how to safely and securely attach the canoe to your vehicle at trips end are important things that you will learn when you take wilderness canoes training.
<G-vec00407-001-s265><attach.befestigen><de> Auch die richtige Technik für die Durchführung ein Kanu Overland und wie sicher und befestigen Sie das Kanu an Ihrem Fahrzeug auf Reisen Ende sind wichtige Dinge, die man lernt, wenn man Wildnis Kanus Ausbildung übernehmen wird.
<G-vec00407-001-s266><attach.befestigen><en> Remove the receiver and attach the hose to the boss on its side then attach the other end to the boss on the left side of the Tremblr.
<G-vec00407-001-s266><attach.befestigen><de> Entfernen Sie den Empfänger und befestigen Sie den Schlauch an der Seite auf der Nabe und befestigen Sie das andere Ende an der Nabe auf der linken Seite des Tremblr.
<G-vec00407-001-s267><attach.befestigen><en> Remove the receiver and attach the hose to the boss on its side then attach the other end to the boss on the left side of the Tremblr.
<G-vec00407-001-s267><attach.befestigen><de> Entfernen Sie den Empfänger und befestigen Sie den Schlauch an der Seite auf der Nabe und befestigen Sie das andere Ende an der Nabe auf der linken Seite des Tremblr.
<G-vec00407-001-s268><attach.befestigen><en> Attach it to those small plastic container, stick it on drawers or any storage box and simply use a pen to write on it what you have stored inside.
<G-vec00407-001-s268><attach.befestigen><de> Befestigen Sie es auf Untergründen, kleben Sie es auf Schubladen oder eine beliebige Aufbewahrungsbox und schreiben Sie einfach mit einem Stift auf das, was Sie darin aufbewahrt haben.
<G-vec00407-001-s269><attach.befestigen><en> Attach the reader to your carâ€2s 16-pin port, which is usually located under the steering wheel.
<G-vec00407-001-s269><attach.befestigen><de> Befestigen Sie den Leser am 16-poligen Anschluss Ihres Autos, der sich normalerweise unter dem Lenkrad befindet.
<G-vec00407-001-s270><attach.befestigen><en> Attach any cinema lens to the viewfinder to get a true rendering of the image.
<G-vec00407-001-s270><attach.befestigen><de> Befestigen Sie jedes beliebige Filmobjektiv am Bildsucher um eine getreue photorealistische Visualisierung zu erhalten.
<G-vec00407-001-s271><attach.befestigen><en> By means of kruglogubets unbend connecting ringlets, fix them on caps and attach to them both parts of a lock.
<G-vec00407-001-s271><attach.befestigen><de> Bei der Hilfe kruglogubzew biegen Sie die Anschlussringel auseinander, festigen Sie sie auf den Blindverschlüssen und befestigen Sie an ihm beide Teile samotschka.
<G-vec00407-001-s272><attach.befestigen><en> Attach the cover reverse steps 1 and 2
<G-vec00407-001-s272><attach.befestigen><de> Befestigen Sie die Abdeckung entgegengesetzt der Schritte 1 und 2.
<G-vec00407-001-s273><attach.befestigen><en> Then you can place the bicycles one by one in the adjustable wheel channels and attach the frame brackets to the bicycles.
<G-vec00407-001-s273><attach.befestigen><de> Dann können Sie die Fahrräder nacheinander in die verstellbaren Radschienen, und befestigen Sie die Rahmenhalterungen an den Rädern.
<G-vec00407-001-s274><attach.befestigen><en> The vitreous is replaced by gas or silicone oil, in order to attach the retina again. Precaution
<G-vec00407-001-s274><attach.befestigen><de> Der Glaskörper wird durch Gas oder Silikonöl ersetzt, um die Netzhaut wieder zu befestigen, da sie nur durch den Druck des Glaskörpers in ihrer Lage gehalten wird.
<G-vec00407-001-s275><attach.befestigen><en> then attach any cold object to the damaged area - meat from the freezer, cold metal, or, ideally, an ice pack.
<G-vec00407-001-s275><attach.befestigen><de> Befestigen Sie dann einen kalten Gegenstand an der beschädigten Stelle - Fleisch aus dem Gefrierschrank, kaltes Metall oder idealerweise einen Eisbeutel.
<G-vec00407-001-s276><attach.befestigen><en> Attach the drive bracket to the machine using the nuts on the top bars.
<G-vec00407-001-s276><attach.befestigen><de> Befestigen Sie unter Verwendung der Muttern an den oberen Gewindestangen die Halteklammer an der Maschine.
<G-vec00407-001-s277><attach.befestigen><en> Simply attach the dartboard surrounds around the dartboard, clamps easily around a standard bristle dartboard, no fixings required.
<G-vec00407-001-s277><attach.befestigen><de> Befestigen Sie einfach die Dartscheibe umgibt auf der Dartscheibe, Klemmen Dartscheibe leicht um eine Standard-Borsten, keine Befestigungen erforderlich.
<G-vec00407-001-s278><attach.befestigen><en> PicNClic - Attach audio to picture, click the mouse or tap the screen to move to the next photo and sound clip.
<G-vec00407-001-s278><attach.befestigen><de> PicNClic - Befestigen Sie Audio zum Bild, klicken Sie mit der Maus oder auf den Bildschirm tippen, um zum nächsten Foto und Soundclip zu bewegen.
<G-vec00407-001-s279><attach.befestigen><en> Attach rods and springs to investigate simple pendulums, spring oscillations, Hooke's Law and rotational motion.
<G-vec00407-001-s279><attach.befestigen><de> Befestigen Sie Stäbe und Federn aneinander, um einfache Pendel, Federschwingungen, Hookesches Gesetz und Rotationsbewegung zu untersuchen.
<G-vec00407-001-s280><attach.befestigen><en> That it was not necessary to hold a hose a hand, to a wall at convenient height attach capture which will allow to place a grid in any position so that the water stream fell slantwise on shoulders and a thorax bathing irrespective of its growth.
<G-vec00407-001-s280><attach.befestigen><de> Damit man den Schlauch von der Hand nicht halten musste, befestigen Sie an der Wand in der bequemen Höhe die Ergreifung, die zulassen wird das Netz in einer beliebigen Lage so, dass der Strahl des Wassers zu unterbringen fiel schief auf die Schultern und den Brustkorb badend unabhängig von seiner Größe.
<G-vec00407-001-s281><attach.befestigen><en> Then, attach the clip to your monitor.
<G-vec00407-001-s281><attach.befestigen><de> Befestigen Sie den Clip dann an Ihrem Monitor.
<G-vec00407-001-s282><attach.befestigen><en> How to use it: Insert the photo into the frame from below and attach it to the twine with a clip.
<G-vec00407-001-s282><attach.befestigen><de> Wie man es benutzt: Legen Sie das Foto von unten in den Rahmen und befestigen Sie es mit einem Clip am Garn.
<G-vec00407-001-s283><attach.befestigen><en> Ligands contain polyunsaturated fatty acids that attach themselves to cholesterol and transport it to the liver for elimination, a function that avoids metabolic syndrome linked to hypertension
<G-vec00407-001-s283><attach.befestigen><de> Liganden enthalten ungesättigte Fettsäuren die sich an das Cholesterin befestigt und es zur Leber zur Beseitigung transportieren, eine Funktion die das metabolische Syndrom das zum Bluthochdruck führt verhindert.
<G-vec00407-001-s284><attach.befestigen><en> Made of a light Styrofoam tipped with a fishing line mount and a string to attach it to rod pod or rest.
<G-vec00407-001-s284><attach.befestigen><de> Hergestellt aus leichtem Styropor, ausgestattet mit einem Griff für die Angelschnur sowie mit einer Schnur, die an einem Träger oder Ständer befestigt ist.
<G-vec00407-001-s285><attach.befestigen><en> The Hartan Parasol is an ideal shade and is easy to attach at the Hartan stroller.
<G-vec00407-001-s285><attach.befestigen><de> Der Hartan Sonnenschirm ist ein idealer Schattenspender und wird einfach am Hartan Kinderwagen befestigt.
<G-vec00407-001-s286><attach.befestigen><en> They are easy to attach and are available in three different colors.
<G-vec00407-001-s286><attach.befestigen><de> Sie können einfach befestigt werden und sind dazu in drei unterschiedlichen Farben erhältlich.
<G-vec00407-001-s287><attach.befestigen><en> On the back there is a fastening, which makes it easy to attach, for example, to the belt in the trousers.
<G-vec00407-001-s287><attach.befestigen><de> Auf der Rückseite befindet sich eine Halterung, die zum Beispiel an dem Gürtel in der Hose leicht befestigt werden kann.
<G-vec00407-001-s288><attach.befestigen><en> These parts will attach securely to your engine in the space provided.
<G-vec00407-001-s288><attach.befestigen><de> Diese Teile können sicher an Ihrem Motor an der dafür vorgesehenen Stelle befestigt werden.
<G-vec00407-001-s289><attach.befestigen><en> The collar is a pretty standard design featuring a shiny riveted 'D' ring on the front for the leash to attach to.
<G-vec00407-001-s289><attach.befestigen><de> Das Halsband ist ein hübsches Standarddesign mit einem glänzenden D-Ring auf der Vorderseite, an dem die Leine befestigt werden kann.
<G-vec00407-001-s290><attach.befestigen><en> They will simply attach around your nipples thanks to their closure system.
<G-vec00407-001-s290><attach.befestigen><de> Sie werden einfach mit ihrem Schliesssystem um Ihre Brustwarzen befestigt.
<G-vec00407-001-s291><attach.befestigen><en> Thanks to the extremely strong embedded magnets, you can safely attach at least 8 knives with a weight of up to 900Â g.
<G-vec00407-001-s291><attach.befestigen><de> Dank der extrem starken verbauten Magnete können an diesem Messerblock mindestens 8 Messer mit bis zu 900 g Gewicht sicher befestigt werden.
<G-vec00407-001-s292><attach.befestigen><en> We do the third couple and we attach it to the first to two.
<G-vec00407-001-s292><attach.befestigen><de> Wir machen das dritte Paar und ist sie an ersten zwei befestigt.
<G-vec00407-001-s293><attach.befestigen><en> It's easy and fast to attach the Buggie to the double bass: the adjustable double belt system attaches to the neck of the double bass with a sturdy elastic strap, while the lower end of the Bass Buggie attaches to the endpin, which does not have to be removed.
<G-vec00407-001-s293><attach.befestigen><de> Der Bass Buggie kann in sehr kurzer Zeit am Kontrabass befestigt werden: das einstellbare Gürtelsystem wird mit einer strapazierfähigen, elastischen Schlaufe am Hals angebracht, während das andere Ende des Bass Buggies am Stachelhalter befestigt wird.
<G-vec00407-001-s294><attach.befestigen><en> The two support brackets are then deployed. These are used to attach the concreting platform to the formwork.
<G-vec00407-001-s294><attach.befestigen><de> Danach werden die beiden Anhängungen aufgeklappt, mit der die Betonierbühne an der Schalung befestigt wird.
<G-vec00407-001-s295><attach.befestigen><en> This wooden model, proposed by Master Series, is easy to install and has two removable fasteners, to attach to your subject's ankles.
<G-vec00407-001-s295><attach.befestigen><de> Dieses Holzmodell von Master Series ist einfach zu installieren und hat zwei abnehmbare Befestigungselemente, die an den Knöcheln des Untergebenen befestigt werden.
<G-vec00407-001-s296><attach.befestigen><en> It can also be used to attach paintings to the inside of transportation crates.
<G-vec00407-001-s296><attach.befestigen><de> So können Gemälde auch im Inneren der Transportkiste befestigt werden.
<G-vec00407-001-s297><attach.befestigen><en> The magnetic frames ensure that you can easily attach the various filters to the filter holder.
<G-vec00407-001-s297><attach.befestigen><de> Die Magnetrahmen sorgen dafür, dass die verschiedenen Filter einfach am Filterhalter befestigt werden können.
<G-vec00407-001-s298><attach.befestigen><en> In order to use it even more easily, but also in all situations, Doc Johnson has supplied this dildo with a Vac-U-Lock removable suction cup, which will attach securely to any smooth, flat surface.
<G-vec00407-001-s298><attach.befestigen><de> Um ihn noch einfacher, aber auch in allen Situationen benutzen zu können, liefert Doc Johnson diesen Dildo mit einem abnehmbaren Vac-U-Lock Saugnapf, der sicher an jeder glatten, ebenen Oberfläche befestigt werden kann.
<G-vec00407-001-s299><attach.befestigen><en> The larva to become an oyster needs to attach to a wall somewhere.
<G-vec00407-001-s299><attach.befestigen><de> Die Larve, die eine Auster werden soll, muss irgendwo an einer Wand befestigt werden.
<G-vec00407-001-s300><attach.befestigen><en> The white charging cable has a round head with two magnetic buttons that attach securely to your toy.
<G-vec00407-001-s300><attach.befestigen><de> Das weisse Ladekabel hat einen runden Kopf mit zwei Magnettasten, die sicher an Ihrem Sextoy befestigt werden können.
<G-vec00407-001-s301><attach.befestigen><en> Two brass mounting screws are provided to attach the cartridge to the shell.
<G-vec00407-001-s301><attach.befestigen><de> Mit den beiden mitgelieferten Messingschrauben wird der Tonabnehmer an der Headshell befestigt.
<G-vec00407-001-s321><attach.beifügen><en> You can unsubscribe at any time by following a link which we attach to all e-mails or by sending a message to the contact details set out above.
<G-vec00407-001-s321><attach.beifügen><de> Sie können sich jederzeit über einen Link, den wir jeder E-Mail beifügen, oder durch eine Nachricht an die oben angegebenen Kontaktdaten abmelden.
<G-vec00407-001-s322><attach.beifügen><en> If the TOP is to be dealt with in a particular Rectorate meeting, please attach an explanation/reason.
<G-vec00407-001-s322><attach.beifügen><de> Sitzungsdatum Wenn der TOP in einer bestimmten Rektoratssitzung behandelt werden soll, bitte Erläuterung/Begründung beifügen.
<G-vec00407-001-s323><attach.beifügen><en> As evidence of their entitlement, the heirs must attach copies of all documents which are liable to prove their entitlements.
<G-vec00407-001-s323><attach.beifügen><de> Als Berechtigungsnachweise müssen die Erben Kopien sämtlicher Dokumente beifügen, die ihre Anspruchsberechtigung nachweisen.
<G-vec00407-001-s324><attach.beifügen><en> Here you have the possibility to attach a file to your application.
<G-vec00407-001-s324><attach.beifügen><de> Hier haben Sie die Möglichkeit ihrer Bewerbung eine Datei beifügen.
<G-vec00407-001-s325><attach.beifügen><en> Attach my proof (invoice...).
<G-vec00407-001-s325><attach.beifügen><de> Meinen Beleg beifügen (Rechnung...).
<G-vec00407-001-s326><attach.beifügen><en> The list of mandatory schedules has changed – for instance, corporations are no longer required to attach an extract from the Commercial Register, or similar register, if the information is available on a remote access basis.
<G-vec00407-001-s326><attach.beifügen><de> Es kommt zu Änderungen in der Aufzählung der Pflichtanlagen – die Firmen zum Beispiel werden nicht mehr den Auszug aus dem Handelsregister oder einem anderen ähnlichen Register beifügen müssen, in dem sie eingetragen sind, sofern die in diesen Registern enthaltenen Angaben durch Fernzugriff ermittelbar sind.
<G-vec00407-001-s327><attach.beifügen><en> I will attach some of my bridal photos.
<G-vec00407-001-s327><attach.beifügen><de> Ich werde einige meiner Brautfotos beifügen.
<G-vec00407-001-s328><attach.beifügen><en> Send us a picture of your smile by Email (Attachment on Contact Form) or via Facebook (send a message and attach your smile).
<G-vec00407-001-s328><attach.beifügen><de> Schicke das Smile Foto per Email (Attachment im Kontakt-Formular) oder via Facebook (Message schicken und Bild beifügen).
<G-vec00407-001-s329><attach.beifügen><en> If you wish to attach a document to your email message, log in to My SVB with your DigiD code.
<G-vec00407-001-s329><attach.beifügen><de> "Wenn Sie eine Anlage beifügen wollen, melden Sie sich mit Ihrem DigiD über ""Meine SVB"" an."
<G-vec00407-001-s330><attach.beifügen><en> You are welcome to attach graphics, pictures or schematic representations.
<G-vec00407-001-s330><attach.beifügen><de> Gerne können Sie Grafiken, Bilder oder schematische Darstellungen beifügen.
<G-vec00407-001-s331><attach.beifügen><en> When you return goods, you can attach a copy of the invoice and write whether you want the money back or the goods exchanged with another product.
<G-vec00407-001-s331><attach.beifügen><de> Wenn Sie Waren zurückschicken, können Sie eine Kopie der Rechnung beifügen und schreiben, ob Sie das Geld zurückgeben oder die Waren mit einem anderen Produkt austauschen möchten.
<G-vec00407-001-s332><attach.beifügen><en> You can attach up to ten photographic or other graphic reproductions as representation of the design, particularly, to show the design from different angles.
<G-vec00407-001-s332><attach.beifügen><de> Sie können als Wiedergabe bis zu zehn Fotos oder sonstige grafische Darstellungen des Designs beifügen, insbesondere um das Design aus verschiedenen Perspektiven zu zeigen.
<G-vec00407-001-s333><attach.beifügen><en> When applying for admission through uni-assist, you always have to attach all certificates documenting your qualifications stated in the application form.
<G-vec00407-001-s333><attach.beifügen><de> Grundsätzlich müssen Sie alle Bildungsnachweise beifügen, die Ihre im Antragsformular angegebenen Qualifikationen belegen.
<G-vec00407-001-s334><attach.beifügen><en> Applicants who wish to explain unavoidable delays in their career development must therefore explicitly state the relevant circumstances in the proposal, covering letter and curriculum vitae and if necessary (if the circumstance is not self-explanatory) attach a short explanation.
<G-vec00407-001-s334><attach.beifügen><de> Antragstellende, die sich auf unvermeidbare Verzögerungen im wissenschaftlichen Werdegang berufen möchten, müssen daher im Antrag, im Anschreiben und im Lebenslauf ausdrücklich auf den jeweiligen Umstand hinweisen und gegebenenfalls (sofern dieser Umstand nicht selbsterklärend ist) eine kurze Erläuterung beifügen.
<G-vec00407-001-s335><attach.beifügen><en> If you would like to submit photos of antiques or art that you would like one of our purchase quote, you can use the forms that are listed below (you can attach all photos you want).
<G-vec00407-001-s335><attach.beifügen><de> Wenn Sie Fotos von Antiquitäten oder der Kunst, dass Sie eines unserer Einkaufsangebot gerne einreichen möchten, können Sie die Formulare, die unten aufgeführt sind (Sie können alle gewünschten Fotos beifügen).
<G-vec00407-001-s336><attach.beifügen><en> if the texts are not written in one of the five languages of publication (German, English, Spanish, Italian, French), please attach a brief summary in one of these languages.
<G-vec00407-001-s336><attach.beifügen><de> Für den Fall, daß diese Texte nicht in einer der fünf Sprachen geschrieben worden sind (deutsch, englisch, spanisch, italienisch, französisch), eine kurze Zusammenfassung in einer dieser Sprachen beifügen.
<G-vec00407-001-s337><attach.beimessen><en> We therefore reaffirm the importance we attach to mutually advantageous transatlantic defence industrial cooperation.
<G-vec00407-001-s337><attach.beimessen><de> Wir bekräftigen daher die Wichtigkeit, die wir einer für beide Seiten vorteilhaften transatlantischen Zusammenarbeit der Rüstungsindustrien beimessen.
<G-vec00407-001-s338><attach.beimessen><en> The SNB will, therefore, continue to attach great importance to the exchange rate when determining its monetary policy.
<G-vec00407-001-s338><attach.beimessen><de> Daher wird die SNB bei der Festlegung ihrer Geldpolitik dem Wechselkurs weiterhin große Bedeutung beimessen.
<G-vec00407-001-s339><attach.beimessen><en> With their mostly spectacularly appearances the car manufacturers demonstrate which importance they attach to the classic world fair.
<G-vec00407-001-s339><attach.beimessen><de> Die Autohersteller demonstrieren mit ihren meist spektakulären Auftritten, welchen Stellenwert die der Klassik-Weltmesse beimessen.
<G-vec00407-001-s340><attach.beimessen><en> Rooms are very clean, with window/balcony in every room, all rooms with attach bath, hot & cold shower.
<G-vec00407-001-s340><attach.beimessen><de> Zimmer sind sehr sauber, mit Fenster / Balkon in jedem Zimmer, alle Zimmer mit Bad beimessen, heiß & kalt Dusche.
<G-vec00407-001-s341><attach.beimessen><en> That being said, the concepts differ from each other in terms of the relative importance they attach to economic, social and environmental concerns and the prominence they give to present and future human welfare.
<G-vec00407-001-s341><attach.beimessen><de> Die Konzepte unterscheiden sich gleichwohl darin, welche relative Bedeutung sie jeweils ökonomischen, sozialen und ökologischen Belangen beimessen und welchen Stellenwert sie der menschlichen Wohlfahrt in Gegenwart und Zukunft zubilligen.
<G-vec00407-001-s342><attach.beimessen><en> "Through his arguments, Rid sets himself against the contentions of the ""mainstream"" military and security experts who attach ever-increasing importance to the Internet as a theatre of war and who put the threat it poses to modern, networked societies on a par with the menace of nuclear weapons."
<G-vec00407-001-s342><attach.beimessen><de> "Rid stellt sich in seiner Argumentation gegen die Vorstellung des ""Mainstreams"" der Militärs und Sicherheitsexperten, die dem Kriegsschauplatz Internet immer größere Bedeutung beimessen und die Bedrohung für die modernen, vernetzten Gesellschaften sogar mit der Bedrohung durch Nuklearwaffen in Kontext setzen."
<G-vec00407-001-s343><attach.beimessen><en> ◆ To assure to get good result, the asphalt binder that used to attach the Paving Mat to the road must be hot asphalt, but not emulsified asphalt.
<G-vec00407-001-s343><attach.beimessen><de> ◆ Versichern um gutes Ergebnis, der Asphalt-Binder zu erhalten, mit dem die Straße die Matte ebnet beimessen muss Heißasphalt, aber nicht emulgierte Asphalt sein.
<G-vec00407-001-s344><attach.beimessen><en> "The only important question is what social or moral significance we attach to their ""symptoms""."
<G-vec00407-001-s344><attach.beimessen><de> "Die einzig wichtige Frage ist, welche moralische oder soziale Bedeutung wir ihren „Symptomen"" beimessen."
<G-vec00407-001-s345><attach.beimessen><en> Evidently it’s a task to which many people attach great importance.
<G-vec00407-001-s345><attach.beimessen><de> Es handelt sich offensichtlich um eine Aufgabe, der viele große Bedeutung beimessen.
<G-vec00407-001-s346><attach.beimessen><en> The location of the Fraunhofer Project Group at BioPark Regensburg strongly believes that external university research institutes attach importance to dialogue with the University.
<G-vec00407-001-s346><attach.beimessen><de> Die Ansiedlung der Fraunhofer Projektgruppe im BioPark Regensburg bekundet das Gewicht, das außeruniversitäre Forschungsstätten dem Dialog mit der Universität beimessen.
<G-vec00407-001-s347><attach.beimessen><en> A client survey conducted by LGT in German-speaking countries in 2018 confirms that private banking clients from Germany, Austria and Switzerland attach great importance to sustainability.
<G-vec00407-001-s347><attach.beimessen><de> Eine 2018 im deutschsprachigen Raum durchgeführte Kundenbefragung der LGT bestätigt, dass Private-Banking-Kunden aus Deutschland, Österreich und der Schweiz dem Thema Nachhaltigkeit viel Bedeutung beimessen.
<G-vec00407-001-s348><attach.beimessen><en> "The only important question is what social or moral significance we attach to their ""symptoms""."
<G-vec00407-001-s348><attach.beimessen><de> "Die einzig wichtige Frage ist, welche moralische oder soziale Bedeutung wir ihren ""Symptomen"" beimessen."
<G-vec00407-001-s349><attach.beimessen><en> 1622 You need not trouble yourself much about X's ideas or attach importance to them.
<G-vec00407-001-s349><attach.beimessen><de> Du brauchst dich über Xs Ideen nicht sehr zu beunruhigen oder ihnen große Wichtigkeit beimessen.
<G-vec00407-001-s350><attach.beimessen><en> For 2015 we were able to almost double our exhibition space, which underscores the great importance we attach to this venue.
<G-vec00407-001-s350><attach.beimessen><de> Dass wir unsere Ausstellungsfläche in 2015 nahezu verdoppeln konnten, zeigt deutlich, welchen hohen Stellenwert wir der Ambiente beimessen.
<G-vec00407-001-s351><attach.beimessen><en> Those who believe in the ambivalence of everything good and bad, and are convinced to be able to actively influence this in their favour through ritually correct behaviour, will attach above-average importance to the rites within their culture.
<G-vec00407-001-s351><attach.beimessen><de> Wer an die Ambivalenz aller guten und schlechten Dinge glaubt und davon überzeugt ist, diese durch rituell korrektes Verhalten aktiv zu seinen Gunsten beeinflussen zu können, wird dem Ritual im Rahmen seiner Kultur überdurchschnittliche Bedeutung beimessen.
<G-vec00407-001-s626><attach.verbinden><en> And outside the studio, artistic practices attach to urban and planetary infrastructures and other sorts of expanded sites of practice that acknowledge one more thing: the materiality of the digital is not reducible to the screen, not to software, and not even to hardware.
<G-vec00407-001-s626><attach.verbinden><de> Und außerhalb des Ateliers verbinden sich künstlerische Praktiken mit städtischen und globalen Infrastrukturen und anderweitigen erweiterten Stätten der Praxis, die einen weiteren Aspekt anerkennen: Die Materialität des Digitalen ist nicht auf den Bildschirm, die Software, nicht einmal auf die Hardware reduzierbar.
<G-vec00407-001-s627><attach.verbinden><en> It is possible to arrive and differently: to the wind wheel established on a mast to attach the compressor which will be through a pipe or small diameter a flexible hose to swing in water air. On the hose end there should be a spray.
<G-vec00407-001-s627><attach.verbinden><de> Man kann und anders handeln: zum Windrad, das auf dem Mast bestimmt ist, den Kompressor zu verbinden, der durch das Rohr oder des kleinen Durchmessers der flexible Schlauch wird ins Wasser die Luft zu schwingen.
<G-vec00407-001-s628><attach.verbinden><en> On the outer edge of the package you can select which greeting you want to attach to the gift or what the occasion for the gift is.
<G-vec00407-001-s628><attach.verbinden><de> Auf der Außenkante der Verpackung können Sie ankreuzen, welchen guten Wunsch Sie mit dem Geschenk verbinden möchten oder was der Anlass für das Geschenk ist.
<G-vec00407-001-s629><attach.verbinden><en> Juwelier Kamerbeek BV has the right to reject orders or attach specific terms and conditions to the delivery, unless expressly stated otherwise.
<G-vec00407-001-s629><attach.verbinden><de> Juwelier Kamerbeek BV hat das Recht, Bestellungen abzulehnen oder gewisse Bedingungen mit der Lieferung zu verbinden, es sei denn, es wurde ausdrücklich anders bestimmt.
<G-vec00407-001-s630><attach.verbinden><en> Water heaters attach To a flue pipes from a roofing steel in the thickness of 0,8-1 mm, and diameter of connecting pipes should be not less than 80 mm for ГB-50 mm and ГB-80 mm and not 100 mm - for ГB-120.
<G-vec00407-001-s630><attach.verbinden><de> Die Wasserwärmer verbinden An den Schornstein von den Rohren aus dem Dachstahl von der Dicke 0,8-1 mm, wobei der Durchmesser der Anschlussrohre nicht weniger als 80 mm für AГB-50 mm und AГB-80 mm nicht 100 mm - für AГB-120 sein soll.
<G-vec00407-001-s631><attach.verbinden><en> Techniques derived from earlier forms of collage can help us move beyond the rather antiquated obsession with digital and analog, and toward discussions that attach to technical media culture and the arts in new ways.
<G-vec00407-001-s631><attach.verbinden><de> Techniken, die aus früheren Formen der Collage abgeleitet sind, können uns helfen, über die eher antiquierte Obsession mit dem Digitalen und Analogen hinaus zu kommen und uns Diskussionen zuzuwenden, die sich auf neue Weisen mit technischer Medienkultur und den Künsten verbinden.
<G-vec00407-001-s632><attach.verbinden><en> Velcro straps attach the Caddy securely to the saddle rails and seat post.
<G-vec00407-001-s632><attach.verbinden><de> Klettbänder verbinden die Tasche sicher mit den Sattelstreben und der Sattelstütze.
<G-vec00407-001-s633><attach.verbinden><en> Polonium, cerium, and alkylating agents attach to each other in random combinations, yet only one of the many different combinations is ever found in cancer patients and is never found in healthy people.
<G-vec00407-001-s633><attach.verbinden><de> Cerium und Alkylierungsmittel verbinden sich in zufälligen Kombinationen miteinander, bislang wurde nur eine der vielen verschiedenen Kommbination in Krebspatienten gefunden, aber nie bei gesunden Menschen.
<G-vec00407-001-s634><attach.verbinden><en> The mind can attach itself to the body, to every single cell of the body, and it can detach itself from it.
<G-vec00407-001-s634><attach.verbinden><de> Der Verstand kann sich mit dem Leib verbinden, mit jeder einzelnen Zelle des Leibes, und er kann sich davon lösen.
<G-vec00407-001-s635><attach.verbinden><en> The striking contrast of jet black and red gold plays across the design of the unusual oval dial, set almost like a jewel between the extra-long lugs which attach it to the luxurious satin strap.
<G-vec00407-001-s635><attach.verbinden><de> Das ungewöhnliche ovale Zifferblatt, das fast wie ein Juwel zwischen den extralangen Bandanstößen sitzt, die es mit dem edlen Satinarmband verbinden, spielt mit dem eindrucksvollen Kontrast zwischen tiefem Schwarz und Rotgold.
<G-vec00407-001-s636><attach.verbinden><en> To move and attach the selected tracks, right click with the mouse over one of them and select “Move” from the context menu.
<G-vec00407-001-s636><attach.verbinden><de> Um ausgewählte Gleisabschnitte zu verschieben und zu verbinden, klicken Sie ein Element des Abschnitts mit der rechten Maustaste an und wählen Sie “Verschieben”.
<G-vec00407-001-s637><attach.verbinden><en> In this menu item you can attach a disk image to 1 of the 4 virtual disk drives.
<G-vec00407-001-s637><attach.verbinden><de> In dieser Menüwahl können Sie eine Diskette zu einem der 4 virtuellen Laufwerke verbinden.
<G-vec00407-001-s638><attach.verbinden><en> All posts Engine mounts attach the engine to the pylons.
<G-vec00407-001-s638><attach.verbinden><de> Alle Beiträge Triebwerksaufhängungen verbinden das Triebwerk mit der Triebwerksgondel.
<G-vec00407-001-s639><attach.verbinden><en> the Copper attach to a flue by means of pipes from a roofing tin (thickness of 0,8-1 mm), diameter of connecting pipes is not less diameter of a branch pipe.
<G-vec00407-001-s639><attach.verbinden><de> den Kessel verbinden an den Schornstein mit Hilfe der Rohre aus dach- schesti (die Dicke 0,8-1 mm), den Durchmesser der Anschlussrohre gibt es mehreren Durchmesser des Stutzens nicht.
<G-vec00407-001-s640><attach.verbinden><en> We attach emotions to results because that’s the best way to move towards success, whatever the pursuit may be.
<G-vec00407-001-s640><attach.verbinden><de> Wir verbinden Emotionen zu Ergebnissen, denn das ist die beste Art, erfolgreich zu sein, egal, wonach wir streben.
<G-vec00407-001-s641><attach.verbinden><en> One example of the fruits of the meeting of the General Chapter is the Confraternity of St. Peter itself. Six years ago it was suggested by a number of priests that a group be established for the laity which would allow them to concretely attach themselves spiritually to the work of our Society of Apostolic Life.
<G-vec00407-001-s641><attach.verbinden><de> Ein Beispiel für die Früchte des Generalkapitels ist die Konfraternität selbst: Vor sechs Jahren brachte eine Reihe von Priestern das Anliegen vor, für die Gläubigen eine konkrete Möglichkeit zu schaffen, sich geistlich mit dem Wirken unserer Gesellschaft apostolischen Lebens zu verbinden.
<G-vec00407-001-s642><attach.verbinden><en> DEFAULTMEDIASERVER specifies the media server to which you want the Desktop Agent to attach after installation.
<G-vec00407-001-s642><attach.verbinden><de> DEFAULTMEDIASERVER gibt den Medienserver an, mit dem Sie Desktop Agent nach Installation verbinden möchten.
<G-vec00407-001-s643><attach.verbinden><en> It aids to create breast cells and enlarge the breasts by lengthening the ducts that attach to the nipple, along with boost the cellulite as well as tendons which offer breasts their assistance and shape.
<G-vec00407-001-s643><attach.verbinden><de> Es hilft Brustgewebe sowie zu erweitern, um die Brüste zu entwickeln, indem die Kanäle erstrecken, die auf die Brustwarze verbinden, zusammen mit den Fettzellen steigen und auch Bänder, die Brüste ihre Unterstützung und auch bilden.
<G-vec00407-001-s644><attach.verbinden><en> The reversible USB 3.1 Type-C™ connector is the same at both ends and on both sides, so it's easy to attach.
<G-vec00407-001-s644><attach.verbinden><de> Der wendbare USB 3.1 Type-CTM-Stecker ist auf beiden Seiten sowie an beiden Enden identisch und deshalb viel einfacher zu verbinden.
<G-vec00407-001-s645><attach.verbinden><en> Note: If you want to perform AVCHD video file recovery from any external drive, then attach it to the computer on which you have installed the software.
<G-vec00407-001-s645><attach.verbinden><de> Hinweis: Wenn Sie die AVCHD-Videodateiwiederherstellung von einem externen Laufwerk durchführen möchten, verbinden Sie sie mit dem Computer, auf dem Sie die Software installiert haben.
<G-vec00407-001-s646><attach.verbinden><en> To serve, pour 6 to 8 ounces into a very clean glass bottle, attach nipple and set in a pan of simmering water.
<G-vec00407-001-s646><attach.verbinden><de> Um zu dienen, gießen Sie 6 - 8 Unzen in die sehr reine Glasflasche aus, verbinden Sie cocok und den Satz im Kochtopf des Kochens des Wassers.
<G-vec00407-001-s647><attach.verbinden><en> Insert the cables plug and then attach the other end to a power source to commence charging.
<G-vec00407-001-s647><attach.verbinden><de> Stecken Sie den Kabelstecker ein und verbinden Sie das andere Ende mit einer Stromquelle, um mit dem Aufladen zu beginnen.
<G-vec00407-001-s648><attach.verbinden><en> Attach devices to theRing networkorEthernetshape using the shape's built-in connectors.
<G-vec00407-001-s648><attach.verbinden><de> Verbinden Sie die Geräte durch den eingebauten Verbinder mit den Formen Ringnetz oder Ethernet.
<G-vec00407-001-s649><attach.verbinden><en> The way it works is relatively simple: Each player generate a ‘seed’ (a string of random characters) and attach it to the create or join request.
<G-vec00407-001-s649><attach.verbinden><de> Die Funktionsweise ist relativ einfach: Jeder Spieler erzeugt eine ‚Samen‘ (eine Folge von zufälligen Zeichen) und verbinden Sie es mit dem Erstellen oder Anforderung beitreten.
<G-vec00407-001-s650><attach.verbinden><en> Start up a spiral from an additional wire on 15 rounds, attach a small branch and make 15 more turns.
<G-vec00407-001-s650><attach.verbinden><de> Lassen Sie die Spirale aus dem zusätzlichen Draht auf 15 Windungen, verbinden Sie klein wetotschku und machen Sie noch 15 Wendungen.
<G-vec00407-001-s651><attach.verbinden><en> In the case where you have formatted the entire hard drive, disconnect the hard drive and attach it to a healthy computer (having the recovery software) as a secondary drive.
<G-vec00407-001-s651><attach.verbinden><de> In dem Fall, dass Sie die gesamte Festplatte formatiert, trennen Sie die Festplatte und verbinden Sie es mit einem gesunden Computer (mit der Wiederherstellung-Software) als sekundäres Laufwerk.
<G-vec00407-001-s652><attach.verbinden><en> Attach the second branch and make 15 more spiral turns.
<G-vec00407-001-s652><attach.verbinden><de> Verbinden Sie zweite wetotschku und machen Sie noch 15 Windungen der Spirale.
<G-vec00407-001-s653><attach.verbinden><en> Attach the other end of the wire at the edge of the reflector.
<G-vec00407-001-s653><attach.verbinden><de> Das andere Ende des Fadens verbinden Sie mit einer Heftklammer am Parabolspiegel.
<G-vec00407-001-s654><attach.verbinden><en> Attach one end of the USB to the printer and the other end to the printer server.
<G-vec00407-001-s654><attach.verbinden><de> Verbinden Sie das eine Ende des USB-Kabels mit dem Drucker und das andere mit dem Druckserver.
<G-vec00407-001-s655><attach.verbinden><en> 2.2 Accessing Removable Media # To access CDs/DVDs or flash disks, insert or attach the medium.
<G-vec00407-001-s655><attach.verbinden><de> Zum Zugriff auf CDs/DVDs oder Flashlaufwerke legen Sie das entsprechende Medium ein (oder verbinden Sie das Medium).
<G-vec00407-001-s656><attach.verbinden><en> In the case where you have formatted the entire hard drive, disconnect the hard drive and attach it to a healthy computer (having the recovery software) as a secondary drive.
<G-vec00407-001-s656><attach.verbinden><de> In dem Fall, dass Sie die gesamte Festplatte formatiert, trennen Sie die Festplatte und verbinden Sie es mit einem gesunden Computer (mit der recovery-Software) als sekundäres Laufwerk.
