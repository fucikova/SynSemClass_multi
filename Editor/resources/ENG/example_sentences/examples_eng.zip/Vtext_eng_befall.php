<G-vec00372-002-s036><befall.befallen><en> whereby I am able to recognise and resolve the committed errors, which befall me on the way of my development.
<G-vec00372-002-s036><befall.befallen><de> wodurch ich die begangenen Fehler zu erkennen und zu beheben vermag, die mich auf dem Weg meiner Entwicklung befallen.
<G-vec00372-002-s035><befall.begegnen><en> 4 But Benjamin, Joseph's brother, Jacob sent not with his brethren: for he said, Lest perhaps mischief shall befall him.
<G-vec00372-002-s035><befall.begegnen><de> 4Aber den Benjamin, Josefs Bruder, ließ Jakob nicht mit seinen Brüdern ziehen; denn er sprach: Es könnte ihm ein Unfall begegnen.
<G-vec00372-002-s020><befall.blühen><en> A rigorous move like that could befall any digital photo archive too, if we’re not careful.
<G-vec00372-002-s020><befall.blühen><de> So ein rigoroser Schritt könnte auch jedem digitalen fotografischen Archiv blühen, wenn man nicht aufpasst.
<G-vec00372-002-s023><befall.ereignen><en> Rigby – Another main character, which befall a variety of funny situations.
<G-vec00372-002-s023><befall.ereignen><de> Rigby – Eine weitere Hauptfigur, die eine Vielzahl von lustigen Situationen ereignen.
<G-vec00372-002-s026><befall.geschehen><en> Then I hold my hand protectively over you and let no harm befall you.
<G-vec00372-002-s026><befall.geschehen><de> Dann halte Ich Meine Hand schützend über euch und lasse euch kein Leid geschehen.
<G-vec00372-002-s027><befall.herausfallen><en> Additionally brings a risk of embarrassment, as they can be seen or befall sometimes.
<G-vec00372-002-s027><befall.herausfallen><de> Auch birgt das Risiko einer Verlegenheit, da sie manchmal zu sehen oder herausfallen können.
<G-vec00372-002-s028><befall.herausfallen><en> Likewise brings a risk of shame, as they could be seen or befall sometimes.
<G-vec00372-002-s028><befall.herausfallen><de> Trägt auch eine Bedrohung der Scham, wie sie gesehen werden könnte, oder manchmal herausfallen.
<G-vec00372-002-s029><befall.hereinbrechen><en> You have to make a change, and then all manner of goodness will befall you.
<G-vec00372-002-s029><befall.hereinbrechen><de> Du musst eine Änderung vornehmen, und danach wird alle Güte auf dich hereinbrechen.
<G-vec00372-002-s030><befall.kommen><en> When the Prophet Joseph Smith was a prisoner in Liberty Jail, the Lord declared to him that multiple calamities can befall mankind.
<G-vec00372-002-s030><befall.kommen><de> Als der Prophet Joseph Smith im Gefängnis zu Liberty gefangen war, ließ der Herr ihn wissen, dass viel Unheil über den Menschen kommen kann.
<G-vec00372-002-s031><befall.kommen><en> The undamaged right hand is raised in blessing and pointing to heaven, as if to convey to us through the almost miraculous preservation of the statue this admonition: Whatever may befall, hold firm to the Catholic faith that was revealed by God and handed down by our forefathers.
<G-vec00372-002-s031><befall.kommen><de> Segnend und zum Himmel weisend erhebt er die unbeschädigt gebliebene rechte Hand, gleich als sollte uns durch die fast wunderbare Errettung dieses Bildes die Mahnung zugerufen werden: "Was auch kommen mag, haltet fest an dem von Gott geoffenbarten, von den Vorfahren ererbten katholischen Glauben.
<G-vec00372-002-s021><befall.treffen><en> However, worse will befall on this earth if people still, like Pharaoh, will ignore the signs of the times and it will be too late.
<G-vec00372-002-s021><befall.treffen><de> Unabhängig davon wird noch Schlimmeres die Erde treffen, wenn die Menschen, wie der Pharao, weiterhin die Zeichen der Zeit ignorieren, und dann wird es zu spät sein.
<G-vec00372-002-s037><befall.vorgesehen><en> The same fate would befall all those officers who, even for a single moment, expressed any doubts about tactics imposed by the Supreme Command.
<G-vec00372-002-s037><befall.vorgesehen><de> Gleiches Schicksal wurde für alle jene Offiziere vorgesehen, die auch nur für einen Moment an der vom Oberkommando auferlegten Taktik gezweifelt hätten.
<G-vec00372-002-s046><befall.widerfahren><en> She sighed and silently prayed that similar experience did not befall her.
<G-vec00372-002-s046><befall.widerfahren><de> Sie seufzte und betete schweigend, dass ihr ähnliche Erfahrungen nicht widerfahren würden.
<G-vec00372-002-s038><befall.zustoßen><en> The liability for accidents that may befall such persons at the production facility is excluded, insofar as the accident was not caused by an intentional or grossly negligent breach of duty on the part of our legal representatives or vicarious agents.
<G-vec00372-002-s038><befall.zustoßen><de> Die Haftung für Unfälle, die diesen Personen auf dem Werkgelände zustoßen, ist ausgeschlossen, soweit diese nicht durch vorsätzliche oder grob fahrlässige Pflichtverletzung unserer gesetzlichen Vertreter oder Erfüllungsgehilfen verursacht wurde.
<G-vec00372-002-s048><befall.zutragen><en> A time will come when your desire is enough, and all will befall as you desire.
<G-vec00372-002-s048><befall.zutragen><de> Eine Zeit wird kommen, wann dein Bestreben ausreichend ist, und alles wird sich zutragen, wie du es erstrebst.
