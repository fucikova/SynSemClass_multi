<G-vec00038-002-s038><activate.aktivieren><en> 7 Next → Please activate some Widgets.
<G-vec00038-002-s038><activate.aktivieren><de> 7 Next → Bitte aktiviere ein paar Widgets.
<G-vec00038-002-s039><activate.aktivieren><en> Activate only when a monster you control inflicts Battle Damage to your opponent by a direct attack.
<G-vec00038-002-s039><activate.aktivieren><de> Aktiviere nur, wenn ein Monster, das du kontrollierst, deinen Gegner direkt angreift.
<G-vec00038-002-s040><activate.aktivieren><en> select the city where you are now: Please select the region where you are now: Please select the country where you are now: Any country Any region Any city Any station. Activate VIP change your country without any restrictions.
<G-vec00038-002-s040><activate.aktivieren><de> Bitte wähle die Stadt in der du dich jetzt befindest: Bitte wähle deine jetzige Region: Wähle das Land in dem du wohnst: Beliebiges LandBeliebige RegionBeliebige StadtBeliebige Haltestation, aktiviere den VIP Status, um die Länderauswahl ohne Beschränkungen zu wählen.
<G-vec00038-002-s041><activate.aktivieren><en> Activate Finn's sword to grapple and deflect lasers when solving puzzles and fighting enemies.
<G-vec00038-002-s041><activate.aktivieren><de> Aktiviere Finns Schwert, um zu greifen und Laser abzuwehren, wenn du Rätsel löst und Gegner bekämpfst.
<G-vec00038-002-s042><activate.aktivieren><en> 10 10 Bronze Team Building 101 Activate two Chemistries at the same time.
<G-vec00038-002-s042><activate.aktivieren><de> 10 10 Aktiviere zwei Chemistry-Werte zur selben Zeit.
<G-vec00038-002-s043><activate.aktivieren><en> Install and activate the WordPress plugin, then add the shortcode to a blog post or page, and On The Run The Getaway will appear on your WordPress site.
<G-vec00038-002-s043><activate.aktivieren><de> Installiere und aktiviere das WordPress-Plug-In und füge danach den Kurzcode zu einem Blog-Beitrag oder zu einer Seite hinzu, dann wird On The Run The Getaway auf deiner WordPress-Website angezeigt.
<G-vec00038-002-s044><activate.aktivieren><en> 3: Activate this checkbox, when you want to tease this promotion in the listing using a badge.
<G-vec00038-002-s044><activate.aktivieren><de> 3: Aktiviere dieses Häkchen, wenn die Aktion im Listing mittels Badge geteasert werden soll.
<G-vec00038-002-s045><activate.aktivieren><en> If the program of your choice is currently not open for application, please register in our job board and activate a Job Agent.
<G-vec00038-002-s045><activate.aktivieren><de> Noch ein Tipp: Sollte keine passende Stelle dabei sein, aktiviere einfach unseren Jobagenten.
<G-vec00038-002-s046><activate.aktivieren><en> Under Select scopes, activate repo:status to access the commit status.
<G-vec00038-002-s046><activate.aktivieren><de> Aktiviere im Menü Select scopes das Kontrollkästchen repo:status.
<G-vec00038-002-s047><activate.aktivieren><en> Install and activate the WordPress plugin, then add the shortcode to a blog post or page, and Skateboard Jam will appear on your WordPress site.
<G-vec00038-002-s047><activate.aktivieren><de> Installiere und aktiviere das WordPress-Plug-In und füge danach den Kurzcode zu einem Blog-Beitrag oder zu einer Seite hinzu, dann wird London 2012 Olympic Games auf deiner WordPress-Website angezeigt.
<G-vec00038-002-s048><activate.aktivieren><en> Activate the plugin at “Dashboard – Plugins” administration page.
<G-vec00038-002-s048><activate.aktivieren><de> Aktiviere das Plugin auf der Administrationsseite „Dashboard – Plugins“.
<G-vec00038-002-s049><activate.aktivieren><en> Install and activate the WordPress plugin, then add the shortcode to a blog post or page, and RotorStorm will appear on your WordPress site.
<G-vec00038-002-s049><activate.aktivieren><de> Installiere und aktiviere das WordPress-Plug-In und füge danach den Kurzcode zu einem Blog-Beitrag oder zu einer Seite hinzu, dann wird Dino Strike auf deiner WordPress-Website angezeigt.
<G-vec00038-002-s050><activate.aktivieren><en> Instead of worrying about having the monster with the highest ATK, activate "Last Turn" when you have "Jowgen the Spiritualist" on the field.
<G-vec00038-002-s050><activate.aktivieren><de> Anstatt dich darum zu sorgen, das Monster mit den höchsten ATK zu haben, aktiviere "Letzter Spielzug", wenn du "Jaugen, der Spiritist" auf dem Spielfeld hast.
<G-vec00038-002-s051><activate.aktivieren><en> Install and activate the WordPress plugin, then add the shortcode to a blog post or page, and Zombie Big Trouble will appear on your WordPress site.
<G-vec00038-002-s051><activate.aktivieren><de> Installiere und aktiviere das WordPress-Plug-In und füge danach den Kurzcode zu einem Blog-Beitrag oder zu einer Seite hinzu, dann wird Zombie Big Trouble auf deiner WordPress-Website angezeigt.
<G-vec00038-002-s052><activate.aktivieren><en> Thus, even though I don’t understand how Segula works, I activate it by carrying out the conditions I am told about.
<G-vec00038-002-s052><activate.aktivieren><de> Obwohl es unverständlich ist, wie Segula funktioniert, aktiviere ich sie, indem ich versuche die vorgegebenen Bedingungen einzuhalten.
<G-vec00038-002-s053><activate.aktivieren><en> Make sure that you activate the flight mode first in your settings app (the one with the gear).
<G-vec00038-002-s053><activate.aktivieren><de> Bitte aktiviere zuerst den Flugmodus in den iOS Einstellungen.
<G-vec00038-002-s054><activate.aktivieren><en> Start Unetbootin, activate "Diskimage", select the ISO-Snapshot (should be in /home/snapshot) and select the USB-target drive.
<G-vec00038-002-s054><activate.aktivieren><de> Starte Unetbootin, aktiviere "Diskimage", wähle den ISO-Snapshot (sollte in /home/snapshot liegen) und wähle das USB-Ziellaufwerk aus.
<G-vec00038-002-s055><activate.aktivieren><en> Then activate the boom to lower the gigantic, digging bucket wheel and convey the mined material to the waiting mine truck.
<G-vec00038-002-s055><activate.aktivieren><de> Aktiviere dann den Ausleger, um das gigantische Schaufelrad zum Graben abzusenken - und befördere den Aushub in den wartenden Muldenkipper.
<G-vec00038-002-s056><activate.aktivieren><en> Activate the plugin in the Plugin options.
<G-vec00038-002-s056><activate.aktivieren><de> Aktiviere das Plugin in den Plugin-Einstellungen.
<G-vec00038-002-s057><activate.aktivieren><en> Karta Trap You can only activate this card when an Attack Position monster on your side of the field that includes "Destiny Hero" in its card name is selected as an attack target.
<G-vec00038-002-s057><activate.aktivieren><de> Karta Trap Du kannst diese Karte nur aktivieren, wenn ein Monster auf deiner Spielfeldseite in Angriffsposition als Angriffsziel bestimmt wurde, dessen Kartenname "Schicksalsheld" enthält.
<G-vec00038-002-s058><activate.aktivieren><en> These messages activate a natural process that brings your nervous system back into balance.
<G-vec00038-002-s058><activate.aktivieren><de> Diese Signale aktivieren einen natürlichen Prozess, der Ihr Nervensystem wieder ins Gleichgewicht bringt.
<G-vec00038-002-s059><activate.aktivieren><en> If you use GarageBand (or Logic) you may not be able to activate the plugin inside the DAW.
<G-vec00038-002-s059><activate.aktivieren><de> Wenn du GarageBand (oder Logic) benutzt, kann es vorkommen, dass du das Plugin nicht auf anhieb aktivieren kannst.
<G-vec00038-002-s060><activate.aktivieren><en> Here, you activate showers or jet types simply at the touch of a button.
<G-vec00038-002-s060><activate.aktivieren><de> Brausen oder Strahlarten aktivieren Sie hier einfach auf Knopfdruck.
<G-vec00038-002-s061><activate.aktivieren><en> To ensure this, we use the so-called double opt-in method, meaning after the initial registration, the interested party receives an e-mail and must re-confirm to activate the subscription by clicking on a confirmation button.
<G-vec00038-002-s061><activate.aktivieren><de> Um dies sicher zu stellen verwenden wir die sogenannte Double-opt-in Methode, bei der nach der initialen Registrierung ein weiteres Mail an den Interessenten verschickt wird, in dem er aufgefordert wird, seine Registrierung zu aktivieren, indem er auf einen Bestätigungslink klickt.
<G-vec00038-002-s062><activate.aktivieren><en> The new build offers the possibility to activate/deactivate SSL/TLS inspection rules independently via a new toggle.
<G-vec00038-002-s062><activate.aktivieren><de> Der neue Build bietet die Möglichkeit, SSL/TLS-Inspektionsregeln über einen neuen Schalter selbständig zu aktivieren/deaktivieren.
<G-vec00038-002-s063><activate.aktivieren><en> You have five attempts to activate your card.
<G-vec00038-002-s063><activate.aktivieren><de> Sie haben fünf Versuche, Ihre Karte zu aktivieren.
<G-vec00038-002-s064><activate.aktivieren><en> All the user has to do is to activate the text module once for the “insert automatically” feature.
<G-vec00038-002-s064><activate.aktivieren><de> Dann reicht es den entsprechenden Textbaustein einmal für das “automatische Einfügen” zu aktivieren.
<G-vec00038-002-s065><activate.aktivieren><en> On this page, in addition to being able to upload licenses to the license pool, you can activate, deactivate, and delete selected licenses.
<G-vec00038-002-s065><activate.aktivieren><de> Neben der Möglichkeit Lizenzen auf dieser Seite hochzuladen, haben Sie auf dieser Seite auch die Möglichkeit, ausgewählte Lizenzen zu aktivieren, zu deaktivieren und zu löschen.
<G-vec00038-002-s066><activate.aktivieren><en> 2Purchase PDFelement To get the full version of Wondershare PDFelement, you need purchase the license to activate it.
<G-vec00038-002-s066><activate.aktivieren><de> Um die Vollversion von Wondershare PDFelement 6 zu erhalten, müssen Sie diese mit einem gültigen Registrierungscode aktivieren.
<G-vec00038-002-s067><activate.aktivieren><en> A: Even in this scenario, you can activate the effect of a Lunalight Black Sheep that was sent to the Graveyard as Fusion Material for a Fusion Summon.
<G-vec00038-002-s067><activate.aktivieren><de> A: Du kannst den Effekt, der durch Wolkiger-Wettermaler Pattern (“Cloudy Weathery Pattern”) erhalten wurde aktivieren, solange sich ein anderes Monster zum Wählen auf dem Feld befindet.
<G-vec00038-002-s068><activate.aktivieren><en> If you've previously purchased Seven Seas Solitaire game from us, you can download the trial version and activate your Seven Seas Solitaire game by selecting the option "Already Purchased This game?" from the Game Manager.
<G-vec00038-002-s068><activate.aktivieren><de> Wenn Du zuvor bereits ein Seven Seas Solitaire bei uns gekauft hast, kannst Du die Demoversion herunterladen und Dein Seven Seas Solitaire durch Wahl der Option "Wurde dieses Spiel bereits gekauft?” im Game Manager aktivieren.
<G-vec00038-002-s069><activate.aktivieren><en> Click here to activate the free Koko risk management tool Practical implementation
<G-vec00038-002-s069><activate.aktivieren><de> Klicken Sie hier um das Koko Risk Management Tool über den Store kostenfrei zu aktivieren.
<G-vec00038-002-s070><activate.aktivieren><en> Besafemail is very easy to use, you can activate your account in only one click and it's completely free up to 25 MB of space used.
<G-vec00038-002-s070><activate.aktivieren><de> Besafemail ist sehr einfach zu bedienen, können Sie Ihr Konto aktivieren, klicken Sie einfach nur und es ist völlig kostenlos bis zu 25 MB Speicherplatz verwendet.
<G-vec00038-002-s071><activate.aktivieren><en> From the time of the complaint forward you can reclaim the overcharged rent from the landlord. The devil is in the details: the tenant has to “activate“ the rent control by issuing a so-called qualified complaint (qualifizierte Rüge).
<G-vec00038-002-s071><activate.aktivieren><de> Der Teufel steckt aber im Detail: Der Mieter muss die Mietpreisbremse mittels eines Anspruchschreibens aktivieren, sonst kann der Vermieter die zu viel erhaltene Miete einfach behalten.
<G-vec00038-002-s072><activate.aktivieren><en> To use your remote control, exit the pairing mode by clicking on any button on the remote control. To be able to use the pause mode from the remote control, remember to activate it on the camera.
<G-vec00038-002-s072><activate.aktivieren><de> Beenden Sie zum Nutzen Ihrer Fernbedienung den Pairingmodus, indem Sie eine beliebige Taste auf der Fernbedienung drücken.Denken Sie daran, den Pausenmodus an der Kamera zu aktivieren, um ihn über die Fernbedienung auswählen zu können.
<G-vec00038-002-s073><activate.aktivieren><en> * Please bear in mind: Do not plug SILENT-Plug into amplifier output / Not effective when tip-ring-sleeve jacks activate power supply
<G-vec00038-002-s073><activate.aktivieren><de> Immer beachten: SILENT-Plug nicht in den Verstärkerausgang stecken / Funktioniert nicht, wenn die Klinkenstecker die Stromversorgung der Gitarre aktivieren.
<G-vec00038-002-s074><activate.aktivieren><en> To activate the menu reorganization, a teachers or students group must exist in the system and the user has to be a member of one of these two groups. Upload screenshot Gamine
<G-vec00038-002-s074><activate.aktivieren><de> Um die Reorganisation des Menüs zu aktivieren, muss im System eine Lehrer- oder eine Schülergruppe vorhanden sein und der Benutzer muss ein Mitglied einer dieser beiden Gruppen sein.
<G-vec00038-002-s075><activate.aktivieren><en> To successfully activate a boot environment, that boot environment must meet several conditions.
<G-vec00038-002-s075><activate.aktivieren><de> Um eine Boot-Umgebung erfolgreich zu aktivieren, müssen verschiedene Bedingungen erfüllt sein.
<G-vec00038-002-s076><activate.aktivieren><en> To convert scanned PDF files, you need to activate the OCR function by ticking the "Enable OCR" option.
<G-vec00038-002-s076><activate.aktivieren><de> Um gescannte PDF-Dateien zu konvertieren, müssen Sie die OCR-Funktion aktivieren, indem Sie bei „OCR aktivieren“ ein Häkchen setzen.
<G-vec00038-002-s077><activate.aktivieren><en> To set a global scripting project for Authentic Desktop, check the Activate Scripting check box and then browse for the Altova Scripting Project (.asprj) file you want.
<G-vec00038-002-s077><activate.aktivieren><de> Um ein globales Skripting-Projekt für Authentic Desktop zu definieren, aktivieren Sie das Kontrollkästchen Skripting aktivieren und navigieren Sie anschließend zum gewünschten Altova Skripting-Projekt (.asprj-Datei).
<G-vec00038-002-s078><activate.aktivieren><en> Hover over the field you want to make active, then select Activate.
<G-vec00038-002-s078><activate.aktivieren><de> Setzen Sie die Maus auf den Namen des Felds, das Sie aktivieren möchten, und wählen Sie Aktivieren aus.
<G-vec00038-002-s079><activate.aktivieren><en> To activate anonymous FTP service, click Switch On.
<G-vec00038-002-s079><activate.aktivieren><de> Um den Anonymous-FTP-Service zu aktivieren, klicken Sie auf Aktivieren.
<G-vec00038-002-s080><activate.aktivieren><en> To activate the sixth reel, please click on the "Extra Wild" button at the top right next to the Sizzling Hot™ 6 extra gold features
<G-vec00038-002-s080><activate.aktivieren><de> Um die sechste Walze zu aktivieren, brauchst du nur den „Extra Wild“-Button, der sich rechts oben neben dem Logo befindet, mit einem Klick zu aktivieren.
<G-vec00038-002-s081><activate.aktivieren><en> For iOS, activating this feature is a two-step process: first you need to Activate “Find My iPhone” via iCloud (see instructions on Apple Support pages) and then enable “Erase your device” (see instructions on Apple Support pages)
<G-vec00038-002-s081><activate.aktivieren><de> Unter iOS erfolgt das Aktivieren dieser Funktion in zwei Schritten: Zuerst müssen Sie über iCloud die Funktion „Mein iPhone suchen“ aktivieren (siehe Anleitung auf den Support-Seiten von Apple) und anschließend die Funktion „Ihr Gerät löschen“ aktivieren (siehe Anleitung auf den Support-Seiten von Apple).
<G-vec00038-002-s082><activate.aktivieren><en> We currently have no songs as made famous by The Hamilton Mixtape in our catalog, but you can activate the email alert to be notified as soon as a new title is being added.
<G-vec00038-002-s082><activate.aktivieren><de> Benachrichtigung aktivieren Wir haben momentan keinen Song von National Anthem in unserem Katalog, aber Sie können die E-Mail-Benachrichtigung aktivieren, um so schnell wie möglich zu erfahren, dass ein neuer Titel hinzugefügt wurde.
<G-vec00038-002-s083><activate.aktivieren><en> You can activate a part of the codebits of an enemy, but never all, because the level is going to crash instead of loading, if you want to start it.
<G-vec00038-002-s083><activate.aktivieren><de> Bei Gegnern kann man auch verschiedene Codebits aktivieren, man sollte aber nie alle aktivieren, denn dann stürzt das Level bereits bei dem Laden ab.
<G-vec00038-002-s084><activate.aktivieren><en> 1.After a successful activation click Enable Anti-Theft to activate ESET Anti-Theft features for the computer you just registered.
<G-vec00038-002-s084><activate.aktivieren><de> 1.Klicken Sie nach der erfolgreichen Aktivierung auf Anti-Theft aktivieren, um die Funktionen von ESET Anti-Theft für den soeben registrierten Computer zu aktivieren.
<G-vec00038-002-s085><activate.aktivieren><en> • To open the BlackBerry Assistant by pressing and holding the Mute key, turn on the Activate With Mute Key
<G-vec00038-002-s085><activate.aktivieren><de> • Um BlackBerry Assistant durch Gedrückthalten der Stummschalttaste zu öffnen, aktivieren Sie die Einstellung Über Stummtaste aktivieren.
<G-vec00038-002-s086><activate.aktivieren><en> If you receive the error message “This activation code is no longer supported” when attempting to activate a Kaspersky Lab product, it means the code you are entering is intended for an old version of the application.
<G-vec00038-002-s086><activate.aktivieren><de> Wenn Sie ein Porgramm von Kaspersky Lab zu aktivieren versuchen aber der Fehler „Der Aktivierungscode wird nicht mehr unterstützt“ auftritt, weist dies darauf hin, dass Sie das Programm mit einem Aktivierungscode für eine alte Version zu aktivieren versuchen.
<G-vec00038-002-s087><activate.aktivieren><en> Alternatively, you can activate the Researcher directly from the Technologies window.
<G-vec00038-002-s087><activate.aktivieren><de> Klicke auf den Button ""Aktivieren"" neben dem Gegenstand - alternativ kannst du den Gegenstand auch direkt über das Technologie-Fenster aktivieren.
<G-vec00038-002-s088><activate.aktivieren><en> [Important] You have to create & log-in to your AURALiC Account in the Lightning DS App first before you try to activate (de-activate) your lightning devices.
<G-vec00038-002-s088><activate.aktivieren><de> Lightning-Gerät aktivieren und deaktivieren [WICHTIG] Sie müssen zunächst in Lightning DS ein AURALiC-Konto erstellen und sich einloggen, bevor Sie eines Ihrer Lightning-Geräte aktivieren beziehungsweise deaktivieren können.
<G-vec00038-002-s090><activate.aktivieren><en> For Include activate the checkbox Notes to include attached notes and the checkbox Overrides to label enabled overrides and include their text field (see Chapter 11.2.2).
<G-vec00038-002-s090><activate.aktivieren><de> Notizen durch Aktivieren der Checkbox Notizen hinzufügen und Übersteuerungen durch Aktivieren der Checkbox Übersteuerungen kennzeichnen und ihr Textfeld einfügen (siehe Kapitel 11.2.2).
<G-vec00038-002-s091><activate.aktivieren><en> "Activate HTTPS": If you flip this switch and enable HTTPS, a Let's Encrypt certificate is issued and the subdomain is configured to use it.
<G-vec00038-002-s091><activate.aktivieren><de> "HTTPS aktivieren": Wenn Sie diesen Schalter betätigen und HTTPS aktivieren, wird ein Let's Encrypt Zertifikat ausgestellt und die Subdomain konfiguriert.
<G-vec00038-002-s092><activate.aktivieren><en> To automate the renewal process even further, activate AutoPay during your initial enrolment.
<G-vec00038-002-s092><activate.aktivieren><de> Um den Erneuerungsvorgang zu automatisieren, aktivieren Sie bei der ursprünglichen Anmeldung AutoPay.
<G-vec00038-002-s093><activate.aktivieren><en> Activate the option Discount scale based on net value of items.
<G-vec00038-002-s093><activate.aktivieren><de> Aktivieren Sie die Option Rabattstaffel auf Nettowarenwert.
<G-vec00038-002-s094><activate.aktivieren><en> An example: Run the Line command, pick one point, move the mouse and activate elevator (press Ctrl) for the second point, type <30.
<G-vec00038-002-s094><activate.aktivieren><de> Als Beispiel: Führen Sie den Befehl Linie aus, wählen Sie einen Punkt, verschieben Sie die Maus und aktivieren Sie den Aufzugmodus (Drücken der Strg-Taste) für den zweiten Punkt.
<G-vec00038-002-s095><activate.aktivieren><en> Never activate a dome when all feet are not evenly supported.
<G-vec00038-002-s095><activate.aktivieren><de> Aktivieren Sie eine Schnappscheibe nie, wenn nicht alle Füße gleichmäßig gestützt werden.
<G-vec00038-002-s096><activate.aktivieren><en> Activate the DoubleClick Bid Manager API in the Google API Console.
<G-vec00038-002-s096><activate.aktivieren><de> Aktivieren Sie die Indexing API in der Google API Console.
<G-vec00038-002-s097><activate.aktivieren><en> Next, activate the property in the item settings and enter the value in percent.
<G-vec00038-002-s097><activate.aktivieren><de> Aktivieren Sie als nächstes das Merkmal in den Artikeleinstellungen und hinterlegen Sie den Wert percent.
<G-vec00038-002-s098><activate.aktivieren><en> Simply activate the Office integration in your application and a new selection of documents can be accessed through your portal.
<G-vec00038-002-s098><activate.aktivieren><de> Aktivieren Sie die Office-Integration in Ihrer Anwendung, und schon ist eine neue Sammlung von Dokumenten von Office aus erreichbar.
<G-vec00038-002-s099><activate.aktivieren><en> Please activate Java Script for your Browser in order to use the full functionality of this service.
<G-vec00038-002-s099><activate.aktivieren><de> Bitte aktivieren Sie Java Script, um den vollen Funktionsumfang diese Angebots nutzen zu können oder wechseln Sie zur Version dieser Seite ohne Java Script.
<G-vec00038-002-s100><activate.aktivieren><en> are needed. Please activate cookies and refresh your browser.
<G-vec00038-002-s100><activate.aktivieren><de> Bitte aktivieren Sie Cookies in Ihrem Browser und laden Sie die Website erneut.
<G-vec00038-002-s101><activate.aktivieren><en> Punch SUBSCRIBE Give in your name, email-address and activate the receivement of mailings.
<G-vec00038-002-s101><activate.aktivieren><de> Geben Sie Ihren Namen und Ihre Emailadresse ein und aktivieren Sie den Mailingempfang (ist standardmäßig aktiviert).
<G-vec00038-002-s102><activate.aktivieren><en> Activate the checkbox Subject.
<G-vec00038-002-s102><activate.aktivieren><de> Aktivieren Sie die Checkbox Subject.
<G-vec00038-002-s103><activate.aktivieren><en> Finally, activate the option labeled iMessage.
<G-vec00038-002-s103><activate.aktivieren><de> Aktivieren Sie abschließend die Option iMessage.
<G-vec00038-002-s104><activate.aktivieren><en> 3 Activate the Bluetooth feature on the second Bluetooth phone and search for the headset (see your phone’s user manual).
<G-vec00038-002-s104><activate.aktivieren><de> 4 Aktivieren Sie die Bluetooth-Funktion auf dem zweiten Bluetooth-Telefon und suchen Sie nach dem Headset (siehe Benutzerhandbuch des Telefons).
<G-vec00038-002-s105><activate.aktivieren><en> To display timers window, activate the item from the main menu.
<G-vec00038-002-s105><activate.aktivieren><de> Um das Timerfenster einzublenden, aktivieren Sie diese Option im Hauptmenü.
<G-vec00038-002-s106><activate.aktivieren><en> Get in touch with Please activate JavaScript to use this website without any limitations.
<G-vec00038-002-s106><activate.aktivieren><de> Bitte aktivieren Sie JavaScript, um diese Website uneingeschränkt nutzen zu können.
<G-vec00038-002-s107><activate.aktivieren><en> Connect the USB camera to the Wifi box and activate it with the button.
<G-vec00038-002-s107><activate.aktivieren><de> Schließen Sie die USB-Kamera an die Wifi-Box an und aktivieren Sie sie mit der Taste.
<G-vec00038-002-s108><activate.aktivieren><en> Activate two-factor authentication if available.
<G-vec00038-002-s108><activate.aktivieren><de> Aktivieren Sie Zwei-Faktor-Authentisierung, wenn dies angeboten wird.
<G-vec00038-002-s109><activate.aktivieren><en> Please activate JavaScript in your browser.
<G-vec00038-002-s109><activate.aktivieren><de> Bitte aktivieren Sie JavaScript in den Browsereinstellungen.
<G-vec00038-002-s110><activate.aktivieren><en> Under Also deliver to, activate the Add more recipients option and Add an additional delivery recipient.
<G-vec00038-002-s110><activate.aktivieren><de> Aktivieren Sie im Abschnitt Auch senden an die Option Weitere Empfänger hinzufügen und klicken auf die Schaltfläche Hinzufügen.
<G-vec00038-002-s111><activate.aktivieren><en> Other monsters cannot attack during the turn you activate this card.
<G-vec00038-002-s111><activate.aktivieren><de> Andere Monster können während des Spielzugs, in dem du diese Karte aktivierst, nicht angreifen.
<G-vec00038-002-s112><activate.aktivieren><en> You cannot Special Summon any monsters during the turn you activate this effect, except Beast-Type monsters.
<G-vec00038-002-s112><activate.aktivieren><de> Du kannst während des Spielzugs, in dem du diesen Effekt aktivierst, keine Monster als Spezialbeschwörung beschwören, außer Monstern vom Typ Ungeheuer.
<G-vec00038-002-s113><activate.aktivieren><en> If you activate this effect, this card cannot attack during this turn.
<G-vec00038-002-s113><activate.aktivieren><de> Falls du diesen Effekt aktivierst, kann diese Karte in diesem Spielzug nicht angreifen.
<G-vec00038-002-s114><activate.aktivieren><en> When you activate the automatic start-up, you can forget about the technology and focus on your race.
<G-vec00038-002-s114><activate.aktivieren><de> Sobald du den Auto-Start aktivierst, kannst du die Technik vergessen und dich aufs Laufen konzentrieren.
<G-vec00038-002-s115><activate.aktivieren><en> Inspiration generates 12 focus when activated, and you heal for 1% of your maximum health whenever you activate an ability that consumes focus.
<G-vec00038-002-s115><activate.aktivieren><de> Inspiration erzeugt bei Aktivierung 12 Fokus und du wirst um 1% deiner maximalen Gesundheit geheilt, wenn du eine Fähigkeit aktivierst, die Fokus verbraucht.
<G-vec00038-002-s116><activate.aktivieren><en> Under “Advanced Options” you activate the automatic loading of the I2C bus.
<G-vec00038-002-s116><activate.aktivieren><de> Unter „Advanced Options“ aktivierst du das automatische Laden des I2C Bus.
<G-vec00038-002-s117><activate.aktivieren><en> Only if you activate the plug-in, your browser establishes a direct connection to the Twitter servers.
<G-vec00038-002-s117><activate.aktivieren><de> Nur wenn Du den Plug- In aktivierst, baut Dein Browser eine direkte Verbindung mit den Servern von Twitter auf.
<G-vec00038-002-s118><activate.aktivieren><en> While this card is face-up on the field, inflict 400 points of damage to your opponent's Life Points each time you activate 1 Normal Spell Card.
<G-vec00038-002-s118><activate.aktivieren><de> Solange sich diese Karte offen auf dem Spielfeld befindet, füge den Life Points deines Gegners 400 Punkte Schaden zu, jedes Mal wenn du 1 Normale Zauberkarte aktivierst.
<G-vec00038-002-s119><activate.aktivieren><en> If you do not activate this option then at your listing only the number of persons is shown but no choice to choose children and infants.
<G-vec00038-002-s119><activate.aktivieren><de> Falls Du dies nicht aktivierst, wird bei Deinem Inserat nur die Anzahl an Personen angezeigt, aber keine Auswahlmöglichkeit für Kleinkinder und Kinder.
<G-vec00038-002-s120><activate.aktivieren><en> The plugin provider only obtains information that you have accessed the respective page of our respective website if you click on the highlighted field and thereby activate it.
<G-vec00038-002-s120><activate.aktivieren><de> Nur wenn Du auf das markierte Feld klickst und es dadurch aktivierst, erhält der Plug-in-Anbieter die Information, dass Du die entsprechende Website unseres Online-Angebots aufgerufen hast.
<G-vec00038-002-s121><activate.aktivieren><en> If you activate the download of the original images at the same time, these are not protected by watermarks, because PicDrop never modifies your uploaded images.
<G-vec00038-002-s121><activate.aktivieren><de> Aktivierst Du gleichzeitig den Download der Originalbilder, so sind diese nicht durch Wasserzeichen geschützt, da PicDrop Deine hochgeladenen Bilder grundsätzlich niemals verändert.
<G-vec00038-002-s122><activate.aktivieren><en> Land three of the golden Lion Wilds on your reels and you’ll activate the Flames of War bonus round, with some fantastic Free Spins just waiting to be conquered.
<G-vec00038-002-s122><activate.aktivieren><de> Treffe drei goldene Löwen Wilds auf Deinen Rädern und Du aktivierst die Flammen des Kriegs Bonus Runde, mit ein paar fantastischen Freispielen die darauf warten alles zu erobern.
<G-vec00038-002-s123><activate.aktivieren><en> When you activate this card, declare 1 card name.
<G-vec00038-002-s123><activate.aktivieren><de> Wenn du diese Karte aktivierst, nenne 1 Kartennamen.
<G-vec00038-002-s124><activate.aktivieren><en> Godmode 10.000 free If you activate this cheat in game, your current and maximum amount of health will be set to the given value as long as this cheat is active.
<G-vec00038-002-s124><activate.aktivieren><de> Wenn du diesen Cheat im Spiel aktivierst, wird deine aktuelle und maximale Lebensenergie für die Dauer des Cheats auf den angegebenen Wert gesetzt, wodurch du unsterblich bist.
<G-vec00038-002-s125><activate.aktivieren><en> - Achieve your wishes the faster, the more savings you activate rules or the higher you choose the saving amounts.
<G-vec00038-002-s125><activate.aktivieren><de> - Erreiche deine Wünsche um so schneller, je mehr Sparregeln du aktivierst oder je höher du die Sparbeträge wählst.
<G-vec00038-002-s126><activate.aktivieren><en> This card cannot attack during the same turn you activate this effect.
<G-vec00038-002-s126><activate.aktivieren><de> Diese Karte kann nicht in dem Spielzug angreifen, in dem du diesen Effekt aktivierst.
<G-vec00038-002-s127><activate.aktivieren><en> Monsters other than the selected monster cannot attack the turn you activate this effect.
<G-vec00038-002-s127><activate.aktivieren><de> Andere Monster außer dem gewählten Monster können in dem Spielzug, in dem du diesen Effekt aktivierst, nicht angreifen.
<G-vec00038-002-s128><activate.aktivieren><en> To overcome monsters, issue commands to individual party members in turn-based battles – or, if you’re confident that your party can handle the situation, you can activate “tactics” to let fights play out automatically.
<G-vec00038-002-s128><activate.aktivieren><de> Mit Monstern wirst du fertig, indem du in den rundenbasierten Kämpfen Befehle an einzelne Mitglieder der Gruppe erteilst – oder, wenn du davon überzeugt bist, dass deine Gruppe die Lage im Griff hat – „Taktik” aktivierst, damit die Kämpfe automatisiert ablaufen.
<G-vec00038-002-s129><activate.aktivieren><en> When you activate this card, change any Defense Position monster(s) to face-up Attack Position.
<G-vec00038-002-s129><activate.aktivieren><de> Wenn du diese Karte aktivierst, ändere alle Monster in Verteidigungsposition in die offene Angriffsposition.
<G-vec00038-002-s130><activate.aktivieren><en> In the final step we activate the adhesive tape.
<G-vec00038-002-s130><activate.aktivieren><de> Im abschließenden Schritt wird die Klebewirkung der Klebefläche aktiviert.
<G-vec00038-002-s131><activate.aktivieren><en> You need activate support of JavaScript and Cookies in your browser
<G-vec00038-002-s131><activate.aktivieren><de> Anscheinend ist in Ihrem Browser JavaScript nicht aktiviert.
<G-vec00038-002-s132><activate.aktivieren><en> If you activate "Hircine beast's pool" so you get the attribute werewolf and becomes a werewolf.
<G-vec00038-002-s132><activate.aktivieren><de> Aktiviert man "Hircine´s Bestienbecken" so bekommt man die Werwolf Atribute und wird zum Werwolf.
<G-vec00038-002-s133><activate.aktivieren><en> An easy-to-reach lever is used to activate the metal footrest from its parking position under the seat.
<G-vec00038-002-s133><activate.aktivieren><de> Aus ihrer Parkposition unter dem Sitzteil wird die Metallfußstütze durch einen gut erreichbaren Hebel aktiviert.
<G-vec00038-002-s134><activate.aktivieren><en> It does not activate the theme, but allows it to show in the site’s Appearance menu.
<G-vec00038-002-s134><activate.aktivieren><de> Es aktiviert nicht das Theme, sondern ermöglicht, es im Menü der Website unter Design anzuzeigen.
<G-vec00038-002-s135><activate.aktivieren><en> It was not possible to activate the ‘approval workflow’ integration with Signavio Process Manager.
<G-vec00038-002-s135><activate.aktivieren><de> Behobene Fehler Die ‚Freigabeworkflow‘-Integration mit Signavio Process Manager konnte nicht aktiviert werden.
<G-vec00038-002-s136><activate.aktivieren><en> The film transport motor will activate for a second to release the film-chamber lock.
<G-vec00038-002-s136><activate.aktivieren><de> Der Filmtransportmotor ist für eine Sekunde aktiviert, um die Filmkammer-Verriegelung freizugeben.
<G-vec00038-002-s137><activate.aktivieren><en> It is also possible to activate the Villain Hunt Bonus Game if you get 3 or more Logo symbols during your free spins.
<G-vec00038-002-s137><activate.aktivieren><de> Bonus Spiel 1: Wenn Sie 3 oder mehr Zig Zag Symbole hintereinander bekommen, wird das Bonusspiel aktiviert.
<G-vec00038-002-s138><activate.aktivieren><en> Any supplements which contain these active ingredients will activate the thermogenic effect which is especially known for the capacity to activate adipose cells and shed the calories.
<G-vec00038-002-s138><activate.aktivieren><de> Jede Art von Ergänzungen, die diese Wirkstoffe enthalten, die thermogene Wirkung aktiviert, die speziell für die Fähigkeit verstanden wird Fett zu triggern und die Kalorien zu vergießen.
<G-vec00038-002-s139><activate.aktivieren><en> When a system requires the use of a booster pump or pulls water directly from a creek or pond, it’s imperative to include a relay that can be counted upon to activate the pump each and every time.
<G-vec00038-002-s139><activate.aktivieren><de> Wenn ein System eine Druckerhöhungspumpe benötigt oder Wasser direkt aus einem Bach oder Teich zieht, ist es unerlässlich, ein Relais hinzuzufügen, das die Pumpe jederzeit verlässlich aktiviert.
<G-vec00038-002-s140><activate.aktivieren><en> In order to optimize a cross‑section in the module, it is necessary to activate this option for the individual cross‑section.
<G-vec00038-002-s140><activate.aktivieren><de> Damit das Modul einen Querschnitt optimiert, muss dies für den einzelnen Querschnitt aktiviert werden.
<G-vec00038-002-s141><activate.aktivieren><en> In two hours, a worm that is already implanted in the servers of every major news publication will activate, replacing the regular content with my 'special report'.
<G-vec00038-002-s141><activate.aktivieren><de> In zwei Stunden wird ein Wurm aktiviert, der bereits in den Servern aller großen Nachrichtenagenturen implantiert ist und die normalen Inhalte durch meine 'Sondermeldung' ersetzen.
<G-vec00038-002-s142><activate.aktivieren><en> If you still failed activate your iPhone after iOS 11 upgrade, try to reactivate through iTunes in following steps.
<G-vec00038-002-s142><activate.aktivieren><de> Wenn das iPhone nach iOS 11 Upgrade immer noch nicht aktiviert wurde, versuchen Sie, in den folgenden Schritten erneut über iTunes zu reaktivieren.
<G-vec00038-002-s143><activate.aktivieren><en> That is why you should activate the “intelligent OCR processing“.
<G-vec00038-002-s143><activate.aktivieren><de> Deswegen sollte die “intelligente OCR Verarbeitung” aktiviert werden.
<G-vec00038-002-s144><activate.aktivieren><en> - a second built-in mechanism will activate the air bladder, pushing the blood sample into the biosensor chamber.
<G-vec00038-002-s144><activate.aktivieren><de> - Ein zweiter integrierter Mechanismus aktiviert die Luftblase und befördert die Blutprobe in die Biosensorkammer.
<G-vec00038-002-s145><activate.aktivieren><en> By selecting one specific sensor, we will activate pairing with the app, which during the recording phases will therefore try to connect to it and read from it the measurements obtained.
<G-vec00038-002-s145><activate.aktivieren><de> Wird ein bestimmter Sensor ausgewählt, aktiviert sich die Verknüpfung mit der App, die danach während der Aufzeichnung versucht, sich mit ihm zu verbinden und die gemessenen Werte einzulesen.
<G-vec00038-002-s146><activate.aktivieren><en> If you activate the automatic opening of the cursor control panel, the measured values at the cursor position are displayed immediately in case of cursor movement.
<G-vec00038-002-s146><activate.aktivieren><de> Sollen bei Cursorbewegung gleich die Messdaten am Cursor angezeigt werden, kann das automatische Aufklappen der Cursortafel aktiviert werden.
<G-vec00038-002-s147><activate.aktivieren><en> If you did not activate Avast Internet Security during installation or you want to activate your subscription on a secondary PC, you can do so using the activation code received in your order confirmation email during the purchase. Follow these steps:
<G-vec00038-002-s147><activate.aktivieren><de> Wenn Sie Avast Internet Security während der Installation nicht aktiviert haben oder Ihr Abonnement auf einem zweiten PC aktivieren möchten, verwenden Sie dazu den Aktivierungscode, den Sie in der während des Kaufvorgangs erhaltenen E-Mail der Bestellbestätigung finden.
<G-vec00038-002-s148><activate.aktivieren><en> No matter how many times you activate any of the three in battle, when it ends, you’ll only have to pay its regular cost.
<G-vec00038-002-s148><activate.aktivieren><de> Egal, wie oft ihr eines der drei im Gefecht aktiviert, am Ende müsst ihr nur die Standardkosten zahlen.
<G-vec00038-002-s149><activate.aktivieren><en> '''Example:''' [[Image:Separator in Text.png|center]] === Necessary adjustments in the frontend === In order to break the text at the desired position where the separator was inserted, you need to activate that function in the frontend.
<G-vec00038-002-s149><activate.aktivieren><de> '''Beispiel:''' [[Image:Separator_im_Text.png|center]] === Notwendige Anpassung im Frontend === Damit der Text auch wie gewünscht an der Stelle, an der sich der Separator befindet, unterbrochen wird, muss eine entsprechende Funktion im Frontend der Webseite aktiviert werden.
<G-vec00038-002-s150><activate.aktivieren><en> The hands of a user illuminated by bright film lamps cast shadows of various densities to activate the sensors of the Theramidi device and the voice archive which it controls.
<G-vec00038-002-s150><activate.aktivieren><de> Die Hände eines Benützers/einer Benützerin werfen im Licht von zwei sehr hellen Filmscheinwerfern Schatten unterschiedlicher Stärke, von denen die Sensoren des Theramidis und dadurch die Klangwelten eines digitalen Stimmarchivs aktiviert werden.
<G-vec00038-002-s151><activate.aktivieren><en> You must prepare a KMS host by first installing the licensing files (see Set up and activate Office KMS), and then activating the KMS host key before it can accept activation requests from clients.
<G-vec00038-002-s151><activate.aktivieren><de> Der KMS-Host muss mit einem KMS-Hostschlüssel installiert und aktiviert werden, bevor er KMS-Aktivierungsanforderungen von KMS-Clients annehmen kann.
<G-vec00038-002-s152><activate.aktivieren><en> You can also use this option if you want to activate this client at a later time.
<G-vec00038-002-s152><activate.aktivieren><de> Wählen Sie diese Option nur aus, wenn der Client später aktiviert werden soll.
<G-vec00038-002-s153><activate.aktivieren><en> Additionally, you can now set up to four ID and Data combination bit conditions and activate triggers based on OR relationships of these combinations.
<G-vec00038-002-s153><activate.aktivieren><de> Zusätzlich können jetzt bis zu vier ID und Daten-Bit-Zustände eingestellt und Trigger auf der Basis von OR-Beziehungen dieser Kombinationen aktiviert werden.
<G-vec00038-002-s154><activate.aktivieren><en> Every computer that has RoboHelp (2019 release) installed must activate in order to continue using the software.
<G-vec00038-002-s154><activate.aktivieren><de> Jeder Computer, auf dem Adobe FrameMaker XML Author (2015 release) installiert ist, muss aktiviert werden, damit die Software uneingeschränkt genutzt werden kann.
<G-vec00038-002-s155><activate.aktivieren><en> In the event that we cannot activate the product, we will warn you when you launch the application.
<G-vec00038-002-s155><activate.aktivieren><de> Falls das Produkt nicht aktiviert werden kann, erhalten Sie beim Start der Applikation eine Warnmeldung.
<G-vec00038-002-s156><activate.aktivieren><en> SCP-159 will fail to activate if it is unplugged during a power outage.
<G-vec00038-002-s156><activate.aktivieren><de> SCP-159 kann nicht aktiviert werden, wenn es während eines Stromausfalls abgesteckt wird.
<G-vec00038-002-s157><activate.aktivieren><en> HTML5 video redirection might activate in sessions that do not support HTML5 video redirection.
<G-vec00038-002-s157><activate.aktivieren><de> Die HTML5-Videoumleitung kann in Sitzungen aktiviert werden, die keine HTML5-Videoumleitung unterstützen.
<G-vec00038-002-s158><activate.aktivieren><en> Free and fair competition should activate all options that can meet demand most efficiently.
<G-vec00038-002-s158><activate.aktivieren><de> Im diskriminierungsfreien Wettbewerb sollten die Optionen aktiviert werden, die den Bedarf am effizientesten decken können.
<G-vec00038-002-s159><activate.aktivieren><en> When enough of humanity can see the Big Picture, people will activate en masse and know what to do, because they will spontaneously know who they truly are.
<G-vec00038-002-s159><activate.aktivieren><de> Wenn genug Menschen das Große Bild sehen können, werden Menschen in Massen aktiviert werden und wissen, was sie zu tun haben, weil sie spontan wissen werden, wer sie wirklich sind.
<G-vec00038-002-s160><activate.aktivieren><en> It’s now possible to activate the option to notify all resources of one Activity if all predecessors have been completed.
<G-vec00038-002-s160><activate.aktivieren><de> In den Optionen kann nun aktiviert werden, dass alle Ressourcen einens Vorgangs benachrichtigt werden, wenn alle Vorgänger abgeschlossen wurden.
<G-vec00038-002-s161><activate.aktivieren><en> Cannot activate full-text search for table or indexed view '%1' because no columns have been enabled for full-text search. (English) - Unlocalize.com
<G-vec00038-002-s161><activate.aktivieren><de> (Die Volltextsuche für die Tabelle oder indizierte Sicht '%1' kann nicht aktiviert werden, da keine Spalten für die Volltextsuche aktiviert wurden.
<G-vec00038-002-s162><activate.aktivieren><en> Unable to activate one or more fonts.
<G-vec00038-002-s162><activate.aktivieren><de> Eine oder mehrere Schriftarten konnten nicht aktiviert werden.
<G-vec00038-002-s163><activate.aktivieren><en> In the Choose Jump Menu menu, select a menu for the Go button to activate and click OK. Apply the Open Browser Window behavior
<G-vec00038-002-s163><activate.aktivieren><de> Wählen Sie im Menü „Wählen Sie ein Sprungmenü aus“ das Menü aus, das durch die Schaltfläche „Gehe zu“ aktiviert werden soll, und klicken Sie auf „OK“.
<G-vec00038-002-s164><activate.aktivieren><en> To receive product notifications or any other news you need to activate it before.
<G-vec00038-002-s164><activate.aktivieren><de> Um Produktnachrichten zu erhalten, müssen diese zuvor von Ihnen aktiviert werden.
<G-vec00038-002-s165><activate.aktivieren><en> For most TV sets you need to activate it for each HDMI channel.
<G-vec00038-002-s165><activate.aktivieren><de> Diese muss bei den meisten Geräten pro HDMI Kanal aktiviert werden.
<G-vec00038-002-s166><activate.aktivieren><en> However, an administrator must explicitly activate a plug-in to encrypt files with AES 256.
<G-vec00038-002-s166><activate.aktivieren><de> Jedoch muss von einem Administrator dazu explizit ein Plug-In aktiviert werden, um Dateien mit AES 256 zu verschlüsseln.
<G-vec00038-002-s167><activate.aktivieren><en> The application uses sound sensors that activate automatically when they detect the baby crying.
<G-vec00038-002-s167><activate.aktivieren><de> Das Programm verfügt über Geräuschsensoren, die automatisch aktiviert werden, wenn das Baby weint.
<G-vec00038-002-s168><activate.aktivieren><en> When you activate this card, declare 1 Type of monster.
<G-vec00038-002-s168><activate.aktivieren><de> Wähle 1 Monster-Typ, wenn diese Karte aktiviert wird.
<G-vec00038-002-s169><activate.aktivieren><en> Users must be enrolled in Secure Hub for the public store app to activate as a managed app (secured by MDX) and to be usable.
<G-vec00038-002-s169><activate.aktivieren><de> Benutzer müssen bei Secure Hub registriert sein, damit eine öffentliche Store-App als verwaltete (mit MDX geschützte) App aktiviert wird und verwendet werden kann.
<G-vec00038-002-s170><activate.aktivieren><en> Note that you have to like the iHeartBerlin.de FB page first to activate the like button in the albums.
<G-vec00038-002-s170><activate.aktivieren><de> Ihr müsst zuvor jedoch die iHeartBerlin.de FB Seite liken, bevor die “Gefällt mir”-Funktion unter den Bildern aktiviert wird.
<G-vec00038-002-s171><activate.aktivieren><en> You can also choose to receive a push notification if the door or window is opened, or to activate a siren.
<G-vec00038-002-s171><activate.aktivieren><de> Auch können Sie wählen, ob eine Push-Meldung verschickt wird, wenn eine Tür oder ein Fenster geöffnet wird, oder ob die Sirene aktiviert wird.
<G-vec00038-002-s172><activate.aktivieren><en> You can activate this function via EXTRAS / TRANSLATE SETTINGS.
<G-vec00038-002-s172><activate.aktivieren><de> Aktiviert wird diese Funktion über "EXTRAS / TRANSLATEEINSTELLUNGEN".
<G-vec00038-002-s173><activate.aktivieren><en> Stop/Start systems are fitted with sensors which continuously monitor the battery status and send signals to a control unit which, in real time, decides whether or not to activate the system.
<G-vec00038-002-s173><activate.aktivieren><de> Start&Stop-Systeme sind mit Sensoren ausgestattet, die den Batteriezustand kontinuierlich überwachen und Signale an ein Steuergerät senden, das in Echtzeit entscheidet, ob das System aktiviert wird oder nicht.
<G-vec00038-002-s174><activate.aktivieren><en> Instances where the global cooldown would activate without triggering the selected ability have been reduced.
<G-vec00038-002-s174><activate.aktivieren><de> Es sollte nun seltener vorkommen, dass die allgemeine Abklingzeit aktiviert wird, ohne dass die ausgewählte Fähigkeit ausgelöst wird.
<G-vec00038-002-s175><activate.aktivieren><en> Wait a few minutes for the mailbox to activate.
<G-vec00038-002-s175><activate.aktivieren><de> Ein paar Minuten warten bis die Mailbox aktiviert wird.
<G-vec00038-002-s176><activate.aktivieren><en> In order to activate the auxiliary brake, for example a magnet rail brake, several requirements must be met first: rotary transducers on the carriage axle continuously detect the travel speed and evaluate this.
<G-vec00038-002-s176><activate.aktivieren><de> Damit die Zusatzbremse, wie beispielsweise eine Magnetschienenbremse, aktiviert wird, müssen mehrere Voraussetzungen erfüllt sein: Drehgeber an den Wagenachsen erfassen permanent die Fahrtgeschwindigkeit und werten diese aus.
<G-vec00038-002-s177><activate.aktivieren><en> Now activate the barcode object by clicking onto it once.
<G-vec00038-002-s177><activate.aktivieren><de> Klicken Sie nun einmal auf das Barcode Objekt, damit dieses aktiviert wird.
<G-vec00038-002-s178><activate.aktivieren><en> Refer to the cheat code's description in the Cheats window to see how to activate the cheat.
<G-vec00038-002-s178><activate.aktivieren><de> Sieh im Cheat-Fenster in der Beschreibung des Cheat-Codes nach, um zu sehen, wie der Cheat aktiviert wird.
<G-vec00038-002-s179><activate.aktivieren><en> You can activate the editing process by clicking on the text.
<G-vec00038-002-s179><activate.aktivieren><de> Aktiviert wird der Editiervorgang durch einen Klick auf den Text.
<G-vec00038-002-s180><activate.aktivieren><en> Hidden Blade and its morphs will receive some adjustments to how Brutality is granted, and Flying Blade will get a targeting responsiveness improvement to activate its special teleport.
<G-vec00038-002-s180><activate.aktivieren><de> „Verborgene Klinge“ und seine Veränderungen werden dahingehend angepasst, wie Brutalität gewährt wird, und „fliegende Klinge“ wird bezüglich der Reaktionsfreudigkeit bei Zielen verbessert, damit die besondere Teleportation aktiviert wird.
<G-vec00038-002-s317><activate.aktivieren><en> Switch the Samsung Galaxy Ace 4 off and then on again to activate the settings.
<G-vec00038-002-s317><activate.aktivieren><de> Schalten Sie Ihr Samsung Galaxy Ace aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s318><activate.aktivieren><en> In order to do so, children have to activate their will which is otherwise asleep in the physical processes.
<G-vec00038-002-s318><activate.aktivieren><de> Dazu müssen sie ihren ansonsten in den Leibesvorgängen schlafenden Willen seelisch aktivieren.
<G-vec00038-002-s319><activate.aktivieren><en> To automate the renewal process even further, activate AutoRenewal during your initial enrollment.
<G-vec00038-002-s319><activate.aktivieren><de> Sie können den Verlängerungsprozess noch weiter automatisieren, indem Sie bei der Erstanmeldung den AutoRenewal-Service aktivieren.
<G-vec00038-002-s320><activate.aktivieren><en> Switch the HTC Desire off and then on again to activate the settings.
<G-vec00038-002-s320><activate.aktivieren><de> Schalten Sie Ihr HTC Desire Z aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s321><activate.aktivieren><en> ADD USERS, share keys, activate/deactivate keys with a single touch - directly from your smartphone.
<G-vec00038-002-s321><activate.aktivieren><de> ZUGANG ERTEILEN Fügen Sie Benutzer hinzu, teilen Sie Schlüssel, de/aktivieren Sie Schlüssel mit einer Berührung – direkt von Ihrem Smartphone.
<G-vec00038-002-s322><activate.aktivieren><en> Switch the LG G3 off and then on again to activate the settings.
<G-vec00038-002-s322><activate.aktivieren><de> Schalten Sie Ihr HTC Desire 601 aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s323><activate.aktivieren><en> Switch the Apple iPhone SE off and then on again to activate the settings.
<G-vec00038-002-s323><activate.aktivieren><de> Schalten Sie Ihr iPhone SE aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s324><activate.aktivieren><en> And we have the power to activate it.
<G-vec00038-002-s324><activate.aktivieren><de> Wir müssen sie nur aktivieren.
<G-vec00038-002-s325><activate.aktivieren><en> bb) You can subsequently activate a technology provided that Lautsprecher Teufel installs a Google Cast technology on a Google Cast enabled device at a later point in time.
<G-vec00038-002-s325><activate.aktivieren><de> bb) Soweit die Google Cast-Technik von Lautsprecher Teufel nachträglich auf einem Google Cast- Gerät installiert wird, können Sie sie nachträglich aktivieren.
<G-vec00038-002-s326><activate.aktivieren><en> Switch the Nokia Asha 311 off and then on again to activate the settings.
<G-vec00038-002-s326><activate.aktivieren><de> Schalten Sie Ihr Nokia E71 aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s327><activate.aktivieren><en> Switch the Nokia 6220 classic off and then on again to activate the settings.
<G-vec00038-002-s327><activate.aktivieren><de> Schalten Sie Ihr Huawei P10 aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s328><activate.aktivieren><en> Activate this by clicking its icon in the Toolbox, or by pressing the Shift+R while inside the image.
<G-vec00038-002-s328><activate.aktivieren><de> Sie aktivieren es durch einen Klick auf das Symbol im Werkzeugfenster oder, während Sie im Bildfenster sind, durch die Taste Umschalt+R (großes „R“).
<G-vec00038-002-s329><activate.aktivieren><en> Switch the Apple iPhone 5s off and then on again to activate the settings.
<G-vec00038-002-s329><activate.aktivieren><de> Schalten Sie Ihr iPhone 5s aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s330><activate.aktivieren><en> Real time information about your payments and settlements. If you have the Banco Sabadell app, activate your card notifications.
<G-vec00038-002-s330><activate.aktivieren><de> Information zu Zahlungen und Abrechnungen in Echtzeit Wenn Sie die App Banco Sabadell nutzen, brauchen Sie nur die Benachrichtigungen für Kartenzahlungen zu aktivieren.
<G-vec00038-002-s331><activate.aktivieren><en> License key codes for Altova® SchemaAgent® 2013 can be used to activate any of the product language options available for download below.
<G-vec00038-002-s331><activate.aktivieren><de> Mit den Lizenz-Keycode für die Altova® SchemaAgent® 2013 können Sie jede der Produktsprachen aktivieren, die weiter unten zum Download zur Verfügung stehen.
<G-vec00038-002-s332><activate.aktivieren><en> ● How to activate collision checking for your simulations.
<G-vec00038-002-s332><activate.aktivieren><de> ● Wie Sie die Kollisionsprüfung für Ihre Simulationen aktivieren.
<G-vec00038-002-s333><activate.aktivieren><en> Switch the HTC Desire 320 off and then on again to activate the settings.
<G-vec00038-002-s333><activate.aktivieren><de> Schalten Sie Ihr Samsung Galaxy Note 4 aus und starten Sie es neu, um die Einstellungen zu aktivieren.
<G-vec00038-002-s334><activate.aktivieren><en> Activate the checkboxes .
<G-vec00038-002-s334><activate.aktivieren><de> Sie aktivieren die Checkboxen.
<G-vec00038-002-s335><activate.aktivieren><en> You will need to activate it by referring to the Website and following the instructions for activation prior to use.
<G-vec00038-002-s335><activate.aktivieren><de> Vor der Nutzung müssen Sie sie zuerst aktivieren, indem Sie den Anweisungen auf der Website folgen.
