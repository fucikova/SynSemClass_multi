<G-vec00028-002-s200><dip.fallen><en> Lowest averages occur in January, when nightly lows dip to 22 degree Celsius.
<G-vec00028-002-s200><dip.fallen><de> Die niedrigste Temperatur wird im Januar gemessen wobei Nachts die Temperatur bis auf 22 Grad Celsius fallen kann.
<G-vec00028-002-s201><dip.fallen><en> Exlusive and naturally camouflaged for polar climates, the Folkmanis arctic fox hand puppet is well adapted to keep you warm when the temperatures dip.
<G-vec00028-002-s201><dip.fallen><de> Mit exklusiver, und für das polare Klima natürlicher Tarnung ist die Polarfuchs Handpuppe gut geeignet, um Sie warm zu halten, wenn die Temperaturen fallen.
<G-vec00028-002-s202><dip.fallen><en> The floaty jersey tunic is constructed with two sheer chiffon panels in front that dip to an angular hem.
<G-vec00028-002-s202><dip.fallen><de> Die fließend fallende Jersey-Tunika hat vorn zwei hauchdünne Chiffonbahnen, die zu einem schrägen Saum fallen.
<G-vec00028-002-s203><dip.fallen><en> Sometimes the risk of cold exposure and frostbite is too high, and it’s smarter to stay indoors, especially when temperatures dip below 0 degrees.
<G-vec00028-002-s203><dip.fallen><de> Manchmal ist das Risiko für Kälteschäden und Erfrierungen einfach zu hoch und es ist klüger, drinnen zu bleiben, besonders wenn die Temperaturen unter 0 Grad fallen.
<G-vec00028-002-s204><dip.fallen><en> The true thickness of the No Name Zone and the Waite Zone is between 10m and 30m and dip steeply to the north, remaining open at depth.
<G-vec00028-002-s204><dip.fallen><de> Die Zonen No Name und Waite weisen wahre Mächtigkeiten von zehn bis 30 Metern auf, fallen steil in Richtung Norden ab und sind in der Tiefe weiterhin offen.
<G-vec00028-002-s367><dip.senken><en> Now walk left a few meters down, following the right slightly downhill into a dip.
<G-vec00028-002-s367><dip.senken><de> Nun geht es links ein paar Meter hinunter, im Anschluss rechts leicht bergab in eine Senke.
<G-vec00028-002-s369><dip.senken><en> The place lay in a dip among the moors, so that one was very near it before one saw it.
<G-vec00028-002-s369><dip.senken><de> Es lag in einer Senke, so dass man es erst sehen konnte, wenn man schon sehr nahe war.
<G-vec00028-002-s370><dip.senken><en> The bass is powerful, the slight emphasis noticed in the lab result is also reflected in the sound reproduction - the broad dip with slightly increasing tops leads to a transparent and relaxing sound that still has plenty of details to show.
<G-vec00028-002-s370><dip.senken><de> Der Bassbereich ist druckvoll, die leichte Betonung macht sich also auch beim Hören durchaus bemerkbar - die breitbandige Senke mit leicht steigenden Höhen manifestiert sich in einem sehr stressfreien und durchsichtigen Klangbild, dem man bei aller Unaufgeregtheit sehr viele feine Details entnehmen kann.
