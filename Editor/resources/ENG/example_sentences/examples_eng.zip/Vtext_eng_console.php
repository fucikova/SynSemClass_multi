<G-vec00536-002-s452><console.trösten><en> And many of the Jews had come to the women around Martha and Mary, to console them concerning their brother.
<G-vec00536-002-s452><console.trösten><de> 19 Viele Juden waren zu Marta und Maria gekommen, um sie wegen ihres Bruders zu trösten.
<G-vec00536-002-s453><console.trösten><en> And so their father, Ephraim, mourned for many days; and his brothers arrived, so that they might console him.
<G-vec00536-002-s453><console.trösten><de> 22 Darüber trauerte ihr Vater Efraim lange Zeit und seine Brüder kamen, ihn zu trösten.
<G-vec00536-002-s454><console.trösten><en> And when the encounter happens, it is never rushed, because God wants to remain at length with us to sustain us, to console us, to give us his joy.
<G-vec00536-002-s454><console.trösten><de> Und wenn es zur Begegnung kommt, dann ist dies niemals eine eilige Begegnung, weil Gott lange bei uns bleiben will, um uns zu stützen, zu trösten, um uns seine Freude zu schenken.
<G-vec00536-002-s455><console.trösten><en> I will console them in all their troubles.
<G-vec00536-002-s455><console.trösten><de> Ich werde sie in all ihren Schwierigkeiten trösten.
<G-vec00536-002-s456><console.trösten><en> Today, the bourgeois are trying to console themselves with optimistic predictions.
<G-vec00536-002-s456><console.trösten><de> Heute versuchen sich die Bürgerlichen mit optimistischen Vorhersagen selbst zu trösten.
<G-vec00536-002-s457><console.trösten><en> If you have recognized the love and you are driving away it, one day it will obey and go away, then all the world will transform into hell for you, and any good either sensual ones or material ones, they will not able to console you.
<G-vec00536-002-s457><console.trösten><de> Wenn hast du die Liebe erlebt, aber vertreibst sie, einmal, gehorchend dir, wird die Liebe weggehen, und dann wird die ganze Welt in einer Hölle für dich sich verwandeln, und dann werden keine sinnliche oder materielle Vorteile dich trösten können.
<G-vec00536-002-s458><console.trösten><en> It’s therefore especially important that those who have won don’t make fun of the losers but rather console and encourage them.
<G-vec00536-002-s458><console.trösten><de> Deshalb ist es besonders wichtig, dass diejenigen, die gewonnen haben, sich nicht über die Verlierer lustig machen, sondern sie trösten und ermutigen.
<G-vec00536-002-s459><console.trösten><en> This leaves nothing for Naftali Bennett, the far-right "natural ally" of Netanyahu, and at this moment the coalition builders are busy enlarging the Economy Ministry to console him.
<G-vec00536-002-s459><console.trösten><de> Dies lässt für Naftali Bennet, den extrem-rechten „natürlichen Verbündeten“ von Netanjahu, nichts übrig, und in diesem Moment sind die Koalitions-Erbauer eifrig dabei, das Wirtschaftsministerium zu erweitern, um ihn damit zu trösten.
<G-vec00536-002-s460><console.trösten><en> I want to console him.
<G-vec00536-002-s460><console.trösten><de> Ich möchte ihn trösten.
<G-vec00536-002-s461><console.trösten><en> "Shinji, you... you did your best..." she tried to console him, but was cut off by the opening door.
<G-vec00536-002-s461><console.trösten><de> "Shinji, du... du hast dein bestes getan...", versuchte sie ihn zu trösten, wurde aber von der sich öffnenden Tür unterbrochen.
<G-vec00536-002-s462><console.trösten><en> So, to console myself, I remembered the time when I used to see two thousand of them at the Playground... but it took only an hour.
<G-vec00536-002-s462><console.trösten><de> Um mich zu trösten, habe ich mich an die Zeit erinnert, als ich auf dem Sportplatz zweitausend Leute sah... aber das dauerte nur eine Stunde.
<G-vec00536-002-s463><console.trösten><en> Yet I must console myself with the fact that the nature of the subject is apparently more responsible for this issue than my own predilection. Focal diagnosis and electrical reactions are really not important in the study of hysteria, whereas a detailed discus- sion of the psychic processes, as one is wont to receive it from the poet, and the application of a few psychological formulae, allows one to gain an insight into the course of events of hysteria.
<G-vec00536-002-s463><console.trösten><de> Ich muss mich damit trösten, dass für dieses Er- gebniss die Natur des Gegenstandes offenbar eher verantwortlich zu machen ist als meine Vorliebe; Localdiagnostik und elektrische Keaktionen kommen bei dem Studium der Hysterie eben nicht zur Geltung, während eine eingehende Darstellung der seelischen Vor- gänge, wie man sie vom Dichter zu erhalten gewöhnt ist, mir ge- stattet, bei Anwendung einiger weniger psychologischer Formeln doch eine Art von Einsicht in den Hergang einer Hysterie zu gewinnen.
<G-vec00536-002-s464><console.trösten><en> We must find the Lord who consoles us and go to console the people of God.
<G-vec00536-002-s464><console.trösten><de> Wir müssen den Herrn finden, der uns tröstet, und gehen, das Volk Gottes zu trösten.
<G-vec00536-002-s465><console.trösten><en> Because I love you, my one wish is to please and console you in your solitude in the tabernacle.
<G-vec00536-002-s465><console.trösten><de> Weil ich dich liebe, ist es mein einziger Wunsch, dir zu gefallen und dich in der Einsamkeit des Tabernakels zu trösten.
<G-vec00536-002-s466><console.trösten><en> You may ask me any question that arises in your heart, and we will comfort and console each other.
<G-vec00536-002-s466><console.trösten><de> Du kannst mir jede Frage stellen, die in deinem Herzen erwacht, und wir werden uns gegenseitig stärken und trösten.
<G-vec00536-002-s467><console.trösten><en> 7 And they will not break bread among themselves for the sake of him who mourns, so as to console him over the dead. And they will not give them a chalice to drink, so as to console them over their father and mother.
<G-vec00536-002-s467><console.trösten><de> 7Und man wird ihnen nicht Brot brechen bei der Trauer, um jemand zu trösten über den Toten, noch ihnen zu trinken geben aus dem Becher des Trostes über jemandes Vater und über jemandes Mutter.
<G-vec00536-002-s468><console.trösten><en> In order to console herself, she would buy a pint of aniseed, and drink little glassfuls of it with her daughter of an evening, after Antoine had gone back to the cafe.
<G-vec00536-002-s468><console.trösten><de> Um sich zu trösten, kaufte sie einen Liter Kümmel und trank den Schnaps gläschenweise in Gesellschaft ihrer Tochter, während Antoine ins Kaffeehaus zurückkehrte.
<G-vec00536-002-s469><console.trösten><en> Inclusive that God desired to console that soul for my mean and therefore, although the thing cost a lot to me, I satisfied the desire of God.
<G-vec00536-002-s469><console.trösten><de> Inbegriffen, daß Gott wünschte jene Seele für mein Mittel zu trösten und deshalb, obwohl das Ding mir viel kostete, befriedigte ich den Wunsch nach Gott.
<G-vec00536-002-s470><console.trösten><en> Tell me at least a little saying.” B., somewhat surprised at first at having to console the president, said to him then: “The blood of Jesus Christ, the Son of God, cleans us from all sin.”
<G-vec00536-002-s470><console.trösten><de> Sagen Sie mir wenigstens ein Sprüchlein.“ B., erst etwas überrascht, den Präses trösten zu sollen, sagt ihm dann: „Das Blut Jesu Christi, des Sohnes Gottes, macht uns rein von aller Sünde.“ Und dann war er wieder beruhigt.
<G-vec00536-002-s490><console.verwenden><en> We recommend using a single microSD card with your Nintendo Switch console.
<G-vec00536-002-s490><console.verwenden><de> Es wird empfohlen, eine einzige microSD Card mit der Nintendo Switch-Konsole zu verwenden.
<G-vec00536-002-s491><console.verwenden><en> In this chapter we will see how to use processing algorithms from the QGIS Python console, and also how to write your own algorithms using Python.
<G-vec00536-002-s491><console.verwenden><de> In diesem Kapitel werden Sie sehen, wie Sie die SEXTANTE QGIS Python-Konsole verwenden, und auch, wie Sie Ihre eigenen Algorithmen mit Python schreiben können.
<G-vec00536-002-s492><console.verwenden><en> You can use the Fax Console to browse incoming or outgoing faxes, or to manually receive a fax.
<G-vec00536-002-s492><console.verwenden><de> Sie können die Faxkonsole verwenden, um eingehende oder ausgehende Faxe zu durchsuchen oder ein Fax manuell zu empfangen.
<G-vec00536-002-s493><console.verwenden><en> The Mini Wireless Bluetooth V4.0 Dongle USB Adapter with Mic for PS4 allows you to use Bluetooth headset and earphones on PS4 console.
<G-vec00536-002-s493><console.verwenden><de> Der Mini Wireless Bluetooth V4.0 Dongle USB-Adapter mit Mikrofon für PS4 ermöglicht es Ihnen, Bluetooth-Headset und Kopfhörer auf PS4-Konsole zu verwenden.
<G-vec00536-002-s494><console.verwenden><en> When you use the Windows XP installation CD-ROM to start your computer, you can use the Windows Recovery Console to help recover the system software.
<G-vec00536-002-s494><console.verwenden><de> Wenn Sie die Windows XP-Installations-CD zum Starten des Computers verwenden, können Sie die Windows-Wiederherstellungskonsole verwenden, um die Systemsoftware wiederherzustellen.
<G-vec00536-002-s495><console.verwenden><en> Using the SQS console, users should create the SQS queue prior to subscribing it to a Topic.
<G-vec00536-002-s495><console.verwenden><de> Wenn Benutzer die SQS-Konsole verwenden, sollten Sie die SQS-Warteschlange erstellen, bevor diese für ein Thema abonniert wird.
<G-vec00536-002-s496><console.verwenden><en> You can install games to a USB flash drive or to an Xbox 360 4 GB console.
<G-vec00536-002-s496><console.verwenden><de> Hinweis: Sie können ein anderes USB-Flash-Laufwerk zum Speichern von Inhalten für bis zu 2 TB verwenden.
<G-vec00536-002-s497><console.verwenden><en> In case a reboot is required after installing .Net Framework 3.5 SP1, you should restart the computer before starting to use Kaspersky Security 8.0 for Microsoft Exchange Servers administration console.
<G-vec00536-002-s497><console.verwenden><de> Wenn nach der Installation von .Net Framework 3.5 SP1 ein Neustart notwendig ist, sollte dieser erfolgen bevor sie die Administrationskonsole von Kaspersky Security 8.0 für Microsoft Exchange Server verwenden.
<G-vec00536-002-s498><console.verwenden><en> Alternatively, you can start from the AWS Backup console to configure your backup plan or initiate an on-demand backup of Volume Gateway volumes.
<G-vec00536-002-s498><console.verwenden><de> Alternativ können Sie die AWS Backup-Konsole verwenden, um mit der Konfiguration Ihres Sicherungsplans zu beginnen oder eine On-Demand-Sicherung der Volume Gateway-Volumes durchzuführen.
<G-vec00536-002-s499><console.verwenden><en> With a few clicks in the AWS Management Console, you can provision a high-quality desktop experience for any number of users at a cost that is highly competitive with traditional desktops and half the cost of most virtual desktop infrastructure (VDI) solutions.
<G-vec00536-002-s499><console.verwenden><de> Mit dieser Version können Sie Amazon WorkSpaces-Cloud-Desktops verwenden, um die Anforderungen an die Datenhoheit besser zu erfüllen, ohne dabei die Kosten und die Komplexität beim Aufbau der lokalen Virtual Desktop Infrastructure (VDI) auf sich nehmen zu müssen.
<G-vec00536-002-s500><console.verwenden><en> You can set up storage class analysis from the Console, the CLI, or through the S3 APIs.
<G-vec00536-002-s500><console.verwenden><de> Dazu verwenden Sie die AWS-Managementkonsole, die S3 REST API, die AWS SDKs oder die AWS-Befehlszeilenschnittstelle.
<G-vec00536-002-s501><console.verwenden><en> If you use the Local Publishing feature from a remote WSUS console, when your WSUS Server is updated with this update, the remote WSUS consoles must also be updated to make sure the API versions match.
<G-vec00536-002-s501><console.verwenden><de> Wenn Sie die Funktion "Local Publishing" auf einer Remote-WSUS-Konsole verwenden und den WSUS-Server mit diesem Update aktualisieren, muss die Remote-WSUS-Konsole ebenfalls aktualisiert werden, damit die API-Versionen übereinstimmen.
<G-vec00536-002-s502><console.verwenden><en> The vCloud Director Web console is not compatible with the Microsoft Edge browser. Platform Google Chrome
<G-vec00536-002-s502><console.verwenden><de> Hinweis: Die Verwendung von Microsoft Edge wird in Verbindung mit vCloud Director-Installationen, die selbstsignierte Zertifikate verwenden, nicht unterstützt.
<G-vec00536-002-s503><console.verwenden><en> Press C to use Recovery Console.
<G-vec00536-002-s503><console.verwenden><de> Drücken Sie C, um die Wiederherstellungskonsole verwenden.
<G-vec00536-002-s504><console.verwenden><en> When you use the Windows Recovery Console, you can obtain limited access to the NTFS file system, FAT, and FAT32 volumes without starting the Windows graphical user interface (GUI).
<G-vec00536-002-s504><console.verwenden><de> Wenn Sie die Windows-Wiederherstellungskonsole verwenden, erhalten Sie einen eingeschränkten Zugriff auf NTFS-Dateisystem-, FAT- und FAT32-Volumes, ohne die grafische Benutzeroberfläche (GUI) von Windows zu starten.
<G-vec00536-002-s505><console.verwenden><en> • Windows Assessment Toolkit: The Windows Assessment Console can be installed on the following operating systems: Windows 8.1, Windows 8, or Windows 7 with SP 1.
<G-vec00536-002-s505><console.verwenden><de> Wenn Sie eine frühere Version von Windows verwenden, Sie können Bewertungskonsole unter folgenden Betriebssystemen installieren: Windows® 8 oder Windows® 7 mit SP 1.
