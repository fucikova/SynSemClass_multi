<G-vec00441-001-s002><clobber.einprügeln><en> Attacks on Jews provide a pretext for Israel’s rulers to clobber Arab people.
<G-vec00441-001-s002><clobber.einprügeln><de> Angriffe auf Juden liefern Israels Herrschern einen Vorwand, auf arabische Menschen einzuprügeln.
<G-vec00441-001-s003><clobber.einprügeln><en> Attacks on Jews provide a pretext for Israel's rulers to clobber Arab people.
<G-vec00441-001-s003><clobber.einprügeln><de> Angriffe auf Juden liefern Israels Herrschern einen Vorwand, auf arabische Menschen einzuprügeln.
<G-vec00372-002-s000><clobber.einschlagen><en> Just as soon as you begin to do that there's an enemy that's going to come and clobber you.
<G-vec00372-002-s000><clobber.einschlagen><de> Sobald ihr beginnt, das zu tun, gibt es einen Feind, der kommen und auf euch einschlagen wird.
