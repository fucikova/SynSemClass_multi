<G-vec00309-003-s019><come_away.bieten><en> Many rooms come with a spectacular view over the hills.
<G-vec00309-003-s019><come_away.bieten><de> Viele Zimmer bieten eine tolle Ausblick auf die Berge an.
<G-vec00309-003-s020><come_away.bieten><en> Some rooms come with a view of Battery Park.
<G-vec00309-003-s020><come_away.bieten><de> Die modernen Hotelzimmer bieten einen Blick auf die Skyline.
<G-vec00309-003-s021><come_away.bieten><en> Rooms come with the garden view.
<G-vec00309-003-s021><come_away.bieten><de> Die Zimmer bieten einen wunderbaren Ausblick auf den Garten.
<G-vec00309-003-s022><come_away.bieten><en> Non-smoking rooms come with an in-room safe, climate control, flat-screen TV, a dining area and a closet. The property offers a bathroom with a shower and a bidet.
<G-vec00309-003-s022><come_away.bieten><de> Die En-suite Zimmer bieten einen Zimmersafe, eine Minibar, Kabelfernsehen mit Video-on-demand, einen Wohnbereich und einen Schreibtisch sowie eine tolle Aussicht auf das Meer.
<G-vec00309-003-s023><come_away.bieten><en> Rooms in Hotel Garni Elba come with a coffee/tea maker.
<G-vec00309-003-s023><come_away.bieten><de> Die Zimmer im Hotel Garni Elba mit einer Küche bieten Kaffeemaschine/Teekocher.
<G-vec00309-003-s024><come_away.bieten><en> Classic-style rooms at the Il Corallo bed and breakfast come with a TV and a private bathroom including a hairdryer.
<G-vec00309-003-s024><come_away.bieten><de> Die Doppelzimmer sind im klassischen Stil eingerichtet, und bieten Ihnen einen Flachbild-TV und ein eigenes Bad mit einem Haartrockner und Handtüchern.
<G-vec00309-003-s025><come_away.bieten><en> Some rooms come with a stunning view of Arabian Gulf.
<G-vec00309-003-s025><come_away.bieten><de> Die Zimmer bieten einen tollen Blick auf die Lagune.
<G-vec00309-003-s026><come_away.bieten><en> Guest units come with air conditioning, tiled floors and a private terrace with serene ocean views.
<G-vec00309-003-s026><come_away.bieten><de> Die Unterkünfte bieten eine Klimaanlage, Fliesenböden und eine private Terrasse mit ruhigem Meerblick.
<G-vec00309-003-s027><come_away.bieten><en> With astonishing brightness, incomparable contrast and captivating color, images come to life with much greater brightness while also featuring much deeper, more nuanced darks.
<G-vec00309-003-s027><come_away.bieten><de> Mithilfe punktueller Dimmfunktion und hoher maximaler Helligkeit bis zu 600 Nit werden Bilder mit sichtbaren Höhepunkten zum Leben erweckt, die tiefere, nuanciertere Schwarztöne bieten.
<G-vec00309-003-s028><come_away.bieten><en> World of Judaica's Israeli Bookmarks come in a variety of styles and shapes.
<G-vec00309-003-s028><come_away.bieten><de> Wir bieten eine Vielfalt an Mesusas,Tallitot, Jüdischem Schmuck und weiteren Dingen an.
<G-vec00309-003-s029><come_away.bieten><en> Certain rooms come with a balcony.
<G-vec00309-003-s029><come_away.bieten><de> Einige Zimmer bieten einen Balkon.
<G-vec00309-003-s030><come_away.bieten><en> Rooms come with a private bathroom equipped with a bath or shower.
<G-vec00309-003-s030><come_away.bieten><de> Die Zimmer bieten Ihnen ein eigenes Bad mit einer Badewanne oder einer Dusche.
<G-vec00309-003-s031><come_away.bieten><en> The rooms come with en suite bathrooms featuring a shower, free toiletries and a hairdryer.
<G-vec00309-003-s031><come_away.bieten><de> Sie bieten private Badezimmer, die über eine Dusche, einen Fön und eine Badewanne verfügen.
<G-vec00309-003-s032><come_away.bieten><en> All rooms come with a seating area and a toilet with shower, hairdryer and free toiletries.
<G-vec00309-003-s032><come_away.bieten><de> Alle Zimmer bieten einen Sitzbereich sowie ein Bad mit Dusche, Haartrockner und kostenlosen Pflegeprodukten.
<G-vec00309-003-s033><come_away.bieten><en> Quality materials and thorough workmanship guarantee a long service life and a reflection of excellence for years to come.
<G-vec00309-003-s033><come_away.bieten><de> Qualitativ hochwertige Materialien und solide Ausführung bieten die Gewähr für lange Lebensdauer und ein auf Dauer attraktives Erscheinungsbild.
<G-vec00309-003-s034><come_away.bieten><en> The apartments come with a kitchen, a dining area and a private bathroom.
<G-vec00309-003-s034><come_away.bieten><de> Die Apartments bieten Ihnen eine Küche, einen Essbereich und ein eigenes Bad.
<G-vec00309-003-s035><come_away.bieten><en> Some hotel rooms come with a panoramic view over the sea.
<G-vec00309-003-s035><come_away.bieten><de> Die Zimmer bieten einen tollen Ausblick auf das Meer.
<G-vec00309-003-s036><come_away.bieten><en> Room description The spacious rooms each come with a bath/ shower, a hairdryer, a direct dial telephone, a satellite TV, a radio and high speed Internet access.
<G-vec00309-003-s036><come_away.bieten><de> Zimmerbeschreibung Die Hotelzimmer bieten ein eigenes Badezimmer mit Dusche/Badewanne und Haartrockner sowie ein Direktwahltelefon, ein TV-Gerät mit Sat.-Kanälen, ein Radio und DSL-Internetzugang.
<G-vec00309-003-s037><come_away.bieten><en> These comfortable rooms come with a hairdryer and a Jacuzzi supplied in a designer bathroom.
<G-vec00309-003-s037><come_away.bieten><de> Die Zimmer bieten En-suite-Badezimmer mit einer Badewanne, einem Fön und einem Jacuzzi.
<G-vec00309-003-s076><come_away.entstehen><en> Something Great will come of it...
<G-vec00309-003-s076><come_away.entstehen><de> Es wird Großartiges daraus entstehen...
<G-vec00309-003-s077><come_away.entstehen><en> The basis for peace of mind is self-confidence and inner strength, which come from the practice of love and compassion, with a sense of respect for others and concern for their well-being.
<G-vec00309-003-s077><come_away.entstehen><de> Die Grundlage für geistigen Frieden ist Selbstvertrauen und innere Stärke, die durch die Praxis von Liebe und Mitgefühl, mit einem Gefühl des Respekts gegenüber anderen und einer Sorge um ihr Wohlergehen, entstehen.
<G-vec00309-003-s078><come_away.entstehen><en> My works come about in Hamburg Altona and Großenwörden in the inspiring Osteland.
<G-vec00309-003-s078><come_away.entstehen><de> Meine Arbeiten entstehen in Hamburg Altona und in Großenwörden im inspirierenden Osteland.
<G-vec00309-003-s079><come_away.entstehen><en> Combined with khaki, gold, thistle and indigo blue, interesting cold/warm contrasts come to light.
<G-vec00309-003-s079><come_away.entstehen><de> Kombiniert mit Khaki, Gold, Distelgrün und Indigo Blue entstehen interessante Kalt-Warm-Kontraste.
<G-vec00309-003-s080><come_away.entstehen><en> This is how the best services come about.
<G-vec00309-003-s080><come_away.entstehen><de> Auf diese Weise entstehen die besten Services.
<G-vec00309-003-s081><come_away.entstehen><en> An alternative approach may come from the potential therapeutic qualities of CBD.
<G-vec00309-003-s081><come_away.entstehen><de> Ein alternativer Ansatz könnte aus den potenziell therapeutischen Qualitäten von CBD entstehen.
<G-vec00309-003-s082><come_away.entstehen><en> Everything actually needs to come into being from nothing.
<G-vec00309-003-s082><come_away.entstehen><de> Alles muss eigentlich aus dem Nichts entstehen.
<G-vec00309-003-s083><come_away.entstehen><en> They come as well when the priesthood service is to members within the quorum.
<G-vec00309-003-s083><come_away.entstehen><de> Sie entstehen auch, wenn das Kollegium durch das Priestertum den Mitgliedern in seinen eigenen Reihen dient.
<G-vec00309-003-s084><come_away.entstehen><en> Or we can provide a complete team so the aforementioned problems don’t come up in the first place.
<G-vec00309-003-s084><come_away.entstehen><de> Oder wir stellen gleich ein komplettes Team, damit die oben beschriebenen Probleme erst gar nicht entstehen können.
<G-vec00309-003-s085><come_away.entstehen><en> And when a group unites against something, an amazingly powerful strength can come out of it.
<G-vec00309-003-s085><come_away.entstehen><de> Und wenn sich eine Gruppe gegen etwas vereinigt, kann daraus eine mächtige Energie entstehen.
<G-vec00309-003-s086><come_away.entstehen><en> It is important for self-confidence, but it can only come from someone else.
<G-vec00309-003-s086><come_away.entstehen><de> Sie ist wichtig für das Selbstbewusstsein, kann aber nicht aus dem eigenen Ich heraus entstehen.
<G-vec00309-003-s087><come_away.entstehen><en> At least I was able to sense, how his manipulated photographs could come into being.
<G-vec00309-003-s087><come_away.entstehen><de> Zumindest erahne ich gerade, wie seine manipulierte Fotografie entstehen könnte.
<G-vec00309-003-s088><come_away.entstehen><en> The object of much of today’s humanities research and cultural criticism is to demonstrate how an imaginary geography or an imagined community develops permanence and boundaries and ultimately replaces reality itself, and how this happens through identification processes in which some elements are discarded in order for that community’s identity to come into being, be it Swedish, Nordic, European or global.
<G-vec00309-003-s088><come_away.entstehen><de> Gegenstand der geisteswissenschaftlichen Forschung und Kulturkritik ist heute häufig, aufzuzeigen, wie eine imaginäre Geographie oder imaginäre Gemeinschaft Stabilität und Grenzen erhält und am Ende selbst den Platz der Wirklichkeit einnimmt, und wie dies durch Identifikationsprozesse geschieht, in denen manches aussortiert wird, damit die eigene Identität entstehen kann, ganz gleich ob schwedisch, nordisch, europäisch oder global.
<G-vec00309-003-s089><come_away.entstehen><en> Netflix also reported that more than 60% of its rentals come from recommendations that are based off of hyper personalization data. **
<G-vec00309-003-s089><come_away.entstehen><de> Auch Netflix berichtet, dass 60% ihrer Verkäufe aus Vorschlägen entstehen, die Kunden aufgrund ihrer personalisierten Daten erhalten.
<G-vec00309-003-s090><come_away.entstehen><en> You need creativity and skill to make Bronze Age decorations from metal and let the Middle Ages come to life with self decorated beads.
<G-vec00309-003-s090><come_away.entstehen><de> Kreativität und Geschick sind gefragt, wenn aus Metall bronzezeitliche Geschmeide entstehen und selbst verzierte Perlen das Mittelalter auferstehen lassen.
<G-vec00309-003-s091><come_away.entstehen><en> I’m not quite sure how the pictures come about, and why they are what they are.
<G-vec00309-003-s091><come_away.entstehen><de> Ich weiß nicht genau, wie die Bilder entstehen, und woran es liegt, wie sie sind.
<G-vec00309-003-s092><come_away.entstehen><en> Yet we all have long known that extraordinary ideas seldom come from nowhere.
<G-vec00309-003-s092><come_away.entstehen><de> Dabei wissen wir längst, dass außergewöhnliche Einfälle selten aus einem Vakuum heraus entstehen.
<G-vec00309-003-s093><come_away.entstehen><en> The relevant research is in the tradition of the resource-based basis and has not yet decided sufficiently what exactly dynamical capabilities are, where they are rooted in the organization, how they come into being, and how their advantage can be unfolded.
<G-vec00309-003-s093><come_away.entstehen><de> Die in der Tradition des ressourcen-orientierten Ansatzes stehende einschlägige Forschung hat bislang jedoch noch nicht hinreichend bestimmt, was genau unter dynamischen Fähigkeiten zu verstehen ist, wo in der Organisation sie zu verorten sind, wodurch sie entstehen und wie genau sich ihr Nutzen entfaltet.
<G-vec00309-003-s094><come_away.entstehen><en> Time and again almost magical moments come up - so great is the intimacy between the protagonists on stage and the audience.
<G-vec00309-003-s094><come_away.entstehen><de> So entstehen auch immer wieder fast schon magische Momente - so groß wird die Innigkeit zwischen den Akteuren auf der Bühne und dem Publikum.
<G-vec00309-003-s114><come_away.finden><en> "Players like him are hard to come by.
<G-vec00309-003-s114><come_away.finden><de> "Es ist sehr schwer, einen Spieler wie ihn zu finden.
<G-vec00309-003-s115><come_away.finden><en> You’ll hardly come across a model that is prettier and better.
<G-vec00309-003-s115><come_away.finden><de> Ein Exemplar, das schöner oder besser ist, werden Sie mit Sicherheit nicht finden.
<G-vec00309-003-s116><come_away.finden><en> Right in the center of Rotterdam, next to Blaak Station, you will come across this chocolate paradise in the Markthal.
<G-vec00309-003-s116><come_away.finden><de> Mitten im Zentrum von Rotterdam, neben der Blaak Station, finden Sie dieses Schokoladenparadies in der Markthal.
<G-vec00309-003-s117><come_away.finden><en> Our team is made up of people from various backgrounds who together can come up with an answer to any question.
<G-vec00309-003-s117><come_away.finden><de> Es besteht aus Menschen verschiedener Hintergrunds, die gemeinsam für jede Frage eine Antwort finden können.
<G-vec00309-003-s118><come_away.finden><en> It is a humanitarian imperative that the suffering, hunger and deaths finally come to an end.
<G-vec00309-003-s118><come_away.finden><de> Es ist ein Gebot der Menschlichkeit, dass Leiden, Hungern und Sterben endlich ein Ende finden.
<G-vec00309-003-s119><come_away.finden><en> In practice, work opportunities are rather more limited, although there is some seasonal tourist industry work available during the summer if you have the requisite skills and language abilities (Norwegian will come in handy).
<G-vec00309-003-s119><come_away.finden><de> In der Praxis ist die Arbeitserlaubnis trotzdem erschwert, obwohl du sehr schnell in der saisonalen Tourismusbranche eine Arbeit finden kannst, vorausgesetzt, du besitzt die nötigen Anforderungen und Sprachkenntnisse in Norwegisch.
<G-vec00309-003-s120><come_away.finden><en> If you want to learn English, make friends, have fun and explore the UK come and join us in the July and/or August.
<G-vec00309-003-s120><come_away.finden><de> Wenn Sie Englisch lernen, Freunde finden, Spaß haben und das Vereinigte Königreich erkunden möchten, besuchen Sie uns im Juli und / oder August.
<G-vec00309-003-s121><come_away.finden><en> It had saved his ears more then once to be able to come up with a believable explanation why some disaster was not at all related to the fact that he had been close.
<G-vec00309-003-s121><come_away.finden><de> Damit hatte er seine Ohren mehr als einmal retten können, wenn es darum ging eine glaubhaften Erklärung zu finden für die Tatsache, warum irgendeine Katastrophe ganz sicher nichts mit seiner Anwesenheit zu tun hatte.
<G-vec00309-003-s122><come_away.finden><en> It seems like it should be fairly easy for the two sides to come together.
<G-vec00309-003-s122><come_away.finden><de> Es scheint, als sollte es für die beiden Seiten relativ leicht sein, eine Einigung zu finden.
<G-vec00309-003-s123><come_away.finden><en> My immune system has crashed completely, I welcome each bacteria and virus I come across.
<G-vec00309-003-s123><come_away.finden><de> Mein Immunsystem ist so im Eimer, dass ich jede Bakterie und jeden Virus mitnehmen, den ich finden kann.
<G-vec00309-003-s124><come_away.finden><en> True unicorns that meet all of our criteria are hard to come by.
<G-vec00309-003-s124><come_away.finden><de> Wahre Unicorns, die alle unsere Kriterien erfüllen, sind jedoch schwer zu finden.
<G-vec00309-003-s125><come_away.finden><en> I, therefore, do not believe anybody could come up with a universal “sufficient condition” based on which you can always tell whether or not an enterprise has been acting ethically or not.
<G-vec00309-003-s125><come_away.finden><de> So glaube ich nicht, dass es genügt und gelingt, eine allgemeine „hinreichende Bedingung“ zu finden, an der gemessen werden kann, ob ein Unternehmen ethisch handelt oder nicht.
<G-vec00309-003-s126><come_away.finden><en> At that point the Iranian professor believed he’d come up with another argument.
<G-vec00309-003-s126><come_away.finden><de> In diesem Augenblick glaubte der Professor, ein anderes Argument zu finden.
<G-vec00309-003-s127><come_away.finden><en> One more fascinating variation you may come across web is Pontoon.
<G-vec00309-003-s127><come_away.finden><de> Eine andere interessante Internet-basierte Varianz Sie finden könnte, ist Pontoon.
<G-vec00309-003-s128><come_away.finden><en> The very goal of our industry is to come up with a smart and effective solution for these challenges.
<G-vec00309-003-s128><come_away.finden><de> Genau dies ist das Ziel unserer Branche: intelligente und effektive Lösungen für diese Herausforderungen zu finden.
<G-vec00309-003-s129><come_away.finden><en> Currently, there is not enough data and evidence to come up with a solution for that.
<G-vec00309-003-s129><come_away.finden><de> Gegenwärtig gibt es nicht genügend Daten und Beweise, um eine Lösung dafür zu finden.
<G-vec00309-003-s130><come_away.finden><en> Talking to other singles who have similar interests is a great way to come up with ideas to do on a first date.
<G-vec00309-003-s130><come_away.finden><de> Triff andere,die ähnliche Interessen haben, das ist ein perfekter Weg, um Ideen zu finden für gemeinsame Unternehmungen beim ersten Treffen.
<G-vec00309-003-s131><come_away.finden><en> Being a flexible co-packer, we would like to think along with you to come to your personal packaging solution.
<G-vec00309-003-s131><come_away.finden><de> Als flexibler Copacker arbeiten wir gerne mit Ihnen zusammen, um die für Sie ideale Verpackungslösung zu finden.
<G-vec00309-003-s132><come_away.finden><en> He added that he had been waiting for a lifetime to come up with a character together with his dad.
<G-vec00309-003-s132><come_away.finden><de> Er fügte hinzu, dass er auf ein Leben lang gewartet habe, um zusammen mit seinem Vater eine Figur zu finden.
<G-vec00309-003-s133><come_away.gehen><en> There are breathtaking film sets where visitors can come into close contact with the jaws of a great white shark, look underneath Marilyn Monroe's skirt or learn about fear at Jurassic Park.
<G-vec00309-003-s133><come_away.gehen><de> In atemberaubenden Filmkulissen können Besucher auf Tuchfühlung mit dem weißen Hai gehen, Marilyn Monroe unter den Rock schauen oder im Jurassic Park das Fürchten lernen.
<G-vec00309-003-s134><come_away.gehen><en> 44:25 And they shall come at no dead person to become unclean; but for father, or for mother, or for son, or for daughter, for brother, or for sister that hath had no husband, they may become unclean.
<G-vec00309-003-s134><come_away.gehen><de> 44:25 Und keiner soll zu dem Leichnam eines Menschen gehen, daß er unrein werde; nur allein wegen Vater und Mutter, und wegen Sohn und Tochter, wegen eines Bruders und wegen einer Schwester, die keines Mannes gewesen ist, dürfen sie sich verunreinigen.
<G-vec00309-003-s135><come_away.gehen><en> This is where interfaces and the single responsibility principle can come to work hand in hand.
<G-vec00309-003-s135><come_away.gehen><de> Hier können Schnittstellen und das Prinzip der einheitlichen Verantwortung Hand in Hand gehen.
<G-vec00309-003-s136><come_away.gehen><en> May your dream will come true this year.
<G-vec00309-003-s136><come_away.gehen><de> Möge Eure Wünsche auch in diesem Jahr in Erfüllung gehen.
<G-vec00309-003-s137><come_away.gehen><en> I hope you have a wonderful new year, and all your dreams and wished come true next year.
<G-vec00309-003-s137><come_away.gehen><de> Ich hoffe ihr habt ein wunderschönes neues Jahr und all eure Wünsche und Träume gehen dieses Jahr in Erfüllung.
<G-vec00309-003-s138><come_away.gehen><en> Sport has always played an important role in my life, in part because I come from a family of athletes.
<G-vec00309-003-s138><come_away.gehen><de> Auch Sport spielte schon immer eine wichtige Rolle in meinem Leben, egal ob Fußball spielen mit meinen Freunden oder einfach im Morgengrauen joggen gehen.
<G-vec00309-003-s139><come_away.gehen><en> Bishops should encourage priests to come to Medjugorje, to Our Lady's school.
<G-vec00309-003-s139><come_away.gehen><de> Die Bischöfe sollten die Menschen ermutigen, nach Medjugorje zu gehen, in die Schule der Muttergottes.
<G-vec00309-003-s140><come_away.gehen><en> 29 Let no evil talk come out of your mouths, but only what is useful for building up, as there is need, so that your words may give grace to those who hear.
<G-vec00309-003-s140><come_away.gehen><de> 29 Lasset kein faul Geschwätz aus eurem Munde gehen, sondern was nützlich zur Besserung ist, wo es not tut, daß es holdselig sei zu hören.
<G-vec00309-003-s141><come_away.gehen><en> It's just necessary to come to a doctor and pick up that medicine, which, according to the dose and type of hormone, will suit you.
<G-vec00309-003-s141><come_away.gehen><de> Es ist nur notwendig, zu einem Arzt zu gehen und die Medizin zu holen, die je nach Dosis und Art des Hormons zu Ihnen passt.
<G-vec00309-003-s142><come_away.gehen><en> Numerous performers, musicians, actors and entertainers come out onto the streets, and the entire city operates as a public space for the presentation of Croatian tradition.
<G-vec00309-003-s142><come_away.gehen><de> Viele Darsteller, Musiker, Performance-Künstler, Schauspieler und Unterhalter gehen auf die Straßen, während die ganze Stadt den Eindruck erweckt, ein öffentlicher Raum für die Vorstellung der kroatischen Tradition zu sein.
<G-vec00309-003-s143><come_away.gehen><en> The gift certificates of Ferienart Resort & Spa are always welcome and make small and bigger dreams come true.
<G-vec00309-003-s143><come_away.gehen><de> Die Geschenkgutscheine des Ferienart Resort & Spa sind immer willkommen und lassen kleine und größere Wünsche in Erfüllung gehen.
<G-vec00309-003-s144><come_away.gehen><en> But these privileges also come with duties.
<G-vec00309-003-s144><come_away.gehen><de> Diese Privilegien gehen jedoch mit Pflichten einher.
<G-vec00309-003-s145><come_away.gehen><en> They remind you that difficult moments and things that come to an end are signs of something beautiful and new that will soon arise.
<G-vec00309-003-s145><come_away.gehen><de> Sie erinnern daran, dass schwierige Momente und Dinge, die zu Ende gehen, Zeichen von etwas Schönem und Neuem sind, das bald auftauchen wird.
<G-vec00309-003-s146><come_away.gehen><en> Who listens to me, he has won much, because what I promise a man will indeed come true.
<G-vec00309-003-s146><come_away.gehen><de> Wer Mich anhöret, der hat viel gewonnen, denn was Ich einem Menschen verspreche, wird wahrlich in Erfüllung gehen.
<G-vec00309-003-s147><come_away.gehen><en> Thus, you will never come up empty and your apartment is always visitors fit, no matter what happens.
<G-vec00309-003-s147><come_away.gehen><de> Somit gehen Sie nie leer aus und Ihre Wohnung ist immer besuchertauglich, egal was auch passiert.
<G-vec00309-003-s148><come_away.gehen><en> Legend has it that if you want something while you ring the church bell, your wish might come true.
<G-vec00309-003-s148><come_away.gehen><de> Die Legende besagt es, wenn Sie etwas wünschen, während Sie die Kirchenglocke läuten, könnte Ihr Wunsch in Erfüllung gehen.
<G-vec00309-003-s149><come_away.gehen><en> 20 And now you will be silent and not able to speak until the day this happens, because you did not believe my words, which will come true at their appointed time.” (Luke 1:13-20)
<G-vec00309-003-s149><come_away.gehen><de> 1:20 Aber weil du meinen Worten nicht geglaubt hast, die in Erfüllung gehen, wenn die Zeit dafür da ist, sollst du stumm sein und nicht mehr reden können bis zu dem Tag, an dem all das eintrifft.
<G-vec00309-003-s150><come_away.gehen><en> They pleaded with me not to come.
<G-vec00309-003-s150><come_away.gehen><de> Sie haben auf mich eingeredet, nicht zu gehen.
<G-vec00309-003-s151><come_away.gehen><en> Because every Theum virtual expert knows about the others, users can query across them transparently and in parallel as new ones come online—without having to know where to look.
<G-vec00309-003-s151><come_away.gehen><de> Weil jeder virtuelle Experte von Theum jeden anderen „kennt“, können Anwender Abfragen über alle virtuellen Experten hinweg transparent und parallel ausführen, sobald neue virtuellen Experten online gehen – ohne deren Adresse zu kennen.
<G-vec00309-003-s285><come_away.kommen><en> A total of 135 participants from 24 countries, including Canada, Israel, China, Russia and South Africa had come to Magdeburg to discuss the latest status of research, resources and constraints of the insects use.
<G-vec00309-003-s285><come_away.kommen><de> Zu dem 2015 von PPM ins Leben gerufenen Kongress kamen insgesamt 135 Teilnehmer aus 24 Ländern, darunter auch Kanada, Israel, China, Russland und Südafrika, um sich über den neuesten Stand der Forschung, Potentiale und Hindernisse der Insektennutzung auszutauschen.
<G-vec00309-003-s286><come_away.kommen><en> 51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the LORD's house.
<G-vec00309-003-s286><come_away.kommen><de> 51 Wir waren zuschanden geworden, weil wir die Schmach hören mussten und Scham unser Angesicht bedeckte, weil die Fremden über das Heiligtum des Hauses des HERRN kamen.
<G-vec00309-003-s287><come_away.kommen><en> Then they had condemnation meetings on Falun Gong, three-hour sessions; then the policemen would come and talk to me.
<G-vec00309-003-s287><come_away.kommen><de> Es gab Versammlungen, die Falun Gong verdammten; dreistündige Sitzungen, dann kamen Polizisten und redeten mit mir.
<G-vec00309-003-s288><come_away.kommen><en> Finally, participants and manufacturers met back inside the universe and let the evening come to an end with long drinks and other speciality drinks.
<G-vec00309-003-s288><come_away.kommen><de> Zuletzt kamen wieder alle Gäste und Hersteller zum Networking im Inneren des Universums zusammen und ließen den Abend bei Longdrinks und anderen Getränkespezialitäten ausklingen.
<G-vec00309-003-s289><come_away.kommen><en> They had come up with the idea after observing the shepherds who lived in the mountain and looked very healthy and vital, even in advanced age.
<G-vec00309-003-s289><come_away.kommen><de> Auf diese Idee kamen sie, indem sie Hirten beobachteten, die im Gebirge lebten und dabei sehr kräftig, gesund und munter aussahen, sogar in hohem Alter.
<G-vec00309-003-s290><come_away.kommen><en> It is important for me that things run well and that the decisive impulses come from me.
<G-vec00309-003-s290><come_away.kommen><de> Wichtig ist es für mich, dass eine Sache gut läuft und die entscheidenden Anstösse von mir kamen.
<G-vec00309-003-s291><come_away.kommen><en> The architects and interior designers who have been working with the chair come from Scandinavia, Great Britain, Benelux, Italy, Switzerland, Austria and Germany.
<G-vec00309-003-s291><come_away.kommen><de> Die Architekten und Innenarchitekten, die sich mit den Stühlen befassten, kamen aus Skandinavien, Benelux, Großbritannien, Italien, der Schweiz, Österreich und natürlich Deutschland.
<G-vec00309-003-s292><come_away.kommen><en> 5:18 Now the Philistines had come and spread themselves in the valley of Rephaim.
<G-vec00309-003-s292><come_away.kommen><de> 18 Und die Philister kamen und breiteten sich in der Ebene Refaim aus.
<G-vec00309-003-s293><come_away.kommen><en> 15:27 And they come to Elim, and there [are] twelve fountains of water, and seventy palm trees; and they encamp there by the waters.
<G-vec00309-003-s293><come_away.kommen><de> 15:27 Und sie kamen gen Elim, da waren zwölf Wasserbrunnen und siebzig Palmbäume, und sie lagerten sich daselbst ans Wasser.
<G-vec00309-003-s294><come_away.kommen><en> When they had a quarrel about a boundary line, or didn't know what to do about a boy that always sassed his ma no matter how many lickings he got, or when the weevils got their seed corn and they didn't have nothing to plant, they come to Al Miller.
<G-vec00309-003-s294><come_away.kommen><de> Aber wenn sie sich wegen einer Feldgrenze stritten oder nicht wußten, was sie mit einem Jungen tun sollten, der immer frech zu seiner Mutter war, oder wenn die Getreidekäfer ihr Saatgut aufgefressen hatten und sie nichts mehr zum Säen hatten, dann kamen die Leute zu Al Miller.
<G-vec00309-003-s295><come_away.kommen><en> My parents, who still had to go out for food or for work, would come back home with all kinds of stories of what they’d experienced or heard.
<G-vec00309-003-s295><come_away.kommen><de> Meine Eltern, die arbeiten gehen mussten, kamen mit vielen Geschichten nach Hause, die sie erlebt oder gehört hatten.
<G-vec00309-003-s296><come_away.kommen><en> Come morning all other ingredients went into the bowl and the machine did the kneading- 5 min on low and 2 more on level 2.
<G-vec00309-003-s296><come_away.kommen><de> Am nächsten Morgen kamen alle anderen Zutaten für den Teig dazu und wurden mit der Maschine gerührt- so 5 min langsam, 2 min etwas schneller.
<G-vec00309-003-s297><come_away.kommen><en> You are not trying to replace, or reject, the games that have come before.
<G-vec00309-003-s297><come_away.kommen><de> Sie versuchen damit keineswegs, die Spiele, die davor kamen, zu ersetzen oder zu verwerfen.
<G-vec00309-003-s298><come_away.kommen><en> More than 12.000 visitors have come to Nuremberg to inform themselves about new products and services during the three days. 515 exhibitors showcased an extensive range of products and services to the trade visitors on an area of 25,000 square metres.
<G-vec00309-003-s298><come_away.kommen><de> Mehr als 12.000 Besucher kamen nach Nürnberg, um sich an drei Messetagen über die neuesten Trends, Entwicklungen und Innovationen aus dem Bereich der Leistungselektronik zu informieren.
<G-vec00309-003-s299><come_away.kommen><en> Some people from Madrid and Málaga, where Fr. James preached previously in Spain, too hard come to the retreat.
<G-vec00309-003-s299><come_away.kommen><de> Aus Madrid und Málaga, Spanien, wo P. James früher schon einmal predigte, kamen auch einige Leute zu den Exerzitien.
<G-vec00309-003-s300><come_away.kommen><en> 16:15 And Absalom and all the people, the men of Israel, have come in to Jerusalem, and Ahithophel with him,
<G-vec00309-003-s300><come_away.kommen><de> 16:15 Aber Absalom und alles Volk der Männer Israels kamen gen Jerusalem, und Ahitophel mit ihm.
<G-vec00309-003-s301><come_away.kommen><en> We’ve had customers come to us initially asking for “something to help with compliance” or “something to ease the workload on IT,” only to find identity does so much more.
<G-vec00309-003-s301><come_away.kommen><de> Wir hatten Kunden, die anfangs zu uns kamen und nach „etwas, das bei der Compliance mit Vorschriften hilft”oder „etwas, das die Arbeitsbelastung der IT erleichtert” fragten, nur um herauszufinden, dass Identity so viel mehr bewirkt.
<G-vec00309-003-s302><come_away.kommen><en> Finally, during the whole history of the Church, all new ideas, all good initiatives for the future, all impulses for reforms always have come from below.
<G-vec00309-003-s302><come_away.kommen><de> Im übrigen kamen in der ganzen Geschichte der Kirche alle neuen Ideen, alle zukunftsweisenden Initiativen, alle Reformansätze immer von unten.
<G-vec00309-003-s303><come_away.kommen><en> And it cometh to pass after this, the sons of Moab have come in, and the sons of Ammon, and with them of the peoples, against Jehoshaphat to battle.
<G-vec00309-003-s303><come_away.kommen><de> 1 Nach diesem kamen die Kinder Moab, die Kinder Ammon und mit ihnen auch Meuniter, wider Josaphat zu streiten.
<G-vec00309-003-s551><come_away.stammen><en> But where does this Life come from to raise the dead?
<G-vec00309-003-s551><come_away.stammen><de> Woher stammt aber dieses Leben, das die Toten auferstehen lässt.
<G-vec00309-003-s552><come_away.stammen><en> 93.30% 97.80% The majority of visitors come from United States.
<G-vec00309-003-s552><come_away.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Deutschland, Reino Unido, Kanada, Indien & Vereinigte Staaten.
<G-vec00309-003-s553><come_away.stammen><en> Fun fact: Welsh ponies come from Wales and date back to the time of the Celts.
<G-vec00309-003-s553><come_away.stammen><de> Interessante Tatsache: Das Welsh-Pony stammt aus Wales und hat seine Ursprünge in der Zeit der Kelten.
<G-vec00309-003-s554><come_away.stammen><en> The majority of visitors come from United States, Italy, Greece, Spain, Poland & Chile.
<G-vec00309-003-s554><come_away.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Türkei, Polen, Spanien, Niederlande, Schweiz und Deutschland.
<G-vec00309-003-s555><come_away.stammen><en> Most of our clients come from the creative sector.
<G-vec00309-003-s555><come_away.stammen><de> Ein Großteil unserer KundInnen stammt aus dem Kreativbereich.
<G-vec00309-003-s556><come_away.stammen><en> The majority of visitors come from Germany, France, Indonesia, United Kingdom, Austria & Uruguay. City City Rank
<G-vec00309-003-s556><come_away.stammen><de> Der größte Teil der Besucher stammt aus den Ländern Spanien, Deutschland, Australien, Vietnam, Reino Unido und Schweiz.
<G-vec00309-003-s557><come_away.stammen><en> Approximately half of all fossil resources now come from sources lying below the sea floor.
<G-vec00309-003-s557><come_away.stammen><de> Inzwischen stammt rund die Hälfte der fossilen Bodenschätze aus unter dem Meeresgrund liegenden Quellen.
<G-vec00309-003-s558><come_away.stammen><en> Even his Fleur de Sel does not just come from anywhere, rather he produces it himself.
<G-vec00309-003-s558><come_away.stammen><de> Auch sein Fleur de Sel stammt nicht von irgendwo, sondern aus seiner eigenen Produktion.
<G-vec00309-003-s559><come_away.stammen><en> A web analysis service collects, inter alia, data about the website from which a person has come (the so-called referrer), which sub-pages were visited, or how often and for what duration a sub-page was viewed.
<G-vec00309-003-s559><come_away.stammen><de> Ein Webanalysedienst erhebt unter anderem Daten über die Website, von der eine Person stammt (sogenannter Referrer), welche Unterseiten besucht wurden oder wie oft und für wie lange eine Unterseite aufgerufen wurde.
<G-vec00309-003-s560><come_away.stammen><en> Those who come from Eritrea and ask for asylum in Switzerland will have higher hurdles in the future.
<G-vec00309-003-s560><come_away.stammen><de> Wer aus Eritrea stammt und in der Schweiz um Asyl ersucht, hat künftig höhere Hürden.
<G-vec00309-003-s561><come_away.stammen><en> This is quite correct; but the proletariat must also recognize that the ‘national' element does not come from the oppressed and exploited masses, but from their oppressors and exploiters - the bourgeoisie.
<G-vec00309-003-s561><come_away.stammen><de> Dies ist ganz richtig, aber das Proletariat muss auch anerkennen, dass das nationale Element nicht von den unterdrückten und ausgebeuteten Massen stammt, sondern von ihren Unterdrückern und Ausbeutern - die Bourgeoisie.
<G-vec00309-003-s562><come_away.stammen><en> Many of the best grapes come from the limestone Arrábida hills high over the peninsula’s southern coast.
<G-vec00309-003-s562><come_away.stammen><de> Ein Großteil der besten Trauben stammt aus dem kalksteinhaltigen Arrábida Hügelland, das sich hoch über der südlichen Küste der Halbinsel erstreckt.
<G-vec00309-003-s563><come_away.stammen><en> Approximately one third of the members come from the fields of administration and education and approximately two thirds from the world of business, from bank institutes to medium-sized companies to global corporations.
<G-vec00309-003-s563><come_away.stammen><de> Rund ein Drittel der Mitglieder stammt aus dem Verwaltungs- und Bildungsbereich, etwa zwei Drittel aus der Wirtschaft, vom Bankinstitut über das mittelständische Unternehmen bis hin zum Weltkonzern.
<G-vec00309-003-s564><come_away.stammen><en> The basic prerequisites are that the ingredients come from the region, that production is regional, and that the products are firmly rooted in regional gastronomy.
<G-vec00309-003-s564><come_away.stammen><de> Grundvoraussetzungen sind, dass der Rohstoff aus der Region stammt, die Produktion örtlich erfolgt und die Produkte in der regionalen Gastronomie verankert sind.
<G-vec00309-003-s565><come_away.stammen><en> Authentication is a security measure implemented by NTP to ensure that the time signal that is sent comes from where it claims to come from.
<G-vec00309-003-s565><come_away.stammen><de> Die Authentifizierung ist eine Sicherheitsmaßnahme, die von NTP implementiert wird, um sicherzustellen, dass das gesendete Zeitsignal von der Stelle kommt, von der es angeblich stammt.
<G-vec00309-003-s566><come_away.stammen><en> The essential oils come from organic farming.
<G-vec00309-003-s566><come_away.stammen><de> Oliven-ätherische Öl stammt aus kontrolliert biologischem Anbau.
<G-vec00309-003-s567><come_away.stammen><en> The majority of international clients come from Venezuela, Jordan and China.
<G-vec00309-003-s567><come_away.stammen><de> Der Großteil der internationalen Kunden stammt aus Venezuela und Jordanien sowie aus China.
<G-vec00309-003-s568><come_away.stammen><en> Smartly Dressed Games is the name of the company that was created by Nelson and this probably isn’t the last title to come from them.
<G-vec00309-003-s568><come_away.stammen><de> Smartly Dressed Games ist der Name der Firma, die von Nelson gegründet wurde, und das ist wahrscheinlich nicht der letzte Titel, der von ihnen stammt.
<G-vec00309-003-s569><come_away.stammen><en> It’s name come from the work “Skufos” which namastea dating means giant cup in ancient Greek, and it is because it looks like one morphologically as it is surrounded from the higher mountain tops of Lefka Ori.
<G-vec00309-003-s569><come_away.stammen><de> Der Name stammt von “Skufos”, was auf Altgriechisch große Tasse bedeutet: und das aufgrund dessen, weil der Ort von den höheren Berggipfeln von Lefka Ori umgeben ist.
<G-vec00309-003-s570><come_away.treffen><en> In the process, people can come together who work in various forms of the care sector: professional care providers, caregivers in family and neighbour contexts, and those in self-care situations.
<G-vec00309-003-s570><come_away.treffen><de> Dabei treffen Menschen zusammen, die in verschiedener Form Arbeitende in diesem Bereich sind: Beruflich Sorgearbeitende, Sorgearbeitende in familiären und nachbarschaftlichen Zusammenhängen und in der Selbstsorge Tätige.
<G-vec00309-003-s571><come_away.treffen><en> Here you will come across a lot of young people and probably for the first time in a long time feel that there is something happening in the South Island!
<G-vec00309-003-s571><come_away.treffen><de> Hier wirst du viele junge Menschen treffen und vermutlich zum ersten Mal seit längerer Zeit das Gefühl haben, dass in Neuseeland ja doch etwas los ist.
<G-vec00309-003-s572><come_away.treffen><en> All the Syrians, as the UN Security Council resolution says, must sit down and come to an agreement.
<G-vec00309-003-s572><come_away.treffen><de> Alle Syrer sollten in Übereinstimmung mit der Resolution des UN-Sicherheitsrats am Verhandlungstisch zusammenkommen und eine Vereinbarung treffen.
<G-vec00309-003-s573><come_away.treffen><en> The prophet Isaiah brings to view the fearful deception which will come upon the wicked, causing them to count themselves secure from the judgments of God: "We have made a covenant with death, and with hell are we at agreement. When the overflowing scourge shall pass through, it shall not come unto (378) us; for we have made lies our refuge, and under falsehood have we hid ourselves." Isa.
<G-vec00309-003-s573><come_away.treffen><de> Der Prophet Jesaja weist auf die furchtbare Täuschung hin, welche über die Gottlosen kommen wird, so daß sie sich vor den Gerichten Gottes sicher fühlen: „Wir haben mit dem Tode einen Bund und mit der Hölle einen Vertrag gemacht; wenn eine Flut dahergeht, wird sie uns nicht treffen; denn wir haben die Lüge zu unserer Zuflucht und Heuchelei zu unserem Schirm gemacht.“ (Jes.
<G-vec00309-003-s574><come_away.treffen><en> Things often come to me with time, so a day later I sat on the beach and cried.
<G-vec00309-003-s574><come_away.treffen><de> Einen Tag später – manchmal treffen mich Dinge mit Zeitverzögerung – habe ich dann am Strand gesessen und geweint.
<G-vec00309-003-s575><come_away.treffen><en> If you cannot manage to come from Sunday to Sunday, try and come from Thursday or Friday evening until Sunday.
<G-vec00309-003-s575><come_away.treffen><de> Wer nicht von Sonntag bis Sonntag an den Treffen teilnehmen kann, sollte am Donnerstag- oder spätestens Freitagabend ankommen und bis Sonntag bleiben.
<G-vec00309-003-s576><come_away.treffen><en> RegisterLogin Cold water from the depths of the Pacific, the searing heat of the sun, the rotation of the earth –these mighty forces come together at the equator and give rise to a wealth of exotic life.
<G-vec00309-003-s576><come_away.treffen><de> Kaltes Wasser aus den dunklen Tiefen des Pazifiks, die brennende Hitze der Sonne und die Rotation des Erdballs – am Äquator treffen diese gewaltigen Kräfte aufeinander und bringen in dieser Kombination eine Vielfalt an exotischem Leben hervor.
<G-vec00309-003-s577><come_away.treffen><en> As in the best tradition, the workshop is the natural place in which craftsmanship and design come together, inextricably linking production and design.
<G-vec00309-003-s577><come_away.treffen><de> Wie in der besten Tradition ist die Werkstatt der Ort, an dem sich Handwerk und Design treffen und dabei Produktion und Planung unlösbar miteinander verbinden.
<G-vec00309-003-s578><come_away.treffen><en> Numerous national and international representatives from business and politics will come together for this first-class event in order to discuss the most current topics.
<G-vec00309-003-s578><come_away.treffen><de> Anlässlich des hochkarätigen Anlasses treffen sich zahlreiche nationale und internationale Vertreter aus Wirtschaft und Politik in Vaduz, um topaktuelle Themen zu diskutieren.
<G-vec00309-003-s579><come_away.treffen><en> Then we pass through the gates of Heaven and come across the proud people who humbly pray the Pater Noster.
<G-vec00309-003-s579><come_away.treffen><de> Dann werden wir durch die Pforte des Himmels gehen und treffen die Stolzen die demütig das Pater Noster beten.
<G-vec00309-003-s580><come_away.treffen><en> Digitalisation and sustainability – two key “mega trends” come together.
<G-vec00309-003-s580><come_away.treffen><de> Digitalisierung und Nachhaltigkeit – hier treffen zwei Megatrends aufeinander.
<G-vec00309-003-s581><come_away.treffen><en> Schedule of events You can come and get to know the JBL team personally at the following events in April 2018.
<G-vec00309-003-s581><come_away.treffen><de> Auf folgenden Veranstaltungen können Sie uns im Juni 2018 treffen und das JBL Team persönlich kennenlernen.
<G-vec00309-003-s582><come_away.treffen><en> Wherever you go, you will come across open-minded people who will be happy to speak English with you.
<G-vec00309-003-s582><come_away.treffen><de> Überall werden Sie auf aufgeschlossene Menschen treffen, die gerne mit Ihnen Englisch plaudern.
<G-vec00309-003-s583><come_away.treffen><en> If these high-stakes talks come to pass, they would be the first between a sitting US president and a North Korean leader.
<G-vec00309-003-s583><come_away.treffen><de> Eine Reise des nordkoreanischen Außenministers nach Schweden nährt nun Spekulationen über den Austragungsort für dieses erste Treffen zwischen einem amtierenden US-Präsidenten und einem nordkoreanischen Machthaber.
<G-vec00309-003-s584><come_away.treffen><en> Because particular bodily organs correspond to every point, it is possible to come to the conclusion about state of this organs.
<G-vec00309-003-s584><come_away.treffen><de> Weil es jedem Punkt bestimmte Körperorgane entsprechen, ist auf Grund des gemessenen Widerstandes den Beschluss über den Stand dieser Organe zu treffen.
<G-vec00309-003-s585><come_away.treffen><en> Graduates of the Master of Science in International Cooperation in Urban Development come upon a broad field of work which has a strong demand for professionals in international projects about urban development.
<G-vec00309-003-s585><come_away.treffen><de> Absolventen und Absolventinnen des Master of Science International Cooperation in Urban Development treffen auf ein weites Arbeitsfeld mit einer starken Nachfrage nach Fachkräften für internationale Projekte im Bereich der Stadtentwicklung.
<G-vec00309-003-s586><come_away.treffen><en> Divers, snorkelers and musicians dressed in whimsical nautical costumes come together every year in Florida for the Underwater Music Festival.
<G-vec00309-003-s586><come_away.treffen><de> Taucher, Schnorchler und Musiker treffen sich Jahr für Jahr in Florida für das Unterwasser-Musik-Festival.
<G-vec00309-003-s587><come_away.treffen><en> The event aims to create a space in which different voices come together to start dialogue and find solutions and answers to the social, emotional and health problems that women face in today's society. The Forum is an open event, free of charge, with an open debate on women's issues.
<G-vec00309-003-s587><come_away.treffen><de> Mit diesem Forum will versucht werden ein Raum zu schaffen, in welchem sich verschiedene Stimmen treffen, unterschiedliche Meinungen ausgetauscht werden um so einen Dialog anzuregen und Lösungen und Antworten auf die soziale, emotionale und gesundheitliche Problematik zu finden, mit welcher sich die Frau tagtäglich in der Gesellschaft konfrontiert sieht.
<G-vec00309-003-s588><come_away.treffen><en> In the living room, family and friends come together for mutual hours.
<G-vec00309-003-s588><come_away.treffen><de> Im Wohnzimmer treffen sich Familie und Freunde für gemeinsame Stunden.
<G-vec00309-003-s589><come_away.treten><en> Also the cooperation with students regarding bachelor’s and master’s theses as well as compulsory internships, new findings come to light that are included in further product development.
<G-vec00309-003-s589><come_away.treten><de> Auch bei der Zusammenarbeit mit Studierenden in Hinblick auf Bachelor- und Masterarbeiten sowie Pflichtpraktika treten regelmäßig neue Erkenntnisse zu Tage, die in die weitere Produktentwicklung miteinfließen.
<G-vec00309-003-s590><come_away.treten><en> Lung cancer typically develops slowly and symptoms often come on gradually.
<G-vec00309-003-s590><come_away.treten><de> Lungenkrebs entwickelt sich gewöhnlich langsam und die Symptome treten oft schrittweise auf.
<G-vec00309-003-s591><come_away.treten><en> They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.
<G-vec00309-003-s591><come_away.treten><de> Und sie sollen hineingehen in mein Heiligtum und vor meinen Tisch treten, mir zu dienen und meine Sitten zu halten.
<G-vec00309-003-s592><come_away.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which lie outside the area of responsibility of the author, a liability obligation would come into force only in the case in which the contents are aware and technically possible and reasonable, the Use in case of illegal content.
<G-vec00309-003-s592><come_away.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00309-003-s593><come_away.treten><en> In the case of direct or indirect references to third-party websites ("hyperlinks"), which are outside the responsibility of the author, a liability obligation would only come into force in the case in which the author is aware of the contents and is technically possible and reasonable, To prevent the use in the case of unlawful content.
<G-vec00309-003-s593><come_away.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten (“Hyperlinks”), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00309-003-s594><come_away.treten><en> In the case of direct or indirect references to external websites ("hyperlinks"), which are beyond the scope of responsibility of Ryf Sports, a liability obligation would only come into effect in the case in which Ryf Sports is aware of the content and it technically possible and reasonable to prevent the use of illegal content.
<G-vec00309-003-s594><come_away.treten><de> Bei direkten oder indirekten Verweisen auf fremde Webseiten ("Hyperlinks"), die außerhalb des Verantwortungsbereiches von Ryf Sports liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem Ryf Sports von den Inhalten Kenntnis hat und es technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00309-003-s595><come_away.treten><en> emmerich exclusivbrillen GmbH & Co. reserves the right to amend the conditions of the present agreement in part or in full at any time and any such amendments come into force immediately following their publication on the website.
<G-vec00309-003-s595><come_away.treten><de> emmerich exclusivbrillen GmbH & Co.KG behält sich das Recht vor, die Bestimmungen dieses Vertrages jederzeit, ganz oder teilweise abzuändern, und diese Änderungen treten sofort nach Veröffentlichung auf der Webseite in Kraft.
<G-vec00309-003-s596><come_away.treten><en> The resolutions passed at the Extraordinary General Meeting of Kaba will come into effect upon completion of the merger.
<G-vec00309-003-s596><come_away.treten><de> Die Beschlüsse der außerordentlichen Generalversammlung von Kaba treten mit dem Vollzug des Zusammenschlusses in Kraft.
<G-vec00309-003-s597><come_away.treten><en> Any provision of the Contract that expressly or by implication is intended to come into or continue in force on or after termination shall remain in full force and effect.
<G-vec00309-003-s597><come_away.treten><de> 8.6 Jedwede Bestimmung des Vertrags, die ausdrücklich oder stillschweigend in Kraft treten oder bei oder nach Kündigung in Kraft bleiben soll, bleibt in Kraft.
<G-vec00309-003-s600><come_away.treten><en> If amendments are merely insignificant, they shall come into force immediately.
<G-vec00309-003-s600><come_away.treten><de> Sollte es sich lediglich um unwesentliche Änderungen handeln, treten diese umgehend in Kraft.
<G-vec00309-003-s601><come_away.treten><en> Everybody shall come in touch with their own greatness, their own divinity.
<G-vec00309-003-s601><come_away.treten><de> Jeder soll vielmehr mit seiner eigenen Größe, seiner eigenen Göttlichkeit in Verbindung treten.
<G-vec00309-003-s602><come_away.treten><en> All direct or indirect references to other Internet sites (links), which lie outside the area of responsibility of the author, any liability obligation would only come into effect if the author is aware of the contents, and it would be technically possible and reasonable for him to prevent the use in the event of illegal contents.
<G-vec00309-003-s602><come_away.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten, die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00309-003-s603><come_away.treten><en> Straight line projection of the zone upwards indicates that it will come to surface (likely under till cover) very near the north boundary of the Burns Block.
<G-vec00309-003-s603><come_away.treten><de> Die geradlinige Weiterführung der Zone nach oben weist darauf hin, dass sie sehr nahe an der nördlichen Grenze des Burns Blocks zu Tage treten wird (wahrscheinlich unterhalb einer Geschiebemergelschicht).
<G-vec00309-003-s604><come_away.treten><en> The changed terms and conditions come in the place of the previous version of the General Terms and Conditions.
<G-vec00309-003-s604><come_away.treten><de> Die geänderten Bedingungen treten an die Stelle der vorhergehenden allgemeinen Geschäftsbedingungen.
<G-vec00309-003-s605><come_away.treten><en> In the case of direct or indirect references to external websites („links“), which are outside the responsibility of the website operator, a liability obligation would only come into force in the case where the website operator is aware of the contents and it is technically possible for him And it would be reasonable to prevent the use of illegal contents.
<G-vec00309-003-s605><come_away.treten><de> Bei direkten oder indirekten Verweisen auf fremde Internetseiten ("Links"), die außerhalb des Verantwortungsbereiches des Autors liegen, würde eine Haftungsverpflichtung ausschließlich in dem Fall in Kraft treten, in dem der Autor von den Inhalten Kenntnis hat und es ihm technisch möglich und zumutbar wäre, die Nutzung im Falle rechtswidriger Inhalte zu verhindern.
<G-vec00309-003-s607><come_away.treten><en> The new prices will come into force from the announcement of the regulation. The cost of transport and other expenses are calculated separately.
<G-vec00309-003-s607><come_away.treten><de> Die neuen Preise treten mit der Bekanntgabe der Verordnung in Kraft, die Kosten für Transport und Sonstiges werden gesondert berechnet.
<G-vec00309-003-s627><come_away.verfügen><en> The rooms, suites and apartments at Garni Anni come with a balcony with mountain views and a bathroom with shower or bath.
<G-vec00309-003-s627><come_away.verfügen><de> Die Zimmer, Suiten und Apartments im Garni Anni verfügen über einen Balkon mit Bergblick und ein Badezimmer mit einer Dusche oder Badewanne.
<G-vec00309-003-s628><come_away.verfügen><en> All of our products come with a 100 percent guarantee of customer satisfaction.
<G-vec00309-003-s628><come_away.verfügen><de> Alle unsere Produkte verfügen über eine 100-prozentige Garantie der Zufriedenheit unserer Kunden.
<G-vec00309-003-s629><come_away.verfügen><en> Rooms come with flat-screen TVs and tea/coffee making facilities.
<G-vec00309-003-s629><come_away.verfügen><de> Die Zimmer verfügen über einen Flachbild-TV sowie Tee- und Kaffeezubehör.
<G-vec00309-003-s630><come_away.verfügen><en> The welcoming rooms come with a bathroom with a hairdryer, a direct dial telephone, a hire safe and a minibar.
<G-vec00309-003-s630><come_away.verfügen><de> Die freundlich eingerichteten Zimmer verfügen über Bad/WC, Haartrockner, Minibar, Mietsafe und Direktwahltelefon.
<G-vec00309-003-s631><come_away.verfügen><en> Rooms at Sheraton Sopot come with air conditioning and a flat-screen satellite TV.
<G-vec00309-003-s631><come_away.verfügen><de> Die Zimmer im Sheraton Colonia Golf And Spa Resort verfügen über eine Minibar, einen TV und ein eigenes Bad.
<G-vec00309-003-s632><come_away.verfügen><en> All these pickups come with 25K pots, stereo jack, battery clip and other mounting hardware.
<G-vec00309-003-s632><come_away.verfügen><de> Alle AHB-1 Tonabnehmer verfügen über 25K Töpfe, Klinkenstecker, Batterie-Clip und andere Montage-Hardware.
<G-vec00309-003-s633><come_away.verfügen><en> Divná pani Luxury Gallery Rooms provides certain rooms with garden views, and all rooms come with a private bathroom.
<G-vec00309-003-s633><come_away.verfügen><de> Das Divná pani Luxury Gallery Rooms bietet Zimmer mit Gartenblick und alle Zimmer verfügen über ein eigenes Bad.
<G-vec00309-003-s634><come_away.verfügen><en> All units come with a terrace, a kitchenette with a fridge, and a private bathroom with bath or shower.
<G-vec00309-003-s634><come_away.verfügen><de> Die modernen Zimmer verfügen über Holzböden, Kabel/Sat-TV, einen Wasserkocher sowie ein eigenes Bad mit einer Warmwasserdusche.
<G-vec00309-003-s635><come_away.verfügen><en> They come with a microwave, an electric kettle and a fridge as well as bathrooms with a shower, a spa bathtub and dressing gowns.
<G-vec00309-003-s635><come_away.verfügen><de> Sie verfügen über eine Mikrowelle, einen Wasserkocher und eine Kaffee-/Teemaschine sowie über private Badezimmer mit einer Dusche, einem Jacuzzi und kostenlosen Pflegeprodukten.
<G-vec00309-003-s636><come_away.verfügen><en> The rooms come with a private or shared bathroom.
<G-vec00309-003-s636><come_away.verfügen><de> Alle Zimmer verfügen über ein eigenes Bad oder bieten Zugang zu einem Gemeinschaftsbad.
<G-vec00309-003-s637><come_away.verfügen><en> Thus they are virtually maintenance-free, very rarely prone to malfunctions, require no lubricants, may be positioned exactly, have a constant stroke speed, and come with a mechanical self-locking mechanism.
<G-vec00309-003-s637><come_away.verfügen><de> So sind sie nahezu wartungsfrei, wenig fehleranfällig, schmiermittelfrei, exakt positionierbar und verfügen über eine konstante Hubgeschwindigkeit sowie über eine mechanische Selbsthemmung.
<G-vec00309-003-s638><come_away.verfügen><en> All units come with a patio, a kitchen with an oven and a microwave, and a private bathroom with bidet.
<G-vec00309-003-s638><come_away.verfügen><de> Alle Unterkünfte verfügen über eine Terrasse, eine Küche mit einem Backofen und einer Mikrowelle sowie ein eigenes Bad mit einem Bidet.
<G-vec00309-003-s639><come_away.verfügen><en> Bathrooms come with a shower, complimentary toiletries and towels.
<G-vec00309-003-s639><come_away.verfügen><de> Badezimmer verfügen über eine Dusche, einen Fön und Handtücher.
<G-vec00309-003-s640><come_away.verfügen><en> All rooms at the Cinco Calderas come with en suite bathroom complete with amenities.
<G-vec00309-003-s640><come_away.verfügen><de> Alle Zimmer im Cinco Calderas verfügen über ein eigenes Bad mit Pflegeprodukten.
<G-vec00309-003-s641><come_away.verfügen><en> rooms at the Linne come with satellite TV, tea/coffee facilities and a private bathroom with a shower.
<G-vec00309-003-s641><come_away.verfügen><de> Die hellen Zimmer im Linne verfügen über Sat-TV, Kaffee- und Teezubehör sowie ein eigenes Bad mit einer Dusche.
<G-vec00309-003-s642><come_away.verfügen><en> Featuring a balcony with outdoor furniture, the bright apartments come with tiled floors and a kitchenette.
<G-vec00309-003-s642><come_away.verfügen><de> Die hellen Apartments verfügen über einen Balkon mit Gartenmöbeln sowie Fliesenböden und eine Küchenzeile.
<G-vec00309-003-s643><come_away.verfügen><en> All wooden furnished, rooms here come with Satellite television, a fan, and a desk.
<G-vec00309-003-s643><come_away.verfügen><de> Alle mit Holz eingerichteten Zimmer verfügen über Sat-TV, einen Ventilator und einen Schreibtisch.
<G-vec00309-003-s644><come_away.verfügen><en> The non-smoking apartments and studios at the Cathedral all come with a private bathroom with a shower or a bathtub, a fully equipped kitchenette, and a satellite TV.
<G-vec00309-003-s644><come_away.verfügen><de> Die rauchfreien Apartments und Studios im Cathedral verfügen alle über ein eigenes Bad mit einer Dusche oder einer Badewanne, eine komplett ausgestattete Küchenzeile und Sat-TV.
<G-vec00309-003-s645><come_away.verfügen><en> Newer DVD players often come with a high definition upconversion feature as well.
<G-vec00309-003-s645><come_away.verfügen><de> Neuere DVD-Player verfügen häufig auch über eine Funktion zur Konvertierung in High Definition.
