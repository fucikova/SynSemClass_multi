<G-vec00514-002-s076><cover_up.abdecken><en> FH Campus Wien is the only university to cover a wide range of highly skilled health and nursing professions with a bachelor's degree program and master's degree programs in Advanced Nursing Counseling (health and nursing counseling), Advanced Nursing Practice (management) and Advanced Nursing Education (teaching).
<G-vec00514-002-s076><cover_up.abdecken><de> Die FH Campus Wien ist die einzige Hochschule, die mit dem Bachelorstudium und den Masterlehrgängen für Gesundheits- und Pflegeberatung), Advanced Nursing Practice (Management) und Advanced Nursing Education (Lehre) ein breites Spektrum der höher qualifizierten Gesundheits- und Krankenpflege abdeckt.
<G-vec00514-002-s077><cover_up.abdecken><en> Bear in mind that the insurance will not cover incidents caused by unauthorized drivers.
<G-vec00514-002-s077><cover_up.abdecken><de> Berücksichtigen Sie bitte, dass diese Versicherung keine Ereignisse abdeckt, die von nicht autorisierten Fahrern verursacht wurden.
<G-vec00514-002-s078><cover_up.abdecken><en> For these reasons, it is very important to make sure that your insurance policy will cover such scenarios, and that the limit of coverage is high enough.
<G-vec00514-002-s078><cover_up.abdecken><de> Aus diesen Gründen ist es sehr wichtig, dass Ihre Versicherung solche Vorfälle abdeckt und die Deckungssummen hoch genug festgelegt sind.
<G-vec00514-002-s079><cover_up.abdecken><en> The alchemist himself is the Wild Symbol of the game, and this can expand to cover entire reels as it lands.
<G-vec00514-002-s079><cover_up.abdecken><de> Der Alchemist selbst ist das Wild Symbol des Spiels und kann sich so erweitern, dass es ganze Walzen abdeckt.
<G-vec00514-002-s080><cover_up.abdecken><en> The use of templates to cover up parts of the canvas so as to go on painting ‘blind’, is one of the methodological points de départ helping to achieve this controversial effect by which the artist here stages painting anew as feint and sleight of hand, presenting it as a statement against calculated intentionality and outworn (visual) experiences.
<G-vec00514-002-s080><cover_up.abdecken><de> Die Arbeit mit Schablonen, mit denen sie Partien der Leinwand abdeckt, um ‚blind‘ weiter zu malen, ist einer der methodischen Ausgangspunkte für die Realisierung dieses kontroversen Effekts, mit dem die Künstlerin die Malerei hier in neuer Form als Täuschungsmanöver in Szene setzt und uns als Statement gegen das Kalkül und abgenutzte (Seh-)Erfahrungen vor Augen führt.
<G-vec00514-002-s081><cover_up.abdecken><en> In order to ensure their acuity, the sensors must not be damaged or dirty, so the Google covers the sensors on the unmanned body with a glass cover.
<G-vec00514-002-s081><cover_up.abdecken><de> Um ihre Schärfe zu gewährleisten, dürfen die Sensoren nicht beschädigt oder verschmutzt sein, so dass Google die Sensoren am unbemannten Körper mit einer Glasabdeckung abdeckt.
<G-vec00514-002-s082><cover_up.abdecken><en> With clear statements regarding targeted financial ratios – net debt to adjusted EBITDA is to stay between 2 and 2.5, and a liquidity reserve that at a minimum is able to cover all maturities of the next 24 months – the Group intends to keep its A-/BBB rating and safeguard unrestricted access to the capital market.
<G-vec00514-002-s082><cover_up.abdecken><de> Mit klaren Aussagen zu den angestrebten Finanzrelationen - Netto-Finanzverbindlichkeiten zu bereinigtem EBITDA weiterhin zwischen 2 und 2,5 sowie eine Liquiditätsreserve, die mindestens die Fälligkeiten der nächsten 24 Monate abdeckt - will der Konzern ein Rating von A-/BBB halten und den uneingeschränkten Zugang zum Kapitalmarkt sicherstellen.
<G-vec00514-002-s083><cover_up.abdecken><en> Position it so that when you put the diaper on your son, the pad will cover his penis and bottom.
<G-vec00514-002-s083><cover_up.abdecken><de> Bringe es so an, dass es seinen Penis und seinen Hintern abdeckt, wenn du deinem Sohn die Windel anziehst.
<G-vec00514-002-s084><cover_up.abdecken><en> The Invert check box makes the gradient cover the parts of the image that it did not cover before.
<G-vec00514-002-s084><cover_up.abdecken><de> Das Umkehren-Kästchen führt dazu, dass der Gradient die Teile des Bildes abdeckt, die er zuvor nicht abgedeckt hat.
<G-vec00514-002-s085><cover_up.abdecken><en> The fourth area is material and resources which cover what green materials have been used in a particular project and finally indoor environmental quality which looks at measures taken to prevent air pollution and strategies established to gain more daylight into the complex and less thermal energy.
<G-vec00514-002-s085><cover_up.abdecken><de> Der vierte Bereich ist Material und Ressourcen, der abdeckt, welche umweltfreundlichen Materialien in einem bestimmten Projekt verwendet wurden und zuletzt noch die umweltfreundliche Qualität der Inneneinrichtung, die bewertet, welche Maßnahmen umgesetzt wurden, um Luftverschmutzung zu vermeiden und Maßnahmen, die eingesetzt wurden, um mehr Tageslicht zu gewinnen und weniger Thermalenergie für das Gebäude zu verbrauchen.
<G-vec00514-002-s086><cover_up.abdecken><en> Customer-specific torches are developed alongside the standard and modular solutions, which in fact cover the majority of applications.
<G-vec00514-002-s086><cover_up.abdecken><de> Neben Standard- und variablen Baukastenlösungen, die bereits den Großteil der Anwendungen abdeckt, werden auch kundenspezifische Brennervarianten entwickelt.
<G-vec00514-002-s087><cover_up.abdecken><en> As a general contractor, we contribute to project development, cover all specialist planning requirements, and make sure that project management supports your project every step of the way.
<G-vec00514-002-s087><cover_up.abdecken><de> Gesicherte Abwicklung Mit uns verfügen Sie über einen Generalunternehmer, der in der Projektentwicklung mitarbeitet, die Fachplanungen abdeckt und ein komplettes Projektmanagement in der Umsetzung gewährleistet.
<G-vec00514-002-s088><cover_up.abdecken><en> When using the standard contracts, the user always needs to make sure that the single clauses actually cover the individual circumstances they intend to have contractually settled.
<G-vec00514-002-s088><cover_up.abdecken><de> Bei der Verwendung der Vertragsmuster ist von der Verwenderin und dem Verwender immer zu beachten bzw zu prüfen, ob das Vertragsmuster bzw die einzelnen Klauseln den individuellen Sachverhalt, den die Verwenderin und der Verwender vertraglich zu regeln wünscht, auch abdeckt.
<G-vec00514-002-s089><cover_up.abdecken><en> Furthermore, the greater the intuitive confidence bettors expressed in one side winning, the greater the confidence they held that this team would also cover the point spread.
<G-vec00514-002-s089><cover_up.abdecken><de> Je größer darüber hinaus das von den Wettenden zum Ausdruck gebrachte intuitive Vertrauen in den Sieg eines Teams war, desto größer war auch ihr Vertrauen darin, dass dieses Team ebenfalls den Point Spread abdeckt.
<G-vec00514-002-s090><cover_up.abdecken><en> If the insurance they have taken out in their country of origin does not cover all legal and contractual liabilities incurred in Luxembourg they must either adapt their insurance or take out a specific civil liability insurance covering their activities and those of their employees.
<G-vec00514-002-s090><cover_up.abdecken><de> Wenn seine im Herkunftsland abgeschlossene Versicherung nicht die gesamte Haftpflicht in Luxemburg abdeckt, muss der Dienstleister seine Haftpflichtversicherung anpassen oder eine spezifische Haftpflichtversicherung für seine Tätigkeit sowie die seiner Angestellten abschließen.
<G-vec00514-002-s091><cover_up.abdecken><en> If you are unsure whether the mandibular advancement device fits your jaw, we have a tip for you: Cut a square out of a thicker, clean cardboard box, just big enough to fit in your mouth and cover your teeth.
<G-vec00514-002-s091><cover_up.abdecken><de> Sollten Sie sich unsicher sein, ob die Schiene für Ihren Kiefer passt, haben wir einen Tipp für Sie: Schneiden Sie aus einem dickeren, sauberen Pappkarton ein Quadrat aus, gerade so groß, dass es in Ihren Mund passt und die Zähne abdeckt.
<G-vec00514-002-s092><cover_up.abdecken><en> Cases in which a DRG (and thus a payment calculation) does not fully cover the use of medical devices are conceivable.
<G-vec00514-002-s092><cover_up.abdecken><de> Medizinische Anwendungen, bei denen die hinterlegte DRG den Sachkostenanteil des Medizinproduktes nicht vollständig abdeckt, sind vorstellbar.
<G-vec00514-002-s093><cover_up.abdecken><en> To cover your costs, consider taking out a cancellation insurance that will cover your refund.
<G-vec00514-002-s093><cover_up.abdecken><de> Um Ihre Kosten zu decken, sollten Sie eine Stornoversicherung abschließen, die Ihre Rückerstattung abdeckt.
<G-vec00514-002-s094><cover_up.abdecken><en> The Bosch flagship store here is set to play a key role in the premium shopping segment of the future, as it’s one of the first stores to cover many different categories — a USP in the world’s biggest e-commerce market.
<G-vec00514-002-s094><cover_up.abdecken><de> Im Premium Shopping der Zukunft spielt der Flagship-Store von Bosch eine bedeutende Rolle, denn er ist einer der ersten Stores, der zahlreiche Kategorien abdeckt – ein Alleinstellungsmerkmal auf dem größten E-Commerce-Markt der Welt.
<G-vec00514-002-s190><cover_up.bedecken><en> Cover the back of your head with your arms to protect your skull.
<G-vec00514-002-s190><cover_up.bedecken><de> Bedecke die Rückseite deines Kopfes mit deinen Armen, um deinen Schädel zu schützen.
<G-vec00514-002-s191><cover_up.bedecken><en> Cover any pipes or other objects with soil first to avoid damaging them with backfilled concrete.
<G-vec00514-002-s191><cover_up.bedecken><de> Bedecke die Leitungen oder andere Objekte zuerst mit Erde, damit sie nicht beschädigt werden.
<G-vec00514-002-s192><cover_up.bedecken><en> Cover the mold.
<G-vec00514-002-s192><cover_up.bedecken><de> Bedecke die Form.
<G-vec00514-002-s193><cover_up.bedecken><en> In order to enjoy the pure aroma of energy, do not cover the thing with lacquer, or use acrylic.
<G-vec00514-002-s193><cover_up.bedecken><de> Um das reine Aroma der Energie zu genießen, bedecke das Ding nicht mit Lack oder verwende Acryl.
<G-vec00514-002-s194><cover_up.bedecken><en> Cover your skin thickly in moisturizer and then put on a layer to protect the moisturizer while it soaks in.
<G-vec00514-002-s194><cover_up.bedecken><de> Bedecke deine Haut mit einer dicken Schicht Pflegecreme und lege dann eine Stoffschicht darauf, um die Pflegecreme zu schützen, während die Creme einzieht.
<G-vec00514-002-s195><cover_up.bedecken><en> Crusade Prayer (98) For the Grace of God to cover world leaders
<G-vec00514-002-s195><cover_up.bedecken><de> (98) Gebet, damit die Gnade Gottes die Weltführer bedecke.
<G-vec00514-002-s196><cover_up.bedecken><en> When finished, take some plastic wrap, cover everything up and refrigerate for at least 6 hours before serving.
<G-vec00514-002-s196><cover_up.bedecken><de> Anschließend bedecke alles mit Frischhaltefolie und stelle es vor dem Servieren für mindestens 6 Stunden kalt.
<G-vec00514-002-s197><cover_up.bedecken><en> She readjusts her bra, and I cover her with the duvet.
<G-vec00514-002-s197><cover_up.bedecken><de> Sie zieht ihren BH herunter und ich bedecke sie mit dem Quilt.
<G-vec00514-002-s198><cover_up.bedecken><en> Cover your whole head in the mask and leave it on for 20-30 minutes.
<G-vec00514-002-s198><cover_up.bedecken><de> Bedecke den gesamten Kopf mit der Maske und lass sie 20 – 30 Minuten einwirken.
<G-vec00514-002-s199><cover_up.bedecken><en> Be sure to cover plants to protect them from overspray.
<G-vec00514-002-s199><cover_up.bedecken><de> Bedecke Pflanzen, um sie vor dem Farbnebel zu schützen.
<G-vec00514-002-s200><cover_up.bedecken><en> Cover the blister with a bandage.
<G-vec00514-002-s200><cover_up.bedecken><de> Bedecke die Brandblase mit einem Verband.
<G-vec00514-002-s201><cover_up.bedecken><en> Cover the area in sand.
<G-vec00514-002-s201><cover_up.bedecken><de> Bedecke den Bereich mit Sand.
<G-vec00514-002-s202><cover_up.bedecken><en> Cover the seeds in a warm damp paper towel for a few hours, while you prepare your soil.
<G-vec00514-002-s202><cover_up.bedecken><de> Bedecke die Samen ein paar Stunden lang mit einem warmen, feuchten Papiertuch, während du den Boden vorbereitest.
<G-vec00514-002-s203><cover_up.bedecken><en> Cover your hair with a shower cap or plastic wrap.
<G-vec00514-002-s203><cover_up.bedecken><de> Bedecke deine Haare mit einer Duschhaube oder Plastikfolie.
<G-vec00514-002-s204><cover_up.bedecken><en> After you remove the chicken and vegetables to a platter, cover it for 20 minutes before slicing.
<G-vec00514-002-s204><cover_up.bedecken><de> Wenn du das Huhn und das Gemüse auf eine Platte gegeben hast, bedecke es vor dem Aufschneiden 20 Minuten.
<G-vec00514-002-s205><cover_up.bedecken><en> Instead of cutting a flap open, you can leave a hole at the top of the balloon (i.e., don't cover it with papier-mâché) and fill the piñata through this hole. Do not cheat!
<G-vec00514-002-s205><cover_up.bedecken><de> Anstatt ein Loch zu schneiden, kannst du auch einfach ein Loch an der Spitze des Ballons lassen (d. h. bedecke es nicht mit Pappmaché) und die Piñata durch dieses Loch befüllen.
<G-vec00514-002-s206><cover_up.bedecken><en> I liberate my mind, and cover it by the precious blood of Jesus Christ.
<G-vec00514-002-s206><cover_up.bedecken><de> Ich befreie meine Gedanken und ich bedecke sie durch das kostbare Blut Jesu Christi.
<G-vec00514-002-s207><cover_up.bedecken><en> Cover your head to remind you that YAHUSHUA is the King of Jews and we are covered by our Redeemer who lives.
<G-vec00514-002-s207><cover_up.bedecken><de> Bedecke deinen Kopf, um dich daran zu erinnern, daß YAHUSHUA der König der Juden ist und wir bedeckt sind durch unseren Erlöser, der lebt.
<G-vec00514-002-s208><cover_up.bedecken><en> Cover the box spring with the mattress cover too.
<G-vec00514-002-s208><cover_up.bedecken><de> Bedecke auch den Federkern mit dem Matratzenüberzug.
<G-vec00514-002-s247><cover_up.behandeln><en> Non-scientific trainings cover topics such as presentation skills, scientific writing, leadership skills, career planning, time management, conflict management and many more.
<G-vec00514-002-s247><cover_up.behandeln><de> Nicht-wissenschaftliche Trainings behandeln zum Beispiel die Themen Selbstpräsentation, wissenschaftliches Schreiben, Führungskräfteentwicklung, Karriereplanung, Zeit- oder Konfliktmanagement und vieles mehr.
<G-vec00514-002-s248><cover_up.behandeln><en> We just want to mention that a language called “Brazilian” doesn’t exist and that there is a distinction between European and Brazilian Portuguese (we only cover Brazilian Portuguese).
<G-vec00514-002-s248><cover_up.behandeln><de> Hier soll nur kurz erwähnt werden, dass es die Sprache “Brasilianisch” nicht gibt und zwischen Europäischem und Brasilianischem Portugiesisch unterschieden wird (wir behandeln nur das Brasilianische Portugiesisch).
<G-vec00514-002-s249><cover_up.behandeln><en> The modules cover currently important subjects which are selected annually in co-operation with the partners of the survey.
<G-vec00514-002-s249><cover_up.behandeln><de> Die jährlich wechselnden Module behandeln Themen, die in enger Abstimmung mit den Nutzern der Untersuchung festgelegt werden.
<G-vec00514-002-s250><cover_up.behandeln><en> Our team works closely together with your staff to cover all aspects of your customized solution.
<G-vec00514-002-s250><cover_up.behandeln><de> Unsere Mitarbeiter arbeiten mit Ihrem Team zusammen, um maßgeschneiderte Lösungen zu erstellen, die alle Aspekte ihres täglichen Bedarfs behandeln.
<G-vec00514-002-s251><cover_up.behandeln><en> All courses cover specific topics, but may also be tailored to your needs.
<G-vec00514-002-s251><cover_up.behandeln><de> Alle Kurse behandeln spezifische Themen, können jedoch auch auf Ihre Bedürfnisse zugeschnitten werden.
<G-vec00514-002-s252><cover_up.behandeln><en> Still, this cooking courses program gives a great flexibility and can cover also traditional meat dishes as well as pizza and bread making.
<G-vec00514-002-s252><cover_up.behandeln><de> Das Kursprogramm ist allerdings sehr flexibel und kann auch traditionelle Fleischgerichte und andere italienische Spezialitäten wie Pizza und italienische Brote behandeln.
<G-vec00514-002-s253><cover_up.behandeln><en> Cover subjects like domestic policy, foreign policy, interpretation of the constitution, criticisms, and proponents’ and opponents’ viewpoints.
<G-vec00514-002-s253><cover_up.behandeln><de> Behandeln Sie Themen wie Innenpolitik, Außenpolitik, Interpretation der Verfassung, Kritik und Ansichten von Befürwortern und Gegnern.
<G-vec00514-002-s254><cover_up.behandeln><en> It displays, once again in graphical form, all documents that cover a similar topic, so perfectly that full-text searching is only needed to enter the knowledge map.
<G-vec00514-002-s254><cover_up.behandeln><de> Eine ebenfalls grafische Anzeige aller Dokumente, die ein ähnliches Thema behandeln, und die so perfekt funktioniert, dass Sie die Volltextsuche nur zum Einstieg in das Wissensnetz benötigen.
<G-vec00514-002-s255><cover_up.behandeln><en> We cover topics from News Entertainment, Sports and Business.
<G-vec00514-002-s255><cover_up.behandeln><de> Wir behandeln Themen von Nachrichten Unterhaltung, Sport und Wirtschaft.
<G-vec00514-002-s256><cover_up.behandeln><en> We will cover this later.
<G-vec00514-002-s256><cover_up.behandeln><de> Wir werden dies später behandeln.
<G-vec00514-002-s257><cover_up.behandeln><en> We cover the troubles and politics in detail but we also look music, art, and sport.
<G-vec00514-002-s257><cover_up.behandeln><de> Wir behandeln detailliert die Probleme und die Politik, sehen aber auch Musik, Kunst und Sport aus.
<G-vec00514-002-s258><cover_up.behandeln><en> In this lesson, we will cover: the different terms used in a bakery, measurement of ingredients, common nouns, proper nouns and exercises.
<G-vec00514-002-s258><cover_up.behandeln><de> In dieser Lektion werden wir behandeln: die verschiedenen Begriffe, die in einer Bäckerei verwendet werden, die Messung von Zutaten, allgemeine Substantive, Eigennamen und Übungen.
<G-vec00514-002-s259><cover_up.behandeln><en> The theoretical modules will take place in the vocational college (Berufsfachschule) and cover topics such as sales & marketing, business & social studies, retailing & accounting, and business processes in Retail.
<G-vec00514-002-s259><cover_up.behandeln><de> Die theoretischen Module werden in der Berufsschule absolviert und behandeln Themen wie Vertrieb und Marketing, Betriebswirtschaft und Soziales, Handel und Rechnungswesen sowie Geschäftsprozesse im Handel.
<G-vec00514-002-s260><cover_up.behandeln><en> The units are designed to cover basic day-to-day tasks such as writing e-mails, to more specific tasks such as press releases and minutes of meetings.
<G-vec00514-002-s260><cover_up.behandeln><de> Die Unterrichtseinheiten behandeln grundlegende Alltagsaufgaben vom Verfassen von E-Mails bis hin zu spezielleren Texten wie Pressemitteilungen oder Protokollen von Meetings.
<G-vec00514-002-s261><cover_up.behandeln><en> The final topic we will cover is the implication of recreational drug use in disrupted sleep.
<G-vec00514-002-s261><cover_up.behandeln><de> Das letzte Thema, das wir behandeln werden, ist die Auswirkung von Freizeitdrogenkonsum bei gestörtem Schlaf.
<G-vec00514-002-s262><cover_up.behandeln><en> We will first cover 1.c4 c5, and everything which does not transition to the Nf3 lines.
<G-vec00514-002-s262><cover_up.behandeln><de> Wir behandeln zuerst 1.c4 c5 und alles, was nicht zu den 1.Sf3-Varianten überleitet.
<G-vec00514-002-s263><cover_up.behandeln><en> Other topics cover a wide range of general interest subjects ranging from Russian cuisine to history.
<G-vec00514-002-s263><cover_up.behandeln><de> Weitere Themen behandeln ein weites Feld allgemein interessanter Aspekte von der russischen Küche bis hin zur Geschichte.
<G-vec00514-002-s264><cover_up.behandeln><en> We cover server choice and configuration in Chapter 6, Server Configuration, but the point we'd like to briefly make here is simply that the answers to some of these other questions might have implications that force your hand when deciding where your repository will live.
<G-vec00514-002-s264><cover_up.behandeln><de> Die Auswahl und Konfigurierung des Servers werden wir in Kapitel 6, Konfiguration des Servers behandeln; jedoch möchten wir an dieser Stelle kurz darauf hinweisen, dass die Antworten auf einige der anderen Fragen zur Folge haben, dass Sie bei der Entscheidung über den Speicherort für das Projektarchiv keine freie Wahl mehr haben.
<G-vec00514-002-s265><cover_up.behandeln><en> Therefore, library education courses cover "responsibly deal with information: avoid plagiarism" within the environment of the standard "effective use of information".
<G-vec00514-002-s265><cover_up.behandeln><de> Daher behandeln bibliothekspädagogische Kurse im Teil "Informationen verarbeiten" auch den Abschnitt "Verantwortungsbewusst mit Informationen umgehen: Plagiate vermeiden".
<G-vec00514-002-s323><cover_up.decken><en> Place a few seed peanuts on top of the soil and cover.
<G-vec00514-002-s323><cover_up.decken><de> Gib ein paar Saat-Erdnüsse auf die Erde und decke sie zu.
<G-vec00514-002-s324><cover_up.decken><en> As soon as all were in bed and the lights extinguished, the frightful racket commenced, and presently entered Mr. and Mrs. Johnson's room with increased demonstrations, stripping the cover from their bed.
<G-vec00514-002-s324><cover_up.decken><de> Sobald alle zu Bett waren und die Lichter erloschen, begann das schreckliche Spektakel und es betrat mit verstärkten Demonstrationen das Zimmer von Herrn und Frau Johnson und zog die Decke von ihrem Bett.
<G-vec00514-002-s325><cover_up.decken><en> Multiple colours make the small knob either invisibly disappear under the cover or make it a colourful eye-catcher.
<G-vec00514-002-s325><cover_up.decken><de> Verschiedene Farben lassen den kleinen Knauf entweder unsichtbar unter der Decke verschwinden oder machen ihn zum farbenfrohen Blickfang.
<G-vec00514-002-s326><cover_up.decken><en> 12 And they shall take all the sacred vessels with which they officiate in the sanctuary and put them in a violet cloth and cover them with a cover of sea-cow skin and put them on a bar.
<G-vec00514-002-s326><cover_up.decken><de> 12 Und sie sollen alle Geräte+ des Dienstes nehmen, mit denen sie an der heiligen Stätte regelmäßig den Dienst verrichten, und sie sollen sie in ein Tuch in Blau legen und sie mit einer Decke aus Seehundsfellen+ bedecken und sie auf eine Trage legen.
<G-vec00514-002-s327><cover_up.decken><en> Wizard Towers are vulnerable to clusters of Barbarians or giants/any troops with very high health, so cover it with an air defense or Archer Towers.
<G-vec00514-002-s327><cover_up.decken><de> Zauberer-Türme sind gegenüber Gruppen von Barbaren oder Riesen/jeglichen Truppen mit sehr hoher Gesundheit verletzlich, also decke sie mit einer Luftverteidigung oder Bogenschützen-Türmen.
<G-vec00514-002-s328><cover_up.decken><en> The cover of the forest was dense, though the sun still tried to break through, speckling the ground in patches.
<G-vec00514-002-s328><cover_up.decken><de> Die Decke des Waldes war dicht, obwohl die Sonne immer noch versuchte zu durchbrechen und den Boden in Flecken zu sprießen.
<G-vec00514-002-s329><cover_up.decken><en> Cover: oil, abrasion and weather resistant polyurethane.
<G-vec00514-002-s329><cover_up.decken><de> Decke: spezielles, synthetisches Gummi, Öl-, Abrieb-und Witterungsbeständig.
<G-vec00514-002-s330><cover_up.decken><en> Not to freeze by the icy heights both have laid in addition to our warm sleeping-bags still a thin summer sleeping-bag virtually as a kind of cover about us and have connected with a zipper with the Isomatten.
<G-vec00514-002-s330><cover_up.decken><de> Um in den Eisigen Höhen nicht einzufrieren haben zusätzlich zu unseren warmen Schlafsäcken noch einen dünnen Sommerschlafsack quasi als Art Decke über uns beide gelegt und mit einem Reißverschluß mit den Isomatten verbunden.
<G-vec00514-002-s331><cover_up.decken><en> Cover the bowl with foil, place it in the water in the pot, cover with a lid, and steam for about 12 minutes.
<G-vec00514-002-s331><cover_up.decken><de> Decke die Schüssel mit Folie ab, stelle sie in das Wasser im Topf, decke den Topf mit dem Deckel ab und gare es etwa 12 Minuten.
<G-vec00514-002-s332><cover_up.decken><en> Cover the bowl with a wet towel or plastic wrap and keep them in the fridge while you prepare the other ingredients and supplies.
<G-vec00514-002-s332><cover_up.decken><de> Decke die Schüssel mit einem feuchten Handtuch oder Plastikfolie ab und bewahre sie im Kühlschrank auf, während du die anderen Zutaten und die Ausrüstung vorbereitest.
<G-vec00514-002-s333><cover_up.decken><en> Cover the dish and refrigerate it.
<G-vec00514-002-s333><cover_up.decken><de> Decke die Schüssel ab und stelle sie kühl.
<G-vec00514-002-s334><cover_up.decken><en> It was a rather bad day and so I would have preferred to got home directly into bed, pulling the cover over the head.
<G-vec00514-002-s334><cover_up.decken><de> Ich hatte einen eher schlechten Tag und somit wär ich irgendwie lieber daheim direkt ins Bett, Decke über den Kopf.
<G-vec00514-002-s335><cover_up.decken><en> Place sharp objects in the trunk or on the floor, or cover your seats with a thick blanket first.
<G-vec00514-002-s335><cover_up.decken><de> Lege scharfe Gegenstände in den Kofferraum oder auf den Boden, oder decke deine Sitze zuerst mit einer dicken Decke ab.
<G-vec00514-002-s336><cover_up.decken><en> The cover is bordered by a multi-stripe binding of real wood, whose diagonal motive reoccurs in the bottom joint.
<G-vec00514-002-s336><cover_up.decken><de> Eingefasst ist die Decke von einem mehrstreifigen Echtholz-Binding, dessen diagonales Motiv sich auch bei der Bodenfuge wiederfindet.
<G-vec00514-002-s337><cover_up.decken><en> I cover the first two with Microsoft Office365.
<G-vec00514-002-s337><cover_up.decken><de> Die ersten beiden decke ich mit Hilfe von Microsoft Office365 ab.
<G-vec00514-002-s338><cover_up.decken><en> Brush baked rolls with melted butter and cover with a clean kitchen towel to make softer dinner rolls.
<G-vec00514-002-s338><cover_up.decken><de> Bepinsel die gebackenen Brötchen mit geschmolzener Butter und decke sie mit einem Küchentuch ab, damit sie schön weich werden.
<G-vec00514-002-s339><cover_up.decken><en> Cover: abrasion, heat, ozone and weather resistant, EPDM rubber.
<G-vec00514-002-s339><cover_up.decken><de> Decke: abriebfester, wärme-, ozon- und witterungsbeständig EPDM-Gummi mit Keramikummantelung, bis zu +600°C beständig.
<G-vec00514-002-s340><cover_up.decken><en> When desired we embroider your cover with your name, initials or your individual Logo.
<G-vec00514-002-s340><cover_up.decken><de> Auf Wunsch besticken wir Ihre Decke mit Ihrem Namen, Initialen oder Ihrem individuellen Logo.
<G-vec00514-002-s341><cover_up.decken><en> 17:19 And a woman put a cover over the hole, and put crushed grain on top of it, and no one had any knowledge of it.
<G-vec00514-002-s341><cover_up.decken><de> 17:19 Da nahm die Frau eine Decke und breitete sie über die Brunnenöffnung und streute Getreidekörner darüber aus, so daß man nichts erkennen konnte.
<G-vec00514-002-s646><cover_up.umfassen><en> Our services cover everything, including consulting and analysis of the actual situation, constant and intensive project support, and delivery of flexible and user-oriented software and hardware.
<G-vec00514-002-s646><cover_up.umfassen><de> Unser Angebot umfasst alles von der Beratung und der Analyse des Ist-Zustandes über die ständige und intensive Projektbegleitung bis hin zur Lieferung flexibler und anwenderorientierter Software und Hardware.
<G-vec00514-002-s647><cover_up.umfassen><en> The price for the carriage services provided under the Contract of Carriage brokered by Us with the Selected Carrier(s) is included in the Full Price (Art. 3.1 hereof) and if not specifically ordered during the Booking it does not cover any extra services provided by the Selected Carrier in connection with the carriage to the Destination.
<G-vec00514-002-s647><cover_up.umfassen><de> Der Preis der Beförderungsleistungen unter dem durch uns vermittelten Beförderungsvertrag mit einer gewählten Fluggesellschaft ist im Gesamtpreis (Artikel 3.1 dieser AGB) enthalten und umfasst keinerlei zusätzliche Leistungen durch die gewählte Fluggesellschaft in Verbindung mit der Beförderung zum Zielort.
<G-vec00514-002-s648><cover_up.umfassen><en> They cover three years and are updated and revised on an annual basis.
<G-vec00514-002-s648><cover_up.umfassen><de> Es umfasst drei Jahre und wird jährlich aktualisiert und ergänzt.
<G-vec00514-002-s649><cover_up.umfassen><en> The main focus of "light engineering" studies cover lectures, tutorials and practical training in the range of...
<G-vec00514-002-s649><cover_up.umfassen><de> Der Studienschwerpunkt Lichttechnik umfasst Vorlesungen, Übungen und Praktika in den Bereichen...
<G-vec00514-002-s650><cover_up.umfassen><en> Our planning services cover our entire product range for painting, final assembly including all fill-up and test procedures, and efficient air pollution control.
<G-vec00514-002-s650><cover_up.umfassen><de> Unser Planungsangebot umfasst den gesamten Lieferumfang rund um die Lackierung, die Endmontage mit allen Befüll- und Prüfprozessen sowie die effiziente Abluftreinigung.
<G-vec00514-002-s651><cover_up.umfassen><en> 17 (1) Freedom of teaching shall cover, in the context of the teaching tasks to be fulfilled, the organisation of classes, seminars and lectures as regards their content and methodology and the right to express expert scientific and artistic opinions.
<G-vec00514-002-s651><cover_up.umfassen><de> 17 (1) Die Freiheit der Lehre umfasst im Rahmen der zu erfüllenden Lehraufgaben die inhaltliche und methodische Gestaltung von Lehrveranstaltungen sowie das Recht auf Äußerung von wissenschaftlichen und künstlerischen Lehrmeinungen.
<G-vec00514-002-s652><cover_up.umfassen><en> Quality inspections cover all relevant areas of the armoring process – disassembling, bending, welding, installation of the armor and bullet-proof glass, assembly – insuring that our armored cars have no visible or invisible flaws.
<G-vec00514-002-s652><cover_up.umfassen><de> Die Qualittskontrolle umfasst sämtliche relevanten Bereiche des Umbau- und Panzerungsprozesses - die Demontage, das Anbringen der Anbindungen, die Schweissarbeiten, die Montage der Panzerung und der Panzergläser, das Finishing - dabei wird stets garantiert, daß unsere Fahrzeuge weder sichtbare noch versteckte Mängel aufweisen.
<G-vec00514-002-s653><cover_up.umfassen><en> By submitting any information or material, you give the Company an unlimited and irrevocable license to use, execute, show, modify and transmit such information, Material or comments, including any underlying idea, concept or know-how (the term “Material” is intended to cover all projects, files or other attachments sent to us).
<G-vec00514-002-s653><cover_up.umfassen><de> Durch die Bereitstellung von Informationen oder Materialien gewähren Sie ein unbegrenztes und unwiderrufliches Lizenzrecht in Bezug auf die Nutzung, Umsetzung, Anzeige, Änderung und Übermittlung dieser Informationen, Materialien oder Kommentare, einschließlich aller zugrundeliegender Überlegungen, Konzepte oder des entsprechenden Know-hows (der Begriff "Material" umfasst alle uns übermittelten Projekte, Dateien oder sonstigen Anhänge).
<G-vec00514-002-s654><cover_up.umfassen><en> The first of which will cover the basic principles of the Price Action strategy and will be open to any traders who wish to attend.
<G-vec00514-002-s654><cover_up.umfassen><de> Der erste Teil umfasst die Grundprinzipien der Kursbewegungsstrategie und ist für alle interessierten Teilnehmer offen.
<G-vec00514-002-s655><cover_up.umfassen><en> PwC and asset control PwC's income tax advisory services cover all current tax matters.
<G-vec00514-002-s655><cover_up.umfassen><de> Das Dienstleistungsangebot von PwC im Bereich der Ertragsteuerberatung umfasst zum einen die gesamte laufende steuerliche Beratung.
<G-vec00514-002-s656><cover_up.umfassen><en> Please bear in mind, however, that it must be valid in Austria and provide sufficient cover for different health issues (covering medical costs of more than 30,000 euros, including guarantee to cover possible recovery and repatriation costs, and it must be valid for the whole duration of your stay in Austria).
<G-vec00514-002-s656><cover_up.umfassen><de> Hierbei ist aber zu beachten, dass der Gültigkeitsbereich Österreich umfasst und ausreichender Schutz für verschiedene Krankheitsfälle gegeben ist (Deckungssumme deutlich über 30.000 Euro, mit Garantie der Übernahme etwaiger Berge- und Rückführungskosten, für die gesamte Aufenthaltsdauer gültig).
<G-vec00514-002-s657><cover_up.umfassen><en> Objectives The investment is planned to cover schemes in both of SGN’s networks—the Scotland Gas Networks business (i.e. all of Scotland) and the Southern Gas Networks business (i.e. southern England).
<G-vec00514-002-s657><cover_up.umfassen><de> Ziele Das Projekt umfasst Investitionen in beiden SGN-Netzen - sowohl im Scotland Gas Network (d.h. in ganz Schottland) als auch im Southern Gas Network (d.h. im Süden Englands).
<G-vec00514-002-s658><cover_up.umfassen><en> Its innovative range of services cover the entire property life cycle.
<G-vec00514-002-s658><cover_up.umfassen><de> Das innovative Dienstleistungsangebot umfasst den gesamten Lebenszyklus von Immobilien.
<G-vec00514-002-s659><cover_up.umfassen><en> The activities of Dayland Group cover all aspects of project development, including site selection, construction and leasing, as well as marketing and operation.
<G-vec00514-002-s659><cover_up.umfassen><de> Der Tätigkeitsbereich der Dayland Group umfasst die gesamte Projektentwicklung, im Speziellen die Standortauswahl, die Errichtung sowie die Vermietung bis hin zu Marketing und Betrieb.
<G-vec00514-002-s660><cover_up.umfassen><en> ESPON activities cover all EU Member States, plus Iceland, Liechtenstein, Norway and Switzerland, and involve more than 130 bodies across the continent.
<G-vec00514-002-s660><cover_up.umfassen><de> Das Netz umfasst alle EU-Mitgliedstaaten sowie Island, Liechtenstein, Norwegen und die Schweiz und besteht aus mehr als 130 Einrichtungen in ganz Europa.
<G-vec00514-002-s661><cover_up.umfassen><en> Lissoni and his multinational team thus comprehensively cover the areas of architecture, interior and product design, graphics, art direction and corporate identity.
<G-vec00514-002-s661><cover_up.umfassen><de> Mit seinem multinationalen Team umfasst Lissoni die Bereiche Architektur, Innenausstattung, Theater, Restaurants und Hotels, Boote, Läden, Verkaufsräume, Kunstausstellungen, Messestände, Innenausstattungen und Beleuchtung.
<G-vec00514-002-s662><cover_up.umfassen><en> Jansen services cover a wide and detailed field including testing, calculations and dimensioning.
<G-vec00514-002-s662><cover_up.umfassen><de> Der Service von Jansen umfasst ein detailliertes Spektrum mit Prüfungen, Berechnungen und Dimensionierung.
<G-vec00514-002-s663><cover_up.umfassen><en> Sexuality does cover a wider range than body parts and wider range of astrological possibilities than Scorpio or Mars.
<G-vec00514-002-s663><cover_up.umfassen><de> Sexualität umfasst ein viel breiteres Spektrum als Körperteile, und ein viel breiteres Spektrum astrologischer Zuordnungen als Skorpion oder Mars.
<G-vec00514-002-s664><cover_up.umfassen><en> Our products cover the entire range of functional and decorative electroplating technology, including the planning of new systems or the modification of existing plants.
<G-vec00514-002-s664><cover_up.umfassen><de> Unsere Produktpalette umfasst den gesamten Bereich der funktionellen und dekorativen Galvanotechnik, einschließlich Planung von Neuanlagen oder Umbau bereits bestehender Anlagen.
<G-vec00514-002-s722><cover_up.übernehmen><en> As public health funds are only permitted to cover a part of the cost – not the full cost – private dental cover is important for those who set a great store by modern and comprehensive dental care.
<G-vec00514-002-s722><cover_up.übernehmen><de> Da die gesetzlichen Krankenversicherungen die Kosten für Zahnersatz nur sehr eingeschränkt übernehmen dürfen, ist eine private Zusatzversicherung für alle diejenigen wichtig, die Wert auf eine zeitgemäße und leistungsstarke zahnmedizinische Versorgung legen.
<G-vec00514-002-s723><cover_up.übernehmen><en> There is a more affordable alternative: The moneyland.ch survey found that many banks cover the cost of transferring securities – either in whole or in part – for new customers.
<G-vec00514-002-s723><cover_up.übernehmen><de> Es gibt aber eine günstigere Alternative: Viele Banken übernehmen die Transfergebühren für einzelne neue Kunden nach einer individuellen Beurteilung ganz oder teilweise, wie die Umfrage von moneyland.ch ergeben hat.
<G-vec00514-002-s724><cover_up.übernehmen><en> The warranty for the DS/3DS, if something should happen during installation, we cover.
<G-vec00514-002-s724><cover_up.übernehmen><de> Die Haftung für Schäden an eurem DS/3DS, falls wir etwas beim Einbau beschädigen sollten, übernehmen wir.
<G-vec00514-002-s725><cover_up.übernehmen><en> Gross negligence waiver: We cover the costs of the damage, even if you are guilty of gross negligence – for example if you pass a red traffic light on your bike and cause an accident as a result, or if you cause a fire because you went to sleep with a lit cigarette.
<G-vec00514-002-s725><cover_up.übernehmen><de> Grobfahrlässigkeitsverzicht: Wir übernehmen die Schadenkosten auch, wenn Sie grob fahrlässig handeln – also beispielsweise mit dem Velo bei Rot weiterfahren und dadurch einen Unfall verursachen oder einen Brand entfachen, weil Sie mit der brennenden Zigarette eingeschlafen sind.
<G-vec00514-002-s726><cover_up.übernehmen><en> To get there from Luisenplatz we will take the tram 5 at 5:08 pm direction Kranichstein.Entrance fee: 5€ (we cover the rest.
<G-vec00514-002-s726><cover_up.übernehmen><de> Anfahrt vom Luisenplatz um 17:08 Uhr mit der Straßenbahn 5 Richtung Kranichstein.Eintritt: 5€ (Wir übernehmen den Rest.
<G-vec00514-002-s727><cover_up.übernehmen><en> While private health insurance companies sometimes contribute to the cost after submitting the invoice, the statutory health insurance funds do not cover the treatment cost of gold therapy since scientific studies are lacking.
<G-vec00514-002-s727><cover_up.übernehmen><de> Während sich private Krankenversicherungen nach Einreichen der Rechnung manchmal an den Kosten beteiligen, übernehmen die gesetzlichen Kassen die Behandlungskosten der Goldtherapie aufgrund fehlender wissenschaftlicher Studien grundsätzlich nicht.
<G-vec00514-002-s728><cover_up.übernehmen><en> They are also reviewing whether health insurance funds might cover the costs in future.
<G-vec00514-002-s728><cover_up.übernehmen><de> Zudem wird geprüft, ob in Zukunft Krankenkassen die Kosten übernehmen.
<G-vec00514-002-s729><cover_up.übernehmen><en> We have a limited possibility to cover travel expenses.
<G-vec00514-002-s729><cover_up.übernehmen><de> Wir haben eine begrenzte Möglichkeit, Reisekosten zu übernehmen.
<G-vec00514-002-s730><cover_up.übernehmen><en> There are major differences as to whether and to what extent public cost carriers cover or refund direct access treatment costs.
<G-vec00514-002-s730><cover_up.übernehmen><de> Ob und in welchem Umfang öffentliche Kostenträger in diesen Staaten die Behandlungskosten im Direktzugang übernehmen oder erstatten, ist sehr unterschiedlich.
<G-vec00514-002-s731><cover_up.übernehmen><en> We cover the cost of repairing your system or replacing the preselected components should they fail.
<G-vec00514-002-s731><cover_up.übernehmen><de> Wir übernehmen die Kosten für die Reparatur Ihres Systems oder für den Ersatz von ausgewählten Komponenten, wenn sie ausfallen.
<G-vec00514-002-s732><cover_up.übernehmen><en> For instance, if you deposit USD 100 by Moneybookers and then withdraw USD 100, you will see the full amount of USD 100 in your Moneybookers account as we cover all transaction fees both ways for you.
<G-vec00514-002-s732><cover_up.übernehmen><de> Wenn Sie beispielsweise 100 USD per Moneybookers einzahlen und dann 100 USD auszahlen lassen, erhalten Sie auf Ihrem Moneybookers-Konto den vollen Betrag in Höhe von 100 USD, weil wir die Transaktionsgebühren in beide Richtungen für Sie übernehmen.
<G-vec00514-002-s733><cover_up.übernehmen><en> Some universities cover the handling costs for their applicants.
<G-vec00514-002-s733><cover_up.übernehmen><de> Einige Hochschulen übernehmen die Bearbeitungskosten für ihre Bewerberinnen und Bewerber.
<G-vec00514-002-s734><cover_up.übernehmen><en> We cover 100% of the costs for design and gluing (no hidden costs).
<G-vec00514-002-s734><cover_up.übernehmen><de> Die Kosten für Design und Bekleben übernehmen wir zu 100% (keine versteckten Kosten).
<G-vec00514-002-s735><cover_up.übernehmen><en> Private insurances cover the cost of annual skin cancer screenings at any age.
<G-vec00514-002-s735><cover_up.übernehmen><de> Die privaten Krankenkassen übernehmen die Kosten des Hautkrebs-Screenings in jedem Lebensalter in jährlichen Abständen.
<G-vec00514-002-s736><cover_up.übernehmen><en> For Germany, the proceedings are as following: Basically if the indication is appropriate, the health insurance funds cover the costs for aids listed in the aids directory of the GKV Association (central interest group of the statutory health and nursing insurance funds in Germany).
<G-vec00514-002-s736><cover_up.übernehmen><de> Grundsätzlich übernehmen die Krankenkassen bei entsprechender Indikation die Kosten für Hilfsmittel, die im Hilfsmittelverzeichnis des GKV Spitzenverbandes (Zentrale Interessenvertretung der gesetzlichen Kranken- und Pflegekassen in Deutschland) gelistet sind.
<G-vec00514-002-s737><cover_up.übernehmen><en> In this capacity, the company will cover sales and client relationship management, as well as project delivery and business process consulting to Danish businesses.
<G-vec00514-002-s737><cover_up.übernehmen><de> In dieser Funktion wird die Firma den Vertrieb und die Kundenbetreuung sowie die Projektlieferung und die Businessprozess-Beratung für dänische Unternehmen übernehmen.
<G-vec00514-002-s738><cover_up.übernehmen><en> Meal & Beverage – If a Flight Change leads to your flight(s) being delayed by more than 4 hours, We will cover the cost of meal and beverages up to a total of 10 HKD per passenger covered by the Connection Guarantee.
<G-vec00514-002-s738><cover_up.übernehmen><de> Speisen und Getränke: Wenn eine Flugänderung zu einer Verspätung Ihres Flugs oder Ihrer Flüge um mehr als 4 Stunden führt, übernehmen wir die Kosten für Speisen und Getränke in Höhe von insgesamt maximal 10 CHF pro Fluggast, für den die Anschlussgarantie gilt.
<G-vec00514-002-s739><cover_up.übernehmen><en> Upon our request, rejected goods should be sent back to us in sufficient quantities for examination; we will cover the shipping costs where reported defects are proven to be justified.
<G-vec00514-002-s739><cover_up.übernehmen><de> Beanstandete Ware ist auf Verlangen in ausreichender Stückzahl an uns zur Befundung zurückzusenden; wir übernehmen die Transportkosten, wenn sich die Mängelrüge als richtig erweist.
<G-vec00514-002-s740><cover_up.übernehmen><en> Awareness-raising For fishing gear, which accounts for 27% of sea litter, producers would need to cover the costs of waste management from port reception facilities.
<G-vec00514-002-s740><cover_up.übernehmen><de> So werden Hersteller kunststoffhaltiger Fanggeräte die Kosten für das Einsammeln der Abfälle aus den Hafenauffangeinrichtungen sowie den Transport und die Behandlung dieser Abfälle übernehmen müssen.
