<G-vec00309-003-s133><end_up.beenden><en> At the end of the exhibition, a lady working in a pharmacy brought hot drinks for the practitioners.
<G-vec00309-003-s133><end_up.beenden><de> Als die Ausstellung beendet wurde, kam eine Frau, die in einer Apotheke arbeitete, vorbei und bot den Praktizierenden heiße Getränke an.
<G-vec00309-003-s134><end_up.beenden><en> Mitch Gerber from the USA: The ongoing persecution against Falun Gong must truly end.
<G-vec00309-003-s134><end_up.beenden><de> Mitchy Gerber, USA Die Verfolgung von Falun Gong muss beendet werden.
<G-vec00309-003-s135><end_up.beenden><en> The Finn wound up his Formula One career at the end of the 2001 season.
<G-vec00309-003-s135><end_up.beenden><de> Nach der Saison 2001 beendet der Finne seine Formel-1-Karriere.
<G-vec00309-003-s136><end_up.beenden><en> If you are ending a contract because we have told you about an error in the price of the product you have ordered and you do not wish to proceed the contract will end immediately and we will refund you in full for any products which have not been provided.
<G-vec00309-003-s136><end_up.beenden><de> Wenn Sie einen Vertrag stornieren, weil wir Sie über einen Fehler bei der Preisangabe des von Ihnen bestellten Produkts benachrichtigt haben und Sie möchten den Kauf nicht durchführen, wird der Vertrag sofort beendet und wir erstatten Ihnen den vollen Preis für jegliche Produkte, die nicht geliefert wurden.
<G-vec00309-003-s137><end_up.beenden><en> System Password You can assign a System Password for the configuration environment of your Gigaset SE551 WLAN dsl/cable, and specify the period after which a session is to end automatically if no further entry is made.
<G-vec00309-003-s137><end_up.beenden><de> Systemkennwort Sie können ein Systemkennwort für die Bedienoberfläche des Gigaset SX762 WLAN dsl zuweisen und die Zeitdauer angeben, nach der eine Sitzung automatisch beendet wird, wenn keine Eingabe mehr vorgenommen wurde.
<G-vec00309-003-s138><end_up.beenden><en> According to the news appeared in press, while the activity was going on with participation of the expelled academics and CHP Ankara MP Murat Emir, riot police came to Cebeci Campus and told the students to end the activity.
<G-vec00309-003-s138><end_up.beenden><de> Während die Veranstaltung, an der auch entlassene Akademiker und der Abgeordnete der CHP Ankara, Murat Emir, teilnahmen, kamen Polizisten der Schnellen Eingreiftruppe auf den Cebeci-Campus und sagte, die Veranstaltung solle auf Anordnung des Rektors der Universität Ankara beendet werden.
<G-vec00309-003-s139><end_up.beenden><en> Menopause: a term used to describe the permanent cessation of the primary functions of the human ovaries, signalling the end of the fertile phase of a woman's life.
<G-vec00309-003-s139><end_up.beenden><de> Die Menopause ist der Zeitpunkt der letzten spontanen Menstruation im Leben einer Frau, womit auch die Fruchtbarkeit der Frau beendet ist.
<G-vec00309-003-s140><end_up.beenden><en> With the end of the season in California, the price is also on a falling trend.
<G-vec00309-003-s140><end_up.beenden><de> In Florda, Georgia, North Carolina und Kalifornien ist die Saison so gut wie beendet.
<G-vec00309-003-s141><end_up.beenden><en> ENGLISH At the end of the programme The display shows 0 and the end indicator comes on.
<G-vec00309-003-s141><end_up.beenden><de> 15 Am Programmende Wenn das Programm beendet ist, leuchtet die Kontrolllampe „Programmende“ und das Display zeigt 0 an.
<G-vec00309-003-s142><end_up.beenden><en> Unless Assad goes, neither the war nor the wave of refugees will end.
<G-vec00309-003-s142><end_up.beenden><de> Ohne Assads Abgang werden weder der Krieg beendet noch die Flüchtlingswelle gestoppt werden.
<G-vec00309-003-s143><end_up.beenden><en> 1928 - Jørgen Jørgensen decides to start up for himself and end the cooperation in Polar.
<G-vec00309-003-s143><end_up.beenden><de> 1928: Jørgen Jørgensen entschließt sich zur Gründung eines eigenen Unternehmens und beendet seine Teilhaberschaft an Polar.
<G-vec00309-003-s144><end_up.beenden><en> They are initiated with "/*" and end with "*/".
<G-vec00309-003-s144><end_up.beenden><de> Diese werden mit "/*" eingeleitet und "*/" beendet.
<G-vec00309-003-s145><end_up.beenden><en> The Pisoni family has come a long way, over 3 centuries of history, overcoming two world wars, a serious financial crisis in the 1930s and one that is just as serious, which started in 2007 and has not yet come to an end.
<G-vec00309-003-s145><end_up.beenden><de> Die Familie Pisoni hat über 3 Jahrhunderte Geschichte hinweg viel Weg zurückgelegt, zwei Weltkriege, eine schwere Wirtschaftskrise in den 30er Jahren des vergangenen Jahrhunderts und eine ebenso schwere Wirtschaftskrise überstanden, die 2007 begonnen hat und noch nicht beendet ist.
<G-vec00309-003-s146><end_up.beenden><en> e. In Shootout and Heads-Up events, if all players at a table are disconnected and / or sitting out for a large number of hands (typically 250 hands or more in real money tournaments), the match will end and the player with the most chips will advance to the next round.
<G-vec00309-003-s146><end_up.beenden><de> e. Wenn bei Shootout- oder Heads-up-Turnieren die Verbindung aller Spieler an einem Tisch abbricht und/oder alle Spieler für eine große Anzahl an Händen (bei Echtgeld-Turnieren üblicherweise 250 Hände oder mehr) aussetzen, wird das Match beendet und der Spieler mit den meisten Chips rückt in die nächste Runde vor.
<G-vec00309-003-s147><end_up.beenden><en> The conversation has come to an end once circumstances show that the matter concerned has been dealt with conclusively.
<G-vec00309-003-s147><end_up.beenden><de> Beendet ist die Konversation dann, wenn sich aus den Umständen entnehmen lässt, dass der betroffene Sachverhalt abschließend geklärt ist.
<G-vec00309-003-s148><end_up.beenden><en> To see an end to our sweet little baby’s suffering is priceless.
<G-vec00309-003-s148><end_up.beenden><de> Das Leiden unseres süßen kleinen Babys beendet zu haben, ist unbezahlbar.
<G-vec00309-003-s149><end_up.beenden><en> 1 And it came to pass, when Jesus had made an end of commanding his twelve disciples, he departed thence to teach and to preach in their cities.
<G-vec00309-003-s149><end_up.beenden><de> 1 Und es begab sich, als Jesus diese Gebote an seine zwölf Jünger beendet hatte, ging er von dort weiter, zu lehren und zu predigen in ihren Städten.
<G-vec00309-003-s150><end_up.beenden><en> At the end of the row, we will have a total of 34 stitches, the same number as when we started the project.
<G-vec00309-003-s150><end_up.beenden><de> Sobald du die Reihe beendet hast, haben wir insgesamt 34 Maschen, also genauso viele, wie zum Beginn deines Projekts.
<G-vec00309-003-s151><end_up.beenden><en> This is day that always remind us, it is the end of riding horse for the little Big Horn Memorial Horse Ride 2014.
<G-vec00309-003-s151><end_up.beenden><de> Dieser Tag bleibt uns immer im Gedächtnis, er beendet unseren Ritt zu Ehren des Kampfes am Little Big Horn 2014.
<G-vec00309-003-s285><end_up.enden><en> Of course, our service does not end as soon as you have found a suitable venue, because a successful event also includes equipment, a culinary framework and decoration elements.
<G-vec00309-003-s285><end_up.enden><de> Natürlich endet unser Service aber nicht, sobald Sie einen passenden Austragungsort gefunden haben, denn eine gelungene Veranstaltung beinhaltet auch die Ausstattung, einen kulinarischen Rahmen und Dekorationselemente.
<G-vec00309-003-s286><end_up.enden><en> Hitting the ground will end your flight.
<G-vec00309-003-s286><end_up.enden><de> Auf dem Boden endet Ihr Flug.
<G-vec00309-003-s287><end_up.enden><en> If the dealer’s second card results in a blackjack, your entire wager will be collected by the dealer and the game will come to an end.
<G-vec00309-003-s287><end_up.enden><de> Wenn die zweite Karte des Gebers zu einem Blackjack führt, wird Ihr gesamter Einsatz vom Geber eingezogen, und das Spiel endet.
<G-vec00309-003-s288><end_up.enden><en> And that is terrible, it could give rise to a war that will never end,” he said at the European premiere.
<G-vec00309-003-s288><end_up.enden><de> Und das ist furchtbar, denn es könnte einen Krieg heraufbeschwören, der nie endet“, erklärt er anlässlich der Uraufführung von „Three Posters“ in Europa.
<G-vec00309-003-s289><end_up.enden><en> But our program philosophy doesn't end there.
<G-vec00309-003-s289><end_up.enden><de> Unsere Programmphilosophie endet damit aber nicht.
<G-vec00309-003-s290><end_up.enden><en> The building process will end by the end of Summer 2017.
<G-vec00309-003-s290><end_up.enden><de> Der Bauprozess endet bis zum Ende des Sommers 2017.
<G-vec00309-003-s291><end_up.enden><en> Pleasure doesn’t need to end when you leave the Gasthof Brandstätter to return home. You can also take some delicious items home with you.
<G-vec00309-003-s291><end_up.enden><de> Damit der Genuss nicht endet, wenn Sie den Gasthof Brandstätter in Salzburg wieder verlassen müssen, können Sie die Köstlichkeiten auch gerne mit nach Hause nehmen.
<G-vec00309-003-s292><end_up.enden><en> The cancellation proceedings before OHIM end with a decision, with which the opposed trademark is cancelled or partially cancelled or with which the request for cancellation is rejected.
<G-vec00309-003-s292><end_up.enden><de> Das Löschungsverfahren vor dem Harmonisierungsamt endet mit einem Beschluss, mit dem die angegriffene Marke gelöscht oder teilweise gelöscht wird oder mit dem der Antrag auf Löschung zurückgewiesen wird.
<G-vec00309-003-s293><end_up.enden><en> The conception phase will end in September 2020.
<G-vec00309-003-s293><end_up.enden><de> Im September 2020 endet die Konzeptionsphase.
<G-vec00309-003-s294><end_up.enden><en> Conditions IMPORTANT NOTIFICATION All those high speed departures from Madrid, or those that pass through Madrid to Castellón or Oropesa del Mar, will be affected until further notice with the end of the line being Valencia.
<G-vec00309-003-s294><end_up.enden><de> Conditions WICHTIGE MITTEILUNG Alle Bahnfahrten ab Madrid, oder die über Madrid gehen, mit Ankunft in Castellón de la Plana oder Oropesa Del Mar sind betroffen, und die Fahrt endet bis auf weiteres in Valencia; wir benachrichtigen Sie sofort, falls RENFE uns Änderungen mitteilen sollte.
<G-vec00309-003-s295><end_up.enden><en> For over 100 cows, calves and sheep this event marks the end of their stay in altitude where they enjoyed the fresh mountain air, tasty grass and cool nights.
<G-vec00309-003-s295><end_up.enden><de> Almabtrieb mit Herbstfest Für die Kühe, Kälber und Schafe endet damit der Aufenthalt in luftiger Höhe, bei frischer Bergluft, würzigem Gras und kühlen Nächten.
<G-vec00309-003-s296><end_up.enden><en> But to depart entirely without faith from earth is a hopeless state and will end with renewed banishment, because the gates of the beyond will close the moment the old earth is dissolved.
<G-vec00309-003-s296><end_up.enden><de> Doch ganz ohne Glauben abzuscheiden von der Erde ist hoffnungslos und endet mit der Neubannung, weil das Jenseits die Tore geschlossen hat mit dem Moment des Auflösens der alten Erde.
<G-vec00309-003-s297><end_up.enden><en> As a sentient being, all the thoughts you have in life will end with death.
<G-vec00309-003-s297><end_up.enden><de> Als fühlendes Wesen, alle Gedanken, die Sie im Leben haben, wird mit dem Tod endet.
<G-vec00309-003-s298><end_up.enden><en> That's really hard to cope with, because I tend to get carried away by it, and end up being hurt myself.
<G-vec00309-003-s298><end_up.enden><de> Es ist wirklich schwer, dies zu bewältigen, weil ich dazu neige, es mit mir mitzutragen und es endet damit, daß ich mir selbst wehtue.
<G-vec00309-003-s299><end_up.enden><en> Therefore, their terms of office end with the conclusion of the Annual General Meeting that decides on discharge for the 2013 financial year.
<G-vec00309-003-s299><end_up.enden><de> Ihre Amtszeit endet daher mit Beendigung der Hauptversammlung, die über die Entlastung für das Geschäftsjahr 2013 beschließt.
<G-vec00309-003-s300><end_up.enden><en> The prayer of Psalm 40, however, does not end against such a dark background.
<G-vec00309-003-s300><end_up.enden><de> Doch das Gebet des Psalm 40 endet nicht mit diesem finsteren Gedanken.
<G-vec00309-003-s301><end_up.enden><en> Preparation does not end with registration and booking your trip.
<G-vec00309-003-s301><end_up.enden><de> Die Vorbereitung endet nicht mit der Registrierung und der Buchung Ihrer Reise.
<G-vec00309-003-s302><end_up.enden><en> The deadline for accepting the offer begins on the day following the dispatch of the offer by the customer immediately and shall end with the end of the fifth day, which follows the dispatch of the offer.
<G-vec00309-003-s302><end_up.enden><de> Die Frist zur Annahme des Angebots beginnt am Tag nach der Absendung des Angebots durch den Kunden zu laufen und endet mit dem Ablauf des fünften Tages, welcher auf die Absendung des Angebots folgt.
<G-vec00309-003-s303><end_up.enden><en> 1. When the ECB determines that direct supervision by the ECB of a supervised entity or a supervised group will end, the ECB shall issue an ECB decision to each supervised entity concerned specifying the date and reasons why the direct supervision will end.
<G-vec00309-003-s303><end_up.enden><de> (1) Bestimmt die EZB, dass die direkte Beaufsichtigung eines beaufsichtigten Unternehmens oder einer beaufsichtigten Gruppe durch die EZB endet, erlässt die EZB für jedes betroffene beaufsichtigte Unternehmen einen Beschluss, in dem der Tag festgelegt wird, an dem die direkte Beaufsichtigung endet, und die Gründe für die Beendigung.
<G-vec00309-003-s304><end_up.endkunden><en> To this end, in the reporting year the previously separate sales structures of Zumtobel and Thorn were merged to form a single sales organisation structured according to three sales channels: project business, end customer and wholesale.
<G-vec00309-003-s304><end_up.endkunden><de> Dazu wurden im Berichtsjahr die bislang getrennten Vertriebe von Zumtobel und Thorn in eine gemeinsame Vertriebsorganisation zusammengeführt und diese nach drei Vertriebskanälen – Projektgeschäft, Endkunden und Großhandel – strukturiert.
<G-vec00309-003-s305><end_up.endkunden><en> If, despite appropriate collection measures, the respective provider is unable to collect debts outstanding for the use of your 0900, 0901 or 0906 number from the end customer (the person who is calling your 0900, 0901 or 0906 number), the respective provider may reclaim the amount already paid to Sunrise for the respective Sunrise provided service.
<G-vec00309-003-s305><end_up.endkunden><de> Alle Informationen Charge-Back Wenn der jeweilige Provider die Forderungen für die Inanspruchnahme Ihrer 0900-, 0901- oder 0906-Nummern gegenüber dem Endkunden (auf Ihre 0900-, 0901- oder 0906-Nummer anrufende Person) trotz entsprechender Inkassomassnahmen nicht einbringen kann, kann der jeweilige Provider den für diese Leistungen an Sunrise ausbezahlten Betrag von Sunrise zurückfordern.
<G-vec00309-003-s306><end_up.endkunden><en> Whether in the healthcare industry, marketing or for the end customer, data analysis personalises experiences, increases efficiency and, thanks to data-driven decision making, offers companies competitive advantages.
<G-vec00309-003-s306><end_up.endkunden><de> Ob in Health Care, im Marketing oder beim Endkunden: Die Datenanalyse personalisiert Erlebnisse, steigert die Effizienz und verschafft Unternehmen aufgrund der datenbasierten Entscheidungsfindung Wettbewerbsvorteile.
<G-vec00309-003-s307><end_up.endkunden><en> In your daily operations, this translates into dedicated account managers who have full oversight of your entire logistic chain, from supplier to end customer.
<G-vec00309-003-s307><end_up.endkunden><de> In der Praxis bedeutet das, dass Sie einen festen Ansprechpartner haben, der einen umfassenden Überblick über Ihre gesamte Lieferkette hat, vom Lieferanten bis zum Endkunden.
<G-vec00309-003-s308><end_up.endkunden><en> Light current (data) StakoHome distributor is ready to meet the demand of 99 percent of end users and developers, and the remaining one percent is on an extensive and demanding installations with multiple data ports and a number of active elements that the Stakohome distributor is not designed for.
<G-vec00309-003-s308><end_up.endkunden><de> Der Stakohome Schwachstrom-(Daten-)Verteiler ist dafür ausgelegt, die Anfrage von 99 Prozent der Endkunden und Developer zu befriedigen; das verbleibende Prozent stellen umfangreiche und anspruchsvolle Installationen mit einer höheren Anzahl an Datenports und einer Vielzahl aktiver Elemente dar, für die der Stakohome Verteiler nicht dimensioniert ist.
<G-vec00309-003-s309><end_up.endkunden><en> Market sales have increased to 63 billion euros in 2018, an increase of around ten percent compared to 2017.1 "The demand for modern and innovative logistics concepts in this area is high, because the goods are to be delivered to the end customer as quickly, cost-effectively and efficiently as possible.
<G-vec00309-003-s309><end_up.endkunden><de> Der Marktumsatz wird sich 2018 voraussichtlich auf 63 Milliarden Euro erhöhen und damit eine Steigerung von rund zehn Prozent im Vergleich zu 2017 vorweisen können.1 „Der Bedarf an modernen und innovativen Logistikkonzepten in diesem Bereich ist groß, denn die Ware soll möglichst schnell, kostengünstig und effizient an den Endkunden geliefert werden.
<G-vec00309-003-s310><end_up.endkunden><en> With the presentation of your studio, you will reach customers and end clients in print media and online in market research agencies and industry for a whole year.
<G-vec00309-003-s310><end_up.endkunden><de> Mit Ihrer Studio-Präsentation erreichen Sie in Print und Online Auftraggeber und Endkunden in Instituten und Industrie - ein ganzes Jahr lang.
<G-vec00309-003-s311><end_up.endkunden><en> GPS Tracking & Anti-and endorsements from Kronings end customers and professional users.
<G-vec00309-003-s311><end_up.endkunden><de> Lesen Sie Meinungen und Empfehlungen von Kronings Endkunden und professionelle Anwendern.
<G-vec00309-003-s312><end_up.endkunden><en> Web2Print is above all an ideal channel for the production of on-demand marketing and advertising materials, business stationery and reports or conference documents, and as a system solution for direct end users.
<G-vec00309-003-s312><end_up.endkunden><de> Web2Print eignet sich vor allem für die Produktion bedarfsgerechter Marketing- und Werbedruckerzeugnisse, für Geschäftsausstattungen und -berichte, Tagungsunterlagen und als Systemlösung für den direkten Endkunden.
<G-vec00309-003-s313><end_up.endkunden><en> Time programs and scenes can be created by the end customer.
<G-vec00309-003-s313><end_up.endkunden><de> Zeitprogramme und Szenen können durch den Endkunden erstellt werden.
<G-vec00309-003-s314><end_up.endkunden><en> With its new online shop, LIQUI MOLY is for the first time also addressing end customers, adding a B2C orientation to its website.
<G-vec00309-003-s314><end_up.endkunden><de> Durch den neuen Onlineshop spricht LIQUI MOLY nun erstmals auch Endkunden an und erweitert so seine Onlinepräsenz um eine B2C-Ausrichtung.
<G-vec00309-003-s315><end_up.endkunden><en> Next was creating a user interface that is very intuitive, designed to help the end client easily withdraw data needed for regulatory compliance audits.
<G-vec00309-003-s315><end_up.endkunden><de> Danach wurde eine sehr intuitive Benutzeroberfläche erstellt, die dem Endkunden dabei helfen sollte, für regulatorische Compliance-Audits benötigte Daten einfach zu entnehmen.
<G-vec00309-003-s316><end_up.endkunden><en> Since 1995, Mannesmann Line Pipe has been organizing technical customer conferences which have quickly developed into a successful information platform for interested employees of public utilities, pipe-laying companies, engineering offices and end customers.
<G-vec00309-003-s316><end_up.endkunden><de> Seit 1995 führt Mannesmann Line Pipe Kundenfachtagungen durch, die sich schnell zu einer erfolgreichen Informationsplattform interessierter Mitarbeiter von Stadtwerken, Verlegeunternehmen, Ingenieurbüros und Endkunden entwickelt haben.
<G-vec00309-003-s317><end_up.endkunden><en> For this, we conduct deep research into real-life problems that end customers and farmers face in vertical and indoor farming software development.
<G-vec00309-003-s317><end_up.endkunden><de> Zu diesem Zweck führen wir tief greifende Untersuchungen zu realen Problemen durch, mit denen Endkunden und Landwirte bei der Softwareentwicklung für vertikale und Indoor-Landwirtschaft konfrontiert sind.
<G-vec00309-003-s318><end_up.endkunden><en> End customers need to activate their servers with Lenovo by providing the address of the server location to ensure coverage and service delivery for 4 or 8 Hour Service.
<G-vec00309-003-s318><end_up.endkunden><de> Endkunden müssen ihre Server bei Lenovo aktivieren, indem sie die Adresse des Serverstandorts angeben, um für die Verfügbarkeit und die Bereitstellung von 4-Stunden-Service zu sorgen.
<G-vec00309-003-s319><end_up.endkunden><en> A distributor is responsible for selling the product to end customers through the retailers and wholesalers.
<G-vec00309-003-s319><end_up.endkunden><de> Ein Distributor ist für den Verkauf des Produkts an Endkunden durch Einzelhändler und Großhändler verantwortlich.
<G-vec00309-003-s320><end_up.endkunden><en> Rogac produces exclusively for industrial clients who demand a professional and reliable partner for the ever increasing expectations of their end customers.
<G-vec00309-003-s320><end_up.endkunden><de> Rogac produziert exklusiv für Industriekunden, die einen professionellen und zuverlässigen Partner für die steigenden Erwartungen der Endkunden verlangen.
<G-vec00309-003-s321><end_up.endkunden><en> Needs are increasing The need for faster data transmission to network operators’ end customers is growing.
<G-vec00309-003-s321><end_up.endkunden><de> Der Bedarf an schneller Datenübertragung zu den Endkunden der Netzbetreiber wächst.
<G-vec00309-003-s322><end_up.endkunden><en> The ISO standard 9241-307 defines quality classes in this respect and thus ensures transparency with regard to the warranty and guarantee claims of end customers, dealers and wholesalers against manufacturers.
<G-vec00309-003-s322><end_up.endkunden><de> Die ISO-Norm 9241-307 legt diesbezüglich Qualitätsklassen fest und sorgt damit für Transparenz in Bezug auf Gewährleistungs- und Garantieansprüche von Endkunden, Händlern und Großhändlern gegenüber den Herstellern.
<G-vec00309-003-s494><end_up.landen><en> The pharmaceuticals we flush down the toilet end up in rivers and eventually into the oceans.
<G-vec00309-003-s494><end_up.landen><de> Die Arzneimittel, die wir in der Toilette hinunterspülen, landen in Flüssen und schließlich im Meer.
<G-vec00309-003-s495><end_up.landen><en> Second, we explain why certain groups of entrants and young employees might be more likely to end up in precarious jobs than others.
<G-vec00309-003-s495><end_up.landen><de> Dann wird gezeigt, warum einige Gruppen von Berufsanfängern und jungen Beschäftigten mit größerer Wahrscheinlichkeit in prekären Jobs landen als andere.
<G-vec00309-003-s496><end_up.landen><en> The nutrients stored in the plant are not really lost, but end up in biowaste, liquid manure and fermentation residues as well as in wastewater via the food chain.
<G-vec00309-003-s496><end_up.landen><de> Dabei gehen die in der Pflanze gespeicherten Nährstoffe nicht wirklich verloren, sondern landen über die Nahrungskette in Bioabfällen, Gülle und Gärresten sowie im Abwasser.
<G-vec00309-003-s497><end_up.landen><en> Many of them end up in prostitution and, according to human rights organizations, exploited under unimaginable conditions.
<G-vec00309-003-s497><end_up.landen><de> Viele von ihnen landen in der Prostitution und werden nach Aussagen von Menschenrechtsorganisationen unter unvorstellbaren Bedingungen ausgebeutet.
<G-vec00309-003-s498><end_up.landen><en> So a number of individuals win but lots of them end up on the losing side.
<G-vec00309-003-s498><end_up.landen><de> Daher ist eine Anzahl von Spielern zu gewinnen, aber viele von ihnen landen auf der Seite der Verlierer.
<G-vec00309-003-s499><end_up.landen><en> (My boss is on vacation, which means the strangest things happen at work right now and all of them end up on my desk *roles eyes*)
<G-vec00309-003-s499><end_up.landen><de> (Mein Chef ist gerade in Urlaub, da passieren grundsätzlich immer die wunderlichsten Dinge und alle landen sie bei mir *augenroll*)...
<G-vec00309-003-s500><end_up.landen><en> The Clark International Airport, which is located approximately 75 km further to the north, is mainly used to start and end domestic flights of low-cost airlines.
<G-vec00309-003-s500><end_up.landen><de> Am etwa 75 km weiter nördlich gelegenen Clark International Airport starten und landen hauptsächlich Inlandsflüge der Billigfluggesellschaften.
<G-vec00309-003-s501><end_up.landen><en> Please also check your spam folder, because unfortunately often answers from us end up there. Contact Form
<G-vec00309-003-s501><end_up.landen><de> Bitte kontrollieren Sie auch Ihren Spam Ordner da leider oft Antworten von uns dort landen.
<G-vec00309-003-s502><end_up.landen><en> Whether it is a VW Golf or Mazda MX5, they all have one thing in common; sooner or later they end up at the scrap yard.
<G-vec00309-003-s502><end_up.landen><de> Von VW Golf bis Mazda MX5, eines haben sie alle gemeinsam – früher oder später landen sie am Schrottplatz.
<G-vec00309-003-s503><end_up.landen><en> Since outdoor products are made for a very long service life, jackets with a PTFE membrane often do not end up with normal household waste.
<G-vec00309-003-s503><end_up.landen><de> Da Outdoor-Produkte ja für eine sehr lange Nutzungsdauer gemacht sind, landen Jacken mit PTFE-Membran häufig gar nicht im Restmüll.
<G-vec00309-003-s504><end_up.landen><en> The hope is that this trend will continue gathering momentum and that fewer valuable prototypes will end up plummeting into the Valley of Death.
<G-vec00309-003-s504><end_up.landen><de> Die Hoffnung ist groß, dass sich dieser Trend noch verstärkt und in Zukunft immer weniger der wertvollen Prototypen im Valley of Death landen.
<G-vec00309-003-s505><end_up.landen><en> Help to ensure that PET bottles no longer end up in the sea to save valuable raw materials.
<G-vec00309-003-s505><end_up.landen><de> Helfen Sie mit, dass PET-Flaschen nicht im Meer landen und damit wertvolle Rohstoffe eingespart werden können.
<G-vec00309-003-s506><end_up.landen><en> These particles accumulate in cleaning water, are emptied unfiltered into sink or toilette and end up in nature.
<G-vec00309-003-s506><end_up.landen><de> Diese Partikel sammeln sich beim Putzen im Schmutzwasser an, werden ungefiltert in Waschbecken oder Toiletten entleert und landen so in der Natur.
<G-vec00309-003-s507><end_up.landen><en> At the Bunker Trail and Etsch Trail, we will experience a lot of driving pleasure and end up at the end directly on the Reschensee, on the banks of which we comfortably reach the next ascent assistance, the Schönebenbahn.
<G-vec00309-003-s507><end_up.landen><de> Am Bunker Trail und Etsch Trail erfahren wir im Anschluss jede Menge Fahrspaß und landen am Ende direkt am Reschensee, an dessen Ufer wir gemütlich zur nächsten Aufstiegshilfe, der Schönebenbahn, gelangen.
<G-vec00309-003-s508><end_up.landen><en> When drug metabolites are in the blood, they'll end up in the blood vessels, including those in the head.
<G-vec00309-003-s508><end_up.landen><de> Die vom Körper verstoffwechselten Drogen werden in den Blutgefäßen und demnach auch auf dem Kopf landen.
<G-vec00309-003-s509><end_up.landen><en> We end up at the hotel Central, eat wild bear and will certainly soon be in our beds.
<G-vec00309-003-s509><end_up.landen><de> Wir landen im Hotel Central, gehen noch mal Wildschwein speisen und dann bestimmt bald ins Bett.
<G-vec00309-003-s510><end_up.landen><en> In cushions you end up a bit far behind and the sheath wants the nasal sling to swing short turns by itself, so it tends to almost shovel the snow in front of you if you take out the turns, almost flooding.
<G-vec00309-003-s510><end_up.landen><de> In Kissen landen Sie ein bisschen weit hinten und die Scheide möchte, dass die Nasalschlinge kurze Schwünge von selbst schwingt, so dass sie den Schnee fast vor sich hin schaufeln wird, wenn Sie die Wendungen herausnehmen, fast überschwemmen.
<G-vec00309-003-s511><end_up.landen><en> Many such particles, known as microplastics, end up in aquatic systems and eventually in the oceans.
<G-vec00309-003-s511><end_up.landen><de> Viele solcher als Mikroplastik bezeichneten Teilchen landen in aquatischen Systemen und schließlich in den Ozeanen.
<G-vec00309-003-s512><end_up.landen><en> Win-Win In a Win-Win scenario, both parties end up, at minimum, within their target ranges.
<G-vec00309-003-s512><end_up.landen><de> Win-Win In einem Win-Win-Szenario landen beide Parteien mindestens innerhalb ihrer Zielbereiche.
