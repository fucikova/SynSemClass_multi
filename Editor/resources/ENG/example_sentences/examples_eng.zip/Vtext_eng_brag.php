<G-vec00418-001-s004><brag.angeben><en> It's not because they want to brag. It's because they want to connect deeply with you, by sharing their process and journey openly.
<G-vec00418-001-s004><brag.angeben><de> Nicht weil sie angeben wollen, sondern weil sie eine tiefe Verbindung herstellen wollen, indem sie ihren Prozess und ihren Weg offen mit Ihnen teilen.
<G-vec00418-001-s005><brag.angeben><en> They can brag, bluff and embarrass.
<G-vec00418-001-s005><brag.angeben><de> Sie können angeben, bluffen und den Kunden bloßstellen.
<G-vec00418-001-s010><brag.sich_brüsten><en> We know our stuff Okay, so now is the one time weÂ ́ll brag.
<G-vec00418-001-s010><brag.sich_brüsten><de> Wir kennen unser Metier Okay, also hier das einzige Mal wo wir uns brüsten.
<G-vec00418-001-s012><brag.angeben><en> Few hotels in Dubai can brag they have the Burj Al Arab in their backyard.
<G-vec00418-001-s012><brag.angeben><de> Nur wenige Hotels in Dubai können damit angeben, das Burj Al Arab im Hinterhof zu haben.
<G-vec00418-001-s013><brag.angeben><en> He said it was absurd to brag about being a great yogi practitioner of a certain Buddha-figure when all one is doing or has done is its short retreat by reciting the relevant mantras a couple hundred thousand times.
<G-vec00418-001-s013><brag.angeben><de> Er sagte, dass es absurd sei, damit anzugeben, ein großer Yogi-Praktizierender einer bestimmten Buddha-Gestalt zu sein, wenn alles, was man tut oder getan hat, lediglich ein kurzes Retreat dazu mit ein paar hunderttausend Rezitationen der relevanten Mantras ist.
<G-vec00418-001-s014><brag.prahlen><en> However not all flower growers can brag of it.
<G-vec00418-001-s014><brag.prahlen><de> Jedoch können nicht alle Blumenzüchter damit prahlen.
<G-vec00418-001-s015><brag.prahlen><en> If you never did petards, ask the help and council for the skilled person who can brag of that never wounded itself.
<G-vec00418-001-s015><brag.prahlen><de> Wenn Sie die Pulverpetarden niemals machten, so bitten Sie der Hilfe und des Rates beim erfahrenen Menschen, der damit prahlen kann, was sich Mal verwundete.
<G-vec00418-001-s017><brag.prahlen><en> Despite that good example, Aldi, Lidl, Rewe and Edeka did not travel to Davos to brag.
<G-vec00418-001-s017><brag.prahlen><de> Aldi, Lidl, Rewe und Edeka fuhren nicht nach Davos, um dort zu prahlen.
<G-vec00418-001-s020><brag.prahlen><en> When it happens to them, they like to brag to other people.
<G-vec00418-001-s020><brag.prahlen><de> Wenn diesen passiert, möchten Sie gegenüber anderen Leuten prahlen.
<G-vec00418-001-s022><brag.prahlen><en> "On second thought I DO like to brag, 'Cause I'm mighty proud of that Ragged Old Flag."""
<G-vec00418-001-s022><brag.prahlen><de> Und nun möchte ich doch mit ihr prahlen, denn ich bin mächtig stolz auf diese alte lumpige Fahne.
<G-vec00418-001-s026><brag.prahlen><en> At the moment the burmese cat cannot brag of a variety of colors.
<G-vec00418-001-s026><brag.prahlen><de> Zur Zeit kann die birmanische Katze mit der Vielfältigkeit okrassow nicht prahlen.
<G-vec00418-001-s027><brag.prahlen><en> Perhaps, shortly the star will brag of the purchase and will share a picture of the new iron friend.
<G-vec00418-001-s027><brag.prahlen><de> Möglich, bald wird der Stern mit dem Kauf prahlen und wird von der Aufnahme des neuen eisernen Freundes mitteilen.
<G-vec00418-001-s028><brag.prahlen><en> Elastic skin – it is simple and available In youth it is very easy to brag of beautiful and elastic skin, but, alas, normal processes of aging can fine spoil its appearance...
<G-vec00418-001-s028><brag.prahlen><de> Die elastische Haut – einfach ist es eben zugänglich In der Jugend ist es sehr leicht, mit der schönen und elastischen Haut zu prahlen, aber leider können die normalen Prozesse des Alterns ihr Aussehen prima beschädigen...
<G-vec00418-001-s029><brag.prahlen><en> For this reason the orchid kattleya can brag of various form and size of flowers.
<G-vec00418-001-s029><brag.prahlen><de> Gerade deshalb kann die Orchidee kattleja mit verschiedener Form und der Größe der Farben prahlen.
<G-vec00418-001-s030><brag.prahlen><en> Having behind shoulders three official marriages and a little civil, the former actress of movies for adults cannot brag of a personal example of the long harmonious union.
<G-vec00418-001-s030><brag.prahlen><de> Hinter den Schultern drei offizieller Ehen und etwas bürgerlich habend, kann die ehemalige Schauspielerin der Filme für die Erwachsenen mit dem persönlichen Beispiel des langen harmonischen Bündnisses nicht prahlen.
<G-vec00418-001-s031><brag.prahlen><en> The Crimea can brag and the fresh-water reservoirs rich with fish for every taste.
<G-vec00418-001-s031><brag.prahlen><de> Krim kann und presnowodnymi mit den Wasserbecken, die mit dem Fisch auf einen beliebigen Geschmack reich sind prahlen.
<G-vec00418-001-s032><brag.prahlen><en> And even if you can brag of a good harvest of healthy vegetables, it not a guarantee of their long storage yet.
<G-vec00418-001-s032><brag.prahlen><de> Und selbst wenn Sie mit der guten Ernte des gesunden Gemüses, es noch nicht die Garantie ihrer langwierigen Aufbewahrung prahlen können.
<G-vec00418-001-s033><brag.prahlen><en> Galbren wanted them to know of Sarmeen's fate - maybe to brag about his mercilessness and unscrupulousness, maybe to induce fear in them, food for the Demons.
<G-vec00418-001-s033><brag.prahlen><de> Galbren hatte gewollt, daß sie von Sarmeens Schicksal wußten - vielleicht, um mit seiner eigene Unerbittlichkeit und Skrupellosigkeit zu prahlen, vielleicht, um ihnen Furcht einzuflößen, als Futter für die Dämonen.
<G-vec00418-001-s034><brag.prahlen><en> Nokia 6700 slide works under control of Symbian OS 9.3, can brag of a 5-megapixel chamber with Carl Zeiss optics, an auto focus and double LED flash.
<G-vec00418-001-s034><brag.prahlen><de> Nokia 6700 slide arbeitet unter der Leitung von Symbian OS 9.3, kann 5-megapikselnoj mit der Kamera mit der Optik Carl Zeiss, dem Autobrennpunkt und dem doppelten LED-Ausbruch prahlen.
<G-vec00418-001-s035><brag.prahlen><en> Even if your organization cannot brag of the dimensions, it does not mean that at work it is possible to look carelessly.
<G-vec00418-001-s035><brag.prahlen><de> Selbst wenn Ihre Organisation mit den Abmessungen nicht prahlen kann, so bedeutet es nicht, dass man auf der Arbeit schlampig aussehen kann.
<G-vec00418-001-s036><brag.prahlen><en> In July zhenshchiny-Ryby can brag of career achievements and new perspective projects.
<G-vec00418-001-s036><brag.prahlen><de> Im Juli der Frau-Fisches können mit den Berufserrungenschaften und den neuen perspektivischen Projekten prahlen.
<G-vec00418-001-s037><brag.prahlen><en> Actually, Tony Todd can brag of very successful career in Hollywood.
<G-vec00418-001-s037><brag.prahlen><de> In Wirklichkeit, Tony Todd kann mit der sehr erfolgreichen Karriere in Hollywood prahlen.
<G-vec00418-001-s038><brag.prahlen><en> This orchid kattleya can brag of more various coloring of the flowers.
<G-vec00418-001-s038><brag.prahlen><de> Diese Orchidee kattleja kann mit der vielfältigeren Färbung der Farben prahlen.
<G-vec00418-001-s039><brag.prahlen><en> Despite the years, Carmen Electra can still brag of a fine figure.
<G-vec00418-001-s039><brag.prahlen><de> Ungeachtet der Jahre, Carmen Elektra kann mit der schönen Figur bis jetzt prahlen.
<G-vec00418-001-s040><brag.prahlen><en> The Filzip archiver can brag of all same main functions, as other free programs archivers.
<G-vec00418-001-s040><brag.prahlen><de> Das Komprimierungsprogramm Filzip kann mit allen selben Hauptfunktionen, dass auch andere kostenlose Programme die Komprimierungsprogramme prahlen.
<G-vec00418-001-s041><brag.prahlen><en> Each ethnic cuisine can brag of the original sauces: in India love chatn, in Japan — unag, in Azerbaijan — narsharab.
<G-vec00418-001-s041><brag.prahlen><de> Jede nationale Küche kann mit den originellen Soßen prahlen: in Indien mögen tschatni, in Japan — unagi, in Aserbaidschan — narscharab.
<G-vec00418-001-s042><brag.prahlen><en> She is multitask, can brag of convenient synchronization.
<G-vec00418-001-s042><brag.prahlen><de> Sie kann mnogosadatschna, mit der bequemen Synchronisation prahlen.
<G-vec00418-001-s043><brag.nehmen><en> The conditions are, we have to brag, dreamy.
<G-vec00418-001-s043><brag.nehmen><de> Die Bedingungen sind, man darf es in den Mund nehmen, traumhaft.
<G-vec00418-001-s044><brag.prahlen><en> Many fans of cats prefer to bring British: graceful and beautiful animals who can brag of wonderful colors: chocolate, blue, marble, black, white, tortoise, cream...
<G-vec00418-001-s044><brag.prahlen><de> Viele Liebhaber der Katzen bevorzugen, die Briten zu führen: der graziösen und schönen Tiere, die wunderbar okrassami prahlen können: schokoladen-, blau, marmor-, schwarz, weiß, schildplatt-, cremefarben...
<G-vec00418-001-s045><brag.prahlen><en> The British lilac Many fans of cats prefer to bring British: graceful and beautiful animals who can brag of wonderful colors: shock...
<G-vec00418-001-s045><brag.prahlen><de> Die britische Lila Viele Liebhaber der Katzen bevorzugen, die Briten zu führen: der graziösen und schönen Tiere, die wunderbar okrassami prahlen können: der Schock...
<G-vec00418-001-s046><brag.prahlen><en> Remember to compare, not threaten or brag that you've got better opportunities elsewhere. Things You'll Need
<G-vec00418-001-s046><brag.prahlen><de> Vergiss nicht, zu vergleichen, aber drohe oder prahle nicht damit, dass du woanders bessere Möglichkeiten hast.
<G-vec00418-001-s047><brag.prahlen><en> But Mozilla Firefox users, no need to wave your arms like a student trying to get a teacher’s attention according to a new browser security study from Accuvant, you don’t have much to brag about at all.
<G-vec00418-001-s047><brag.prahlen><de> Aber Mozilla Firefox-Nutzer, keine Notwendigkeit, Ihre Arme wie ein Schüler versuchen, winken ein teacherâ € ™ s Aufmerksamkeit Â-nach einem neuen Browser-Sicherheit Studie von Accuvant, Sie dona € ™ t haben viel darüber überhaupt prahlen.
<G-vec00418-001-s048><brag.prahlen><en> I know this doesn’t mean I’m strong or say anything about the person I am, and I’m not telling you these things to brag or because I hope you’ll be impressed.
<G-vec00418-001-s048><brag.prahlen><de> Ich weiß, dass dies nicht bedeutet, ich bin stark oder sagen etwas über die Person, die ich bin, und ich sage Ihnen nicht, diese Dinge zu prahlen oder weil ich hoffe, werden Sie begeistert sein.
<G-vec00418-001-s049><brag.prahlen><en> I don’t say this to brag, but because if you asked me I would tell you that I am very shy and insecure and overcome it by pure force of will.
<G-vec00418-001-s049><brag.prahlen><de> Ich sage nicht, dies zu prahlen, sondern weil, wenn Sie mich gefragt, ich möchte Ihnen sagen, dass ich bin sehr schüchtern und unsicher und Überwindung durch reine Kraft des Willens.
<G-vec00418-001-s050><brag.prahlen><en> I'd encourage you to read those parts of Scripture where people brag about God. Isaiah 40.
<G-vec00418-001-s050><brag.prahlen><de> Ich würde empfehlen Ihnen, die Teile der Bibel zu lesen, wo die Menschen prahlen über Gott.
<G-vec00418-001-s051><brag.prahlen><en> "This product brag ""with up to 8 POUNDS IN a month, MINUS WORKS fast, PROVEN EFFECTS, powerful FAT BURNER, ACTUALLY REDUCES appetite, without DRASTIC DIETS."
<G-vec00418-001-s051><brag.prahlen><de> "Dieses Produkt prahlen ""mit bis zu 8 Pfund IN einem Monat, abzüglich arbeitet schnell, nachgewiesene Effekte, leistungsstarke Fatburner tatsächlich reduziert den Appetit, ohne DRASTISCHE Diäten."
<G-vec00418-001-s052><brag.prahlen><en> "Currently, we rely mainly on the (relatively) new modifications, which develop very quickly and their creators like to ""brag"" news."
<G-vec00418-001-s052><brag.prahlen><de> "Derzeit setzen wir vor allem auf die (relativ) neue Modifikationen, die sehr schnell zu entwickeln und ihre Schöpfer, wie zu ""prahlen"" news."
<G-vec00418-001-s053><brag.prahlen><en> This car can brag and very capacious luggage carrier.
<G-vec00418-001-s053><brag.prahlen><de> Dieses Auto kann und dem sehr umfangreichen Gepäckraum prahlen.
<G-vec00418-001-s054><brag.prahlen><en> Businesses like to brag in their advertising about quality of work, commitment to their customers, and excellent service.
<G-vec00418-001-s054><brag.prahlen><de> Unternehmen wie prahlen in ihrer Werbung die Qualität der Arbeit, Engagement für ihre Kunden, und ein ausgezeichneter Service.
<G-vec00418-001-s055><brag.prahlen><en> It befits beggars to brag about sores and show off their deformities, not warriors and philosophers.
<G-vec00418-001-s055><brag.prahlen><de> Es steht Bettlern an, über Wunden zu prahlen und Entstellungen zu zeigen, nicht Kriegern und Philosophen.
<G-vec00418-001-s056><brag.prahlen><en> "I do it not for this purpose, God forbid, to brag to readers praises with which great Sholem Aleichem presented me, - to the fact that he even subscribed with admiration: ""Your reader, your pupil, your friend""."
<G-vec00418-001-s056><brag.prahlen><de> Ich es mache nicht dazu, nicht, Gott geb', dass vor den Lesern vom Lob, die mich großen Scholom-Alejchem beschenkt hat, - bevor zu prahlen, dass er mit dem Entzücken sogar abonniert hat: «Ihr Leser, Ihr Schüler, Ihr Freund».
<G-vec00418-001-s057><brag.prahlen><en> Pointing to a positive experience, not zagovarivaytes not brag.
<G-vec00418-001-s057><brag.prahlen><de> Unter Hinweis auf eine positive Erfahrung, nicht zagovarivaytes nicht prahlen.
<G-vec00418-001-s058><brag.prahlen><en> We do not brag.
<G-vec00418-001-s058><brag.prahlen><de> Wir prahlen nicht.
<G-vec00418-001-s059><brag.prahlen><en> And it succeeds admirably . And we brag about it.
<G-vec00418-001-s059><brag.prahlen><de> Es gelingt vortrefflich, und wir prahlen darüber.
<G-vec00418-001-s060><brag.prahlen><en> The New Year's horoscope advises these true judges of all fine not to assume too highly airs and not to brag of the knowledge of all areas.
<G-vec00418-001-s060><brag.prahlen><de> Berät das Neujahrshoroskop diesen wahrhaften Kennern des ganzen Schönen, nicht hochzuheben es ist die Nase viel zu hoch, von den Erkenntnissen auf allen Gebieten nicht zu prahlen.
<G-vec00418-001-s061><brag.prahlen><en> I’d encourage you to read those parts of Scripture where people brag about God.
<G-vec00418-001-s061><brag.prahlen><de> Ich würde empfehlen Ihnen, die Teile der Bibel zu lesen, wo die Menschen prahlen über Gott.
<G-vec00418-001-s062><brag.prahlen><en> Envision how it would be to brag about your new adore instrument to your companion considering that in the past, you truly shed sleep attempting to find ways to give your intercourse daily life a increase.
<G-vec00418-001-s062><brag.prahlen><de> Vorstellen, wie es wäre, zu Ihrem neuen adore Instrument, um Ihr Begleiter man bedenkt, dass in der Vergangenheit, die Sie wirklich Schuppen schlafen versucht, Möglichkeiten, um Ihre Verkehr Alltag eine Zunahme zu geben finden prahlen.
<G-vec00418-001-s063><brag.prahlen><en> We like to brag we have the best location in Cape Coral.
<G-vec00418-001-s063><brag.prahlen><de> Wir gerne prahlen, wir haben die beste Lage in Cape Coral.
<G-vec00418-001-s064><brag.prahlen><en> Not only do I think you should brag sometimes, I think it's what you were created to do.
<G-vec00418-001-s064><brag.prahlen><de> Nicht nur, dass ich glaube, Sie sollten manchmal prahlen, Ich denke, es ist das, was Sie erstellt wurden, zu tun.
<G-vec00418-001-s065><brag.prahlen><en> The Wallaces brag about the horrible act among their friends, but are not arrested.
<G-vec00418-001-s065><brag.prahlen><de> Die Wallaces prahlen um die schreckliche Tat unter ihren Freunden, aber werden nicht verhaftet.
<G-vec00418-001-s066><brag.prahlen><en> They brag about it, they are proud.
<G-vec00418-001-s066><brag.prahlen><de> Sie prahlen damit und sind stolz.
<G-vec00418-001-s067><brag.prahlen><en> We get tired of hearing grown men brag about their high school football days (it's time to move on, sir).
<G-vec00418-001-s067><brag.prahlen><de> Wir werden müde des Hörens erwachsene Männer prahlen über ihre High-School-Fußball-Tage (es ist Zeit weiterzugehen, Herr).
<G-vec00418-001-s068><brag.prahlen><en> But the trait that we tend to brag about the most is actually our dog's...
<G-vec00418-001-s068><brag.prahlen><de> Aber das Merkmal, dass wir dazu neigen, prahlen über die tatsächlich unsere int...
<G-vec00418-001-s069><brag.prahlen><en> Children, playing with their peers, communicating in school or kindergarten, brag to each other who did what game, and who achieved what in the computer world.
<G-vec00418-001-s069><brag.prahlen><de> Kinder, die mit Gleichaltrigen spielen, in der Schule oder im Kindergarten kommunizieren, prahlen mit einander, wer was gemacht hat und wer was in der Computerwelt erreicht hat.
<G-vec00418-001-s070><brag.prahlen><en> Many women like to brag about their own hands -the way they are beautiful, well-groomed, pleasant to look at and touch... but not everyone is happy with the nails donated by nature.
<G-vec00418-001-s070><brag.prahlen><de> Viele Frauen prahlen gerne mit ihren eigenen Händen -wie sie schön sind, gepflegt, angenehm anzusehen und anzufassen... aber nicht jeder ist glücklich mit den von der Natur gespendeten Nägeln.
<G-vec00418-001-s071><brag.prahlen><en> People brag about having thousands of 'links' on LinkedIn.com.
<G-vec00418-001-s071><brag.prahlen><de> Leute prahlen mit Haben von von Tausenden ' Verbindungen auf LinkedIn.com.
<G-vec00418-001-s072><brag.prahlen><en> Brag of the car, tell about achievements at work – girls love stories of successful and attractive men.
<G-vec00418-001-s072><brag.prahlen><de> Prahlen Sie mit dem Auto, erzählen Sie von den Errungenschaften auf der Arbeit – die Mädchen mögen die Geschichten der erfolgreichen und attraktiven Männer.
<G-vec00418-001-s073><brag.prahlen><en> The feminized Girl Scout Cookies by Cali Connection is what the West Coast rappers talk and brag about and the whole stoner community is eager to empathize what these fortune cookies are all about, making this Thin Mint phenotype one of the most sought after varieties today.
<G-vec00418-001-s073><brag.prahlen><de> Die feminisierte Girl Scout Cookies von Cali Connection ist, worüber die West Coast Rapper sprechen und prahlen und die ganze Kiffer Gemeinde ist bestrebt, nachzufühlen, was es mit diesen Glückskeksen auf sich hat, was diesen Thin Mint Phänotyp zu einem der derzeit meist gesuchten Sorten macht.
<G-vec00418-001-s074><brag.prahlen><en> Chinese hospitals brag about their organ transplant accomplishments on the websites.
<G-vec00418-001-s074><brag.prahlen><de> Chinesische Krankenhäuser prahlen mit ihren Organtransplantatleistungen auf den Webseiten.
<G-vec00418-001-s075><brag.prahlen><en> She was very modest and did not brag about the influence she might have had.
<G-vec00418-001-s075><brag.prahlen><de> Sie war sehr bescheiden und prahlte nicht mit dem Einfluss, den sie gehabt haben mochte.
<G-vec00418-001-s078><brag.angeben><en> If in your bundle is a solution, acid, lye or the similar, you can brag in these fields which concentration the solution has and what is the solvent.
<G-vec00418-001-s078><brag.angeben><de> Wenn sich in Ihren Gebinde eine Lösung, Säure, Lauge oder ähnliches befindet, so können Sie in diesen Feldern angeben welche Konzentration die Lösung hat und was das Lösungsmittel ist.
<G-vec00418-001-s081><brag.prahlen><en> The main cola of Cookies Autoflowering is something every grower would be proud to brag about.
<G-vec00418-001-s081><brag.prahlen><de> Die Haupt-Cola von Cookies Autoflowering ist etwas, womit jeder Grower stolz prahlen würde.
