<G-vec00078-001-s038><clear.deaktivieren><en> We have improved quality control processes of clear stamps for scrapbooking to ensure each export qualified product.
<G-vec00078-001-s038><clear.deaktivieren><de> Wir haben von Deaktivieren Sie Briefmarken für scrapbooking verbesserte Qualitätskontrolle, jede Export qualifiziertes Produkt zu gewährleisten.
<G-vec00078-001-s039><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body can clear more fat.
<G-vec00078-001-s039><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr um sicherzustellen, dass Ihre physischen Körper viel mehr Fettgewebe deaktivieren kann.
<G-vec00078-001-s040><clear.deaktivieren><en> Select or clear the Use international settings check box.
<G-vec00078-001-s040><clear.deaktivieren><de> Aktivieren oder deaktivieren Sie das Kontrollkästchen Internationale Einstellungen verwenden.
<G-vec00078-001-s041><clear.deaktivieren><en> Then clear the wall brush and moistened with water.
<G-vec00078-001-s041><clear.deaktivieren><de> Deaktivieren Sie dann die Wand Pinsel und mit Wasser angefeuchtet.
<G-vec00078-001-s042><clear.deaktivieren><en> Clear Automatic date & time and Automatic time zone, and then set the time zone, date, and time as required.
<G-vec00078-001-s042><clear.deaktivieren><de> Deaktivieren Sie die Optionen Automatisch Datum & Uhrzeit und Automatische Zeitzone und stellen Sie anschließend die Zeitzone, das Datum und die Uhrzeit ein.
<G-vec00078-001-s043><clear.deaktivieren><en> On the Enable this Resource Partner page, if you do not want to enable the resource partner now, clear the Enable this resource partner check box, and then click Next.
<G-vec00078-001-s043><clear.deaktivieren><de> Wenn Sie den Ressourcenpartner zu diesem Zeitpunkt nicht aktivieren möchten, deaktivieren Sie auf der Seite Ressourcenpartner aktivieren das Kontrollkästchen Ressourcenpartner aktivieren, und klicken Sie auf Weiter.
<G-vec00078-001-s044><clear.deaktivieren><en> Bobble Shooter - Clear all the bubbles from the board .
<G-vec00078-001-s044><clear.deaktivieren><de> Bobble Shooter - Deaktivieren Sie alle Blasen vom Spielfeld.
<G-vec00078-001-s046><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This active ingredient really helps up your metabolic price so that your body could clear much more fat deposits.
<G-vec00078-001-s046><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: dieser Stoff hilft Ihre metabolische Preis um sicherzustellen, dass Ihre physischen Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00078-001-s047><clear.deaktivieren><en> Clear this option to prohibit Web service extensions from running on your Web server.
<G-vec00078-001-s047><clear.deaktivieren><de> Deaktivieren Sie diese Option, um das Ausführen der Webdiensterweiterungen auf dem Server nicht zuzulassen.
<G-vec00078-001-s048><clear.deaktivieren><en> order to detect subtle, keep clear the brain, read the thoughts of those who are thinking of you, very helpful and good help breathing exercises that produce different nostrils, it can be done sitting or standing in front of the open window, in a wellventilated room.
<G-vec00078-001-s048><clear.deaktivieren><de> um zu erkennen, subtil, zu halten deaktivieren Sie das Gehirn, lesen Sie die Gedanken derer, die daran denken, Sie, sehr hilfsbereit und gute Hilfe Atemübungen, die verschiedenen Nasenlöcher zu erzeugen, kann es getan sitzen oder stehen vor dem offenen Fenster, in einem gut werdenbelüfteten Raum.
<G-vec00078-001-s049><clear.deaktivieren><en> Clear the apples from seeds and rind, cut into strips.
<G-vec00078-001-s049><clear.deaktivieren><de> Deaktivieren Sie die Äpfel aus Samen und Rinde, in Streifen geschnitten.
<G-vec00078-001-s050><clear.deaktivieren><en> Clear all options.
<G-vec00078-001-s050><clear.deaktivieren><de> Deaktivieren Sie alle Optionen.
<G-vec00078-001-s051><clear.deaktivieren><en> To enable or prevent wireless networks from displaying in the Connect to a network dialog box, either select or clear Allow user to view denied networks.
<G-vec00078-001-s051><clear.deaktivieren><de> Aktivieren oder deaktivieren Sie Anzeigen von abgelehnten Netzwerken für Benutzer zulassen, um zu ermöglichen oder zu verhindern, dass Drahtlosnetzwerke im Dialogfeld Verbindung mit einem Netzwerk herstellen angezeigt werden.
<G-vec00078-001-s052><clear.deaktivieren><en> When the lake level rises another 2 or 3 feet, sunlight won’t reach the roots of plants and they will die and clear out the surface.
<G-vec00078-001-s052><clear.deaktivieren><de> Wenn der See steigt ein anderer 2 oder 3 Füße, Sonnenlicht wird nicht an die Wurzeln der Pflanzen, und sie werden sterben, und deaktivieren Sie die Oberfläche.
<G-vec00078-001-s053><clear.deaktivieren><en> If you’ve ever needed to force stop, or clear the data/cache from an app, this is a welcome addition as it makes finding this page much, much easier.
<G-vec00078-001-s053><clear.deaktivieren><de> Wenn Sie jemals benötigt wird, um Gewalt zu stoppen, oder deaktivieren Sie die Daten / Cache aus einer App, Dies ist eine willkommene Ergänzung, da es viel zu finden Diese Seite macht, viel einfacher.
<G-vec00078-001-s054><clear.deaktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00078-001-s054><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00078-001-s055><clear.deaktivieren><en> 1,3-Dimethypentylamine Hydrochloride: This ingredient helps up your metabolic fee so that your physical body could clear much more fat deposits.
<G-vec00078-001-s055><clear.deaktivieren><de> 1,3-Dimethypentylamine-Hydrochlorid: Diese Komponente hilft Ihre metabolische Gebühr, damit Ihr Körper viel mehr Fettdepots deaktivieren kann.
<G-vec00078-001-s056><clear.deaktivieren><en> To stop filtering altogether, in the key table, clear the check box next to Image.
<G-vec00078-001-s056><clear.deaktivieren><de> Deaktivieren Sie in der Schlüsseltabelle das Kontrollkästchen neben Abbild, um die gesamte Filterung zu beenden.
<G-vec00078-001-s418><clear.klären><en> So we have to clear it.
<G-vec00078-001-s418><clear.klären><de> Das müssen wir klären.
<G-vec00078-001-s419><clear.klären><en> If you find mold, do not attempt to clear it up yourself, as you will probably just spread it around .
<G-vec00078-001-s419><clear.klären><de> Wenn Sie Schimmel zu finden, Versuchen Sie nicht, es zu klären, sich selbst, wie Sie wahrscheinlich nur breitete es rund.
<G-vec00078-001-s420><clear.klären><en> Before one starts to design a model, it should be clear which information one needs to construct the model and which information is available.
<G-vec00078-001-s420><clear.klären><de> Bevor ein Modell für ein System entworfen wird, ist zu klären, welche Information man für die Modellierung benötigt und welche Information über das System zur Verfügung steht.
<G-vec00078-001-s421><clear.klären><en> Therefore, in order to make the terms and conditions clear, please contact us directly. Â
<G-vec00078-001-s421><clear.klären><de> Setzen Sie sich daher bitte mit uns direkt in Verbindung, um die jeweiligen Bedingungen und Konditionen zu klären.
<G-vec00078-001-s422><clear.klären><en> In traditional Chinese medicine, the leaves are considered to be of sweet, bitter and cold properties, which are associated with the liver and lung meridians, and functions to clear lung heat (to manifest as a fever, headache, sore throat or cough) and clear fire in the liver.
<G-vec00078-001-s422><clear.klären><de> In der traditionellen chinesischen Medizin haben die Blätter süße, bittere und kalte Eigenschaften, die mit den Leber- und Lungenmeridianen assoziiert sind, und sie klären die Lungenwärme (manifestieren sich als Fieber, Kopfschmerzen, Halsschmerzen oder Husten) und klares Feuer in der Leber.
<G-vec00078-001-s423><clear.klären><en> Your destiny is to ascend and many of you have already risen to a point where you have little or no karma to clear.
<G-vec00078-001-s423><clear.klären><de> Eure Zielbestimmung ist, aufzusteigen, und Viele unter euch haben sich bereits bis zu einem Punkt weiter aufwärtsentwickelt, an dem sie kaum noch oder gar kein Karma mehr zu klären haben.
<G-vec00078-001-s424><clear.klären><en> The Ace of Swords means that we have the chance now to clear things which had been unclear or incomprehensible.
<G-vec00078-001-s424><clear.klären><de> Das As der Schwerter bedeutet, dass sich uns die Chance bietet, Dinge zu klären, die uns bisher unklar oder unverständlich waren, Verwicklungen aufzulösen, Konflikte zu beheben.
<G-vec00078-001-s425><clear.klären><en> If ‘Da Greco’ doesn’t scream Italian, I’m sure the food at this restaurant will clear things up.
<G-vec00078-001-s425><clear.klären><de> "Wenn 'Da Greco ""schreit nicht italienisch, ich bin sicher, das Essen in diesem Restaurant werden die Dinge klären."
<G-vec00078-001-s426><clear.klären><en> "And ""Any auditing is better than no auditing"", because if you want to stop all auditing, then you don't clear."
<G-vec00078-001-s426><clear.klären><de> "Und ""Irgendein Auditing ist besser als gar kein Auditing"", denn wenn Sie das gesamte Auditing stoppen, klären Sie nicht."
<G-vec00078-001-s427><clear.klären><en> Worry not, reading this article can help clear some doubts.
<G-vec00078-001-s427><clear.klären><de> Sorge, diesen Artikel lesen helfen einige Zweifel klären kann.
<G-vec00078-001-s428><clear.klären><en> Specifically, time alone made it prohibitive to clear a population of billions by training enough Professional Auditors to deliver one-on-one auditing to every preclear on Earth.
<G-vec00078-001-s428><clear.klären><de> Insbesondere war der Faktor der Zeit sehr hinderlich dabei, eine Bevölkerung von Milliarden von Menschen zu klären, indem man genügend professionelle Auditoren ausbildet, um jedem Preclear auf der Welt auf individueller Basis Auditing zu geben.
<G-vec00078-001-s429><clear.klären><en> Your system is designed that way in order to clear the suppressed emotions.
<G-vec00078-001-s429><clear.klären><de> Euer System ist in einer Art entworfen, um unterdrückte Emotionen zu klären.
<G-vec00078-001-s430><clear.klären><en> """Oh, thats no problem"", I said, ""I meet him sometimes"", and I asked the man if a document would help to clear the circumstances."
<G-vec00078-001-s430><clear.klären><de> """Kein Problem"", sagte ich, ""den treffe ich ja gelegentlich"" und fragte noch, ob denn ein entsprechendes Schriftstück die Sachlage klären könnte."
<G-vec00078-001-s431><clear.klären><en> If we cannot provide the performance expected, we clear up the causes together and find possible solutions.
<G-vec00078-001-s431><clear.klären><de> Wenn wir die erwartete Leistung nicht erbringen können, klären wir gemeinsam Ursachen und finden Lösungsmöglichkeiten.
<G-vec00078-001-s432><clear.klären><en> Let us clear out first what the only method of the evolutionary process is.
<G-vec00078-001-s432><clear.klären><de> Klären wir zuerst was die einzige Methode des evolutionären Prozesses ist.
<G-vec00078-001-s433><clear.klären><en> Strive to clear your emotional body of pain.
<G-vec00078-001-s433><clear.klären><de> Strebt danach euren emotionalen Schmerzkörper zu klären.
<G-vec00078-001-s434><clear.klären><en> Before we ask ourselves whether God has accepted our penitence, we should get it clear what penitence actually is.
<G-vec00078-001-s434><clear.klären><de> Bevor wir uns fragen, ob Gott unsere Buße angenommen hat, sollten wir klären, was Buße eigentlich ist.
<G-vec00078-001-s435><clear.klären><en> We shouldn’t get stuck in our own concepts, but clear the hindrances of the concepts we have created.
<G-vec00078-001-s435><clear.klären><de> Wir sollten nicht in den eigenen Konzepten stecken bleiben, sondern die Hindernisse der Konzepte, die wir geschaffen haben, klären.
<G-vec00078-001-s436><clear.klären><en> So if you want to participate in the Master Cylinder, it is highly recommended that you try to clear out any areas within you or your life that are untrue BEFORE you come.
<G-vec00078-001-s436><clear.klären><de> Darum wird es in höchstem Maße empfohlen, dass du probierst, alle Bereiche in dir und deinem Leben zu klären, die unwahr sind, BEVOR du kommst.
<G-vec00078-001-s475><clear.löschen><en> The following VBA code can help you quickly clear contents of a textbox when double-clicking on it. Please do as follows.
<G-vec00078-001-s475><clear.löschen><de> Der folgende VBA-Code kann Ihnen helfen, Inhalte eines Textfelds schnell zu löschen, wenn Sie darauf doppelklicken.
<G-vec00078-001-s476><clear.löschen><en> A graceful restart can fail if the original Apache instance is not able to clear all necessary resources.
<G-vec00078-001-s476><clear.löschen><de> Ein ordnungsgemäßer Start kann fehlschlagen, wenn die originale Apache-Instanz nicht alle nötigen Ressourcen löschen kann.
<G-vec00078-001-s477><clear.löschen><en> Cheques take an average of three working days to clear.
<G-vec00078-001-s477><clear.löschen><de> Schecks einen Durchschnitt von drei Werktagen zu löschen.
<G-vec00078-001-s478><clear.löschen><en> All papers clear and you can begin construction immediately.
<G-vec00078-001-s478><clear.löschen><de> Alle Papiere zu löschen und Sie können Bau sofort beginnen.
<G-vec00078-001-s479><clear.löschen><en> iMyFone Umate Pro is handy in such a situation, as it helps to clear Facebook cache,delete WeChat account,clear cache on iPad&clear off all the temporary files freeing up sufficient storage space in the device.
<G-vec00078-001-s479><clear.löschen><de> iMyFone Animate Pro ist praktisch, in einer solchen Situation, wie es hilft, klar Facebook-Cache, löschen WeChat Konto, Löschen des Cache auf dem iPad & Löschen Sie alle temporären Dateien ausreichend Speicherplatz im Gerät der Freisetzung.
<G-vec00078-001-s481><clear.löschen><en> If you clear the cookies from your browser, you need to set the opt-out cookie once again.
<G-vec00078-001-s481><clear.löschen><de> Löschen Sie die Cookies in diesem Browser, müssen Sie das Opt-out-Cookie erneut setzen.
<G-vec00078-001-s482><clear.löschen><en> Coconut powder also can promote capillary blood circulation, anti-aging; to help clear the accumulation of oxygen free radicals.
<G-vec00078-001-s482><clear.löschen><de> Kokos Pulver kann auch Kapillare Durchblutung, Anti-Aging fördern; zu helfen, die Anhäufung von freien Sauerstoffradikalen zu löschen.
<G-vec00078-001-s483><clear.löschen><en> NOTE: If the changes are not applied, clear your browser cache and try again.
<G-vec00078-001-s483><clear.löschen><de> Hinweis: Wenn keine Änderungen erscheinen, löschen Sie bitte den Browserchache und versuchen Sie es erneut.
<G-vec00078-001-s484><clear.löschen><en> Lake Placid area offers 27 clear, freshwater lakes with some of the best fishing anywhere.
<G-vec00078-001-s484><clear.löschen><de> Lake Placid Bereich Angebote 27 Löschen, Süßwasserseen mit einigen der besten Fisch überall.
<G-vec00078-001-s485><clear.löschen><en> Blue, I, water, calm, meditative mood … and the result: clear, világos gondolatok.
<G-vec00078-001-s485><clear.löschen><de> Blau, I, Wasser, beruhigen, meditative Stimmung … und das Ergebnis: löschen, világos gondolatok.
<G-vec00078-001-s486><clear.löschen><en> Just like Mozilla Firefox, you have to follow some easy instructions to clear download history from your browser.
<G-vec00078-001-s486><clear.löschen><de> Genau wie Mozilla Firefox, müssen Sie einige einfache Anweisungen zu Download-Verlauf löschen aus Ihrem Browser folgen.
<G-vec00078-001-s487><clear.löschen><en> "Confirm your choice by clicking ""Clear all""."
<G-vec00078-001-s487><clear.löschen><de> "Bestätigen Sie Ihre Auswahl durch Klicken auf ""Alle löschen""."
<G-vec00078-001-s488><clear.löschen><en> You can also click Clear Bets to remove all bets from the Casino Hold 'Em table and start over.
<G-vec00078-001-s488><clear.löschen><de> Sie können auch auf „Einsätze löschen“ klicken, um alle Ihre Wetten auf dem Casino Hold'em Tisch zu löschen und um neu anzufangen.
<G-vec00078-001-s489><clear.löschen><en> Shoot back and clear the screen to get away from this crazy music.
<G-vec00078-001-s489><clear.löschen><de> Schieß zurück und löschen Sie den Bildschirm, um weg von diesem verrückten Musik.
<G-vec00078-001-s490><clear.löschen><en> The last used folder to import audio into an Alchemy Source is now remembered after the File > Clear command has been used.
<G-vec00078-001-s490><clear.löschen><de> "Der letzte verwendete Ordner zum Importieren von Audio in eine Alchemy-Quelle wird nun gespeichert, nachdem der Befehl ""Ablage"" > ""Löschen"" verwendet wurde."
<G-vec00078-001-s491><clear.löschen><en> You can click the brush icon to clear your chat history.
<G-vec00078-001-s491><clear.löschen><de> Sie können auch auf das Besen-Symbol klicken, um Ihren Chat-Verlauf zu löschen.
<G-vec00078-001-s492><clear.löschen><en> To clear browsing history on Safari, you can click the clear history on the history page or under the show all history view, you can right click on the individual links and click the delete option.
<G-vec00078-001-s492><clear.löschen><de> Um den Browserverlauf in Safari zu löschen, können Sie auf der Verlaufsseite auf Verlauf löschen klicken oder unter Gesamten Verlauf anzeigen mit der rechten Maustaste auf die einzelnen Links klicken und auf die Option zum Löschen klicken.
<G-vec00078-001-s513><clear.reinigen><en> We clear and cut onions, we fry till golden color on a frying pan.
<G-vec00078-001-s513><clear.reinigen><de> Wir reinigen und schneiden die Zwiebel, obschariwajem bis zur goldigen Farbe auf der Pfanne.
<G-vec00078-001-s514><clear.reinigen><en> At first it is necessary to clear well skin tonic, or lotion.
<G-vec00078-001-s514><clear.reinigen><de> Erstens muss man gut die Haut tonikom, oder der Lotion reinigen.
<G-vec00078-001-s515><clear.reinigen><en> If you can do your part to clear the air today you could make a huge difference in how your children and grandchildren live in the future.
<G-vec00078-001-s515><clear.reinigen><de> Wenn Sie Ihren Teil tun, um die Luft zu reinigen Sie heute könnte einen großen Unterschied machen, wie Ihre Kinder und Enkelkinder leben in der Zukunft.
<G-vec00078-001-s516><clear.reinigen><en> The mask from a peach with starch addition will help to clear and moisten fat skin: on 1 fruit 1 teaspoon of starch from potatoes suffices.
<G-vec00078-001-s516><clear.reinigen><de> Die fettige Haut wird helfen, zu reinigen und, die Maske aus dem Pfirsich mit der Ergänzung der Stärke zu befeuchten: auf 1 Frucht ist genug es 1 Teelöffel der Stärke aus den Kartoffeln.
<G-vec00078-001-s517><clear.reinigen><en> Touch honey agarics, clear, wash out in cold water, bring to boiling in a pan and merge water.
<G-vec00078-001-s517><clear.reinigen><de> Die Hallimasche lesen Sie aus, reinigen Sie, waschen Sie im kalten Wasser aus, führen Sie bis zum Kochen im Kochtopf hin und ziehen Sie das Wasser zusammen.
<G-vec00078-001-s518><clear.reinigen><en> At breaks in work a laying cover with roofing felt or a brick dry, and before renewal of works clear of snow, naledi and a frozen solution.
<G-vec00078-001-s518><clear.reinigen><de> Bei den Pausen in der Arbeit das Mauerwerk bedecken tolem oder dem Ziegel nassucho, und vor der Erneuerung der Arbeiten reinigen vom Schnee, naledi und merslogo der Lösung.
<G-vec00078-001-s519><clear.reinigen><en> Mushrooms to wash up, clear if necessary, also small to cut.
<G-vec00078-001-s519><clear.reinigen><de> Die Pilze auszuwaschen, falls notwendig zu reinigen, auch klein zu schneiden.
<G-vec00078-001-s520><clear.reinigen><en> Prepare the footwear for painting: clear it and dry.
<G-vec00078-001-s520><clear.reinigen><de> Bereiten Sie die Schuhe zu pokraske vor: reinigen Sie sie und trocknen Sie aus.
<G-vec00078-001-s521><clear.reinigen><en> To clear it it will be faster possible, if right after over cookings to pour cold water.
<G-vec00078-001-s521><clear.reinigen><de> Es reinigen es kann schneller, wenn sofort nach dem Kochen, vom kalten Wasser zu begießen.
<G-vec00078-001-s522><clear.reinigen><en> He is now asked to clear himself of the charge and show that he was still a pious Jew.
<G-vec00078-001-s522><clear.reinigen><de> Es wird ihm nun aufgetragen, sich von dieser Anklage zu reinigen und darzutun, daß er noch ein frommer Jude sei.
<G-vec00078-001-s523><clear.reinigen><en> Your task - with the reliable weapon in hands to clear the city of evil spirits and to rescue the innocent.
<G-vec00078-001-s523><clear.reinigen><de> Ihre Aufgabe - mit den sicheren Waffen in den Händen, die Stadt von der Teufelei zu reinigen und, die Unschuldigen zu retten.
<G-vec00078-001-s524><clear.reinigen><en> Before repair the damaged place clear of unsteadily keeping parts and plaster which lags behind a wall at a lung postukivanii.
<G-vec00078-001-s524><clear.reinigen><de> Vor der Reparatur die beschädigte Stelle reinigen von es ist der sich haltenden Teilchen und des Putzes nicht haltbar, der von der Wand bei der Lunge postukiwanii zurückbleibt.
<G-vec00078-001-s525><clear.reinigen><en> Easy to clear, using a dish cloth to wipe stains or clean it with water.
<G-vec00078-001-s525><clear.reinigen><de> Leicht zu reinigen, mit einem Spültuch, um Flecken abzuwischen oder mit Wasser zu reinigen.
<G-vec00078-001-s526><clear.reinigen><en> Breed bokoplavy in a considerable quantity, they not only clear water, but also play essential and even defining role in a food of almost all fishes and waterfowls.
<G-vec00078-001-s526><clear.reinigen><de> Pflanzen sich bokoplawy in der großen Menge fort, sie nicht nur reinigen das Wasser, sondern auch spielen wesentlich und sogar die bestimmende Rolle in einer Ernährung ist es aller Fische und der Wasservögel praktisch.
<G-vec00078-001-s527><clear.reinigen><en> In the beginning clear a hollow of dead wood and smooth out a sharp knife of its edge to the healthy.
<G-vec00078-001-s527><clear.reinigen><de> Zunächst reinigen duplo vom toten Holz und säubern vom scharfen Messer seines Randes bis zur Gesunden.
<G-vec00078-001-s528><clear.reinigen><en> The day before the exhibition I sent forth-righteous thoughts in front of the Chinese embassy, in order to clear the field for the next day.
<G-vec00078-001-s528><clear.reinigen><de> Am Tag vor der Ausstellung sendete ich vor der chinesischen Botschaft aufrichtige Gedanken aus, um das Feld für den nächsten Tag zu reinigen.
<G-vec00078-001-s529><clear.reinigen><en> Having chosen a place for a fire, it is necessary to clear the earth of turf accurately.
<G-vec00078-001-s529><clear.reinigen><de> die Stelle für das Feuer Gewählt, muss man die Erde vom Rasen akkurat reinigen.
<G-vec00078-001-s530><clear.reinigen><en> For its preparation take one small tomato, clear of a peel (that it was easier to be made, it is possible to obdat it boiled water) and small cut pulp.
<G-vec00078-001-s530><clear.reinigen><de> Für ihre Vorbereitung nehmen Sie eine kleine Tomate, reinigen Sie von der Schale (damit es war es leichter, zu machen, man kann es abbrühen) und ist nareschte das Fruchtfleisch klein.
<G-vec00078-001-s531><clear.reinigen><en> If together with a band the edge of trousers at first unpick the turned in edge of a bottom of trousers was wiped also, clear of a dirt and iron.
<G-vec00078-001-s531><clear.reinigen><de> Wenn zusammen mit der Borte auch der Rand der Hosen abgerieben wurde, so reinigen zuerst otparywajut podognutyj der Rand des Unterteils der Hosen, vom Schmutz und bügeln.
<G-vec00279-002-s038><clear.deaktivieren><en> If you want to see only the complete multivalue field in your results, clear the Show check box for the single value field.
<G-vec00279-002-s038><clear.deaktivieren><de> Wenn Sie nur das vollständige mehrwertige Feld in den Ergebnissen anzeigen möchten, deaktivieren Sie das Kontrollkästchen Anzeigen für das Einzelwertfeld.
<G-vec00279-002-s039><clear.deaktivieren><en> Clear all the IIS Resource Kit Tools and components check boxes except the Metabase Explorer 1.6 check box.
<G-vec00279-002-s039><clear.deaktivieren><de> Deaktivieren Sie alle IIS Resource Kit Tools und Komponenten Kontrollkästchen außer dem KontrollkästchenMetabase Explorer 1.6 .
<G-vec00279-002-s040><clear.deaktivieren><en> * Word wipe: Clear the board for a Power Point bonus.
<G-vec00279-002-s040><clear.deaktivieren><de> * Wort wischen: Deaktivieren Sie das Board für eine Power-Point-Bonus.
<G-vec00279-002-s041><clear.deaktivieren><en> All you need is 45,000 points and then clear all the jellies.
<G-vec00279-002-s041><clear.deaktivieren><de> Alles, was Sie brauchen, ist 45.000 Punkte und dann deaktivieren Sie alle Gelees.
<G-vec00279-002-s042><clear.deaktivieren><en> However if, for example, you want to limit the Objectionable content policy to outbound mail, you can clear all check boxes except Outbound.
<G-vec00279-002-s042><clear.deaktivieren><de> Wenn Sie die Einstellung jedoch auf ausgehende E-Mails beschränken möchten, können Sie alle Kontrollkästchen außer "Ausgehend" deaktivieren.
<G-vec00279-002-s043><clear.deaktivieren><en> Clear the check boxes for products you do not want to repair.
<G-vec00279-002-s043><clear.deaktivieren><de> Deaktivieren Sie Kontrollkästchen für Produkte, die nicht repariert werden sollen.
<G-vec00279-002-s044><clear.deaktivieren><en> Clear the check box next to the folder you want to keep off this device.
<G-vec00279-002-s044><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen neben dem Ordner, der auf diesem Gerät nicht angezeigt werden soll.
<G-vec00279-002-s045><clear.deaktivieren><en> Clear this check box to hide these updates.
<G-vec00279-002-s045><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um diese Aktualisierungen auszublenden.
<G-vec00279-002-s046><clear.deaktivieren><en> Open the document library and clear all check marks so no files are selected.
<G-vec00279-002-s046><clear.deaktivieren><de> Öffnen Sie die Dokumentbibliothek, und deaktivieren Sie alle Häkchen, sodass keine Dateien ausgewählt sind.
<G-vec00279-002-s047><clear.deaktivieren><en> Click to clear the Use Cached Exchange Mode checkbox, click Next, and then click Finish.
<G-vec00279-002-s047><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen Exchange-Cache-Modus verwenden, klicken Sie auf Weiterund dann auf Fertig stellenklicken.
<G-vec00279-002-s048><clear.deaktivieren><en> Clear this check box to hide drawings and possibly speed the display of messages that contain many drawings.
<G-vec00279-002-s048><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, damit Zeichnungen ausgeblendet werden und die Anzeige von E-Mails mit zahlreichen Zeichnungen beschleunigt wird.
<G-vec00279-002-s049><clear.deaktivieren><en> Clear all eight exciting levels and enjoy the
<G-vec00279-002-s049><clear.deaktivieren><de> Deaktivieren Sie alle acht spannende Levels und genießen das Spiel.
<G-vec00279-002-s050><clear.deaktivieren><en> Clear the setting that blocks activation.
<G-vec00279-002-s050><clear.deaktivieren><de> Deaktivieren Sie die Einstellung, die die Aktivierung blockiert.
<G-vec00279-002-s051><clear.deaktivieren><en> Select the Temporary Internet files check box, clear the other check boxes, and then click Delete.
<G-vec00279-002-s051><clear.deaktivieren><de> Aktivieren Sie das Kontrollkästchen Temporäre Internetdateien, deaktivieren Sie die übrigen Kontrollkästchen, und klicken Sie auf Löschen.
<G-vec00279-002-s052><clear.deaktivieren><en> If you do not want the Connect to MobiLink Server dialog to appear when you start the Monitor without command line options, clear the checkbox beside this option.
<G-vec00279-002-s052><clear.deaktivieren><de> Wenn das Fenster Mit dem MobiLink-Server verbinden beim Aufruf des MobiLink-Monitors ohne Befehlszeilenoptionen nicht erscheinen soll, deaktivieren Sie das Kontrollkästchen zu dieser Option.
<G-vec00279-002-s053><clear.deaktivieren><en> Eat a grass and clear a level.
<G-vec00279-002-s053><clear.deaktivieren><de> Essen Sie alle das Gras und deaktivieren Sie die Ebene.
<G-vec00279-002-s054><clear.deaktivieren><en> Clear series of exiting levels and have fun.
<G-vec00279-002-s054><clear.deaktivieren><de> Deaktivieren Sie alle Ebenen und gewinnen das Spiel zu.
<G-vec00279-002-s055><clear.deaktivieren><en> If you do not want to display table headers, on the Tables tab, under Table Options, clear Header Row.
<G-vec00279-002-s055><clear.deaktivieren><de> Hinweis: Wenn Sie keine Tabellenüberschriften anzeigen möchten, können Sie sie später deaktivieren.
<G-vec00279-002-s056><clear.deaktivieren><en> Clear the check box to display the docking area at the bottom of the window.
<G-vec00279-002-s056><clear.deaktivieren><de> Deaktivieren Sie das Kontrollkästchen, um den Andockbereich unten im Vegas-Fenster anzuzeigen.
<G-vec00279-002-s190><clear.eindeutigen><en> Consent shall mean any informed and unambiguous statement of intent by the data subject in the form of a declaration or other clear affirmative act by which the data subject indicates his or her consent to the processing of personal data concerning him or her.
<G-vec00279-002-s190><clear.eindeutigen><de> Eine Einwilligung ist jede von der betroffenen Person freiwillig für den bestimmten Fall in informierter Weise und unmissverständlich abgegebene Willensbekundung in Form einer Erklärung oder einer sonstigen eindeutigen bestätigenden Handlung, mit der die betroffene Person zu verstehen gibt, dass sie mit der Verarbeitung der sie betreffenden personenbezogenen Daten einverstanden ist.
<G-vec00279-002-s191><clear.eindeutigen><en> Each cartridge housing is individually marked for clear identification.
<G-vec00279-002-s191><clear.eindeutigen><de> Jedes Kerzengehäuse ist individuell zur eindeutigen Identifikation gekennzeichnet.
<G-vec00279-002-s192><clear.eindeutigen><en> RODRÍGUEZ MARADIAGA: But to say that it was lawful only «in the case of a clear and prolonged tyranny that grievously attacked the fundamental rights of the person and harmed in dangerous fashion the common good of the country».
<G-vec00279-002-s192><clear.eindeutigen><de> RODRÍGUEZ MARADIAGA: Aber nur, um herauszustellen, daß diese nur im „Fall der eindeutigen und lang dauernden Gewaltherrschaft, die die Grundrechte der Person schwer verletzt und dem Gemeinwohl des Landes ernsten Schaden zufügt“ legitim ist.
<G-vec00279-002-s193><clear.eindeutigen><en> One the one hand this serves for clear traceability of stamped parts, and on the other hand for visual monitoring of the correct machine parameters.
<G-vec00279-002-s193><clear.eindeutigen><de> Dies dient zum einen zur eindeutigen Nachverfolgbarkeit der Stanzteile und zum anderen zur optischen Kontrolle der richtigen Maschinenparameter.
<G-vec00279-002-s194><clear.eindeutigen><en> The concept comprises an unambiguous gesture that cannot be released accidentally to unlock the interaction. It must be performed consciously and then be confirmed by another clear gesture.
<G-vec00279-002-s194><clear.eindeutigen><de> Das Konzept beinhaltet eine eindeutige Geste zum Entsperren der Interaktion, die nicht zufällig ausgelöst werden kann: Sie muss bewusst eingesetzt und mit einer weiteren, eindeutigen Geste bestätigt werden.
<G-vec00279-002-s195><clear.eindeutigen><en> This number is also output in the documents to establish a clear reference to your article master.
<G-vec00279-002-s195><clear.eindeutigen><de> Diese Nummer wird auch in den Belegen ausgegeben, um einen eindeutigen Bezug zu Ihrem Artikelstamm herstellen zu können.
<G-vec00279-002-s196><clear.eindeutigen><en> In order to offer the potential for profiling and also clear guidance in the jungle of available organic produce, the BCS-ÖKO-Garantie assigns its own test seal which goes beyond the EC standards. On the market, this indicates the environmental consistency of all elements right down to the packaging.
<G-vec00279-002-s196><clear.eindeutigen><de> Um im "BIO-Angebots-Dschungel" die Möglichkeit zur Profilierung und zugleich zur eindeutigen Orientierung zu bieten, vergibt BCS-ÖKO-Garantie über den EG-Standard hinaus ein eigenes Prüfsiegel, das am Markt weitergehende Konsequenz bis zur Umweltverträglichkeit der Verpackung signalisiert.
<G-vec00279-002-s197><clear.eindeutigen><en> You can perfectly ADAPT YOUR SHOVELING STRATEGY and save important time thanks to the clear 1m marker, CONTRASTINGDEPTH SCALE and COLORFUL END SEGMENTS.
<G-vec00279-002-s197><clear.eindeutigen><de> Dank der eindeutigen 1 m - Markierung, der KONTRASTREICHEN TIEFENSKALA sowie der FARBIGEN ENDSEGMENTE kannst du deine SCHAUFELSTRATEGIE OPTIMAL ANPASSEN und wichtige Zeit sparen.
<G-vec00279-002-s198><clear.eindeutigen><en> If we make significant changes to the way in which we collect, use and/or disclose the personal data you provide to us, we will make you aware of this by providing you with a clear and clearly visible notice on the website.
<G-vec00279-002-s198><clear.eindeutigen><de> Sollten wir wesentliche Änderungen bei der Sammlung, der Nutzung und/oder der Weitergabe der uns von Ihnen zur Verfügung gestellten personenbezogenen Daten vornehmen, werden wir Sie durch einen eindeutigen und gut sichtbaren Hinweis auf der Website darauf aufmerksam machen.
<G-vec00279-002-s199><clear.eindeutigen><en> To exercise the right to cancel, you must inform us (enter postal address, telephone number and e-mail address here) of your decision to cancel this contract by a clear statement (e.g.
<G-vec00279-002-s199><clear.eindeutigen><de> Um Ihr Widerrufsrecht auszuüben, müssen Sie uns (CAMONDAS Schokoladen GmbH, An der Frauenkirche 20, 01067 Dresden, info@camondas.de, Telefon: 0351 49 76 98 43) mittels einer eindeutigen Erklärung (z.
<G-vec00279-002-s200><clear.eindeutigen><en> Now you has responded with a clear Statement on your Website on the rumors.
<G-vec00279-002-s200><clear.eindeutigen><de> Jetzt hat sie mit einem eindeutigen Statement auf ihrer Website auf die Gerüchte reagiert.
<G-vec00279-002-s201><clear.eindeutigen><en> In about half the cases, it is not possible to give a clear reason for the habitual abortions.
<G-vec00279-002-s201><clear.eindeutigen><de> In etwa der Hälfte der Fälle ist es nicht möglich, einen eindeutigen Grund für die wiederholten Fehlgeburten zu benennen.
<G-vec00279-002-s202><clear.eindeutigen><en> Pipeline operators all over the world are convinced of the clear cost advantages (CAPEX and OPEX).
<G-vec00279-002-s202><clear.eindeutigen><de> Die eindeutigen Kostenvorteile (CAPEX und OPEX) haben bereits Rohrbetreiber überall auf der Welt überzeugt.
<G-vec00279-002-s203><clear.eindeutigen><en> That means that elections to the European Parliament must become, more clearly than before, contests between clear political alternatives, and between the leaders representing those alternatives.
<G-vec00279-002-s203><clear.eindeutigen><de> Dies bedeutet, dass die Wahlen zum Europäischen Parlament noch deutlicher als bisher zu einem Wettstreit zwischen eindeutigen politischen Alternativen werden müssen und somit zwischen den politischen Vertretern dieser Alternativen.
<G-vec00279-002-s204><clear.eindeutigen><en> But in this case, I think it is quite clear that autocomplete should be reigned in because there would be no detriment to free speech involved.
<G-vec00279-002-s204><clear.eindeutigen><de> In diesem sehr speziellen und recht eindeutigen Fall jedoch finde ich, dass die Autovervollständigung manipuliert werden kann, da hier keine Bedrohung der Meinungsfreiheit vorliegt.
<G-vec00279-002-s205><clear.eindeutigen><en> If you cannot say something good, the Bible is clear: keep quiet.
<G-vec00279-002-s205><clear.eindeutigen><de> Wenn du nichts Gutes sagen kannst, hat die Bibel einen eindeutigen Rat: Halte deinen Mund.
<G-vec00279-002-s206><clear.eindeutigen><en> "Despite the clear and weighty evidence based on reputable scientific facts, large parts of the media, unwitting doctors and alleged “nutritionists” keep spreading incorrect and misleading facts about the animal food industry and archaic and faulty doctrines.
<G-vec00279-002-s206><clear.eindeutigen><de> "Trotz der überwältigend eindeutigen Beweislage aufgrund der seriösen wissenschaftlichen Fakten verbreiten große Teile der Presse, unwissende Ärzte und vermeintliche „Ernährungsexperten“ lieber Unwahrheiten und Irreführungen der Tierindustrie und falsche Lehrmeinungen vergangener Zeiten.
<G-vec00279-002-s207><clear.eindeutigen><en> Attractively designed 3D floor advertising leads to a clear advantage for the advertised brand over competitive products in the direct vicinity on the shelves.
<G-vec00279-002-s207><clear.eindeutigen><de> Attraktiv gestaltete Bodenwerbung wird von den Kunden als angenehme Überraschung beim Einkauf empfunden und führt zu einem eindeutigen Vorteil der zu bewerbenden Marke gegenüber Konkurrenzprodukten, die sich im Warenregal in unmittelbarer Nähe befinden.
<G-vec00279-002-s208><clear.eindeutigen><en> The novel booklets and puzzle magazines, as well as the publishing segments children's and youth books, audio and, in particular, LYX were the clear growth and earnings drivers in the last nine months.
<G-vec00279-002-s208><clear.eindeutigen><de> Die Verlagssparten Romanhefte und Rätselmagazine, Kinder- und Jugendbuch, Audio und insbesondere LYX gehörten in den vergangenen neun Monaten zu den eindeutigen Wachstums- und Ergebnismotoren innerhalb der Verlagsgruppe.
<G-vec00279-002-s342><clear.klaren><en> It offers a clear overview of all sponsors’ contracts, the ability to track easily all contract related activities and to have a communication history with each account.
<G-vec00279-002-s342><clear.klaren><de> Es bietet einen klaren Überblick über die Verträge aller Sponsoren, die Möglichkeit, alle vertragsbezogenen Aktivitäten leicht zu verfolgen und mit jedem Konto einen Kommunikationsverlauf zu haben.
<G-vec00279-002-s343><clear.klaren><en> Depending on the destination, there are sometimes quite rigid security regulations of public institutions for providers: This ranges from the audit requirement for operators and boatmen on the regular decrease of boats up to clear rules as regards the equipment to be carried.
<G-vec00279-002-s343><clear.klaren><de> Abhängig vom Zielgebiet existieren teils recht rigide Sicherheitsmaßgaben öffentlicher Institutionen für die Anbieter: Das reicht von der Prüfungspflicht für Unternehmer und Bootsführer über die regelmäßige Abnahme der Boote bis zu klaren Vorschriften, was die mitzuführende Ausrüstung angeht.
<G-vec00279-002-s344><clear.klaren><en> We place a clear focus on action competence and transversal skills for direct use in companies and teach you this in interdisciplinary classes.
<G-vec00279-002-s344><clear.klaren><de> Wir legen einen klaren Fokus auf Handlungs- und Querschnittskompetenz für den direkten Einsatz in Unternehmen und vermitteln Ihnen dies in interdisziplinären Lehrveranstaltungen.
<G-vec00279-002-s345><clear.klaren><en> The settled communists as well as a wide range of NGOs close to the WSF failed to take a clear stance on the side of Muslims and Dalits against the fascist-like communalist frenzy that saw its preliminary climaxes in the destruction of the destruction of the Babri mosque in Ayodhya in 1992 and in the Gujarat massacre of 2002.
<G-vec00279-002-s345><clear.klaren><de> Die etablierten Kommunistische Partei sowie auch die meisten der NGOs, die in einem Naheverhältnis zu dem WSF stehen, versagten im Einnehmen einer klaren Position auf der Seite der Moslems und Dalits gegen die faschistoide kommunalistische Raserei, die ihre vorläufigen Höhepunkte in der Zerstörung der Babri Moschee in Ayodhya 1992 und im Massaker von Gujarat 2002 fanden.
<G-vec00279-002-s346><clear.klaren><en> Through a pleasant tour, with clear images and without filters, our real estate agent will walk around the living room, kitchen and all the interiors and exteriors of the property.
<G-vec00279-002-s346><clear.klaren><de> Durch eine angenehme Tour, mit klaren Bildern und ohne Filter, wird unser Immobilienmakler durch das Wohnzimmer, die Küche und alle Innen- und Außenbereiche der Immobilie gehen.
<G-vec00279-002-s347><clear.klaren><en> We will create together an action plan in order to be clear about what and how you can actually achieve within or outside the organization.
<G-vec00279-002-s347><clear.klaren><de> In diesem Workshop erstellen wir gemeinsam einen Aktionsplan, um darüber im Klaren zu sein, wie Sie sich tatsächlich innerhalb oder auch außerhalb der Organisation verwirklichen können.
<G-vec00279-002-s348><clear.klaren><en> They help our customers enjoy clear benefits with costs and utilisation.
<G-vec00279-002-s348><clear.klaren><de> So verhelfen wir unseren Kunden zu klaren Kosten- und Nutzenvorteilen.
<G-vec00279-002-s349><clear.klaren><en> You will know how to increase your project success with a clear project order and a strong interaction with the project manager.
<G-vec00279-002-s349><clear.klaren><de> Sie erfahren, wie Sie Ihren Projekterfolg mit einem klaren Projektauftrag und einem starken Zusammenspiel mit der ProjektmanagerIn steigern.
<G-vec00279-002-s350><clear.klaren><en> There was never a clear plan or idea of what we were to do.
<G-vec00279-002-s350><clear.klaren><de> Es gab niemals einen klaren Plan oder Idee, was wir tun sollten.
<G-vec00279-002-s351><clear.klaren><en> We, CERATIZIT Germany GmbH, are responsible for this online offer and, as a teleservice provider, are obliged to inform you at the start of your visit to our online offer, in clear and simple language, about the nature, scope and purpose of the collection and use of personal data, and to do so in a precise, transparent, understandable and easily accessible form.
<G-vec00279-002-s351><clear.klaren><de> Wir, CERATIZIT Deutschland GmbH, sind Verantwortlicher für dieses Onlineangebot und haben als Anbieter eines Teledienstes Sie zu Beginn Ihres Besuches auf unserem Onlineangebot über Art, Umfang und Zwecke der Erhebung und Verwendung personenbezogener Daten in präziser, transparenter, verständlicher und leicht zugänglicher Form in einer klaren und einfachen Sprache zu unterrichten.
<G-vec00279-002-s352><clear.klaren><en> Needless to say, equally, if not more spectacular is the lake with its clear water and accompanying mountain panorama.
<G-vec00279-002-s352><clear.klaren><de> Natürlich ist der See mit seinem klaren Wasser und dem dazugehörigen Bergpanorama mindestens so spektakulär.
<G-vec00279-002-s353><clear.klaren><en> At the end it was only possible to enjoy take-offs in full afterburner in the dark clear sky.
<G-vec00279-002-s353><clear.klaren><de> Ab einem gewissen Zeitpunkt war es nur noch möglich die Starts mit vollem Nachbrenner im dunklen klaren Nachthimmel zu bestaunen.
<G-vec00279-002-s354><clear.klaren><en> Since short-acting insulin is clear and long-acting insulin is cloudy, you can use the following to help you remember the order when drawing insulin up: always start clear and end cloudy.
<G-vec00279-002-s354><clear.klaren><de> Da kurzfristig aktives Insulin klar und langfristig aktives trüb ist, kannst du Folgendes verwenden, um dir die Reihenfolge zu merken, wenn du Insulin aufziehst: "Startklar" – starte mit der klaren Flüssigkeit.
<G-vec00279-002-s355><clear.klaren><en> According to the BBC, Estonian Prime Minister Taavi Roivas called the verdict “a clear and grave violation of international law”.
<G-vec00279-002-s355><clear.klaren><de> Nach Angaben der BBC bezeichnete der estnische Ministerpräsident Taavi Roivas das Urteil als „klaren und schweren Verstoß gegen internationales Recht“.
<G-vec00279-002-s356><clear.klaren><en> Compared to the current RTI Strategy 2020, in which some things have fallen by the wayside, the new undertaking presents essential improvements, according to the FWF’s president, as it constitutes a joint approach, also involves the finance ministry, and features a clear division of tasks.
<G-vec00279-002-s356><clear.klaren><de> Im Gegensatz zur aktuellen FTI-Strategie 2020, bei der doch einiges auf der Strecke blieb, sieht der FWF-Präsident bei der nunmehr vorgestellten Initiative im gemeinsamen Vorgehen, der Einbeziehung auch des Finanzministeriums sowie der klaren Aufgabenverteilung wesentliche Verbesserungen.
<G-vec00279-002-s357><clear.klaren><en> KING KING KING survives short-lived fashion trends thanks to the elegance of its clear shapes.
<G-vec00279-002-s357><clear.klaren><de> KING KING Dank der Eleganz seiner klaren Form überdauert KING schnelllebige Modetrends.
<G-vec00279-002-s358><clear.klaren><en> "The signing of this contract demonstrates the strong commitment and the clear political will to create an independent global satellite navigation system in Europe," said the Chairman of the DLR Executive Board, Johann-Dietrich Wörner.
<G-vec00279-002-s358><clear.klaren><de> "Die Vertragsunterzeichnung verdeutlicht das große Engagement und den klaren politischen Willen zur Schaffung eines eigenständigen globalen Satellitennavigationssystems Europas", erklärt der DLR-Vorstandsvorsitzende Prof. Dr. Johann-Dietrich Wörner.
<G-vec00279-002-s359><clear.klaren><en> On a clear day, the shores of Iran from Sky.
<G-vec00279-002-s359><clear.klaren><de> An einem klaren Tag können Sie sogar die Grenze zum Iran von Sky aus sehen.
<G-vec00279-002-s360><clear.klaren><en> The HOFA PRO course has helped me tie together all the disparate threads of music production knowledge I’ve picked up over the years into a clear and comprehensive formal structure.
<G-vec00279-002-s360><clear.klaren><de> Der HOFA PRO Kurs hat mir geholfen, all die unterschiedlichen Wissensstränge der Musikproduktion, die ich im Laufe der Jahre gesammelt habe, zu einer klaren und umfassenden formalen Struktur zu verbinden.
<G-vec00279-002-s475><clear.löschen><en> To clear the New Shortcut Key input field, press any of the control keys, Ctrl, Alt, or Shift.
<G-vec00279-002-s475><clear.löschen><de> Um die Eingabe im Feld "Tastaturkürzel drücken" zu löschen, drücken Sie eine der Tasten Strg, Alt oder Umschalt.
<G-vec00279-002-s476><clear.löschen><en> Expand Settings and select the check box next to Clear update cache.
<G-vec00279-002-s476><clear.löschen><de> Erweitern Sie Einstellungen und aktivieren Sie das Kontrollkästchen neben Update-Cache löschen.
<G-vec00279-002-s477><clear.löschen><en> However, you can clear the results in the Output Pane.
<G-vec00279-002-s477><clear.löschen><de> Sie können jedoch die Ergebnisse im Ausgabebereich löschen.
<G-vec00279-002-s478><clear.löschen><en> This is an amazing action game.One man army in war as a frontline commando...You are appointed as an sniper shooter, your mission is to clear the small enemy unit that will try to protect the city.You are equipped with a modern sniper...
<G-vec00279-002-s478><clear.löschen><de> Das ist ein erstaunliches Action-Spiel.Ein Mann Armee im Krieg als Frontline-Kommando...Sie werden als Scharfschützen-Shooter ernannt, Ihre Mission ist es, die kleine feindliche Einheit zu löschen, die versuchen wird, die Stadt zu schützen.Sie sind mit einer...
<G-vec00279-002-s479><clear.löschen><en> Clear your Internet tracks, sweep away temporary files you may have downloaded, and hide which programs you have recently used.
<G-vec00279-002-s479><clear.löschen><de> Löschen Sie Ihre Internet-Spuren, wegfegen temporäre Dateien, die Sie heruntergeladen haben, und verstecken sich, welche Programme Sie in letzter Zeit verwendet haben.
<G-vec00279-002-s480><clear.löschen><en> Solution 3: Clear the system cache Press the Guide button on your controller. Go to Settings and select System Settings.
<G-vec00279-002-s480><clear.löschen><de> Löschen des Systemcaches Drücken Sie auf dem Controller die Guide-Taste, wechseln Sie zu den "Einstellungen", und wählen Sie "Systemeinstellungen" aus.
<G-vec00279-002-s481><clear.löschen><en> Tap "Privacy" and then "Clear personal data".
<G-vec00279-002-s481><clear.löschen><de> Tippen Sie auf "Datenschutz" und dann auf "Persönliche Daten löschen".
<G-vec00279-002-s482><clear.löschen><en> To clear your history and cookies, go to Settings > Safari, and tap Clear History and Website Data.
<G-vec00279-002-s482><clear.löschen><de> Um den Verlauf und Cookies zu löschen, gehen Sie zu "Einstellungen" > "Safari", und tippen Sie auf "Verlauf und Websitedaten löschen".
<G-vec00279-002-s484><clear.löschen><en> In order to clear the data being stored by the border concepts GmbH, you can turn to the border concepts GmbH (dataprivacy(at)borderconcepts.biz) at any time.
<G-vec00279-002-s484><clear.löschen><de> Zum Löschen der von der border concepts GmbH gespeicherten Daten können Sie sich jederzeit an die border concepts GmbH wenden (datenschutz(at)borderconcepts.biz).
<G-vec00279-002-s485><clear.löschen><en> You can also clear formatting.
<G-vec00279-002-s485><clear.löschen><de> Sie können auch die Formatierung löschen.
<G-vec00279-002-s486><clear.löschen><en> To clear the operational indicators, press ON SCREEN twice.
<G-vec00279-002-s486><clear.löschen><de> Um die Betriebsanzeigen zu löschen, drücken Sie zweimal auf ON SCREEN.
<G-vec00279-002-s487><clear.löschen><en> First of all, you need to clear the file from cuts and possible rust.
<G-vec00279-002-s487><clear.löschen><de> Zunächst einmal müssen Sie die Datei aus Kürzungen und möglichem Rost löschen.
<G-vec00279-002-s488><clear.löschen><en> If you want to clear the text you entered, click the button [Clear].
<G-vec00279-002-s488><clear.löschen><de> Wollen Sie den eingegebenen Text wieder löschen, klicken Sie auf die Schaltfläche [Löschen].
<G-vec00279-002-s489><clear.löschen><en> If you want to clear the text you entered, click the button [Clear].
<G-vec00279-002-s489><clear.löschen><de> Wollen Sie den eingegebenen Text wieder löschen, klicken Sie auf die Schaltfläche [Löschen].
<G-vec00279-002-s490><clear.löschen><en> Copy the rule, "Clear categories on mail."
<G-vec00279-002-s490><clear.löschen><de> Kopiere die Regel "Kategorie aus Mail löschen".
<G-vec00279-002-s491><clear.löschen><en> Clear passwords: Deletes any previously stored user names or passwords.
<G-vec00279-002-s491><clear.löschen><de> Kennwörter löschen: Löscht gespeicherte Kennwörter.
<G-vec00279-002-s492><clear.löschen><en> Match colors vertically to clear them.
<G-vec00279-002-s492><clear.löschen><de> Spiel Farben vertikal um sie zu löschen.
<G-vec00279-002-s493><clear.löschen><en> Here you will find options related to displaying recent searches or if you care to clear all of them when exiting the browser.
<G-vec00279-002-s493><clear.löschen><de> Hier finden Sie Optionen, um die Anzeige der aktuellen Suchanfragen zu ändern oder um alle zu löschen, wenn Sie den Browser schließen.
