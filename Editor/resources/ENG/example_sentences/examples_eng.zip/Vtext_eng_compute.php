<G-vec00206-002-s019><compute.berechnen><en> SPEED CONTROLLERS 32 How to compute current consumption properly.
<G-vec00206-002-s019><compute.berechnen><de> FAHRTREGLER 32 So berechnen Sie den Stromverbrauch richtig.
<G-vec00206-002-s020><compute.berechnen><en> To characterize how pleasant the weather is in Chinchinim throughout the year, we compute two travel scores.
<G-vec00206-002-s020><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Araguanã im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s021><compute.berechnen><en> To characterize how pleasant the weather is in Brooks throughout the year, we compute two travel scores.
<G-vec00206-002-s021><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Brooks im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s022><compute.berechnen><en> To characterize how pleasant the weather is in El Monte throughout the year, we compute two travel scores.
<G-vec00206-002-s022><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in El Arador im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s023><compute.berechnen><en> To characterize how pleasant the weather is in Rūdiškės throughout the year, we compute two travel scores.
<G-vec00206-002-s023><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Yarkovo im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s024><compute.berechnen><en> To characterize how pleasant the weather is at Davenport Municipal Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s024><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Ağrı Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s025><compute.berechnen><en> To characterize how pleasant the weather is in Manhiça throughout the year, we compute two travel scores.
<G-vec00206-002-s025><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Osasco im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s026><compute.berechnen><en> With the Ray Acoustics interface, you can compute the trajectories, phase, and intensity of acoustic rays.
<G-vec00206-002-s026><compute.berechnen><de> Mit dem Interface Ray Acoustics können Sie die Trajektorien, die Phase und die Intensität der Schallwellen berechnen.
<G-vec00206-002-s027><compute.berechnen><en> To characterize how pleasant the weather is in Cienfuegos throughout the year, we compute two travel scores.
<G-vec00206-002-s027><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Pablo L. Sidar im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s028><compute.berechnen><en> To characterize how pleasant the weather is at Edwards County Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s028><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Barstow Daggett County Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s029><compute.berechnen><en> A key feature as compared to other methods to standardize grades is that we do not only compute a standardized grade point average (GPA) but also provide standardized grades at the level of individual exams.
<G-vec00206-002-s029><compute.berechnen><de> Ein Kernaspekt unserer Methode im Vergleich zu anderen Methoden ist, dass wir nicht nur einen standardisierten Notendurchschnitt berechnen sondern standardisierte Noten für die einzelnen Prüfungen erstellen.
<G-vec00206-002-s030><compute.berechnen><en> To characterize how pleasant the weather is in Kayan throughout the year, we compute two travel scores.
<G-vec00206-002-s030><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Ayapa im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s031><compute.berechnen><en> They have mastered the operations of vector algebra and their applications to linear geometry; they know the behaviour of the solutions of systems of linear equations and are able to compute the solutions; they can do basic calculations with matrices and determinants including finding eigenvalues and eigenvectors.
<G-vec00206-002-s031><compute.berechnen><de> Sie beherrschen die Operationen der Vektorrechnung und deren Anwendung in der linearen Geometrie; sie kennen das Lösungsverhalten linearer Gleichungssysteme und können die Lösungen berechnen; sie beherrschen das grundlegende Rechnen mit Matrizen und Determinanten einschließlich der Bestimmung von Eigenwerten und Eigenvektoren.
<G-vec00206-002-s032><compute.berechnen><en> To characterize how pleasant the weather is at Redding Municipal Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s032><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Gobernador Edgardo Castello Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s033><compute.berechnen><en> To characterize how pleasant the weather is at Gioia Del Colle throughout the year, we compute two travel scores.
<G-vec00206-002-s033><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Gioia Del Colle im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s034><compute.berechnen><en> If your data represents the entire population, then compute the standard deviation using STDEVP.
<G-vec00206-002-s034><compute.berechnen><de> Für den Fall, dass die zugehörigen Daten eine Grundgesamtheit angeben, sollten Sie die Standardabweichung mit der Funktion STABWNA berechnen.
<G-vec00206-002-s035><compute.berechnen><en> To characterize how pleasant the weather is in Tarxien throughout the year, we compute two travel scores.
<G-vec00206-002-s035><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Huaranchal im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s036><compute.berechnen><en> To characterize how pleasant the weather is in Kirchhundem throughout the year, we compute two travel scores.
<G-vec00206-002-s036><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Calatañazor im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s037><compute.berechnen><en> To characterize how pleasant the weather is in Tapalpa throughout the year, we compute two travel scores.
<G-vec00206-002-s037><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Tepango im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s264><compute.rechnen><en> Therefore, applications can compute with up to eight threads at the same time.
<G-vec00206-002-s264><compute.rechnen><de> Anwendungen können deshalb auf bis zu acht Threads gleichzeitig rechnen.
<G-vec00206-002-s265><compute.rechnen><en> (They do compute as to the calculation of the number of people).
<G-vec00206-002-s265><compute.rechnen><de> (Sie rechnen jedoch bei der Berechnung der Personenzahl mit).
<G-vec00206-002-s268><compute.verarbeiten><en> Mammalian cortical neurons compute sensory information that arrives through numerous synaptic inputs located on their dendrites.
<G-vec00206-002-s268><compute.verarbeiten><de> Kortikale Neurone in Säugetieren verarbeiten sensorische Informationen, die sie durch unzählige Synapsen entlang ihrer Dendriten empfangen.
<G-vec00206-002-s269><compute.verarbeiten><en> Hewlett Packard Enterprise and Intel® are pushing the Internet of Things forward by building a new class of systems that compute and analyse data where it lives - everywhere.
<G-vec00206-002-s269><compute.verarbeiten><de> Hewlett Packard Enterprise und Intel® bringen das Internet der Dinge voran, indem sie eine neue Art von Systemen entwickeln, die Daten dort verarbeiten und analysieren wo sie entstehen – überall.
<G-vec00206-002-s270><compute.verarbeiten><en> Yes, one hell of a description, but the guys and girl compute a whole whack of different influences.
<G-vec00206-002-s270><compute.verarbeiten><de> Ja, das ist ein ziemlicher Brocken von einer Beschreibung, aber die Jungs und Madel verarbeiten eine ganze Menge verschiedener Einflusse.
<G-vec00206-002-s271><compute.verarbeiten><en> Determining how brain cells compute recognisable images in the higher visual cortex was one of the study’s initial steps.
<G-vec00206-002-s271><compute.verarbeiten><de> Einer der ersten Schritte der Studie bestand darin, zu bestimmen, wie Gehirnzellen im oberen visuellen Cortex Bilder von erkennbaren Objekten verarbeiten.
