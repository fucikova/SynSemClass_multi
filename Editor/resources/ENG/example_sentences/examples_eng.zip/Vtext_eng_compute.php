<G-vec00206-002-s019><compute.berechnen><en> SPEED CONTROLLERS 32 How to compute current consumption properly.
<G-vec00206-002-s019><compute.berechnen><de> FAHRTREGLER 32 So berechnen Sie den Stromverbrauch richtig.
<G-vec00206-002-s020><compute.berechnen><en> To characterize how pleasant the weather is in Chinchinim throughout the year, we compute two travel scores.
<G-vec00206-002-s020><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Araguanã im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s021><compute.berechnen><en> To characterize how pleasant the weather is in Brooks throughout the year, we compute two travel scores.
<G-vec00206-002-s021><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Brooks im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s022><compute.berechnen><en> To characterize how pleasant the weather is in El Monte throughout the year, we compute two travel scores.
<G-vec00206-002-s022><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in El Arador im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s023><compute.berechnen><en> To characterize how pleasant the weather is in Rūdiškės throughout the year, we compute two travel scores.
<G-vec00206-002-s023><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Yarkovo im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s024><compute.berechnen><en> To characterize how pleasant the weather is at Davenport Municipal Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s024><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Ağrı Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s025><compute.berechnen><en> To characterize how pleasant the weather is in Manhiça throughout the year, we compute two travel scores.
<G-vec00206-002-s025><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Osasco im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s026><compute.berechnen><en> With the Ray Acoustics interface, you can compute the trajectories, phase, and intensity of acoustic rays.
<G-vec00206-002-s026><compute.berechnen><de> Mit dem Interface Ray Acoustics können Sie die Trajektorien, die Phase und die Intensität der Schallwellen berechnen.
<G-vec00206-002-s027><compute.berechnen><en> To characterize how pleasant the weather is in Cienfuegos throughout the year, we compute two travel scores.
<G-vec00206-002-s027><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Pablo L. Sidar im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s028><compute.berechnen><en> To characterize how pleasant the weather is at Edwards County Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s028><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Barstow Daggett County Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s029><compute.berechnen><en> A key feature as compared to other methods to standardize grades is that we do not only compute a standardized grade point average (GPA) but also provide standardized grades at the level of individual exams.
<G-vec00206-002-s029><compute.berechnen><de> Ein Kernaspekt unserer Methode im Vergleich zu anderen Methoden ist, dass wir nicht nur einen standardisierten Notendurchschnitt berechnen sondern standardisierte Noten für die einzelnen Prüfungen erstellen.
<G-vec00206-002-s030><compute.berechnen><en> To characterize how pleasant the weather is in Kayan throughout the year, we compute two travel scores.
<G-vec00206-002-s030><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Ayapa im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s031><compute.berechnen><en> They have mastered the operations of vector algebra and their applications to linear geometry; they know the behaviour of the solutions of systems of linear equations and are able to compute the solutions; they can do basic calculations with matrices and determinants including finding eigenvalues and eigenvectors.
<G-vec00206-002-s031><compute.berechnen><de> Sie beherrschen die Operationen der Vektorrechnung und deren Anwendung in der linearen Geometrie; sie kennen das Lösungsverhalten linearer Gleichungssysteme und können die Lösungen berechnen; sie beherrschen das grundlegende Rechnen mit Matrizen und Determinanten einschließlich der Bestimmung von Eigenwerten und Eigenvektoren.
<G-vec00206-002-s032><compute.berechnen><en> To characterize how pleasant the weather is at Redding Municipal Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s032><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Gobernador Edgardo Castello Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s033><compute.berechnen><en> To characterize how pleasant the weather is at Gioia Del Colle throughout the year, we compute two travel scores.
<G-vec00206-002-s033><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Gioia Del Colle im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s034><compute.berechnen><en> If your data represents the entire population, then compute the standard deviation using STDEVP.
<G-vec00206-002-s034><compute.berechnen><de> Für den Fall, dass die zugehörigen Daten eine Grundgesamtheit angeben, sollten Sie die Standardabweichung mit der Funktion STABWNA berechnen.
<G-vec00206-002-s035><compute.berechnen><en> To characterize how pleasant the weather is in Tarxien throughout the year, we compute two travel scores.
<G-vec00206-002-s035><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Huaranchal im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s036><compute.berechnen><en> To characterize how pleasant the weather is in Kirchhundem throughout the year, we compute two travel scores.
<G-vec00206-002-s036><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Calatañazor im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s037><compute.berechnen><en> To characterize how pleasant the weather is in Tapalpa throughout the year, we compute two travel scores.
<G-vec00206-002-s037><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Tepango im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s264><compute.rechnen><en> Therefore, applications can compute with up to eight threads at the same time.
<G-vec00206-002-s264><compute.rechnen><de> Anwendungen können deshalb auf bis zu acht Threads gleichzeitig rechnen.
<G-vec00206-002-s265><compute.rechnen><en> (They do compute as to the calculation of the number of people).
<G-vec00206-002-s265><compute.rechnen><de> (Sie rechnen jedoch bei der Berechnung der Personenzahl mit).
<G-vec00206-002-s268><compute.verarbeiten><en> Mammalian cortical neurons compute sensory information that arrives through numerous synaptic inputs located on their dendrites.
<G-vec00206-002-s268><compute.verarbeiten><de> Kortikale Neurone in Säugetieren verarbeiten sensorische Informationen, die sie durch unzählige Synapsen entlang ihrer Dendriten empfangen.
<G-vec00206-002-s269><compute.verarbeiten><en> Hewlett Packard Enterprise and Intel® are pushing the Internet of Things forward by building a new class of systems that compute and analyse data where it lives - everywhere.
<G-vec00206-002-s269><compute.verarbeiten><de> Hewlett Packard Enterprise und Intel® bringen das Internet der Dinge voran, indem sie eine neue Art von Systemen entwickeln, die Daten dort verarbeiten und analysieren wo sie entstehen – überall.
<G-vec00206-002-s270><compute.verarbeiten><en> Yes, one hell of a description, but the guys and girl compute a whole whack of different influences.
<G-vec00206-002-s270><compute.verarbeiten><de> Ja, das ist ein ziemlicher Brocken von einer Beschreibung, aber die Jungs und Madel verarbeiten eine ganze Menge verschiedener Einflusse.
<G-vec00206-002-s271><compute.verarbeiten><en> Determining how brain cells compute recognisable images in the higher visual cortex was one of the study’s initial steps.
<G-vec00206-002-s271><compute.verarbeiten><de> Einer der ersten Schritte der Studie bestand darin, zu bestimmen, wie Gehirnzellen im oberen visuellen Cortex Bilder von erkennbaren Objekten verarbeiten.
<G-vec00166-002-s038><compute.berechnen><en> If the no load speed is available along with voltage and current, Drive Calculator will compute the Kv based on that data, when you click the 'Save' button.
<G-vec00166-002-s038><compute.berechnen><de> Wenn die Leerlaufdrehzahl zusammen mit Leerlaufspannung und -strom angegeben wird, berechnet Drive Calculator die spezifische Drehzahl Kv aus diesen Daten, wenn du auf 'Speichern' klickst.
<G-vec00166-002-s039><compute.berechnen><en> The software will compute the sun's Azimuth and Altitude as a function of the time, date and location.
<G-vec00166-002-s039><compute.berechnen><de> Diese Software berechnet die Himmelsrichtung (Azimut) und die Erhebung (Altitude) der Sonne über dem Horizont in Abhängigkeit von Uhrzeit, Datum und Ort.
<G-vec00166-002-s040><compute.berechnen><en> Facts can be temporarily posted via the predicate post/1, the forward chaining engine will then compute the completion:?- post(a(1)), b(X).
<G-vec00166-002-s040><compute.berechnen><de> Fakten können temporär mittels dem Prädikat post/1 hinterlegt werden, die Machinerie der Vorwärtsverkettung berechnet dann den Abschluss:?- post(a(1)), b(X).
<G-vec00166-002-s041><compute.berechnen><en> If checked then Compute how much free disk space is needed to complete the Sync.
<G-vec00166-002-s041><compute.berechnen><de> Wenn aktiviert, berechnet wie viel freier Speicherplatz benötigt wird, um die Synchronisierung abzuschließen.
<G-vec00166-002-s042><compute.berechnen><en> Compute the logical or of two tuples.
<G-vec00166-002-s042><compute.berechnen><de> Berechnet die symmetrische Differenz von zwei Tupeln.
<G-vec00166-002-s043><compute.berechnen><en> The plot has 1,750 M2, currently has a buildability of 405 m2, can be built on 2 floors, the basement does not compute and can have up to 200 m2 additional.
<G-vec00166-002-s043><compute.berechnen><de> Das Grundstück hat 1.750 m2, hat derzeit eine Bebaubarkeit von 405 m2, kann auf 2 Etagen gebaut werden, der Keller nicht berechnet und kann bis zu 200 m2 zusätzlich haben.
<G-vec00166-002-s044><compute.berechnen><en> While a consensus on how to measure environmental impacts is slowly developing, views diverge on how to compute the ethical impacts of business activities.
<G-vec00166-002-s044><compute.berechnen><de> Während sich langsam eine Übereinstimmung darüber entwickelt, wie man Leistungseinflüsse mißt, gehen die Ansichten darüber auseinander, wie man ethische Einflüsse auf Geschäftstätigkeiten berechnet.
<G-vec00166-002-s045><compute.berechnen><en> If a tie point table is not specified, the tool will compute its own tie points and estimate the camera model.
<G-vec00166-002-s045><compute.berechnen><de> Wenn keine Verknüpfungspunkttabelle angegeben wird, berechnet das Werkzeug seine eigenen Verknüpfungspunkte und schätzt das Kameramodell.
<G-vec00166-002-s046><compute.berechnen><en> Compute the distance values for a rectified stereo image pair using multigrid methods.
<G-vec00166-002-s046><compute.berechnen><de> Berechnet die Disparität für ein rektifiziertes Bildpaar mit Hilfe von Korrelationsmethoden.
<G-vec00166-002-s047><compute.berechnen><en> "I didn't compute the forecast myself but only disseminated and explained it," the mathematician stresses.
<G-vec00166-002-s047><compute.berechnen><de> "Ich habe die Prognose nicht selbst berechnet, sondern sie nur verbreitet und erklärt", betont der Mathematiker.
<G-vec00166-002-s048><compute.berechnen><en> (see Data=>Compute Linear Correlation Coefficient). Create Norm Dataset
<G-vec00166-002-s048><compute.berechnen><de> Berechnet den linearen Korrelations-Koeffizienten und stellt den Wert als Text- Objekt dar (siehe Daten=>Korrelationskoeffizient).
<G-vec00166-002-s049><compute.berechnen><en> When required Labeljoy will compute the check digit regardless of what was input.
<G-vec00166-002-s049><compute.berechnen><de> Bei Bedarf berechnet Labeljoy die Prüfziffer unabhängig von der Eingabe.
<G-vec00166-002-s050><compute.berechnen><en> For our project ways2see we compute routes as well as descriptions of routes, and we present maps which are especially designed for people with visual impairment.
<G-vec00166-002-s050><compute.berechnen><de> Für ways2see beispielsweise werden Routen berechnet sowie Wegbeschreibungen und Karten erstellt, die speziell für Menschen mit Sehbeeinträchtigung oder Blindheit gestaltet sind.
<G-vec00166-002-s051><compute.berechnen><en> In this case, he must compute the number of claims fees due on the basis of the claims on file on expiry of the six-month period under Rule 161.
<G-vec00166-002-s051><compute.berechnen><de> Werden innerhalb dieser Nachfrist geänderte Ansprüche eingereicht, so werden die Anspruchsgebühren auf der Grundlage der geänderten Ansprüche berechnet.
<G-vec00166-002-s070><compute.bestimmen><en> Compute a projective transformation matrix between two images by finding correspondences between points.
<G-vec00166-002-s070><compute.bestimmen><de> Bestimmt eine projektive Transformationsmatrix automatisch durch Zuordnung von Punkten zwischen zwei Bildern.
<G-vec00166-002-s071><compute.bestimmen><en> Compute the distances of the points of one 3D object model to another 3D object model.
<G-vec00166-002-s071><compute.bestimmen><de> Bestimmt die Abstände der Punkte eines 3D-Objektmodells zu einem anderen 3D-Objektmodell.
