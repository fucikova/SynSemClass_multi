<G-vec00078-001-s057><accept.akzeptieren><en> send I accept the privacy policy.
<G-vec00078-001-s057><accept.akzeptieren><de> senden Ich akzeptiere die Datenschutzbestimmungen.
<G-vec00078-001-s058><accept.akzeptieren><en> strAcceptI am at least 18 years of age and accept the LINKAGB terms and conditionsLINKEND.
<G-vec00078-001-s058><accept.akzeptieren><de> strAcceptIch bin mindestens 18 Jahre alt und akzeptiere die LINKAGBAGB (Disclaimer)LINKEND.
<G-vec00078-001-s059><accept.akzeptieren><en> If you appreciate this guide, I accept Donations.
<G-vec00078-001-s059><accept.akzeptieren><de> Wenn du diese Anleitung hilfreich fandest, ich akzeptiere Spenden.
<G-vec00078-001-s060><accept.akzeptieren><en> * I confirm that I have read the terms and conditions of business and accept them.
<G-vec00078-001-s060><accept.akzeptieren><de> E-Mail * Ich bestätige, dass ich die AGB`s gelesen habe und sie akzeptiere.
<G-vec00078-001-s061><accept.akzeptieren><en> I understand and accept that under no circumstances will Extasy Webcam or any of its related, affiliated companies be liable for any direct, indirect, incidental, special, consequential or punitive damages that result from any false disclosures that may arise, violation of the rights of Subscribers, prostitution, pedophilia, child pornography, illegal abuse, exploitation or traffic of women and/or children.
<G-vec00078-001-s061><accept.akzeptieren><de> Ich verstehe und akzeptiere, dass unter keinen Umständen Free Cam Sex oder irgendeines seiner in Verbindung stehenden Vertragsfirmen haftet für jedweden direkten, indirekten, zufälligen, speziellen, Folge- oder ersatzpflichtigen Schaden, die aus jedweder eventuell auftretenden, falschen Offenlegung, Verletzung der Rechte der Abonnenten, Prostitution, Pädophilie, Kinderpornografie, illegalem Missbrauch, Ausbeutung oder Menschenhandel von Frauen und/oder Kindern resultieren.
<G-vec00078-001-s062><accept.akzeptieren><en> I hereby agree to receive the Hermle AG newsletter and hereby acknowledge and accept the information and explanations provided in the statement on data protection, in particular, the information outlined under the item
<G-vec00078-001-s062><accept.akzeptieren><de> "Ich willige hiermit ein, den Newsletter der Hermle AG zu erhalten und beachte und akzeptiere hiermit auch die Hinweise und Erläuterungen in der Datenschutzerklärung, insbesondere die Hinweise unter dem Punkt ""Newsletter""."
<G-vec00078-001-s063><accept.akzeptieren><en> I accept the Terms of WebMobil24.
<G-vec00078-001-s063><accept.akzeptieren><de> Ich akzeptiere die AGB von WebMobil24.
<G-vec00078-001-s064><accept.akzeptieren><en> Data protection requirements By sending this I accept the data protection provisions of Schüco International KG.
<G-vec00078-001-s064><accept.akzeptieren><de> Mit Versendung akzeptiere ich die Datenschutzbestimmungen der Schüco International KG.
<G-vec00078-001-s065><accept.akzeptieren><en> I have read and accept the Privacy Policy about Data Protection
<G-vec00078-001-s065><accept.akzeptieren><de> Ich habe die Datenschutzerklärung zum Datenschutz gelesen und akzeptiere sie.
<G-vec00078-001-s066><accept.akzeptieren><en> When pain and difficult feelings arise, take some deep breaths and say, “I do not enjoy what I am experiencing, but I accept that it is part of my life right now.”
<G-vec00078-001-s066><accept.akzeptieren><de> Wann immer du Schmerzen oder schwierige Gefühle empfindest, atme tief ein und sage dir selbst: Was ich gerade erlebe, macht mir keinen Spaß, aber ich akzeptiere, dass es nun Teil meines Lebens ist.
<G-vec00078-001-s067><accept.akzeptieren><en> I accept the data protection regulations and agree to the processing of my data.
<G-vec00078-001-s067><accept.akzeptieren><de> Ich akzeptiere die Datenschutzbestimmungen und stimme der Verarbeitung meiner Daten zu.
<G-vec00078-001-s068><accept.akzeptieren><en> After reading my book review, you will know which of Burger 's instinctotherapy approaches I don't accept and which I do.
<G-vec00078-001-s068><accept.akzeptieren><de> Nach dem Lesen meiner Buchbesprechung erkennen Sie, welche Ansätze ich bei Burger bei seiner Instinctotherapie nicht akzeptiere und welche schon.
<G-vec00078-001-s069><accept.akzeptieren><en> -I do not want to watch negative, I accept the disease and on her watch the smile.
<G-vec00078-001-s069><accept.akzeptieren><de> -Ich will nicht negativ sehen, Ich akzeptiere die Krankheit und auf ihr das Lächeln sehen.
<G-vec00078-001-s070><accept.akzeptieren><en> Don’t accept limitations of birth and death.
<G-vec00078-001-s070><accept.akzeptieren><de> Akzeptiere keine Grenzen durch Geburt und Tod.
<G-vec00078-001-s071><accept.akzeptieren><en> "(1) This Agreement shall come into effect by you clicking on the option ""I accept the discount terms"" below and choosing to register your Club free of charge with the Provider."
<G-vec00078-001-s071><accept.akzeptieren><de> "(1) Dieser Vertrag kommt zustande, indem Sie für Ihren Verein unten die Option ""Ich akzeptiere die Discountbedingungen"" anklicken und sich damit für eine Registrierung als Verein entscheiden."
<G-vec00078-001-s072><accept.akzeptieren><en> I hereby confirm that I have read and understood the Privacy Policy and the product registration terms and conditions and accept it.
<G-vec00078-001-s072><accept.akzeptieren><de> Hiermit bestätige ich, dass ich die Datenschutzerklärung mit den Bedingungen zur Produktregistrierung gelesen und verstanden habe und diese auch akzeptiere.
<G-vec00078-001-s073><accept.akzeptieren><en> I accept the terms and conditions of privacy and imprint .
<G-vec00078-001-s073><accept.akzeptieren><de> Ich akzeptiere die Datenschutzerklärun g und die Konditionen von Impressum .
<G-vec00078-001-s074><accept.akzeptieren><en> Yes, I accept the terms and conditions for Medialounge.
<G-vec00078-001-s074><accept.akzeptieren><de> Ja, ich akzeptiere die Nutzungsbedingungen des Medialounge.
<G-vec00078-001-s075><accept.akzeptieren><en> Yes, I have read the privacy policy and accept it.
<G-vec00078-001-s075><accept.akzeptieren><de> Ja, ich habe die Einwilligungserklärung Datenschutz gelesen und akzeptiere sie.
<G-vec00120-001-s065><accept.akzeptieren><en> I have read and accept the Privacy Policy about Data Protection
<G-vec00120-001-s065><accept.akzeptieren><de> Ich habe die Datenschutzerklärung zum Datenschutz gelesen und akzeptiere sie.
<G-vec00078-001-s076><accept.akzeptieren><en> Information regarding applying for accommodation will be sent to all students who firmly accept an offer of a place.
<G-vec00078-001-s076><accept.akzeptieren><de> Informationen in Bezug auf die Anwendung für die Unterkunft wird für alle Schüler gesendet werden, die fest ein Angebot eines Ortes akzeptieren.
<G-vec00078-001-s077><accept.akzeptieren><en> Fare gates do not accept cash, so make sure you have a Metrorail EASY Card or EASY Ticket ahead of time.
<G-vec00078-001-s077><accept.akzeptieren><de> Die Flugsteige akzeptieren kein Bargeld, also stellen Sie sicher, dass Sie vorab eine Metrorail EASY Karte oder ein EASY Ticket haben.
<G-vec00078-001-s078><accept.akzeptieren><en> Experience was definitely real It took me years to accept the reality of the experience and I am really hoping to come to terms with why it happened
<G-vec00078-001-s078><accept.akzeptieren><de> Erfahrung war definitiv real Ich brauchte Jahre um die Realität der Erfahrung zu akzeptieren und ich hoffe wirklich damit klarzukommen warum sie geschah.
<G-vec00078-001-s079><accept.akzeptieren><en> His declaration of love Jo ’ at the end of the episode confirms the goodness of his intentions and, above, He seems to have really ’ l heard and understood what the problem, but at this point I give for granted that Jo accept the proposal; of course there are the ’ atmosphere and spirit right to decide to marry.
<G-vec00078-001-s079><accept.akzeptieren><de> Seine Liebeserklärung an Jo ’ am Ende der Episode bestätigt die Güte seiner Absichten und, vor allen, Er scheint wirklich haben ’ l gehört und verstanden was das Problem, aber an dieser Stelle gebe ich für selbstverständlich, dass Jo akzeptieren den Vorschlag; Natürlich gibt es die ’ Atmosphäre und Geist richtig zu entscheiden, zu heiraten.
<G-vec00078-001-s080><accept.akzeptieren><en> Commentators urge the heads of government to accept the European Parliament's top candidate, stressing that the EU mustn't allow itself to be blackmailed by London.
<G-vec00078-001-s080><accept.akzeptieren><de> Kommentatoren drängen die Regierungschefs, den Favoriten des EU-Parlaments zu akzeptieren, und betonen, dass sich die EU nicht von London erpressen lassen darf.
<G-vec00078-001-s081><accept.akzeptieren><en> Banned countries are countries whose traffic IQ OPTION do not accept, or on whose territory it is forbidden to conduct advertising activities.
<G-vec00078-001-s081><accept.akzeptieren><de> Gebannt Länder sind Länder, deren Verkehr IQ OPTION nicht akzeptieren, oder auf dessen Gebiet es ist verboten, Werbeaktivitäten durchzuführen.
<G-vec00078-001-s082><accept.akzeptieren><en> You can even accept credit cards online (optional).
<G-vec00078-001-s082><accept.akzeptieren><de> Sie können sogar akzeptieren Kreditkarten online (optional).
<G-vec00078-001-s083><accept.akzeptieren><en> As I said as follows, without further specification, and that is that you, it is true that the good of the righteous act is acceptance of the gift of Grace and Mercy but without the pre-Divine motion (effective Grace) which it means that the will of man infallibly accept the Grace (while maintaining the freedom of being able to refuse), that Grace would be fruitless because of man (as it happens with the reprobate), as I said no such justification is expires in pseudo-Pelagianism so common among Catholics today.
<G-vec00078-001-s083><accept.akzeptieren><de> Wie gesagt wie folgt, ohne weitere Spezifizierung, und das ist, dass Sie, es stimmt, dass das Wohl der gerechten Tat ist die Annahme der Gabe der Gnade und Barmherzigkeit, aber ohne die vorge göttliche Bewegung (wirksame Gnade) was bedeutet es, dass der Wille des Menschen unfehlbar die Gnade akzeptieren (während die Freiheit der Lage zu verweigern), dass Gnade würde wegen des Menschen fruchtlos (wie es geschieht mit dem verworfenen), Da ich keine solche Rechtfertigung gesagt ist abläuft in pseudo-Pelagianism unter Katholiken so heute üblich.
<G-vec00078-001-s084><accept.akzeptieren><en> I don't think that there is a Palestinian who would accept that all this struggle would go, and all the years of our lives, not just ours, but those before us, so that in the end we would have a system of government that has taken the shape of a dictatorship.
<G-vec00078-001-s084><accept.akzeptieren><de> Ich glaube nicht, dass es einen Palästinenser gibt, der akzeptieren würde, dass dieser Kampf enden würde, und all die Jahre unseres Lebens, nicht nur unseres, sondern auch derer vor uns, so dass wir am Ende ein Regierungssystem haben, das die Form einer Diktatur angenommen hat.
<G-vec00078-001-s085><accept.akzeptieren><en> Upon prior agreement, we accept pets, provided that the pets’ owners undertake entire responsibility for any damage caused by their pets.
<G-vec00078-001-s085><accept.akzeptieren><de> Nach vorheriger Absprache akzeptieren wir Haustiere, sofern die Haustierbesitzer die gesamte Verantwortung für mögliche Schäden, die durch ihre Haustiere verursacht werden, übernehmen.
<G-vec00078-001-s086><accept.akzeptieren><en> By browsing our site you accept the use of these cookies.
<G-vec00078-001-s086><accept.akzeptieren><de> Wenn Sie weiterhin in unserer Website browsen, akzeptieren Sie die Verwendung dieser Cookies.
<G-vec00078-001-s087><accept.akzeptieren><en> The cat Lady Caroline did not want to accept me after one month yet and hissed loudly each time we met.
<G-vec00078-001-s087><accept.akzeptieren><de> "Die Katze ""Lady Caroline"" wollte mich nach einem Monat immer noch nicht akzeptieren und fauchte mich jedes Mal lautstark an, wenn wir uns begegneten."
<G-vec00078-001-s088><accept.akzeptieren><en> On the Certificate Store page, accept the default option Place all certificates in the following store (in the certificate store Trusted Root Certification Authorities), and then click Next.
<G-vec00078-001-s088><accept.akzeptieren><de> Akzeptieren Sie auf der Seite Zertifikatspeicher die Standardoption Alle Zertifikate in folgendem Speicher speichern (im Zertifikatspeicher Vertrauenswürdige Stammzertifizierungsstellen), und klicken Sie dann auf Weiter.
<G-vec00078-001-s089><accept.akzeptieren><en> All shop stewards should accept the authority of the union in respect of decisions, policies, and the constitution of the union.
<G-vec00078-001-s089><accept.akzeptieren><de> Alle Vertrauensleutemüssen die Autorität der Gewerkschaft in Bezug auf Entscheidungen, Politik und die Satzung der Gewerkschaft akzeptieren.
<G-vec00078-001-s090><accept.akzeptieren><en> We accept Euro, Swiss-Francs, British Pounds Sterling and US-Dollars.
<G-vec00078-001-s090><accept.akzeptieren><de> (Wir akzeptieren Euro, Schweizer Franken, Britische Pfund und US-Dollar).
<G-vec00078-001-s091><accept.akzeptieren><en> And it was essential to accept different nationalities, cultures and languages - giving living expression to European diversity in a mutual “European house”.
<G-vec00078-001-s091><accept.akzeptieren><de> Und es galt, unterschiedliche Nationalitäten und Kulturen und Sprachen zu akzeptieren – als lebendiger Ausdruck einer europäischen Vielfalt in einem gemeinsamen „europäischen Haus“.
<G-vec00078-001-s092><accept.akzeptieren><en> Bumble Zoosk This means that you have to add or accept contacts before being able to message.
<G-vec00078-001-s092><accept.akzeptieren><de> Bumble Zoosk Dies bedeutet, dass Sie neue Kontakte hinzufügen oder akzeptieren müssen, bevor Sie Nachrichten verschicken können.
<G-vec00078-001-s093><accept.akzeptieren><en> NOTE: It's easy to accept credit cards with the PayPal integration and Ecwid .
<G-vec00078-001-s093><accept.akzeptieren><de> HINWEIS: Es ist einfach, die Kreditkarten akzeptieren, mit der PayPal integration und Ecwid .
<G-vec00078-001-s094><accept.akzeptieren><en> This humanitarian cause is worth dying for, and the characters accept this.
<G-vec00078-001-s094><accept.akzeptieren><de> Diese humanitäre Sache ist es wert, dafür zu sterben, und die Charaktere akzeptieren dies.
<G-vec00120-001-s086><accept.akzeptieren><en> By browsing our site you accept the use of these cookies.
<G-vec00120-001-s086><accept.akzeptieren><de> Wenn Sie weiterhin in unserer Website browsen, akzeptieren Sie die Verwendung dieser Cookies.
<G-vec00078-001-s095><accept.akzeptieren><en> If you want to prevent cookies from being stored on your local unit, you need to change your browser settings to not accept cookies.
<G-vec00078-001-s095><accept.akzeptieren><de> Wenn Sie verhindern möchten, dass Cookies auf Ihrem Rechner gespeichert werden, müssen Sie Ihren Browser so einstellen, dass er keine Cookies akzeptiert.
<G-vec00078-001-s096><accept.akzeptieren><en> Important information Please note, this property does not accept arrivals after midnight.
<G-vec00078-001-s096><accept.akzeptieren><de> Wichtige Informationen Bitte beachten Sie, dass diese Unterkunft keine Ankünfte nach Mitternacht akzeptiert.
<G-vec00078-001-s097><accept.akzeptieren><en> Kalama Discourse Advice to Westerners on Choosing a Spiritual Path Faith Scriptures - the Tipitaka Scriptures - Other Collections Treatment of the Scriptures Do not accept any of my words on faith, Believing them just because I said them.
<G-vec00078-001-s097><accept.akzeptieren><de> "Die Ein Rat an westliche Leute, einen spirituellen Pfad zu gehen Kalama Belehrung Glaube Skripte – Der Tipitaka Der Umgang mit den Skripten ""Akzeptiert und glaubt meine Worte nicht nur deshalb, weil ich sie gesprochen habe."
<G-vec00078-001-s098><accept.akzeptieren><en> The LongJTAPI did not accept your destination address.
<G-vec00078-001-s098><accept.akzeptieren><de> LongJTAPI akzeptiert die von Ihnen gewünschte Zieladresse nicht.
<G-vec00078-001-s099><accept.akzeptieren><en> The fine print Please note that Cicek Palas Hotel does not accept bookings from non-married couples.
<G-vec00078-001-s099><accept.akzeptieren><de> Kleingedrucktes Bitte beachten Sie, dass das Cicek Palas Hotel keine Buchungen von unverheirateten Paaren akzeptiert.
<G-vec00078-001-s100><accept.akzeptieren><en> Tommy Hilfiger shoes for children - Official Tommy Hilfiger® Store Your browser currently is not set to accept Cookies.
<G-vec00078-001-s100><accept.akzeptieren><de> Tommy Hilfiger Schuhe für Kinder - Offizieller Tommy Hilfiger® Shop Ihr Browser akzeptiert keine Cookies.
<G-vec00078-001-s101><accept.akzeptieren><en> The Hotel doesn’t accept American Express like a payment method.
<G-vec00078-001-s101><accept.akzeptieren><de> American Express wird nicht als Zahlungsmittel akzeptiert.
<G-vec00078-001-s102><accept.akzeptieren><en> We will not accept scans of dated registration forms.
<G-vec00078-001-s102><accept.akzeptieren><de> Scans von Anmeldeformularen werden nicht akzeptiert.
<G-vec00078-001-s103><accept.akzeptieren><en> At any time, the user can set the browser to either accept all cookies or refuse them or disable their use by the Website.
<G-vec00078-001-s103><accept.akzeptieren><de> Der Benutzer hat jederzeit die Möglichkeit, in seinem Browser einzustellen, ob er alle Cookies akzeptiert, nur einige Cookies oder gar keine Cookies.
<G-vec00078-001-s104><accept.akzeptieren><en> Please note that the automatic check-in terminal does not accept cash payments.
<G-vec00078-001-s104><accept.akzeptieren><de> Bitte beachten Sie, dass das automatische Check-in-Terminal keine Barzahlungen akzeptiert.
<G-vec00078-001-s105><accept.akzeptieren><en> The general conditions of booking.com are accessible through the link below and are subject to acceptance just before booking online, Users of this service accept them without reservation.
<G-vec00078-001-s105><accept.akzeptieren><de> Der Nutzer dieses Dienstes akzeptiert sämtliche allgmeinen Geschäftsbedingungen von booking.com, die via untenstehendem Link zugänglich sind und denen er vor der Onlinereservierung zustimmen muss.
<G-vec00078-001-s106><accept.akzeptieren><en> The property will only accept credit cards under the same name as the guest on the reservation.
<G-vec00078-001-s106><accept.akzeptieren><de> Die Unterkunft akzeptiert nur Kreditkarten, die der Person gehören, die die Buchung vorgenommen hat.
<G-vec00078-001-s107><accept.akzeptieren><en> Royal Tulip Suzhou China (5*) - Suzhou, China It can only accept Mainland Chinese citizens.
<G-vec00078-001-s107><accept.akzeptieren><de> Royal Tulip Suzhou China (5*) - Suzhou, China Das Hotel akzeptiert nur chinesische Staatsbürger vom Festland.
<G-vec00078-001-s108><accept.akzeptieren><en> They only accept music in Lilypond format.
<G-vec00078-001-s108><accept.akzeptieren><de> Die Seite akzeptiert nur Beiträge im Lilypond-Format.
<G-vec00078-001-s109><accept.akzeptieren><en> Please note that the hotel does not accept third party credit cards unless authorized by Management and the credit card vendor.
<G-vec00078-001-s109><accept.akzeptieren><de> Bitte beachten Sie, dass dieses Hotel keine Kreditkarten Dritter akzeptiert, sofern dies nicht vom Management und vom Kreditkartenanbieter autorisiert wurde.
<G-vec00078-001-s110><accept.akzeptieren><en> 16.12 Should a time penalty be imposed and notified when the race leader has to complete 7 minutes or less of the scheduled race duration, it is up to the competitor concerned to take that penalty or, alternatively to the notified time penalty, to accept an additional time penalty of 30 seconds to be added to the elapsed time of his total time.
<G-vec00078-001-s110><accept.akzeptieren><de> 16.12 Wird eine Zeitstrafe zu einem Zeitpunkt verkündet, zu dem der Führende des Wertungslaufs nur noch 7 Minuten oder weniger der geplanten Dauer zu absolvieren hat, obliegt es dem betroffenen Teilnehmer, ob er die Strafe antritt oder anstelle einer verkündeten Zeitstrafe einen 30 Sekunden Zeitzuschlag zu seiner Gesamtfahrzeit akzeptiert.
<G-vec00078-001-s111><accept.akzeptieren><en> One must acknowledge that, throughout the years, the Debian project has become more and more demanding of the developers that it will accept.
<G-vec00078-001-s111><accept.akzeptieren><de> Zugegebenermaßen hat das Debian-Projekt im Laufe der Jahre an die Entwickler, die es akzeptiert, immer höhere Ansprüche gestellt.
<G-vec00078-001-s112><accept.akzeptieren><en> Please note that this property does not accept any hen or stag parties.
<G-vec00078-001-s112><accept.akzeptieren><de> Beachten Sie bitte, dass die Unterkunft keine Buchungen für Junggesellen- oder Junggesellinnenabschiede akzeptiert.
<G-vec00078-001-s113><accept.akzeptieren><en> The EU does not accept the U.S. justification of a national security threat.
<G-vec00078-001-s113><accept.akzeptieren><de> Die EU akzeptiert die Rechtfertigung der Maßnahmen auf Basis der Bedrohung der nationalen Sicherheit der USA nicht.
<G-vec00120-001-s101><accept.akzeptieren><en> The Hotel doesn’t accept American Express like a payment method.
<G-vec00120-001-s101><accept.akzeptieren><de> American Express wird nicht als Zahlungsmittel akzeptiert.
<G-vec00078-001-s133><accept.anerkennen><en> The Customer shall not be entitled to accept any such claims raised by third parties.
<G-vec00078-001-s133><accept.anerkennen><de> Die Organisation darf von sich aus die Ansprüche Dritter nicht anerkennen.
<G-vec00078-001-s134><accept.anerkennen><en> I will never accept such coercion although I will not openly oppose it so as not to use coercion Myself.
<G-vec00078-001-s134><accept.anerkennen><de> Einen solchen Willenszwang werde Ich nie und nimmer anerkennen, selbst wenn Ich nicht offen dagegen vorgehe, um eben wieder keinen Willenszwang auszuüben.
<G-vec00078-001-s135><accept.anerkennen><en> These actions are prohibited by law if you do not accept this License.
<G-vec00078-001-s135><accept.anerkennen><de> Diese Handlungen sind gesetzlich verboten, wenn Sie diese Lizenz nicht anerkennen.
<G-vec00078-001-s136><accept.anerkennen><en> We continue to call on Palestinians to end incitement against Israel, and we continue to emphasize that America does not accept the legitimacy of continued Israeli settlements. (Applause.)
<G-vec00078-001-s136><accept.anerkennen><de> Wir rufen die Palästinenser weiterhin dazu auf, die Aggression gegen Israel zu beenden und betonen weiterhin, dass die Vereinigten Staaten die Legitimität der fortgesetzten israelischen Besiedlung nicht anerkennen werden.
<G-vec00078-001-s137><accept.anerkennen><en> Both the government and the opposition have announced that they will accept the results of elections of this sort.
<G-vec00078-001-s137><accept.anerkennen><de> Regierung und Opposition des Landes hätten bereits angekündigt, das Ergebnis solcher Wahlen anerkennen zu wollen.
<G-vec00078-001-s138><accept.anerkennen><en> I tell you: these are the so-called believing Christians who sought their righteousness only in faith and did not want to really accept the love as if it would not have any value for eternal life.
<G-vec00078-001-s138><accept.anerkennen><de> Ich sage euch: das sind die sogenannten gläubigen Christen, welche in dem alleinigen Glauben die Rechtfertigung suchten und die Liebe nicht wohl anerkennen wollten, als tauge sie nichts fürs ewige Leben, sondern allein der Glaube.
<G-vec00078-001-s139><accept.anerkennen><en> ZIZIOULAS: For the future development of dialogue on this issue, it is of crucial importance that the Orthodox accept that primacy is part of the essence of the Church and not a matter of organization.
<G-vec00078-001-s139><accept.anerkennen><de> ZIZIOULAS: Für die zukünftige Entwicklung des Dialogs zu diesem Thema ist es überaus wichtig, daß die Orthodoxen anerkennen, daß der Primat Teil des Wesens der Kirche ist und keine Frage der Organisation.
<G-vec00078-001-s140><accept.anerkennen><en> The Association represents around 400 members, who accept the guidelines of and respect for the preservation of the cultural heritage in every field of their work, including preservation, examination, documentation, carrying out any treatment as well as education and professional advice.
<G-vec00078-001-s140><accept.anerkennen><de> Der Verein zählt etwa 400 Restauratoren als Mitglieder, welche die Achtung und Erhaltung des Kulturellen Erbes in jedem ihrer Fachgebiete als Grundsatz anerkennen, die Bewahrung, Untersuchung, Dokumentation, die Durchführung verschiedener Behandlungen sowie die Schulung und fachlichen Ratschläge miteingenommen.
<G-vec00078-001-s141><accept.anerkennen><en> If we accept the evolutionary idea, such a thing may have its place.
<G-vec00078-001-s141><accept.anerkennen><de> Wenn wir die evolutionäre Idee anerkennen, ist so etwas durchaus möglich.
<G-vec00078-001-s142><accept.anerkennen><en> People's attention should be drawn to their lifeless state, and thus living faith has to be preached all the time. They have to be advised that they may not call themselves believers as long as they only accept traditionally adopted spiritual knowledge without having made it their own, thus being able to uphold it with innermost conviction and not just with their mouth, and that this also necessitates intellectual contemplation.
<G-vec00078-001-s142><accept.anerkennen><de> Es sollen die Menschen aufmerksam gemacht werden auf ihren toten Zustand, und darum muss stets der lebendige Glaube gepredigt werden, es muss ihnen nahegelegt werden, daß sie sich nicht gläubig nennen dürfen, solange sie nur traditionell übernommenes Geistesgut anerkennen, jedoch nicht davon Besitz ergriffen haben, also es mit innerster Überzeugung, nicht nur mit dem Munde, vertreten können und daß dazu auch eine gedankliche Auseinandersetzung nötig ist.
<G-vec00078-001-s143><accept.anerkennen><en> The mere fact that you visit this web site implies that you know, understand and accept the Conditions for Use in the existing version at the time of access.
<G-vec00078-001-s143><accept.anerkennen><de> p>Ihr Zugriff auf diese Internetseite bedeutet, dass Sie die Nutzungsbedingungen in der im Augenblick des Zugriffs gültigen Version kennen, verstehen und anerkennen.
<G-vec00078-001-s144><accept.anerkennen><en> If you do not accept the amended or new Terms of Use you may not access, use or continue to use the Site or any of the services provided by Gaming Operator.
<G-vec00078-001-s144><accept.anerkennen><de> Wenn Sie die neuen oder geänderten Nutzungsbedingungen nicht anerkennen möchten, können Sie nicht oder nicht mehr auf die Website oder Leistungen des Spielbetreibers zugreifen.
<G-vec00078-001-s145><accept.anerkennen><en> The Principal will not accept any such claims spontaneously.
<G-vec00078-001-s145><accept.anerkennen><de> Der AG wird von sich aus solche Ansprüche nicht anerkennen.
<G-vec00078-001-s146><accept.anerkennen><en> Friedrich Wilhelm Otto denied this feud in a trial but finally had to accept it in 1845.
<G-vec00078-001-s146><accept.anerkennen><de> In einem Prozeß bestritt Friedrich Wilhelm Otto von der Decken die Lehnshoheit, des Herzogs, musste sie aber 1845 doch anerkennen.
<G-vec00078-001-s147><accept.anerkennen><en> In 1935, during the negotiations which were aimed at concluding the London Treaty on Naval Disarmament, he refused to accept the conditions of the Treaty which denied Japan naval parity with the United States and Great Britain.
<G-vec00078-001-s147><accept.anerkennen><de> Im Jahr 1935, während der Verhandlungen im Hinblick auf die Londoner Flottenkonferenz, weigerte er sich, die Bedingungen des Vertrags zu anerkennen, welcher Japan keine mit der USA und Großbritannien vergleichbare Flottenstärke zugestand.
<G-vec00078-001-s148><accept.anerkennen><en> As human beings, however, you cannot grasp the extent of the immense significance this act of Salvation has for you.... for each individual soul.... and you therefore have to ‘believe’ what you are told and accept the divine Saviour Jesus Christ without proof. Then you become free of your former guilt and once again place your trust in Me....
<G-vec00078-001-s148><accept.anerkennen><de> Als Mensch aber könnt ihr es nicht übersehen, welch große Bedeutung dieses Erlösungswerk für euch.... für eine jede einzelne Seele.... hat, und ihr müsset darum „glauben“, was euch darüber unterbreitet wird, und ohne Beweise den göttlichen Erlöser Jesus Christus anerkennen, dann entsühnet ihr auch dadurch eure einstige Schuld, ihr vertrauet euch wieder Mir....
<G-vec00078-001-s149><accept.anerkennen><en> Basically every religion will accept him as their messiah, but the Bible says that those who are saved will not be deceived by him.
<G-vec00078-001-s149><accept.anerkennen><de> Im Grunde wird jede Religion ihn als ihren Messias anerkennen, aber die Bibel sagt, dass diejenigen, die errettet sind, nicht von ihm getäuscht werden.
<G-vec00078-001-s150><accept.anerkennen><en> You are required to accept and sign the PSLive Terms of Use to sign up for a PSLive account.
<G-vec00078-001-s150><accept.anerkennen><de> Sie müssen die PSLive-Teilnahmebedingungen anerkennen und unterzeichnen, um ein PSLive-Konto zu erstellen.
<G-vec00078-001-s151><accept.anerkennen><en> Mr. Netanyahu, who was spying not only on the 5+1 negotiations, but also on the secret bilateral talks, reacted violently by publicly announcing that as long as he was alive, Israël would never accept the recognition of a Palestinian state.
<G-vec00078-001-s151><accept.anerkennen><de> Herr Netanjahu, der nicht nur die Verhandlungen 5 + 1 abhörte, sondern auch die geheimen bilateralen Gespräche, reagiert aufgebracht mit der öffentlichen Ankündigung, dass solange er lebe, Israel niemals einen palästinensischen Staat anerkennen würde.
<G-vec00078-001-s152><accept.annehmen><en> There are many different stock photo agencies and the types of content they are looking for and will accept will differ slightly from company to company.
<G-vec00078-001-s152><accept.annehmen><de> Es gibt viele verschiedene Stockfoto-Agenturen, und der Content, der gesucht und angenommen wird, ist von Unternehmen zu Unternehmen unterschiedlich.
<G-vec00078-001-s153><accept.annehmen><en> "Only those who accept the redeeming sacrifice of the crucified Son of God for our sins - thus those who have put on the ""wedding clothes"" and are delivered from their sins - may stay."
<G-vec00078-001-s153><accept.annehmen><de> "Nur wer das Loskaufopfer des gekreuzigten Sohnes Gottes für unsere Sünden angenommen - wer also das ""hochzeitliche Gewand"" angezogen hat und von seinen Sünden befreit ist - darf bleiben."
<G-vec00078-001-s154><accept.annehmen><en> Both the one and the other God intends for people and wants them to accept both of them.
<G-vec00078-001-s154><accept.annehmen><de> Beide sind von Gott für die Menschen gedacht und Er will, dass beide angenommen werden.
<G-vec00078-001-s155><accept.annehmen><en> No contract will come into force between you and us unless and until we accept your order in accordance with the procedure detailed below.
<G-vec00078-001-s155><accept.annehmen><de> Es tritt kein Vertrag zwischen Ihnen und uns in Kraft wenn und solange wir Ihre Bestellung nicht gemäß dem im Folgenden aufgeführten Vorgang angenommen haben.
<G-vec00078-001-s156><accept.annehmen><en> We were also happy to accept your invitation to the summit in Bucharest.
<G-vec00078-001-s156><accept.annehmen><de> Auch wir haben die Einladung zum Gipfel nach Bukarest gern angenommen.
<G-vec00078-001-s157><accept.annehmen><en> Also faced with tight budgets at schools, universities, museums and cultural centres, Finland is glad to accept the assistance provided by the German Academic Exchange Service (DAAD), the Educational Exchange Service (PAD), the Alexander von Humboldt Foundation and other cultural intermediaries. The DAAD has academic teachers working there, in Helsinki, Turku and Vaasa, and the PAD has one German language consultant.
<G-vec00078-001-s157><accept.annehmen><de> Die Fördermaßnahmen von DAAD (Deutscher Akademischer Austauschdienst) durch DAAD-Lektoren in Helsinki, Turku und Vaasa, PAD (Pädagogischer Austauschdienst) durch eine Fachberaterin, Alexander-von-Humboldt-Stiftung und anderen Mittlerorganisationen werden - angesichts der auch in Finnland bestehenden Sparzwänge bei Schulen, Hochschulen, Museen und Kulturzentren - gerne angenommen.
<G-vec00078-001-s158><accept.annehmen><en> But the others ‒ those who did not come to believe in Christ at that time ‒ are waiting, together with all people who have died since who did not accept Christ as their Savior, in a different part of the realm of the dead for the General Resurrection and the Last Judgment, where they will receive their sentence.
<G-vec00078-001-s158><accept.annehmen><de> Die Anderen aber, die damals nicht zum Glauben an Christus gekommen sind, warten gemeinsam mit allen seither verstorbenen Menschen, die Christus nicht als ihren Retter angenommen haben, im anderen Teil des Totenreichs auf die Allgemeinen Auferstehung und das Weltgericht, wo sie ihr Urteil empfangen werden.
<G-vec00078-001-s159><accept.annehmen><en> The team folder will only take effect after users you send the invitation to accept the invitation.
<G-vec00078-001-s159><accept.annehmen><de> Der Team-Ordner ist erst wirksam, nachdem Nutzer, denen Sie eine Einladung gesendet haben, diese angenommen haben.
<G-vec00078-001-s160><accept.annehmen><en> He said that not only did he not accept the book, he cursed at them.
<G-vec00078-001-s160><accept.annehmen><de> Er sagte, dass er nicht nur das Buch nicht angenommen habe, sondern sie sogar noch beschimpfte.
<G-vec00078-001-s161><accept.annehmen><en> Don't be afraid to make an offer if it's reasonable they will accept.
<G-vec00078-001-s161><accept.annehmen><de> Seien Sie nicht scheu, einfach ein Angebot zu machen, wenn das vernünftig ist, wird er sicher angenommen.
<G-vec00078-001-s162><accept.annehmen><en> If they do not accept before then, the invite will expire, and you will need to send another one.
<G-vec00078-001-s162><accept.annehmen><de> Wenn die Einladung in diesem Zeitraum nicht angenommen wird, läuft sie ab, und Sie müssen eine neue Einladung senden.
<G-vec00078-001-s163><accept.annehmen><en> In the daylight, you can accept it, But at the moment even LCD TVs offer better results.
<G-vec00078-001-s163><accept.annehmen><de> Bei Tageslicht kann angenommen werden, Aber im Moment auch LCD-TVs bieten bessere Ergebnisse.
<G-vec00078-001-s164><accept.annehmen><en> Accordingly sawed coconut shells are also suited, and many fish readily accept them; the edible flesh of the fruit must of course be removed entirely.
<G-vec00078-001-s164><accept.annehmen><de> Entsprechend zurechtgesägte Kokosnussschalen eignen sich ebenfalls gut und werden von vielen Fischen gerne angenommen; das Fruchtfleisch muss natürlich restlos entfernt werden.
<G-vec00078-001-s165><accept.annehmen><en> """I did not accept the Supervisory Board's offer to extend my contract for another three years,"" states Rainer Beaujean."
<G-vec00078-001-s165><accept.annehmen><de> """Ich habe das Angebot des Aufsichtsrats, meinen Vertrag für drei weitere Jahre zu verlängern, nicht angenommen"", sagte Rainer Beaujean."
<G-vec00078-001-s166><accept.annehmen><en> Afterwards, the offer can still be increased, reduced or cancelled entirely up to 28 hours prior to departure (provided that Luxair has not accept the offer yet).
<G-vec00078-001-s166><accept.annehmen><de> Danach kann das Angebot bis zu 28 Stunden vor Abflug noch erhöht, reduziert oder ganz storniert werden (sofern Luxair das Angebot noch nicht angenommen hat).
<G-vec00078-001-s167><accept.annehmen><en> His act of Salvation released you from all guilt providing you accept it voluntarily.
<G-vec00078-001-s167><accept.annehmen><de> Denn Sein Erlösungswerk hat euch frei gemacht von aller Schuld, aber es muss von euch freiwillig angenommen werden.
<G-vec00078-001-s168><accept.annehmen><en> Only those who accept the redeeming sacrifice of the crucified Son of God for our sins - thus those who have put on the “wedding clothes” and are delivered from their sins - may stay.
<G-vec00078-001-s168><accept.annehmen><de> Nur wer das Loskaufopfer des gekreuzigten Sohnes Gottes für unsere Sünden angenommen - wer also das „hochzeitliche Gewand” angezogen hat und von seinen Sünden befreit ist - darf bleiben.
<G-vec00078-001-s169><accept.annehmen><en> We will only accept payments with Visa and MasterCard if they are SET transactions (Secure Electronic Transactions).
<G-vec00078-001-s169><accept.annehmen><de> Zahlungen mit Visa oder Mastercard werden nur angenommen, wenn sie über SET (Secure Electronic Transaction) laufen.
<G-vec00078-001-s170><accept.annehmen><en> MICHAEL: Yes, itís definitely there to perceive and accept.
<G-vec00078-001-s170><accept.annehmen><de> MICHAEL: Ja, sie ist definitiv da, um erkannt und angenommen zu werden.
<G-vec00078-001-s190><accept.annehmen><en> Not in such a way that we call error truth, but in such a way that we accept them as they are, as human beings, and meet their needs.
<G-vec00078-001-s190><accept.annehmen><de> Nicht in einer Weise, dass wir Falsches wahr nennen, sondern sie als Menschen annehmen wie sie sind und ihren Bedürfnissen begegnen.
<G-vec00078-001-s191><accept.annehmen><en> Since he who wants truly be blessed by Me, must indeed accept My word wherein dwells all mercy, all light, all truth and all power, otherwise it would be impossible to award him any mercy.
<G-vec00078-001-s191><accept.annehmen><de> Denn wer von Mir tatsächlich gesegnet sein will, der muss Mein Wort, darin alle Gnade, alles Licht, alle Wahrheit und alle Macht wohnt, auch tatsächlich annehmen, ansonst es unmöglich wäre, ihm irgendeine Gnade zu erteilen.
<G-vec00078-001-s192><accept.annehmen><en> As the new Cardinals accept the burden of this office, I am confident that they will be supported by your constant prayers and your cooperation in their efforts to build up the Body of Christ in unity, holiness and peace.
<G-vec00078-001-s192><accept.annehmen><de> Während die neuen Kardinäle die Last ihres Amtes annehmen, vertraue ich darauf, daß sie die Unterstützung durch eure ständigen Gebete und eure Mitwirkung in ihren Bemühungen um den Aufbau des Leibes Christi in Einheit, Heiligkeit und Frieden erhalten werden.
<G-vec00078-001-s193><accept.annehmen><en> If the product's correct price at your order date is higher than the price stated on the Website, we will contact you for your instructions before we accept your order.
<G-vec00078-001-s193><accept.annehmen><de> Wenn der korrekte Preis des Produktes am Tag Ihrer Bestellung höher ist als der auf der Website angegebene Preis, werden wir Sie in Bezug auf die weiteren Schritte kontaktieren, bevor wir Ihre Bestellung annehmen.
<G-vec00078-001-s194><accept.annehmen><en> Having nothing but rice-water to give him, she asked him to go elsewhere, but the Elder showed his desire to accept her gift and refused alms offered to him by Sakka and by the inmates of the house behind which the woman lived.
<G-vec00078-001-s194><accept.annehmen><de> Da sie nichts hatte außer Reiswasser, bat sie ihn woanders hinzugehen, aber der Ältere gab ihr zu verstehen, dass er die Gabe annehmen möchte, nachdem er die Almosen von Sakka und den Bewohnern des Hauses, wo die Frau lebte, abgelehnt hatte.
<G-vec00078-001-s195><accept.annehmen><en> Neither the company nor its employees or agents is able to accept bookings for a specific building or a specific flat in a building; the company shall endeavour to provide any specific accommodation requested in writing by the guest but it cannot guarantee such accommodation will be available for the dates requested.
<G-vec00078-001-s195><accept.annehmen><de> Weder das Unternehmen noch seine Angestellten oder Vertreter können Buchungen für ein spezielles Gebäude oder eine spezielle Wohnung eines Gebäudes annehmen; das Unternehmen bemüht sich nach Kräften, schriftlich geäußerten Wünschen seitens der Gäste nach einer speziellen Unterkunft nachzukommen, kann die Verfügbarkeit dieser zu dem gewünschten Zeitraum jedoch nicht garantieren.
<G-vec00078-001-s196><accept.annehmen><en> Some conclusions: The natural sciences do not define human identity so diverse groups of people can accept scientific theories without feeling personally compromised.
<G-vec00078-001-s196><accept.annehmen><de> Einige Zusammenfassungen: Die Naturwissenschaften definieren nicht menschliche Identität, also können verschiedene Gruppen von Personen wissenschaftliche Theorien annehmen, ohne persönlich gekompromittiert zu glauben.
<G-vec00078-001-s197><accept.annehmen><en> Participants without an account can accept or refuse the meeting by clicking on an hyperlink in the notification e-mail.
<G-vec00078-001-s197><accept.annehmen><de> Teilnehmer ohne Benutzerkonto können den Termin annehmen oder ablehnen, indem sie auf den entsprechenden Link in der Benachrichtigungs-E-Mail klicken.
<G-vec00078-001-s198><accept.annehmen><en> This I say to all, who accept my word directly sent to you from above, so it is offered to them.
<G-vec00078-001-s198><accept.annehmen><de> Dies sage Ich zu allen, die Mein direkt aus der Höhe euch zugeleitetes Wort annehmen, so es ihnen angeboten wird.
<G-vec00078-001-s199><accept.annehmen><en> But I know every person's ability and willingness to love and thus also his degree of maturity.... I really also know best who is already so close to Me that I can accept him as My child.... Yet according to the law of eternity the soul has to be completely free of impurities, because the highest degree of beatitude, the childship to God, can only be reached on earth, because it is no longer possible for the soul in the spiritual kingdom to reach perfection, an ascent towards childship to God.... This is why the soul will still be offered the opportunity on earth to perfect itself, which a sorrowful and difficult earthly existence can achieve.
<G-vec00078-001-s199><accept.annehmen><de> Ich aber weiß um die Liebefähigkeit und Liebewilligkeit eines jeden Menschen und also auch um seinen Reifegrad.... Ich weiß es wahrlich auch am besten, wer Mir schon so nahesteht, daß Ich es als Mein Kind annehmen kann.... Doch laut Gesetz von Ewigkeit muss die Seele bei ihrem Ableben völlig schlackenlos sein, weil der höchste Grad der Glückseligkeit, die Gotteskindschaft, nur auf der Erde erreicht werden kann, weil für die Seele eine Vollendung im geistigen Reich, ein Aufsteigen zur Gotteskindschaft, nicht mehr in Frage kommt.... Darum wird der Seele noch auf Erden die Gelegenheit geboten, sich zu vollenden, was ein leidvolles und schweres Erdendasein zuwege bringen kann.
<G-vec00078-001-s200><accept.annehmen><en> In order to understand this, one has to accept the following basic principles: Human being is not a body, but consciousness (soul) that lives in the body and is temporarily connected with it.
<G-vec00078-001-s200><accept.annehmen><de> Um das zu verstehen, muss man folgende Grundsätze (Thesen) annehmen: Der verkörperte Mensch ist kein Körper, sondern ein Bewußtsein (die Seele), das im Körper lebt und vorübergehend mit dem Körper verbunden ist.
<G-vec00078-001-s201><accept.annehmen><en> If one is willing to accept the good from the hand of God one must also be willing to accept with thankfulness whatever may be difficult and painful.
<G-vec00078-001-s201><accept.annehmen><de> Man darf aus der Hand Gottes nicht nur das Gute annehmen wollen, sondern muss auch dankbar sein können für alles andere, so schwierig und schmerzlich es auch sein mag.
<G-vec00078-001-s202><accept.annehmen><en> We use these data in order to fulfil the contractual obligations existing between us and you (when you accept the regulations of the contests, games or random draws, and when you accept the conditions for using the loyalty programme).
<G-vec00078-001-s202><accept.annehmen><de> Wir verwenden diese Daten, um die zwischen uns und Ihnen bestehenden vertraglichen Verpflichtungen zu erfüllen (wenn Sie die Regeln der Wettbewerbe, Spiele oder Auslosungen akzeptieren und wenn Sie die Bedingungen zur Teilnahme am Treueprogramm annehmen).
<G-vec00078-001-s203><accept.annehmen><en> Sometimes it is fair to expect that a person will accept a particular task.
<G-vec00078-001-s203><accept.annehmen><de> Manchmal kann man erwarten, dass eine Person eine bestimmte Aufgabe annehmen wird.
<G-vec00078-001-s204><accept.annehmen><en> Accept SNMP packets from these hosts: Lists the SNMP hosts and SNMP management systems that can send SNMP requests to this SNMP host.
<G-vec00078-001-s204><accept.annehmen><de> SNMP-Pakete von diesen Hosts annehmen: Listet die SNMP-Hosts und SNMP-Verwaltungssysteme auf, die SNMP-Anforderungen an diesen SNMP-Host senden können.
<G-vec00078-001-s205><accept.annehmen><en> You can accept or reject an opponent until he/she wants to join the game.
<G-vec00078-001-s205><accept.annehmen><de> Sie können annehmen oder ablehnen, einen Gegner, bis er / sie will das Spiel einsteigen.
<G-vec00078-001-s206><accept.annehmen><en> """We are building an exchange system, in which members of social networks can offer their computing capacities and accept those of others,"" Caton says. He heads the Young Investigators Group developing the Social Cloud platform."
<G-vec00078-001-s206><accept.annehmen><de> """Wir bauen ein Austauschsystem, in dem Mitglieder sozialer Netzwerke ihre Rechenleistungen anbieten und die anderer annehmen können"", sagt Caton, der die Young Investigator Group leitet, welche die Plattform Social Cloud entwickelt."
<G-vec00078-001-s207><accept.annehmen><en> The seller can accept orders or purchase orders within 14 days of receipt.
<G-vec00078-001-s207><accept.annehmen><de> Bestellungen oder Aufträge kann der Verkäufer innerhalb von 14 Tagen nach Zugang annehmen.
<G-vec00078-001-s208><accept.annehmen><en> 3 Â Any third party, even the drawee, and any party already liable on the bill, with the exception of the acceptor, may accept or pay a bill of exchange for honour.
<G-vec00078-001-s208><accept.annehmen><de> 3 Jeder Dritte, auch der Bezogene, sowie jeder aus dem Wechsel bereits Verpflichtete, mit Ausnahme des Annehmers, kann einen Wechsel zu Ehren annehmen oder bezahlen.
<G-vec00078-001-s209><accept.annehmen><en> The City as the owner has wisely set up one of the cheaper fee machine which does not change and does not accept cards.
<G-vec00078-001-s209><accept.annehmen><de> Die Stadt als Betreiber hat wohlweislich einen der preiswerteren Gebührenautomaten aufgestellt, der nicht wechselt und keine Karten annimmt.
<G-vec00078-001-s210><accept.annehmen><en> 2 In the case of any member State which shall subsequently sign the Protocol without reservation in respect of ratification, acceptance or approval or which shall ratify, accept or approve it, the Protocol shall enter into force three months after the date of such signature or after the date of deposit of the instrument of ratification, acceptance or approval.
<G-vec00078-001-s210><accept.annehmen><de> 2 Für jeden Mitgliedstaat, der das Protokoll später ohne Vorbehalt der Ratifikation, Annahme oder Genehmigung unterzeichnet oder der es ratifiziert, annimmt oder genehmigt, tritt es drei Monate nach der Unterzeichnung oder der Hinterlegung der Ratifikations-, Annahme- oder Genehmigungsurkunde in Kraft.
<G-vec00078-001-s211><accept.annehmen><en> When we accept it it's as if it disappears and this enables us to see how much Jesus loves us and the price He paid for us.
<G-vec00078-001-s211><accept.annehmen><de> Wenn man es annimmt, ist es, als ob es verschwinde und man erfährt, wie sehr Jesus uns liebt und welchen Preis er für uns bezahlt hat.
<G-vec00078-001-s212><accept.annehmen><en> If you do not want your browser to accept cookies, you can deactivate or restrict this option in your browser settings.
<G-vec00078-001-s212><accept.annehmen><de> Wenn Sie nicht wollen, dass Ihr Browser Cookies annimmt, können Sie diese Möglichkeit in den Browser-Einstellungen deaktivieren oder einschränken.
<G-vec00078-001-s213><accept.annehmen><en> You can prevent cookies from being saved on your end device by setting your browser to not accept cookies.
<G-vec00078-001-s213><accept.annehmen><de> Sie können das Speichern von Cookies auf Ihrem Gerät verhindern, indem Sie den Browser so einstellen, dass er keine Cookies annimmt.
<G-vec00078-001-s214><accept.annehmen><en> When humanity will accept the affirmation of Infinity, destiny will reveal itself not as a punishment but as a cosmic expansion.
<G-vec00078-001-s214><accept.annehmen><de> Sobald die Menschheit die Bestätigung der Unbegrenztheit annimmt, wird sich das Schicksal nicht als Strafe, sondern als kosmische Ausweitung enthüllen.
<G-vec00078-001-s215><accept.annehmen><en> Anyone who fails to accept this redeeming sacrifice for his sins in faith will not be able to appeal to the so-called unconditional love of God – let alone “the identity of the Jewish people” – but will be judged in accordance with the justice of God and will not see God’s kingdom.
<G-vec00078-001-s215><accept.annehmen><de> "Wer dieses Loskaufopfer für seine Sünden nicht im Glauben annimmt, kann sich weder auf eine unendliche noch auf eine bedingungslose Liebe Gottes - geschweige denn auf ""die Identität des jüdischen Volkes"" - berufen, sondern er wird nach der Gerechtigkeit Gottes verurteilt und das Reich Gottes nicht sehen."
<G-vec00078-001-s216><accept.annehmen><en> In case the Islamic world should not accept the challenge, it might get isolated completely and starved out as the Soviet Union was, having to admit its bankruptcy in the end.
<G-vec00078-001-s216><accept.annehmen><de> Für den Fall, dass die islamische Welt die Herausforderung nicht annimmt, droht ihr völlige Isolierung und damit eine Art Aushungern, wie es die Sowjetunion erlebt hat, mit dem Bankrott am Ende.
<G-vec00078-001-s217><accept.annehmen><en> The configuration of such a service is more complicated: you first install the vnc4server package, change the configuration of the display manager to accept XDMCP Query requests (for gdm3, this can be done by adding Enable=true in the “xdmcp” section of /etc/gdm3/daemon.conf), and finally, start the VNC server with inetd so that a session is automatically started when a user tries to login.
<G-vec00078-001-s217><accept.annehmen><de> Die Konfiguration eines derartigen Dienstes ist komplizierter: zunächst installieren Sie das Paket vnc4server, passen die Konfiguration des Display Managers dahingehend an, dass er Anfragen an XDMCP Query annimmt (für gdm3 kann dies durch Hinzufügen von Enable=true im Abschnitt “xdmcp” von /etc/gdm3/daemon.conf) und starten schließlich den VNC-Server mit inetd, so dass eine Sitzung automatisch beginnt, wenn ein Benutzer sich anzumelden versucht.
<G-vec00078-001-s218><accept.annehmen><en> - dispatchers can see the suggestion from the optimization and they can decide to accept or reject it.
<G-vec00078-001-s218><accept.annehmen><de> - der Disponent sieht die Empfehlung der Optimierung/automatischen Disposition und entscheidet ob er die Empfehlung annimmt.
<G-vec00078-001-s219><accept.annehmen><en> Possible discrepancies and difficulties will be resolved by tirelessly seeking what unites everyone, with patient and sincere dialogue, and a willingness to listen and accept goals which will bring new hope.
<G-vec00078-001-s219><accept.annehmen><de> Die eventuellen Unstimmigkeiten und Schwierigkeiten sind dadurch zu lösen, daß man unermüdlich sucht, was alle verbindet, und zwar in einem geduldigen und aufrichtigen Dialog, in gegenseitigem Verständnis und mit einem aufrichtigen Willen des Zuhörens, der Ziele annimmt, die neue Hoffnungen mit sich bringen.
<G-vec00078-001-s220><accept.annehmen><en> Please note: The property can only accept major credit cards and will not accept ATM cards or cash as a payment.
<G-vec00078-001-s220><accept.annehmen><de> Bitte beachten Sie, dass die Unterkunft nur die gängigsten Kreditkarten annimmt und keine Geldkarten oder Barzahlungen akzeptiert.
<G-vec00078-001-s221><accept.annehmen><en> Wait for your friend to accept the invitation.
<G-vec00078-001-s221><accept.annehmen><de> Warten Sie, bis Ihr Freund die Einladung annimmt.
<G-vec00078-001-s222><accept.annehmen><en> They can choose to accept or decline the challenge.
<G-vec00078-001-s222><accept.annehmen><de> Clan B kann sich nun entscheiden, ob er die Herausforderung annimmt oder ablehnt.
<G-vec00078-001-s223><accept.annehmen><en> The play pauses while the opposing team decide whether to give up or to accept the increased stake.
<G-vec00078-001-s223><accept.annehmen><de> Das Spiel wird unterbrochen, und das gegnerische Team entscheidet, ob es aufgibt oder den erhöhten Einsatz annimmt.
<G-vec00078-001-s224><accept.annehmen><en> Scripture excludes not a single human person from the possibility of salvation, but leaves every individual the free decision whether to accept this offer of God's or to refuse it.
<G-vec00078-001-s224><accept.annehmen><de> Die Schrift schließt keinen einzigen Menschen von der Möglichkeit zur Errettung aus, sondern lässt jedem Menschen die freie Entscheidung, ob er dieses Angebot Gottes annimmt oder ablehnt.
<G-vec00078-001-s225><accept.annehmen><en> It is all the more fruitful if you just accept this FACT, that is, YOU HAVE BEEN CREATED FOR LOVE, NAMELY FOR UNCREATED LOVE!
<G-vec00078-001-s225><accept.annehmen><de> Es nützt viel mehr, wenn ihr diese TATSACHE annimmt, das heißt, dass ihr zu LIEBE GESCHAFFEN SEID, UND ZWAR ZU UNGESCHAFFENEN LIEBE.
<G-vec00078-001-s226><accept.annehmen><en> An episcopal commission can be charged with preparing the catechetical material, even on a permanent basis, but always respecting the right of the Episcopal Conference as a whole to decide whether or not to accept it and, as far as national catechisms are concerned, whether or not to present them to the Holy See for approval.
<G-vec00078-001-s226><accept.annehmen><de> - Eine bischöfliche Kommission kann auch auf Dauer beauftragtwerden, das katechetische Material vorzubereiten, wobei immer das Recht der Bischofskonferenz in Ihrer Gesamtheit gewahrt bleibt, zu entscheiden, ob sie es annimmt oder nicht und ob sie, wenn es sich um nationale Katechismen handelt, diese zur Approbation dem Heiligen Stuhl vorlegt oder nicht.
<G-vec00078-001-s227><accept.annehmen><en> If the tax authority does not accept the arguments and adopts its first-instance decision, an appeal can be submitted at the same tax authority within 15 days, or in the case of an ex post tax assessment, within 30 days.
<G-vec00078-001-s227><accept.annehmen><de> Falls die Steuerbehörde unsere Argumente nicht annimmt und ihren erstinstanzlichen Beschluss fällt, kann innerhalb von 15 Tagen (bei nachträglicher Steuerfestsetzung innerhalb von 30 Tagen) bei der erstinstanzlichen Behörde eine Berufung erhoben werden.
<G-vec00078-001-s228><accept.anerkennen><en> In 1988, however, the PLO decided that it would accept the existence of Israel.
<G-vec00078-001-s228><accept.anerkennen><de> 1988 jedoch beschloss die PLO, die Existenz Israels anzuerkennen.
<G-vec00078-001-s229><accept.anerkennen><en> The demoniac person may not agree to accept the supremacy of the Lord, and it is a fact that he may act according to his own whims, but his next birth will depend upon the decision of the Supreme Personality of Godhead and not on himself.
<G-vec00078-001-s229><accept.anerkennen><de> Der dämonische Mensch mag nicht damit einverstanden sein, die Oberhoheit des Herrn anzuerkennen, und es ist auch eine Tatsache, daß er nach seinen eigenen Launen handeln mag, doch seine nächste Geburt wird von der Entscheidung der Höchsten Persönlichkeit Gottes abhängen, nicht von seiner eigenen.
<G-vec00078-001-s230><accept.anerkennen><en> The film relates the story of an elderly couple which refuses to accept their own physical and mental deterioration.
<G-vec00078-001-s230><accept.anerkennen><de> Der Film erzählt die Geschichte eines alternden Paares, das sich weigert, seinen körperlichen und geistigen Verfall anzuerkennen.
<G-vec00078-001-s231><accept.anerkennen><en> It is easier if one clearly feels them to be outside forces and foreign to oneself; but even if you cannot feel that yet when they enter, still the mind must keep that idea and refuse to accept them as any longer a part of the nature.
<G-vec00078-001-s231><accept.anerkennen><de> Es ist leichter, wenn man deutlich fühlt, dass es sich um äußere Kräfte handelt, die nicht zu einem gehören; aber auch wenn du das bei ihrem Eindringen noch nicht zu fühlen vermagst, muss dennoch das Mental diesen Grundgedanken aufrechterhalten und sich weigern, sie weiterhin als Teil der Natur anzuerkennen.
<G-vec00078-001-s232><accept.anerkennen><en> Marginalization strategy presupposes the renunciation of some cultural roots and at the same time inability to take root in another culture and accept new norms, values and settings.
<G-vec00078-001-s232><accept.anerkennen><de> Marginalisierungsstrategie setzt die Ablehnung einiger kultureller Wurzeln sowie das gleichzeitige Unvermögen voraus, in einer anderen Kultur Fuß zu fassen und die neuen Normen, Werte und Einstellungen anzuerkennen.
<G-vec00078-001-s233><accept.anerkennen><en> He who accepts the class struggle cannot fail to accept civil wars, which in every class society are the natural, and under certain conditions inevitable, continuation, development and intensification of the class struggle.
<G-vec00078-001-s233><accept.anerkennen><de> Wer den Klassenkampf anerkennt, der kann nicht umhin, auch Bürgerkriege anzuerkennen, die in jeder Klassengesellschaft eine natürliche, unter gewissen Umständen unvermeidliche Weiterführung, Entwicklung und Verschärfung des Klassenkampfes darstellen.
<G-vec00078-001-s234><accept.anerkennen><en> "Dirk Schumer is thus entirely correct, for example, when he states, in his article ""Modern Slavery"" (FAZ – English edition, March 28, 2001), that for long-standing historical as well as more recent economic and political reasons, Poland may find it difficult to accept new and more rigid borders with Lithuania and Ukraine."
<G-vec00078-001-s234><accept.anerkennen><de> "Dirk Schumer zum Beispiel hat also völlig Recht, wenn er in seinem Artikel ""Modern Slavery"" in der englischen Ausgabe der FAZ im März 2001 feststellt, dass Polen es sowohl aus bereits lang bestehenden historischen als auch aus neueren wirtschaftlichen und politischen Gründen vielleicht schwierig finden wird, neue und starrere Grenzen zu Litauen und der Ukraine anzuerkennen."
<G-vec00078-001-s235><accept.anerkennen><en> It is good to accept and reward him, and confer titles of prestige on him.
<G-vec00078-001-s235><accept.anerkennen><de> Es ist von Wert, ihn zu entlohnen und anzuerkennen und ihm den Anspruch auf Ansehen zuzugestehen.
<G-vec00078-001-s236><accept.anerkennen><en> the insured person is not authorised to totally or partially accept a liability claim or to settle or satisfy such a claim without prior consent of the insurer.
<G-vec00078-001-s236><accept.anerkennen><de> Die versicherte Person ist nicht berechtigt, ohne vorherige Zustimmung des Versicherers einen Haftpflichtanspruch ganz oder zum Teil oder vergleichsweise anzuerkennen oder zu befriedigen.
<G-vec00078-001-s237><accept.anerkennen><en> Geyer found it hard to accept those prophetic calls and to follow the Apostle Preuss.
<G-vec00078-001-s237><accept.anerkennen><de> Geyer fiel es schwer, diese Rufung anzuerkennen und dem Apostel Preuß nachzufolgen.
<G-vec00078-001-s238><accept.anerkennen><en> Precisely because this is a mysterious reality that surpasses our understanding, we must not be surprised if today too many find it hard to accept the Real Presence of Christ in the Eucharist.
<G-vec00078-001-s238><accept.anerkennen><de> Gerade weil es sich um eine geheimnisvolle Wirklichkeit handelt, die unser »Verstehen« übersteigt, dürfen wir uns nicht wundern, wenn auch heute viele Menschen Mühe haben, die wirkliche Gegenwart Christi in der Eucharistie anzuerkennen.
<G-vec00078-001-s239><accept.anerkennen><en> Because God is a gentleman, He will not force us to love or accept Him.
<G-vec00078-001-s239><accept.anerkennen><de> Weil Gott von vornehmer Art ist, wird Er uns nicht zwingen, Ihn zu lieben oder anzuerkennen.
<G-vec00078-001-s240><accept.anerkennen><en> Mr. Song refused to accept the sentence and proposed an appeal, which was unreasonably rejected.
<G-vec00078-001-s240><accept.anerkennen><de> Er lehnte es jedoch ab, die Strafe anzuerkennen und reichte ein Bittgesuch ein, welches unangemessen zurückgewiesen wurde.
<G-vec00078-001-s241><accept.anerkennen><en> I believe that some political pressures are evident in the excerpt of the Report, but it will not be necessary for the reader to share my notions regarding the specific manifestations of these pressures in the excerpt in order to accept the major conclusion that I draw from the excerpt.
<G-vec00078-001-s241><accept.anerkennen><de> Ich glaube, daß in diesem Auszug aus dem Bericht ein gewisser politischer Druck offensichtlich ist, aber es wird für den Leser nicht notwendig sein, meine Empfindungen im Hinblick auf besondere Bekundungen dieses Drucks in dem Auszug zu teilen, um die Hauptfolgerung anzuerkennen, die ich aus diesem Auszug ziehe.
<G-vec00078-001-s242><accept.anerkennen><en> "Rami Hamdallah, prime minister of the national consensus government, said it reflects the broad international support to accept ""Palestine"" as an independent state."
<G-vec00078-001-s242><accept.anerkennen><de> "Laut dem Premierminister der Regierung der Nationalen Einheit, Rami Hamdallah, reflektiert der Schritt die große internationale Bereitschaft, ""Palästina"" als unabhängigen Staat anzuerkennen."
<G-vec00078-001-s243><accept.anerkennen><en> In this context, many artists today are protesting against growing nationalistic tendencies and refusing to accept state-propagated versions of cultural history as their own.
<G-vec00078-001-s243><accept.anerkennen><de> Viele Künstler verwahren sich in diesem Zusammenhang gegen einen aufflammenden Nationalismus und die Versuchung, Formen eines staatlich diktierten kulturellen Gedächtnisses als das ihre anzuerkennen.
<G-vec00078-001-s244><accept.anerkennen><en> Because of the ever more general conviction that the apparitions are authentic, and especially because of the exceptional spiritual gifts to the whole world in regard to the apparitions, it was, nevertheless, compelled to accept Medjugorje as a shrine and to take on itself greater care for a correct development of devotion and adequate provision for the spiritual needs of pilgrims in Medjugorje.
<G-vec00078-001-s244><accept.anerkennen><de> Aufgrund der immer generelleren Ueberzeugung, dass die Erscheinungen echt seien, besonders wegen der außerordentlichen geistigen Gabe für die ganze Welt, wurde sie gedraengt, Medjugorje als Heiligtum anzuerkennen und sich mehr Sorge um eine richtige Entfaltung der Froemmigkeit zu nehmen, und einen geeigneten Vorschlag für die geistigen Notwendigkeiten der Pilger in Medjugorje zu machen.
<G-vec00078-001-s245><accept.anerkennen><en> "Â MYTH ""Unlike the Jews, the Arabs were willing to accept the internationalization of Jerusalem."""
<G-vec00078-001-s245><accept.anerkennen><de> "Behauptung ""Die Araber waren bereit, den internationalen Status von Jerusalem anzuerkennen, doch die Juden lehnten den Vorschlag ab."
<G-vec00078-001-s246><accept.anerkennen><en> It's a kind of refusal – a refusal to accept a certain method of knowing that isn't the purely material method, and a negation of the experience, of the reality of the experience – how can they be convinced of it?...
<G-vec00078-001-s246><accept.anerkennen><de> Es ist die Weigerung, eine gewisse Wissensbasis anzuerkennen, die von der rein materiellen abweicht, und eine Verneinung der Erfahrung, der Wirklichkeit der Erfahrung – wie kann man sie davon überzeugen?...
<G-vec00078-001-s247><accept.annehmen><en> I Myself have certainly shared an abundance of knowledge on earth, yet I also knew My listeners’ hearts, I was aware of their degree of love, their will and their realisation of My Personality which made them accept the knowledge they were offered as the only truth.
<G-vec00078-001-s247><accept.annehmen><de> Ich Selbst habe wohl auf Erden Wissen in Fülle ausgeteilt, doch Ich kannte auch die Herzen Meiner Zuhörer, Ich wußte um ihren Liebegrad, ihren Willen und um die Erkenntnis Meiner Person, die Meine Zuhörer veranlaßte, das ihnen gebotene Wissen als alleinige Wahrheit anzunehmen.
<G-vec00078-001-s248><accept.annehmen><en> The card warns of overestimating one's capabilities, demands humility and asks us to accept help.
<G-vec00078-001-s248><accept.annehmen><de> Die Acht der Münzen mahnt auch vor Selbstüberschätzung und fordert zu Bescheidenheit und dazu, Hilfe anzunehmen auf.
<G-vec00078-001-s249><accept.annehmen><en> The problem with human relationships, especially in the families, and the relationship one has toward oneself, is to accept the others the way that they are and oneself the way that one is.
<G-vec00078-001-s249><accept.annehmen><de> Das Problem mit menschlichen Beziehungen, besonders in den Familien und mit der Beziehung zu sich selbst liegt darin, die anderen anzunehmen, wie sie sind und sich selbst, so wie man ist.
<G-vec00078-001-s250><accept.annehmen><en> This pledge to service illustrated by Issaias send me is a commitment to accept whatever the office asks of one in terms of sacrifice to the point of persecution, torture, martyrdom.
<G-vec00078-001-s250><accept.annehmen><de> "Wenn man das Gelübde ablegt, sich in den Dienst zu stellen (Jesaias ""Sende mich""), verspricht man, alles anzunehmen, was der Dienst an Opfern verlangt, bis hin zu Verfolgtwerden, Marter und Märtyrertum."
<G-vec00078-001-s251><accept.annehmen><en> We reserve the right to accept or refuse applications without justification.
<G-vec00078-001-s251><accept.annehmen><de> Wir behalten uns das Recht vor, jede Bewerbung ohne weitere Erklärung anzunehmen oder abzulehnen.
<G-vec00078-001-s252><accept.annehmen><en> At the end of his emotional address, he thanked Chief Apostle Helper Jean-Luc Schneider for his willingness to accept this new commission.
<G-vec00078-001-s252><accept.annehmen><de> Am Ende seiner emotionalen Ansprache dankte er dem Stammapostelhelfer Jean-Luc Schneider für dessen Bereitschaft, den Auftrag anzunehmen.
<G-vec00078-001-s253><accept.annehmen><en> The family of the company’s founder, Carsten Maschmeyer, also supports the bid and has committed to accept the offer for 20% of the share capital.
<G-vec00078-001-s253><accept.annehmen><de> Auch die Familie des Unternehmensgründers Maschmeyer unterstützt das Angebot und hat sich unwiderruflich verpflichtet, es für 20% des Aktienkapitals anzunehmen.
<G-vec00078-001-s254><accept.annehmen><en> Although the four major religious founders thoroughly reveal the contents they learned in these seminars, since they are invisible to the eyes of earthly people, they cannot readily accept it as real.
<G-vec00078-001-s254><accept.annehmen><de> Auch wenn die vier Gründer der großen Weltreligionen ihnen gründlich die Inhalte offenbaren, die sie hier in diesen Seminaren gelernt haben, ist es sehr schwierig für die Menschen auf Erden, das bereitwillig anzunehmen, weil sie es nicht selbst sehen können.
<G-vec00078-001-s255><accept.annehmen><en> but now follows (22: 22-34) the story of the ass, with which God's anger at the refusal of the seer to accept His answer, given once and for all, is manifested.
<G-vec00078-001-s255><accept.annehmen><de> aber nun folgt (22: 22-34) die Geschichte vom Esel, mit der sich Gottes Ärger über die Weigerung des Sehers, seine ein für alle Mal gegebene Antwort anzunehmen, manifestiert.
<G-vec00078-001-s256><accept.annehmen><en> It is a free gift. I need only to accept it.
<G-vec00078-001-s256><accept.annehmen><de> Das ist ein freies Geschenk, das ich nur anzunehmen brauche.
<G-vec00078-001-s257><accept.annehmen><en> It only remains for us now to accept this offer on God’s part.
<G-vec00078-001-s257><accept.annehmen><de> An uns liegt es nun nur mehr, dieses Angebot Gottes anzunehmen.
<G-vec00078-001-s258><accept.annehmen><en> While as a boy he still rebelled against it, after a while he not only comes to accept his role, but also makes use of the independence from social conventions that goes with it. Thus he becomes the unerring logician and observer, the audience has loved for so long because of his unique perspective and – even more – his deadpan punch lines.
<G-vec00078-001-s258><accept.annehmen><de> Während er als Junge noch gegen diese Rolle aufbegehrte, lernt er mit der Zeit nicht nur sie anzunehmen, sondern auch die damit einhergehende Unabhängigkeit von Konventionen zu nutzen und wird so zu jenem unbestechlichen Logiker und Beobachter, den die Zuschauer seiner so originellen Perspektiven und mehr noch der trockenen Pointen wegen schon immer liebten.
<G-vec00078-001-s259><accept.annehmen><en> Directing our analysis toward the appearances that we see and the feelings they elicit, we try to accept ourselves as we actually were then.
<G-vec00078-001-s259><accept.annehmen><de> Wir richten unsere Analyse auf die Erscheinungen, die wir sehen, und die Empfindungen, die sie auslösen, und versuchen uns selbst so anzunehmen, wie wir damals waren.
<G-vec00078-001-s260><accept.annehmen><en> I speak to people Myself, and use for this a willing instrument which serves me knowingly and allows My direct action on and within him.... because I do not impose My will on humanity but it should freely decide whether to accept My Word or not....
<G-vec00078-001-s260><accept.annehmen><de> Ich Selbst spreche die Menschen an, und Ich nütze dazu ein williges Werkzeug, das bewußt Mir dienet und Mein direktes Wirken an und in ihm zuläßt.... weil Ich die Menschheit keinem Willenszwang aussetze, sondern sie sich frei entscheiden soll, Meine Ansprache anzunehmen oder nicht....
<G-vec00078-001-s261><accept.annehmen><en> Begin to ask to be shown how to deal with life situations, the problems which other humans present and the challenge to accept where a person is in relation to where you are.
<G-vec00078-001-s261><accept.annehmen><de> Fangt an zu fragen, damit euch gezeigt wird, wie mit Lebenssituationen umzugehen ist, den Problemen, die andere Menschen darstellen, und die Herausforderung anzunehmen, wo eine Person in Beziehung zu dem steht, wo ihr seid.
<G-vec00078-001-s262><accept.annehmen><en> In Kenya, a team is using a well established IofC-developed method called the Clean Election Campaign to inspire a critical mass of people to commit themselves to neither give nor accept bribes during elections, and to vote on the basis of character rather than tribal allegiance.
<G-vec00078-001-s262><accept.annehmen><de> "In Kenia arbeitet ein Team mit der inzwischen gut eingespielten IofC-Methode der sogenannten ""Clean Election Campaign"" (Kampagne für saubere Wahlen"") daran, kritische Menschen dazu anzuregen, ein Versprechen abzulegen, in Wahlkampfkampagnen weder Bestechungsgelder anzunehmen noch zu geben und eher dem Charakter der Kandidaten entsprechend zu wählen anstatt nach Stammeszugehörigkeit."
<G-vec00078-001-s263><accept.annehmen><en> We are entitled to accept such a contractual offer within two weeks after receipt of the order.
<G-vec00078-001-s263><accept.annehmen><de> Wir sind berechtigt, das in der Bestellung liegende Vertragsangebot innerhalb von zwei Wochen nach Eingang bei uns anzunehmen.
<G-vec00078-001-s264><accept.annehmen><en> To the extent that they have an authentic personal experience of Christ, they will be able to accept generously the requirement of the gift of themselves to God and to others and will give themselves in the humble and disinterested service of charity.
<G-vec00078-001-s264><accept.annehmen><de> In dem Maße wie sie wirklich persönlich Christus erfahren, werden sie auch in der Lage sein, die Forderung nach Selbsthingabe an Gott und an die Mitmenschen hochherzig anzunehmen und sie im demütigen und selbstlosen Liebesdienst umzusetzen.
<G-vec00078-001-s265><accept.annehmen><en> But the receiver would not allow herself to accept the generosity of her friend.
<G-vec00078-001-s265><accept.annehmen><de> Die Empfängerin konnte sich jedoch nicht selbst erlauben die Großzügigkeit ihrer Freundin anzunehmen.
<G-vec00078-001-s266><accept.aufnehmen><en> We cannot accept any more in the seminary because we have no more places to send them to carry out their priestly service, and we cannot help in other churches outside of our country, given that most of them join their priestly life with married life and are thus precluded from Eastern lands.
<G-vec00078-001-s266><accept.aufnehmen><de> Wir können in den Seminaren keine weiteren Kandidaten aufnehmen, weil wir nicht wissen, wohin wir sie anschließend zum priesterlichen Dienst schicken sollen, und wir können mit ihnen auch nicht anderen Kirchen außerhalb unseres Landes aushelfen, da die Mehrheit von ihnen ihr Priestertum mit dem Ehestand verbindet, weshalb ihnen die Länder des Westens verschlossen sind.
<G-vec00078-001-s267><accept.aufnehmen><en> Whether you're passing through Oban on the way to the Islands, or staying for a couple of days and exploring historic and beautiful Argyll, the original Oban Backpackers is the place for you!Our funky hostel is part of the World famous 'Scotland's Top Hostels' chain and we look forward to welcoming you to Oban.As our accommodation is comprised of dorm rooms, we can only accept families with children if the whole room has been booked for sole occupancy.
<G-vec00078-001-s267><accept.aufnehmen><de> Egal, ob Sie auf dem Weg zu den Inseln durch Oban fahren oder ein paar Tage bleiben und das historische und wunderschöne Argyll erkunden, das Original Oban Backpackers ist der richtige Ort für Sie!Unser funky Hostel ist Teil der weltberühmten 'Scotland's Top Hostels' Kette und wir freuen uns darauf, Sie in Oban begrüßen zu dürfen.Da es sich bei unserer Unterkunft um Schlafsäle handelt, können wir nur Familien mit Kindern aufnehmen, wenn das ganze Zimmer zur alleinigen Belegung gebucht wurde.
<G-vec00078-001-s268><accept.aufnehmen><en> She remains perseverant and patient even when we do not have faith in her and accept her superficially.
<G-vec00078-001-s268><accept.aufnehmen><de> Sie bleibt hartnäckig und geduldig, auch wenn wir ihr nicht glauben und sie oberflächlich aufnehmen.
<G-vec00078-001-s269><accept.aufnehmen><en> It will also accept up to 32 individual 0,2 ml tubes.
<G-vec00078-001-s269><accept.aufnehmen><de> Er kann auch bis zu 32 einzelne 0,2 ml PCR-Röhrchen aufnehmen.
<G-vec00078-001-s270><accept.aufnehmen><en> Indeed, the confrontation with the West can fundamentally change the situation in Russia, in all social strata and above all in the upper class, which will not only understand but feel first-hand that the Western elite will never accept them in their circles, and sooner or later they will be devoured up.
<G-vec00078-001-s270><accept.aufnehmen><de> Tatsächlich kann eine Konfrontation mit dem Westen die Situation in Russland grundlegend ändern, und zwar in allen sozialen Schichten, vor allem aber in der Oberschicht, die nicht nur verstehen, sondern am eigenen Leib spüren wird, dass die westliche Elite sie niemals in ihre Kreise aufnehmen wird, sondern dass sie ganz im Gegenteil früher oder später von ihr gefressen wird.
<G-vec00078-001-s271><accept.aufnehmen><en> The labour camp authorities refused to accept him, and the National Security Bureau agents then took Li Zhen to a hospital for a physical exam.
<G-vec00078-001-s271><accept.aufnehmen><de> Das Arbeitslager wollte Li Zhen nicht aufnehmen, woraufhin ihn die Agenten des nationalen Sicherheitsbüros zu einer Untersuchung in ein Krankenhaus brachten.
<G-vec00078-001-s272><accept.aufnehmen><en> Although Angela Merkel has not been able to stand up for herself with her proposal to cut funding to member states that refuse to accept refugees, she can rely on the European Commission and in particular on the German Commissioner for Budget and Human Resources Günther Oettinger.
<G-vec00078-001-s272><accept.aufnehmen><de> Zwar konnte sich Angela Merkel mit ihrem Vorschlag, die EU-Förderung für Mitgliedstaaten einzuschränken, die keine Flüchtlinge aufnehmen wollen, nicht richtig durchsetzen, doch auf die EU-Kommission, insbesondere auf den für Haushalt zuständigen deutschen Kommissar, Günther Oettinger, kann sich die Bundeskanzlerin verlassen.
<G-vec00078-001-s273><accept.aufnehmen><en> "Say: ""I want my hands to be polarized from the great store of Nature, where great Wisdom and Love are hidden, so that I could accept them, I could accept Good – the uniting link, that serves to all the people on Earth."""
<G-vec00078-001-s273><accept.aufnehmen><de> Sagt folgendes:Von der großen Schatzkammer der Natur, wo sich so viel Weisheit und Liebe verbirgt, lasse ich meine Hände polarisieren, ich will die Weisheit und die Liebe aufnehmen, das Gute aufnehmen und die Verbindung, die alle Menschen der Erde vereinigt.
<G-vec00078-001-s275><accept.aufnehmen><en> Temporarily, we can not accept any new alumni job profiles.
<G-vec00078-001-s275><accept.aufnehmen><de> Temporär können wir leider keine neuen Alumni-Stellenprofile aufnehmen.
<G-vec00078-001-s276><accept.aufnehmen><en> Instead, we are called to accept God into our life, to lose ourselves in Him, to savour His Love, His peace, His mercy, and thus to know Him.
<G-vec00078-001-s276><accept.aufnehmen><de> Dieses Kennen wäre hingegen Gott in unser Leben aufnehmen, sich in Ihn verlieren, um Seine Liebe, Seinen Frieden, Seine Barmherzig-keit auszukosten.
<G-vec00078-001-s277><accept.aufnehmen><en> And whoever shall accept one such little child in my name, accepts me.
<G-vec00078-001-s277><accept.aufnehmen><de> und wer irgend ein solches Kindlein aufnehmen wird in meinem Namen, nimmt mich auf.
<G-vec00078-001-s278><accept.aufnehmen><en> A person with the will to live a good life, thus to live according to God’s will, is never left without spiritual guidance, he will be guided, his thoughts will be directed, i.e., although his freedom of will is not being curtailed, the thoughts will come so close to him that he has to accept them if he does not consciously reject them.
<G-vec00078-001-s278><accept.aufnehmen><de> Der Mensch, der den Willen hat, gut, also dem Willen Gottes gemäß, zu leben, wird niemals ohne geistigen Beistand gelassen, er wird geführt, sein Denken wird gelenkt, d.h., die Willensfreiheit wird ihm zwar nicht beschnitten, aber die Gedanken treten ihm so greifbar nahe, daß er sie aufnehmen muss, so er sich nicht bewußt abwendet von ihnen.
<G-vec00078-001-s279><accept.aufnehmen><en> 23:1 Thou shalt not accept a false report; extend not thy hand to the wicked, to be an unrighteous witness.
<G-vec00078-001-s279><accept.aufnehmen><de> 23:1 Du sollst kein falsches Gerücht aufnehmen; du sollst deine Hand nicht dem Gesetzlosen reichen, um ein ungerechter Zeuge zu sein.
<G-vec00078-001-s280><accept.aufnehmen><en> Operation is subject to the following two conditions: (1) This device may not cause harmful interference, and (2) this device must accept any interference received, including interference that may cause undesired operation.
<G-vec00078-001-s280><accept.aufnehmen><de> Der Betrieb ist nur zulässig, wenn die folgenden beiden Bedingungen erfüllt sind: (1) Dieses Gerät darf keine schädlichen Interferenzen erzeugen und (2) Dieses Gerät muss empfangene Interferenzen aufnehmen, auch wenn diese zu Betriebsstörungen führen können.
<G-vec00078-001-s281><accept.aufnehmen><en> · Anyone (whether an Austrian citizen or not) who resides in Austria – or in the absence of a permanent residence, has a habitual abode in Austria – and has filed a job placement application with the AMS, and is available to take a job (essentially, anyone who is practically and legally able to accept employment immediately and is fit and willing to work), irrespective of whether they are drawing benefits under the Unemployment Insurance Law, or whether they are already employed.
<G-vec00078-001-s281><accept.aufnehmen><de> Alle Personen (österreichische Staatsbürgerinnen wie nicht-österreichische StaatsbürgerInnen), die ihren Wohnsitz - oder mangels eines solchen ihren ständigen Aufenthaltsort - in Österreich haben, dem AMS einen Arbeitsvermittlungsauftrag erteilt haben, der Arbeitsvermittlung zur Verfügung stehen (das sind im wesentlichen Personen, die sofort eine Beschäftigung aufnehmen können und dürfen sowie arbeitsfähig und arbeitswillig sind), unabhängig davon, ob sie eine Leistung nach dem Arbeitslosenversicherungsgesetz beziehen oder nicht, und unabhängig davon, ob sie beschäftigt sind.
<G-vec00078-001-s282><accept.aufnehmen><en> It was decided to end this nuisance by finally welcoming all contributors, regardless of the nature of their contribution into the heart of the Debian Project and invite the Debian Account Managers to establish procedures to evaluate and accept non-packaging contributors.
<G-vec00078-001-s282><accept.aufnehmen><de> Wir haben uns entschieden, diesem Ärger ein Ende zu setzen, indem wir endlich sämtliche Unterstützenden, unabhängig von der Natur ihrer Beiträge in das Herz des Debian-Projekts geholt und die Debian-Kontenführer eingeladen haben, Prozeduren zum Bewerten und Aufnehmen von nicht programmierenden Helferinnen und Helfern zu entwickeln.
<G-vec00078-001-s283><accept.aufnehmen><en> Those who accept His Word are righteous, even though they were previously sinners.
<G-vec00078-001-s283><accept.aufnehmen><de> Alle werden gerecht, die Gottes Wort aufnehmen, obgleich sie Sünder waren.
<G-vec00078-001-s284><accept.aufnehmen><en> The hall Strossmayer is equipped with the highest esthetical and technical criteria and can accept up to 50 participants.
<G-vec00078-001-s284><accept.aufnehmen><de> Der Saal Strossmayer ist nach den höchsten ästhetischen und technischen Kriterien eingerichtet und kann bis zu 50 Teilnehmer aufnehmen.
<G-vec00078-001-s285><accept.aufnehmen><en> You were truly granted an extensive period of time in order to achieve this change of will and nature, yet one day even the longest space of time comes to an end, and you are facing this end.... I cannot arbitrarily shape you such that you can enter eternal life, you must lend a hand yourselves, for it is always My will to accept you into My kingdom, My will would never reject your will if it desires to reach Me, just as it once turned away from Me and pulled you into the abyss.... Worlds will vanish before the last spiritual being has accomplished this transformation of will.... Nevertheless, My love wants to help you humans so that you will not remain distant from Me for eternities to come, so that you will not remain for eternities in a material form, which either keeps your will bound or, as a human being, gives you the final opportunity to reach your goal of uniting yourselves with Me again....
<G-vec00078-001-s285><accept.aufnehmen><de> Es ist euch wahrlich eine umfassende Zeitspanne zugebilligt worden, um diese Willens- und Wesenswandlung zu erreichen, doch einmal nimmt auch die längste Zeit ihr Ende, und vor diesem Ende stehet ihr.... Ich kann euch nicht willkürlich so gestalten, daß ihr zum ewigen Leben eingehen könnet, ihr müsset selbst Hand anlegen an euch, ihr müsset wollen, denn Mein Wille ist jederzeit, euch aufzunehmen in Mein Reich, Mein Wille wird niemals sich eurem Willen entgegenstellen, wenn dieser zu Mir verlangt, wie er sich einstmals abwandte von Mir und euch in die Tiefe riß....
<G-vec00078-001-s286><accept.aufnehmen><en> Today I call on all energy and environment ministers of the member states and neighbouring countries, to demonstrate their focus and foresight in using this momentum to accept and support ambitious agreements also in Europe's neighbourhood policy.
<G-vec00078-001-s286><accept.aufnehmen><de> Heute appelliere ich an alle Energie- und Umweltminister der Mitglieds- und Nachbarstaaten, mit Augenmerk, aber auch Weitsicht dieses Momentum zu nutzen und anspruchsvolle Vereinbarungen auch in der europäischen Nachbarschaftspolitik aufzunehmen und zu unterstützen.
<G-vec00078-001-s287><accept.aufnehmen><en> May the Virgin Mary, model of docility and obedience to the Word of God, teach you to accept ever better the inexhaustible riches of Sacred Scripture, not only through intellectual research but also in your lives as believers, so that your work and your action may contribute to making the light of Sacred Scripture shine ever brighter before the faithful.
<G-vec00078-001-s287><accept.aufnehmen><de> Die Jungfrau Maria, Vorbild an Gefügigkeit und Gehorsam gegenüber dem Wort Gottes, lehre euch, den unerschöpflichen Reichtum der Heiligen Schrift immer besser aufzunehmen, nicht nur durch die intellektuelle Forschung, sondern auch in eurem Leben als Gläubige, damit eure Arbeit und euer Wirken dazu beitragen können, vor den Gläubigen immer mehr das Licht der Heiligen Schrift erstrahlen zu lassen.
<G-vec00078-001-s288><accept.aufnehmen><en> The application manager has the power to decline applying players or to accept them into the alliance through the Diplomacy → Apps page.
<G-vec00078-001-s288><accept.aufnehmen><de> Der Application Manager hat die Macht, sich bewerbende Spieler abzulehnen oder in die Allianz aufzunehmen, durch die Diplomacy → Apps Seite.
<G-vec00078-001-s289><accept.aufnehmen><en> The establishment of the academy, equipped with a boarding school, provides the opportunity to accept students from around the world.
<G-vec00078-001-s289><accept.aufnehmen><de> Die Gründung der mit einem Internat ausgestatteten Akademie schafft die Möglichkeit, Schüler aus aller Welt aufzunehmen.
<G-vec00078-001-s290><accept.aufnehmen><en> They drove to a detention centre, but the detention centre refused to accept Ms. Chen because of her health.
<G-vec00078-001-s290><accept.aufnehmen><de> Sie wurden zu einer Haftanstalt gebracht, aber die Beamten der Haftanstalt weigerten sich, Frau Chen in ihrem schlechten Gesundheitszustand aufzunehmen.
<G-vec00078-001-s291><accept.aufnehmen><en> The prison refused to accept him in such poor physical condition.
<G-vec00078-001-s291><accept.aufnehmen><de> Das Gefängnis weigerte sich jedoch, ihn in einer so schlechten körperlichen Verfassung aufzunehmen.
<G-vec00078-001-s292><accept.aufnehmen><en> restrict behavioral ads; social networks links to connect with others while playing; option to accept push notifications to inform of exciting news e.g.
<G-vec00078-001-s292><accept.aufnehmen><de> B. Einschränkung verhaltensbezogener Werbung, Links zu sozialen Netzwerken, um beim Spielen Kontakt zu anderen Spielern aufzunehmen; die Option, Push-Benachrichtigungen zu erhalten, die über aufregende Neuigkeiten informieren, z.
<G-vec00078-001-s293><accept.aufnehmen><en> Reintex does not accept and record personal data from persons below the age of 14.
<G-vec00078-001-s293><accept.aufnehmen><de> Die Reintex beabsichtigt nicht, von Personen unter 14 Jahren Daten aufzunehmen, zu erfassen.
<G-vec00078-001-s294><accept.aufnehmen><en> She conceived Jesus by the work of the Holy Spirit, and every Christian, each one of us, is called to accept the Word of God, to accept Jesus inside of us and then to bring him to everyone.
<G-vec00078-001-s294><accept.aufnehmen><de> Sie hat Jesus durch das Wirken des Heiligen Geistes empfangen, und jeder Christ, jeder von uns, ist dazu berufen, das Wort Gottes aufzunehmen, Jesus in sich aufzunehmen und ihn dann zu allen zu bringen.
<G-vec00078-001-s295><accept.aufnehmen><en> Moreover the Virgin Mary is also the teacher of this prayer because no one has been able better than Mary to contemplate Jesus with a gaze of faith and to accept in his or her heart the deep resonance of his human and divine presence.
<G-vec00078-001-s295><accept.aufnehmen><de> Die Jungfrau Maria ist Lehrerin auch dieses Gebets, da es keiner mehr und besser verstanden hat als sie, Jesus mit dem Blick des Glaubens zu betrachten und im Herzen das innerste Mitschwingen seiner menschlichen und göttlichen Gegenwart aufzunehmen.
<G-vec00078-001-s296><accept.aufnehmen><en> This presentation is a demonstration tournament, formulated to support a new format for the IOC to accept Billiards as an additional Sport for inclusion into the programme of the 2024 Olympic Games in Paris.
<G-vec00078-001-s296><accept.aufnehmen><de> Dies ist ein Demonstrationsturnier in einem Format, welches das Ziel hat, Billard in das Programm der Olympischen Spiele 2024 in Paris aufzunehmen.
<G-vec00078-001-s297><accept.aufnehmen><en> On top of this heinous crime came the refusal of the imperialist Allies to accept Jewish refugees.
<G-vec00078-001-s297><accept.aufnehmen><de> Zu diesem abscheulichen Verbrechen kam die Ablehnung der imperialistischen Alliierten, jüdische Flüchtlinge aufzunehmen.
<G-vec00078-001-s298><accept.aufnehmen><en> Those who accept this truth and are prepared to accept Wisdom, receive it as a gift.
<G-vec00078-001-s298><accept.aufnehmen><de> Wer diese Wahrheit akzeptiert und sich vorbereitet, um die Weisheit aufzunehmen, der empfängt sie als Geschenk.
<G-vec00078-001-s299><accept.aufnehmen><en> "According to the Australian Church, since that of refugees is a global phenomenon on the rise, ""the developed countries are called to accept the care for refugees, without measures that inflict harm and suffering""."
<G-vec00078-001-s299><accept.aufnehmen><de> "Angesichts der globalen Tragweite des Flüchtlingsproblems, so der Bischof abschließend, ""sind Industriestaaten berufen Flüchtlinge aufzunehmen, ohne Maßnahmen zu ergreifen, die ihnen Schaden und Leid zufügen""."
<G-vec00078-001-s300><accept.aufnehmen><en> France also has been very reluctant to accept North African mass refugee flows - taught by the many riots they organize.
<G-vec00078-001-s300><accept.aufnehmen><de> Auch Frankreich ist sehr unwillig gewesen, die nordafrikanischen Massen-Flüchtlingsströme aufzunehmen - belehrt von den vielen Krawallen, die sie veranstalten.
<G-vec00078-001-s301><accept.aufnehmen><en> After that, the implant is able to accept permanently the functional load of a prosthetic restoration as a support and/or fixation element.
<G-vec00078-001-s301><accept.aufnehmen><de> Danach ist das Implantat in der Lage, die funktionelle Belastung einer prothetischen Versorgung als Stütz- und/oder Verankerungselement dauerhaft aufzunehmen.
<G-vec00078-001-s302><accept.aufnehmen><en> If they were given a right to refuse in these exceptional cases, the result would be that such persons would probably have no access at all to private health insurance, because no undertaking would be prepared to accept them.
<G-vec00078-001-s302><accept.aufnehmen><de> Ein Ablehnungsrecht in diesen Ausnahmefällen hätte zur Folge, dass solchen Personen der Zugang zur privaten Krankenversicherung voraussichtlich gänzlich verschlossen wäre, weil sich kein Unternehmen bereiterklären würde sie aufzunehmen.
<G-vec00078-001-s303><accept.aufnehmen><en> "After 20 centuries of history, the Church, ""pillar and bulwark of the truth"" (1 Tm 3:15), feels called more than ever to accept God's plan for humanity, to hear the voice raised from the different societies, cultures and civilizations of the whole world, and to perceive their deepest needs so that she might serve them."
<G-vec00078-001-s303><accept.aufnehmen><de> Nach zwanzig Jahrhunderten der Geschichte fühlt sich die Kirche, »die die Säule und das Fundament der Wahrheit ist« (1 Tim 3,15), mehr denn je gerufen, den Plan Gottes mit der Menschheit aufzunehmen, die Stimme zu hören, die sich aus den verschiedenen Gesellschaften, den Kulturen und den Zivilisationen der ganzen Welt erhebt, ihre tiefsten Bedürfnisse zu erfassen, um sich in ihren Dienst zu stellen.
<G-vec00078-001-s342><accept.empfangen><en> Believing in themselves and hard work in 1978 the couple Marija and Sime were brave enough to accept into their home first tourists and they did not make a mistake.
<G-vec00078-001-s342><accept.empfangen><de> Selbstvertrauen und harte Arbeit hat dem Ehepaar Marija und ©ime Mut gegeben 1978. in ihrem Haus die ersten Touristen zu empfangen, und sie machten keinen Fehler.
<G-vec00078-001-s343><accept.empfangen><en> The restaurant is able to accept 210 persons with a terrace, and 160 persons without a terrace.
<G-vec00078-001-s343><accept.empfangen><de> Das Restaurant kann 210 Personen mit Terrasse, 160 Personen ohne Terrasse empfangen.
<G-vec00078-001-s344><accept.empfangen><en> When you accept an investment request, this information becomes visible for you and vice versa.
<G-vec00078-001-s344><accept.empfangen><de> Wenn Sie das Geld investieren oder die Investitionen empfangen, werden Sie die Kontaktinformationen der Gegenpartei automatisch erhalten, und umgekehrt.
<G-vec00078-001-s345><accept.empfangen><en> We accept groups of up to 30 people.
<G-vec00078-001-s345><accept.empfangen><de> Wir empfangen bis zu 30 Personen gleichzeitig.
<G-vec00078-001-s346><accept.empfangen><en> Let us be content to accept men and women on the basis of the gospel which they profess and preach, rather than on the basis of the denomination or tradition from which they have come.
<G-vec00078-001-s346><accept.empfangen><de> Lasst uns zufrieden sein, Männer und Frauen zu empfangen, auf Grundlage des Evangeliums das sie bekennen und predigen, anstatt auf Grundlage der Konfession oder der Tradition von denen sie abstammen.
<G-vec00078-001-s347><accept.empfangen><en> Thus, trading one account, traders can not only accept investments in their PAMM projects, but also provide their trades for copying within the ForexCopy system.
<G-vec00078-001-s347><accept.empfangen><de> So kann der Trader nicht nur in sein PAMM-Projekt Investitionen empfangen, sondern auch seine Geschäfte im Rahmen des ForexCopy-Systems kopieren lassen.
<G-vec00078-001-s348><accept.empfangen><en> They are already working on that and I can say here that we are prepared to accept 250 students a year from the United States' Third World.
<G-vec00078-001-s348><accept.empfangen><de> Sie befassen sich mit dieser Aufgabe, und von hier aus kann ich bekräftigen, daß wir bereit sind, 250 Studenten pro Jahr aus der US-amerikanischen Dritten Welt zu empfangen (Beifall).
<G-vec00078-001-s349><accept.empfangen><en> And he asked “Our Lady for the grace of meekness, humility and goodness, which really safeguard our heart, in order not to let the Lord pass, in order not to accept in vain the gift, the grace, that the Lord gives us”.
<G-vec00078-001-s349><accept.empfangen><de> Vor allem aber forderte er dazu auf, »die Muttergottes um die Gnade der Sanftmut, der Demut, der Güte zu bitten, die unser Herz so gut behüten, damit wir den Herrn nicht vorübergehen lassen, damit wir das Geschenk, die Gnade nicht vergebens empfangen, die uns der Herr schenkt«.
<G-vec00078-001-s350><accept.empfangen><en> Let us ask ourselves – it will do us good – if we are prepared to accept God’s gifts, or prefer instead to shut ourselves up within our forms of material security, intellectual security, the security of our plans.
<G-vec00078-001-s350><accept.empfangen><de> Fragen wir uns – es wird uns gut tun –, ob wir bereit sind, die Gaben Gottes zu empfangen, oder ob wir es lieber vorziehen, uns auf unsere materiellen Sicherheiten, auf unsere intellektuellen Gewissheiten oder auf die Gewähr unserer Planungen zurückzuziehen.
<G-vec00078-001-s351><accept.empfangen><en> She knows that not everyone will believe and accept her messages and God s love which is manifested today through her presence.
<G-vec00078-001-s351><accept.empfangen><de> Sie weiß, dass nicht alle ihre Botschaften und Gottes Liebe, die sich durch ihre Gegenwart offenbart, empfangen werden.
<G-vec00078-001-s352><accept.empfangen><en> Your response will determine your entire experience of life, and how willing you are to accept everything God intends for you.
<G-vec00078-001-s352><accept.empfangen><de> Ihre Antwort wird die Erfahrung Ihres ganzen Lebens prägen und Ihre Bereitschaft, alles zu empfangen, was Gott für Sie bereitet hat.
<G-vec00078-001-s353><accept.empfangen><en> Israel was called to accept and to live out God's law as a particular gift and sign of its election and of the divine Covenant, and also as a pledge of God's blessing.
<G-vec00078-001-s353><accept.empfangen><de> Israel war dazu berufen, das Gesetz Gottes als besonderes Geschenk und Zeichen der Erwählung und des göttlichen Bundes und zugleich als Gewähr für den Segen Gottes zu empfangen und zu leben.
<G-vec00078-001-s354><accept.empfangen><en> For a Late Check-In every beginning hour will be charged with 15 € if QBE Mobile Hotels chooses to accept guests after regular Check-In hours.
<G-vec00078-001-s354><accept.empfangen><de> Für einen Late Check-In werden pro angefangener Stunde 15 € berechnet, wenn Qbe Mobile Hotels entscheidet Gäste noch nach den Check-In Zeiten zu empfangen.
<G-vec00078-001-s355><accept.empfangen><en> The apartments in the high attic (A5 and a6) can be joined in the necessary and as such can accept up to 6 members.
<G-vec00078-001-s355><accept.empfangen><de> Die Apartments im Dachgeschoss (A5 und a6) können miteinander verbunden werden und so die Gruppe von 6 Personen empfangen.
<G-vec00078-001-s356><accept.empfangen><en> Whoever is violent, you have to know, that when the Spirit knocked on his heart, he also did not accept Him.
<G-vec00078-001-s356><accept.empfangen><de> Wenn ein Mensch grausam ist, müßt ihr wissen, daß, als Der Geist an die Tür seines Herzens geklopft hatte, nicht empfangen wurde.
<G-vec00078-001-s357><accept.empfangen><en> "14:15 ""If you love me, you will obey what I command. < 14:16 And I will ask the Father, and he will give you another Counselor to be with you forever-- 14:17 the Spirit of truth. The world cannot accept him, because it neither sees him nor knows him."
<G-vec00078-001-s357><accept.empfangen><de> 14:15 Wenn ihr mich liebet, so haltet meine Gebote; < 14:16 und ich werde den Vater bitten, und er wird euch einen anderen Sachwalter geben, daß er bei euch sei in Ewigkeit, 14:17 den Geist der Wahrheit, den die Welt nicht empfangen kann, weil sie ihn nicht sieht noch ihn kennt.
<G-vec00078-001-s358><accept.empfangen><en> For example the moon takes the heat of sun at the sunny side and at the dark side this energy is completely radiated back into space (and planets radiate more energy than they accept, see below).
<G-vec00078-001-s358><accept.empfangen><de> Beispielsweise nimmt der Mond auf einer Seite die Wärme der Sonnenstrahlung auf und strahlt sie auf seiner Schattenseite komplett ins All zurück (Planeten geben sogar mehr Strahlung ab als sie empfangen, siehe unten).
<G-vec00078-001-s359><accept.empfangen><en> Many people accept or feel another or sixth sense within them.
<G-vec00078-001-s359><accept.empfangen><de> Eine Reihe von Menschen empfangen und empfinden in sich darüber hinaus noch einen weiteren oder sechsten Sinn.
<G-vec00078-001-s360><accept.empfangen><en> For other net participants we can offer an expert guidance through trained staff, give an expert opinion, procure expert information and establish new contacts in the field of our work. We also accept volunteers.
<G-vec00078-001-s360><accept.empfangen><de> Nach Absprache können wir für andere Netzteilnehmer eine Beratung durchführen, ein Referat halten, aktuelle Fachinformationen und Kontakte vermitteln auf dem Gebiet unserer Arbeit, und Freiwillige MithelferInnen empfangen.
<G-vec00078-001-s361><accept.entgegennehmen><en> But do not walk past the source of life I opened up for you.... Listen when I speak to you and think about it.... keep coming back to hear My Word and soon you will no longer want to accept any other food and drink, you will constantly come to My table, you will accept My invitation for Supper and I will offer it to you with all the love a Host can grant to His guest, who will always come to Him in order to replenish themselves....
<G-vec00078-001-s361><accept.entgegennehmen><de> Aber gehet nicht an dem Lebensquell vorüber, den Ich für euch erschlossen habe.... Höret, wenn Ich zu euch rede, denket darüber nach.... kommet immer wieder, um Meine Ansprache zu vernehmen, und ihr werdet bald keine andere Speise und keinen anderen Trank mehr entgegennehmen wollen, ihr werdet euch dann ständig einfinden an Meinem Tisch, ihr werdet Meiner Einladung folgen, zum Abendmahl zu kommen, und Ich werde es euch darreichen mit aller Liebe, die der Gastgeber Seinen Gästen schenken wird, die sich immer bei Ihm einfinden, um sich sättigen zu lassen....
<G-vec00078-001-s362><accept.entgegennehmen><en> Only then will he gratefully accept what the Father's love offers to His child....
<G-vec00078-001-s362><accept.entgegennehmen><de> Dann erst wird er dankbar entgegennehmen, was die Liebe des Vaters Seinem Kind bietet....
<G-vec00078-001-s363><accept.entgegennehmen><en> Such light beings are mostly spiritual leaders, i.e., they stand in close union with me through leading a life according to my will and can therefore accept my instructions directly and impart them to men.
<G-vec00078-001-s363><accept.entgegennehmen><de> Solche Lichtseelen sind zumeist geistige Führer, d.h., sie stehen durch einen Lebenswandel nach Meinem Willen in naher Verbindung mit Mir und können also Meine Unterweisungen direkt entgegennehmen und den Menschen vermitteln.
<G-vec00078-001-s364><accept.entgegennehmen><en> Only if they united with Me and appealed for the transmission of truth will they be allowed to receive and also accept information from these said messengers of light, who are then working on My instructions again.
<G-vec00078-001-s364><accept.entgegennehmen><de> Und erst nach dieser Bindung mit Mir und der Bitte um Zuführung der Wahrheit werden sie empfangen dürfen und auch von jenen Lichtboten Belehrungen entgegennehmen, die dann wieder in Meinem Auftrag tätig sind.
<G-vec00078-001-s365><accept.entgegennehmen><en> Information about Bank Transfers Due to the special status of the Goethe-Institut Thailand, the institute has no account with a Thai commercial bank and can therefore only accept payment in cash.
<G-vec00078-001-s365><accept.entgegennehmen><de> Information zu Überweisungen Aufgrund seines besonderen Status verfügt das Goethe-Institut Thailand über kein Bankkonto bei einer thailändischen Geschäftsbank und kann nur Barzahlungen entgegennehmen.
<G-vec00078-001-s366><accept.entgegennehmen><en> The Justices of the Federal Constitutional Court may only accept remuneration for attending events and for publications if and to the extent that it does not compromise the reputation of the Court, nor cast doubt on the independence, impartiality, neutrality and integrity of the Court’s members.
<G-vec00078-001-s366><accept.entgegennehmen><de> Die Richterinnen und Richter des Bundesverfassungsgerichts können für Vorträge, für die Mitwirkung an Veranstaltungen und für Publikationen eine Vergütung nur und nur insoweit entgegennehmen, als dies das Ansehen des Gerichts nicht beeinträchtigen und keine Zweifel an der Unabhängigkeit, Unparteilichkeit, Neutralität und Integrität seiner Mitglieder begründen kann.
<G-vec00078-001-s367><accept.entgegennehmen><en> Network services are programs that accept input from anywhere on the network.
<G-vec00078-001-s367><accept.entgegennehmen><de> Netzwerkdienste sind Programme, die Eingaben aus dem Netzwerk entgegennehmen.
<G-vec00078-001-s368><accept.entgegennehmen><en> But since I want people to receive the truth I will always enlighten My bearers of light, I will not allow them to accept misguided mental concepts, I will always support their strength and will of resistance and increase their feeling for the pure truth and thus will also always be ready to solve problems which can lead to differences of opinion and spiritual debates.
<G-vec00078-001-s368><accept.entgegennehmen><de> Da Ich aber will, daß die Wahrheit den Menschen zugeleitet wird, werde Ich Meine Lichtträger auch stets erleuchten, Ich werde es nicht zulassen, daß sie irriges Gedankengut entgegennehmen, Ich werde ihre Abwehrkräfte und ihren Abwehrwillen stets unterstützen und ihr Empfinden für die reine Wahrheit verstärken und so auch immer bereit sein, Probleme zu lösen, die Anlaß von Meinungsverschiedenheiten und Debatten geistiger Art sein können.
<G-vec00078-001-s369><accept.entgegennehmen><en> Lifesize Icon can add video participants and accept multiple incoming callers to the active call.
<G-vec00078-001-s369><accept.entgegennehmen><de> Lifesize Icon kann Videoteilnehmer hinzufügen und mehrere eingehende Anrufe für einen aktiven Anruf entgegennehmen.
<G-vec00078-001-s370><accept.entgegennehmen><en> How else should you accept it if not from Himself.... which is purely determined by your desire....
<G-vec00078-001-s370><accept.entgegennehmen><de> Denn wie anders solltet ihr sie entgegennehmen, wenn nicht von Ihm Selbst.... was euer Begehren allein bestimmt....
<G-vec00078-001-s371><accept.entgegennehmen><en> Differently it is with those, who are in contact with the spiritual kingdom, who are at any time allowed to request and accept power in accordance with their will and their closeness to God.
<G-vec00078-001-s371><accept.entgegennehmen><de> Anders verhält es sich mit denen, die in Verbindung stehen mit dem geistigen Reich, die sich jederzeit Kraft erbitten und entgegennehmen dürfen ihrem Willen und ihrer Gottverbundenheit gemäß.
<G-vec00078-001-s372><accept.entgegennehmen><en> If the EPO had been acting as receiving Office under the PCT it would, under the PCT, also have had to accept a demand for international preliminary examination.
<G-vec00078-001-s372><accept.entgegennehmen><de> Handle das EPA als PCT-Anmeldeamt, so müsse es auch einen Antrag auf internationale vorläufige Prüfung gemäß dem PCT entgegennehmen.
<G-vec00078-001-s373><accept.entgegennehmen><en> It must have the most intimate bond with Him, it must want the suffering itself and also gratefully accept it as a gift from God in realisation that it pulls down the last barriers between God and itself and that only an overcoming of them will result in the highest bliss.... to become a child of God with all rights and duties....
<G-vec00078-001-s373><accept.entgegennehmen><de> Sie muss in der innigsten Verbindung stehen mit Ihm, sie muss selbst das Leid wollen und auch dieses als ein Geschenk Gottes dankbar entgegennehmen in der Erkenntnis, daß es die letzten Schranken zwischen Gott und sich niederreißt und daß nur ein Überwinden dessen ihm die höchste Seligkeit einträgt.... ein Kind Gottes zu werden mit allen Rechten und Pflichten....
<G-vec00078-001-s374><accept.entgegennehmen><en> Please make sure that someone who is authorized to accept delivery is available at your stand during the expected time of delivery.
<G-vec00078-001-s374><accept.entgegennehmen><de> Bitte stellen Sie sicher, dass sich während der erwarteten Lieferzeiten jemand Empfangsbefugtes zum Entgegennehmen der Sendung auf dem Stand befindet.
<G-vec00078-001-s375><accept.entgegennehmen><en> In that sense, the repository is internationalized—that is, the repository is ready to accept input in any human language.
<G-vec00078-001-s375><accept.entgegennehmen><de> In diesem Sinne ist das Projektarchiv internationalisiert – d.h., das Projektarchiv kann Eingaben in jeder menschlichen Sprache entgegennehmen.
<G-vec00078-001-s376><accept.entgegennehmen><en> You cannot accept my word differently than in thoughts of me because he, who speaks to you, cannot vanish into oblivion as long as you listen to him.
<G-vec00078-001-s376><accept.entgegennehmen><de> Ihr könnet Mein Wort nicht anders als in Gedanken an Mich entgegennehmen, weil Der, Der zu euch spricht, nicht in Vergessenheit geraten kann, solange ihr Ihn anhört.
<G-vec00078-001-s377><accept.entgegennehmen><en> You should gratefully accept the right seeds, embed it deep in your hearts and let it mature and, truly, the harvest will be a good fruit, for the seed you receive from Me Myself is pure truth which will lead you to the goal, to Me, Who is the Truth Itself.
<G-vec00078-001-s377><accept.entgegennehmen><de> Und ihr sollet dankbar das rechte Saatgut entgegennehmen, es in eure Herzen versenken und nun ausreifen lassen, und wahrlich, es wird eine gute Frucht geerntet werden, denn das Saatgut, das ihr von Mir Selbst empfanget, ist reine Wahrheit, und die Wahrheit führt euch auch zum Ziel, zu Mir, Der Ich Selbst die Wahrheit bin.
<G-vec00078-001-s378><accept.entgegennehmen><en> The confidants will accept your information or complaints and give an assessment of whether these are likely to be legally relevant.
<G-vec00078-001-s378><accept.entgegennehmen><de> Die Vertrauenspersonen werden Ihre Informationen oder Beschwerden entgegennehmen und beurteilen, ob diese voraussichtlich rechtlich relevant sind.
<G-vec00078-001-s379><accept.entgegennehmen><en> Icon can add video participants and accept multiple incoming callers to the ongoing call.
<G-vec00078-001-s379><accept.entgegennehmen><de> Icon kann Videoteilnehmer hinzufügen und mehrere eingehende Anrufe für den aktuellen Anruf entgegennehmen.
<G-vec00078-001-s380><accept.entgegennehmen><en> Of course, both types of biographical meetings are records, they are records consisting of words, words that penetrate the innocent paper, destroy its smooth surface, its constant readiness to accept the record.
<G-vec00078-001-s380><accept.entgegennehmen><de> In jedem Fall sind beide Arten von Biographien schriftliche Aufzeichnungen, sie sind Aufzeichnungen bestehend aus Worten, aus Worten, die das unschuldige Papier durchdringen, seine glatte Oberfläche zunichte machen, seine permanente Bereitschaft, die Aufzeichnung entgegenzunehmen.
<G-vec00078-001-s381><accept.entgegennehmen><en> And then you will be blessed to own a supply of spiritual goods and so that you permanently increase these I admonish you again and again and call out to you to take seriously my admonition and to accept my word from above often because it is the most delicious gift I can give and because it has an exceedingly favourable influence on you.
<G-vec00078-001-s381><accept.entgegennehmen><de> Und dann werdet ihr selig sein, einen Vorrat zu besitzen an geistigen Gütern, und auf daß ihr ständig diese vermehret, ermahne Ich euch immer wieder und rufe euch zu, Meine Mahnungen ernst zu nehmen und Mein Wort aus der Höhe des öfteren entgegenzunehmen, weil es die köstlichste Gabe ist, die Ich euch zuwenden kann, und weil sie überaus günstigen Einfluß hat auf euch.
<G-vec00078-001-s382><accept.entgegennehmen><en> The magnetic card reader also allows users to accept credit cards on location.
<G-vec00078-001-s382><accept.entgegennehmen><de> Der integrierte Magnetkartenleser erlaubt es den Bedienern darüber hinaus, Kreditkartenzahlungen entgegenzunehmen.
<G-vec00078-001-s383><accept.entgegennehmen><en> Should safe delivery of the Products to the address provided be impossible as no one is able to accept them, the Customer will be sent an email, to the address provided in the Order Form and Payment, stating the place from which the Customer can collect the package.
<G-vec00078-001-s383><accept.entgegennehmen><de> Wenn es sich als unmöglich erweist, Produkte sicher an die zu diesem Zweck angegebene Adresse zu versenden, da niemand zur Verfügung steht, um sie entgegenzunehmen, wird dem Kunden eine Mitteilung per E-Mail an die im Bestell- und Zahlungsformular angegebene Adresse gesendet, die den Ort angibt, an dem sich die Produkte befinden und für die Abholung durch den Kunden bereit stehen.
<G-vec00078-001-s384><accept.entgegennehmen><en> (5) The customer will be obliged to accept all delivered goods in accordance with this contract. In the event that the customer refuses to accept the delivery of goods delivered within the agreed delivery period for reasons for which Mahr is not responsible, Mahr will be entitled to demand compensation for damages, including any additional costs incurred, regardless of whether the goods were expressly offered or not, if these goods were capable of fulfilling their intended purpose at the time of delivery.
<G-vec00078-001-s384><accept.entgegennehmen><de> (5) Weigert sich der Besteller aus Gründen, die Mahr nicht zu vertreten hat, die Ware zu dem vereinbarten Liefertermin entgegenzunehmen, wozu er nach dem Inhalte dieses Vertrages verpflichtet ist, kann Mahr - unabhängig davon, ob sie die Ware ausdrücklich angeboten hat - den ihr entstehenden Schaden, einschließlich etwaiger Mehraufwendungen ersetzt verlangen, wenn sie zum vereinbarten Zeitpunkt leistungsfähig und leistungsbereit gewesen ist.
<G-vec00078-001-s385><accept.entgegennehmen><en> The customer shall accept the goods at any time once KAMEI has informed the customer that the goods are ready to for collection.
<G-vec00078-001-s385><accept.entgegennehmen><de> Der Kunde hat die Ware jederzeit entgegenzunehmen, sobald KAMEI den Kunden über die Abholbereitschaft benachrichtigt hat.
<G-vec00078-001-s386><accept.entgegennehmen><en> We have a complete customer service department that's here to accept your orders, help you select the right tablet cases and answer your questions. 8.
<G-vec00078-001-s386><accept.entgegennehmen><de> Wir haben eine vollständige Kundenservice-Abteilung, die dafür da ist, Ihre Bestellungen entgegenzunehmen, Ihnen bei der Wahl der richtigen Tablet-Hülle behilflich zu sein und Ihre Fragen zu beantworten.
<G-vec00078-001-s387><accept.entgegennehmen><en> I, however, gave the first human beings the opportunity to accept love from Me again....
<G-vec00078-001-s387><accept.entgegennehmen><de> Ich aber gab den ersten Menschen die Möglichkeit, wieder von Mir Liebe entgegenzunehmen....
<G-vec00078-001-s388><accept.entgegennehmen><en> The contact person is authorized to make any declarations with regard to execution of the contractually agreed performance and to accept any corresponding declarations from MCL.
<G-vec00078-001-s388><accept.entgegennehmen><de> Die Kontaktperson ist ermächtigt, alle Erklärungen im Rahmen der Ausführung der vertraglich vereinbarten Leistung abzugeben und entsprechende Erklärungen der MCL entgegenzunehmen.
<G-vec00078-001-s389><accept.entgegennehmen><en> PIONEER DJ has a policy not to accept any proposals, remarks, suggestions, ideas, materials or other information concerning PIONEER DJ's products and services (hereinafter collectively referred to as Proposals).
<G-vec00078-001-s389><accept.entgegennehmen><de> PIONEER DJ verfolgt die Richtlinie, keine Vorschläge, Anmerkungen, Anregungen, Ideen, Materialien oder andere Informationen bezüglich seiner Produkte und Dienstleistungen (im Folgenden zusammenfassend „Vorschläge“ genannt) entgegenzunehmen.
<G-vec00078-001-s390><accept.entgegennehmen><en> The services of Mollie enable you to accept payments from your Customers in exchange for the products and/or services delivered by you.
<G-vec00078-001-s390><accept.entgegennehmen><de> Die Dienstleistungen von Mollie ermöglichen Ihnen, Zahlungen Ihrer Kunden für die von Ihnen gelieferten Produkte und/oder erbrachten Dienstleistungen entgegenzunehmen.
<G-vec00078-001-s392><accept.entgegennehmen><en> Every thought to accept spiritual goods offered by me is my love's hint that I give you to foster your development.
<G-vec00078-001-s392><accept.entgegennehmen><de> Jeder Gedanke, von Mir gebotenes Geistesgut entgegenzunehmen, ist Meiner Liebe Wink, den Ich euch gebe, um euch zu fördern in eurer Entwicklung.
<G-vec00078-001-s393><accept.entgegennehmen><en> The FreeBSD Foundation is now able to accept donations through the web with PayPal.
<G-vec00078-001-s393><accept.entgegennehmen><de> Die FreeBSD Foundation ist nun auch in der Lage, Spenden durch das PayPal-System entgegenzunehmen.
<G-vec00078-001-s394><accept.entgegennehmen><en> What a little thing it is for the mind to accept something.
<G-vec00078-001-s394><accept.entgegennehmen><de> Was für etwas Kleines ist es für den Geist, etwas entgegenzunehmen.
<G-vec00078-001-s395><accept.entgegennehmen><en> When you accept an incoming call, together with the number (name) the caller on the screen of your phone’s display advertising image (banner).
<G-vec00078-001-s395><accept.entgegennehmen><de> Wenn Sie einen eingehenden Anruf entgegenzunehmen, zusammen mit der Nummer (Name) des Anrufers auf dem Bildschirm Ihres Telefon-Displays Bild Werbung (Banner).
<G-vec00078-001-s396><accept.entgegennehmen><en> 2.7 We shall not be bound to accept cheques and bills of exchange.
<G-vec00078-001-s396><accept.entgegennehmen><de> 2.7 Wir sind nicht verpflichtet, Schecks und Wechsel entgegenzunehmen.
<G-vec00078-001-s397><accept.entgegennehmen><en> On February 8, 2005 the Falun Dafa Information Centre reported that the 610 Office in mainland China had spread another verbal secret document that required the public security sectors, procuratorial sectors and people's courts to not accept Falun Gong practitioners' complaints, appeals, or charges.
<G-vec00078-001-s397><accept.entgegennehmen><de> Februar 2005 berichtete das Falun Gong Informationszentrum, dass das Büro 610 auf dem Festland Chinas ein anderes geheimes mündliches Dokument verbreitete, welches die öffentlichen Sicherheitssektoren, Staatsanwaltssektoren und Volksgerichtshöfe aufforderte, Beschwerden, Rechtsmittel oder Klagen von Falun Gong-Praktizierenden, nicht entgegenzunehmen.
<G-vec00078-001-s398><accept.entgegennehmen><en> But you, too, must try to accept this answer without prejudice....
<G-vec00078-001-s398><accept.entgegennehmen><de> Doch auch ihr müsset euch bemühen, völlig vorurteilsfrei diese Antwort entgegenzunehmen....
<G-vec00078-001-s418><accept.hinnehmen><en> """[6] This kind of rising up, this kind of insurrection, which Stirner had to linguistically argue in this manner in order to avoid criminal prosecution[7], does not want to arrange itself, does not want to accept the institutions, even those of the revolution, as such, if they close themselves off again."
<G-vec00078-001-s418><accept.hinnehmen><de> """[6] Ein solches Emporrichten, eine solche Empörung, die Stirner übrigens, um nicht strafrechtlich verfolgt zu werden, linguistisch argumentieren muss[7], will sich nicht einrichten lassen, will die Einrichtungen, selbst jene der Revolution, nicht als solche hinnehmen, insofern diese sich selbst wieder verschließen."
<G-vec00078-001-s419><accept.hinnehmen><en> We cannot accept that this is denied by war, which is an aggregation of oppression and untruth.
<G-vec00078-001-s419><accept.hinnehmen><de> Wir dürfen nicht hinnehmen, dass dies durch den Krieg geleugnet wird, der eine Anhäufung von Übergriffen und Lügen ist.
<G-vec00078-001-s420><accept.hinnehmen><en> As a whole, the right had to accept the loss of 164 cantons.
<G-vec00078-001-s420><accept.hinnehmen><de> Im Saldo muss die Rechte den Verlust von 164 Kantonen hinnehmen.
<G-vec00078-001-s421><accept.hinnehmen><en> """Being guarantor power of the comprehensive peace agreement between North and South Sudan (of January 2005), Germany should not simply accept this occupation"", the STP's expert on questions regarding Africa, Ulrich Delius, stated in Göttingen on Monday."
<G-vec00078-001-s421><accept.hinnehmen><de> """Als Garantiemacht des umfassenden Friedensabkommens zwischen Nord- und Südsudan im Januar 2005 darf Deutschland diese Besatzung nicht einfach hinnehmen"", erklärte der GfbV-Afrikareferent Ulrich Delius am Montag in Göttingen."
<G-vec00078-001-s422><accept.hinnehmen><en> In this phase capitalism must accept many defeats.
<G-vec00078-001-s422><accept.hinnehmen><de> In dieser Phase muss der Kapitalismus viele Niederlagen hinnehmen.
<G-vec00078-001-s423><accept.hinnehmen><en> Die kleine Verkäuferin der Sonne/The Small Vendor of the SunÂ All the newspaper vendors on the streets of Dakar are boys, but the 12-year-old girl Sili, who can only walk with the aid of crutches, does not want to accept this.
<G-vec00078-001-s423><accept.hinnehmen><de> Die kleine Verkäuferin der Sonne Alle Zeitungsverkäufer in Dakars Straßen sind Buben, doch die zwölfjährige Sili, die nur mit Krücken gehen kann, will dies nicht hinnehmen.
<G-vec00078-001-s424><accept.hinnehmen><en> A repeat of the scenario on New Year's Eve 2015 had to be prevented, for the state cannot accept public places becoming realms of fear.
<G-vec00078-001-s424><accept.hinnehmen><de> Ein Szenario wie in der Silvesternacht 2015 musste verhindert werden, denn der Staat darf es nicht hinnehmen, dass öffentliche Orte zu Angsträumen werden.
<G-vec00078-001-s425><accept.hinnehmen><en> I invite all those concerned to act with determination: we cannot accept that so many innocent people continue to suffer and die in this way.
<G-vec00078-001-s425><accept.hinnehmen><de> Ich fordere alle zu entschlossenem Handeln auf: Wir dürfen es nicht hinnehmen, daß so viele Unschuldige weiter leiden und in der Folge sterben.
<G-vec00078-001-s426><accept.hinnehmen><en> Irrespective of that, you have to accept that actions like the swimming pool ban will be assessed legally and morally.
<G-vec00078-001-s426><accept.hinnehmen><de> Unabhängig davon muss man es aber hinnehmen, wenn Handlungen wie das Badiverbot einer rechtlichen und moralischen Bewertung unterzogen werden.
<G-vec00078-001-s427><accept.hinnehmen><en> They will not accept the occupation and will struggle in different ways.
<G-vec00078-001-s427><accept.hinnehmen><de> Es wird die Besatzung nicht hinnehmen und auf verschiedene Weise gegen sie kämpfen.
<G-vec00078-001-s428><accept.hinnehmen><en> The hook at the thing: the dam operators would have to accept a loss of 15 per cent during the energy production, which would mean approximately 35 million euro reduced receipts per year according to present calculation.
<G-vec00078-001-s428><accept.hinnehmen><de> Der Haken an der Sache: die Staudamm-Betreiber müssten bei der Energieerzeugung eine Einbuße von 15 Prozent hinnehmen, was nach derzeitiger Rechnung rund 35 Millionen Euro Mindereinnahmen pro Jahr bedeuten würde.
<G-vec00078-001-s429><accept.hinnehmen><en> But I would simply have to accept this special type of noise, even though the level of disturbance to me personally is the same.
<G-vec00078-001-s429><accept.hinnehmen><de> Diesen speziellen anderen Lärm müsste ich klaglos hinnehmen - obwohl die persönlich empfundene Belästigung eben doch dieselbe bleibt.
<G-vec00078-001-s430><accept.hinnehmen><en> "Regarding the Chinese Communist regime's persecution and killing of Falun Gong practitioners, Ms Veronique Dantec said, ""I cannot accept the persecution of Falun Gong."
<G-vec00078-001-s430><accept.hinnehmen><de> "Bezüglich der brutalen Verfolgung und Tötung von Falun Gong Praktizierenden durch das chinesische kommunistische Regime sagte Frau Dantec: ""Ich kann die Verfolgung von Falun Gong nicht hinnehmen."
<G-vec00078-001-s431><accept.hinnehmen><en> What other children easily accept or dismiss is heavy and problematic for him.
<G-vec00078-001-s431><accept.hinnehmen><de> Vieles, was andere Kinder leicht hinnehmen, ist für ihn schwer und problematisch.
<G-vec00078-001-s432><accept.hinnehmen><en> Last year we had to accept the first defeat of the season in São Paulo.
<G-vec00078-001-s432><accept.hinnehmen><de> Im vergangenen Jahr mussten wir in São Paulo die erste Saisonniederlage hinnehmen.
<G-vec00078-001-s433><accept.hinnehmen><en> "As early as October 2010, Bavaria's Interior Minister Joachim Herrmann warned: ""We will not accept this obvious abuse of our asylum system."
<G-vec00078-001-s433><accept.hinnehmen><de> "Schon im Oktober 2010 warnte der Bayrische Innenminister Joachim Herrmann: ""Diesen offenkundigen Missbrauch unseres Asylrechts werden wir nicht hinnehmen."
<G-vec00078-001-s434><accept.hinnehmen><en> "Or why he could refuse to accept many of also from ""official"" side already rejected testimonies, but on the other hand he would accept without any hesitation other statements made by witnesses, which were not rejected by the establishment, although them too could not withstand critical assessment."
<G-vec00078-001-s434><accept.hinnehmen><de> "Oder wie er zwar einerseits die vielen bereits auch von ""offizieller"" Seite inhaltlich verworfenen Zeugenaussagen ablehnen könne, andererseits aber andere bislang vom Establishment nicht angegriffene, inhaltlich aber nicht minder unglaubhafte Zeugenaussagen kritiklos hinnehmen könne."
<G-vec00078-001-s435><accept.hinnehmen><en> In any insolvency proceedings with its German customer, a supplier or creditor always face the problem that they must accept a discount claim that varies from case to case and must be satisfied with a quota on a regular basis.
<G-vec00078-001-s435><accept.hinnehmen><de> Der Lieferant und Gläubiger steht bei der Insolvenz seines deutschen Kunden immer vor dem Problem, dass er im Insolvenzverfahren seines deutschen Kunden häufig einen von Fall zu Fall unterschiedlich großen Abschlag von seiner Forderung hinnehmen und sich regelmäßig mit einer Quote zufrieden geben muss.
<G-vec00078-001-s436><accept.hinnehmen><en> On account of the unusual thoroughness with which everything is treated here, the precepts that the pupil never has to accept blindly take on far greater importance for him.
<G-vec00078-001-s436><accept.hinnehmen><de> Gerade durch die ungewöhnliche Ausführlichkeit, mit der alles hier behandelt wird, bekommen die Vorschriften, die er nie blind hinnehmen muss, ein viel größeres Gewicht für den Schüler.
<G-vec00078-001-s627><accept.zulassen><en> Some bank accounts cannot accept Direct Debits; they may be closed, or blocked either for regulatory reasons or by the customer.
<G-vec00078-001-s627><accept.zulassen><de> Einige Konten können keine Lastschriften zulassen; sie sind vielleicht geschlossen oder gesperrt, entweder aus regulatorischen Gründen oder durch den Kunden.
<G-vec00078-001-s628><accept.zulassen><en> In the Block cookies section, specify if and when Safari should accept cookies from websites.
<G-vec00078-001-s628><accept.zulassen><de> "Geben Sie unter ""Cookies blockieren"" an, wann Safari Cookies von Websites zulassen soll."
<G-vec00078-001-s629><accept.zulassen><en> In exceptional cases the management board may accept smaller amounts, if the management is convinced that an adequate market in the securities to be admitted will be established.
<G-vec00078-001-s629><accept.zulassen><de> In Ausnahmefällen kann die Geschäftsführung auch geringere Beträge zulassen, wenn sie davon überzeugt ist, dass sich für die zuzulassenden Wertpapiere ein ausreichender Markt bilden wird.
<G-vec00078-001-s630><accept.zulassen><en> The help function in the menu bar of most web browsers explains how you can accept or reject cookies.
<G-vec00078-001-s630><accept.zulassen><de> Die Hilfefunktion in der Menüleiste der meisten Webbrowser erklärt Ihnen, wie Sie Cookies zulassen oder ablehnen können.
<G-vec00078-001-s631><accept.zulassen><en> If you choose not to accept cookies, Web beacon technologies will still detect anonymous visits, but the notices they generate cannot be associated with other information and are disregarded.
<G-vec00078-001-s631><accept.zulassen><de> Wenn Sie Cookies nicht zulassen, erkennen Web Beacon-Technologien jedoch weiterhin anonyme Besuche, aber die generierten Mitteilungen können keinen anderen Informationen zugeordnet werden, sodass die Mitteilungen verworfen werden.
<G-vec00078-001-s632><accept.zulassen><en> My own experience is like this: in the world's present state, a direct miracle (vital or material, that is) must necessarily involve a number of fallacious elements which we cannot accept – those miracles are necessarily fallacious miracles.
<G-vec00078-001-s632><accept.zulassen><de> Meine Erfahrung lautet also: Im gegenwärtigen Zustand der Welt müßte ein direktes (materielles oder vitales) Wunder notgedrungen eine Fülle von lügenhaften Elementen berücksichtigen, die man nicht zulassen darf – es wären notgedrungen lügenhafte Wunder.
<G-vec00078-001-s633><accept.zulassen><en> “We can no longer accept the use of these poisons because they destroy biodiversity, aggravate climate change, destroy the soil’s fertility, and contaminate the water and even the air,” said Joao Pedro Stédile, leader of Brazil’s Landless Workers’ Movement (MST). “And above all, they bring more illness, such as cancer,” he told IPS.
<G-vec00078-001-s633><accept.zulassen><de> „Wir dürfen nicht länger zulassen, dass diese Gifte die Artenvielfalt gefährden, Klimaveränderungen begünstigen, Böden unfruchtbar machen, Luft und Gewässer verseuchen und dann auch noch beim Menschen Krankheiten wie Krebs erzeugen“, so auch der Leiter der brasilianischen Landlosenbewegung MST, João Pedro Stédile.
<G-vec00078-001-s634><accept.zulassen><en> We ask request that we can´t accept any exceptions.
<G-vec00078-001-s634><accept.zulassen><de> Wir bitten um Ihr Verständnis, dass wir keine Ausnahmen zulassen können.
<G-vec00078-001-s635><accept.zulassen><en> You may permit, block or delete cookies installed on your computer by configuring the options for the browser installed on your computer, however, should your browser be set not to accept cookies, you may be unable to access certain sections our website.
<G-vec00078-001-s635><accept.zulassen><de> Sie können die auf Ihrem Gerät installierten Cookies anhand der Einstellungsoptionen des auf Ihrem Computer installierten Browsers zulassen, blockieren oder löschen; sollten Sie die Installation von Cookies in Ihrem Browser nicht zulassen, ist es möglich, dass Sie auf einige Bereiche unserer Website nicht zugreifen können.
<G-vec00078-001-s636><accept.zulassen><en> Therefore, we provide you with information and links to the official support sites of the main browsers so you can decide whether or not you want to accept the use of cookies.
<G-vec00078-001-s636><accept.zulassen><de> Dafür geben wir Ihnen die Informationen und Links zu den offiziellen Support-Seiten der wichtigsten Browser an, sodass Sie entscheiden können, ob Sie die Nutzung von Cookies zulassen möchten oder nicht.
<G-vec00078-001-s637><accept.zulassen><en> We may maintain one or more blogs on the site that accept comments.
<G-vec00078-001-s637><accept.zulassen><de> Eventuell unterhalten wir eines oder mehrere Blogs auf der OTW-Website, die Kommentare zulassen.
<G-vec00078-001-s638><accept.zulassen><en> In Mozilla Firefox in the menu Tools/Options/Privacy please “Accept cookies from sites”.
<G-vec00078-001-s638><accept.zulassen><de> In Mozilla Firefox können Sie unter Extras/Einstellungen/Datenschutz Cookies zulassen.
<G-vec00078-001-s639><accept.zulassen><en> The theocracies that only accept one belief and persecute and kill those who have different beliefs or oppose the official theocratic line.
<G-vec00078-001-s639><accept.zulassen><de> · Die Theokratien, die nur einen Glauben zulassen und jene verfolgen und töten, die einen anderen Glauben haben oder sich der offiziellen theokratischen Linie widersetzen.
<G-vec00078-001-s640><accept.zulassen><en> If you visit our Website when your browser is set to accept cookies, we will interpret this as an indication that you consent to our use of cookies and other similar technologies as described in this Policy.
<G-vec00078-001-s640><accept.zulassen><de> Zustimmung Browser Einstellungen Wenn Sie unsere Website besuchen und Ihre Browsereinstellungen Cookies zulassen, interpretieren wir das als Zustimmung zum Einsatz von Cookies und ähnlichen Technologien, wie in den Richtlinien beschrieben.
<G-vec00078-001-s641><accept.zulassen><en> If you prefer to connect in Radar, then tap “Accept” on your iOS device to build connection.
<G-vec00078-001-s641><accept.zulassen><de> Tippen Sie auf Ihrem iOS Gerät nun auf „Zulassen“, um die Verbindung herzustellen.
<G-vec00078-001-s642><accept.zulassen><en> You can choose to accept or decline cookies.
<G-vec00078-001-s642><accept.zulassen><de> Sie können das Ablegen von Cookies zulassen oder ablehnen.
<G-vec00078-001-s643><accept.zulassen><en> If you do not wish to accept GARDENA's use of cookies, most browsers allow you to configure your browser to reject cookies by modifying your browser settings.
<G-vec00078-001-s643><accept.zulassen><de> Wenn Sie die Verwendung von Cookies durch Husqvarna nicht zulassen möchten, können Sie die Einstellungen der meisten Browser so konfigurieren, dass Cookies nicht zugelassen werden.
<G-vec00078-001-s644><accept.zulassen><en> We must accept new technologies, but we must use them together and in more innovative ways than before.
<G-vec00078-001-s644><accept.zulassen><de> Wir müssen neue Technologien zulassen, aber wir müssen sie gemeinsam und innovativer nutzen als bisher.
<G-vec00078-001-s645><accept.zulassen><en> Although the default setting on most internet browsers is to accept cookies, you can remove cookies that have already been placed and restrict or block the placement of new cookies by adjusting your browser settings.
<G-vec00078-001-s645><accept.zulassen><de> Obwohl die meisten Internetbrowser in ihren Einstellungen standardmäßig Cookies zulassen, können Sie bereits abgelegte Cookies löschen und das Ablegen neuer Cookies beschränken oder blockieren, indem Sie die Browsereinstellungen entsprechend ändern.
<G-vec00078-001-s646><accept.zustimmen><en> You are hereby informed that, if you accept the sending of commercial communications, your contact data may be assigned to the other companies that make up the HOVIMA HOTELS group for the sending of commercial communications and promotions regarding its own hotel offers.
<G-vec00078-001-s646><accept.zustimmen><de> Falls Sie der Zusendung von geschäftlichen Mitteilungen zustimmen, können Ihre Kontaktdaten an die restlichen Unternehmen der Gruppe HOVIMA HOTELS zum Versand von geschäftlichen Mitteilungen und Werbung über ihre eigenen Hotelangebote weitergegeben werden Ihre Daten werden keinen anderen Dritten mitgeteilt, außer wenn eine rechtliche Pflicht dazu besteht.
<G-vec00078-001-s647><accept.zustimmen><en> Nevertheless, the policyholder can ask TOKIO MARINE ASSISTANCE to organise the repatriation, the costs being at the insured personâ€TMs charge; only TOKIO MARINE ASSISTANCE medical management can accept or not the repatriation.
<G-vec00078-001-s647><accept.zustimmen><de> Der Versicherungsnehmer kann dennoch TOKIO MARINE ASSISTANCE mit der Organisation der Rückführung beauftragen, die entstandenen Kosten werden in diesem Fall von ihm getragen; nur die ärztliche Leitung von TOKIO MARINE ASSISTANCE kann der Rückführung zustimmen oder nicht.
<G-vec00078-001-s648><accept.zustimmen><en> Please accept our cookie agreement to see full comments functionality.
<G-vec00078-001-s648><accept.zustimmen><de> Um die Kommentare zu sehen, bitte unserer Cookie Vereinbarung zustimmen.
<G-vec00078-001-s649><accept.zustimmen><en> Emails telling me exactly how my data is being used within a certain organisation, or asking me to accept specific data usage terms are just a drop in the bucket.
<G-vec00078-001-s649><accept.zustimmen><de> Die E-Mails, in denen angegeben wird, wie genau meine Daten von der jeweiligen Firma verarbeitet und genutzt werden, und denen ich zustimmen soll, sind nur ein Tropfen auf den heißen Stein.
<G-vec00078-001-s650><accept.zustimmen><en> Verify that you have entered the correct payment and contact information and that you have read the Terms and Conditions before you accept them.
<G-vec00078-001-s650><accept.zustimmen><de> Versichern Sie sich, dass Sie die richtigen Zahlungs- und Kontaktinformationen angegeben und die Teilnahmebedingungen gelesen haben, bevor Sie ihnen zustimmen.
<G-vec00078-001-s651><accept.zustimmen><en> Comments Please accept our cookie agreement to see full comments functionality.
<G-vec00078-001-s651><accept.zustimmen><de> Um die Kommentare zu sehen, bitte unserer Cookie Vereinbarung zustimmen.
<G-vec00078-001-s652><accept.zustimmen><en> Thus the Prophet (peace be upon him and his pure family) reluctantly had to accept their marriage – although he knew that Uthman was a hypocrite – only to increase the number of Muslims at that critical time.
<G-vec00078-001-s652><accept.zustimmen><de> Aufgrund dessen musste der Prophet (Friede sei mit ihm und seiner aufrechten Familie) widerwillig der Hochzeit zustimmen um die Anzahl der Muslime zu erhöhen.
<G-vec00078-001-s653><accept.zustimmen><en> Not only did it force the Galactic Republic to desperately accept unfavorable terms in ending the Great War; it also allowed for the utter destruction of the Jedi Temple.
<G-vec00078-001-s653><accept.zustimmen><de> Als Folge musste die Galaktische Republik nicht nur unvorteilhaften Bedingungen zustimmen, um den Großen Krieg zu beenden, auch der Jedi-Tempel wurde im Zuge der Plünderung völlig zerstört.
<G-vec00078-001-s654><accept.zustimmen><en> NOTE: If you would like to keep up to date with MTG novelties and promotions, it is very important you accept receiving notifications and share your location with MTG PRO (when the app prompts you during the install process).
<G-vec00078-001-s654><accept.zustimmen><de> ANMERKUNG: Wenn Sie weiter über alle Neuheiten und Angebote von MTG informiert werden wollen, müssen Sie unbedingt dem Erhalt von Mitteilungen zustimmen und Ihren Standort mit MTG PRO teilen (wenn Sie die App während der Installation dazu auffordert).
<G-vec00078-001-s655><accept.zustimmen><en> If you are not willing to accept the terms of this Privacy Notice or if you do not agree with how we will handle your personal data, please do not use this Website or provide us with your personal data.
<G-vec00078-001-s655><accept.zustimmen><de> Wenn Sie den Bedingungen in dieser Datenschutzrichtlinie nicht zustimmen möchten, oder wenn Sie nicht einverstanden damit sind, wie wir mit Ihren persönlichen Daten umgehen, dann nutzen Sie bitte diese Website nicht und stellen Sie uns Ihre persönlichen Daten nicht zur Verfügung.
<G-vec00078-001-s656><accept.zustimmen><en> If you continue browsing, it will be understood that you accept the use of cookies.
<G-vec00078-001-s656><accept.zustimmen><de> Wenn Sie diese Seite weiterhin nutzen, gehen wir davon aus, dass Sie unserer Verwendung von Cookies zustimmen.
<G-vec00078-001-s657><accept.zustimmen><en> If you accept the terms, you will then be given the option of a Standard or Advanced installation.
<G-vec00078-001-s657><accept.zustimmen><de> Wenn Sie der Lizenzvereinbarung zustimmen, haben sie die Wahl zwischen einer Standard- und einer fortgeschrittenen Installation.
<G-vec00078-001-s658><accept.zustimmen><en> If you do not wish to accept the change(s) you may opt-out by deleting your account
<G-vec00078-001-s658><accept.zustimmen><de> Wenn Sie der Änderung (den Änderungen) nicht zustimmen wollen, können Sie sich dagegen entscheiden, indem Sie Ihr Konto löschen.
<G-vec00078-001-s659><accept.zustimmen><en> Your use of the Intel Services following these changes means that you accept the revised Supplement.
<G-vec00078-001-s659><accept.zustimmen><de> Die Nutzung der Intel-Dienste nach den Änderungen bedeutet, dass Sie dem geänderten Datenschutzhinweis zustimmen.
<G-vec00078-001-s660><accept.zustimmen><en> It goes without saying that should any European government fail to accept this plan, the others should proceed without them.
<G-vec00078-001-s660><accept.zustimmen><de> Es versteht sich von selbst, daß für den Fall, daß einige der europäischen Regierungen diesem Plan nicht zustimmen sollten, die anderen alleine vorangehen.
<G-vec00078-001-s661><accept.zustimmen><en> You must therefore accept to be poisoned to enter these countries.
<G-vec00078-001-s661><accept.zustimmen><de> Sie müssen daher zustimmen, vergiftet zu werden, um in diese Länder einzureisen.
<G-vec00078-001-s662><accept.zustimmen><en> I accept More information Viewed products Wallpaper...
<G-vec00078-001-s662><accept.zustimmen><de> Zustimmen Mehr Information Angesehene Produkte Hintergrund...
<G-vec00078-001-s663><accept.zustimmen><en> It will not accept a territorial solution dictated by Serbs and Croats at the expense of the Bosnian Muslims.
<G-vec00078-001-s663><accept.zustimmen><de> Er wird einer von Serben und Kroaten diktierten Gebietslösung auf Kosten der bosnischen Muslime nicht zustimmen.
<G-vec00078-001-s664><accept.zustimmen><en> "Click on ""Next"" two times, then on button ""Accept""."
<G-vec00078-001-s664><accept.zustimmen><de> "Klicken Sie zweimal auf ""Weiter"", dann auf den Knopf ""Zustimmen""."
<G-vec00120-001-s657><accept.zustimmen><en> If you accept the terms, you will then be given the option of a Standard or Advanced installation.
<G-vec00120-001-s657><accept.zustimmen><de> Wenn Sie der Lizenzvereinbarung zustimmen, haben sie die Wahl zwischen einer Standard- und einer fortgeschrittenen Installation.
<G-vec00120-001-s660><accept.zustimmen><en> It goes without saying that should any European government fail to accept this plan, the others should proceed without them.
<G-vec00120-001-s660><accept.zustimmen><de> Es versteht sich von selbst, daß für den Fall, daß einige der europäischen Regierungen diesem Plan nicht zustimmen sollten, die anderen alleine vorangehen.
<G-vec00078-001-s665><accept.übernehmen><en> Now FIFA 14 Is Coming, To meet many player's need, we accept pay for fifa 14 ultimate team ps3 mÃ1⁄4nzen Paypal online securely.
<G-vec00078-001-s665><accept.übernehmen><de> Jetzt FIFA 14 kommt, brauchen viele Spieler gerecht zu werden, übernehmen wir zahlen für Online fifa 14 ultimate team ps3 mÃ1⁄4nzen Paypal sicher.
<G-vec00078-001-s666><accept.übernehmen><en> We shall not accept any liability for our Internet offer being suitable for users from other countries, or for it being usable or legally permissible there.
<G-vec00078-001-s666><accept.übernehmen><de> Wir übernehmen keine Haftung dafür, dass unser Internet-Angebot für Nutzer aus anderen Staaten geeignet, verwendbar oder dort rechtlich zulässig ist.
<G-vec00078-001-s667><accept.übernehmen><en> Despite carefully monitoring content, we cannot accept any liability for the content of external links.
<G-vec00078-001-s667><accept.übernehmen><de> Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links.
<G-vec00078-001-s668><accept.übernehmen><en> However, Salzgitter AG and EQS Group do not accept any liability or guarantee for the topicality, correctness and completeness of the information provided on this webpage.
<G-vec00078-001-s668><accept.übernehmen><de> Trotz sorgfältiger Informationsbeschaffung und -bereitstellung übernehmen die Salzgitter AG undEQS Groupkeine Gewährleistung für die Vollständigkeit, Richtigkeit und Aktualität der Daten.
<G-vec00078-001-s669><accept.übernehmen><en> For Christians to accept this faulty line of reasoning would lead to the notion that there is little need to emphasize objective truth in the presentation of the Christian faith, for one need but follow his or her own conscience and choose a community that best suits his or her individual tastes.
<G-vec00078-001-s669><accept.übernehmen><de> Wenn Christen dieses falsche Denkschema übernehmen, dann kommen sie zu dem Schluß, daß es wohl kaum notwendig sei, bei der Darlegung des christlichen Glaubens die objektive Wahrheit hervorzuheben: man brauche nur seinem Gewissen zu folgen und eine Gemeinschaft zu wählen, die dem eigenen Geschmack am besten entspricht.
<G-vec00078-001-s670><accept.übernehmen><en> NATO, would have to accept the responsibility of course, of having now turned the situation into a world-wide mess.
<G-vec00078-001-s670><accept.übernehmen><de> Die NATO müsste natürlich die Verantwortung übernehmen, dass sie die Lage jetzt zu einer weltweiten Sauerei gemacht hätten.
<G-vec00078-001-s671><accept.übernehmen><en> "The DAAD and the Content5 AG accept no liability for the correctness of the data contained in the ""International Programmes in Germany"" and ""Language and Short Courses in Germany""."
<G-vec00078-001-s671><accept.übernehmen><de> "Der DAAD und die Content5 AG übernehmen für die ""International Programmes in Germany"" und ""Sprach- und Fachkurse in Deutschland"" keine Gewähr über die Korrektheit der Daten."
<G-vec00078-001-s672><accept.übernehmen><en> We do not accept any liability towards people or companies for the use of, or trust in, incorrect information or opinions included on this website.
<G-vec00078-001-s672><accept.übernehmen><de> Wir übernehmen keinerlei Haftung gegenüber Personen oder Gesellschaften für die Verwendung von oder das Vertrauen in unrichtige Informationen oder Meinungen, die auf dieser Website enthalten sind.
<G-vec00078-001-s673><accept.übernehmen><en> Now FIFA 14 Is Coming, To meet many player's need, we accept pay for fifa 14 ultimate team coins for xbox 360 Paypal online securely.
<G-vec00078-001-s673><accept.übernehmen><de> Jetzt FIFA 14 kommt, brauchen viele Spieler gerecht zu werden, übernehmen wir zahlen für Online fifa 14 ultimate team coins for xbox 360 Paypal sicher.
<G-vec00078-001-s674><accept.übernehmen><en> These specialist credit cards allow you to pay off debt over an extended period of time and will also accept debts which have been transferred across from other cards.
<G-vec00078-001-s674><accept.übernehmen><de> Diese Fach Kreditkarten erlauben Sie Schulden über einen längeren Zeitraum zu zahlen sich aus und wird auch Schulden übernehmen, die von anderen Karten über übertragen wurden.
<G-vec00078-001-s675><accept.übernehmen><en> To accept the proposed setup without any changes, choose Next to proceed.
<G-vec00078-001-s675><accept.übernehmen><de> Wenn Sie das vorgeschlagene Setup ohne Änderungen übernehmen möchten, klicken Sie zum Fortfahren auf Weiter .
<G-vec00078-001-s676><accept.übernehmen><en> Now FIFA 14 Is Coming, To meet many player's need, we accept pay for fut cheap coins Paypal online securely.
<G-vec00078-001-s676><accept.übernehmen><de> Jetzt FIFA 14 kommt, brauchen viele Spieler gerecht zu werden, übernehmen wir zahlen für Online fut cheap coins Paypal sicher.
<G-vec00078-001-s677><accept.übernehmen><en> Despite careful checks of the content of external links given, Akkord does not accept any liability.
<G-vec00078-001-s677><accept.übernehmen><de> Haftungshinweis: Trotz sorgfältiger inhaltlicher Kontrolle übernehmen wir keine Haftung für die Inhalte externer Links.
<G-vec00078-001-s678><accept.übernehmen><en> The minimum charge for credit card is 100€ and there will be a charge of 2% per each transaction.CANCELLATIONS: WE UNDERSTAND THAT SOMETIMES PLANS CHANGE, BUT ALL CANCELLATIONS SHOULD BE DONE ONE WEEK PRIOR TO YOUR ARRIVAL, OTHERWISE YOUR WHOLE RESERVATION WILL BE CHARGED (NO-REFUNDS). APARTMENTS SERENITY MAKES NO-REFUNDS FOR NO SHOWS OR EARLY CHECKOUTS.ONCE YOU MAKE A RESERVATION WE DO NOT ACCEPT ANY CHANGES. IF YOU WANT TO MAKE ANY CHANGES YOU HAVE TO CANCEL THE RESERVATION AND MAKE A NEW ONE.
<G-vec00078-001-s678><accept.übernehmen><de> Die Mindestgebühr für eine Kreditkarte 100 € und es wird eine Gebühr von 2% pro Transaktion.RÜCKTRITT: Wir verstehen, dass manchmal PLÄNE ändern, aber alle Stornierungen zu tun eine Woche vor Ihrer Ankunft, ansonsten wird Ihr gesamter Reservierung berechnet (BE NO-Erstattungen).Apartments Serenity GIBT KEINE-Erstattungen für die No-Show oder verfrühter Kassen.ONCE Sie eine Buchung übernehmen wir keine Änderungen vornehmen.If You Wanna Ihre Änderungen die Reservierung zu stornieren und eine neue zu machen.Nachdem Sie erfolgreich eine Reservierung bitten wir schicken Ihnen Anweisungen, um Ihre E-Mail-Adresse.
<G-vec00078-001-s679><accept.übernehmen><en> We do not accept responsibility for any information about the service that we pass on to you in good faith.
<G-vec00078-001-s679><accept.übernehmen><de> Wir übernehmen keine Verantwortung für Informationen über den Service, die wir Ihnen in gutem Glauben übermitteln.
<G-vec00078-001-s680><accept.übernehmen><en> Where such flaws, faults or errors cause a game to be interrupted in circumstances where it cannot be restarted from exactly the same position without any detriment to You or other players, we will take all reasonable steps to treat You in a fair manner.17.2 We do not accept any liability whatsoever for IT failures which are caused by the equipment which You or other players are using to access the Website or faults which relate to Your or their internet service provider.
<G-vec00078-001-s680><accept.übernehmen><de> Wenn solche Defekte, Mängel oder Fehlfunktionen zu einer Unterbrechung eines Spiels führen, so dass es nicht ohne Nachteil für Sie oder andere Spieler am selben Punkt wiederaufgenommen werden kann, werden wir alle angemessenen Maßnahmen ergreifen, um Sie fair zu behandeln.17.2 Wir übernehmen keine Haftung für EDV-Fehlfunktionen, die durch die technische Ausrüstung verursacht werden, die Sie oder andere Spieler zum Zugang der Webseite verwenden, oder für Funktionsfehler in Zusammenhang mit Ihrem oder deren Internetdienstleister.
<G-vec00078-001-s681><accept.übernehmen><en> How you benefit: You can accept it as a complete package included in your offer without much effort on your part.
<G-vec00078-001-s681><accept.übernehmen><de> Ihr Vorteil: Sie können dieses als Komplettpaket ohne großen Aufwand in Ihr Angebot übernehmen.
<G-vec00078-001-s682><accept.übernehmen><en> I believe that the main reason for Israeli pressure on the Palestinians is primarily defensive and not, as many suggest, to aggressively suppress the Palestinians so they can make a land grab. I accept that some Zionists are using the violence to make a land grab, but here's the thing.
<G-vec00078-001-s682><accept.übernehmen><de> Ich glaube, dass der Hauptgrund für Israels Druck auf die Palästinenser in erster Linie defensiv ist und nicht, wie viele vermuten, um die Palästinenser aggressiv zu unterjochen, damit sie das Land übernehmen können.
<G-vec00078-001-s683><accept.übernehmen><en> Nonetheless, the author and publisher can accept no warranty or liability for the accuracy, reliability, completeness and actuality of the information.
<G-vec00078-001-s683><accept.übernehmen><de> Dennoch übernehmen Autoren und Herausgeber keine Gewähr und Haftung für die Richtigkeit, Zuverlässigkeit, Vollständigkeit und Aktualität der Information.
<G-vec00078-001-s684><accept.übernehmen><en> Gericke does not accept any liability for the accuracy and completeness of the information on this web site.
<G-vec00078-001-s684><accept.übernehmen><de> Gericke übernimmt keine Haftung für Richtigkeit und Vollständigkeit der Informationen auf dieser Website.
<G-vec00078-001-s685><accept.übernehmen><en> 2.8 The customer shall ensure that they or a representative is available to accept the delivery.
<G-vec00078-001-s685><accept.übernehmen><de> 2.8 Der Besteller hat dafür Sorge zu tragen, dass er oder eine Vertretungsperson die Lieferung übernimmt.
<G-vec00078-001-s686><accept.übernehmen><en> The Canadian Securities Exchange does not accept responsibility for the adequacy or accuracy of this press release.
<G-vec00078-001-s686><accept.übernehmen><de> Die Canadian Securities Exchange übernimmt keine Verantwortung für die Angemessenheit oder Genauigkeit dieser Meldung.
<G-vec00078-001-s687><accept.übernehmen><en> WOTRANT does not accept responsibility for unauthorized access to the private part of the Website through use of passwords in the name of the user.
<G-vec00078-001-s687><accept.übernehmen><de> WOTRANT übernimmt keine Haftung für den unrechtmäßigen Zugriff auf den privaten Teil der Webseite durch die Verwendung der Zugangsdaten und des Benutzernamens.
<G-vec00078-001-s688><accept.übernehmen><en> Secury-surf.com does not accept responsibility for the activities of the third parties which are advertised, which means that you use the search engine at your own risk.
<G-vec00078-001-s688><accept.übernehmen><de> Secury-surf.com übernimmt keine Verantwortung für die Aktivitäten der Drittanbieter, die dargestellt werden, was bedeutet, dass Sie die Suchmaschine auf eigenes Risiko verwenden.
<G-vec00078-001-s689><accept.übernehmen><en> HES-SO does not accept any liability for the uninterrupted availability of the functions on the bao-genre.hes-so.ch website, nor that the browser in question shall be free from viruses or any other harmful elements.
<G-vec00078-001-s689><accept.übernehmen><de> HES-SO übernimmt keine Haftung und keine Gewährleistung dafür, dass die auf der Website bao-genre.hes-so.ch verfügbaren Funktionen nie unterbrochen werden oder dass im jeweiligen Webbrowser keine Viren oder andere schädliche Bestandteile auftreten.
<G-vec00078-001-s690><accept.übernehmen><en> However the organizers neither will nor accept responsibility for lost or stolen valuables.
<G-vec00078-001-s690><accept.übernehmen><de> Der Veranstalter übernimmt keine Haftung für verlorene oder abhanden gekommene Wertsachen.
<G-vec00078-001-s691><accept.übernehmen><en> Coperion will accept no liability for damage incurred by the applicant by transfer of personal data over the Internet.
<G-vec00078-001-s691><accept.übernehmen><de> Coperion übernimmt keinerlei Haftung, falls der Bewerber durch die Übermittlung von persönlichen Daten über das Internet Schaden nimmt.
<G-vec00078-001-s692><accept.übernehmen><en> Whilst no brokers are directly connected with the Payoneer services, the vast majority accept MasterCard payments to fund accounts.
<G-vec00078-001-s692><accept.übernehmen><de> Während keine Makler direkt mit den Payoneer Diensten verbunden sind, übernimmt die überwiegende Mehrheit Mastercard Zahlungen Konten zu finanzieren.
<G-vec00078-001-s693><accept.übernehmen><en> If the kid does not accept the water which passed a filtration, so so far in additional liquid need is not present, and to the child breast milk suffices.
<G-vec00078-001-s693><accept.übernehmen><de> Wenn der Kleine das Wasser, die vergangene Filtrierung nicht übernimmt, bedeutet, bis in der zusätzlichen Flüssigkeit der Notwendigkeit gibt es, und dem Kind der völlig ausreichend Brustmilch.
<G-vec00078-001-s694><accept.übernehmen><en> The TSX Venture Exchange has not reviewed and does not accept responsibility for the adequacy or accuracy of this release
<G-vec00078-001-s694><accept.übernehmen><de> Diese Informationen wurden von der TSX Venture Exchange nicht geprüft und sie übernimmt keine Verantwortung für ihre Angemessenheit oder Genauigkeit.
<G-vec00078-001-s695><accept.übernehmen><en> Furthermore, the KION Group cannot guarantee that future performance and actual profits generated will be consistent with the stated assumptions and estimates and can accept no liability in this regard.
<G-vec00078-001-s695><accept.übernehmen><de> Ferner übernimmt die KIONGroup keine Gewährleistung und keine Haftung dafür, dass die künftige Entwicklung und die künftig erzielten tatsächlichen Ergebnisse mit den geäußerten Annahmen und Schätzungen übereinstimmen werden.
<G-vec00078-001-s696><accept.übernehmen><en> The TSX Venture Exchange does not accept responsibility for the adequacy or accuracy of this news release.
<G-vec00078-001-s696><accept.übernehmen><de> Die TSX Venture Exchange übernimmt keine Verantwortung für die Richtigkeit oder Genauigkeit dieser Pressemitteilung.
<G-vec00078-001-s697><accept.übernehmen><en> """Bruce Winfield"" President, CEO & Director The TSX Venture Exchange does not accept responsibility for the adequacy or accuracy of this release."
<G-vec00078-001-s697><accept.übernehmen><de> """Bruce Winfield"" President & CEO Die TSX Venture Exchange hat diese Pressemitteilung nicht überprüft und übernimmt keine Verantwortung für die Richtigkeit oder Genauigkeit des Inhaltes."
<G-vec00078-001-s698><accept.übernehmen><en> Sellaround GmbH shall not accept responsibility for the design, content or any link to Sellaround or Sellaround GmbH from the websites of third parties.
<G-vec00078-001-s698><accept.übernehmen><de> Die Sellaround GmbH übernimmt keine Verantwortung für Darstellung, Inhalt oder irgendeiner Verbindung zu Sellaround oder Sellaround GmbH in Webseiten Dritter.
<G-vec00078-001-s699><accept.übernehmen><en> Please note that the EPO does not accept any responsibility for the accuracy or quality of the data displayed, including but not limited to their completeness or fitness for specific purposes.
<G-vec00078-001-s699><accept.übernehmen><de> Das EPA übernimmt keine Gewähr für die Richtigkeit oder die Qualität der angezeigten Daten und schließt insbesondere jegliche Haftung für deren Vollständigkeit und Eignung für bestimmte Zwecke aus.
<G-vec00078-001-s700><accept.übernehmen><en> As a consequence, in terms of the accuracy, completeness and up-to-date status of these web pages, Cherry GmbH refuses to accept any liability whatsoever for material or notional damage arising from any use of inaccurate or incomplete information within the context of this Internet facility.
<G-vec00078-001-s700><accept.übernehmen><de> Die Cherry GmbH übernimmt deshalb hinsichtlich der Richtigkeit, Vollständigkeit und Aktualität ihrer Webseiten keine Haftung für Schäden materieller oder ideeller Art, die durch die Nutzung fehlerhafter oder unvollständiger Informationen innerhalb dieses Internetangebotes entstehen.
<G-vec00078-001-s701><accept.übernehmen><en> Messerli shall also not accept any liability for the delayed arrival of such objects.
<G-vec00078-001-s701><accept.übernehmen><de> Messerli übernimmt auch keinerlei Haftung für nicht rechtzeitiges Eintreffen solcher Gegenstände.
<G-vec00078-001-s702><accept.übernehmen><en> CAUTIONARY DISCLAIMER STATEMENT: The Canadian Securities Exchange has not reviewed and does not accept responsibility for the adequacy or accuracy of the content of this news release .
<G-vec00078-001-s702><accept.übernehmen><de> HAFTUNGSAUSSCHLUSS UND WARNHINWEISE: Die Canadian Securities Exchange hat diese Meldung nicht geprüft und übernimmt keine Verantwortung für die Richtigkeit und Angemessenheit der Meldung.
<G-vec00120-002-s095><accept.akzeptieren><en> Read The telephone number is: By calling the phone number I declare that I am of age and accept the terms and conditions of use and privacy policy.
<G-vec00120-002-s095><accept.akzeptieren><de> Telefonnummer: Mit dem Anruf der Telefonnummer erkläre ich, dass ich volljährig bin und akzeptiere die Allgemeinen Geschäftsbedingungen und die Datenschutzerklärung.
<G-vec00120-002-s096><accept.akzeptieren><en> I understand and accept that under no circumstances will Nimfomane Webcam or any of its related, affiliated companies be liable for any direct, indirect, incidental, special, consequential or punitive damages that result from any false disclosures that may arise, violation of the rights of Subscribers, prostitution, pedophilia, child pornography, illegal abuse, exploitation or traffic of women and/or children.
<G-vec00120-002-s096><accept.akzeptieren><de> Ich verstehe und akzeptiere, dass unter keinen Umständen BongaChats - oder irgendeines seiner in Verbindung stehenden Vertragsfirmen haftet für jedweden direkten, indirekten, zufälligen, speziellen, Folge- oder ersatzpflichtigen Schaden, die aus jedweder eventuell auftretenden, falschen Offenlegung, Verletzung der Rechte der Abonnenten, Prostitution, Pädophilie, Kinderpornografie, illegalem Missbrauch, Ausbeutung oder Menschenhandel von Frauen und/oder Kindern resultieren.
<G-vec00120-002-s097><accept.akzeptieren><en> I acknowledge the Privacy Policy and hereby accept the Terms & Conditions.
<G-vec00120-002-s097><accept.akzeptieren><de> Ich habe die Datenschutzerklärung zur Kenntnis genommen und akzeptiere die AGB.
<G-vec00120-002-s098><accept.akzeptieren><en> I accept that have no claim for damages.
<G-vec00120-002-s098><accept.akzeptieren><de> Ich akzeptiere, dass ich keinerlei Anspruch auf Schadenersatz habe.
<G-vec00120-002-s099><accept.akzeptieren><en> If you agree, select I accept the terms in the license agreement.
<G-vec00120-002-s099><accept.akzeptieren><de> Wenn Sie einverstanden sind, wählen Sie Ich akzeptiere die Bedingungen in der Lizenzvereinbarung und klicken Sie auf Weiter.
<G-vec00120-002-s100><accept.akzeptieren><en> Accept, rather than deny, that you have a hard time dealing with annoying people, and that some of these people are in your family.
<G-vec00120-002-s100><accept.akzeptieren><de> Akzeptiere, anstatt zu leugnen, dass es dir schwer fällt mit lästigen Menschen umzugehen, und dass einige dieser Menschen zu deiner Familie gehören.
<G-vec00120-002-s101><accept.akzeptieren><en> I accept the terms and conditions of the ligita.
<G-vec00120-002-s101><accept.akzeptieren><de> Ich akzeptiere die allgemeinen Bedingungen der ligita.
<G-vec00120-002-s102><accept.akzeptieren><en> Furthermore, I hereby accept the Special Insurance Provisions.
<G-vec00120-002-s102><accept.akzeptieren><de> Zudem akzeptiere ich die Besonderen Vertragsbedingungen.
<G-vec00120-002-s103><accept.akzeptieren><en> I accept alone and offer practically everything that will make you leave happy and want to come back.
<G-vec00120-002-s103><accept.akzeptieren><de> Ich akzeptiere alleine und biete praktisch alles an, was dich glücklich macht und zurückkommen will.
<G-vec00120-002-s104><accept.akzeptieren><en> The customer declares to have read and accept the rights and obligations pertaining thereto.
<G-vec00120-002-s104><accept.akzeptieren><de> Der Kunde erklärt, habe gelesen und akzeptiere die Rechte und Pflichten in Bezug dazu.
<G-vec00120-002-s105><accept.akzeptieren><en> "OPT-IN" -- Some Offers may be presented to the subscriber with the option to express the subscriber's preference by either clicking or entering "accept" (alternatively "yes") or "decline" (alternatively "no").
<G-vec00120-002-s105><accept.akzeptieren><de> "OPT-IN" -- Einige Angebote werden dem Abonnenten vielleicht geschickt mit der Option, die Vorlieben des Abonnenten entweder durch Klicken oder der Eingabe von "Akzeptiere" (alternativ "ja") oder "Ablehnen" (alternativ "nein") auszudrücken.
<G-vec00120-002-s106><accept.akzeptieren><en> Subscribe to receive the latest news, promotions and offers I accept the privacy policy of CELO and the subscription to the newsletter.
<G-vec00120-002-s106><accept.akzeptieren><de> Ich akzeptiere die Nutzungsbedingungen der CELO Gruppe und möchte Ihren Newsletter abonnieren.
<G-vec00120-002-s107><accept.akzeptieren><en> I accept the electronic storage of my personal data according to the privacy notice.
<G-vec00120-002-s107><accept.akzeptieren><de> Ich akzeptiere die elektronische Speicherung meiner Daten gemäß den Datenschutzbestimmungen.
<G-vec00120-002-s108><accept.akzeptieren><en> By continuing, I accept the General Terms and Conditions (including the privacy statement)
<G-vec00120-002-s108><accept.akzeptieren><de> Durch die weitere Nutzung der Website akzeptiere ich die AGB (einschließlich der Datenschutzerklärung).
<G-vec00120-002-s109><accept.akzeptieren><en> GIBAATWWXXX I acknowledge the Privacy Policy and hereby accept the Terms & Conditions.
<G-vec00120-002-s109><accept.akzeptieren><de> GIBAATWWXXX Ich habe die Datenschutzerklärung zur Kenntnis genommen und akzeptiere die AGB.
<G-vec00120-002-s110><accept.akzeptieren><en> I do not accept men under the influence of alcohol or other drugs.
<G-vec00120-002-s110><accept.akzeptieren><de> Ich akzeptiere keine Männer unter dem Einfluss von Alkohol oder anderen Drogen.
<G-vec00120-002-s111><accept.akzeptieren><en> The consent to data processing and data transfer I have read and accept them.
<G-vec00120-002-s111><accept.akzeptieren><de> Die Zustimmungserklärung zur Datenverarbeitung und Datenübermittlung habe ich gelesen und akzeptiere sie.
<G-vec00120-002-s112><accept.akzeptieren><en> Accept that you do it for Me.
<G-vec00120-002-s112><accept.akzeptieren><de> Akzeptiere es, dass du es für Mich tust.
<G-vec00120-002-s113><accept.akzeptieren><en> Join our newsletter I have read the Privacy Policy and accept the conditions
<G-vec00120-002-s113><accept.akzeptieren><de> Ich habe die Datenschutzerklärung gelesen und akzeptiere die Bedingungen.
<G-vec00120-002-s114><accept.akzeptieren><en> One of the pillars of Thatcherism, for instance, is portraying working class institutions as factors limiting democracy and individual freedom (to accept any job and any working condition).
<G-vec00120-002-s114><accept.akzeptieren><de> Zum Beispiel war es ein Anliegen des Thatcherismus, zu versuchen, die Arbeiterinstitutionen als Faktoren darzustellen, die die Demokratie und die individuelle Freiheit (die Freiheit, jede Arbeit und jede Arbeitsbedingung zu akzeptieren) einschränken.
<G-vec00120-002-s115><accept.akzeptieren><en> You see people will accept lies if their lives get better.
<G-vec00120-002-s115><accept.akzeptieren><de> Schauen Sie, die Menschen akzeptieren Lügen, wenn ihr Leben besser wird.
<G-vec00120-002-s116><accept.akzeptieren><en> When you register a GuestReady account, you accept the Terms and Conditions of our Website stated herein.
<G-vec00120-002-s116><accept.akzeptieren><de> Wenn Sie ein GuestReady-Konto registrieren, akzeptieren Sie die hier aufgeführten Allgemeinen Geschäftsbedingungen unserer Website.
<G-vec00120-002-s117><accept.akzeptieren><en> They do not accept any rules and stereotypes.
<G-vec00120-002-s117><accept.akzeptieren><de> Sie akzeptieren nicht eine der Regeln und Stereotypen.
<G-vec00120-002-s118><accept.akzeptieren><en> The Bag in Box is slowly opening its way in our sector, this is a reality that we can not deny, and as long as we are able to accept it, will occupy a place in the system of packaging and distribution of our wines.
<G-vec00120-002-s118><accept.akzeptieren><de> Die Bag in Box entwickelt sich langsam in unserer Branche, eine Realität, die wir nicht leugnen können, und in dem Maße, wie wir sie akzeptieren können, wird sie einen Platz im Verpackungs- und Vertriebssystem unserer Weine einnehmen.
<G-vec00120-002-s119><accept.akzeptieren><en> >>back to top Conduct For the benefit of everyone on your vacation, Latin Deluxe reserves the right to accept or reject any vacation participant and to remove any participant whose conduct is deemed incompatible with the interests of the other participants.
<G-vec00120-002-s119><accept.akzeptieren><de> >>Zurück zum Anfang BENEHMEN Im Interesse eines jeden Reiseteilnehmers behält sich Latin Deluxe das Recht vor jeglichen Teilnehmer zu akzeptieren oder abzulehnen und jeden Teilnehmer zum Abbruch seines Urlaubs zu zwingen, dessen Benehmen unvereinbar mit den Interessen der übrigen Reisenden erachtet wird.
<G-vec00120-002-s120><accept.akzeptieren><en> If you continue to use this website without changing your cookie settings or click "Accept" below you are consenting to this.
<G-vec00120-002-s120><accept.akzeptieren><de> Wenn du diese Website ohne Änderung der Cookie-Einstellungen verwendest oder auf "Akzeptieren" klickst, erklärst du sich damit einverstanden.
<G-vec00120-002-s121><accept.akzeptieren><en> Please note that you must accept our Terms of Use before using the AOK Pregnancy App.
<G-vec00120-002-s121><accept.akzeptieren><de> Bitte beachten Sie, dass Sie vor Nutzung der AOK Schwanger App unsere Nutzungsbedingungen akzeptieren müssen.
<G-vec00120-002-s122><accept.akzeptieren><en> ICONINSIDER.COM — Shannen Doherty is attempting to accept her body following battle with cancer.
<G-vec00120-002-s122><accept.akzeptieren><de> ICONINSIDER — Shannen Doherty versucht ihren Körper nach dem Kampf gegen den Krebs zu akzeptieren.
<G-vec00120-002-s123><accept.akzeptieren><en> All senders Click this button to specify that the recipient can accept messages from all senders.
<G-vec00120-002-s123><accept.akzeptieren><de> Alle Absender Wählen Sie diese Option, um festzulegen, dass der Empfänger Nachrichten von allen Absendern akzeptieren kann.
<G-vec00120-002-s124><accept.akzeptieren><en> Some EU countries are reluctant to accept a system based on fair sharing and solidarity.
<G-vec00120-002-s124><accept.akzeptieren><de> Einige EU-Staaten weigern sich, ein System zu akzeptieren, das auf fairer Verteilung und Solidarität basiert.
<G-vec00120-002-s125><accept.akzeptieren><en> We will accept exchanges for a wrong size or color within 15 days of the original invoice date.
<G-vec00120-002-s125><accept.akzeptieren><de> • Austausch Wir akzeptieren Austausch für eine andere Größe oder Farbe innerhalb von 30 Tagen nach dem ursprünglichen Versand Versanddatum.
<G-vec00120-002-s126><accept.akzeptieren><en> Accept This website uses cookies to offer you a seamless experience.
<G-vec00120-002-s126><accept.akzeptieren><de> Akzeptieren Diese Website nutzt Cookies.
<G-vec00120-002-s127><accept.akzeptieren><en> You accept that TomTom may charge you for any shipping or postage costs incurred directly associated with returning the Product.
<G-vec00120-002-s127><accept.akzeptieren><de> Sie akzeptieren, dass TomTom Ihnen Versand- oder Portokosten, die direkt mit der Rücksendung des Produkts in Verbindung stehen, in Rechnung stellen kann.
<G-vec00120-002-s128><accept.akzeptieren><en> In stores that accept Google Pay as a payment method, it is sufficient to hold the mobile device to the POS terminal without having to open the boon app.
<G-vec00120-002-s128><accept.akzeptieren><de> So reicht es in Geschäften, die Google Pay als Zahlungsart akzeptieren, das mobile Endgerät an das Kassenterminal zu halten, ohne die boon-App öffnen zu müssen.
<G-vec00120-002-s129><accept.akzeptieren><en> Please allow cookies and accept our privacy policy by clicking Accept on the banner Odden Havn
<G-vec00120-002-s129><accept.akzeptieren><de> Bitte erlauben Sie Cookies und akzeptieren Sie unsere Datenschutzbestimmungen, indem Sie auf Akzeptieren oder diesen Banner klicken.
<G-vec00120-002-s130><accept.akzeptieren><en> According to the British Foreign Minister, in this case, any hope would be that the House of Commons would accept the Brexit Agreement, especially if the Members “dipped” about what “cataclysm” would entail without the agreement to leave the EU.
<G-vec00120-002-s130><accept.akzeptieren><de> Dem britischen Außenminister zufolge besteht in diesem Fall jede Hoffnung in der Annahme, dass das Unterhaus das Brexit-Abkommen akzeptieren würde, insbesondere wenn sich die Abgeordneten darauf einlassen, was “Katastrophe” ohne die Zustimmung zum Austritt aus der EU bedeuten würde.
<G-vec00120-002-s131><accept.akzeptieren><en> Only in Homa Therapy do bees accept living under the protection of a roof.
<G-vec00120-002-s131><accept.akzeptieren><de> Nur mit Homa-Therapie akzeptieren die Bienen unter dem Schutz eines Daches zu leben.
<G-vec00120-002-s132><accept.akzeptieren><en> In the event that the return conditions are not adhered to, then the seller reserves the right to not accept the returned products.
<G-vec00120-002-s132><accept.akzeptieren><de> Sollten Rücktrittsmodalitäten nicht eingehalten werden, behält sich die Verkäuferin das Recht vor, die zurückgegebenen Produkte nicht zu akzeptieren.
<G-vec00120-002-s134><accept.akzeptieren><en> By using the site, you accept the use of cookies on our part.
<G-vec00120-002-s134><accept.akzeptieren><de> Abonnieren Sie Durch die Nutzung der Website akzeptieren Sie die Verwendung von Cookies unsererseits.
<G-vec00120-002-s136><accept.akzeptieren><en> Accept the End User License Agreement (EULA).
<G-vec00120-002-s136><accept.akzeptieren><de> Akzeptieren Sie den Endbenutzer-Lizenzvertrag (EULA).
<G-vec00120-002-s138><accept.akzeptieren><en> View and accept the license agreement, if prompted.
<G-vec00120-002-s138><accept.akzeptieren><de> Lesen und akzeptieren Sie bei Aufforderung den Lizenzvertrag.
<G-vec00120-002-s139><accept.akzeptieren><en> Read and accept the Novell SUSE Linux Enterprise Server software license agreement.
<G-vec00120-002-s139><accept.akzeptieren><de> Lesen und akzeptieren Sie die Software-Lizenzvereinbarung für Novell SUSE Linux Enterprise Server.
<G-vec00120-002-s140><accept.akzeptieren><en> Accept that most of successful expatriate professionals are bilingual and many of them bi-cultural.
<G-vec00120-002-s140><accept.akzeptieren><de> Akzeptieren Sie, dass die meisten erfolgreichen Expatriate-Profis zweisprachig sind und viele von ihnen bi-kulturell sind.
<G-vec00120-002-s141><accept.akzeptieren><en> Accept the terms of use
<G-vec00120-002-s141><accept.akzeptieren><de> Akzeptieren Sie die Nutzungsbedingungen.
<G-vec00120-002-s142><accept.akzeptieren><en> Accept the terms in the license agreement, then click Next to continue.
<G-vec00120-002-s142><accept.akzeptieren><de> Akzeptieren Sie die Bedingungen der Lizenzvereinbarung und klicken Sie anschließend auf Next, um fortzufahren.
<G-vec00120-002-s144><accept.akzeptieren><en> Accept no fillers or artificial components.
<G-vec00120-002-s144><accept.akzeptieren><de> Akzeptieren Sie keine Füllstoffe oder künstliche Zutaten.
<G-vec00120-002-s146><accept.akzeptieren><en> Accept payments with your PC, tablet, or smartphone
<G-vec00120-002-s146><accept.akzeptieren><de> Akzeptieren Sie Zahlungen mit dem Computer, Tablet oder Handy.
<G-vec00120-002-s147><accept.akzeptieren><en> Review and accept the Intel Software License Agreement.
<G-vec00120-002-s147><accept.akzeptieren><de> Lesen und akzeptieren Sie die Intel Softwarelizenzvereinbarung.
<G-vec00120-002-s148><accept.akzeptieren><en> Read and accept the end user agreement to proceed.
<G-vec00120-002-s148><accept.akzeptieren><de> Lesen und akzeptieren Sie die Nutzungsbedingungen, um fortzufahren.
<G-vec00120-002-s149><accept.akzeptieren><en> Accept this request to make using Google maps easier.
<G-vec00120-002-s149><accept.akzeptieren><de> Akzeptieren Sie diese Anfrage, um die Bedienung von Google Maps zu erleichtern.
<G-vec00120-002-s151><accept.akzeptieren><en> By accepting these General Conditions, you understand and accept that any order, purchase or transaction is made exclusively between the Company and the Customer, and that Tictail AB, Tictail Inc — as a platform provider - is not responsible for any content, interactions or transactions made on alyonastorm.tictail.com.
<G-vec00120-002-s151><accept.akzeptieren><de> Indem Sie diese Geschäftsbedingungen akzeptieren, verstehen und akzeptieren Sie, dass alle Bestellungen, Käufe oder Transaktionen ausschließlich zwischen dem Unternehmen und dem Kunden abgeschlossen werden und dass Tictail AB, Tictail Inc – als Plattformanbieter – nicht für die Inhalte, Interaktionen oder Transaktionen auf familytreeshop.tictail.com verantwortlich ist.
<G-vec00120-002-s152><accept.akzeptieren><en> Once you accept and confirm availability, guest books and pays a booking fee to Homestay.com
<G-vec00120-002-s152><accept.akzeptieren><de> Sobald du die Verfügbarkeit akzeptierst und bestätigst, buchen die Gäste und bezahlen eine Buchungsgebühr an Homestay.com.
<G-vec00120-002-s153><accept.akzeptieren><en> If you continue to use this website, you accept this.
<G-vec00120-002-s153><accept.akzeptieren><de> Wenn du die Website weiter nutzt, akzeptierst du dies.
<G-vec00120-002-s154><accept.akzeptieren><en> If you are a child under the age where parental consent is required in your country, you should review the terms of this Privacy Charter with your parent or guardian to make sure you understand and accept it.
<G-vec00120-002-s154><accept.akzeptieren><de> Wenn Du ein Kind unter dem Alter bist, in dem die Einwilligung der Eltern in Deinem Land erforderlich ist, solltest Du die Bedingungen dieser Datenschutz-Charta mit einem Erziehungsberechtigten oder Vormund überprüfen, um sicherzustellen, dass Du sie verstehst und akzeptierst.
<G-vec00120-002-s155><accept.akzeptieren><en> If you do not accept cookies, this may restrict certain functions on our website.
<G-vec00120-002-s155><accept.akzeptieren><de> Beachte: Wenn Du keine Cookies akzeptierst, kann dies zu Funktionseinschränkungen unserer Angebote führen.
<G-vec00120-002-s156><accept.akzeptieren><en> You won't be able to get over a guy unless you accept what your relationship was.
<G-vec00120-002-s156><accept.akzeptieren><de> Du wirst nicht in der Lage sein, über den Typen hinwegzukommen, wenn du die Beziehung nicht als das akzeptierst, was sie war.
<G-vec00120-002-s157><accept.akzeptieren><en> By loading the video you accept the privacy policy of Vimeo.
<G-vec00120-002-s157><accept.akzeptieren><de> Durch das Laden des Videos akzeptierst Du die Datenschutzbestimmungen von Vimeo.
<G-vec00120-002-s158><accept.akzeptieren><en> If you accept the weather in the mind as it is, happiness will be present and will not go away.
<G-vec00120-002-s158><accept.akzeptieren><de> Wenn du das Wetter im Verstand akzeptierst, wie es gerade ist, wird das Glücklich-Sein gegenwärtig sein und nicht weggehen.
<G-vec00120-002-s159><accept.akzeptieren><en> You confirm with submitting this declaration, that you accept that any contribution the opinion of its author and that reflects the administrators, moderators and operator of the portal only for their own contributions.
<G-vec00120-002-s159><accept.akzeptieren><de> Du bestätigst mit Absenden dieser Einverständniserklärung, dass du akzeptierst, dass jeder Beitrag die Meinung seines Urhebers wiedergibt und dass die Administratoren, Moderatoren und Betreiber des Portal nur für ihre eigenen Beiträge verantwortlich sind.
<G-vec00120-002-s160><accept.akzeptieren><en> close By using our website, you accept the use of cookies to make your visit more pleasant, to offer you advertisements and content tailored to your interests, to allow you to share content on social networks, and to create visitor statistics for website optimization.
<G-vec00120-002-s160><accept.akzeptieren><de> Mounts Concept - Crowfall close Durch die Nutzung unserer Website akzeptierst du die Verwendung von Cookies, mit deren Hilfe wir dir für dich interessante Werbung und Inhalte anbieten können, du Inhalte in sozialen Netzwerken teilen kannst und wir Besucherstatistiken zur Optimierung der Website erstellen können.
<G-vec00120-002-s161><accept.akzeptieren><en> If you don’t want to accept the use of cookies, you’ll have to leave the website or block cookies in your browser.
<G-vec00120-002-s161><accept.akzeptieren><de> Wenn Du die Verwendung von Cookies nicht akzeptierst, musst Du die Website verlassen oder Cookies in Deinem Browser blockieren.
<G-vec00120-002-s162><accept.akzeptieren><en> If you'd like to continue exploring our site, please accept our Cookie Shaping jeans
<G-vec00120-002-s162><accept.akzeptieren><de> Wenn du weiter auf unserer Seite surfst, akzeptierst du die Cookie-Policy.
<G-vec00120-002-s163><accept.akzeptieren><en> You show the kid that you accept his feelings and empathize with him.
<G-vec00120-002-s163><accept.akzeptieren><de> Du zeigst dem Jungen, dass du seine Gefühle akzeptierst und dich in ihn einfühlst.
<G-vec00120-002-s164><accept.akzeptieren><en> When you accept this quest you have to clear the way from the castle to the factory in the north off all enemy troops.
<G-vec00120-002-s164><accept.akzeptieren><de> Wenn du dieses Quest akzeptierst, musst du den Weg vom Schloss bis zur Fabrik im Norden von allen feindlichen Truppen säubern.
<G-vec00120-002-s165><accept.akzeptieren><en> By clicking on the button "Send eMail" you accept the terms & conditions and the privacy statement
<G-vec00120-002-s165><accept.akzeptieren><de> BetreffDeine Nachricht Mit dem Klick auf "Email senden" akzeptierst du unsere Allgemeine Geschäftsbedingungen und die Datenschutzerklärung .
<G-vec00120-002-s166><accept.akzeptieren><en> COLLECTING Contact me with the contact form: Fill in the product code, that you want to collect the product in Lucerne and that you accept the GTC.
<G-vec00120-002-s166><accept.akzeptieren><de> Kontaktiere mich mit dem Kontaktformular: Gibt den Produktecode an, schreibe auf, dass du das Produkt in Luzern abholen möchtest und die AGBs akzeptierst.
<G-vec00120-002-s167><accept.akzeptieren><en> You accept that, because of how your childhood went, you have a predisposition to exaggerate in certain areas.
<G-vec00120-002-s167><accept.akzeptieren><de> Du akzeptierst, dass du aufgrund deiner Kindheit eine Neigung hast, in bestimmten Bereichen zu übertreiben.
<G-vec00120-002-s168><accept.akzeptieren><en> And even though you accept that it's not always easy having long hair, you embrace the struggles, because you simply couldn't imagine having your hair any other way.
<G-vec00120-002-s168><accept.akzeptieren><de> Share Und obwohl du akzeptierst, dass es nicht immer leicht ist, lange Haare zu haben, erträgst du die Mühen – weil du dir einfach nicht vorstellen kannst, deine Haare anders zu tragen.
<G-vec00120-002-s169><accept.akzeptieren><en> When signing in, you accept our Privacy Policy and Terms of Use.
<G-vec00120-002-s169><accept.akzeptieren><de> Mit deiner Anmeldung akzeptierst du unsere Datenschutzerklärung und die Nutzungsbedingungen.
<G-vec00120-002-s170><accept.akzeptieren><en> close By using our website, you accept the use of cookies to make your visit more pleasant, to offer you advertisements and content tailored to your interests, to allow you to share content on social networks, and to create visitor statistics for website optimization.
<G-vec00120-002-s170><accept.akzeptieren><de> Bestiarium - Crowfall close Durch die Nutzung unserer Website akzeptierst du die Verwendung von Cookies, mit deren Hilfe wir dir für dich interessante Werbung und Inhalte anbieten können, du Inhalte in sozialen Netzwerken teilen kannst und wir Besucherstatistiken zur Optimierung der Website erstellen können.
<G-vec00120-002-s171><accept.akzeptieren><en> Please note that the property does not accept bookings made by debit card.
<G-vec00120-002-s171><accept.akzeptieren><de> Bitte beachten Sie zudem, dass die Unterkunft keine Buchungen mit Debitkarte akzeptiert.
<G-vec00120-002-s172><accept.akzeptieren><en> The Company does not accept Player registrations and / or deposits and / or play from the following countries: Spain, Portugal, Hungary, Netherlands, Turkey, United States of America (and its territories), Czech Republic, Australia, Croatia, France (and its territories), Curacao, Netherlands Antilles, Ireland, Romania, Denmark, Greece or any other jurisdictions were registration and/or participation would be in conflict with any applicable laws or rules relating to Online Gambling.
<G-vec00120-002-s172><accept.akzeptieren><de> Das Unternehmen akzeptiert keine Registrierung und/oder Einzahlungen und/oder Einsätze von Spielern aus folgenden Ländern: Spanien, Portugal, Ungarn, Niederlande, Türkei, Vereinigte Staaten von Amerika (und Gebiete), Tschechische Republik, Australien, Kroatien, Frankreich (und Gebiete), Curacao, Niederländische Antillen, Irland, Rumänien, Dänemark, Griechenland oder andere Jurisdiktionen, in welchen die Registrierung und/oder Teilnahme einen Konflikt mit vorhandenen Gesetzen oder Regulierungen in Bezug auf Online Glücksspiel darstellen würde.
<G-vec00120-002-s173><accept.akzeptieren><en> When you try to use the Zune software, you can’t accept the Zune Terms of Service (TOS).
<G-vec00120-002-s173><accept.akzeptieren><de> Bei der Verwendung der Zune-Software können die Zune-Nutzungsbedingungen (TOS, Terms of Service) nicht akzeptiert werden.
<G-vec00120-002-s174><accept.akzeptieren><en> This property does not accept payments with American Express credit cards.
<G-vec00120-002-s174><accept.akzeptieren><de> Die Unterkunft akzeptiert keine Zahlungen mit Kreditkarten von American Express.
<G-vec00120-002-s175><accept.akzeptieren><en> Visitors can set their computer's browser to accept/reject all cookies or to alert whenever a cookie is offered, so that the visitor can assess whether or not to accept it.
<G-vec00120-002-s175><accept.akzeptieren><de> Besucher können den Browser ihres Computers so einstellen, dass er alle Cookies akzeptiert oder ablehnt oder dass er meldet, wenn ein Cookie angeboten wird, damit der Besucher entscheiden kann, ob er es akzeptiert oder nicht.
<G-vec00120-002-s177><accept.akzeptieren><en> Announcements Please note that this property does not accept bookings from non-married couples.
<G-vec00120-002-s177><accept.akzeptieren><de> Ankündigungen Bitte beachten Sie, dass die Unterkunft keine Buchungen von unverheirateten Paaren akzeptiert.
<G-vec00120-002-s178><accept.akzeptieren><en> Those who call this unilateral removal of missiles from Cuba "an action that saved mankind from World War", do actually accept the thesis of imperialist propaganda that the Soviet Union brought the world to the brink of nuclear war by the stationing of missiles in Cuba .
<G-vec00120-002-s178><accept.akzeptieren><de> Wer aber die einseitige Entfernung der Raketen aus Kuba eine Handlung, die die Menschheit vor dem Weltkrieg bewahrte, bezeichnet, der akzeptiert tatsächlich die These der imperialistischen Propaganda, dass die Sowjetunion durch die Stationierung dieser Raketen in Kuba die Welt an den Rand des Atomkriegs gebracht hätte.
<G-vec00120-002-s179><accept.akzeptieren><en> If the customer does not accept the changes, the customer will no longer be permitted to use abilio.
<G-vec00120-002-s179><accept.akzeptieren><de> Akzeptiert der Kunde die Änderungen nicht, kann er abilio nicht mehr weiter nutzen.
<G-vec00120-002-s180><accept.akzeptieren><en> discounts at McArthur Glen outlets in Italy Together with the card you will receive a detailed golf guide with all the golf clubs that accept the Italia Golf & More Card.
<G-vec00120-002-s180><accept.akzeptieren><de> Zusammen mit Ihrer persönlichen Italia Golf & More Card erhalten Sie von uns eine detaillierte Golf Guide mit sämtlichen Angaben der Golf Clubs, wo unsere Italia Golf & More Card akzeptiert wird.
<G-vec00120-002-s181><accept.akzeptieren><en> But the obstacles on her way, her shyness, her conflicts with the husband who does not want a "superior" woman, with the collective which does not accept her orders, are portrayed against the usual stereotypes with love for the character and with authenticity.
<G-vec00120-002-s181><accept.akzeptieren><de> Aber die Hindernisse auf ihrem Weg, ihre Schüchternheit, ihre Konflikte mit einem Ehemann, der keine ihm «überlegene» Frau will, mit dem Kolchoskollektiv, das ihre Anordnungen nicht akzeptiert, sind gegen die üblichen Klischees mit Liebe zur Figur und Authentizität dargestellt.
<G-vec00120-002-s182><accept.akzeptieren><en> Please be advised that certain sections or functionalities of this site may be inaccessible to you if your browser does not accept cookies.
<G-vec00120-002-s182><accept.akzeptieren><de> Bitte beachten Sie, dass bestimmte Teile oder Funktionen dieser Website möglicherweise nicht zugänglich sind, wenn Ihr Browser keine Cookies akzeptiert.
<G-vec00120-002-s183><accept.akzeptieren><en> In guaranteeing guests’ peace and quiet, the structure does not accept small guests under 12.
<G-vec00120-002-s183><accept.akzeptieren><de> Um den Gästen eine warme und entspannte Atmosphäre zu garantieren, akzeptiert das Hotel keine Kinder unter 12 Jahren.
<G-vec00120-002-s184><accept.akzeptieren><en> 6. Answer N (default) if asked if you want to accept maintainers version.
<G-vec00120-002-s184><accept.akzeptieren><de> Antwort N (vorgegeben), falls gefragt wird, ob die Maintainer-Version akzeptiert werden soll.
<G-vec00120-002-s185><accept.akzeptieren><en> EuroSlots EuroSlots does not accept customers from USA.
<G-vec00120-002-s185><accept.akzeptieren><de> EuroSlots EuroSlots akzeptiert keine Kunden aus Vereinigte Staaten.
<G-vec00120-002-s186><accept.akzeptieren><en> Your name, address, telephone number, and a statement that you consent to the jurisdiction of the Federal District Court for the judicial district in which your address is located or, if your address is outside of the United States, for any judicial district in which THEBLAZE may be found, and that you will accept service of process from the person who provided notification of the alleged infringement or an agent of such person.
<G-vec00120-002-s186><accept.akzeptieren><de> d) Name, Adresse und Telefonnummer des mutmaßlichen Rechtsverletzers und eine Erklärung, dass der mutmaßliche Rechtsverletzer sich der Zuständigkeit des Bundesgerichts für den Gerichtsbezirk unterwirft, in dem sich die Adresse des mutmaßlichen Rechtsverletzers befindet, oder wenn sich dessen Adresse außerhalb der Vereinigten Staaten befindet, der Zuständigkeit eines Gerichtsbezirks, in dem HubSpot präsent ist, sowie eine Erklärung, dass der mutmaßliche Rechtsverletzer eine Klagezustellung von der Person (oder ihrem Vertreter) akzeptiert, von der die Meldung eingereicht wurde.
<G-vec00120-002-s187><accept.akzeptieren><en> Yes. Sebra does not accept complaints about products that have been damaged due to carelessness / accident, for instance If a product is dropped or hit against hard materials such as clinks or wood flooring.
<G-vec00120-002-s187><accept.akzeptieren><de> Ja, Sebra akzeptiert keine Reklamationen bezüglich Produkten, die durch Achtlosigkeit / Missgeschicke beschädigt werden.Beispielsweise wenn ein Produkt herunter fällt, oder gegen harte Materialien wie Glas oder Holzböden stößt.
<G-vec00120-002-s188><accept.akzeptieren><en> Prior to any material changes coming into effect, you will be requested to confirm that you have read and accept the new terms and conditions.
<G-vec00120-002-s188><accept.akzeptieren><de> Vor dem Inkrafttreten wesentlicher Änderungen werden Sie aufgefordert zu bestätigen, dass Sie die neuen Bedingungen gelesen und akzeptiert haben.
<G-vec00120-002-s189><accept.akzeptieren><en> I have read and accept the Terms and Conditions and the data protections notice.*
<G-vec00120-002-s189><accept.akzeptieren><de> Ich habe die AGBs und Hinweise zum Datenschutz gelesen und akzeptiert.
<G-vec00120-002-s228><accept.annehmen><en> Click on the Accept button in the Mila Partner App to accept the request.
<G-vec00120-002-s228><accept.annehmen><de> Durch Klicken auf den Annahme-Button in der Mila Partner App wird die Anfrage angenommen.
<G-vec00120-002-s229><accept.annehmen><en> We will not accept packages sent without postage paid or as cash on delivery.
<G-vec00120-002-s229><accept.annehmen><de> Unfrankierte Rücksendungen oder Sendungen ohne Nachnahme werden nicht angenommen.
<G-vec00120-002-s230><accept.annehmen><en> Overstock was launched back in 1999 to sell surplus and returned merchandise online and became a “pioneer” in the crypto space by becoming one of the first major companies to accept Bitcoin (BTC) in 2014.
<G-vec00120-002-s230><accept.annehmen><de> Overstock wurde 1999 gegründet und verkaufte zunächst Restposten und retournierte Waren, später wurde die Firma dann zu einem „Pionier“ der Krypto-Branche, indem sie eines der ersten großen Unternehmen war, das ab 2014 Bitcoin (BTC) als Zahlungsmittel angenommen hat.
<G-vec00120-002-s232><accept.annehmen><en> You can configure your browser to inform you about the use of cookies so that you can decide on a case-by-case basis whether to accept or reject a cookie.
<G-vec00120-002-s232><accept.annehmen><de> Sie können die Einstellungen Ihres Browsers so konfigurieren, dass Cookies gar nicht oder nur eingeschränkt von diesem angenommen und gespeichert werden.
<G-vec00120-002-s233><accept.annehmen><en> To accept the offer, investors can exercise their conversion rights prematurely within the offer period.
<G-vec00120-002-s233><accept.annehmen><de> Das Angebot kann dadurch angenommen werden, dass die Investoren ihr Wandlungsrecht innerhalb der Angebotsfrist vorzeitig ausüben.
<G-vec00120-002-s234><accept.annehmen><en> Operators accept the call in your name, take down caller information, then pass it to your dealership the next working day for processing.
<G-vec00120-002-s234><accept.annehmen><de> Die Anrufe werden in Ihrem Namen angenommen, die Daten des Anrufers notiert und am nächsten Arbeitstag zur Bearbeitung in Ihr Autohaus weitergeleitet.
<G-vec00120-002-s235><accept.annehmen><en> De facto no single human being is saved, unless they personally accept this offer of God’s for themselves and actually believe that this sacrifice of the Son of God has been offered for their own sins as well.
<G-vec00120-002-s235><accept.annehmen><de> De facto ist kein einziger Mensch gerettet, solange er dieses Angebot Gottes nicht auch für sich persönlich angenommen hat und tatsächlich daran glaubt, dass dieses Opfer des Sohnes Gottes auch für seine eigenen Sünden erbracht worden ist.
<G-vec00120-002-s236><accept.annehmen><en> It barely went well, since she did not want to accept the parcel (”I didn’t order anything and I do NOT expect any parcel!”).
<G-vec00120-002-s236><accept.annehmen><de> Es ging gerade noch mal gut, denn sie hätte das Paket fast nicht angenommen (”Ich habe nichts bestellt!”).
<G-vec00120-002-s237><accept.annehmen><en> None of us would be here if we hadn't heard a word and would not accept it.
<G-vec00120-002-s237><accept.annehmen><de> Keiner von uns wäre hier, wenn wir nicht hörten das Wort, und nicht angenommen hätten.
<G-vec00120-002-s239><accept.annehmen><en> Mr President, I am sorry that we are not going to accept our report in toto.
<G-vec00120-002-s239><accept.annehmen><de> Herr Präsident, ich bedaure, daß unser Bericht nicht in toto angenommen werden wird.
<G-vec00120-002-s240><accept.annehmen><en> The timer starts as soon as you accept a task.
<G-vec00120-002-s240><accept.annehmen><de> Die Stoppuhr startet direkt nachdem Sie die Aufgabe angenommen haben.
<G-vec00120-002-s241><accept.annehmen><en> - We accept bookings for pitches for minimum stays of 7 nights with 2 paying adults (from 09/08/2014 to 23/08/2014 minimum stay of 14 nights).
<G-vec00120-002-s241><accept.annehmen><de> Es werden auch Buchungen für Stellplätze für einen Mindestaufenthalt von 7 Nächten für 2 zahlende Erwachsene angenommen (von 09.08.2014 bis 23.08.2014 ist der Mindestaufenthalt 14 Nächte).
<G-vec00120-002-s242><accept.annehmen><en> But the mayor didn’t accept this money, for example, to create a fund for the victims of the latest fires, so that his council could support the citizens who voted for him in rebuilding their houses.
<G-vec00120-002-s242><accept.annehmen><de> Nein, der Bürgermeister hat das Geld nicht angenommen, um einen Fond für die Opfer der letzten Waldbrände aufzulegen, auf dass sein Rathaus die Bürger, die ihn gewählt haben, beim Wiederaufbau ihrer abgebrannten Häuser unterstützt.
<G-vec00120-002-s243><accept.annehmen><en> We do not accept credit cards or debit cards.
<G-vec00120-002-s243><accept.annehmen><de> Bancomat- und Kreditkarten werden nicht angenommen.
<G-vec00120-002-s244><accept.annehmen><en> By sending the invoice to you we accept your order.
<G-vec00120-002-s244><accept.annehmen><de> Deine Bestellung gilt erst dann als angenommen, wenn wir die Rechnung an Dich versandt haben.
<G-vec00120-002-s245><accept.annehmen><en> Please note that certain functions of this website may only function partially or not work at all if your browser is set to not accept cookies (from our website).
<G-vec00120-002-s245><accept.annehmen><de> Bitte beachten Sie, dass bestimmte Funktionen dieser Website möglicherweise nicht oder nur eingeschränkt genutzt werden können, wenn Ihr Browser so eingestellt ist, dass keine Cookies (unserer Website) angenommen werden.
<G-vec00120-002-s246><accept.annehmen><en> My mother had already known about it for a long time but I naturally did not accept it so well from her.
<G-vec00120-002-s246><accept.annehmen><de> Meiner Mutter war es schon länger bekannt, aber von ihr hab ich es natürlich nicht so gerne angenommen.
<G-vec00120-002-s267><accept.annehmen><en> If we do not accept the offer of the Purchaser within the time limit of § 2, these documents shall be returned to us without delay.
<G-vec00120-002-s267><accept.annehmen><de> Soweit wir das Angebot des Bestellers nicht innerhalb der Frist von § 2 annehmen, sind diese Unterlagen uns unverzüglich zurückzusenden.
<G-vec00120-002-s268><accept.annehmen><en> Furthermore, you can set there your browser in such a way that you are informed about the placement of cookies as well as to be able to decide in each individual case whether you would like to accept a given cookie or not.
<G-vec00120-002-s268><accept.annehmen><de> Ferner können Sie Ihren Browser dort so einstellen, dass Sie über das Setzen von Cookies informiert werden und jeweils im Einzelnen darüber entscheiden können, ob Sie ein Cookie annehmen möchten oder nicht.
<G-vec00120-002-s269><accept.annehmen><en> With the credit approval, you will receive a first offer – an offer you should not accept immediately.
<G-vec00120-002-s269><accept.annehmen><de> Mit der Kreditzusage haben Sie ein erstes Angebot, das Sie nicht gleich annehmen sollten.
<G-vec00120-002-s270><accept.annehmen><en> Before he went to bed, he prayed to know if he should accept the call as bishop.
<G-vec00120-002-s270><accept.annehmen><de> Ehe er zu Bett ging, betete er, um zu wissen, ob er die Berufung als Bischof annehmen sollte.
<G-vec00120-002-s271><accept.annehmen><en> read more When you successfully completed phase 2, you receive a individual investment offer from Up to Eleven that you can accept or reject.
<G-vec00120-002-s271><accept.annehmen><de> Ist die zweite Phase erfolgreich absolviert, bekommst du ein individuelles Investment-Angebot von Up to Eleven, das du annehmen oder ablehnen kannst.
<G-vec00120-002-s272><accept.annehmen><en> I even felt rejected by my Father in heaven because He could not accept me with the burden of sin.
<G-vec00120-002-s272><accept.annehmen><de> Ich fühlte mich sogar von meinem Vater im Himmel verlassen, weil er mich nicht mit der Last der Sünde annehmen konnte.
<G-vec00120-002-s273><accept.annehmen><en> If you do not respond to our e-mail with the counter-offer within 14 days, i. e. do not expressly accept or reject it, we assume that you want to accept our counter-offer.
<G-vec00120-002-s273><accept.annehmen><de> Wenn Sie auf unsere E-Mail mit dem Gegenangebot nicht innerhalb von 14 Tagen reagieren, dieses also weder ausdrücklich annehmen noch ablehnen, so gehen wir davon aus, dass Sie unser Gegenangebot annehmen wollen.
<G-vec00120-002-s275><accept.annehmen><en> Taking help in your browser for a description of how you can set the standard web browser to accept cookies and or reject it.
<G-vec00120-002-s275><accept.annehmen><de> Unter Hilfe in Ihrem Browser finden Sie eine Beschreibung, wie Sie die gängigen Browser entsprechend einstellen und Cookies annehmen oder ablehnen können.
<G-vec00120-002-s276><accept.annehmen><en> Never, in all of mankind’s past experiences, which are summed up by the term history, have so many millions of beings had to accept cannibalism as a way of life, in order to ensure their own survival.
<G-vec00120-002-s276><accept.annehmen><de> In den Erzählungen über das menschliche Dasein, die man mit dem Begriff der Geschichte zusammenfasst, mussten nie zuvor so viele Millionen Wesen wie heute den Kannibalismus als Lebensweise annehmen, um das eigene Überleben zu sichern.
<G-vec00120-002-s277><accept.annehmen><en> I cannot avoid to integrate it into my perception, I have to accept it in order to live up to it.
<G-vec00120-002-s277><accept.annehmen><de> Ich komme nicht umhin, sie in meine Wahrnehmung zu integrieren, ich muss mich ihrer annehmen, um der Sache gerecht zu werden.
<G-vec00120-002-s278><accept.annehmen><en> Many Kurds obviously don’t accept this invitation, and the authoritarian-kemalist policies are again put into practice.
<G-vec00120-002-s278><accept.annehmen><de> Viele KurdInnen scheinen die Einladung nicht annehmen zu wollen, woraufhin autoritär-kemalistische Maßnahmen ein Revival erleben.
<G-vec00120-002-s279><accept.annehmen><en> Verbal offer A verbal offer by the obligor suffices if the obligee has declared to him that he will not accept the performance, or if effecting the performance requires an act by the obligee, in particular if the obligee must collect the thing owed.
<G-vec00120-002-s279><accept.annehmen><de> Ein wörtliches Angebot des Schuldners genügt, wenn der Gläubiger ihm erklärt hat, dass er die Leistung nicht annehmen werde, oder wenn zur Bewirkung der Leistung eine Handlung des Gläubigers erforderlich ist, insbesondere wenn der Gläubiger die geschuldete Sache abzuholen hat.
<G-vec00120-002-s280><accept.annehmen><en> Aolite: We have 1~5 years for different equipments, and the warranty commences since we accept the balance.
<G-vec00120-002-s280><accept.annehmen><de> Aolite: Wir haben 1~5 Jahre für verschiedene Geräte, und die Garantie beginnt, da wir den Ausgleich annehmen.
<G-vec00120-002-s281><accept.annehmen><en> You must prepare a KMS host by first installing the licensing files (see Set up and activate Office KMS), and then activating the KMS host key before it can accept activation requests from clients.
<G-vec00120-002-s281><accept.annehmen><de> Der KMS-Host muss mit einem KMS-Hostschlüssel installiert und aktiviert werden, bevor er KMS-Aktivierungsanforderungen von KMS-Clients annehmen kann.
<G-vec00120-002-s282><accept.annehmen><en> At a waterfall you will ritually accept yourself as a complete, loving and sensual being in your original naturalness.
<G-vec00120-002-s282><accept.annehmen><de> An einem Wasserfall wirst du dich rituell als vollständiges, liebendes und sinnliches Wesen in deiner ursprünglichen Natürlichkeit annehmen.
<G-vec00120-002-s283><accept.annehmen><en> Order Acceptance Please note that there may be certain orders that we are unable to accept and must cancel.
<G-vec00120-002-s283><accept.annehmen><de> Bitte beachten Sie, dass es bestimmte Aufträge geben kann, die wir nicht annehmen können und stornieren müssen.
<G-vec00120-002-s284><accept.annehmen><en> The Publisher can accept this offer by activating the download link.
<G-vec00120-002-s284><accept.annehmen><de> Der Verlag kann dieses Angebot durch Freischaltung des Downloadlinks annehmen.
<G-vec00120-002-s285><accept.annehmen><en> As an urgent necessity, the Government must start serious negotiations with the opposition on a path out of the crisis and to this end accept the offers of mediation by countries from the region.
<G-vec00120-002-s285><accept.annehmen><de> Es ist dringend notwendig, dass die Regierung mit der Opposition ernsthafte Verhandlungen über einen Ausweg aus der Krise aufnimmt und dazu die existierenden Vermittlungsangebote von Ländern aus der Region annimmt.
<G-vec00120-002-s286><accept.annehmen><en> Since Christ’s Death on the Cross and his Resurrection constitute the content of the daily life of the Church (25) and the pledge of his eternal Passover, (26) the Liturgy has as its first task to lead us untiringly back to the Easter pilgrimage initiated by Christ, in which we accept death in order to enter into life. 7.
<G-vec00120-002-s286><accept.annehmen><de> Da der Tod Christi am Kreuze und seine Auferstehung den Inhalt des täglichen Lebens der Kirche[25] und das Unterpfand ihres ewigen Ostern[26] bilden, hat die Liturgie als erste Aufgabe, uns unermüdlich auf den österlichen Weg zu führen, den uns Christus eröffnet hat und auf dem man es annimmt zu sterben, um in das Leben einzugehen.
<G-vec00120-002-s287><accept.annehmen><en> Should the client not accept the goods at the agreed place of delivery or not collect them within 8 days from the transport company’s collection point, then the Oui Group will grant the client a 14 day period of grace.
<G-vec00120-002-s287><accept.annehmen><de> Falls der Kunde die Ware am vereinbarten Lieferort nicht annimmt oder sie bei der Packstation des Transportunternehmens nicht innerhalb von 8 Tagen abholt, so wird die Oui Gruppe eine Nachfrist von 14 Tagen setzen.
<G-vec00120-002-s288><accept.annehmen><en> However, it is located separately in the harbor, not at a campsite, how to accept incorrectly.
<G-vec00120-002-s288><accept.annehmen><de> Allerdings ist es einzeln gelegen, direkt im Hafen, nicht auf einem Campingplatz, wie man fälschlicherweise annimmt.
<G-vec00120-002-s289><accept.annehmen><en> We all need to love and to feel that others accept us and love us.
<G-vec00120-002-s289><accept.annehmen><de> Alle brauchen wir das Gefühl, jemanden gern zu haben, und zu spüren, daß jemand uns annimmt und uns liebt.
<G-vec00120-002-s290><accept.annehmen><en> If you do not agree to the use of cookies, you can delete the cookies at any time in the security settings of your browser or configure your browser so that it does not accept cookies.
<G-vec00120-002-s290><accept.annehmen><de> Sofern Sie nicht mit der Verwendung von Cookies einverstanden sein sollten, können Sie die Cookies in den Sicherheitseinstellungen Ihres Browsers jederzeit löschen oder Ihren Browser so konfigurieren, dass dieser Cookies schon nicht annimmt.
<G-vec00120-002-s291><accept.annehmen><en> These signs were granted to Moses so that he could convince the Pharaoh of the fallacies of his ways and so that he would accept Islam.
<G-vec00120-002-s291><accept.annehmen><de> Diese Wunder wurden Moses gewährt, damit er den Pharao davon überzeugen konnte, dass er sich im Irrtum befindet und damit der Pharao den Islam annimmt.
<G-vec00120-002-s292><accept.annehmen><en> However if you have a friend outside United Kingdom who is happy to accept your order, we can ship it there for you.
<G-vec00120-002-s292><accept.annehmen><de> Wenn Sie jedoch einen Freund außerhalb Großbritanniens haben, der Ihre Bestellung gerne annimmt, können wir ihn dort für Sie versenden.
<G-vec00120-002-s293><accept.annehmen><en> Unless BÖWE SYSTEC was granted the right, in accordance with the insurance contracts, to assert claims directly, the buyer shall assign any claims for compensation against the insurance company for any damage/loss of the delivery item to BÖWE SYSTEC as of now, where the latter shall accept such assignment.
<G-vec00120-002-s293><accept.annehmen><de> Soweit in den Versicherungsverträgen der BÖWE SYSTEC kein unmittelbares Forderungsrecht eingeräumt wird, tritt der Besteller bereits jetzt etwaige Entschädigungsansprüche gegen die Versicherung für eine etwaige Beschädigung/Untergang des Liefergegenstandes an BÖWE SYSTEC ab, die diese Abtretung annimmt.
<G-vec00120-002-s294><accept.annehmen><en> A material fact is a fact or circumstance that would influence the judgment of a prudent underwriter in fixing the premium or determining whether he will accept the risk and, if so, on what terms.
<G-vec00120-002-s294><accept.annehmen><de> Unter wesentlichen Fakten versteht sich eine Tatsache oder ein Umstand, der die Beurteilung eines umsichtigen Versicherers bei der Festsetzung der Prämie oder bei der Feststellung, ob er das Risiko annimmt, und gegebenenfalls zu welchen Bedingungen, beeinflussen würde.
<G-vec00120-002-s295><accept.annehmen><en> At that, we do not consider the patient as a subordinate who is to accept our therapy as determined by us with no argument allowed.
<G-vec00120-002-s295><accept.annehmen><de> Dabei sehen wir den Patienten aber nicht als Befehlsempfänger, der unsere Therapie diskussionslos wie von uns festgelegt annimmt.
<G-vec00120-002-s296><accept.annehmen><en> The Author who is approved for the specified quality level, has not been excluded by the Client and is first to accept the offer, shall be awarded the assignment.
<G-vec00120-002-s296><accept.annehmen><de> Den Zuschlag erhält der für die vorgegebene Qualitätsstufe zugelassene und nicht vom Kunden ausgeschlossene Autor, der als erster das Angebot annimmt.
<G-vec00120-002-s297><accept.annehmen><en> Once they accept the email invitation, they can create a new account.
<G-vec00120-002-s297><accept.annehmen><de> Sobald sie die E-Mail öffnet und die Einladung annimmt, kann sie ein neues Konto anlegen.
<G-vec00120-002-s298><accept.annehmen><en> The casino will need to be licensed and regulated so you know you can trust them, but you can go through our comprehensive online casino reviews to find the best Bitcoin casinos or those that accept Bitcoin payment methods.
<G-vec00120-002-s298><accept.annehmen><de> Das Casino sollte reguliert und lizenziert sein, damit Sie ihnen vertrauen können aber Sie können sich einfach unsere verständlichen Online Casino Bewertungen ansehen um das beste Bitcoin Casino zu finden, das Bitcoin Zahlungsmethoden annimmt.
<G-vec00120-002-s299><accept.annehmen><en> Whoever believes in Him and accept Him, whose heart will be purified so that it becomes white as snow.
<G-vec00120-002-s299><accept.annehmen><de> Wer an Ihn glaubt und Ihn annimmt, dessen Herz wird gereinigt, sodass es weiß wird wie Schnee.
<G-vec00120-002-s300><accept.annehmen><en> In the case of any member State which shall subsequently sign the Protocol without reservation in respect of ratification, acceptance or approval or which shall ratify, accept or approve it, the Protocol shall enter into force three months after the date of such signature or after the date of deposit of the instrument of ratification, acceptance or approval.
<G-vec00120-002-s300><accept.annehmen><de> Für jeden Mitgliedstaat, der das Protokoll später ohne Vorbehalt der Ratifikation, Annahme oder Genehmigung unterzeichnet oder der es ratifiziert, annimmt oder genehmigt, tritt es drei Monate nach der Unterzeichnung oder der Hinterlegung der Ratifikations-, Annahme- oder Genehmigungsurkunde in Kraft.
<G-vec00120-002-s301><accept.annehmen><en> When they return to Tia Dalma and she asks if they would be willing to do anything to save Jack and the Pearl, Gibbs is the first to accept.
<G-vec00120-002-s301><accept.annehmen><de> Als sie zu Tia Dalma zurückkehren und sie sie fragt, was sie tun würden, um den einmaligen Jack und seine kostbare Black Pearl zurückzuholen, ist Gibbs der Erste, der ihre Herausforderung annimmt.
<G-vec00120-002-s302><accept.annehmen><en> Every prospective arbitrator shall declare in writing whether they accept to act as arbitrator.
<G-vec00120-002-s302><accept.annehmen><de> Jede Person, die als Schiedsrichter bestellt werden soll, hat schriftlich mitzuteilen, ob sie das Schiedsrichteramt annimmt.
<G-vec00120-002-s303><accept.annehmen><en> The Seller may refuse to accept any further Orders from a Customer after multiple returns on previous purchases by the same Customer. 13. DISCLAIMER OF WARRANTIES
<G-vec00120-002-s303><accept.annehmen><de> Nach mehreren Rücktritten und Rückgaben durch den Kunden kann sich der Verkäufer die Entscheidung vorbehalten, ob er eine Bestellung seitens dieses Kunden annimmt oder nicht.
<G-vec00120-002-s304><accept.annehmen><en> You simply started killing people instead of accepting the apology of Lord Lothian and his willingness to accept his punishment -- but of course, not at any price. ------------ translation:
<G-vec00120-002-s304><accept.annehmen><de> Sie begannen einfach Tötungleute, anstatt, die Entschuldigung des Lords Lothian und seine Bereitwilligkeit, seine Bestrafung anzunehmen -- aber selbstverständlich, nicht zu jedem möglichem Preis anzunehmen.
<G-vec00120-002-s305><accept.annehmen><en> In Kenya, a team is using a well established IofC-developed method called the Clean Election Campaign to inspire a critical mass of people to commit themselves to neither give nor accept bribes during elections, and to vote on the basis of character rather than tribal allegiance.
<G-vec00120-002-s305><accept.annehmen><de> In Kenia arbeitet ein Team mit der inzwischen gut eingespielten IofC-Methode der sogenannten "Clean Election Campaign" (Kampagne für saubere Wahlen") daran, kritische Menschen dazu anzuregen, ein Versprechen abzulegen, in Wahlkampfkampagnen weder Bestechungsgelder anzunehmen noch zu geben und eher dem Charakter der Kandidaten entsprechend zu wählen anstatt nach Stammeszugehörigkeit.
<G-vec00120-002-s306><accept.annehmen><en> Though I couldn’t be there in person tonight to accept this prestigious award, I’m so happy to have the chance to send this message to let all my French fans know how much your support has meant throughout the years.
<G-vec00120-002-s306><accept.annehmen><de> Weil ich heute nicht persönlich da sein kann, um diesen renommierten Preis anzunehmen, bin ich glücklich, die Chance zu haben diese Nachricht zu übermitteln, um meine französischen Fans wissen zu lassen, wieviel mir ihre jahrelange Unterstützung bedeutet.
<G-vec00120-002-s307><accept.annehmen><en> But few had chosen to accept the plan.
<G-vec00120-002-s307><accept.annehmen><de> Doch nur wenige hatten es erwählt, den Plan anzunehmen.
<G-vec00120-002-s308><accept.annehmen><en> And so I was more or less obliged to accept, but I did not plan on staying for more than three days.
<G-vec00120-002-s308><accept.annehmen><de> Und so war ich mehr oder weniger gezwungen anzunehmen, wollte aber nicht länger als drei Tage bleiben.
<G-vec00120-002-s309><accept.annehmen><en> The Third Party shall accept the highest bid placed by a User when the auction has ended.
<G-vec00120-002-s309><accept.annehmen><de> Der Drittanbieter verpflichtet sich, das Gebot des höchstbietenden Nutzers nach Zeitablauf der Versteigerung anzunehmen.
<G-vec00120-002-s310><accept.annehmen><en> 2.3. In the case of a substantial change of a substantial characteristic of a travel service or the deviation from special specifications of the customer which have become contents of the package tour contract, the customer is entitled to either accept the change or withdraw from the package tour contract free of charge within a reasonable period set by LRV at the same time as notification of the change.
<G-vec00120-002-s310><accept.annehmen><de> Im Fall einer erheblichen Änderung einer wesentlichen Eigenschaft einer Reiseleistung oder der Abweichung von besonderen Vorgaben des Kunden, die Inhalt des Pauschalreisevertrags geworden sind, ist der Kunde berechtigt, innerhalb einer von OMNIBUS RIEDER gleichzeitig mit Mitteilung der Änderung gesetzten angemessenen Frist entweder die Änderung anzunehmen oder unentgeltlich vom Pauschalreisevertrag zurückzutreten.
<G-vec00120-002-s311><accept.annehmen><en> — Based on EFSA’s assessment, the Commission drafts a recommendation to accept or reject the application.
<G-vec00120-002-s311><accept.annehmen><de> Auf der Grundlage der Prüfung durch die EFSA erarbeitet die Kommission eine Empfehlung, den Antrag anzunehmen oder abzulehnen.
<G-vec00120-002-s312><accept.annehmen><en> CRE RÖSLER ELECTRONIC GmbH is entitled to accept the contractual offer represented by this purchase order within two weeks of receipt.
<G-vec00120-002-s312><accept.annehmen><de> Die CRE RÖSLER ELECTRONIC GmbH ist berechtigt, das in der Bestellung liegende Vertragsangebot innerhalb von zwei Wochen nach Eingang anzunehmen.
<G-vec00120-002-s313><accept.annehmen><en> The person you invite has five minutes to accept your invitation.
<G-vec00120-002-s313><accept.annehmen><de> Die eingeladene Person hat fünf Minuten lang Zeit, die Einladung anzunehmen.
<G-vec00120-002-s314><accept.annehmen><en> Adolfo Wildt completed the work in 1926 – the year in which he became Professor of Sculpture at the Brera Academy – without a commission from the Vatican, which took over forty years to accept it.
<G-vec00120-002-s314><accept.annehmen><de> Adolfo Wildt schuf dieses Kunstwerk im Jahr 1926 – dem Jahr, in dem er Professor für Bildhauerkunst an der Brera-Akademie wurde –, ohne vom Vatikan beauftragt worden zu sein, der gute 40 Jahre brauchte, um die Büste anzunehmen.
<G-vec00120-002-s315><accept.annehmen><en> In order to reach a good and satisfactory way of life the therapist as well as the patient are both faced with a major challenge, namely to accept the topic: sexuality and cancer.
<G-vec00120-002-s315><accept.annehmen><de> Um eine gelungene befriedi-gende Lebenssituation für den Patienten zu erreichen, sind sowohl der Behandler als auch der Patient vor eine Herausforderung gestellt: nämlich sich dieses Themas Sexualität und Krebs anzunehmen.
<G-vec00120-002-s316><accept.annehmen><en> You have the option to accept or decline cookies.
<G-vec00120-002-s316><accept.annehmen><de> Sie haben die Möglichkeit, Cookies anzunehmen oder abzulehnen.
<G-vec00120-002-s317><accept.annehmen><en> The Seller shall have the right not to accept the goods returned by the Buyer if the Buyer does not follow the return procedure set out in this Article.
<G-vec00120-002-s317><accept.annehmen><de> Der Verkäufer hat das Recht, die vom Käufer zurückgesandte Ware nicht anzunehmen, wenn der Käufer das in diesem Artikel beschriebene Rückgabeverfahren nicht einhält.
<G-vec00120-002-s318><accept.annehmen><en> HandBrake is not limited to DVDs: it will now accept practically any type of video as a source.
<G-vec00120-002-s318><accept.annehmen><de> Handbrake ist nicht auf DVDs beschränkt: es wird nun praktisch jede Art von Video als Quelle anzunehmen.
<G-vec00120-002-s319><accept.annehmen><en> The size of the internal container is adjustable, in order to accept items with different shapes.
<G-vec00120-002-s319><accept.annehmen><de> Die Größe des internen Behälters ist justierbar, um Einzelteile mit verschiedenen Formen anzunehmen.
<G-vec00120-002-s320><accept.annehmen><en> "Indeed, if I do not make an effort to accept you as you are and you do not strive to accept me as I am, the building of love between us can no longer be erected, bound though we may be by reciprocal and patient love". And to complete the image, let us not forget that "there is one foundation that supports the full weight of the construction; and it is our Redeemer, who alone bears all together the customs of us all.
<G-vec00120-002-s320><accept.annehmen><de> Denn wenn ich mich nicht anstrenge, euch so anzunehmen, wie ihr seid, und wenn ihr euch nicht bemüht, mich so anzunehmen, wie ich bin, kann unter euch das Bauwerk der Liebe nicht entstehen, obwohl wir doch durch gegenseitige und geduldige Liebe verbunden sind.« Zur Abrundung des Bildes ist nicht zu vergessen, daß »es ein Fundament gibt, das das ganze Gewicht des Bauwerks trägt, und das ist unser Erlöser, der ganz allein all unsere Verhaltensweisen erträgt.
<G-vec00120-002-s322><accept.annehmen><en> You also represent and warrant that you have the authority to accept this Agreement on behalf of owners and users of those administered Devices, and hereby accept this Agreement on their behalf.
<G-vec00120-002-s322><accept.annehmen><de> Ferner weisen Sie nach und belegen, dass Sie berechtigt sind, diese Vereinbarung im Namen der Besitzer und Benutzer von diesen verwalteten Geräten anzunehmen und hiermit diese Vereinbarung in deren Namen anzunehmen.
<G-vec00120-002-s551><accept.annehmen><en> I accept your offer for a free strategy meeting.
<G-vec00120-002-s551><accept.annehmen><de> Ich nehme Ihr Angebot für ein kostenfreies Strategiegespräch gerne an.
<G-vec00120-002-s552><accept.annehmen><en> I will lovingly transfer you something; I'm glad that you want to help me and love to accept it, feels so well.
<G-vec00120-002-s552><accept.annehmen><de> Ich werde Dir aber von Herzen etwas überweisen, ich freue mich, das Du mir helfen möchtest und nehme es gern an, fühlt sich gut an.
<G-vec00120-002-s553><accept.annehmen><en> That’s because I only accept jobs I’ll be able to realize optimally.
<G-vec00120-002-s553><accept.annehmen><de> Denn ich nehme nur Aufträge an die ich optimal umsetzen kann.
<G-vec00120-002-s554><accept.annehmen><en> 5 6 I declare to have acquainted with the conditions and the loads (responsibilities) and accept them.
<G-vec00120-002-s554><accept.annehmen><de> 5 6 Ich erkläre, Kenntnis der Bedingungen und der Lasten genommen zu haben und nehme sie an.
<G-vec00120-002-s555><accept.annehmen><en> Here I accept what Your hand hands to me.
<G-vec00120-002-s555><accept.annehmen><de> Ich nehme da ist alles jenes an, das Deine Hand mir reicht.
<G-vec00120-002-s556><accept.annehmen><en> May the Lord accept the sacrifice at your hands for the praise and glory of his name, for our good, and the good of all his Church.
<G-vec00120-002-s556><accept.annehmen><de> R. Der Herr nehme das Opfer an aus Deinen Händen zum Lob und Ruhm seines Namens, zum Segen für uns und seine ganze Heilige Kirche.
<G-vec00120-002-s557><accept.annehmen><en> Yes I now accept all religion as the downfall of mankind.
<G-vec00120-002-s557><accept.annehmen><de> Ja Ich nehme jetzt alle Religionen an, als den Niedergang der Menschheit.
<G-vec00120-002-s558><accept.annehmen><en> I openly acknowledge and accept His death for my sins.
<G-vec00120-002-s558><accept.annehmen><de> Ich anerkenne seinen Tod und nehme Jesu Opfer für meine Sünden in Anspruch.
<G-vec00120-002-s559><accept.annehmen><en> I am pleased to welcome you to the Vatican and to accept the Letters of Credence by which you are appointed Ambassador Extraordinary and Plenipotentiary of the Republic of Uganda to the Holy See.
<G-vec00120-002-s559><accept.annehmen><de> Mit Freude heiße ich Sie im Vatikan willkommen und nehme das Beglaubigungsschreiben entgegen, mit dem Sie als außerordentliche und bevollmächtigte Botschafterin der Republik Uganda beim Heiligen Stuhl akkreditiert werden.
<G-vec00120-002-s561><accept.annehmen><en> I will accept you into our institute, which now stands under the true protection of God and under the protection of Rome.
<G-vec00120-002-s561><accept.annehmen><de> Ich nehme dich auf in unser Institut, das da nun steht unter dem wahren Schutze Gottes und unter dem Schutze Roms.
<G-vec00120-002-s562><accept.annehmen><en> As a professional, I only accept work where I am 100% confident that I can do a great job.
<G-vec00120-002-s562><accept.annehmen><de> Ich nehme nur Aufträge an, wo ich mir 100% sicher bin, dass ich erstklassige Arbeit liefern kann.
<G-vec00120-002-s563><accept.annehmen><en> When I process your order, I accept your purchase offer and set the order status to “processing”.
<G-vec00120-002-s563><accept.annehmen><de> Wenn ich deine Bestellung erhalten habe und bearbeite, nehme ich deinen Kaufangebot an und setze ich den Bestellstatus zu „in Bearbeitung“.
<G-vec00120-002-s564><accept.annehmen><en> I call Carlos from the car and ask him for more information about the matter and I tell him that Nuñez Mosquera should accept the letter" —Felipe had already done the same— "and I said" —this is what I added— "to communicate it immediately" —I did not know that Felipe had already given his instructions, and I told him what he should say— "to accept the document and to also tell them not to get impatient over the steps that they wanted taken quickly." "12:35 after midnight.
<G-vec00120-002-s564><accept.annehmen><de> Vom Auto aus rufe ich Carlos an, bitte um eine Präzision dieser Nachfrage und erteile die Anweisung, daß Nuñez Mosquera das Schreiben in Empfang nimmt"- Felipe hatte seinerseits bereits dasselbe gemacht – „und ich sagte","- das ist das, was ich hinzufügte – „daß er sofort übermittle"- ich weiß nicht, daß Felipe bereits Anweisungen gegeben hat, ich sage ihm das, was er ihm sagen muss – „daß er das Dokument in Empfang nehme und daß er ihnen gegenüber hinzufüge, sie sollten nicht ungeduldig werden in bezug auf die Maßnahme, deren schnelle Durchführung sie wünschten.
<G-vec00120-002-s565><accept.annehmen><en> I accept you now as my Lord and Savior, You are the God I love.
<G-vec00120-002-s565><accept.annehmen><de> Lieber YAHUSHUA, Ich nehme Dich jetzt als meinen Herrn und Retter an.
<G-vec00120-002-s566><accept.annehmen><en> And I accept what comes from You instead of from Myself.
<G-vec00120-002-s566><accept.annehmen><de> Und Ich nehme das an was von Dir kommt anstelle dessen was von Mir kommt.
<G-vec00120-002-s567><accept.annehmen><en> Do not accept files sent to you over instant messaging services.
<G-vec00120-002-s567><accept.annehmen><de> Nehme keine Dateien an, die dir jemand über solche Dienste schickt.
<G-vec00120-002-s568><accept.annehmen><en> I carry on with my pending cases, but I only accept new ones if the refugees involved seem genuine to me, namely the ones who really had a good reason for coming to this country, to a secular state where women and men are equal in the eyes of the law, where we can eat pork and even sunbathe naked on the beach if we feel like it.
<G-vec00120-002-s568><accept.annehmen><de> Ich führe die angefangenen Fälle zwar weiter, nehme aber nur noch neue Fälle auf, wo es sich meiner Ansicht nach um wirkliche Flüchtlinge handelt, die einen Grund haben, in unseren säkularen Staat zu kommen, wo Frauen und Männer per Gesetz gleichberechtigt sind, wo Schweinefleisch gegessen wird, wo wir sogar nackt am Strand sitzen dürfen.
<G-vec00120-002-s569><accept.annehmen><en> I accept the miracle like a credulous person.
<G-vec00120-002-s569><accept.annehmen><de> Ich nehme das Wunder hin wie ein gläubiger Mensch.
<G-vec00120-002-s570><accept.annehmen><en> For money is not allowable for the Sakyan-son contemplatives, the Sakyan-son contemplatives do not consent to money, the Sakyan-son contemplatives do not accept money, the Sakyan-son contemplatives have given up gold & jewelry, have renounced money.
<G-vec00120-002-s570><accept.annehmen><de> Denn Geld ist nicht erlaubt für die Besinnlichen der Sakyer-Söhne, die Besinnlichen der Sakyer-Söhne stimmen Geld nicht zu, die Besinnlichen der Sakyer-Söhne nehmen kein Geld an, die Besinnlichen der Sakyer-Söhne haben Gold und Juwelen aufgegeben, haben dem Geld entsagt.
<G-vec00120-002-s571><accept.annehmen><en> According to that decision, the paying agencies will accept or reject the tenders on products available for sale.
<G-vec00120-002-s571><accept.annehmen><de> Auf der Grundlage dieses Beschlusses nehmen die Zahlstellen die Angebote für die zum Verkauf stehenden Erzeugnisse an oder lehnen sie ab.
<G-vec00120-002-s572><accept.annehmen><en> We accept Visa, Mastercard, EC-Card and cash
<G-vec00120-002-s572><accept.annehmen><de> Wir nehmen Visa, Mastercard, EC-Karte und Bargeld.
<G-vec00120-002-s573><accept.annehmen><en> A:We accept T/T,L/C, 30% in advance.
<G-vec00120-002-s573><accept.annehmen><de> A: Wir nehmen T/T, L/C, 30% im Voraus an.
<G-vec00120-002-s574><accept.annehmen><en> We only accept your offer, and conclude the contract of sale for a product ordered by you, when we dispatch the product to you and send e-mail confirmation to you that we've dispatched the product to you (the "Fulfillment Confirmation E-mail").
<G-vec00120-002-s574><accept.annehmen><de> Wir nehmen Ihr Angebot erst an und schließen den Verkaufsvertrag für ein von Ihnen bestelltes Produkt erst dann ab, wenn wir das Produkt an Sie ausliefern und Ihnen eine Bestätigungsmail über den Versand des Produkts an Sie (die „Erfüllungsbestätigungsmail“) schicken.
<G-vec00120-002-s575><accept.annehmen><en> Popular toroidal inductor base, competitive price and short lead time, accept special dimension.
<G-vec00120-002-s575><accept.annehmen><de> Beliebttoroidale Induktorbasis, konkurrenzfähiger Preis und kurze Vorbereitungs- und Anlaufzeit, nehmen spezielle Dimension an.
<G-vec00120-002-s576><accept.annehmen><en> NEW We accept guests in Kazbegi, warm and hospitable.
<G-vec00120-002-s576><accept.annehmen><de> NEU Wir nehmen die Gäste in Kazbegi, warm und gastfreundlich.
<G-vec00120-002-s577><accept.annehmen><en> In case, for any reason, you are not completely satisfied with your purchase, we will be happy to accept a return for a refund, store credit or an exchange.
<G-vec00120-002-s577><accept.annehmen><de> Sollten Sie, egal aus welchem Grund, nicht zufrieden mit dem gelieferten Artikel sein, so nehmen wir diesen gerne wieder zurück und erstatten Ihnen den Kaufpreis, legen eine Gutschrift im Kundenkonto für Sie an oder tauschen den Artikel um.
<G-vec00120-002-s578><accept.annehmen><en> We accept OEM products, FREE SAMPLES on your design are also availsble.
<G-vec00120-002-s578><accept.annehmen><de> Wir nehmen Soem-Produkte an, FREIE PROBEN auf Ihrem Entwurf sind auch availsble.
<G-vec00120-002-s579><accept.annehmen><en> When a presiding officer asks your help, be glad to accept and give the best you have to that labor.
<G-vec00120-002-s579><accept.annehmen><de> Wenn ein präsidierender Beamter Sie um Hilfe bittet, nehmen Sie dies gern an und geben Sie bei der Aufgabe Ihr Bestes.
<G-vec00120-002-s580><accept.annehmen><en> We will gladly accept your reservation.
<G-vec00120-002-s580><accept.annehmen><de> Gerne nehmen wir Ihre Reservierung entgegen.
<G-vec00120-002-s581><accept.annehmen><en> Amounts receivable resulting from resale or for another legal reason (insurance, unauthorized actions) regarding the goods subject to retention of title (including all payment balance requests from current accounts) are hereby conveyed in their full amount by way of security to us; we hereby accept this conveyance.
<G-vec00120-002-s581><accept.annehmen><de> Die aus dem Weiterverkauf oder einem sonstigen Rechtsgrund (Versicherung, unerlaubte Handlung) bezüglich der Vorbehaltsware entstehenden Forderungen (einschließlich sämtlicher Saldoforderungen aus Kontokorrent) tritt der Käufer bereits jetzt sicherungshalber in vollem Umfang an uns ab; wir nehmen die Abtretung hiermit an.
<G-vec00120-002-s582><accept.annehmen><en> Yes we do accept small qty, so that you can check our quality first.
<G-vec00120-002-s582><accept.annehmen><de> Ja nehmen wir kleine Menge an, damit Sie unsere Qualität zuerst überprüfen können.
<G-vec00120-002-s583><accept.annehmen><en> It goes without saying that we also accept production-specific commercial waste.
<G-vec00120-002-s583><accept.annehmen><de> Selbstverständlich nehmen wir auch produktionsspezifische Gewerbeabfälle an.
<G-vec00120-002-s584><accept.annehmen><en> Is the good of the customer to be regarded as the main good as a consequence of the amalgamation, the customer and us agree that the customer shall assign us proportional part-ownership of the good; we herewith accept this assignment.
<G-vec00120-002-s584><accept.annehmen><de> Ist die Sache des Kunden in Folge der Vermischung als Hauptsache anzusehen, sind der Kunde und wir uns einig, dass der Kunde uns anteilmäßig Miteigentum an der Sache überträgt; die Übertragung nehmen wir hiermit an.
<G-vec00120-002-s585><accept.annehmen><en> By clicking on Send, you accept the Privacy Policy and User Agreement provisions automatically.
<G-vec00120-002-s585><accept.annehmen><de> Beim Klicken auf "Senden" nehmen Sie die Bedingungen unserer Datenschutzerklärung und Nutzungsvereinbarung automatisch an.
<G-vec00120-002-s586><accept.annehmen><en> c. We hereby accept the aforementioned assignments.
<G-vec00120-002-s586><accept.annehmen><de> c. Wir nehmen die obigen Abtretungen hiermit an.
<G-vec00120-002-s587><accept.annehmen><en> A4: We accept T/T, Western Union, Paypal, L/C.
<G-vec00120-002-s587><accept.annehmen><de> A4: Wir nehmen T/T, Western union, Paypal, L/C.
<G-vec00120-002-s588><accept.annehmen><en> By clicking the button "Buy", you will accept the purchase offer for the products in your shopping cart.
<G-vec00120-002-s588><accept.annehmen><de> Mit Anklicken des Buttons „Kaufen“ nehmen Sie das Kaufangebot über die im Warenkorb befindlichen Produkte an.
<G-vec00120-002-s589><accept.annehmen><en> We accept this transfer.
<G-vec00120-002-s589><accept.annehmen><de> Wir nehmen diese Übertragung an.
<G-vec00120-002-s590><accept.annehmen><en> We accept TT .
<G-vec00120-002-s590><accept.annehmen><de> Wir nehmen TT an.
<G-vec00120-002-s591><accept.annehmen><en> Many of the people who visit the park, follow the purpose of performing physical exercises, others bring their children to play, others go there to enjoy nature and still others accept other events, which took place there.
<G-vec00120-002-s591><accept.annehmen><de> Viele der Menschen, die den Park besuchen, verfolgen den Zweck der Ausübung sportlicher Bewegung, andere bringen ihre Kinder zum Spielen, andere gehen dorthin, um die Natur genießen und wieder andere nehmen an anderen Veranstaltungen teil, die dort stattfinden.
<G-vec00120-002-s592><accept.annehmen><en> They accept the falsehood and reject the pure truth which God Himself sends in plain form to earth....
<G-vec00120-002-s592><accept.annehmen><de> Sie nehmen an die Unwahrheit und lehnen ab die reine Wahrheit, die in schlichtem Gewande von Gott Selbst zur Erde geleitet wird....
<G-vec00120-002-s593><accept.annehmen><en> For safety reasons, we don't accept Attachments from unknown sources nor do we publish publicly an e-mail.
<G-vec00120-002-s593><accept.annehmen><de> Aus Sicherheitsgründen nehmen wir keine Attachments aus unbekannten Quellen an und geben unsere e-mail nicht öffentlich preis.
<G-vec00120-002-s594><accept.annehmen><en> Yes, we have our own factory,We accept custom making all types and sizes packing bags according to your requirements.
<G-vec00120-002-s594><accept.annehmen><de> Ja haben wir unsere eigene Fabrik, nehmen wir die Gewohnheit an, die alle Arten und Größen Taschen entsprechend Ihren Anforderungen verpackend macht.
<G-vec00120-002-s595><accept.annehmen><en> We accept returns.
<G-vec00120-002-s595><accept.annehmen><de> Wir nehmen die Rückgaben an.
<G-vec00120-002-s596><accept.annehmen><en> However we only accept projects which guarantee respectable dealings with all parties working in full transparency.
<G-vec00120-002-s596><accept.annehmen><de> Dabei nehmen wir allerdings nur Aufträge an, die einen seriösen Umgang unter vollständiger Transparenz für alle Beteiligten gewährleisten.
<G-vec00120-002-s597><accept.annehmen><en> We accept that challenge.
<G-vec00120-002-s597><accept.annehmen><de> Wir nehmen diese Herausforderung an.
<G-vec00120-002-s598><accept.annehmen><en> We accept applications throughout the year.
<G-vec00120-002-s598><accept.annehmen><de> Wir nehmen das ganze Jahr über Bewerbungen an.
<G-vec00120-002-s599><accept.annehmen><en> Also accept help if you need it.
<G-vec00120-002-s599><accept.annehmen><de> Nehmen Sie bei Bedarf auch Unterstützung an.
<G-vec00120-002-s600><accept.annehmen><en> We accept various technical translation orders.
<G-vec00120-002-s600><accept.annehmen><de> Wir nehmen sehr unterschiedliche Aufträge für technische Übersetzungen an.
<G-vec00120-002-s601><accept.annehmen><en> Again, it applies: We only accept what we can represent.
<G-vec00120-002-s601><accept.annehmen><de> Und auch hier gilt: Wir nehmen an, was wir vertreten können.
<G-vec00120-002-s602><accept.annehmen><en> We accept credit cards and discounts.
<G-vec00120-002-s602><accept.annehmen><de> Wir nehmen alle Kreditkarten und Diskonte an.
<G-vec00120-002-s603><accept.annehmen><en> We accept emergencies during these opening hours.
<G-vec00120-002-s603><accept.annehmen><de> Wir nehmen Notfälle zu den Öffnungszeiten an.
<G-vec00120-002-s604><accept.annehmen><en> People unreservedly accept whatever is presented to them as truth and accordingly adjust their outlook, i.e. depending on the information conveyed to them they either live within light or within darkness....
<G-vec00120-002-s604><accept.annehmen><de> Die Menschen nehmen bedenkenlos an, was ihnen als Wahrheit zugetragen wird, und stellen dann ihr Denken danach ein, d.h., entsprechend diesem ihnen zugetragenen Wissen bewegen sie sich nun im Licht oder im Dunkeln....
<G-vec00120-002-s605><accept.annehmen><en> We accept bank transfer for large orders.
<G-vec00120-002-s605><accept.annehmen><de> Wir nehmen Banküberweisung für große Aufträge an.
<G-vec00120-002-s606><accept.annehmen><en> We also accept files in other formats.
<G-vec00120-002-s606><accept.annehmen><de> Wir nehmen auch Dateien in anderen Formaten an.
<G-vec00120-002-s607><accept.annehmen><en> We will gladly accept any rectification.
<G-vec00120-002-s607><accept.annehmen><de> Wir nehmen gern jegliche Berichtigung an.
<G-vec00120-002-s627><accept.annehmen><en> Accept our kind greetings and stop at Hotel Orts.
<G-vec00120-002-s627><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Hotel Orts an.
<G-vec00120-002-s628><accept.annehmen><en> Four celebrity teams come together to compete against each other in front of an audience: teams North, South, East and West accept the challenge of cooking a four-course barbecue meal in only 150 minutes.
<G-vec00120-002-s628><accept.annehmen><de> Vier Promi-Teams treten gegeneinander an: Die Teams Norden, Süden, Osten und Westen nehmen Sie die Herausforderung an, ein Vier-Gänge-Grill-Menü in nur 150 Minuten zuzubereiten.
<G-vec00120-002-s629><accept.annehmen><en> Accept now Yeshua HaMashiach, Jesus Christ.
<G-vec00120-002-s629><accept.annehmen><de> Nehmen Sie jetzt Yeshua HaMashiach, Jesus Christus an.
<G-vec00120-002-s630><accept.annehmen><en> Accept our kind greetings and stop at Radisson Blu Grand Hotel.
<G-vec00120-002-s630><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Radisson Blu Grand Hotel an.
<G-vec00120-002-s631><accept.annehmen><en> Accept the challenge and manage to stare at your rival through your smartphone's camera without laughing.
<G-vec00120-002-s631><accept.annehmen><de> Nehmen Sie die Herausforderung an und schauen Sie Ihren Gegner in die Augen ohne zu lachen.
<G-vec00120-002-s632><accept.annehmen><en> Accept our kind greetings and stop at Professor's Guest House.
<G-vec00120-002-s632><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Professor's Guest House an.
<G-vec00120-002-s633><accept.annehmen><en> Accept this invitation and come and rest with us.
<G-vec00120-002-s633><accept.annehmen><de> Nehmen Sie unsere Einladung an und erholen Sie sich bei uns.
<G-vec00120-002-s634><accept.annehmen><en> Accept our kind greetings and stop at Oaks 212 Margaret.
<G-vec00120-002-s634><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Oaks 212 Margaret an.
<G-vec00120-002-s635><accept.annehmen><en> Accept our invitation and visit to the place where the dreams come true.
<G-vec00120-002-s635><accept.annehmen><de> Nehmen Sie unsere Einladung an und treten Sie in den Ort der erfüllten Wünsche.
<G-vec00120-002-s636><accept.annehmen><en> Accept our kind greetings and stop at Econo Lodge Montmorency Falls.
<G-vec00120-002-s636><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Econo Lodge Montmorency Falls an.
<G-vec00120-002-s637><accept.annehmen><en> Accept city’s invitation for an enchanting walk that will reveal its hidden side.
<G-vec00120-002-s637><accept.annehmen><de> Nehmen Sie die Einladung der Stadt an und genießen Sie einen bezaubernden Spaziergang der seine verborgene Seite enthüllt.
<G-vec00120-002-s638><accept.annehmen><en> Accept our kind greetings and stop at Beijing Hotel.
<G-vec00120-002-s638><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Beijing Hotel an.
<G-vec00120-002-s639><accept.annehmen><en> Accept the lowest bid, you need to risk taken by you to add something.
<G-vec00120-002-s639><accept.annehmen><de> Nehmen Sie das niedrigste Angebot an, müssen Sie für das Risiko das Sie eingehen etwas hinzurechnen.
<G-vec00120-002-s640><accept.annehmen><en> Accept our kind greetings and stop at Siesta Apartments.
<G-vec00120-002-s640><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Siesta Apartments an.
<G-vec00120-002-s641><accept.annehmen><en> Accept what you can't change and let go of things out of your control.
<G-vec00120-002-s641><accept.annehmen><de> Nehmen Sie, was Sie nicht ändern können, und lassen Sie die Dinge aus der Kontrolle.
<G-vec00120-002-s642><accept.annehmen><en> Accept our concerns.
<G-vec00120-002-s642><accept.annehmen><de> Nehmen Sie unsere Bedenken.
<G-vec00120-002-s643><accept.annehmen><en> Accept our kind greetings and stop at Hotel Arena.
<G-vec00120-002-s643><accept.annehmen><de> Nehmen Sie unsere freundlichen Grüße und Anschlag am Hotel Arena an.
<G-vec00120-002-s644><accept.annehmen><en> Accept our invitation to the very best winter events.
<G-vec00120-002-s644><accept.annehmen><de> Nehmen Sie unsere Einladung zu den besten winterlichen Events an.
<G-vec00120-002-s645><accept.annehmen><en> Sign up today and accept credit and debit cards wherever your business takes you.
<G-vec00120-002-s645><accept.annehmen><de> Registrieren Sie sich jetzt und nehmen Sie Kredit- und Debitkartenzahlungen von überall da an, wo Ihr Geschäft Sie hinführt.
<G-vec00120-002-s646><accept.annehmen><en> To secure our claims against the Purchaser, the Purchaser also assigns to us such claims which he accrues based on the intermingling of the reserved goods with a property against a third party; we accept this assignation today.
<G-vec00120-002-s646><accept.annehmen><de> Zur Sicherung der Forderungen der Phicomm Europe GmbH gegen den Kunden tritt der Kunde auch solche Forderungen an Phicomm Europe GmbH ab, die ihm durch die Verbindung der Vorbehaltsware mit einem Grundstück gegen einen Dritten erwachsen; die Phicomm Europe GmbH nimmt diese Abtretung schon jetzt an.
<G-vec00120-002-s647><accept.annehmen><en> • Will accept 0.4 - 1.1mm (26-18 gauge) conductors.
<G-vec00120-002-s647><accept.annehmen><de> • Nimmt 0,4 - 1.1mm (Messgerät 26-18) die Leiter an.
<G-vec00120-002-s648><accept.annehmen><en> 7.3 If reserved goods are sold alone or together with goods that are not the property of the vendor, the purchaser shall immediately assign the claims arising from the resale to the value of the reserved goods together with all ancillary rights and priority over the other claims. The vendor shall accept the assignment.
<G-vec00120-002-s648><accept.annehmen><de> Wir Vorbehaltsware allein oder zusammen mit nicht dem Verwender gehörender Ware veräußert, so tritt der Kunde schon jetzt die aus der Weiterveräußerung entstehenden Forderungen in Höhe des Wertes der Vorbehaltsware mit allen Nebenrechten und im Rang vor dem Rest ab; der Verwender nimmt die Abtretung an.
<G-vec00120-002-s649><accept.annehmen><en> The museum will not accept fakes as donations, so it’s important that you only purchase the authentic pieces. Steps Part 1
<G-vec00120-002-s649><accept.annehmen><de> Das Museum nimmt Fälschungen nicht als Schenkung von dir an, darum ist es wichtig, dass du nur echte Kunst kaufst.
<G-vec00120-002-s650><accept.annehmen><en> But Chester Dugan can’t worry about things he doesn’t understand. I just accept them.
<G-vec00120-002-s650><accept.annehmen><de> Aber Chester Dugan macht sich keine Gedanken über Dinge, die er nicht versteht — er nimmt sie einfach hin.
<G-vec00120-002-s651><accept.annehmen><en> The seller shall accept the assignment.
<G-vec00120-002-s651><accept.annehmen><de> Der Verkäufer nimmt diese Abtretung an.
<G-vec00120-002-s652><accept.annehmen><en> If neither you personally nor your neighbour can accept the parcel, GLS will take it to the nearest GLS ParcelShop.
<G-vec00120-002-s652><accept.annehmen><de> Wird der Empfänger nicht angetroffen und nimmt kein Nachbar das Paket an, bringt GLS es in den nächstgelegenen GLS PaketShop.
<G-vec00120-002-s653><accept.annehmen><en> For as soon as the person discovers correlations which harmonise with God's nature, that is, which show God's love, wisdom and omnipotence, he will accept what is offered to him as plausible.
<G-vec00120-002-s653><accept.annehmen><de> Denn sowie der Mensch Zusammenhänge entdeckt, die mit dem Wesen Gottes in Einklang zu bringen sind, d.h. die Liebe, Weisheit und Allmacht Gottes erkennen lassen, nimmt er das ihm Gebotene als glaubwürdig an.
<G-vec00120-002-s654><accept.annehmen><en> A single tap allows you to play music or pause it, pushing from top to bottom controls volume, double tap allows you to go to the next song/accept a call, triple tap allows you to go back to the previous song, and a press and hold brings up the menu and ambient sound.
<G-vec00120-002-s654><accept.annehmen><de> Ein Tippen startet oder stoppt die Musikwiedergabe, vertikales Wischen steuert die Lautstärke, ein Doppel-Tipp springt zum nächsten Lied oder nimmt einen Anruf an, dreimaliges Tippen springt ein Lied zurück, Tippen und Halten führt ins Menü und aktiviert die Umgebungsgeräusche.
<G-vec00120-002-s655><accept.annehmen><en> 9.3 If the reserved goods are sold alone or together with goods not belonging to Heyer Medical AG, the Purchaser shall assign all accounts receivable arising from the resale in the amount of the value of the reserved goods, with all ancillary rights, before the others; Heyer Medical AG shall accept this assignment.
<G-vec00120-002-s655><accept.annehmen><de> 9.3 Wird die Vorbehaltsware allein oder zusammen mit nicht der Heyer Medical AG gehörenden Ware veräußert, so tritt der Besteller schon jetzt die aus der Weiterveräußerung entstehen-den Forderungen in Höhe des Wertes der Vorbehaltsware mit allen Nebenrechten und Rang vor dem Rest ab; die Heyer Medical AG nimmt diese Abtretung an.
<G-vec00120-002-s656><accept.annehmen><en> The hotel will only accept payments in Euro or Hungarian forint on checkout.
<G-vec00120-002-s656><accept.annehmen><de> Das Hotel nimmt vor Ort Zahlungen ausschließlich in Euro und in Ungarischen Forint entgegegen.
<G-vec00120-002-s657><accept.annehmen><en> TTBV shall accept the assignment.
<G-vec00120-002-s657><accept.annehmen><de> TTBV nimmt die Abtretung an.
<G-vec00120-002-s658><accept.annehmen><en> Hope Karma will accept my peace offer.
<G-vec00120-002-s658><accept.annehmen><de> Ich hoffe das Karma nimmt mein Friedensangebot an.
<G-vec00120-002-s659><accept.annehmen><en> Our service team will help you with any user questions, import the latest security updates and accept any requests for changes.
<G-vec00120-002-s659><accept.annehmen><de> Unser Service-Team hilft Ihnen bei Anwenderfragen, spielt die neuesten Sicherheitsupdates ein und nimmt Ihre Änderungswünsche entgegen.
<G-vec00120-002-s660><accept.annehmen><en> A host Member State which requires of its nationals proof of good character or good repute when they take up for the first time an activity in the field of architecture must accept as sufficient evidence, in respect of nationals of other Member States, a certificate issued by a competent authority in the Member State of origin or in the Member State from which the foreign national comes.
<G-vec00120-002-s660><accept.annehmen><de> Der Aufnahmemitgliedstaat, der von seinen Staatsangehörigen einen Zuverlässigkeitsnachweis für den ersten Zugang zu einer der Tätigkeiten im Bereich Architektur fordert, nimmt als ausreichenden Nachweis für die Staatsangehörigen der anderen Mitgliedstaaten eine von einer zuständigen Behörde des Herkunfts- oder Ursprungsmitgliedstaats ausgestellte Bescheinigung an.
<G-vec00120-002-s661><accept.annehmen><en> Reutter Group herewith accept the assignment.
<G-vec00120-002-s661><accept.annehmen><de> Reutter-Group nimmt hiermit die Abtretung an.
<G-vec00120-002-s662><accept.annehmen><en> Most sights will accept anyone as long as is in adult age of 18 years and above.
<G-vec00120-002-s662><accept.annehmen><de> Der meiste Anblick nimmt jedermann an, solange im erwachsenen Alter von 18 Jahren und oben ist.
<G-vec00120-002-s663><accept.annehmen><en> Every tax office in the world is set up to accept applications directly from taxpayers so yes, you can file your return yourself.
<G-vec00120-002-s663><accept.annehmen><de> Jede Steuerbehörde weltweit nimmt Erklärungen direkt von den Steuerzahlern an, somit können selbstverständlich auch Sie Ihre Steuererklärung selbst einreichen.
<G-vec00120-002-s664><accept.annehmen><en> Therefore, from the depths of your heart, with as open a consciousness as possible, accept all that may arrive in your life, as strange as it may seem at times, but all the while keeping your balance and being well anchored on the Earth.
<G-vec00120-002-s664><accept.annehmen><de> Aus dem tiefsten eures Herzens also, mit dem höchstmöglichen offenen Bewusstsein, nimmt alles an, was euch in eurem Leben passieren kann, so seltsam es euch manchmal erscheinen kann, aber indem Ihr immer das Gleichgewicht behaltet, indem Ihr immer gut an der Erde verankert seid.
<G-vec00120-002-s456><accept.erklären><en> By clicking “Accept”, you consent to the use of ALL the cookies.
<G-vec00120-002-s456><accept.erklären><de> Durch die Nutzung dieser Website erklären Sie sich mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s457><accept.erklären><en> By accessing and browsing this Website, you accept to the terms of the most recent version of this Privacy Statement.
<G-vec00120-002-s457><accept.erklären><de> Mit dem Zugriff auf diese Website und deren Nutzung erklären Sie sich mit den Bedingungen dieser Datenschutzerklärung in ihrer jeweils gültigen Fassung einverstanden.
<G-vec00120-002-s458><accept.erklären><en> By providing your personal data on this Website [www.avr.be and/or dealerzone.avr.be], whether or not with accompanying e-mail addresses, you declare that you have read and expressly accept this Privacy Policy, as well as the processing itself.
<G-vec00120-002-s458><accept.erklären><de> Durch die Bereitstellung Ihrer personenbezogenen Daten auf dieser Webseite [www.avr.be und/oder dealerzone.avr.be], ob mit oder ohne dazugehörige E-Mail-Adressen, erklären Sie, diese Datenschutzrichtlinie zur Kenntnis genommen zu haben und Sie erklären ebenfalls ausdrücklich, mit dieser Richtlinie und mit der Verarbeitung Ihrer Daten einverstanden zu sein.
<G-vec00120-002-s459><accept.erklären><en> By continuing to browse our site you accept our cookie policy.
<G-vec00120-002-s459><accept.erklären><de> Mit der weiteren Nutzung der Webseite erklären Sie sich mit unseren Cookies-Richtlinien einverstanden.
<G-vec00120-002-s460><accept.erklären><en> By accessing and using the website, you expressly accept the following general terms and conditions.
<G-vec00120-002-s460><accept.erklären><de> Mit dem Zugang zur Website und ihrer Nutzung erklären Sie sich ausdrücklich mit den folgenden allgemeinen Bedingungen einverstanden.
<G-vec00120-002-s461><accept.erklären><en> Vision Toaster By browsing this site, you accept the use of cookies to improve your browsing experience and offer you content and advertising tailored to your interests.
<G-vec00120-002-s461><accept.erklären><de> FRÜHSTÜCK Toaster Durch die weitere Nutzung dieser Website erklären Sie sich für eine bessere Nutzbarkeit und auf Sie abgestimmte Inhalte und Werbungen mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s462><accept.erklären><en> this website, you automatically accept the use of cookies to record visit statistics and enhance user experience.
<G-vec00120-002-s462><accept.erklären><de> Durch die Nutzung dieser Website erklären Sie sich mit der Verwendung von Cookies einverstanden, die es uns ermöglichen, Besucherstatistiken zu erstellen.
<G-vec00120-002-s463><accept.erklären><en> By submitting an order, you accept and agree to these Terms and Conditions.
<G-vec00120-002-s463><accept.erklären><de> Durch das Absenden einer Bestellung erklären Sie sich ausdrücklich mit diesen AGBs einverstanden.
<G-vec00120-002-s464><accept.erklären><en> YOUR CONTINUED USE OF THE APPLICATION AFTER ANY SUCH MODIFICATION MEANS THAT YOU ACCEPT THE MODIFIED POLICY.
<G-vec00120-002-s464><accept.erklären><de> Durch die Weiternutzung der Applikation im Anschluss an eine Änderung der Policy erklären Sie sich mit der geänderten Policy einverstanden.
<G-vec00120-002-s465><accept.erklären><en> By using this website, you accept the using of cookies.
<G-vec00120-002-s465><accept.erklären><de> Durch die Nutzung dieser Webseite erklären Sie sich mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s466><accept.erklären><en> If you continue browsing we consider you accept the use of cookies.
<G-vec00120-002-s466><accept.erklären><de> Mit der Nutzung der Seite erklären Sie sich mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s467><accept.erklären><en> With the forwarding of this form you agree to accept that your personal information is being documented, transmitted and processed by ESYON.
<G-vec00120-002-s467><accept.erklären><de> Mit der Nutzung dieses Formulars erklären Sie sich mit der Speicherung und Verarbeitung ihrer Daten durch diese Website einverstanden.
<G-vec00120-002-s468><accept.erklären><en> By using this web site you accept the processing of the generated data by Google in the aforementioned way for the described purpose. ©2017 Looki Publishing GmbH.
<G-vec00120-002-s468><accept.erklären><de> Durch die Nutzung dieser Website erklären Sie sich mit der Bearbeitung der über Sie erhobenen Daten durch Google in der zuvor beschriebenen Art und Weise und zu dem zuvor benannten Zweck einverstanden.
<G-vec00120-002-s469><accept.erklären><en> Your Account If you have registered with Historicus Forma, you are responsible for maintaining the confidentiality of log-in information and for restricting access to your computer, and you agree to accept responsibility for all activities that occur under your account or password.
<G-vec00120-002-s469><accept.erklären><de> Wenn Sie einen Amazon Service nutzen, sind Sie für die Sicherstellung der Vertraulichkeit Ihres Kontos und Passworts und für die Beschränkung des Zugangs zu Ihrem Computer und Ihren mobilen Geräten verantwortlich und soweit unter anwendbarem Recht zulässig, erklären Sie sich damit einverstanden, für alle Aktivitäten verantwortlich zu sein, die über Ihr Konto oder Passwort vorgenommen werden.
<G-vec00120-002-s470><accept.erklären><en> By using our site, you indicate that you accept these terms and you agree to abide by them.
<G-vec00120-002-s470><accept.erklären><de> Durch die Nutzung unserer Websites erklären Sie sich mit diesen Nutzungsbedingungen und deren Einhaltung einverstanden.
<G-vec00120-002-s471><accept.erklären><en> Your use of the Websites, Apps, or the Services, as applicable, following these changes means that you accept the revised Privacy Policy.
<G-vec00120-002-s471><accept.erklären><de> Wenn Sie die Services nach derartigen Änderungen weiter nutzen, erklären Sie sich dadurch mit der überarbeiteten Datenschutzrichtlinie einverstanden.
<G-vec00120-002-s472><accept.erklären><en> By continuing to use this website, you are giving consent to cookies being used. Cookie policy. I accept cookies from this site.
<G-vec00120-002-s472><accept.erklären><de> Mit einem Klick auf "Ok" und/oder der weiteren Nutzung der Website erklären Sie sich einverstanden, dass auf Ihrem Gerät Cookies gespeichert werden.
<G-vec00120-002-s474><accept.erklären><en> By continuing to use these pages, you accept that policy.
<G-vec00120-002-s474><accept.erklären><de> Durch die Nutzung unserer Seiten erklären Sie sich damit einverstanden.
<G-vec00120-002-s380><accept.sein><en> If you do not accept these terms and conditions in its entirety, discontinue use of This Website.
<G-vec00120-002-s380><accept.sein><de> WENN SIE MIT DEN NUTZUNGSBEDINGUNGEN NICHT EINVERSTANDEN SIND, VERWENDEN SIE DIESE WEBSITE NICHT.
<G-vec00120-002-s381><accept.sein><en> Often, exclusion is the only method that is concluded. Assimilation meets with resistance from those concerned, and integration projects come up against resistance from the majority of the host society, who accept the value of integration but prefer not to be involved in the process.
<G-vec00120-002-s381><accept.sein><de> Oft ist nur der Ausschluss in Reichweite, die Assimilation trifft auf den Widerstand der Betroffenen und die Integrationsprojekte stoßen auf den Widerstand der Mehrheit der Gastgesellschaft, die einverstanden ist mit dem abstrakten Wert der Integration, es aber vorzieht, an diesem Prozess nicht teilzunehmen.
<G-vec00120-002-s382><accept.sein><en> I hereby accept and assume full responsibility for any and all risks of illness, injury or loss of life to myself and loss or damage to my property arising out of the participation in the trip organized by Cabalgatas Antilco.
<G-vec00120-002-s382><accept.sein><de> Hiermit erkläre ich mich einverstanden und übernehme volle Veranwortung für jegliche Arten von Gesundheitsrisiken, Verletzungen oder Tod und Verlust von Eigentum während der Teilnahme an von Antilco organisierten Touren.
<G-vec00120-002-s383><accept.sein><en> Please click on the button marked "I Accept" at the end of these terms and conditions if you accept them.
<G-vec00120-002-s383><accept.sein><de> Bitte klicken Sie auf die Schaltfläche "Ich bin einverstanden" am Schluss dieser Bedingungen, wenn Sie damit einverstanden sind.
<G-vec00120-002-s384><accept.sein><en> Azerbaijan naturally can not accept these conditions.
<G-vec00120-002-s384><accept.sein><de> Aserbaidschan kann natürlich mit diesen Voraussetzungen nicht einverstanden sein.
<G-vec00120-002-s385><accept.sein><en> If you are unable to accept one or more clauses in our General Terms and Conditions or if you are troubled when reading these General Terms and Conditions then please navigate away from this Website immediately.
<G-vec00120-002-s385><accept.sein><de> Sollten Sie mit einem oder mehreren Punkten unserer Allgemeinen Geschäftsbedingungen nicht einverstanden sein, brechen Sie bitte Ihren Besuch an dieser Stelle ab.
<G-vec00120-002-s386><accept.sein><en> If you continue to use this site we will assume that you accept it.
<G-vec00120-002-s386><accept.sein><de> Wenn Sie diese Seite weiterhin nutzen, gehen wir davon aus, dass Sie damit einverstanden sind.
<G-vec00120-002-s387><accept.sein><en> If you do not accept the license terms, you may delete the software and all its copies from your media.
<G-vec00120-002-s387><accept.sein><de> Sind Sie mit den Lizenzbestimmungen nicht einverstanden, müssen Sie die Software sowie dessen Kopien von Ihren Datenträgern löschen.
<G-vec00120-002-s388><accept.sein><en> By accessing and browsing the Site, you declare that you fully understand, accept and agree to, without limitation or qualification, these terms and conditions as well as any other notices or instructions that may be provided to you by Bristol-Myers Squibb Company and/or its affiliates when accessing or browsing the Site.
<G-vec00120-002-s388><accept.sein><de> Durch das Aufrufen und Browsen auf der Website erklären Sie sich einschränkungs- und bedingungslos mit diesen Bedingungen sowie jeglichen sonstigen Hinweisen oder Anweisungen, die Ihnen möglicherweise von Bristol-Myers Squibb beim Zugriff auf die Website oder beim Browsen angezeigt werden, einverstanden und bestätigen, dass Sie diese in vollem Umfang verstanden haben.
<G-vec00120-002-s389><accept.sein><en> To know more, read our Privacy Policy Accept and Continue.
<G-vec00120-002-s389><accept.sein><de> Mit der Benutzung unserer Website erklären Sie sich mit unseren Datenschutzrichtlinien einverstanden.
<G-vec00120-002-s390><accept.sein><en> If you do not accept any of these terms, leave this website now.
<G-vec00120-002-s390><accept.sein><de> Falls Sie mit diesen Bestimmungen nicht einverstanden sind, bitten wir Sie, diese Website jetzt zu verlassen.
<G-vec00120-002-s391><accept.sein><en> I have read the privacy policy and hereby accept them
<G-vec00120-002-s391><accept.sein><de> Ich habe die Datenschutzerklärung gelesen und bin damit einverstanden.
<G-vec00120-002-s392><accept.sein><en> The charge requires a consent, which we will try to obtain from those who are willing to accept the increase in the near future.
<G-vec00120-002-s392><accept.sein><de> Dies würde eine Zustimmung der Paten erfordern, die wir demnächst einholen würden bei denen, die einverstanden sind.
<G-vec00120-002-s393><accept.sein><en> The Principal agrees explicitly to accept invoices transmitted electronically by the Agent (HCH IT Services GmbH). 12.
<G-vec00120-002-s393><accept.sein><de> Der Auftraggeber erklärt sich mit der Zusendung von Rechnungen in elektronischer Form durch den Auftragnehmer (HCH IT Services GmbH) ausdrücklich einverstanden.
<G-vec00120-002-s394><accept.sein><en> If you continue browsing we consider you accept the use of cookies. Accept
<G-vec00120-002-s394><accept.sein><de> Durch die fortgesetzte Nutzung unserer Website erklärst du dich mit der Verwendung der Cookies einverstanden.
<G-vec00120-002-s395><accept.sein><en> 1.2 You should print a copy of these conditions of sale for future reference. 1.3 Please click on the button marked "I Accept" at the end of the order process if you accept them.
<G-vec00120-002-s395><accept.sein><de> 1.3 Bitte klicken Sie am Ende des Bestellprozesses auf die Schaltfläche "Ich akzeptiere die Verkaufs- und Lieferbedingungen von Hamilton", falls Sie mit diesen Verkaufs- und Lieferbedingungen einverstanden sind.
<G-vec00120-002-s396><accept.sein><en> Body Oils and Creams - NUXE If you continue browsing without changing your settings, this confirms that you accept the use of cookies as a tool to perform the analysis of user navigation.
<G-vec00120-002-s396><accept.sein><de> Intensive Haut- und Gesichtspflege - Lippenpflege Rêve de Miel® - NUXE Wenn Sie die Navigation auf dieser Website fortsetzen, ohne Ihre Cookie-Einstellungen zu ändern, erklären Sie sich mit der Nutzung von Cookies einverstanden.
<G-vec00120-002-s397><accept.sein><en> If CUSTOMER does not accept the AGREEMENT in its entirety, CUSTOMER may not access or use the SOFTWARE.
<G-vec00120-002-s397><accept.sein><de> Wenn Sie nicht mit den Bedingungen dieser EULA einverstanden sind, installieren oder verwenden Sie nicht das SOFTWAREPRODUKT.
<G-vec00120-002-s398><accept.sein><en> If you do not accept these Terms of Use or you do not meet or comply with their provisions, you may not use the Website
<G-vec00120-002-s398><accept.sein><de> Wenn Sie NICHT mit den Nutzungsbedingungen einverstanden sind, dürfen Sie diese Website NICHT nutzen.
<G-vec00120-002-s456><accept.sich_erklären><en> By clicking “Accept”, you consent to the use of ALL the cookies.
<G-vec00120-002-s456><accept.sich_erklären><de> Durch die Nutzung dieser Website erklären Sie sich mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s457><accept.sich_erklären><en> By accessing and browsing this Website, you accept to the terms of the most recent version of this Privacy Statement.
<G-vec00120-002-s457><accept.sich_erklären><de> Mit dem Zugriff auf diese Website und deren Nutzung erklären Sie sich mit den Bedingungen dieser Datenschutzerklärung in ihrer jeweils gültigen Fassung einverstanden.
<G-vec00120-002-s458><accept.sich_erklären><en> By providing your personal data on this Website [www.avr.be and/or dealerzone.avr.be], whether or not with accompanying e-mail addresses, you declare that you have read and expressly accept this Privacy Policy, as well as the processing itself.
<G-vec00120-002-s458><accept.sich_erklären><de> Durch die Bereitstellung Ihrer personenbezogenen Daten auf dieser Webseite [www.avr.be und/oder dealerzone.avr.be], ob mit oder ohne dazugehörige E-Mail-Adressen, erklären Sie, diese Datenschutzrichtlinie zur Kenntnis genommen zu haben und Sie erklären ebenfalls ausdrücklich, mit dieser Richtlinie und mit der Verarbeitung Ihrer Daten einverstanden zu sein.
<G-vec00120-002-s459><accept.sich_erklären><en> By continuing to browse our site you accept our cookie policy.
<G-vec00120-002-s459><accept.sich_erklären><de> Mit der weiteren Nutzung der Webseite erklären Sie sich mit unseren Cookies-Richtlinien einverstanden.
<G-vec00120-002-s460><accept.sich_erklären><en> By accessing and using the website, you expressly accept the following general terms and conditions.
<G-vec00120-002-s460><accept.sich_erklären><de> Mit dem Zugang zur Website und ihrer Nutzung erklären Sie sich ausdrücklich mit den folgenden allgemeinen Bedingungen einverstanden.
<G-vec00120-002-s461><accept.sich_erklären><en> Vision Toaster By browsing this site, you accept the use of cookies to improve your browsing experience and offer you content and advertising tailored to your interests.
<G-vec00120-002-s461><accept.sich_erklären><de> FRÜHSTÜCK Toaster Durch die weitere Nutzung dieser Website erklären Sie sich für eine bessere Nutzbarkeit und auf Sie abgestimmte Inhalte und Werbungen mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s462><accept.sich_erklären><en> this website, you automatically accept the use of cookies to record visit statistics and enhance user experience.
<G-vec00120-002-s462><accept.sich_erklären><de> Durch die Nutzung dieser Website erklären Sie sich mit der Verwendung von Cookies einverstanden, die es uns ermöglichen, Besucherstatistiken zu erstellen.
<G-vec00120-002-s463><accept.sich_erklären><en> By submitting an order, you accept and agree to these Terms and Conditions.
<G-vec00120-002-s463><accept.sich_erklären><de> Durch das Absenden einer Bestellung erklären Sie sich ausdrücklich mit diesen AGBs einverstanden.
<G-vec00120-002-s464><accept.sich_erklären><en> YOUR CONTINUED USE OF THE APPLICATION AFTER ANY SUCH MODIFICATION MEANS THAT YOU ACCEPT THE MODIFIED POLICY.
<G-vec00120-002-s464><accept.sich_erklären><de> Durch die Weiternutzung der Applikation im Anschluss an eine Änderung der Policy erklären Sie sich mit der geänderten Policy einverstanden.
<G-vec00120-002-s465><accept.sich_erklären><en> By using this website, you accept the using of cookies.
<G-vec00120-002-s465><accept.sich_erklären><de> Durch die Nutzung dieser Webseite erklären Sie sich mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s466><accept.sich_erklären><en> If you continue browsing we consider you accept the use of cookies.
<G-vec00120-002-s466><accept.sich_erklären><de> Mit der Nutzung der Seite erklären Sie sich mit der Verwendung von Cookies einverstanden.
<G-vec00120-002-s467><accept.sich_erklären><en> With the forwarding of this form you agree to accept that your personal information is being documented, transmitted and processed by ESYON.
<G-vec00120-002-s467><accept.sich_erklären><de> Mit der Nutzung dieses Formulars erklären Sie sich mit der Speicherung und Verarbeitung ihrer Daten durch diese Website einverstanden.
<G-vec00120-002-s468><accept.sich_erklären><en> By using this web site you accept the processing of the generated data by Google in the aforementioned way for the described purpose. ©2017 Looki Publishing GmbH.
<G-vec00120-002-s468><accept.sich_erklären><de> Durch die Nutzung dieser Website erklären Sie sich mit der Bearbeitung der über Sie erhobenen Daten durch Google in der zuvor beschriebenen Art und Weise und zu dem zuvor benannten Zweck einverstanden.
<G-vec00120-002-s469><accept.sich_erklären><en> Your Account If you have registered with Historicus Forma, you are responsible for maintaining the confidentiality of log-in information and for restricting access to your computer, and you agree to accept responsibility for all activities that occur under your account or password.
<G-vec00120-002-s469><accept.sich_erklären><de> Wenn Sie einen Amazon Service nutzen, sind Sie für die Sicherstellung der Vertraulichkeit Ihres Kontos und Passworts und für die Beschränkung des Zugangs zu Ihrem Computer und Ihren mobilen Geräten verantwortlich und soweit unter anwendbarem Recht zulässig, erklären Sie sich damit einverstanden, für alle Aktivitäten verantwortlich zu sein, die über Ihr Konto oder Passwort vorgenommen werden.
<G-vec00120-002-s470><accept.sich_erklären><en> By using our site, you indicate that you accept these terms and you agree to abide by them.
<G-vec00120-002-s470><accept.sich_erklären><de> Durch die Nutzung unserer Websites erklären Sie sich mit diesen Nutzungsbedingungen und deren Einhaltung einverstanden.
<G-vec00120-002-s471><accept.sich_erklären><en> Your use of the Websites, Apps, or the Services, as applicable, following these changes means that you accept the revised Privacy Policy.
<G-vec00120-002-s471><accept.sich_erklären><de> Wenn Sie die Services nach derartigen Änderungen weiter nutzen, erklären Sie sich dadurch mit der überarbeiteten Datenschutzrichtlinie einverstanden.
<G-vec00120-002-s472><accept.sich_erklären><en> By continuing to use this website, you are giving consent to cookies being used. Cookie policy. I accept cookies from this site.
<G-vec00120-002-s472><accept.sich_erklären><de> Mit einem Klick auf "Ok" und/oder der weiteren Nutzung der Website erklären Sie sich einverstanden, dass auf Ihrem Gerät Cookies gespeichert werden.
<G-vec00120-002-s474><accept.sich_erklären><en> By continuing to use these pages, you accept that policy.
<G-vec00120-002-s474><accept.sich_erklären><de> Durch die Nutzung unserer Seiten erklären Sie sich damit einverstanden.
<G-vec00120-002-s684><accept.zustimmen><en> I accept the privacy policy terms specified within the scope of the relevant legislation on the personal data protection and share my personal data.
<G-vec00120-002-s684><accept.zustimmen><de> Ich stimme den im Rahmen der einschlägigen Gesetzgebung bezüglich des Schutzes personenbezogener Daten aufgeführten Datenschutzhinweisen zu und teile meine personenbezogenen Daten mit.
<G-vec00120-002-s685><accept.zustimmen><en> Project Yes, I accept that my data will be sent to the manufacturer COR to process my request.
<G-vec00120-002-s685><accept.zustimmen><de> Projekt Ja, ich stimme zu, dass meine Daten an den Hersteller JUNG zur Bearbeitung meiner Anfrage weitergegeben werden.
<G-vec00120-002-s686><accept.zustimmen><en> Yes, I accept that the manufacturer Züco may save my data for marketing purposes and is allowed to contact me.
<G-vec00120-002-s686><accept.zustimmen><de> Ja, ich stimme zu, dass der Hersteller Züco meine Daten für Marketingzwecke speichern und mich darüber kontaktieren darf.
<G-vec00120-002-s687><accept.zustimmen><en> Yes, I accept that the manufacturer Antrax IT may save my data for marketing purposes and is allowed to contact me.
<G-vec00120-002-s687><accept.zustimmen><de> Ja, ich stimme zu, dass der Hersteller Antrax IT meine Daten für Marketingzwecke speichern und mich darüber kontaktieren darf.
<G-vec00120-002-s688><accept.zustimmen><en> I accept this IMPORTANT NOTICE AND DISCLAIMER, Aquantum’s Terms And Conditions as well as its Privacy Policy.
<G-vec00120-002-s688><accept.zustimmen><de> Ich stimme diesem WICHTIGEN HINWEIS UND HAFTUNGSAUSSCHLUSS, den Rechtlichen Hinweisen und der Datenschutzrichtlinie der Aquantum zu.
<G-vec00120-002-s689><accept.zustimmen><en> Please enter your contact details I have read the privacy statement and I accept it.
<G-vec00120-002-s689><accept.zustimmen><de> Kontaktdetails Ich stimme der Datenschutzerklärung von Panasonic Electric Works zu.
<G-vec00120-002-s690><accept.zustimmen><en> I accept, that this site uses Cookies for analyze purposes.
<G-vec00120-002-s690><accept.zustimmen><de> Sitemap Ich stimme zu, dass diese Seite Cookies für Analysen verwendet.
<G-vec00120-002-s691><accept.zustimmen><en> Yes, I accept that my data will be sent to the manufacturer [more] to process my request.
<G-vec00120-002-s691><accept.zustimmen><de> Ja, ich stimme zu, dass meine Daten an den Hersteller [more] zur Bearbeitung meiner Anfrage weitergegeben werden.
<G-vec00120-002-s692><accept.zustimmen><en> Yes, I accept that my data will be sent to the manufacturer ClassiCon to process my request.
<G-vec00120-002-s692><accept.zustimmen><de> Ja, ich stimme zu, dass meine Daten an den Hersteller DEDON zur Bearbeitung meiner Anfrage weitergegeben werden.
<G-vec00120-002-s693><accept.zustimmen><en> Work Email Password By agreeing to a free trial I accept the Terms and Conditions
<G-vec00120-002-s693><accept.zustimmen><de> Firmen-Email Passwort Durch die Nutzung der kostenlosen Testversion stimme ich den Allgemeinen Geschäftsbedingungen zu.
<G-vec00120-002-s694><accept.zustimmen><en> Yes, I accept that my data will be sent to the manufacturer ClassiCon to process my request.
<G-vec00120-002-s694><accept.zustimmen><de> Ja, ich stimme zu, dass meine Daten an den Hersteller JUNG zur Bearbeitung meiner Anfrage weitergegeben werden.
<G-vec00120-002-s695><accept.zustimmen><en> I accept, that this site uses Cookies for analyze purposes.
<G-vec00120-002-s695><accept.zustimmen><de> Impressum Ich stimme zu, dass diese Seite Cookies für Analysen verwendet.
<G-vec00120-002-s696><accept.zustimmen><en> I confirm that I have read and accept the Privacy Statement.
<G-vec00120-002-s696><accept.zustimmen><de> Ich habe die Datenschutzerklärung gelesen und stimme ihrer Geltung zu.
<G-vec00120-002-s697><accept.zustimmen><en> Message I have read the Privacy statement and I accept it.
<G-vec00120-002-s697><accept.zustimmen><de> Ja, ich habe die Datenschutzerklärung gelesen und stimme dieser zu.
<G-vec00120-002-s698><accept.zustimmen><en> Yes, I accept that the manufacturer Porro may save my data for marketing purposes and is allowed to contact me.
<G-vec00120-002-s698><accept.zustimmen><de> Ja, ich stimme zu, dass der Hersteller Porro meine Daten für Marketingzwecke speichern und mich darüber kontaktieren darf.
<G-vec00120-002-s699><accept.zustimmen><en> Services I accept, that this site uses Cookies for analyze purposes.
<G-vec00120-002-s699><accept.zustimmen><de> Leistungen Ich stimme zu, dass diese Seite Cookies für Analysen verwendet.
<G-vec00120-002-s700><accept.zustimmen><en> Yes, I accept that my data will be sent to the manufacturer Gloster Furniture to process my request.
<G-vec00120-002-s700><accept.zustimmen><de> Ja, ich stimme zu, dass meine Daten an den Hersteller Gloster Furniture zur Bearbeitung meiner Anfrage weitergegeben werden.
<G-vec00120-002-s701><accept.zustimmen><en> Yes, I accept that my data will be sent to the manufacturer to process my request.
<G-vec00120-002-s701><accept.zustimmen><de> Ja, ich stimme zu, dass meine Daten an den Hersteller zur Bearbeitung meiner Anfrage weitergegeben werden.
<G-vec00120-002-s702><accept.zustimmen><en> I've read the privacy policy and accept it.
<G-vec00120-002-s702><accept.zustimmen><de> Ich habe die Datenschutzbestimmungen gelesen und stimme ihnen zu.
<G-vec00120-002-s703><accept.zustimmen><en> By submitting this form, you accept the Mollom privacy policy.
<G-vec00120-002-s703><accept.zustimmen><de> Mit dem Absenden dieses Formulars stimmen sie unseren Datenschutzbestimmungen zu.
<G-vec00120-002-s704><accept.zustimmen><en> If you continue to use this page, you automatically accept the use of cookies.
<G-vec00120-002-s704><accept.zustimmen><de> Durch die weitere Nutzung dieser Webseite stimmen Sie der Verwendung von Cookies zu.
<G-vec00120-002-s705><accept.zustimmen><en> By continuing to browse this website, you accept the use of cookies destined to provide you services and offers tailored to your interests.
<G-vec00120-002-s705><accept.zustimmen><de> Indem Sie diese Seite nutzen, stimmen Sie der Verwendung von Cookies zu, dank derer wir Ihnen Dienstleistungen und Angebote unterbreiten können, die auf Ihre Interessen zugeschnitten sind.
<G-vec00120-002-s706><accept.zustimmen><en> By transmitting this form you accept our data protection declaration.
<G-vec00120-002-s706><accept.zustimmen><de> Mit dem Absenden dieses Formulars stimmen Sie unserer Datenschutzerklärung zu.
<G-vec00120-002-s707><accept.zustimmen><en> By using this website, you accept the use of cookies.
<G-vec00120-002-s707><accept.zustimmen><de> Wenn Sie die Website weiter nutzen, stimmen Sie der Verwendung von Cookies zu.
<G-vec00120-002-s708><accept.zustimmen><en> You accept the collection of information by cookies by navigating on male
<G-vec00120-002-s708><accept.zustimmen><de> Sie stimmen der Erfassung von Informationen durch Cookies zu, indem Sie auf unserer Webseite navigieren.
<G-vec00120-002-s709><accept.zustimmen><en> By continuing to browse this website, you declare to accept the use of cookies.
<G-vec00120-002-s709><accept.zustimmen><de> Wenn Sie weiterhin auf diesen Seiten surfen, stimmen Sie der Cookie-Nutzung zu.
<G-vec00120-002-s710><accept.zustimmen><en> By continuing to browse the website or closing this banner, you accept that we use cookies that are necessary for the functionality of the website.
<G-vec00120-002-s710><accept.zustimmen><de> Wir verwenden Cookies - Durch die Nutzung dieser Website oder das Schließen dieser Website stimmen Sie unserer Cookie-Richtlinie zu.
<G-vec00120-002-s711><accept.zustimmen><en> Participants accept that in case of a win, they will be contacted by email or by phone.
<G-vec00120-002-s711><accept.zustimmen><de> Teilnehmer stimmen zu, im Falle eines Gewinnes, per Email oder Telefon kontaktiert zu werden.
<G-vec00120-002-s712><accept.zustimmen><en> You accept this Privacy Policy when you sign up for, access, or use our products, services, content, features, technologies or functions offered on our website and all related sites, applications, and services (collectively “PayPal Services”).
<G-vec00120-002-s712><accept.zustimmen><de> Sie stimmen diesen Datenschutzgrundsätzen zu, indem Sie sich für unsere Produkte, Services, Inhalte oder technischen Funktionen sowie alle zugehörigen Seiten oder Anwendungen (gemeinsam "die PayPal-Services") neu anmelden oder diese nutzen.
<G-vec00120-002-s713><accept.zustimmen><en> PDF By continuing to browse this website, you accept that cookies will be used to ensure that your visit runs smoothly and obtain user statistics.
<G-vec00120-002-s713><accept.zustimmen><de> Durch die weitere Nutzung unserer Webseite stimmen Sie der Verwendung von Cookies zur Gewährleistung des reibungslosen Ablaufs Ihres Besuchs und zur Erstellung von Besucherstatistiken zu.
<G-vec00120-002-s714><accept.zustimmen><en> How do we use your data? By clicking subscribe, you accept that your email address will be used to create and manage your user account and if you elect, to send Aveda newsletters and information about Aveda products, events and offers.
<G-vec00120-002-s714><accept.zustimmen><de> Durch Klicken auf „Anmelden“ stimmen Sie zu, dass Ihre E-Mail-Adresse genutzt wird, um Ihr Benutzerkonto anzulegen und zu verwalten, und wenn Sie dies ankreuzen, auch, um Ihnen die Newsletter von Aveda und Informationen zu den Produkten, Veranstaltungen und Angeboten von Aveda zu schicken.
<G-vec00120-002-s715><accept.zustimmen><en> If you continue to browse on this site, you accept cookies .
<G-vec00120-002-s715><accept.zustimmen><de> Durch die Nutzung dieser Seite stimmen Sie unserer Datenschutzerklärung zu.
<G-vec00120-002-s716><accept.zustimmen><en> send Please accept the storage of cookies to see our Google Map.
<G-vec00120-002-s716><accept.zustimmen><de> Stimmen Sie bitte der Speicherung von Cookies zu, damit Sie unsere Google Map sehen können.
<G-vec00120-002-s717><accept.zustimmen><en> Please accept the terms and conditions to see the report.
<G-vec00120-002-s717><accept.zustimmen><de> Bitte stimmen Sie den Nutzungsbedingungen zu, um den Bericht anzuzeigen.
<G-vec00120-002-s718><accept.zustimmen><en> We’ll assume that you accept the use of cookies on the GROHE website.
<G-vec00120-002-s718><accept.zustimmen><de> Wenn Sie auf der Website weiter surfen, stimmen Sie damit der Cookie-Nutzung zu.
<G-vec00120-002-s719><accept.zustimmen><en> By continuing to use this site, you accept our privacy policy.Ok
<G-vec00120-002-s719><accept.zustimmen><de> Durch die weitere Nutzung der Webseite stimmen Sie der Verwendung von Cookies zu.
<G-vec00120-002-s721><accept.zustimmen><en> continue browsing you accept this use. For more info
<G-vec00120-002-s721><accept.zustimmen><de> Mit der Nutzung dieser Seite stimmen Sie dieser Verwendung zu.
<G-vec00120-002-s741><accept.zustimmen><en> If you refuse to accept these Terms, you will not be able to order any Products from our site or make any payments related thereto.
<G-vec00120-002-s741><accept.zustimmen><de> Sollten Sie den Bedingungen nicht zustimmen, wird eine Bestellung jeglicher Produkte von unserer Seite sowie die Durchführung jeglicher in Zusammenhang mit Ihrer Bestellung stehender Zahlungsvorgänge nicht möglich sein.
<G-vec00120-002-s742><accept.zustimmen><en> To continue, you must accept our Privacy & Cookie Statement.
<G-vec00120-002-s742><accept.zustimmen><de> Um fortzufahren, müssen Sie der Datenschutz- & Cookie-Erklärung zustimmen.
<G-vec00120-002-s743><accept.zustimmen><en> If you do not accept the use of cookies, you can turn cookies off in your browser’s security settings.
<G-vec00120-002-s743><accept.zustimmen><de> Wenn Sie dem Einsatz von Cookies nicht zustimmen, können Sie diesem in den Sicherheitseinstellungen Ihres Browsers widersprechen.
<G-vec00120-002-s744><accept.zustimmen><en> If you are under 21 years of age or do not accept this Privacy Policy in its entirety, please leave the Site immediately.
<G-vec00120-002-s744><accept.zustimmen><de> Wenn Sie jünger als 18 Jahre sind oder dieser Datenschutzrichtlinie nicht komplett zustimmen, verlassen Sie die Site bitte umgehend.
<G-vec00120-002-s745><accept.zustimmen><en> If you do not terminate the relationship in this way you are deemed to accept the new Terms and Conditions.
<G-vec00120-002-s745><accept.zustimmen><de> Wenn Sie die Geschäftsbeziehung nicht auf diese Weise beenden, wird davon ausgegangen, dass Sie den neuen Allgemeinen Geschäftsbedingungen zustimmen.
<G-vec00120-002-s746><accept.zustimmen><en> If you do not accept these terms, you should not continue with the installation, use, reproduction and distribution of the 3Dconnexion SDK.
<G-vec00120-002-s746><accept.zustimmen><de> Sollten Sie diesen Vorschriften nicht uneingeschränkt zustimmen können oder wollen, empfehlen wir Ihnen, von der Installation, dem Gebrauch sowie der Vervielfältigung und Distribution des 3Dconnexion-SDK Abstand zu nehmen.
<G-vec00120-002-s747><accept.zustimmen><en> You must accept the license agreement to use this product.
<G-vec00120-002-s747><accept.zustimmen><de> Sie müssen der Lizenzvereinbarung für dieses Produkt zustimmen.
<G-vec00120-002-s748><accept.zustimmen><en> If you do not wish to accept the amended Privacy Policy, please discontinue use of our products and services and contact us to delete your account (s).
<G-vec00120-002-s748><accept.zustimmen><de> Wenn Sie der veränderten Datenschutzerklärung nicht zustimmen möchten, dann nutzen Sie bitte unsere Produkte und Dienstleistungen nicht weiter und setzen sich zur Löschung Ihres Kontos/Ihrer Konten mit uns in Kontakt.
<G-vec00120-002-s749><accept.zustimmen><en> If you click on “Accept”, you expressly confirm that you have read, understood and accepted the important information set out below.
<G-vec00120-002-s749><accept.zustimmen><de> Durch das Anklicken von «Zustimmen» bestätigen Sie ausdrücklich, dass Sie die unten aufgeführten wichtigen Informationen gelesen und verstanden haben und ihnen zustimmen.
<G-vec00120-002-s750><accept.zustimmen><en> You can, however, set your browser so that cookies are not stored or you are informed about each cookie and can decide in the individual case whether to accept its use.
<G-vec00120-002-s750><accept.zustimmen><de> Sie können Ihren Browser aber auch so einstellen, dass keine Cookies gespeichert werden oder Sie über die einzelnen Cookies informiert werden und im Einzelfall so entscheiden können, ob Sie der Verwendung zustimmen.
<G-vec00120-002-s751><accept.zustimmen><en> The board was unable to accept this.
<G-vec00120-002-s751><accept.zustimmen><de> Die Kammer konnte dem nicht zustimmen.
<G-vec00120-002-s752><accept.zustimmen><en> If you choose not to ‘Accept’ the use of cookies we use to provide our website service, we cannot place cookies on your computer and this will affect the performance of certain functions on the site.
<G-vec00120-002-s752><accept.zustimmen><de> Wenn Sie der Verwendung von Cookies, die wir zur Bereitstellung unseres Webseite-Dienstes verwenden, nicht zustimmen, können wir keine Cookies auf Ihrem Computer ablegen, was die Leistung bestimmter Funktionen auf der Webseite beeinträchtigt.
<G-vec00120-002-s753><accept.zustimmen><en> By using our site, you indicate that you accept these terms of use and that you agree to be legally bound by them.
<G-vec00120-002-s753><accept.zustimmen><de> Durch die Nutzung unserer Website erklären Sie, dass Sie den Nutzungsbedingungen zustimmen und diese einhalten werden.
<G-vec00120-002-s754><accept.zustimmen><en> close By continuing your navigation on this site, you must accept the use and writing of Cookies on your connected device.
<G-vec00120-002-s754><accept.zustimmen><de> Wenn Sie Ihre Navigation auf dieser Website fortsetzen, müssen Sie der Verwendung und dem Schreiben von Cookies auf Ihrem verbundenen Gerät zustimmen.
<G-vec00120-002-s755><accept.zustimmen><en> If you do not accept these terms, please do not use this Website.
<G-vec00120-002-s755><accept.zustimmen><de> Bitte nutzen Sie diese Website nicht, wenn Sie diesen Bedingungen nicht zustimmen.
<G-vec00120-002-s756><accept.zustimmen><en> You must accept this agreement.
<G-vec00120-002-s756><accept.zustimmen><de> Sie müssen den Bedingungen zustimmen.
<G-vec00120-002-s757><accept.zustimmen><en> In case a user does not want to accept the adapted terms of service, the only remedy is to not use the services of RISER on the website and all its subdomains as well as the mobile application any longer.
<G-vec00120-002-s757><accept.zustimmen><de> Sollte der Nutzer den geänderten Vertragsbedingungen nicht zustimmen wollen, so besteht die einzige Abhilfe darin, die RISER Webseite sowie die mobile Applikation nicht mehr zu nutzen.
<G-vec00120-002-s758><accept.zustimmen><en> IF YOU DO NOT ACCEPT THESE TERMS OF SERVICE IN THEIR ENTIRETY, YOU MAY NOT ACCESS OR USE THE SITE, CONTENT, FILES OR SERVICES.
<G-vec00120-002-s758><accept.zustimmen><de> Wenn Sie diesen Bedingungen nicht zustimmen, sind Sie nicht berechtigt, sich Informationen von der Website, der mobilen Anwendung oder den Diensten zu verschaffen oder diese anderweitig weiter zu nutzen.
<G-vec00120-002-s759><accept.zustimmen><en> If you do not accept the use of these cookies, please disable them using the instructions in this cookie notice, for instance by following the ‘opt-out’ links provided below or by changing your browser settings so that cookies from these websites cannot be placed on your computer or mobile device.
<G-vec00120-002-s759><accept.zustimmen><de> Sollten Sie der Verwendung von Cookies nicht zustimmen, deaktivieren Sie diese bitte wie in dieser Cookie-Richtlinie beschrieben, beispielsweise indem Sie dem nachstehenden Opt-Out-Link folgen oder die Einstellungen Ihres Browsers ändern, damit von dieser Website aus keine Cookies auf Ihren Computer oder Ihr Mobilgerät gesetzt werden können.
<G-vec00189-002-s494><accept.annehmen><en> In using our website, you acknowledge that you are perfectly aware of the risks connected with the Internet and that you accept those risks.
<G-vec00189-002-s494><accept.annehmen><de> Mit der Benutzung unserer Site bestätigen Sie, dass Sie sich dieser Risiken des Internets vollkommen bewusst sind und diese Risiken in Kauf nehmen.
<G-vec00189-002-s495><accept.annehmen><en> Therefore, cryptocurrencies are only suitable for customers who can accept a loss of the invested capital.
<G-vec00189-002-s495><accept.annehmen><de> Daher sind Kryptowährungen nur für Kunden geeignet, die einen Verlust des eingesetzten Kapitals in Kauf nehmen können.
<G-vec00189-002-s496><accept.annehmen><en> Because when manufacturers demand 4 µm at 99 percent or even more today, they are of course not prepared to accept shorter change intervals, rather the opposite.
<G-vec00189-002-s496><accept.annehmen><de> Denn wenn Hersteller heute 4 µm bei 99 Prozent oder sogar noch mehr fordern, sind sie natürlich keineswegs bereit, dafür kürzere Wechselintervalle in Kauf zu nehmen, eher das Gegenteil.
<G-vec00189-002-s497><accept.annehmen><en> It is indeed a matter of tradition, when mothers not only accept the death of their sons in Jihad, but also declare that they want to have more sons, who would be ready to perpetrate the suicide attack, allegedly following God's will.
<G-vec00189-002-s497><accept.annehmen><de> Es hat Tradition, wenn Mütter den Tod ihrer Söhne im Jihad in Kauf nehmen und ankündigen, weitere Söhne haben zu wollen, die ebenfalls zum angeblich gottgewollten Selbstmordanschlag bereit sind.
<G-vec00189-002-s498><accept.annehmen><en> They do not need to accept a greater risk in order to protect the enemy.
<G-vec00189-002-s498><accept.annehmen><de> Sie müssen kein höheres Risiko in Kauf nehmen, um den Gegner zu schützen.
<G-vec00189-002-s499><accept.annehmen><en> This is where Bühler is upfront: If the application would require the Ex-safe cooler working at only 4 percent capacity after all, the user would possibly also accept the extremely low utilisation of capacity.
<G-vec00189-002-s499><accept.annehmen><de> Hier arbeitet Bühler mit offenen Karten: Wenn der Ex-geschützte Kühler mit nur 4 Prozent Kühlerauslastung dennoch für die Anwendung unbedingt benötigt wird, würde der Anwender wohl auch die äußerst geringe Auslastung in Kauf nehmen.
<G-vec00189-002-s500><accept.annehmen><en> However, it has been shown that few countries are willing to provide enormous resources and to accept the death of their citizens for this purpose.
<G-vec00189-002-s500><accept.annehmen><de> Allerdings hat sich gezeigt, dass kaum Staaten willens sind, die hierfür erforderlichen enormen Mittel bereitzustellen und den Tod ihrer Staatsbürger für dieses Ziel in Kauf zu nehmen.
<G-vec00189-002-s501><accept.annehmen><en> For example, customers can choose to accept quality cuts in return for a reduction in price if the translation is of an internal document not intended for the public market.
<G-vec00189-002-s501><accept.annehmen><de> Kunden können beispielsweise Qualitätsabzüge zugunsten eines besseren Preises in Kauf nehmen, wenn es sich bei der Übersetzung um ein internes Dokument handelt, welches nicht für den öffentlichen Markt bestimmt ist.
<G-vec00189-002-s502><accept.annehmen><en> This enables customers to communicate with you without having to accept the restrictions of fixed office hours and endless call center waiting loops.
<G-vec00189-002-s502><accept.annehmen><de> Hierüber können Kunden mit Ihnen kommunizieren, ohne die Einschränkungen von festen Bürozeiten und endlosen Call-Center-Warteschleifen in Kauf nehmen zu müssen.
<G-vec00189-002-s503><accept.annehmen><en> But she was willing to accept these conditions for the chance to escape the confines of the city for the first time in almost ten months.
<G-vec00189-002-s503><accept.annehmen><de> Aber sie war gewillt, das in Kauf zu nehmen für die Chance, zum ersten Mal seit zehn Monaten der beengten Stadt zu entfliehen.
<G-vec00189-002-s504><accept.annehmen><en> The only alternative is to accept the slow death of my nation and the slow disintegration of the Eurozone – which will destroy the European Union itself.
<G-vec00189-002-s504><accept.annehmen><de> Die einzige Alternative wäre, den langsamen Tod meiner Nation und den langsamen Zerfall der Eurozone, der letztlich auch die Zerstörung der Europäischen Union nach sich ziehen würde, in Kauf zu nehmen.
<G-vec00189-002-s505><accept.annehmen><en> The part-time MBA while in employment has enabled me to continue working and at the same time gain further qualifications without having to accept large financial losses and more importantly loss of time.
<G-vec00189-002-s505><accept.annehmen><de> Der berufsbegleitende Part-Time-MBA hat es mir ermöglicht, weiter im Beruf zu bleiben und mich nebenbei zu qualifizieren ohne große finanzielle und viel mehr zeitliche Verluste in Kauf nehmen zu müssen.
<G-vec00189-002-s506><accept.annehmen><en> As a result, he maintains control of his bids but will need to expend more effort to accept a bid.
<G-vec00189-002-s506><accept.annehmen><de> Dadurch behält er die Kontrolle über seine Gebote, muss dafür allerdings erhöhten manuellen Aufwand in Kauf nehmen.
<G-vec00189-002-s507><accept.annehmen><en> Once you have played against stronger opponents and you go back to playing at your normal limit, you'll be happy to put your chips into the pot as favourite even if you have to accept a few bad beats and suck outs. Cooler PROBLEM
<G-vec00189-002-s507><accept.annehmen><de> Wenn ihr einmal mit stärkeren Gegnern zu tun hattet und danach wieder auf euer vertrautes Stammlimit zurückgeht, werdet ihr euch freuen, eure Chips auch einmal wieder als Favorit in den Pot schieben zu können, selbst wenn ihr Bad Beats und Suckouts dafür in Kauf nehmen müsst.
<G-vec00189-002-s508><accept.annehmen><en> Through the combination of porous carbon with metal clusters, the researchers now plan to connect the advantages of the materials currently used without having to accept their drawbacks.
<G-vec00189-002-s508><accept.annehmen><de> Durch die Kombination von porösem Kohlenstoff mit Metallclustern wollen die Forscher nun die Vorzüge der derzeit eingesetzten Materialien verbinden, ohne deren Nachteile in Kauf nehmen zu müssen.
<G-vec00189-002-s509><accept.annehmen><en> In the short run there is little alternative to the current strategy of the Bank of Japan, unless policymakers are willing to accept a significant correction in the exchange rate and equity prices.
<G-vec00189-002-s509><accept.annehmen><de> Solange die Politik nicht bereit ist, eine erhebliche Korrektur der Wechselkurse und der Aktienkurse in Kauf zu nehmen, gibt es auf kurze Sicht wenig Alternativen zur aktuellen Strategie der Bank of Japan.
<G-vec00189-002-s510><accept.annehmen><en> Nevertheless, the user does not have to accept losses in resolution.
<G-vec00189-002-s510><accept.annehmen><de> Abstriche bei der Auflösung muss der User dennoch nicht in Kauf nehmen.
<G-vec00189-002-s511><accept.annehmen><en> Indeed, a recent McKinsey survey revealed not only that Europeans aspire to a more vibrant economy, higher incomes, and better public services (especially health care and education), but also that they are prepared to accept tradeoffs, including longer hours and reduced social protection, to achieve them.
<G-vec00189-002-s511><accept.annehmen><de> In der Tat geht aus einer aktuellen McKinsey-Umfrage nicht nur hervor, dass sich die Europäer eine lebendigere Wirtschaft, höhere Einkommen und bessere öffentliche Dienstleistungen (insbesondere in den Bereichen Gesundheit und Ausbildung) wünschen, sondern auch, dass sie bereit sind, dafür Abstriche zu machen und beispielsweise längere Arbeitszeiten oder geringere soziale Sicherheit in Kauf zu nehmen.
<G-vec00189-002-s512><accept.annehmen><en> 87% evaluated shared rides as being positive, even if they had to accept short detours.
<G-vec00189-002-s512><accept.annehmen><de> 87% empfanden geteilte Fahrten als positiv, auch wenn sie dafür kurze Umwege in Kauf nehmen mussten.
<G-vec00189-002-s399><accept.entgegennehmen><en> UPS does not accept ideas, concepts, or techniques for new services or products through the Website ("Comments").
<G-vec00189-002-s399><accept.entgegennehmen><de> UPS nimmt keine Ideen, Konzepte oder Techniken für neue Serviceleistungen oder Produkte ("Kommentare") über die Website entgegen.
<G-vec00189-002-s400><accept.entgegennehmen><en> I only know you bear sweet fruits for Me, and I accept them simply.
<G-vec00189-002-s400><accept.entgegennehmen><de> Ich weiß schier, du trägst für Mich Früchte, und Ich nehme sie schlicht entgegen.
<G-vec00189-002-s401><accept.entgegennehmen><en> Dear friend, please accept this emotional voucher.
<G-vec00189-002-s401><accept.entgegennehmen><de> Lieber Freund, bitte nehmen Sie diesen emotionalen Gutschein entgegen.
<G-vec00189-002-s402><accept.entgegennehmen><en> If a person’s selfish love is strongly accentuated, he will only accept the knowledge from the spiritual realm for himself.
<G-vec00189-002-s402><accept.entgegennehmen><de> Ist die Ichliebe eines Menschen stark betont, dann nimmt jener Mensch das Wissen aus dem geistigen Reich nur für sich entgegen.
<G-vec00189-002-s403><accept.entgegennehmen><en> You should always accept My instructions for only I can offer you truth, only I can provide you with the nourishment and drink which your soul requires in order to perfect itself.
<G-vec00189-002-s403><accept.entgegennehmen><de> Nehmet Meine Belehrungen allzeit entgegen, denn Ich allein kann euch die Wahrheit darbieten, Ich allein kann euch mit der Speise und dem Trank versorgen, den eure Seele benötigt, um sich zu vollenden.
<G-vec00189-002-s404><accept.entgegennehmen><en> When you accept the waiting call, you can either end the first call or place it on hold and resume the call later on.
<G-vec00189-002-s404><accept.entgegennehmen><de> Nehmen Sie den Zweitanruf entgegen, können Sie das erste Gespräch zuvor beenden, aber auch auf Warten legen und später weiterführen.
<G-vec00189-002-s405><accept.entgegennehmen><en> Once again, you will reap benefits from our excellent one-stop services: Innovative Financial Management AG will provide your with a dedicated phone and fax number, will accept inbound calls in the name of your company and will forward all messages to you via e-mail, SMS or fax.
<G-vec00189-002-s405><accept.entgegennehmen><de> Auch hier profitieren Sie von ausgezeichnetem Service aus einer Hand: Die Innovative Financial Management AG bietet Ihnen eine eigene Telefon- und Faxnummer, nimmt eingehende Anrufe im Namen Ihres Unternehmens entgegen und leitet Ihnen die Nachrichten per E-Mail, SMS oder Fax weiter.
<G-vec00189-002-s406><accept.entgegennehmen><en> In addition, it will accept complaints directly from individuals and will undertake Privacy Shield investigations on its own initiative, in particular as part of its wider investigations of privacy issues.
<G-vec00189-002-s406><accept.entgegennehmen><de> Überdies nimmt sie Beschwerden direkt von Privatpersonen entgegen und leitet von sich aus Ermittlungen ein, die den Datenschutzschild betreffen, insbesondere im Rahmen breiter angelegter Untersuchungen zu Fragen des Datenschutzes.
<G-vec00189-002-s407><accept.entgegennehmen><en> Seelbach´s Mayor Thomas Schäfer, as well as Markus and Jennifer Juchheim joined Mr. Juchheim in Stuttgart to accept his much deserved award.
<G-vec00189-002-s407><accept.entgegennehmen><de> Im Beisein des Seelbacher Bürgermeisters Thomas Schäfer und Markus Juchheim mit Ehefrau Jennifer, nahm Gerhard Juchheim die wohlverdiente Auszeichnung entgegen.
<G-vec00189-002-s408><accept.entgegennehmen><en> The Halle (Saale) Administrative Authority does not accept encrypted emails.
<G-vec00189-002-s408><accept.entgegennehmen><de> Die Stadt Halle (Saale) nimmt keine verschlüsselten E-Mails entgegen.
<G-vec00189-002-s409><accept.entgegennehmen><en> At the Red Dot Gala in the Konzerthaus Berlin, the Red Dot: Best of the Best winners accept their well-deserved trophies and can hope to win additional awards. This is because, in the field of “Communication Design”, the best piece of work in each category, which receives the Red Dot: Grand Prix, is not announced until during the award ceremony.
<G-vec00189-002-s409><accept.entgegennehmen><de> Während der Red Dot Gala im Konzerthaus Berlin nehmen die Sieger ihre verdienten Trophäen entgegen und dürfen auf zusätzliche Awards hoffen: Erst während der Preisverleihung wird bekannt gegeben, welche Arbeit im Bereich „Communication Design“ als beste in ihrer Kategorie mit dem Red Dot: Grand Prix honoriert wird.
<G-vec00189-002-s410><accept.entgegennehmen><en> SVA accept no confidential information via this site; any information and other data sent to SVA are considered to be of a non-confidential nature.
<G-vec00189-002-s410><accept.entgegennehmen><de> Die SVA GmbH nimmt über diese Website keine vertraulichen Informationen entgegen; alle Informationen und jedwedes der SVA übersandtes Material werden als nicht vertraulich betrachtet.
<G-vec00189-002-s411><accept.entgegennehmen><en> No, for legal reasons contracts we cannot accept agreements sent by email.
<G-vec00189-002-s411><accept.entgegennehmen><de> Aus rechtlichen Gründen nehmen wir keine Verträge via E-Mail entgegen.
<G-vec00189-002-s412><accept.entgegennehmen><en> Jobs in does not accept recruitment agency applications for this position....
<G-vec00189-002-s412><accept.entgegennehmen><de> Siemens nimmt für diese Position keine Bewerbungen von Personalvermittlern entgegen...
<G-vec00189-002-s413><accept.entgegennehmen><en> Alex Taxi does not accept credit cards, sorry.
<G-vec00189-002-s413><accept.entgegennehmen><de> Sorry, Alex Taxi nimmt keine Kreditkartenzahlungen entgegen.
<G-vec00189-002-s414><accept.entgegennehmen><en> We exclusively take accept orders at these terms and conditions.
<G-vec00189-002-s414><accept.entgegennehmen><de> Wir nehmen Bestellungen ausschließlich zu diesen Bedingungen entgegen.
<G-vec00189-002-s415><accept.entgegennehmen><en> Online safety of children The Seller does not accept orders in the online shop from someone they know or suspect to be a child without the explicit consent of their parents or guardians.
<G-vec00189-002-s415><accept.entgegennehmen><de> Der Verkäufer nimmt ohne ausdrückliche Genehmigung der Eltern oder Pflegeberechtigten keine Bestellungen entgegen, wenn ihm bekannt ist oder er den Verdacht hat, dass es sich beim Besteller um ein Kind handelt.
<G-vec00189-002-s416><accept.entgegennehmen><en> We do not accept calls with suppressed number.
<G-vec00189-002-s416><accept.entgegennehmen><de> Anrufe mit Unterdrückter Nummer nehmen wir nicht entgegen.
<G-vec00189-002-s417><accept.entgegennehmen><en> Our reservation department will be pleased to accept your enquiry even before your stay.
<G-vec00189-002-s417><accept.entgegennehmen><de> Gerne nimmt unsere Reservierung auch schon vor Ihrem Aufenthalt eine Anfrage entgegen.
<G-vec00189-002-s418><accept.entgegennehmen><en> 81 O 91/11) all websites acting as agents (be it regarding services pertaining to food ordering, apartments or other real estate or any other goods or services), which accept moneys from clients with the purpose of forwarding it, should be affected by regulation of money remittance business – at least from the judiciary’s point of view.
<G-vec00189-002-s418><accept.entgegennehmen><de> 81 O 91/11) dürften – jedenfalls aus Sicht der Rechtsprechung – sämtliche Vermittlungsportale im Internet (sei es nun von Essensbestellungen, Wohnungen oder sonstigen Gütern), die Geldbeträge von Kunden zur Weiterleitung entgegennehmen, von der Regelung des Finanztransfergeschäfts betroffen sein.
<G-vec00189-002-s419><accept.entgegennehmen><en> Forster announced that the BGL ’ s highest award will shortly be handed over to the winner in Berlin, as he was unfortunately unable to accept the “ Silver Landscape ” at the start of the exhibition in Nürnberg.
<G-vec00189-002-s419><accept.entgegennehmen><de> Forster gab bekannt, die höchste Auszeichnung des BGL werde in Kürze in Berlin an den Preisträger überreicht, der die „ Silberne Landschaft “ leider nicht anlässlich des Messe-Auftaktes in Nürnberg entgegennehmen konnte.
<G-vec00189-002-s420><accept.entgegennehmen><en> Check Guarantee is a guarantee that you will be paid on the paper checks you accept from your customers.
<G-vec00189-002-s420><accept.entgegennehmen><de> Scheckgarantie ist die Garantie, dass Sie für die Schecks, die Sie von Ihren Kunden entgegennehmen, bezahlt werden.
<G-vec00189-002-s421><accept.entgegennehmen><en> Items bought online can be returned at any River Island store in the UK, Republic of Ireland, The Netherlands, Belgium and Sweden (unfortunately We cannot accept returns in any of Our other international stores), within 1 month of receipt.
<G-vec00189-002-s421><accept.entgegennehmen><de> Online erworbene Produkte können innerhalb von 1 Monat(en) nach Erhalt in allen Filialen von River Island in Großbritannien, der Republik Irland, den Niederlanden, Belgien und Schweden zurückgegeben werden (leider können wir in anderen internationalen Filialen keine Rückgaben entgegennehmen).
<G-vec00189-002-s422><accept.entgegennehmen><en> And He has given you the ability to perceive His creation, to stimulate your intellect.... and thus it is He Himself Who is mentally instructing you, providing you are willing to accept His instructions when you look at the creation around you, when you ponder its meaning and purpose, its origin and the One Who brought it into existence.
<G-vec00189-002-s422><accept.entgegennehmen><de> Und Er hat euch die Fähigkeit gegeben, Seine Werke zu sehen, euren Verstand tätig werden zu lassen.... und also ist Er Selbst es, Der euch gedanklich unterweiset, so ihr Seine Belehrungen entgegennehmen wollt, so ihr die Schöpfung um euch betrachtet, über Sinn und Zweck derselben nachdenkt, über ihr Entstehen und über Den, Der sie entstehen ließ.
<G-vec00189-002-s423><accept.entgegennehmen><en> Built-in capabilities allow you to simplify daily tasks, speed up transactions, engage customers, and accept the latest payments effortlessly.
<G-vec00189-002-s423><accept.entgegennehmen><de> Dank der integrierten Funktionen kannst du tägliche Aufgaben vereinfachen, Transaktionen beschleunigen, Kunden einbeziehen und die neuesten Zahlungen problemlos entgegennehmen.
<G-vec00189-002-s424><accept.entgegennehmen><en> Instead of turning bright red in shame, you either brush it off like you meant it to happen and accept your award from the floor, or you put up your arms in a "tada" moment and embrace the spotlight.
<G-vec00189-002-s424><accept.entgegennehmen><de> Anstatt vor Scham feuerrot zu werden, kannst du es entweder abtun, als wäre es geplant gewesen und den Preis vom Boden aus entgegennehmen, oder du reißt deine Arme auf „tada“-Weise hoch und genießt das Rampenlicht.
<G-vec00189-002-s425><accept.entgegennehmen><en> Please understand that we do not accept legally binding orders this way.
<G-vec00189-002-s425><accept.entgegennehmen><de> Bitte haben Sie Verständnis dafür, dass wir auf diesem Weg keine rechtsverbindlichen Aufträge entgegennehmen.
<G-vec00189-002-s426><accept.entgegennehmen><en> Due to the special status of the Goethe-Institut Thailand, the institute has no account with a Thai commercial bank and can therefore only accept payment in cash.
<G-vec00189-002-s426><accept.entgegennehmen><de> Aufgrund seines besonderen Status verfügt das Goethe-Institut Thailand über kein Bankkonto bei einer thailändischen Geschäftsbank und kann nur Barzahlungen entgegennehmen.
<G-vec00189-002-s427><accept.entgegennehmen><en> The SBA expects its members not to accept any assets where they know that these assets are and will remain untaxed.
<G-vec00189-002-s427><accept.entgegennehmen><de> Die SBVg erwartet von ihren Mitgliedern, dass sie keine Vermögenswerte entgegennehmen, von denen sie wissen, dass sie nicht versteuert sind und nicht versteuert werden.
<G-vec00189-002-s428><accept.entgegennehmen><en> We can only accept registrations for the first day.
<G-vec00189-002-s428><accept.entgegennehmen><de> Wir können daher nur noch Anmeldungen für den ersten Veranstaltungstag entgegennehmen.
<G-vec00189-002-s429><accept.entgegennehmen><en> Please note that, due to the size of the establishment, we are unable to accept table reservations.
<G-vec00189-002-s429><accept.entgegennehmen><de> Bitte beachten Sie, dass wir aufgrund der begrenzten Plätze im Lokal, keine Reservierungen entgegennehmen können.
<G-vec00189-002-s430><accept.entgegennehmen><en> You will then be shown an overview of EEW Energy from Waste’s plants which will accept the relevant waste.
<G-vec00189-002-s430><accept.entgegennehmen><de> Sie bekommen anschließend eine Übersicht der Abfallverbrennungsanlagen von EEW Energy from Waste, die den entsprechenden Abfall entgegennehmen.
<G-vec00189-002-s431><accept.entgegennehmen><en> Please note: we unfortunately cannot accept any orders for Radius products from Switzerland for distribution reasons.
<G-vec00189-002-s431><accept.entgegennehmen><de> Hinweis: Aus vertriebstechnischen Gründen können wir leider keine Bestellungen aus der Schweiz für Radius Produkten entgegennehmen.
<G-vec00189-002-s432><accept.entgegennehmen><en> Unfortunately, that's not possible. We need a written and binding application and can't accept reservations.
<G-vec00189-002-s432><accept.entgegennehmen><de> Leider nicht, wir benötigen eine schriftliche, verbindliche Anmeldung und können keine Vorreservierungen entgegennehmen.
<G-vec00189-002-s433><accept.entgegennehmen><en> Let them "wholly for the sake of God proclaim His Message, and with that same spirit accept whatever response their words may evoke in their hearers."
<G-vec00189-002-s433><accept.entgegennehmen><de> Laßt sie »ganz um der Sache Gottes willen Seine Botschaft verkünden und im gleichen Geist jeden Widerhall entgegennehmen, den ihre Worte bei ihren Hörern hervorrufen mögen«.
<G-vec00189-002-s435><accept.entgegennehmen><en> You can also call us. Although we are unable to accept your cancellation over the telephone, we are happy to help you find a solution to your problems.
<G-vec00189-002-s435><accept.entgegennehmen><de> Gerne können Sie uns aber auch anrufen, zwar können wir telefonisch Ihre Kündigung nicht entgegennehmen, helfen Ihnen aber gerne bei der Lösung von Problemen.
<G-vec00189-002-s436><accept.entgegennehmen><en> For payment, we use various payment service providers, which are always identified and accept your input directly and are therefore recipients of your personal data collected in connection with the payment process.
<G-vec00189-002-s436><accept.entgegennehmen><de> Zur Zahlungsabwicklung nutzen wir verschiedene Zahlungsdienstleister, welche stets kenntlich gemacht sind und direkt Ihre Eingaben entgegennehmen und somit Empfänger Ihrer im Zusammenhang mit dem Bezahlvorgang erhobenen personenbezogenen Daten sind.
<G-vec00189-002-s608><accept.entgegennehmen><en> In the Bricks & Pieces selection, we are not able to accept orders for parts that are temporarily not available.
<G-vec00189-002-s608><accept.entgegennehmen><de> Bei „Steine & Teile“ nehmen wir keine Bestellungen für Artikel entgegen, die zurzeit nicht verfügbar sind.
<G-vec00189-002-s609><accept.entgegennehmen><en> First, you accept the incoming raw ingredients, semi-finished and finished products and check them.
<G-vec00189-002-s609><accept.entgegennehmen><de> Zunächst nehmen sie Rohstoffe, Halbfertig- und Fertigprodukte entgegen und prüfen sie.
<G-vec00189-002-s610><accept.entgegennehmen><en> We accept applications from 6 months before the month of admission.
<G-vec00189-002-s610><accept.entgegennehmen><de> Wir nehmen Bewerbungen frühestens ab 6 Monate for dem Beginn des Semesters entgegen.
<G-vec00189-002-s611><accept.entgegennehmen><en> We will also accept prescription orders.
<G-vec00189-002-s611><accept.entgegennehmen><de> Wir nehmen auch Ihre Rezeptbestellung entgegen.
<G-vec00189-002-s612><accept.entgegennehmen><en> We are happy to accept reservations for groups.
<G-vec00189-002-s612><accept.entgegennehmen><de> Reservationen für Gruppen und Einzelreisende nehmen wir gerne entgegen.
<G-vec00189-002-s613><accept.entgegennehmen><en> Contact We will gladly accept your request by phone, fax or e-mail.
<G-vec00189-002-s613><accept.entgegennehmen><de> Kontakt Gern nehmen wir Ihre Anfrage per Telefon, Fax oder E-Mail entgegen.
<G-vec00189-002-s614><accept.entgegennehmen><en> We are happy to accept your order per telephone.
<G-vec00189-002-s614><accept.entgegennehmen><de> Gerne nehmen wir Ihre Bestellung auch telefonisch entgegen.
<G-vec00189-002-s615><accept.entgegennehmen><en> We are glad to accept already your orders for the seasons 2015 and 2016.
<G-vec00189-002-s615><accept.entgegennehmen><de> Gerne nehmen wir bereits jetzt Ihre Aufträge für die Jahre 2018 und 2019 entgegen.
<G-vec00189-002-s616><accept.entgegennehmen><en> ALBA experts accept empty paper sacks at several hundred collection points throughout Germany, and recycle them in an in-house cleaning plant.
<G-vec00189-002-s616><accept.entgegennehmen><de> Die Fachkräfte nehmen restentleerte Säcke an mehreren hundert Annahme- und Sammelstellen deutschlandweit entgegen und verwerten sie in einer eigenen Reinigungsanlage.
<G-vec00189-002-s617><accept.entgegennehmen><en> They accept proposals and are also responsible for searching for projects that appear suitable.
<G-vec00189-002-s617><accept.entgegennehmen><de> Sie nehmen die Vorschläge entgegen und suchen auch selbständig nach geeignet erscheinenden Projekten.
<G-vec00189-002-s618><accept.entgegennehmen><en> We only accept reservations for the same day from 5 pm by telephone, because it’s possible that the emails are not processed in time.
<G-vec00189-002-s618><accept.entgegennehmen><de> Reservierungen für den gleichen Tag nehmen wir ab 17 Uhr nur telefonisch entgegen, da nicht immer gewährleistet werden kann, dass die E-Mails rechtzeitig bearbeitet werden.
<G-vec00189-002-s619><accept.entgegennehmen><en> Most large chains and brands today accept old textiles for recycling.
<G-vec00189-002-s619><accept.entgegennehmen><de> Die meisten großen Ketten und Marken nehmen heutzutage alte Kleidungsstücke zum Recyceln entgegen.
<G-vec00189-002-s620><accept.entgegennehmen><en> Please accept my deepest sympathy on behalf of the INTERKULTUR leadership and all its staff members.
<G-vec00189-002-s620><accept.entgegennehmen><de> Bitte nehmen Sie von mir und dem ganzen Team von INTERKULTUR unser tiefstes Mitgefühl entgegen.
<G-vec00189-002-s621><accept.entgegennehmen><en> On request we also accept 1 night for a small surcharge.
<G-vec00189-002-s621><accept.entgegennehmen><de> Auf Anfrage nehmen wir auch gegen einen kleinen Aufpreis 1 Übernachtung entgegen.
<G-vec00189-002-s622><accept.entgegennehmen><en> We also accept traveler's checks.
<G-vec00189-002-s622><accept.entgegennehmen><de> Wir nehmen zudem Reiseschecks entgegen.
<G-vec00189-002-s623><accept.entgegennehmen><en> Table reservations for the same day, we are pleased to accept phone.
<G-vec00189-002-s623><accept.entgegennehmen><de> Tischreservationen für den selben Tag nehmen wir gerne telefonisch entgegen.
<G-vec00189-002-s624><accept.entgegennehmen><en> We only accept repairs directly from the point of sale.
<G-vec00189-002-s624><accept.entgegennehmen><de> Wir nehmen Reparaturen nur direkt von der Verkaufsstelle entgegen.
<G-vec00189-002-s625><accept.entgegennehmen><en> We can accept pallets at our production locations or pick them up at your location by prior arrangement.
<G-vec00189-002-s625><accept.entgegennehmen><de> Die Paletten nehmen wir an unseren Produktionsstandorten entgegen oder holen sie nach Vereinbarung an Ihrem Standort ab.
<G-vec00189-002-s626><accept.entgegennehmen><en> We will gladly accept your initiative application by e-mail.
<G-vec00189-002-s626><accept.entgegennehmen><de> Gerne nehmen wir deine Initiativbewerbung per E-Mail entgegen.
