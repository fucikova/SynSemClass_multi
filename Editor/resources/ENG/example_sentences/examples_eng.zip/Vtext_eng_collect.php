<G-vec00169-001-s019><collect.abholen><en> I wanted to collect our tickets for the New Years Eve party.
<G-vec00169-001-s019><collect.abholen><de> Ich wollte unsere Karten für die Sylvesterfeier abholen.
<G-vec00169-001-s020><collect.abholen><en> If you are unhappy with your vehicle, speak to the local supplier when you collect your car.
<G-vec00169-001-s020><collect.abholen><de> Wenn Sie mit Ihrem fahrzeug unzufrieren sind, sprechen Sie mit dem Anbieter vor Ort, wenn sie das Auto abholen.
<G-vec00169-001-s021><collect.abholen><en> It is also possible to authorize someone to collect the decision letter and to do the exam registration (authorization letter, copy of ID card or copy of Blue Card required).
<G-vec00169-001-s021><collect.abholen><de> Das Abholen oder Anmelden ist auch durch eine/n Bevollmächtigte/n möglich (Vollmacht, Kopie des Ausweises oder eine Kopie der Blue Card sind notwendig).
<G-vec00169-001-s022><collect.abholen><en> The Tafel maintains four vehicles, each with teams of drivers that collect food from cooperating companies five days a week.
<G-vec00169-001-s022><collect.abholen><de> Die Tafel unterhält vier Fahrzeuge, mit denen Fahrerteams Lebensmittel an fünf Tagen die Woche bei kooperationsbereiten Firmen abholen.
<G-vec00169-001-s023><collect.abholen><en> The other way around, all employees, wanting to send a packet, have to inform the porter, which has to collect the packet at the workstation place and which will hand over the packet to the ordered courier at the gate.
<G-vec00169-001-s023><collect.abholen><de> Umgekehrt müssen alle Mitarbeiter, die ein Paket verschicken wollen, den Pförtner anrufen, der das Paket am Arbeitsplatz abholen lässt und am Tor an einen bestellten Kurier übergibt.
<G-vec00169-001-s024><collect.abholen><en> Out of hours As not all car rental companies are open 24 hours at St Maarten, you will still be able to collect your car before or after opening hours.
<G-vec00169-001-s024><collect.abholen><de> Außerhalb der Öffnungszeiten Da nicht alle Autovermietungen 24 Stunden in St. Maarten geöffnet sind, können Sie Ihr Auto noch vor oder nach der Öffnungszeiten abholen.
<G-vec00169-001-s025><collect.abholen><en> We find the media for you, and you can usually collect them a few hours later.
<G-vec00169-001-s025><collect.abholen><de> Wir suchen die Medien für Sie heraus und Sie können sie in der Regel wenige Stunden danach abholen.
<G-vec00169-001-s026><collect.abholen><en> In that case, clearly indicate when applying for your card that you want to collect it in person from your KBC branch.
<G-vec00169-001-s026><collect.abholen><de> Vermerken Sie beim Beantragen Ihrer Karte klar und deutlich, dass Sie die Karte in Ihrer KBC Bank abholen wollen.
<G-vec00169-001-s027><collect.abholen><en> When traveling to Czech Republic you can have one of our drivers collect you and start your holidays in Czech Republic straight away.
<G-vec00169-001-s027><collect.abholen><de> Wenn Sie nach Tschechische Republik reisen, kann Sie unser Fahrer abholen und Sie können Ihren Urlaub in Tschechische Republik sofort beginnen.
<G-vec00169-001-s028><collect.abholen><en> When the harvest time approached, he sent his servants to the tenants to collect his fruit.
<G-vec00169-001-s028><collect.abholen><de> Zur Zeit der Weinlese schickte er seine Boten zu den Pächtern, um den Ertrag abholen zu lassen.
<G-vec00169-001-s029><collect.abholen><en> You can collect your keys from 34 Murray Street, after 15:00.
<G-vec00169-001-s029><collect.abholen><de> Die Schlüssel können Sie ab 15:00 Uhr in der Murray Street 34 abholen.
<G-vec00169-001-s030><collect.abholen><en> As not all car rental companies are open 24 hours at Fort Lauderdale, you will still be able to collect your car before or after opening hours.
<G-vec00169-001-s030><collect.abholen><de> Da nicht alle Autovermieter 24 Stunden in Fort Lauderdale geöffnet sind, können Sie Ihr Auto noch vor oder nach der Öffnungszeiten abholen.
<G-vec00169-001-s031><collect.abholen><en> If you have asked to collect the products from our stores, you can collect them from us at any time during the opening hours of the particular store.
<G-vec00169-001-s031><collect.abholen><de> Wenn Sie gebeten haben, die Produkte aus unseren Geschäften abzuholen, dürfen Sie sie jederzeit bei uns abholen, während der Öffnungszeiten der jeweiligen Shops.
<G-vec00169-001-s032><collect.abholen><en> You may collect the ordered goods either in person in our plant or we will deliver them directly to the house.
<G-vec00169-001-s032><collect.abholen><de> Die bestellte Ware können Sie persönlich in unserem Werk abholen oder wir senden Ihnen diese bis ins Haus.
<G-vec00169-001-s033><collect.abholen><en> When purchasing from Denmark or Sweden, you’re able to choose “Collect in Store” as a shipping method.
<G-vec00169-001-s033><collect.abholen><de> "Wenn du aus Dänemark, Schweden oder Norwegen bestellst, kannst du „Im Store abholen"" als Versandmethode wählen."
<G-vec00169-001-s034><collect.abholen><en> Upon arrival customers can proceed to the Firearm Desk to collect firearms.
<G-vec00169-001-s034><collect.abholen><de> Bei der Ankunft können Kunden ihre Schusswaffen am Schusswaffenschalter abholen.
<G-vec00169-001-s035><collect.abholen><en> You may choose to have your passport and visa returned to your home/business address in Austria via courier service (Premium Home Delivery) or collect them from the DPD City Hub (Pickup).
<G-vec00169-001-s035><collect.abholen><de> Sie können Ihren Pass mit dem Visum per Kurierdienst an Ihre Privat- oder Geschäftsadresse in Österreich zustellen lassen (Premium Hauslieferung) oder sie bei DPD Wien City Hub (Selbst-Abholung) abholen.
<G-vec00169-001-s036><collect.abholen><en> For international flights, guests will have to collect their baggage and clear Customs at the first port of entry.
<G-vec00169-001-s036><collect.abholen><de> Bei internationalen Flügen müssen die Gäste ihr Gepäck abholen und am ersten Einreiseort den Zoll passieren.
<G-vec00169-001-s037><collect.abholen><en> Off course, it is possible to collect your order from our warehouse.
<G-vec00169-001-s037><collect.abholen><de> Selbstverständlich ist es ebenfalls möglich, die Waren direkt bei uns abholen.
<G-vec00169-001-s057><collect.abholen><en> They have two UK depots, and you can opt to collect your order from them if you are local, they are in Bolton and Aylesbury.
<G-vec00169-001-s057><collect.abholen><de> Sie haben zwei britische Depots, und Sie können entscheiden, Ihre Bestellung von ihnen abzuholen, wenn Sie lokal sind, sie sind in Bolton und Aylesbury.
<G-vec00169-001-s059><collect.abholen><en> It is high time that she was able to come and collect it.
<G-vec00169-001-s059><collect.abholen><de> Es ist höchste Zeit, dass sie kommen kann, um ihn abzuholen.
<G-vec00169-001-s060><collect.abholen><en> The Customer has 15 days from the in-store delivery date to collect their parcel.
<G-vec00169-001-s060><collect.abholen><de> Der Kunde verfügt über eine Frist von 15 Tagen ab dem Datum der Lieferung in der Boutique, um seine Bestellung abzuholen.
<G-vec00169-001-s061><collect.abholen><en> Since apparently he had left his parents in the dark about his financial situation and its effects, Theodor and Else Daltrop were all the more dismayed to find out one day that their son had been picked up, completely disoriented while begging on the street, and to find themselves requested to collect him immediately.
<G-vec00169-001-s061><collect.abholen><de> Da er seine Eltern über seine finanzielle Situation und ihre Folgen anscheinend im Unklaren gelassen hatte, waren Theodor und Else Daltrop umso bestürzter, als sie eines Tages erfuhren, dass ihr Sohn völlig orientierungslos beim Betteln auf der Straße aufgegriffen worden war, und sie aufgefordert wurden, ihn umgehend abzuholen.
<G-vec00169-001-s062><collect.abholen><en> Practitioners are not allowed to leave the cell to fetch any necessities, collect their laundry, nor are they allowed to go to the store room to get their clothing.
<G-vec00169-001-s062><collect.abholen><de> Die Praktizierenden dürfen ihre Zelle nicht verlassen, um sich notwendige Dinge zu holen, ihre Wäsche abzuholen oder in den Lagerraum zu gehen, um Kleidung zu bekommen.
<G-vec00169-001-s063><collect.abholen><en> Our chauffeur will collect you with a personalised sign.
<G-vec00169-001-s063><collect.abholen><de> Unser Chauffeur wird den Flug verfolgen um euch rechtzeitig abzuholen.
<G-vec00169-001-s064><collect.abholen><en> Every morning, you can also collect your bread and croissants at reception (upon order) on all our sites.
<G-vec00169-001-s064><collect.abholen><de> Sie haben auf all unseren Campingplätzen die Möglichkeit jeden Morgen gegen Vorbestellung frisches Brot und Croissants an der Rezeption abzuholen.
<G-vec00169-001-s065><collect.abholen><en> At Berlin, proceed to baggage reclaim to collect your bags as normal.
<G-vec00169-001-s065><collect.abholen><de> In Berlin gehst du zur Gepäckausgabe, um dein Gepäck wie gewohnt abzuholen.
<G-vec00169-001-s066><collect.abholen><en> (5) In case of abnormal weather such as hail and squally winds, protective measures should be taken immediately to collect the equipment into the warehouse.
<G-vec00169-001-s066><collect.abholen><de> (5) Bei ungewöhnlichem Wetter wie Hagel und starkem Wind sollten sofort Schutzmaßnahmen ergriffen werden, um die Geräte im Lager abzuholen.
<G-vec00169-001-s067><collect.abholen><en> Avis/Budget also offer a facility for customers to collect their rental cars from Terminal 2.
<G-vec00169-001-s067><collect.abholen><de> Avis/Budget bietet auch die Möglichkeit für Kunden an, die Mietwagen von Terminal 2 abzuholen.
<G-vec00169-001-s068><collect.abholen><en> Please collect it within 7 days.
<G-vec00169-001-s068><collect.abholen><de> Sie haben 7 Tage Zeit, sie dort abzuholen.
<G-vec00169-001-s069><collect.abholen><en> You will then have 10 working days, from when your order arrives at the post office, to collect it.
<G-vec00169-001-s069><collect.abholen><de> In diesem Fall verfügen Sie über 10 Werktage ab Eingang Ihres Pakets im Postamt, um es abzuholen.
<G-vec00169-001-s070><collect.abholen><en> Of course, this right of retention does not apply if he himself has offered to collect the goods from the consumer.
<G-vec00169-001-s070><collect.abholen><de> Dieses Zurückbehaltungsrecht besteht selbstverständlich dann nicht, wenn er selbst angeboten hat, die Ware beim Verbraucher abzuholen.
<G-vec00169-001-s071><collect.abholen><en> Where, according to the provisions of the packaging legislation, the supplier is required to take back the packaging, it must collect this from the customer at its own cost.
<G-vec00169-001-s071><collect.abholen><de> Soweit der Lieferant nach den Bestimmungen der Verpackungsordnung verpflichtet ist, Verpackungen zurückzunehmen, hat er sie auf seine Kosten bei dem Besteller abzuholen.
<G-vec00169-001-s072><collect.abholen><en> To collect his baggage, the Passenger should show the corresponding Baggage Check delivered to him at check-in.
<G-vec00169-001-s072><collect.abholen><de> Um das Gepäck abzuholen, muss der Fluggast den entsprechenden Gepäckschein, den er beim Check-in erhalten hat, vorweisen.
<G-vec00169-001-s073><collect.abholen><en> We also remind you that, from the landing time, you will have an hour to collect your luggage and reach the desk mentioned on the Terravision Voucher.
<G-vec00169-001-s073><collect.abholen><de> Wir möchten Sie außerdem daran erinnern, dass Sie ab der Landung eine Stunde Zeit haben, um Ihr Gepäcke abzuholen und den Schalter zu erreichen, der auf dem Terravision-Gutschein angegeben ist.
<G-vec00169-001-s074><collect.abholen><en> Customers are asked to authorize shipment or to collect the supply directly at our warehouse within 30 days from the communication of availability.
<G-vec00169-001-s074><collect.abholen><de> Der Kunde ist verpflichtet, die Lieferung innerhalb 30 Tagen nach Erhalt der Mitteilung über die Verfügbarkeit am Lager der Produkte zu genehmigen oder abzuholen.
<G-vec00169-001-s075><collect.abholen><en> An INWB connector for the compliance address verification can analyze this attribute in order to collect messages from or store messages in this directory.
<G-vec00169-001-s075><collect.abholen><de> Ein INWB-Connector für die Compliance-Adressprüfung kann dieses Attribut auswerten, um Nachrichten in diesem Verzeichnis abzuholen oder abzulegen.
<G-vec00169-001-s114><collect.einsammeln><en> The main difference is that we bypass the middlemen; they do not earn any money with us, so all of the money we collect makes its way back to the producer.
<G-vec00169-001-s114><collect.einsammeln><de> Der Hauptunterschied ist, dass wir die Mittelsmänner umgehen, sie verdienen kein Geld an uns, sodass alles Geld, das wir einsammeln, seinen Weg zurück zum Hersteller nimmt.
<G-vec00169-001-s115><collect.einsammeln><en> Crawl in and collect the golden rose .
<G-vec00169-001-s115><collect.einsammeln><de> Hinein kriechen und die goldene Rose einsammeln.
<G-vec00169-001-s116><collect.einsammeln><en> We go forwards with you by using this review to COLLECT everything which you left behind, forgot or flung away.
<G-vec00169-001-s116><collect.einsammeln><de> Wir gehen mit euch vorwärts, indem wir in dieser Rückschau ALLES einsammeln, was ihr liegengelassen, vergessen und von euch geschleudert habt.
<G-vec00169-001-s117><collect.einsammeln><en> In addition the robot has to collect parts of a rocket, transport them to a launch pad and sort and align them in the color sequence of the Russian flag.
<G-vec00169-001-s117><collect.einsammeln><de> Darüber hinaus muss der Roboter Teile einer Rakete einsammeln und zu einer Abschussrampe transportieren und in der farbigen Reihenfolge der Russischen Flagge sortieren und aufstellen.
<G-vec00169-001-s118><collect.einsammeln><en> This operation is taking longer for two reasons. First, we needed to collect, surreptitiously, the enormous amounts of money stolen by the dark.
<G-vec00169-001-s118><collect.einsammeln><de> Diese Operation nimmt aus zweierlei Gründen längere Zeit in Anspruch: Erstens mussten wir heimlich die enormen Mengen an Geld einsammeln, die von den Dunkelkräften gestohlen worden waren.
<G-vec00169-001-s119><collect.einsammeln><en> Crawl out and collect the grenades in the alcove opposite.
<G-vec00169-001-s119><collect.einsammeln><de> Draußen in der Nische gegenüber die Granaten einsammeln.
<G-vec00169-001-s120><collect.einsammeln><en> Sloths, hippos, L & ouml; wen, pandas... All are just as lazy and waiting to can collect from the players .
<G-vec00169-001-s120><collect.einsammeln><de> Faultiere, Nilpferde, Löwen, Pandas... Alle liegen nur faul da und warten darauf, sich von den Spielern einsammeln zu lassen.
<G-vec00169-001-s121><collect.einsammeln><en> (If you drop into the water you can collect the goodies later on, you have to return here anyway.
<G-vec00169-001-s121><collect.einsammeln><de> [Hinweis] Wenn man ins Wasser fällt, kann man die Gegenstände später noch mal einsammeln, man muss sowieso noch mal hier hin.
<G-vec00169-001-s122><collect.einsammeln><en> Collect the Venus Symbol .
<G-vec00169-001-s122><collect.einsammeln><de> Das Venus Symbol einsammeln.
<G-vec00169-001-s123><collect.einsammeln><en> Optionally the Binopterus can be equipped with two wind wings „windcollector“, which “collect” the wind and allow the start of the wind turbine even in very low wind speed regions.
<G-vec00169-001-s123><collect.einsammeln><de> Wahlweise kann der Binopterus mit zwei Windflügeln (Windkollektoren) ausgestattet werden, die den Wind „einsammeln“ und ermöglichen somit einen Betrieb selbst in windschwachen Gebieten.
<G-vec00169-001-s124><collect.einsammeln><en> Collect the Iris Lab Access he loses.
<G-vec00169-001-s124><collect.einsammeln><de> Den Iris Labor Zugang den er verliert einsammeln.
<G-vec00169-001-s125><collect.einsammeln><en> Help small orange to dupe the gravity and to collect all the lemons.
<G-vec00169-001-s125><collect.einsammeln><de> Helfen Sie kleiner Orange die Schwerkraft übertölpeln und alle Zitronen einsammeln.
<G-vec00169-001-s126><collect.einsammeln><en> Meanwhile, as the Earth changes progress, scaring the wealthy class, he will collect their funds.
<G-vec00169-001-s126><collect.einsammeln><de> In der Zwischenzeit, während die Erdveränderungen weiter voran schreiten und die reiche Klasse verängstigen, wird er Ihr Geld einsammeln.
<G-vec00169-001-s127><collect.einsammeln><en> The Climate Talk highlighted questions on the role of existing institutions regarding the allocation of sources and whether new institutions should be created to collect and distribute the funds.
<G-vec00169-001-s127><collect.einsammeln><de> Der Climate Talk beleuchtete Fragen, welche Rolle bestehende Institutionen bei der Mittelverwendung haben können, oder ob neue Institutionen geschaffen werden sollen, die die Mittel einsammeln und verteilen.
<G-vec00169-001-s128><collect.einsammeln><en> Collect the golden rose and climb back out.
<G-vec00169-001-s128><collect.einsammeln><de> Die goldene Rose einsammeln und wieder nach draußen klettern.
<G-vec00169-001-s129><collect.einsammeln><en> You should collect fallen leaves.
<G-vec00169-001-s129><collect.einsammeln><de> Abgefallene Blätter sollte man immer einsammeln.
<G-vec00169-001-s130><collect.einsammeln><en> "As already added in example 3, one should rather collect the output of the individual ""partial incremental backups"" and evaluate them at the end of the script, e.g. search for errors or summarize the ""summaries"" ."
<G-vec00169-001-s130><collect.einsammeln><de> "Wie im Beispiel 3 schon ergänzt, sollte man also eher die Ausgabe der einzelnen ""partial incremental backups"" einsammeln und zum Ende des Skriptes auswerten, beispielsweise nach Fehlern suchen oder die ""Summaries"" zusammenfassen."
<G-vec00169-001-s131><collect.einsammeln><en> Collect the crystal .
<G-vec00169-001-s131><collect.einsammeln><de> Den Kristall einsammeln.
<G-vec00169-001-s132><collect.einsammeln><en> In order to accomplish your task, you can collect extras and power-ups.
<G-vec00169-001-s132><collect.einsammeln><de> Um die Mission zu erfüllen, kannst du Extras und Power-Ups einsammeln.
<G-vec00443-001-s054><collect.einsammeln><en> The main difference is that we bypass the middlemen; they do not earn any money with us, so all of the money we collect makes its way back to the producer.
<G-vec00443-001-s054><collect.einsammeln><de> Der Hauptunterschied ist, dass wir die Mittelsmänner umgehen, sie verdienen kein Geld an uns, sodass alles Geld, das wir einsammeln, seinen Weg zurück zum Hersteller nimmt.
<G-vec00443-001-s056><collect.einsammeln><en> We go forwards with you by using this review to COLLECT everything which you left behind, forgot or flung away.
<G-vec00443-001-s056><collect.einsammeln><de> Wir gehen mit euch vorwärts, indem wir in dieser Rückschau ALLES einsammeln, was ihr liegengelassen, vergessen und von euch geschleudert habt.
<G-vec00443-001-s057><collect.einsammeln><en> In addition the robot has to collect parts of a rocket, transport them to a launch pad and sort and align them in the color sequence of the Russian flag.
<G-vec00443-001-s057><collect.einsammeln><de> Darüber hinaus muss der Roboter Teile einer Rakete einsammeln und zu einer Abschussrampe transportieren und in der farbigen Reihenfolge der Russischen Flagge sortieren und aufstellen.
<G-vec00443-001-s061><collect.einsammeln><en> (If you drop into the water you can collect the goodies later on, you have to return here anyway.
<G-vec00443-001-s061><collect.einsammeln><de> [Hinweis] Wenn man ins Wasser fällt, kann man die Gegenstände später noch mal einsammeln, man muss sowieso noch mal hier hin.
<G-vec00169-001-s133><collect.einziehen><en> This shall not affect the authority of Münch to collect the receivables itself. Münch shall not collect the receivables, however, while the customer duly discharges its payment obligations from the proceeds received, is not in arrears with payments and, most importantly, if no request has been made to open insolvency proceedings or payments have been discontinued.
<G-vec00169-001-s133><collect.einziehen><de> Münch wird jedoch die Forderung nicht einziehen, solange der Kunde seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und insbesondere kein Antrag auf Eröffnung eines Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00169-001-s134><collect.einziehen><en> So that we can collect the SEPA direct debit from the indicated account, we need a SEPA direct debit mandate.
<G-vec00169-001-s134><collect.einziehen><de> Damit wir die SEPA-Lastschrift vom angegebenen Konto einziehen können, benötigen wir ein SEPA-Lastschriftmandat.
<G-vec00169-001-s135><collect.einziehen><en> Not just for fixed amounts Once a Direct Debit is in place, you can use it to collect one-off or recurring payments of any amount.
<G-vec00169-001-s135><collect.einziehen><de> Nicht nur für feste Beträge Sobald eine Lastschrift eingerichtet ist, können Sie damit einmalige oder wiederkehrende Zahlungen jeder Größe einziehen.
<G-vec00169-001-s136><collect.einziehen><en> Our right to collect the claim ourselves remains untouched whereas we are not allowed to collect the claim as long as the customer duly meets his obligation to pay.
<G-vec00169-001-s136><collect.einziehen><de> Unberührt bleibt unsere Befugnis, die Forderung selbst einzuziehen, wobei wir die Forderung nicht einziehen dürfen, solange der Kunde seinen Zahlungsverpflichtungen ordnungsgemäß nachkommt.
<G-vec00169-001-s137><collect.einziehen><en> The team can now collect and amend payments on any day of the month and see the status of payments at any time.
<G-vec00169-001-s137><collect.einziehen><de> Das Team kann nun an jedem Tag des Monats Zahlungen einziehen und ändern und dabei jederzeit den Status der Zahlungen einsehen.
<G-vec00169-001-s138><collect.einziehen><en> In order to prevent unauthorised access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.
<G-vec00169-001-s138><collect.einziehen><de> Um unbefugten Zugang zu Ihren Daten oder Offenbarung Ihrer Daten zu vermeiden, haben wir passende physikalische, elektronische und unternehmerische Maßnahmen getroffen, mit denen wir die Informationen, die wir online einziehen, absichern und schützen.
<G-vec00169-001-s139><collect.einziehen><en> Domestic case – if we are able to collect these costs and interest, we will pay back this amount to you.
<G-vec00169-001-s139><collect.einziehen><de> Nationaler Fall: sofern wir die zusätzlichen Kosten einziehen können, werden wir diese an Sie zurück zahlen.
<G-vec00169-001-s140><collect.einziehen><en> At the same time, BUTSCH will not collect the claims while contractual partner meets its payment obligations from the revenues received, while it is not late with its payments, and especially if they did not initiate the starting of an insolvency procedure, or the performance of payments is not suspended.
<G-vec00169-001-s140><collect.einziehen><de> BUTSCH wird jedoch die Forderung nicht einziehen, solange der Vertragspartner seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und insbesondere kein Antrag auf Eröffnung eines Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00169-001-s141><collect.einziehen><en> Which is right for you will depend on your business and the amount of payments you collect.
<G-vec00169-001-s141><collect.einziehen><de> Was für Sie richtig ist, hängt von Ihrem Unternehmen und der Höhe der Zahlungen ab, die Sie einziehen.
<G-vec00169-001-s142><collect.einziehen><en> We shall not collect the claims ourselves as long as Customer duly fulfils its payment obligations to us.
<G-vec00169-001-s142><collect.einziehen><de> Wir selbst werden die Forderungen nicht einziehen, solange der Kunde seinen Zahlungsverpflichtungen uns gegenüber ordnungsgemäß nachkommt.
<G-vec00169-001-s143><collect.einziehen><en> Hansgrohe will not collect the claim itself if the buyer meets its payment obligations resulting from the proceeds collected, is not overdue with its payments and there is no application for opening insolvency proceedings.
<G-vec00169-001-s143><collect.einziehen><de> Hansgrohe wird die Forderung nicht selbst einziehen, solange der Käufer seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und kein Antrag auf Eröffnung eines Insolvenzverfahrens vorliegt.
<G-vec00169-001-s144><collect.einziehen><en> If collect about it information on the Internet, t...
<G-vec00169-001-s144><collect.einziehen><de> Wenn Sie über ihn die Informationen im Internet, t einziehen werden...
<G-vec00169-001-s145><collect.einziehen><en> But despite this explosion in recurring payments, the way companies collect them isn’t fit for the digital age.
<G-vec00169-001-s145><collect.einziehen><de> Aber trotz dieser explosionsartigen Zunahme wiederkehrender Zahlungen ist die Art und Weise, wie Unternehmen diese einziehen, nicht für das digitale Zeitalter geeignet.
<G-vec00169-001-s146><collect.einziehen><en> Claims against us may only be assigned by the Customer to third parties and he may only allow third parties to collect them with our prior written consent, unless they are accounts which are not contested, ready for judgment or have been adjudicated.
<G-vec00169-001-s146><collect.einziehen><de> Forderungen gegen uns darf der Kunde nur mit unserer vorherigen schriftlichen Zustimmung an Dritte abtreten oder durch Dritte einziehen lassen, es sei denn, es handelt sich um Forderungen, die unbestritten, entscheidungsreif oder rechtskräftig festgestellt sind.
<G-vec00169-001-s147><collect.einziehen><en> We shall not collect the claims assigned as long as the purchaser meets his payment obligations.
<G-vec00169-001-s147><collect.einziehen><de> Wir werden die abgetretenen Forderungen, solange unser Besteller seinen Zahlungsverpflichtungen nachkommt, nicht einziehen.
<G-vec00169-001-s148><collect.einziehen><en> In this case we shall have the right to request the necessary data, in particular name, address, phone number of the Customer´s clients and the resold products to give us the opportunity to notify the assignment of the claim and to collect the claim.
<G-vec00169-001-s148><collect.einziehen><de> Kommt der Kunde seinen wesentlichen Pflichten nicht nach, ist er verpflichtet, auf Verlangen von uns die erforderlichen Daten mitzuteilen, insbesondere Name, Adresse, Telefonnummer des Käufers und die an ihn veräußerten Waren, damit wir dem Käufer gegenüber die Abtretung der Forderung anzeigen und diese selbst einziehen kann.
<G-vec00169-001-s149><collect.einziehen><en> The customer is obliged to undertake all the required actions upon request from AID so that AID can calculate and collect the supplier compensation in accordance with the determinations of this contract.
<G-vec00169-001-s149><collect.einziehen><de> Der Kunde verpflichtet sich, alle erforderlichen Handlungen auf Anforderung von AID zu unternehmen, damit AID die Anbietervergütung nach den Bestimmungen dieses Vertrages abrechnen und einziehen kann.
<G-vec00169-001-s150><collect.einziehen><en> "Before you can collect a SEPA Direct Debit payment from a customer, you must give them ""Pre-notification""."
<G-vec00169-001-s150><collect.einziehen><de> "Bevor Sie eine SEPA-Lastschrift von einem Kunden einziehen können, müssen Sie ihm eine ""Vorabankündigung"" zukommen lassen."
<G-vec00169-001-s151><collect.einziehen><en> If you want to charge an additional fee, put those details in your House Rules and collect the fee using the Resolutions Center .
<G-vec00169-001-s151><collect.einziehen><de> Wenn du eine zusätzliche Gebühr erheben möchtest, kannst du diese Einzelheiten in deinen Hausregeln festhalten und die Gebühr über unser Mediations-Center einziehen.
<G-vec00169-001-s152><collect.einziehen><en> The authorization to collect the claims expires when the customer is in delay of payment, when a decree of insolvency is applied for, or when he suspends payments.
<G-vec00169-001-s152><collect.einziehen><de> Die Berechtigung zur Einziehung erlischt, wenn der Kunde in Zahlungsverzug gerät, wenn ein Antrag auf Eröffnung des Insolvenzverfahrens gestellt wurde oder er seine Zahlungen eingestellt hat.
<G-vec00169-001-s153><collect.einziehen><en> After the assignment, the entrepreneur is authorised to collect the claim.
<G-vec00169-001-s153><collect.einziehen><de> Nach der Abtretung ist der Unternehmer zur Einziehung der Forderung ermächtigt.
<G-vec00169-001-s154><collect.einziehen><en> The buyer still remains entitled to collect on this claim for us in trust.
<G-vec00169-001-s154><collect.einziehen><de> Der Besteller bleibt jedoch berechtigt, die Einziehung der Forderung treuhänderisch für uns vorzunehmen.
<G-vec00169-001-s155><collect.einziehen><en> (c) The buyer shall remain authorised to collect the claim in addition to us.
<G-vec00169-001-s155><collect.einziehen><de> (c) Zur Einziehung der Forderung bleibt der Käufer neben uns ermächtigt.
<G-vec00169-001-s156><collect.einziehen><en> 6.5 The purchaser is authorised to collect assigned claims from the resale until this right is revoked.
<G-vec00169-001-s156><collect.einziehen><de> 6.5 Bis auf Widerruf ist der Käufer zur Einziehung abgetretener Forderungen aus der Weiterveräußerung befugt.
<G-vec00169-001-s157><collect.einziehen><en> If and insofar as the receivables assigned to us amount to less than 110% of our claims against the customer, the customer hereby assigns to us, in order to reach this level, the current and future claims due to them – irrespective of the legal reason – up to the level of the above-mentioned maximum amount and authorises us to collect and then offset them as long and insofar as claims exist on our side against the customer.
<G-vec00169-001-s157><collect.einziehen><de> Wenn und soweit die an uns abgetretenen Forderungen den Betrag von 110 % unserer Forderungen gegen den Kunden nicht erreichen, tritt dieser zur Auffüllung hiermit seine gegenwärtigen und zukünftigen Ansprüche, die ihm - gleich aus welchem Rechtsgrund - zustehen, bis zum vorgenannten Höchstbetrag an uns ab und ermächtigt uns zur Einziehung und anschließenden Verrechnung, solange und soweit unsererseits Forderungen gegen den Kunden besteht.
<G-vec00169-001-s158><collect.einziehen><en> In spite of the assignment the Customer shall be entitled to collect the receivables from the resale.
<G-vec00169-001-s158><collect.einziehen><de> Der Besteller ist zur Einziehung der Forderungen aus der Weiterveräußerung trotz der Abtretung ermächtigt.
<G-vec00169-001-s159><collect.einziehen><en> The Purchaser remains authorised to collect the receivables, even after cession.
<G-vec00169-001-s159><collect.einziehen><de> Der Käufer bleibt zur Einziehung der Forderung auch nach der Abtretung ermächtigt.
<G-vec00169-001-s160><collect.einziehen><en> The purchaser shall remain authorized to collect on the claim even after the assignment.
<G-vec00169-001-s160><collect.einziehen><de> Zur Einziehung dieser Forderung bleibt der Besteller auch nach der Abtretung ermächtigt.
<G-vec00169-001-s161><collect.einziehen><en> After assignment of Buyer to collect outstanding payments until further notice.
<G-vec00169-001-s161><collect.einziehen><de> Nach Abtretung ist der Besteller zur Einziehung der Forderung bis auf Widerruf ermächtigt.
<G-vec00169-001-s162><collect.einziehen><en> At our request, the customer shall be obliged to give us in full the information and documents required to collect assigned claims without delay and, if we do not do so ourselves, to notify its buyers immediately of the assignment to us.8.
<G-vec00169-001-s162><collect.einziehen><de> Auf unser Verlangen ist er verpflichtet, uns die zur Einziehung abgetretener Forderungen erforderlichen Auskünfte und Unterlagen vollständig unverzüglich zu geben und, sofern wir dies nicht selbst tun, seine Abnehmer unverzüglich von der Abtretung an uns zu unterrichten.8.
<G-vec00169-001-s163><collect.einziehen><en> Regardless of this assignment, the purchaser is entitled to collect the accounts receivable.
<G-vec00169-001-s163><collect.einziehen><de> Der Käufer ist zur Einziehung seiner Forderungen trotz der Abtretung berechtigt.
<G-vec00169-001-s164><collect.einziehen><en> 3) Despite assignment, the ordering party shall be permitted to collect his/her claims towards the buyer.
<G-vec00169-001-s164><collect.einziehen><de> 3) Trotz Abtretung ist der Besteller zur Einziehung seiner Forderung gegenüber dem Abnehmer berechtigt.
<G-vec00169-001-s165><collect.einziehen><en> The customer remains entitled to collect this claim, even subsequent to the assignment.
<G-vec00169-001-s165><collect.einziehen><de> Zur Einziehung dieser Forderung bleibt der Kunde auch nach der Abtretung ermächtigt.
<G-vec00169-001-s166><collect.einziehen><en> (c) The Customer shall remain entitled to collect the claim alongside us.
<G-vec00169-001-s166><collect.einziehen><de> (c) Zur Einziehung der Forderung bleibt der Kunde neben uns ermächtigt.
<G-vec00169-001-s167><collect.einziehen><en> Our right to collect the claims from the buyer shall be effective only, if the ordering party does not fulfil his/her payment obligations, if insolvency proceedings are instituted, a cheque or bill is protested or seizure is carried out.
<G-vec00169-001-s167><collect.einziehen><de> Unser Recht zur Einziehung der Forderung beim Abnehmer tritt nur in Kraft, wenn der Besteller seinen Zahlungspflichten nicht nachkommt, mit Beauftragung des Insolvenzverfahrens, einem Scheck- oder Wechselprotest oder einer erfolgten Pfändung beim Kunden.
<G-vec00169-001-s168><collect.einziehen><en> The Buyer is also authorised to collect receivables even after the reassignment.
<G-vec00169-001-s168><collect.einziehen><de> Zur Einziehung dieser Forderungen ist der Käufer auch nach Abtretung ermächtigt.
<G-vec00169-001-s169><collect.einziehen><en> (c) The customer shall remain entitled to collect the claim in addition to us.
<G-vec00169-001-s169><collect.einziehen><de> (c) Zur Einziehung der Forderung bleibt der Kunde neben uns ermächtigt.
<G-vec00169-001-s170><collect.einziehen><en> At our request, the customer shall be obliged to give us in full the information and documents required to collect assigned claims and, if we do not do so ourselves, to notify its buyers immediately of the assignment to us.
<G-vec00169-001-s170><collect.einziehen><de> Auf unser Verlangen ist er verpflichtet, uns die zur Einziehung abgetretener Forderungen erforderlichen Auskünfte und Unterlagen vollständig zu geben und, sofern wir dies nicht selbst tun, seine Abnehmer unverzüglich von der Abtretung an uns zu unterrichten.
<G-vec00169-001-s171><collect.einsammeln><en> Well, Skipper Gek gives you the boat before starting to collect his cargo.
<G-vec00169-001-s171><collect.einsammeln><de> Besser gesagt, Skipper Gek gibt dir das Boot, bevor du beginnst, seine Fracht einzusammeln.
<G-vec00169-001-s172><collect.einsammeln><en> Go on a fun platform adventure and help the penguin find and collect all her children.
<G-vec00169-001-s172><collect.einsammeln><de> Begebe dich in ein lustiges Abenteuer und hilf dem Pinguin dabei, alle seine Kinder zu finden und einzusammeln.
<G-vec00169-001-s173><collect.einsammeln><en> Storyline When the Hive arrived in Clint City, the queen mother sent Aegis undercover to try and locate and collect the energy sources used in the town.
<G-vec00169-001-s173><collect.einsammeln><de> Bei der Ankunft der Hive in Clint City hat die Königinmutter Aegis auf Aufklärungsmission geschickt, um nutzbare Energiequellen in der Stadt zu finden und einzusammeln.
<G-vec00169-001-s174><collect.einsammeln><en> Aim the beam and try to collect green dots.
<G-vec00169-001-s174><collect.einsammeln><de> Ziele mit dem Strahl und versuche, die grünen Punkte einzusammeln.
<G-vec00169-001-s175><collect.einsammeln><en> Your aim is to collect all the gems without running into any mines.
<G-vec00169-001-s175><collect.einsammeln><de> Ihr Ziel besteht darin, alle Edelsteine einzusammeln, ohne auf eine Mine zu treffen.
<G-vec00169-001-s176><collect.einsammeln><en> Land just sitting there with no ownership, banks belly-up unable to carry though and collect mortgages or collect properties and re-sell them.
<G-vec00169-001-s176><collect.einsammeln><de> Land, das einfach ohne Eigentümerschaft dasitzt, Banken geben den Geist auf, da sie unfähig werden, Hypotheken durchzudrücken und einzusammeln, oder Eigentum einzusammeln und es wieder zu verkaufen.
<G-vec00169-001-s177><collect.einsammeln><en> I think it is preferable to use all this energy to collect the bottles locally, for recycling.
<G-vec00169-001-s177><collect.einsammeln><de> "Ich denke dass es sinnvoller ist, diese ganze Energie zu verwenden, um die Flaschen ""vor Ort"" - oder in der Region - einzusammeln und wieder zu verwerten."
<G-vec00169-001-s178><collect.einsammeln><en> Yang energy is usually calling on me to collect my strength and focus on something...some kind of central idea, and to ignite my energy and act with power and decision.
<G-vec00169-001-s178><collect.einsammeln><de> Die Yang Energie ruft mich gewöhnlich dazu auf, meine Stärke einzusammeln und mich auf etwas zu konzentrieren... eine Art zentraler Idee, und meine Energien zu entzünden und mit Kraft und Entschiedenheit zu handeln.
<G-vec00169-001-s179><collect.einsammeln><en> For all this to work out, the Devs are hoping for fans of appropriate titles, and thus a large community: To finalize the game, they offer the title on Kickstarter and plans to collect over the next 29 days 100,000 British pounds.
<G-vec00169-001-s179><collect.einsammeln><de> Damit all das wirklich hinhauen wird, hoffen die Devs auf Fans entsprechender Titel und damit auf eine große Community: Zum Finalisieren des Spiels bietet man den Titel auf Kickstarter an und plant, in den nächsten 29 Tagen 100.000 britische Pfund einzusammeln.
<G-vec00169-001-s180><collect.einsammeln><en> The player moves through his provinces to collect gold and to relocate his legions.
<G-vec00169-001-s180><collect.einsammeln><de> Der Spieler bewegt sich durch seine Provinzen, um sein Gold einzusammeln und um seine Legionen umzuplatzieren.
<G-vec00169-001-s181><collect.einsammeln><en> Note: After you have the 3 spiritual stones, you could go and become an adult right away, but I prefer to collect a few things first, which weren´t reachable before.
<G-vec00169-001-s181><collect.einsammeln><de> OOTMQ_10_2.zip Beachte: Nachdem du die 3 heiligen Steine hast, könntest du sofort hingehen und erwachsen werden, aber ich ziehe es vor, vorher noch ein paar Dinge einzusammeln, die vorher unerreichbar waren.
<G-vec00169-001-s182><collect.einsammeln><en> If the Hall of Plenty feature is triggered in this slot casino game, you need to open one of the six doors to collect treasure.
<G-vec00169-001-s182><collect.einsammeln><de> Wenn die Hall of Plenty-Funktion bei diesem Casino-Spielautomaten ausgelöst wird, dann müssen Sie eine der sechs Türen öffnen, um die Gewinne einzusammeln.
<G-vec00169-001-s183><collect.einsammeln><en> While snorkelers are encouraged to collect old fishing nets or plastic waste during their tours, divers turn into underwater gardeners.
<G-vec00169-001-s183><collect.einsammeln><de> Während Schnorchler bei ihren Ausflügen dazu angehalten werden, alte Angelnetze oder Plastikmüll einzusammeln, werden Taucher förmlich zu Unterwassergärtnern.
<G-vec00169-001-s184><collect.einsammeln><en> They often have the titles of their messages already printed on envelopes, pencils, and other gadgets... to collect money.
<G-vec00169-001-s184><collect.einsammeln><de> Sie haben oft Titel der Predigte schon auf den Umschlägen, Bleistiften, und anderen Spielereien vorgedruckt,... um das Geld einzusammeln.
<G-vec00169-001-s185><collect.einsammeln><en> So they were paid to collect it from the restaurants.
<G-vec00169-001-s185><collect.einsammeln><de> Also sie wurden dafür bezahlt es von den Restaurants einzusammeln.
<G-vec00169-001-s186><collect.einsammeln><en> Now you must help Paul collect all puzzle pieces to rebuild his house.
<G-vec00169-001-s186><collect.einsammeln><de> Jetzt musst du Paul dabei helfen, die Puzzleteile wieder einzusammeln, damit er sein Bild zusammensetzen kann.
<G-vec00169-001-s187><collect.einsammeln><en> Been weeks, and no one came to collect them.
<G-vec00169-001-s187><collect.einsammeln><de> Sind Wochen gewesen, und keiner kam, um sie einzusammeln.
<G-vec00169-001-s188><collect.einsammeln><en> KURDWATCH, September6,2014—On August and August272014 in ʿAmuda and the surrounding area employees of the Asayiş, the security service of the Democratic Union Party(PYD), tried to collect family registers in order to use to them as a basis to compile recruitment lists for persons between eighteen and thirty years of age.
<G-vec00169-001-s188><collect.einsammeln><de> KURDWATCH, 6.September2014 – Am 26.und 27.August2014 haben Mitarbeiter des Asayiş, des Sicherheitsdienstes der Partei der Demokratischen Union(PYD), in ʿAmuda und Umgebung versucht Familienbücher einzusammeln um auf dieser Basis Namenslisten zur Rekrutierung von Personen zwischen achtzehn und dreißig Jahren zu erstellen.
<G-vec00169-001-s189><collect.einsammeln><en> You need colonists to collect the native taxes.
<G-vec00169-001-s189><collect.einsammeln><de> Du benötigst Kolonisten, um die Steuern der Eingeborenen einzusammeln.
<G-vec00443-001-s082><collect.einsammeln><en> Go on a fun platform adventure and help the penguin find and collect all her children.
<G-vec00443-001-s082><collect.einsammeln><de> Begebe dich in ein lustiges Abenteuer und hilf dem Pinguin dabei, alle seine Kinder zu finden und einzusammeln.
<G-vec00169-001-s190><collect.einziehen><en> We reserve the right to collect payment ourselves, should the customer fail to fulfil his obligation to pay and be in arrears.
<G-vec00169-001-s190><collect.einziehen><de> Wir behalten uns vor, die Forderung selbst einzuziehen, wenn der Kunde seinen Zahlungsverpflichtungen nicht ordnungsgemäß nachkommt und in Zahlungsverzug gerät.
<G-vec00169-001-s191><collect.einziehen><en> If the Buyer fails to pay on time, Supplier is entitled to collect the assigned receivable directly from the third-party debtor.
<G-vec00169-001-s191><collect.einziehen><de> Bei Zahlungsverzug des Bestellers ist der Lieferer berechtigt, die abgetretene Forderung beim Drittschuldner direkt einzuziehen.
<G-vec00169-001-s192><collect.einziehen><en> This is without prejudice to our right to collect such receivables ourselves.
<G-vec00169-001-s192><collect.einziehen><de> Unsere Befugnis, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s193><collect.einziehen><en> (1) The liquidators must complete the current business, collect the receivables, convert the rest of the assets into cash, satisfy the creditors and pay out the surplus to those entitled to receive it.
<G-vec00169-001-s193><collect.einziehen><de> § 49 Aufgaben der Liquidatoren (1) Die Liquidatoren haben die laufenden Geschäfte zu beendigen, die Forderungen einzuziehen, das übrige Vermögen in Geld umzusetzen, die Gläubiger zu befriedigen und den Überschuss den Anfallberechtigten auszuantworten.
<G-vec00169-001-s194><collect.einziehen><en> He is entitled to collect the amount of such claims on our behalf until revoked or until cessation of his payments made to us.
<G-vec00169-001-s194><collect.einziehen><de> Er ist ermächtigt, diese bis zum Widerruf oder zur Einstellung seiner Zahlungen an uns für unsere Rechnung einzuziehen.
<G-vec00169-001-s195><collect.einziehen><en> However, we undertake not to collect the debt if purchasers meet their payment obligations from the sales proceeds, do not fall into arrears, and, in particular, have not filed for settlement or bankruptcy proceedings, nor ceased making payments.
<G-vec00169-001-s195><collect.einziehen><de> Wir verpflichten uns jedoch, die Forderung nicht einzuziehen, solange der Kunde seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug gerät und insbesondere kein Antrag auf Eröffnung eines Vergleichs- oder Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00169-001-s196><collect.einziehen><en> We retain the right to collect the receivable ourselves; the orderer's right to undertake the collection shall remain in force even after the assignment.
<G-vec00169-001-s196><collect.einziehen><de> Wir bleiben befugt, die Forderung selbst einzuziehen, das Recht des Bestellers, die Einziehung vorzunehmen, bleibt auch nach Abtretung bestehen.
<G-vec00169-001-s197><collect.einziehen><en> Nouvag AG shall be entitled at any time to disclose the assignment and to collect the claims assigned.
<G-vec00169-001-s197><collect.einziehen><de> Die Nouvag AG ist jederzeit berechtigt, die Abtretung offen zu legen und die abgetretenen Forderungen selbst einzuziehen.
<G-vec00169-001-s198><collect.einziehen><en> In this context, we are obliged not to collect the claim as long and insofar as the buyer meets his payment obligations, there has been no application for the opening of insolvency or similar proceedings or cessation of payment.
<G-vec00169-001-s198><collect.einziehen><de> In diesem Zusammenhang verpflichten wir uns, die Forderung nicht einzuziehen, solange und soweit der Käufer seinen Zahlungsverpflichtungen nachkommt, kein Antrag auf Eröffnung eines Insolvenz- oder ähnlichen Verfahrens gestellt ist und keine Zahlungseinstellung vorliegt.
<G-vec00169-001-s199><collect.einziehen><en> The authority of Hematris to collect the receivable itself will remain unaffected by this; however Hematris undertakes not to collect the receivable provided the Customer properly fulfils his payment obligations and is not in default of payment.
<G-vec00169-001-s199><collect.einziehen><de> Die Befugnis von Hematris, die Forderung selbst einzuziehen, bleibt hiervon unberührt; jedoch verpflichtet sich Hematris, die Forderung nicht einzuziehen, solange der Kunde seinen Zahlungsverpflichtungen ordnungsgemäß nachkommt und nicht in Zahlungsverzug ist.
<G-vec00169-001-s201><collect.einziehen><en> The authority of the supplier, to collect the claim themselves, remains hereof unaffected.
<G-vec00169-001-s201><collect.einziehen><de> Die Befugnis des Verkäufers, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s202><collect.einziehen><en> Our authority to collect the claim ourselves remains thereby unaffected.
<G-vec00169-001-s202><collect.einziehen><de> Unsere Befugnis, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s203><collect.einziehen><en> The SEPA Direct Debit allows you to give a European creditor (the Belgian or European supplier of your goods or services) permission to collect payment automatically for your future invoices.
<G-vec00169-001-s203><collect.einziehen><de> Mittels einer europäischen Lastschrift können Sie einem europäischen Gläubiger (dem belgischen oder europäischen Lieferanten Ihrer Waren oder Dienstleistungen) die Erlaubnis erteilen, Ihre zukünftigen Rechnungen automatisch einzuziehen.
<G-vec00169-001-s204><collect.einziehen><en> In this case the seller is hereby authorized by the purchaser to inform his buyers about the assignment and to collect the claims himself.
<G-vec00169-001-s204><collect.einziehen><de> In diesem Falle wird der Verkäufer hiermit vom Käufer bevollmächtigt, die Abnehmer von der Abtretung zu unterrichten und die Forderungen selbst einzuziehen.
<G-vec00169-001-s205><collect.einziehen><en> This shall not affect the entitlement of the Supplier to collect the receivables himself.
<G-vec00169-001-s205><collect.einziehen><de> Die Befugnis des Lieferanten, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s206><collect.einziehen><en> We reserve the right to collect the outstanding payments ourselves should the entrepreneur not properly fulfil his payment duties and fall into default with payment.
<G-vec00169-001-s206><collect.einziehen><de> Wir behalten uns vor, die Forderung selbst einzuziehen, sobald der Unternehmer seinen Zahlungsverpflichtungen nicht ordnungsgemäß nachkommt und in Zahlungsverzug gerät.
<G-vec00169-001-s208><collect.einziehen><en> The Buyer is entitled to collect claims resulting from the reselling until revoked by the supplier.
<G-vec00169-001-s208><collect.einziehen><de> Der Käufer ist - bis auf Widerruf - berechtigt, die Forderung für HTV-Conservation GmbH einzuziehen.
<G-vec00169-001-s209><collect.erfassen><en> Data Transfers We may transfer the personal information we collect through the Channels to, and store such data in, other countries, including the U.S., which may have different data protection laws than the country in which the information was provided.
<G-vec00169-001-s209><collect.erfassen><de> Wir dÃ1⁄4rfen personenbezogene Daten, die wir Ã1⁄4ber die Kanäle erfassen, in andere Länder Ã1⁄4bertragen und dort speichern, einschließlich der USA, die möglicherweise andere Datenschutzgesetze haben als das Land, in dem die Informationen bereitgestellt wurden, soweit zulässig und im Einklang mit den Regeln Ã1⁄4ber den internationalen Datenverkehr stehend.
<G-vec00169-001-s210><collect.erfassen><en> These are cookies that are merely required to collect certain information on our Platforms to provide a service required or wanted by you as user.
<G-vec00169-001-s210><collect.erfassen><de> Dies sind solche, die ausschließlich zum Erfassen einiger Informationen auf unseren Plattformen erforderlich sind, um eine von Ihnen als Nutzer angeforderte oder erwünschte Leistung zu erbringen.
<G-vec00169-001-s211><collect.erfassen><en> We collect information to provide better services to all of our users – from figuring out basic stuff like which language you speak, to more complex things like which ads you'll find most useful, the people who matter most to you online, or which YouTube videos you might like.
<G-vec00169-001-s211><collect.erfassen><de> Wir erfassen Informationen, um allen unseren Nutzern bessere Dienste zur Verfügung zu stellen – von der Feststellung grundlegender Aspekte wie zum Beispiel der Sprache, die Sie sprechen, bis hin zu komplexeren Fragen wie zum Beispiel der Werbung, die Sie besonders nützlich finden, den Personen, die Ihnen online am wichtigsten sind, oder den YouTube-Videos, die Sie interessant finden könnten.
<G-vec00169-001-s212><collect.erfassen><en> When it is installed, the Federation Service Proxy role service uses WS-F PRP protocols to collect user credential information from browser clients and Web applications and send the information to the Federation Service on their behalf.
<G-vec00169-001-s212><collect.erfassen><de> Wenn der Verbunddienstproxy-Rollendienst installiert ist, verwendet er WS-Verbund-PRP-Protokolle, um Benutzeranmeldeinformationen von Browserclients und Webanwendungen zu erfassen und die Informationen in ihrem Auftrag an den Verbunddienst zu senden.
<G-vec00169-001-s213><collect.erfassen><en> This Cathay Pacific Customer Privacy Policy (Privacy Policy) sets out what information we collect, and how we use it.
<G-vec00169-001-s213><collect.erfassen><de> Diese Datenschutzrichtlinien von Cathay Pacific (Datenschutzrichtlinien) erklären, welche Angaben wir erfassen und was wir damit tun.
<G-vec00169-001-s214><collect.erfassen><en> Information we collect from third parties: We collect Personal Information from third party service providers, such as information about your credit history from credit agencies and other financial information which is relevant to the provision of the Services, as well as information which is gathered in order to verify your identity and prevent fraudulent or illegal activity.
<G-vec00169-001-s214><collect.erfassen><de> Informationen, die wir von Dritten erfassen: Wir erfassen personenbezogene Daten von Drittdienstleistern, wie etwa Informationen über Ihre Bonität von Auskunfteien und andere Informationen, die für die Bereitstellung der Services relevant sind, sowie Informationen, die erfasst werden, um Ihre Identität zu überprüfen und zu bestätigen und betrügerische oder illegale Handlungen zu verhindern.
<G-vec00169-001-s216><collect.erfassen><en> From the very beginning until the completion of a construction process and even afterwards, there is often a need to collect a large number of different measurements, prepare their graphic representation, evaluate, correlate them, transfer them to the reports and archive them.
<G-vec00169-001-s216><collect.erfassen><de> Oft sind vom Beginn einer Baumaßnahme bis zur Fertigstellung und auch darüber hinaus eine Vielzahl von verschiedenen Messgrößen kontinuierlich zu erfassen, grafisch darzustellen und auszuwerten, miteinander in Bezug zu setzen, in Berichte zu exportieren und zu archivieren.
<G-vec00169-001-s217><collect.erfassen><en> Log informationWhen you use our services or view content provided by Google, we may automatically collect and store certain information in server logs .
<G-vec00169-001-s217><collect.erfassen><de> Protokolldaten Wenn Sie unsere Dienste nutzen oder von Google bereitgestellte Inhalte aufrufen, erfassen und speichern wir bestimmte Daten in Serverprotokollen .
<G-vec00169-001-s218><collect.erfassen><en> We use cloud based servers hosted by third party service providers (which may be located outside the EEA) to collect site traffic information.
<G-vec00169-001-s218><collect.erfassen><de> Wir nutzen cloudbasierte Server, die von Drittanbietern (die sich außerhalb des EWRs befinden können) gehostet werden, um Website-Traffic-Informationen zu erfassen.
<G-vec00169-001-s219><collect.erfassen><en> We used an internal testing tool to collect performance data and metrics from the machines under test and to drive the session launches.
<G-vec00169-001-s219><collect.erfassen><de> Wir verwendeten ein internes Testtool, um Leistungsdaten und Metriken der getesteten Maschinen zu erfassen und um die Sitzungen zu starten.
<G-vec00169-001-s220><collect.erfassen><en> To give you a better overview of how we collect and use personal information in the various interactions between you and göldo, please read the following sections. 4.
<G-vec00169-001-s220><collect.erfassen><de> Um dir einen besseren Überblick darüber zu geben, wie wir personenbezogene Daten erfassen und in den verschiedenen Interaktionen zwischen dir und göldo verwenden, lies dir bitte die folgenden Abschnitte durch.
<G-vec00169-001-s221><collect.erfassen><en> Information About User Content: In some cases, we may collect information about content you provide to the Services.
<G-vec00169-001-s221><collect.erfassen><de> Daten über Inhalte von Nutzern: In manchen Fällen erfassen wir Daten über Inhalte, die du den Diensten bereitstellst.
<G-vec00169-001-s222><collect.erfassen><en> Then it was off on the 18 km long test track to measure the strength of the support and collect other data.
<G-vec00169-001-s222><collect.erfassen><de> Anschließend ging die Fahrt weiter über die gesamte 18 km lange Strecke, um die Stärke der Unterstützung und weitere Daten zu erfassen.
<G-vec00169-001-s223><collect.erfassen><en> (c) Activity Information: While using the Viber Services, we will collect, and other users can see, your connection status, whether you have received and seen messages sent to you, if you are currently on another call, and information related to the calls and messages you have sent and received such as length of the call, who called who, who messaged who, and at what time; if you do not want people to know that you're online or that you've seen messages, you can change these options in your settings.
<G-vec00169-001-s223><collect.erfassen><de> (c) Nutzungsdaten:Während der Nutzung der Viber-Dienste werden wir Ihren Verbindungsstatus erfassen und andere Benutzer können sehen, ob Sie Nachrichten empfangen und gesehen haben, die an Sie gesendet wurden, wenn Sie sich gerade in einem anderen Anruf befinden, und Informationen zu den Anrufen und Nachrichten haben Sie senden und empfangen wie die Länge des Anrufs, wer wen angerufen hat, wer wen angerufen hat und zu welcher Zeit; Wenn Sie nicht möchten, dass die Leute wissen, dass Sie online sind oder dass Sie Nachrichten gesehen haben, können Sie diese Optionen in Ihren Einstellungen ändern.
<G-vec00169-001-s224><collect.erfassen><en> Performance cookies These cookies collect information about your visit and use of this website, for instance which pages you visit the most often, and if you get error messages from web pages.
<G-vec00169-001-s224><collect.erfassen><de> Leistungs-Cookies Diese Cookies erfassen Informationen über Ihren Besuch und die Nutzung dieser Website, zum Beispiel welche Seiten Sie am häufigsten besuchen und ob Sie von Webseiten Fehlermeldungen erhalten.
<G-vec00169-001-s225><collect.erfassen><en> ou can collect key pieces of analytics information that are related to JSONStore
<G-vec00169-001-s225><collect.erfassen><de> Sie können Sie wichtige Analysedaten mit Bezug zu JSONStore erfassen.
<G-vec00169-001-s226><collect.erfassen><en> The following paragraphs describe the various purposes for which We collect and use your Personal Data, and the different types of Personal Data that are collected for each purpose.
<G-vec00169-001-s226><collect.erfassen><de> Die folgenden Absätze erläutern die verschiedenen Zwecke, für die wir Ihre personenbezogenen Daten erfassen und verwenden, sowie die verschiedenen Arten von personenbezogenen Daten, die für jeden Zweck erfasst werden.
<G-vec00169-001-s227><collect.erfassen><en> "Please note that our Website is not directed at children under the age of 13 (each a ""Child"" together ""Children"") and we do not knowingly collect personal information about Children."
<G-vec00169-001-s227><collect.erfassen><de> "Bitte beachten Sie, dass sich unsere Website nicht an Kinder unter 13 Jahren richtet (jeweils ein ""Kind"" zusammen ""Kinder"") und wir nicht wissentlich persönliche Informationen über Kinder erfassen."
<G-vec00169-001-s228><collect.erfassen><en> We use Google Analytics, which uses cookies and similar technologies to collect and analyse information about use of the Services and report on activities and trends.
<G-vec00169-001-s228><collect.erfassen><de> Unsere Websites verwenden Google Analytics, einen Service, der anhand von Cookies und ähnlichen Technologien Informationen über die Nutzung der Dienstleistungen erfasst und analysiert und Aktivitäten und Trends meldet.
<G-vec00169-001-s229><collect.erfassen><en> This Privacy declaration states which personal data we may collect from you, how we may use that data, and with whom we may share it.
<G-vec00169-001-s229><collect.erfassen><de> In dieser Datenschutzerklärung ist festgelegt, welche Ihrer personenbezogenen Daten von uns erfasst werden können, wie diese Daten von uns verwendet werden, und mit wem wir sie gegebenenfalls teilen.
<G-vec00169-001-s230><collect.erfassen><en> This is done by means of cookies stored in your browser which are used by Google to collect and analyse your user behaviour when you visit different websites.
<G-vec00169-001-s230><collect.erfassen><de> Dies erfolgt mittels in Ihrem Browser gespeicherter Cookies, über die Ihr Nutzungsverhalten bei Besuch verschiedener Websites durch Google erfasst und ausgewertet wird.
<G-vec00169-001-s231><collect.erfassen><en> Penske does not knowingly collect or use personal information from children under the age of sixteen (16) or allow such children to participate in any services offered on the Sites that require the submission of user information.
<G-vec00169-001-s231><collect.erfassen><de> Penske erfasst oder verwendet wissentlich keine personenbezogenen Daten von Kindern unter sechzehn (16) oder gestattet diesen Kindern, an Dienstleistungen teilzunehmen, die auf den Websites angeboten werden, welche die Übermittlung von Nutzerinformationen erfordern.
<G-vec00169-001-s232><collect.erfassen><en> Our web servers will only collect your domain name or IP address when you browse our website.
<G-vec00169-001-s232><collect.erfassen><de> Bei Ihrem Besuch auf der Website wird von unseren Webservern lediglich Ihr Domainname oder Ihre IP-Adresse erfasst.
<G-vec00169-001-s233><collect.erfassen><en> The service Google Tag Manager itself (which implements the tags) is a domain without cookies and does not collect personal data.
<G-vec00169-001-s233><collect.erfassen><de> Der Dienst Google Tag Manager selbst (der die Tags implementiert) ist eine Cookie-lose Domain und erfasst keine personenbezogenen Daten.
<G-vec00169-001-s234><collect.erfassen><en> The Tag Manager tool itself, which implements the tags, is a cookie-less domain and does not collect personal data.
<G-vec00169-001-s234><collect.erfassen><de> Das Tool Tag Manager selbst, welches die Tags implementiert, ist eine cookielose Domain und erfasst keine personenbezogenen Daten.
<G-vec00169-001-s235><collect.erfassen><en> If you set your PC to automatically update according to location or network accessibility, Settings will collect corresponding data, such as WIFI and VPN information, to seamlessly update your system.
<G-vec00169-001-s235><collect.erfassen><de> Wenn Sie Ihren PC so einstellen, dass er Aktualisierungen je nach Standort- oder Netzwerkzugänglichkeit automatisch durchführt, werden die entsprechenden Daten, etwa Wi-Fi- und VPN-Informationen, in Ihren Einstellungen erfasst, damit Ihr System nahtlos aktualisiert werden kann.
<G-vec00169-001-s236><collect.erfassen><en> Unique users - Google Analytics cookies collect and group your data.
<G-vec00169-001-s236><collect.erfassen><de> Eindeutige Nutzer - Google Analytics Cookies erfasst und gruppiert Ihre Daten.
<G-vec00169-001-s237><collect.erfassen><en> MTS does not knowingly or intentionally collect Personal Data from children under the age of 16, or such other age as specified by local law.
<G-vec00169-001-s237><collect.erfassen><de> "MTS erfasst nicht wissentlich oder vorsätzlich ""Personenbezogene Daten"" von Kindern unter 16 Jahren oder einem anderen Alter, das von den örtlichen Gesetzen festgelegt wurde."
<G-vec00169-001-s238><collect.erfassen><en> We will collect your IP address when you visit the Site.
<G-vec00169-001-s238><collect.erfassen><de> Beim Besuch auf der Website wird Ihre IP-Adresse erfasst.
<G-vec00169-001-s239><collect.erfassen><en> The resulting archive does not collect just post-socialist experiences, but also memories from transitional periods in countries that joined the EU at a later date, for example, Greece and others.
<G-vec00169-001-s239><collect.erfassen><de> Das daraus resultie- rende Archiv erfasst dabei nicht nur die Erfahrungen der postsozialistischen Länder, sondern auch Erinnerungen an die Zeit des Umbruchs in Ländern wie Griechenland, die erst später in die EU eintraten.
<G-vec00169-001-s240><collect.erfassen><en> Therefore this program can collect the fuel prices of as many gas stations as possible.
<G-vec00169-001-s240><collect.erfassen><de> Dazu können Kraftstoffpreise beliebig vieler Tankstellen mit diesem Programm erfasst werden.
<G-vec00169-001-s241><collect.erfassen><en> Nor can we be held responsible for the actions or omissions of other users or third parties who may misuse your personal data which they collect from the Site.
<G-vec00169-001-s241><collect.erfassen><de> Wir können auch nicht für die Handlungen oder Unterlassungen anderer Nutzer oder Dritter verantwortlich gemacht werden, die möglicherweise Ihre personengebundenen Daten, die sie von der Website erfasst haben, missbrauchen.
<G-vec00169-001-s242><collect.erfassen><en> "By clicking on ""Complete Download"" you agree to the End-User Licence Agreement and that Bluebeam will collect and use the information you provide in accordance with Bluebeam's Privacy Policy ."
<G-vec00169-001-s242><collect.erfassen><de> "Durch Klicken auf ""Download abschließen"" stimmen Sie der Endbenutzer-Lizenzvereinbarung zu und erklären sich damit einverstanden, dass Bluebeam die Informationen, die Sie im Einklang mit der Datenschutzrichtlinie von Bluebeam bereitstellen, erfasst und verwendet."
<G-vec00169-001-s243><collect.erfassen><en> "The Symate GmbH, in association with the Technische Universität Dresden, is developing the integrated Technology Data Management system ""Detact"". Detact can be used to systematically collect, combine, and intelligently evaluate technological data."
<G-vec00169-001-s243><collect.erfassen><de> "Die Symate GmbH entwickelt in Kooperation mit dem Institut für Werkzeugmaschinen und Steuerungstechnik der TU Dresden das integrierte Technologiedatenmanagement-System ""Detact"", mit dem produktionstechnologische Daten systematisch erfasst, zusammengeführt und intelligent ausgewertet werden können."
<G-vec00169-001-s244><collect.erfassen><en> However, it is not currently possible to collect podcasts, for technical reasons.
<G-vec00169-001-s244><collect.erfassen><de> Allerdings können Podcasts derzeit aus technischen Gründen noch nicht erfasst werden.
<G-vec00169-001-s245><collect.erfassen><en> If you are using Dometic business websites, online order services or connected devices we may collect additional information from you.
<G-vec00169-001-s245><collect.erfassen><de> Wenn Sie Websites von Dometic für Unternehmenskunden, Online-Bestelldienste oder angeschlossene Geräte nutzen, werden möglicherweise zusätzliche Daten über Sie erfasst.
<G-vec00169-001-s246><collect.erfassen><en> GMS Z Med Ausbild will be screened by MEDLINE and collect impact factor credits immediately.
<G-vec00169-001-s246><collect.erfassen><de> GMS Z Med Ausbild wird von Anfang an in MEDLINE erfasst und somit den internationalen Zitationsindices zugeführt.
<G-vec00169-001-s247><collect.erfassen><en> To ensure the security and confidentiality of personal data that we collect on-line, we use data networks protected, inter alia, by industry standard firewall and password protection.
<G-vec00169-001-s247><collect.erfassen><de> Um die Sicherheit und Vertraulichkeit der online erfassten personenbezogenen Daten zu wahren, werden Datennetzwerke genutzt, die unter anderem mit Firewalls und Kennwörtern nach Branchenstandards geschützt sind.
<G-vec00169-001-s248><collect.erfassen><en> We take reasonable steps to ensure that all of your Personal Information we collect, use or disclose is accurate, complete, up to date, stored in a secure environment and accessed only by authorized personnel for permitted purposes.
<G-vec00169-001-s248><collect.erfassen><de> Wir treffen angemessene Maßnahmen, um sicherzustellen, dass Ihre von uns erfassten, verwendeten oder offen gelegten persönlichen Daten richtig, vollständig und aktuell sind, dass sie sicher gespeichert werden und dass auf diese Daten nur von dazu ermächtigtem Mitarbeitern und nur im Rahmen fest umrissener Aufgabenstellungen zugegriffen werden kann.
<G-vec00169-001-s249><collect.erfassen><en> Purpose: The personal data we collect allows us to process your enquiry and provide you with an appropriate response.
<G-vec00169-001-s249><collect.erfassen><de> Zweck: Die von uns erfassten personenbezogenen Daten ermöglichen uns die Bearbeitung Ihrer Anfrage und die Bereitstellung einer entsprechenden Antwort.
<G-vec00169-001-s250><collect.erfassen><en> All the data that you collect on a form is automatically passed as form variables to the associated action page.
<G-vec00169-001-s250><collect.erfassen><de> Alle in einem Formular erfassten Daten werden automatisch als Formularvariablen an die zugehörige Aktionsseite übergeben.
<G-vec00169-001-s251><collect.erfassen><en> We also use the information we collect to offer you content, search results and advertisements that will be of most interest to you.
<G-vec00169-001-s251><collect.erfassen><de> Wir verwenden die von uns erfassten Informationen auch dazu, Ihnen die Inhalte, Suchergebnisse und Werbeanzeigen zur Verfügung zu stellen, die für Sie am relevantesten sind.
<G-vec00169-001-s252><collect.erfassen><en> We have implemented reasonable administrative, technical, and physical safeguards to protect the confidentiality, security, and integrity of the personal information that we collect through Radar Pace.
<G-vec00169-001-s252><collect.erfassen><de> Wir haben angemessene organisatorische, technische und physische Schutzmechanismen umgesetzt, um die Vertraulichkeit, Sicherheit und Unversehrtheit der von uns mittels Radar Pace erfassten personenbezogenen Informationen zu schÃ1⁄4tzen.
<G-vec00169-001-s253><collect.erfassen><en> When you create a YouVersion account or use any one of our applications or sites, the information we collect is for the purpose of offering a more personalised Bible experience.
<G-vec00169-001-s253><collect.erfassen><de> Wenn du ein YouVersion-Konto erstellst oder eine unserer Apps oder Webseiten verwendest, sollen die von uns erfassten Informationen dazu dienen, dass die App noch besser auf dich maßgeschneidert wird.
<G-vec00169-001-s254><collect.erfassen><en> The data you collect with Unbounce is processed securely and in accordance with GDPR requirements.
<G-vec00169-001-s254><collect.erfassen><de> Die mit Unbounce erfassten Daten werden sicher und gemäß den DSGVO-Anforderungen verarbeitet.
<G-vec00169-001-s255><collect.erfassen><en> We may share the location information we collect with third parties as addressed in Section 3.
<G-vec00169-001-s255><collect.erfassen><de> Wir können die von uns erfassten Standortinformationen an Dritte weitergeben, wie in Abschnitt 3 beschrieben.
<G-vec00169-001-s256><collect.erfassen><en> This is a basic overview of the information we collect.
<G-vec00169-001-s256><collect.erfassen><de> Die obige Aufstellung versteht sich lediglich als grober Überblick über die von uns erfassten Informationen.
<G-vec00169-001-s257><collect.erfassen><en> In order to prevent unauthorised access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.
<G-vec00169-001-s257><collect.erfassen><de> Um unberechtigten Zugriff oder Offenlegung zu verhindern, haben wir geeignete physikalische, elektronische und verwaltungstechnische Maßnahmen zur Sicherung und zum Schutz der von uns online erfassten Daten umgesetzt.
<G-vec00169-001-s258><collect.erfassen><en> Tesla intends to provide you with a level of comfort and confidence in how we collect, use, share, and safeguard information that we collect.
<G-vec00169-001-s258><collect.erfassen><de> Tesla möchte, dass Sie ein gutes Gefühl haben und uns hinsichtlich der Erfassung, Verwendung, Weitergabe und Sicherung der von uns erfassten Informationen vertrauen.
<G-vec00169-001-s259><collect.erfassen><en> If you are a Facebook member and Facebook has allowed it through your account's privacy settings, Facebook may also link the information we collect from your visit to us with your member account and use it to direct targeted Facebook ads.
<G-vec00169-001-s259><collect.erfassen><de> Falls Sie Mitglied bei Facebook sind und es Facebook über die Privatsphären-Einstellungen Ihres Kontos erlaubt haben, kann Facebook die über Ihren Besuch bei uns erfassten Information zudem mit Ihrem Mitgliedskonto verknüpfen und für die zielgerichtete Schaltung von Facebook-Ads benutzen.
<G-vec00169-001-s260><collect.erfassen><en> The personal data we collect may include your username, profile photo, name, email address, gender, birthday/age, country, language, latest tweet, profile URL, social media profile, location and password.
<G-vec00169-001-s260><collect.erfassen><de> Zu den gegebenenfalls erfassten personenbezogenen Daten gehören Benutzername, Profilfoto, Name, E-Mail-Adresse, Geschlecht, Geburtstag/Alter, Land, Sprache, letzter Tweet, Profil-URL, Profil in sozialen Medien, Standort und Passwort.
<G-vec00169-001-s261><collect.erfassen><en> We retain the data you provide from time to time, including your purchase history and data we collect when you use our products and services.
<G-vec00169-001-s261><collect.erfassen><de> Wir sichern die Daten, die Sie zu verschiedenen Gelegenheiten übermitteln, einschließlich Ihrer Kaufdaten und der von uns erfassten Informationen, wenn Sie unsere Produkte und Services nutzen.
<G-vec00169-001-s262><collect.erfassen><en> We have put in place commercially reasonable physical, electronic, and organisational procedures to safeguard and secure the information we collect.
<G-vec00169-001-s262><collect.erfassen><de> Wir haben wirtschaftlich angemessene physische, elektronische und organisatorische Verfahren eingeführt, um die von uns erfassten Informationen zu sichern und zu schützen.
<G-vec00169-001-s263><collect.erfassen><en> Under no circumstances will data we collect be passed on to third parties or linked to personal data without your consent.
<G-vec00169-001-s263><collect.erfassen><de> In keinem Fall werden die von uns erfassten Daten an Dritte weitergegeben oder ohne Ihre Einwilligung eine Verknüpfung mit personenbezogenen Daten hergestellt.
<G-vec00169-001-s264><collect.erfassen><en> "We clarified under ""Our Use of Information That We Collect: Personal Data"" that if we intend to use your Personal Data in a manner that is not consistent with our Privacy Policy, we will inform you of such anticipated use prior to or at the time at which we collect it or we will obtain your consent subsequent to such collection but prior to such use."
<G-vec00169-001-s264><collect.erfassen><de> "Im Abschnitt ""Verwendung der von uns erfassten Informationen: Persönliche Daten"" haben wir klargestellt, dass wir, falls wir beabsichtigen, persönliche Daten in einer Weise zu verwenden, die nicht in Einklang mit den vorliegenden Datenschutzrichtlinien steht, Sie vor oder zum Zeitpunkt der Erfassung der persönlichen Daten über eine solche vorhergesehene Verwendung informieren, oder wir Ihre Genehmigung nach einer solchen Erfassung, jedoch vor einer solchen Verwendung einholen."
<G-vec00169-001-s265><collect.erfassen><en> The information we collect will never be forwarded to third parties or linked with your personal data without your explicit consent.
<G-vec00169-001-s265><collect.erfassen><de> In keinem Fall werden die von uns erfassten Daten an Dritte weitergegeben oder ohne Ihre Einwilligung eine Verknüpfung mit personenbezogenen Daten hergestellt.
<G-vec00169-001-s285><collect.erhalten><en> Next, zero in on the directory where you want to collect more reviews for your business.
<G-vec00169-001-s285><collect.erhalten><de> Fang beim Verzeichnis, auf dem Du mehr Bewertungen erhalten willst, bei Null an.
<G-vec00169-001-s286><collect.erhalten><en> You collect the payments via PayPal or check.
<G-vec00169-001-s286><collect.erhalten><de> Sie erhalten die Zahlungen per PayPal oder Scheck.
<G-vec00169-001-s287><collect.erhalten><en> Within 7 days after your arrival, you have to be at one of the registration departments (see bottom of page) and collect a certificate of your registration.
<G-vec00169-001-s287><collect.erhalten><de> Nach Ihrer Ankunft müssen Sie sich innerhalb von 7 Tagen bei einer der unten genannten Meldestellen amtlich anmelden und erhalten dort eine Meldebestätigung.
<G-vec00169-001-s288><collect.erhalten><en> "Where We Store Your Personal Data Due to the nature of modern 'cloud' computer systems, the data we collect from you may be transferred to, and stored at, a destination outside of the European Economic Area (""EEA""), including in countries where you may have fewer legal rights that you do under the laws of your own country."
<G-vec00169-001-s288><collect.erhalten><de> "Die Aufbewahrung Ihrer persönlichen Daten Aufgrund der modernen ""Cloud"" Computersysteme, können die Informationen, die wir von Ihnen erhalten an einen Ort außerhalb des Europäischen Wirtschaftsraums (EWR) Ã1⁄4bermittelt und dort gespeichert werden, dazu zählen auch Länder, in denen man weniger Rechte hat als in dem Land, in dem Sie leben."
<G-vec00169-001-s289><collect.erhalten><en> Because of delays I was no less than 45 minutes late (and after closing time), but still it was possible to collect my ring.
<G-vec00169-001-s289><collect.erhalten><de> Wegen der Verzögerungen war ich nicht weniger als 45 Minuten zu spät (und nach den Öffnungszeiten), aber trotzdem war es möglich, meinen Ring zu erhalten.
<G-vec00169-001-s290><collect.erhalten><en> On the same page you are requested to choose how you would like to collect your tickets.
<G-vec00169-001-s290><collect.erhalten><de> Auf derselben Seite werden Sie aufgefordert anzugeben, wie Sie ihre Tickets erhalten m chten .
<G-vec00169-001-s291><collect.erhalten><en> Send surveys and polls to your subscribers to collect valuable information.
<G-vec00169-001-s291><collect.erhalten><de> Umfragen und Befragungen an Ihre Abonnenten um wertvolle Informationen zu erhalten zu machen.
<G-vec00169-001-s292><collect.erhalten><en> The $80 pending bonus will be remitted to players' accounts in $8 increments, comprised of $1 cash and $7 in tournament tickets, each time they collect 250 Bonus Points for playing poker.
<G-vec00169-001-s292><collect.erhalten><de> Der verbleibende Bonus in Höhe von $ 80 wird den Spielerkonten jedes Mal, wenn die Spieler 250 Bonuspunkte für ihr Pokerspiel erhalten, in Teilzahlungen zu je $ 8 ausgezahlt ($ 1 in bar und $ 7 in Turniertickets).
<G-vec00169-001-s293><collect.erhalten><en> 5 December: The FreeBSD Project has enabled Google Analytics to collect anonymised statistics on web site use.
<G-vec00169-001-s293><collect.erhalten><de> 5 Dezember: Das FreeBSD Project hat Google Analytics aktiviert, um anonymisierte Statistiken über die Nutzung der Webseiten zu erhalten.
<G-vec00169-001-s294><collect.erhalten><en> In order to collect your money, you must either link an existing PayPal account to your Microsoft account or create a new PayPal account.
<G-vec00169-001-s294><collect.erhalten><de> Um Ihr Geld zu erhalten, müssen Sie entweder ein vorhandenes PayPal-Konto mit Ihrem Microsoft-Konto verknüpfen oder aber ein neues PayPal-Konto erstellen.
<G-vec00169-001-s295><collect.erhalten><en> Over 80% of the data we collect about the surrounding comes from visual stimuli.
<G-vec00169-001-s295><collect.erhalten><de> Über 80 % aller Informationen über die Außenwelt erhalten wir durch unsere Augen.
<G-vec00169-001-s296><collect.erhalten><en> To be elected, a candidate must collect an absolute majority of votes (N.B.
<G-vec00169-001-s296><collect.erhalten><de> Um gewählt zu werden, muss ein Kandidat die absolute Mehrheit der Stimmen erhalten.
<G-vec00169-001-s297><collect.erhalten><en> We may use the information we collect from you as your authentication for authorization of your access to your vehicle account data or use certain other application features in the following ways: to personalize your experience and to allow us to deliver the content related to your vehicle
<G-vec00169-001-s297><collect.erhalten><de> Die Daten, die wir von Ihnen erhalten, werden wir für Ihre Authentifizierung verwenden, um den Zugriff auf Daten aus dem Konto Ihres Fahrzeugs zu ermöglichen und für bestimmte andere Merkmale unserer mobilen Applikation.
<G-vec00169-001-s298><collect.erhalten><en> The objective of the directive is to collect information on all of the materials on the market in the EU, to evaluate them and to protect humans and the environment with appropriate measures.
<G-vec00169-001-s298><collect.erhalten><de> Ziel der Verordnung ist es, Informationen zu allen in der EU auf dem Markt befindlichen Stoffen zu erhalten, sie zu bewerten und durch geeignete Maßnahmen Mensch und Umwelt zu schützen.
<G-vec00169-001-s299><collect.erhalten><en> Info Multibanco Multibanco is an Instant bank transfer tool, available in Portugal, enables merchants to collect funds from customers who have personal bank account in the leading banks in Portugal.
<G-vec00169-001-s299><collect.erhalten><de> Info Multibanco Multibanco ist ein Tool für sofortige Banküberweisungen, das in Portugal verfügbar ist und mit dem Händler Geld von Kunden erhalten können, die in einer führenden Bank in Portugal ein Bankkonto unterhalten.
<G-vec00169-001-s300><collect.erhalten><en> You can now play Captain Cooks Flash casino, no download required, and collect 100% match bonus up to $50 + $25 each month with a purchase of $50 or more
<G-vec00169-001-s300><collect.erhalten><de> Wenn Sie es lieber haben, können Sie Captain Cooks Casino Flash spielen, ohne die Software zu installieren, und Sie erhalten einen Bonus von 100% bis zu $ 50 jeden Monat mit dem Kauf von $ 50 oder mehr.
<G-vec00169-001-s301><collect.erhalten><en> """We are the first company to start scanning cultural heritage for commercial purposes and also for the benefit of the host party: the museums collect a royalty from each sale and receive the models."
<G-vec00169-001-s301><collect.erhalten><de> """Wir sind das erste Unternehmen, das kulturelle Denkmäler zu kommerziellen Zwecken scannt und dabei gleichzeitig den Museen zu gute kommt: Die Museen erhalten eine Lizenzgebühr für jeden Verkauf und bekommen außerdem die Modelle selbst."
<G-vec00169-001-s302><collect.erhalten><en> We collect information about your use of our services during travel, such as your use of our inflight entertainment system or our VIP lounge facilities.
<G-vec00169-001-s302><collect.erhalten><de> Wir erhalten Daten über Ihre Nutzung unserer Serviceleistungen während der Reise, beispielsweise die Nutzung unserer Unterhaltungssysteme an Bord oder unserer VIP-Lounges.
<G-vec00169-001-s303><collect.erhalten><en> All passengers will enter through the arrivals hall in the new terminal and collect their baggage at one of the ten carousels.
<G-vec00169-001-s303><collect.erhalten><de> Alle Passagiere kommen bereits in der Ankunftshalle im neuen Terminal an und erhalten hier an einem der zehn Laufbänder ihr Gepäck.
<G-vec00169-001-s304><collect.erheben><en> In addition, we will also collect personal information from you when you correspond with us (for example, if you contact us with a query about one of our products or services), when you provide your details when you visit a Vacheron Constantin boutique or contact the Vacheron Constantin concierge by telephone.
<G-vec00169-001-s304><collect.erheben><de> Wir können außerdem personenbezogene Daten über Sie erheben, wenn Sie mit uns kommunizieren (etwa, wenn Sie sich mit einer Rückfrage zu einem unserer Produkte oder einer unserer Dienstleistungen an uns wenden), wenn Sie anlässlich eines Besuchs einer Vacheron Constantin-Boutique Ihre Kontaktangaben hinterlassen, oder wenn Sie die Vacheron Constantin-Rezeption telefonisch kontaktieren.
<G-vec00169-001-s305><collect.erheben><en> Collection and processing when using the contact form When you use the contact form we will only collect your personal data (name, email address, message text) in the scope provided by you.
<G-vec00169-001-s305><collect.erheben><de> Kontakt Bewertungen Newsletter Erhebung und Verarbeitung bei Nutzung des Kontaktformulars Bei der Nutzung des Kontaktformulars erheben wir Ihre personenbezogenen Daten (Name, E-Mail-Adresse, Nachrichtentext) nur in dem von Ihnen zur Verfügung gestellten Umfang.
<G-vec00169-001-s306><collect.erheben><en> Furthermore, we collect personal data during the use of our website.
<G-vec00169-001-s306><collect.erheben><de> Darüber hinaus erheben wir personenbezogene Daten bei der Nutzung ihrer Website.
<G-vec00169-001-s307><collect.erheben><en> Unbounce cookies will be used to collect non-personal data that will be used to improve the landing pages and provide a better experience.
<G-vec00169-001-s307><collect.erheben><de> Unbounce-Cookies werden verwendet, um nicht personenbezogene Daten zu erheben, die verwendet werden, um die Landing-Seiten zu verbessern und ein besseres Erlebnis anzubieten.
<G-vec00169-001-s308><collect.erheben><en> (1) When you use the website for merely informational purposes, meaning if you do not register or otherwise transmit information to us, we only collect the personal data that your browser transmits to our server.
<G-vec00169-001-s308><collect.erheben><de> (1) Bei der bloß informatorischen Nutzung der Website, also wenn Sie sich nicht registrieren oder uns anderweitig Informationen übermitteln, erheben wir nur die personenbezogenen Daten, die Ihr Browser an unseren Server übermittelt.
<G-vec00169-001-s309><collect.erheben><en> The third-party partner or the web analytical service partner may be able with your consent to collect data about your visit to our and other sites because of these internet tags/cookies, may compose reports regarding the website’s activity for us and may provide further services which are related to the use of the website and the internet.
<G-vec00169-001-s309><collect.erheben><de> Mit Ihrer Einwilligung sind diese dritten Partner oder Webanalysedienste berechtigt, Daten zu Ihrem Besuch unserer und anderer Websites anhand dieser Internet-Tags/Cookies zu erheben, für uns Berichte zu den Aktivitäten auf der Website zu erstellen und weitere Dienstleistungen im Zusammenhang mit der Nutzung der Website und des Internets zu erbringen.
<G-vec00169-001-s310><collect.erheben><en> Processing data (customer and contract data) We collect, process and use personal data only insofar as they are necessary for the establishment, content or modification of the legal relationship (inventory data).
<G-vec00169-001-s310><collect.erheben><de> Verarbeiten von Daten (Kunden- und Vertragsdaten) Wir erheben, verarbeiten und nutzen personenbezogene Daten nur, soweit sie für die Begründung, inhaltliche Ausgestaltung oder Änderung des Rechtsverhältnisses erforderlich sind (Bestandsdaten).
<G-vec00169-001-s311><collect.erheben><en> This list is not exhaustive and, in specific instances, we may need to collect additional data for the purposes set out in this Policy.
<G-vec00169-001-s311><collect.erheben><de> Diese Liste ist nicht erschöpfend, und in bestimmten Fällen müssen wir möglicherweise zusätzliche Daten für die in dieser Richtlinie genannten Zwecke erheben.
<G-vec00169-001-s312><collect.erheben><en> If a contractual relationship is established between you and us or the content of a contractual relationship is developed or amended, we will collect and use personal information about you to the extent necessary for those purposes.
<G-vec00169-001-s312><collect.erheben><de> Sofern zwischen Ihnen und uns ein Vertragsverhältnis begründet, inhaltlich ausgestaltet oder geändert werden soll, erheben und verwenden wir personenbezogene Daten von Ihnen, soweit dies zu diesen Zwecken erforderlich ist.
<G-vec00169-001-s313><collect.erheben><en> We also collect data about you through cookies.
<G-vec00169-001-s313><collect.erheben><de> Darüber hinaus erheben wir Daten auch mithilfe von Cookies.
<G-vec00169-001-s314><collect.erheben><en> Whenever you call up and use our website, we collect the personal data automatically. Your browser then transmits this to our server.
<G-vec00169-001-s314><collect.erheben><de> Beim Aufrufen und der Nutzung unserer Website erheben wir die personenbezogenen Daten, die dein Browser automatisch an unseren Server übermittelt.
<G-vec00169-001-s315><collect.erheben><en> If you are a visitor from the EEA, the legal basis for the collection and use of the above-mentioned personal data depends on the personal data involved and the specific context in which we collect them.
<G-vec00169-001-s315><collect.erheben><de> Wenn Sie ein Besucher aus dem EWR sind, hängt die Rechtsgrundlage für die Erhebung und Nutzung der oben angegebenen personenbezogenen Daten von den betroffenen personenbezogenen Daten und dem spezifischen Kontext, in dem wir sie erheben, ab.
<G-vec00169-001-s316><collect.erheben><en> Without the explicit consent of the ordering party, alfer® will not collect, save, transfer or use the data of the ordering party for the purposes of advertising, market or opinion research.
<G-vec00169-001-s316><collect.erheben><de> Ohne die ausdrückliche Einwilligung des Bestellers wird alfer® Daten des Bestellers nicht für Zwecke der Werbung, Markt- oder Meinungsforschung erheben, speichern, übermitteln oder nutzen.
<G-vec00169-001-s317><collect.erheben><en> We therefore only collect and use personal data if this is permitted by law (Art.
<G-vec00169-001-s317><collect.erheben><de> Daher erheben und nutzen wir personenbezogene Daten nur dann, wenn uns dies gesetzlich erlaub ist (Art.
<G-vec00169-001-s318><collect.erheben><en> We are committed to protecting the information we collect.
<G-vec00169-001-s318><collect.erheben><de> Wir verpflichten uns zum Schutz der Daten, die wir erheben.
<G-vec00169-001-s319><collect.erheben><en> Special and / or sensitive personal data that we process Our website and / or service does not intend to collect data about website visitors who are younger than 16 years.
<G-vec00169-001-s319><collect.erheben><de> Besondere und/oder sensible personenbezogene Daten, die wir verarbeiten Unsere Website und/oder unsere Dienstleistung hat nicht die Absicht, Daten von Website-Besuchern zu erheben, die jünger als 16 Jahre sind.
<G-vec00169-001-s320><collect.erheben><en> We do not collect personal data on the use of our web pages (usage data).
<G-vec00169-001-s320><collect.erheben><de> Personenbezogene Daten über die Inanspruchnahme unserer Internetseiten (Nutzungsdaten) erheben wir nicht.
<G-vec00169-001-s321><collect.erheben><en> We only ever collect and process your personal data to the extent that this is necessary to fulfil our tasks.
<G-vec00169-001-s321><collect.erheben><de> Wir erheben und verarbeiten Ihre personenbezogenen Daten grundsätzlich nur, soweit dies zur ErfÃ1⁄4llung unserer Aufgaben erforderlich ist.
<G-vec00169-001-s322><collect.erheben><en> We use the information we collect about you and your domain name, payment method to process registrations only.
<G-vec00169-001-s322><collect.erheben><de> Wir verwenden die Daten, die wir über Sie und Ihren Domain-Namen und Ihre Zahlungsweise erheben, nur zur Verarbeitung von Registrierungen.
<G-vec00169-001-s323><collect.erheben><en> This website does not collect, use or process personal data.
<G-vec00169-001-s323><collect.erheben><de> Diese Website erhebt, verwendet und verarbeitet keine personenbezogenen Daten.
<G-vec00169-001-s324><collect.erheben><en> In this case, a so-called opt-out cookie will be stored in your browser, with the result that Matomo does not collect any session data at all.
<G-vec00169-001-s324><collect.erheben><de> In diesem Fall wird in Ihrem Browser ein sogenannter Opt-Out-Cookie abgelegt, was zur Folge hat, dass Matomo keinerlei Sitzungsdaten erhebt.
<G-vec00169-001-s325><collect.erheben><en> The Group of the Progressive Alliance of Socialists & Democrats in the European Parliament will collect personal information only to the extent necessary to fulfil a precise purpose specified by the data controller for each online service.
<G-vec00169-001-s325><collect.erheben><de> Das Fraktion der Progressiven Allianz der Sozialdemokraten im Europäischen Parlament erhebt personenbezogene Informationen nur, soweit dies zur Erreichung eines bestimmten Zwecks erforderlich ist, den der für die Verarbeitung Verantwortliche für jeden Online-Dienst festlegt.
<G-vec00169-001-s326><collect.erheben><en> The provider of the pages can automatically collect and store the following information in so-called server log files, which your browser automatically transmits to us.
<G-vec00169-001-s326><collect.erheben><de> Server-Log-Dateien Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, die Ihr Browser automatisch an uns übermittelt.
<G-vec00169-001-s327><collect.erheben><en> The Mathison after the disappointment of Saul, must collect the about-face by Jonas.
<G-vec00169-001-s327><collect.erheben><de> Die Mathison nach der Enttäuschung von Saul, erhebt die Kehrtwendung von Jonas.
<G-vec00169-001-s328><collect.erheben><en> If you don’t want Google to collect, process or use, through our website, any data relating to you, you can disable JavaScript in your browser settings.
<G-vec00169-001-s328><collect.erheben><de> Wenn Sie nicht möchten, dass Google über unsere Website Daten über Sie erhebt, verarbeitet oder nutzt, können Sie in Ihrem Browsereinstellungen JavaScript deaktivieren.
<G-vec00169-001-s329><collect.erheben><en> Steinigke Showtechnic GmbH does not collect data while you are installing our applications. No registration required.
<G-vec00169-001-s329><collect.erheben><de> Die Steinigke Showtechnic GmbH erhebt bei der Installation von Applikationen keine Daten; eine Anmeldung ist nicht erforderlich.
<G-vec00169-001-s330><collect.erheben><en> Google will transfer information received in the context of the use of the service to third parties insofar as this is required by law or insofar as third parties collect data received for Google on their behalf.
<G-vec00169-001-s330><collect.erheben><de> Google wird im Rahmen der Nutzung des Dienstes erhaltene Informationen an Dritte übertragen, soweit dies aufgrund einer gesetzlichen Vorschrift erforderlich ist oder soweit Dritte erhaltene Daten für Google in deren Auftrag erhebt.
<G-vec00169-001-s331><collect.erheben><en> Castrol does not knowingly collect information from children under the age of 13 and Castrol does not target its websites to children under 13.
<G-vec00169-001-s331><collect.erheben><de> Castrol erhebt keine Daten von Kindern unter 13 Jahren und die Webseite ist auch nicht auf Kinder unter 13 Jahren ausgerichtet.
<G-vec00169-001-s332><collect.erheben><en> Non identifiable information – Tropical Paradise will from time to time collect information from you that does not reveal your personal identity.
<G-vec00169-001-s332><collect.erheben><de> Nicht personenbezogene Daten – Tropical Paradise erhebt von Zeit zu Zeit Daten von Ihnen, die Ihre persönliche Identität nicht preisgeben.
<G-vec00169-001-s333><collect.erheben><en> We automatically collect and store in our server log files information that your browser sends to us.
<G-vec00169-001-s333><collect.erheben><de> Die fortytools gmbh erhebt und speichert automatisch in ihren Server Log Files Informationen, die Ihr Browser an uns übermittelt.
<G-vec00169-001-s334><collect.erheben><en> According to Google itself, it does not collect any personal data during this process.
<G-vec00169-001-s334><collect.erheben><de> Nach eigenen Angaben erhebt Google bei diesem Vorgang keine personenbezogenen Daten.
<G-vec00169-001-s335><collect.erheben><en> "Information collection and use UEFA does not collect personal identifying information when you access the Website homepage and browse the Website without disclosing your personal data except as described in this Privacy Policy or the relevant part of the Website and except cookies (see below under ""cookies"").UEFA collects personal identifying information when you register on the Website, when you use certain products or services on the Website and when you enter promotions, sweepstakes or similar services sponsored by UEFA or its business partners."
<G-vec00169-001-s335><collect.erheben><de> "Datenerhebung und -verwendung Die UEFA erhebt keine persönlichen Kenndaten, wenn Sie die Homepage oder weitere Seiten der Website öffnen, ohne persönliche Daten einzugeben, abgesehen von den in dieser Datenschutzpolitik oder dem entsprechenden Teil der Website beschriebenen Ausnahmen sowie Cookies (siehe unten unter ""Cookies"").Die UEFA erhebt persönliche Kenndaten, wenn Sie sich auf der Website registrieren, wenn Sie bestimmte Produkte oder Dienstleistungen der Website in Anspruch nehmen oder wenn Sie Promotion, Gewinnspiele oder ähnliche Angebote nutzen, die von der UEFA oder ihren Geschäftspartnern gesponsert werden."
<G-vec00169-001-s336><collect.erheben><en> No collection of personal data from children Schindler does not knowingly collect information from children.
<G-vec00169-001-s336><collect.erheben><de> Keine Erhebung von personenbezogenen Daten von Kindern Schindler erhebt nicht wissentlich Daten von Kindern.
<G-vec00169-001-s337><collect.erheben><en> Once you visit a page of our websites that contains Google Maps, Google will collect, process and use information about your use of that feature, such as the date and time of your visit, your IP address and the address you enter using the directions function.
<G-vec00169-001-s337><collect.erheben><de> Sobald Sie Seiten auf unseren Webseiten aufrufen, die Google Maps enthalten, so erhebt, verarbeitet und nutzt Google die mit Ihrer Nutzung dieses Features in Verbindung stehenden Informationen, das Datum und die Uhrzeit ihres Zugriffes, sowie Ihre IP-Adresse und die von Ihnen bei der Routenplanung eingegebene Adresse.
<G-vec00169-001-s338><collect.erheben><en> If you do not want Google to collect, process, or use data about you through our online presence, you can deactivate JavaScript in your browser settings.
<G-vec00169-001-s338><collect.erheben><de> Wenn Sie nicht möchten, dass Google über unseren Internetauftritt Daten über Sie erhebt, verarbeitet oder nutzt, können Sie in Ihrem Browsereinstellungen JavaScript deaktivieren.
<G-vec00169-001-s339><collect.erheben><en> G2A.COM shall collect its commission from each sale price of a given product specified by the Seller or the Selling User.
<G-vec00169-001-s339><collect.erheben><de> G2A.COM erhebt eine Provision auf den Verkaufspreis aller Produkte, die der Käufer oder verkaufende Benutzer festlegt.
<G-vec00169-001-s340><collect.erheben><en> GOODSYNC CONNECT DATA: Customers who enabled GoodSync Connect on their computers hereby agree that Siber shall collect data needed for arranging TCP/IP or UDP connection between Customer's computers where GoodSync Connect is enabled.
<G-vec00169-001-s340><collect.erheben><de> GOODSYNC CONNECT DATEN: Kunden, die GoodSync Connect auf ihren Computern aktiviert haben bestätigen hiermit, dass Siber die für die Vermittlung erforderlichen Daten für die TCP / IP- oder UDP-Verbindung zwischen den Computern des Kunden auf denen GoodSync Connect aktiviert ist erhebt.
<G-vec00169-001-s341><collect.erheben><en> In this case, an opt-out cookie is stored in your browser and Matomo does not collect any session data.
<G-vec00169-001-s341><collect.erheben><de> In diesem Fall wird in Ihrem Browser ein Opt-Out-Cookie abgelegt und Matomo erhebt keinerlei Sitzungsdaten.
<G-vec00169-001-s361><collect.erheben><en> Should you access other websites using the links provided, the operators of said website may collect your personal information.
<G-vec00169-001-s361><collect.erheben><de> Beim Zugriff auf solche Websites über die hier angebotenen Verknüpfungen werden von den Betreibern dieser Seiten möglicherweise personenbezogene Daten über Sie erhoben.
<G-vec00169-001-s362><collect.erheben><en> If you access other websites using the links provided, the operators of these websites may collect information from you which will be used by them in accordance with their privacy policy, which may differ from ours.
<G-vec00169-001-s362><collect.erheben><de> Beim Aufruf anderer Websites über die angegebenen Links können von den Betreibern der jeweiligen Websites gegebenenfalls Daten über Sie erhoben werden, die von den Betreibern dann gemäß ihrer jeweiligen Datenschutzrichtlinie in einer Art und Weise verwendet werden können, die von unserer Richtlinie abweichen kann.
<G-vec00169-001-s363><collect.erheben><en> DS SolidWorks does not exercise any control over the content of third party websites or the practices of these third parties in connection with the protection of Personal Data that they might collect and are thus not in the control of DS SolidWorks.
<G-vec00169-001-s363><collect.erheben><de> DS SolidWorks hat keinerlei Einfluss auf den Inhalt der Websites Dritter oder auf deren Vorkehrungen zum Schutz der personenbezogenen Daten, die von ihnen möglicherweise erhoben werden und sich somit dem Einfluss von DS SolidWorks entziehen.
<G-vec00169-001-s364><collect.erheben><en> The above cookies are used to collect anonymized data that make it possible to analyze the use of our website.
<G-vec00169-001-s364><collect.erheben><de> Mit Hilfe vorstehend genannter Cookies werden anonymisierte Daten erhoben, die eine Analyse der Benutzung unserer Webseite ermöglichen.
<G-vec00169-001-s365><collect.erheben><en> The Internet site does not collect any information from the private sphere of the user.
<G-vec00169-001-s365><collect.erheben><de> Es werden keine Daten aus dem privaten Bereich der Benutzer von der Internetseite erhoben.
<G-vec00169-001-s366><collect.erheben><en> Generally, we do not collect any personally identifying information when you visit our Website.
<G-vec00169-001-s366><collect.erheben><de> In der Regel werden keine personenbezogenen Daten von Ihnen erhoben, wenn Sie die Internetseite der ec4u expert consulting ag besuchen.
<G-vec00169-001-s367><collect.erheben><en> This website uses Wiredminds to collect and process anonymized data to analyze and continuously optimize our website.
<G-vec00169-001-s367><collect.erheben><de> Auf dieser Website werden mittels Wiredminds Daten in anonymisierter Form zur kontinuierlichen Optimierung und zur Analyse unseres Webangebotes erhoben und weiterverarbeitet.
<G-vec00169-001-s368><collect.erheben><en> Please note that there may be other uses, which we would describe to you when we collect the information.
<G-vec00169-001-s368><collect.erheben><de> Bitte beachten Sie, dass es darüber hinaus weitere Verwendungen geben kann, die Ihnen beschrieben werden, wenn die Informationen erhoben werden.
<G-vec00169-001-s369><collect.erheben><en> If we did not collect this data directly from the respective data subject, we may also collect contact data about the data subject from publicly available sources, in particular the website of the respective company, classified directories, or advertisements of the respective business.
<G-vec00169-001-s369><collect.erheben><de> Soweit wir diese Daten nicht direkt vom jeweiligen Betroffenen erhoben haben, können wir Kontaktdaten des Betroffenen auch aus öffentlichen Quellen entnehmen, wie insbesondere der Webseite des jeweiligen Unternehmens, Branchenverzeichnissen oder vom Unternehmen geschalteten Stellenanzeigen.
<G-vec00169-001-s370><collect.erheben><en> If you get in contact with us (e.g. via contact form or e-mail) we will collect personal data.
<G-vec00169-001-s370><collect.erheben><de> Im Rahmen Ihrer Kontaktaufnahme mit uns (beispielsweise per Kontaktformular oder E-Mail) werden personenbezogene Daten erhoben.
<G-vec00169-001-s371><collect.erheben><en> We may also evaluate information about bookings and behaviour on our premises and on-line booking platforms and link this to other personal information, such as non-personal statistics and other personal data we collect about you.
<G-vec00169-001-s371><collect.erheben><de> Wir können Angaben über Buchungen und das Verhalten in unseren Räumlichkeiten und Online-Buchungsplattformen auch auswerten und mit anderen Personendaten verknüpfen, zum Beispiel mit nicht personenbezogenen statistischen Angaben und mit anderen Personendaten, die wir über Sie erhoben haben.
<G-vec00169-001-s372><collect.erheben><en> So we will not collect personal data, i.e. information with the help of which a natural person could be directly identified or which enables the identification.
<G-vec00169-001-s372><collect.erheben><de> Personenbezogene Daten, d.h. Angaben, mittels derer eine natürliche Person unmittelbar identifiziert werden kann oder die deren Identifikation ermöglichen, werden nicht erhoben.
<G-vec00169-001-s373><collect.erheben><en> Generally speaking, we will not collect or process personal data to this end.
<G-vec00169-001-s373><collect.erheben><de> Dabei werden in der Regel keine personenbezogenen Daten erhoben oder verarbeitet.
<G-vec00169-001-s374><collect.erheben><en> 4.1 When you contact us (via the contact form, by e-mail or by other means), we collect the information you give us, such as your first name, last name, e-mail address and subject, so we can process your enquiry.
<G-vec00169-001-s374><collect.erheben><de> 4.1 Bei der Kontaktaufnahme mit uns (per Kontaktformular, E-Mail oder auf sonstigem Wege) werden Ihre uns mitgeteilten Angaben wie Vorname, Nachname, E-Mail-Adresse, Betreff erhoben, damit wir Ihre Anfrage bearbeiten können.
<G-vec00169-001-s375><collect.erheben><en> Every day, scientists collect countless data about the state of our planet - whether from the atmosphere, ocean or land.
<G-vec00169-001-s375><collect.erheben><de> Jeden Tag werden von Wissenschaftlerinnen und Wissenschaftlern unzählige Daten über den Zustand unseres Planeten erhoben – ob aus Atmosphäre, Ozean oder von Land.
<G-vec00169-001-s376><collect.erheben><en> The following statement provides an overview of how we ensure this protection, and explains which types of data we collect for which purposes.
<G-vec00169-001-s376><collect.erheben><de> Die nachfolgende Erklärung gibt Ihnen einen Überblick darüber, wie wir diesen Schutz gewährleisten und welche Art von Daten zu welchem Zweck erhoben werden.
<G-vec00169-001-s377><collect.erheben><en> We collect personal data for technical requirements only.
<G-vec00169-001-s377><collect.erheben><de> Personenbezogene Daten werden auf dieser Webseite nur im technisch notwendigen Umfang erhoben.
<G-vec00169-001-s378><collect.erheben><en> However, by clicking on a XING link or XING button you as the data subject will be transferred to XING where XING will collect data.
<G-vec00169-001-s378><collect.erheben><de> Bei einem Klick auf einen XING-Link oder XING-Button gelangen Sie als betroffene Person jedoch zu XING und dort werden Daten durch XING erhoben.
<G-vec00169-001-s379><collect.erheben><en> unsubscribe I hereby grant my consent to allow CENIT AG to collect, process and use the personal data I have provided above for the purpose of informing me by e-mail or phone about CENIT AG software products, services, events and market information (based on the topics selected in advance).
<G-vec00169-001-s379><collect.erheben><de> Mit dem Absenden des Formulars erkläre ich mich einverstanden, dass meine oben angegebenen, persönlichen Daten von der CENIT AG sowie von Tochtergesellschaften der CENIT AG und deren Mehrheitsbeteiligungen zur Bearbeitung meines Anliegens erhoben, verarbeitet und genutzt werden dürfen.
<G-vec00169-001-s380><collect.erheben><en> We take precautions intended to help protect personal data that we collect and store.
<G-vec00169-001-s380><collect.erheben><de> Wir treffen Vorkehrungen, um die von uns erhobenen und gespeicherten personenbezogenen Daten zu schützen.
<G-vec00169-001-s381><collect.erheben><en> The data we collect can also be used for marketing purposes.
<G-vec00169-001-s381><collect.erheben><de> Internetmarketing Die von uns erhobenen Daten können auch zu Marketingzwecken genutzt werden.
<G-vec00169-001-s382><collect.erheben><en> This data protection policy is designed to inform our users about the contents and purposes of the personal data that we collect and process.
<G-vec00169-001-s382><collect.erheben><de> Mit dieser Datenschutzerklärung möchte unser Unternehmen die Besucher über Inhalt und Zweck der von uns erhobenen und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s383><collect.erheben><en> We will never use the data we collect to make inferences about your person.
<G-vec00169-001-s383><collect.erheben><de> In keinem Fall verwenden wir die erhobenen Daten zu dem Zweck, Rückschlüsse auf Ihre Person zu ziehen.
<G-vec00169-001-s384><collect.erheben><en> By means of this data protection declaration, our enterprise would like to inform the general public of the nature, scope, and purpose of the personal data we collect, use and process.
<G-vec00169-001-s384><collect.erheben><de> Mittels dieser DatenschutzerklÀrung möchte unser Unternehmen die Öffentlichkeit ĂŒber Art, Umfang und Zweck der von uns erhobenen, genutzten und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s385><collect.erheben><en> The data we collect when subscribing to our newsletter will only be used for advertising purposes via the newsletter.
<G-vec00169-001-s385><collect.erheben><de> Die von uns bei der Anmeldung zum Newsletter erhobenen Daten werden ausschließlich für Zwecke der werblichen Ansprache im Wege des Newsletters benutzt.
<G-vec00169-001-s386><collect.erheben><en> We use the information we collect from all of our services to provide, maintain, protect and improve them, to develop new ones, and to protect ANIMEGG and our users.
<G-vec00169-001-s386><collect.erheben><de> Wir nutzen die im Rahmen unserer Dienste erhobenen Daten zur Bereitstellung, zur Wartung, zum Schutz und zur Verbesserung unserer Dienste, zur Entwicklung neuer Dienste sowie zum Schutz von Google und unseren Nutzern .
<G-vec00169-001-s387><collect.erheben><en> By means of this data privacy policy, I would like to inform the general public of the nature, scope, and purpose of the personal data I collect, use and process.
<G-vec00169-001-s387><collect.erheben><de> Mittels dieser Datenschutzerklärung möchte ich die Öffentlichkeit über Art, Umfang und Zweck der von mir erhobenen, genutzten und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s388><collect.erheben><en> By means of this data protection declaration, our enterprise would like to inform the general public of the nature, scope, and purpose of the used cookies and the personal data we collect, use and process.
<G-vec00169-001-s388><collect.erheben><de> Mittels dieser Datenschutzerklärung möchte Valais/Wallis Promotion die Benutzer der Website www.wallis.ch über Art, Umfang und Zweck der von uns eingesetzten Cookies und die dabei erhobenen, genutzten und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s389><collect.erheben><en> Through this privacy policy, our company seeks to inform the public about the nature, scope and purpose of the personal information we collect, use and process.
<G-vec00169-001-s389><collect.erheben><de> Mittels dieser Datenschutzerklärung möchte unser Unternehmen die Öffentlichkeit über Art, Umfang und Zweck der von uns erhobenen, genutzten und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s390><collect.erheben><en> In addition to the data we collect, we also process contact data available on websites to the general public.
<G-vec00169-001-s390><collect.erheben><de> Wir verarbeiten neben den von uns erhobenen Daten auch auf Webseiten öffentlich einsehbare Kontaktdaten.
<G-vec00169-001-s391><collect.erheben><en> We retain the information we collect for as long as necessary to provide our Services, and we may retain that information beyond that period if necessary for legal, operational or other legitimate reasons.
<G-vec00169-001-s391><collect.erheben><de> Wir speichern die erhobenen Daten, solange dies für die Bereitstellung unserer Dienste erforderlich ist, und können diese Informationen auch über diesen Zeitraum hinaus speichern, wenn dies aus rechtlichen, betrieblichen oder anderen legitimen Gründen erforderlich ist.
<G-vec00169-001-s392><collect.erheben><en> Information that you give to us: Most of the personal data that we collect about you will be information that you have given to us yourself.
<G-vec00169-001-s392><collect.erheben><de> Informationen, die Sie uns geben: Die meisten von uns erhobenen personenbezogenen Daten sind Informationen, die Sie selbst uns gegeben haben.
<G-vec00169-001-s393><collect.erheben><en> 3.How We Share the Information We Collect and Receive .
<G-vec00169-001-s393><collect.erheben><de> 3.Wie wir die erhobenen und erhaltenen Informationen teilen .
<G-vec00169-001-s394><collect.erheben><en> We may also obtain information about you from other sources and link or combine that with information we collect on our websites.
<G-vec00169-001-s394><collect.erheben><de> Wir können auch Daten über Sie von anderen Quellen beziehen, und diese mit den auf unseren Websites erhobenen Daten verknüpfen oder kombinieren.
<G-vec00169-001-s395><collect.erheben><en> As a developer you can inform end-users about data you collect through a privacy policy, cookie banner and/ or preferences page on a Sitecore XP 8.x website, but you have no way of auditing a history of interactions.
<G-vec00169-001-s395><collect.erheben><de> Als Entwickler können Sie Endnutzer über die von Ihnen erhobenen Daten mit Datenschutzrichtlinien, einem Cookie-Banner und/oder einer Seite für Einstellungen auf einer Sitecore 8.x Website informieren, aber Sie haben keine Möglichkeit, den Interaktionsverlauf zu überprüfen.
<G-vec00169-001-s396><collect.erheben><en> By means of this data protection declaration, we would like to inform the public about the type, scope and purpose of the personal data we collect, use and process.
<G-vec00169-001-s396><collect.erheben><de> Mittels dieser Datenschutzerklärung möchte wir die Öffentlichkeit über Art, Umfang und Zweck der von uns erhobenen, genutzten und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s397><collect.erheben><en> Should counting pixels in the newsletter collect personal data, these will be stored by the Responsible Party responsible for processing and assessed in order to optimise newsletter sending, and to adapt the contents in future newsletters better to the interest of the impacted person.
<G-vec00169-001-s397><collect.erheben><de> Solche über die in den Newslettern enthaltenen Zählpixel erhobenen personenbezogenen Daten, werden von dem für die Verarbeitung Verantwortlichen gespeichert und ausgewertet, um den Newsletterversand zu optimieren und den Inhalt zukünftiger werblichen E-Mails noch besser den Interessen der betroffenen Person anzupassen.
<G-vec00169-001-s398><collect.erheben><en> Our company would like to use this privacy policy to inform the public about the nature, extent and purpose of the personal data we collect, use and process.
<G-vec00169-001-s398><collect.erheben><de> Mittels dieser Datenschutzerklärung möchte unser Unternehmen die Öffentlichkeit über Art, Umfang und Zweck der von uns erhobenen, genutzten und verarbeiteten personenbezogenen Daten informieren.
<G-vec00169-001-s399><collect.sammeln><en> Advertising cookies for online behaviour – These cookies collect information about your browser behaviour and preferences for products and services.
<G-vec00169-001-s399><collect.sammeln><de> Anzeigen-Cookies für Online-Verhalten – Mit diesen Cookies werden Informationen und Präferenzen für Produkte und Dienstleistungen gesammelt.
<G-vec00169-001-s400><collect.sammeln><en> We collect content data, metadata, transaction data, behavioral data, health data, financial data, measurement results and monitoring data.
<G-vec00169-001-s400><collect.sammeln><de> Gesammelt werden inhaltliche Daten, Metadaten, Transaktionsdaten, Verhaltensdaten, Gesundheitsdaten, Finanzdaten, Messergebnisse und Überwachungsdaten.
<G-vec00169-001-s401><collect.sammeln><en> The reels of the slot where the Crazy Slots symbols have landed will be spun and you will collect points.
<G-vec00169-001-s401><collect.sammeln><de> Die Walzen jenes Slots, in dem die Crazy-Slots-Symbole gefallen sind, werden gedreht und dadurch Punkte gesammelt.
<G-vec00169-001-s402><collect.sammeln><en> For this reason many ski resorts collect and store water in reservoirs during the summer.
<G-vec00169-001-s402><collect.sammeln><de> Daher behelfen sich viele Skigebiete mit Speicherseen, in denen während des Sommers Wasser gesammelt wird.
<G-vec00169-001-s403><collect.sammeln><en> Among other things, ABB AbilityTM Connected Services will be used to collect and analyze information about the condition and performance of robots in the factory, to help detect any potential faults early and avoid costly failures.
<G-vec00169-001-s403><collect.sammeln><de> Unter anderem werden mit den ABB AbilityTM Connected Services Informationen über den Zustand und die Leistung von Robotern in der Fabrik gesammelt und analysiert, um potenzielle Störungen frühzeitig erkennen und kostenintensive Betriebsausfälle vermeiden zu können.
<G-vec00169-001-s404><collect.sammeln><en> You can also collect the selected combinations and dimensions on a separate sheet for printing.
<G-vec00169-001-s404><collect.sammeln><de> Die ausgewählten Kombinationen und Abmessungen können auf einem separaten Blatt gesammelt und ausgedruckt werden.
<G-vec00169-001-s405><collect.sammeln><en> European legislation requires all sites that use cookies to ensure that you are well informed about this and that you give your express permission to collect and store information collected through the use of cookies.
<G-vec00169-001-s405><collect.sammeln><de> Die europäische Gesetzgebung verlangt von allen Website-Betreibern, die Cookies verwenden, Sie umfassend zu informieren und Sie um Ihre ausdrückliche Zustimmung zu bitten, bevor Informationen durch die Verwendung von Cookies gesammelt oder gespeichert werden.
<G-vec00169-001-s406><collect.sammeln><en> When ESMC runs a Server Scan client task, it will collect the list of targets and you will be asked to select scan targets for On-demand mailbox database scan on that particular server.
<G-vec00169-001-s406><collect.sammeln><de> Wenn ESMC einen Client-Task Server-Scan ausführt, wird die Liste der Ziele gesammelt, und Sie werden aufgefordert, Prüfziele für die On-Demand-Datenbankprüfung auf dem entsprechenden Server auszuwählen.
<G-vec00169-001-s407><collect.sammeln><en> If an interaction service with social networks is installed, it is possible that, even if the Users do not use the service, the same collect traffic data relating to the pages in which it is installed.
<G-vec00169-001-s407><collect.sammeln><de> Im Falle, dass ein Interaktionsdienst mit den sozialen Netzwerken eingebaut wird, ist es möglich, auch wenn der User diesen Dienst nicht nutzen sollte, dass die Nutzungsdaten trotzdem bezüglich der Seiten, auf denen dieser eingerichtet ist, gesammelt werden.
<G-vec00169-001-s408><collect.sammeln><en> The exhibition is part of a campaign to collect funds to open a Centre for Education and Culture for some 80,000 people, most of them children, in desperate living conditions.
<G-vec00169-001-s408><collect.sammeln><de> Diese Ausstellung ist Teil einer Solidaritätsaktion, in deren Rahmen finanzielle Mittel für den Bau eines Kultur- und Bildungszentrums für 80.000 Menschen, davon über die Hälfte Kinder und Jugendliche, gesammelt werden sollen.
<G-vec00169-001-s409><collect.sammeln><en> Marketers may find that their campaign actions shift based on what data they can collect and extrapolate from Safari users, rather than focusing on what they can’t have.
<G-vec00169-001-s409><collect.sammeln><de> Vermarkter stellen vielleicht schon bald fest, dass sie ihre Werbestrategie darauf ausrichten müssen, welche Daten von Safari-Nutzern gesammelt werden können und sollten sich nicht zu sehr auf die Einschränkungen konzentrieren.
<G-vec00169-001-s410><collect.sammeln><en> At a meeting that is held to collect some money for the fatally ill director, Dong-soo meets the actress again.
<G-vec00169-001-s410><collect.sammeln><de> Bei einem Treffen, bei dem Geld für den todkranken Regisseur gesammelt wird, trifft Dong-soo die Schauspielerin erneut.
<G-vec00169-001-s411><collect.sammeln><en> This collection is perhaps the first of its kind, the first to collect all of Roy's best 'rockin'' material from the different periods in his career—from the early days at Sun Records and at the Norman Petty studios, to the short-lived days as an RCA Victor artist in the late 50s, and the few but fertile rockers that Roy cut in his golden days for Monument Records in the early 1960s.
<G-vec00169-001-s411><collect.sammeln><de> Diese Sammlung ist vielleicht die erste ihrer Art, die das beste Rockmaterial von Roy aus den verschiedenen Epochen seiner Karriere gesammelt hat - von den Anfängen bei Sun Records und in den Norman Petty Studios bis zu den kurzlebigen Tagen als RCA Victor Künstler in den späten 50ern und den wenigen, aber fruchtbaren Rockern, die Roy in seinen goldenen Tagen für Monument Records in den frühen 60ern geschnitten hat.
<G-vec00169-001-s412><collect.sammeln><en> All information these cookies collect is aggregated and therefore anonymous.
<G-vec00169-001-s412><collect.sammeln><de> Alle Daten, die von diesen Cookies gesammelt werden, werden aggregiert zusammengefasst und sind deshalb anonym.
<G-vec00169-001-s413><collect.sammeln><en> After collect the luggage, pass through the sliding glass door.
<G-vec00169-001-s413><collect.sammeln><de> Nachdem Sie das Gepäck gesammelt haben, gehen Sie durch die Glasschiebetür.
<G-vec00169-001-s414><collect.sammeln><en> "Plus, you can collect ""I Was There"" stamps at selected Linz09 events to earn additional rewards."
<G-vec00169-001-s414><collect.sammeln><de> "Bei ausgewählten Veranstaltungen können zudem ""Ich-war-da""-Stempel gesammelt werden, die weitere Belohnungen bringen."
<G-vec00169-001-s415><collect.sammeln><en> Subsequent to the workcamp, each participating organization will have a wrap-up meeting to formulate impressions, experiences, and results and collect them in protocols, which then will be submitted to each other.
<G-vec00169-001-s415><collect.sammeln><de> Jede Organisation der teilnehmenden Länder wird im Anschluss ein Nachbereitungstreffen haben, in dem in Protokollform die Eindrücke, Erfahrungen und Ergebnisse beschrieben und gesammelt werden.
<G-vec00169-001-s416><collect.sammeln><en> Potential sites are located in the vicinity of the TenneT substations in Diele and Conneforde, which primarily collect and distribute offshore wind energy from the North Sea.
<G-vec00169-001-s416><collect.sammeln><de> In Betracht kommen Standorte im Bereich der TenneT-Umspannwerke Diele und Conneforde, in denen vor allem Offshore-Windstrom aus der Nordsee gesammelt und weiterverteilt wird.
<G-vec00169-001-s417><collect.sammeln><en> ● Facebook Pixel is used to collect information about the effect of advertising and visitors’ behaviour on the website.
<G-vec00169-001-s417><collect.sammeln><de> Mit dem Facebook Pixel werden Informationen über den Einfluss der Werbung und die Nutzungsverhalten der Besucher gesammelt.
<G-vec00169-001-s418><collect.sammeln><en> If you do not want Facebook to associate the information we collect about you on our websites with your Facebook account, you must log out before visiting our websites on Facebook.
<G-vec00169-001-s418><collect.sammeln><de> Wenn Sie nicht möchten, dass Facebook die über unsere Websites über Sie gesammelten Daten Ihrem Facebook-Konto zuordnet, müssen Sie sich vor Ihrem Besuch unserer Websites bei Facebook ausloggen.
<G-vec00169-001-s419><collect.sammeln><en> If you link your account from a third-party site or service, we may collect information from those third-party accounts, and any information that we collect will be governed by this Privacy Policy.
<G-vec00169-001-s419><collect.sammeln><de> Bei der Verlinkung Ihres Kontos mit einer Website oder einem Dienst eines Drittanbieters können wir Informationen von solchen Konten Dritter sammeln, wobei alle von uns gesammelten Informationen unter diese Datenschutzrichtlinie fallen.
<G-vec00169-001-s420><collect.sammeln><en> Like all other types of spyware, banker Trojans are built with a backdoor, allowing them to send all the data they collect to a remote server.
<G-vec00169-001-s420><collect.sammeln><de> Wie alle anderen Arten von Spyware verfügen Banker-Trojaner über eine Hintertür, über die sie alle gesammelten Daten an einen Remote-Server senden können.
<G-vec00169-001-s421><collect.sammeln><en> No, there is no limit; if you collect enough vouchers, you can enjoy your holiday for free.
<G-vec00169-001-s421><collect.sammeln><de> Nein, falls Sie genug der gesammelten Gutscheine haben, können Sie den Urlaub sogar ganz gratis haben.
<G-vec00169-001-s422><collect.sammeln><en> In order to prevent unauthorised access or disclosure we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online. Â
<G-vec00169-001-s422><collect.sammeln><de> Um den unerlaubten Zugriff oder die Offenlegung zu verhindern, haben wir geeignete technische, elektronische und innerbetriebliche Prozesse zum Schutz und zur Sicherheit der von uns online gesammelten Informationen eingerichtet.
<G-vec00169-001-s423><collect.sammeln><en> Most of the data we collect is anonymous, but some of our Clients may direct us to ask for your contact information, which is Personal Data.
<G-vec00169-001-s423><collect.sammeln><de> Die meisten der von uns gesammelten Daten sind anonym, aber einige unserer Kunden können uns auffordern, Ihre Kontaktinformationen, d. h. personenbezogene Daten, zu erfragen.
<G-vec00169-001-s424><collect.sammeln><en> We may derive other information from the information we collect, such as your general location from your IP address.
<G-vec00169-001-s424><collect.sammeln><de> Wir leiten eventuell weitere Informationen von den von uns gesammelten Informationen ab, wie beispielsweise Ihren generellen Standort von Ihrer IP-Adresse.
<G-vec00169-001-s425><collect.sammeln><en> As a consequence, a considerable part of the data we collect comes in the shape of visual material, and multi-media libraries are rapidly filling up with images and video-footage.
<G-vec00169-001-s425><collect.sammeln><de> Infolgedessen kommt ein beträchtlicher Teil der von uns gesammelten Daten in Form visuellen Materials und Multimedia-Bibliotheken füllen sich rasant mit Bildern und Videobildern.
<G-vec00169-001-s426><collect.sammeln><en> We encourage you to periodically review this Privacy Policy to stay informed about how we are protecting the Personal Information we collect.
<G-vec00169-001-s426><collect.sammeln><de> Wir empfehlen Ihnen, diese Datenschutzrichtlinie regelmäßig zu prüfen, damit Sie fortlaufend darüber informiert sind, wie wir die von uns gesammelten personenbezogenen Daten schützen.
<G-vec00169-001-s427><collect.sammeln><en> The gems you collect on your way can be used to customize your avatar or to buy more lives.
<G-vec00169-001-s427><collect.sammeln><de> Die gesammelten Edelsteine kannst Du später dazu benutzen, um entweder Deinen Avatar zu verschönern oder ein paar Extra-Leben zu kaufen.
<G-vec00169-001-s428><collect.sammeln><en> What you may not know is that this can take a lot of time, especially if you don't know what to do with the information that you collect.
<G-vec00169-001-s428><collect.sammeln><de> Was Du vielleicht nicht weißt, ist, dass das viel Zeit in Anspruch nimmt – Besonders, wenn man nicht weiß, was man mit den gesammelten Daten anfangen soll.
<G-vec00169-001-s429><collect.sammeln><en> The natural food of bees is honey, which bees make from the nectar and honeydew they collect.
<G-vec00169-001-s429><collect.sammeln><de> Unterschiedliche Bienenfutter Honig Das natürliche Futter ist Honig, den die Bienen aus den gesammelten Rohstoffen Nektar und Honigtau bereiten.
<G-vec00169-001-s430><collect.sammeln><en> Consume every book, research, survey reports and you'll be amazed at the quality of information you'll collect.
<G-vec00169-001-s430><collect.sammeln><de> Verschlinge jedes Buch, jede Forschung und alle Umfrage-Ergebnisse und Du wirst von der Qualität Deiner gesammelten Informationen begeistert sein.
<G-vec00169-001-s432><collect.sammeln><en> Purpose: The personal data we collect allows us to process your job applications.
<G-vec00169-001-s432><collect.sammeln><de> Zweck: Die gesammelten personenbezogenen Daten ermöglichen uns die Bearbeitung Ihrer Bewerbung.
<G-vec00169-001-s433><collect.sammeln><en> We store information that we collect through log files to create a profile of our users (both users who book accommodation as well as users who register on our website).
<G-vec00169-001-s433><collect.sammeln><de> Wir speichern die gesammelten Informationen mithilfe von Log-Dateien, um ein Nutzerprofil zu erstellen (sowohl Nutzer, die eine Unterkunft buchen, als auch Nutzer, die sich auf unserer Website anmelden).
<G-vec00169-001-s434><collect.sammeln><en> Under the terms of the Order Data Agreement, which we have created as a website operator with Google Inc., the information we collect is used to compile an evaluation of website use and website activity, and to provide services related to internet usage.
<G-vec00169-001-s434><collect.sammeln><de> Im Rahmen der Vereinbarung zur Auftragsdatenvereinbarung, welche wir als Websitebetreiber mit der Google Inc. geschlossen haben, erstellt diese mithilfe der gesammelten Informationen eine Auswertung der Websitenutzung und der Websiteaktivität und erbringt mit der Internetnutzung verbundene Dienstleistungen.
<G-vec00169-001-s436><collect.sammeln><en> The information we collect is used only by AEK and the Aaron Group of Companies to notify customers about updates to our equipment inventory, or information regarding a request for quotation proposal and printed marketing literature.
<G-vec00169-001-s436><collect.sammeln><de> Die gesammelten Informationen werden nur von AEK und dem Aaron Group of Companies, die Kunden über Aktuelles zu unserer Ausrüstung Inventar, oder Informationen über eine Anfrage Vorschlag und gedruckten Marketing-Literatur benachrichtigen verwendet.
<G-vec00443-001-s201><collect.sammeln><en> No, there is no limit; if you collect enough vouchers, you can enjoy your holiday for free.
<G-vec00443-001-s201><collect.sammeln><de> Nein, falls Sie genug der gesammelten Gutscheine haben, können Sie den Urlaub sogar ganz gratis haben.
<G-vec00169-001-s437><collect.holen><en> Both, dressage specialists and experts in the show jumping course such as the two GLOCK Riders Hans Peter Minderhoud and Gerco Schröder were eager to collect important points for the FEI World Cup.
<G-vec00169-001-s437><collect.holen><de> Sowohl für die Dressurspezialisten als auch die Profis im Springparcours ging es im Rahmen der Equita Lyon um wichtige Punkte im FEI Weltcup und die wollten sich auch die beiden GLOCK Rider Hans Peter Minderhoud und Gerco Schröder holen.
<G-vec00169-001-s438><collect.holen><en> The player must collect a best score to ranking.
<G-vec00169-001-s438><collect.holen><de> Der Spieler muss ein bestes Ergebnis zum Ranking holen.
<G-vec00169-001-s439><collect.holen><en> The prominent East Coast casino apparently began an attempt to collect in the Garden State, only to find Ivey had zero assets there, leading to the motion to expand its search to Nevada.
<G-vec00169-001-s439><collect.holen><de> Das prominente East Coast Casino begann anscheinend einen Versuch, im Garden State das Geld zu holen, nur um festzustellen, dass Ivey dort keine Vermögenswerte hatte, was zu dem Antrag führte, die Suche auf Nevada auszuweiten.
<G-vec00169-001-s440><collect.holen><en> Then the Father gave permission for the groom to collect his (His) bride.
<G-vec00169-001-s440><collect.holen><de> Dann erteilte der Vater seine Zustimmung an den Bräutigam um seine (Seine) Braut zu holen.
<G-vec00169-001-s441><collect.holen><en> They walk through the store with their smartphone and collect information.
<G-vec00169-001-s441><collect.holen><de> Sie gehen mit ihrem Smartphone im Laden herum und holen sich die Informationen.
<G-vec00169-001-s442><collect.holen><en> We collect you from each hotel in the region of Sharm el Sheikh with our shuttle bus, take you to the Dive Centre and back to your hotel after your dive trip.
<G-vec00169-001-s442><collect.holen><de> Wir holen Euch mit unserem Shuttle Bus von allen anderen Hotels der Region Sharm el Sheikh ab, bringen Euch zur Marina und nach dem Tauchtag auch wieder zurück zu Eurem Hotel.
<G-vec00169-001-s443><collect.holen><en> You collect sacred idols, the scatter symbols, to win free spin games and seek out the Aztec King, the wild symbol, to turn any spin into a winning spin.
<G-vec00169-001-s443><collect.holen><de> Sie holen heilige Idole, die Streuungssymbole ab, um freie Drehungsspiele zu gewinnen und den aztekischen König, das wilde Symbol herauszufinden, um jede Drehung in eine Gewinnen-Drehung zu verwandeln.
<G-vec00169-001-s444><collect.holen><en> Just go to the Avis Preferred counter, collect your keys and go.
<G-vec00169-001-s444><collect.holen><de> Gehen Sie einfach zum Schalter von Avis Preferred, holen Sie die Schlüssel für Ihr Mietfahrzeug ab und los geht's.
<G-vec00169-001-s445><collect.holen><en> Order cash online and collect it from the branch of your choice.
<G-vec00169-001-s445><collect.holen><de> Bestellen Sie Bargeld online und holen Sie dieses in einer Filiale Ihrer Wahl ab.
<G-vec00169-001-s446><collect.holen><en> We will collect you and up to 3 passengers from your flight and transport you via Loch Ness and past Eilean Donan Castle to your accommodation in Lochalsh or South Skye.
<G-vec00169-001-s446><collect.holen><de> Wir holen Sie und bis zu 3 Passagiere von Ihrem Flug ab und bringen Sie über Loch Ness und vorbei an Eilean Donan Castle zu Ihrer Unterkunft in Lochalsh oder South Skye.
<G-vec00169-001-s447><collect.holen><en> To explore this intriguing destination, simply collect your Avis hire car from Figari Airport (at the southern end of the island) and start your journey across Corsica.
<G-vec00169-001-s447><collect.holen><de> Um das Meiste aus diesem traumhaften Reiseziel zu machen, holen Sie Ihren Avis Mietwagen direkt am Flughafen Figari ab (am südlichen Ende der Insel) und beginnen Sie Ihr ganz persönliches Abenteuer auf Korsika.
<G-vec00169-001-s448><collect.holen><en> If you decide to take a taxi, make sure you take it from the rank and either collect a coupon from the airport for a fixed price or ensure a meter is running.
<G-vec00169-001-s448><collect.holen><de> Wenn Sie sich entscheiden, ein Taxi zu nehmen, stellen Sie sicher, dass Sie es vom Taxistand nehmen und entweder einen Coupon vom Flughafen zu einem Festpreis holen oder sicherstellen, dass ein Taxameter läuft.
<G-vec00169-001-s449><collect.holen><en> Spongebob is going to travel to the moon, but he needs to collect oxygen there.
<G-vec00169-001-s449><collect.holen><de> SpongeBob wird zum Mond zu reisen, aber es muss zu holen Sauerstoff.
<G-vec00169-001-s450><collect.holen><en> The CardLink concept enables users to collect their new access rights without having to walk to the operator.
<G-vec00169-001-s450><collect.holen><de> Das CardLink-Konzept ermöglicht es den Nutzern, ihre neuen Zutrittsrechte zu holen, ohne zum Empfang gehen zu müssen.
<G-vec00169-001-s451><collect.holen><en> Guests can collect their favorite vegetables directly from the garden.
<G-vec00169-001-s451><collect.holen><de> Gäste können ihr Lieblingsgemüse direkt aus dem Garten holen.
<G-vec00169-001-s452><collect.holen><en> We collect all the required data from your server and update this when and as often as you wish.
<G-vec00169-001-s452><collect.holen><de> Wir holen alle erforderlichen Daten von Ihrem Server ab und aktualisieren diese Daten wann und wie oft Sie wollen.
<G-vec00169-001-s453><collect.holen><en> We will collect returns from your home, work or other address for free.
<G-vec00169-001-s453><collect.holen><de> Wir holen Rücksendungen kostenlos bei Ihnen Zuhause, an Ihrem Arbeitsplatz oder einer anderen Adresse ab.
<G-vec00169-001-s454><collect.holen><en> Collect your online orders in our Regent Street store
<G-vec00169-001-s454><collect.holen><de> Holen Sie Ihre Online-Bestellungen in unserem Regent Street Store ab.
<G-vec00169-001-s455><collect.holen><en> We would of course collect you from the station.
<G-vec00169-001-s455><collect.holen><de> Wir holen Sie natürlich gerne ab.
<G-vec00169-001-s456><collect.sammeln><en> Big Data basically refers to the fact that we can now collect and analyse data in ways that was impossible even a few years ago.
<G-vec00169-001-s456><collect.sammeln><de> Orientierungsworkshop Big Data Big Data bezieht sich darauf, dass wir heute Daten sammeln und verarbeiten können, die vor einigen Jahren unmöglich waren.
<G-vec00169-001-s457><collect.sammeln><en> Sk8park You only have a few seconds to collect the 4 orange skate wheels.
<G-vec00169-001-s457><collect.sammeln><de> sk8park Sie haben nur ein paar Sekunden, um die 4 orange-Skate-Rollen zu sammeln.
<G-vec00169-001-s458><collect.sammeln><en> The information these cookies collect may be anonymised.
<G-vec00169-001-s458><collect.sammeln><de> Die Informationen, die diese Cookies sammeln, sind anonym.
<G-vec00169-001-s459><collect.sammeln><en> The artist travelled for months on end in order to collect over 500 songs from every region of Argentina.
<G-vec00169-001-s459><collect.sammeln><de> Um über 500 Lieder aus allen Regionen Argentiniens zu sammeln, reiste sie mehrere Monate durch das Land.
<G-vec00169-001-s460><collect.sammeln><en> JMP allows Cree's production teams to visualize and communicate issues in the process, collect data on those issues, apply models, study the effects of interactions and demonstrate improvement.
<G-vec00169-001-s460><collect.sammeln><de> Lösung Mit JMP können die Produktionsteams von Cree Probleme innerhalb des Prozesses visualisieren und kommunizieren, Daten zu diesen Problemen sammeln, Modelle anwenden, die Auswirkungen von Interaktionen untersuchen und Verbesserungen nachweisen.
<G-vec00169-001-s461><collect.sammeln><en> We collect and archive data you provide us within our web portal, or otherwise.
<G-vec00169-001-s461><collect.sammeln><de> Wir sammeln und archivieren die Daten, die ihr uns innerhalb des web Portals oder andersweitig übermittelt.
<G-vec00169-001-s462><collect.sammeln><en> Collect money to boost your truck power.Try not to get your monster truck crash by the zombies attack.
<G-vec00169-001-s462><collect.sammeln><de> Sammeln Sie Geld, um Ihre LKW power.Try steigern nicht, Ihre Monster-Truck-Crash vom Zombieangriff zu bekommen.
<G-vec00169-001-s463><collect.sammeln><en> We collect this information in order to make strategic decisions on the one hand and to create relevant marketing material for our sales people and our customers on the other.
<G-vec00169-001-s463><collect.sammeln><de> Wir sammeln diese Informationen, um einerseits strategische Entscheidungen treffen und andererseits relevantes Marketingmaterial für unsere Verkäuferinnen und Verkäufer und für die Kundinnen und Kunden erstellen zu können.
<G-vec00169-001-s464><collect.sammeln><en> Collect all the teams and tactical positions and hone your skills.
<G-vec00169-001-s464><collect.sammeln><de> Sammeln Sie alle Teams und taktische Positionen und Ihre Fähigkeiten verbessern.
<G-vec00169-001-s465><collect.sammeln><en> Other side effects of having adware programs such as Mac Optimizer Pro on your computer is that the software begins to collect your data without your approval.
<G-vec00169-001-s465><collect.sammeln><de> Andere Nebenwirkungen von Adware-Programme, die wie Mac Optimizer Pro auf Ihrem Computer ist, dass die Software Ihre Daten beginnt ohne Ihre Zustimmung zu sammeln.
<G-vec00169-001-s466><collect.sammeln><en> If your servers archive all their backups and they collect their data just once a day, you’re looking at making 365 deletions in each of your corporate and subsidiaries’ backup media for each year the client was on your systems.
<G-vec00169-001-s466><collect.sammeln><de> Wenn Ihre Server alle Sicherheitskopien einmal am Tag sammeln, sind das 365 Löschungen in jedem Ihrer Korporativen Server und den Tochtergesellschaften für jedes Jahr der Kunde in Ihren Systemen war.
<G-vec00169-001-s467><collect.sammeln><en> This Privacy Policy covers the information that we collect about you as a process of you using our services, or otherwise interacting with us, unless a different policy is displayed.
<G-vec00169-001-s467><collect.sammeln><de> Diese Datenschutzerklärung deckt die Informationen ab, die wir über Sie sammeln, wenn Sie unsere Dienste nutzen oder anderweitig mit uns interagieren, es sei denn, eine andere Richtlinie wird angezeigt.
<G-vec00169-001-s468><collect.sammeln><en> PicoLog data acquisition software can collect up to 1 million samples.
<G-vec00169-001-s468><collect.sammeln><de> Die PicoLog- Datenerfassungs- Software kann bis zu 1 Millionen Samples sammeln.
<G-vec00169-001-s469><collect.sammeln><en> In the course of this work staff from the ICWC collect sources, which are scattered around the world, and then analyse them from a variety of academic perspectives.
<G-vec00169-001-s469><collect.sammeln><de> Im Zuge dieser Tätigkeiten sammeln die Mitarbeiterinnen und Mitarbeiter des ICWC überall auf der Welt verstreute Quellen und werten sie unter verschiedenen wissenschaftlichen Blickwinkeln aus.
<G-vec00169-001-s470><collect.sammeln><en> Early spring agricultural workers start their work: plow the land, sowing, watering, fertilizing, weed, and only then, when the harvest is ripe, carefully collect it, placed in specially designed containers and shipped to customers.
<G-vec00169-001-s470><collect.sammeln><de> Vorfrühling Landarbeiter ihre Arbeit aufnehmen: pflügen das Land, Aussaat, Bewässerung, Düngung, Unkraut, und nur dann, wenn die Ernte reif ist, sorgfältig sammeln, platziert in speziell entwickelten Behältern und an Kunden ausgeliefert.
<G-vec00169-001-s471><collect.sammeln><en> Cars reached the finish line without crashing the game, remember that the road to collect the stars.
<G-vec00169-001-s471><collect.sammeln><de> Autos erreichten die Ziellinie, ohne abzustürzen das Spiel, denken Sie daran, dass die Straße, um die Sterne zu sammeln.
<G-vec00169-001-s472><collect.sammeln><en> Then the Lech ZÃ1⁄4rs Tourismus GmbH invites you to a cosy drink where I can only collect enthusiastic opinions.
<G-vec00169-001-s472><collect.sammeln><de> Dann lädt die Lech Zürs Tourismus GmbH zu einem gemütlichen Umtrunk ein, bei dem ich nur begeisterte Meinungen sammeln kann.
<G-vec00169-001-s473><collect.sammeln><en> These cookies do not collect information about you that could be used for advertising or to register your activity on the internet.
<G-vec00169-001-s473><collect.sammeln><de> Diese Cookies sammeln keine Informationen über Sie, die für Werbung verwendet werden könnten, oder um Ihre Aktivitäten im Internet zu registrieren.
<G-vec00169-001-s474><collect.sammeln><en> Collect or store personally identifying information about other users for commercial or unlawful purposes.
<G-vec00169-001-s474><collect.sammeln><de> Personenbezogene Daten von Benutzern zu gewerblichen oder ungesetzlichen Zwecken zu sammeln oder zu speichern.
<G-vec00443-001-s219><collect.sammeln><en> The artist travelled for months on end in order to collect over 500 songs from every region of Argentina.
<G-vec00443-001-s219><collect.sammeln><de> Um über 500 Lieder aus allen Regionen Argentiniens zu sammeln, reiste sie mehrere Monate durch das Land.
<G-vec00169-001-s475><collect.sammeln><en> If you are a Facebook member and do not wish Facebook to collect information about you via our internet site and link this to your data stored at Facebook, then you must log out of Facebook prior to visiting our site.
<G-vec00169-001-s475><collect.sammeln><de> Wenn Sie Facebookmitglied sind und nicht möchten, dass Facebook über unseren Internetauftritt Daten über Sie sammelt und mit Ihren bei Facebook gespeicherten Daten verknüpft, müssen Sie sich vor Ihrem Besuch unseres Internetauftritts bei Facebook ausloggen.
<G-vec00169-001-s476><collect.sammeln><en> We have already told how to collect and harvest a plant, and now we can talk about how to use a burdock for hair.
<G-vec00169-001-s476><collect.sammeln><de> Wir haben bereits erzählt, wie man eine Pflanze sammelt und ernten kann, und jetzt können wir darüber sprechen, wie man eine Klette für Haare verwendet.
<G-vec00169-001-s477><collect.sammeln><en> If you don’t want that Facebook collect data about you through our website, please log out of Facebook before visiting our website.
<G-vec00169-001-s477><collect.sammeln><de> Wenn Sie Facebookmitglied sind und nicht möchten, dass Facebook über unseren Internetauftritt Daten über Sie sammelt und mit Ihren bei Facebook gespeicherten Daten verknüpft, müssen Sie sich vor Ihrem Besuch unseres Internetauftritts bei Facebook ausloggen.
<G-vec00169-001-s478><collect.sammeln><en> Plantation House will only collect details about you when you place an order.
<G-vec00169-001-s478><collect.sammeln><de> Plantage-Haus sammelt nur Details über Sie, wenn Sie einen Auftrag erteilen.
<G-vec00169-001-s479><collect.sammeln><en> Tompkins: Yeah. And we were told by the Reptilians there, “Go ahead and finish two or three more missions, but collect your rocks and take your photographs and don't come back.
<G-vec00169-001-s479><collect.sammeln><de> Tompkins: Ja, und uns wurde von den Reptiloiden dort gesagt: „Geht los und beendet noch zwei bis drei weitere Missionen, aber sammelt eure Steine und macht eure Fotos und kommt nicht wieder.
<G-vec00169-001-s480><collect.sammeln><en> The device can collect up to 24 litres of condensate humidity in rooms of up to 50 m2 in 24 hours.
<G-vec00169-001-s480><collect.sammeln><de> Denn in Räumen bis rund 50 m2 sammelt das Gerät in 24 Stunden bis zu 24 Liter kondensierte Feuchtigkeit ein.
<G-vec00169-001-s481><collect.sammeln><en> We use the web analytics program Matomo (formerly Piwik) for the purpose of statistical data collection on user behaviour. It uses cookies and Javascript to collect various information on your computer and transmit it to us.
<G-vec00169-001-s481><collect.sammeln><de> Wir setzen zur statistischen Datenerfassung des Nutzungsverhaltens das Webanalytik-Programm Matomo (ehemals Piwik) ein, das mit Cookies und JavaScript verschiedene Informationen auf Ihrem Computer sammelt und automatisiert an uns überträgt.
<G-vec00169-001-s482><collect.sammeln><en> The FUERTE GROUP services are not intended for minors aged under 14 without the full consent of their parent or guardian, therefore FUERTE GROUP does not collect or request information from minors aged under 14.
<G-vec00169-001-s482><collect.sammeln><de> Die Serviceleistungen der FUERTE GROUP sind ohne Zustimmung der Erziehungsberechtigten nicht für Minderjährige unter 14 Jahren bestimmt, sodass die FUERTE GROUP von unter 14-Jährigen keine Daten sammelt oder anfragt.
<G-vec00169-001-s483><collect.sammeln><en> Collect the goodies on the left (Automatic Ammo and Flares).
<G-vec00169-001-s483><collect.sammeln><de> Sammelt die Goodies (Automatik-Munition und Fackeln) links ein.
<G-vec00169-001-s484><collect.sammeln><en> You agree that the Software may collect and communicate certain software, hardware, and use information to Quark's (or its service providers') servers for the purposes of (i) checking for and performing any updates; and (ii) ensuring that You have complied and are complying with the terms of this License Agreement, including the use of valid serial numbers and validation codes.
<G-vec00169-001-s484><collect.sammeln><de> Sie erklären sich damit einverstanden, dass die Software möglicherweise bestimmte Software-, Hardware- und Nutzungsdaten sammelt und an die Server von Quark (oder an die Server seiner Service-Provider) kommuniziert zum Zwecke (i) der Prüfung und Ausführung verfügbarer Updates; und (ii) zur Gewährleistung, dass Sie die Bedingung dieser Lizenzvereinbarung eingehalten haben und immer noch einhalten, einschließlich der Verwendung gültiger Seriennummern und Validierungscodes.
<G-vec00169-001-s485><collect.sammeln><en> If a USER is member of FACEBOOK and does not want FACEBOOK to collect data about him and connects it to his personal data on FACEBOOK via the HOMEPAGE, the USER has to log out of the FACEBOOK HOMEPAGE before visiting the HOMEPAGE.
<G-vec00169-001-s485><collect.sammeln><de> Wenn ein Nutzer Facebookmitglied ist und nicht möchte, dass Facebook über dieses Angebot Daten über ihn sammelt und mit seinen bei Facebook gespeicherten Mitgliedsdaten verknüpft, muss er sich vor dem Besuch des Internetauftritts bei Facebook ausloggen.
<G-vec00169-001-s486><collect.sammeln><en> Most cookie does not collect identifiable information, instead gather more general information such as the way in which users have come to our site, such as the use, or the general location of a user.
<G-vec00169-001-s486><collect.sammeln><de> Die meisten Cookie sammelt keine Daten, statt allgemeinere Informationen zu sammeln, wie die Art, in der Benutzer haben auf unserer Seite zu kommen, wie die Verwendung oder die allgemeine Lage eines Benutzers.
<G-vec00169-001-s487><collect.sammeln><en> If a user is a member of Facebook, but does not want Facebook to collect data about them using the Offer and link it to their member data stored in Facebook, they must log out from Facebook before visiting the website.
<G-vec00169-001-s487><collect.sammeln><de> Wenn ein Nutzer Facebook-Mitglied ist und nicht möchte, dass Facebook über dieses Angebot Daten über ihn sammelt und mit seinen bei Facebook gespeicherten Mitgliedsdaten verknüpft, muss er sich vor dem Besuch des Internetauftritts bei Facebook ausloggen.
<G-vec00169-001-s488><collect.sammeln><en> If a user is on Facebook and does not want Facebook to collect data via it about this online offer and link him/her to his/her member data stored with Facebook, he/she must log out of Facebook and delete its cookies before using our online offer.
<G-vec00169-001-s488><collect.sammeln><de> Wenn ein Nutzer Facebookmitglied ist und nicht möchte, dass Facebook über dieses Onlineangebot Daten über ihn sammelt und mit seinen bei Facebook gespeicherten Mitgliedsdaten verknüpft, muss er sich vor der Nutzung unseres Onlineangebotes bei Facebook ausloggen und seine Cookies löschen.
<G-vec00169-001-s489><collect.sammeln><en> Run forward and collect the ammo .
<G-vec00169-001-s489><collect.sammeln><de> Lauft geradeaus und sammelt die HK-Munition ein.
<G-vec00169-001-s490><collect.sammeln><en> Collect Incredibricks and assemble them into massive structures to advance through your adventures.
<G-vec00169-001-s490><collect.sammeln><de> Sammelt Incredi-Steine und baut mit ihnen riesige Konstruktionen, um in euren Abenteuern weiterzukommen.
<G-vec00169-001-s491><collect.sammeln><en> Now a new search folder of For Follow Up is added in the Navigation Pane, which will collect all flagged email messages automatically.
<G-vec00169-001-s491><collect.sammeln><de> Jetzt ein neuer Suchordner von Für die Nachverfolgung wird im Navigationsbereich hinzugefügt, der alle markierten E-Mail-Nachrichten automatisch sammelt.
<G-vec00169-001-s492><collect.sammeln><en> The Citizens Committee continues to collect artefacts which document the work of the Stasi in Leipzig, and beyond.
<G-vec00169-001-s492><collect.sammeln><de> Das Bürgerkomitee sammelt schwerpunktmäßig all jene Objekte, die die Arbeit des MfS in Leipzig und im Einzelfall auch darüber hinaus dokumentieren.
<G-vec00169-001-s493><collect.sammeln><en> The first version of Oracle IAS was developed in 2008 in the current version, the system allows you to collect and analyze data on the medical staff, on equipment of medical institutions, on the sanitary-and-spa treatment, a clinical examination of orphans, the sick with cancer, influenza, diabetes diabetes, multiple sclerosis and others.
<G-vec00169-001-s493><collect.sammeln><de> Die erste Version von Oracle IAS wurde 2008 in der aktuellen Version entwickelt, das System ermöglicht es Ihnen, sammelt und analysiert Daten über die medizinische Personal, die Ausrüstung der medizinischen Einrichtungen auf der Sanitär-und-Spa-Behandlung, eine klinische Untersuchung der Waisen, Kranken mit Krebs, Grippe, Diabetes Diabetes, Multiple Sklerose und andere.
<G-vec00443-001-s226><collect.sammeln><en> We have already told how to collect and harvest a plant, and now we can talk about how to use a burdock for hair.
<G-vec00443-001-s226><collect.sammeln><de> Wir haben bereits erzählt, wie man eine Pflanze sammelt und ernten kann, und jetzt können wir darüber sprechen, wie man eine Klette für Haare verwendet.
<G-vec00169-001-s494><collect.sammeln><en> BUST OUT THE BIG GUNS • 20 exotic cars to collect and upgrade.
<G-vec00169-001-s494><collect.sammeln><de> HER MIT DEN GROSSEN GESCHÜTZEN • Sammle und verbessere 20 exotische Autos.
<G-vec00169-001-s495><collect.sammeln><en> Collect bonuses and coins.
<G-vec00169-001-s495><collect.sammeln><de> Sammle Boni und Münzen.
<G-vec00169-001-s496><collect.sammeln><en> I help the customers with their bags and I collect the shopping trolleys.
<G-vec00169-001-s496><collect.sammeln><de> Ich helfe den Kunden mit ihren Tüten und sammle die Einkaufswagen ein.
<G-vec00169-001-s497><collect.sammeln><en> Collect Christmas toys to score points.
<G-vec00169-001-s497><collect.sammeln><de> Sammle die Weihnachtsgeschenke ein um mehr Punkte zu bekommen.
<G-vec00169-001-s498><collect.sammeln><en> Two gameplay modes: 1) classic: Collect all flowers in level 2) dynamic: Collect more as possible flowers, before it is not be possible.
<G-vec00169-001-s498><collect.sammeln><de> Zwei Spielmodi: 1) Klassiker: Sammeln Sie alle Blumen in Ebene 2) dynamisch: Sammle mehr wie möglich Blumen, bevor es wird nicht möglich sein,.
<G-vec00169-001-s499><collect.sammeln><en> Be the smartest prospector and collect the most of that valuable gold.
<G-vec00169-001-s499><collect.sammeln><de> Sei der gewiefteste Goldsucher und sammle das meiste wertvolle Gold.
<G-vec00169-001-s500><collect.sammeln><en> Small ball end portion of the maze and collect all points in the next late.
<G-vec00169-001-s500><collect.sammeln><de> Kleiner Ball Endabschnitt des Labyrinth und sammle alle Punkte in den nächsten spät.
<G-vec00169-001-s501><collect.sammeln><en> There are also special gaming triggers like The Lucky Nudge, Collect a Wild, Brilliant Wilds and the Your Gamble extra win opportunity.
<G-vec00169-001-s501><collect.sammeln><de> Weitere besondere Spielzüge, wie den Lucky Nudge, Sammle ein Wild, Brillante Wilds und die Deine Gamble Extra-Gewinnchance.
<G-vec00169-001-s502><collect.sammeln><en> I also keep a kind of visual diary, where I collect impressions and photos.
<G-vec00169-001-s502><collect.sammeln><de> Ich führe auch so eine Art visuelles Tagebuch, wo ich Eindrücke und Fotos sammle.
<G-vec00169-001-s503><collect.sammeln><en> Collect all the fruits and land safely on the platform before your fuel runs out.
<G-vec00169-001-s503><collect.sammeln><de> Sammle alle Früchte und sicher zu landen auf der Plattform, bevor der Treibstoff ausgeht.
<G-vec00169-001-s504><collect.sammeln><en> Take on swarms of enemies and collect treasure as you fight.
<G-vec00169-001-s504><collect.sammeln><de> Nehmen Sie auf Schwärme von Gegnern und sammle Schätze, wie Sie kämpfen.
<G-vec00169-001-s505><collect.sammeln><en> Collect the bombs before they explode.
<G-vec00169-001-s505><collect.sammeln><de> Sammle die Bomben bevor sie explodieren.
<G-vec00169-001-s506><collect.sammeln><en> Collect pictures of that which you wish to sow.
<G-vec00169-001-s506><collect.sammeln><de> Sammle Bilder von dem was Du wünschst zu säen.
<G-vec00169-001-s507><collect.sammeln><en> "For those collectors that have the motto ""I collect coins and not packaging"" we, of course, we have the traditional 2017 Dutch UNC set available from stock...."
<G-vec00169-001-s507><collect.sammeln><de> Für Sammler derer Devise 'ich sammle Münzen und keine Packungen' ist, haben wir selbstverständlich die traditionelle UNC-Serie 2017 der Niederlande...
<G-vec00169-001-s508><collect.sammeln><en> Collect the shields for points.
<G-vec00169-001-s508><collect.sammeln><de> Sammle die Schilder auf der Strecke, um zu Punkten.
<G-vec00169-001-s509><collect.sammeln><en> Collect health orbs to fill your health bar.
<G-vec00169-001-s509><collect.sammeln><de> Sammle Gesundheit Kugeln, um Ihre Gesundheit Bar zu füllen.
<G-vec00169-001-s510><collect.sammeln><en> Collect all styles for the Knight PvP Battlesuit.
<G-vec00169-001-s510><collect.sammeln><de> Sammle alle Erscheinungen für den Ritter-Kampfanzug im PvP-Modus.
<G-vec00169-001-s511><collect.sammeln><en> Collect items and clues to help you solve the mystery.
<G-vec00169-001-s511><collect.sammeln><de> Sammle Gegenstände und Hinweise, damit Sie das Rätsel zu lösen.
<G-vec00169-001-s512><collect.sammeln><en> Collect stars and save as many Bots as you can in this action packed strategy game.
<G-vec00169-001-s512><collect.sammeln><de> Sammle Sterne und so viele Bots speichern, wie Sie in diesem actionreichen Strategiespiel.
<G-vec00443-001-s236><collect.sammeln><en> I help the customers with their bags and I collect the shopping trolleys.
<G-vec00443-001-s236><collect.sammeln><de> Ich helfe den Kunden mit ihren Tüten und sammle die Einkaufswagen ein.
<G-vec00443-001-s239><collect.sammeln><en> Be the smartest prospector and collect the most of that valuable gold.
<G-vec00443-001-s239><collect.sammeln><de> Sei der gewiefteste Goldsucher und sammle das meiste wertvolle Gold.
<G-vec00443-001-s242><collect.sammeln><en> I also keep a kind of visual diary, where I collect impressions and photos.
<G-vec00443-001-s242><collect.sammeln><de> Ich führe auch so eine Art visuelles Tagebuch, wo ich Eindrücke und Fotos sammle.
<G-vec00169-001-s551><collect.speichern><en> Diagnostics - In case of any technical issues, you should collect the app diagnostic data and provide the ticket ID to our support for further assistance.
<G-vec00169-001-s551><collect.speichern><de> Diagnostics (Diagnostik) – Im Falle von technischen Problemen solltest du die diagnostischen Daten der Anwendung speichern und diese mitsamt der generierten Ticket-ID unserem Kundenservice zukommen lassen, damit er dir weiterhelfen kann.
<G-vec00169-001-s552><collect.speichern><en> This online Privacy Statement informs you about which data we collect and how we use it.
<G-vec00169-001-s552><collect.speichern><de> Mit dieser Online-Datenschutzerklärung möchten wir Sie darüber informieren, wann wir welche Daten speichern und wie wir diese verwenden.
<G-vec00169-001-s553><collect.speichern><en> Globtour will also collect credit card information, including card number, card type, cardholder name, and expiry date, in order to guarantee your reservation or bill you for prepaid reservations.
<G-vec00169-001-s553><collect.speichern><de> Globtour wird auch Kreditkarteninformationen, einschließlich Kartennummer, Art, Name des Karteninhabers und Ablaufdatum speichern, um Ihre Reservierung zu garantieren oder die Prepaid-Reservierung für Sie zu berechnen.
<G-vec00169-001-s554><collect.speichern><en> Simson Maxwell encourages you to review the privacy statements of Web sites you choose to link to from Simson Maxwell so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s554><collect.speichern><de> EUF fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von EUF verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s555><collect.speichern><en> Tumbao encourages you to review the privacy statements of Web sites you choose to link to from Tumbao so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s555><collect.speichern><de> CP Academy fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von CP Academy verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s556><collect.speichern><en> AGS Dinamika Vanderbijlpark encourages you to review the privacy statements of Web sites you choose to link to from AGS Dinamika Vanderbijlpark so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s556><collect.speichern><de> Limited Partner fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Limited Partner verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s557><collect.speichern><en> Bayview Glass encourages you to review the privacy statements of Web sites you choose to link to from Bayview Glass so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s557><collect.speichern><de> Anna Maria Dieplinger fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Anna Maria Dieplinger verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s558><collect.speichern><en> Welcome to Bikini Racer encourages you to review the privacy statements of Web sites you choose to link to from Welcome to Bikini Racer so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s558><collect.speichern><de> Limited Partner fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Limited Partner verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s559><collect.speichern><en> Half of the noise meters are anonymous white boxes, which solely measure and collect noise levels.
<G-vec00169-001-s559><collect.speichern><de> Die eine Hälfte der Messgeräte sind anonyme weiße Boxen, die ausschließlich den Lärmpegel messen und speichern.
<G-vec00169-001-s560><collect.speichern><en> Smartphone Advertising encourages you to review the privacy statements of Web sites you choose to link to from Smartphone Advertising so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s560><collect.speichern><de> Drops fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Drops verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s561><collect.speichern><en> Cookies do not collect personal details.
<G-vec00169-001-s561><collect.speichern><de> Cookies speichern keine persönlichen Daten.
<G-vec00169-001-s562><collect.speichern><en> At bodytrainer.tv we respect your privacy and believe you should be informed about how we collect, use and disclose your personal information.
<G-vec00169-001-s562><collect.speichern><de> Datenschutzrichtlinie Wir bei bodytrainer.tv respektieren Ihre Privatsphäre und glauben, sollten Sie darüber informiert werden, wie wir persönliche Daten speichern und verwenden.
<G-vec00169-001-s563><collect.speichern><en> We collect the domain names, not the e-mail addresses, of visitors.
<G-vec00169-001-s563><collect.speichern><de> Wir speichern die Domainnamen, nicht die E-Mail-Adressen unserer Website-Besucher.
<G-vec00169-001-s564><collect.speichern><en> ArcAnjl encourages you to review the privacy statements of Web sites you choose to link to from ArcAnjl so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s564><collect.speichern><de> Netfactory GmbH fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Netfactory GmbH verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s565><collect.speichern><en> 3) The property of being able to collect a charge of electricity.
<G-vec00169-001-s565><collect.speichern><de> 3) Die Eigenschaft, elektrische Ladungen speichern zu können.
<G-vec00169-001-s566><collect.speichern><en> Emma EDB AS encourages you to review the privacy statements of Web sites you choose to link to from Emma EDB AS so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s566><collect.speichern><de> Limited Partner fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Limited Partner verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s568><collect.speichern><en> CogSports encourages you to review the privacy statements of Web sites you choose to link to from CogSports so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s568><collect.speichern><de> Benzingschnur Homepage fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von Benzingschnur Homepage verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00169-001-s569><collect.speichern><en> Brown Swiss Association encourages you to review the privacy statements of Web sites you choose to link to from Brown Swiss Association so that you can understand how those Web sites collect, use and share your information.
<G-vec00169-001-s569><collect.speichern><de> AutoCom fordert Sie dazu auf, die Datenschutzerklärung der Webseiten, auf die sie von AutoCom verlinkt werden, zu überprüfen, so dass Sie wissen, wie diese Web-Sites Ihre Informationen speichern und verwenden.
<G-vec00443-002-s172><collect.einsammeln><en> Collect the souls of your party guests with the Godfather Death costume.
<G-vec00443-002-s172><collect.einsammeln><de> Mit dem Gevatter Tod Kostüm wird es ein leichtes für Sie sein die Seelen Ihrer Partygäste einzusammeln.
<G-vec00443-002-s173><collect.einsammeln><en> A mix of addictive match-3 gameplay and city-building fun, Heroes of Hellas 2 challenges you to drag your mouse across chains of identical items to remove obstacles, activate bonus items and collect valuable objects.
<G-vec00443-002-s173><collect.einsammeln><de> Heroes of Hellas 2: Olympia ist ein fesselndes Kombinationsspiel mit Stadtbau-Elementen, in dem du deine Maus über identische Objekte ziehen musst, um Hindernisse zu entfernen, Bonusgegenstände zu aktivieren und wertvolle Objekte einzusammeln.
<G-vec00443-002-s174><collect.einsammeln><en> But do remember to collect all your resources and bank them in time!
<G-vec00443-002-s174><collect.einsammeln><de> Vergiss aber nicht alle Ressourcen einzusammeln und in der Bank zu verstauen, solange dies möglich ist.
<G-vec00443-002-s175><collect.einsammeln><en> Should he leave and move on something, he seems not to want to the items and you are free to collect such items.
<G-vec00443-002-s175><collect.einsammeln><de> Sollte er etwas liegenlassen und weiterziehen, so scheint er die Items nicht zu wollen und es steht euch frei, diese Gegenstände einzusammeln.
<G-vec00443-002-s176><collect.einsammeln><en> A very smart game where you must keep the mouse cursor in the game area and collect the "-" and "x".
<G-vec00443-002-s176><collect.einsammeln><de> Ein cooles Spiel, indem es deine Aufgabe ist den Mauszeiger innerhalb des Spielfeldes zu halten und die "-" & "x" einzusammeln.
<G-vec00443-002-s177><collect.einsammeln><en> And if you do not have time to collect the banks that will meet in your way, then you will lose.
<G-vec00443-002-s177><collect.einsammeln><de> Und wenn Sie keine Zeit haben, die Banken einzusammeln, die auf Ihre Art und Weise zusammentreffen werden, werden Sie verlieren.
<G-vec00443-002-s178><collect.einsammeln><en> They realized what happened and volunteered immediately to collect and bring up my things.
<G-vec00443-002-s178><collect.einsammeln><de> Sie bemerkten, was passiert war und boten sofort ihre Hilfe an meine Sachen einzusammeln und nach oben zu bringen.
<G-vec00443-002-s179><collect.einsammeln><en> Meet Ball Weevil - Ball Weevil uses a sticky ball to collect random junk.
<G-vec00443-002-s179><collect.einsammeln><de> Ball Grille verwendet einen klebrigen Ball, um alles Möglichen einzusammeln.
<G-vec00443-002-s180><collect.einsammeln><en> It is not always advisable to collect the most expensive extra, sometimes, as simple speed-up or a threefold shot is more important than a fish weapon.
<G-vec00443-002-s180><collect.einsammeln><de> Es ist nicht immer ratsam das jeweils teuerste Extra einzusammeln, manchmal sind ein simples Speedup oder ein Dreifachschuss wichtiger als eine teure Fish-Weapon.
<G-vec00443-002-s181><collect.einsammeln><en> In the GAMBLE game use the RED and BLACK buttons to predict the colour of the next card, or use the COLLECT button to take your winnings thus far and end the game.
<G-vec00443-002-s181><collect.einsammeln><de> Im GAMBLE-Spiel verwendest du die Buttons RED und BLACK, um die Farbe der nächsten Karte vorherzusagen, oder den COLLECT-Button, um die Gewinne einzusammeln und das Spiel zu beenden.
<G-vec00443-002-s182><collect.einsammeln><en> Don't forget to collect your gifts in time, since more crystals will only appear if there's room under the tree. Note:
<G-vec00443-002-s182><collect.einsammeln><de> Vergiss nicht, deine Geschenke regelmäßig einzusammeln, denn nur wenn der Platz unter dem Baum leer ist, erscheinen neue Kristalle.
<G-vec00443-002-s184><collect.einsammeln><en> Even 6-10 Offices ordered their lower levels to collect all documents pertaining to the persecution of Falun Gong.
<G-vec00443-002-s184><collect.einsammeln><de> Sogar Büros 610 wiesen ihre nachgeordneten Ebenen an, alle die Verfolgung von Falun Gong betreffenden Dokumente einzusammeln.
<G-vec00443-002-s185><collect.einsammeln><en> It's your objective to collect all the diamonds.
<G-vec00443-002-s185><collect.einsammeln><de> Ihr Ziel ist es, alle herumliegenden Diamanten einzusammeln.
<G-vec00443-002-s186><collect.einsammeln><en> This time the elves have blown all gifts to the sky and your task is to help Santa to collect them all.
<G-vec00443-002-s186><collect.einsammeln><de> Diesmal haben die Elfen alle Geschenke über den Himmel verteilt und du musst Santa Claus helfen, alles einzusammeln.
<G-vec00443-002-s187><collect.einsammeln><en> Recently, Companisto reverted to its old model and once again offers new start-ups the possibility to collect capital over a period of 120 days.
<G-vec00443-002-s187><collect.einsammeln><de> Inzwischen ist Companisto wieder zum ursprünglichen Modell zurückgekehrt und bietet neuen Start-Ups die Möglichkeit, wieder über einen Gesamtzeitraum von bis zu 120 Tagen Kapital einzusammeln.
<G-vec00443-002-s188><collect.einsammeln><en> He looked up and for the briefest of moments, their gazes met, before he turned around and started to collect his things.
<G-vec00443-002-s188><collect.einsammeln><de> Für einen kurzen Moment schaute er auf und ihre Blicke trafen sich, bevor er sich umdrehte und begann, seine Sachen einzusammeln.
<G-vec00443-002-s189><collect.einsammeln><en> We are at the beginning of the game but we already have to click 6 times to collect these resources.
<G-vec00443-002-s189><collect.einsammeln><de> Wir sind zwar erst am Anfang des Spiels, aber wir müssen schon 6 mal klicken, um alle Ressourcen einzusammeln.
<G-vec00443-002-s133><collect.einziehen><en> We need to collect tax and forward them to the spa.
<G-vec00443-002-s133><collect.einziehen><de> Wir müssen die Kurtaxe einziehen und an die Kurverwaltung weiterleiten.
<G-vec00443-002-s134><collect.einziehen><en> We shall nevertheless not collect the claim, as long as the purchaser complies with its obligations of payment from the revenue it receives, is not in default of payment, an application has not been made to open insolvency proceedings against the purchaser’s assets and it has not suspended payments.
<G-vec00443-002-s134><collect.einziehen><de> Der Besteller darf die an WOELKE Industrieelektronik GmbH abgetretenen Forderungen jedoch einziehen, solange er sich nicht in Zahlungsverzug befindet oder die Zahlungen eingestellt hat.
<G-vec00443-002-s135><collect.einziehen><en> Merchants are able to collect payments when they want.
<G-vec00443-002-s135><collect.einziehen><de> Händler können Zahlungen einziehen, wann immer sie wollen.
<G-vec00443-002-s136><collect.einziehen><en> The seller, however, will not collect the claims as long as the customer meets his payment obligations to the seller, is not in default of payment, and no application for opening insolvency proceedings is filed.
<G-vec00443-002-s136><collect.einziehen><de> Der Verkäufer wird jedoch die Forderungen nicht einziehen, solange der Kunde seinen Zahlungsverpflichtungen dem Verkäufer gegenüber nachkommt, nicht in Zahlungsverzug gerät und kein Antrag auf Eröffnung eines Insolvenzverfahrens gestellt ist.
<G-vec00443-002-s137><collect.einziehen><en> You continue to be entitled to collect receivables, but we are also permitted to collect receivables ourselves if you have failed to meet your payment obligations.
<G-vec00443-002-s137><collect.einziehen><de> Sie bleiben zur Einziehung der Forderungen ermächtigt, wir dürfen Forderungen jedoch auch selbst einziehen, soweit Sie Ihren Zahlungsverpflichtungen nicht nachkommen.
<G-vec00443-002-s138><collect.einziehen><en> The Company may, if the Buyer is more than two weeks in arrears with his payment obligations to the Company, demand the return of the reserved goods and collect the demands and other claims assigned to the Company.
<G-vec00443-002-s138><collect.einziehen><de> 5.6 Der Verkäufer kann, wenn der Kunde mit seinen Zahlungsverpflichtungen gegenüber dem Verkäufer länger als zwei Wochen in Verzug ist, die Vorbehaltsware herausverlangen und die an den Verkäufer abgetretenen Forderungen und sonstigen Ansprüche einziehen.
<G-vec00443-002-s139><collect.einziehen><en> Optionally, we can collect the entry fees during the online registration and will pay them out to you at the end of each month.
<G-vec00443-002-s139><collect.einziehen><de> Optional können Sie auch die Startgelder im Rahmen der Online-Anmeldung einziehen lassen, die wir Ihnen monatlich auszahlen.
<G-vec00443-002-s140><collect.einziehen><en> Collect payments online.
<G-vec00443-002-s140><collect.einziehen><de> Zahlungen online einziehen.
<G-vec00443-002-s142><collect.einziehen><en> We undertake, however, not to collect the claim as long as the customer fulfils his payment obligations from the received proceeds, is not in default of payment and, in particular, so long as no application for the opening of conciliation or insolvency proceedings has been made and payments have not been suspended.
<G-vec00443-002-s142><collect.einziehen><de> Wir werden jedoch die Forderung nicht einziehen, solange der Besteller seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und insbesondere kein Antrag auf Eröffnung eines Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00443-002-s143><collect.einziehen><en> You can now collect payments for orders made through the PayPal checkout on your store.
<G-vec00443-002-s143><collect.einziehen><de> Sie können jetzt Zahlungen für Bestellungen einziehen, die über den PayPal-Checkout in Ihrem Geschäft getätigt wurden.
<G-vec00443-002-s145><collect.einziehen><en> resolve disputes or collect overdue payments.
<G-vec00443-002-s145><collect.einziehen><de> Streitigkeiten lösen oder überfällige Zahlungen einziehen.
<G-vec00443-002-s146><collect.einziehen><en> We shall be entitled to collect any claims that have been assigned to us directly from third parties.
<G-vec00443-002-s146><collect.einziehen><de> An uns abgetretene Forderungen können wir unmittelbar bei dem Dritten einziehen.
<G-vec00443-002-s147><collect.einziehen><en> PayCific will once again collect the due amount on behalf of the website operator.
<G-vec00443-002-s147><collect.einziehen><de> Auch wird PayCific dann für den Betreiber der Webseite den fälligen Betrag wieder einziehen.
<G-vec00443-002-s148><collect.einziehen><en> 4) The Seller shall not collect the assigned claims as long as the Buyer performs its payment obligations or its financial conditions do not deteriorate considerably.
<G-vec00443-002-s148><collect.einziehen><de> (4) Der Verkäufer wird die abgetretenen Forderungen, so lange der Käufer seinen Zahlungsverpflichtungen nachkommt oder sich seine Vermögensverhältnisse nicht wesentlich verschlechtert, nicht einziehen.
<G-vec00443-002-s149><collect.einziehen><en> This is because we collect with a delay.
<G-vec00443-002-s149><collect.einziehen><de> Dies kommt dadurch zustande, dass wir verspätet Zahlungen einziehen.
<G-vec00443-002-s150><collect.einziehen><en> ...because you will only collect the participation fee from the participants once (and it is not a recurring payment).
<G-vec00443-002-s150><collect.einziehen><de> …da Sie die Teilnahmegebühr ja nur einmalig von den Teilnehmern einziehen werden (und es sich nicht um eine wiederkehrende Zahlung handelt).
<G-vec00443-002-s151><collect.einziehen><en> The Vendor is not entitled to collect claims through third parties without the explicit prior written approval of BHI.
<G-vec00443-002-s151><collect.einziehen><de> Der Verkäufer ist ohne vorherige schriftliche Genehmigung durch BHI nicht berechtigt Forderungen durch Dritte einziehen zu lassen.
<G-vec00443-002-s247><collect.erfassen><en> We take a number of organizational, technical and physical measures that are designed to protect the personal information we collect.
<G-vec00443-002-s247><collect.erfassen><de> Wir ergreifen eine Reihe von organisatorischen, technischen und physischen Maßnahmen, die darauf abzielen, die von uns erfassten personenbezogenen Daten zu schützen.
<G-vec00443-002-s248><collect.erfassen><en> All information these cookies collect is aggregated and therefore anonymous.
<G-vec00443-002-s248><collect.erfassen><de> Alle von diesen Cookies erfassten Informationen werden aggregiert und sind daher anonym.
<G-vec00443-002-s249><collect.erfassen><en> We use the data we collect to provide third parties with the information necessary to enable those third parties’ fulfillment of the products or services that an Athlete has requested.
<G-vec00443-002-s249><collect.erfassen><de> Wir nutzen die von uns erfassten Daten, um den Drittanbietern die zur Bereitstellung der von einem Sportler verlangten Produkte und Dienstleistungen nötigen Informationen zur Verfügung zu stellen.
<G-vec00443-002-s250><collect.erfassen><en> Additionally, in the event of a transfer, reorganization, merger, or sale of the website, we may transfer any and all personal information we collect to the relevant third party.
<G-vec00443-002-s250><collect.erfassen><de> Dies gilt auch im Falle einer Reorganisation, eines Firmenzusammenschlusses oder eines Firmenerwerbs – wir werden dann alle von uns erfassten personenbezogenen Informationen an das jeweilige Unternehmen weitergeben.
<G-vec00443-002-s251><collect.erfassen><en> If you are from the European Economic Area (EEA), alternative.money's legal basis for collecting and using the personal information described in this Privacy Policy depends on the Personal Data we collect and the specific context in which we collect it. alternative.money may process your Personal Data because:
<G-vec00443-002-s251><collect.erfassen><de> Falls sich Ihr Wohnsitz innerhalb des Europäischen Wirtschaftsraums (EWR) befindet, hängt die rechtliche Grundlage von Investment by Objectives (IBO) SA für die Erfassung und Nutzung der in dieser Datenschutz-Richtlinie beschriebenen personenbezogenen Daten von den von uns erfassten personenbezogenen Daten sowie von dem erfassungsspezifischen Kontext ab.
<G-vec00443-002-s252><collect.erfassen><en> The data that we collect from you may be transferred to, and stored at, a destination outside the European Economic Area (EEA).
<G-vec00443-002-s252><collect.erfassen><de> Die von uns erfassten personenbezogenen Daten werden möglicherweise an einen Ort außerhalb des Europäischen Wirtschaftsraums („EWR”) übermittelt und dort gespeichert.
<G-vec00443-002-s253><collect.erfassen><en> If you are from the European Economic Area (EEA), SecureSystem GmbH legal basis for collecting and using the personal information described in this Privacy Policy depends on the Personal Data we collect and the specific context in which we collect it.
<G-vec00443-002-s253><collect.erfassen><de> Falls sich Ihr Wohnsitz innerhalb des Europäischen Wirtschaftsraums (EWR) befindet, hängt die rechtliche Grundlage von Bergmann Touristik GmbH für die Erfassung und Nutzung der in dieser Datenschutz-Richtlinie beschriebenen personenbezogenen Daten von den von uns erfassten personenbezogenen Daten sowie von dem erfassungsspezifischen Kontext ab.
<G-vec00443-002-s254><collect.erfassen><en> Information that we collect and manage using the Subscription Service for our own marketing belongs to us and is used, disclosed and protected according to this Privacy Policy. Use by Our Customers
<G-vec00443-002-s254><collect.erfassen><de> Die von uns mit dem Abonnementdienst erfassten und verwalteten Daten für unser eigenes Marketing gehören uns und werden gemäß dieser Datenschutzrichtlinie verwertet, offengelegt und geschützt.
<G-vec00443-002-s255><collect.erfassen><en> This means that when we collect your personal information we may process it in any of these countries, subject to the following paragraph.
<G-vec00443-002-s255><collect.erfassen><de> Dies bedeutet, dass Ihre von uns erfassten personenbezogenen Daten in jedem dieser Länder verarbeitet werden könnten.
<G-vec00443-002-s256><collect.erfassen><en> The information we collect may be used to facilitate your use of our site and improve the operation of the site; respond to and fulfill any requests you make for products, services or other support from Xerox Business Services; communicate with you about the products, services and promotional offers available from Xerox Business Services or our business partners.
<G-vec00443-002-s256><collect.erfassen><de> Die erfassten Informationen können dazu dienen, die Verwendung unserer Website zu vereinfachen und den Betrieb der Website zu verbessern, Ihre Anfragen hinsichtlich Produkten, Services oder anderer Unterstützung von ACS zu beantworten und abzuarbeiten und im Zusammenhang mit den von ACS oder unseren Geschäftspartnern verfügbaren Produkten, Services oder Werbeangeboten mit Ihnen in Kontakt zu treten.
<G-vec00443-002-s257><collect.erfassen><en> The information we collect is typically related to the product or service requested, such as name and contact details, the nature of the product or service requested, and related information so that we may fulfill requests and respond to them.
<G-vec00443-002-s257><collect.erfassen><de> Die von uns erfassten Daten beziehen sich üblicherweise auf das angefragte Produkt oder die angefragte Dienstleistung, wie etwa Name und Kontaktdaten, die Art des angefragten Produkts oder der Dienstleistung, und damit verbundene Informationen, sodass wir die Anfragen beantworten und darauf eingehen können.
<G-vec00443-002-s258><collect.erfassen><en> We take steps in accordance with good industry practice to protect the information we collect from unauthorized access, disclosure, alteration, or destruction.
<G-vec00443-002-s258><collect.erfassen><de> Wir unternehmen alle angemessenen Schritte mit bewährten Verfahren, um die von uns erfassten Daten vor unbefugtem Zugriff sowie vor Weitergabe, Änderung oder Zerstörung zu schützen.
<G-vec00443-002-s260><collect.erfassen><en> The data we collect directly from the social media presence are deleted as soon as they have served their purpose for being stored, if you request us to do so, if you revoke your consent to store the data or there is no longer any reason for the storage of your data.
<G-vec00443-002-s260><collect.erfassen><de> Die unmittelbar von uns über die Social-Media-Präsenz erfassten Daten werden von unseren Systemen gelöscht, sobald der Zweck für ihre Speicherung entfällt, Sie uns zur Löschung auffordern, Ihre Einwilligung zur Speicherung widerrufen oder der Zweck für die Datenspeicherung entfällt.
<G-vec00443-002-s261><collect.erfassen><en> If you are from the European Economic Area (EEA), GyanSys Inc. legal basis for collecting and using the personal information described in this Privacy Policy depends on the Personal Data we collect and the specific context in which we collect it.
<G-vec00443-002-s261><collect.erfassen><de> Falls sich Ihr Wohnsitz innerhalb des Europäischen Wirtschaftsraums (EWR) befindet, hängt die rechtliche Grundlage von Parkside Informationstechnologie GmbH für die Erfassung und Nutzung der in dieser Datenschutz-Richtlinie beschriebenen personenbezogenen Daten von den von uns erfassten personenbezogenen Daten sowie von dem erfassungsspezifischen Kontext ab.
<G-vec00443-002-s262><collect.erfassen><en> The information we collect about gift recipients is not used for marketing purposes.
<G-vec00443-002-s262><collect.erfassen><de> Die von uns erfassten Informationen über Geschenkempfänger werden nicht zu Marketingzwecken verwendet.
<G-vec00443-002-s263><collect.erfassen><en> We believe the use of cookies to be in your interest, as the information we collect through cookies helps us to identify any errors and offer you to more specific services.
<G-vec00443-002-s263><collect.erfassen><de> Die von uns mithilfe von Cookies erfassten Informationen helfen uns, mögliche Fehler zu identifizieren, um Ihnen spezifische Dienste anbieten zu können, von denen wir vermuten, dass diese für Sie interessant sein können.
<G-vec00443-002-s264><collect.erfassen><en> The personal information we collect includes, but is not limited to, name, address, and telephone number, information about the form of identification used to send or receive a transaction (required by law in some instances and used by Western Union to prevent fraud) including the identification and a copy of the identification document, transaction activity, bank account and payment information, the products and services you have with us and your use of them, and your computer’s IP address and other online activity details.
<G-vec00443-002-s264><collect.erfassen><de> Zu den von uns erfassten personenbezogenen Informationen gehören unter anderem Ihr Name, Ihre Adresse und Ihre Telefonnummer, Informationen über das Ausweisdokument, das zum Senden oder Empfangen einer Transaktion verwendet wurde (falls gesetzlich vorgeschrieben), einschließlich des Ausweises sowie einer Kopie des Ausweisdokuments, die Transaktionsaktivität, Bankkonto- und Zahlungsinformationen, die Produkte und Dienstleistungen, die Sie von uns in Anspruch genommen haben, und wie Sie sie genutzt haben, und die IP-Adresse Ihres Computers und andere Details zu Ihren Online-Aktivitäten.
<G-vec00443-002-s265><collect.erfassen><en> Purposes of use The data we collect will only be used for the purpose of supplying you with the requested products or services or for other purposes for which you have given your consent, except where otherwise provided by law.
<G-vec00443-002-s265><collect.erfassen><de> Die von Ihnen erfassten persönlichen Daten werden wir nur dazu verwenden, Ihnen die gewünschten Produkte oder Dienstleistungen bereitzustellen, oder aber zu anderen Zwecken, für die Sie Ihre Einwilligung erteilt haben, sofern keine anderslautenden gesetzlichen Verpflichtungen bestehen.
<G-vec00443-002-s323><collect.erheben><en> By integrating these Google services, Google may collect and process information (including personal data).
<G-vec00443-002-s323><collect.erheben><de> Beim Laden dieses iFrames erhebt Google unter Umständen Informationen (auch personenbezogene Daten) und verarbeitet diese.
<G-vec00443-002-s324><collect.erheben><en> Furthermore, HB IM not collect, process or use your personal data for any other purpose without your prior consent.
<G-vec00443-002-s324><collect.erheben><de> Darüber hinaus erhebt, verarbeitet und nutzt HB IM Ihre personenbezogenen Daten nur, sofern Sie hierzu eine Einwilligung erteilt haben.
<G-vec00443-002-s325><collect.erheben><en> If you use a payment card from your Google Payments account or choose to save your payment card in your Google Payments account for future use, Chrome will collect information about your computer and share it with Google Pay to protect you from fraud and provide the service.
<G-vec00443-002-s325><collect.erheben><de> Wenn Sie eine Zahlungskarte aus Ihrem Google Payments-Konto verwenden oder Ihre Zahlungskarte zur zukünftigen Verwendung in Ihrem Google Payments-Konto speichern, erhebt Chrome Informationen zu Ihrem Computer und teilt sie mit Google Pay, um Sie vor Betrug zu schützen und den Dienst zur Verfügung zu stellen.
<G-vec00443-002-s326><collect.erheben><en> By filling in and sending off the data mask you are forwarding personal data to StrikoWestofen GmbH and giving your consent for StrikoWestofen GmbH to collect, process, store, change and use your data for the purposes of expediting your request for information.
<G-vec00443-002-s326><collect.erheben><de> Mit dem Ausfüllen und Absenden der Datenmaske leiten Sie personenbezogene Daten von sich an StrikoWestofen GmbH und willigen ein, dass StrikoWestofen GmbH Ihre Daten zum Zwecke der Durchführung Ihrer Informationswünsche erhebt, verarbeitet, speichert, verändert und nutzt.
<G-vec00443-002-s327><collect.erheben><en> Google Inc. does not collect any personal data as long as the "+1" button is not clicked.
<G-vec00443-002-s327><collect.erheben><de> Google Inc. erhebt laut eigenen Angaben keine personenbezogenen Daten, solange die "+1"- Schaltfläche nicht angeklickt wird.
<G-vec00443-002-s328><collect.erheben><en> The Sponsor or its affiliate shall collect only those personal details that have been expressly and freely given by the participants in the Promotion who visit the JBL website.
<G-vec00443-002-s328><collect.erheben><de> Der Sponsor oder das mit ihm verbundene Unternehmen erhebt nur die persönlichen Angaben, die der Aktion ausdrücklich und frei von den Teilnehmern in Zusammenhang mit der Promotion, übermittelt werden.
<G-vec00443-002-s330><collect.erheben><en> Website providers automatically collect and store information in so-called server log files, which your browser automatically transmits to us.
<G-vec00443-002-s330><collect.erheben><de> Der Provider der Seiten erhebt und speichert automatisch Informationen in so genannten Server-Log-Dateien, die Ihr Browser automatisch an uns übermittelt.
<G-vec00443-002-s331><collect.erheben><en> SWITCH will collect and process personal data of the contact persons in the context of performance with its tasks as registry according to the statutory provisions and the following particular provisions.
<G-vec00443-002-s331><collect.erheben><de> SWITCH erhebt und bearbeitet Personendaten der Kontaktpersonen im Rahmen der Erfüllung ihrer Aufgaben als Registerbetreiberin gemäß den gesetzlichen sowie den nachfolgenden besonderen Bestimmungen.
<G-vec00443-002-s332><collect.erheben><en> Required field CARMEN WÜRTH FORUM will collect and process all personal data entered in this form in order to process your inquiry.
<G-vec00443-002-s332><collect.erheben><de> Pflichtfeld Das CARMEN WÜRTH FORUM erhebt und verarbeitet die in dem Formular angegebenen personenbezogenen Daten, um für Sie die gewünschte Anfrage zu bearbeiten.
<G-vec00443-002-s333><collect.erheben><en> HUGO BOSS will only collect, process and use your personal data to the extent described below.
<G-vec00443-002-s333><collect.erheben><de> HUGO BOSS erhebt, verarbeitet oder nutzt Ihre personenbezogenen Daten ausschließlich in nachfolgend beschriebenem Umfang.
<G-vec00443-002-s335><collect.erheben><en> The provider (or its web space provider) shall collect data upon every instance of access to the website (so-called server log files).
<G-vec00443-002-s335><collect.erheben><de> Der Anbieter (beziehungsweise sein Webspace-Provider) erhebt Daten über jeden Zugriff auf das Angebot (so genannte Serverlogfiles).
<G-vec00443-002-s337><collect.erheben><en> If you sign into Cortana on your device, Microsoft will collect and use data related to the music you play via Groove Music to provide personalized experiences and relevant suggestions.
<G-vec00443-002-s337><collect.erheben><de> Wenn Sie sich bei Cortana auf Ihrem Gerät anmelden, erhebt Microsoft Daten in Bezug auf die Musik, die Sie über Groove Music abspielen und verwendet diese, um personifizierte Erfahrungen und zutreffende Anregungen zu geben.
<G-vec00443-002-s338><collect.erheben><en> The UBB website does not intentionally collect information from users under the age of 16.
<G-vec00443-002-s338><collect.erheben><de> Die Website der BBU erhebt absichtlich keine Daten über Benützer/innen unter 16 Jahren.
<G-vec00443-002-s340><collect.erheben><en> GTM does not collect any personal information.
<G-vec00443-002-s340><collect.erheben><de> GTM erhebt keine personenbezogenen Informationen.
<G-vec00443-002-s399><collect.sammeln><en> These cookies do not collect any personal data.
<G-vec00443-002-s399><collect.sammeln><de> Mit diesen Cookies werden keine persönlichen Daten gesammelt.
<G-vec00443-002-s400><collect.sammeln><en> These workshops helped to collect and retain traditional knowledge and this in turn has allowed farmers to be trained and supported in the cultivation, propagation and marketing of indigenous varieties.
<G-vec00443-002-s400><collect.sammeln><de> Als Folge davon wird weiterhin traditionelles Wissen gesammelt und festgehalten, der Anbau, die Verbreitung und Vermarktung einheimischer Sorten werden geschult und gefördert.
<G-vec00443-002-s401><collect.sammeln><en> The project will collect and present success stories from companies that have in recent years shifted their logistics processes from trucks to trains.
<G-vec00443-002-s401><collect.sammeln><de> Erfolgstorys von Unternehmen, die in den letzten Jahren ihre Logistikprozesse vom LKW auf die Bahn umgestellt haben, werden im Projekt gesammelt und vorgestellt.
<G-vec00443-002-s402><collect.sammeln><en> The first step is to collect information on each area, and on individuals in the local public security departments, to establish a more complete database, and do it within a specific timeframe to avoid inadvertently forgetting important information.
<G-vec00443-002-s402><collect.sammeln><de> Im ersten Schritt haben wir Informationen zu jeder Gegend und über jede einzelne Person der örtlichen öffentlichen Sicherheitsabteilungen gesammelt, eine umfassende Datenbank aufgebaut und es innerhalb eines bestimmten Zeitfensters getan, um ungewolltes Vergessen wichtiger Informationen zu vermeiden.
<G-vec00443-002-s403><collect.sammeln><en> If the Acrolinx administrator has configured the software to collect custom user information, users must fill out the form before starting the first check or when registering with the Acrolinx Server.
<G-vec00443-002-s403><collect.sammeln><de> Wenn der Acrolinx-Administrator die Software so eingerichtet hat, dass individuelle Benutzerinformationen gesammelt werden, müssen Benutzer das entsprechende Formular ausfüllen, bevor sie Prüfungen durchführen oder sich am Server registrieren.
<G-vec00443-002-s404><collect.sammeln><en> This page describes the information that these collect, how we use them and why, at times, we need to store these cookies.
<G-vec00443-002-s404><collect.sammeln><de> Auf dieser Seite erfahren Sie, welche Informationen gesammelt werden, wie wir sie verwenden und warum wir manchmal diese Cookies speichern müssen.
<G-vec00443-002-s405><collect.sammeln><en> These cookies can be used by 3rd parties to collect information about users from different websites. This information is then used in a number of ways: advertising, analytics, improving products, etc.
<G-vec00443-002-s405><collect.sammeln><de> Durch solche Cookies werden Informationen über die Benutzer von verschiedenen Webseiten gesammelt, die für verschiedene Zwecke, von Werbung, Analytik bis zur Verbesserung der Produkte verwendet werden.
<G-vec00443-002-s406><collect.sammeln><en> These tools collect certain standard information that your browser sends to our website such as your browser type and language, access times, and the address of the website from which you arrived at an SAP website.
<G-vec00443-002-s406><collect.sammeln><de> Gesammelt werden Standardinformationen, die Ihr Browser an unsere Website sendet, wie zum Beispiel Ihren Browsertyp und Ihre Spracheeinstellungen, Zugriffszeiten oder die Adresse derjenigen Website, die Sie auf die SAP-Webseite verwiesen hat.
<G-vec00443-002-s408><collect.sammeln><en> Did you collect all the food in a section, your shovel will become a powerful magnet, absorbing all the food into your shovel.
<G-vec00443-002-s408><collect.sammeln><de> Haben Sie alle Lebensmittel in einem Abschnitt gesammelt, wird Ihre Schaufel zu einem starken Magneten, der alle Lebensmittel in Ihre Schaufel aufnimmt.
<G-vec00443-002-s409><collect.sammeln><en> What personal data we collect and why we collect it Comments When visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.
<G-vec00443-002-s409><collect.sammeln><de> Wenn Besucher Kommentare auf der Website schreiben, werden die Daten gesammelt, die im Kommentar-Formular angezeigt werden, außerdem die IP-Adresse des Besuchers und der User-Agent-String (damit wird der Browser identifiziert), um die Erkennung von Spam zu unterstützen.
<G-vec00443-002-s410><collect.sammeln><en> The longer and more difficult each section is to ride, the more points a rider can collect.
<G-vec00443-002-s410><collect.sammeln><de> Je länger und je schwieriger ein Stück mit dem Bike zu fahren ist, desto mehr Punkte können gesammelt werden.
<G-vec00443-002-s411><collect.sammeln><en> Specialized in this one area, the company was able to collect and convert a lot of experience in this area.
<G-vec00443-002-s411><collect.sammeln><de> Spezialisiert auf diesen einen Bereich, konnte eine Fülle an Erfahrungen auf diesem Gebiet gesammelt und umgesetzt werden.
<G-vec00443-002-s412><collect.sammeln><en> Being somewhat obsessed with all the coloring options and dyes in Guild Wars 2, I started to collect data right from the start.
<G-vec00443-002-s412><collect.sammeln><de> Nachdem ich von den Färbemöglichkeiten und den Farben in Guild Wars 2 regelrecht besessen bin, habe ich von Anfang an Daten dazu gesammelt.
<G-vec00443-002-s414><collect.sammeln><en> Every time you visit our site, these components collect and store data for marketing and improvement purposes, and this data is then used by cookies to generate usage profiles with a pseudonym.
<G-vec00443-002-s414><collect.sammeln><de> Bei jedem einzelnen Aufruf unserer Seite werden durch diese Komponenten Daten zu Marketing- und Optimierungszwecken gesammelt und gespeichert, aus denen sodann durch den Einsatz von Cookies unter einem Pseudonym Nutzungsprofile erstellt werden können.
<G-vec00443-002-s415><collect.sammeln><en> We also have third parties that collect personal information this way.
<G-vec00443-002-s415><collect.sammeln><de> Auch von Dritten werden diese persönlichen Informationen gesammelt.
<G-vec00443-002-s416><collect.sammeln><en> You should refer to the privacy policies of the non-Microsoft services for any questions about how they collect and use data.
<G-vec00443-002-s416><collect.sammeln><de> Für alle Fragen bezüglich wie Daten gesammelt oder verwendet werden, beziehen Sie sich bitte auf die Datenschutzrichtlinien der nicht von Microsoft stammenden Dienste.
<G-vec00443-002-s417><collect.sammeln><en> The aim of this package of measures is to collect all available information about the approximately 30,000 chemical substances on the European market.
<G-vec00443-002-s417><collect.sammeln><de> Mit Hilfe dieses Maßnahmenkomplexes sollen sämtliche zugänglichen Informationen über etwa 30.000 chemische Stoffe auf dem europäischen Markt gesammelt werden.
