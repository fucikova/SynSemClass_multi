<G-vec00001-001-s046><drill.bohren><en> In this case In places where screws later are entered, drill apertures in DSP and paste the wooden shkanty.
<G-vec00001-001-s046><drill.bohren><de> In diesem Fall An den Stellen, wohin später die Schrauben eingeführt werden, bohren die Öffnungen in DSP und kleben die Hölzernen ein schkanty.
<G-vec00001-001-s047><drill.bohren><en> – first Drill parades and l ' the start of the study Show.
<G-vec00001-001-s047><drill.bohren><de> – Bohren Sie zuerst Paraden und l ' der Beginn der Studie zeigen.
<G-vec00001-001-s048><drill.bohren><en> We below sea shell or shell to drill a piece of soft wood, pine for example.
<G-vec00001-001-s048><drill.bohren><de> Wir unterhalb seemuschel oder Schale ein weiches Holz, Kiefer zum Beispiel zu bohren.
<G-vec00001-001-s049><drill.bohren><en> Then, take a clothes pin and drill a hole with a diameter of 1.5 mm into one side.
<G-vec00001-001-s049><drill.bohren><de> Nehmen Sie dann eine Wäscheklammer und bohren Sie ein Loch von 1.5 mm Durchmesser in die eine Klammerhälfte.
<G-vec00001-001-s050><drill.bohren><en> Please be aware that the throttle pedal can move free of the handbrake. - Use the bracket as a mould to drill the holes in the body (Ø 6.5 mm).
<G-vec00001-001-s050><drill.bohren><de> Das Gaspedal sollte sich noch frei bewegen können · Benützen Sie die Handbremsführung als Schablone für die Löcher die sie in die Karosserie bohren Müsse (Ø 6.5 mm).
<G-vec00001-001-s051><drill.bohren><en> To do this, use the drill and a 10-mm wood drill bit to make a hole inside the circle close to the pencil line.
<G-vec00001-001-s051><drill.bohren><de> Bohren Sie hierzu mit der Bohrmaschine und einem 10-mm-Holzbohrer innen im Kreis dicht an der Bleistiftlinie ein Loch.
<G-vec00001-001-s052><drill.bohren><en> If you want to drill the chassis by your self we recommend th Hammond Chassis 1590B (Part# ha1590b)
<G-vec00001-001-s052><drill.bohren><de> Will man das Gehäuse selbst bohren so empfiehlt sich die Verwendung des Hammond Chassis 1590B (Artikel# ha1590b).
<G-vec00001-001-s053><drill.bohren><en> Then it's time to drill.
<G-vec00001-001-s053><drill.bohren><de> Dann geht es jetzt ans Bohren.
<G-vec00001-001-s054><drill.bohren><en> Toolholder-reversing clutch, coupled to drill presses.
<G-vec00001-001-s054><drill.bohren><de> Werkzeughalter-Wendekupplung, gekoppelt mit Pressen zu bohren.
<G-vec00001-001-s055><drill.bohren><en> The plug and turn need to drill a hole into which a pin skip and lock nut design.
<G-vec00001-001-s055><drill.bohren><de> Der Stecker und drehen Sie benötigen ein Loch zu bohren, in die ein Stift überspringen und Mutter Design sperren.
<G-vec00001-001-s056><drill.bohren><en> With suitable tungsten bucking bars, you will make the task easier and riveting better, meaning less rivets to drill out.
<G-vec00001-001-s056><drill.bohren><de> Mit geeigneten Wolfram bucking Bars, werden Sie die Aufgabe zu erleichtern und Nieten besser, was bedeutet, weniger Nieten machen zu bohren.
<G-vec00001-001-s057><drill.bohren><en> The door for cats is installed easily - just drill through the door a window of the right size at the level of the muzzle of your pet.
<G-vec00001-001-s057><drill.bohren><de> Die Tür für Katzen ist leicht zu installieren - bohren Sie einfach ein Fenster mit der richtigen Größe in Höhe der Schnauze Ihres Haustiers durch die Tür.
<G-vec00001-001-s058><drill.bohren><en> If you will be hanging your hammock with hooks, drill a 3/16-inch or smaller starter hole where the hooks will go and if you do not have a drill, a hammer and nail will work fine.
<G-vec00001-001-s058><drill.bohren><de> Wenn Sie Ihre Hängematte mit Haken hängen werden, bohren Sie ein 3/16-inch oder kleinere eine Starterbohrung, wohin die Haken gehen und wenn Sie nicht ein Bohrgerät haben, einen Hammer und Nagel arbeitet fein.
<G-vec00001-001-s059><drill.bohren><en> What I bought is clearly not a wedge pin and means and not through the back side because I did not see anything except for traces of the core means it is necessary to drill.
<G-vec00001-001-s059><drill.bohren><de> Was ich gekauft habe ist eindeutig keine Keilstift und bedeutet, und nicht durch die Rückseite, weil ich habe nichts gesehen außer Spuren der Kern bedeutet es notwendig, zu bohren ist.
<G-vec00001-001-s060><drill.bohren><en> If you are looking to buy Drill Cordless screwdriver Stayer at the best price, here you'll get it at the right price.
<G-vec00001-001-s060><drill.bohren><de> Wenn Sie sind der Suche nach Akkuschrauber bohren kaufen Stayer auf dem besten Preis, hier finden Sie bekommen es auf dem richtigen Preis.
<G-vec00001-001-s061><drill.bohren><en> The ceilings are drilled holes for dowels, nails, always bringing to drill holes for the rack bolts.
<G-vec00001-001-s061><drill.bohren><de> Die Decken sind Bohrungen für Dübel, Nägel, immer für die Rack-Schrauben bringen Löcher zu bohren.
<G-vec00001-001-s062><drill.bohren><en> The JV Partner has surveyed a total of 10 locations and has an option with its drilling contractor to drill a n additional 6 wells at Bannock Creek.
<G-vec00001-001-s062><drill.bohren><de> Der JV Partner hat insgesamt 10 Stellen untersucht und hat eine Option mit dem Bohrunternehmen vereinbart bis zu 6 weitere Brunnen auf Bannock Creek zu bohren.
<G-vec00001-001-s063><drill.bohren><en> Open standards are set to enable the seamless integration of industrial power tools used to drill, tighten, measure, and solder into an overall system of networked tools in the future.
<G-vec00001-001-s063><drill.bohren><de> Künftig sollen sich industrielle Elektrowerkzeuge zum Bohren, Verschrauben, Vermessen oder Löten dank offener Standards lückenlos in ein Gesamtsystem vernetzter Werkzeuge integrieren lassen.
<G-vec00001-001-s064><drill.bohren><en> To guide the cords, before assembling the roof you drill two 10-mm-diameter holes through each of the two roof halves as described in the construction drawing.
<G-vec00001-001-s064><drill.bohren><de> Als Führung für die Kordeln bohren Sie, wie in der Konstruktionszeichnung beschrieben, noch vor dem Zusammenbau des Daches je zwei Löcher mit 10 mm Durchmesser durch die beiden Dachhälften.
<G-vec00001-001-s460><drill.durchbohren><en> For this purpose in longitudinal frameworks drill apertures on diameter of a wire - 6, 8, 10 mm depth 2,5 - 3 see In these apertures insert the ends of arches from an iron wire with which it is necessary to paint for the purpose of protection from a rust.
<G-vec00001-001-s460><drill.durchbohren><de> Dazu durchbohren Sie in den längslaeufigen Rahmen die Öffnungen nach dem Durchmesser des Drahtes - 6, 8, 10 mm von der Tiefe 2,5 - 3 siehe In diese Öffnungen stellen Sie die Enden der Bögen aus dem eisernen Draht ein, den man zwecks des Schutzes vom Rost anstreichen muss.
<G-vec00001-001-s461><drill.durchbohren><en> For this purpose we take a round timber (1,5 sm in a diameter) which from both parties is entered in rejki (in advance it is necessary to drill in them corresponding apertures), or pieces of the same thickness, as shtaketnik into which thorns which in turn, enter into the eyes accordingly hollowed by a chisel run undertake.
<G-vec00001-001-s461><drill.durchbohren><de> Dazu nehmen wir krugljak (1,5 cm im Durchmesser), der von beiden Seiten in rejki (im Voraus eingeführt wird folgen in sie die entsprechenden Öffnungen) zu durchbohren, oder es übernehmen die Abschnitte der selben Dicke, dass auch schtaketnik, in die die Dornen eindringen, die in die ausgehöhlten vom Stemmeisen entsprechend Henkel seinerseits eingehen.
<G-vec00001-001-s462><drill.durchbohren><en> Now we can drill in each case a small 3mm hole at the two markings.
<G-vec00001-001-s462><drill.durchbohren><de> Nun können wir auch schon bei den beiden Markierungen jeweils ein kleines 3mm Loch durchbohren.
<G-vec00001-001-s463><drill.durchbohren><en> Put a drill on a marking (on a door face sheet) and, having fixed a door, drill it through.
<G-vec00001-001-s463><drill.durchbohren><de> Stellen Sie swerlo auf die Markierung (auf der Vorderseite der Tür) und, die Tür festgelegt, durchbohren Sie sie durch und durch.
<G-vec00001-001-s464><drill.durchbohren><en> to cut out a circle from thick plywood, to drill in it holes for a rope, to stretch a rope, having fixed e by means of knots on a reverse side; the circle should be sheathed skin and strongly to sew in a pear.
<G-vec00001-001-s464><drill.durchbohren><de> Den Kreis aus dem dicken Furnier auszuschneiden, darin die Löcher für den Strick zu durchbohren, den Strick zu strecken, je mit Hilfe der Knoten auf der Rückseite gefestigt; den Kreis muss man von der Haut und fest benähen, in die Birne einnähen.
<G-vec00001-001-s465><drill.durchbohren><en> Then drill on the right and left racks of a box on three openings.
<G-vec00001-001-s465><drill.durchbohren><de> Dann durchbohren Sie auf den rechten und linken Theken der Schachtel auf drei Öffnungen.
<G-vec00001-001-s466><drill.durchbohren><en> The versatility and ease of use are two of the main advantages of Kerlite, being thin and light it is very easy to cut and drill, reducing processing time by 40% compared to traditional tiles.
<G-vec00001-001-s466><drill.durchbohren><de> Die Vielseitigkeit und Benutzerfreundlichkeit sind die Stärken von Kerlite: dünn und leicht ist die Platte besonders einfach zu schneiden und zu durchbohren, wobei Arbeitszeiten um 40% im Vergleich zu herkömmlichen Fliesen reduziert werden.
<G-vec00001-001-s467><drill.durchbohren><en> First mark the holes for fixing the bird feed on the floor panel and drill them with the 8-mm or 10-mm drill bit.
<G-vec00001-001-s467><drill.durchbohren><de> Zeichnen Sie zunächst die Löcher zur Befestigung der Futterkugeln auf der Bodenplatte ein und durchbohren Sie diese mit dem 8- oder 10-mm-Bohrer.
<G-vec00001-001-s468><drill.durchbohren><en> The drill which has been brought down from an axis, it is impossible to drill an aperture precisely.
<G-vec00001-001-s468><drill.durchbohren><de> Swerlom, abgeschlagen ist es von der Achse, unmöglich genau, die Öffnung zu durchbohren.
<G-vec00001-001-s469><drill.durchbohren><en> Drill them between small strips of the center.
<G-vec00001-001-s469><drill.durchbohren><de> Durchbohren Sie sie zwischen den kleinen Streifen der mittleren Schicht.
<G-vec00001-001-s470><drill.durchbohren><en> It is possible to arrive and so: to turn out two-three extreme screws; from a lateral face, having receded from a box edge for length of a smooth part of a screw, to drill apertures in diameter of 15-20 mm and depth, in one and a half time of a quarter exceeding width (fig.
<G-vec00001-001-s470><drill.durchbohren><de> Man kann und so handeln: zwei-drei äußerste Schrauben herauszuziehen; von der Seitenseite, von der Kante der Schachtel auf die Länge des glatten Teiles der Schraube zurückgetreten, die Öffnungen vom Durchmesser 15-20 mm und der Tiefe, in anderthalb Male des die Breite übertretenden Viertels zu durchbohren (siehe die Abb.
<G-vec00001-001-s471><drill.durchbohren><en> It is best of all to drill at first, and then to expand it with a chisel and a hammer.
<G-vec00001-001-s471><drill.durchbohren><de> Es ist zuerst, zu durchbohren, und später zuerst, von seinem Meißel und dem Hammer auszudehnen.
<G-vec00001-001-s472><drill.durchbohren><en> The following that it is necessary to make — to drill openings in sidewalls for fixing of shelves and also to make openings in end faces of horizontal details.
<G-vec00001-001-s472><drill.durchbohren><de> Das Folgende, dass man machen muss, — die Öffnungen in den Seitenwänden für die Fixierung der Regale zu durchbohren, sowie die Öffnungen in den Stirnseiten der horizontalen Details zu machen.
<G-vec00001-001-s473><drill.durchbohren><en> Therefore it is recommended to drill at first an aperture in a lath on diameter of an applied nail.
<G-vec00001-001-s473><drill.durchbohren><de> Deshalb ist es empfehlenswert, zuerst die Öffnung in der Leiste nach dem Durchmesser des verwendeten Nagels zu durchbohren.
<G-vec00001-001-s474><drill.durchbohren><en> Mark holes on the canister and drill with metal drill the tin.
<G-vec00001-001-s474><drill.durchbohren><de> Löcher auf dem Kanister anzeichnen und mit Metallbohrer das Blech durchbohren.
<G-vec00001-001-s475><drill.bohren><en> Ring-shaped drill bits used to cut a ring-shaped groove into stone.
<G-vec00001-001-s475><drill.bohren><de> Ringförmige Bohrwerkzeuge, mit denen nur ein Ringspalt gebohrt wird.
<G-vec00001-001-s476><drill.bohren><en> "Steve Khan, Director and CEO of Pacific Potash, commented ""Our goal with the 2011 drill program was to confirm the presence of potash within Alberta, and we are excited to announce that we are the first company ever to drill for and discover potash within the Province."
<G-vec00001-001-s476><drill.bohren><de> "Steve Khan, Director und CEO von Pacific Potash, erklärte: ""Das Ziel unseres Bohrprogramms 2011 war die Bestätigung von Kalivorkommen in Alberta und wir freuen uns ungemein, berichten zu können, dass wir das erste Unternehmen sind, das jemals in dieser Provinz nach Kali gebohrt hat und Kali entdeckt hat."
<G-vec00001-001-s477><drill.bohren><en> The PMD 10 alerts the user to a positive search result by emitting an audible signal and changing the color of its luminous ring: green means “It is OK to drill”, red means “Please do not drill: an object has been detected”, yellow means “It is not advisable to drill”. If electricity is detected, the luminous ring flashes.
<G-vec00001-001-s477><drill.bohren><de> Auf ein positives Suchergebnis macht das PMD 10 mit einem akustischen Signal aufmerksam und einem Farbwechsel seines Leuchtrings: Grün bedeutet „Es darf gebohrt werden“, rot „Bitte nicht bohren: Es wurde ein Objekt gefunden“, gelb „Das Bohren wird nicht empfohlen“.
<G-vec00001-001-s478><drill.bohren><en> For the protective housing you will need to drill 3 holes.
<G-vec00001-001-s478><drill.bohren><de> Für das Schutzgehäuse müssen 3 Löcher gebohrt werden.
<G-vec00001-001-s479><drill.bohren><en> Since it is either not possible or permitted to drill holes in some rooms, Artiteq offers a solution in the form of a hanging rail that may be glued in place.
<G-vec00001-001-s479><drill.bohren><de> Da in bestimmten Räume nicht gebohrt werden kann oder darf, bietet Artiteq auch hierfür eine Lösung: durch Verkleben einer Aufhängeschiene.
<G-vec00001-001-s480><drill.bohren><en> Dr. Stefan Nolte: At Bosch, this technology is currently deployed to drill geometrically complex holes in fuel injection nozzles.
<G-vec00001-001-s480><drill.bohren><de> Stefan Nolte: Bei Bosch werden mit dieser Technologie derzeit Löcher mit angepasster Form in Düsen für die Benzin-Direkteinspritzung gebohrt.
<G-vec00001-001-s481><drill.bohren><en> They do not just drill straight down.
<G-vec00001-001-s481><drill.bohren><de> Es wird dabei nicht einfach gerade nach unten gebohrt.
<G-vec00001-001-s482><drill.bohren><en> Diamond drill data from a total of 127 drill holes and 13 surface trenches were used for the resource calculation of which 59 are new holes completed in 2008.
<G-vec00001-001-s482><drill.bohren><de> Für die Ressourcenberechnung wurden die Daten von Diamantbohrungen von insgesamt 127 Bohrlöchern und 13 Oberflächenschürfungen verwendet; 59 Bohrlöcher davon wurden im Jahr 2008 gebohrt.
<G-vec00001-001-s483><drill.bohren><en> To reach the reserves it is necessary to overcome not only the water depths, but also to drill almost equally deep into the sea floor, as shown in this example.
<G-vec00001-001-s483><drill.bohren><de> Um die Vorkommen zu erreichen, muss nicht nur die Wassertiefe überwunden, sondern, wie hier in diesem Beispiel, fast genauso tief in den Boden gebohrt werden.
<G-vec00001-001-s484><drill.bohren><en> AGATA NORTH PROJECT A total of 134 drill holes have been completed to the end of the Phase 1 drilling program, which finished in August 2007.
<G-vec00001-001-s484><drill.bohren><de> PROJEKT AGATA NORTH Bis zum Ende des Phase-I-Bohrprogramms, das im August 2007 abgeschlossen wurde, wurden insgesamt 134 Bohrlöcher gebohrt.
<G-vec00001-001-s485><drill.bohren><en> The injection material is injected with the designated pressure through a grid of drill holes.
<G-vec00001-001-s485><drill.bohren><de> Hierzu wird ein den Gegebenheiten angepasstes Raster gebohrt und das entsprechende Injektionsmittel mit angepasstem Druck injiziert.
<G-vec00001-001-s486><drill.bohren><en> The business with oil is one of the most profitable ones all over the world. Veins, hundreds of kilometers long, transport the valuable blood, the oil concerns’ greed leads to the fact that they drill further and deeper into the ground.
<G-vec00001-001-s486><drill.bohren><de> Das Geschäft mit dem Öl ist eines der lukrativsten der Welt, hunderte Kilometer lange Adern transportieren das so wertvolle Blut, die Gier der Ölkonzerne führt dazu, dass immer weiter und tiefer in die Erde gebohrt wird.
<G-vec00001-001-s487><drill.bohren><en> One of the technical challenges of the project is the need to drill into hard rock in places.
<G-vec00001-001-s487><drill.bohren><de> Eine technische Herausforderung besteht darin, dass teilweise in hartem Fels gebohrt werden muss.
<G-vec00001-001-s488><drill.bohren><en> T he 2017 drill holes reported above were designed to test the King, Winnipeg, Portal, Southwest and South zones .
<G-vec00001-001-s488><drill.bohren><de> Die oben angegebenen Bohrlöcher 2017 wurden gebohrt, um die Zonen King, Winnipeg, Portal, Southwest und South zu erproben.
<G-vec00001-001-s489><drill.bohren><en> The result is displayed to the user by three LEDs in a traffic light system: green means “It's OK to drill”, red means “Please do not drill: an object has been found”, and yellow means “Drilling is not recommended”. If electricity is detected, the red LED flashes.
<G-vec00001-001-s489><drill.bohren><de> Das Ergebnis wird dem Anwender nach dem Ampelprinzip über drei LED-Leuchten angezeigt: Grün bedeutet „Es darf gebohrt werden“, rot „Bitte nicht bohren: Es wurde ein Objekt gefunden“, gelb „Das Bohren wird nicht empfohlen“.
<G-vec00001-001-s490><drill.bohren><en> A total of 14 drill holes have been completed targeting a broad alteration zone over an area of 850 m by 500 m that hosts the past producing Upper Canada mine.
<G-vec00001-001-s490><drill.bohren><de> Es wurden insgesamt 14 Bohrlöcher gebohrt, die eine breite Alterationszone auf einem 850 mal 500 Meter großen Gebiet anpeilten, welches die ehemals produzierende Mine Upper Canada beherbergt.
<G-vec00001-001-s491><drill.bohren><en> - 46 holes were completed to infill a portion of the existing Mineral Resource to a 50m x 50m drill spacing.
<G-vec00001-001-s491><drill.bohren><de> - 46 Bohrlöcher wurden gebohrt, um einen Teil der bestehenden Mineralressource in einem Bohrabstand von 50 mal 50 Metern zu ergänzen.
<G-vec00001-001-s492><drill.bohren><en> Additional results from new drilling are as follows: CSD035, drilled to the southeast and perpendicular to the current drill grid, was designed to test the continuity of mineralization in this orientation and target mineralization at depth under CSD013.
<G-vec00001-001-s492><drill.bohren><de> Weitere Ergebnisse aus den neuen Bohrungen sind: Loch CSD035 wurde südöstlich und senkrecht zum aktuellen Bohrraster gebohrt, um die Kontinuität der Mineralisierung in dieser Ausrichtung zu erkunden, und hatte einen Bereich in der Tiefe unterhalb von Loch CSD013 zum Ziel.
<G-vec00001-001-s493><drill.bohren><en> The Company anticipates a total of up to 15-20 drill holes to be completed during the 2012 program.
<G-vec00001-001-s493><drill.bohren><de> Das Unternehmen schätzt, dass während des Programms 2012 insgesamt bis zu 15 - 20 Löcher gebohrt werden.
