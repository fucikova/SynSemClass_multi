<G-vec00206-002-s133><equal.entsprechen><en> Some set a price for exchanging, which may be equal to the minimum bet at that point.
<G-vec00206-002-s133><equal.entsprechen><de> Eine Variante besteht darin, dass ein Preis für den Austausch festgesetzt wird, der dem Mindesteinsatz zu diesem Zeitpunkt entsprechen kann.
<G-vec00206-002-s134><equal.entsprechen><en> Our ingredients are pure and unpolluted and 100% equal to the ingredients in Colombo Coral Pro reef salt.
<G-vec00206-002-s134><equal.entsprechen><de> Unsere Inhaltsstoffe sind rein und schadstofffrei und entsprechen zu 100% den Inhaltsstoffen in Colombo Pro Reef Salt.
<G-vec00206-002-s135><equal.entsprechen><en> Thereby, the performance characteristics of the bioplastics shall equal or even outperform the characteristics of conventional oil-based plastics.
<G-vec00206-002-s135><equal.entsprechen><de> Dabei müssen die Gebrauchseigenschaften der Biopolymere denen der derzeit verwendeten erdölbasierten Kunststoffe mindestens entsprechen oder diese gar übertreffen.
<G-vec00206-002-s136><equal.entsprechen><en> Bit Bit is a common unit used to designate a sub-unit of a bitcoin - 1,000,000 bits is equal to 1 bitcoin (BTC).
<G-vec00206-002-s136><equal.entsprechen><de> Bit Bit ist eine häufig verwendete Einheit und stellt den Bruchteil eines ganzen Bitcoins dar - 1.000.000 Bits entsprechen einem Bitcoin (BTC).
<G-vec00206-002-s137><equal.entsprechen><en> Revelation 12:6, 14 indicates that three and a half times equal “1,260 days.” “Seven times” would therefore last twice as long, or 2,520 days.
<G-vec00206-002-s137><equal.entsprechen><de> Sie sagt, dass dreieinhalb „Zeiten“ 1 260 Tagen entsprechen; „sieben Zeiten“ sind dann das Doppelte: 2 520 Tage (Offenbarung 12:6, 14).
<G-vec00206-002-s138><equal.entsprechen><en> And quickly, too; 15 hours of Babbel are equal to one university term of a language course (shown by a study from the City University of New York).
<G-vec00206-002-s138><equal.entsprechen><de> Dies zeigt auch eine Studie der City University of New York, die bestätigt, dass 15 Stunden Lernen mit Babbel einem ganzen Erstsemester an einem US-College entsprechen.
<G-vec00206-002-s139><equal.entsprechen><en> Two Double Paw Print symbols and one Single Paw Print symbol equal 5 paw prints.
<G-vec00206-002-s139><equal.entsprechen><de> Zwei Doppeltatzen-Symbole und ein einzelnes Tatzen-Symbol entsprechen 5 Tatzen.
<G-vec00206-002-s140><equal.entsprechen><en> · We are committed to ensuring that our recruitment processes are aligned with our approach to equal opportunities.
<G-vec00206-002-s140><equal.entsprechen><de> Wir möchten sicherstellen, dass unsere Rekrutierungsprozesse unserem Gleichstellungsansatz entsprechen.
<G-vec00206-002-s141><equal.entsprechen><en> (Annual compensation must equal or exceed 35 x 50 x minimum wages).
<G-vec00206-002-s141><equal.entsprechen><de> (Die jährliche Vergütung muss mindestens 35 x 50 x Mindestgehalt entsprechen).
<G-vec00206-002-s142><equal.entsprechen><en> Because there are actually 8 bits in each byte, so 8 megabits is equal to 1 megabyte (8 Mb = 1 MB).
<G-vec00206-002-s142><equal.entsprechen><de> Jedes Byte enthält 8 Bits, also entsprechen 8 Megabits 1 Megabyte (8 Mb = 1 MB).
<G-vec00206-002-s143><equal.entsprechen><en> Czech exports equal 70% of the GDP.
<G-vec00206-002-s143><equal.entsprechen><de> Die tschechischen Exporte entsprechen 70 % des BIP.
<G-vec00206-002-s144><equal.entsprechen><en> Please note that the total amount stated does not necessarily equal the sum of the detailed attributed holdings.
<G-vec00206-002-s144><equal.entsprechen><de> Bitte beachten Sie, dass die oben angegebene Gesamtzahl nicht unbedingt der Summe der aufgeführten Zurechnungen entsprechen muss.
<G-vec00206-002-s145><equal.entsprechen><en> These Levels are equal to 10% of the total Levels in the game and can only be used for Advantage Cards.
<G-vec00206-002-s145><equal.entsprechen><de> Diese Punkte entsprechen 10 % der Gesamtstufenpunkte und können nur für Vorteilskarten investiert werden.
<G-vec00206-002-s146><equal.entsprechen><en> The prices mentioned on the invoice are equal to the official price minus the possibly applicable Rebate, or the price of the Sales point, whichever is the lowest.
<G-vec00206-002-s146><equal.entsprechen><de> Die in der Rechnung angegebenen Preise entsprechen dem offiziellen Preis abzüglich des eventuell anwendbaren Rabatts oder dem Preis der Verkaufsstelle, falls dieser niedriger sein sollte.
<G-vec00206-002-s147><equal.entsprechen><en> Health cost is equal to 40% of total damage dealt (unchanged ratio)
<G-vec00206-002-s147><equal.entsprechen><de> Die Lebenskosten entsprechen 40 % des insgesamt verursachten Schadens (Faktor unverändert).
<G-vec00206-002-s148><equal.entsprechen><en> It is also your task, however, to ensure that the school is equal to the educational role entrusted to it, particularly when the education it offers claims to be “Catholic”.
<G-vec00206-002-s148><equal.entsprechen><de> Aber an euch liegt es auch, zu bewirken, dass die Schule dem ihr anvertrauten Erziehungsauftrag entsprechen kann, insbesondere wenn die angebotene Bildung sich als katholisch versteht.
<G-vec00206-002-s149><equal.entsprechen><en> Their quality features are equal to those of solid construction timber and are even higher regarding dimensional accuracy and crack formation.
<G-vec00206-002-s149><equal.entsprechen><de> Ihre Qualitätsmerkmale entsprechen denen von KVH® und sind bei der Formstabilität und Rissbildung sogar noch höher.
<G-vec00206-002-s150><equal.entsprechen><en> CAPACITY: Ideal for towing vehicles with the weight equal to or under 5 tons – lighter, easier, and prevents damages compared to tow chains.
<G-vec00206-002-s150><equal.entsprechen><de> CAPACITY: Ideal für Abschleppwagen mit dem Gewicht entsprechen zu oder unter 5 Tonnen – heller, einfacher und verhindern die Schäden, die mit Schleppseilketten verglichen werden.
<G-vec00206-002-s151><equal.entsprechen><en> 8.6 The value of the product must be at least equal to the amount of the promotion voucher.
<G-vec00206-002-s151><equal.entsprechen><de> 8.6 Der Warenwert muss mindestens dem Betrag des Aktionsgutscheins entsprechen.
<G-vec00206-002-s399><equal.gleichen><en> Gamma Vir consists of two yellow-white, nearly equal stars in brightness: one with 3.6 mag, the other with 3.7 mag.
<G-vec00206-002-s399><equal.gleichen><de> Gamma Vir besteht aus zwei gelb-weißen, in ihrer Helligkeit fast gleichen Sternen (einer mit 3.6 Magnituden, der andere mit 3.7 Magnituden).
<G-vec00206-002-s400><equal.gleichen><en> In case of lack of conformity, Restart Srl provides, without cost to the customer, the restoration of conformity by repairing or replacing the damaged item with a product of equal or superior characteristics.
<G-vec00206-002-s400><equal.gleichen><de> Im Falle von Material- oder Verarbeitungsfehler, bietet Restart Srl ohne Zusatzkosten die Wiederherstellung der Konformität an, indem er das Produkt repariert oder durch einen mit gleichen oder überlegenen Eigenschaften ersetzt.
<G-vec00206-002-s401><equal.gleichen><en> Equal parts strange, entertaining, and foreboding, Jerry’s music is always engaging, and one can’t help but feel these recordings offer a glimpse through a murky portal into the unadulterated creative experience.
<G-vec00206-002-s401><equal.gleichen><de> Zu gleichen Teilen seltsam, unterhaltsam und ahnungsvoll, ist die Musik von Jerry Salomon immer spannend, und man kann nicht umhin zu spüren, dass diese Aufnahmen einen Blick durch ein trübes Portal in die unverfälschte kreative Erfahrung ermöglichen.
<G-vec00206-002-s402><equal.gleichen><en> The Lomond Evojet Office printer is equal to the lowest printing cost inkjet printer on the market today and 40% lower when compared with other laser and other non-digital desktop printers.
<G-vec00206-002-s402><equal.gleichen><de> Neuer revolutionärer Bürodrucker Lomond EvoJet hat ungefähr die gleichen Betriebskosten als bei gewöhnlichen Tinten-Druckern auf dem Markt und um 40% niedriger im Vergleich zu anderen Laser-und digitalen Druckmaschinen.
<G-vec00206-002-s403><equal.gleichen><en> His fashion universe is created from equal part 90s grunge and romantic goth, clashing with a traditional vision of Paris -- often too canonized and nostalgic.
<G-vec00206-002-s403><equal.gleichen><de> Seine Mode besteht zu gleichen Teilen aus 90er-Grunge und romantischem Goth und reibt sich damit an der traditionellen Pariser Mode, die oft zu sehr am klassischen Modekanon festhält und nostalgisch wirkt.
<G-vec00206-002-s404><equal.gleichen><en> †In a multinational country the political sovereignty of the people is not possible without recognizing democracy, the right to self determination of the nations and their equal rights.
<G-vec00206-002-s404><equal.gleichen><de> In einem multinationalen und pluralistischen Land ist die politische Souveränität des Volkes ohne Anerkennung der Demokratie, ohne das Recht auf Selbstbestimmung der Völker und ihrer gleichen Rechte nicht möglich.
<G-vec00206-002-s405><equal.gleichen><en> The scheduled depreciation is generally made in equal annual instalments over the useful life (straight-line depreciation).
<G-vec00206-002-s405><equal.gleichen><de> Die planmäßige Abschreibung erfolgt grundsätzlich in gleichen Jahresraten über die Nutzungsdauer (lineare Abschreibung).
<G-vec00206-002-s406><equal.gleichen><en> Portfolio Manager, Belvoir Capital Guba: Our approach gives equal weight to the technical and fundamental analysis of all stocks.
<G-vec00206-002-s406><equal.gleichen><de> Guba: Bei unserem Ansatz hat die technische Analyse sämtlicher Aktien den gleichen Stellenwert wie die Fundamentalanalyse.
<G-vec00206-002-s407><equal.gleichen><en> The condition is that they agree to set up a meritocratically staffed future planning agency under equal East/West control.
<G-vec00206-002-s407><equal.gleichen><de> Die Bedingung ist, dass sie der Gründung einer meritokratisch geführten Zukunfts-Planungs-Agentur zustimmt, die zu gleichen Teilen unter östlicher/westlicher Kontrolle steht.
<G-vec00206-002-s408><equal.gleichen><en> Gain the equal numbers red and black, earn blocks.
<G-vec00206-002-s408><equal.gleichen><de> Gewinnen Sie die gleichen Zahlen rot und schwarz, verdienen Blöcke.
<G-vec00206-002-s409><equal.gleichen><en> Ebarbold answered evasively: "But here on earth we Alemanni have equal rights.
<G-vec00206-002-s409><equal.gleichen><de> Ausweichend antwortete der Gereizte: »Hier auf Erden aber sind wir gleichen Rechts, wir Alamannen.
<G-vec00206-002-s410><equal.gleichen><en> It is based on the Botball game table, the rules are equal to the Botball game and will be announced at the workshop.
<G-vec00206-002-s410><equal.gleichen><de> Er setzt auf dem Botball Spieltisch auf und hat auch die gleichen Regeln, welche beim Workshop bekannt gegeben werden.
<G-vec00206-002-s411><equal.gleichen><en> Support Hybrid Fossil Group is committed to providing persons with disabilities equal opportunity to benefit from the goods and services we offer.
<G-vec00206-002-s411><equal.gleichen><de> Die Fossil Group verpflichtet sich, Menschen mit Behinderungen die gleichen Möglichkeiten zu bieten, von den von uns angebotenen Waren und Dienstleistungen zu profitieren.
<G-vec00206-002-s412><equal.gleichen><en> Songs came in equal parts from Quest For Love and Electric One.
<G-vec00206-002-s412><equal.gleichen><de> Musikalisch gab es zu gleichen Teilen Songs von Quest For Love und Electric One.
<G-vec00206-002-s413><equal.gleichen><en> Companies in which, other things being equal, the borrower has more chances to get a loan, get a slight advantage when ranking in the rating table.
<G-vec00206-002-s413><equal.gleichen><de> Unternehmen, bei denen der Kreditnehmer bei sonst gleichen Bedingungen mehr Chancen auf einen Kredit hat, erhalten einen leichten Vorteil, wenn sie in der Bewertungstabelle eingetragen werden.
<G-vec00206-002-s414><equal.gleichen><en> Article 58 EPC gives natural and legal persons equal rights to file a European patent application.
<G-vec00206-002-s414><equal.gleichen><de> 4.6 Artikel 58 EPÜ verleiht natürlichen und juristischen Personen die gleichen Rechte zur Anmeldung europäischer Patente.
<G-vec00206-002-s415><equal.gleichen><en> This capsule has a much better impact than the equal solitary testosterone like Cypionate.
<G-vec00206-002-s415><equal.gleichen><de> Diese Ergänzung hat eine viel bessere Wirkung im Vergleich zu dem gleichen einzigen Testosteron wie Cypionate.
<G-vec00206-002-s416><equal.gleichen><en> Qin creates his musical material from the gestures of traditional folk music and the Chinese avant-garde in equal measure.
<G-vec00206-002-s416><equal.gleichen><de> Sein musikalisches Material schöpft Qin dabei zu gleichen Teilen aus dem Gestus traditioneller Volksmusik und der chinesischen Avantgarde.
<G-vec00206-002-s417><equal.gleichen><en> This is based on the premise that all human beings possess “inherent dignity and [...] equal and inalienable rights”, without distinction being drawn on any basis such as colour, gender, language or religion.
<G-vec00206-002-s417><equal.gleichen><de> Diese geht von "der angeborenen Würde und den gleichen und unveräußerlichen Rechten" der Menschen aus und spricht diese jedem Menschen zu, ohne dabei einen Unterschied nach Hautfarbe, Geschlecht, Sprache, Religion oder anderen Kriterien zuzulassen.
