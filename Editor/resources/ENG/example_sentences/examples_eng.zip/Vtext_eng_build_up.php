<G-vec00084-002-s038><build_up.aufbauen><en> Every day, exercising will help you burn calories and build muscle and give your metabolism to increase, even at rest.
<G-vec00084-002-s038><build_up.aufbauen><de> Die tägliche Ausübung hilft Ihnen, Kalorien verbrennen und Muskeln aufbauen und geben Sie Ihrem Stoffwechsel einen Schub auch in Ruhe.
<G-vec00084-002-s039><build_up.aufbauen><en> To help students build their confidence and prepare them for the real world.
<G-vec00084-002-s039><build_up.aufbauen><de> Damit die Schüler ihr Vertrauen aufbauen und sie für die reale Welt vorzubereiten.
<G-vec00084-002-s040><build_up.aufbauen><en> Anyone can build on top of OneNote using our Developer APIs, which are already used by hundreds of developers to create experiences that are integrated with OneNote.
<G-vec00084-002-s040><build_up.aufbauen><de> Jeder kann mithilfe unserer bereits von vielen Entwicklern genutzten Entwickler-APIs auf OneNote aufbauen, um Benutzeroberflächen zu erstellen, die in OneNote integriert sind.
<G-vec00084-002-s041><build_up.aufbauen><en> Tags and toppers are additional punchlines that build upon your first punchline.
<G-vec00084-002-s041><build_up.aufbauen><de> Anhänger und Spitzen sind zusätzliche Pointen, die auf deiner ersten Pointe aufbauen.
<G-vec00084-002-s042><build_up.aufbauen><en> You can build the color up of course.
<G-vec00084-002-s042><build_up.aufbauen><de> Natürlich kann man die Farbe auch aufbauen.
<G-vec00084-002-s043><build_up.aufbauen><en> When your Testosterone degree is high, you can build muscular tissue and also shred fat efficiently.
<G-vec00084-002-s043><build_up.aufbauen><de> Wenn Ihr Testosteronspiegel hoch ist, könnten Sie Muskelmasse aufbauen und auch Fett effektiv zerkleinern.
<G-vec00084-002-s044><build_up.aufbauen><en> Over the years I have been able to build a stable international network.
<G-vec00084-002-s044><build_up.aufbauen><de> Über die Jahre konnte ich ein gutes internationales Netzwerk aufbauen.
<G-vec00084-002-s045><build_up.aufbauen><en> The EU also wants to build strategic relationships with emerging economies, to discuss issues of common concern, promote cooperation on regulation and other matters, and resolve bilateral issues.
<G-vec00084-002-s045><build_up.aufbauen><de> Darüber hinaus möchte die EU strategische Beziehungen mit Schwellenländern aufbauen, um gemeinsame Angelegenheiten zu erörtern, die Zusammenarbeit bei Regulierungs- und anderen Fragen zu fördern und bilaterale Meinungsverschiedenheiten zu lösen.
<G-vec00084-002-s046><build_up.aufbauen><en> It provides interested operators with three choices: Live Casino in a Box - a product intended for betting shop operators to set up a live casino operation using PC terminals in physical locations; Live Turnkey Online Casino - an overall solution for operators who’d rather efficiently build, manage and market their own casino brands, at the same time benefiting from a multitude of options offered by Visionary iGaming; and Live Casino Game Feed – a product which can easily be integrated into operators’ existing casino infrastructure.
<G-vec00084-002-s046><build_up.aufbauen><de> Er stellt interessierten Anbieter drei Optionen zur Wahl: Live Casino in a Box: Ein Produkt, dass sich an Wett-Anbieter mit lokalen Geschäften richtet, die Live Casino Angebote in Form von PC Terminals anbieten möchten; Liver Turnkey Online Casino: Eine Rundum-Lösung für Anbieter, die eher eine eigene Casinomarke aufbauen, managen und vermarkten möchten und dabei gleichzeitig von einer Vielfalt an Optionen von Visionary iGaming profitieren möchten; und Live Casino Game Feed: Ein Produkt, das leicht in ein bestehendes Casino integriert werden kann.
<G-vec00084-002-s047><build_up.aufbauen><en> In order to make your cilia more dense, you can build up a short "silk".
<G-vec00084-002-s047><build_up.aufbauen><de> Um Ihre Wimpern dichter zu machen, können Sie eine kurze "Seide" aufbauen.
<G-vec00084-002-s048><build_up.aufbauen><en> It is they who build direct and long-lasting relationships with our patients and improve their quality of life every single day.
<G-vec00084-002-s048><build_up.aufbauen><de> Es sind diese Mitarbeiter, die direkte und lang anhaltende Beziehungen zu unseren Patienten aufbauen und ihre Lebensqualität Tag für Tag verbessern.
<G-vec00084-002-s049><build_up.aufbauen><en> School classes, working groups or inquisitive individual researchers can either launch into bionics with the ready-made kit or organize and build up everything from scratch themselves.
<G-vec00084-002-s049><build_up.aufbauen><de> So können Schulklassen, Arbeitsgruppen oder neugierige Einzelforscher entweder mit dem vorab ausgestatteten Baukasten in die Bionik starten oder von A bis Z alles selbst organisieren und aufbauen.
<G-vec00084-002-s050><build_up.aufbauen><en> Regin’s cloud central gives you a platform you can build on.
<G-vec00084-002-s050><build_up.aufbauen><de> Regins Cloud Zentrale bietet Ihnen eine Platform, auf der Sie aufbauen können.
<G-vec00084-002-s051><build_up.aufbauen><en> This way you can build up your defenses and as you move the infantry to the front lines then you can buy your armor as it get closer to attack time.
<G-vec00084-002-s051><build_up.aufbauen><de> Auf diese Weise kann man seine Verteidigung aufbauen und während man seine Infanteristen Richtung Front bewegt kann man immer noch Panzer kaufen, wenn man sich der Zeit des Angriffs nähert.
<G-vec00084-002-s052><build_up.aufbauen><en> Sessioning DH runs will improve your overall speed as you build your confidence by repeating runs, trying multiple lines and sessioning sections that a normal ride would only let you hit once.
<G-vec00084-002-s052><build_up.aufbauen><de> Eine Abfahrt immer wieder zu wiederholen macht euch insgesamt schneller, denn ihr könnt Selbstvertrauen aufbauen, indem ihr verschiedene Lines ausprobiert und Passagen intensiv kennenlernt, die ihr auf einer normalen Tour nur einmal fahren würdet.
<G-vec00084-002-s053><build_up.aufbauen><en> The indoor space of new luxury cab has been enlarged for 360°view, which can build up a pleasant working environment for the operator.
<G-vec00084-002-s053><build_up.aufbauen><de> Der Innenraum des neuen Luxusfahrerhauses ist für 360°view vergrößert worden, das einen angenehmen Arbeitsbereich für den Betreiber aufbauen kann.
<G-vec00084-002-s054><build_up.aufbauen><en> At the same time, we can provide our expertise about how to benefit from IoT solutions and how to build a fully autonomous plant.
<G-vec00084-002-s054><build_up.aufbauen><de> Zeitgleich können wir unsere Expertise anbieten, wie man von IoT-Lösungen profitieren und eine vollautonome Anlage aufbauen kann.
<G-vec00084-002-s055><build_up.aufbauen><en> This conformity to law therefore makes research easier for man, because they can draw the conclusions out of this and build up their knowledge upon them.
<G-vec00084-002-s055><build_up.aufbauen><de> Diese Gesetzmäßigkeit also erleichtert den Menschen das Forschen, denn daraus können sie die Folgerungen ziehen und auf diesen wieder ihr Wissen aufbauen.
<G-vec00084-002-s056><build_up.aufbauen><en> You can also build scenarios hierarchically with scenarios.
<G-vec00084-002-s056><build_up.aufbauen><de> Außerdem können Sie die Szenarien hierarchisch mit Szenarien aufbauen.
<G-vec00084-002-s057><build_up.aufbauen><en> This is the universal pathway that must be activated for a muscle to build itself up.
<G-vec00084-002-s057><build_up.aufbauen><de> Dies ist der universelle Biosyntheseweg der Muskel, der sich aktivieren muss, damit er sich selbst wieder aufbaut.
<G-vec00084-002-s058><build_up.aufbauen><en> An initial common achievement on which further collaborative processes can build.
<G-vec00084-002-s058><build_up.aufbauen><de> Ein erster gemeinsamer Erfolg, auf dem die weitere Zusammenarbeit aufbaut.
<G-vec00084-002-s059><build_up.aufbauen><en> “The target for Airbnb as company from California was to build up a local presence in Germany. Thanks to Schwartz Public Relations we could reach out to all relevant national daily and economic media in a very short period of time.
<G-vec00084-002-s059><build_up.aufbauen><de> “Als Internet-Unternehmen aus Kalifornien, das in Deutschland eine Präsenz aufbaut, konnten wir dank Schwartz PR in kürzester Zeit alle relevanten Medien der nationalen Tages- und Wirtschaftspresse erreichen.
<G-vec00084-002-s060><build_up.aufbauen><en> However, a lot is possible if you build a close bond with the dog, have good nerves and have the time to work with it daily.
<G-vec00084-002-s060><build_up.aufbauen><de> Vieles ist trotzdem möglich, wenn man eine enge Bindung zum Hund aufbaut, gute Nerven und die nötige Zeit hat, um täglich mit ihm zu arbeiten.
<G-vec00084-002-s061><build_up.aufbauen><en> Please help me to value godly women in ways that bless them, honor you, and build up your Church.
<G-vec00084-002-s061><build_up.aufbauen><de> Bitte hilf mir, diese göttlichen Frauen auf eine Weise wertzuschätzen, die sie segnet, dich ehrt und deine Gemeinde aufbaut.
<G-vec00084-002-s062><build_up.aufbauen><en> Learn how to build the business case, make connections and make it happen.
<G-vec00084-002-s062><build_up.aufbauen><de> Lernen Sie, wie man das geschäftliche Szenario aufbaut, Verbindungen knüpft und Ziele verwirklicht.
<G-vec00084-002-s063><build_up.aufbauen><en> The cell is submerged in a dilute sulphuric acid solution and is irradiated with sunlight from the front to cause an electrical tension to build up inside the cell.
<G-vec00084-002-s063><build_up.aufbauen><de> Die Zelle ist in verdünnte Schwefelsäure getaucht und wird von vorne mit Sonnenlicht bestrahlt, so dass sich eine elektrische Spannung aufbaut.
<G-vec00084-002-s064><build_up.aufbauen><en> 3 min 17 March, 2016 Cannabis Tolerance: What It Is And How To Bring It Down Smoking weed all the time can cause a tolerance to build up, requiring more weed to be used to reach the same level of high.
<G-vec00084-002-s064><build_up.aufbauen><de> 3 min 17 March, 2016 Cannabis Toleranz: Was Es Ist Und Wie Man Sie Schlägt Ständiges Kiffen kann bewirken, dass man eine Toleranz aufbaut, so dass man mehr Weed konsumieren muss, um das gleiche Maß an Rausch zu erreichen.
<G-vec00084-002-s065><build_up.aufbauen><en> At that meeting, we agreed on concrete progress in local cross-border traffic around Kaliningrad to make the lives of people in the region easier and, at the same time, build up trust.
<G-vec00084-002-s065><build_up.aufbauen><de> Wir haben damals konkrete Fortschritte im kleinen Grenzverkehr um Kaliningrad auf den Weg gebracht, der den Menschen der Region das Leben erleichtert und zugleich Vertrauen aufbaut.
<G-vec00084-002-s066><build_up.aufbauen><en> This healing causes plaque to build up where the arteries are damaged.
<G-vec00084-002-s066><build_up.aufbauen><de> Diese Heilung bewirkt, dass sich dort, wo die Arterien beschädigt sind, Plaque aufbaut.
<G-vec00084-002-s067><build_up.aufbauen><en> It is important that your dog no longer pulls on the leash, the dog to build a reference to his dog.
<G-vec00084-002-s067><build_up.aufbauen><de> Wichtig ist, damit ihr Hund nicht mehr an der Leine zieht, dass der Hund einen Bezug zu seinem Hundehalter aufbaut.
<G-vec00084-002-s068><build_up.aufbauen><en> It is fundamental to the collective sense of society and mutual reliance on which we will build Europe’s future.
<G-vec00084-002-s068><build_up.aufbauen><de> Nur durch Kohäsion können Gemeinschaftssinn und gegenseitiges Vertrauen entstehen, auf denen die Zukunft Europas aufbaut.
<G-vec00084-002-s069><build_up.aufbauen><en> I am inspired in the way you build upon spirit.
<G-vec00084-002-s069><build_up.aufbauen><de> Ich bin begeistert davon, wie ihr auf den Geist aufbaut.
<G-vec00084-002-s070><build_up.aufbauen><en> Here’s an example. Maybe you have an internet marketing blog where you share useful posts on how to build a successful online business.
<G-vec00084-002-s070><build_up.aufbauen><de> Hier ist ein Beispiel: Du hast einen Internet Marketing Blog, auf dem Du nützliche Posts teilst, wie man ein erfolgreiches Online Business aufbaut.
<G-vec00084-002-s071><build_up.aufbauen><en> It works as an authentic testosterone which not only build up solid muscles and strength but it also keeps in good shape and enhances progression of male sex organs, one of the most excellent choice for bulking phases.
<G-vec00084-002-s071><build_up.aufbauen><de> Es wirkt wie ein authentisches Testosteron, das nicht nur feste Muskeln und Kraft aufbaut, sondern es auch in gutem Zustand hält und die Progression der männlichen Geschlechtsorgane fördert, eine der besten Wahl für Bulking-Phasen.
<G-vec00084-002-s072><build_up.aufbauen><en> Creating a bond that will build lasting relationships and provide mutual satisfaction and trust.
<G-vec00084-002-s072><build_up.aufbauen><de> Wir erstellen ein Band, dass dauerhafte Beziehungen aufbaut und gegenseitige Zufriedenheit und Vertrauen bietet.
<G-vec00084-002-s073><build_up.aufbauen><en> For the participating cinemas we have designed a sophisticated participation scheme which is build on the catchment area of the cinema.
<G-vec00084-002-s073><build_up.aufbauen><de> Für die teilnehmenden Kinos entwickelten wir ein ausgeklügeltes Beteiligungsmodell, welches auf dem Einzugsgebiet der Kinos aufbaut.
<G-vec00084-002-s074><build_up.aufbauen><en> Most importantly, Arrow continues to build an unparalleled ecosystem of Edge and IoT partners and suppliers capable of implementing cutting-edge, end-to-end Edge and IoT solutions across a variety of markets and industries.
<G-vec00084-002-s074><build_up.aufbauen><de> Am wichtigsten ist jedoch, dass Arrow weiterhin ein einzigartiges Ökosystem von Edge- und IoT-Partnern und -Lieferanten aufbaut, das in der Lage ist, innovative Edge-to-End-Edge- und IoT-Lösungen in einer Vielzahl von Märkten und Branchen zu implementieren.
<G-vec00084-002-s075><build_up.aufbauen><en> That's where they can learn how to manage things, promote, and build up and manage their own business.
<G-vec00084-002-s075><build_up.aufbauen><de> Dort können sie lernen, wie man Dinge managt, Werbung macht, wie man ein eigenes Geschäft aufbaut und organisiert.
<G-vec00084-002-s076><build_up.aufbauen><en> In a certain way you don’t build up any suspense during the 25 minutes of the film. However, it is exactly the last few minutes that contribute to the understanding of the previous scenes by revealing the water problem in Burkina Faso as well as the lack of customers for agricultural products.
<G-vec00084-002-s076><build_up.aufbauen><de> In gewisser Weise wird in den gut 25 Minuten, die der Film dauert, ja keinerlei Spannungsbogen aufgebaut, und dennoch geben dann gerade die letzten Minuten Aufschluss über die Wasserproblematik in Burkina Faso, den Mangel an Abnehmern für die landwirtschaftlichen Produkte und tragen damit zum Verständnis der vorher gesehenen Szenen bei.
<G-vec00084-002-s077><build_up.aufbauen><en> Our core shooters are of modular build and can therefore be specifically configured in accordance with customer requirements.
<G-vec00084-002-s077><build_up.aufbauen><de> Unsere Kernschießmaschinen sind modular aufgebaut und können daher entsprechend den Kundenwünschen konfiguriert werden.
<G-vec00084-002-s078><build_up.aufbauen><en> Although FinTechs have raised nearly US$110 billion since 2009, the report found that most are likely to fail if they do not build an effective partnership ecosystem.
<G-vec00084-002-s078><build_up.aufbauen><de> Obwohl Fintechs seit 2009 mit 110 Milliarden US-Dollar finanziert wurden, sieht der Bericht die meisten von ihnen scheitern, weil sie kein effektives Partner-Ökosystem aufgebaut haben.
<G-vec00084-002-s079><build_up.aufbauen><en> The machines and facilities are build up, electrically installed and set up by our experienced service team.
<G-vec00084-002-s079><build_up.aufbauen><de> Die Maschinen oder Anlagen werden von unserem erfahrenen Serviceteam aufgebaut, elektrisch installiert und in Betrieb genommen.
<G-vec00084-002-s080><build_up.aufbauen><en> The whole song is composed to build up to its powerful energetic refrain.
<G-vec00084-002-s080><build_up.aufbauen><de> Der ganze Song ist auf den mächtigen energetischen Refrain hinlaufend aufgebaut.
<G-vec00084-002-s081><build_up.aufbauen><en> All together we did more water related activities - irrigation in Mesopotamia, were and when do we use water (we baked bread, cooked apple sauce, both need some water), we build up a miniature water purification system.
<G-vec00084-002-s081><build_up.aufbauen><de> Alle zusammen haben wir weiter unser Wasserthema verfolgt - Bewässerung in Mesopotamien, wie und wo verwenden wir Wasser (wir haben Brot gebacken, Apfelmus eingekocht für beides braucht man ja auch etwas Wasser), wir haben eine Minikläranlage aufgebaut.
<G-vec00084-002-s082><build_up.aufbauen><en> Up until today, however, the Waldorf School in Chișinău remains the only Waldorf initiative in the country that was able to surpass its baby steps and build a viable organism.
<G-vec00084-002-s082><build_up.aufbauen><de> Die Waldorfschule in Chişinău ist nach wie vor die einzige Waldorfinitiative, die über die Kinderschuhe hinaus einen überlebensfähigen Organismus aufgebaut hat.
<G-vec00084-002-s083><build_up.aufbauen><en> Meanwhile different Non-Profit-Organizations from Switzerland and abroad belong to her clients, for which Rosi Blissenbach either founded a Swiss entity to build it up or took over the management of the existing organization to develop and expand it.
<G-vec00084-002-s083><build_up.aufbauen><de> Inzwischen gehören Non-Profit-Organisationen aus dem In- und Ausland zu ihren Kunden, für die Rosi Blissenbach entweder eine Tochter-Organisation in der Schweiz gegründet und aufgebaut oder eine bereits bestehende Organisation in der Geschäftsführung übernommen hat, um sie weiter auszubauen.
<G-vec00084-002-s084><build_up.aufbauen><en> Just connect the central unit to the router and then gradually build up a complex, smart household by connecting other devices.
<G-vec00084-002-s084><build_up.aufbauen><de> Die Zentraleinheit muss nur mit dem Router verbunden werden, damit dann nach und nach ein komplexes, intelligentes Zuhause mit anderen smarten Geräten aufgebaut werden kann.
<G-vec00084-002-s085><build_up.aufbauen><en> We at BAUNAT recognise the importance of consumer trust and have build the company upon it:
<G-vec00084-002-s085><build_up.aufbauen><de> Bei BAUNAT legen wir Wert auf die Bedeutung vom Verbrauchervertrauen und haben das Unternehmen so aufgebaut.
<G-vec00084-002-s086><build_up.aufbauen><en> The Cooler Master SX power pack is build modular, as already mentioned on the first page and provides thanks to individually connectable cables a cleared up PC for a better aeration and/or heat dissipation from the PC case.
<G-vec00084-002-s086><build_up.aufbauen><de> Wie bereits auf der ersten Netzteil Test Seite erwähnt, ist das Cooler Master V700 Netzteil vollkommen modular aufgebaut und ermöglicht einen aufgeräumten PC dank individuell ansteckbarer Kabel.
<G-vec00084-002-s087><build_up.aufbauen><en> Since we’ve already arrived a few days earlier to build our stand and install all products and systems, we wondered if and how you might like it.
<G-vec00084-002-s087><build_up.aufbauen><de> Wir sind ja schon ein paar Tage vorher angereist, haben den Stand aufgebaut, alle Produkte und Systeme installiert und uns Gedanken darüber gemacht, ob und wie es Ihnen gefallen wird.
<G-vec00084-002-s088><build_up.aufbauen><en> The investor mainly benefits from the increased customer relations and the good reputation IVT was able to form and build up in the last three decades, as well as its employees’ expertise, experience and loyalty.
<G-vec00084-002-s088><build_up.aufbauen><de> Dabei profitiert der Investor vor allem von den gewachsenen Kundenbeziehungen und dem guten Ruf, den sich IVT in dreieinhalb Jahrzehnten aufgebaut hat, sowie von der Kompetenz, Erfahrung und Loyalität der Mitarbeiter.
<G-vec00084-002-s089><build_up.aufbauen><en> Also, swimming tends not to build muscle, because the muscles are supported by the water, which restricts the type of movements the muscles make.
<G-vec00084-002-s089><build_up.aufbauen><de> Hinzu kommt, dass beim Schwimmen kaum Muskel aufgebaut werden, weil die Muskeln vom Wasser getragen werden, was die Art der von den Muskeln ausgeführten Bewegungen eingrenzt.
<G-vec00084-002-s090><build_up.aufbauen><en> By working closely with local project developers and companies the fund also helps build up know-how on renewable energy.
<G-vec00084-002-s090><build_up.aufbauen><de> Darüber hinaus wird durch die enge Zusammenarbeit des Fonds mit lokalen Projektentwicklern und Unternehmen Know-how im Bereich Erneuerbare Energie aufgebaut.
<G-vec00084-002-s091><build_up.aufbauen><en> However, if you work at it, the relationship you build with your cat will be worth the time and effort.
<G-vec00084-002-s091><build_up.aufbauen><de> Wenn du daran arbeitest, dann ist die Beziehung, die du mit der Katze aufgebaut hast, die Zeit und Mühe definitiv wert.
<G-vec00084-002-s092><build_up.aufbauen><en> Unfortunately I build up the tent a bit behind the pass and so I could see, what a stunning sunrise was going on behind the mountains, while I was packing my things together.
<G-vec00084-002-s092><build_up.aufbauen><de> Leider habe ich mein Zelt hinter dem Pass aufgebaut und so konnte ich nur sehen was sich da am Himmel hinter den Bergen abspielen musste, während ich meine Sachen zusammenpackte.
<G-vec00084-002-s093><build_up.aufbauen><en> The stolen books were taken to depots to be routed to various destinations, such as the Hohe Schule, a projected Nazi élite academy, never completed, which was supposed to build its library from the expropriated books.
<G-vec00084-002-s093><build_up.aufbauen><de> Die gestohlenen Bücher wurden zwischengelagert für weitere Verwendungszwecke wie die Hohe Schule, eine geplante, jedoch nie gänzlich realisierte nationalsozialistische Elitehochschule, deren Bibliothek aus dem Fundus der enteigneten Bücher aufgebaut werden sollte.
<G-vec00084-002-s094><build_up.aufbauen><en> OpenCms is an enterprise - ready content management solution build in Java and XML from open source components.
<G-vec00084-002-s094><build_up.aufbauen><de> OpenCms ist eine Java und XML basierte Website Content Management Lösung für Unternehmen, welche komplett aus Open Source Komponenten aufgebaut ist.
<G-vec00084-002-s095><build_up.aufbauen><en> Trade petitions and remedies are blunt and unwieldy policy tools that do nothing to address the underlying issue at hand—the U.S. can’t compete with China and Germany and other clean energy leaders unless it makes an assertive effort to build a more sustainable economy at home and abroad.
<G-vec00084-002-s095><build_up.aufbauen><de> Handelseingaben und Gegenmaßnahmen sind stumpfe und schwerfällige politische Instrumente, die nichts dazu beitragen, das zugrunde liegende Problem anzugehen – die Vereinigten Staaten können mit China, Deutschland und anderen Führern auf dem Gebiet der erneuerbaren Energie nicht konkurrieren, solange sie nicht ausdrückliche Anstrengungen unternehmen, zu Hause und im Ausland eine nachhaltigere Wirtschaft aufzubauen.
<G-vec00084-002-s096><build_up.aufbauen><en> I'm still a member of that organization today, I question patriarchy, and I try to build freedom for myself.
<G-vec00084-002-s096><build_up.aufbauen><de> Ich befinde mich heute immer noch in derselben Organisation, hinterfrage das Patriarchat und versuche, mir meine Freiheit aufzubauen.
<G-vec00084-002-s097><build_up.aufbauen><en> There’s no doubt that penning good blog posts can help you build a successful online business.
<G-vec00084-002-s097><build_up.aufbauen><de> Zweifellos kann das Bloggen Dir dabei helfen, ein erfolgreiches Online-Unternehmen aufzubauen.
<G-vec00084-002-s098><build_up.aufbauen><en> Those looking at expanding their manufacturing capabilities can meet technology experts to get answers on selecting the right system for their plant processes according to individual plant needs and be sure to discover the technology developments in the industry, develop contacts and build a potential supplier base. The educational sessions and learning zone will perfectly complement the visitor’s needs.
<G-vec00084-002-s098><build_up.aufbauen><de> Auf der Suche nach einer Erweiterung der Fertigungsmöglichkeiten kann man mit Technologieexperten sprechen, um Antworten hinsichtlich der Auswahl des richtigen Systems für die Anlagenprozesse entsprechend dem Bedarf des jeweiligen Werks zu erhalten, um sich über die technologischen Entwicklungen in der Branche zu informieren, um Kontakte zu knüpfen und einen Stamm potenzieller Lieferanten aufzubauen.
<G-vec00084-002-s099><build_up.aufbauen><en> Read more about how CREALOGIX helped Société Générale to successfully build up their digital bank.
<G-vec00084-002-s099><build_up.aufbauen><de> Lesen Sie mehr wie CREALOGIX Société Générale geholfen hat ihre digitale Bank erfolgreich aufzubauen.
<G-vec00084-002-s100><build_up.aufbauen><en> But we did not consider it as part of the program of the National Socialist Revolution to destroy human life or material goods, but rather to build up a new and better life.
<G-vec00084-002-s100><build_up.aufbauen><de> Allein wir sahen die Aufgabe der nationalsozialistischen Revolution nicht darin, Menschenleben oder Sachwerte zu vernichten, als vielmehr darin, ein neues und besseres Leben aufzubauen.
<G-vec00084-002-s101><build_up.aufbauen><en> Emilie, a University Partnerships Manager at JobTeaser, advises to build trust by including advice that doesn’t come from the career services department: career development blogs like The Muse or JobTeaser Advice can make easily shareable content, for instance.
<G-vec00084-002-s101><build_up.aufbauen><de> Emilie, eine Managerin für Universitätspartnerschaften bei JobTeaser, rät dazu, mithilfe von Tipps, die nicht aus der Career-Service-Abteilung kommen, Vertrauen aufzubauen: Blogs rund um das Thema Karriereentwicklung wie The Muse oder JobTeaser Advice beispielsweise bieten Inhalte, die sich leicht teilen lassen.
<G-vec00084-002-s102><build_up.aufbauen><en> Your body starts to expel the bad and to build up again the good.
<G-vec00084-002-s102><build_up.aufbauen><de> Ihr Körper fängt an, das Schlechte auszustoßen und das Gute wieder aufzubauen.
<G-vec00084-002-s103><build_up.aufbauen><en> From the first day we are developing, like parents, together with a tiny child, we learn to live together, experience, care for each other, and build new family relationships.
<G-vec00084-002-s103><build_up.aufbauen><de> Vom ersten Tag an entwickeln wir wie Eltern zusammen mit einem winzigen Kind zusammen zu leben, zu erleben, füreinander zu sorgen und neue Familienbeziehungen aufzubauen.
<G-vec00084-002-s104><build_up.aufbauen><en> With XProtect as the foundation of your video surveillance, you get the freedom to build the entire system just the way you like it.
<G-vec00084-002-s104><build_up.aufbauen><de> Mit XProtect als Grundlage für Ihre Videoüberwachung erhalten Sie die Freiheit, das gesamte System genau so aufzubauen, wie es Ihnen gefällt.
<G-vec00084-002-s105><build_up.aufbauen><en> From the outset, one of the major cornerstones of the Baobab Family has been its efforts to build up the “most transparent project” of its kind.
<G-vec00084-002-s105><build_up.aufbauen><de> Einer der ausgesprochenen Eckpfeiler der Baobab Family ist seit Anfang an das Bestreben, das „Transparenteste Projekt“ in seiner Form aufzubauen.
<G-vec00084-002-s106><build_up.aufbauen><en> He would not have been the right man to build up the mission in South Shandong as superior.
<G-vec00084-002-s106><build_up.aufbauen><de> Er wäre wohl nicht der richtige Mann gewesen, die Mission in Süd-Shantung als Oberer aufzubauen.
<G-vec00084-002-s107><build_up.aufbauen><en> It adopts leading 3D printing technology to build biological micro-structure which guarantees the access, proliferation and differentiation of bone cells, growth of new vessels and exchange of metabolite.
<G-vec00084-002-s107><build_up.aufbauen><de> Es nutzt die führende 3D-Drucktechnologie, um eine biologische Mikrostruktur aufzubauen, die den Zugang, die Proliferation und Differenzierung von Knochenzellen, das Wachstum neuer Gefäße und den Austausch von Metaboliten garantiert.
<G-vec00084-002-s108><build_up.aufbauen><en> Her support in various types of projects, like restructuring programs, change of ownership, foundation of new branches of business, company’s rebranding, product launches and establishment of international divisions in Australia, China and India have enabled Christine Och, to build a broad range of knowledge.
<G-vec00084-002-s108><build_up.aufbauen><de> Ihre Begleitung der unterschiedlichsten Projekte, sei es Restrukturierungsprogramme, Eigentümerwechsel, Gründung neuer Geschäftszweige, Änderung der Markenpolitik, Produkteinführungen und der Aufbau internationaler Abteilungen in Australien, China und Indien haben es Christine Och ermöglicht, ein breites Wissensspektrum aufzubauen.
<G-vec00084-002-s109><build_up.aufbauen><en> But many women believe that weight training only for men who want to "bulk" or build muscle.
<G-vec00084-002-s109><build_up.aufbauen><de> Aber viele Frauen glauben, dass Krafttraining ist nur für Männer, die wollten "Bulk-up " oder Muskeln aufzubauen.
<G-vec00084-002-s110><build_up.aufbauen><en> These materials are solid proteins when they are used to build lean muscle.
<G-vec00084-002-s110><build_up.aufbauen><de> Diese Materialien sind feste Proteine, wenn sie verwendet werden, um Muskelmasse aufzubauen.
<G-vec00084-002-s111><build_up.aufbauen><en> If something goes wrong: Trigger chaos / civil war, because the end goal is the demolition of the old order to build the new on the ruins – with reduced slaves population.
<G-vec00084-002-s111><build_up.aufbauen><de> Sollte etwas schief gehen: Chaos/Bürgerkrieg auslösen, denn das Endziel ist der Abriss der alten Ordnung, um die Neue auf den Ruinen aufzubauen – mit reduzierter Sklavenbevölkerung.
<G-vec00084-002-s112><build_up.aufbauen><en> This model will definitely help ourselves to ask the right questions and to build our company on a solid basis.
<G-vec00084-002-s112><build_up.aufbauen><de> Der Geschäftsplan wird uns helfen, uns die richtigen Fragen zu stellen und unsere Firma auf stabilem Grund aufzubauen.
<G-vec00084-002-s113><build_up.aufbauen><en> A highly functional website can help you build your brand...
<G-vec00084-002-s113><build_up.aufbauen><de> Eine hochfunktionelle Website kann Ihnen dabei helfen, Ihre Marke aufzubauen...
<G-vec00084-002-s133><build_up.bauen><en> Plot with permission to build a large villa with pool and garden, located close to all amenities with good access, between Estômbar and Lagoa.
<G-vec00084-002-s133><build_up.bauen><de> Grundstück in Erlaubnis zum Bau einer großen Villa mit Pool und Garten, in der Nähe von allen Annehmlichkeiten in Lagoa.
<G-vec00084-002-s134><build_up.bauen><en> The currently applicable building codes allow on each property to build a country house with up to 500 m² of living space.
<G-vec00084-002-s134><build_up.bauen><de> Die derzeit gültigen Baunormen erlauben auf jedem Grundstück den Bau eines Landhauses mit bis zu 500 m² Wohnfläche.
<G-vec00084-002-s135><build_up.bauen><en> History The Bed and Breakfast business in the Casa di Peppino e Lucia was started in the summer of 2008, but the history of this house began in the early 60’s when Peppino Aiello and Lucia Puccio decided to build it.
<G-vec00084-002-s135><build_up.bauen><de> Geschichte Das B&B besteht seit Sommer 2008, aber die Geschichte dieses Hauses ist schon viel älter – sie beginnt in den frühen 60er Jahren, als Peppino Aiello und Lucia Puccio sich zum Bau des Hauses entschieden haben.
<G-vec00084-002-s136><build_up.bauen><en> With our listings of land for sale in Mallorca you can find that perfect plot to start your build.
<G-vec00084-002-s136><build_up.bauen><de> Mit unseren Grundstücksangeboten auf Mallorca können Sie das perfekte Grundstück für Ihren Bau finden.
<G-vec00084-002-s137><build_up.bauen><en> The majority of the raw materials (such as wood and Co.), which we need to build our loving Floors, we source from the region.
<G-vec00084-002-s137><build_up.bauen><de> Den Großteil der Rohstoffe (wie Holz und Co.), die wir zum Bau unserer liebevollen Floors benötigen, beziehen wir aus der Region.
<G-vec00084-002-s138><build_up.bauen><en> In 2001, Sultan Qaboos decided by royal decree to build an opera house in Oman's capital, Muscat.
<G-vec00084-002-s138><build_up.bauen><de> Im Jahr 2001 beschloss Sultan Qaboos durch ein königliches Dekret den Bau eines Opernhauses in Omans Haupt...
<G-vec00084-002-s139><build_up.bauen><en> When the rush finished, they were desperate for work, so the farmers had them build dams.
<G-vec00084-002-s139><build_up.bauen><de> Als sie nach Beendigung des Goldrausches nach Arbeit suchten, stellten die Farmer sie zum Bau von Dämmen an.
<G-vec00084-002-s140><build_up.bauen><en> Who ever buys this kit should know that he buys pure Science Fiction or a nice spare parts box with parts to build several better Mistel Models .
<G-vec00084-002-s140><build_up.bauen><de> Wer sich diesen Bausatz kauft, der sollte sich bewußt sein, daß er hier pure Science Fiction erwirbt oder eine schöne Grabelkiste mit Einzelteilen zum Bau verschiedener besserer Mistel Modelle.
<G-vec00084-002-s141><build_up.bauen><en> The inside of the church is made of different but harmonious materials: the floor is of Kalithea white marble with a grey cross of Gramata marble – the same kind of stone was used to build the pulpit; the window panes are in onyx, the balustrades and the altars in marble, the tables are monolithic blocks of Gramata stone and the tabernacles are in Kamiros stone.
<G-vec00084-002-s141><build_up.bauen><de> Das Innere der Kirche besteht aus verschiedenen, aber gut harmonierenden Materialien: der Boden ist aus Calitea mit weißen Marmor und einem grauen Kreuz aus Gramata Marmor – der gleiche Stein, der für den Bau der Kanzel benutzt wurde; die Fensterscheiben sind aus Onyx, die Balustraden und der Altar aus Marmor, die Tische gigantische Gramata Marmor Steinblöcke und die Stiftshütten sind aus Camiro Stein.
<G-vec00084-002-s142><build_up.bauen><en> To build the XOno is in my opinion a plus for most audio systems.
<G-vec00084-002-s142><build_up.bauen><de> Der Bau des XOno lohnt sich meiner Meinung nach auf jeden Fall und ist sicherlich ein Gewinn in fast jeder Audio Kette.
<G-vec00084-002-s143><build_up.bauen><en> At the museum of the city's history you can see that the grave stones were used to build the city walls.
<G-vec00084-002-s143><build_up.bauen><de> Im Museum der Stadtgeschichte können Sie auch die Verwendung der Grabsteine zum Bau der Stadtmauer sehen.
<G-vec00084-002-s144><build_up.bauen><en> The estimated project economics for Canarc to build and operate a 750 tonne per day gold mine at New Polaris using bio-oxidation followed by a leaching process to produce 80,000 ounces of gold per year in doré bars at site are reasonably achievable for this project.
<G-vec00084-002-s144><build_up.bauen><de> Die geschätzte Projektwirtschaftlichkeit für den Bau und Betrieb einer Goldmine mit 750 Tagestonnen Kapazität bei New Polaris mittels Bio-Oxidation gefolgt von einem Laugungsverfahren zur Herstellung von 80.000 Unzen Gold pro Jahr in Form von Doré-Barren vor Ort durch Canarc ist vernünftigerweise erreichbar.
<G-vec00084-002-s145><build_up.bauen><en> KfW is also contributing to a fund that provides finance to help people on moderate or low incomes to build energy-efficient houses.
<G-vec00084-002-s145><build_up.bauen><de> Die KfW ist zudem an einem Fonds beteiligt, der den Bau energieeffizienter Häuser für Menschen mit mittleren und niedrigen Einkommen finanziert.
<G-vec00084-002-s146><build_up.bauen><en> The focus remains to increase renewable capacity and to build highly efficient fossil-fuel-fired power stations.
<G-vec00084-002-s146><build_up.bauen><de> Schwerpunkt bleibt der Ausbau der erneuerbaren Energien und der Bau von hocheffizienten fossil befeuerten Kraftwerken.
<G-vec00084-002-s147><build_up.bauen><en> This big contract to build the dome and main structure is expected to be awarded towards the end of 2014.
<G-vec00084-002-s147><build_up.bauen><de> Die Vergabe dieses großen Vertrags über den Bau des Schutzbaus und der Hauptstruktur wird voraussichtlich gegen Ende des Jahres 2014 abgeschlossen sein.
<G-vec00084-002-s148><build_up.bauen><en> There are more ways than ever before to build, conquer, and inspire.
<G-vec00084-002-s148><build_up.bauen><de> Es gibt mehr Möglichkeiten für Bau, Eroberung und Inspiration als je zuvor.
<G-vec00084-002-s149><build_up.bauen><en> Build yourself your own RePricing for eBay.
<G-vec00084-002-s149><build_up.bauen><de> Bau dir dein eigenes RePricing für ebay.
<G-vec00084-002-s150><build_up.bauen><en> Call "I am the descendant of Sir Sobha Singh who worked closely with Sir Edwin Lutyens to construct and build the city of New Delhi.
<G-vec00084-002-s150><build_up.bauen><de> „Ich bin ein Nachkomme von Sir Sobha Singh, einem engen Mitarbeiter von Sir Edwin Lutyens bei Planung und Bau der Stadt Neu Delhi.
<G-vec00084-002-s151><build_up.bauen><en> So the LORD scattered them abroad from thence upon the face of all the earth: and they left off to build the city.
<G-vec00084-002-s151><build_up.bauen><de> 8 So zerstreute der Herr die Menschen über die ganze Erde; den Bau der Stadt mussten sie abbrechen.
<G-vec00084-002-s152><build_up.bauen><en> Build a house from cards with the highest value.
<G-vec00084-002-s152><build_up.bauen><de> Baue ein Kartenhaus mit dem höchstmöglichen Wert.
<G-vec00084-002-s153><build_up.bauen><en> Build a Farm.
<G-vec00084-002-s153><build_up.bauen><de> Baue eine Farm.
<G-vec00084-002-s154><build_up.bauen><en> Build 100 Missile towers.
<G-vec00084-002-s154><build_up.bauen><de> Baue 100 Raketen-Türme.
<G-vec00084-002-s155><build_up.bauen><en> With Live and Push this has completely changed actually, because I either start with a melody or a drum loop that I construct myself and then build on it and the song is created along the way.
<G-vec00084-002-s155><build_up.bauen><de> Mit Live und Push hat sich das komplett geändert eigentlich, weil ich fang entweder mit einer Melodie oder einem Drum-Loop an, den ich mir zusammenbaue und baue dann darauf auf und das Lied entsteht so währenddessen.
<G-vec00084-002-s156><build_up.bauen><en> Ezra 1:3 - Who is there among you of all his people? his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of the LORD God of Israel, (he is the God,) which is in Jerusalem.
<G-vec00084-002-s156><build_up.bauen><de> 3 Wer irgend unter euch aus seinem Volke ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem, das in Juda ist, und baue das Haus Jahwes, des Gottes Israels (er ist Gott), in Jerusalem.
<G-vec00084-002-s157><build_up.bauen><en> Build shoulder muscles by lifting dumbbells out from your sides for resistance.
<G-vec00084-002-s157><build_up.bauen><de> Baue Schulter- und Nackenmuskulatur auf, indem du seitliche Hantelübungen für mehr Kraft ausführst.
<G-vec00084-002-s158><build_up.bauen><en> Build Lumber Yards to secure a steady supply of raw materials and Upgrade them to increase production.
<G-vec00084-002-s158><build_up.bauen><de> Baue Holzlager, um für stetigen Nachschub an Rohmaterial zu sorgen und verbessere sie, um deine Produktion zu steigern.
<G-vec00084-002-s159><build_up.bauen><en> Build your organic grocery store, cozy movie theater, vintage diner, relaxing spa, classic Bed & Breakfast, dreamy beach cafe and more.
<G-vec00084-002-s159><build_up.bauen><de> Baue deinen Biokostladen, ein gemütliches Kino, einen altmodischen Imbiss, ein entspannendes Kurbad, eine klassische Pension, ein verträumtes Strandcafé und mehr.
<G-vec00084-002-s160><build_up.bauen><en> Founded in 1947 by Edwin J. Montalvo Sr. the Montalvo Corporation continues the core principle it was built on: build a product right the first time and back it up with the highest quality service and support.
<G-vec00084-002-s160><build_up.bauen><de> Gegründet 1947 von Edwin J. Montalvo Sr. gilt bei der Montalvo Corporation nach wie vor ihr Grundprinzip, auf dem es aufgebaut wurde: baue ein Produkt bereits beim ersten Mal richtig und unterstütze es mit einem erstklassigen Service und Support.
<G-vec00084-002-s161><build_up.bauen><en> Build your dream team - Choose from among the best football stars of all time and build a team to take home the glory in FIFA Ultimate Team.
<G-vec00084-002-s161><build_up.bauen><de> Traumteam zusammenstellen - Verpflichte die besten Fußballstars aller Zeiten und baue in FIFA Ultimate Team eine Mannschaft auf, die dir jede Menge Ruhm einbringt.
<G-vec00084-002-s162><build_up.bauen><en> Build, buy and sell houses.
<G-vec00084-002-s162><build_up.bauen><de> Baue, verbaue und verkaufe Häuser.
<G-vec00084-002-s163><build_up.bauen><en> Let yourself be engulfed by the rich world of the Dark Souls. Gradually build your character, discover scary locations, and collect and master an extensive range of weapons, equipment and magic spells to create a truly unique gaming experience.
<G-vec00084-002-s163><build_up.bauen><de> Erlebe die dunkle Welt der dunklen Seelen, baue deinen Charakter Schritt nach Schritt auf, entdecke erschreckende Orte und sammle und meistere eine umfangreiche Sammlung von Waffen, Ausrüstung und Zaubersprüchen, um ein wirklich einzigartiges Spielerlebnis zu erschaffen.
<G-vec00084-002-s164><build_up.bauen><en> His God is with him, and he doth go up to Jerusalem, that [is] in Judah, and build the house of Jehovah, God of Israel -- He [is] God -- that [is] in Jerusalem.
<G-vec00084-002-s164><build_up.bauen><de> 3Wer nun unter euch von seinem Volk ist, mit dem sei sein Gott, und er ziehe hinauf nach Jerusalem in Juda und baue das Haus des HERRN, des Gottes Israels; das ist der Gott, der zu Jerusalem ist.
<G-vec00084-002-s165><build_up.bauen><en> Build your case with logical reasoning and fact while adding in an emotional element.
<G-vec00084-002-s165><build_up.bauen><de> Baue dein Anliegen mit logischen Argumenten und Fakten auf und setze dann einen emotionalen Bestandteil ein.
<G-vec00084-002-s166><build_up.bauen><en> Build fluency and confidence through interactive Danish classes that are effective and fun.
<G-vec00084-002-s166><build_up.bauen><de> Baue deine Fremdsprachkenntnisse und dein Selbstvertrauen durch interaktiven Online-Unterricht auf.
<G-vec00084-002-s167><build_up.bauen><en> Build your own monster vehicle with weapons to take part in crazy racing tracks.
<G-vec00084-002-s167><build_up.bauen><de> Baue dein eigenes Monster Vehikel, mit Deinen bevorzugten Waffen.
<G-vec00084-002-s168><build_up.bauen><en> Build a party of famous warriors and epic monsters from Dragon...
<G-vec00084-002-s168><build_up.bauen><de> Baue eine Gruppe aus berühmten Kriegern und epischen Monstern aus...
<G-vec00084-002-s169><build_up.bauen><en> If I build an elephant house for a zoo, I have to deal with elephants.
<G-vec00084-002-s169><build_up.bauen><de> Wenn ich für einen Zoo ein Elefantenhaus baue, muss ich mich mit Elefanten beschäftigen.
<G-vec00084-002-s170><build_up.bauen><en> I build two new bikes.
<G-vec00084-002-s170><build_up.bauen><de> Ich baue zwei neue Motorräder auf.
<G-vec00084-002-s171><build_up.bauen><en> 3:2 He began to build in the second [day] of the second month, in the fourth year of his reign.
<G-vec00084-002-s171><build_up.bauen><de> 3:2 Und er fing an zu bauen im zweiten Monat, am zweiten [Tag] im vierten Jahr seiner Regierung.
<G-vec00084-002-s172><build_up.bauen><en> Build a beautiful pair of Pandora earring with these 14K gold and Onyx Drop charms.
<G-vec00084-002-s172><build_up.bauen><de> Bauen Sie ein schönes Paar Pandora Ohrring mit diesen 14K Gold und Onyx Tropfen Reize.
<G-vec00084-002-s173><build_up.bauen><en> In one of the few places in the world where you can surf in the morning and ski in the afternoon, Nick set out to build a vehicle that could deal with the climatic extremes of his “Urban Adventures”.
<G-vec00084-002-s173><build_up.bauen><de> In einem der wenigen Orte auf der Welt, wo man am Morgen surfen und am Nachmittag Skifahren kann, hat sich Nick vorgenommen, ein Fahrzeug zu bauen, das mit den klimatischen Extremen seines "Stadtabendteuers" umgehen konnte.
<G-vec00084-002-s174><build_up.bauen><en> 10See, today I appoint you over nations and kingdoms to uproot and tear down, to destroy and overthrow, to build and to plant.’
<G-vec00084-002-s174><build_up.bauen><de> 10Siehe, ich bestelle dich an diesem Tage über die Nationen und über die Königreiche, um auszurotten und niederzureißen und zu zerstören und abzubrechen, um zu bauen und um zu pflanzen.
<G-vec00084-002-s175><build_up.bauen><en> "The decision to build a house is elementary and a long-term decision.
<G-vec00084-002-s175><build_up.bauen><de> Bemusterungszentrum Hartenfels „Die Entscheidung ein Haus zu bauen ist elementar und langfristig.
<G-vec00084-002-s176><build_up.bauen><en> We are confident that we can create a system that is tightly scoped to our needs that will not be complex to design, build and deploy.
<G-vec00084-002-s176><build_up.bauen><de> Wir sind zuversichtlich, dass wir ein System erschaffen können, welches sich fest an unsere Bedingungen anpasst und dabei einfach zu entwerfen, bauen und einzusetzen ist.
<G-vec00084-002-s177><build_up.bauen><en> Easily build your own custom app to meet the unique – and changing – needs of your business.
<G-vec00084-002-s177><build_up.bauen><de> Bauen Sie ganz einfach Ihre eigene maßgeschneiderte App auf, um den speziellen – und sich verändernden – Anforderungen Ihres Unternehmens gerecht zu werden.
<G-vec00084-002-s178><build_up.bauen><en> 3 You know how that David my father could not build an house to the name of the LORD his God for the wars which were about him on every side, until the LORD put them under the soles of his feet.
<G-vec00084-002-s178><build_up.bauen><de> 3 Du weißt, daß David, mein Vater, nicht vermochte, ein Haus zu bauen dem Namen Jehova's, seines Gottes, wegen des Krieges, womit sie ihn umgaben, bis sie Jehova unter seine Fußsohlen legte.
<G-vec00084-002-s179><build_up.bauen><en> Since then it has been his claim to build the best possible tools ever.
<G-vec00084-002-s179><build_up.bauen><de> Seitdem ist es sein Anspruch, das bestmögliche Werkzeug überhaupt zu bauen.
<G-vec00084-002-s180><build_up.bauen><en> The announced fact that some businessmen are planing to build big hotel complexes on different nature protected areas abusing all existing laws provokes civic attention and in fact this ecological in its beginning protests grown into civil ones, attracting a lot of students and young people.
<G-vec00084-002-s180><build_up.bauen><de> Mira Die öffentlich bekannt gegebene Tatsache, dass einige Geschäftsmänner große Hotelkomplexe auf verschiedenen naturgeschützten Geländen zu bauen beabsichtigen, wobei sie gültige Gesetze missachten, provozierte die zivile Öffentlichkeit, womit diese ursprünglich ökologisch motivierten Proteste zu einem zivilen, viele Studenten und Jugendliche anziehenden Widerstand wurden.
<G-vec00084-002-s181><build_up.bauen><en> This lovely plot is tranquill, has good connections, beautiful surroundings and ample space to build a large villa with pool and terraces.
<G-vec00084-002-s181><build_up.bauen><de> Hier genießt man Ruhe, hat eine gute Anbindung, eine schöne Umgebung und Platz, um eine große Villa mit Pool und Terrassen zu bauen.
<G-vec00084-002-s182><build_up.bauen><en> With Drupal 8, you can build almost any integrated experience you can imagine.
<G-vec00084-002-s182><build_up.bauen><de> Mit Drupal 8 können Sie so gut wie jeden integrierten Web-Auftritt bauen, den Sie sich vorstellen können.
<G-vec00084-002-s183><build_up.bauen><en> We build on the experience, motivation and qualifications of our employees to fulfill the most sophisticated customer requirements with excellence and dedication.
<G-vec00084-002-s183><build_up.bauen><de> Wir bauen auf die Erfahrung, Motivation und Qualifikation unserer Mitarbeitenden, um selbst die anspruchsvollsten Kundenanforderungen kompetent und mit persönlichem Einsatz zu erfüllen.
<G-vec00084-002-s184><build_up.bauen><en> Build with LemonChili many pages and beverage menu, as you want.
<G-vec00084-002-s184><build_up.bauen><de> Bauen Sie mit LemonChili viele Seiten und Getränkekarte, wie Sie wollen.
<G-vec00084-002-s185><build_up.bauen><en> “More and more Is- tanbulites are buying land in the area to build villas and holiday homes, thus taking land away from agriculture.
<G-vec00084-002-s185><build_up.bauen><de> «Immer mehr Istanbuler erwerben außerdem Land in der Um- gebung, um Villen und Ferienhäuser zu bauen – dieses Land geht der Landwirt- schaft verloren.
<G-vec00084-002-s186><build_up.bauen><en> Help Jane to make the pickiest customers happy: choose refined furniture, build a golf course and please your customers with exquisite drinks and good meals.
<G-vec00084-002-s186><build_up.bauen><de> Helfen Sie Jane die heikelste Kunden glücklich zu machen: Wählen Sie raffinierte Möbel, einen Golfplatz zu bauen und bitte Sie Ihre Kunden mit exquisiten Drinks und gutes Essen.
<G-vec00084-002-s187><build_up.bauen><en> Our mission is to build lightweight, efficient, all-terrain bikes that build two-wheeled balance, coordination, and confidence in children.
<G-vec00084-002-s187><build_up.bauen><de> Unser Ziel ist es, leichtgewichtige, effiziente Geländeräder zu bauen, die das Gleichgewichthalten, die Koordination und das Selbstvertrauen von Kindern fördern.
<G-vec00084-002-s188><build_up.bauen><en> It is our aim to build and operate properties with their setting, with the result to achieve a maximum of user satisfaction, productivity and efficiency by using a minimum of resources (ecology, economy, personal expenditure).
<G-vec00084-002-s188><build_up.bauen><de> Unser Ziel ist es, Immobilien und deren Umfeld zu bauen und zu betreiben, so dass mit einem Minimum an Ressourcen (Ökologie, Ökonomie, Personalaufwand) ein Maximum an Nutzerzufriedenheit, Produktivität und Effizienz erreicht werden kann.
<G-vec00084-002-s189><build_up.bauen><en> Print Bodyshop We engineer, design, build and install manual as well as automatic systems for hemflange adhesive application as well as for cosmetic sealing, untiflutter and sounddeadener.
<G-vec00084-002-s189><build_up.bauen><de> Wir planen, konstruieren, bauen und installieren manuelle und automatische Anlagen für die Nahtabdichtungen, Kosmetiksealer, Unterbodenschutzauftrag, Schweller-Beschichtungssysteme sowie für spritzbare Schalldämmmassen.
<G-vec00084-002-s190><build_up.bauen><en> Protect the devices customers depend on and build trust in your brand.
<G-vec00084-002-s190><build_up.bauen><de> Schützen Sie die Geräte, auf die Kunden angewiesen sind, und bauen Sie das Vertrauen in Ihre Marke auf.
<G-vec00084-002-s191><build_up.bauen><en> Multiplayer— Build a region with friends for the first time!
<G-vec00084-002-s191><build_up.bauen><de> Multiplayer: Bauen Sie zum ersten Mal mit Freunden eine ganze Region auf.
<G-vec00084-002-s192><build_up.bauen><en> Build deeper customer relationships and personalized digital experiences with AI, while lowering operating costs and boosting return on investment.
<G-vec00084-002-s192><build_up.bauen><de> Bauen Sie engere Kundenbeziehungen und ein personalisiertes digitales Erlebnis mit KI auf, während die Kosten sinken und der Return-on-Investment steigt.
<G-vec00084-002-s193><build_up.bauen><en> Build upon your existing IT infrastructure with a step-by-step approach featuring technologies engineered to optimize your future infrastructure. Learn more Events
<G-vec00084-002-s193><build_up.bauen><de> Bauen Sie mit einer Schritt-für-Schritt-Methode auf Ihrer bestehenden IT-Infrastruktur auf und nutzen Sie dabei Technologien, die eigens in Hinblick auf eine Optimierung Ihrer künftigen Infrastruktur entwickelt wurden.
<G-vec00084-002-s194><build_up.bauen><en> Use individual customer scores to build personalized automation workflows.
<G-vec00084-002-s194><build_up.bauen><de> Bauen Sie mithilfe des Punktestands einzelner Kunden personalisierte Automatisierungsworkflows.
<G-vec00084-002-s195><build_up.bauen><en> - Hard coating, avoid the light pollution and build good ecological environment.
<G-vec00084-002-s195><build_up.bauen><de> - Harte Beschichtung, vermeiden Sie die Lichtverschmutzung und bauen Sie eine gute ökologische Umgebung.
<G-vec00084-002-s196><build_up.bauen><en> Build the web site and all documents.
<G-vec00084-002-s196><build_up.bauen><de> Bauen Sie die Webseite und alle Dokumente.
<G-vec00084-002-s197><build_up.bauen><en> Build the essential relationships that set the foundation for ExxonMobil’s continued industry leadership.
<G-vec00084-002-s197><build_up.bauen><de> Bauen Sie die richtigen Geschäftsbeziehungen auf, die die Grundlage für ExxonMobils fortwährende Führungsrolle innerhalb der Branche schaffen.
<G-vec00084-002-s198><build_up.bauen><en> Build mission-critical applications and take advantage of open frameworks, open source applications, and various development languages.
<G-vec00084-002-s198><build_up.bauen><de> Bauen Sie Auftrag-kritische Anwendungen auf und nutzen Sie offene Rahmen, Anwendungen der offenen Quelle und verschiedene Entwicklungssprachen.
<G-vec00084-002-s199><build_up.bauen><en> Build a rock-solid network for mission-critical business applications.
<G-vec00084-002-s199><build_up.bauen><de> Bauen Sie ein zuverlässiges Netzwerk für geschäftskritische Unternehmensanwendungen.
<G-vec00084-002-s200><build_up.bauen><en> Build with us – it’s pleasure combined with good business
<G-vec00084-002-s200><build_up.bauen><de> Bauen Sie mit uns – so verbinden Sie ein Vergnügen mit gutem Geschäft.
<G-vec00084-002-s201><build_up.bauen><en> Build great user experience
<G-vec00084-002-s201><build_up.bauen><de> Bauen Sie großartige Benutzererfahrung auf.
<G-vec00084-002-s202><build_up.bauen><en> Partner with us to build the perfect production facility to meet your business needs.
<G-vec00084-002-s202><build_up.bauen><de> Werden Sie unser Partner und bauen Sie sich Ihre perfekte Produktionsstätte nach Ihren Geschäftsvorstellungen.
<G-vec00084-002-s203><build_up.bauen><en> Build your tomorrow, today.
<G-vec00084-002-s203><build_up.bauen><de> Bauen Sie sich heute Ihre Zukunft auf.
<G-vec00084-002-s204><build_up.bauen><en> Build over 60 base upgrades and large scale secret projects for your empire.
<G-vec00084-002-s204><build_up.bauen><de> Bauen Sie über 60 Basiseinrichtungen und gewaltige Geheimprojekte, um Ihren Machtbereich auszuweiten.
<G-vec00084-002-s205><build_up.bauen><en> Description Build your city township - build houses, decorations, decorate the streets.
<G-vec00084-002-s205><build_up.bauen><de> Errichten Sie die Stadt aus der Siedlung, bauen Sie Häuser und ihre Ausstattung, dekorieren Sie Straßen.
<G-vec00084-002-s206><build_up.bauen><en> Lose weight, build lean muscle and increase energy with this 20-minute workout.
<G-vec00084-002-s206><build_up.bauen><de> Verlieren Sie an Gewicht, bauen Sie schlanke Muskeln auf und steigern Sie mit diesem 20-Minuten-Programm Ihre Kraft.
<G-vec00084-002-s207><build_up.bauen><en> Build your IoT success on our foundation of 100+ years developing operational technologies and 50+ years creating IT innovation and solutions. Improve Efficiency
<G-vec00084-002-s207><build_up.bauen><de> Bauen Sie für Ihren IoT-Erfolg auf das technologische Fundament von über 100 Jahren Erfahrung in der Entwicklung operativer Technologien und mehr als 50 Jahren von IT-Innovationen und -Lösungen.
<G-vec00084-002-s208><build_up.bauen><en> Build on your taste in the game.
<G-vec00084-002-s208><build_up.bauen><de> Bauen Sie auf Ihren Geschmack im Spiel.
<G-vec00084-002-s209><build_up.bauen><en> Structure a company wiki, build a self-service knowledge base, and onboard new hires simply and effectively.
<G-vec00084-002-s209><build_up.bauen><de> Legt ein Unternehmens-Wiki an, baut eine Wissensdatenbank für die Mitarbeiter auf und bringt neue Kollegen schnell und effektiv auf Stand.
<G-vec00084-002-s210><build_up.bauen><en> Whoever has no house will never build one now.
<G-vec00084-002-s210><build_up.bauen><de> Wer jetzt kein Haus hat, baut sich keines mehr.
<G-vec00084-002-s211><build_up.bauen><en> In fact, at times the Lord himself is one who ”uproots”, ”tears down”, ”destroys” and ”overthrows” in order to ”build” and to ”plant”.
<G-vec00084-002-s211><build_up.bauen><de> Tatsächlich ist zu gewissen Zeiten der Herr selbst einer, der „entwurzelt“, „herunterreißt“, „zerstört“ und „übergibt“, bevor er „baut“ und „pflanzt“.
<G-vec00084-002-s212><build_up.bauen><en> Making changes in your body takes time but if you have been working hard for a few months and still do not see results, it's a sign that you need to learn how to build muscles faster.
<G-vec00084-002-s212><build_up.bauen><de> Veränderungen in Ihrem Körper braucht Zeit, aber wenn Sie seit ein paar Monaten hart gearbeitet haben und immer noch keine Ergebnisse sehen, ist es ein Zeichen, dass Sie lernen müssen, wie man Muskeln schneller baut.
<G-vec00084-002-s213><build_up.bauen><en> Verner Panton is not about superficial effects, he is more inclined to build upon the functional persuasiveness of an idea.
<G-vec00084-002-s213><build_up.bauen><de> Verner Panton ist nicht auf vordergründige Effekte aus, er baut vielmehr auf die funktionale Überzeugungskraft einer Idee.
<G-vec00084-002-s214><build_up.bauen><en> They argue that the only way to avoid using energy or resources is to not build at all.
<G-vec00084-002-s214><build_up.bauen><de> Nur wer gar nicht baut, verbraucht weder Energie noch Ressourcen.
<G-vec00084-002-s215><build_up.bauen><en> This will help improve your form, and build up the arm and shoulder strength needed for one-handed cartwheels.
<G-vec00084-002-s215><build_up.bauen><de> Das hilft dir, deine Form zu verbessern und baut die Kraft in den Schultern und Armen auf, die du zum Radschlagen brauchst.
<G-vec00084-002-s216><build_up.bauen><en> Build the sacred room, dear ones, with the stones of your own walls mixed with the mortar of the love of Home.
<G-vec00084-002-s216><build_up.bauen><de> Baut den Heiligen Raum, Ihr Lieben, mit den Steinen eurer eigenen gefallenen Mauern, vermischt mit dem Mörtel der Liebe von Zuhause.
<G-vec00084-002-s217><build_up.bauen><en> Far from being a single product, the term refers to a culture or “software development discipline, where you build software in such a way that [it] can be released to production at any time,” explains Martin Fowler.
<G-vec00084-002-s217><build_up.bauen><de> Es handelt sich dabei nicht um ein einzelnes Produkt, sondern der Begriff bezieht sich auf eine Kultur oder „Software-Entwicklungsdisziplin, wo man Software auf eine Weise baut, dass sie jederzeit für die Produktion freigegeben werden kann“, erklärt Martin Fowler.
<G-vec00084-002-s218><build_up.bauen><en> You build deep connections to your fellow students and this cohesion is a really, really strong asset of HHL.
<G-vec00084-002-s218><build_up.bauen><de> Man baut tiefgehende Verbindungen zu seinen Kommilitonen auf und dieser Zusammenhalt ist ein richtig, richtig starkes Asset der HHL.
<G-vec00084-002-s219><build_up.bauen><en> This causes a brake pressure to build up, which stops the cutterhead.
<G-vec00084-002-s219><build_up.bauen><de> Dadurch baut sich ein Bremsdruck auf, der die Häckseltrommel stoppt.
<G-vec00084-002-s220><build_up.bauen><en> Your confidence in the water will grow and you’ll build on what you’ve already learned.
<G-vec00084-002-s220><build_up.bauen><de> Der Kurs baut auf dem auf, was du bereits gelernt hast und erweitert deine Kenntnisse.
<G-vec00084-002-s221><build_up.bauen><en> Therefore, Jeremiah sent a letter to the exiled recommending to organize themselves in Babylon, to “build houses, settle down… marry and have sons and daughters… work for the good of the city to which I have exiled you; pray to Yahweh on its behalf. For Yahweh says this: “When the seventy years granted to Babylon are over… I will bring you back to this place” (Jeremiah 29,4-10).
<G-vec00084-002-s221><build_up.bauen><de> Jeremia sandte zu dieser Zeit einen Brief an die Verbannten mit dem Rat sie sollten sich in Babylonien organisieren: “Baut Häuser und wohnt darin… Nehmt euch Frauen und zeugt Söhne und Töchter… Bemüht euch um das Wohl der Stadt, aus der ich euch weggeführt habe, und betet für sie zum Herrn… Denn so spricht der Herr: Wenn siebzig Jahre für Babel vorüber sind, dann werde ich euch an diesen Ort zurückführen” (Jeremia 29,4-10).
<G-vec00084-002-s222><build_up.bauen><en> Castle Wars 2 is the sequel to Castle wars, and is a very addictive card game where your goal is to crush your enemy's castle or be the first to build a 100 storey castle.
<G-vec00084-002-s222><build_up.bauen><de> Castle Wars 2 ist die Fortsetzung von Castle Wars 1 und ein sehr fesselndes Kartenspiel, in dem es Dein Ziel ist, die feindliche Burg zu vernichten oder der Erste zu sein, der eine Burg mit 100 Stockwerken baut.
<G-vec00084-002-s223><build_up.bauen><en> You have fought many wars. You are not the one who will build a house for my Name.
<G-vec00084-002-s223><build_up.bauen><de> Weil du so viel Blut vor mir vergossen hast, sollst du es nicht sein, der ein Haus zu Ehren meines Namens baut.
<G-vec00084-002-s224><build_up.bauen><en> The Master's degree in German Studies is designed to follow and build on the academic skills acquired during the Bachelor's degree and is substantially research-based.
<G-vec00084-002-s224><build_up.bauen><de> Der konsekutiv angelegte Masterstudiengang Germanistik baut auf den im Bachelorstudium erworbenen wissenschaftlichen Fähigkeiten auf und ist dezidiert forschungsbezogen gestaltet.
<G-vec00084-002-s225><build_up.bauen><en> If you build a big church, it can be taken away, as has happened in Central Asia.
<G-vec00084-002-s225><build_up.bauen><de> Wenn man ein großes Kirchengebäude baut, kann es weggenommen werden, das ist auch in Zentralasien passiert.
<G-vec00084-002-s226><build_up.bauen><en> VK started to build an agent network in the Baltic countries and Poland.
<G-vec00084-002-s226><build_up.bauen><de> VK baut ein Netzwerk von Agenten in den baltischen Staaten und in Polen auf.
<G-vec00084-002-s227><build_up.bauen><en> Please build a bridge between people, among people and between countries.
<G-vec00084-002-s227><build_up.bauen><de> Bitte baut eine Brücke zwischen den Menschen und zwischen Ländern.
<G-vec00084-002-s418><build_up.bauen><en> Increase the number of clan members and open new Zones, which allow you to build additional structures.
<G-vec00084-002-s418><build_up.bauen><de> Erhöhen Sie die Anzahl der Clanmitglieder und öffnen Sie neue Zonen, in denen zusätzliche Strukturen gebaut werden können.
<G-vec00084-002-s419><build_up.bauen><en> This lens is build more compact as its neighbor.
<G-vec00084-002-s419><build_up.bauen><de> Dieses Objektiv ist etwas kompakter gebaut.
<G-vec00084-002-s420><build_up.bauen><en> Thus making it easier for you to control and navigate, as it is smaller and with a lighter build.
<G-vec00084-002-s420><build_up.bauen><de> Dadurch ist es für Sie einfacher zu kontrollieren und zu navigieren, da es kleiner und leichter gebaut ist.
<G-vec00084-002-s421><build_up.bauen><en> The clinics that we cooperate with are a bright example of how to build a team of experts who excel beyond other companies on the market.
<G-vec00084-002-s421><build_up.bauen><de> Die Kliniken, mit denen wir kooperieren sind ein leuchtendes Beispiel dafür, wie ein Team von Experten gebaut wird, die sich von anderen Unternehmen auf dem Markt auszeichnen.
<G-vec00084-002-s422><build_up.bauen><en> GIZ has also worked with UNICEF to build seven schools and provide equipment for them.
<G-vec00084-002-s422><build_up.bauen><de> Außerdem hat die GIZ in Zusammenarbeit mit UNICEF sieben Schulen gebaut und ausgestattet.
<G-vec00084-002-s423><build_up.bauen><en> It is ideal for those who want buy a special and unique plot where to build a large housing dimensions, with stunning views and total privacy.
<G-vec00084-002-s423><build_up.bauen><de> Es ist ideal für diejenigen, die ein besonderes und einzigartiges Grundstück kaufen wollen, wo ein großes Haus gebaut werden kann, mit atemberaubender Aussicht und absolute Privatsphäre.
<G-vec00084-002-s424><build_up.bauen><en> Well build, no health issues.
<G-vec00084-002-s424><build_up.bauen><de> Gut gebaut, keine gesundheitlichen Probleme.
<G-vec00084-002-s425><build_up.bauen><en> Top House is build on 2 floors.
<G-vec00084-002-s425><build_up.bauen><de> Top Haus gebaut auf 2 Etagen.
<G-vec00084-002-s426><build_up.bauen><en> In the morning, visit Lingyin Buddhist Temple, one of the best known Buddhist monasteries in China, Which was build in 326 at the foot of Linyin Mountain.
<G-vec00084-002-s426><build_up.bauen><de> Am Morgen besuchen Sie Lingyin Tempel, der im Jahr 326 am Fuß des Linyin Berges gebaut wurde.
<G-vec00084-002-s427><build_up.bauen><en> Since my homepage in online I've got many requests of people who have never build a loudspeaker system their own.
<G-vec00084-002-s427><build_up.bauen><de> Seit meine Homepage im Netz ist habe ich viele Anfragen von Leuten bekommen, die noch nie selbst Lautsprecher gebaut haben.
<G-vec00084-002-s428><build_up.bauen><en> The whole property is build around a pleasant interior courtyard.
<G-vec00084-002-s428><build_up.bauen><de> Das gesamte Anwesen ist um einen angenehmen Innenhof herum gebaut.
<G-vec00084-002-s429><build_up.bauen><en> Ailerons At this time the wings are finsihed except the bottom main skins, so it was time to build the elevators and flaps.
<G-vec00084-002-s429><build_up.bauen><de> Zu diesem Zeitpunkt sind die Tragflächen bis auf die Hauptbeplankung der Unterseite fertig, also müssen erstmal die Querruder und Klappen gebaut werden.
<G-vec00084-002-s430><build_up.bauen><en> The coal pit Zeche Zollverein in Essen was build at the end of the 1920s and was closed down in the year 1986.
<G-vec00084-002-s430><build_up.bauen><de> Der Gesamtkomplex Zeche Zollverein in Essen wurde Ende der 20er Jahre gebaut und im Jahre 1986 stillgelegt.
<G-vec00084-002-s431><build_up.bauen><en> This Microcontroller bases DC power supply is not the simplest circuit but I can assure you that you will not regret the time needed to build it.
<G-vec00084-002-s431><build_up.bauen><de> Diese Mikrocontroller basierte Stromversorgung ist nicht die einfachste Schaltung, aber ich kann dir versichern, dass du es nicht bereuen wirst, diese Schaltung gebaut zu haben.
<G-vec00084-002-s432><build_up.bauen><en> He showed how to create automatic swells, to build a preset for an acoustic guitar, to fight annoying frequencies by using peak EQ-ing and more.
<G-vec00084-002-s432><build_up.bauen><de> Er zeigte, wie ein automatischer Swell gebaut wird, wie man ein Proeset für die Akustische Gitarre anlegt, wie man nervende Frequenzen mit Hilfe des Equalizers eindämmt, und mehr.
<G-vec00084-002-s433><build_up.bauen><en> To instruct Moses in how to build the sanctuary, God showed him a pattern already existing.
<G-vec00084-002-s433><build_up.bauen><de> Um Mose anzuweisen, wie das Heiligtum gebaut werden sollte, zeigte ihm Gott ein schon existierendes Vorbild.
<G-vec00084-002-s434><build_up.bauen><en> Venetian blind motor Airy and transparent – is how we build today.
<G-vec00084-002-s434><build_up.bauen><de> Luftig und transparent - so wird heute gebaut.
<G-vec00084-002-s435><build_up.bauen><en> With the right set-up we knew what to do and were quickly able to build up the first engine.
<G-vec00084-002-s435><build_up.bauen><de> Mit dem richtigen Set-Up wussten wir, was wir zu tun hatten und dann haben wir ziemlich schnell den ersten Motor gebaut.
<G-vec00084-002-s436><build_up.bauen><en> There was also a new toilet seat beeing build by a few boys.
<G-vec00084-002-s436><build_up.bauen><de> Außerdem hatten einige Jungs der Gruppe einen Toilettensitz gebaut.
<G-vec00084-002-s228><build_up.bilden><en> The observations and analyses of social development processes in connection with experiences from missions throughout Germany build important focal points in the approach of the GRC.
<G-vec00084-002-s228><build_up.bilden><de> Die Beobachtungen und Analysen gesellschaftlicher Entwicklungsprozesse in Verbindung mit Erfahrungen aus Einsätzen in ganz Deutschland bilden hierbei wichtige Schwerpunkte im Vorgehen des DRK.
<G-vec00084-002-s229><build_up.bilden><en> Hitachi’s array was the one to go with because it’s going to be the foundation to build our media distribution business on, as well as our editorial business on.
<G-vec00084-002-s229><build_up.bilden><de> Wir haben uns für das Array von Hitachi entschieden, da es die Grundlage für unser Medienverbreitungsgeschäft und unser redaktionelles Geschäft bilden wird.
<G-vec00084-002-s230><build_up.bilden><en> They build the framework from which to address the (semi)-professional athletes who shop here in a truthful way.
<G-vec00084-002-s230><build_up.bilden><de> Sie bilden den Rahmen für eine authentische Ansprache der (semi)professionellen Sportler, die hier einkaufen.
<G-vec00084-002-s231><build_up.bilden><en> Whereby both currencies build one currency pair.
<G-vec00084-002-s231><build_up.bilden><de> Wobei beide Währungen ein Währungspaar bilden.
<G-vec00084-002-s232><build_up.bilden><en> On good days, impressive waves build up near the shore.
<G-vec00084-002-s232><build_up.bilden><de> An guten Tagen bilden sich in Küstennähe beeindruckende Wellen.
<G-vec00084-002-s233><build_up.bilden><en> A conference, varying exhibition formats, a film and video program, performances, and workshops build its programmatic core.
<G-vec00084-002-s233><build_up.bilden><de> Den Schwerpunkt des jährlichen Festivals bilden ein Konferenzprogramm, wechselnde Ausstellungsformate, ein Film- und Videoprogramm, Performances und Workshops.
<G-vec00084-002-s234><build_up.bilden><en> When applying the HLB test one can find out through the way blood proteins are stored and build a net how strongly the body is affected by free radicals which corresponds to the severity of the disease.
<G-vec00084-002-s234><build_up.bilden><de> Beim HLB-Test kann aus der Art und Weise, wie sich die Bluteiweiße anlagern und ein Netz bilden, abgelesen werden, wie stark der Körper mit freien Radikalen belastet ist, was wiederum mit der Schwere der Erkrankung einhergeht.
<G-vec00084-002-s235><build_up.bilden><en> These questions build the framework of this talk. Final answers are intentionally not given because questions do not have an expiry date.
<G-vec00084-002-s235><build_up.bilden><de> Diese Fragen bilden das Gerüst dieses Vortrags, finale Antworten werden bewusst nicht geliefert, denn Fragen haben kein Verfallsdatum, Antworten hingegen schon.
<G-vec00084-002-s236><build_up.bilden><en> Traders can use support and resistance to build positions: using gains to finance additional lots.
<G-vec00084-002-s236><build_up.bilden><de> Trader können Unterstützung und Widerstand einsetzen, um Positionen zu bilden: Mittels Gewinnen zur Finanzierung zusätzlicher Lots.
<G-vec00084-002-s237><build_up.bilden><en> We build the bridge between production sites all over the world and the exacting requirements of European customers.
<G-vec00084-002-s237><build_up.bilden><de> Wir bilden die Brücke zwischen den Produktionen der ganzen Welt und den anspruchsvollen Kunden in Europa.
<G-vec00084-002-s238><build_up.bilden><en> Participation in sport and exercise can build trust and facilitate access to further guidance and educational programmes.
<G-vec00084-002-s238><build_up.bilden><de> Ein Zugang über Sport- und Bewegungsangebote kann Vertrauen bilden und so den Zugang für weitere Beratungs- und Bildungsangebote erleichtern.
<G-vec00084-002-s239><build_up.bilden><en> The cavities build up a threedimensional branched system. In the crystal structure determination no guest molecules were found to be in these cavities.
<G-vec00084-002-s239><build_up.bilden><de> Die Hohlräume bilden ein dreidimensional verzweigtes System, in dem in der Einkristallstrukturanalyse keine Gastmoleküle lokalisiert werden konnten.
<G-vec00084-002-s240><build_up.bilden><en> The stillness and beauty of Nature with its mountains, lakes, narrow valleys and scenic trails build the backdrop for rejuvenation, connecting with intuition and listening to the longing of our “True Nature”.
<G-vec00084-002-s240><build_up.bilden><de> Die Ruhe sowie die wunderschöne Natur mit ihrer Hügel- und Berglandschaft, weiten Seen, engen Tälern und herrlichen Wegen bilden einen energievollen Rahmen für Entschleunigung und kraftvolles Auftanken.
<G-vec00084-002-s241><build_up.bilden><en> RAe/StB build an office community and not a common firm with the consultancy company.
<G-vec00084-002-s241><build_up.bilden><de> RAe/StB bilden mit der Unternehmensberatung eine Bürogemeinschaft und keine Sozietät.
<G-vec00084-002-s242><build_up.bilden><en> Alternating stripes of classical herringbone and basket weaves build a tonal design, whose pattern affords both interesting close-up views and a broad texture when seen from further afar.
<G-vec00084-002-s242><build_up.bilden><de> Wechselnde Streifen des Fischgrätmusters und Leinenbindung bilden ein komplexes Design, dessen Muster sowohl interessante Nahansichten bietet als auch eine breite Textur aus der Ferne.
<G-vec00084-002-s243><build_up.bilden><en> With grammar, the student has the essential basis to build the correct sentences.
<G-vec00084-002-s243><build_up.bilden><de> Durch die Grammatik bekommt der Student die unentbehrliche Basis, um einen korrekten Satz zu bilden.
<G-vec00084-002-s244><build_up.bilden><en> We have made investments in developing an Automotive Competence Center which has allowed us to build a team of industry experts to best support our customers this growing sector," said Cindy Haring, managing director DHL Global Forwarding Brazil.
<G-vec00084-002-s244><build_up.bilden><de> Wir haben in ein Kompetenzzentrum für den Automobilbereich investiert und konnten ein Team von Branchenexperten bilden, welches unsere Kunden in diesem Wachstumssektor bestmöglich unterstützen", sagte Cindy Haring, Managing Director von DHL Global Forwarding Brasilien.
<G-vec00084-002-s245><build_up.bilden><en> The battle is not only to locate the best talent, it is to build teams around it, and to ensure the competencies the CFO needs to drive better productivity in their department are available.
<G-vec00084-002-s245><build_up.bilden><de> Es geht nicht nur darum, die talentiertesten Mitarbeiter ausfindig zu machen, sondern auch darum, Teams um sie herum zu bilden und dabei sicherzustellen, dass die Kompetenzen, die der CFO zur Steigerung der Produktivität in seiner Abteilung benötigt, verfügbar sind.
<G-vec00084-002-s246><build_up.bilden><en> In phase 2, glyceraldehyde-3-phosphate – a sugar with three carbon atoms from which the plant can build other organic compounds – forms.
<G-vec00084-002-s246><build_up.bilden><de> Das Enzym Rubisco ermöglicht die Anlagerung von Zucker mit drei Kohlenstoff-Atomen, aus dem die Pflanze andere organische Verbindungen bilden kann.
<G-vec00084-002-s323><build_up.errichten><en> To achieve this, we raise the soil and build settlements in cooperation with the population above the inundation level.
<G-vec00084-002-s323><build_up.errichten><de> Dazu schütten wir Erde auf und errichten in Zusammenarbeit mit der Bevölkerung Siedlungen, die über dem kritischen Pegelstand liegen.
<G-vec00084-002-s324><build_up.errichten><en> Holzhandlung Gundelach GmbH will build a modern wood retailers on its 18,000 sq.m. site.
<G-vec00084-002-s324><build_up.errichten><de> Die Holzhandlung Gundelach GmbH wird auf ihrem 18.000 Quadratmeter großen Grundstück eine moderne Holzhandlung errichten.
<G-vec00084-002-s325><build_up.errichten><en> Over the next few years, the company will also build a large module factory in California.
<G-vec00084-002-s325><build_up.errichten><de> In den nächsten Jahren wird das Unternehmen zudem eine große Modulfabrik in Kalifornien errichten.
<G-vec00084-002-s326><build_up.errichten><en> Overview Trellis Formwork is an easy and intuitive system of modular formwork in plastic used to build concrete walls, foundations and columns.
<G-vec00084-002-s326><build_up.errichten><de> Gitter-Verschalung ist ein einfaches und intuitives System der modularen Verschalung im Plastik, der benutzt wird, um Betonmauern, Grundlagen und Spalten zu errichten.
<G-vec00084-002-s327><build_up.errichten><en> Everyone who keeps a fence will agree with us: it’s not difficult to build a fence, but it’s difficult to maintain it regularly.
<G-vec00084-002-s327><build_up.errichten><de> Jeder, der einen Zaun sein eigen nennt, wird uns Recht geben, dass die Schwierigkeit nicht darin besteht, einen Zaun zu errichten, sondern ihn in Ordnung zu halten.
<G-vec00084-002-s328><build_up.errichten><en> The estate was built in a place where "Domator" housing cooperative had been planning to build a multilevel garage.
<G-vec00084-002-s328><build_up.errichten><de> Die Investition ist an derjenigen Stelle entstanden, wo die Wohnbaugenossenschaft "Domator" vorhatte, eine Tiefgarage mit mehreren Etagen zu errichten.
<G-vec00084-002-s329><build_up.errichten><en> We had to build a terrace.
<G-vec00084-002-s329><build_up.errichten><de> Wir mussten eine Terrasse errichten.
<G-vec00084-002-s330><build_up.errichten><en> Moreover,we additionally provide hardware and software to build complete solution.
<G-vec00084-002-s330><build_up.errichten><de> Außerdem stellen wir zusätzlich Hardware und Software zur Verfügung, um komplette Lösung zu errichten.
<G-vec00084-002-s331><build_up.errichten><en> But this new approach could help us build stronger and lighter materials in the future - which is something that's of great interest to industries such as aerospace and aviation.
<G-vec00084-002-s331><build_up.errichten><de> Aber dieses neue Konzept könnte uns helfen, die stärkeren und helleren Materialien in der Zukunft zu errichten - das etwas ist, das vom großen Interesse zu den Industrien wie Aerospace und Luftfahrt ist.
<G-vec00084-002-s332><build_up.errichten><en> Strategy Free Build your military empire and conquer your enemies by becoming a war mastermind.
<G-vec00084-002-s332><build_up.errichten><de> Strategie Frei Errichten Sie ein Militär-Imperium und besiegen Sie Ihre Feinde mit überlegener Kriegskunst.
<G-vec00084-002-s333><build_up.errichten><en> In a document released to the public and the media, the group reports speaks of "the state and federal governments' violent actions against the people of San Salvador Atenco, which are now registered among the systematic aggressions against the people of Atenco, starting with the federal government's attempt to build an international airport there in 2002."
<G-vec00084-002-s333><build_up.errichten><de> In einer an die Öffentlichkeit und die Presse gerichteten Stellungnahme spricht die Gruppe von gewaltsamen Aktionen gegen die Einwohner von San Salvador Atenco, die der Reihe systematischer Angriffe gegen die Bevölkerung hinzugefügt wurden - beginnend im Jahr 2002 mit dem Versuch der Bundesregierung einen internationalen Flughafen zu errichten.
<G-vec00084-002-s334><build_up.errichten><en> As today's standard for the transmission of electrical signals in a network, for example in a data center, compatible Blade Networks BN-QS-QS-CBL-1M Direct Attach Cables (DAC) provide a way to build high-availability connections in high-speed networks on short distances without having to compromise the arbitrary Blade Networks price policy of the large world conglomerates.
<G-vec00084-002-s334><build_up.errichten><de> Als heute üblicher Standard für die Übertragung elektrischer Signale, zum Beispiel in einem Rechenzentrum, stellen Blade Networks kompatible BN-QS-QS-CBL-1M Direct Attach Kabel (DAC) eine Möglichkeit dar, günstige hochverfügbarkeits-Verbindungen in Highspeed Netzwerken auf kurzen Distanzen zu errichten, ohne sich der willkürlichen Preispolitik der großen Weltkonzerne unterwerfen zu müssen.
<G-vec00084-002-s335><build_up.errichten><en> As today's standard for the transmission of electrical signals in a network, for example in a data center, compatible Dell 450-16140 Direct Attach Cables (DAC) provide a way to build high-availability connections in high-speed networks on short distances without having to compromise the arbitrary Dell price policy of the large world conglomerates.
<G-vec00084-002-s335><build_up.errichten><de> Als heute üblicher Standard für die Übertragung elektrischer Signale, zum Beispiel in einem Rechenzentrum, stellen Dell kompatible 450-16140 Direct Attach Kabel (DAC) eine Möglichkeit dar, günstige hochverfügbarkeits-Verbindungen in Highspeed Netzwerken auf kurzen Distanzen zu errichten, ohne sich der willkürlichen Preispolitik der großen Weltkonzerne unterwerfen zu müssen.
<G-vec00084-002-s336><build_up.errichten><en> Either you do not have enough resources to build the building or you cannot place it on that area of land.
<G-vec00084-002-s336><build_up.errichten><de> Entweder hast du nicht genug Ressourcen, um das Gebäude zu errichten, oder du kannst das Gebäude nicht auf diesem Terrain platzieren.
<G-vec00084-002-s337><build_up.errichten><en> Generous donations from the United States enabled Freie Universität to build some of its central facilities, including the Benjamin Franklin University Hospital and the Henry Ford Building.
<G-vec00084-002-s337><build_up.errichten><de> Großzügige Spenden aus den USA ermöglichten der Freien Universität, einige ihrer zentralen Gebäude zu errichten, unter ihnen das Universitätsklinikum Benjamin Franklin und der Henry-Ford-Bau.
<G-vec00084-002-s338><build_up.errichten><en> At the end of this course students will have all the knowledge and experience required to build powerful Access 2010 databases from scratch. Key learning points
<G-vec00084-002-s338><build_up.errichten><de> Am Ende des Kurses werden die Kursteilnehmer grundlegende Kenntnisse und eine breitgefächerte Erfahrung haben, die benötigt wird, um leistungsfähige Access 2010 Datenbanken von Grund auf zu errichten.
<G-vec00084-002-s339><build_up.errichten><en> This film is born from the want to understand what drives a woman or an elderly person to leave their homes to build barricades.
<G-vec00084-002-s339><build_up.errichten><de> Dieser Film versucht zu verstehen, was eine Dame oder einen Greisen dazu ermutigt, sein Haus zu verlassen, um Barrikaden zu errichten.
<G-vec00084-002-s340><build_up.errichten><en> In your guilds stronghold map you will come together to build many types of structures that will benefit your guild in PvE and PvP.
<G-vec00084-002-s340><build_up.errichten><de> Auf der Strongholds-Karte werdet ihr mit eurer Gilde gemeinsam viele verschiedene Strukturen errichten, die euch im PvE oder PvP Vorteile bieten.
<G-vec00084-002-s341><build_up.errichten><en> To protect your throne of ones and zeroes, you build a perimeter wall around yourself.
<G-vec00084-002-s341><build_up.errichten><de> Zum Schutz Ihres Volks aus Bits und Bytes errichten Sie eine Mauer um Ihr Gebiet.
<G-vec00084-002-s342><build_up.errichten><en> So not only does this drug help to build muscle, it can help to burn fat.
<G-vec00084-002-s342><build_up.errichten><de> Errichtet diese Drogenhilfe so nicht nur Muskel, es kann helfen, Fett zu brennen.
<G-vec00084-002-s343><build_up.errichten><en> The strategic location was last exploited by the Japanese during World War II, who used POW labor to build the infamous Death Railway to ferry supplies across.
<G-vec00084-002-s343><build_up.errichten><de> Außerdem wurde hier im Zweiten Weltkrieg die sogenannte Todeseisenbahn von den Japanern errichtet.
<G-vec00084-002-s344><build_up.errichten><en> It is free to build and allows for smaller Combines to have as much fun, as the bigger ones have with Mining Complexes.
<G-vec00084-002-s344><build_up.errichten><de> Sie kann kostenlos errichtet werden und ermöglicht kleineren Ligen ebenso viel Spielspaß wie Lichttürme den großen Clans.
<G-vec00084-002-s345><build_up.errichten><en> If you rather want to build you own home in paradise we can show you various Bali Real Estate that has been build by the architects and contractors we represent.
<G-vec00084-002-s345><build_up.errichten><de> Falls Sie am liebsten alles selber planen und auch selber bauen wollen, bieten wir Ihnen die Möglichkeit, zur Anregung Häuser zu besichtigen, die von den Architekten und Bauunternehmern, die wir vertreten, errichtet wurden.
<G-vec00084-002-s346><build_up.errichten><en> You could build a house on it or a block of flats as the land is large enough.
<G-vec00084-002-s346><build_up.errichten><de> Durch das relativ große Grundstück kann ein Haus oder auch ein Apartmentblock errichtet werden.
<G-vec00084-002-s347><build_up.errichten><en> Make it something new and build it as strong as you can.
<G-vec00084-002-s347><build_up.errichten><de> Macht etwas Neues daraus und errichtet es so stark wie ihr könnt.
<G-vec00084-002-s349><build_up.errichten><en> In the third period the tower was build in two segments.
<G-vec00084-002-s349><build_up.errichten><de> Der Turm wurde seit 1463 bis 1484 errichtet, zuerst mit zwei Segmente(1).
<G-vec00084-002-s350><build_up.errichten><en> As a contemporary marketer, you understand the value of a brand story, the tribe you build around your brand with that story, the influence this has on a buyer, especially with a considered purchase (and one that is so public that can be a statement of you).
<G-vec00084-002-s350><build_up.errichten><de> Moderne Marketer verstehen den Wert einer Markenstory, den Stamm, den man mit einer solchen Story rund um die Marke errichtet, und die Wirkung, die das, insbesondere bei einem durchdachten Kauf, auf einen Käufer hat (und eine, die so öffentlich ist, wie eine Aussage von Ihnen nur sein kann).
<G-vec00084-002-s351><build_up.errichten><en> To better serve customers in China and Asia with their cutting edge technology, the two global companies aligned in a joint venture to build the largest silicone manufacturing site in China.
<G-vec00084-002-s351><build_up.errichten><de> Um ihre jeweiligen Kunden in China und in der Region Asien noch besser mit technologisch hochstehenden Lösungen bedienen zu können, haben die beiden Unternehmen gemeinsam den größten Produktionsstandort für Silicone in China errichtet.
<G-vec00084-002-s352><build_up.errichten><en> For example, if someone wants to build a new house, he needs to build a small one for the ghost first before he can even start to build his own. It’s because the Thai people believe that every property is haunted by a ghost.
<G-vec00084-002-s352><build_up.errichten><de> Wenn zum Beispiel irgendwo ein neues Haus gebaut wird, dann wird erst ein kleines Geisterhaus errichtet und der Geist, der auf dem Grundstück „wohnt“, von einem Mönch beschwichtigt in dieses für ihn errichtete Haus umzuziehen.
<G-vec00084-002-s353><build_up.errichten><en> A Silicon Mine is build on an asteroid, where it is to mine it.
<G-vec00084-002-s353><build_up.errichten><de> Eine Siliziummine wird auf einem Asteroiden errichtet, wo sie Silizium abbaut.
<G-vec00084-002-s354><build_up.errichten><en> A unique blend of peptide-loaded Matrixyl 3000, Wild Pansy extract and Pro-Biotic Complexes work to reduce the appearance of fine lines and build a protective skin barrier to repair and smooth uneven textures.
<G-vec00084-002-s354><build_up.errichten><de> Eine einzigartige Mischung aus peptidbeladenem Matrixyl 3000, wildes Stiefmütterchenextrakt und probiotischen Komplexen reduziert das Auftreten von feinen Linien und errichtet eine schützende Hautbarriere, um unebene Strukturen zu reparieren und auszuglätten.
<G-vec00084-002-s355><build_up.errichten><en> In 2012 we set out to build the first watch factory in Detroit and to create jobs by doing so.
<G-vec00084-002-s355><build_up.errichten><de> 2012 haben wir die erste Uhrenfabrik in Detroit errichtet, weil wir Arbeitsplätze schaffen wollten.
<G-vec00084-002-s356><build_up.errichten><en> The Alaska Blood bank was build with big effort and support from the Lions Clubs.
<G-vec00084-002-s356><build_up.errichten><de> Die Blutbank von Alaska wurde mit großer Unterstützung und Beteiligung der Lions errichtet.
<G-vec00084-002-s357><build_up.errichten><en> Build a net turret that immobilizes nearby foes.
<G-vec00084-002-s357><build_up.errichten><de> Errichtet einen Netzturm, der Gegner in der Nähe immobilisiert.
<G-vec00084-002-s358><build_up.errichten><en> It is not allowed to build new churches.
<G-vec00084-002-s358><build_up.errichten><de> Neue Kirchen dürfen nicht errichtet werden.
<G-vec00084-002-s359><build_up.errichten><en> Over the past several years of Earth time, we have given in-depth instructions about how to build Pyramids of Light/Power in the fifth dimension.
<G-vec00084-002-s359><build_up.errichten><de> Während der letzten paar Jahre der Erdenzeit haben wir Euch detaillierte Instruktionen darüber gegeben, wie man Pyramiden des Lichts/der Macht in der fünften Dimension errichtet.
<G-vec00084-002-s360><build_up.errichten><en> Hall 12, the former saddlery and needle case room build in 1899, is the most interesting hall of the SPINNEREI.
<G-vec00084-002-s360><build_up.errichten><de> Die Halle 12, ursprünglich als Nadelsetzerei und Sattlerei im Jahre 1899 errichtet, ist heute eine der spannendsten Ausstellungsflächen der SPINNEREI.
<G-vec00084-002-s361><build_up.erstellen><en> This type of services allows the Owner to build user profiles by starting from an email address, a personal name, or other information that the User provides to this Application, as well as to track User activities through analytics features.
<G-vec00084-002-s361><build_up.erstellen><de> Diese Art von Diensten erlauben es dem Eigentümer Nutzerprofile zu erstellen, indem sie zunächst die E-Mail-Adresse, den Namen oder sonstige Angaben verwenden, die der Nutzer an diese Anwendung übermittelt hat, als auch das Nachverfolgen von Nutzeraktivitäten durch Analysefunktionalitäten.
<G-vec00084-002-s362><build_up.erstellen><en> NetGuardians’ solution uses advanced analytics, dynamic profiling and machine learning to build highly accurate customer and employee profiles.
<G-vec00084-002-s362><build_up.erstellen><de> Die Lösung von NetGuardians kombiniert fortschrittliche Analysen, dynamisches Profiling und maschinelles Lernen, um hochpräzise Kunden- und Mitarbeiterprofile zu erstellen.
<G-vec00084-002-s363><build_up.erstellen><en> If you still want to sell extensions through your own websites or via other channels, you can build your own installer or provide instructions to your users on how to use the Extension Manager command line to install your extension.
<G-vec00084-002-s363><build_up.erstellen><de> Wenn Sie Ihre Erweiterungen über eigene Websites oder andere Vertriebskanäle verkaufen möchten, können Sie eigene Installationsprogramme erstellen oder Ihren Benutzern Anweisungen zur Installation der Erweiterung mithilfe der Extension Manager-Befehlszeile zur Verfügung stellen.
<G-vec00084-002-s364><build_up.erstellen><en> Our software suites ~sedna presenter and ~sedna touch offer a maximum of creative possibilities and a wealth of tools to build and transport fascinating, attractive and convincing brand messages with the highest quality level.
<G-vec00084-002-s364><build_up.erstellen><de> Unsere Softwarekollektionen ~sedna presenter und ~sedna touch ermöglichen ein Höchstmaß an kreativen Ideen und die notwendigen Mittel, um faszinierende, anziehende und überzeugende Markenbotschaften zu erstellen.
<G-vec00084-002-s365><build_up.erstellen><en> Build a family tree that can be accessed online and updated by other family members.
<G-vec00084-002-s365><build_up.erstellen><de> Erstellen Sie einen Familienstammbaum, der online abgerufen und von anderen Familienmitgliedern aktualisiert werden kann.
<G-vec00084-002-s366><build_up.erstellen><en> Build lists of up to 200,000 generated keyword lists.
<G-vec00084-002-s366><build_up.erstellen><de> Erstellen von Listen mit bis zu 200.000 generierten Keywords.
<G-vec00084-002-s367><build_up.erstellen><en> We use it in particular to develop algorithms for our search platforms and machine learning features, and we find SageMaker's hosted Jupyter Notebooks allows us to build and iterate rapidly.
<G-vec00084-002-s367><build_up.erstellen><de> Wir verwenden es insbesondere, um Algorithmen für unsere Suchplattformen und Funktionen für maschinelles Lernen zu entwickeln, und stellen fest, dass wir mit den von SageMaker gehosteten Jupyter-Notebooks schnell erstellen und iterieren können.
<G-vec00084-002-s368><build_up.erstellen><en> This means that we must always define the purpose before we can define and build the model, and that there will always be several models for different purposes.
<G-vec00084-002-s368><build_up.erstellen><de> Das bedeutet, dass wir immer den Zweck vordefinieren müssen, bevor wir das Modell beschreiben und erstellen können, und dass es immer mehrere Modelle für die unterschiedlichen Zwecke geben wird.
<G-vec00084-002-s369><build_up.erstellen><en> Making sure that MediaWiki, the platform we build our wikis on, is available in as many languages as possible is a central task for Wikimedia translators.
<G-vec00084-002-s369><build_up.erstellen><de> Die Gewährleistung, dass MediaWiki, die Plattform, mit der wir unsere Wikis erstellen, in so vielen Sprachen wie möglich verfügbar ist, ist eine zentrale Aufgabe für Wikimedia-Übersetzer.
<G-vec00084-002-s370><build_up.erstellen><en> Part of Arian Silver's forward-looking strategy lies in the envisaged use of large scale mechanized mining techniques over wider mineralized structures, which reduces the overall operating cost per ounce of silver, and to build up NI 43-101 compliant resources.
<G-vec00084-002-s370><build_up.erstellen><de> Ein Teil der vorausblickenden Strategie von Arian Silver ist die Verwendung von groß angelegten mechanisierten Bergbautechniken auf größeren mineralisierten Strukturen, um die insgesamten Betriebskosten pro Unze Silber zu reduzieren und um Ressourcen gemäß NI 43-101 zu erstellen.
<G-vec00084-002-s371><build_up.erstellen><en> You can access a pre-built report directly from the AWS IoT 1-Click console, the iOS or Android mobile app, or build a custom report using Amazon CloudWatch.
<G-vec00084-002-s371><build_up.erstellen><de> Sie können direkt über die AWS IoT 1-Click-Konsole oder die Mobil-App für iOS oder Android auf einen vordefinierten Bericht zugreifen oder mit Amazon CloudWatch einen individuellen Bericht erstellen.
<G-vec00084-002-s372><build_up.erstellen><en> Upload or record greetings, build menus and easily make changes to customise your customers' experiences. More Resources Phone support 101
<G-vec00084-002-s372><build_up.erstellen><de> Sie können Grüße hochladen oder aufzeichnen, Menüs erstellen und im Handumdrehen Änderungen vornehmen, um das Kundenerlebnis wie gewünscht anzupassen.
<G-vec00084-002-s373><build_up.erstellen><en> We can help you build a robust business case to support your investment decision.
<G-vec00084-002-s373><build_up.erstellen><de> Wir können Ihnen helfen, einen robusten Business Case zu erstellen, der Ihre Investitionsentscheidung unterstützt.
<G-vec00084-002-s374><build_up.erstellen><en> This 27-minute video will walk you through step-by-step how to build your first app with Windows App Studio Beta.
<G-vec00084-002-s374><build_up.erstellen><de> In diesem 27-minütigen Video wird Schritt für Schritt beschrieben, wie Sie mit Windows App Studio Beta Ihre erste App erstellen.
<G-vec00084-002-s375><build_up.erstellen><en> This is accomplished by the application taking user input and combining it with static parameters to build a SQL query.
<G-vec00084-002-s375><build_up.erstellen><de> Dies wird durch die Applikation erreicht, welche den Input des Benutzers mit statischen Parametern kombiniert, um eine SQL Abfrage zu erstellen.
<G-vec00084-002-s376><build_up.erstellen><en> Multiple reference frames can be related to each other to build the dependency that exists in a real application.
<G-vec00084-002-s376><build_up.erstellen><de> Mehrere Bezugssysteme können miteinander verknüpft werden, um die Abhängigkeit zu erstellen, die der Realität entspricht.
<G-vec00084-002-s377><build_up.erstellen><en> Work across teams to build, test and manage different versions of your models in production with Azure Databricks and Azure Machine Learning.
<G-vec00084-002-s377><build_up.erstellen><de> Arbeiten Sie mit Azure Databricks und Azure Machine Learning im Team zusammen, um verschiedene Versionen Ihrer Modelle in der Produktion zu erstellen, zu testen und zu verwalten.
<G-vec00084-002-s378><build_up.erstellen><en> Hire C++ developers on hourly or full time (dedicated monthly) basis to build feature-rich, interactive and secure C++ applications.
<G-vec00084-002-s378><build_up.erstellen><de> ENTWICKLER EINSTELLEN Stellen Sie C++-Entwickler stündlich oder ganztägig (monatlich) ein, um funktionsreiche, interaktive und sichere C++-Anwendungen zu erstellen.
<G-vec00084-002-s379><build_up.erstellen><en> Help your child build a word family.
<G-vec00084-002-s379><build_up.erstellen><de> Hilf deinem Kind dabei, eine Wortfamilie zu erstellen.
<G-vec00084-002-s380><build_up.erstellen><en> The virtual machines with appropriate resource allocation, software installation, and system configurations are used to build lightweight security laboratories on a hosting computer.
<G-vec00084-002-s380><build_up.erstellen><de> Unter Beachtung angemessener Ressourcennutzung, Softwareinstallationen und Systemkonfigurationen wurden virtuelle Maschinen als Übungsstationen erstellt, die auf einem einzelnen Rechner betrieben werden.
<G-vec00084-002-s381><build_up.erstellen><en> Technical Trader uses palettes and buttons to build a custom user interface.
<G-vec00084-002-s381><build_up.erstellen><de> Technical Trader erstellt eine spezielle Anwenderschnittstelle mit Paletten und Knöpfen.
<G-vec00084-002-s382><build_up.erstellen><en> This data will be used to build the statistical models that underpin the Predict product recommendations.
<G-vec00084-002-s382><build_up.erstellen><de> Auf Basis dieser Daten werden die statistischen Modelle erstellt, die den Predict Produktempfehlungen zugrunde liegen.
<G-vec00084-002-s383><build_up.erstellen><en> Having performed this example in countless workshops (which is a bit different than reading on a webpage), I have found that some of the comments about the business idea for more technical people are about how to build it, whereas for marketers, the focus is on how to market the product.
<G-vec00084-002-s383><build_up.erstellen><de> Nachdem ich dieses Beispiel in unzähligen Workshops durchgeführt habe (was ein bisschen anders ist als das Lesen auf einer Webseite), habe ich festgestellt, dass einige der Kommentare über die Geschäftsidee für technisch versiertere Leute sind, wie man sie erstellt, während für Vermarkter der Fokus ist wie man das Produkt vermarktet.
<G-vec00084-002-s384><build_up.erstellen><en> Based on the wishes, we select a suitable platform to build the online store with.
<G-vec00084-002-s384><build_up.erstellen><de> Basierend auf den Wünschen wählen wir eine geeignete Plattform aus, mit der der Internetshop erstellt werden kann.
<G-vec00084-002-s385><build_up.erstellen><en> I was experimenting processing and build this little stupid game to see how far we can go with it.
<G-vec00084-002-s385><build_up.erstellen><de> Ich hab mit Processing experimentiert und dieses kleine blöde Spiel erstellt, um zu sehen, wie weit wir damit kommen.
<G-vec00084-002-s386><build_up.erstellen><en> 3D printing The design process of 3D printing: firstly use software to build a model, and then split the 3D model to a layer-by-layer cross-section, ie, slicing, so as to guide the printer to print layer by layer.
<G-vec00084-002-s386><build_up.erstellen><de> 3D-Druck Der Entwurfsprozess des 3D-Drucks: Zuerst wird ein Modell mithilfe von Software erstellt und anschließend das 3D-Modell in einen schichtweisen Querschnitt (Slicing) aufgeteilt, um den Drucker Schicht für Schicht zu drucken.
<G-vec00084-002-s387><build_up.erstellen><en> But Outlook prefers that you build distribution lists from your Contacts, so you first must add the sender to an address book in Contacts.
<G-vec00084-002-s387><build_up.erstellen><de> In Outlook werden Verteilerlisten jedoch aus Ihren Kontakten erstellt, daher müssen Sie also den Absender zuerst zu einem Adressbuch in den Kontakten hinzufügen.
<G-vec00084-002-s388><build_up.erstellen><en> How to build Spark applications architecture to facilitate code reuse, quality and performance.
<G-vec00084-002-s388><build_up.erstellen><de> Wie man eine Architektur von Spark-Anwendungen erstellt, um die Wiederverwendung von Code, Qualität und Leistung zu unterstützen.
<G-vec00084-002-s389><build_up.erstellen><en> Before this plugin worked by converting CSV files into HTML Tables, but now you can start from scratch and build your table in the backend.
<G-vec00084-002-s389><build_up.erstellen><de> Zu Anfang konnte das Plugin nur CSV Dateien konvertieren, nun können Tabellen von Grund auf in einem Tabellen-Editor gestaltet und erstellt werden.
<G-vec00084-002-s390><build_up.erstellen><en> In each Class you will have to select up to 7 Units that will be used to build your 2 teams.
<G-vec00084-002-s390><build_up.erstellen><de> In jeder Klasse könnt ihr bis zu 7 Einheiten auswählen, aus denen ihr dann eure 2 Teams erstellt.
<G-vec00084-002-s391><build_up.erstellen><en> After you build the Desktop Web Viewer app, click "URL" to display your content in your current browser.
<G-vec00084-002-s391><build_up.erstellen><de> Nachdem Sie die App für den Web Viewer für den Desktop erstellt haben, klicken Sie auf „URL“, um den Inhalt in Ihrem aktuellen Browser anzuzeigen.
<G-vec00084-002-s392><build_up.erstellen><en> They know how to build networks with reduced vulnerability, but depend on applications like web servers and web browsers to keep things safe.
<G-vec00084-002-s392><build_up.erstellen><de> Sie wissen, wie man Netzwerke mit geringerer Anfälligkeit erstellt, aber diese hängen von Anwendungen wie Webservern und Webbrowsern ab, um die Sicherheit zu gewährleisten.
<G-vec00084-002-s393><build_up.erstellen><en> − Using the external toolchain is an easy way to build applications for your Neo.
<G-vec00084-002-s393><build_up.erstellen><de> Die Benutzung der externen Toolchain stellt einen einfachen Weg dar, mit den Applikationen für das Neo erstellt werden können.
<G-vec00084-002-s394><build_up.erstellen><en> The Media Manager will build a list of all the files used in your composition, and mark the missing ones in red for you.
<G-vec00084-002-s394><build_up.erstellen><de> Der Medienmanager erstellt eine Liste aller in Ihrer Komposition verwendeten Dateien und markiert die fehlenden in Rot.
<G-vec00084-002-s395><build_up.erstellen><en> Power BI Embedded provides stunning, fully interactive data visualisations in your customer-facing apps without the time and expense of having to build it from the ground up.
<G-vec00084-002-s395><build_up.erstellen><de> Power BI Embedded bietet beeindruckende, hochgradig interaktive Datenvisualisierungen in Ihren Apps für Kunden – und das ohne den Zeit- und Kostenaufwand, der erforderlich wäre, wenn diese von Grund auf erstellt werden müssten.
<G-vec00084-002-s396><build_up.erstellen><en> Instead, the team developed a method to build two meters of belt at a time and then assemble them together at the end.
<G-vec00084-002-s396><build_up.erstellen><de> Stattdessen entwickelte das Team eine Methode, bei der jeweils zwei Meter des Bands erstellt und die Teile am Ende zusammengesetzt wurden.
<G-vec00084-002-s397><build_up.erstellen><en> This website is build with Hugo, the source code is hosted on GitHub.
<G-vec00084-002-s397><build_up.erstellen><de> Diese Website wird mit Hugo erstellt, der Quellcode ist öffentlich auf GitHub verfügbar.
<G-vec00084-002-s398><build_up.erstellen><en> It ingests all of a company’s first-party data and uses that to build complete pictures of all of your customers (also known as a single customer view).
<G-vec00084-002-s398><build_up.erstellen><de> Sie erfasst alle Erstanbieter-Daten eines Unternehmens und erstellt daraus vollständige Kundenprofile (auch Single Customer View genannt).
<G-vec00084-002-s475><build_up.schaffen><en> From developing the dreams of students and makers to helping professional engineers develop their ideas and products, we build a community that benefits from our technology.
<G-vec00084-002-s475><build_up.schaffen><de> Egal, ob es darum geht, Träume von Studenten und Makern weiterzuentwickeln oder professionellen Entwicklern bei der Umsetzung ihrer Ideen und Produkte zu helfen – wir schaffen eine Community, die von unseren Technologien profitiert.
<G-vec00084-002-s476><build_up.schaffen><en> We are new to eBay and our goal is to build a reputation from honesty and transparency.
<G-vec00084-002-s476><build_up.schaffen><de> Wir sind neu zu eBay und unser Ziel ist es, einen Ruf von Ehrlichkeit und Transparenz zu schaffen.
<G-vec00084-002-s477><build_up.schaffen><en> Albeit in the case of the Vietnam war, the painful daily images of the dead American youths that were brought home highly contributed to build an awareness about how useless, unfair and absurd that war was, the situation with the child was different.
<G-vec00084-002-s477><build_up.schaffen><de> Wenn auch beim Vietnams Krieg die schmerzhaften Bilder junger leblos zurückkehrender Nordamerikaner, die es täglich beobachten musste, dazu beitrugen, ein Bewußtsein über das Sterile, Ungerechte und Absurde jenes Krieges zu schaffen, geschah im Falle des Jungen nichts Ähnliches.
<G-vec00084-002-s478><build_up.schaffen><en> Fastems mission is to build a world where the manufacturing industry is a cornerstone of success and a source of sustainable well-being in the society.
<G-vec00084-002-s478><build_up.schaffen><de> Die Mission von Fastems besteht darin, eine Welt zu schaffen, in der die Fertigungsindustrie ein Eckpfeiler des Erfolgs und eine Quelle nachhaltigen Wohlbefindens in der Gesellschaft ist.
<G-vec00084-002-s479><build_up.schaffen><en> With our network of partners we build connections across Europe.
<G-vec00084-002-s479><build_up.schaffen><de> Mit unserem Partnernetzwerk schaffen wir Verbindungen in ganz Europa.
<G-vec00084-002-s480><build_up.schaffen><en> Here, we started to build a new home, while we wait for the time of our revenge.
<G-vec00084-002-s480><build_up.schaffen><de> Hier fingen wir an, ein neues Heim zu schaffen, während wir auf den Tag unserer Rache warten.
<G-vec00084-002-s481><build_up.schaffen><en> May Israelis and Palestinians have the courage and determination to write a new page of history, where hate and revenge give way to the will to build together a future of mutual understanding and harmony.
<G-vec00084-002-s481><build_up.schaffen><de> Israelis und Palästinenser mögen den Mut und die Entschlossenheit haben, eine neue Seite der Geschichte zu schreiben, in der Hass und Vergeltung den Platz räumen gegenüber dem Willen, gemeinsam eine Zukunft gegenseitigen Verständnisses und Einklanges zu schaffen.
<G-vec00084-002-s482><build_up.schaffen><en> Contentserv has been recently recognized as a Contender by Forrester in its latest independent MRM evaluation and highlighted in Forrester”s latest PIM Now Tech report as providing end-to-end functionality for organizations looking to build a foundation for today and beyond.
<G-vec00084-002-s482><build_up.schaffen><de> Contentserv wurde kürzlich von Forrester in seiner jüngsten unabhängigen MRM-Bewertung als Contender anerkannt und im jüngsten PIM Now Tech-Bericht von Forrester als Anbieter von End-to-End-Funktionalität für Organisationen hervorgehoben, die eine digitale Basis für heute und darüber hinaus schaffen wollen.
<G-vec00084-002-s483><build_up.schaffen><en> Instead, they aim for a kaleidoscopic and resourceful approach that emerges from the glaring necessity to build a knowledge-base simultaneously broad in its disciplinary perspectives as well as out-of-the-box and that helps to readjust the human position within a broader geo-fabric.
<G-vec00084-002-s483><build_up.schaffen><de> Stattdessen streben sie nach einem kaleidoskopischen Ansatz, der sich aus der dringenden Notwendigkeit ergibt, eine Wissensbasis zu schaffen, die in ihren einzelwissenschaftlichen Sichtweisen breit aufgestellt und frei von Schubladendenken ist.
<G-vec00084-002-s484><build_up.schaffen><en> In order to to be able to fundamentally understand the consequences of a collision between an aircraft and a drone, the Fraunhofer Institute for High-Speed Dynamics, Ernst-Mach-Institut, EMI is now planning to build a test bench for recreating various collision scenarios with complete drones.
<G-vec00084-002-s484><build_up.schaffen><de> Um entsprechende Grundlagen zu schaffen, plant das Fraunhofer-Institut für Kurzzeitdynamik, Ernst-Mach-Institut, EMI derzeit die Errichtung eines Teststands, auf dem Kollisionsszenarien mit kompletten Drohnen nachgestellt werden können.
<G-vec00084-002-s485><build_up.schaffen><en> Build your services revenue Form the foundation for years of profitable services revenue by leveraging the migration and device renewal opportunity.
<G-vec00084-002-s485><build_up.schaffen><de> Schaffen Sie die Grundlage für viele Jahre profitabler Dienstleistungsumsätze, indem Sie Chancen bei der Migration und Reprofilierung von Geräten nutzen.
<G-vec00084-002-s486><build_up.schaffen><en> Our core values are trust, which helps us build solutions together, passion, which inspires dedication, teamwork with our customers and our partners, disruption to innovate and think outside the box, and responsibility, since we always hold responsibility for our actions.
<G-vec00084-002-s486><build_up.schaffen><de> Unsere Kernwerte sind das Vertrauen, das es uns ermöglicht, gemeinsam Großes zu schaffen, die Leidenschaft, die uns dazu treibt, stets unser Bestes zu geben, der Teamgeist zur erfolgreichen Zusammenarbeit mit Kunden und OVH Partnern, die Disruption, um durch eine andere Denkweise Innovationen hervorzubringen, und unsere Verantwortung, denn wir wissen, dass unser Handeln auch verpflichtet.
<G-vec00084-002-s487><build_up.schaffen><en> Our goal: to build a foundation of trust between management and employees, partners and customers alike.
<G-vec00084-002-s487><build_up.schaffen><de> Das Ziel: zwischen Geschäftsleitung und Mitarbeitern, Partnern und Kunden ein Fundament des Vertrauens zu schaffen.
<G-vec00084-002-s488><build_up.schaffen><en> The Nexus 9 is an impressive tablet but not with the build quality you expect out of HTC.
<G-vec00084-002-s488><build_up.schaffen><de> Mit dem Nexus 9 hätte Google einen großen Wurf am Tablet-Markt schaffen können.
<G-vec00084-002-s489><build_up.schaffen><en> AI seeks, fundamentally, to build a constructive union between a whole people and the massive entirety of what people talk about as past and present capacities: achievements, assets, unexplored potentials, innovations, strengths, elevated thoughts, opportunities, benchmarks, high point moments, lived values, traditions, strategic competencies, stories, expressions of wisdom, insights into the deeper corporate spirit or soul - and visions of valued and possible futures.
<G-vec00084-002-s489><build_up.schaffen><de> AI versucht grundlegend einen konstruktiven Zusammenschluss zwischen ganzen Leuten und der massiven Ganzheit zu schaffen, worüber Leute als vergangene und gegenwärtige Kapazitäten sprechen: Erfolge, Aktiva, nicht erforschte Potentiale, Innovationen, Stärken, höhere Gedanken, Gelegenheiten Benchmarks, Höhepunkte, gelebte Werte, Traditionen, strategische Kompetenzen, Geschichten, Ausdrücke von Klugheit, Einblicke in den tieferen unternehmerischen Geist oder in die Seele - und Vorstellungen der geschätzten und möglichen Zukunft.
<G-vec00084-002-s490><build_up.schaffen><en> ProveSource is a social proof marketing platform that streams recent customer behaviors on your website to build trust and increase conversions.
<G-vec00084-002-s490><build_up.schaffen><de> ProveSource ist eine Social-Proof-Marketingplattform, die das aktuelle Kundenverhalten auf deiner Website streamt, um Vertrauen zu schaffen und die Zahl der Conversions zu steigern.
<G-vec00084-002-s491><build_up.schaffen><en> Planon wants to build its future on sustainable profit, based on sound business ethics and respect for its stakeholders, and wants to be a good corporate citizen.
<G-vec00084-002-s491><build_up.schaffen><de> Planon möchte ein guter Corporate Citizen sein und ist bestrebt, seine Profitabilität auf nachhaltige Weise und auf der Grundlage einer guten Geschäftsethik sowie Respekt gegenüber seinen Stakeholdern zu schaffen.
<G-vec00084-002-s492><build_up.schaffen><en> We build the requirements to realise your ideas.
<G-vec00084-002-s492><build_up.schaffen><de> Wir schaffen die Voraussetzungen für die Realisierung Ihrer Vorstellungen.
<G-vec00084-002-s493><build_up.schaffen><en> All this potential, taken together, can make the difference to a business that places at its centre: the person, the quality of its relationships, the truth of its commitment to build a more just world, a world that is truly everyone’s.
<G-vec00084-002-s493><build_up.schaffen><de> Gemeinsam können all diese Kräfte etwas bewirken in einem Unternehmen, das den Menschen in den Mittelpunkt stellt, die Qualität seiner Beziehungen, die Wahrhaftigkeit seines Einsatzes, eine gerechtere Welt zu schaffen, eine Welt, die wirklich für alle da ist.
<G-vec00179-002-s114><build_up.ausbauen><en> This dependency forces state managers to be concerned about maintaining economic activity, irrespective of whether they are bureaucrats or elected professional politicians and regardless of whether their goals are to build up military capacity or implement social reforms.
<G-vec00179-002-s114><build_up.ausbauen><de> Diese Abhängigkeit zwingt die Entscheidungsträger des Staates, sich um die Aufrechterhaltung der wirtschaftlichen Aktivität zu kümmern, unabhängig davon, ob sie in der staatlichen Verwaltung arbeiten, oder zum gewählten hauptberuflichen politischen Führungspersonal gehören und auch unabhängig davon, ob ihr Ziel daran besteht, die Schlagkraft des Militärs auszubauen oder Sozialreformen umzusetzen.
<G-vec00179-002-s115><build_up.ausbauen><en> At the point where the performers become practised enough to feel secure, begin to build their roles and to act, the piece loses more than just its charm.
<G-vec00179-002-s115><build_up.ausbauen><de> In dem Moment, in dem die Darsteller genug Praxis haben, um sich sicher zu fühlen, wenn sie anfangen, ihre Rolle auszubauen und zu spielen, dann verliert das Stück mehr als nur seinen Charme.
<G-vec00179-002-s116><build_up.ausbauen><en> They opened in late 2018 and have already managed to build up their client list extensively.
<G-vec00179-002-s116><build_up.ausbauen><de> Sie wurden Ende 2018 eröffnet und haben es bereits geschafft, ihre Kundenliste umfassend auszubauen.
<G-vec00179-002-s117><build_up.ausbauen><en> Different workshops will give the participants the opportunity to deepen their knowledge about TTIP and to coordinate common activities to build up civil resistance.
<G-vec00179-002-s117><build_up.ausbauen><de> Bei verschiedenen Workshops können die Teilnehmer_innen ihre Kenntnisse von TTIP vertiefen und gemeinsame Aktivitäten koordinieren, um zivilen Widerstand auf- und auszubauen.
<G-vec00179-002-s118><build_up.ausbauen><en> And even if a concept is well accepted, it is imperative for a startup to constantly adapt in order to keep up with the market and continue to build on its lead.
<G-vec00179-002-s118><build_up.ausbauen><de> Und auch wenn gute Konzepte greifen, ist es unabdingbar, dass das Startup sich stetig anpasst, um am Markt dran zu sein und seinen Vorsprung weiter auszubauen.
<G-vec00179-002-s119><build_up.ausbauen><en> He later joined a younger diversified investment firm to build their private equity practice.
<G-vec00179-002-s119><build_up.ausbauen><de> Danach schließt er sich als Managing Director einem jüngeren deutschen Investmenthaus an um dort den Private Equity Bereich auszubauen.
<G-vec00179-002-s120><build_up.ausbauen><en> The head of the Belarusian delegation emphasized the permanent demand for CEI at the current stage, the need to build up applied project activities in socially and economically significant areas and to prevent the emergence of dividing lines in the region.
<G-vec00179-002-s120><build_up.ausbauen><de> Der Leiter der belarussischen Delegation unterstrich die beständige CEI-Wichtigkeit, die Notwendigkeit, angewandte Tätigkeit auf sozialen und wirtschaftlich wichtigen Gebieten auszubauen sowie Nichtzulassung von Trennlinien in der Region.
<G-vec00179-002-s121><build_up.ausbauen><en> The Biointelligence Competence Center sees biointelligent value creation as a unique opportunity for Germany to implement a positive vision as a pioneer in this field that not only enables the economy to build on existing competitive advantages, but also guarantees sustainable development.
<G-vec00179-002-s121><build_up.ausbauen><de> Das Kompetenzzentrum Biointelligenz sieht in der biointelligenten Wertschöpfung eine einzigartige Gelegenheit für Deutschland, eine positive Vision als Vorreiter umzusetzen, die es der Wirtschaft nicht nur erlaubt, existieren-de Wettbewerbsvorteile weiter auszubauen, sondern einen nachhaltigen Fortschritt garantiert.
<G-vec00179-002-s122><build_up.ausbauen><en> The fair was not only an opportunity to build business relationships, but also to exchange experiences.
<G-vec00179-002-s122><build_up.ausbauen><de> Die Messe war nicht nur eine Gelegenheit, Geschäftsbeziehungen auszubauen, sondern gab auch die Gelegenheit Erfahrungen auszutauschen.
<G-vec00179-002-s123><build_up.ausbauen><en> Our number one priority is to identify our employees’ potential, increase their motivation and build their qualifications.
<G-vec00179-002-s123><build_up.ausbauen><de> Unsere höchste Priorität ist es, Potenziale von Mitarbeitern zu erkennen, ihre Motivation zu fördern und ihre Qualifikationen auszubauen.
<G-vec00179-002-s124><build_up.ausbauen><en> In this way you can make a positive contribution to teaching and research and help to build on Reutlingen University’s good reputation.
<G-vec00179-002-s124><build_up.ausbauen><de> So tragen Sie dazu bei, die Lehre und Forschung und den guten Ruf der Hochschule Reutlingen kontinuierlich auszubauen.
<G-vec00179-002-s125><build_up.ausbauen><en> In order to safeguard this status and to build on it for the long term, the University, together with its partners on the Göttingen Campus, places particular emphasis on innovation and enhancement of profile, fostering early career researchers and expanding research and information infrastructure.
<G-vec00179-002-s125><build_up.ausbauen><de> Um diesen Status zu sichern und langfristig auszubauen, setzt sie gemeinsam mit ihren Partnern am Göttingen Campus auf Innovation und Profilschärfung, Nachwuchsförderung, Chancengleichheit und Diversität sowie den Ausbau der Forschungs- und Informationsinfrastruktur.
<G-vec00179-002-s126><build_up.ausbauen><en> The Citrix Service Provider Program helps service providers build high-value hosted workspace businesses through extensive guidance, support and tools to plan, build, market and sell.
<G-vec00179-002-s126><build_up.ausbauen><de> CITRIX SERVICE PROVIDER (CSP) Das "Citrix Service Provider"-Programm hilft Partnern durch ausführliche Anleitungen, Support und Tools, wertvolle Geschäfte mit gehosteten Arbeitsplätzen auszubauen.
<G-vec00179-002-s127><build_up.ausbauen><en> Enhanced and better targeted EU development assistance could accompany reform, helping to build administrative capacity and mitigate social adjustment costs.
<G-vec00179-002-s127><build_up.ausbauen><de> Eine intensivere und gezieltere Entwicklungshilfe der EU könnte die Reformen begleiten und dazu beitragen, die Verwaltungskapazitäten auszubauen und die Kosten der sozialen Anpassung zu begrenzen.
<G-vec00179-002-s128><build_up.ausbauen><en> Savvy companies leverage the power of social channels to generate leads, provide customer service, build awareness, and more.
<G-vec00179-002-s128><build_up.ausbauen><de> Schlaue Unternehmen nutzen den Einfluss von Social Media Kanälen um Leads zu generieren, um einen Kundenservice zu gewährleisten, um die Bekanntheit auszubauen etc.
<G-vec00179-002-s129><build_up.ausbauen><en> Die Mobiliar saw documents serving different insurance use cases as an opportunity for the company to communicate and build strong relationships with its customers in different languages and countries, especially across Europe.
<G-vec00179-002-s129><build_up.ausbauen><de> Die Mobiliar sieht Dokumente, die in verschiedenen Versicherungs-kontexten benötigt werden, als eine Chance für das Unternehmen, mit Kunden in verschiedenen Sprachen zu kommunizieren und die Beziehungen über mehrere Länder hinweg und insbesondere in Europa auszubauen.
<G-vec00179-002-s130><build_up.ausbauen><en> In Poland, where only online advertising has been marketed to date, the Goldbach Group is planning to continuously build up the services for selling digital TV.
<G-vec00179-002-s130><build_up.ausbauen><de> In Polen, wo bisher ausschließlich Online-Werbung vermarktet wurde, plant die Goldbach Group, das Angebot für den Verkauf von digitalem TV kontinuierlich auszubauen.
<G-vec00179-002-s131><build_up.ausbauen><en> During our recent phase of intensive investment, we also managed in parallel to achieve strong organic growth in our three chemical divisions, to consolidate and build on our competitive position, and to enhance our profitability.
<G-vec00179-002-s131><build_up.ausbauen><de> Parallel zu dieser intensiven Investitionsphase ist es gelungen, in den drei Chemiebereichen organisch stark zu wachsen, die Wettbewerbspositionen zu festigen und auszubauen sowie die Ertragskraft zu stärken.
<G-vec00179-002-s132><build_up.ausbauen><en> To continue to build on our success, we value our employees’ unique perspectives and ideas.
<G-vec00179-002-s132><build_up.ausbauen><de> Um unseren Erfolg weiter auszubauen, sind wir auf die besonderen Standpunkte und Ideen unserer Mitarbeiter angewiesen.
<G-vec00179-002-s285><build_up.entwickeln><en> If you're looking for other utilities to help you build out your growing set of tools for WordPress or for code to study and become more well-versed in WordPress, don't forget to see what we have available in Envato Market.
<G-vec00179-002-s285><build_up.entwickeln><de> Wenn Sie nach anderen Dienstprogrammen suchen, die Sie beim Entwickeln Ihres wachsenden Satzes von Werkzeugen für WordPress oder nach Code unterstützen, der sich mit WordPress auskennt, sollten Sie nicht vergessen, was wir in Envato Market anbieten.
<G-vec00179-002-s286><build_up.entwickeln><en> “As more developers draw from existing code libraries to build new tools, tracking changes in dependencies like security vulnerabilities has become more difficult,” blogged GitHub.
<G-vec00179-002-s286><build_up.entwickeln><de> “Das immer mehr Entwickler vorhandenen Code übernehmen, um neue Tools zu entwickeln, macht die Verfolgung von Abhängigkeiten wie Sicherheitslücken immer schwieriger”, heißt es in einem Blogeintrag von GitHub.
<G-vec00179-002-s287><build_up.entwickeln><en> To build an optimal device, the company needed to measure — in real time — data such as the currents and voltages of the electromagnetic “cage” used to control the plasma as it floats past the accelerator walls.
<G-vec00179-002-s287><build_up.entwickeln><de> Um das optimale Design zu entwickeln, musste das Unternehmen Daten wie die Ströme und Spannungen des elektromagnetischen "Käfigs" messen, der das Plasma auf seinem Fluss entlang der Beschleunigerwände einschließt – und zwar in Echtzeit.
<G-vec00179-002-s288><build_up.entwickeln><en> We can help you select the right technology and build a system which is compliant and stays within your budget and timeline.
<G-vec00179-002-s288><build_up.entwickeln><de> Wir können Ihnen helfen, die richtige Technologie auszuwählen und ein System zu entwickeln, das mit den Vorschriften konform ist und Ihrem Budget und Zeitplan entspricht.
<G-vec00179-002-s289><build_up.entwickeln><en> Watch this Webinar from Visual Studio Magazine to learn how to build software installations according to agile best practices.
<G-vec00179-002-s289><build_up.entwickeln><de> Webinar Sehen Sie sich dieses Webinar des Visual Studio Magazine an, und erfahren Sie, wie Sie Softwareinstallationen gemäß agilen Best Practices entwickeln.
<G-vec00179-002-s290><build_up.entwickeln><en> Find SAP partners and independent software vendors that can build SAP-certified, prepackaged solutions to help extend the functionality of SAP S/4HANA to meet your unique needs.
<G-vec00179-002-s290><build_up.entwickeln><de> Arbeiten Sie mit SAP-Partnern und unabhängigen Softwareanbietern zusammen, die SAP-zertifizierte, vorkonfigurierte Lösungen entwickeln und die Funktionalität von SAP S/4HANA Cloud entsprechend Ihren spezifischen Anforderungen erweitern.
<G-vec00179-002-s291><build_up.entwickeln><en> We listen to you and take the time to understand what type of logistics your customers need and then build a solution to suit.
<G-vec00179-002-s291><build_up.entwickeln><de> Wir hören Ihnen zu und nehmen uns Zeit, um zu verstehen, welche Art Logistik Ihre Kunden benötigen, bevor wir eine passende Lösung für Sie entwickeln.
<G-vec00179-002-s292><build_up.entwickeln><en> We build all features in-house for a seamless experience.
<G-vec00179-002-s292><build_up.entwickeln><de> Für ein nahtloses Erlebnis entwickeln wir alle Funktionen intern.
<G-vec00179-002-s293><build_up.entwickeln><en> Shift your attitude and treat them as opportunities to build a stronger product.
<G-vec00179-002-s293><build_up.entwickeln><de> Ändere deine Einstellung und behandle sie als Chance, ein stärkeres Produkt zu entwickeln.
<G-vec00179-002-s294><build_up.entwickeln><en> Even though it is a light steroid, oxandrolone aids to build really first class muscular tissue mass, without water retention.
<G-vec00179-002-s294><build_up.entwickeln><de> Obwohl es ein Licht Steroid ist, hilft oxandrolone sehr hochwertige Muskelmasse zu entwickeln, ohne Wassereinlagerungen.
<G-vec00179-002-s295><build_up.entwickeln><en> Build or scale with PowerEdge servers pre-configured for your workloads.
<G-vec00179-002-s295><build_up.entwickeln><de> Entwickeln oder skalieren Sie Ihre eigene Lösung mit für Ihre Workloads vorkonfigurierten PowerEdge-Servern.
<G-vec00179-002-s296><build_up.entwickeln><en> Extend, integrate, or build new standalone, next-generation applications with the SAP Cloud Platform.
<G-vec00179-002-s296><build_up.entwickeln><de> Mit der SAP Cloud Platform entwickeln Sie schnell und einfach neue, intuitiv bedienbare Anwendungen.
<G-vec00179-002-s297><build_up.entwickeln><en> Build a more comprehensive view of customers by integrating and analyzing data of all types, sizes, and velocities.
<G-vec00179-002-s297><build_up.entwickeln><de> Entwickeln Sie eine umfassendere Sicht des Kunden, indem Sie Daten aller Arten, Größen und Geschwindigkeiten integrieren und analysieren.
<G-vec00179-002-s298><build_up.entwickeln><en> To realize this idea, our client needed a brand-new software development kit (SDK) that would allow OEMs to build next-generation embedded navigation solutions.
<G-vec00179-002-s298><build_up.entwickeln><de> Um diese Idee zu verwirklichen, benötigte unser Kunde ein brandneues Softwareentwicklungskit (SDK), das es Erstausrüstern ermöglichen würde, eingebettete Navigationslösungen der nächsten Generation zu entwickeln.
<G-vec00179-002-s299><build_up.entwickeln><en> We help organisations understand the potential and build successful business models.
<G-vec00179-002-s299><build_up.entwickeln><de> Wir helfen Unternehmen, dieses Potenzial zu verstehen und erfolgreiche Geschäftsmodelle zu entwickeln.
<G-vec00179-002-s300><build_up.entwickeln><en> Together with financing from Avalon, Prospect and Versant, this deal should enable Amira to rapidly build itself into a strong R&D based company in this important therapeutic area.”
<G-vec00179-002-s300><build_up.entwickeln><de> Mit der gemeinsamen Finanzierung durch Avalon, Prospect und Versant sind für Amira die Voraussetzungen gegeben, um sich rasch zu einem starken, forschungsorientierten Unternehmen auf diesem wichtigen therapeutischen Gebiet zu entwickeln.
<G-vec00179-002-s301><build_up.entwickeln><en> Orders API – Build custom integrations with the third-party systems that you use to handle order fulfillment and production logistics.
<G-vec00179-002-s301><build_up.entwickeln><de> Bestellungs-API – Entwickeln Sie eigene Integrationen in Drittsysteme und nutzen Sie diese zur Auftragsabwicklung oder Unterstützung Ihrer Produktionslogistik.
<G-vec00179-002-s302><build_up.entwickeln><en> With RWD, businesses build just one site to serve fixed line users as well as mobile users.
<G-vec00179-002-s302><build_up.entwickeln><de> Beim RWD entwickeln Unternehmen nur eine Website sowohl für Festnetznutzer als auch für mobile Nutzer.
<G-vec00179-002-s303><build_up.entwickeln><en> Not-for-profit. Mozilla puts people over profit in everything we say, build and do.
<G-vec00179-002-s303><build_up.entwickeln><de> Für Mozilla steht der Mensch bei allem, was wir sagen, entwickeln und tun über dem Profit.
<G-vec00179-002-s437><build_up.gestalten><en> We'll help you build the bedroom of your dreams.
<G-vec00179-002-s437><build_up.gestalten><de> Wir helfen dir, dein Traumschlafzimmer zu gestalten.
<G-vec00179-002-s438><build_up.gestalten><en> Fulfill your dreams and let us build a successful future together.
<G-vec00179-002-s438><build_up.gestalten><de> Erfüllen Sie Lebensträume und gestalten Sie mit uns gemeinsam eine erfolgreiche Zukunft.
<G-vec00179-002-s439><build_up.gestalten><en> Let's build the future together.
<G-vec00179-002-s439><build_up.gestalten><de> Gemeinsam die Zukunft gestalten.
<G-vec00179-002-s440><build_up.gestalten><en> We place great hopes in the openness andreadiness for mutual understanding of the youth, which, in future, will have to build up the relationship between Jews and Christians.
<G-vec00179-002-s440><build_up.gestalten><de> Große Hoffnung setzen wir dabei auf die Offenheit und Verständigungsbereitschaft der Jugend, die künftig das Verhältnis zwischen Juden und Christen zu gestalten haben wird.
<G-vec00179-002-s441><build_up.gestalten><en> Marketing Help build the future by assessing customer needs and gathering insights for product development.
<G-vec00179-002-s441><build_up.gestalten><de> Marketing Helfen Sie, die Zukunft zu gestalten, indem Sie Kundenbedürfnisse einschätzen und nützliche Erkenntnisse für die Produktentwicklung sammeln.
<G-vec00179-002-s442><build_up.gestalten><en> Luckily the vast majority of our survey respondents are ahead of the game, of those surveyed, 81% of IT firms report they are using a business information management platform to tie these systems together and build efficient processes.
<G-vec00179-002-s442><build_up.gestalten><de> Laut der Autotask-Studie ist die Mehrheit der Befragten hier gut beraten: 81 % der IT-Firmen berichten, dass sie eine Business-Informationsmanagement-Plattform verwenden, um die verschiedenen Systeme miteinander zu verknüpfen und so effiziente Prozesse zu gestalten.
<G-vec00179-002-s443><build_up.gestalten><en> Arlo partners with an ever growing number of IoT and automation platforms to help you to build a safer and smarter business.
<G-vec00179-002-s443><build_up.gestalten><de> Arlo arbeitet mit einer wachsenden Anzahl an Plattformen für das intelligente Zuhause zusammen, um Sie dabei zu unterstützen, Ihr Zuhause intelligenter und sicherer zu gestalten.
<G-vec00179-002-s444><build_up.gestalten><en> In these times which are difficult, even though there never has been an easy time, we must especially be careful that we build our lives according to God and His light.
<G-vec00179-002-s444><build_up.gestalten><de> In dieser Zeit, die schwer ist und in der es keine leichte Zeit gab, müssen wir besonders aufpassen, dass wir unser Leben in Gottes Licht gestalten.
<G-vec00179-002-s445><build_up.gestalten><en> We build your future.
<G-vec00179-002-s445><build_up.gestalten><de> Wir gestalten Ihre Zukunft.
<G-vec00179-002-s446><build_up.gestalten><en> Most prefer to start with a concept for larger devices (desktop / tablet landscape) then scale down. However, you start with a concept for smaller devices, it is easier to par down to the essentials and build a crisp, concise story.
<G-vec00179-002-s446><build_up.gestalten><de> Den meisten fällt es einfacher mit einem Konzept für größere Devices (Desktop / Tablet Landscape) zu starten und dieses dann für kleinere anzupassen; wenn man aber mit den kleineren Mobile Geräten startet, ist es einfacher, sich auf das Wesentliche zu reduzieren und die Story knackig und prägnant zu gestalten.
<G-vec00179-002-s447><build_up.gestalten><en> Share From cowboy boots to peek-a-boo pumps, we’ve found five shoes to build your evening look around this festive season..
<G-vec00179-002-s447><build_up.gestalten><de> Von Cowboystiefeln bis hin zu Peek-a-Boos haben wir fünf Schuhe gefunden, mit denen Sie Ihren Abendlook zu dieser festlichen Jahreszeit gestalten können.
<G-vec00179-002-s448><build_up.gestalten><en> Skanska AB As a pioneer in the insulation industry Paroc aims to fulfill the changing demands today’s world sets for the environments we build for ourselves.
<G-vec00179-002-s448><build_up.gestalten><de> PAROC hat sich in der Dämmstoffindustrie zum Ziel gesetzt, die heutigen sich ändernden globalen Anforderungen an die Umwelt, die wir für uns gestalten, zu erfüllen.
<G-vec00179-002-s449><build_up.gestalten><en> In the afternoon, the young actors will build sets, create costumes, and design the makeup of the characters, in order to have the complete theatre experience.
<G-vec00179-002-s449><build_up.gestalten><de> Am Nachmittag gestalten die jungen Darsteller das Bühnenbild, die Kostüme und das Make-up der Charaktere und machen so eine ganzheitliche Theatererfahrung.
<G-vec00179-002-s450><build_up.gestalten><en> Expected outcome: To create a network of people across the continent who are working to build a genuinely multicultural Europe.
<G-vec00179-002-s450><build_up.gestalten><de> Angestrebte Ergebnisse: Ein Netzwerk zwischen Menschen des gesamten Kontinents schaffen, die ein wirklich multikulturelles Europa gestalten.
<G-vec00179-002-s452><build_up.gestalten><en> Qualyshelps organizations streamline and consolidate their security and compliance solutions in a single platform and build security into digital transformation initiatives for greater agility, better business outcomes and substantial cost savings.
<G-vec00179-002-s452><build_up.gestalten><de> Qualys hilft Unternehmen, ihre Sicherheits- und Compliance-Lösungen zu optimieren und in einer einzigen Plattform zu konsolidieren, Initiativen zur digitalen Transformation grundlegend sicher zu gestalten und so mehr Agilität, bessere Geschäftsergebnisse und bedeutende Kosteneinsparungen zu erzielen.
<G-vec00179-002-s453><build_up.gestalten><en> The Huawei Watch lets you build a bespoke timepiece that expresses your individual look.
<G-vec00179-002-s453><build_up.gestalten><de> Mit der Huawei Watch können Sie sich eine maßgeschneiderte Uhr gestalten, mit der Sie ihren individuellen Look ausdrücken.
<G-vec00179-002-s454><build_up.gestalten><en> The WWF is fighting to stop the ongoing destruction of the environment and aims to build a future in which mankind and nature live in harmony.
<G-vec00179-002-s454><build_up.gestalten><de> Ziel des WWF ist es, die weltweite Umweltzerstörung zu stoppen und eine Zukunft zu gestalten, in der Mensch und Natur im Einklang miteinander leben.
<G-vec00179-002-s455><build_up.gestalten><en> Social dialogue with trade unions, workers and experts is necessary to build a future where the workers can ride the opportunity of the new technology instead of be buried by it, and can live the advantages without fear.
<G-vec00179-002-s455><build_up.gestalten><de> Der soziale Dialog mit Gewerkschaften, Arbeitnehmern und Sachverständigen ist notwendig, um eine Zukunft zu gestalten, in der die Arbeitnehmer die Gelegenheit der neuen Technologie nutzen können, anstatt von ihr zugrunde gerichtet zu werden, und die Vorteile ohne Angst wahrnehmen können.
