<G-vec00552-002-s019><clean.bereinigen><en> This helps to clean up the edges around the Keyed image.
<G-vec00552-002-s019><clean.bereinigen><de> Dies hilft, die Ränder um das kodierte Bild zu bereinigen.
<G-vec00552-002-s020><clean.bereinigen><en> It has the ability to clean your junk file.
<G-vec00552-002-s020><clean.bereinigen><de> Es hat die Fähigkeit, Ihre Junk-Datei zu bereinigen.
<G-vec00552-002-s021><clean.bereinigen><en> Correct, clean up and enrich your product data to create tailored, optimized data feeds.
<G-vec00552-002-s021><clean.bereinigen><de> Verbessern, bereinigen und reichern Sie Ihre Produktdaten an, um perfekt optimierte Daten-Feeds zu erstellen.
<G-vec00552-002-s022><clean.bereinigen><en> It's your responsibility to clean your email lists outside of SurveyMonkey before using them on the site.
<G-vec00552-002-s022><clean.bereinigen><de> Sie sind dafür verantwortlich, Ihre E-Mail-Listen außerhalb von SurveyMonkey zu bereinigen, bevor Sie sie auf der Website verwenden.
<G-vec00552-002-s023><clean.bereinigen><en> HTML based documentation formats (CHM, HTML, ePub, Kindle and Qt Help) can now optionally clean the output directory before generating the documentation, making it easier to create perfectly clean documentation without any deleted or outdated content: you can choose between “Never clean”, “Always clean” or “Ask before cleaning” from the build settings to make sure that it fits your specific workflow.
<G-vec00552-002-s023><clean.bereinigen><de> Die HTML-basierten Dokumentationsformate (CHM, HTML, ePub, Kindle und Qt-Hilfe) können jetzt das Ausgabeverzeichnis optional vor der Generierung der Dokumentation bereinigen, sodass Sie auf einfache Weise eine einwandfrei saubere Dokumentation ohne gelöschte oder veraltete Inhalte erstellen können: Sie können unter den Build-Einstellungen zwischen “Nie bereinigen”, “Immer bereinigen” oder “Vor dem Bereinigen fragen” auswählen und so die für Ihren spezifischen Arbeitsablauf passende Einstellung auswählen.
<G-vec00552-002-s026><clean.bereinigen><en> Clean up the neighborhood by destroying the goos with Koala Koala and his arsenal of magic potions.
<G-vec00552-002-s026><clean.bereinigen><de> Bereinigen Sie die Nachbarschaft durch die Zerstörung der Goos mit Koala Koala und seinem Arsenal von Zaubertränken.
<G-vec00552-002-s027><clean.bereinigen><en> Jean Marie clean up the rooms every day.
<G-vec00552-002-s027><clean.bereinigen><de> Jean Marie bereinigen die Zimmer jeden Tag.
<G-vec00552-002-s028><clean.bereinigen><en> Over 30 one-touch tools—clean your drive, secure private files, take screenshots, or download a video all with just a single click.
<G-vec00552-002-s028><clean.bereinigen><de> Mehr als 30 One-Touch-Tools: Laufwerke bereinigen, private Dateien sichern, Screenshots erstellen oder Videos herunterladen – alles mit nur einem Klick.
<G-vec00552-002-s029><clean.bereinigen><en> 3×02 Phoenix – Clark has to clean up his mess, including the providing of another blood sample.
<G-vec00552-002-s029><clean.bereinigen><de> 3×02 Phoenix – Clark muss das Chaos bereinigen, welches er hinterlassen hat, was eine neue Blutprobe einschließt.
<G-vec00552-002-s030><clean.bereinigen><en> And this also happens on iPhone and iPad, but you can get hold of an application that helps you to clean iOS and improve its performance.
<G-vec00552-002-s030><clean.bereinigen><de> Und das passiert auch auf iPhone und iPad, aber Sie können sich aber eine Anwendung holen, die Ihnen hilft, Ihr iOS zu bereinigen und die Leistung zu verbessern.
<G-vec00552-002-s031><clean.bereinigen><en> This is a requirement because customers typically clean up and architect their SharePoint solutions again as part of the upgrade, which we recommend.
<G-vec00552-002-s031><clean.bereinigen><de> Dies ist erforderlich, da Kunden im Rahmen des Upgrades ihre SharePoint-Lösungen meist bereinigen und neu gestalten, was wir empfehlen.
<G-vec00552-002-s032><clean.bereinigen><en> With Autodesk ReCap you can also access a wide range of tools and, for instance, clean the unwanted objects to work more specifically on a precise object!
<G-vec00552-002-s032><clean.bereinigen><de> Mit Autodesk ReCap haben Sie Zugriff auf eine Vielzahl von Werkzeugen und können beispielsweise unerwünschte Objekte bereinigen, um ein präzises 3D-Modell zu erhalten.
<G-vec00552-002-s033><clean.bereinigen><en> Clean up all of your files that include your account passwords, messages and photos.
<G-vec00552-002-s033><clean.bereinigen><de> Bereinigen Sie alle Dateien, die Ihre Passwörter, Nachrichten und Fotos enthalten.
<G-vec00552-002-s034><clean.bereinigen><en> Select the type of contacts you want to clean out.
<G-vec00552-002-s034><clean.bereinigen><de> Wählen Sie auf der nächsten Seite diejenigen Kontakte, die Sie bereinigen möchten.
<G-vec00552-002-s035><clean.bereinigen><en> You can clean up these lists.
<G-vec00552-002-s035><clean.bereinigen><de> Sie können diese Listen bereinigen.
<G-vec00552-002-s036><clean.bereinigen><en> The program integrates into most modern browsers, can clean their visiting history, temporary files and data, includes a window with detailed connection statistics, can record and export logs in txt format.
<G-vec00552-002-s036><clean.bereinigen><de> Das Programm lässt sich in die meisten modernen Browser integrieren, kann den Besuchsverlauf bereinigen, temporäre Dateien und Daten bereinigen, enthält ein Fenster mit detaillierten Verbindungsstatistiken, kann Protokolle im TXT-Format aufzeichnen und exportieren.
<G-vec00552-002-s037><clean.bereinigen><en> Scan and clean your computer from PUPs periodically with our the Free Emsisoft Emergency Kit.
<G-vec00552-002-s037><clean.bereinigen><de> Prüfen Sie Ihren Computer auf PUPs und bereinigen Sie ihn regelmäßig, zum Beispiel auch mit dem kostenlosen Emsisoft Emergency Kit.
<G-vec00552-002-s228><clean.putzen><en> She continued to frequent the church with three of her companions, clean it and decorate the altar.
<G-vec00552-002-s228><clean.putzen><de> Sie ging also weiterhin mit ihren drei Freundinnen zur Pfarrkirche, um sie zu putzen und den Altar zu schmücken.
<G-vec00552-002-s229><clean.putzen><en> Just as our tenants should have no problems with pets - even if we can before we left to clean the house, of course, you can not eliminate all traces of the animals living here.
<G-vec00552-002-s229><clean.putzen><de> Genauso sollten unsere Mieter keine Probleme mit Haustieren haben - auch wenn wir natürlich vor unserer Abreise das Haus putzen kann man nicht alle Spuren der hier lebenden Tiere beseitigen.
<G-vec00552-002-s230><clean.putzen><en> Clean the spring onion and cut it into fine rings.
<G-vec00552-002-s230><clean.putzen><de> Die Frühlingszwiebel putzen und in feine Ringe schneiden.
<G-vec00552-002-s231><clean.putzen><en> The brush can clean your teeth, whiten your teeth, massage your gums, prevent tooth decay, remove plaque and coffee stain.
<G-vec00552-002-s231><clean.putzen><de> Die Bürste kann Ihre Zähne putzen, Ihre Zähne bleichen, Ihr Zahnfleisch massieren, Karies vorbeugen, Plaque und Kaffeeflecken entfernen.
<G-vec00552-002-s232><clean.putzen><en> Clean, wash and cut spring onions into rings.
<G-vec00552-002-s232><clean.putzen><de> Lauchzwiebeln putzen, waschen und in Ringe schneiden.
<G-vec00552-002-s233><clean.putzen><en> If you attend regular appointments for dental care and prophylaxis at your dentist and also clean your teeth regularly at home, you are unlikely to be affected.
<G-vec00552-002-s233><clean.putzen><de> Wenn Sie regelmäßig die Nachsorge- und Prophylaxetermine wahrnehmen und auch zu Hause regelmäßig die Zähne putzen, sollten Sie diesbezüglich auf der sicheren Seite sein.
<G-vec00552-002-s234><clean.putzen><en> Well, she already has a lot of work with four lawyers and an apprentice. And then when she comes home she has to clean the house that we all make dirty.
<G-vec00552-002-s234><clean.putzen><de> Nun, als hätte sie mit den anderen vier Anwälten und dem Lehrling nicht schon genug zu tun...Und wenn sie dann heimkommt, muss sie noch den Dreck, den wir alle machen, putzen.
<G-vec00552-002-s235><clean.putzen><en> After Christian had cut open the diesel tank 2 years ago in the boatyard (in order to clean out the goo that had accumulated over 25 years) he resealed the tank with red silicone which now started to dissolve.
<G-vec00552-002-s235><clean.putzen><de> Nachdem Christian den Tank vor 2 Jahren in der Werft aufgeschnitten hatte (um den Dreck von 25 Jahren raus zu putzen), versiegelte er den Tank mit rotem Silikon, das jetzt begann sich aufzulösen.
<G-vec00552-002-s236><clean.putzen><en> Meanwhile, wash the rhubarb, clean and remove the threads.
<G-vec00552-002-s236><clean.putzen><de> Inzwischen den Rhabarber waschen, putzen, entfädeln.
<G-vec00552-002-s237><clean.putzen><en> AC: I ask people, “Would you clean a rental car before you return it?” Most people say they wouldn’t because it’s not theirs and they don’t really care about it.
<G-vec00552-002-s237><clean.putzen><de> AC: Ich stelle Menschen häufig die Frage: „Würden Sie einen Mietwagen putzen, bevor Sie ihn zurückgeben?“ Die meisten Menschen verneinen dies, weil das Auto nicht ihnen gehört und sie sich nichts daraus machen.
<G-vec00552-002-s238><clean.putzen><en> The young girl seems to be a faithful soul, only she needs to learn to clean better.
<G-vec00552-002-s238><clean.putzen><de> Das junge Mädchen ist scheinbar eine treue Seele nur muss sie noch ordentlicher putzen lernen.
<G-vec00552-002-s239><clean.putzen><en> Clean the peppers, potatoes and root and cut into small cubes.
<G-vec00552-002-s239><clean.putzen><de> Paprikaschoten, Kartoffeln und Wurzel putzen und in kleine Würfel schneiden.
<G-vec00552-002-s240><clean.putzen><en> Again, you have free choice to "clean the window" of your soul to see whatever part you need to.
<G-vec00552-002-s240><clean.putzen><de> Nochmals, ihr habt freie Wahl „das Fenster eurer Seele zu putzen“ um jedweden Teil zu sehen den {zu sehen} ihr nötig habt.
<G-vec00552-002-s241><clean.putzen><en> Being an oil-based paint, and very thick at that, it is a hassle to clean up.
<G-vec00552-002-s241><clean.putzen><de> Da es eine Farbe auf Ölbasis ist, und noch dazu eine sehr zähe, ist das Putzen äußerst mühsam.
<G-vec00552-002-s242><clean.putzen><en> On the issue of cleanliness, we do our best to clean the apartment thoroughly before a guest's arrival but it can be difficult to thoroughly clean everything when it has been a month or more since the last turnover.
<G-vec00552-002-s242><clean.putzen><de> Was die Sauberkeit betrifft, so tun wir unser Bestes, die Wohnung vor der Ankunft eines Gastes gründlich zu putzen, aber das kann schwierig werden, wenn der letzte Mieterwechsel bereits einen Monat, oder länger zurückliegt.
<G-vec00552-002-s243><clean.putzen><en> Richie tries to explain himself intimidated, but the young dominant lady of the house orders what to him only in pungent tone as he has to clean.
<G-vec00552-002-s243><clean.putzen><de> Richie versucht sich eingeschüchtert zu erklären, doch die junge dominante Hausherrin befiehlt ihm nur in strengem Ton was er wie zu putzen hat.
<G-vec00552-002-s244><clean.putzen><en> Let yourself be tied up, clean and like to go for a walk.
<G-vec00552-002-s244><clean.putzen><de> Lasst sich brav anbinden, putzen und geht gern spazieren.
<G-vec00552-002-s245><clean.putzen><en> Besides, writing in a café keeps you safe from the desire to clean your apartment instead of working on your novel.
<G-vec00552-002-s245><clean.putzen><de> Außerdem garantiert die Schreibarbeit im Kaffeehaus, dass einen nicht das plötzliche und dringende Bedürfnis überfällt, die Wohnung zu putzen, anstatt am Roman zu arbeiten.
<G-vec00552-002-s246><clean.putzen><en> Don't forget to clean the tables and pick up tips.
<G-vec00552-002-s246><clean.putzen><de> Vergiss nicht, nach jedem Kunden den Tisch zu putzen und Trinkgeld einzukassieren.
<G-vec00552-002-s114><clean.reinigen><en> Your skin feels clean, nourished and soft.
<G-vec00552-002-s114><clean.reinigen><de> Ihre Haut fühlt sich gereinigt, genährt und sanft an.
<G-vec00552-002-s115><clean.reinigen><en> The floor must be clean and dry prior to application. Shake the care oil well before use.
<G-vec00552-002-s115><clean.reinigen><de> Vor der Anwendung muss der Boden trocken gereinigt werden (Staubsauger oder Staubtuch).
<G-vec00552-002-s116><clean.reinigen><en> How to clean an airbrush in just 10 seconds!
<G-vec00552-002-s116><clean.reinigen><de> Wie eine Airbrush in 10 Sekunden gereinigt wird.
<G-vec00552-002-s117><clean.reinigen><en> 9 But the voice answered a second time from heaven, ‘What God has made clean, do not call common.’
<G-vec00552-002-s117><clean.reinigen><de> 9 Aber die Stimme antwortete mir zum andernmal vom Himmel: Was Gott gereinigt hat, das mache du nicht gemein.
<G-vec00552-002-s118><clean.reinigen><en> Suede leather or nubuck: to maintain the velvety look of the leather, clean it gently with a soft brush.
<G-vec00552-002-s118><clean.reinigen><de> Velours- oder Nubuk-Leder, das vorsichtig mit einer weichen Bürste gereinigt wird, um dessen samtige Optik zu bewahren.
<G-vec00552-002-s119><clean.reinigen><en> You should also monitor/clean his eyes and ears on a regular basis.
<G-vec00552-002-s119><clean.reinigen><de> Außerdem müssen seine Augen und Ohren regelmäßig überprüft/gereinigt werden.
<G-vec00552-002-s120><clean.reinigen><en> Once one side of the blade is done, clean the knife sharpener and do the same on the other side.
<G-vec00552-002-s120><clean.reinigen><de> Wenn eine Seite der Klinge geschliffen ist, wird der Wetzstahl gereinigt und es wird mit der anderen Seite begonnen.
<G-vec00552-002-s121><clean.reinigen><en> The shower ring can be moved up and down to easily clean the whole body.
<G-vec00552-002-s121><clean.reinigen><de> Der Duschring lässt sich auf und ab bewegen, wodurch der ganze Körper auf einfache Weise gereinigt wird.
<G-vec00552-002-s122><clean.reinigen><en> Property delivered clean and equipped with sheets and bath towels with weekly change.
<G-vec00552-002-s122><clean.reinigen><de> Haus komplett gereinigt und mit Bettwäsche und Badetücher mit wöchentlichem Wechsel versorgt.
<G-vec00552-002-s123><clean.reinigen><en> KJV_Cambridge(i) 41 And Jesus, moved with compassion, put forth his hand, and touched him, and saith unto him, I will; be thou clean.
<G-vec00552-002-s123><clean.reinigen><de> ELB1871(i) 41 Jesus aber, innerlich bewegt, streckte die Hand aus, rührte ihn an und spricht zu ihm: Ich will; sei gereinigt.
<G-vec00552-002-s124><clean.reinigen><en> To make sure the rooms are clean and tidy for the next guests, we charge an additional fee of €25.
<G-vec00552-002-s124><clean.reinigen><de> - Damit das Zimmer für andere Gäste besonders gut gereinigt werden kann, berechnen wir € 25,- extra.
<G-vec00552-002-s125><clean.reinigen><en> Wet & dry OneBlade is water resistant, so it's easy to clean: just rinse it under the tap.
<G-vec00552-002-s125><clean.reinigen><de> Nass/trocken OneBlade ist wasserdicht und kann somit ganz einfach gereinigt werden: Spülen Sie sie einfach unter fließendem Wasser ab.
<G-vec00552-002-s126><clean.reinigen><en> - Before applying the makeup base, the skin must be perfectly clean, toned and hydrated.
<G-vec00552-002-s126><clean.reinigen><de> - Vor dem Auftragen der Foundation muss die Haut perfekt gereinigt, gestrafft und mit Feuchtigkeit versorgt werden.
<G-vec00552-002-s127><clean.reinigen><en> The laboratory UVR unit will help you provide a tests with any type of petrochemical product to verify the possibility to clean it.
<G-vec00552-002-s127><clean.reinigen><de> Die Labor-UVR-Einheit wird Ihnen helfen, Tests mit jeder Art von petrochemischen Produkten durchzuführen, um zu bestätigen, dass es gereinigt werden kann.
<G-vec00552-002-s128><clean.reinigen><en> The special weave structure makes it easy to clean the blanket from sand.
<G-vec00552-002-s128><clean.reinigen><de> Dank der speziellen Stoffstruktur, kann die Decke einfach von Sand gereinigt werden.
<G-vec00552-002-s129><clean.reinigen><en> Therefore, it is important to thoroughly and optimally clean the feeding equipment.
<G-vec00552-002-s129><clean.reinigen><de> Da ist es wichtig, dass auch die Fütterungstechnik optimal gereinigt wird.
<G-vec00552-002-s130><clean.reinigen><en> Treatment can require relatively long periods of administration (minutes or hours), and it is usually necessary to prepare the device prior to treatment and clean it afterwards.
<G-vec00552-002-s130><clean.reinigen><de> Die Behandlung kann relativ langwierige Verwaltungszeiträume (Minuten oder Stunden) mit sich bringen und das Gerät muss normalerweise vor der Behandlung vorbereitet und danach gereinigt werden.
<G-vec00552-002-s131><clean.reinigen><en> The best way to clean our reversed rubbers SPECIAL DEFENCE, DOMINATION, DOMINATION SPEED and GOLIATH SPEED is to use a soft sponge or piece of cloth with clean water.
<G-vec00552-002-s131><clean.reinigen><de> Unsere Noppen-innen Beläge SPECIAL DEFENCE, DOMINATION, DOMINATION SPEED und GOLIATH SPEED werden am besten mit sauberem Wasser und einem weichen Schwamm oder Tuch gereinigt.
<G-vec00552-002-s132><clean.reinigen><en> Regarding air, oxide-based gas sensors are being developed to monitor the air quality, especially with regard to formaldehyde, and photocatalytic coatings are applied in order to clean the air using solar energy.
<G-vec00552-002-s132><clean.reinigen><de> Für die Luftsteuerung werden derzeit oxidbasierte Gassensoren zur Überwachung der Luftqualität entwickelt, insbesondere hinsichtlich Formaldehyd, und mithilfe photokatalytischer Beschichtungen soll die Luft mit Solarenergie gereinigt werden.
<G-vec00552-002-s551><clean.säubern><en> One thought behind this is that it exposes the water to more surface area allowing naturally occurring bacteria to help clean the water.
<G-vec00552-002-s551><clean.säubern><de> Der Gedanke dahinter ist, dass das Wasser dadurch einer größeren Oberfläche ausgesetzt wird, wodurch die natürlichen Bakterien dabei helfen können, es zu säubern.
<G-vec00552-002-s552><clean.säubern><en> Use that to clean the rope and then rinse with another damp cloth with water only.
<G-vec00552-002-s552><clean.säubern><de> Mit diesem Tuch die schmutzigen Bänder säubern und mit einem anderen, nur mit Wasser befeuchteten Tuch, abwischen.
<G-vec00552-002-s553><clean.säubern><en> Disinfect and clean the balloon regularly.
<G-vec00552-002-s553><clean.säubern><de> Desinfizieren Sie und säubern Sie den Ballon regelmäßig.
<G-vec00552-002-s554><clean.säubern><en> Clean the cod and cut into small cubes, turn in a bowl with lime juice, salt, pepper and chopped coriander.
<G-vec00552-002-s554><clean.säubern><de> Säubern Sie den Kabeljau und schneiden ihn in kleine Würfel, dann in einer Schüssel mit Limettensaft, Salz, Pfeffer und gehacktem Koriander wenden.
<G-vec00552-002-s555><clean.säubern><en> According to his lawyer, when he "did not clean up the excrement, a large IRF team of 10 guards was ordered to his cell and beat him severely.
<G-vec00552-002-s555><clean.säubern><de> Als er sich weigerte, diese zu säubern, wurde seinem Anwalt zufolge "ein 10-köpfiges IRF-Team zu seiner Zelle beordert und verprügelte ihn massiv.
<G-vec00552-002-s556><clean.säubern><en> The selection of food was poor, the orange and apple juices didn't taste good, and the waiters used too much time to clean the tables.
<G-vec00552-002-s556><clean.säubern><de> Die Auswahl an Essen war schlecht, die Orangen- und Apfelsaft schmeckte nicht gut, und die Kellner haben viel Zeit die Tische zu säubern.
<G-vec00552-002-s557><clean.säubern><en> De Mercuur boasts a spacious fishing deck and large fishing tables, on which you can immediately clean your catch.
<G-vec00552-002-s557><clean.säubern><de> Das Deck der Mercuur bietet ausreichend Platz zum Angeln und Reinigungsstationen, an denen Sie Ihren Fang sofort säubern können.
<G-vec00552-002-s558><clean.säubern><en> To disinfect and clean wounds.
<G-vec00552-002-s558><clean.säubern><de> Um Wunden zu säubern und zu desinfizieren.
<G-vec00552-002-s559><clean.säubern><en> To enjoy your cufflinks for a lifetime, you have to clean and store them properly.
<G-vec00552-002-s559><clean.säubern><de> Um deine Manschettenknöpfe ein Leben lang genießen zu können, solltest du sie regelmäßig säubern und angemessen aufbewahren.
<G-vec00552-002-s560><clean.säubern><en> Easy to clean and reusable.
<G-vec00552-002-s560><clean.säubern><de> Einfach zu säubern und wiederverwendbar.
<G-vec00552-002-s561><clean.säubern><en> It is suggested to scan and clean your PC using AdwCleaner to eliminate malicious infection if any for better experience while surfing web.
<G-vec00552-002-s561><clean.säubern><de> Es wird vorgeschlagen, zu scannen und säubern Sie Ihren Computer mit AdwCleaner, um schädliche Infektionen für eine bessere Erfahrung zu beseitigen, während das Surfen im Web.
<G-vec00552-002-s562><clean.säubern><en> Around 800 Jews were kept in a barrack to clean the ghetto area.
<G-vec00552-002-s562><clean.säubern><de> Etwa 800 Juden wurden in Lodz zurück gehalten um das Ghetto zu säubern.
<G-vec00552-002-s563><clean.säubern><en> Always clean the accumulated dust and grease with a dry cloth to keep your SPC Stork clean.
<G-vec00552-002-s563><clean.säubern><de> Säubern Sie den Staub und das angesammelte Fett mit einem trockenen Tuch, damit Ihr SPC Stork stets frisch bleibt.
<G-vec00552-002-s564><clean.säubern><en> You have to clean her shoes with your weak tongue, lying on the dirty floor!
<G-vec00552-002-s564><clean.säubern><de> Auf dem dreckigen Boden liegend, hast du ihre Schuhe mit deiner kleinen schwächlichen Zunge zu säubern.
<G-vec00552-002-s565><clean.säubern><en> The advantage of this device lies in the combination of mechanical, chemical and thermal cleaning power: with the addition of a cleaning rod per pass clean rotating polishing needles the prosthesis.
<G-vec00552-002-s565><clean.säubern><de> Der Vorteil dieses Gerätes liegt in der Kombination von mechanischer, chemischer und thermischer Reinigungskraft: Unter der Zugabe eines Reinigungstabs pro Durchgang säubern rotierende Poliernadeln die Prothese.
<G-vec00552-002-s566><clean.säubern><en> Before I start colouring the image, I use the dodge and burn tool to clean the image further and get rid of extra colours using saturation.
<G-vec00552-002-s566><clean.säubern><de> Bevor ich anfange, das Bild einzufärben, benutze ich das Abwedler- und Brennwerkzeug, um das Bild weiter zu säubern und zusätzliche Farben durch Sättigung zu entfernen.
<G-vec00552-002-s567><clean.säubern><en> Click left to shoot and clean the table before your time is up.
<G-vec00552-002-s567><clean.säubern><de> Klicken Sie auf die Links um zu schießen und den Tisch zu säubern, bevor deine Zeit abgelaufen ist.
<G-vec00552-002-s568><clean.säubern><en> These planets then effectively spring clean their orbits, clearing them of gas and dust and herding the remaining material into well-defined bands.
<G-vec00552-002-s568><clean.säubern><de> Diese Planeten säubern dann sozusagen ihre Umlaufbahn, indem sie das dort befindliche Gas und den Staub vereinnahmen und das verbleibende Material in wohldefinierten Bändern ansammeln.
<G-vec00552-002-s569><clean.säubern><en> The design creates a space in which the user can concentrate on what he’s doing.” “It’s also worth noting the industrial nature of the design, the smooth, jointless surface, which is beautiful and easy to clean,” states Rianne Makkink, with Suvi Saloniemi adding: “In theory, this kitchen can be installed anywhere there’s a water connection, because it’s not mounted on the wall.
<G-vec00552-002-s569><clean.säubern><de> Der Entwurf schafft einen Ort, an dem man sich auf das, was man tut, konzentrieren kann.“ „Außerdem ist das industrielle Design hervorzuheben, die glatte, fugenlose Oberfläche, die schön und einfach zu säubern ist“, so Rianne Makkink, und Suvi Saloniemi ergänzt: „Diese Küche lässt sich theoretisch überall installieren, wo es einen Wasseranschluss gibt, da sie nicht an die Wand montiert ist.
