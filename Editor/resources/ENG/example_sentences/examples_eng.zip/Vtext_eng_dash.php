<G-vec00389-002-s153><dash.laufen><en> The boys dash off again into the garden.
<G-vec00389-002-s153><dash.laufen><de> Die Jungen laufen weiter in den Garten.
<G-vec00389-002-s154><dash.laufen><en> Dash past them and you will find the vibrant youth park, 3 *SCAPE.
<G-vec00389-002-s154><dash.laufen><de> Laufen Sie schnurstracks an ihnen vorbei bis zum *SCAPE Youth Park, 3 *SCAPE.
<G-vec00389-002-s155><dash.laufen><en> And we hardly have any troops left, they’ve all been deployed to far away from our country. Deliberately.) They dash to the city wall; the protective shield is put in place.
<G-vec00389-002-s155><dash.laufen><de> Und wir haben kaum noch Truppen übrig, Sie wurden Alle absichtlich weit weg von unserem Land stationiert) Sie laufen zur Stadtmauer; das schützende Schild ist aufgestellt.
<G-vec00389-002-s199><dash.springen><en> In slide mode, you must boldly dash from wall to wall as you slide down them and avoid obstacles.
<G-vec00389-002-s199><dash.springen><de> Beim Rutschen musst du mutig von Wand zu Wand springen, während du an ihnen hinunterrutscht und Hindernisse vermeidest.
<G-vec00389-002-s200><dash.springen><en> The teams will have the pleasure to dash on the track to try to offer the victory of their team.
<G-vec00389-002-s200><dash.springen><de> Die Teams können sich freuen auf die Piste zu springen, um zu versuchen, den Sieg zu bekommen.
<G-vec00389-002-s201><dash.springen><en> You’ll have to dash between four lanes like a pro to make it in this cool arcade game.
<G-vec00389-002-s201><dash.springen><de> Du musst wie ein Profi zwischen vier Bahnen springen, um in diesem coolen Arcade-Spiel weiter zu kommen.
<G-vec00389-002-s255><dash.stürzen><en> As your family arrives at the train station, your hand slips free of your Mom's and you dash over to the tracks.
<G-vec00389-002-s255><dash.stürzen><de> Während Ihre Familie zu der Zugstation kommt, stürzen Ihre Handbelege, die von Ihrer Mamma und von Ihnen frei sind, rüber zu den Schienen.
<G-vec00389-002-s256><dash.stürzen><en> Play as little kid as you dash, jump and spin your way across stunning HD environments.
<G-vec00389-002-s256><dash.stürzen><de> Spielen Sie als kleines Kind, wie Sie stürzen, zu springen und drehen Sie Ihren Weg durch atemberaubende HD-Umgebungen.
<G-vec00389-002-s257><dash.stürzen><en> TEXT 29: I see all people rushing full speed into Your mouths, as moths dash to destruction in a blazing fire.
<G-vec00389-002-s257><dash.stürzen><de> Ich sehe alle Menschen mit rasender Geschwindigkeit in Deine Münder stürzen, so wie Motten, die in ein loderndes Feuer stürzen, der Vernichtung entgegen.
<G-vec00389-002-s258><dash.stürzen><en> Try playing this game and dash yourself to match and crush people with matching identities.
<G-vec00389-002-s258><dash.stürzen><de> Versuchen Sie, dieses Spiel zu spielen und stürzen Sie sich zu entsprechen und zu vernichten Menschen mit passenden Identitäten.
