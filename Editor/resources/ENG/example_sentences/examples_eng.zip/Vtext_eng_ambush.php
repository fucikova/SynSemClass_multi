<G-vec00441-002-s037><ambush.angreifen><en> Notes Edit In the tunnels, Enclave soldiers will ambush the player character from apparently inaccessible catwalks.
<G-vec00441-002-s037><ambush.angreifen><de> In den Tunneln wird man von Soldaten der Enklave angegriffen, die auf scheinbar unerreichbaren Stegen laufen.
<G-vec00441-002-s044><ambush.attackieren><en> In order to catch its prey, the spider will typically anchor its hind legs to a stone or a plant, with its front legs resting on the surface of the water, ready to ambush.
<G-vec00441-002-s044><ambush.attackieren><de> Um ihre Beute zu fangen, verankert sich die Spinne mit ihren Hinterbeinen an einem Felsen oder einer Pflanze und platziert ihre Vorderbeine auf der Wasseroberfläche, bereit die Beute zu attackieren.
<G-vec00441-002-s099><ambush.lauern><en> 9 And the man of God sent to the king of Israel, saying: Beware that thou pass not to such a place: for the Syrians are there in ambush.
<G-vec00441-002-s099><ambush.lauern><de> 9Aber der Mann Gottes sandte zum König von Israel und ließ ihm sagen: Hüte dich, dass du nicht an diesem Ort vorüberziehst, denn die Aramäer lauern dort.
<G-vec00441-002-s115><ambush.überfallen><en> For example, some WWE Superstars might ask you to ambush a rival or go toe to toe with them in a promo.
<G-vec00441-002-s115><ambush.überfallen><de> Einige WWE Superstars könnten euch zum Beispiel darum bitten, einen Rivalen zu überfallen oder euch diesem in einer Promo zu stellen.
<G-vec00441-002-s116><ambush.überfallen><en> 3x Three masked robbers (25-40, Afghan speaking) ambush a beverage supplier in front of his apartment.
<G-vec00441-002-s116><ambush.überfallen><de> 3x Drei maskierte Räuber (25-40, afghanisch sprechend) überfallen einen Getränkelieferanten vor seiner Wohnung.
<G-vec00441-002-s117><ambush.überfallen><en> Suddenly they ambush passing cars and their occupants, watching out for calm places, where they sit down and try to place their achy bite.
<G-vec00441-002-s117><ambush.überfallen><de> Sie überfallen unversehens vorbeifahrende Fahrzeuge und deren Insassen, wo sie sich auf deren Körpern windstille Flecken suchen, um dann ihren schmerzhaften Stich anbringen zu können.
<G-vec00441-002-s118><ambush.überfallen><en> To put a stop to the invasion, your Swarmers must plan attacks carefully, emerging from vents and lockers to take the human prey by surprise, and ambush multiple enemies at once to remain undetected.
<G-vec00441-002-s118><ambush.überfallen><de> Um der Invasion Einhalt zu gebieten, müssen die Schwärmer sorgfältige Angriffe planen, die aus Lüftungsschlitzen und Schränken stattfinden – um die menschliche Beute zu überraschen und mehrere Feinde gleichzeitig zu überfallen und dabei gleichzeitig unentdeckt bleiben.
<G-vec00441-002-s119><ambush.überfallen><en> After completing Broken Steel, raiders outside Tenpenny Tower will try to ambush Brotherhood of Steel members transporting water (one has a Gatling laser).
<G-vec00441-002-s119><ambush.überfallen><de> Wenn man Broken Steel installiert hat, versuchen Räuber außerhalb des Turms eine Wasserkarawane der Stählernen Bruderschaft zu überfallen.
<G-vec00441-002-s120><ambush.überfallen><en> The Hureisenjin ambush the convoy shipping the foundation's artifacts back to Japan and take the Lunar Soul.
<G-vec00441-002-s120><ambush.überfallen><de> Die Hureisenjin überfallen die LKWs, die die Artefakte der Inoue Foundation zurück nach Japan bringen sollen.
