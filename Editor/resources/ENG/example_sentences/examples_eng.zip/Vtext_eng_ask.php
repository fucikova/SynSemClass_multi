<G-vec00272-001-s057><ask.auffordern><en> Furthermore, the arbitral tribunal may ask a party to provide the expert with any information serving the purpose intended, or to produce or make available to him for his inspection any and all of the documents or objects that are relevant to the proceedings.
<G-vec00272-001-s057><ask.auffordern><de> Es kann ferner eine Partei auffordern, dem Sachverständigen jede sachdienliche Auskunft zu erteilen oder alle für das Verfahren erheblichen Dokumente oder Sachen zur Besichtigung vorzulegen oder zugänglich zu machen.
<G-vec00272-001-s058><ask.auffordern><en> He said that the China Affairs Office in the Taiwanese Legislature, and other organisations which deal with Chinese affairs, should actively ask the Chinese government to release Shao.
<G-vec00272-001-s058><ask.auffordern><de> Er sagte, dass das Angelegenheitsbüro in der Taiwanischen Legislative und andere Organisationen, die mit chinesischen Angelegenheiten zu tun haben, aktiv die chinesische Regierung dazu auffordern sollten, Shao freizulassen.
<G-vec00272-001-s059><ask.auffordern><en> Where we process personal data for marketing purposes or with your consent, we process the data until you ask us to stop and for a short period after this (to allow us to implement your requests).
<G-vec00272-001-s059><ask.auffordern><de> Soweit wir Personendaten für Marketingzwecke oder mit Ihrer Einwilligung verarbeiten, verarbeiten wir diese Daten so lange, bis Sie uns zur Beendigung dieser Verarbeitung auffordern und für einen kurzen Zeitraum danach (damit wir Ihrer Forderung nachkommen können).
<G-vec00272-001-s060><ask.auffordern><en> According to employees at Tonicale, Chinese vice consul Wang Yanmin threatened that if the show were to go on, the Chinese consulate will ask all the Chinese people living in Munich not to go to any activities held by Tonicale.
<G-vec00272-001-s060><ask.auffordern><de> Mitarbeiter von Tonicale berichten, die chinesische Vizekonsulin Wang Yanmin habe damit gedroht, falls die Show stattfinde, werde das chinesische Konsulat alle in München lebenden Chinesen auffordern, keine der von Tonicale veranstalteten Aktivitäten zu besuchen.
<G-vec00272-001-s061><ask.auffordern><en> · Ask us to correct your personal information;
<G-vec00272-001-s061><ask.auffordern><de> • Uns zur Berichtigung Ihrer personenbezogenen Daten auffordern.
<G-vec00272-001-s062><ask.auffordern><en> If you enter on your online account the landline or mobile number(s) with which you will use the card to call from Spain, each time you call from these numbers the system will not ask you to dial your PIN of the card.
<G-vec00272-001-s062><ask.auffordern><de> Wenn Sie in Ihrem Onlinezugang Ihre Festnetz oder Mobilfunknummer angeben, mit der Sie die Karte aus Spanien benutzen wollen, wird das System diese jedesmal erkennen und Sie nicht auffordern Ihre Pin der Karte einzugeben.
<G-vec00272-001-s063><ask.auffordern><en> If you gave us your consent for inform you about our exclusive offers and discounts, we will store your details until you ask us to opt out from our direct marketing or until you exercise your right to withdraw your consent to our processing of your Personal Data in any other form. 3.
<G-vec00272-001-s063><ask.auffordern><de> Wenn Sie uns Ihr Einverständnis gegeben haben, Sie über unsere exklusiven Angebote und Rabatte zu informieren, speichern wir Ihre Daten, bis Sie uns auffordern, Sie von unserem Direktmarketing abzumelden, oder bis Sie von Ihrem Recht Gebrauch machen, Ihre Zustimmung zur Verarbeitung Ihrer persönlichen Daten in anderer Form zu widerrufen.
<G-vec00272-001-s064><ask.auffordern><en> We could simply ask Subversion to swap out the changed prefixes of the URL.
<G-vec00272-001-s064><ask.auffordern><de> Wir können Subversion einfach auffordern, die geänderten Präfixe des URL zu tauschen.
<G-vec00272-001-s065><ask.auffordern><en> If your credit card is close to expiry, we may ask you to enter a new one.
<G-vec00272-001-s065><ask.auffordern><de> Wenn die Gültigkeit Ihre Kreditkarte am Ablaufen ist, können wir Sie um die Eingabe einer neuen Kreditkarte auffordern.
<G-vec00272-001-s066><ask.auffordern><en> If they do not do that, an attendant will approach them and ask them to move away.
<G-vec00272-001-s066><ask.auffordern><de> Falls Spieler das nicht von selbst tun, wird ein Angestellter des Kasinos sie auffordern, Abstand zu halten.
<G-vec00272-001-s067><ask.auffordern><en> Your appropriate adult must, unless there are special reasons, be with you for the whole time if the police do any of these things: Interview you or ask you to sign a written statement or police notes.
<G-vec00272-001-s067><ask.auffordern><de> Sofern keine besonderen Gründe dagegen sprechen, muss der für Sie zuständige Erwachsene die ganze Zeit bei Ihnen sein, wenn die Polizeibeamten irgendeine dieser Maßnahmen ergreifen: Sie vernehmen oder Sie auffordern, eine schriftliche Aussage oder polizeiliche Aufzeichnungen zu unterschreiben.
<G-vec00272-001-s068><ask.auffordern><en> At the end of the installation process, reboot the computer (the installer will ask you to).
<G-vec00272-001-s068><ask.auffordern><de> Starten Sie den Rechner am Ende der Installation neu (der Installer wird Sie dazu auffordern).
<G-vec00272-001-s069><ask.auffordern><en> The European Citizens’ Initiative allows you to ask the European Commission to prepare a proposal for a legal act.
<G-vec00272-001-s069><ask.auffordern><de> Im Rahmen der Europäischen Bürgerinitiative können Sie die Europäische Kommission auffordern, einen Vorschlag für einen Rechtsakt auszuarbeiten.
<G-vec00272-001-s070><ask.auffordern><en> After watching the video, teachers could ask some questions related to the times and activities seen in the video or prepare a worksheet with multiple choice questions about the text or ask learners to put the times and activities mentioned in the video in the correct order.
<G-vec00272-001-s070><ask.auffordern><de> Wenn die Lernenden sich das Video angesehen haben, kann der Lehrer Fragen zu den Uhrzeiten und Tätigkeiten im Video stellen, ein Arbeitsblatt mit Multiple-Choice-Fragen zum Video vorbereiten oder die Schüler auffordern, die genannten Uhrzeiten und Tätigkeiten in die richtige Reihenfolge zu bringen.
<G-vec00272-001-s071><ask.auffordern><en> You can ask us or third parties to stop sending you marketing messages at any time by contacting us [emailprotected] at any time.
<G-vec00272-001-s071><ask.auffordern><de> Sie können uns oder Dritte auffordern, das Senden von Marketingnachrichten jederzeit zu beenden, indem Sie uns kontaktieren [Email protected] jederzeit.
<G-vec00272-001-s072><ask.auffordern><en> Where you wish to transfer certain personal data that we hold about you, which is processed by automated means, to a third party you may write to us and ask us to provide it to you in a commonly used machine-readable format.
<G-vec00272-001-s072><ask.auffordern><de> Wenn Sie bestimmte personenbezogene Daten, die wir über Sie gespeichert haben und die automatisiert verarbeitet werden, an Dritte weitergeben möchten, können Sie uns schreiben und uns auffordern, Ihnen diese in einem gängigen maschinenlesbaren Format zur Verfügung zu stellen.
<G-vec00272-001-s073><ask.auffordern><en> 2 Â The court may ask the parents to attempt mediation.
<G-vec00272-001-s073><ask.auffordern><de> 2 Das Gericht kann die Eltern zu einem Mediationsversuch auffordern.
<G-vec00272-001-s074><ask.auffordern><en> We will keep this data until you ask us to delete it or until we have fulfilled the purpose for which we were storing it.
<G-vec00272-001-s074><ask.auffordern><de> Sie verbleibt bei uns, bis Sie uns zur Löschung auffordern oder der Zweck für die Datenspeicherung erfüllt ist.
<G-vec00272-001-s075><ask.auffordern><en> Telefónica will ask international media agencies to prepare a single bid to handle all the company's advertising in Europe.
<G-vec00272-001-s075><ask.auffordern><de> Telefónica wird international operierende Media-Agenturen auffordern, ein Angebot zu erstellen, das sämtliche Werbeaktivitäten des Unternehmens in Europa abdeckt.
<G-vec00384-001-s057><ask.auffordern><en> Furthermore, the arbitral tribunal may ask a party to provide the expert with any information serving the purpose intended, or to produce or make available to him for his inspection any and all of the documents or objects that are relevant to the proceedings.
<G-vec00384-001-s057><ask.auffordern><de> Es kann ferner eine Partei auffordern, dem Sachverständigen jede sachdienliche Auskunft zu erteilen oder alle für das Verfahren erheblichen Dokumente oder Sachen zur Besichtigung vorzulegen oder zugänglich zu machen.
<G-vec00384-001-s058><ask.auffordern><en> He said that the China Affairs Office in the Taiwanese Legislature, and other organisations which deal with Chinese affairs, should actively ask the Chinese government to release Shao.
<G-vec00384-001-s058><ask.auffordern><de> Er sagte, dass das Angelegenheitsbüro in der Taiwanischen Legislative und andere Organisationen, die mit chinesischen Angelegenheiten zu tun haben, aktiv die chinesische Regierung dazu auffordern sollten, Shao freizulassen.
<G-vec00384-001-s059><ask.auffordern><en> Where we process personal data for marketing purposes or with your consent, we process the data until you ask us to stop and for a short period after this (to allow us to implement your requests).
<G-vec00384-001-s059><ask.auffordern><de> Soweit wir Personendaten für Marketingzwecke oder mit Ihrer Einwilligung verarbeiten, verarbeiten wir diese Daten so lange, bis Sie uns zur Beendigung dieser Verarbeitung auffordern und für einen kurzen Zeitraum danach (damit wir Ihrer Forderung nachkommen können).
<G-vec00384-001-s060><ask.auffordern><en> According to employees at Tonicale, Chinese vice consul Wang Yanmin threatened that if the show were to go on, the Chinese consulate will ask all the Chinese people living in Munich not to go to any activities held by Tonicale.
<G-vec00384-001-s060><ask.auffordern><de> Mitarbeiter von Tonicale berichten, die chinesische Vizekonsulin Wang Yanmin habe damit gedroht, falls die Show stattfinde, werde das chinesische Konsulat alle in München lebenden Chinesen auffordern, keine der von Tonicale veranstalteten Aktivitäten zu besuchen.
<G-vec00384-001-s061><ask.auffordern><en> · Ask us to correct your personal information;
<G-vec00384-001-s061><ask.auffordern><de> • Uns zur Berichtigung Ihrer personenbezogenen Daten auffordern.
<G-vec00384-001-s062><ask.auffordern><en> If you enter on your online account the landline or mobile number(s) with which you will use the card to call from Spain, each time you call from these numbers the system will not ask you to dial your PIN of the card.
<G-vec00384-001-s062><ask.auffordern><de> Wenn Sie in Ihrem Onlinezugang Ihre Festnetz oder Mobilfunknummer angeben, mit der Sie die Karte aus Spanien benutzen wollen, wird das System diese jedesmal erkennen und Sie nicht auffordern Ihre Pin der Karte einzugeben.
<G-vec00384-001-s063><ask.auffordern><en> If you gave us your consent for inform you about our exclusive offers and discounts, we will store your details until you ask us to opt out from our direct marketing or until you exercise your right to withdraw your consent to our processing of your Personal Data in any other form. 3.
<G-vec00384-001-s063><ask.auffordern><de> Wenn Sie uns Ihr Einverständnis gegeben haben, Sie über unsere exklusiven Angebote und Rabatte zu informieren, speichern wir Ihre Daten, bis Sie uns auffordern, Sie von unserem Direktmarketing abzumelden, oder bis Sie von Ihrem Recht Gebrauch machen, Ihre Zustimmung zur Verarbeitung Ihrer persönlichen Daten in anderer Form zu widerrufen.
<G-vec00384-001-s064><ask.auffordern><en> We could simply ask Subversion to swap out the changed prefixes of the URL.
<G-vec00384-001-s064><ask.auffordern><de> Wir können Subversion einfach auffordern, die geänderten Präfixe des URL zu tauschen.
<G-vec00384-001-s065><ask.auffordern><en> If your credit card is close to expiry, we may ask you to enter a new one.
<G-vec00384-001-s065><ask.auffordern><de> Wenn die Gültigkeit Ihre Kreditkarte am Ablaufen ist, können wir Sie um die Eingabe einer neuen Kreditkarte auffordern.
<G-vec00384-001-s066><ask.auffordern><en> If they do not do that, an attendant will approach them and ask them to move away.
<G-vec00384-001-s066><ask.auffordern><de> Falls Spieler das nicht von selbst tun, wird ein Angestellter des Kasinos sie auffordern, Abstand zu halten.
<G-vec00384-001-s067><ask.auffordern><en> Your appropriate adult must, unless there are special reasons, be with you for the whole time if the police do any of these things: Interview you or ask you to sign a written statement or police notes.
<G-vec00384-001-s067><ask.auffordern><de> Sofern keine besonderen Gründe dagegen sprechen, muss der für Sie zuständige Erwachsene die ganze Zeit bei Ihnen sein, wenn die Polizeibeamten irgendeine dieser Maßnahmen ergreifen: Sie vernehmen oder Sie auffordern, eine schriftliche Aussage oder polizeiliche Aufzeichnungen zu unterschreiben.
<G-vec00384-001-s068><ask.auffordern><en> At the end of the installation process, reboot the computer (the installer will ask you to).
<G-vec00384-001-s068><ask.auffordern><de> Starten Sie den Rechner am Ende der Installation neu (der Installer wird Sie dazu auffordern).
<G-vec00384-001-s069><ask.auffordern><en> The European Citizens’ Initiative allows you to ask the European Commission to prepare a proposal for a legal act.
<G-vec00384-001-s069><ask.auffordern><de> Im Rahmen der Europäischen Bürgerinitiative können Sie die Europäische Kommission auffordern, einen Vorschlag für einen Rechtsakt auszuarbeiten.
<G-vec00384-001-s070><ask.auffordern><en> After watching the video, teachers could ask some questions related to the times and activities seen in the video or prepare a worksheet with multiple choice questions about the text or ask learners to put the times and activities mentioned in the video in the correct order.
<G-vec00384-001-s070><ask.auffordern><de> Wenn die Lernenden sich das Video angesehen haben, kann der Lehrer Fragen zu den Uhrzeiten und Tätigkeiten im Video stellen, ein Arbeitsblatt mit Multiple-Choice-Fragen zum Video vorbereiten oder die Schüler auffordern, die genannten Uhrzeiten und Tätigkeiten in die richtige Reihenfolge zu bringen.
<G-vec00384-001-s071><ask.auffordern><en> You can ask us or third parties to stop sending you marketing messages at any time by contacting us [emailprotected] at any time.
<G-vec00384-001-s071><ask.auffordern><de> Sie können uns oder Dritte auffordern, das Senden von Marketingnachrichten jederzeit zu beenden, indem Sie uns kontaktieren [Email protected] jederzeit.
<G-vec00384-001-s072><ask.auffordern><en> Where you wish to transfer certain personal data that we hold about you, which is processed by automated means, to a third party you may write to us and ask us to provide it to you in a commonly used machine-readable format.
<G-vec00384-001-s072><ask.auffordern><de> Wenn Sie bestimmte personenbezogene Daten, die wir über Sie gespeichert haben und die automatisiert verarbeitet werden, an Dritte weitergeben möchten, können Sie uns schreiben und uns auffordern, Ihnen diese in einem gängigen maschinenlesbaren Format zur Verfügung zu stellen.
<G-vec00384-001-s073><ask.auffordern><en> 2 Â The court may ask the parents to attempt mediation.
<G-vec00384-001-s073><ask.auffordern><de> 2 Das Gericht kann die Eltern zu einem Mediationsversuch auffordern.
<G-vec00384-001-s074><ask.auffordern><en> We will keep this data until you ask us to delete it or until we have fulfilled the purpose for which we were storing it.
<G-vec00384-001-s074><ask.auffordern><de> Sie verbleibt bei uns, bis Sie uns zur Löschung auffordern oder der Zweck für die Datenspeicherung erfüllt ist.
<G-vec00384-001-s075><ask.auffordern><en> Telefónica will ask international media agencies to prepare a single bid to handle all the company's advertising in Europe.
<G-vec00384-001-s075><ask.auffordern><de> Telefónica wird international operierende Media-Agenturen auffordern, ein Angebot zu erstellen, das sämtliche Werbeaktivitäten des Unternehmens in Europa abdeckt.
<G-vec00272-001-s076><ask.befragen><en> Access to others' biographies: children and young people contact other people and ask them questions about their lives.
<G-vec00272-001-s076><ask.befragen><de> Der biographische Zugang: Kinder und Jugendliche gehen in Kontakt mit anderen Menschen, die sie nach ihrer Lebensgeschichte befragen.
<G-vec00272-001-s077><ask.befragen><en> And they ask thee what they ought to spend.
<G-vec00272-001-s077><ask.befragen><de> Und sie befragen dich was sie spenden sollen.
<G-vec00272-001-s078><ask.befragen><en> © Jonas Opperskalski Share article We visited the most inspiring women in Silicon Wadi's tech industry – and did not forget to ask them about the city's most beautiful spots.
<G-vec00272-001-s078><ask.befragen><de> © Jonas Opperskalski Artikel teilen Wir haben die spannendsten Frauen der Tech-Branche im Silicon Wadi besucht – natürlich nicht, ohne sie nach den schönsten Orten der Stadt zu befragen.
<G-vec00272-001-s079><ask.befragen><en> For 25 years Wayne McGregor has created choreographies that ask questions about life through the experience of the body.
<G-vec00272-001-s079><ask.befragen><de> 25 Jahre lang hat Wayne McGregor Choreografien entwickelt, die das Leben durch die Erfahrung des Körpers befragen.
<G-vec00272-001-s080><ask.befragen><en> The owner will ask guests if this works for them and if guests do wish to have it come on earlier, they can notify the owner to make this change.
<G-vec00272-001-s080><ask.befragen><de> Der Besitzer wird die Gäste befragen, ob dies für sie in Ordnung sei und falls sie die Wärme früher haben möchten, können sie ihm Bescheid geben, so dass er es umändert.
<G-vec00272-001-s081><ask.befragen><en> They lead interviews and ask the visitors.
<G-vec00272-001-s081><ask.befragen><de> Sie führen Interviews und befragen die Besucher.
<G-vec00272-001-s082><ask.befragen><en> It is necessary, though, that they be placed in the right and perfect places, and the decisions that they make—if you were to ask them—they would often say that, no, they have no effect upon the world, they did not do this for Christ Michael, Nebadonia, their guardian angel, or even for themselves, but they knew it was the right decision to be made of all the options that were available.
<G-vec00272-001-s082><ask.befragen><de> Es ist jedoch unerlässlich, daß sie an den richtigen und idealen Orten eingesetzt werden, und wenn Ihr sie bezüglich der Entscheidungen, die sie treffen, befragen würdet, dann würden sie oft antworten, daß sie überhaupt keinen Einfluß auf die Welt haben und dies nicht für Christ Michael, Nebadonia, ihren Schutzengel oder gar für sich selbst gemacht haben, sondern weil sie wußten, daß dies unter allen verfügbaren Optionen die einzige richtige Entscheidung war.
<G-vec00272-001-s083><ask.befragen><en> 2:215 They ask thee as to what they should spend.
<G-vec00272-001-s083><ask.befragen><de> 2:215 Sie befragen dich, was sie spenden sollen.
<G-vec00272-001-s084><ask.befragen><en> This was such a wonderful and lucky coincidence that we wish to ask you right away: You like to solve problems.
<G-vec00272-001-s084><ask.befragen><de> Eine wirklich schöne und glückliche Fügung, dass wir Sie nun direkt befragen dürfen: Sie mögen es, Probleme zu lösen.
<G-vec00272-001-s085><ask.befragen><en> "Mr. Wei was puzzled by his behaviour and asked him, ""Why are you doing this?"" The man replied, ""I am puzzled about something and would like to ask you about it, but I am afraid that I might offend you."" Mr. Wei told him, ""I won't be upset."
<G-vec00272-001-s085><ask.befragen><de> Wei war bestürzt über sein Verhalten und fragte: “Warum machst du das?“ Der Mann antwortete: “Ich bin über etwas beunruhigt und möchte Sie darüber befragen; aber ich fürchte, dass ich Sie verletzen könnte.“ Wei entgegnete: “Ich werde nicht ärgerlich darüber sein.
<G-vec00272-001-s086><ask.befragen><en> I happily agreed and so during the next two days my colleagues had a possibility to learn a few Falun Gong exercises and ask me about the things they were interested in.
<G-vec00272-001-s086><ask.befragen><de> Glücklich stimmte ich zu und so hatten meine Kollegen in den nächsten zwei Tagen die Möglichkeit, ein paar Falun Gong Übungen zu lernen und mich über die Dinge, die sie interessierten, zu befragen.
<G-vec00272-001-s087><ask.befragen><en> And then you ask your members online on your website which position the readers are more likely to agree to.
<G-vec00272-001-s087><ask.befragen><de> Und dann befragen Sie online auf Ihrer Website Ihre Mitglieder, welcher Position die Leser eher zustimmen.
<G-vec00272-001-s088><ask.befragen><en> We will ask him about it and see what sort of an opinion he will give.
<G-vec00272-001-s088><ask.befragen><de> Wir wollen ihn darüber befragen und sehen, was er eben darüber für eine Meinung von sich geben wird.
<G-vec00272-001-s089><ask.befragen><en> And from then on no one dared ask him any more questions.
<G-vec00272-001-s089><ask.befragen><de> Und es wagte niemand mehr, ihn zu befragen.
<G-vec00272-001-s090><ask.befragen><en> When he and his wife saw the Falun Gong booth in the Berlin city centre, they stopped to watch the exercise demonstration and ask practitioners about the persecution.
<G-vec00272-001-s090><ask.befragen><de> Als er und seine Frau den Falun Gong Stand im Stadtzentrum von Berlin sahen, blieben sie stehen, um die Übungsvorführungen anzuschauen und die Praktizierenden über die Verfolgung zu befragen.
<G-vec00272-001-s091><ask.befragen><en> Therefore, we systematically ask our customers around the world — completely independent of specific technical solutions — what specific market and business challenges they think they face.
<G-vec00272-001-s091><ask.befragen><de> So befragen wir weltweit systematisch unsere Kunden – ganz unabhängig von konkreten technischen Lösungen – über ihre Sicht des Marktes und die geschäftlichen Herausforderungen, die sie konkret zu bewältigen haben.
<G-vec00272-001-s092><ask.befragen><en> I can't ask the internet, because I don't have access to it.
<G-vec00272-001-s092><ask.befragen><de> Ich kann leider das Internet nicht befragen, da ich keinen Zugang bekomme.
<G-vec00272-001-s093><ask.befragen><en> We shall also ask you for your personal details if you take part in a prize competition or send inquiries to us.
<G-vec00272-001-s093><ask.befragen><de> Nach persönlichen Daten befragen wir Sie auch, wenn Sie an einem Gewinnspiel teilnehmen oder Anfragen an uns richten.
<G-vec00272-001-s094><ask.befragen><en> Here they ask potential users about the attractiveness, potentials and barriers of electric cars.
<G-vec00272-001-s094><ask.befragen><de> Dafür befragen sie potenzielle Nutzerinnen und Nutzer nach Attraktivität, Potenzialen und Barrieren der Elektroautos.
<G-vec00272-001-s095><ask.bitten><en> We ask you to note that during the period May to Midsummer, vertical fishing is not allowed.
<G-vec00272-001-s095><ask.bitten><de> Bitte beachten Sie, dass in der Zeit von Mai bis Mittsommer vertikales Fischen nicht erlaubt ist.
<G-vec00272-001-s096><ask.bitten><en> I ask that you consider this fact very carefully.
<G-vec00272-001-s096><ask.bitten><de> Ich bitte euch, diese Tatsache sehr sorgfältig zu erwägen.
<G-vec00272-001-s097><ask.bitten><en> All i ask you is just for you to give me this opportunity to prove to you how much i really want you.
<G-vec00272-001-s097><ask.bitten><de> Ich bitte Sie ist nur für dich, gib mir diese Gelegenheit, um Ihnen zu beweisen, wie sehr ich will dich wirklich.
<G-vec00272-001-s098><ask.bitten><en> There is really too much to list and it may be better if you ask us for more details.
<G-vec00272-001-s098><ask.bitten><de> Es ist wirklich zu viel Liste und ist es vielleicht besser, wenn Sie uns bitte für weitere Informationen.
<G-vec00272-001-s099><ask.bitten><en> I ask Christ Crucified and Risen to give each Sister the grace to recognize His will and her specific vocation on the Carmelite way of life.
<G-vec00272-001-s099><ask.bitten><de> Inständig bitte ich Christus, den Gekreuzigten und Auferstandenen, euch alle seinen Willen und die besondere Berufung auf dem Weg des Karmelitenlebens erkennen zu lassen.
<G-vec00272-001-s100><ask.bitten><en> We ask you for understanding, that we can provide such information only to the known contacts.
<G-vec00272-001-s100><ask.bitten><de> Bitte haben Sie deshalb Verständnis dafür, dass wir solche Auskünfte nur den uns bekannten Kontaktpersonen erteilen können.
<G-vec00272-001-s101><ask.bitten><en> I change our course to more or less 245? and ask the radio operator for QTE or QDM. What do you know?
<G-vec00272-001-s101><ask.bitten><de> Ich wechsle den Kurs grob geschätzt auf zirka 245°, und bitte einen Funker um ein QTE oder ein QDM.
<G-vec00272-001-s102><ask.bitten><en> It is more than a word that I ask you to practice.
<G-vec00272-001-s102><ask.bitten><de> Das ist mehr als ein Wort, was Ich euch bitte zu praktizieren.
<G-vec00272-001-s103><ask.bitten><en> By reflecting on the history of our relations, we cannot help but be saddened by the disputes and acts of violence committed in the name of our faith, and I ask that the Lord grant us the grace to recognize ourselves all as sinners and to be able to forgive one another.
<G-vec00272-001-s103><ask.bitten><de> Wenn wir über die Geschichte unserer Beziehungen nachdenken, dann können wir nicht umhin, traurig zu sein über die im Namen des eigenen Glaubens begangenen Konflikte und Gewalttaten, und ich bitte den Herrn, dass er uns die Gnade schenken möge, uns alle als Sünder zu bekennen und einander vergeben zu können.
<G-vec00272-001-s104><ask.bitten><en> And I also ask for great generosity on the part of those who can help, to resolve the problem.
<G-vec00272-001-s104><ask.bitten><de> Und ich bitte auch um Großherzigkeit beim Helfen seitens derer, die helfen können, das Problem zu lösen.
<G-vec00272-001-s105><ask.bitten><en> To protect this email address against spammers, I ask that you type your code (displayed above) in the text box.
<G-vec00272-001-s105><ask.bitten><de> Spamprotection Um die Benutzung dieses Formulars durch Spammer zu verhindern, bitte ich Sie, den unten angezeigten Zahlencode in das Eingabefeld einzugeben.
<G-vec00272-001-s106><ask.bitten><en> I ask you to respect the work on the map and not to offer them without the consent of my other portals.
<G-vec00272-001-s106><ask.bitten><de> Ich bitte, die Arbeit an der Map zu respektieren und diese nicht ohne Zustimmung von mir in anderen Portalen anzubieten.
<G-vec00272-001-s107><ask.bitten><en> 5 If any of you lack wisdom, let him ask of God, that giveth to all men liberally, and upbraideth not; and it shall be given him.
<G-vec00272-001-s107><ask.bitten><de> 5 Wenn aber jemandem unter euch Weisheit mangelt, der bitte Gott, der da gern gibt jedermann und allen mit Güte begegnet, so wird ihm gegeben werden.
<G-vec00272-001-s108><ask.bitten><en> To avoid spam we kindly ask you to answer the question below.
<G-vec00272-001-s108><ask.bitten><de> Um Spam zu vermeiden beantworten Sie bitte die Frage unten.
<G-vec00272-001-s109><ask.bitten><en> The video feeds was a rather pleasant experience, they ran smooth in a medium sized window, and I don't ask for much more on xxx sites yet, but you can get better quality though.
<G-vec00272-001-s109><ask.bitten><de> Die videozufuhren waren eine ziemlich pleasent Erfahrung, ließen sie glattes in einem mittelgrossen Fenster laufen, und ich bitte nicht um viel mehr auf xxx Aufstellungsorten noch, aber Sie können bessere Qualität zwar erhalten.
<G-vec00272-001-s110><ask.bitten><en> Make your presence known in my life. Father, I also ask that you bless those I know who are struggling with their faith, and with broken and disappointed hearts.
<G-vec00272-001-s110><ask.bitten><de> Vater, ich bitte dich auch, die mir bekannten Menschen zu segnen, die um ihren Glauben kämpfen und sich mit ihren verwundeten und enttäuschten Herzen auseinandersetzen.
<G-vec00272-001-s111><ask.bitten><en> Ask your client to sit down, and gently place both feet into the warm, bubbly bath.
<G-vec00272-001-s111><ask.bitten><de> Bitte deine/n Freund/in, sich hinzusetzen und seine Füße vorsichtig in das Wasser zu tauchen.
<G-vec00272-001-s112><ask.bitten><en> To see what other custom car audio items that could enhance the sound quality we might want to ask the help of sales assistants.
<G-vec00272-001-s112><ask.bitten><de> Um zu sehen, welche anderen Custom Car Audio-Elemente, die Verbesserung der Klangqualität wir möchten bitte die Hilfe der Verkäufer.
<G-vec00272-001-s113><ask.bitten><en> If you come to Me like children to the Father with a request, I will not close My ears but grant you what you ask for.
<G-vec00272-001-s113><ask.bitten><de> Wenn ihr wie Kinder zum Vater kommet und Mich bittet, verschließe Ich nicht Mein Ohr, sondern Ich bedenke euch dieser Bitte gemäß.
<G-vec00384-001-s095><ask.bitten><en> We ask you to note that during the period May to Midsummer, vertical fishing is not allowed.
<G-vec00384-001-s095><ask.bitten><de> Bitte beachten Sie, dass in der Zeit von Mai bis Mittsommer vertikales Fischen nicht erlaubt ist.
<G-vec00384-001-s096><ask.bitten><en> I ask that you consider this fact very carefully.
<G-vec00384-001-s096><ask.bitten><de> Ich bitte euch, diese Tatsache sehr sorgfältig zu erwägen.
<G-vec00384-001-s097><ask.bitten><en> All i ask you is just for you to give me this opportunity to prove to you how much i really want you.
<G-vec00384-001-s097><ask.bitten><de> Ich bitte Sie ist nur für dich, gib mir diese Gelegenheit, um Ihnen zu beweisen, wie sehr ich will dich wirklich.
<G-vec00384-001-s098><ask.bitten><en> There is really too much to list and it may be better if you ask us for more details.
<G-vec00384-001-s098><ask.bitten><de> Es ist wirklich zu viel Liste und ist es vielleicht besser, wenn Sie uns bitte für weitere Informationen.
<G-vec00384-001-s099><ask.bitten><en> I ask Christ Crucified and Risen to give each Sister the grace to recognize His will and her specific vocation on the Carmelite way of life.
<G-vec00384-001-s099><ask.bitten><de> Inständig bitte ich Christus, den Gekreuzigten und Auferstandenen, euch alle seinen Willen und die besondere Berufung auf dem Weg des Karmelitenlebens erkennen zu lassen.
<G-vec00384-001-s100><ask.bitten><en> We ask you for understanding, that we can provide such information only to the known contacts.
<G-vec00384-001-s100><ask.bitten><de> Bitte haben Sie deshalb Verständnis dafür, dass wir solche Auskünfte nur den uns bekannten Kontaktpersonen erteilen können.
<G-vec00384-001-s101><ask.bitten><en> I change our course to more or less 245? and ask the radio operator for QTE or QDM. What do you know?
<G-vec00384-001-s101><ask.bitten><de> Ich wechsle den Kurs grob geschätzt auf zirka 245°, und bitte einen Funker um ein QTE oder ein QDM.
<G-vec00384-001-s102><ask.bitten><en> It is more than a word that I ask you to practice.
<G-vec00384-001-s102><ask.bitten><de> Das ist mehr als ein Wort, was Ich euch bitte zu praktizieren.
<G-vec00384-001-s103><ask.bitten><en> By reflecting on the history of our relations, we cannot help but be saddened by the disputes and acts of violence committed in the name of our faith, and I ask that the Lord grant us the grace to recognize ourselves all as sinners and to be able to forgive one another.
<G-vec00384-001-s103><ask.bitten><de> Wenn wir über die Geschichte unserer Beziehungen nachdenken, dann können wir nicht umhin, traurig zu sein über die im Namen des eigenen Glaubens begangenen Konflikte und Gewalttaten, und ich bitte den Herrn, dass er uns die Gnade schenken möge, uns alle als Sünder zu bekennen und einander vergeben zu können.
<G-vec00384-001-s104><ask.bitten><en> And I also ask for great generosity on the part of those who can help, to resolve the problem.
<G-vec00384-001-s104><ask.bitten><de> Und ich bitte auch um Großherzigkeit beim Helfen seitens derer, die helfen können, das Problem zu lösen.
<G-vec00384-001-s105><ask.bitten><en> To protect this email address against spammers, I ask that you type your code (displayed above) in the text box.
<G-vec00384-001-s105><ask.bitten><de> Spamprotection Um die Benutzung dieses Formulars durch Spammer zu verhindern, bitte ich Sie, den unten angezeigten Zahlencode in das Eingabefeld einzugeben.
<G-vec00384-001-s106><ask.bitten><en> I ask you to respect the work on the map and not to offer them without the consent of my other portals.
<G-vec00384-001-s106><ask.bitten><de> Ich bitte, die Arbeit an der Map zu respektieren und diese nicht ohne Zustimmung von mir in anderen Portalen anzubieten.
<G-vec00384-001-s107><ask.bitten><en> 5 If any of you lack wisdom, let him ask of God, that giveth to all men liberally, and upbraideth not; and it shall be given him.
<G-vec00384-001-s107><ask.bitten><de> 5 Wenn aber jemandem unter euch Weisheit mangelt, der bitte Gott, der da gern gibt jedermann und allen mit Güte begegnet, so wird ihm gegeben werden.
<G-vec00384-001-s108><ask.bitten><en> To avoid spam we kindly ask you to answer the question below.
<G-vec00384-001-s108><ask.bitten><de> Um Spam zu vermeiden beantworten Sie bitte die Frage unten.
<G-vec00384-001-s109><ask.bitten><en> The video feeds was a rather pleasant experience, they ran smooth in a medium sized window, and I don't ask for much more on xxx sites yet, but you can get better quality though.
<G-vec00384-001-s109><ask.bitten><de> Die videozufuhren waren eine ziemlich pleasent Erfahrung, ließen sie glattes in einem mittelgrossen Fenster laufen, und ich bitte nicht um viel mehr auf xxx Aufstellungsorten noch, aber Sie können bessere Qualität zwar erhalten.
<G-vec00384-001-s110><ask.bitten><en> Make your presence known in my life. Father, I also ask that you bless those I know who are struggling with their faith, and with broken and disappointed hearts.
<G-vec00384-001-s110><ask.bitten><de> Vater, ich bitte dich auch, die mir bekannten Menschen zu segnen, die um ihren Glauben kämpfen und sich mit ihren verwundeten und enttäuschten Herzen auseinandersetzen.
<G-vec00384-001-s111><ask.bitten><en> Ask your client to sit down, and gently place both feet into the warm, bubbly bath.
<G-vec00384-001-s111><ask.bitten><de> Bitte deine/n Freund/in, sich hinzusetzen und seine Füße vorsichtig in das Wasser zu tauchen.
<G-vec00384-001-s112><ask.bitten><en> To see what other custom car audio items that could enhance the sound quality we might want to ask the help of sales assistants.
<G-vec00384-001-s112><ask.bitten><de> Um zu sehen, welche anderen Custom Car Audio-Elemente, die Verbesserung der Klangqualität wir möchten bitte die Hilfe der Verkäufer.
<G-vec00384-001-s113><ask.bitten><en> If you come to Me like children to the Father with a request, I will not close My ears but grant you what you ask for.
<G-vec00384-001-s113><ask.bitten><de> Wenn ihr wie Kinder zum Vater kommet und Mich bittet, verschließe Ich nicht Mein Ohr, sondern Ich bedenke euch dieser Bitte gemäß.
<G-vec00272-001-s114><ask.bitten><en> """Cheat Sheet: Questions to Ask Before You Hire a Sponsorship Broker"" -Â This is a compilation of questionsÂ that will allow greatÂ brokers to shine, expose the shonks, and clarify the weaknesses and strengths of all the brokers in between."
<G-vec00272-001-s114><ask.bitten><de> "Förderungüberbrückerblätter ""Überbrücker-Blatt: Die Fragen, zum, bevor Sie einen Förderung-Vermittler"" - anstellen um um dieses zu bitten ist eine Kompilation der Fragen, die großen Vermittlern erlauben zu glänzen, die shonks herauszustellen und die Schwächen und die Stärken aller Vermittler in-between zu erklären."
<G-vec00272-001-s115><ask.bitten><en> Piste and off-piste are often different so we ask snow reporters to describe Mount Parnassos piste and off-piste conditions separately.
<G-vec00272-001-s115><ask.bitten><de> Piste und Off- Pisten sind oft anders, so bitten wir Schnee Reportern die Pisten und Off-Pisten Bedingungen in Mount Parnassos getrennt zu beschreiben.
<G-vec00272-001-s116><ask.bitten><en> If you have a shops want the similar flooring as the above picture, please contact us and we will ask a dealer to contact you.
<G-vec00272-001-s116><ask.bitten><de> Wenn Sie wollen ein Geschäfte die ähnliche Bodenbeläge wie das obige Bild, bitte Kontakt uns und wir bitten einen Händler mit Ihnen Kontakt aufnehmen.
<G-vec00272-001-s117><ask.bitten><en> If we want to make use of your personal data in a way that we haven't previously identified, we will contact you to provide information about this and, if necessary, to ask for your consent.
<G-vec00272-001-s117><ask.bitten><de> Wenn wir Ihre persönlichen Daten in einer Art und Weise verwenden möchten, die wir vorher nicht identifiziert haben, werden wir Sie kontaktieren Informationen Ã1⁄4ber die Verwendung zur VerfÃ1⁄4gung zu stellen und, falls erforderlich, um ihre Zustimmung bitten.
<G-vec00272-001-s118><ask.bitten><en> If we doubt that we truly belong to Christ, we only need to repent and ask Him to save us.
<G-vec00272-001-s118><ask.bitten><de> Wenn wir daran zweifeln, ob wir wirklich zu Christus gehören, dann müssen wir nur bereuen und bekennen und Gott bitten uns zu retten.
<G-vec00272-001-s119><ask.bitten><en> Piste and off-piste are often different so we ask snow reporters to describe Telgárt piste and off-piste conditions separately.
<G-vec00272-001-s119><ask.bitten><de> Piste und Off- Pisten sind oft anders, so bitten wir Schnee Reportern die Pisten und Off-Pisten Bedingungen in Telgárt getrennt zu beschreiben.
<G-vec00272-001-s120><ask.bitten><en> She is ready right away to come to our aid when we pray to her, when we ask for her help, her protection is in our favour.
<G-vec00272-001-s120><ask.bitten><de> Sie ist sofort bereit, uns zur Hilfe zu kommen, wenn wir zu ihr beten, wenn wir um ihre Hilfe, ihren Schutz für uns bitten.
<G-vec00272-001-s121><ask.bitten><en> Some actively reach out to their customers to ask how they can improve.
<G-vec00272-001-s121><ask.bitten><de> Stattdessen bitten sie ihre Kunden aktiv um Verbesserungsvorschläge.
<G-vec00272-001-s122><ask.bitten><en> He stood in front of a petition desk and managed to use his very limited English to ask people to sign their names.
<G-vec00272-001-s122><ask.bitten><de> Er stand vor dem Tisch mit den Unterschriftenlisten und schaffte es mit seinem sehr begrenzten Englisch die Menschen zu bitten, zu unterschreiben.
<G-vec00272-001-s123><ask.bitten><en> In the event of domain disputes or problems under copyright law or similar problems, we ask you to contact us as soon as possible in order to avoid unnecessary legal disputes and costs.
<G-vec00272-001-s123><ask.bitten><de> Im Falle von Domainstreitigkeiten oder wettbewerbsrechtlichen oder ähnlichen Problemen, bitten wir Sie, zur Vermeidung unnötiger Rechtsstreite und Kosten, uns bereits im Vorfeld zu kontaktieren.
<G-vec00272-001-s124><ask.bitten><en> We kindly ask you to specify your inquiry as detailed as possible.
<G-vec00272-001-s124><ask.bitten><de> Wir bitten Ihrer Anfrage möglichst detaillierte technische Spezifikationen beizufügen.
<G-vec00272-001-s125><ask.bitten><en> "It is Jesus himself, said the Pope, who, in anticipating this, told us: If you then, who are evil, know how to give good gifts to your children, how much more will the heavenly Father give the Holy Spirit to those who ask him!"""
<G-vec00272-001-s125><ask.bitten><de> "Doch es sei Jesus selbst, der uns gesagt habe: ""Wenn nun ihr, die ihr böse seid, euren Kindern gute Gaben zu geben wisst, wie viel mehr wird euer Vater im Himmel den Heiligen Geist denen geben, die ihn bitten"", bekräftigte der Papst mit Blick auf das Tagesevangelium."
<G-vec00272-001-s126><ask.bitten><en> The other prophets had to ask for the word and for the power with which they could perform the deeds. You do not have to ask but act as a Lord who does not have to ask a higher divine being for inspiration of the word or for strength to perform deeds.
<G-vec00272-001-s126><ask.bitten><de> Die andern Propheten mussten bitten ums Wort und um die Machtgabe zur Tat, – du brauchst nicht zu bitten, sondern handelst wie ein Herr, der niemanden zu bitten braucht, daß ihm ein höheres Gottwesen das Wort einhauche und ihn stärke zur Tat.
<G-vec00272-001-s127><ask.bitten><en> The other prophets had to ask for the word and for the power with which they could perform the deeds. You do not have to ask but act as a Lord who does not have to ask a higher divine being for inspiration of the word or for strength to perform deeds.
<G-vec00272-001-s127><ask.bitten><de> Die andern Propheten mussten bitten ums Wort und um die Machtgabe zur Tat, – du brauchst nicht zu bitten, sondern handelst wie ein Herr, der niemanden zu bitten braucht, daß ihm ein höheres Gottwesen das Wort einhauche und ihn stärke zur Tat.
<G-vec00272-001-s128><ask.bitten><en> We would like to ask you not to wear sportswear or bathrobes in the drinking and dining room and also not to use mobile phones during events in these rooms.
<G-vec00272-001-s128><ask.bitten><de> Wir bitten, im Trink- und Speisesaal keine Sportbekleidung oder Bademäntel zu tragen und hier sowie bei Veranstaltungen kein Mobiltelefon zu benutzen.
<G-vec00272-001-s129><ask.bitten><en> On this World Day of the Sick let us ask Jesus in his mercy, through the intercession of Mary, his Mother and ours, to grant to all of us this same readiness to be serve those in need, and, in particular, our infirm brothers and sisters.
<G-vec00272-001-s129><ask.bitten><de> An diesem Welttag der Kranken wollen wir den barmherzigen Jesus auf die Fürsprache Marias, seiner und unserer Mutter, bitten, uns allen diese Bereitschaft zum Dienst an den Bedürftigen, und konkret an unseren kranken Brüdern und Schwestern, zu schenken.
<G-vec00272-001-s130><ask.bitten><en> Piste and off-piste are often different so we ask snow reporters to describe Mount Seymour piste and off-piste conditions separately.
<G-vec00272-001-s130><ask.bitten><de> Piste und Off- Pisten sind oft anders, so bitten wir Schnee Reportern die Pisten und Off-Pisten Bedingungen in Mount Seymour getrennt zu beschreiben.
<G-vec00272-001-s131><ask.bitten><en> We ask you to transfer the invoice amount, stating your order number.
<G-vec00272-001-s131><ask.bitten><de> Wir bitten Sie, den Rechnungsbetrag unter Angabe der Bestellnummer, zu überweisen.
<G-vec00272-001-s132><ask.bitten><en> Some online medicine stores ask the client to give their medical history, by filling in a kind that they give on their web site.
<G-vec00272-001-s132><ask.bitten><de> Einige online Drogerien bitten den Kunden ihre medizinische Vorgeschichte, durch Ausfüllen eines Formulars, das sie auf ihrer Webseite zur Verfügung stellen.
<G-vec00384-001-s114><ask.bitten><en> """Cheat Sheet: Questions to Ask Before You Hire a Sponsorship Broker"" -Â This is a compilation of questionsÂ that will allow greatÂ brokers to shine, expose the shonks, and clarify the weaknesses and strengths of all the brokers in between."
<G-vec00384-001-s114><ask.bitten><de> "Förderungüberbrückerblätter ""Überbrücker-Blatt: Die Fragen, zum, bevor Sie einen Förderung-Vermittler"" - anstellen um um dieses zu bitten ist eine Kompilation der Fragen, die großen Vermittlern erlauben zu glänzen, die shonks herauszustellen und die Schwächen und die Stärken aller Vermittler in-between zu erklären."
<G-vec00384-001-s115><ask.bitten><en> Piste and off-piste are often different so we ask snow reporters to describe Mount Parnassos piste and off-piste conditions separately.
<G-vec00384-001-s115><ask.bitten><de> Piste und Off- Pisten sind oft anders, so bitten wir Schnee Reportern die Pisten und Off-Pisten Bedingungen in Mount Parnassos getrennt zu beschreiben.
<G-vec00384-001-s116><ask.bitten><en> If you have a shops want the similar flooring as the above picture, please contact us and we will ask a dealer to contact you.
<G-vec00384-001-s116><ask.bitten><de> Wenn Sie wollen ein Geschäfte die ähnliche Bodenbeläge wie das obige Bild, bitte Kontakt uns und wir bitten einen Händler mit Ihnen Kontakt aufnehmen.
<G-vec00384-001-s117><ask.bitten><en> If we want to make use of your personal data in a way that we haven't previously identified, we will contact you to provide information about this and, if necessary, to ask for your consent.
<G-vec00384-001-s117><ask.bitten><de> Wenn wir Ihre persönlichen Daten in einer Art und Weise verwenden möchten, die wir vorher nicht identifiziert haben, werden wir Sie kontaktieren Informationen Ã1⁄4ber die Verwendung zur VerfÃ1⁄4gung zu stellen und, falls erforderlich, um ihre Zustimmung bitten.
<G-vec00384-001-s118><ask.bitten><en> If we doubt that we truly belong to Christ, we only need to repent and ask Him to save us.
<G-vec00384-001-s118><ask.bitten><de> Wenn wir daran zweifeln, ob wir wirklich zu Christus gehören, dann müssen wir nur bereuen und bekennen und Gott bitten uns zu retten.
<G-vec00384-001-s119><ask.bitten><en> Piste and off-piste are often different so we ask snow reporters to describe Telgárt piste and off-piste conditions separately.
<G-vec00384-001-s119><ask.bitten><de> Piste und Off- Pisten sind oft anders, so bitten wir Schnee Reportern die Pisten und Off-Pisten Bedingungen in Telgárt getrennt zu beschreiben.
<G-vec00384-001-s120><ask.bitten><en> She is ready right away to come to our aid when we pray to her, when we ask for her help, her protection is in our favour.
<G-vec00384-001-s120><ask.bitten><de> Sie ist sofort bereit, uns zur Hilfe zu kommen, wenn wir zu ihr beten, wenn wir um ihre Hilfe, ihren Schutz für uns bitten.
<G-vec00384-001-s121><ask.bitten><en> Some actively reach out to their customers to ask how they can improve.
<G-vec00384-001-s121><ask.bitten><de> Stattdessen bitten sie ihre Kunden aktiv um Verbesserungsvorschläge.
<G-vec00384-001-s122><ask.bitten><en> He stood in front of a petition desk and managed to use his very limited English to ask people to sign their names.
<G-vec00384-001-s122><ask.bitten><de> Er stand vor dem Tisch mit den Unterschriftenlisten und schaffte es mit seinem sehr begrenzten Englisch die Menschen zu bitten, zu unterschreiben.
<G-vec00384-001-s123><ask.bitten><en> In the event of domain disputes or problems under copyright law or similar problems, we ask you to contact us as soon as possible in order to avoid unnecessary legal disputes and costs.
<G-vec00384-001-s123><ask.bitten><de> Im Falle von Domainstreitigkeiten oder wettbewerbsrechtlichen oder ähnlichen Problemen, bitten wir Sie, zur Vermeidung unnötiger Rechtsstreite und Kosten, uns bereits im Vorfeld zu kontaktieren.
<G-vec00384-001-s124><ask.bitten><en> We kindly ask you to specify your inquiry as detailed as possible.
<G-vec00384-001-s124><ask.bitten><de> Wir bitten Ihrer Anfrage möglichst detaillierte technische Spezifikationen beizufügen.
<G-vec00384-001-s125><ask.bitten><en> "It is Jesus himself, said the Pope, who, in anticipating this, told us: If you then, who are evil, know how to give good gifts to your children, how much more will the heavenly Father give the Holy Spirit to those who ask him!"""
<G-vec00384-001-s125><ask.bitten><de> "Doch es sei Jesus selbst, der uns gesagt habe: ""Wenn nun ihr, die ihr böse seid, euren Kindern gute Gaben zu geben wisst, wie viel mehr wird euer Vater im Himmel den Heiligen Geist denen geben, die ihn bitten"", bekräftigte der Papst mit Blick auf das Tagesevangelium."
<G-vec00384-001-s126><ask.bitten><en> The other prophets had to ask for the word and for the power with which they could perform the deeds. You do not have to ask but act as a Lord who does not have to ask a higher divine being for inspiration of the word or for strength to perform deeds.
<G-vec00384-001-s126><ask.bitten><de> Die andern Propheten mussten bitten ums Wort und um die Machtgabe zur Tat, – du brauchst nicht zu bitten, sondern handelst wie ein Herr, der niemanden zu bitten braucht, daß ihm ein höheres Gottwesen das Wort einhauche und ihn stärke zur Tat.
<G-vec00384-001-s127><ask.bitten><en> The other prophets had to ask for the word and for the power with which they could perform the deeds. You do not have to ask but act as a Lord who does not have to ask a higher divine being for inspiration of the word or for strength to perform deeds.
<G-vec00384-001-s127><ask.bitten><de> Die andern Propheten mussten bitten ums Wort und um die Machtgabe zur Tat, – du brauchst nicht zu bitten, sondern handelst wie ein Herr, der niemanden zu bitten braucht, daß ihm ein höheres Gottwesen das Wort einhauche und ihn stärke zur Tat.
<G-vec00384-001-s128><ask.bitten><en> We would like to ask you not to wear sportswear or bathrobes in the drinking and dining room and also not to use mobile phones during events in these rooms.
<G-vec00384-001-s128><ask.bitten><de> Wir bitten, im Trink- und Speisesaal keine Sportbekleidung oder Bademäntel zu tragen und hier sowie bei Veranstaltungen kein Mobiltelefon zu benutzen.
<G-vec00384-001-s129><ask.bitten><en> On this World Day of the Sick let us ask Jesus in his mercy, through the intercession of Mary, his Mother and ours, to grant to all of us this same readiness to be serve those in need, and, in particular, our infirm brothers and sisters.
<G-vec00384-001-s129><ask.bitten><de> An diesem Welttag der Kranken wollen wir den barmherzigen Jesus auf die Fürsprache Marias, seiner und unserer Mutter, bitten, uns allen diese Bereitschaft zum Dienst an den Bedürftigen, und konkret an unseren kranken Brüdern und Schwestern, zu schenken.
<G-vec00384-001-s130><ask.bitten><en> Piste and off-piste are often different so we ask snow reporters to describe Mount Seymour piste and off-piste conditions separately.
<G-vec00384-001-s130><ask.bitten><de> Piste und Off- Pisten sind oft anders, so bitten wir Schnee Reportern die Pisten und Off-Pisten Bedingungen in Mount Seymour getrennt zu beschreiben.
<G-vec00384-001-s131><ask.bitten><en> We ask you to transfer the invoice amount, stating your order number.
<G-vec00384-001-s131><ask.bitten><de> Wir bitten Sie, den Rechnungsbetrag unter Angabe der Bestellnummer, zu überweisen.
<G-vec00384-001-s132><ask.bitten><en> Some online medicine stores ask the client to give their medical history, by filling in a kind that they give on their web site.
<G-vec00384-001-s132><ask.bitten><de> Einige online Drogerien bitten den Kunden ihre medizinische Vorgeschichte, durch Ausfüllen eines Formulars, das sie auf ihrer Webseite zur Verfügung stellen.
<G-vec00272-001-s133><ask.bitten><en> You should also ask your doctor to check the compatibility of the drugs you may be taking with Kamagra Polo. Known interactions include such medications as nitroglycerin drugs, nitroprusside medicines, amyl nitrate, azole antifungal drugs and others.
<G-vec00272-001-s133><ask.bitten><de> Bitten Sie Ihren Arzt auch darum, die Kompatibilität von Kamagra Polo mit anderen Arzneimitteln zu prüfen, welche Sie gleichzeitig mit Kamagra Polo einnehmen können.
<G-vec00272-001-s134><ask.bitten><en> All the forces of the heavenly dimension are at our disposal, provided that we ask in accordance with God’s perfect will.
<G-vec00272-001-s134><ask.bitten><de> Uns stehen alle Kräfte der himmlischen He-Dimension zu Gebot, vorausgesetzt, wir bitten darum im Einklang mit dem vollkommenen Willen Gottes.
<G-vec00272-001-s135><ask.bitten><en> "Referring to the joint prayers held by Catholic and Protestant Christians for the welfare of the fatherland the bishops ask the President to show ""fatherly love"" in the current tense situation - the English text reads: ""commotion"" -, to find so a peaceful solution to the problems, so that stability, peace and non-violence can be restored. Preferential Treatment for Buddhism"
<G-vec00272-001-s135><ask.bitten><de> "Mit Verweis auf die gemeinsamen Gebete, die katholische und protestantische Christen für das Wohl des Vaterlandes gehalten haben, bitten die Bischöfe, in der gegenwärtigen angespannten Situation - im englischen Text heißt es: ""commotion"" - den Präsidenten darum, ""väterliche Liebe"" zu zeigen, um eine friedliche Lösung der Probleme herbeizuführen, damit Stabilität, Friede und Gewaltlosigkeit wieder hergestellt werden können."
<G-vec00272-001-s136><ask.bitten><en> We do ask that you please attempt to resolve any issues with us first, although you have a right to contact your supervisory authority at any time.
<G-vec00272-001-s136><ask.bitten><de> Wir bitten Sie inständig darum, zunächst eine Lösung bestehender Probleme mit uns anzustreben, auch wenn Sie jderzeit das Recht haben, die für Sie zuständige Aufsichtsbehörde zu kontaktieren.
<G-vec00272-001-s137><ask.bitten><en> – For this pain and this joy, We ask that our homes are homes bright because it is God and cheerful because we trust in the Lord.
<G-vec00272-001-s137><ask.bitten><de> – Für diesen Schmerz und diese Freude, Wir bitten darum, dass unsere Häuser Häuser sind hell denn es ist Gott und heiter weil wir auf den Herrn vertrauen.
<G-vec00272-001-s138><ask.bitten><en> We ask that groups please choose from our group menu in advance for faster service.
<G-vec00272-001-s138><ask.bitten><de> Wir bitten die Gruppen darum, die gewünschten Speisen aus unserem Gruppenmenü für einen schnelleren Kundenservice auszuwählen.
<G-vec00272-001-s139><ask.bitten><en> If you don't consent to the aforementioned conditions, we kindly ask you to consider one of the other donation options outlined on this page.
<G-vec00272-001-s139><ask.bitten><de> Falls Sie mit diesen Einschränkungen nicht einverstanden sind, bitten wir darum, eine andere auf dieser Seite genannte Spendenmöglichkeit zu nutzen.
<G-vec00272-001-s140><ask.bitten><en> """We would like to ask you to advocate for a dialogue between the government and the Mapuche, mediated by the Bishop of Temuco."
<G-vec00272-001-s140><ask.bitten><de> Wir bitten Sie sehr herzlich darum, den Dialog zwischen Regierung und Mapuche, in dem der Bischof von Temuco vermitteln soll, zu unterstützen.
<G-vec00272-001-s141><ask.bitten><en> We would also like to ask you to let us know as long as possible in advance - ideally about two months before the conference commences.
<G-vec00272-001-s141><ask.bitten><de> Wir bitten Sie darum, uns über Ihrem Auftrag im Voraus zu informieren, damit wir unseren Druckplan anpassen können - idealerweise zwei Monate vorher.
<G-vec00272-001-s142><ask.bitten><en> Whenever we ask you for information, it is to better serve you: If we don't need it, we won't ask for it. 2.
<G-vec00272-001-s142><ask.bitten><de> Wann immer wir Sie um Informationen bitten, tun wir das nur, um Ihnen einen besseren Dienst anbieten zu können: Wenn wir die Informationen nicht benötigen, bitten wir Sie auch nicht darum.
<G-vec00272-001-s143><ask.bitten><en> Since Christ died for us out of love, when we celebrate the memorial of his death at the moment of sacrifice we ask that love may be granted to us by the coming of the Holy Spirit.
<G-vec00272-001-s143><ask.bitten><de> „Da Christus aus Liebe für uns gestorben ist, bitten wir, wenn wir das Gedächtnis an seinen Tod halten, im Moment des Opfers darum, daß durch das Kommen des Heiligen Geistes uns die Liebe gewährt werde.
<G-vec00272-001-s144><ask.bitten><en> In future PANArt's tuners will dedicate their energy completely to the refinement of their new musical instrument Gubal . Therefor they ask, not to send requests for a Free Integral Hang any longer.
<G-vec00272-001-s144><ask.bitten><de> Sie wollen sich ganz auf die Verfeinerung ihres neuen Instruments Gubal konzentrieren und bitten daher darum, keine Anfragen nach einem Hang mehr zu schicken.
<G-vec00272-001-s145><ask.bitten><en> Where local laws are less strict we promote higher standards generally, as well as a level competitive playing field, and ask governments to embody our Principles or similar provisions into local law.
<G-vec00272-001-s145><ask.bitten><de> Wenn lokale Gesetze weniger streng sind, fördern wir im Allgemeinen höhere Standards sowie gleiche Wettbewerbsbedingungen, und bitten Regierungen darum, unsere Grundlagen oder ähnliche Bestimmungen in das örtliche Gesetz einzubinden.
<G-vec00272-001-s146><ask.bitten><en> This time, we ask that you travel with us through the thick forests of ancient trees where we once roamed with you or watched you.
<G-vec00272-001-s146><ask.bitten><de> Dieses Mal bitten wir euch darum, mit uns durch die dichten Wälder aus altvorderen Bäumen zu reisen, die wir einst zusammen durchstreifen oder euch beobachteten.
<G-vec00272-001-s147><ask.bitten><en> We ask that the WOW-Day contact person at your school sends us (the Friends of Waldorf Education) a list of names, addresses and respective amounts of donors who want to receive a donation receipt.
<G-vec00272-001-s147><ask.bitten><de> Hier bitten wir darum, dass der WOW-Day Ansprechpartner Eurer Schule uns, den Freunden der Erziehungskunst, eine Liste mit Namen, Adressen und jeweiligen Beträgen der Spender, die eine Spendenquittung wünschen, senden.
<G-vec00272-001-s148><ask.bitten><en> We would ask you to be ready to leave by 9 a.m. on the day of your discharge so that new patients may move into your room as quickly as possible.
<G-vec00272-001-s148><ask.bitten><de> Wir bitten Sie darum, um 9:00 Uhr morgens am Tag Ihrer Entlassung abreisefertig zu sein, damit die neuen Patienten schnellstmöglich ihr Zimmer beziehen können.
<G-vec00272-001-s149><ask.bitten><en> Second, concrete initiatives are indicated for the protection and social re-integration of the victims of trafficking, in particular for those that ask for help to exit their context of exploitation and enslavement.
<G-vec00272-001-s149><ask.bitten><de> An zweiter Stelle seien konkrete Initiativen zum Schutz der Opfer des Handels notwendig, insbesondere für diejenigen, die um Hilfe bitten, wenn es darum geht aus dem Kontext der Ausbeutung und Sklaverei herauszukommen.
<G-vec00272-001-s150><ask.bitten><en> Even if you’re notified of the delay before you arrive at the airport, we ask you to check in on time (according to your original flight time), unless advised otherwise.
<G-vec00272-001-s150><ask.bitten><de> Auch wenn Sie vor Ihrer Ankunft am Flughafen über die Verspätung informiert wurden, bitten wir Sie darum, pünktlich einzuchecken (entsprechend der ursprünglichen Abflugzeit), sofern nichts anderes angegeben wurde.
<G-vec00272-001-s151><ask.bitten><en> Should a linking not function, we ask for the fact that one announces this mistake to us. .
<G-vec00272-001-s151><ask.bitten><de> Sollte eine Verknüpfung nicht funktionieren, bitten wir darum, dass man uns diesen Fehler meldet.
<G-vec00384-001-s133><ask.bitten><en> You should also ask your doctor to check the compatibility of the drugs you may be taking with Kamagra Polo. Known interactions include such medications as nitroglycerin drugs, nitroprusside medicines, amyl nitrate, azole antifungal drugs and others.
<G-vec00384-001-s133><ask.bitten><de> Bitten Sie Ihren Arzt auch darum, die Kompatibilität von Kamagra Polo mit anderen Arzneimitteln zu prüfen, welche Sie gleichzeitig mit Kamagra Polo einnehmen können.
<G-vec00384-001-s134><ask.bitten><en> All the forces of the heavenly dimension are at our disposal, provided that we ask in accordance with God’s perfect will.
<G-vec00384-001-s134><ask.bitten><de> Uns stehen alle Kräfte der himmlischen He-Dimension zu Gebot, vorausgesetzt, wir bitten darum im Einklang mit dem vollkommenen Willen Gottes.
<G-vec00384-001-s135><ask.bitten><en> "Referring to the joint prayers held by Catholic and Protestant Christians for the welfare of the fatherland the bishops ask the President to show ""fatherly love"" in the current tense situation - the English text reads: ""commotion"" -, to find so a peaceful solution to the problems, so that stability, peace and non-violence can be restored. Preferential Treatment for Buddhism"
<G-vec00384-001-s135><ask.bitten><de> "Mit Verweis auf die gemeinsamen Gebete, die katholische und protestantische Christen für das Wohl des Vaterlandes gehalten haben, bitten die Bischöfe, in der gegenwärtigen angespannten Situation - im englischen Text heißt es: ""commotion"" - den Präsidenten darum, ""väterliche Liebe"" zu zeigen, um eine friedliche Lösung der Probleme herbeizuführen, damit Stabilität, Friede und Gewaltlosigkeit wieder hergestellt werden können."
<G-vec00384-001-s136><ask.bitten><en> We do ask that you please attempt to resolve any issues with us first, although you have a right to contact your supervisory authority at any time.
<G-vec00384-001-s136><ask.bitten><de> Wir bitten Sie inständig darum, zunächst eine Lösung bestehender Probleme mit uns anzustreben, auch wenn Sie jderzeit das Recht haben, die für Sie zuständige Aufsichtsbehörde zu kontaktieren.
<G-vec00384-001-s137><ask.bitten><en> – For this pain and this joy, We ask that our homes are homes bright because it is God and cheerful because we trust in the Lord.
<G-vec00384-001-s137><ask.bitten><de> – Für diesen Schmerz und diese Freude, Wir bitten darum, dass unsere Häuser Häuser sind hell denn es ist Gott und heiter weil wir auf den Herrn vertrauen.
<G-vec00384-001-s138><ask.bitten><en> We ask that groups please choose from our group menu in advance for faster service.
<G-vec00384-001-s138><ask.bitten><de> Wir bitten die Gruppen darum, die gewünschten Speisen aus unserem Gruppenmenü für einen schnelleren Kundenservice auszuwählen.
<G-vec00384-001-s139><ask.bitten><en> If you don't consent to the aforementioned conditions, we kindly ask you to consider one of the other donation options outlined on this page.
<G-vec00384-001-s139><ask.bitten><de> Falls Sie mit diesen Einschränkungen nicht einverstanden sind, bitten wir darum, eine andere auf dieser Seite genannte Spendenmöglichkeit zu nutzen.
<G-vec00384-001-s140><ask.bitten><en> """We would like to ask you to advocate for a dialogue between the government and the Mapuche, mediated by the Bishop of Temuco."
<G-vec00384-001-s140><ask.bitten><de> Wir bitten Sie sehr herzlich darum, den Dialog zwischen Regierung und Mapuche, in dem der Bischof von Temuco vermitteln soll, zu unterstützen.
<G-vec00384-001-s141><ask.bitten><en> We would also like to ask you to let us know as long as possible in advance - ideally about two months before the conference commences.
<G-vec00384-001-s141><ask.bitten><de> Wir bitten Sie darum, uns über Ihrem Auftrag im Voraus zu informieren, damit wir unseren Druckplan anpassen können - idealerweise zwei Monate vorher.
<G-vec00384-001-s142><ask.bitten><en> Whenever we ask you for information, it is to better serve you: If we don't need it, we won't ask for it. 2.
<G-vec00384-001-s142><ask.bitten><de> Wann immer wir Sie um Informationen bitten, tun wir das nur, um Ihnen einen besseren Dienst anbieten zu können: Wenn wir die Informationen nicht benötigen, bitten wir Sie auch nicht darum.
<G-vec00384-001-s143><ask.bitten><en> Since Christ died for us out of love, when we celebrate the memorial of his death at the moment of sacrifice we ask that love may be granted to us by the coming of the Holy Spirit.
<G-vec00384-001-s143><ask.bitten><de> „Da Christus aus Liebe für uns gestorben ist, bitten wir, wenn wir das Gedächtnis an seinen Tod halten, im Moment des Opfers darum, daß durch das Kommen des Heiligen Geistes uns die Liebe gewährt werde.
<G-vec00384-001-s144><ask.bitten><en> In future PANArt's tuners will dedicate their energy completely to the refinement of their new musical instrument Gubal . Therefor they ask, not to send requests for a Free Integral Hang any longer.
<G-vec00384-001-s144><ask.bitten><de> Sie wollen sich ganz auf die Verfeinerung ihres neuen Instruments Gubal konzentrieren und bitten daher darum, keine Anfragen nach einem Hang mehr zu schicken.
<G-vec00384-001-s145><ask.bitten><en> Where local laws are less strict we promote higher standards generally, as well as a level competitive playing field, and ask governments to embody our Principles or similar provisions into local law.
<G-vec00384-001-s145><ask.bitten><de> Wenn lokale Gesetze weniger streng sind, fördern wir im Allgemeinen höhere Standards sowie gleiche Wettbewerbsbedingungen, und bitten Regierungen darum, unsere Grundlagen oder ähnliche Bestimmungen in das örtliche Gesetz einzubinden.
<G-vec00384-001-s146><ask.bitten><en> This time, we ask that you travel with us through the thick forests of ancient trees where we once roamed with you or watched you.
<G-vec00384-001-s146><ask.bitten><de> Dieses Mal bitten wir euch darum, mit uns durch die dichten Wälder aus altvorderen Bäumen zu reisen, die wir einst zusammen durchstreifen oder euch beobachteten.
<G-vec00384-001-s147><ask.bitten><en> We ask that the WOW-Day contact person at your school sends us (the Friends of Waldorf Education) a list of names, addresses and respective amounts of donors who want to receive a donation receipt.
<G-vec00384-001-s147><ask.bitten><de> Hier bitten wir darum, dass der WOW-Day Ansprechpartner Eurer Schule uns, den Freunden der Erziehungskunst, eine Liste mit Namen, Adressen und jeweiligen Beträgen der Spender, die eine Spendenquittung wünschen, senden.
<G-vec00384-001-s148><ask.bitten><en> We would ask you to be ready to leave by 9 a.m. on the day of your discharge so that new patients may move into your room as quickly as possible.
<G-vec00384-001-s148><ask.bitten><de> Wir bitten Sie darum, um 9:00 Uhr morgens am Tag Ihrer Entlassung abreisefertig zu sein, damit die neuen Patienten schnellstmöglich ihr Zimmer beziehen können.
<G-vec00384-001-s149><ask.bitten><en> Second, concrete initiatives are indicated for the protection and social re-integration of the victims of trafficking, in particular for those that ask for help to exit their context of exploitation and enslavement.
<G-vec00384-001-s149><ask.bitten><de> An zweiter Stelle seien konkrete Initiativen zum Schutz der Opfer des Handels notwendig, insbesondere für diejenigen, die um Hilfe bitten, wenn es darum geht aus dem Kontext der Ausbeutung und Sklaverei herauszukommen.
<G-vec00384-001-s150><ask.bitten><en> Even if you’re notified of the delay before you arrive at the airport, we ask you to check in on time (according to your original flight time), unless advised otherwise.
<G-vec00384-001-s150><ask.bitten><de> Auch wenn Sie vor Ihrer Ankunft am Flughafen über die Verspätung informiert wurden, bitten wir Sie darum, pünktlich einzuchecken (entsprechend der ursprünglichen Abflugzeit), sofern nichts anderes angegeben wurde.
<G-vec00384-001-s151><ask.bitten><en> Should a linking not function, we ask for the fact that one announces this mistake to us. .
<G-vec00384-001-s151><ask.bitten><de> Sollte eine Verknüpfung nicht funktionieren, bitten wir darum, dass man uns diesen Fehler meldet.
<G-vec00272-001-s152><ask.bitten><en> Ask the designer of the logo into a digital format and send to us by email.
<G-vec00272-001-s152><ask.bitten><de> Bitten Sie den Designer des Logos in ein digitales Format und senden Sie uns per E-Mail.
<G-vec00272-001-s153><ask.bitten><en> However, all you have to do is pull the sales clerk aside, and ask them to allow you to have just a quick whiff of Adrienne Vittadini perfume on a paper blotter.
<G-vec00272-001-s153><ask.bitten><de> Alles, was Sie tun müssen, ist jedoch ziehen die Verkäufe Angestellte beiseite, und bitten Sie sie, Sie haben gerade einen schnellen Hauch von Adrienne Vittadini Parfüm auf ein Papier-Blotter können.
<G-vec00272-001-s154><ask.bitten><en> Â In this technique first connect with the Universal Energy and ask for help detoxify your body.
<G-vec00272-001-s154><ask.bitten><de> Bei dieser Technik wird zunächst eine Verbindung mit der universellen Energie und um Hilfe bitten entgiften Sie Ihren Körper.
<G-vec00272-001-s155><ask.bitten><en> Control NR1609 with your voice and Amazon Alexa — download the HEOS Home Entertainment skill and ask Alexa to play, pause or stop music, switch inputs for your different media players, turn up the volume and more. Key Features
<G-vec00272-001-s155><ask.bitten><de> Steuern Sie den NR1609 per Amazon Alexa-Sprachsteuerung - laden Sie die HEOS Home Entertainment Skill runter und bitten Sie Alexa, Musik abzuspielen, zu pausieren oder abzuschalten, wechseln Sie die Eingänge für Ihre verschiedenen Media Player, erhöhen Sie die Lautstärke und vieles mehr.
<G-vec00272-001-s156><ask.bitten><en> We therefore ask for your patience.
<G-vec00272-001-s156><ask.bitten><de> Wir bitten Sie daher um Ihr Verständnis.
<G-vec00272-001-s157><ask.bitten><en> Explicitly ask that person to share your petition.
<G-vec00272-001-s157><ask.bitten><de> Bitten Sie diese Person ausdrücklich, Ihre Petition zu verbreiten.
<G-vec00272-001-s158><ask.bitten><en> Ask him to bring you at Godowlia crossing and then from there ask anyone where is the Golden Temple or the famous Vishwanath Gali?When you are nearby here, you can ask anyone where is the Monu Guest House.
<G-vec00272-001-s158><ask.bitten><de> Bitten Sie ihn, Sie an der Kreuzung Godowlia bringen und dann von dort jemanden fragen, wo die Golden Temple oder die berühmte Vishwanath Gali ist?Wenn Sie befinden sich hier in der Nähe, können Sie jeden fragen, wo die Monu Guest House ist.
<G-vec00272-001-s159><ask.bitten><en> Have a try if you are traveling and want to buy a coffee to go: Submit your waitress or waiter a clean JOCO Cup and ask them to fill the organic coffee or tea in your packed vessel.
<G-vec00272-001-s159><ask.bitten><de> Probieren Sie es doch einfach mal aus, wenn Sie unterwegs sind und sich einen Coffee to go kaufen wollen: Reichen Sie der Bedienung Ihren sauberen JOCO Cup und bitten Sie sie, den Bio Kaffee oder Tee in Ihr mitgebrachtes Gefäß zu füllen.
<G-vec00272-001-s160><ask.bitten><en> It's possible to control the versions activities and ask her to watch your cam.
<G-vec00272-001-s160><ask.bitten><de> Es ist möglich zu Steuern, welche Versionen Aktivitäten und bitten Sie Sie, um zu sehen wie die cam.
<G-vec00272-001-s161><ask.bitten><en> We ask for your understanding that due to the limited capacity table at our gourmet restaurant in advance reservation is recommended.
<G-vec00272-001-s161><ask.bitten><de> Wir bitten Sie um Ihr Verständnis, dass aufgrund der begrenzten Tischkapazität in unserem Gourmetrestaurant eine vorherige Reservierung empfehlenswert ist.
<G-vec00272-001-s162><ask.bitten><en> "Introduce the technical term ""trajectory"".Step 4: (homework) Distribute the worksheets on money tracking and ask the pupils to allot the collected coins."
<G-vec00272-001-s162><ask.bitten><de> Führen Sie den Begriff der Trajektorien ein.Schritt 4: (Hausaufgabe) Teilen Sie die Arbeitsblätter zur Geldverteilung aus und bitten Sie die Schüler, die gesammelten Münzen zuzuordnen.
<G-vec00272-001-s163><ask.bitten><en> So in speaking to an upright Jew who really loves God with all his heart and all his soul and all his might, we can only give the following advice: just give your heart a jog, and go into a room where you can be undisturbed for the next half an hour and speak there in your spirit with the Eternal, with your God, and ask him to give you wisdom and understanding so that you may recognize the truth, the real truth.
<G-vec00272-001-s163><ask.bitten><de> Daher kann man dem aufrichtigen Juden, der Gott tatsächlich liebt mit seinem ganzen Herzen und mit seiner ganzen Seele und mit seiner ganzen Kraft, nur raten: geben Sie Ihrem Herzen einen Stoß und gehen Sie in einen Raum, in welchem Sie die nächste halbe Stunde ungestört sind und sprechen Sie dort in Ihrem Geist mit dem Ewigen, Ihrem Gott und bitten Sie ihn, dass er Ihnen Weisheit und Erkenntnis geben möge, damit Sie die Wahrheit – die echte Wahrheit – erkennen.
<G-vec00272-001-s164><ask.bitten><en> It is therefore up to the discretion of the student to determine if slowing down on their course would be acceptable to their circumstances.Finally, always ask for a hotline number from the online college that you are planning to enroll in.
<G-vec00272-001-s164><ask.bitten><de> Es ist folglich bis zur Diskretion des Kursteilnehmers, zum wenn das Verlangsamen festzustellen, auf ihrem Kurs für ihre Umstände annehmbar sein würde.Schließlich bitten Sie immer um eine Hotlinezahl von der on-line-Hochschule, daß Sie planen, innen einzuschreiben.
<G-vec00272-001-s165><ask.bitten><en> Ask the bookseller to help you.
<G-vec00272-001-s165><ask.bitten><de> Bitten Sie den Buchhändler, Ihnen zu helfen.
<G-vec00272-001-s166><ask.bitten><en> If is not present — ask phone number of the attending physician.
<G-vec00272-001-s166><ask.bitten><de> Wenn gibt es — bitten Sie die Rufnummer des behandelnden Arztes.
<G-vec00272-001-s167><ask.bitten><en> Ask the person which handwriting very much is pleasant to you, to write the short text on paper.
<G-vec00272-001-s167><ask.bitten><de> Bitten Sie den Menschen, dessen Handschrift Ihnen sehr gefällt, auf dem Papier den kurzen Text zu schreiben.
<G-vec00272-001-s168><ask.bitten><en> Afterwards, please reply to your thread in translators@lists.fsfe.org and ask other people to proofread your file.
<G-vec00272-001-s168><ask.bitten><de> Danach antworten Sie bitte auf Ihre eigene Mail in translators@lists.fsfe.org und bitten Sie andere Leute, Ihre Übersetzung gegenzulesen.
<G-vec00272-001-s169><ask.bitten><en> 3-hour parking tickets are available at the reception desk, and feel free to ask our staff to change the parking ticket every 3 hours for you if you are away from the hotel.
<G-vec00272-001-s169><ask.bitten><de> 3 Stunden Parkscheine sind an der Rezeption erhältlich und bitten Sie unser Personal ruhig, Ihren Parkschein jede dritte Stunde zu tauschen, wenn Sie von dem Hotel weg sind.
<G-vec00272-001-s170><ask.bitten><en> Deactivate the software or ask your system administrator to deactivate it.
<G-vec00272-001-s170><ask.bitten><de> Deaktivieren Sie diese Software oder bitten Sie Ihren Systemadministrator sie zu deaktivieren.
<G-vec00384-001-s152><ask.bitten><en> Ask the designer of the logo into a digital format and send to us by email.
<G-vec00384-001-s152><ask.bitten><de> Bitten Sie den Designer des Logos in ein digitales Format und senden Sie uns per E-Mail.
<G-vec00384-001-s153><ask.bitten><en> However, all you have to do is pull the sales clerk aside, and ask them to allow you to have just a quick whiff of Adrienne Vittadini perfume on a paper blotter.
<G-vec00384-001-s153><ask.bitten><de> Alles, was Sie tun müssen, ist jedoch ziehen die Verkäufe Angestellte beiseite, und bitten Sie sie, Sie haben gerade einen schnellen Hauch von Adrienne Vittadini Parfüm auf ein Papier-Blotter können.
<G-vec00384-001-s154><ask.bitten><en> Â In this technique first connect with the Universal Energy and ask for help detoxify your body.
<G-vec00384-001-s154><ask.bitten><de> Bei dieser Technik wird zunächst eine Verbindung mit der universellen Energie und um Hilfe bitten entgiften Sie Ihren Körper.
<G-vec00384-001-s155><ask.bitten><en> Control NR1609 with your voice and Amazon Alexa — download the HEOS Home Entertainment skill and ask Alexa to play, pause or stop music, switch inputs for your different media players, turn up the volume and more. Key Features
<G-vec00384-001-s155><ask.bitten><de> Steuern Sie den NR1609 per Amazon Alexa-Sprachsteuerung - laden Sie die HEOS Home Entertainment Skill runter und bitten Sie Alexa, Musik abzuspielen, zu pausieren oder abzuschalten, wechseln Sie die Eingänge für Ihre verschiedenen Media Player, erhöhen Sie die Lautstärke und vieles mehr.
<G-vec00384-001-s156><ask.bitten><en> We therefore ask for your patience.
<G-vec00384-001-s156><ask.bitten><de> Wir bitten Sie daher um Ihr Verständnis.
<G-vec00384-001-s157><ask.bitten><en> Explicitly ask that person to share your petition.
<G-vec00384-001-s157><ask.bitten><de> Bitten Sie diese Person ausdrücklich, Ihre Petition zu verbreiten.
<G-vec00384-001-s158><ask.bitten><en> Ask him to bring you at Godowlia crossing and then from there ask anyone where is the Golden Temple or the famous Vishwanath Gali?When you are nearby here, you can ask anyone where is the Monu Guest House.
<G-vec00384-001-s158><ask.bitten><de> Bitten Sie ihn, Sie an der Kreuzung Godowlia bringen und dann von dort jemanden fragen, wo die Golden Temple oder die berühmte Vishwanath Gali ist?Wenn Sie befinden sich hier in der Nähe, können Sie jeden fragen, wo die Monu Guest House ist.
<G-vec00384-001-s159><ask.bitten><en> Have a try if you are traveling and want to buy a coffee to go: Submit your waitress or waiter a clean JOCO Cup and ask them to fill the organic coffee or tea in your packed vessel.
<G-vec00384-001-s159><ask.bitten><de> Probieren Sie es doch einfach mal aus, wenn Sie unterwegs sind und sich einen Coffee to go kaufen wollen: Reichen Sie der Bedienung Ihren sauberen JOCO Cup und bitten Sie sie, den Bio Kaffee oder Tee in Ihr mitgebrachtes Gefäß zu füllen.
<G-vec00384-001-s160><ask.bitten><en> It's possible to control the versions activities and ask her to watch your cam.
<G-vec00384-001-s160><ask.bitten><de> Es ist möglich zu Steuern, welche Versionen Aktivitäten und bitten Sie Sie, um zu sehen wie die cam.
<G-vec00384-001-s161><ask.bitten><en> We ask for your understanding that due to the limited capacity table at our gourmet restaurant in advance reservation is recommended.
<G-vec00384-001-s161><ask.bitten><de> Wir bitten Sie um Ihr Verständnis, dass aufgrund der begrenzten Tischkapazität in unserem Gourmetrestaurant eine vorherige Reservierung empfehlenswert ist.
<G-vec00384-001-s162><ask.bitten><en> "Introduce the technical term ""trajectory"".Step 4: (homework) Distribute the worksheets on money tracking and ask the pupils to allot the collected coins."
<G-vec00384-001-s162><ask.bitten><de> Führen Sie den Begriff der Trajektorien ein.Schritt 4: (Hausaufgabe) Teilen Sie die Arbeitsblätter zur Geldverteilung aus und bitten Sie die Schüler, die gesammelten Münzen zuzuordnen.
<G-vec00384-001-s163><ask.bitten><en> So in speaking to an upright Jew who really loves God with all his heart and all his soul and all his might, we can only give the following advice: just give your heart a jog, and go into a room where you can be undisturbed for the next half an hour and speak there in your spirit with the Eternal, with your God, and ask him to give you wisdom and understanding so that you may recognize the truth, the real truth.
<G-vec00384-001-s163><ask.bitten><de> Daher kann man dem aufrichtigen Juden, der Gott tatsächlich liebt mit seinem ganzen Herzen und mit seiner ganzen Seele und mit seiner ganzen Kraft, nur raten: geben Sie Ihrem Herzen einen Stoß und gehen Sie in einen Raum, in welchem Sie die nächste halbe Stunde ungestört sind und sprechen Sie dort in Ihrem Geist mit dem Ewigen, Ihrem Gott und bitten Sie ihn, dass er Ihnen Weisheit und Erkenntnis geben möge, damit Sie die Wahrheit – die echte Wahrheit – erkennen.
<G-vec00384-001-s164><ask.bitten><en> It is therefore up to the discretion of the student to determine if slowing down on their course would be acceptable to their circumstances.Finally, always ask for a hotline number from the online college that you are planning to enroll in.
<G-vec00384-001-s164><ask.bitten><de> Es ist folglich bis zur Diskretion des Kursteilnehmers, zum wenn das Verlangsamen festzustellen, auf ihrem Kurs für ihre Umstände annehmbar sein würde.Schließlich bitten Sie immer um eine Hotlinezahl von der on-line-Hochschule, daß Sie planen, innen einzuschreiben.
<G-vec00384-001-s165><ask.bitten><en> Ask the bookseller to help you.
<G-vec00384-001-s165><ask.bitten><de> Bitten Sie den Buchhändler, Ihnen zu helfen.
<G-vec00384-001-s166><ask.bitten><en> If is not present — ask phone number of the attending physician.
<G-vec00384-001-s166><ask.bitten><de> Wenn gibt es — bitten Sie die Rufnummer des behandelnden Arztes.
<G-vec00384-001-s167><ask.bitten><en> Ask the person which handwriting very much is pleasant to you, to write the short text on paper.
<G-vec00384-001-s167><ask.bitten><de> Bitten Sie den Menschen, dessen Handschrift Ihnen sehr gefällt, auf dem Papier den kurzen Text zu schreiben.
<G-vec00384-001-s168><ask.bitten><en> Afterwards, please reply to your thread in translators@lists.fsfe.org and ask other people to proofread your file.
<G-vec00384-001-s168><ask.bitten><de> Danach antworten Sie bitte auf Ihre eigene Mail in translators@lists.fsfe.org und bitten Sie andere Leute, Ihre Übersetzung gegenzulesen.
<G-vec00384-001-s169><ask.bitten><en> 3-hour parking tickets are available at the reception desk, and feel free to ask our staff to change the parking ticket every 3 hours for you if you are away from the hotel.
<G-vec00384-001-s169><ask.bitten><de> 3 Stunden Parkscheine sind an der Rezeption erhältlich und bitten Sie unser Personal ruhig, Ihren Parkschein jede dritte Stunde zu tauschen, wenn Sie von dem Hotel weg sind.
<G-vec00384-001-s170><ask.bitten><en> Deactivate the software or ask your system administrator to deactivate it.
<G-vec00384-001-s170><ask.bitten><de> Deaktivieren Sie diese Software oder bitten Sie Ihren Systemadministrator sie zu deaktivieren.
<G-vec00272-001-s171><ask.bitten><en> According to Scripture, one is to return what is stolen and to ask the forgiveness of the wronged person, and naturally that of God as well.
<G-vec00272-001-s171><ask.bitten><de> Biblisch ist, daß man gestohlenes Gut zurückgibt und den Geschädigten und selbstverständlich auch Gott um Vergebung bittet.
<G-vec00272-001-s172><ask.bitten><en> Do ask the Lord to make more clear to you what it involves, and let us ask the Lord very much that there may be literal expressions of His heavenly house found more and more widely on this earth.
<G-vec00272-001-s172><ask.bitten><de> Bittet den Herrn, er möge euch noch klarer machen, was alles daraus folgt, und bittet den Herrn sehr stark, dass es auf dieser Erde mehr und mehr einen buchstäblichen Ausdruck seiner himmlischen Ordnung geben möge.
<G-vec00272-001-s173><ask.bitten><en> Do ask the Lord to make more clear to you what it involves, and let us ask the Lord very much that there may be literal expressions of His heavenly house found more and more widely on this earth.
<G-vec00272-001-s173><ask.bitten><de> Bittet den Herrn, er möge euch noch klarer machen, was alles daraus folgt, und bittet den Herrn sehr stark, dass es auf dieser Erde mehr und mehr einen buchstäblichen Ausdruck seiner himmlischen Ordnung geben möge.
<G-vec00272-001-s174><ask.bitten><en> In the spirit of the Jubilee, you give thanks to God for the good he has wrought and, at the same time, you ask his forgiveness for the failings that may have marked the life of your religious families.
<G-vec00272-001-s174><ask.bitten><de> Im Geist des Jubiläums sagt ihr Gott Dank für das vollbrachte Gute und bittet zugleich um Vergebung für die möglichen Unzulänglichkeiten, die das Leben eurer Ordensfamilien gezeichnet haben.
<G-vec00272-001-s175><ask.bitten><en> "So I say, brethren, pray over it, think over it, and ask the Lord to make it all true where you are""!"
<G-vec00272-001-s175><ask.bitten><de> So sage ich, ihr Brüder: Betet darüber, denkt darüber nach, und bittet den Herrn, es überall dort wahr zu machen, wo ihr seid».
<G-vec00272-001-s176><ask.bitten><en> 7 Ask, and it shall be given to you. Seek, and you shall find. Knock, and it shall be opened to you.
<G-vec00272-001-s176><ask.bitten><de> 7 Bittet, so wird euch gegeben; suchet, so werdet ihr finden; klopfet an, so wird euch aufgetan.
<G-vec00272-001-s177><ask.bitten><en> If you ask them they'll give you £10, but don't wake them up in the morning, because if they have to do dhyana in the morning is horrible, then if you ask them to take a bath, that's the worst of all!
<G-vec00272-001-s177><ask.bitten><de> Wenn ihr sie danach fragt, geben sie euch 10 Pfund, aber weckt sie nicht auf am Morgen, denn wenn sie am Morgen Dhyana (Meditation) tun sollen, das ist schrecklich, aber wenn ihr sie bittet, ein Bad zu nehmen, ist das das Schlimmste überhaupt.
<G-vec00272-001-s178><ask.bitten><en> So, Anil thinks that he will make a friendship with some bully guy and ask him for the help.
<G-vec00272-001-s178><ask.bitten><de> So denkt Anil, daß er eine Freundschaft mit irgendeinem Tyrannkerl bildet und ihn um die Hilfe bittet.
<G-vec00272-001-s179><ask.bitten><en> Whoever is wise will ask the Lord to cause all this fruit to come to maturity in him.
<G-vec00272-001-s179><ask.bitten><de> Wer weise ist, bittet den Herrn, dass er alle diese Früchte in ihm zur Reife bringe.
<G-vec00272-001-s180><ask.bitten><en> Before you start the battle, Elizabeth will ask you to send your party members back.
<G-vec00272-001-s180><ask.bitten><de> Bevor du die Schlacht anfängst, bittet Elisabeth dich, deine Partie-Mitglieder zurück zu schicken.
<G-vec00272-001-s181><ask.bitten><en> Lead a life in unselfish neighbourly love, and remember me on many occasions; consciously connect yourselves with me, and ask me for my help, and also earthly you will no longer need to worry, because then I care for you.
<G-vec00272-001-s181><ask.bitten><de> Führet ein Leben in uneigennütziger Nächstenliebe, und gedenket des öfteren Meiner, verbindet euch bewußt mit Mir, und bittet Mich um Meinen Beistand, und ihr werdet euch auch irdisch nicht mehr zu sorgen brauchen, denn dann sorge Ich für euch.
<G-vec00272-001-s182><ask.bitten><en> "9 ""So I say to you: Ask and it will be given to you; seek and you will find; knock and the door will be opened to you."
<G-vec00272-001-s182><ask.bitten><de> Luk 11:9 So sage ich euch: Bittet, dann wird euch gegeben; sucht, dann werdet ihr finden; klopft an, dann wird euch aufgetan.
<G-vec00272-001-s183><ask.bitten><en> 9 And I say to you, ask, and it will be given to you; seek, and you will find; knock, and it will be opened to you.
<G-vec00272-001-s183><ask.bitten><de> 9 Und ich sage euch auch: Bittet, so wird euch gegeben; suchet, so werdet ihr finden; klopfet an, so wird euch aufgetan.
<G-vec00272-001-s184><ask.bitten><en> Ask for forgiveness, and recount how you have sinned against them, ask for pardon.
<G-vec00272-001-s184><ask.bitten><de> Bittet auch darum, dass sie euch vergeben und zählt auf, wie ihr gegen sie gesündigt habt, bittet um Entschuldigung.
<G-vec00272-001-s185><ask.bitten><en> The Prince Estate is not the first to ask Trump to stop using their music during his rallies.
<G-vec00272-001-s185><ask.bitten><de> The Prince Estate ist nicht der erste, der Trump bittet, ihre Musik während seiner Kundgebungen nicht mehr zu verwenden.
<G-vec00272-001-s186><ask.bitten><en> Towards the end of the research stay, the Alexander von Humboldt Foundation will ask award winners for a brief, informal report on their experiences, which should also contain information on the academic collaboration with the host institution and contacts with other research institutions in Germany and abroad. They will also be asked to comment on their own and their families' personal impressions during their stay in Germany.
<G-vec00272-001-s186><ask.bitten><de> Gegen Ende des Forschungsaufenthaltes bittet die Alexander von Humboldt- Stiftung die Preisträger um einen kurzen, informellen Erfahrungsbericht, der auch Informationen über die wissenschaftliche Zusammenarbeit mit dem Gastinstitut, über die Kontakte zu anderen Forschungsinstitutionen in Deutschland und im Ausland sowie über die persönlichen Eindrücke der Preisträger und ihrer Familien während des Aufenthaltes in Deutschland enthalten sollte.
<G-vec00272-001-s187><ask.bitten><en> The Noah’s Animal Shelter want to ask everybody for NOT BEING UNINTERESTED.
<G-vec00272-001-s187><ask.bitten><de> Die NOAH Tierheim Stiftung bittet alle, nicht GLEICHGÜLTIG zu sein.
<G-vec00272-001-s188><ask.bitten><en> "Truly, truly I say to you, whatever you ask the Father in my name, He will give it to you...ask in my name; I am not saying I will pray to the Father for you, for the Father Himself loves you, because you have loved me..."" v23-27) That is the first thing we have in common with the Father - we both love Jesus."
<G-vec00272-001-s188><ask.bitten><de> Wahrlich, wahrlich ich sage euch, was immer ihr den Vater in meinem Namen bitten werdet, wird er euch geben... bittet in meinem Namen, ich sage nicht, dass ich für euch den Vater bitten werde, den der Vater selbst liebt euch, weil ihr mich geliebt habt (Verse 23-27) Die erste Sache, die wir mit dem Vater gemeinsam haben, ist, dass wir beide Jesus lieben.
<G-vec00272-001-s189><ask.bitten><en> But if you want to ask for stupidity, She cannot do it.
<G-vec00272-001-s189><ask.bitten><de> Wenn ihr aber um Dummheit bittet, diese kann sie euch nicht geben.
<G-vec00384-001-s171><ask.bitten><en> According to Scripture, one is to return what is stolen and to ask the forgiveness of the wronged person, and naturally that of God as well.
<G-vec00384-001-s171><ask.bitten><de> Biblisch ist, daß man gestohlenes Gut zurückgibt und den Geschädigten und selbstverständlich auch Gott um Vergebung bittet.
<G-vec00384-001-s172><ask.bitten><en> Do ask the Lord to make more clear to you what it involves, and let us ask the Lord very much that there may be literal expressions of His heavenly house found more and more widely on this earth.
<G-vec00384-001-s172><ask.bitten><de> Bittet den Herrn, er möge euch noch klarer machen, was alles daraus folgt, und bittet den Herrn sehr stark, dass es auf dieser Erde mehr und mehr einen buchstäblichen Ausdruck seiner himmlischen Ordnung geben möge.
<G-vec00384-001-s173><ask.bitten><en> Do ask the Lord to make more clear to you what it involves, and let us ask the Lord very much that there may be literal expressions of His heavenly house found more and more widely on this earth.
<G-vec00384-001-s173><ask.bitten><de> Bittet den Herrn, er möge euch noch klarer machen, was alles daraus folgt, und bittet den Herrn sehr stark, dass es auf dieser Erde mehr und mehr einen buchstäblichen Ausdruck seiner himmlischen Ordnung geben möge.
<G-vec00384-001-s174><ask.bitten><en> In the spirit of the Jubilee, you give thanks to God for the good he has wrought and, at the same time, you ask his forgiveness for the failings that may have marked the life of your religious families.
<G-vec00384-001-s174><ask.bitten><de> Im Geist des Jubiläums sagt ihr Gott Dank für das vollbrachte Gute und bittet zugleich um Vergebung für die möglichen Unzulänglichkeiten, die das Leben eurer Ordensfamilien gezeichnet haben.
<G-vec00384-001-s175><ask.bitten><en> "So I say, brethren, pray over it, think over it, and ask the Lord to make it all true where you are""!"
<G-vec00384-001-s175><ask.bitten><de> So sage ich, ihr Brüder: Betet darüber, denkt darüber nach, und bittet den Herrn, es überall dort wahr zu machen, wo ihr seid».
<G-vec00384-001-s176><ask.bitten><en> 7 Ask, and it shall be given to you. Seek, and you shall find. Knock, and it shall be opened to you.
<G-vec00384-001-s176><ask.bitten><de> 7 Bittet, so wird euch gegeben; suchet, so werdet ihr finden; klopfet an, so wird euch aufgetan.
<G-vec00384-001-s177><ask.bitten><en> If you ask them they'll give you £10, but don't wake them up in the morning, because if they have to do dhyana in the morning is horrible, then if you ask them to take a bath, that's the worst of all!
<G-vec00384-001-s177><ask.bitten><de> Wenn ihr sie danach fragt, geben sie euch 10 Pfund, aber weckt sie nicht auf am Morgen, denn wenn sie am Morgen Dhyana (Meditation) tun sollen, das ist schrecklich, aber wenn ihr sie bittet, ein Bad zu nehmen, ist das das Schlimmste überhaupt.
<G-vec00384-001-s178><ask.bitten><en> So, Anil thinks that he will make a friendship with some bully guy and ask him for the help.
<G-vec00384-001-s178><ask.bitten><de> So denkt Anil, daß er eine Freundschaft mit irgendeinem Tyrannkerl bildet und ihn um die Hilfe bittet.
<G-vec00384-001-s179><ask.bitten><en> Whoever is wise will ask the Lord to cause all this fruit to come to maturity in him.
<G-vec00384-001-s179><ask.bitten><de> Wer weise ist, bittet den Herrn, dass er alle diese Früchte in ihm zur Reife bringe.
<G-vec00384-001-s180><ask.bitten><en> Before you start the battle, Elizabeth will ask you to send your party members back.
<G-vec00384-001-s180><ask.bitten><de> Bevor du die Schlacht anfängst, bittet Elisabeth dich, deine Partie-Mitglieder zurück zu schicken.
<G-vec00384-001-s181><ask.bitten><en> Lead a life in unselfish neighbourly love, and remember me on many occasions; consciously connect yourselves with me, and ask me for my help, and also earthly you will no longer need to worry, because then I care for you.
<G-vec00384-001-s181><ask.bitten><de> Führet ein Leben in uneigennütziger Nächstenliebe, und gedenket des öfteren Meiner, verbindet euch bewußt mit Mir, und bittet Mich um Meinen Beistand, und ihr werdet euch auch irdisch nicht mehr zu sorgen brauchen, denn dann sorge Ich für euch.
<G-vec00384-001-s182><ask.bitten><en> "9 ""So I say to you: Ask and it will be given to you; seek and you will find; knock and the door will be opened to you."
<G-vec00384-001-s182><ask.bitten><de> Luk 11:9 So sage ich euch: Bittet, dann wird euch gegeben; sucht, dann werdet ihr finden; klopft an, dann wird euch aufgetan.
<G-vec00384-001-s183><ask.bitten><en> 9 And I say to you, ask, and it will be given to you; seek, and you will find; knock, and it will be opened to you.
<G-vec00384-001-s183><ask.bitten><de> 9 Und ich sage euch auch: Bittet, so wird euch gegeben; suchet, so werdet ihr finden; klopfet an, so wird euch aufgetan.
<G-vec00384-001-s184><ask.bitten><en> Ask for forgiveness, and recount how you have sinned against them, ask for pardon.
<G-vec00384-001-s184><ask.bitten><de> Bittet auch darum, dass sie euch vergeben und zählt auf, wie ihr gegen sie gesündigt habt, bittet um Entschuldigung.
<G-vec00384-001-s185><ask.bitten><en> The Prince Estate is not the first to ask Trump to stop using their music during his rallies.
<G-vec00384-001-s185><ask.bitten><de> The Prince Estate ist nicht der erste, der Trump bittet, ihre Musik während seiner Kundgebungen nicht mehr zu verwenden.
<G-vec00384-001-s186><ask.bitten><en> Towards the end of the research stay, the Alexander von Humboldt Foundation will ask award winners for a brief, informal report on their experiences, which should also contain information on the academic collaboration with the host institution and contacts with other research institutions in Germany and abroad. They will also be asked to comment on their own and their families' personal impressions during their stay in Germany.
<G-vec00384-001-s186><ask.bitten><de> Gegen Ende des Forschungsaufenthaltes bittet die Alexander von Humboldt- Stiftung die Preisträger um einen kurzen, informellen Erfahrungsbericht, der auch Informationen über die wissenschaftliche Zusammenarbeit mit dem Gastinstitut, über die Kontakte zu anderen Forschungsinstitutionen in Deutschland und im Ausland sowie über die persönlichen Eindrücke der Preisträger und ihrer Familien während des Aufenthaltes in Deutschland enthalten sollte.
<G-vec00384-001-s187><ask.bitten><en> The Noah’s Animal Shelter want to ask everybody for NOT BEING UNINTERESTED.
<G-vec00384-001-s187><ask.bitten><de> Die NOAH Tierheim Stiftung bittet alle, nicht GLEICHGÜLTIG zu sein.
<G-vec00384-001-s188><ask.bitten><en> "Truly, truly I say to you, whatever you ask the Father in my name, He will give it to you...ask in my name; I am not saying I will pray to the Father for you, for the Father Himself loves you, because you have loved me..."" v23-27) That is the first thing we have in common with the Father - we both love Jesus."
<G-vec00384-001-s188><ask.bitten><de> Wahrlich, wahrlich ich sage euch, was immer ihr den Vater in meinem Namen bitten werdet, wird er euch geben... bittet in meinem Namen, ich sage nicht, dass ich für euch den Vater bitten werde, den der Vater selbst liebt euch, weil ihr mich geliebt habt (Verse 23-27) Die erste Sache, die wir mit dem Vater gemeinsam haben, ist, dass wir beide Jesus lieben.
<G-vec00384-001-s189><ask.bitten><en> But if you want to ask for stupidity, She cannot do it.
<G-vec00384-001-s189><ask.bitten><de> Wenn ihr aber um Dummheit bittet, diese kann sie euch nicht geben.
<G-vec00272-001-s190><ask.fragen><en> If one recognize that something keeps him from doing so, one should ask him directly about it, or ask him if he wants to become a Muslim instead of commanding and exerting pressure on him.
<G-vec00272-001-s190><ask.fragen><de> Wenn man erkennt, dass etwas ihn davon abhält, sollte man ihn direkt danach fragen, oder ihn fragen, ob er Muslim werden möchte, anstatt es ihm zu befehlen und Druck auszuüben.
<G-vec00272-001-s191><ask.fragen><en> Khiray was tempted to stop at the next big city and ask a doctor or herb healer for it.
<G-vec00272-001-s191><ask.fragen><de> Khiray war versucht, in der nächsten größeren Stadt anzuhalten und einen Arzt oder Kräuterheiler danach zu fragen.
<G-vec00272-001-s192><ask.fragen><en> At least if you have to ask about it.
<G-vec00272-001-s192><ask.fragen><de> Zumindest, wenn Sie danach fragen.
<G-vec00272-001-s193><ask.fragen><en> The Spiritual Healing Section of the Society has been active from 1980 and undertakes selflessly the performance of therapies to patients who ask for it.
<G-vec00272-001-s193><ask.fragen><de> Der Spiritual Healing Sektion der Gesellschaft aktiv war von 1980 und verpflichtet sich selbstlos die Leistung von Therapien für Patienten, die danach fragen.
<G-vec00272-001-s194><ask.fragen><en> """For weeks her record was sold out regularly, but now you can ask for it again..."
<G-vec00272-001-s194><ask.fragen><de> """Wochenlang war ihre Platte regelmäßig ausverkauft, aber jetzt kann man schon wieder mal danach fragen..."
<G-vec00272-001-s195><ask.fragen><en> [...] it is not permanently activated but only when the system and applications ask for it.
<G-vec00272-001-s195><ask.fragen><de> [...] Es ist nicht permanent aktiviert, sondern nur, wenn das System und die Anwendungen danach fragen.
<G-vec00272-001-s196><ask.fragen><en> And if you are one of those ready to accept a sceptre, you also need to step forth in your full integrity and ask for one.
<G-vec00272-001-s196><ask.fragen><de> Und wenn Du zu denen gehörst, die bereit sind, ein solches Zepter anzunehmen, musst auch Du in deiner ganzen Integrität hervortreten und danach fragen.
<G-vec00272-001-s197><ask.fragen><en> You can also stop in the many wineries and dairies that are located along the streets around Pienza and ask the owners to make you taste the wines or the famous pecorino of Pienza.
<G-vec00272-001-s197><ask.fragen><de> Außerdem kannst Du in den zahlreichen Kellereien und Käsereien anhalten, die sich entlang der Straßen befinden, die Pienza umgeben, und die Besitzer danach fragen, Dich die hervorragenden Weine oder die berühmten Pecorini von Pienza probieren zu lassen.
<G-vec00272-001-s198><ask.fragen><en> Dmitry is emphatic that you shouldn't ask for or expect a quick transaction.
<G-vec00272-001-s198><ask.fragen><de> Dmitry betont nachdrücklich, dass du keine schnelle Transaktion erwarten und auch nicht danach fragen solltest.
<G-vec00272-001-s199><ask.fragen><en> So don't be afraid to ask should you have any special requests in this regard..
<G-vec00272-001-s199><ask.fragen><de> Scheuen Sie sich also nicht, danach zu fragen, wenn Sie diesbezüglich besondere Wünsche haben.
<G-vec00272-001-s200><ask.fragen><en> For small companies with flat hierarchies this could be more of an exclusion criterion, while larger companies often ask explicitly for it.
<G-vec00272-001-s200><ask.fragen><de> Bei kleinen Unternehmen mit flachen Hierarchien könnte das eher ein Ausschlusskriterium sein, während größere Unternehmen oftmals gezielt danach fragen.
<G-vec00272-001-s201><ask.fragen><en> Then go into Tools - Options - Plug-ins, and remove the checks in the Enabled box for all of the plug-ins you have installed that did not ship with Rhino, and check the “Ask to load…” at the bottom.
<G-vec00272-001-s201><ask.fragen><de> Danach gehen Sie auf Werkzeuge - Optionen - Plug-ins und entfernen Sie die Markierungen des Kästchens Aktiviert für alle Plug-ins, die Sie installiert haben und nicht mit Rhino versendet wurden, und markieren Sie das Kästchen “Danach fragen, deaktivierte Plug-ins zu laden”.
<G-vec00272-001-s202><ask.fragen><en> If you ask us, we will endeavour to provide you with information about relevant complaint avenues which may be applicable to your circumstances.
<G-vec00272-001-s202><ask.fragen><de> Wenn Sie uns danach fragen, werden wir uns bemühen, Ihnen Informationen über die relevanten und für Ihre Umstände anwendbaren Beschwerdewege zur Verfügung zu stellen.
<G-vec00272-001-s203><ask.fragen><en> Consider sending an email to ask if you can add them to your email marketing lists.
<G-vec00272-001-s203><ask.fragen><de> Ziehen Sie es in Betracht, eine E-Mail zu verschicken, wo Sie danach fragen, Sie zu Ihren E-Mail Marketing Listen hinzuzufügen.
<G-vec00272-001-s204><ask.fragen><en> If we don't ask for more, it means that we're not really interested, we're not really motivated.
<G-vec00272-001-s204><ask.fragen><de> Wenn wir nicht danach fragen, heißt das, dass wir nicht wirklich interessiert, nicht wirklich motiviert sind.
<G-vec00272-001-s205><ask.fragen><en> If they are interested in it, they will ask you.
<G-vec00272-001-s205><ask.fragen><de> Wenn es Ihre Zuhörer interessiert, werden sie schon danach fragen.
<G-vec00272-001-s206><ask.fragen><en> If you succeed at inspiring the editor or blog owner (for GetResponse, it’s the editor), then you could simply ask that they reference and link to your guest article from the first paragraph of their popular post that’s already sitting at the #1 position in Google.
<G-vec00272-001-s206><ask.fragen><de> Wenn Du den Herausgeber oder Blog-Inhaber erfolgreich inspirieren kannst (bei GetResponse ist es der Herausgeber), dann kannst Du danach fragen, ob sie Deinen Gastbeitrag mit einem Link in einem ihrer populären Artikel erwähnen, die bei Google bereits an erster Stelle erscheinen.
<G-vec00272-001-s207><ask.fragen><en> If you want to repeat the series you simply go online and ask for it.
<G-vec00272-001-s207><ask.fragen><de> Wenn Sie möchten, wiederholen Sie die Serien, die du einfach online gehen und danach Fragen.
<G-vec00272-001-s208><ask.fragen><en> With shared rates, they lock in effective rate parity (even as rate parity clauses are beginning to be thrown out of courts across Europe) and with shared inventory they guarantee all the stock an OTA can want without them having to ask.
<G-vec00272-001-s208><ask.fragen><de> Mit gemeinsamen Tarifen blockieren sie eine effektive Ratenparität (sogar, wenn Ratenparitäts-Klauseln von Gerichten in ganz Europa als nichtig erklärt werden) und mit einem gemeinsamen Inventar gewährleisten sie den gesamten Bestand, den sich eine OTA wünschen kann, ohne dass sie danach fragen müssen.
<G-vec00384-001-s190><ask.fragen><en> If one recognize that something keeps him from doing so, one should ask him directly about it, or ask him if he wants to become a Muslim instead of commanding and exerting pressure on him.
<G-vec00384-001-s190><ask.fragen><de> Wenn man erkennt, dass etwas ihn davon abhält, sollte man ihn direkt danach fragen, oder ihn fragen, ob er Muslim werden möchte, anstatt es ihm zu befehlen und Druck auszuüben.
<G-vec00384-001-s191><ask.fragen><en> Khiray was tempted to stop at the next big city and ask a doctor or herb healer for it.
<G-vec00384-001-s191><ask.fragen><de> Khiray war versucht, in der nächsten größeren Stadt anzuhalten und einen Arzt oder Kräuterheiler danach zu fragen.
<G-vec00384-001-s192><ask.fragen><en> At least if you have to ask about it.
<G-vec00384-001-s192><ask.fragen><de> Zumindest, wenn Sie danach fragen.
<G-vec00384-001-s193><ask.fragen><en> The Spiritual Healing Section of the Society has been active from 1980 and undertakes selflessly the performance of therapies to patients who ask for it.
<G-vec00384-001-s193><ask.fragen><de> Der Spiritual Healing Sektion der Gesellschaft aktiv war von 1980 und verpflichtet sich selbstlos die Leistung von Therapien für Patienten, die danach fragen.
<G-vec00384-001-s194><ask.fragen><en> """For weeks her record was sold out regularly, but now you can ask for it again..."
<G-vec00384-001-s194><ask.fragen><de> """Wochenlang war ihre Platte regelmäßig ausverkauft, aber jetzt kann man schon wieder mal danach fragen..."
<G-vec00384-001-s195><ask.fragen><en> [...] it is not permanently activated but only when the system and applications ask for it.
<G-vec00384-001-s195><ask.fragen><de> [...] Es ist nicht permanent aktiviert, sondern nur, wenn das System und die Anwendungen danach fragen.
<G-vec00384-001-s196><ask.fragen><en> And if you are one of those ready to accept a sceptre, you also need to step forth in your full integrity and ask for one.
<G-vec00384-001-s196><ask.fragen><de> Und wenn Du zu denen gehörst, die bereit sind, ein solches Zepter anzunehmen, musst auch Du in deiner ganzen Integrität hervortreten und danach fragen.
<G-vec00384-001-s197><ask.fragen><en> You can also stop in the many wineries and dairies that are located along the streets around Pienza and ask the owners to make you taste the wines or the famous pecorino of Pienza.
<G-vec00384-001-s197><ask.fragen><de> Außerdem kannst Du in den zahlreichen Kellereien und Käsereien anhalten, die sich entlang der Straßen befinden, die Pienza umgeben, und die Besitzer danach fragen, Dich die hervorragenden Weine oder die berühmten Pecorini von Pienza probieren zu lassen.
<G-vec00384-001-s198><ask.fragen><en> Dmitry is emphatic that you shouldn't ask for or expect a quick transaction.
<G-vec00384-001-s198><ask.fragen><de> Dmitry betont nachdrücklich, dass du keine schnelle Transaktion erwarten und auch nicht danach fragen solltest.
<G-vec00384-001-s199><ask.fragen><en> So don't be afraid to ask should you have any special requests in this regard..
<G-vec00384-001-s199><ask.fragen><de> Scheuen Sie sich also nicht, danach zu fragen, wenn Sie diesbezüglich besondere Wünsche haben.
<G-vec00384-001-s200><ask.fragen><en> For small companies with flat hierarchies this could be more of an exclusion criterion, while larger companies often ask explicitly for it.
<G-vec00384-001-s200><ask.fragen><de> Bei kleinen Unternehmen mit flachen Hierarchien könnte das eher ein Ausschlusskriterium sein, während größere Unternehmen oftmals gezielt danach fragen.
<G-vec00384-001-s201><ask.fragen><en> Then go into Tools - Options - Plug-ins, and remove the checks in the Enabled box for all of the plug-ins you have installed that did not ship with Rhino, and check the “Ask to load…” at the bottom.
<G-vec00384-001-s201><ask.fragen><de> Danach gehen Sie auf Werkzeuge - Optionen - Plug-ins und entfernen Sie die Markierungen des Kästchens Aktiviert für alle Plug-ins, die Sie installiert haben und nicht mit Rhino versendet wurden, und markieren Sie das Kästchen “Danach fragen, deaktivierte Plug-ins zu laden”.
<G-vec00384-001-s202><ask.fragen><en> If you ask us, we will endeavour to provide you with information about relevant complaint avenues which may be applicable to your circumstances.
<G-vec00384-001-s202><ask.fragen><de> Wenn Sie uns danach fragen, werden wir uns bemühen, Ihnen Informationen über die relevanten und für Ihre Umstände anwendbaren Beschwerdewege zur Verfügung zu stellen.
<G-vec00384-001-s203><ask.fragen><en> Consider sending an email to ask if you can add them to your email marketing lists.
<G-vec00384-001-s203><ask.fragen><de> Ziehen Sie es in Betracht, eine E-Mail zu verschicken, wo Sie danach fragen, Sie zu Ihren E-Mail Marketing Listen hinzuzufügen.
<G-vec00384-001-s204><ask.fragen><en> If we don't ask for more, it means that we're not really interested, we're not really motivated.
<G-vec00384-001-s204><ask.fragen><de> Wenn wir nicht danach fragen, heißt das, dass wir nicht wirklich interessiert, nicht wirklich motiviert sind.
<G-vec00384-001-s205><ask.fragen><en> If they are interested in it, they will ask you.
<G-vec00384-001-s205><ask.fragen><de> Wenn es Ihre Zuhörer interessiert, werden sie schon danach fragen.
<G-vec00384-001-s206><ask.fragen><en> If you succeed at inspiring the editor or blog owner (for GetResponse, it’s the editor), then you could simply ask that they reference and link to your guest article from the first paragraph of their popular post that’s already sitting at the #1 position in Google.
<G-vec00384-001-s206><ask.fragen><de> Wenn Du den Herausgeber oder Blog-Inhaber erfolgreich inspirieren kannst (bei GetResponse ist es der Herausgeber), dann kannst Du danach fragen, ob sie Deinen Gastbeitrag mit einem Link in einem ihrer populären Artikel erwähnen, die bei Google bereits an erster Stelle erscheinen.
<G-vec00384-001-s207><ask.fragen><en> If you want to repeat the series you simply go online and ask for it.
<G-vec00384-001-s207><ask.fragen><de> Wenn Sie möchten, wiederholen Sie die Serien, die du einfach online gehen und danach Fragen.
<G-vec00384-001-s208><ask.fragen><en> With shared rates, they lock in effective rate parity (even as rate parity clauses are beginning to be thrown out of courts across Europe) and with shared inventory they guarantee all the stock an OTA can want without them having to ask.
<G-vec00384-001-s208><ask.fragen><de> Mit gemeinsamen Tarifen blockieren sie eine effektive Ratenparität (sogar, wenn Ratenparitäts-Klauseln von Gerichten in ganz Europa als nichtig erklärt werden) und mit einem gemeinsamen Inventar gewährleisten sie den gesamten Bestand, den sich eine OTA wünschen kann, ohne dass sie danach fragen müssen.
<G-vec00272-001-s209><ask.bitten><en> Therefore, “all those of whom it is required by virtue of their ministry in the care of souls are obliged to ensure that the confessions of the faithful entrusted to them are heard when they reasonably ask, and that they are given the opportunity to approach individual confession, on days and at times set down for their convenience”.13
<G-vec00272-001-s209><ask.bitten><de> Deshalb ist »jeder, dem von Amts wegen die Seelsorge aufgetragen ist, zur Vorsorge dafür verpflichtet, daß die Beichten der ihm anvertrauten Gläubigen gehört werden, die in vernünftiger Weise darum bitten; des weiteren, daß ihnen an festgesetzten Tagen und Stunden, die ihnen genehm sind, Gelegenheit geboten wird, zu einer persönlichen Beichte zu kommen«.
<G-vec00272-001-s210><ask.bitten><en> Okay, here it is: phone a public corporation and ask to speak with the CEO.If a secretary tells you that the CEO expects to be busy in meetings for the next six hundred years, call your broker and sell the stock short.
<G-vec00272-001-s210><ask.bitten><de> Okay, hier ist es: Telefon eine Körperschaft des öffentlichen Rechts und darum bitten, sprechen Sie mit der CEO.If eine Sekretärin Ihnen sagt, dass der CEO erwartet, dass es in den Sitzungen beschäftigt für die nächsten sechshundert Jahre, wenden Sie sich an Ihren Broker und verkaufen die Aktie kurz.
<G-vec00272-001-s211><ask.bitten><en> Let us work for an abundant harvest of holiness in the Church and ask to be found among Christ’s righteous ones on the Day of Judgement.
<G-vec00272-001-s211><ask.bitten><de> Wir wollen für eine reiche Ernte an Heiligkeit in der Kirche arbeiten und darum bitten, daß wir am Tag des Jüngsten Gerichts unter den Gerechten Christi gefunden werden.
<G-vec00272-001-s212><ask.bitten><en> You please destroy him!” That’s Her job and She’d love to do it, but somebody has to tell Her and ask Her.
<G-vec00272-001-s212><ask.bitten><de> „Bitte, zerstöre diesen Menschen!“ Das ist Ihre Angelegenheit und Sie tut es gern, aber irgendjemand muss es Ihr mitteilen und Sie darum bitten.
<G-vec00272-001-s213><ask.bitten><en> """I lecture in about twenty colleges a year,"" he began, ""and I do a faith-healing demonstration — but I always make them ask for it."
<G-vec00272-001-s213><ask.bitten><de> """Ich gebe in ungefähr zwanzig Colleges pro Jahr Vortäge"", begann er, ""und ich demonstriere ihnen auch auf den Glauben basierende Heilungen – doch ich lasse sie immer darum bitten."
<G-vec00272-001-s214><ask.bitten><en> You'll be able to collect certified reviews if you ask your guests to leave reviews for your establishment.
<G-vec00272-001-s214><ask.bitten><de> Sie können Bewertungen sammeln, indem Sie Ihre Gäste darum bitten, Bewertungen zu Ihrem Unternehmen zu hinterlassen.
<G-vec00272-001-s215><ask.bitten><en> If our teachers ask us to undertake something that, for some reason, we cannot do, we need to explain humbly and politely why we are unable to comply.
<G-vec00272-001-s215><ask.bitten><de> Wenn uns unsere Lehrer darum bitten, etwas auszuführen, das wir aus irgendeinem Grund nicht tun können, müssen wir bescheiden und höflich erklären, warum es uns unmöglich ist, dem nachzukommen.
<G-vec00272-001-s216><ask.bitten><en> We are to ask Jesus in prayer that we not fall for other voices, but rather that we listen to the words of the Holy Spirit.
<G-vec00272-001-s216><ask.bitten><de> Wir dürfen Jesus darum bitten, daß wir auf keine anderen Stimmen hereinfallen, sondern nur auf die Worte des Heiligen Geistes hören.
<G-vec00272-001-s217><ask.bitten><en> The Bible says that God will give good things to those who ask Him, much more than parents to their children.
<G-vec00272-001-s217><ask.bitten><de> In der Bibel steht, dass Gott jenen Gutes tut, die Ihn darum bitten, und dabei noch zuverlässiger ist, als Eltern es ihren Kindern gegenüber sind.
<G-vec00272-001-s218><ask.bitten><en> We ask this through the intercession of the Holy Apostles Peter and Paul and St John Mary Vianney, the Curé d'Ars, to whose protection I have dedicated the next Presbyteral Year.
<G-vec00272-001-s218><ask.bitten><de> Darum bitten wir auf die Fürsprache der heiligen Apostel Petrus und Paulus und des heiligen Pfarrers von Ars Jean-Marie Vianney, unter dessen Patrozinium ich das kommende Priesterjahr gestellt habe.
<G-vec00272-001-s219><ask.bitten><en> @ We must therefore ask you to come to us for questions on a free parking space, from the infotafel 500m. @
<G-vec00272-001-s219><ask.bitten><de> Wir müssen Sie deswegen darum bitten, für Fragen auf einen freien Stellplatz, ab der Infotafel 500m zu Fuß zu uns zu kommen.
<G-vec00272-001-s220><ask.bitten><en> Because we're going to ask that you share this website on any of your social networks and access to a unique place.
<G-vec00272-001-s220><ask.bitten><de> Denn wir darum bitten, dass teilen Sie diese Website auf Ihre sozialen Netzwerke und Zugang zu einem einzigartigen Ort.
<G-vec00272-001-s221><ask.bitten><en> Mr. Cuffe asked the Minister for Foreign Affairs if his attention has been drawn to the recent shocking and tragic death of a person (details supplied); if the Irish Government can ask the Chinese Government to investigate this person’s death; and if he will make a statement on the matter.
<G-vec00272-001-s221><ask.bitten><de> Herr Cuffe fragte den Außenminister, ob seine Aufmerksamkeit auf den jüngsten schockierenden und tragischen Todesfall einer Person (die Daten wurden genannt) gelenkt worden sei; ob die irische Regierung die chinesische Regierung darum bitten könnte, den Todesfall dieser Person zu untersuchen; und ob er eine Erklärung bezüglich dieser Angelegenheit abgeben werde.
<G-vec00272-001-s222><ask.bitten><en> You can ask people to make videos, usually of themselves performing a task.
<G-vec00272-001-s222><ask.bitten><de> Du kannst die Teilnehmer auch darum bitten, ein Video von sich zu machen.
<G-vec00272-001-s223><ask.bitten><en> He gives it freely, if we ask for it.
<G-vec00272-001-s223><ask.bitten><de> Und er gibt sie gern, wenn wir darum bitten.
<G-vec00272-001-s224><ask.bitten><en> Your request and choices may be limited in certain cases: For example, if fulfilling your request would reveal information about another person, or if you ask to delete information which we are permitted by law or have compelling legitimate interests to keep.
<G-vec00272-001-s224><ask.bitten><de> Ihre Anfrage und Auswahl kann in bestimmten Fällen eingeschränkt sein: Zum Beispiel, wenn die Erfüllung Ihrer Anfrage Informationen über eine andere Person preisgeben würde, oder wenn Sie darum bitten, Informationen zu löschen, die wir gesetzlich erlaubt sind oder zwingende legitime Interessen behalten müssen.
<G-vec00272-001-s225><ask.bitten><en> For example, if fulfilling your request would reveal information about another person, or if you ask to delete information which we are permitted by law or have compelling legitimate interests to keep.
<G-vec00272-001-s225><ask.bitten><de> Zum Beispiel, wenn die Erfüllung Ihrer Anfrage Informationen über eine andere Person preisgeben würde, oder wenn Sie darum bitten, Informationen zu löschen, die wir gesetzlich erlaubt sind oder zwingende legitime Interessen behalten müssen.
<G-vec00272-001-s226><ask.bitten><en> If your medical equipment causes interference, our cabin crew may ask that you turn it off.
<G-vec00272-001-s226><ask.bitten><de> Wenn Ihre medizinischen Geräte Störungen verursachen, kann Sie unser Kabinenpersonal darum bitten, diese auszuschalten.
<G-vec00272-001-s227><ask.bitten><en> Then they said, and we work in the brush, we’re going to ask him to please take his clothes off and work there naked, let’s see what he thinks then.
<G-vec00272-001-s227><ask.bitten><de> Dann sagten sie, wir arbeiten in den Bergen und wir werden ihn darum bitten, sich auszuziehen und nackt zu arbeiten, mal sehen, was er dann denkt.
<G-vec00384-001-s209><ask.bitten><en> Therefore, “all those of whom it is required by virtue of their ministry in the care of souls are obliged to ensure that the confessions of the faithful entrusted to them are heard when they reasonably ask, and that they are given the opportunity to approach individual confession, on days and at times set down for their convenience”.13
<G-vec00384-001-s209><ask.bitten><de> Deshalb ist »jeder, dem von Amts wegen die Seelsorge aufgetragen ist, zur Vorsorge dafür verpflichtet, daß die Beichten der ihm anvertrauten Gläubigen gehört werden, die in vernünftiger Weise darum bitten; des weiteren, daß ihnen an festgesetzten Tagen und Stunden, die ihnen genehm sind, Gelegenheit geboten wird, zu einer persönlichen Beichte zu kommen«.
<G-vec00384-001-s210><ask.bitten><en> Okay, here it is: phone a public corporation and ask to speak with the CEO.If a secretary tells you that the CEO expects to be busy in meetings for the next six hundred years, call your broker and sell the stock short.
<G-vec00384-001-s210><ask.bitten><de> Okay, hier ist es: Telefon eine Körperschaft des öffentlichen Rechts und darum bitten, sprechen Sie mit der CEO.If eine Sekretärin Ihnen sagt, dass der CEO erwartet, dass es in den Sitzungen beschäftigt für die nächsten sechshundert Jahre, wenden Sie sich an Ihren Broker und verkaufen die Aktie kurz.
<G-vec00384-001-s211><ask.bitten><en> Let us work for an abundant harvest of holiness in the Church and ask to be found among Christ’s righteous ones on the Day of Judgement.
<G-vec00384-001-s211><ask.bitten><de> Wir wollen für eine reiche Ernte an Heiligkeit in der Kirche arbeiten und darum bitten, daß wir am Tag des Jüngsten Gerichts unter den Gerechten Christi gefunden werden.
<G-vec00384-001-s212><ask.bitten><en> You please destroy him!” That’s Her job and She’d love to do it, but somebody has to tell Her and ask Her.
<G-vec00384-001-s212><ask.bitten><de> „Bitte, zerstöre diesen Menschen!“ Das ist Ihre Angelegenheit und Sie tut es gern, aber irgendjemand muss es Ihr mitteilen und Sie darum bitten.
<G-vec00384-001-s213><ask.bitten><en> """I lecture in about twenty colleges a year,"" he began, ""and I do a faith-healing demonstration — but I always make them ask for it."
<G-vec00384-001-s213><ask.bitten><de> """Ich gebe in ungefähr zwanzig Colleges pro Jahr Vortäge"", begann er, ""und ich demonstriere ihnen auch auf den Glauben basierende Heilungen – doch ich lasse sie immer darum bitten."
<G-vec00384-001-s214><ask.bitten><en> You'll be able to collect certified reviews if you ask your guests to leave reviews for your establishment.
<G-vec00384-001-s214><ask.bitten><de> Sie können Bewertungen sammeln, indem Sie Ihre Gäste darum bitten, Bewertungen zu Ihrem Unternehmen zu hinterlassen.
<G-vec00384-001-s215><ask.bitten><en> If our teachers ask us to undertake something that, for some reason, we cannot do, we need to explain humbly and politely why we are unable to comply.
<G-vec00384-001-s215><ask.bitten><de> Wenn uns unsere Lehrer darum bitten, etwas auszuführen, das wir aus irgendeinem Grund nicht tun können, müssen wir bescheiden und höflich erklären, warum es uns unmöglich ist, dem nachzukommen.
<G-vec00384-001-s216><ask.bitten><en> We are to ask Jesus in prayer that we not fall for other voices, but rather that we listen to the words of the Holy Spirit.
<G-vec00384-001-s216><ask.bitten><de> Wir dürfen Jesus darum bitten, daß wir auf keine anderen Stimmen hereinfallen, sondern nur auf die Worte des Heiligen Geistes hören.
<G-vec00384-001-s217><ask.bitten><en> The Bible says that God will give good things to those who ask Him, much more than parents to their children.
<G-vec00384-001-s217><ask.bitten><de> In der Bibel steht, dass Gott jenen Gutes tut, die Ihn darum bitten, und dabei noch zuverlässiger ist, als Eltern es ihren Kindern gegenüber sind.
<G-vec00384-001-s218><ask.bitten><en> We ask this through the intercession of the Holy Apostles Peter and Paul and St John Mary Vianney, the Curé d'Ars, to whose protection I have dedicated the next Presbyteral Year.
<G-vec00384-001-s218><ask.bitten><de> Darum bitten wir auf die Fürsprache der heiligen Apostel Petrus und Paulus und des heiligen Pfarrers von Ars Jean-Marie Vianney, unter dessen Patrozinium ich das kommende Priesterjahr gestellt habe.
<G-vec00384-001-s219><ask.bitten><en> @ We must therefore ask you to come to us for questions on a free parking space, from the infotafel 500m. @
<G-vec00384-001-s219><ask.bitten><de> Wir müssen Sie deswegen darum bitten, für Fragen auf einen freien Stellplatz, ab der Infotafel 500m zu Fuß zu uns zu kommen.
<G-vec00384-001-s220><ask.bitten><en> Because we're going to ask that you share this website on any of your social networks and access to a unique place.
<G-vec00384-001-s220><ask.bitten><de> Denn wir darum bitten, dass teilen Sie diese Website auf Ihre sozialen Netzwerke und Zugang zu einem einzigartigen Ort.
<G-vec00384-001-s221><ask.bitten><en> Mr. Cuffe asked the Minister for Foreign Affairs if his attention has been drawn to the recent shocking and tragic death of a person (details supplied); if the Irish Government can ask the Chinese Government to investigate this person’s death; and if he will make a statement on the matter.
<G-vec00384-001-s221><ask.bitten><de> Herr Cuffe fragte den Außenminister, ob seine Aufmerksamkeit auf den jüngsten schockierenden und tragischen Todesfall einer Person (die Daten wurden genannt) gelenkt worden sei; ob die irische Regierung die chinesische Regierung darum bitten könnte, den Todesfall dieser Person zu untersuchen; und ob er eine Erklärung bezüglich dieser Angelegenheit abgeben werde.
<G-vec00384-001-s222><ask.bitten><en> You can ask people to make videos, usually of themselves performing a task.
<G-vec00384-001-s222><ask.bitten><de> Du kannst die Teilnehmer auch darum bitten, ein Video von sich zu machen.
<G-vec00384-001-s223><ask.bitten><en> He gives it freely, if we ask for it.
<G-vec00384-001-s223><ask.bitten><de> Und er gibt sie gern, wenn wir darum bitten.
<G-vec00384-001-s224><ask.bitten><en> Your request and choices may be limited in certain cases: For example, if fulfilling your request would reveal information about another person, or if you ask to delete information which we are permitted by law or have compelling legitimate interests to keep.
<G-vec00384-001-s224><ask.bitten><de> Ihre Anfrage und Auswahl kann in bestimmten Fällen eingeschränkt sein: Zum Beispiel, wenn die Erfüllung Ihrer Anfrage Informationen über eine andere Person preisgeben würde, oder wenn Sie darum bitten, Informationen zu löschen, die wir gesetzlich erlaubt sind oder zwingende legitime Interessen behalten müssen.
<G-vec00384-001-s225><ask.bitten><en> For example, if fulfilling your request would reveal information about another person, or if you ask to delete information which we are permitted by law or have compelling legitimate interests to keep.
<G-vec00384-001-s225><ask.bitten><de> Zum Beispiel, wenn die Erfüllung Ihrer Anfrage Informationen über eine andere Person preisgeben würde, oder wenn Sie darum bitten, Informationen zu löschen, die wir gesetzlich erlaubt sind oder zwingende legitime Interessen behalten müssen.
<G-vec00384-001-s226><ask.bitten><en> If your medical equipment causes interference, our cabin crew may ask that you turn it off.
<G-vec00384-001-s226><ask.bitten><de> Wenn Ihre medizinischen Geräte Störungen verursachen, kann Sie unser Kabinenpersonal darum bitten, diese auszuschalten.
<G-vec00384-001-s227><ask.bitten><en> Then they said, and we work in the brush, we’re going to ask him to please take his clothes off and work there naked, let’s see what he thinks then.
<G-vec00384-001-s227><ask.bitten><de> Dann sagten sie, wir arbeiten in den Bergen und wir werden ihn darum bitten, sich auszuziehen und nackt zu arbeiten, mal sehen, was er dann denkt.
<G-vec00272-001-s228><ask.erbitten><en> One can come before an altar and ask for something.
<G-vec00272-001-s228><ask.erbitten><de> Man kann als Gläubiger vor einen Altar treten und etwas erbitten.
<G-vec00272-001-s229><ask.erbitten><en> You have to ask for all miracles.
<G-vec00272-001-s229><ask.erbitten><de> Wir müssen alle Wunder erbitten.
<G-vec00272-001-s230><ask.erbitten><en> If a player makes a lot of bad drops in a play-off match, the opponent can ask for a neutral dropper.
<G-vec00272-001-s230><ask.erbitten><de> Wenn ein Spieler den Puck wiederholt inkorrekt droppt, kann der Gegner einen neutralen Dropper erbitten.
<G-vec00272-001-s231><ask.erbitten><en> We thank Peter and Mike for their service in the Team and ask God's blessing on their future ministries.
<G-vec00272-001-s231><ask.erbitten><de> Wir danken Peter und Mike für ihren Einsatz im Team und erbitten Gottes Segen für ihre zukünftigen Aufgaben.
<G-vec00272-001-s232><ask.erbitten><en> In our serene prayer, which wavers between embarrassment and dignity, dignity and embarrassment, both together, let us ask for the grace to sense that mercy as giving meaning to our entire life, the grace to feel how the heart of the Father beats as one with our own.
<G-vec00272-001-s232><ask.erbitten><de> In unserem ruhigen Beten, das von der Beschämung zur Würde und von der Würde zur Beschämung geht – beides zusammen –, erbitten wir die Gnade, diese Barmherzigkeit als grundlegend für unser ganzes Leben zu empfinden; die Gnade, zu spüren, wie der Herzschlag des Vaters sich mit dem unsrigen verbindet.
<G-vec00272-001-s233><ask.erbitten><en> The assistance we ask for is already the first step of God’s mercy toward us.
<G-vec00272-001-s233><ask.erbitten><de> Die Hilfe, die wir erbitten, ist bereits der erste Schritt der Barmherzigkeit Gottes mit uns.
<G-vec00272-001-s234><ask.erbitten><en> the custom of spending the night in contact with these stones to stimulate dreams predicting the future or, in any event, to seek contact and ask for assistance from one's ancestors now one with the earth.
<G-vec00272-001-s234><ask.erbitten><de> Der Brauch verlangte, eine Nacht inmitten dieser Steine zu verbringen, um so zukunftsweisende Träume zu fördern oder um mit verstorbenen Vorfahren in Kontakt treten und deren Hilfe erbitten zu können.
<G-vec00272-001-s235><ask.erbitten><en> Through that power in us, God can do much more than we can ask or imagine (Ephesians 3:20-21).
<G-vec00272-001-s235><ask.erbitten><de> Gott kann durch diese Macht in uns viel mehr tun, als wir erbitten oder uns vorstellen können (Eph.3,20-21).
<G-vec00272-001-s236><ask.erbitten><en> At the beginning of a new millennium, the six hundred delegates at this Assembly have the opportunity to thank God for all that being a woman signifies in the divine plan, and to ask his help in overcoming the many obstacles which still hinder full recognition of the dignity and mission of women in society and within the ecclesial community.
<G-vec00272-001-s236><ask.erbitten><de> Zu Beginn eines neuen Jahrtausends haben die sechshundert hier versammelten Delegierten die Gelegenheit, Gott für die Bedeutung zu danken, die dem Frau-Sein im göttlichen Plan zukommt, und seine Hilfe zur Überwindung all jener Hindernisse zu erbitten, die die volle Anerkennung der Würde und Sendung der Frauen in der Gesellschaft und innerhalb der kirchlichen Gemeinschaft immer noch nicht zulassen.
<G-vec00272-001-s237><ask.erbitten><en> And as we read, let's do it as a search for the heart of Jesus and ask God to help us know him better.
<G-vec00272-001-s237><ask.erbitten><de> Und lasst uns, während wir lesen, nach dem Herz Jesu suchen und Gottes Hilfe erbitten, damit wir ihn besser kennenlernen.
<G-vec00272-001-s238><ask.erbitten><en> Only when they have recognized that there is no other possible option left to them can they themselves ask for God's forgiveness, in a spirit of conversion and contrition.
<G-vec00272-001-s238><ask.erbitten><de> Erst wenn sie erkannt haben, dass es für sie keine andere Möglichkeit mehr gibt, können sie durch Umkehr und Reue selbst von ihrem Gott Vergebung erbitten.
<G-vec00272-001-s239><ask.erbitten><en> “To God who by the power at work within us is able to do far more abundantly than we can ask or think, to him be glory in the Church and in Christ Jesus to all generations, for ever and ever.
<G-vec00272-001-s239><ask.erbitten><de> »Er aber, der durch die Macht, die in uns wirkt, unendlich viel mehr tun kann, als wir erbitten oder uns ausdenken können, er werde verherrlicht durch die Kirche und durch Christus Jesus in allen Generationen, für ewige Zeiten.
<G-vec00272-001-s240><ask.erbitten><en> "Mt 18,19 ""Again I say to you, that if two of you agree on earth about anything that they may ask, it shall be done for them by My Father who is in heaven."
<G-vec00272-001-s240><ask.erbitten><de> Mt 18,19 Wiederum sage ich euch: Wenn zwei von euch auf der Erde übereinkommen, irgendeine Sache zu erbitten, so wird sie ihnen werden von meinem Vater, der in den Himmeln ist.
<G-vec00272-001-s241><ask.erbitten><en> We must not allow this, and we must continue to ask for work, to generate it, to estimate it, to love it.
<G-vec00272-001-s241><ask.erbitten><de> Wir dürfen das nicht zulassen, und wir müssen die Arbeit weiterhin erbitten, erzeugen, achten und lieben.
<G-vec00272-001-s242><ask.erbitten><en> And when we live this sort of a life in the flesh, we may ask many things of God, and he will give us the desire of our hearts that we may be the better prepared to serve our fellows.
<G-vec00272-001-s242><ask.erbitten><de> Und wenn wir auf Erden so leben, können wir von Gott vieles erbitten, und er wird uns den Herzenswunsch eingeben, wir möchten besser ausgerüstet sein, um unseren Mitmenschen zu helfen.
<G-vec00272-001-s243><ask.erbitten><en> So also every earthly trouble is to be regarded as favour, because it can lead up, when it is regarded as such, when the trouble lets man become aware that he is to turn his look upwards to ask help from him, who always wants and can help.
<G-vec00272-001-s243><ask.erbitten><de> So ist auch jede irdische Not als Gnade anzusehen, weil sie zur Höhe führen kann, wenn sie als solche angesehen wird, wenn die Not dem Menschen bewußt werden läßt, daß er seinen Blick zur Höhe wenden soll, um Hilfe zu erbitten von Dem, Der immer helfen kann und will.
<G-vec00272-001-s244><ask.erbitten><en> 19 Again I say to you, if two of you agree on earth about anything they ask, it will be done for them by my Father in heaven.
<G-vec00272-001-s244><ask.erbitten><de> 19 Wiederum sage ich euch: Wenn zwei von euch auf der Erde übereinkommen, irgendeine Sache zu erbitten, so wird sie ihnen werden von meinem Vater, der in den Himmeln ist.
<G-vec00272-001-s245><ask.erbitten><en> We ask this, not for ourselves or our reputation, but for your glory and the salvation of our world.
<G-vec00272-001-s245><ask.erbitten><de> Wir erbitten das nicht für uns selbst noch unseres Ansehens wegen, sondern damit du verherrlicht wirst und die Welt gerettet wird.
<G-vec00272-001-s246><ask.erbitten><en> When we ask him not to let us fall into temptation, we ask not to contract more debts than those we have already incurred.
<G-vec00272-001-s246><ask.erbitten><de> Wenn wir bitten «Führe uns nicht in Versuchung» wollen wir von Ihm erbitten, dass wir zu den von uns begangenen Sünden nicht noch neue hinzufügen.
<G-vec00384-001-s228><ask.erbitten><en> One can come before an altar and ask for something.
<G-vec00384-001-s228><ask.erbitten><de> Man kann als Gläubiger vor einen Altar treten und etwas erbitten.
<G-vec00384-001-s229><ask.erbitten><en> You have to ask for all miracles.
<G-vec00384-001-s229><ask.erbitten><de> Wir müssen alle Wunder erbitten.
<G-vec00384-001-s230><ask.erbitten><en> If a player makes a lot of bad drops in a play-off match, the opponent can ask for a neutral dropper.
<G-vec00384-001-s230><ask.erbitten><de> Wenn ein Spieler den Puck wiederholt inkorrekt droppt, kann der Gegner einen neutralen Dropper erbitten.
<G-vec00384-001-s231><ask.erbitten><en> We thank Peter and Mike for their service in the Team and ask God's blessing on their future ministries.
<G-vec00384-001-s231><ask.erbitten><de> Wir danken Peter und Mike für ihren Einsatz im Team und erbitten Gottes Segen für ihre zukünftigen Aufgaben.
<G-vec00384-001-s232><ask.erbitten><en> In our serene prayer, which wavers between embarrassment and dignity, dignity and embarrassment, both together, let us ask for the grace to sense that mercy as giving meaning to our entire life, the grace to feel how the heart of the Father beats as one with our own.
<G-vec00384-001-s232><ask.erbitten><de> In unserem ruhigen Beten, das von der Beschämung zur Würde und von der Würde zur Beschämung geht – beides zusammen –, erbitten wir die Gnade, diese Barmherzigkeit als grundlegend für unser ganzes Leben zu empfinden; die Gnade, zu spüren, wie der Herzschlag des Vaters sich mit dem unsrigen verbindet.
<G-vec00384-001-s233><ask.erbitten><en> The assistance we ask for is already the first step of God’s mercy toward us.
<G-vec00384-001-s233><ask.erbitten><de> Die Hilfe, die wir erbitten, ist bereits der erste Schritt der Barmherzigkeit Gottes mit uns.
<G-vec00384-001-s234><ask.erbitten><en> the custom of spending the night in contact with these stones to stimulate dreams predicting the future or, in any event, to seek contact and ask for assistance from one's ancestors now one with the earth.
<G-vec00384-001-s234><ask.erbitten><de> Der Brauch verlangte, eine Nacht inmitten dieser Steine zu verbringen, um so zukunftsweisende Träume zu fördern oder um mit verstorbenen Vorfahren in Kontakt treten und deren Hilfe erbitten zu können.
<G-vec00384-001-s235><ask.erbitten><en> Through that power in us, God can do much more than we can ask or imagine (Ephesians 3:20-21).
<G-vec00384-001-s235><ask.erbitten><de> Gott kann durch diese Macht in uns viel mehr tun, als wir erbitten oder uns vorstellen können (Eph.3,20-21).
<G-vec00384-001-s236><ask.erbitten><en> At the beginning of a new millennium, the six hundred delegates at this Assembly have the opportunity to thank God for all that being a woman signifies in the divine plan, and to ask his help in overcoming the many obstacles which still hinder full recognition of the dignity and mission of women in society and within the ecclesial community.
<G-vec00384-001-s236><ask.erbitten><de> Zu Beginn eines neuen Jahrtausends haben die sechshundert hier versammelten Delegierten die Gelegenheit, Gott für die Bedeutung zu danken, die dem Frau-Sein im göttlichen Plan zukommt, und seine Hilfe zur Überwindung all jener Hindernisse zu erbitten, die die volle Anerkennung der Würde und Sendung der Frauen in der Gesellschaft und innerhalb der kirchlichen Gemeinschaft immer noch nicht zulassen.
<G-vec00384-001-s237><ask.erbitten><en> And as we read, let's do it as a search for the heart of Jesus and ask God to help us know him better.
<G-vec00384-001-s237><ask.erbitten><de> Und lasst uns, während wir lesen, nach dem Herz Jesu suchen und Gottes Hilfe erbitten, damit wir ihn besser kennenlernen.
<G-vec00384-001-s238><ask.erbitten><en> Only when they have recognized that there is no other possible option left to them can they themselves ask for God's forgiveness, in a spirit of conversion and contrition.
<G-vec00384-001-s238><ask.erbitten><de> Erst wenn sie erkannt haben, dass es für sie keine andere Möglichkeit mehr gibt, können sie durch Umkehr und Reue selbst von ihrem Gott Vergebung erbitten.
<G-vec00384-001-s239><ask.erbitten><en> “To God who by the power at work within us is able to do far more abundantly than we can ask or think, to him be glory in the Church and in Christ Jesus to all generations, for ever and ever.
<G-vec00384-001-s239><ask.erbitten><de> »Er aber, der durch die Macht, die in uns wirkt, unendlich viel mehr tun kann, als wir erbitten oder uns ausdenken können, er werde verherrlicht durch die Kirche und durch Christus Jesus in allen Generationen, für ewige Zeiten.
<G-vec00384-001-s240><ask.erbitten><en> "Mt 18,19 ""Again I say to you, that if two of you agree on earth about anything that they may ask, it shall be done for them by My Father who is in heaven."
<G-vec00384-001-s240><ask.erbitten><de> Mt 18,19 Wiederum sage ich euch: Wenn zwei von euch auf der Erde übereinkommen, irgendeine Sache zu erbitten, so wird sie ihnen werden von meinem Vater, der in den Himmeln ist.
<G-vec00384-001-s241><ask.erbitten><en> We must not allow this, and we must continue to ask for work, to generate it, to estimate it, to love it.
<G-vec00384-001-s241><ask.erbitten><de> Wir dürfen das nicht zulassen, und wir müssen die Arbeit weiterhin erbitten, erzeugen, achten und lieben.
<G-vec00384-001-s242><ask.erbitten><en> And when we live this sort of a life in the flesh, we may ask many things of God, and he will give us the desire of our hearts that we may be the better prepared to serve our fellows.
<G-vec00384-001-s242><ask.erbitten><de> Und wenn wir auf Erden so leben, können wir von Gott vieles erbitten, und er wird uns den Herzenswunsch eingeben, wir möchten besser ausgerüstet sein, um unseren Mitmenschen zu helfen.
<G-vec00384-001-s243><ask.erbitten><en> So also every earthly trouble is to be regarded as favour, because it can lead up, when it is regarded as such, when the trouble lets man become aware that he is to turn his look upwards to ask help from him, who always wants and can help.
<G-vec00384-001-s243><ask.erbitten><de> So ist auch jede irdische Not als Gnade anzusehen, weil sie zur Höhe führen kann, wenn sie als solche angesehen wird, wenn die Not dem Menschen bewußt werden läßt, daß er seinen Blick zur Höhe wenden soll, um Hilfe zu erbitten von Dem, Der immer helfen kann und will.
<G-vec00384-001-s244><ask.erbitten><en> 19 Again I say to you, if two of you agree on earth about anything they ask, it will be done for them by my Father in heaven.
<G-vec00384-001-s244><ask.erbitten><de> 19 Wiederum sage ich euch: Wenn zwei von euch auf der Erde übereinkommen, irgendeine Sache zu erbitten, so wird sie ihnen werden von meinem Vater, der in den Himmeln ist.
<G-vec00384-001-s245><ask.erbitten><en> We ask this, not for ourselves or our reputation, but for your glory and the salvation of our world.
<G-vec00384-001-s245><ask.erbitten><de> Wir erbitten das nicht für uns selbst noch unseres Ansehens wegen, sondern damit du verherrlicht wirst und die Welt gerettet wird.
<G-vec00384-001-s246><ask.erbitten><en> When we ask him not to let us fall into temptation, we ask not to contract more debts than those we have already incurred.
<G-vec00384-001-s246><ask.erbitten><de> Wenn wir bitten «Führe uns nicht in Versuchung» wollen wir von Ihm erbitten, dass wir zu den von uns begangenen Sünden nicht noch neue hinzufügen.
<G-vec00272-001-s247><ask.erfragen><en> One thing we ask before reporting a ticket is to do a quick google search and see if your problem has been discussed on the forums or bug tracker previously.
<G-vec00272-001-s247><ask.erfragen><de> Eine Sache, die wir erfragen bevor Sie einen Vorgang (Ticket) berichten, ist eine schnelle Suche bei einer Suchmaschine (auch Google) und schauen Sie, ob Ihr Problem vorher im Forum oder der Fehlerverfolgung (Bug Tracker) diskutiert wurde.
<G-vec00272-001-s248><ask.erfragen><en> If the Bot wants to ask the desired travel class, but the user just remembers and states that he seeks to reserve a table at his favorite Italian Restaurant, the Virtual Agent can master this context change.
<G-vec00272-001-s248><ask.erfragen><de> Wenn der Chatbot die gewünschte Bahnklasse erfragen möchte, dem Nutzer aber gerade einfällt, dass er einen Tisch bei seinem Lieblingsitaliener reservieren muss, wäre der Virtual Agent in der Lage diesen Kontextwechsel zu meistern und anschließend zum vorhergehenden Anliegen wieder zurückzukehren.
<G-vec00272-001-s249><ask.erfragen><en> Please ask for these fees with your local customs office.
<G-vec00272-001-s249><ask.erfragen><de> Bitte erfragen Sie diese Gebühren bei Ihrem Zollamt vor Ort.
<G-vec00272-001-s250><ask.erfragen><en> We will ask and use your personal data exclusively for the processing of the order.
<G-vec00272-001-s250><ask.erfragen><de> Wir werden Ihre persönlichen Daten ausschließlich zur Abwicklung der Bestellung erfragen und verwenden.
<G-vec00272-001-s251><ask.erfragen><en> Therefore the state is holding hearings to ask experts and citizens for their opinions on how to determine a two-month supply.
<G-vec00272-001-s251><ask.erfragen><de> Daher führt der Staat Anhörungen durch, um die Meinungen von Experten und Bürgern zu erfragen, wie ein zweimonatiger Vorrat bestimmt werden sollte.
<G-vec00272-001-s252><ask.erfragen><en> We have to always maintain our contact with God, we must know his will and sometimes we have to ask him directly.
<G-vec00272-001-s252><ask.erfragen><de> Unser Kontakt mit Gott muss immer aufrecht erhalten werden, wir müssen sein Wort kennen und wir müssen seinen Willen manchmal direkt von ihm erfragen.
<G-vec00272-001-s253><ask.erfragen><en> For the use of such cookies we will ask your consent at the beginning of the use of our website, so that the use of such cookies is covered by Art.
<G-vec00272-001-s253><ask.erfragen><de> Für die Verwendung derartiger Cookies werden wir zu Beginn der Nutzung unserer Website Ihr Einverständnis erfragen, so dass der Einsatz solcher Cookies von Art.
<G-vec00272-001-s254><ask.erfragen><en> Please ask for prices.
<G-vec00272-001-s254><ask.erfragen><de> Bitte erfragen Sie die Preise.
<G-vec00272-001-s255><ask.erfragen><en> Like Article 101B but used. Price depending on condition - please ask.
<G-vec00272-001-s255><ask.erfragen><de> Wie Auspuffendtopfsatz 101B, aber gebraucht, Preis je nach Zustand, bitte erfragen.
<G-vec00272-001-s256><ask.erfragen><en> If you have not provided PayPal with a postal address to which we can send the receipt, we will ask for this by e-mail.
<G-vec00272-001-s256><ask.erfragen><de> Sofern Sie bei PayPal keine Postadresse angeben, an die wir die Spendenquittung schicken können, erfragen wir diese von Ihnen per E-Mail.
<G-vec00272-001-s257><ask.erfragen><en> Creating an account means that we do not have to ask for your details for each individual assignment.
<G-vec00272-001-s257><ask.erfragen><de> Durch Eröffnung eines Kontos müssen wir nicht für jeden einzelnen Auftrag Ihre Daten erfragen.
<G-vec00272-001-s258><ask.erfragen><en> If round slings, hoisting belts, lashing straps are used in conjunction with chemicals, please tell the manufacturer the certain application and conditions of use and ask the manufacturer for additional instructions and observe them.
<G-vec00272-001-s258><ask.erfragen><de> Sollen Rundschlingen, Hebebänder, Zurrgurte in Verbindung mit Chemikalien verwendet werden, sind unter Angabe von Einsatzdauer und Einsatzbedingungen beim Hersteller zusätzliche Hinweise zu erfragen und zu beachten.
<G-vec00272-001-s259><ask.erfragen><en> Please note that you have to ask for your affiliate’s bank details and then make the payout yourself.
<G-vec00272-001-s259><ask.erfragen><de> Bitte beachten Sie, dass Sie die Bankverbindung Ihres Affiliates gegebenenfalls erfragen müssen und Sie selbst die Auszahlung vornehmen.
<G-vec00272-001-s260><ask.erfragen><en> Later when the family went to the police station to ask about Mr. Sun's arrest, they were told he was not there.
<G-vec00272-001-s260><ask.erfragen><de> Später, als die Familie zur Polizeistation kam, um die Hintergründe der Verhaftung zu erfragen, wurde ihnen gesagt, dass er nicht da sei.
<G-vec00272-001-s261><ask.erfragen><en> These spacious and quiet rooms offer free use of the minibar and free telephone calls up to a set limit (please ask upon check-in).
<G-vec00272-001-s261><ask.erfragen><de> In diesen geräumigen und ruhigen Zimmern nutzen Sie die Minibar kostenfrei und führen kostenlose Telefonate bis zu einem bestimmten Wert (bitte beim Check-in erfragen).
<G-vec00272-001-s262><ask.erfragen><en> A self-service breakfast, Dutch specialties, cereals, juices and fresh fruit will be stoked in the fridge upon request, ask for rates.
<G-vec00272-001-s262><ask.erfragen><de> Ein Selbstbedienungs-Frühstück, holländische Spezialitäten, Müsli, Säfte und frisches Obst wird geschürt werden, im Kühlschrank auf Anfrage, Preise erfragen.
<G-vec00272-001-s263><ask.erfragen><en> Recommended filling weight: 60 kg (Please ask if higher payload is requested).
<G-vec00272-001-s263><ask.erfragen><de> Hinzugefügt am: 13.02.2019 Empfohlenes Füllgewicht: 60 kg (Höhere Zuladung erfragen).
<G-vec00272-001-s264><ask.erfragen><en> Here the focus is on the one hand to provide as much information as possible, on the other hand to ask for and discuss the concerns and needs of the local residents and to incorporate the information and results into the planning process.
<G-vec00272-001-s264><ask.erfragen><de> Dabei geht es einerseits um eine möglichst umfassende Information, andererseits darum, die Sorgen und Befürchtungen der AnrainerInnen zu erfragen, zu diskutieren und die formulierten Bedürfnisse in die Planungen einfließen zu lassen.
<G-vec00272-001-s265><ask.erfragen><en> All kinds of bikes, maintenance and repair service; ask for special offers in the shop.
<G-vec00272-001-s265><ask.erfragen><de> Fahrräder aller Art, Wartungs- und Reparaturservice, Sonderangebote im Shop erfragen.
<G-vec00384-001-s247><ask.erfragen><en> One thing we ask before reporting a ticket is to do a quick google search and see if your problem has been discussed on the forums or bug tracker previously.
<G-vec00384-001-s247><ask.erfragen><de> Eine Sache, die wir erfragen bevor Sie einen Vorgang (Ticket) berichten, ist eine schnelle Suche bei einer Suchmaschine (auch Google) und schauen Sie, ob Ihr Problem vorher im Forum oder der Fehlerverfolgung (Bug Tracker) diskutiert wurde.
<G-vec00384-001-s248><ask.erfragen><en> If the Bot wants to ask the desired travel class, but the user just remembers and states that he seeks to reserve a table at his favorite Italian Restaurant, the Virtual Agent can master this context change.
<G-vec00384-001-s248><ask.erfragen><de> Wenn der Chatbot die gewünschte Bahnklasse erfragen möchte, dem Nutzer aber gerade einfällt, dass er einen Tisch bei seinem Lieblingsitaliener reservieren muss, wäre der Virtual Agent in der Lage diesen Kontextwechsel zu meistern und anschließend zum vorhergehenden Anliegen wieder zurückzukehren.
<G-vec00384-001-s249><ask.erfragen><en> Please ask for these fees with your local customs office.
<G-vec00384-001-s249><ask.erfragen><de> Bitte erfragen Sie diese Gebühren bei Ihrem Zollamt vor Ort.
<G-vec00384-001-s250><ask.erfragen><en> We will ask and use your personal data exclusively for the processing of the order.
<G-vec00384-001-s250><ask.erfragen><de> Wir werden Ihre persönlichen Daten ausschließlich zur Abwicklung der Bestellung erfragen und verwenden.
<G-vec00384-001-s251><ask.erfragen><en> Therefore the state is holding hearings to ask experts and citizens for their opinions on how to determine a two-month supply.
<G-vec00384-001-s251><ask.erfragen><de> Daher führt der Staat Anhörungen durch, um die Meinungen von Experten und Bürgern zu erfragen, wie ein zweimonatiger Vorrat bestimmt werden sollte.
<G-vec00384-001-s252><ask.erfragen><en> We have to always maintain our contact with God, we must know his will and sometimes we have to ask him directly.
<G-vec00384-001-s252><ask.erfragen><de> Unser Kontakt mit Gott muss immer aufrecht erhalten werden, wir müssen sein Wort kennen und wir müssen seinen Willen manchmal direkt von ihm erfragen.
<G-vec00384-001-s253><ask.erfragen><en> For the use of such cookies we will ask your consent at the beginning of the use of our website, so that the use of such cookies is covered by Art.
<G-vec00384-001-s253><ask.erfragen><de> Für die Verwendung derartiger Cookies werden wir zu Beginn der Nutzung unserer Website Ihr Einverständnis erfragen, so dass der Einsatz solcher Cookies von Art.
<G-vec00384-001-s254><ask.erfragen><en> Please ask for prices.
<G-vec00384-001-s254><ask.erfragen><de> Bitte erfragen Sie die Preise.
<G-vec00384-001-s255><ask.erfragen><en> Like Article 101B but used. Price depending on condition - please ask.
<G-vec00384-001-s255><ask.erfragen><de> Wie Auspuffendtopfsatz 101B, aber gebraucht, Preis je nach Zustand, bitte erfragen.
<G-vec00384-001-s256><ask.erfragen><en> If you have not provided PayPal with a postal address to which we can send the receipt, we will ask for this by e-mail.
<G-vec00384-001-s256><ask.erfragen><de> Sofern Sie bei PayPal keine Postadresse angeben, an die wir die Spendenquittung schicken können, erfragen wir diese von Ihnen per E-Mail.
<G-vec00384-001-s257><ask.erfragen><en> Creating an account means that we do not have to ask for your details for each individual assignment.
<G-vec00384-001-s257><ask.erfragen><de> Durch Eröffnung eines Kontos müssen wir nicht für jeden einzelnen Auftrag Ihre Daten erfragen.
<G-vec00384-001-s258><ask.erfragen><en> If round slings, hoisting belts, lashing straps are used in conjunction with chemicals, please tell the manufacturer the certain application and conditions of use and ask the manufacturer for additional instructions and observe them.
<G-vec00384-001-s258><ask.erfragen><de> Sollen Rundschlingen, Hebebänder, Zurrgurte in Verbindung mit Chemikalien verwendet werden, sind unter Angabe von Einsatzdauer und Einsatzbedingungen beim Hersteller zusätzliche Hinweise zu erfragen und zu beachten.
<G-vec00384-001-s259><ask.erfragen><en> Please note that you have to ask for your affiliate’s bank details and then make the payout yourself.
<G-vec00384-001-s259><ask.erfragen><de> Bitte beachten Sie, dass Sie die Bankverbindung Ihres Affiliates gegebenenfalls erfragen müssen und Sie selbst die Auszahlung vornehmen.
<G-vec00384-001-s260><ask.erfragen><en> Later when the family went to the police station to ask about Mr. Sun's arrest, they were told he was not there.
<G-vec00384-001-s260><ask.erfragen><de> Später, als die Familie zur Polizeistation kam, um die Hintergründe der Verhaftung zu erfragen, wurde ihnen gesagt, dass er nicht da sei.
<G-vec00384-001-s261><ask.erfragen><en> These spacious and quiet rooms offer free use of the minibar and free telephone calls up to a set limit (please ask upon check-in).
<G-vec00384-001-s261><ask.erfragen><de> In diesen geräumigen und ruhigen Zimmern nutzen Sie die Minibar kostenfrei und führen kostenlose Telefonate bis zu einem bestimmten Wert (bitte beim Check-in erfragen).
<G-vec00384-001-s262><ask.erfragen><en> A self-service breakfast, Dutch specialties, cereals, juices and fresh fruit will be stoked in the fridge upon request, ask for rates.
<G-vec00384-001-s262><ask.erfragen><de> Ein Selbstbedienungs-Frühstück, holländische Spezialitäten, Müsli, Säfte und frisches Obst wird geschürt werden, im Kühlschrank auf Anfrage, Preise erfragen.
<G-vec00384-001-s263><ask.erfragen><en> Recommended filling weight: 60 kg (Please ask if higher payload is requested).
<G-vec00384-001-s263><ask.erfragen><de> Hinzugefügt am: 13.02.2019 Empfohlenes Füllgewicht: 60 kg (Höhere Zuladung erfragen).
<G-vec00384-001-s264><ask.erfragen><en> Here the focus is on the one hand to provide as much information as possible, on the other hand to ask for and discuss the concerns and needs of the local residents and to incorporate the information and results into the planning process.
<G-vec00384-001-s264><ask.erfragen><de> Dabei geht es einerseits um eine möglichst umfassende Information, andererseits darum, die Sorgen und Befürchtungen der AnrainerInnen zu erfragen, zu diskutieren und die formulierten Bedürfnisse in die Planungen einfließen zu lassen.
<G-vec00384-001-s265><ask.erfragen><en> All kinds of bikes, maintenance and repair service; ask for special offers in the shop.
<G-vec00384-001-s265><ask.erfragen><de> Fahrräder aller Art, Wartungs- und Reparaturservice, Sonderangebote im Shop erfragen.
<G-vec00272-001-s285><ask.fordern><en> This enables you to ask us to delete or remove personal information where there is no good reason for us continuing to process it.
<G-vec00272-001-s285><ask.fordern><de> Dies ermöglicht es Ihnen, von uns zu fordern, personenbezogene Daten zu löschen oder zu entfernen, wenn es keinen triftigen Grund dafür gibt, dass wir sie weiterhin verarbeiten.
<G-vec00272-001-s286><ask.fordern><en> Please ask for a quote at sales@trenz-electronic.de.
<G-vec00272-001-s286><ask.fordern><de> Bitte fordern Sie ein Angebot an: sales (at) trenz-electronic.de.
<G-vec00272-001-s287><ask.fordern><en> 29:54 They ask you to hasten on the chastisement, and most surely hell encompasses the unbelievers;
<G-vec00272-001-s287><ask.fordern><de> Und g 29:54 Sie fordern dich zur Eile mit der Peinigung auf.
<G-vec00272-001-s288><ask.fordern><en> To this end, we ask the Commission not to add an endorsement of (F)RAND licensing policies for software standards.
<G-vec00272-001-s288><ask.fordern><de> Daher fordern wir die Kommission auf, keine Billigung von (F)RAND-Lizenzierungen für Software-Standards in den EIF aufzunehmen.
<G-vec00272-001-s289><ask.fordern><en> 12 And Ahaz said, I will not ask, and will not tempt Jehovah.
<G-vec00272-001-s289><ask.fordern><de> 12 Aber Ahas sprach: Ich will's nicht fordern, daß ich den HErrn nicht versuche.
<G-vec00272-001-s290><ask.fordern><en> If Canada increases access for EU cheese imports, the precedent will make it easier for Europe to ask for even greater access in the future.
<G-vec00272-001-s290><ask.fordern><de> Wenn Kanada den Zugang für Käseeinfuhren aus der EU ausweitet, schafft das einen Präzedenzfall, der es Europa leichter macht, künftig einen noch breiteren Zugang zu fordern.
<G-vec00272-001-s291><ask.fordern><en> "When practitioners start practising Falun Gong, they ask themselves to fulfil the standards of ""truthfulness, benevolence and forbearance""."
<G-vec00272-001-s291><ask.fordern><de> "Menschen, die mit dem Praktizieren von Falun Gong beginnen, fordern von sich selbst nach den Prinzipien ""Wahrhaftigkeit, Barmherzigkeit, Nachsicht"" zu leben."
<G-vec00272-001-s292><ask.fordern><en> They ask students and workers to accept mobility and then do not provide the support necessary.
<G-vec00272-001-s292><ask.fordern><de> Sie fordern Studierende und Arbeitnehmer auf, Mobilität zu akzeptieren, und stellen die notwendige Unterstützung nicht bereit.
<G-vec00272-001-s293><ask.fordern><en> If you want to take full advantage of the sharing features we offer, we might also ask you to create a publicly visible ANIMEGG Profile, which may include your name and photo.
<G-vec00272-001-s293><ask.fordern><de> Falls Sie die von uns angebotenen Funktionen zum Teilen von Inhalten in vollem Umfang nutzen möchten, fordern wir Sie möglicherweise auch dazu auf, ein öffentlich einsehbares Google-Profil zu erstellen, das auch Ihren Namen und Ihr Foto beinhalten kann.
<G-vec00272-001-s294><ask.fordern><en> And again, no voice was raised in Parliament to ask that Italy should observe the non-proliferation Treaty and adhere to that of the UNO concerning the ban on nuclear weapons, forcing the USA to withdraw from our national territory its B61 nuclear bombs and not to install, from the first half of 2020, the even more dangerous B61-12's.
<G-vec00272-001-s294><ask.fordern><de> Und wieder wurde im Parlament keine Stimme erhoben, um zu fordern, dass Italien den Atomwaffensperrvertrag einhält und sich an die UNO bezüglich des Verbots von Kernwaffen hält, das die USA zwingt, ihre Atombomben B61 aus unserem Staatsgebiet abzuziehen und die noch gefährlicheren B61-12 nicht ab dem ersten Halbjahr 2020 zu installieren.
<G-vec00272-001-s295><ask.fordern><en> Please ask for our special tariff.
<G-vec00272-001-s295><ask.fordern><de> Fordern Sie dazu unsere spezielle Preisliste an.
<G-vec00272-001-s296><ask.fordern><en> "As to the reason he said, ""Jiang has led the officials to ask for bribes."
<G-vec00272-001-s296><ask.fordern><de> "Als Grund führte er an, ""Jiang hat die Beamten dazu geführt, Bestechungsgeldern zu fordern."
<G-vec00272-001-s297><ask.fordern><en> For instance they ask city Councilors not to go to events where Falun Gong information is coming out in various cities around the world saying it would effect economic relations between that city and China,” Matas said.
<G-vec00272-001-s297><ask.fordern><de> Zum Beispiel fordern sie Stadträte auf, nicht zu Veranstaltungen zu gehen, auf denen es in den verschiedenen Städten auf der ganzen Welt Falun Gong Informationen gibt, drohen an, es würde die ökonomischen Beziehungen zwischen China und jener Stadt beeinträchtigen“, sagte Matas.
<G-vec00272-001-s298><ask.fordern><en> Four years after Julian Assange passed through the gates of the Ecuadorian Embassy in London and was forced to seek asylum, people from all over the world joined their voices in order to ask that this persecution be brought to to an end.
<G-vec00272-001-s298><ask.fordern><de> Vier Jahre, nachdem Julian Assange durch die Tore der ecuadorianischen Botschaft in London geführt wurde, gezwungen Asyl zu suchen, vereinigen sich Menschen weltweit und werden zu einer Stimme, um zu fordern, dass die Verfolgung beendet werden soll.
<G-vec00272-001-s299><ask.fordern><en> And Ahaz said, I will not ask, and will not tempt Jehovah.
<G-vec00272-001-s299><ask.fordern><de> Ahas aber sagte: Ich will nicht fordern und will den HERRN nicht prüfen.
<G-vec00272-001-s300><ask.fordern><en> In case of doubt ask them for a free quote first and check the details before you book your car online.
<G-vec00272-001-s300><ask.fordern><de> Im Zweifelsfall fordern Sie ein unverbindliches Angebot an, um erst Mal in aller Ruhe alle Einzelheiten zu überprüfen, bevor Sie Ihr Auto online buchen.
<G-vec00272-001-s301><ask.fordern><en> "We therefore ask you to report ""Long-tailed Tit (A. c. caudatus)"" only for well observed / documented individuals."
<G-vec00272-001-s301><ask.fordern><de> "Wir fordern daher alle BeobachterInnen auf, nur gut gesehene und/oder dokumentierte Vögel als ""Schwanzmeise (A. c. caudatus)"" zu melden."
<G-vec00272-001-s302><ask.fordern><en> We ask people to let go of self-interest, feelings, and concern for renown.
<G-vec00272-001-s302><ask.fordern><de> Wir fordern Menschen auf, Ruhm, Reichtum und Gefühle loszulassen.
<G-vec00272-001-s303><ask.fordern><en> Ask us for a report for your insurance company as proof of any loss, damage or delay that may have occurred.
<G-vec00272-001-s303><ask.fordern><de> Fordern Sie als Nachweis für aufgetretene Verluste, Beschädigungen oder Verspätungen einen Bericht bei uns an.
<G-vec00384-001-s285><ask.fordern><en> This enables you to ask us to delete or remove personal information where there is no good reason for us continuing to process it.
<G-vec00384-001-s285><ask.fordern><de> Dies ermöglicht es Ihnen, von uns zu fordern, personenbezogene Daten zu löschen oder zu entfernen, wenn es keinen triftigen Grund dafür gibt, dass wir sie weiterhin verarbeiten.
<G-vec00384-001-s286><ask.fordern><en> Please ask for a quote at sales@trenz-electronic.de.
<G-vec00384-001-s286><ask.fordern><de> Bitte fordern Sie ein Angebot an: sales (at) trenz-electronic.de.
<G-vec00384-001-s287><ask.fordern><en> 29:54 They ask you to hasten on the chastisement, and most surely hell encompasses the unbelievers;
<G-vec00384-001-s287><ask.fordern><de> Und g 29:54 Sie fordern dich zur Eile mit der Peinigung auf.
<G-vec00384-001-s288><ask.fordern><en> To this end, we ask the Commission not to add an endorsement of (F)RAND licensing policies for software standards.
<G-vec00384-001-s288><ask.fordern><de> Daher fordern wir die Kommission auf, keine Billigung von (F)RAND-Lizenzierungen für Software-Standards in den EIF aufzunehmen.
<G-vec00384-001-s289><ask.fordern><en> 12 And Ahaz said, I will not ask, and will not tempt Jehovah.
<G-vec00384-001-s289><ask.fordern><de> 12 Aber Ahas sprach: Ich will's nicht fordern, daß ich den HErrn nicht versuche.
<G-vec00384-001-s290><ask.fordern><en> If Canada increases access for EU cheese imports, the precedent will make it easier for Europe to ask for even greater access in the future.
<G-vec00384-001-s290><ask.fordern><de> Wenn Kanada den Zugang für Käseeinfuhren aus der EU ausweitet, schafft das einen Präzedenzfall, der es Europa leichter macht, künftig einen noch breiteren Zugang zu fordern.
<G-vec00384-001-s291><ask.fordern><en> "When practitioners start practising Falun Gong, they ask themselves to fulfil the standards of ""truthfulness, benevolence and forbearance""."
<G-vec00384-001-s291><ask.fordern><de> "Menschen, die mit dem Praktizieren von Falun Gong beginnen, fordern von sich selbst nach den Prinzipien ""Wahrhaftigkeit, Barmherzigkeit, Nachsicht"" zu leben."
<G-vec00384-001-s292><ask.fordern><en> They ask students and workers to accept mobility and then do not provide the support necessary.
<G-vec00384-001-s292><ask.fordern><de> Sie fordern Studierende und Arbeitnehmer auf, Mobilität zu akzeptieren, und stellen die notwendige Unterstützung nicht bereit.
<G-vec00384-001-s293><ask.fordern><en> If you want to take full advantage of the sharing features we offer, we might also ask you to create a publicly visible ANIMEGG Profile, which may include your name and photo.
<G-vec00384-001-s293><ask.fordern><de> Falls Sie die von uns angebotenen Funktionen zum Teilen von Inhalten in vollem Umfang nutzen möchten, fordern wir Sie möglicherweise auch dazu auf, ein öffentlich einsehbares Google-Profil zu erstellen, das auch Ihren Namen und Ihr Foto beinhalten kann.
<G-vec00384-001-s294><ask.fordern><en> And again, no voice was raised in Parliament to ask that Italy should observe the non-proliferation Treaty and adhere to that of the UNO concerning the ban on nuclear weapons, forcing the USA to withdraw from our national territory its B61 nuclear bombs and not to install, from the first half of 2020, the even more dangerous B61-12's.
<G-vec00384-001-s294><ask.fordern><de> Und wieder wurde im Parlament keine Stimme erhoben, um zu fordern, dass Italien den Atomwaffensperrvertrag einhält und sich an die UNO bezüglich des Verbots von Kernwaffen hält, das die USA zwingt, ihre Atombomben B61 aus unserem Staatsgebiet abzuziehen und die noch gefährlicheren B61-12 nicht ab dem ersten Halbjahr 2020 zu installieren.
<G-vec00384-001-s295><ask.fordern><en> Please ask for our special tariff.
<G-vec00384-001-s295><ask.fordern><de> Fordern Sie dazu unsere spezielle Preisliste an.
<G-vec00384-001-s296><ask.fordern><en> "As to the reason he said, ""Jiang has led the officials to ask for bribes."
<G-vec00384-001-s296><ask.fordern><de> "Als Grund führte er an, ""Jiang hat die Beamten dazu geführt, Bestechungsgeldern zu fordern."
<G-vec00384-001-s297><ask.fordern><en> For instance they ask city Councilors not to go to events where Falun Gong information is coming out in various cities around the world saying it would effect economic relations between that city and China,” Matas said.
<G-vec00384-001-s297><ask.fordern><de> Zum Beispiel fordern sie Stadträte auf, nicht zu Veranstaltungen zu gehen, auf denen es in den verschiedenen Städten auf der ganzen Welt Falun Gong Informationen gibt, drohen an, es würde die ökonomischen Beziehungen zwischen China und jener Stadt beeinträchtigen“, sagte Matas.
<G-vec00384-001-s298><ask.fordern><en> Four years after Julian Assange passed through the gates of the Ecuadorian Embassy in London and was forced to seek asylum, people from all over the world joined their voices in order to ask that this persecution be brought to to an end.
<G-vec00384-001-s298><ask.fordern><de> Vier Jahre, nachdem Julian Assange durch die Tore der ecuadorianischen Botschaft in London geführt wurde, gezwungen Asyl zu suchen, vereinigen sich Menschen weltweit und werden zu einer Stimme, um zu fordern, dass die Verfolgung beendet werden soll.
<G-vec00384-001-s299><ask.fordern><en> And Ahaz said, I will not ask, and will not tempt Jehovah.
<G-vec00384-001-s299><ask.fordern><de> Ahas aber sagte: Ich will nicht fordern und will den HERRN nicht prüfen.
<G-vec00384-001-s300><ask.fordern><en> In case of doubt ask them for a free quote first and check the details before you book your car online.
<G-vec00384-001-s300><ask.fordern><de> Im Zweifelsfall fordern Sie ein unverbindliches Angebot an, um erst Mal in aller Ruhe alle Einzelheiten zu überprüfen, bevor Sie Ihr Auto online buchen.
<G-vec00384-001-s301><ask.fordern><en> "We therefore ask you to report ""Long-tailed Tit (A. c. caudatus)"" only for well observed / documented individuals."
<G-vec00384-001-s301><ask.fordern><de> "Wir fordern daher alle BeobachterInnen auf, nur gut gesehene und/oder dokumentierte Vögel als ""Schwanzmeise (A. c. caudatus)"" zu melden."
<G-vec00384-001-s302><ask.fordern><en> We ask people to let go of self-interest, feelings, and concern for renown.
<G-vec00384-001-s302><ask.fordern><de> Wir fordern Menschen auf, Ruhm, Reichtum und Gefühle loszulassen.
<G-vec00384-001-s303><ask.fordern><en> Ask us for a report for your insurance company as proof of any loss, damage or delay that may have occurred.
<G-vec00384-001-s303><ask.fordern><de> Fordern Sie als Nachweis für aufgetretene Verluste, Beschädigungen oder Verspätungen einen Bericht bei uns an.
<G-vec00272-001-s304><ask.fordern><en> If you are thinking of emphasizing the corporate identity of your company in your own individual colours or would like to differentiate tests from one another, then why not ask for the stool sample preparation device in your colours.
<G-vec00272-001-s304><ask.fordern><de> Sie beabsichtigen die Corporate Identity Ihres Unternehmens in Ihren individuellen Farben zu unterstreichen, oder Sie wollen Ihre unterschiedlichen Testarten voneinander abgrenzen, dann fordern Sie das Stuhlaufbereitungsröhrchen in Ihren Farben an.
<G-vec00272-001-s305><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Dell SFP-10G-ER-DE compatible 10GBASE-ER Transceiver SFP+ Duplex SFP+s without any risk of loss of functionality.
<G-vec00272-001-s305><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Dell SFP-10G-ER-DE kompatiblen 10GBASE-ER LC Duplex SFP+s von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s306><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's #not found: Original-Vendor 2498-X24-2602 compatible #not found: Main-Application Duplex #not found: Formfactors without any risk of loss of functionality.
<G-vec00272-001-s306><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der #not found: Original-Hersteller 2498-X24-2602 kompatiblen #not found: Hauptanwendung #not found: Anschluss #not found: Formfaktors von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s307><ask.fordern><en> Ask participants applauded when Oga throw a marker to the north, sa du markers you are caught again by hand, som du kan se mer om requested stop clapping.
<G-vec00272-001-s307><ask.fordern><de> Fordern Sie die Teilnehmer applaudierten, wenn Oga einen Marker im Norden werfen, sa du Marker Sie wieder von Hand gefangen werden, som du kan se mer om angeforderte Stopp Klatschen.
<G-vec00272-001-s308><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Alcatel-Lucent SFP-10G-SR-AL compatible 10GBASE-SR Duplex SFP+s without any risk of loss of functionality.
<G-vec00272-001-s308><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Alcatel-Lucent SFP-10G-SR-AL kompatiblen 10GBASE-SR LC Duplex SFP+s von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s309><ask.fordern><en> If you are interested just contact us and ask for a non-committal offer of an in-house statistic course.
<G-vec00272-001-s309><ask.fordern><de> Bei Interesse kontaktieren Sie uns einfach und fordern Sie eine unverbindliche Offerte zu einem In-House-Statistik-Kurs an.
<G-vec00272-001-s310><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Mellanox QSFP-4SFP10G-MC-007 compatible 40GBASE-SR4 7 Meter QSFP Breakout AOCs without any risk of loss of functionality.
<G-vec00272-001-s310><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den Vorteilen der Mellanox QSFP-4SFP10G-MC-007 kompatiblen 40GBASE-SR4 7 Meter QSFP Breakout AOCs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s311><ask.fordern><en> If not, please contact DSD.net and ask for your free JobTimer 2.0 match code update.
<G-vec00272-001-s311><ask.fordern><de> Wenn nicht, wenden Sie sich bitte an DSD.net und fordern Sie Ihr Matchcode-Update für Jobtimer 2.30 an.
<G-vec00272-001-s312><ask.fordern><en> Visit us and ask for the coupon valid until 2017. Photographs
<G-vec00272-001-s312><ask.fordern><de> Besuchen Sie uns und fordern Sie den Gutschein gültig bis 2017.
<G-vec00272-001-s313><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Huawei QSFP-100G-SR4-HU compatible 100GBASE-SR4 Transceiver QSFP28 Duplex-MPO-MTP QSFP28s without any risk of loss of functionality.
<G-vec00272-001-s313><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Huawei QSFP-100G-SR4-HU kompatiblen 100GBASE-SR4 MPO/MTP QSFP28s von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s314><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's BlueOptics BO31H13610D compatible 2/4/8GBASE-LW Duplex XFPs without any risk of loss of functionality.
<G-vec00272-001-s314><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der BlueOptics BO31H13610D kompatiblen 2/4/8GBASE-LW LC Duplex XFPs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s315><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's #not found: Original-Vendor BO253503K30M compatible 40GBASE-SR4 30 Meter Aktive Optische Kabel (AOC) QSFP Breakout AOCs without any risk of loss of functionality.
<G-vec00272-001-s315><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den Vorteilen der #not found: Original-Hersteller BO253503K30M kompatiblen 40GBASE-SR4 30 Meter QSFP Breakout AOCs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s316><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Huawei QSFP-4SFP10-AOC3M compatible 40GBASE-SR4 3 Meter QSFP Breakout AOCs without any risk of loss of functionality.
<G-vec00272-001-s316><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den Vorteilen der Huawei QSFP-4SFP10-AOC3M kompatiblen 40GBASE-SR4 3 Meter QSFP Breakout AOCs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s317><ask.fordern><en> Just fall back on our standard methods or ask us for survey types designed specially for you.
<G-vec00272-001-s317><ask.fordern><de> Greifen Sie einfach auf unsere Standardmethoden zurück oder fordern Sie uns durch speziell für Sie entwickelte Befragungstypen.
<G-vec00272-001-s318><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's BlueOptics BO15B3149620D compatible SONET OC-12 / SDH STM-4 Transceiver SFP Bidi SFPs without any risk of loss of functionality.
<G-vec00272-001-s318><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der BlueOptics BO15B3149620D kompatiblen SONET OC-12 / SDH STM-4 LC Simplex SFPs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s319><ask.fordern><en> Ask women to tell them.
<G-vec00272-001-s319><ask.fordern><de> Fordern Sie Frauen auf sie zu erzählen.
<G-vec00272-001-s320><ask.fordern><en> - AF 50: Please ask for the special AF 50 colour chart or see the colours shown in the product group INTERIOR VENETIAN BLINDS 50,60,80 mm.
<G-vec00272-001-s320><ask.fordern><de> - AF 50: Bitte fordern Sie die spezielle AF 50 Farbtabelle an oder siehe dargestellte Farben in Produktgruppe INNENJALOUSIEN 50,60,80 mm.
<G-vec00272-001-s321><ask.fordern><en> Ask for advices from doctors as they are the ones who can give you assurance that will lessen the burden that you and your partner is facing.
<G-vec00272-001-s321><ask.fordern><de> Fordern Sie Ratschläge von Ärzten, wie sie sind diejenigen, die Ihnen Sicherheit, dass die Last, die Sie und Ihr Partner steht vor vermindern geben können.
<G-vec00272-001-s322><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Juniper QSFPP-4X10GE-LR compatible 40GBASE-PLR4 Duplex-MPO-MTP QSFPs without any risk of loss of functionality.
<G-vec00272-001-s322><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Juniper QSFPP-4X10GE-LR kompatiblen 40GBASE-PLR4 MPO/MTP QSFPs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s304><ask.fordern><en> If you are thinking of emphasizing the corporate identity of your company in your own individual colours or would like to differentiate tests from one another, then why not ask for the stool sample preparation device in your colours.
<G-vec00384-001-s304><ask.fordern><de> Sie beabsichtigen die Corporate Identity Ihres Unternehmens in Ihren individuellen Farben zu unterstreichen, oder Sie wollen Ihre unterschiedlichen Testarten voneinander abgrenzen, dann fordern Sie das Stuhlaufbereitungsröhrchen in Ihren Farben an.
<G-vec00384-001-s305><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Dell SFP-10G-ER-DE compatible 10GBASE-ER Transceiver SFP+ Duplex SFP+s without any risk of loss of functionality.
<G-vec00384-001-s305><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Dell SFP-10G-ER-DE kompatiblen 10GBASE-ER LC Duplex SFP+s von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s306><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's #not found: Original-Vendor 2498-X24-2602 compatible #not found: Main-Application Duplex #not found: Formfactors without any risk of loss of functionality.
<G-vec00384-001-s306><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der #not found: Original-Hersteller 2498-X24-2602 kompatiblen #not found: Hauptanwendung #not found: Anschluss #not found: Formfaktors von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s307><ask.fordern><en> Ask participants applauded when Oga throw a marker to the north, sa du markers you are caught again by hand, som du kan se mer om requested stop clapping.
<G-vec00384-001-s307><ask.fordern><de> Fordern Sie die Teilnehmer applaudierten, wenn Oga einen Marker im Norden werfen, sa du Marker Sie wieder von Hand gefangen werden, som du kan se mer om angeforderte Stopp Klatschen.
<G-vec00384-001-s308><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Alcatel-Lucent SFP-10G-SR-AL compatible 10GBASE-SR Duplex SFP+s without any risk of loss of functionality.
<G-vec00384-001-s308><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Alcatel-Lucent SFP-10G-SR-AL kompatiblen 10GBASE-SR LC Duplex SFP+s von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s309><ask.fordern><en> If you are interested just contact us and ask for a non-committal offer of an in-house statistic course.
<G-vec00384-001-s309><ask.fordern><de> Bei Interesse kontaktieren Sie uns einfach und fordern Sie eine unverbindliche Offerte zu einem In-House-Statistik-Kurs an.
<G-vec00384-001-s310><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Mellanox QSFP-4SFP10G-MC-007 compatible 40GBASE-SR4 7 Meter QSFP Breakout AOCs without any risk of loss of functionality.
<G-vec00384-001-s310><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den Vorteilen der Mellanox QSFP-4SFP10G-MC-007 kompatiblen 40GBASE-SR4 7 Meter QSFP Breakout AOCs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s311><ask.fordern><en> If not, please contact DSD.net and ask for your free JobTimer 2.0 match code update.
<G-vec00384-001-s311><ask.fordern><de> Wenn nicht, wenden Sie sich bitte an DSD.net und fordern Sie Ihr Matchcode-Update für Jobtimer 2.30 an.
<G-vec00384-001-s312><ask.fordern><en> Visit us and ask for the coupon valid until 2017. Photographs
<G-vec00384-001-s312><ask.fordern><de> Besuchen Sie uns und fordern Sie den Gutschein gültig bis 2017.
<G-vec00384-001-s313><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Huawei QSFP-100G-SR4-HU compatible 100GBASE-SR4 Transceiver QSFP28 Duplex-MPO-MTP QSFP28s without any risk of loss of functionality.
<G-vec00384-001-s313><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Huawei QSFP-100G-SR4-HU kompatiblen 100GBASE-SR4 MPO/MTP QSFP28s von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s314><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's BlueOptics BO31H13610D compatible 2/4/8GBASE-LW Duplex XFPs without any risk of loss of functionality.
<G-vec00384-001-s314><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der BlueOptics BO31H13610D kompatiblen 2/4/8GBASE-LW LC Duplex XFPs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s315><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's #not found: Original-Vendor BO253503K30M compatible 40GBASE-SR4 30 Meter Aktive Optische Kabel (AOC) QSFP Breakout AOCs without any risk of loss of functionality.
<G-vec00384-001-s315><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den Vorteilen der #not found: Original-Hersteller BO253503K30M kompatiblen 40GBASE-SR4 30 Meter QSFP Breakout AOCs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s316><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Huawei QSFP-4SFP10-AOC3M compatible 40GBASE-SR4 3 Meter QSFP Breakout AOCs without any risk of loss of functionality.
<G-vec00384-001-s316><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den Vorteilen der Huawei QSFP-4SFP10-AOC3M kompatiblen 40GBASE-SR4 3 Meter QSFP Breakout AOCs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s317><ask.fordern><en> Just fall back on our standard methods or ask us for survey types designed specially for you.
<G-vec00384-001-s317><ask.fordern><de> Greifen Sie einfach auf unsere Standardmethoden zurück oder fordern Sie uns durch speziell für Sie entwickelte Befragungstypen.
<G-vec00384-001-s318><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's BlueOptics BO15B3149620D compatible SONET OC-12 / SDH STM-4 Transceiver SFP Bidi SFPs without any risk of loss of functionality.
<G-vec00384-001-s318><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der BlueOptics BO15B3149620D kompatiblen SONET OC-12 / SDH STM-4 LC Simplex SFPs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00384-001-s319><ask.fordern><en> Ask women to tell them.
<G-vec00384-001-s319><ask.fordern><de> Fordern Sie Frauen auf sie zu erzählen.
<G-vec00384-001-s320><ask.fordern><en> - AF 50: Please ask for the special AF 50 colour chart or see the colours shown in the product group INTERIOR VENETIAN BLINDS 50,60,80 mm.
<G-vec00384-001-s320><ask.fordern><de> - AF 50: Bitte fordern Sie die spezielle AF 50 Farbtabelle an oder siehe dargestellte Farben in Produktgruppe INNENJALOUSIEN 50,60,80 mm.
<G-vec00384-001-s321><ask.fordern><en> Ask for advices from doctors as they are the ones who can give you assurance that will lessen the burden that you and your partner is facing.
<G-vec00384-001-s321><ask.fordern><de> Fordern Sie Ratschläge von Ärzten, wie sie sind diejenigen, die Ihnen Sicherheit, dass die Last, die Sie und Ihr Partner steht vor vermindern geben können.
<G-vec00384-001-s322><ask.fordern><en> If you would like to be convinced of the nature and functionality, ask for your personal sample for testing purposes now and profit from the advantages of CBO's Juniper QSFPP-4X10GE-LR compatible 40GBASE-PLR4 Duplex-MPO-MTP QSFPs without any risk of loss of functionality.
<G-vec00384-001-s322><ask.fordern><de> Sollten Sie sich von der Beschaffenheit und Funktionsweise überzeugen wollen, fordern Sie jetzt Ihr persönliches Sample zur Bemusterung an und profitieren Sie von den preislichen Vorteilen der Juniper QSFPP-4X10GE-LR kompatiblen 40GBASE-PLR4 MPO/MTP QSFPs von CBO ohne das Risiko von Funktionseinbußen.
<G-vec00272-001-s323><ask.fragen><en> Of course, you will also want to assess your hosting service, so ask yourself if you are happy with the overall service provided.
<G-vec00272-001-s323><ask.fragen><de> Natürlich wirst du auch deinen Hosting-Service bewerten wollen, also frag dich, ob du mit dem gesamten Service zufrieden bist.
<G-vec00272-001-s324><ask.fragen><en> I ask about foreign attachments and in most cases it's yes.
<G-vec00272-001-s324><ask.fragen><de> Dann frag ich ab auf fremde Ankopplung und fast immer kommt ja.
<G-vec00272-001-s325><ask.fragen><en> "Ask the people who were leading that struggle in the plants, on the ground."""
<G-vec00272-001-s325><ask.fragen><de> "Frag die Leute, die den Streik in den Betrieben, vor Ort, geführt haben""."
<G-vec00272-001-s326><ask.fragen><en> Ask around to find out who else is as excited to make a difference as you are.
<G-vec00272-001-s326><ask.fragen><de> Frag herum und finde Menschen, die ebenso wie du einen Unterschied machen wollen.
<G-vec00272-001-s327><ask.fragen><en> So when the messenger came to him, he said: Go back to your lord and ask him, what is the case of the women who cut their hands; surely my Lord knows their guile.
<G-vec00272-001-s327><ask.fragen><de> "Als der Bote zu ihm kam, sagte er: ""Kehr zu deinem Herrn zurück und frag ihn, wie es mit den Frauen steht, die sich ihre Hände zerschnitten."
<G-vec00272-001-s328><ask.fragen><en> “If you doubt what We have revealed to you, ask those who have read the Scriptures before you.” (Koran X; Jonah,94)
<G-vec00272-001-s328><ask.fragen><de> “Wenn du über das, was zu dir als Offenbarung herabgesandt worden ist im Zweifel bist, dann frag diejenigen, welche die Schriften, die früher herabgesandt worden sind, lesen” (Koran 10; Jonas 94).
<G-vec00272-001-s329><ask.fragen><en> Ask a parent or guardian before you use the baking soda.
<G-vec00272-001-s329><ask.fragen><de> Frag einen Elternteil, bevor du anfängst, Küchenschränke zu durchwühlen.
<G-vec00272-001-s330><ask.fragen><en> When he or she talks about hobbies or family, ask some questions to show your interest.
<G-vec00272-001-s330><ask.fragen><de> Frag interessiert nach, wenn er oder sie von Hobbys oder Familie spricht.
<G-vec00272-001-s331><ask.fragen><en> "8 1⁄2 Ask an Italian to name a popular Italian soundtrack and in general he will answer ""8 1⁄2"" first."
<G-vec00272-001-s331><ask.fragen><de> "Frag einen Italiener nach ""der"" italienischen Filmmusik überhaupt und er wird Dir ""8 1⁄2"" antworten."
<G-vec00272-001-s332><ask.fragen><en> If you don't have access to suitable programs and equipment, ask at the Commons:Graphics village pump .
<G-vec00272-001-s332><ask.fragen><de> Falls Du keinen Zugriff auf geeignete Programme und Ausstattung hast, frag bezüglich Fotos die Fotowerkstatt und bezüglich Grafiken die Grafikwerkstatt .
<G-vec00272-001-s333><ask.fragen><en> But then I found out the data and... if you investigate it, just ask anybody that has run a franchise in the San Francisco area in the early 70's, and you'll find out what she did to them.
<G-vec00272-001-s333><ask.fragen><de> Aber dann fand ich die Daten raus und falls du es untersuchst, frag einfach irgendwen, der in der Gegend von Sen Francisco ein Franchise geleitet hat, und du wirst erfahren, was sie ihnen angetan hat.
<G-vec00272-001-s334><ask.fragen><en> Ask those who know me.
<G-vec00272-001-s334><ask.fragen><de> Frag' diejenigen, die mich kennen.
<G-vec00272-001-s335><ask.fragen><en> Ask him how you can help him decrease his symptom (outside of complying with his rituals).
<G-vec00272-001-s335><ask.fragen><de> Frag die Person, wie du ihr dabei helfen kannst, ihre Symptome zu lindern (ohne ihren Ritualen entgegenzukommen).
<G-vec00272-001-s336><ask.fragen><en> Show up early, get out your materials, ask a friend questions (and have them do the same), slip in some gum, and settle in.
<G-vec00272-001-s336><ask.fragen><de> Sei früh da, lege deine Utensilien zurecht, frag einen Freund Fragen (und lass ihn das Gleiche tun), schnapp dir ein Kaugummi und mach es dir bequem.
<G-vec00272-001-s337><ask.fragen><en> If you meet someone new, ask your parents first if it's okay to give them your email address.
<G-vec00272-001-s337><ask.fragen><de> Wenn du jemanden kennenlernst, frag deine Eltern, ob du ihm deine E-Mail-Adresse geben darfst.
<G-vec00272-001-s338><ask.fragen><en> But please don't ask me what we laugh about.
<G-vec00272-001-s338><ask.fragen><de> Aber frag mich nicht mehr worum es da geht.
<G-vec00272-001-s339><ask.fragen><en> Don’t ask about sunshine.
<G-vec00272-001-s339><ask.fragen><de> Frag' nicht nach Sonnenschein.
<G-vec00272-001-s340><ask.fragen><en> Excl: Online date (non nude), personalized shows, toys, C2C, phone, requests, femdom, fetish, ask me for more.
<G-vec00272-001-s340><ask.fragen><de> Excl: Online Dates (nicht nackt), die Shows werden persönlicher gestaltet, Toys, C2C, Phone, Wünsche, Fetisch, Femdom, frag mich für mehr.
<G-vec00272-001-s341><ask.fragen><en> Just ask Siri for a film, show, genre, actor or song you love.
<G-vec00272-001-s341><ask.fragen><de> Frag einfach Siri nach Filmen, Sendungen, Genres, Schauspielern oder Songs, die du magst.
<G-vec00384-001-s323><ask.fragen><en> Of course, you will also want to assess your hosting service, so ask yourself if you are happy with the overall service provided.
<G-vec00384-001-s323><ask.fragen><de> Natürlich wirst du auch deinen Hosting-Service bewerten wollen, also frag dich, ob du mit dem gesamten Service zufrieden bist.
<G-vec00384-001-s324><ask.fragen><en> I ask about foreign attachments and in most cases it's yes.
<G-vec00384-001-s324><ask.fragen><de> Dann frag ich ab auf fremde Ankopplung und fast immer kommt ja.
<G-vec00384-001-s325><ask.fragen><en> "Ask the people who were leading that struggle in the plants, on the ground."""
<G-vec00384-001-s325><ask.fragen><de> "Frag die Leute, die den Streik in den Betrieben, vor Ort, geführt haben""."
<G-vec00384-001-s326><ask.fragen><en> Ask around to find out who else is as excited to make a difference as you are.
<G-vec00384-001-s326><ask.fragen><de> Frag herum und finde Menschen, die ebenso wie du einen Unterschied machen wollen.
<G-vec00384-001-s327><ask.fragen><en> So when the messenger came to him, he said: Go back to your lord and ask him, what is the case of the women who cut their hands; surely my Lord knows their guile.
<G-vec00384-001-s327><ask.fragen><de> "Als der Bote zu ihm kam, sagte er: ""Kehr zu deinem Herrn zurück und frag ihn, wie es mit den Frauen steht, die sich ihre Hände zerschnitten."
<G-vec00384-001-s328><ask.fragen><en> “If you doubt what We have revealed to you, ask those who have read the Scriptures before you.” (Koran X; Jonah,94)
<G-vec00384-001-s328><ask.fragen><de> “Wenn du über das, was zu dir als Offenbarung herabgesandt worden ist im Zweifel bist, dann frag diejenigen, welche die Schriften, die früher herabgesandt worden sind, lesen” (Koran 10; Jonas 94).
<G-vec00384-001-s329><ask.fragen><en> Ask a parent or guardian before you use the baking soda.
<G-vec00384-001-s329><ask.fragen><de> Frag einen Elternteil, bevor du anfängst, Küchenschränke zu durchwühlen.
<G-vec00384-001-s330><ask.fragen><en> When he or she talks about hobbies or family, ask some questions to show your interest.
<G-vec00384-001-s330><ask.fragen><de> Frag interessiert nach, wenn er oder sie von Hobbys oder Familie spricht.
<G-vec00384-001-s331><ask.fragen><en> "8 1⁄2 Ask an Italian to name a popular Italian soundtrack and in general he will answer ""8 1⁄2"" first."
<G-vec00384-001-s331><ask.fragen><de> "Frag einen Italiener nach ""der"" italienischen Filmmusik überhaupt und er wird Dir ""8 1⁄2"" antworten."
<G-vec00384-001-s332><ask.fragen><en> If you don't have access to suitable programs and equipment, ask at the Commons:Graphics village pump .
<G-vec00384-001-s332><ask.fragen><de> Falls Du keinen Zugriff auf geeignete Programme und Ausstattung hast, frag bezüglich Fotos die Fotowerkstatt und bezüglich Grafiken die Grafikwerkstatt .
<G-vec00384-001-s333><ask.fragen><en> But then I found out the data and... if you investigate it, just ask anybody that has run a franchise in the San Francisco area in the early 70's, and you'll find out what she did to them.
<G-vec00384-001-s333><ask.fragen><de> Aber dann fand ich die Daten raus und falls du es untersuchst, frag einfach irgendwen, der in der Gegend von Sen Francisco ein Franchise geleitet hat, und du wirst erfahren, was sie ihnen angetan hat.
<G-vec00384-001-s334><ask.fragen><en> Ask those who know me.
<G-vec00384-001-s334><ask.fragen><de> Frag' diejenigen, die mich kennen.
<G-vec00384-001-s335><ask.fragen><en> Ask him how you can help him decrease his symptom (outside of complying with his rituals).
<G-vec00384-001-s335><ask.fragen><de> Frag die Person, wie du ihr dabei helfen kannst, ihre Symptome zu lindern (ohne ihren Ritualen entgegenzukommen).
<G-vec00384-001-s336><ask.fragen><en> Show up early, get out your materials, ask a friend questions (and have them do the same), slip in some gum, and settle in.
<G-vec00384-001-s336><ask.fragen><de> Sei früh da, lege deine Utensilien zurecht, frag einen Freund Fragen (und lass ihn das Gleiche tun), schnapp dir ein Kaugummi und mach es dir bequem.
<G-vec00384-001-s337><ask.fragen><en> If you meet someone new, ask your parents first if it's okay to give them your email address.
<G-vec00384-001-s337><ask.fragen><de> Wenn du jemanden kennenlernst, frag deine Eltern, ob du ihm deine E-Mail-Adresse geben darfst.
<G-vec00384-001-s338><ask.fragen><en> But please don't ask me what we laugh about.
<G-vec00384-001-s338><ask.fragen><de> Aber frag mich nicht mehr worum es da geht.
<G-vec00384-001-s339><ask.fragen><en> Don’t ask about sunshine.
<G-vec00384-001-s339><ask.fragen><de> Frag' nicht nach Sonnenschein.
<G-vec00384-001-s340><ask.fragen><en> Excl: Online date (non nude), personalized shows, toys, C2C, phone, requests, femdom, fetish, ask me for more.
<G-vec00384-001-s340><ask.fragen><de> Excl: Online Dates (nicht nackt), die Shows werden persönlicher gestaltet, Toys, C2C, Phone, Wünsche, Fetisch, Femdom, frag mich für mehr.
<G-vec00384-001-s341><ask.fragen><en> Just ask Siri for a film, show, genre, actor or song you love.
<G-vec00384-001-s341><ask.fragen><de> Frag einfach Siri nach Filmen, Sendungen, Genres, Schauspielern oder Songs, die du magst.
<G-vec00272-001-s342><ask.fragen><en> I don't immediately recognize them as my family until I ask myself who these people are.
<G-vec00272-001-s342><ask.fragen><de> Er erkenne sie nicht sofort als meine Familie, bis ich mich frage, wer es sein könnte.
<G-vec00272-001-s343><ask.fragen><en> If someone left a note or delivery at your doorstep, ask your neighbors if they saw the deliverer.
<G-vec00272-001-s343><ask.fragen><de> Wenn jemand etwas an deiner Tür hinterlassen hat, frage die Nachbarn, ob sie denjenigen gesehen haben.
<G-vec00272-001-s344><ask.fragen><en> If she, however, is signalizing that something feels neutral and does not get better over half of a minute – or she is showing any reaction that you do not understand – pause your movements, and ask her what she wishes for you to do right now.
<G-vec00272-001-s344><ask.fragen><de> Wenn sie hingegen signalisiert, dass sich etwas länger als eine halbe Minute lauwarm anfühlt und auch nicht besser wird – oder generell eine Reaktion zeigt, mit der du dich nicht auskennst – pausiere deine Bewegungen, und frage sie, was sie sich gerade von dir wünscht.
<G-vec00272-001-s345><ask.fragen><en> I usually ask the parents if they have ever played the games with their kid.
<G-vec00272-001-s345><ask.fragen><de> Ich frage die Eltern, ob normalerweise sie überhaupt die Spiele mit ihrem Zicklein gespielt haben.
<G-vec00272-001-s346><ask.fragen><en> Ask your child what their sexuality means to them.
<G-vec00272-001-s346><ask.fragen><de> Frage dein Kind, was es für es bedeutet, homosexuell zu sein.
<G-vec00272-001-s347><ask.fragen><en> I don't ask to You, Mr., to get away from the cross, but I beg You to give to me the strength to persevere on it.
<G-vec00272-001-s347><ask.fragen><de> Ich frage Dich nicht, Herr, mir vom Kreuz abnehmen, aber ich flehe Dich mir Kraft zu geben an, auf ihr beharren.
<G-vec00272-001-s348><ask.fragen><en> Always ask other experts in related fields how you can get better.
<G-vec00272-001-s348><ask.fragen><de> Frage immer Experten in verwandten Bereichen, wie du besser werden könntest.
<G-vec00272-001-s349><ask.fragen><en> Ask whatever you wish.
<G-vec00272-001-s349><ask.fragen><de> Frage, was immer du willst.
<G-vec00272-001-s350><ask.fragen><en> And so you need to ask yourself how you can save money on food, while eating healthily (cue ultra-expensive superfood...) and still ending up full.
<G-vec00272-001-s350><ask.fragen><de> Und da stellt sich die Frage, wie du beim Essen sparen kannst, gesund isst (Stichwort: superteures Superfood) und trotzdem satt wirst.
<G-vec00272-001-s351><ask.fragen><en> “Cold?” I ask her pulling her closer to my body to keep her warm.
<G-vec00272-001-s351><ask.fragen><de> „Frierst du?“, frage ich sie und ziehe sie enger an mich, um sie zu wärmen.
<G-vec00272-001-s352><ask.fragen><en> Please do not ask for large subsystems or patches to be merged.
<G-vec00272-001-s352><ask.fragen><de> Bitte frage nicht nach großen Susbsystemen oder Patches, die eingefügt werden sollen.
<G-vec00272-001-s353><ask.fragen><en> Sometimes I ask myself if my father was a seal...
<G-vec00272-001-s353><ask.fragen><de> Manchmal frage ich mich, ob mein Vater ein Seehund war...
<G-vec00272-001-s354><ask.fragen><en> 18:5 They said to him, “Please ask counsel of God, that we may know whether our way which we go shall be prosperous.”
<G-vec00272-001-s354><ask.fragen><de> 18:5 Sie sprachen zu ihm: Lieber, frage Gott, daß wir erfahren, ob unser Weg, den wir wandeln, auch wohlgeraten werde.
<G-vec00272-001-s355><ask.fragen><en> When I ask those ignorant who wear rings why they wear them, some say it is to prove to people that they are married.
<G-vec00272-001-s355><ask.fragen><de> Wenn ich diese Unwissenden, die Ringe tragen, frage, warum sie sie tragen, beantworten manche davon, indem sie sagen, dass sie beweisen wollen, dass sie verheiratet sind.
<G-vec00272-001-s356><ask.fragen><en> This is a very useful feature and it allows you to learn your cards in both directions. In reversed mode, SuperMemo will ask you showing the answer side of the card, and you have to reply recalling the question side.
<G-vec00272-001-s356><ask.fragen><de> SuperMemo erlaubt Ihnen, Ihre Karten in den Übungen umzudrehen, d.h. statt der Frage wird Ihnen die Antwort vorgelegt und Sie müssen die zugehörige Frage wissen.
<G-vec00272-001-s357><ask.fragen><en> When in doubt I like to ask whether I could print a logo with equal effectiveness on a biro and on a running elephant.
<G-vec00272-001-s357><ask.fragen><de> Ich frage gerne, ob ich ein Logo im Zweifel auch auf einen Kugelschreiber und ebenso auf einen laufenden Elefanten drucken kann.
<G-vec00272-001-s358><ask.fragen><en> “What time is your flight?” I ask Taylor.
<G-vec00272-001-s358><ask.fragen><de> „Um wie viel Uhr geht Ihr Flieger?“ frage ich Taylor.
<G-vec00272-001-s359><ask.fragen><en> For other instruments, please ask before.
<G-vec00272-001-s359><ask.fragen><de> Für andere Instrumente, frage bitte vor der Buchung.
<G-vec00272-001-s360><ask.fragen><en> Ask your doctor if a medication could help you.
<G-vec00272-001-s360><ask.fragen><de> Frage deinen Arzt, ob ein Medikament helfen könnte.
<G-vec00384-001-s342><ask.fragen><en> I don't immediately recognize them as my family until I ask myself who these people are.
<G-vec00384-001-s342><ask.fragen><de> Er erkenne sie nicht sofort als meine Familie, bis ich mich frage, wer es sein könnte.
<G-vec00384-001-s343><ask.fragen><en> If someone left a note or delivery at your doorstep, ask your neighbors if they saw the deliverer.
<G-vec00384-001-s343><ask.fragen><de> Wenn jemand etwas an deiner Tür hinterlassen hat, frage die Nachbarn, ob sie denjenigen gesehen haben.
<G-vec00384-001-s344><ask.fragen><en> If she, however, is signalizing that something feels neutral and does not get better over half of a minute – or she is showing any reaction that you do not understand – pause your movements, and ask her what she wishes for you to do right now.
<G-vec00384-001-s344><ask.fragen><de> Wenn sie hingegen signalisiert, dass sich etwas länger als eine halbe Minute lauwarm anfühlt und auch nicht besser wird – oder generell eine Reaktion zeigt, mit der du dich nicht auskennst – pausiere deine Bewegungen, und frage sie, was sie sich gerade von dir wünscht.
<G-vec00384-001-s345><ask.fragen><en> I usually ask the parents if they have ever played the games with their kid.
<G-vec00384-001-s345><ask.fragen><de> Ich frage die Eltern, ob normalerweise sie überhaupt die Spiele mit ihrem Zicklein gespielt haben.
<G-vec00384-001-s346><ask.fragen><en> Ask your child what their sexuality means to them.
<G-vec00384-001-s346><ask.fragen><de> Frage dein Kind, was es für es bedeutet, homosexuell zu sein.
<G-vec00384-001-s347><ask.fragen><en> I don't ask to You, Mr., to get away from the cross, but I beg You to give to me the strength to persevere on it.
<G-vec00384-001-s347><ask.fragen><de> Ich frage Dich nicht, Herr, mir vom Kreuz abnehmen, aber ich flehe Dich mir Kraft zu geben an, auf ihr beharren.
<G-vec00384-001-s348><ask.fragen><en> Always ask other experts in related fields how you can get better.
<G-vec00384-001-s348><ask.fragen><de> Frage immer Experten in verwandten Bereichen, wie du besser werden könntest.
<G-vec00384-001-s349><ask.fragen><en> Ask whatever you wish.
<G-vec00384-001-s349><ask.fragen><de> Frage, was immer du willst.
<G-vec00384-001-s350><ask.fragen><en> And so you need to ask yourself how you can save money on food, while eating healthily (cue ultra-expensive superfood...) and still ending up full.
<G-vec00384-001-s350><ask.fragen><de> Und da stellt sich die Frage, wie du beim Essen sparen kannst, gesund isst (Stichwort: superteures Superfood) und trotzdem satt wirst.
<G-vec00384-001-s351><ask.fragen><en> “Cold?” I ask her pulling her closer to my body to keep her warm.
<G-vec00384-001-s351><ask.fragen><de> „Frierst du?“, frage ich sie und ziehe sie enger an mich, um sie zu wärmen.
<G-vec00384-001-s352><ask.fragen><en> Please do not ask for large subsystems or patches to be merged.
<G-vec00384-001-s352><ask.fragen><de> Bitte frage nicht nach großen Susbsystemen oder Patches, die eingefügt werden sollen.
<G-vec00384-001-s353><ask.fragen><en> Sometimes I ask myself if my father was a seal...
<G-vec00384-001-s353><ask.fragen><de> Manchmal frage ich mich, ob mein Vater ein Seehund war...
<G-vec00384-001-s354><ask.fragen><en> 18:5 They said to him, “Please ask counsel of God, that we may know whether our way which we go shall be prosperous.”
<G-vec00384-001-s354><ask.fragen><de> 18:5 Sie sprachen zu ihm: Lieber, frage Gott, daß wir erfahren, ob unser Weg, den wir wandeln, auch wohlgeraten werde.
<G-vec00384-001-s355><ask.fragen><en> When I ask those ignorant who wear rings why they wear them, some say it is to prove to people that they are married.
<G-vec00384-001-s355><ask.fragen><de> Wenn ich diese Unwissenden, die Ringe tragen, frage, warum sie sie tragen, beantworten manche davon, indem sie sagen, dass sie beweisen wollen, dass sie verheiratet sind.
<G-vec00384-001-s356><ask.fragen><en> This is a very useful feature and it allows you to learn your cards in both directions. In reversed mode, SuperMemo will ask you showing the answer side of the card, and you have to reply recalling the question side.
<G-vec00384-001-s356><ask.fragen><de> SuperMemo erlaubt Ihnen, Ihre Karten in den Übungen umzudrehen, d.h. statt der Frage wird Ihnen die Antwort vorgelegt und Sie müssen die zugehörige Frage wissen.
<G-vec00384-001-s357><ask.fragen><en> When in doubt I like to ask whether I could print a logo with equal effectiveness on a biro and on a running elephant.
<G-vec00384-001-s357><ask.fragen><de> Ich frage gerne, ob ich ein Logo im Zweifel auch auf einen Kugelschreiber und ebenso auf einen laufenden Elefanten drucken kann.
<G-vec00384-001-s358><ask.fragen><en> “What time is your flight?” I ask Taylor.
<G-vec00384-001-s358><ask.fragen><de> „Um wie viel Uhr geht Ihr Flieger?“ frage ich Taylor.
<G-vec00384-001-s359><ask.fragen><en> For other instruments, please ask before.
<G-vec00384-001-s359><ask.fragen><de> Für andere Instrumente, frage bitte vor der Buchung.
<G-vec00384-001-s360><ask.fragen><en> Ask your doctor if a medication could help you.
<G-vec00384-001-s360><ask.fragen><de> Frage deinen Arzt, ob ein Medikament helfen könnte.
<G-vec00272-001-s361><ask.stellen><en> "Given these symptoms that are all indicators of the system's chronic collapse, a collapse that cannot simply be staved off through ""cleverer"" economic policies, we would do well to ask how tomorrow's society will be shaped if the prophets of gloom turn out to be right."
<G-vec00272-001-s361><ask.stellen><de> "Angesichts dieser Symptome, die allesamt Indizien für einen chronischen Niedergang des Systems sind, eines Niederganges, der nicht einfach durch ""klügere"" Wirtschaftspolitik aufgehalten werden kann, tun wir jedenfalls gut daran, uns die Frage zu stellen, wie die Gesellschaft von Morgen denn gestaltet werden sollte, wenn die Krisenpropheten recht haben sollten."
<G-vec00272-001-s362><ask.stellen><en> """Engineers constantly have to ask themselves what happens when there is a power failure or an operator presses the emergency OFF switch on a machine."
<G-vec00272-001-s362><ask.stellen><de> """Konstrukteure müssen sich stets die Frage stellen, was passiert, wenn der Strom an einer Maschine ausfällt oder der Bediener den Not-Aus-Schalter betätigt."
<G-vec00272-001-s363><ask.stellen><en> You have to ask them what would be good for their working environment so that they can do an even better job.
<G-vec00272-001-s363><ask.stellen><de> Man muss ihnen die Frage stellen, was gut für ihr Arbeitsumfeld wäre, damit sie einen noch besseren Job machen können.
<G-vec00272-001-s364><ask.stellen><en> "It is important for us to ask ourselves what ""those who can afford it"" actually means."
<G-vec00272-001-s364><ask.stellen><de> "Wichtig ist dabei, dass wir uns die Frage stellen, was ""wer es sich leisten kann"" eigentlich heißt."
<G-vec00272-001-s365><ask.stellen><en> You speak other languages and you wish to give/ask advice in another language.
<G-vec00272-001-s365><ask.stellen><de> Sie sprechen andere Sprachen und Sie möchten, Rat geben oder Frage stellen in einer anderen Sprache.
<G-vec00272-001-s366><ask.stellen><en> I could ask if you or the Federation of Cuban Women or other mass organizations or the young communists or the students have assassinated any Cuban; if a soldier of the Revolutionary Armed Forces has killed any Cuban; if a Cuban has been killed by one of our combatants from the Ministry of the Interior. Nobody would be able to find a single one in 40 years of struggle, of harassment and blockade, in a country that has carried on the struggle here and abroad.
<G-vec00272-001-s366><ask.stellen><de> Man könnte die Frage stellen, welchen Bürger ihr ermordet habt, oder der Kubanische Frauenbund und andere Massenorganisationen, oder die Jungkommunisten, oder die Studenten; welchen Bürger hat ein Soldat der Revolutionären Streitkräfte ermordet; welcher Bürger wurde von einem unserer Kämpfer des Innenministeriums getötet, und niemand könnte einen einzigen finden in 40 Jahren Kampf, Anfeindung und Blockade gegenüber einem Land, das hier und außerhalb seiner Grenzen gekämpft hat.
<G-vec00272-001-s367><ask.stellen><en> It helps to ask yourself why you 2nd barrel at all and what you expect from it.
<G-vec00272-001-s367><ask.stellen><de> Es hilft, sich selber die Frage zu stellen, warum man eigentlich 2nd-barrelt und was man sich davon verspricht.
<G-vec00272-001-s368><ask.stellen><en> If we gather these three together and ask them what the walnut is like, the one would say it is tart, pungent, and poisonous; the second one would say it is a hard fruit, breaking the teeth of people; the third one – that it is something tasty and pleasant.
<G-vec00272-001-s368><ask.stellen><de> Wenn wir diese drei Menschen versammeln und ihnen die Frage stellen, was eine Nuß ist, wird der erste sagen, sie sei eine herbe, scharfe und höchstwahrscheinlich auch giftige Frucht; der zweite, sie sei eine harte Frucht, die schlecht für die Zähne ist; der dritte, sie sei etwas Wohlschmeckendes und Gutes.
<G-vec00272-001-s369><ask.stellen><en> But before we get started, let me ask you something.
<G-vec00272-001-s369><ask.stellen><de> Aber bevor wir beginnen, lassen Sie mich Ihnen eine Frage stellen.
<G-vec00272-001-s370><ask.stellen><en> Him trying to subtly avoid me along with my questions about when the next certification event was supposed to happen, me gently cornering him to ask anyway.
<G-vec00272-001-s370><ask.stellen><de> Er versuchte mich mit meinen Fragen, wann der nächste stattfinden würde, auf subtile Weise zu meiden, während ich in vorsichtig versuchte, ihm in einer Ecke doch noch meine Frage stellen zu können.
<G-vec00272-001-s371><ask.stellen><en> I try to ask it early in the process and hopefully get to a point where there's a full idea with some room to wander.
<G-vec00272-001-s371><ask.stellen><de> Ich versuche, mir diese Frage schon in der Anfangsphase des Produzierens zu stellen und hoffe, auf diese Weise an einen Punkt zu gelangen, an dem eine komplette Idee entsteht, die Spielraum hat.
<G-vec00272-001-s372><ask.stellen><en> In the end, the best thing would be for employees to ask their employers whether or not they are being watched because the chance of managers telling the truth is high due to their moral ethics.
<G-vec00272-001-s372><ask.stellen><de> Am Ende wäre es am besten, wenn Angestellte ihren Arbeitgebern die Frage stellen, ob sie beobachtet werden, weil die Wahrscheinlichkeit, dass Führungskräfte die Wahrheit sagen, aufgrund ihrer moralischen Ethik hoch ist.
<G-vec00272-001-s373><ask.stellen><en> We can dare, as we should, to tell each young person to ask whether this is the path that they are meant to follow.
<G-vec00272-001-s373><ask.stellen><de> Wir können – und müssen – den Mut haben, zu jedem jungen Menschen zu sagen, dass er sich die Frage nach der Möglichkeit stellen soll, diesen Weg zu verfolgen.
<G-vec00272-001-s374><ask.stellen><en> Jasmine even has the courage to ask about my present life, and pressures me into considering my future.
<G-vec00272-001-s374><ask.stellen><de> Jasmin hat allerdings den Mut, mein Leben in der Gegenwart in Frage zu stellen und drängt mich, über meine Zukunft nachzudenken.
<G-vec00272-001-s375><ask.stellen><en> One must ask oneself, looking at the large number of episodes, whether normal gamers will be able to pay the total offer, if each episode is sold for the full price of $39.
<G-vec00272-001-s375><ask.stellen><de> Man muss sich bei der großen Anzahl von Episoden auch die Frage stellen, ob man das Gesamtangebot als Normalspieler wird bezahlen können, wenn jeder Teil zum Vollpreis von $39 angeboten wird.
<G-vec00272-001-s376><ask.stellen><en> Flat-earthers should ask themselves why they instead trust the videos of avowed enemies of the Gospel such as Dubay.
<G-vec00272-001-s376><ask.stellen><de> Vertreter einer flachen Erde sollten sich selbst die Frage stellen, warum sie stattdessen den Videos von ausgesprochenen Gegnern des Evangeliums, wie im Fall von Dubay, Glauben schenken.
<G-vec00272-001-s377><ask.stellen><en> So we need to ask ourselves where the future lies for our German-language media abroad.
<G-vec00272-001-s377><ask.stellen><de> Wir müssen uns also auch die Frage stellen, wo die Zukunft der deutschsprachigen Medien im Ausland liegt.
<G-vec00272-001-s378><ask.stellen><en> Now you can ask: how important is the BuGa and does our Federal President really need to talk at its opening.
<G-vec00272-001-s378><ask.stellen><de> Jetzt kann man die Frage stellen, wie wichtig die Buga ist und ob da unser Bundespräsident unbedingt eine Rede halten muss.
<G-vec00272-001-s379><ask.stellen><en> The research association will therefore also ask for the relationship between interdependence and inequality and thus deconstruct cultural constructions, stereotypes, clichés and prejudices.
<G-vec00272-001-s379><ask.stellen><de> Der Themenverbund wird daher auch die Frage nach der Beziehung zwischen Verflechtung und Ungleichheit stellen sowie damit einhergehende kulturelle Konstruktionen, Stereotypen, Klischees und Vorurteile dekonstruieren.
<G-vec00384-001-s361><ask.stellen><en> "Given these symptoms that are all indicators of the system's chronic collapse, a collapse that cannot simply be staved off through ""cleverer"" economic policies, we would do well to ask how tomorrow's society will be shaped if the prophets of gloom turn out to be right."
<G-vec00384-001-s361><ask.stellen><de> "Angesichts dieser Symptome, die allesamt Indizien für einen chronischen Niedergang des Systems sind, eines Niederganges, der nicht einfach durch ""klügere"" Wirtschaftspolitik aufgehalten werden kann, tun wir jedenfalls gut daran, uns die Frage zu stellen, wie die Gesellschaft von Morgen denn gestaltet werden sollte, wenn die Krisenpropheten recht haben sollten."
<G-vec00384-001-s362><ask.stellen><en> """Engineers constantly have to ask themselves what happens when there is a power failure or an operator presses the emergency OFF switch on a machine."
<G-vec00384-001-s362><ask.stellen><de> """Konstrukteure müssen sich stets die Frage stellen, was passiert, wenn der Strom an einer Maschine ausfällt oder der Bediener den Not-Aus-Schalter betätigt."
<G-vec00384-001-s363><ask.stellen><en> You have to ask them what would be good for their working environment so that they can do an even better job.
<G-vec00384-001-s363><ask.stellen><de> Man muss ihnen die Frage stellen, was gut für ihr Arbeitsumfeld wäre, damit sie einen noch besseren Job machen können.
<G-vec00384-001-s364><ask.stellen><en> "It is important for us to ask ourselves what ""those who can afford it"" actually means."
<G-vec00384-001-s364><ask.stellen><de> "Wichtig ist dabei, dass wir uns die Frage stellen, was ""wer es sich leisten kann"" eigentlich heißt."
<G-vec00384-001-s365><ask.stellen><en> You speak other languages and you wish to give/ask advice in another language.
<G-vec00384-001-s365><ask.stellen><de> Sie sprechen andere Sprachen und Sie möchten, Rat geben oder Frage stellen in einer anderen Sprache.
<G-vec00384-001-s366><ask.stellen><en> I could ask if you or the Federation of Cuban Women or other mass organizations or the young communists or the students have assassinated any Cuban; if a soldier of the Revolutionary Armed Forces has killed any Cuban; if a Cuban has been killed by one of our combatants from the Ministry of the Interior. Nobody would be able to find a single one in 40 years of struggle, of harassment and blockade, in a country that has carried on the struggle here and abroad.
<G-vec00384-001-s366><ask.stellen><de> Man könnte die Frage stellen, welchen Bürger ihr ermordet habt, oder der Kubanische Frauenbund und andere Massenorganisationen, oder die Jungkommunisten, oder die Studenten; welchen Bürger hat ein Soldat der Revolutionären Streitkräfte ermordet; welcher Bürger wurde von einem unserer Kämpfer des Innenministeriums getötet, und niemand könnte einen einzigen finden in 40 Jahren Kampf, Anfeindung und Blockade gegenüber einem Land, das hier und außerhalb seiner Grenzen gekämpft hat.
<G-vec00384-001-s367><ask.stellen><en> It helps to ask yourself why you 2nd barrel at all and what you expect from it.
<G-vec00384-001-s367><ask.stellen><de> Es hilft, sich selber die Frage zu stellen, warum man eigentlich 2nd-barrelt und was man sich davon verspricht.
<G-vec00384-001-s368><ask.stellen><en> If we gather these three together and ask them what the walnut is like, the one would say it is tart, pungent, and poisonous; the second one would say it is a hard fruit, breaking the teeth of people; the third one – that it is something tasty and pleasant.
<G-vec00384-001-s368><ask.stellen><de> Wenn wir diese drei Menschen versammeln und ihnen die Frage stellen, was eine Nuß ist, wird der erste sagen, sie sei eine herbe, scharfe und höchstwahrscheinlich auch giftige Frucht; der zweite, sie sei eine harte Frucht, die schlecht für die Zähne ist; der dritte, sie sei etwas Wohlschmeckendes und Gutes.
<G-vec00384-001-s369><ask.stellen><en> But before we get started, let me ask you something.
<G-vec00384-001-s369><ask.stellen><de> Aber bevor wir beginnen, lassen Sie mich Ihnen eine Frage stellen.
<G-vec00384-001-s370><ask.stellen><en> Him trying to subtly avoid me along with my questions about when the next certification event was supposed to happen, me gently cornering him to ask anyway.
<G-vec00384-001-s370><ask.stellen><de> Er versuchte mich mit meinen Fragen, wann der nächste stattfinden würde, auf subtile Weise zu meiden, während ich in vorsichtig versuchte, ihm in einer Ecke doch noch meine Frage stellen zu können.
<G-vec00384-001-s371><ask.stellen><en> I try to ask it early in the process and hopefully get to a point where there's a full idea with some room to wander.
<G-vec00384-001-s371><ask.stellen><de> Ich versuche, mir diese Frage schon in der Anfangsphase des Produzierens zu stellen und hoffe, auf diese Weise an einen Punkt zu gelangen, an dem eine komplette Idee entsteht, die Spielraum hat.
<G-vec00384-001-s372><ask.stellen><en> In the end, the best thing would be for employees to ask their employers whether or not they are being watched because the chance of managers telling the truth is high due to their moral ethics.
<G-vec00384-001-s372><ask.stellen><de> Am Ende wäre es am besten, wenn Angestellte ihren Arbeitgebern die Frage stellen, ob sie beobachtet werden, weil die Wahrscheinlichkeit, dass Führungskräfte die Wahrheit sagen, aufgrund ihrer moralischen Ethik hoch ist.
<G-vec00384-001-s373><ask.stellen><en> We can dare, as we should, to tell each young person to ask whether this is the path that they are meant to follow.
<G-vec00384-001-s373><ask.stellen><de> Wir können – und müssen – den Mut haben, zu jedem jungen Menschen zu sagen, dass er sich die Frage nach der Möglichkeit stellen soll, diesen Weg zu verfolgen.
<G-vec00384-001-s374><ask.stellen><en> Jasmine even has the courage to ask about my present life, and pressures me into considering my future.
<G-vec00384-001-s374><ask.stellen><de> Jasmin hat allerdings den Mut, mein Leben in der Gegenwart in Frage zu stellen und drängt mich, über meine Zukunft nachzudenken.
<G-vec00384-001-s375><ask.stellen><en> One must ask oneself, looking at the large number of episodes, whether normal gamers will be able to pay the total offer, if each episode is sold for the full price of $39.
<G-vec00384-001-s375><ask.stellen><de> Man muss sich bei der großen Anzahl von Episoden auch die Frage stellen, ob man das Gesamtangebot als Normalspieler wird bezahlen können, wenn jeder Teil zum Vollpreis von $39 angeboten wird.
<G-vec00384-001-s376><ask.stellen><en> Flat-earthers should ask themselves why they instead trust the videos of avowed enemies of the Gospel such as Dubay.
<G-vec00384-001-s376><ask.stellen><de> Vertreter einer flachen Erde sollten sich selbst die Frage stellen, warum sie stattdessen den Videos von ausgesprochenen Gegnern des Evangeliums, wie im Fall von Dubay, Glauben schenken.
<G-vec00384-001-s377><ask.stellen><en> So we need to ask ourselves where the future lies for our German-language media abroad.
<G-vec00384-001-s377><ask.stellen><de> Wir müssen uns also auch die Frage stellen, wo die Zukunft der deutschsprachigen Medien im Ausland liegt.
<G-vec00384-001-s378><ask.stellen><en> Now you can ask: how important is the BuGa and does our Federal President really need to talk at its opening.
<G-vec00384-001-s378><ask.stellen><de> Jetzt kann man die Frage stellen, wie wichtig die Buga ist und ob da unser Bundespräsident unbedingt eine Rede halten muss.
<G-vec00384-001-s379><ask.stellen><en> The research association will therefore also ask for the relationship between interdependence and inequality and thus deconstruct cultural constructions, stereotypes, clichés and prejudices.
<G-vec00384-001-s379><ask.stellen><de> Der Themenverbund wird daher auch die Frage nach der Beziehung zwischen Verflechtung und Ungleichheit stellen sowie damit einhergehende kulturelle Konstruktionen, Stereotypen, Klischees und Vorurteile dekonstruieren.
<G-vec00272-001-s380><ask.fragen><en> Days are long in the summer (in mid summer there’s no dark at all) and the winter is very dark and cold (and people ask why so many metal bands *lol*).
<G-vec00272-001-s380><ask.fragen><de> Die Tage sind lang im Sommer (im Mitsommer gibt es überhaupt keine Dunkelheit) und die Winter sind sehr dunkel und kalt (und die Leute fragen, warum so viele Metal Bands *lol*).
<G-vec00272-001-s381><ask.fragen><en> You'll need to ask yourself a few questions about how serious you are about trading overseas, and whether or not you are ready to accept the necessary risk.
<G-vec00272-001-s381><ask.fragen><de> Sie müssen sich fragen, ein paar Fragen, wie ernst es Ihnen über den Handel in Übersee, und ob Sie bereit sind, die notwendige Risikobereitschaft.
<G-vec00272-001-s382><ask.fragen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00272-001-s382><ask.fragen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00272-001-s383><ask.fragen><en> Just before you submit the payday loan application, talk about the fees, the costs, and once again ask about the final date of the loan.
<G-vec00272-001-s383><ask.fragen><de> Kurz vor der Zahltag Darlehen bewerben, sprechen über die Gebühren, die kosten, und wieder einmal fragen nach dem letzten Tag des Darlehens.
<G-vec00272-001-s384><ask.fragen><en> Before buying a lawnmower AL-KO 112865 4125 BC II Comfort ask about all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s384><ask.fragen><de> Vor dem Kauf eines Rasenmäher AL-KO 112865 4125 BC II Comfort fragen Ã1⁄4ber alle Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s385><ask.fragen><en> You can solve this kind of problem by adding phonetic spelling so that you don’t have to ask Siri repeatedly.
<G-vec00272-001-s385><ask.fragen><de> Sie können durch das Hinzufügen Lautschrift diese Art von Problem zu lösen, so dass Sie zu Siri nicht fragen wiederholt.
<G-vec00272-001-s386><ask.fragen><en> Anyway, I've looked online for as much information as I can find, and have done a ton of reading from the newbie posts, so as to not ask repetitious questions, but now I'm overwhelmed, since everything since to depend on multiple factors.
<G-vec00272-001-s386><ask.fragen><de> Sowieso habe ich online zu so vieler Information geschaut, wie ich finden kann, und habe eine Tonne Ablesen von den Neupfosten getan, um nicht zu fragen repetitious Fragen, aber jetzt mich überwältigt werden, seit alles seit von den mehrfachen Faktoren abhängen.
<G-vec00272-001-s387><ask.fragen><en> At each station you will hurry to my car and ask for my orders.
<G-vec00272-001-s387><ask.fragen><de> Auf jeder Station hast du zu meinem Waggon zu eilen und nach meinen Befehlen zu fragen.
<G-vec00272-001-s388><ask.fragen><en> If you ask to your guide, Surely you will find new versions of this history that continues with its end open.
<G-vec00272-001-s388><ask.fragen><de> Wenn Sie Ihr Reiseleiter Fragen, Sie werden sicherlich neue Versionen der Geschichte finden, die mit seinem offenen Ende weiter.
<G-vec00272-001-s389><ask.fragen><en> Therefore we are often preoccupied and very rarely find time or space to ask ourselves what really matters to us in life, what we want to spend our energy on and what is actually the source of our existence.
<G-vec00272-001-s389><ask.fragen><de> Das hält uns fast ständig beschäftigt und deshalb finden wir selten Zeit und Raum, um uns zu fragen, worauf es uns im Leben wirklich ankommt, wofür wir unsere Energie einsetzen wollen und was eigentlich die Quelle unserer Existenz ausmacht.
<G-vec00272-001-s390><ask.fragen><en> First, I am still active on the Ask at the Shell Gas station on pilgrimage and then I like a well-behaved Lemming out again.
<G-vec00272-001-s390><ask.fragen><de> Erst rege ich mich noch über die Fragen an der Shell Tankstelle auf und dann pilgere ich wie ein gut erzogener Lemming nochmal hin.
<G-vec00272-001-s391><ask.fragen><en> In the beginning of the war, When The people had not been united, as the leaders thought They would ask, the war went bad for France.
<G-vec00272-001-s391><ask.fragen><de> Am Anfang des Krieges, als die Leute noch nicht vereint, wie die Führer dachte, Sie würden fragen, der Krieg ging schlecht für Frankreich.
<G-vec00272-001-s392><ask.fragen><en> Some comrades will ask us, not without indignation, “Would you be against organic unity?”
<G-vec00272-001-s392><ask.fragen><de> „Was, ihr seid also gegen die organische Einheit?“, werden uns nicht ohne Entrüstung manche Genossen fragen.
<G-vec00272-001-s393><ask.fragen><en> AllExperts is an American website, where you can ask anything, including about chess, and get an answer.
<G-vec00272-001-s393><ask.fragen><de> AllExperts ist eine amerikanische Website, auf der Sie irgendetwas, einschließend Dinge über Schachspiel, fragen können, und eine Antwort erhalten können.
<G-vec00272-001-s394><ask.fragen><en> Greater privacy when you gamble - Beyond your email address, most Bitcoin casinos will not ask you for any of your other personal details and there are many mechanisms that exist with Bitcoin to protect the privacy of its users. Want to try your luck at a Bitcoin Casino? Check out our top list of the best Bitcoin online casinos here.
<G-vec00272-001-s394><ask.fragen><de> Mehr Anonymität beim Glücksspiel – Bitcoin Casinos werden Sie lediglich nach Ihrer E-Mail-Adresse fragen, darüber hinaus werden keine weiteren persönlichen Angaben benötigt, und es bestehen zahlreiche Maßnahmen, die mit dieser einzigartigen Zahlungsoption eingeführt wurden, um die Privatsphäre der Nutzer zu schützen.
<G-vec00272-001-s395><ask.fragen><en> You have to pray and to ask yourselves what you have to pray for.
<G-vec00272-001-s395><ask.fragen><de> Ihr müsst beten und euch selbst fragen, worum ihr beten müsst.
<G-vec00272-001-s396><ask.fragen><en> The employees of Empire of Sports AG will never ask you for your password and you should never give it to anyone who does ask for it.
<G-vec00272-001-s396><ask.fragen><de> Die Mitarbeiter von Empire of Sports AG werden Sie nie nach Ihrem Kennwort fragen und Sie sollten es niemals ausgeben, wenn Sie danach gefragt werden.
<G-vec00272-001-s397><ask.fragen><en> As you shop online for the best auto insurance deals you may begin to ask yourself what exactly is required by law when it comes to auto insurance.
<G-vec00272-001-s397><ask.fragen><de> Wie Sie Online-Shop für die beste Auto-Versicherung können Sie uns beginnen, fragen Sie sich, was gesetzlich vorgeschrieben ist, wenn es um die Auto-Versicherung.
<G-vec00272-001-s398><ask.fragen><en> You ask for it and simply get online, if you want to repeat the series.
<G-vec00272-001-s398><ask.fragen><de> Sie Fragen Sie und einfach online, wenn Sie möchten, wiederholen Sie die Serie.
<G-vec00384-001-s380><ask.fragen><en> Days are long in the summer (in mid summer there’s no dark at all) and the winter is very dark and cold (and people ask why so many metal bands *lol*).
<G-vec00384-001-s380><ask.fragen><de> Die Tage sind lang im Sommer (im Mitsommer gibt es überhaupt keine Dunkelheit) und die Winter sind sehr dunkel und kalt (und die Leute fragen, warum so viele Metal Bands *lol*).
<G-vec00384-001-s381><ask.fragen><en> You'll need to ask yourself a few questions about how serious you are about trading overseas, and whether or not you are ready to accept the necessary risk.
<G-vec00384-001-s381><ask.fragen><de> Sie müssen sich fragen, ein paar Fragen, wie ernst es Ihnen über den Handel in Übersee, und ob Sie bereit sind, die notwendige Risikobereitschaft.
<G-vec00384-001-s382><ask.fragen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00384-001-s382><ask.fragen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00384-001-s383><ask.fragen><en> Just before you submit the payday loan application, talk about the fees, the costs, and once again ask about the final date of the loan.
<G-vec00384-001-s383><ask.fragen><de> Kurz vor der Zahltag Darlehen bewerben, sprechen über die Gebühren, die kosten, und wieder einmal fragen nach dem letzten Tag des Darlehens.
<G-vec00384-001-s384><ask.fragen><en> Before buying a lawnmower AL-KO 112865 4125 BC II Comfort ask about all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s384><ask.fragen><de> Vor dem Kauf eines Rasenmäher AL-KO 112865 4125 BC II Comfort fragen Ã1⁄4ber alle Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s385><ask.fragen><en> You can solve this kind of problem by adding phonetic spelling so that you don’t have to ask Siri repeatedly.
<G-vec00384-001-s385><ask.fragen><de> Sie können durch das Hinzufügen Lautschrift diese Art von Problem zu lösen, so dass Sie zu Siri nicht fragen wiederholt.
<G-vec00384-001-s386><ask.fragen><en> Anyway, I've looked online for as much information as I can find, and have done a ton of reading from the newbie posts, so as to not ask repetitious questions, but now I'm overwhelmed, since everything since to depend on multiple factors.
<G-vec00384-001-s386><ask.fragen><de> Sowieso habe ich online zu so vieler Information geschaut, wie ich finden kann, und habe eine Tonne Ablesen von den Neupfosten getan, um nicht zu fragen repetitious Fragen, aber jetzt mich überwältigt werden, seit alles seit von den mehrfachen Faktoren abhängen.
<G-vec00384-001-s387><ask.fragen><en> At each station you will hurry to my car and ask for my orders.
<G-vec00384-001-s387><ask.fragen><de> Auf jeder Station hast du zu meinem Waggon zu eilen und nach meinen Befehlen zu fragen.
<G-vec00384-001-s388><ask.fragen><en> If you ask to your guide, Surely you will find new versions of this history that continues with its end open.
<G-vec00384-001-s388><ask.fragen><de> Wenn Sie Ihr Reiseleiter Fragen, Sie werden sicherlich neue Versionen der Geschichte finden, die mit seinem offenen Ende weiter.
<G-vec00384-001-s389><ask.fragen><en> Therefore we are often preoccupied and very rarely find time or space to ask ourselves what really matters to us in life, what we want to spend our energy on and what is actually the source of our existence.
<G-vec00384-001-s389><ask.fragen><de> Das hält uns fast ständig beschäftigt und deshalb finden wir selten Zeit und Raum, um uns zu fragen, worauf es uns im Leben wirklich ankommt, wofür wir unsere Energie einsetzen wollen und was eigentlich die Quelle unserer Existenz ausmacht.
<G-vec00384-001-s390><ask.fragen><en> First, I am still active on the Ask at the Shell Gas station on pilgrimage and then I like a well-behaved Lemming out again.
<G-vec00384-001-s390><ask.fragen><de> Erst rege ich mich noch über die Fragen an der Shell Tankstelle auf und dann pilgere ich wie ein gut erzogener Lemming nochmal hin.
<G-vec00384-001-s391><ask.fragen><en> In the beginning of the war, When The people had not been united, as the leaders thought They would ask, the war went bad for France.
<G-vec00384-001-s391><ask.fragen><de> Am Anfang des Krieges, als die Leute noch nicht vereint, wie die Führer dachte, Sie würden fragen, der Krieg ging schlecht für Frankreich.
<G-vec00384-001-s392><ask.fragen><en> Some comrades will ask us, not without indignation, “Would you be against organic unity?”
<G-vec00384-001-s392><ask.fragen><de> „Was, ihr seid also gegen die organische Einheit?“, werden uns nicht ohne Entrüstung manche Genossen fragen.
<G-vec00384-001-s393><ask.fragen><en> AllExperts is an American website, where you can ask anything, including about chess, and get an answer.
<G-vec00384-001-s393><ask.fragen><de> AllExperts ist eine amerikanische Website, auf der Sie irgendetwas, einschließend Dinge über Schachspiel, fragen können, und eine Antwort erhalten können.
<G-vec00384-001-s394><ask.fragen><en> Greater privacy when you gamble - Beyond your email address, most Bitcoin casinos will not ask you for any of your other personal details and there are many mechanisms that exist with Bitcoin to protect the privacy of its users. Want to try your luck at a Bitcoin Casino? Check out our top list of the best Bitcoin online casinos here.
<G-vec00384-001-s394><ask.fragen><de> Mehr Anonymität beim Glücksspiel – Bitcoin Casinos werden Sie lediglich nach Ihrer E-Mail-Adresse fragen, darüber hinaus werden keine weiteren persönlichen Angaben benötigt, und es bestehen zahlreiche Maßnahmen, die mit dieser einzigartigen Zahlungsoption eingeführt wurden, um die Privatsphäre der Nutzer zu schützen.
<G-vec00384-001-s395><ask.fragen><en> You have to pray and to ask yourselves what you have to pray for.
<G-vec00384-001-s395><ask.fragen><de> Ihr müsst beten und euch selbst fragen, worum ihr beten müsst.
<G-vec00384-001-s396><ask.fragen><en> The employees of Empire of Sports AG will never ask you for your password and you should never give it to anyone who does ask for it.
<G-vec00384-001-s396><ask.fragen><de> Die Mitarbeiter von Empire of Sports AG werden Sie nie nach Ihrem Kennwort fragen und Sie sollten es niemals ausgeben, wenn Sie danach gefragt werden.
<G-vec00384-001-s397><ask.fragen><en> As you shop online for the best auto insurance deals you may begin to ask yourself what exactly is required by law when it comes to auto insurance.
<G-vec00384-001-s397><ask.fragen><de> Wie Sie Online-Shop für die beste Auto-Versicherung können Sie uns beginnen, fragen Sie sich, was gesetzlich vorgeschrieben ist, wenn es um die Auto-Versicherung.
<G-vec00384-001-s398><ask.fragen><en> You ask for it and simply get online, if you want to repeat the series.
<G-vec00384-001-s398><ask.fragen><de> Sie Fragen Sie und einfach online, wenn Sie möchten, wiederholen Sie die Serie.
<G-vec00272-001-s399><ask.fragen><en> People today ask the couple to do things and the few acts the certain way to make the things right.
<G-vec00272-001-s399><ask.fragen><de> Die Menschen heute Fragen sich die paar Dinge zu tun und die wenigen Handlungen, die bestimmte Art und Weise zu machen die Dinge richtig.
<G-vec00272-001-s400><ask.fragen><en> People ask the couple to do the few behaves the way.
<G-vec00272-001-s400><ask.fragen><de> Die Menschen Fragen sich das paar zu tun, das einige sich so verhält, wie.
<G-vec00272-001-s401><ask.fragen><en> It is common that patients ask their treating physicians whether their relatives are at an increased risk of developing the disease too.
<G-vec00272-001-s401><ask.fragen><de> Oft fragen die Patienten die behandelnden Ärzte von sich aus, ob ihre Verwandten einem erhöhten Erkrankungsrisiko ausgesetzt sind.
<G-vec00272-001-s402><ask.fragen><en> Therefore, I expect that the problems with these data sources mean that researchers will continue to ask respondents about their behavior for the foreseeable future.
<G-vec00272-001-s402><ask.fragen><de> Deshalb erwarte ich, dass die Probleme mit diesen Datenquellen bedeuten, dass die Forscher die Befragten Ã1⁄4ber ihr Verhalten fÃ1⁄4r die absehbare Zukunft zu fragen, wird sich fortsetzen.
<G-vec00272-001-s403><ask.fragen><en> Many people ask whether God still works miracles in this day and age.
<G-vec00272-001-s403><ask.fragen><de> Viele Menschen fragen sich, ob Gott auch heute noch Wunder wirken kann.
<G-vec00272-001-s404><ask.fragen><en> People ask the few to do things and the few behaves the specific means to make the items right.
<G-vec00272-001-s404><ask.fragen><de> Die Menschen Fragen sich das einige, Dinge zu tun und die wenigen, verhält sich die spezifischen Mittel, um den Artikel direkt.
<G-vec00272-001-s405><ask.fragen><en> Some people might even ask why I have included this category in my list.
<G-vec00272-001-s405><ask.fragen><de> Einige Leute fragen sich vielleicht sogar, warum ich diese Kategorie in meine Liste aufgenommen habe.
<G-vec00272-001-s406><ask.fragen><en> People ask the couple to do the few behaves the specific means.
<G-vec00272-001-s406><ask.fragen><de> Die Menschen Fragen sich das paar zu tun, das paar verhält sich das spezifische Mittel.
<G-vec00272-001-s407><ask.fragen><en> People ask the couple to do the few behaves the specific way to create the items right.
<G-vec00272-001-s407><ask.fragen><de> Die Menschen Fragen sich das paar zu tun, das paar verhält sich die spezifische Art und Weise zu erstellen, die Elemente rechts.
<G-vec00272-001-s408><ask.fragen><en> People today ask the few to do things and the couple acts the certain means to make the items right.
<G-vec00272-001-s408><ask.fragen><de> Die Menschen heute Fragen sich die paar Dinge zu tun, und die paar, die Handlungen, die bestimmte Mittel, um den Artikel direkt.
<G-vec00272-001-s409><ask.fragen><en> You may ask why these scans can't be done on your local computer.
<G-vec00272-001-s409><ask.fragen><de> Sie fragen sich wohl, warum diese Scans nicht lokal auf Ihrem Computer durchgeführt werden können.
<G-vec00272-001-s410><ask.fragen><en> People ask the couple to do the few behaves the means to make the things right.
<G-vec00272-001-s410><ask.fragen><de> Die Menschen Fragen sich das paar zu tun, das paar verhält sich die Mittel, um die Dinge richtig.
<G-vec00272-001-s411><ask.fragen><en> People today ask the few to do things and the couple acts the means to create the things right.
<G-vec00272-001-s411><ask.fragen><de> Die Menschen heute Fragen sich die paar Dinge zu tun, und die paar, die Handlungen, die Mittel zu schaffen, die Dinge richtig.
<G-vec00272-001-s412><ask.fragen><en> Let us first ask which concrete model assumptions lead to the contradiction to the wave model of the light.
<G-vec00272-001-s412><ask.fragen><de> Fragen wir uns zunächst, aus welchen konkreten Modellannahmen sich eigentlich der Widerspruch zum Wellenbild des Lichts ergibt.
<G-vec00272-001-s413><ask.fragen><en> On the contrary, one could ask her many things without pushing them.
<G-vec00272-001-s413><ask.fragen><de> Im Gegenteil, man konnte sie so manches fragen, ohne dass sie sich aufdrängten.
<G-vec00272-001-s414><ask.fragen><en> Nonetheless Europe's commentators find plenty to discuss: they explain how Crimea will vote, and ask how long Putin will remain in power.
<G-vec00272-001-s414><ask.fragen><de> Genug Diskussionsstoff bietet die Wahl für Europas Kommentatoren dennoch: Sie erklären, wie die Krim abstimmen wird und fragen sich, wie lange Putin noch im Amt bleibt.
<G-vec00272-001-s415><ask.fragen><en> """If you ask me... the artist... knows it quite well how to use provocation."
<G-vec00272-001-s415><ask.fragen><de> """Wenn Sie mich fragen versteht sich der Mardorfer Künstler Dr. Hans-Joachim Bauer trefflich auf das Mittel der Provokation."
<G-vec00272-001-s416><ask.fragen><en> With the new Nokia X, you might ask how can you transfer all the music on your iPod to this new Nokia X, how to sync music to Nokia XL.
<G-vec00272-001-s416><ask.fragen><de> Mit dem neuen Nokia X, Sie fragen sich vielleicht, wie Sie die Musik auf Ihrem iPod auf diese neue Nokia X übertragen, wie zu synchronisieren Musik zu Nokia XL.
<G-vec00272-001-s417><ask.fragen><en> In this connection, a pedagogy of the arts will ask about ways and means for constituting artistic education in processes and discourse.
<G-vec00272-001-s417><ask.fragen><de> In diesem Zusammenhang wird eine Pädagogik der Künste nach der Art und Weise fragen, wie sich künstlerische Bildung im Prozess und Diskurs konstituieren kann.
<G-vec00272-001-s418><ask.fragen><en> 1)From Kottayam 12 kms... to the house of Georgekutty, Kottapparampil(via)Pulikkuttyssery, puthenthodu, Valliadu S. N. D. P and cross the bridge in right and proceed to left and ask for the above mentioned address.2)If you inform us about your arrival we will receive you from the Air port, bus or railway stations or from Kottayam even if you come by taxi.UP TO KOTAYAM THERE ARE TRAINS AND BUSES ARE AVAILABE FROM EVERY WHERE.
<G-vec00272-001-s418><ask.fragen><de> Alles löschen Wie man dorthin kommt 1) Vom Kottayam 12 km... in das Haus des Georgekutty, Kottapparampil(Via) Pulikkuttyssery, puthenthodu, Valliadu SNDP und überqueren die Brücke in rechts und fahren Sie links ab und fragen Sie nach der oben genannten Adresse.2) Wenn Sie informieren uns über Ihre Ankunft werden wir Sie von der Air-Port empfangen, Bus oder Bahn-Stationen oder von Kottayam, auch wenn Sie mit dem Taxi kommen.UP TO KOTAYAM gibt es Züge und Busse sind erhältlich von JEDER WHERE.
<G-vec00272-001-s419><ask.fragen><en> However, it is authorised not everywhere, so simply ask local residents before to be dipped.
<G-vec00272-001-s419><ask.fragen><de> Im übrigen, wird es nicht überall erlaubt, so dass die Ortsbewohner einfach fragen Sie, bevor einzutauchen.
<G-vec00272-001-s420><ask.fragen><en> Ask them what their secrets are, and hey will surely be willing to help.
<G-vec00272-001-s420><ask.fragen><de> Fragen Sie sie, was ihre Geheimnisse sind, und he seien Sie sicher bereit zu helfen.
<G-vec00272-001-s421><ask.fragen><en> This varies by webhoster, either ask your webhoster or in the forum for advice.
<G-vec00272-001-s421><ask.fragen><de> Fragen Sie entweder Ihren Webhoster oder im Forum nach Rat.
<G-vec00272-001-s422><ask.fragen><en> You can communicate with the women, ask to do everything you want and try women.
<G-vec00272-001-s422><ask.fragen><de> Sie können die Kommunikation mit den Frauen, Fragen Sie alles, was Sie tun wollen und versuchen, Frauen.
<G-vec00272-001-s423><ask.fragen><en> Ask any GM, and the thing we all want is to have our young players come through.
<G-vec00272-001-s423><ask.fragen><de> Fragen Sie einen GM, und das, was wir alle wollen, ist es, dass unsere jungen Spieler kommen durch.
<G-vec00272-001-s424><ask.fragen><en> Also ask your midwife about birth preparation courses.
<G-vec00272-001-s424><ask.fragen><de> Fragen Sie Ihre Hebamme auch nach Kursen für die Geburtsvorbereitung.
<G-vec00272-001-s425><ask.fragen><en> Just ask the 1,700 employees being made redundant at Corus's steel plant in Redcar.
<G-vec00272-001-s425><ask.fragen><de> Fragen Sie einfach die 1.700 Mitarbeiter, die bei dem Stahlwerk Corus in Redcar entlassen wurden.
<G-vec00272-001-s426><ask.fragen><en> Please read our information for bulky luggage or ask directly to Munich Airport or your airline.
<G-vec00272-001-s426><ask.fragen><de> Bitte lesen Sie hierzu unsere Informationen zum Sperrgepäck oder fragen Sie direkt am Münchner Flughafen oder bei Ihrer Airline nach.
<G-vec00272-001-s427><ask.fragen><en> When you place an order with Europoolshop, we ask for your name, your billing address, the address for shipment of the order, your credit card number and expiration date and your email address.
<G-vec00272-001-s427><ask.fragen><de> Wenn Sie bei Europoolshop eine Bestellung aufgeben, fragen wir Sie nach Ihrem Namen, der Adresse des Rechnungsempfängers, der Lieferadresse für die Bestellung, Ihrer Kreditkartennummer mit Gültigkeitsdauer sowie nach Ihrer E-Mail Adresse.
<G-vec00272-001-s428><ask.fragen><en> If the program does not arrange for visas, ask for a letter of introduction to present along with your application for a visa.
<G-vec00272-001-s428><ask.fragen><de> Wenn das Programm nicht für Visa arrangieren, fragen Sie nach einem Brief der Einführung zu präsentieren zusammen mit Ihrem Antrag auf ein Visum.
<G-vec00272-001-s429><ask.fragen><en> Ask your boss, your partner, your friends s, Yes, really, you listening ear.
<G-vec00272-001-s429><ask.fragen><de> Fragen Sie Ihren Chef, Ihr Partner, Ihre Freunde s, wenn Sie wirklich, Sie hören Ohr.
<G-vec00272-001-s430><ask.fragen><en> Ask me how I do to reach out to people and portraying them spontaneously, one of the ways to do is talk to them... or try.
<G-vec00272-001-s430><ask.fragen><de> Fragen Sie mich, wie ich tun, um Menschen und porträtiert sie spontan zu erreichen, einer der Wege zu tun ist, sprechen Sie mit ihnen... oder versuchen.
<G-vec00272-001-s431><ask.fragen><en> Ask the render for the way to the next stop.
<G-vec00272-001-s431><ask.fragen><de> Fragen Sie den Vermieter nach dem Weg zu der nächsten Haltestelle.
<G-vec00272-001-s432><ask.fragen><en> Ask for your two references in time to include these with your application.
<G-vec00272-001-s432><ask.fragen><de> Fragen Sie rechtzeitig nach Ihren zwei Referenzen, um sie Ihrer Bewerbung beizufügen.
<G-vec00272-001-s433><ask.fragen><en> Ask at the Town Hall or ask one of the local residents.
<G-vec00272-001-s433><ask.fragen><de> Fragen Sie im Rathaus oder fragen Sie einen der Anwohner.
<G-vec00272-001-s434><ask.fragen><en> Ask at the Town Hall or ask one of the local residents.
<G-vec00272-001-s434><ask.fragen><de> Fragen Sie im Rathaus oder fragen Sie einen der Anwohner.
<G-vec00272-001-s435><ask.fragen><en> pcs Ask more about the product
<G-vec00272-001-s435><ask.fragen><de> Fragen Sie mehr über das Produkt.
<G-vec00272-001-s436><ask.fragen><en> Research them on the Internet and ask the more experienced players for their opinions on the guns in question.
<G-vec00272-001-s436><ask.fragen><de> Forschung auf dem Internet und fragen Sie die erfahrenen Spieler für ihre Stellungnahmen zu den Waffen in Frage.
<G-vec00384-001-s418><ask.fragen><en> 1)From Kottayam 12 kms... to the house of Georgekutty, Kottapparampil(via)Pulikkuttyssery, puthenthodu, Valliadu S. N. D. P and cross the bridge in right and proceed to left and ask for the above mentioned address.2)If you inform us about your arrival we will receive you from the Air port, bus or railway stations or from Kottayam even if you come by taxi.UP TO KOTAYAM THERE ARE TRAINS AND BUSES ARE AVAILABE FROM EVERY WHERE.
<G-vec00384-001-s418><ask.fragen><de> Alles löschen Wie man dorthin kommt 1) Vom Kottayam 12 km... in das Haus des Georgekutty, Kottapparampil(Via) Pulikkuttyssery, puthenthodu, Valliadu SNDP und überqueren die Brücke in rechts und fahren Sie links ab und fragen Sie nach der oben genannten Adresse.2) Wenn Sie informieren uns über Ihre Ankunft werden wir Sie von der Air-Port empfangen, Bus oder Bahn-Stationen oder von Kottayam, auch wenn Sie mit dem Taxi kommen.UP TO KOTAYAM gibt es Züge und Busse sind erhältlich von JEDER WHERE.
<G-vec00384-001-s419><ask.fragen><en> However, it is authorised not everywhere, so simply ask local residents before to be dipped.
<G-vec00384-001-s419><ask.fragen><de> Im übrigen, wird es nicht überall erlaubt, so dass die Ortsbewohner einfach fragen Sie, bevor einzutauchen.
<G-vec00384-001-s420><ask.fragen><en> Ask them what their secrets are, and hey will surely be willing to help.
<G-vec00384-001-s420><ask.fragen><de> Fragen Sie sie, was ihre Geheimnisse sind, und he seien Sie sicher bereit zu helfen.
<G-vec00384-001-s421><ask.fragen><en> This varies by webhoster, either ask your webhoster or in the forum for advice.
<G-vec00384-001-s421><ask.fragen><de> Fragen Sie entweder Ihren Webhoster oder im Forum nach Rat.
<G-vec00384-001-s422><ask.fragen><en> You can communicate with the women, ask to do everything you want and try women.
<G-vec00384-001-s422><ask.fragen><de> Sie können die Kommunikation mit den Frauen, Fragen Sie alles, was Sie tun wollen und versuchen, Frauen.
<G-vec00384-001-s423><ask.fragen><en> Ask any GM, and the thing we all want is to have our young players come through.
<G-vec00384-001-s423><ask.fragen><de> Fragen Sie einen GM, und das, was wir alle wollen, ist es, dass unsere jungen Spieler kommen durch.
<G-vec00384-001-s424><ask.fragen><en> Also ask your midwife about birth preparation courses.
<G-vec00384-001-s424><ask.fragen><de> Fragen Sie Ihre Hebamme auch nach Kursen für die Geburtsvorbereitung.
<G-vec00384-001-s425><ask.fragen><en> Just ask the 1,700 employees being made redundant at Corus's steel plant in Redcar.
<G-vec00384-001-s425><ask.fragen><de> Fragen Sie einfach die 1.700 Mitarbeiter, die bei dem Stahlwerk Corus in Redcar entlassen wurden.
<G-vec00384-001-s426><ask.fragen><en> Please read our information for bulky luggage or ask directly to Munich Airport or your airline.
<G-vec00384-001-s426><ask.fragen><de> Bitte lesen Sie hierzu unsere Informationen zum Sperrgepäck oder fragen Sie direkt am Münchner Flughafen oder bei Ihrer Airline nach.
<G-vec00384-001-s427><ask.fragen><en> When you place an order with Europoolshop, we ask for your name, your billing address, the address for shipment of the order, your credit card number and expiration date and your email address.
<G-vec00384-001-s427><ask.fragen><de> Wenn Sie bei Europoolshop eine Bestellung aufgeben, fragen wir Sie nach Ihrem Namen, der Adresse des Rechnungsempfängers, der Lieferadresse für die Bestellung, Ihrer Kreditkartennummer mit Gültigkeitsdauer sowie nach Ihrer E-Mail Adresse.
<G-vec00384-001-s428><ask.fragen><en> If the program does not arrange for visas, ask for a letter of introduction to present along with your application for a visa.
<G-vec00384-001-s428><ask.fragen><de> Wenn das Programm nicht für Visa arrangieren, fragen Sie nach einem Brief der Einführung zu präsentieren zusammen mit Ihrem Antrag auf ein Visum.
<G-vec00384-001-s429><ask.fragen><en> Ask your boss, your partner, your friends s, Yes, really, you listening ear.
<G-vec00384-001-s429><ask.fragen><de> Fragen Sie Ihren Chef, Ihr Partner, Ihre Freunde s, wenn Sie wirklich, Sie hören Ohr.
<G-vec00384-001-s430><ask.fragen><en> Ask me how I do to reach out to people and portraying them spontaneously, one of the ways to do is talk to them... or try.
<G-vec00384-001-s430><ask.fragen><de> Fragen Sie mich, wie ich tun, um Menschen und porträtiert sie spontan zu erreichen, einer der Wege zu tun ist, sprechen Sie mit ihnen... oder versuchen.
<G-vec00384-001-s431><ask.fragen><en> Ask the render for the way to the next stop.
<G-vec00384-001-s431><ask.fragen><de> Fragen Sie den Vermieter nach dem Weg zu der nächsten Haltestelle.
<G-vec00384-001-s432><ask.fragen><en> Ask for your two references in time to include these with your application.
<G-vec00384-001-s432><ask.fragen><de> Fragen Sie rechtzeitig nach Ihren zwei Referenzen, um sie Ihrer Bewerbung beizufügen.
<G-vec00384-001-s433><ask.fragen><en> Ask at the Town Hall or ask one of the local residents.
<G-vec00384-001-s433><ask.fragen><de> Fragen Sie im Rathaus oder fragen Sie einen der Anwohner.
<G-vec00384-001-s434><ask.fragen><en> Ask at the Town Hall or ask one of the local residents.
<G-vec00384-001-s434><ask.fragen><de> Fragen Sie im Rathaus oder fragen Sie einen der Anwohner.
<G-vec00384-001-s435><ask.fragen><en> pcs Ask more about the product
<G-vec00384-001-s435><ask.fragen><de> Fragen Sie mehr über das Produkt.
<G-vec00384-001-s436><ask.fragen><en> Research them on the Internet and ask the more experienced players for their opinions on the guns in question.
<G-vec00384-001-s436><ask.fragen><de> Forschung auf dem Internet und fragen Sie die erfahrenen Spieler für ihre Stellungnahmen zu den Waffen in Frage.
<G-vec00272-001-s437><ask.fragen><en> You ask about rituals, well, it's a fascinating subject.
<G-vec00272-001-s437><ask.fragen><de> Du fragst nach Ritualen, tja, das ist ein faszinierendes Thema.
<G-vec00272-001-s438><ask.fragen><en> The prices for memberships are pretty cheap, if you ask me.
<G-vec00272-001-s438><ask.fragen><de> Die Preise für Mitgliedschaften sind ziemlich günstig, wenn du mich fragst.
<G-vec00272-001-s439><ask.fragen><en> I enjoy how you ask and then answer yourself, because it does help you keep your orientation toward that open, universal field that is, ultimately and singularly, God's will.
<G-vec00272-001-s439><ask.fragen><de> Ich freue mich, wie du fragst und dann selber antwortest, weil es dir hilft, deine Orientierung auf dieses offene, universale Feld zu halten, das letztlich und einzigartig Gottes Wille ist.
<G-vec00272-001-s440><ask.fragen><en> Aram: No problem at all if you ask me.
<G-vec00272-001-s440><ask.fragen><de> Aram: Nein, das ist war überhaupt kein Problem, wenn du mich fragst.
<G-vec00272-001-s441><ask.fragen><en> You do not ask Me which dress to wear or purse to carry.
<G-vec00272-001-s441><ask.fragen><de> Du fragst Mich nicht, welches Kleid oder welche Tasche du tragen sollst.
<G-vec00272-001-s442><ask.fragen><en> A pretty easy one if you ask me.
<G-vec00272-001-s442><ask.fragen><de> Eine ziemliche einfache wenn du mich fragst.
<G-vec00272-001-s443><ask.fragen><en> If thou ask them, who created them, they will certainly say, Allah.
<G-vec00272-001-s443><ask.fragen><de> Und wenn du sie fragst: «Wer schuf sie>», werden sie sicherlich sagen: «Allah».
<G-vec00272-001-s444><ask.fragen><en> The answer depends on who you ask, but the bottom line is this: properly prepped, you can paint anything over anything.
<G-vec00272-001-s444><ask.fragen><de> Die Antwort ist davon abhängig, wen du fragst, aber grundsätzlich kann gesagt werden: Bei einer gründlichen Vorbereitung kannst du nahezu jede Farbe über eine andere Farbe streichen.
<G-vec00272-001-s445><ask.fragen><en> if you ask me, i will tell you i agree, i tried to explain to my wife how this Walters program but she insisted i was reckless to invest in the said skills of someone i heard of online, my first payout put a sock in her mouth and we haven’t stopped working with Walter ever since.
<G-vec00272-001-s445><ask.fragen><de> wenn du mich fragst, Ich werde Ihnen sagen, ich stimme zu, i tried to explain to my wife how this Walters program but she insisted i was reckless to invest in the said skills of someone i heard of online, meine erste Auszahlung legte eine Socke in den Mund und wir aufgehört haben, nicht mit Walter jemals arbeiten seit.
<G-vec00272-001-s446><ask.fragen><en> [29.61] If you ask them: 'Who has created the heavens and the earth and subjected the sun and the moon?' They will say: 'Allah.' How perverted they are!
<G-vec00272-001-s446><ask.fragen><de> [29.61] Und wenn du sie fragst: ┬źWer hat die Himmel und die Erde geschaffen und die Sonne und den Mond dienstbar gemacht?┬╗ dann werden sie gewi├člich sagen: ┬źAllah┬╗.
<G-vec00272-001-s447><ask.fragen><en> """I would have expected that you'd ask 'Where'"", Pallys returned."
<G-vec00272-001-s447><ask.fragen><de> """Ich hätte erwartet, daß du 'Wo' fragst"", gab Pallys zurück."
<G-vec00272-001-s448><ask.fragen><en> That’s a big deal if you ask me.
<G-vec00272-001-s448><ask.fragen><de> Ganz schön viele Leute, wenn Du mich fragst.
<G-vec00272-001-s449><ask.fragen><en> What is the point of a game of cards, you ask.
<G-vec00272-001-s449><ask.fragen><de> Was ist der Punkt bei einem Kartenspiel, fragst du.
<G-vec00272-001-s450><ask.fragen><en> This site allows their viewers to download any of the presented manga, and that is quite a hot deal if you ask me.
<G-vec00272-001-s450><ask.fragen><de> Diese Seite erlaubt es ihren Zuschauern, jeden der vorgestellten Manga herunterzuladen, und das ist ein ziemlich heißes Geschäft, wenn du mich fragst.
<G-vec00272-001-s451><ask.fragen><en> And you can ask us any sort of inquiries you have.
<G-vec00272-001-s451><ask.fragen><de> Und fragst du uns alle Fragen, die Sie haben.
<G-vec00272-001-s452><ask.fragen><en> I always say Professor Google only tells you what you ask.
<G-vec00272-001-s452><ask.fragen><de> Ich sage immer, Professor Google sagt dir nur das, was du fragst.
<G-vec00272-001-s453><ask.fragen><en> One could argue and say that they are shitty quality because most of them are amateur clips, but they might just have been re-uploaded too many times if you ask me.
<G-vec00272-001-s453><ask.fragen><de> Man könnte argumentieren und sagen, dass sie von beschissener Qualität sind, weil die meisten von ihnen Amateur-Clips sind, aber sie könnten einfach zu oft neu hochgeladen worden sein, wenn du mich fragst.
<G-vec00272-001-s454><ask.fragen><en> The visa requirements vary depending both on your residence and target country so it is important for you to ask at the host country's embassy placed in your country what are the requirements to get a visa issued to work as an Au Pair.
<G-vec00272-001-s454><ask.fragen><de> Die Visa Voraussetzungen variieren je nach Heimat- und Zielland, es ist also wichtig, dass du die Botschaft des Gastlandes mit Sitz in der Heimat nach den Bedingungen für ein Visum als Au Pair fragst.
<G-vec00272-001-s455><ask.fragen><en> Why do you ask?” Goku answered, intrigued.
<G-vec00272-001-s455><ask.fragen><de> Warum fragst du?“, wollte Goku wissen.
<G-vec00384-001-s437><ask.fragen><en> You ask about rituals, well, it's a fascinating subject.
<G-vec00384-001-s437><ask.fragen><de> Du fragst nach Ritualen, tja, das ist ein faszinierendes Thema.
<G-vec00384-001-s438><ask.fragen><en> The prices for memberships are pretty cheap, if you ask me.
<G-vec00384-001-s438><ask.fragen><de> Die Preise für Mitgliedschaften sind ziemlich günstig, wenn du mich fragst.
<G-vec00384-001-s439><ask.fragen><en> I enjoy how you ask and then answer yourself, because it does help you keep your orientation toward that open, universal field that is, ultimately and singularly, God's will.
<G-vec00384-001-s439><ask.fragen><de> Ich freue mich, wie du fragst und dann selber antwortest, weil es dir hilft, deine Orientierung auf dieses offene, universale Feld zu halten, das letztlich und einzigartig Gottes Wille ist.
<G-vec00384-001-s440><ask.fragen><en> Aram: No problem at all if you ask me.
<G-vec00384-001-s440><ask.fragen><de> Aram: Nein, das ist war überhaupt kein Problem, wenn du mich fragst.
<G-vec00384-001-s441><ask.fragen><en> You do not ask Me which dress to wear or purse to carry.
<G-vec00384-001-s441><ask.fragen><de> Du fragst Mich nicht, welches Kleid oder welche Tasche du tragen sollst.
<G-vec00384-001-s442><ask.fragen><en> A pretty easy one if you ask me.
<G-vec00384-001-s442><ask.fragen><de> Eine ziemliche einfache wenn du mich fragst.
<G-vec00384-001-s443><ask.fragen><en> If thou ask them, who created them, they will certainly say, Allah.
<G-vec00384-001-s443><ask.fragen><de> Und wenn du sie fragst: «Wer schuf sie>», werden sie sicherlich sagen: «Allah».
<G-vec00384-001-s444><ask.fragen><en> The answer depends on who you ask, but the bottom line is this: properly prepped, you can paint anything over anything.
<G-vec00384-001-s444><ask.fragen><de> Die Antwort ist davon abhängig, wen du fragst, aber grundsätzlich kann gesagt werden: Bei einer gründlichen Vorbereitung kannst du nahezu jede Farbe über eine andere Farbe streichen.
<G-vec00384-001-s445><ask.fragen><en> if you ask me, i will tell you i agree, i tried to explain to my wife how this Walters program but she insisted i was reckless to invest in the said skills of someone i heard of online, my first payout put a sock in her mouth and we haven’t stopped working with Walter ever since.
<G-vec00384-001-s445><ask.fragen><de> wenn du mich fragst, Ich werde Ihnen sagen, ich stimme zu, i tried to explain to my wife how this Walters program but she insisted i was reckless to invest in the said skills of someone i heard of online, meine erste Auszahlung legte eine Socke in den Mund und wir aufgehört haben, nicht mit Walter jemals arbeiten seit.
<G-vec00384-001-s446><ask.fragen><en> [29.61] If you ask them: 'Who has created the heavens and the earth and subjected the sun and the moon?' They will say: 'Allah.' How perverted they are!
<G-vec00384-001-s446><ask.fragen><de> [29.61] Und wenn du sie fragst: ┬źWer hat die Himmel und die Erde geschaffen und die Sonne und den Mond dienstbar gemacht?┬╗ dann werden sie gewi├člich sagen: ┬źAllah┬╗.
<G-vec00384-001-s447><ask.fragen><en> """I would have expected that you'd ask 'Where'"", Pallys returned."
<G-vec00384-001-s447><ask.fragen><de> """Ich hätte erwartet, daß du 'Wo' fragst"", gab Pallys zurück."
<G-vec00384-001-s448><ask.fragen><en> That’s a big deal if you ask me.
<G-vec00384-001-s448><ask.fragen><de> Ganz schön viele Leute, wenn Du mich fragst.
<G-vec00384-001-s449><ask.fragen><en> What is the point of a game of cards, you ask.
<G-vec00384-001-s449><ask.fragen><de> Was ist der Punkt bei einem Kartenspiel, fragst du.
<G-vec00384-001-s450><ask.fragen><en> This site allows their viewers to download any of the presented manga, and that is quite a hot deal if you ask me.
<G-vec00384-001-s450><ask.fragen><de> Diese Seite erlaubt es ihren Zuschauern, jeden der vorgestellten Manga herunterzuladen, und das ist ein ziemlich heißes Geschäft, wenn du mich fragst.
<G-vec00384-001-s451><ask.fragen><en> And you can ask us any sort of inquiries you have.
<G-vec00384-001-s451><ask.fragen><de> Und fragst du uns alle Fragen, die Sie haben.
<G-vec00384-001-s452><ask.fragen><en> I always say Professor Google only tells you what you ask.
<G-vec00384-001-s452><ask.fragen><de> Ich sage immer, Professor Google sagt dir nur das, was du fragst.
<G-vec00384-001-s453><ask.fragen><en> One could argue and say that they are shitty quality because most of them are amateur clips, but they might just have been re-uploaded too many times if you ask me.
<G-vec00384-001-s453><ask.fragen><de> Man könnte argumentieren und sagen, dass sie von beschissener Qualität sind, weil die meisten von ihnen Amateur-Clips sind, aber sie könnten einfach zu oft neu hochgeladen worden sein, wenn du mich fragst.
<G-vec00384-001-s454><ask.fragen><en> The visa requirements vary depending both on your residence and target country so it is important for you to ask at the host country's embassy placed in your country what are the requirements to get a visa issued to work as an Au Pair.
<G-vec00384-001-s454><ask.fragen><de> Die Visa Voraussetzungen variieren je nach Heimat- und Zielland, es ist also wichtig, dass du die Botschaft des Gastlandes mit Sitz in der Heimat nach den Bedingungen für ein Visum als Au Pair fragst.
<G-vec00384-001-s455><ask.fragen><en> Why do you ask?” Goku answered, intrigued.
<G-vec00384-001-s455><ask.fragen><de> Warum fragst du?“, wollte Goku wissen.
<G-vec00272-001-s456><ask.fragen><en> Ask yourself now...
<G-vec00272-001-s456><ask.fragen><de> Fragt euch das jetzt selbst...
<G-vec00272-001-s457><ask.fragen><en> I would like you to think about that – and it does help if you can ask for some help from The Source, from God The Source of All – to take away any confusion or friction that maybe around and so that will make that easier for you to flow in the day of your life.
<G-vec00272-001-s457><ask.fragen><de> Ich moechte gerne das Ihr darueber nachdenkt – und es hilft sehr wenn Ihr um Hilfe fragt von Der Kreatur des Allen, vom Gott Dem Ursprung des Allen – etwaige Verwirrung oder Friktion die herum sind wegzunehmen und dadurch wird es für Euch leichter sein durch den Tag zu kommen.
<G-vec00272-001-s458><ask.fragen><en> Yet ask him which of the awards has been the most valuable to him, then you will certainly get the reply, “Awards for my cuisine are indeed a certain extent extra.
<G-vec00272-001-s458><ask.fragen><de> Fragt man ihn aber, welche der Auszeichnungen für ihn am wertvollsten war, dann bekommt man die zu seiner Person passende Antwort: „Die Auszeichnungen meiner Kochkunst sind gewissermaßen das Salz in der Suppe.
<G-vec00272-001-s459><ask.fragen><en> If you ask there, it should usually be no problem for you to use the toilet without eating in the restaurant.
<G-vec00272-001-s459><ask.fragen><de> Fragt man dort nach, sollte es meist kein Problem sein, deren Toilette auch ohne einen Verzehr benutzen zu dürfen.
<G-vec00272-001-s460><ask.fragen><en> "I f they ask you, ""What is the sign of your Father in you?"" say to them, “it is movement and repose.”"
<G-vec00272-001-s460><ask.fragen><de> W enn man euch fragt: «Was ist das Zeichen eures Vaters in euch?», sagt zu ihnen: «Bewegung ist es und Ruhe».
<G-vec00272-001-s461><ask.fragen><en> "These ulterior resources and the strengthening of the patrimonial state - it has specified - will allow us to satisfy the increasing ask of the customers widening our fleet with new ships and estimating opportunity of strategic acquisitions times to the increase""."
<G-vec00272-001-s461><ask.fragen><de> "Diese zusätzlichen Ressourcen und die Stärkung von dem Kontostand werden zulassen uns fragt von der Kundschaft unsere Flotte mit neuen Schiffen das Wachstum erweitert und bewertet Gelegenheit von den strategischen wendet Erwerben"", den Wachsend zu befriedigen,- hat es spezifiziert -."
<G-vec00272-001-s462><ask.fragen><en> "I know ladies, if you ask them they said, ""I observe Monday, I observe Tuesday; I observe Wednesday, I observe Thursday; I observe Friday as a fast, and perhaps maybe, if I do not starve on Saturday I will eat on Sunday."""
<G-vec00272-001-s462><ask.fragen><de> "Ich kenne Frauen, wenn man sie fragt, sagen sie: ""Ich faste Montag, ich faste Dienstag, ich faste Mittwoch, ich faste Donnerstag, ich faste Freitag, und wenn ich am Samstag nicht verhungert bin, werde ich am Sonntag essen""."
<G-vec00272-001-s463><ask.fragen><en> If this is not set for a three-way diff, then TortoiseMerge will ask the user where to save the result.
<G-vec00272-001-s463><ask.fragen><de> Wenn dieser Parameter für einen Dreiwegevergleich nicht angegeben wurde, fragt TortoiseSVN den Anwender, wo die Ergebnisse gespeichert werden sollen.
<G-vec00272-001-s464><ask.fragen><en> For example, someone may ask an astrologer whether to invest in one venture or the other.
<G-vec00272-001-s464><ask.fragen><de> Als Beispiel: Eine Person fragt einen Astrologen, ob er in das eine Unternehmen oder besser in das andere investieren sollte.
<G-vec00272-001-s465><ask.fragen><en> We are able to give information for certain things in the area if you pop in the office (or ask the porters).
<G-vec00272-001-s465><ask.fragen><de> Wir können jeden mit Informationen über die Umgebung bedienen, wenn man in unserem Büro vorbeischaut (oder die Pförtner fragt).
<G-vec00272-001-s466><ask.fragen><en> Ask members of DREAM THEATER or QUEENSRYCHE about their biggest musical influences, the first name that will be mentioned in an almost reverent way will be the one of Jim Matheos' band.
<G-vec00272-001-s466><ask.fragen><de> Fragt man Musiker von Bands wie DREAM THEATER oder QUEENSRYCHE nach ihren größten musikalischen Einflüssen, wird der Name der Truppe um Jim Matheos fast ehrfürchtig als allererstes erwähnt.
<G-vec00272-001-s467><ask.fragen><en> "If you want a coffee, you ask for an ""americano."""
<G-vec00272-001-s467><ask.fragen><de> "Wer einen Kaffee will, fragt nach einem ""americano""."
<G-vec00272-001-s468><ask.fragen><en> They probably don´t ask anyone at all (aside from the merchants that is).
<G-vec00272-001-s468><ask.fragen><de> Wahrscheinlich fragt man auch sonst niemanden (außer die Fotohändler).
<G-vec00272-001-s469><ask.fragen><en> If you ask locals just nice, it is sometimes down for nothing.
<G-vec00272-001-s469><ask.fragen><de> Wenn man einfach Einheimische nett fragt, wird man auch mal umsonst gefahren.
<G-vec00272-001-s470><ask.fragen><en> This is necessary so that our site would ask for your permission next time you turn your camera on.
<G-vec00272-001-s470><ask.fragen><de> Dies ist erforderlich, damit unsere Website beim nächsten Einschalten der Kamera Sie um Ihre Erlaubnis fragt.
<G-vec00272-001-s471><ask.fragen><en> After the malware downloads, the device will ask a user to install the application.
<G-vec00272-001-s471><ask.fragen><de> Nach den Malware-Downloads, Das Gerät fragt ein Benutzer die Anwendung installieren.
<G-vec00272-001-s472><ask.fragen><en> CNA-Fita has found that politics ask time, but the enterprises do not have to us.
<G-vec00272-001-s472><ask.fragen><de> CNA-Fita hat erhoben, dass die Politik die Zeit fragt, aber haben die Betriebe nicht uns das.
<G-vec00272-001-s473><ask.fragen><en> Ask your greengrocer if he can get them at the wholesale market.
<G-vec00272-001-s473><ask.fragen><de> Fragt euren Gemüsehändler, ob er sie auf dem Großmarkt besorgen kann.
<G-vec00272-001-s474><ask.fragen><en> DALnet will not send you mail and ask for passwords.
<G-vec00272-001-s474><ask.fragen><de> DALnet schreibt auch keine Mails und fragt darin nach Passwörtern.
<G-vec00384-001-s456><ask.fragen><en> Ask yourself now...
<G-vec00384-001-s456><ask.fragen><de> Fragt euch das jetzt selbst...
<G-vec00384-001-s457><ask.fragen><en> I would like you to think about that – and it does help if you can ask for some help from The Source, from God The Source of All – to take away any confusion or friction that maybe around and so that will make that easier for you to flow in the day of your life.
<G-vec00384-001-s457><ask.fragen><de> Ich moechte gerne das Ihr darueber nachdenkt – und es hilft sehr wenn Ihr um Hilfe fragt von Der Kreatur des Allen, vom Gott Dem Ursprung des Allen – etwaige Verwirrung oder Friktion die herum sind wegzunehmen und dadurch wird es für Euch leichter sein durch den Tag zu kommen.
<G-vec00384-001-s458><ask.fragen><en> Yet ask him which of the awards has been the most valuable to him, then you will certainly get the reply, “Awards for my cuisine are indeed a certain extent extra.
<G-vec00384-001-s458><ask.fragen><de> Fragt man ihn aber, welche der Auszeichnungen für ihn am wertvollsten war, dann bekommt man die zu seiner Person passende Antwort: „Die Auszeichnungen meiner Kochkunst sind gewissermaßen das Salz in der Suppe.
<G-vec00384-001-s459><ask.fragen><en> If you ask there, it should usually be no problem for you to use the toilet without eating in the restaurant.
<G-vec00384-001-s459><ask.fragen><de> Fragt man dort nach, sollte es meist kein Problem sein, deren Toilette auch ohne einen Verzehr benutzen zu dürfen.
<G-vec00384-001-s460><ask.fragen><en> "I f they ask you, ""What is the sign of your Father in you?"" say to them, “it is movement and repose.”"
<G-vec00384-001-s460><ask.fragen><de> W enn man euch fragt: «Was ist das Zeichen eures Vaters in euch?», sagt zu ihnen: «Bewegung ist es und Ruhe».
<G-vec00384-001-s461><ask.fragen><en> "These ulterior resources and the strengthening of the patrimonial state - it has specified - will allow us to satisfy the increasing ask of the customers widening our fleet with new ships and estimating opportunity of strategic acquisitions times to the increase""."
<G-vec00384-001-s461><ask.fragen><de> "Diese zusätzlichen Ressourcen und die Stärkung von dem Kontostand werden zulassen uns fragt von der Kundschaft unsere Flotte mit neuen Schiffen das Wachstum erweitert und bewertet Gelegenheit von den strategischen wendet Erwerben"", den Wachsend zu befriedigen,- hat es spezifiziert -."
<G-vec00384-001-s462><ask.fragen><en> "I know ladies, if you ask them they said, ""I observe Monday, I observe Tuesday; I observe Wednesday, I observe Thursday; I observe Friday as a fast, and perhaps maybe, if I do not starve on Saturday I will eat on Sunday."""
<G-vec00384-001-s462><ask.fragen><de> "Ich kenne Frauen, wenn man sie fragt, sagen sie: ""Ich faste Montag, ich faste Dienstag, ich faste Mittwoch, ich faste Donnerstag, ich faste Freitag, und wenn ich am Samstag nicht verhungert bin, werde ich am Sonntag essen""."
<G-vec00384-001-s463><ask.fragen><en> If this is not set for a three-way diff, then TortoiseMerge will ask the user where to save the result.
<G-vec00384-001-s463><ask.fragen><de> Wenn dieser Parameter für einen Dreiwegevergleich nicht angegeben wurde, fragt TortoiseSVN den Anwender, wo die Ergebnisse gespeichert werden sollen.
<G-vec00384-001-s464><ask.fragen><en> For example, someone may ask an astrologer whether to invest in one venture or the other.
<G-vec00384-001-s464><ask.fragen><de> Als Beispiel: Eine Person fragt einen Astrologen, ob er in das eine Unternehmen oder besser in das andere investieren sollte.
<G-vec00384-001-s465><ask.fragen><en> We are able to give information for certain things in the area if you pop in the office (or ask the porters).
<G-vec00384-001-s465><ask.fragen><de> Wir können jeden mit Informationen über die Umgebung bedienen, wenn man in unserem Büro vorbeischaut (oder die Pförtner fragt).
<G-vec00384-001-s466><ask.fragen><en> Ask members of DREAM THEATER or QUEENSRYCHE about their biggest musical influences, the first name that will be mentioned in an almost reverent way will be the one of Jim Matheos' band.
<G-vec00384-001-s466><ask.fragen><de> Fragt man Musiker von Bands wie DREAM THEATER oder QUEENSRYCHE nach ihren größten musikalischen Einflüssen, wird der Name der Truppe um Jim Matheos fast ehrfürchtig als allererstes erwähnt.
<G-vec00384-001-s467><ask.fragen><en> "If you want a coffee, you ask for an ""americano."""
<G-vec00384-001-s467><ask.fragen><de> "Wer einen Kaffee will, fragt nach einem ""americano""."
<G-vec00384-001-s468><ask.fragen><en> They probably don´t ask anyone at all (aside from the merchants that is).
<G-vec00384-001-s468><ask.fragen><de> Wahrscheinlich fragt man auch sonst niemanden (außer die Fotohändler).
<G-vec00384-001-s469><ask.fragen><en> If you ask locals just nice, it is sometimes down for nothing.
<G-vec00384-001-s469><ask.fragen><de> Wenn man einfach Einheimische nett fragt, wird man auch mal umsonst gefahren.
<G-vec00384-001-s470><ask.fragen><en> This is necessary so that our site would ask for your permission next time you turn your camera on.
<G-vec00384-001-s470><ask.fragen><de> Dies ist erforderlich, damit unsere Website beim nächsten Einschalten der Kamera Sie um Ihre Erlaubnis fragt.
<G-vec00384-001-s471><ask.fragen><en> After the malware downloads, the device will ask a user to install the application.
<G-vec00384-001-s471><ask.fragen><de> Nach den Malware-Downloads, Das Gerät fragt ein Benutzer die Anwendung installieren.
<G-vec00384-001-s472><ask.fragen><en> CNA-Fita has found that politics ask time, but the enterprises do not have to us.
<G-vec00384-001-s472><ask.fragen><de> CNA-Fita hat erhoben, dass die Politik die Zeit fragt, aber haben die Betriebe nicht uns das.
<G-vec00384-001-s473><ask.fragen><en> Ask your greengrocer if he can get them at the wholesale market.
<G-vec00384-001-s473><ask.fragen><de> Fragt euren Gemüsehändler, ob er sie auf dem Großmarkt besorgen kann.
<G-vec00384-001-s474><ask.fragen><en> DALnet will not send you mail and ask for passwords.
<G-vec00384-001-s474><ask.fragen><de> DALnet schreibt auch keine Mails und fragt darin nach Passwörtern.
<G-vec00272-001-s475><ask.fragen><en> "Just as if the Word of God do not ever warned admonishing: ""To whom much is given, much will be required; to whom men have committed much, It will ask the more "" [LC 12, 48]."
<G-vec00272-001-s475><ask.fragen><de> "Gerade als ob das Wort Gott noch immer nicht gewarnt mahnende: ""Zu wem viel gegeben, viel wird benötigt; wem haben die Menschen begangen viel, Sie werden gefragt, die mehr "" [LC 12, 48]."
<G-vec00272-001-s476><ask.fragen><en> "Readers often ask me, ""How can one tell the difference between positive and negative synchronicities?"""
<G-vec00272-001-s476><ask.fragen><de> Ich werde oft von Lesern gefragt, woran sie den Unterschied zwischen Synchronizitäten positiver und negativer Natur erkennen können.
<G-vec00272-001-s477><ask.fragen><en> This year the speakers at the roadshow days are Justin and Mary Marantz and Philip Landerer called me to ask if I would be interested in translating for the German speaking guests of the workshop attendees.
<G-vec00272-001-s477><ask.fragen><de> Dieses Jahr sind die Sprecher während der Roadshow Justin und Mary Marrantz und Philip Landerer hat mich gefragt, ob ich Interesse hätte, für die deutschsprachigen Teilnehmer des Workshops zu übersetzten.
<G-vec00272-001-s478><ask.fragen><en> We ́ll ask you to give us your contact details and then you can confirm the booking by making a secure payment online.
<G-vec00272-001-s478><ask.fragen><de> Jetzt werden Sie nach Ihren Kontaktdaten gefragt (Schuhgröße optional) und dann können Sie die Buchung bestätigen, in dem Sie einfach ganz sicher online bezahlen.
<G-vec00272-001-s479><ask.fragen><en> Here you can ask for advice when needed.
<G-vec00272-001-s479><ask.fragen><de> Hier kann bei Bedarf um Rat gefragt werden.
<G-vec00272-001-s480><ask.fragen><en> YES, no doubt, I did not ask.
<G-vec00272-001-s480><ask.fragen><de> Naja, habe wohl auch nicht gefragt.
<G-vec00272-001-s481><ask.fragen><en> Actually, I hate it when I go to these gallery weekends and people ask me if I´m an artist or a collector. I´m neither of the two.
<G-vec00272-001-s481><ask.fragen><de> Ich hasse es eigentlich, wenn man auf Gallery-Weekends gefragt wird, ‚Sind Sie Künstler oder Sammler?´ Ich bin nichts von beidem.
<G-vec00272-001-s482><ask.fragen><en> Recommended reading: our selection Our customers and seminar participants often ask us for recommendations for books on intercultural communication.
<G-vec00272-001-s482><ask.fragen><de> Unsere Leseempfehlungen Von unseren Kunden und Seminarteilnehmern werden wir oft gefragt, welche Bücher zum Thema interkulturelle Kommunikation wir empfehlen können.
<G-vec00272-001-s483><ask.fragen><en> Marianna Binder from the Recruiting team called me a short time later to ask whether I would consider taking on a role in the Investor Relations team – a different position to the one I applied for, and one that had not even been advertised at that point.
<G-vec00272-001-s483><ask.fragen><de> Marianna Binder aus dem Recruiting-Team hat mich kurze Zeit später angerufen und gefragt, ob ich unter Umständen auch an einer Tätigkeit im Investor-Relations-Team interessiert wäre – einer Stelle, die zum damaligen Zeitpunkt gar nicht mehr ausgeschrieben war.
<G-vec00272-001-s484><ask.fragen><en> We ask five Finnish journalists who have extensive experience working abroad.
<G-vec00272-001-s484><ask.fragen><de> Wir haben fünf finnische Journalisten gefragt, die über umfassende Arbeitserfahrung im Ausland verfügen.
<G-vec00272-001-s485><ask.fragen><en> Many visitors ask us this question.
<G-vec00272-001-s485><ask.fragen><de> werden wir immer wieder von vielen unserer Besucher gefragt.
<G-vec00272-001-s486><ask.fragen><en> In light of the fact that there is the chance of realizing this project at the end of an era of new museum buildings which dominated the international architectural discussions of the previous fifteen years, it is the intention to ask for the conditions which might help establish a constructive relationship between art and architecture before the execution of tangible architectural plans.
<G-vec00272-001-s486><ask.fragen><de> In Anbetracht der Chance zur Realisierung dieses Vorhabens am Ende einer Ära von Museumsneubauten, welche die internationale Architekturdiskussion der vergangenen fünfzehn Jahre beherrscht hat, soll vor der Verwirklichung konkreter architektonischer Entwürfe nach den Bedingungen für ein konstruktives Verhältnis von Kunst und Architektur gefragt werden, das die gewünschte Auseinandersetzung mit Ort und Werk beflügeln könnte.
<G-vec00272-001-s487><ask.fragen><en> Others will ask you if you want them to steam the milk in order to make a lot or a little amount of foam in the drink.
<G-vec00272-001-s487><ask.fragen><de> Andere werden Sie gefragt, ob Sie die Milch Dampf um einiges oder eine kleine Menge von Schaum in das Getränk zu machen sollen.
<G-vec00272-001-s488><ask.fragen><en> It will ask where to save the file XML that will process.
<G-vec00272-001-s488><ask.fragen><de> Es wird gefragt, wo die Datei gespeichert werden XML dieser Wille Prozess.
<G-vec00272-001-s489><ask.fragen><en> We availed not only of the bed and breakfast formula, but also of dinner (every day we ask for confirmation if you want to dine on site): their cuisine is homemade, simple but tasty, thanks to the high quality and freshness of the ingredients Used, almost all of their production; Also their wines are excellent; To note the readiness to prepare vegetarian alternatives and generally the attention and attentions reserved for the guests.
<G-vec00272-001-s489><ask.fragen><de> Wir nutzten nicht nur ein Bett und Frühstück, aber das Abendessen (jeden Tag gefragt wird, noch zu bestätigen, ob Sie vor Ort speisen wollen): ihr Essen ist alles selbst gemacht, einfach, aber schmackhaft, dank der hohen Qualität und Frische der Zutaten gebraucht, fast alle ihre Produktion; Auch gut ihre Weine; beachten Sie die gute Verfügbarkeit in vegetarische Alternativen vorbereitet und im Allgemeinen die Weitsicht und die Aufmerksamkeit für die Gäste reserviert.
<G-vec00272-001-s490><ask.fragen><en> If the target drive is a boot disk then the system will ask you if you want to run the command.
<G-vec00272-001-s490><ask.fragen><de> Wenn das Ziellaufwerk eine Startdiskette ist, werden Sie vom System gefragt, ob Sie den Befehl ausführen möchten.
<G-vec00272-001-s491><ask.fragen><en> To be honest, after tonight's short rendevouz with Max, I seriously ask myself how he still can manage to play his show.
<G-vec00272-001-s491><ask.fragen><de> Ehrlich gestanden habe ich mich nach dem kurzen Rendevouz mit Max vor der heutigen Show ernsthaft gefragt, wie dieser überhaupt die Show durchstehen will.
<G-vec00272-001-s492><ask.fragen><en> When you ask me what season I think would be the best to come and visit Lanzarote I'll definitely say to you autumn.
<G-vec00272-001-s492><ask.fragen><de> Wenn ich gefragt werde welche Saison wohl die Beste sei um Lanzarote zu besuchen, dann sage ich ohne zu zögern Herbst.
<G-vec00272-001-s493><ask.fragen><en> I did not ask Conrad if he would be willing to do that or not.
<G-vec00272-001-s493><ask.fragen><de> Ich habe Conrad nicht gefragt, ob er dazu bereit wäre oder nicht.
<G-vec00384-001-s475><ask.fragen><en> "Just as if the Word of God do not ever warned admonishing: ""To whom much is given, much will be required; to whom men have committed much, It will ask the more "" [LC 12, 48]."
<G-vec00384-001-s475><ask.fragen><de> "Gerade als ob das Wort Gott noch immer nicht gewarnt mahnende: ""Zu wem viel gegeben, viel wird benötigt; wem haben die Menschen begangen viel, Sie werden gefragt, die mehr "" [LC 12, 48]."
<G-vec00384-001-s476><ask.fragen><en> "Readers often ask me, ""How can one tell the difference between positive and negative synchronicities?"""
<G-vec00384-001-s476><ask.fragen><de> Ich werde oft von Lesern gefragt, woran sie den Unterschied zwischen Synchronizitäten positiver und negativer Natur erkennen können.
<G-vec00384-001-s477><ask.fragen><en> This year the speakers at the roadshow days are Justin and Mary Marantz and Philip Landerer called me to ask if I would be interested in translating for the German speaking guests of the workshop attendees.
<G-vec00384-001-s477><ask.fragen><de> Dieses Jahr sind die Sprecher während der Roadshow Justin und Mary Marrantz und Philip Landerer hat mich gefragt, ob ich Interesse hätte, für die deutschsprachigen Teilnehmer des Workshops zu übersetzten.
<G-vec00384-001-s478><ask.fragen><en> We ́ll ask you to give us your contact details and then you can confirm the booking by making a secure payment online.
<G-vec00384-001-s478><ask.fragen><de> Jetzt werden Sie nach Ihren Kontaktdaten gefragt (Schuhgröße optional) und dann können Sie die Buchung bestätigen, in dem Sie einfach ganz sicher online bezahlen.
<G-vec00384-001-s479><ask.fragen><en> Here you can ask for advice when needed.
<G-vec00384-001-s479><ask.fragen><de> Hier kann bei Bedarf um Rat gefragt werden.
<G-vec00384-001-s480><ask.fragen><en> YES, no doubt, I did not ask.
<G-vec00384-001-s480><ask.fragen><de> Naja, habe wohl auch nicht gefragt.
<G-vec00384-001-s481><ask.fragen><en> Actually, I hate it when I go to these gallery weekends and people ask me if I´m an artist or a collector. I´m neither of the two.
<G-vec00384-001-s481><ask.fragen><de> Ich hasse es eigentlich, wenn man auf Gallery-Weekends gefragt wird, ‚Sind Sie Künstler oder Sammler?´ Ich bin nichts von beidem.
<G-vec00384-001-s482><ask.fragen><en> Recommended reading: our selection Our customers and seminar participants often ask us for recommendations for books on intercultural communication.
<G-vec00384-001-s482><ask.fragen><de> Unsere Leseempfehlungen Von unseren Kunden und Seminarteilnehmern werden wir oft gefragt, welche Bücher zum Thema interkulturelle Kommunikation wir empfehlen können.
<G-vec00384-001-s483><ask.fragen><en> Marianna Binder from the Recruiting team called me a short time later to ask whether I would consider taking on a role in the Investor Relations team – a different position to the one I applied for, and one that had not even been advertised at that point.
<G-vec00384-001-s483><ask.fragen><de> Marianna Binder aus dem Recruiting-Team hat mich kurze Zeit später angerufen und gefragt, ob ich unter Umständen auch an einer Tätigkeit im Investor-Relations-Team interessiert wäre – einer Stelle, die zum damaligen Zeitpunkt gar nicht mehr ausgeschrieben war.
<G-vec00384-001-s484><ask.fragen><en> We ask five Finnish journalists who have extensive experience working abroad.
<G-vec00384-001-s484><ask.fragen><de> Wir haben fünf finnische Journalisten gefragt, die über umfassende Arbeitserfahrung im Ausland verfügen.
<G-vec00384-001-s485><ask.fragen><en> Many visitors ask us this question.
<G-vec00384-001-s485><ask.fragen><de> werden wir immer wieder von vielen unserer Besucher gefragt.
<G-vec00384-001-s486><ask.fragen><en> In light of the fact that there is the chance of realizing this project at the end of an era of new museum buildings which dominated the international architectural discussions of the previous fifteen years, it is the intention to ask for the conditions which might help establish a constructive relationship between art and architecture before the execution of tangible architectural plans.
<G-vec00384-001-s486><ask.fragen><de> In Anbetracht der Chance zur Realisierung dieses Vorhabens am Ende einer Ära von Museumsneubauten, welche die internationale Architekturdiskussion der vergangenen fünfzehn Jahre beherrscht hat, soll vor der Verwirklichung konkreter architektonischer Entwürfe nach den Bedingungen für ein konstruktives Verhältnis von Kunst und Architektur gefragt werden, das die gewünschte Auseinandersetzung mit Ort und Werk beflügeln könnte.
<G-vec00384-001-s487><ask.fragen><en> Others will ask you if you want them to steam the milk in order to make a lot or a little amount of foam in the drink.
<G-vec00384-001-s487><ask.fragen><de> Andere werden Sie gefragt, ob Sie die Milch Dampf um einiges oder eine kleine Menge von Schaum in das Getränk zu machen sollen.
<G-vec00384-001-s488><ask.fragen><en> It will ask where to save the file XML that will process.
<G-vec00384-001-s488><ask.fragen><de> Es wird gefragt, wo die Datei gespeichert werden XML dieser Wille Prozess.
<G-vec00384-001-s489><ask.fragen><en> We availed not only of the bed and breakfast formula, but also of dinner (every day we ask for confirmation if you want to dine on site): their cuisine is homemade, simple but tasty, thanks to the high quality and freshness of the ingredients Used, almost all of their production; Also their wines are excellent; To note the readiness to prepare vegetarian alternatives and generally the attention and attentions reserved for the guests.
<G-vec00384-001-s489><ask.fragen><de> Wir nutzten nicht nur ein Bett und Frühstück, aber das Abendessen (jeden Tag gefragt wird, noch zu bestätigen, ob Sie vor Ort speisen wollen): ihr Essen ist alles selbst gemacht, einfach, aber schmackhaft, dank der hohen Qualität und Frische der Zutaten gebraucht, fast alle ihre Produktion; Auch gut ihre Weine; beachten Sie die gute Verfügbarkeit in vegetarische Alternativen vorbereitet und im Allgemeinen die Weitsicht und die Aufmerksamkeit für die Gäste reserviert.
<G-vec00384-001-s490><ask.fragen><en> If the target drive is a boot disk then the system will ask you if you want to run the command.
<G-vec00384-001-s490><ask.fragen><de> Wenn das Ziellaufwerk eine Startdiskette ist, werden Sie vom System gefragt, ob Sie den Befehl ausführen möchten.
<G-vec00384-001-s491><ask.fragen><en> To be honest, after tonight's short rendevouz with Max, I seriously ask myself how he still can manage to play his show.
<G-vec00384-001-s491><ask.fragen><de> Ehrlich gestanden habe ich mich nach dem kurzen Rendevouz mit Max vor der heutigen Show ernsthaft gefragt, wie dieser überhaupt die Show durchstehen will.
<G-vec00384-001-s492><ask.fragen><en> When you ask me what season I think would be the best to come and visit Lanzarote I'll definitely say to you autumn.
<G-vec00384-001-s492><ask.fragen><de> Wenn ich gefragt werde welche Saison wohl die Beste sei um Lanzarote zu besuchen, dann sage ich ohne zu zögern Herbst.
<G-vec00384-001-s493><ask.fragen><en> I did not ask Conrad if he would be willing to do that or not.
<G-vec00384-001-s493><ask.fragen><de> Ich habe Conrad nicht gefragt, ob er dazu bereit wäre oder nicht.
<G-vec00272-001-s513><ask.nachfragen><en> International warranties are not standardised, and you should always ask and verify that your warranty is valid in your home country.
<G-vec00272-001-s513><ask.nachfragen><de> Internationale Garantien sind nicht standardisiert und Sie sollten stets nachfragen und sicherstellen, dass Ihre Garantie in Ihrem Heimatland gültig ist.
<G-vec00272-001-s514><ask.nachfragen><en> If unclear, please ask..
<G-vec00272-001-s514><ask.nachfragen><de> Falls unklar, bitte nachfragen.
<G-vec00272-001-s515><ask.nachfragen><en> Explain to your children why he is wearing eyewear so that he can also explain to his friends, should they ask.
<G-vec00272-001-s515><ask.nachfragen><de> Erklären Sie Ihrem Kind, warum es eine Brille trägt, damit es auch bei seinen Freunden argumentieren kann, wenn diese nachfragen.
<G-vec00272-001-s516><ask.nachfragen><en> As usual, you can also ask in the mailing list.
<G-vec00272-001-s516><ask.nachfragen><de> Wie gewohnt kannst Du auch in der Mailingliste nachfragen.
<G-vec00272-001-s517><ask.nachfragen><en> Please ask for LED light!
<G-vec00272-001-s517><ask.nachfragen><de> Für LED-Beleuchtung bitte nachfragen.
<G-vec00272-001-s518><ask.nachfragen><en> It is planned to build there therefore ask beforehand if the place is open.
<G-vec00272-001-s518><ask.nachfragen><de> Es ist geplant dort zu bauen daher vorher nachfragen ob der Platz geöffnet ist.
<G-vec00272-001-s519><ask.nachfragen><en> If you do not think that you are capable of doing that, you could also ask at an alteration shop before discarding it.
<G-vec00272-001-s519><ask.nachfragen><de> Falls Sie sich das nicht zutrauen, können Sie auch in einer Änderungsschneiderei nachfragen, bevor Sie ein Teil entsorgen.
<G-vec00272-001-s520><ask.nachfragen><en> If your boss tells you how to do something, listen and remember so you won't have to ask again.
<G-vec00272-001-s520><ask.nachfragen><de> Wenn dein Chef dir erklärt, wie du etwas zu machen hast, höre zu und verinnerliche das Gesagte, damit du kein zweites Mal nachfragen musst.
<G-vec00272-001-s521><ask.nachfragen><en> Under Downloads, either choose another location or Always ask me where to save files .
<G-vec00272-001-s521><ask.nachfragen><de> Wählen Sie unter Downloads entweder einen anderen Speicherort aus oder aktivieren Sie die Option Jedes Mal nachfragen, wo eine Datei gespeichert werden soll .
<G-vec00272-001-s522><ask.nachfragen><en> NEW: File Conflict Dialog: The option 'If there are other conflicts, don't ask any more and always perform last action' has been added.
<G-vec00272-001-s522><ask.nachfragen><de> "NEU: Dateikonflikt-Dialog: Option ""Bei weiteren Konflikten nicht mehr nachfragen und immer die letzte Aktion durchführen"" hinzugefügt."
<G-vec00272-001-s523><ask.nachfragen><en> Looking more closely, you sometimes have to ask whether just the names have been switched, but for many people, doors have opened to make other work possible. Today it can be seen that the humanities comprise more than just spirit.
<G-vec00272-001-s523><ask.nachfragen><de> Im Detail muss man da sicher manchmal nachfragen, ob nur Namen ausgetauscht wurden, aber für viele Leute sind Türen geöffnet worden, sodass andere Arbeiten möglich geworden sind und heute eingesehen wird, dass der Geist nicht nur aus Geist besteht.
<G-vec00272-001-s524><ask.nachfragen><en> Select Always submit not to be prompted before submitting your ESET Mail Security configuration data to customer care, or use Ask before submission .
<G-vec00272-001-s524><ask.nachfragen><de> Wählen Sie Immer senden aus, um vor dem Senden Ihrer ESET File Security-Konfigurationsdaten nicht gefragt zu werden, oder verwenden Sie die Option Vor dem Senden nachfragen .
<G-vec00272-001-s525><ask.nachfragen><en> If you are interested just ask for more details.
<G-vec00272-001-s525><ask.nachfragen><de> Bei Interesse einfach nach mehr Details nachfragen.
<G-vec00272-001-s526><ask.nachfragen><en> Usually on Tuesdays. Just ask reception.
<G-vec00272-001-s526><ask.nachfragen><de> Einfach an der Rezeption nachfragen.
<G-vec00272-001-s527><ask.nachfragen><en> However, just occasionally, an error can occur. If we discover an error in the price or description of a product you have ordered, we will tell you and ask you whether you wish to continue with your order or cancel it.
<G-vec00272-001-s527><ask.nachfragen><de> Wenn wir einen Fehler im Preis oder der Beschreibung eines Produktes entdecken, das Sie bestellt haben, werden wir Ihnen diesen mitteilen und nachfragen, ob Sie mit Ihrer Bestellung fortfahren oder sie stornieren möchten.
<G-vec00272-001-s528><ask.nachfragen><en> It's a lot of work which can be quite demanding (for example when you spend evenings during a vacation translating song lyrics, or when you have to ask again and again to get information), but first and foremost, the job is fun.
<G-vec00272-001-s528><ask.nachfragen><de> Es ist viel Arbeit, die oft einiges abverlangt (wenn man zum Beispiel Urlaubsabende damit zubringt, Liedtexte zu übersetzen, oder wenn man immer wieder und wieder nachfragen muss, um Informationen zu bekommen), aber vor allem macht der Job Spaß.
<G-vec00272-001-s529><ask.nachfragen><en> Finally, if ever you're suspicious of something the dealer does, don't hesitate to ask why, as objectively and calmly as possible.
<G-vec00272-001-s529><ask.nachfragen><de> Zu guter Letzt sollten Sie so sachlich und ruhig wie möglich nachfragen, falls Ihnen etwas Verdächtiges auf Seiten des Dealers auffällt.
<G-vec00272-001-s530><ask.nachfragen><en> In accordance with applicable law, you can ask us in writing at any time whether and what personal data about you is stored by us.
<G-vec00272-001-s530><ask.nachfragen><de> Gemäß geltendem Recht können Sie jederzeit bei uns schriftlich nachfragen, ob und welche personenbezogenen Daten bei uns über Sie gespeichert sind.
<G-vec00272-001-s531><ask.nachfragen><en> You can auto-save these settings for future reference by clicking on the option “Set my choices as default and don’t ask again,” and next time, iTube will detect settings on its own.
<G-vec00272-001-s531><ask.nachfragen><de> Sie können diese Einstellungen für zukünftige Referenz automatisch speichern auf die Option, indem Sie auf “Richten meine Auswahl als Standard und nicht mehr nachfragen,” und das nächste Mal, iTube werden die Einstellungen auf ihre eigene erkennen.
<G-vec00384-001-s513><ask.nachfragen><en> International warranties are not standardised, and you should always ask and verify that your warranty is valid in your home country.
<G-vec00384-001-s513><ask.nachfragen><de> Internationale Garantien sind nicht standardisiert und Sie sollten stets nachfragen und sicherstellen, dass Ihre Garantie in Ihrem Heimatland gültig ist.
<G-vec00384-001-s514><ask.nachfragen><en> If unclear, please ask..
<G-vec00384-001-s514><ask.nachfragen><de> Falls unklar, bitte nachfragen.
<G-vec00384-001-s515><ask.nachfragen><en> Explain to your children why he is wearing eyewear so that he can also explain to his friends, should they ask.
<G-vec00384-001-s515><ask.nachfragen><de> Erklären Sie Ihrem Kind, warum es eine Brille trägt, damit es auch bei seinen Freunden argumentieren kann, wenn diese nachfragen.
<G-vec00384-001-s516><ask.nachfragen><en> As usual, you can also ask in the mailing list.
<G-vec00384-001-s516><ask.nachfragen><de> Wie gewohnt kannst Du auch in der Mailingliste nachfragen.
<G-vec00384-001-s517><ask.nachfragen><en> Please ask for LED light!
<G-vec00384-001-s517><ask.nachfragen><de> Für LED-Beleuchtung bitte nachfragen.
<G-vec00384-001-s518><ask.nachfragen><en> It is planned to build there therefore ask beforehand if the place is open.
<G-vec00384-001-s518><ask.nachfragen><de> Es ist geplant dort zu bauen daher vorher nachfragen ob der Platz geöffnet ist.
<G-vec00384-001-s519><ask.nachfragen><en> If you do not think that you are capable of doing that, you could also ask at an alteration shop before discarding it.
<G-vec00384-001-s519><ask.nachfragen><de> Falls Sie sich das nicht zutrauen, können Sie auch in einer Änderungsschneiderei nachfragen, bevor Sie ein Teil entsorgen.
<G-vec00384-001-s520><ask.nachfragen><en> If your boss tells you how to do something, listen and remember so you won't have to ask again.
<G-vec00384-001-s520><ask.nachfragen><de> Wenn dein Chef dir erklärt, wie du etwas zu machen hast, höre zu und verinnerliche das Gesagte, damit du kein zweites Mal nachfragen musst.
<G-vec00384-001-s521><ask.nachfragen><en> Under Downloads, either choose another location or Always ask me where to save files .
<G-vec00384-001-s521><ask.nachfragen><de> Wählen Sie unter Downloads entweder einen anderen Speicherort aus oder aktivieren Sie die Option Jedes Mal nachfragen, wo eine Datei gespeichert werden soll .
<G-vec00384-001-s522><ask.nachfragen><en> NEW: File Conflict Dialog: The option 'If there are other conflicts, don't ask any more and always perform last action' has been added.
<G-vec00384-001-s522><ask.nachfragen><de> "NEU: Dateikonflikt-Dialog: Option ""Bei weiteren Konflikten nicht mehr nachfragen und immer die letzte Aktion durchführen"" hinzugefügt."
<G-vec00384-001-s523><ask.nachfragen><en> Looking more closely, you sometimes have to ask whether just the names have been switched, but for many people, doors have opened to make other work possible. Today it can be seen that the humanities comprise more than just spirit.
<G-vec00384-001-s523><ask.nachfragen><de> Im Detail muss man da sicher manchmal nachfragen, ob nur Namen ausgetauscht wurden, aber für viele Leute sind Türen geöffnet worden, sodass andere Arbeiten möglich geworden sind und heute eingesehen wird, dass der Geist nicht nur aus Geist besteht.
<G-vec00384-001-s524><ask.nachfragen><en> Select Always submit not to be prompted before submitting your ESET Mail Security configuration data to customer care, or use Ask before submission .
<G-vec00384-001-s524><ask.nachfragen><de> Wählen Sie Immer senden aus, um vor dem Senden Ihrer ESET File Security-Konfigurationsdaten nicht gefragt zu werden, oder verwenden Sie die Option Vor dem Senden nachfragen .
<G-vec00384-001-s525><ask.nachfragen><en> If you are interested just ask for more details.
<G-vec00384-001-s525><ask.nachfragen><de> Bei Interesse einfach nach mehr Details nachfragen.
<G-vec00384-001-s526><ask.nachfragen><en> Usually on Tuesdays. Just ask reception.
<G-vec00384-001-s526><ask.nachfragen><de> Einfach an der Rezeption nachfragen.
<G-vec00384-001-s527><ask.nachfragen><en> However, just occasionally, an error can occur. If we discover an error in the price or description of a product you have ordered, we will tell you and ask you whether you wish to continue with your order or cancel it.
<G-vec00384-001-s527><ask.nachfragen><de> Wenn wir einen Fehler im Preis oder der Beschreibung eines Produktes entdecken, das Sie bestellt haben, werden wir Ihnen diesen mitteilen und nachfragen, ob Sie mit Ihrer Bestellung fortfahren oder sie stornieren möchten.
<G-vec00384-001-s528><ask.nachfragen><en> It's a lot of work which can be quite demanding (for example when you spend evenings during a vacation translating song lyrics, or when you have to ask again and again to get information), but first and foremost, the job is fun.
<G-vec00384-001-s528><ask.nachfragen><de> Es ist viel Arbeit, die oft einiges abverlangt (wenn man zum Beispiel Urlaubsabende damit zubringt, Liedtexte zu übersetzen, oder wenn man immer wieder und wieder nachfragen muss, um Informationen zu bekommen), aber vor allem macht der Job Spaß.
<G-vec00384-001-s529><ask.nachfragen><en> Finally, if ever you're suspicious of something the dealer does, don't hesitate to ask why, as objectively and calmly as possible.
<G-vec00384-001-s529><ask.nachfragen><de> Zu guter Letzt sollten Sie so sachlich und ruhig wie möglich nachfragen, falls Ihnen etwas Verdächtiges auf Seiten des Dealers auffällt.
<G-vec00384-001-s530><ask.nachfragen><en> In accordance with applicable law, you can ask us in writing at any time whether and what personal data about you is stored by us.
<G-vec00384-001-s530><ask.nachfragen><de> Gemäß geltendem Recht können Sie jederzeit bei uns schriftlich nachfragen, ob und welche personenbezogenen Daten bei uns über Sie gespeichert sind.
<G-vec00384-001-s531><ask.nachfragen><en> You can auto-save these settings for future reference by clicking on the option “Set my choices as default and don’t ask again,” and next time, iTube will detect settings on its own.
<G-vec00384-001-s531><ask.nachfragen><de> Sie können diese Einstellungen für zukünftige Referenz automatisch speichern auf die Option, indem Sie auf “Richten meine Auswahl als Standard und nicht mehr nachfragen,” und das nächste Mal, iTube werden die Einstellungen auf ihre eigene erkennen.
<G-vec00272-001-s551><ask.fragen><en> And Adam was astonished at this answer and did not dare to ask the stranger anything else.
<G-vec00272-001-s551><ask.fragen><de> Und der Adam verwunderte sich überhoch über diese Antwort bei sich und getraute sich den Fremden nicht mehr zu fragen um irgend etwas.
<G-vec00272-001-s552><ask.fragen><en> But we must access it on deeper levels and ask ourselves whether we should follow a trend or just ignore it.
<G-vec00272-001-s552><ask.fragen><de> Aber man muss eine Ebene tiefer ansetzen und sich fragen, ob man auf einen Trend aufspringen sollte oder nicht.
<G-vec00272-001-s553><ask.fragen><en> How could this be, you might ask, if the cards are dealt randomly?
<G-vec00272-001-s553><ask.fragen><de> Sie werden sich fragen, wie das sein kann, wenn die Karten zufällig verteilt werden.
<G-vec00272-001-s554><ask.fragen><en> You can ask for details of the removal company insurances but be careful with the limited responsibilities.
<G-vec00272-001-s554><ask.fragen><de> Sie können sich für Details der Umzugsfirma Versicherungen fragen, aber sein vorsichtig mit der begrenzten Zuständigkeiten.
<G-vec00272-001-s555><ask.fragen><en> SC: To protect ourselves from evil, then, it seems that each of us must ask ourselves if we are in the presence of one of these twisted people who lie and are only out for their personal interest.
<G-vec00272-001-s555><ask.fragen><de> Silvia Cattori: Um uns vom Bösen zu schützen erscheint es also, dass jeder von uns sich fragen muss, ob man sich in der Präsenz von einem dieser verdrehten Personen befindet, die lügen und nur auf ihre eigenen Interessen aus sind.
<G-vec00272-001-s556><ask.fragen><en> But is is right for you?The first question you'll need to ask yourself is how often you'll use your wireless phone?Since the biggest benefit of a prepaid wireless phone is there is no monthly contract, you'll pay a little more for the prepaid minutes y...
<G-vec00272-001-s556><ask.fragen><de> Aber ist ist Recht für Sie?Die erste Frage, die Sie sich fragen müssen, daß ist, wie häufig Sie Ihr drahtloses Telefon benutzen?Da der größte Nutzen eines frankierten drahtlosen Telefons ist, gibt es keinen Monatsvertrag, Si...
<G-vec00272-001-s557><ask.fragen><en> Increasingly, CEOs must ask where the best new ideas are emerging.
<G-vec00272-001-s557><ask.fragen><de> CEOs müssten sich immer mehr fragen, wo die besten neuen Ideen entstehen.
<G-vec00272-001-s558><ask.fragen><en> One could ask, what sense does it make to admit a terminal patient to the Hospice, who is in the final stages of AIDS and do little more than pain control and waiting for his death.
<G-vec00272-001-s558><ask.fragen><de> Man mag sich fragen, was hat es überhaupt für einen Sinn, wenn ein Patient hier eingeliefert wird mit AIDS im Endstadium, dass man hier mehr tut als nur die Schmerzen zu nehmen und darauf warten, dass er stirbt.
<G-vec00272-001-s559><ask.fragen><en> The Board member thought it would be helpful to step back and ask whether it was needed or whether the remaining information might be better included in other documents.
<G-vec00272-001-s559><ask.fragen><de> Das Boardmitglied hielt es für hilfreich, einen Schritt zurückzutreten und sich zu fragen, ob es benötigt wird oder ob die restlichen Informationen besser in andere Dokumente aufgenommen werden können.
<G-vec00272-001-s560><ask.fragen><en> We could ask ourselves how long this easily-accessible energy is going to last our civilized neighbors, I don't mean the people, I mean that very civilized government —and do forgive me for mentioning a government in particular, I don't want to mention any because I don't want to offend anyone— but that policy, or whatever you wish to call it, that is so civilized and humanitarian, opposed to the Kyoto Protocol, a simple and modest attempt to contain atmospheric contamination, that policy deserves our repudiation.
<G-vec00272-001-s560><ask.fragen><de> Und ich erwähne hier nur ein einziges Problem, das der Energie, und man könnte sich fragen, wie lange diese bequeme Energie, von der unsere zivilisierten Nachbarn, – ich beziehe mich nicht auf das Volk – jene so zivilisierte Regierung – und verzeiht, dass ich eine Regierung genannt habe, ich will keine nennen, da ich niemanden verletzen möchte, nun gut, wie ihr es nennen möchtet – diese so zivilisierte und humanitäre Politik führt, die sich dem Kyoto-Protokoll widersetzt, einem einfachen und begrenzten Versuch, die Luftverunreinigung aufzuhalten.
<G-vec00272-001-s561><ask.fragen><en> In your enterprise the point is perhaps already reached, in which you ask yourselves, with which products and which services you earn money and where you see losing business.
<G-vec00272-001-s561><ask.fragen><de> In Ihrem Unternehmen ist vielleicht schon der Punkt erreicht, in dem Sie sich fragen, mit welchen Produkten und welchen Dienstleistungen Sie „Geld verdienen“ und wo die „Verlustbringer“ stecken.
<G-vec00272-001-s562><ask.fragen><en> You may ask why we are adamant about classical homoeopathy, when there are other ‘methods’ that are successfully treating AIDS in Africa.
<G-vec00272-001-s562><ask.fragen><de> Man könnte sich fragen, warum wir auf die klassische Homöopathie bestehen, wenn es auch andere „Methoden“ gibt, mit denen AIDS in Afrika erfolgreich behandelt werden kann.
<G-vec00272-001-s563><ask.fragen><en> Even so, I understand why my fellow Germans ask why they have to shoulder the costs of the rescue package.
<G-vec00272-001-s563><ask.fragen><de> Ich kann aber auch meine deutschen Mitbürger verstehen, die sich fragen, warum sie die Rettungsschirme schultern und als Mitgaranten der EZB für italienische und griechische Staatsschulden bürgen sollen.
<G-vec00272-001-s564><ask.fragen><en> If migration and its concomitant notions of space generate non-linearity as a form of thinking and acting, because one lives in between heterogeneous worlds and cultures, between the here and the there, then we must ask which space of movement and which kind of movement are the basis for the production of news. Is there a reversibility between non-linear forms and the notion of space?
<G-vec00272-001-s564><ask.fragen><de> Wenn Migration und die damit verbundenen Raumvorstellungen Nicht-Linearität als Denk- und Handlungsform generieren, weil man zwischen heterogenen Welten und Kulturen, zwischen dem Hier und Dort lebt, muss man sich fragen, welchen Bewegungsraum und welche Art der Bewegung der Produktion von Nachrichten wirklich zu Grunde liegt.
<G-vec00272-001-s565><ask.fragen><en> Gallanti however has specified that the contracts that had to be stipulated in the period spring/summer - the period of the cruises - are seasonal and they do not resolve the problems for how many they ask greater stability.
<G-vec00272-001-s565><ask.fragen><de> Gallanti hat jedoch präzisiert, dass die Verträge, die/Sommer mussten Frühling abschließt in der Periode sein,- die Periode von den Kreuzfahrten -, und die Probleme meist Stabilität saisonal sie nicht lösen sich fragen von wie viel sind.
<G-vec00272-001-s566><ask.fragen><en> One might ask why Jesus had to die in the first place.
<G-vec00272-001-s566><ask.fragen><de> Man könnte sich fragen, warum Jesus überhaupt geopfert werden musste.
<G-vec00272-001-s567><ask.fragen><en> Besides you should ask which impact for your requirements are sufficient, since disinfectants under dirty conditions become gesture constant and are not necessary their strong effect if necessary.
<G-vec00272-001-s567><ask.fragen><de> Zudem sollten Sie sich fragen welche Wirkungsweise für Ihre Anforderungen ausreichend ist, da Desinfektionsmittel unter schmutzigen Bedingungen gestestet werden und deren starke Wirkung gegebenenfalls nicht notwendig ist.
<G-vec00272-001-s568><ask.fragen><en> In every country, there are those who find different religious beliefs threatening; in every culture, those who love freedom for themselves must ask themselves how much they’re willing to tolerate freedom for others.
<G-vec00272-001-s568><ask.fragen><de> In jedem Land gibt es diejenigen, die unterschiedliche religiöse Ansichten als Bedrohung empfinden; in jeder Kultur müssen sich diejenigen, die Freiheit für sich in Anspruch nehmen, fragen, wie viel Freiheit sie anderen zugestehen.
<G-vec00272-001-s569><ask.fragen><en> Men put beautiful woman on this high pedestal and then it can be quite challenging and nerve wracking if you ask one out and she actually accepts.
<G-vec00272-001-s569><ask.fragen><de> Männer setzen schöne Frau auf diesem hohen Sockel und dann kann es ziemlich schwierig und nervenaufreibend sein, wenn Sie sich fragen aus, und sie tatsächlich akzeptiert.
<G-vec00272-001-s589><ask.bitten><en> There is no obligation to actually provide such data as we ask for on our website.
<G-vec00272-001-s589><ask.bitten><de> Es besteht keine Verpflichtung jene Daten, um deren Angabe wir Sie auf unserer Website bitten, tatsächlich anzugeben.
<G-vec00272-001-s590><ask.bitten><en> After reading it, people usually ask for more.
<G-vec00272-001-s590><ask.bitten><de> Wenn sie das lesen, bitten die Nutzer normalerweise um mehr.
<G-vec00272-001-s591><ask.bitten><en> "While they were in the car, the police told Ms. Xu, ""When we arrive at your house, you have to ask your family members to allow you to stay home."
<G-vec00272-001-s591><ask.bitten><de> "Solange sie im Wagen waren, erzählte die Polizei Frau Xu: ""Wenn wir bei Ihnen zu Hause ankommen, müssen Sie Ihre Familienangehörigen bitten, Ihnen zu erlauben, zu Hause bleiben zu dürfen."
<G-vec00272-001-s592><ask.bitten><en> If we wish to keep your application longer for future job postings, we will ask for your written consent.
<G-vec00272-001-s592><ask.bitten><de> Falls wir Ihre Bewerbung für zukünftige Stellenausschreibungen länger aufbewahren möchten, werden wir Sie um Ihr schriftliches Einverständnis bitten.
<G-vec00272-001-s593><ask.bitten><en> If we envisage obtaining navigation information related to your terminal from a third party, which we could combine with the personal data you provided, we will ask for your explicit prior consent before proceeding with such an association and sending you any resulting advertisements or surveys.
<G-vec00272-001-s593><ask.bitten><de> Sollten wir beabsichtigen, von einem Dritten Surf-Informationen über Ihren Computer zu erhalten, mit denen wir die persönlichen Informationen ergänzen können, die Sie uns zur Verfügung gestellt haben, werden wir Sie zunächst um Ihre ausdrückliche Erlaubnis hierzu bitten, bevor wir mit dem jeweiligen Dritten eine entsprechende Vereinbarung treffen und die hieraus resultierenden Werbeanzeigen oder Kundenwerbematerialien an Sie übermitteln werden.
<G-vec00272-001-s594><ask.bitten><en> This means that after you have registered we send to the email address entered an email in which we ask for confirmation that you wish to receive the newsletter.
<G-vec00272-001-s594><ask.bitten><de> Das heißt, dass wir Ihnen nach Ihrer Anmeldung eine E-Mail an die angegebene E-Mail-Adresse senden, in welcher wir Sie um Bestätigung bitten, dass Sie den Versand des Newsletters wünschen.
<G-vec00272-001-s595><ask.bitten><en> If one insists on one’s own ideas and reasonings, the greater Light and Knowledge cannot come or else is marred and obstructed in the coming at every step by a lower interference; if one insists on one’s desire s and fancies, that great luminous Will and Force cannot act in its own true power – for you ask it to be the servant of your desires; if one refuses to give up one’s petty ways of feeling, eternal Love and suprem e Ananda cannot descend or ar e mixed and spil t from the effervescing crude emotional vessel.
<G-vec00272-001-s595><ask.bitten><de> Wenn man auf seinen eigenen Vorstellungen und Überlegungen beharrt, können das größere Licht und Wissen nicht kommen, oder aber sie werden in ihrem Kommen auf Schritt und Tritt durch eine Störung von unten entstellt und behindert; wenn man auf seinen eigenen Wünschen und Eitelkeiten beharrt, können jener große leuchtende Wille und jene Kraft in der ihnen eigenen wahren Macht nicht wirken – denn das wäre so, als würdest du sie bitten, der Knecht deiner Begierden zu sein; solange man seine kleine Art des Fühlens nicht aufgeben will, können die ewige Liebe und der höchste Ananda nicht herabkommen, oder sie werden beim Überschäumen des groben emotionalen Kessels vermischt und verschüttet.
<G-vec00272-001-s596><ask.bitten><en> Note: Because of the high number of enrolments we must ask you to cut your programme to 20 minutes in the first round.
<G-vec00272-001-s596><ask.bitten><de> Hinweis: Auf Grund der hohen Zahl an Anmeldungen müssen wir Sie bitten, Ihr Pogramm in der ersten Runde auf 20 Minuten zu kürzen.
<G-vec00272-001-s597><ask.bitten><en> Where appropriate and required, we will ask for your consent.
<G-vec00272-001-s597><ask.bitten><de> Wo dies angemessen und erforderlich ist, werden wir Sie um Ihre Zustimmung bitten.
<G-vec00272-001-s598><ask.bitten><en> We will ask for your consent before processing your information in this way.
<G-vec00272-001-s598><ask.bitten><de> Wir werden wir Sie um Ihre Zustimmung bitten, bevor wir Ihre Daten auf diese Weise verarbeiten.
<G-vec00272-001-s599><ask.bitten><en> DINNER - Chicken noodle soup - Call your mom and ask her about renting your old room.
<G-vec00272-001-s599><ask.bitten><de> DINNER - Chicken Noodle Soup - Rufen Sie Ihre Mutter und sie bitten, über die Vermietung Ihrer alten Zimmer.
<G-vec00272-001-s600><ask.bitten><en> We have also been wanting to ask for sometime for copies of the booklet Who prays is saved for our community.
<G-vec00272-001-s600><ask.bitten><de> Wir haben auch schon seit geraumer Zeit die Absicht, Sie um ein paar Exemplare des Gebetbüchleins Who prays is saved für unsere Gemeinschaft zu bitten.
<G-vec00272-001-s601><ask.bitten><en> So pray to Our Lady too and ask her, as a mother, to “make me strong”.
<G-vec00272-001-s601><ask.bitten><de> Also auch zur Muttergottes beten und sie bitten, dass sie, als Mutter, mich stark macht.
<G-vec00272-001-s602><ask.bitten><en> Step 3: Once you click on the appropriate option, the software will takes you to the next level where you will see a new window which will ask you to select the appropriate drive from where your file gets deleted.
<G-vec00272-001-s602><ask.bitten><de> Schritt 3: Sobald Sie auf die entsprechende Option, wird die Software führt Sie auf die nächste Ebene, wo Sie ein neues Fenster, das Sie bitten, das entsprechende Laufwerk aus, wo Sie Ihre Datei gelöscht wird wählen werden sehen.
<G-vec00272-001-s603><ask.bitten><en> He continued and told her that he would like to ask her to cooperate in a great work for humanity.
<G-vec00272-001-s603><ask.bitten><de> Er fuhr fort und sagte ihr, er möchte sie um ihre Kooperation in einem großen Werk für die Menschheit bitten.
<G-vec00272-001-s604><ask.bitten><en> We may ask to confirm your requests by sending an email to your email account registered with Us.
<G-vec00272-001-s604><ask.bitten><de> Wir können Sie bitten, Ihre Anfrage zu bestätigen, indem Sie eine E-Mail an Ihren bei uns registrierten E-Mail-Account senden.
<G-vec00272-001-s605><ask.bitten><en> Imagine being able to see them or even being with people that are several at one time and do all you ask them, couples talk, orgies for cams, wake up your more if you are female or male.
<G-vec00272-001-s605><ask.bitten><de> Stellen Sie sich vor, Sie zu sehen oder sogar mit Menschen, die mehrere auf einmal und alles tun, was Sie Sie bitten, Ihnen, Paare zu sprechen, Orgien, für die Kameras, aufwachen Ihr mehr, wenn Sie weiblich sind oder Männlich.
<G-vec00272-001-s606><ask.bitten><en> She went away, and consulted her evil mother, who hated John the Baptist because of what he had said about her evil ways; and the mother counselled the daughter to ask for the head of John the Baptist.
<G-vec00272-001-s606><ask.bitten><de> Sie ging fort und konsultierte ihre böse Mutter, die Johannes den Täufer hasste wegen seiner Aussagen über ihre bösen Wege; und die Mutter riet der Tochter, sie möge um den Kopf Johannes' des Täufers bitten.
<G-vec00272-001-s607><ask.bitten><en> I am grateful to you for transmitting the courteous greetings from the Governor-General, Sir Colville Young, and in return I would ask you kindly to convey my own good wishes to him and to all the people of your nation.
<G-vec00272-001-s607><ask.bitten><de> Ich danke ihnen, daß Sie mir die freundlichen Grüße des Generalgouverneurs, Sir Colville Young, übermittelt haben, und im Gegenzug möchte ich Sie bitten, ihm und dem ganzen Volk Ihrer Nation meine eigenen guten Wünsche zu überbringen.
<G-vec00384-001-s589><ask.bitten><en> There is no obligation to actually provide such data as we ask for on our website.
<G-vec00384-001-s589><ask.bitten><de> Es besteht keine Verpflichtung jene Daten, um deren Angabe wir Sie auf unserer Website bitten, tatsächlich anzugeben.
<G-vec00384-001-s590><ask.bitten><en> After reading it, people usually ask for more.
<G-vec00384-001-s590><ask.bitten><de> Wenn sie das lesen, bitten die Nutzer normalerweise um mehr.
<G-vec00384-001-s591><ask.bitten><en> "While they were in the car, the police told Ms. Xu, ""When we arrive at your house, you have to ask your family members to allow you to stay home."
<G-vec00384-001-s591><ask.bitten><de> "Solange sie im Wagen waren, erzählte die Polizei Frau Xu: ""Wenn wir bei Ihnen zu Hause ankommen, müssen Sie Ihre Familienangehörigen bitten, Ihnen zu erlauben, zu Hause bleiben zu dürfen."
<G-vec00384-001-s592><ask.bitten><en> If we wish to keep your application longer for future job postings, we will ask for your written consent.
<G-vec00384-001-s592><ask.bitten><de> Falls wir Ihre Bewerbung für zukünftige Stellenausschreibungen länger aufbewahren möchten, werden wir Sie um Ihr schriftliches Einverständnis bitten.
<G-vec00384-001-s593><ask.bitten><en> If we envisage obtaining navigation information related to your terminal from a third party, which we could combine with the personal data you provided, we will ask for your explicit prior consent before proceeding with such an association and sending you any resulting advertisements or surveys.
<G-vec00384-001-s593><ask.bitten><de> Sollten wir beabsichtigen, von einem Dritten Surf-Informationen über Ihren Computer zu erhalten, mit denen wir die persönlichen Informationen ergänzen können, die Sie uns zur Verfügung gestellt haben, werden wir Sie zunächst um Ihre ausdrückliche Erlaubnis hierzu bitten, bevor wir mit dem jeweiligen Dritten eine entsprechende Vereinbarung treffen und die hieraus resultierenden Werbeanzeigen oder Kundenwerbematerialien an Sie übermitteln werden.
<G-vec00384-001-s594><ask.bitten><en> This means that after you have registered we send to the email address entered an email in which we ask for confirmation that you wish to receive the newsletter.
<G-vec00384-001-s594><ask.bitten><de> Das heißt, dass wir Ihnen nach Ihrer Anmeldung eine E-Mail an die angegebene E-Mail-Adresse senden, in welcher wir Sie um Bestätigung bitten, dass Sie den Versand des Newsletters wünschen.
<G-vec00384-001-s595><ask.bitten><en> If one insists on one’s own ideas and reasonings, the greater Light and Knowledge cannot come or else is marred and obstructed in the coming at every step by a lower interference; if one insists on one’s desire s and fancies, that great luminous Will and Force cannot act in its own true power – for you ask it to be the servant of your desires; if one refuses to give up one’s petty ways of feeling, eternal Love and suprem e Ananda cannot descend or ar e mixed and spil t from the effervescing crude emotional vessel.
<G-vec00384-001-s595><ask.bitten><de> Wenn man auf seinen eigenen Vorstellungen und Überlegungen beharrt, können das größere Licht und Wissen nicht kommen, oder aber sie werden in ihrem Kommen auf Schritt und Tritt durch eine Störung von unten entstellt und behindert; wenn man auf seinen eigenen Wünschen und Eitelkeiten beharrt, können jener große leuchtende Wille und jene Kraft in der ihnen eigenen wahren Macht nicht wirken – denn das wäre so, als würdest du sie bitten, der Knecht deiner Begierden zu sein; solange man seine kleine Art des Fühlens nicht aufgeben will, können die ewige Liebe und der höchste Ananda nicht herabkommen, oder sie werden beim Überschäumen des groben emotionalen Kessels vermischt und verschüttet.
<G-vec00384-001-s596><ask.bitten><en> Note: Because of the high number of enrolments we must ask you to cut your programme to 20 minutes in the first round.
<G-vec00384-001-s596><ask.bitten><de> Hinweis: Auf Grund der hohen Zahl an Anmeldungen müssen wir Sie bitten, Ihr Pogramm in der ersten Runde auf 20 Minuten zu kürzen.
<G-vec00384-001-s597><ask.bitten><en> Where appropriate and required, we will ask for your consent.
<G-vec00384-001-s597><ask.bitten><de> Wo dies angemessen und erforderlich ist, werden wir Sie um Ihre Zustimmung bitten.
<G-vec00384-001-s598><ask.bitten><en> We will ask for your consent before processing your information in this way.
<G-vec00384-001-s598><ask.bitten><de> Wir werden wir Sie um Ihre Zustimmung bitten, bevor wir Ihre Daten auf diese Weise verarbeiten.
<G-vec00384-001-s599><ask.bitten><en> DINNER - Chicken noodle soup - Call your mom and ask her about renting your old room.
<G-vec00384-001-s599><ask.bitten><de> DINNER - Chicken Noodle Soup - Rufen Sie Ihre Mutter und sie bitten, über die Vermietung Ihrer alten Zimmer.
<G-vec00384-001-s600><ask.bitten><en> We have also been wanting to ask for sometime for copies of the booklet Who prays is saved for our community.
<G-vec00384-001-s600><ask.bitten><de> Wir haben auch schon seit geraumer Zeit die Absicht, Sie um ein paar Exemplare des Gebetbüchleins Who prays is saved für unsere Gemeinschaft zu bitten.
<G-vec00384-001-s601><ask.bitten><en> So pray to Our Lady too and ask her, as a mother, to “make me strong”.
<G-vec00384-001-s601><ask.bitten><de> Also auch zur Muttergottes beten und sie bitten, dass sie, als Mutter, mich stark macht.
<G-vec00384-001-s602><ask.bitten><en> Step 3: Once you click on the appropriate option, the software will takes you to the next level where you will see a new window which will ask you to select the appropriate drive from where your file gets deleted.
<G-vec00384-001-s602><ask.bitten><de> Schritt 3: Sobald Sie auf die entsprechende Option, wird die Software führt Sie auf die nächste Ebene, wo Sie ein neues Fenster, das Sie bitten, das entsprechende Laufwerk aus, wo Sie Ihre Datei gelöscht wird wählen werden sehen.
<G-vec00384-001-s603><ask.bitten><en> He continued and told her that he would like to ask her to cooperate in a great work for humanity.
<G-vec00384-001-s603><ask.bitten><de> Er fuhr fort und sagte ihr, er möchte sie um ihre Kooperation in einem großen Werk für die Menschheit bitten.
<G-vec00384-001-s604><ask.bitten><en> We may ask to confirm your requests by sending an email to your email account registered with Us.
<G-vec00384-001-s604><ask.bitten><de> Wir können Sie bitten, Ihre Anfrage zu bestätigen, indem Sie eine E-Mail an Ihren bei uns registrierten E-Mail-Account senden.
<G-vec00384-001-s605><ask.bitten><en> Imagine being able to see them or even being with people that are several at one time and do all you ask them, couples talk, orgies for cams, wake up your more if you are female or male.
<G-vec00384-001-s605><ask.bitten><de> Stellen Sie sich vor, Sie zu sehen oder sogar mit Menschen, die mehrere auf einmal und alles tun, was Sie Sie bitten, Ihnen, Paare zu sprechen, Orgien, für die Kameras, aufwachen Ihr mehr, wenn Sie weiblich sind oder Männlich.
<G-vec00384-001-s606><ask.bitten><en> She went away, and consulted her evil mother, who hated John the Baptist because of what he had said about her evil ways; and the mother counselled the daughter to ask for the head of John the Baptist.
<G-vec00384-001-s606><ask.bitten><de> Sie ging fort und konsultierte ihre böse Mutter, die Johannes den Täufer hasste wegen seiner Aussagen über ihre bösen Wege; und die Mutter riet der Tochter, sie möge um den Kopf Johannes' des Täufers bitten.
<G-vec00384-001-s607><ask.bitten><en> I am grateful to you for transmitting the courteous greetings from the Governor-General, Sir Colville Young, and in return I would ask you kindly to convey my own good wishes to him and to all the people of your nation.
<G-vec00384-001-s607><ask.bitten><de> Ich danke ihnen, daß Sie mir die freundlichen Grüße des Generalgouverneurs, Sir Colville Young, übermittelt haben, und im Gegenzug möchte ich Sie bitten, ihm und dem ganzen Volk Ihrer Nation meine eigenen guten Wünsche zu überbringen.
<G-vec00272-001-s608><ask.fragen><en> If you're unsure you can ask your Yamaha Official dealer, but whatever you do, never fit a non-approved plug.
<G-vec00272-001-s608><ask.fragen><de> Wenn Sie sich nicht sicher sind, können Sie Ihren Yamaha-Händler fragen, aber was auch immer Sie tun, verwenden Sie niemals eine nicht zugelassene Zündkerze.
<G-vec00272-001-s609><ask.fragen><en> "2007-11-13 22:16:19 - Go ask alice One of fiction's finest marketing minds, The Cheshire Cat, once told Alice in Wonderland something all business owners and marketers should remember:""If you don't care where you are going, it doesn't make a difference which path you take."
<G-vec00272-001-s609><ask.fragen><de> "2007-11-13 22:16:19 - Gehen Sie Fragen Alice Ein von feinstem Marketing der Erfindung kümmert sich, die Cheshire Katze, sobald erklärt Alice im Märchenland etwas alle Geschäft Inhaber und Marketingspezialisten sollten sich erinnern:""wenn Sie sich nicht interessieren, wo Sie gehen, unterscheidet es nicht, das Weg Sie nehmen."
<G-vec00272-001-s610><ask.fragen><en> Feel free to use the Ask Seller a question feature to ask about the necessary software, or if you have any other questions.
<G-vec00272-001-s610><ask.fragen><de> Fühlen Sie sich frei verwenden Sie die Frage an den Verkäufer Funktion, über die notwendige Software fragen, oder wenn Sie weitere Fragen haben.
<G-vec00272-001-s611><ask.fragen><en> Her glacier-coloured eyes seem to ask if you are ready for a ride on a sledge.
<G-vec00272-001-s611><ask.fragen><de> Ihre gletscherfarbenen Augen scheinen Sie zu fragen, ob Sie für eine Schlittenfahrt bereit sind.
<G-vec00272-001-s612><ask.fragen><en> If you approach politely and ask for directions, there's a good chance the person – a city native or a knowledgeable expat — will be willing to help you out.
<G-vec00272-001-s612><ask.fragen><de> Wenn Sie höflich auf sie zugehen und nach dem Weg fragen, besteht eine gute Chance, dass die Person – ein Einheimischer der Stadt oder ein sachkundiger Zugezogener – dazu bereit ist, Ihnen behilflich zu sein.
<G-vec00272-001-s613><ask.fragen><en> In this beautiful area and with the help of trained insurance workers, you will find the house of your dreams, you just have to contact a real estate agent and through your portfolio, Â you will be able to select the house you want from hundreds of places and get all the information you need know about it, including the location, number of rooms, bathrooms, size in square meters, surroundings and the vicinity of the property, and to corroborate you can ask for a guided tour, the staff will be available to assist you and help you in the election you make.
<G-vec00272-001-s613><ask.fragen><de> In dieser schönen Gegend und mit Hilfe von geschulten Versicherten finden Sie das Haus Ihrer Träume, Sie mÃ1⁄4ssen nur einen Immobilienmakler in Dénia kontaktieren und durch Ihr Portfolio können Sie aus Hunderten von Orten das gewÃ1⁄4nschte Haus auswählen und erhalten alle Informationen, die Sie benötigen, einschließlich der Staat, in dem es ist, Anzahl der Zimmer, Badezimmer, Größe in Quadratmetern, Umgebung und der Umgebung des Anwesens, und zur Bestätigung können Sie um eine gefÃ1⁄4hrte Tour fragen, das Personal wird Ihnen zur VerfÃ1⁄4gung stehen und Ihnen bei der Auswahl behilflich sein.
<G-vec00272-001-s614><ask.fragen><en> If this plastics company for sale in Italy does not fit your requirements feel free to ask for other plastics companies for sale .
<G-vec00272-001-s614><ask.fragen><de> Wenn dieses Kunststoffunternehmen, das in Italien zum Verkauf steht, nicht Ihren Anforderungen entspricht, zögern Sie nicht, nach anderen Kunststoffunternehmen zu fragen.
<G-vec00272-001-s615><ask.fragen><en> No requirement any type of prescriptions Currently, you will certainly no more have to ask your medical professional for any kind of prescriptions since you can buy Winstrol whoever you are, anywhere you could be without any kind of prescriptions.
<G-vec00272-001-s615><ask.fragen><de> Keine Anforderung jede Art von Vorschriften Derzeit werden Sie nicht viel länger Sie Ihren Arzt für jede Art von Rezepten fragen müssen, da könnten Sie Winstrol kaufen wer Sie sind, jeder Ort, den Sie ohne jede Art von Vorschriften sein kann.
<G-vec00272-001-s616><ask.fragen><en> These peoples should ask the Blacks or the Native Americans or the millions of Latin American immigrants who live in the USA whether there is really democracy and freedom there.
<G-vec00272-001-s616><ask.fragen><de> Aber sie muessten die Schwarzen und die nordamerikanischen Indianer fragen und die Millionen von lateinamerikanischen Migranten, die in den Vereinigten Staaten leben, ob dort wirklich Demokratie und Freiheit herrschen.
<G-vec00272-001-s617><ask.fragen><en> Above all, do not forget to ask about nice places to visit.
<G-vec00272-001-s617><ask.fragen><de> Vergessen Sie vor allem nicht, nach interessanten Ausflugszielen zu fragen.
<G-vec00272-001-s618><ask.fragen><en> I have recounted it in front of hundreds of business people in my community and almost daily to people who ask me why I opened my store in March 2003.
<G-vec00272-001-s618><ask.fragen><de> Ich habe sie vor Hunderten von Geschäftsleuten in meiner Gemeinschaft erzählt und erzähle sie fast täglich denjenigen, die mich fragen, warum ich meinen Laden im März 2003 eröffnet habe.
<G-vec00272-001-s619><ask.fragen><en> If this plastics company for sale in France does not fit your requirements feel free to ask for other plastics companies for sale.
<G-vec00272-001-s619><ask.fragen><de> Wenn dieses Kunststoffunternehmen nicht Ihren Anforderungen entspricht, können Sie gerne nach anderen Kunststoffunternehmen zum Verkauf fragen.
<G-vec00272-001-s620><ask.fragen><en> If you ask those who used the berries to help recover from a serious illness, and now have good health, he or she will tell you that becoming an increasingly important health than finances or work.
<G-vec00272-001-s620><ask.fragen><de> Wenn man jemanden, der die Beeren verwendet hat, zu helfen, wieder an einer schweren Krankheit und haben jetzt eine gute Gesundheit, würde er oder sie Ihnen sagen, dass mehr Wert auf Gesundheit als Finanzen setzen oder sie zu fragen.
<G-vec00272-001-s621><ask.fragen><en> In that case, the operator will only ask for additional useful information.
<G-vec00272-001-s621><ask.fragen><de> Der Operator wird Sie gegebenenfalls lediglich um zusätzliche nützliche Informationen fragen.
<G-vec00272-001-s622><ask.fragen><en> You'd have to ask them that yourself.
<G-vec00272-001-s622><ask.fragen><de> Das müssten Sie sie selbst fragen.
<G-vec00272-001-s623><ask.fragen><en> If this plastics company for sale in Italy does not fit your requirements feel free to ask for other plastics companies for sale.
<G-vec00272-001-s623><ask.fragen><de> Wenn dieses Kunststoffunternehmen, das in Italien zum Verkauf steht, nicht Ihren Anforderungen entspricht, zögern Sie nicht, nach anderen Kunststoffunternehmen zum Verkauf zu fragen.
<G-vec00272-001-s624><ask.fragen><en> Pray to Him, seek Him, ask for His love.
<G-vec00272-001-s624><ask.fragen><de> Sie möge zu Ihm beten, Ihn suchen, nach Seiner Liebe fragen.
<G-vec00272-001-s625><ask.fragen><en> Establish as a challenge to introspect and ask ourselves whether we really grateful to the other gestures that have taken us.
<G-vec00272-001-s625><ask.fragen><de> Stellen Sie als Herausforderung an introspect und uns fragen, ob wir wirklich dankbar, dass die anderen Gesten, die uns genommen haben.
<G-vec00272-001-s626><ask.fragen><en> Be sure to ask your institution if you'll be responsible for additional expenses, such as textbooks and technology fees.
<G-vec00272-001-s626><ask.fragen><de> Stellen Sie sicher, dass Sie Ihre Institution fragen, ob Sie für zusätzliche Ausgaben wie Lehrbücher und Technologiegebühren verantwortlich sind.
<G-vec00384-001-s608><ask.fragen><en> If you're unsure you can ask your Yamaha Official dealer, but whatever you do, never fit a non-approved plug.
<G-vec00384-001-s608><ask.fragen><de> Wenn Sie sich nicht sicher sind, können Sie Ihren Yamaha-Händler fragen, aber was auch immer Sie tun, verwenden Sie niemals eine nicht zugelassene Zündkerze.
<G-vec00384-001-s609><ask.fragen><en> "2007-11-13 22:16:19 - Go ask alice One of fiction's finest marketing minds, The Cheshire Cat, once told Alice in Wonderland something all business owners and marketers should remember:""If you don't care where you are going, it doesn't make a difference which path you take."
<G-vec00384-001-s609><ask.fragen><de> "2007-11-13 22:16:19 - Gehen Sie Fragen Alice Ein von feinstem Marketing der Erfindung kümmert sich, die Cheshire Katze, sobald erklärt Alice im Märchenland etwas alle Geschäft Inhaber und Marketingspezialisten sollten sich erinnern:""wenn Sie sich nicht interessieren, wo Sie gehen, unterscheidet es nicht, das Weg Sie nehmen."
<G-vec00384-001-s610><ask.fragen><en> Feel free to use the Ask Seller a question feature to ask about the necessary software, or if you have any other questions.
<G-vec00384-001-s610><ask.fragen><de> Fühlen Sie sich frei verwenden Sie die Frage an den Verkäufer Funktion, über die notwendige Software fragen, oder wenn Sie weitere Fragen haben.
<G-vec00384-001-s611><ask.fragen><en> Her glacier-coloured eyes seem to ask if you are ready for a ride on a sledge.
<G-vec00384-001-s611><ask.fragen><de> Ihre gletscherfarbenen Augen scheinen Sie zu fragen, ob Sie für eine Schlittenfahrt bereit sind.
<G-vec00384-001-s612><ask.fragen><en> If you approach politely and ask for directions, there's a good chance the person – a city native or a knowledgeable expat — will be willing to help you out.
<G-vec00384-001-s612><ask.fragen><de> Wenn Sie höflich auf sie zugehen und nach dem Weg fragen, besteht eine gute Chance, dass die Person – ein Einheimischer der Stadt oder ein sachkundiger Zugezogener – dazu bereit ist, Ihnen behilflich zu sein.
<G-vec00384-001-s613><ask.fragen><en> In this beautiful area and with the help of trained insurance workers, you will find the house of your dreams, you just have to contact a real estate agent and through your portfolio, Â you will be able to select the house you want from hundreds of places and get all the information you need know about it, including the location, number of rooms, bathrooms, size in square meters, surroundings and the vicinity of the property, and to corroborate you can ask for a guided tour, the staff will be available to assist you and help you in the election you make.
<G-vec00384-001-s613><ask.fragen><de> In dieser schönen Gegend und mit Hilfe von geschulten Versicherten finden Sie das Haus Ihrer Träume, Sie mÃ1⁄4ssen nur einen Immobilienmakler in Dénia kontaktieren und durch Ihr Portfolio können Sie aus Hunderten von Orten das gewÃ1⁄4nschte Haus auswählen und erhalten alle Informationen, die Sie benötigen, einschließlich der Staat, in dem es ist, Anzahl der Zimmer, Badezimmer, Größe in Quadratmetern, Umgebung und der Umgebung des Anwesens, und zur Bestätigung können Sie um eine gefÃ1⁄4hrte Tour fragen, das Personal wird Ihnen zur VerfÃ1⁄4gung stehen und Ihnen bei der Auswahl behilflich sein.
<G-vec00384-001-s614><ask.fragen><en> If this plastics company for sale in Italy does not fit your requirements feel free to ask for other plastics companies for sale .
<G-vec00384-001-s614><ask.fragen><de> Wenn dieses Kunststoffunternehmen, das in Italien zum Verkauf steht, nicht Ihren Anforderungen entspricht, zögern Sie nicht, nach anderen Kunststoffunternehmen zu fragen.
<G-vec00384-001-s615><ask.fragen><en> No requirement any type of prescriptions Currently, you will certainly no more have to ask your medical professional for any kind of prescriptions since you can buy Winstrol whoever you are, anywhere you could be without any kind of prescriptions.
<G-vec00384-001-s615><ask.fragen><de> Keine Anforderung jede Art von Vorschriften Derzeit werden Sie nicht viel länger Sie Ihren Arzt für jede Art von Rezepten fragen müssen, da könnten Sie Winstrol kaufen wer Sie sind, jeder Ort, den Sie ohne jede Art von Vorschriften sein kann.
<G-vec00384-001-s616><ask.fragen><en> These peoples should ask the Blacks or the Native Americans or the millions of Latin American immigrants who live in the USA whether there is really democracy and freedom there.
<G-vec00384-001-s616><ask.fragen><de> Aber sie muessten die Schwarzen und die nordamerikanischen Indianer fragen und die Millionen von lateinamerikanischen Migranten, die in den Vereinigten Staaten leben, ob dort wirklich Demokratie und Freiheit herrschen.
<G-vec00384-001-s617><ask.fragen><en> Above all, do not forget to ask about nice places to visit.
<G-vec00384-001-s617><ask.fragen><de> Vergessen Sie vor allem nicht, nach interessanten Ausflugszielen zu fragen.
<G-vec00384-001-s618><ask.fragen><en> I have recounted it in front of hundreds of business people in my community and almost daily to people who ask me why I opened my store in March 2003.
<G-vec00384-001-s618><ask.fragen><de> Ich habe sie vor Hunderten von Geschäftsleuten in meiner Gemeinschaft erzählt und erzähle sie fast täglich denjenigen, die mich fragen, warum ich meinen Laden im März 2003 eröffnet habe.
<G-vec00384-001-s619><ask.fragen><en> If this plastics company for sale in France does not fit your requirements feel free to ask for other plastics companies for sale.
<G-vec00384-001-s619><ask.fragen><de> Wenn dieses Kunststoffunternehmen nicht Ihren Anforderungen entspricht, können Sie gerne nach anderen Kunststoffunternehmen zum Verkauf fragen.
<G-vec00384-001-s620><ask.fragen><en> If you ask those who used the berries to help recover from a serious illness, and now have good health, he or she will tell you that becoming an increasingly important health than finances or work.
<G-vec00384-001-s620><ask.fragen><de> Wenn man jemanden, der die Beeren verwendet hat, zu helfen, wieder an einer schweren Krankheit und haben jetzt eine gute Gesundheit, würde er oder sie Ihnen sagen, dass mehr Wert auf Gesundheit als Finanzen setzen oder sie zu fragen.
<G-vec00384-001-s621><ask.fragen><en> In that case, the operator will only ask for additional useful information.
<G-vec00384-001-s621><ask.fragen><de> Der Operator wird Sie gegebenenfalls lediglich um zusätzliche nützliche Informationen fragen.
<G-vec00384-001-s622><ask.fragen><en> You'd have to ask them that yourself.
<G-vec00384-001-s622><ask.fragen><de> Das müssten Sie sie selbst fragen.
<G-vec00384-001-s623><ask.fragen><en> If this plastics company for sale in Italy does not fit your requirements feel free to ask for other plastics companies for sale.
<G-vec00384-001-s623><ask.fragen><de> Wenn dieses Kunststoffunternehmen, das in Italien zum Verkauf steht, nicht Ihren Anforderungen entspricht, zögern Sie nicht, nach anderen Kunststoffunternehmen zum Verkauf zu fragen.
<G-vec00384-001-s624><ask.fragen><en> Pray to Him, seek Him, ask for His love.
<G-vec00384-001-s624><ask.fragen><de> Sie möge zu Ihm beten, Ihn suchen, nach Seiner Liebe fragen.
<G-vec00384-001-s625><ask.fragen><en> Establish as a challenge to introspect and ask ourselves whether we really grateful to the other gestures that have taken us.
<G-vec00384-001-s625><ask.fragen><de> Stellen Sie als Herausforderung an introspect und uns fragen, ob wir wirklich dankbar, dass die anderen Gesten, die uns genommen haben.
<G-vec00384-001-s626><ask.fragen><en> Be sure to ask your institution if you'll be responsible for additional expenses, such as textbooks and technology fees.
<G-vec00384-001-s626><ask.fragen><de> Stellen Sie sicher, dass Sie Ihre Institution fragen, ob Sie für zusätzliche Ausgaben wie Lehrbücher und Technologiegebühren verantwortlich sind.
<G-vec00272-001-s627><ask.stellen><en> Ask a question. Another way to get the conversation rolling with a girl is to ask a question.
<G-vec00272-001-s627><ask.stellen><de> Stelle eine Frage: Eine weitere gute Methode, um ein Gespräch in Gang zu bringen, ist, wenn du der Frau eine Frage stellst.
<G-vec00272-001-s628><ask.stellen><en> Ask questions to better understand the problem.
<G-vec00272-001-s628><ask.stellen><de> Stelle Fragen, um das Problem besser zu verstehen.
<G-vec00272-001-s629><ask.stellen><en> Please ask here .
<G-vec00272-001-s629><ask.stellen><de> Stelle sie einfach hier .
<G-vec00272-001-s630><ask.stellen><en> Ask your child questions about what they see and hear on television.
<G-vec00272-001-s630><ask.stellen><de> Stelle deinem Kind Fragen zu dem, was es im Fernsehen sieht und hört.
<G-vec00272-001-s631><ask.stellen><en> ―After reading this kind of defeatist prose, I ask three questions.
<G-vec00272-001-s631><ask.stellen><de> Nachdem ich diese Art von Miesmacher Prosa gelesen habe, stelle ich drei Fragen.
<G-vec00272-001-s632><ask.stellen><en> Throughout this time, I also ask this question in French justice.
<G-vec00272-001-s632><ask.stellen><de> Während dieser Zeit, ich stelle diese Frage in Französisch Gerechtigkeit.
<G-vec00272-001-s633><ask.stellen><en> For this purpose, we kindly ask you to keep this information updated. Finally, we would like to inform you about the possibility of exercising your rights of access, rectification, cancellation and opposition of such data.
<G-vec00272-001-s633><ask.stellen><de> Hierfür bitte halten Sie ihre Informationen aktuellen Lehrplan angemessen.Schließlich stelle ich die Möglichkeit der Ausübung von Rechten auf Auskunft, Berichtigung, Löschung und Widerspruch dieser Daten.
<G-vec00272-001-s634><ask.stellen><en> - I ask young people aged 12-21 questions that people keep questioning themselves still when they are grown-up.
<G-vec00272-001-s634><ask.stellen><de> - Ich stelle Jugendlichen zwischen 12-21 Jahren Fragen, die man sich auch noch stellt, wenn man erwachsen ist.
<G-vec00272-001-s635><ask.stellen><en> I ask this question out of very real concern.
<G-vec00272-001-s635><ask.stellen><de> Ich stelle diese Frage aus sehr realen Sorge.
<G-vec00272-001-s636><ask.stellen><en> Please do not use this forum to ask gameplay questions.
<G-vec00272-001-s636><ask.stellen><de> Bitte stelle in diesem Forum keine Fragen zum Gameplay.
<G-vec00272-001-s637><ask.stellen><en> Ask Questions – Involve your audience in more than just everyday quizzes, trivia and contests.
<G-vec00272-001-s637><ask.stellen><de> Stelle Fragen – Beteilige Deine Zielgruppe an mehr als nur täglichen Quizzen, belanglosen Ratespielen und Wettbewerben.
<G-vec00272-001-s638><ask.stellen><en> Of course I ask myself artistic questions.
<G-vec00272-001-s638><ask.stellen><de> Natürlich stelle ich mir auch künstlerische Fragen.
<G-vec00272-001-s639><ask.stellen><en> This is the question he asked, and I ask you the same question.
<G-vec00272-001-s639><ask.stellen><de> Dies ist die Frage, die er mir stellte und ich stelle euch jetzt die selbe Frage.
<G-vec00272-001-s640><ask.stellen><en> Ask yourself a couple of questions before you consult your doctor.
<G-vec00272-001-s640><ask.stellen><de> Stelle dir selbst einige Fragen, bevor du einen Arzt aufsuchst.
<G-vec00272-001-s641><ask.stellen><en> Ask your questions and find out the best answers.
<G-vec00272-001-s641><ask.stellen><de> Stelle eine Frage und finde die besten Antworten.
<G-vec00272-001-s642><ask.stellen><en> He mentioned a value of a certain compound's physical property which seemed so improbable to my supervisor that he interrupted to ask where he could have gotten such a figure.
<G-vec00272-001-s642><ask.stellen><de> An einer Stelle seines Vortrages gab er eine bestimmte physikalische Größe an, die meinem Doktorvater so unwahrscheinlich erschien, daß er nachfrug, woher Dr. Hillebrecht denn diesen Wert habe.
<G-vec00272-001-s643><ask.stellen><en> It is a question that I often ask myself in the course of cultivation.
<G-vec00272-001-s643><ask.stellen><de> Das ist eine Frage, die ich mir im Laufe der Kultivierung oft selbst stelle.
<G-vec00272-001-s644><ask.stellen><en> "After seeing the results of our approach the client said, ""I do ask for a lot, however, as a supplier you should be aware by now of my respect for DS Smith."""
<G-vec00272-001-s644><ask.stellen><de> "Vermindert sie das Abfallvolumen bei den Kunden des Herstellers Nach Begutachtung der Ergebnisse unseres Ansatzes sagte der Kunde: ""Ich stelle hohe Ansprüche und kann DS Smith als Lieferant nur meinen Respekt aussprechen."
<G-vec00272-001-s645><ask.stellen><en> Ask questions and be sure that you are satisfied with the answers.
<G-vec00272-001-s645><ask.stellen><de> Stelle Fragen und versichere dich, dass du mit den Antwort zufrieden bist.
<G-vec00384-001-s627><ask.stellen><en> Ask a question. Another way to get the conversation rolling with a girl is to ask a question.
<G-vec00384-001-s627><ask.stellen><de> Stelle eine Frage: Eine weitere gute Methode, um ein Gespräch in Gang zu bringen, ist, wenn du der Frau eine Frage stellst.
<G-vec00384-001-s628><ask.stellen><en> Ask questions to better understand the problem.
<G-vec00384-001-s628><ask.stellen><de> Stelle Fragen, um das Problem besser zu verstehen.
<G-vec00384-001-s629><ask.stellen><en> Please ask here .
<G-vec00384-001-s629><ask.stellen><de> Stelle sie einfach hier .
<G-vec00384-001-s630><ask.stellen><en> Ask your child questions about what they see and hear on television.
<G-vec00384-001-s630><ask.stellen><de> Stelle deinem Kind Fragen zu dem, was es im Fernsehen sieht und hört.
<G-vec00384-001-s631><ask.stellen><en> ―After reading this kind of defeatist prose, I ask three questions.
<G-vec00384-001-s631><ask.stellen><de> Nachdem ich diese Art von Miesmacher Prosa gelesen habe, stelle ich drei Fragen.
<G-vec00384-001-s632><ask.stellen><en> Throughout this time, I also ask this question in French justice.
<G-vec00384-001-s632><ask.stellen><de> Während dieser Zeit, ich stelle diese Frage in Französisch Gerechtigkeit.
<G-vec00384-001-s633><ask.stellen><en> For this purpose, we kindly ask you to keep this information updated. Finally, we would like to inform you about the possibility of exercising your rights of access, rectification, cancellation and opposition of such data.
<G-vec00384-001-s633><ask.stellen><de> Hierfür bitte halten Sie ihre Informationen aktuellen Lehrplan angemessen.Schließlich stelle ich die Möglichkeit der Ausübung von Rechten auf Auskunft, Berichtigung, Löschung und Widerspruch dieser Daten.
<G-vec00384-001-s634><ask.stellen><en> - I ask young people aged 12-21 questions that people keep questioning themselves still when they are grown-up.
<G-vec00384-001-s634><ask.stellen><de> - Ich stelle Jugendlichen zwischen 12-21 Jahren Fragen, die man sich auch noch stellt, wenn man erwachsen ist.
<G-vec00384-001-s635><ask.stellen><en> I ask this question out of very real concern.
<G-vec00384-001-s635><ask.stellen><de> Ich stelle diese Frage aus sehr realen Sorge.
<G-vec00384-001-s636><ask.stellen><en> Please do not use this forum to ask gameplay questions.
<G-vec00384-001-s636><ask.stellen><de> Bitte stelle in diesem Forum keine Fragen zum Gameplay.
<G-vec00384-001-s637><ask.stellen><en> Ask Questions – Involve your audience in more than just everyday quizzes, trivia and contests.
<G-vec00384-001-s637><ask.stellen><de> Stelle Fragen – Beteilige Deine Zielgruppe an mehr als nur täglichen Quizzen, belanglosen Ratespielen und Wettbewerben.
<G-vec00384-001-s638><ask.stellen><en> Of course I ask myself artistic questions.
<G-vec00384-001-s638><ask.stellen><de> Natürlich stelle ich mir auch künstlerische Fragen.
<G-vec00384-001-s639><ask.stellen><en> This is the question he asked, and I ask you the same question.
<G-vec00384-001-s639><ask.stellen><de> Dies ist die Frage, die er mir stellte und ich stelle euch jetzt die selbe Frage.
<G-vec00384-001-s640><ask.stellen><en> Ask yourself a couple of questions before you consult your doctor.
<G-vec00384-001-s640><ask.stellen><de> Stelle dir selbst einige Fragen, bevor du einen Arzt aufsuchst.
<G-vec00384-001-s641><ask.stellen><en> Ask your questions and find out the best answers.
<G-vec00384-001-s641><ask.stellen><de> Stelle eine Frage und finde die besten Antworten.
<G-vec00384-001-s642><ask.stellen><en> He mentioned a value of a certain compound's physical property which seemed so improbable to my supervisor that he interrupted to ask where he could have gotten such a figure.
<G-vec00384-001-s642><ask.stellen><de> An einer Stelle seines Vortrages gab er eine bestimmte physikalische Größe an, die meinem Doktorvater so unwahrscheinlich erschien, daß er nachfrug, woher Dr. Hillebrecht denn diesen Wert habe.
<G-vec00384-001-s643><ask.stellen><en> It is a question that I often ask myself in the course of cultivation.
<G-vec00384-001-s643><ask.stellen><de> Das ist eine Frage, die ich mir im Laufe der Kultivierung oft selbst stelle.
<G-vec00384-001-s644><ask.stellen><en> "After seeing the results of our approach the client said, ""I do ask for a lot, however, as a supplier you should be aware by now of my respect for DS Smith."""
<G-vec00384-001-s644><ask.stellen><de> "Vermindert sie das Abfallvolumen bei den Kunden des Herstellers Nach Begutachtung der Ergebnisse unseres Ansatzes sagte der Kunde: ""Ich stelle hohe Ansprüche und kann DS Smith als Lieferant nur meinen Respekt aussprechen."
<G-vec00384-001-s645><ask.stellen><en> Ask questions and be sure that you are satisfied with the answers.
<G-vec00384-001-s645><ask.stellen><de> Stelle Fragen und versichere dich, dass du mit den Antwort zufrieden bist.
<G-vec00272-001-s646><ask.stellen><en> One of the already drunk guys tried to ask us questions in Lao which we of course had no chance to understand.
<G-vec00272-001-s646><ask.stellen><de> Einer der schon betrunkenen Männer versuchte uns Fragen in laotisch zu stellen, die für uns das reinste Kauderwelsch waren...
<G-vec00272-001-s647><ask.stellen><en> You can ask questions at any point and can begin to get an idea of all the possibilities that we offer.
<G-vec00272-001-s647><ask.stellen><de> Sie haben jederzeit die Möglichkeit, Fragen zu stellen und gewinnen so einen guten Eindruck von den zahlreichen Möglichkeiten, die wir Ihnen bieten.
<G-vec00272-001-s648><ask.stellen><en> We want to ask ourselves such questions theoretically as well as with regard to the role of texts, practices and objects – from a historical and contemporary point of view.
<G-vec00272-001-s648><ask.stellen><de> Solchen Fragen wollen wir uns theoretisch und mit Blick auf die Rolle von Texten, Praktiken und Objekten – historisch und gegenwartsbezogen – stellen.
<G-vec00272-001-s649><ask.stellen><en> There will also be the opportunity to ask own questions and to receive competent answers.
<G-vec00272-001-s649><ask.stellen><de> Es wird im Anschluss daran auch die Möglichkeit geben, eigene Fragen zu stellen und kompetente Antworten aus berufenem Munde zu erhalten.
<G-vec00272-001-s650><ask.stellen><en> This is what Erkan thought when he wanted to ask his girlfriend Rosa the all-important question.
<G-vec00272-001-s650><ask.stellen><de> Dies dachte sich auch Erkan, als er seiner Freundin Rosa die alles entscheidende Frage stellen wollte.
<G-vec00272-001-s651><ask.stellen><en> Ask 10LouiseB10 about Sheraton Fuerteventura Beach, Golf & Spa Resort This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC
<G-vec00272-001-s651><ask.stellen><de> Stellen Sie Eichkaetzchen eine Frage zu Sheraton Fuerteventura Beach, Golf & Spa Resort Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00272-001-s652><ask.stellen><en> There is an interview with your massage therapist before the massage in which you can ask any questions and voice any wishes.
<G-vec00272-001-s652><ask.stellen><de> Der Massage geht ein Gespräch voraus, in dem Sie der Masseurin oder dem Masseur Ihre Wünsche offenbaren und Fragen stellen können.
<G-vec00272-001-s653><ask.stellen><en> You are welcome to ask questions to clarify your understanding of Martinus' analyses.
<G-vec00272-001-s653><ask.stellen><de> Sie sind willkommen, Fragen zum Verständnis von Martinus' Analysen zu stellen.
<G-vec00272-001-s654><ask.stellen><en> We will also learn to ask questions using 'Est-ce que' (Is it that), the masculine and feminine words for...
<G-vec00272-001-s654><ask.stellen><de> "Wir werden auch lernen, Fragen zu stellen, indem wir ""Est-ce que"" (das ist das), die männlichen und..."
<G-vec00272-001-s655><ask.stellen><en> In the very beginning of writing they were conditional on and created by the sole and deeply human endeavour to ask questions, existential questions of 'Where are we coming from?' and 'Where are we going to?': Still primitive symbols, in ancient times carved into tortoise shells and oracle bones as 'questions' to the powers of fate - getting 'answers', read from the cracks the burning heat of fire had left on them.
<G-vec00272-001-s655><ask.stellen><de> Im frühen Beginn der Schrift bedingt und geschaffen durch das allein und zutiefst menschliche Bestreben, Fragen zu stellen, Fragen nach dem 'Woher' und 'Wohin' unseres Daseins: Primitive Zeichen noch - in uralter Zeit als 'Fragen' in Schildkrötpanzer und Orakelknochen geritzt - die von Feuersglut hinterlassenen Risse und Sprünge darauf als 'Antwort'-Zeichen der Schicksalsmächte 'gelesen'.
<G-vec00272-001-s656><ask.stellen><en> You are at university to learn new things, which means you are allowed to ask as many questions as possible.
<G-vec00272-001-s656><ask.stellen><de> Du bist an der Uni, um Neues zu lernen, das bedeutet, dass du so viele Fragen wie möglich stellen darfst.
<G-vec00272-001-s657><ask.stellen><en> When seeking to understand someone, don't be afraid to ask questions or say something wrong.
<G-vec00272-001-s657><ask.stellen><de> Bei der Suche nach jemanden zu verstehen,, Haben Sie keine Angst, Fragen zu stellen oder sagen etwas falsch.
<G-vec00272-001-s658><ask.stellen><en> The kids can have a go at the instruments, get a little concert and can ask questions.
<G-vec00272-001-s658><ask.stellen><de> Die Kids dürfen zudem alle Instrumente anfassen, Fragen stellen und erleben, wie die Gruppe ein Musikstück zusammensetzt.
<G-vec00272-001-s659><ask.stellen><en> Let's define our position clearly, ask relevant questions and suggest areas of our spiritual lives that need attention.
<G-vec00272-001-s659><ask.stellen><de> Wir definieren unsere Position klar, sachdienliche Fragen stellen und schlagen Bereichen unseres geistigen Lebens, die Aufmerksamkeit brauchen.
<G-vec00272-001-s660><ask.stellen><en> No need any prescriptions Now, you will certainly no more need to ask your doctor for any prescriptions since you can buy Winstrol whoever you are, any place you might be without any type of prescriptions.
<G-vec00272-001-s660><ask.stellen><de> Keine Anforderung jede Art von Vorschriften Derzeit sind Sie nicht mehr benötigen Sie Ihren Arzt für alle Rezepte aufgrund der Tatsache zu stellen, dass man Winstrol bestellen, wer Sie sind, wo Sie ohne jede Art von Vorschriften sein kann.
<G-vec00272-001-s661><ask.stellen><en> You can ask for some concerns and examination in the main website.
<G-vec00272-001-s661><ask.stellen><de> Sie könnten für einige Bedenken stellen und auch die Prüfung im Hauptstandort.
<G-vec00272-001-s662><ask.stellen><en> Ask Switz_traveler about Hotel Manzoni This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC
<G-vec00272-001-s662><ask.stellen><de> Stellen Sie SMTORD eine Frage zu Hotel Manzoni Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00272-001-s663><ask.stellen><en> This is why I decided to build an orchid forum...so people looking for help could find information and ask questions.
<G-vec00272-001-s663><ask.stellen><de> Deshalb entschied ich, ein Orchideeforum zu errichten…, also das Suchen nach Hilfe bevölkeren könnte Informationen finden und Fragen stellen.
<G-vec00272-001-s664><ask.stellen><en> Was allowed to ask questions, and remember the answers.
<G-vec00272-001-s664><ask.stellen><de> Ihm wurde erlaubt Fragen zu stellen, und sich an die Antworten zu erinnern.
<G-vec00384-001-s646><ask.stellen><en> One of the already drunk guys tried to ask us questions in Lao which we of course had no chance to understand.
<G-vec00384-001-s646><ask.stellen><de> Einer der schon betrunkenen Männer versuchte uns Fragen in laotisch zu stellen, die für uns das reinste Kauderwelsch waren...
<G-vec00384-001-s647><ask.stellen><en> You can ask questions at any point and can begin to get an idea of all the possibilities that we offer.
<G-vec00384-001-s647><ask.stellen><de> Sie haben jederzeit die Möglichkeit, Fragen zu stellen und gewinnen so einen guten Eindruck von den zahlreichen Möglichkeiten, die wir Ihnen bieten.
<G-vec00384-001-s648><ask.stellen><en> We want to ask ourselves such questions theoretically as well as with regard to the role of texts, practices and objects – from a historical and contemporary point of view.
<G-vec00384-001-s648><ask.stellen><de> Solchen Fragen wollen wir uns theoretisch und mit Blick auf die Rolle von Texten, Praktiken und Objekten – historisch und gegenwartsbezogen – stellen.
<G-vec00384-001-s649><ask.stellen><en> There will also be the opportunity to ask own questions and to receive competent answers.
<G-vec00384-001-s649><ask.stellen><de> Es wird im Anschluss daran auch die Möglichkeit geben, eigene Fragen zu stellen und kompetente Antworten aus berufenem Munde zu erhalten.
<G-vec00384-001-s650><ask.stellen><en> This is what Erkan thought when he wanted to ask his girlfriend Rosa the all-important question.
<G-vec00384-001-s650><ask.stellen><de> Dies dachte sich auch Erkan, als er seiner Freundin Rosa die alles entscheidende Frage stellen wollte.
<G-vec00384-001-s651><ask.stellen><en> Ask 10LouiseB10 about Sheraton Fuerteventura Beach, Golf & Spa Resort This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC
<G-vec00384-001-s651><ask.stellen><de> Stellen Sie Eichkaetzchen eine Frage zu Sheraton Fuerteventura Beach, Golf & Spa Resort Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00384-001-s652><ask.stellen><en> There is an interview with your massage therapist before the massage in which you can ask any questions and voice any wishes.
<G-vec00384-001-s652><ask.stellen><de> Der Massage geht ein Gespräch voraus, in dem Sie der Masseurin oder dem Masseur Ihre Wünsche offenbaren und Fragen stellen können.
<G-vec00384-001-s653><ask.stellen><en> You are welcome to ask questions to clarify your understanding of Martinus' analyses.
<G-vec00384-001-s653><ask.stellen><de> Sie sind willkommen, Fragen zum Verständnis von Martinus' Analysen zu stellen.
<G-vec00384-001-s654><ask.stellen><en> We will also learn to ask questions using 'Est-ce que' (Is it that), the masculine and feminine words for...
<G-vec00384-001-s654><ask.stellen><de> "Wir werden auch lernen, Fragen zu stellen, indem wir ""Est-ce que"" (das ist das), die männlichen und..."
<G-vec00384-001-s655><ask.stellen><en> In the very beginning of writing they were conditional on and created by the sole and deeply human endeavour to ask questions, existential questions of 'Where are we coming from?' and 'Where are we going to?': Still primitive symbols, in ancient times carved into tortoise shells and oracle bones as 'questions' to the powers of fate - getting 'answers', read from the cracks the burning heat of fire had left on them.
<G-vec00384-001-s655><ask.stellen><de> Im frühen Beginn der Schrift bedingt und geschaffen durch das allein und zutiefst menschliche Bestreben, Fragen zu stellen, Fragen nach dem 'Woher' und 'Wohin' unseres Daseins: Primitive Zeichen noch - in uralter Zeit als 'Fragen' in Schildkrötpanzer und Orakelknochen geritzt - die von Feuersglut hinterlassenen Risse und Sprünge darauf als 'Antwort'-Zeichen der Schicksalsmächte 'gelesen'.
<G-vec00384-001-s656><ask.stellen><en> You are at university to learn new things, which means you are allowed to ask as many questions as possible.
<G-vec00384-001-s656><ask.stellen><de> Du bist an der Uni, um Neues zu lernen, das bedeutet, dass du so viele Fragen wie möglich stellen darfst.
<G-vec00384-001-s657><ask.stellen><en> When seeking to understand someone, don't be afraid to ask questions or say something wrong.
<G-vec00384-001-s657><ask.stellen><de> Bei der Suche nach jemanden zu verstehen,, Haben Sie keine Angst, Fragen zu stellen oder sagen etwas falsch.
<G-vec00384-001-s658><ask.stellen><en> The kids can have a go at the instruments, get a little concert and can ask questions.
<G-vec00384-001-s658><ask.stellen><de> Die Kids dürfen zudem alle Instrumente anfassen, Fragen stellen und erleben, wie die Gruppe ein Musikstück zusammensetzt.
<G-vec00384-001-s659><ask.stellen><en> Let's define our position clearly, ask relevant questions and suggest areas of our spiritual lives that need attention.
<G-vec00384-001-s659><ask.stellen><de> Wir definieren unsere Position klar, sachdienliche Fragen stellen und schlagen Bereichen unseres geistigen Lebens, die Aufmerksamkeit brauchen.
<G-vec00384-001-s660><ask.stellen><en> No need any prescriptions Now, you will certainly no more need to ask your doctor for any prescriptions since you can buy Winstrol whoever you are, any place you might be without any type of prescriptions.
<G-vec00384-001-s660><ask.stellen><de> Keine Anforderung jede Art von Vorschriften Derzeit sind Sie nicht mehr benötigen Sie Ihren Arzt für alle Rezepte aufgrund der Tatsache zu stellen, dass man Winstrol bestellen, wer Sie sind, wo Sie ohne jede Art von Vorschriften sein kann.
<G-vec00384-001-s661><ask.stellen><en> You can ask for some concerns and examination in the main website.
<G-vec00384-001-s661><ask.stellen><de> Sie könnten für einige Bedenken stellen und auch die Prüfung im Hauptstandort.
<G-vec00384-001-s662><ask.stellen><en> Ask Switz_traveler about Hotel Manzoni This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC
<G-vec00384-001-s662><ask.stellen><de> Stellen Sie SMTORD eine Frage zu Hotel Manzoni Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00384-001-s663><ask.stellen><en> This is why I decided to build an orchid forum...so people looking for help could find information and ask questions.
<G-vec00384-001-s663><ask.stellen><de> Deshalb entschied ich, ein Orchideeforum zu errichten…, also das Suchen nach Hilfe bevölkeren könnte Informationen finden und Fragen stellen.
<G-vec00384-001-s664><ask.stellen><en> Was allowed to ask questions, and remember the answers.
<G-vec00384-001-s664><ask.stellen><de> Ihm wurde erlaubt Fragen zu stellen, und sich an die Antworten zu erinnern.
<G-vec00272-001-s665><ask.stellen><en> Ask mhossam about The Oberoi Sahl Hasheesh This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC
<G-vec00272-001-s665><ask.stellen><de> Stellen Sie Chriskiss eine Frage zu The Oberoi Sahl Hasheesh Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00272-001-s666><ask.stellen><en> Before buying a lawn mower STIGA SBK 45 F ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s666><ask.stellen><de> Vor dem Kauf eines Rasenmäher STIGA SBK 45 F stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s667><ask.stellen><en> Before buying a lawnmower Watt Garden WRT-1000L ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s667><ask.stellen><de> Vor dem Kauf eines Rasenmähers Watt Garten WRT-1000L stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s668><ask.stellen><en> Before buying a lawnmower ALPINA TB 34 D ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s668><ask.stellen><de> Vor dem Kauf eines Rasenmähers ALPINA TB 34 D stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s669><ask.stellen><en> Before buying a lawn mower Husqvarna R 316T ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s669><ask.stellen><de> Vor dem Kauf eines Rasenmäher Husqvarna 316T R stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s670><ask.stellen><en> Before buying an electric guitar Stagg G300 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s670><ask.stellen><de> Vor dem Kauf eine E-Gitarre Stagg G300 stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s671><ask.stellen><en> Before buying a lawn mower AS-Motor Allmaher AS 21-165/3 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s671><ask.stellen><de> Vor dem Kauf eines Rasenmäher AS-Motor AS Allmäher 21-165/3 stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s672><ask.stellen><en> Before purchasing an electric Gretsch G5422TDC Electromatic Hollow Body ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s672><ask.stellen><de> Vor dem Kauf eines Elektro Gretsch Electromatic Hollow Body G5422TDC stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s673><ask.stellen><en> Before buying an electric guitar Schecter Stiletto Studio 5 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s673><ask.stellen><de> Vor dem Kauf eine E-Gitarre Schecter Stiletto Studio 5 stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s674><ask.stellen><en> Before buying a lawnmower STERN Austria GT15 + ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s674><ask.stellen><de> Vor dem Kauf eines Rasenmähers STERN Österreich GT15 + stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s675><ask.stellen><en> Before buying an electric guitar Dean Hardtail Classic Quilt ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s675><ask.stellen><de> Vor dem Kauf eine E-Gitarre Dean Hardtail-Klassiker Quilt stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s676><ask.stellen><en> Before buying a lawnmower AL-KO 119463 P 473 Highline ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s676><ask.stellen><de> Vor dem Kauf eines Rasenmäher AL-KO 119463 P 473 Highline stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s677><ask.stellen><en> Before buying a lawn mower Echo GT-22GES ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s677><ask.stellen><de> Vor dem Kauf eines Rasenmähers Echo GT-22GES stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s678><ask.stellen><en> Ask poppy4 about Hotel Cipriani and Palazzo Vendramin by Orient-Express This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC.
<G-vec00272-001-s678><ask.stellen><de> Stellen Sie bubffm eine Frage zu Hotel Cipriani and Palazzo Vendramin by Orient-Express Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00272-001-s679><ask.stellen><en> Before buying a lawn mower MTD Smart 46 PO ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s679><ask.stellen><de> Vor dem Kauf eines Rasenmäher MTD Smart-46 PO stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s680><ask.stellen><en> Before buying a lawnmower Maruyama BCV5020 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s680><ask.stellen><de> Vor dem Kauf eines Rasenmähers Maruyama BCV5020 stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s681><ask.stellen><en> Before buying a lawnmower PARTNER P51-650CMD ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s681><ask.stellen><de> Vor dem Kauf eines Rasenmähers PARTNER P51-650CMD stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s682><ask.stellen><en> Before buying a lawnmower Patriot Garden Power PTA 30 Li ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s682><ask.stellen><de> Vor dem Kauf eines Rasenmähers Patriot Gartenwerk PTA 30 Li stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s683><ask.stellen><en> Before purchasing an electric LTD M-103FM ask all your options, equipment, appearance and warranty from the seller.
<G-vec00272-001-s683><ask.stellen><de> Vor dem Kauf eines Elektro LTD M-103FM stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s665><ask.stellen><en> Ask mhossam about The Oberoi Sahl Hasheesh This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC
<G-vec00384-001-s665><ask.stellen><de> Stellen Sie Chriskiss eine Frage zu The Oberoi Sahl Hasheesh Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00384-001-s666><ask.stellen><en> Before buying a lawn mower STIGA SBK 45 F ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s666><ask.stellen><de> Vor dem Kauf eines Rasenmäher STIGA SBK 45 F stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s667><ask.stellen><en> Before buying a lawnmower Watt Garden WRT-1000L ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s667><ask.stellen><de> Vor dem Kauf eines Rasenmähers Watt Garten WRT-1000L stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s668><ask.stellen><en> Before buying a lawnmower ALPINA TB 34 D ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s668><ask.stellen><de> Vor dem Kauf eines Rasenmähers ALPINA TB 34 D stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s669><ask.stellen><en> Before buying a lawn mower Husqvarna R 316T ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s669><ask.stellen><de> Vor dem Kauf eines Rasenmäher Husqvarna 316T R stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s670><ask.stellen><en> Before buying an electric guitar Stagg G300 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s670><ask.stellen><de> Vor dem Kauf eine E-Gitarre Stagg G300 stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s671><ask.stellen><en> Before buying a lawn mower AS-Motor Allmaher AS 21-165/3 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s671><ask.stellen><de> Vor dem Kauf eines Rasenmäher AS-Motor AS Allmäher 21-165/3 stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s672><ask.stellen><en> Before purchasing an electric Gretsch G5422TDC Electromatic Hollow Body ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s672><ask.stellen><de> Vor dem Kauf eines Elektro Gretsch Electromatic Hollow Body G5422TDC stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s673><ask.stellen><en> Before buying an electric guitar Schecter Stiletto Studio 5 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s673><ask.stellen><de> Vor dem Kauf eine E-Gitarre Schecter Stiletto Studio 5 stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s674><ask.stellen><en> Before buying a lawnmower STERN Austria GT15 + ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s674><ask.stellen><de> Vor dem Kauf eines Rasenmähers STERN Österreich GT15 + stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s675><ask.stellen><en> Before buying an electric guitar Dean Hardtail Classic Quilt ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s675><ask.stellen><de> Vor dem Kauf eine E-Gitarre Dean Hardtail-Klassiker Quilt stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s676><ask.stellen><en> Before buying a lawnmower AL-KO 119463 P 473 Highline ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s676><ask.stellen><de> Vor dem Kauf eines Rasenmäher AL-KO 119463 P 473 Highline stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s677><ask.stellen><en> Before buying a lawn mower Echo GT-22GES ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s677><ask.stellen><de> Vor dem Kauf eines Rasenmähers Echo GT-22GES stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s678><ask.stellen><en> Ask poppy4 about Hotel Cipriani and Palazzo Vendramin by Orient-Express This review is the subjective opinion of a TripAdvisor member and not of TripAdvisor LLC.
<G-vec00384-001-s678><ask.stellen><de> Stellen Sie bubffm eine Frage zu Hotel Cipriani and Palazzo Vendramin by Orient-Express Diese Bewertung ist die subjektive Meinung eines TripAdvisor-Mitgliedes und nicht die von TripAdvisor LLC.
<G-vec00384-001-s679><ask.stellen><en> Before buying a lawn mower MTD Smart 46 PO ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s679><ask.stellen><de> Vor dem Kauf eines Rasenmäher MTD Smart-46 PO stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s680><ask.stellen><en> Before buying a lawnmower Maruyama BCV5020 ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s680><ask.stellen><de> Vor dem Kauf eines Rasenmähers Maruyama BCV5020 stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s681><ask.stellen><en> Before buying a lawnmower PARTNER P51-650CMD ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s681><ask.stellen><de> Vor dem Kauf eines Rasenmähers PARTNER P51-650CMD stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s682><ask.stellen><en> Before buying a lawnmower Patriot Garden Power PTA 30 Li ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s682><ask.stellen><de> Vor dem Kauf eines Rasenmähers Patriot Gartenwerk PTA 30 Li stellen Sie alle Ihre Optionen, AusrÃ1⁄4stung, Aussehen und Garantie vom Verkäufer.
<G-vec00384-001-s683><ask.stellen><en> Before purchasing an electric LTD M-103FM ask all your options, equipment, appearance and warranty from the seller.
<G-vec00384-001-s683><ask.stellen><de> Vor dem Kauf eines Elektro LTD M-103FM stellen Sie alle Ihre Optionen, Ausrüstung, Aussehen und Garantie vom Verkäufer.
<G-vec00272-001-s703><ask.verlangen><en> Prophetic action: There are other assemblies in which so-called servants of God, ask their faithful to bring sand.
<G-vec00272-001-s703><ask.verlangen><de> Prophetische Aktion: Es gibt Gemeinden, in denen die so genannten Gottesmänner Sand von den Kirchgängern verlangen.
<G-vec00272-001-s704><ask.verlangen><en> The hotel reserves the right to ask for a deposit upon check in which is refundable if no damage is made in the apartments.
<G-vec00272-001-s704><ask.verlangen><de> Das Hotel behält sich das Recht vor, beim Check-in eine Kaution zu verlangen, die erstattet wird, wenn keine Schäden in den Apartments verursacht wurden.
<G-vec00272-001-s705><ask.verlangen><en> This enables you to ask us to delete or remove personal data where there is no good reason for our continuing to process such data.
<G-vec00272-001-s705><ask.verlangen><de> Aufgrund dieses Rechts können Sie von uns die Löschung oder Entfernung von personenbezogenen Daten verlangen, wenn kein triftiger Grund für deren weitere Verarbeitung vorliegt.
<G-vec00272-001-s706><ask.verlangen><en> And as she was going on her way her husband admonished her to ask a field of her father.
<G-vec00272-001-s706><ask.verlangen><de> Als sie nun ankam, drängte er sie, von ihrem Vater ein Stück Land zu verlangen.
<G-vec00272-001-s707><ask.verlangen><en> It was a big bass frenzy on this fishing trip and you could not ask for more.
<G-vec00272-001-s707><ask.verlangen><de> Es war eine große Bass Raserei auf diesem Angelausflug und man konnte nicht mehr verlangen.
<G-vec00272-001-s708><ask.verlangen><en> Please ask us the price list and the associated Exposé.
<G-vec00272-001-s708><ask.verlangen><de> Bitte verlangen Sie von uns die aktuelle Preisliste und das dazugehörige Exposé.
<G-vec00272-001-s709><ask.verlangen><en> Please ask for our price lists for gastronomy or resellers.
<G-vec00272-001-s709><ask.verlangen><de> Bitte verlangen Sie unsere Preislisten für Gastro- oder Wiederverkäufer.
<G-vec00272-001-s710><ask.verlangen><en> In this case the hotel reserves the right to ask a prepayment as a guarantee for the reservation.
<G-vec00272-001-s710><ask.verlangen><de> In diesem Fall behält sich das Hotel das Recht vor, eine Vorauszahlung als Buchungsgarantie zu verlangen.
<G-vec00272-001-s711><ask.verlangen><en> The Seller may also ask the Client to e-mail photographs showing the non-conformity claim made.
<G-vec00272-001-s711><ask.verlangen><de> Der Verkäufer kann auch verlangen, dass der Kunde ihm per E-Mail Fotos als Beweis für die behauptete Nichtübereinstimmung schickt.
<G-vec00272-001-s712><ask.verlangen><en> If the defect cannot be cured in a reasonable amount of time, or if the correction of replacement failed for other reasons, you have the option to ask for a reduced price or may cancel the order.
<G-vec00272-001-s712><ask.verlangen><de> Kann der Mangel nicht innerhalb angemessener Frist behoben werden oder ist die Nachbesserung oder Ersatzlieferung aus sonstigen Gründen als fehlgeschlagen anzusehen, können Sie nach Ihrer Wahl Herabsetzung der Vergütung (Minderung) verlangen oder vom Vertrag zurücktreten.
<G-vec00272-001-s713><ask.verlangen><en> In order to not be misquoted or have false information that got lost in translation slip into the article, ask to proofread the article and that it's not to be published without your consent.
<G-vec00272-001-s713><ask.verlangen><de> Damit Sie nicht falsch zitiert werden oder gar falsche Informationen veröffentlicht werden, die irgendwo im Interview verdreht beim Journalisten angekommen sind, verlangen Sie, den Artikel gegenzulesen.
<G-vec00272-001-s714><ask.verlangen><en> You may also ask us to correct or complete inaccurate information about you in our systems.Right to erasure and restriction You have the right to ask us to delete or restrict the processing of your personal data.
<G-vec00272-001-s714><ask.verlangen><de> Zudem können Sie von uns verlangen, dass wir unrichtige Daten über Sie in unseren Systemen berichtigen oder vervollständigen.Recht auf Löschung und Einschränkung Sie haben das Recht, von uns die Löschung oder die Einschränkung der Bearbeitung Ihrer Personendaten zu verlangen.
<G-vec00272-001-s715><ask.verlangen><en> You may also ask us to correct or complete inaccurate information about you in our systems.Right to erasure and restriction You have the right to ask us to delete or restrict the processing of your personal data.
<G-vec00272-001-s715><ask.verlangen><de> Zudem können Sie von uns verlangen, dass wir unrichtige Daten über Sie in unseren Systemen berichtigen oder vervollständigen.Recht auf Löschung und Einschränkung Sie haben das Recht, von uns die Löschung oder die Einschränkung der Bearbeitung Ihrer Personendaten zu verlangen.
<G-vec00272-001-s716><ask.verlangen><en> And the fact that I feel God in the soul, doesn't prevent at all me from completing my duties, also when I hurry the most important matters, that ask for attention, I don't tightly lose the presence of God in the soul and rest united to Him.
<G-vec00272-001-s716><ask.verlangen><de> Und die Tatsache, die ich Gott in der Seele höre, verhindert mich nicht ganz, meine Pflichten zu tun, auch wenn ich die wichtigsten Probleme erledige, die Aufmerksamkeit verlangen, verliere ich Ihm die Anwesenheit Gottes nicht in der Seele und dem Rest eng vereint.
<G-vec00272-001-s717><ask.verlangen><en> Not only we mention it but we also differ from other car rental companies because we don´t ask for minimum amounts of 400 € or 600 €.
<G-vec00272-001-s717><ask.verlangen><de> Wir erwähnen sie nicht nur, sondern wir unterscheiden uns auch von anderen Mietwagen-Unternehmen da wir nicht Minimum-Beträge von 400 oder 600 € verlangen.
<G-vec00272-001-s718><ask.verlangen><en> And they can't ask Krilin to risk his life with a second try that would definitely be more risky.
<G-vec00272-001-s718><ask.verlangen><de> Und er konnte nicht von Krilin verlangen, sein Leben für einen zweiten versuch zu riskieren, der deutlich gefährlicher sein würde.
<G-vec00272-001-s719><ask.verlangen><en> You have the right to ask for restricted processing of your personal data.
<G-vec00272-001-s719><ask.verlangen><de> Sie haben das Recht, die Einschränkung der Verarbeitung Ihrer personenbezogenen Daten zu verlangen.
<G-vec00272-001-s720><ask.verlangen><en> Once we have accepted, that God could ask Jews and Muslims alike to surrender their claim to al Haram ash Sharif / The Temple Mount in Jerusalem, both parties could get together on equal terms and discuss their willingness to compromise.
<G-vec00272-001-s720><ask.verlangen><de> Sobald wir akzeptiert haben, dass Gott sowohl von Juden wie auch von Muslimen verlangen könnte, ihren Anspruch auf al Haram ash Sharif, den Tempelberg, aufzugeben, können sich beide Parteien auf Augenhöhe begegnen und ihre Bereitschaft zu einem Kompromiss diskutieren.
<G-vec00272-001-s721><ask.verlangen><en> I would never wish it upon anyone else and would never ask for it, ever.
<G-vec00272-001-s721><ask.verlangen><de> Das würde ich niemandem wünschen und ich würde es niemals verlangen.
<G-vec00384-001-s703><ask.verlangen><en> Prophetic action: There are other assemblies in which so-called servants of God, ask their faithful to bring sand.
<G-vec00384-001-s703><ask.verlangen><de> Prophetische Aktion: Es gibt Gemeinden, in denen die so genannten Gottesmänner Sand von den Kirchgängern verlangen.
<G-vec00384-001-s704><ask.verlangen><en> The hotel reserves the right to ask for a deposit upon check in which is refundable if no damage is made in the apartments.
<G-vec00384-001-s704><ask.verlangen><de> Das Hotel behält sich das Recht vor, beim Check-in eine Kaution zu verlangen, die erstattet wird, wenn keine Schäden in den Apartments verursacht wurden.
<G-vec00384-001-s705><ask.verlangen><en> This enables you to ask us to delete or remove personal data where there is no good reason for our continuing to process such data.
<G-vec00384-001-s705><ask.verlangen><de> Aufgrund dieses Rechts können Sie von uns die Löschung oder Entfernung von personenbezogenen Daten verlangen, wenn kein triftiger Grund für deren weitere Verarbeitung vorliegt.
<G-vec00384-001-s706><ask.verlangen><en> And as she was going on her way her husband admonished her to ask a field of her father.
<G-vec00384-001-s706><ask.verlangen><de> Als sie nun ankam, drängte er sie, von ihrem Vater ein Stück Land zu verlangen.
<G-vec00384-001-s707><ask.verlangen><en> It was a big bass frenzy on this fishing trip and you could not ask for more.
<G-vec00384-001-s707><ask.verlangen><de> Es war eine große Bass Raserei auf diesem Angelausflug und man konnte nicht mehr verlangen.
<G-vec00384-001-s708><ask.verlangen><en> Please ask us the price list and the associated Exposé.
<G-vec00384-001-s708><ask.verlangen><de> Bitte verlangen Sie von uns die aktuelle Preisliste und das dazugehörige Exposé.
<G-vec00384-001-s709><ask.verlangen><en> Please ask for our price lists for gastronomy or resellers.
<G-vec00384-001-s709><ask.verlangen><de> Bitte verlangen Sie unsere Preislisten für Gastro- oder Wiederverkäufer.
<G-vec00384-001-s710><ask.verlangen><en> In this case the hotel reserves the right to ask a prepayment as a guarantee for the reservation.
<G-vec00384-001-s710><ask.verlangen><de> In diesem Fall behält sich das Hotel das Recht vor, eine Vorauszahlung als Buchungsgarantie zu verlangen.
<G-vec00384-001-s711><ask.verlangen><en> The Seller may also ask the Client to e-mail photographs showing the non-conformity claim made.
<G-vec00384-001-s711><ask.verlangen><de> Der Verkäufer kann auch verlangen, dass der Kunde ihm per E-Mail Fotos als Beweis für die behauptete Nichtübereinstimmung schickt.
<G-vec00384-001-s712><ask.verlangen><en> If the defect cannot be cured in a reasonable amount of time, or if the correction of replacement failed for other reasons, you have the option to ask for a reduced price or may cancel the order.
<G-vec00384-001-s712><ask.verlangen><de> Kann der Mangel nicht innerhalb angemessener Frist behoben werden oder ist die Nachbesserung oder Ersatzlieferung aus sonstigen Gründen als fehlgeschlagen anzusehen, können Sie nach Ihrer Wahl Herabsetzung der Vergütung (Minderung) verlangen oder vom Vertrag zurücktreten.
<G-vec00384-001-s713><ask.verlangen><en> In order to not be misquoted or have false information that got lost in translation slip into the article, ask to proofread the article and that it's not to be published without your consent.
<G-vec00384-001-s713><ask.verlangen><de> Damit Sie nicht falsch zitiert werden oder gar falsche Informationen veröffentlicht werden, die irgendwo im Interview verdreht beim Journalisten angekommen sind, verlangen Sie, den Artikel gegenzulesen.
<G-vec00384-001-s714><ask.verlangen><en> You may also ask us to correct or complete inaccurate information about you in our systems.Right to erasure and restriction You have the right to ask us to delete or restrict the processing of your personal data.
<G-vec00384-001-s714><ask.verlangen><de> Zudem können Sie von uns verlangen, dass wir unrichtige Daten über Sie in unseren Systemen berichtigen oder vervollständigen.Recht auf Löschung und Einschränkung Sie haben das Recht, von uns die Löschung oder die Einschränkung der Bearbeitung Ihrer Personendaten zu verlangen.
<G-vec00384-001-s715><ask.verlangen><en> You may also ask us to correct or complete inaccurate information about you in our systems.Right to erasure and restriction You have the right to ask us to delete or restrict the processing of your personal data.
<G-vec00384-001-s715><ask.verlangen><de> Zudem können Sie von uns verlangen, dass wir unrichtige Daten über Sie in unseren Systemen berichtigen oder vervollständigen.Recht auf Löschung und Einschränkung Sie haben das Recht, von uns die Löschung oder die Einschränkung der Bearbeitung Ihrer Personendaten zu verlangen.
<G-vec00384-001-s716><ask.verlangen><en> And the fact that I feel God in the soul, doesn't prevent at all me from completing my duties, also when I hurry the most important matters, that ask for attention, I don't tightly lose the presence of God in the soul and rest united to Him.
<G-vec00384-001-s716><ask.verlangen><de> Und die Tatsache, die ich Gott in der Seele höre, verhindert mich nicht ganz, meine Pflichten zu tun, auch wenn ich die wichtigsten Probleme erledige, die Aufmerksamkeit verlangen, verliere ich Ihm die Anwesenheit Gottes nicht in der Seele und dem Rest eng vereint.
<G-vec00384-001-s717><ask.verlangen><en> Not only we mention it but we also differ from other car rental companies because we don´t ask for minimum amounts of 400 € or 600 €.
<G-vec00384-001-s717><ask.verlangen><de> Wir erwähnen sie nicht nur, sondern wir unterscheiden uns auch von anderen Mietwagen-Unternehmen da wir nicht Minimum-Beträge von 400 oder 600 € verlangen.
<G-vec00384-001-s718><ask.verlangen><en> And they can't ask Krilin to risk his life with a second try that would definitely be more risky.
<G-vec00384-001-s718><ask.verlangen><de> Und er konnte nicht von Krilin verlangen, sein Leben für einen zweiten versuch zu riskieren, der deutlich gefährlicher sein würde.
<G-vec00384-001-s719><ask.verlangen><en> You have the right to ask for restricted processing of your personal data.
<G-vec00384-001-s719><ask.verlangen><de> Sie haben das Recht, die Einschränkung der Verarbeitung Ihrer personenbezogenen Daten zu verlangen.
<G-vec00384-001-s720><ask.verlangen><en> Once we have accepted, that God could ask Jews and Muslims alike to surrender their claim to al Haram ash Sharif / The Temple Mount in Jerusalem, both parties could get together on equal terms and discuss their willingness to compromise.
<G-vec00384-001-s720><ask.verlangen><de> Sobald wir akzeptiert haben, dass Gott sowohl von Juden wie auch von Muslimen verlangen könnte, ihren Anspruch auf al Haram ash Sharif, den Tempelberg, aufzugeben, können sich beide Parteien auf Augenhöhe begegnen und ihre Bereitschaft zu einem Kompromiss diskutieren.
<G-vec00384-001-s721><ask.verlangen><en> I would never wish it upon anyone else and would never ask for it, ever.
<G-vec00384-001-s721><ask.verlangen><de> Das würde ich niemandem wünschen und ich würde es niemals verlangen.
<G-vec00272-001-s722><ask.verlangen><en> You should be sceptical if they already ask to be paid for this service.
<G-vec00272-001-s722><ask.verlangen><de> Verlangt er dafür bereits ein Honorar, sollte Sie das hellhörig machen.
<G-vec00272-001-s723><ask.verlangen><en> It does not ask for small personal satisfactions, but finds its satisfaction in the growth of the Truth within the being; what it seeks and finds is not any indulgence of a vital and physical claim, but the true nearness which consists in the constant presence of the Divine in the heart and the rule of the Divine in all the Nature.
<G-vec00272-001-s723><ask.verlangen><de> Sie verlangt nicht nach armseliger persönlicher Befriedigung, sondern findet ihre Befriedigung, wenn die Wahrheit im Inneren des [menschlichen] Wesens wächst; was sie sucht und findet, ist nicht Nachsicht gegenüber einer vitalen und physischen Forderung, sondern die wahre Nähe, die aus der immerwährenden Gegenwart des Göttlichen im Herzen sowie der Herrschaft des Göttlichen in der ganzen menschlichen Natur besteht.
<G-vec00272-001-s724><ask.verlangen><en> I thought that I would see these twitter feeds by their location, like on a map, but I suppose that's a bit too much to ask for (also it might be creepy).
<G-vec00272-001-s724><ask.verlangen><de> Ich dachte, dass ich sehen würde, diese Twitter-Feeds durch ihre Lage, wie auf einer Karte, aber ich vermute, das ist ein bisschen zu viel verlangt (auch könnte es gruselig sein).
<G-vec00272-001-s725><ask.verlangen><en> After examination begins, the PTO may issue something called an office action, which usually ask for explanations, raise questions, or request further information.
<G-vec00272-001-s725><ask.verlangen><de> "Nach dem Beginn der Prüfung erteilt das USPTO dem Anmelder üblicherweise einen Prüfungsbescheid (,,Office Action""), welcher normalerweise Formmängel und offensichtliche Patentierungshindernisse mitteilt, Erklärungen verlangt, Fragen erhebt oder um weitere Informationen ersucht."
<G-vec00272-001-s726><ask.verlangen><en> Jesus does not ask us to give up living, but to accept a newness and a fullness of life that only He can give.
<G-vec00272-001-s726><ask.verlangen><de> Jesus verlangt nicht, auf das Leben zu verzichten, sondern eine Neuheit und Fülle des Lebens anzunehmen, die nur Er geben kann.
<G-vec00272-001-s727><ask.verlangen><en> Anyway some of those asking for an account underline that they ask it only in case the commercial value of the pictures is high and therefore it is not a regular question.
<G-vec00272-001-s727><ask.verlangen><de> Nahezu alle Einrahmer, die eine Anzahlung verlangen, weisen jedoch darauf hin, daß eine Anzahlung nicht regulär und in allen Fällen verlangt wird, sondern nur, wenn der Handelswert der einzurahmenden Bilder nahezu Null ist.
<G-vec00272-001-s728><ask.verlangen><en> The Christian does not ask to be freed from the trials and sufferings that are a part of being in the world, but to remain always united to Christ, in the Church, and to offer in peace their own life, in the expectation of his coming, in the fullness of the Kingdom.
<G-vec00272-001-s728><ask.verlangen><de> Der Christ verlangt nicht, befreit zu werden von den Bedrängnissen und Leiden, die Teil des Seins in der Welt sind, sondern immer vereint in Christus, in der Kirche zu verbleiben und in Frieden das eigene Leben in Erwartung seines Kommens in der Fülle seines Reiches darzubringen.
<G-vec00272-001-s729><ask.verlangen><en> the court will itself send them to the other party if you apply for a child arrangements order, a specific issue or prohibited steps order unless you ask the court to return them to you so you can send them to the other party.
<G-vec00272-001-s729><ask.verlangen><de> das Gericht schickt ihn selbst an die anderen Parteien, wenn der Antrag auf eine Kinderregelungsverfügung, Verbotsverfügung oder eine spezifische Anordnung gestellt worden ist, es sei denn Sie haben verlangt, dass der Antrag ihnen zurückgeschickt wird, damit Sie ihn zustellen können.
<G-vec00272-001-s730><ask.verlangen><en> This means that if you let someone purchase something on your account, and they ask for their money back, your account will be banned for the requested refunds.
<G-vec00272-001-s730><ask.verlangen><de> Dies bedeutet dass wenn du jemand anderen mit deinem Konto Dinge kaufen lässt, und dieser sein Geld zurück verlangt, wird dein Konto für die verlangten Rückerstattungen gesperrt.
<G-vec00272-001-s731><ask.verlangen><en> God does not ask of us anything that he himself has not first given us. “We love because he first has loved us” (1 Jn 4:19).
<G-vec00272-001-s731><ask.verlangen><de> Gott verlangt nichts von uns, das er uns nicht schon vorher geschenkt hätte: „Wir wollen lieben, weil er uns zuerst geliebt hat“ (1Joh 4,19).
<G-vec00272-001-s732><ask.verlangen><en> It doesn't ask to know, only there's the old habit.
<G-vec00272-001-s732><ask.verlangen><de> Er verlangt nicht zu wissen, doch er hat noch die alte Gewohnheit.
<G-vec00272-001-s733><ask.verlangen><en> He was a bit strict - strict in the sense that he has a lot to ask, the workplace.
<G-vec00272-001-s733><ask.verlangen><de> Er war ein bisschen streng - streng in dem Sinn, dass er viel verlangt hat, arbeitsmäßig.
<G-vec00272-001-s734><ask.verlangen><en> Please note that Citadines Arnulfpark Munich may ask for a security deposit on arrival.
<G-vec00272-001-s734><ask.verlangen><de> Bitte beachten Sie, dass das Citadines Arnulfpark Munich bei Anreise eventuell eine Schadenskaution verlangt.
<G-vec00272-001-s735><ask.verlangen><en> This is an additional safety measure that you will not find in any directives, but which is not too much to ask of a responsible road user.
<G-vec00272-001-s735><ask.verlangen><de> Dies ist eine zusätzliche Sicherheitsmaßnahme, die in keiner Richtlinie zu finden ist, aber für einen verantwortungsvollen Teilnehmer am Straßenverkehr nicht zu viel verlangt ist.
<G-vec00272-001-s736><ask.verlangen><en> From 1771 there are data available that the Eger Jesuit Pharmacy, namely Monk Jakab Neussel, had not handed over the recipe even to the Kassa Jesuit Druggist's, it was vain for them to ask for.
<G-vec00272-001-s736><ask.verlangen><de> Aus dem Jahre 1771 stehen uns Angaben zur Verfügung, daß die Jesuitische Apotheke in Erlau, namentlich Bruder Jakab Neussel, hat nicht einmal der jesuistischen Apotheke in Karschau das Rezept übergeben, man hat es von ihm vergeblich verlangt.
<G-vec00272-001-s737><ask.verlangen><en> At the first sign of a threat, it will ask for multi-factor authentication, and depending on the threat level it can even block user access and wipe data from a machine.
<G-vec00272-001-s737><ask.verlangen><de> Beim ersten Anzeichen einer Bedrohung verlangt es nach einer Multi-Faktor-Authentifizierung und kann abhängig von der Bedrohungsstufe sogar den Nutzerzugriff blockieren und Daten von einem Gerät löschen.
<G-vec00272-001-s738><ask.verlangen><en> Jesus does not ask for refined invocations, but rather, the whole of human existence, with its most concrete and mundane problems, can become prayer.
<G-vec00272-001-s738><ask.verlangen><de> Jesus verlangt keine raffinierten Anrufungen, sondern das ganze menschliche Leben, mit seinen ganz konkreten und alltäglichen Problemen kann zum Gebet werden.
<G-vec00272-001-s739><ask.verlangen><en> If the expressions of love are solicited, asked for, then you do not really know that they would be there if you did not ask for them.
<G-vec00272-001-s739><ask.verlangen><de> Wenn Sie Liebesbeweise herausgefordert, nach ihnen verlangt haben, so wissen Sie nicht, ob sie auch dann da wären, wenn Sie nicht nach ihnen verlangt hätten.
<G-vec00272-001-s740><ask.verlangen><en> They are required to keep your personal information confidential and may not use it other than as we ask them to and always in accordance with this privacy policy.
<G-vec00272-001-s740><ask.verlangen><de> Sie müssen Ihre personenbezogenen Daten vertraulich behandeln und dürfen sie zu nichts Anderem verwenden, als wie von uns verlangt, und immer im Einklang mit dieser Datenschutzrichtlinie.
<G-vec00384-001-s722><ask.verlangen><en> You should be sceptical if they already ask to be paid for this service.
<G-vec00384-001-s722><ask.verlangen><de> Verlangt er dafür bereits ein Honorar, sollte Sie das hellhörig machen.
<G-vec00384-001-s723><ask.verlangen><en> It does not ask for small personal satisfactions, but finds its satisfaction in the growth of the Truth within the being; what it seeks and finds is not any indulgence of a vital and physical claim, but the true nearness which consists in the constant presence of the Divine in the heart and the rule of the Divine in all the Nature.
<G-vec00384-001-s723><ask.verlangen><de> Sie verlangt nicht nach armseliger persönlicher Befriedigung, sondern findet ihre Befriedigung, wenn die Wahrheit im Inneren des [menschlichen] Wesens wächst; was sie sucht und findet, ist nicht Nachsicht gegenüber einer vitalen und physischen Forderung, sondern die wahre Nähe, die aus der immerwährenden Gegenwart des Göttlichen im Herzen sowie der Herrschaft des Göttlichen in der ganzen menschlichen Natur besteht.
<G-vec00384-001-s724><ask.verlangen><en> I thought that I would see these twitter feeds by their location, like on a map, but I suppose that's a bit too much to ask for (also it might be creepy).
<G-vec00384-001-s724><ask.verlangen><de> Ich dachte, dass ich sehen würde, diese Twitter-Feeds durch ihre Lage, wie auf einer Karte, aber ich vermute, das ist ein bisschen zu viel verlangt (auch könnte es gruselig sein).
<G-vec00384-001-s725><ask.verlangen><en> After examination begins, the PTO may issue something called an office action, which usually ask for explanations, raise questions, or request further information.
<G-vec00384-001-s725><ask.verlangen><de> "Nach dem Beginn der Prüfung erteilt das USPTO dem Anmelder üblicherweise einen Prüfungsbescheid (,,Office Action""), welcher normalerweise Formmängel und offensichtliche Patentierungshindernisse mitteilt, Erklärungen verlangt, Fragen erhebt oder um weitere Informationen ersucht."
<G-vec00384-001-s726><ask.verlangen><en> Jesus does not ask us to give up living, but to accept a newness and a fullness of life that only He can give.
<G-vec00384-001-s726><ask.verlangen><de> Jesus verlangt nicht, auf das Leben zu verzichten, sondern eine Neuheit und Fülle des Lebens anzunehmen, die nur Er geben kann.
<G-vec00384-001-s727><ask.verlangen><en> Anyway some of those asking for an account underline that they ask it only in case the commercial value of the pictures is high and therefore it is not a regular question.
<G-vec00384-001-s727><ask.verlangen><de> Nahezu alle Einrahmer, die eine Anzahlung verlangen, weisen jedoch darauf hin, daß eine Anzahlung nicht regulär und in allen Fällen verlangt wird, sondern nur, wenn der Handelswert der einzurahmenden Bilder nahezu Null ist.
<G-vec00384-001-s728><ask.verlangen><en> The Christian does not ask to be freed from the trials and sufferings that are a part of being in the world, but to remain always united to Christ, in the Church, and to offer in peace their own life, in the expectation of his coming, in the fullness of the Kingdom.
<G-vec00384-001-s728><ask.verlangen><de> Der Christ verlangt nicht, befreit zu werden von den Bedrängnissen und Leiden, die Teil des Seins in der Welt sind, sondern immer vereint in Christus, in der Kirche zu verbleiben und in Frieden das eigene Leben in Erwartung seines Kommens in der Fülle seines Reiches darzubringen.
<G-vec00384-001-s729><ask.verlangen><en> the court will itself send them to the other party if you apply for a child arrangements order, a specific issue or prohibited steps order unless you ask the court to return them to you so you can send them to the other party.
<G-vec00384-001-s729><ask.verlangen><de> das Gericht schickt ihn selbst an die anderen Parteien, wenn der Antrag auf eine Kinderregelungsverfügung, Verbotsverfügung oder eine spezifische Anordnung gestellt worden ist, es sei denn Sie haben verlangt, dass der Antrag ihnen zurückgeschickt wird, damit Sie ihn zustellen können.
<G-vec00384-001-s730><ask.verlangen><en> This means that if you let someone purchase something on your account, and they ask for their money back, your account will be banned for the requested refunds.
<G-vec00384-001-s730><ask.verlangen><de> Dies bedeutet dass wenn du jemand anderen mit deinem Konto Dinge kaufen lässt, und dieser sein Geld zurück verlangt, wird dein Konto für die verlangten Rückerstattungen gesperrt.
<G-vec00384-001-s731><ask.verlangen><en> God does not ask of us anything that he himself has not first given us. “We love because he first has loved us” (1 Jn 4:19).
<G-vec00384-001-s731><ask.verlangen><de> Gott verlangt nichts von uns, das er uns nicht schon vorher geschenkt hätte: „Wir wollen lieben, weil er uns zuerst geliebt hat“ (1Joh 4,19).
<G-vec00384-001-s732><ask.verlangen><en> It doesn't ask to know, only there's the old habit.
<G-vec00384-001-s732><ask.verlangen><de> Er verlangt nicht zu wissen, doch er hat noch die alte Gewohnheit.
<G-vec00384-001-s733><ask.verlangen><en> He was a bit strict - strict in the sense that he has a lot to ask, the workplace.
<G-vec00384-001-s733><ask.verlangen><de> Er war ein bisschen streng - streng in dem Sinn, dass er viel verlangt hat, arbeitsmäßig.
<G-vec00384-001-s734><ask.verlangen><en> Please note that Citadines Arnulfpark Munich may ask for a security deposit on arrival.
<G-vec00384-001-s734><ask.verlangen><de> Bitte beachten Sie, dass das Citadines Arnulfpark Munich bei Anreise eventuell eine Schadenskaution verlangt.
<G-vec00384-001-s735><ask.verlangen><en> This is an additional safety measure that you will not find in any directives, but which is not too much to ask of a responsible road user.
<G-vec00384-001-s735><ask.verlangen><de> Dies ist eine zusätzliche Sicherheitsmaßnahme, die in keiner Richtlinie zu finden ist, aber für einen verantwortungsvollen Teilnehmer am Straßenverkehr nicht zu viel verlangt ist.
<G-vec00384-001-s736><ask.verlangen><en> From 1771 there are data available that the Eger Jesuit Pharmacy, namely Monk Jakab Neussel, had not handed over the recipe even to the Kassa Jesuit Druggist's, it was vain for them to ask for.
<G-vec00384-001-s736><ask.verlangen><de> Aus dem Jahre 1771 stehen uns Angaben zur Verfügung, daß die Jesuitische Apotheke in Erlau, namentlich Bruder Jakab Neussel, hat nicht einmal der jesuistischen Apotheke in Karschau das Rezept übergeben, man hat es von ihm vergeblich verlangt.
<G-vec00384-001-s737><ask.verlangen><en> At the first sign of a threat, it will ask for multi-factor authentication, and depending on the threat level it can even block user access and wipe data from a machine.
<G-vec00384-001-s737><ask.verlangen><de> Beim ersten Anzeichen einer Bedrohung verlangt es nach einer Multi-Faktor-Authentifizierung und kann abhängig von der Bedrohungsstufe sogar den Nutzerzugriff blockieren und Daten von einem Gerät löschen.
<G-vec00384-001-s738><ask.verlangen><en> Jesus does not ask for refined invocations, but rather, the whole of human existence, with its most concrete and mundane problems, can become prayer.
<G-vec00384-001-s738><ask.verlangen><de> Jesus verlangt keine raffinierten Anrufungen, sondern das ganze menschliche Leben, mit seinen ganz konkreten und alltäglichen Problemen kann zum Gebet werden.
<G-vec00384-001-s739><ask.verlangen><en> If the expressions of love are solicited, asked for, then you do not really know that they would be there if you did not ask for them.
<G-vec00384-001-s739><ask.verlangen><de> Wenn Sie Liebesbeweise herausgefordert, nach ihnen verlangt haben, so wissen Sie nicht, ob sie auch dann da wären, wenn Sie nicht nach ihnen verlangt hätten.
<G-vec00384-001-s740><ask.verlangen><en> They are required to keep your personal information confidential and may not use it other than as we ask them to and always in accordance with this privacy policy.
<G-vec00384-001-s740><ask.verlangen><de> Sie müssen Ihre personenbezogenen Daten vertraulich behandeln und dürfen sie zu nichts Anderem verwenden, als wie von uns verlangt, und immer im Einklang mit dieser Datenschutzrichtlinie.
