<G-vec00214-002-s048><dominate.beherrschen><en> The 'Like' button appears almost everywhere on the web these days, and Facebook continues to dominate the social space.
<G-vec00214-002-s048><dominate.beherrschen><de> Der „Gefällt mir „ Knopf erscheint heutzutage auf fast allen Webseiten, und Facebook beherrscht immer noch die sozialen Raum.
<G-vec00214-002-s049><dominate.beherrschen><en> Become the most scientifically advanced civilization, dominate through sheer military power or become the foremost destination for the cultural arts;
<G-vec00214-002-s049><dominate.beherrschen><de> Werden Sie zur wissenschaftlich fortschrittlichsten Zivilisation, die von militärischer Macht beherrscht wird, oder zum wichtigsten Ziel der kulturellen Künste.
<G-vec00214-002-s050><dominate.beherrschen><en> Your bourgeoisie counted on you, on your endurance and your productive power, to win a place for imperialism, to dominate the industrial and agricultural basis of Europe.
<G-vec00214-002-s050><dominate.beherrschen><de> Eure Bourgeoisie zhlt auf Euch, auf Euer Durchhaltevermgen und auf Eure produktive Kraft, um einen Raum des Imperialismus einzunehmen, der das industrielle und landwirtschaftliche Zentrum Europas beherrscht.
<G-vec00214-002-s051><dominate.beherrschen><en> This somewhat banal practice, which is also an indispensable ritual at any exhibition opening, is suddenly invested with poignancy and discloses, ever so subtly, the extent to which men dominate our social and administrative fabric.
<G-vec00214-002-s051><dominate.beherrschen><de> Diese fast banale Vorgehensweise, die auch bei Ausstellungseröffnungen zum unabdingbaren Teil des Rituals gehört, bekommt plötzlich Brisanz und deckt in subtiler Art und Weise auf, wie sehr der männliche Teil der Bevölkerung die gesellschaftliche und administrative Matrix beherrscht.
<G-vec00214-002-s052><dominate.beherrschen><en> It points out that five major conflicts dominate the debate on the strategic conception of the regional development policy.
<G-vec00214-002-s052><dominate.beherrschen><de> Es wird gezeigt, dass die Debatte über die strategische Konzeption der regionalen Entwicklungspolitik von fünf großen Konflikten beherrscht wird.
<G-vec00214-002-s053><dominate.beherrschen><en> There’s nothing hotter than having a daddy dominate you and you responding “yes sir”.
<G-vec00214-002-s053><dominate.beherrschen><de> Es gibt nichts Schöneres als einen Papa zu haben, der Sie beherrscht und Sie antworten mit "Ja, Sir".
<G-vec00214-002-s054><dominate.beherrschen><en> If this axis becomes particularly polarised, the split-off side can become so powerful that it can start to dominate our lives.
<G-vec00214-002-s054><dominate.beherrschen><de> Wird diese Achse besonders stark polarisiert, so kann die abgespaltene Seite so mächtig werden, dass sie allmählich unser ganzes Leben beherrscht.
<G-vec00214-002-s055><dominate.beherrschen><en> With her naked ass she dominate him and sit in different positions on his face.
<G-vec00214-002-s055><dominate.beherrschen><de> Mit ihrem nackten Arsch beherrscht sie ihn und sitzt in verschiedenen Positionen auf seinem Gesicht.
<G-vec00214-002-s056><dominate.beherrschen><en> Checks dominate fashion this autumn.
<G-vec00214-002-s056><dominate.beherrschen><de> Karo beherrscht die Mode des kommenden Herbstes.
<G-vec00214-002-s057><dominate.bestimmen><en> Shades in the fumo family, light to medium browns, powdery pastels and black and white dominate the season’s palate.
<G-vec00214-002-s057><dominate.bestimmen><de> Töne der Fumo-Familie, helle bis mittlere Brauntöne, pudrige Pastelltöne sowie schwarz und weiß bestimmen das Farbbild.
<G-vec00214-002-s058><dominate.bestimmen><en> Crises in the eurozone and the EU, the rise of nationalism and populism, the migration crisis, clientelism and identity politics, the increasing divides of north-south and east-west and the new mistrust of democratic institutions dominate debates and fuel Europeans’ fears.
<G-vec00214-002-s058><dominate.bestimmen><de> Die Krisen in der Eurozone und der EU, der Aufstieg von Nationalismus und Populismus, die Migrationskrise, Klientel- und Identitätspolitik, die sich verstärkenden Spaltungen in Nord-Süd sowie Ost-West und das neue Misstrauen gegenüber demokratischen Institutionen bestimmen die Debatten und befeuern die Ängste der EuropäerInnen.
<G-vec00214-002-s059><dominate.bestimmen><en> In our digital world, a wealth of ideas and the speed of work dominate business procedures; the logical result is we produce individual, highly modern fabrication cells with robots and automatic feeders for an ever increasing number of clients.
<G-vec00214-002-s059><dominate.bestimmen><de> In unserer digitalen Welt bestimmen Ideenreichtum und Arbeitsgeschwindigkeit das Geschäft, deshalb stellen wir für immer mehr Kunden individuelle, hochmoderne Fertigungszellen mit Robotern und automatischer Zuführung her.
<G-vec00214-002-s060><dominate.bestimmen><en> Three issues dominate political debate in the US and will continue to do so for some time: the corona crisis, the anti-racist uprising, and the presidential and congressional elections scheduled for this autumn.
<G-vec00214-002-s060><dominate.bestimmen><de> Brennpunkt USA Drei Themen bestimmen gerade die politische Debatte in den USA: die Coronakrise, das Aufbegehren gegen Rassismus und die Präsidentschafts- und Kongresswahlen.
<G-vec00214-002-s061><dominate.bestimmen><en> This part of the exhibition deals with the new start for motorisation in the ten years after 1945. Initially, reconstruction is restricted to two-wheelers, as bicycles (with and without auxiliary engine) and mopeds dominate the streetscape.
<G-vec00214-002-s061><dominate.bestimmen><de> Dieser Teil der Ausstellung thematisiert den Neuanfang der Motorisierung im ersten Nachkriegsjahrzehnt: Die Motorisierung bleibt zunächst überwiegend zweirädrig, Fahrräder mit und ohne Hilfsmotor und Mopeds bestimmen das Straßenbild.
<G-vec00214-002-s062><dominate.bestimmen><en> Three facets have been identified: technology has tended to lead science, and commercial interests, with practically no public accountability, tend to dominate;
<G-vec00214-002-s062><dominate.bestimmen><de> Drei Folgerungen lassen sich ziehen: Die Technologie neigt dazu, die Wissenschaft und die kommerziellen Interessen zu bestimmen, die praktisch keiner öffentlichen Rechenschaftspflicht unterliegen.
<G-vec00214-002-s063><dominate.bestimmen><en> Wintery pastels, warm shades of stone and beige as well as classic dark blues, reds and black dominate the palette.
<G-vec00214-002-s063><dominate.bestimmen><de> Winterliche Pastells, warme Stein- und Beigetöne aber auch klassisches Dunkelblau, Rot und Schwarz bestimmen die Farbpalette.
<G-vec00214-002-s064><dominate.bestimmen><en> With their 3D design, the crystalline structures of the headlights, tail lights and other features dominate the sophisticated character that is defined by modern technology and a particular degree of refinement.
<G-vec00214-002-s064><dominate.bestimmen><de> Die kristallinen Strukturen bei den Scheinwerfern, Heckleuchten und weiteren Details bestimmen mit ihrer Dreidimensionalität den hochwertigen, von moderner Technologie und besonderer Raffinesse geprägten Charakter.
<G-vec00214-002-s065><dominate.bestimmen><en> The phone app did not change compared to the Galaxy S5: Large pictures and rectangular buttons dominate the picture and remind us of the current Windows design language.
<G-vec00214-002-s065><dominate.bestimmen><de> Die Telefonapp hat sich im Vergleich zum Galaxy S5 nicht verändert: Große Bilder und viereckige Tasten bestimmen das Bild und erinnern an die aktuelle Windows-Designsprache.
<G-vec00214-002-s066><dominate.bestimmen><en> That said, the prerequisites for creating such a public sphere are certainly in place given that European issues increasingly dominate agendas and headlines.
<G-vec00214-002-s066><dominate.bestimmen><de> Gleichzeitig sind die Voraussetzungen für das Entstehen einer solchen Öffentlichkeit durchaus vorhanden: Zunehmend bestimmen europäische Themen die Tagesordnungen und Schlagzeilen.
<G-vec00214-002-s067><dominate.bestimmen><en> More and more buildings dominate the landscape, large warehouses and industrial complexes are becoming more common.
<G-vec00214-002-s067><dominate.bestimmen><de> Mehr und mehr Gebäude bestimmen das Landschaftsbild, große Lagerhallen und Industriekomplexe werden häufiger.
<G-vec00214-002-s068><dominate.bestimmen><en> Vivid and bright colors dominate the picture.
<G-vec00214-002-s068><dominate.bestimmen><de> Lebendige und leuchtende Farben bestimmen das Bild.
<G-vec00214-002-s069><dominate.bestimmen><en> Stomping rhythms dominate the start of the powerful tune The Shattered Fortress, which integrates slight oriental flair.
<G-vec00214-002-s069><dominate.bestimmen><de> Stampfende Rhythmen bestimmen zu Beginn das kraftvolle The Shattered Fortress, das auch leicht orientalisches Flair mit einfließen lässt.
<G-vec00214-002-s070><dominate.bestimmen><en> Narrow, often dirt lanes invite you for a walk or to hike, atmospheric old houses and chapels, huge orchards and small farms dominate the landscape.
<G-vec00214-002-s070><dominate.bestimmen><de> Kleine, oft unbefestigte Gassen laden zum Spazieren und Wandern ein, stimmungsvolle alte Häuser, riesige Plantagen und kleine Landwirtschaften bestimmen das Bild.
<G-vec00214-002-s071><dominate.bestimmen><en> The ergonomic handles dominate the clear and simple design of the draft.
<G-vec00214-002-s071><dominate.bestimmen><de> Die ergonomischen Grifföffnungen bestimmen die klare, schlichte Formensprache des Entwurfs.
<G-vec00214-002-s072><dominate.bestimmen><en> Passion and pathos dominate the mighty Adagio, marked “Feierlich langsam; doch nicht schleppend” (Solemn and slow, but not dragging).
<G-vec00214-002-s072><dominate.bestimmen><de> Ob man’s mag oder nicht: Passion und Pathos bestimmen das gewaltige Adagio mit der Spielanweisung »Feierlich langsam; doch nicht schleppend«.
<G-vec00214-002-s073><dominate.bestimmen><en> In the south, along the Syrian and Iraqi border, the dry steppes of the Mesopotamian plain dominate the landscape.
<G-vec00214-002-s073><dominate.bestimmen><de> Im Süden, entlang der syrischen und irakischen Grenze bestimmen die trockenen Steppenlandschaften der mesopotamischen Ebene das Landschaftsbild.
<G-vec00214-002-s074><dominate.bestimmen><en> In Rheydt, where the second centre for shopping is to be found, specialist shops and department stores dominate the scene, not only in Farm Shopping
<G-vec00214-002-s074><dominate.bestimmen><de> Im Stadtteil Rheydt, in dem sich das zweite Einkaufszentrum befindet, bestimmen nicht nur auf der Haupt- und Stresemannstraße Fachgeschäfte und Kaufhäuser das Bild.
<G-vec00214-002-s075><dominate.bestimmen><en> Wild graphical or animal patterns dominate the scene.
<G-vec00214-002-s075><dominate.bestimmen><de> Wilde grafische oder tierische Muster bestimmen das Bild.
<G-vec00214-002-s112><dominate.dominieren><en> Because illicit, self-centered love invaded the first family, selfishness and greed have continued to dominate human history from the individual to the family, society, nation, and world.
<G-vec00214-002-s112><dominate.dominieren><de> Da unerlaubte, selbstbezogene Liebe in die erste Familie eingedrungen ist, haben Selbstsucht und Habgier die menschliche Geschichte ununterbrochen dominiert, angefangen vom Individuum bis hin zur Familie, Gesellschaft, Nation und Welt.
<G-vec00214-002-s113><dominate.dominieren><en> Once again, the endless straight lines surrounded by grain fields will dominate the stage.
<G-vec00214-002-s113><dominate.dominieren><de> Die heutige Tageswanderung wird erneut von den endlosen, von Getreide umgebenden Geraden dominiert.
<G-vec00214-002-s114><dominate.dominieren><en> "We are the 99 percent," states one of the main slogans of the global Occupy movement. It is meant to express that a small minority from the financial sector and the moneyed aristocracy dominate over the rest of the global populace.
<G-vec00214-002-s114><dominate.dominieren><de> "Wir sind 99 Prozent", lautet einer der zentralen Slogans der weltweiten Occupy-Bewegung - er soll ausdrücken, dass eine kleine Minderheit aus Finanzwirtschaft und Geldadel den großen Rest der Bevölkerung dominiert.
<G-vec00214-002-s115><dominate.dominieren><en> Impressive coconut palms dominate the local flora all over the island, but Phuket is the home for many other wonderful palm species, too.
<G-vec00214-002-s115><dominate.dominieren><de> Die flächendeckende Flora wird von beeindruckenden Kokospalmen dominiert, aber auch andere schönen Palmenarten fühlen sich auf Phuket zu Hause.
<G-vec00214-002-s116><dominate.dominieren><en> Ernst Moser (Teamchef Phoenix Racing): “We didn’t dominate the race but experienced a duel.
<G-vec00214-002-s116><dominate.dominieren><de> Ernst Moser (Teamchef Phoenix Racing): „Wir haben das Rennen nicht dominiert, sondern einen Zweikampf erlebt.
<G-vec00214-002-s117><dominate.dominieren><en> iQIYI is still showing aggressive growth, YouTube increases support for creators, and Tinder continues to dominate as it explores new features.
<G-vec00214-002-s117><dominate.dominieren><de> iQIYI wächst nach wie vor aggressiv, YouTube verbessert Unterstützung für Schöpfer von Inhalten, und Tinder dominiert weiterhin mit neuen Features.
<G-vec00214-002-s118><dominate.dominieren><en> "Whereas Modernism was still a serious (grown-up) matter, the (childish) urge to play has since come to dominate things exclusively.
<G-vec00214-002-s118><dominate.dominieren><de> "Während es bei der Moderne noch ernsthaft (erwachsen) zur Sache ging, dominiert inzwischen ausschließlich der (kindliche) Spieltrieb.
<G-vec00214-002-s119><dominate.dominieren><en> A small number of major state-owned commercial banks still dominate Vietnam’s banking sector.
<G-vec00214-002-s119><dominate.dominieren><de> Eine kleine Anzahl großer staatseigener Geschäftsbanken dominiert immer noch den vietnamesischen Bankensektor.
<G-vec00214-002-s120><dominate.dominieren><en> Wheat Continues to Dominate Fertilizer Market
<G-vec00214-002-s120><dominate.dominieren><de> Weizen dominiert weiterhin den Gesamtmarkt.
<G-vec00214-002-s121><dominate.dominieren><en> Don’t allow the loudest voices to dominate meetings
<G-vec00214-002-s121><dominate.dominieren><de> Lassen Sie nicht zu, dass Besprechungen von den lautesten Stimmen dominiert werden.
<G-vec00214-002-s122><dominate.dominieren><en> 11.09.2008 - This is for those of you who enjoy seeing a larger black woman thoroughly dominate a smaller white one.
<G-vec00214-002-s122><dominate.dominieren><de> Dieser Titel ist für all diejenigen unter Euch, die es lieben, dabei zuzusehen, wenn eine große schwarze Frau eine kleinere weiße dominiert.
<G-vec00214-002-s123><dominate.dominieren><en> The customer, whose personality the eyewear is supposed to underline rather than dominate, is at the centre of all design considerations.
<G-vec00214-002-s123><dominate.dominieren><de> Im Vordergrund aller Designüberlegungen steht der Brillenträger, dessen Persönlichkeit durch die Brille unterstrichen und nicht dominiert werden soll.
<G-vec00214-002-s124><dominate.dominieren><en> Steep slopes and precipitous rocky cliffs dominate in the middle and higher zones respectively.
<G-vec00214-002-s124><dominate.dominieren><de> Steile Hänge und steile Felsklippen dominiert in den mittleren und höheren Zonen jeweils.
<G-vec00214-002-s125><dominate.dominieren><en> SSG’s top-laner easily handled C9’s Impact in all three games of their short series against Cloud9, surprising many NA fans who had seen Impact dominate the domestic competition leading up to Worlds.
<G-vec00214-002-s125><dominate.dominieren><de> SSGs Top-Laner hatte mit Impact von C9 in allen drei Spielen der kurzen Serie leichtes Spiel, was viele NA-Fans überraschte, da Impact die heimische Liga bis zu Weltmeisterschaft dominiert hatte.
<G-vec00214-002-s126><dominate.dominieren><en> The intellect does not dominate, the material does not put pressure on us.
<G-vec00214-002-s126><dominate.dominieren><de> Der Geist dominiert nicht, die Materie setzt nicht unter Druck.
<G-vec00214-002-s127><dominate.dominieren><en> Like gin, however, rum makes an excellent cocktail ingredient because of its "legs": the flavor will persist, but not dominate in a mix.
<G-vec00214-002-s127><dominate.dominieren><de> Wie Gin eignet sich Rum jedoch auch hervorragend als Cocktailzutat, da sich sein Aroma lange hält, eine Mischung jedoch nicht dominiert.
<G-vec00214-002-s128><dominate.dominieren><en> Its 620 hp (456 kW) and light construction make this special car a real racer that will dominate all its peers.
<G-vec00214-002-s128><dominate.dominieren><de> 620 PS (456 kW) und konsequenter Leichtbau machen aus einem besonderen Fahrzeug einen echten Rennwagen, der auf allen Straßen mit seinen Siegergenen dominiert.
<G-vec00214-002-s129><dominate.dominieren><en> Allover metallic surfaces, in matte, neutral silver dominate the exterior; only the lightly rubber-coated underside for better grip, the matte display bezel with a protruding edge and hinge, and the keys are black.
<G-vec00214-002-s129><dominate.dominieren><de> Dominiert wird das Äußere durch einheitliche metallische Oberflächen in mattem, neutralem Silber, schwarz sind nur die für bessere Griffigkeit leicht gummierte Unterseite, der matte Bildschirmrahmen mit erhabenem Rand und Scharnier sowie die Tasten.
<G-vec00214-002-s130><dominate.dominieren><en> Dominate the Alliance War battlefield and become Emperor of Tamriel.
<G-vec00214-002-s130><dominate.dominieren><de> Dominiert auf den Schlachtfeldern des Allianzkriegs und werdet Kaiser Tamriels.
<G-vec00214-002-s213><dominate.herrschen><en> The extremely powerful machines from the Boiler & Power series are able to overcome the demanding conditions which often dominate the boiler and power plant industry.
<G-vec00214-002-s213><dominate.herrschen><de> Die extrem starken Maschinen der Boiler & Power-Serie trotzen den anspruchsvollen Umgebungsbedingungen, die in der Kessel- und Kraftwerksindustrie häufig herrschen.
<G-vec00214-002-s214><dominate.herrschen><en> The book design is reserved and effective: As skimming through the thin pages, largely printed on newsprint, one senses the threat and the danger, which dominate this city.
<G-vec00214-002-s214><dominate.herrschen><de> Das Buchdesign ist zurückhaltend und wirkungsvoll: Beim Durchblättern der dünnen, größtenteils auf Zeitungspapier gedruckten Seiten spürt man geradezu die Bedrohung und die Gefahr, die in dieser Stadt herrschen.
<G-vec00214-002-s215><dominate.herrschen><en> As Trotsky once wrote, “Empiricism, and its foster brother, impressionism, dominate from top to bottom.”
<G-vec00214-002-s215><dominate.herrschen><de> Wie Trotzki einmal schrieb: „Empirismus und sein Stiefbruder Impressionismus herrschen überall vor“.
<G-vec00214-002-s216><dominate.herrschen><en> In Conan Exiles, we’re giving players the opportunity to experience the world of Conan the Barbarian and learn to survive, build and dominate their way to victory.
<G-vec00214-002-s216><dominate.herrschen><de> In Conan Exiles geben wir Spielern die Möglichkeit, die Welt von Conan dem Barbaren zu erkunden, um dort zu überleben, zu bauen und zu herrschen.
<G-vec00214-002-s217><dominate.herrschen><en> Precarious life and work situations dominate in the unfocussed margins. The osmotic skins of the econofilm can be found in the face of fractal approaches to most places: precarization is one of the principles that manages the force, the duty of derivatization, it is perhaps its most convincing incentive.
<G-vec00214-002-s217><dominate.herrschen><de> Prekäre Lebens- und Arbeitssituationen herrschen an den unscharfen Rändern, den osmotischen Häuten des Econofilms, die sich aber in der Ansicht fraktaler Annäherung an den meisten Stellen finden lassen: Prekarisierung ist eines der Prinzipien, die den Zwang, die Pflicht zur Derivatisierung steuern, managen, ist sein vielleicht überzeugendstes Incentive.
<G-vec00214-002-s218><dominate.herrschen><en> But it is enough to understand how and why it carries out these functions to find the practical evidence that whatever governments do is always motivated by the desire to dominate, and is always geared to defending, extending and perpetuating its privileges and those of the class of which it is both the representative and defender.
<G-vec00214-002-s218><dominate.herrschen><de> Wenn wir es aber genauer betrachten, wie und warum sie diese Aufgaben erledigt, so beweisen die Tatsachen, daß alles was die Regierung tut, nur darum und deswegen getan wird, um zu herrschen, um die Vorrechte -ihre eigenen und diejenigen der Klasse, die sie vertritt und verteidigt — aufrecht zu erhalten, zu vermehren und zu verewigen.
<G-vec00214-002-s219><dominate.herrschen><en> As already clarified in the principle of creation, man originally was to dominate even the angels, after having perfected himself by fulfilling his own portion of responsibility.
<G-vec00214-002-s219><dominate.herrschen><de> Wie bereits in den Prinzipien der Schöpfung erklärt, sollte der Mensch ursprünglich durch die Erfüllung seines Teils der Verantwortung Vollkommenheit erreichen und sogar über die Engel herrschen.
<G-vec00214-002-s220><dominate.herrschen><en> Just as God was qualified to dominate all men because He was the Creator, man had to have the creativity of God in order to be qualified as the dominator of all things.
<G-vec00214-002-s220><dominate.herrschen><de> Ebenso wie Gott, der Schöpfer, qualifiziert ist, über alle Menschen zu herrschen, so musste auch der Mensch göttliche Schöpferkraft besitzen, um die Qualifikation als Herr über die Schöpfung zu erlangen.
<G-vec00214-002-s221><dominate.herrschen><en> West winds dominate and high seas have to be expected.
<G-vec00214-002-s221><dominate.herrschen><de> Westwinde herrschen vor und man muss auch mit hohem Seegang rechnen.
<G-vec00214-002-s222><dominate.herrschen><en> 4 And I will deliver Egypt into the hand of cruel masters, and a strong king will dominate them, says the Lord, the God of hosts.
<G-vec00214-002-s222><dominate.herrschen><de> 4 Doch ich gebe die Ägypter in die Gewalt eines strengen Herrn, / ein harter König wird über sie herrschen - / Spruch Gottes, des Herrn der Heere.
<G-vec00214-002-s223><dominate.herrschen><en> If a victim develops certain abilities and emits massive material wishes, and if this person has the strength to dominate his neighbor, to subjugate him and perhaps enslave him, then he will be made an accomplice. For the accomplices ally with those of like mind again and again, in order to find more victims and raise, in turn, able victims to be accomplices.
<G-vec00214-002-s223><dominate.herrschen><de> Entwickelt ein Opfer entsprechende Fähigkeiten, sendet es massive materielle Wünsche aus und hat dieser Mensch die Kraft, über den Nächsten zu herrschen, ihn zu unterjochen und eventuell zu versklaven, dann wird er zu einem Helfershelfer gemacht; denn die Helfershelfer verbünden sich immer wieder mit Gleichgesinnten, um weitere Opfer zu finden und fähige Opfer wiederum zu Helfershelfern zu erheben.
<G-vec00214-002-s224><dominate.herrschen><en> Not to dominate but to witness with respect.
<G-vec00214-002-s224><dominate.herrschen><de> Nicht um zu herrschen, sondern um respektvoll Zeugnis zu geben.
<G-vec00214-002-s237><dominate.morgen><en> After mainly cloudless weather in the morning cloudy, but mainly dry weather will dominate for a time.
<G-vec00214-002-s237><dominate.morgen><de> Morgen Nach dem sonnigen Wetter vom Morgen gibt es graues, aber weitgehend trockenes Wetter.
<G-vec00214-002-s238><dominate.morgen><en> After partly sunny weather in the morning clouds with light rain will dominate for a time.
<G-vec00214-002-s238><dominate.morgen><de> Morgen Nach dem wechselnd bewölkten Wetter vom Morgen gibt es stark bewölktes Wetter mit leichtem Regen.
<G-vec00214-002-s239><dominate.morgen><en> After widely foggy weather with development of hoar frost in the morning sunny weather will dominate.
<G-vec00214-002-s239><dominate.morgen><de> Nach dem oft nebligen und trüben Wetter mit Reifbildung vom Morgen bringt der Tag wolkenloses Wetter.
<G-vec00214-002-s240><dominate.morgen><en> After sunny weather in the morning mostly cloudy weather will dominate for a time.
<G-vec00214-002-s240><dominate.morgen><de> Morgen Nach dem wolkenlosen Wetter vom Morgen gibt es teilweise bewölktes Wetter.
<G-vec00214-002-s241><dominate.morgen><en> After clouds with light snowfall in the morning variable cloudy, but mostly dry weather will dominate for a time.
<G-vec00214-002-s241><dominate.morgen><de> Morgen Nach dem bewölkten Wetter mit zeitweiligem Schneefall vom Morgen gibt es oft sonniges Wetter.
<G-vec00214-002-s242><dominate.morgen><en> After sunny weather in the morning widely overcast, but mainly dry weather will dominate for a time.
<G-vec00214-002-s242><dominate.morgen><de> Morgen Nach dem sehr sonnigen Wetter vom Morgen gibt es trübes, aber weitgehend trockenes Wetter.
<G-vec00214-002-s243><dominate.morgen><en> After sunny weather in the morning variable cloudy, but mostly dry weather will dominate for a time.
<G-vec00214-002-s243><dominate.morgen><de> Morgen Nach dem wolkenlosen Wetter vom Morgen gibt es teils stark bewölktes, aber meist trockenes Wetter.
<G-vec00214-002-s244><dominate.morgen><en> After clouds with local snowfall in the morning cloudless weather will dominate.
<G-vec00214-002-s244><dominate.morgen><de> Morgen Am Morgen ist es unbeständig mit zeitweiligem Schneefall.
<G-vec00214-002-s245><dominate.morgen><en> After clouds with local snowfall in the morning cloudy, but mainly dry weather will dominate for a time.
<G-vec00214-002-s245><dominate.morgen><de> Morgen Nach dem unbeständigen Wetter mit zeitweiligem Schneefall vom Morgen gibt es graues, aber weitgehend trockenes Wetter.
<G-vec00214-002-s246><dominate.morgen><en> After partly sunny weather in the morning clouds with light rain will dominate for a time.
<G-vec00214-002-s246><dominate.morgen><de> Morgen Nach dem sonnigen oder leicht bewölkten Wetter vom Morgen wird es stark bewölkt mit leichtem Regen.
<G-vec00214-002-s247><dominate.morgen><en> After clouds with light rain in the morning mostly cloudy weather will dominate for a time.
<G-vec00214-002-s247><dominate.morgen><de> Morgen Am Morgen ist es stark bewölkt mit leichtem Regen.
<G-vec00214-002-s248><dominate.morgen><en> After cloudy and rainy weather in the morning widely overcast, but mainly dry weather will dominate for a time.
<G-vec00214-002-s248><dominate.morgen><de> Morgen Nach dem leicht bewölkten Wetter vom Morgen wird es wechselnd bis stark bewölkt und verbreitet trocken.
<G-vec00214-002-s249><dominate.prägen><en> The gently curving course of the river Elbe in the south and vine-covered hills in the north still dominate the picture.
<G-vec00214-002-s249><dominate.prägen><de> Das sanft geschwungene Band der Elbe im Süden und rebenbedeckte Hänge im Norden prägen bis heute das Bild.
<G-vec00214-002-s250><dominate.prägen><en> The buildings along the railway line are largely preserved in its original state and dominate the landscape.
<G-vec00214-002-s250><dominate.prägen><de> Die Bauwerke an der Strecke sind häufig noch in ihrem Urzustand erhalten und prägen die Landschaft.
<G-vec00214-002-s251><dominate.prägen><en> The world is changing at a very fast pace – smartphones, apps and e-books dominate our everyday lives.
<G-vec00214-002-s251><dominate.prägen><de> Die Welt verändert sich rasend schnell – Smartphones, Apps und E-Books prägen unseren Alltag.
<G-vec00214-002-s252><dominate.prägen><en> Frequently changing ascents, with maximum values of up to 18 %, as well as magnificent views of the surrounding peaks, which extend far into the Dolomites, now dominate the next 11 mile long stretch of road up until the turning point at the Rifugio Bassano on the Monte Grappa at 5715 ft above sea level.
<G-vec00214-002-s252><dominate.prägen><de> Stark wechselnde Steigungen mit Spitzenwerten von bis zu 18 % sowie grandiose Aussichten zu den umliegenden Gipfeln bis weit in die Dolomiten, prägen nun die folgende 17 km lange Wegstrecke zum Wendepunkt beim Rifugio Bassano auf dem Monte Grappa in 1.742m Meereshöhe.
<G-vec00214-002-s253><dominate.prägen><en> At twelve, three, six and nine o'clock Arabic numerals dominate the appearance.
<G-vec00214-002-s253><dominate.prägen><de> Auf zwölf, drei, sechs und neun Uhr prägen arabische Ziffern das Erscheinungsbild.
<G-vec00214-002-s254><dominate.prägen><en> Location: between 22 degrees and 40 degrees east longitude and 45 degrees and 52 Geography: In the West the mountains of the Carpathian Mountains (up to 2000 m) dominate the landscape, on the southern peninsula of Crimea, the Crimean mountains (up to 1500 m).
<G-vec00214-002-s254><dominate.prägen><de> Lage: zwischen 22 Grad und 40 Grad östlicher Länge sowie 45 Grad und 52 Grad Schwarzmeerküste Geographie: Im Westen prägen die Berge der Karpaten (bis 2000 m) die Landschaft, auf der südlichen Halbinsel Krim das Krimgebirge (bis 1500 m).
<G-vec00214-002-s255><dominate.prägen><en> The highlight is a visit to the Renon's earth pyramids – mighty earth cones that dominate the landscape, and are considered the most beautiful of Europe in terms of shape.
<G-vec00214-002-s255><dominate.prägen><de> Das Highlight ist die Besichtigung der Rittner Erdpyramiden, mächtige Erdkegel die das Landschaftsbild prägen, und als die formschönsten Europas gelten.
<G-vec00214-002-s256><dominate.prägen><en> Narrow cobbled streets, small half-timbered houses, churches and old buildings dominate the picture of romantic medieval Rothenburg.
<G-vec00214-002-s256><dominate.prägen><de> Enge gepflasterte Gassen, kleine Fachwerkhäuser, Kirchen und alte Gemäuer prägen das romantische mittelalterliche Bild von Rothenburg.
<G-vec00214-002-s257><dominate.prägen><en> Numerous olive tree plantations dominate the area around Primosten.
<G-vec00214-002-s257><dominate.prägen><de> Zahlreiche Olivenbaum Plantagen prägen das Gebiet rund um Primosten.
<G-vec00214-002-s258><dominate.prägen><en> Future perspectives have a transcendent effect on reality, and consequently dominate the social space in which they are formulated.
<G-vec00214-002-s258><dominate.prägen><de> Zukünftige Perspektiven haben eine transzendierende Wirkung auf die Wirklichkeit und prägen infolgedessen den sozialen Raum in dem sie formuliert werden.
<G-vec00214-002-s259><dominate.prägen><en> Bright blue skies and many hours of sunshine dominate your holiday.
<G-vec00214-002-s259><dominate.prägen><de> Der tiefblaue Himmel und die vielen Sonnenstunden prägen Ihren Urlaub.
<G-vec00214-002-s260><dominate.prägen><en> Numerous Scandinavian businesses dominate the cityscape providing variety and making Flensburg a popular shopping destination between Hamburg and Copenhagen.
<G-vec00214-002-s260><dominate.prägen><de> Zahlreiche skandinavische Geschäfte prägen das Stadtbild, sorgen für Vielfalt und machen Flensburg zur gefragten Einkaufsstadt zwischen Hamburg und Kopenhagen.
<G-vec00214-002-s261><dominate.prägen><en> Vineyards and meadows dominate the landscape around the climatic spa Badenweiler.
<G-vec00214-002-s261><dominate.prägen><de> Rund um den Kurort Badenweiler prägen Weinberge und Wiesen die Landschaft.
<G-vec00214-002-s262><dominate.prägen><en> Your Maria dominate in the center of village at the sunny side of the valley.
<G-vec00214-002-s262><dominate.prägen><de> Bauernhöfe prägen den Ortskern auf der Sonnenseite des Tals.
<G-vec00214-002-s263><dominate.prägen><en> Personalised ring binders Ring binders dominate shelves at offices, and often also in private homes.
<G-vec00214-002-s263><dominate.prägen><de> Ringordner prägen das Interieur von österreichischen Büros, Amtsstuben, Geschäftsräumen oder privaten Regalen.
<G-vec00214-002-s264><dominate.prägen><en> Volos and its harbour dominate the surrounding coast, which you can use as a base for boating to nearby Evia and the Sporades Islands.
<G-vec00214-002-s264><dominate.prägen><de> Volos und der Hafen prägen die umliegende Küstenregion, die Sie als Basis für den Törn in die nahegelegene Euböda und die Sporadeninseln nutzen können.
<G-vec00214-002-s265><dominate.prägen><en> Their talks focus on two issues which will also dominate the rest of the German Foreign Minister’s visit to the United States: transatlantic relations and the situation in Ukraine.
<G-vec00214-002-s265><dominate.prägen><de> Im Mittelpunkt des Gesprächs stehen zwei Themen, die auch den weiteren USA-Besuch des deutschen Außenministers prägen werden: Das transatlantische Verhältnis und die Lage in der Ukraine.
<G-vec00214-002-s266><dominate.prägen><en> Beside harmoniously inserted new buildings, there are the very old houses that dominate the impression of the village's scenery, giving a hint of the classic characteristics of the region.
<G-vec00214-002-s266><dominate.prägen><de> Neben harmonisch eingefügte Neubauten finden sich in den Orten auch sehr oft die sehr alten Häuser, die das Landschaftsbild der Dörfer prägen und sehr viel von der klassischen Charakteristik der Region Kassandras durchblicken lassen.
<G-vec00214-002-s267><dominate.prägen><en> Large forests, long rows of hedges and 40 lakes dominate the sparsely populated landscape in the Duchy of Lauenburg.
<G-vec00214-002-s267><dominate.prägen><de> Radrundtouren Große Wälder, Heckenzüge und 40 Seen prägen die dünn besiedelte Landschaft im Herzogtum Lauenburg.
<G-vec00214-002-s268><dominate.regen><en> After clouds with local snowfall in the morning clouds with local rain will dominate for a time.
<G-vec00214-002-s268><dominate.regen><de> Nach dem wechselnd bis stark bewölkten Wetter mit ab und zu etwas Schnee vom Morgen gibt es wechselnd bis stark bewölktes Wetter mit ab und zu etwas Regen.
<G-vec00214-002-s269><dominate.regen><en> In the evening clouds with light snowfall will dominate.
<G-vec00214-002-s269><dominate.regen><de> Der Abend bringt bewölktes Wetter mit leichtem Regen.
<G-vec00214-002-s270><dominate.regen><en> In the early morning it will be cloudy, but mostly dry. Before noon clouds with local rain will dominate.
<G-vec00214-002-s270><dominate.regen><de> Nach dem meist bewölkten, aber trockenen Wetter vom Morgen wird es wechselhaft mit ab und zu etwas Regen.
<G-vec00214-002-s271><dominate.regen><en> Before noon fair weather with cloudy periods will dominate.
<G-vec00214-002-s271><dominate.regen><de> Am Abend überwiegt bewölktes Wetter mit leichtem Regen.
<G-vec00214-002-s272><dominate.regen><en> In the early morning it will be variable with isolated rain showers. Before noon clouds with local rain will dominate.
<G-vec00214-002-s272><dominate.regen><de> Nach dem wechselhaften Wetter mit ab und zu Schauern vom Morgen wird es wechselnd bis stark bewölkt mit ab und zu etwas Regen.
<G-vec00214-002-s273><dominate.regen><en> In the afternoon clouds with local snowfall will dominate.
<G-vec00214-002-s273><dominate.regen><de> Der Nachmittag wird stark bewölkt mit leichtem Regen.
<G-vec00214-002-s274><dominate.regen><en> In the afternoon clouds with light snowfall will dominate.
<G-vec00214-002-s274><dominate.regen><de> In der Nacht gibt es stark bewölktes Wetter mit leichtem Regen.
<G-vec00214-002-s275><dominate.regen><en> After fair weather with cloudy periods in the morning clouds with local rain will dominate for a time.
<G-vec00214-002-s275><dominate.regen><de> Nach dem zeitweise sonnigen Wetter vom Morgen gibt es wechselnd bis stark bewölktes Wetter mit ab und zu etwas Regen.
<G-vec00214-002-s276><dominate.regen><en> After widely overcast, but mainly dry weather in the morning fair weather with cloudy periods will dominate for a time.
<G-vec00214-002-s276><dominate.regen><de> Nach dem wechselnd bewölkten Wetter vom Morgen gibt es unbeständiges Wetter mit zeitweiligem Regen.
<G-vec00214-002-s277><dominate.regen><en> Before noon clouds with local snowfall will dominate.
<G-vec00214-002-s277><dominate.regen><de> Ab den Mittagsstunden überwiegt stark bewölktes Wetter mit leichtem Regen.
<G-vec00214-002-s356><dominate.überwiegen><en> In Phase I, early failures dominate.
<G-vec00214-002-s356><dominate.überwiegen><de> In Phase I überwiegen die Frühausfälle.
<G-vec00214-002-s357><dominate.überwiegen><en> Small deals dominate: Most deals with disclosed transaction volumes are smaller than EUR 10m and 57% of the deals belong to the category of early-stage financing transactions (accelerator, incubator, seed & angel transactions).
<G-vec00214-002-s357><dominate.überwiegen><de> Kleine Deals überwiegen: Die Mehrheit der Deals mit veröffentlichten Volumen bewegt sich im Bereich weit unter 10 Millionen Euro und 57% der Deals gehören zur Kategorie der Frühphasenfinanzierungen (Accelerator-, Incubator-, Seed- & Angel-Transaktionen).
<G-vec00214-002-s358><dominate.überwiegen><en> Due to the small dimensions, the bass is lacking in the sound and the highs and mids dominate.
<G-vec00214-002-s358><dominate.überwiegen><de> Beim Klang fehlt es wie so oft auf Grund der geringen Abmessungen an Bass, sodass die Höhen und Mitten überwiegen.
<G-vec00214-002-s359><dominate.überwiegen><en> At each stage there are some short and some long slopes to master, but overall the descents dominate. That is because you are starting in Tripoli at 600 m altitude and roll down to the sea and also the transfer to Epidauros takes you at 300 m altitude and again you roll down to the sea.
<G-vec00214-002-s359><dominate.überwiegen><de> Auf jeder Radetappe sind zwar auch immer wieder kurze und einzelne längere Steigungen zu meistern, doch insgesamt überwiegen die Abfahrten, da Sie einerseits in Tripolis auf 600 m Höhe starten und zum Meer hinabrollen und auch beim Transfer nach Epidauros auf 300 m Höhe gebracht werden und erneut zum Meer abwärts rollen.
<G-vec00214-002-s360><dominate.überwiegen><en> The interior was designed as the perfect place to welcome customers: reassuring shades of blue dominate, regular geometric patterns adorn the walls and the spaces are roomy, airy and linear, decorated with snow-white design objects and the unique concrete and wood floor.
<G-vec00214-002-s360><dominate.überwiegen><de> Das Interieur ist für einen perfekten Empfang des Kunden gedacht: die beruhigenden Farbtöne des Blau überwiegen, geometrische Muster von einer gewissen Regelmäßigkeit schmücken die Wände, weite, luftige und geradlinige Räume, die durch schneeweiße Design-Gegenstände und den originellen Boden aus Beton und Holz veredelt werden.
<G-vec00214-002-s361><dominate.überwiegen><en> It is striking that it is the nationalist and left-wing tendencies that dominate in all the political parties united in this movement.
<G-vec00214-002-s361><dominate.überwiegen><de> Auffällig ist, dass nationalistische und linke Tendenzen bei allen in dieser Bewegung vereinten Parteien überwiegen.
