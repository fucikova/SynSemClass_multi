<G-vec00060-001-s038><add.addieren><en> It's used to add contents of a diary or news by the owner (blogger).
<G-vec00060-001-s038><add.addieren><de> Es wird verwendet, um Inhalt eines Tagebuchs oder Nachrichten zu addieren vom Inhaber (blogger).
<G-vec00060-001-s039><add.addieren><en> Whether it’s a breakfast bar for serving food or additional prep space for cooking, ample kitchen counters add huge value; a feature you will see in all Deepblue SmartHouse homes.
<G-vec00060-001-s039><add.addieren><de> Ob es ein Frühstücksbar für dienende Nahrung oder zusätzlichen Vorbereitungsraum für das Kochen ist, addieren reichliche Küchenarbeitsplatten enormen Wert; eine Eigenschaft, die Sie in allen Häusern Deepblue SmartHouse sehen.
<G-vec00060-001-s040><add.addieren><en> Add up numbers before the time runs out.
<G-vec00060-001-s040><add.addieren><de> Addieren von Zahlen, bevor die Zeit abläuft.
<G-vec00060-001-s041><add.addieren><en> But take a good, long moment to check whether you need to add it to or subtract it from the time given by your precious timepiece to ascertain the true solar time.
<G-vec00060-001-s041><add.addieren><de> Nehmen Sie sich aber die nötige Zeit, um herauszufinden, ob man addieren oder subtrahieren muss, wenn man mit der Stundenanzeige des guten Stücks die wahre Sonnenzeit ausrechnen will.
<G-vec00060-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00060-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00060-001-s043><add.addieren><en> We also can add wood frame outside as clients request.
<G-vec00060-001-s043><add.addieren><de> Wir können hölzerne Rahmenaußenseite auch addieren wie Kundenantrag.
<G-vec00060-001-s044><add.addieren><en> Now we can add the velocity change in cell C3 to this value.
<G-vec00060-001-s044><add.addieren><de> Jetzt können wir den Geschwindigkeitswert in Zelle C3 zu diesem Wert addieren.
<G-vec00060-001-s045><add.addieren><en> 9, Option: outside baffle add the flap function, which made the cardboard orientation more exact, avoid to
<G-vec00060-001-s045><add.addieren><de> 9, Wahl: äußeres Leitblech addieren die Landeklappenfunktion, die die Papporientierung genauer machte, vermeiden, um zu vergeuden.
<G-vec00060-001-s046><add.addieren><en> We must never add, subtract or change the doctrine of Christ or to whom He gave authority to record His written word.
<G-vec00060-001-s046><add.addieren><de> Wir dürfen nie addieren, subtrahieren oder die Lehre von Christus oder zu denen er Vollmacht gab, seine geschriebene Wort aufzunehmen.
<G-vec00060-001-s047><add.addieren><en> 1 Due to rounding it is possible that individual figures presented in this press release may not add up exactly to the totals shown and that the nine-month figures listed may not follow from adding up the individual quarterly figures.
<G-vec00060-001-s047><add.addieren><de> 1 Aufgrund von Rundungen ist es möglich, dass sich einzelne Zahlen in dieser Pressemitteilung nicht genau zur angegebenen Summe addieren lassen und sich die Neunmonatszahlen nicht aus der Aufsummierung der einzelnen Quartalszahlen ergeben.
<G-vec00060-001-s048><add.addieren><en> "Please enter this formula =SUMIF(A2:A6,""*KTE*"",B2:B6) into a blank cell, and press Enter key, then all the numbers in column B where the corresponding cell in column A contains text “KTE” will add up."
<G-vec00060-001-s048><add.addieren><de> "Bitte geben Sie diese Formel ein = SUMIF (A2: A6 ""TEC * *"" B2: B6) in eine leere Zelle und drücken Sie Weiter Schlüssel, dann addieren sich alle Zahlen in Spalte B, wo die entsprechende Zelle in Spalte A den Text ""KTE"" enthält."
<G-vec00060-001-s049><add.addieren><en> On friday we must add 3 days to get next monday, on saturday 2 days are to be added and for all other weekdays the next day is the next working day.
<G-vec00060-001-s049><add.addieren><de> Am Freitag muss ich 3 Tage addieren, um auf den kommenden Montag zu kommen, am Samstag 2 Tage und an allen anderen Tagen ist der nächste Tag auch der nächste Arbeitstag.
<G-vec00060-001-s050><add.addieren><en> We offer 5 double bedrooms, each of which has the possibility to add up to 2 single beds.
<G-vec00060-001-s050><add.addieren><de> Wir bieten 5 Doppelzimmer, von denen jeder die Möglichkeit, 5 Einzelbetten zu addieren hat.
<G-vec00060-001-s051><add.addieren><en> The waste is generated when people are in too big a hurry to build more sites, add more products, and get more traffic to sites that can convert sometimes 1000% BETTER than they do now.
<G-vec00060-001-s051><add.addieren><de> Die Vergeudung wird erzeugt, wenn Leute in einer zu großen Hast sind, zum von von mehr Aufstellungsorten zu errichten, von von mehr Produkten zu addieren und mehr Verkehrs an Aufstellungsorte zu gelangen, die manchmal 1000% umwandeln können, das BESSER ist, als sie jetzt.
<G-vec00060-001-s052><add.addieren><en> • Bet per Line: Click this button to add or subtract from your wager per activated payline.
<G-vec00060-001-s052><add.addieren><de> • Zeileneinsatz: Klicken Sie auf diesen Button, um Ihren Einsatz pro aktivierter Gewinnlinie zu addieren oder abzuziehen.
<G-vec00060-001-s053><add.addieren><en> They automatically add 0.3 mm per year to this region, not because the sea is rising, but to compensate for an alleged isostatic increase in land.
<G-vec00060-001-s053><add.addieren><de> Sie addieren sich automatisch um 0,3 mm pro Jahr in dieser Region, nicht weil das Meer steigt, sondern um einen angeblichen isostatischen Anstieg des Landes auszugleichen.
<G-vec00060-001-s054><add.addieren><en> Many times an owner of an independent Detailing Shop will wish to add those items he/she believes their customers want.
<G-vec00060-001-s054><add.addieren><de> Viele Mal möchte ein Inhaber eines unabhängigen einzeln aufführengeschäftes jene Einzelteile addieren, die he/she glaubt, dass ihre Kunden wünschen.
<G-vec00060-001-s055><add.addieren><en> Unfortunately, we do a little bit of celebrating during this time of year and add up extra baggage when the New Year appears.
<G-vec00060-001-s055><add.addieren><de> Leider tun wir ein wenig vom Feiern während dieser Zeit des Jahres und addieren oben Extragepäck, wenn das neue Jahr erscheint.
<G-vec00060-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
<G-vec00060-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00407-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00407-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00407-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
<G-vec00407-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00060-001-s076><add.dazugeben><en> Add the coconut milk and blend with an immersion blender.
<G-vec00060-001-s076><add.dazugeben><de> Kokosmilch dazugeben und alles mit dem Pürierstab pürieren.
<G-vec00060-001-s077><add.dazugeben><en> Put a caramel thermometer inside the pot: add food coloring, cinnamon and cloves as soon as the temperature reaches 100 degrees.
<G-vec00060-001-s077><add.dazugeben><de> Dann einen Karamell-Thermometer in den Topf legen: die Lebensmittelfarbe, Zimt und Gewürznelken dazugeben, sobald die Temperatur auf 100° ist.
<G-vec00060-001-s078><add.dazugeben><en> Finally, add vinegar and garnish with the hard-boiled eggs.
<G-vec00060-001-s078><add.dazugeben><de> Zum Schluss Essig dazugeben und mit den hartgekochten Eiern garnieren.
<G-vec00060-001-s079><add.dazugeben><en> 13 'But if he should ever wish to redeem it, then he shall add one-fifth of it to your valuation.
<G-vec00060-001-s079><add.dazugeben><de> 13 Will es aber jemand unbedingt wieder auslösen, so soll er den fünften Teil deiner Schätzung dazugeben.
<G-vec00060-001-s080><add.dazugeben><en> Add Grappa Nonino Chardonnay in barriques, Amaro Nonino and ice.
<G-vec00060-001-s080><add.dazugeben><de> Grappa Nonino Monovitigno® Chardonnay 12 Monate in Barriques, Amaro Nonino und Eis dazugeben.
<G-vec00060-001-s081><add.dazugeben><en> Weigh the pulp and add equal amount of sugar.
<G-vec00060-001-s081><add.dazugeben><de> Die gleiche Menge an Zucker in einem Topf leicht erhitzen, Zitronensaft dazugeben.
<G-vec00060-001-s082><add.dazugeben><en> If you think the salsa is too spicy, add the avocado to the blender and mix again very well.
<G-vec00060-001-s082><add.dazugeben><de> Wem die Salsa zu scharf ist, der kann die Avocado dazugeben und die Sauce nochmals gut pürieren.
<G-vec00060-001-s083><add.dazugeben><en> Wash the potatoes and boil them in salted water in their skin. Meanwhile, brown the bacon with butter in a pan and, after a few minutes, add the chopped onion, turn off as soon as the onion is soft and transparent.
<G-vec00060-001-s083><add.dazugeben><de> Die Kartoffeln waschen und mit der Schale im salzigen Wasser kochen; in der Zeit den Speck mit Butter in einer Pfanne anbraten, nach einigen Minuten die gehackte Zwiebel dazugeben und köcheln lassen, solange bis sie weich und glasig ausschaut.
<G-vec00060-001-s084><add.dazugeben><en> Add the flour and lightly brown it.
<G-vec00060-001-s084><add.dazugeben><de> Mehl und Hefe vermischen und die Milch dazugeben.
<G-vec00060-001-s085><add.dazugeben><en> Add caramel right before serving.
<G-vec00060-001-s085><add.dazugeben><de> Kurz vor dem Servieren den Karamell dazugeben.
<G-vec00060-001-s086><add.dazugeben><en> You can add also nuts like cashew for example.
<G-vec00060-001-s086><add.dazugeben><de> Man kann auch Nüsse wie zum Beispiel Cashew dazugeben.
<G-vec00060-001-s087><add.dazugeben><en> Add chanterelles and thyme and stew all until al dente.
<G-vec00060-001-s087><add.dazugeben><de> Eierschwammerl und Thymian dazugeben und alles bissfest dünsten.
<G-vec00060-001-s088><add.dazugeben><en> Heat the milk in a pan and add the oatmeal.
<G-vec00060-001-s088><add.dazugeben><de> Die Milch in einem Topf erhitzen und die Haferflocken dazugeben.
<G-vec00060-001-s089><add.dazugeben><en> Then add the water, the grated potato, the stock cubes and 1 teaspoon of salt and bring to the boil.
<G-vec00060-001-s089><add.dazugeben><de> Anschließend Wasser, geriebene Kartoffeln, Gemüsebouillonwürfel und 1 TL Salz dazugeben und zum Kochen bringen.
<G-vec00060-001-s090><add.dazugeben><en> Add meat cubes and fry them.
<G-vec00060-001-s090><add.dazugeben><de> Fleischwürfel dazugeben und anbraten.
<G-vec00060-001-s091><add.dazugeben><en> Add the shredded chicken and season with a pinch of salt, pepper and parsley.
<G-vec00060-001-s091><add.dazugeben><de> Das zerkleinerte Hähnchen dazugeben und mit einer Prise Salz, Pfeffer und Petersilie würzen.
<G-vec00060-001-s092><add.dazugeben><en> Than add bananas, pineapple (and other fruits), add the coconut ice and pour the vegetable broth on it.
<G-vec00060-001-s092><add.dazugeben><de> Nun Bananen, Ananas (und weitere Früchte) dazugeben, Kokosraspeln beifügen und mit der Gemüsebouillon aufgiessen.
<G-vec00060-001-s093><add.dazugeben><en> Bake it in a preheated oven for 30 minutes at 200 ° / gas level 4, add seasoned lamb chops to it depending on the thickness at the last 10 – 15 minutes.
<G-vec00060-001-s093><add.dazugeben><de> 30 Minuten im auf 200° / Gas Stufe 4 vorgeheizten Ofen backen, gewürzte Lammkotelett je nach Dicke für die letzten 10-15 Minuten dazugeben.
<G-vec00060-001-s094><add.dazugeben><en> As soon as all the sugar is melted, add soft butter and salt (we suggest you to go away from the pan as it could splatter and you might burn yourself).
<G-vec00060-001-s094><add.dazugeben><de> Wenn der ganze Zucker geschmolzen ist, weiche Butter und Salz dazugeben (wir empfehlen, sich von der Pfanne zu entfernen, da es spritzen kann undman sich verbrennen könnte).
<G-vec00407-001-s076><add.dazugeben><en> Add the coconut milk and blend with an immersion blender.
<G-vec00407-001-s076><add.dazugeben><de> Kokosmilch dazugeben und alles mit dem Pürierstab pürieren.
<G-vec00407-001-s078><add.dazugeben><en> Finally, add vinegar and garnish with the hard-boiled eggs.
<G-vec00407-001-s078><add.dazugeben><de> Zum Schluss Essig dazugeben und mit den hartgekochten Eiern garnieren.
<G-vec00407-001-s081><add.dazugeben><en> Weigh the pulp and add equal amount of sugar.
<G-vec00407-001-s081><add.dazugeben><de> Die gleiche Menge an Zucker in einem Topf leicht erhitzen, Zitronensaft dazugeben.
<G-vec00407-001-s082><add.dazugeben><en> If you think the salsa is too spicy, add the avocado to the blender and mix again very well.
<G-vec00407-001-s082><add.dazugeben><de> Wem die Salsa zu scharf ist, der kann die Avocado dazugeben und die Sauce nochmals gut pürieren.
<G-vec00499-001-s091><add.dazugeben><en> Add the shredded chicken and season with a pinch of salt, pepper and parsley.
<G-vec00499-001-s091><add.dazugeben><de> Das zerkleinerte Hähnchen dazugeben und mit einer Prise Salz, Pfeffer und Petersilie würzen.
<G-vec00407-001-s133><add.einfügen><en> As the articles are published we will add links to them from here.
<G-vec00407-001-s133><add.einfügen><de> Sobald die Artikel veröffentlicht werden, werden wir die Links hier einfügen.
<G-vec00407-001-s134><add.einfügen><en> Value chain is a high-level model of how businesses receive raw materials as input, add value to the raw materials through various processes, and sell finished products to customers.
<G-vec00407-001-s134><add.einfügen><de> Die Wertschöpfungskette ist ein Hochmodell, das stellt dar, wie Unternehmen Rohstoffe als Eingabe erhalten, wie Mehrwert für die Rohstoffe durch die verschiedenen Prozesse einfügen, und wie fertige Produkte an Kunden verkaufen.
<G-vec00407-001-s135><add.einfügen><en> Please note: You can create as many categories as you need; add the same score to different categories; present catalogues in other language versions.
<G-vec00407-001-s135><add.einfügen><de> Zu Ihrer Information: Sie können so viele Kategorien erstellen wie Sie möchten, eine Partitur in mehrere Kategorien einfügen und auch die Kategorien in vier Sprachversionen präsentieren.
<G-vec00407-001-s136><add.einfügen><en> You shouldn't add an IP address to your access list just because one time your hostname appeared as numbers.
<G-vec00407-001-s136><add.einfügen><de> Du solltest keine Nummern in deine Access Liste einfügen, nur weil Du einmal zufällig eine IP Adresse zugewiesen bekommen hast.
<G-vec00407-001-s137><add.einfügen><en> In addition, you can add remarks to any address in the text box provided for this purpose.
<G-vec00407-001-s137><add.einfügen><de> Sie können außerdem eine Bemerkung zu jedem Adressdatensatz in das dafür vorgesehene Textfeld einfügen.
<G-vec00407-001-s138><add.einfügen><en> Add an Alkacon GeoMap to your website by Drag & Drop.
<G-vec00407-001-s138><add.einfügen><de> Einfügen einer GeoMap auf einer Webseite ganz einfach per Drag & Drop.
<G-vec00407-001-s139><add.einfügen><en> You can use any number of free and paid plugins to add your code.
<G-vec00407-001-s139><add.einfügen><de> Sie können eine beliebige Anzahl von kostenlosen und kostenpflichtigen Plugins, um Ihren Code einfügen.
<G-vec00407-001-s140><add.einfügen><en> Put the cherries (whole) in a pan together with Madeira wine and boil until the wine evaporates completely; add the sherry vinegar at the end.
<G-vec00407-001-s140><add.einfügen><de> In einem Topf die Kirschen mit Kerne und den Madeirawein und bis zur vollständige Verdampfung kochen; am Ende, Sherry-Essig einfügen.
<G-vec00407-001-s141><add.einfügen><en> For example, you can add your favourite transactions to the easy access menu in a more graphical form.
<G-vec00407-001-s141><add.einfügen><de> Sie können zum Beispiel Ihre Lieblingstransaktionen in einer geeigneten grafischen Form in das Easy Access Menü einfügen.
<G-vec00407-001-s142><add.einfügen><en> You can also add a video straight from the email builder.
<G-vec00407-001-s142><add.einfügen><de> Sie können auch ein Video direkt aus dem E-Mail Ersteller einfügen.
<G-vec00407-001-s143><add.einfügen><en> Find the document you would like to add and click on its name.
<G-vec00407-001-s143><add.einfügen><de> Suchen Sie das Dokument das Sie einfügen wollen, und klicken Sie auf den Namen.
<G-vec00407-001-s144><add.einfügen><en> Here you can edit the number of items by clicking on the item add, or delete or empty the whole basket.
<G-vec00407-001-s144><add.einfügen><de> Hier können Sie selbst noch die Anzahl der Elemente bearbeiten, in dem Sie auf Einfügen oder Löschen klicken, oder den gesamten Korb ausleeren.
<G-vec00407-001-s145><add.einfügen><en> If you add an A/B test to the campaign, you must create at least two versions of the message.
<G-vec00407-001-s145><add.einfügen><de> Wenn Sie einen A/B-Test in eine Kampagne einfügen, müssen Sie mindestens zwei Varianten einer Nachricht erstellen.
<G-vec00407-001-s146><add.einfügen><en> You can add graphics or images to glossary entries, as you can to other text.
<G-vec00407-001-s146><add.einfügen><de> In die Glossareinträge können Sie wie bei anderen Texten auch Grafiken oder Bilder einfügen.
<G-vec00407-001-s147><add.einfügen><en> You also can add the name of the sender.
<G-vec00407-001-s147><add.einfügen><de> Sie können auch den Namen des Absenders einfügen.
<G-vec00407-001-s148><add.einfügen><en> You’ll also have access to some editing options to cut out frames, add watermarks or add size and duration.
<G-vec00407-001-s148><add.einfügen><de> Darüber hinaus haben Sie Zugriff auf einige Bearbeitungsoptionen zum Ausschneiden von Rahmen, Hinzufügen von Wasserzeichen oder einfügen der Größe und Dauer.
<G-vec00407-001-s149><add.einfügen><en> Advanced/Add picture to the background...
<G-vec00407-001-s149><add.einfügen><de> Erweitert/Hintergrundbild einfügen...
<G-vec00407-001-s150><add.einfügen><en> For example, you could add a “TV” tag on all of the pages where you sell televisions.
<G-vec00407-001-s150><add.einfügen><de> "So könnten Sie etwa auf allen Seiten, auf denen Sie Fernseher anbieten, das Tag ""TV"" einfügen."
<G-vec00407-001-s151><add.einfügen><en> You have acquired a new facility and whish to add it to your existing portfolio.
<G-vec00407-001-s151><add.einfügen><de> Sie haben eine neue Bestandsimmobilie und möchten diese neu in ihr Portfolio einfügen.
<G-vec00060-001-s152><add.ergänzen><en> At first dissolve soda, then in the small portions add kremneftoristyj sodium at careful hashing.
<G-vec00060-001-s152><add.ergänzen><de> lösen die Soda Zuerst auf, dann von den kleinen Portionen ergänzen kremneftoristyj das Natrium bei der sorgfältigen Vermischung.
<G-vec00060-001-s153><add.ergänzen><en> We add fresh tonic to taste and a lemon slice.
<G-vec00060-001-s153><add.ergänzen><de> Wir ergänzen frisch tonik nach dem Geschmack und das Scheibchen der Zitrone.
<G-vec00060-001-s154><add.ergänzen><en> In a circle we shake up 2 eggs to homogeneous mass, we salt a little, we add to a support, we mix everything.
<G-vec00060-001-s154><add.ergänzen><de> Im Krug ist 2 Eier bis zur gleichartigen Masse gerührt, wir salzen ein wenig, wir ergänzen in oparu, alles ist gemischt.
<G-vec00060-001-s155><add.ergänzen><en> In case you want that the wall could be washed by means of a damp rag, it is necessary to add a little primer to solution.
<G-vec00060-001-s155><add.ergänzen><de> Falls Sie wollen, dass man die Wand mit Hilfe des feuchten Lappens waschen konnte, ist nötig es in die Lösung ein wenig Grundierungen zu ergänzen.
<G-vec00060-001-s156><add.ergänzen><en> If you are not able to do needlework, but at this expert in computer, it is possible to make presentation of photos: now there are many programs which allow to combine literally in some clicks photos, to make transitions between them, to add the text, to impose music, and then to keep presentation in video format.
<G-vec00060-001-s156><add.ergänzen><de> "Wenn Sie rukodelnitschat nicht verstehen, aber kann man dabei ""auf du"" mit dem Computer, die Präsentation aus den Fotografien machen: jetzt geben es viel Programme, die buchstäblich in etwas klikow zulassen die Fotografien zu vereinen, die Übergänge zwischen ihnen zu machen, den Text zu ergänzen, die Musik, und später aufzuerlegen, die Präsentation im Format Videos aufzusparen."
<G-vec00060-001-s157><add.ergänzen><en> After registration of the Account Licensee has the right to realize filling of the Account, the Personal page and other elements of the Professional network the Content, to add photos and other materials according to the provided functionality, to create pages of the organizations, to enter groups and to use other functions provided by the Licensor in case of use of the Professional network on condition of observance of the present Agreement.
<G-vec00060-001-s157><add.ergänzen><de> Nach der Registrierung des Benutzerkontos ist der Lizenznehmer berechtigt, die Füllung des Benutzerkontos, der Personalseite und anderer Elemente des Professionellen Netzes von Kontentom zu verwirklichen, die Fotografien und andere Materialien entsprechend gewährt фyHkциoHaлoM zu ergänzen, die Seiten der Organisationen zu schaffen, die Gruppen zu betreten und, andere Funktionen zu benutzen, die vom Lizenzgeber unter Anwendung vom Professionellen Netz vorbehaltlich der Beachtung des gegenwärtigen Abkommens gewährt sind.
<G-vec00060-001-s158><add.ergänzen><en> Approximately in an hour, after dissolution of glue available in a paint, there at careful hashing add in the small portions drying oil (before reception homogeneous emulsii) and plant with water to the necessary density.
<G-vec00060-001-s158><add.ergänzen><de> Ungefähr ergänzen nach der Stunde, nach der Auflösung des in der Farbe vorhandenen Leims, dorthin trennen bei der sorgfältigen Vermischung von den kleinen Portionen olifu (bis zum Erhalten der gleichartigen Emulsion) und zu Wasser bis zur nötigen Dichte.
<G-vec00060-001-s159><add.ergänzen><en> "No special package has been added yet... You can add it using the ""Add"" button."
<G-vec00060-001-s159><add.ergänzen><de> "Bisher ist kein Aufenthaltspaket eingegeben... Ergänzen Sie mit der Taste ""Hinzufügen""."
<G-vec00060-001-s160><add.ergänzen><en> Four times mix the turned-out substance then add all other components.
<G-vec00060-001-s160><add.ergänzen><de> Die sich ergebende Substation vier Male vermischen, wonach alle übrigen Komponenten ergänzen.
<G-vec00060-001-s161><add.ergänzen><en> The large poplars, pine and palm trees, acacias and oleanders, bay laurel and other Mediterranean plants add to the beauty of the park.
<G-vec00060-001-s161><add.ergänzen><de> Die großen Pappeln, Pinien, Palmen und Akazien und Oleander, Lorbeer Bucht und anderen mediterranen Pflanzen ergänzen die Schönheit des Parks.
<G-vec00060-001-s162><add.ergänzen><en> In the received mix at constant hashing add a chalk before reception of demanded density.
<G-vec00060-001-s162><add.ergänzen><de> In die bekommene Mischung bei der ständigen Vermischung ergänzen die Kreide bis zum Erhalten der geforderten Dichte.
<G-vec00060-001-s163><add.ergänzen><en> With our wide-ranging selection of day trips, you can take advantage of this during your language study abroad and road-test, consolidate and add to what you have already learnt in an interesting and fun way.
<G-vec00060-001-s163><add.ergänzen><de> Mit unserem breitgefächerten Angebot an Ausflügen können Sie sich diesen Umstand während Ihres Sprachaufenthalts zunutze machen und auf interessante und spassige Weise Gelerntes direkt in der Praxis erproben, festigen und ergänzen.
<G-vec00060-001-s164><add.ergänzen><en> Greens small to chop and add to a liver, then to fry some more minutes.
<G-vec00060-001-s164><add.ergänzen><de> Das Kraut klein porubit und zur Leber, dann obscharit noch etwas Minuten zu ergänzen.
<G-vec00060-001-s165><add.ergänzen><en> With the fifth package you can add further Performance Services to boost your performance.
<G-vec00060-001-s165><add.ergänzen><de> Im fünften Paket ergänzen Sie zusätzliche Performance-Services zur Steigerung Ihrer Leistungsstärke.
<G-vec00060-001-s166><add.ergänzen><en> Sausage to slice, add to vegetables and to allow soup to begin to boil once again.
<G-vec00060-001-s166><add.ergänzen><de> Die Wurst von den Scheibchen zu schneiden, zum Gemüse zu ergänzen und, der Suppe noch einmal zu gestatten, aufzukochen.
<G-vec00060-001-s167><add.ergänzen><en> And we decided to add pattern drawing gold paint on the tab intended for a cover.
<G-vec00060-001-s167><add.ergänzen><de> Und uns hat sich entschieden, die Schablonenzeichnung von der goldenen Farbe auf wkladku, vorbestimmt für den Deckel zu ergänzen.
<G-vec00060-001-s168><add.ergänzen><en> it is possible to add to classical spices also others, but do not hurry to mix everything at once.
<G-vec00060-001-s168><add.ergänzen><de> Zu den klassischen Gewürzen kann man und andere ergänzen, aber Sie beeilen sich nicht, allen sofort zu mischen.
<G-vec00060-001-s169><add.ergänzen><en> For bigger reliability it is possible to add today's date to it.
<G-vec00060-001-s169><add.ergänzen><de> Für bolschej der Zuverlässigkeit zu ihm kann man das heutige Datum ergänzen.
<G-vec00060-001-s170><add.ergänzen><en> Contains in some fruit and berries a little zheliruyushchy substance of pectin therefore in order that jam had a necessary jellylike consistence, it is possible to add at a laying of products to the container ready apple pectin.
<G-vec00060-001-s170><add.ergänzen><de> In einigen Früchten und den Beeren ist wenig schelirujuschtschego die Stoffe des Pektins, deshalb enthalten, damit die Marmelade notwendig scheleobrasnuju die Konsistenz hatte, man kann bei der Grundsteinlegung der Lebensmittel in den Container das fertige Apfelpektin ergänzen.
<G-vec00060-001-s171><add.ergänzen><en> In a couple of minutes add the cut onions.
<G-vec00060-001-s171><add.ergänzen><de> Durch ein Paar Minuten ergänzen Sie naresannyj die Zwiebel.
<G-vec00060-001-s172><add.ergänzen><en> after you crumbled cookies (it is possible to use for this purpose the blender) add it to the softened butter.
<G-vec00060-001-s172><add.ergänzen><de> Nachdem Sie pokroschili das Gebäck (kann man dazu blender verwenden) es in die erweichte Butter ergänzen Sie.
<G-vec00060-001-s173><add.ergänzen><en> In a kastryulka heat cream and add a flour.
<G-vec00060-001-s173><add.ergänzen><de> In kastrjulke erwärmen Sie die Sahne und ergänzen Sie das Mehl.
<G-vec00060-001-s174><add.ergänzen><en> When berries of a black-fruited mountain ash are drawn, again bring them to boiling, add the remained sugar and continue to cook.
<G-vec00060-001-s174><add.ergänzen><de> Wenn die Beeren tschernoplodnoj die Vogelbeerbäume bestanden werden werden, führen Sie sie bis zum Kochen wieder hin, ergänzen Sie den bleibenden Zucker und setzen Sie fort, zu kochen.
<G-vec00060-001-s175><add.ergänzen><en> Pour weight in a pan, add coconut juice (if that is not present, it is possible to use usual water) and lime juice.
<G-vec00060-001-s175><add.ergänzen><de> Die Masse füllen Sie in den Kochtopf um, ergänzen Sie den Kokossaft (wenn gibt es diesen nicht, man kann das gewöhnliche Wasser verwenden) und den Saft lajma.
<G-vec00060-001-s176><add.ergänzen><en> Portable Lenovo computer: as popast... Happy owners of Lenovo laptops need change of standard parameters of the device or installation add sooner or later...
<G-vec00060-001-s176><add.ergänzen><de> Der portative Computer Lenovo: wie popast... Den glücklichen Besitzer der Notebooks Lenovo früh oder spät wird die Veränderung der standardmäßigen Parameter dewajsa benötigt oder die Anlage ergänzen Sie...
<G-vec00060-001-s177><add.ergänzen><en> "It is possible to open ""Magazine"" also a combination of the Ctrl+Shift+H keys, during removal add to this combination also the Del key."
<G-vec00060-001-s177><add.ergänzen><de> """Die Zeitschrift"" öffnen es kann auch von der Kombination der Tasten Ctrl+Shift+H, bei der Entfernung ergänzen Sie zu dieser Kombination auch die Taste Del."
<G-vec00060-001-s178><add.ergänzen><en> Add to listed the starting complete set of account materials, expenses for installation and training, servicing within the second year of operation and further.
<G-vec00060-001-s178><add.ergänzen><de> Ergänzen Sie zu aufgezählt den Startsatz der Ausgabematerialien, die Kosten die Installation und die Ausbildung, die Instandhaltung im Laufe vom zweiten Jahr des Betriebes weiter.
<G-vec00060-001-s179><add.ergänzen><en> Now slowly and accurately add liqueur (or coffee) and cream.
<G-vec00060-001-s179><add.ergänzen><de> Jetzt ergänzen Sie langsam und den Likör (oder den Kaffee) und die Sahne akkurat.
<G-vec00060-001-s180><add.ergänzen><en> Play it down with neutral tones, or add to the exciting feel with bold colours and textures.
<G-vec00060-001-s180><add.ergänzen><de> Spielen Sie es mit neutralen Tönen ab oder ergänzen Sie das aufregende Gefühl mit kräftigen Farben und Texturen.
<G-vec00060-001-s181><add.ergänzen><en> Add eggs, sugar and a semolina.
<G-vec00060-001-s181><add.ergänzen><de> Ergänzen Sie die Eier, den Zucker und manku.
<G-vec00060-001-s182><add.ergänzen><en> Then reduce fire, add 2 more spoons of oil and mushrooms.
<G-vec00060-001-s182><add.ergänzen><de> Dann verringern Sie das Feuer, ergänzen Sie noch 2 Löffel des Öls und die Pilze.
<G-vec00060-001-s183><add.ergänzen><en> Find the right product for your needs and add more functionality to your system.
<G-vec00060-001-s183><add.ergänzen><de> Finden Sie das passende Produkt für Ihre Bedürfnisse und ergänzen Sie Ihr System mit mehr Funktionalität.
<G-vec00060-001-s184><add.ergänzen><en> And that it became more gentle and soft, add to it a little sweet yogurt and mix.
<G-vec00060-001-s184><add.ergänzen><de> Und damit sie zarter und weich wurde, ergänzen Sie in sie ein wenig süß jogurta und vermischen Sie.
<G-vec00060-001-s185><add.ergänzen><en> Add a custom Signup Form to your Website to sign up new contacts.
<G-vec00060-001-s185><add.ergänzen><de> Ergänzen Sie Ihre Webseite mit einem speziellen Anmeldeformular, um neue Kontakte zu gewinnen.
<G-vec00060-001-s186><add.ergänzen><en> If you want to improve the recipe, add banana chips.
<G-vec00060-001-s186><add.ergänzen><de> Wenn Sie das Rezept vervollkommnen wollen, so ergänzen Sie die Bananenchips.
<G-vec00060-001-s187><add.ergänzen><en> Add here the characteristics identical for all shop pages.
<G-vec00060-001-s187><add.ergänzen><de> Ergänzen Sie hier, was für alle Seiten des Shops charakteristisch ist.
<G-vec00060-001-s188><add.ergänzen><en> Add intelligent operations management and automation to your data center through vSphere with Operations Management.
<G-vec00060-001-s188><add.ergänzen><de> Mit vSphere with Operations Management ergänzen Sie Ihr Rechenzentrum um intelligentes Betriebsmanagement und Automatisierung.
<G-vec00060-001-s189><add.ergänzen><en> For its preparation take the egg white beaten to a condition of foam, add a spoon of honey and will put on a face for about 5 minutes, then wash and use nutritious cream.
<G-vec00060-001-s189><add.ergänzen><de> Für ihre Vorbereitung nehmen Sie gerührt bis zum Zustand des Schaums der Eichhörner, ergänzen Sie den Löffel des Honigs und werden auf die Person der Minuten auf 5 auftragen, dann waschen Sie sich und nutzen Sie die nahrhafte Creme aus.
<G-vec00060-001-s228><add.hinzufügen><en> Add some eye-catching photos of yourself to your profile page, and complete all of your personal details .
<G-vec00060-001-s228><add.hinzufügen><de> Füge einige auffällige Fotos von dir selbst zu deiner Profilseite hinzu und komplettiere alle deine persönlichen Details .
<G-vec00060-001-s229><add.hinzufügen><en> Add in a source of fiber.
<G-vec00060-001-s229><add.hinzufügen><de> Füge eine Faserstoffquelle hinzu.
<G-vec00060-001-s230><add.hinzufügen><en> Add also hiss in this section (a classic tape noise).
<G-vec00060-001-s230><add.hinzufügen><de> Füge in diesem Abschnitt auch Rauschen hinzu (ein klassisches Bandrauschen).
<G-vec00060-001-s231><add.hinzufügen><en> In the peak training period I add evening.
<G-vec00060-001-s231><add.hinzufügen><de> In der Spitzentrainingsperiode füge ich Abend hinzu.
<G-vec00060-001-s232><add.hinzufügen><en> Find some fabrics and click to add them.
<G-vec00060-001-s232><add.hinzufügen><de> Füge Deine Stoffproben durch Klicken hinzu.
<G-vec00060-001-s233><add.hinzufügen><en> "Zauberkarte Add 1 monster from your Deck to your hand that includes ""Elemental Hero"" in its card name."
<G-vec00060-001-s233><add.hinzufügen><de> "Zauberkarte Füge deiner Hand 1 Monster von deinem Deck hinzu, dessen Kartenname ""Elementarheld"" enthält."
<G-vec00060-001-s234><add.hinzufügen><en> Add a teaspoon of vegetable oil to each container of dye.
<G-vec00060-001-s234><add.hinzufügen><de> Füge zu jedem Farbglas einen Teelöffel Pflanzenöl hinzu.
<G-vec00060-001-s235><add.hinzufügen><en> And add a sense of motion with GPU-accelerated effects like Path and Spin Blur.
<G-vec00060-001-s235><add.hinzufügen><de> Füge deinen Bildern mit GPU-beschleunigten Effekten wie Path Blur und Spin Blur das Gefühl der Bewegung hinzu.
<G-vec00060-001-s236><add.hinzufügen><en> 2 Add the amount of rice suggested by the recipe.
<G-vec00060-001-s236><add.hinzufügen><de> 2 Füge die im Rezept vorgeschlagen Menge Reises hinzu.
<G-vec00060-001-s237><add.hinzufügen><en> Add stamps, notes and fields and enter the document for review / release in the workflow.
<G-vec00060-001-s237><add.hinzufügen><de> Füge Stempel, Notizen und Felder hinzu und gebe den Beleg zur Prüfung / Freigabe in den Workflow.
<G-vec00060-001-s238><add.hinzufügen><en> Add and promote your Fortnite server on the top 100 list for more players.
<G-vec00060-001-s238><add.hinzufügen><de> Füge Deinen Fortnite Server hinzu, und mach Werbung auf der Liste der Besten 100.
<G-vec00060-001-s239><add.hinzufügen><en> add these cards to your arsenal and build your perfect deck.
<G-vec00060-001-s239><add.hinzufügen><de> füge diese Karten deinem Arsenal hinzu und baue dein perfektes Deck.
<G-vec00060-001-s240><add.hinzufügen><en> Customise your teeth with braces and add piercings to your nose, eyebrows, eyelids and around your mouth.
<G-vec00060-001-s240><add.hinzufügen><de> Pass deine Zähne mit einer Spange an oder füge deiner Nase, deinen Augenbrauen, deinen Augenlidern oder deinem Mund Piercings hinzu.
<G-vec00060-001-s241><add.hinzufügen><en> Tap on the green + button to add the file.
<G-vec00060-001-s241><add.hinzufügen><de> Füge die Datei mit einem Klick auf den grünen „+“-Button hinzu.
<G-vec00060-001-s242><add.hinzufügen><en> Add categories to these pages.
<G-vec00060-001-s242><add.hinzufügen><de> Füge diesen Seiten Kategorien hinzu.
<G-vec00060-001-s243><add.hinzufügen><en> I cut the cuttle fish into pieces and let them cook in a pre-prepared soffritto (chopped onion and bit of garlic fried on a low heat); at its half cooking I add a sprinkle of white wine and the ink black that laid inside the cuttle fish.
<G-vec00060-001-s243><add.hinzufügen><de> Ich schneide die Tintenfische in Stückchen und koche sie mit einem Soffritto (Knoblauch, Zwiebeln beides fein gehackt auf kleiner Stufe angeröstet) und einem Spritzer Weißwein solange bis sie halb durch sind, danach füge ich die Tinte hinzu, die man im Inneren der Tintenfische findet und lasse sie fertig garen.
<G-vec00060-001-s244><add.hinzufügen><en> Add kite spots to your profile Access English (Translate this text in English): AIA North across from the Cafe Oasis.
<G-vec00060-001-s244><add.hinzufügen><de> Füge Kitespots zu deinem Profil hinzu Zugang English (Übersetze diesen text in Deutsch): AIA North across from the Cafe Oasis.
<G-vec00060-001-s245><add.hinzufügen><en> Please add me on...messenger.
<G-vec00060-001-s245><add.hinzufügen><de> Bitte füge mich zum...-Messenger hinzu.
<G-vec00060-001-s246><add.hinzufügen><en> Add graphics and text to your columns.
<G-vec00060-001-s246><add.hinzufügen><de> Füge deinen Spalten Grafiken und Text hinzu.
<G-vec00407-001-s228><add.hinzufügen><en> Add some eye-catching photos of yourself to your profile page, and complete all of your personal details .
<G-vec00407-001-s228><add.hinzufügen><de> Füge einige auffällige Fotos von dir selbst zu deiner Profilseite hinzu und komplettiere alle deine persönlichen Details .
<G-vec00407-001-s234><add.hinzufügen><en> Add a teaspoon of vegetable oil to each container of dye.
<G-vec00407-001-s234><add.hinzufügen><de> Füge zu jedem Farbglas einen Teelöffel Pflanzenöl hinzu.
<G-vec00060-001-s266><add.hinzufügen><en> "They also add: ""Do not forget about the musicians""."
<G-vec00060-001-s266><add.hinzufügen><de> "Sie fügen hinzu: ""Vergessen Sie nicht die Musiker""."
<G-vec00060-001-s267><add.hinzufügen><en> Even in esoteric circles people take the knowledge revealed by the Masters, add their own language and colour and publish it as their own thing.
<G-vec00060-001-s267><add.hinzufügen><de> Selbst in esoterischen Kreisen nehmen Leute das von den Meistern offenbarte Wissen, fügen ihre eigene Sprache und Farbe hinzu und geben es als ihre eigene Sache heraus.
<G-vec00060-001-s268><add.hinzufügen><en> Add the external schema by clicking the Add New Schema icon in the Overview entry helper and then browsing for the schema you wish to add.
<G-vec00060-001-s268><add.hinzufügen><de> "Fügen Sie das externe Schema hinzu, indem Sie in der Eingabehilfe ""Übersicht"" auf das Symbol Neues Schema hinzufügen klicken und anschließend zum gewünschten Schema navigieren."
<G-vec00060-001-s269><add.hinzufügen><en> Information from Other Sources: We also may periodically obtain information about you from affiliated entities, business partners and other independent third-party sources and add it to other information about you.
<G-vec00060-001-s269><add.hinzufügen><de> Informationen aus anderen Quellen: Wir erhalten möglicherweise auch regelmäßig von Affiliate-Partnern, Geschäftspartnern und anderen unabhängigen Drittquellen Informationen über Sie und fügen diese anderen Informationen über Sie hinzu.
<G-vec00060-001-s270><add.hinzufügen><en> Just tap on it and add the contact you want to block.
<G-vec00060-001-s270><add.hinzufügen><de> Tippen Sie einfach darauf und fügen Sie den zu blockierenden Kontakt hinzu.
<G-vec00060-001-s271><add.hinzufügen><en> 1279 BC + 12 hours; all add up to 96 hours, = 48 + 48 hours of two years of sped up reverse orbit countered by the long days.
<G-vec00060-001-s271><add.hinzufügen><de> 1279 BC + 12 Stunden; alle fügen oben 96 Stunden, = 48 + 48 Stunden von zwei Jahren der beschleunigten Rückbahn hinzu, die bis zum den langen Tagen widersprochen wird.
<G-vec00060-001-s272><add.hinzufügen><en> Supposing you add a VBA macro for a workbook, now you want to save it as a template.
<G-vec00060-001-s272><add.hinzufügen><de> Angenommen, Sie fügen einen VBA-Makro für eine Arbeitsmappe hinzu, möchten Sie ihn jetzt als Vorlage speichern.
<G-vec00060-001-s273><add.hinzufügen><en> This requires a change in the way programming is taught, they add.
<G-vec00060-001-s273><add.hinzufügen><de> Dies erfordert eine Veränderung in der Art der Programmierung gelehrt wird, fügen Sie hinzu.
<G-vec00060-001-s274><add.hinzufügen><en> With «Add Poll» you add a new survey.
<G-vec00060-001-s274><add.hinzufügen><de> Mit «Add Poll» fügen Sie eine neue Umfrage hinzu.
<G-vec00060-001-s275><add.hinzufügen><en> Create and save a ringtone and then add it to your Tones library in iTunes.
<G-vec00060-001-s275><add.hinzufügen><de> Erstellen und speichern Sie einen Klingelton und fügen ihn dann zur Bibliothek mit Tönen in iTunes hinzu (Video auf Englisch).
<G-vec00060-001-s276><add.hinzufügen><en> The monks then add rennet: this is a substance that makes the milk stiff.
<G-vec00060-001-s276><add.hinzufügen><de> Dann fügen die Mönche Lab hinzu, einen Stoff, wodurch die Milch steif wird.
<G-vec00060-001-s277><add.hinzufügen><en> When you decide to treat your self to a 4 hour exclusive entry to the Retreat Spa and the Blue Lagoon, add this luxury private transfer to your package.
<G-vec00060-001-s277><add.hinzufügen><de> Wenn Sie sich entscheiden, sich selbst mit einem 4-stündigen exklusiven Eintritt in das Retreat Spa und die Blaue Lagune zu verwöhnen, fügen Sie diesen luxuriösen Privattransfer zu Ihrem Paket hinzu.
<G-vec00060-001-s278><add.hinzufügen><en> Celtic cultures often add mystical and religious markings and symbols to their wedding jewellery.
<G-vec00060-001-s278><add.hinzufügen><de> Keltische Kulturen fügen Ihrem Hochzeitsschmuck häufig mystische und religiöse Zeichen und Symbole hinzu.
<G-vec00060-001-s279><add.hinzufügen><en> And a Kutools for Excel dialog box pops up, please select the certain table range you will add a blank row below, and then click the OK button.
<G-vec00060-001-s279><add.hinzufügen><de> Und ein Kutools for Excel Dialogfeld erscheint, bitte wählen Sie den bestimmten Tabellenbereich aus, Sie fügen eine leere Zeile hinzu und klicken dann auf OK Taste.
<G-vec00060-001-s280><add.hinzufügen><en> The spiralling seams and capped vents add sculptural detail to the roof encouraging the eye to move across it to further enhance the reading of the Foudre as a single entity.
<G-vec00060-001-s280><add.hinzufügen><de> "Die spiralförmigen Falze und die bedeckten Schlitze fügen dem Dach ein plastisches Detail hinzu und ermutigen das Auge weiterzuwandern, um den ""Foudre"" als alleinstehende Einheit wahrzunehmen."
<G-vec00060-001-s281><add.hinzufügen><en> Jot down your thoughts, a short story, add some stems of pressed grass and the flat little stone you could have skimmed over the water.
<G-vec00060-001-s281><add.hinzufügen><de> Sie schreiben Ihre Gedanken auf, eine kleine Erzählung, fügen gepresste Gräser hinzu und das flache Steinchen, das Sie eigentlich über den Wasserspiegel springen lassen wollten.
<G-vec00060-001-s282><add.hinzufügen><en> • If you need additional information add it as a comment and it will appear in brackets under the designation on the form.
<G-vec00060-001-s282><add.hinzufügen><de> • Wenn Sie zusätzliche Informationen benötigen, fügen Sie ein Kommentar hinzu und dieser erscheint in Klammern unterhalb der Fragestellung.
<G-vec00060-001-s283><add.hinzufügen><en> We will add new functions to the API.
<G-vec00060-001-s283><add.hinzufügen><de> Wir fügen neue Funktionen zur API hinzu.
<G-vec00060-001-s284><add.hinzufügen><en> To get a first idea please visit our price page and check the size and figure count then add on a frame if required.
<G-vec00060-001-s284><add.hinzufügen><de> Um einen ersten Eindruck zu bekommen besuchen Sie unsere Preis-Seite und überprüfen Sie das Format mit der Personenzahl und fügen dann den Rahmenpreis hinzu, falls gewünscht.
<G-vec00060-001-s304><add.hinzufügen><en> Anavar will add quality pounds to any frame small or large by increasing growth factors, such as IGF also.
<G-vec00060-001-s304><add.hinzufügen><de> Anavar fügt Qualitätspfund jedem möglichem Rahmen hinzu, der indem er auch Wachstumsfaktoren, wie IGF klein oder groß ist, erhöht.
<G-vec00060-001-s305><add.hinzufügen><en> The buttons on the top have the following function: Add Add the selected file(s) in the explorer to the project.
<G-vec00060-001-s305><add.hinzufügen><de> Die Schalter oben haben folgende Funktion: Hinzufügen Fügt das/die im Explorer ausgewählte(n) Datei(en) zum Projekt hinzu.
<G-vec00060-001-s306><add.hinzufügen><en> It will force your body into a more natural position and add detail to your portrait.
<G-vec00060-001-s306><add.hinzufügen><de> Es zwingt deinen Körper in eine natürlichere Haltung und fügt deinem Portrait ein Detail hinzu.
<G-vec00060-001-s307><add.hinzufügen><en> It may add the old version in the last parameter, if the package has already been installed and removed since (but not purged, the configuration files having been retained).
<G-vec00060-001-s307><add.hinzufügen><de> Möglicherweise fügt es im letzten Parameter die alte Version hinzu, falls das Paket früher schon einmal installiert war und seither entfernt wurde (aber nicht vollständig gelöscht, da die Konfigurationsdateien noch zurückbehalten wurden).
<G-vec00060-001-s308><add.hinzufügen><en> memoQ will immediately add the term pair to the term base.
<G-vec00060-001-s308><add.hinzufügen><de> memoQ fügt das Termpaar sofort der Termdatenbank hinzu.
<G-vec00060-001-s309><add.hinzufügen><en> I have always thought that the lighting object takes shape from the light source, through a design concept aimed at solving needs.... on the sheet you draw the bulb, you add a ground plane, maybe a deposit for books or music, and why not, endless profiles of lamps that envelop the light..... Also available with a writable surface with markers for the whiteboard.
<G-vec00060-001-s309><add.hinzufügen><de> Ich habe immer gedacht, dass das Lichtobjekt Form von der Lichtquelle annimmt, durch ein Designkonzept, das auf die Lösung der Bedürfnisse ausgerichtet ist..... auf dem Blatt, auf dem man die Glühbirne zeichnet, fügt man eine Grundplatte hinzu, vielleicht eine Kaution für Bücher oder Musik, und warum nicht, endlose Profile von Lampen, die das Licht umhüllen........ Auch mit beschreibbarer Oberfläche mit Markern für das Whiteboard erhältlich.
<G-vec00060-001-s310><add.hinzufügen><en> Remarks: Add a wireless network profile on an interface for all or current users.
<G-vec00060-001-s310><add.hinzufügen><de> Anmerkungen: Fügt einer Schnittstelle für alle oder für die aktuellen Benutzer ein Drahtlosnetzwerkprofil hinzu.
<G-vec00060-001-s311><add.hinzufügen><en> The brand new Czech amateur Nikol will gladly prepare anything you wish for and she might even add a little of something erotic.
<G-vec00060-001-s311><add.hinzufügen><de> Der brandneue tschechische Amateur Nikol bereitet gerne alles vor, was Sie sich wünschen, und vielleicht fügt er sogar etwas Erotisches hinzu.
<G-vec00060-001-s312><add.hinzufügen><en> 'Omron’s highly specialized owned core technologies add the Think Dimension to manufacturing today to enable producers to innovate to Industry 4.0 smart factories and improve their output', remarks Peter Cusack, Head of Strategic Marketing at Omron Europe.
<G-vec00060-001-s312><add.hinzufügen><de> „Die hochgradig spezialisierte, unternehmenseigene Kerntechnologie von Omron fügt der Fertigung von heute die Denk-Dimension hinzu und ebnet so Herstellern den Weg zur Industrie 4.0 und ermöglicht ihnen, ihre Leistung zu steigern“, meint Peter Cusack, Head of Strategic Marketing bei Omron Europe.
<G-vec00060-001-s313><add.hinzufügen><en> How to add a watermark to pictures
<G-vec00060-001-s313><add.hinzufügen><de> Wie fügt man ein Wasserzeichen auf Bildern hinzu...
<G-vec00060-001-s314><add.hinzufügen><en> Click Data > Filter, Excel will add drop-down arrows to the column headers.
<G-vec00060-001-s314><add.hinzufügen><de> Klicken Dateimanagement erfolgen > FilternExcel fügt den Spaltenüberschriften Dropdown-Pfeile hinzu.
<G-vec00060-001-s315><add.hinzufügen><en> MAYA is extremely simple to use. For a cup of hot chocolate just fill the provided jug with whole milk, add a sachet of powdered chocolate and, without stirring, place the jug on the machine support. Press the button 1 and in a few seconds you will obtain a perfect thick hot chocolate
<G-vec00060-001-s315><add.hinzufügen><de> MAYA ist einfach in ihrer Anwendung: man gießt Vollmilch in den zur Ausstattung gehörenden Krug, fügt das Tütchen Kakaopulver hinzu und stellt den Krug auf die eigens dafür vorgesehenen Halteplatte der Maschine; nach Drücken der gewählten Taste, wird automatisch eine perfekte Schokolade zubereitet.
<G-vec00060-001-s316><add.hinzufügen><en> Now add to this the fact that in the last lifetimes, the roles were reversed.
<G-vec00060-001-s316><add.hinzufügen><de> Und nun fügt dem die Tatsache hinzu, dass in den vorherigen Leben die Rollen vertauscht waren.
<G-vec00060-001-s317><add.hinzufügen><en> This modern and quirky Whale Shaped Serving Bowl will add fun and style to any table.
<G-vec00060-001-s317><add.hinzufügen><de> das ist modern und skurril Wal-förmige Servierschale fügt jedem Tisch Spaß und Stil hinzu.
<G-vec00060-001-s318><add.hinzufügen><en> Add a knot via left mouse click.
<G-vec00060-001-s318><add.hinzufügen><de> Drücken der linken Maustaste fügt einen Knoten hinzu.
<G-vec00060-001-s319><add.hinzufügen><en> (2) This VBA code won’t add flash background to blank selection.
<G-vec00060-001-s319><add.hinzufügen><de> (2) Dieser VBA-Code fügt der leeren Auswahl keinen Flash-Hintergrund hinzu.
<G-vec00060-001-s320><add.hinzufügen><en> "Implementation of the WirelessHART standard will add Session keys for communication between two network devices so that other devices can't ""listen in."""
<G-vec00060-001-s320><add.hinzufügen><de> Implementierung des WirelessHART Standard fügt Sitzungsschlüssel für die Kommunikation zwischen zwei Netzwerkgeräten hinzu, so dass andere Geräte nicht „zuhören“ können.
<G-vec00060-001-s321><add.hinzufügen><en> Write a string in the #File and add an 'end of line' character.
<G-vec00060-001-s321><add.hinzufügen><de> Schreibt einen String in die '#Datei' und fügt ein 'End of line' Zeichen (für Zeilenumbruch) hinzu.
<G-vec00060-001-s322><add.hinzufügen><en> Notes: This method will also add space at the beginning of cells if the first letter is capital.
<G-vec00060-001-s322><add.hinzufügen><de> Notizen: Diese Methode fügt auch am Anfang von Zellen Speicherplatz hinzu, wenn der erste Buchstabe groß ist.
<G-vec00060-001-s399><add.hinzufügen><en> "At the bottom of the page ""Order information"" click on the button ""Add to cart""."
<G-vec00060-001-s399><add.hinzufügen><de> "Am unteren Teil der Seite ""Bestellinformationen"" klicken Sie auf ""In den Warenkorb hinzufügen""."
<G-vec00060-001-s400><add.hinzufügen><en> I will add, and they take love with them.
<G-vec00060-001-s400><add.hinzufügen><de> Ich will hinzufügen, und sie nehmen sie verliebt.
<G-vec00060-001-s401><add.hinzufügen><en> Deglaze with the red wine vinegar, add the beer, 2 large tablespoons of Sirop de Liège and then add the raisins.
<G-vec00060-001-s401><add.hinzufügen><de> Mit dem Rotwein ablöschen, das Bier hinzufügen, sowie 2 gute Löffel Sirop de Liège und die Rosinen.
<G-vec00060-001-s402><add.hinzufügen><en> Add 250g of single cream, season with salt and chilli pepper.
<G-vec00060-001-s402><add.hinzufügen><de> 250 g flüssige Sahne hinzufügen, mit Salz und Piment d'Espelette abschmecken.
<G-vec00060-001-s403><add.hinzufügen><en> Add minced meat and let it fry, constantly stirring.
<G-vec00060-001-s403><add.hinzufügen><de> Faschiertes hinzufügen und unter ständigem Rühren anbraten.
<G-vec00060-001-s404><add.hinzufügen><en> Maybe you also sell a tool for keyword research. You can easily add that, too.
<G-vec00060-001-s404><add.hinzufügen><de> Wenn Du ein Programm für die Keyword-Recherche verkaufst, kannst Du Keyword-Recherche als Interesse hinzufügen.
<G-vec00060-001-s405><add.hinzufügen><en> Heat olive oil, add chopped celery with finely grated lemon zest, sauté on low heat for 3 minutes.
<G-vec00060-001-s405><add.hinzufügen><de> Das Olivenöl erhitzen, gehackten Sellerie mit dem feinen Zitronenabrieb hinzufügen und bei kleiner Hitze für 3 Minuten anbraten.
<G-vec00060-001-s406><add.hinzufügen><en> Opens the Add Provider dialog box in which you can add a provider for the selected feature.
<G-vec00060-001-s406><add.hinzufügen><de> Öffnet das Dialogfeld Anbieter hinzufügen, in dem Sie einen Anbieter für das ausgewählte Feature hinzufügen können.
<G-vec00060-001-s408><add.hinzufügen><en> "To remove a category, select it in the drop menu, delete all the scripts and click the ""Add/remove category"" button."
<G-vec00060-001-s408><add.hinzufügen><de> Um eine Kategorie zu entfernen, wählen Sie sie im Dropdown-Menü aus, entfernen Sie alle Skripten, die sie enthält, und klicken Sie auf „Kategorie hinzufügen/entfernen“.
<G-vec00060-001-s409><add.hinzufügen><en> add to my travel plan Volleyball players of all ages, from beginners to experts, meet on Vienna's beach volleyball courts.
<G-vec00060-001-s409><add.hinzufügen><de> Beachvolleyball zu meinem Reiseplan hinzufügen Volleyballer jeden Alters, von Anfängern bis zu Könnern, treffen sich auf Wiens Beachvolleyball-Plätzen.
<G-vec00060-001-s410><add.hinzufügen><en> Shake all the ingredient – without orange juice – strain into cocktail glass filled with ice – then add orange juice to it.
<G-vec00060-001-s410><add.hinzufügen><de> Rütteln Sie alles - ohne Orangensaft – zusammen ins mit Eis gefüllte Cocktailglas - Orangensaft dann hinzufügen.
<G-vec00060-001-s411><add.hinzufügen><en> No matter whether you want to add your face to Will Smith or a cute little baby, this app makes it possible.
<G-vec00060-001-s411><add.hinzufügen><de> Egal, ob Sie Ihr Gesicht zu Will Smith oder ein nettes kleines Baby hinzufügen möchten, Diese App macht es möglich.
<G-vec00060-001-s412><add.hinzufügen><en> If relevant to the work, you may choose to add a time parameter to your NDA that states how long the information or materials between the parties should be kept confidential; this could be anything from six months after finishing the contract to more than 15 years.
<G-vec00060-001-s412><add.hinzufügen><de> Wenn dies für die Arbeit relevant ist, kannst du deiner NDA einen Zeitparameter hinzufügen, das angibt, wie lange die Informationen oder Materialien zwischen den Parteien vertraulich behandelt werden sollen; dies kann sechs Monate nach Abschluss des Vertrages bis zu mehr als 15 Jahren betragen.
<G-vec00060-001-s413><add.hinzufügen><en> Any comments and ideas will be welcomed below, if they make sense we’ll add them to our workplan.
<G-vec00060-001-s413><add.hinzufügen><de> Alle Kommentare und Ideen unter begrüßen, wenn sie Sinn machen wir sie zu unserem Arbeitsplan hinzufügen.
<G-vec00060-001-s415><add.hinzufügen><en> Enter the Serial Number for the particular mobile device you want to add.
<G-vec00060-001-s415><add.hinzufügen><de> Geben Sie die Seriennummer des Mobilgeräts ein, das Sie hinzufügen möchten.
<G-vec00060-001-s416><add.hinzufügen><en> If you plan a short trip or vacation in British Virgin Islands in the future, make sure you add Virgin Islands, Saint Barthélemy, Anguilla, Saint-Martin (French part), Puerto Rico, Saint Kitts and Nevis, Montserrat, Antigua and Barbuda, Dominica, Dominican Republic to your list.
<G-vec00060-001-s416><add.hinzufügen><de> Wenn Sie einen Kurzurlaub oder Ferien in Britische Jungferninseln in Zukunft planen, stellen Sie sicher, dass Sie Amerikanische Jungferninseln, Saint-Barthélemy, Anguilla, Saint Martin, Puerto Rico, Saint Christopher und Nevis, Montserrat, Antigua und Barbuda, Dominica, Dominikanische Republik zu Ihrer Liste hinzufügen.
<G-vec00060-001-s417><add.hinzufügen><en> The features add to the overall game experience as well.
<G-vec00060-001-s417><add.hinzufügen><de> Die Funktionen hinzufügen, um das gesamte Spiel Erfahrung.
<G-vec00060-001-s418><add.hinzufügen><en> One problem that many people hit is that I can not add a credit card or debit card to Apple Pay / Wallet when initializing iOS on your iPhone or iPad.
<G-vec00060-001-s418><add.hinzufügen><de> Ein Problem, das viele Menschen treffen, ist das Ich kann Apple Pay / Wallet keine Kreditkarte oder Debitkarte hinzufügen wenn Sie iOS auf Ihrem iPhone oder iPad initialisieren.
<G-vec00060-001-s419><add.hinzufügen><en> If you need to add any lube then use a good water-based lube and apply it to your partners penis.
<G-vec00060-001-s419><add.hinzufügen><de> Wenn Sie ein Gleitmittel hinzufügen müssen, verwenden Sie ein gutes Gleitmittel auf Wasserbasis und wenden Sie es auf den Penis Ihres Partners an.
<G-vec00060-001-s420><add.hinzufügen><en> If you want to add the files from your Mac Desktop and Documents folder to iCloud Drive, update your Mac to macOS Sierra or later then turn on Desktop and Documents .
<G-vec00060-001-s420><add.hinzufügen><de> "Wenn Sie Dateien vom Schreibtisch Ihres Mac oder aus dem Ordner ""Dokumente"" zu iCloud Drive hinzufügen möchten, aktualisieren Sie Ihren Mac auf macOS Sierra oder neuer, und aktivieren Sie dann ""Schreibtisch"" und ""Dokumente"" ."
<G-vec00060-001-s421><add.hinzufügen><en> If apples are juicy, you can add a little water and sugar, because your cake should have a good soak.
<G-vec00060-001-s421><add.hinzufügen><de> Wenn Äpfel saftig sind, können Sie ein wenig Wasser und Zucker hinzufügen, weil Sie Ihren Kuchen eine gute einweichen haben sollte.
<G-vec00060-001-s422><add.hinzufügen><en> Using a store builder like Ecwid, an AJAX application, allows you to add your store and be mirrored on several platforms (websites, blogs, social networks) simultaneously with a central point to manage each channel.
<G-vec00060-001-s422><add.hinzufügen><de> Mit einem store builder wie Ecwid, eine AJAX-Anwendung, ermöglicht das hinzufügen und speichern Sie Ihre spiegelung auf mehreren Plattformen (websites, blogs, soziale Netzwerke) gleichzeitig mit einem zentralen Punkt zu verwalten jeden Kanal.
<G-vec00060-001-s423><add.hinzufügen><en> Additional added fats like butter, margarine, gravy, salad dressing, sour cream, and those found in whole milk, cream and fried foods also add hundreds of calories: just cut a bit and see how quickly reveals the scale of change.
<G-vec00060-001-s423><add.hinzufügen><de> Extra hinzu Fette wie Butter, Margarine, Soße, Salat-Dressing, saure Sahne, und die in Vollmilch, Sahne gefunden, und frittierten Lebensmitteln auch hinzufügen, Hunderte von Kalorien: kopieren Sie einfach ein wenig zurück und sehen, wie schnell die Skala zeigt eine Veränderung.
<G-vec00060-001-s424><add.hinzufügen><en> However, if you need to add properties or methods only to one instance of an object, use the Add-Member cmdlet.
<G-vec00060-001-s424><add.hinzufügen><de> "Wenn Sie jedoch Eigenschaften oder Methoden lediglich einer Instanz eines Objekts hinzufügen müssen, verwenden Sie das Cmdlet ""Add-Member""."
<G-vec00060-001-s425><add.hinzufügen><en> Click Add, type the directory that you want to exclude from scanning into the given field and then click OK .
<G-vec00060-001-s425><add.hinzufügen><de> Klicken Sie auf Hinzufügen, geben Sie das Verzeichnis ein, das Sie vom Scannen ausschließen möchten und klicken Sie dann auf OK .
<G-vec00060-001-s426><add.hinzufügen><en> If you cannot add your NAS to Q’center, here are some common reasons why.
<G-vec00060-001-s426><add.hinzufügen><de> Wenn Sie Ihr NAS nicht zu Q’center hinzufügen können, finden Sie hier einige gängige Ursachen.
<G-vec00060-001-s427><add.hinzufügen><en> You can now add lessons into the timetable by right clicking in teacher’s timetable.
<G-vec00060-001-s427><add.hinzufügen><de> Sie können nun dem Stundenplan Unterrichtsstunden hinzufügen indem Sie im Lehrerstundenplan die rechte Maustaste drücken.
<G-vec00060-001-s428><add.hinzufügen><en> Price for 1: CHF Add to cart bodykey by NUTRILITETM MEAL REPLACEMENT BAR DARK CHOCOLATE The perfect replacement for 1-2 daily meals to support your weight-loss and healthy lifestyle goals.
<G-vec00060-001-s428><add.hinzufügen><de> Preis für 1: CHF Hinzufügen bodykey by NUTRILITETM MAHLZEITERSATZ-RIEGEL – DUNKLE SCHOKOLADE Der perfekte Ersatz von 1-2 Tagesmahlzeiten, der Sie bei Ihrer Gewichtsabnahme und Ihren Zielen auf dem Weg zu einem gesunden Lebensstil unterstützt.
<G-vec00060-001-s429><add.hinzufügen><en> If the group to which you like to add components to already exists, right-click onto this group and select New Component .
<G-vec00060-001-s429><add.hinzufügen><de> Falls bereits eine Gruppe besteht, zu der Sie Komponenten hinzufügen möchten, klicken Sie mit der rechten Maustaste auf diese Gruppe und wählen Sie Neue Komponente .
<G-vec00060-001-s430><add.hinzufügen><en> Insert HTML, CSS, shortcodes, use embed codes etc. Use for anything you can think of: announce a product, add social buttons, highlight content etc.
<G-vec00060-001-s430><add.hinzufügen><de> HTML einfügen, CSS, Kurzwahlnummern, Verwendung einbetten Codes etc.. Verwendung für alles, was man sich vorstellen kann: ankündigen eines Produkts, social-Buttons hinzufügen, Markieren Sie Inhalte etc..
<G-vec00060-001-s431><add.hinzufügen><en> Add Allow Restriction Rule - Type an IPv4 address in the Specific IPv4 Address box in the Add Allow Restriction Rule dialog box when you want to allow access to content for a specific IPv4 address.
<G-vec00060-001-s431><add.hinzufügen><de> Zulassungseinschränkungsregel hinzufügen - Geben Sie im Dialogfeld Zulassungseinschränkungsregel hinzufügen im Feld Bestimmte IPv4-Adresse eine IPv4-Adresse ein, wenn Sie für eine bestimmte IPv4-Adresse den Zugriff auf Inhalt zulassen möchten.
<G-vec00060-001-s432><add.hinzufügen><en> "Go to ""Add favourite"" in the browser menu and store the web app as a bookmark."
<G-vec00060-001-s432><add.hinzufügen><de> Gehen Sie im Browsermenü auf den Eintrag Favorit hinzufügen und legen Sie die Web-App als Lesezeichen ab.
<G-vec00060-001-s433><add.hinzufügen><en> PERSONALIZED MESSAGING If you wish to add a personal message to a Gift Card, simply type your message in the Message field during the purchase process.
<G-vec00060-001-s433><add.hinzufügen><de> INDIVIDUELLE NACHRICHTEN Wenn Sie einem Geschenkgutschein eine individuelle Nachricht hinzufügen möchten, geben Sie Ihre Nachricht einfach im Bestellprozess im Nachricht-Feld ein.
<G-vec00060-001-s434><add.hinzufügen><en> ": Add a new ""time frame"" (will be filled with the data specified)."
<G-vec00060-001-s434><add.hinzufügen><de> : Neuen Zeitraum hinzufügen (wird mit den Daten, die Sie spezifiziert haben ausgefüllt werden).
<G-vec00060-001-s435><add.hinzufügen><en> If you want to add a dollar sign at the end of the number, type #$ into the Type text box.
<G-vec00060-001-s435><add.hinzufügen><de> Wenn Sie ein Dollarzeichen am Ende der Zahl hinzufügen möchten, geben Sie ein #$ in die Art Textfeld.
<G-vec00060-001-s436><add.hinzufügen><en> In the Add Text dialog, type the zeros you want to add into the textbox of Text, and check Before first character option, and you can preview the adding result in the right pane.
<G-vec00060-001-s436><add.hinzufügen><de> In dem Text hinzufügen Geben Sie die Nullen ein, die Sie in das Textfeld von hinzufügen möchten SMS, und prüfe Vor dem ersten Charakter Option, und Sie können eine Vorschau des Addierergebnisses im rechten Fensterbereich anzeigen.
<G-vec00060-001-s437><add.hinzufügen><en> When you right mouse click the icon you can also add files to the list and change their properties. (same for a customizable file system).
<G-vec00060-001-s437><add.hinzufügen><de> Bei Rechtsklicken des Symbols, können Dateien zu der Liste hinzugefügt oder deren Eigenschaften geändert werden (Wie bei einem anpassbaren Dateisystem).
<G-vec00060-001-s438><add.hinzufügen><en> Add additional trees and spawn points for the multiplayer mode.
<G-vec00060-001-s438><add.hinzufügen><de> Für die Multiplayer-Version müssen zusätzliche Bäume und Spawnpunkte hinzugefügt werden.
<G-vec00060-001-s439><add.hinzufügen><en> "If you click on the ""Locale"" button it should add your preferred language."
<G-vec00060-001-s439><add.hinzufügen><de> Wenn Sie auf den Locale-Knopf drücken, sollte Ihre bevorzugte Sprache hinzugefügt werden.
<G-vec00060-001-s440><add.hinzufügen><en> You can easily add supports when doing double-sided cutting and preview your job on-screen to confirm the cutting path.
<G-vec00060-001-s440><add.hinzufügen><de> Bei doppelseitigen Schneidearbeiten kann Trägermaterial einfach hinzugefügt werden und zur Bestätigung der Fräsbahn kann eine Voransicht des Auftrags auf dem Bildschirm aufgerufen werden.
<G-vec00060-001-s441><add.hinzufügen><en> After that, we drain the water in excess and we add dried sea-salt coming from the Salinas of Margherita di Savoia,
<G-vec00060-001-s441><add.hinzufügen><de> Dann wird das überschüssige Wasser abgetropft und getrocknetes Meersalz aus den Salzlagerstätten von Margherita di Savoia hinzugefügt.
<G-vec00060-001-s442><add.hinzufügen><en> For example, you can add other objects to it.
<G-vec00060-001-s442><add.hinzufügen><de> Dem Array können beispielsweise weitere Objekte hinzugefügt werden.
<G-vec00060-001-s443><add.hinzufügen><en> If listening below these frequencies are important, you should add a switched 150 pf capacitor.
<G-vec00060-001-s443><add.hinzufügen><de> Beim Hören unterhalb dieser Frequenz, sollte ein schaltbarer Kondensator von 150pF hinzugefügt werden.
<G-vec00060-001-s444><add.hinzufügen><en> Now add yeast and salt and knead for 2 min at slow speed and 8 min at fast speed.
<G-vec00060-001-s444><add.hinzufügen><de> Nun werden Hefe und Salz hinzugefügt und der Teig erst 2 min bei langsamer Geschwindigkeit, dann weitere 8 min bei schneller Geschwindigkeit geknetet.
<G-vec00060-001-s445><add.hinzufügen><en> It add some additional functions which made the machine easy and convenient to operate.
<G-vec00060-001-s445><add.hinzufügen><de> Es wurden einige zusätzliche Funktionen hinzugefügt, die die Bedienung der Maschine einfach und bequem machten.
<G-vec00060-001-s446><add.hinzufügen><en> You don't want people to add new features to the project, but you don't want to tell all developers to stop programming either.
<G-vec00060-001-s446><add.hinzufügen><de> Sie wollen weder, dass dem Projekt neue Funktionen hinzugefügt werden, noch möchten Sie alle Entwicklern auffordern, das Programmieren einzustellen.
<G-vec00060-001-s447><add.hinzufügen><en> You must be an administrator to add and manage brands.
<G-vec00060-001-s447><add.hinzufügen><de> Marken können nur von einem Administrator hinzugefügt und verwaltet werden.
<G-vec00060-001-s448><add.hinzufügen><en> Episerver Find Connections Edition lets you add connectors, which index external content that is related to but not part of your website.
<G-vec00060-001-s448><add.hinzufügen><de> Mit der Episerver Find Connections Edition können Konnektoren hinzugefügt werden, die externe Inhalte indizieren, die einen Bezug zu Ihrer Webseite haben, aber nicht Teil derselben sind.
<G-vec00060-001-s449><add.hinzufügen><en> With the latest Volvo V40 D5 racer, it intends to add a new chapter to its success story from July.
<G-vec00060-001-s449><add.hinzufügen><de> Mit dem neuen Volvo V40 D5 Rennwagen soll seiner Erfolgsgeschichte ab Juli ein weiteres Kapitel hinzugefügt werden.
<G-vec00060-001-s450><add.hinzufügen><en> Now the main table has been updated the data and add new data based on the lookup table.
<G-vec00060-001-s450><add.hinzufügen><de> Nun wurden die Daten in der Haupttabelle aktualisiert und neue Daten basierend auf der Nachschlagetabelle hinzugefügt.
<G-vec00060-001-s451><add.hinzufügen><en> – Add a little vibrancy.
<G-vec00060-001-s451><add.hinzufügen><de> – Ein bisschen Leuchtkraft hinzugefügt.
<G-vec00060-001-s452><add.hinzufügen><en> The forest functional level must be Windows Server 2003, Windows Server 2008, or Windows Server 2008 R2 to add an RODC to the forest.
<G-vec00060-001-s452><add.hinzufügen><de> "Die Gesamtstrukturfunktionsebene muss ""Windows Server 2003"", ""Windows Server 2008"" oder ""Windows Server 2008 R2"" lauten, damit der Gesamtstruktur ein schreibgeschützter Domänencontroller hinzugefügt werden kann."
<G-vec00060-001-s453><add.hinzufügen><en> If there's already an event at this frame, it will add the event at the next frame.
<G-vec00060-001-s453><add.hinzufügen><de> Falls bereits ein Event vorhanden ist, dann wird das Event zum nächsten Frame hinzugefügt.
<G-vec00060-001-s454><add.hinzufügen><en> If you are a member of the local Administrators group, you can grant someone else the Manage Server permission to be able to add a printer by IP address or hostname.
<G-vec00060-001-s454><add.hinzufügen><de> Wenn Sie Mitglied der lokalen Gruppe Administratoren sind, können Sie einem anderen Benutzer die Berechtigung Server verwalten erteilen, damit ein Drucker über die IP-Adresse oder den Hostnamen hinzugefügt werden kann.
<G-vec00060-001-s455><add.hinzufügen><en> You can also add vehicles and landscapes drawn by yourself.
<G-vec00060-001-s455><add.hinzufügen><de> Es können eigene Fahrzeuge und Landschaften hinzugefügt werden.
<G-vec00060-001-s456><add.hinzufügen><en> Click, to add wishes to the new list.
<G-vec00060-001-s456><add.hinzufügen><de> Klicken Sie auf, um Wünsche zur neuen Wunschliste hinzuzufügen.
<G-vec00060-001-s457><add.hinzufügen><en> A Modern Tremolo bridge allows your tuning to remain incredibly stable, as well offering you the ability to add wide vibrato to your notes.
<G-vec00060-001-s457><add.hinzufügen><de> Eine moderne Tremolo-Brücke ermöglicht Ihre tuning sowie bietet Ihnen die Möglichkeit, Ihre Notizen breiten Vibrato hinzuzufügen unglaublich stabil bleiben.
<G-vec00060-001-s458><add.hinzufügen><en> Frameless wipers without support, use their wiper blades to add pressure, and make the force-bearing points evenly distributed, so it ha more efficient.
<G-vec00060-001-s458><add.hinzufügen><de> Frameless Wischer ohne Unterstützung, benutzen ihre Wischerblätter, um Druck hinzuzufügen, und machen die krafttragenden Punkte gleichmäßig verteilt, also ist es effizienter.
<G-vec00060-001-s459><add.hinzufügen><en> We are nearing the apex of this pyramid where there is nothing left to add.
<G-vec00060-001-s459><add.hinzufügen><de> Wir nähern uns der Spitze dieser Pyramide, wo es nichts mehr hinzuzufügen gibt.
<G-vec00060-001-s460><add.hinzufügen><en> Often it is only necessary to add a copy of the GNU GPL license text to documentation, and add an offer to provide the software source code (see FSFE's compliance tips).
<G-vec00060-001-s460><add.hinzufügen><de> Oftmals ist es ausreichend, eine Kopie des Lizenztextes der GNU GPL zur Dokumentation hinzuzufügen und das Angebot, den Quelltext zur Verfügung zu stellen zu unterbreiten (siehe dazu die Tipps der FSFE zur Lizenzeinhaltung).
<G-vec00060-001-s461><add.hinzufügen><en> Click left on the image to add a new object.
<G-vec00060-001-s461><add.hinzufügen><de> Klickt links auf das Bild um ein neues Objekt hinzuzufügen.
<G-vec00060-001-s462><add.hinzufügen><en> Specify additional DNS servers by their names and IP addresses, and then click Add to add them to the list.
<G-vec00060-001-s462><add.hinzufügen><de> Geben Sie zusätzliche DNS-Server mit Namen und IP-Adressen an, und klicken Sie dann auf Hinzufügen, um sie der Liste hinzuzufügen.
<G-vec00060-001-s463><add.hinzufügen><en> They make it simple for the average joe to add content to their site on a daily basis with just a few clicks of the mouse.
<G-vec00060-001-s463><add.hinzufügen><de> Sie bilden es einfach für den Durchschnitt Joe, Inhalt ihrem Aufstellungsort auf einer täglichen Grundlage mit gerade einigem Klicken der Maus hinzuzufügen.
<G-vec00060-001-s464><add.hinzufügen><en> ADD command is used to add new entries to the IPX configuration.
<G-vec00060-001-s464><add.hinzufügen><de> Der Befehl ADD wird verwendet, um neue Einträge zu der IPX-Konfiguration hinzuzufügen.
<G-vec00060-001-s465><add.hinzufügen><en> It may take some time to add photos to all or the most important contacts of the Thunderbird address book.
<G-vec00060-001-s465><add.hinzufügen><de> Es kann einige Zeit dauern, um Fotos hinzuzufügen, um alle oder die wichtigsten Kontakte aus dem Thunderbird-Adressbuch.
<G-vec00060-001-s466><add.hinzufügen><en> Cartier LOVE bracelet stainless steel screwdriver design needs a classic visual, but also add a contemporary interpretation of the spirit, to more sophisticated works.
<G-vec00060-001-s466><add.hinzufügen><de> Cartier Love-Armband aus Schraubendreher Design eine klassische Ästhetik erfordert, sondern auch eine zeitgemäße Interpretation von dem Geist hinzuzufügen, zu zeitgenössischen Werken.
<G-vec00060-001-s467><add.hinzufügen><en> Alternatively you can select All applications from the drop-down menu to add all applications.
<G-vec00060-001-s467><add.hinzufügen><de> Sie können auch den Eintrag Alle Anwendungen aus dem Dropdownmenü auswählen, um alle Anwendungen hinzuzufügen.
<G-vec00060-001-s468><add.hinzufügen><en> To add another effect to the image choose it in the Effects panel, and double click on it or use the icon at the bottom part of the panel.
<G-vec00060-001-s468><add.hinzufügen><de> Um einen anderen Effekt dem Bild hinzuzufügen, doppelklicken Sie darauf in der Effekte-Leiste oder benutzen Sie das Symbol im unteren Teil der Leiste.
<G-vec00060-001-s469><add.hinzufügen><en> I've verified these were causing the problem by creating a blank form and trying to add one on.
<G-vec00060-001-s469><add.hinzufügen><de> Ich habe überprüft, dass dies das Problem verursacht, indem ich ein leeres Formular erstellt und versucht habe, eines hinzuzufügen.
<G-vec00060-001-s470><add.hinzufügen><en> – add a new blank text field into your disc menu.
<G-vec00060-001-s470><add.hinzufügen><de> – Ihrem Datenträgermenü ein neues, freies Textfeld hinzuzufügen.
<G-vec00060-001-s471><add.hinzufügen><en> In some houses it is possible to add one or two extra beds.
<G-vec00060-001-s471><add.hinzufügen><de> In einigen Häusern ist es möglich, ein oder zwei zusätzliche Betten hinzuzufügen.
<G-vec00060-001-s472><add.hinzufügen><en> Then double-click the .reg file to add the information to the Windows registry.
<G-vec00060-001-s472><add.hinzufügen><de> Doppelklicken Sie dann die .reg-Datei, um die Informationen der Windows Registry hinzuzufügen.
<G-vec00060-001-s473><add.hinzufügen><en> The lead free and copper free silver mirror comes with a clear and bright surface, ensuring distinct and lifelike image.Positioned well, it also helps to add depth to any room.
<G-vec00060-001-s473><add.hinzufügen><de> Der bleifreie und kupferfreie silberne Spiegel kommt mit einer klaren und hellen Oberfläche und sorgt für ein ausgeprägtes und lebensechtes Bild.Positioniert gut, es hilft auch, Tiefe zu jedem Raum hinzuzufügen.
<G-vec00060-001-s474><add.hinzufügen><en> Tap Aa to add text, to add a sticker, or to draw on your photo or video.
<G-vec00060-001-s474><add.hinzufügen><de> Tippe auf Aa, um Text hinzuzufügen, auf, um einen Sticker hinzuzufügen oder auf, um etwas in dein Foto oder Video zu zeichnen.
<G-vec00060-001-s532><add.hinzufügen><en> With a turquoise background and a microphone as centerpiece, simply add your own text and the flyer's ready in no time.
<G-vec00060-001-s532><add.hinzufügen><de> Mit einem türkisfarbenen Hintergrund und einem Mikrofon als Mittelpunkt müssen Sie einfach nur noch Ihren eigenen Text hinzufügen und der Flyer ist im Handumdrehen fertig.
<G-vec00060-001-s533><add.hinzufügen><en> I should add a few words about the liner notes which are extensive, in German and English, with very nicely done (and a nice example of how one lays out Yiddish text w/transliteration if one's goal is to aid the reader).
<G-vec00060-001-s533><add.hinzufügen><de> Ich sollte noch ein paar Worte hinzufügen über die aufwendigen und umfangreichen Kommentare in Deutsch und Englisch, die sehr gut und ansprechend gemacht sind (und die ein gutes Beispiel dafür sind, wie jemand jiddischen Text mit Transliteration layoutet, wenn es sein Ziel ist, es dem Leser leichtzumachen).
<G-vec00060-001-s534><add.hinzufügen><en> One must add to this the fact of the absence of national leaders.
<G-vec00060-001-s534><add.hinzufügen><de> Man muss noch die Tatsache des Mangels an nationalen Führern hinzufügen.
<G-vec00060-001-s535><add.hinzufügen><en> We need to add that the Ministry of Transport doesn't agree with Uber's position and the employees are penalizing Uber drivers for charging too much.
<G-vec00060-001-s535><add.hinzufügen><de> Wir müssen noch hinzufügen, dass das Transportministerium dieser Meinung von Uber nicht zustimmt und ihre Mitarbeiter die Uber-Fahrer mit einer Strafe belegen, weil diese zu viel berechnen.
<G-vec00060-001-s536><add.hinzufügen><en> Obviously, they had to add delusional to my medical certificate.
<G-vec00060-001-s536><add.hinzufügen><de> Ganz offensichtlich mussten sie nun auch noch „wahnhafte Störungen“ zu meinem medizinischen Gutachten hinzufügen.
<G-vec00060-001-s537><add.hinzufügen><en> On the subject of narcotics, one may add that since they require a gradual increase of the amount taken, they are as veritable chains of darkness, placing man in a helpless situation.
<G-vec00060-001-s537><add.hinzufügen><de> Zum Thema Betäubungsmittel kann man noch hinzufügen, daß sie, weil sie eine allmähliche Steigerung der eingenommenen Menge er- fordern, wie wahrhaftige Ketten der Dunkelheit sind, die die Menschen in eine hilflose Lage versetzen.
<G-vec00060-001-s538><add.hinzufügen><en> Depending on the consistency, you may have to add some extra milk.
<G-vec00060-001-s538><add.hinzufügen><de> Je nach Konsistenz musst du noch etwas mehr Milch hinzufügen.
<G-vec00060-001-s539><add.hinzufügen><en> "If you want to add a second part, click on the ""+"" icon."
<G-vec00060-001-s539><add.hinzufügen><de> Möchten Sie noch einen zweiten Artikel hinzufügen, so klicken Sie auf das Plus-Icon.
<G-vec00060-001-s540><add.hinzufügen><en> Now click the Add to List button to apply the filter. This applies the filter and allows it to be displayed in the list on top.
<G-vec00060-001-s540><add.hinzufügen><de> Jetzt müssen Sie noch auf die Schaltfläche Zur Liste hinzufügen klicken; der Filter wird damit übernommen und in der Liste oben angezeigt.
<G-vec00060-001-s541><add.hinzufügen><en> I would like to add that one thing that really struck me about the experience was the knowledge that God loves everyone, and his love is all-inclusive.
<G-vec00060-001-s541><add.hinzufügen><de> Ich moechte noch hinzufügen, dass mich das Wissen in meiner Erfahrung, dass Gott jeden liebt und dass seine Liebe allumfassend ist, sehr beeindruckt hat.
<G-vec00060-001-s542><add.hinzufügen><en> If we add to their teaching experience an extra dose of life experience, international living and a zest for life, then we have a better description of our trainers.
<G-vec00060-001-s542><add.hinzufügen><de> Wenn wir zu der Unterrichtserfahrung noch eine Prise Lebenserfahrung, Internationalität und Lebensfreude hinzufügen, dann kommen wir einer guten Beschreibung unserer Trainerinnen und Trainer schon ziemlich nahe.
<G-vec00060-001-s543><add.hinzufügen><en> Now, if you got the impression, that only the instrumental tracks are worth listening, I have to add that Perez and Apocalyptica are doing a pretty fine job on “House of Chains” and “Come Back Down”.
<G-vec00060-001-s543><add.hinzufügen><de> Wenn jetzt der Eindruck entstanden ist, dass nur die instrumentalen Stücke – außer „Riot Lights“ – es wert sind gehört zu werden, muss ich schnell noch hinzufügen, dass Perez und Apocalyptica ihr ganzes Können auf „House of Chains“ und „Come Back Down“ zur Schau stellen.
<G-vec00060-001-s544><add.hinzufügen><en> I would add that the owner Philippe is very courteous.
<G-vec00060-001-s544><add.hinzufügen><de> Ich würde noch hinzufügen, dass Philippe, der Eigentümer, äußerst zuvorkommend ist.
<G-vec00060-001-s545><add.hinzufügen><en> I may add this: My experience is that no one really has spiritual knowledge without suffering.
<G-vec00060-001-s545><add.hinzufügen><de> Darf ich noch dies hinzufügen: Meine Erfahrung ist die, dass niemand ohne Leiden wirkliche geistliche Erkenntnis gewinnt.
<G-vec00060-001-s546><add.hinzufügen><en> I may add, before leaving Coquimbo, that M. Gay found in the neighbouring Cordillera, at the height of 14,000 feet above the sea, a fossiliferous formation, including a Trigonia and Pholadomya;*—both of which genera occur at the Puente del Inca.
<G-vec00060-001-s546><add.hinzufügen><de> Ehe ich Coquimbo verlasse, will ich noch hinzufügen, daszGay in der benachbarten Cordillera in einer Höhe von 14 000 Fuszüber dem Meere eine Fossile führende Formation gefunden hat, welcheeine Trigonia und Fholadomya enthielt2, welche beide Gattungen amPuente del Inca vorkommen.
<G-vec00060-001-s547><add.hinzufügen><en> Out of respect for the genuine religions honestly practiced by billions of people in the world, and for the genuine theologians, we might simply add that the theology of the market is sectarian, fundamentalist and anti-ecumenical.
<G-vec00060-001-s547><add.hinzufügen><de> Aus Achtung vor den eigentlichen Religionen, die weltweit von Milliarden Menschen achtbar ausgeübt werden, und vor den echten Theologen müssen wir noch hinzufügen, daß die Theologie des Marktes sektiererisch, fundamentalistisch und antiökumenisch ist.
<G-vec00060-001-s548><add.hinzufügen><en> "If we add to the pleasant and useful healing mud the climatic and geographic benefits (a warm and shallow sea), we can say that the beach with the healing mud in the Soline Bay has been rightfully dubbed ""a beach for the entire family""."
<G-vec00060-001-s548><add.hinzufügen><de> "Wenn wir dem Heilschlamm und den günstigen Klimaverhältnissen noch die günstige geografische Lage hinzufügen (immer angenehmes Wetters und flaches Meer) wird der Strand mit Heilschlamm in der Bucht Soline zu Recht als ""Strand für die ganze Familie"" bezeichnet."
<G-vec00060-001-s549><add.hinzufügen><en> From a Western perspective, we may add that when anger or hostility is aimed at another person or group, it may take the form of rejecting the person or group.
<G-vec00060-001-s549><add.hinzufügen><de> Aus abendländischer Perspektive können wir noch hinzufügen, dass Ärger, wenn er sich auf eine andere Person oder Gruppe richtet, in Form von Ablehnung der Person oder Gruppe auftreten kann.
<G-vec00060-001-s550><add.hinzufügen><en> Tertiary strata, such as are here described, appear to extend along the whole coast between Rio Chupat and Port Desire, except where interrupted by the underlying claystone porphyry, and by some metamorphic rocks; these hard rocks, I may add, are found at intervals over a space of about five degrees of latitude, from Point Union to a point between Port S. Julian and S. Cruz, and will be described in the ensuing chapter.
<G-vec00060-001-s550><add.hinzufügen><de> Tertiäre Schichten, so wie sie hier beschrieben wurden, erstreckensich augenscheinlich der ganzen Küste zwischen dem Rio Chupat undPort Desire entlang, ausgenommen wo sie von dem darunter liegendenToeca-Gestein, Porphyr und von einigen metamorphischen Gesteinenunterbrochen werden; ich will noch hinzufügen, dasz diese harten Ge-steine in Zwischenräumen über einen Raum von ungefähr fünf Breiten-graden von Point Union bis zu einem Punkte zwischen Port San Julianund Santa Cruz gefunden werden; sie werden im folgenden Capitel be-schrieben.
<G-vec00060-001-s570><add.hinzufügen><en> Effect: Under the Effect tabï1⁄4Œyou can add desired effect, adjust brightness, contrast and saturation.
<G-vec00060-001-s570><add.hinzufügen><de> Effekt: Unter der Registerkarte Effekt können Sie gewünschte Effekt hinzufügen, Helligkeit, Kontrast und Sättigung einstellen.
<G-vec00060-001-s571><add.hinzufügen><en> Art.code: Pallet-WK Log in or sign up to add to Favourites.
<G-vec00060-001-s571><add.hinzufügen><de> Art.Kode: Pallet-WK Log ein oder Melden Sie sich an um Favoriten hinzufügen.
<G-vec00060-001-s572><add.hinzufügen><en> Add as many viewing stations as you need, from 2 to 20 viewing stations can be used with single microscope.
<G-vec00060-001-s572><add.hinzufügen><de> Sie können Ihrem Mikroskop 2 bis 20 Diskussionsstationen hinzufügen, genau so viel, wie Sie brauchen.
<G-vec00060-001-s573><add.hinzufügen><en> Maybe you'll even discover a song or two to add to your own workout music playlist.
<G-vec00060-001-s573><add.hinzufügen><de> Vielleicht finden Sie hier sogar ein oder zwei Songs, die Sie Ihrer Workout-Playliste hinzufügen möchten.
<G-vec00060-001-s574><add.hinzufügen><en> Click the Project tab, right-click the SQL folder, and select Add Active File to Project from the context menu.
<G-vec00060-001-s574><add.hinzufügen><de> Klicken Sie auf das Projektregister, klicken Sie mit der rechten Maustaste auf den Ordner SQL und wählen Sie im Kontextmenü den Befehl Aktive Datei zum Projekt hinzufügen .
<G-vec00060-001-s575><add.hinzufügen><en> You may need to add USB drivers to the Windows 7 image.
<G-vec00060-001-s575><add.hinzufügen><de> Hinweis Möglicherweise müssen Sie dem Windows 7-Abbild USB-Treiber hinzufügen.
<G-vec00060-001-s576><add.hinzufügen><en> Right-click the connection to which you want to add a static IP address and then click Properties.
<G-vec00060-001-s576><add.hinzufügen><de> Klicken Sie mit der rechten Maustaste auf die Verbindung, der Sie eine statische IP-Adresse hinzufügen möchten, und klicken Sie dann auf Eigenschaften.
<G-vec00060-001-s577><add.hinzufügen><en> Use the Add Always Allowed URL dialog box to add a URL sequence to the list of URL sequences for which the request-filtering module will always grant access.
<G-vec00060-001-s577><add.hinzufügen><de> Im Dialogfeld Ablehnungssequenz hinzufügen können Sie der Liste der URL-Sequenzen eine URL-Sequenz hinzufügen, für die das Anforderungsfilterungsmodul den Zugriff ablehnt.
<G-vec00060-001-s578><add.hinzufügen><en> for think-cell.adm: In the Group Policy Object Editor use Add/Remove Templates... under Action
<G-vec00060-001-s578><add.hinzufügen><de> für think-cell.adm: Verwenden Sie im Gruppenrichtlinienobjekt-Editor Vorlagen hinzufügen/entfernen... im Menü Aktion .
<G-vec00060-001-s579><add.hinzufügen><en> Add another editing point to a closed shape: Option-click the shape's border where you want to add a point.
<G-vec00060-001-s579><add.hinzufügen><de> Weiteren Bearbeitungspunkt zu einer geschlossenen Form hinzufügen: Klicken Sie bei gedrückter Wahltaste an der Stelle auf den Rahmen der Form, an der Sie einen Punkt hinzufügen wollen.
<G-vec00060-001-s580><add.hinzufügen><en> With the free, easy-to-use VIRB Mobile app and VIRB Edit desktop software, you can edit, stabilize, share and add data overlays to videos.
<G-vec00060-001-s580><add.hinzufügen><de> Mit der kostenlosen, benutzerfreundlichen VIRB Mobile-App und der Desktop-Software VIRB Edit kannst du Videos bearbeiten, Stabilisierungen anwenden, sie mit anderen teilen und Datenüberlagerungen hinzufügen.
<G-vec00060-001-s581><add.hinzufügen><en> Determine the attribute value you want to remove and then the attribute value you want to add to the crossTank entries.
<G-vec00060-001-s581><add.hinzufügen><de> Legen Sie hierzu zunächst den Attributwert fest, den Sie entfernen möchten, und anschließend den Attributwert, den Sie zu den crossTank-Einträgen hinzufügen möchten.
<G-vec00060-001-s582><add.hinzufügen><en> The below VBA code can help to add captions to all images at once in a Word document.
<G-vec00060-001-s582><add.hinzufügen><de> Mit dem folgenden VBA-Code können Sie Bildunterschriften in einem Word-Dokument auf einmal hinzufügen.
<G-vec00060-001-s583><add.hinzufügen><en> To install GPMC on Windows Server 2008 R2, use the Add Features Wizard in Server Manager.
<G-vec00060-001-s583><add.hinzufügen><de> Verwenden Sie zum Installieren der GPMC unter Windows Server 2008 R2 den Assistenten zum Hinzufügen von Features im Server-Manager.
<G-vec00060-001-s584><add.hinzufügen><en> In the Manage Smart Media dialog, select a tray, click Add, and select Add from tray.
<G-vec00060-001-s584><add.hinzufügen><de> Markieren Sie im Fenster „Smarte Medien verwalten“ den Eintrag eines Papierfachs, klicken Sie auf „ Hinzufügen “ und wählen Sie „ Aus Fach hinzufügen “.
<G-vec00060-001-s585><add.hinzufügen><en> When using this method, it is possible to add audio data later, until the CD-R/RW disc has been finalized.
<G-vec00060-001-s585><add.hinzufügen><de> Bei dieser Methode können Sie Audiodaten auch später hinzufügen, bis die CD-R/RW- Disk finalisiert wurde.
<G-vec00060-001-s586><add.hinzufügen><en> In the details pane, right-click the user you want to add to the NIS domain, and then click Properties.
<G-vec00060-001-s586><add.hinzufügen><de> Klicken Sie im Detailbereich mit der rechten Maustaste auf den Benutzer, den Sie der NIS-Domäne hinzufügen möchten, und klicken Sie dann auf Eigenschaften.
<G-vec00060-001-s587><add.hinzufügen><en> When stewing dishes, you can add a little olive or other vegetable oil.
<G-vec00060-001-s587><add.hinzufügen><de> Wenn Sie Gerichte schmoren, können Sie etwas Olivenöl oder anderes Pflanzenöl hinzufügen.
<G-vec00060-001-s588><add.hinzufügen><en> Contents: 4 cards with envelop 2 Designs a Package Log in or sign up to add to Favourites.
<G-vec00060-001-s588><add.hinzufügen><de> Inhalt: 4 Karten mit Umschlage 2 Verschiedene pro Packung Log ein oder Melden Sie sich an um Favoriten hinzufügen.
<G-vec00499-001-s589><add.verleihen><en> The bases are available in all Cubit colors and veneers and add a classic touch to the shelf.
<G-vec00499-001-s589><add.verleihen><de> Die Sockel sind in allen Cubit-Farben und Furnieren erhältlich – verleihen dem Regal eine klassische Note.
<G-vec00499-001-s590><add.verleihen><en> A light grey block is used to add colour density to the bush.
<G-vec00499-001-s590><add.verleihen><de> Ein hellgrauer Druckstock wurde dazu eingesetzt, dem Busch Farbdichte zu verleihen.
<G-vec00499-001-s591><add.verleihen><en> Flavoured olive oil is a wonderful marinade that can add flavour to salads, rice, boiled vegetables, potatoes, pasta, meat and fish, or be used as the main ingredient in a vinaigrette.
<G-vec00499-001-s591><add.verleihen><de> Das aromatisierte Olivenöl ist eine wunderbare Marinade, die Salaten, Reis, gekochtem Gemüse, Kartoffeln, Teigwaren, Fleisch- und Fischgerichten Duft verleihen, oder der Hauptbestandteil zu einer anderen Vinegrette von Ihnen werden kann.
<G-vec00499-001-s592><add.verleihen><en> To fully appreciate the patience required to add a bold new hue to this material, it pays to understand just how difficult it is to make something as seemingly simple as a ceramic bezel.
<G-vec00499-001-s592><add.verleihen><de> Wenn man die Geduld, die erforderlich ist, diesem Material einen kräftigen neuen Farbton zu verleihen, wahrhaft zu würdigen wissen will, muss man zunächst verstehen, wie schwierig es ist, etwas scheinbar so Einfaches wie eine Keramiklünette herzustellen.
<G-vec00499-001-s593><add.verleihen><en> The loose fit with side slits, a dropped hemline in the back, the drawstring hood and the straight sleeves with dropped shoulders add a bit of urban style to your time off.Athletic Life is a lifestyle line from Freddy, designed for those who love athletic garments with unique character.
<G-vec00499-001-s593><add.verleihen><de> Die lockere Passform mit Seitenschlitzen mit verlängertem Rückenteil, der Kordelzug an der Kapuze und die geraden Ärmel mit hängender Schulter verleihen Ihren Freizeitlooks urbanen Stil.Athletic Life ist die Lifestyle-Linie von Freddy, die sich gern sportlich und zugleich erlesen kleiden.
<G-vec00499-001-s594><add.verleihen><en> The unique decorative pillow slips add a sofa or chair made of euro pallets an exceptional charm.
<G-vec00499-001-s594><add.verleihen><de> Die einzigartigen Zierkissen verleihen einem Sofa oder Stuhl, gefertigt aus Euro-Paletten, einen außergewöhnlichen Charme.
<G-vec00499-001-s595><add.verleihen><en> Keratin rich to add volume, structure and shine, the conditioner will leave your hair feeling healthy and replenished.
<G-vec00499-001-s595><add.verleihen><de> Reichhaltig an Keratin, um Volumen, Struktur und Glanz zu verleihen; die Spülung wird dein Haar revitalisiert mit einer verbesserten Feuchtigkeit und Gesundheit hinterlassen.
<G-vec00499-001-s596><add.verleihen><en> If you want to enhance your performance in the gym and add serious size onto your frame, look no further than Storm.
<G-vec00499-001-s596><add.verleihen><de> Wenn Sie Ihre Leistung im Fitnessstudio verbessern und Ihrem Rahmen eine ernstzunehmende Größe verleihen möchten, dann sind Sie bei Storm genau richtig.
<G-vec00499-001-s597><add.verleihen><en> When sliced the juice can be used to add flavour to a dish.
<G-vec00499-001-s597><add.verleihen><de> Man kann auch den Saft der Scheiben benutzen um Gerichten Geschmack zu verleihen.
<G-vec00499-001-s598><add.verleihen><en> A main highlight this season is the white silk blouses with transparent sleeves that will add a certain je ne sais quoi to any outfit.
<G-vec00499-001-s598><add.verleihen><de> Besonderes Highlight diese Saison sind weiße Seidenblusen mit transparenten Ärmeln, die jedem Look das gewisse Etwas verleihen.
<G-vec00499-001-s599><add.verleihen><en> Taps are available in stainless steel as well as the latest ceramic colours: an ideal choice for anyone looking to add a very special touch to their kitchen.
<G-vec00499-001-s599><add.verleihen><de> Die Armaturen sind in Edelstahl sowie in aktuellen Keramikfarben verfügbar: ideal für alle, die ihrer Küche das gewisse Etwas verleihen wollen.
<G-vec00499-001-s600><add.verleihen><en> The grey and white highlights add depth to the supple and soft Genuine Rabbit Fur hood and lined interior.
<G-vec00499-001-s600><add.verleihen><de> Die grauen und weißen Highlights der geschmeidig und weich echtes Kaninchenfell Haube Tiefe verleihen und Innenfutter.
<G-vec00499-001-s601><add.verleihen><en> Damaged leaves will not add beauty to the anemone.
<G-vec00499-001-s601><add.verleihen><de> Beschädigte Blätter werden der Anemone keine Schönheit verleihen.
<G-vec00499-001-s602><add.verleihen><en> Even if the weather forecast isn't calling for snow, you can easily add some winter flair to your pictures using the Snowflakes Frame Pack by AKVIS.
<G-vec00499-001-s602><add.verleihen><de> Auch wenn die Wettervorhersage nicht so vielversprechend ausfällt, können Sie das Schneeflocken-Paket von AKVIS benutzen, um Ihren Bildern etwas Winterflair zu verleihen.
<G-vec00499-001-s603><add.verleihen><en> With Triluminos Colour you'll enjoy brilliant images and a wide range of colours which add depth to any scene
<G-vec00499-001-s603><add.verleihen><de> Mit Triluminos Colour genießen Sie brillante Bilder und eine Vielzahl von Farben, die jeder Szene Tiefe verleihen.
<G-vec00499-001-s604><add.verleihen><en> The modern decorative table cloths will add a fresh color to your dining room.
<G-vec00499-001-s604><add.verleihen><de> Die modernen dekorativen Tischdecken verleihen Ihrem Esszimmer eine frische Farbe.
<G-vec00499-001-s605><add.verleihen><en> Blue support caps add bulk to the heel wrap with grey top lines and extra material bits creating balance through a much more neutral tone.
<G-vec00499-001-s605><add.verleihen><de> Blaue Stützkappen verleihen dem Fersenwickel mehr Volumen mit grauen Oberlinien und zusätzlichen Materialteilen, die durch einen viel neutraleren Farbton ein Gleichgewicht schaffen.
<G-vec00499-001-s606><add.verleihen><en> Unique details like local fabrics, alcoves and stained-glass windows add an elegant touch.
<G-vec00499-001-s606><add.verleihen><de> Einzigartige Details wie lokale Stoffe, Nischen und Glasmalereien verleihen den Zimmern eine elegante Note.
<G-vec00499-001-s607><add.verleihen><en> GOI paste is used to add shine to the product.
<G-vec00499-001-s607><add.verleihen><de> GOI-Paste wird verwendet, um dem Produkt Glanz zu verleihen.
<G-vec00407-001-s608><add.zugeben><en> Gradually add the rest of the milk and the eggs, one at a time, and whisk to a smooth batter with no lumps.
<G-vec00407-001-s608><add.zugeben><de> Die restliche Milch und die Eier zugeben, wieder verrühren, bis der Teig glatt und ohne Klumpen ist.
<G-vec00407-001-s609><add.zugeben><en> Add beef stock and let all simmer about 15 minutes.
<G-vec00407-001-s609><add.zugeben><de> Die Suppe zugeben und zugedeckt etwa 15 Minuten dünsten.
<G-vec00407-001-s610><add.zugeben><en> Add the vinegar, oil and mustard and combine.
<G-vec00407-001-s610><add.zugeben><de> Essig, Öl und Senf zugeben und vermengen.
<G-vec00407-001-s611><add.zugeben><en> Add egg yolk, port, red, simple syrup and scotch whisky.
<G-vec00407-001-s611><add.zugeben><de> Eigelb, Portwein, rot, Zuckersirup und Schottischer Whisky zugeben.
<G-vec00407-001-s612><add.zugeben><en> Add much liquid until the dough is thick but running.
<G-vec00407-001-s612><add.zugeben><de> So viel Flüssigkeit zugeben, dass ein zähflüssiger Teig entsteht.
<G-vec00407-001-s613><add.zugeben><en> Dosage EHEIM Plant Care 7 Days Fertilizer: Add weekly 10 ml per 100 litres of aquarium water.
<G-vec00407-001-s613><add.zugeben><de> Dosierung EHEIM Plant Care 7 Tage Langzeitdünger: Wöchentlich 10 ml auf 100 Liter Aquarienwasser zugeben.
<G-vec00407-001-s614><add.zugeben><en> Combine water and egg, add 0,5 tsp.
<G-vec00407-001-s614><add.zugeben><de> Wasser und Ei mischen, 0,5 TL zugeben.
<G-vec00407-001-s615><add.zugeben><en> Add stock and saffron, mix.
<G-vec00407-001-s615><add.zugeben><de> Brühe und Safran zugeben, verrühren.
<G-vec00407-001-s616><add.zugeben><en> Inside your basket, you can edit the goods you already inserted in or add and remove the new goods.
<G-vec00407-001-s616><add.zugeben><de> Im Korb kann man Warenmenge einrichten, die Produkte zugeben oder abnehmen und im Korb sehen Sie auch die gesamte Einzahlungssumme.
<G-vec00407-001-s617><add.zugeben><en> Add daily when watering the plant in the first 2 weeks.
<G-vec00407-001-s617><add.zugeben><de> In den ersten 2 Wochen täglich während des Gießens zugeben.
<G-vec00407-001-s618><add.zugeben><en> Juice of lemons squeeze into a cup, mix it with chilled water and add ice.
<G-vec00407-001-s618><add.zugeben><de> Saft von Zitronen in eine Tasse drücken, mit kaltem Wasser mischen und Eis zugeben.
<G-vec00407-001-s619><add.zugeben><en> Add Absolut Pears.
<G-vec00407-001-s619><add.zugeben><de> Absolut Pears zugeben.
<G-vec00407-001-s620><add.zugeben><en> Add black raspberry liqueur, Absolut Vodka and triple sec.
<G-vec00407-001-s620><add.zugeben><de> Schwarzer Himbeerlikör, Absolut Vodka und Triple Sec zugeben.
<G-vec00407-001-s621><add.zugeben><en> Add wine, vinegar and boiled noodles, mix well and bring to the boil.
<G-vec00407-001-s621><add.zugeben><de> Wein, Essig und die gekochten Nudeln zugeben, alles gut vermischen und aufkochen.
<G-vec00407-001-s622><add.zugeben><en> After 25 minutes, add the vegetables and continue to steam.
<G-vec00407-001-s622><add.zugeben><de> Nach 25 Minuten Gemüse zugeben und weiterdämpfen.
<G-vec00407-001-s623><add.zugeben><en> Add the peeled and finely sliced onions.
<G-vec00407-001-s623><add.zugeben><de> Die Zwiebeln schälen, in feine Streifen schneiden und zugeben.
<G-vec00407-001-s624><add.zugeben><en> Mix well, add corn flour, breadcrumbs and flour.
<G-vec00407-001-s624><add.zugeben><de> Gut vermischen, Maismehl, Paniermehl und Mehl zugeben.
<G-vec00407-001-s625><add.zugeben><en> Add the flour bit by bit until the dow does not stick to your hands anymore.
<G-vec00407-001-s625><add.zugeben><de> Dabei das Mehl nur nach und nach zugeben, bis der Teig nicht mehr an den Händen klebt.
<G-vec00407-001-s626><add.zugeben><en> If necessary, add some more water (possibly up to about 80 ml).
<G-vec00407-001-s626><add.zugeben><de> Gegebenenfalls mehr Wasser zugeben (eventuell etwa 80 ml).
<G-vec00499-001-s616><add.zugeben><en> Inside your basket, you can edit the goods you already inserted in or add and remove the new goods.
<G-vec00499-001-s616><add.zugeben><de> Im Korb kann man Warenmenge einrichten, die Produkte zugeben oder abnehmen und im Korb sehen Sie auch die gesamte Einzahlungssumme.
<G-vec00499-001-s625><add.zugeben><en> Add the flour bit by bit until the dow does not stick to your hands anymore.
<G-vec00499-001-s625><add.zugeben><de> Dabei das Mehl nur nach und nach zugeben, bis der Teig nicht mehr an den Händen klebt.
