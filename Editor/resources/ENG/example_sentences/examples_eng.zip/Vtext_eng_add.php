<G-vec00060-001-s038><add.addieren><en> It's used to add contents of a diary or news by the owner (blogger).
<G-vec00060-001-s038><add.addieren><de> Es wird verwendet, um Inhalt eines Tagebuchs oder Nachrichten zu addieren vom Inhaber (blogger).
<G-vec00060-001-s039><add.addieren><en> Whether it’s a breakfast bar for serving food or additional prep space for cooking, ample kitchen counters add huge value; a feature you will see in all Deepblue SmartHouse homes.
<G-vec00060-001-s039><add.addieren><de> Ob es ein Frühstücksbar für dienende Nahrung oder zusätzlichen Vorbereitungsraum für das Kochen ist, addieren reichliche Küchenarbeitsplatten enormen Wert; eine Eigenschaft, die Sie in allen Häusern Deepblue SmartHouse sehen.
<G-vec00060-001-s040><add.addieren><en> Add up numbers before the time runs out.
<G-vec00060-001-s040><add.addieren><de> Addieren von Zahlen, bevor die Zeit abläuft.
<G-vec00060-001-s041><add.addieren><en> But take a good, long moment to check whether you need to add it to or subtract it from the time given by your precious timepiece to ascertain the true solar time.
<G-vec00060-001-s041><add.addieren><de> Nehmen Sie sich aber die nötige Zeit, um herauszufinden, ob man addieren oder subtrahieren muss, wenn man mit der Stundenanzeige des guten Stücks die wahre Sonnenzeit ausrechnen will.
<G-vec00060-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00060-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00060-001-s043><add.addieren><en> We also can add wood frame outside as clients request.
<G-vec00060-001-s043><add.addieren><de> Wir können hölzerne Rahmenaußenseite auch addieren wie Kundenantrag.
<G-vec00060-001-s044><add.addieren><en> Now we can add the velocity change in cell C3 to this value.
<G-vec00060-001-s044><add.addieren><de> Jetzt können wir den Geschwindigkeitswert in Zelle C3 zu diesem Wert addieren.
<G-vec00060-001-s045><add.addieren><en> 9, Option: outside baffle add the flap function, which made the cardboard orientation more exact, avoid to
<G-vec00060-001-s045><add.addieren><de> 9, Wahl: äußeres Leitblech addieren die Landeklappenfunktion, die die Papporientierung genauer machte, vermeiden, um zu vergeuden.
<G-vec00060-001-s046><add.addieren><en> We must never add, subtract or change the doctrine of Christ or to whom He gave authority to record His written word.
<G-vec00060-001-s046><add.addieren><de> Wir dürfen nie addieren, subtrahieren oder die Lehre von Christus oder zu denen er Vollmacht gab, seine geschriebene Wort aufzunehmen.
<G-vec00060-001-s047><add.addieren><en> 1 Due to rounding it is possible that individual figures presented in this press release may not add up exactly to the totals shown and that the nine-month figures listed may not follow from adding up the individual quarterly figures.
<G-vec00060-001-s047><add.addieren><de> 1 Aufgrund von Rundungen ist es möglich, dass sich einzelne Zahlen in dieser Pressemitteilung nicht genau zur angegebenen Summe addieren lassen und sich die Neunmonatszahlen nicht aus der Aufsummierung der einzelnen Quartalszahlen ergeben.
<G-vec00060-001-s048><add.addieren><en> "Please enter this formula =SUMIF(A2:A6,""*KTE*"",B2:B6) into a blank cell, and press Enter key, then all the numbers in column B where the corresponding cell in column A contains text “KTE” will add up."
<G-vec00060-001-s048><add.addieren><de> "Bitte geben Sie diese Formel ein = SUMIF (A2: A6 ""TEC * *"" B2: B6) in eine leere Zelle und drücken Sie Weiter Schlüssel, dann addieren sich alle Zahlen in Spalte B, wo die entsprechende Zelle in Spalte A den Text ""KTE"" enthält."
<G-vec00060-001-s049><add.addieren><en> On friday we must add 3 days to get next monday, on saturday 2 days are to be added and for all other weekdays the next day is the next working day.
<G-vec00060-001-s049><add.addieren><de> Am Freitag muss ich 3 Tage addieren, um auf den kommenden Montag zu kommen, am Samstag 2 Tage und an allen anderen Tagen ist der nächste Tag auch der nächste Arbeitstag.
<G-vec00060-001-s050><add.addieren><en> We offer 5 double bedrooms, each of which has the possibility to add up to 2 single beds.
<G-vec00060-001-s050><add.addieren><de> Wir bieten 5 Doppelzimmer, von denen jeder die Möglichkeit, 5 Einzelbetten zu addieren hat.
<G-vec00060-001-s051><add.addieren><en> The waste is generated when people are in too big a hurry to build more sites, add more products, and get more traffic to sites that can convert sometimes 1000% BETTER than they do now.
<G-vec00060-001-s051><add.addieren><de> Die Vergeudung wird erzeugt, wenn Leute in einer zu großen Hast sind, zum von von mehr Aufstellungsorten zu errichten, von von mehr Produkten zu addieren und mehr Verkehrs an Aufstellungsorte zu gelangen, die manchmal 1000% umwandeln können, das BESSER ist, als sie jetzt.
<G-vec00060-001-s052><add.addieren><en> • Bet per Line: Click this button to add or subtract from your wager per activated payline.
<G-vec00060-001-s052><add.addieren><de> • Zeileneinsatz: Klicken Sie auf diesen Button, um Ihren Einsatz pro aktivierter Gewinnlinie zu addieren oder abzuziehen.
<G-vec00060-001-s053><add.addieren><en> They automatically add 0.3 mm per year to this region, not because the sea is rising, but to compensate for an alleged isostatic increase in land.
<G-vec00060-001-s053><add.addieren><de> Sie addieren sich automatisch um 0,3 mm pro Jahr in dieser Region, nicht weil das Meer steigt, sondern um einen angeblichen isostatischen Anstieg des Landes auszugleichen.
<G-vec00060-001-s054><add.addieren><en> Many times an owner of an independent Detailing Shop will wish to add those items he/she believes their customers want.
<G-vec00060-001-s054><add.addieren><de> Viele Mal möchte ein Inhaber eines unabhängigen einzeln aufführengeschäftes jene Einzelteile addieren, die he/she glaubt, dass ihre Kunden wünschen.
<G-vec00060-001-s055><add.addieren><en> Unfortunately, we do a little bit of celebrating during this time of year and add up extra baggage when the New Year appears.
<G-vec00060-001-s055><add.addieren><de> Leider tun wir ein wenig vom Feiern während dieser Zeit des Jahres und addieren oben Extragepäck, wenn das neue Jahr erscheint.
<G-vec00060-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
<G-vec00060-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00407-001-s042><add.addieren><en> If two of these magnetic moments are coupled, two options result: Either the magnetic moments add up to a stronger moment or they compensate each other and magnetism disappears.
<G-vec00407-001-s042><add.addieren><de> Koppelt man zwei solcher magnetischer Momente zusammen, ergeben sich zwei Möglichkeiten: Entweder die magnetischen Momente addieren sich zu einem stärkeren Moment – oder sie kompensieren einander und der Magnetismus verschwindet.
<G-vec00407-001-s056><add.addieren><en> In order to calculate the mean, you must add all the values of x, then divide by the number of values, using the following formula:
<G-vec00407-001-s056><add.addieren><de> Berechne den Mittelwert von x. Um den Mittelwert zu berechnen, musst du alle Werte für x addieren und dann durch die Anzahl der Werte teilen, wie in obiger Formel angegeben.
<G-vec00060-001-s076><add.dazugeben><en> Add the coconut milk and blend with an immersion blender.
<G-vec00060-001-s076><add.dazugeben><de> Kokosmilch dazugeben und alles mit dem Pürierstab pürieren.
<G-vec00060-001-s077><add.dazugeben><en> Put a caramel thermometer inside the pot: add food coloring, cinnamon and cloves as soon as the temperature reaches 100 degrees.
<G-vec00060-001-s077><add.dazugeben><de> Dann einen Karamell-Thermometer in den Topf legen: die Lebensmittelfarbe, Zimt und Gewürznelken dazugeben, sobald die Temperatur auf 100° ist.
<G-vec00060-001-s078><add.dazugeben><en> Finally, add vinegar and garnish with the hard-boiled eggs.
<G-vec00060-001-s078><add.dazugeben><de> Zum Schluss Essig dazugeben und mit den hartgekochten Eiern garnieren.
<G-vec00060-001-s079><add.dazugeben><en> 13 'But if he should ever wish to redeem it, then he shall add one-fifth of it to your valuation.
<G-vec00060-001-s079><add.dazugeben><de> 13 Will es aber jemand unbedingt wieder auslösen, so soll er den fünften Teil deiner Schätzung dazugeben.
<G-vec00060-001-s080><add.dazugeben><en> Add Grappa Nonino Chardonnay in barriques, Amaro Nonino and ice.
<G-vec00060-001-s080><add.dazugeben><de> Grappa Nonino Monovitigno® Chardonnay 12 Monate in Barriques, Amaro Nonino und Eis dazugeben.
<G-vec00060-001-s081><add.dazugeben><en> Weigh the pulp and add equal amount of sugar.
<G-vec00060-001-s081><add.dazugeben><de> Die gleiche Menge an Zucker in einem Topf leicht erhitzen, Zitronensaft dazugeben.
<G-vec00060-001-s082><add.dazugeben><en> If you think the salsa is too spicy, add the avocado to the blender and mix again very well.
<G-vec00060-001-s082><add.dazugeben><de> Wem die Salsa zu scharf ist, der kann die Avocado dazugeben und die Sauce nochmals gut pürieren.
<G-vec00060-001-s083><add.dazugeben><en> Wash the potatoes and boil them in salted water in their skin. Meanwhile, brown the bacon with butter in a pan and, after a few minutes, add the chopped onion, turn off as soon as the onion is soft and transparent.
<G-vec00060-001-s083><add.dazugeben><de> Die Kartoffeln waschen und mit der Schale im salzigen Wasser kochen; in der Zeit den Speck mit Butter in einer Pfanne anbraten, nach einigen Minuten die gehackte Zwiebel dazugeben und köcheln lassen, solange bis sie weich und glasig ausschaut.
<G-vec00060-001-s084><add.dazugeben><en> Add the flour and lightly brown it.
<G-vec00060-001-s084><add.dazugeben><de> Mehl und Hefe vermischen und die Milch dazugeben.
<G-vec00060-001-s085><add.dazugeben><en> Add caramel right before serving.
<G-vec00060-001-s085><add.dazugeben><de> Kurz vor dem Servieren den Karamell dazugeben.
<G-vec00060-001-s086><add.dazugeben><en> You can add also nuts like cashew for example.
<G-vec00060-001-s086><add.dazugeben><de> Man kann auch Nüsse wie zum Beispiel Cashew dazugeben.
<G-vec00060-001-s087><add.dazugeben><en> Add chanterelles and thyme and stew all until al dente.
<G-vec00060-001-s087><add.dazugeben><de> Eierschwammerl und Thymian dazugeben und alles bissfest dünsten.
<G-vec00060-001-s088><add.dazugeben><en> Heat the milk in a pan and add the oatmeal.
<G-vec00060-001-s088><add.dazugeben><de> Die Milch in einem Topf erhitzen und die Haferflocken dazugeben.
<G-vec00060-001-s089><add.dazugeben><en> Then add the water, the grated potato, the stock cubes and 1 teaspoon of salt and bring to the boil.
<G-vec00060-001-s089><add.dazugeben><de> Anschließend Wasser, geriebene Kartoffeln, Gemüsebouillonwürfel und 1 TL Salz dazugeben und zum Kochen bringen.
<G-vec00060-001-s090><add.dazugeben><en> Add meat cubes and fry them.
<G-vec00060-001-s090><add.dazugeben><de> Fleischwürfel dazugeben und anbraten.
<G-vec00060-001-s091><add.dazugeben><en> Add the shredded chicken and season with a pinch of salt, pepper and parsley.
<G-vec00060-001-s091><add.dazugeben><de> Das zerkleinerte Hähnchen dazugeben und mit einer Prise Salz, Pfeffer und Petersilie würzen.
<G-vec00060-001-s092><add.dazugeben><en> Than add bananas, pineapple (and other fruits), add the coconut ice and pour the vegetable broth on it.
<G-vec00060-001-s092><add.dazugeben><de> Nun Bananen, Ananas (und weitere Früchte) dazugeben, Kokosraspeln beifügen und mit der Gemüsebouillon aufgiessen.
<G-vec00060-001-s093><add.dazugeben><en> Bake it in a preheated oven for 30 minutes at 200 ° / gas level 4, add seasoned lamb chops to it depending on the thickness at the last 10 – 15 minutes.
<G-vec00060-001-s093><add.dazugeben><de> 30 Minuten im auf 200° / Gas Stufe 4 vorgeheizten Ofen backen, gewürzte Lammkotelett je nach Dicke für die letzten 10-15 Minuten dazugeben.
<G-vec00060-001-s094><add.dazugeben><en> As soon as all the sugar is melted, add soft butter and salt (we suggest you to go away from the pan as it could splatter and you might burn yourself).
<G-vec00060-001-s094><add.dazugeben><de> Wenn der ganze Zucker geschmolzen ist, weiche Butter und Salz dazugeben (wir empfehlen, sich von der Pfanne zu entfernen, da es spritzen kann undman sich verbrennen könnte).
<G-vec00407-001-s076><add.dazugeben><en> Add the coconut milk and blend with an immersion blender.
<G-vec00407-001-s076><add.dazugeben><de> Kokosmilch dazugeben und alles mit dem Pürierstab pürieren.
<G-vec00407-001-s078><add.dazugeben><en> Finally, add vinegar and garnish with the hard-boiled eggs.
<G-vec00407-001-s078><add.dazugeben><de> Zum Schluss Essig dazugeben und mit den hartgekochten Eiern garnieren.
<G-vec00407-001-s081><add.dazugeben><en> Weigh the pulp and add equal amount of sugar.
<G-vec00407-001-s081><add.dazugeben><de> Die gleiche Menge an Zucker in einem Topf leicht erhitzen, Zitronensaft dazugeben.
<G-vec00407-001-s082><add.dazugeben><en> If you think the salsa is too spicy, add the avocado to the blender and mix again very well.
<G-vec00407-001-s082><add.dazugeben><de> Wem die Salsa zu scharf ist, der kann die Avocado dazugeben und die Sauce nochmals gut pürieren.
<G-vec00499-001-s091><add.dazugeben><en> Add the shredded chicken and season with a pinch of salt, pepper and parsley.
<G-vec00499-001-s091><add.dazugeben><de> Das zerkleinerte Hähnchen dazugeben und mit einer Prise Salz, Pfeffer und Petersilie würzen.
<G-vec00407-001-s133><add.einfügen><en> As the articles are published we will add links to them from here.
<G-vec00407-001-s133><add.einfügen><de> Sobald die Artikel veröffentlicht werden, werden wir die Links hier einfügen.
<G-vec00407-001-s134><add.einfügen><en> Value chain is a high-level model of how businesses receive raw materials as input, add value to the raw materials through various processes, and sell finished products to customers.
<G-vec00407-001-s134><add.einfügen><de> Die Wertschöpfungskette ist ein Hochmodell, das stellt dar, wie Unternehmen Rohstoffe als Eingabe erhalten, wie Mehrwert für die Rohstoffe durch die verschiedenen Prozesse einfügen, und wie fertige Produkte an Kunden verkaufen.
<G-vec00407-001-s135><add.einfügen><en> Please note: You can create as many categories as you need; add the same score to different categories; present catalogues in other language versions.
<G-vec00407-001-s135><add.einfügen><de> Zu Ihrer Information: Sie können so viele Kategorien erstellen wie Sie möchten, eine Partitur in mehrere Kategorien einfügen und auch die Kategorien in vier Sprachversionen präsentieren.
<G-vec00407-001-s136><add.einfügen><en> You shouldn't add an IP address to your access list just because one time your hostname appeared as numbers.
<G-vec00407-001-s136><add.einfügen><de> Du solltest keine Nummern in deine Access Liste einfügen, nur weil Du einmal zufällig eine IP Adresse zugewiesen bekommen hast.
<G-vec00407-001-s137><add.einfügen><en> In addition, you can add remarks to any address in the text box provided for this purpose.
<G-vec00407-001-s137><add.einfügen><de> Sie können außerdem eine Bemerkung zu jedem Adressdatensatz in das dafür vorgesehene Textfeld einfügen.
<G-vec00407-001-s138><add.einfügen><en> Add an Alkacon GeoMap to your website by Drag & Drop.
<G-vec00407-001-s138><add.einfügen><de> Einfügen einer GeoMap auf einer Webseite ganz einfach per Drag & Drop.
<G-vec00407-001-s139><add.einfügen><en> You can use any number of free and paid plugins to add your code.
<G-vec00407-001-s139><add.einfügen><de> Sie können eine beliebige Anzahl von kostenlosen und kostenpflichtigen Plugins, um Ihren Code einfügen.
<G-vec00407-001-s140><add.einfügen><en> Put the cherries (whole) in a pan together with Madeira wine and boil until the wine evaporates completely; add the sherry vinegar at the end.
<G-vec00407-001-s140><add.einfügen><de> In einem Topf die Kirschen mit Kerne und den Madeirawein und bis zur vollständige Verdampfung kochen; am Ende, Sherry-Essig einfügen.
<G-vec00407-001-s141><add.einfügen><en> For example, you can add your favourite transactions to the easy access menu in a more graphical form.
<G-vec00407-001-s141><add.einfügen><de> Sie können zum Beispiel Ihre Lieblingstransaktionen in einer geeigneten grafischen Form in das Easy Access Menü einfügen.
<G-vec00407-001-s142><add.einfügen><en> You can also add a video straight from the email builder.
<G-vec00407-001-s142><add.einfügen><de> Sie können auch ein Video direkt aus dem E-Mail Ersteller einfügen.
<G-vec00407-001-s143><add.einfügen><en> Find the document you would like to add and click on its name.
<G-vec00407-001-s143><add.einfügen><de> Suchen Sie das Dokument das Sie einfügen wollen, und klicken Sie auf den Namen.
<G-vec00407-001-s144><add.einfügen><en> Here you can edit the number of items by clicking on the item add, or delete or empty the whole basket.
<G-vec00407-001-s144><add.einfügen><de> Hier können Sie selbst noch die Anzahl der Elemente bearbeiten, in dem Sie auf Einfügen oder Löschen klicken, oder den gesamten Korb ausleeren.
<G-vec00407-001-s145><add.einfügen><en> If you add an A/B test to the campaign, you must create at least two versions of the message.
<G-vec00407-001-s145><add.einfügen><de> Wenn Sie einen A/B-Test in eine Kampagne einfügen, müssen Sie mindestens zwei Varianten einer Nachricht erstellen.
<G-vec00407-001-s146><add.einfügen><en> You can add graphics or images to glossary entries, as you can to other text.
<G-vec00407-001-s146><add.einfügen><de> In die Glossareinträge können Sie wie bei anderen Texten auch Grafiken oder Bilder einfügen.
<G-vec00407-001-s147><add.einfügen><en> You also can add the name of the sender.
<G-vec00407-001-s147><add.einfügen><de> Sie können auch den Namen des Absenders einfügen.
<G-vec00407-001-s148><add.einfügen><en> You’ll also have access to some editing options to cut out frames, add watermarks or add size and duration.
<G-vec00407-001-s148><add.einfügen><de> Darüber hinaus haben Sie Zugriff auf einige Bearbeitungsoptionen zum Ausschneiden von Rahmen, Hinzufügen von Wasserzeichen oder einfügen der Größe und Dauer.
<G-vec00407-001-s149><add.einfügen><en> Advanced/Add picture to the background...
<G-vec00407-001-s149><add.einfügen><de> Erweitert/Hintergrundbild einfügen...
<G-vec00407-001-s150><add.einfügen><en> For example, you could add a “TV” tag on all of the pages where you sell televisions.
<G-vec00407-001-s150><add.einfügen><de> "So könnten Sie etwa auf allen Seiten, auf denen Sie Fernseher anbieten, das Tag ""TV"" einfügen."
<G-vec00407-001-s151><add.einfügen><en> You have acquired a new facility and whish to add it to your existing portfolio.
<G-vec00407-001-s151><add.einfügen><de> Sie haben eine neue Bestandsimmobilie und möchten diese neu in ihr Portfolio einfügen.
<G-vec00060-001-s152><add.ergänzen><en> At first dissolve soda, then in the small portions add kremneftoristyj sodium at careful hashing.
<G-vec00060-001-s152><add.ergänzen><de> lösen die Soda Zuerst auf, dann von den kleinen Portionen ergänzen kremneftoristyj das Natrium bei der sorgfältigen Vermischung.
<G-vec00060-001-s153><add.ergänzen><en> We add fresh tonic to taste and a lemon slice.
<G-vec00060-001-s153><add.ergänzen><de> Wir ergänzen frisch tonik nach dem Geschmack und das Scheibchen der Zitrone.
<G-vec00060-001-s154><add.ergänzen><en> In a circle we shake up 2 eggs to homogeneous mass, we salt a little, we add to a support, we mix everything.
<G-vec00060-001-s154><add.ergänzen><de> Im Krug ist 2 Eier bis zur gleichartigen Masse gerührt, wir salzen ein wenig, wir ergänzen in oparu, alles ist gemischt.
<G-vec00060-001-s155><add.ergänzen><en> In case you want that the wall could be washed by means of a damp rag, it is necessary to add a little primer to solution.
<G-vec00060-001-s155><add.ergänzen><de> Falls Sie wollen, dass man die Wand mit Hilfe des feuchten Lappens waschen konnte, ist nötig es in die Lösung ein wenig Grundierungen zu ergänzen.
<G-vec00060-001-s156><add.ergänzen><en> If you are not able to do needlework, but at this expert in computer, it is possible to make presentation of photos: now there are many programs which allow to combine literally in some clicks photos, to make transitions between them, to add the text, to impose music, and then to keep presentation in video format.
<G-vec00060-001-s156><add.ergänzen><de> "Wenn Sie rukodelnitschat nicht verstehen, aber kann man dabei ""auf du"" mit dem Computer, die Präsentation aus den Fotografien machen: jetzt geben es viel Programme, die buchstäblich in etwas klikow zulassen die Fotografien zu vereinen, die Übergänge zwischen ihnen zu machen, den Text zu ergänzen, die Musik, und später aufzuerlegen, die Präsentation im Format Videos aufzusparen."
<G-vec00060-001-s157><add.ergänzen><en> After registration of the Account Licensee has the right to realize filling of the Account, the Personal page and other elements of the Professional network the Content, to add photos and other materials according to the provided functionality, to create pages of the organizations, to enter groups and to use other functions provided by the Licensor in case of use of the Professional network on condition of observance of the present Agreement.
<G-vec00060-001-s157><add.ergänzen><de> Nach der Registrierung des Benutzerkontos ist der Lizenznehmer berechtigt, die Füllung des Benutzerkontos, der Personalseite und anderer Elemente des Professionellen Netzes von Kontentom zu verwirklichen, die Fotografien und andere Materialien entsprechend gewährt фyHkциoHaлoM zu ergänzen, die Seiten der Organisationen zu schaffen, die Gruppen zu betreten und, andere Funktionen zu benutzen, die vom Lizenzgeber unter Anwendung vom Professionellen Netz vorbehaltlich der Beachtung des gegenwärtigen Abkommens gewährt sind.
<G-vec00060-001-s158><add.ergänzen><en> Approximately in an hour, after dissolution of glue available in a paint, there at careful hashing add in the small portions drying oil (before reception homogeneous emulsii) and plant with water to the necessary density.
<G-vec00060-001-s158><add.ergänzen><de> Ungefähr ergänzen nach der Stunde, nach der Auflösung des in der Farbe vorhandenen Leims, dorthin trennen bei der sorgfältigen Vermischung von den kleinen Portionen olifu (bis zum Erhalten der gleichartigen Emulsion) und zu Wasser bis zur nötigen Dichte.
<G-vec00060-001-s159><add.ergänzen><en> "No special package has been added yet... You can add it using the ""Add"" button."
<G-vec00060-001-s159><add.ergänzen><de> "Bisher ist kein Aufenthaltspaket eingegeben... Ergänzen Sie mit der Taste ""Hinzufügen""."
<G-vec00060-001-s160><add.ergänzen><en> Four times mix the turned-out substance then add all other components.
<G-vec00060-001-s160><add.ergänzen><de> Die sich ergebende Substation vier Male vermischen, wonach alle übrigen Komponenten ergänzen.
<G-vec00060-001-s161><add.ergänzen><en> The large poplars, pine and palm trees, acacias and oleanders, bay laurel and other Mediterranean plants add to the beauty of the park.
<G-vec00060-001-s161><add.ergänzen><de> Die großen Pappeln, Pinien, Palmen und Akazien und Oleander, Lorbeer Bucht und anderen mediterranen Pflanzen ergänzen die Schönheit des Parks.
<G-vec00060-001-s162><add.ergänzen><en> In the received mix at constant hashing add a chalk before reception of demanded density.
<G-vec00060-001-s162><add.ergänzen><de> In die bekommene Mischung bei der ständigen Vermischung ergänzen die Kreide bis zum Erhalten der geforderten Dichte.
<G-vec00060-001-s163><add.ergänzen><en> With our wide-ranging selection of day trips, you can take advantage of this during your language study abroad and road-test, consolidate and add to what you have already learnt in an interesting and fun way.
<G-vec00060-001-s163><add.ergänzen><de> Mit unserem breitgefächerten Angebot an Ausflügen können Sie sich diesen Umstand während Ihres Sprachaufenthalts zunutze machen und auf interessante und spassige Weise Gelerntes direkt in der Praxis erproben, festigen und ergänzen.
<G-vec00060-001-s164><add.ergänzen><en> Greens small to chop and add to a liver, then to fry some more minutes.
<G-vec00060-001-s164><add.ergänzen><de> Das Kraut klein porubit und zur Leber, dann obscharit noch etwas Minuten zu ergänzen.
<G-vec00060-001-s165><add.ergänzen><en> With the fifth package you can add further Performance Services to boost your performance.
<G-vec00060-001-s165><add.ergänzen><de> Im fünften Paket ergänzen Sie zusätzliche Performance-Services zur Steigerung Ihrer Leistungsstärke.
<G-vec00060-001-s166><add.ergänzen><en> Sausage to slice, add to vegetables and to allow soup to begin to boil once again.
<G-vec00060-001-s166><add.ergänzen><de> Die Wurst von den Scheibchen zu schneiden, zum Gemüse zu ergänzen und, der Suppe noch einmal zu gestatten, aufzukochen.
<G-vec00060-001-s167><add.ergänzen><en> And we decided to add pattern drawing gold paint on the tab intended for a cover.
<G-vec00060-001-s167><add.ergänzen><de> Und uns hat sich entschieden, die Schablonenzeichnung von der goldenen Farbe auf wkladku, vorbestimmt für den Deckel zu ergänzen.
<G-vec00060-001-s168><add.ergänzen><en> it is possible to add to classical spices also others, but do not hurry to mix everything at once.
<G-vec00060-001-s168><add.ergänzen><de> Zu den klassischen Gewürzen kann man und andere ergänzen, aber Sie beeilen sich nicht, allen sofort zu mischen.
<G-vec00060-001-s169><add.ergänzen><en> For bigger reliability it is possible to add today's date to it.
<G-vec00060-001-s169><add.ergänzen><de> Für bolschej der Zuverlässigkeit zu ihm kann man das heutige Datum ergänzen.
<G-vec00060-001-s170><add.ergänzen><en> Contains in some fruit and berries a little zheliruyushchy substance of pectin therefore in order that jam had a necessary jellylike consistence, it is possible to add at a laying of products to the container ready apple pectin.
<G-vec00060-001-s170><add.ergänzen><de> In einigen Früchten und den Beeren ist wenig schelirujuschtschego die Stoffe des Pektins, deshalb enthalten, damit die Marmelade notwendig scheleobrasnuju die Konsistenz hatte, man kann bei der Grundsteinlegung der Lebensmittel in den Container das fertige Apfelpektin ergänzen.
<G-vec00060-001-s171><add.ergänzen><en> In a couple of minutes add the cut onions.
<G-vec00060-001-s171><add.ergänzen><de> Durch ein Paar Minuten ergänzen Sie naresannyj die Zwiebel.
<G-vec00060-001-s172><add.ergänzen><en> after you crumbled cookies (it is possible to use for this purpose the blender) add it to the softened butter.
<G-vec00060-001-s172><add.ergänzen><de> Nachdem Sie pokroschili das Gebäck (kann man dazu blender verwenden) es in die erweichte Butter ergänzen Sie.
<G-vec00060-001-s173><add.ergänzen><en> In a kastryulka heat cream and add a flour.
<G-vec00060-001-s173><add.ergänzen><de> In kastrjulke erwärmen Sie die Sahne und ergänzen Sie das Mehl.
<G-vec00060-001-s174><add.ergänzen><en> When berries of a black-fruited mountain ash are drawn, again bring them to boiling, add the remained sugar and continue to cook.
<G-vec00060-001-s174><add.ergänzen><de> Wenn die Beeren tschernoplodnoj die Vogelbeerbäume bestanden werden werden, führen Sie sie bis zum Kochen wieder hin, ergänzen Sie den bleibenden Zucker und setzen Sie fort, zu kochen.
<G-vec00060-001-s175><add.ergänzen><en> Pour weight in a pan, add coconut juice (if that is not present, it is possible to use usual water) and lime juice.
<G-vec00060-001-s175><add.ergänzen><de> Die Masse füllen Sie in den Kochtopf um, ergänzen Sie den Kokossaft (wenn gibt es diesen nicht, man kann das gewöhnliche Wasser verwenden) und den Saft lajma.
<G-vec00060-001-s176><add.ergänzen><en> Portable Lenovo computer: as popast... Happy owners of Lenovo laptops need change of standard parameters of the device or installation add sooner or later...
<G-vec00060-001-s176><add.ergänzen><de> Der portative Computer Lenovo: wie popast... Den glücklichen Besitzer der Notebooks Lenovo früh oder spät wird die Veränderung der standardmäßigen Parameter dewajsa benötigt oder die Anlage ergänzen Sie...
<G-vec00060-001-s177><add.ergänzen><en> "It is possible to open ""Magazine"" also a combination of the Ctrl+Shift+H keys, during removal add to this combination also the Del key."
<G-vec00060-001-s177><add.ergänzen><de> """Die Zeitschrift"" öffnen es kann auch von der Kombination der Tasten Ctrl+Shift+H, bei der Entfernung ergänzen Sie zu dieser Kombination auch die Taste Del."
<G-vec00060-001-s178><add.ergänzen><en> Add to listed the starting complete set of account materials, expenses for installation and training, servicing within the second year of operation and further.
<G-vec00060-001-s178><add.ergänzen><de> Ergänzen Sie zu aufgezählt den Startsatz der Ausgabematerialien, die Kosten die Installation und die Ausbildung, die Instandhaltung im Laufe vom zweiten Jahr des Betriebes weiter.
<G-vec00060-001-s179><add.ergänzen><en> Now slowly and accurately add liqueur (or coffee) and cream.
<G-vec00060-001-s179><add.ergänzen><de> Jetzt ergänzen Sie langsam und den Likör (oder den Kaffee) und die Sahne akkurat.
<G-vec00060-001-s180><add.ergänzen><en> Play it down with neutral tones, or add to the exciting feel with bold colours and textures.
<G-vec00060-001-s180><add.ergänzen><de> Spielen Sie es mit neutralen Tönen ab oder ergänzen Sie das aufregende Gefühl mit kräftigen Farben und Texturen.
<G-vec00060-001-s181><add.ergänzen><en> Add eggs, sugar and a semolina.
<G-vec00060-001-s181><add.ergänzen><de> Ergänzen Sie die Eier, den Zucker und manku.
<G-vec00060-001-s182><add.ergänzen><en> Then reduce fire, add 2 more spoons of oil and mushrooms.
<G-vec00060-001-s182><add.ergänzen><de> Dann verringern Sie das Feuer, ergänzen Sie noch 2 Löffel des Öls und die Pilze.
<G-vec00060-001-s183><add.ergänzen><en> Find the right product for your needs and add more functionality to your system.
<G-vec00060-001-s183><add.ergänzen><de> Finden Sie das passende Produkt für Ihre Bedürfnisse und ergänzen Sie Ihr System mit mehr Funktionalität.
<G-vec00060-001-s184><add.ergänzen><en> And that it became more gentle and soft, add to it a little sweet yogurt and mix.
<G-vec00060-001-s184><add.ergänzen><de> Und damit sie zarter und weich wurde, ergänzen Sie in sie ein wenig süß jogurta und vermischen Sie.
<G-vec00060-001-s185><add.ergänzen><en> Add a custom Signup Form to your Website to sign up new contacts.
<G-vec00060-001-s185><add.ergänzen><de> Ergänzen Sie Ihre Webseite mit einem speziellen Anmeldeformular, um neue Kontakte zu gewinnen.
<G-vec00060-001-s186><add.ergänzen><en> If you want to improve the recipe, add banana chips.
<G-vec00060-001-s186><add.ergänzen><de> Wenn Sie das Rezept vervollkommnen wollen, so ergänzen Sie die Bananenchips.
<G-vec00060-001-s187><add.ergänzen><en> Add here the characteristics identical for all shop pages.
<G-vec00060-001-s187><add.ergänzen><de> Ergänzen Sie hier, was für alle Seiten des Shops charakteristisch ist.
<G-vec00060-001-s188><add.ergänzen><en> Add intelligent operations management and automation to your data center through vSphere with Operations Management.
<G-vec00060-001-s188><add.ergänzen><de> Mit vSphere with Operations Management ergänzen Sie Ihr Rechenzentrum um intelligentes Betriebsmanagement und Automatisierung.
<G-vec00060-001-s189><add.ergänzen><en> For its preparation take the egg white beaten to a condition of foam, add a spoon of honey and will put on a face for about 5 minutes, then wash and use nutritious cream.
<G-vec00060-001-s189><add.ergänzen><de> Für ihre Vorbereitung nehmen Sie gerührt bis zum Zustand des Schaums der Eichhörner, ergänzen Sie den Löffel des Honigs und werden auf die Person der Minuten auf 5 auftragen, dann waschen Sie sich und nutzen Sie die nahrhafte Creme aus.
<G-vec00060-001-s228><add.hinzufügen><en> Add some eye-catching photos of yourself to your profile page, and complete all of your personal details .
<G-vec00060-001-s228><add.hinzufügen><de> Füge einige auffällige Fotos von dir selbst zu deiner Profilseite hinzu und komplettiere alle deine persönlichen Details .
<G-vec00060-001-s229><add.hinzufügen><en> Add in a source of fiber.
<G-vec00060-001-s229><add.hinzufügen><de> Füge eine Faserstoffquelle hinzu.
<G-vec00060-001-s230><add.hinzufügen><en> Add also hiss in this section (a classic tape noise).
<G-vec00060-001-s230><add.hinzufügen><de> Füge in diesem Abschnitt auch Rauschen hinzu (ein klassisches Bandrauschen).
<G-vec00060-001-s231><add.hinzufügen><en> In the peak training period I add evening.
<G-vec00060-001-s231><add.hinzufügen><de> In der Spitzentrainingsperiode füge ich Abend hinzu.
<G-vec00060-001-s232><add.hinzufügen><en> Find some fabrics and click to add them.
<G-vec00060-001-s232><add.hinzufügen><de> Füge Deine Stoffproben durch Klicken hinzu.
<G-vec00060-001-s233><add.hinzufügen><en> "Zauberkarte Add 1 monster from your Deck to your hand that includes ""Elemental Hero"" in its card name."
<G-vec00060-001-s233><add.hinzufügen><de> "Zauberkarte Füge deiner Hand 1 Monster von deinem Deck hinzu, dessen Kartenname ""Elementarheld"" enthält."
<G-vec00060-001-s234><add.hinzufügen><en> Add a teaspoon of vegetable oil to each container of dye.
<G-vec00060-001-s234><add.hinzufügen><de> Füge zu jedem Farbglas einen Teelöffel Pflanzenöl hinzu.
<G-vec00060-001-s235><add.hinzufügen><en> And add a sense of motion with GPU-accelerated effects like Path and Spin Blur.
<G-vec00060-001-s235><add.hinzufügen><de> Füge deinen Bildern mit GPU-beschleunigten Effekten wie Path Blur und Spin Blur das Gefühl der Bewegung hinzu.
<G-vec00060-001-s236><add.hinzufügen><en> 2 Add the amount of rice suggested by the recipe.
<G-vec00060-001-s236><add.hinzufügen><de> 2 Füge die im Rezept vorgeschlagen Menge Reises hinzu.
<G-vec00060-001-s237><add.hinzufügen><en> Add stamps, notes and fields and enter the document for review / release in the workflow.
<G-vec00060-001-s237><add.hinzufügen><de> Füge Stempel, Notizen und Felder hinzu und gebe den Beleg zur Prüfung / Freigabe in den Workflow.
<G-vec00060-001-s238><add.hinzufügen><en> Add and promote your Fortnite server on the top 100 list for more players.
<G-vec00060-001-s238><add.hinzufügen><de> Füge Deinen Fortnite Server hinzu, und mach Werbung auf der Liste der Besten 100.
<G-vec00060-001-s239><add.hinzufügen><en> add these cards to your arsenal and build your perfect deck.
<G-vec00060-001-s239><add.hinzufügen><de> füge diese Karten deinem Arsenal hinzu und baue dein perfektes Deck.
<G-vec00060-001-s240><add.hinzufügen><en> Customise your teeth with braces and add piercings to your nose, eyebrows, eyelids and around your mouth.
<G-vec00060-001-s240><add.hinzufügen><de> Pass deine Zähne mit einer Spange an oder füge deiner Nase, deinen Augenbrauen, deinen Augenlidern oder deinem Mund Piercings hinzu.
<G-vec00060-001-s241><add.hinzufügen><en> Tap on the green + button to add the file.
<G-vec00060-001-s241><add.hinzufügen><de> Füge die Datei mit einem Klick auf den grünen „+“-Button hinzu.
<G-vec00060-001-s242><add.hinzufügen><en> Add categories to these pages.
<G-vec00060-001-s242><add.hinzufügen><de> Füge diesen Seiten Kategorien hinzu.
<G-vec00060-001-s243><add.hinzufügen><en> I cut the cuttle fish into pieces and let them cook in a pre-prepared soffritto (chopped onion and bit of garlic fried on a low heat); at its half cooking I add a sprinkle of white wine and the ink black that laid inside the cuttle fish.
<G-vec00060-001-s243><add.hinzufügen><de> Ich schneide die Tintenfische in Stückchen und koche sie mit einem Soffritto (Knoblauch, Zwiebeln beides fein gehackt auf kleiner Stufe angeröstet) und einem Spritzer Weißwein solange bis sie halb durch sind, danach füge ich die Tinte hinzu, die man im Inneren der Tintenfische findet und lasse sie fertig garen.
<G-vec00060-001-s244><add.hinzufügen><en> Add kite spots to your profile Access English (Translate this text in English): AIA North across from the Cafe Oasis.
<G-vec00060-001-s244><add.hinzufügen><de> Füge Kitespots zu deinem Profil hinzu Zugang English (Übersetze diesen text in Deutsch): AIA North across from the Cafe Oasis.
<G-vec00060-001-s245><add.hinzufügen><en> Please add me on...messenger.
<G-vec00060-001-s245><add.hinzufügen><de> Bitte füge mich zum...-Messenger hinzu.
<G-vec00060-001-s246><add.hinzufügen><en> Add graphics and text to your columns.
<G-vec00060-001-s246><add.hinzufügen><de> Füge deinen Spalten Grafiken und Text hinzu.
<G-vec00407-001-s228><add.hinzufügen><en> Add some eye-catching photos of yourself to your profile page, and complete all of your personal details .
<G-vec00407-001-s228><add.hinzufügen><de> Füge einige auffällige Fotos von dir selbst zu deiner Profilseite hinzu und komplettiere alle deine persönlichen Details .
<G-vec00407-001-s234><add.hinzufügen><en> Add a teaspoon of vegetable oil to each container of dye.
<G-vec00407-001-s234><add.hinzufügen><de> Füge zu jedem Farbglas einen Teelöffel Pflanzenöl hinzu.
<G-vec00060-001-s266><add.hinzufügen><en> "They also add: ""Do not forget about the musicians""."
<G-vec00060-001-s266><add.hinzufügen><de> "Sie fügen hinzu: ""Vergessen Sie nicht die Musiker""."
<G-vec00060-001-s267><add.hinzufügen><en> Even in esoteric circles people take the knowledge revealed by the Masters, add their own language and colour and publish it as their own thing.
<G-vec00060-001-s267><add.hinzufügen><de> Selbst in esoterischen Kreisen nehmen Leute das von den Meistern offenbarte Wissen, fügen ihre eigene Sprache und Farbe hinzu und geben es als ihre eigene Sache heraus.
<G-vec00060-001-s268><add.hinzufügen><en> Add the external schema by clicking the Add New Schema icon in the Overview entry helper and then browsing for the schema you wish to add.
<G-vec00060-001-s268><add.hinzufügen><de> "Fügen Sie das externe Schema hinzu, indem Sie in der Eingabehilfe ""Übersicht"" auf das Symbol Neues Schema hinzufügen klicken und anschließend zum gewünschten Schema navigieren."
<G-vec00060-001-s269><add.hinzufügen><en> Information from Other Sources: We also may periodically obtain information about you from affiliated entities, business partners and other independent third-party sources and add it to other information about you.
<G-vec00060-001-s269><add.hinzufügen><de> Informationen aus anderen Quellen: Wir erhalten möglicherweise auch regelmäßig von Affiliate-Partnern, Geschäftspartnern und anderen unabhängigen Drittquellen Informationen über Sie und fügen diese anderen Informationen über Sie hinzu.
<G-vec00060-001-s270><add.hinzufügen><en> Just tap on it and add the contact you want to block.
<G-vec00060-001-s270><add.hinzufügen><de> Tippen Sie einfach darauf und fügen Sie den zu blockierenden Kontakt hinzu.
<G-vec00060-001-s271><add.hinzufügen><en> 1279 BC + 12 hours; all add up to 96 hours, = 48 + 48 hours of two years of sped up reverse orbit countered by the long days.
<G-vec00060-001-s271><add.hinzufügen><de> 1279 BC + 12 Stunden; alle fügen oben 96 Stunden, = 48 + 48 Stunden von zwei Jahren der beschleunigten Rückbahn hinzu, die bis zum den langen Tagen widersprochen wird.
<G-vec00060-001-s272><add.hinzufügen><en> Supposing you add a VBA macro for a workbook, now you want to save it as a template.
<G-vec00060-001-s272><add.hinzufügen><de> Angenommen, Sie fügen einen VBA-Makro für eine Arbeitsmappe hinzu, möchten Sie ihn jetzt als Vorlage speichern.
<G-vec00060-001-s273><add.hinzufügen><en> This requires a change in the way programming is taught, they add.
<G-vec00060-001-s273><add.hinzufügen><de> Dies erfordert eine Veränderung in der Art der Programmierung gelehrt wird, fügen Sie hinzu.
<G-vec00060-001-s274><add.hinzufügen><en> With «Add Poll» you add a new survey.
<G-vec00060-001-s274><add.hinzufügen><de> Mit «Add Poll» fügen Sie eine neue Umfrage hinzu.
<G-vec00060-001-s275><add.hinzufügen><en> Create and save a ringtone and then add it to your Tones library in iTunes.
<G-vec00060-001-s275><add.hinzufügen><de> Erstellen und speichern Sie einen Klingelton und fügen ihn dann zur Bibliothek mit Tönen in iTunes hinzu (Video auf Englisch).
<G-vec00060-001-s276><add.hinzufügen><en> The monks then add rennet: this is a substance that makes the milk stiff.
<G-vec00060-001-s276><add.hinzufügen><de> Dann fügen die Mönche Lab hinzu, einen Stoff, wodurch die Milch steif wird.
<G-vec00060-001-s277><add.hinzufügen><en> When you decide to treat your self to a 4 hour exclusive entry to the Retreat Spa and the Blue Lagoon, add this luxury private transfer to your package.
<G-vec00060-001-s277><add.hinzufügen><de> Wenn Sie sich entscheiden, sich selbst mit einem 4-stündigen exklusiven Eintritt in das Retreat Spa und die Blaue Lagune zu verwöhnen, fügen Sie diesen luxuriösen Privattransfer zu Ihrem Paket hinzu.
<G-vec00060-001-s278><add.hinzufügen><en> Celtic cultures often add mystical and religious markings and symbols to their wedding jewellery.
<G-vec00060-001-s278><add.hinzufügen><de> Keltische Kulturen fügen Ihrem Hochzeitsschmuck häufig mystische und religiöse Zeichen und Symbole hinzu.
<G-vec00060-001-s279><add.hinzufügen><en> And a Kutools for Excel dialog box pops up, please select the certain table range you will add a blank row below, and then click the OK button.
<G-vec00060-001-s279><add.hinzufügen><de> Und ein Kutools for Excel Dialogfeld erscheint, bitte wählen Sie den bestimmten Tabellenbereich aus, Sie fügen eine leere Zeile hinzu und klicken dann auf OK Taste.
<G-vec00060-001-s280><add.hinzufügen><en> The spiralling seams and capped vents add sculptural detail to the roof encouraging the eye to move across it to further enhance the reading of the Foudre as a single entity.
<G-vec00060-001-s280><add.hinzufügen><de> "Die spiralförmigen Falze und die bedeckten Schlitze fügen dem Dach ein plastisches Detail hinzu und ermutigen das Auge weiterzuwandern, um den ""Foudre"" als alleinstehende Einheit wahrzunehmen."
<G-vec00060-001-s281><add.hinzufügen><en> Jot down your thoughts, a short story, add some stems of pressed grass and the flat little stone you could have skimmed over the water.
<G-vec00060-001-s281><add.hinzufügen><de> Sie schreiben Ihre Gedanken auf, eine kleine Erzählung, fügen gepresste Gräser hinzu und das flache Steinchen, das Sie eigentlich über den Wasserspiegel springen lassen wollten.
<G-vec00060-001-s282><add.hinzufügen><en> • If you need additional information add it as a comment and it will appear in brackets under the designation on the form.
<G-vec00060-001-s282><add.hinzufügen><de> • Wenn Sie zusätzliche Informationen benötigen, fügen Sie ein Kommentar hinzu und dieser erscheint in Klammern unterhalb der Fragestellung.
<G-vec00060-001-s283><add.hinzufügen><en> We will add new functions to the API.
<G-vec00060-001-s283><add.hinzufügen><de> Wir fügen neue Funktionen zur API hinzu.
<G-vec00060-001-s284><add.hinzufügen><en> To get a first idea please visit our price page and check the size and figure count then add on a frame if required.
<G-vec00060-001-s284><add.hinzufügen><de> Um einen ersten Eindruck zu bekommen besuchen Sie unsere Preis-Seite und überprüfen Sie das Format mit der Personenzahl und fügen dann den Rahmenpreis hinzu, falls gewünscht.
<G-vec00060-001-s304><add.hinzufügen><en> Anavar will add quality pounds to any frame small or large by increasing growth factors, such as IGF also.
<G-vec00060-001-s304><add.hinzufügen><de> Anavar fügt Qualitätspfund jedem möglichem Rahmen hinzu, der indem er auch Wachstumsfaktoren, wie IGF klein oder groß ist, erhöht.
<G-vec00060-001-s305><add.hinzufügen><en> The buttons on the top have the following function: Add Add the selected file(s) in the explorer to the project.
<G-vec00060-001-s305><add.hinzufügen><de> Die Schalter oben haben folgende Funktion: Hinzufügen Fügt das/die im Explorer ausgewählte(n) Datei(en) zum Projekt hinzu.
<G-vec00060-001-s306><add.hinzufügen><en> It will force your body into a more natural position and add detail to your portrait.
<G-vec00060-001-s306><add.hinzufügen><de> Es zwingt deinen Körper in eine natürlichere Haltung und fügt deinem Portrait ein Detail hinzu.
<G-vec00060-001-s307><add.hinzufügen><en> It may add the old version in the last parameter, if the package has already been installed and removed since (but not purged, the configuration files having been retained).
<G-vec00060-001-s307><add.hinzufügen><de> Möglicherweise fügt es im letzten Parameter die alte Version hinzu, falls das Paket früher schon einmal installiert war und seither entfernt wurde (aber nicht vollständig gelöscht, da die Konfigurationsdateien noch zurückbehalten wurden).
<G-vec00060-001-s308><add.hinzufügen><en> memoQ will immediately add the term pair to the term base.
<G-vec00060-001-s308><add.hinzufügen><de> memoQ fügt das Termpaar sofort der Termdatenbank hinzu.
<G-vec00060-001-s309><add.hinzufügen><en> I have always thought that the lighting object takes shape from the light source, through a design concept aimed at solving needs.... on the sheet you draw the bulb, you add a ground plane, maybe a deposit for books or music, and why not, endless profiles of lamps that envelop the light..... Also available with a writable surface with markers for the whiteboard.
<G-vec00060-001-s309><add.hinzufügen><de> Ich habe immer gedacht, dass das Lichtobjekt Form von der Lichtquelle annimmt, durch ein Designkonzept, das auf die Lösung der Bedürfnisse ausgerichtet ist..... auf dem Blatt, auf dem man die Glühbirne zeichnet, fügt man eine Grundplatte hinzu, vielleicht eine Kaution für Bücher oder Musik, und warum nicht, endlose Profile von Lampen, die das Licht umhüllen........ Auch mit beschreibbarer Oberfläche mit Markern für das Whiteboard erhältlich.
<G-vec00060-001-s310><add.hinzufügen><en> Remarks: Add a wireless network profile on an interface for all or current users.
<G-vec00060-001-s310><add.hinzufügen><de> Anmerkungen: Fügt einer Schnittstelle für alle oder für die aktuellen Benutzer ein Drahtlosnetzwerkprofil hinzu.
<G-vec00060-001-s311><add.hinzufügen><en> The brand new Czech amateur Nikol will gladly prepare anything you wish for and she might even add a little of something erotic.
<G-vec00060-001-s311><add.hinzufügen><de> Der brandneue tschechische Amateur Nikol bereitet gerne alles vor, was Sie sich wünschen, und vielleicht fügt er sogar etwas Erotisches hinzu.
<G-vec00060-001-s312><add.hinzufügen><en> 'Omron’s highly specialized owned core technologies add the Think Dimension to manufacturing today to enable producers to innovate to Industry 4.0 smart factories and improve their output', remarks Peter Cusack, Head of Strategic Marketing at Omron Europe.
<G-vec00060-001-s312><add.hinzufügen><de> „Die hochgradig spezialisierte, unternehmenseigene Kerntechnologie von Omron fügt der Fertigung von heute die Denk-Dimension hinzu und ebnet so Herstellern den Weg zur Industrie 4.0 und ermöglicht ihnen, ihre Leistung zu steigern“, meint Peter Cusack, Head of Strategic Marketing bei Omron Europe.
<G-vec00060-001-s313><add.hinzufügen><en> How to add a watermark to pictures
<G-vec00060-001-s313><add.hinzufügen><de> Wie fügt man ein Wasserzeichen auf Bildern hinzu...
<G-vec00060-001-s314><add.hinzufügen><en> Click Data > Filter, Excel will add drop-down arrows to the column headers.
<G-vec00060-001-s314><add.hinzufügen><de> Klicken Dateimanagement erfolgen > FilternExcel fügt den Spaltenüberschriften Dropdown-Pfeile hinzu.
<G-vec00060-001-s315><add.hinzufügen><en> MAYA is extremely simple to use. For a cup of hot chocolate just fill the provided jug with whole milk, add a sachet of powdered chocolate and, without stirring, place the jug on the machine support. Press the button 1 and in a few seconds you will obtain a perfect thick hot chocolate
<G-vec00060-001-s315><add.hinzufügen><de> MAYA ist einfach in ihrer Anwendung: man gießt Vollmilch in den zur Ausstattung gehörenden Krug, fügt das Tütchen Kakaopulver hinzu und stellt den Krug auf die eigens dafür vorgesehenen Halteplatte der Maschine; nach Drücken der gewählten Taste, wird automatisch eine perfekte Schokolade zubereitet.
<G-vec00060-001-s316><add.hinzufügen><en> Now add to this the fact that in the last lifetimes, the roles were reversed.
<G-vec00060-001-s316><add.hinzufügen><de> Und nun fügt dem die Tatsache hinzu, dass in den vorherigen Leben die Rollen vertauscht waren.
<G-vec00060-001-s317><add.hinzufügen><en> This modern and quirky Whale Shaped Serving Bowl will add fun and style to any table.
<G-vec00060-001-s317><add.hinzufügen><de> das ist modern und skurril Wal-förmige Servierschale fügt jedem Tisch Spaß und Stil hinzu.
<G-vec00060-001-s318><add.hinzufügen><en> Add a knot via left mouse click.
<G-vec00060-001-s318><add.hinzufügen><de> Drücken der linken Maustaste fügt einen Knoten hinzu.
<G-vec00060-001-s319><add.hinzufügen><en> (2) This VBA code won’t add flash background to blank selection.
<G-vec00060-001-s319><add.hinzufügen><de> (2) Dieser VBA-Code fügt der leeren Auswahl keinen Flash-Hintergrund hinzu.
<G-vec00060-001-s320><add.hinzufügen><en> "Implementation of the WirelessHART standard will add Session keys for communication between two network devices so that other devices can't ""listen in."""
<G-vec00060-001-s320><add.hinzufügen><de> Implementierung des WirelessHART Standard fügt Sitzungsschlüssel für die Kommunikation zwischen zwei Netzwerkgeräten hinzu, so dass andere Geräte nicht „zuhören“ können.
<G-vec00060-001-s321><add.hinzufügen><en> Write a string in the #File and add an 'end of line' character.
<G-vec00060-001-s321><add.hinzufügen><de> Schreibt einen String in die '#Datei' und fügt ein 'End of line' Zeichen (für Zeilenumbruch) hinzu.
<G-vec00060-001-s322><add.hinzufügen><en> Notes: This method will also add space at the beginning of cells if the first letter is capital.
<G-vec00060-001-s322><add.hinzufügen><de> Notizen: Diese Methode fügt auch am Anfang von Zellen Speicherplatz hinzu, wenn der erste Buchstabe groß ist.
<G-vec00060-001-s399><add.hinzufügen><en> "At the bottom of the page ""Order information"" click on the button ""Add to cart""."
<G-vec00060-001-s399><add.hinzufügen><de> "Am unteren Teil der Seite ""Bestellinformationen"" klicken Sie auf ""In den Warenkorb hinzufügen""."
<G-vec00060-001-s400><add.hinzufügen><en> I will add, and they take love with them.
<G-vec00060-001-s400><add.hinzufügen><de> Ich will hinzufügen, und sie nehmen sie verliebt.
<G-vec00060-001-s401><add.hinzufügen><en> Deglaze with the red wine vinegar, add the beer, 2 large tablespoons of Sirop de Liège and then add the raisins.
<G-vec00060-001-s401><add.hinzufügen><de> Mit dem Rotwein ablöschen, das Bier hinzufügen, sowie 2 gute Löffel Sirop de Liège und die Rosinen.
<G-vec00060-001-s402><add.hinzufügen><en> Add 250g of single cream, season with salt and chilli pepper.
<G-vec00060-001-s402><add.hinzufügen><de> 250 g flüssige Sahne hinzufügen, mit Salz und Piment d'Espelette abschmecken.
<G-vec00060-001-s403><add.hinzufügen><en> Add minced meat and let it fry, constantly stirring.
<G-vec00060-001-s403><add.hinzufügen><de> Faschiertes hinzufügen und unter ständigem Rühren anbraten.
<G-vec00060-001-s404><add.hinzufügen><en> Maybe you also sell a tool for keyword research. You can easily add that, too.
<G-vec00060-001-s404><add.hinzufügen><de> Wenn Du ein Programm für die Keyword-Recherche verkaufst, kannst Du Keyword-Recherche als Interesse hinzufügen.
<G-vec00060-001-s405><add.hinzufügen><en> Heat olive oil, add chopped celery with finely grated lemon zest, sauté on low heat for 3 minutes.
<G-vec00060-001-s405><add.hinzufügen><de> Das Olivenöl erhitzen, gehackten Sellerie mit dem feinen Zitronenabrieb hinzufügen und bei kleiner Hitze für 3 Minuten anbraten.
<G-vec00060-001-s406><add.hinzufügen><en> Opens the Add Provider dialog box in which you can add a provider for the selected feature.
<G-vec00060-001-s406><add.hinzufügen><de> Öffnet das Dialogfeld Anbieter hinzufügen, in dem Sie einen Anbieter für das ausgewählte Feature hinzufügen können.
<G-vec00060-001-s408><add.hinzufügen><en> "To remove a category, select it in the drop menu, delete all the scripts and click the ""Add/remove category"" button."
<G-vec00060-001-s408><add.hinzufügen><de> Um eine Kategorie zu entfernen, wählen Sie sie im Dropdown-Menü aus, entfernen Sie alle Skripten, die sie enthält, und klicken Sie auf „Kategorie hinzufügen/entfernen“.
<G-vec00060-001-s409><add.hinzufügen><en> add to my travel plan Volleyball players of all ages, from beginners to experts, meet on Vienna's beach volleyball courts.
<G-vec00060-001-s409><add.hinzufügen><de> Beachvolleyball zu meinem Reiseplan hinzufügen Volleyballer jeden Alters, von Anfängern bis zu Könnern, treffen sich auf Wiens Beachvolleyball-Plätzen.
<G-vec00060-001-s410><add.hinzufügen><en> Shake all the ingredient – without orange juice – strain into cocktail glass filled with ice – then add orange juice to it.
<G-vec00060-001-s410><add.hinzufügen><de> Rütteln Sie alles - ohne Orangensaft – zusammen ins mit Eis gefüllte Cocktailglas - Orangensaft dann hinzufügen.
<G-vec00060-001-s411><add.hinzufügen><en> No matter whether you want to add your face to Will Smith or a cute little baby, this app makes it possible.
<G-vec00060-001-s411><add.hinzufügen><de> Egal, ob Sie Ihr Gesicht zu Will Smith oder ein nettes kleines Baby hinzufügen möchten, Diese App macht es möglich.
<G-vec00060-001-s412><add.hinzufügen><en> If relevant to the work, you may choose to add a time parameter to your NDA that states how long the information or materials between the parties should be kept confidential; this could be anything from six months after finishing the contract to more than 15 years.
<G-vec00060-001-s412><add.hinzufügen><de> Wenn dies für die Arbeit relevant ist, kannst du deiner NDA einen Zeitparameter hinzufügen, das angibt, wie lange die Informationen oder Materialien zwischen den Parteien vertraulich behandelt werden sollen; dies kann sechs Monate nach Abschluss des Vertrages bis zu mehr als 15 Jahren betragen.
<G-vec00060-001-s413><add.hinzufügen><en> Any comments and ideas will be welcomed below, if they make sense we’ll add them to our workplan.
<G-vec00060-001-s413><add.hinzufügen><de> Alle Kommentare und Ideen unter begrüßen, wenn sie Sinn machen wir sie zu unserem Arbeitsplan hinzufügen.
<G-vec00060-001-s415><add.hinzufügen><en> Enter the Serial Number for the particular mobile device you want to add.
<G-vec00060-001-s415><add.hinzufügen><de> Geben Sie die Seriennummer des Mobilgeräts ein, das Sie hinzufügen möchten.
<G-vec00060-001-s416><add.hinzufügen><en> If you plan a short trip or vacation in British Virgin Islands in the future, make sure you add Virgin Islands, Saint Barthélemy, Anguilla, Saint-Martin (French part), Puerto Rico, Saint Kitts and Nevis, Montserrat, Antigua and Barbuda, Dominica, Dominican Republic to your list.
<G-vec00060-001-s416><add.hinzufügen><de> Wenn Sie einen Kurzurlaub oder Ferien in Britische Jungferninseln in Zukunft planen, stellen Sie sicher, dass Sie Amerikanische Jungferninseln, Saint-Barthélemy, Anguilla, Saint Martin, Puerto Rico, Saint Christopher und Nevis, Montserrat, Antigua und Barbuda, Dominica, Dominikanische Republik zu Ihrer Liste hinzufügen.
<G-vec00060-001-s417><add.hinzufügen><en> The features add to the overall game experience as well.
<G-vec00060-001-s417><add.hinzufügen><de> Die Funktionen hinzufügen, um das gesamte Spiel Erfahrung.
<G-vec00060-001-s418><add.hinzufügen><en> One problem that many people hit is that I can not add a credit card or debit card to Apple Pay / Wallet when initializing iOS on your iPhone or iPad.
<G-vec00060-001-s418><add.hinzufügen><de> Ein Problem, das viele Menschen treffen, ist das Ich kann Apple Pay / Wallet keine Kreditkarte oder Debitkarte hinzufügen wenn Sie iOS auf Ihrem iPhone oder iPad initialisieren.
<G-vec00060-001-s419><add.hinzufügen><en> If you need to add any lube then use a good water-based lube and apply it to your partners penis.
<G-vec00060-001-s419><add.hinzufügen><de> Wenn Sie ein Gleitmittel hinzufügen müssen, verwenden Sie ein gutes Gleitmittel auf Wasserbasis und wenden Sie es auf den Penis Ihres Partners an.
<G-vec00060-001-s420><add.hinzufügen><en> If you want to add the files from your Mac Desktop and Documents folder to iCloud Drive, update your Mac to macOS Sierra or later then turn on Desktop and Documents .
<G-vec00060-001-s420><add.hinzufügen><de> "Wenn Sie Dateien vom Schreibtisch Ihres Mac oder aus dem Ordner ""Dokumente"" zu iCloud Drive hinzufügen möchten, aktualisieren Sie Ihren Mac auf macOS Sierra oder neuer, und aktivieren Sie dann ""Schreibtisch"" und ""Dokumente"" ."
<G-vec00060-001-s421><add.hinzufügen><en> If apples are juicy, you can add a little water and sugar, because your cake should have a good soak.
<G-vec00060-001-s421><add.hinzufügen><de> Wenn Äpfel saftig sind, können Sie ein wenig Wasser und Zucker hinzufügen, weil Sie Ihren Kuchen eine gute einweichen haben sollte.
<G-vec00060-001-s422><add.hinzufügen><en> Using a store builder like Ecwid, an AJAX application, allows you to add your store and be mirrored on several platforms (websites, blogs, social networks) simultaneously with a central point to manage each channel.
<G-vec00060-001-s422><add.hinzufügen><de> Mit einem store builder wie Ecwid, eine AJAX-Anwendung, ermöglicht das hinzufügen und speichern Sie Ihre spiegelung auf mehreren Plattformen (websites, blogs, soziale Netzwerke) gleichzeitig mit einem zentralen Punkt zu verwalten jeden Kanal.
<G-vec00060-001-s423><add.hinzufügen><en> Additional added fats like butter, margarine, gravy, salad dressing, sour cream, and those found in whole milk, cream and fried foods also add hundreds of calories: just cut a bit and see how quickly reveals the scale of change.
<G-vec00060-001-s423><add.hinzufügen><de> Extra hinzu Fette wie Butter, Margarine, Soße, Salat-Dressing, saure Sahne, und die in Vollmilch, Sahne gefunden, und frittierten Lebensmitteln auch hinzufügen, Hunderte von Kalorien: kopieren Sie einfach ein wenig zurück und sehen, wie schnell die Skala zeigt eine Veränderung.
<G-vec00060-001-s424><add.hinzufügen><en> However, if you need to add properties or methods only to one instance of an object, use the Add-Member cmdlet.
<G-vec00060-001-s424><add.hinzufügen><de> "Wenn Sie jedoch Eigenschaften oder Methoden lediglich einer Instanz eines Objekts hinzufügen müssen, verwenden Sie das Cmdlet ""Add-Member""."
<G-vec00060-001-s425><add.hinzufügen><en> Click Add, type the directory that you want to exclude from scanning into the given field and then click OK .
<G-vec00060-001-s425><add.hinzufügen><de> Klicken Sie auf Hinzufügen, geben Sie das Verzeichnis ein, das Sie vom Scannen ausschließen möchten und klicken Sie dann auf OK .
<G-vec00060-001-s426><add.hinzufügen><en> If you cannot add your NAS to Q’center, here are some common reasons why.
<G-vec00060-001-s426><add.hinzufügen><de> Wenn Sie Ihr NAS nicht zu Q’center hinzufügen können, finden Sie hier einige gängige Ursachen.
<G-vec00060-001-s427><add.hinzufügen><en> You can now add lessons into the timetable by right clicking in teacher’s timetable.
<G-vec00060-001-s427><add.hinzufügen><de> Sie können nun dem Stundenplan Unterrichtsstunden hinzufügen indem Sie im Lehrerstundenplan die rechte Maustaste drücken.
<G-vec00060-001-s428><add.hinzufügen><en> Price for 1: CHF Add to cart bodykey by NUTRILITETM MEAL REPLACEMENT BAR DARK CHOCOLATE The perfect replacement for 1-2 daily meals to support your weight-loss and healthy lifestyle goals.
<G-vec00060-001-s428><add.hinzufügen><de> Preis für 1: CHF Hinzufügen bodykey by NUTRILITETM MAHLZEITERSATZ-RIEGEL – DUNKLE SCHOKOLADE Der perfekte Ersatz von 1-2 Tagesmahlzeiten, der Sie bei Ihrer Gewichtsabnahme und Ihren Zielen auf dem Weg zu einem gesunden Lebensstil unterstützt.
<G-vec00060-001-s429><add.hinzufügen><en> If the group to which you like to add components to already exists, right-click onto this group and select New Component .
<G-vec00060-001-s429><add.hinzufügen><de> Falls bereits eine Gruppe besteht, zu der Sie Komponenten hinzufügen möchten, klicken Sie mit der rechten Maustaste auf diese Gruppe und wählen Sie Neue Komponente .
<G-vec00060-001-s430><add.hinzufügen><en> Insert HTML, CSS, shortcodes, use embed codes etc. Use for anything you can think of: announce a product, add social buttons, highlight content etc.
<G-vec00060-001-s430><add.hinzufügen><de> HTML einfügen, CSS, Kurzwahlnummern, Verwendung einbetten Codes etc.. Verwendung für alles, was man sich vorstellen kann: ankündigen eines Produkts, social-Buttons hinzufügen, Markieren Sie Inhalte etc..
<G-vec00060-001-s431><add.hinzufügen><en> Add Allow Restriction Rule - Type an IPv4 address in the Specific IPv4 Address box in the Add Allow Restriction Rule dialog box when you want to allow access to content for a specific IPv4 address.
<G-vec00060-001-s431><add.hinzufügen><de> Zulassungseinschränkungsregel hinzufügen - Geben Sie im Dialogfeld Zulassungseinschränkungsregel hinzufügen im Feld Bestimmte IPv4-Adresse eine IPv4-Adresse ein, wenn Sie für eine bestimmte IPv4-Adresse den Zugriff auf Inhalt zulassen möchten.
<G-vec00060-001-s432><add.hinzufügen><en> "Go to ""Add favourite"" in the browser menu and store the web app as a bookmark."
<G-vec00060-001-s432><add.hinzufügen><de> Gehen Sie im Browsermenü auf den Eintrag Favorit hinzufügen und legen Sie die Web-App als Lesezeichen ab.
<G-vec00060-001-s433><add.hinzufügen><en> PERSONALIZED MESSAGING If you wish to add a personal message to a Gift Card, simply type your message in the Message field during the purchase process.
<G-vec00060-001-s433><add.hinzufügen><de> INDIVIDUELLE NACHRICHTEN Wenn Sie einem Geschenkgutschein eine individuelle Nachricht hinzufügen möchten, geben Sie Ihre Nachricht einfach im Bestellprozess im Nachricht-Feld ein.
<G-vec00060-001-s434><add.hinzufügen><en> ": Add a new ""time frame"" (will be filled with the data specified)."
<G-vec00060-001-s434><add.hinzufügen><de> : Neuen Zeitraum hinzufügen (wird mit den Daten, die Sie spezifiziert haben ausgefüllt werden).
<G-vec00060-001-s435><add.hinzufügen><en> If you want to add a dollar sign at the end of the number, type #$ into the Type text box.
<G-vec00060-001-s435><add.hinzufügen><de> Wenn Sie ein Dollarzeichen am Ende der Zahl hinzufügen möchten, geben Sie ein #$ in die Art Textfeld.
<G-vec00060-001-s436><add.hinzufügen><en> In the Add Text dialog, type the zeros you want to add into the textbox of Text, and check Before first character option, and you can preview the adding result in the right pane.
<G-vec00060-001-s436><add.hinzufügen><de> In dem Text hinzufügen Geben Sie die Nullen ein, die Sie in das Textfeld von hinzufügen möchten SMS, und prüfe Vor dem ersten Charakter Option, und Sie können eine Vorschau des Addierergebnisses im rechten Fensterbereich anzeigen.
<G-vec00060-001-s437><add.hinzufügen><en> When you right mouse click the icon you can also add files to the list and change their properties. (same for a customizable file system).
<G-vec00060-001-s437><add.hinzufügen><de> Bei Rechtsklicken des Symbols, können Dateien zu der Liste hinzugefügt oder deren Eigenschaften geändert werden (Wie bei einem anpassbaren Dateisystem).
<G-vec00060-001-s438><add.hinzufügen><en> Add additional trees and spawn points for the multiplayer mode.
<G-vec00060-001-s438><add.hinzufügen><de> Für die Multiplayer-Version müssen zusätzliche Bäume und Spawnpunkte hinzugefügt werden.
<G-vec00060-001-s439><add.hinzufügen><en> "If you click on the ""Locale"" button it should add your preferred language."
<G-vec00060-001-s439><add.hinzufügen><de> Wenn Sie auf den Locale-Knopf drücken, sollte Ihre bevorzugte Sprache hinzugefügt werden.
<G-vec00060-001-s440><add.hinzufügen><en> You can easily add supports when doing double-sided cutting and preview your job on-screen to confirm the cutting path.
<G-vec00060-001-s440><add.hinzufügen><de> Bei doppelseitigen Schneidearbeiten kann Trägermaterial einfach hinzugefügt werden und zur Bestätigung der Fräsbahn kann eine Voransicht des Auftrags auf dem Bildschirm aufgerufen werden.
<G-vec00060-001-s441><add.hinzufügen><en> After that, we drain the water in excess and we add dried sea-salt coming from the Salinas of Margherita di Savoia,
<G-vec00060-001-s441><add.hinzufügen><de> Dann wird das überschüssige Wasser abgetropft und getrocknetes Meersalz aus den Salzlagerstätten von Margherita di Savoia hinzugefügt.
<G-vec00060-001-s442><add.hinzufügen><en> For example, you can add other objects to it.
<G-vec00060-001-s442><add.hinzufügen><de> Dem Array können beispielsweise weitere Objekte hinzugefügt werden.
<G-vec00060-001-s443><add.hinzufügen><en> If listening below these frequencies are important, you should add a switched 150 pf capacitor.
<G-vec00060-001-s443><add.hinzufügen><de> Beim Hören unterhalb dieser Frequenz, sollte ein schaltbarer Kondensator von 150pF hinzugefügt werden.
<G-vec00060-001-s444><add.hinzufügen><en> Now add yeast and salt and knead for 2 min at slow speed and 8 min at fast speed.
<G-vec00060-001-s444><add.hinzufügen><de> Nun werden Hefe und Salz hinzugefügt und der Teig erst 2 min bei langsamer Geschwindigkeit, dann weitere 8 min bei schneller Geschwindigkeit geknetet.
<G-vec00060-001-s445><add.hinzufügen><en> It add some additional functions which made the machine easy and convenient to operate.
<G-vec00060-001-s445><add.hinzufügen><de> Es wurden einige zusätzliche Funktionen hinzugefügt, die die Bedienung der Maschine einfach und bequem machten.
<G-vec00060-001-s446><add.hinzufügen><en> You don't want people to add new features to the project, but you don't want to tell all developers to stop programming either.
<G-vec00060-001-s446><add.hinzufügen><de> Sie wollen weder, dass dem Projekt neue Funktionen hinzugefügt werden, noch möchten Sie alle Entwicklern auffordern, das Programmieren einzustellen.
<G-vec00060-001-s447><add.hinzufügen><en> You must be an administrator to add and manage brands.
<G-vec00060-001-s447><add.hinzufügen><de> Marken können nur von einem Administrator hinzugefügt und verwaltet werden.
<G-vec00060-001-s448><add.hinzufügen><en> Episerver Find Connections Edition lets you add connectors, which index external content that is related to but not part of your website.
<G-vec00060-001-s448><add.hinzufügen><de> Mit der Episerver Find Connections Edition können Konnektoren hinzugefügt werden, die externe Inhalte indizieren, die einen Bezug zu Ihrer Webseite haben, aber nicht Teil derselben sind.
<G-vec00060-001-s449><add.hinzufügen><en> With the latest Volvo V40 D5 racer, it intends to add a new chapter to its success story from July.
<G-vec00060-001-s449><add.hinzufügen><de> Mit dem neuen Volvo V40 D5 Rennwagen soll seiner Erfolgsgeschichte ab Juli ein weiteres Kapitel hinzugefügt werden.
<G-vec00060-001-s450><add.hinzufügen><en> Now the main table has been updated the data and add new data based on the lookup table.
<G-vec00060-001-s450><add.hinzufügen><de> Nun wurden die Daten in der Haupttabelle aktualisiert und neue Daten basierend auf der Nachschlagetabelle hinzugefügt.
<G-vec00060-001-s451><add.hinzufügen><en> – Add a little vibrancy.
<G-vec00060-001-s451><add.hinzufügen><de> – Ein bisschen Leuchtkraft hinzugefügt.
<G-vec00060-001-s452><add.hinzufügen><en> The forest functional level must be Windows Server 2003, Windows Server 2008, or Windows Server 2008 R2 to add an RODC to the forest.
<G-vec00060-001-s452><add.hinzufügen><de> "Die Gesamtstrukturfunktionsebene muss ""Windows Server 2003"", ""Windows Server 2008"" oder ""Windows Server 2008 R2"" lauten, damit der Gesamtstruktur ein schreibgeschützter Domänencontroller hinzugefügt werden kann."
<G-vec00060-001-s453><add.hinzufügen><en> If there's already an event at this frame, it will add the event at the next frame.
<G-vec00060-001-s453><add.hinzufügen><de> Falls bereits ein Event vorhanden ist, dann wird das Event zum nächsten Frame hinzugefügt.
<G-vec00060-001-s454><add.hinzufügen><en> If you are a member of the local Administrators group, you can grant someone else the Manage Server permission to be able to add a printer by IP address or hostname.
<G-vec00060-001-s454><add.hinzufügen><de> Wenn Sie Mitglied der lokalen Gruppe Administratoren sind, können Sie einem anderen Benutzer die Berechtigung Server verwalten erteilen, damit ein Drucker über die IP-Adresse oder den Hostnamen hinzugefügt werden kann.
<G-vec00060-001-s455><add.hinzufügen><en> You can also add vehicles and landscapes drawn by yourself.
<G-vec00060-001-s455><add.hinzufügen><de> Es können eigene Fahrzeuge und Landschaften hinzugefügt werden.
<G-vec00060-001-s456><add.hinzufügen><en> Click, to add wishes to the new list.
<G-vec00060-001-s456><add.hinzufügen><de> Klicken Sie auf, um Wünsche zur neuen Wunschliste hinzuzufügen.
<G-vec00060-001-s457><add.hinzufügen><en> A Modern Tremolo bridge allows your tuning to remain incredibly stable, as well offering you the ability to add wide vibrato to your notes.
<G-vec00060-001-s457><add.hinzufügen><de> Eine moderne Tremolo-Brücke ermöglicht Ihre tuning sowie bietet Ihnen die Möglichkeit, Ihre Notizen breiten Vibrato hinzuzufügen unglaublich stabil bleiben.
<G-vec00060-001-s458><add.hinzufügen><en> Frameless wipers without support, use their wiper blades to add pressure, and make the force-bearing points evenly distributed, so it ha more efficient.
<G-vec00060-001-s458><add.hinzufügen><de> Frameless Wischer ohne Unterstützung, benutzen ihre Wischerblätter, um Druck hinzuzufügen, und machen die krafttragenden Punkte gleichmäßig verteilt, also ist es effizienter.
<G-vec00060-001-s459><add.hinzufügen><en> We are nearing the apex of this pyramid where there is nothing left to add.
<G-vec00060-001-s459><add.hinzufügen><de> Wir nähern uns der Spitze dieser Pyramide, wo es nichts mehr hinzuzufügen gibt.
<G-vec00060-001-s460><add.hinzufügen><en> Often it is only necessary to add a copy of the GNU GPL license text to documentation, and add an offer to provide the software source code (see FSFE's compliance tips).
<G-vec00060-001-s460><add.hinzufügen><de> Oftmals ist es ausreichend, eine Kopie des Lizenztextes der GNU GPL zur Dokumentation hinzuzufügen und das Angebot, den Quelltext zur Verfügung zu stellen zu unterbreiten (siehe dazu die Tipps der FSFE zur Lizenzeinhaltung).
<G-vec00060-001-s461><add.hinzufügen><en> Click left on the image to add a new object.
<G-vec00060-001-s461><add.hinzufügen><de> Klickt links auf das Bild um ein neues Objekt hinzuzufügen.
<G-vec00060-001-s462><add.hinzufügen><en> Specify additional DNS servers by their names and IP addresses, and then click Add to add them to the list.
<G-vec00060-001-s462><add.hinzufügen><de> Geben Sie zusätzliche DNS-Server mit Namen und IP-Adressen an, und klicken Sie dann auf Hinzufügen, um sie der Liste hinzuzufügen.
<G-vec00060-001-s463><add.hinzufügen><en> They make it simple for the average joe to add content to their site on a daily basis with just a few clicks of the mouse.
<G-vec00060-001-s463><add.hinzufügen><de> Sie bilden es einfach für den Durchschnitt Joe, Inhalt ihrem Aufstellungsort auf einer täglichen Grundlage mit gerade einigem Klicken der Maus hinzuzufügen.
<G-vec00060-001-s464><add.hinzufügen><en> ADD command is used to add new entries to the IPX configuration.
<G-vec00060-001-s464><add.hinzufügen><de> Der Befehl ADD wird verwendet, um neue Einträge zu der IPX-Konfiguration hinzuzufügen.
<G-vec00060-001-s465><add.hinzufügen><en> It may take some time to add photos to all or the most important contacts of the Thunderbird address book.
<G-vec00060-001-s465><add.hinzufügen><de> Es kann einige Zeit dauern, um Fotos hinzuzufügen, um alle oder die wichtigsten Kontakte aus dem Thunderbird-Adressbuch.
<G-vec00060-001-s466><add.hinzufügen><en> Cartier LOVE bracelet stainless steel screwdriver design needs a classic visual, but also add a contemporary interpretation of the spirit, to more sophisticated works.
<G-vec00060-001-s466><add.hinzufügen><de> Cartier Love-Armband aus Schraubendreher Design eine klassische Ästhetik erfordert, sondern auch eine zeitgemäße Interpretation von dem Geist hinzuzufügen, zu zeitgenössischen Werken.
<G-vec00060-001-s467><add.hinzufügen><en> Alternatively you can select All applications from the drop-down menu to add all applications.
<G-vec00060-001-s467><add.hinzufügen><de> Sie können auch den Eintrag Alle Anwendungen aus dem Dropdownmenü auswählen, um alle Anwendungen hinzuzufügen.
<G-vec00060-001-s468><add.hinzufügen><en> To add another effect to the image choose it in the Effects panel, and double click on it or use the icon at the bottom part of the panel.
<G-vec00060-001-s468><add.hinzufügen><de> Um einen anderen Effekt dem Bild hinzuzufügen, doppelklicken Sie darauf in der Effekte-Leiste oder benutzen Sie das Symbol im unteren Teil der Leiste.
<G-vec00060-001-s469><add.hinzufügen><en> I've verified these were causing the problem by creating a blank form and trying to add one on.
<G-vec00060-001-s469><add.hinzufügen><de> Ich habe überprüft, dass dies das Problem verursacht, indem ich ein leeres Formular erstellt und versucht habe, eines hinzuzufügen.
<G-vec00060-001-s470><add.hinzufügen><en> – add a new blank text field into your disc menu.
<G-vec00060-001-s470><add.hinzufügen><de> – Ihrem Datenträgermenü ein neues, freies Textfeld hinzuzufügen.
<G-vec00060-001-s471><add.hinzufügen><en> In some houses it is possible to add one or two extra beds.
<G-vec00060-001-s471><add.hinzufügen><de> In einigen Häusern ist es möglich, ein oder zwei zusätzliche Betten hinzuzufügen.
<G-vec00060-001-s472><add.hinzufügen><en> Then double-click the .reg file to add the information to the Windows registry.
<G-vec00060-001-s472><add.hinzufügen><de> Doppelklicken Sie dann die .reg-Datei, um die Informationen der Windows Registry hinzuzufügen.
<G-vec00060-001-s473><add.hinzufügen><en> The lead free and copper free silver mirror comes with a clear and bright surface, ensuring distinct and lifelike image.Positioned well, it also helps to add depth to any room.
<G-vec00060-001-s473><add.hinzufügen><de> Der bleifreie und kupferfreie silberne Spiegel kommt mit einer klaren und hellen Oberfläche und sorgt für ein ausgeprägtes und lebensechtes Bild.Positioniert gut, es hilft auch, Tiefe zu jedem Raum hinzuzufügen.
<G-vec00060-001-s474><add.hinzufügen><en> Tap Aa to add text, to add a sticker, or to draw on your photo or video.
<G-vec00060-001-s474><add.hinzufügen><de> Tippe auf Aa, um Text hinzuzufügen, auf, um einen Sticker hinzuzufügen oder auf, um etwas in dein Foto oder Video zu zeichnen.
<G-vec00060-001-s532><add.hinzufügen><en> With a turquoise background and a microphone as centerpiece, simply add your own text and the flyer's ready in no time.
<G-vec00060-001-s532><add.hinzufügen><de> Mit einem türkisfarbenen Hintergrund und einem Mikrofon als Mittelpunkt müssen Sie einfach nur noch Ihren eigenen Text hinzufügen und der Flyer ist im Handumdrehen fertig.
<G-vec00060-001-s533><add.hinzufügen><en> I should add a few words about the liner notes which are extensive, in German and English, with very nicely done (and a nice example of how one lays out Yiddish text w/transliteration if one's goal is to aid the reader).
<G-vec00060-001-s533><add.hinzufügen><de> Ich sollte noch ein paar Worte hinzufügen über die aufwendigen und umfangreichen Kommentare in Deutsch und Englisch, die sehr gut und ansprechend gemacht sind (und die ein gutes Beispiel dafür sind, wie jemand jiddischen Text mit Transliteration layoutet, wenn es sein Ziel ist, es dem Leser leichtzumachen).
<G-vec00060-001-s534><add.hinzufügen><en> One must add to this the fact of the absence of national leaders.
<G-vec00060-001-s534><add.hinzufügen><de> Man muss noch die Tatsache des Mangels an nationalen Führern hinzufügen.
<G-vec00060-001-s535><add.hinzufügen><en> We need to add that the Ministry of Transport doesn't agree with Uber's position and the employees are penalizing Uber drivers for charging too much.
<G-vec00060-001-s535><add.hinzufügen><de> Wir müssen noch hinzufügen, dass das Transportministerium dieser Meinung von Uber nicht zustimmt und ihre Mitarbeiter die Uber-Fahrer mit einer Strafe belegen, weil diese zu viel berechnen.
<G-vec00060-001-s536><add.hinzufügen><en> Obviously, they had to add delusional to my medical certificate.
<G-vec00060-001-s536><add.hinzufügen><de> Ganz offensichtlich mussten sie nun auch noch „wahnhafte Störungen“ zu meinem medizinischen Gutachten hinzufügen.
<G-vec00060-001-s537><add.hinzufügen><en> On the subject of narcotics, one may add that since they require a gradual increase of the amount taken, they are as veritable chains of darkness, placing man in a helpless situation.
<G-vec00060-001-s537><add.hinzufügen><de> Zum Thema Betäubungsmittel kann man noch hinzufügen, daß sie, weil sie eine allmähliche Steigerung der eingenommenen Menge er- fordern, wie wahrhaftige Ketten der Dunkelheit sind, die die Menschen in eine hilflose Lage versetzen.
<G-vec00060-001-s538><add.hinzufügen><en> Depending on the consistency, you may have to add some extra milk.
<G-vec00060-001-s538><add.hinzufügen><de> Je nach Konsistenz musst du noch etwas mehr Milch hinzufügen.
<G-vec00060-001-s539><add.hinzufügen><en> "If you want to add a second part, click on the ""+"" icon."
<G-vec00060-001-s539><add.hinzufügen><de> Möchten Sie noch einen zweiten Artikel hinzufügen, so klicken Sie auf das Plus-Icon.
<G-vec00060-001-s540><add.hinzufügen><en> Now click the Add to List button to apply the filter. This applies the filter and allows it to be displayed in the list on top.
<G-vec00060-001-s540><add.hinzufügen><de> Jetzt müssen Sie noch auf die Schaltfläche Zur Liste hinzufügen klicken; der Filter wird damit übernommen und in der Liste oben angezeigt.
<G-vec00060-001-s541><add.hinzufügen><en> I would like to add that one thing that really struck me about the experience was the knowledge that God loves everyone, and his love is all-inclusive.
<G-vec00060-001-s541><add.hinzufügen><de> Ich moechte noch hinzufügen, dass mich das Wissen in meiner Erfahrung, dass Gott jeden liebt und dass seine Liebe allumfassend ist, sehr beeindruckt hat.
<G-vec00060-001-s542><add.hinzufügen><en> If we add to their teaching experience an extra dose of life experience, international living and a zest for life, then we have a better description of our trainers.
<G-vec00060-001-s542><add.hinzufügen><de> Wenn wir zu der Unterrichtserfahrung noch eine Prise Lebenserfahrung, Internationalität und Lebensfreude hinzufügen, dann kommen wir einer guten Beschreibung unserer Trainerinnen und Trainer schon ziemlich nahe.
<G-vec00060-001-s543><add.hinzufügen><en> Now, if you got the impression, that only the instrumental tracks are worth listening, I have to add that Perez and Apocalyptica are doing a pretty fine job on “House of Chains” and “Come Back Down”.
<G-vec00060-001-s543><add.hinzufügen><de> Wenn jetzt der Eindruck entstanden ist, dass nur die instrumentalen Stücke – außer „Riot Lights“ – es wert sind gehört zu werden, muss ich schnell noch hinzufügen, dass Perez und Apocalyptica ihr ganzes Können auf „House of Chains“ und „Come Back Down“ zur Schau stellen.
<G-vec00060-001-s544><add.hinzufügen><en> I would add that the owner Philippe is very courteous.
<G-vec00060-001-s544><add.hinzufügen><de> Ich würde noch hinzufügen, dass Philippe, der Eigentümer, äußerst zuvorkommend ist.
<G-vec00060-001-s545><add.hinzufügen><en> I may add this: My experience is that no one really has spiritual knowledge without suffering.
<G-vec00060-001-s545><add.hinzufügen><de> Darf ich noch dies hinzufügen: Meine Erfahrung ist die, dass niemand ohne Leiden wirkliche geistliche Erkenntnis gewinnt.
<G-vec00060-001-s546><add.hinzufügen><en> I may add, before leaving Coquimbo, that M. Gay found in the neighbouring Cordillera, at the height of 14,000 feet above the sea, a fossiliferous formation, including a Trigonia and Pholadomya;*—both of which genera occur at the Puente del Inca.
<G-vec00060-001-s546><add.hinzufügen><de> Ehe ich Coquimbo verlasse, will ich noch hinzufügen, daszGay in der benachbarten Cordillera in einer Höhe von 14 000 Fuszüber dem Meere eine Fossile führende Formation gefunden hat, welcheeine Trigonia und Fholadomya enthielt2, welche beide Gattungen amPuente del Inca vorkommen.
<G-vec00060-001-s547><add.hinzufügen><en> Out of respect for the genuine religions honestly practiced by billions of people in the world, and for the genuine theologians, we might simply add that the theology of the market is sectarian, fundamentalist and anti-ecumenical.
<G-vec00060-001-s547><add.hinzufügen><de> Aus Achtung vor den eigentlichen Religionen, die weltweit von Milliarden Menschen achtbar ausgeübt werden, und vor den echten Theologen müssen wir noch hinzufügen, daß die Theologie des Marktes sektiererisch, fundamentalistisch und antiökumenisch ist.
<G-vec00060-001-s548><add.hinzufügen><en> "If we add to the pleasant and useful healing mud the climatic and geographic benefits (a warm and shallow sea), we can say that the beach with the healing mud in the Soline Bay has been rightfully dubbed ""a beach for the entire family""."
<G-vec00060-001-s548><add.hinzufügen><de> "Wenn wir dem Heilschlamm und den günstigen Klimaverhältnissen noch die günstige geografische Lage hinzufügen (immer angenehmes Wetters und flaches Meer) wird der Strand mit Heilschlamm in der Bucht Soline zu Recht als ""Strand für die ganze Familie"" bezeichnet."
<G-vec00060-001-s549><add.hinzufügen><en> From a Western perspective, we may add that when anger or hostility is aimed at another person or group, it may take the form of rejecting the person or group.
<G-vec00060-001-s549><add.hinzufügen><de> Aus abendländischer Perspektive können wir noch hinzufügen, dass Ärger, wenn er sich auf eine andere Person oder Gruppe richtet, in Form von Ablehnung der Person oder Gruppe auftreten kann.
<G-vec00060-001-s550><add.hinzufügen><en> Tertiary strata, such as are here described, appear to extend along the whole coast between Rio Chupat and Port Desire, except where interrupted by the underlying claystone porphyry, and by some metamorphic rocks; these hard rocks, I may add, are found at intervals over a space of about five degrees of latitude, from Point Union to a point between Port S. Julian and S. Cruz, and will be described in the ensuing chapter.
<G-vec00060-001-s550><add.hinzufügen><de> Tertiäre Schichten, so wie sie hier beschrieben wurden, erstreckensich augenscheinlich der ganzen Küste zwischen dem Rio Chupat undPort Desire entlang, ausgenommen wo sie von dem darunter liegendenToeca-Gestein, Porphyr und von einigen metamorphischen Gesteinenunterbrochen werden; ich will noch hinzufügen, dasz diese harten Ge-steine in Zwischenräumen über einen Raum von ungefähr fünf Breiten-graden von Point Union bis zu einem Punkte zwischen Port San Julianund Santa Cruz gefunden werden; sie werden im folgenden Capitel be-schrieben.
<G-vec00060-001-s570><add.hinzufügen><en> Effect: Under the Effect tabï1⁄4Œyou can add desired effect, adjust brightness, contrast and saturation.
<G-vec00060-001-s570><add.hinzufügen><de> Effekt: Unter der Registerkarte Effekt können Sie gewünschte Effekt hinzufügen, Helligkeit, Kontrast und Sättigung einstellen.
<G-vec00060-001-s571><add.hinzufügen><en> Art.code: Pallet-WK Log in or sign up to add to Favourites.
<G-vec00060-001-s571><add.hinzufügen><de> Art.Kode: Pallet-WK Log ein oder Melden Sie sich an um Favoriten hinzufügen.
<G-vec00060-001-s572><add.hinzufügen><en> Add as many viewing stations as you need, from 2 to 20 viewing stations can be used with single microscope.
<G-vec00060-001-s572><add.hinzufügen><de> Sie können Ihrem Mikroskop 2 bis 20 Diskussionsstationen hinzufügen, genau so viel, wie Sie brauchen.
<G-vec00060-001-s573><add.hinzufügen><en> Maybe you'll even discover a song or two to add to your own workout music playlist.
<G-vec00060-001-s573><add.hinzufügen><de> Vielleicht finden Sie hier sogar ein oder zwei Songs, die Sie Ihrer Workout-Playliste hinzufügen möchten.
<G-vec00060-001-s574><add.hinzufügen><en> Click the Project tab, right-click the SQL folder, and select Add Active File to Project from the context menu.
<G-vec00060-001-s574><add.hinzufügen><de> Klicken Sie auf das Projektregister, klicken Sie mit der rechten Maustaste auf den Ordner SQL und wählen Sie im Kontextmenü den Befehl Aktive Datei zum Projekt hinzufügen .
<G-vec00060-001-s575><add.hinzufügen><en> You may need to add USB drivers to the Windows 7 image.
<G-vec00060-001-s575><add.hinzufügen><de> Hinweis Möglicherweise müssen Sie dem Windows 7-Abbild USB-Treiber hinzufügen.
<G-vec00060-001-s576><add.hinzufügen><en> Right-click the connection to which you want to add a static IP address and then click Properties.
<G-vec00060-001-s576><add.hinzufügen><de> Klicken Sie mit der rechten Maustaste auf die Verbindung, der Sie eine statische IP-Adresse hinzufügen möchten, und klicken Sie dann auf Eigenschaften.
<G-vec00060-001-s577><add.hinzufügen><en> Use the Add Always Allowed URL dialog box to add a URL sequence to the list of URL sequences for which the request-filtering module will always grant access.
<G-vec00060-001-s577><add.hinzufügen><de> Im Dialogfeld Ablehnungssequenz hinzufügen können Sie der Liste der URL-Sequenzen eine URL-Sequenz hinzufügen, für die das Anforderungsfilterungsmodul den Zugriff ablehnt.
<G-vec00060-001-s578><add.hinzufügen><en> for think-cell.adm: In the Group Policy Object Editor use Add/Remove Templates... under Action
<G-vec00060-001-s578><add.hinzufügen><de> für think-cell.adm: Verwenden Sie im Gruppenrichtlinienobjekt-Editor Vorlagen hinzufügen/entfernen... im Menü Aktion .
<G-vec00060-001-s579><add.hinzufügen><en> Add another editing point to a closed shape: Option-click the shape's border where you want to add a point.
<G-vec00060-001-s579><add.hinzufügen><de> Weiteren Bearbeitungspunkt zu einer geschlossenen Form hinzufügen: Klicken Sie bei gedrückter Wahltaste an der Stelle auf den Rahmen der Form, an der Sie einen Punkt hinzufügen wollen.
<G-vec00060-001-s580><add.hinzufügen><en> With the free, easy-to-use VIRB Mobile app and VIRB Edit desktop software, you can edit, stabilize, share and add data overlays to videos.
<G-vec00060-001-s580><add.hinzufügen><de> Mit der kostenlosen, benutzerfreundlichen VIRB Mobile-App und der Desktop-Software VIRB Edit kannst du Videos bearbeiten, Stabilisierungen anwenden, sie mit anderen teilen und Datenüberlagerungen hinzufügen.
<G-vec00060-001-s581><add.hinzufügen><en> Determine the attribute value you want to remove and then the attribute value you want to add to the crossTank entries.
<G-vec00060-001-s581><add.hinzufügen><de> Legen Sie hierzu zunächst den Attributwert fest, den Sie entfernen möchten, und anschließend den Attributwert, den Sie zu den crossTank-Einträgen hinzufügen möchten.
<G-vec00060-001-s582><add.hinzufügen><en> The below VBA code can help to add captions to all images at once in a Word document.
<G-vec00060-001-s582><add.hinzufügen><de> Mit dem folgenden VBA-Code können Sie Bildunterschriften in einem Word-Dokument auf einmal hinzufügen.
<G-vec00060-001-s583><add.hinzufügen><en> To install GPMC on Windows Server 2008 R2, use the Add Features Wizard in Server Manager.
<G-vec00060-001-s583><add.hinzufügen><de> Verwenden Sie zum Installieren der GPMC unter Windows Server 2008 R2 den Assistenten zum Hinzufügen von Features im Server-Manager.
<G-vec00060-001-s584><add.hinzufügen><en> In the Manage Smart Media dialog, select a tray, click Add, and select Add from tray.
<G-vec00060-001-s584><add.hinzufügen><de> Markieren Sie im Fenster „Smarte Medien verwalten“ den Eintrag eines Papierfachs, klicken Sie auf „ Hinzufügen “ und wählen Sie „ Aus Fach hinzufügen “.
<G-vec00060-001-s585><add.hinzufügen><en> When using this method, it is possible to add audio data later, until the CD-R/RW disc has been finalized.
<G-vec00060-001-s585><add.hinzufügen><de> Bei dieser Methode können Sie Audiodaten auch später hinzufügen, bis die CD-R/RW- Disk finalisiert wurde.
<G-vec00060-001-s586><add.hinzufügen><en> In the details pane, right-click the user you want to add to the NIS domain, and then click Properties.
<G-vec00060-001-s586><add.hinzufügen><de> Klicken Sie im Detailbereich mit der rechten Maustaste auf den Benutzer, den Sie der NIS-Domäne hinzufügen möchten, und klicken Sie dann auf Eigenschaften.
<G-vec00060-001-s587><add.hinzufügen><en> When stewing dishes, you can add a little olive or other vegetable oil.
<G-vec00060-001-s587><add.hinzufügen><de> Wenn Sie Gerichte schmoren, können Sie etwas Olivenöl oder anderes Pflanzenöl hinzufügen.
<G-vec00060-001-s588><add.hinzufügen><en> Contents: 4 cards with envelop 2 Designs a Package Log in or sign up to add to Favourites.
<G-vec00060-001-s588><add.hinzufügen><de> Inhalt: 4 Karten mit Umschlage 2 Verschiedene pro Packung Log ein oder Melden Sie sich an um Favoriten hinzufügen.
<G-vec00499-001-s589><add.verleihen><en> The bases are available in all Cubit colors and veneers and add a classic touch to the shelf.
<G-vec00499-001-s589><add.verleihen><de> Die Sockel sind in allen Cubit-Farben und Furnieren erhältlich – verleihen dem Regal eine klassische Note.
<G-vec00499-001-s590><add.verleihen><en> A light grey block is used to add colour density to the bush.
<G-vec00499-001-s590><add.verleihen><de> Ein hellgrauer Druckstock wurde dazu eingesetzt, dem Busch Farbdichte zu verleihen.
<G-vec00499-001-s591><add.verleihen><en> Flavoured olive oil is a wonderful marinade that can add flavour to salads, rice, boiled vegetables, potatoes, pasta, meat and fish, or be used as the main ingredient in a vinaigrette.
<G-vec00499-001-s591><add.verleihen><de> Das aromatisierte Olivenöl ist eine wunderbare Marinade, die Salaten, Reis, gekochtem Gemüse, Kartoffeln, Teigwaren, Fleisch- und Fischgerichten Duft verleihen, oder der Hauptbestandteil zu einer anderen Vinegrette von Ihnen werden kann.
<G-vec00499-001-s592><add.verleihen><en> To fully appreciate the patience required to add a bold new hue to this material, it pays to understand just how difficult it is to make something as seemingly simple as a ceramic bezel.
<G-vec00499-001-s592><add.verleihen><de> Wenn man die Geduld, die erforderlich ist, diesem Material einen kräftigen neuen Farbton zu verleihen, wahrhaft zu würdigen wissen will, muss man zunächst verstehen, wie schwierig es ist, etwas scheinbar so Einfaches wie eine Keramiklünette herzustellen.
<G-vec00499-001-s593><add.verleihen><en> The loose fit with side slits, a dropped hemline in the back, the drawstring hood and the straight sleeves with dropped shoulders add a bit of urban style to your time off.Athletic Life is a lifestyle line from Freddy, designed for those who love athletic garments with unique character.
<G-vec00499-001-s593><add.verleihen><de> Die lockere Passform mit Seitenschlitzen mit verlängertem Rückenteil, der Kordelzug an der Kapuze und die geraden Ärmel mit hängender Schulter verleihen Ihren Freizeitlooks urbanen Stil.Athletic Life ist die Lifestyle-Linie von Freddy, die sich gern sportlich und zugleich erlesen kleiden.
<G-vec00499-001-s594><add.verleihen><en> The unique decorative pillow slips add a sofa or chair made of euro pallets an exceptional charm.
<G-vec00499-001-s594><add.verleihen><de> Die einzigartigen Zierkissen verleihen einem Sofa oder Stuhl, gefertigt aus Euro-Paletten, einen außergewöhnlichen Charme.
<G-vec00499-001-s595><add.verleihen><en> Keratin rich to add volume, structure and shine, the conditioner will leave your hair feeling healthy and replenished.
<G-vec00499-001-s595><add.verleihen><de> Reichhaltig an Keratin, um Volumen, Struktur und Glanz zu verleihen; die Spülung wird dein Haar revitalisiert mit einer verbesserten Feuchtigkeit und Gesundheit hinterlassen.
<G-vec00499-001-s596><add.verleihen><en> If you want to enhance your performance in the gym and add serious size onto your frame, look no further than Storm.
<G-vec00499-001-s596><add.verleihen><de> Wenn Sie Ihre Leistung im Fitnessstudio verbessern und Ihrem Rahmen eine ernstzunehmende Größe verleihen möchten, dann sind Sie bei Storm genau richtig.
<G-vec00499-001-s597><add.verleihen><en> When sliced the juice can be used to add flavour to a dish.
<G-vec00499-001-s597><add.verleihen><de> Man kann auch den Saft der Scheiben benutzen um Gerichten Geschmack zu verleihen.
<G-vec00499-001-s598><add.verleihen><en> A main highlight this season is the white silk blouses with transparent sleeves that will add a certain je ne sais quoi to any outfit.
<G-vec00499-001-s598><add.verleihen><de> Besonderes Highlight diese Saison sind weiße Seidenblusen mit transparenten Ärmeln, die jedem Look das gewisse Etwas verleihen.
<G-vec00499-001-s599><add.verleihen><en> Taps are available in stainless steel as well as the latest ceramic colours: an ideal choice for anyone looking to add a very special touch to their kitchen.
<G-vec00499-001-s599><add.verleihen><de> Die Armaturen sind in Edelstahl sowie in aktuellen Keramikfarben verfügbar: ideal für alle, die ihrer Küche das gewisse Etwas verleihen wollen.
<G-vec00499-001-s600><add.verleihen><en> The grey and white highlights add depth to the supple and soft Genuine Rabbit Fur hood and lined interior.
<G-vec00499-001-s600><add.verleihen><de> Die grauen und weißen Highlights der geschmeidig und weich echtes Kaninchenfell Haube Tiefe verleihen und Innenfutter.
<G-vec00499-001-s601><add.verleihen><en> Damaged leaves will not add beauty to the anemone.
<G-vec00499-001-s601><add.verleihen><de> Beschädigte Blätter werden der Anemone keine Schönheit verleihen.
<G-vec00499-001-s602><add.verleihen><en> Even if the weather forecast isn't calling for snow, you can easily add some winter flair to your pictures using the Snowflakes Frame Pack by AKVIS.
<G-vec00499-001-s602><add.verleihen><de> Auch wenn die Wettervorhersage nicht so vielversprechend ausfällt, können Sie das Schneeflocken-Paket von AKVIS benutzen, um Ihren Bildern etwas Winterflair zu verleihen.
<G-vec00499-001-s603><add.verleihen><en> With Triluminos Colour you'll enjoy brilliant images and a wide range of colours which add depth to any scene
<G-vec00499-001-s603><add.verleihen><de> Mit Triluminos Colour genießen Sie brillante Bilder und eine Vielzahl von Farben, die jeder Szene Tiefe verleihen.
<G-vec00499-001-s604><add.verleihen><en> The modern decorative table cloths will add a fresh color to your dining room.
<G-vec00499-001-s604><add.verleihen><de> Die modernen dekorativen Tischdecken verleihen Ihrem Esszimmer eine frische Farbe.
<G-vec00499-001-s605><add.verleihen><en> Blue support caps add bulk to the heel wrap with grey top lines and extra material bits creating balance through a much more neutral tone.
<G-vec00499-001-s605><add.verleihen><de> Blaue Stützkappen verleihen dem Fersenwickel mehr Volumen mit grauen Oberlinien und zusätzlichen Materialteilen, die durch einen viel neutraleren Farbton ein Gleichgewicht schaffen.
<G-vec00499-001-s606><add.verleihen><en> Unique details like local fabrics, alcoves and stained-glass windows add an elegant touch.
<G-vec00499-001-s606><add.verleihen><de> Einzigartige Details wie lokale Stoffe, Nischen und Glasmalereien verleihen den Zimmern eine elegante Note.
<G-vec00499-001-s607><add.verleihen><en> GOI paste is used to add shine to the product.
<G-vec00499-001-s607><add.verleihen><de> GOI-Paste wird verwendet, um dem Produkt Glanz zu verleihen.
<G-vec00407-001-s608><add.zugeben><en> Gradually add the rest of the milk and the eggs, one at a time, and whisk to a smooth batter with no lumps.
<G-vec00407-001-s608><add.zugeben><de> Die restliche Milch und die Eier zugeben, wieder verrühren, bis der Teig glatt und ohne Klumpen ist.
<G-vec00407-001-s609><add.zugeben><en> Add beef stock and let all simmer about 15 minutes.
<G-vec00407-001-s609><add.zugeben><de> Die Suppe zugeben und zugedeckt etwa 15 Minuten dünsten.
<G-vec00407-001-s610><add.zugeben><en> Add the vinegar, oil and mustard and combine.
<G-vec00407-001-s610><add.zugeben><de> Essig, Öl und Senf zugeben und vermengen.
<G-vec00407-001-s611><add.zugeben><en> Add egg yolk, port, red, simple syrup and scotch whisky.
<G-vec00407-001-s611><add.zugeben><de> Eigelb, Portwein, rot, Zuckersirup und Schottischer Whisky zugeben.
<G-vec00407-001-s612><add.zugeben><en> Add much liquid until the dough is thick but running.
<G-vec00407-001-s612><add.zugeben><de> So viel Flüssigkeit zugeben, dass ein zähflüssiger Teig entsteht.
<G-vec00407-001-s613><add.zugeben><en> Dosage EHEIM Plant Care 7 Days Fertilizer: Add weekly 10 ml per 100 litres of aquarium water.
<G-vec00407-001-s613><add.zugeben><de> Dosierung EHEIM Plant Care 7 Tage Langzeitdünger: Wöchentlich 10 ml auf 100 Liter Aquarienwasser zugeben.
<G-vec00407-001-s614><add.zugeben><en> Combine water and egg, add 0,5 tsp.
<G-vec00407-001-s614><add.zugeben><de> Wasser und Ei mischen, 0,5 TL zugeben.
<G-vec00407-001-s615><add.zugeben><en> Add stock and saffron, mix.
<G-vec00407-001-s615><add.zugeben><de> Brühe und Safran zugeben, verrühren.
<G-vec00407-001-s616><add.zugeben><en> Inside your basket, you can edit the goods you already inserted in or add and remove the new goods.
<G-vec00407-001-s616><add.zugeben><de> Im Korb kann man Warenmenge einrichten, die Produkte zugeben oder abnehmen und im Korb sehen Sie auch die gesamte Einzahlungssumme.
<G-vec00407-001-s617><add.zugeben><en> Add daily when watering the plant in the first 2 weeks.
<G-vec00407-001-s617><add.zugeben><de> In den ersten 2 Wochen täglich während des Gießens zugeben.
<G-vec00407-001-s618><add.zugeben><en> Juice of lemons squeeze into a cup, mix it with chilled water and add ice.
<G-vec00407-001-s618><add.zugeben><de> Saft von Zitronen in eine Tasse drücken, mit kaltem Wasser mischen und Eis zugeben.
<G-vec00407-001-s619><add.zugeben><en> Add Absolut Pears.
<G-vec00407-001-s619><add.zugeben><de> Absolut Pears zugeben.
<G-vec00407-001-s620><add.zugeben><en> Add black raspberry liqueur, Absolut Vodka and triple sec.
<G-vec00407-001-s620><add.zugeben><de> Schwarzer Himbeerlikör, Absolut Vodka und Triple Sec zugeben.
<G-vec00407-001-s621><add.zugeben><en> Add wine, vinegar and boiled noodles, mix well and bring to the boil.
<G-vec00407-001-s621><add.zugeben><de> Wein, Essig und die gekochten Nudeln zugeben, alles gut vermischen und aufkochen.
<G-vec00407-001-s622><add.zugeben><en> After 25 minutes, add the vegetables and continue to steam.
<G-vec00407-001-s622><add.zugeben><de> Nach 25 Minuten Gemüse zugeben und weiterdämpfen.
<G-vec00407-001-s623><add.zugeben><en> Add the peeled and finely sliced onions.
<G-vec00407-001-s623><add.zugeben><de> Die Zwiebeln schälen, in feine Streifen schneiden und zugeben.
<G-vec00407-001-s624><add.zugeben><en> Mix well, add corn flour, breadcrumbs and flour.
<G-vec00407-001-s624><add.zugeben><de> Gut vermischen, Maismehl, Paniermehl und Mehl zugeben.
<G-vec00407-001-s625><add.zugeben><en> Add the flour bit by bit until the dow does not stick to your hands anymore.
<G-vec00407-001-s625><add.zugeben><de> Dabei das Mehl nur nach und nach zugeben, bis der Teig nicht mehr an den Händen klebt.
<G-vec00407-001-s626><add.zugeben><en> If necessary, add some more water (possibly up to about 80 ml).
<G-vec00407-001-s626><add.zugeben><de> Gegebenenfalls mehr Wasser zugeben (eventuell etwa 80 ml).
<G-vec00499-001-s616><add.zugeben><en> Inside your basket, you can edit the goods you already inserted in or add and remove the new goods.
<G-vec00499-001-s616><add.zugeben><de> Im Korb kann man Warenmenge einrichten, die Produkte zugeben oder abnehmen und im Korb sehen Sie auch die gesamte Einzahlungssumme.
<G-vec00499-001-s625><add.zugeben><en> Add the flour bit by bit until the dow does not stick to your hands anymore.
<G-vec00499-001-s625><add.zugeben><de> Dabei das Mehl nur nach und nach zugeben, bis der Teig nicht mehr an den Händen klebt.
<G-vec00407-002-s038><add.addieren><en> The EDATE function requires two values (also referred to as argument): the start date and the number of months that you want to add or subtract.
<G-vec00407-002-s038><add.addieren><de> Für die EDATUM-Funktion werden zwei Werte (auch als Argumente bezeichnet) benötigt: das Startdatum und die Anzahl der Monate, die Sie addieren oder subtrahieren möchten.
<G-vec00407-002-s039><add.addieren><en> To the product price it is to be add the delivery cost, which can vary depending on the chosen mode of delivery and/or the total cost of the order.
<G-vec00407-002-s039><add.addieren><de> Zum Produktpreis sind die Versandkosten zu addieren, die je nach gewählter Versandart und / oder Gesamtkosten der Bestellung variieren können.
<G-vec00407-002-s040><add.addieren><en> Next to the resulting number of panels add 10% when plating the square of the rectangular shape.
<G-vec00407-002-s040><add.addieren><de> Neben der resultierenden Anzahl von Paneelen addieren 10% beim Plattieren des Quadrats der rechteckigen Form.
<G-vec00407-002-s041><add.addieren><en> Customized size, material, color, and design, add your logo, meeting your unique jewellery.
<G-vec00407-002-s041><add.addieren><de> Kundengebundene Größe, Material, Farbe und Entwurf, addieren Ihr Logo und treffen Ihren einzigartigen Schmuck.
<G-vec00407-002-s042><add.addieren><en> Sometimes worker are not willing to add the oil everyday.
<G-vec00407-002-s042><add.addieren><de> Manchmal sind Arbeitskraft nicht bereit, das tägliche Öl zu addieren.
<G-vec00407-002-s043><add.addieren><en> And we do not need to add the oil manually.
<G-vec00407-002-s043><add.addieren><de> Und wir brauchen nicht, das Öl manuell zu addieren.
<G-vec00407-002-s044><add.addieren><en> We will add more material as we prepare it.
<G-vec00407-002-s044><add.addieren><de> Wir addieren mehr Material, wie wir es vorbereiten.
<G-vec00407-002-s045><add.addieren><en> Inns double the value of a road, while Cathedrals add a bonus point per city tile.
<G-vec00407-002-s045><add.addieren><de> Wirtshäuser verdoppeln den Wert von Straßen, Kathedralen addieren pro Stadtkarte einen Punkt.
<G-vec00407-002-s047><add.addieren><en> The calculator can add, subtract, multiply and divide.
<G-vec00407-002-s047><add.addieren><de> Die Rechenmaschine kann addieren, subtrahieren, dividieren und multiplizieren.
<G-vec00407-002-s048><add.addieren><en> Path combinations (Add/Subtract/Intersect/Exclude Overlap) are nondestructive.
<G-vec00407-002-s048><add.addieren><de> Pfadkombinationen (Addieren/Subtrahieren/Schnittmenge bilden/Überlappung ausschließen) sind nicht destruktiv.
<G-vec00407-002-s049><add.addieren><en> This year we add an grey board laminated machine, can process the grey board laminated with duplex board, black card and kraft paper.
<G-vec00407-002-s049><add.addieren><de> Dieses Jahr addieren wir eine Graupappe lamellierte Maschine, können die Graupappe verarbeiten, die mit Duplexbrett, schwarzer Karte und Kraftpapier lamelliert wird.
<G-vec00407-002-s050><add.addieren><en> It is also available to add new one.
<G-vec00407-002-s050><add.addieren><de> Es ist auch verfügbar, Neues zu addieren.
<G-vec00407-002-s051><add.addieren><en> The amounts of components A) and B) add up to at least about 75 wt .-%, preferably at least 90 wt .-%, in particular 100 wt .-%, based on the total weight of the composition.
<G-vec00407-002-s051><add.addieren><de> Die Mengen der Komponenten A) und B) addieren sich vorzugsweise zu mindestens 75 Gew.-%, bevorzugt zu mindestens 90 Gew.-%, insbesondere zu 100 Gew.-%, bezogen auf das Gesamtgewicht der Zusammensetzung.
<G-vec00407-002-s052><add.addieren><en> To add a specific subnet, right click in the list, select the Add network option and enter the specific details for that network.
<G-vec00407-002-s052><add.addieren><de> Um ein Subnetz hinzuzufügen, rechts klicken Sie in der Liste, selektieren Sie die Netzwerk addieren Option und geben die entsprechenden Daten für das Netz ein.
<G-vec00407-002-s054><add.addieren><en> FreeVIEW → Used by millions of people worldwide, Family Tree Builder helps you research your family history, build your family tree and add photos, historical records and more.
<G-vec00407-002-s054><add.addieren><de> Weltweit verwendet durch Millionen Leute, hilft Family Tree Builder Ihnen, Ihre Familiengeschichte zu erforschen, Ihren Stammbaum zu errichten und Fotos, historische Aufzeichnungen und mehr zu addieren.
<G-vec00407-002-s055><add.addieren><en> This is because the ropes themselves can add additional space.
<G-vec00407-002-s055><add.addieren><de> Dieses ist, weil die Seile selbst zusätzlichen Raum addieren können.
<G-vec00407-002-s056><add.addieren><en> The annual losses add up to billions and threaten the reputation, liquidity and credit capacity of your business.
<G-vec00407-002-s056><add.addieren><de> Die jährlichen Schäden addieren sich zu Milliarden und gefährden die Reputation, Liquidität und Kreditfähigkeit Ihres Unternehmens.
<G-vec00407-002-s133><add.dazugeben><en> Add the sundried tomatoes and stir to distribute evenly.
<G-vec00407-002-s133><add.dazugeben><de> Rasch einrühren und dann das restliche Wasser dazugeben und zu einen geschmeidigen Teig rühren.
<G-vec00407-002-s134><add.dazugeben><en> Add the other ingredients after turning.
<G-vec00407-002-s134><add.dazugeben><de> Nach dem Wenden die anderen Zutaten dazugeben.
<G-vec00407-002-s135><add.dazugeben><en> Gradually add the remaining broth.
<G-vec00407-002-s135><add.dazugeben><de> Die restliche Brühe nach und nach dazugeben.
<G-vec00407-002-s136><add.dazugeben><en> Add the eggs one after another and mix well in between.
<G-vec00407-002-s136><add.dazugeben><de> Die Eier einzeln dazugeben und jeweils gut unterrühren.
<G-vec00407-002-s137><add.dazugeben><en> Add the sour cream and mix until smooth.
<G-vec00407-002-s137><add.dazugeben><de> Den Schmand (sour cream) dazugeben und glattrühren.
<G-vec00407-002-s138><add.dazugeben><en> Mix the almonds with the sugar, add to the bowl and fold in.
<G-vec00407-002-s138><add.dazugeben><de> Die gemahlenen Mandeln mit dem Zucker vermischen und dann zur Schüssel dazugeben und kurz unterrühren.
<G-vec00407-002-s139><add.dazugeben><en> Add the fresh herbs and pomegranate seeds and mix well.
<G-vec00407-002-s139><add.dazugeben><de> Quorn Hack, Brotkrümel, verkopftes Ei und Petersilie dazugeben und untermischen.
<G-vec00407-002-s140><add.dazugeben><en> Continuing to whisk, add flour, baking powder, and cinnamon.
<G-vec00407-002-s140><add.dazugeben><de> Unter Rühren Mehl, Backpulver und Zimt dazugeben und verrühren.
<G-vec00407-002-s141><add.dazugeben><en> Add the espresso followed by the water to lower the alcohol content.
<G-vec00407-002-s141><add.dazugeben><de> Den Zucker im Espresso schmelzen und das Wasser dazugeben.
<G-vec00407-002-s142><add.dazugeben><en> Sift the confectioner's sugar and cocoa into a bowl, add cream cheese and mix well.
<G-vec00407-002-s142><add.dazugeben><de> Puderzucker und Kakao in eine Schüssel sieben, den Frischkäse dazugeben und gut verrühren - es sollte eine cremige Masse entstehen.
<G-vec00407-002-s143><add.dazugeben><en> Add the minced basil.
<G-vec00407-002-s143><add.dazugeben><de> Das gehackte Basilikum dazugeben.
<G-vec00407-002-s144><add.dazugeben><en> Add the herbs, garlic, salt and pepper and cook for another 5 minutes. Add the water and cook until it evaporates.
<G-vec00407-002-s144><add.dazugeben><de> Gewürze zufügen und noch einmal für 5 min braten, anschließend das Wasser dazugeben und kochen, bis es verdampft ist.
<G-vec00407-002-s145><add.dazugeben><en> Add the rice noodles and garnish your soup with fresh cilantro, fresh chili and add some more tamari or lime juice if you prefer.
<G-vec00407-002-s145><add.dazugeben><de> Nun die Reisnudeln dazugeben und die Suppe mit etwas frischem Koriander und frischen Chili oder Peperoni garnieren.
<G-vec00407-002-s146><add.dazugeben><en> Add the eggs and mix to combine.
<G-vec00407-002-s146><add.dazugeben><de> Die Joghurtmasse dazugeben und schnell zuzsammenschlagen.
<G-vec00407-002-s147><add.dazugeben><en> Grate the carrots very fine and add the sprouts and cabbage.
<G-vec00407-002-s147><add.dazugeben><de> Die Möhren sehr fein raspeln und den Rosenkohl und Kohl dazugeben.
<G-vec00407-002-s148><add.dazugeben><en> Clean the avocado, blend the pulp with extra virgin olive oil, chili, and lime juice and add the coffee.
<G-vec00407-002-s148><add.dazugeben><de> Die Avocado säubern, das Fruchtfleisch mit nativem Olivenöl, Chili und Limettensaft pürieren und den Kaffee dazugeben.
<G-vec00407-002-s149><add.dazugeben><en> The 2-nd glass of water and the salt add.
<G-vec00407-002-s149><add.dazugeben><de> Das 2.Glas Wasser und das Salz dazugeben.
<G-vec00407-002-s150><add.dazugeben><en> Finally, add the cooked mussels.
<G-vec00407-002-s150><add.dazugeben><de> Zuletzt die gekochten Muscheln dazugeben.
<G-vec00407-002-s151><add.dazugeben><en> Finally, add the drained mandarins with a little of the liquid and fold in.
<G-vec00407-002-s151><add.dazugeben><de> Zum Schluss die abgetropfen Mandarinen mit ein wenig von der Flüssigkeit dazugeben und unterheben.
<G-vec00407-002-s209><add.einfügen><en> Besides adding an audio file, you can also use Wondershare Filmora (originally Wondershare Video Editor) to record and add your own voiceover.
<G-vec00407-002-s209><add.einfügen><de> Neben dem Hinzufügen einer Audiodatei, können Sie mit Wondershare Filmora auch Ihre eigenen Voiceover aufnehmen und einfügen.
<G-vec00407-002-s210><add.einfügen><en> Yes, you can add playlists just like albums or songs to a Box.
<G-vec00407-002-s210><add.einfügen><de> Ja, du kannst Playlists genau wie Alben oder einzelne Songs in eine Box einfügen.
<G-vec00407-002-s211><add.einfügen><en> In the Add Field dialog box, type a name for your new field, and then click OK.
<G-vec00407-002-s211><add.einfügen><de> Klicken Sie im Dialogfeld Adressfeld einfügen auf die gewünschten Adresselemente, und klicken Sie dann auf OK.
<G-vec00407-002-s212><add.einfügen><en> To add Endpoint Management enterprise functionality to mobile apps, you wrap them with the MDX Toolkit.
<G-vec00407-002-s212><add.einfügen><de> Zum Einfügen von Endpoint Management-Unternehmensfunktionen werden mobile Apps mit dem MDX Toolkit umschlossen.
<G-vec00407-002-s213><add.einfügen><en> If you are editing a wiki page or a publishing page, click an editable area of the page where you want to add the Content Query Web Part.
<G-vec00407-002-s213><add.einfügen><de> Wenn Sie eine Wiki-Seite oder eine Veröffentlichungsseite bearbeiten, klicken Sie an einer bearbeitbaren Position auf der Seite, an der Sie das Webpart für Inhaltsabfragen einfügen möchten.
<G-vec00407-002-s214><add.einfügen><en> We would like to add a litte logo like the one you can see on the right to a number of images.
<G-vec00407-002-s214><add.einfügen><de> Wir würden gern ein kleines Logo, wie du es rechts sehen kannst, in eine Anzahl von Bildern einfügen.
<G-vec00407-002-s215><add.einfügen><en> Enter the Re number, the measured coefficients cl und cd, and the corresponding angle of attack alpha in the edit fields below the list. Then click on 'Add' to have the data assigned to the list.
<G-vec00407-002-s215><add.einfügen><de> Trage die Re-Zahl, die gemessenen Beiwerte ca und cw und den jeweiligen Anstellwinkel alpha in die Eingabefelder unter der Liste ein und klicke auf 'Einfügen', um sie in die Liste zu übertragen.
<G-vec00407-002-s216><add.einfügen><en> Also, you can add own additions to the privacy policy with this plugin which are kept by an update of the plugin.
<G-vec00407-002-s216><add.einfügen><de> Außerdem kannst du über dieses Plugin eigene Abschnitte einfügen, welche auch bei einem Update der Datenschutzerklärung bestehen bleiben.
<G-vec00407-002-s217><add.einfügen><en> To add a new field, click on the relevant form and choose the type of field you would like to add on a form panel, opened next to the text editor toolbar
<G-vec00407-002-s217><add.einfügen><de> Um ein neues Feld einzufügen, klicken Sie auf das betreffende Formular und wählen Sie den Feldtyp, den Sie einfügen möchten, aus der Formularanzeige, die sich neben dem Texteditorfeld öffnet.
<G-vec00407-002-s218><add.einfügen><en> You could add, for example, a second therapist’s availability to the schedule.
<G-vec00407-002-s218><add.einfügen><de> Du kannst beispielsweise die Verfügbarkeit eines zweiten Therapeuten in demselben Kalender einfügen.
<G-vec00407-002-s219><add.einfügen><en> When you're modifying the Touch Bar, the icon (Space) indicates an empty slot where you can add a command.
<G-vec00407-002-s219><add.einfügen><de> Wenn Sie die Touch Bar ändern, bezeichnet das Symbol eine freie Stelle, an der Sie einen Befehl einfügen können.
<G-vec00407-002-s220><add.einfügen><en> With the Coupa app, you can use voice entry to add expense lines, take photos to capture receipts, and submit your expense report without ever opening your laptop.
<G-vec00407-002-s220><add.einfügen><de> Mit der Coupa-App können Sie sprachgesteuert zusätzliche Reisekosten-Positionen ergänzen, fotografierte Quittungen einfügen und Ihre Abrechnung ohne Laptop absenden.
<G-vec00407-002-s221><add.einfügen><en> add background music easily.
<G-vec00407-002-s221><add.einfügen><de> Hintergrundmusik einfügen.
<G-vec00407-002-s222><add.einfügen><en> Everyone can create a profile on gigmit and link it with their social media profiles, add their own songs and videos and use the gigmit Artist Page as their Electronic Press Kit.
<G-vec00407-002-s222><add.einfügen><de> Jeder kann sich ein Profil bei gigmit anlegen und seine Social Media Profile verknüpfen, Songs und Videos einfügen und die gigmit Artist Page als sein eigenes Electronic Press Kit nutzen.
<G-vec00407-002-s223><add.einfügen><en> You can add a different time tag right next to the original one so that you don't have to type it twice.
<G-vec00407-002-s223><add.einfügen><de> Du kannst einen anderen Zeit-Tag rechts neben dem Originalen einfügen, damit du ihn nicht zweimal eingeben musst.
<G-vec00407-002-s224><add.einfügen><en> In Step 4 of the Email Creation Process, go to the block where you would like to add your Flickr image.
<G-vec00407-002-s224><add.einfügen><de> Im Schritt 4 des E-Mail Erstellungs-Vorgang, gehen Sie auf den Block wo Sie das Flickr Bild einfügen wollen.
<G-vec00407-002-s225><add.einfügen><en> You can then add a comment on the right side of the app pane.
<G-vec00407-002-s225><add.einfügen><de> Anschließend können Sie auf der rechten Seite des App-Fensters einen Kommentar einfügen.
<G-vec00407-002-s226><add.einfügen><en> Subsequently I have to assemble the films, add music and label it; this is a job again.
<G-vec00407-002-s226><add.einfügen><de> Nachher muss ich dafür die Filme zusammenstellen, Musik einfügen und beschriften, das ist auch wieder eine Arbeit für sich.
<G-vec00407-002-s227><add.einfügen><en> The rectangle/square and ellipse/circle tools allow you to add mark-up or simple drawings to your documents.
<G-vec00407-002-s227><add.einfügen><de> Mit den Werkzeugen Rechteck/Quadrat und Ellipse/Kreis können Sie Hervorhebungen oder einfache Skizzen in Dokumente einfügen.
<G-vec00407-002-s228><add.ergänzen><en> The marks provided are just a small set of examples, but the table is designed to allow the reader to fill in the blanks with the appropriate marks and add entries for other ministries or personalities that are of interest to him/her.
<G-vec00407-002-s228><add.ergänzen><de> Die enthaltenen Kennzeichen sind zwar nur eine begrenzte Zusammenstellung von Beispielen, aber die Tabelle ist so aufgebaut, dass der Leser die freigelassenen Felder mit den entsprechenden Kennzeichen und Einträgen für andere Missionswerke oder Personen seines Interesses ergänzen kann.
<G-vec00407-002-s229><add.ergänzen><en> The provider reserves the right to change parts of the pages or the entire offer without prior notice, to add to, delete or cease publication temporarily or permanently.
<G-vec00407-002-s229><add.ergänzen><de> Der Anbieter behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00407-002-s230><add.ergänzen><en> The website proprietor explicitly reserves the right to modify, add to or delete parts of the pages or the entire offering without special announcement or to temporarily or finally cease its publication.
<G-vec00407-002-s230><add.ergänzen><de> Der Webseitenbesitzer behält sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00407-002-s231><add.ergänzen><en> The Virtuelles Studio GmbH shall reserve the right to alter, add to or delete its range of offers or to suspend publication at any time and without prior announcement.
<G-vec00407-002-s231><add.ergänzen><de> Die Virtuelles Studio GmbH behält sich vor, jederzeit und ohne vorherige Ankündigung das Angebot zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung einzustellen.
<G-vec00407-002-s232><add.ergänzen><en> Sino Pack Recruitment has the right, in its sole discretion, to add to, remove, modify or otherwise change any part of these Terms and Conditions, including the Privacy Policy, in whole or in part, at any time.
<G-vec00407-002-s232><add.ergänzen><de> Orion Telescopes & Binoculars behält sich das Recht vor, alle oder einige Bestimmungen dieser Allgemeinen Geschäftsbedingungen teilweise oder vollständig jederzeit nach alleinigem Ermessen zu ändern, zu modifizieren, zu ergänzen oder zu streichen.
<G-vec00407-002-s233><add.ergänzen><en> The author reserves the express right to alter, add or delete parts of the pages or the entire website without prior notice or to temporarily suspend or finally discontinue publication.
<G-vec00407-002-s233><add.ergänzen><de> Die DGPs behält es sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00407-002-s234><add.ergänzen><en> The Georg Sahm GmbH & Co. KG expressly reserves to itself the right to change the site content partially or entirely without separate announcement, to add or delete content or to cease publication temporarily or permanently.
<G-vec00407-002-s234><add.ergänzen><de> Die Georg Sahm GmbH & Co. KG behält sich ausdrücklich vor, Teile der Seiten oder das gesamte Angebot ohne gesonderte Ankündigung zu verändern, zu ergänzen, zu löschen oder die Veröffentlichung zeitweise oder endgültig einzustellen.
<G-vec00407-002-s235><add.ergänzen><en> To any Bitdefender endpoint solution, you can add additional protection layers, to increase the protection areas.
<G-vec00407-002-s235><add.ergänzen><de> Sie können jede Bitdefender-Endpunktlösung um weitere Schutzebenen ergänzen und damit den Schutz ausweiten.
<G-vec00407-002-s236><add.ergänzen><en> You're sure to want to add this stylish modern piece to your collection.
<G-vec00407-002-s236><add.ergänzen><de> Sie ist schick und modern und wird Ihre Kollektion perfekt ergänzen.
<G-vec00407-002-s237><add.ergänzen><en> Coming in various styles and designs, our Pinup Costumes selection is perfect for you to add style to your look.
<G-vec00407-002-s237><add.ergänzen><de> Mit verschiedenen Stilen und Designs ist unsere große Auswal an Pinup Costumes für Sie ideal, Ihren Stil zum einzigartigen Look zu ergänzen.
<G-vec00407-002-s238><add.ergänzen><en> Coming in various styles and designs, our Wedding Dresses Trumpet selection is perfect for you to add style to your look.
<G-vec00407-002-s238><add.ergänzen><de> Mit verschiedenen Stilen und Designs ist unsere große Auswal an Wedding Dresses Trumpet für Sie ideal, Ihren Stil zum einzigartigen Look zu ergänzen.
<G-vec00407-002-s239><add.ergänzen><en> Coming in various styles and designs, our Wig Rei Ayanami selection is perfect for you to add style to your look.
<G-vec00407-002-s239><add.ergänzen><de> Mit verschiedenen Stilen und Designs ist unsere große Auswal an Wig Rei Ayanami für Sie ideal, Ihren Stil zum einzigartigen Look zu ergänzen.
<G-vec00407-002-s240><add.ergänzen><en> KGAL also reserves the right to amend or add to the information provided.
<G-vec00407-002-s240><add.ergänzen><de> Die KGAL behält sich zudem das Recht vor, die zur Verfügung gestellten Informationen zu ändern oder zu ergänzen.
<G-vec00407-002-s241><add.ergänzen><en> When the construction work is finished, everyone who helped make the building a reality will be able to find their message at The House of One and can add a new one if they wish.
<G-vec00407-002-s241><add.ergänzen><de> Jeder, der im In- und Ausland die Errichtung des House of One mit ermöglicht hat und das House of One dann einmal besuchen wird, kann seinen Namen und seine Botschaft wiederfinden und durch eine neue Botschaft ergänzen.
<G-vec00407-002-s242><add.ergänzen><en> When a wiki is used as a platform to collect and evaluate ideas, its real strength can be brought to bear by granting access to as many employees as possible, who can then comment on, add to and evaluate the ideas.
<G-vec00407-002-s242><add.ergänzen><de> Wird das Wiki als Plattform zur Sammlung und Bewertung von Ideen genutzt, kann es insbesondere dann seine Stärken voll ausspielen, wenn es vielen Mitarbeitern zugänglich ist und diese die Möglichkeit haben, die Ideen zu kommentieren, zu ergänzen und selbst zu bewerten.
<G-vec00407-002-s243><add.ergänzen><en> If you want guidance on installing your new software, please add installation help to your license.
<G-vec00407-002-s243><add.ergänzen><de> Falls Sie Hilfe bei der Installation Ihrer neuen Software wünschen, können Sie Ihre Lizenz auch um die Installationshilfe ergänzen.
<G-vec00407-002-s244><add.ergänzen><en> New functions and connective solutions add to the range of features already offered by the previous Wilo-Assistant.
<G-vec00407-002-s244><add.ergänzen><de> Neue Funktionen und konnektive Lösungen ergänzen die bisherige Vielfalt des Wilo-Assistant.
<G-vec00407-002-s245><add.ergänzen><en> Once certain methods have proven themselves and your system has first achieved success, then you can incrementally optimize and add to them.
<G-vec00407-002-s245><add.ergänzen><de> Wenn sich bestimmte Methoden bewährt haben und Ihr System erste Erfolge erzielt hat, können Sie es dann schrittweise optimieren und ergänzen.
<G-vec00407-002-s246><add.ergänzen><en> Coming in various styles and designs, our Japanese School Uniform selection is perfect for you to add style to your look.
<G-vec00407-002-s246><add.ergänzen><de> Mit verschiedenen Stilen und Designs ist unsere große Auswal an Japan Cosplay für Sie ideal, Ihren Stil zum einzigartigen Look zu ergänzen.
<G-vec00407-002-s361><add.geben><en> New shot animations add a variety of new shots to your arsenal to strike the ball past the goalie.
<G-vec00407-002-s361><add.geben><de> Neue Schuss-Animationen geben dir neue Möglichkeiten, den Ball am Torhüter vorbei ins Netz zu befördern.
<G-vec00407-002-s362><add.geben><en> Add the onion and fry until it is translucent. Season with salt and pepper and add the pearl wheat and tomatoes.
<G-vec00407-002-s362><add.geben><de> Kurz bevor die Pizza fertig ist, das Oliven-Öl zum Salat geben und mit Salz und Pfeffer abschmecken.
<G-vec00407-002-s363><add.geben><en> Explore Creative filters like Toy camera and Miniature that add a different mood and unique finish to your photos.
<G-vec00407-002-s363><add.geben><de> Experimentieren Sie mit Kreativfiltern wie dem Spielzeugkamera- oder Miniatur-Effekt und geben Ihren Aufnahmen damit einen ganz speziellen Look.
<G-vec00407-002-s364><add.geben><en> Description Details Fine washed lambskin and a new and vibrant colour palette add a dash of contemporary chic to this iconic range of wallets.
<G-vec00407-002-s364><add.geben><de> Beschreibung Details Das edle, gewaschene Lammleder und die neue, leuchtende Farbpalette geben dieser kultigen Portemonnaie-Linie von Bottega Veneta eine moderne Note.
<G-vec00407-002-s365><add.geben><en> As soon as the water simmers (that’s just before cooking), turn off the heat and gradually add 50 grams of soda to the water.
<G-vec00407-002-s365><add.geben><de> Sobald das Wasser simmert (also kurz vorm Kochen ist), die Hitze ausschalten & 50 Gramm Natron zum Wasser geben (dabei aufpassen, denn es schäumt sehr stark).
<G-vec00407-002-s366><add.geben><en> For this, they heat one liter of red juice of your choice and add 1 tablespoon of our spice mixture, let it draw for 10 minutes and let it off.
<G-vec00407-002-s366><add.geben><de> Dafür erhitzten sie einen Liter Roten Saft Ihrer Wahl und geben 1 EL unserer Gewürzmischung hinzu, lassen sie es 10 Minuten ziehen und seien sie es ab.
<G-vec00407-002-s367><add.geben><en> Mix the crumbled biscuits, flour and almonds or nuts and add spoon by spoon to the cream. Mix into a thick, viscous batter.
<G-vec00407-002-s367><add.geben><de> Die zerbröselten Kekse, das Mehl und die Mandeln oder Nüsse mischen, löffelweise zur Eicreme geben und alles zu einem dickflüssigen Teig verrühren.
<G-vec00407-002-s368><add.geben><en> After a thorough warm-up, we’ll mix the basics of tribal style with new ingredients, add some spices and create great fusion combinations and learn a Fusion Choreography.
<G-vec00407-002-s368><add.geben><de> Nach einem gründlichen WarmUp mixen wir die Tribal Basics mit neuen Zutaten, geben einige Gewürze dazu, kreieren super Fusion Combinations und lernen eine Fusion Choreo.
<G-vec00407-002-s369><add.geben><en> IRSA Aqua Star R9 is diluted (add 100 ml Aqua Star R9 clean water to 10 L) and use in an uncomplicated wiping process.
<G-vec00407-002-s369><add.geben><de> IRSA Aqua Star R9 wird verdünnt (auf 10 L sauberes Wischwasser 100 ml Aqua Star R9 geben) und im Wischverfahren unkompliziert eingesetzt.
<G-vec00407-002-s370><add.geben><en> Add another receiver Add your arrival and departure dates and discover great deals on hotels in New York.
<G-vec00407-002-s370><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Oklahoma City (and vicinity).
<G-vec00407-002-s371><add.geben><en> With a very dirty tent you can add a little bit of natural soap to the water.
<G-vec00407-002-s371><add.geben><de> Wenn Ihr Zelt sehr schmutzig ist, können Sie etwas grüne Seife ins Wasser geben.
<G-vec00407-002-s372><add.geben><en> If you desire quality plant pots and would like to add style to your garden or patio, then a garden planter from our classic range of planters and containers - including baskets, bowls, boxes, jardinieres, troughs, urns and vase planters - will be ideal fore displaying your plants and flowers on your lawn or patio.
<G-vec00407-002-s372><add.geben><de> Wenn Sie Qualitätspflanztöpfe wünschen und Ihrem Garten oder Patio Stil geben möchten, dann ist ein Gartenpflanzgefäß aus unserer klassischen Reihe an Pflanzgefäßen und Behältnissen - einschließlich, Körben, Schalen, Kisten, Jardiniere, Trögen, Urnen und Vasenpflanzgefäßen - ideal, um Ihre Pflanzen und Blumen auf Ihrem Rasen oder Patio zur Schau zu stellen.
<G-vec00407-002-s373><add.geben><en> You can add a few tablespoons of cold milk to your Milo to cool it off, and add create a creamier texture.
<G-vec00407-002-s373><add.geben><de> Du kannst ein paar Esslöffel kalte Milch in deinen Milo geben, damit er abkühlt und eine cremigere Konsistenz bekommt.
<G-vec00407-002-s374><add.geben><en> 8 Combine vanilla and lemon juice with apple juice and add to the quince.
<G-vec00407-002-s374><add.geben><de> Vanillemark und Zitronensaft mit Apfeldicksaft und Apfelsaft zu den Quitten geben.
<G-vec00407-002-s375><add.geben><en> For the crust, we grind up buckwheat with isomalt and add some plant ash, pulverised Californian seaweed salad, some salt and a pinch of trisol.
<G-vec00407-002-s375><add.geben><de> Für die Kruste mahlen wir Buchweizenkörner mit Isomalt und geben etwas Pflanzenasche, pulverisierten kalifornischen Algen-Salat, Salz und eine Prise Trisol dazu.
<G-vec00407-002-s376><add.geben><en> Then TunesGo will allow you to add photos and transfer them to your iPad.
<G-vec00407-002-s376><add.geben><de> Dann kannst du Filme vom Computer auf dein iPad geben.
<G-vec00407-002-s377><add.geben><en> After that you add the fruits and sprinkle with the almond slivers.
<G-vec00407-002-s377><add.geben><de> Alles in eine Schuessel geben und mit dem Salz bestreuen.
<G-vec00407-002-s378><add.geben><en> Remove the stones from the olives, slice them into rings and add to the chopped cauliflower.
<G-vec00407-002-s378><add.geben><de> Die Oliven entkernen, in kleine Ringe schneiden und zum Blumenkohl geben.
<G-vec00407-002-s379><add.geben><en> 12 Demetrius has received a good testimony from everyone, and from the truth itself; and we add our testimony, and you know that our testimony is true.
<G-vec00407-002-s379><add.geben><de> 12 Dem Demetrius ist Zeugnis gegeben worden von allen und von der Wahrheit selbst; aber auch wir geben Zeugnis, und du weißt, daß unser Zeugnis wahr ist.
<G-vec00407-002-s342><add.hinzufügen><en> If you don't include the unsubscribe merge tag, Mailchimp will add a footer to your campaign that includes an unsubscribe link.
<G-vec00407-002-s342><add.hinzufügen><de> Wenn du kein Zusammenführungs-Tag für die Abbestellung einfügst, fügt Mailchimp eine Fußzeile zu deiner Kampagne hinzu, die einen Abbestell-Link enthält.
<G-vec00407-002-s343><add.hinzufügen><en> 7 Will add 2 lines of Universal Wheels similar to the photo you send us.
<G-vec00407-002-s343><add.hinzufügen><de> 7 fügt 2 Linien von den Universalrädern hinzu, die dem Foto ähnlich sind, das Sie uns senden.
<G-vec00407-002-s344><add.hinzufügen><en> WordPress will automatically add those translations to your website if they hit 100% completion at least once.
<G-vec00407-002-s344><add.hinzufügen><de> WordPress fügt diese Übersetzungen automatisch zu Ihrer Website hinzu, sobald eine Vervollständigung von 100% erreicht ist.
<G-vec00407-002-s345><add.hinzufügen><en> When a Server Administrator selects a person they wish to add to their server's team of IRCops, they will add an O:line for that person into the configuration file.
<G-vec00407-002-s345><add.hinzufügen><de> Wenn ein Server Administrator eine bestimmte Person ausgesucht hat, die er zum Oper auf seinem Server machen will, so fügt er eine Zeile in der Konfigurationsdatei hinzu, die sogenannte O:line für die betreffende Person.
<G-vec00407-002-s346><add.hinzufügen><en> Game Serial Code: Used to upgrade your account from a free-to-play account, add expansion packs, and unlock additional features when creating or upgrading your account.
<G-vec00407-002-s346><add.hinzufügen><de> Seriennummerncode: Mit diesem Code wertet ihr euren kostenlosen Account auf, fügt Erweiterungen hinzu und schaltet zusätzliche Features bei der Erstellung oder Aufwertung eures Accounts frei.
<G-vec00407-002-s347><add.hinzufügen><en> Add instant preview for color matching.
<G-vec00407-002-s347><add.hinzufügen><de> Fügt sofortige Vorschau für Farbe Anpassung hinzu.
<G-vec00407-002-s348><add.hinzufügen><en> Using the snap knob, you can not only determine the character of the attack phase, but also add noise to the signal.
<G-vec00407-002-s348><add.hinzufügen><de> Der Snap-Regler legt nicht nur den Charakter des Anschlags fest, sondern fügt dem Signal auch Rauschen hinzu und imitiert so einen Snare-Teppich.
<G-vec00407-002-s349><add.hinzufügen><en> Equally, adding comments to a gallery will not add files to the gallery, nor change any files in the gallery or on your web server.
<G-vec00407-002-s349><add.hinzufügen><de> Noch einmal: das Hinzufügen von Kommentaren zu Ihrer Galerie fügt weder Ihrer Galerie Dateien hinzu, noch werden Dateien Ihrer Galerie oder auf Ihrem Webserver verändert.
<G-vec00407-002-s350><add.hinzufügen><en> Add hashtags to your Stories to help them reach more people, just like posts in the feed.
<G-vec00407-002-s350><add.hinzufügen><de> Fügt auch Hashtags bei euren Stories hinzu, um mehr Menschen zu erreichen.
<G-vec00407-002-s351><add.hinzufügen><en> Once you’ve successfully launched the sidebar, select Searchmetrics as your “Data Source” and add a new account.
<G-vec00407-002-s351><add.hinzufügen><de> Nachdem die Sidebar gelauncht ist, wählt Searchmetrics als eure “Data Source” und fügt einen neuen Account hinzu.
<G-vec00407-002-s352><add.hinzufügen><en> Forge will add a public key to your account when you create a server.
<G-vec00407-002-s352><add.hinzufügen><de> Forge fügt Ihrem Konto einen öffentlichen Schlüssel hinzu, wenn Sie einen Server erstellen.
<G-vec00407-002-s353><add.hinzufügen><en> Conflict: In May, the second free update will add new features to the Dark Zone and add a new incursion in the iconic Columbus Circle.
<G-vec00407-002-s353><add.hinzufügen><de> Konflikt: Das zweite kostenlose Update, das im Mai erscheint, fügt der Dark Zone neue Features hinzu und bietet einen weiteren Übergriff auf dem bekannten Columbus Circle.
<G-vec00407-002-s354><add.hinzufügen><en> Let’s make the image more like 3D. Add a new layer named “Shadow” and add a black layer mask.
<G-vec00407-002-s354><add.hinzufügen><de> Jetzt sorgen wir für einen plastischen Effekt: Erstellt zuerst eine neue Ebene namens “Schattierung” und fügt eine schwarze Ebenenmaske hinzu.
<G-vec00407-002-s355><add.hinzufügen><en> RSS Feed RSS Comments Feed Add our application to your Facebook page and it will remind you and your friends about a new giveaway on a daily basis.
<G-vec00407-002-s355><add.hinzufügen><de> Cool YouTube To Mp3 Converter hilft euch beim Herunterladen von Fügt unsere Anwendung eurer Facebook Seite hinzu und sie wird euch und eure Freunde täglich an ein neues Giveaway erinnern.
<G-vec00407-002-s356><add.hinzufügen><en> Drivers select defects, add comments, review previous inspections and certify that the repair performed fixed the defect(s) identified.
<G-vec00407-002-s356><add.hinzufügen><de> Der Fahrer legt den Defekt fest, fügt seine Anmerkungen hinzu, prüft vorangegangene Inspektionen und bestätigt, dass die durchgeführten Reparaturen den angezeigten Defekt beseitigt haben.
<G-vec00407-002-s357><add.hinzufügen><en> Please add the item a short letter with order number and reason.
<G-vec00407-002-s357><add.hinzufügen><de> Bitte fügt der Sendung ein kurzes Schreiben mit Ordernummer und Grund/Bitte hinzu.
<G-vec00407-002-s358><add.hinzufügen><en> Add in new policies and zones to create popular hotspots and provide enough taxis and trains to get to and from the clubs! Download QR-Code
<G-vec00407-002-s358><add.hinzufügen><de> Fügt neue Richtlinien und Zonen hinzu, um populäre Hotspots zu erschaffen und sorgt für genug Taxis und Busse, damit eure Stadtbewohner zu den Clubs kommen und von dort auch wieder wegkommen können.
<G-vec00407-002-s359><add.hinzufügen><en> A new component in the MAPILab Toolbox - "Reply All Forget" doesn't add any addition buttons on the ribbon.
<G-vec00407-002-s359><add.hinzufügen><de> Die neue Komponente der MAPILab Toolbox "Reply All" Forget fügt keine zusätzlichen Buttons hinzu.
<G-vec00407-002-s360><add.hinzufügen><en> The Java ES Installer does not add a platform entry for an existing directory server installation (DIRECTORY_MODE=2).
<G-vec00407-002-s360><add.hinzufügen><de> Der Installer fügt für die bereits vorhandene Verzeichnisinstallation keinen Plattformeintrag hinzu (6202902).
<G-vec00407-002-s589><add.verleihen><en> This sweatshirt is designed for Halloween, and the letters print and print add vitality to the clothes and make it vivid.
<G-vec00407-002-s589><add.verleihen><de> Dieses Sweatshirt ist für Halloween entworfen, und die Buchstaben Print und Print verleihen der Kleidung Vitalität und machen sie lebendig.
<G-vec00407-002-s590><add.verleihen><en> Applying colored filters when shooting black and white can produce vivid effects that add drama and presence to your images.
<G-vec00407-002-s590><add.verleihen><de> Das Anwenden von Farbfiltern bei Schwarz-Weiß-Aufnahmen kann lebendige Effekte erzeugen, die Ihren Bildern Drama und Präsenz verleihen.
<G-vec00407-002-s591><add.verleihen><en> Uber-cool flash gradient and advanced polar lenses add a contemporary edge to the finely crafted profile of a distinctive new icon – the Clubround Wood.
<G-vec00407-002-s591><add.verleihen><de> Verlaufsgläser und die modernen polarisierenden Gläser verleihen dem fein gearbeiteten Profil einer neuen unverwechselbaren Ikone einen stark zeitgenössischen Schnitt - die Clubround Wood.
<G-vec00407-002-s592><add.verleihen><en> The diagonal slit pockets and the pleated effect add a subtle sense of style to an everyday look.
<G-vec00407-002-s592><add.verleihen><de> Die schrägen Eingrifftaschen und der geraffte Effekt verleihen dem Alltagslook einen dezenten stilvollen Effekt.
<G-vec00407-002-s593><add.verleihen><en> The high content of fruits and the variety of natural colours add a summer feeling and the full taste of sweet life to Bravo fruit juices. Authentic fruits.
<G-vec00407-002-s593><add.verleihen><de> Der hohe Fruchtgehalt und die vielen natürlich bunten Farben unserer Früchte verleihen den BRAVO-Fruchtdrinks das Gefühl von Sommer und den vollen Geschmack am süßen Leben.
<G-vec00407-002-s594><add.verleihen><en> Customizable colors, social icons with links and Google Fonts support add a unique touch to your email.
<G-vec00407-002-s594><add.verleihen><de> Anpassbare Farben, Social Icons mit Verlinkung sowie der Support von Google Fonts verleihen Ihren E-Mails einen einzigartigen Touch.
<G-vec00407-002-s595><add.verleihen><en> Many people assume that their velvet-to-the-touch walls add enough texture to the room.
<G-vec00407-002-s595><add.verleihen><de> Viele Menschen gehen davon aus, dass ihre weich anzufassenden Wände dem Raum genügend Textur verleihen.
<G-vec00407-002-s596><add.verleihen><en> For a real sense of place, our Insider Collection leverages local expertise within InterContinental’s global network to add something special to your event.
<G-vec00407-002-s596><add.verleihen><de> Um wirklich ein Gefühl für den Ort zu bekommen, nutzt unsere Insider-Kollektion die Fachkompetenz vor Ort im Rahmen des globalen Netzwerks von InterContinental zu Ihrem Vorteil, um Ihrer Veranstaltung das gewisse Etwas zu verleihen.
<G-vec00407-002-s597><add.verleihen><en> Available in a wide range of colors, sizes, and designs, our moral patches are the perfect way to add a touch of style and personality to your uniform, tactical, or workout kit.
<G-vec00407-002-s597><add.verleihen><de> Die 5.11 Tactical Morale Patches sind in vielen verschiedenen Farben, Größen und Designs erhältlich und verleihen Ihrer Uniform und Ausrüstung das gewisse Maß Persönlichkeit und Style.
<G-vec00407-002-s598><add.verleihen><en> The jaunty g" and almost upside-down "s" add subtle charm, while the capital letters provide the broader gestures of Stepp's personality.
<G-vec00407-002-s598><add.verleihen><de> Das lebhafte „g” und das fast umgedrehte „s” verleihen subtilen Charme, während die Großbuchstaben mit großzügigeren Formen die Persönlichkeit von Stepp zum Ausdruck bringen.
<G-vec00407-002-s599><add.verleihen><en> Intrecciato inlays and engraved zippers add a signature touch to the style, accenting the asymmetrical front closure, cuffs and three pockets.
<G-vec00407-002-s599><add.verleihen><de> Intrecciato Einsätze und gravierte Reißverschlussschieber verleihen dem Modell eine unverkennbare Note und akzentuieren den asymmetrischen Reißverschluss, die Ärmelabschlüsse und die drei Taschen.
<G-vec00407-002-s600><add.verleihen><en> Now it’s time to add a more personal touch to the places where you have a presence.
<G-vec00407-002-s600><add.verleihen><de> Jetzt sollten Sie den Seiten, auf welchen Sie präsent sind, eine persönlichere Note verleihen.
<G-vec00407-002-s601><add.verleihen><en> Try out the experience of a hotel in the daytime to add a sense of adventure.
<G-vec00407-002-s601><add.verleihen><de> Wagen Sie die Erfahrung eines Tageshotels, um Ihrer Beziehung einen Hauch Abenteuer zu verleihen.
<G-vec00407-002-s602><add.verleihen><en> The flap pockets and cool collar add a subtle sense of style.
<G-vec00407-002-s602><add.verleihen><de> Die Klappentaschen und der coole Kragen verleihen einen dezent stilvollen Look.
<G-vec00407-002-s604><add.verleihen><en> Eye shadow can add depth and dimension to one's eyes, complement the eye color, make one's eyes appear larger, or simply draw attention to the eyes.
<G-vec00407-002-s604><add.verleihen><de> Lidschatten können den Augen Tiefe und Dimension verleihen, die Augenfarbe ergänzen, die Augen größer erscheinen lassen oder einfach die Aufmerksamkeit auf die Augen lenken.
<G-vec00407-002-s605><add.verleihen><en> The result is ambiences that embody all the attributes of sophisticated home decor and add a personal touch to the home.
<G-vec00407-002-s605><add.verleihen><de> Das Resultat sind Ambiencen, die alle Attribute gehobener Wohnkultur verkörpern und dem Zuhause eine ganz persönliche Note verleihen.
<G-vec00407-002-s606><add.verleihen><en> This will add harmony and integrity to the whole bedroom.
<G-vec00407-002-s606><add.verleihen><de> Dies wird dem ganzen Schlafzimmer Harmonie und Integrität verleihen.
<G-vec00407-002-s607><add.verleihen><en> The VERTEX X has an innovative tip and tail shape with rockers to help the ski pivot and add fluidity to the turn.
<G-vec00407-002-s607><add.verleihen><de> Der VERTEX X ist eine wahre Innovation dank der einzigartigen Form seiner Schaufel und des Hecks, kombiniert mit den Rocker, die für Auftrieb sorgen und dem Ski viel Drehfreudigkeit verleihen.
<G-vec00407-002-s608><add.zugeben><en> Add 2 teaspoons of cocoa powder to the remaining batter and mix until incorporated.
<G-vec00407-002-s608><add.zugeben><de> Zum restlichen Teig zwei Teelöffel Kakao zugeben und unterrühren.
<G-vec00407-002-s609><add.zugeben><en> Add rice and brown the rice for short time.
<G-vec00407-002-s609><add.zugeben><de> Reis zugeben und unter Rühren kurz anrösten.
<G-vec00407-002-s610><add.zugeben><en> Add the cream cheese and vanilla extract and mix until well combined.
<G-vec00407-002-s610><add.zugeben><de> Frischkäse und Vanille Extrakt zugeben und gut verrühren.
<G-vec00407-002-s611><add.zugeben><en> Add the desired amount of pigment and mix.
<G-vec00407-002-s611><add.zugeben><de> Die gewünschte Menge an Pigment zugeben und mischen.
<G-vec00407-002-s612><add.zugeben><en> Simmer for approx 20 minutes; you might need to add some water, if the sauce thickens too much.
<G-vec00407-002-s612><add.zugeben><de> Ca 20 Minuten koecheln lassen, evt etwas Wasser zugeben, falls sie zu sehr eindickt.
<G-vec00407-002-s613><add.zugeben><en> Add canadian whisky.
<G-vec00407-002-s613><add.zugeben><de> Kanadischer Whisky zugeben.
<G-vec00407-002-s614><add.zugeben><en> If needed, add a tiny bit of water.
<G-vec00407-002-s614><add.zugeben><de> Falls nötig einen Schuss Wasser zugeben.
<G-vec00407-002-s615><add.zugeben><en> Do not add water.
<G-vec00407-002-s615><add.zugeben><de> Kein Wasser zugeben.
<G-vec00407-002-s616><add.zugeben><en> Add chestnuts, garlic and bacon.
<G-vec00407-002-s616><add.zugeben><de> Maronen, Knoblauch und Speck zugeben.
<G-vec00407-002-s617><add.zugeben><en> Top off with some freshly ground black pepper, stir and add a large slice of cucumber.
<G-vec00407-002-s617><add.zugeben><de> Mit etwas frisch zerstoßenen Pfefferkörnern abrunden, umrühren und eine große Gurkenscheibe zugeben.
<G-vec00407-002-s618><add.zugeben><en> Add the white wine and let cook until some of the wine has reduced.
<G-vec00407-002-s618><add.zugeben><de> Den Weißwein zugeben und koecheln lassen, bis der Wein leicht eingekocht ist.
<G-vec00407-002-s619><add.zugeben><en> Then add the whisked eggs and rice and bring to the boil again.
<G-vec00407-002-s619><add.zugeben><de> Anschliessend verrührte Eier sowie Reis zugeben und nochmal zum Kochen bringen.
<G-vec00407-002-s620><add.zugeben><en> Add the chopped onion after 2 minutes and cook as well.
<G-vec00407-002-s620><add.zugeben><de> Nach etwa 2 Minuten die Zwiebeln zugeben und mitkochen – dauert etwa 10-15 Minuten.
<G-vec00407-002-s622><add.zugeben><en> Add the oil and butter mixture
<G-vec00407-002-s622><add.zugeben><de> Eier und Öl zugeben und unterrühren.
<G-vec00407-002-s623><add.zugeben><en> Add in the milk and beat until just combined.
<G-vec00407-002-s623><add.zugeben><de> Milch zugeben und gerade so lange rühren, bis alles vermischt ist.
<G-vec00407-002-s624><add.zugeben><en> Skim any fat or impurities off the top periodically and add more liquid as needed to keep the bones covered.
<G-vec00407-002-s624><add.zugeben><de> Dabei das Fett und Verunreinigungen an der Oberfläche regelmäßig abschöpfen und nach Bedarf mehr Flüssigkeit zugeben damit die Knochen immer bedeckt sind.
<G-vec00407-002-s625><add.zugeben><en> As you can see, this salad is very colorful, you can add some more ingredients or leave some out, change whatever you like.
<G-vec00407-002-s625><add.zugeben><de> Wie Ihr sehen koennt, sieht der Salat wunderbar bunt aus, da kann man auch je nach Geschmack Zutaten zugeben oder weglassen.
<G-vec00407-002-s626><add.zugeben><en> 1) Heat up a pan then add the honey.
<G-vec00407-002-s626><add.zugeben><de> 1) Eine Pfanne erhitzen, den Honig zugeben und aufschäumen lassen.
<G-vec00060-002-s380><add.geben><en> Please add your dates to check the availability at Maison Vintage Chambre d'Hôtes, Carcassonne
<G-vec00060-002-s380><add.geben><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im Ocean Blue Hostel, Miami Beach zu überprüfen.
<G-vec00060-002-s381><add.geben><en> Melt a knob of butter in a saucepan and add the risotto mix.
<G-vec00060-002-s381><add.geben><de> Schmelzen sie Butter im Topf und geben Sie den Risotto-Mix zu.
<G-vec00060-002-s382><add.geben><en> Please add your dates to check the availability at ibis Dubai Mall of the Emirates Hotel, Dubai
<G-vec00060-002-s382><add.geben><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im ibis Melbourne Little Bourke Street, Melbourne zu überprüfen.
<G-vec00060-002-s383><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Southeast Ireland.
<G-vec00060-002-s383><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Sintra.
<G-vec00060-002-s384><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Dabrowa Tarnowska.
<G-vec00060-002-s384><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Schoenaich.
<G-vec00060-002-s385><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Bruges.
<G-vec00060-002-s385><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Montussan.
<G-vec00060-002-s386><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Seriate.
<G-vec00060-002-s386><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Lissone.
<G-vec00060-002-s387><add.geben><en> Add the description of the company and define which folder you're looking for.
<G-vec00060-002-s387><add.geben><de> Geben Sie zu die Firmenbeschreibung und erwähnen Sie, welche Arbeiten Sie suchen.
<G-vec00060-002-s388><add.geben><en> Add a title and content to the article, according to the headings in the template.
<G-vec00060-002-s388><add.geben><de> Geben Sie die Überschriften und den Inhalt für die Vorlage ein.
<G-vec00060-002-s389><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Ya'an.
<G-vec00060-002-s389><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Ganzhou.
<G-vec00060-002-s390><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Tembok.
<G-vec00060-002-s390><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Tembok.
<G-vec00060-002-s391><add.geben><en> Bring the water to a rolling boil, then add the sliced mushrooms.
<G-vec00060-002-s391><add.geben><de> Bringen Sie das Wasser zum kochen, dann geben Sie die in Scheiben geschnittenen Pilze dazu.
<G-vec00060-002-s392><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Linxia.
<G-vec00060-002-s392><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Linxia.
<G-vec00060-002-s393><add.geben><en> Add 2 tablespoonfuls of argan oil, 3 drops of lavender essential oil and finely chopped lemon zest into a food processor and mix well.
<G-vec00060-002-s393><add.geben><de> Geben Sie 2 Esslöffel Arganöl, 3 Tropfen ätherisches Lavendelöl und fein gehackte Zitronenschalen in eine Küchenmaschine und mixen Sie alles gut.
<G-vec00060-002-s394><add.geben><en> Osaka Please add your dates to check the availability at Toko City Hotel Umeda, Osaka
<G-vec00060-002-s394><add.geben><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im Tulip Inn Leiden Centre, Leiden zu überprüfen.
<G-vec00060-002-s395><add.geben><en> Please add your dates to check the availability at BlueBay Lanzarote, Teguise
<G-vec00060-002-s395><add.geben><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im H·TOP Olympic, Calella zu überprüfen.
<G-vec00060-002-s396><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Cannes.
<G-vec00060-002-s396><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Villeurbanne.
<G-vec00060-002-s397><add.geben><en> Add your arrival and departure dates and discover great deals on hotels in Uehlingen-Birkendorf.
<G-vec00060-002-s397><add.geben><de> Geben Sie Ihre Anreise- und Abreisedaten an und entdecken Sie großartige Angebote an Hotels in Lenzkirch.
<G-vec00060-002-s398><add.geben><en> Please add your dates to check the availability at Apartament Vistamar, Vilassar de Mar
<G-vec00060-002-s398><add.geben><de> Bitte, geben Sie Ihre Reisedaten an, um die Verfügbarkeit im Apartamento Sant Jaume, Calella zu überprüfen.
<G-vec00060-002-s399><add.geben><en> Add toppings of your choice (I used onion rings, blanched broccoli and the nut-free ‘cheese’).
<G-vec00060-002-s399><add.geben><de> Gib Belag deiner Wahl drauf (bei mir waren es Zwiebelringe, blanchierter Brokkoli und ‚Käse‘).
<G-vec00060-002-s400><add.geben><en> BALI KRATOM 15x EXTRACT DOSAGE: For a light experience, add 0.5 grams to a glass of hot water or juice.
<G-vec00060-002-s400><add.geben><de> Bali Kratom 15x Extrakt Dosierung: Für eine leichte Erfahrung, gib 0,5 Gramm in ein Glas mit heißem Wasser oder Saft.
<G-vec00060-002-s401><add.geben><en> Add a mind-bending splash of colour to your outfit with our MRI Mesh hipster, inspired by scans of the human mind.
<G-vec00060-002-s401><add.geben><de> Gib deinem Outfit eine bewusstseinsverändernde Farbinjektion mit unserem MRI-Mesh-Hipster, inspiriert von Aufnahmen des menschlichen Gehirns.
<G-vec00060-002-s402><add.geben><en> Drain the pineapple (but keep the water, we don’t want to waste all the nutrients! You can just drink it or use it for your oatmeal or sth like that) Add all ingredients except for the oats into your blender and blend them on highspeed.
<G-vec00060-002-s402><add.geben><de> Gieße die Ananas ab (aber schütte das Wasser nicht weg, es wäre schade um all die Nährstoffe, du kannst es entweder trinken oder weiterverwenden) Gib alle Zutaten außer die Haferflocken in den Mixer und blende auf Höchstgeschwindigkeit.
<G-vec00060-002-s403><add.geben><en> Add a bit of mild dish soap. Swish the soapy water around the interior of the carafe.
<G-vec00060-002-s403><add.geben><de> Gib ein klein wenig mildes Spülmittel dazu und schwenke das Seifenwasser in der Kanne herum.
<G-vec00060-002-s404><add.geben><en> To make carpet cleaner, add a few drops of oil to baking soda and shake it on your carpets.
<G-vec00060-002-s404><add.geben><de> Gib ein paar Tropfen ätherischen Öls auf den Staubsaugerbeutel, bevor du den Staubsauger anschaltest.
<G-vec00060-002-s405><add.geben><en> Assemble the Tiramisu Add a layer of the cheese mixture.
<G-vec00060-002-s405><add.geben><de> Gib eine Schicht der Mascarpone-Mischung auf die Löffelbiskuits.
<G-vec00060-002-s406><add.geben><en> Add the apples to the syrup.
<G-vec00060-002-s406><add.geben><de> Gib die Äpfel in den Sirup.
<G-vec00060-002-s407><add.geben><en> 6 Add the right kind of washing fluid and close the door.
<G-vec00060-002-s407><add.geben><de> Gib die richtige Art von Waschmittel in die Trommel und schließe die Tür.
<G-vec00060-002-s408><add.geben><en> Dark Violet-Blue Shade: Add a small amount of black (or transparent yellow-green) to violet. Transparent yellow-green is violet's complement.
<G-vec00060-002-s408><add.geben><de> Grau-Blau: Gib sowohl Weiß als auch Dunkel Violett-Blau: Gib eine kleine Menge Schwarz (oder Gelb) zu Blau.
<G-vec00060-002-s409><add.geben><en> Add fresh parsley with the basil as a way to make your pesto a brighter healthier green color.
<G-vec00060-002-s409><add.geben><de> Gib frische Petersilie zum Basilikum, als Möglichkeit, dem Pesto eine gesündere grüne Farbe zu verleihen.
<G-vec00060-002-s410><add.geben><en> Stir together the skyr, stone-ground mustard and finely chopped parsley and add the mixture to the fennel and cauliflower.
<G-vec00060-002-s410><add.geben><de> Vermenge den Skyr, Senf und die feingehackte Petersilie und gib die Mischung auf den Fenchel und den Blumenkohl.
<G-vec00060-002-s411><add.geben><en> Suggested Use: Add the pasta to plenty of boiling water and let the pasta simmer for 6-8 minutes.
<G-vec00060-002-s411><add.geben><de> Empfohlene Anwendung: Gib die Nudeln in reichlich kochendes Wasser und lasse sie 6-8 Minuten lang köcheln.
<G-vec00060-002-s412><add.geben><en> Add four cups (946.4 mL) of non-instant white rice or other heatable food, including dried corn kernels and flaxseed, to the sock.
<G-vec00060-002-s412><add.geben><de> Gib vier Tassen (etwa einen Liter) weißen Reis oder andere Nahrungsmittel, die erhitzt werden können, wie getrocknete Maiskörner oder Leinsamen in die Socke.
<G-vec00060-002-s413><add.geben><en> Add the corn to a pan.
<G-vec00060-002-s413><add.geben><de> Gib den Mais in eine Pfanne.
<G-vec00060-002-s414><add.geben><en> Add 500 uL suspension in the prefilled tube with reagent R and mix for 5 seconds.
<G-vec00060-002-s414><add.geben><de> Gib 500 ul Suspension in das vorgefüllte Röhrchen mit Reagenz R und mische 5 Sekunden lang.
<G-vec00060-002-s415><add.geben><en> 9 Stir the lemon juice and grated ginger to form a slurry, then add it to the bottle.
<G-vec00060-002-s415><add.geben><de> 9 Verrühre beides zu einem dünnen Brei und gib ihn dann in die Flasche.
<G-vec00060-002-s416><add.geben><en> Mix the dry ingredients in a large bowl, add the veggi milk, the vinegar and the sweetener (maple syrup, agave etc).
<G-vec00060-002-s416><add.geben><de> Anleitungen Mische die trockenen Zutaten in einer großen Schüssel, gib die Milch, Essig und Honig (Agave für Veganer) dazu.
<G-vec00060-002-s417><add.geben><en> Add the grated cheese to the hot soup.
<G-vec00060-002-s417><add.geben><de> Gib den geriebenen Käse zu der heißen Suppe.
<G-vec00060-002-s095><add.hinzufügen><en> You can add another document for the device Dell SE400 Network Hardware.
<G-vec00060-002-s095><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Accton Technology Network Hardware EH2041S Netzwerkgerät hinzufügen.
<G-vec00060-002-s096><add.hinzufügen><en> Now add rosewater and mix until a soft, but not stick paste has formed.
<G-vec00060-002-s096><add.hinzufügen><de> Nun das Rosenwasser hinzufügen und weitermixen, bis ein weiches, aber nicht klebriges Marzipan entstanden ist.
<G-vec00060-002-s097><add.hinzufügen><en> You can add another document for the device Creda 5kg Clothes Dryer.
<G-vec00060-002-s097><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Creda 5kg Kleiderföhn hinzufügen.
<G-vec00060-002-s098><add.hinzufügen><en> You can add another document for the device Whirlpool Side By Side Refrigerator 7GS6SHAXKB01 Refrigerator.
<G-vec00060-002-s098><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Whirlpool Side By Side Refrigerator ED2YHGXLT01 Kühlschrank hinzufügen.
<G-vec00060-002-s099><add.hinzufügen><en> Please see example in GuiXT tutorial 6 Add images.
<G-vec00060-002-s099><add.hinzufügen><de> Vergleichen Sie hierzu das GuiXT Tutorial 6 Abbildungen hinzufügen.
<G-vec00060-002-s100><add.hinzufügen><en> You can add another document for the device Dell XPS TM373 Laptop.
<G-vec00060-002-s100><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Dell XPS TM373 Laptop hinzufügen.
<G-vec00060-002-s101><add.hinzufügen><en> You can add another document for the device Xerox CX PRINT SERVER 560 All in One Printer.
<G-vec00060-002-s101><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Xerox CX PRINT SERVER 560 Multifunktionsgerät hinzufügen.
<G-vec00060-002-s102><add.hinzufügen><en> You can add another document for the device Whirlpool Refrigerator GD5SHAXMQ00 Refrigerator.
<G-vec00060-002-s102><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Whirlpool Refrigerator GD5SHAXMQ00 Kühlschrank hinzufügen.
<G-vec00060-002-s103><add.hinzufügen><en> You can add another document for the device Motorola TIMEPORT 270c Cell Phone.
<G-vec00060-002-s103><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Motorola TIMEPORT 270c Handy hinzufügen.
<G-vec00060-002-s104><add.hinzufügen><en> You can add another document for the device Sony Ericsson walkman W980 Cell Phone.
<G-vec00060-002-s104><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Sony Ericsson walkman W980 Handy hinzufügen.
<G-vec00060-002-s105><add.hinzufügen><en> You can add another document for the device Sony Flat Panel Television FWD-42PV Flat Panel Television.
<G-vec00060-002-s105><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Sony Flat Panel Television FWD-42PV Flachfernseher hinzufügen.
<G-vec00060-002-s106><add.hinzufügen><en> You can add another document for the device Diamond D662 Car Speaker.
<G-vec00060-002-s106><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Diamond D363I Lautsprecher hinzufügen.
<G-vec00060-002-s107><add.hinzufügen><en> You can add another document for the device Frigidaire 100BTU-25 Air Conditioner.
<G-vec00060-002-s107><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Frigidaire 100BTU-25 Klimaanlage hinzufügen.
<G-vec00060-002-s108><add.hinzufügen><en> You can add another document for the device Beverage-Air VM7 Refrigerator.
<G-vec00060-002-s108><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Beverage-Air VM7 Kühlschrank hinzufügen.
<G-vec00060-002-s109><add.hinzufügen><en> You can add another document for the device Asus Barebone System RS720QE7RS12 Server.
<G-vec00060-002-s109><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Asus Barebone System ESC4000FDRG2 Server hinzufügen.
<G-vec00060-002-s110><add.hinzufügen><en> You can add another document for the device Whirlpool Refrigerator ED5PBAXVQ00 Refrigerator.
<G-vec00060-002-s110><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Whirlpool Refrigerator ED5PBAXVQ00 Kühlschrank hinzufügen.
<G-vec00060-002-s111><add.hinzufügen><en> Once you have changed the Marriage Tag Type to add these roles, you can not only use it for new marriages you enter, but you can also go back to existing Marriage tags and apply the new roles to them as well
<G-vec00060-002-s111><add.hinzufügen><de> Sobald Sie den Elementtyp "Heirat" über das Hinzufügen dieser Funktionen verändert haben, können Sie hiervon nicht nur für neue Eheschließungen, die Sie erfassen, Gebrauch machen, sondern Sie können vielmehr auch zu bereits vorhandenen Heirats-Elementen "zurückgehen" und auch bei diesen die neu erstellten Funktionen anwenden.
<G-vec00060-002-s112><add.hinzufügen><en> They can then add cash expenses, driving expenses and per diem allowances in local and foreign currency.
<G-vec00060-002-s112><add.hinzufügen><de> Möglich ist auch das Hinzufügen von Barauslagen, Fahrspesen und Pauschalen in lokaler und ausländischer Währung.
<G-vec00060-002-s113><add.hinzufügen><en> You can add another document for the device Samsung Eternity II SGH-A597 Cell Phone.
<G-vec00060-002-s113><add.hinzufügen><de> Sie können das nächste Dokument für das Gerät Samsung Eternity II SGH-A597 Handy hinzufügen.
<G-vec00060-002-s247><add.hinzufügen><en> Add anti_virus2000 as a friend
<G-vec00060-002-s247><add.hinzufügen><de> Füge QuiLLa_Quaak als Freund hinzu.
<G-vec00060-002-s248><add.hinzufügen><en> Add galleries to playlist by clicking a icon on your favourite videos. Related GAY4PAY 15
<G-vec00060-002-s248><add.hinzufügen><de> Füge Galerien zu der Playlist hinzu, indem du auf das Icon bei einem deiner Lieblingsvideos klickst.
<G-vec00060-002-s260><add.hinzufügen><en> If you need an easy way to add instant charm to your designs, add a little stitching to your work.
<G-vec00060-002-s260><add.hinzufügen><de> Wenn du einen einfachen Weg brauchst, um deinen Designs einen sofortigen Charme zu verleihen, füge deiner Arbeit eine kleine Naht hinzu.
<G-vec00060-002-s261><add.hinzufügen><en> Open the file "Plugins.xml" in your SDRSharp directory with a text processor and add the following line in the <sharpPlugins> section:
<G-vec00060-002-s261><add.hinzufügen><de> Öffne die Datei "Plugins.xml" im SDRSharp-Programmverzeichnis in einem Texteditor und füge folge der Anleitung auf der Seite Erste Schritte.
<G-vec00060-002-s266><add.hinzufügen><en> Webmaster: Add your Site to our list FOR FREE for a lot of new visitors.
<G-vec00060-002-s266><add.hinzufügen><de> Füge deinen Link KOSTENLOS zu unserer Sammlung hinzu für viele neue Besucher.
<G-vec00060-002-s267><add.hinzufügen><en> Add 1 teaspoon of borax.
<G-vec00060-002-s267><add.hinzufügen><de> Füge einen Teelöffel Borax hinzu.
<G-vec00060-002-s268><add.hinzufügen><en> I enjoy adding killer drills to make the workshops sweat then add challenging dance movement exercises, to add speed and precision to a dancer’s vocabulary.
<G-vec00060-002-s268><add.hinzufügen><de> Ich liebe mörderischen Drill, damit meine Kurse so richtig ins Schwitzen kommen, und füge auch gern ein paar herausfordernde Tanzübungen hinzu, damit meine Schülerinnen sich einprägen, was Tempo und Präzision im Tänzerinnen-Vokabular bedeuten.
<G-vec00060-002-s269><add.hinzufügen><en> Add your team name, player name and player number.
<G-vec00060-002-s269><add.hinzufügen><de> Füge deinen Teamnamen, Spielerinitialien, Sponsorlogo und Teamkrone hinzu.
<G-vec00060-002-s270><add.hinzufügen><en> Add comments about questions or other answers to their respective comment sections, not as a new answer.
<G-vec00060-002-s270><add.hinzufügen><de> Füge Kommentare zu Fragen oder anderen Antworten im Kommentarbereich hinzu, nicht als neue Antwort.
<G-vec00060-002-s271><add.hinzufügen><en> Top 100 servers hosted in Canada, add your Unturned server and advertise with us.
<G-vec00060-002-s271><add.hinzufügen><de> Top 100 Server die in Canada gehostet werden, füge Deinen Unturned Server hinzu und mach Werbung bei uns.
<G-vec00060-002-s272><add.hinzufügen><en> do like to add touches of reality to my fiction, but in the end my stories are born purely from my imagination.
<G-vec00060-002-s272><add.hinzufügen><de> Ich füge meiner Fiktion gern etwas Realität hinzu, aber am Ende sind meine Geschichten rein aus meiner Vorstellung geboren.
<G-vec00060-002-s273><add.hinzufügen><en> 4 Add the grounds.
<G-vec00060-002-s273><add.hinzufügen><de> 4 Füge den gemahlenen Kaffee hinzu.
<G-vec00060-002-s274><add.hinzufügen><en> Add specific AK 47 flavor and aroma to all kinds of oils, herbal extractions, and resins.
<G-vec00060-002-s274><add.hinzufügen><de> Füge allen Arten von Ölen, Kräuterextrakten und Harzen spezifisches Chemdawg 4 Aroma und Aroma hinzu.
<G-vec00060-002-s275><add.hinzufügen><en> Top 100 private servers hosted in Israel, add your Conquer Online server and advertise with us.
<G-vec00060-002-s275><add.hinzufügen><de> Top 100 Privat Server die in Egypt gehostet werden, füge Deinen Conquer Online Server hinzu und mach Werbung bei uns.
<G-vec00060-002-s276><add.hinzufügen><en> Now, whenever you're discovering new books in blinks that you want to send to your Kindle, simply add them to your Blinkist library.
<G-vec00060-002-s276><add.hinzufügen><de> Wenn du nun neue Bücher entdeckst, welche du zum Kindle senden möchtest, füge sie einfach deiner Blinkist Bibliothek hinzu.
<G-vec00060-002-s277><add.hinzufügen><en> Add some hashtags.
<G-vec00060-002-s277><add.hinzufügen><de> Füge einige Hashtags hinzu.
<G-vec00060-002-s278><add.hinzufügen><en> Add any texts as a final touch.
<G-vec00060-002-s278><add.hinzufügen><de> Füge beliebige Texte als letzten Schliff hinzu.
<G-vec00060-002-s279><add.hinzufügen><en> I stir one tablespoon in my porridge every morning, or add it to soups, pasta sauces, or to energy balls.
<G-vec00060-002-s279><add.hinzufügen><de> Ich rühre morgens einen Esslöffel in mein Porridge, füge es zu Suppen hinzu, rühre es in Pasta-Saucen, oder mische es in Energiebälle.
<G-vec00060-002-s280><add.hinzufügen><en> Top 100 private servers hosted in Russia, add your OGame server and advertise with us.
<G-vec00060-002-s280><add.hinzufügen><de> Top 100 Privat Server die in Russia gehostet werden, füge Deinen OGame Server hinzu und mach Werbung bei uns.
<G-vec00060-002-s281><add.hinzufügen><en> Description Add features to your checkout item.
<G-vec00060-002-s281><add.hinzufügen><de> Beschreibung Füge in deinem Checkout Artikelmerkmale hinzu.
<G-vec00060-002-s282><add.hinzufügen><en> As this blend is fast absorbing, we recommend having it 30-60 minutes’ post-workout — add 1 sachet to water or milk, whichever you prefer.
<G-vec00060-002-s282><add.hinzufügen><de> Da diese Mischung schnell absorbiert wird, empfehlen wir 30-60 Minuten nach dem Training den Eiweißshake einzunehmen – füge je nach Belieben 1 Messlöffel (25 g) zu Wasser oder Milch hinzu.
<G-vec00060-002-s283><add.hinzufügen><en> You can discard 1 Spell; add 1 LIGHT Ritual Monster or 1 Ritual Spell from your Deck to your hand.
<G-vec00060-002-s283><add.hinzufügen><de> Du kannst 1 Zauber abwerfen; füge deiner Hand 1 LICHT Ritualmonster oder 1 Ritualzauber von deinem Deck hinzu.
<G-vec00060-002-s284><add.hinzufügen><en> Add Sav_09 as a friend
<G-vec00060-002-s284><add.hinzufügen><de> Füge Victor236 als Freund hinzu.
<G-vec00060-002-s285><add.hinzufügen><en> * To process your RFQ, please add MAX1723EZK-T with quantity into BOM.
<G-vec00060-002-s285><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte MAX158AEWI-T mit Menge in den BOM.
<G-vec00060-002-s286><add.hinzufügen><en> * To process your RFQ, please add ICL7611BMTV with quantity into BOM.
<G-vec00060-002-s286><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte P79E38 mit Menge in den BOM.
<G-vec00060-002-s287><add.hinzufügen><en> * To process your RFQ, please add BQ2050SN with quantity into BOM.
<G-vec00060-002-s287><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte PCI1250GFN mit Menge in den BOM.
<G-vec00060-002-s288><add.hinzufügen><en> * To process your RFQ, please add L6229PDTR with quantity into BOM.
<G-vec00060-002-s288><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte L6506D013TR mit Menge in den BOM.
<G-vec00060-002-s289><add.hinzufügen><en> Then you add these two values before you multiply by 8.
<G-vec00060-002-s289><add.hinzufügen><de> Dann fügen Sie diese beiden Werte, bevor Sie mit 8 multiplizieren.
<G-vec00060-002-s290><add.hinzufügen><en> Edit the videos – You can now add special effects and more when you use the inbuilt video editor for UniConverter.
<G-vec00060-002-s290><add.hinzufügen><de> Videos bearbeiten – Fügen Sie nun Spezialeffekte und mehr ein, wenn Sie den integrierten Video Editor des UniConverter nutzen wollen.
<G-vec00060-002-s291><add.hinzufügen><en> Add a web page to your HTML movies.
<G-vec00060-002-s291><add.hinzufügen><de> Fügen eine Webseite in Ihren HTML-Film ein.
<G-vec00060-002-s292><add.hinzufügen><en> Please add the opavote.org domain to your safe sender list to avoid the email being sent your spam folder.
<G-vec00060-002-s292><add.hinzufügen><de> Und fügen Sie bitte die opavote.com-Domain zu Ihrer Liste sicherer Absender hinzu, damit die E-Mail nicht in Ihren Spamordner gelangt.
<G-vec00060-002-s293><add.hinzufügen><en> * To process your RFQ, please add BCM7004AKPB50G with quantity into BOM.
<G-vec00060-002-s293><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte BCM6529IFBG mit Menge in den BOM.
<G-vec00060-002-s294><add.hinzufügen><en> * To process your RFQ, please add NFM2012R13C223RT1M with quantity into BOM.
<G-vec00060-002-s294><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte NM232DDC mit Menge in den BOM.
<G-vec00060-002-s295><add.hinzufügen><en> From 25° we add a 'cold-pack' to the parcel to keep the products fresh and cool during transport.
<G-vec00060-002-s295><add.hinzufügen><de> Ab 25° fügen wir der Sendung ein 'Cold-Pack' bei, um die Produkte während des Transports frisch und kühl zu halten.
<G-vec00060-002-s296><add.hinzufügen><en> * To process your RFQ, please add FDD3076TM-NL with quantity into BOM.
<G-vec00060-002-s296><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte VLS252010MNT-2R2M-1 mit Menge in den BOM.
<G-vec00060-002-s297><add.hinzufügen><en> * To process your RFQ, please add 2SD1819A with quantity into BOM.
<G-vec00060-002-s297><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte 2SA1806GQL+ mit Menge in den BOM.
<G-vec00060-002-s298><add.hinzufügen><en> * To process your RFQ, please add MIC5247-1.8YD5 TR with quantity into BOM.
<G-vec00060-002-s298><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte MIC5247-1.8YML TR mit Menge in den BOM.
<G-vec00060-002-s299><add.hinzufügen><en> If any of this code needs to access the DOM, add the code in a DOMContentLoaded event handler.
<G-vec00060-002-s299><add.hinzufügen><de> Fügen Sie Code, der Zugriff auf das DOM benötigt, in einen DOMContentLoaded-Ereignishandler ein.
<G-vec00060-002-s300><add.hinzufügen><en> * To process your RFQ, please add MAX6716AUTZWD3+T with quantity into BOM.
<G-vec00060-002-s300><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte MAX6465XR54+T mit Menge in den BOM.
<G-vec00060-002-s301><add.hinzufügen><en> * To process your RFQ, please add QCPM-8861 with quantity into BOM.
<G-vec00060-002-s301><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte HCPL-322J mit Menge in den BOM.
<G-vec00060-002-s302><add.hinzufügen><en> * To process your RFQ, please add 7142SA20J with quantity into BOM.
<G-vec00060-002-s302><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte 7143LA55J mit Menge in den BOM.
<G-vec00060-002-s303><add.hinzufügen><en> * To process your RFQ, please add OPA2336UA/2K5G4 with quantity into BOM.
<G-vec00060-002-s303><add.hinzufügen><de> * Um Ihren RFQ verarbeiten, fügen Sie bitte OPA137UA/2K5G4 mit Menge in den BOM.
<G-vec00060-002-s304><add.hinzufügen><en> In Office 365, Group members typically create their own Groups, add themselves to Groups they want to join, or are invited by Group owners.
<G-vec00060-002-s304><add.hinzufügen><de> In Office 365 erstellen Gruppenmitglieder in der Regel ihre Gruppen selbst, fügen sich selbst zu Gruppen hinzu, an denen sie teilnehmen möchten, oder werden von anderen Gruppenbesitzern eingeladen.
<G-vec00060-002-s305><add.hinzufügen><en> You can also add information on Michelin restaurants, tourist attractions or hotels in Hörbranz or Dornbirn.
<G-vec00060-002-s305><add.hinzufügen><de> Fügen Sie Ihrem Routenplan Feldkirch - Dornbirn Informationen zu Restaurants, Sehenswürdigkeiten und Hotels in Dornbirn hinzu.
<G-vec00060-002-s306><add.hinzufügen><en> If we add another dimension, everyone can watch them in 3D on their smartphone with any virtual reality viewer like Google Cardboard, Samsung Gear VR and the like.
<G-vec00060-002-s306><add.hinzufügen><de> Fügen wir eine weitere Dimension hinzu, lassen sich Panoramen in 3D am Smartphone mit einem VR Headset wie Google Cardboard, Samsung Gear VR oder ähnlichen betrachten.
<G-vec00060-002-s307><add.hinzufügen><en> If you like, please add yourself as a fan – Thanks from your friends at WorldLingo.
<G-vec00060-002-s307><add.hinzufügen><de> Wenn Sie mögen, bitte fügen Sie sich als Ventilator hinzu - Dank von Ihren Freunden bei WorldLingo.
<G-vec00060-002-s308><add.hinzufügen><en> Then, we add a layer Mask and reduce the smoke significantly.
<G-vec00060-002-s308><add.hinzufügen><de> Wir fügen eine Ebenenmaske hinzu und schwächen den Rauch stark ab.
<G-vec00060-002-s309><add.hinzufügen><en> The event and its effects add something to the world, and this can change what is already constituted.
<G-vec00060-002-s309><add.hinzufügen><de> Das Ereignis und seine Effekte fügen der Welt etwas hinzu, und dieses Hinzugefügte kann eine Veränderung dessen bewirken, was bereits konstituiert ist.
<G-vec00060-002-s310><add.hinzufügen><en> By the way, we continuously update CopyTrans Contacts and add new features too.
<G-vec00060-002-s310><add.hinzufügen><de> Wir aktualisieren CopyTrans Contacts regelmäßig und fügen auch neue Funktionen hinzu.
<G-vec00060-002-s311><add.hinzufügen><en> Both respect traditional methods and utilize local products but add a contemporary, creative spin.
<G-vec00060-002-s311><add.hinzufügen><de> Beide respektieren traditionelle Methoden und nutzen lokale Produkte, fügen dem aber einen zeitgemäßen kreativen Dreh hinzu.
<G-vec00060-002-s312><add.hinzufügen><en> With a beautiful pair of diamond earrings, you add an elegant touch to any look.
<G-vec00060-002-s312><add.hinzufügen><de> Mit schönen Diamant-Ohrringen fügen Sie eine elegante Note zu jedem Look hinzu.
<G-vec00060-002-s313><add.hinzufügen><en> We offer over 300 game titles from four different operators and we add new games each month.
<G-vec00060-002-s313><add.hinzufügen><de> Wir bieten über 300 Spieltitel von vier verschiedenen Entwicklern und wir fügen ständig neue Spiele hinzu.
<G-vec00060-002-s314><add.hinzufügen><en> Change the colors, add your own photos and text to customize the layout for just about any business.
<G-vec00060-002-s314><add.hinzufügen><de> Ändern Sie die Farben, und fügen Sie eigene Fotos und Text hinzu, um das Layout für ein beliebiges Unternehmen anzupassen.
<G-vec00060-002-s315><add.hinzufügen><en> We still add the ending -ing to the semantic verb, and instead of one future-time word, two - shall / will plus be.
<G-vec00060-002-s315><add.hinzufügen><de> Wir fügen dem semantischen Verb noch die Endung -ing hinzu, und statt eines Zukunftswortes zwei - soll / wird plus sein.
<G-vec00060-002-s316><add.hinzufügen><en> Most manufacturers add their own security features on top of what Google adds by default.
<G-vec00060-002-s316><add.hinzufügen><de> Die meisten Hersteller fügen dem, was Google standardmäßig draufhat, ihre eigenen Sicherheits-Features hinzu.
<G-vec00060-002-s317><add.hinzufügen><en> This is basically the highest form of verbal praise we can give, when we are so blown away by things, we add at least 7 o’s and at least the same number of whatever consonant letter follows the vowel.
<G-vec00060-002-s317><add.hinzufügen><de> Dies ist im Grunde die höchste Form von verbalem Lob, das wir geben können, wenn wir von den Dingen so hinreißen, fügen wir mindestens 7 o's hinzu und mindestens die gleiche Anzahl von Konsonanten, die dem Vokal folgen.
<G-vec00060-002-s318><add.hinzufügen><en> They add too small amount of characteristics and must be used only if you have nothing else to upgrade.
<G-vec00060-002-s318><add.hinzufügen><de> Sie fügen zu wenig Eigenschaften hinzu und dürfen nur verwendet werden, wenn du nichts anderes zu aktualisieren hast.
<G-vec00060-002-s319><add.hinzufügen><en> You can add the Comic filter, then adjust it in the inspector or the heads-up display (HUD).
<G-vec00060-002-s319><add.hinzufügen><de> Fügen Sie den Comic-Filter hinzu, und passen Sie ihn im Informationsfenster oder in der Schwebepalette an.
<G-vec00060-002-s320><add.hinzufügen><en> Most applications on computers and portable devices add some type of personal information to documents and images upon creation or modification.
<G-vec00060-002-s320><add.hinzufügen><de> Die meisten Anwendungen auf Computern und tragbaren Geräten fügen bei der Erstellung oder Änderung irgendeine Art von persönlichen Informationen zu Dokumenten und Bildern hinzu.
<G-vec00060-002-s321><add.hinzufügen><en> You can add up to 62 cores and 240 GB of RAM (AMD CPUs) for each VM, or 27 cores and 120 GB RAM for Intel CPUs.
<G-vec00060-002-s321><add.hinzufügen><de> Fügen Sie pro VM bis zu 62 Cores und 240 GB RAM (bei AMD-CPU), beziehungsweise 27 Cores und 120 GB RAM (bei Intel-CPU) hinzu.
<G-vec00060-002-s322><add.hinzufügen><en> You can also add information on Michelin restaurants, tourist attractions or hotels in Altstätten or Arbon.
<G-vec00060-002-s322><add.hinzufügen><de> Fügen Sie Ihrem Routenplan Roggwil - Arbon Informationen zu Restaurants, Sehenswürdigkeiten und Hotels in Arbon hinzu.
<G-vec00060-002-s323><add.hinzufügen><en> Add a description of U-Haul Cie Ltee, Riviere-rouge and connect with thousands of local users.
<G-vec00060-002-s323><add.hinzufügen><de> Fügen Sie eine Beschreibung der U-Haul Cie ltee, Blainville und verbinden Sie mit Tausenden von Benutzern.
<G-vec00060-002-s324><add.hinzufügen><en> Click on the button featuring the plus (+) symbol and add the action Names From CSV File to the action list.
<G-vec00060-002-s324><add.hinzufügen><de> Fügen Sie die Aktion "Namen aus CSV-Datei" durch einen Klick auf die Schaltfläche mit dem "Plus"-Symbol zur Aktionsliste hinzu.
<G-vec00060-002-s325><add.hinzufügen><en> Best Uses Add the SV% field to the timephased portion of the Task Usage view when you want to see a percentage of how much you're under, over, or exactly on target with your schedule for the current level of completion on tasks.
<G-vec00060-002-s325><add.hinzufügen><de> Optimale Verwendung Fügen Sie das Feld PAP zum Zeitphasenabschnitt der Ansicht Vorgang: Einsatz hinzu, wenn Sie einen Prozentwert dazu anzeigen möchten, wie weit Sie gemäß dem aktuellen Stand der Fertigstellung der Vorgänge unter, über oder genau im Plan sind.
<G-vec00060-002-s326><add.hinzufügen><en> Create your customized a Map plugin, match your website's style and colors, and add a Map to your InstaPage website wherever you like.
<G-vec00060-002-s326><add.hinzufügen><de> Erstellen Sie das Plugin, passen Sie den Stil und die Farben Ihrer Website an und fügen Sie a Header Slideshow hinzu, wo immer Sie möchten, auf Ihrer Google Sites Site.
<G-vec00060-002-s327><add.hinzufügen><en> Add 2 eSATA ports to your desktop computer through a PCI Express expansion slot
<G-vec00060-002-s327><add.hinzufügen><de> Fügen Sie Ihrem Desktopcomputer 2 eSATA-Ports über einen PCI Express-Erweiterungssteckplatz hinzu.
<G-vec00060-002-s328><add.hinzufügen><en> Therefore, if you have a country style, then you obviously do not fit Japanese or bamboo panels, or in high-tech add a huge amount of embroidery and decor.
<G-vec00060-002-s328><add.hinzufügen><de> Daher, wenn Sie einen Landhausstil haben, dann passen Sie offensichtlich nicht zu japanischen oder Bambus-Platten, oder in High-Tech fügen Sie eine riesige Menge an Stickerei und Dekor.
<G-vec00060-002-s329><add.hinzufügen><en> Scan, store and generate copies of your physical signature and add them to documents whenever you want.
<G-vec00060-002-s329><add.hinzufügen><de> Scannen, speichern und erstellen Sie Kopien Ihrer handgeschriebenen Signatur, und fügen Sie diese in Dokumente ein, wann immer Sie möchten.
<G-vec00060-002-s330><add.hinzufügen><en> Add 16 RS232 serial ports to your computer via a single low profile PCI Express slot
<G-vec00060-002-s330><add.hinzufügen><de> Fügen Sie Ihrem Computer 8 serielle RS232-Ports über einen einzigen PCI Express-Steckplatz hinzu.
<G-vec00060-002-s331><add.hinzufügen><en> Add The Secret of Royal Bloodlines to your favorite flash games.
<G-vec00060-002-s331><add.hinzufügen><de> Fügen Sie The Secret of Royal Bloodlines auf Ihre Lieblings-Flash-Spiele.
<G-vec00060-002-s332><add.hinzufügen><en> Add either the front or rear to reduce chassis flex and improve suspension performance, or add both to make a super-rigid chassis! #101268 ALUM.CNC Front Anti-Bending Plate Set #101268 ALUM.
<G-vec00060-002-s332><add.hinzufügen><de> Fügen Sie die vordere oder hintere Chassis-Strebe hinzu, um den Flex des Chassis zu reduzieren, oder holen Sie sich beide Streben, um ein super steifes Chassis zu erlangen.
<G-vec00060-002-s333><add.hinzufügen><en> Add the new variable to an automated message - easily add dynamic variables (default variables automatically created by Guesty for you) and custom variables using the drop-down menus when creating an automated message.
<G-vec00060-002-s333><add.hinzufügen><de> Fügen Sie die neue Variable einer automatisierten Nachricht hinzu - fügen Sie einfach dynamische Variablen (Standardvariablen, die automatisch von Guesty für Sie erstellt werden) und benutzerdefinierte Variablen mithilfe der Dropdown-Menüs hinzu, wenn Sie eine automatisierte Nachricht erstellen.
<G-vec00060-002-s334><add.hinzufügen><en> When the water cools, add 1 cup 9% vinegar, 2 St. spoonful
<G-vec00060-002-s334><add.hinzufügen><de> Wenn das Wasser kühlt, fügen Sie 1 Cup 9 % Essig, 2 St. Löffel Zucker und 1 Kunst.
<G-vec00060-002-s335><add.hinzufügen><en> To do this, simply add any email addresses from our domain name for example
<G-vec00060-002-s335><add.hinzufügen><de> Um dieses zu tun, fügen Sie einfach jede E-Mail Adresse unseres Casinos, wie z.B.
<G-vec00060-002-s336><add.hinzufügen><en> Add a bookmark commented and baste own annotations in the form of text, images, pictures and audio comments at any passages added.
<G-vec00060-002-s336><add.hinzufügen><de> Fügen Sie kommentierte Lesezeichen ein und heften Sie eigene Annotationen in Form von Texten, Bildern, Fotos und Audiokommentaren an beliebigen Textstellen hinzu.
<G-vec00060-002-s337><add.hinzufügen><en> Add layers of onion, the chopped garlic and parsley, then a pour over some oil, salt and pepper.
<G-vec00060-002-s337><add.hinzufügen><de> Fügen Sie Zwiebel, den gehackten Knoblauch und Petersilie in Schichten, dann übergießen Sie etwas Öl, Salz und Pfeffer.
<G-vec00060-002-s338><add.hinzufügen><en> The last step is to create a ChangeLanguage-Module and add it via the page layout or as content-element.
<G-vec00060-002-s338><add.hinzufügen><de> Im letzten Schritt erstellen Sie ein Sprachenwechsler-Modul und fügen Sie es an der gewünschten Stelle im Seitenlayout oder einem Artikel hinzu.
<G-vec00060-002-s339><add.hinzufügen><en> Add Bristlies to your favorite flash games.
<G-vec00060-002-s339><add.hinzufügen><de> Fügen Sie Bristlies auf Ihre Lieblings-Flash-Spiele.
<G-vec00060-002-s340><add.hinzufügen><en> You can easily drag wires to connect inputs and outputs and add converters to existing connections.
<G-vec00060-002-s340><add.hinzufügen><de> Verbinden Sie beliebige Node-Inputs und -Outputs miteinander und fügen Sie Converter-Nodes in bestehende Verbindungen ein.
<G-vec00060-002-s341><add.hinzufügen><en> Add curriculum items directly into curriculums, not into folders.
<G-vec00060-002-s341><add.hinzufügen><de> Fügen Sie Studienplanelemente direkt in Studienpläne ein, nicht in Ordner.
<G-vec00060-002-s437><add.hinzufügen><en> Use them in your layout right away, add to the Swatches panel for future use or save to Adobe Color.
<G-vec00060-002-s437><add.hinzufügen><de> Sie lassen sich sofort im Layout einsetzen, zum Farbfelder-Bedienfeld hinzufügen oder in Adobe Color speichern.
<G-vec00060-002-s438><add.hinzufügen><en> To this, we can add: “using the right energy-efficient technology”.
<G-vec00060-002-s438><add.hinzufügen><de> Dazu können wir „mit der richtigen energieeffizienten Technologie“ hinzufügen.
<G-vec00060-002-s439><add.hinzufügen><en> You can also add keywords in bulk.
<G-vec00060-002-s439><add.hinzufügen><de> Sie können auch Keywords in einem Massenvorgang hinzufügen.
<G-vec00060-002-s440><add.hinzufügen><en> Tip: If you want to import a folder, please click the "Add files to iPod" drop-down button, and choose the "Add Folder to List" option.
<G-vec00060-002-s440><add.hinzufügen><de> Tipp: Wenn Sie einen Ordner importieren möchten, klicken Sie bitte auf "Den Ordner zum Gerät hinzufügen".
<G-vec00060-002-s441><add.hinzufügen><en> Add sound effect to emphasis front right.
<G-vec00060-002-s441><add.hinzufügen><de> Soundeffekte hinzufügen, um vorne rechts zu unterstreichen.
<G-vec00060-002-s442><add.hinzufügen><en> ▼ Add, emulsify and leave to cool in refrigerator.
<G-vec00060-002-s442><add.hinzufügen><de> Ein anderes Produkt Hinzufügen, emulgieren und im Kühlschrank abkühlen lassen.
<G-vec00060-002-s443><add.hinzufügen><en> Beat the egg yolks with the sugar and the cream cheese in a bowl until frothy, add the vanilla grains.
<G-vec00060-002-s443><add.hinzufügen><de> Die Eigelb mit dem Zucker und dem Frischkäse in einer Schüssel schaumig rühren, das Vanillemark hinzufügen.
<G-vec00060-002-s444><add.hinzufügen><en> The new article interface gives you a lot of options, but all you need to do is add a title and put something in the content area.
<G-vec00060-002-s444><add.hinzufügen><de> Die neue Artikel-Schnittstelle gibt Ihnen eine Menge von Optionen, aber alles, was Sie tun müssen, ist einen Titel hinzufügen und legen Sie etwas in den Content-Bereich.
<G-vec00060-002-s445><add.hinzufügen><en> Obliterate the following items from: Do not allow any site to show desktop notifications Add new fax Scanning content...
<G-vec00060-002-s445><add.hinzufügen><de> Die folgenden Elemente löschen: Anzeige von Desktop-Benachrichtigungen für keine Website zulassen Neues Faxgerät hinzufügen Der Inhalt wird durchsucht...
<G-vec00060-002-s446><add.hinzufügen><en> You add questions to tests and surveys in the same way, but you don't add points to survey questions because they aren't graded.
<G-vec00060-002-s446><add.hinzufügen><de> Sie können in gleicher Weise Fragen in Tests und Umfragen einfügen, jedoch keine Punkte zu Umfrageoptionen hinzufügen.
<G-vec00060-002-s447><add.hinzufügen><en> Click Add Chart Element.
<G-vec00060-002-s447><add.hinzufügen><de> Klicken Sie auf Diagrammelement hinzufügen.
<G-vec00060-002-s448><add.hinzufügen><en> Click on 'Edit' > 'Add Outline item' or simply click ⌘⇧D.
<G-vec00060-002-s448><add.hinzufügen><de> Klicken Sie auf 'Bearbeiten' > 'Gliederungselement hinzufügen' oder verwenden Sie die Tastenkombination ⌘⇧D.
<G-vec00060-002-s449><add.hinzufügen><en> You can then schedule the recorded profile, and add other actions you want it to perform.
<G-vec00060-002-s449><add.hinzufügen><de> Sie können dann das aufgezeichnete Profil planen und weitere Aktionen hinzufügen, die es ausführen soll.
<G-vec00060-002-s450><add.hinzufügen><en> Mail On the left bar, click on the 'Add' link next to 'Contacts'.
<G-vec00060-002-s450><add.hinzufügen><de> Auf der linken Leiste, klicken Sie auf dem Link "Hinzufügen" neben 'Kontakte'.
<G-vec00060-002-s451><add.hinzufügen><en> Hover over the widget you want to add to a different Dashboard.
<G-vec00060-002-s451><add.hinzufügen><de> Bewegen Sie die Maus über das Widget, das Sie einem anderen Dashboard hinzufügen wollen.
<G-vec00060-002-s452><add.hinzufügen><en> In a saucepan mix the coconut milk and the curry, add the cream and bring to a boil, then whisk with a mixer.
<G-vec00060-002-s452><add.hinzufügen><de> In einem kleinen Topf Kokosmilch und Curry vermischen, die Sahne hinzufügen, alles zum Kochen bringen und dann im Mixer pürieren.
<G-vec00060-002-s453><add.hinzufügen><en> To do this, please go to My Account settings in the Client Portal area, click ‘Manage Credit Cards’ > ‘Add Credit Card Now’ and follow the prompts.
<G-vec00060-002-s453><add.hinzufügen><de> Gehen Sie dazu in Ihrem Kundenportal zu "Meine Kontoeinstellungen", klicken Sie auf "Kreditkarten verwalten"> Jetzt Kreditkarte hinzufügen und Anweisungen befolgen.
<G-vec00060-002-s454><add.hinzufügen><en> This allows you to add new applications and services very quickly.
<G-vec00060-002-s454><add.hinzufügen><de> So können Sie sehr schnell neue Anwendungen und Dienste hinzufügen.
<G-vec00060-002-s455><add.hinzufügen><en> If you do not add an action, then the $MT_EMBEDDEDMESSAGE page source will not be created.
<G-vec00060-002-s455><add.hinzufügen><de> Wenn Sie keine Aktion hinzufügen, wird die Seitenquelle $MT_EMBEDDEDMESSAGE nicht erstellt.
<G-vec00060-002-s456><add.hinzufügen><en> With the wall stickers, you can add subtle dots or sparkles in a few minutes and create a fun twist on the walls.
<G-vec00060-002-s456><add.hinzufügen><de> Mit diesen Wandaufklebern bekommen die Wände in wenigen Minuten subtile Punkte oder ein Funkeln hinzugefügt, die einen lustigen Twist schaffen.
<G-vec00060-002-s457><add.hinzufügen><en> It has all the features of messaging apps and more specific ways like stickers and doodles to add on during te conversation.
<G-vec00060-002-s457><add.hinzufügen><de> Es hat alle Features der Messaging-Apps und spezifischere Arten wie Aufkleber und Kritzeleien auf während des Gesprächs hinzugefügt.
<G-vec00060-002-s458><add.hinzufügen><en> It will also simplify engineering and repairs, upgrade onboard status sensors and add an extra layer of control redundancy in the event of accidents.
<G-vec00060-002-s458><add.hinzufügen><de> Gleichzeitig werden Technik und Reparaturen vereinfacht, die Status-Sensoren an Bord aufgerüstet und eine zusätzliche Ebene der Steuerungsredundanz bei Unfällen hinzugefügt.
<G-vec00060-002-s459><add.hinzufügen><en> You can add shipping fees through the online store settings.
<G-vec00060-002-s459><add.hinzufügen><de> Liefergebühren können in den Einstellungen des Online-Shops hinzugefügt werden.
<G-vec00060-002-s460><add.hinzufügen><en> To only show colors for a specific product, you should filter on this product or alternatively add the dimension "products".
<G-vec00060-002-s460><add.hinzufügen><de> Um nur die für ein bestimmtes Produkt gewählten Farben anzuzeigen, sollte auf dieses Produkt gefiltert werden oder "Produkte" als Dimension hinzugefügt werden.
<G-vec00060-002-s461><add.hinzufügen><en> See Customize the Quick Access Toolbar to learn how to add commands.
<G-vec00060-002-s461><add.hinzufügen><de> Wenn Sie wissen möchten, wie Befehle hinzugefügt werden, lesen Sie Anpassen der Symbolleiste für den Schnellzugriff.
<G-vec00060-002-s462><add.hinzufügen><en> If you didn’t add your wallet address we will ask you to do so before continuing to the payment.
<G-vec00060-002-s462><add.hinzufügen><de> Wenn du deine Wallet-Adresse nicht hinzugefügt hast, werden wir dich bitten, dies zu tun, bevor du mit der Zahlung fortfährst.
<G-vec00060-002-s463><add.hinzufügen><en> Add OCS Driver
<G-vec00060-002-s463><add.hinzufügen><de> OCS Treiber hinzugefügt.
<G-vec00060-002-s464><add.hinzufügen><en> In the lists, choose the conditions that you want to add to the rule.
<G-vec00060-002-s464><add.hinzufügen><de> Wählen Sie in den Listen die Bedingungen aus, die der Regel hinzugefügt werden sollen.
<G-vec00060-002-s465><add.hinzufügen><en> Subscriptions are cumulative, so if you pay for an additional year of service, it will add to your current subscription or free year-long trial.
<G-vec00060-002-s465><add.hinzufügen><de> Abos sind kumulativ, das heißt, wenn Sie für ein weiteres Jahr bezahlen, wird es zu Ihrem jetzigen Abo oder kostenlosen Jahr hinzugefügt.
<G-vec00060-002-s466><add.hinzufügen><en> With Subversion, you can add, - delete, copy, and rename both files and directories.
<G-vec00060-002-s466><add.hinzufügen><de> Mit Subversion - können sowohl Dateien als auch Verzeichnisse - hinzugefügt, gelöscht, kopiert und umbenannt werden.
<G-vec00060-002-s467><add.hinzufügen><en> Edit (Add, Delete or Change) any of the information and Save your changes.
<G-vec00060-002-s467><add.hinzufügen><de> Bearbeiten (Hinzugefügt, gelöscht oder geändert) beliebige Informationen und Speichern Sie Ihre Änderungen.
<G-vec00060-002-s468><add.hinzufügen><en> With a click at "edit" you will get to the details view, where you can add rules.
<G-vec00060-002-s468><add.hinzufügen><de> Mit einem Klick auf "bearbeiten" gelangen Sie zur Detailansicht, in der die Regel hinzugefügt wird.
<G-vec00060-002-s469><add.hinzufügen><en> At frequencies away from center frequency, add Channel Response to the Absolute Amplitude Accuracy.
<G-vec00060-002-s469><add.hinzufügen><de> Bei Frequenzen ungleich der Mittenfrequenz muss zur absoluten Amplitudengenauigkeit die Kanalantwort hinzugefügt werden.
<G-vec00060-002-s470><add.hinzufügen><en> Pressing the return or space keys will turn a square black or add a circle respectively, and pressing the key again will show the number again or remove the circle.
<G-vec00060-002-s470><add.hinzufügen><de> Durch Drücken der Eingabe- oder Leertaste wird ein Quadrat schwarz gefärbt oder respektive ein Kreis hinzugefügt und durch erneutes Drücken der Taste wird wieder die Zahl gezeigt oder der Kreis entfernt.
<G-vec00060-002-s471><add.hinzufügen><en> The designer can add ribs on thin walls die casting to increase component strength.
<G-vec00060-002-s471><add.hinzufügen><de> Beim Entwurf können bei dünnen Wänden Verbindungsrippen hinzugefügt werden, um die Festigkeit des Teils zu erhöhen.
<G-vec00060-002-s472><add.hinzufügen><en> If you would like a user to be able to edit dashboards, queries, and datasets without you sharing them first, you should add them as an admin.
<G-vec00060-002-s472><add.hinzufügen><de> Wenn ein Benutzer Dashboards, Querys und Verbindungen bearbeiten soll, ohne dass diese vorher mit ihm geteilt werden müssen, muss er als Administrator hinzugefügt werden.
<G-vec00060-002-s473><add.hinzufügen><en> Select the Data Disc option from the homepage and you will be directed to another screen where you can add audio files to the software interface.
<G-vec00060-002-s473><add.hinzufügen><de> Nachdem Sie Ihre Dateien erfolgreich hinzugefügt haben, wählen Sie die DVD-Menüvorlage rechts in der Softwareoberfläche.
<G-vec00060-002-s474><add.hinzufügen><en> You can add offices, users and features easily to grow and customize your communications for a true competitive advantage.
<G-vec00060-002-s474><add.hinzufügen><de> Standorte, Benutzer und Funktionen können leicht hinzugefügt werden, sodass Sie dem Wachstum Ihres Unternehmens Rechnung tragen und sich mit Ihrer Kommunikationslösung einen echten Wettbewerbsvorteil verschaffen können.
<G-vec00060-002-s475><add.hinzufügen><en> No such ‘confession’ is even pretended to by the Jharkhand Police to add my name to this case.
<G-vec00060-002-s475><add.hinzufügen><de> Keines dieser „Geständnisse“ wurde überhaupt von der Polizei Jharkhands präsentiert, um meinen Namen zu diesem Fall hinzuzufügen.
<G-vec00060-002-s476><add.hinzufügen><en> Help from the developer community from those that want to add code, documentation, or samples
<G-vec00060-002-s476><add.hinzufügen><de> Die Entwickler-Community kann dabei helfen, Code, Dokumentation oder Beispiele hinzuzufügen.
<G-vec00060-002-s477><add.hinzufügen><en> Fortunately it's not hard to add chapter numbers to your captions and have them automatically update if you move a figure from chapter to chapter in the course of editing.
<G-vec00060-002-s477><add.hinzufügen><de> Glücklicherweise ist es nicht schwierig, Ihren Beschriftungen Kapitelnummern hinzuzufügen und sie automatisch aktualisieren zu lassen, wenn Sie eine Abbildung während der Dokumentbearbeitung zwischen den Kapiteln verschieben.
<G-vec00060-002-s478><add.hinzufügen><en> Shachtman forgets to add that Lenin’s hope did not at all materialize.
<G-vec00060-002-s478><add.hinzufügen><de> Shachtman vergißt hinzuzufügen, daß sich Lenins Hoffnung nicht verwirklichte.
<G-vec00060-002-s479><add.hinzufügen><en> Allows the app to change or add to personal profile information stored on your device, such as your name and contact information.
<G-vec00060-002-s479><add.hinzufügen><de> Ermöglicht der App, auf Ihrem Gerät gespeicherte persönliche Profildaten zu ändern, darunter Ihren Namen und Ihre Kontaktdaten, sowie Daten hinzuzufügen.
<G-vec00060-002-s480><add.hinzufügen><en> Our rooms are double with the possibility to add a third bed. We also have a room with a box room incorporated, complete with bunk beds for the children.
<G-vec00060-002-s480><add.hinzufügen><de> Es gibt die Möglichkeit, in alle unsere Doppelzimmer ein drittes Bett hinzuzufügen: außerdem gibt es ein Zimmer mit einem inneren Kinderzimmer mit Etagenbett.
<G-vec00060-002-s481><add.hinzufügen><en> Being open source, decentralized and with the ability to add smart contracts, it offers a great deal of transparency and trust between the people who use it, thus avoiding any third-party intermediaries.
<G-vec00060-002-s481><add.hinzufügen><de> Als dezentralisierte Open-Source-Technologie mit der Möglichkeit, Smart Contracts hinzuzufügen, bietet die Blockchain enorm viel Transparenz und schafft Vertrauen zwischen den Benutzern, ohne dass Drittparteien als Vermittler erforderlich sind.
<G-vec00060-002-s482><add.hinzufügen><en> To add a new term for which an entry and therefore at least one term already exists in the same or another language, you must first select the respective entry or term.
<G-vec00060-002-s482><add.hinzufügen><de> Um einen neuen Term hinzuzufügen, für den es bereits einen Eintrag und somit mindestens auch schon einen Term in einer anderen oder derselben Sprache gibt, müssen Sie zunächst den entsprechenden Eintrag oder Term auswählen.
<G-vec00060-002-s483><add.hinzufügen><en> When you add the plants to your ecosystem, make sure to separate them and add them individually.
<G-vec00060-002-s483><add.hinzufügen><de> Wenn du die Pflanzen zu deinem Ökosystem hinzufügst, achte darauf, sie zu trennen und einzeln hinzuzufügen.
<G-vec00060-002-s484><add.hinzufügen><en> Users can add Text and Image both watermarks to their PDF files by utilizing this program.
<G-vec00060-002-s484><add.hinzufügen><de> Es ist möglich, Wasserzeichen auf mehrere PDF-Dateien hinzuzufügen, die in einem Ordner gespeichert sind.
<G-vec00060-002-s485><add.hinzufügen><en> To add picture watermark, please click "Add Picture Watermark" button, and choose a picture in the dialog that opens, and adjust the settings below.
<G-vec00060-002-s485><add.hinzufügen><de> Um Bildwasserzeichen hinzuzufügen, klicken Sie bitte auf „Bildwasserzeichen hinzufügen“, wählen Sie ein Bild aus dem geöffneten Dialog aus und passen Sie die Einstellungen an.
<G-vec00060-002-s486><add.hinzufügen><en> d products and even cookery schools to add ‘edutainment’.
<G-vec00060-002-s486><add.hinzufügen><de> Sogar Kochschulen sind denkbar, um 'Edutainment“-Elemente hinzuzufügen.
<G-vec00060-002-s487><add.hinzufügen><en> If you want to let other people administer the folder, click the Add button to add their names.
<G-vec00060-002-s487><add.hinzufügen><de> Wenn Sie anderen Personen den Ordner zu verwalten lassen möchten, klicken Sie auf die Schaltfläche Hinzufügen, um deren Namen hinzuzufügen.
<G-vec00060-002-s488><add.hinzufügen><en> If not, click on the “Plus” sign to add AdGuard and then tick it.
<G-vec00060-002-s488><add.hinzufügen><de> Wenn nicht, klicken Sie auf das "Plus"-Zeichen, um AdGuard hinzuzufügen und dann anzukreuzen.
<G-vec00060-002-s489><add.hinzufügen><en> Send your agents on raids to foreign lands to steal world wonders and monuments, to add them to your collection.
<G-vec00060-002-s489><add.hinzufügen><de> Entsende Agenten in fremde Länder und reiß dir Weltwunder und Denkmäler unter den Nagel, um sie deiner Sammlung hinzuzufügen.
<G-vec00060-002-s490><add.hinzufügen><en> To add entries to the menu, you can either create a /boot/grub/custom.cfg file or modify the /etc/grub.d/50_custom file.
<G-vec00060-002-s490><add.hinzufügen><de> Um Einträge zum Menü hinzuzufügen, können Sie entweder eine Datei namens /boot/grub/custom.cfg erstellen oder die Datei /etc/grub.d/50_custom ändern.
<G-vec00060-002-s491><add.hinzufügen><en> To add additional site owners, enter an employee's name under Add additional owners.
<G-vec00060-002-s491><add.hinzufügen><de> Um weitere Websitebesitzer hinzuzufügen, geben Sie unter Weitere Besitzer hinzufügen den Namen eines Mitarbeiters ein.
<G-vec00060-002-s492><add.hinzufügen><en> Start the program and click “Import” to add PowerPoint files.
<G-vec00060-002-s492><add.hinzufügen><de> Starten Sie das Programm und klicken Sie auf "Import" PowerPoint-Dateien hinzuzufügen.
<G-vec00060-002-s493><add.hinzufügen><en> That’s why we have made it so easy to add your own fonts to Crello.
<G-vec00060-002-s493><add.hinzufügen><de> Deshalb haben wir es so einfach gemacht, Crello eigene Schriftarten hinzuzufügen.
<G-vec00060-002-s570><add.hinzufügen><en> If we also wanted to add them to a tool bar, we could have given icons to the actions.
<G-vec00060-002-s570><add.hinzufügen><de> Wollten wir sie auch zu einer Werkzeugleiste hinzufügen, könnten wir für die Aktionen auch Icons festlegen.
<G-vec00060-002-s571><add.hinzufügen><en> In the dropdown menu on the After Sale Log page there is an option to "add a note".
<G-vec00060-002-s571><add.hinzufügen><de> Im Sales-Management-Menü finden Sie die Option "Notiz hinzufügen".
<G-vec00060-002-s572><add.hinzufügen><en> Learn how to add a payment method if you don't have one on file.
<G-vec00060-002-s572><add.hinzufügen><de> Hier erfahren Sie, wie Sie eine Zahlungsmethode hinzufügen, wenn Sie noch keine hinterlegt haben.
<G-vec00060-002-s573><add.hinzufügen><en> Learn how to add images, audio/music and video.
<G-vec00060-002-s573><add.hinzufügen><de> Erfahren Sie, wie Sie Bilder, Audio/Musik und Videos hinzufügen.
<G-vec00060-002-s574><add.hinzufügen><en> Less To make room for more information in a table, you can add rows and columns without leaving Word Online.
<G-vec00060-002-s574><add.hinzufügen><de> Wenn Sie Platz für weitere Daten in einer Tabelle benötigen, können Sie Zeilen und Spalten hinzufügen, ohne Word Online verlassen zu müssen.
<G-vec00060-002-s575><add.hinzufügen><en> You'll learn to add functionality to your app that lets users upload images from their device's gallery or camera, then rotate and automatically resize the images, and finally save the modified images to your database.
<G-vec00060-002-s575><add.hinzufügen><de> Sie erfahren, wie Sie Funktionen zu Ihrer App hinzufügen, mit denen Benutzer Bilder aus der Galerie oder von der Kamera ihres Geräts hochladen können, diese drehen, automatisch in der Größe anpassen und die bearbeiteten Bilder schließlich in Ihrer Datenbank speichern können.
<G-vec00060-002-s576><add.hinzufügen><en> Opens the Select Devices dialog, from which target devices to add to this view are selected.
<G-vec00060-002-s576><add.hinzufügen><de> Öffnet das Dialogfeld “Select Devices”, in dem Sie Zielgeräte auswählen und dieser Ansicht hinzufügen können.
<G-vec00060-002-s577><add.hinzufügen><en> Follow these steps to create a new project, add videos and graphics, and apply transitions.
<G-vec00060-002-s577><add.hinzufügen><de> Diese Anleitung zeigt Ihnen, wie Sie ein neues Projekt erstellen, Video-Clips und Grafiken hinzufügen und Überblendungen anwenden.
<G-vec00060-002-s578><add.hinzufügen><en> In the Add Role Services dialog, expand Web Server, then Application Development, select ASP.NET and CGI.
<G-vec00060-002-s578><add.hinzufügen><de> Erweitern Sie im Dialogfeld "Rollendienste hinzufügen" zuerst "Webserver" und dann "Anwendungsentwicklungsfeatures".
<G-vec00060-002-s579><add.hinzufügen><en> 1.To add a new computer, click Computers, Add New and then select Computers (alternatively click the gear icon next to existing Static group and then click Add New).
<G-vec00060-002-s579><add.hinzufügen><de> 1.Um einen neuen Computer hinzuzufügen, navigieren Sie zur Registerkarte Computer, klicken Sie auf Neue hinzufügen und wählen Sie Computer aus (oder klicken Sie auf das Zahnradsymbol neben einer vorhandenen statischen Gruppe und anschließend auf Neue hinzufügen).
<G-vec00060-002-s580><add.hinzufügen><en> Right-click NIS Servers, and then click Add NIS Server.
<G-vec00060-002-s580><add.hinzufügen><de> Klicken Sie mit der rechten Maustaste auf NIS-Server, und klicken Sie dann auf NIS-Server hinzufügen.
<G-vec00060-002-s581><add.hinzufügen><en> This page describes how to add video-on-demand apps to the App channels list in OneGuide.
<G-vec00060-002-s581><add.hinzufügen><de> Auf dieser Seite wird erläutert, wie Sie Video-on-Demand-Apps zur Liste der App-Kanäle in OneGuide hinzufügen.
<G-vec00060-002-s582><add.hinzufügen><en> You may have to add all the available domains of a particular website, if they do have different once for different device platforms like mobile, tablet and a computer because the blacklist works with only the domain specified.
<G-vec00060-002-s582><add.hinzufügen><de> Möglicherweise müssen Sie alle verfügbaren Domains einer bestimmten Webseite hinzufügen, wenn sie für verschiedene Geräteplattformen wie Handy, Tablet und Computer unterschiedlich sind, da die Blacklist nur mit der angegebenen Domain funktioniert.
<G-vec00060-002-s583><add.hinzufügen><en> If you know any other happy ending massages in Cebu, please leave a comment below and I will add it to this guide.
<G-vec00060-002-s583><add.hinzufügen><de> Wenn du noch andere Happy Ending Massagen in Cebu kennst, dann hinterlasse bitte unten einen Kommentar und ich werde sie zu diesem Guide hinzufügen.
<G-vec00060-002-s584><add.hinzufügen><en> Once you set up a team page, add event types for invitees to choose from.
<G-vec00060-002-s584><add.hinzufügen><de> Sobald Sie eine Teamseite eingerichtet haben, können Sie Ereignistypen hinzufügen, aus denen Eingeladene wählen können.
<G-vec00060-002-s585><add.hinzufügen><en> Learn how in this video, Add fades to audio with the Audition waveform display.
<G-vec00060-002-s585><add.hinzufügen><de> Erfahren Sie in diesem Video, wie Sie Ein- und Ausblendungen mit der Auditions-Wellenformanzeige zu Audio hinzufügen.
<G-vec00060-002-s586><add.hinzufügen><en> Number of metrics in a single panel: Adobe Analytics offers the ability to add virtually as many metrics to a freeform table as your screen can fit.
<G-vec00060-002-s586><add.hinzufügen><de> Anzahl der Metriken in einem einzelnen Fenster: In Adobe Analytics können Sie so viele Metriken zu einer Freiformtabelle hinzufügen, wie auf den Bildschirm passen.
<G-vec00060-002-s587><add.hinzufügen><en> I describe how to add the Report Server Content types later in this article under Integration with Report Builder 3.0.
<G-vec00060-002-s587><add.hinzufügen><de> Weiter unten im Abschnitt Integration in Report Builder 3.0 wird beschrieben, wie Sie die Report Server-Inhaltstypen manuell hinzufügen.
<G-vec00060-002-s588><add.hinzufügen><en> But Outlook prefers that you build distribution lists from your Contacts, so you first must add the sender to an address book in Contacts.
<G-vec00060-002-s588><add.hinzufügen><de> In Outlook werden Verteilerlisten jedoch aus Ihren Kontakten erstellt, daher müssen Sie also den Absender zuerst zu einem Adressbuch in den Kontakten hinzufügen.
