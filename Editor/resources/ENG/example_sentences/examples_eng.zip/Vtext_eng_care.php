<G-vec00574-002-s019><care.achten><en> For synchronizing the content of iPod or to update the software, you just need to connect the device to the system and let iTunes media player take care of the rest.
<G-vec00574-002-s019><care.achten><de> Für die Synchronisation der Inhalte des iPod oder um die Software zu aktualisieren, müssen Sie nur das Gerät an das System anschließen und lassen Sie den iTunes Media Player auf den Rest achten.
<G-vec00574-002-s020><care.achten><en> It is worth taking care of additional desktop lighting.
<G-vec00574-002-s020><care.achten><de> Es lohnt sich, auf zusätzliche Desktop-Beleuchtung zu achten.
<G-vec00574-002-s021><care.achten><en> Well, in order to keep the nose fresh again at night, take care of the good air humidification.
<G-vec00574-002-s021><care.achten><de> Nun, um die Nase nachts wieder frisch zu halten, achten Sie auf die gute Luftbefeuchtung.
<G-vec00574-002-s022><care.achten><en> In addition to creating a calm environment in the bedroom, you need to take care of its quality gardening.
<G-vec00574-002-s022><care.achten><de> Zusätzlich zu einer ruhigen Umgebung im Schlafzimmer müssen Sie auf die Qualität der Gartenarbeit achten.
<G-vec00574-002-s023><care.achten><en> I thought since Master has given me life, I should ask him to help take care of it.
<G-vec00574-002-s023><care.achten><de> Ich dachte, da mir der Meister das Leben gegeben hat, sollte ich den Meister bitten mir zu helfen, auf mein Leben zu achten.
<G-vec00574-002-s024><care.achten><en> Learn what you can do to take better care of both of you.
<G-vec00574-002-s024><care.achten><de> Erfahren Sie, was Sie tun können, um besser auf Sie beide zu achten.
<G-vec00574-002-s025><care.achten><en> Likewise, there are granulocytes that do not need to take care of their health when choosing destructive methods against microbes that are consumed.
<G-vec00574-002-s025><care.achten><de> Ebenso gibt es Granulozyten, die nicht auf ihre Gesundheit achten müssen, wenn sie zerstörerische Methoden gegen verbrauchte Mikroben wählen.
<G-vec00574-002-s026><care.achten><en> Every single person has to take care not only of his own safety but for the safety of his / her colleagues, visitors as well as employees of other companies.
<G-vec00574-002-s026><care.achten><de> Jeder muss nicht nur auf seine Sicherheit, sondern auch auf die seiner Kolleginnen und Kollegen, Besucher und Mitarbeiterinnen und Mitarbeiter anderer Firmen achten.
<G-vec00574-002-s027><care.achten><en> Out of principle, we use pure and seasonal organic products from the region, whilst supporting the local economy and taking care to work responsibly and respectfully in harmony with nature.
<G-vec00574-002-s027><care.achten><de> Aus Überzeugung verwenden wir unverfälschte und saisonale BIO-Produkte aus der Region, unterstützen die heimische Landwirtschaft und achten auf einen verantwortungsbewussten und respektvollen Umgang im Einklang mit der Natur.
<G-vec00574-002-s028><care.achten><en> When playing chess one has to take care that the user only uses the computer to transmit the moves.
<G-vec00574-002-s028><care.achten><de> Beim Schach spielen ist darauf zu achten, dass der Anwender den Computer lediglich zum Übermitteln der Züge benutzt.
<G-vec00574-002-s029><care.achten><en> One would be lying to say we don't care about prices, while optimizing our standards for quality.
<G-vec00574-002-s029><care.achten><de> Man würde lügen zu behaupten, dass wir bei der Optimierung der Qualität nicht auf den Preis achten.
<G-vec00574-002-s030><care.achten><en> I tell you what to take care of.
<G-vec00574-002-s030><care.achten><de> Ich erkläre dir, worauf du achten musst.
<G-vec00574-002-s031><care.achten><en> More consumers will care about cutting down on waste and will prefer natural, local or seasonal products.
<G-vec00574-002-s031><care.achten><de> Konsumenten würden mehr auf Abfallvermeidung achten und bevorzugten natürliche, lokale oder saisonale Produkte, wie Euromonitor betont.
<G-vec00574-002-s032><care.achten><en> We accompany the realization of your plans with the project participants and take care of schedules at a strict cost orientation.
<G-vec00574-002-s032><care.achten><de> Wir begleiten die Realisation des Vorhabens mit den Projektbeteiligten und achten auf Zeitpläne bei strikter Kostenorientierung.
<G-vec00574-002-s033><care.achten><en> Note to select the correct title: When selecting the title, you should take care of an exact naming.
<G-vec00574-002-s033><care.achten><de> Hinweis zur Auswahl des richtigen Titels: Bei der Auswahl des Titels ist auf eine sinnvolle Benennung zu achten.
<G-vec00574-002-s034><care.achten><en> In general, the owner should pay attention to the care of the coat and the hygiene of the dog.
<G-vec00574-002-s034><care.achten><de> Generell hat ein Halter auf die Fellpflege und Hygiene seines Hundes zu achten.
<G-vec00574-002-s035><care.achten><en> Please take care to select the appropriate sealant for your tent material (i.e. silicone or PU coating).
<G-vec00574-002-s035><care.achten><de> Beim Kauf bitte auf die Art des zu reparierenden Zeltmaterials (Silikon- oder PU-Beschichtung) achten.
<G-vec00574-002-s036><care.achten><en> This is why I wish to lift up my voice, inviting everyone to protect and to care for children, so that nothing may extinguish their smile, but that they may live in peace and look to the future with confidence.
<G-vec00574-002-s036><care.achten><de> Darum möchte ich meine Stimme erheben und alle auffordern, die Kinder zu beschützen und auf sie zu achten, damit ihr Lächeln nie vergehe, sie in Frieden leben und vertrauensvoll in die Zukunft blicken können.
<G-vec00574-002-s037><care.achten><en> While it's not the most important thing in the world, healthy glowing skin helps your self-confidence and lets other people know that you can take care of yourself.
<G-vec00574-002-s037><care.achten><de> Auch wenn es Wichtigeres gibt, unterstützt eine gesunde, strahlende Haut das Selbstvertrauen und vermittelt anderen, dass du auf dich achten kannst.
<G-vec00574-002-s456><care.kümmern><en> It can also be successfully used by healthy people who care about the proper care of the face, body, hair and nails.
<G-vec00574-002-s456><care.kümmern><de> Es kann auch erfolgreich von gesunden Menschen verwendet werden, die sich um die richtige Pflege von Gesicht, Körper, Haar und Nägel kümmern.
<G-vec00574-002-s457><care.kümmern><en> His wife had to shoulder the farm work and take care of his 80-year-old mother and grand-baby by herself.
<G-vec00574-002-s457><care.kümmern><de> Seine Frau muss nun alleine die schwere Farmarbeit schultern und sich um ihre 80-jährige Schwiegermutter und ihr Enkelkind kümmern.
<G-vec00574-002-s458><care.kümmern><en> Eva Ringler and her team were able to show that territorial males care for all clutches inside their territory, even if they had not fertilised a single clutch in the previous weeks.
<G-vec00574-002-s458><care.kümmern><de> Verhaltensforscherin Eva Ringler vom Messerli Forschungsinstitut der Vetmeduni Vienna und ihr Team konnten zeigen, dass sie sich zumeist um alle Gelege in ihrem Territorium kümmern, sogar wenn sie in den Wochen zuvor kein eigenes Gelege befruchtet hatten.
<G-vec00574-002-s459><care.kümmern><en> They'll drive, fly, walk, run or you to show how much they care about you.
<G-vec00574-002-s459><care.kümmern><de> Sie würden zu Dir fahren, fliegen, laufen oder rennen, nur um zu zeigen, wie sehr sie sich um dich kümmern.
<G-vec00574-002-s460><care.kümmern><en> If you install an electric bio toilet toilet yourself, you must take care of the ventilation device in advance.
<G-vec00574-002-s460><care.kümmern><de> Wenn Sie eine elektrische Bio-Toiletten-Toilette selbst installieren, müssen Sie sich im Voraus um das Lüftungsgerät kümmern.
<G-vec00574-002-s461><care.kümmern><en> So many things to take care of, so many trivial cares that kept her continually occupied.
<G-vec00574-002-s461><care.kümmern><de> So viele Dinge, um die man sich kümmern muss, so viele belanglose Dinge, die sie laufend ausfüllten.
<G-vec00574-002-s462><care.kümmern><en> And you would prefer to spend more time with those lovers who care most about you or are more interesting persons in general.
<G-vec00574-002-s462><care.kümmern><de> Und man würde es vorziehen, mehr Zeit mit jenen Liebespartnern zu verbringen, die sich am meisten um einen kümmern, oder allgemein die interessanteren Personen sind.
<G-vec00574-002-s463><care.kümmern><en> “With two square meters of skin to take care of everyday, it is not surprising that today’s consumers want to use natural and mild products to cleanse and nourish.
<G-vec00574-002-s463><care.kümmern><de> „Bei zwei Quadratmetern Haut, um die man sich täglich zu kümmern hat, ist es nicht weiter verwunderlich, dass die heutigen Verbraucher natürliche und sanfte Produkte zur Reinigung und Pflege bevorzugen.
<G-vec00574-002-s464><care.kümmern><en> Whether they are used as treatment tents, in which doctors and medics care for patients, as a soup kitchen or as a storage tent for equipment and provisions: all tents from Trotec can be equipped with a maintenance opening.
<G-vec00574-002-s464><care.kümmern><de> Ob als Behandlungszelt, in dem sich Ärzte und Sanitäter um Patienten kümmern, als Suppenküche oder als Lagerzelt für Geräte und Verpflegung: Alle Zelte von Trotec lassen sich mit einer Versorgungsöffnung ausstatten.
<G-vec00574-002-s465><care.kümmern><en> But first Birgit had to take care of another lantern, to be more exact the lighthouse of our Granny aka the silent blog reader.
<G-vec00574-002-s465><care.kümmern><de> Vorher musste sich Birgit aber noch um eine andere Laterne kümmern, genauer gesagt das Lichthaus von unserer Oma alias die stille Blogleserin.
<G-vec00574-002-s466><care.kümmern><en> And there is plenty to do: on the big farm there are any number of animals that have to be taken care of.
<G-vec00574-002-s466><care.kümmern><de> Es ist viel zu tun: Auf dem großen Hof gibt es jede Menge Tiere, um die man sich kümmern muss.
<G-vec00574-002-s467><care.kümmern><en> So, to pull from Micah Solomon in his Forbes article titled “Millennials, The Biggest Generation of Customers Ever, Don’t Care About the Internet,” it would be a really bad idea to make millennials pay for something they’ve always seen as a basic utility similar to electricity or running water.
<G-vec00574-002-s467><care.kümmern><de> Also, um von Micah Solomons Forbes Artikel zu zitieren, der den Titel “Millennials, die größte Generation von Kunden, die sich nicht um das Internet kümmern,” hat, wäre es wirklich eine schlechte Idee, Millennials für etwas zahlen zu lassen, was Sie schon immer als ein grundlegendes Diestprogram angesehen haben, ähnlich wie Strom oder fließendes Wasser.
<G-vec00574-002-s468><care.kümmern><en> Without him this would not have been possible. We run some special configs which had to be taken care of.
<G-vec00574-002-s468><care.kümmern><de> Ohne ihn wäre das nicht möglich gewesen, da wir einiges an Spezialkonfiguration haben, um die man sich kümmern musste.
<G-vec00574-002-s469><care.kümmern><en> I think that precisely here, an "integrated pastoral care" should be put into practice, for in fact not every parish priest can cope adequately with youth.
<G-vec00574-002-s469><care.kümmern><de> Ich denke, gerade hier sollte eine »integrierte Seelsorge« verwirklicht werden, weil ja nicht jeder Pfarrer die Möglichkeit hat, sich genügend um die Jugend zu kümmern.
<G-vec00574-002-s470><care.kümmern><en> You’ll have a large field, five different animals to take care of, nine farm products to sell and six buildings to buy.
<G-vec00574-002-s470><care.kümmern><de> Sie haben ein großes Feld, fünf verschiedene Tiere, um die Sie sich kümmern, neun Bauernhof-Produkte zum Verkaufen und sechs Gebäude zum Kaufen.
<G-vec00574-002-s471><care.kümmern><en> Among these guardian spirits who care for the children there may be some who have been great authors or narrators of fairy-tales in the physical world.
<G-vec00574-002-s471><care.kümmern><de> Unter den Schutzgeistern, die sich um die Kinder kümmern, können Wesen sein, die einmal große Märchenerzähler und Dichter in der physischen Welt gewesen sind.
<G-vec00574-002-s472><care.kümmern><en> In our team you have a brought range of job opportunities, whether you would like to work in Sales and meet the customer personally, take care about him in the Customer Service team or develop trainings for the usage of our products.
<G-vec00574-002-s472><care.kümmern><de> In unserem Team erhalten Sie eine Reihe von Jobangeboten, je nachdem, ob Sie im Vertrieb arbeiten und unsere Kunden persönlich kennenlernen möchten, sich lieber im Customer Service-Team um unsere Kunden kümmern oder auch Schulungen zum Gebrauch unserer Produkte entwickeln.
<G-vec00574-002-s473><care.kümmern><en> You said you would let my mom go, but you didn't!" All his relatives and friends blamed him, saying that he didn't care about his mom.
<G-vec00574-002-s473><care.kümmern><de> Sie haben gesagt, Sie würden meine Mama gehen lassen, doch das haben Sie nicht getan!“ Alle sein Verwandten und Freunde beschimpften ihn, sagten, er würde sich nicht um seine Mutter kümmern.
<G-vec00574-002-s474><care.kümmern><en> The "deacons" are the men appointed to "serve tables" (Acts 6:2-6), namely those who care exclusively for the business side of things.
<G-vec00574-002-s474><care.kümmern><de> Die "Diener" sind die Männer, die ernannt sind, zu "Tische zu dienen" (Apg 6,2-6), nämlich diejenigen, die sich ausschließlich um die geschäftliche Seite der Dinge kümmern.
<G-vec00574-002-s399><care.pflegen><en> Take care of your favourite outfit easily with our Boots and Tack Cleaner.
<G-vec00574-002-s399><care.pflegen><de> Pflegen sie Ihre wertvollen Outfits mit unseren Gamaschen- und Lederreinigern.
<G-vec00574-002-s400><care.pflegen><en> "The Kurds and the assyrian-aramaic Christians regard Hasankeyf as an integral part of their identity, to which they are attached and which they care for", reported the Near-east correspondent of the GfbV Germany, Kamal Sido.
<G-vec00574-002-s400><care.pflegen><de> "Die Kurden und christlichen Assyro-Aramäer betrachten Hasankeyf als unverzichtbaren Teil ihrer Identität, an der sie hängen und die sie pflegen", berichtete der Nahostreferent der GfbV Deutschland, Kamal Sido.
<G-vec00574-002-s401><care.pflegen><en> Despite the roughness of the climate and life conditions, the villagers are working hard in their fields to preserve and take care of their small harvest.
<G-vec00574-002-s401><care.pflegen><de> Trotz der schwierigen Lebensbedingungen und des rauen Klimas arbeiten die Dorfbewohner ausdauernd daran, ihre magere Ernte zu erhalten und zu pflegen.
<G-vec00574-002-s402><care.pflegen><en> Easy to clean and care for, Excellent thermal conductivity, Very good thermal conductivity, Cut resistant, Wide pouring rim for drip-free pouring.
<G-vec00574-002-s402><care.pflegen><de> Produkteigenschaften Ausgezeichnete Wärmeleitfähigkeit, Leicht zu reinigen und zu pflegen, Sehr gute Wärmeleitfähigkeit, Schnittfest, Breiter Schüttrand für tropffreies Ausgießen.
<G-vec00574-002-s403><care.pflegen><en> With leather grease, you professionally care for wood-nailed shoes and protect the connections of the sole and upper material against penetrating water or deformation.
<G-vec00574-002-s403><care.pflegen><de> Mit Lederfett pflegen Sie holzgenagelte Schuhe fachmännisch und schützen die Verbindungen von Sohle und Obermaterial vor eindringendem Wasser oder Verformungen.
<G-vec00574-002-s404><care.pflegen><en> Reiki can be perfectly associated to other professions aiming at taking care of our body or mind, at touching or manipulating, like psychotherapists, medical doctors, nurses, physiotherapists, chiropracticiens, masseurs,..., In addition, it is very complementary to techniques like yoga, meditation, psychotherapy or other methods of personal development.
<G-vec00574-002-s404><care.pflegen><de> Reiki lässt sich perfekt assoziieren mit allen Berufen, die das Ziel haben, den Geist oder Körper zu pflegen, zu berühren oder zu manipulieren, etwa Psychotherapeuten, Ärzten, Krankenpfleger, wie Yoga, Meditation, Psychotherapie oder eine andere Methode der Persönlichkeitsentwicklung.
<G-vec00574-002-s405><care.pflegen><en> In this meditative game in the Asian style your task will be to care for the plants, water them in time and give a sufficient amount of light and air.
<G-vec00574-002-s405><care.pflegen><de> In diesem meditativen Spiel im asiatischen Stil musst du die Pflanzen pflegen, rechtzeitig gießen und ausreichend Licht und Luft spenden.
<G-vec00574-002-s406><care.pflegen><en> Some read books, others cook, but to deal with your body, take care of it, even soothes the soul.
<G-vec00574-002-s406><care.pflegen><de> Manche lesen Bücher, andere kochen, doch sich mit seinem Körper zu befassen, ihn zu pflegen, tut auch der Seele gut.
<G-vec00574-002-s407><care.pflegen><en> BICYCLE CARE WITH SYSTEM – CONTEC STAR COLLECTION Maintain, lubricate, care – the CONTEC Workshop and Care Agent Program offers products for the professional workshops and for the mechanic hobbyists.
<G-vec00574-002-s407><care.pflegen><de> FAHRRADPFLEGE MIT SYSTEM – CONTEC STAR COLLECTION Warten, schmieren, pflegen - das CONTEC Werkstatt- und Pflegemittel-Programm bietet starke Produkte für die Profiwerkstatt und für Hobbyschrauber.
<G-vec00574-002-s408><care.pflegen><en> In addition to medication, you need to do some special care for your baby's skin.
<G-vec00574-002-s408><care.pflegen><de> Zusätzlich zu den Medikamenten müssen Sie die Haut Ihres Babys besonders pflegen.
<G-vec00574-002-s409><care.pflegen><en> This means that we give you advice and at the same time, help you to understand how to take care of your teeth while reducing the need for dental treatment.
<G-vec00574-002-s409><care.pflegen><de> Wir beraten Sie, wir helfen Ihnen zu verstehen, wie Sie Ihre Zähne richtig pflegen sollten, um somit den Bedarf an dentalen Interventionen zu verringern.
<G-vec00574-002-s410><care.pflegen><en> There are hundreds of varieties of bulbs to choose from, and most of them grow well in any region if you know how to care for them properly.
<G-vec00574-002-s410><care.pflegen><de> Es stehen hunderte von Sorten von Blumenzwiebeln zur Auswahl und die meisten gedeihen in jeder Gegend, wenn du weißt, wie du sie pflegen musst.
<G-vec00574-002-s411><care.pflegen><en> But no one denies that there may be a risk to certain individual rights, which could be violated, and that we, lawyers, must defend, care for and uphold.
<G-vec00574-002-s411><care.pflegen><de> Aber niemand bestreitet, dass es eine Gefahr für bestimmte individuelle Rechte geben kann, die verletzt werden könnten, und dass wir, die Anwälte, diese verteidigen, pflegen und aufrechterhalten müssen.
<G-vec00574-002-s412><care.pflegen><en> They should be conscientious about dental care so that they will not need to have teeth extracted.
<G-vec00574-002-s412><care.pflegen><de> Sie sollten gewissenhaft ihre Zähne pflegen, damit ihnen kein Zahn gezogen werden muss.
<G-vec00574-002-s413><care.pflegen><en> This natural biological process is genetically conditioned and the only thing that can be done is to carefully care for hair and use specialist baldness pills that strengthen the bulbs and hair follicles.
<G-vec00574-002-s413><care.pflegen><de> Dieser natürliche biologische Prozess ist genetisch bedingt und das einzige, was man tun kann, ist vorsichtig zu pflegen und spezielle Haarausfall-Pillen zu verwenden, die die Zwiebeln und Haarfollikel stärken.
<G-vec00574-002-s414><care.pflegen><en> -The chair is durable and easy to care for as it is made of powder-coated steel.
<G-vec00574-002-s414><care.pflegen><de> -Stuhl aus pulverlackiertem Stahl - daher robust und einfach zu pflegen.
<G-vec00574-002-s415><care.pflegen><en> The Bielenda BioTech 7D Effective Lifting 50+ face mask will pamper and take care of your skin.
<G-vec00574-002-s415><care.pflegen><de> Die Gesichtsmaske Bielenda BioTech 7D Effective Lifting 50+ wird Ihre Haut pflegen und verwöhnen.
<G-vec00574-002-s416><care.pflegen><en> The fact that the plant is extremely easy to care for means that it fits into any busy family life.
<G-vec00574-002-s416><care.pflegen><de> Aber sie ist auch eine wahre „Alltagspflanze“, denn sie ist leicht zu pflegen.
<G-vec00574-002-s417><care.pflegen><en> Quarantallina is family managed and the young owners Mario and Serena, like taking care of this farmhouse in the details, especially in the furniture that is particularly re-searched and of very good taste.
<G-vec00574-002-s417><care.pflegen><de> Das Landgut ist ein Familienbetrieb und das junge Besitzerehepaar, Mario und Serena, pflegen dieses Bauernhaus bis ins kleinste Detail; besonders erwähnenswert ist die gepflegte und geschmackvolle Einrichtung der Innenräume.
<G-vec00574-002-s456><care.sich_kümmern><en> It can also be successfully used by healthy people who care about the proper care of the face, body, hair and nails.
<G-vec00574-002-s456><care.sich_kümmern><de> Es kann auch erfolgreich von gesunden Menschen verwendet werden, die sich um die richtige Pflege von Gesicht, Körper, Haar und Nägel kümmern.
<G-vec00574-002-s457><care.sich_kümmern><en> His wife had to shoulder the farm work and take care of his 80-year-old mother and grand-baby by herself.
<G-vec00574-002-s457><care.sich_kümmern><de> Seine Frau muss nun alleine die schwere Farmarbeit schultern und sich um ihre 80-jährige Schwiegermutter und ihr Enkelkind kümmern.
<G-vec00574-002-s458><care.sich_kümmern><en> Eva Ringler and her team were able to show that territorial males care for all clutches inside their territory, even if they had not fertilised a single clutch in the previous weeks.
<G-vec00574-002-s458><care.sich_kümmern><de> Verhaltensforscherin Eva Ringler vom Messerli Forschungsinstitut der Vetmeduni Vienna und ihr Team konnten zeigen, dass sie sich zumeist um alle Gelege in ihrem Territorium kümmern, sogar wenn sie in den Wochen zuvor kein eigenes Gelege befruchtet hatten.
<G-vec00574-002-s459><care.sich_kümmern><en> They'll drive, fly, walk, run or you to show how much they care about you.
<G-vec00574-002-s459><care.sich_kümmern><de> Sie würden zu Dir fahren, fliegen, laufen oder rennen, nur um zu zeigen, wie sehr sie sich um dich kümmern.
<G-vec00574-002-s460><care.sich_kümmern><en> If you install an electric bio toilet toilet yourself, you must take care of the ventilation device in advance.
<G-vec00574-002-s460><care.sich_kümmern><de> Wenn Sie eine elektrische Bio-Toiletten-Toilette selbst installieren, müssen Sie sich im Voraus um das Lüftungsgerät kümmern.
<G-vec00574-002-s461><care.sich_kümmern><en> So many things to take care of, so many trivial cares that kept her continually occupied.
<G-vec00574-002-s461><care.sich_kümmern><de> So viele Dinge, um die man sich kümmern muss, so viele belanglose Dinge, die sie laufend ausfüllten.
<G-vec00574-002-s462><care.sich_kümmern><en> And you would prefer to spend more time with those lovers who care most about you or are more interesting persons in general.
<G-vec00574-002-s462><care.sich_kümmern><de> Und man würde es vorziehen, mehr Zeit mit jenen Liebespartnern zu verbringen, die sich am meisten um einen kümmern, oder allgemein die interessanteren Personen sind.
<G-vec00574-002-s463><care.sich_kümmern><en> “With two square meters of skin to take care of everyday, it is not surprising that today’s consumers want to use natural and mild products to cleanse and nourish.
<G-vec00574-002-s463><care.sich_kümmern><de> „Bei zwei Quadratmetern Haut, um die man sich täglich zu kümmern hat, ist es nicht weiter verwunderlich, dass die heutigen Verbraucher natürliche und sanfte Produkte zur Reinigung und Pflege bevorzugen.
<G-vec00574-002-s464><care.sich_kümmern><en> Whether they are used as treatment tents, in which doctors and medics care for patients, as a soup kitchen or as a storage tent for equipment and provisions: all tents from Trotec can be equipped with a maintenance opening.
<G-vec00574-002-s464><care.sich_kümmern><de> Ob als Behandlungszelt, in dem sich Ärzte und Sanitäter um Patienten kümmern, als Suppenküche oder als Lagerzelt für Geräte und Verpflegung: Alle Zelte von Trotec lassen sich mit einer Versorgungsöffnung ausstatten.
<G-vec00574-002-s465><care.sich_kümmern><en> But first Birgit had to take care of another lantern, to be more exact the lighthouse of our Granny aka the silent blog reader.
<G-vec00574-002-s465><care.sich_kümmern><de> Vorher musste sich Birgit aber noch um eine andere Laterne kümmern, genauer gesagt das Lichthaus von unserer Oma alias die stille Blogleserin.
<G-vec00574-002-s466><care.sich_kümmern><en> And there is plenty to do: on the big farm there are any number of animals that have to be taken care of.
<G-vec00574-002-s466><care.sich_kümmern><de> Es ist viel zu tun: Auf dem großen Hof gibt es jede Menge Tiere, um die man sich kümmern muss.
<G-vec00574-002-s467><care.sich_kümmern><en> So, to pull from Micah Solomon in his Forbes article titled “Millennials, The Biggest Generation of Customers Ever, Don’t Care About the Internet,” it would be a really bad idea to make millennials pay for something they’ve always seen as a basic utility similar to electricity or running water.
<G-vec00574-002-s467><care.sich_kümmern><de> Also, um von Micah Solomons Forbes Artikel zu zitieren, der den Titel “Millennials, die größte Generation von Kunden, die sich nicht um das Internet kümmern,” hat, wäre es wirklich eine schlechte Idee, Millennials für etwas zahlen zu lassen, was Sie schon immer als ein grundlegendes Diestprogram angesehen haben, ähnlich wie Strom oder fließendes Wasser.
<G-vec00574-002-s468><care.sich_kümmern><en> Without him this would not have been possible. We run some special configs which had to be taken care of.
<G-vec00574-002-s468><care.sich_kümmern><de> Ohne ihn wäre das nicht möglich gewesen, da wir einiges an Spezialkonfiguration haben, um die man sich kümmern musste.
<G-vec00574-002-s469><care.sich_kümmern><en> I think that precisely here, an "integrated pastoral care" should be put into practice, for in fact not every parish priest can cope adequately with youth.
<G-vec00574-002-s469><care.sich_kümmern><de> Ich denke, gerade hier sollte eine »integrierte Seelsorge« verwirklicht werden, weil ja nicht jeder Pfarrer die Möglichkeit hat, sich genügend um die Jugend zu kümmern.
<G-vec00574-002-s470><care.sich_kümmern><en> You’ll have a large field, five different animals to take care of, nine farm products to sell and six buildings to buy.
<G-vec00574-002-s470><care.sich_kümmern><de> Sie haben ein großes Feld, fünf verschiedene Tiere, um die Sie sich kümmern, neun Bauernhof-Produkte zum Verkaufen und sechs Gebäude zum Kaufen.
<G-vec00574-002-s471><care.sich_kümmern><en> Among these guardian spirits who care for the children there may be some who have been great authors or narrators of fairy-tales in the physical world.
<G-vec00574-002-s471><care.sich_kümmern><de> Unter den Schutzgeistern, die sich um die Kinder kümmern, können Wesen sein, die einmal große Märchenerzähler und Dichter in der physischen Welt gewesen sind.
<G-vec00574-002-s472><care.sich_kümmern><en> In our team you have a brought range of job opportunities, whether you would like to work in Sales and meet the customer personally, take care about him in the Customer Service team or develop trainings for the usage of our products.
<G-vec00574-002-s472><care.sich_kümmern><de> In unserem Team erhalten Sie eine Reihe von Jobangeboten, je nachdem, ob Sie im Vertrieb arbeiten und unsere Kunden persönlich kennenlernen möchten, sich lieber im Customer Service-Team um unsere Kunden kümmern oder auch Schulungen zum Gebrauch unserer Produkte entwickeln.
<G-vec00574-002-s473><care.sich_kümmern><en> You said you would let my mom go, but you didn't!" All his relatives and friends blamed him, saying that he didn't care about his mom.
<G-vec00574-002-s473><care.sich_kümmern><de> Sie haben gesagt, Sie würden meine Mama gehen lassen, doch das haben Sie nicht getan!“ Alle sein Verwandten und Freunde beschimpften ihn, sagten, er würde sich nicht um seine Mutter kümmern.
<G-vec00574-002-s474><care.sich_kümmern><en> The "deacons" are the men appointed to "serve tables" (Acts 6:2-6), namely those who care exclusively for the business side of things.
<G-vec00574-002-s474><care.sich_kümmern><de> Die "Diener" sind die Männer, die ernannt sind, zu "Tische zu dienen" (Apg 6,2-6), nämlich diejenigen, die sich ausschließlich um die geschäftliche Seite der Dinge kümmern.
<G-vec00574-002-s494><care.sorgen><en> Omar was able to distinguish between the truth and falsehood, he felt pain when the Ummah or any member of it was hurting, and he felt joy when those under his care were content and happy worshipping their Lord.
<G-vec00574-002-s494><care.sorgen><de> Umar war in der Lage, zwischen Wahrheit und Falschheit zu differenzieren, er fühlte Schmerzen, wenn die Ummah oder eines ihrer Mitglieder litt, und er freute sich, wenn die unter seiner Sorge stehenden zufrieden und glücklich ihren Herrn anbeteten.
<G-vec00574-002-s495><care.sorgen><en> No parent is allowed to waive his/her right to parental care.
<G-vec00574-002-s495><care.sorgen><de> Kein Elternteil darf auf sein Recht auf elterliche Sorge verzichten.
<G-vec00574-002-s496><care.sorgen><en> The dismantling of the welfare state in the globalised economy leaves to women the care for life in unpaid domestic work or in badly paid waged work.
<G-vec00574-002-s496><care.sorgen><de> Der Abbau des Wohlfahrtsstaats in einer globalisierten Ökonomie überlässt die Sorge um das Leben Frauen in unbezahlter häuslicher Arbeit oder in gering bezahlter Lohnarbeit.
<G-vec00574-002-s497><care.sorgen><en> So, don't worry, for I will take care of you.... always just work at improving yourselves, so that you will resist all temptations, that you will not become heartless and put your degree of maturity at risk, and then you will also always be allowed to feel My love to an extent that you will feel My presence and be happy....
<G-vec00574-002-s497><care.sorgen><de> So sorget euch nicht, denn Ich sorge für euch.... arbeitet nur immer an euch selbst, daß ihr allen Versuchungen widersteht, daß ihr nicht in Lieblosigkeit verfallet und euren Reifegrad gefährdet, und immer werdet ihr dann auch Meine Liebe erfahren dürfen in einem Maß, daß ihr Meine Gegenwart spüret und selig seid....
<G-vec00574-002-s498><care.sorgen><en> I consider reality to be the last thing one need concern oneself about, for it is, tediously enough, always present, while more beautiful and necessary things demand our attention and care.
<G-vec00574-002-s498><care.sorgen><de> Ich finde, die Wirklichkeit ist das, worum man sich am allerwenigsten zu kümmern braucht, denn sie ist, lästig genug, ja immerzu vorhanden, während schönere und nötigere Dinge unsre Aufmerksamkeit und Sorge fordern.
<G-vec00574-002-s499><care.sorgen><en> In case of our company all of the aforementioned aspects are treated with equal care and diligence towards even the smallest details.
<G-vec00574-002-s499><care.sorgen><de> Im Falle unserer Firma werden alle oben angegebenen Aspekte gleich mit größter Sorgfalt und Sorge um die winzigsten Details behandelt.
<G-vec00574-002-s500><care.sorgen><en> We constantly come across these truths of God’s reality and holiness, his love and care for the individual soul and man’s total dependence on his sustaining and providential power, reflected in Newman’s own prayers.
<G-vec00574-002-s500><care.sorgen><de> In Newmans Gebeten begegnen wir immer wieder den Wahrheiten von Gottes Wirklichkeit und Heiligkeit, von seiner Liebe und Sorge für den einzelnen und von der völligen Abhängigkeit des Menschen von seiner Kraft und Vorsehung.
<G-vec00574-002-s501><care.sorgen><en> We also aim to care for the safety and the interests of the client, with particular emphasis on his or her expectations with regard to planned goals.
<G-vec00574-002-s501><care.sorgen><de> Unser Ziel ist auch die Sorge um die Sicherheit und die Geschäfte des Mandanten, mit besonderer Berücksichtigung seiner Erwartungen, was die geplanten Vorhaben anbetrifft.
<G-vec00574-002-s502><care.sorgen><en> We also believe that our value chain goes through thriving and loyal employees and customers, through responsibility and care for the community we are part of, to profitable and sustainable development for our company.
<G-vec00574-002-s502><care.sorgen><de> Wir sind außerdem überzeugt, dass unsere Wertschöpfungskette entlang von kreativen und loyalen Mitarbeitern und Kunden, Verantwortung und Sorge für die Gemeinschaft, der wir angehören, hin zu einer profitablen und nachhaltigen Entwicklung unseres Unternehmens verläuft.
<G-vec00574-002-s503><care.sorgen><en> A good friend left it in my care while a contractor remodeled his garage.
<G-vec00574-002-s503><care.sorgen><de> Ein guter Freund verließ es in meiner Sorge, während ein Unternehmer seine Garage umgestaltete.
<G-vec00574-002-s504><care.sorgen><en> American pit bull terrier - it's unpretentiousA dog whose care is simple.
<G-vec00574-002-s504><care.sorgen><de> Amerikanischer Pitbullterrier ist unprätentiösein Hund, dessen Sorge einfach ist.
<G-vec00574-002-s505><care.sorgen><en> When it comes to the care of our “common home”, we are living at a critical moment of history.
<G-vec00574-002-s505><care.sorgen><de> Was die Sorge für unser »gemeinsames Haus« betrifft, leben wir gerade in einem kritischen Moment der Geschichte.
<G-vec00574-002-s506><care.sorgen><en> The enemy created the sin and he takes care for him to exist.
<G-vec00574-002-s506><care.sorgen><de> Der Feind schuf die Sünde, und er nimmt Sorge für ihn zu existieren.
<G-vec00574-002-s507><care.sorgen><en> Take care of your kids.
<G-vec00574-002-s507><care.sorgen><de> Sorge für deine Kinder.
<G-vec00574-002-s508><care.sorgen><en> 7 5 Article 5 For the purposes of this Convention (a) (b) rights of custody shall include rights relating to the care of the person of the child and, in particular, the right to determine the child's place of residence; rights of access shall include the right to take a child for a limited period of time to a place other than the child's habitual residence.
<G-vec00574-002-s508><care.sorgen><de> Artikel 5 Im Sinn dieses Übereinkommens umfaßt a) das "Sorgerecht" die Sorge für die Person des Kindes und insbesondere das Recht, den Aufenthalt des Kindes zu bestimmen; b) das "Besuchsrecht" das Recht, das Kind für eine begrenzte Zeit an einen anderen Ort als seinen gewöhnlichen Aufenthaltsort zu bringen.
<G-vec00574-002-s509><care.sorgen><en> VALAMAR RIVIERA, as the data controller, takes utmost care to meet the highest organisational and technical data protection standards.
<G-vec00574-002-s509><care.sorgen><de> VALAMAR RIVIERA trägt als Verantwortlicher Sorge von den höchsten organisatorischen und technischen Standards für den Datenschutz.
<G-vec00574-002-s510><care.sorgen><en> As we continue to monitor the COVID-19 pandemic, we are taking extraordinary steps as a company to protect the health and well-being of each of our 12,000 employees worldwide, and we extend that care to each of you.
<G-vec00574-002-s510><care.sorgen><de> Während wir die COVID-19-Pandemie weiterhin überwachen, ergreifen wir als Unternehmen besondere Schritte, um die Gesundheit und das Wohlbefinden all unserer 12.000 Mitarbeiter weltweit zu schützen, und diese Sorge gilt für jeden von Ihnen gleichermaßen.
<G-vec00574-002-s511><care.sorgen><en> During the official part of the ceremony NIWA has been awarded with the Nomination for the Polish Business Leader 2009 due to its very good economic results, care for excellent quality of rendered services and engagement in social activities.
<G-vec00574-002-s511><care.sorgen><de> Während des offiziellen Teils wurde die Firma NIWA für den Wirtschaftspreis „Leader des Polnischen Business 2009“ nominiert – für Anerkennung für sehr gute Finanzergebnisse, Sorge um die perfekte Qualität der erbrachten Leitungen sowie Engagement in die soziale Tätigkeit.
<G-vec00574-002-s512><care.sorgen><en> Take particular care of your priests, your first and irreplaceable collaborators in your ministry, as well as young people.
<G-vec00574-002-s512><care.sorgen><de> Tragt insbesondere Sorge für die Priester, eure ersten und unersetzlichen Mitarbeiter im Dienst, und für die jungen Menschen.
