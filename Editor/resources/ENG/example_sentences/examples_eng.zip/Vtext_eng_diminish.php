<G-vec00463-002-s146><diminish.abnehmen><en> We in trend research might also assume, however, that the pull of this way of life could diminish in the future since meaning-oriented and socially conscious value systems might gain significance in career and economic areas.
<G-vec00463-002-s146><diminish.abnehmen><de> Man nimmt in der Trendforschung aber auch an, dass sich der Einfluss dieses Lebensstils in Zukunft abschwächen könnte, weil sinn- und gemeinschaftsorientierte Wertvorstellungen im Arbeits- und Wirtschaftsbereich zunehmend an Bedeutung gewinnen dürften.
<G-vec00463-002-s084><diminish.herabsetzen><en> Don't look for “hidden meanings” or make your own interpretations of the compliment to diminish it.
<G-vec00463-002-s084><diminish.herabsetzen><de> Such nicht nach „versteckten Bedeutungen“ und stell keine eigenen Interpretationen des Kompliments an, um es herabzusetzen.
<G-vec00463-002-s118><diminish.minimieren><en> All windings are made by phase insulation in order to provide for profitability in all applications, especially when using converters, while the stators are made of rolled plates in order to diminish magnetic losses.
<G-vec00463-002-s118><diminish.minimieren><de> Alle Spulen sind durch die Isolierung der Phasen gemacht, um die Zuverlässigkeit in allen Anwendungen, insbesondere bei der Nutzung der Konverter zu gewährleisten, während die Ständer aus Laminatplättchen sind, um die magnetischen Verluste zu minimieren.
<G-vec00463-002-s123><diminish.nachlassen><en> As a result, upstream production would gradually diminish, with excess cash being returned to investors.
<G-vec00463-002-s123><diminish.nachlassen><de> Folglich würde die vorgelagerte Produktion langsam nachlassen und überschüssige Barmittel würden an die Anleger ausgeschüttet.
<G-vec00463-002-s124><diminish.nachlassen><en> And companies should be aware of one thing: Reports and notifications of data breaches will not diminish, but rather increase.
<G-vec00463-002-s124><diminish.nachlassen><de> Und Unternehmen sollten sich über eines im Klaren sein: Die Meldungen und Anzeigen zu Datenverstößen werden nicht nachlassen, sondern eher zunehmen.
<G-vec00463-002-s125><diminish.nachlassen><en> A cyclical application is not necessary as the beneficial effects of betaine do not diminish over time and because betaine is completely safe.
<G-vec00463-002-s125><diminish.nachlassen><de> Eine zyklische Anwendung ist nicht notwendig, da die positiven Wirkungen von Betain nicht mit der Zeit nachlassen und Betain gesundheitlich völlig unbedenklich ist.
<G-vec00463-002-s126><diminish.nachlassen><en> On a sunny day, its effectiveness can diminish quickly.
<G-vec00463-002-s126><diminish.nachlassen><de> An einem sonnigen Tag kann die Wirkung schneller nachlassen.
<G-vec00463-002-s127><diminish.nachlassen><en> And then he adds amarantos, will not fade away, can’t diminish.
<G-vec00463-002-s127><diminish.nachlassen><de> Und dann fügt er noch amarantos hinzu, wird nicht verwelken, kann nicht nachlassen.
<G-vec00463-002-s149><diminish.reduzieren><en> You can enlarge or diminish the size proportionally according to your technology.
<G-vec00463-002-s149><diminish.reduzieren><de> Du kannst die Gröβe proportional nach Deiner Wahl erhöhen oder reduzieren.
<G-vec00463-002-s150><diminish.reduzieren><en> By harnessing the power of coffee compounds, it is now possible to diminish visible signs of facial-skin aging induced by solar radiation.
<G-vec00463-002-s150><diminish.reduzieren><de> Durch die Kraft der Kaffeebohne ist es jetzt möglich, sichtbare Zeichen der durch UV-Licht verursachten Hautalterung zu reduzieren.
<G-vec00463-002-s151><diminish.reduzieren><en> The number of reinsurers for such programmes will steadily diminish.
<G-vec00463-002-s151><diminish.reduzieren><de> Für diese Programme wird sich die Zahl der Rückversicherer weiter reduzieren.
<G-vec00463-002-s152><diminish.reduzieren><en> ANDIROBA OIL: Andiroba oil is rich in alpha-hydroxyl acids and fatty acids that are known to prevent and diminish all signs of aging like wrinkles, dark spots and hyperpigmentation.
<G-vec00463-002-s152><diminish.reduzieren><de> ANDIROBA-ÖL: Andiroba-Öl ist reich an Alpha-Hydroxysäuren und Fettsäuren, die dafür bekannt sind, alle Anzeichen des Alterns wie Falten, dunkle Flecken und Hyperpigmentierung zu verhindern und zu reduzieren.
<G-vec00463-002-s153><diminish.reduzieren><en> Cryotherapy ice cubes diminish puffiness and refresh the eyes.
<G-vec00463-002-s153><diminish.reduzieren><de> Die in der Kryotherapie verwendeten Eiswürfel reduzieren Schwellungen und erfrischen die Augen.
<G-vec00463-002-s154><diminish.reduzieren><en> In spite of everything, they have not been able to diminish my love for you in the slightest.
<G-vec00463-002-s154><diminish.reduzieren><de> Trotz allem haben sie es nicht einmal annähernd geschafft, meine Liebe zu Dir auch nur etwas zu reduzieren.
<G-vec00463-002-s157><diminish.reduzieren><en> Diminish the appearance of cellulite while instantly both toning and slimming the affected area with this award-winning fast-absorbing Gel.
<G-vec00463-002-s157><diminish.reduzieren><de> Reduzieren Sie das Auftreten von Cellulite mit diesem preisgekrönten schnell einziehenden Gel, während Sie sofort den betroffenen Bereich sowohl straffen als auch schlanker machen.
<G-vec00463-002-s158><diminish.reduzieren><en> When rainfalls diminish and the soil is no longer saturated, then the plant can acceletrate its growth.
<G-vec00463-002-s158><diminish.reduzieren><de> Wenn die Niederschläge reduzieren und der Boden nicht mehr gesättigt ist, dann beschleunigt die Pflanze ihr Wachstum.
<G-vec00463-002-s159><diminish.reduzieren><en> Bearberry - improves clarity and helps diminish dark spots and pigmentation.
<G-vec00463-002-s159><diminish.reduzieren><de> Bärentraube - klärt die Haut und hilft, dunkle Flecken und Pigmentierung zu reduzieren.
<G-vec00463-002-s160><diminish.reduzieren><en> No one can return to “the scene of the crime” and retract the words, repair bruised feelings, and diminish the pain that resulted from an exchange that was five, ten years ago.
<G-vec00463-002-s160><diminish.reduzieren><de> Niemand kann zurück zum “Tatort”, die Worte zurücknehmen, verletzte Gefühle reparieren und den Schmerz reduzieren, den ein kurzer Wortwechsel vor fünf oder zehn Jahren verursacht hat.
<G-vec00463-002-s162><diminish.reduzieren><en> While SQUARE ENIX encourages unique play styles, SQUARE ENIX may penalise players who hinder or diminish the quality of gameplay for others through inappropriate behaviour.
<G-vec00463-002-s162><diminish.reduzieren><de> Wenn SQUARE ENIX auch individuelle Spielstile befürwortet, kann SQUARE ENIX doch Spieler bestraften, die durch unangemessenes Verhalten die Qualität des Spiels anderer behindern oder reduzieren.
<G-vec00463-002-s165><diminish.schmälern><en> This is not to diminish the fact that heaven is a reward and that it is something we should hope for and desire.
<G-vec00463-002-s165><diminish.schmälern><de> Dies sollte nicht die Tatsache schmälern, dass der Himmel eine Belohnung ist und dass wir auf den Himmel hoffen sollen.
<G-vec00463-002-s166><diminish.schmälern><en> The Cape Schanck coastline is rugged in nature, but that won't diminish your coastal experience.
<G-vec00463-002-s166><diminish.schmälern><de> Die Cape Schanck Küste ist in der Natur zerklüftet, aber das wird Ihr Küstenerlebnis nicht schmälern.
<G-vec00463-002-s167><diminish.schmälern><en> Without wanting to diminish the suffering of the victims of 'Cologne' and similar incidents in European cities, we must also remind ourselves that there have been many cases of abuse within 'white' German society and just as many within communities with a migrant background.
<G-vec00463-002-s167><diminish.schmälern><de> Ohne das Leiden der Opfer von 'Köln' und ähnlicher Vorfälle in europäischen Städten schmälern zu wollen, dürfen wir nicht vergessen, dass es viele Missbrauchsfälle innerhalb der 'weißen' deutschen Gesellschaft und genauso wie innerhalb der Gemeinschaften mit Migrationshintergrund gibt.
<G-vec00463-002-s168><diminish.schmälern><en> Since the loss of profits due to state-induced production is spread over the society as a whole, it remains tolerable for a long time, without thereby ceasing to diminish the total profit.
<G-vec00463-002-s168><diminish.schmälern><de> Durch die sich über die ganze Gesellschaft ausdehnende Aufteilung des Profitverlustes der staatlich induzierten Produktion bleibt sie für längere Zeit tragbar, ohne daß sie damit aufhörte, den Gesamtprofit zu schmälern.
<G-vec00463-002-s169><diminish.schmälern><en> Nothing can touch the work of Christ and diminish it.
<G-vec00463-002-s169><diminish.schmälern><de> Nichts kann das Werk Christi antasten und schmälern.
<G-vec00463-002-s170><diminish.schmälern><en> Sustainable development is the one in which the needs of the present generation do not diminish the chances of future generations for meeting their own goals.
<G-vec00463-002-s170><diminish.schmälern><de> Nachhaltigkeit bedeutet, dass die Bedürfnisse der heutigen Generation nicht die Chance künftiger Generationen schmälern, ihre eigenen Bedürfnisse zu erfüllen.
<G-vec00463-002-s171><diminish.schmälern><en> Since the cycle route leads through three countries, the issue of "roaming" is even more important because it can diminish your wallet when downloading data.
<G-vec00463-002-s171><diminish.schmälern><de> Da der Bodensee-Radweg durch drei Länder führt, ist das Thema "Roaming" umso wichtiger, denn das kann den Geldbeutel beim Herunterladen von Daten schmälern.
<G-vec00463-002-s172><diminish.schmälern><en> They diminish the salvation of Christ, which He has already completed and realized in His followers.
<G-vec00463-002-s172><diminish.schmälern><de> Sie schmälern das Heil Christi, das er bereits vollendet und in seinen Nachfolgern verwirklicht hat.
<G-vec00463-002-s173><diminish.schmälern><en> However, it would be a mistake to think this would diminish the quality of their work and commitment to their clients’ success.
<G-vec00463-002-s173><diminish.schmälern><de> Es wäre jedoch ein Irrtum zu glauben, dass dies die Qualität ihrer Arbeit und das Engagement für den Erfolg ihrer Kunden schmälern würde.
<G-vec00463-002-s174><diminish.schmälern><en> The commandments are not imposed upon us from without; they do not diminish our freedom.
<G-vec00463-002-s174><diminish.schmälern><de> Die Gebote werden nicht von außen auferlegt, sie schmälern nicht unsere Freiheit.
<G-vec00463-002-s176><diminish.schwinden><en> His strength continued to diminish so we decided to go down the same day as far as base camp.
<G-vec00463-002-s176><diminish.schwinden><de> Seine Kräfte schwanden und wir beschlossen noch am selben Tag abzusteigen.
<G-vec00463-002-s190><diminish.senken><en> JAXenter: San Francisco-based company SFOX has created an algorithm to diminish Bitcoin’s volatility.
<G-vec00463-002-s190><diminish.senken><de> JAXenter: Das Unternehmen SFOX aus San Francisco hat einen Algorithmus erschaffen, um die Volatilität von Bitcoin zu senken.
<G-vec00463-002-s084><diminish.sich_herabsetzen><en> Don't look for “hidden meanings” or make your own interpretations of the compliment to diminish it.
<G-vec00463-002-s084><diminish.sich_herabsetzen><de> Such nicht nach „versteckten Bedeutungen“ und stell keine eigenen Interpretationen des Kompliments an, um es herabzusetzen.
<G-vec00463-002-s118><diminish.sich_minimieren><en> All windings are made by phase insulation in order to provide for profitability in all applications, especially when using converters, while the stators are made of rolled plates in order to diminish magnetic losses.
<G-vec00463-002-s118><diminish.sich_minimieren><de> Alle Spulen sind durch die Isolierung der Phasen gemacht, um die Zuverlässigkeit in allen Anwendungen, insbesondere bei der Nutzung der Konverter zu gewährleisten, während die Ständer aus Laminatplättchen sind, um die magnetischen Verluste zu minimieren.
<G-vec00463-002-s149><diminish.sich_reduzieren><en> You can enlarge or diminish the size proportionally according to your technology.
<G-vec00463-002-s149><diminish.sich_reduzieren><de> Du kannst die Gröβe proportional nach Deiner Wahl erhöhen oder reduzieren.
<G-vec00463-002-s150><diminish.sich_reduzieren><en> By harnessing the power of coffee compounds, it is now possible to diminish visible signs of facial-skin aging induced by solar radiation.
<G-vec00463-002-s150><diminish.sich_reduzieren><de> Durch die Kraft der Kaffeebohne ist es jetzt möglich, sichtbare Zeichen der durch UV-Licht verursachten Hautalterung zu reduzieren.
<G-vec00463-002-s151><diminish.sich_reduzieren><en> The number of reinsurers for such programmes will steadily diminish.
<G-vec00463-002-s151><diminish.sich_reduzieren><de> Für diese Programme wird sich die Zahl der Rückversicherer weiter reduzieren.
<G-vec00463-002-s152><diminish.sich_reduzieren><en> ANDIROBA OIL: Andiroba oil is rich in alpha-hydroxyl acids and fatty acids that are known to prevent and diminish all signs of aging like wrinkles, dark spots and hyperpigmentation.
<G-vec00463-002-s152><diminish.sich_reduzieren><de> ANDIROBA-ÖL: Andiroba-Öl ist reich an Alpha-Hydroxysäuren und Fettsäuren, die dafür bekannt sind, alle Anzeichen des Alterns wie Falten, dunkle Flecken und Hyperpigmentierung zu verhindern und zu reduzieren.
<G-vec00463-002-s153><diminish.sich_reduzieren><en> Cryotherapy ice cubes diminish puffiness and refresh the eyes.
<G-vec00463-002-s153><diminish.sich_reduzieren><de> Die in der Kryotherapie verwendeten Eiswürfel reduzieren Schwellungen und erfrischen die Augen.
<G-vec00463-002-s154><diminish.sich_reduzieren><en> In spite of everything, they have not been able to diminish my love for you in the slightest.
<G-vec00463-002-s154><diminish.sich_reduzieren><de> Trotz allem haben sie es nicht einmal annähernd geschafft, meine Liebe zu Dir auch nur etwas zu reduzieren.
<G-vec00463-002-s157><diminish.sich_reduzieren><en> Diminish the appearance of cellulite while instantly both toning and slimming the affected area with this award-winning fast-absorbing Gel.
<G-vec00463-002-s157><diminish.sich_reduzieren><de> Reduzieren Sie das Auftreten von Cellulite mit diesem preisgekrönten schnell einziehenden Gel, während Sie sofort den betroffenen Bereich sowohl straffen als auch schlanker machen.
<G-vec00463-002-s158><diminish.sich_reduzieren><en> When rainfalls diminish and the soil is no longer saturated, then the plant can acceletrate its growth.
<G-vec00463-002-s158><diminish.sich_reduzieren><de> Wenn die Niederschläge reduzieren und der Boden nicht mehr gesättigt ist, dann beschleunigt die Pflanze ihr Wachstum.
<G-vec00463-002-s159><diminish.sich_reduzieren><en> Bearberry - improves clarity and helps diminish dark spots and pigmentation.
<G-vec00463-002-s159><diminish.sich_reduzieren><de> Bärentraube - klärt die Haut und hilft, dunkle Flecken und Pigmentierung zu reduzieren.
<G-vec00463-002-s160><diminish.sich_reduzieren><en> No one can return to “the scene of the crime” and retract the words, repair bruised feelings, and diminish the pain that resulted from an exchange that was five, ten years ago.
<G-vec00463-002-s160><diminish.sich_reduzieren><de> Niemand kann zurück zum “Tatort”, die Worte zurücknehmen, verletzte Gefühle reparieren und den Schmerz reduzieren, den ein kurzer Wortwechsel vor fünf oder zehn Jahren verursacht hat.
<G-vec00463-002-s162><diminish.sich_reduzieren><en> While SQUARE ENIX encourages unique play styles, SQUARE ENIX may penalise players who hinder or diminish the quality of gameplay for others through inappropriate behaviour.
<G-vec00463-002-s162><diminish.sich_reduzieren><de> Wenn SQUARE ENIX auch individuelle Spielstile befürwortet, kann SQUARE ENIX doch Spieler bestraften, die durch unangemessenes Verhalten die Qualität des Spiels anderer behindern oder reduzieren.
<G-vec00463-002-s165><diminish.sich_schmälern><en> This is not to diminish the fact that heaven is a reward and that it is something we should hope for and desire.
<G-vec00463-002-s165><diminish.sich_schmälern><de> Dies sollte nicht die Tatsache schmälern, dass der Himmel eine Belohnung ist und dass wir auf den Himmel hoffen sollen.
<G-vec00463-002-s166><diminish.sich_schmälern><en> The Cape Schanck coastline is rugged in nature, but that won't diminish your coastal experience.
<G-vec00463-002-s166><diminish.sich_schmälern><de> Die Cape Schanck Küste ist in der Natur zerklüftet, aber das wird Ihr Küstenerlebnis nicht schmälern.
<G-vec00463-002-s167><diminish.sich_schmälern><en> Without wanting to diminish the suffering of the victims of 'Cologne' and similar incidents in European cities, we must also remind ourselves that there have been many cases of abuse within 'white' German society and just as many within communities with a migrant background.
<G-vec00463-002-s167><diminish.sich_schmälern><de> Ohne das Leiden der Opfer von 'Köln' und ähnlicher Vorfälle in europäischen Städten schmälern zu wollen, dürfen wir nicht vergessen, dass es viele Missbrauchsfälle innerhalb der 'weißen' deutschen Gesellschaft und genauso wie innerhalb der Gemeinschaften mit Migrationshintergrund gibt.
<G-vec00463-002-s168><diminish.sich_schmälern><en> Since the loss of profits due to state-induced production is spread over the society as a whole, it remains tolerable for a long time, without thereby ceasing to diminish the total profit.
<G-vec00463-002-s168><diminish.sich_schmälern><de> Durch die sich über die ganze Gesellschaft ausdehnende Aufteilung des Profitverlustes der staatlich induzierten Produktion bleibt sie für längere Zeit tragbar, ohne daß sie damit aufhörte, den Gesamtprofit zu schmälern.
<G-vec00463-002-s169><diminish.sich_schmälern><en> Nothing can touch the work of Christ and diminish it.
<G-vec00463-002-s169><diminish.sich_schmälern><de> Nichts kann das Werk Christi antasten und schmälern.
<G-vec00463-002-s170><diminish.sich_schmälern><en> Sustainable development is the one in which the needs of the present generation do not diminish the chances of future generations for meeting their own goals.
<G-vec00463-002-s170><diminish.sich_schmälern><de> Nachhaltigkeit bedeutet, dass die Bedürfnisse der heutigen Generation nicht die Chance künftiger Generationen schmälern, ihre eigenen Bedürfnisse zu erfüllen.
<G-vec00463-002-s171><diminish.sich_schmälern><en> Since the cycle route leads through three countries, the issue of "roaming" is even more important because it can diminish your wallet when downloading data.
<G-vec00463-002-s171><diminish.sich_schmälern><de> Da der Bodensee-Radweg durch drei Länder führt, ist das Thema "Roaming" umso wichtiger, denn das kann den Geldbeutel beim Herunterladen von Daten schmälern.
<G-vec00463-002-s172><diminish.sich_schmälern><en> They diminish the salvation of Christ, which He has already completed and realized in His followers.
<G-vec00463-002-s172><diminish.sich_schmälern><de> Sie schmälern das Heil Christi, das er bereits vollendet und in seinen Nachfolgern verwirklicht hat.
<G-vec00463-002-s173><diminish.sich_schmälern><en> However, it would be a mistake to think this would diminish the quality of their work and commitment to their clients’ success.
<G-vec00463-002-s173><diminish.sich_schmälern><de> Es wäre jedoch ein Irrtum zu glauben, dass dies die Qualität ihrer Arbeit und das Engagement für den Erfolg ihrer Kunden schmälern würde.
<G-vec00463-002-s174><diminish.sich_schmälern><en> The commandments are not imposed upon us from without; they do not diminish our freedom.
<G-vec00463-002-s174><diminish.sich_schmälern><de> Die Gebote werden nicht von außen auferlegt, sie schmälern nicht unsere Freiheit.
<G-vec00463-002-s190><diminish.sich_senken><en> JAXenter: San Francisco-based company SFOX has created an algorithm to diminish Bitcoin’s volatility.
<G-vec00463-002-s190><diminish.sich_senken><de> JAXenter: Das Unternehmen SFOX aus San Francisco hat einen Algorithmus erschaffen, um die Volatilität von Bitcoin zu senken.
<G-vec00463-002-s201><diminish.sich_verkleinern><en> Only our physical limits diminish our ability to recognize it.
<G-vec00463-002-s201><diminish.sich_verkleinern><de> Nur unsere physischen Begrenzungen verkleinern unsere Fähigkeit sie zu erkennen.
<G-vec00463-002-s202><diminish.sich_verkürzen><en> 10 If he take him another [wife]; her food, her raiment, and her duty of marriage, shall he not diminish.
<G-vec00463-002-s202><diminish.sich_verkürzen><de> 10 Falls er sich [noch] eine andere nimmt, soll er ihre Nahrung, ihre Kleidung und den ehelichen Verkehr mit ihr nicht verkürzen.
<G-vec00463-002-s223><diminish.sich_vermindern><en> For their mechanical properties such as load-bearing capacity and impact resistance also diminish with increasing age – particularly if they absorb moisture.
<G-vec00463-002-s223><diminish.sich_vermindern><de> Auch die mechanischen Eigenschaften wie Tragfähig- und Schlagzähigkeit vermindern sich im Laufe der Zeit – vor allem durch die Aufnahme von Feuchtigkeit.
<G-vec00463-002-s269><diminish.sich_verringern><en> When Czechoslovakia was founded in 1918, its backwardness compared to highly industrialised Bohemia was dramatic, and did not diminish in the following years.
<G-vec00463-002-s269><diminish.sich_verringern><de> Bei der Gründung der Tschechoslowakei 1918 bestand ein großer Abstand zum hochindustrialisierten Böhmen, der sich in den Folgejahren nicht verringerte.
<G-vec00463-002-s272><diminish.sich_verschlechtern><en> These inflammatory responses may diminish the efficiency and safety of such techniques.
<G-vec00463-002-s272><diminish.sich_verschlechtern><de> Diese Entzündungsreaktionen könnten die Effizienz und Sicherheit solcher Ansätze verschlechtern.
<G-vec00463-002-s201><diminish.verkleinern><en> Only our physical limits diminish our ability to recognize it.
<G-vec00463-002-s201><diminish.verkleinern><de> Nur unsere physischen Begrenzungen verkleinern unsere Fähigkeit sie zu erkennen.
<G-vec00463-002-s202><diminish.verkürzen><en> 10 If he take him another [wife]; her food, her raiment, and her duty of marriage, shall he not diminish.
<G-vec00463-002-s202><diminish.verkürzen><de> 10 Falls er sich [noch] eine andere nimmt, soll er ihre Nahrung, ihre Kleidung und den ehelichen Verkehr mit ihr nicht verkürzen.
<G-vec00463-002-s223><diminish.vermindern><en> For their mechanical properties such as load-bearing capacity and impact resistance also diminish with increasing age – particularly if they absorb moisture.
<G-vec00463-002-s223><diminish.vermindern><de> Auch die mechanischen Eigenschaften wie Tragfähig- und Schlagzähigkeit vermindern sich im Laufe der Zeit – vor allem durch die Aufnahme von Feuchtigkeit.
<G-vec00463-002-s233><diminish.verringern><en> Its foaming formula is infused with exfoliating broadleaf kelp to gently break down dirt, diminish excess oil and transform dull skin, revealing a brighter, healthy-looking complexion.
<G-vec00463-002-s233><diminish.verringern><de> Ihre schäumende Formel wurde mit peelendem Seetang angereichert, um Schmutz sanft zu entfernen, überschüssiges Fett zu verringern und matte Haut zu verwandeln, damit ein strahlender, gesund aussehender Teint enthüllt wird.
<G-vec00463-002-s234><diminish.verringern><en> These redirects significantly diminish the web browsing experience.
<G-vec00463-002-s234><diminish.verringern><de> Diese Weiterleitungen verringern erheblich die Surferfahrung.
<G-vec00463-002-s235><diminish.verringern><en> A balance has to be created in order to diminish this great guilt, and precisely this balance is guaranteed by the Judgment.... by placing the soul, having become sinful, into a situation where it has to reduce this guilt, since it had not voluntarily accepted the gift of atonement
<G-vec00463-002-s235><diminish.verringern><de> Es muss ein Ausgleich geschaffen werden, um diese große Schuld zu verringern, und dieser Ausgleich ist eben gewährleistet durch das Gericht.... durch das Versetzen des Schuldig-Gewordenen in den Zustand, wo es wieder die Schuld abtragen muss, da es freiwillig das Geschenk der Entsühnung nicht annahm....
<G-vec00463-002-s236><diminish.verringern><en> Now I take Agnihotra ash for a sister that began to lose or to diminish her vision four years ago.
<G-vec00463-002-s236><diminish.verringern><de> Jetzt nehme ich auch Agnihotra Asche für eine ander Ordensschwester mit, die vor 4 Jahrne anfing, ihre Sicht zu verlieren und zu verringern.
<G-vec00463-002-s237><diminish.verringern><en> - Measures must be put in place to prevent and diminish the negative effects of migration on family life.
<G-vec00463-002-s237><diminish.verringern><de> - es müssen Maßnahmen ergriffen werden, die den negativen Auswirkungen der Migration auf das Familienleben vorbeugen und sie verringern.
<G-vec00463-002-s238><diminish.verringern><en> As our world continues to grow, we know the threat of infection is something we need to diminish each and every day.
<G-vec00463-002-s238><diminish.verringern><de> Da unsere Welt immer weiter anwächst, wissen wir, dass wir das Infektionsrisiko jeden Tag verringern müssen.
<G-vec00463-002-s239><diminish.verringern><en> Endorphins act as analgesics, which means they diminish the perception of pain.
<G-vec00463-002-s239><diminish.verringern><de> Endorphine wirken analgetisch, das heißt sie verringern die Schmerzwahrnehmung.
<G-vec00463-002-s240><diminish.verringern><en> Periods of drought diminish the already poor harvests. One out of every seven children is malnourished.
<G-vec00463-002-s240><diminish.verringern><de> Dürreperioden verringern die ohnehin schon geringen Ernten, jedes dritte Kind ist unterernährt.
<G-vec00463-002-s241><diminish.verringern><en> Taking glutamine with acidic juices (like orange or grapefruit juice) or hot liquids will degrade the glutamate and therefore diminish any benefits.
<G-vec00463-002-s241><diminish.verringern><de> Die Einnahme von Glutamin mit säurehaltigen Säften wird das Glutamat zersetzen und den Nutzen verringern.
<G-vec00463-002-s242><diminish.verringern><en> But, even in this repose of all thought movements and all movements of feeling, one sees, when one looks more closely at it, that the mind-substance is still in a constant state of very subtle formless but potentially formative vibration – not at first easily observable, but afterwards quite evident – and that state of constant vibration may be as harmful to the exact reflection or reception of the descending Truth as any formed thought movement or emotional movement; for these vibrations are the source of a mentalisation which can diminish or distort the authenticity of the higher Truth or break it up into mental refractions.
<G-vec00463-002-s242><diminish.verringern><de> Doch selbst in dieser Ruhe aller Gedanken– oder Gefühlsregungen erkennt man bei näherer Betrachtung, dass die Substanz des Mentals sich in einem andauernden Zustand sehr feiner Schwingung befindet, die zunächst nicht gleich erkennbar, doch dann ganz offensichtlich ist – und dieser Zustand fortwährender Schwingung kann einer genauen Widerspiegelung oder dem genauen Empfang der herabkommenden Wahrheit so schädlich sein wie jede andere mehrgeformte Gedankenregung; denn er ist die Quelle einer Mentalisierung, welche die Echtheit der höheren Wahrheit verringern oder entstellen oder in mentale Brechungen auflösen kann.
<G-vec00463-002-s243><diminish.verringern><en> By performing these actions, PUAs significantly diminish the browsing experience and pose a significant threat to your privacy/computer safety.
<G-vec00463-002-s243><diminish.verringern><de> Durch die Durchführung dieser Aktionen verringern PUAs das Surfen im Internet erheblich und stellen eine große Bedrohung für die Privatsphäre und Computersicherheit der Benutzer dar.
<G-vec00463-002-s244><diminish.verringern><en> It is possible to diminish standard deviation when you move from a single-asset portfolio to a two-asset portfolio in 3 out of the 6 possible two-asset portfolios; from a two-asset portfolio to a three-asset portfolio – in respect to 3 out of 6 two-asset portfolios, and in a four-asset portfolio – in respect to 1 of the 4 three-asset portfolios.
<G-vec00463-002-s244><diminish.verringern><de> Es ist möglich, die Standardabweichung zu verringern, wenn Sie bei 3 der 6 möglichen Portfolios mit zwei Vermögenswerten von einem Portfolio mit einem Vermögenswert zu einem Portfolio mit zwei Vermögenswerten wechseln; von einem Portfolio mit zwei Vermögenswerten zu einem Portfolio mit drei Vermögenswerten - in Bezug auf 3 von 6 Portfolios mit zwei Vermögenswerten und bei einem Portfolio mit vier Vermögenswerten - in Bezug auf eines der vier Portfolios mit drei Vermögenswerten.
<G-vec00463-002-s245><diminish.verringern><en> Mary Cohr ☆ This rich and highly absorbent Mary Cohr body care product restores the skin's firmness and softness, which diminish due to passing time and fatigue.
<G-vec00463-002-s245><diminish.verringern><de> Instock Dieses reiche und hoch saugfähige Mary Cohr Körperpflegeprodukt stellt die Festigkeit und Weichheit der Haut wieder her, die sich durch Zeit und Müdigkeit verringern.
<G-vec00463-002-s246><diminish.verringern><en> Dear ones, it's almost like it was rebooted and the negative and dramatic things that it remembered before, and the places that remembered them, will start to diminish and disappear.
<G-vec00463-002-s246><diminish.verringern><de> Meine Lieben, es ist fast so als würde es neu gebootet und die negativen und dramatischen Dinge an die es sich zuvor erinnert hat, fangen an sich zu verringern und zu verschwinden.
<G-vec00463-002-s247><diminish.verringern><en> In fact, rather than diminish with the passage of years, the atrocity propaganda concerning the German occupation, and in particular their treatment of the Jews, has done nothing but increase its virulence, and elaborate its catalogue of horrors.
<G-vec00463-002-s247><diminish.verringern><de> In Wirklichkeit hat die Greuelpropaganda, die deutsche Besatzung und die Behandlung der Juden betreffend, anstatt sich im Laufe der Jahre zu verringern, an Giftigkeit und Vielgestaltigkeit ihrer Kataloge des Schreckens zugenommen.
<G-vec00463-002-s248><diminish.verringern><en> We want to see a clear action plan on ways to diminish the social exclusion of Roma people while...
<G-vec00463-002-s248><diminish.verringern><de> Wir wollen einen klaren Aktionsplan für Möglichkeiten, um die gesellschaftliche Ausgrenzung von Roma zu verringern.
<G-vec00463-002-s249><diminish.verringern><en> The entry permits last one month and are only granted to those Bushmen with relatives in the reserve – a policy clearly designed to slowly diminish the number of Bushmen able to access their land.
<G-vec00463-002-s249><diminish.verringern><de> Die Genehmigungen, das CKGR zu betreten, gelten jeweils einen Monat und werden nur an Buschleute vergeben, die Verwandte innerhalb des Reservates haben – eine Praktik, die eindeutig dazu dient, die Anzahl der Buschleute, die ihr Land betreten können, langsam zu verringern.
<G-vec00463-002-s250><diminish.verringern><en> Gently dab around the eye area and massage in a circular counter clockwise motion. clinically proven to smooth skin's surface and diminish fine lines.
<G-vec00463-002-s250><diminish.verringern><de> Sanft Klecks in einer kreisförmigen Bewegung gegen den Uhrzeigersinn um die Augenpartie und Hautoberfläche zu glätten und feine Linien zu verringern.
<G-vec00463-002-s251><diminish.verringern><en> The Governor of the PBoC said this spring that while virtual currencies are “technologically inevitable” and will ultimately diminish cash circulation, the PBoC intends to control the “unpredictable effects” posed by decentralized forms of crypto and certain applications of blockchain. #Bitcoin News #China
<G-vec00463-002-s251><diminish.verringern><de> In Frühling gab der Gouverneur der PBoC zu Protokoll, dass sie davon ausgehen, dass virtuelle Währungen "technologisch unvermeidbar" sind und den Bargeldumlauf letztendlich verringern werden, weswegen die PBoC beabsichtigt, die "unvorhersehbaren Auswirkungen" dezentraler Verschlüsselungsformen und bestimmter Anwendungen von Blockchain zu kontrollieren.
<G-vec00463-002-s272><diminish.verschlechtern><en> These inflammatory responses may diminish the efficiency and safety of such techniques.
<G-vec00463-002-s272><diminish.verschlechtern><de> Diese Entzündungsreaktionen könnten die Effizienz und Sicherheit solcher Ansätze verschlechtern.
<G-vec00463-002-s285><diminish.werden><en> Supply sources become more distant from their bases of demand, fuel costs mount and opportunities for labour arbitrage diminish.
<G-vec00463-002-s285><diminish.werden><de> Lieferanten sind weiter entfernt von der Nachfrage, Benzinkosten steigen und die Möglichkeiten für Lohnkostenarbitrage werden geringer.
<G-vec00463-002-s289><diminish.zurückgehen><en> The believer, however, will also find help in every adversity, it just will not be externally visible, but God's strength will inundate him, he will also master every situation in life and always remain in contact with God, his faith will deepen, his love for matter diminish, and this means far greater progress than the increased earthly wealth of the former.
<G-vec00463-002-s289><diminish.zurückgehen><de> Der Gläubige aber wird auch Hilfe finden in jeder Not, nur nicht nach außen ersichtlich, sondern die Kraft Gottes wird ihn überfluten, er wird auch jeder Lebenslage Herr werden und stets mit Gott in Verbindung bleiben, sein Glaube wird vertieft werden, die Liebe zur Materie zurückgehen, und es ist dies ein weit größerer Fortschritt als der vermehrte irdische Besitz des ersteren.
