<G-vec00418-001-s038><drop.abfallen><en> If you find that your impressions and lead quality drop significantly, over a three to four-day period (or however long it takes for someone to go through your funnel), gradually increase your bid.
<G-vec00418-001-s038><drop.abfallen><de> Wenn Du feststellst, das Deine Impressionen und die Lead-Qualität im Zeitraum von drei bis vier Tagen (oder wie lang es auch immer dauert, jemanden durch Deinen Trichter zu leiten) entscheidend abfallen, dann erhöh Dein Gebot schrittweise.
<G-vec00418-001-s039><drop.abfallen><en> One speaks of the diffuse alopecia (diffuse alopecia) if the hairs drop from the whole head.
<G-vec00418-001-s039><drop.abfallen><de> Vom diffusen Haarausfall (diffuse Alopezie) spricht man, wenn die Haare vom gesamten Kopf abfallen.
<G-vec00418-001-s040><drop.abfallen><en> Super-cold chemicals, such as liquid nitrogen, are put on warts in a collection of therapies and they eventually drop off.
<G-vec00418-001-s040><drop.abfallen><de> Super-Kalt Chemikalien, wie flüssiger Stickstoff, werden auf Warzen in einer Sammlung von Therapien setzen und sie abfallen schließlich.
<G-vec00418-001-s041><drop.abfallen><en> The name ‘red beach’ comes from the unique red lava cliffs which drop down to the beach which is comprised of red and black pebbles and coarse sand.
<G-vec00418-001-s041><drop.abfallen><de> Der Name, „Roter Strand“ kommt von den einmaligen roten Lavaklippen, die auf den Strand abfallen, der mit rotem und schwarzem Kiesel und grobem Sand übersät ist.
<G-vec00418-001-s042><drop.abfallen><en> Sailing back to Athens from Aegina at the end of your sailing holiday in Greece, you will see the pistachio orchards along the west and north coast of the island, where cliffs drop steeply down to the sea.
<G-vec00418-001-s042><drop.abfallen><de> Wenn Sie dann zurück nach Athen segeln, werden Sie die Pistazienhaine an der West- und Nordküste von Aegina sehen, wo die Klippen steil ins Meer abfallen.
<G-vec00418-001-s043><drop.abfallen><en> Drafts and temperature extremes can cause the flower buds to drop from the plant before they have a chance to open.
<G-vec00418-001-s043><drop.abfallen><de> Zugluft und Temperaturextreme können bewirken, dass die Blütenknospen abfallen, noch bevor sie sich öffnen konnten.
<G-vec00418-001-s044><drop.abfallen><en> Even if we struggle to keep it, it will nevertheless drop off from us and disperse its elements.
<G-vec00418-001-s044><drop.abfallen><de> Selbst wenn wir darum kämpfen, ihn zu behalten, wird er dennoch wieder von uns abfallen und seine Elemente zerstreuen.
<G-vec00418-001-s045><drop.abfallen><en> "Here are some interesting facts that will show you why you want to get as close to the bulb as you can - at 2"" from the bulb the foot candles drop to 700, 4""=500, 8""=320, 16""=200."
<G-vec00418-001-s045><drop.abfallen><de> "Sind hier einige interessante Tatsachen, die dir zeigen, warum du wie nah an der Birne erhalten möchtest, wie du kannst - bei 2“ von der Birne, welche die Fußkerzen auf 700 abfallen, 4 "" =500, 8 "" =320, 16 "" =200."
<G-vec00418-001-s046><drop.abfallen><en> The long reddish orange, tubular flowers are borne in upright racemes at the onset of summer each year, just as the leaves turn yellow and drop off.
<G-vec00418-001-s046><drop.abfallen><de> Die langen rötlich orangefarbenen, röhrenförmigen Blüten erscheinen zu Beginn des Sommers jedes Jahr, gerade dann wenn die Blätter gelb werden und abfallen.
<G-vec00418-001-s047><drop.abfallen><en> The low iron glass is lowest self-explosion, with highly light transmittance, good transparent,is very safety and durable, cause of tempered glass after broken is been small particle, is not harmful and the PVB/SGP film will laminated together the small particle, is not drop off.
<G-vec00418-001-s047><drop.abfallen><de> Das niedrige Eisenglas ist niedrigste Selbstexplosion, mit hoher Lichtdurchlässigkeit, gut transparent, ist sehr sicher und haltbar, Ursache von gehärtetes Glas Nach dem Bruch ist kleine Partikel, ist nicht schädlich und der PVB / SGP-Film wird zusammen laminiert das kleine Teilchen, ist nicht abfallen.
<G-vec00418-001-s048><drop.abfallen><en> The intensity and density will drop off, and you will be weightless, and you will reverberate to high music that is ever-present now but which you do not presently hear.
<G-vec00418-001-s048><drop.abfallen><de> Die Intensität und Dichte wird abfallen, und ihr werdet gewichtslos, und ihr werdet zu hoher Musik widerhallen, die jetzt immerzu präsent ist, die ihr aber zur Zeit nicht hört.
<G-vec00418-001-s049><drop.abfallen><en> As soon as the speed drop off, the front of the pedal will reduce the angle of the lift.
<G-vec00418-001-s049><drop.abfallen><de> Sobald die Geschwindigkeit abfallen, verringert die Vorderseite des Pedals den Winkel des Aufzugs.
<G-vec00418-001-s050><drop.abfallen><en> No outlet of the great vale was to be seen from this point, for the gorge winds about among the crags which rise high above and drop far below to the base of the rocky glen.
<G-vec00418-001-s050><drop.abfallen><de> Kein Anschluß des großen vale sollte von diesem Punkt, für travel Schluchtwinde ungefähr unter den Felsspitzen gesehen werden, travel stark oben steigen und weit unten auf die Unterseite des felsigen Glen abfallen.
<G-vec00418-001-s051><drop.abfallen><en> Of course, when Bergeron and Marchand are apart, their numbers drop off considerably, though Bergeron’s less so because he is amazing.
<G-vec00418-001-s051><drop.abfallen><de> Natürlich, wenn Bergeron und Marchand sind auseinander, ihre Zahl deutlich abfallen, obwohl Bergeron ist weniger, weil er ist erstaunlich.
<G-vec00418-001-s052><drop.abfallen><en> This prevents a drop in the battery voltage, which may cause a misdiagnosis or abortion of a software update.
<G-vec00418-001-s052><drop.abfallen><de> Ein Abfallen der Batteriespannung, das Fehldiagnosen verursachen kann oder zum Abbruch eines Software-Updates führt, wird somit vermieden.
<G-vec00418-001-s053><drop.abfallen><en> These other buds over here will drop and not begin growing any fruit.
<G-vec00418-001-s053><drop.abfallen><de> Diese anderen Knospen hier werden keine Früchte ansetzen und abfallen.
<G-vec00418-001-s054><drop.abfallen><en> However, this can sometimes drop to as low as 13 feet (4 m) after heavy rains.
<G-vec00418-001-s054><drop.abfallen><de> Allerdings kann die Sicht unter Wasser nach heftigen Regenfällen auch manchmal auf 4 Meter abfallen.
<G-vec00418-001-s055><drop.abfallen><en> All the dirt may drop off, yet the lie lies within.
<G-vec00418-001-s055><drop.abfallen><de> All der Schmutz mag abfallen, aber die Lüge liegt darunter.
<G-vec00418-001-s056><drop.abfallen><en> Harvesting therefore is recommended to be done in late fall, shortly before the leaves drop.
<G-vec00418-001-s056><drop.abfallen><de> Eine Ernte wird daher im späten Herbst empfohlen, kurz bevor die Blätter abfallen.
<G-vec00418-001-s057><drop.ablegen><en> From their desktops, employees just drag and drop the information to be displayed on the collaborative video wall to share simultaneously with other operators.
<G-vec00418-001-s057><drop.ablegen><de> Von ihren Desktops aus können Mitarbeiter die Informationen, die auf der gemeinsamen Videowand angezeigt werden sollen, einfach ziehen und ablegen, um sie mit anderen Bedienern zu teilen.
<G-vec00418-001-s058><drop.ablegen><en> To replace it with a new image, load or drag and drop a picture file onto the area on the left side.
<G-vec00418-001-s058><drop.ablegen><de> Ersetzen Sie es durch ein neues Bild, indem Sie eine Bilddatei in den Bereich auf der linken Seite laden oder ziehen und ablegen.
<G-vec00418-001-s059><drop.ablegen><en> Definition [top] The drop folder is a special folder in your private Documents, where the members of the groups you belong to may drop Documents.
<G-vec00418-001-s059><drop.ablegen><de> Definition [top] Der Eingangsordner ist ein spezieller Ordner in Ihren persönlichen Dokumenten, in dem die Mitglieder von Gruppen, denen Sie angehören, Dokumente ablegen können.
<G-vec00418-001-s060><drop.ablegen><en> Events are created where you drop the files (and the media files are added to the Project Media window if you're using the Explorer).
<G-vec00418-001-s060><drop.ablegen><de> Beim Ablegen der Dateien werden Events erstellt (und die Mediendateien im Fenster Projektmedien hinzugefügt, wenn Sie den Explorer verwenden).
<G-vec00418-001-s061><drop.ablegen><en> It isn't only smart to keep the smartphone supported just in case you drop it within the toilet, but additionally whether it will get stolen and you've got to remotely wipe it clean.
<G-vec00418-001-s061><drop.ablegen><de> Es ist nicht nur klug, um das Smartphone nur für den Fall in die Toilette zu halten unterstützt Sie es ablegen, sondern zusätzlich, ob es gestohlen und Sie haben aus der Ferne abwischen.
<G-vec00418-001-s062><drop.ablegen><en> The Nuxeo Platform-based CNG application enables journalists to compile news stories using text, photos and/or videos by simply using drag and drop.
<G-vec00418-001-s062><drop.ablegen><de> ie auf der Nuxeo Platform basierte CNG-Anwendung ermöglicht Journalisten die Zusammenstellung von Artikeln mit Texten, Fotos und Videos durch einfaches Ziehen und Ablegen.
<G-vec00418-001-s063><drop.ablegen><en> To save them within SendBlaster, simply drag and drop the program icon to the Shortcuts section.
<G-vec00418-001-s063><drop.ablegen><de> Speichern Sie diese innerhalb SendBlaster, indem Sie das Programmsymbol auf den Abschnitt Verknüpfungen ziehen und ablegen.
<G-vec00418-001-s064><drop.ablegen><en> That ́s better, bring it back and drop it.
<G-vec00418-001-s064><drop.ablegen><de> So ist es besser, zurück bringen und ablegen.
<G-vec00418-001-s065><drop.ablegen><en> If you like it a bit more contemplative, head to Gargnano and treat yourself to an espresso or capucino on the promenade next to the harbor, watching the cruise ships take off and drop off.
<G-vec00418-001-s065><drop.ablegen><de> Wenn Sie es einmal etwas beschaulicher mögen, fahren Sie nach Gargnano und gönnen Sie sich an der Promenade neben dem Hafen einen Espresso oder Capucino und beobachten dabei, wie die Rundfahrtschiffe an- und ablegen.
<G-vec00418-001-s066><drop.ablegen><en> You can also use the arrow keys to move the token left or right, and the down or space key to drop a token.
<G-vec00418-001-s066><drop.ablegen><de> Du kannst auch die Pfeiltasten „Rechts“ und „Links“ zum Bewegen und die Leertaste oder die Pfeiltaste „Runter“ zum Ablegen eines Spielsteines benutzen.
<G-vec00418-001-s067><drop.ablegen><en> When you show content in one language only, you can move pages to another location in the page tree structure by drag and drop or copy and paste, but it is not possible to sort pages.
<G-vec00418-001-s067><drop.ablegen><de> Hinweis: Werden Inhalte in nur einer Sprache angezeigt, können Sie Seiten an einen anderen Ort in der Seitenbaumstruktur verschieben, indem Sie sie ziehen und ablegen oder kopieren und einfügen, aber diese Seiten können nicht sortiert werden.
<G-vec00418-001-s068><drop.ablegen><en> Even then the qualities continue to work and conduct the body functions until we drop off our vehicle.
<G-vec00418-001-s068><drop.ablegen><de> Selbst dann wirken die Qualitäten weiter und leiten die Körperfunktionen, bis wir unseren Träger ablegen.
<G-vec00418-001-s069><drop.ablegen><en> Once your brainstorming phase is complete, simply drag and drop the branches of your Mind Map to transform it into the necessary Work Breakdown Structure.
<G-vec00418-001-s069><drop.ablegen><de> Ist die Brainstormingphase abgeschlossen, ordnen Sie die Zweige Ihrer Mind Map einfach per Ziehen und Ablegen, um die gewünschte Projektstruktur zu erhalten.
<G-vec00418-001-s070><drop.ablegen><en> Drop a file here or click to upload Choose File
<G-vec00418-001-s070><drop.ablegen><de> Zum Hochladen Datei hier ablegen oder auf den Button klicken.
<G-vec00418-001-s071><drop.ablegen><en> This speciality you should drop and the real beauty of your personality reached.
<G-vec00418-001-s071><drop.ablegen><de> Diese Besonderheit solltet ihr ablegen und die wirkliche Schönheit eurer Persönlichkeit erreichen.
<G-vec00418-001-s072><drop.ablegen><en> Syntex stopped in the U.S. in 1993, which was around the same time they decided to drop this item in a number of foreign countries as well.
<G-vec00418-001-s072><drop.ablegen><de> Syntex beendet in den USA im Jahr 1993, die etwa zur gleichen Zeit entschlossen sie sich war, dieses Element in einer Reihe von ausländischen Ländern sowie ablegen.
<G-vec00418-001-s073><drop.ablegen><en> In addition, the infection is fairly new and because there is not enough information, how it works, it could drop even malicious data in other directories.
<G-vec00418-001-s073><drop.ablegen><de> Darüber hinaus die Infektion ist relativ neu und da gibt es nicht genügend Informationen, wie es funktioniert, es könnte sogar schädliche Daten in anderen Verzeichnissen ablegen.
<G-vec00418-001-s074><drop.ablegen><en> You can also drag and drop files into the ESET File Security scan window. These files will be virus scanned immediately.
<G-vec00418-001-s074><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Security for Microsoft SharePoint-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s075><drop.ablegen><en> You can also drag and drop files into the ESET Mail Security scan window. These files will be virus scanned immediately.
<G-vec00418-001-s075><drop.ablegen><de> Sie können Dateien mit der Maus ziehen und im ESET Mail Security-Scanfenster ablegen, um sie sofort nach Viren zu scannen.
<G-vec00418-001-s076><drop.absetzen><en> On your journey home, please drop off the driver at the car park, then continue your journey.
<G-vec00418-001-s076><drop.absetzen><de> Sie müssen dann den Fahrer auf Ihrem Rückweg am Parkplatz absetzen, bevor Sie Ihren Heimweg antreten.
<G-vec00418-001-s077><drop.absetzen><en> 11:30pm: Our evening will come to a close as we drop you back at your hotel for around midnight.
<G-vec00418-001-s077><drop.absetzen><de> 23:30 Uhr: Unser Abend neigt sich dem Ende zu, als wir Sie gegen Mitternacht in Ihrem Hotel absetzen.
<G-vec00418-001-s078><drop.absetzen><en> Wired glass, laminated with wired or wire mesh, with stronger impact resistance, when been impacting, is form a radial crack not drop off to hurt human,mainly use on High-rise buildings and the workshop] building under the powerful concussive.
<G-vec00418-001-s078><drop.absetzen><de> Drahtglas mit laminierten verdrahtet oder wire Mesh, mit stärker Schlagzähigkeit, wenn Auswirkungen auf gewesen, ist Form ein radialer Spalt nicht absetzen verletzt Menschen, vor allem auf Hochhäuser und der Werkstatt] Gebäude unter den mächtigen erschütternder.
<G-vec00418-001-s079><drop.absetzen><en> In spite its high speed the procedure resembles the gentle way of placing a drop with a dosing needle.
<G-vec00418-001-s079><drop.absetzen><de> Der Vorgang gleicht trotz der hohen Geschwindigkeit dem sanften Absetzen durch eine Dosiernadel.
<G-vec00418-001-s080><drop.absetzen><en> What happens to the scrap cable wire after you drop them off They are sorted by material and sliced into smaller pieces The processed scrap is packaged and shipped to a company that re melts the materials and makes new products out of it An...
<G-vec00418-001-s080><drop.absetzen><de> Was passiert mit den Schrott Kabeldraht, nachdem Sie sie absetzen?Sie sind sortiert nach Material und in kleinere Stücke geschnitten.Die verarbeiteten Schrott ist verpackt und ausgeliefert, ein Unternehmen, das wieder schmilzt das Material und macht...
<G-vec00418-001-s081><drop.absetzen><en> Each tube has 15 stops, so it can drop you close to your final destination.
<G-vec00418-001-s081><drop.absetzen><de> Jede U-Bahn hat 15 Haltestellen, so dass sie Sie in der Nähe Ihres Endziels absetzen kann.
<G-vec00418-001-s082><drop.absetzen><en> With the left mouse button with the mouse, move the meat and fat drop off.
<G-vec00418-001-s082><drop.absetzen><de> Mit der linken Maustaste mit der Maus bewegen Sie den Fleisch und Fett absetzen.
<G-vec00418-001-s083><drop.absetzen><en> It doesn’t need to land, it can just hover above and use the long line to drop off supplies or even rescue people from narrow valley walls.
<G-vec00418-001-s083><drop.absetzen><de> Der Helikopter muss nicht landen, er kann einfach darüber schweben und mit der Longline, Vorräte absetzen oder sogar Menschen aus engen Talwände retten.
<G-vec00418-001-s084><drop.absetzen><en> But Klöden and Landis are the strongest and they can once again drop their opponents after an acceleration from the German to finish 25 seconds ahead of Sastre.
<G-vec00418-001-s084><drop.absetzen><de> Doch Klöden und Landis sind die Stärksten und können sich nach einer Temposteigerung des Deutschen wieder absetzen und das Ziel 25 Sekunden vor Sastre erreichen.
<G-vec00418-001-s085><drop.absetzen><en> The motorcycle drop was to have been at an entirely different place.
<G-vec00418-001-s085><drop.absetzen><de> Das Motorrad hätte mich an einer ganz anderen Stelle absetzen sollen.
<G-vec00418-001-s086><drop.absetzen><en> Our group will pick you up and drop you off in your accommodation so you don’t have to worry and enjoy your trip.
<G-vec00418-001-s086><drop.absetzen><de> Unsere Gruppe wird Sie abholen und in Ihrer Unterkunft absetzen, damit Sie sich keine Sorgen machen müssen und Ihre Reise genießen können.
<G-vec00418-001-s087><drop.absetzen><en> The shuttle driver will bring you to Maastricht Aachen Airport and drop you off in front of the departure terminal.
<G-vec00418-001-s087><drop.absetzen><de> Der Shuttlefahrer wird Sie zum Flughafen Maastricht Aachen fahren und direkt vor dem Abflugsterminal absetzen.
<G-vec00418-001-s088><drop.absetzen><en> If the goal were to see the backside of the Sun, one would merely have to drop a satellite near Earth's orbit and wait 6 months for a full 360 round view of the Sun.
<G-vec00418-001-s088><drop.absetzen><de> Wenn es das Ziel wäre, die Rückseite der Sonne zu sehen, würde man bloß einen Satelliten nahe des Erdorbits absetzen und 6 Monate auf einen vollen 360 Grad Rundumblick warten müssen.
<G-vec00418-001-s089><drop.absetzen><en> "In this case you could drop the passenger on this planet and indeed could continue your flight since you never in fact ""landed"" on the planet."
<G-vec00418-001-s089><drop.absetzen><de> "In diesem Fall könnte man tatsächlich einen Passagier auf diesem Planeten absetzen und den Flug danach fortsetzen, da man ja nicht auf diesem Planeten ""gelandet"" ist."
<G-vec00418-001-s090><drop.absetzen><en> If you are bringing someone to the airport follow the signs for 'Departures' and use the outside lane to drop them off.
<G-vec00418-001-s090><drop.absetzen><de> "Wenn Sie jemanden zum Flughafen bringen, folgen Sie bitte den Schildern zum Abflug, ""Departures"", und benutzen Sie die äußere Spur, wenn Sie sie absetzen."
<G-vec00418-001-s091><drop.absetzen><en> A bar, restaurant buffet Buena Vista with a wide range and show cooking, the snack bar open in high season to enjoy delicious snacks in the pool, a parking lot where to drop off your vehicle, a Hairdresser and a shop.
<G-vec00418-001-s091><drop.absetzen><de> Eine bar, Restaurant-Buffet Buena Vista mit einer Vielzahl und Show-cooking, Snack-Bar geöffnet in der Hauptsaison genießen Sie leckere Snacks im Pool, einem Parkplatz wo Sie Ihr Fahrzeug, ein Friseur und ein Geschäft absetzen.
<G-vec00418-001-s092><drop.absetzen><en> Lisa was running late for our appointment and didn't have time to drop Shelby off before coming over for her shoot.
<G-vec00418-001-s092><drop.absetzen><de> Lisa war spät dran für unsere Berufung und hatte keine Zeit zu Shelby absetzen, bevor er über für sie zu schießen.
<G-vec00418-001-s093><drop.absetzen><en> If you cannot meet us at the meeting point we can pick you up and drop you off in your accommodation.
<G-vec00418-001-s093><drop.absetzen><de> Wenn Sie uns nicht am Treffpunkt treffen können, können wir Sie abholen und in Ihrer Unterkunft absetzen.
<G-vec00418-001-s094><drop.absetzen><en> Coaches If you travel by coach, you probably want drop off and pick up your group at a suitable place.
<G-vec00418-001-s094><drop.absetzen><de> Reisebusse Wenn Sie mit dem Bus anreisen, möchten Sie Ihre Gruppe an einem günstig gelegenen Ort absetzen und wieder abholen.
<G-vec00418-001-s095><drop.absinken><en> With 3-5 years of growing rapidly, love of light, very drought-resistant, undemanding to soil, heat-loving, but can withstand short-term drop in temperature to -25 ° C. Durable, lives to 600 years old.
<G-vec00418-001-s095><drop.absinken><de> Mit 3-5 Jahren schnell wächst, lieben von Licht, sehr dÃ1⁄4rreresistenten, anspruchslos an Boden, Wärme liebende, können aber kurzfristigen Absinken der Temperatur auf -25 ° C standhalten Langlebige, lebt zu 600 Jahre alt.
<G-vec00418-001-s096><drop.absinken><en> b) The glass method: Place the seeds in a glass with a few centimeters of lukewarm water and leave in a dark warm place (floating seeds will drop to the bottom).
<G-vec00418-001-s096><drop.absinken><de> b) Die Glas-Methode: Lege die Samen in ein Glas, das einige Zentimeter hoch mit handwarmem Wasser befüllt ist, und stelle es an einen dunklen warmen Platz (zunächst oben schwimmende Samen werden bald bis zum Boden absinken).
<G-vec00418-001-s097><drop.absinken><en> Where the inland lake or sea lies over a fault line, the change of waves generated by a sudden drop in the sea floor is also present.
<G-vec00418-001-s097><drop.absinken><de> Wo der Inlandsee über einer Bruchlinie liegt, ist auch der Wechsel von Wellen durch ein plötzliches Absinken des Meeresgrundes präsent.
<G-vec00418-001-s098><drop.absinken><en> The pumping temperature must not drop below 27°C.
<G-vec00418-001-s098><drop.absinken><de> Die Pumptemperatur darf nicht auf <27°C absinken.
<G-vec00418-001-s099><drop.absinken><en> The drop in salinity from 17.5 psu on 10.1.2017 to 10.3 psu on 24.1.2017 could be an evidence of freshwater inflow from Lake Conventer See, which may have contained the high Aphanizomenon-biomass.
<G-vec00418-001-s099><drop.absinken><de> Das Absinken des Salzgehaltes von 17,5 psu am 10.1.2017 auf 10,3 psu am 24.1.2017 könnte ein Indiz für kurzzeitig eingeleitetes Süßwasser aus dem Conventer See sein, welches die hohen Aphanizomenon-Biomassen enthielt.
<G-vec00418-001-s100><drop.absinken><en> In adulthood ornamental cabbage can withstand short-term drop in temperature to -8-12 ° C. Seedlings of ornamental cabbage can withstand temperatures drop to -4 ° C. Ornamental kale can grow in partial shade.
<G-vec00418-001-s100><drop.absinken><de> Im Erwachsenenalter Zierkohl standhalten können kurzfristigen Absinken der Temperatur um -8-12 ° C. Sämlinge von Zierkohl hält Temperaturen bis -4 ° C fallen Ornamental GrÃ1⁄4nkohl können im Halbschatten wachsen.
<G-vec00418-001-s101><drop.absinken><en> Quite hardy, can withstand short-term drop in temperature to -20 ° C, a love of light, dust, smoke and gazoustoychiv.
<G-vec00418-001-s101><drop.absinken><de> Ziemlich robust, widerstandsfähig gegenüber kurzfristigen Absinken der Temperatur bis -20 ° C, eine Liebe, von Licht, Staub, Rauch und gazoustoychiv.
<G-vec00418-001-s102><drop.absinken><en> A drop in pension levels and the increasing spread of unstable employment biographies and low incomes may also lead to an increase in the number of pensioners whose retirement income is no longer sufficient to secure their accustomed standard of living.Â
<G-vec00418-001-s102><drop.absinken><de> Ein Absinken des Rentenniveaus sowie die zunehmende Verbreitung unsteter Erwerbsbiographien und geringer Einkommen können zudem dazu führen, dass es zukünftig vermehrt Rentner geben wird, deren Alterseinkommen nicht mehr ausreichen, um den gewohnten Lebensstandard zu sichern.
<G-vec00418-001-s103><drop.absinken><en> In adulthood ornamental cabbage can withstand short-term drop in temperature to -8-12 ° C.
<G-vec00418-001-s103><drop.absinken><de> Im Erwachsenenalter Zierkohl standhalten können kurzfristigen Absinken der Temperatur um -8-12 ° C.
<G-vec00418-001-s104><drop.absinken><en> The fluid level may drop slightly after a period of time due to the automatic compensation for brake pad wear. This is quite normal.
<G-vec00418-001-s104><drop.absinken><de> Ein geringfügiges Absinken des Flüssigkeitsstandes entsteht im Fahrbetrieb durch die Abnutzung und automatische Nachstellung der Bremsbeläge und ist deshalb normal.
<G-vec00418-001-s105><drop.absinken><en> Technical measures can especially support forest ecosystems in very dry regions where water is insufficiently available during summer months. These measures counteract the increasing lack of water and a drop in the groundwater level.
<G-vec00418-001-s105><drop.absinken><de> Vor allem in besonders trockenen Regionen, in denen Wasser während der Sommermonate nur eingeschränkt zur Verfügung steht, können Waldökosysteme durch technische Maßnahmen unterstützt werden, die dem zunehmenden Wassermangel sowie einem Absinken des Grundwasserspiegels entgegenwirken.
<G-vec00418-001-s106><drop.absinken><en> Ascending to high altitudes subjects the body to several significant changes, including decreases in temperature and ambient humidity, to a drop in barometric pressure (air pressure)..
<G-vec00418-001-s106><drop.absinken><de> Das Aufsteigen auf große Höhen unterwirft die Karosserie einigen bedeutenden Änderungen, einschließlich Temperaturabnahmen und umgebende Feuchtigkeit, an einem Absinken des Luftdrucks (Luftdruck).
<G-vec00418-001-s107><drop.absinken><en> Recession follows boom and cools off an overheated economy, allowing prices to drop back down to sensible levels, companies to scale down and become efficient again, and encouraging new creativity and innovation until these factors together create the beginnings of a new recovery, and eventually the next boom.
<G-vec00418-001-s107><drop.absinken><de> Rezession folgt auf Boom und kühlt eine überhitzte Wirtschaft ab, Preise, die wieder auf ein empfindliches Niveau absinken, Unternehmen werden reduziert und wieder effizient und ermutigt zu neuer Kreativität und Innovation bis diese Faktoren wieder die Anfänge einer neuen Erholung schaffen, und eventuell den nächsten Boom.
<G-vec00418-001-s108><drop.absinken><en> In this chart, temperature continues to drop for several days after the initial dip.
<G-vec00418-001-s108><drop.absinken><de> In diesem Diagramm fällt die Temperatur nach dem ersten Absinken noch einige Tage ab.
<G-vec00418-001-s109><drop.absinken><en> 6V System(1), the uC should work below 5V because the voltage can drop under load.
<G-vec00418-001-s109><drop.absinken><de> 6V System(1), d.h. die uC Schaltung sollte noch mit unter 5V funktionieren, da die Spannung unter Belastung absinken kann.
<G-vec00418-001-s110><drop.absinken><en> If the proportion of bicarbonate ions is too low, this can cause a strong drop in the pH value (drop in acidity), which can threaten the lives of many fish and invertebrates.
<G-vec00418-001-s110><drop.absinken><de> Ist der Anteil der Hydrogenkarbonat-Ionen zu gering, könnte es zu einem starken Absinken des pH-Wertes kommen (Säuresturz), was für viele Fische lebensbedrohlich ist.
<G-vec00418-001-s111><drop.absinken><en> When cows cannot access feed regularly throughout the day, an intake of a large quantity of rapidly fermentable feed causes an extreme drop in the animals' pH.
<G-vec00418-001-s111><drop.absinken><de> Wenn Kühe tagsüber nicht regelmäßig an Futter kommen, verursacht die Aufnahme einer großen Menge schnell gärenden Futters ein extremes Absinken der pH-Werte.
<G-vec00418-001-s112><drop.absinken><en> In the first three days I did not feel something ..vqt I did not sleep and did not pick up cat food for only a few sips of water and small spoons of honey was my mother fed me against my fear of a drop in circulation was close to my friend stay with me take my children with ..ookhry her children for a walk so as not to feel something special with home atmosphere Almichh in Black.
<G-vec00418-001-s112><drop.absinken><de> In den ersten drei Tagen habe ich nicht etwas ..vqt ich nicht schlafen und nicht abholen Katzenfutter für nur ein paar Schlucke Wasser und kleine Löffel Honig wurde meine Mutter gegen meine Angst vor einem Absinken der Auflage zugeführt mir wurde in der Nähe von meinem Freund bei mir bleiben nehme meine Kinder mit ..ookhry fühlen ihre Kinder für einen Spaziergang, um nicht etwas Besonderes mit Atmosphäre zu Hause Almichh in Black fühlen.
<G-vec00418-001-s113><drop.absinken><en> Doubts will take you back a step and let your frequency drop.
<G-vec00418-001-s113><drop.absinken><de> Zweifeln versetzt Sie einen Schritt zurück und lässt Ihre Frequenz absinken.
<G-vec00418-001-s304><drop.fallen><en> The video documentation of the solemn handing over during which Michl Schmidt will drop this heavy heritage of the artist on his bare feet can be seen during the exhibition period.
<G-vec00418-001-s304><drop.fallen><de> Die filmische Dokumentation der Performance, bei der sich Michl Schmidt das gewichtige Vermächtnis eines Künstlers seiner Elterngeneration auf die nackten Füße fallen lässt, ist während der Ausstellungszeit zu sehen.
<G-vec00418-001-s305><drop.fallen><en> The handles are carefully hand stitched and drop to more than four inches.
<G-vec00418-001-s305><drop.fallen><de> Die Griffe sind sorgfältig von Hand genäht und fallen um mehr als vier Zentimeter.
<G-vec00418-001-s306><drop.fallen><en> As you grow older, your muscle density begins to drop.
<G-vec00418-001-s306><drop.fallen><de> Wenn man älter wird, beginnt Ihre Muskeldichte zu fallen.
<G-vec00418-001-s307><drop.fallen><en> If the firewall does not drop the request but rejects the request the port scanner does not have to wait for the timeout.
<G-vec00418-001-s307><drop.fallen><de> Falls die Firewall die Anfrage nicht fallen lässt, aber sie ablehnt, muss der Portscanner nicht auf das Timeout warten.
<G-vec00418-001-s308><drop.fallen><en> “The hammer is about to drop, as Attorney General Bill Barr met John Huber prior to FISA declassification and mass arrests,” a Pentagon source noted.
<G-vec00418-001-s308><drop.fallen><de> „Der Hammer ist dabei, zu fallen, da Justizminister Bill Barr und John Huber sich vor der FISA-Freigabe und Massenverhaftungen getroffen haben“, stellte eine Pentagon-Quelle fest.
<G-vec00418-001-s309><drop.fallen><en> We are always ready to help you.There are many ways to contact you.You may drop us on line.
<G-vec00418-001-s309><drop.fallen><de> Wir sind immer bereit, viele Möglichkeiten you.There sind zu helfen you.You fallen können uns auf Linie zu kontaktieren.
<G-vec00418-001-s310><drop.fallen><en> To avoid the piece pulling together in the sides, replace the 3 YOs at beg and end of 7th row in A.1 with 4 YOs – drop YOs off the needle on next row as before.
<G-vec00418-001-s310><drop.fallen><de> Um zu vermeiden, dass sich die Arb an den Seiten zusammenzieht, macht man am Anfang und am Ende der 7.R von A.1 4 Umschläge statt 3 Umschläge – die Umschläge werden in der nächsten R fallen lassen wie gehabt.
<G-vec00418-001-s311><drop.fallen><en> Elsewhere, BTC started to drop below the $7,700 yesterday in the evening and is presently fighting to reclaim that level that could prove the most important one in term as it will reveal whether the market has a chance of continuing upwards or whether we should expect a steeper drop after an admittedly impressive bull-run.
<G-vec00418-001-s311><drop.fallen><de> Andernorts begann BTC gestern Abend unter die 7.700 $-Marke zu fallen und kämpft derzeit darum, das Niveau zurückzugewinnen, das sich als das wichtigste in der Geschichte erweisen könnte, da es zeigen wird, ob der Markt die Chance hat, weiter nach oben zu steigen, oder ob wir nach einem zugegebenermaßen beeindruckenden Bullenlauf einen stärkeren Rückgang erwarten sollten.
<G-vec00418-001-s312><drop.fallen><en> They worried that if you sailed far enough, you would drop off the Earth into nothing.
<G-vec00418-001-s312><drop.fallen><de> Sie glaubten, wenn man weit genug segeln würde, würde man vom Rand der Erde ins Nichts fallen.
<G-vec00418-001-s313><drop.fallen><en> In summer it can easiliy hit the mid eighty’s but be warned in the winter it can also easily drop to just above freezing with temperatures of 4 degrees in the deep winter.
<G-vec00418-001-s313><drop.fallen><de> Im Sommer kann es leicht die Mitte der Achtzigerjahre treffen, aber seien Sie gewarnt, im Winter kann es auch leicht fallen bis knapp über dem Gefrierpunkt mit Temperaturen von 4 Grad im tiefen Winter.
<G-vec00418-001-s314><drop.fallen><en> Make fewer phones and let high-end devices run a two-year course instead of just six or 12 mese, and gradually drop the price as better models come out .
<G-vec00418-001-s314><drop.fallen><de> Machen Sie weniger Handys und lassen Sie High-End-Geräten laufen einen Zwei-Jahres-Kurs statt nur sechs oder 12 Monat, und nach und nach fallen die Preise als bessere Modelle herauskommen .
<G-vec00418-001-s315><drop.fallen><en> a day with no physical exercise is great information to people who used up hours of jogging, jumping and even spending a lot of cash to gymnasium coaches simply to drop a bit of weight.
<G-vec00418-001-s315><drop.fallen><de> einen Tag ohne körperliche Bewegung ist groß Informationen an Menschen, die Stunden Joggen verwendet, Springen und sogar eine Menge Geld auszugeben, um Turnhalle Trainer einfach, ein bisschen Gewicht zu fallen.
<G-vec00418-001-s316><drop.fallen><en> However, because shorter hours are associated with lower pay in most people's minds, the program also has a guarantee that weekly wages will not drop by more than a small amount if work hours are substantially reduced.
<G-vec00418-001-s316><drop.fallen><de> Allerdings hat auch, weil kürzere Arbeitszeiten mit niedrigeren Lohn in den meisten Köpfen der Menschen verbunden das Programm eine Garantie, dass die Wochenlöhne um nicht mehr als eine kleine Menge fallen, wenn Arbeitszeiten werden deutlich reduziert.
<G-vec00418-001-s317><drop.fallen><en> ● Hot Sale Design Framed Folding Clear Glass Sliding Shower Enclosure With Cheap Price ● Certified tempered clear glass, aluminiumfinish hardware, clear premium leak-seal strips, durable steel supports, you just drop in your relaxing shower time.
<G-vec00418-001-s317><drop.fallen><de> ● Heißer Verkaufs-Entwurfs-gerahmtes faltendes freies Glas-Schiebe-Dusche-Einschließung mit preiswertem Preis ● Bescheinigtes gehärtetes klares Glas, aluminiumfinish Hardware, freie erstklassige Leckdichtungsstreifen, haltbare Stahlstützen, Sie fallen einfach in Ihre entspannende Duschenzeit.
<G-vec00418-001-s318><drop.fallen><en> As Human Growth Hormone levels continue to drop, you don't sleep as well anymore.
<G-vec00418-001-s318><drop.fallen><de> Wie Human Growth Hormone noch fallen weiter, schläfst du nicht auch mehr.
<G-vec00418-001-s319><drop.fallen><en> There are great deals of reasons that people drop their hair.
<G-vec00418-001-s319><drop.fallen><de> Es gibt Angebote von Faktoren, die Menschen ihre Haare fallen.
<G-vec00418-001-s320><drop.fallen><en> When you drop the bars of dynamite during the game, either on purpose or by accident, this will destroy the surrounding jewels.
<G-vec00418-001-s320><drop.fallen><de> Wenn du während des Spiels absichtlich oder unabsichtlich Stangen Dynamit fallen lässt, werden dadurch die umliegenden Juwelen zerstört.
<G-vec00418-001-s321><drop.fallen><en> Any guy can drop you an e-mail from time to time to keep his investment in you alive for just a little while longer.
<G-vec00418-001-s321><drop.fallen><de> Jeder Mann können Sie eine E-Mail von Zeit zu Zeit fallen, seine Investitionen in die Sie am Leben nur für eine Weile zu halten.
<G-vec00418-001-s322><drop.fallen><en> Continuous, substantial data transfer dramatically lowers the performance of an M.2 SSD without cooling and can actually drop performance down to as little as 10% of its actual capability.
<G-vec00418-001-s322><drop.fallen><de> Bei hohen, anhaltenden Datenübertragungen sinkt die Performance einer M.2 SSD ohne Kühlung dramatisch ab und kann auf bis zu 10% der eigentlichen Leistung fallen.
<G-vec00418-001-s323><drop.lassen><en> A larger display does not always fit in your pocket, and people with tiny hands can drop it altogether.
<G-vec00418-001-s323><drop.lassen><de> Ein größeres Display passt nicht immer in Ihre Hosentasche, und Personen mit kleinen Händen können es ganz fallen lassen.
<G-vec00418-001-s324><drop.lassen><en> Drop down and climb the blocks on the right.
<G-vec00418-001-s324><drop.lassen><de> Hinunter fallen lassen und dann auf die Blöcke rechts klettern.
<G-vec00418-001-s325><drop.lassen><en> His internship stretched into a three-year experience that covered most aspects of theater production, including lighting, set design, and stage management, prompting Hanks to drop out of college.
<G-vec00418-001-s325><drop.lassen><de> Sein Praktikum gestreckt in eine dreijährige Erfahrung, die die meisten Aspekte der Theaterproduktion abgedeckt, einschließlich Beleuchtung, Set-Design, und Stage-Management, Hanks Aufforderung aus der Schule fallen zu lassen.
<G-vec00418-001-s326><drop.lassen><en> The knowledge about this I impart to you through my word, and as it is offered to you directly out of the heavens, also the believing in it is made easier for you, because what I announce to you, proves to be true, and therefore you can drop all doubt, you can, when you are still weak in faith, just give full expression to my word and therefore put it to the test, and you will recognize that my word is truth, that it is my word, which is offered to you from above.
<G-vec00418-001-s326><drop.lassen><de> Das Wissen darum vermittle Ich euch durch Mein Wort, und so es direkt aus den Himmeln euch geboten wird, ist euch auch das Glauben daran leichter gemacht, denn was Ich euch kundtue, bewahrheitet sich, und also könnet ihr jeden Zweifel fallen lassen, ihr könnet, so ihr noch schwachgläubig seid, nur Mein Wort ausleben und also die Probe aufs Exempel machen, und ihr werdet erkennen, daß Mein Wort Wahrheit ist, daß es Mein Wort ist, das euch geboten wird aus der Höhe.
<G-vec00418-001-s327><drop.lassen><en> I can only just drop these hints, but I know what I am talking about, and I do believe, dear friends, that all we need is the power of the Holy Spirit in the Gospel.
<G-vec00418-001-s327><drop.lassen><de> Ich bloß diese Hinweise fallen lassen, aber ich weiß, wovon ich rede, und ich glaube, liebe Freunde, dass alles, was wir brauchen, die Kraft des Heiligen Geistes im Evangelium ist.
<G-vec00418-001-s328><drop.lassen><en> Before the trial, there was an international campaign asking that people press the Ministry of Defence to drop the charges.
<G-vec00418-001-s328><drop.lassen><de> Noch vor dem Verfahren hatte es eine internationale Kampagne gegeben, um Druck auf das Verteidigungsministerium auszuüben, die Anklage fallen zu lassen.
<G-vec00418-001-s329><drop.lassen><en> Lizard, a tattoo image of which mandecides to do on his body, - essentially a creature dodgy, fast, capable at the slightest risk to drop his tail to save life.
<G-vec00418-001-s329><drop.lassen><de> Eidechse, ein Tattoo Bild von welchem Mannbeschließt, auf seinem Körper zu tun, - im Wesentlichen eine Kreatur zweifelhaft, schnell, in der Lage bei dem geringsten Risiko, seinen Schwanz fallen zu lassen, um das Leben zu retten.
<G-vec00418-001-s330><drop.lassen><en> PhenQ examines programs that this item can be one of the safest as well as best methods to drop weight without needing to invest a lot of money and perhaps place your health and wellness at risk.
<G-vec00418-001-s330><drop.lassen><de> PhenQ beurteilt Programme, die dieses Produkt eines der sichersten und besten Methoden, um Gewicht fallen zu lassen, ohne dass eine Tonne Geld ausgeben, sowie möglicherweise platzieren Sie Ihre Wellness in Gefahr.
<G-vec00418-001-s331><drop.lassen><en> It's an OK show for when nothing else is on, but with my tight schedule I think this is one of the shows I'll drop again (along with Stargate Universe).
<G-vec00418-001-s331><drop.lassen><de> Die Serie ist OK, wenn gerade nichts anderes läuft, aber mit meinem vollgepackten Terminplan denke ich, dass das eine der Serien ist, die ich wieder fallen lassen werde (zusammen mit Stargate Universe).
<G-vec00418-001-s332><drop.lassen><en> Whether you’re just trying to shed 5 pounds, are frustrated by the last 10 or need to drop 15 fast, we’ve got the best tips to lose weight in 8 weeks.
<G-vec00418-001-s332><drop.lassen><de> Egal, ob Sie nur versuchen, 5 Pfund Schuppen, durch die letzten 10 frustriert ist oder müssen 15 schnell fallen zu lassen, haben wir die besten Tipps bekommen Gewicht in 8 Wochen zu verlieren.
<G-vec00418-001-s333><drop.lassen><en> Then drop down on the right side, onto the walkway leading to the remaining drawbridge.
<G-vec00418-001-s333><drop.lassen><de> Dann auf der rechten Seite, auf den Weg, der zur letzten Zugbrücke führt fallen lassen.
<G-vec00418-001-s334><drop.lassen><en> If not, you drop.
<G-vec00418-001-s334><drop.lassen><de> Wenn nicht, dann fallen zu lassen.
<G-vec00418-001-s335><drop.lassen><en> Google is making changes to its Chrome OS to reduce the number of times that Chromebooks drop their connections to Wi-Fi networks.
<G-vec00418-001-s335><drop.lassen><de> Google wird allen Eingriffen in die Chrome OS auf die Anzahl der Male, dass Chromebooks ihre Verbindungen fallen lassen, um Wi-Fi-Netzwerke zu reduzieren.
<G-vec00418-001-s336><drop.lassen><en> Also, there are lots of power-ups to increase the range of the explosion, drop extra bombs and many more items to increase the abilities of your character.
<G-vec00418-001-s336><drop.lassen><de> Außerdem gibt es jede Menge Power-Ups, um die Reichweite der Explosion zu erhöhen, zusätzliche Bomben fallen zu lassen und viele weitere Elemente, um die Fähigkeiten Ihres Charakters zu erhöhen.
<G-vec00418-001-s337><drop.lassen><en> The vulnerable corners of your phone are the most exposed area should you ever happen to drop it, so the added peace of mind the reinforced corners provide is priceless - especially for the slight increase in size.
<G-vec00418-001-s337><drop.lassen><de> Die empfindlichen Ecken Ihres Telefons sind der am stärksten exponierte Bereich, sollten Sie es jemals fallen lassen, so dass die zusätzliche Ruhe, die die verstärkten Ecken bieten, unbezahlbar ist - besonders für die leichte Vergrößerung der Größe.
<G-vec00418-001-s338><drop.lassen><en> Drop down into the hole at the end.
<G-vec00418-001-s338><drop.lassen><de> Am Ende in das Loch fallen lassen.
<G-vec00418-001-s339><drop.lassen><en> This exclusive formula makes it easy for you to drop pounds and appreciate a slim and also trim physical body in no time at all.
<G-vec00418-001-s339><drop.lassen><de> Diese proprietäre Formel macht es einfach für Sie Pfund fallen zu lassen und genießen Sie einen schlanken sowie trimmen physischen Körper im Handumdrehen.
<G-vec00418-001-s340><drop.lassen><en> It is without a doubt the most effective anabolic steroid around if you are aiming to drop a few of your bodyweight and also acquire a muscular physique without needing to bother with size or durability constraints.
<G-vec00418-001-s340><drop.lassen><de> Es ist bei weitem das wirksamste anabole Steroide da draußen, wenn Sie einige Ihrer Körpergewicht fallen zu lassen wollen, sind und eine muskulöse Figur erhalten, ohne dass über Dimension oder Langlebigkeit Einschränkungen zu kümmern.
<G-vec00418-001-s341><drop.lassen><en> You could possibly anticipate to drop body fat as well as get leaner, a lot more powerful as well as fitter and a matter of a couple of months of taking it.
<G-vec00418-001-s341><drop.lassen><de> Sie können antizipieren Körperfett fallen zu lassen und erhalten schlanker, stärker und fitter und auch eine Frage von einigen Monaten davon nehmen.
<G-vec00418-001-s342><drop.fallen><en> Every $10 drop in the price of a barrel of oil means Russia losing up to $14.6 billion a year.
<G-vec00418-001-s342><drop.fallen><de> Wenn der Preis des Ölbarrels um 10 $ fällt, bedeutet es jedes Mal für Russland bis jährlich 14,6 Milliarden $ entgangenen Gewinns.
<G-vec00418-001-s343><drop.fallen><en> Do not get to close or you might bump your head and drop down.
<G-vec00418-001-s343><drop.fallen><de> Nicht zu nahe kommen, sonst stößt man sich den Kopf und fällt in die Tiefe.
<G-vec00418-001-s344><drop.fallen><en> """And something that is easy to plug in can easily drop out if geometry is one hundred percent not totally correct"", says Buschhaus."
<G-vec00418-001-s344><drop.fallen><de> """Und was leicht steckbar ist, fällt auch leicht wieder raus wenn die Geometrie nicht hundertprozentig stimmt"", so Buschhaus."
<G-vec00418-001-s345><drop.fallen><en> The reef consists of a parapet at a depth of 30 metres and then a drop to 60 metres.
<G-vec00418-001-s345><drop.fallen><de> Das Riff besteht aus einer Steilwand bei 30 Metern und fällt dann 60 Meter tief ab.
<G-vec00418-001-s346><drop.fallen><en> On average in a year in the territory of the Village Council about 650 mm of rainfall drop out.
<G-vec00418-001-s346><drop.fallen><de> Durchschnittlich fällt im Jahr auf dem Territorium des Dorfsowjets bis zu 650 mm der Ablagerungen aus.
<G-vec00418-001-s347><drop.fallen><en> “People are connecting with your brand through different models, primarily on social networks.” A research study by PricewaterhouseCoopers projected that in 2013 through 2018, the annual revenue for newspaper publishing will continue to drop, but online publishing will boom.
<G-vec00418-001-s347><drop.fallen><de> „Menschen stellen auf verschiedenen Art und Weise Verbindungen zu Deiner Marke her, allen voran auf sozialen Netzwerken.“ Eine Studie von PricewaterhouseCoopers sagte voraus, dass der jährliche Ertrag für Zeitungsveröffentlichungen im Zeitraum von 2013 bis 2018 weiterhin fällt, während Online-Publishing boomt.
<G-vec00418-001-s348><drop.fallen><en> (If you drop into the water you can collect the goodies later on, you have to return here anyway.
<G-vec00418-001-s348><drop.fallen><de> [Hinweis] Wenn man ins Wasser fällt, kann man die Gegenstände später noch mal einsammeln, man muss sowieso noch mal hier hin.
<G-vec00418-001-s349><drop.fallen><en> Pembrok two times a year fade, in the rest of the time wool at them, as a rule, does not drop out.
<G-vec00418-001-s349><drop.fallen><de> Verschießen pembroki zwei Male im Jahr, zur übrigen Zeit fällt die Wolle bei ihnen in der Regel nicht aus.
<G-vec00418-001-s350><drop.fallen><en> In all three scenarios, however, the spot price will drop to 16 $/kg by the end of 2014.
<G-vec00418-001-s350><drop.fallen><de> In allen drei Szenarien fällt der Spotpreis jedoch bis Ende 2014 auf 16 $/kg.
<G-vec00418-001-s351><drop.fallen><en> As soon as it's done with this, the ransomware may also drop and display it's primary ransom note file.
<G-vec00418-001-s351><drop.fallen><de> Sobald es damit fertig, Notizdatei primäres Lösegeld fällt und zeigt die Ransomware kann auch es ist.
<G-vec00418-001-s352><drop.fallen><en> The withdrawal of the commodity through consumption, i.e. its annihilation as exchange value, and the withdrawal of money, its becoming independent, which is again another form of its annihilation, likewise drop out of circulation.
<G-vec00418-001-s352><drop.fallen><de> Ebenso fällt außerhalb der Zirkulation die Entziehung der Ware durch den Konsum, also ihre Vernichtung als Tauschwert, und das Entziehn des Geldes, seine Verselbstständigung, was wieder eine andre Form seiner Vernichtung ist.
<G-vec00418-001-s353><drop.fallen><en> Question asked by: Boštjan Kastelic • Over the year the temperature of water does not drop below 24℃.
<G-vec00418-001-s353><drop.fallen><de> Frage gestellt von: Boštjan Kastelic • Im Laufe des Jahres fällt die Temperatur des Wassers nicht unter 24°C.
<G-vec00418-001-s354><drop.fallen><en> """The problem is that after three years of crisis the first tentative signs of economic growth in Russia still aren't noticeable for the people, whose living standards continue to drop."
<G-vec00418-001-s354><drop.fallen><de> """Das Problem dabei ist, dass die ersten zarten Anzeichen von Wirtschaftswachstum in Russland - nach drei Jahren Krise - noch lange nicht bei den Menschen angekommen sind, deren Lebensstandard weiter fällt."
<G-vec00418-001-s355><drop.fallen><en> The dried product will drop from the last layer of the drying plate to the bottom layer of the smell body, and will be moved by harrows to the discharge port.
<G-vec00418-001-s355><drop.fallen><de> Das getrocknete Produkt fällt von der letzten Schicht der Trockenplatte zur unteren Schicht des Geruchskörpers und wird durch Eggen zur Austragsöffnung bewegt.
<G-vec00418-001-s356><drop.fallen><en> In one sense, drop everything.
<G-vec00418-001-s356><drop.fallen><de> In einem gewissen Sinne fällt alles.
<G-vec00418-001-s357><drop.fallen><en> Question asked by: Marilyn Vargas • Over the year the temperature of water does not drop below 19℃.
<G-vec00418-001-s357><drop.fallen><de> Frage gestellt von: Marilyn Vargas • Im Laufe des Jahres fällt die Temperatur des Wassers nicht unter 19°C.
<G-vec00418-001-s358><drop.fallen><en> Thanks to its non-slip material, the phone doesn't drop so easily from your hand.
<G-vec00418-001-s358><drop.fallen><de> Durch die Rutschfestigkeit des Materials fällt das Gerät nicht so leicht aus der Hand.
<G-vec00418-001-s359><drop.fallen><en> "The child will be able to play to roll the ball along the path inside the castle and along the walls: putting the ball in the top of the tower it will drop down along the various levels, stopping inside the ""courtyard"" in front of the entrance."
<G-vec00418-001-s359><drop.fallen><de> "Das kind kann spielen zu lassen, rollt die kugel entlang der strecke innerhalb der burg und auf den mauern, indem sie die kugel in der spitze des turms, dieser fällt nach unten durch die verschiedenen ebenen, mit halt im ""innenhof"" vor dem eingang."
<G-vec00418-001-s360><drop.fallen><en> The temperature does only drop to 20.6°C.
<G-vec00418-001-s360><drop.fallen><de> Die Temperatur fällt nur auf 20.6°C.
<G-vec00418-001-s399><drop.löschen><en> When a trigger is highlighted, the right mouse button menu offers options to create a new trigger, edit or drop the highlighted trigger, or set the marked trigger (or multiple triggers) to inactive/active.
<G-vec00418-001-s399><drop.löschen><de> Wenn ein Trigger markiert ist, bietet das Rechtsklickmenü Optionen zur Erzeugung eines neuen Triggers an, den Trigger zu bearbeiten oder zu löschen oder den Trigger (oder auch mehrere Trigger) aktiv oder inaktiv zu setzen.
<G-vec00418-001-s400><drop.löschen><en> To drop a table use the DB Explorer, right-click and select the menu item Drop Table or [Ctrl + Del] or, if the table is already opened in the Table Editor, use the Table Editor main menü item, (opened by clicking Table in the top left-hand corner), Drop Table.
<G-vec00418-001-s400><drop.löschen><de> Verwenden Sie zum Löschen einer Tabelle den Rechtsklickmenüpunkt Lösche Tabelle im DB Explorer oder die Tasten [Strg + Entf] oder, wenn die Tabelle bereits im Tabelleneditor geöffnet ist, verwenden Sie das Tabelleneditor Menü (durch Anklicken Tabelle oben links zu öffnen), Lösche Tabelle.
<G-vec00418-001-s401><drop.löschen><en> Always learn everything that you can about any online poker site before you drop any money.
<G-vec00418-001-s401><drop.löschen><de> Immer erfahren Sie alles, die Sie über alle online-Gaming-Site können, bevor Sie Geld löschen.
<G-vec00418-001-s402><drop.löschen><en> To reinitialize this subscription, you must drop and re-create the subscription.
<G-vec00418-001-s402><drop.löschen><de> Um dieses Abonnement neu zu initialisieren, müssen Sie es löschen und neu erstellen.
<G-vec00418-001-s403><drop.löschen><en> Every Egyptian free invited to drop the crime of coup d ' état on his will and freedom..
<G-vec00418-001-s403><drop.löschen><de> Alle ägyptischen kostenlose eingeladen, das Verbrechen der Staatsstreich auf seinem Willen und Freiheit zu löschen..
<G-vec00418-001-s404><drop.löschen><en> ALTER VIEW enables a view definition to be altered without the need to recreate (drop and create) the old version of the view and all of its dependencies.
<G-vec00418-001-s404><drop.löschen><de> ALTER VIEW ermöglicht die Änderung der Viewdefinition ohne die alte Version und all ihre Abhängigkeiten neu erzeugen (löschen und neu erzeugen) zu müssen.
<G-vec00418-001-s405><drop.löschen><en> And in the end, bad information, we should be able to drop our luggage for the release of this apartment to a nearby address, we had mentioned, we have found doors closed at this address, what did we lose the benefit of our last day of stay in ROME.
<G-vec00418-001-s405><drop.löschen><de> Und am Ende, schlechte Informationen, sollte man in der Lage, unser Gepäck für die Freigabe der Wohnung zu einer nahe gelegenen Adresse zu löschen, wir hatten erwähnt, Türen geschlossen unter dieser Adresse gefunden zu haben, was wir verlieren den Vorteil, unser letzter Tag des Aufenthalts in Rom.
<G-vec00418-001-s406><drop.löschen><en> Use YOUR MOUSE to position your sushi cat and click LEFT MOUSE BUTTON to drop sushi cat.
<G-vec00418-001-s406><drop.löschen><de> Verwenden Sie IHRE Maus positionieren Ihre Suchi-Katze und klicken Sie auf die linke Maustaste um Suchi Katze zu löschen.
<G-vec00418-001-s407><drop.löschen><en> Grasp objects with the mouse instead of the house you want to drop.
<G-vec00418-001-s407><drop.löschen><de> Fassen Sie Objekte mit der Maus statt des Hauses die Sie löschen möchten.
<G-vec00418-001-s408><drop.löschen><en> This aids you drop weight while obtaining an amazing improvement of energy.
<G-vec00418-001-s408><drop.löschen><de> Diese Vorlagen löschen Sie Gewicht während des Abrufens einer erstaunlichen Verbesserung der Energie.
<G-vec00418-001-s409><drop.löschen><en> If no database owner is specified at the time of database creation, then only the SYSDBA is authorized to drop the database.
<G-vec00418-001-s409><drop.löschen><de> Sollte kein Datenbankbesitzer bei der Erzeugung der Datenbank angegeben werden ist nur der SYSDBA autorisiert, die Datenbank zu löschen.
<G-vec00418-001-s410><drop.löschen><en> Various icons & templates are available for you to drag, drop and edit easily.
<G-vec00418-001-s410><drop.löschen><de> Verschiedene Symbole und Vorlagen stehen zur Verfügung, die Sie einfach ziehen, löschen und bearbeiten können.
<G-vec00418-001-s411><drop.löschen><en> DROP TABLE <table_name>; Note: When used to drop an external table, DROP TABLE only removes the table definition from the database.
<G-vec00418-001-s411><drop.löschen><de> DROP TABLE <table_name>; Bitte beachten Sie: Wenn DROP TABLE zum Löschen einer externen Tabelle verwendet wird, wird nur die Tabellendefinition aus der Datenbank entfernt.
<G-vec00418-001-s412><drop.löschen><en> Drop a block, play free Puzzle games online.
<G-vec00418-001-s412><drop.löschen><de> Einen Block löschen, Spielfreie Puzzle Spiele online.
<G-vec00418-001-s413><drop.löschen><en> To drop the column, you must first drop the table from all publications and subscriptions.
<G-vec00418-001-s413><drop.löschen><de> Zum Löschen der Spalte mÃ1⁄4ssen Sie zuerst die Tabelle aus allen Veröffentlichungen und Abonnements löschen.
<G-vec00418-001-s415><drop.löschen><en> These companies may drop cookies on your computer when you use them on our site or if you are already logged in to them.
<G-vec00418-001-s415><drop.löschen><de> Diese Unternehmen können Cookies auf Ihrem Computer löschen, wenn Sie sie auf unserer Website verwenden oder wenn Sie bereits bei ihnen angemeldet sind.
<G-vec00418-001-s416><drop.löschen><en> ALTER INDEX <index_name> ACTIVE | INACTIVE If you paid attention to the IBExpert Compile dialog whilst compiling your index alterations in the Index Editor, you will have noticed that in order to enforce your desired changes,IBExpert does none other than drop the index and then recreate it incorporating the new properties specified.
<G-vec00418-001-s416><drop.löschen><de> Die SQL-Syntax lautet: ALTER INDEX <index_name> ACTIVE | INACTIVE Wenn Sie den IBExpert Dialog Compile beim Kompilieren Ihrer Indexänderung aufmerksam verfolgt haben, werden Sie bemerkt haben, dass zur Ausführung Ihrer gewünschten Änderungen, IExpert nichts anderes macht, als den Index zu löschen und entsprechend der definierten Eigenschaften neu zu erzeugen.
<G-vec00418-001-s417><drop.löschen><en> Despite the fact that this is largely considereded the best way to drop weight, some past customers claim that they haven't considered any sort of exercise after taking Phen375 as well as have still seasoned substantial fat burning.
<G-vec00418-001-s417><drop.löschen><de> Trotz der Tatsache, dass dies weitgehend Considereded als der effektivste Weg, Gewicht zu löschen ist behaupten einige vorbei an Kunden, sie wandten sich nicht gegen jede Art von Training nach der Einnahme von Phen375 sowie haben noch qualifizierte enormen Gewichtsverlust.
<G-vec00418-001-s513><drop.sinken><en> At the 2009 Automotive Press Briefing, Bosch elaborated on this point: over the medium term, the fuel consumption and CO2 emissions of internal-combustion engines will drop by 30 percent – both for gasoline and for diesel engines.
<G-vec00418-001-s513><drop.sinken><de> Beim Motorpressekolloquium im Jahr 2009 hatte Bosch es deutlich herausgearbeitet: Mittelfristig wird beim Verbrenner der Kraftstoffverbrauch und gleichermaßen die CO2-Emissionen um 30 Prozent sinken – sowohl beim Benziner als auch beim Diesel.
<G-vec00418-001-s514><drop.sinken><en> Temperatures drop to minus 30 degrees Celsius and no sunlight breaks the darkness of the polar night for months.
<G-vec00418-001-s514><drop.sinken><de> Die Temperaturen sinken bis auf minus 30 Grad Celsius und kein Sonnenstrahl dringt für Monate durch die polare Nacht.
<G-vec00418-001-s515><drop.sinken><en> Constant cleaning is no longer necessary and the production costs drop.
<G-vec00418-001-s515><drop.sinken><de> Das ständige Reinigen entfällt, die Produktionskosten sinken.
<G-vec00418-001-s516><drop.sinken><en> When temperatures drop, get out and get your heart rate up with the men's NB Heat Quarter Zip.
<G-vec00418-001-s516><drop.sinken><de> Wenn die Temperaturen sinken, geh raus und erhöhe deine Herzfrequenz mit dem NB Heat Quarter Zip.
<G-vec00418-001-s517><drop.sinken><en> Figures from the Dutch ministry of justice suggest overall crime will drop by 0.9% a year in the next five years.
<G-vec00418-001-s517><drop.sinken><de> Figuren aus Das niederländische Ministerium für Justiz schlage vor, allgemeine Kriminalität um 0,9 % pro Jahr in den nächsten fünf Jahren sinken wird.
<G-vec00418-001-s518><drop.sinken><en> Time when the temperatures drop and the whole landscape is covered in snow.
<G-vec00418-001-s518><drop.sinken><de> Zeit, wenn die Temperaturen sinken, und die ganze Landschaft ist mit Schnee bedeckt.
<G-vec00418-001-s519><drop.sinken><en> This type of heat pump has the disadvantage that its heating capacity and efficiency drop sharply at lower outside temperatures.
<G-vec00418-001-s519><drop.sinken><de> Dieser Wärmepumpentyp hat den Nachteil, dass die Heizkapazität und Leistungszahl bei niedrigeren Außentemperaturen sehr stark sinken.
<G-vec00418-001-s520><drop.sinken><en> If the efficiency of electrical and pneumatic drive technology could be increased, the electricity requirements of industry would drop.
<G-vec00418-001-s520><drop.sinken><de> Gelingt es, die Effizienz der elektrischen und pneumatischen Antriebstechnik zu erhöhen, würde der Strombedarf der Industrie sinken.
<G-vec00418-001-s521><drop.sinken><en> Product details X There is nothing better than to have a cuddly soft turtleneck pullover at hand as soon as the temperatures drop.
<G-vec00418-001-s521><drop.sinken><de> Produktdetails X Es gibt doch nichts schöneres als einen kuschelweichen Rollkragenpullover griffbereit im Schrank zu haben, sobald die Temperaturen sinken.
<G-vec00418-001-s522><drop.sinken><en> Prices for MOD editions will not drop significantly, regardless how long you wait with your order since they are always custom made.
<G-vec00418-001-s522><drop.sinken><de> Die Preise für MOD-Boxen werden unabhängig vom Zuwarten nach dem Erscheinungstermin nicht spürbar sinken, da es sich immer um Einzelfertigungen handelt.
<G-vec00418-001-s523><drop.sinken><en> The pH level of the surface waters could drop to levels below those seen for more than 5 million years.
<G-vec00418-001-s523><drop.sinken><de> Der pH-Wert des Oberflächenwassers könnte unter das Niveau der letzten 5 Millionen Jahre sinken.
<G-vec00418-001-s524><drop.sinken><en> This will allow you to drop pounds quicker.
<G-vec00418-001-s524><drop.sinken><de> Dies wird Ihnen erlauben, zusätzliche Pfunde schneller sinken.
<G-vec00418-001-s525><drop.sinken><en> Only for a 905 nm lidar with an electronic scanning process, IHS expects the unit price to drop from currently 590 dollars to below the 200 dollar threshold by 2025.
<G-vec00418-001-s525><drop.sinken><de> Lediglich für ein 905-nm-Lidar mit elektronischem Scan-Verfahren rechnet IHS mit einem Sinken des Stückpreises von aktuell 590 Dollar unter die 200-Dollar-Schwelle bis 2025.
<G-vec00418-001-s526><drop.sinken><en> The unemployment rate is expected to drop to 4.9% in 2019, whilst the number of people in work rises further to 45.2 million.
<G-vec00418-001-s526><drop.sinken><de> Die Arbeitslosenquote wird im Jahr 2019 voraussichtlich auf 4,9 Prozent sinken, die Zahl der Beschäftigten wird weiter auf 45,2 Millionen steigen.
<G-vec00418-001-s527><drop.sinken><en> Car buying motives, usage patterns, ownership patterns could change – and income from fuel tax could drop dramatically.
<G-vec00418-001-s527><drop.sinken><de> Kaufmotive und Nutzerverhalten können sich ändern – ebenso kann das Steuereinkommen aus der Mineralölsteuer stark sinken.
<G-vec00418-001-s528><drop.sinken><en> They unique in that their swim bladder is non-functional, meaning that when they’re not swimming, they drop to the bottom like a rock.
<G-vec00418-001-s528><drop.sinken><de> Kennzeichnend für diese Gruppe ist das Fehlen einer funktionsfähigen Schwimmblase, so dass sie nicht frei im Wasser schweben können, sondern wie ein Stein zu Boden sinken.
<G-vec00418-001-s529><drop.sinken><en> In earlier studies, the scientists calculated that as more turbines are installed in an area, the efficiency of wind turbines would drop.
<G-vec00418-001-s529><drop.sinken><de> In früheren Studien hatten die Wissenschaftler berechnet, dass die Effizienz von Windrädern sinken sollte, je mehr Turbinen in einem Gebiet errichtet werden.
<G-vec00418-001-s530><drop.sinken><en> This would, eventually,come at the cost of the user because (security) features would be be continually reduced and the user-friendliness would drop.
<G-vec00418-001-s530><drop.sinken><de> Das geht im Endeffekt zulasten der Verbraucher, da (Sicherheits-)Funktionen immer weiter abgespeckt werden und die Benutzerfreundlichkeit sinken wird.
<G-vec00418-001-s531><drop.sinken><en> According to forecasts, this year the employment numbers should again increase by about half a million, and the number of those registered as unemployed should again drop slightly.
<G-vec00418-001-s531><drop.sinken><de> Nach den Prognosen soll in diesem Jahr die Zahl der Erwerbstätigen noch einmal um etwa eine halbe Million steigen sowie die Zahl der registrierten Arbeitslosen noch einmal leicht sinken.
<G-vec00418-001-s532><drop.sinken><en> When there is perhaps a reduction in the need of the particular currency on the market or a rise within the offer, the worthiness of this currency will drop.
<G-vec00418-001-s532><drop.sinken><de> Wenn es vielleicht eine Verringerung der Notwendigkeit der jeweiligen Währung auf dem Markt oder ein Anstieg im Angebot, die Würdigkeit dieser Währung sinkt.
<G-vec00418-001-s533><drop.sinken><en> For men, levels of testosterone drop the older you get.
<G-vec00418-001-s533><drop.sinken><de> Bei Männern sinkt mit zunehmendem Alter der Testosteronspiegel.
<G-vec00418-001-s534><drop.sinken><en> The test results show the amount of time it takes for a battery to drop from 80% to 20%.
<G-vec00418-001-s534><drop.sinken><de> Als Ergebnis kommt die Zeitdauer heraus, in der der Akku von 80 Prozent auf 20 Prozent sinkt.
<G-vec00418-001-s535><drop.sinken><en> Second, a monetary policy which, say, aims to shore up financial markets in times of turmoil has to take into account a temporary drop in inflation when it reduces enterprises' funding costs.
<G-vec00418-001-s535><drop.sinken><de> Zweitens muss eine Geldpolitik, die etwa in turbulenten Zeiten die Finanzmärkte stützen will, damit rechnen, dass die Inflation vorübergehend sinkt, wenn sie die Finanzierungskosten der Unternehmen reduziert.
<G-vec00418-001-s536><drop.sinken><en> Rainy days also usually mean less sunlight, which makes your serotonin levels drop.
<G-vec00418-001-s536><drop.sinken><de> Regentage bedeuten normalerweise auch weniger Sonnenlicht, wodurch der Serotoninspiegel sinkt.
<G-vec00418-001-s537><drop.sinken><en> 2.Much security,when the glass is broken,it will not drop down and without harmful for human.
<G-vec00418-001-s537><drop.sinken><de> 2. viel Sicherheit, wenn das Glas gebrochen, ist es nicht sinkt nach unten und ohne schädlich für den menschlichen.
<G-vec00418-001-s538><drop.sinken><en> If your adrenaline levels drop, your sensory perception will become less acute, and your tinnitus will ease.
<G-vec00418-001-s538><drop.sinken><de> Wenn Ihr Adrenalinspiegel sinkt, wird Ihre sensorische Wahrnehmung weniger akut, und Ihr Tinnitus wird sich leichter.
<G-vec00418-001-s539><drop.sinken><en> Entire economies suffer when the water levels of Africa's huge rivers drop.
<G-vec00418-001-s539><drop.sinken><de> Ganze Wirtschaftszweige leiden, wenn der Wasserpegel der großen Flüsse Afrikas sinkt.
<G-vec00418-001-s540><drop.sinken><en> It can start when temperatures drop to minus 2.4 degrees.
<G-vec00418-001-s540><drop.sinken><de> Damit fängt man an, wenn das Thermometer auf -2,4° sinkt.
<G-vec00418-001-s541><drop.sinken><en> This beginner friendly strain will flower as long as the temperature does not drop below 10°C, so even growers living in the Benelux states, Germany, Poland and the Czech Republic can enjoy rearing her in their garden.
<G-vec00418-001-s541><drop.sinken><de> Diese anfängerfreundliche Sorte wird blühen, solange die Temperatur nicht unter 10°C sinkt, so daß auch Züchter, die in den Benelux Staaten, Deutschland, Polen und der Tschechischen Republik ihre Aufzucht in ihrem Garten genießen.
<G-vec00418-001-s542><drop.sinken><en> The rise in the price of the ounce of gold had a stimulating effect on the world production of gold, it prevented that the production of gold does not drop brutally.
<G-vec00418-001-s542><drop.sinken><de> Die Erhöhung des Preises von der Unze Gold hat eine anregende Wirkung auf die Goldweltproduktion gehabt, sie hat vermieden, daß die Goldproduktion grob sinkt.
<G-vec00418-001-s543><drop.sinken><en> Thanks to the nearby sea, the area enjoys a unique microclimate with a constant cooling breeze during summer and temperatures that rarely drop below freezing in winter.
<G-vec00418-001-s543><drop.sinken><de> Die Eigenschaften des Bodens und des Klimas in diesem Gebiet haben seit der Antike bewiesen, dass sie sich hervorragend für den Weinbau eignen: das Mikroklima zeichnet sich Dank des nahen Meeres im Sommer stets durch eine angenehme Brise aus, während die Temperatur im Winter nur sehr selten unter Null Grad sinkt.
<G-vec00418-001-s544><drop.sinken><en> The reduced pump function causes the oxygen supply to important organs such as the brain, the kidneys and the muscles to drop.
<G-vec00418-001-s544><drop.sinken><de> Als Folge der verminderten Pumpfunktion sinkt die Sauerstoffversorgung von wichtigen Organen wie dem Gehirn, den Nieren oder den Muskeln.
<G-vec00418-001-s545><drop.sinken><en> At constant absolute humidity, a rise in air temperature in the container results in a drop in relative humidity (see climate table).
<G-vec00418-001-s545><drop.sinken><de> Steigt bei gleichbleibender absoluter Luftfeuchte die Lufttemperatur im Container, sinkt gleichzeitig die relative Luftfeuchte (siehe Klimatabelle).
<G-vec00418-001-s546><drop.sinken><en> The software quality needs to correspond to expectations – otherwise, acceptance of the new solution will drop and your business model might be threatened.
<G-vec00418-001-s546><drop.sinken><de> Die Qualität der Software muss den Erwartungen entsprechen – sonst sinkt die Akzeptanz der neuen Lösung und damit kann Ihr Geschäftsmodell in Gefahr geraten.
<G-vec00418-001-s547><drop.sinken><en> As publishing companies seek to continually reduce their storage and logistics costs, the number of copies per title they print continues to drop as well.
<G-vec00418-001-s547><drop.sinken><de> Weil die Verlage kontinuierlich ihre Lager- und Logistikkosten reduzieren, sinkt die Anzahl Exemplare pro Titel im Verlagswesen kontinuierlich.
<G-vec00418-001-s548><drop.sinken><en> Increasing economic wealth is also viewed in a close context with rising GNH. Transport routes in the impassable mountain state, which is especially exposed to the climate, are important for both happiness and the economy: If the routes are not trafficable, many of the population’s basic needs cannot be satisfied, causing the GNH to drop.
<G-vec00418-001-s548><drop.sinken><de> Für beides spielen die Transportwege in dem unwegsamen und klimatisch exponierten Gebirgsstaat eine bedeutende Rolle: Sind sie nicht befahrbar, können viele Grundbedürfnisse der Bevölkerung nicht befriedigt werden und das BNG sinkt.
<G-vec00418-001-s549><drop.sinken><en> To reassure outdoor growers, Super Critical Autoflowering will flower as long as the temperature does not drop below 10°C, so even growers living in the Benelux states, Germany, Poland and the Czech Republic can enjoy rearing her in their garden and harvest multiple times throughout the year.
<G-vec00418-001-s549><drop.sinken><de> Um Züchter im Garten zu beruhigen, Super Critical Autoflowering wird blühen, solange die Temperatur nicht unter 10°C sinkt, so daß auch Züchter, die in den Benelux Staaten, Deutschland, Polen und der Tschechischen Republik leben, ihre Aufzucht in ihrem Garten genießen können und über das ganze Jahr mehrfach ernten.
<G-vec00418-001-s550><drop.sinken><en> Against this background, the unemployment rate will continue to drop to 6.3 percent this year and 5.9 percent in 2016.
<G-vec00418-001-s550><drop.sinken><de> Bei alledem sinkt die Arbeitslosenquote weiter auf 6,3 Prozent in diesem Jahr und auf 5,9 Prozent im kommenden Jahr.
<G-vec00418-001-s551><drop.tropfen><en> Charles Spurgeon said, “As the salt flavors every drop in the Atlantic, so does sin affect every atom of our nature.
<G-vec00418-001-s551><drop.tropfen><de> Charles Spurgeon sagte: „So wie das Salz jeden Tropfen des Atlantiks salzig macht, so beeinflusst Sünde jedes Atom unserer eigenen Natur.
<G-vec00418-001-s552><drop.tropfen><en> Drop test certified over 6ft, this case will show off the unique design of your device and provide shock and drop resistance.
<G-vec00418-001-s552><drop.tropfen><de> Drop-Test zertifiziert über 6ft, wird dieser Fall zeigen, die einzigartige Gestaltung Ihres Gerätes und bieten Schock und Tropfen Widerstand.
<G-vec00418-001-s553><drop.tropfen><en> Unlike traditional blends, Monkey Shoulder is made from 100% malt whisky (not a drop of grain whisky in there) resulting in an exceptional creation.
<G-vec00418-001-s553><drop.tropfen><de> Im Gegensatz zu den herkömmlichen Mischungen wird Monkey Shoulder aus 100 % Malt-Whisky hergestellt (hierin ist kein einziger Tropfen Grain-Whisky enthalten), wodurch eine außergewöhnliche Kreation entsteht.
<G-vec00418-001-s554><drop.tropfen><en> """We feel that what we are doing is just a drop in the ocean."
<G-vec00418-001-s554><drop.tropfen><de> """Wir wissen, was wir tun, ist nur ein Tropfen im Meer."
<G-vec00418-001-s555><drop.tropfen><en> A mighty wave is only a drop in the bucket of the Ocean.
<G-vec00418-001-s555><drop.tropfen><de> Eine mächtige Welle ist bloß ein Tropfen im Eimer des Ozeans.
<G-vec00418-001-s556><drop.tropfen><en> It is easy to measure blood pressure with small, modern devices where only a small drop of blood is required and the result comes after only about 20 seconds.
<G-vec00418-001-s556><drop.tropfen><de> Man kann seinen Blutzucker sehr einfach selber mit kleinen modernen Geräten messen, man benötigt bloß einen kleinen Tropfen Blut und das Ergebnis erscheint nach 20 Sekunden.
<G-vec00418-001-s557><drop.tropfen><en> And then the subtle systems: so you keep the one drop, and then you have two more drops, and then you have four more drops, and then you have eight more drops – and the full mandala's in each of them – and then you draw it back, in order.
<G-vec00418-001-s557><drop.tropfen><de> Zur Übung der subtilen Systeme behält man diesen einen Tropfen bei und visualisiert dann noch zwei weitere Tropfen, dann vier weitere und dann acht weitere Tropfen – und in jedem davon das komplette Mandala –, und dann zieht man all das der Reihe nach wieder zurück.
<G-vec00418-001-s558><drop.tropfen><en> By means of a blood drop sent by mail, Brown diagnosed and treated patients in their homes.
<G-vec00418-001-s558><drop.tropfen><de> Der Patient sendet einen Tropfen Blut, und blieb für die Diagnose und Behandlung einfach zuhause.
<G-vec00418-001-s559><drop.tropfen><en> It is to set apart people who are washed themselves from the stains of sins and iniquities without blemish in splendour and glory that I sent My Son and allowed Him to die on the Cross stretching out His arms and shedding even the last drop of His blood.
<G-vec00418-001-s559><drop.tropfen><de> Dazu habe ich Meinen Sohn gesandt, daß die Menschen von den Steinen der Sünden und Frevel gewaschen, ohne Fehler in Glanz und Herrlichkeit sind, und Ihm erlaubt, Seine Arme auszustrecken, um am Kreuz zu sterben und selbst den letzten Tropfen Seines Blutes zu vergießen.
<G-vec00418-001-s560><drop.tropfen><en> Tape made of welded polyethylene - on a seam while weldingleave tiny holes through which the water trickles drop by drop.
<G-vec00418-001-s560><drop.tropfen><de> Band aus verschweißten Polyethylen - auf einer Naht während Schweißlassen winzige Löcher, durch die das Wasser Tropfen für Tropfen rinnt.
<G-vec00418-001-s561><drop.tropfen><en> They were not allowed to move one bit, or spill one drop of water.
<G-vec00418-001-s561><drop.tropfen><de> Sie durften sich nicht einen Millimeter bewegen oder auch nur einen Tropfen Wasser verschütten.
<G-vec00418-001-s562><drop.tropfen><en> The crystals are usually grown by vapor diffusion, typically by the hanging drop method where a drop of protein solution is suspended over a reservoir containing buffer and precipitant.
<G-vec00418-001-s562><drop.tropfen><de> Die Kristalle werden in der Regel durch Dampfdiffusion gezüchtet, meist nach der „Hanging-Drop“-Methode, bei der ein Tropfen einer Proteinlösung über ein Reservoir mit Puffer und Ausfällungsreagenz gehängt wird.
<G-vec00418-001-s563><drop.tropfen><en> Given the situation in the regions of origin with more than a million refugees, the admission of 2.500 people by Germany remains a drop in the ocean.
<G-vec00418-001-s563><drop.tropfen><de> Angesichts der Lage in der Herkunftsregion mit weit mehr als einer Million Flüchtlinge bleibt die Aufnahme von 2.500 Menschen in Deutschland ein Tropfen auf den heißen Stein.
<G-vec00418-001-s564><drop.tropfen><en> This dress has a wide neckline V. The sleeves are short with little drop and a short skirt that reaches the thigh.
<G-vec00418-001-s564><drop.tropfen><de> Dieses Kleid hat einen weiten Ausschnitt V. Die Ärmel sind kurz mit kleinen Tropfen und einem kurzen Rock, der den Oberschenkel erreicht.
<G-vec00418-001-s565><drop.tropfen><en> The roll-off angle corresponds to the angle of surface inclination at the moment the drop changes its position and slides or rolls off the surface.
<G-vec00418-001-s565><drop.tropfen><de> Der Abrollwinkel entspricht dem Neigewinkel der Oberfläche, bei welchem der Tropfen seine Position ändert und abrollt oder abgleitet.
<G-vec00418-001-s566><drop.tropfen><en> There were many people like Xiang Xiong in the Chinese history, so there is a Chinese saying: when one receives a kindness even so little as a drop from others, he/she ought to repay it with a spring.
<G-vec00418-001-s566><drop.tropfen><de> "In der chinesischen Geschichte gibt es viele Menschen, wie Xiang Xiong, deshalb gibt es ein chinesisches Sprichwort: ""Wenn einer von anderen eine Gefälligkeit erhält, die nur so groß ist, wie ein Tropfen, sollte er diese mit einer Quelle zurückzahlen."
<G-vec00418-001-s567><drop.tropfen><en> To expose the look, you can apply a highlighter or a drop of nacre shadows under the eyebrow curve.
<G-vec00418-001-s567><drop.tropfen><de> Um das Aussehen freizulegen, können Sie einen Highlighter oder einen Tropfen Perlmuttschatten unter der Augenbrauenkurve anbringen.
<G-vec00418-001-s568><drop.tropfen><en> All this is complimented by a good drop of wine from our own wine cellar.
<G-vec00418-001-s568><drop.tropfen><de> Ergänzt wird das Ganze durch edle Tropfen aus dem hauseigenen Weinkeller.
<G-vec00418-001-s569><drop.tropfen><en> The motorized lift automatically actuates the dosing height or places the drop carefully on the sample.
<G-vec00418-001-s569><drop.tropfen><de> Der motorische Lift steuert die Dosierhöhe automatisch an oder setzt die Tropfen behutsam auf der Probe ab.
<G-vec00418-001-s608><drop.verlieren><en> The HCA, as in Hydroxycitric Acid, is the part that really aids you drop weight.
<G-vec00418-001-s608><drop.verlieren><de> Die HCA, wie Hydroxycitric Säure, ist die Komponente, die tatsächlich hilft Ihnen Gewicht zu verlieren.
<G-vec00418-001-s609><drop.verlieren><en> Despite the fact that this is commonly considereded the best method to drop weight, some previous customers assert that they have not resorted to any type of exercise after taking PhenQ as well as have still skilled large weight reduction.
<G-vec00418-001-s609><drop.verlieren><de> Obwohl diese wird weitgehend als das wirksamste Mittel considereded um Gewicht zu verlieren, einige frühere Kunden behaupten, dass sie nach der Einnahme von PhenQ nicht auf jede Art von Übung gemacht haben und auch noch gewürzt großen Gewichts-Management haben.
<G-vec00418-001-s610><drop.verlieren><en> If you're searching for a significant method to drop weight, and to have that weight stay off too, the fact that Dr. Oz suggests Garcinia cambogia extract must be incredibly encouraging to folks in Ruggell Liechtenstein.
<G-vec00418-001-s610><drop.verlieren><de> Wenn Sie suchen nach einem sinnvollen Weg, Gewicht zu verlieren und das Gewicht auch bleiben haben, sollte die Tatsache, die Dr. Oz Garcinia Cambogia empfiehlt sehr ermutigend für die Menschen in Ruggell Liechtenstein.
<G-vec00418-001-s611><drop.verlieren><en> With so many people in the world wanting to drop weight, the weight-loss drug market is consistently going to be strong.
<G-vec00418-001-s611><drop.verlieren><de> Mit vielen Menschen auf der ganzen Welt planen, Gewicht zu verlieren, ist die Gewichtsreduktion Drogenmarkt konsequent gehen, stark zu sein.
<G-vec00418-001-s612><drop.verlieren><en> You could drop weight with routine diet/exercise likewise but just what's making this supplement so preferred is that it will securely increase the procedure.
<G-vec00418-001-s612><drop.verlieren><de> Sie können Gewicht verlieren mit regelmäßiger Ernährung/Bewegung auch, aber was diese Ergänzung so beliebt macht, ist, dass es den Prozess sicher beschleunigen wird.
<G-vec00418-001-s613><drop.verlieren><en> A PhenQ review discussed people's experiences, as well as concerning how excellent they felt to understand that there was a reliable solution offered in the market that helped them drop weight.
<G-vec00418-001-s613><drop.verlieren><de> Ein PhenQ Auswertung sprach über Begegnungen von Menschen, und auch in Bezug auf, wie exzellent sie zu erkennen, dass es eine effiziente Möglichkeit, auf dem Markt, die sie Gewicht zu verlieren geholfen angeboten fühlte.
<G-vec00418-001-s614><drop.verlieren><en> There are lots of reasons that people drop their hair.
<G-vec00418-001-s614><drop.verlieren><de> Es gibt Angebote von Faktoren, die Menschen verlieren ihre Haare.
<G-vec00418-001-s615><drop.verlieren><en> Any type of doctor or dietitian will tell you that in order to drop weight, you have to reduce calorie consumption, eat healthy types of foods and workout routinely.
<G-vec00418-001-s615><drop.verlieren><de> Jede Art von Arzt oder Ernährungsberater informieren Sie, dass, um Gewicht zu verlieren, müssen Sie den Kalorienverbrauch verringern, gesund essen Arten von Lebensmitteln sowie Training häufig.
<G-vec00418-001-s616><drop.verlieren><en> You can customize your diet regimen and include in additional activity to obtain more weight loss, or you can merely drop weight without worrying.
<G-vec00418-001-s616><drop.verlieren><de> Sie können Ihre Ernährung zu ändern und hinzufügen extra activity zu mehr Gewichtsverlust oder kann man nur Gewicht verlieren, ohne Hervorhebung.
<G-vec00418-001-s617><drop.verlieren><en> You could tweak your diet and add in extra activity to obtain more weight loss, or you could just drop weight without pressuring.
<G-vec00418-001-s617><drop.verlieren><de> Sie können Ihre Ernährung zu ändern und hinzufügen extra activity zu mehr Gewichtsverlust oder kann man nur Gewicht verlieren, ohne Hervorhebung.
<G-vec00418-001-s618><drop.verlieren><en> This implies that you will drop weight more quickly, seeing lead to less time.
<G-vec00418-001-s618><drop.verlieren><de> Dies impliziert, dass Sie Gewicht schneller zu verlieren, sehen Ergebnisse in viel kürzerer Zeit.
<G-vec00418-001-s619><drop.verlieren><en> Just what the supplement does, is it keeps your metabolism working outing efficiently, hence enabling you to drop weight.
<G-vec00418-001-s619><drop.verlieren><de> Was die Ergänzung der Fall ist, ist es hält Ihr Stoffwechsel arbeitet so effizient, so dass Sie, Gewicht zu verlieren.
<G-vec00418-001-s620><drop.verlieren><en> Raspberry ketones Gambia has actually already assisted countless Gambia individuals to drop weight and we below from our customer frequently telling us exactly how our formula has actually helped them.
<G-vec00418-001-s620><drop.verlieren><de> Himbeer Ketone Masescha Liechtenstein hat bereits dazu beigetragen, Tausende von Masescha Liechtenstein-Menschen, um Gewicht zu verlieren und wir hier unsere Kunden regelmäßig uns mitzuteilen, wie unsere Formel, die ihnen geholfen hat.
<G-vec00418-001-s621><drop.verlieren><en> The pill is made to assist you drop weight therefore you have to aid it help you.
<G-vec00418-001-s621><drop.verlieren><de> Die Pille wurde entwickelt, um Ihnen helfen, Gewicht zu verlieren und so sollten Sie zu unterstützen ist es Ihnen zu helfen.
<G-vec00418-001-s622><drop.verlieren><en> What the supplement does, is it keeps your metabolic process working out efficiently, hence enabling you to drop weight.
<G-vec00418-001-s622><drop.verlieren><de> Was die Ergänzung der Fall ist, ist es hält Ihr Stoffwechsel arbeitet so effizient, so dass Sie, Gewicht zu verlieren.
<G-vec00418-001-s623><drop.verlieren><en> Any type of doctor or dietitian will certainly tell you that in order to drop weight, you need to decrease calorie intake, consume nourishing types of foods as well as workout consistently.
<G-vec00418-001-s623><drop.verlieren><de> Jede Art von Arzt oder Ernährungsberater werden Sie sicherlich informieren, dass, um Gewicht zu verlieren, Sie zu niedrigeren Kalorienverbrauch haben, essen nahrhaft Arten von Lebensmitteln und Training routinemäßig.
<G-vec00418-001-s624><drop.verlieren><en> You could expect to drop body fat and additionally get leaner, a lot more powerful and also fitter and also a matter of a number of months of taking it.
<G-vec00418-001-s624><drop.verlieren><de> Man könnte erwarten, dass auch Körperfett zu verlieren, wie ebenfalls erhalten schlanker, viel stärker und fitter sowie eine Angelegenheit von ein paar Monaten, nachdem es nehmen.
<G-vec00418-001-s625><drop.verlieren><en> The fact that 11 extra pounds were dropped in two weeks reveals exactly how rapidly you can drop weight utilizing this medication.
<G-vec00418-001-s625><drop.verlieren><de> , Dass 11 zusätzliche Pfunde wurden in zwei Wochen fallen gelassen zeigt genau, wie schnell man Gewicht verlieren die Verwendung dieser Medikamente.
<G-vec00418-001-s626><drop.verlieren><en> Let's check out just what the raspberry ketones do and just how they help you drop weight.
<G-vec00418-001-s626><drop.verlieren><de> Lassen Sie uns betrachten, was die Himbeere Ketone tun und wie sie helfen, Gewicht zu verlieren.
<G-vec00321-002-s056><drop.ablegen><en> If your shapes are already on the page, you can drag a connector from a blue AutoConnect arrow of one shape and drop it on another shape.
<G-vec00321-002-s056><drop.ablegen><de> Wenn sich die Shapes bereits auf dem Zeichenblatt befinden, können Sie einen Verbinder von einem blauen AutoVerbinden-Pfeil eines Shapes ziehen und auf einem anderen Shape ablegen.
<G-vec00321-002-s058><drop.ablegen><en> If you drop a dimension into the middle zone, a report is automatically run that inserts the top items for that dimension.
<G-vec00321-002-s058><drop.ablegen><de> Wenn Sie eine Dimension in der mittleren Dropzone ablegen, wird automatisch ein Bericht ausgeführt, der die obersten Elemente für diese Dimension einfügt.
<G-vec00321-002-s060><drop.ablegen><en> Simply drag & drop an audio file to your phone to make it available as a ringtone.
<G-vec00321-002-s060><drop.ablegen><de> Einfach Audiodateien per Ziehen und Ablegen auf dem iPhone speichern und schon sind sie als Klingelton verfügbar.
<G-vec00321-002-s061><drop.ablegen><en> Choose file Open or drag&drop a video from your Mac, Windows computer or other device.
<G-vec00321-002-s061><drop.ablegen><de> Datei auswählen Ein Video von Ihrem Computer oder Handy öffnen oder ziehen und ablegen.
<G-vec00321-002-s062><drop.ablegen><en> You can drag the files to be copied onto the desktop of your Mac (see Method 1) or open the Finder if you want to drop the files at another storage location.
<G-vec00321-002-s062><drop.ablegen><de> Sie haben also die Möglichkeit entweder die zu kopierenden Dateien auf Ihren Schreibtisch / Desktop ihres Macs zu ziehen (siehe Methode 1), oder Sie öffnen den Finder, wenn Sie die Dateien an einen anderen Speicherplatz ablegen möchten.
<G-vec00321-002-s063><drop.ablegen><en> Drag and Drop a file from Mac to Windows doesn’t work.
<G-vec00321-002-s063><drop.ablegen><de> Das Ziehen und Ablegen einer Datei von Mac auf Windows funktioniert nicht.
<G-vec00321-002-s064><drop.ablegen><en> Tipically, your work day will start with helping in the morning: breakfast, dress-up and drop in the kindergarten (3 min walking distance).
<G-vec00321-002-s064><drop.ablegen><de> In der Regel beginnt Ihr Arbeitstag mit der morgendlichen Hilfe: Frühstück, Anziehen und Ablegen im Kindergarten (3 Minuten zu Fuß).
<G-vec00321-002-s065><drop.ablegen><en> Drag and drop of plans and actions supports copy, move and delete operations.
<G-vec00321-002-s065><drop.ablegen><de> Ziehen und Ablegen von Plänen und Aktionen unterstützt Kopieren, Verschieben und Löschen von Operationen.
<G-vec00321-002-s066><drop.ablegen><en> You can drag and drop photos, audio and video from the media library to the timeline in the order you want them to appear.
<G-vec00321-002-s066><drop.ablegen><de> Sie können Fotos, Audio- und Videomaterial aus der Medienbibliothek in der gewünschten Reihenfolge auf die Zeitachse ziehen und ablegen.
<G-vec00321-002-s067><drop.ablegen><en> Just feel free to drag, drop and edit them to meet different situations or create special shapes to meet special requirements with prepared drawing tools.
<G-vec00321-002-s067><drop.ablegen><de> Sie können sie einfach ziehen, ablegen und bearbeiten, um verschiedenen Situationen gerecht zu werden, oder spezielle Formen erstellen, um spezielle Anforderungen mit vorbereiteten Zeichenwerkzeugen zu erfüllen.
<G-vec00321-002-s068><drop.ablegen><en> You can then drop the items into the folder or any subfolders under it.
<G-vec00321-002-s068><drop.ablegen><de> Sie können die Elemente dann im Ordner oder in einem beliebigen Unterordner ablegen.
<G-vec00321-002-s069><drop.ablegen><en> Or you can drag more swimlane shapes from the Shapes window and drop them when you see the orange connection indicator.
<G-vec00321-002-s069><drop.ablegen><de> Sie können aber auch weitere Verantwortlichkeitsbereich-Shapes aus dem Fenster Shapes ziehen und ablegen, wenn der orangefarbene Verbindungsanzeiger eingeblendet wird.
<G-vec00321-002-s070><drop.ablegen><en> A table is hung in the library with a basket where you can drop off the book you read and write your opinion on it in order to recommend it to other guests.
<G-vec00321-002-s070><drop.ablegen><de> In der Bibliothek wird eine Tafel mit einem Korb aufgehängt, in dem Sie das Buch, das Sie lesen, ablegen und Ihre Meinung dazu schreiben können, um es anderen Gästen zu empfehlen.
<G-vec00321-002-s071><drop.ablegen><en> If I had to take this distribution, came to me when you drop it on the side table special thoughts.
<G-vec00321-002-s071><drop.ablegen><de> Wenn ich diese Verteilung übernehmen musste, kamen mir beim Ablegen auf die Beistelltischchen ganz besondere Gedanken.
<G-vec00321-002-s072><drop.ablegen><en> You can also drag and drop existing pages into the Index.
<G-vec00321-002-s072><drop.ablegen><de> Sie können auch bestehende Seiten mit der Maus in den Index ziehen und ablegen.
<G-vec00321-002-s073><drop.ablegen><en> Create Drag and drop filters, transitions and high-impact titles.
<G-vec00321-002-s073><drop.ablegen><de> Fügen Sie per Ziehen und Ablegen Filter, Übergänge und wirkungsstarke Titel ein.
<G-vec00321-002-s074><drop.ablegen><en> A user can add or replace a project logo in several ways – with drag and drop or by pressing on a logo area.
<G-vec00321-002-s074><drop.ablegen><de> Ein Benutzer kann hinzufügen oderersetzen ein Projekt Logo auf verschiedene Arten - durch Ziehen und Ablegen oder durch Drücken auf einen Logo-Bereich.
<G-vec00321-002-s075><drop.absetzen><en> Airport pick up or drop off (by car) available on request.
<G-vec00321-002-s075><drop.absetzen><de> Flughafen abholen oder absetzen (mit dem Auto) auf Anfrage erhältlich.
<G-vec00321-002-s076><drop.absetzen><en> Your holiday at the Gran Hotel Son Net will have only just begun once you drop off your luggage at reception.
<G-vec00321-002-s076><drop.absetzen><de> Ihr Urlaub im Gran Hotel Son Net wird gerade erst begonnen haben, wenn Sie Ihr Gepäck in Ihrem Zimmer absetzen.
<G-vec00321-002-s077><drop.absetzen><en> Learn how to pick up and drop off riders at IAH Airport.
<G-vec00321-002-s077><drop.absetzen><de> Erfahre, wie du Fahrgäste am Flughafen EWR abholen und absetzen kannst.
<G-vec00321-002-s079><drop.absetzen><en> After that, we’ll drop you into the area formerly known as the San Francisco Bay Area and set you loose to hunt for Arktech. Good luck.
<G-vec00321-002-s079><drop.absetzen><de> Danach werden wir dich in einer Gegend absetzen, die vormals als San Francisco Bay Area bekannt war und du wirst dich auf der Jagd nach Archentech begeben.
<G-vec00321-002-s080><drop.absetzen><en> Just click icon and then drag & drop any music or playlist from Spotify to Sidify Music converter.
<G-vec00321-002-s080><drop.absetzen><de> Klick Sie einfach auf der Schaltfläche " " und dann ziehen und absetzen beliebige Musikdateien oder Wiedergabelisten von Spotify zu Spotify Music Converter.
<G-vec00321-002-s081><drop.absetzen><en> Not included: Meals, driver’s gratuity, and drop off at the hotel is not included as we drop you off at Pier 39 to enjoy your bay cruise trip and then return to your hotel on your own, overtime and optional activities or features.
<G-vec00321-002-s081><drop.absetzen><de> Nicht enthalten: Mahlzeiten, Trinkgeld für den Fahrer, Rückfahrt zu Ihrem Hotel, da wir Sie am Pier 39 absetzen, wo Sie an Bord der Bootstour gehen, Überstunden und andere optionale Aktivitäten oder Angebote.
<G-vec00321-002-s082><drop.absetzen><en> The beauty of the Abel Tasman Coastal Track is that you can decide which section of the 4 day Great Walk you would like to do, as water taxis can drop you off at different locations on the track, as well as pick you up again.
<G-vec00321-002-s082><drop.absetzen><de> Das Schöne am Abel Tasman Coastal Track ist, dass Sie entscheiden können, welchen Abschnitt des 4 Day Great Walk Sie machen möchten, da Wassertaxis Sie an verschiedenen Stellen des Tracks absetzen und Sie auch wieder abholen können.
<G-vec00321-002-s083><drop.absetzen><en> We will drop you off on the waterfront to give you time for exploring this charming old Dalmatian town.
<G-vec00321-002-s083><drop.absetzen><de> Wir werden Sie an der Küste absetzen, um Ihnen Zeit zu geben, diese charmante alte dalmatinische Stadt zu erkunden.
<G-vec00321-002-s084><drop.absetzen><en> Driving with Uber at SBA Airport Learn how to pick up and drop off riders at SBA Airport.
<G-vec00321-002-s084><drop.absetzen><de> In unserem SYD-Guide für Fahrer erfährst du, wie du Fahrgäste am Flughafen abholen und absetzen kannst.
<G-vec00321-002-s085><drop.absetzen><en> The cheaper and more convenient option is to catch the Greenline 757 service which will drop you off at Finchley Road tube station.
<G-vec00321-002-s085><drop.absetzen><de> Die Option billigere und bequemere ist, den Greenline-757-Dienst zu fangen, der Sie an der Bahnstation Finchley Road absetzen wird.
<G-vec00321-002-s086><drop.absetzen><en> Pros: Painless and easy drop off.
<G-vec00321-002-s086><drop.absetzen><de> Positiv: Schnell und einfach absetzen.
<G-vec00321-002-s087><drop.absetzen><en> Once you arrive at the exhibition halls our staff will point out where you can stop to drop off your passengers.
<G-vec00321-002-s087><drop.absetzen><de> An den Messehallen erhalten Sie von unserem Personal Instruktionen wo Sie halten und Ihre Passagiere absetzen können.
<G-vec00321-002-s089><drop.absetzen><en> A bus ride to New Haven will drop you off at Union Ave.
<G-vec00321-002-s089><drop.absetzen><de> Ein Bus nach New Haven wird Sie an der Station Union Ave absetzen.
<G-vec00321-002-s090><drop.absetzen><en> * Can drop satellites.
<G-vec00321-002-s090><drop.absetzen><de> * Der Explorer kann Satelliten absetzen.
<G-vec00321-002-s091><drop.absetzen><en> Included: Pick up and drop off at hotels in Reykjavik, super jeep tour, accommodation in mountain huts and a farm, in sleeping bags (sleeping bag included), meals from dinner on Day 1 to breakfast on Day 5. Optional: We offer an exciting snowmobiling tour on Langjokull glacier as an optional extra
<G-vec00321-002-s091><drop.absetzen><de> Inklusive: Abholung und Absetzen in Reykjavík, Tour um den Goldenen Kreis, Hochland-Abenteuer im Super Jeep, Hotelzimmer mit eigenem Badezimmer - 2 Nächte, 2 Abendessen, 2 Frühstücke und 1 Mittagessen, Schneemobil-Fahrt, Helm und Anzug, Schneeschuhe/Wanderstöcke, Minibus-Tour zur Geheimen Lagune und Eintritt zur Geheimen Lagune.
<G-vec00321-002-s092><drop.absetzen><en> Users can drop off their clothes in the locke and pick up anytime after cleaning.
<G-vec00321-002-s092><drop.absetzen><de> Benutzer können ihre Kleidung im locke absetzen und jederzeit aufheben, nachdem sie gesäubert haben.
<G-vec00321-002-s093><drop.absetzen><en> For everyday multi-tasking simply remove the pods from the main bag and attach onto any stroller, or drop off at nursery.
<G-vec00321-002-s093><drop.absetzen><de> Für Multitasking im Alltag, ziehen Sie die Pods von der Tasche aus und befestigen sie auf dem Griff der Kinderwagen, oder absetzen sie im Kindergarten.
<G-vec00321-002-s094><drop.absinken><en> After a temperature drop of 5 K below the limit set point, or after a fault has been remedied, the limiter can be re-activated by means of a re-set button on the device itself or via a remote re-set control.
<G-vec00321-002-s094><drop.absinken><de> Nach Absinken der Temperatur um 5 K unter den Abschaltpunkt oder nach einer Fehlerbehebung, kann der Begrenzer durch eine Entriegelungstaste am Gerät oder über Fernentriegelung wieder in Betrieb genommen werden.
<G-vec00321-002-s095><drop.absinken><en> The interaction of external factors like climate change, population growth, and land use calls for regional adaption strategies to ensure fair and sustainable water availability, and to reduce the drop of the groundwater level and therefore the mobilization of saline groundwater.
<G-vec00321-002-s095><drop.absinken><de> Das Zusammenwirken externer Einflussfaktoren wie Klimawandel, Bevölkerungswachstum, Landnutzung erfordert regionale Anpassungsstrategien, um eine gerechte und nachhaltige Wasserverfügbarkeit sicherzustellen, sowie das Absinken der Grundwasserspiegel und eine Mobilisierung tiefer versalzter Grundwässer zu reduzieren.
<G-vec00321-002-s096><drop.absinken><en> But they find it equally likely that their living standards might drop even lower than they are today.
<G-vec00321-002-s096><drop.absinken><de> Auf der anderen Seite scheint es ihnen aber ebenso wahrscheinlich, dass ihr heutiger Lebensstandard noch absinken könnte.
<G-vec00321-002-s097><drop.absinken><en> Everything indicates that the mercury column in thermometers can drop even by several degrees.
<G-vec00321-002-s097><drop.absinken><de> Alles deutet darauf hin, dass die Quecksilbersäule in Thermometern sogar um mehrere Grad absinken kann.
<G-vec00321-002-s098><drop.absinken><en> On a meat chicken farm the temperatures also mustn’t drop too much in the cold season.
<G-vec00321-002-s098><drop.absinken><de> Auch in der Hähnchenmast dürfen die Temperaturen in der kalten Jahreszeit nicht allzu sehr absinken.
<G-vec00321-002-s099><drop.absinken><en> Remember that you wanted to experience duality, and pit yourself against the lower vibrations that it was foreseen you would drop into.
<G-vec00321-002-s099><drop.absinken><de> Bedenkt, dass ihr einst den Wunsch hattet, die Dualität zu erfahren und euch dabei den niederen Schwingungen auszusetzen, sodass vorauszusehen war, dass ihr in eurer Eigenschwingung entsprechend absinken würdet.
<G-vec00321-002-s100><drop.absinken><en> · PRP-T101C is the best functionality and ergonomics for user application, high temperature, low temperature, shock, vibration, drop.
<G-vec00321-002-s100><drop.absinken><de> · PRP-T101C ist die beste Funktionalität und die Ergonomie für Benutzeranwendung, Hochtemperatur-, niedrige Temperatur, Schlag, Schwingung, Absinken.
<G-vec00321-002-s101><drop.absinken><en> Here a vascular constriction is often indicated early by a drop in the PWV, sometimes much earlier than the drop of ABI under the value of 1.0.
<G-vec00321-002-s101><drop.absinken><de> Hier deutet sich eine Gefäßverengung häufig recht früh in einem Absinken der PWV an, teilweise deutlich früher als das Absinken des ABI unter den Wert von 1,0.
<G-vec00321-002-s103><drop.absinken><en> Electro spinning is a process by which a suspended drop of polymer is charged with thousands of volts.
<G-vec00321-002-s103><drop.absinken><de> Das Galvanospinnen ist ein Prozess, durch den ein verschobenes Absinken des Polymers mit Tausenden Volt aufgeladen wird.
<G-vec00321-002-s104><drop.absinken><en> At first, when leakage is small, the drop in packing liquid level may not be realised by the user, so he/she does not realise that the measurement is wrong.
<G-vec00321-002-s104><drop.absinken><de> Zuerst, wenn die Leckage gering ist, wird das Absinken des Flüssigkeitspegels vom Anwender nicht bemerkt und es wird mit falschen Messwerten gearbeitet.
<G-vec00321-002-s105><drop.absinken><en> It grows into a stout plant and can develop eye-catching red, purple and blue shades during its flowering period when night-time temperatures drop by 10°C or so.
<G-vec00321-002-s105><drop.absinken><de> Sie wächst zu einer kräftigen Pflanze heran und kann während der Blütezeit, wenn die Nachttemperaturen um 10 Grad absinken, auffällige Rot-, Violett- und Blautöne entwickeln.
<G-vec00321-002-s106><drop.absinken><en> Moderately hardy, can withstand short-term drop in temperature to -25 C. Very decorative to its slender growth, beautiful pyramidal crown and dark thick needles.
<G-vec00321-002-s106><drop.absinken><de> Mäßig winterhart, übersteht kurzfristige Absinken der Temperatur bis -25 ° C. Sehr dekorativ, seine schlanken Wuchs, schöne pyramidenförmige Krone und dunklen dicken Nadeln.
<G-vec00321-002-s107><drop.absinken><en> The trial result: A gradual drop in temperature and rapid convergence to outside temperatures was recognisable in both film tubes.
<G-vec00321-002-s107><drop.absinken><de> Das Versuchsergebnis: In beiden Folienschläuchen ist das allmähliche Absinken der Temperatur und eine rasche Annäherung an die Außentemperaturen zu erkennen.
<G-vec00321-002-s108><drop.absinken><en> By doing some cool-down exercises, your blood will spread over your body again and your heart rate can drop to normal levels.
<G-vec00321-002-s108><drop.absinken><de> Durch einige Abkühlübungen verteilt sich Ihr Blut wieder über Ihren Körper und Ihre Herzfrequenz kann auf ein normales Niveau absinken.
<G-vec00321-002-s109><drop.absinken><en> During this period, there was a cooling of the climate all over the planet, along with with extensive glaciations and a drop in sea level.
<G-vec00321-002-s109><drop.absinken><de> In dieser Periode kam es zu einer Abkühlung des Klimas auf der ganzen Erde, verbunden mit weiträumigen Vergletscherungen und einem Absinken des Meeresspiegels.
<G-vec00321-002-s110><drop.absinken><en> If the net calorific value of these secondary fuels is too low, there will be a critical drop in temperature: Therefore, the quality of the clinker will be reduced.
<G-vec00321-002-s110><drop.absinken><de> Fällt der Heizwert dieser Ersatzbrennstoffe zu gering aus, kommt es zu einem kritischen Absinken der Temperatur und somit zu einer Qualitätsminderung des Klinkers.
<G-vec00321-002-s111><drop.absinken><en> The series equipment for voltage failure detection UVS ensures that a drop in supply voltage does not go unnoticed.
<G-vec00321-002-s111><drop.absinken><de> Die serienmäßige Ausstattung mit der Spannungsausfall-Erkennung UVS® sorgt dafür, dass ein Absinken der Versorgungsspannung nicht unbemerkt bleibt.
<G-vec00321-002-s112><drop.absinken><en> The ability of the E5_C to read and react to any drop in temperature means that the quality of the seal is maintained while operating at high or low speeds.
<G-vec00321-002-s112><drop.absinken><de> Die Fähigkeit des E5_C, jedes Absinken der Temperatur zu erfassen und darauf zu reagieren, bedeutet, dass die Qualität der Versiegelung bei hohen wie auch niedrigen Arbeitsgeschwindigkeiten beibehalten wird.
<G-vec00321-002-s132><drop.bringen><en> To register your child for aftercare/supervised study please complete the registration form and send it to admin@kilians.com or drop it into the Administration Office.
<G-vec00321-002-s132><drop.bringen><de> Um Ihr Kind für die Nachmittagsbetreuung anzumelden, füllen Sie bitte das Anmeldeformular aus und senden es an admin@kilians.com oder bringen es im Administrationsbüro vorbei.
<G-vec00321-002-s133><drop.bringen><en> If your trip in Kiel is shortly coming to end then we'll drop you straight outside Hauptbahnhof train station so that you can jump straight onto your train!
<G-vec00321-002-s133><drop.bringen><de> Wenn Ihre Zeit in Kiel sich dem Ende zuneigt, können wir Sie gerne direkt zum Hauptbahnhof bringen, damit Sie Ihren Zug erwischen.
<G-vec00321-002-s134><drop.bringen><en> After our Gorge excursion, we will drop you at the Portland Spirit where you will take an evening dinner cruise on the Willamette River.
<G-vec00321-002-s134><drop.bringen><de> Nach unserem Ausflug bringen wir Sie zum Portland Spirit, wo Sie eine Bootsfahrt mit Abendessen auf dem Willamette River machen.
<G-vec00321-002-s135><drop.bringen><en> Follow the directions to the parking bay, and see if you can safely drop this huge vehicle off in the parking lot with the same ease.
<G-vec00321-002-s135><drop.bringen><de> Folge den Anweisungen zum Parkplatz und schaue, ob du dieses riesige Fahrzeug mit der gleichen Leichtigkeit sicher auf den Parkplatz bringen kannst.
<G-vec00321-002-s136><drop.bringen><en> We will pick you up and drop you off in your accommodation in Kuta, Seminyak, Nusa Dua, Jimbaran, Sanur or Ubud.
<G-vec00321-002-s136><drop.bringen><de> Wir holen Sie ab und bringen Sie in Ihre Unterkunft in Kuta, Seminyak, Nusa Dua, Jimbaran, Sanur oder Ubud.
<G-vec00321-002-s137><drop.bringen><en> We drop you off at your beach campsite for a relaxing evening under the stars.
<G-vec00321-002-s137><drop.bringen><de> Wir bringen Sie zu Ihrem Strandcampingplatz.
<G-vec00321-002-s138><drop.bringen><en> We pick up your child from your hotel, your office or any other place. We spend the day with your child offering an individually arranged programme and drop them off at the agreed time and place.
<G-vec00321-002-s138><drop.bringen><de> Wir holen Ihr Kind vom Hotel, der Firma oder einer anderen Wunschadresse ab, übernehmen die Gestaltung dieses Tages und bringen es zum vereinbarten Zeitpunkt wieder zurück.
<G-vec00321-002-s139><drop.bringen><en> Concerts and festivities, whether at the Cannstatter Wasen or at the Porsche Arena/Hanns-Martin-Schleyer Event-Hall are all accessible via subway: Please note that S1, S2 and S3 will drop you off right at the front door.
<G-vec00321-002-s139><drop.bringen><de> Konzerte und Feste, ob auf dem Cannstatter Wasen oder in der Porsche-Arena / Hanns-Martin-Schleyerhalle: Die S-Bahnen S1, S2 und S3 bringen Sie direkt von Haustür zu Haustür.
<G-vec00321-002-s140><drop.bringen><en> We will pick you up and drop you off in your accommodation in Bagan.
<G-vec00321-002-s140><drop.bringen><de> Wir holen Sie ab und bringen Sie zu Ihrer Unterkunft in Bagan.
<G-vec00321-002-s141><drop.bringen><en> You can also park your car with one of the Taxi transfer companies (like Taxi / Parking Christophe) who will then transfer you by car up to Zermatt Urania Taxi drop off point.
<G-vec00321-002-s141><drop.bringen><de> Sie können Ihr Auto auch bei einer der Taxi-Transferfirmen (wie Taxi / Parking Christophe) parken, die Sie dann mit dem Auto zur Taxi Haltestelle Urania in Zermatt bringen.
<G-vec00321-002-s142><drop.bringen><en> Day 13: Drive to Brisbane and drop off your rental car at Brisbane City depot.
<G-vec00321-002-s142><drop.bringen><de> Tag 13: Fahren Sie nach Brisbane und bringen Sie Ihren Mietwagen zum Brisbane City Depot.
<G-vec00321-002-s143><drop.bringen><en> Alternately, use public transport or ask a friend/relative to drop you home.
<G-vec00321-002-s143><drop.bringen><de> Alternativ kannst du auch das öffentliche Verkehrssystem nutzen oder einen Freund oder Verwandten fragen, dich abzuholen und nach Hause zu bringen.
<G-vec00321-002-s144><drop.bringen><en> We will pick you up and drop you off at the airport of Kathmandu.
<G-vec00321-002-s144><drop.bringen><de> Wir holen Sie ab und bringen Sie zum Flughafen von Kathmandu.
<G-vec00321-002-s145><drop.bringen><en> Return to Johannesburg on day 12 and drop off your hire car at the car rental station.
<G-vec00321-002-s145><drop.bringen><de> Begeben Sie sich an Tag 12 auf die Rückreise nach Johannesburg und bringen Sie Ihren Mietwagen zurück zur Autovermietung.
<G-vec00321-002-s146><drop.bringen><en> We will pick you up and drop you off at the reception of your hotel.
<G-vec00321-002-s146><drop.bringen><de> Wir holen Sie ab und bringen Sie an der Rezeption Ihres Hotels ab.
<G-vec00321-002-s147><drop.bringen><en> Also, if you stay in a hotel, we can drop off the car there and then pick it up again so you do not have to lift a finger.
<G-vec00321-002-s147><drop.bringen><de> Und wenn Du in einem Hotel übernachtest, dann bringen wir dir das Auto dorthin und holen es dort auch wieder ab, damit Du keine Extrafahrten machen musst.
<G-vec00321-002-s148><drop.bringen><en> With parking right outside the door, it's easy to drop off and pick up repairs or purchases.
<G-vec00321-002-s148><drop.bringen><de> Die Möglichkeit direkt vor unserem Geschäft zu parken macht es einfach Geräte zu bringen oder abzuholen.
<G-vec00321-002-s149><drop.bringen><en> Just drop off your car and they will ensure your smooth transfer to Charleroi airport.
<G-vec00321-002-s149><drop.bringen><de> Bringen Sie einfach Ihr Fahrzeug zu uns und wir bieten Ihnen einen stressfreien Transfer zum Flughafen Charleroi.
<G-vec00321-002-s150><drop.bringen><en> We will pick you up and drop you off in your accommodation in Mandalay.
<G-vec00321-002-s150><drop.bringen><de> Wir holen Sie ab und bringen Sie zu Ihrer Unterkunft in Mandalay.
<G-vec00321-002-s471><drop.fallen><en> Drop Shipping: We do drop shipping.
<G-vec00321-002-s471><drop.fallen><de> Tropfenverschiffen: Wir lassen Verschiffen fallen.
<G-vec00321-002-s472><drop.fallen><en> Pine cones are open and drop their seeds.
<G-vec00321-002-s472><drop.fallen><de> Kiefernzapfen sind offen und lassen ihre Samen fallen.
<G-vec00321-002-s473><drop.fallen><en> Units drop resources on death.
<G-vec00321-002-s473><drop.fallen><de> Einheiten lassen beim Tod Ressourcen fallen.
<G-vec00321-002-s474><drop.fallen><en> As she talks to a co-worker, they drop a spotlight, climb the wall, load the hood into a van, and flee.
<G-vec00321-002-s474><drop.fallen><de> Als sie ein Mitarbeiter darauf anspricht, lassen sie einen Scheinwerfer fallen, klettern über die Mauer, laden die Motorhaube in einen Lieferwagen ein und flüchten.
<G-vec00321-002-s475><drop.fallen><en> Bonus Loot: These camps also drop certain chests, which can only be opened with red guard keys.
<G-vec00321-002-s475><drop.fallen><de> Bonusbeute: Die Camps lassen außerdem Truhen fallen, die nur mit einem roten Wächterschlüssel geöffnet werden können.
<G-vec00321-002-s476><drop.fallen><en> All enemies of socialism have the same face: If they are exposed then they act brutally and unscrupulously; they attack us in a blind range and drop their reactionary mask.
<G-vec00321-002-s476><drop.fallen><de> Alle Feinde des Sozialismus haben dasselbe Gesicht: wenn sie entlarvt werden, dann handeln sie brutal und skrupellos, greifen uns blindwütig an und lassen ihre Maske fallen.
<G-vec00321-002-s477><drop.fallen><en> In addition to finding new homes in a post-Cataclysm world, they drop new, improved loot, provide a healthy experience bonus, and respawn much more quickly when killed.
<G-vec00321-002-s477><drop.fallen><de> Nicht nur, dass sie sich in der postkataklysmischen Welt ein neues Heim gesucht haben, nein, sie lassen auch neue, verbesserte Beute fallen, gewähren einen schönen Erfahrungsbonus und spawnen weitaus schneller nach, wenn sie getötet wurden.
<G-vec00321-002-s478><drop.fallen><en> Nearby Diano Marina we drop the anchor.
<G-vec00321-002-s478><drop.fallen><de> In der Nähe von Diano Marina lassen wir den Anker fallen.
<G-vec00321-002-s479><drop.fallen><en> Unique – Favor: Enemy minions killed by your allies sometimes drop coins that give either 30 or restore 8% missing mana (minimum 15).
<G-vec00321-002-s479><drop.fallen><de> Einmalig – Gefälligkeit: Gegnerische Vasallen, die von deinen Verbündeten getötet werden, lassen manchmal Münzen fallen, die entweder 30 oder 8% deines fehlenden Manas (mindestens 15) wiederherstellen.
<G-vec00321-002-s480><drop.fallen><en> Some run into the open fields, others drop their bikes and take cover under a tree or try to flee into a house.
<G-vec00321-002-s480><drop.fallen><de> Einige sind auf freien Feldwegen unterwegs, andere lassen ihr Fahrrad fallen, suchen Schutz unter einem Baum oder versuchen noch, in ein Haus zu flüchten.
<G-vec00321-002-s481><drop.fallen><en> Cacti drop ordinary cactus when cut, even though they have a different color.
<G-vec00321-002-s481><drop.fallen><de> Kakteen lassen den gewöhnlichen Kaktus-Gegenstand fallen, trotz ihres ungewöhnlichen Aussehens.
<G-vec00321-002-s482><drop.fallen><en> Mobs[Baby zombies now drop loot upon death.
<G-vec00321-002-s482><drop.fallen><de> Endermite Baby-Zombies lassen beim Tod nun Gegenstände fallen.
<G-vec00321-002-s483><drop.fallen><en> We drop the anchor and symbolically our captain takes you to the port of the marriage.
<G-vec00321-002-s483><drop.fallen><de> Wir lassen den Anker fallen und symbolisch bringt unser Kapitän Sie in den Hafen der EHE.
<G-vec00321-002-s484><drop.fallen><en> Lay evenly 2 tablespoons of yogurt at the one end of the loukoumi and drop on it some pine nuts.
<G-vec00321-002-s484><drop.fallen><de> Legen Sie gleichmäßig 2 Esslöffel griechischen Joghurt auf das eine Ende des Loukoumi und lassen Sie einige Pinienkerne darauf fallen.
<G-vec00321-002-s485><drop.fallen><en> The Butcher: Minions that die near The Butcher will now always drop Fresh Meat stacks.
<G-vec00321-002-s485><drop.fallen><de> Der Schlächter: Diener, die in der Nähe des Schlächters sterben, lassen jetzt immer Stapel von Frischfleisch fallen.
<G-vec00321-002-s486><drop.fallen><en> Lucrative PvE graves: You can largely ignore the graves of other players, but defeated samurai usually drop good items.
<G-vec00321-002-s486><drop.fallen><de> Lukrative PvE-Gräber Die Gräber anderer Spieler könnt ihr größtenteils ignorieren, allerdings lassen die besiegten Samurai meist gute Gegenstände fallen.
<G-vec00321-002-s487><drop.fallen><en> Humanoid creatures drop currency.
<G-vec00321-002-s487><drop.fallen><de> Humanoide Kreaturen lassen bei Tod ihr mitgeführtes Geld fallen.
<G-vec00321-002-s488><drop.fallen><en> If there are defeats between options in the Schwartz set, we drop the weakest such defeats from the list of pairwise defeats, and return to step 5. a.
<G-vec00321-002-s488><drop.fallen><de> Wenn es Besiegungen zwischen Wahlmöglichkeiten gibt, die in der Schwartzschen Menge liegen, so lassen wir die schwächste solcher Besiegungen aus der Liste der paarweisen Besiegungen fallen und kehren zu Schritt 5 zurück.
<G-vec00321-002-s489><drop.fallen><en> Most of us drop our phones more than once.
<G-vec00321-002-s489><drop.fallen><de> Die meisten Menschen lassen ihr Smartphone mehr als nur einmal fallen.
<G-vec00321-002-s452><drop.lassen><en> If you would like to book or you have any questions about any of our properties, feel free to either drop us a line or simply fill in the form below and we’ll be in touch.
<G-vec00321-002-s452><drop.lassen><de> Sie buchen möchten oder Fragen zu einer unserer Immobilien haben, können Sie uns gerne eine Nachricht zukommen lassen oder einfach das untenstehende Formular ausfüllen und wir werden uns mit Ihnen in Verbindung setzen.
<G-vec00321-002-s453><drop.lassen><en> Once past Greti, ask the driver to drop you one stop before Piazza Trento at the tourist information booth.
<G-vec00321-002-s453><drop.lassen><de> Wenn der Bus an Greti vorbeigefahren ist, bitten Sie den Fahrer, Sie eine Station vor Piazza Trento an der Touristeninformation aussteigen zu lassen.
<G-vec00321-002-s454><drop.lassen><en> Backups are very simple with drag and drop file access.
<G-vec00321-002-s454><drop.lassen><de> Sicherungen lassen sich ganz einfach per Drag-and-Drop-Dateizugriff ausführen.
<G-vec00321-002-s455><drop.lassen><en> Rich Internet applications (RIA) enable a wealth of user-friendly functions, such as Drag and drop, 3D effects and animations, to be used with ease, and also support various video formats and other media.
<G-vec00321-002-s455><drop.lassen><de> So lassen sich mit Rich Internet Application (RIA) zahlreiche benutzerfreundliche Funktionen wie u. a. Drag-and-Drop, 3D-Effekte und Animationen problemlos nutzen, zusätzlich unterstützt sie diverse Videoformate und andere Medien.
<G-vec00321-002-s456><drop.lassen><en> We'll stop our boat and drop the pescafondo (a jig that looks like a small fish) all the way to the bottom, then pull it up slowly.
<G-vec00321-002-s456><drop.lassen><de> Wir werfen unsere Pescafondos aus (eine Spannvorrichtung, mit einem Köder, der wie ein kleiner Fisch aussieht) und lassen ihn zum Grund hinab.
<G-vec00321-002-s457><drop.lassen><en> Then feel your jaw drop as you approach the infinitely romantic Alnwick Castle, which bursts into sight from behind manmade hills at its most impressive point.
<G-vec00321-002-s457><drop.lassen><de> Lassen Sie sich dann vom romantischen Alnwick Castle begeistern, welches hinter künstlich angelegten Hügeln zum Vorschein tritt und von dort am beeindruckendsten erscheint.
<G-vec00321-002-s458><drop.lassen><en> A yacht harbour, good restaurants and cheerful bars encourage the sailing community to drop anchor in this pretty little town.
<G-vec00321-002-s458><drop.lassen><de> Ein Jachthafen, gute Restaurants und gemütliche Bars lassen auch immer wieder Segler in dem schönen Städtchen vor Anker gehen.
<G-vec00321-002-s459><drop.lassen><en> He wants to put an end to his gang membership and drop out of the scene.
<G-vec00321-002-s459><drop.lassen><de> Seine Bandengeschichten will er ein für alle Mal hinter sich lassen.
<G-vec00321-002-s460><drop.lassen><en> The researchers led by Prof. Andreas Hierlemann, Professor at the Department of Biosystems Science and Engineering (D-BSSE), and Olivier Frey successfully created a network of spherical micro-tissues (spheroids) in hanging drop platforms. The cells can communicate through fine mesh-like channels via fluid currents.
<G-vec00321-002-s460><drop.lassen><de> Die Forscher um Prof. Andreas Hierlemann, Professor für Biosystems Engineering am Departement Biosysteme (D-BSSE), und Dr. Oliver Frey können ein Netzwerk aus kugelförmigen Mikrogeweben (Sphäroiden) in Hanging-Drop-Plattformen in Nährlösungen züchten und über feinste Kanäle gitterartig über Flüssigkeitsströme miteinander kommunizieren lassen.
<G-vec00321-002-s461><drop.lassen><en> Use Visual Workflow to rapidly design and run any business process with drag and drop simplicity.
<G-vec00321-002-s461><drop.lassen><de> Mit Visual Workflow lassen sich beliebige Geschäftsprozesse dank Drag-and-Drop-Funktionalität zügig entwerfen und ausführen.
<G-vec00321-002-s462><drop.lassen><en> Then drop them and relax a few seconds.
<G-vec00321-002-s462><drop.lassen><de> Dann lassen sie sie sich entspannen für ein paar Sekunden.
<G-vec00321-002-s463><drop.lassen><en> I can’t keep explaining to them that you’re such a nice, reliable, intelligent guy, then drop the bombshell that you’re unemployed.
<G-vec00321-002-s463><drop.lassen><de> Ich kann ihr ja wohl kaum erklären, dass du so ein netter, zuverlässiger, intelligenter Junge bist, und dann die Bombe deiner Arbeitslosigkeit platzen lassen.
<G-vec00321-002-s464><drop.lassen><en> Alpha and mask channels offer multilevel transparency for drop shadows and soft edges of objects, also known as feather effects.
<G-vec00321-002-s464><drop.lassen><de> Mit Alpha- und Maskenkanälen lassen sich mehrstufige Transparenzen für Schlagschatten und unscharfe Ränder von Objekten, auch "Weiche Auswahlkanten" genannt, realisieren.
<G-vec00321-002-s465><drop.lassen><en> Drop into the pit.
<G-vec00321-002-s465><drop.lassen><de> In das Loch herunter lassen.
<G-vec00321-002-s466><drop.lassen><en> Such great dependency and the tie-up of vendors is advantageous only in the short run, but risky in the long run: "In times of crises, suppliers can be squeezed to the last drop", says Bischinger, "but if they break down, buyers will also have a problem."
<G-vec00321-002-s466><drop.lassen><de> Eine so große Abhängigkeit und das Knebeln von Zulieferern ist nur kurzfristig von Vorteil, birgt aber langfristig Gefahren: „In Krisenzeiten kann man die Lieferanten ausquetschen bis aufs Blut“, so Bischinger, „aber wenn sie bei der kleinsten Luft umfallen, hat auch der Einkäufer ein Problem.“ Leben und leben lassen ist seine Devise.
<G-vec00321-002-s467><drop.lassen><en> Drag and drop functionality whereby in a very simple manner multi- channel and multi-step campaigns can be planned and executed.
<G-vec00321-002-s467><drop.lassen><de> Mithilfe der Drag-and-Drop-Funktionalität lassen sich multi-channel, multi-step umfassende Kampagnen auf einfache Art und Weise planen und durchführen.
<G-vec00321-002-s468><drop.lassen><en> Here’s how to sell to all of your different customer segments without risking a drop in sales.
<G-vec00321-002-s468><drop.lassen><de> Ich zeige Dir jetzt, wie Du alle Deine unterschiedlichen Kundensegmente ansprechen kannst, ohne Deine Umsätze einbrechen zu lassen.
<G-vec00321-002-s469><drop.lassen><en> Drop it into that, making sure that it starts at the beginning of the timeline.
<G-vec00321-002-s469><drop.lassen><de> Lassen Sie die Maustaste los, wenn Sie die Datei an den Anfang der Zeitleiste bewegt haben.
<G-vec00321-002-s470><drop.lassen><en> Drag the command away from the menu, and drop it as soon as the check mark icon appears below the mouse pointer.
<G-vec00321-002-s470><drop.lassen><de> Ziehen Sie die Befehl aus dem Menü und lassen Sie die Maustaste los, sobald unterhalb des Mauszeigers ein Häkchen angezeigt wird.
<G-vec00321-002-s490><drop.legen><en> One way to sterilize a needle is to drop it in boiling water.
<G-vec00321-002-s490><drop.legen><de> Eine Möglichkeit die Nadel zu sterilisieren ist, sie in kochendes Wasser zu legen.
<G-vec00321-002-s491><drop.legen><en> Simply activate the temperature logger, drop it in the box and check the status via intuitive LEDs whilst handling the shipment during shipment or once the final destination has been reached.
<G-vec00321-002-s491><drop.legen><de> Aktivieren Sie einfach den Temperaturlogger, legen Sie ihn in die Box und prüfen Sie den Status über intuitive LEDs während dem Transport oder nach Erreichen des Endziels.
<G-vec00321-002-s492><drop.legen><en> You drop coins in a slot, pull a lever, and hope that the same icons on the reels line up.
<G-vec00321-002-s492><drop.legen><de> Sie legen Münzen in einen Schlitz, ziehen Sie den Griff,... Hoffnung, dass die gleichen Bilder auf den Rollen line up.
<G-vec00321-002-s493><drop.legen><en> They offer $10, $15 or $20 tastings, depending on how much you want to drop, and you can sample wines from all over the world. Trivia night
<G-vec00321-002-s493><drop.legen><de> Das Cellar Door bietet internationale Weinproben für AU$10, AU$15 oder AU$20 an, je nachdem, wie viel du auf den Tisch legen (und wie schnell du drunter liegen) willst.
<G-vec00321-002-s494><drop.legen><en> Pick color pencils and drop them on the image to apply colors.
<G-vec00321-002-s494><drop.legen><de> Wähle Farbstiften und legen Sie sie auf das Bild, um die Farben anzuwenden.
<G-vec00321-002-s495><drop.legen><en> To add songs to a playlist, drag music from your music over to the Playlist icon and then drop it into the playlist that you want.
<G-vec00321-002-s495><drop.legen><de> Ziehen Sie zum Hinzufügen von Songs zu einer Wiedergabeliste Titel aus Ihrer Musiksammlung auf das Wiedergabelistensymbol, und legen Sie sie in der gewünschten Wiedergabeliste ab.
<G-vec00321-002-s496><drop.legen><en> Users simply search for the assets or access they need and drop it in their cart.
<G-vec00321-002-s496><drop.legen><de> Benutzer suchen einfach nach den gewünschten Assets oder Zugriffen und legen sie in den Warenkorb.
<G-vec00321-002-s497><drop.legen><en> Simply select any video source, including HD content, and drop it directly onto any of the iClone 3D Video FX Motion Montage props to add broadcast-quality motion graphics to your videos.
<G-vec00321-002-s497><drop.legen><de> Wählen Sie einfach ein Video – auch in HD Auflösung – und legen es direkt auf eine der enthaltenen Requisiten, um hochwertige Motion Graphics für Ihre Videos zu erstellen.
<G-vec00321-002-s498><drop.legen><en> The first time you play a casino game, you drop the game software on your computer, put the game operation into your mind from 1 and switch to pay when you have confidence.
<G-vec00321-002-s498><drop.legen><de> Wenn Sie zum ersten Mal ein Casino-Spiel spielen, legen Sie die Spielsoftware auf Ihrem Computer ab, legen den Spielbetrieb von 1 in den Sinn und wechseln, um zu bezahlen, wenn Sie Vertrauen haben.
<G-vec00321-002-s499><drop.legen><en> Drag and drop the item from Finder into the window
<G-vec00321-002-s499><drop.legen><de> Ziehen Sie das Objekt aus dem Finder und legen Sie es auf dem Fenster ab.
<G-vec00321-002-s500><drop.legen><en> Usually they drop but quite early in the morning, so it is usually too tight for cruise guests.
<G-vec00321-002-s500><drop.legen><de> Meistens legen diese aber recht früh am Morgen ab, so dass es für Kreuzfahrtgäste meist zu knapp ist.
<G-vec00321-002-s501><drop.legen><en> Drag the symbols of flowchart from the left libraries and drop them on the blank page or click the floating button around the symbols to add automatically.
<G-vec00321-002-s501><drop.legen><de> Ziehen Sie die Flussdiagrammsymbole aus den linken Bibliotheken und legen Sie sie auf der leeren Seite ab oder klicken Sie auf die schwebende Schaltfläche um die Symbole herum, um sie automatisch hinzuzufügen.
<G-vec00321-002-s502><drop.legen><en> The best you can do is point out that the phenomenon exists, when you see it happening, and persuade the senior developers—the people whose posts carry the most weight—to drop their paintbrushes early, so at least they're not contributing to the noise.
<G-vec00321-002-s502><drop.legen><de> Das beste was Sie machen können, ist darauf hinzuweisen, dass das Problem existiert sobald es auftaucht, und Ihre Senior-Entwickler – die Personen deren Nachrichten am meisten Gewicht tragen – dazu überreden, frühzeitig Ihre Pinsel nieder zu legen, damit zumindest sie nicht zum Rauschen beitragen.
<G-vec00321-002-s503><drop.legen><en> Draw your bath and drop in and watch them fizz.
<G-vec00321-002-s503><drop.legen><de> Zeichnen Sie Ihr Bad und legen an und beobachten sie fizz.
<G-vec00321-002-s504><drop.legen><en> Drag and drop images or videos from the Files and Effects area to the available Working Areas at the bottom part of the program window.
<G-vec00321-002-s504><drop.legen><de> Ziehen Sie Bilder oder Videos aus dem Datei- und Effektbereich und legen Sie sie in den verfügbaren Arbeitsbereichen im unteren Teil des Programmfensters ab.
<G-vec00321-002-s505><drop.legen><en> It functions like other land mines, but takes the player slightly more time to arm and drop.
<G-vec00321-002-s505><drop.legen><de> Sie funktioniert wie andere Annäherungsminen, braucht aber etwas mehr Zeit beim Scharfmachen und Legen.
<G-vec00321-002-s506><drop.legen><en> ¡¤ Fill out your return address information on the label, affix it to your package, and drop it off at your nearest post office.
<G-vec00321-002-s506><drop.legen><de> j. Füllen Sie Ihre Absenderadresse auf dem Etikett, bringen Sie ihn zu Ihrem Paket, und legen Sie es bei Ihrem nächsten Postamt ab.
<G-vec00321-002-s507><drop.löschen><en> Only the owner of the procedure or a user with DBA authority can drop the procedure from the database.
<G-vec00321-002-s507><drop.löschen><de> Nur der Eigentümer der Prozedur oder ein Benutzer mit DBA-Berechtigung dürfen die Prozedur aus der Datenbank löschen.
<G-vec00321-002-s508><drop.löschen><en> In Sybase Central, you can add, alter, and drop column constraints on the Constraints tab of the table or Column Properties window.
<G-vec00321-002-s508><drop.löschen><de> In Sybase Central können Sie Spalten-Integritätsregeln über die Registerkarte Integritätsregeln der Tabelle oder des Fensters Spalteneigenschaften hinzufügen, ändern und löschen.
<G-vec00321-002-s509><drop.löschen><en> It makes it possible to browse, alter, copy, rename, create and drop database, views, indexes, tables and fields.
<G-vec00321-002-s509><drop.löschen><de> Es ist möglich, Datenbank, Ansichten, Indizes, Tabellen und Felder zu durchsuchen, zu verändern, zu kopieren, umzubenennen, zu erstellen und zu löschen.
<G-vec00321-002-s510><drop.löschen><en> Note: When used to drop an external table, DROP TABLE only removes the table definition from the database.
<G-vec00321-002-s510><drop.löschen><de> Bitte beachten Sie: Wenn DROP TABLE zum Löschen einer externen Tabelle verwendet wird, wird nur die Tabellendefinition aus der Datenbank entfernt.
<G-vec00321-002-s511><drop.löschen><en> In Sybase Central, you can add, alter, and drop column constraints on the Constraints tab of the table or Column Properties window.
<G-vec00321-002-s511><drop.löschen><de> Sie können Standardwerte für Spalten in Sybase Central über die Registerkarte Wert des Fensters Spalteneigenschaften hinzufügen, ändern und löschen .
<G-vec00321-002-s512><drop.löschen><en> Too many people are trying to use a network connection at once, and the network routers cannot process what to do with all the packets fast enough so they necessarily have to drop some.
<G-vec00321-002-s512><drop.löschen><de> Zu viele Benutzer versuchen, eine Netzwerkverbindung gleichzeitig zu verwenden, und die Netzwerkrouter können nicht schnell genug verarbeiten, was mit allen Paketen geschehen soll, sodass sie einige Pakete löschen müssen.
<G-vec00321-002-s513><drop.löschen><en> Moreover, the Trojan can drop other malicious applications onto your computer that will cause even more damage.
<G-vec00321-002-s513><drop.löschen><de> Darüber hinaus kann der Trojaner andere schädlichen Anwendungen auf Ihrem Computer löschen, die noch mehr Schaden anrichtet.
<G-vec00321-002-s514><drop.löschen><en> Before you drop a table, you must disable or drop all dependent materialized views.
<G-vec00321-002-s514><drop.löschen><de> Bevor Sie eine Tabelle löschen oder ändern, müssen Sie alle abhängigen materialisierten Ansichten deaktivieren oder löschen.
<G-vec00321-002-s516><drop.löschen><en> At the remote database, use the ALTER PUBLICATION statement to temporarily drop the table from the publication.
<G-vec00321-002-s516><drop.löschen><de> Verwenden Sie die Anweisung ALTER PUBLICATION in der entfernten Datenbank, um die Tabelle temporär aus der Publikation zu löschen.
<G-vec00321-002-s517><drop.löschen><en> - Note: Do not drop the file into any other folder in Internal storage.
<G-vec00321-002-s517><drop.löschen><de> - Hinweis: Löschen Sie die Datei nicht in einen anderen Ordner im internen Speicher.
<G-vec00321-002-s518><drop.löschen><en> Now we can combine our knowledge and use it to drop all tables of a schema.
<G-vec00321-002-s518><drop.löschen><de> Mit dem Erlernten können wir jetzt alle Tabellen eines Schemas löschen.
<G-vec00321-002-s519><drop.löschen><en> Management of XML Schemas registered in the database – add or drop XML Schemas from the database., or decompose an XML Schema for applications that require shredding – or decomposing – XML data into multiple columns in database tables (exclusively for IBM DB2 9 in this release).
<G-vec00321-002-s519><drop.löschen><de> Verwaltung von in der Datenbank registrierten XML-Schemas - Hinzufügen oder Löschen von XML-Schemas aus der Datenbank oder Zerlegen eines XML-Schemas für Applikationen, für die eine Dekomposition von XML-Daten in mehrere Spalten in Datenbanktabellen erforderlich ist (in dieser Release nur für IBM DB2 9).
<G-vec00321-002-s520><drop.löschen><en> The database user needs the right to create and drop tables.
<G-vec00321-002-s520><drop.löschen><de> Der Datenbankbenutzer benötigt das Recht Tabellen anlegen und löschen zu dürfen.
<G-vec00321-002-s521><drop.löschen><en> The user who is the owner of a database has full administrator rights with respect to that database, including the right to drop it, to restore it from a backup and to enable or disable the AUTO ADMIN MAPPING capability.
<G-vec00321-002-s521><drop.löschen><de> Der Benutzer, der Eigentümer einer Datenbank ist, hat volle Administratorrechte in Bezug auf diese Datenbank, einschließlich des Rechtes, sie zu löschen, um es von einer Sicherung wiederherzustellen und zu aktivieren oder die Fähigkeit AUTO ADMIN MAPPING zu deaktivieren.
<G-vec00321-002-s522><drop.löschen><en> Use the mouse to drop the objects and the ball.
<G-vec00321-002-s522><drop.löschen><de> Verwenden Sie die Maus, um die Objekte und den Ball zu löschen.
<G-vec00321-002-s523><drop.löschen><en> For immediate refresh text indexes, you must drop the text index and recreate it after you alter the text configuration object.
<G-vec00321-002-s523><drop.löschen><de> Bei Textindizes mit sofortiger Aktualisierung müssen Sie den Textindex löschen und ihn wieder erstellen, nachdem Sie das Textkonfigurationsobjekt geändert haben.
<G-vec00321-002-s602><drop.sinken><en> For example, if temperatures drop below 7°C during the winter months, you should consider driving on a set of winter tyres.
<G-vec00321-002-s602><drop.sinken><de> Wenn beispielsweise die Temperatur im Winter unter -7°C sinkt, sollten Sie mit Winterreifen fahren.
<G-vec00321-002-s603><drop.sinken><en> Here, the emulsion technology has a neutral to improving effect on the engine’s effectiveness, i.e. fuel consumption does not increase, or may even drop by a few percent.
<G-vec00321-002-s603><drop.sinken><de> Dabei ist die Emulsionstechnologie in Bezug auf den Motorwirkungsgrad neutral bis steigernd, d.h. der Kraftstoffverbrauch erhöht sich nicht oder sinkt sogar um einige Prozent..
<G-vec00321-002-s604><drop.sinken><en> Google takes notice, and if this happens a lot more, Google will drop your ranking for that search term.
<G-vec00321-002-s604><drop.sinken><de> Google bekommt dies mit, und wenn es häufiger passiert, sinkt der Rang der Seite für diesen Suchbegriff.
<G-vec00321-002-s605><drop.sinken><en> That way, if you feel your blood sugar drop, you can quickly have a nutritious snack to bring it back up to normal.
<G-vec00321-002-s605><drop.sinken><de> Wenn du merkst, dass dein Blutzuckerspiegel sinkt, kannst du schnell einen nährstoffreichen Snack zu dir nehmen, um ihn wieder zu normalisieren.
<G-vec00321-002-s606><drop.sinken><en> Ø The device has an alarm indicating battery voltage drop.
<G-vec00321-002-s606><drop.sinken><de> Wenn die Akku-Spannung sinkt, erzeugt das Gerät ein Alarmsignal.
<G-vec00321-002-s608><drop.sinken><en> With plenty of pockets and a high comfort collar, as well as a wind catcher behind the front zipper, you’ll stay toasty warm when the temperatures drop.
<G-vec00321-002-s608><drop.sinken><de> Mit vielen Taschen, einem hohen Komfortkragen und einer Windleiste hinter dem Frontreißverschluss bleibt es Ihnen mollig warm, unabhängig davon wohin das Thermometer sinkt.
<G-vec00321-002-s609><drop.sinken><en> If I post a new photographer on Facebook and Instagram every day, your market value may drop quickly.
<G-vec00321-002-s609><drop.sinken><de> Wenn ich täglich ein neuer Fotograf auf Facebook und Instagram postet, sinkt dein Marktwert unter Umständen schnell.
<G-vec00321-002-s610><drop.sinken><en> The winter months may mean that Santa will soon be visiting, but it is also the time of the year when the temperature takes a dramatic drop, the winds pick up some momentum and we all have to add a few layers when bracing the morning dew.
<G-vec00321-002-s610><drop.sinken><de> Die Wintermonate können bedeuten, dass der Weihnachtsmann bald zu Besuch kommt, aber es ist auch die Zeit des Jahres, in der die Temperatur dramatisch sinkt, die Winde etwas mehr Schwung bekommen und wir alle ein paar Schichten hinzufügen müssen, wenn wir den Morgentau tragen.
<G-vec00321-002-s611><drop.sinken><en> For example, if temperatures drop below 7°C during the winter months, you should consider buying a set of winter tyres.
<G-vec00321-002-s611><drop.sinken><de> Wenn beispielsweise die Temperatur im Winter unter 7 °C sinkt, sollten Sie einen Satz Winterpneus kaufen.
<G-vec00321-002-s613><drop.sinken><en> An extreme example: first pulse increases only very slowly when climbing stairs and when the person has reached the top, it takes much too long for the pulse rate to drop again.
<G-vec00321-002-s613><drop.sinken><de> Ein extremes Beispiel: Erst wird der Puls beim Treppensteigen nur sehr schwerfällig gesteigert und wenn man oben angekommen ist, dauert es viel zu lange bis der Puls wieder sinkt.
<G-vec00321-002-s614><drop.sinken><en> In the next few days, the temperature will drop to 0℃.
<G-vec00321-002-s614><drop.sinken><de> In den nächsten Tagen sinkt die Temperatur auf 0℃.
<G-vec00321-002-s615><drop.sinken><en> The first thing that happens is that your blood sugar levels drop, which curbs insulin production.
<G-vec00321-002-s615><drop.sinken><de> Das Erste, was passiert, ist, dass der Blutzucker sinkt und infolgedessen die Insulinproduktion gedrosselt wird.
<G-vec00321-002-s616><drop.sinken><en> If you eat snow your body temperature will drop and you risk hypothermia or death.
<G-vec00321-002-s616><drop.sinken><de> Wenn du Schnee isst, sinkt deine Körpertemperatur und du kannst dich unterkühlen und daran sterben.
<G-vec00321-002-s618><drop.sinken><en> The New York Times quoted a top executive at Manpower North America, who said: “We have not before seen unemployment drop, low participation rates and wages not move.
<G-vec00321-002-s618><drop.sinken><de> Die New York Times zitierte ein Führungsmitglied des Beschäftigungsdienstleisters Manpower North America mit den Worten: „Wir haben es bisher noch nicht erlebt, dass die Arbeitslosigkeit sinkt, aber die Erwerbsquote niedrig bleibt und sich bei den Löhnen nichts tut.
<G-vec00321-002-s619><drop.sinken><en> A trader who acts on the assumption that the rate of a financial instrument (currency pair) he has selected will drop sufficiently to allow him to make profit from the sale and subsequent purchase of the instrument in question.
<G-vec00321-002-s619><drop.sinken><de> Bear Ein Händler, der davon ausgeht, dass der Kurs des von ihm gewählten Finanzinstruments (Währungspaares) so stark sinkt, dass er vom Verkauf und späteren Kauf dieses Instruments profitiert.
<G-vec00321-002-s620><drop.sinken><en> But we're annoyed when the interest rates on our savings drop.
<G-vec00321-002-s620><drop.sinken><de> Aber wir sind verärgert, wenn die Verzinsung unserer Sparguthaben sinkt.
<G-vec00321-002-s621><drop.tropfen><en> During use, the honeydipper does not let get lost any drop of honey anymore.
<G-vec00321-002-s621><drop.tropfen><de> Im Gebrauch lässt der Honiglöffel Olivenholz keinen Tropfen Honig mehr verloren gehen.
<G-vec00321-002-s622><drop.tropfen><en> Build a beautiful pair of Pandora earring with these 14K gold and Onyx Drop charms.
<G-vec00321-002-s622><drop.tropfen><de> Bauen Sie ein schönes Paar Pandora Ohrring mit diesen 14K Gold und Onyx Tropfen Reize.
<G-vec00321-002-s623><drop.tropfen><en> The main ingredient is the Golden Drop of oil rapeseed oil, which was enriched by the addition of linseed oil.
<G-vec00321-002-s623><drop.tropfen><de> Die wichtigste Zutat ist das Goldene Tropfen Öl Rapsöl, welches durch die Zugabe von Leinöl angereichert wurde.
<G-vec00321-002-s624><drop.tropfen><en> For this reason, everything here is polished to the highest possible degree, so that all the light which is applied to the objects is reflected almost to the last drop, and therefore cannot interfere with the bodies.
<G-vec00321-002-s624><drop.tropfen><de> Aus diesem Grunde ist hier auch alles so höchst glanzvoll poliert, damit dadurch alles auf die Gegenstände einwirkende Licht trotz seiner immensen Intensität nahe bis auf den letzten Tropfen zurückgeworfen wird und darum mit den Körpern nicht zerstörend in Wechselwirkung treten kann.
<G-vec00321-002-s625><drop.tropfen><en> Shake the vial before use. Discard the first drop of control solution.
<G-vec00321-002-s625><drop.tropfen><de> Schwenken Sie zunächst die Kontrolllösung und verwerfen Sie den ersten Tropfen.
<G-vec00321-002-s626><drop.tropfen><en> Then drop one drop of the liquid in the water until it turns green.
<G-vec00321-002-s626><drop.tropfen><de> Dann tropfen Sie einen Tropfen der Flüssigkeit in das Wasser, bis es von rot nach grün wechselt.
<G-vec00321-002-s627><drop.tropfen><en> In ten teaspoons of cream or milk, stir a drop of oil, then drop one teaspoon of the mixture into a glass of loose tea or warm milk.
<G-vec00321-002-s627><drop.tropfen><de> In zehn Teelöffel Sahne oder Milch einen Tropfen Öl verrühren und einen Teelöffel der Mischung in ein Glas losen Tee oder warme Milch geben.
<G-vec00321-002-s628><drop.tropfen><en> Nevertheless, I have to be careful that any drop of DHC Deep Cleansing oil accidentally enters the eye.
<G-vec00321-002-s628><drop.tropfen><de> Nichtsdestotrotz muss ich aufpassen, dass kein Tropfen des Deep Cleansing Öl von DHC versehentlich ins Auge gelangt.
<G-vec00321-002-s629><drop.tropfen><en> That essence, that drop of you in the Pure Energy of Nature decided to join in this vast creation of the universe that we know as our reality.
<G-vec00321-002-s629><drop.tropfen><de> Diese Essenz, dieser Tropfen von euch in der Reinen Energie der Natur, entschied sich, sich in die ausgedehnte Schöpfung des Universums anzuschließen, das wir als unsere Realität kennen.
<G-vec00321-002-s630><drop.tropfen><en> Drop falls into the water.
<G-vec00321-002-s630><drop.tropfen><de> Tropfen fällt ins Wasser.
<G-vec00321-002-s631><drop.tropfen><en> Drop by drop it is finest GILARDY design and craftsmanship.
<G-vec00321-002-s631><drop.tropfen><de> Tropfen für Tropfen feinste GILARDY Design- und Handwerkskunst.
<G-vec00321-002-s633><drop.tropfen><en> We can say like this: supposing My hands are dirty, so I go to one tap and I find there is one drop coming, so I can’t wash. So I go to another place, there’s no water.
<G-vec00321-002-s633><drop.tropfen><de> Wir können so sagen: Angenommen, meine Hände sind schmutzig, also gehe ich zu einem Waschbecken und merke, da kommt nur mehr ein Tropfen heraus, also kann ich mich nicht waschen; dann gehe ich woanders hin – da gibt es kein Wasser.
<G-vec00321-002-s634><drop.tropfen><en> SUGGESTION OF USE: from 1 drop per plate to two to three tablespoons of Natural Food Flavouring per litre of preparation.
<G-vec00321-002-s634><drop.tropfen><de> ANWENDUNGSEMPFEHLUNG: von 1 Tropfen pro Teller bis zu zwei bis drei Esslöffeln Naturkostaroma pro Liter Zubereitung.
<G-vec00321-002-s635><drop.tropfen><en> Against halitosis or smoker’s breath: put one drop of the essential oil on the toothbrush or on a clean finger and rub it on your gums and teeth.
<G-vec00321-002-s635><drop.tropfen><de> Gegen Mundgeruch oder schlechten Atem wegen Rauchens: Geben sie einen Tropfen dieser Mischung ätherischer Öle auf eine Zahnbürste oder auf einen sauberen Finger und reiben Sie es auf Ihr Zahnfleisch und Ihre Zähne.
<G-vec00321-002-s636><drop.tropfen><en> Every drop is precious, and anyone who is aware of hansgrohe’s attention to detail will also understand how passionate we are when it comes to cleaning and maintaining our products.
<G-vec00321-002-s636><drop.tropfen><de> Jeder Tropfen ist wertvoll, und wer die hansgrohe Liebe zum Detail kennt, der versteht auch unsere Leidenschaft für die Reinigung und Pflege unserer Produkte.
<G-vec00321-002-s637><drop.tropfen><en> The Commission’s recommendations are a drop in the ocean.
<G-vec00321-002-s637><drop.tropfen><de> Die Empfehlungen der Kommission sind ein Tropfen auf den heißen Stein.
<G-vec00321-002-s638><drop.tropfen><en> Relax in one of the four lovingly designed rooms available, which have been designed together with local well-known artists, and enjoy a last drop of excellent wine in the Genießer-Suite before retiring at the end of the day.
<G-vec00321-002-s638><drop.tropfen><de> Wohlfühlen in den vier liebevoll ausgestatteten Zimmern, die von bedeutenden Künstlern der Region mitgestaltet wurden und noch einen guten Schluck der edlen Tropfen in der Genießer-Suite nehmen bevor der Tag zu Ende geht.
<G-vec00321-002-s639><drop.tropfen><en> Burns nice and clean to the last drop for 9 hours.
<G-vec00321-002-s639><drop.tropfen><de> Brennt 9 Stunden lang schön sauber bis zum letzten Tropfen.
<G-vec00321-002-s678><drop.verlieren><en> The purpose of this tip is that you drop unnecessary calories, not those valuable proteins after your workout or at breakfast.
<G-vec00321-002-s678><drop.verlieren><de> Der Zweck dieses Tipps ist, dass Sie unnötige Kalorien verlieren, nicht die wertvollen Proteine nach dem Training oder beim Frühstück.
<G-vec00321-002-s679><drop.verlieren><en> Bananas are additionally great when you are trying to drop weight and develop muscle.
<G-vec00321-002-s679><drop.verlieren><de> Bananen sind auch sehr gut, wenn Sie versuchen, Gewicht zu verlieren und Muskeln aufzubauen.
<G-vec00321-002-s680><drop.verlieren><en> Garcinia cambogia extract is being boasted as one of the most highly effective supplement offered for aiding folks in Elat Israel to drop weight successfully and permanently.
<G-vec00321-002-s680><drop.verlieren><de> Garcinia Cambogia angepriesen wird als einer der mächtigsten Zulage für Menschen in Seraing Belgien, Gewicht zu verlieren, effektiv und dauerhaft zu helfen.
<G-vec00321-002-s681><drop.verlieren><en> When your oestrogen degrees are lesser, you have better opportunity to drop weight and build additional lean muscular tissue.
<G-vec00321-002-s681><drop.verlieren><de> Wenn Ihr Östrogenspiegel niedriger sind, haben Sie bessere Chancen, Gewicht zu verlieren und mehr Muskelmasse aufzubauen.
<G-vec00321-002-s683><drop.verlieren><en> Garcinia cambogia extract is being boasted as one of the most powerful supplement readily available for assisting people in Diekirch Luxembourg to drop weight effectively and permanently.
<G-vec00321-002-s683><drop.verlieren><de> Garcinia Cambogia angepriesen wird als einer der mächtigsten Zulage für Menschen in Diekirch Luxemburg, Gewicht zu verlieren, effektiv und dauerhaft zu helfen.
<G-vec00321-002-s684><drop.verlieren><en> As a general rule, you want to eat healthy and exercise during this time, not do anything that that promises to drop X pounds in Y days.
<G-vec00321-002-s684><drop.verlieren><de> Als Faustregel gilt, dass du während dieser Zeit gesund essen und Sport treiben und nichts tun solltest, das dir verspricht in x Tagen y Pfund zu verlieren.
<G-vec00321-002-s686><drop.verlieren><en> It could easily be made use of to assist you drop weight, that is exactly what we all want.
<G-vec00321-002-s686><drop.verlieren><de> Es kann einfach verwendet werden, helfen Sie, Gewicht zu verlieren, das ist genau das was wir alle wollen.
<G-vec00321-002-s688><drop.verlieren><en> They collaborate to aid you drop weight, as well as really feel great while you are doing it.
<G-vec00321-002-s688><drop.verlieren><de> Sie arbeiten zusammen, um Ihnen helfen, Gewicht zu verlieren, ebenso wie sich wohl fühlen, während Sie es tun.
<G-vec00321-002-s689><drop.verlieren><en> If you are somebody that truly has a sturdy need to drop weight, however can not seem to shed also merely a few pounds whatever you do, in comparison to this diet pill is for you.
<G-vec00321-002-s689><drop.verlieren><de> Wenn Sie jemand, der wirklich hat einen starken Wunsch sind, Gewicht zu verlieren, aber kann nicht scheinen, egal was Sie tun, als diese Diätpille für Sie ist auch nur ein paar Pfund zu vergießen.
<G-vec00321-002-s690><drop.verlieren><en> It is made from an artificial fat burning formula that has assisted people to drop weight (as high as 10 pounds in 2 weeks).
<G-vec00321-002-s690><drop.verlieren><de> Es wird von einem künstlichen Fettverbrennung Formel, die Menschen unterstützt hat, um Gewicht zu verlieren (so hoch wie 10 Pfund in 2 Wochen) gefertigt.
<G-vec00321-002-s691><drop.verlieren><en> "It is obviously good for us when we win and our main rivals drop points," said Bayern's Kroos.
<G-vec00321-002-s691><drop.verlieren><de> "Das ist natürlich gut für uns, wenn wir gewinnen und unsere ärgsten Konkurrenten Punkte verlieren", sagte Bayerns Kroos.
<G-vec00321-002-s693><drop.verlieren><en> This home alone will certainly aid you drop several of your excess pounds.
<G-vec00321-002-s693><drop.verlieren><de> Diese Eigenschaft allein wird Ihnen helfen, einige Ihrer überschüssigen Pfunde zu verlieren.
<G-vec00321-002-s694><drop.verlieren><en> Pure raspberry ketone is natural, scientifically proven and is a great way to drop weight promptly and properly.
<G-vec00321-002-s694><drop.verlieren><de> Reine Himbeer Keton ist ganz natürlich, klinisch getestet und ist eine gute Möglichkeit, schnell und effektiv Gewicht zu verlieren.
<G-vec00321-002-s696><drop.verlieren><en> In general, Garcinia Cambogia not simply aids you to drop weight however also provides you several wellness benefits to obtain an optimal weight with healthy and balanced mind and body.
<G-vec00321-002-s696><drop.verlieren><de> Insgesamt Garcinia Cambogia nicht nur hilft Ihnen, Gewicht zu verlieren, sondern Sie bietet auch viele gesundheitliche Vorteile um ein Idealgewicht mit gesunden Körper und Geist zu erhalten.
<G-vec00321-002-s716><drop.ziehen><en> Click and drop the bricks you want in your Palette top of the screen.
<G-vec00321-002-s716><drop.ziehen><de> Durch Anklicken könnt ihr die Bricks in eure Menüleiste am oberen Bildschirmrand ziehen.
<G-vec00321-002-s717><drop.ziehen><en> When you drop the document into an opened case, the document will be imported into the case.
<G-vec00321-002-s717><drop.ziehen><de> Wenn Sie die Dokumente in eine geöffnete Akte ziehen, werden Sie in diese Akte importiert.
<G-vec00321-002-s718><drop.ziehen><en> From the Content Finder, you can drag-and-drop the schema elements on the form.
<G-vec00321-002-s718><drop.ziehen><de> Sie können Elemente aus der XSD-Hierarchie in das adaptive Formular ziehen.
<G-vec00321-002-s719><drop.ziehen><en> The tab has two fields: one to drop or upload an asset and one that displays some information about the containing page and about the asset if one has been referenced.
<G-vec00321-002-s719><drop.ziehen><de> Die Registerkarte verfügt über zwei Felder: eines, in das Sie Assets ziehen oder hochladen können, und eines, das Informationen über die Seite, die es umfasst, und das Asset (falls auf eines verwiesen wird) anzeigt.
<G-vec00321-002-s720><drop.ziehen><en> File Juicer doesn't care what type file you drop onto it; it searches the entire file byte by byte.
<G-vec00321-002-s720><drop.ziehen><de> File Juicer ist es egal welche Dateientyp sie in ihn ziehen; er sucht die ganze Datei Byte für Byte.
<G-vec00321-002-s721><drop.ziehen><en> It is also possible to select text in a word processing application and drop it onto a 4D text variable.
<G-vec00321-002-s721><drop.ziehen><de> Sie können auch Text in einem Textverarbeitungsprogramm auswählen und in eine 4D Variable vom Typ Text ziehen.
<G-vec00321-002-s722><drop.ziehen><en> Drag and drop or just click a question to add it to the preview.
<G-vec00321-002-s722><drop.ziehen><de> Sie können eine Frage mit der Maus auf die Vorschau ziehen oder darauf klicken, um sie hinzuzufügen.
<G-vec00321-002-s723><drop.ziehen><en> Alternatviely, you can also load your videos in simple drag-and-drop way.
<G-vec00321-002-s723><drop.ziehen><de> Alternativ können Sie Ihre gewünschten FLV-Videos per Drag-and-Drop direkt auf die primäre Benutzeroberfläche ziehen.
<G-vec00321-002-s724><drop.ziehen><en> Windows & Doors – Choose from a variety of styles including designer brand name products and simply drop them into self-healing walls.
<G-vec00321-002-s724><drop.ziehen><de> •Â Â Â Fenster & TĂĽren: Wählen Sie aus einer Vielfalt von Stilen und ziehen Sie sie einfach in Wendeltreppen per Klicken & Ziehen ein.
<G-vec00321-002-s725><drop.ziehen><en> An already placed piece can be moved to another place by drag and drop or be removed again by dragging it to the outside of the game field.
<G-vec00321-002-s725><drop.ziehen><de> Eine bereits aufgestellte Figur kann durch Klicken und Ziehen an einen anderen Platz verschoben werden oder durch ziehen auf den rechten Rand wieder entfernt werden.
<G-vec00321-002-s726><drop.ziehen><en> It allows you to drag-and-drop form-model elements onto the fragment.
<G-vec00321-002-s726><drop.ziehen><de> Sie können dann Formularmodellelemente auf das Fragment ziehen.
<G-vec00321-002-s727><drop.ziehen><en> Select an audio clip of your choice and drop it onto the track.
<G-vec00321-002-s727><drop.ziehen><de> Wählen Sie den gewünschten Audioclip aus und ziehen Sie ihn auf die Spur.
<G-vec00321-002-s728><drop.ziehen><en> Each time he just ate the bate and being lifted out of the water, but before we could get hold of him, he let himself drop back in the water.
<G-vec00321-002-s728><drop.ziehen><de> Fünfmal haben wir sie „gefangen“, jedes Mal hat er einfach unser Fischfutter gegessen und sie aus dem Wasser ziehen lassen.
<G-vec00321-002-s729><drop.ziehen><en> You can also drag-and-drop topics from the topic list to a Table of Contents and an index.
<G-vec00321-002-s729><drop.ziehen><de> Sie können Themen auch aus der Themenliste in ein Inhaltsverzeichnis und einen Index ziehen.
<G-vec00321-002-s730><drop.ziehen><en> Simply drag and drop your video clips and still images to preview your movie – and watch your content come alive, complete with Hollywood style multi-layered effects, animated graphics, titles and Hi-Fi audio.
<G-vec00321-002-s730><drop.ziehen><de> Ziehen Sie Videomaterial und Fotos einfach per Drag-and-Drop in den Bearbeitungsbereich und betrachten Sie, wie Ihre Inhalte lebendig werden, komplett mit mehrlagigen Effekten in Hollywood-Qualität sowie animierten Grafiken, Titeln und Hi-Fi-Audio.
<G-vec00321-002-s731><drop.ziehen><en> You can drop a tag above, below, or in between multiple tags.
<G-vec00321-002-s731><drop.ziehen><de> Sie können ein Tag über, unter oder zwischen mehreren Tags ziehen.
<G-vec00321-002-s732><drop.ziehen><en> • Select a table, column, or primary key in the Online Browser or in a table design and drop it onto a table design of another table.
<G-vec00321-002-s732><drop.ziehen><de> Wählen Sie im Online Browser oder in einem Tabellendesign eine Tabelle, Spalte oder einen Primärschlüssel und ziehen Sie das Objekt in das Tabellendesign einer anderen Tabelle.
<G-vec00321-002-s733><drop.ziehen><en> To overlay the Motion Title on the video clip, drop it on track 2 (over a video clip on track 1)
<G-vec00321-002-s733><drop.ziehen><de> Um den Bewegungstitel im Videoclip zu überlagern, ziehen Sie ihn auf Spur 2 (über einen Videoclip auf Spur 1).
<G-vec00321-002-s734><drop.ziehen><en> Simply drag and drop - and all your desired files are stored on the Data Traveler I G2: Reports, pictures, tables or other important documents.
<G-vec00321-002-s734><drop.ziehen><de> Einfach nur klicken und ziehen - und schon sind alle gewünschten Dateien auf dem DataTraveler I G2 abgelegt: Berichte, Bilder, Tabellen oder andere wichtige Dokumente.
<G-vec00418-002-s320><drop.fallen><en> Regardless of the fact that Litecoin has a striking similarity to Bitcoin, its block generation occurs in at the drop of a dime and thus, its transaction confirmation is ten times quicker.
<G-vec00418-002-s320><drop.fallen><de> Ungeachtet der Tatsache, dass Litecoin eine auffallende Ähnlichkeit mit Bitcoin hat, tritt seine Blockgenerierung in einem Fall von einem Cent auf, und somit ist seine Transaktionsbestätigung zehnmal schneller.
<G-vec00418-002-s321><drop.fallen><en> Tracking of sensor data like temperature, humidity, light, infrared, pressure, orientation, shock, drop, vibration, motion, signal, battery and jamming.
<G-vec00418-002-s321><drop.fallen><de> Erfassung von Sensordaten wie Temperatur, Feuchtigkeit, Licht, Infrarot, Druck, Ausrichtung, Erschütterung, Fall, Vibration, Bewegung, Signal, Batterie und Störsignal.
<G-vec00418-002-s322><drop.fallen><en> DIN 8308 specifies that a watch has to withstand a vertical drop from a one-metre height onto hardwood flooring without sustaining functional damage to its case or movement parts, or hands or glass.
<G-vec00418-002-s322><drop.fallen><de> DIN 8308 regelt, dass eine Uhr den senkrechten Fall aus einem Meter Höhe auf Hartholzboden ohne funktionsstörende Beschädigungen des Gehäuses oder von Werkteilen oder auch Zeigern und Glas überstehen muss.
<G-vec00418-002-s323><drop.fallen><en> If it is not, simply drag and drop it onto the "tutorial_database" namespace.
<G-vec00418-002-s323><drop.fallen><de> Falls dies nicht der Fall ist, ziehen Sie sie einfach mit der Maus auf den Namespace "tutorial_database".
<G-vec00418-002-s324><drop.fallen><en> Alternatively, a drop through support exposes the 50% level at 83.76.
<G-vec00418-002-s324><drop.fallen><de> Alternativ legt ein Fall durch die Unterstützung das 50% Level bei 83,76 frei.
<G-vec00418-002-s325><drop.fallen><en> Gold followed up on Wednesday’s slip with a much more convincing 2.1 percent drop this past session.
<G-vec00418-002-s325><drop.fallen><de> Gold folgte dem Abrutsch vom Mittwoch mit einem noch überzeugenderem 2,1 Prozent Fall in der vergangenen Handelszeit.
<G-vec00418-002-s326><drop.fallen><en> CE foot protection at the last cm drop.
<G-vec00418-002-s326><drop.fallen><de> CE Fußschutz beim letzten cm Fall.
<G-vec00418-002-s327><drop.fallen><en> The unexpected drop in an elevator let me know it was time to land the ship.
<G-vec00418-002-s327><drop.fallen><de> Der unerwartete Fall im Aufzug lies mich wissen dass es Zeit war, das Raumschiff zu landen.
<G-vec00418-002-s328><drop.fallen><en> When you have gone over his Messer and pulled your Messer at you as described before, drop your left hand to the middle of your Messer and turn your right hand on your Messer, letting the thumb face up.
<G-vec00418-002-s328><drop.fallen><de> Wenn du wie vorher beschrieben über sein Messer gefahren bist und dein Messer an dich gezogen hast, fall mit deiner linken Hand in die Mitte deines Messers und dreh die rechte an deinem Messer um, so dass der Daumen nach oben zeigt.
<G-vec00418-002-s329><drop.fallen><en> Therefore when you compare the rise in Pepsi’s buzz with the drop in McD’s score there is a difference of 10%.
<G-vec00418-002-s329><drop.fallen><de> Wenn Sie nun den Aufschwung in dem Pepsi-Trend mit dem Fall der Rate von McD vergleichen, dann existiert dort ein Unterschied von 10%.
<G-vec00418-002-s330><drop.fallen><en> Capital accumulates and multiplies actual power by comparison with labour; however, it also develops the social productivity of labour, which in turn must be reflected in the general trend towards a drop in profit margins.
<G-vec00418-002-s330><drop.fallen><de> Das Kapital akkumuliert, vermehrt die sachliche Macht gegenüber der Arbeitskraft; es entwickelt aber auch die gesellschaftliche Produktivkraft der Arbeit, die sich wiederum im tendenziellen Fall der Profitrate niederschlagen muss.
<G-vec00418-002-s331><drop.fallen><en> After connecting to PureVPN’s servers, a considerable drop in ping was noted, but not always.
<G-vec00418-002-s331><drop.fallen><de> Nachdem Verbinden mit PureVPN Servern gab es einen bemerkenswerten Fall in dem Ping, doch nicht immer.
<G-vec00418-002-s332><drop.fallen><en> Shock, drop: Please protect the device against shock and drops in all operating modes. Electrostatic discharge: This device is sensitive to electrostatic discharge.
<G-vec00418-002-s332><drop.fallen><de> Stoß, Fall: Schützen Sie das Gerät in jedem Betriebszustand vor Stoß und Fall Elektrostatische Entladung: Dieses Gerät ist sensibel gegenüber elektrostatischer Entladung.
<G-vec00418-002-s333><drop.fallen><en> This is one of the largest waterfalls in Iceland with a drop of around 60m / 200ft.
<G-vec00418-002-s333><drop.fallen><de> Skogafoss ist einer der größten Wasserfälle Islands mit einem Fall von circa 60m/200ft.
<G-vec00418-002-s334><drop.fallen><en> Fly through the trees on a thrilling zipline circuit, including an Aquazip; ride the Tarzania zipline coaster, and take a daring parachute drop.
<G-vec00418-002-s334><drop.fallen><de> Fliegen Sie durch die Bäume auf einer aufregenden Zipline-Strecke, einschließlich eines Aquazip; Fahren Sie mit der Tarzania Zipline Coaster und nehmen Sie einen gewagten Fallschirm Fall.
<G-vec00418-002-s335><drop.fallen><en> According to the European Commission itself, between 2009 and 2011 Greece has suffered the most violent drop in “real household disposable income”: the Greek households lost 17% of their real disposable income, while the other Southern European households counted income losses ranging from 5% (Ireland) to 8% (Spain).
<G-vec00418-002-s335><drop.fallen><de> Laut Europäischer Kommission hat Griechenland zwischen 2009 und 2011 den größten Fall im "real verfügbaren Einkommen der Haushalte" erlitten: die griechischen Haushalte verloren 17% ihres real verfügbaren Einkommens, während die anderen südeuropäischen Haushalte Einkommensverluste von 5% (Irland) bis 8% (Spanien) verzeichneten.
<G-vec00418-002-s336><drop.fallen><en> - Pokémon cannot use the move Sky Drop during battle Other Information:
<G-vec00418-002-s336><drop.fallen><de> - Pokémon ist nicht erlaubt, im Kampf die Attacke „Freier Fall“ einzusetzen.
<G-vec00418-002-s337><drop.fallen><en> Function Test whether the specimen is damaged drop from certain height, suitable for small consumer electronics.
<G-vec00418-002-s337><drop.fallen><de> Funktion Test, ob das Exemplar geschädigter Fall von bestimmter Höhe ist, passend für kleine Unterhaltungselektronik.
<G-vec00418-002-s338><drop.fallen><en> To this situation was added a few months ago a drop in the price of oil which has been a plot by the USA and Saudi Arabia with the aim of destroying the economy of oil-producing countries; especially Russia, Iran, Venezuela, and also Ecuador, which is a producer and exporter of oil.
<G-vec00418-002-s338><drop.fallen><de> Zu dieser Situation gesellte sich vor ein paar Monaten der Fall des Ölpreises, welcher eine Idee der USA und Saudi-Arabiens war, mit dem Ziel der Zerstörung der Wirtschaft der Ölförderländern, vor allem Russland, Iran, Venezuela und auch Ecuador, welches Produzent und Exporteur von Öl ist.
<G-vec00418-002-s471><drop.lassen><en> Drop Shipping: We do drop shipping.
<G-vec00418-002-s471><drop.lassen><de> Tropfenverschiffen: Wir lassen Verschiffen fallen.
<G-vec00418-002-s472><drop.lassen><en> Pine cones are open and drop their seeds.
<G-vec00418-002-s472><drop.lassen><de> Kiefernzapfen sind offen und lassen ihre Samen fallen.
<G-vec00418-002-s473><drop.lassen><en> Units drop resources on death.
<G-vec00418-002-s473><drop.lassen><de> Einheiten lassen beim Tod Ressourcen fallen.
<G-vec00418-002-s474><drop.lassen><en> As she talks to a co-worker, they drop a spotlight, climb the wall, load the hood into a van, and flee.
<G-vec00418-002-s474><drop.lassen><de> Als sie ein Mitarbeiter darauf anspricht, lassen sie einen Scheinwerfer fallen, klettern über die Mauer, laden die Motorhaube in einen Lieferwagen ein und flüchten.
<G-vec00418-002-s475><drop.lassen><en> Bonus Loot: These camps also drop certain chests, which can only be opened with red guard keys.
<G-vec00418-002-s475><drop.lassen><de> Bonusbeute: Die Camps lassen außerdem Truhen fallen, die nur mit einem roten Wächterschlüssel geöffnet werden können.
<G-vec00418-002-s476><drop.lassen><en> All enemies of socialism have the same face: If they are exposed then they act brutally and unscrupulously; they attack us in a blind range and drop their reactionary mask.
<G-vec00418-002-s476><drop.lassen><de> Alle Feinde des Sozialismus haben dasselbe Gesicht: wenn sie entlarvt werden, dann handeln sie brutal und skrupellos, greifen uns blindwütig an und lassen ihre Maske fallen.
<G-vec00418-002-s477><drop.lassen><en> In addition to finding new homes in a post-Cataclysm world, they drop new, improved loot, provide a healthy experience bonus, and respawn much more quickly when killed.
<G-vec00418-002-s477><drop.lassen><de> Nicht nur, dass sie sich in der postkataklysmischen Welt ein neues Heim gesucht haben, nein, sie lassen auch neue, verbesserte Beute fallen, gewähren einen schönen Erfahrungsbonus und spawnen weitaus schneller nach, wenn sie getötet wurden.
<G-vec00418-002-s478><drop.lassen><en> Nearby Diano Marina we drop the anchor.
<G-vec00418-002-s478><drop.lassen><de> In der Nähe von Diano Marina lassen wir den Anker fallen.
<G-vec00418-002-s479><drop.lassen><en> Unique – Favor: Enemy minions killed by your allies sometimes drop coins that give either 30 or restore 8% missing mana (minimum 15).
<G-vec00418-002-s479><drop.lassen><de> Einmalig – Gefälligkeit: Gegnerische Vasallen, die von deinen Verbündeten getötet werden, lassen manchmal Münzen fallen, die entweder 30 oder 8% deines fehlenden Manas (mindestens 15) wiederherstellen.
<G-vec00418-002-s480><drop.lassen><en> Some run into the open fields, others drop their bikes and take cover under a tree or try to flee into a house.
<G-vec00418-002-s480><drop.lassen><de> Einige sind auf freien Feldwegen unterwegs, andere lassen ihr Fahrrad fallen, suchen Schutz unter einem Baum oder versuchen noch, in ein Haus zu flüchten.
<G-vec00418-002-s481><drop.lassen><en> Cacti drop ordinary cactus when cut, even though they have a different color.
<G-vec00418-002-s481><drop.lassen><de> Kakteen lassen den gewöhnlichen Kaktus-Gegenstand fallen, trotz ihres ungewöhnlichen Aussehens.
<G-vec00418-002-s482><drop.lassen><en> Mobs[Baby zombies now drop loot upon death.
<G-vec00418-002-s482><drop.lassen><de> Endermite Baby-Zombies lassen beim Tod nun Gegenstände fallen.
<G-vec00418-002-s483><drop.lassen><en> We drop the anchor and symbolically our captain takes you to the port of the marriage.
<G-vec00418-002-s483><drop.lassen><de> Wir lassen den Anker fallen und symbolisch bringt unser Kapitän Sie in den Hafen der EHE.
<G-vec00418-002-s484><drop.lassen><en> Lay evenly 2 tablespoons of yogurt at the one end of the loukoumi and drop on it some pine nuts.
<G-vec00418-002-s484><drop.lassen><de> Legen Sie gleichmäßig 2 Esslöffel griechischen Joghurt auf das eine Ende des Loukoumi und lassen Sie einige Pinienkerne darauf fallen.
<G-vec00418-002-s485><drop.lassen><en> The Butcher: Minions that die near The Butcher will now always drop Fresh Meat stacks.
<G-vec00418-002-s485><drop.lassen><de> Der Schlächter: Diener, die in der Nähe des Schlächters sterben, lassen jetzt immer Stapel von Frischfleisch fallen.
<G-vec00418-002-s486><drop.lassen><en> Lucrative PvE graves: You can largely ignore the graves of other players, but defeated samurai usually drop good items.
<G-vec00418-002-s486><drop.lassen><de> Lukrative PvE-Gräber Die Gräber anderer Spieler könnt ihr größtenteils ignorieren, allerdings lassen die besiegten Samurai meist gute Gegenstände fallen.
<G-vec00418-002-s487><drop.lassen><en> Humanoid creatures drop currency.
<G-vec00418-002-s487><drop.lassen><de> Humanoide Kreaturen lassen bei Tod ihr mitgeführtes Geld fallen.
<G-vec00418-002-s488><drop.lassen><en> If there are defeats between options in the Schwartz set, we drop the weakest such defeats from the list of pairwise defeats, and return to step 5. a.
<G-vec00418-002-s488><drop.lassen><de> Wenn es Besiegungen zwischen Wahlmöglichkeiten gibt, die in der Schwartzschen Menge liegen, so lassen wir die schwächste solcher Besiegungen aus der Liste der paarweisen Besiegungen fallen und kehren zu Schritt 5 zurück.
<G-vec00418-002-s489><drop.lassen><en> Most of us drop our phones more than once.
<G-vec00418-002-s489><drop.lassen><de> Die meisten Menschen lassen ihr Smartphone mehr als nur einmal fallen.
<G-vec00555-002-s377><drop.fallen><en> Investor Z will need some incentive to buy them, so the price of the shares will drop.
<G-vec00555-002-s377><drop.fallen><de> Anleger Z braucht einen Anreiz, um die Aktien zu kaufen, daher fällt der Kurs der Aktien.
<G-vec00555-002-s379><drop.fallen><en> The north offer 24 to 26 degrees in summer, at night the temperatures can drop 10 degrees down.
<G-vec00555-002-s379><drop.fallen><de> Im Norden hat es im Sommer durchschnittlich zwischen 24 und 26 Grad, in der Nacht fällt das Barometer um bis zu 10 Grad.
<G-vec00555-002-s381><drop.fallen><en> However, it is now starting to drop drastically; at the time of writing this article it had lost almost 50 percent of its value and is currently being traded at around $11,500.
<G-vec00555-002-s381><drop.fallen><de> Obwohl er jetzt drastisch fällt – zum Zeitpunkt des Schreibens dieses Artikels, hat er fast 50% seines Werts verloren und wird derzeit um 11.500 US $ gehandelt – ist er immer noch eine Menge Geld wert.
<G-vec00555-002-s382><drop.fallen><en> We drop the anchor in the South River, a bay towards the Neuss River.
<G-vec00555-002-s382><drop.fallen><de> In einer Bucht im Neuss River fällt der Anker und wir haben erstaunlicherweise gute Internetverbindung.
<G-vec00555-002-s383><drop.fallen><en> There is no guarantee that the price of a bitcoin will increase or drop.
<G-vec00555-002-s383><drop.fallen><de> Es gibt keine Garantie dafür, dass der Preis eines Bitcoins weiter steigt oder fällt.
<G-vec00555-002-s384><drop.fallen><en> If too many traders dump at the same time, the cryptocurrency's price is likely to drop.
<G-vec00555-002-s384><drop.fallen><de> Wenn zu viele Händler gleichzeitig dumpen, ist es wahrscheinlich, dass der Preis der Kryptowährung fällt.
<G-vec00555-002-s385><drop.fallen><en> Even with the fuel tax increase, drivers and travelers are likely to pay less if prices continue to drop.
<G-vec00555-002-s385><drop.fallen><de> Selbst nach dieser Steuererhöhung ist es wahrscheinlich, dass Fahrzeughalter und Reisende immer noch weniger bezahlen, falls der Ölpreis weiter fällt.
<G-vec00555-002-s386><drop.fallen><en> Well kept, a cigar of this age can prove exceptional but, if the humidity in which it has been stored is allowed to drop much below the prescribed 65 to 70 percent, the taste will be harsh and unpalatable regardless of how perfect it was at its birth.
<G-vec00555-002-s386><drop.fallen><de> Eine gut aufbewahrte Zigarre dieses Alters kann sich als exzeptionell erweisen, doch wenn die Luftfeuchtigkeit bei der Lagerung zu weit unter die vorgeschriebenen 65 bis 70 Prozent fällt, dann wird sie herb und ungenießbar sein, ganz gleich wie perfekt der Geschmack bei ihrer Geburt war.
<G-vec00555-002-s387><drop.fallen><en> “Many of you are lying in beds of condemnation, from the time you awake and become conscious to the very moment you drop off to sleep.
<G-vec00555-002-s387><drop.fallen><de> “Viele von euch liegen in Betten der Verurteilung, von dem Zeitpunkt, wo ihr aufwacht und zu Bewusstsein kommt bis zu dem Augenblick, wo ihr ins Bett fällt, um zu schlafen.
<G-vec00555-002-s388><drop.fallen><en> A supporting Italian study, published in the National Institutes of Health, conquers that love impacts the serotonin system by causing serotonin (5-HT) levels to drop and obsessive, neurotic, obsessive-compulsive thinking about your lover to take over your brainwaves.
<G-vec00555-002-s388><drop.fallen><de> Eine italienische Studie, die vom nationalen Gesundheitsinstitut veröffentlicht wurde, fügt hinzu, dass Liebe Einfluss auf das Serotoninsystem hat, und dafür sorgt, dass der Serotoninspiegel (5-HAT) fällt und neurotische, besessene Gedanken über den Schwarm das Gehirn dominieren.
<G-vec00555-002-s389><drop.fallen><en> The score did not drop below 900 points.
<G-vec00555-002-s389><drop.fallen><de> Unter einen Wert von 900 Punkten fällt das Ergebnis nicht.
<G-vec00555-002-s390><drop.fallen><en> If the projector is suspended from a ceiling or wall mount and installed in an environment with heavy oil smoke or places where oils or chemicals are volatilized, places where a lot of smoke or bubbles are used for event staging, or where aroma oils are frequently burned, it can make certain parts of our products susceptible to a material degradation which over time could break and cause the projector to drop from the ceiling.
<G-vec00555-002-s390><drop.fallen><de> Falls der Projektor mittels Decken- oder Wandhalterung in einer stark ölhaltigen Atmosphäre installiert wurde oder sich an Orten befindet, an denen Öle und Chemikalien verflüchtigt beziehungsweise regelmäßig aromatische Öle verbrannt werden, können diese Substanzen bestimmte Materialien unserer Produkte angreifen, sodass diese mit der Zeit nachgeben und der Projektor möglicherweise aus der Befestigung fällt.
<G-vec00555-002-s391><drop.fallen><en> Those, who can not meet the requirements, drop behind in the competition.
<G-vec00555-002-s391><drop.fallen><de> Wer diese Vorgaben nicht erfüllen kann, fällt im Wettbewerb zurück.
<G-vec00555-002-s392><drop.fallen><en> • Over the year the temperature of water does not drop below 19℃.
<G-vec00555-002-s392><drop.fallen><de> • Im Laufe des Jahres fällt die Temperatur des Wassers nicht unter 19℃.
<G-vec00555-002-s393><drop.fallen><en> This will cause a drop in fluid pressure and cause the shift points to change and the clutches and brakes to slip.
<G-vec00555-002-s393><drop.fallen><de> Dadurch fällt der Flüssigkeitsdruck, die Schaltpunkte ändern sich und es macht sich Schlupf von Kupplungen und Bremsen des Automatikgetriebes bemerkbar.
<G-vec00555-002-s394><drop.fallen><en> It does not really need a spotlight to drop down from the sky right before one's feet...
<G-vec00555-002-s394><drop.fallen><de> Es muss ja nicht gleich ein Scheinwerfer sein, der einem vom Himmel direkt vor die Füße fällt...
<G-vec00555-002-s471><drop.fallenlassen><en> Drop Shipping: We do drop shipping.
<G-vec00555-002-s471><drop.fallenlassen><de> Tropfenverschiffen: Wir lassen Verschiffen fallen.
<G-vec00555-002-s472><drop.fallenlassen><en> Pine cones are open and drop their seeds.
<G-vec00555-002-s472><drop.fallenlassen><de> Kiefernzapfen sind offen und lassen ihre Samen fallen.
<G-vec00555-002-s473><drop.fallenlassen><en> Units drop resources on death.
<G-vec00555-002-s473><drop.fallenlassen><de> Einheiten lassen beim Tod Ressourcen fallen.
<G-vec00555-002-s474><drop.fallenlassen><en> As she talks to a co-worker, they drop a spotlight, climb the wall, load the hood into a van, and flee.
<G-vec00555-002-s474><drop.fallenlassen><de> Als sie ein Mitarbeiter darauf anspricht, lassen sie einen Scheinwerfer fallen, klettern über die Mauer, laden die Motorhaube in einen Lieferwagen ein und flüchten.
<G-vec00555-002-s475><drop.fallenlassen><en> Bonus Loot: These camps also drop certain chests, which can only be opened with red guard keys.
<G-vec00555-002-s475><drop.fallenlassen><de> Bonusbeute: Die Camps lassen außerdem Truhen fallen, die nur mit einem roten Wächterschlüssel geöffnet werden können.
<G-vec00555-002-s476><drop.fallenlassen><en> All enemies of socialism have the same face: If they are exposed then they act brutally and unscrupulously; they attack us in a blind range and drop their reactionary mask.
<G-vec00555-002-s476><drop.fallenlassen><de> Alle Feinde des Sozialismus haben dasselbe Gesicht: wenn sie entlarvt werden, dann handeln sie brutal und skrupellos, greifen uns blindwütig an und lassen ihre Maske fallen.
<G-vec00555-002-s477><drop.fallenlassen><en> In addition to finding new homes in a post-Cataclysm world, they drop new, improved loot, provide a healthy experience bonus, and respawn much more quickly when killed.
<G-vec00555-002-s477><drop.fallenlassen><de> Nicht nur, dass sie sich in der postkataklysmischen Welt ein neues Heim gesucht haben, nein, sie lassen auch neue, verbesserte Beute fallen, gewähren einen schönen Erfahrungsbonus und spawnen weitaus schneller nach, wenn sie getötet wurden.
<G-vec00555-002-s478><drop.fallenlassen><en> Nearby Diano Marina we drop the anchor.
<G-vec00555-002-s478><drop.fallenlassen><de> In der Nähe von Diano Marina lassen wir den Anker fallen.
<G-vec00555-002-s479><drop.fallenlassen><en> Unique – Favor: Enemy minions killed by your allies sometimes drop coins that give either 30 or restore 8% missing mana (minimum 15).
<G-vec00555-002-s479><drop.fallenlassen><de> Einmalig – Gefälligkeit: Gegnerische Vasallen, die von deinen Verbündeten getötet werden, lassen manchmal Münzen fallen, die entweder 30 oder 8% deines fehlenden Manas (mindestens 15) wiederherstellen.
<G-vec00555-002-s480><drop.fallenlassen><en> Some run into the open fields, others drop their bikes and take cover under a tree or try to flee into a house.
<G-vec00555-002-s480><drop.fallenlassen><de> Einige sind auf freien Feldwegen unterwegs, andere lassen ihr Fahrrad fallen, suchen Schutz unter einem Baum oder versuchen noch, in ein Haus zu flüchten.
<G-vec00555-002-s481><drop.fallenlassen><en> Cacti drop ordinary cactus when cut, even though they have a different color.
<G-vec00555-002-s481><drop.fallenlassen><de> Kakteen lassen den gewöhnlichen Kaktus-Gegenstand fallen, trotz ihres ungewöhnlichen Aussehens.
<G-vec00555-002-s482><drop.fallenlassen><en> Mobs[Baby zombies now drop loot upon death.
<G-vec00555-002-s482><drop.fallenlassen><de> Endermite Baby-Zombies lassen beim Tod nun Gegenstände fallen.
<G-vec00555-002-s483><drop.fallenlassen><en> We drop the anchor and symbolically our captain takes you to the port of the marriage.
<G-vec00555-002-s483><drop.fallenlassen><de> Wir lassen den Anker fallen und symbolisch bringt unser Kapitän Sie in den Hafen der EHE.
<G-vec00555-002-s484><drop.fallenlassen><en> Lay evenly 2 tablespoons of yogurt at the one end of the loukoumi and drop on it some pine nuts.
<G-vec00555-002-s484><drop.fallenlassen><de> Legen Sie gleichmäßig 2 Esslöffel griechischen Joghurt auf das eine Ende des Loukoumi und lassen Sie einige Pinienkerne darauf fallen.
<G-vec00555-002-s485><drop.fallenlassen><en> The Butcher: Minions that die near The Butcher will now always drop Fresh Meat stacks.
<G-vec00555-002-s485><drop.fallenlassen><de> Der Schlächter: Diener, die in der Nähe des Schlächters sterben, lassen jetzt immer Stapel von Frischfleisch fallen.
<G-vec00555-002-s486><drop.fallenlassen><en> Lucrative PvE graves: You can largely ignore the graves of other players, but defeated samurai usually drop good items.
<G-vec00555-002-s486><drop.fallenlassen><de> Lukrative PvE-Gräber Die Gräber anderer Spieler könnt ihr größtenteils ignorieren, allerdings lassen die besiegten Samurai meist gute Gegenstände fallen.
<G-vec00555-002-s487><drop.fallenlassen><en> Humanoid creatures drop currency.
<G-vec00555-002-s487><drop.fallenlassen><de> Humanoide Kreaturen lassen bei Tod ihr mitgeführtes Geld fallen.
<G-vec00555-002-s488><drop.fallenlassen><en> If there are defeats between options in the Schwartz set, we drop the weakest such defeats from the list of pairwise defeats, and return to step 5. a.
<G-vec00555-002-s488><drop.fallenlassen><de> Wenn es Besiegungen zwischen Wahlmöglichkeiten gibt, die in der Schwartzschen Menge liegen, so lassen wir die schwächste solcher Besiegungen aus der Liste der paarweisen Besiegungen fallen und kehren zu Schritt 5 zurück.
<G-vec00555-002-s489><drop.fallenlassen><en> Most of us drop our phones more than once.
<G-vec00555-002-s489><drop.fallenlassen><de> Die meisten Menschen lassen ihr Smartphone mehr als nur einmal fallen.
<G-vec00555-002-s396><drop.gehen><en> It's getting cooler: From 21 degrees on Tuesday the daily highs drop to 16 degrees on Thursday.
<G-vec00555-002-s396><drop.gehen><de> Es wird kühler: Von 21 Grad am Mittwoch gehen die Höchstwerte auf 16 Grad am Donnerstag zurück.
<G-vec00555-002-s397><drop.gehen><en> It's getting colder: From 8 degrees on Friday the daily highs drop to 4 degrees on Sunday. Forecast
<G-vec00555-002-s397><drop.gehen><de> Es wird kälter: Von 8 Grad am Montag gehen die Höchstwerte auf 4 Grad am Mittwoch zurück.
<G-vec00555-002-s398><drop.gehen><en> But snow will fall on Tuesday. It's getting colder: Up to Wednesday the temperature will drop slowly to 7 degrees.
<G-vec00555-002-s398><drop.gehen><de> Es wird kälter: Von 11 Grad am Dienstag gehen die Höchstwerte auf 7 Grad am Mittwoch zurück.
<G-vec00555-002-s399><drop.gehen><en> Sadhana is a spiritual practice, our techniques help you still the mind and drop into the silence of the heart where love can blossom.
<G-vec00555-002-s399><drop.gehen><de> Unsere Methoden werden dir helfen den Verstand zu beruhigen und in die Stille deines Herzens zu gehen, wo sich die Liebe entfalten kann.
<G-vec00555-002-s400><drop.gehen><en> Set it on the switch and go through the door. Drop down the hole.
<G-vec00555-002-s400><drop.gehen><de> Platziert hier eine der Holzboxen auf den Schalter, damit ihr durch die Türe gehen könnt.
<G-vec00555-002-s401><drop.gehen><en> The heat is decreasing: From 29 degrees on Saturday the daily highs drop to 24 degrees on Monday.
<G-vec00555-002-s401><drop.gehen><de> Von 29 Grad am Sonntag gehen die Höchstwerte auf 21 Grad am Montag zurück.
<G-vec00555-002-s402><drop.gehen><en> It's getting cooler: From 23 degrees on Tuesday the daily highs drop to 19 degrees on Wednesday. Forecast
<G-vec00555-002-s402><drop.gehen><de> Es wird kühler: Von 23 Grad am Montag gehen die Höchstwerte auf 19 Grad am Mittwoch zurück.
<G-vec00555-002-s403><drop.gehen><en> It's getting cooler: From 23 degrees on Tuesday the daily highs drop to 19 degrees on Wednesday. Forecast
<G-vec00555-002-s403><drop.gehen><de> Es wird kühler: Von 23 Grad am Dienstag gehen die Höchstwerte auf 19 Grad am Mittwoch zurück.
<G-vec00555-002-s404><drop.gehen><en> The pirates drop anchor and row ashore.
<G-vec00555-002-s404><drop.gehen><de> Die Piraten gehen vor Anker und rudern an Land.
<G-vec00555-002-s405><drop.gehen><en> It's getting cooler: From 27 degrees on Sunday the daily highs drop to 23 degrees on Tuesday. Forecast
<G-vec00555-002-s405><drop.gehen><de> Es wird kühler: Von 27 Grad am Dienstag gehen die Höchstwerte auf 22 Grad am Donnerstag zurück.
<G-vec00555-002-s407><drop.gehen><en> It's getting cooler: From 25 degrees on Tuesday the daily highs drop to 19 degrees on Thursday.
<G-vec00555-002-s407><drop.gehen><de> Es wird kühler: Von 25 Grad am Sonntag gehen die Höchstwerte auf 21 Grad am Montag zurück.
<G-vec00555-002-s408><drop.gehen><en> It's getting cooler: From 24 degrees on Thursday the daily highs drop to 14 degrees on Friday. Forecast
<G-vec00555-002-s408><drop.gehen><de> Es wird kühler: Von 19 Grad am Mittwoch gehen die Höchstwerte auf 14 Grad am Donnerstag zurück.
<G-vec00555-002-s409><drop.gehen><en> -We provide homework and revision support for the child not to school drop and to remain at the best level he can be.
<G-vec00555-002-s409><drop.gehen><de> – Wir bieten Hausaufgaben und Revisionsunterstützung für das Kind an, um nicht zur Schule zu gehen und auf dem bestmöglichen Niveau zu bleiben.
<G-vec00555-002-s410><drop.gehen><en> for your olives shall drop off. 41 You shall beget sons and daughters, but they shall not remain yours;
<G-vec00555-002-s410><drop.gehen><de> 41 Du wirst Söhne und Töchter zeugen und doch keine haben, denn sie werden in die Gefangenschaft gehen.
<G-vec00555-002-s411><drop.gehen><en> He stands calm, relaxed and smiling and from his subtle punches, the recipients drop on their knees, totally loose focus of their eyes, laugh or cry.
<G-vec00555-002-s411><drop.gehen><de> Er steht ruhig da, entspannt und lächelnd und durch seine subtilen Schläge gehen die Leute zu Boden, verlieren komplett ihren Fokus, lachen oder weinen.
<G-vec00555-002-s412><drop.gehen><en> The length should drop just below the knee.
<G-vec00555-002-s412><drop.gehen><de> Die Länge sollte bis über das Knie gehen.
<G-vec00555-002-s413><drop.gehen><en> It's getting colder: From 16 degrees on Thursday the daily highs drop to 6 degrees on Friday.
<G-vec00555-002-s413><drop.gehen><de> Es wird kälter: Von 16 Grad am Montag gehen die Höchstwerte auf 9 Grad am Mittwoch zurück.
<G-vec00555-002-s414><drop.gehen><en> Modern-day Nottingham is a bustling hive of activity, where you can shop ‘til you drop and dine out in style.
<G-vec00555-002-s414><drop.gehen><de> Das moderne Nottingham ist ein pulsierendes Zentrum, in dem Sie bis zum Umfallen shoppen gehen und stilvoll essen gehen können.
<G-vec00555-002-s434><drop.können><en> Luck is on your side with 3 free spins that randomly drop at any time, turning up to three reels completely wild for each spin.
<G-vec00555-002-s434><drop.können><de> Das Glück ist auf deiner Seite: Jederzeit können zufällig 3 Free Spins aktiviert werden, wobei für jeden Spin bis zu drei Walzen vollständig in Jokersymbole verwandelt werden.
<G-vec00555-002-s435><drop.können><en> For those who want to continue partying, the hotel has a great disco with a professional DJ that will make you dance until you drop.
<G-vec00555-002-s435><drop.können><de> Überdies hat das Hotel für alle die weiter feiern möchten, eine große Discothek mit einem profesionellen DJ, damit Sie tanzen können solange der Körper mitmacht.
<G-vec00555-002-s436><drop.können><en> Drag and drop to reorder, create folders and subfolders, scale the brush stroke preview, toggle new view modes, and save brush presets with opacity, flow, blend mode, and color. Brush performance improvements
<G-vec00555-002-s436><drop.können><de> Sie können die Reihenfolge per Drag-and-Drop ändern, Ordner und Unterordner erstellen, die Vorschau der Pinselstriche skalieren, neue Ansichtsmodi ein- und ausschalten und Pinselvorgaben einschließlich Einstellungen für Deckkraft, Fluss, Mischmodus und Farbe speichern.
<G-vec00555-002-s437><drop.können><en> To determine which brake pad references fit to your VARIO, we recommend you select the engine type of your Mercedes-Benz $serie in the drop down menu or enter your registration number.
<G-vec00555-002-s437><drop.können><de> Wählen Sie jetzt den genauen Typ Ihres Mercedes-Benz VARIO aus, um alle Bremsbeläge, die für Ihren VARIO geeignet sind, einsehen zu können.
<G-vec00555-002-s438><drop.können><en> If you have baggage to check in, drop it at a Bag Drop desk.
<G-vec00555-002-s438><drop.können><de> Falls Sie Gepäck einchecken möchten, können Sie dies am Bag Drop-Schalter tun.
<G-vec00555-002-s439><drop.können><en> Not to mention enough shops to shop until you drop... into the beautiful orchid garden to relax.
<G-vec00555-002-s439><drop.können><de> Von den vielen Shops ganz zu schweigen… Sie können an diesem Flughafen shoppen bis zum Abwinken und sich danach im wunderschönen Orchideengarten entspannen.
<G-vec00555-002-s440><drop.können><en> To find out which references are suitable for your car, we recommend you select the model and engine type of your Citroen BERLINGO in the drop down menu or enter your registration number.
<G-vec00555-002-s440><drop.können><de> Wählen Sie jetzt den genauen Typ Ihres BERLINGO aus, um alle Bremsscheiben, die für Ihren Citroen BERLINGO geeignet sind, einsehen zu können.
<G-vec00555-002-s441><drop.können><en> To determine which brake pad references fit to your BRAVA, we recommend you select the engine type of your Fiat $serie in the drop down menu or enter your registration number.
<G-vec00555-002-s441><drop.können><de> Wählen Sie jetzt den genauen Typ Ihres Fiat BRAVA aus, um alle Bremsbeläge, die für Ihren BRAVA geeignet sind, einsehen zu können.
<G-vec00555-002-s442><drop.können><en> Example: For a party of five players, Dungeon bosses are now guaranteed to drop at least 1 item with a chance for 2 items to drop.
<G-vec00555-002-s442><drop.können><de> Beispiel: Bei einer Gruppe aus fünf Spielern können Spieler jetzt mindestens 1 Gegenstand von einem Dungeonboss erbeuten, wobei die Chance besteht, dass 2 Gegenstände verfügbar sind.
<G-vec00555-002-s443><drop.können><en> All you have to do is drag and drop the files and folders you want to transfer from your PC.
<G-vec00555-002-s443><drop.können><de> Durch einfaches Ziehen-und-Ablegen können Sie Dateien und Ordner von Ihrem PC übertragen.
<G-vec00555-002-s444><drop.können><en> Orbi creates one seamless network, so as you move from room to room, your signal won't drop.
<G-vec00555-002-s444><drop.können><de> Orbi generiert ein nahtloses Netzwerk, sodass Sie sich frei von Raum zu Raum bewegen können, ohne dass das Signal schwächer wird.
<G-vec00555-002-s445><drop.können><en> To determine as well as possible which spark plug references are suitable for your car we recommend you enter your registration number or select the engine type of your Nissan ALMERA in the drop down menu.
<G-vec00555-002-s445><drop.können><de> Wählen Sie jetzt den genauen Typ Ihres Fahrzeugs aus, um alle Wärmetauscher, die für Ihren Nissan ALMERA geeignet sind, einsehen zu können.
<G-vec00555-002-s446><drop.können><en> ...In the right hand corner (menu "View") you find a drop down list for selecting the period of time for which you would like to show the charts.
<G-vec00555-002-s446><drop.können><de> ...Auf der rechten Seite im Menü "Ansicht" können Sie den Zeitraum für den die Daten angezeigt werden sollen einstellen.
<G-vec00555-002-s447><drop.können><en> A courtesy car service is available for downtown pick up and drop off, subject to availability.
<G-vec00555-002-s447><drop.können><de> Bei Verfügbarkeit können Sie den kostenfreien Autoservice von und zur Innenstadt nutzen.
<G-vec00555-002-s448><drop.können><en> Drag and drop personal events to change times or delete personal events that you no longer need.
<G-vec00555-002-s448><drop.können><de> Per Drag-and-Drop können Sie die Uhrzeit persönlicher Ereignisse ändern oder persönliche Ereignisse, die nicht mehr relevant sind, löschen.
<G-vec00555-002-s449><drop.können><en> To offer you fitting tie rod ends for car, we recommend you select the model and engine type of your Fiat DOBLO in the drop down menu or enter your registration number.
<G-vec00555-002-s449><drop.können><de> Wählen Sie jetzt den genauen Typ Ihres Fiat DOBLO aus, um alle Bremsbeläge, die für Ihren DOBLO geeignet sind, einsehen zu können.
<G-vec00555-002-s450><drop.können><en> With this drag and drop support, you are sure to design personalized visual effects easily.
<G-vec00555-002-s450><drop.können><de> Mit dieser Drag-and-Drop-Unterstützung können Sie ganz einfach personalisierte visuelle Effekte entwerfen.
<G-vec00555-002-s451><drop.können><en> Resolves an issue that prevented adding allowed websites from Safari via drag and drop.
<G-vec00555-002-s451><drop.können><de> Behebung eines Problems, bei dem verhindert wird, dass erlaubte Websites in Safari per Drag-and-Drop hinzugefügt werden können.
