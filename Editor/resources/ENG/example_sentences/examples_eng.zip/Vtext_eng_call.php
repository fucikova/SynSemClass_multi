<G-vec00092-001-s057><call.bezeichnen><en> The offers of the tantric scene, which I got to know, I would not call the same.
<G-vec00092-001-s057><call.bezeichnen><de> Ich würde die Angebote der Tantra-Szene, die ich kennengelernt habe, nicht als das bezeichnen wollen.
<G-vec00092-001-s058><call.bezeichnen><en> Well, I read it and I would call it revolutionary.
<G-vec00092-001-s058><call.bezeichnen><de> Ich habe es gelesen und würde es als revolutionär bezeichnen.
<G-vec00092-001-s059><call.bezeichnen><en> That is something we would call highly concentrated.
<G-vec00092-001-s059><call.bezeichnen><de> So etwas würden WIR als hochkonzentriert bezeichnen.
<G-vec00092-001-s060><call.bezeichnen><en> What people call practice these days is not really practice.
<G-vec00092-001-s060><call.bezeichnen><de> Was die Leute heutzutage als Praxis bezeichnen, ist keine wirkliche Praxis mehr.
<G-vec00092-001-s061><call.bezeichnen><en> I would call it repressive tolerance, and it's still the case today.
<G-vec00092-001-s061><call.bezeichnen><de> Ich würde das als »repressive Toleranz« bezeichnen, ein Prinzip, das auch heute noch zu beobachten ist.
<G-vec00092-001-s062><call.bezeichnen><en> “Mystical bird” the Romanians call the capercaillie.
<G-vec00092-001-s062><call.bezeichnen><de> Als „mystischen Vogel“ bezeichnen die Rumänen den Auerhahn.
<G-vec00092-001-s063><call.bezeichnen><en> First, the introduction of the common currency led to a huge movement of capital into those countries that we today call PIIGS or periphery countries.
<G-vec00092-001-s063><call.bezeichnen><de> Zunächst löste die Einführung der gemeinsamen Währung eine enorme Kapitalbewegung in die Länder aus, die wir heute als PIIGS oder Peripheriestaaten bezeichnen.
<G-vec00092-001-s064><call.bezeichnen><en> We can only call them evil policemen.
<G-vec00092-001-s064><call.bezeichnen><de> Wir können sie nur als bösartige Polizisten bezeichnen.
<G-vec00092-001-s065><call.bezeichnen><en> """I wish you'd call it what it is,"" she said."
<G-vec00092-001-s065><call.bezeichnen><de> """Ich wünschte, du würdest ihn als das bezeichnen, was er ist"", sagte sie."
<G-vec00092-001-s066><call.bezeichnen><en> "Some people would call that ""progress"" or ""innovation""."
<G-vec00092-001-s066><call.bezeichnen><de> "Manche würden das jetzt als ""Fortschritt"" oder auf neudeutsch ""Innovation"" bezeichnen."
<G-vec00092-001-s067><call.bezeichnen><en> "A being can also have an incurable illness that is rapidly leading towards the destruction of the organism or body, towards what we call ""death"", and from the point of view of the body the situation is hopeless, but behind this hopelessness there is still burning a tiny flame from Paradise."
<G-vec00092-001-s067><call.bezeichnen><de> Ein Wesen kann auch einer unheilbaren Krankheit ausgesetzt sein, die den Organismus oder Körper unaufhaltsam seinem Untergang, d.h. dem, was wir als „Tod“ bezeichnen, entgegenführt, und die Situation ist damit körperlich gesehen hoffnungslos, aber trotzdem lodert hinter dieser Hoffnungslosigkeit eine kleine Flamme aus dem Paradies.
<G-vec00092-001-s068><call.bezeichnen><en> "When a word has several different definitions, you cannot limit your understanding of the word to one definition only and call the word ""understood."""
<G-vec00092-001-s068><call.bezeichnen><de> "Wenn ein Wort mehrere verschiedene Definitionen hat, können Sie Ihr Verstehen dieses Wortes nicht nur auf eine Definition beschränken und es als ""verstanden"" bezeichnen."
<G-vec00092-001-s069><call.bezeichnen><en> "Yeah, the genre itself is mainly influenced by the 80s but if you listen to Santa Cruz, you hear right away that it`s not Hard Rock from the 80s; it`s rather something I would call ""Modern Hard Rock""."
<G-vec00092-001-s069><call.bezeichnen><de> "Ja, das Genre an sich ist vornehmlich von den 80ern beeinflusst, aber hier hört man sofort, dass dies kein Hard Rock aus den 80ern ist, sondern etwas, dass ich persönlich als ""Modern Hard Rock"" bezeichnen würde."
<G-vec00092-001-s070><call.bezeichnen><en> But maybe the badly written dialogues are to blame that you seldom can call the acting well done.
<G-vec00092-001-s070><call.bezeichnen><de> Vielleicht sind aber auch die schlecht geschriebenen Dialoge daran schuld, dass man das Schauspiel selten als gelungen bezeichnen kann.
<G-vec00092-001-s071><call.bezeichnen><en> What people call this body is merely the result of a willed concentration organized in a specific way; that's how it spontaneously feels, all the time (not that it's observing itself, but if something forces it to observe itself, that's what it spontaneously feels).
<G-vec00092-001-s071><call.bezeichnen><de> Nur eine willentliche Konzentration in einer besonderen Anordnung ergibt das, was wir als Körper bezeichnen – spontan fühlt er sich immer so (er hält nicht inne, sich zu beobachten, aber wenn etwas ihn veranlaßt, sich zu betrachten, spürt er es spontan so).
<G-vec00092-001-s072><call.bezeichnen><en> "And yet, as Daniel Pauly shows us onstage at Mission Blue, each time the baseline drops, we call it the new ""normal."""
<G-vec00092-001-s072><call.bezeichnen><de> "Daniel Pauly zeigt uns in einem Vortrag während der Mission Blue, dass wir jedes Mal, wenn sich die Zahlen der Normwerte nach unten bewegen, wir sie als das neue ""Normal"" bezeichnen."
<G-vec00092-001-s073><call.bezeichnen><en> It is interesting because the action is very powerful, but I can't call it pleasant.
<G-vec00092-001-s073><call.bezeichnen><de> Es ist interessant, denn die Aktion ist sehr machtvoll, aber ich kann diese Zeit nicht als erfreulich bezeichnen.
<G-vec00092-001-s074><call.bezeichnen><en> "Micha Brumlik notes that, above all it is Levinas to whom we owe an appreciation of what one could call ""eastern European Jewry""."
<G-vec00092-001-s074><call.bezeichnen><de> "Micha Brum-lik stellt dar, dass wir vor allem Levinas eine Würdigung dessen verdanken, was man als ""Ostjudentum"" bezeichnen könnte."
<G-vec00092-001-s075><call.bezeichnen><en> With Springsteen, I would call this title very arbitrary.
<G-vec00092-001-s075><call.bezeichnen><de> Bei Springsteen würde ich diese Titel als sehr beliebig bezeichnen.
<G-vec00092-001-s114><call.anrufen><en> Call: Select and confirm the desired telephone number.
<G-vec00092-001-s114><call.anrufen><de> Anrufen: Wählen und bestätigen Sie die gewünschte Telefonnummer.
<G-vec00092-001-s115><call.anrufen><en> Company dedicated to the sale of minutes to call centers, More... companies and also offer call termination equipment sales ip virtuale nuemros recargs s virtual.
<G-vec00092-001-s115><call.anrufen><de> Unternehmen spezialisiert auf den Verkauf von Minuten, Unternehmen anrufen und Mehr... bieten auch die Anrufzustellung Ausrüstung Verkäufe ip virtuale nuemros recargs s virtuell.
<G-vec00092-001-s116><call.anrufen><en> He has extended His wonderful salvation to ALL who call upon His Name and repent, whatever their background: ROMANS 9:6-8 and ROMANS 11:17-27 demonstrate this clearly.
<G-vec00092-001-s116><call.anrufen><de> Er hat Seine wundervolle Errettung ALLEN verheißen, die Seinen Namen anrufen und Buße tun, ganz gleich welcher Herkunft: RÖMER 9:6-8 und RÖMER 11:17-27 machen das sehr deutlich.
<G-vec00092-001-s117><call.anrufen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00092-001-s117><call.anrufen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00092-001-s118><call.anrufen><en> It is very easy and you have nothing to worry about, she will do everything for you Call our agency and make a booking We will give you all the information you need to encounter the best escorts of Amsterdam.
<G-vec00092-001-s118><call.anrufen><de> Es ist sehr einfach, und Sie haben nichts zu befürchten, sie werden alles tun, damit Sie unsere Agentur anrufen und eine Reservierung vorzunehmen Wir Sie alle Informationen erhalten Sie brauchen die besten Begleiter von Amsterdam zu begegnen.
<G-vec00092-001-s119><call.anrufen><en> "If you do not want to wait until the web page loads and a logical question emerges about how to add traffic to ""Tele2"", you should visit the official website of the operator or call the contact center and specify how it can be done."
<G-vec00092-001-s119><call.anrufen><de> Wenn Sie nicht, bis die Download-Webseite warten möchten, und es war eine logische Frage, wie Verkehr zu „Tele2“ hinzufügen möchte, sollten Sie die offizielle Website Betreiber besuchen oder das Contact Center anrufen und klären, wie es getan werden kann.
<G-vec00092-001-s120><call.anrufen><en> When you call 112, you will be connected to an operator who will pass you on to the emergency service you require.
<G-vec00092-001-s120><call.anrufen><de> Wenn Sie die 112 anrufen, werden Sie mit einem Mitarbeiter verbunden, der Sie an den passenden Notdienst weiterleitet.
<G-vec00092-001-s121><call.anrufen><en> If you are so hungry for these moments, like me, then you should not wait any longer but call me directly.
<G-vec00092-001-s121><call.anrufen><de> Wenn du dich auch so sehr nach diesen Momenten sehnst, wie ich, dann solltest du nicht noch länger warten sondern mich direkt anrufen.
<G-vec00092-001-s122><call.anrufen><en> 2 To the church of God which is at Corinth, to those who are sanctified in Christ Jesus, called to be saints, with all who in every place call on the name of Jesus Christ our Lord, both theirs and ours:
<G-vec00092-001-s122><call.anrufen><de> 2 an die Gemeinde Gottes, die in Korinth ist, den Geheiligten in Christus Jesus, den berufenen Heiligen, samt allen, die an jedem Ort den Namen unseres Herrn Jesus Christus anrufen, ihres und unseres [Herrn].
<G-vec00092-001-s123><call.anrufen><en> Calling anywhere outside Kuwait is extremely expensive, regardless of when you call.
<G-vec00092-001-s123><call.anrufen><de> Aufruf irgendwo außerhalb Kuwait ist extrem teuer, unabhängig davon, wann Sie anrufen.
<G-vec00092-001-s124><call.anrufen><en> "To restore hope to Europe, therefore, the Churches must look to her and call upon her to continue to show herself as Mother of Hope and lead the entire European continent through the paths of mercy to a revitalising encounter with ""Jesus Christ, our Hope"" (1 Tim1:1)."
<G-vec00092-001-s124><call.anrufen><de> "Um Europa neue Hoffnung zu geben, müssen die Kirchen auf Maria schauen und sie anrufen, damit sie sich weiterhin als Mutter der Hoffnung zeigt und ganz Europa auf dem Weg des Erbarmens zur erneuernden Begegnung mit ""Jesus Christus, unsere Hoffnung"" (1 Tim 1, 1) führt."
<G-vec00092-001-s125><call.anrufen><en> Cortana can remind you of something when you call or text someone, or when they call or text you.
<G-vec00092-001-s125><call.anrufen><de> Cortana kann Sie an etwas erinnern, wenn Sie jemanden anrufen oder ihm eine SMS senden oder wenn die betreffende Person Sie anruft oder Ihnen eine SMS sendet.
<G-vec00092-001-s126><call.anrufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00092-001-s126><call.anrufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00092-001-s127><call.anrufen><en> If you have additional questions you may also call toll free: 0800 098 8202 (GB), 24 hours a day, 7 days a week.
<G-vec00092-001-s127><call.anrufen><de> Wenn Sie weitere Fragen haben, können Sie auch anrufen 0800 098 8202 (GB), 24 Stunden am Tag, 7 Tage die Woche.
<G-vec00092-001-s128><call.anrufen><en> If you would like to purcase a CD, you are most welcome to email or call me.
<G-vec00092-001-s128><call.anrufen><de> Wenn Sie eine CD bestellen möchten, können Sie mir gerne eine Email schreiben oder mich anrufen.
<G-vec00092-001-s129><call.anrufen><en> This decision came from the awareness that most students and bystanders call the ambulance only when the health condition came critical.
<G-vec00092-001-s129><call.anrufen><de> Diese Entscheidung kam aus dem Bewusstsein, dass die meisten Studenten und Umstehenden den Krankenwagen nur dann anrufen, wenn der Gesundheitszustand kritisch wurde.
<G-vec00092-001-s130><call.anrufen><en> If somebody who regularly comes to the center stops coming, especially if it is someone living alone, call and find out if they are sick, if they need any help.
<G-vec00092-001-s130><call.anrufen><de> Wenn jemand, der regelmäßig das Zentrum besucht, nicht mehr kommt, insbesondere wenn es sich um jemanden handelt, der allein lebt, sollte man anrufen und sich erkundigen, ob er krank ist oder Hilfe braucht.
<G-vec00092-001-s131><call.anrufen><en> Call: Select and confirm a favourite/your home address.
<G-vec00092-001-s131><call.anrufen><de> Anrufen: Wählen und bestätigen Sie einen Favoriten/die Heimatadresse.
<G-vec00092-001-s132><call.anrufen><en> If you are not sure since, if a voucher or coupon is valid, then you can call us or write an email.
<G-vec00092-001-s132><call.anrufen><de> Wenn ihr euch nicht sicher seit, ob ein Gutschein oder Coupon gültig ist, dann könnt ihr uns gerne anrufen oder eine Mail schreiben.
<G-vec00092-001-s152><call.anrufen><en> He asked the Uzbeks to call him to snap a session, if they suddenly found a new corpse and decide to bury it.
<G-vec00092-001-s152><call.anrufen><de> Er bat die Usbeken, ihn für eine Aufnahmesession anzurufen, sobald sie wieder eine Leiche finden würden, die bestattet werden musste.
<G-vec00092-001-s153><call.anrufen><en> "In my case, I am sorrowful, because I lost her 1 1/2 month ago, but it not pass one day, in which I not be remember in her about the memory key ""Grandparents"" of the phone and the need to call her for hear her voice."
<G-vec00092-001-s153><call.anrufen><de> "In meinem Fall, bin ich sehr traurig, weil ich sie vor 1 1/2 Monaten verloren habe, aber nicht ein Tag vergeht, an dem ich nicht durch die Abspeicherungstaste ""Grosseltern"" am Telefon an sie erinnert werde und das Bedürfnis verspüre, sie anzurufen, um ihre Stimme zu hören."
<G-vec00092-001-s154><call.anrufen><en> If you would like to become better acquainted with us, we invite you to take a look at our home page or call us or write to us.
<G-vec00092-001-s154><call.anrufen><de> Wenn Sie uns näher kennen lernen wollen, laden wir Sie ein, einen Blick auf unsere Homepage zu werfen oder uns anzurufen oder zu schreiben.
<G-vec00092-001-s155><call.anrufen><en> The truth is, you have the power to call on angels to light your way.
<G-vec00092-001-s155><call.anrufen><de> Die Wahrheit ist, du hast die Macht, Engel anzurufen, um deinen Weg zu beleuchten.
<G-vec00092-001-s156><call.anrufen><en> But people should be informed that earth is a planet on its own which has no connection with other worlds, and that any connection with other worlds can only be spiritually established.... Hence the human being is, in fact, able to make contact with inhabitants of advanced worlds, with the kingdom of light, by way of good and appealing thoughts for help at times of spiritual hardship.... which will then be given to him spiritually.... but that it is not advisable for him to call on beings on other stars whose spiritual degree of maturity and their ability to offer spiritual help is unknown to him.
<G-vec00092-001-s156><call.anrufen><de> Die Menschen sollen aber darüber aufgeklärt werden, daß die Erde ein Gestirn für sich ist, das keine Verbindung hat mit anderen Welten, und daß jegliche Bindung mit deren Bewohnern nur geistig herzustellen ist.... daß also sich der Mensch wohl den Bewohnern höherer Welten, des Lichtreiches, verbinden kann durch gute bittende Gedanken um Hilfe in geistiger Not.... die ihm geistig wohl auch geleistet wird.... daß es aber für ihn nicht ratsam ist, Wesen anzurufen von Gestirnen, von denen er nicht weiß, in welchem geistigen Reifegrad diese stehen und ob sie ihm geistige Hilfe gewähren können.
<G-vec00092-001-s157><call.anrufen><en> We tried to call the owner, but the phone number in the reservation confirmation was wrong.
<G-vec00092-001-s157><call.anrufen><de> Wir haben versucht, den Besitzer anzurufen, aber die Telefonnummer in der Reservierungsbestätigung war falsch.
<G-vec00092-001-s158><call.anrufen><en> Should you have further questions, do not hesitate to use the contact form or to call us directly.
<G-vec00092-001-s158><call.anrufen><de> Sollten Sie Fragen haben, zögern Sie nicht, das Kontaktformular zu nutzen oder uns direkt anzurufen.
<G-vec00092-001-s159><call.anrufen><en> Scenario: Joe is trying to call Mary but the operator doesn't know who Mary is.
<G-vec00092-001-s159><call.anrufen><de> Beispielszene: Joe versucht Mary anzurufen, aber der Operator weiß nicht, wer Mary ist.
<G-vec00092-001-s160><call.anrufen><en> I do not want that men must suffer, but I recognize the necessity, to lead them on to the right way through unusual suffering; I recognize their often uncompromising will, which defies me and which I cannot break forcibly to not endanger its perfection; I therefore can only seek to change this will through means, which finally men determine themselves, to call me, to then supply the proof to them through help for their faith that I am from eternity to eternity and stand in indissoluble connection with my creatures.
<G-vec00092-001-s160><call.anrufen><de> Ich will nicht, daß die Menschen leiden müssen, aber Ich erkenne die Notwendigkeit, sie durch ungewöhnliches Leid auf den rechten Weg zu führen, Ich erkenne ihren oft unbeugsamen Willen, der Mir trotzet und den Ich nicht gewaltsam brechen kann, um nicht seine Vollendung zu gefährden; Ich kann also diesen Willen nur zu wandeln suchen durch Mittel, die den Menschen zuletzt selbst bestimmen, Mich anzurufen, um ihnen dann durch Hilfeleistung für ihren Glauben den Beweis zu liefern, daß Ich bin von Ewigkeit zu Ewigkeit und mit Meinen Geschöpfen in unauflösbarer Verbindung stehe.
<G-vec00092-001-s161><call.anrufen><en> After that talk, I never received any further information regarding my passport, so I decided to call the Consulate to get an update on the situation.
<G-vec00092-001-s161><call.anrufen><de> Nach diesem Gespräch erhielt ich keine weiteren Informationen bezüglich der Verlängerung meines Passes und so entschloss ich mich, das Konsulat anzurufen um zu erfahren, wie der Stand der Dinge sei.
<G-vec00092-001-s162><call.anrufen><en> If we need more information before we can complete it, you'll be asked to call us.
<G-vec00092-001-s162><call.anrufen><de> Sofern wir für die weitere Bearbeitung zusätzliche Informationen benötigen, werden Sie gebeten, uns anzurufen.
<G-vec00092-001-s163><call.anrufen><en> 2007-11-13 22:16:19 - A real man Something I find 100% humor in is the fact that men are so quick to call women bitches.
<G-vec00092-001-s163><call.anrufen><de> 2007-11-13 22:16:19 - Ein Wirklicher Mann Etwas, die ich die 100%-Stimmung ist finde innen, die Tatsache, daß Männer so schnell sind, Frauen anzurufen Weibchen.
<G-vec00092-001-s164><call.anrufen><en> In his own supplications to God, he is known to have said, “Oh God, I ask you of you by every name that You have named yourself, or that You have revealed in Your book, or that You have taught any of Your creation, or that You have kept hidden in the unseen knowledge with Yourself.”[2] We are encouraged to call upon God by the name that is specific to the kind of care and help we need.
<G-vec00092-001-s164><call.anrufen><de> Wir wissen, dass er in seinen eigenen Bittgebeten zu Gott sagte: “Oh Gott, ich bitte Dich bei jedem Namen, mit dem du Dich Selbst bezeichnet hast oder den Du in Deinem Buch offenbart hast oder den Du jemandem von Deiner Schöpfung gelehrt hast oder den Du mit dem Wissen von der Verborgenheit für Dich behalten hast.”[2] Wir werden aufgefordert, Gott mit dem Namen anzurufen, der speziell zu der Art der Sorge und Hilfe, um die wir bitten wollen, passt.
<G-vec00092-001-s165><call.anrufen><en> To call the girl or guy who liked to go to a movie, all of a sudden to buy a ticket to somewhere and go (or fly) on the weekend.
<G-vec00092-001-s165><call.anrufen><de> Um das Mädchen oder den Kerl anzurufen, der gern in einen Film ging, plötzlich ein Ticket zu irgendwo zu kaufen und am Wochenende zu fliegen (oder zu fliegen).
<G-vec00092-001-s166><call.anrufen><en> It’s as easy as one, two, three. three. Just call or write us and together we will find the best solution for you.
<G-vec00092-001-s166><call.anrufen><de> Mit uns wird eine Gesellschaft eins zwei drei gegründet, es genügt, uns anzurufen oder uns zu schreiben und wir finden gemeinsam die beste Lösung für Sie.
<G-vec00092-001-s167><call.anrufen><en> I literally ran to the phone to call him.
<G-vec00092-001-s167><call.anrufen><de> Ich rannte buchstäblich zum Telefon, um ihn anzurufen.
<G-vec00092-001-s168><call.anrufen><en> After all, anyone has the right to call 911…
<G-vec00092-001-s168><call.anrufen><de> Schließlich hat jeder das Recht, 911 anzurufen...
<G-vec00092-001-s169><call.anrufen><en> In the event that you are unable to locate the driver of your private transfer or the representative of the shuttle Transport Operator, it is your responsibility to contact us on the 24/7 telephone numbers printed on your Transfer Voucher. If you fail to call these numbers and make alternative travel arrangements, we will be unable to provide the service, the Transport Operator will be relieved of their obligations and a refund will not be due.
<G-vec00092-001-s169><call.anrufen><de> Sollten Sie den Fahrer Ihres privaten Transfers oder den Vertreter des Shuttle-Transportunternehmens bei der Ankunft am Flughafen nicht finden, liegt es in Ihrer Verantwortung, uns über die 24-Stunden-Telefonnummern, die auf dem Transferbeleg aufgeführt sind, zu kontaktieren Versäumen Sie es, diese Nummern anzurufen, und vereinbaren stattdessen alternative Reisearrangements, wird die Leistung nicht erbracht, das Transportunternehmen wird von seinen Verpflichtungen entbunden und eine Erstattung wird nicht fällig.
<G-vec00092-001-s170><call.anrufen><en> When you use your mobile phone in other EU countries – to call, text (send SMS messages) or go online – there's a limit on what your operator can charge you.
<G-vec00092-001-s170><call.anrufen><de> Wenn Sie Ihr Mobiltelefon in anderen EU-Ländern verwenden – um anzurufen, eine SMS zu verschicken oder im Internet zu surfen –, kann Ihnen Ihr Mobilfunkanbieter nicht beliebig viel berechnen.
<G-vec00092-001-s209><call.aufrufen><en> Point.Show End; Compiler links statically call to subroutine point.
<G-vec00092-001-s209><call.aufrufen><de> Point.Show End; Compiler Links aufrufen zu statisch Punkt Subroutine.
<G-vec00092-001-s210><call.aufrufen><en> MyMail is not really what you would call a MailChimp plugin.
<G-vec00092-001-s210><call.aufrufen><de> MyMail ist nicht wirklich das, was man ein MailChimp Plugin aufrufen.
<G-vec00092-001-s211><call.aufrufen><en> Note that the trigger is invoked at the moment you call SAVE RECORD, not when it is created.
<G-vec00092-001-s211><call.aufrufen><de> Beachten Sie, dass der Trigger beim Aufrufen von SAVE RECORD und nicht beim Erstellen aktiv wird.
<G-vec00092-001-s212><call.aufrufen><en> This means that you do not need to call reset() before a foreach loop.
<G-vec00092-001-s212><call.aufrufen><de> Das bedeutet, dass Sie vor einem Durchlauf von foreach reset() nicht aufrufen müssen.
<G-vec00092-001-s213><call.aufrufen><en> Whenever you call up and use our website, we collect the personal data automatically. Your browser then transmits this to our server.
<G-vec00092-001-s213><call.aufrufen><de> Beim Aufrufen und der Nutzung unserer Website erheben wir die personenbezogenen Daten, die dein Browser automatisch an unseren Server übermittelt.
<G-vec00092-001-s214><call.aufrufen><en> Women who believe that having an elegant and sensuous fragrance is necessary to boost the romantic feel and meaning of any occasion should take relief in the fact that they have the option of using a fragrance that they can truly call their own.
<G-vec00092-001-s214><call.aufrufen><de> Frauen, die glauben, dass mit einen eleganten und sinnlichen Duft notwendig ist, die romantische Atmosphäre Erhöhung und Bedeutung der jede Gelegenheit sollte Relief in der Tatsache, dass sie haben die Möglichkeit, mit einen Duft, den sie wirklich ihre eigenen aufrufen können.
<G-vec00092-001-s215><call.aufrufen><en> As the compression is (relatively) slow, it's possible to call a procedure at regular time to follow the packing progress.
<G-vec00092-001-s215><call.aufrufen><de> Da das Komprimieren sehr langsam abläuft, ist damit das regelmäßige Aufrufen einer Prozedur zum Verfolgen des Pack-Prozesses möglich.
<G-vec00092-001-s216><call.aufrufen><en> True to the motto Together we are strong, the race track aims to call on racing professionals and fans as well as visitors of the Nürburgring and the region to be a role model also on public roads.
<G-vec00092-001-s216><call.aufrufen><de> Nach dem Motto Gemeinsam sind wir stark möchte die Rennstrecke Motorsportler, Fans sowie Besucher des Nürburgrings und der Region dazu aufrufen, auch im öffentlichen Straßenverkehr als gutes Beispiel voran zu gehen.
<G-vec00092-001-s217><call.aufrufen><en> This event was to encourage UK people to show concern for the Chinese people in mainland China who have been suffering under a brutal communist dictatorship, and was also to call on the Chinese people to quit the CCP and its related organisations.
<G-vec00092-001-s217><call.aufrufen><de> Die Veranstaltung sollte die Aufmerksamkeit der britischen Bürger auf die Chinesen im Festland China lenken, die unter der brutalen kommunistischen Diktatur leiden und gleichzeitig die Chinesen aufrufen, aus der KP Chinas und ihren angegliederten Organisationen auszutreten.
<G-vec00092-001-s218><call.aufrufen><en> If you now call library commands using [Step into], the program pointer does not jump into the library but could land in your callback routine if this is just now being called from within the library.
<G-vec00092-001-s218><call.aufrufen><de> Wenn Sie jetzt Library-Befehle mit Eintreten aufrufen, springt der Programmzeiger zwar nicht in die Library, kann aber in Ihrer Callback-Routine landen, wenn diese gerade von der Library aus aufgerufen wird.
<G-vec00092-001-s219><call.aufrufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00092-001-s219><call.aufrufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00092-001-s220><call.aufrufen><en> You can also call up the display when the ignition is switched off by pressing the SET button Link.
<G-vec00092-001-s220><call.aufrufen><de> Bei ausgeschalteter Zündung können Sie die Anzeige auch mit der Taste SET aufrufen Link.
<G-vec00092-001-s221><call.aufrufen><en> int MyFunction (char *); This defines a function of type int which can receive a char * for input, the actual function can now be put anywhere else, it is defined, so the compiler won ́t complain if we call it, and upon calling it the compiler will use the actual function instead of the prototype, no matter where it is located.
<G-vec00092-001-s221><call.aufrufen><de> int MyFunction (char *); Dies definiert eine Funktion vom Typ int, die ein char * empfangen kann, die Funktion selbst kann jetzt sonst wo stehen, sie ist definiert, der Compiler meckert nicht wenn wir sie aufrufen und beim Aufruf wird die echte Funktion verwendet, egal wo sie steht.
<G-vec00092-001-s222><call.aufrufen><en> Tip: For a form template, you can call up an overview – analogous to the internal form builder – in which the data fields are listed per form section (Function | Fields menu item).
<G-vec00092-001-s222><call.aufrufen><de> Tipp: Zu einer Formularvorlage können Sie eine Übersicht - analog zum internen Formulargenerator - aufrufen, in der die Datenfelder je Formularabschnitt aufgelistet sind (Menüpunkt Funktion | Felder).
<G-vec00092-001-s223><call.aufrufen><en> In order to prevent your users from being able to call up similar functions, you should leave this option turned on.
<G-vec00092-001-s223><call.aufrufen><de> Damit Benutzer auf Ihrem Terminal nicht ähnliche Funktionen aufrufen können, sollten Sie die Option eingeschaltet lassen.
<G-vec00092-001-s224><call.aufrufen><en> In addition to the internal mapping of logical interfaces via 'id_str', wpa_action can call external mapping scripts.
<G-vec00092-001-s224><call.aufrufen><de> Zusätzlich zum internen Mapping von logischen Schnittstellen mittels 'id_str', kann wpa_action externe Mapping-Scripts aufrufen.
<G-vec00092-001-s225><call.aufrufen><en> Should you call up this website or download contents, please note that it is your own responsibility to ensure that you act in compliance with local legislation applicable in that place.
<G-vec00092-001-s225><call.aufrufen><de> Sollten Sie diese Website aufrufen und/oder Inhalte herunterladen, so sind Sie selbst dafür verantwortlich, dass dies mit den in Ihrem Aufenthaltsort geltenden lokalen Gesetzen vereinbar ist.
<G-vec00092-001-s226><call.aufrufen><en> However, sometimes you only need little motivators; maybe a cute saying on a poster, to make you feel like you have to power to call your own shots.
<G-vec00092-001-s226><call.aufrufen><de> Aber brauchen manchmal Sie nur wenig Motivatoren; vielleicht ein hübsch sagen auf einem Plakat zu machen, Sie fühlen, wie Sie an die macht Ihre eigenen Aufnahmen aufrufen.
<G-vec00092-001-s227><call.aufrufen><en> You can call REST services by using any REST client.
<G-vec00092-001-s227><call.aufrufen><de> Sie können REST-Dienste über einen beliebigen REST-Client aufrufen.
<G-vec00092-001-s247><call.aufrufen><en> There are several ways to call up the Color dialog once the part has been selected:
<G-vec00092-001-s247><call.aufrufen><de> Es gibt verschiedene Wege, den Farb-Dialog aufzurufen, nachdem das zu färbende Bauteil ausgewählt wurde.
<G-vec00092-001-s248><call.aufrufen><en> The resolution urged the central government to call for the United Nations, international human right organisations and world health organisations to send delegates to China to investigate and publish reports to safeguard basic human rights, and to demand the CCP to immediately stop the brutality.
<G-vec00092-001-s248><call.aufrufen><de> Die Resolution fordert die Zentralregierung dringlich auf, die Vereinten Nationen, die internationalen Menschenrechtsorganisationen und die Weltgesundheitsorganisationen dazu aufzurufen, Delegationen nach China zu schicken, Untersuchungen anzustellen und die Ergebnisse zu veröffentlichen, damit die grundlegenden Menschenrechte gewahrt bleiben und die KPC dazu aufgefordert wird, diese Brutalität sofort zu beenden.
<G-vec00092-001-s249><call.aufrufen><en> To “burn out” fleas with high temperatures, it is rational to call up special teams: they will cope with the task quickly and with guaranteed results (they use powerful heat guns).
<G-vec00092-001-s249><call.aufrufen><de> Um Flöhe mit hohen Temperaturen auszubrennen, ist es sinnvoll, Spezialteams aufzurufen: Sie werden die Aufgabe schnell und mit garantierten Ergebnissen erledigen (sie verwenden leistungsstarke Heißluftgebläse).
<G-vec00092-001-s250><call.aufrufen><en> It is not enough to call for the fall of this government.
<G-vec00092-001-s250><call.aufrufen><de> Es reicht nicht, nur zum Sturz dieser Regierung aufzurufen.
<G-vec00092-001-s251><call.aufrufen><en> Mobile apps can call these procedures by issuing AJAX requests.
<G-vec00092-001-s251><call.aufrufen><de> Mobile Apps können Ajax-Anforderungen absetzen, um Prozeduren aufzurufen.
<G-vec00092-001-s252><call.aufrufen><en> I know each of you by name and I come from Heaven to call you to conversion.
<G-vec00092-001-s252><call.aufrufen><de> Ich kenne jeden von euch beim Namen und kam vom Himmel um euch zur Bekehrung aufzurufen.
<G-vec00092-001-s253><call.aufrufen><en> The pan value is saved for the #Sound, so it's not needed to call it every time.
<G-vec00092-001-s253><call.aufrufen><de> Der 'Balance'-Wert wird für den #Sound gespeichert - deshalb ist es nicht nötig, diesen jedes Mal aufzurufen.
<G-vec00092-001-s254><call.aufrufen><en> Unlike the CWI, Workers Power rightly notes that “the HDP is not a working class party but a petty bourgeois organisation”—only to call for a vote for them anyway.
<G-vec00092-001-s254><call.aufrufen><de> Im Unterschied zum CWI stellt Workers Power zutreffend fest, dass „die HDP keine Partei der Arbeiterklasse, sondern eine kleinbürgerliche Organisation ist“ – um dann trotzdem zur Stimmabgabe für sie aufzurufen.
<G-vec00092-001-s255><call.aufrufen><en> It is important to call up and just say hi to your fellow franchisees because it will remind them that you are always near by.
<G-vec00092-001-s255><call.aufrufen><de> Aufzurufen ist wichtig, und gerechtes Sagen hallo zu Ihren Mitfranchisenehmern, weil sie sie erinnert, daß Sie immer nahe vorbei sind.
<G-vec00092-001-s256><call.aufrufen><en> Round the corner in Parliament Square, Falun Gong practitioners held a peaceful demonstration to call for an end to the persecution, which has sadly been going on for 10 years.
<G-vec00092-001-s256><call.aufrufen><de> Gleich um die Ecke auf dem Parlamentsplatz hielten Falun Gong-Praktizierende eine friedliche Demonstration ab, um zu einer Beendigung der Verfolgung aufzurufen, die bedauerlicherweise seit 10 Jahren andauert.
<G-vec00092-001-s257><call.aufrufen><en> God sent to every nation a prophet, mostly from amongst them, to call them to worship God alone and to shun false gods.
<G-vec00092-001-s257><call.aufrufen><de> Gott hat zu jedem Volk einen Propheten gesandt, meistens einen der ihren, um sie dazu aufzurufen, Gott allein zu dienen und falsche Götter zu meiden.
<G-vec00092-001-s258><call.aufrufen><en> The event was organised as part of a global action to raise awareness of the ongoing human rights crisis of forced disappearances in Mexico, and to call on the Mexican Government to end it.
<G-vec00092-001-s258><call.aufrufen><de> Die Veranstaltung war organisiert als Teil einer weltweiten Aktion, um Aufmerksamkeit auf die fortwährende Menschenrechtskrise des gewaltsamen Verschwindenlassens in Mexiko zu richten und die mexikanische Regierung aufzurufen, diese Krise zu beenden.
<G-vec00092-001-s259><call.aufrufen><en> Dear children, I came from Heaven to call you to a noble mission: announce Jesus to all those who do not yet know Him.
<G-vec00092-001-s259><call.aufrufen><de> Geliebte Kinder, Ich kam vom Himmel um euch zu einer edlen Mission aufzurufen: Jesus allen zu verkuendigen welche Ihn noch nicht kennen.
<G-vec00092-001-s260><call.aufrufen><en> Dear children, I am your Mother and I love you. I came from Heaven to call you to holiness.
<G-vec00092-001-s260><call.aufrufen><de> Geliebte Kinder, Ich bin eure Mutter und liebe euch, Komme vom Himmel um euch zur Heiligkeit aufzurufen.
<G-vec00092-001-s261><call.aufrufen><en> I come to you this night to call you to make reparation on the Feast of the Holy Innocents and to step inside the Holy Family on the Feast of the Holy Family. When you belong to a family there are family obligations.
<G-vec00092-001-s261><call.aufrufen><de> Ich bin heute nacht zu euch gekommen um euch aufzurufen um Wiedergutmachung am Fest der Heiligen Unschuldigen Kinder zu machen und in die Heilige Familie einzutreten - am Festtag der Heiligen Familie.
<G-vec00092-001-s262><call.aufrufen><en> After practitioners explained to her that these tortures are occurring right now in China against Falun Gong practitioners and our activity here today was to call for the end of persecution against innocent people, the old lady understood the truth and signed our petition to “Support Falun Gong Practitioners in China, Denounce the Persecution Against Falun Gong”.
<G-vec00092-001-s262><call.aufrufen><de> "Nachdem die Praktizierenden ihr erklärt hatten, daß solche Folterungen gerade jetzt in China gegen Falun Gong Praktizierender geschehen, und unsere Aktivität dem Zweck diente, zu einem Ende der Verfolgung gegen unschuldige Menschen aufzurufen, verstand die alte Frau und unterschrieb unsere Petition zur ""Unterstützen Sie Falun Gong Praktizierender in China, verurteilen Sie die Verfolgung gegen Falun Gong""."
<G-vec00092-001-s263><call.aufrufen><en> To call this plugin: in Adobe Photoshop select the menu item File -> Automate -> AKVIS Magnifier;
<G-vec00092-001-s263><call.aufrufen><de> Um die Plugin-Version aufzurufen, wählen Sie den Befehl Datei -> Automatisieren -> AKVIS Magnifier in Photoshop.
<G-vec00092-001-s264><call.aufrufen><en> But the trade union bureaucracy continues to act as a brake, as we can see from their slowness to call a general strike.
<G-vec00092-001-s264><call.aufrufen><de> Aber die Gewerkschaftsbürokratie wirkt weiterhin als Bremser, deutlich sichtbar an ihrem Zögern, zum Generalstreik aufzurufen.
<G-vec00092-001-s265><call.aufrufen><en> Since the beginning of 2013, emergency rescue personnel can now use an online license plate look-up service to quickly call up the pertinent rescue data sheet for a vehicle that has been involved in an accident and to thus take into account the specific vehicle-related information in their rescue work.
<G-vec00092-001-s265><call.aufrufen><de> Dabei wird den Rettungskräften über eine seit Anfang 2013 verfügbare Online-Kennzeichenabfrage die Möglichkeit geboten, sehr schnell das jeweils zutreffende Rettungsdatenblatt eines verunfallten Fahrzeuges online aufzurufen und die speziellen fahrzeugbezogenen Angaben bei der Rettungsarbeit zu berücksichtigen.
<G-vec00092-001-s304><call.bezeichnen><en> The Catholic church and other bigots continue to call abortion “murder.” In the U.S., doctors who carry out abortions have been murdered.
<G-vec00092-001-s304><call.bezeichnen><de> Die katholische Kirche und andere Eiferer bezeichnen Abtreibung immer noch als „Mord“, in den USA wurden Ärzte ermordet, die Abtreibungen durchführten.
<G-vec00092-001-s305><call.bezeichnen><en> Almost half, 48 percent, said they would call themselves a democratic socialist or socialist, compared to 39 percent who said they identified as neither.
<G-vec00092-001-s305><call.bezeichnen><de> Fast die Hälfte, 48 Prozent, sagten, dass sie sich als demokratische(r) Sozialist(in) oder Sozialist(in) bezeichnen würden, verglichen mit 39 Prozent, die sagten, dass sie sich als beides betrachteten.
<G-vec00092-001-s306><call.bezeichnen><en> Over the past decade and a half, you have been subjected to a number of subtle changes that we generally call Ascension Symptoms.
<G-vec00092-001-s306><call.bezeichnen><de> Während der vergangenen anderthalb Jahrzehnte wart ihr einer Reihe subtiler Veränderungen unterworfen, die wir generell als Aufstiegs-Symptome bezeichnen.
<G-vec00092-001-s307><call.bezeichnen><en> "Attorney McMahon said, ""In our lawsuit we have alleged there are various agents, spies-- whatever you want to call them--who are attached to the embassies and consulates here in America."
<G-vec00092-001-s307><call.bezeichnen><de> "Anwalt McMahon sagte: ""In unserer Anklage behaupten wir, dass es verschiedene Agenten, Spione oder wie man diese Personen auch immer bezeichnen will, gibt, die zu den Botschaften und Konsulaten hier in Amerika in Beziehung stehen."
<G-vec00092-001-s308><call.bezeichnen><en> Because this Power is becoming more and more obvious – this Truth-Power – and naturally human thought, which is childish (it has the same attitude towards supramental thought as what we may call animal thought or sentiment has towards human thought or sentiment), has almost a need for superstition (“superstition” is an ugly word for something that's not ugly: it's an ignorant, ingenuous and very trusting faith), and, well, as soon as you feel the influence of a Power, that faith makes you believe in the miracle, it makes you believe that the Supramental is going to manifest now, that you are going to become supramental, and that...
<G-vec00092-001-s308><call.bezeichnen><de> Denn diese Kraft wird immer offensichtlicher – diese Kraft der Wahrheit –, und natürlich bedarf das menschliche Denken, das von kindlicher Beschaffenheit ist (es hat zum supramentalen Denken die gleiche Beziehung wie es das, was man als animalisches Denken oder Empfinden bezeichnen kann, dem menschlichen Empfinden und Denken gegenüber hegt), beinahe eines Aberglaubens (Aberglaube ist ein häßliches Wort für etwas, das nicht eigentlich häßlich, sondern ein unwissender, naiver und sehr vertrauensvoller Glaube ist), und genau dieser Glaube läßt einen dann an Wunder glauben, sobald man den Einfluß einer Kraft fühlt – er läßt einen denken, daß das Supramental sich bald manifestiert und man supramental wird und...
<G-vec00092-001-s309><call.bezeichnen><en> We call the resulting earnings after cost of capital the business value contribution, or BVC .
<G-vec00092-001-s309><call.bezeichnen><de> Das Ergebnis nach Kapitalkosten bezeichnen wir als Business Value Contribution, kurz BVC.
<G-vec00092-001-s310><call.bezeichnen><en> "The Shia call the male descendants of the Prophet Muhammad ""Imams"" and ascribe to them a quasi-divine status."
<G-vec00092-001-s310><call.bezeichnen><de> Die Schiiten bezeichnen alle Nachkommen des Propheten Muhammad als Imame und schreiben ihnen einen quasi-göttlichen Status zu.
<G-vec00092-001-s311><call.bezeichnen><en> "We don't have to have a name for it; a worm doesn't have a name for water, but it knows that that's water – what we would call water with the word ""water."""
<G-vec00092-001-s311><call.bezeichnen><de> "Wir haben vielleicht keinen Namen dafür; ein Wurm hat keinen Namen für Wasser, aber er weiß, was das ist – etwas, das wir mit dem Wort ""Wasser"" bezeichnen würden."
<G-vec00092-001-s312><call.bezeichnen><en> What they call them is a tactical question, but in the end they will agree to only run a single candidate.
<G-vec00092-001-s312><call.bezeichnen><de> Das ist schon eine taktische Frage, wie sie sie bezeichnen werden, aber am Ende wird es nur einen geben.
<G-vec00092-001-s313><call.bezeichnen><en> It is believed that you can not call their children the names of deceased relatives.
<G-vec00092-001-s313><call.bezeichnen><de> Es wird angenommen, dass Sie ihre Kinder nicht als verstorbene Verwandte bezeichnen können.
<G-vec00092-001-s314><call.bezeichnen><en> When we reach Mayfield Bore we get a bit of a laugh about our efforts before.... there are so many trees here one must almost call it a forest.
<G-vec00092-001-s314><call.bezeichnen><de> Beim erreichen von Mayfield Bore müssen wir ab der Mühe lachen, die wir hatten um vorher genügend Brennholz zu sammeln.... es hat hier so viele Bäume, dass man es beinahe schon als Wald bezeichnen muss.
<G-vec00092-001-s315><call.bezeichnen><en> "Strangely, as soon as there's the slightest slackening in the attitude, for instance, a second of forgetfulness (what I might call ""forgetfulness,"" that is, the former old habit, the old terrestrial habit of being), the body instantly feels about to be dissolved."
<G-vec00092-001-s315><call.bezeichnen><de> Seltsam, beim geringsten Nachlassen in der Haltung, zum Beispiel in einer Sekunde der Vergessenheit (was man als Vergessenheit bezeichnen könnte, d.h. die alte Haltung von früher, die alte irdische Seinsgewohnheit), spürt der Körper sofort, daß er sich auflösen wird.
<G-vec00092-001-s316><call.bezeichnen><en> """They are only interested in healthy individuals because they don't cost anything."" If this was actually the case, we would have to call ourselves a ""healthy person insurer""."
<G-vec00092-001-s316><call.bezeichnen><de> «Die interessieren sich doch nur für die Gesunden, weil die nichts kosten.» Wäre dem tatsächlich so, müssten wir uns als «Gesundenkasse» bezeichnen.
<G-vec00092-001-s317><call.bezeichnen><en> Here we present the program for the first three-day certification seminar. Following successful examination, participants have the right to call themselves HICHERT Certified Consultants (HCC).
<G-vec00092-001-s317><call.bezeichnen><de> Hier wird das Programm für das dreitägige Zertifizierungsseminar vorgestellt, deren Teilnehmerinnen und Teilnehmer sich nach der erfolgreichen Prüfungsteilnahme als HICHERT® IBCS Certified Consultant (HCC) bezeichnen können.
<G-vec00092-001-s318><call.bezeichnen><en> At this time, when I had considered these ideas and made my plans, I had already written and published various things, but I would not have dared to call myself an novelist or even an artist yet.
<G-vec00092-001-s318><call.bezeichnen><de> Als ich damals diese Gedanken erwog und meine Pläne faßte, hatte ich zwar schon Verschiedenes geschrieben und an die Oeffentlichkeit gegeben, aber es war mir noch nicht eingefallen, mich als Schriftsteller oder gar als Künstler zu bezeichnen.
<G-vec00092-001-s319><call.bezeichnen><en> Products like the Solaris are in what we call the boutique synthesizer market, and so are for a more specialized customer.
<G-vec00092-001-s319><call.bezeichnen><de> Produkte wie der Solaris befinden sich in einem Markt, den wir als Synthesizer-Nischenmarkt bezeichnen, sie sind somit für einen fachkundigeren Musiker gedacht.
<G-vec00092-001-s320><call.bezeichnen><en> "This is what we call the ""psychic being."""
<G-vec00092-001-s320><call.bezeichnen><de> "Das bezeichnen wir dann als das ""psychische Wesen""."
<G-vec00092-001-s321><call.bezeichnen><en> That discovery I made at the age of about fifteen or sixteen, or seventeen. I began to see clearly all the “gifts” (if we can call them that) that came from father, mother, parents, grandparents, education, people who looked after me, that whole mudhole, as it were, into which you fall headfirst.
<G-vec00092-001-s321><call.bezeichnen><de> "Diese Entdeckung machte ich mit fünfzehn oder vielleicht siebzehn; ich begann, diese ""Gaben"" klar zu sehen (wenn man das als Gaben bezeichnen kann), die mir vom Vater, der Mutter, den Großeltern, der Erziehung, den Leuten, die sich um mich kümmerten, übermittelt wurden – kurz, dieses ganze Morastloch, in dem man Hals über Kopf landet."
<G-vec00092-001-s322><call.bezeichnen><en> Now, when you are in that state, the cancer is triggered by those proteins, which they call as 52 and 58.
<G-vec00092-001-s322><call.bezeichnen><de> Wenn ihr euch in einem solchen Zustand befindet, dann wird der Krebs durch diese Proteine ausgelöst, die sie als 52 und 58 bezeichnen.
<G-vec00092-001-s437><call.nennen><en> Because Croatia, the country of a thousand islands – as they like to call it, is a blend of a thousand year-old historical and cultural heritage, unreal natural beauty, top quality gastronomy, different lifestyles, dialects and mentalities.
<G-vec00092-001-s437><call.nennen><de> Weil Kroatien, das Land der tausend Inseln – wie es liebevoll genannt wird, eine Verbindung des tausendjährigen historischen und kulturellen Erbes, der unglaublichen natürlichen Schönheit, einer ausgezeichneten Küche und unterschiedlicher Lebensstile, Dialekte und Mentalitäten darstellt.
<G-vec00092-001-s438><call.nennen><en> History buffs will want to visit ancient Kalidon, ancient Pleuron, the castle of Kyra Rhini, as the locals call it, and the Windmill, a revolutionary monument.
<G-vec00092-001-s438><call.nennen><de> Historisch interessierte Feriengäste werden das antike Kalydon, das antike Pleuron, das Kastell von Kyra Rhini, wie es von den Einheimischen genannt wird, und die Windmühle, ein Revolutions-Denkmal, besuchen wollen.
<G-vec00092-001-s439><call.nennen><en> "This is why we call it ""the large marine aerosol""."
<G-vec00092-001-s439><call.nennen><de> "Darum wird das Meer auch ""das große marine Aerosol"" genannt."
<G-vec00092-001-s440><call.nennen><en> They call software development “industry” and then try to argue that this means it should be subject to patent monopolies.
<G-vec00092-001-s440><call.nennen><de> Softwareentwicklung wird „Industrie“ genannt und dann versucht zu argumentieren, dies würde bedeuten, dass es dadurch Patentmonopolen unterworfen sein sollte.
<G-vec00092-001-s441><call.nennen><en> Children's areas Huldreheimen, or the 'heart' of Sirdal Ski Centre as we like to call it, is one of our two popular children's areas.
<G-vec00092-001-s441><call.nennen><de> Kinderbereiche Hulderheimen, oder auch das «Herz» des Sirdal Skisenter, wie es genannt wird, ist eines der zwei Kinderbereiche.
<G-vec00092-001-s442><call.nennen><en> The ruin the Voss call the Dark Heart lies deep in the twisted Nightmare Lands.
<G-vec00092-001-s442><call.nennen><de> Die Ruine, die von den Voss das Dunkle Herz genannt wird, liegt tief in den seltsamen Albtraumlanden.
<G-vec00092-001-s443><call.nennen><en> Today we call the belief in purgatory ancient superstition, but the truth is that humankind, in this century more than ever before, has had to flee from its effects.
<G-vec00092-001-s443><call.nennen><de> Der Glaube an das Fegefeuer wird heute alter Aberglauben genannt, und doch ist die Wahrheit die, daß die Menschheit in diesem Jahrhundert mehr denn je vor seinen Wirkungen fliehen musste.
<G-vec00092-001-s444><call.nennen><en> "Just opposite, there is Trouville-sur-Mer, a corner of the Côte Fleurie that some call the ""Queen of Beaches"", particularly renowned for its fishing harbour."
<G-vec00092-001-s444><call.nennen><de> "Gegenüber liegt Trouville-sur-Mer, ein Ort an der Blühenden Küste (Côte Fleurie), von einigen auch genannt die ""Königin der Strände""."
<G-vec00092-001-s445><call.nennen><en> They call it Hot Spot. This reduce to visible area reduces the memory size dramatically. So it is a good idea to use it.
<G-vec00092-001-s445><call.nennen><de> Und es erhält dabei die ursprünglichen Koordinaten des Nullunktes, in MMF Hot Spot genannt, sodass der Sprite immer an der gleichen Stelle gezeichnet wird.
<G-vec00092-001-s446><call.nennen><en> "since 1991: The city of Safwan near Kuwait - the ""motorway of death"" and uranium dust: children die of malformations, cancer, leukemia, heart disease - and there are stillbirths Woman speaker: The city of Safwan on the border with Kuwait: Soldiers call this road between Basra and Safwan also as the ""motorway of death "" (26'20'')."
<G-vec00092-001-s446><call.nennen><de> "ab 1991: Die Stadt Safwan nahe Kuwait - die""Autobahn des Todes"" und der Uranstaub: Kinder sterben an Fehlbildungen, Krebs, Leukämie, Herzerkrankungen - und Totgeburten Sprecherin: Die Stadt Safwan an der Grenze zu Kuwait: Die Straße zwischen Basra und Safwan wird von Soldaten auch ""Autobahn des Todes "" genannt (26'20'')."
<G-vec00092-001-s447><call.nennen><en> On Wednesday evening Bruce Springsteen performed in the Olympiastadion Berlin and showed once again with how much passion and stage presence he, the Boss, as his fans like to call him, has been standing on the stages of this world for almost 40 years now.
<G-vec00092-001-s447><call.nennen><de> Bruce Springsteen spielte am Mittwoch Abend im Olympiastadion Berlin und zeigte wieder einmal, mit wieviel Leidenschaft und Bühnenpräsenz der Boss, wie er von seinen Fans genannt wird, seit beinahe 40 Jahren auf den Bühnen dieser Welt steht.
<G-vec00092-001-s448><call.nennen><en> [15] It was on the outskirts of the city, on a slope directly above the harbor access road, which the people living there call “the mountain.”
<G-vec00092-001-s448><call.nennen><de> [15] Sie war am Rande der Stadt, am Abhang direkt über der Zugangsstraße zum Hafen gelegen und wurde von den Bewohnern „the mountain“ genannt.
<G-vec00092-001-s449><call.nennen><en> "Exactly sixty years ago, in 1953, Sherpa Tenzing Norgay and Edmund Hillary were the first to reach the summit of the ""Holy Mother"", as the Tibetans call the eight-thousander."
<G-vec00092-001-s449><call.nennen><de> "Genau vor sechzig Jahren, im Jahr 1953, waren Sherpa Tenzing Norgay und Edmund Hillary die ersten, die den Gipfel der ""Heiligen Mutter"", wie der Achttausender von den Tibetern genannt wird, erreichten."
<G-vec00092-001-s450><call.nennen><en> "Chinese natives believe that ""the monk's fruit"" as they call it, plays a big part in their renowned longevity ."
<G-vec00092-001-s450><call.nennen><de> "Chinesen glauben, dass Sie Ihr hohes Alter diesem ""Mönchsobst"", wie es in China genannt wird, zu verdanken haben."
<G-vec00092-001-s451><call.nennen><en> "While the disciple confronts the obstacles her mind and psyche place in the path, the sheikh does the real work of transformation, softening the heart and preparing the disciple for the awakening of the consciousness of the heart, the divine consciousness that is present in the innermost chamber of the heart, what the Sufis call the ""heart of hearts."""
<G-vec00092-001-s451><call.nennen><de> "Während die Schülerin sich mit den Hindernissen auseinandersetzt, die ihr der Verstand und ihre Psyche in den Weg stellen, leistet der sheikh die wirkliche Arbeit der Transformation, indem er das Herz weich macht und die Schülerin auf das Erwachen des Bewusstseins des Herzens vorbereitet, des göttlichen Bewusstseins, das in der innersten Kammer des Herzens, die von den Sufis ""das Herz der Herzen"" genannt wird, gegenwärtig ist."
<G-vec00092-001-s452><call.nennen><en> "Of course, very conveniently, the band also invented its own genre – ""symphonic extreme metal art"" and when you call something art, it ́s immediately beyond the critique..."
<G-vec00092-001-s452><call.nennen><de> "Klarer- und bequemerweise hat diese Band auch gleich ihr eigenes Genre erfunden – ""symphonic extreme metal art"", und wenn etwas Kunst genannt wird, dann entzieht es sich automatisch jeglicher Kritik..."
<G-vec00092-001-s453><call.nennen><en> Built-in louver insulating glass, also call built in shutter glass, insulated glass blinds, double glass with blinds, is a traditional sunshade product in which the louver is installed in the hollow glass cavity.
<G-vec00092-001-s453><call.nennen><de> Eingebaute Jalousie Isolierglas, auch in Shutterglas, Isolierglas Jalousien, Doppelglas mit Jalousien genannt, ist ein traditionelles Sonnenschutzprodukt, bei dem die Jalousie led in den Hohlglashohlraum eingebaut ist.
<G-vec00092-001-s454><call.nennen><en> "Traditionally, the extra card was placed face down on the table (people still often call it ""doubling down""), and it would only be revealed at the end of the round."
<G-vec00092-001-s454><call.nennen><de> "Traditionsgemäß wurde die zusätzliche Karte verdeckt auf den Spieltisch gelegt (was nach wie vor ""doubling down"" genannt wird) und erst am Ende der Runde aufgedeckt."
<G-vec00092-001-s455><call.nennen><en> "The next day started with a beautiful sunrise in the desert and was followed by a lot of oil fields with ""donkey pumps"", as the locals call the oil pumps."
<G-vec00092-001-s455><call.nennen><de> "Der nächste Tag begann mit einem wunderschönen Sonnenaufgang in der Wüste, gefolgt von vielen Ölfeldern mit ""Eselspumpen"", wie die Ölpumpen dort genannt wurden."
<G-vec00092-001-s494><call.nennen><en> I also habitually call it creative packaging.
<G-vec00092-001-s494><call.nennen><de> Ich nenne es auch gewöhnlich kreative Verpackungen.
<G-vec00092-001-s495><call.nennen><en> It felt as if I remained by the place I call the gate for a short moment, taking it all in and processing it.
<G-vec00092-001-s495><call.nennen><de> Es fühlte sich an als wäre ich eine kurze Weile an diesem Ort, den ich das Tor nenne, geblieben um alles aufzunehmen und zu begreifen.
<G-vec00092-001-s496><call.nennen><en> I call them packages because they're more than just new modes.
<G-vec00092-001-s496><call.nennen><de> Ich nenne sie Pakete, weil sie mehr als nur neue Modi sind.
<G-vec00092-001-s497><call.nennen><en> [...] your KTM 1090 ADVENTURE R for offroad and call it adventure biking.
<G-vec00092-001-s497><call.nennen><de> [...] deine KTM 1090 ADVENTURE R fürs Offroad-Fahren vor und nenne das Ganze eine Abenteuer-Tour.
<G-vec00092-001-s498><call.nennen><en> "Let's take a look at my first image – a fun image I call ""Swing Shift."""
<G-vec00092-001-s498><call.nennen><de> "Sehen Sie sich mein erstes Foto an – ein lustiges Foto, dass ich ""Swing Shift"" nenne."
<G-vec00092-001-s499><call.nennen><en> """One is often forced in public to duplicate oneself – as I always call it."
<G-vec00092-001-s499><call.nennen><de> """In der Öffentlichkeit ist man gezwungen, oft sich selbst zu kopieren – wie ich das immer nenne."
<G-vec00092-001-s500><call.nennen><en> Now that's what I call a hottie.
<G-vec00092-001-s500><call.nennen><de> Nun da ist, was ich ein hottie nenne.
<G-vec00092-001-s501><call.nennen><en> """, ""Call the greatest success of your career"" and so on."
<G-vec00092-001-s501><call.nennen><de> """, ""Nenne den größten Erfolg deiner Karriere"" und so weiter."
<G-vec00092-001-s502><call.nennen><en> / “The Loxone home automation system was easy to combine with the Fronius inverter - that‘s what I call Plug & Play!” says Brandstötter.
<G-vec00092-001-s502><call.nennen><de> / „Die Loxone Hausautomatisierung ließ sich unkompliziert mit dem Fronius Wechselrichter verbinden - das nenne ich Plug & Play.“ sagt Brandstötter.
<G-vec00092-001-s503><call.nennen><en> "I like to call them ""postcard landmarks"" because photos of these tributes and buildings are most likely to end up on postcards or in calendars."
<G-vec00092-001-s503><call.nennen><de> "Ich nenne sie ""Postkarten Merkmale"" weil Fotos von diesen Gedenkstätten und Gebäuden oft auf Postkarten und Kalendern zu finden sind."
<G-vec00092-001-s504><call.nennen><en> I call that paradigm shift.
<G-vec00092-001-s504><call.nennen><de> Ich nenne das Paradigmenwechsel.
<G-vec00092-001-s505><call.nennen><en> I call it the rise of the freelance generalist.
<G-vec00092-001-s505><call.nennen><de> Ich nenne das den Aufstieg der Allround-Freiberufler.
<G-vec00092-001-s506><call.nennen><en> I therefore call it the constant part of capital, or, more shortly, constant capital.
<G-vec00092-001-s506><call.nennen><de> Ich nenne ihn daher konstanten Kapitalteil, oder kürzer: konstantes Kapital.
<G-vec00092-001-s507><call.nennen><en> I call it a brand name since in the Middle East there have existed (and still do) two famous American universities – one in Cairo and another in Beirut.
<G-vec00092-001-s507><call.nennen><de> Ich nenne das so, weil es im Nahen/Mittleren Osten zwei berühmte amerikanische Universitäten gab (und noch gibt), eine in Kairo, die andere in Beirut.
<G-vec00092-001-s508><call.nennen><en> Stand in the magnificence of My light, but do not call it your own.
<G-vec00092-001-s508><call.nennen><de> Stehe in der Herrlichkeit Meines Lichts, doch nenne es nicht dein eigenes.
<G-vec00092-001-s509><call.nennen><en> "An intellectual infinity, but in time not so long away, consists in what I call the ""shame of democracy"", the democratic handing over of power to the National Socialists in Germany in 1933."
<G-vec00092-001-s509><call.nennen><de> Eine intellektuelle Unendlichkeit, zeitlich aber gar nicht so weite Strecke ist es bis zu dem, was ich die »Schmach der Demokratie« nenne, die dämonkratische Machtübergabe an die Nationalsozialisten in Deutschland 1933.
<G-vec00092-001-s510><call.nennen><en> "But to be able to say that a point is black or white, I must first know under what conditions a point is called white or black; in order to be able to say ""p"" is true (or false) I must have determined under what conditions I call ""p"" true, and thereby I determine the sense of the proposition."
<G-vec00092-001-s510><call.nennen><de> "Um aber sagen zu können, ein Punkt sei schwarz oder weiß, muss ich vorerst wissen, wann man einen Punkt schwarz und wann man ihn weiß nennt; um sagen zu können, ""p"" ist wahr (oder falsch), muss ich bestimmt haben, unter welchen Umständen ich ""p"" wahr nenne, und damit bestimme ich den Sinn des Satzes."
<G-vec00092-001-s511><call.nennen><en> In each thought you will implant dynamism (electricity); after that broadness; then density (weight), and lastly power of movement, or as I call it, growth.
<G-vec00092-001-s511><call.nennen><de> Ihr werdet in jeden Gedanken Dynamik (Elektrizität) hineinführen, danach werdet ihr diesem Gedanken Breite geben, dann Dichte (Gewicht) und endlich – Bewegungskraft, oder wie ich sie nenne: Wachsen.
<G-vec00092-001-s512><call.nennen><en> "For want of a better name I call them the ""Emmy-Emma"" group (a nickname for them given by my son, Rick)."
<G-vec00092-001-s512><call.nennen><de> "Aus Mangel an einem besseren Namen ich nenne sie die ""Emmy-Emma""-Gruppe (ein Spitzname für sie da von meinem Sohn, Rick)."
<G-vec00092-001-s513><call.nennen><en> "On the other hand, by combining the values celebrated by the maker culture – an openness towards knowledge, collaborative working, need-based, resource-efficient and decentralised production – with the designer's ability to create things that benefit others and not just themselves, while ideally involving the user as an equal participant, we can create a model you might call ""do-it-together""."
<G-vec00092-001-s513><call.nennen><de> "Wenn allerdings die von der Maker-Kultur propagierten Werte wie offener Umgang mit Wissen, gemeinschaftliches Handeln und bedürfnisgerechte, ressourcenschonende und dezentrale Produktion mit der Fähigkeit des Designers gekoppelt werden, nicht nur für sich selbst, sondern für andere zu gestalten – im Idealfall unter gleichberechtigter Teilhabe des Nutzers – entstünde ein Zusammenhang, der sich dann ""Do-it-together"" nennen könnte."
<G-vec00092-001-s514><call.nennen><en> Not in such a way that we call error truth, but in such a way that we accept them as they are, as human beings, and meet their needs.
<G-vec00092-001-s514><call.nennen><de> Nicht in einer Weise, dass wir Falsches wahr nennen, sondern sie als Menschen annehmen wie sie sind und ihren Bedürfnissen begegnen.
<G-vec00092-001-s515><call.nennen><en> "This cultural dimension is what the economist may call ""real capital"" (in contrast to financial capital)."
<G-vec00092-001-s515><call.nennen><de> "Diese kulturelle Dimension ist das, was der Wirtschaftswissenschaftler ""Realkapital"" nennen könnte (im Gegensatz zu Finanzkapital)."
<G-vec00092-001-s516><call.nennen><en> Reactivity is closely related to what researchers call demand effects (Orne 1962; Zizzo 2010) and the Hawthorne effect (Adair 1984; Levitt and List 2011) .
<G-vec00092-001-s516><call.nennen><de> Die Reaktivität ist eng verwandt mit dem, was (Orne 1962; Zizzo 2010) Nachfrageeffekte nennen (Orne 1962; Zizzo 2010) und den Hawthorne-Effekt (Adair 1984; Levitt and List 2011) .
<G-vec00092-001-s517><call.nennen><en> "Let's call the book Maps of Time ""Christian, version 1.0""."
<G-vec00092-001-s517><call.nennen><de> "Nennen wir die Buch Karten der Zeit ""Christian, Version 1.0""."
<G-vec00092-001-s518><call.nennen><en> The most meaningful, if you could call it that, part of the experience was feeling flooded and caressed so fully in utter love and compassion.
<G-vec00092-001-s518><call.nennen><de> Das Bedeutungsvollste, wenn man es so nennen kann, ist der Teil der Erfahrung wo ich mich so voll überflutet und gestreichelt fühlte mit äußerster Liebe und Mitgefühl.
<G-vec00092-001-s519><call.nennen><en> They call themselves Anufo or the people of Anu.
<G-vec00092-001-s519><call.nennen><de> Sie nennen sich Anufo oder die Leute von Anu.
<G-vec00092-001-s520><call.nennen><en> Incidentally as you move up from one sphere to the other in Yoga Nidra, you are encountering what the Sufis call the 'light that sees' rather than 'the light that can (or could) be seen'.
<G-vec00092-001-s520><call.nennen><de> "Wenn Sie sich im Yoga Nidra von einer Sphäre zur nächsten erheben, finden Sie schließlich das, was die Sufis ""das Licht das man sieht"" nennen - und nicht mehr das Licht, das man sehen kann."
<G-vec00092-001-s521><call.nennen><en> "The below 29 Literary critics and critics call a month – in free choice – four new books, they ""möglichst viele Leser..."
<G-vec00092-001-s521><call.nennen><de> "Die unten aufgeführten 29 Literaturkritikerinnen und -kritiker nennen monatlich – in freier Auswahl – vier Buch-Neuerscheinungen, denen sie ""möglichst viele Leser..."
<G-vec00092-001-s522><call.nennen><en> The makers themselves call it Doom Pop and even though it`s definitely not everyone`s cup of tea, I`m at least strangely fascinated by this quite deranged concoction.
<G-vec00092-001-s522><call.nennen><de> Doom Pop nennen das die Macher selbst und obwohl es definitiv nicht jedermanns Sache sein wird, bin doch zumindest ich auf irgendeine Weise von der doch sehr durchgeknallten Mischung extrem fasziniert.
<G-vec00092-001-s523><call.nennen><en> Call it a way to articulate critique of the flow while embodying the flow.
<G-vec00092-001-s523><call.nennen><de> Man könnte das einen Weg nennen, Kritik am Flow zu äußern und ihn zugleich zu verkörpern.
<G-vec00092-001-s524><call.nennen><en> Whatever you call it, it’s there to assist you all the time.
<G-vec00092-001-s524><call.nennen><de> Was auch immer Sie es nennen, es ist da, um zu helfen, die Sie die ganze Zeit.
<G-vec00092-001-s525><call.nennen><en> "And with this new perception I feel, inexpressibly, a concentration of... the truth of what we call Sri Aurobindo gathering around and on and within this body (there is really neither ""within"" nor ""without"")."
<G-vec00092-001-s525><call.nennen><de> "(Schweigen) Mit dieser neuen Wahrnehmung fühle ich auf unaussprechliche Weise, wie sich eine Konzentration der... der Wahrheit von dem, was wir Sri Aurobindo nennen, um und auf und im Körper sammelt (es gibt kein ""darin"" oder ""außerhalb"")."
<G-vec00092-001-s526><call.nennen><en> As soon as a â smile relationshipâ has been established, as many call it, a visit will be announced.
<G-vec00092-001-s526><call.nennen><de> Sobald das „Lächelverhältnis“, wie es viele nennen, hergestellt ist, wird ein Besuch angekündigt.
<G-vec00092-001-s527><call.nennen><en> We can also call it nibbana or the Unconditioned.
<G-vec00092-001-s527><call.nennen><de> Wir können es auch Nibbana nennen, oder das Unbedingte.
<G-vec00092-001-s528><call.nennen><en> """Jazz du monde"" is what the musicians call their craft, and they indeed knead together all the influences that they have encountered in a multicultural metropolis like Paris."
<G-vec00092-001-s528><call.nennen><de> """Jazz du Monde"" nennen die Musiker ihr Metier und verarbeiten alle Einflüsse, die sie in einer multikulturell geprägten Großstadt wie Paris antreffen."
<G-vec00092-001-s529><call.nennen><en> Those who are at first concerned with being happier until they have optimized happiness will find a way to afford the happy life that they call their dream life.
<G-vec00092-001-s529><call.nennen><de> Die, die sich zuerst damit beschäftigen glücklicher zu sein, bis sie das Glücklichsein optimiert haben, werden einen Weg finden, sich das glückliche Leben leisten zu können, das sie ihr Traumleben nennen.
<G-vec00092-001-s530><call.nennen><en> That is what we Bolsheviks call a real offensive.
<G-vec00092-001-s530><call.nennen><de> Das nennen wir Bolschewiki eine wirkliche Offensive.
<G-vec00092-001-s531><call.nennen><en> We call this energy future 24 hours of sun.
<G-vec00092-001-s531><call.nennen><de> Wir nennen diese Energiezukunft 24 Stunden Sonne.
<G-vec00092-001-s532><call.nennen><en> But for most human beings this experience only emerges through the passage you call death.
<G-vec00092-001-s532><call.nennen><de> Aber die meisten Menschen machen diese Erfahrung nur bei dem Übergang, den ihr Tod nennt.
<G-vec00092-001-s533><call.nennen><en> Some call it as “ruh.” You may call it by any name – is the love, love of God.
<G-vec00092-001-s533><call.nennen><de> Es gibt verschiedene Namen dafür, man nennt sie Paramchaitanya, Chaitanya, manche nennen sie Ruh.
<G-vec00092-001-s534><call.nennen><en> This is what you call a linguistic exchange: the idea is really to exchange your knowledge in English against the knowledge of a Spanish-speaking person in his or her language.
<G-vec00092-001-s534><call.nennen><de> Das nennt man einen sprachlichen Austausch: Die Idee ist wirklich, Ihr Wissen in deutscher Sprache gegen die Sprachkenntnisse einer spanischsprechenden Person auszutauschen.
<G-vec00092-001-s535><call.nennen><en> "Bonus: TransferWise will automatically lock the exchange rate for a specified time frame, from 24 hours for most countries, and 48 hours for several others and 72 hours for BRL (Brazilian Reals) so you're not exposed to exchange rate fluctuations (they call this the ""guaranteed rate"" feature)."
<G-vec00092-001-s535><call.nennen><de> "In vielen Fällen wenn Sie von oder nach GBP (britische Pfund), EUR (Euro) oder USD (US Dollar) Geld senden, setzt TransferWise den Wechselkurs automatisch für einen Zeitraum von 24-48 Stunden fest, so dass Sie keinen Wechselkursschwankungen ausgesetzt sind (man nennt dies die ""fester Wechselkurs""-Funktion"" (""guaranteed rate"" feature)."
<G-vec00092-001-s536><call.nennen><en> Justice as used in your common language today refers to the idea of [protection] of the individual, the even handed treatment of individuals within a given culture or society and an idea that the law will be fairly applied to all those evenly and if your brother infringes upon your rights then (you) have laws to turn to seek what you call justice which is the idea of a larger authority enforcing laws and rules that you have agreed upon.
<G-vec00092-001-s536><call.nennen><de> Gerechtigkeit, wie sie in eurer gewöhnlichen Sprache verwendet wird, bezieht sich auf die Idee des Schutzes des Individuums, die eben gegebene Behandlung von Individuen in einer gegebenen Kultur oder Gesellschaft, und auf eine Idee, dass das Gesetz ziemlich gleichmäßig auf alle jene angewandt wird, und wenn euer Bruder gegen eure Rechte verstößt, dann habt ihr Gesetze es zu wenden, zu suchen, was ihr Gerechtigkeit nennt, was die Idee einer größeren Autorität ist, die Gesetze und Regeln erlässt, mit denen ihr übereingestimmt habt.
<G-vec00092-001-s537><call.nennen><en> There is something interesting in this cellular consciousness: they have a sense of sincerity which is much sharper, and what they call in English exacting, than in the vital and the mind (even the material vital and mind).
<G-vec00092-001-s537><call.nennen><de> Etwas Interessantes zeigt sich im Bewußtsein der Zellen: Sie haben einen Sinn für Aufrichtigkeit, der VIEL exakter ist – was man im Englischen exacting [anspruchsvoll, streng] nennt – als im Vital und im Mental (das trifft sogar für das materielle Vital und Mental zu).
<G-vec00092-001-s538><call.nennen><en> "It was a show that regarded, early on, what we today call ""mediation"" to be an important component of artistic production."
<G-vec00092-001-s538><call.nennen><de> "Das war ja eine Schau, die frühzeitig sehr stark das, was man heute ""Vermittlung"" nennt, als einen wichtigen Bestandteil der künstlerischen Produktion verstanden hat."
<G-vec00092-001-s539><call.nennen><en> You are not dealing with something that you call 'Christianity', or with your own conception of a Christian, which may be all wrong, faulty, or at most inadequate.
<G-vec00092-001-s539><call.nennen><de> Ihr habt es nicht mit etwas zu tun, das sich «Christentum» nennt, oder mit eurer eigenen Vorstellung eines Christen, die völlig falsch, mangelhaft oder zumindest unangemessen sein mag.
<G-vec00092-001-s540><call.nennen><en> "Call me a ""reformist"" if you like, but I don't want such a future any more than the neo-liberal future."
<G-vec00092-001-s540><call.nennen><de> "Nennt mich eine ""Reformistin"", wenn ihr wollt, aber ich möchte solch eine Zukunft ebenso wenig wie die neoliberale Zukunft."
<G-vec00092-001-s541><call.nennen><en> Precisely what you call cleverness, beauty and strength, precisely these are rather obstacles than means to an intimate relationship with Me.
<G-vec00092-001-s541><call.nennen><de> Ja sogar genau das, was ihr Schönheit, Klugheit und Stärke nennt, sind eher die Hindernisse als die Beförderer der innerlichen Beziehung zu Mir.
<G-vec00092-001-s542><call.nennen><en> As you are civilized/conditioned/cultured long before you develop the ability to question and examine these—call them the facts of birth you received when you were born—your emergence as an individual depends upon, in turn, your curiosity and exploration of who and what you feel yourself to be somewhat independent of your given situation.
<G-vec00092-001-s542><call.nennen><de> Wenn ihr zivilisiert/konditioniert/kultiviert seid lange bevor ihr die Fähigkeit entwickelt, sie zu hinterfragen und zu untersuchen – nennt sie die Tatsachen von Geburt, die ihr erhaltet, wenn ihr geboren werdet – euer Auftauchen als Individuum hängt im Gegenzug von eurer Neugier und Erforschung ab, als wer und was ihr euch selbst fühlt, um etwas unabhängig von eurer gegebenen Situation zu sein.
<G-vec00092-001-s543><call.nennen><en> "It is said that Han Yu, a famous literary figure from the Tang dynasty, burst into tears in fear of the frightful path to ""Blue Dragon Ridge"" and wrote for help, creating the landmark we now call ""Han Yu's Cry for Help"" [9]."
<G-vec00092-001-s543><call.nennen><de> Man erzählt, dass Han Yu, ein berühmter Literat der Tang-Dynastie, aus Angst vor dem furchteinflößenden Pfad zum „Blauer Drache-Bergrücken“ in Tränen ausbrach und um Hilfe schrie, wodurch die Landmarke entstand, die sich nun „Han Yus Schrei um Hilfe“ (9) nennt.
<G-vec00092-001-s544><call.nennen><en> “Remember, at one time the distance between the bodies of land on your Earth, which you call continents, was considered great, and much time was required to travel from one to another.
<G-vec00092-001-s544><call.nennen><de> Erinnere Dich, dass einmal die Entfernung auf Eurer Erde zwischen den Erdkörpern, die Ihr Kontinente nennt, als sehr gross galt und man brauchte für die Überquerung viel Zeit.
<G-vec00092-001-s545><call.nennen><en> The Acts of the Apostles call Jesus the leader of the way into life.
<G-vec00092-001-s545><call.nennen><de> Die Apostelgeschichte nennt Jesus den Führer auf dem Weg in das Leben.
<G-vec00092-001-s546><call.nennen><en> "David Sugar, the author of Bayonne, likes to call it the ""Swiss army knife"" of the ""telephony servers,"" because tdM bus support, call ""switching"" and VoIP gateway services are already being worked on."
<G-vec00092-001-s546><call.nennen><de> "David Sugar, der Autor von Bayonne, nennt es gerne das ""Schweizer Taschenmesser"" der ""Telefonie Server"", da auch die Unterstützung des tdM Bus, ""Anrufumschaltung"" und VoIP Gateway-Dienste in Arbeit sind."
<G-vec00092-001-s547><call.nennen><en> Meditation has become a natural, almost daily part of my life- the island of stillness, how you call it, helps me to stay in touch with being myself and find deep rest and new energy.
<G-vec00092-001-s547><call.nennen><de> "Die Meditation ist ein natürlicher, beinahe täglicher Teil meines Lebens geworden - die ""Insel der Stille"", wie Ihr es so treffend nennt, hilft mir, bei mir zu bleiben und Kraft zu tanken."
<G-vec00092-001-s548><call.nennen><en> "He may call Palestinians ""Terrorists"", but he performs surgery on them, ""no matter what they believe""."
<G-vec00092-001-s548><call.nennen><de> Zwar nennt er Palästinenser «Terroristen», aber er operiert sie, «egal, was sie glauben».
<G-vec00092-001-s549><call.nennen><en> Whoever can call a Prinz Hunting Weapon his own expresses with it not only his individuality, but also, in particular, his will to give the hunter’s luck a helping hand.
<G-vec00092-001-s549><call.nennen><de> Wer eine Prinz sein Eigen nennt, drückt damit nicht nur seine Individualität aus, sondern auch und vor allem seinen Willen, dem Jagdglück ein wenig auf die Sprünge zu helfen.
<G-vec00092-001-s550><call.nennen><en> Beside of the helpless story contains the video a lot income statements of bank accounts and similar, full censored, and call it a proof.
<G-vec00092-001-s550><call.nennen><de> Neben der nutzlosen Story enthält das Video eine menge Kontostände von Bankkonto und ähnliches, voll zensiert, und nennt das auch noch einen Beweis.
<G-vec00092-001-s570><call.rufen><en> I call Mr.Levon Ter-Petrosyan for active cooperation and establishment of peace.
<G-vec00092-001-s570><call.rufen><de> Ich rufe Herrn Levon Ter-Petrosjan zur aktiven Zusammenarbeit auf Friedenssuche auf.
<G-vec00092-001-s571><call.rufen><en> 14 Is any sick among you? let him call to him the elders of the assembly, and let them pray over him, anointing him with oil in the name of the Lord;
<G-vec00092-001-s571><call.rufen><de> 14 Ist jemand krank, der rufe zu sich die Ältesten von der Gemeinde und lasse sie über sich beten und salben mit Öl in dem Namen des HErrn.
<G-vec00092-001-s572><call.rufen><en> Here I call on fellow practitioners to urgently search for those missing Falun Dafa practitioners, expose the evil persecution and save fellow practitioners.
<G-vec00092-001-s572><call.rufen><de> Ich rufe meine Mitpraktizierenden dazu auf, unbedingt die vermissten Falun Gong-Praktizierenden zu suchen, das Böse zu entlarven und die Mitpraktizierenden zu retten.
<G-vec00092-001-s573><call.rufen><en> And therefore I call to you time and again: Believe that you are shortly facing the end.
<G-vec00092-001-s573><call.rufen><de> Und immer wieder rufe Ich euch daher zu: Glaubet es, daß ihr kurz vor dem Ende steht.
<G-vec00092-001-s574><call.rufen><en> I know about the terrible lot of the souls; I see men in their blindness steer towards the abyss; I call out to them words of admonition and warning; I send to them guides into the way, who are to push them back onto the right way, which leads to me.
<G-vec00092-001-s574><call.rufen><de> Ich weiß um das furchtbare Los der Seelen, Ich sehe die Menschen in ihrer Blindheit dem Abgrund zusteuern, Ich rufe ihnen Mahn- und Warnworte zu, Ich sende ihnen Führer in den Weg, die sie zurückdrängen sollen auf den rechten Weg, der zu Mir führt.
<G-vec00092-001-s575><call.rufen><en> Regardless of whether they were from the business field or the Chinese consulate, they clearly heard the Falun Gong practitioners' call for ending the persecution.
<G-vec00092-001-s575><call.rufen><de> Ganz gleich, ob es Geschäftsleute waren oder vom Chinesischen Konsulat, konnten sie doch die Rufe der Praktizierenden die Verfolgung zu stoppen deutlich hören.
<G-vec00092-001-s576><call.rufen><en> I call to all Californian visionaries of immortality: first, let us make the world a better place – together.
<G-vec00092-001-s576><call.rufen><de> Ich komme zum Schluss: Allen kalifornischen Unsterblichkeits-Visionären rufe ich zu: Erstens: ja, lasst uns die Welt besser machen.
<G-vec00092-001-s577><call.rufen><en> In this case internet calls would not reach the actual owner of the call number any longer.
<G-vec00092-001-s577><call.rufen><de> Rufe aus dem Internet würden den Rufnummern-Inhaber in diesem Fall nicht mehr erreichen.
<G-vec00092-001-s578><call.rufen><en> I want to be the man that you run to whenever I call on you When everything that loved someone finally found it's way Wanna be a better man I see it in you yeah... Teile diesen Songtext
<G-vec00092-001-s578><call.rufen><de> Ich will der Mann sein, zu dem du immer rennst, egal wann ich nach dir rufe Wenn alle letztendlich ihren Weg gefunden haben Ich will ein besserer Mensch sein Ich kann es in dir sehen yeah...
<G-vec00092-001-s579><call.rufen><en> And then you will be blessed to own a supply of spiritual goods and so that you permanently increase these I admonish you again and again and call out to you to take seriously my admonition and to accept my word from above often because it is the most delicious gift I can give and because it has an exceedingly favourable influence on you.
<G-vec00092-001-s579><call.rufen><de> Und dann werdet ihr selig sein, einen Vorrat zu besitzen an geistigen Gütern, und auf daß ihr ständig diese vermehret, ermahne Ich euch immer wieder und rufe euch zu, Meine Mahnungen ernst zu nehmen und Mein Wort aus der Höhe des öfteren entgegenzunehmen, weil es die köstlichste Gabe ist, die Ich euch zuwenden kann, und weil sie überaus günstigen Einfluß hat auf euch.
<G-vec00092-001-s580><call.rufen><en> "Well, only if you want to be sarcastic and call that abovementioned gloom ""Finnish party mood""... Initially it seemed that this evening should see more people on stage than in front of it, most likely caused by the simple fact that not everybody had noticed the early schedule (first band started 20:15h, very unusual for Finland). But during the first songs the club filled up, and in the end the band faced a pretty big crowd that cheered and even wanted more."
<G-vec00092-001-s580><call.rufen><de> "Nunja, nur wenn man obengenannte düstere Stimmung sarkastischerweise als ""finnische Partylaune"" deklariert... Anfänglich schien es auch so, als sollten sich an diesem Abend mehr Musiker auf der Bühne tummelten als Publikum davor – die für Finnland ungewöhnlich früh angesetzte Beginnzeit des Konzerts (20:15h) hatte sich wohl nicht rechtzeitig herumgesprochen... doch im Laufe der ersten Songs füllte sich der Club, und am Schluss konnte diese neue finnische All-Star-Group verdienten Jubel von ziemlich vollem Haus und sogar vereinzelte Rufe nach Zugabe einheimsen."
<G-vec00092-001-s581><call.rufen><en> For, behold, I will call all the families of the kingdoms of the north, says Yahweh; and they shall come, and they shall set everyone his throne at the entrance of the gates of Jerusalem, and against all the walls of it round about, and against all the cities of Judah.
<G-vec00092-001-s581><call.rufen><de> Denn siehe, ich rufe allen Stammesgruppen in den Königreichen des Nordens zu, spricht der HERR, daß sie kommen, und jeder wird seinen Thron am Eingang der Tore Jerusalems aufstellen und gegen all seine Mauern ringsum und gegen alle Städte Judas.
<G-vec00092-001-s582><call.rufen><en> Take advantage of the time yet available and open your ears and your hearts, so that I THE LORD can soon reveal to you and do even greater things through MY messengers, call I THE LORD AND FATHER OF ETERNAL LOVE unto you.
<G-vec00092-001-s582><call.rufen><de> Nutzet die Zeit und öffnet eure Ohren und eure Herzen, auf daß ICH DER HERR euch bald noch Größeres durch MEINE Sendboten offenbaren und tun kann, rufe ICH euch zu, euer HERR und VATER DER EWIGEN LIEBE.
<G-vec00092-001-s583><call.rufen><en> He said to his companion; make the call to prayer so that we might be comforted by praying.
<G-vec00092-001-s583><call.rufen><de> Er sagte zu seinem Gefährten: Rufe zum Gebet, damit wir durch das Gebet Trost finden.
<G-vec00092-001-s584><call.rufen><en> "15 (UKJV) ""For, lo, I will call all the families of the kingdoms of the north, says the LORD; and they shall come, and they shall set every one his throne at the entering of the gates of Jerusalem, and against all the walls thereof round about, and against all the cities of Judah. """
<G-vec00092-001-s584><call.rufen><de> 15 (ELB) Denn siehe, ich rufe allen Geschlechtern der Königreiche gegen Norden, spricht Jehova, daß sie kommen und ein jeder seinen Thron stellen an den Eingang der Tore Jerusalems und wider alle seine Mauern ringsum, und wider alle Städte Judas.
<G-vec00092-001-s585><call.rufen><en> I call on each one of you to consciously decide for God and against Satan.
<G-vec00092-001-s585><call.rufen><de> Ich rufe euch auf, daß sich jeder von euch bewußt für Gott und gegen Satan entscheidet.
<G-vec00092-001-s586><call.rufen><en> I call on Member States to clarify and expand international law on environmental protection in times of war.
<G-vec00092-001-s586><call.rufen><de> Ich rufe die Mitgliedstaaten der Vereinten Nationen dazu auf, die internationalen Gesetze für den Umweltschutz in Zeiten von Kriegen zu präzisieren und auszuweiten.
<G-vec00092-001-s587><call.rufen><en> Today is a day of peace, but in the whole world there is a great lack of peace. That is why I call you all to build a new world of peace with me through prayer.
<G-vec00092-001-s587><call.rufen><de> Heute ist der Tag des Friedens, aber in der ganzen Welt ist viel Unfriede, deshalb rufe ich euch auf, daß ihr alle mit mir durch das Gebet eine neue Welt des Friedens aufbaut.
<G-vec00092-001-s588><call.rufen><en> SCP-1340-12: I hereby call this meeting into order.
<G-vec00092-001-s588><call.rufen><de> SCP-1340-12: Ich rufe dieses Treffen hiermit zur Ordnung.
<G-vec00092-001-s589><call.rufen><en> Send a rental inquiry through fritiden.se or call the landlordLinda Lindell at 070-5098939.
<G-vec00092-001-s589><call.rufen><de> Schicken Sie eine Buchungsanfrage über fritiden.se oder rufen Sie den VermieterLinda Lindell unter 070-5098939 an.
<G-vec00092-001-s590><call.rufen><en> As a basis for our study we assume an arbitrary collection of entities of an arbitrary nature, entities which, for brevity, we shall call points, but this is quite independent of their nature.
<G-vec00092-001-s590><call.rufen><de> Als Grundlage für unsere Studie gehen wir davon eine willkürliche Sammlung von Entitäten einer willkürlichen Charakter, Organisationen, die zu kurz, wir rufen Punkte, aber das ist ganz unabhängig von ihrer Natur.
<G-vec00092-001-s591><call.rufen><en> You are encouraged to call upon us should you require our help, and we will respond with love and help you where possible.
<G-vec00092-001-s591><call.rufen><de> Ihr seid ermuntert, nach uns zu rufen, solltet ihr unserer Hilfe bedürfen, und wir werden, wo es möglich ist, mit Liebe und Hilfe darauf antworten.
<G-vec00092-001-s592><call.rufen><en> You set the cursor on the line with the block to rename and then you call this command Rename block .
<G-vec00092-001-s592><call.rufen><de> Setzen Sie den Cursor auf die Zeile des Bausteins, den Sie umbenennen wollen und rufen Sie nun das Kommando Umbenennen auf.
<G-vec00092-001-s593><call.rufen><en> On the lower floor there are four bedrooms, a large bathroom and storage room.It is a very bright apartment with cross ventilation.It has pre-installation of natural gas for heating and natural gas.With a reform you can stay a large floor to the taste of the consumer.If you want to buy a flat in El Carmen, do not hesitate to call us, Atico inmobiliaria Inmobiliaria.
<G-vec00092-001-s593><call.rufen><de> In der unteren Etage befinden sich vier Schlafzimmer, ein großes Badezimmer und ein Abstellraum.Es ist eine sehr helle Wohnung mit Querlüftung.Es hat Erdgas zum Heizen und Erdgas vorinstalliert.Mit einer Reform können Sie eine große Etage nach dem Geschmack des Verbrauchers bleiben.Wenn Sie eine Wohnung in El Carmen kaufen möchten, rufen Sie uns bitte Atico inmobiliaria Inmobiliaria an.
<G-vec00092-001-s594><call.rufen><en> Send a Rental Inquiry Or call the landlord Peter Schmidt at 049034544 (0706195007).
<G-vec00092-001-s594><call.rufen><de> Buchungsanfrage Schicken Oder rufen Sie den Vermieter Peter Schmidt unter 049034544 (0706195007) an.
<G-vec00092-001-s595><call.rufen><en> Please call toll-free 0800 1 85 55 22 (Germany) to speak to a booking specialist or click the button below to view a list of our hotels in Germany. Weimar
<G-vec00092-001-s595><call.rufen><de> Bitte rufen Sie uns unter 0800 1 85 55 22 (Deutschland) (gebührenfrei aus Deutschland) an, um mit unserem Reservierungsservice zu sprechen oder klicken Sie auf den Button unten, um eine Liste unserer Hotels in Deutschland zu erhalten.
<G-vec00092-001-s596><call.rufen><en> Other necessary functions include music playing, call receiving and security monitoring.
<G-vec00092-001-s596><call.rufen><de> Andere notwendigen Funktionen umfassen Musikwiedergabe, rufen empfangen und Sicherheitsüberwachung.
<G-vec00092-001-s597><call.rufen><en> Call the service, they themselves only develop the immunity, the further, the harder it is to choose the drug for complete destruction.
<G-vec00092-001-s597><call.rufen><de> Rufen Sie den Dienst an, sie selbst entwickeln nur die Immunität, je weiter es desto schwieriger ist, das Medikament für die vollständige Zerstörung auszuwählen.
<G-vec00092-001-s598><call.rufen><en> In case you need help, please call our customer service on the phone number: +36 1 510 0548.
<G-vec00092-001-s598><call.rufen><de> Sollten Sie Hilfe brauchen, rufen Sie bitte unseren Kundendienst an:+36 1 510 0548.
<G-vec00092-001-s599><call.rufen><en> I was afraid that they would call the police, so I decided to go back and not tell them that I took the pills.
<G-vec00092-001-s599><call.rufen><de> Ich fürchtete sie würden die Polizei rufen, also entschied ich zurückzugehen und ihnen nicht zu sagen dass ich die Pillen nahm.
<G-vec00092-001-s600><call.rufen><en> We will be happy to call you back
<G-vec00092-001-s600><call.rufen><de> Gerne rufen wir Sie zurück.
<G-vec00092-001-s601><call.rufen><en> How much you call - All cards expire (usually 30-90 days from the first time you use it to call).
<G-vec00092-001-s601><call.rufen><de> Wie viel Sie rufen - (normalerweise 30-90 Tage nach dem ersten Mal, wenn Sie es verwenden, um Anruf) Alle Karten verfallen.
<G-vec00092-001-s602><call.rufen><en> Please get ready all the necessary information (see Question above) and call our Reservation Center.
<G-vec00092-001-s602><call.rufen><de> Bitte halten sie alle benoetigten Informationen berreit (siehe Fragen unten) und rufen sie unser Reservierungs Center an.
<G-vec00092-001-s603><call.rufen><en> Send a rental inquiry or call the landlord Eva Rapp Rock / Rappland House Rent co.Ltd at +46 70-2973363.
<G-vec00092-001-s603><call.rufen><de> Klicken Sie hier um eine Buchungsanfrage zu schicken oder rufen Sie den Vermieter Eva Rapp Rock / Rappland House Rent co.Ltd unter +46 70-2973363 an.
<G-vec00092-001-s604><call.rufen><en> If you have any questions about our Class I leak detectors, call us.
<G-vec00092-001-s604><call.rufen><de> Wenn Sie vorab Fragen rund um unsere Klasse-I-Leckanzeiger haben, rufen Sie uns an.
<G-vec00092-001-s605><call.rufen><en> It is advisable, when traveling by provincial buses in this region, to call in and buy the ticket the evening before, in order to ensure a numbered seat (as opposed to the possibility of a stool in the gangway).
<G-vec00092-001-s605><call.rufen><de> Es ist ratsam, beim Reisen durch provinzielle Busse in diesem Gebiet, in zu rufen, und travel Karte den Abend vor zu kaufen, um zu sichern, einen gezählten Sitz (im Gegensatz zur Möglichkeit von einem Hocker in der Gangway).
<G-vec00092-001-s606><call.rufen><en> And in the Assembly people were saying that person who said that, we should call him in the rainy season, when there’s lots of mud and sometimes your feet sink 50 or 80 centimeters, and you don’t realize there’s glass or sharp rocks underneath.
<G-vec00092-001-s606><call.rufen><de> In der Versammlung wurde darauf gesagt, dass man denjenigen der dies sagte, rufen sollte, wenn Regenzeit ist, wenn alles voller Schlamm ist und die Füße manchmal versinken, 50 bis 80 Zentimeter, und man nicht merkt, ob irgendwo Glas liegt, oder spitze Steine oder Stöcke.
<G-vec00092-001-s607><call.rufen><en> arriving in Paraty, you can walk 50 mts from the bus station, taking the right street in east direction, till the big tree (thereÂ ́s a pizzaria in the corner of the house)or call us and weÂ ́ll go until you in a minute.
<G-vec00092-001-s607><call.rufen><de> Ankunft in Paraty, können Sie zu Fuß 50 m von der Bushaltestelle, die die Straße rechts in Richtung Osten, bis zum großen Baum (gibt es eine Pizzeria in der Ecke des Hauses) oder rufen Sie uns an und wir gehen, bis Sie in einem Minute.
<G-vec00092-001-s608><call.anrufen><en> For relaxed vacation moments, call them and they will take you to the desired location.
<G-vec00092-001-s608><call.anrufen><de> Wenn sie sich den Urlaub ohne Sorgen wünschen, rufen Sie sie an, und sie werden sie auf die gefragte Stelle bringen.
<G-vec00092-001-s609><call.anrufen><en> Call +31 (0)497 383818 or e-mail marketing@kse.nl to request free entry tickets or to pre-arrange an appointment at the event.
<G-vec00092-001-s609><call.anrufen><de> Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zumarketing@kse.nlfür kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00092-001-s610><call.anrufen><en> Visit KSE on stand G028 in hall 5.Â Call +31 (0)497 383818 or e-mail marketing@kse.nlÂ to request free entry tickets or to pre-arrange an appointment on the stand.
<G-vec00092-001-s610><call.anrufen><de> Besuchen Sie KSE auf Stand G028 in Halle 5.Â Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zu marketing@kse.nlÂ für kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00092-001-s611><call.anrufen><en> Please call:
<G-vec00092-001-s611><call.anrufen><de> Rufen Sie uns an.
<G-vec00092-001-s612><call.anrufen><en> Please call us at the opening times.
<G-vec00092-001-s612><call.anrufen><de> Bitte rufen Sie uns während der Öffnungszeiten an.
<G-vec00092-001-s613><call.anrufen><en> The cafe is strictly reservation only, so make sure to call in advance.
<G-vec00092-001-s613><call.anrufen><de> Reservierungen sind unabdingbar, um bedient zu werden, rufen Sie deshalb unbedingt im Vorfeld an.
<G-vec00092-001-s614><call.anrufen><en> Call if you are in doubt or need advice and information yourself.
<G-vec00092-001-s614><call.anrufen><de> Rufen Sie uns an, sofern Sie im Zweifel sind oder selbst Rat und Auskunft benötigen.
<G-vec00092-001-s615><call.anrufen><en> Please call (or have your lawyer call) us for more details: Tel.
<G-vec00092-001-s615><call.anrufen><de> Rufen Sie uns an (oder lassen Sie Ihren Anwalt anrufen) um weitere Informationen zu bekommen: Tel.
<G-vec00092-001-s616><call.anrufen><en> Just call us or send us e-mail.
<G-vec00092-001-s616><call.anrufen><de> Rufen Sie uns einfach an oder senden Sie uns eine E- Mail.
<G-vec00092-001-s617><call.anrufen><en> You can find more detailed information on our homepage Or call us
<G-vec00092-001-s617><call.anrufen><de> und ausführlichere Informationen finden Sie auf unserer Homepage oder rufen Sie uns an.
<G-vec00092-001-s618><call.anrufen><en> Only experts call, but then they do not give a guarantee.
<G-vec00092-001-s618><call.anrufen><de> Nur Experten rufen an, aber dann geben sie keine Garantie.
<G-vec00092-001-s619><call.anrufen><en> Call 150 and follow voice prompts to enter scratch card details.
<G-vec00092-001-s619><call.anrufen><de> Rufen Sie die 150 an und folgen Sie den Sprachanweisungen, um die Scratch-Karte auf Ihre SIM-Karte aufzuladen.
<G-vec00092-001-s620><call.anrufen><en> Call and organize all your...
<G-vec00092-001-s620><call.anrufen><de> Rufen Sie an und organisieren...
<G-vec00092-001-s621><call.anrufen><en> Or simply call us.
<G-vec00092-001-s621><call.anrufen><de> Oder rufen Sie uns einfach an.
<G-vec00092-001-s622><call.anrufen><en> Please call if your vehicle is higher than 1.95 metres
<G-vec00092-001-s622><call.anrufen><de> Bitte rufen Sie an, wenn Ihr Fahrzeug höher als 1,95 m ist.
<G-vec00092-001-s623><call.anrufen><en> Visit KSE on stand B7878, hall B. Call +31 (0)497 383818 or e-mailmarketing@kse.nlto request free entry tickets or to pre-arrange an appointment on the stand. During the IPPE, KSE gives a TECHTalk with the title ‘Dosing Slide vs. Dosing Screw.
<G-vec00092-001-s623><call.anrufen><de> Besuchen Sie KSE auf Stand B7878, Halle B. Rufen Sie an: +31 (0)497 383818 oder senden Sie eine E-Mail:marketing@kse.nlfür kostenlose Eintrittskarten oder für einen vorher vereinbarten Termin auf der Stand.
<G-vec00092-001-s624><call.anrufen><en> Call us for more information.
<G-vec00092-001-s624><call.anrufen><de> Rufen Sie uns fÃ1⁄4r weitere Informationen an.
<G-vec00092-001-s625><call.anrufen><en> Call us, or send us an e-mail, and you will quickly receive your personalized gift certificate.
<G-vec00092-001-s625><call.anrufen><de> Rufen Sie uns an, oder senden Sie uns eine mail, schnell erhalten Sie Ihren ganz persönlichen Gutschein zum verschenken.
<G-vec00092-001-s626><call.anrufen><en> Call us toll free.
<G-vec00092-001-s626><call.anrufen><de> Rufen Sie uns an Maut.
<G-vec00092-001-s627><call.rufen><en> Just call our customer service: +49 89 4161 430 70.
<G-vec00092-001-s627><call.rufen><de> Rufen Sie einfach unseren Kundenservice an: +49 89 4161 430 70.
<G-vec00092-001-s628><call.rufen><en> Call on the help of neighbors and create for your children a whole gaming complex together.
<G-vec00092-001-s628><call.rufen><de> Rufen Sie die Hilfe von Nachbarn an und schaffen Sie für Ihre Kinder einen ganzen Spielkomplex zusammen.
<G-vec00092-001-s629><call.rufen><en> This is why hiring our immigration law firm can greatly improve your chances of success in the immigration process, and in starting a new life in the U.S. No matter what your immigration status is, or your immigration plans are, call our firm at +1 (941) 362-7100.
<G-vec00092-001-s629><call.rufen><de> Dies is der Grund, unsere Einwanderungsanwaltskanzlei zu beauftragen, damit wir Ihre Chancen auf Erfolg in dem Einwanderungsprozess erheblich verbessern können, und Sie ein neues Leben in den USA zu beginnen können, ganz gleich was Ihr Aufenthaltsstatus ist, oder Ihre Einwanderungspläne sind, rufen Sie unsere Kanzlei unter +1 (941) 362-7100 an.
<G-vec00092-001-s630><call.rufen><en> Call diligently on his name.
<G-vec00092-001-s630><call.rufen><de> Rufen Sie bestndig seinen Namen an.
<G-vec00092-001-s631><call.rufen><en> Detailed specifications, CAD and datasheets can be found on our webstore, alternatively request a catalogue or call customer service for support in selecting the rightcomponent for your application.
<G-vec00092-001-s631><call.rufen><de> Detaillierte technische Daten, CAD-Zeichnungen und Datenblätter finden Sie unter Webstore, alternativ können Sie auch auf Anfrage Kataloge anfordern oder rufen Sie unseren Kundenservice an, um sich bei der Auswahl des richtigen Wartungsgerätes, für Ihre Anwendung, beraten zu lassen.
<G-vec00092-001-s632><call.rufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00092-001-s632><call.rufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00092-001-s633><call.rufen><en> If the problem persists, call Customer Service.
<G-vec00092-001-s633><call.rufen><de> Wenn das Problem anhält, rufen Sie den Kundendienst an.
<G-vec00092-001-s634><call.rufen><en> "Make sure your status - if in the next 15 minutes it will be a wet spot, immediately call the brigade ""first aid"" - doctors know exactly how to determine the leakage of amniotic fluid."
<G-vec00092-001-s634><call.rufen><de> Stellen Sie sicher, dass Ihr Status - wenn in den nächsten 15 Minuten wird es eine nasse Stelle sein, rufen Sie sofort die Brigade „Erste Hilfe“ - die Ärzte wissen genau, wie das Austreten von Fruchtwasser zu bestimmen.
<G-vec00092-001-s635><call.rufen><en> Call the plug-in with the command Effects -> AKVIS -> Retoucher.
<G-vec00092-001-s635><call.rufen><de> Rufen Sie das Plugin mit dem Befehl Effekte -> AKVIS -> Retoucher.
<G-vec00092-001-s636><call.rufen><en> Call now gladly advise free.
<G-vec00092-001-s636><call.rufen><de> Rufen Sie jetzt gerne beraten kostenlos.
<G-vec00092-001-s637><call.rufen><en> Call now to reserve one of our most popular rooms.
<G-vec00092-001-s637><call.rufen><de> Rufen Sie jetzt an, um eines unserer beliebtesten Zimmer reservieren.
<G-vec00092-001-s638><call.rufen><en> Favorites Call a user, meeting room or conference room system listed in your favorites.
<G-vec00092-001-s638><call.rufen><de> Favoriten Rufen Sie einen Benutzer, einen Konferenzraum oder ein Konferenzraumsystem an, das in Ihren Favoriten hinterlegt ist.
<G-vec00092-001-s639><call.rufen><en> Or call YouTube in the integrated Internet browser and see YouTube videos on your TV screen in HDTV quality.
<G-vec00092-001-s639><call.rufen><de> Oder rufen Sie YouTube in dem integrierten Internet-Browser auf und sehen Sie YouTube-Videos auf Ihrem TV-Bildschirm in HDTV-Qualität.
<G-vec00092-001-s640><call.rufen><en> Call today for a quote.
<G-vec00092-001-s640><call.rufen><de> Rufen Sie noch heute ein Angebot.
<G-vec00092-001-s641><call.rufen><en> Call the Australian Customs Service at tel.
<G-vec00092-001-s641><call.rufen><de> Rufen Sie den Australian Customs Service unter Tel..
<G-vec00092-001-s642><call.rufen><en> Call now for more information.
<G-vec00092-001-s642><call.rufen><de> Rufen Sie für weitere Informationen.
<G-vec00092-001-s643><call.rufen><en> Send a rental inquiry through fritiden.se or call the landlordUlf Linderbäck at 070-6069760.
<G-vec00092-001-s643><call.rufen><de> Schicken Sie eine Buchungsanfrage Ã1⁄4ber fritiden.se oder rufen Sie den VermieterUlf Linderbäck unter 070-6069760 an.
<G-vec00092-001-s644><call.rufen><en> Iberflora and all entities and associations that collaborate in the preparation of its parallel activities final details for its next edition, from 3 rd to 5 October at Feria Valencia in joint with EUROBRICO call, the International Salon of DIY.
<G-vec00092-001-s644><call.rufen><de> Iberflora und alle Entitäten und Zuordnungen, die Zusammenarbeit in der Vorbereitung seiner parallele Aktivitäten letzte Details für die nächste Ausgabe, die 3 zum 5 Rufen Sie Oktober Feria Valencia in Verbindung mit EUROBRICO, Internationaler Salon der DIY.
<G-vec00092-001-s645><call.rufen><en> Try our new “call me back” feature, to let your busy friends know you want them to call.
<G-vec00092-001-s645><call.rufen><de> Probieren Sie unsere neue „rufen Sie mich zurück“ -Funktion, lassen Sie Ihre beschäftigt Freunde wissen, dass Sie sie nennen wollen.
<G-vec00092-001-s646><call.rufen><en> The beginnings of evangelization on the South American continent always call to mind the Dominican land which was the first to receive the rich deposit of faith, which the missionaries brought with steadfast fidelity and proclaimed with constancy.
<G-vec00092-001-s646><call.rufen><de> Der Beginn der Evangelisierung auf dem amerikanischen Kontinent ruft stets die dominikanischen Inseln ins Gedächtnis, da sie als Erste das reiche Glaubensgut empfangen haben, das von den Missionaren treu überliefert und beharrlich verkündet wurde.
<G-vec00092-001-s647><call.rufen><en> Whether ye call them or are silent is all one for you.
<G-vec00092-001-s647><call.rufen><de> Es ist ganz gleich für euch, ob ihr sie ruft oder ob ihr schweigt.
<G-vec00092-001-s648><call.rufen><en> And in this vocation God did not call Abraham alone, as an individual, but involved from the start his family, his household and all those in service to his house.
<G-vec00092-001-s648><call.rufen><de> Und in dieser Berufung ruft Gott Abraham nicht allein, als Einzelnen, sondern er bezieht von Anfang an seine Familie, seine Verwandtschaft und alle ein, die im Dienst an seinem Haus stehen.
<G-vec00092-001-s649><call.rufen><en> Or they can call me in one of Lifesize's persistent virtual meeting rooms, and we can sit down and talk through the issues.
<G-vec00092-001-s649><call.rufen><de> Oder die Person ruft mich in einem der bestehenden virtuellen Konferenzräume von Lifesize an, sodass wir uns zusammensetzen und alles durchsprechen können.
<G-vec00092-001-s650><call.rufen><en> It should be personal because the presence of Christ among his people can most effectively be pointed to by the person ordained to proclaim the Gospel and to call the community to serve the Lord in unity of life and witness.
<G-vec00092-001-s650><call.rufen><de> Persönlich dadurch, daß auf die Präsenz Jesu Christi unter seinem Volk am wirksamsten durch eine Person hingewiesen werden kann, die ordiniert worden ist, um das Evangelium zu verkündigen, und die Gemeinschaft dazu ruft, dem Herrn in Einheit von Leben und Zeugnis zu dienen.
<G-vec00092-001-s651><call.rufen><en> For this reason - as I stressed in the same Message - the priest's mission is irreplaceable, and even if in some regions a scarcity of clergy is being recorded, we must never doubt that God continues to call boys, young men and adults to leave everything to dedicate themselves totally to preaching the Gospel and to the pastoral ministry (cf. Message for the World Day of Prayer for Vocations 2006, L'Osservatore Romano English edition, 12 April 2006, p. 5).
<G-vec00092-001-s651><call.rufen><de> Aus diesem Grund ist – wie ich in derselben Botschaft betont habe – die Sendung des Priesters unersetzlich, und auch wenn in manchen Gegenden ein Priestermangel festzustellen ist, darf man nicht daran zweifeln, daß Gott auch weiterhin Jungen, junge Männer und Erwachsene dazu ruft, alles zu verlassen, um sich der Predigt des Evangeliums und dem Pastoraldienst zu widmen.
<G-vec00092-001-s652><call.rufen><en> He reports that around 1931, a former leader of the Guomindang left challenged a Left Oppositionist: “You Trotskyists claim that the revolution in China is proletarian, but you call for a national assembly; the Stalinists say that it is bourgeois but call for soviets.
<G-vec00092-001-s652><call.rufen><de> Er berichtet, dass um 1931 ein ehemaliger Führer der Guomindang-Linken ein Mitglied der Linken Opposition konfrontiert habe: „,Ihr Trotzkisten behauptet, dass die Revolution in China proletarisch sei‘, sagte er,,aber ihr ruft zu einer Nationalversammlung auf; während die Stalinisten sagen, die Revolution sei bürgerlich, aber zur Bildung von Sowjets aufrufen.
<G-vec00092-001-s653><call.rufen><en> When you are before a person who seems to be spiritually receptive, call upon your brothers Michael and Monjoronson and ask for their peace and forgiveness to be seeded into that other persons being.
<G-vec00092-001-s653><call.rufen><de> Wenn ihr vor einer Person steht, die geistig empfänglich zu sein scheint, ruft eure Brüder Michael oder Monjoronson und bittet um ihren Frieden und ihre Vergebung, damit sie in das Wesen dieser anderen Personen gesät werden.
<G-vec00092-001-s654><call.rufen><en> Whenever you fall, call upon Jesus and seek Him in the Sacrament of Confession.
<G-vec00092-001-s654><call.rufen><de> Wenn es vorkommt dass ihr faellt, ruft nach Jesus und sucht Ihn im Sakrament der Beichte.
<G-vec00092-001-s655><call.rufen><en> Call down the Avatar of Form, the embodiment of psionic potential.
<G-vec00092-001-s655><call.rufen><de> Ruft den Avatar der Form, die Verkörperung psionischen Potenzials.
<G-vec00092-001-s656><call.rufen><en> "In the first place, he continues to call the Churches of so-called ""ancient tradition"", which in the past provided the missions with a consistent number of priests, men and women religious and lay people as well as material means, giving life to an effective cooperation between Christian communities."
<G-vec00092-001-s656><call.rufen><de> Er ruft weiterhin an erster Stelle die sogenannten Kirchen mit alter Tradition auf, die in der Vergangenheit außer materiellen Gütern auch eine ansehnliche Zahl an Priestern, Ordensmännern, Ordensfrauen und Laien zur Verfügung gestellt und auf diese Weise eine wirksame Zusammenarbeit zwischen den christlichen Gemeinden geschaffen haben.
<G-vec00092-001-s657><call.rufen><en> At about four in the afternoon we get a call from Chief of Section Tomas Pochop: “Guys, a convoy of police cars will be arriving after five. It would be worth taking a couple of pictures.”
<G-vec00092-001-s657><call.rufen><de> Um vier Uhr nachmittags ruft der Chef der Abteilung Tomáš Pochop an: „Jungs, nach fünf kommt eine Kolone von Polizeiwagen, das wäre ein Foto wert.“ Im Schneegestöber warte ich auf die Fahrzeuge der Polizei der Tschechischen Republik im neuen Design.
<G-vec00092-001-s658><call.rufen><en> If you have any problems, call us and we will help.
<G-vec00092-001-s658><call.rufen><de> Solltet ihr Schwierigkeiten haben, ruft uns an, und wir helfen euch gerne weiter.
<G-vec00092-001-s659><call.rufen><en> Then when He calls you with a [single] call from the earth, immediately you will come forth.
<G-vec00092-001-s659><call.rufen><de> Wenn Er euch hierauf ein (einziges Mal) ruft, da kommt ihr sogleich aus der Erde hervor.
<G-vec00092-001-s660><call.rufen><en> He hears but cannot answer to your call.
<G-vec00092-001-s660><call.rufen><de> Er hört, reagiert aber nicht, wenn man ihn ruft.
<G-vec00092-001-s661><call.rufen><en> She might not return a call, or she might make a snide or offensive comment when talking to you.
<G-vec00092-001-s661><call.rufen><de> Vielleicht ruft er nicht zurück oder macht bei einem eurer Gespräche eine höhnische oder beleidigende Anmerkung.
<G-vec00092-001-s662><call.rufen><en> Acknowledge their presence and call them to service on your behalf.
<G-vec00092-001-s662><call.rufen><de> Erkennt ihre Präsenz an und ruft sie in eurem Auftrag um Hilfestellung an.
<G-vec00092-001-s663><call.rufen><en> Call of Duty: Advanced Warfare is a military science fiction war thriller first-person shooter video game published by Activision.
<G-vec00092-001-s663><call.rufen><de> Die Pflicht ruft: Erweiterte Warfare ist ein Military Science Fiktion Krieg Thriller Ego-Shooter Videospiel von Activision veröffentlicht.
<G-vec00092-001-s664><call.rufen><en> The planned and brutal murder of a French priest is a call to wage religious war on many levels....
<G-vec00092-001-s664><call.rufen><de> Der geplante, brutale Mord an dem französischen Priester ruft in vielfältiger Weise zum Religionskrieg auf....
<G-vec00485-002-s038><call.abrufen><en> Get phone call logs history with Location Read more...
<G-vec00485-002-s038><call.abrufen><de> Abrufen des Anrufprotokollverlaufs mit Standort Mehr erfahren...
<G-vec00485-002-s039><call.abrufen><en> In future the air conditioning will link up to my smartphone via an interface provided by the manufacturer and an app and call up my settings – temperature, ventilator, off.
<G-vec00485-002-s039><call.abrufen><de> In Zukunft wird sich die Klimaanlage über ein Interface des Herstellers und eine App mit meinem Smartphone verbinden und meine Einstellungen abrufen – Temperatur, Ventilator, Off-Einstellung.
<G-vec00485-002-s040><call.abrufen><en> Topped off by the intelligent design, athletes can call up their optimum performance - both during workout and in competition.
<G-vec00485-002-s040><call.abrufen><de> Abgerundet durch das intelligente Design können Sportler Ihre optimale Leistung abrufen – sowohl beim Workout als auch im Wettkampf.
<G-vec00485-002-s041><call.abrufen><en> No profound mission stimulating thought - design, like Clayman with his "Zero," no deliberation is announced here, just follow the orders and do your thing, and call on your abilities, to exist in this mission, which is called "go, go, go..." from beginning to end.
<G-vec00485-002-s041><call.abrufen><de> Kein tiefgründiges, zum Denken anregendes Mission – Design, wie Clayman mit seinem „Zero“, kein Überlegen ist hier angesagt, nein den Orders folgen und Deinen Dienst tun und Dein Können abrufen, um in dieser Mission zu bestehen, die von Anfang bis Ende „go,go,go...“ heißt.
<G-vec00485-002-s042><call.abrufen><en> Drivers can call up camera images and receive alarm alerts during their trip.
<G-vec00485-002-s042><call.abrufen><de> Während der Fahrt kann der Fahrer Kamerabilder abrufen und Alarmmeldungen empfangen.
<G-vec00485-002-s043><call.abrufen><en> VitaDock® Online from Medisana makes it possible to save, call up, evaluate and export your personal vital data such as blood pressure, blood sugar, blood oxygen, body temperature, weight and activity.
<G-vec00485-002-s043><call.abrufen><de> VitaDock® Online von Medisana ermöglicht das Speichern, Abrufen, Auswerten und Exportieren Ihrer persönlichen Vitaldaten wie Blutdruck, Blutzucker, Blutsauerstoff, Körpertemperatur, Gewicht und Aktivität.
<G-vec00485-002-s044><call.abrufen><en> Therefore, you should have a high –tech tool that empowers you to get the Voip call history logs.
<G-vec00485-002-s044><call.abrufen><de> Daher sollten Sie über ein Hightech-Tool verfügen, mit dem Sie die Voip-Anrufprotokolle abrufen können.
<G-vec00485-002-s045><call.abrufen><en> In NoRA, you can call up the abstract of any of the standards, and for the majority of standards also the table of contents.
<G-vec00485-002-s045><call.abrufen><de> Sie können über NoRA zu jeder Norm das Kurzreferat und in den meisten Fällen auch das Inhaltsverzeichnis abrufen.
<G-vec00485-002-s046><call.abrufen><en> With the monitoring tools, users can call up and view the system’s performance online at any time.
<G-vec00485-002-s046><call.abrufen><de> Mit Monitoring-Tools kann der Nutzer die Leistung der Anlage jederzeit online abrufen.
<G-vec00485-002-s047><call.abrufen><en> Intelligent service starts in your BMW X6 from where you can call up your service status at any time.
<G-vec00485-002-s047><call.abrufen><de> Im BMW M3 Coupé können Sie jederzeit den Service-Status abrufen.
<G-vec00485-002-s048><call.abrufen><en> In addition, you can easily go with a few clicks the Our company call in order to find us easily.
<G-vec00485-002-s048><call.abrufen><de> Darüber hinaus können Sie bequem unterwegs mit ein paar Klicks den Standort unserer Firma abrufen damit Sie uns leicht finden.
<G-vec00485-002-s049><call.abrufen><en> If you call up this website from inside the Provincial Government Buildings, there is no limit on the 'Addressee' field, but your own Province e-mail address has to be in the 'Sender' field.
<G-vec00485-002-s049><call.abrufen><de> Wenn Sie diese Website innerhalb des Gouvernements abrufen, gilt keine Einschränkung für das Feld 'Adressat', doch im Feld 'Absender' sollte Ihre Provinz-E-Mail-Adresse stehen.
<G-vec00485-002-s050><call.abrufen><en> Our partners can call up special additional services directly at the POS with a personal password.
<G-vec00485-002-s050><call.abrufen><de> Mit einem persönlichen Passwort können unsere Partner am Point of Sale die besonderen Zusatzleistungen abrufen.
<G-vec00485-002-s051><call.abrufen><en> Should you call up pages and files within our site and thus be asked to enter data about yourself, we hereby give notice that such data transmission via the internet is not secure, and that these data can thus be seen by unauthorised persons, or can be forged.
<G-vec00485-002-s051><call.abrufen><de> Wenn Sie innerhalb unseres Angebotes Seiten und Dateien abrufen und dabei aufgefordert werden, Daten über sich einzugeben, so weisen wir darauf hin, dass diese Datenübertragung über das Internet ungesichert erfolgt, die Daten somit von Unbefugten zur Kenntnis genommen oder auch verfälscht werden können.
<G-vec00485-002-s052><call.abrufen><en> In the future, marketing will increasingly become a service, as users are able to call up additional information via tags and communicate directly with the retailer.
<G-vec00485-002-s052><call.abrufen><de> Künftig wird Marketing immer mehr zum Service, indem User über Tags Zusatzinformationen abrufen und mit dem Händler direkt kommunizieren können.
<G-vec00485-002-s053><call.abrufen><en> I do not leave you without a fight to my opponent but I can only oppose him with love and therefore also call you away out of love when the only thing that you can still expect on earth is death, spiritual death, which is so terrible that I take pity and want to protect you from it.
<G-vec00485-002-s053><call.abrufen><de> Ich überlasse euch nicht kampflos Meinem Gegner, doch nur mit Liebe kann Ich ihm gegenübertreten und also auch aus Liebe euch abrufen, wenn ihr auf Erden nur noch den Tod zu erwarten habt, den geistigen Tod, der so entsetzlich ist, daß es Mich erbarmet und Ich euch davor bewahren will.
<G-vec00485-002-s054><call.abrufen><en> This saves time, for example, when the operator can call data required from CAD/CAM applications directly from the TNC control.
<G-vec00485-002-s054><call.abrufen><de> Das spart Zeit, wenn Sie direkt von der TNC-Steuerung fehlende Daten aus CAD/CAM-Anwendungen abrufen können.
<G-vec00485-002-s055><call.abrufen><en> The user can for example call up video sequences that show the changing of the film roll and the film knife.
<G-vec00485-002-s055><call.abrufen><de> Der Bediener kann zum Beispiel Videosequenzen abrufen, die den Folienrollen- und Folienmesserwechsel zeigen.
<G-vec00485-002-s056><call.abrufen><en> In addition, the website operator can also recognize which subpages you call up on the page, as each page call ends up in a so-called log file.
<G-vec00485-002-s056><call.abrufen><de> Zudem kann der Webseitenbetreiber erkennen, welche Unterseiten Sie auf der Seite abrufen, da jeder Seitenabruf in einer sogenannten Log-Datei landet.
<G-vec00485-002-s133><call.anrufen><en> Automatically saves your device's call history to a calendar.
<G-vec00485-002-s133><call.anrufen><de> Speichert Anrufe automatisch im Kalender Ihres Geräts.
<G-vec00485-002-s134><call.anrufen><en> It displays the list of recent call that you have made or received.
<G-vec00485-002-s134><call.anrufen><de> Es wird die Liste der zuletzt durchgeführten oder angenommenen Anrufe angezeigt.
<G-vec00485-002-s135><call.anrufen><en> But when I call you never seem to be home
<G-vec00485-002-s135><call.anrufen><de> Aber wenn ich anrufe scheinst du nie Zuhause zu sein.
<G-vec00485-002-s136><call.anrufen><en> Login Mobile Spy Package, Monitor GPS locations, Call, SMS, Videos, Photos and Social Media and much more.
<G-vec00485-002-s136><call.anrufen><de> Login Mobiles Spionagepaket, Überwachung von GPS-Standorten, Anrufe, SMS, Videos, Fotos und Social Media und vieles mehr.
<G-vec00485-002-s137><call.anrufen><en> Call blending – using an auto dialing strategy such as predictive dialing combined with inbound call handling - drives significant efficiencies through the ability to allocate agents across contact channels through true and through automated multichannel blending defined by business rules.
<G-vec00485-002-s137><call.anrufen><de> Call Blending – mit einer Autodialer-Strategie wie Predictive Dialing, kombiniert mit der Behandlung eingehender Anrufe – eröffnet die Möglichkeit, die Mitarbeiter über die Kontaktkanäle hinweg über echtes oder automatisiertes Mehrkanal-Blending gemäß der Definition in den Geschäftsregeln zuzuweisen, und sorgt so für erhebliche Effizienz.
<G-vec00485-002-s138><call.anrufen><en> * Any kind of alcoholic drinks, hot shower, cold drinks, snacks, laundry, phone call, internet.
<G-vec00485-002-s138><call.anrufen><de> * Jede Art von alkoholischen Getränken, kalten Getränken, Wäscherei, Anrufe, Internet.
<G-vec00485-002-s139><call.anrufen><en> The module makes a GSM call or send an SMS (text) to each configured user number.
<G-vec00485-002-s139><call.anrufen><de> Das Modul macht GSM Anrufe und schickt SMS Nachrichten an jede eingestellte Benutzer-Telefonnummer.
<G-vec00485-002-s140><call.anrufen><en> Moreover, the call and demands of the Spirit resound in the very events of history, and so the Church can also be guided to a more profound understanding of the inexhaustible mystery of marriage and the family by the circumstances, the questions and the anxieties and hopes of the young people, married couples and parents of today.[9]
<G-vec00485-002-s140><call.anrufen><de> Und nicht nur das: Die Forderungen und Anrufe des göttlichen Geistes sprechen auch aus den Ereignissen der Geschichte, weshalb die Kirche auch durch die Situationen, Fragen, Ängste und Hoffnungen der Jugendlichen, der Eheleute und der Eltern von heute zu einer tieferen Kenntnis des unerschöpflichen Mysteriums der Ehe und Familie geführt werden kann (Vgl.
<G-vec00485-002-s141><call.anrufen><en> Operators accept the call in your name, take down caller information, then pass it to your dealership the next working day for processing.
<G-vec00485-002-s141><call.anrufen><de> Die Anrufe werden in Ihrem Namen angenommen, die Daten des Anrufers notiert und am nächsten Arbeitstag zur Bearbeitung in Ihr Autohaus weitergeleitet.
<G-vec00485-002-s142><call.anrufen><en> Select Menu > Settings > Call and from the following options: ● Call divert — to divert your incoming calls (network service).
<G-vec00485-002-s142><call.anrufen><de> Anrufen Wählen Sie Menü > Einstellungen > Anrufe und eine der folgenden Optionen: ● Rufumleitung — Zum Umleiten von Anrufen (Netzdienst).
<G-vec00485-002-s143><call.anrufen><en> There are many variants of settings: you can answer the incoming call shaking your smartphone or taking it to your ear, you can finish the conversation turning your device and others. Game features:
<G-vec00485-002-s143><call.anrufen><de> Es gibt viele Anpassungsmöglichkeiten, du kannst zum Beispiel Anrufe annehmen, indem du dein Smartphone schüttelst oder es zum Ohr bewegst, Auflegen kannst du, indem du dein Telefon mit dem Bildschirm auf den Tisch legst.
<G-vec00485-002-s144><call.anrufen><en> Settings for incoming phone call, email, and other notifications and for smartphone remaining battery notifications can be configured.
<G-vec00485-002-s144><call.anrufen><de> Einstellungen für eingehende Anrufe, E-Mails und andere Benachrichtigungen sowie für Hinweise über den Smartphone-Akkustand können konfiguriert werden.
<G-vec00485-002-s145><call.anrufen><en> Unwanted call blocking is a feature that helps block your Skype Number from receiving unwanted spam calls.
<G-vec00485-002-s145><call.anrufen><de> Das Blockieren unerwünschter Anrufe ist eine Funktion, mit dem Sie verhindern, dass Ihre Skype-Rufnummer unerwünschte Spam-Anrufe empfängt.
<G-vec00485-002-s146><call.anrufen><en> *Using Bixby may be limited under certain situations including without limitation during media (Video/Game/Voice) recording, during call (including outgoing call), Maximum power saving mode, Emergency mode, Kids Mode, and MirrorLink™.
<G-vec00485-002-s146><call.anrufen><de> ** Bixby kann unter bestimmten Bedingungen nur eingeschränkt nutzbar sein, zum Beispiel bei Medienaufnahmen (Video/Spiele/Sprache), Telefonaten (inklusive Anrufe), im maximalen Stromsparmodus, Notfallmodus, Kids Mode und bei MirrorLink™.
<G-vec00485-002-s147><call.anrufen><en> You also agree to not offer or use the Services as a service bureau by which the Services can be accessed by third parties or by which information produced pursuant to the Service is sold or given to third parties via pay per call or any other such arrangements whatsoever.
<G-vec00485-002-s147><call.anrufen><de> Ferner verpflichten Benutzer sich, die Dienstleistungen nicht als ein Serviceunternehmen anzubieten oder zu benutzen, über welches Dritte auf die Dienstleistungen zugreifen können oder die durch die Dienstleistungen erzeugten Informationen durch gebührenpflichtige Anrufe oder vergleichbare Service an Dritte verkauft oder weiter geleitet werden.
<G-vec00485-002-s148><call.anrufen><en> Cordless phone with answer machine With a digital answering machine, you'll never miss a call or message.
<G-vec00485-002-s148><call.anrufen><de> Schnurlostelefon mit Anrufbeantworter Der digitale Anrufbeantworter speichert zuverlässig alle Anrufe und Nachrichten.
<G-vec00485-002-s149><call.anrufen><en> “Placing a call is one of the most intuitive actions a consumer can take on their mobile phone, and calls are proving to be a very effective way to monetize mobile advertising, especially in service-based verticals.”
<G-vec00485-002-s149><call.anrufen><de> Anrufe haben sich außerdem als einer der effektivsten Wege erwiesen, mobile Werbung zu monetarisieren – insbesondere im Dienstleistersektor.“ Es hat sich gezeigt, dass besonders Unternehmen in der Service-Branche erfolgreich mit mobilem Click-to-Call arbeiten.
<G-vec00485-002-s150><call.anrufen><en> Tap the channel or direct message name to open the channel or conversation info, and choose Start a call.
<G-vec00485-002-s150><call.anrufen><de> Anrufe starten Tippe auf den Namen des Channels oder der Direktnachricht, um die Informationen für den Channel oder die Unterhaltung zu öffnen.
<G-vec00485-002-s151><call.anrufen><en> The call is coming to you company no matter if the caller originates in your geographical location or abroad.
<G-vec00485-002-s151><call.anrufen><de> Die Anrufe werden direkt zu Ihnen geleitet, egal ob der Anrufer im Inland oder im Ausland (mit Ländervorwahl) sitzt.
<G-vec00485-002-s266><call.aufrufen><en> Nothing, however, stopped him from continuing to call for Egyptians to continue their protests.
<G-vec00485-002-s266><call.aufrufen><de> Nichts hat ihn jedoch davon abgehalten, die Ägypter dazu aufzurufen mit ihren Protesten fortzufahren.
<G-vec00485-002-s267><call.aufrufen><en> Of course, our example program is rather abstract, as it does almost nothing but call the methods.
<G-vec00485-002-s267><call.aufrufen><de> Dieses Beispielprogramm ist eher theoretischer Natur, da das Programm so gut wie nichts anderes macht, als die Methoden aufzurufen.
<G-vec00485-002-s268><call.aufrufen><en> The aims of Faith and Order to “proclaim the oneness of the church of Jesus Christ and to call the churches to the goal of visible unity in one faith and one eucharistic fellowship” (By-laws of Faith and Order, 3.1) is lived out in particular way in the divided churches of South Africa today.
<G-vec00485-002-s268><call.aufrufen><de> Das Ziel von Glauben und Kirchenverfassung, „die Einheit der Kirche Jesu Christi zu verkündigen und die Kirchen aufzurufen zu dem Ziel der sichtbaren Einheit in einem Glauben und einer eucharistischen Gemeinschaft“ (Satzung von Glauben und Kirchenverfassung 3.1), wird unter den getrennten Kirchen im heutigen Südafrika in einer für sie besonderen Weise umgesetzt.
<G-vec00485-002-s269><call.aufrufen><en> In order to call up a favorite, click on in the tab bar.
<G-vec00485-002-s269><call.aufrufen><de> Um einen Favoriten aufzurufen, klicken Sie in der Tab Bar auf .
<G-vec00485-002-s271><call.aufrufen><en> By the way, the Nazis put this message into circulation to call for the defence of areas that they had occupied during the Second World War.
<G-vec00485-002-s271><call.aufrufen><de> Übrigens ist das ein Begriff, den die Nazis in die Welt gesetzt haben, um während des Zweiten Weltkriegs zur Verteidigung der von ihnen besetzten Gebiete aufzurufen.
<G-vec00485-002-s272><call.aufrufen><en> ‘In other words, now’s not the time to call people into the streets,’ wrote Parker of Navalny’s approach.
<G-vec00485-002-s272><call.aufrufen><de> „Jetzt ist, anders gesagt, nicht die Zeit, die Leute aufzurufen, auf die Straße zu gehen“, charakterisierte Parker Nawalnys Herangehensweise.
<G-vec00485-002-s274><call.aufrufen><en> Use the init method, with appropriate arguments, to call an instance of the class.
<G-vec00485-002-s274><call.aufrufen><de> Verwenden Sie die Methode init mit den geeigneten Argumenten, um eine Instanz der Klasse aufzurufen.
<G-vec00485-002-s275><call.aufrufen><en> Choose the appropriate key combo to activate the menu bar and call on apps without taking your hands off the keyboard.
<G-vec00485-002-s275><call.aufrufen><de> Wähle die entsprechende Tastaturkombination, um die Menüleiste zu aktivieren und Apps aufzurufen, ohne deine Hände von der Tastatur zu nehmen.
<G-vec00485-002-s276><call.aufrufen><en> It is possible to call up these pictures and evaluate/analyse them during subsequent maintenance and service visits.
<G-vec00485-002-s276><call.aufrufen><de> Bei späteren Wartungs- und Serviceeinsätzen ist es möglich, diese Bilder aufzurufen und zu bewerten/analysieren.
<G-vec00485-002-s277><call.aufrufen><en> It is your task, by your words and your witness of life, to call people to find Christ in the power of the Spirit and to strengthen them in the living faith.
<G-vec00485-002-s277><call.aufrufen><de> Es ist eure Aufgabe, durch das Wort und durch das Zeugnis eures Lebens die Menschen aufzurufen, Christus in der Kraft des Heiligen Geistes zu entdecken, und sie im lebendigen Glauben zu bestärken.
<G-vec00485-002-s278><call.aufrufen><en> That's not what we're here for. We are here to call for an end to the persecution and to stop the CCP’s atrocities of organ harvesting from living Falun Gong practitioners.”
<G-vec00485-002-s278><call.aufrufen><de> Wir sind hier, um für ein Ende der Verfolgung aufzurufen und die Gräueltaten der KPCh, den Organraub an lebenden Falun Gong-Praktizierenden zu stoppen.“ Danach unterschrieb die ganze Familie die Petition.
<G-vec00485-002-s279><call.aufrufen><en> Falun Gong practitioners continued to peacefully call for an end to human rights violations by the CCP.
<G-vec00485-002-s279><call.aufrufen><de> Die Falun Gong-Praktizierenden würden fortfahren, friedlich für ein Ende der Menschenrechtsverletzungen durch die KPCh aufzurufen.
<G-vec00485-002-s280><call.aufrufen><en> President Xi Jinping is taking on the old leader and his cronies for corruption, and Falun Gong practitioners are using this chance to call for Jiang to be brought to justice, and an end to the decades-long persecution against them.
<G-vec00485-002-s280><call.aufrufen><de> Präsident Xi Jinping verfolgt den alten Führer und seine Kumpane wegen Korruption, und Falun Gong-Praktizierende nutzen diese Chance, um dazu aufzurufen, Jiang vor Gericht zu stellen und die jahrzehntelange Verfolgung gegen sie zu beenden.
<G-vec00485-002-s281><call.aufrufen><en> Tried to call a removed routine.
<G-vec00485-002-s281><call.aufrufen><de> Versuchte eine Routine aufzurufen, die entfernt wurde.
<G-vec00485-002-s282><call.aufrufen><en> After selecting the order volume, click on the Take profit / Stop loss line to call the cells to set the stop loss and take profit.
<G-vec00485-002-s282><call.aufrufen><de> Klicken Sie nach Auswahl des Auftragsvolumens auf die Zeile Take Profit / Stop Loss, um die Zellen aufzurufen, in denen der Stop Loss und der Take Profit festgelegt werden.
<G-vec00485-002-s283><call.aufrufen><en> 3 Press the [I] (ASSIGN) button to call up the PARAMETER ASSIGN window.
<G-vec00485-002-s283><call.aufrufen><de> Drücken Sie eine der Tasten [A] – [J], um das gewünschte Untermenü aufzurufen.
<G-vec00485-002-s284><call.aufrufen><en> Actually – November 2013 – it is possible to call the old Console via „Dismiss“.
<G-vec00485-002-s284><call.aufrufen><de> Noch – Stand November 2013 – ist es jedoch möglich, per „Dismiss“ die alte Console aufzurufen.
<G-vec00485-002-s323><call.bezeichnen><en> Bahlsen: You could call him that.
<G-vec00485-002-s323><call.bezeichnen><de> Bahlsen: So könnte man ihn bezeichnen.
<G-vec00485-002-s324><call.bezeichnen><en> It is therefore incomprehensible that the guests call me the house as not clean.
<G-vec00485-002-s324><call.bezeichnen><de> Es ist mir daher unverständlich das die Gäste das Haus als nicht sauber bezeichnen.
<G-vec00485-002-s325><call.bezeichnen><en> Because there are already four of those restaurants, so I guess you can call it a chain.
<G-vec00485-002-s325><call.bezeichnen><de> Weil es mittlerweile bereits vier Ishins gibt, von daher kann man es wohl getrost als Ladenkette bezeichnen.
<G-vec00485-002-s326><call.bezeichnen><en> External creation as well as quotation from the Bible urged to call this bell "Christ's bell".
<G-vec00485-002-s326><call.bezeichnen><de> Sowohl äußere Gestaltung als auch Bibelwort legten nahe, diese Glocke als "Christusglocke" zu bezeichnen.
<G-vec00485-002-s327><call.bezeichnen><en> This positive confirmation of aesthetic interventions was the motivation to examine current trends more closely and to carry out an analysis based on historical developments, which, in our opinion, must necessarily lead to a changed philosophy of aesthetic medicine, which we would like to call Compositional Aesthetics.
<G-vec00485-002-s327><call.bezeichnen><de> Diese positive Bestätigung ästhetischer Interventionen war Motivation, die aktuellen Trends genauer zu untersuchen und eine Analyse auf Basis der historischen Entwicklung durchzuführen, die notwendigerweise unserer Auffassung nach zu einer veränderten Philosophie der ästhetischen Medizin führen muss, die wir mit dem Begriff Kompositorische Ästhetik bezeichnen wollen.
<G-vec00485-002-s328><call.bezeichnen><en> Thus the Jews call God the Father, and in Christianity God has even put forth a human Son.
<G-vec00485-002-s328><call.bezeichnen><de> Entsprechend bezeichnen die Juden Gott als Vater, im Christentum hat Gott sogar einen menschlichen Sohn gezeugt.
<G-vec00485-002-s329><call.bezeichnen><en> Many scientist have described what we call the information field as a "field of mental and physical interchange".
<G-vec00485-002-s329><call.bezeichnen><de> Viele Wissenschaftler beschrieben bereits den Bereich, den wir als Informationsfeld bezeichnen, als ein Feld der mentalen und physischen Wechselwirkungen.
<G-vec00485-002-s330><call.bezeichnen><en> As boxer engine you can not call it well, because opposite cylinders run on a connecting rod pin and thus always run the same movement.
<G-vec00485-002-s330><call.bezeichnen><de> Als Boxermotor kann man ihn wohl nicht bezeichnen, weil gegenüberliegende Zylinder auf einem Pleuelzapfen laufen und damit immer die gleiche Bewegung ausführen.
<G-vec00485-002-s331><call.bezeichnen><en> Share On pinterest Pin Wrestling might be fake, but at least it has the chops to call it a squared circle.
<G-vec00485-002-s331><call.bezeichnen><de> Beim Wrestling mag zwar vieles Fake sein, aber immerhin haben die genügend Eier, ihren Ring als quadratischen Kreis zu bezeichnen.
<G-vec00485-002-s332><call.bezeichnen><en> I would call our group “blue helmets” as an analogy to UN peacekeepers.
<G-vec00485-002-s332><call.bezeichnen><de> Ich würde unsere ganze Gruppe als „Blauhelme“ bezeichnen, in Analogie zu den Friedensstiftern der UNO.
<G-vec00485-002-s333><call.bezeichnen><en> I am now able to call myself bilingual, as I use both English and German in my daily life.
<G-vec00485-002-s333><call.bezeichnen><de> Nun kann ich mich selbst als bilingual bezeichnen, denn in meinem Alltag gebrauche ich sowohl Englisch als auch Deutsch.
<G-vec00485-002-s334><call.bezeichnen><en> We always call them LR44 on Lovehoney.com
<G-vec00485-002-s334><call.bezeichnen><de> Wir bezeichnen sie stets als LR44-Batterien.
<G-vec00485-002-s335><call.bezeichnen><en> You can call Him a hippie, all right!
<G-vec00485-002-s335><call.bezeichnen><de> Man könnte Ihn als Hippie bezeichnen.
<G-vec00485-002-s336><call.bezeichnen><en> It also extends to those who call themselves "healers" in this room, for they have the same task as the channeller or the teacher, and that is translating a perceptual, metaphörical message into something that is 3D and practical.
<G-vec00485-002-s336><call.bezeichnen><de> Es schließt auch diejenigen im Raum ein, die sich als Heiler bezeichnen, denn sie haben die gleiche Aufgabe wie die Channeler oder Lehrer, nämlich, eine wahrgenommene metaphorische Botschaft in etwas zu übersetzen, was 3D und praktisch ist.
<G-vec00485-002-s337><call.bezeichnen><en> With our nearly 30 years of experience and extensive series of delivered projects, we can rightly call ourselves solid surface experts.
<G-vec00485-002-s337><call.bezeichnen><de> Mit unseren fast 30 Jahren Erfahrung und bereits realisierte, erfolgreiche Projekte können wir uns mit Recht als Solid Surface-Experten bezeichnen.
<G-vec00485-002-s338><call.bezeichnen><en> If the score of any method is above a certain limit, then we call that moment “abnormal” according to that method.
<G-vec00485-002-s338><call.bezeichnen><de> Wenn der Wert einer dieser Methoden einen bestimmten Grenzwert überschreitet, bezeichnen wir diesen Moment als „abnormal“ entsprechend der jeweiligen Methode.
<G-vec00485-002-s339><call.bezeichnen><en> The shape of the main island of Taiwan is similar to a sweet potato seen in a south-to-north direction, and therefore, Taiwanese (especially Min Nan speakers) often call themselves "children of the Sweet Potato.
<G-vec00485-002-s339><call.bezeichnen><de> Charakteristisch für Taiwan ist die auf der Landkarte eine Süßkartoffel ähnelnde Form, aufgrund deren sich die Min Nan Ureinwohner auch als „Kinder der Süßkartoffel“ bezeichnen.
<G-vec00485-002-s340><call.bezeichnen><en> What we call "evil spirits" are Satan and all the evil spirit men on his side.
<G-vec00485-002-s340><call.bezeichnen><de> Mit dem Ausdruck "böse Geister" bezeichnen wir Satan und all seine bösen Geister.
<G-vec00485-002-s341><call.bezeichnen><en> As a top place I would not call this place.
<G-vec00485-002-s341><call.bezeichnen><de> Als Top-Platz würde ich diesen Platz nicht bezeichnen.
<G-vec00485-002-s380><call.erfordern><en> The challenges of international competition and the EC internal market call for an increased effort to structure the world of work more humanely.
<G-vec00485-002-s380><call.erfordern><de> Die Herausforderungen des internationalen Wettbewerbs und des EG-Binnenmarktes erfordern vermehrte Anstrengungen für eine menschengerechtere Strukturierung der Arbeitswelt.
<G-vec00485-002-s381><call.erfordern><en> Modern printers and smart devices call for a multi-layered approach to security that spans intrusion prevention, device detection, document and data detection and external partnerships with security specialists.
<G-vec00485-002-s381><call.erfordern><de> Moderne Drucker und intelligente Geräte erfordern einen mehrschichtigen Sicherheitsansatz, der die Bereiche Angriffsverhinderung, Geräteerkennung sowie Dokumenten- und Datenschutz abdeckt und Partnerschaften mit externen Anbietern für Datensicherheit beinhaltet.
<G-vec00485-002-s382><call.erfordern><en> Variable inlet guide vanes (IGV) ensure optimal flow rates, especially when changing on-site conditions call for immediate adjustments.
<G-vec00485-002-s382><call.erfordern><de> Verstellbare Eintrittsleitschaufeln (IGVs, Inlet Guide Vanes) gewährleisten optimale Flussraten, insbesondere, wenn sich wandelnde Bedingungen vor Ort eine sofortige Anpassung erfordern.
<G-vec00485-002-s383><call.erfordern><en> Special working environments call for special solutions.
<G-vec00485-002-s383><call.erfordern><de> Besondere Arbeitsumgebungen erfordern besondere Lösungen.
<G-vec00485-002-s384><call.erfordern><en> Trial and error, early corrections, and brand-new approaches call for a creative way of working toward solutions.
<G-vec00485-002-s384><call.erfordern><de> Versuch und Irrtum, frühe Korrekturen und völlig neue Ansätze erfordern eine kreative Annäherung an die Lösungen.
<G-vec00485-002-s385><call.erfordern><en> Rough, sloping terrain and cramped working conditions call for robust and reliable forestry machines.
<G-vec00485-002-s385><call.erfordern><de> Raues, abschüssiges Gelände und beengte Arbeitsbedingungen erfordern robuste und zuverlässige Forstmaschinen.
<G-vec00485-002-s386><call.erfordern><en> Such deep dives are, however, quite strenuous and usually call for some resting time at the surface which was observed in some of the pilot whales this morning.
<G-vec00485-002-s386><call.erfordern><de> Solche tiefen Tauchgänge sind jedoch ziemlich anstrengend und erfordern normalerweise eine gewisse Ruhezeit an der Wasseroberfläche, die bei einigen Pilotwale während der heutigen Nachmittagstour beobachtet werden konnte.
<G-vec00485-002-s387><call.erfordern><en> From ultrasonic welding, gluing or riveting, whether force, current or position measurement: custom drives call for customized solutions.
<G-vec00485-002-s387><call.erfordern><de> Ob Ultraschall-Schweißen, Kleben oder Vernieten, ob Kraft-, Strom- oder Positionsmessung: Individuelle Antriebe erfordern individuelle Lösungen.
<G-vec00485-002-s388><call.erfordern><en> Each situation and each woman may call for something different.
<G-vec00485-002-s388><call.erfordern><de> Jede Situation und jede Frau kann etwas anderes erfordern.
<G-vec00485-002-s389><call.erfordern><en> Specifically, they call for a lifestyle marked by sobriety and solidarity, with new rules and forms of engagement, one which focuses confidently and courageously on strategies that actually work, while decisively rejecting those that have failed.
<G-vec00485-002-s389><call.erfordern><de> Sie erfordern insbesondere eine durch Maßhalten und Solidarität gekennzeichnete Lebensweise mit neuen Regeln und Formen des Einsatzes, die zuversichtlich und mutig die positiven Erfahrungen aufgreifen und die negativen entschieden zurückweisen.
<G-vec00485-002-s390><call.erfordern><en> Highly complex food products like fruit juices may – depending on the performance requirements – call for the use of the entire spectrum of analytical methods.
<G-vec00485-002-s390><call.erfordern><de> Fruchtsäfte als hochkomplexe Lebensmittel erfordern je nach Aufgabenstellung das gesamte Spektrum der analytischen Methoden.
<G-vec00485-002-s391><call.erfordern><en> On the mountain, extreme conditions call for the right balance between weight and functionality.
<G-vec00485-002-s391><call.erfordern><de> Die extremen Bedingungen am Berg erfordern eine ausgewogene Balance zwischen Gewicht und Funktionalität.
<G-vec00485-002-s392><call.erfordern><en> Ever-increasing demands regarding the cleanliness of component surfaces call for increasingly effective cleaning methods.
<G-vec00485-002-s392><call.erfordern><de> Immer höhere Anforderungen an die Sauberkeit von Bauteiloberflächen erfordern immer effektivere Reinigungsverfahren.
<G-vec00485-002-s393><call.erfordern><en> Industrial revolutions always call for investments to implement structural change – and Industry 4.0 is no exception.
<G-vec00485-002-s393><call.erfordern><de> Industrielle Revolutionen erfordern Investitionen, ohne die nun mal kein Strukturwandel möglich ist – da macht auch die Industrie 4.0 keine Ausnahme.
<G-vec00485-002-s394><call.erfordern><en> Constantly rising competition and cost pressure as well as decreasing margins call for flexibility and constant adaptability.
<G-vec00485-002-s394><call.erfordern><de> Ständig steigender Wettbewerbs- und Kostendruck und sinkende Margen erfordern Flexibilität und stetige Anpassungen.
<G-vec00485-002-s395><call.erfordern><en> Pressing conflicts, risks and crisis may call for rapid, decisive actions.
<G-vec00485-002-s395><call.erfordern><de> Konflikte, dringende Risiken und Krisen erfordern entschlossenes und rasches Handeln.
<G-vec00485-002-s396><call.erfordern><en> Granting rights of use not only needs to be taken into consideration for traditional licensing agreements, but also in a variety of other types of agreement: creating websites, drafting ASP agreements or transferring databases all call for copyright provisions which may be critical to the quality of the overall contractual framework.
<G-vec00485-002-s396><call.erfordern><de> Die Einräumung von Nutzungsrechten ist nicht nur bei klassischen Lizenzverträgen zu berücksichtigen, sondern auch bei einer Reihe anderer Vereinbarungen: Die Erstellung von Webseiten, ASP-Verträge oder die Übernahme von Datenbanken erfordern urheberrechtliche Regelungen, die über die Qualität des gesamten Vertragswerkes entscheiden können.
<G-vec00485-002-s397><call.erfordern><en> The great challenges of our time call upon us all to stand together and to commit to continual improvement.
<G-vec00485-002-s397><call.erfordern><de> Klimawandel, knappe Ressourcen und globale Märkte – die großen Herausforderungen unserer Zeit erfordern Zusammenhalt und den Willen zur stetigen Verbesserung.
<G-vec00485-002-s398><call.erfordern><en> Individual needs call for individual solutions.
<G-vec00485-002-s398><call.erfordern><de> Individuelle Bedürfnisse erfordern individuelle Lösungen.
<G-vec00485-002-s399><call.fordern><en> To call for the use of arms under the guise of democracy is in itself impermissible, but to speak of Germany as a democracy state, which in this way could somehow repair its damaged image, that is defamatory, and the question must be asked of why Germany could be so bent on playing at war again, instead of eschewing it for all time.
<G-vec00485-002-s399><call.fordern><de> Waffeneinsätze unter dem Deckmantel der Demokratie zu fordern ist schon unzulässig, aber Deutschland als demokratischen Staat anzupreisen, der dadurch eine Art Imageschaden wieder gut machen könnte, das ist ehrenrührig und es muss die Frage gestellt werden, warum Deutschland so versessen darauf sein könnte, wieder Krieg zu spielen, anstatt dies für alle Zeiten bleiben zu lassen.
<G-vec00485-002-s400><call.fordern><en> In an article in Spiegel Online, Andre Wilkens and Jakob von Weizsäcker call for a publicly financed media channel that is produced in and for Europe.1 It is their hope that the project will make an important contribution to European democracy.
<G-vec00485-002-s400><call.fordern><de> In ihrem Gastbeitrag für „Spiegel Online“ fordern die Autoren Andre Wilkens und Jakob von Weizsäcker einen öffentlich-rechtlichen Medienkanal aus und für Europa.1 Von diesem erhoffen sie sich einen wichtigen Beitrag zur Rettung der europäischen Demokratie.
<G-vec00485-002-s401><call.fordern><en> Meanwhile, we call on the Council of the EU to take a final decision on further sanctions against the Russian Federation only after thoroughly evaluating the progress towards the political solution.
<G-vec00485-002-s401><call.fordern><de> In der Zwischenzeit fordern wir den Rat der Europäischen Union auf, einen endgültigen Beschluss über weitere Sanktionen gegen Russland erst nach einer gründlichen Bewertung des Fortschritts auf dem Weg zur politischen Lösung zu fassen.
<G-vec00485-002-s402><call.fordern><en> About 60 protesters marched to the local police headquarters to support the arrested reclaimers and call for their release.
<G-vec00485-002-s402><call.fordern><de> Etwa 60 DemonstrantInnen marschierten zur Polizeistation, um die Verhafteten zu unterstützen und ihre Freilassung zu fordern.
<G-vec00485-002-s403><call.fordern><en> Younger Central Committee members call on the "old comrades" to leave the CC voluntarily in the face of the demands of the rank and file.
<G-vec00485-002-s403><call.fordern><de> Jüngere ZK-Mitglieder fordern die „alten Genossen" auf, freiwillig aus dem ZK zurückzutreten, weil dies die Parteibasis verlange.
<G-vec00485-002-s404><call.fordern><en> Their feeling that they are under threat is fuelled above all by the fact that hard-liners in Tehran time and again openly call for the destruction of Israel while Hezbollah’s rockets are, at the same time, stationed on Israel’s northern border.
<G-vec00485-002-s404><call.fordern><de> Das Gefühl der Bedrohung wird vor allem dadurch genährt, dass immer wieder Hardliner in Teheran offen die Vernichtung Israels fordern, während gleichzeitig an Israels Nordgrenze die Raketen der Hisbollah stehen.
<G-vec00485-002-s405><call.fordern><en> In accordance with the FBE previous and constant position we call upon an end to arbitrary arrest, detention, and prosecution of judges, lawyers and journalists.
<G-vec00485-002-s405><call.fordern><de> Entsprechend dem bisherigen und festen Standpunkt des FBE fordern wir ein Ende der willkürlichen Festnahme, Inhaftierung und Verfolgung von Richtern, Anwälten und Journalisten.
<G-vec00485-002-s406><call.fordern><en> We call for EU citizens to have the choice to continue to buy healthy bulbs in the future.
<G-vec00485-002-s406><call.fordern><de> Wir fordern für alle europäischen Bürger die Freiheit, auch in Zukunft gesunde Leuchtmittel kaufen zu können.
<G-vec00485-002-s407><call.fordern><en> We also call on all armed groups to put an immediate end to violence.
<G-vec00485-002-s407><call.fordern><de> Wir fordern außerdem alle bewaffneten Gruppierungen auf, die Gewalt unverzüglich zu beenden.
<G-vec00485-002-s408><call.fordern><en> Organic Farming News European experts call to convert organic agriculture in the model for European agriculture.
<G-vec00485-002-s408><call.fordern><de> Landwirtschaft News Europäische Experten fordern die Umstellung auf den ökologischen Landbau in dem Modell für die europäische Landwirtschaft.
<G-vec00485-002-s409><call.fordern><en> We call for an independent review of all existing surveillance powers as to their effectiveness, proportionality, costs, harmful side-effects and alternative solutions.
<G-vec00485-002-s409><call.fordern><de> Wir fordern eine unabhängige Überprüfung aller bestehenden Überwachungsbefugnisse in Hinblick auf ihre Wirksamkeit, Verhältnismäßigkeit, Kosten, schädliche Nebenwirkungen und Alternativen.
<G-vec00485-002-s410><call.fordern><en> We call on Europe to push for the conversion of the INF Treaty into a multilateral Treaty in order to include other nuclear states, like China.
<G-vec00485-002-s410><call.fordern><de> Wir fordern die EU auf, die Umwandlung des INF-Vertrags in einen multilateralen Vertrag voranzutreiben, um andere Nuklearstaaten wie China einzubeziehen.
<G-vec00485-002-s411><call.fordern><en> The stream that meanders through the grounds, the trickily undulating greens well protected by bunkers, and the ancient tree population including some majestic solitary giants, call for accurate play on this special 9-hole course.
<G-vec00485-002-s411><call.fordern><de> Der sich durch das Gelände ziehende Bach, die durch Bunker gut verteidigten und anspruchsvoll ondulierten Grüns sowie der alte Baumbestand mit großen Solitären fordern ein akkurates Spiel auf diesem besonderen 9-Loch-Platz.
<G-vec00485-002-s412><call.fordern><en> She told the audience that the reason she came to South Africa was to call for a stop to the persecution of Falun Dafa.
<G-vec00485-002-s412><call.fordern><de> Sie erzählte den Zuschauern warum sie nach Südafrika gekommen war, nämlich um ein Ende der Verfolgung von Falun Gong zu fordern.
<G-vec00485-002-s413><call.fordern><en> When “masters” control servants, or when capitalists control workers, this is considered to be in the nature of things; the private life of the working and exploited people is not considered inviolable. The bourgeoisie are entitled to call to account any "wage slave" and at any time to make public his income and expenditure.
<G-vec00485-002-s413><call.fordern><de> Wenn die „Herrschaften“ die Dienstboten kontrollieren, wenn die Kapitalisten die Arbeiter kontrollieren, dann hält man das für ganz in Ordnung, das Privatleben des Werktätigen und Ausgebeuteten gilt nicht für unantastbar, die Bourgeoisie ist berechtigt, von jedem „Lohnsklaven“ Rechenschaft zu fordern, seine Einnahmen und Ausgaben jederzeit an die Öffentlichkeit zu zerren.
<G-vec00485-002-s414><call.fordern><en> We need a more creative and coordinated response from the EU and its Member States, and we call for a European strategy on demographic change and for more familyand child-friendly environments.
<G-vec00485-002-s414><call.fordern><de> Wir benötigen eine kreativere und koordiniertere Antwort der EU und ihrer Mitgliedstaaten, und wir fordern eine europäische Strategie zum demografischen Wandel sowie zu familien- und kinderfreundlichen Umgebungen.
<G-vec00485-002-s415><call.fordern><en> The artists call for the resignation of the Senator of Culture, because a competent Senator for Cultural Affairs would do something intelligent for the city of Berlin with the keys of the house in his/her hands.
<G-vec00485-002-s415><call.fordern><de> Die Künstler fordern den Rücktritt des Kultursenators, da ein kompetenter Senator für kulturelle Angelegenheiten mit dem ihm übergebenen Tacheles Schlüssel etwas Intelligentes für die Stadt Berlin bewirken könnte.
<G-vec00485-002-s416><call.fordern><en> We call on the Russian Federation to immediately cease its attacks on the Syrian opposition and civilians and to focus its efforts on fighting ISIL.
<G-vec00485-002-s416><call.fordern><de> Wir fordern die Russische Föderation auf, ihre Angriffe auf die syrische Opposition und die Zivilbevölkerung unverzüglich zu stoppen und sich auf die Bekämpfung von ISIS zu konzentrieren.
<G-vec00485-002-s417><call.fordern><en> However, the finite nature of fossil fuels, climate change and smog call for alternative solutions from the automotive industry, such as the electric drive.
<G-vec00485-002-s417><call.fordern><de> Die Endlichkeit fossiler Kraftstoffe, der Klimawand und Smog fordern von der Automobilindustrie jedoch alternative Lösungen wie den Elektroantrieb.
<G-vec00485-002-s494><call.nennen><en> 13 “You call me ‘Teacher’ and ‘Lord,’ and rightly so, for that is what I am.
<G-vec00485-002-s494><call.nennen><de> Ihr nennt mich Meister und Herr und sagt es mit Recht, denn ich bin’s auch.
<G-vec00485-002-s495><call.nennen><en> Cheap flights from Seville to Rio De Janeiro from 502 € on Iberia From the moment you enter Rio de Janeiro, you will understand why they call it the ‘Marvellous City’.
<G-vec00485-002-s495><call.nennen><de> Billige Tickets für Iberia Flüge von Berlin nach Rio de Janeiro ab 638 € bei Iberia Vom Zeitpunkt an, in dem Sie Rio de Janeiro betreten, werden Sie verstehen, warum man sie „die wundervolle Stadt“ nennt.
<G-vec00485-002-s496><call.nennen><en> Once he says his sounding name at the end of the phone call, they put his Hungarian language to a test.
<G-vec00485-002-s496><call.nennen><de> Als er gegen Ende des Telefonats seinen klingenden Namen nennt, stellt man gleich sein Ungarisch auf eine Belastungsprobe.
<G-vec00485-002-s497><call.nennen><en> Let us take it from another aspect of what you call insects and bees.
<G-vec00485-002-s497><call.nennen><de> Lasst uns das unter einem anderen Aspekt sehen, von den Kreaturen, die ihr Insekten und Bienen nennt.
<G-vec00485-002-s498><call.nennen><en> You do not put your feet on the table, you do not burp while eating, and you do not call the twelve worst years in German history "bird shit."
<G-vec00485-002-s498><call.nennen><de> Man legt die Füße nicht auf den Tisch, man rülpst nicht beim Essen, und man nennt die 12 schlimmsten Jahre der deutschen Geschichte nicht einen „Vogelschiss“.
<G-vec00485-002-s499><call.nennen><en> The two of them then make up after he assures her that he will not leave her (although she continues to call him a liar).
<G-vec00485-002-s499><call.nennen><de> Die beiden von ihnen machen dann auf, nachdem er ihr versichert hat, dass er sie nicht verlassen wird (obwohl sie ihn weiterhin einen Lügner nennt).
<G-vec00485-002-s500><call.nennen><en> That would be exactly what we call diplomacy: the art of (secret) negotiation....
<G-vec00485-002-s500><call.nennen><de> Das wäre genau das, was man Diplomatie nennt: die Kunst des (geheimen) Verhandelns....
<G-vec00485-002-s501><call.nennen><en> Perhaps you already have a remedy that has helped you to heal the wounds quickly, and you know exactly what to call the pharmacist in the pharmacy.
<G-vec00485-002-s501><call.nennen><de> Vielleicht haben Sie bereits ein Mittel, das Ihnen geholfen hat, die Wunden schnell zu heilen, und Sie wissen genau, wie man den Apotheker in der Apotheke nennt.
<G-vec00485-002-s502><call.nennen><en> It is possible to go back into what you call your history and change or alter it.
<G-vec00485-002-s502><call.nennen><de> Es ist möglich, in das, was ihr eure Geschichte nennt, zurückzugehen und sie zu ändern oder umzugestalten.
<G-vec00485-002-s503><call.nennen><en> We wish you much Joy and Love as you "unfold" into the New Cycle which you call a New Year.
<G-vec00485-002-s503><call.nennen><de> Wir wünschen euch viel Freude und Liebe, wenn ihr euch in den Neuen Zyklus hinein „entfaltet“, den ihr das Neue Jahr nennt.
<G-vec00485-002-s504><call.nennen><en> When we talk about the first collective dimension, this is what you actually call God.
<G-vec00485-002-s504><call.nennen><de> Wenn wir über die erste kollektive Dimension sprechen, so ist dies das, was ihr Gott nennt.
<G-vec00485-002-s505><call.nennen><en> You call them Gods but... Kana yakulani atta'ama.
<G-vec00485-002-s505><call.nennen><de> Ihr nennt sie Götter, aber "Kana Yakulani Atta'ama".
<G-vec00485-002-s506><call.nennen><en> I also know that many persons, including nuns from various monasteries of contemplative life, "mystical antennae", as you call them, accompany you and support you with their prayers, while the sick, hospital patients and prisoners offer up their sufferings for your apostolate.
<G-vec00485-002-s506><call.nennen><de> Ich weiß, daß euch viele Personen, darunter Nonnen in verschiedenen Klöstern des kontemplativen Lebens, die ihr »mystische Antennen« nennt, durch ihr Gebet unterstützen, während Kranke, bettlägerige Patienten in Krankenhäusern sowie Gefangene ihr Leiden eurem Apostolat widmen.
<G-vec00485-002-s507><call.nennen><en> In the Basque country, they call it a transition stage, but 6 climbs were on the program on the 164 kilomters between Ataun and Villatuerta.
<G-vec00485-002-s507><call.nennen><de> Ausreissersieg durch Baskenland nennt man das eine Übergangsetappe, doch nicht weniger als 6 Bergwertungen standen auch heute auf den 164 Kilometern zwischen Ataun und Villatuerta auf dem Programm.
<G-vec00485-002-s508><call.nennen><en> In order to have a clear concept of this planetary body which you call Saturn, it is important to know what its actual name denotes: Earth Calmness, World Nothingdom. It is also absolutely necessary to learn about its natural sphere, its distance from the sun, its size, structure, its inhabitants as well as the inhabitants on the rings and moons, as well as its diverse vegetation in accordance with the conditions that prevail because of distinctly varying climates.
<G-vec00485-002-s508><call.nennen><de> Der Saturn Um sich von diesem Weltkörper, den ihr Saturn nennt – während sein eigentlicher Name soviel besagt wie: Erdruhe, Weltnichtstum – einen deutlichen Begriff zu machen, ist vor allem nötig, seine natürliche Sphäre, Entfernung von der Sonne, seine Größe wie auch die seiner Monde so genau wie nur immer eurer Fassungskraft möglich zu erkennen.
<G-vec00485-002-s509><call.nennen><en> Furthermore, you become aware of your own limits, in English, you call that ‘Humility’.
<G-vec00485-002-s509><call.nennen><de> Des Weiteres wirst du dir auch deiner eigenen Grenzen bewusst, im Englischen nennt man das ‚Humility‘.
<G-vec00485-002-s510><call.nennen><en> Indeed these occur through connectivity in the neural networks (plasmic filaments) of the Living Cosmos or gestalt energy you call God.
<G-vec00485-002-s510><call.nennen><de> In der Tat geschieht dies durch die Verbindungsfähigkeit in den neuronalen Netzwerken (plasmaartige Leuchtfäden) des lebendigen Kosmos oder der gestaltenden Energie, die ihr Gott nennt.
<G-vec00485-002-s511><call.nennen><en> As long as no one is in the way … or a wing is broken – or what would you call it?
<G-vec00485-002-s511><call.nennen><de> Das ist ein großer Spaß, wenn keiner im Wege steht … oder ein Flügel hinkt, oder wie man das nennt.
<G-vec00485-002-s512><call.nennen><en> In any case, Marlen was not a year old when Lore become pregnant again; so Cristina was what in show business you call the encore, the familiar song, saved for last and laid in a gently polished version at the feet of the breathless audience.
<G-vec00485-002-s512><call.nennen><de> Jedenfalls war Marlen noch kein Jahr alt, als Lore wieder schwanger war; Cristina wurde also das, was man im Showbusiness die Zugabe nennt, der vertraute Song, aufgespart, um ihn dem atemlosen Publikum in einer sanft polierten Variante zu Füßen zu legen.
<G-vec00485-002-s570><call.rufen><en> Guests arriving by public transport call the hotel from the PostBus terminal or the tourist office.
<G-vec00485-002-s570><call.rufen><de> Gäste, die mit öffentlichen Verkehrsmitteln anreisen, rufen das Hotel vom PostAuto-Terminal oder vom Tourismusbüro aus an.
<G-vec00485-002-s571><call.rufen><en> Alternatively, call +44870 400 9121 (not toll-free) or your country-specific number.
<G-vec00485-002-s571><call.rufen><de> Rufen Sie andernfalls +44870 400 9121 (gebührenpflichtig) oder Ihre länderspezifische Nummer an.
<G-vec00485-002-s572><call.rufen><en> For EVE Audio demos in USA please contact our distributor EVE Audio US or call +1 845 378 1189.
<G-vec00485-002-s572><call.rufen><de> Für eine Demo von EVE-Monitoren in den USA kontaktieren Sie bitte unseren Vertrieb EVE Audio US oder rufen an +1 845 378 1189.
<G-vec00485-002-s573><call.rufen><en> Every day, people call psychotherapists offices for help in a crisis.
<G-vec00485-002-s573><call.rufen><de> Jeden Tag rufen in den Psychotherapeutischen Praxen Menschen an, die Hilfe in einer Krise suchen.
<G-vec00485-002-s574><call.rufen><en> Melding: questions, comments or concerns, please call us.
<G-vec00485-002-s574><call.rufen><de> Wenn Sie Fragen, Anmerkungen oder Bedenken haben, rufen Sie uns bitte an.
<G-vec00485-002-s576><call.rufen><en> AGROSPOL, Malý you have any questions, comments or concerns, please call us.
<G-vec00485-002-s576><call.rufen><de> Schließen Wenn Sie Fragen, Anmerkungen oder Bedenken haben, rufen Sie uns bitte an.
<G-vec00485-002-s577><call.rufen><en> View them on the page or call one of our employees for further information. Suzanna Dee
<G-vec00485-002-s577><call.rufen><de> Sehen Sie sich diese auf der Seite an oder rufen Sie einen unserer Mitarbeiter für weitere Informationen an.
<G-vec00485-002-s578><call.rufen><en> If you are a dog groomer and would like more information about KW and are interested in testing our competitively priced quality products, please do not hesitate to call or write to us.
<G-vec00485-002-s578><call.rufen><de> Sind Sie Hundefriseur und daran interessiert, mehr über KW zu erfahren, und unsere hohe Qualität bei den Produkten zu wettbewerbsfähigen Preisen auszuprobieren – dann schreiben Sie uns oder rufen Sie uns an.
<G-vec00485-002-s579><call.rufen><en> Also, if you need to find the address of the person or on the phone to find someone by the name, then just immediately call the detective agency " Private detective Kharkiv", which carries out its activities in the city Pervomajskij .
<G-vec00485-002-s579><call.rufen><de> Auch, wenn Sie benötigen die Adresse der Person am Telefon zu wissen oder den Nachnamen, jemanden zu finden, rufen Sie einfach direkt an die Detektei "Kharkov Private Detective", die Pervomajskij im Gebiet der Stadt tätig ist.
<G-vec00485-002-s581><call.rufen><en> Procédure au retour Please call the staff of Park & Fly as soon as you have collected your luggage.
<G-vec00485-002-s581><call.rufen><de> Nach Ihrer Gepäckannahme, rufen Sie bitte die PMS Park & Fly Service Hotline an, um Ihre Ankunft zu bestätigen.
<G-vec00485-002-s582><call.rufen><en> If you need help, call 972-385-0100. Ribbon Text Our Company
<G-vec00485-002-s582><call.rufen><de> Wenn Sie Hilfe benötigen, rufen uns bitte an unter +31 (0)20 305 8620.
<G-vec00485-002-s583><call.rufen><en> Simply give our Managed Security team a call now and they will have your data safe in no time.
<G-vec00485-002-s583><call.rufen><de> Rufen Sie unser Managed Security-Team einfach an, damit es Ihre Daten im Handumdrehen schützt.
<G-vec00485-002-s584><call.rufen><en> Please give us a call or send an email.
<G-vec00485-002-s584><call.rufen><de> Bitte rufen Sie uns an oder schreiben Sie uns eine E-Mail.
<G-vec00485-002-s585><call.rufen><en> To book, we kindly ask you to call on +41 (0)91 996 21 55 between 8am and 10pm from Monday to Sunday.
<G-vec00485-002-s585><call.rufen><de> Um eine Reservierung vorzunehmen, rufen Sie bitte zwischen 08:00 und 22:00 Uhr, Montag bis Sonntag, unter +41 (91) 996 21 55 an.
<G-vec00485-002-s586><call.rufen><en> Quick question? Call KBC Live
<G-vec00485-002-s586><call.rufen><de> Rufen Sie KBC Live an, Tel.
<G-vec00485-002-s587><call.rufen><en> In other call centres the 'human' work plays a crucial role: people call because they want to talk (besides ordering stuff).
<G-vec00485-002-s587><call.rufen><de> Bei anderen Call Centern spielt die "menschliche" Arbeit eine zentrale Rolle: Die Leute rufen an, weil sie reden wollen (und nebenbei die Bestellung aufgeben).
<G-vec00485-002-s588><call.rufen><en> They call us frequently, knowing they can rely on a fast, knowledgeable response to their requests for information.
<G-vec00485-002-s588><call.rufen><de> Sie rufen uns häufig an und wissen, dass sie sich auf eine schnelle und kompetente Antwort auf ihre Fragen verlassen können.
<G-vec00485-002-s665><call.telefonieren><en> Whether you need to make a call while driving, require current traffic information, want to reach your destination using the navigation system or simply want to listen to your own music – your Golf SV provides various options for using modern technology in a convenient and uncomplicated way.
<G-vec00485-002-s665><call.telefonieren><de> Infotainment Ob Sie beim Fahren telefonieren müssen, aktuelle Verkehrsinformationen benötigen, per Navigation Ihr Ziel erreichen wollen oder einfach nur Ihre eigene Musik hören möchten – Ihr Golf Sportsvan bietet Ihnen diverse Möglichkeiten, moderne Technik bequem und unkompliziert zu nutzen.
<G-vec00485-002-s666><call.telefonieren><en> No, the man in the picture does not want to call, but checks with the help of the 'Internet of Things', if he has loaded all his tools and not has forgotten any at his former working place.
<G-vec00485-002-s666><call.telefonieren><de> Nein, der Mitarbeiter auf dem Bild will nicht telefonieren, sondern überprüft mit Hilfe des 'Internets der Dinge', ob er alle Werkzeuge eingeladen, also keins auf der Baustelle vergessen hat.
<G-vec00485-002-s667><call.telefonieren><en> 3 Keeping in touch 3 Keeping in touch Call in style Launching the Phone app Your ASUS Tablet’s Phone app offers you many ways to make a call.
<G-vec00485-002-s667><call.telefonieren><de> 3 In Kontakt bleiben In Verbindung bleiben 3 Stilvoll telefonieren Starten der Phone-App Die Telefon-App Ihres ASUS Tablets bietet Ihnen viele Möglichkeiten, einen Anruf abzusetzen.
<G-vec00485-002-s668><call.telefonieren><en> Employees can make a call or send an email or fax directly from SAP, Microsoft Dynamics & Co.
<G-vec00485-002-s668><call.telefonieren><de> Mitarbeiter können direkt aus SAP, Microsoft Dynamics & Co. telefonieren, eine Mail oder ein Fax versenden.
<G-vec00485-002-s669><call.telefonieren><en> If you have to make a phone call while travelling, be careful not to sit in the quiet section when booking your business trip.
<G-vec00485-002-s669><call.telefonieren><de> Wenn du während der Fahrt telefonieren musst, achte bei der Buchung der Geschäftsreise darauf, nicht im Ruheabteil zu sitzen.
<G-vec00485-002-s670><call.telefonieren><en> Until now, it simply wasn’t possible to listen to music, watch TV, or make a phone call with the vacuum cleaner on in the background.
<G-vec00485-002-s670><call.telefonieren><de> Bis jetzt war es schlicht und einfach nicht möglich, Musik zu hören, fernzusehen oder zu telefonieren, wenn ein Staubsauger im Hintergrund lief.
<G-vec00485-002-s671><call.telefonieren><en> Regardless of whether you use your cell phone to make a call in the morning, drive your electric car to work or boot your laptop, metal weld connections in the lithium-ion cells made by Schunk Sonosystem devices accompany you reliably throughout the whole day.
<G-vec00485-002-s671><call.telefonieren><de> Egal ob Sie morgens mit Ihrem Handy telefonieren, mit Ihrem E-Auto zur Arbeit fahren oder Ihren Laptop hochfahren: Metallschweißungen an den Li-Ionen Zellen von Schunk Sonosystems begleiten Sie zuverlässig den ganzen Tag.
<G-vec00485-002-s672><call.telefonieren><en> In the event that it is a false alarm, you can then lie back and relax and call your friends, as Scope doubles up as a cordless landline telephone.
<G-vec00485-002-s672><call.telefonieren><de> Sollte es bloß falscher Alarm sein, können Sie sich beruhigt zurücklehnen und ganz in Ruhe mit Ihren Freunden telefonieren, denn Scope ist zugleich ein schnurloses Festnetztelefon.
<G-vec00485-002-s673><call.telefonieren><en> No matter where you are from and no matter where exactly you want to call cheap to Russia: from the source of the Volga to the Caspian Sea.
<G-vec00485-002-s673><call.telefonieren><de> Egal woher Sie stammen und egal wohin genau Sie günstig nach Russland telefonieren möchten: von der Quelle der Wolga bis ans kaspische Meer.
<G-vec00485-002-s674><call.telefonieren><en> Surf, Call, Text security that keeps your communications safe by blocking unwanted content and contact
<G-vec00485-002-s674><call.telefonieren><de> Sicherheit beim Surfen, Telefonieren und Simsen schützt Ihre gesamte Kommunikation, indem unerwünschte Inhalte und Kontakte gesperrt werden.
<G-vec00485-002-s675><call.telefonieren><en> Up to 8 hours battery life while being used on a call, and up to 200 hours on standby.
<G-vec00485-002-s675><call.telefonieren><de> Bis zu 8 Stunden Akkulaufzeit beim Telefonieren und bis zu 200 Stunden im Standby-Betrieb.
<G-vec00485-002-s676><call.telefonieren><en> Why to call if all the important information about the office services and working schedules obviously placed on the homepage.
<G-vec00485-002-s676><call.telefonieren><de> Warum telefonieren, wenn alle wichtigen Informationen über die Leistungen und Arbeitszeiten offensichtlich auf der Homepage platziert sind.
<G-vec00485-002-s677><call.telefonieren><en> Intern: By dialing the room number, you can call another room in the hotel free of charge.
<G-vec00485-002-s677><call.telefonieren><de> Intern: Durch wählen der Zimmernummer können Sie im Haus kostenfrei zu einem anderen Zimmer telefonieren.
<G-vec00485-002-s678><call.telefonieren><en> They are third party modules integrated into apps to track the user and „call home“ with their findings.
<G-vec00485-002-s678><call.telefonieren><de> Dabei handelt es sich um in Apps eingebundene Module von Drittanbietern, die das Verhalten der Anwender beobachten und „nach Hause telefonieren“.
<G-vec00485-002-s679><call.telefonieren><en> We couldn’t call each other or text, but in the end we found each other.
<G-vec00485-002-s679><call.telefonieren><de> Telefonieren und SMSen war nicht möglich, aber schlussendlich fanden wir uns doch.
<G-vec00485-002-s680><call.telefonieren><en> They want to make a call.
<G-vec00485-002-s680><call.telefonieren><de> Sie möchten telefonieren.
<G-vec00485-002-s681><call.telefonieren><en> Except you call a local KBC employee from the comfort of your home, outside office hours.
<G-vec00485-002-s681><call.telefonieren><de> Sie telefonieren mit einem KBC-Mitarbeiter aus Ihrer Nähe, ruhig von zu Hause aus, auch außerhalb der Geschäftszeiten.
<G-vec00485-002-s682><call.telefonieren><en> Being a full-blown alternative to a fixed line, it can meet the needs of customers who want to call while remaining connected to the data network. Fixed-line replacement
<G-vec00485-002-s682><call.telefonieren><de> Als vollwertige Alternative zum Festnetz geht man auf die Bedürfnisse der Kunden ein, welche telefonieren sowie gleichzeitig über einen Datennetzanschluss verfügen möchten, aber aus unterschiedlichen Gründen kein Festnetz haben.
<G-vec00485-002-s683><call.telefonieren><en> How to call from Skype for free, we have already figured out.
<G-vec00485-002-s683><call.telefonieren><de> Wie telefonieren mit "Skype" kostenlos, haben wir bereits verstanden.
<G-vec00485-002-s722><call.verlangen><en> The SDGs call for a division of labour and a concentration on low income countries that are especially dependent on external support.
<G-vec00485-002-s722><call.verlangen><de> Die SDGs verlangen einen arbeitsteiligen Ansatz und eine Konzentration auf Ländern, die besonders stark von externer Unterstützung abhängig sind.
<G-vec00485-002-s723><call.verlangen><en> The Registrar has broad powers over trade union accounts, including the right to call for accounts at any time and to investigate any accounts that the Registrar considers unsatisfactory (ss 39 and 40, Trade Unions Act).
<G-vec00485-002-s723><call.verlangen><de> Der zuständige Beamte hat weitreichende Befugnisse bezüglich Gewerkschaftskonten wie zum Beispiel das Recht, jederzeit Kontoauszüge zu verlangen oder Konten zu prüfen, die er für unbefriedigend hält (Artikel 39 und 40 des Gewerkschaftsgesetzes).
<G-vec00485-002-s724><call.verlangen><en> They shall also be entitled to call for the data to be updated, rectified, supplemented or deleted, ask for them to be blocked or object to their processing, and require further information on the processing of personal data by contacting Assicurazioni Generali, Piazza Duca degli Abruzzi 2, 34132 Trieste.
<G-vec00485-002-s724><call.verlangen><de> Sie sind auch berechtigt zu verlangen, dass die Daten aktualisiert, korrigiert, ergänzt oder gelöscht werden; sie können die Daten blockieren lassen oder ihre Verarbeitung ablehnen sowie weitere Informationen über die Verarbeitung der personenbezogenen Daten verlangen, indem sie sich mit Assicurazioni Generali, Piazza Duca degli Abruzzi 2, 34132 Triest, in Verbindung setzen.
<G-vec00485-002-s725><call.verlangen><en> They also call for the clubs to respect the legislation dealing with immigration, especially when they employ young players from other countries, and the possibility of their returning to their country of origin if their career doesn’t take off.
<G-vec00485-002-s725><call.verlangen><de> Die Abgeordneten verlangen von den Sportvereinen, dass sie insbesondere bei der Verpflichtung jugendlicher Sportler aus Drittländern bestehende Einwanderungsvorschriften einhalten und ihnen die Möglichkeit der Rückkehr in ihr Heimatland offen lassen, falls ihre Karriere nicht wie geplant verläuft.
<G-vec00485-002-s726><call.verlangen><en> New technical capabilites and new moral challenges in clinical medicine call for new parameters and principles in post-Hippocratic health care ethics.
<G-vec00485-002-s726><call.verlangen><de> Neue technische Möglichkeiten und neue ethische Herausforderungen der klinischen Medizin verlangen nach dem Ausmessen neuer Parameter der klinischen Ethik jenseits von Hippokrates.
<G-vec00485-002-s727><call.verlangen><en> These requirements call for structure and for a perfect balance of text and visual elements.
<G-vec00485-002-s727><call.verlangen><de> Forderungen, die eine übersichtliche Struktur und ein perfektes Zusammenspiel zwischen den verbalen und visuellen Elementen verlangen.
<G-vec00485-002-s728><call.verlangen><en> Since this look can take on a costume makeup appearance, save it for special occasions that call for getting dressed up in style.
<G-vec00485-002-s728><call.verlangen><de> Da dieser Look ein Kostüm-Make-up-Erscheinungsbild annehmen kann, solltest du ihn für besondere Ereignisse aufheben, die danach verlangen, dass du dich mit Stil zurecht machst.
<G-vec00485-002-s729><call.verlangen><en> Anarcho-primitivists like the Fifth Estate paper in Detroit call for nothing less than the eradication of industrial-technological society and a return to primitive communism.
<G-vec00485-002-s729><call.verlangen><de> Anarcho-Primitivlinge wie die Zeitung FIFTH ESTATE in Detroit verlangen nichts geringeres als die Ausmerzung der industriell-technologischen Gesellschaft und die Rückkehr zum primitiven Kommunismus.
<G-vec00485-002-s730><call.verlangen><en> Different employers and situations will call for different styles and tones in a cover letter.
<G-vec00485-002-s730><call.verlangen><de> Verschiedene Arbeitgeber und Situationen verlangen nach einem sehr unterschiedlichen Stil und Ton im Bewerbungsschreiben.
<G-vec00485-002-s731><call.verlangen><en> One is thus led to think that perhaps David Irving, by taking the great risk of launching his libel suit, secretly intended to call the cards of his opponents and that we now see their hand, in the form of van Pelt's book.
<G-vec00485-002-s731><call.verlangen><de> Da er sein Plädoyer nun dennoch so vorträgt, kann man vielleicht darauf schließen, dass David Irving, als er das große Risiko seiner Verleumdungsklage auf sich nahm, insgeheim darauf abzielte, von seinen Gegnern zu verlangen, ihre Karten auf den Tisch zu legen und wir nun diese Karten in Gestalt von van Pelts Buch vor uns haben.
<G-vec00485-002-s732><call.verlangen><en> Heavier trucks require tires to match, and new tire product lines call for matching tire retreading materials.
<G-vec00485-002-s732><call.verlangen><de> Schwere Lkws fordern passende Reifen und neue Reifenproduktlinien verlangen nach passenden Materialien für die Runderneuerung.
<G-vec00485-002-s733><call.verlangen><en> Most recommendations call for repeating each exercise 10 times, at least twice a week, for noticeable results.
<G-vec00485-002-s733><call.verlangen><de> Die meisten Empfehlungen verlangen, dass jede Übung zehn Mal wiederholt wird, mindestens zweimal pro Woche, um spürbare Ergebnisse zu erzielen.
<G-vec00485-002-s734><call.verlangen><en> New energy efficiency targets, such as the 80PLUS® Gold requirement promoted by Climate Savers Computing Initiative, call for approximately a 10 percent improvement in the energy efficiency of computers compared to the current requirements of the U.S. Energy Star program.
<G-vec00485-002-s734><call.verlangen><de> Neue Vorgaben zur Energieeinsparung wie die 80PLUS® Gold-Anforderung der Climate Savers Computing Initiative verlangen bei Computern eine weitere Verbesserung der Energieeffizienz im Vergleich zum derzeitigen U.S. Energy Star Programm.
<G-vec00485-002-s735><call.verlangen><en> Accelerated social and technological changes call for new attitudes and behaviours on the part of individuals, groups and institutions.
<G-vec00485-002-s735><call.verlangen><de> Beschleunigte gesellschaftliche und technologische Wandlungsprozesse verlangen neue Einstellungen und Verhaltensweisen von Individuen, Gruppen und Institutionen.
<G-vec00485-002-s736><call.verlangen><en> It is in this spirit that we call for a European peace initiative with a set timeframe leading to tangible results in the context of the two-state solution, which should include an international monitoring and implementation mechanism.
<G-vec00485-002-s736><call.verlangen><de> In diesem Geiste verlangen wir eine europäische Friedensinitiative mit einem festgelegten Zeitrahmen, die zu konkreten Ergebnissen im Rahmen der Zwei-Staaten-Lösung führt und einen internationalen Überwachungs- und Umsetzungsmechanismus beinhalten sollte.
<G-vec00485-002-s737><call.verlangen><en> Call for an ambulance as soon as possible because the casualty needs hospital care.
<G-vec00485-002-s737><call.verlangen><de> Einen Krankenwagen so bald wie möglich verlangen, weil der Unfall Krankenhausobacht benötigt.
<G-vec00485-002-s738><call.verlangen><en> In order to completely exit Container Shipping, TUI will obtain the right to call for an IPO with priority placement of the shares held by TUI any time as of end of June 2012.
<G-vec00485-002-s738><call.verlangen><de> Um den vollständigen Ausstieg aus der Containerschiffahrt zu vollziehen, erhält TUI das Recht, jederzeit ab Ende Juni 2012 einen Börsengang mit vorrangiger Platzierung der von TUI gehaltenen Aktien zu verlangen.
<G-vec00485-002-s739><call.verlangen><en> This shows that the call for a united “Fatherland” had a very material background.
<G-vec00485-002-s739><call.verlangen><de> Man sieht hieraus, wie das Verlangen nach einem einheitlichen "Vaterland" einen sehr materiellen Hintergrund besaß.
<G-vec00485-002-s740><call.verlangen><en> The Trump administration and the Republican Party will get nearly everything they want, while the Democrats wage a phony war and call on the victims of Trump’s attacks to wait until the 2018 elections.
<G-vec00485-002-s740><call.verlangen><de> Die Trump-Regierung und die Republikaner werden fast alles durchsetzen, während die Demokraten nur symbolisch kämpfen und von den Opfern verlangen, dass sie sich bis zur Kongresswahl 2018 gedulden.
<G-vec00532-002-s608><call.rufen><en> Call Swiss America trading right now: 1-800-289-2646.
<G-vec00532-002-s608><call.rufen><de> Ruft Swiss America Trading gleich jetzt an: 1-800-289-2646.
<G-vec00532-002-s609><call.rufen><en> Please leave your name and telephone number and UF Gabelstapler GmbH will call you back.
<G-vec00532-002-s609><call.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und UF Gabelstapler GmbH ruft Sie zurück.
<G-vec00532-002-s610><call.rufen><en> The Checkmk alert helpers call up their functions synchronously.
<G-vec00532-002-s610><call.rufen><de> Der Alerthelper von Checkmk ruft Ihre Funktionen synchron auf.
<G-vec00532-002-s611><call.rufen><en> call on him while he is near.
<G-vec00532-002-s611><call.rufen><de> Ruft ihn an, während er nahe ist.
<G-vec00532-002-s612><call.rufen><en> Please leave your name and telephone number and Delgado Freizeit GmbH will call you back.
<G-vec00532-002-s612><call.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und UnikTruck A/S ruft Sie zurück.
<G-vec00532-002-s613><call.rufen><en> It will call res_init(), if it has not already been called.
<G-vec00532-002-s613><call.rufen><de> Sie ruft res_init() auf, wenn es noch nicht aufgerufen wurde.
<G-vec00532-002-s614><call.rufen><en> opening, you must call, Ya Fattah, Ya Fattah, Ya Fattah.
<G-vec00532-002-s614><call.rufen><de> Für die Öffnung ruft ihr Ya Fattah, Ya Fattah, Ya Fattah.
<G-vec00532-002-s615><call.rufen><en> There are daily steamers from Piraeus to Corfu, Cephallonia and Zakynthos, though the same ship does not necessarily call at all three.
<G-vec00532-002-s615><call.rufen><de> Es gibt tägliche Dampfer von Piraeus zu Corfu, Cephallonia und Zakynthos, obwohl das gleiche Schiff nicht unbedingt überhaupt drei ruft.
<G-vec00532-002-s616><call.rufen><en> Please leave your name and telephone number and AGRAVIS Technik Center GmbH will call you back.
<G-vec00532-002-s616><call.rufen><de> Bitte hinterlassen Sie Ihren Namen und Telefonnummer und AGRAVIS Technik Center GmbH ruft Sie zurück.
<G-vec00532-002-s617><call.rufen><en> Call to Allah.
<G-vec00532-002-s617><call.rufen><de> Ruft Allah an.
<G-vec00532-002-s618><call.rufen><en> Call xxx() to get the result for the aggregate when the group changes or after the last row has been processed.
<G-vec00532-002-s618><call.rufen><de> Es ruft xxx() auf, um das Aggregatergebnis zu erhalten, wenn die Gruppe wechselt oder nachdem die letzte Zeile verarbeitet wurde.
<G-vec00532-002-s619><call.rufen><en> Be aware of this and be clear about the assistance you call to yourself.
<G-vec00532-002-s619><call.rufen><de> Seid euch dessen bewußt, und seid klar in bezug auf die Unterstützung, die ihr zu euch ruft.
<G-vec00532-002-s620><call.rufen><en> Enlighten your peasant brothers, banish ignorance from the villages, call on the peasant poor to support the workers of town and country in their glorious struggle.
<G-vec00532-002-s620><call.rufen><de> Klärt eure Brüder, die Bauern, auf: vertreibt die Finsternis aus dem Dorf, ruft die Dorfarmut auf, die Arbeiter in Stadt und Land in ihrem ruhmvollen Kampf zu unterstützen.
<G-vec00532-002-s621><call.rufen><en> In my country Malaysia, the muezzin would call out to Muslims for prayer five times a day through loudspeakers from the minarets of mosques.
<G-vec00532-002-s621><call.rufen><de> In meinem Heimatland Malaysien ruft der Muezzin durch die Lautsprecher auf den Minaretten der Moscheen fünfmal am Tag die Muslime zum Gebet.
<G-vec00532-002-s622><call.rufen><en> If you call them to Guidance they would not hear; you see them looking at you and they see not.
<G-vec00532-002-s622><call.rufen><de> Und wenn ihr sie zur Rechtleitung ruft, hören sie nicht.
<G-vec00532-002-s623><call.rufen><en> 110 Say: "Call upon Allah, or call upon Rahman: by whatever name ye call upon Him, (it is well): for to Him belong the Most Beautiful Names.
<G-vec00532-002-s623><call.rufen><de> 110 Sag: Ruft Allah oder ruft den Allerbarmer an; welchen ihr auch ruft, Sein sind die schönsten Namen.
<G-vec00532-002-s626><call.rufen><en> Elijah said to the prophets of Baal, Choose you one bull for yourselves, and dress it first; for you are many; and call on the name of your god, but put no fire under.
<G-vec00532-002-s626><call.rufen><de> 25Und Elia sprach zu den Propheten Baals: Wählt ihr einen Stier und richtet zuerst zu, denn ihr seid viele, und ruft den Namen eures Gottes an, aber legt kein Feuer daran.
<G-vec00043-002-s076><call.bezeichnen><en> I believe they’re going to be happy but I guess you could call me sentimental. 5.
<G-vec00043-002-s076><call.bezeichnen><de> Ich denke, dass die beiden glücklich werden, aber ich vermute, ihr könntet mich auch als sentimental bezeichnen.
<G-vec00043-002-s078><call.bezeichnen><en> We make here a brief exposition of this activity, which we call Social Education.
<G-vec00043-002-s078><call.bezeichnen><de> Wir legen hier kurz diese Aktivität dar, die wir als Sozialerziehung bezeichnen.
<G-vec00043-002-s079><call.bezeichnen><en> As we annually use 200 tonnes of welding rod, we venture to call ourselves experts in the welding of carbon steel.
<G-vec00043-002-s079><call.bezeichnen><de> Da wir jährlich 200 Tonnen Schweißdraht verbrauchen, können wir uns ohne weiteres als Experten beim Schweißen von Karbonstahl bezeichnen.
<G-vec00043-002-s080><call.bezeichnen><en> We say there are things that we call wild cards.
<G-vec00043-002-s080><call.bezeichnen><de> Wir sagen, dass es Dinge gibt, die wir als Joker bezeichnen.
<G-vec00043-002-s081><call.bezeichnen><en> Unfortunately, childhood is difficult to call carefree, stress is part of human nature since birth.
<G-vec00043-002-s081><call.bezeichnen><de> Leider ist die Kindheit schwer als sorglos zu bezeichnen, Stress ist seit der Geburt Teil der menschlichen Natur.
<G-vec00043-002-s082><call.bezeichnen><en> Not always those who call themselves experts are really experts.
<G-vec00043-002-s082><call.bezeichnen><de> Nicht alle die sich selbst als experten bezeichnen, sind wirkliche experten.
<G-vec00043-002-s083><call.bezeichnen><en> In this context, if markets are characterized by what economists call perfect competition, once the opportunity cost of all inputs has been paid, there is nothing left to distribute.
<G-vec00043-002-s083><call.bezeichnen><de> In diesem Zusammenhang gilt: Wenn Märkte durch einen Zustand gekennzeichnet sind, den die Ökonomen als vollkommenen Wettbewerb bezeichnen, gibt es nach Bezahlung der Opportunitätskosten aller Inputfaktoren nichts mehr zu verteilen.
<G-vec00043-002-s084><call.bezeichnen><en> This is a typical German way of looking at things, shaped by what our fellow men abroad call "German Angst".
<G-vec00043-002-s084><call.bezeichnen><de> Das ist eine typisch deutsche Sichtweise auf die Dinge, geprägt von dem, was unsere Mitmenschen im Ausland als "German Angst" bezeichnen.
<G-vec00043-002-s085><call.bezeichnen><en> We want women who want to be leaders, and equip them with what we call Leadership Essentials.
<G-vec00043-002-s085><call.bezeichnen><de> Wir wollen Frauen, die führend sein wollen, und rüsten sie mit dem aus, was wir als Leadership Essentials bezeichnen.
<G-vec00043-002-s086><call.bezeichnen><en> I would call this “raving”, had not decades of political struggle taught me to regard honesty in opponents as a rare exception.
<G-vec00043-002-s086><call.bezeichnen><de> Ich würde dies als „Fieberphantasien“ bezeichnen, hätten mich nicht Jahrzehnte politischen Kampfes gelehrt, die Ehrlichkeit von Opponenten als seltene Ausnahme zu betrachten.
<G-vec00043-002-s087><call.bezeichnen><en> If examining the content and the circumstances that what we call "consensus" has always had, we will find that no social rule can operate only on the basis of physical force, and that always the best made dominations are those that can translate force in basic social agreements.
<G-vec00043-002-s087><call.bezeichnen><de> Wenn man den Inhalt und die Umstände untersucht, die das, was wir als „Konsens“ bezeichnen, so wird man zum Schluss kommen, dass keine gesellschaftliche Herrschaft allein auf der Grundlage der physischen Gewalt operieren kann, und dass immer die am besten verwirklichten Herrschaften jene sind, die die Gewalt in grundlegende gesellschaftliche Vereinbarungen umzumünzen in der Lage sind.
<G-vec00043-002-s088><call.bezeichnen><en> This was already the case with the Bible of Israel, which we Christians call the Old Testament.
<G-vec00043-002-s088><call.bezeichnen><de> Das gilt bereits innerhalb der Bibel Israels, die wir Christen als das Alte Testament bezeichnen.
<G-vec00043-002-s089><call.bezeichnen><en> I'd call my work abstract art or intuitive art.
<G-vec00043-002-s089><call.bezeichnen><de> Ich würde meine Arbeit als abstrakte Kunst oder intuitive Kunst bezeichnen.
<G-vec00043-002-s090><call.bezeichnen><en> In everyday life I would not call myself submissive.
<G-vec00043-002-s090><call.bezeichnen><de> Im Alltag würde ich mich nicht als devot bezeichnen.
<G-vec00043-002-s091><call.bezeichnen><en> This 'eternal now' moves forward and creates what in sequential time we call past, present and future.
<G-vec00043-002-s091><call.bezeichnen><de> Diese ‘ewige Jetzt’ bewegt sich vorwärts und erschafft, was wir in der sequentiellen Zeitmessung als Vergangenheit, Gegenwart und Zukunft bezeichnen.
<G-vec00043-002-s092><call.bezeichnen><en> But, even though today many call me the Madam of rubber fetish, at that time I just was an apprentice.
<G-vec00043-002-s092><call.bezeichnen><de> Aber, auch wenn mich heute viele als die Meisterin des Gummifetisch bezeichnen, zu der Zeit war ich doch nur ein Lehrmädchen.
<G-vec00043-002-s094><call.bezeichnen><en> Their criticisms of the Union parties are directed against its social programme, which they call excessive and unrealistic.
<G-vec00043-002-s094><call.bezeichnen><de> Ihre Kritik an der Union richtet sich gegen das Sozialprogramm, das sie als überzogen und unrealistisch bezeichnen.
<G-vec00043-002-s456><call.nennen><en> I prefer to call it the real "New Wave."
<G-vec00043-002-s456><call.nennen><de> Ich nenne es lieber die echte "New Wave".
<G-vec00043-002-s457><call.nennen><en> Around others, I will continue to call you Captain Quinn.
<G-vec00043-002-s457><call.nennen><de> Aber wenn andere dabei sind, nenne ich Euch weiterhin Captain Quinn.
<G-vec00043-002-s458><call.nennen><en> Younger people – I call them today's "Generation Europe" – have every reason to seize and shape their future with self-confidence.
<G-vec00043-002-s458><call.nennen><de> Die jüngeren Menschen - ich nenne sie die heutige "Generation Europa" - haben allen Grund, selbstbewusst ihre Zukunft anzupacken und zu gestalten.
<G-vec00043-002-s459><call.nennen><en> I like to call these my interactive runs.
<G-vec00043-002-s459><call.nennen><de> Ich nenne diese Art von Workout interaktive Läufe.
<G-vec00043-002-s460><call.nennen><en> We all share a oneness with what science calls the "unified field" and with what I call the amazing, divine love that is God.
<G-vec00043-002-s460><call.nennen><de> Wir alle teilen eine Einheit mit dem was die Wissenschaft das 'einheitliche Feld' nennt, und mit dem was ich die erstaunliche, göttliche Liebe nenne, welche Gott ist.
<G-vec00043-002-s461><call.nennen><en> For example, I always call our son with the name of my colleague and my colleague must bear it that I speak to him with the first name of our son.
<G-vec00043-002-s461><call.nennen><de> Zum Beispiel nenne ich immer wieder unseren Sohn mit dem Namen meines Kollegen und mein Kollege muss sich von mir mit dem Vornamen unseres Sohnes ansprechen lassen.
<G-vec00043-002-s462><call.nennen><en> Call upon Me in every adversity of body and soul.... this is what I call pray and watch.... direct your thoughts upwards where he cannot follow you and you will safely escape from him and place yourselves under My protection.
<G-vec00043-002-s462><call.nennen><de> Rufet Mich an in jeder Not des Leibes und der Seele.... das nenne Ich beten und wachsam sein.... richtet eure Gedanken zur Höhe, wohin er nicht folgen kann, und ihr entfliehet ihm sicher und begebet euch in Meinen Schutz.
<G-vec00043-002-s463><call.nennen><en> EP: I used many lights during the shooting for TEN, but the one that stood out and that we choose for the final image was the one I call Solar Wind, which I discovered a year ago with Ariane (my assistant on the TEN photoshoot).
<G-vec00043-002-s463><call.nennen><de> Eric Paré: Ich habe während des Shootings viele verschiedene Lichtarten verwendet, aber die beste von allen war die, die ich Solar Wind nenne und vor einem Jahr gemeinsam mit Ariane (meiner Assistentin beim TEN Projekt) entdeckt habe.
<G-vec00043-002-s464><call.nennen><en> My thanks to our amazing safari guide, Ali Khan of Vumbi Jeep Safaris, who I am proud to call a friend.
<G-vec00043-002-s464><call.nennen><de> Mein Dank gilt unserem fantastischen Safariführer, Ali Khan von Vumbi Jeep Safaris, den ich stolz meinen Freund nenne.
<G-vec00043-002-s465><call.nennen><en> But when we come to discuss the principle, as I call it, of Divergence of Character, we shall see how this may be explained, and how the lesser differences between varieties tend to increase into the greater differences between species.
<G-vec00043-002-s465><call.nennen><de> Wenn wir aber zur Erörterung des Princips, wie ich es nenne, der „Divergenz der Charactere" kommen, so werden wir sehen, wie dies zu erklären ist, und wie die geringeren Verschiedenheiten zwischen Varietäten zu den gröszeren Verschiedenheiten zwischen Arten anzuwachsen streben.
<G-vec00043-002-s466><call.nennen><en> This last Sunday I decided to have a day to myself to explore this beautiful area I use to call home.
<G-vec00043-002-s466><call.nennen><de> Letzten Sonntag entschloss ich mich, einen Tag alleine zu verbringen und die wundervolle Gegend zu erkunden, die ich mein Zuhause nenne.
<G-vec00043-002-s467><call.nennen><en> I call that capitalism.
<G-vec00043-002-s467><call.nennen><de> Ich nenne das den Kapitalismus.
<G-vec00043-002-s468><call.nennen><en> That's why I say that you are one in a million and I call you my guardian angle.
<G-vec00043-002-s468><call.nennen><de> Darum sage ich du bist einer unter Millionen und ich nenne dich meinen Schutzengel.
<G-vec00043-002-s469><call.nennen><en> I call it “the backpack of life”.
<G-vec00043-002-s469><call.nennen><de> Ich nenne das „den Rucksack des Lebens“.
<G-vec00043-002-s470><call.nennen><en> „This strong proscriptive claim, that natural causes can only transmit CSI but never originate it, I call the Law of Conservation of Information.
<G-vec00043-002-s470><call.nennen><de> ↑ Auf Deutsch etwa: Diese stark einschränkende Behauptung, dass natürliche Ursachen CSI nie entstehen lassen, sondern nur übertragen können, nenne ich das Informationserhaltungsgesetz.
<G-vec00043-002-s471><call.nennen><en> During your Standby Phase, select 1 random card from your opponent's hand. Call the type of card (Monster, Spell, or Trap).
<G-vec00043-002-s471><call.nennen><de> Wähle während deiner Standby Phase 1 Karte in der Hand deines Gegners und nenne einen Kartentyp (Monster, Zauber oder Falle).
<G-vec00043-002-s472><call.nennen><en> In the camp, there's a lot of supporters, students and so on; these I call friends.
<G-vec00043-002-s472><call.nennen><de> Im Camp gibt es viele FreundInnen, die uns unterstützen, StudentInnen und andere – die nenne ich FreundInnen.
<G-vec00043-002-s473><call.nennen><en> Ye are my friends... Henceforth I call you not servants, for the servant knoweth not what his lord doeth; but I have called you friends, for all things that I have heard of my father I have made known unto you.
<G-vec00043-002-s473><call.nennen><de> Ihr seid meine Freunde … Fortan nenne ich Euch nicht Diener, da der Diener nicht weiß, was sein Herr tut; aber ich habe Euch Freunde genannt, da ich Euch alle Dinge bekannt gemacht, die ich von meinem Vater erfahren habe.
<G-vec00043-002-s474><call.nennen><en> #5 READ THE DESCRIPTION OVER HERE This is basically a Lets Play, but im not going to call it Lets Play, because i am probably going to talk a little less while playing Portal than i would in any other game.
<G-vec00043-002-s474><call.nennen><de> Im Prinzip is das hier wie ein Lets Play, aber da ich vermutlich beim Portal spielen nicht soviel reden werde wie bei anderen Spielen, nenne ich es lieber nicht Lets Play da sonst wieder Captain Obvious auftaucht und mir erklären möchte, dass man in einem Lets Play mehr redet.
<G-vec00043-002-s475><call.nennen><en> That’s why we call it ascension.
<G-vec00043-002-s475><call.nennen><de> Deshalb nennen wir es Aufstieg.
<G-vec00043-002-s476><call.nennen><en> This is because much of space is what we call a ‘vacuum’.
<G-vec00043-002-s476><call.nennen><de> Das liegt daran, dass der Großteil des Weltraums aus etwas besteht, was wir ein Vakuum nennen.
<G-vec00043-002-s477><call.nennen><en> Junction point should be partners for the governments of the other member states, while the other junction point is assigned to place to consumers and entrepreneurs information ready for the Internet right and to call addresses from complaint and arbitration boards to.
<G-vec00043-002-s477><call.nennen><de> Eine Verbindungsstelle soll Ansprechpartner für die Regierungen der anderen Mitgliedstaaten sein, während die andere Verbindungsstelle damit beauftragt ist, Verbrauchern und Unternehmern Informationen zum Internetrecht bereit zu stellen und Adressen von Beschwerde- und Schlichtungsstellen zu nennen.
<G-vec00043-002-s479><call.nennen><en> It is difficult briefly to summarise this mood — for I cannot call it anything else — simply because it is a mood and not a constructive thought.
<G-vec00043-002-s479><call.nennen><de> Es ist schwer, diese Stimmung — denn ich kann sie nicht anders nennen — kurz und bündig zusammenzufassen, eben weil sie eine Stimmung, nicht ein konstruktiver Gedanke ist.
<G-vec00043-002-s480><call.nennen><en> On the other side, we see those dark times in the history of the Church, such as what we call the Middle Ages, and other times when it seemed that the Lord was standing still.
<G-vec00043-002-s480><call.nennen><de> Auf der anderen Seite sehen wir jene dunklen Zeiten in der Geschichte der Gemeinde, wie zum Beispiel jene, die wir das Mittelalter nennen (englisch: dark ages), und andere Zeiten, da es den Anschein hat, als stehe der Herr still.
<G-vec00043-002-s481><call.nennen><en> FEZ: Yes, very funny to call me an anti-Semite.
<G-vec00043-002-s481><call.nennen><de> FWZ: Ja, sehr witzig, mich einen Antisemiten zu nennen.
<G-vec00043-002-s482><call.nennen><en> Around 60,000 “Häfler”, as the locals call themselves, live here, and some 700,000 guests flock to Messe Friedrichshafen on the lake every year.
<G-vec00043-002-s482><call.nennen><de> Rund 60.000 „Häfler“, wie sich die Einheimischen selbst nennen, leben hier – und rund 700.000 Gäste lockt die Messe Friedrichshafen jedes Jahr an den See.
<G-vec00043-002-s483><call.nennen><en> The creators call it the end of the line of the long list of Tetris-clones.
<G-vec00043-002-s483><call.nennen><de> Die Programmierer nennen es das Ende aller Tetris-Klone.
<G-vec00043-002-s484><call.nennen><en> The VW bus, kombi, camper, van, what ever you call it - it is an incredibly popular car among classic car buyers in the UK, Netherlands, and Australia.
<G-vec00043-002-s484><call.nennen><de> Der VW-Bus, Kombi, Camper, Van, wie auch immer Sie ihn nennen - ist ein unglaublich beliebtes Auto bei Käufern klassischer Autos in Großbritannien, den Niederlanden und Australien.
<G-vec00043-002-s485><call.nennen><en> This cultural dimension is what the economist may call "real capital" (in contrast to financial capital).
<G-vec00043-002-s485><call.nennen><de> Diese kulturelle Dimension ist das, was der Wirtschaftswissenschaftler "Realkapital" nennen könnte (im Gegensatz zu Finanzkapital).
<G-vec00043-002-s486><call.nennen><en> Any and all that responds to the material-gravity circuit centering in nether Paradise, we call matter -- energy-matter in all its metamorphic states. 0:6.2
<G-vec00043-002-s486><call.nennen><de> Alles und jedes, was auf den materiellen Gravitationskreis mit Zentrum im Unteren Paradies anspricht, nennen wir Materie — Energie-Materie in all ihren metamorphischen Zuständen.
<G-vec00043-002-s487><call.nennen><en> The steps help break what I might call the "public language barrier" so that the source of one's own thinking is found and spoken from.
<G-vec00043-002-s487><call.nennen><de> Die Schritte helfen zu durchbrechen, was ich die "allgemeine öffentliche Sprachbarriere" nennen würde, damit die Quelle des eigenen Denkens gefunden und daraus gesprochen wird.
<G-vec00043-002-s488><call.nennen><en> Though long hailed as beach soccer's greatest-ever player, it is only now - at the age of 38 - that Madjer is able to call himself a world champion.
<G-vec00043-002-s488><call.nennen><de> Madjer gilt zwar schon seit langem als bester Beach-Soccer-Spieler aller Zeiten, doch erst jetzt, im Alter von 38 Jahren, kann er sich auch Weltmeister nennen.
<G-vec00043-002-s489><call.nennen><en> He said, ‘You can’t possibly call it Amnesia–you can’t have a database that forgets things!’.
<G-vec00043-002-s489><call.nennen><de> Er meinte: ‚Ihr könnt das Ding doch nicht Amnesia nennen – ihr könnt keine Datenbank entwickeln, die Sachen vergisst!‘.
<G-vec00043-002-s490><call.nennen><en> Loud meowing, like a howl, cats call themselves a couple.
<G-vec00043-002-s490><call.nennen><de> Lautes Miauen, wie ein Heulen, nennen sich Katzen ein Paar.
<G-vec00043-002-s491><call.nennen><en> And simply call it ARTelier Reiss.
<G-vec00043-002-s491><call.nennen><de> Und nennen es das ARTelier Reiss.
<G-vec00043-002-s492><call.nennen><en> It’s well known that there are a series of potential limitations of CRISPR that can cause what we call “off-target effects”—where basically in addition to breaking what you want to break, it can break something else in your genome.
<G-vec00043-002-s492><call.nennen><de> Es ist bekannt, dass es eine Reihe von möglichen Einschränkungen von CRISPR gibt, die das verursachen können, was wir "Off-Target-Effekte" nennen - wo es im Grunde genommen nicht nur das, was man brechen will, sondern auch etwas anderes in seinem Genom brechen kann.
<G-vec00043-002-s493><call.nennen><en> One of the new technical innovations in The Sims 4 is something we call “multi-tasking.”
<G-vec00043-002-s493><call.nennen><de> Eine der technischen Innovationen in Die Sims 4 ist etwas, was wir „Multitasking” nennen.
<G-vec00043-002-s513><call.rufen><en> It is the individual's own decision whether or not to believe and heed the divine call and faithfully fulfil the tasks assigned to him.
<G-vec00043-002-s513><call.rufen><de> Ob er dem göttlichen Ruf glaubt, folgt und treu die ihm zugewiesenen Aufgaben erfüllt, liegt in seiner Entscheidung.
<G-vec00043-002-s514><call.rufen><en> Call her – she looks forward to your coming.
<G-vec00043-002-s514><call.rufen><de> Ruf sie an – sie freut sich auf dein Kommen.
<G-vec00043-002-s515><call.rufen><en> Now is the time for the Renewal to forcefully respond to the call of prayer and give strong witness of its rich experience of prayer in the power of the Holy Spirit.
<G-vec00043-002-s515><call.rufen><de> Jetzt ist es an der Zeit, dass die Erneuerung entschieden auf den Ruf ins Gebet antwortet und von ihrer reichen Erfahrung mit dem Gebet aus der Kraft des Heiligen Geistes Zeugnis gibt.
<G-vec00043-002-s516><call.rufen><en> During personal interaction as well as when talking to large audiences she radiated the certainty that the mission of the Volunteers is the call of God to serve, to be transparencies of the love of God for us.
<G-vec00043-002-s516><call.rufen><de> Im persönlichen Kontakt wie auch beim Reden vor großem Publikum strahlte sie ihre Gewissheit aus, dass die Sendung des „Freiwilligen“ ein Ruf Gottes zum Dienen ist, ein Transparent Seiner Liebe für die Menschen zu sein.
<G-vec00043-002-s517><call.rufen><en> Everywhere I must seek my little sheep, which were lost; my call must get through everywhere, and for that reason my voice must sound again and again – again and again I must come in the word to men and call them home into the father house.
<G-vec00043-002-s517><call.rufen><de> Überall muss Ich Meine Schäflein suchen, die verloren waren, Mein Ruf muss überallhin dringen, und daher muss Meine Stimme immer wieder ertönen - immer wieder muss Ich im Wort kommen zu den Menschen und sie rufen heim ins Vaterhaus.
<G-vec00043-002-s518><call.rufen><en> And more than 500 uniformed comrades from Austria and the crown lands followed the call.
<G-vec00043-002-s518><call.rufen><de> Und mehr als 500 Uniformierte aus Österreich und den Kronländern folgten dem Ruf.
<G-vec00043-002-s519><call.rufen><en> United states and Britain have never been on the eyes of man, at best, is a ‘Call to come’ that is able to play only a doll’.
<G-vec00043-002-s519><call.rufen><de> Die Vereinigten Staaten und Britannien standen niemals vor Augen der Männer, bestenfalls ist es ein ‚Ruf nach Hause‘, den nur eine Puppe spielen kann.
<G-vec00043-002-s520><call.rufen><en> We therefore emphatically welcome the document produced by the joint working group of the World Council of Churches and the Roman Catholic Church on the topic "The Challenge of Proselytism and the Call to Common Witness", the insights of which can be helpful for future discussions.
<G-vec00043-002-s520><call.rufen><de> Wir begrüssen deshalb mit Nachdruck das Dokument der gemeinsamen Arbeitsgruppe zwischen dem Ökumenischen Rat der Kirchen und der Römisch-Katholischen Kirche zum Thema "Die Herausforderung des Proselytismus und der Ruf zum gemeinsamen Zeugnis", dessen Einsichten für das künftige Gespräch hilfreich sein könnten.
<G-vec00043-002-s521><call.rufen><en> It is time for those who incorporate the Feminine Principle, the women of this earth, to respond to the higher call that will awaken unprecedented expressions of the Mother Spirit.
<G-vec00043-002-s521><call.rufen><de> Es is an der Zeit für diejenigen, denen das feminine Prinzip innewohnt - die Frauen dieser Welt - ihrem höheren Ruf zu folgen, um noch nie zuvor bekannte Ausdrucksformen des Mutter-Archetyps zu erwecken.
<G-vec00043-002-s522><call.rufen><en> Over 2100 exhibitors from 43 countries and around 145,000 visitors from more than 100 nations heeded the call for “Intelligence in Production”.
<G-vec00043-002-s522><call.rufen><de> Dem Ruf nach „Intelligence in Production“ waren über 2100 Aussteller aus 43 Ländern und rund 145.000 Besucher aus mehr als 100 Nationen gefolgt.
<G-vec00043-002-s523><call.rufen><en> The word salat (prayer) literally means "call" and to perform it is to seek closeness to God.
<G-vec00043-002-s523><call.rufen><de> Das Wort Salat (Gebet) bedeutet wörtlich „Ruf" und es auszuführen bedeutet die Nähe Gottes zu suchen.
<G-vec00043-002-s524><call.rufen><en> Call us if you want to be picked up (for free).
<G-vec00043-002-s524><call.rufen><de> Ruf uns an, wenn du abgeholt werden möchtest (kostenlos).
<G-vec00043-002-s525><call.rufen><en> If you follow the call to nurture the light in a particular space your job is just beginning.
<G-vec00043-002-s525><call.rufen><de> Wenn ihr dem Ruf folgt, das Licht an einem bestimmten Ort zu hüten, dann beginnt eure Aufgabe gerade erst.
<G-vec00043-002-s526><call.rufen><en> 1 Number: The device will receive a call only if the caller's number is transmitted and if that number is in the number list.
<G-vec00043-002-s526><call.rufen><de> 1 Nummer: das Gerät nimmt einen Ruf nur entgegen, wenn der Anrufer in der Nummernliste steht und seine Rufnummer übermittelt wird.
<G-vec00043-002-s527><call.rufen><en> This call was given in mid Africa, but once called this entity roamed about a bit, answering The Call from others in the vicinity.
<G-vec00043-002-s527><call.rufen><de> Dieser Ruf wurde in Zentralafrika gegeben, doch einmal gerufen, reiste dieses Wesen ein bißchen herum und beantwortete den Ruf von anderen in der Nähe.
<G-vec00043-002-s529><call.rufen><en> The kidnapping and subsequent release of Neda, mother of Mãezinha, occurring in February 1989, was the immediate preparation for the call of God, and led our Founders to completely detach themselves from material goods.
<G-vec00043-002-s529><call.rufen><de> Die im Februar 1989 stattgefundene Entführung und anschließende Freilassung von Neda, der Mutter von Mãezinha, war die unmittelbare Vorbereitung auf den Ruf Gottes und veranlasste unsere Gründer dazu, sich vollständig von materiellen Gütern zu lösen.
<G-vec00043-002-s530><call.rufen><en> They were joined by extremist European left activists and volunteers who answered the call to help the Palestinians in the Gaza." ↑
<G-vec00043-002-s530><call.rufen><de> Ihnen schlossen sich linksradikale Aktivisten und Organisationen aus Europa an sowie Freiwillige, die dem Ruf folgten, den Palästinensern im Gazastreifen zu helfen und nicht in die Gewaltpläne der IHH eingeweiht waren.
<G-vec00043-002-s531><call.rufen><en> IVR remote control via DTMF not possible if outgoing gateway call is not in state CONNECTED.
<G-vec00043-002-s531><call.rufen><de> Die Steuerung eines IVR-Systems via DTMF ist nicht möglich solange der Ruf nicht vollständig aufgebaut ist.
<G-vec00043-002-s532><call.rufen><en> Contact us We’re here to help, so send us an e-mail, call us or chat to us live online.
<G-vec00043-002-s532><call.rufen><de> Wir helfen Dir gerne weiter, also sende uns doch einfach eine E-Mail, rufe uns an oder chatte live mit uns.
<G-vec00043-002-s533><call.rufen><en> 33:3 Call unto Me, and I will answer thee, and will tell thee great things, and hidden, which thou knowest not.
<G-vec00043-002-s533><call.rufen><de> 33:3 Rufe mich an, dann will ich dir antworten und will dir Großes und Unfaßbares mitteilen, das du nicht kennst.
<G-vec00043-002-s534><call.rufen><en> I call on both parties to continue their constructive approach in the next rounds of talks and to show the necessary willingness to compromise."
<G-vec00043-002-s534><call.rufen><de> Ich rufe beide Seiten dazu auf, auch in den folgenden Gesprächsrunden ihren bisherigen konstruktiven Ansatz weiterzuführen und die notwendige Kompromissbereitschaft zu zeigen“.
<G-vec00043-002-s535><call.rufen><en> I call some hotel service number and ask for explanations.
<G-vec00043-002-s535><call.rufen><de> Ich rufe eine Servicenummer des Hotels an und bitte um Erklärungen.
<G-vec00043-002-s536><call.rufen><en> Call upon God to convict you so deeply that you can say, “My sin is ever before me” (Psalm 51:3).
<G-vec00043-002-s536><call.rufen><de> Rufe zu Gott, dich so zu überzeugen, daß du sagen kannst, “Meine Sünde ist immer vor mir.” (Ps.
<G-vec00043-002-s537><call.rufen><en> 26 I call heaven and earth as witnesses this day, that you shall quickly perish from the land, which, when you have crossed over the Jordan, you will possess.
<G-vec00043-002-s537><call.rufen><de> 26. den Himmel und die Erde rufe ich heute als Zeugen gegen euch an: dann werdet ihr unverzüglich aus dem Land ausgetilgt sein, in das ihr jetzt über den Jordan zieht, um es in Besitz zu nehmen.
<G-vec00043-002-s538><call.rufen><en> He says, “Call to me and I will answer you, and will tell you great and hidden things that you have not known” (Jer.
<G-vec00043-002-s538><call.rufen><de> Er sagt: „Rufe zu mir, so will ich dir antworten und dir große, unfassbare Dinge mitteilen, die du nicht kennst“ (Jer.
<G-vec00043-002-s539><call.rufen><en> Males begin to call around March and throughout May.
<G-vec00043-002-s539><call.rufen><de> Männchen fangen an, im März und bis Mai Rufe auszustossen.
<G-vec00043-002-s540><call.rufen><en> 16I call my servant but he does not reply though I beg him with my own mouth.
<G-vec00043-002-s540><call.rufen><de> 16Meinem Knechte rufe ich, und er antwortet nicht; mit meinem Munde muss ich zu ihm flehen.
<G-vec00043-002-s541><call.rufen><en> Then call now and learn from a French teacher at a distance.
<G-vec00043-002-s541><call.rufen><de> Dann rufe jetzt an und lerne von einem Französischlehrer aus der Ferne.
<G-vec00043-002-s542><call.rufen><en> I always get there one more time, there’s nothing else I can do, even here, where I let my hand pass over the tall grass, raise my head and call, my hand, my distinctly real hand.
<G-vec00043-002-s542><call.rufen><de> Ich gelange da immer noch einmal hin, ich kann nicht anders, auch hier, wo ich die Hand übers hohe Gras streichen lasse, den Kopf hebe und rufe, meine Hand, meine ausgesprochen wirkliche Hand.
<G-vec00043-002-s543><call.rufen><en> Psalms 50:15 And call me in the day of trouble; I will deliver you, and you will glorify me."
<G-vec00043-002-s543><call.rufen><de> Psalms 50:15 Und rufe mich an in der Not, so will ich dich erretten, so sollst du mich preisen.
<G-vec00043-002-s544><call.rufen><en> I call heaven and earth to record this day against you, that I have set before you life and death, blessing and cursing: therefore choose life, that both thou and thy seed may live…
<G-vec00043-002-s544><call.rufen><de> Ich rufe Himmel und Erde an, um diesen Tag gegen dich festzuhalten, den ich dir vor Leben und Tod, Segen und Fluchen gestellt habe: also wähle das Leben, damit sowohl du als auch dein Same leben möge...
<G-vec00043-002-s545><call.rufen><en> Call the dialog to search and replace texts in the schematic.
<G-vec00043-002-s545><call.rufen><de> Rufe den Dialog, um Texte im Schaltplan zu suchen und zu ersetzen, auf.
<G-vec00043-002-s546><call.rufen><en> Call to me and I will answer you, and will tell you great and hidden things that you have not known. prayer listening
<G-vec00043-002-s546><call.rufen><de> Rufe mich an, so will ich dir antworten und will dir kundtun große und unfassbare Dinge, von denen du nichts weißt.
<G-vec00043-002-s547><call.rufen><en> If you fear that your parent may hurt you, your siblings, or themselves, call the emergency department.
<G-vec00043-002-s547><call.rufen><de> Wenn du Angst hast, dass dein Vater oder deine Mutter dich, deine Geschwister oder sich selbst verletzt, rufe den Notdienst.
<G-vec00043-002-s548><call.rufen><en> Plumbing, however, is another story. Then I call for help immediately.
<G-vec00043-002-s548><call.rufen><de> Klempnerarbeiten sind allerdings etwas ganz anderes: da rufe ich sofort um Hilfe.
<G-vec00043-002-s549><call.rufen><en> 16 Jesus said to her, "Go, call your husband, and come here."
<G-vec00043-002-s549><call.rufen><de> 16 Er sagte zu ihr: Geh, rufe deinen Mann und komm hierher.
<G-vec00043-002-s550><call.rufen><en> Use quirks and call on your companions to help you launch powerful attacks in which you also use the environment — or destroy it completely.
<G-vec00043-002-s550><call.rufen><de> Setze Macken ein und rufe Deine Begleiter zu Hilfe, um mächtige Angriffe zu starten, in denen Du auch die Umgebung einsetzt — oder vollständig zerstörst.
<G-vec00043-002-s551><call.rufen><en> If you wish to speak to us, please call our Reservation Center at ++84.4.3927 4120 and live chat during our business office hours.
<G-vec00043-002-s551><call.rufen><de> Wenn Sie mit uns sprechen möchten, rufen Sie bitte unsere Reservierungszentrale unter + +84.4.3927 4120 an oder per Live-Chat während unserer Geschäftszeiten.
<G-vec00043-002-s552><call.rufen><en> Call the sa_server_option system procedure, setting the ProcedureProfiling option to ON.
<G-vec00043-002-s552><call.rufen><de> Rufen Sie die Systemprozedur "sa_server_option" auf und setzen Sie die Option "ProcedureProfiling" auf ON.
<G-vec00043-002-s553><call.rufen><en> To go to layouts in an external file, define a script in that file using the Go to Layout script step, and call that script from the first file using the Perform Script script step.
<G-vec00043-002-s553><call.rufen><de> Um in Layouts in einer externen Datei zu wechseln, definieren Sie in der betreffenden Datei ein Script mit dem Scriptschritt „Gehe zu Layout“ und rufen dieses Script aus der ersten Datei mit dem Script ausführen Scriptschritt auf.
<G-vec00043-002-s554><call.rufen><en> We call our friends in Colombo and are relieved to hear, they have not been bothered; we send SMS and E-Mails to all our other friends and get to know, they too stayed healthy and unhit by Tsunami.
<G-vec00043-002-s554><call.rufen><de> Wir rufen unsere Freunde in Colombo an und hören erleichtert, dass sie nicht betroffen sind; versenden SMS und E-mails an unsere anderen Bekannten und hören, dass auch sie nicht zu Schaden gekommen sind.
<G-vec00043-002-s555><call.rufen><en> On your arrival back to Otopeni Airport, simply call us at 0786 015 300 / 0786 015 301 and our fast shuttle will wait for you in front of the Departures Terminal, A Zone to transfer you straight back to your car, in the parking place.
<G-vec00043-002-s555><call.rufen><de> Bei der Rückkehr, nachdem Sie die Kontrolle der Dokumente hinter sich haben, während Sie auf Ihr Gepäck warten, rufen Sie uns bei den Telefonnummer 0786 015 300 oder 0786 015 301 an und wir werden vor dem Terminal Abreisen, Zone A anwesend sein, für den Transfer zur AirParking und zur Übernahme Ihres Fahrzeugs.
<G-vec00043-002-s556><call.rufen><en> Harmonic sounds call forth feelings.
<G-vec00043-002-s556><call.rufen><de> Harmonische Töne rufen Gefühle hervor.
<G-vec00043-002-s557><call.rufen><en> Call us or write an e-mail and we will find the perfect package for you.
<G-vec00043-002-s557><call.rufen><de> Rufen Sie uns einfach an oder schreiben Sie uns eine E-Mail und wir finden bestimmt das perfekte Paket für Sie.
<G-vec00043-002-s558><call.rufen><en> Call 800-633-4410 to speak to a Korn Ferry representative or complete the form below.
<G-vec00043-002-s558><call.rufen><de> RUFEN SIE UNS AN UNTER 800-633-4410 UM MIT EINEM KORN FERRY MITARBEITER ZU SPRECHEN.
<G-vec00043-002-s559><call.rufen><en> Schmallenbach, however most people call me Schmalli.
<G-vec00043-002-s559><call.rufen><de> Mein Name ist Volker Schmallenbach, die Meisten rufen mich allerdings Schmalli.
<G-vec00043-002-s560><call.rufen><en> For suites, call (800) 544-9288 in the U.S. and Canada or your nearest Global Contact Center.
<G-vec00043-002-s560><call.rufen><de> Für die Buchung von Suiten rufen Sie aus den USA oder Kanada die Nummer +(1) 800 544 9288 an oder wenden Sie sich an Ihr nächstgelegenes Global Contact Center.
<G-vec00043-002-s561><call.rufen><en> We call upon the International Community to pay close attention to events that unfold within Israel and in the Occupied Territories, to make it absolutely clear that crimes against humanity will not be tolerated, and to take concrete measures to prevent such crimes from taking
<G-vec00043-002-s561><call.rufen><de> Wir rufen die internationale Gemeinschaft auf, die Vorkommnisse in Israel und den Besetzten Gebieten genau zu beobachten, um absolut klar zu machen, dass Verbrechen gegen die Menschheit nicht geduldet werden, sowie konkrete Maßnahmen zu ergreifen, um zu verhindern, dass solche Verbrechen stattfinden.
<G-vec00043-002-s562><call.rufen><en> We urgently call on kind hearted people and international human rights organizations to pay attention to the plight of Falun Gong practitioners, and hope that they will help end the persecution of Falun Gong.
<G-vec00043-002-s562><call.rufen><de> -Rao Wanglai Wir rufen dringend gutherzige Menschen und internationale Menschenrechtsorganisationen auf, der Notlage von Falun Gong-Praktizierenden Aufmerksamkeit zu schenken und hoffen, dass sie mithelfen werden, die Verfolgung von Falun Gong zu beenden.
<G-vec00043-002-s563><call.rufen><en> On the TV, a lot of broadcasts are broadcast, in which doctors call to be vigilant, watch their birthmarks, periodically consult a doctor.
<G-vec00043-002-s563><call.rufen><de> Im Fernsehen werden viele Sendungen ausgestrahlt, in denen Ärzte rufen, wachsam zu sein, ihre Muttermale zu beobachten, regelmäßig einen Arzt aufzusuchen.
<G-vec00043-002-s564><call.rufen><en> We condemn violent conflict in the world, more so violence committed in the name of religion, and call for an end to violent hostility.
<G-vec00043-002-s564><call.rufen><de> Wir verdammen gewaltsame Konflike in der Welt, besonders Gewalt im Namen der Religion und rufen zu einem Ende gewaltsamer Feindschaft auf....
<G-vec00043-002-s565><call.rufen><en> BUT: please call us before, to be sure that we are in.
<G-vec00043-002-s565><call.rufen><de> ABER: bevor Sie kommen, rufen Sie uns an um sicher zu gehen, dass wir auch da sind.
<G-vec00043-002-s566><call.rufen><en> Animal Companion – Your Call Pet additionally summons the first pet from your stable as a second companion to fight by your side.
<G-vec00043-002-s566><call.rufen><de> 'Tierbegleiter' – Euer 'Begleiter rufen' ruft zusätzlich den ersten Begleiter aus eurem Stall herbei, der als zweiter Gefährte an eurer Seite kämpft.
<G-vec00043-002-s567><call.rufen><en> 31Jesus answered them, ‘It is not the healthy who need a doctor, but those who are ill. 32I have not come to call the righteous, but sinners to repentance.’
<G-vec00043-002-s567><call.rufen><de> 31Und Jesus antwortete und sprach zu ihnen: Die Gesunden bedürfen nicht eines Arztes, sondern die Kranken; 32ich bin nicht gekommen, Gerechte zu rufen, sondern Sünder zur Buße.
<G-vec00043-002-s568><call.rufen><en> When the vehicle is going to be used again, the driver can call the vehicle.
<G-vec00043-002-s568><call.rufen><de> Soll das Fahrzeug wieder genutzt werden, kann der Fahrer das Fahrzeug rufen.
<G-vec00043-002-s569><call.rufen><en> Getting Started For additional information or to arrange an appointment to discuss your situation please call us at 518-584-5844 (x) 2311 or email us.
<G-vec00043-002-s569><call.rufen><de> Für weitere Informationen, oder um einen Termin zu vereinbaren und Ihren Fall zu besprechen, rufen Sie bitte Frau Alicia Butler unter der Rufnummer (+1)518-584-5844 (Durchwahl) 2311 an oder schicken Sie uns eine E-Mail.
<G-vec00043-002-s589><call.rufen><en> CALL NOW - +1 416-253-6666 (Toll Free: +1 800-265-8521) and speak to a customer service representative for more info.
<G-vec00043-002-s589><call.rufen><de> RUFEN SIE NOCH HEUTE AN +1 416-253-6666 (Gebührenfrei in Nordamerika: +1 800-265-8521) und erfahren Sie mehr von einem unserer Kundendienstmitarbeiter.
<G-vec00043-002-s590><call.rufen><en> Call the Samsung Contact Centre and ask for remote support.
<G-vec00043-002-s590><call.rufen><de> Rufen Sie das SamsungCallcenter an, und bitten Sie um Fernunterstützung.
<G-vec00043-002-s591><call.rufen><en> Or call the landlord Elisabeth Fihn at 0708-553609.
<G-vec00043-002-s591><call.rufen><de> Oder rufen Sie den Vermieter Elisabeth Fihn unter 0708-553609 an.
<G-vec00043-002-s592><call.rufen><en> German, English Simply call Gebr.
<G-vec00043-002-s592><call.rufen><de> Deutsch, Englisch Rufen Sie Gebr.
<G-vec00043-002-s593><call.rufen><en> Call MUCHO Hotline at 0800 077 800, free from MUCHO, cost of a local call from a fixed telephone.
<G-vec00043-002-s593><call.rufen><de> Rufen Sie den MUCHO Kundendienst an: 0800 077 800, gratis ab MUCHO; Kosten für einen lokalen Anruf ab Fixtelefon.
<G-vec00043-002-s594><call.rufen><en> If you suspect that you have an intestinal blockage, call an ambulance urgently or go to the doctor as soon as possible to prevent any serious complications.
<G-vec00043-002-s594><call.rufen><de> Wenn Sie den Verdacht haben, dass Sie eine Darmblockade haben, rufen Sie dringend einen Krankenwagen oder gehen Sie so schnell wie möglich zum Arzt, um schwerwiegende Komplikationen zu vermeiden.
<G-vec00043-002-s595><call.rufen><en> If you have any interest in tungsten radiation shielding, please feel free to email us: sales@chinatungsten.com or call us by: 0086 592 512 9696, 0086 592 512 9595.
<G-vec00043-002-s595><call.rufen><de> Wenn Sie Interesse an Wolfram Strahlenschutz haben, wenden Sie sich bitte an uns per E-Mail: sales@chinatungsten.com oder rufen Sie uns von: 0086 592 512 9696, 0086 592 512 9595.
<G-vec00043-002-s596><call.rufen><en> If you have questions regarding the EULAs that came with your purchase, please contact an in-store Microsoft Store sales associate or call customer service on 1800 267 785. Microsoft EULAs
<G-vec00043-002-s596><call.rufen><de> Bei Fragen zu den Endbenutzer-Lizenzverträgen, die mit Ihrem Kauf ausgeliefert wurden, wenden Sie sich an einen Mitarbeiter in der Microsoft-Filiale oder rufen Sie den Kundendienst an unter 0800 401065.
<G-vec00043-002-s597><call.rufen><en> If you get a cold or other infection while receiving Arava, call your doctor or health care professional.
<G-vec00043-002-s597><call.rufen><de> Wenn Sie eine Erkältung oder eine andere Infektion bekommen, während Sie dieses Medikament nehmen, rufen Sie Ihren Arzt oder Ärztin.
<G-vec00043-002-s598><call.rufen><en> Or call the landlord Linda Lindell at 070-5098939.
<G-vec00043-002-s598><call.rufen><de> Oder rufen Sie den Vermieter Linda Lindell unter 070-5098939 an.
<G-vec00043-002-s599><call.rufen><en> You can send us an email to contact@casas-ambiente.com or call us at +34 966 498 595.
<G-vec00043-002-s599><call.rufen><de> Sie können uns eine E-Mail senden an contact@casas-ambiente.com oder rufen Sie uns an unter +34 966 498 595.
<G-vec00043-002-s600><call.rufen><en> Use our freight fare search to find prices and information online or call now and talk to our knowledgeable freight ferry team for bookings and advice. If you aren’t carrying freight and are looking to make a tourist booking then please visit our Fishbourne Portsmouth Ferry page instead.
<G-vec00043-002-s600><call.rufen><de> Nutzen Sie unsere Frachfährensuche um Preise und Informationen online zu finden oder rufen Sie uns an um mit unseren Frachtexperten über Buchungen und Informationen zu sprechen Wenn Sie keine Fracht transportieren und eine normale Touristenbuchung durchführen wollen, besuchen Sie bitte unsere Fishbourne Portsmouth Fähre Seite.
<G-vec00043-002-s601><call.rufen><en> Refine your search or call us on +31(0)184 60 13 48.
<G-vec00043-002-s601><call.rufen><de> Präzisieren Sie Ihre Suche oder rufen Sie uns an: +31 (0) 184-60 13 48.
<G-vec00043-002-s602><call.rufen><en> Or call the landlord Malin Andersson at 0414-30938 (0706-640306).
<G-vec00043-002-s602><call.rufen><de> Oder rufen Sie den Vermieter Malin Andersson unter 0414-30938 (0706-640306) an.
<G-vec00043-002-s603><call.rufen><en> Contact For all inquiries and reservations, call the Villa Giulia, or send an email via the contact form.
<G-vec00043-002-s603><call.rufen><de> Kontakt Für alle Anfragen und Reservierungen rufen Sie die Villa Giulia an oder senden Sie eine E-Mail über das Kontaktformular.
<G-vec00043-002-s604><call.rufen><en> Please call us on 0800 330 8011, email us on groupsgrv@amba-hotel.com or use the contact form provided.
<G-vec00043-002-s604><call.rufen><de> Bitte rufen Sie uns an unter 0800 330 8011, senden Sie uns eine E-Mail an groupsgrv@amba-hotel.com oder verwenden Sie das bereitgestellte Kontaktformular.
<G-vec00043-002-s605><call.rufen><en> If this does not help, call your firewall settings or from the standard “control Panel”, or via the menu “Run” command firewall.cpl, and completely unplug.
<G-vec00043-002-s605><call.rufen><de> Wenn das nicht hilft, rufen Sie die Firewall-Einstellungen entweder von Standard „Control Panel” oder über das Menü „Run“ Befehl firewall.cpl ein, und deaktivieren Sie ihn vollständig.
<G-vec00043-002-s606><call.rufen><en> Please call the hotel no later than 18:00 on the day of arrival if you wish to check in later.
<G-vec00043-002-s606><call.rufen><de> Bitte rufen Sie das Hotel am Tag Ihrer Ankunft bis spätestens 18:00 Uhr an, falls Sie später einchecken wollen.
<G-vec00043-002-s607><call.rufen><en> • Reporting: Call your test results from a button.
<G-vec00043-002-s607><call.rufen><de> • Reporting: Rufen Sie Ihre Prüfergebnisse auf Knopfdruck ab.
