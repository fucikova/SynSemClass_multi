<EnglishT-wsj_0467-s24#EnglishT-wsj_0467-s24-t9><ev-w109f2.v-w5882f1> ``I've read Balzac<start_vauxs>,<end_vauxs>'' he <start_vs>answers<end_vs> critics <start_vauxs>.<end_vauxs> 
<EnglishT-wsj_0800-s39#EnglishT-wsj_0800-s39-t16><ev-w109f2.v-w2834f1> ``You should know what questions to ask to get people <start_vauxs>to<end_vauxs> <start_vs>answer<end_vs>.'' 
<EnglishT-wsj_0909-s1#EnglishT-wsj_0909-s1-t20><ev-w109f2.v-w1051f3> Call Jim Wright's office in downtown Fort Worth, Texas, these days and the receptionist still <start_vs>answers<end_vs> the phone, ``Speaker Wright's office.'' 
<EnglishT-wsj_0989-s11#EnglishT-wsj_0989-s11-t6><ev-w109f2.v-w2834f1> Anybody with a mailbox <start_vauxs>can<end_vauxs> <start_vs>answer<end_vs> that: sheer, overwhelming, mind-numbing volume. 
