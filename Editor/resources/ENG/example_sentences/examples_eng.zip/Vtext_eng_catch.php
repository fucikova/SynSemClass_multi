<G-vec00185-001-s019><catch.auffangen><en> Various large wooden plateaux are phased into a small fountain tower with several water pumps, between the joints there are wide water gutters to catch and channel the water.
<G-vec00185-001-s019><catch.auffangen><de> Zu einem kleinen Brunnenturm mit mehreren Wasserpumpen staffeln sich verschieden große Holzplateaus, zwischen den Fugen befinden sich breite Wasserrinnen zum Auffangen und Leiten des Wassers.
<G-vec00185-001-s020><catch.auffangen><en> “If the Captain wants to push you down a cliff because of this, we will secretly catch you at the bottom,” Ed comforted him.
<G-vec00185-001-s020><catch.auffangen><de> „Wenn der Hauptmann dich deshalb von einer Klippe werfen will, werden wir dich heimlich unten auffangen“, tröstete ihn Ed.
<G-vec00185-001-s021><catch.auffangen><en> The inflection at the underside should catch the forces, that occur in the context of the Doll, and should refer.
<G-vec00185-001-s021><catch.auffangen><de> Die Biegung an der Unterseite soll die Kräfte, die im Zusammenhang mit der Doll auftreten auffangen und weiterleiten.
<G-vec00185-001-s022><catch.auffangen><en> The blood spouts in a heavy fountain from his carotid artery, and before anyone can catch him he sinks backward into the dust.
<G-vec00185-001-s022><catch.auffangen><de> Das Blut schießt in schwerer Fontäne aus dem Schnitt hervor, ehe ihn noch jemand auffangen kann, sinkt er nach rückwärts in den tiefen Staub.
<G-vec00185-001-s023><catch.auffangen><en> The glass pearl is a symbol of our fragility... the red silk ribbon symbolizes our family and friends the often catch us in difficult situations of our lives...
<G-vec00185-001-s023><catch.auffangen><de> Art Die Glaskugel ist Symbol unsere Zerbrechlichkeit...das rote Seidenband symbolisiert unsere Familie und Freunde die uns in den schwierigen Situationen unseres Lebens auffangen...
<G-vec00185-001-s024><catch.auffangen><en> What I considered as bad was that I could not catch in my consciousness the commands he was issuing, since the king of Maros, as I had to admit, disposed of the same ability as I had: He could conceal his words to his own mind.
<G-vec00185-001-s024><catch.auffangen><de> Und ich hielt für schlimm, daß ich seine Befehle in meinem Bewusstsein nicht auffangen konnte, denn, wie ich feststellte, der König der Maros verfügt über dieselbe Fähigkeit wie ich: Er weiß, seinem eigenen Sinn seine Worte zu verbergen; hier wandte er diese Fähigkeit vor dem Feind an.
<G-vec00185-001-s025><catch.auffangen><en> Filters are made of fine nylon mesh to catch dust effectively without airflow performance penalty.
<G-vec00185-001-s025><catch.auffangen><de> Filter sind zum effektiven Auffangen von Staub ohne Einbußen bei der Luftstromleistung aus einem feinen Nylongitter hergestellt.
<G-vec00185-001-s026><catch.auffangen><en> Fillet the oranges over a plate or bowl to catch the juice.
<G-vec00185-001-s026><catch.auffangen><de> Die Orangen über einem Teller oder einer Schüssel filetieren und den Saft auffangen.
<G-vec00185-001-s027><catch.auffangen><en> It also features a kief screen so you can catch and collect trichomes.
<G-vec00185-001-s027><catch.auffangen><de> Er weist außerdem ein Kiefsieb auf, sodass Du Trichome auffangen und sammeln kannst.
<G-vec00185-001-s028><catch.auffangen><en> 'Catch me' referred to my consciousness versus my body.
<G-vec00185-001-s028><catch.auffangen><de> 'Auffangen' bezog sich auf mein Bewusstsein anstatt meinen Körper.
<G-vec00185-001-s029><catch.auffangen><en> The proclamation of the three articles of faith of the Evangelical Lutheran Church and their explanation in the church catechism are so massive and compact that they can, like a shield, catch and extinguish the fiery darts of the evil one.
<G-vec00185-001-s029><catch.auffangen><de> Die Proklamation der drei Artikel unseres Glaubens und ihrer Erklärung im Katechismus sind so massiv und dicht, dass sie wie ein Schild die feurigen Pfeile des Bösewichts auffangen und auslöschen können.
<G-vec00185-001-s030><catch.auffangen><en> As it was virtually impossible to draw sufficient water from a well given the nature of the sites, ingenious systems were designed to catch rain water, filter it through sand and store it in cisterns in numerous castles.
<G-vec00185-001-s030><catch.auffangen><de> Da der Bau von Brunnen angesichts der natürlichen Gegebenheiten praktisch unmöglich war, wurden in vielen Schlössern findige Systeme zum Auffangen des Regenwassers eingerichtet; das Wasser wurde mit Sand gefiltert und in Zisternen aufbewahrt.
<G-vec00185-001-s031><catch.auffangen><en> "Since centuries, princes, presidents, bankers are make catch up with by inflation, but not our ""geniuses""."
<G-vec00185-001-s031><catch.auffangen><de> Seit Jahrhunderten sind Prinzen, Präsidenten, Bankiers(Bankhalter), lass von der Inflation auffangen, aber nicht unsere Genies.
<G-vec00185-001-s032><catch.auffangen><en> the often catch us in difficult situations of our lives...
<G-vec00185-001-s032><catch.auffangen><de> und Freunde die uns in den schwierigen Situationen unseres Lebens auffangen...
<G-vec00185-001-s033><catch.auffangen><en> There are people to catch anyone who falls so none should be hurt.
<G-vec00185-001-s033><catch.auffangen><de> Es sind Leute da, die jene auffangen, die fallen, damit niemand sich verletzt.
<G-vec00185-001-s034><catch.auffangen><en> Savor the pure pleasure of flavours that catch your mood and match the moment.
<G-vec00185-001-s034><catch.auffangen><de> Genießen Sie pure Aromen, die Ihre Stimmung auffangen und zu dem Moment passen.
<G-vec00185-001-s035><catch.auffangen><en> Behold, he shall fall with none to catch him, and great shall be his fall!...
<G-vec00185-001-s035><catch.auffangen><de> Schaut, er wird fallen und Niemand wird ihn auffangen und gross wird sein Fall sein!...
<G-vec00185-001-s036><catch.auffangen><en> Die Welt sees the ABM project in Poland and Czechia as systems to catch the last remnants of Russian nuclear missiles after a US first strike against Russia.
<G-vec00185-001-s036><catch.auffangen><de> """Die Welt"" sieht das ABM-Projekt in Polen und Tschechien als Systeme zum Auffangen der letzten Reste der russischen Atomraketen nach einem US-Erstschlag gegen Russland ."
<G-vec00185-001-s037><catch.aufholen><en> At some point, and the rest of Russia is beginning to catch up with the capital, but still this is slower and there is still a difference.
<G-vec00185-001-s037><catch.aufholen><de> Irgendwann, und dem restlichen Russland ist beginnend mit der Hauptstadt, aber immer noch das aufholen ist langsamer und es gibt noch einen Unterschied.
<G-vec00185-001-s038><catch.aufholen><en> """Following the forthcoming EU enlargement, I expect Romania and Bulgaria to catch up quickly."
<G-vec00185-001-s038><catch.aufholen><de> """Nach der bevorstehenden EU-Erweiterung werden Rumänien und Bulgarien sicher rasch aufholen."
<G-vec00185-001-s039><catch.aufholen><en> But when someone is so far ahead of his time, and always has been, as it's the case with the 25-year-old rapper, it's alright to lean back and allow the competitors to catch up – and at the same time, he still defends his grounds, like with this little EP.
<G-vec00185-001-s039><catch.aufholen><de> Wenn man wie der 25-Jährige aber schon so lange und so weit seiner Zeit voraus ist, dann kann man die Konkurrenz ganz zurückgelehnt auch mal etwas aufholen lassen – und mit einer kleinen EP wie dieser trotzdem vorlegen.
<G-vec00185-001-s040><catch.aufholen><en> To avoid the ongoing havoc and keep the economy growing, the Panamanian Government sent out an SOS to find quick, reliable, cost-effective interim power until the permanent energy grid could catch up.
<G-vec00185-001-s040><catch.aufholen><de> Um anhaltendes Chaos zu vermeiden, und die Wirtschaft weiter wachsen zu lassen, sendete die Regierung von Panama einen Hilferuf aus, um schnelle, zuverlässige, kostengünstige Stromversorgung auf Zeit zu finden, bis das dauerhafte Energienetz aufholen konnte.
<G-vec00185-001-s041><catch.aufholen><en> Sooner or later digital cameras will catch up, since there is a lot of research and development spended in digital cameras compared to scanners. in one point the photographing method is leading: The speed is significantly higher compared to a classic scan.
<G-vec00185-001-s041><catch.aufholen><de> Über kurz oder lang werden die Digitalkameras hier sicher aufholen, zumal bei Digitalkameras ja im Gegensatz zu der eher konservativen Scanner-Industrie erheblich in Forschung und Entwicklung investiert wird.
<G-vec00185-001-s042><catch.aufholen><en> The company expects to catch up with revenues in the second half of the year and that the earnings will also be better.
<G-vec00185-001-s042><catch.aufholen><de> Das Unternehmen geht davon aus, im zweiten Halbjahr bei der Leistung aufholen zu können und dass sich damit auch das Ergebnis besser entwickelt.
<G-vec00185-001-s043><catch.aufholen><en> But consciousness can catch up with a bang. That is the real meaning of a revolution.
<G-vec00185-001-s043><catch.aufholen><de> Aber das Bewusstsein kann mit einem Ruck aufholen – das ist die wahre Bedeutung einer Revolution.
<G-vec00185-001-s044><catch.aufholen><en> Sonos determinedly stayed the course, making key bets on next-generation systems and technologies with the conviction that consumers would catch up.
<G-vec00185-001-s044><catch.aufholen><de> Sonos blieb konsequent auf Kurs und setzte auf Systeme und Technologien der nächsten Generation in der Überzeugung, dass die Verbraucher aufholen würden.
<G-vec00185-001-s045><catch.aufholen><en> The guests were able to win the third quarter with 20:18, but did not catch up decisively.
<G-vec00185-001-s045><catch.aufholen><de> Das dritte Viertel konnten die Gäste mit 20:18 knapp für sich entscheiden, aber nicht entscheidend aufholen.
<G-vec00185-001-s046><catch.aufholen><en> If the mortgage will, sooner or later volumes of the regional market will catch up capital indicators, and the market it will be very attractive, and therefore highly competitive.
<G-vec00185-001-s046><catch.aufholen><de> Wenn die Hypothek wird, früher oder spГ¤ter BГ¤nde der regionalen Markt aufholen Hauptstadt Indikatoren und der Markt wird es sehr attraktiv, und daher hart umkГ¤mpft.
<G-vec00185-001-s047><catch.aufholen><en> Seeing how others cultivate, we should figure out how we can catch up.
<G-vec00185-001-s047><catch.aufholen><de> Man schaut, wie sich die anderen kultiviert haben und wie wir selbst aufholen können.
<G-vec00185-001-s048><catch.aufholen><en> We need to catch up a bit.
<G-vec00185-001-s048><catch.aufholen><de> Wir müssen etwas aufholen.
<G-vec00185-001-s049><catch.aufholen><en> One of the main reasons it was unforgettable was the ability to go out for a nice ride on the boat and catch up a whole bunch of smallmouth bass.
<G-vec00185-001-s049><catch.aufholen><de> Einer der Hauptgründe war, war es unvergesslich die Fähigkeit, auf dem Boot für eine schöne Fahrt zu gehen und eine ganze Reihe von Schwarzbarsch aufholen.
<G-vec00185-001-s050><catch.aufholen><en> Retail still needs to catch up in the IT sector, but also in terms of sustainability – huge potential savings in money and resources are laying idle here.
<G-vec00185-001-s050><catch.aufholen><de> Nicht nur im Bereich IT, sondern besonders auch im Bereich Nachhaltigkeit muss der Handel noch weiter aufholen - zu viele Einsparmöglichkeiten und Ressourcen sparende Potenziale liegen hier brach.
<G-vec00185-001-s051><catch.aufholen><en> The German coin trade by tradition makes up a large part of the exhibitors at the New York International, although Italy and Spain in particular have started to catch up in recent years.
<G-vec00185-001-s051><catch.aufholen><de> Der deutschsprachige Münzhandel stellt traditionell einen großen Teil der Aussteller auf der New York International, wobei in den letzten Jahren vor allem Spanien und Italien aufholen.
<G-vec00185-001-s052><catch.aufholen><en> Harrison was faster and was able to catch up for 1.4 seconds.
<G-vec00185-001-s052><catch.aufholen><de> Harrison war aber schneller und konnte schon 1,4 Sekunden aufholen.
<G-vec00185-001-s053><catch.aufholen><en> Go down the hill and help Scooby catch up with shaggy.
<G-vec00185-001-s053><catch.aufholen><de> Gehen Sie den Hügel hinunter und Hilfe Scooby aufholen shaggy.
<G-vec00185-001-s054><catch.aufholen><en> As Intel low-power chips appear in more devices, more app producers will optimize for them, and the big players (who make the most desirable apps) are likely to catch up quickly.
<G-vec00185-001-s054><catch.aufholen><de> Wie Intel Low-Power-Chips kommen in mehr Geräte, mehr App-Hersteller werden für sie optimieren, und die großen Spieler (die machen die begehrtesten Anwendungen) werden wahrscheinlich schnell aufholen.
<G-vec00185-001-s055><catch.aufholen><en> It was good to know about the latest marketing trends in 2018 will catch up with the listed trends to grow our as well as our clients business to a totally different dimension at all.
<G-vec00185-001-s055><catch.aufholen><de> Es war gut, sich über die neuesten Marketing-Trends kennen 2018 werde mit den genannten Trends aufholen unser sowie unser Kundengeschäft zu einer völlig anderen Dimension wachsen überhaupt.
<G-vec00185-001-s056><catch.auffangen><en> Of course he also tried to catch some of it with his mouth, but he failed miserably.
<G-vec00185-001-s056><catch.auffangen><de> Natürlich versuchte er auch etwas davon mit dem Mund aufzufangen, scheiterte aber kläglich.
<G-vec00185-001-s057><catch.auffangen><en> Dip the top of each cooled doughnut into the glaze and place on a cooling rack that is over a baking sheet to catch the drips.
<G-vec00185-001-s057><catch.auffangen><de> Tauchen Sie die Spitze jedes gekühlt Donut in die Glasur und auf einem Rack-Kühlung, die über ein Backblech ist es, die Tropfen aufzufangen.
<G-vec00185-001-s058><catch.auffangen><en> Then we will be able to catch with open arms the wondrous opportunities which will then appear.
<G-vec00185-001-s058><catch.auffangen><de> Dann sind wir in der Lage mit offenen Armen die wunderbaren Gelegenheiten aufzufangen, welche dann erscheinen werden.
<G-vec00185-001-s059><catch.auffangen><en> It is possible to catch a glimpse of the city through the panels from the garage, while at the same time the screened panels draw the attention on the outside.
<G-vec00185-001-s059><catch.auffangen><de> Es ist möglich aus der Garage durch die Paneele einen Schimmer von der Stadt aufzufangen, während von außen gesehen gerade die durchleuchteten Paneele die Aufmerksamkeit auf sich ziehen.
<G-vec00185-001-s060><catch.auffangen><en> But if we are standing strong as a True One with our hands open in readiness to embrace the New, then we will be free to catch melon after melon after melon.
<G-vec00185-001-s060><catch.auffangen><de> Aber wenn wir kräftig als Wahre Eine stehen, mit offenen Händen bereit das Neue zu umarmen, werde wir frei sein Melone nach Melone nach Melone aufzufangen.
<G-vec00185-001-s061><catch.auffangen><en> Our polish friend was on his way with antenna and receiver to catch the signals of tagged cranes.
<G-vec00185-001-s061><catch.auffangen><de> Und unser polnischer Freund war mit Antenne und Empfangsgerät unterwegs, um die Signale besenderter Kraniche aufzufangen.
<G-vec00185-001-s062><catch.auffangen><en> The system includes natural water purification and, moreover, has sufficient capacity to catch excess rainwater temporarily, thereby helping to prevent flooding.
<G-vec00185-001-s062><catch.auffangen><de> Außerdem verfügt das System über eine große Kapazität um temporär angesammeltes überflüssiges Regenwasser aufzufangen und somit Überschwemmungen frühzeitig vermieden werden können.
<G-vec00185-001-s063><catch.auffangen><en> It consists of a 220 micron screen and a 70 micron screen to filter out the waste and catch your crystals.
<G-vec00185-001-s063><catch.auffangen><de> Er besteht aus einem 220 Mikrometer und einem 70 Mikrometer Sieb, um die Abfälle herauszufiltern und Deine Kristalle aufzufangen.
<G-vec00185-001-s064><catch.auffangen><en> Both are aware of this proverb and, the longer the boys try to catch a leaf, the more Leung’s wish becomes apparent.
<G-vec00185-001-s064><catch.auffangen><de> Sie kennen das Sprichwort, und je länger die Jungen versuchen, ein Blatt aufzufangen, desto deutlicher tritt Leungs Wunsch hervor.
<G-vec00185-001-s065><catch.auffangen><en> Jeff Bezos, the world's richest man, will be there to catch it.
<G-vec00185-001-s065><catch.auffangen><de> Jeff Bezos, der reichste Mann der Welt, wird da sein, um es aufzufangen.
<G-vec00185-001-s066><catch.auffangen><en> Before the plum falls, position yourself under it to catch it.
<G-vec00185-001-s066><catch.auffangen><de> Bevor sie nach unten fällt, müsst ihr euch darunter stellen, um sie aufzufangen.
<G-vec00185-001-s067><catch.auffangen><en> cried her mother, flying towards her, weeping and stretching out her arms to catch her daughter.
<G-vec00185-001-s067><catch.auffangen><de> """, schrie ihre Mutter, als sie unter Tränen mit ausgestreckten Armen zu ihr flog um ihre Tochter aufzufangen."
<G-vec00185-001-s068><catch.auffangen><en> Luckily, the knights around them managed to catch the crown prince in time, so His Highness didn’t fall to the floor.
<G-vec00185-001-s068><catch.auffangen><de> Glücklicherweise schafften es die königlichen Ritter in ihrer Nähe den Kronprinz rechtzeitig aufzufangen, sodass Seine Hoheit nicht zu Boden fiel.
<G-vec00185-001-s069><catch.auffangen><en> """The system on our Open Chat option is already designed to catch any obvious swear words and inappropriate comments, but it can also break codes and screen out hidden methods players might sometimes use in an effort to get past the filter and bully or harass another participant,"" says Merrifield."
<G-vec00185-001-s069><catch.auffangen><de> „Das System unserer offenen Chat-Option ist bereits dafür ausgelegt, alle offensichtlichen Schimpfwörter und unangemessenen Kommentare aufzufangen, aber es kann zudem auch Codes knacken und versteckte Methoden aussondern, die Spieler vielleicht manchmal benutzen, um dem Filter zu entgehen und andere Teilnehmer zu schikanieren oder zu belästigen“, so Merrifield.
<G-vec00185-001-s070><catch.auffangen><en> Try to catch all treasures and stuff that falls from above.
<G-vec00185-001-s070><catch.auffangen><de> Versuche alle Schätze und Extras, die von oben herab fallen aufzufangen.
<G-vec00185-001-s071><catch.auffangen><en> Of particular note is the recent weakness, presenting the dreaded conundrum of ‘trying to catch a falling knife.’
<G-vec00185-001-s071><catch.auffangen><de> Besonders hervorzuheben ist die jüngste Schwäche, die das gefürchtete Dilemma des Versuchs,'ein fallendes Messer aufzufangen', darstellt.
<G-vec00185-001-s072><catch.auffangen><en> One decision was during delivery that no one was there to 'catch me' at delivery.
<G-vec00185-001-s072><catch.auffangen><de> Eine Entscheidung war während der Entbindung dass niemand da war um mich bei der Geburt 'aufzufangen'.
<G-vec00185-001-s073><catch.auffangen><en> Then they suddenly held their sceptres on high and tossed them in the air to the Bridges -- some of whom ducked out of old reflex patterns so they wouldn't have to catch them.
<G-vec00185-001-s073><catch.auffangen><de> Dann hielten sie plötzliche ihre Szepter hoch und warfen sie in die Luft Richtung Brücken - von denen sich einige aus einem alten Reflex heraus weg duckten um sie nicht aufzufangen.
<G-vec00185-001-s074><catch.auffangen><en> Try to catch in the mirror light beam.
<G-vec00185-001-s074><catch.auffangen><de> Versuchen Sie, in den Spiegel Lichtstrahl aufzufangen.
<G-vec00185-001-s075><catch.aufholen><en> I’m also afraid that in the coming wave, which is even more about data and which is subsumed under AI, it will be difficult for us to catch up.
<G-vec00185-001-s075><catch.aufholen><de> Ich fürchte auch in der kommenden Welle, in der es noch mehr um Daten geht und die unter KI/AI subsumiert ist, wird es uns schwer fallen die Rückstände aufzuholen.
<G-vec00185-001-s076><catch.aufholen><en> Then back to work to catch up.
<G-vec00185-001-s076><catch.aufholen><de> Dann zurück zur Arbeit, um wieder aufzuholen.
<G-vec00185-001-s077><catch.aufholen><en> Great Software: What amazed me when I got back after the shutdown is that their software is still the best, even after giving rivals 16 months to catch up.
<G-vec00185-001-s077><catch.aufholen><de> Tolle Software:Was mich begeistert hat, nachdem ich nach der Stilllegung der Seite zurückgekommen bin, war, dass ihre Software immer noch die beste war, sogar nachdem die Konkurrenz 16 Monate hatte um aufzuholen.
<G-vec00185-001-s078><catch.aufholen><en> Falun Gong practitioners are trying hard to maintain or catch up with the progress of the Fa-rectification.
<G-vec00185-001-s078><catch.aufholen><de> Falun Gong-Praktizierende bemühen sich sehr, mit dem Prozess der Fa-Berichtigung Schritt zu halten oder aufzuholen.
<G-vec00185-001-s079><catch.aufholen><en> Angry about that me and that confusion i drove again out on the track with the aim to catch up the lost time.
<G-vec00185-001-s079><catch.aufholen><de> Verärgert über mich und diese Verwechslung fuhr ich wieder hinaus auf die Strecke mit dem Ziel, die verloren gegangene Zeit wieder aufzuholen.
<G-vec00185-001-s080><catch.aufholen><en> Rather topping slows vertical growth down allowing side branches to catch up while two new top colas are emerging.
<G-vec00185-001-s080><catch.aufholen><de> Vielmehr verlangsamt das Topping den vertikalen Wuchs und ermöglicht so den Seitenzweigen aufzuholen, während zwei neue Haupt-Colas entstehen.
<G-vec00185-001-s081><catch.aufholen><en> It managed the impossible bet to catch up and surpass the 315% increase in the gold price in dollars.
<G-vec00185-001-s081><catch.aufholen><de> "Buch, mit 324%, sie das Unmögliche Wette, um aufzuholen und übertreffen die 315% ige Erhöhung der Goldpreis in Dollar verwaltet, ist der Euro das letzte Gold "", mit einer kleine ""183%."
<G-vec00185-001-s082><catch.aufholen><en> Keep clicking on the penguin so as to catch it up and bounce it upwards until it breaks the ice and lands successfully.
<G-vec00185-001-s082><catch.aufholen><de> Halten Sie auf den Pinguin, um ihn aufzuholen und hüpfen sie nach oben, bis er das Eis bricht und landet erfolgreich.
<G-vec00185-001-s083><catch.aufholen><en> So let's take a tour around your Ecwid store to catch up with the updates of the last three months.
<G-vec00185-001-s083><catch.aufholen><de> Also lassen Sie sich eine Tour um den Ecwid Speicher, um aufzuholen mit dem Updates der letzten drei Monate.
<G-vec00185-001-s084><catch.aufholen><en> In summary: Renzi is at a disadvantage, but retains the opportunity to catch up.
<G-vec00185-001-s084><catch.aufholen><de> Zusammengefasst: Renzi ist im Nachteil, aber behält die Möglichkeit aufzuholen.
<G-vec00185-001-s085><catch.aufholen><en> The males who’re overwhelmed to catch up the proper item frequently drop for your bogus products which are created up of cheap ingredients and inefficient formula.
<G-vec00185-001-s085><catch.aufholen><de> Die Männer, die überfordert, um aufzuholen den richtigen Artikel sind häufig fallen für Ihre gefälschte Produkte, die aus billigen Zutaten und ineffizient Formel erstellt werden.
<G-vec00185-001-s086><catch.aufholen><en> And most of them just buy a new phone in order to catch up with the latest fashion or show their loyalty to some particular brand, like Apple or Samsung.
<G-vec00185-001-s086><catch.aufholen><de> Und die meisten von ihnen nur ein neues Telefon kaufen, um mit der neuesten Mode, um aufzuholen oder zeigen ihre Treue zu einem bestimmten Marke, wie Apple oder Samsung.
<G-vec00185-001-s087><catch.aufholen><en> "At the current rate, it would take 15 years to catch up,"" concludes Ludovic Subran."
<G-vec00185-001-s087><catch.aufholen><de> "Bei der aktuellen Rate würde es 15 Jahre dauern, aufzuholen,"" schließt Ludovic Subran."
<G-vec00185-001-s088><catch.aufholen><en> In truth, I had been expecting to receive money that would allow me to catch up on the mortgage and resume payments.
<G-vec00185-001-s088><catch.aufholen><de> In Wahrheit, ich erwartet hatte, Geld zu erhalten, die mich auf die Hypothek aufzuholen erlauben würde und Zahlungen wieder aufzunehmen.
<G-vec00185-001-s089><catch.aufholen><en> "Do not ""double-up"" the dose to catch up."
<G-vec00185-001-s089><catch.aufholen><de> "Verdoppeln Sie sich ""nicht hinauf"" die Dosis aufzuholen."
<G-vec00185-001-s090><catch.aufholen><en> After the 'Big Bang' at REWE Germany, it was now time for REWE DORTMUND to catch up.
<G-vec00185-001-s090><catch.aufholen><de> Nach dem ›Big Bang‹ der REWE Deutschland war es auch für die REWE DORTMUND an der Zeit, aufzuholen.
<G-vec00185-001-s091><catch.aufholen><en> Both objects where flying fast and high, one of them sped up as to catch up with the other.
<G-vec00185-001-s091><catch.aufholen><de> Beide Objekte in dem, mit dem anderen aufzuholen beschleunigt fliegen schnell und hoch, einer von ihnen.
<G-vec00185-001-s092><catch.aufholen><en> When you are committed to Me, you do not have to catch up.
<G-vec00185-001-s092><catch.aufholen><de> Sobald du Mir verschrieben bist, hast du nicht aufzuholen.
<G-vec00185-001-s093><catch.aufholen><en> I am planning to take my fiance there in July because i was so touched by the families that work there and I want her to experience what I went through and I can't wait to catch up with my old friends again. Love this place!
<G-vec00185-001-s093><catch.aufholen><de> Ich plane, mein Verlobter dort im Juli, weil ich war so begeistert von den Familien, die dort arbeiten, und ich will, dass sie erleben, was ich durchgemacht habe, und ich kann nicht warten, um aufzuholen mit meinen alten Freunden wieder berührt.
<G-vec00185-001-s094><catch.bekommen><en> But for others it's even worse because if you use your anger in that manner then that person might be just frightened of you, might develop inferiority complex, might become a left sided person, might catch some bhoots or God knows what can happen to a person who has somebody all the time shouting at him.
<G-vec00185-001-s094><catch.bekommen><de> "Aber für andere ist es sogar schlimmer, denn wenn ihr euren Ärger so benutzt, können andere Angst vor euch haben, Minderwertigkeits- komplexe entwickeln, könnten zu ""linksseitig"" werden, Bhoots oder weiß Gott was bekommen, wenn jemand dauernd mit ihnen schreit oder das Schlimmste, was physisch passieren könnte, ist, dass sie taub werden."
<G-vec00185-001-s095><catch.bekommen><en> It takes a lot more to really catch a cold.
<G-vec00185-001-s095><catch.bekommen><de> Um eine Erkältung zu bekommen, muss mehr geschehen.
<G-vec00185-001-s096><catch.bekommen><en> There are many ways to catch a taxi in Porto, from ranks, phones or via the many apps available.
<G-vec00185-001-s096><catch.bekommen><de> Es gibt viele Möglichkeiten, ein Taxi in Porto zu bekommen: von den Taxiständen, per Telefon oder über die vielen verfügbaren Apps.
<G-vec00185-001-s097><catch.bekommen><en> But the fleas are really not on my beloved pet, and earlier I used the Kiltix collar, my dog did not catch a single tick.
<G-vec00185-001-s097><catch.bekommen><de> Aber die Flöhe sind wirklich nicht auf meinem geliebten Haustier und früher habe ich das Kiltix-Halsband benutzt, und mein Hund hat keine einzige Zecke bekommen.
<G-vec00185-001-s098><catch.bekommen><en> It is important to remember that many of them had sonorous titles, but not ground possession, and were therefore full of determination to catch them in the east.
<G-vec00185-001-s098><catch.bekommen><de> Es ist wichtig, sich zu erinnern, dass viele ihnen die klangvollen Titel hatten, aber nicht war der Landbesitz, und diesem der Entschlossenheit voll, sie im Osten zu bekommen.
<G-vec00185-001-s099><catch.bekommen><en> If the first two weeks after the surgery were still necessary to cope with the sheer physical challenges, after this time, she re-learns to catch a bus and to move around in the crowd.
<G-vec00185-001-s099><catch.bekommen><de> Waren die ersten zwei Wochen nach der Operation notwendig, die schieren Körperlichkeiten in den Griff zu bekommen, so kann sie nach dieser Zeit wieder Bus fahren und sich auch wieder besser in den Menschenmassen bewegen.
<G-vec00185-001-s100><catch.bekommen><en> However, if you have to invest too large a part of the effective stack in the call, you won't be getting the correct price to try to catch a favourable flop.
<G-vec00185-001-s100><catch.bekommen><de> Wenn du jedoch mit einem Call einen zu großen Teil deines effektiven Stacks investiert hast, erhältst du nicht den richtigen Preis, um einen lohnenswerten Versuch auf einen guten Flop zu bekommen.
<G-vec00185-001-s101><catch.bekommen><en> In such cases, there is too high a chance to catch the infection.
<G-vec00185-001-s101><catch.bekommen><de> In solchen Fällen ist die Chance, die Infektion zu bekommen, zu groß.
<G-vec00185-001-s102><catch.bekommen><en> But the servants said that they had obtained a secret from a foreign fisherman of how to catch such fish even outside the winter season, and the fish were the truest witnesses that the secret was working.
<G-vec00185-001-s102><catch.bekommen><de> Aber die Knechte sagten, sie seien durch einen fremden Fischer auf ein Geheimnis gekommen, derlei Fische auch außer der Winterszeit zu bekommen, und die Fische seien die sichersten Zeugen, dass sich das Geheimnis bewähre.
<G-vec00185-001-s103><catch.bekommen><en> For the next few hours we all try to find a way to catch some of sleep, not an easy thing to do on the wooden floor or in the wicker chairs.
<G-vec00185-001-s103><catch.bekommen><de> Während der nächsten Stunden versuchen wir alle, noch ein wenig Schlaf zu bekommen, aber dies ist auf dem Holzfußboden oder in den Strandkörben nicht so einfach.
<G-vec00185-001-s104><catch.bekommen><en> At the end of the week, as we were unsure we'd be able to leave because of the volcano eruption, he offered we stay until we catch a flight, at no additional cost. We were deeply touched by this offer.
<G-vec00185-001-s104><catch.bekommen><de> Als wir am Ende des Aufenthaltes nicht sicher waren, ob wir aufgrund des Vulkans abreisen konnten, hat er uns angeboten solange in der Wohnung wohnen zu bleiben, bis wir einen Flug bekommen würden und das ohne zusätzliche Kosten.
<G-vec00185-001-s105><catch.bekommen><en> For a frontal shot of the group with a 28mm lens on an APS chip camera you need to step back almost 9 meters to catch the 7 pairs.
<G-vec00185-001-s105><catch.bekommen><de> Für eine frontale Aufnahme mit einem 28mm Objektiv auf einer APS-Chip Kamera muss der Fotograf fast 9 Meter zurücktreten, um die 7 Paare in‘s Bild zu bekommen.
<G-vec00185-001-s106><catch.bekommen><en> “Fine, thank you,” she murmurs still trying to catch her breath.
<G-vec00185-001-s106><catch.bekommen><de> „Gut, Danke“, murmelt sie und versucht immer noch ihren Atem unter Kontrolle zu bekommen.
<G-vec00185-001-s107><catch.bekommen><en> UTIs are not infectious and you cannot catch one from somebody else.
<G-vec00185-001-s107><catch.bekommen><de> Harnwegsinfekte sind nicht ansteckend, daher kannst du sie nicht von jemand anderem bekommen.
<G-vec00185-001-s108><catch.bekommen><en> Nevertheless it is very unlikely to catch sight of it during a hiking tour, as it avoids the company of humans. As opposed to many adventure stories, humans are not on the menu of bears.
<G-vec00185-001-s108><catch.bekommen><de> Allerdings ist es sehr unwahrscheinlich, ihn auf einer Wandertour tatsächlich zu Gesicht zu bekommen, meidet er doch die Gesellschaft von Menschen und weicht diesen aus.
<G-vec00185-001-s109><catch.bekommen><en> In fact, the more afraid we are of catching it, the greater the chances are that we will catch it, which is ironic.
<G-vec00185-001-s109><catch.bekommen><de> Tatsächlich ist es so, dass umso mehr wir Angst davor haben, Lepra zu bekommen, desto wahrscheinlicher ist es, dass wir sie tatsächlich bekommen, was etwas ironisch ist.
<G-vec00185-001-s110><catch.bekommen><en> Complications arising from tattooing Infections, the ability to catch hepatitis or AIDS.
<G-vec00185-001-s110><catch.bekommen><de> Komplikationen durch Tätowierung von Infektionen, die Fähigkeit, Hepatitis oder AIDS zu bekommen.
<G-vec00185-001-s111><catch.bekommen><en> To monitor these conversations, set up alerts in your chosen social media monitoring tool to catch all mentions across the web and social.
<G-vec00185-001-s111><catch.bekommen><de> Um diese Unterhaltungen zu beobachten, installiere einen Benachrichtigungsalarm in deinem gewünschten Social-Media-Beobachtungstool, um über jede Erwähnung im Web und in den sozialen Netzwerken Bescheid zu bekommen.
<G-vec00185-001-s112><catch.bekommen><en> Sometimes level should be restarted several times to catch the necessary subject.
<G-vec00185-001-s112><catch.bekommen><de> Manchmal muss man das Niveau mehrmals wieder anlaufen, um den nötigen Gegenstand zu bekommen.
<G-vec00185-001-s147><catch.einfangen><en> You can't catch them.
<G-vec00185-001-s147><catch.einfangen><de> Du kannst sie nicht einfangen.
<G-vec00185-001-s148><catch.einfangen><en> We were able to catch 36 chicks and to calculate their exact age by interpolating weight and head length.
<G-vec00185-001-s148><catch.einfangen><de> Wir konnten 36 Küken einfangen und mittels Gewicht und Kopfläge ihr exaktes Alter ermitteln.
<G-vec00185-001-s149><catch.einfangen><en> Albert needed to catch him at the right moment using the right props and the right light.
<G-vec00185-001-s149><catch.einfangen><de> Albert musste ihn im richtigen Moment in der richtigen Kulisse und im richtigen Licht einfangen.
<G-vec00185-001-s150><catch.einfangen><en> But whenever there's some kind of affinity of magician to energy, a connection of any sort, he can catch it and use it, guide and direct it with his will.
<G-vec00185-001-s150><catch.einfangen><de> Aber wenn eine Affinität zwischen dem Magier und der Energie besteht, eine Verbindung irgendeiner Art, so kann er sie einfangen und für sich nutzen, umleiten und lenken ganz nach seinem Willen.
<G-vec00185-001-s151><catch.einfangen><en> DK, Titan, and iG could not catch EG.
<G-vec00185-001-s151><catch.einfangen><de> DK, Titan und iG konnten EG nicht einfangen.
<G-vec00185-001-s152><catch.einfangen><en> Our criticism is directed not only at those who catch wild elephants, but also the zoos and wildlife parks that act as buyers.
<G-vec00185-001-s152><catch.einfangen><de> In der Kritik stehen nicht nur jene, die wilde Elefanten einfangen, sondern auch die Zoos, die als Abnehmer für solche Tiere fungieren.
<G-vec00185-001-s153><catch.einfangen><en> Many scenes I could not catch, others I could!
<G-vec00185-001-s153><catch.einfangen><de> Viele Szenen habe ich nicht einfangen können, viele andere schon.
<G-vec00185-001-s154><catch.einfangen><en> First I ran away when the people came too near to me because I was not sure if they want to catch me.
<G-vec00185-001-s154><catch.einfangen><de> Zuerst lief ich weg, wenn sie auf mich zu kamen, weil ich nicht sicher war, ob sie mich einfangen wollten.
<G-vec00185-001-s155><catch.einfangen><en> Love is like measles, stick around and you will catch it.
<G-vec00185-001-s155><catch.einfangen><de> Die Liebe ist wie Masern, hänge herum und du wirst sie dir einfangen.
<G-vec00185-001-s156><catch.einfangen><en> The central refinancing instance which has accepted for the sake of banks high risks and historically unique interest conditions, is now supposed to catch up with the consequences of its liquidity and collateral policy. Nevertheless ECB refuses to stop the privileged refinancing of the state by banks.
<G-vec00185-001-s156><catch.einfangen><de> Mehr noch: jene Instanz, die unter dem Gesichtspunkt der Bankenstabilisierung hohe Risiken der Kreditinstitute unbegrenzt refinanziert hat und damit unweigerlich die Anlagepolitik der Banken quergeschrieben hat, soll eben die Folgen dieser Politik nun als Bankenaufsicht einfangen.
<G-vec00185-001-s157><catch.einfangen><en> Let your eyes catch butterflies as they fly past you.
<G-vec00185-001-s157><catch.einfangen><de> Lasse deine Augen Schmetterlinge einfangen, während sie an dir vorüberfliegen.
<G-vec00185-001-s158><catch.einfangen><en> As a consequence, spectators of this piece can hear the sound of a movie that has never been filmed, while on stage one can hear the whispering of the heart, black shadows and an inner demon, which cameras normally can’t catch.
<G-vec00185-001-s158><catch.einfangen><de> Die Zuschauer hören somit den Sound eines Films, der nie gedreht wurde, während auf der Bühne das Flüstern des Herzens, schwarze Schatten und der innere Dämon zu sehen ist, den Kameras normalerweise nicht einfangen können.
<G-vec00185-001-s159><catch.einfangen><en> The first butterfly is yellow of course and the Backyard Potterer can't catch it with his eyes, to paint it multicoloured with his mental watercolours.
<G-vec00185-001-s159><catch.einfangen><de> Der erste Schmetterling ist natürlich gelb und der Garten-Werkler kann ihn nicht mit seinen Augen einfangen, um ihn mit seinen geistigen Wasserfarben bunt anzumalen.
<G-vec00185-001-s160><catch.einfangen><en> Dragonfly approach to the Mediterranean: Surprisingly, I was able to catch the insect with my smartphone.
<G-vec00185-001-s160><catch.einfangen><de> Libellenanflug am Mittelmeer: Über ra schen der wei se konnte ich das Insekt mit meinem Smartphone einfangen.
<G-vec00185-001-s161><catch.einfangen><en> Tip: Even though you got only one Bug, they multiply to 3 every time you let it out, therefore you can catch one again right away to keep it for later, while the other two still get the Gold Skulltula out of the hole.
<G-vec00185-001-s161><catch.einfangen><de> Tip: Auch wenn du nur einen Käfer hast, sie vermehren sich jedes Mal wenn du ihn raus lässt, darum kannst du einen gleich wieder einfangen für später, während die anderen Beiden die Goldene Skulltula aus dem Loch locken.
<G-vec00185-001-s162><catch.einfangen><en> Setting the bird in some higher spot may be tried: by letting itself drop it can catch wind in the wings and be gone in a moment.
<G-vec00185-001-s162><catch.einfangen><de> Den Vogel auf einen höheren Punkt zu setzen kann probiert werden: indem er sich fallen lässt, kann er den Wind in den Flügeln einfangen und in einem Augenblick weg sein.
<G-vec00185-001-s163><catch.einfangen><en> The intersecting grooves of guilloché form a patina of endlessly varied motifs to catch and reflect the light; here, they strike out from the center in rays.
<G-vec00185-001-s163><catch.einfangen><de> Die sich kreuzenden Linien der Guillochierung bilden ein Netz endlos variierbarer Motive, die das Licht einfangen und reflektieren – hier als Dekor, das strahlenförmig aus dem Zentrum scheint.
<G-vec00185-001-s164><catch.einfangen><en> But if we catch the bird and put it in a cage, the bird is going to be very unhappy and might even die.
<G-vec00185-001-s164><catch.einfangen><de> Aber wenn wir den Vogel einfangen und ihn in einen Käfig setzen, ist der Vogel sehr unglücklich und stirbt vielleicht sogar.
<G-vec00185-001-s165><catch.einfangen><en> The photos should catch the strong moments and the variety of the Tor.
<G-vec00185-001-s165><catch.einfangen><de> Die Fotos sollten die verschiedensten Nuancen und Schwerpunkte des Tors einfangen.
<G-vec00185-001-s166><catch.einholen><en> And even then, if they catch up with him, catch him and establish his identity.
<G-vec00185-001-s166><catch.einholen><de> Und selbst dann, wenn sie ihn einholen, fangen sie ihn und stellen seine Identität fest.
<G-vec00185-001-s167><catch.einholen><en> You will catch on to it. Or, even if you don’t, it will catch you.
<G-vec00185-001-s167><catch.einholen><de> Anderenfalls, falls du es nicht tust, wird er dich einholen.
<G-vec00185-001-s168><catch.einholen><en> They want catch us!
<G-vec00185-001-s168><catch.einholen><de> sie werden uns nicht einholen.
<G-vec00185-001-s169><catch.einholen><en> Then the Blessed One willed a feat of psychic power such that Aṅgulimāla, though running with all his might, could not catch up with the Blessed One walking at normal pace.
<G-vec00185-001-s169><catch.einholen><de> Da vollbrachte der Erhabene ein derartiges Kunststück übernatürlicher Kräfte, daß der Verbrecher Aṅgulimāla, obwohl er lief, so schnell er konnte, den Erhabenen nicht einholen konnte, der in normaler Geschwindigkeit ging.
<G-vec00185-001-s170><catch.einholen><en> They will not catch us! They will not catch us!
<G-vec00185-001-s170><catch.einholen><de> Sie werden uns nicht einholen, nicht einholen.
<G-vec00185-001-s172><catch.einholen><en> One more lap and I would perhaps have been able to catch Jesse.
<G-vec00185-001-s172><catch.einholen><de> Eine Runde mehr und ich hätte Jesse vielleicht einholen können.
<G-vec00185-001-s173><catch.einholen><en> Consequently, a weakened collapsed immune system would never catch up with and overtake the progressive disease.
<G-vec00185-001-s173><catch.einholen><de> Daraus folgt, dass das geschwächte und zerstörte Immunsystem die fortgeschrittene Krankheit niemals einholen, zurücklassen und besiegen kann.
<G-vec00185-001-s174><catch.einholen><en> The latest on the next sunshine you are the old and new resolutions for your car care catch up again.
<G-vec00185-001-s174><catch.einholen><de> Spätestens bei dem nächsten Sonnenschein werden Sie die alten und neuen Vorsätze für Ihre Fahrzeugpflege wieder einholen.
<G-vec00185-001-s175><catch.einholen><en> Even someone who initially loses out in every game will still be able to catch up with his opponent by winning the remaining rounds.
<G-vec00185-001-s175><catch.einholen><de> Denn selbst wer zunächst bei jedem Spiel leer ausgeht, kann seinen Kontrahenten mit Siegen in den verbleibenden Runden noch einholen.
<G-vec00185-001-s176><catch.einholen><en> Images of childhood, places and life situations appear as if the author is trying to catch up lost time.
<G-vec00185-001-s176><catch.einholen><de> Bilder der Kindheit flackern auf, Orte und Lebensstationen, als wolle der Autor die verlorene Zeit einholen.
<G-vec00185-001-s177><catch.einholen><en> I did need to pause the video a few times until I could catch up with the instructor.
<G-vec00185-001-s177><catch.einholen><de> Ich musste das Video ein paar Mal pausieren, bis ich den Lehrer einholen konnte.
<G-vec00185-001-s178><catch.einholen><en> Sundowner, which also made the London start, had stopped en route due to technical issues and will catch up with the fleet later on.
<G-vec00185-001-s178><catch.einholen><de> Sundowner, welche ebenfalls in London gestartet sind, mussten unterwegs wegen technischer Probleme zwischen stoppen und werden die Flotte später wieder einholen.
<G-vec00185-001-s179><catch.einholen><en> He was going to catch him in a few moments.
<G-vec00185-001-s179><catch.einholen><de> Er würde ihn in den nächsten Augenblicken einholen.
<G-vec00185-001-s180><catch.einholen><en> Because of the explosive growth of data center traffic, the technology iteration of optical transceivers can not catch up with the demand, and almost all the most advanced technologies are applied to data centers.
<G-vec00185-001-s180><catch.einholen><de> Aufgrund des explosionsartigen Wachstums des Datencenterverkehrs kann die technologische Iteration optischer Transceiver die Nachfrage nicht einholen, und fast alle fortschrittlichsten Technologien werden in Rechenzentren eingesetzt.
<G-vec00185-001-s181><catch.einholen><en> Quickly send pre-written messages to your fellow riders and let them know if you'll catch up in a few minutes or if they should go on without you.
<G-vec00185-001-s181><catch.einholen><de> Sende im Handumdrehen bereits verfasste Nachrichten an deine Mitfahrer und sage ihnen, ob du sie in ein paar Minuten einholen wirst oder ob sie schon ohne dich vorfahren sollen.
<G-vec00185-001-s182><catch.einholen><en> Yet, indiscretions online can catch up with you later in life.
<G-vec00185-001-s182><catch.einholen><de> Indiskretionen online können Sie jedoch später im Leben einholen.
<G-vec00185-001-s183><catch.einholen><en> It is still not too late, and perhaps we can still catch up with them.
<G-vec00185-001-s183><catch.einholen><de> Noch ist es nicht zu spät, noch können wir sie einholen.
<G-vec00185-001-s184><catch.einholen><en> Certainly the same fate could catch up with salvia divinorum that struck psilocybin mushrooms, ololiuqui, peyote(lophophora williamsii), as well as other psychoactive plants because of their augmented popularity.
<G-vec00185-001-s184><catch.einholen><de> Allerdings könnte das pharmakratische Schicksal, das schon Psilocybe-Pilze, Ololiuqhui,Peyote (Lophophora williamsii) und andere psychoaktive Gewächse so hart traf, nun durch die zunehmende Popularisierung der Zauberpflanzen auch Salvia divinorum einholen.
<G-vec00185-001-s185><catch.einfangen><en> However, I come just by time, when As I Lay Dying, start their set and I'm trying desperately to catch the vibe with my camera
<G-vec00185-001-s185><catch.einfangen><de> Wie auch immer, ich komme gerade rechtzeitig zum Anpfiff von As I Lay Dying, und versuche mit schierer Verzweiflung deren Vibe per Bild einzufangen.
<G-vec00185-001-s186><catch.einfangen><en> This wonder world and all the daily observations I tried to catch with the camera.
<G-vec00185-001-s186><catch.einfangen><de> Diese Wunderwelten und die vielen täglichen Beobachtungen habe ich versucht, mit der Kamera einzufangen.
<G-vec00185-001-s187><catch.einfangen><en> They have no possibility to catch the cats and no financial means to care for the cats being spayed and neutered.
<G-vec00185-001-s187><catch.einfangen><de> Sie haben nicht die Möglichkeit, die völlig verwilderten Hauskatzen einzufangen und gleich gar nicht die finanziellen Mittel, um Kastrationen zu bezahlen.
<G-vec00185-001-s188><catch.einfangen><en> I strive to catch the soul and spirit of the original as well as its specific characteristics, and to render all this in the replica.
<G-vec00185-001-s188><catch.einfangen><de> Mein Bestreben ist es, die Seele und den Geist eines Originals und seine spezifischen Eigenheiten einzufangen und im Nachbau wiederkehren zu lassen.
<G-vec00185-001-s189><catch.einfangen><en> – All creatures on Earth try to catch the hot sun's rays.
<G-vec00185-001-s189><catch.einfangen><de> – Alle Lebewesen auf der Erde versuchen die heißen Sonnenstrahlen einzufangen.
<G-vec00185-001-s190><catch.einfangen><en> When Lotto Soudal's Adam Hansen and Tim Wellens tried to bridge across to a dangerous break, the message came back to the Mitchelton-Scott team of leader Simon Yates and they put the hammer down to catch them.
<G-vec00185-001-s190><catch.einfangen><de> Als Adam Hansen und Tim Wellens von Lotto versuchten, an eine gefährliche Ausreißergruppe heranzufahren, wurde das Team Mitchelton-Scott des Gesamtführenden Simon Yates aktiv und gab Vollgas, um sie einzufangen.
<G-vec00185-001-s191><catch.einfangen><en> "In turn, this implies long, deep-rooted work alongside our class, to reintroduce the awareness that the national economy is not something to be safeguarded and defended, on the altar of which living and working conditions should be sacrificed; and that its ""higher needs"" are a trap to catch the proletariat and lead it, bound hand and foot, to the ""defence of the Nation"", in a war of fraticide against other proletarians."
<G-vec00185-001-s191><catch.einfangen><de> "Auf seine Weise bedeutet das eine lange und tiefschürfende Arbeit an der Seite unserer Klasse, um in diese das Bewusstsein darüber einzuführen, dass die nationale Wirtschaft kein Gemeinschaftsgut ist, das gerettet und verteidigt werden muss, an dessen Altar man seine eigenen Arbeits- und Lebensbedingungen opfert; und das daher die ""höheren Bedürfnisse"" eine Falle sind, um das Proletariat einzufangen und es schließlich an Händen und Füßen gefesselt zur ""Verteidigung des Vaterlandes"" zu schleppen, in einen Bruderkrieg gegen andere Proletarier."
<G-vec00185-001-s192><catch.einfangen><en> One of the main aims of content marketing is to catch people at the moment in their life where they need some guidance. What you need to do is to make sure that your content is ready to meet them when they’re at this point.
<G-vec00185-001-s192><catch.einfangen><de> Eins der wichtigsten Ziele vom Content Marketing ist es, die Menschen genau an dem Punkt in ihrem Leben einzufangen, an dem sie eine Anleitung benötigen .
<G-vec00185-001-s193><catch.einfangen><en> Well, yes, I know part of it is a real attraction to catch the latest news.
<G-vec00185-001-s193><catch.einfangen><de> Nun ja, ich weiß, dass Teil davon eine echte Anziehung ist, die neusten Nachrichten einzufangen.
<G-vec00185-001-s194><catch.einfangen><en> Remembering this, we have taken a first step towards overcoming our lack of communication. NATO has established an emergency contact mechanism that enables the military side to catch dangerous situations or misunderstandings before they escalate by getting in touch quickly.
<G-vec00185-001-s194><catch.einfangen><de> Dies in Erinnerung, ist ein erster Schritt zur Überwindung der Sprachlosigkeit ist getan: Die NATO hat einen Krisenkontaktmechanismus eingerichtet, der es der militärischen Seite erlaubt, gefährliche Situationen oder auch Missverständnisse durch rasche Kontaktaufnahme einzufangen.
<G-vec00185-001-s195><catch.einfangen><en> There is one point we would like to touch on briefly at the end: Due to the hardware gaps Meltdown and Spectre, Synology NAS systems cannot be confirmed to be safe, but it is less likely to catch a malicious program there, which makes the use of these gaps possible in the first place.
<G-vec00185-001-s195><catch.einfangen><de> Einen Punkt möchten wir am Schluss noch kurz anschneiden: Im Zuge der Hardware Lücken Meltdown sowie Spectre kann den NAS Systeme von Synology zwar keine Unbedenklichkeit bestätigt werden, es ist jedoch unwahrscheinlicher sich dort ein Schadprogramm einzufangen, welches die Nutzung dieser Lücken erst möglich macht.
<G-vec00185-001-s196><catch.einfangen><en> I think that main aim is to catch a beautiful moment.
<G-vec00185-001-s196><catch.einfangen><de> Das Ziel ist es, einen schönen Moment einzufangen.
<G-vec00185-001-s197><catch.einfangen><en> There are plans in Latvia to catch two more white-tailed eagles but it is not easy.
<G-vec00185-001-s197><catch.einfangen><de> In Lettland gibt es Pläne zwei weitere Seeadler einzufangen, doch das ist nicht einfach.
<G-vec00185-001-s198><catch.einfangen><en> The eye of God is always on you, shining light on you, trying every which way to catch your eye.
<G-vec00185-001-s198><catch.einfangen><de> Das Auge Gottes liegt stets auf dir, scheint Licht auf dich, versucht alles, um dein Auge einzufangen.
<G-vec00185-001-s199><catch.einfangen><en> "With the new training game ""Tux Racer"" the visitors of the fair are racing a ""penguin"" down the hill on an icy track, steering by load shifting to ""catch fish"" on the way down at the same time."
<G-vec00185-001-s199><catch.einfangen><de> "Beim neuen Trainingsspiel ""Tux Racer"" jagten die Messebesucher einen ""Pinguin"" über eine Piste hinab ins Tal, während sie ihn mit Gewichtsverlagerung steuerten um ""Fische einzufangen""."
<G-vec00185-001-s200><catch.einfangen><en> Your goal is to catch as many clouds and nuts as possible.
<G-vec00185-001-s200><catch.einfangen><de> Dein Ziel ist es, so viele Wolken und Nüsse wie möglich einzufangen.
<G-vec00185-001-s201><catch.einfangen><en> If you're unlucky enough to catch one (but don't beat yourself too much if you do, because they are incredibly common), expect havoc to be wrecked on your hard disk — slower PC performance, Â damaged or destroyed files, and everything in between.
<G-vec00185-001-s201><catch.einfangen><de> Wenn Sie das Pech haben, sich einen einzufangen (aber ärgern Sie sich nicht zu sehr, falls es passiert, denn sie sind unglaublich weit verbreitet), dann dürfen Sie sich auf ernsthafte Schäden Ihrer Festplatte gefasst machen – von gedrosselter PC-Leistung bis hin zu beschädigten oder zerstörten Dateien.
<G-vec00185-001-s202><catch.einfangen><en> Important during the shooting was the absolute moment, to catch the authentic way of the artists.
<G-vec00185-001-s202><catch.einfangen><de> Wichtig während der Dreharbeiten war der absolute Augenblick, die Authentizität der Künstler einzufangen.
<G-vec00185-001-s203><catch.einfangen><en> With his camera he tries to catch the animal’s natural behavior in their habitat with great respect toward animal and nature.
<G-vec00185-001-s203><catch.einfangen><de> Hinter seiner Kamera versucht er mit dem nötigen Respekt und Achtung gegenüber Tier und Natur, deren Verhalten in ihrem natürlichen Lebensraum einzufangen.
<G-vec00185-001-s204><catch.einholen><en> Asuka called to the boy who was running to catch up with her.
<G-vec00185-001-s204><catch.einholen><de> """, rief Asuka dem Jungen zu, der rannte, um sie einzuholen."
<G-vec00185-001-s205><catch.einholen><en> Invest your money in the good that is on its way to you, rushing to you, trying to catch up to you. Make way for the good.
<G-vec00185-001-s205><catch.einholen><de> Investiert euer Geld in das Gute, was zu euch auf dem Weg ist, was zu euch hin eilt, was versucht, euch einzuholen.
<G-vec00185-001-s206><catch.einholen><en> In Katanga, they believed, they may be able to catch memories of their youth.
<G-vec00185-001-s206><catch.einholen><de> In Katanga glaubten sie vielleicht, ein Stück ihrer Jugend wieder einzuholen.
<G-vec00185-001-s207><catch.einholen><en> They are thus trying to catch up to Planet X, even when Planet X leaves them behind.
<G-vec00185-001-s207><catch.einholen><de> Sie versuchen also Planet X einzuholen, sogar wenn Planet X sie hinter sich lässt.
<G-vec00185-001-s208><catch.einholen><en> Having noticed a female, they broke and a shot dispersed foxes in different directions, and then, having quickly passed sideways a trace of a female of kilometer two and having hidden behind any shelter, waited and beat males who, having returned on that place from where they were driven away from a female, hurried to catch up with her on a trace and got under a shot.
<G-vec00185-001-s208><catch.einholen><de> Das Weibchen bemerkt, zerschlugen sie auch dem Schuss vertrieben die Füchse zu verschiedenen Seiten, und dann, neben der Spur des Weibchens des Kilometers zwei schnell gegangen und hinter irgendwelcher Deckung verborgen geworden, warteten ab und schlugen die Männchen, die, auf jene Stelle zurückgekehrt, woher sie vom Weibchen vertrieben haben, beeilten sich, sie nach der Spur einzuholen und gerieten unter den Schuss.
<G-vec00185-001-s209><catch.einholen><en> 36:40 It is not appropriate (or required) of the sun to catch up with the moon, and not the night to get ahead of the day, and each flow in an orbit.
<G-vec00185-001-s209><catch.einholen><de> 36:40 Weder ziemt es der Sonne, den Mond einzuholen, noch wird die Nacht dem Tag zuvorkommen; alle laufen in einer (jeweils eigenen) Umlaufbahn.
<G-vec00185-001-s210><catch.einholen><en> New Edge Browser: In order to catch up with popular browsers such as Chrome and Firefox, Microsoft eliminated old IE and brought in edge browsers.
<G-vec00185-001-s210><catch.einholen><de> Neuer Rand-Browser: Um populäre Browser wie Chrome und Firefox einzuholen, beseitigte Microsoft altes IE und holt in Randbrowser.
<G-vec00185-001-s211><catch.einholen><en> That is just more motivation for Mars to catch up with the big rival.
<G-vec00185-001-s211><catch.einholen><de> Umso mehr arbeitet Mars daran, den großen Rivalen einzuholen.
<G-vec00185-001-s212><catch.einholen><en> He realized what the corgi was doing, but he couldn't get his horse to run fast enough to catch up with her; she must have been moving with the aid of some magic.
<G-vec00185-001-s212><catch.einholen><de> Es war ihm klar, was Corgi-san im Sinn hatte, aber er konnte sein Pferd nicht dazu bringen, schneller zu rennen, um ihn einzuholen; der Hunde-Geist schien von magischen Kräften beflügelt zu sein.
<G-vec00185-001-s213><catch.einholen><en> Jiang Jiao ordered his men to catch up to the monk and bring him back.
<G-vec00185-001-s213><catch.einholen><de> Darauf hin befahl Jiang Jiao seinen Männer, den Mönch einzuholen und ihn zurückzubringen.
<G-vec00185-001-s214><catch.einholen><en> He then stepped back. When I had mounted it, he led it quickly away to catch up to the people.
<G-vec00185-001-s214><catch.einholen><de> Als ich es bestiegen hatte, führte er es schnell fort, um die Leute einzuholen, aber, bei Allah, wir konnten sie nicht erreichen.
<G-vec00185-001-s215><catch.einholen><en> In the high quality match between Dick Jaspers and Martin Horn it was all square 2-2 at this moment, but the Germans could not catch up with their opponents any more.
<G-vec00185-001-s215><catch.einholen><de> In einem hochklassigen Match stand es zu diesem Zeitpunkt 2:2 zwischen Dick Jaspers und Martin Horn, doch die Niederländer waren nicht mehr einzuholen.
<G-vec00185-001-s216><catch.einholen><en> In this case the above remarks about the passport are the same but you also need a tourist visa which has to be catch at the American foreign authorities before starting the trip.
<G-vec00185-001-s216><catch.einholen><de> Für diesen Fall gelten die obigen Ausführungen gleichermaßen und zusätzlich ist ein entsprechendes Touristen-Visum bei den amerikanischen Auslandsbehörden vor Antritt der Reise einzuholen.
<G-vec00185-001-s217><catch.einholen><en> Well, then we had to hike up quickly there where we walked down to catch up with the others.
<G-vec00185-001-s217><catch.einholen><de> Tja, dann mussten wir da, wo wir runter waren, auch schnell wieder rauf, um die Anderen einzuholen.
<G-vec00185-001-s218><catch.einholen><en> Two planes try to catch each other.
<G-vec00185-001-s218><catch.einholen><de> Zwei Flugzeuge versuchen einander einzuholen.
<G-vec00185-001-s219><catch.einholen><en> Afterwards, policeman Bell rolls the dice and tries to catch up with Bert as fast as he can.
<G-vec00185-001-s219><catch.einholen><de> Im Anschluss würfelt der Polizist Bell, der versucht, Bert so schnell wie möglich einzuholen.
<G-vec00185-001-s220><catch.einholen><en> Mother Yasoda, however, could not easily catch the fast-running child because of her thin waist and heavy body.
<G-vec00185-001-s220><catch.einholen><de> Für Mutter Yasoda war es nicht leicht, das flinke Kind einzuholen, denn sie hatte eine schmale Taille und einen schweren Körper.
<G-vec00185-001-s221><catch.einholen><en> The girl got angry and decided to catch up with the harmful animal.
<G-vec00185-001-s221><catch.einholen><de> Das Mädchen wurde wütend und beschloss, das schädliche Tier einzuholen.
<G-vec00185-001-s222><catch.einholen><en> To catch up for lost time and to terminate the use, he remained with the weapon to fire at you against the enemy and was killed in the explosion.
<G-vec00185-001-s222><catch.einholen><de> Um die verlorene Zeit wieder einzuholen und den Einsatz zu beendigen, blieb er bei der Waffe, um Sie gegen die Gegner abzufeuern und starb bei dessen Explosion.
<G-vec00185-001-s286><catch.erreichen><en> In the night before I received a telephone call and was just barely able to catch a flight to Frankfurt and then the 747 to Beijing.
<G-vec00185-001-s286><catch.erreichen><de> In der Nacht vor dem geplanten Abflug nach Paris erhielt ich einen Anruf und konnte gerade noch rechtzeitig ein Flugzeug nach Frankfurt und damit den Jumbo nach Beijing erreichen.
<G-vec00185-001-s287><catch.erreichen><en> Airports An airport is a highly controlled environment where everyday millions of passengers pass to catch their flight.
<G-vec00185-001-s287><catch.erreichen><de> Flughäfen Ein Flughafen ist eine hoch kontrollierte Umgebung, in der jeden Tag Millionen von Passagieren ihren Flug erreichen möchten.
<G-vec00185-001-s288><catch.erreichen><en> This bridge was long enough and strong enough for Lang to walk onto and catch his wife.
<G-vec00185-001-s288><catch.erreichen><de> Die Brücke war lang und fest genug, daß Lang über sie gehen und seine Frau erreichen konnte.
<G-vec00185-001-s289><catch.erreichen><en> I was able to drop my stick and I ran up to tell my mother I was healed and again able to catch the car.
<G-vec00185-001-s289><catch.erreichen><de> Ich war in der Lage, meinen Stock wegzuwerfen und ich rannte nach oben, um meiner Mutter zu erzählen, daß ich geheilt war und wieder in der Lage, den Bus zu erreichen.
<G-vec00185-001-s290><catch.erreichen><en> Walk, drive or catch cabs between the cultural exhibition pavilions of Haaretz Museum, historic Independence Hall Museum, bustling Carmel Market and Old Jaffa's boardwalk.
<G-vec00185-001-s290><catch.erreichen><de> Die Pavillons des Haaretz Museums, das historische Independence Hall Museum, der geschäftige Carmel-Markt und die Promenade der Altstadt Jaffas sind zu Fuß, mit dem Auto oder per Taxi zu erreichen.
<G-vec00185-001-s291><catch.erreichen><en> They would catch the ship.
<G-vec00185-001-s291><catch.erreichen><de> Sie würden das Schiff erreichen.
<G-vec00185-001-s292><catch.erreichen><en> Guests can catch a ride to nearby destinations on the area shuttle (surcharge).Pets allowed Check-in time starts at 3 PM Check-out time is 10:30 AMFeatured amenities include luggage storage, laundry facilities, and an elevator (lift).
<G-vec00185-001-s292><catch.erreichen><de> Ziele in der Umgebung erreichen Sie mit dem Shuttle (gegen Gebühr).Haustiere gestattet Check-in ab 15:00 Uhr Check-out bis 10:30 UhrZum Angebot gehören eine Gepäckaufbewahrung, eine Wäscherei und ein Aufzug.
<G-vec00185-001-s293><catch.erreichen><en> I sprang out of bed and quickly packed my poor stuff, and then, in twenty minutes or so, I was running out to catch a train that should take me more than hundred kilometres away from home, to a German-populated area, to Jablonec nad Nisou (germ.: Gablonz).
<G-vec00185-001-s293><catch.erreichen><de> Ich sprang aus dem Bett, packte schnell meine Sachen zusammen, deren ich sehr wenig hatte und vielleicht in zwanzig Minuten nahm ich Reißaus aus dem Haus, um einen Zug zu erreichen, der mich mehr als ein hundert Kilometer weg von der Heimat brachte, ins deutsche Kreis, Gablonz.
<G-vec00185-001-s294><catch.erreichen><en> Afterwards you are taken to the airport in order to catch the flight to the continent.
<G-vec00185-001-s294><catch.erreichen><de> Danach fahren Sie zum Flughafen, um den Flug zum Festland zu erreichen.
<G-vec00185-001-s295><catch.erreichen><en> Two days before my accident I was leaving my friend's art supply store to catch a bus to go to my Art Gallery to open up for business for the day.
<G-vec00185-001-s295><catch.erreichen><de> Zwei Tage vor meinem Unfall verließ ich das Geschäft für Künstlerbedarf meines Freundes, um meinen Bus zu erreichen damit ich zu meiner Kunstgalerie gehen konnte um sie für den Tag zu öffnen.
<G-vec00185-001-s296><catch.erreichen><en> Guests who must leave before 6:00 a.m. in order to catch their flight will receive a small breakfast at 4:00 a.m.
<G-vec00185-001-s296><catch.erreichen><de> Gäste, die vor 6:00 Uhr abreisen, um ihren Flug zu erreichen, erhalten ab 4:00 Uhr ein kleines Frühstück.
<G-vec00185-001-s297><catch.erreichen><en> Our location downtown and on the waterfront is still close enough to the airport to catch a red eye quickly.
<G-vec00185-001-s297><catch.erreichen><de> Das Hotel liegt günstig in der Innenstadt und am Hafen, aber auch der Flughafen liegt nahe genug, um einen späten Flug zu erreichen.
<G-vec00185-001-s298><catch.erreichen><en> So, if supposing you have to catch the plane, then you don’t get down on the way somewhere and stay out.
<G-vec00185-001-s298><catch.erreichen><de> Nehmen wir an, ihr müßt zum Flughafen, um ein Flugzeug zu erreichen, in dem Fall würdet ihr auch nicht irgendwo unterwegs haltmachen.
<G-vec00185-001-s299><catch.erreichen><en> Meanwhile, in July 1945, permission was granted to open a Novitiate in Chowtsun, but seven months later, while we were doing our laundry, Father Lee said, ‘Sisters, hurry, we’ve got to catch the last train to Jinan because the Communists are coming.’ We quickly gathered some of our belongings and immediately got to the train station.
<G-vec00185-001-s299><catch.erreichen><de> In der Zwischenzeit, im Juli1945, war die Genehmigung erteilt worden, in Chowtsun ein Noviziat zu errichten, aber sieben Monate später – wir waren gerade dabei, unsere Wäsche zu waschen, sagte Pater Lee: “Schwestern, beeilt euch, wir müssen unbedingt den letzten Zug nach Jinan erreichen, die Kommunisten kommen.“ Schnell rafften wir einige unserer Sachen zusammen und machten uns unverzüglich auf den Weg zum Bahnhof.
<G-vec00185-001-s300><catch.erreichen><en> Day 4: Mykonos After an early breakfast, depart to the port to catch the boat to Mykonos Island, duration of the trip 15 minutes.
<G-vec00185-001-s300><catch.erreichen><de> Tag 4: Mykonos Nach einem frühen Frühstück gehen Sie zum Hafen, um die Fähre nach Mykonos zu erreichen, Dauer der Fahrt: 15 Minuten.
<G-vec00185-001-s301><catch.erreichen><en> If life were carry-on luggage and the wheels get stuck, you would adapt to your carry on and still catch your flight and still take your carry-on with you.
<G-vec00185-001-s301><catch.erreichen><de> Falls das Leben ein Handgepäckstück wäre und dessen Räder säßen fest, würdet ihr euch eurem Trara anpassen und trotzdem noch euren Flug erreichen, das Handgepäck immer noch bei euch.
<G-vec00185-001-s302><catch.erreichen><en> Breakfast is served from 8am till 10am, but if you have to leave before that in order to catch an early flight or to try and avoid the queues at the Vatican Museums we will make sure there will be some food waiting for you when you get up.
<G-vec00185-001-s302><catch.erreichen><de> Das Frühstück wird von 8 bis 10 Uhr bereitgestellt, aber falls Sie einen frühen Flug erreichen müssen oder versuchen möchten die Schlangen vor den Vatikanischen Museen zu vermeiden, werden wir sicherstellen, dass das Frühstück bereit steht, wenn Sie aufstehen.
<G-vec00185-001-s303><catch.erreichen><en> Théâtre des Arts: This is one of the stations with the highest number of connections in which travelers can catch the Metrobús lines T1, T2, and T3 and the bus numbers 8, 10, 20, and 21.
<G-vec00185-001-s303><catch.erreichen><de> Théâtre des Arts: Dies ist eine der Stationen mit der höchsten Anzahl von Verbindungen, an denen Reisende die Metrobús-Linien T1, T2 und T3 sowie die Buslinien 8, 10, 20 und 21 erreichen können.
<G-vec00185-001-s304><catch.erreichen><en> For those who need to be near the KC Irving Centre or need to catch a red eye at the Bathurst Airport, there's no better location than this Bathurst hotel.
<G-vec00185-001-s304><catch.erreichen><de> Für Gäste, die eine Unterkunft in der Nähe des KC Irving Centre suchen oder einen frühen Flug am Flughafen Bathurst erreichen müssen, gibt es keine bessere Unterkunft als dieses Hotel in Bathurst.
<G-vec00185-001-s305><catch.erwischen><en> If the accident occurred, they had to jump out of the hiding place and catch the cosmonaut as firemen catch people jumping from the upper floors of burning buildings.
<G-vec00185-001-s305><catch.erwischen><de> Wenn der Unfall passierte, mussten sie aus dem Versteck springen und den Kosmonauten erwischen, während Feuerwehrmänner Leute fangen, die von den oberen Stockwerken der brennenden Gebäude springen.
<G-vec00185-001-s306><catch.erwischen><en> Whenever someone mentioned the police, Mr. Ren would murmur that he had to run or the police would catch him.
<G-vec00185-001-s306><catch.erwischen><de> Wann immer jemand die Polizei erwähnte, murmelte Ren, dass er weglaufen müsse, oder die Polizei würde ihn erwischen.
<G-vec00185-001-s307><catch.erwischen><en> They were hoping that this would catch them off guard and, separated from the permanent workers, they would be forced to accept or risk their jobs.
<G-vec00185-001-s307><catch.erwischen><de> Ihre Hoffnung war gewesen, daß sie die Arbeiter auf dem falschen Fuß erwischen würden und sie, getrennt von den anderen Arbeitern, zwingen könnten, zu akzeptieren oder ihren Job zu riskieren.
<G-vec00185-001-s308><catch.erwischen><en> Try to catch the moment when heat button appears and click on it to unlock next level.
<G-vec00185-001-s308><catch.erwischen><de> Versuche den Moment zu erwischen, wenn der Hotspot auftaucht, klicke dann darauf, um zu einem neuen Level zu gelangen.
<G-vec00185-001-s309><catch.erwischen><en> Check out what we learned from our closed alpha and follow us on Twitch to catch us live next time.
<G-vec00185-001-s309><catch.erwischen><de> Lest nach, was wir aus unserer geschlossenen Alpha gelernt haben, und folgt uns auf Twitch, um uns das nächste Mal live zu erwischen.
<G-vec00185-001-s310><catch.erwischen><en> You'll also catch yourself getting impatient or frustrated, but then you'll see that when you breathe through these emotions, they go away. You're beginning to see the impact of the breath on the mind.
<G-vec00185-001-s310><catch.erwischen><de> Du wirst dich auch dabei erwischen, wie du ungeduldig oder frustriert wirst, aber dann erkennst du, daß, wenn du durch diese Emotionen durchatmest, diese verschwinden.
<G-vec00185-001-s311><catch.erwischen><en> You have to catch the right time and proclaim your real interest - then it is a worthwhile address.
<G-vec00185-001-s311><catch.erwischen><de> Man muss es hier richtig erwischen und sein echtes Interesse kundtun können, dann ist es eine sehr lohnende Adresse.
<G-vec00185-001-s312><catch.erwischen><en> You can catch these curvy cock lovers right from the homepage where a good selection of scenes has been availed for your pleasure.
<G-vec00185-001-s312><catch.erwischen><de> Du kannst diese kurvenreichen Schwanzliebhaber direkt auf der Homepage erwischen, wo eine gute Auswahl an Szenen für dein Vergnügen zur Verfügung steht.
<G-vec00185-001-s313><catch.erwischen><en> We can't begin to estimate whether we will catch a good weather window or will have to return home without achieving our goal.
<G-vec00185-001-s313><catch.erwischen><de> Wir können nicht abschätzen, ob wir ein günstiges Wetterfenster erwischen oder unverrichteter Dinge nach Hause zurückkehren müssen.
<G-vec00185-001-s314><catch.erwischen><en> I had to catch my train and as hard as it was – the first few songs of the Lausanne indie rock band sounded really good again – after 2-3 songs it was already over for me.
<G-vec00185-001-s314><catch.erwischen><de> Ich musste meinen Zug erwischen und so schwer es mir fiel – die ersten paar Songs der Lausanner Indie-Rockband klangen wieder echt gut – war dann nach 2-3 Songs bereits Schluss für mich.
<G-vec00185-001-s315><catch.erwischen><en> If your don’t get the chance to catch it by chance, there is no way to catch him.
<G-vec00185-001-s315><catch.erwischen><de> Wenn man ihn nicht zufällig antrifft, wie ich in der ersten Nacht, hat man quasi keine Möglichkeit, ihn zu erwischen.
<G-vec00185-001-s316><catch.erwischen><en> FRANK BLACK: I think you'll catch him there.
<G-vec00185-001-s316><catch.erwischen><de> FRANK BLACK: Ich denke, dort werden Sie ihn erwischen.
<G-vec00185-001-s317><catch.erwischen><en> I am not proud to catch the minister lying unscrupulously since I am overfilled with his lye.
<G-vec00185-001-s317><catch.erwischen><de> Ich bin nicht stolz den Minister beim skrupellosen Lügen zu erwischen aber ich habe genug von seinen Lügen.
<G-vec00185-001-s318><catch.erwischen><en> In Balham, south London, we watched people dashing across a junction to catch their trains to work.
<G-vec00185-001-s318><catch.erwischen><de> In Balham, im Londoner Süden, sahen wir Leute sich über eine Straßenkreuzung stürzen, um ihren Zug zur Arbeit zu erwischen.
<G-vec00185-001-s319><catch.erwischen><en> We have to hurry in order to catch the last cable car to Chamonix.
<G-vec00185-001-s319><catch.erwischen><de> Wir müssen uns beeilen, um die letzte Seilbahn nach Chamonix zu erwischen.
<G-vec00185-001-s320><catch.erwischen><en> The first rule of present-peeking is that you search only when you’re sure your parents won't catch you. Preferably, search while they’re out.
<G-vec00185-001-s320><catch.erwischen><de> Die erste Regel beim Suchen nach den Geschenken ist, dass du nur dann suchst, wenn du sicher sein kannst, dass dich deine Eltern nicht erwischen.
<G-vec00185-001-s321><catch.erwischen><en> – Discover the truth You can discover the truth or catch a cheating spouse with Aobo Keystroke Logger installed on Mac.
<G-vec00185-001-s321><catch.erwischen><de> – Die Wahrheit entdecken Mi t Aobo Keystroke Logger, das auf dem Mac installiert ist, können Sie die Wahrheit entdecken oder einen betrügenden Ehepartner erwischen.
<G-vec00185-001-s322><catch.erwischen><en> We can't begin to estimate whether we will catch a good weather window or will have to return home empty-handed.
<G-vec00185-001-s322><catch.erwischen><de> Wir können nicht abschätzen, ob wir ein günstiges Wetterfenster erwischen oder unverrichteter Dinge nach Hause zurückkehren müssen.
<G-vec00185-001-s323><catch.erwischen><en> No doors, moving quickly to try and catch decent light and angles from a fast moving platform.
<G-vec00185-001-s323><catch.erwischen><de> Keine Türen und ein sich bewegender Untergrund, und der ständige Versuch, vernünftiges Licht und gute Winkel zu erwischen.
<G-vec00185-001-s324><catch.erwischen><en> Don't let the police catch you and use all of the options available to you.
<G-vec00185-001-s324><catch.erwischen><de> Lassen Sie sich nicht der Polizei erwischt und nutzen alle Möglichkeiten zur Verfügung.
<G-vec00185-001-s325><catch.erwischen><en> Hubert von Goisern: But that was the one time that we didn't catch anything, on the bank holiday.
<G-vec00185-001-s325><catch.erwischen><de> Hubert von Goisern: Das war aber das eine Mal, als wir nichts erwischt haben, am Nationalfeiertag.
<G-vec00185-001-s326><catch.erwischen><en> One always started trying to keep dry but sooner or later a large breaker would catch you slap on the back and it was really more comfortable when this was over.
<G-vec00185-001-s326><catch.erwischen><de> Man versuchte immer trocken zu bleiben, aber früher oder später wurde man sowieso von einem großen Brecher erwischt, der einem auf den Rücken plätscherte, und es war wirklich angenehmer, wenn das vorbei war.
<G-vec00185-001-s327><catch.erwischen><en> Just make sure the chef doesn't catch you and uses you as an ingredient for his chilli con carne.
<G-vec00185-001-s327><catch.erwischen><de> Pass nur auf, dass der Koch dich nicht erwischt und als Zutat für sein Chilli con Carne verwenden will.
<G-vec00185-001-s328><catch.erwischen><en> He's passionate, he's loud and he knows how to inspire his troops, but you catch him on a bad day and he might shoot you dead if you look at him sideways… Always remember that.
<G-vec00185-001-s328><catch.erwischen><de> Er ist leidenschaftlich, laut und weiß, wie er seine Truppen bei Laune halten kann, aber wenn ihr ihn an einem schlechten Tag erwischt, erschießt er euch vielleicht, nur weil ihr ihn schräg anschaut...Behaltet das immer im Hinterkopf.
<G-vec00185-001-s329><catch.erwischen><en> Tip: The biggest fish is always the one next to the tree in the water, opposite of entrance, if you catch that one you will break the record for sure, but its weight depends within a small range on some kind of random, if you want the biggest possible (or if it slips away first time and you can´t find it anymore), leave the pond and come back to try again, biggest one I found so far was 11 pounds.
<G-vec00185-001-s329><catch.erwischen><de> Tip: Der größte Fisch ist immer der, der bei dem Baum im Wasser gegenüber vom Eingang steht, wenn du den erwischt brichst du auf jeden Fall den Rekord, aber das Gewicht ist in Grenzen abhängig von einer Art Zufallsgenerator, wenn du den Größtmöglichen willst (oder wenn er beim ersten Mal entwischt und du ihn nicht mehr finden kannst), verlass den Fischweiher und komm zurück um nochmal zu versuchen, der Größte den ich gefunden habe wog 11 Pfund.
<G-vec00185-001-s330><catch.erwischen><en> "If you can catch that event in the mind — the mind saying, ""This is this and that is that; this is the pain and it's doing this,"" and all of the other running commentary that the mind makes on the present moment — then you begin to realize this in itself is a lot of the problem right there."
<G-vec00185-001-s330><catch.erwischen><de> "Wenn ihr diesen Augenblick im Geist erwischt, den Augenblick, in dem der Geist sagt, ""Das ist dies und das ist jenes; das ist der Schmerz und er macht jenes"", und den ganzen Rest des laufenden Kommentars den der Geist in diesem Augenblick abgibt – dann beginnt ihr zu erkennen, dass dort eine Hauptursache für eure Probleme verborgen liegt."
<G-vec00185-001-s331><catch.erwischen><en> Try to kiss and not let her brother catch you.
<G-vec00185-001-s331><catch.erwischen><de> Versuchen Sie zu küssen und nicht zulassen, ihr Bruder erwischt.
<G-vec00185-001-s332><catch.erwischen><en> Obrenovic: We've managed to catch a few more, either by gunpoint or in mines.
<G-vec00185-001-s332><catch.erwischen><de> Obrenovic: Wir haben noch ein paar andere erwischt, mit dem Gewehr oder auf den Minenfeldern.
<G-vec00185-001-s333><catch.erwischen><en> However, we should not wait for a disease can “catch us”.
<G-vec00185-001-s333><catch.erwischen><de> Wir sollten jedoch nicht warten, bis uns eine Krankheit „erwischt“.
<G-vec00185-001-s334><catch.erwischen><en> While driving by a market I almost catch a bullet.
<G-vec00185-001-s334><catch.erwischen><de> Als ich am Markt vorbeifahre, erwischt mich beinah eine Kugel.
<G-vec00185-001-s335><catch.erwischen><en> This reduces the telephone bill and team play will be much better, if this is allowed --- or the other will not catch you at team play.
<G-vec00185-001-s335><catch.erwischen><de> Somit kann man Kosten sparen und auch besser im Team arbeiten, wenn dies auch erlaubt ist -- oder man dabei nicht erwischt wird.
<G-vec00185-001-s336><catch.fangen><en> However, his deceitful friend Dog greedily wolfs down the catch and heedlessly risks harming his friends.
<G-vec00185-001-s336><catch.fangen><de> Doch sein hinterlistiger Freund Hund vertilgt gierig den Fang und nimmt rücksichtslos den Schaden seiner Freunde in Kauf.
<G-vec00185-001-s337><catch.fangen><en> The East coast of England is the home of the Essex Smacks, former fishing boats to catch oysters.
<G-vec00185-001-s337><catch.fangen><de> Die Ostküste Englands ist die Heimat der Essex Smacks, ehemalige Fischereiboote für den Fang von Austern.
<G-vec00185-001-s338><catch.fangen><en> This seems to be the catch cry of an Aries—Sagittarius relationship.
<G-vec00185-001-s338><catch.fangen><de> Dies scheint der Fang Schrei eines Widder-Schütze Beziehung zu sein.
<G-vec00185-001-s339><catch.fangen><en> The huge caverns of a blast freezer held the days catch — dozens of huge tuna and two small blue sharks.
<G-vec00185-001-s339><catch.fangen><de> Die riesigen Höhlen der Gefrierräume enthielten den Fang des heutigen Tages – dutzende von riesigen Thunfischen und zwei kleinere Blauhaie.
<G-vec00185-001-s340><catch.fangen><en> The area is actually a fishing village, so a night-time visit to historic Palmilla beach will include watching the fishermen bring in their catch.
<G-vec00185-001-s340><catch.fangen><de> Dieser Ort ist eigentlich ein Fischerdorf, weshalb man nachts am historischen Strand Palmilla sehen kann, wie die Fischer ihren Fang einbringen.
<G-vec00185-001-s341><catch.fangen><en> Two weeks ago, the fishing of dolphin fish started and the fishers of Cala Ratjada are more than satisfied with the catch of that fish this year.
<G-vec00185-001-s341><catch.fangen><de> Vor zwei Wochen gab es den Startschuss für den Fang dieses Fisches und die Fischer von Cala Ratjada sind mehr als zufrieden mit ihrem Fang dieses Jahr.
<G-vec00185-001-s342><catch.fangen><en> The pond is ideal for fishermen who love fishing itself and fish in catch&release style-the quantity of fish in the pond is high and so will their catch be.
<G-vec00185-001-s342><catch.fangen><de> Der Teich ist ideal für Fischer, die das Fischen mögenun fangen und freilassen- Menge der Fische im Teich ist hoch und so wird auch Fang sein.
<G-vec00185-001-s343><catch.fangen><en> A day’s catch of carp, bream, perch, tench, and a lot more would be delightful and fun.
<G-vec00185-001-s343><catch.fangen><de> Ein Tag Fang von Karpfen, Brachsen, Barsch, Schleie, und vieles mehr wäre wunderbar und macht Spaß.
<G-vec00185-001-s344><catch.fangen><en> Another rare catch for you.
<G-vec00185-001-s344><catch.fangen><de> Ein weiterer seltener Fang für dich.
<G-vec00185-001-s345><catch.fangen><en> He was asked to lay out fyke nets every evening, evaluate the catch the next morning, and preserve it for scientific purposes.
<G-vec00185-001-s345><catch.fangen><de> Jeden Abend musste er Reusen auslegen, am nächsten Morgen den Fang auswerten und für wissenschaftliche Zwecke präservieren.
<G-vec00185-001-s346><catch.fangen><en> Anglers are releasing many of those fish and applying to our “Big Catch” angler recognition program (MyFWC.com/Fishing) to memorialize their catch.
<G-vec00185-001-s346><catch.fangen><de> "Angler sind die Freigabe viele dieser Fische und Anwendung zu unserem ""Big Catch"" Angler Erkennungsprogramm (MyFWC.com / Fischerei) um ihren Fang zu gedenken."
<G-vec00185-001-s347><catch.fangen><en> No more long time to assemble a hike, rent a boat or a boat, buy tackle and bait, just start the game Russian fishing line and enjoy the tranquility and beauty of your monitor, and a great catch.
<G-vec00185-001-s347><catch.fangen><de> Nicht mehr lange, um eine Wanderung zusammenzustellen, ein Boot mieten oder ein Boot, kaufen und Köder, starte das Spiel russischen Angelschnur und genießen Sie die Ruhe und die Schönheit Ihres Monitors, und ein großer Fang.
<G-vec00185-001-s348><catch.fangen><en> The main thing is not to forget the gear to provide a fishing line with a large diameter, so as not to miss the big catch.
<G-vec00185-001-s348><catch.fangen><de> Die Hauptsache ist, nicht zu vergessen das Getriebe eine Angelschnur mit einem großen Durchmesser zu schaffen,, um nicht den großen Fang zu verpassen.
<G-vec00185-001-s349><catch.fangen><en> "Enjoy your breakfast of fresh fruits at your private terrace, some sashimi from the catch of the day"" in the shade of a palm tree and your favourite meal, created together with our chef, during sunset, barefooted at a table, set for you at the beach of the Indian Ocean."
<G-vec00185-001-s349><catch.fangen><de> Genießen Sie Ihr Frühstück aus frischen Früchten auf Ihrer privaten Terrasse, eine Portion Sashimi aus dem heutigen Fang im Schatten einer Palme und Ihre Lieblingsspeise, die Sie gemeinsam mit unserem Chef zu Ihrem persönlichen Gaumenerlebnis verfeinert haben, zum Sonnenuntergang mit den Füßen im Sand am Strand des Indischen Ozeans.
<G-vec00185-001-s350><catch.fangen><en> These guys were hot and hungry and ready to show off their catch.
<G-vec00185-001-s350><catch.fangen><de> Diese Jungs waren heiß und hungrig und bereit zu zeigen, ihren Fang.
<G-vec00185-001-s351><catch.fangen><en> Time and again, countries bordering the Southern Ocean find and detain ships fishing illegally and confiscate their catch.
<G-vec00185-001-s351><catch.fangen><de> Immer wieder werden von den Anrainerstaaten des Südpolarmeeres Schiffe beim verbotenen Fischfang überrascht, aufgebracht und der Fang beschlagnahmt.
<G-vec00185-001-s352><catch.fangen><en> I just want to request you remind him, if he could e-mail the picture he took of my son and me with our catch.
<G-vec00185-001-s352><catch.fangen><de> Ich möchte nur bitten Sie ihn daran erinnern,, wenn er eine E-Mail das Bild nahm er meinen Sohn und mich mit unseren Fang.
<G-vec00185-001-s353><catch.fangen><en> Daily catch is limited to 5 protected white fish (crucian carp, nase, barbel, chub,...).
<G-vec00185-001-s353><catch.fangen><de> Der tägliche Fang ist auf 5 geschützte Weißfische beschränkt (Karauschen, Nase, Barbe, Döbel,...).
<G-vec00185-001-s354><catch.fangen><en> Whether it is the nearby ocean tides, the fishermen bringing their catch in around 4 PM every day, going to the local market or enjoying crèpes with cider, the region has an astonishing vitality, beautiful landscapes and fields, no pollution and strong cultural traditions.
<G-vec00185-001-s354><catch.fangen><de> Ob es nun das Meer direkt vor der Tür, die Fischer, die um vier Uhr morgens ihren Fang an Land bringen, der örtliche Markt oder die köstlichen Crépes mit Cidre sind – die Region ist gekennzeichnet von einer erstaunlichen Vitalität, wunderschönen Landschaften und ausgeprägten kulturellen Traditionen.
<G-vec00185-001-s355><catch.fangen><en> Catch with your left hand and then catch in your right hand.
<G-vec00185-001-s355><catch.fangen><de> Fange mit der linken Hand und fange dann mit der rechten Hand.
<G-vec00185-001-s357><catch.fangen><en> And I water them with boiling water, catch them with needles, so as not to smudge the walls and burn them on the fire.
<G-vec00185-001-s357><catch.fangen><de> Und ich gieße sie mit kochendem Wasser, fange sie mit Nadeln, um die Wände nicht zu verschmieren und sie im Feuer zu verbrennen.
<G-vec00185-001-s358><catch.fangen><en> I value all life, even that of insects (I no longer kill flies and spiders, I catch them and release them outside).
<G-vec00185-001-s358><catch.fangen><de> Ich wertschätze alles Leben, sogar das von Insekten (Ich töte keine Fliegen und Spinnen mehr, ich fange sie und lasse sie draußen frei).
<G-vec00185-001-s359><catch.fangen><en> Catch him in a place, surround him and don't let him break through.
<G-vec00185-001-s359><catch.fangen><de> Fange ihn an einem Ort, umstelle ihn und lasse ihn nicht durchbrechen.
<G-vec00185-001-s360><catch.fangen><en> "2011-10-03 15:31:42 - Catch my husband cheating - common sense will prevail Are you asking the question: ""How can I catch my husband cheating?"" if so, then I'm sorry."
<G-vec00185-001-s360><catch.fangen><de> "2011-10-03 15:31:42 - Fangen Sie meinen Mann betrogen - der gesunde Menschenverstand wird sich durchsetzen Sind Sie der Frage: ""Wie kann ich fange mein Mann betrügt"" wenn ja, dann tut mir leid."
<G-vec00185-001-s361><catch.fangen><en> So, I love every minute on my rock platform, soak up the sun, enjoy the day, catch myself a few fish and know for sure: summertime and the livin’ is easy.
<G-vec00185-001-s361><catch.fangen><de> So liebe ich jede Minute auf meinem Felsen, sauge die Sonnenstrahlen auf, geniesse den Tag, fange mir ein paar Fische und bin mir ganz sicher: summertime and the livin’ is easy.
<G-vec00185-001-s362><catch.fangen><en> I catch some more rainbow and brown trout, but the time to leave this paradise is getting closer and I decide to go back to where I had lost the big grayling in the early afternoon.
<G-vec00185-001-s362><catch.fangen><de> Ich fange noch ein paar Regenbogen- und Bachforellen, aber die Zeit dieses Paradies zu verlassen rückt näher und ich beschließe an den Ort zurückzukehren, an dem ich die große Äsche am frühen Nachmittag verloren habe.
<G-vec00185-001-s363><catch.fangen><en> View details Description Catch the true beauty of lifeThe Xperia XZ1 Compact's Motion Eye camera with super slow motion and predictive shooting lets you capture moments like you've never seen them before.
<G-vec00185-001-s363><catch.fangen><de> Beschreibung Fange die wahre Schönheit des Lebens einDank der Motion Eye-Kamera des Xperia XZ1 Compact mit Super slow motion Funktion und vorhersagender Aufnahme fängst du Augenblicke so ein, wie du sie zuvor noch nie gesehen hast.
<G-vec00185-001-s364><catch.fangen><en> Catch all flies and eat your way through 10 screen.
<G-vec00185-001-s364><catch.fangen><de> Fange alle Fliegen und futtere dich durch 10 Levels.
<G-vec00185-001-s365><catch.fangen><en> I catch a series of pugnacious brown trout, between 20 and 30 cm.
<G-vec00185-001-s365><catch.fangen><de> Ich fange eine Reihe von kämpferischen Bachforellen die zwischen 20 und 30 cm.
<G-vec00185-001-s366><catch.fangen><en> Then catch the red squares.
<G-vec00185-001-s366><catch.fangen><de> Fange dann die roten Quadrate.
<G-vec00185-001-s367><catch.fangen><en> I catch another smaller barbel then I swap the green nymph with a striking red collar one.
<G-vec00185-001-s367><catch.fangen><de> Ich fange eine andere kleinere Barbe, dann wechsel ich die Grünkopfnymphe mit einer mit auffälligem roten Kragen.
<G-vec00185-001-s368><catch.fangen><en> Catch King Stefan while he's marching to Nuoren.
<G-vec00185-001-s368><catch.fangen><de> Fange König Stefan ab, während er nach Nuoren marschiert.
<G-vec00185-001-s369><catch.fangen><en> Catch both a man and a woman.
<G-vec00185-001-s369><catch.fangen><de> Fange einen Mann und eine Frau.
<G-vec00185-001-s370><catch.fangen><en> Her finger reaches up to clear it, but I catch it up, chiding.
<G-vec00185-001-s370><catch.fangen><de> Sie hebt ihren Finger, um es wegzuwischen, aber ich fange ihre Hand tadelnd ab.
<G-vec00185-001-s371><catch.fangen><en> Catch a bag mid air.
<G-vec00185-001-s371><catch.fangen><de> Fange eine Tasche aus der Luft.
<G-vec00185-001-s372><catch.fangen><en> * “I did not consider it possible to catch that many mosquitoes.
<G-vec00185-001-s372><catch.fangen><de> “Ich hatte es nicht für möglich gehalten dass ich damit so viele Mücken fange.
<G-vec00185-001-s373><catch.fangen><en> Manual: Catch all the moving fish by simple clicking or touching them with your finger.
<G-vec00185-001-s373><catch.fangen><de> "Handbuch: Fange alle schwimmenden Fische, entweder durch einen Mausklick oder indem du sie mit deinem Finger berührst""."
<G-vec00185-001-s374><catch.fangen><en> An extraordinary Eden where organic fish are being bred, their growth and harvesting taking place on a natural schedule, where bass, bream and mullets feed only on what they catch in the canals.
<G-vec00185-001-s374><catch.fangen><de> Ein einzigartiges Paradies, in dem die Eigentümer sich mit der Zucht von Bio-Fisch beschäftigen, dessen Wachstum und Angeln gemäß der natürlichen Zeiten erfolgt, in dem sich Seebarsche, Goldbrassen und Meeräschen nur von dem ernähren, was sie in den Kanälen fangen.
<G-vec00185-001-s375><catch.fangen><en> Please catch the red colored one, because other colors do not go to the Kowloon area.
<G-vec00185-001-s375><catch.fangen><de> Sie fangen die roten, da andere Farben gehen nicht auf den Bereich Kowloon.
<G-vec00185-001-s376><catch.fangen><en> In these waters you can catch excellent specimens, what do not even know many of the local residents.
<G-vec00185-001-s376><catch.fangen><de> In diesen Gewässern können Sie ausgezeichnete Exemplare fangen, was nicht einmal wissen, viele der Anwohner.
<G-vec00185-001-s377><catch.fangen><en> But the bloodhounds catch her again.
<G-vec00185-001-s377><catch.fangen><de> Doch die Häscher fangen sie wieder ein.
<G-vec00185-001-s378><catch.fangen><en> 7:12 And the king arose in the night, and said unto his servants, I will now shew you what the Syrians have done to us. They know that we be hungry; therefore are they gone out of the camp to hide themselves in the field, saying, When they come out of the city, we shall catch them alive, and get into the city.
<G-vec00185-001-s378><catch.fangen><de> 7:12 Und der König stand in der Nacht auf und sprach zu seinen Knechten: Ich will euch doch sagen, was die Syrer mit uns vorhaben: Sie wissen, daß wir Hunger leiden, und sind aus dem Lager gegangen, um sich im Felde zu verbergen, und denken: Wenn die aus der Stadt gehen, wollen wir sie lebendig fangen und in die Stadt eindringen.
<G-vec00185-001-s379><catch.fangen><en> Slower systems may not be able to recalculate your route in time to catch the next turn and get you back on track.
<G-vec00185-001-s379><catch.fangen><de> Langsamere Systeme möglicherweise nicht in der Lage, um Ihre Route in der Zeit zu fangen die nächste Abzweigung und steigen Sie wieder auf den richtigen Weg.
<G-vec00185-001-s380><catch.fangen><en> 32801 Women's Scalloped Print One-Piece Swimwear Scoop Neck Tank Top Bathing Suit This scalloped print slimming swimsuit will shape a flattering silhouette to catch eyes.
<G-vec00185-001-s380><catch.fangen><de> 32801 Women's überbacken Drucken einteilige Badebekleidung Scoop Neck Pullunder Badeanzug/Badehose Diese überbackene Druck schlank-Badeanzug wird eine schmeichelhafte Silhouette Augen fangen prägen.
<G-vec00185-001-s381><catch.fangen><en> It's very common to have flare ups when you grill so you don't want to have an overhang that could potentially catch on fire when your flare ups occur.
<G-vec00185-001-s381><catch.fangen><de> Es ist sehr üblich, Flare ups haben, wenn Sie grillen, so dass Sie dies nicht wünschen einen Überhang haben dass möglicherweise Feuer fangen, wenn Ihr Flare ups auftreten.
<G-vec00185-001-s382><catch.fangen><en> In some cases, you can catch a break in shipping fees with picking closer companies.
<G-vec00185-001-s382><catch.fangen><de> Oft können Sie mit der Wahl näher Unternehmen eine Pause bei den Versandkosten fangen.
<G-vec00185-001-s383><catch.fangen><en> Come Catch Yours Today with Captain John Leech on Johns Lake.
<G-vec00185-001-s383><catch.fangen><de> Gekommen Fangen Sie noch heute mit Captain John Leech auf Johns See.
<G-vec00185-001-s384><catch.fangen><en> Law enforcement may also use catphishing techniques to catch criminals.
<G-vec00185-001-s384><catch.fangen><de> Die Strafverfolgung kann auch Catphishing-Techniken einsetzen, um Kriminelle zu fangen.
<G-vec00185-001-s385><catch.fangen><en> Private research on infidelity, location of people inside and outside More... the country, capturing vehicles, notices, catch maintenance, evictions etc.
<G-vec00185-001-s385><catch.fangen><de> Private Forschung auf Untreue, Standort von Personen innerhalb und außerhalb Mehr... des Landes, die Erfassung Fahrzeugen, Hinweise, fangen Wartung, Vertreibungen usw.
<G-vec00185-001-s386><catch.fangen><en> Use the mouse to play Tarzan Ball and help out his arm and the Hedgehog to catch the ball is seeking.
<G-vec00185-001-s386><catch.fangen><de> Benutzen Sie die Maus, Tarzan Ball spielen und helfen, seinen Arm und der Igel, den Ball zu fangen sucht.
<G-vec00185-001-s387><catch.fangen><en> But we can catch a few trout and I smoke them at home.
<G-vec00185-001-s387><catch.fangen><de> Aber wir fangen ein paar Forellen, die ich zu hause raeuchere.
<G-vec00185-001-s388><catch.fangen><en> Allinformation on fishing in The pond Brdinje, with licence Catch and release .
<G-vec00185-001-s388><catch.fangen><de> Alle Infos über Fischerei in Der Teich Brdinje, mit dem Angelschein Fangen und Freilassen .
<G-vec00185-001-s389><catch.fangen><en> Use arrow keys left-right to rotate the tiny iceberg and throw baby Pengui to catch the fish.
<G-vec00185-001-s389><catch.fangen><de> Mit den Pfeiltasten links-rechts, um die winzigen Eisberg zu drehen und werfen Baby Pengui den Fisch zu fangen.
<G-vec00185-001-s390><catch.fangen><en> Above by using the mouse or the arrow keys to try to catch the falling pancakes.
<G-vec00185-001-s390><catch.fangen><de> Vor, indem Sie die Maus oder die Pfeiltasten, um zu versuchen, um die fallenden Pfannkuchen zu fangen.
<G-vec00185-001-s391><catch.fangen><en> A mai összeállítást ezek a szeptemberi színek (and lights) inspired by . If you catch your mood emanating from the images below, here you will inspirálódhatsz, the next time you redecorated your room or condo .
<G-vec00185-001-s391><catch.fangen><de> Wenn Sie fangen die Stimmung, die aus den Bildern unten, hier finden Sie inspirálódhatsz, das nächste Mal, wenn Sie Ihr Zimmer renoviert oder Eigentumswohnung .
<G-vec00185-001-s392><catch.fangen><en> "10 ""Sorry,"" Shadow said, turning to look at a big dog who was watching a game of catch."
<G-vec00185-001-s392><catch.fangen><de> "10 ""Entschuldige"", sagte Shadow und drehte sich um, um zu einer Deutschen Dogge zu schauen, die beim Fangen spielen zusah."
<G-vec00185-001-s393><catch.fangen><en> Catch Limit and restocking: For Perch over 25cm, a maximum of 2 fish raised per angler per day.
<G-vec00185-001-s393><catch.fangen><de> Fangen Sie Limit und Besatzmaßnahmen: Für Perch über 25cm, hob ein Maximum von 2 Fisch pro Angler pro Tag.
<G-vec00185-001-s394><catch.fangen><en> When you first catch a peek, it seems as though the entire front of the backpack is the opening flap.
<G-vec00185-001-s394><catch.fangen><de> Wenn Sie zuerst fangen Sie einen Blick, es scheint, als ob die gesamte Front des Rucksacks ist der Öffnungsklappe.
<G-vec00185-001-s395><catch.fangen><en> Change your underwater view and catch more fish with the Dragonfly 4, 5 and 7 wide-spectrum CHIRP DownVisionTM technology.
<G-vec00185-001-s395><catch.fangen><de> Verbessern Sie Ihre Unterwassersicht mit Dragonfly 4, 5 und 7 und fangen Sie mehr Fische dank der integrierten Broadband-CHIRP DownVisionTM-Technologie.
<G-vec00185-001-s396><catch.fangen><en> And even then, if they catch up with him, catch him and establish his identity.
<G-vec00185-001-s396><catch.fangen><de> Und selbst dann, wenn sie ihn einholen, fangen sie ihn und stellen seine Identität fest.
<G-vec00185-001-s397><catch.fangen><en> Room Challenge 2 Catch the stones to earn money and buy furniture to your room.
<G-vec00185-001-s397><catch.fangen><de> Zimmer Challenge 2 Fangen Sie die Steine, um Geld zu verdienen und kaufe Möbel für dein Zimmer.
<G-vec00185-001-s398><catch.fangen><en> Catch the green diamond to transform into a mutant.
<G-vec00185-001-s398><catch.fangen><de> Fangen Sie die grüne Raute, in einen Mutanten zu verwandeln.
<G-vec00185-001-s399><catch.fangen><en> Catch every sparkle of light.
<G-vec00185-001-s399><catch.fangen><de> Fangen Sie jeden Lichtschimmer ein.
<G-vec00185-001-s400><catch.fangen><en> Catch her while you can - this heart-stopping Black version that has all the Loubi Ladies talking.
<G-vec00185-001-s400><catch.fangen><de> Fangen Sie sie, während Sie können - dieses Herz-stopp Silber-Version, die alle sprechen die Loubi Damen hat.
<G-vec00185-001-s401><catch.fangen><en> Bushwalk and snorkel, share bush-tucker or learn to craft spears and catch fish in the traditional way.
<G-vec00185-001-s401><catch.fangen><de> "Unternehmen Sie Buschwanderungen und schnorcheln Sie, kosten Sie vom ""Bush Tucker"" oder lernen Sie die Herstellung von Speeren und fangen Sie auf traditionelle Weise Fisch."
<G-vec00185-001-s402><catch.fangen><en> Game Description: Catch only the small fish that swim in the sea.
<G-vec00185-001-s402><catch.fangen><de> Spielbeschreibung: Fangen Sie nur die kleinen Fische, die im Meer schwimmen.
<G-vec00185-001-s403><catch.fangen><en> Catch one of the most influential jazz musicians alive today.
<G-vec00185-001-s403><catch.fangen><de> Fangen Sie eine der einflussreichsten Jazzmusiker heute noch am Leben.
<G-vec00185-001-s405><catch.fangen><en> Catch both balls.
<G-vec00185-001-s405><catch.fangen><de> Fangen Sie beide Bälle.
<G-vec00185-001-s406><catch.fangen><en> Catch the treasures to pass to the next level.
<G-vec00185-001-s406><catch.fangen><de> Fangen Sie die Schätze, um zum nächsten Level zu gelangen.
<G-vec00185-001-s407><catch.fangen><en> Drnovický wetland called & quot; Catch & quot; the water pools in Kopaninách .
<G-vec00185-001-s407><catch.fangen><de> Drnovický Feuchtgebiet namens & quot; Fangen Sie & quot; die Wasserbecken in Kopaninách .
<G-vec00185-001-s408><catch.fangen><en> Catch the funny kids while jumping to the net, some times extra gifts will fall down catch it will get more points.
<G-vec00185-001-s408><catch.fangen><de> Fangen Sie die lustigen Kinder beim Springen auf den Nettopreis fangen einige Male extra Geschenke fallen wird es mehr Punkte zu bekommen.
<G-vec00185-001-s409><catch.fangen><en> Forests catch and store water, stabilize soils, harbour biodiversity and make an important contribution to regulating climate and the greenhouse gases that are causing climate change.
<G-vec00185-001-s409><catch.fangen><de> Wälder fangen Wasser auf und speichern es, sie festigen die Böden, sorgen für Biodiversität und leisten einen wichtigen Beitrag zur Regulierung des Klimas und der Treibhausgase, die den Klimawandel verursachen.
<G-vec00185-001-s410><catch.fangen><en> Go through immigration again here and take a bus to Changuinola, than Changuinola to Almirante or catch a taxi to Almirante ($5/person) passing the town of Changuinola along the route.
<G-vec00185-001-s410><catch.fangen><de> Gehen Sie durch Einwanderung wieder hier und nehmen Sie einen Bus zu Changuinola, als Changuinola zu Almirante oder fangen Sie ein Taxi zu Almirante ($5/person) an vorbeigehend der Stadt von Changuinola entlang der Route.
<G-vec00185-001-s411><catch.fangen><en> Catch the books and pencils you find floating in the sky.
<G-vec00185-001-s411><catch.fangen><de> Fangen Sie die Bücher und Bleistifte Sie in den Himmel schwebende finden .
<G-vec00185-001-s427><catch.fangen><en> At least it is a fact that you primarily catch salmon when you bait your hooks with shrimp.
<G-vec00185-001-s427><catch.fangen><de> Auf jeden Fall ist es eine Tatsache, daß man mit Garnelen vor allem Lachse fängt.
<G-vec00185-001-s428><catch.fangen><en> He remarks that it doesn't actually matters if he will catch a fish or not as long as he can chat with his buddies and have some cooled beers.
<G-vec00185-001-s428><catch.fangen><de> Er meint, es sei ihm egal, ob er tatsächlich etwas fängt solange er nur mit seinen Freunden quatschen und sich dabei ein paar Bier reinkippen kann.
<G-vec00185-001-s429><catch.fangen><en> During all this time millions of its needles catch the radiation from space, which was generated by people.
<G-vec00185-001-s429><catch.fangen><de> Ihre gesamte Lebenszeit hindurch fängt sie in ihren Millionen von Nadeln aus dem kosmischen Raum die Energiestrahlen ein, die von Menschen generiert werden.
<G-vec00185-001-s430><catch.fangen><en> Return to Infidelity Articles Cheating Husbands: Top 10 Ways on How to Catch a Cheating Husband Cheating husbands leave many signs and with a bit of detective work, a wife can catch her husband with solid proof.
<G-vec00185-001-s430><catch.fangen><de> Zurück zur Untreue Artikel Cheating Husbands: oben 10 Möglichkeiten auf, wie ein Ehemann betrug Cheating Männer fangen lassen viele Zeichen und mit einem wenig Detektivarbeit, eine Frau kann ihren Mann mit festen Beweis fängt.
<G-vec00185-001-s431><catch.fangen><en> After the city tour we transfer to the airport of Osh and catch an evening flight to Bishkek.
<G-vec00185-001-s431><catch.fangen><de> Am Nachmittag fahren Sie zurück nach Bischkek und fängt die Stadtrundfahrt in Bischek an.
<G-vec00185-001-s432><catch.fangen><en> We've ensured that the Triobike mono hood will keep water out, will not catch fire and will never fade thanks to a special solution-dyed sunacryl acrylic fiber that is water resistant, fire tested and 100% UV stable.
<G-vec00185-001-s432><catch.fangen><de> Wir haben dafür gesorgt, dass das Triobike Mono Verdeck kein Wasser durchlässt, kein Feuer fängt und niemals seine Farbe verliert dank einer speziellen spinngefärbten Acrylfaser, die wasserfest, brandgeprüft und 100% UV-beständig ist.
<G-vec00185-001-s433><catch.fangen><en> If your clothes catch fire, immediately stop what you're doing, drop flat to the ground, and roll around until you put the fire out.
<G-vec00185-001-s433><catch.fangen><de> Wenn deine Kleidung Feuer fängt, unterbrich was du gerade tust, und rolle am Boden herum, um das Feuer zu ersticken.
<G-vec00185-001-s434><catch.fangen><en> Warmer weather typically is the most effective time to come explore and catch peacock bass.
<G-vec00185-001-s434><catch.fangen><de> Wärmeres Wetter ist in der Regel die effektivste Zeit zu kommen zu erkunden und fängt Peacock Bass.
<G-vec00185-001-s435><catch.fangen><en> "He likes to sleep in the sun, look out the window and catch mice ""(cat)."
<G-vec00185-001-s435><catch.fangen><de> "Er schläft gerne in der Sonne, schaut aus dem Fenster und fängt Mäuse ""(Katze)."
<G-vec00185-001-s436><catch.fangen><en> Stop, drop, and roll if your clothes catch fire.
<G-vec00185-001-s436><catch.fangen><de> Bleibe stehen, lasse dich fallen, und rolle hin und her, wenn deine Kleidung Feuer fängt.
<G-vec00185-001-s437><catch.fangen><en> It was just shy of a Florida trophy catch and was the last fish of the day.
<G-vec00185-001-s437><catch.fangen><de> Es war nur schüchtern von einer Trophäe fängt Florida und war der letzte Fisch des Tages.
<G-vec00185-001-s438><catch.fangen><en> You will not catch any fish if you do not listen to the river, a father explains to his sons.
<G-vec00185-001-s438><catch.fangen><de> Ihr fängt keinen Fisch, wenn ihr nicht auf den Fluss hört, erklärt der Vater seinen Söhnen.
<G-vec00185-001-s439><catch.fangen><en> The early bird does not catch the worm at the Kitzsteinhorn – it is treated to a glacier breakfast with the finest regional specialities like jam, cheese or bacon instead.
<G-vec00185-001-s439><catch.fangen><de> Gletscherfrühstück Der frühe Vogel fängt am Kitzsteinhorn nicht den Wurm – er wird beim Gletscherfrühstück mit feinsten regionalen Spezialitäten wie Marmelade, Käse oder Speck verwöhnt.
<G-vec00185-001-s440><catch.fangen><en> With the paperboard’s piling to a higher level, the machine tool platform automatically adjusts the tilting height; when the paperboards are piled to the planned height, the paper receiving tray will automatically open and catch the paperboard under the pneumatic motion.
<G-vec00185-001-s440><catch.fangen><de> Mit der Anhäufung der Pappe zu einem hochgradigen, justiert die Werkzeugmaschinenplattform automatisch die Kippenhöhe; wenn die Pappen zur geplanten Höhe angehäuft werden, öffnet der empfangende Papierbehälter automatisch und fängt die Pappe unter der pneumatischen Bewegung.
<G-vec00185-001-s441><catch.fangen><en> Yes, it may sound a little kitschy, but the music of the Melt Trio really does catch the human primeval desire for harmony and perfection.
<G-vec00185-001-s441><catch.fangen><de> Ja, es mag ein wenig kitschig klingen, aber die Musik des Melt Trios fängt tatsächlich das menschliche Urverlangen nach Harmonie und Vollkommenheit auf.
<G-vec00185-001-s442><catch.fangen><en> A week long tournament had them tired and ready to sit back and catch bass.
<G-vec00185-001-s442><catch.fangen><de> Eine Woche lang Turnier hatte sie müde und bereit, wieder und fängt Bass zu sitzen.
<G-vec00185-001-s443><catch.fangen><en> When the tea is poured, the filter will catch any leaves, meaning that the tea is free of any leaves.
<G-vec00185-001-s443><catch.fangen><de> Wenn der Tee gegossen wird, fängt der Filter alle Blätter, was bedeutet, dass alle Blätter der Tee ist.
<G-vec00185-001-s444><catch.fangen><en> Take the game Free Aqua Zoo: here, players catch their own fish in nearby lakes, place them in their aquarium, feed, cuddle and level them up bit by bit.
<G-vec00185-001-s444><catch.fangen><de> In Free Aqua Zoo fängt der Spieler Fische in den Seen der Umgebung, er bringt sie in sein Aquarium, füttert sie, knuddelt sie und zieht sie schrittweise groß.
<G-vec00185-001-s445><catch.fangen><en> No, at this time of the day, it’s not possible to catch fish, even the small time fisher knows that.
<G-vec00185-001-s445><catch.fangen><de> Nein, um diese Zeit fängt man keine Fische, das weiß jeder noch so kleine Fischer.
<G-vec00185-001-s446><catch.fangen><en> But I've too often failed to catch anything to still think: it has to work now, something has to bite.
<G-vec00185-001-s446><catch.fangen><de> Aber ich hab zu oft nichts gefangen, als dass ich immer noch denken würde: Das muss jetzt klappen, es muss was beißen.
<G-vec00185-001-s447><catch.fangen><en> Throw and catch a boom five times as fast as possible.
<G-vec00185-001-s447><catch.fangen><de> Ein Bumerang wird so schnell wie möglich fünf mal gefangen.
<G-vec00185-001-s448><catch.fangen><en> Find all 5 of them and run after them until you catch them, if you lose one of them, leave that part of town and come back to try again.
<G-vec00185-001-s448><catch.fangen><de> Finde alle 5 und renn ihnen nach bis du sie gefangen hast, wenn du einen verlierst, verlass den Teil der Stadt und komm nochmal zurück um es nochmal zu versuchen.
<G-vec00185-001-s449><catch.fangen><en> Alas, we didn't catch anything.
<G-vec00185-001-s449><catch.fangen><de> Leider haben wir nichts gefangen.
<G-vec00185-001-s450><catch.fangen><en> 20 Therefore thus saith the Lord God: Behold I declare against your cushions, wherewith you catch flying souls: and I will tear them off from your arms: and I will let go the souls that you catch, the souls that should fly.
<G-vec00185-001-s450><catch.fangen><de> 20 Darum spricht Gott der HERR: Siehe, ich will über eure Binden kommen, mit denen ihr die Seelen fangt, und will sie von euren Armen reißen und die Seelen, die ihr gefangen habt, befreien.
<G-vec00185-001-s451><catch.fangen><en> Enjoy the selection of fine Eastern and Western Specialties, the freshly caught lobsters, prawns and other seafood provided by local fisherman or your own catch.
<G-vec00185-001-s451><catch.fangen><de> Genießen Sie die Auswahl an feinen östlichen und westlichen Spezialitäten, der frisch gefangenen Hummer, der Garnelen und anderer Meeresfrüchte, die vom lokalen Fischer oder von Ihnen selbst gefangen wurden.
<G-vec00185-001-s452><catch.fangen><en> It took me a moment to catch myself, then an intrigued smile pulled at the corners of my mouth.
<G-vec00185-001-s452><catch.fangen><de> Es dauerte einen Moment, bis ich mich wieder gefangen hatte, dann kroch ein fasziniertes Lächeln auf meine Lippen.
<G-vec00185-001-s453><catch.fangen><en> In addition, you can catch Pokémon or perform other simple actions by pressing the button on the device.
<G-vec00185-001-s453><catch.fangen><de> Zudem können durch Drücken des Knopfes auf dem Gerät Pokémon gefangen oder andere einfache Aktionen durchgeführt werden.
<G-vec00185-001-s454><catch.fangen><en> Sometimes the Tibetans would catch Chinese, tie them together by the hair, and sit on them.
<G-vec00185-001-s454><catch.fangen><de> Manchmal haben die Tibeter die Chinesen gefangen, haben sie an den Haaren zusammengebunden und sich auf sie gesetzt.
<G-vec00185-001-s455><catch.fangen><en> This respectable catch proves that there were no limits for huchen set in 1940, and it was not such a common feat for one angler to catch so many fish, and so the press treated the catch as sensational news.
<G-vec00185-001-s455><catch.fangen><de> Dieser respektable Fang verweist darauf, da3 es 1940 keine Beschränkung bezüglich des Huchenangelns gab, es war auch nicht oft der Fall, da3 ein Fischer bei einer einzigen Angeltour derart viele Fische gefangen hätte, und so berichteten die Zeitungen von diesem Fang als Sensation.
<G-vec00185-001-s456><catch.fangen><en> 38cm long, the Slapstick is made from a soft material, making it easy to throw and catch.
<G-vec00185-001-s456><catch.fangen><de> Der 38cm große Slapstick ist aus weichem Material und kann somit problemlos geworfen und gefangen werden.
<G-vec00185-001-s457><catch.fangen><en> The fish catch includes sardines, tuna, mackerel, anchovies, and shellfish.
<G-vec00185-001-s457><catch.fangen><de> Gefangen werden vor allem Sardinen, Sardellen, Thunfische, Makrelen sowie Schalen- und Krebstiere.
<G-vec00185-001-s458><catch.fangen><en> Local fishermen catch fresh fish and seafood daily.
<G-vec00185-001-s458><catch.fangen><de> Fisch und Meeresfrüchte werden täglich frisch von den Fischern aus der Umgebung gefangen.
<G-vec00185-001-s459><catch.fangen><en> Once you catch some blocks on the pad, use the up arrow key to drop the up block and the down key to drop the bottom block.
<G-vec00185-001-s459><catch.fangen><de> Wenn du einmal einige Blöcke gefangen hast, kannst du mit der Pfeiltaste nach oben den obersten und mit der Pfeiltaste nach unten den untersten Block ablegen.
<G-vec00185-001-s460><catch.fangen><en> In addition to the boat, which has a hook that can be used to catch the fish, the turtle or the starfish, this set also includes a fisherman who can be placed on the boat at will.
<G-vec00185-001-s460><catch.fangen><de> Neben dem Boot, an dem ein Haken befestigt ist, mit dem der Fisch, die Schildkröte oder der Seestern gefangen werden können, beinhaltet dieses Set auch einen Fischer, der nach Belieben auf dem Boot platziert werden kann.
<G-vec00185-001-s461><catch.fangen><en> The village of Conil de la Frontera used to live in the past mainly from tuna fishing according to the old tradition of the Almadraba, where they catch the up to 3m long fish with huge nets and by hand.
<G-vec00185-001-s461><catch.fangen><de> Die Ortschaft Conil de la Frontera lebte in der Vergangenheit hauptsächlich vom Thunfischfang nach der alten Tradition der Almadraba, wo die bis zu 3m langen Fische wie schon vor hunderten von Jahren mit großen Netzen und mit der Hand gefangen werden.
<G-vec00185-001-s462><catch.fangen><en> Not only did he catch big numbers on this bait, but he got the fish of the trip that was just over 9 pounds.
<G-vec00185-001-s462><catch.fangen><de> Er hat nicht nur große Mengen an diesem Köder gefangen, sondern auch den Fisch der Reise, der knapp über 9 Pfund betrug.
<G-vec00185-001-s633><catch.nehmen><en> MONDAY Catch a Mariners baseball game
<G-vec00185-001-s633><catch.nehmen><de> Montag Nehmen Sie an einem Mariners Baseballspiel teil.
<G-vec00185-001-s634><catch.nehmen><en> Catch some waves off the coast of Byron Bay's famous beaches with an introductory surf lesson.
<G-vec00185-001-s634><catch.nehmen><de> Nehmen Sie ein paar Wellen mit vor der Küste der berühmten Strände von Byron Bay bei einem Surfkurs für Anfänger.
<G-vec00185-001-s635><catch.nehmen><en> The restored grove has a consolidated parking area, farther away from the trees (catch the shuttle from the south entrance), and some roads have been turned into hiking trails, including a boardwalk walkway.
<G-vec00185-001-s635><catch.nehmen><de> Die restaurierte Grove hat einen eigenen Parkbereich, der weiter weg von den Bäumen ist (nehmen Sie den Shuttle vom Südeingang) und manche Straßen wurden zu Wanderwegen umfunktioniert.
<G-vec00185-001-s636><catch.nehmen><en> To reach Disneyland Paris by public transport, catch the train to Marne-la-Vallée-Chessy (Disneyland), which is served by direct TGV (high-speed train) links from Paris-Charles de Gaulle Airport and London St Pancras.
<G-vec00185-001-s636><catch.nehmen><de> Um das Disneyland Paris mit öffentlichen Verkehrsmitteln zu erreichen, nehmen Sie den Zug in Richtung der Station Marne-la-Vallée-Chessy (Disneyland), die der TGV vom Flughafen Paris-Charles de Gaulle und vom Londoner Bahnhof St Pancras aus direkt anfährt.
<G-vec00185-001-s637><catch.nehmen><en> To get there, catch the Shingu Station-bound bus departing from Hongu Taisha-mae at 8:40 a.m. It also picks up passengers from Yunomine, Kawayu, and Wataze Onsen stops.
<G-vec00185-001-s637><catch.nehmen><de> Um dorthin zu gelangen, nehmen Sie den Bus in Richtung Shingu Bahnhof: Dieser fährt an der Haltestelle Hingu Taisha-mae um 8:40 Uhr ab und nimmt auch Fahrgäste in Yunomine, Kawayu und dem Watarase Onsen auf.
<G-vec00185-001-s638><catch.nehmen><en> Catch the bus M-124 to Carmona.
<G-vec00185-001-s638><catch.nehmen><de> Nehmen sie den Bus M-124 mit Richtung Carmona.
<G-vec00185-001-s639><catch.nehmen><en> Now lift the left leg straight up and catch the foot.
<G-vec00185-001-s639><catch.nehmen><de> Jetzt heben Sie das linke Bein gerade nach oben und nehmen Sie den Fuß.
<G-vec00185-001-s640><catch.nehmen><en> Visit the 13 art spaces within theÂ Salamanca Arts Centre, and then catch the ferry to the laudedÂ Mona (Museum of Old and New Art), which houses the controversial private collection of Tasmanian art collector David Walsh.
<G-vec00185-001-s640><catch.nehmen><de> Besuchen Sie die 13 Kunsträume im Salamanca Arts Centre und nehmen Sie eine Fähre zum hochgepriesenen Mona (Museum of Old and New Art), in dem die kontroverse Privatsammlung des tasmanischen Kunstsammlers David Walsh untergebracht ist.
<G-vec00185-001-s641><catch.nehmen><en> Catch bus number 52 for “Nice – Station JC Bermond” and alight at “Nice Magnan/Promenade” .
<G-vec00185-001-s641><catch.nehmen><de> Nehmen Sie die Buslinie 52 in Richtung „Nice – Station JC Bermond“ und steigen Sie an der Haltestelle „Nice Magnan/Promenade“ aus.
<G-vec00185-001-s642><catch.nehmen><en> Finally, if you need to go north/south in Brooklyn or to reach Queens, you can catch the G train at Lafayette Avenue and Fulton Street, which runs to trendy Williamsburg and Greenpoint, as well as Park Slope.
<G-vec00185-001-s642><catch.nehmen><de> Wenn Sie Richtung Norden oder Süden in Brooklyn oder nach Queens möchten, nehmen Sie die Linie G an der Ecke Lafayette Avenue und Fulton Street, diese bringt Sie ins trendige Williamsburg, nach Greenpoint sowie nach Park Slope.
<G-vec00185-001-s643><catch.nehmen><en> Address: 2 Sanamchai Road, Phra Nakhon, Bangkok, Thailand 10200, Thailand Directions: Catch one of the river taxis to Pier Tha Thien (N8) and the wander through the market.
<G-vec00185-001-s643><catch.nehmen><de> Adresse: 2 Sanamchai Road, Phra Nakhon, Bangkok, Thailand 10200, Thailand Wegbeschreibung: Nehmen Sie eine der Flusstaxis zum Pier Tha Thien (N8) und der Spaziergang durch den Markt.
<G-vec00185-001-s644><catch.nehmen><en> Leave your car at the free car park and catch the bus to Venice.
<G-vec00185-001-s644><catch.nehmen><de> Lassen Sie Ihr Auto auf dem kostenfreien Parkplatz stehen und nehmen Sie den Bus nach Venedig.
<G-vec00185-001-s645><catch.nehmen><en> From Bologna catch the train to Rovigo and in Rovigo catch the regional train to Chioggia (total duration: about 2 hours and a half, ticket price: about 25,00 €), and get off at the last stop.
<G-vec00185-001-s645><catch.nehmen><de> In Bologna nehmen Sie den Zug nach Rovigo und dann den Regionalzug nach Chioggia (gesamte Streckezeit ungefähr 2 Stunde und 30 Minuten, ungefährer Preis: Euro 25,00) und steigen Sie an der letzten Haltstelle aus.
<G-vec00185-001-s646><catch.nehmen><en> By Train Catch the Heathrow Express from Paddington Railway Station to the airport.
<G-vec00185-001-s646><catch.nehmen><de> Mit der Bahn Nehmen Sie den Heathrow Express vom Bahnhof Paddington zum Flughafen.
<G-vec00185-001-s647><catch.nehmen><en> From there, catch a train to Martres-Tolosane (1.5 km from the camp site) or Boussens (4 km from the camp site).
<G-vec00185-001-s647><catch.nehmen><de> Von da, nehmen Sie mühelos einen Zug nach Martres-Tolosane (1,5 km vom Camping) oder nach Boussens, dies liegt 4 km vom Camping entfernt.
<G-vec00185-001-s648><catch.nehmen><en> Catch the metro to Karlovo Namesti station.
<G-vec00185-001-s648><catch.nehmen><de> "Nehmen Sie die Metro zur Station ""Karlovo Namesti""."
<G-vec00185-001-s649><catch.nehmen><en> Catch a shuttle from central Paris and spend time discovering the gardens, art, and architecture of this chateau before choosing a time to return to the city.
<G-vec00185-001-s649><catch.nehmen><de> Nehmen Sie einen Shuttle vom Zentrum von Paris und verbringen Sie Zeit, die Gärten, die Kunst und die Architektur dieses Schlosses zu entdecken, bevor Sie sich für eine Rückkehr in die Stadt entscheiden.
<G-vec00185-001-s650><catch.nehmen><en> From here catch the green line metro to Barcelona Sants (Estacio de Sants).
<G-vec00185-001-s650><catch.nehmen><de> Von dort nehmen Sie die grüne U-Bahn-Linie bisBarcelona Sants (Sants Estació).
<G-vec00185-001-s651><catch.nehmen><en> Catch the train from Manchester Piccadilly to Edale, a village on the southern fringes of the Peak District National Park .
<G-vec00185-001-s651><catch.nehmen><de> Nehmen Sie den Zug von Manchester Piccadilly nach Edale, einer Ortschaft am südlichen Rand des Peak District Nationalparks .
<G-vec00126-002-s038><catch.auffangen><en> I will catch ya, I will catch your fall
<G-vec00126-002-s038><catch.auffangen><de> Ich werde dich aus deinem Sturz heraus auffangen.
<G-vec00126-002-s039><catch.auffangen><en> Hey lawyer gotta catch me when I fall
<G-vec00126-002-s039><catch.auffangen><de> Hey, Anwalt, du musst mich auffangen, wenn ich falle.
<G-vec00126-002-s040><catch.auffangen><en> Because your brain is shifting back and forth between simple and big concept, it may not catch a typo.
<G-vec00126-002-s040><catch.auffangen><de> Da Ihr Gehirn zwischen einfachen und großen Konzepten hin und her wechselt, kann es einen Tippfehler nicht auffangen.
<G-vec00126-002-s041><catch.auffangen><en> Now consider, in what spiritual darkness mankind goes along; consider that only very few create a sphere full of light around themselves, that therefore as it were only sparks of light flash on earth, which certainly every man could catch and which would be enough to again light a light in the heart of a man who wants to flee from darkness.
<G-vec00126-002-s041><catch.auffangen><de> Bedenket nun, in welchem Geistesdunkel die Menschheit dahingeht, bedenket, daß nur einige wenige eine lichtvolle Sphäre um sich schaffen, daß also gleichsam nur Lichtfunken auf der Erde aufblitzen, die zwar jeder Mensch auffangen könnte und die genügen würden, wieder ein Licht anzuzünden im Herzen eines Menschen, der dem Dunkel entfliehen möchte.
<G-vec00126-002-s042><catch.auffangen><en> These openings are placed at the top of the shaft; therefore they can catch more privileged wind.
<G-vec00126-002-s042><catch.auffangen><de> Diese Öffnungen befinden sich im oberen Teil des Schachtes, wodurch sie stärkeren Wind auffangen können.
<G-vec00126-002-s043><catch.auffangen><en> In combination with an f/1.75 aperture, the main sensor can catch many details even in very unfavourable lighting conditions.
<G-vec00126-002-s043><catch.auffangen><de> In Kombination mit einer f/1.75 Blende kann der Hauptsensor selbst bei sehr ungünstigen Lichtverhältnissen noch viele Details auffangen.
<G-vec00126-002-s045><catch.auffangen><en> Watch the coin in the air and either catch it or pay attention to where it rolls after it hits the floor.
<G-vec00126-002-s045><catch.auffangen><de> Du kannst die Münze auffangen oder musst beobachten, wo sie hinfällt, wenn sie auf dem Fußboden landet.
<G-vec00126-002-s046><catch.auffangen><en> The interview, whether promotional or informative, is based on communication techniques that will catch the audience and do everything to keep this audience.
<G-vec00126-002-s046><catch.auffangen><de> Das Interview, ob werblich oder informativ, basiert auf Kommunikationstechniken, die das Publikum auffangen und alles tun, um dieses Publikum zu halten.
<G-vec00126-002-s047><catch.auffangen><en> The well in Lamartine square, called the Passy well, was dug in 1855, and a standpipe was to be built over it to catch the gushing water.
<G-vec00126-002-s047><catch.auffangen><de> Der Brunnen des Square Lamartine, auch Passybrunnen genannt, wurde ab 1855 gegraben und man fasste den Bau eines Steigrohres ins Auge, welches das heraufsprudelnde Wasser auffangen sollte.
<G-vec00126-002-s048><catch.auffangen><en> Here you need to catch as many flowers (20) as possible.
<G-vec00126-002-s048><catch.auffangen><de> Hier müssen Sie möglichst viele Blumen (20) auffangen.
<G-vec00126-002-s049><catch.auffangen><en> No longer can we rely on safety nets to catch us.
<G-vec00126-002-s049><catch.auffangen><de> Wir können uns nicht länger auf Sicherheitsnetze verlassen, die uns auffangen.
<G-vec00126-002-s050><catch.auffangen><en> The filters can catch the impurities minimal 5 microns.
<G-vec00126-002-s050><catch.auffangen><de> Die eingesetzten Filter können Verunreinigung von bis zu 5 Mikron auffangen.
<G-vec00126-002-s051><catch.auffangen><en> The bottom of the grinder is tapered, so you can easily catch your grinded powder in the round plastic box which comes extra with this product.
<G-vec00126-002-s051><catch.auffangen><de> Die Unterseite des Grinders ist konisch, so dass Sie Ihr gemahlenes Pulver leicht auffangen können, in der runden Kunststoffbox die mit diesem Produkt mitgeliefert wird.
<G-vec00126-002-s052><catch.auffangen><en> Catch the juice in a bowl and squeeze out the orange skins, then add them to the segments.
<G-vec00126-002-s052><catch.auffangen><de> Den Saft in einer Schüssel auffangen und aus den Orangenhäuten drücken und ebenfalls zu den Fruchtfilets geben.
<G-vec00126-002-s054><catch.auffangen><en> In the bottom part is plate for catch escaping fat. It is also possible to insert the sieve inside the smoke house (for surcharge) and use this device as a fruit dryer.
<G-vec00126-002-s054><catch.auffangen><de> Im unteren Bereich befindet sich eine Schüssel zum Auffangen der abtropfenden Fette, in die Räucherkammer kann man auch Siebe (gegen Aufpreis) einlegen und als Obsttrockner benutzen.
<G-vec00126-002-s074><catch.auffangen><en> It’s not a good idea to use dumbbells when you do box jumps; you might need your hands to catch yourself if you trip.
<G-vec00126-002-s074><catch.auffangen><de> Es ist keine gute Idee, bei Kastensprüngen Kurzhanteln zu verwenden; du könntest deine Hände benötigen, um dich im Falle eines Sturzes aufzufangen.
<G-vec00126-002-s075><catch.auffangen><en> The bigger object has to leave it´s balance in order to catch the movement energy of the smaller object.
<G-vec00126-002-s075><catch.auffangen><de> Dass größere Objekt muss seine Balance verlassen um die Bewegungsenergie des kleineren aufzufangen.
<G-vec00126-002-s076><catch.auffangen><en> You control a large hand and it is your objective to catch all the things that are falling through the screen.
<G-vec00126-002-s076><catch.auffangen><de> Du kontrollierst eine riesige Hand und Deine Aufgabe ist es, all die Dinge aufzufangen, die durchs Bild fallen.
<G-vec00126-002-s078><catch.auffangen><en> But the best place for the mop bucket is not a hook, it should be on the floor or a shelf under the mop to catch drops.
<G-vec00126-002-s078><catch.auffangen><de> Der beste Platz für den Wischeimer ist jedoch kein Haken, er sollte auf dem Boden oder auf einem Regal unter dem Mop stehen, um Tropfen aufzufangen.
<G-vec00126-002-s079><catch.auffangen><en> When Peter attempts to fly on his own, Nathan sees him fall and flies up to catch him.
<G-vec00126-002-s079><catch.auffangen><de> Als Peter versucht, selbst zu fliegen, sieht Nathan ihn fallen und fliegt nach oben, um ihn aufzufangen.
<G-vec00126-002-s080><catch.auffangen><en> However, the delay before you can move again is too long to catch certain heavier targets.
<G-vec00126-002-s080><catch.auffangen><de> Allerdings ist die Verzögerung, bevor Elsword sich erneut bewegen kann zu lang, um bestimmte schwere Gegner wieder aufzufangen.
<G-vec00126-002-s081><catch.auffangen><en> To clean the dispensing guns: before starting work, the operator should have to hand a suitable waste container and a rag to catch dissolved foam residue and cleaning fluid.
<G-vec00126-002-s081><catch.auffangen><de> Zur Reinigung der Dosierpistolen: Vor dem Beginn der Arbeiten sollte der Anwender einen geeigneten Abfallbehälter und einen Lappen bereithalten, um angelöste Schaumreste und Reinigerflüssigkeit aufzufangen.
<G-vec00126-002-s082><catch.auffangen><en> Get rid of the tea leaves in the pot (if you have a strainer or infuser) or pour the liquid into another vessel with a strainer to catch any tea leaves.
<G-vec00126-002-s082><catch.auffangen><de> Entferne die Teeblätter aus der Kanne (wenn du ein Sieb oder ein Tee-Ei hast) oder gieße die Flüssigkeit über ein Sieb in ein anderes Gefäß, um die Teeblätter aufzufangen.
<G-vec00126-002-s083><catch.auffangen><en> Place a larger tray underneath it to catch any oil that overflows from the tin while cooking.
<G-vec00126-002-s083><catch.auffangen><de> Schieben Sie ein größeres Blech darunter, um das Öl aufzufangen, das beim Backen aus der Form laufen wird.
<G-vec00126-002-s084><catch.auffangen><en> If possible, set up supporting bars underneath the rack to catch the weight in case you are unable to bring the weight back up to the rack.
<G-vec00126-002-s084><catch.auffangen><de> Wenn möglich, bringe Stützstangen am Gestell an, um das Gewicht aufzufangen, falls du es nicht wieder im Gestell ablegen kannst.
<G-vec00126-002-s085><catch.auffangen><en> Turn up the sides of the foil to catch the meat juice.
<G-vec00126-002-s085><catch.auffangen><de> Die Seiten der Folie zu einem Rand hochschlagen, um den Fleischsaft aufzufangen.
<G-vec00126-002-s086><catch.auffangen><en> Because of the sensitive surface of the printing area he is enabled to catch and illustrate the slightest movements: the wing beats of moths passing by lamps or the tracks ants leave behind.
<G-vec00126-002-s086><catch.auffangen><de> Wegen der sensiblen Oberfläche des Druckgrundes ist es ihm möglich, kleinste Bewegungen aufzufangen und darzustellen: die Flügelschläge von an Lampen vorbeifliegenden Nachtfaltern oder die Spuren von Ameisen.
<G-vec00126-002-s087><catch.auffangen><en> Of course, an umbrella stand is also used to catch dripping water.
<G-vec00126-002-s087><catch.auffangen><de> Natürlich ist ein Schirmständer auch dazu da, herabtropfendes Wasser aufzufangen.
<G-vec00126-002-s089><catch.auffangen><en> Verily, from God’s Kingdom of heaven a heavenly safety net came, in order to catch many souls and the children, and to gather them before God’s throne.
<G-vec00126-002-s089><catch.auffangen><de> Wahrlich, von Gottes Königreich der Himmel aus kam ein himmlisches Fangnetz, um viele Seelen und die Kinder aufzufangen, und um sie beieinander vor Gottes Thron zu bringen.
<G-vec00126-002-s090><catch.auffangen><en> First I really liked this little plush doggy and threw it into the air to catch it again, but it fell off my hands and didn't come back.
<G-vec00126-002-s090><catch.auffangen><de> Zuerst mochte ich diesen süßen Plüschhund noch und habe ihn hochgeworfen um ihn wieder aufzufangen, doch er ist daneben gefallen und nicht zurück gekommen.
<G-vec00126-002-s091><catch.auffangen><en> Popularity: 8.7 Run up and down and jump to catch all snowflakes.
<G-vec00126-002-s091><catch.auffangen><de> Popularität: 8,0 Versuche alle fallende Schneeflocken aufzufangen.
<G-vec00126-002-s092><catch.auffangen><en> Try to catch as many sweets as you can before time runs out.
<G-vec00126-002-s092><catch.auffangen><de> Versuch in der Süßwarenfabrik so viel Süßigkeiten aufzufangen wie du nur kannst.
<G-vec00126-002-s221><catch.einfangen><en> I think this sense of loss drives us on to try to catch up with it – in love, in our lives, in our work.
<G-vec00126-002-s221><catch.einfangen><de> Ich denke, dieses Gefühl des Verlustes treibt uns an, damit wir es einfangen - in der Liebe, in unserem Leben, in unserer Arbeit.
<G-vec00126-002-s222><catch.einfangen><en> We wanted to catch our sound as genuine as possible and to maintain our own atmosphere.
<G-vec00126-002-s222><catch.einfangen><de> Wir wollten unseren Sound so direkt wie möglich einfangen, unsere eigene Atmosphäre entstehen lassen.
<G-vec00126-002-s223><catch.einfangen><en> Made from durable polyester materials that feature reflective accents designed to catch the light.
<G-vec00126-002-s223><catch.einfangen><de> Aus strapazierfähigem Polyester mit reflektierenden Akzenten, die das Licht einfangen.
<G-vec00126-002-s224><catch.einfangen><en> Again and again the bird trainer lured her with a piece of meat on the seat, so that I could catch the approach.
<G-vec00126-002-s224><catch.einfangen><de> Immer wieder lockte der Vogeltrainer sie mit einem Stück Fleisch auf den Ansitz, sodass ich auch den Anflug einfangen konnte.
<G-vec00126-002-s225><catch.einfangen><en> In his role as an executive with International Gaming Specialists, Steve Forte teaches the casinos how to identify and catch blackjack card counters.
<G-vec00126-002-s225><catch.einfangen><de> In seiner Rolle als Führungskraft bei International Gaming Specialists bringt Steve Forte Casinos bei, wie sie Blackjack Kartenzähler erkennen und einfangen können.
<G-vec00126-002-s226><catch.einfangen><en> Capture your world in brilliant detail with a powerful camera and larger 1.55 µm pixels that catch more light, day or night.
<G-vec00126-002-s226><catch.einfangen><de> Anhand seiner leistungsstarken Kamera und 1,55 µm großen Pixeln, die bei Tag und Nacht mehr Licht einfangen, machen Sie brillante Fotos, auf denen jedes Detail zur Geltung kommt.
<G-vec00126-002-s228><catch.einfangen><en> I personally think, with all the money spent, the Adwords should be in a better situation as the normal SEO, otherwise I will not spent a cent to this anymore, cause users will catch at a picture, not at a text, no matter how cool the text is.
<G-vec00126-002-s228><catch.einfangen><de> Ich persönlich denke, mit all dem ausgegebenen Geld, sollten die Adwords in einer besseren Situation als die normale SEO sein, sonst werde ich keinen Cent mehr dafür ausgeben, denn die Nutzer werden ein Bild einfangen, nicht einen Text, egal wie cool der Text ist.
<G-vec00126-002-s229><catch.einfangen><en> You CANNOT catch Jones with the cat box, for this your first need the net.
<G-vec00126-002-s229><catch.einfangen><de> Man kann Jones NICHT mit der Cat Box einfangen, dafür braucht man zunächst das Netz.
<G-vec00126-002-s230><catch.einfangen><en> Plastic trap to catch and control the infestation of Aethina Tumida in the beehive.
<G-vec00126-002-s230><catch.einfangen><de> Kunststoff-Falle zum Einfangen des Kleinen Beutekäfers (Aethina Tumida) und Überwachen des Befalls im Bienenstock.
<G-vec00126-002-s231><catch.einfangen><en> The scientists then had to catch the birds again to access the data.
<G-vec00126-002-s231><catch.einfangen><de> Als nächstes mussten die Wissenschaftler sie erneut einfangen, um an die Daten zu gelangen.
<G-vec00126-002-s232><catch.einfangen><en> Featuring wider, longer and deeper tweezers the Braun Silk-épil 9 removes with precision even the shortest hairs that wax cannot catch (down to 0.5mm).
<G-vec00126-002-s232><catch.einfangen><de> Mit einer breiteren, längeren und tieferen Pinzette entfernt die Braun Silk-epil 9 präzise auch die kürzesten Haare, die Wachs nicht einfangen kann (bis zu 0,5 mm).
<G-vec00126-002-s233><catch.einfangen><en> I wanted to catch their strength, wilderness, free spirit and energy…
<G-vec00126-002-s233><catch.einfangen><de> Ich wollte Ihre Wildheit, Freiheit, Stärke und Kraft einfangen.
<G-vec00126-002-s234><catch.einfangen><en> I like songs - songs like yours - that tell a story, catch me, affect me and invite me to reflect...
<G-vec00126-002-s234><catch.einfangen><de> Ich mag Songs wie Deine sehr, die eine Story erzählen, mich einfangen, mich berühren und zum Nachdenken anregen...
<G-vec00126-002-s235><catch.einfangen><en> However, there are also traps that catch the little intruders in a tank, where they can be collected and released into the wild again afterwards.
<G-vec00126-002-s235><catch.einfangen><de> Eine weitere Methode ist das Einfangen der kleinen Störenfriede in einem Behälter, wo sie gesammelt und anschließend wieder in die Freiheit entlassen werden können.
<G-vec00126-002-s236><catch.einfangen><en> fraction of a second in which we can catch a Moment.
<G-vec00126-002-s236><catch.einfangen><de> Der Bruchteil einer Sekunde in der wir einen Moment einfangen können.
<G-vec00126-002-s237><catch.einfangen><en> You won’t catch it.
<G-vec00126-002-s237><catch.einfangen><de> Sie werden es nicht einfangen.
<G-vec00126-002-s238><catch.einfangen><en> Crafted from smooth nappa in two tonal shades, it is embellished with a stylized flower application and small, shiny metal studs that catch the light.
<G-vec00126-002-s238><catch.einfangen><de> Gearbeitet ist es aus weichem Nappa in zwei Farbnuancen, verziert mit einer stilvollen Blumen-Applikation und zierlichen, glänzenden Metallnieten, die das Licht einfangen.
<G-vec00126-002-s239><catch.einfangen><en> These discarded nets can remain in the sea for centuries continuing to catch or injure marine life such as fish, dolphins, turtles and marine birds (known as ghost fishing).
<G-vec00126-002-s239><catch.einfangen><de> Diese als Abfall zurückgelassenen Netze können jahrhundertelang im Meer verbleiben und dabei maritime Lebewesen wie Fische, Delfine, Schildkröten und Meeresvögel einfangen oder verletzen (auch als "Ghost Fishing" bekannt).
<G-vec00126-002-s259><catch.einfangen><en> Ania cannot stop thinking about the wolf, so she tries to catch the creature.
<G-vec00126-002-s259><catch.einfangen><de> Aber der Gedanke an den Wolf lässt Ania nicht los und sie versucht das Tier einzufangen.
<G-vec00126-002-s260><catch.einfangen><en> Try to catch the goodies and find out what they will do for you.
<G-vec00126-002-s260><catch.einfangen><de> Versuche die Goodies und Extras einzufangen, und finde heraus, was sie bewirken.
<G-vec00126-002-s261><catch.einfangen><en> Bill had been expecting to catch Frank, and Frank had been expecting Bill to come up from behind.
<G-vec00126-002-s261><catch.einfangen><de> Bill hatte erwartet, Frank einzufangen, und Frank hatte erwartet, dass Bill sich von hinten nähert.
<G-vec00126-002-s263><catch.einfangen><en> You had to leave the house to catch the last warm rays of the sun and to enjoy them.
<G-vec00126-002-s263><catch.einfangen><de> Da musste man aus dem Haus gehen um die letzten warmen Sonnenstrahlen einzufangen und zu genießen.
<G-vec00126-002-s264><catch.einfangen><en> It aims only to find and catch the abstract.
<G-vec00126-002-s264><catch.einfangen><de> Stattdessen zielt es darauf ab, das Abstrakte zu finden und einzufangen.
<G-vec00126-002-s265><catch.einfangen><en> His son has to learn to climb on steep slopes, to work with dogs, lead the herd, to identify the plants and to catch lame sheep.
<G-vec00126-002-s265><catch.einfangen><de> Alexandre lernt sich in steilen Hängen zu bewegen, mit den Hunden zu arbeiten, die Herde zu treiben, Pflanzen zu erkennen oder lahmende Schafe einzufangen.
<G-vec00126-002-s266><catch.einfangen><en> Comedians and filmmakers attempt to make the most outlandish, over-the-top videos to catch the attention of viewers.
<G-vec00126-002-s266><catch.einfangen><de> Comedians und Filmemacher versuchen, die absonderlichsten und übertriebensten Videos zu machen, um die Aufmerksamkeit der Zuschauer einzufangen.
<G-vec00126-002-s267><catch.einfangen><en> In order to catch the RNA molecules, the three junior researchers used a trick: They supplied cells with a molecule acting as a kind of anchor for a couple of minutes.
<G-vec00126-002-s267><catch.einfangen><de> Um die RNA-Moleküle einzufangen, verwendeten die Forscher einen Trick: Sie verabreichten den Zellen für einige Minuten ein Molekül, das als eine Art Anker wirkt.
<G-vec00126-002-s268><catch.einfangen><en> I put up my tripod and my camera and tried to catch the beauty of the moment.
<G-vec00126-002-s268><catch.einfangen><de> Ich baute mein Stativ und meine Kamera auf und versuchte die Schönheit des Moments einzufangen.
<G-vec00126-002-s269><catch.einfangen><en> And Lampre wants to take the opportunity because once more, the boys of Daniele Bennati achieve a monster work to catch the early break of the day: Guido Trenti, Gorka Gonzales and Hubert Krys who are in the lead since km 75.
<G-vec00126-002-s269><catch.einfangen><de> Und Lampre will sich diese Gelegenheit nicht entgehen lassen, denn einmal mehr machen die Jungs von Daniele Bennati eine Monsterarbeit an der Spitze des Feldes, um die frühere Ausreissergruppe wieder einzufangen, die mit Guido Trenti, Gorka Gonzales und Hubert Krys seit km 75 an der Spitze liegt.
<G-vec00126-002-s270><catch.einfangen><en> The demon stood high atop the obelisk and spread its wings to catch the warmth of the second sun.
<G-vec00126-002-s270><catch.einfangen><de> Der Dämon stand hoch aufgerichtet auf dem Obelisken und bereitete die Flügel aus, um die Wärme der zweiten Sonne einzufangen.
<G-vec00126-002-s271><catch.einfangen><en> Hundreds of residents gathered and major networks broadcast live as 17 firefighters, some on top of the slope and others underneath, tried to catch the dog.
<G-vec00126-002-s271><catch.einfangen><de> Hunderte von Anwohnern hatten sich versammelt, als 17 Feuerwehrleute ober- und unterhalb des Hügels versuchten, den Hund einzufangen.
<G-vec00126-002-s272><catch.einfangen><en> I looked at the pictures and tried to catch the mood.
<G-vec00126-002-s272><catch.einfangen><de> Ich sah mir die Bilder an und versuchte, die Stimmung einzufangen.
<G-vec00126-002-s273><catch.einfangen><en> Catch the Big Break! At first these were places known for their fishing tradition, but over time, in addition to fish, more and more sun and fun were “caught” here.
<G-vec00126-002-s273><catch.einfangen><de> Zu Beginn waren es kleine, durch ihre Fischertradition bekannte Orte, doch mit der Zeit begann man sich dort außer Fisch auch Sonne und Unterhaltung „einzufangen“.
<G-vec00126-002-s274><catch.einfangen><en> I’m just trying to catch every single one of them,” she said of the whole orchestra.
<G-vec00126-002-s274><catch.einfangen><de> Ich versuche, jeden Einzelnen von ihnen einzufangen“, sagte sie über ihre Empfindungen im Hinblick auf das ganze Orchester.
<G-vec00126-002-s276><catch.einfangen><en> The Italian, Luca Crevenna, drops out of the leading trio but his team-mates manage to catch up with the two remaining leaders at kilometre 36.
<G-vec00126-002-s276><catch.einfangen><de> Aber die Verfolger machen Druck und nachdem der Italiener Luca Crevenna aus dem Spitzentrio rausfällt, gelingt es seinen Teamkollegen auch die beiden Spitzenreiter bei Km 36 wieder einzufangen.
<G-vec00126-002-s277><catch.einfangen><en> Try to catch negative thoughts and find a new way to look at the situation.
<G-vec00126-002-s277><catch.einfangen><de> Versuche negative Gedanken einzufangen und finde einen Weg, die Situation neu zu betrachten.
<G-vec00126-002-s413><catch.fangen><en> At first they thought it was John Mark, who had come down to welcome them back with their catch, but as they drew nearer the shore, they saw they were mistaken -- the man was too tall for John.
<G-vec00126-002-s413><catch.fangen><de> Zuerst dachten sie, es sei Johannes Markus, der herabgekommen sei, um sie bei ihrer Rückkehr mit ihrem Fang willkommen zu heißen, aber als sie dem Ufer näher kamen, sahen sie, dass sie sich geirrt hatten – der Mann war zu groß für Johannes.
<G-vec00126-002-s414><catch.fangen><en> Catch a movie at nearby St. Clair 10 Cine and AMC Enterprise.
<G-vec00126-002-s414><catch.fangen><de> Fang einen Film in der Nähe von St. Clair 10 Cine und AMC Enterprise.
<G-vec00126-002-s415><catch.fangen><en> Catch Long, wide and strong to make caring the game easier for the dog.
<G-vec00126-002-s415><catch.fangen><de> Fang Lang, breit, tief und kräftig um dem Hund das richtige Tragen des Wildes zu erleichtern.
<G-vec00126-002-s416><catch.fangen><en> This is why you should not entrust your catch to the cheapest taxidermist but only to the specialist.
<G-vec00126-002-s416><catch.fangen><de> Deshalb sollten Sie Ihren Fang nicht einfach dem Billigsten, sondern nur dem Spezialisten anvertrauen.
<G-vec00126-002-s417><catch.fangen><en> Not because I’m not a great catch but because life has happened way too fast and I wanted to get it right.
<G-vec00126-002-s417><catch.fangen><de> Nicht, weil ich nicht ein großer Fang bin, sondern weil das Leben hat viel zu schnell passiert und ich wollte es richtig machen.
<G-vec00126-002-s418><catch.fangen><en> Location: Hotel family┬┤s sustainable catch is cut with a sword-like Japanese tuna knife in front of the audience with skill and concentration before processing into a delicious Tuna menu.
<G-vec00126-002-s418><catch.fangen><de> Ein frischer Blauflossen-Thunfisch aus nachhaltigem Fang der Familie Balfego wird mit einem schwertähnlichen japanischen Thunfischmesser vor dem Publikum mit Können und Konzentration zerlegt und zu einem köstlichen Tuna Menu verarbeitet.
<G-vec00126-002-s419><catch.fangen><en> De Mercuur boasts a spacious fishing deck and large fishing tables, on which you can immediately clean your catch.
<G-vec00126-002-s419><catch.fangen><de> Das Deck der Mercuur bietet ausreichend Platz zum Angeln und Reinigungsstationen, an denen Sie Ihren Fang sofort säubern können.
<G-vec00126-002-s420><catch.fangen><en> Karuc Karuc is a small fisherman village on the coast of Skadar lake.,,The eye,, of Karuc - a source famous for the great catch of fish, so in time instead of the temporary the permanent fisherman village was created on the spot.
<G-vec00126-002-s420><catch.fangen><de> Karuc Karuc ist ein kleines Fischerdorf an der Küste des Skutari Sees.,, Das Auge“, von Karuc - eine Quelle für den großen Fang von Fischen bekannt, darum entstand dort auch das Fischerdorf .
<G-vec00126-002-s421><catch.fangen><en> That’s our today’s catch, 48 years old Ivana from Prague.
<G-vec00126-002-s421><catch.fangen><de> Das ist unser heutiger Fang, die 48-jährige Ivana aus Prag.
<G-vec00126-002-s422><catch.fangen><en> Registration of catches at our catchment sites must take place no later than 24 hours after the catch.
<G-vec00126-002-s422><catch.fangen><de> Die Registrierung der Fänge an unseren Einzugsgebieten muss spätestens 24 Stunden nach dem Fang erfolgen.
<G-vec00126-002-s423><catch.fangen><en> Catch the escaped crooks in action-packed car chases, on foot in the park, or by boat in the swamp.
<G-vec00126-002-s423><catch.fangen><de> Fang die fliehenden Gauner in actiongeladenen Verfolgungsjagden, zu Fuß im Park oder mit dem Boot im Sumpf wieder ein.
<G-vec00126-002-s424><catch.fangen><en> In keeping with the atmosphere of the place, the menu at Brasserie du Grand Chêne takes gourmets to their favourite country: France, the country of traditionally excellent taste and timeless flavours. The most popular dishes include beef tartare and steak, onion soup, fish soup, escargots de Bourgogne and fish (catch of the day).
<G-vec00126-002-s424><catch.fangen><de> Passend zur Gesamtstimmung des Restaurants versetzt auch die Küche der Brasserie du Grand-Chêne Gourmets in ihr Lieblingsland, in dem schmackhafte traditionelle Gerichte und zeitlose Geschmacksklassiker auf der Speisekarte stehen: Tartar und Entrecôte vom Rind, Zwiebel- oder Fischsuppe, Weinbergschnecken aus der Bourgogne und Fischgerichte je nach Fang des Tages sind besonders beliebt.
<G-vec00126-002-s425><catch.fangen><en> Catch of the day is prepared in various delicious ways.
<G-vec00126-002-s425><catch.fangen><de> Der Fang des Tages wird in dutzenden leckeren Möglichkeiten vorbereitet.
<G-vec00126-002-s426><catch.fangen><en> Catch as many ball as you can.
<G-vec00126-002-s426><catch.fangen><de> Fang so viele Ball wie möglich.
<G-vec00126-002-s427><catch.fangen><en> They offer the possibility to enjoy the fight with the catch in the immediate vicinity of water surface.
<G-vec00126-002-s427><catch.fangen><de> Sie bieten die Möglichkeit, den Kampf mit dem Fang aus unmittelbarer Nähe des Wasserspiegels zu erleben.
<G-vec00126-002-s428><catch.fangen><en> But a great catch.
<G-vec00126-002-s428><catch.fangen><de> Aber ein großer Fang.
<G-vec00126-002-s429><catch.fangen><en> The American complimented the Mexican on the quality of his fish and asked how long it had taken to catch them.
<G-vec00126-002-s429><catch.fangen><de> Der Amerikaner gratulierte dem Mexikaner zu seinem prächtigen Fang und fragte wie lange er dazu gebraucht hatte.
<G-vec00126-002-s430><catch.fangen><en> Of course, the region has suffered setbacks in recent times – overfishing and a damaged environment mean it is harder to make ‘the’ catch.
<G-vec00126-002-s430><catch.fangen><de> Natürlich hat die Region in jüngster Zeit ein paar Rückschläge einstecken müssen – Überfischung und eine beschädigte Umwelt machen es schwerer ‚den‘ Fang zu machen.
<G-vec00126-002-s431><catch.fangen><en> Well-maintained bathing lakes will cool you down on hot days, while fishermen may hope for a good catch in lakes full of fish.
<G-vec00126-002-s431><catch.fangen><de> Gepflegte Badeseen sorgen an heißen Tagen für Abkühlung, während Angler in den fischreichen Seen auf einen guten Fang hoffen können.
<G-vec00126-002-s432><catch.fangen><en> I catch the peeping tom from the end of clip II and tie him to a fence.
<G-vec00126-002-s432><catch.fangen><de> Ich fange den Spanner vom Ende von Teil 2 und fessle ihn an einen Zaun.
<G-vec00126-002-s433><catch.fangen><en> --- Votes: 0 Nautical life - buy various yachts, furnish them to your liking, go to the sea voyage, catch fish in different seas.
<G-vec00126-002-s433><catch.fangen><de> --- Stimmen: 0 Kaufe in Nautical Life verschiedene Yachten, statte sie nach deinen Wünschen aus, egib dich auf eine Meeresreise und fange Fisch in verschiedenen Meeren.
<G-vec00126-002-s434><catch.fangen><en> 1 Catch Pichu in a Luxury Ball.
<G-vec00126-002-s434><catch.fangen><de> 1 Fange Pichu mit einem Luxusball.
<G-vec00126-002-s435><catch.fangen><en> Catch and fuck as many mermaids and divers, as you can.
<G-vec00126-002-s435><catch.fangen><de> Fange und ficke so viele Meerjungfrauen und Taucher wie möglich.
<G-vec00126-002-s436><catch.fangen><en> Catch the needed amount of fish to earn money before time runs out.
<G-vec00126-002-s436><catch.fangen><de> Fange innerhalb der vorgegebenen Zeit die benötigte Menge Fisch, um Geld zu verdienen.
<G-vec00126-002-s437><catch.fangen><en> We made a big game "catch me if you can" out of it.
<G-vec00126-002-s437><catch.fangen><de> Was daraus wurde, war ein Riesenspiel 'Fange mich, wenn du kannst'.
<G-vec00126-002-s438><catch.fangen><en> Room Challenge 2 Catch the stones to earn money and buy furniture to your room.
<G-vec00126-002-s438><catch.fangen><de> Zimmerspiel 2 Fange die Steine, um Geld zu verdienen und kaufe davon Möbel für dein Zimmer.
<G-vec00126-002-s439><catch.fangen><en> 35:8 Let destruction come upon him at unawares; and let his net that he hath hid catch himself: into that very destruction let him fall.
<G-vec00126-002-s439><catch.fangen><de> 35:8 Unvermutet ereile ihn das Verderben; / er fange sich selbst in seinem Netz, / er falle in die eigene Grube.
<G-vec00126-002-s441><catch.fangen><en> 5.3 Catch the cork which falls from black screw in the palm of your hands.
<G-vec00126-002-s441><catch.fangen><de> 5.3 Fange den Korken, der von der schwarzen Schraube in deiner Handfläche fällt.
<G-vec00126-002-s442><catch.fangen><en> Console Game Throw a hand like you throw Poke Balls and catch wild Pokémon, whether with the help of the Joy-Con driver or Poké Ball Plus, which shines, vibrates and makes sounds to bring your adventure to life.
<G-vec00126-002-s442><catch.fangen><de> 47,90 € mit der Hand, als ob du Pokéballs wirfst und fange wilde Pokémons, ob mit Hilfe des Joy-Con-Controllers oder dem Zubehör von Poké Ball Plus, das glänzt, vibriert und Geräusche macht, um dein Abenteuer zum Leben zu erwecken.
<G-vec00126-002-s443><catch.fangen><en> Catch the flies to feed yourself (and practice Clothes in German just for fun).
<G-vec00126-002-s443><catch.fangen><de> Fange die Fliegen, um dich selbst zu füttern (und aus Spaß Deutsch zu üben).
<G-vec00126-002-s445><catch.fangen><en> Sea Mistress - Catch the lucky goldfish while playing in the underwater world.
<G-vec00126-002-s445><catch.fangen><de> Sea Mistress — Fange den Glücksgoldfisch, während du unter Wasser spielst.
<G-vec00126-002-s446><catch.fangen><en> Try to catch as many fish as possible in these fishing games.
<G-vec00126-002-s446><catch.fangen><de> Fange mit der Angel so viele Fische wie möglich.
<G-vec00126-002-s447><catch.fangen><en> I catch you and give you the relaxation that you need.
<G-vec00126-002-s447><catch.fangen><de> Ich fange dich auf und gebe dir die Entspannung, die du benötigst.
<G-vec00126-002-s448><catch.fangen><en> so that the snow is warm when I catch it in my fingers.
<G-vec00126-002-s448><catch.fangen><de> Nur damit der Schnee den ich mit den Fingern fange warm wird.
<G-vec00126-002-s449><catch.fangen><en> Go with the flow and catch that elusive "decisive moment" with your Diana camera.
<G-vec00126-002-s449><catch.fangen><de> Go with the flow und fange diesen schwer fassbaren "entscheidenden Moment" mit deiner Diana ein.
<G-vec00126-002-s450><catch.fangen><en> I catch on the first morning in the pool Antonias (former Andrew) five pieces, all between 13 and 16.5 pounds, and lose a further three.
<G-vec00126-002-s450><catch.fangen><de> Ich fange am ersten Morgen am Pool Antonias (ehemalig Andrew) fünf Stück, alle zwischen 13 und 16,5 Pfund, weitere drei verliere ich.
<G-vec00126-002-s451><catch.fangen><en> You will have to try to catch an opponent and acquire some useful artifact along the way.
<G-vec00126-002-s451><catch.fangen><de> Sie müssen versuchen, einen Gegner zu fangen und ein nützliches Artefakt auf dem Weg zu erhalten.
<G-vec00126-002-s452><catch.fangen><en> If you wish to use more rods or catch more fish, more licenses can be bought.
<G-vec00126-002-s452><catch.fangen><de> Will man mehrere Ruten anwenden oder mehrere Fische fangen, so muss man mehrere Lizenzen lösen.
<G-vec00126-002-s453><catch.fangen><en> I managed to catch on these fishing rods and bream (2200g), and a duster (500g), and a small roach.
<G-vec00126-002-s453><catch.fangen><de> Ich habe es geschafft, diese Angelruten und Brühe (2200g) und ein Staubtuch (500g) und eine kleine Kakerlake zu fangen.
<G-vec00126-002-s454><catch.fangen><en> There is AC in the first floor but not in the bedrooms; however, we were able to sleep comfortably with the fans and the windows open to catch the breeze at night.
<G-vec00126-002-s454><catch.fangen><de> Es gibt AC in der ersten Etage, aber nicht in den Schlafzimmern; jedoch konnten wir bequem mit den Fans schlafen und die Fenster öffnen, um die Brise in der Nacht fangen.
<G-vec00126-002-s455><catch.fangen><en> There are no activities there but the bungalows are very nice and clean as is the beach with a lot of coral fish and the one or other possibility to catch fish around the rocks.
<G-vec00126-002-s455><catch.fangen><de> Die Bungalows von Las Brujas sind jedoch sehr schön gelegen, zweckmäßig und sauber, wie auch der Strand, der viele Korallenfische beheerbergt und Möglichkeiten bietet, auch den ein oder anderen Fisch vom Ufer aus zu fangen.
<G-vec00126-002-s456><catch.fangen><en> Catch it today with this exercise and spread this message.
<G-vec00126-002-s456><catch.fangen><de> Fangen sie heute noch mit dieser Übung an und verbreiten diese Mitteilung.
<G-vec00126-002-s457><catch.fangen><en> There is a pond in the middle of the park where you can catch tadpoles.
<G-vec00126-002-s457><catch.fangen><de> Es gibt einen Teich in der Mitte des Parks, wo man Kaulquappen fangen kann.
<G-vec00126-002-s458><catch.fangen><en> If you could catch some Dorado for me, I'd be very grateful.
<G-vec00126-002-s458><catch.fangen><de> Dorado zu fangen ist gewöhnlich kein Problem für mich, aber....
<G-vec00126-002-s459><catch.fangen><en> The Iridium Rod is a tool used to catch fish.
<G-vec00126-002-s459><catch.fangen><de> The Bambusstange ist ein Werkzeug, um Fische zu fangen.
<G-vec00126-002-s460><catch.fangen><en> If you are lucky and the blood of a domestic pet is clean, try simply to avoid toxoplasmosis, do not give meat to the pet without preliminary treatment, do not allow to catch and eat mice, limit outlets to the street and communicate with other cats.
<G-vec00126-002-s460><catch.fangen><de> Wenn Sie Glück haben und das Blut eines Haustiers sauber ist, versuchen Sie einfach Toxoplasmose zu vermeiden, geben Sie dem Tier kein Fleisch ohne Vorbehandlung, lassen Sie keine Mäuse fangen und essen, beschränken Sie Steckdosen auf die Straße und kommunizieren Sie mit anderen Katzen.
<G-vec00126-002-s461><catch.fangen><en> A must for shooter should be: ability to make, catch & shoot skills, spatial intelligence and ability to thrive in pressure.
<G-vec00126-002-s461><catch.fangen><de> Ein Muss für Shooter sollte sein: Fähigkeit, Fähigkeiten zu machen, zu fangen und zu schießen, räumliche Intelligenz und die Fähigkeit, unter Druck zu gedeihen.
<G-vec00126-002-s462><catch.fangen><en> The flower-visiting bats use their rod receptor for UV-perception and catch the UV-photons with the so-called beta-band of their photoreceptor, a peak of minor sensitivity for light absorption.
<G-vec00126-002-s462><catch.fangen><de> Die blütenbesuchenden Fledermäuse nutzen ihren Stäbchenrezeptor auch zur UV-Wahrnehmung und fangen die UV-Photonen mit dem so genannten beta-Band, einem Nebenbereich der Lichtabsorption ihres Photorezeptors, ein.
<G-vec00126-002-s463><catch.fangen><en> You can catch bigger fish by upgrading your line.
<G-vec00126-002-s463><catch.fangen><de> Du kannst größere Fische fangen, nachdem du deine Angel verbessert hast.
<G-vec00126-002-s464><catch.fangen><en> Catch Words, play free Puzzle games online.
<G-vec00126-002-s464><catch.fangen><de> Worte zu fangen, Spielfreie Puzzle Spiele online.
<G-vec00126-002-s465><catch.fangen><en> You feel the mood of a loved one, catch the nuances.
<G-vec00126-002-s465><catch.fangen><de> Sie fühlen die Stimmung eines geliebten Menschen, fangen die Nuancen ein.
<G-vec00126-002-s466><catch.fangen><en> Take a spin in your golf kart, or stop by the pond and try to catch a few fish.
<G-vec00126-002-s466><catch.fangen><de> Dreht zum Beispiel eine Runde in eurem Golfwagen oder geht zum Teich und versucht, ein paar Fische zu fangen.
<G-vec00126-002-s467><catch.fangen><en> Usage: Plastic strainer Kitchen Tools can effectively catch food particles without blocking water drainage.
<G-vec00126-002-s467><catch.fangen><de> Verwendung: Kunststoffsieb Kitchen Tools kann effektiv Speisereste fangen, ohne den Wasserablauf zu blockieren.
<G-vec00126-002-s468><catch.fangen><en> Even if we will not be able to catch any fish, spending some fun time on the ice, acquiring a new skill, and enjoying the winter scenery will be enough to make a memorable experience.
<G-vec00126-002-s468><catch.fangen><de> Selbst wenn es Ihnen nicht gelingt, einen einzigen Fisch zu fangen, ist die auf dem Eis verbrachte Zeit ausreichend angenehm, um sich eine neue Fertigkeit anzueignen und die winterliche Natur zu genießen.
<G-vec00126-002-s469><catch.fangen><en> Game Description: In this game genre, Simulation help the famous Scooby-Doo to catch as many snacks.
<G-vec00126-002-s469><catch.fangen><de> Spielbeschreibung: In diesem Spiele-Genre, Simulation helfen, die berühmte Scooby-Doo, möglichst viele Snacks zu fangen.
<G-vec00126-002-s470><catch.fangen><en> Bolmen with its 365 islands is the perfect place to catch bass, perch, pike and carp.
<G-vec00126-002-s470><catch.fangen><de> Im See Bolmen mit seinen 365 Inseln fangen Sie Barsch, Zander, Hecht und Karpfen.
<G-vec00126-002-s471><catch.fangen><en> Catch a few of their approximately 25,000 HD videos including all categories of porn.
<G-vec00126-002-s471><catch.fangen><de> Fangen Sie ein paar von ihren rund 25.000 HD-Videos, einschließlich aller Arten von Pornos.
<G-vec00126-002-s472><catch.fangen><en> CLEAN & MESS-FREE: Keep countertops spotless and tidy with the all-around deep juice groove to catch excess liquids from meats, poultry, fish, fruits and vegetables.
<G-vec00126-002-s472><catch.fangen><de> SAUBER & MESSFREI: Halten Sie die Arbeitsplatten mit der umlaufenden tiefen Saftrille makellos sauber und fangen Sie überschüssige Flüssigkeiten von Fleisch, Geflügel, Fisch, Obst und Gemüse auf.
<G-vec00126-002-s473><catch.fangen><en> Catch the suitcase crush, do not lose weight enough.
<G-vec00126-002-s473><catch.fangen><de> Fangen Sie den Koffer Crush, verlieren Sie nicht genug Gewicht.
<G-vec00126-002-s474><catch.fangen><en> Catch only the even numbers in the basket, which appears in this game as the main operating platform.
<G-vec00126-002-s474><catch.fangen><de> Fangen Sie nur die geraden Zahlen in den Korb, die in diesem Spiel erscheint als Haupt-Betriebssystem-Plattform.
<G-vec00126-002-s475><catch.fangen><en> Catch the mild autumn sun and gain new energy and strength to get fit for your everyday life.
<G-vec00126-002-s475><catch.fangen><de> Fangen Sie die milde Herbstsonne ein und gewinnen Sie neue Energie und Kraft, um wieder fit für Ihren Alltag zu werden.
<G-vec00126-002-s476><catch.fangen><en> Go out to sea with experienced fishermen and catch the best seafood in the world.
<G-vec00126-002-s476><catch.fangen><de> Begleiten Sie erfahrene Fischer hinaus aufs Meer und fangen Sie die weltweit besten Schalentiere.
<G-vec00126-002-s477><catch.fangen><en> Catch the precious opportunity to own this goodlooking display set with favorable price.
<G-vec00126-002-s477><catch.fangen><de> Fangen Sie die wertvolle Gelegenheit, dieses gutaussehend Display mit günstigen Preisen zu besitzen.
<G-vec00126-002-s478><catch.fangen><en> Catch this with the collectors which convert the sunlight into warmth.
<G-vec00126-002-s478><catch.fangen><de> Fangen Sie diese mit Kollektoren ein, die das Sonnenlicht in Wärme umwandeln.
<G-vec00126-002-s479><catch.fangen><en> Go with Maps, the official app you can rely on for real-time GPS navigation, traffic, transit e.t.c Get there faster with real-time updates Beat traffic with real-time navigation, ETAs and traffic conditions Catch your bus, train, or ride-share with real-time transit info Save time with automatic re-routing based on live...
<G-vec00126-002-s479><catch.fangen><de> Schneller und schneller mit Echtzeit-Updates Beat-Traffic mit Echtzeit-Navigation, ETAs und Verkehrsbedingungen Fangen Sie Ihren Bus, Zug oder Ride-Share mit Echtzeit-Transit info Sparen Sie Zeit mit automatischer Umleitung auf der Grundlage von Live-Verkehr, Straße Schließungen und Verkehrsunfälle Navigation mit Spurführung, so dass Sie nicht verpassen eine Wendung oder Ausfahrt Finden Sie Pit Stops entlang Ihrer Route wie Tankstellen und Kaffee...
<G-vec00126-002-s480><catch.fangen><en> Blow up numbered blocks, catch bonus specials and power ups.
<G-vec00126-002-s480><catch.fangen><de> Nummerierte Blöcke sprengen Sie, fangen Sie Bonus Spezialitäten und Power-UPS.
<G-vec00126-002-s481><catch.fangen><en> Use the water which is consumed while mingling the correct temperature or warming up the water during the shower: Catch it in a container and apply it for tidying your household or watering the plants.
<G-vec00126-002-s481><catch.fangen><de> – Nutzen Sie das Wasser, das beim Duschen verbraucht wird, während Sie die richtige Temperatur mischen oder das Wasser noch aufheizt: Fangen Sie es in einem Behälter auf und verwenden Sie es zum Putzen oder Bewässern der Pflanzen.
<G-vec00126-002-s482><catch.fangen><en> Be ready to catch the meat once it has been through the tenderiser process and vacates the machine.
<G-vec00126-002-s482><catch.fangen><de> Fangen Sie das Fleisch wieder auf, sobald es an der Unterseite des Geräts erscheint.
<G-vec00126-002-s483><catch.fangen><en> Change your underwater view and catch more fish with the Raymarine Dragonfly 4 and 5 wide-spectrum CHIRP DownVision technology.
<G-vec00126-002-s483><catch.fangen><de> Verändern Sie Ihre Unterwassersicht und fangen Sie mehr Fische mit dem Dragonfly 4 und 5 und der Weitwinkel CHIRP DownVision™ Technologie.
<G-vec00126-002-s485><catch.fangen><en> Catch the Sunbus (there is one bus that meets every flight).
<G-vec00126-002-s485><catch.fangen><de> Fangen Sie die Sunbus (es gibt einen Bus, der jeden Flug erfüllt).
<G-vec00126-002-s486><catch.fangen><en> Catch a new look with this gorgeous black gown featuring sparkling sequin material.
<G-vec00126-002-s486><catch.fangen><de> Fangen Sie einen neuen Look mit diesem wunderschönen Kleid mit glitzernden Pailletten Material.
<G-vec00126-002-s487><catch.fangen><en> Catch The Candy Xmas, Catch The Candy Xmas games, Candy games, Xmas games, Dear Boss
<G-vec00126-002-s487><catch.fangen><de> Fangen Sie die Candy Xmas, Catch The Candy Weihnachtsspiele, Candy-Spiele, Weihnachtsspiele, Spaß Spiele.
<G-vec00126-002-s488><catch.fangen><en> Catch your customer's attention and encourage to share within his social network.
<G-vec00126-002-s488><catch.fangen><de> Fangen Sie Ihre Kunden darauf aufmerksam und ermutigen in seinem sozialen Netzwerk zu teilen.
<G-vec00126-002-s489><catch.fangen><en> This same woman in charge of the disposal of the catch, also made all the necessary arrangements to ensure that the family's fishing unit obtained the funds required for the pre-financing of the fishing trips.
<G-vec00126-002-s489><catch.fangen><de> Dieselbe Frau, die für die Entsorgung der Fänge verantwortlich war, traf auch alle notwendigen Vorkehrungen, um der Fangeinheit der Familie die für die Vorfinanzierung der Ausfahrten erforderlichen Mittel zur Verfügung zu stellen.
<G-vec00126-002-s490><catch.fangen><en> The fish market is located in a separate area of the hall, where the freshest catch of the morning is brought to the customer.
<G-vec00126-002-s490><catch.fangen><de> In einem eigenen Bereich der Halle ist der Fischmarkt untergebracht, in welchem die frischesten Fänge des Morgens an den Kunden gebracht werden.
<G-vec00126-002-s491><catch.fangen><en> 1. Masters of third country fishing vessels or their representative shall submit to the authorities of the Member State whose designated ports of landing or transhipment facilities they use, if possible by electronic means prior to landing or transhipment operations, a declaration indicating the quantity of fishery products by species to be landed or transhipped, and the date and place of each catch.
<G-vec00126-002-s491><catch.fangen><de> (1) Der Kapitän eines Fischereifahrzeugs eines Drittlands oder sein Beauftragter legt vor Beginn der Anlandung oder Umladung den Behörden des Mitgliedstaats, dessen bezeichneten Anlande- oder Umladehafen er benutzt, sofern möglich auf elektronischem Wege eine Erklärung vor, in der die anzulandenden oder umzuladenden Mengen an Fischereierzeugnissen nach Arten sowie der Zeitpunkt und der Ort der einzelnen Fänge angegeben sind.
<G-vec00126-002-s492><catch.fangen><en> Fishermen bring in their impressive catch every day – huge lobsters and gigantic tuna among other things.
<G-vec00126-002-s492><catch.fangen><de> Fischer fahren täglich ihre fetten Fänge ein – darunter riesige Langusten und Monster-Tunfische.
<G-vec00126-002-s493><catch.fangen><en> The volume of illegally caught fish is estimated to be equal to 14 to 33 per cent of the world’s total legal catch.
<G-vec00126-002-s493><catch.fangen><de> Die Menge des illegal gefangenen Fischs beträgt nach Schätzungen zwischen 14 und 33 Prozent der weltweiten legalen Fänge.
<G-vec00126-002-s494><catch.fangen><en> The catch brought in by adults Tiina and Tiit and regurgitated for feeding the chicks is extraordinary.
<G-vec00126-002-s494><catch.fangen><de> Die Fänge, die von den Altstörchen Tiina und Tiit gebracht und ausgewürgt werden sind außergewöhnlich.
<G-vec00126-002-s495><catch.fangen><en> The fishermen were forced to hand over their entire catch to their conquerors and women to serve them.
<G-vec00126-002-s495><catch.fangen><de> Die Fischer sind gezwungen, den Besatzern ihre gesamten Fänge zu übergeben und ausschließlich für sie zu arbeiten.
<G-vec00126-002-s496><catch.fangen><en> assessment of the catch and bycatch of juvenile yellowfin tuna and other stocks of living marine resources associated with tuna fishing.
<G-vec00126-002-s496><catch.fangen><de> Einschätzung der Fänge und Beifänge von jungem Gelbflossenthun und anderen lebenden Meeresschätzen beim Thunfischfang.
<G-vec00126-002-s497><catch.fangen><en> This provision shall not exclude the use of specified devices used to reduce wear and tear, to strengthen or to limit the escape of catches in the forward part of towed gears, or the installation of catch control devices.
<G-vec00126-002-s497><catch.fangen><de> Diese Bestimmung schließt jedoch nicht den Einsatz bestimmter Vorrichtungen, durch die Verschleiß verringert und das Entweichen von Fischen im vorderen Teil von gezogenen Fanggeräten begünstigt oder begrenzt werden soll, oder die Installation von Vorrichtungen zur Kontrolle der Fänge aus.
<G-vec00126-002-s498><catch.fangen><en> You know the gesture that indicates the size of the catch... almost daily, we obtain such information as well as pictures from our customers of their sweet potato harvest.
<G-vec00126-002-s498><catch.fangen><de> Sie kennen die Handbewegung, die die Grösse der Fänge anzeigt … So erreichen uns fast täglich Informationen und Bilder zur Süsskartoffelernte unserer Kunden.
<G-vec00126-002-s499><catch.fangen><en> The catch reporting is very important for obtaining statistical data on the regrowth of salmon and trout and what different measures will have for consequences.
<G-vec00126-002-s499><catch.fangen><de> Die Berichterstattung über die Fänge ist sehr wichtig, um statistische Daten über das Nachwachsen von Lachsen und Forellen zu erhalten und welche unterschiedlichen Maßnahmen dies für die Folgen haben.
<G-vec00126-002-s500><catch.fangen><en> Thus, the body says, “Enough is enough; we have to do something here, or we will be facing bigger trouble.” You “catch” a cold, and get shut down or slowed down considerably; mucous is produced; wastes, damaged materials and toxins are expelled; the body goes through a general cleansing, and you recover.
<G-vec00126-002-s500><catch.fangen><de> Daher sagt der Körper: „Genug ist genug; wir haben hier etwas zu erledigen oder uns stehen größere Probleme bevor.“ Du „fängst“ dir eine Erkältung ein und wirst aus dem Verkehr gezogen oder musst dein Tempo beträchtlich herabsetzen; Schleim wird produziert; Abfälle, geschädigtes Material und Toxine werden ausgeschieden; der Körper geht durch einen generellen Reinigungsprozess und du erholst dich wieder.
<G-vec00126-002-s501><catch.fangen><en> Usually you catch rebel female gangsters around entire space.
<G-vec00126-002-s501><catch.fangen><de> Normalerweise fängst du rebellische weibliche Gangster im gesamten Kosmos.
<G-vec00126-002-s502><catch.fangen><en> The more cards you move in succession the larger the fish you catch!
<G-vec00126-002-s502><catch.fangen><de> Umso mehr Karten Du nacheinander bewegst, umso länger ist der Fisch, den Du fängst.
<G-vec00126-002-s503><catch.fangen><en> When you catch a cat, don’t let it out of the box trap.
<G-vec00126-002-s503><catch.fangen><de> Wenn du eine Katze fängst, lass sie nicht aus der Falle.
<G-vec00126-002-s504><catch.fangen><en> You flow and catch the sunlight.
<G-vec00126-002-s504><catch.fangen><de> Du fließt und fängst das Sonnenlicht ein.
<G-vec00126-002-s505><catch.fangen><en> Get on your feet and step outside to find and catch wild Pokémon.
<G-vec00126-002-s505><catch.fangen><de> In diesem Kapitel lernst du, wie du wilde Pokémon findest und fängst.
<G-vec00126-002-s506><catch.fangen><en> Every time you catch a fish you get at least one Angler Token as well as XP.
<G-vec00126-002-s506><catch.fangen><de> Jedes Mal, wenn du einen Fisch fängst, erhältst du mindestens eine Angler-Marke sowie EP (Erfahrung).
<G-vec00126-002-s507><catch.fangen><en> As Anna, you will jump over snowy pits, collect crystals, and catch snowflakes.
<G-vec00126-002-s507><catch.fangen><de> Als Anna spingst du über verschneite Schluchten, sammelst Kristalle und fängst Schneeflocken.
<G-vec00126-002-s508><catch.fangen><en> And you catch portions of it.
<G-vec00126-002-s508><catch.fangen><de> Und du fängst Portionen von ihm ein.
<G-vec00126-002-s509><catch.fangen><en> You catch a glimpse of Me, but you do not hold Me in your sight.
<G-vec00126-002-s509><catch.fangen><de> Du fängst einen flüchtigen Eindruck von Mir ein, aber du hältst Mich nicht in deiner Sicht.
<G-vec00126-002-s511><catch.fangen><en> Take a typical fishing boat on the sea and learn how to catch with fishing line and hook kingfish, tuna and barracuda.
<G-vec00126-002-s511><catch.fangen><de> Fahren Sie mit einem typischen Fischerboot aufs Meer hinaus und lernen Sie, wie man nur mit Angelschnur und Haken Kingfish, Thunfisch und Barracuda fängt.
<G-vec00126-002-s512><catch.fangen><en> Document Leaves form the jaws of a trap: the mechanism that the carnivorous waterwheel plant uses to catch its prey inspired Freiburg researchers to incorporate and develop it into a design for bionic shades for building facades.
<G-vec00126-002-s512><catch.fangen><de> Blätter mit Schnappfallen: Der Mechanismus, mit dem das fleischfressende Wasserrad seine Beute fängt, hat Freiburger Forschern einen Weg aufgezeigt, ihre bionische Fassadenverschattung weiterzuentwickeln.
<G-vec00126-002-s513><catch.fangen><en> It’s a whirlwind strawberry romance, but that thick graham cracker swirl will catch you when you swoon.
<G-vec00126-002-s513><catch.fangen><de> Es ist eine aufregende Erdbeer-Romanze, aber keine Angst, der dicke Graham-Cracker Swirl fängt dich auf, falls du ohnmächtig wirst.
<G-vec00126-002-s514><catch.fangen><en> Help Tom when he is in love or when he is angry and he desperately wants to catch Jerry.
<G-vec00126-002-s514><catch.fangen><de> Hilf Tom, wenn er verliebt ist oder wenn er wütend ist und er verzweifelt will, dass er Jerry fängt.
<G-vec00126-002-s515><catch.fangen><en> Boone argued with Shannon, telling her, she could not provide for herself. This prompted her to flirt with Charlie so he would catch a fish for her.
<G-vec00126-002-s515><catch.fangen><de> Boone sagt Shannon, dass sie nicht für sich selbst sorgen könne, woraufhin sie anfängt mit Charlie zu flirten, damit dieser für sie Fische fängt.
<G-vec00126-002-s516><catch.fangen><en> The computed information reveals quantitative defensive statistics, including the difficulty of a catch, the probability of a particular fielder making that catch, and a comparison of the True Defensive Range of all the fielders at once.
<G-vec00126-002-s516><catch.fangen><de> Aus den erfassten Daten errechnet das System statistische Informationen zur Verteidigungsarbeit der Feldspieler, etwa die Schwierigkeit eines Wurfes oder die Wahrscheinlichkeit, dass ein bestimmter Spieler diesen Wurf fängt.
<G-vec00126-002-s517><catch.fangen><en> score points when your opponent fails to catch the ring, when the ring comes to a halt on the ground, or when it lands outside the field after touching the ground
<G-vec00126-002-s517><catch.fangen><de> Punkte gibt’s, sobald dein Gegner den Ring nicht fängt, der Ring im Feld liegen bleibt oder der Ring außerhalb des Feldes liegen bleibt nachdem der Ring das Feld berührt hat.
<G-vec00126-002-s519><catch.fangen><en> He won't catch the trout with his rod
<G-vec00126-002-s519><catch.fangen><de> So fängt er die Forelle mit seiner Angel nicht.
<G-vec00126-002-s520><catch.fangen><en> Feigned interest in Charlie so that he'd catch a fish for her.
<G-vec00126-002-s520><catch.fangen><de> Spielt Interesse an Charlie vor, damit er ihr einen Fisch fängt.
<G-vec00126-002-s521><catch.fangen><en> But can let your mind wander during the day - and suddenly you catch an idea.
<G-vec00126-002-s521><catch.fangen><de> Aber während des Tages kann man seine Gedanken schweifen lassen - und plötzlich fängt man eine Idee.
<G-vec00126-002-s522><catch.fangen><en> She will be rescued by a man who will here catch the fish of his life.
<G-vec00126-002-s522><catch.fangen><de> Sie soll von dem Mann gerettet werden, der hier den Fisch seines Lebens fängt.
<G-vec00126-002-s524><catch.fangen><en> Punch the frog to make him jump and catch all the flies before the time runs out to complete each le...
<G-vec00126-002-s524><catch.fangen><de> 17 6 0 Stanzen Sie den Frosch, damit er springt und alle Fliegen fängt, bevor die Zeit abläuft, um jedes Level zu beenden.
<G-vec00126-002-s525><catch.fangen><en> You can give the children a ball: who will catch, he answers.
<G-vec00126-002-s525><catch.fangen><de> Sie können den Kindern einen Ball geben: wer fängt, antwortet er.
<G-vec00126-002-s526><catch.fangen><en> The Poison Dart frogs is so poisonous that the native people of South America catch the frogs, boil them, and dip their weapons in them for hunting.
<G-vec00126-002-s526><catch.fangen><de> Die Gift-Pfeilfrösche ist so giftig, dass der Ureinwohner von Südamerika die Frösche fängt, sie kocht und ihre Waffen in ihnen für die Jagd eintaucht.
<G-vec00126-002-s527><catch.fangen><en> He can tell exactly when the fog will dissipate, how to make fire in the snow, where to find fish, berries and mushrooms, and how to catch, kill and skin a reindeer with a single small knife.
<G-vec00126-002-s527><catch.fangen><de> Er kann genau sagen, wann sich der Nebel zerstreuen wird, wie man Feuer im Schnee macht, wo man Fisch, Beeren und Pilze findet, und wie man ein Rentier mit einem einzigen kleinen Messer fängt, tötet und häutet.
<G-vec00126-002-s528><catch.fangen><en> Alternatively, if you have a big enough tub, everyone can start at the same time and the first person to catch an apple in their teeth is the winner.
<G-vec00126-002-s528><catch.fangen><de> Wenn die Wanne groß genug ist, können auch alle zur gleichen Zeit anfangen und die erste Person, die einen Apfel mit den Zähnen fängt, ist der Gewinner.
<G-vec00126-002-s529><catch.fangen><en> If you don’t catch the exception it will propagate to the calling method, just like with synchronous code.
<G-vec00126-002-s529><catch.fangen><de> Wird eine Exception nicht gefangen, wird sie, wie bei synchronem Code, an die aufrufende Methode weitergereicht.
<G-vec00126-002-s530><catch.fangen><en> Japanese scientists have calculated that whales eat more than three times the amount of seafood than what the fisheries catch themselves.
<G-vec00126-002-s530><catch.fangen><de> Japanische Forscher haben errechnet, dass Wale rund dreimal soviel Fisch fressen wie durch die Fischerei gefangen wird.
<G-vec00126-002-s531><catch.fangen><en> Once again they are mostly used to catch cod.
<G-vec00126-002-s531><catch.fangen><de> Auch mit diesem Fanggerät werden überwiegend Dorsche gefangen.
<G-vec00126-002-s532><catch.fangen><en> Mijo Vojković, owner of a traditional craft for producing original fishing souvenirs of Croatian Posavina, presented on this occasion authentic replicas of fishing tools used to catch fish in
<G-vec00126-002-s532><catch.fangen><de> Herr Mijo Vojković aus kroatischer Posavina, der Inhaber eines Traditionsgewerbes für Herstellung von Fischfangwerkzeugen und autochtonen Souveniren, hat bei der Ausstellung mit authentischer Replika von Fischfangwerkzeugen, mit welchen in der Vergangenheit Fische in der kroatischen Posavina gefangen wurden, teilgenommen.
<G-vec00126-002-s533><catch.fangen><en> Amongst the usual tourist information two items on the same page catch my eye.
<G-vec00126-002-s533><catch.fangen><de> Inmitten der üblichen Touristeninformation wird meine Aufmerksamkeit von zwei Details gefangen genommen.
<G-vec00126-002-s534><catch.fangen><en> Today it didn’t take me long to catch a salmon: 3 casts.
<G-vec00126-002-s534><catch.fangen><de> Heute hat es nicht lange gedauert, bis ich einen Lachs gefangen habe: 3 Wuerfe.
<G-vec00126-002-s535><catch.fangen><en> Speed and strength, courage and coordination skills are necessary in order to catch the rabbits with one’s bare hands.
<G-vec00126-002-s535><catch.fangen><de> Schnelligkeit und Kraft, Mut und Koordinationsfähigkeit sind notwendig, denn die Kaninchen werden mit den Händen gefangen.
<G-vec00126-002-s536><catch.fangen><en> For he and all who were with him were amazed at the catch of fish that they had taken; and so also were James and John, sons of Zebedee, who were partners with Simon.
<G-vec00126-002-s536><catch.fangen><de> Denn er und alle seine Begleiter waren erstaunt und erschrocken, weil sie so viele Fische gefangen hatten; ebenso ging es Jakobus und Johannes, den Söhnen des Zebedäus, die mit Simon zusammenarbeiteten.
<G-vec00126-002-s537><catch.fangen><en> Here you can catch brook trout and char.
<G-vec00126-002-s537><catch.fangen><de> Gefangen werden unter anderem Bachforellen und Saiblinge.
<G-vec00126-002-s538><catch.fangen><en> You may catch two fish per rod, after which you must fish in the big lake.
<G-vec00126-002-s538><catch.fangen><de> Es dürfen 2 Fische pro Rute gefangen werden, danach muss im großen See weiter gefischt werden.
<G-vec00126-002-s539><catch.fangen><en> The location was deliberately chosen because the region is home to more than half of the world's Atlantic lobster catch.
<G-vec00126-002-s539><catch.fangen><de> Der Standort wurde bewusst gewählt, weil in der Region mehr als die Hälfte des weltweiten Aufkommens an Atlantikhummer gefangen wird.
<G-vec00126-002-s540><catch.fangen><en> When Jade, Beck, Andre and Cat finally catch him, he turns out to be a stranger from another school.
<G-vec00126-002-s540><catch.fangen><de> Nachdem André, Jade, Cat und Beck ihn endlich gefangen haben, stellt sich heraus, dass es ein Schüler von einer anderen Schule war.
<G-vec00126-002-s541><catch.fangen><en> For example, a flying fabric disc designed for adult dogs may be too large for a little puppy to catch.
<G-vec00126-002-s541><catch.fangen><de> Zum Beispiel könnte ein Stofffrisbee, die für ausgewachsene Hunde gedacht ist, zu groß sein, um von einem kleinen Welpen gefangen zu werden.
<G-vec00185-002-s657><catch.(sich)_nehmen><en> Whether you need to catch a train to nearby coast, or a quick ride across down to the Vatican City, our budget hotel’s proximity to Termini will be a great convenience during your Rome trip.
<G-vec00185-002-s657><catch.(sich)_nehmen><de> Ob Sie einen Zug zur nahegelegenen Küste nehmen möchten oder eine kurze Fahrt zur Vatikanstadt, die Nähe unseres Budget-Hotels zu Termini wird Ihnen während Ihrer Romreise sehr angenehm sein.
<G-vec00185-002-s658><catch.(sich)_nehmen><en> In general, if you wish to catch a train, it is normally first necessary to take a train into Barcelona city centre - Estació Sants (Barcelona Sants) - One of Barcelona's largest train stations.
<G-vec00185-002-s658><catch.(sich)_nehmen><de> Im Allgemeinen müssen Sie, wenn Sie einen Zug nehmen möchten, erst mit dem Zug ins Stadtzentrum von Barcelona fahren, zur einem der größten Bahnhöfe in Barcelona.
<G-vec00185-002-s659><catch.(sich)_nehmen><en> Between Picton and Christchurch you can catch the Coastal Pacific.
<G-vec00185-002-s659><catch.(sich)_nehmen><de> Zwischen Picton und Christchurch kann man den Coastal Pacific nehmen.
<G-vec00185-002-s660><catch.(sich)_nehmen><en> If you're not travelling by car, you can catch one of the buses that goes to to the western side of the Island and get off either at Marciana Alta or Marina di Campo, (it takes about two and a half hours to go right round without making any stops).
<G-vec00185-002-s660><catch.(sich)_nehmen><de> Falls ihr nicht mit dem eigenen Auto anreist, könnt ihr einen der Busse nehmen, die den Westring abfahren, und direkt in Marciana Alta oder in Marina di Campo für eine Pause aussteigen (ohne Pause benötigt man circa 2,30 - 2,40 Stunden für die Rundfahrt mit dem Bus).
<G-vec00185-002-s661><catch.(sich)_nehmen><en> Rise early to catch the first bus up to Machu Picchu with the guide.
<G-vec00185-002-s661><catch.(sich)_nehmen><de> Hüpfe früh aus den Federn, um gemeinsam mit dem Guide den ersten Bus nach Machu Picchu zu nehmen.
<G-vec00185-002-s662><catch.(sich)_nehmen><en> Whether you catch the train in Valencia or Barcelona is no matter, you will get to see the beautiful station in each.
<G-vec00185-002-s662><catch.(sich)_nehmen><de> Es ist nicht wichtig, ob Sie den Zug in Valencia oder Barcelona nehmen, Sie werden die Schönheit der Station an beiden Stellen schätzen können.
<G-vec00185-002-s663><catch.(sich)_nehmen><en> There are bus stations at both Cowes’ terminals where you can catch the bus to take you directly to the festival if you are on foot.
<G-vec00185-002-s663><catch.(sich)_nehmen><de> An beiden Terminals in Cowes gibt es Bushaltestellen, von denen du Busse direkt zum Festivalgelände nehmen kannst.
<G-vec00185-002-s665><catch.(sich)_nehmen><en> To return to Bilbao, you can catch the train at the nearby station of Sagrada Familia.
<G-vec00185-002-s665><catch.(sich)_nehmen><de> Für den Rückweg nach Bilbao können Sie an dem nahe gelegenen Bahnhof Sagrada Familia den Zug nehmen.
<G-vec00185-002-s666><catch.(sich)_nehmen><en> However, should you feel the need to explore other neighborhoods in the city; you can catch the A, C, E or L lines at the 14 Street / 8 Avenue subway station just 6 blocks from the apartment.
<G-vec00185-002-s666><catch.(sich)_nehmen><de> Falls Sie trotzdem die anderen Viertel der Stadt entdecken möchten; können Sie die Linien A, C, E oder L von der 14 Street U-Bahn-Station nehmen, die sich nur 6 Blocks von Ihrer Wohnung entfernt befindet.
<G-vec00185-002-s667><catch.(sich)_nehmen><en> Alternatively, you can catch the direct bus from outside the airport which takes about 30 minutes to get to Avenida Carlos V in the centre of the city.
<G-vec00185-002-s667><catch.(sich)_nehmen><de> Oder Sie nehmen den Bus außerhalb des Flughafens, der etwa 30 Minuten braucht, um zur Avenida Carlos V im Stadtzentrum zu gelangen.
<G-vec00185-002-s668><catch.(sich)_nehmen><en> In the port of Agaete you can catch Fred Olsen boat and visit the island of Tenerife in 2 hours away.
<G-vec00185-002-s668><catch.(sich)_nehmen><de> Im Hafen von Agaete können Sie Fred Olsen Boot nehmen und die Insel Teneriffa in 2 Stunden entfernt besuchen.
<G-vec00185-002-s669><catch.(sich)_nehmen><en> Tonight, we will catch a night train to Zagreb, from where we try to reach Split and perhaps take a daytrip to Dubrovnik!
<G-vec00185-002-s669><catch.(sich)_nehmen><de> Heute Nacht werden wir den Nachtzug nach Zagreb nehmen, von wo aus wir versuchen, Split zu erreichen und dann eventuell einen Tagesausflug nach Dubrovnik.
<G-vec00185-002-s670><catch.(sich)_nehmen><en> From Avezzano, you can catch a train to Sora.
<G-vec00185-002-s670><catch.(sich)_nehmen><de> Von Avezzano können Sie einen Zug nach Sora nehmen.
<G-vec00185-002-s671><catch.(sich)_nehmen><en> If you have to catch a connecting flight in Barcelona, the airport may provide you with a buggy on loan for the duration of your stopover.
<G-vec00185-002-s671><catch.(sich)_nehmen><de> Wenn Sie in Barcelona einen Anschlussflug nehmen, kann Ihnen der Flughafen selbst einen Kinderwagen leihen, solange Ihr Aufenthalt dauert.
<G-vec00185-002-s672><catch.(sich)_nehmen><en> Instead, you could catch the train out of Brno and change in Kojetín.
<G-vec00185-002-s672><catch.(sich)_nehmen><de> Sie können aber auch den Zug von Brünn nehmen und in Kojetín umsteigen.
<G-vec00185-002-s673><catch.(sich)_nehmen><en> If you wish to catch a taxi from the airport you should be aware that the queues can be long during peak times and so it is advisable to book a private transfer in advance.
<G-vec00185-002-s673><catch.(sich)_nehmen><de> Wenn Sie ein Taxi vom Flughafen Faro aus nehmen möchten, denken Sie bitte daran, dass es im Sommer längere Warteschlangen geben kann und es insofern ratsam ist, im Voraus einen privaten Transfer zu buchen.
<G-vec00185-002-s674><catch.(sich)_nehmen><en> On the final day, drive to the airport to catch the international flight.
<G-vec00185-002-s674><catch.(sich)_nehmen><de> Am letzten Tag fahren Sie zum Flughafen, um den internationalen Flug zu nehmen.
<G-vec00185-002-s675><catch.(sich)_nehmen><en> If you want to be sure to catch fish, try special guided fishing tours, organized by Vuokatti Fishing.
<G-vec00185-002-s675><catch.(sich)_nehmen><de> Wenn Sie auf Nummer sicher gehen möchten, nehmen Sie doch einfach an geführten Angeltouren teil, organisiert von Vuokatti Fishing.
<G-vec00185-002-s676><catch.(sich)_nehmen><en> Catch any of the Meiko buses heading for “Shirarahama” from JR Shirahama Station.
<G-vec00185-002-s676><catch.(sich)_nehmen><de> Nehmen Sie einen der Meiko-Busse, die vom JR-Bahnhof Shirahama nach Shirarahama fahren.
<G-vec00185-002-s677><catch.(sich)_nehmen><en> From airport Tegel catch bus X9 to Zoologischer Garten.
<G-vec00185-002-s677><catch.(sich)_nehmen><de> Vom Tegel Flughafen nehmen Sie das Bus X9 bis zum Zoologischer Garten.
<G-vec00185-002-s678><catch.(sich)_nehmen><en> Catch the cog train from the Cosme Velho station and journey through dense rainforest to the Art Deco statue of Christ the Redeemer on Corcovado mountain.
<G-vec00185-002-s678><catch.(sich)_nehmen><de> Nehmen Sie die Zahnradbahn vom Bahnhof Cosme Velho und fahren Sie durch dichten Regenwald zur Art-Deco-Statue von Christus, dem Erlöser, auf dem Berg Corcovado.
<G-vec00185-002-s679><catch.(sich)_nehmen><en> From here, catch bus 546 to the hotel (the bus stop is in front of the hotel).
<G-vec00185-002-s679><catch.(sich)_nehmen><de> Von dort aus nehmen Sie den Bus 546 zum Hotel (die Bushaltestelle liegt vor dem Hotel).
<G-vec00185-002-s680><catch.(sich)_nehmen><en> From Sorso's train station, catch the bus for Castelsardo o Santa Teresa di Gallura and get off at the Marritza stop.
<G-vec00185-002-s680><catch.(sich)_nehmen><de> Von Sorso nehmen Sie den Bus nach Castelsardo oder Santa Teresa di Gallura und steigen an der Haltestelle Marritza aus.
<G-vec00185-002-s681><catch.(sich)_nehmen><en> Catch a connecting flight to Manchester to discover this city’s thriving music scene.
<G-vec00185-002-s681><catch.(sich)_nehmen><de> Nehmen Sie einen Anschlussflug nach Manchester, um die blühende Musikszene dieser Stadt zu erkunden.
<G-vec00185-002-s682><catch.(sich)_nehmen><en> Catch all the layers of sound - both low and high-sounds are fuller and more natural.
<G-vec00185-002-s682><catch.(sich)_nehmen><de> Nehmen Sie alle Klangnuancen wahr, sowohl tiefe als auch hohe Töne sind so voller und natürlicher.
<G-vec00185-002-s683><catch.(sich)_nehmen><en> - Go underground and catch the red metro line to Astoria.
<G-vec00185-002-s683><catch.(sich)_nehmen><de> - U-Bahn gehen und nehmen Sie die rote U-Bahn bis Astoria.
<G-vec00185-002-s684><catch.(sich)_nehmen><en> Catch the bus directly from the city, or the train to Bondi Junction then a very short bus from there.
<G-vec00185-002-s684><catch.(sich)_nehmen><de> Nehmen Sie den Bus direkt im Stadtzentrum oder den Zug nach Bondi Junction und ab dort eine sehr kurze Busfahrt.
<G-vec00185-002-s685><catch.(sich)_nehmen><en> Catch the bus M-124 to Carmona.
<G-vec00185-002-s685><catch.(sich)_nehmen><de> Nehmen sie den Bus M-124 mit Richtung Carmona.
<G-vec00185-002-s686><catch.(sich)_nehmen><en> You need to catch the L200 to get there.
<G-vec00185-002-s686><catch.(sich)_nehmen><de> Um dorthin zu gelangen, nehmen Sie die L200.
<G-vec00185-002-s687><catch.(sich)_nehmen><en> Add another day to your trip and catch a ferry from Magheraroarty to Tory Island.
<G-vec00185-002-s687><catch.(sich)_nehmen><de> Verlängern Sie Ihre Reise um einen weiteren Tag und nehmen Sie die Fähre von Magheraroarty nach Tory Island.
<G-vec00185-002-s688><catch.(sich)_nehmen><en> The restored grove has a consolidated parking area, farther away from the trees (catch the shuttle from the south entrance), and some roads have been turned into hiking trails, including a boardwalk walkway.
<G-vec00185-002-s688><catch.(sich)_nehmen><de> Die restaurierte Grove hat einen eigenen Parkbereich, der weiter weg von den Bäumen ist (nehmen Sie den Shuttle vom Südeingang) und manche Straßen wurden zu Wanderwegen umfunktioniert.
<G-vec00185-002-s689><catch.(sich)_nehmen><en> Catch the metro to Karlovo Namesti station.
<G-vec00185-002-s689><catch.(sich)_nehmen><de> Nehmen Sie die Metro zur Station "Karlovo Namesti".
<G-vec00185-002-s690><catch.(sich)_nehmen><en> Catch bus number 2 in the direction of 'Sand'.
<G-vec00185-002-s690><catch.(sich)_nehmen><de> Nehmen Sie den Bus der Linie 2 in Richtung „Sand“.
<G-vec00185-002-s691><catch.(sich)_nehmen><en> Now lift the left leg straight up and catch the foot.
<G-vec00185-002-s691><catch.(sich)_nehmen><de> Jetzt heben Sie das linke Bein gerade nach oben und nehmen Sie den Fuß.
<G-vec00185-002-s692><catch.(sich)_nehmen><en> Or, catch the local bus (dolmus) into Kyrenia for a 30 minute ride to the lively centre of Kyrenia Town.
<G-vec00185-002-s692><catch.(sich)_nehmen><de> Oder nehmen Sie den örtlichen Bus (Dolmus) nach Kyrenia und fahren Sie 30 Minuten zum lebendigen Zentrum von Kyrenia.
<G-vec00185-002-s657><catch.nehmen><en> Whether you need to catch a train to nearby coast, or a quick ride across down to the Vatican City, our budget hotel’s proximity to Termini will be a great convenience during your Rome trip.
<G-vec00185-002-s657><catch.nehmen><de> Ob Sie einen Zug zur nahegelegenen Küste nehmen möchten oder eine kurze Fahrt zur Vatikanstadt, die Nähe unseres Budget-Hotels zu Termini wird Ihnen während Ihrer Romreise sehr angenehm sein.
<G-vec00185-002-s658><catch.nehmen><en> In general, if you wish to catch a train, it is normally first necessary to take a train into Barcelona city centre - Estació Sants (Barcelona Sants) - One of Barcelona's largest train stations.
<G-vec00185-002-s658><catch.nehmen><de> Im Allgemeinen müssen Sie, wenn Sie einen Zug nehmen möchten, erst mit dem Zug ins Stadtzentrum von Barcelona fahren, zur einem der größten Bahnhöfe in Barcelona.
<G-vec00185-002-s659><catch.nehmen><en> Between Picton and Christchurch you can catch the Coastal Pacific.
<G-vec00185-002-s659><catch.nehmen><de> Zwischen Picton und Christchurch kann man den Coastal Pacific nehmen.
<G-vec00185-002-s660><catch.nehmen><en> If you're not travelling by car, you can catch one of the buses that goes to to the western side of the Island and get off either at Marciana Alta or Marina di Campo, (it takes about two and a half hours to go right round without making any stops).
<G-vec00185-002-s660><catch.nehmen><de> Falls ihr nicht mit dem eigenen Auto anreist, könnt ihr einen der Busse nehmen, die den Westring abfahren, und direkt in Marciana Alta oder in Marina di Campo für eine Pause aussteigen (ohne Pause benötigt man circa 2,30 - 2,40 Stunden für die Rundfahrt mit dem Bus).
<G-vec00185-002-s661><catch.nehmen><en> Rise early to catch the first bus up to Machu Picchu with the guide.
<G-vec00185-002-s661><catch.nehmen><de> Hüpfe früh aus den Federn, um gemeinsam mit dem Guide den ersten Bus nach Machu Picchu zu nehmen.
<G-vec00185-002-s662><catch.nehmen><en> Whether you catch the train in Valencia or Barcelona is no matter, you will get to see the beautiful station in each.
<G-vec00185-002-s662><catch.nehmen><de> Es ist nicht wichtig, ob Sie den Zug in Valencia oder Barcelona nehmen, Sie werden die Schönheit der Station an beiden Stellen schätzen können.
<G-vec00185-002-s663><catch.nehmen><en> There are bus stations at both Cowes’ terminals where you can catch the bus to take you directly to the festival if you are on foot.
<G-vec00185-002-s663><catch.nehmen><de> An beiden Terminals in Cowes gibt es Bushaltestellen, von denen du Busse direkt zum Festivalgelände nehmen kannst.
<G-vec00185-002-s665><catch.nehmen><en> To return to Bilbao, you can catch the train at the nearby station of Sagrada Familia.
<G-vec00185-002-s665><catch.nehmen><de> Für den Rückweg nach Bilbao können Sie an dem nahe gelegenen Bahnhof Sagrada Familia den Zug nehmen.
<G-vec00185-002-s666><catch.nehmen><en> However, should you feel the need to explore other neighborhoods in the city; you can catch the A, C, E or L lines at the 14 Street / 8 Avenue subway station just 6 blocks from the apartment.
<G-vec00185-002-s666><catch.nehmen><de> Falls Sie trotzdem die anderen Viertel der Stadt entdecken möchten; können Sie die Linien A, C, E oder L von der 14 Street U-Bahn-Station nehmen, die sich nur 6 Blocks von Ihrer Wohnung entfernt befindet.
<G-vec00185-002-s667><catch.nehmen><en> Alternatively, you can catch the direct bus from outside the airport which takes about 30 minutes to get to Avenida Carlos V in the centre of the city.
<G-vec00185-002-s667><catch.nehmen><de> Oder Sie nehmen den Bus außerhalb des Flughafens, der etwa 30 Minuten braucht, um zur Avenida Carlos V im Stadtzentrum zu gelangen.
<G-vec00185-002-s668><catch.nehmen><en> In the port of Agaete you can catch Fred Olsen boat and visit the island of Tenerife in 2 hours away.
<G-vec00185-002-s668><catch.nehmen><de> Im Hafen von Agaete können Sie Fred Olsen Boot nehmen und die Insel Teneriffa in 2 Stunden entfernt besuchen.
<G-vec00185-002-s669><catch.nehmen><en> Tonight, we will catch a night train to Zagreb, from where we try to reach Split and perhaps take a daytrip to Dubrovnik!
<G-vec00185-002-s669><catch.nehmen><de> Heute Nacht werden wir den Nachtzug nach Zagreb nehmen, von wo aus wir versuchen, Split zu erreichen und dann eventuell einen Tagesausflug nach Dubrovnik.
<G-vec00185-002-s670><catch.nehmen><en> From Avezzano, you can catch a train to Sora.
<G-vec00185-002-s670><catch.nehmen><de> Von Avezzano können Sie einen Zug nach Sora nehmen.
<G-vec00185-002-s671><catch.nehmen><en> If you have to catch a connecting flight in Barcelona, the airport may provide you with a buggy on loan for the duration of your stopover.
<G-vec00185-002-s671><catch.nehmen><de> Wenn Sie in Barcelona einen Anschlussflug nehmen, kann Ihnen der Flughafen selbst einen Kinderwagen leihen, solange Ihr Aufenthalt dauert.
<G-vec00185-002-s672><catch.nehmen><en> Instead, you could catch the train out of Brno and change in Kojetín.
<G-vec00185-002-s672><catch.nehmen><de> Sie können aber auch den Zug von Brünn nehmen und in Kojetín umsteigen.
<G-vec00185-002-s673><catch.nehmen><en> If you wish to catch a taxi from the airport you should be aware that the queues can be long during peak times and so it is advisable to book a private transfer in advance.
<G-vec00185-002-s673><catch.nehmen><de> Wenn Sie ein Taxi vom Flughafen Faro aus nehmen möchten, denken Sie bitte daran, dass es im Sommer längere Warteschlangen geben kann und es insofern ratsam ist, im Voraus einen privaten Transfer zu buchen.
<G-vec00185-002-s674><catch.nehmen><en> On the final day, drive to the airport to catch the international flight.
<G-vec00185-002-s674><catch.nehmen><de> Am letzten Tag fahren Sie zum Flughafen, um den internationalen Flug zu nehmen.
<G-vec00185-002-s675><catch.nehmen><en> If you want to be sure to catch fish, try special guided fishing tours, organized by Vuokatti Fishing.
<G-vec00185-002-s675><catch.nehmen><de> Wenn Sie auf Nummer sicher gehen möchten, nehmen Sie doch einfach an geführten Angeltouren teil, organisiert von Vuokatti Fishing.
<G-vec00185-002-s676><catch.nehmen><en> Catch any of the Meiko buses heading for “Shirarahama” from JR Shirahama Station.
<G-vec00185-002-s676><catch.nehmen><de> Nehmen Sie einen der Meiko-Busse, die vom JR-Bahnhof Shirahama nach Shirarahama fahren.
<G-vec00185-002-s677><catch.nehmen><en> From airport Tegel catch bus X9 to Zoologischer Garten.
<G-vec00185-002-s677><catch.nehmen><de> Vom Tegel Flughafen nehmen Sie das Bus X9 bis zum Zoologischer Garten.
<G-vec00185-002-s678><catch.nehmen><en> Catch the cog train from the Cosme Velho station and journey through dense rainforest to the Art Deco statue of Christ the Redeemer on Corcovado mountain.
<G-vec00185-002-s678><catch.nehmen><de> Nehmen Sie die Zahnradbahn vom Bahnhof Cosme Velho und fahren Sie durch dichten Regenwald zur Art-Deco-Statue von Christus, dem Erlöser, auf dem Berg Corcovado.
<G-vec00185-002-s679><catch.nehmen><en> From here, catch bus 546 to the hotel (the bus stop is in front of the hotel).
<G-vec00185-002-s679><catch.nehmen><de> Von dort aus nehmen Sie den Bus 546 zum Hotel (die Bushaltestelle liegt vor dem Hotel).
<G-vec00185-002-s680><catch.nehmen><en> From Sorso's train station, catch the bus for Castelsardo o Santa Teresa di Gallura and get off at the Marritza stop.
<G-vec00185-002-s680><catch.nehmen><de> Von Sorso nehmen Sie den Bus nach Castelsardo oder Santa Teresa di Gallura und steigen an der Haltestelle Marritza aus.
<G-vec00185-002-s681><catch.nehmen><en> Catch a connecting flight to Manchester to discover this city’s thriving music scene.
<G-vec00185-002-s681><catch.nehmen><de> Nehmen Sie einen Anschlussflug nach Manchester, um die blühende Musikszene dieser Stadt zu erkunden.
<G-vec00185-002-s682><catch.nehmen><en> Catch all the layers of sound - both low and high-sounds are fuller and more natural.
<G-vec00185-002-s682><catch.nehmen><de> Nehmen Sie alle Klangnuancen wahr, sowohl tiefe als auch hohe Töne sind so voller und natürlicher.
<G-vec00185-002-s683><catch.nehmen><en> - Go underground and catch the red metro line to Astoria.
<G-vec00185-002-s683><catch.nehmen><de> - U-Bahn gehen und nehmen Sie die rote U-Bahn bis Astoria.
<G-vec00185-002-s684><catch.nehmen><en> Catch the bus directly from the city, or the train to Bondi Junction then a very short bus from there.
<G-vec00185-002-s684><catch.nehmen><de> Nehmen Sie den Bus direkt im Stadtzentrum oder den Zug nach Bondi Junction und ab dort eine sehr kurze Busfahrt.
<G-vec00185-002-s686><catch.nehmen><en> You need to catch the L200 to get there.
<G-vec00185-002-s686><catch.nehmen><de> Um dorthin zu gelangen, nehmen Sie die L200.
<G-vec00185-002-s687><catch.nehmen><en> Add another day to your trip and catch a ferry from Magheraroarty to Tory Island.
<G-vec00185-002-s687><catch.nehmen><de> Verlängern Sie Ihre Reise um einen weiteren Tag und nehmen Sie die Fähre von Magheraroarty nach Tory Island.
<G-vec00185-002-s689><catch.nehmen><en> Catch the metro to Karlovo Namesti station.
<G-vec00185-002-s689><catch.nehmen><de> Nehmen Sie die Metro zur Station "Karlovo Namesti".
<G-vec00185-002-s690><catch.nehmen><en> Catch bus number 2 in the direction of 'Sand'.
<G-vec00185-002-s690><catch.nehmen><de> Nehmen Sie den Bus der Linie 2 in Richtung „Sand“.
<G-vec00185-002-s692><catch.nehmen><en> Or, catch the local bus (dolmus) into Kyrenia for a 30 minute ride to the lively centre of Kyrenia Town.
<G-vec00185-002-s692><catch.nehmen><de> Oder nehmen Sie den örtlichen Bus (Dolmus) nach Kyrenia und fahren Sie 30 Minuten zum lebendigen Zentrum von Kyrenia.
