<G-vec00555-002-s028><eject.ausgeben><en> Have the All-In-One automatically eject the jammed paper by pressing and holding Select.
<G-vec00555-002-s028><eject.ausgeben><de> Drücken Sie auf Auswahl und halten Sie die Taste gedrückt, damit der All-In-One das gestaute Papier automatisch ausgibt.
<G-vec00555-002-s030><eject.ausstoßen><en> If you are using iPod as a hard disk, you must eject it before disconnecting it from your computer.
<G-vec00555-002-s030><eject.ausstoßen><de> Wenn du iPod als Festplatte benutzt, mußt du sie ausstoßen, bevor Sie sie von deinem Computer trennen.
<G-vec00555-002-s064><eject.auswerfen><en> Once the recovery process is complete, you may click on the removal icon on the task tray to stop and eject the player.
<G-vec00555-002-s064><eject.auswerfen><de> Nach Abschluss der Übertragung können Sie auf das Auswurfsymbol in der Taskleiste klicken, um den Player anzuhalten und auszuwerfen.
<G-vec00555-002-s092><eject.drücken><en> Formatting a Memory Card • This will cause the memory card to disengage and eject partially.
<G-vec00555-002-s092><eject.drücken><de> Legen Sie keine schweren Gegenstände auf eine Speicherkarte, und verbiegen oder drücken Sie die Speicherkarte nicht.
<G-vec00555-002-s093><eject.einlegen><en> To eject and reload a disc from the player, click the Eject button, or press [E] on the keyboard.
<G-vec00555-002-s093><eject.einlegen><de> Um eine Disk aus dem Player auszuwerfen und erneut einzulegen, klicken Sie auf die Schaltfläche Auswerfen oder drücken Sie [E] auf der Tastatur.
<G-vec00555-002-s106><eject.entfernen><en> Select this option to eject all drives connected to Elgato Thunderbolt Dock.
<G-vec00555-002-s106><eject.entfernen><de> Verwende diese Option um alle angeschlossenen Geräte am Elgato Thunderbolt Dock sicher zu entfernen.
<G-vec00555-002-s108><eject.entnehmen><en> Eject the memory card 1.
<G-vec00555-002-s108><eject.entnehmen><de> Entnehmen Sie die Speicherkarte.
<G-vec00555-002-s060><eject.festmachen><en> 1024 Passo 48 Remove the single 2.0 mm Phillips screw securing the SIM card eject lever to the rear case.
<G-vec00555-002-s060><eject.festmachen><de> Schritt 48 Entferne die einzelne 2,0 mm Kreuzschlitzschraube, die den SIM Karten Auswurfhebel am hinteren Gehäuse festmacht.
<G-vec00555-002-s115><eject.herauslösen><en> The positive gas ions are accelerated towards a negative charged target where they eject atoms by direct momentum transfer.
<G-vec00555-002-s115><eject.herauslösen><de> Die positiven Gasionen werden dann auf ein negativ geladenes Target beschleunigt und lösen dort durch unmittelbare Impulsübertragung Atome heraus.
<G-vec00555-002-s112><eject.herausspringen><en> Insert the SIM card eject tool into the hole in the side of the SIM card tray and push to eject the tray.
<G-vec00555-002-s112><eject.herausspringen><de> Setze das Auswurfwerkzeug für SIM Karten in die Öffnung neben dem SIM Karten Einschub ein und drücke es hinein, um den Einschub herausspringen zu lassen.
<G-vec00555-002-s113><eject.hinauswerfen><en> The underlying principle in their minimalistic model was that each parasite lays no more than one egg in another bird’s nest, which the host may accept or eject.
<G-vec00555-002-s113><eject.hinauswerfen><de> In einem minimalistischen Modell haben sie zugrunde gelegt, dass jeder Parasit nur maximal ein Ei in ein fremdes Nest legt, das der Wirt akzeptieren oder hinauswerfen kann.
<G-vec00555-002-s121><eject.rausschleudern><en> The ease with which they eject one song after the next.
<G-vec00555-002-s121><eject.rausschleudern><de> Diese Leichtigkeit, mit der sie einen Song nach dem nächsten rausschleudern.
<G-vec00555-002-s126><eject.stoßen><en> People consume too much energy, use too much water and eject too much carbon into the atmosphere.
<G-vec00555-002-s126><eject.stoßen><de> Die Menschen konsumieren zu viel Energie, verbrauchen zu viel Wasser und stoßen viel zu viel CO2 in die Atmosphäre.
<G-vec00555-002-s130><eject.vernichten><en> Eject 7 ennemies with a single laser shot.
<G-vec00555-002-s130><eject.vernichten><de> Vernichte 7 Feinde mit einem einzigen Laserschuss.
<G-vec00555-002-s119><eject.verweisen><en> The Park reserves the right to deny persons under the influence of drugs or alcohol access to the Park or to eject them from the Park's premises.
<G-vec00555-002-s119><eject.verweisen><de> Personen, die unter Alkohol- und Drogeneinfluss stehen, kann der Zutritt zum Park verweigert oder können vom Parkgelände verwiesen werden.
<G-vec00555-002-s132><eject.werfen><en> Phreatomagmatic eruptions eject a "cocktail" of bombs, lapilli and ash.
<G-vec00555-002-s132><eject.werfen><de> Phreatomagmatische Eruptionen werfen einen "Cocktail" aus Bomben, Lapilli und Asche aus.
