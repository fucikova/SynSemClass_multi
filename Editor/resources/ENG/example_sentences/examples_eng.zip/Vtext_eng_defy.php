<G-vec00461-002-s082><defy.sich_widersetzen><en> To defy dangers or indecision.
<G-vec00461-002-s082><defy.sich_widersetzen><de> Sich Gefahren oder Unentschlossenheit zu widersetzen.
<G-vec00461-002-s083><defy.sich_widersetzen><en> However, these experimental structures that defy state standards create conflict between Reynolds and the authorities, who are backed by big business.
<G-vec00461-002-s083><defy.sich_widersetzen><de> Diese experimentellen Strukturen, die sich den staatlichen Standards widersetzen, schaffen jedoch einen Konflikt zwischen Reynolds und den Behörden, die von Grossunternehmen unterstützt werden.
<G-vec00461-002-s058><defy.trotzen><en> Following the example of our divine Lord and Redeemer, thou didst defy unjust power and help the needy with prayer and deed.
<G-vec00461-002-s058><defy.trotzen><de> Dem Beispiel unseres göttlichen Herrn und Erlösers folgend, hast du der ungerechten Gewalt getrotzt und den Notleidenden durch Gebet und Tat geholfen.
<G-vec00461-002-s133><defy.widersetzen><en> In the midst of this struggle, the idea dawned on me that we can only find the safest place if we collectively manage to defy the pressure of extreme economic constraints, do not blindly believe everything we are told and wrongly assume that statements are absolute scientific truths.
<G-vec00461-002-s133><defy.widersetzen><de> In diesem Ringen wuchs meine Einsicht, dass der sicherste Ort nur dort zu finden sein kann, wo es uns als Kollektiv gelingt, uns dem Druck extremer ökonomischer Sachzwänge zu widersetzen, nicht zu Gläubigen zu werden und Behauptungen nicht voreilig als letzte wissenschaftliche Wahrheiten zu missverstehen.
<G-vec00461-002-s134><defy.widersprechen><en> Mini-skirts in winter seem to defy common sense.
<G-vec00461-002-s134><defy.widersprechen><de> Miniröcke im Winter scheinen dem gesunden Menschenverstand zu widersprechen.
<G-vec00461-002-s135><defy.widersprechen><en> The desire to control one’s own destiny, to carve one’s own path and defy expectations, is a road few of us ever dare to travel.
<G-vec00461-002-s135><defy.widersprechen><de> … aber dem Verlangen zu folgen, Herr über sein eigenes Schicksal zu sein, seinen eigenen Weg zu gehen und Erwartungen zu widersprechen, ist eine Entscheidung, die nur wenige von uns zu treffen wagen.
<G-vec00461-002-s137><defy.widerstehen><en> Humans living under these types of laws have no humanity, no truth—they all defy the truth, and are hostile to God.
<G-vec00461-002-s137><defy.widerstehen><de> Menschen, die unter dieser Art von Gesetzen leben, haben keine Menschlichkeit, keine Wahrheit – sie alle widerstehen der Wahrheit und sind Gott feindlich gesinnt.
<G-vec00461-002-s138><defy.widerstehen><en> It seems to defy the interpretation as well as restrictions of dental steroids.
<G-vec00461-002-s138><defy.widerstehen><de> Es scheint, die Interpretation und die Grenzen von oralen Steroiden zu widerstehen.
<G-vec00461-002-s139><defy.widerstehen><en> It seems to defy the definition and also limitations of dental steroids.
<G-vec00461-002-s139><defy.widerstehen><de> Es scheint, die Auslegung und die Einschränkungen von oralen Steroiden zu widerstehen.
