<G-vec00121-002-s044><compete.antreten><en> Michael Rutter will again compete on Ripley Land Matchless.
<G-vec00121-002-s044><compete.antreten><de> Wieder auf Ripley Land Matchless wird Michael Rutter antreten.
<G-vec00121-002-s045><compete.antreten><en> You can setup your own contest within each of the available prediction games and compete against your friends and colleagues.
<G-vec00121-002-s045><compete.antreten><de> Du kannst innerhalb jedes verfügbaren Tippspiels deinen eigenen Wettbewerb starten und gegen deine Freunde und Kollegen antreten.
<G-vec00121-002-s046><compete.antreten><en> “You must never compete in order to win second place because then you have already lost.
<G-vec00121-002-s046><compete.antreten><de> “Du darfst niemals antreten, um zweiter Sieger zu werden, denn dann hast du bereits im Vorfeld verloren.
<G-vec00121-002-s047><compete.antreten><en> Matchplayer can compete against each other within a single match play as well as in a match play foursome. In the end of the round, the winner is the Matchplayer or team with the lowest score.
<G-vec00121-002-s047><compete.antreten><de> Matchplayer können sowohl im Single Match Play gegeneinander antreten, als auch im Match Play Foursome im Zweier-Team gegen ein anderes Team um den niedrigsten Punktestand spielen.
<G-vec00121-002-s048><compete.antreten><en> All players will benefit from the big changes that have been made to the VIP Club by being able to compete in selected freerolls and all points races, as well as getting those high paying monthly points boosts.
<G-vec00121-002-s048><compete.antreten><de> Alle Spieler werden von den großen Veränderungen, die im VIP Club stattgefunden haben, profitieren und in ausgewählten Freerolls und All Points Races antreten können, sowie die gewinnbringenden monatlichen Points Boosts erhalten.
<G-vec00121-002-s049><compete.antreten><en> The game idea is based on the FEO media application and contains that the users of the application compete against friends or unknown challengers in different categories, which will be broadcasted live on TV.
<G-vec00121-002-s049><compete.antreten><de> Die auf der FEO Media Applikation basierende Spielidee, bei der App-Nutzer gegen Freunde oder unbekannte Herausforderer in verschiedenen Kategorien antreten, wird live im TV übertragen.
<G-vec00121-002-s050><compete.antreten><en> Zarco was originally supposed to compete as a KTM factory driver until the end of 2020, after the joint contract resolution, he should then drive for KTM […weiter lesen]
<G-vec00121-002-s050><compete.antreten><de> Zarco sollte ursprünglich bis Ende 2020 als KTM-Werksfahrer antreten, nach der gemeinsamen Vertragsauflösung dann noch bis zum Ende dieser Saison.
<G-vec00121-002-s051><compete.antreten><en> The FIA Formula E is a series that was established by the FIA in 2014 in which leading professional race drivers compete against one another in fully electrical powertrain formula racing cars.
<G-vec00121-002-s051><compete.antreten><de> Die Formula E ist eine von der FIA ins Leben gerufene Meisterschaft, in der die Piloten in rein elektrisch betriebenen Formelrennwagen gegeneinander antreten.
<G-vec00121-002-s052><compete.antreten><en> The singers will also compete in the "Folklore" category at the Grand Prix of Nations Berlin 2017 and will present music and dances from their homeland.
<G-vec00121-002-s052><compete.antreten><de> Die Sängerinnen und Sänger werden auch beim Grand Prix of Nations Berlin 2017 in der Kategorie „Folklore“ antreten und Musik und Tanz aus ihrer Heimat präsentieren.
<G-vec00121-002-s053><compete.antreten><en> Three boys and three girls respectively (U 16 – born in 2002 and 2003) are allowed to compete at the Junior Race.
<G-vec00121-002-s053><compete.antreten><de> Jeweils drei Buben und drei Mädchen (U16 – Jahrgänge 2002/2003) dürfen beim Junior Race antreten.
<G-vec00121-002-s054><compete.antreten><en> A total of 10 teams will compete.
<G-vec00121-002-s054><compete.antreten><de> Insgesamt werden 10 Teams antreten.
<G-vec00121-002-s055><compete.antreten><en> 4) Each player announces (via PM) 3 factions with which he wants to compete, this happens via PM to the Manager.
<G-vec00121-002-s055><compete.antreten><de> 4) Jeder Spieler meldet (per PM) 3 Völker mit dennen er antreten will.
<G-vec00121-002-s056><compete.antreten><en> Every year there is also a special: In 2016, the players could compete against a winner of the German or even European Championships in the “Challenge A Champion”.
<G-vec00121-002-s056><compete.antreten><de> Jedes Jahr gibt es auch ein Special: 2016 konnten die Spieler beim „Challenge A Champion“ gegen einen Gewinner der Deutschen oder sogar Europäischen Meisterschaften antreten.
<G-vec00121-002-s057><compete.antreten><en> Everyone wants to compete there.
<G-vec00121-002-s057><compete.antreten><de> Dort will jeder antreten.
<G-vec00121-002-s058><compete.antreten><en> At Year Six this was Rebecca Arenz who will now compete a the next level at the old castle Bilstein at the beginning of 2008.
<G-vec00121-002-s058><compete.antreten><de> Im sechsten Schuljahr war dieses Rebecca Arenz, die jetzt in der nächsten Runde auf der alten Burg Bilstein Anfang 2008 antreten wird.
<G-vec00121-002-s059><compete.antreten><en> Despite not being able to officially compete in racing competitions, Ducati developed the Mach 250, capable of exceeding the 150km/h threshold, which gained it a special place in the heart of all sporting enthusiasts.
<G-vec00121-002-s059><compete.antreten><de> Im Wettkampfbereich entwickelte Ducati, die offiziell nicht mit einem Team antreten konnte, die Mach 250, die die 150-km/h-Schwelle überschritt und damit die Herzen der Sportgemeinde eroberte.
<G-vec00121-002-s060><compete.antreten><en> A dancer can compete together with one dancer in the standard section and with another dancer in the latin section.
<G-vec00121-002-s060><compete.antreten><de> Teilnehmer*innen können mit einer Person in der Standard-Sektion antreten und mit einer anderen Person in der Latein- Sektion.
<G-vec00121-002-s061><compete.antreten><en> Even opera singers are allowed to compete.
<G-vec00121-002-s061><compete.antreten><de> Selbst Opernsänger dürfen antreten.
<G-vec00121-002-s062><compete.antreten><en> Michael Brandner: Women must also compete and participate in politics, art and culture, even among the broad masses.
<G-vec00121-002-s062><compete.antreten><de> Michael Brandner: Auch in der breiten Masse müssen Frauen antreten und mitwirken in der Politik, in der Kunst und Kultur.
<G-vec00121-002-s063><compete.antreten><en> Customers will be able to purchase the BMW M6 GT3 from the end of 2015, allowing them to compete in the 2016 BMW Sports Trophy with the new car.
<G-vec00121-002-s063><compete.antreten><de> Kunden haben ab Ende 2015 die Möglichkeit, einen BMW M6 GT3 zu erwerben und damit ab 2016 in verschiedenen Rennserien und im Rahmen der BMW Sports Trophy anzutreten.
<G-vec00121-002-s064><compete.antreten><en> The so-called king of street fighters, a Thai kick boxer named Sagat, challenges the most talented fighters from all countries to compete in the tournament.
<G-vec00121-002-s064><compete.antreten><de> Der sogenannte König der Street Fighter, ein thailändischer Kickboxer namens Sagat, rief die begabtesten Kämpfer aus allen Ländern auf, in den Tournament anzutreten.
<G-vec00121-002-s065><compete.antreten><en> There are more ways to compete against your friends in FUT 17.
<G-vec00121-002-s065><compete.antreten><de> In FUT 17 hast du noch mehr Möglichkeiten, gegen deine Freunde anzutreten.
<G-vec00121-002-s066><compete.antreten><en> "I am devastated to announce that I will not be able to compete in Sochi," the alpine skier wrote in a post on her Facebook page.
<G-vec00121-002-s066><compete.antreten><de> "Ich bin am Boden zerstört, mitteilen zu müssen, dass ich nicht in der Lage sein werde in Sotschi anzutreten.
<G-vec00121-002-s067><compete.antreten><en> Statistics and multipler profiles make it possible to compete against your family / friends.
<G-vec00121-002-s067><compete.antreten><de> Statistiken und Mehrspieler Profile ermöglichen es Ihnen, gegen Ihre Freunde / Familie anzutreten.
<G-vec00121-002-s068><compete.antreten><en> Yet what keeps Mirko ‘fueled’ more than anything, is his motivation to compete against others and to have the chance to explore Switzerland during these competitions.
<G-vec00121-002-s068><compete.antreten><de> Was Mirko vor allem antreibt, ist die Motivation, gegen andere anzutreten und die Möglichkeit, die Schweiz während dieser Rennen kennenzulernen.
<G-vec00121-002-s069><compete.antreten><en> For it to serve its purposes, which include providing females opportunities equal to males, it must have eligibility standards that ensure that athletes who identify as female but have testes, and testosterone levels in the male range, at least drop their testosterone levels into the female range in order to compete at the elite level in the female classification.
<G-vec00121-002-s069><compete.antreten><de> Damit es seinen Zweck erfüllen kann, einschließlich der Chancengleichheit von Frauen und Männern, muss es über Zulassungsstandards verfügen, die sicherstellen, dass Athleten, die sich als weiblich identifizieren, aber Hoden und Testosteronspiegel im männlichen Bereich haben, zumindest ihre Testosteronspiegel in den weiblichen Bereich herabsetzen, um auf der obersten Elite-Ebene in der weiblichen Klassifizierung anzutreten.
<G-vec00121-002-s070><compete.antreten><en> Then, prepare to compete around the world.
<G-vec00121-002-s070><compete.antreten><de> Bereite dich dann darauf vor, weltweit anzutreten.
<G-vec00121-002-s071><compete.antreten><en> Description You are nearly ready to compete in the grand melee.
<G-vec00121-002-s071><compete.antreten><de> Beschreibung Ihr seid fast bereit, beim großen Arenakampf anzutreten.
<G-vec00121-002-s072><compete.antreten><en> Because this game enables the player to slip into the role of bank and to compete against others.
<G-vec00121-002-s072><compete.antreten><de> Denn dieses Spiel ermöglicht den Spieler in die Rolle der Bank zu schlüpfen und gegen andere anzutreten.
<G-vec00121-002-s073><compete.antreten><en> Support your club and compete against rivals in every area of the game, lifting your club higher in the league tables or helping them avoid relegation.
<G-vec00121-002-s073><compete.antreten><de> Die Saison in FIFA 13 wird durch Ereignisse in der realen Fußballwelt beeinflusst.,,Support Your Club" ermöglicht es den Fans, ihren Verein zu repräsentieren und in jedem Bereich von FIFA 13 gegen rivalisierende Vereine anzutreten.
<G-vec00121-002-s074><compete.antreten><en> But this is only one of the available modes, since you will be able to compete in single races or for a fixed time as well as in races against the clock.
<G-vec00121-002-s074><compete.antreten><de> Aber das ist nur einer der verfügbaren Modi, da Sie in der Lage sind, in einzelnen Rennen oder für eine bestimmte Zeit auch in Rennen gegen die Uhr anzutreten.
<G-vec00121-002-s075><compete.antreten><en> SQUAD BATTLES Hockey Ultimate Team introduces a new way to play in Squad Battles that allows you to compete and earn big rewards.
<G-vec00121-002-s075><compete.antreten><de> TEAM BATTLES Hockey Ultimate Team führt mit Team Battles eine neue Spielweise ein, die dir ermöglicht, in Duellen anzutreten, um tolle Belohnungen zu erhalten.
<G-vec00121-002-s076><compete.antreten><en> SAFT admits, that in the telecommunication and consumer markets it is hard to compete against China.
<G-vec00121-002-s076><compete.antreten><de> SAFT räumt ein, dass es im Telekommunikations- und Konsumenten-Sektor schwierig ist, gegen Chinesische Produkte anzutreten.
<G-vec00121-002-s077><compete.antreten><en> Ehret: „I am pleased to compete together with Michele and the team in the Blancpain Endurance Series.
<G-vec00121-002-s077><compete.antreten><de> Ehret: „Ich freue mich wieder mit Michele und seinem Team in der diesjährigen Blancpain Endurance Series anzutreten.
<G-vec00121-002-s078><compete.antreten><en> Rack up points to compete against prior scavenger hunt teams, or simply enjoy the self-guided tour at your own pace, with plenty of stops to eat, drink and sightsee.
<G-vec00121-002-s078><compete.antreten><de> Sammeln Sie Punkte, um gegen frühere Scavenger-Jagdteams anzutreten, oder genießen Sie einfach die selbstgeführte Tour in Ihrem eigenen Tempo mit vielen Stopps zum Essen, Trinken und Besichtigen.
<G-vec00121-002-s138><compete.antreten><en> Oh by the way, Verizon has reinvented the enterprise cloud and thus would compete with the Amazon Web Services.
<G-vec00121-002-s138><compete.antreten><de> Ach übrigens, Verizon hat die Enterprise Cloud neu erfunden und möchte damit gegen die Amazon Web Services antreten.
<G-vec00121-002-s139><compete.antreten><en> You can compete with your friends once your Samsung account is registered.
<G-vec00121-002-s139><compete.antreten><de> Sie können gegen Ihre Freunde antreten, sobald Ihr Samsung Account registriert wurde.
<G-vec00121-002-s140><compete.antreten><en> Here, you can analyze your data, deep dive into your stats, track your progress, and interact and compete with people all around the world.
<G-vec00121-002-s140><compete.antreten><de> Hier kannst du deine Daten analysieren, tief eintauchen in deine Statistiken, deinen Fortschritt verfolgen und mit anderen Leuten auf der ganzen Welt interagieren sowie gegen sie antreten.
<G-vec00121-002-s141><compete.antreten><en> Fancy Pants Adventures on PlayStation 3 features an addictive multiplayer mode that you can compete in with up to three of your friends via PlayStation Network.
<G-vec00121-002-s141><compete.antreten><de> The Fancy Pants Adventures für PlayStation 3 verfügt über einen tollen Multiplayermodus, bei dem du über PlayStation Network gegen bis zu drei Freunde antreten kannst.
<G-vec00121-002-s142><compete.antreten><en> When racing, he always had to compete guys who were bigger and stronger than him.
<G-vec00121-002-s142><compete.antreten><de> Beim Rennfahren musste er stets gegen Jungs antreten, die größer und stärker als er waren.
<G-vec00121-002-s143><compete.antreten><en> Finally holidays with the family But also together as a family you will experience a lot of fun and entertainment: Walks that show you the most beautiful parts of the mountains, horse-drawn carriage rides in Zug, compete with other families at the snowman building contest in front of the Goldener Berg Hotel or dash down the bobsleigh run in Lech.
<G-vec00121-002-s143><compete.antreten><de> Aber auch im Familienverbund wartet einiges an Unterhaltung: Spaziergänge, bei denen Sie die schönsten Seiten der Bergwelt kennenlernen, Pferdekutschenfahrten in Zug, beim Schneemannbau-Wettbewerb vor der Haustüre des Hotels Goldener Berg gegen andere Familien antreten oder auf der mit Flutlicht beleuchteten Bobbahn in Lech mit der Rodel ins Tal sausen.
<G-vec00121-002-s144><compete.antreten><en> In addition, Explore, Global Events and RiderNet - SSX’s recommendation engine - headline an online feature set that will revolutionize social competition for gamers, making it fun and easy to compete with friends on your schedule. LATEST POSTS
<G-vec00121-002-s144><compete.antreten><de> Ferner bilden “Explore”, Globale Events und RiderNet – die Empfehlungs-Engine von SSX – den Mittelpunkt eines Online-Modus, der den sozialen Wettbewerb für Videospieler revolutionieren wird und dir ermöglicht, nach deinem persönlichen Zeitplan gegen deine Freunde anzutreten.
<G-vec00121-002-s145><compete.antreten><en> Both teams participate in the Formula Student Germany (FSG) and term for term they develop, construct and build racing cars to compete with other student from all over the world.
<G-vec00121-002-s145><compete.antreten><de> Die beiden Teams nehmen an der Formula Student Germany (FSG) teil und entwickeln, konstruieren und bauen Semester für Semester neue Rennfahrzeuge, um gegen andere Studenten aus der ganzen Welt anzutreten.
<G-vec00121-002-s146><compete.antreten><en> Use strategy and magical boosts to score more points and compete with friends from all over the world.
<G-vec00121-002-s146><compete.antreten><de> Wende Strategie und magische Verstärkungen an, um mehr Punkte zu erlangen und gegen Freunden aus der ganzen Welt anzutreten.
<G-vec00121-002-s147><compete.antreten><en> Each level has its own leaderboard, making it easy to track progress in the game, compete with friends, and show off your powerful skills.
<G-vec00121-002-s147><compete.antreten><de> Jedes Level hat seine eigene Bestenliste, was es dir einfach macht, deinen Fortschritt nachzuverfolgen, gegen Freunde anzutreten und deine coolen Skills zu zeigen.
<G-vec00121-002-s148><compete.antreten><en> The team was so good, in fact, the Wasteland team was so scared it never showed up to compete.
<G-vec00121-002-s148><compete.antreten><de> Diese Mannschaft war so gut, dass sich die Auswahl des Ödlands nie getraut hat, gegen sie anzutreten.
<G-vec00121-002-s166><compete.antreten><en> From challenging climbing routes to mazes: climbers can compete with each other, cooperate and improve their skills.
<G-vec00121-002-s166><compete.antreten><de> Von anspruchsvollen Kletterrouten bis zu Labyrinthen: Die Kletterer können gegeneinander antreten, miteinander kooperieren und ihre Fähigkeiten verbessern.
<G-vec00121-002-s167><compete.antreten><en> Our competitor is strong and we decided not to strategically position our two cars but to let them compete against each other.
<G-vec00121-002-s167><compete.antreten><de> Unser Wettbewerber ist stark und wir haben uns entschlossen, unsere beiden Autos nicht strategisch zu positionieren, sondern sie gegeneinander antreten zu lassen.
<G-vec00121-002-s168><compete.antreten><en> From the beginning of XIX in London on the River Thames a classic Royal Regatta has been held, in which the crews of Oxford and Cambridge compete.
<G-vec00121-002-s168><compete.antreten><de> Seit Beginn des XIX in London an der Themse findet eine klassische Royal Regatta statt, bei der die Mannschaften von Oxford und Cambridge gegeneinander antreten.
<G-vec00121-002-s169><compete.antreten><en> The McLaren Ultimate Vision Gran Turismo was designed in response to a call from game creator, Kazunori Yamauchi, for vehicle manufacturers to design ‘visionary GT cars’ to compete in Gran Turismo Sport.
<G-vec00121-002-s169><compete.antreten><de> Der McLaren Ultimate Vision Gran Turismo wurde als Reaktion auf einen Aufruf des Spieleschöpfers Kazunori Yamauchi entworfen: Fahrzeughersteller sollten “visionäre GT Autos” designen, die in „Gran Turismo Sport“ gegeneinander antreten würden.
<G-vec00121-002-s170><compete.antreten><en> Secret Hitler is a board game in which liberals and fascists compete against each other.
<G-vec00121-002-s170><compete.antreten><de> Secret Hitler ist ein Brettspiel, in dem Liberale und Faschisten gegeneinander antreten.
<G-vec00121-002-s171><compete.antreten><en> Sixteen national teams will compete in a total of 31 matches to be crowned champions.
<G-vec00121-002-s171><compete.antreten><de> Sechzehn Nationalmannschaften werden in insgesamt 31 Spielen gegeneinander antreten und um den Meistertitel kämpfen.
<G-vec00121-002-s172><compete.antreten><en> For their part, both Xavi Torres and Lorena Homar showed their satisfaction about their nomination to participate in those games in which more than 4200 sportsmen of more than 160 different countries will compete for one of the 500 Paralympics’ medals.
<G-vec00121-002-s172><compete.antreten><de> Ihrerseits haben sowohl Xavi Torres, als auch Lorena Homar ihre Zufriedenheit über die Aufstellung gezeigt, um an diesen Spielen teilnehmen zu dürfen, an denen mehr als 4200 Sportler aus mehr als 160 verschiedenen Ländern gegeneinander antreten, um eine der mehr als 500 Medaillen zu gewinnen.
<G-vec00121-002-s173><compete.antreten><en> For one thing, because of the impressive standard at the final in Geneva and the exciting way that different instruments and line-ups come together to compete.
<G-vec00121-002-s173><compete.antreten><de> Zum einen aufgrund des beeindruckenden Niveaus im Finale in Genf und des spannenden Modus, bei dem unterschiedliche Instrumente und Besetzungen gegeneinander antreten.
<G-vec00121-002-s174><compete.antreten><en> luchadores bet their masks, the loser is unmasked by the winner. Máscara contra cabellera ("mask versus hair"): a masked wrestler and an unmasked one compete, sometimes after the unmasked one has lost his mask to the masked one in a prior bout.
<G-vec00121-002-s174><compete.antreten><de> Ein anderer bekannter Kampftyp ist máscara contra cabellera (Maske gegen Haare), wo ein maskierter und ein unmaskierter Wrestler gegeneinander antreten (für gewöhnlich hat der unmaskierte seine Maske gegen den maskierten Wrestler in einem vorherigen Kampf verloren); wenn der maskierte Luchador gewinnt, muss der unmaskierte seine Haare abrasieren lassen, was ein weiteres Zeichen der Erniedrigung darstellt.
<G-vec00121-002-s175><compete.antreten><en> Console Quartets Let 32 consoles and additionally handhelds and special rarities compete in Top Trumps.
<G-vec00121-002-s175><compete.antreten><de> Lass 32 Konsolen und zusätzlich Handhelds und Raritäten im Supertrumpf gegeneinander antreten.
<G-vec00121-002-s176><compete.antreten><en> In a total of nine disciplines runners, skaters, walkers, pedal scooters and handbikers can compete against each other on the cross-country, demanding route.
<G-vec00121-002-s176><compete.antreten><de> In insgesamt neun Disziplinen können Läufer, Skater, Walker, Tretrollerfahrer und Handbiker auf der grenzüberschreitenden, anspruchsvollen Strecke gegeneinander antreten.
<G-vec00121-002-s177><compete.antreten><en> In the final event, the 16 best Melee Singles players, the 8 best Melee Doubles teams and the top 2 crews will compete against each other in their respective formats.
<G-vec00121-002-s177><compete.antreten><de> Im Finalen Event werden die 16 besten Melee Singles Spieler, die 8 besten Melee Doubles Teams sowie die Top 2 der Crews in ihrem jeweiligen Format gegeneinander antreten.
<G-vec00121-002-s178><compete.antreten><en> “People always want to see people compete against each other.
<G-vec00121-002-s178><compete.antreten><de> “Die Leute wollen immer Menschen gegeneinander antreten sehen.
<G-vec00121-002-s179><compete.antreten><en> The Limit Hold'em Challenge is a series of heads-up matches where the biggest names in poker compete for high-stakes.
<G-vec00121-002-s179><compete.antreten><de> Die Limit Hold'em Challenge ist eine neue Serie von High Stakes Matches, in denen die großen Namen der Szene Heads-up gegeneinander antreten.
<G-vec00121-002-s180><compete.antreten><en> In the 1930s, Foshan is a hub of Southern Chinese martial arts, where various schools actively recruit disciples and compete against each other.
<G-vec00121-002-s180><compete.antreten><de> Das Dorf ist Zentrum einiger Kampfsportschulen, die gelegentlich gegeneinander antreten, um voneinander zu lernen.
<G-vec00121-002-s181><compete.antreten><en> Today boys and girls from over 150 schools compete in various track and field disciplines.
<G-vec00121-002-s181><compete.antreten><de> Heute sind es Jungen und Mädchen von über 150 Schulen, die in verschiedenen Disziplinen jedes Jahr gegeneinander antreten.
<G-vec00121-002-s182><compete.antreten><en> For the second time, the Data Science Challenge will take place at the BTW conference series, where five research groups will compete against each other this year.
<G-vec00121-002-s182><compete.antreten><de> Zum zweiten Mal findet auf der BTW-Konferenzreihe die Data Science Challenge statt, auf der in diesem Jahr fünf Forschergruppen gegeneinander antreten.
<G-vec00121-002-s183><compete.antreten><en> They are all played by the outstanding actress Tilda Swinton, who has the very diverse characters she is playing compete which each other with self-irony.
<G-vec00121-002-s183><compete.antreten><de> Sie alle werden von der grandiosen Schauspielerin Tilda Swinton gespielt, die ihre sehr unterschiedlichen Charaktere selbstironisch gegeneinander antreten lässt.
<G-vec00121-002-s184><compete.antreten><en> Users can even meet in language clubs and compete against each other.
<G-vec00121-002-s184><compete.antreten><de> Benutzer können sich sogar in Sprachclubs treffen und gegeneinander antreten.
<G-vec00121-002-s581><compete.antreten><en> Designers compete in five main categories—beverages, food, body, luxury, and other markets—and no fewer than 44 sub-categories.
<G-vec00121-002-s581><compete.antreten><de> Die Gestalter treten in den fünf Hauptkategorien Getränke, Nahrung, Körperpflege, Luxusartikel und Andere Märkte sowie in nicht weniger als 44 Unterkategorien an.
<G-vec00121-002-s582><compete.antreten><en> In the new five-part music show series, nine celebrities compete in this major singing contest.
<G-vec00121-002-s582><compete.antreten><de> In der neuen fünfteiligen Musikshowreihe treten neun Prominente zum großen Gesangswettstreit an.
<G-vec00121-002-s583><compete.antreten><en> Elite and amateur trail runners from all over the world compete in this punishing 119 km race featuring 5,850 metres elevation gain.
<G-vec00121-002-s583><compete.antreten><de> Athleten aus aller Welt treten zum Wettlauf auf einer 119 km langen, einmalig schönen Strecke an.
<G-vec00121-002-s584><compete.antreten><en> For Priest talents, we are trying one more time to make Angelic Feather compete with the other movement talents, and let Mindbender and From Darkness, Comes Light compete better with Solace and Insanity.
<G-vec00121-002-s584><compete.antreten><de> Was die Priestertalente betrifft, versuchen wir ein letztes Mal, 'Engelsfeder' in Konkurrenz mit den anderen Bewegungstalenten treten zu lassen.
<G-vec00121-002-s585><compete.antreten><en> The question is, whether it makes even sense for a small producer such as the fruit juice cooperative "El Paraiso" to compete on the market with a mainstream product such as orange juice, or whether it isn’t better to focus on niche products that might be sold with higher margins.
<G-vec00121-002-s585><compete.antreten><de> Die Frage ist, ob es für einen Kleinhersteller wie die Fruchtsaftkooperative "El Paraiso" überhaupt Sinn ergibt, mit Mainstream-Produkten wie Orangensaft an den Markt zu treten, für den es viele Mitbewerber gibt, oder ob nicht Nischenprodukte zu höheren Gewinnspannen verkauft werden können.
<G-vec00121-002-s586><compete.antreten><en> There is a novelty: For the first time in the RCCO, eight cars will compete against each other at the same time on a digital “Slotfire” track.
<G-vec00121-002-s586><compete.antreten><de> Dabei gibt es ein Novum: Zum ersten Mal treten bei der RCCO auf einer digitalen Slotfire-Bahn acht Autos gleichzeitig im Rennen an.
<G-vec00121-002-s587><compete.antreten><en> Final, the best junior handlers from the semi-finals compete in the final together with the participants sent by the national organisations.
<G-vec00121-002-s587><compete.antreten><de> Im Finale treten die besten Junior Handler der Halbfinals gegen die Teilnehmer aus dem Ausland an, die von ihrem Land nominiert wurden.
<G-vec00121-002-s588><compete.antreten><en> The other four categories, on the other hand, are heavily occupied, with more than 100 drivers having agreed to come and compete in the final races of the DKM season 2020.
<G-vec00121-002-s588><compete.antreten><de> Die anderen vier Kategorien sind dagegen stark besetzt, über 100 Fahrerinnen und Fahrer haben ihr Kommen zugesagt und treten in den finalen Rennen der DKM-Saison 2020.
<G-vec00121-002-s589><compete.antreten><en> In the highly remunerated Golden League, the winners of all DWM trophies from a calendar year enter compete against each other in the search for the best of the best.
<G-vec00121-002-s589><compete.antreten><de> In der hochdotierten Golden League treten die Gewinner aller DWM Trophies eines Kalenderjahres wettbewerbsübergreifend gegeneinander an: gesucht werden die Besten der Besten.
<G-vec00121-002-s590><compete.antreten><en> For three weeks, the best jockeys in Europe compete against each other in different disciplines with their fiery thoroughbreds.
<G-vec00121-002-s590><compete.antreten><de> Drei Wochen lang treten in verschiedenen Disziplinen die besten Jockeys Europas mit ihren feurigen Vollblütern gegeneinander an.
<G-vec00121-002-s591><compete.antreten><en> Its U8’s and U10’s boys and girls teams, plus its U14’s and U16’s girls teams compete nationally.
<G-vec00121-002-s591><compete.antreten><de> Seine U8 und U10 Buben- und Mädchen-Teams, und seine U14 und U16 Mädchen-Teams treten national an.
<G-vec00121-002-s592><compete.antreten><en> Compete in epic 24-player races and Forza Race Leagues across 26 world-famous locales, all at a stunning 1080p resolution and 60 frames per second.
<G-vec00121-002-s592><compete.antreten><de> Treten Sie bei epischen 24-Stunden-Rennen und Forza-Rennligen an 26 weltbekannten Veranstaltungsorten an, all das in atemberaubender 1080p-Auflösung und mit 60 fps.
<G-vec00121-002-s593><compete.antreten><en> Compete against CART cars that are controlled by exacting artificial intelligence.
<G-vec00121-002-s593><compete.antreten><de> Treten Sie gegen CART Autos, die durch anspruchsvolle künstliche Intelligenz gesteuert werden.
<G-vec00121-002-s594><compete.antreten><en> You will compete in the space with aliens.
<G-vec00121-002-s594><compete.antreten><de> Sie treten in den Raum mit aliens.
<G-vec00121-002-s595><compete.antreten><en> Explorers compete as individuals, or in pairs and they may choose to be advised by a mentor on scientific and technical aspects of their project entry.
<G-vec00121-002-s595><compete.antreten><de> Explorer treten einzeln oder in Paaren an und dürfen sich von einem Mentor in Bezug auf wissenschaftliche oder technische Aspekte ihrer Projektbeiträge beraten lassen.
<G-vec00121-002-s596><compete.antreten><en> In the global MARGA Online Competition the participants compete as a management team and run a simulated company - web-based, self-directed and independent of location.
<G-vec00121-002-s596><compete.antreten><de> Im globalen MARGA Online Planspiel-Wettbewerb treten die Teilnehmenden als Management-Team an, ein simuliertes Unternehmen zu führen – webbasiert, selbstgesteuert und ortsunabhängig.
<G-vec00121-002-s597><compete.antreten><en> Men and women compete in separate fitness categories.
<G-vec00121-002-s597><compete.antreten><de> Männer und Frauen treten in einzelnen Fitnessklassen an.
<G-vec00121-002-s598><compete.antreten><en> Accordingly, the teams compete against other teams only within their age group.
<G-vec00121-002-s598><compete.antreten><de> Dementsprechend treten die Teams nur innerhalb ihrer Altersklasse gegen andere Teams an.
<G-vec00121-002-s599><compete.antreten><en> The 17 best respective drivers of both races are then going to compete against each other in the final race.
<G-vec00121-002-s599><compete.antreten><de> Die jeweils besten 17 aus den beiden Rennen treten dann im Finale gegeneinander an.
<G-vec00121-002-s600><compete.antreten><en> In the open Master tournament, 132 players compete.
<G-vec00121-002-s600><compete.antreten><de> Im Meisteropen treten 132 Spieler an.
<G-vec00121-002-s601><compete.antreten><en> From the 2019 Formula 1 World Championship, the two historic brands, Sauber and Alfa Romeo, will compete with a new name as Alfa Romeo Racing.
<G-vec00121-002-s601><compete.antreten><de> Ab der Formel-1-Weltmeisterschaft 2019 treten die zwei historischen Marken, Sauber und Alfa Romeo, mit einem neuen Namen als Alfa Romeo Racing an.
<G-vec00121-002-s602><compete.antreten><en> In this tournament teams from all over Germany compete.
<G-vec00121-002-s602><compete.antreten><de> In diesem Turnier treten Teams aus ganz Deutschland an.
<G-vec00121-002-s603><compete.antreten><en> WARZONE MULTIPLAYER Play with friends and compete against rivals in three massive multiplayer modes new to the Halo franchise: Warzone, Warzone Assault, and Warzone Firefight: -WARZONE is a massive-scale multiplayer mode that supports 24-player battles with both friendly and enemy AI constantly dropping in to mix up the experience.
<G-vec00121-002-s603><compete.antreten><de> KRIEGSGEBIET-MULTIPLAYER Spielen Sie mit Freunden und treten Sie gegen Rivalen in drei neuen, massiven Multiplayer-Modi an – Kriegsgebiet, Kriegsgebiet-Angriff und Kriegsgebiet-Feuergefecht: – KRIEGSGEBIET ist ein massiver Multiplayer-Modus, in dem 24 Spieler gegeneinander antreten und von der KI kontrollierte Verbündete und Gegner das Kampfgeschehen interessant halten.
<G-vec00121-002-s604><compete.antreten><en> During the qualifying tournament, 4 players of a team compete over 2 days with the best 3 results being included in the rankings.
<G-vec00121-002-s604><compete.antreten><de> Beim Qualifikationsturnier treten an 2 Tagen jeweils 4 Spieler einer Mannschaft an, wobei jeweils die 3 besten Resultate in die Wertung kommen.
<G-vec00121-002-s605><compete.antreten><en> Designers compete in five main catégories - beverages, food, body, luxury and other markets - and no fewer than 50 sub-categories. Autre présentation Pentawards
<G-vec00121-002-s605><compete.antreten><de> Die Gestalter treten an in den fünf Hauptkategorien Getränke, Nahrung, Körperpflege, Luxusartikel und Andere Märkte sowie in nicht weniger als 50 Unterkategorien.
<G-vec00121-002-s606><compete.antreten><en> Vancouver’s biggest event sees three countries compete over three evenings in the world’s largest offshore fireworks competition.
<G-vec00121-002-s606><compete.antreten><de> Bei Vancouvers größter Veranstaltung treten drei Länder über drei Abende hinweg beim weltgrößten Feuerwerks-Wettbewerb über Wasser an.
<G-vec00121-002-s607><compete.antreten><en> In a world-first stunt staged in the wild, icy landscape of the Yukon in Canada, stunt driver Debbie Evans, and Evans' Jaguar F-TYPE 5.0 Supercharged V8 R AWD - with the strength of Castrol EDGE - compete against a mixed-reality army of military tanks, nuclear submarines, helicopters, missiles, explosions and shattering ice.
<G-vec00121-002-s607><compete.antreten><de> Bei diesem nie dagewesenen Stunt in der eisigen Wildnis des Yukons in Kanada treten die Stuntfahrerin Debbie Evans und ihr modifizierter Jaguar F-TYPE SVR mit 5,0-Liter-V8-Motor – und der Stärke von Castrol EDGE – gegen eine Mixed-Reality-Armee aus realen und animierten Panzern, Atom-U-Booten, Helikoptern, Raketen, Explosionen und zersplitterndem Eis an.
<G-vec00121-002-s608><compete.antreten><en> In order to motivate these with a particular trigger, a special kind of sales competition was developed: The teams compete in a virtual Formula 1 race against each other on a microsite.
<G-vec00121-002-s608><compete.antreten><de> Um mit einer besonderen Incentiverung zu motivieren, wurde ein Verkaufswettbewerb der besonderen Art veranstaltet: Die Teams treten auf einer Microsite in einem virtuellen Formel 1 Rennen gegeneinander an.
<G-vec00121-002-s609><compete.antreten><en> In eight international teams, the world’s best drone pilots compete against each other and try to steer their custom-made drones through an exciting course as quickly as possible.
<G-vec00121-002-s609><compete.antreten><de> In acht internationalen Teams treten die weltweit besten Drohnenpiloten gegeneinander an und versuchen, ihre selbstgebauten Drohnen schnellstmöglich durch einen aufregenden Parcours zu steuern.
<G-vec00121-002-s610><compete.antreten><en> Fine materials such as silk, wool and cashmere cloth and pony fur compete against tarpaulin, reflector material and embroidered felt.
<G-vec00121-002-s610><compete.antreten><de> Edle Materialien wie Seide, Woll- und Kaschmirtuch und Ponyfell treten an gegen Zeltplane, Reflektorstoff und bestickten Filz.
<G-vec00121-002-s611><compete.antreten><en> The two German finalists, Julian Genesi (German Wizard Champion 2014) and Mareike Mutz (German Vice Champion 2014), have come to Athens, too, and will compete against the international März 2013
<G-vec00121-002-s611><compete.antreten><de> Auch die beiden deutschen Finalisten Julian Genisi (Deutscher Wizard-Meister 2014) und Mareike Mutz (Deutsche Vizemeisterin 2014) sind heute in Athen dabei und treten gegen die internationale Konkurrenz an.
<G-vec00121-002-s612><compete.antreten><en> Compete with other players during tournaments.
<G-vec00121-002-s612><compete.antreten><de> Treten Sie während der Turniere mit anderen Spielern an.
<G-vec00121-002-s613><compete.antreten><en> Starting today the choirs compete in competitions of different categories.
<G-vec00121-002-s613><compete.antreten><de> Ab heute treten die Teilnehmerchören in verschiedenen Wettbewerbskategorien an.
<G-vec00121-002-s614><compete.antreten><en> They have 14 varsity teams and they compete in the Big Sky Conference.
<G-vec00121-002-s614><compete.antreten><de> Die Teams gehören der Big Sky Conference an und treten in den Wettbewerben der NCAA Division I an.
<G-vec00121-002-s615><compete.antreten><en> In Marseille more top athletes from the U.S.A., Australia, Poland, Italy, Sweden, Austria and Great Britain will compete.
<G-vec00121-002-s615><compete.antreten><de> Darüber hinaus treten Topathleten aus den U.S.A., Australien, Polen, Italien, Schweden, Österreich und Großbritannien bei der Champions Trophy in Marseille an.
<G-vec00121-002-s616><compete.antreten><en> ISTAF Managing Director Martin Seeber, „The success story of the ISTAF consists of the same ingredients for over 90 years now: The best German athletes compete against the best in the world.
<G-vec00121-002-s616><compete.antreten><de> ISTAF-Geschäftsführer Martin Seeber: „Das Erfolgsrezept des ISTAF besteht seit über 90 Jahren aus den gleichen Zutaten: Die besten deutschen Athletinnen und Athleten treten gegen die besten der Welt an.
<G-vec00121-002-s617><compete.antreten><en> Four celebrity teams come together to compete against each other in front of an audience: teams North, South, East and West accept the challenge of cooking a four-course barbecue meal in only 150 minutes.
<G-vec00121-002-s617><compete.antreten><de> Vier Promi-Teams treten gegeneinander an: Die Teams Norden, Süden, Osten und Westen nehmen Sie die Herausforderung an, ein Vier-Gänge-Grill-Menü in nur 150 Minuten zuzubereiten.
<G-vec00121-002-s618><compete.antreten><en> The 90 best in Germany compete against each other and this breathtaking event is worth having a look at.
<G-vec00121-002-s618><compete.antreten><de> Die 90 Besten Deutschlands treten gegeneinander an und diese rasanten Rennen sind sicher einen Blick wert.
<G-vec00121-002-s619><compete.antreten><en> Three coaches compete against each other with the task of presenting complex FMEA topics as vividly and entertainingly as possible in 300 seconds.
<G-vec00121-002-s619><compete.antreten><de> Drei Coaches treten mit der Aufgabe gegeneinander an, in 300 Sekunden komplexe Themen rund um FMEA möglichst anschaulich und unterhaltsam vorzutragen.
<G-vec00121-002-s620><compete.antreten><en> At the Prater, 12 teams will compete against each other on creatively redesigned rail trolleys.
<G-vec00121-002-s620><compete.antreten><de> 12 Teams treten im Prater auf kreativ umgestalteten Draisinen in Wettfahrten gegeneinander an.
<G-vec00121-002-s621><compete.antreten><en> Six international teams will compete against each other on three match days.
<G-vec00121-002-s621><compete.antreten><de> Sechs internationale Teams treten an drei Spieltagen gegeneinander an.
<G-vec00121-002-s622><compete.antreten><en> Send Showdown Challenges to compete against friends even when you are not both online.
<G-vec00121-002-s622><compete.antreten><de> Verschicke Showdown Challenges (Showdown-Herausforderungen) und tritt selbst dann gegen deine Freunde an, wenn einer von euch nicht online ist.
<G-vec00121-002-s623><compete.antreten><en> The Team from Aachen to compete in the Challenger category.
<G-vec00121-002-s623><compete.antreten><de> Das Team aus Aachen tritt in der Challenger Kategorie an.
<G-vec00121-002-s624><compete.antreten><en> Compete in over 200 races across 500 stages around the world, including famous Tours such as La Vuelta and the iconic Tour de France.
<G-vec00121-002-s624><compete.antreten><de> Tritt bei über 200 Rennen mit 500 Etappen rund um den Globus an, natürlich auch bei so berühmten Rennen wie La Vuelta und der legendären Tour de France.
<G-vec00121-002-s625><compete.antreten><en> Build your perfect line-up from thousands of players and compete in the most popular mode in FIFA, featuring content from the UEFA Champions League and Europa League.
<G-vec00121-002-s625><compete.antreten><de> Stelle aus Tausenden von Spielern die perfekte Mannschaft zusammen, tritt im populärsten FIFA-Modus an und nutze Inhalte aus UEFA Champions League und UEFA Europa League.
<G-vec00121-002-s626><compete.antreten><en> The winner of this tournament will travel to Addis Ababa next summer to compete against ten regional teams there.
<G-vec00121-002-s626><compete.antreten><de> Der Gewinner dieses Turniers fährt dann im kommenden Sommer nach Addis Abeba und tritt gegen 10 regionale Mannschaften an.
<G-vec00121-002-s627><compete.antreten><en> Win the 2010 FIFA World Cup – Compete as one of 199 teams from qualification right through to a virtual reproduction of the 2010 FIFA World Cup Final.
<G-vec00121-002-s627><compete.antreten><de> Vergrößern Vergrößern Vergrößern Features: * Gewinne die FIFA Fussball-Weltmeisterschaft 2010 — Tritt als eine von 199 Mannschaften von der Qualifikation bis hin zur virtuellen Nachbildung der Endrunde der FIFA Fussball-Weltmeisterschaft 2010 an.
<G-vec00121-002-s628><compete.antreten><en> Dominate the leaderboards – compete against other opponents each Season to see who the ultimate Dragon Lords are and show off with exclusive winner avatars. System Requirements
<G-vec00121-002-s628><compete.antreten><de> Beherrsche die Ranglisten - Tritt zu jeder Jahreszeit gegen andere Gegner an, um zu sehen, wer der beste Drachenlord ist und die exklusiven Gewinner-Avatare vorzuzeigen.
<G-vec00121-002-s629><compete.antreten><en> Compete in challenging new ski and snowboard freestyle events and unlock even more events by playing.
<G-vec00121-002-s629><compete.antreten><de> Tritt in herausfordernden Ski- und Snowboard-Freestyle-Events an und schalte beim Spielen sogar noch mehr Events frei.
<G-vec00121-002-s630><compete.antreten><en> More important, however, the president must compete against not only Capriles, but also cancer.
<G-vec00121-002-s630><compete.antreten><de> Wichtiger jedoch: Der Präsident tritt nicht nur gegen Capriles an, sondern auch gegen seine eigene Krebskrankheit.
<G-vec00121-002-s631><compete.antreten><en> Stake your claim, run your crew, and for a limited time, compete daily for your chance to win 1/8 ounce of real gold*.
<G-vec00121-002-s631><compete.antreten><de> Stecke deinen Claim ab, manage deine Mannschaft und tritt für kurze Zeit täglich um eine Chance an, 1/8 Unze echtes Gold* zu gewinnen.
<G-vec00121-002-s632><compete.antreten><en> The NBA superstar and host will compete with other top athletes against the soccer team of racers founded in 1981.
<G-vec00121-002-s632><compete.antreten><de> Der Weltstar und Gastgeber tritt mit einer illustren Auswahl absoluter Topsportler gegen die 1981 gegründete „Fußball-Nationalmannschaft der Rennfahrer“ an.
<G-vec00121-002-s633><compete.antreten><en> For even more variety activate the complete basic game as well as the add-ons “Cities & Knights” and “Seafarers” as in-app purchases, defend yourself against barbarian invasions, conquer new frontiers, and compete against shrewd computer opponents.
<G-vec00121-002-s633><compete.antreten><de> Für noch mehr Abwechslung schalte das komplette Basisspiel sowie die Erweiterungen „Städte & Ritter“ und „Seefahrer“ als In-App-Kauf frei, wehre dich gegen Barbarenüberfälle, brich zu neuen Ufern auf und tritt gegen gewiefte Computergegner an.
<G-vec00121-002-s634><compete.antreten><en> Hone your skills through four levels of challenging career mode, then compete against the globe in one-on-one matches and multiplayer tournaments.
<G-vec00121-002-s634><compete.antreten><de> Verbessere im herausfordernden Karrieremodus in vier Schwierigkeitsgraden deine Fähigkeiten und tritt dann in Matches für zwei Spieler und Multiplayer-Turnieren gegen den Rest der Welt an.
<G-vec00121-002-s635><compete.antreten><en> TIME TRIAL: compete against your own best performance times, and your rivals’ ghost laps, to set the fastest lap time you possibly can.
<G-vec00121-002-s635><compete.antreten><de> ZEITRENNEN: Tritt gegen die Geisterfahrzeuge deiner eigenen sowie der gegnerischen Rundenbestzeiten an und lege die schnellstmögliche Rundenzeit hin.
<G-vec00121-002-s636><compete.antreten><en> Experiment with different techniques, create your own challenges and compete against your friends—the possibilities are endless.
<G-vec00121-002-s636><compete.antreten><de> Probiere verschiedene Techniken, denk dir eigene Herausforderungen aus und tritt gegen deine Freunde an – es gibt unendlich viele Möglichkeiten.
<G-vec00121-002-s637><compete.antreten><en> Romania will compete in the second semi-final, alongside Switzerland, Sweden, Ireland, Austria, the Republic of Moldova, Latvia, Denmark and Armenia.
<G-vec00121-002-s637><compete.antreten><de> Rumänien tritt gemeinsam mit der Schweiz, Schweden, Irland, Österreich, der Republik Moldau, Lettland, Dänemark und Armenien im zweiten Halbfinale des Wettbewerbs an.
<G-vec00121-002-s638><compete.antreten><en> Collect, play and compete with your favorite UFC fighters.
<G-vec00121-002-s638><compete.antreten><de> Hol dir deine Lieblingskämpfer, passe sie an und tritt mit ihnen an.
<G-vec00121-002-s639><compete.antreten><en> • Compete in time limited events with a new challenge every week.
<G-vec00121-002-s639><compete.antreten><de> • Tritt jede Woche in zeitlich begrenzten Events mit einer neuen Herausforderung an.
<G-vec00121-002-s640><compete.antreten><en> Compete against the computer or your friends in a colorful, comforting environment.
<G-vec00121-002-s640><compete.antreten><de> Tritt gegen den Computer oder deine Freunde an in einer farbenfrohen, stimmungsvollen Umgebung.
<G-vec00121-002-s641><compete.antreten><en> Compete alone or with up to seven friends online and strive to break records as you lead your chosen national squad to victory.
<G-vec00121-002-s641><compete.antreten><de> Tritt alleine oder online mit bis zu sieben Freunden an und versuche, Rekorde zu brechen und mit dem Nationalkader deiner Wahl den Sieg zu holen.
<G-vec00121-002-s642><compete.antreten><en> Choose your own country, and compete in the European tournament.
<G-vec00121-002-s642><compete.antreten><de> Wähle dein eigenes Land aus und tritt in der Europa-Meisterschaft an.
<G-vec00121-002-s643><compete.antreten><en> Compete against over 100 of the best anglers on the planet including Ali Hamidi across Carp, Bass and Predator fishing.
<G-vec00121-002-s643><compete.antreten><de> Tritt an gegen 100 der besten Angler der Welt, darunter Ali Hamidi, im Karpfen-, Barsch- und Raubfisch-Angeln.
<G-vec00121-002-s644><compete.antreten><en> ๏ COMPETE against other players around the world in global tournaments to show off your strength and earn amazing prizes
<G-vec00121-002-s644><compete.antreten><de> ๏ Tritt in globalen Turnieren gegen andere Spieler auf der ganzen Welt an, zeige deine Stärke und gewinne tolle Preise.
<G-vec00121-002-s646><compete.antreten><en> Compete against a friend, a stranger or one of 4 different com- puter players, in what has been called a "two player Solitaire with an extra portion of suspense".
<G-vec00121-002-s646><compete.antreten><de> Tritt an gegen Freunde, Zufallsgegner oder einen von vier verschiedenen Computergegner, in einem Spiel das man als "Zwei-Spieler Solitär mit einer gehörigen Portion Spannung" beschreiben könnte.
<G-vec00121-002-s647><compete.antreten><en> This season BLACK FALCON will compete with five Mercedes-AMG cars and two cars from Porsche.
<G-vec00121-002-s647><compete.antreten><de> In dieser Saison tritt BLACK FALCON mit fünf Fahrzeugen von Mercedes-AMG und zwei Fahrzeugen von Porsche an.
<G-vec00121-002-s648><compete.antreten><en> Compete in a weekly challenge.
<G-vec00121-002-s648><compete.antreten><de> Tritt in einer wöchentlichen Herausforderung an.
<G-vec00121-002-s263><compete.konkurrieren><en> Trade petitions and remedies are blunt and unwieldy policy tools that do nothing to address the underlying issue at hand—the U.S. can’t compete with China and Germany and other clean energy leaders unless it makes an assertive effort to build a more sustainable economy at home and abroad.
<G-vec00121-002-s263><compete.konkurrieren><de> Handelseingaben und Gegenmaßnahmen sind stumpfe und schwerfällige politische Instrumente, die nichts dazu beitragen, das zugrunde liegende Problem anzugehen – die Vereinigten Staaten können mit China, Deutschland und anderen Führern auf dem Gebiet der erneuerbaren Energie nicht konkurrieren, solange sie nicht ausdrückliche Anstrengungen unternehmen, zu Hause und im Ausland eine nachhaltigere Wirtschaft aufzubauen.
<G-vec00121-002-s264><compete.konkurrieren><en> As with all Google Ads, you'll compete with other advertisers to show your ads on placements you select.
<G-vec00121-002-s264><compete.konkurrieren><de> Wie immer bei Werbung mit Google Ads konkurrieren Ihre Anzeigen auch hier mit den Anzeigen anderer Werbetreibender.
<G-vec00121-002-s265><compete.konkurrieren><en> It is hard to disagree with the owners of boarding houses and hotels (especially the small family ones) who complain that they are not able to compete in price competition with rental offers of apartments on such a website as Airbnb.
<G-vec00121-002-s265><compete.konkurrieren><de> Es ist schwer, den Eigentümern von Pensionen und Hotels (insbesondere den kleinen Familien) zu widersprechen, die sich darüber beschweren, dass sie nicht im Preiswettbewerb mit Mietangeboten von Wohnungen auf einer Website wie Airbnb konkurrieren können.
<G-vec00121-002-s266><compete.konkurrieren><en> We are not a manufacturer of cutting tools and therefore do not compete with the products of our customers, as we are a non-competitive supplier.
<G-vec00121-002-s266><compete.konkurrieren><de> Wir sind kein Hersteller von Schneidwerkzeugen und konkurrieren als "non competitive supplier" auch nicht mit den Produkten unserer Kunden.
<G-vec00121-002-s267><compete.konkurrieren><en> The rsyslog project began in 2004, when Rainer Gerhards, the primary author of rsyslog, decided to write a new strong syslog daemon to compete with syslog-ng, because, according to the author, "A new major player will prevent monocultures and provide a rich freedom of choice.
<G-vec00121-002-s267><compete.konkurrieren><de> Das rsyslog-Projekt begann im Jahr 2004, als Rainer Gerhards, der primäre Autor von rsyslog, sich entschied einen neuen und starken Syslog-Daemon zu schreiben, der mit syslog-ng konkurrieren kann, weil, und laut der Aussage des Autors, „Ein neuer Mitspieler eine Monokultur verhindern kann und die Entscheidungsfreiheit sicherstellen werde“.
<G-vec00121-002-s268><compete.konkurrieren><en> Stymied by conflict, poverty, killer diseases and corruption, much of Africa was in no position to compete with richer countries that promised bigger salaries, better working conditions and political stability.
<G-vec00121-002-s268><compete.konkurrieren><de> Konflikte, Armut, tödliche Krankheiten verhinderten, dass Afrika mit reicheren Ländern um Wissensarbeiter konkurrieren könnte, die bessere Löhne, bessere Arbeitsbedingungen und politische Stabilität versprechen können.
<G-vec00121-002-s269><compete.konkurrieren><en> In the surrounding area the Corsican countryside unveils all its treasures: fine sandy beaches, lagoons, lakes and marshes all compete for beauty on this miraculous wild shore.
<G-vec00121-002-s269><compete.konkurrieren><de> In der Umgebung zeigen die korsischen Landschaften den vollen Umfang ihrer Vielfalt: Sandstrände, Lagunen, Teiche und Sümpfe konkurrieren in Schönheit an dieser erstaunlich wilden Küste.
<G-vec00121-002-s270><compete.konkurrieren><en> It is one of the best photo sensors at the moment, the mid-range will therefore be able to compete with the high-end for the quality of the photos.
<G-vec00121-002-s270><compete.konkurrieren><de> Es ist derzeit einer der besten Fotosensoren, daher kann der mittlere Bereich mit dem High-End um die Qualität der Fotos konkurrieren.
<G-vec00121-002-s271><compete.konkurrieren><en> The problem is that Western companies with high social labor standards cannot compete with the "modern slavery" companies from the countries where taxes and wages are lower than in the single market.
<G-vec00121-002-s271><compete.konkurrieren><de> Problematisch ist, dass westliche Unternehmen mit hohen sozialen Arbeitsstandards nicht mit den „modernen Sklavenunternehmen" aus den Ländern konkurrieren können, in denen Steuern und Löhne niedriger sind als im Binnenmarkt.
<G-vec00121-002-s272><compete.konkurrieren><en> With its austerity measures, Germany would like to be able to continue to economically compete with the world powers and forge itself a sufficient economic foundation to be a world power.
<G-vec00121-002-s272><compete.konkurrieren><de> Hintergrund der deutschen Maßnahmen ist das Bemühen, ökonomisch auch weiterhin mit den Weltmächten zu konkurrieren und sich die wirtschaftliche Basis für eine eigene Weltmachtstellung zu erkämpfen.
<G-vec00121-002-s273><compete.konkurrieren><en> Highly successful Jewish mobster gangs, known collectively as the Kosher Mafia, compete with Italian and Irish gangs for control of New York City's underworld.
<G-vec00121-002-s273><compete.konkurrieren><de> Sehr erfolgreiche jüdische Gangsterbanden, unter der Sammelbezeichnung "Koscher-Mafia" bekannt, konkurrieren mit italienischen und irischen Banden um die Kontrolle über die Unterwelt von New-York.
<G-vec00121-002-s274><compete.konkurrieren><en> Of course, the M17x can't compete with a good external sound system, but the given sound is sufficient for various gaming and movie sessions, anyway.
<G-vec00121-002-s274><compete.konkurrieren><de> Mit einer guten externen Anlage kann das M17x natürlich nicht konkurrieren, trotzdem reicht der gebotene Klang für diverse Spiel- und Filmsessions.
<G-vec00121-002-s275><compete.konkurrieren><en> This building should not compete with „Langer Eugen“ in height and position.
<G-vec00121-002-s275><compete.konkurrieren><de> Dieser Schlußpunkt sollte in Höhe und Lage nicht mit dem Langen Eugen konkurrieren.
<G-vec00121-002-s276><compete.konkurrieren><en> All compete in comfort and some even have a real dressing room in the parental room.
<G-vec00121-002-s276><compete.konkurrieren><de> Alle konkurrieren bequem und einige haben sogar eine echte Garderobe im Elternraum.
<G-vec00121-002-s277><compete.konkurrieren><en> The anti¬estrogenic effect of all of these compounds is presumably caused by their ability to compete with other substrates for binding to the aromatase enzyme.
<G-vec00121-002-s277><compete.konkurrieren><de> Die antiöstrogene Wirkung aller dieser Verbindungen ist vermutlich auf ihre Fähigkeit zurückzuführen, mit anderen Substraten um die Bindung an das Aromataseenzym zu konkurrieren.
<G-vec00121-002-s278><compete.konkurrieren><en> Build your private team to compete the superiors in arena.
<G-vec00121-002-s278><compete.konkurrieren><de> Bauen Sie Ihr eigene Team um die Vorgesetzten in der Arena zu konkurrieren.
<G-vec00121-002-s279><compete.konkurrieren><en> No new power plant can compete with that.
<G-vec00121-002-s279><compete.konkurrieren><de> Damit können keine neuen Anlagen konkurrieren.
<G-vec00121-002-s280><compete.konkurrieren><en> Blackjack Tournaments: Tournaments offer players the chance to compete against other players instead of against the house.
<G-vec00121-002-s280><compete.konkurrieren><de> Blackjack-Turniere: Während einem Turnier haben Spieler die Möglichkeit mit anderen Spielern um größere Geldpreise zu konkurrieren.
<G-vec00121-002-s281><compete.konkurrieren><en> Because the World Bank is not by any means determined to compete with the private banks and damage it.
<G-vec00121-002-s281><compete.konkurrieren><de> Denn die Weltbank ist keineswegs gewillt, mit den privaten Banken zu konkurrieren und sie zu schädigen.
<G-vec00121-002-s282><compete.konkurrieren><en> We are one of the few programs in the state where Athletic Training majors can also compete in intercollegiate athletics - giving our students a competitive edge.
<G-vec00121-002-s282><compete.konkurrieren><de> Wir sind eines der wenigen Programme in dem Zustand, in dem Athletic Training Majors auch in intercollegiate Leichtathletik konkurrieren können - unsere Studenten einen Wettbewerbsvorteil verschaffen.
<G-vec00121-002-s283><compete.konkurrieren><en> The company vision is that of reaching the level of excellency in all the aspects of its business by delivering products that can proudly compete with strong brands on both domestic and European markets
<G-vec00121-002-s283><compete.konkurrieren><de> Das Vorhaben der Gesellschaft ist es, für alle Aspekte ihrer Tätigkeit den höchsten Niveau zu erreichen, dadurch dass Sie Produkte liefert, die voller Stolz mit mächtigen Marken von den internen und europäischen Märkten konkurrieren können.
<G-vec00121-002-s284><compete.konkurrieren><en> This helps the local companies/ brands better compete in the market, especially in case of Vietnam's deep integration into the world and regional economy.
<G-vec00121-002-s284><compete.konkurrieren><de> Dies hilft dem lokalen Unternehmen / Marken besser auf dem Markt konkurrieren zu können, vor allem im Falle Vietnams tiefer Integration in die Welt- und Regionalwirtschaft.
<G-vec00121-002-s285><compete.konkurrieren><en> In 1882 American Express expanded into the financial services market by introducing an American Express money order business this was done to compete with the United States Post Offices money orders.
<G-vec00121-002-s285><compete.konkurrieren><de> Im Jahre 1882 expandierte American Express in den Markt für Finanzdienstleistungen durch die Einführung einer American Express Postanweisung um mit den Postanweisungen des Postoffices der Vereinigten Staaten konkurrieren zu können.
<G-vec00121-002-s286><compete.konkurrieren><en> Bids below this are often too low to compete against other advertisers' bids on the same keywords.
<G-vec00121-002-s286><compete.konkurrieren><de> Gebote unterhalb dieses Betrags sind meist zu niedrig, um mit Geboten anderer Inserenten für das gleiche Keyword konkurrieren zu können.
<G-vec00121-002-s287><compete.konkurrieren><en> Older adults that are college graduates and PhD's could never hope to compete with the amount of knowledge that a 15-year-old child of the future will have.
<G-vec00121-002-s287><compete.konkurrieren><de> Ältere Erwachsene mit Uniabschluss und Doktortitel werden nie und nimmer mit der Menge Wissen konkurrieren können, die ein 15-jähriges Kind der Zukunft besitzen wird.
<G-vec00121-002-s288><compete.konkurrieren><en> TN technology can never compete with superior IPS displays in that regard - which is also true for the CX61.
<G-vec00121-002-s288><compete.konkurrieren><de> Technologisch bedingt wird ein TN-Panel in dieser Disziplin nie mit einem hochwertigen IPS-Display konkurrieren können – ein Grundsatz, der sich auch beim CX61 wieder einmal bestätigt.
<G-vec00121-002-s289><compete.konkurrieren><en> Graduates with a degree in translation can have the tools necessary to compete for lucrative and fulfilling careers.
<G-vec00121-002-s289><compete.konkurrieren><de> Absolventen mit einem Abschluss in Übersetzung können die Werkzeuge haben, die notwendig sind, um für lukrative und erfüllende Karrieren konkurrieren zu können.
<G-vec00121-002-s290><compete.konkurrieren><en> With that said, the EU's plan is to work together - although there might be doubts at times - so it's necessary to develop AI in the EU in order to better compete with other powers, which are far ahead.
<G-vec00121-002-s290><compete.konkurrieren><de> Das ursprüngliche Interesse der EU ist jedoch die Zusammenarbeit, weshalb es notwendig ist, die KI innerhalb der EU zu entwickeln, um besser mit den Mächten konkurrieren zu können, die derzeit weit voraus sind.
<G-vec00121-002-s291><compete.konkurrieren><en> British newspaper the Guardian brings a more balanced view on Europe, while the Canadian-owned Reuters focuses on markets, in order to compete with New York’s Bloomberg.
<G-vec00121-002-s291><compete.konkurrieren><de> Die britische Zeitung The Guardian bringt eine ausgewogenere Sicht auf Europa, während sich Reuters, in kanadischem Besitz, auf die Märkte konzentriert, um mit New Yorks Bloomberg konkurrieren zu können.
<G-vec00121-002-s292><compete.konkurrieren><en> This enables merchants to maximize their international sales and to compete on a level playing field with local competitors.
<G-vec00121-002-s292><compete.konkurrieren><de> Dies ermöglicht Händlern, ihre internationalen Verkäufe zu maximieren und unter gleichen Bedingungen mit lokalen Wettbewerbern konkurrieren zu können.
<G-vec00121-002-s293><compete.konkurrieren><en> Ava Devine and Bridgette B compete to see who can suck...
<G-vec00121-002-s293><compete.konkurrieren><de> Ava Devine und Bridgette B konkurrieren um zu sehen, wer kann saugen...
<G-vec00121-002-s294><compete.konkurrieren><en> Select from one of ten individual teams and compete to win the championship.
<G-vec00121-002-s294><compete.konkurrieren><de> Wählen Sie aus einem von zehn einzelnen Teams und konkurrieren um die Meisterschaft zu gewinnen.
<G-vec00121-002-s295><compete.konkurrieren><en> Women now actually compete to show off their miserliness in caring for others, each trying to outdo the rest in proving they are the greatest scrooge with love.
<G-vec00121-002-s295><compete.konkurrieren><de> Frauen konkurrieren heutzutage darum ihre Ablehnung der Betreuung anderer zu zeigen, jede versucht, den Rest zu übertreffen, um zu beweisen, dass sie die größte Liebesgeizhals ist.
<G-vec00121-002-s296><compete.konkurrieren><en> Merging French creativity and Swiss Made, RESERVOIR watches compete in innovation.
<G-vec00121-002-s296><compete.konkurrieren><de> RESERVOIR-Uhren verbinden französische Kreativität mit Swiss Made und konkurrieren um Innovation.
<G-vec00121-002-s297><compete.konkurrieren><en> Projects from different sectors and based on different technologies will compete for government funding.
<G-vec00121-002-s297><compete.konkurrieren><de> Projekte aus unterschiedlichen Sektoren und auf der Basis unterschiedlicher Technologien konkurrieren um staatliche Fördermittel.
<G-vec00121-002-s298><compete.konkurrieren><en> Cities compete for tourists but also for residents, of course.
<G-vec00121-002-s298><compete.konkurrieren><de> Städte konkurrieren um Touristen, aber natürlich auch um Einwohner.
<G-vec00121-002-s299><compete.konkurrieren><en> It can for a certain time fairly compete with the VW Beetle or less collapsed, but then suddenly deeply plunges.
<G-vec00121-002-s299><compete.konkurrieren><de> Sie kann für eine gewisse Zeit mit dem VW-Käfer halbwegs konkurrieren, stürzt aber dann plötzlich um so tiefer.
<G-vec00121-002-s300><compete.konkurrieren><en> We have new cars and we also introduce used cars that will be able to compete with new ones and which are several classes higher.
<G-vec00121-002-s300><compete.konkurrieren><de> Wir haben neue Autos und wir führen auch gebrauchte Autos ein, die mit neuen konkurrieren können und die um einige Klassen höher sind.
<G-vec00121-002-s301><compete.konkurrieren><en> Saving one’s own tooth should be given high priority, therefore, being very often the only way to do so, the endodontic treatment may easily compete with tooth extractions.
<G-vec00121-002-s301><compete.konkurrieren><de> Da die Erhaltung eigener Zähne immer Priorität haben sollte, bleibt die Zahnwurzelbehandlung oftmals die einzige Möglichkeit, die zerstörten oder kranken Zähne zu retten, und konkurriert mit ihrer Entfernung.
<G-vec00121-002-s302><compete.konkurrieren><en> By combining your studies with full-time, paid employment in career-related positions, you will be able to apply what you learn in the classroom, gain related, hands-on experience, network with employers, explore career options and learn how to compete confidently in the job market.
<G-vec00121-002-s302><compete.konkurrieren><de> Wenn Sie Ihr Studium mit einer Vollzeitbeschäftigung in karrierebezogenen Positionen kombinieren, können Sie das, was Sie im Unterricht gelernt haben, anwenden, praktische Erfahrungen sammeln, sich mit Arbeitgebern vernetzen, Karrieremöglichkeiten erkunden und lernen, wie man konkurriert zuversichtlich auf dem Arbeitsmarkt.
<G-vec00121-002-s303><compete.konkurrieren><en> Since the surface of the filtered dirt and the filter surface itself compete with the textiles to be cleaned in regard to the antistatic component, some of the antistatic performance is inevitably lost, but the best possible cleaning effect is still achieved.
<G-vec00121-002-s303><compete.konkurrieren><de> Da die Oberfläche des filtrierten Schmutzes und die Filteroberfläche selbst hinsichtlich der Antistatikkomponente mit den zu reinigenden Textilien konkurriert, verliert man zwangsläufig einen Teil der Antistatikleistung, hat dafür aber den bestmöglichen Reinigungseffekt.
<G-vec00121-002-s304><compete.konkurrieren><en> Salesforce provide various business tools, and as a result can compete with the software heavyweight SAP.
<G-vec00121-002-s304><compete.konkurrieren><de> Als Anbieter verschiedener Unternehmenstools konkurriert Salesforce mit dem Software-Schwergewicht SAP.
<G-vec00121-002-s305><compete.konkurrieren><en> Difficult maybe, as each individual has to compete in their own working environment, yet necessary.
<G-vec00121-002-s305><compete.konkurrieren><de> Dies ist möglicherweise schwierig, da jeder mit seinem eigenen Arbeitsumfeld konkurriert, doch es ist notwendig.
<G-vec00121-002-s306><compete.konkurrieren><en> Compete with the faction shipyards by selling ships to the war factions or build your own fleets.
<G-vec00121-002-s306><compete.konkurrieren><de> Konkurriert mit Fraktionschiffswerften, indem ihr Schiffe an die Kriegsfraktionen verkauft oder eigene Flotten baut.
<G-vec00121-002-s307><compete.konkurrieren><en> In line with the launch, the Hager team organised a competition where customers had to compete to see who could install the socket in the fastest time.
<G-vec00121-002-s307><compete.konkurrieren><de> Passend dazu organisierten die Kollegen einen Wettbewerb, bei dem die Kunden um die schnellste Zeit zur Installation der Steckdose konkurriert haben.
<G-vec00121-002-s308><compete.konkurrieren><en> TTC TELEPORT does not compete with its customers.
<G-vec00121-002-s308><compete.konkurrieren><de> TTC TELEPORT konkurriert nicht mit seinen Kunden.
<G-vec00121-002-s309><compete.konkurrieren><en> The XL-teaser shows how these two rappers compete with, against, and within various growing markets in Ghana, including new churches like the Alive Chapel International and mobile phone companies like Glo Mobile.
<G-vec00121-002-s309><compete.konkurrieren><de> Der XL-Teaser (gefilmt in 6 Drehtagen in Accra) zeigt, wie das Rapper Duo FOKN Bois mit und gegen schnelle wachsende Märkte in Ghana konkurriert: mit den omnipräsenten Neukirchen wie der «Alive Chapel International» oder mit aufstrebenden Mobil-Phone-Firmen wie «Glo Mobile».
<G-vec00121-002-s388><compete.konkurrieren><en> Trademark protection can only be achieved in most countries by formally registering it, though up to three different trademark systems compete against each others in certain countries, though these systems may be combined.
<G-vec00121-002-s388><compete.konkurrieren><de> Ein Markenschutz kann in den meisten Ländern nur durch eine formale Registrierung der Marke erreicht werden, wobei in vielen Ländern bis zu drei unterschiedliche Markensysteme miteinander konkurrieren, aber auch miteinander kombiniert werden können.
<G-vec00121-002-s389><compete.konkurrieren><en> We also observe that correspondingly different types of legitimation and legitimacy of supranational orders compete with each other.
<G-vec00121-002-s389><compete.konkurrieren><de> Auch stellen wir fest, dass entsprechend verschiedene Typen der Legitimation und Legitimität überstaatlicher Ordnungen miteinander konkurrieren.
<G-vec00121-002-s390><compete.konkurrieren><en> At the event, these young innovators share ideas, showcase cutting-edge research, and compete for more than USD 4 million in awards and scholarships. Rewarding Scientific Discovery and Innovation
<G-vec00121-002-s390><compete.konkurrieren><de> Bei dieser Feier können sich junge, innovative Menschen austauschen, topaktuelle Forschungsprojekte vorstellen und miteinander um mehr als $ 5 Millionen an Preisgeldern und Stipendien konkurrieren.
<G-vec00121-002-s391><compete.konkurrieren><en> In 1996 the United States government selected Lockheed Martin and Boeing to each develop Evolved Expendable Launch Vehicles (EELV) to compete for launch contracts and provide assured access to space.
<G-vec00121-002-s391><compete.konkurrieren><de> 1996 wählte die amerikanische Regierung Lockheed Martin und Boeing aus, damit jedes Unternehmen sogenannte Evolved Expendable Launch Vehicles (EELV, weiterentwickelte Einwegstartfahrzeuge) entwickelte, um für Startaufgaben miteinander zu konkurrieren und um einen sicheren Zugang zum Weltraum zu schaffen.
<G-vec00121-002-s392><compete.konkurrieren><en> As the aforesaid areas are united in one territory and border each other, one of the most important tasks is to achieve is that they do not compete, but rather supplement each other.
<G-vec00121-002-s392><compete.konkurrieren><de> Da die genannten Bereiche in einem Territorium zusammengefasst sind und aneinander angrenzen, war es eine der wichtigsten Aufgaben, dass diese nicht miteinander konkurrieren, sondern einander ergänzen.
<G-vec00121-002-s393><compete.konkurrieren><en> Junior golfers can compete in a world-class player field and grow into the professional golf world.
<G-vec00121-002-s393><compete.konkurrieren><de> Junior-Golfspieler/innen können in einem Weltklasse-Umfeld miteinander konkurrieren und in die professionelle Golfsportwelt hineinwachsen.
<G-vec00121-002-s394><compete.konkurrieren><en> You will also discover the quieter backstreets and the contrade, the 17 city districts which date back to the Middle Ages and compete every year in the two days of the Palio.
<G-vec00121-002-s394><compete.konkurrieren><de> Ihr Reiseleiter wird Sie auch in die ruhigen Gassen bringen und Ihnen alles über die Contrade erzählen - das sind die 17 Stadtbezirke, die seit dem Mittelalter jedes Jahr in den zwei Tagen des Palio miteinander konkurrieren.
<G-vec00121-002-s395><compete.konkurrieren><en> Backgammon tournaments bring fun and excitement to people around the globe, allowing professional and amateur enthusiasts to compete with one another in a geographically boundless environment.
<G-vec00121-002-s395><compete.konkurrieren><de> Backgammon Turniere bringen Spaß und Spannung für Menschen rund um den Globus, so dass Profi-und Amateur-Enthusiasten miteinander in einer geographisch unbegrenzten Umfeld konkurrieren.
<G-vec00121-002-s396><compete.konkurrieren><en> Only then can energy providers freely compete and provide the best energy prices.
<G-vec00121-002-s396><compete.konkurrieren><de> Das ist die Voraussetzung dafür, dass die Energieversorger frei miteinander konkurrieren und die besten Preise anbieten können.
<G-vec00121-002-s397><compete.konkurrieren><en> We are dealing here with structures on several levels and of varying sizes that mutually comment on and compete with one another.
<G-vec00121-002-s397><compete.konkurrieren><de> Wir haben Strukturen auf verschiedenen Ebenen vor uns und von verschie dener Größenordnung, die sich gegenseitig kommentieren und miteinander konkurrieren.
<G-vec00121-002-s668><compete.konkurrieren><en> The result is: if both brain hemispheres compete for control, the left hemisphere is able to delay the activity of neurons in the right hemisphere.
<G-vec00121-002-s668><compete.konkurrieren><de> Das Ergebnis: Wenn die beiden Hirnhälften um die Kontrolle konkurrieren, kann die linke Hemisphäre die Aktivität von Neuronen in der rechten Hemisphäre verzögern.
<G-vec00121-002-s669><compete.konkurrieren><en> Testo wanted to have the ability to comprehensively plan and manage these projects, some of which stand independently and compete for resources.
<G-vec00121-002-s669><compete.konkurrieren><de> Bei Testo wollte man eine übergreifende Planung und Verwaltung dieser Projekte, die teils in Abhängigkeiten stehen und um Ressourcen konkurrieren.
<G-vec00121-002-s670><compete.konkurrieren><en> The agrégation is a notoriously difficult civil service exam through which students from all over France compete for a teaching position within the enormous government body of the national education.
<G-vec00121-002-s670><compete.konkurrieren><de> Die agrégation ist eine berühmte schwierige Prüfung des öffentlichen Dienstes, durch welche Studenten aus ganz Frankreich um eine Lehrstelle innerhalb der gewaltigen Regierungsbehörde der nationalen Bildung konkurrieren.
<G-vec00121-002-s671><compete.konkurrieren><en> After the sun goes down, the riders take to the streets to compete with each other, taking part in illegal tournaments.
<G-vec00121-002-s671><compete.konkurrieren><de> Nachdem die Sonne untergegangen ist, nehmen die Reiter auf die Straße, um miteinander zu konkurrieren und an illegalen Turnieren teilzunehmen.
<G-vec00121-002-s672><compete.konkurrieren><en> Since the body’s own hormones and the secondary plant substances compete for the binding sites on the receptors in the body, the phytohormones are able to weaken – as well as strengthen – the effect of the body’s own hormones.
<G-vec00121-002-s672><compete.konkurrieren><de> Da sowohl das körpereigene Hormon als auch die sekundären Pflanzenstoffe um die Bindungsstellen der Rezeptoren im Körper konkurrieren, können die Phytohormone die Wirkung der körpereigenen Hormone nicht nur verstärken, sondern auch abschwächen.
<G-vec00121-002-s673><compete.konkurrieren><en> Not only is there not enough cultivable land, but other energy carriers such as biogas, vegetable oils and the methyl ester or rapeseed oil will compete for the available cultivable land.
<G-vec00121-002-s673><compete.konkurrieren><de> Dafür steht jedoch zu wenig Anbaufläche zur Verfügung, gleichzeitig werden andere Bioenergieformen wie Biogas, Pflanzenöle, Rapsölmethylester um diese Anbauflächen konkurrieren.
<G-vec00121-002-s674><compete.konkurrieren><en> On this basis, it can be concluded which molecules cause reduction, when competing adsorption takes place, i.e. if several substances compete for adsorption on catalytic converters, and how individual molecules coordinate on the metal atom. A group of researchers headed by Professor Jan-Dierk Grunwaldt, Professor Christoph R. Jacob, who recently moved from KIT to TU Braunschweig, and Dr. Pieter Glatzel at the European Synchrotron Radiation Facility (ESRF) in Grenoble / France now for the first time have combined the above methods to study under close-to-reality conditions reactions on two catalytically active materials applied in vehicles, namely Fe-ZSM-5 and Cu-SSZ-13.
<G-vec00121-002-s674><compete.konkurrieren><de> So lässt sich erschließen, welche Moleküle zur Reduktion führen, wann eine konkurrierende Adsorption stattfindet, das heißt, wann mehrere Stoffe um die Anlagerung am Katalysator konkurrieren, und wie einzelne Christoph R. Jacob, der kürzlich vom KIT an die TU Braunschweig berufen wurde, und Dr. Pieter Glatzel von der European Synchrotron Radiation Facility (ESRF) in Grenoble/Frankreich hat nun erstmals beide Methoden kombiniert, um die Reaktionen an zwei bereits in Fahrzeugen eingesetzten katalytisch aktiven Materialien unter realitätsnahen Bedingungen zu untersuchen.
<G-vec00121-002-s675><compete.konkurrieren><en> The online market is overflowing with cheap products that all look identical. While different suppliers compete on price, at Peak Art we are going in the other direction.
<G-vec00121-002-s675><compete.konkurrieren><de> Während der Online-Markt mit billigen Produkten aus der Fabrik überschwemmt wird, die alle gleich aussehen, und verschiedene Hersteller um den günstigsten Preis konkurrieren, gehen wir bei Peak Art in die andere Richtung.
<G-vec00121-002-s676><compete.konkurrieren><en> Beyond its estimated more than USD $250 billion in retail sales volume, its dominant and highly profitable Web services business, and its growing advertising business, Amazon announced just this year that it would form a health care consortium, launch a delivery service to compete with the top national shippers, sell medical supplies to hospitals and clinics, offer discounted memberships to Medicaid recipients, and purchase Ring, the smart doorbell company.
<G-vec00121-002-s676><compete.konkurrieren><de> Über das geschätzte Umsatzvolumen von mehr als 250 Milliarden US-Dollar im Einzelhandel, das dominante und hochprofitable Webservice-Business und das wachsende Werbegeschäft hinaus kündigte Amazon gerade an, das Unternehmen plane die Gründung eines Gesundheitskonsortiums sowie einen Lieferservice, um mit den führenden inländischen Versandhäusern zu konkurrieren.
<G-vec00121-002-s677><compete.konkurrieren><en> As will become clear in the following, in rereading the old stories and in summoning back their moving images, however, it is not solely an issue of the prehistory or early history of reproductive technologies, which compete with the biological (and sexual) reproduction of human life.
<G-vec00121-002-s677><compete.konkurrieren><de> In den Re-Lektüren der alten Geschichten und im Wiederaufruf ihrer bewegenden Bilder geht es jedoch nicht allein um eine Vor- und Frühgeschichte der Reproduktionstechnologien, die mit der biologischen (und sexuellen) Re-Produktion menschlichen Lebens konkurrieren, wie im Folgenden deutlich werden soll.
<G-vec00121-002-s678><compete.konkurrieren><en> The thesis also shows that glutamate receptors compete for synaptic anchoring sites in postsynaptic densities.
<G-vec00121-002-s678><compete.konkurrieren><de> Diese Arbeit zeigt auch, das Glutamatrezeptoren um synaptische Ankerplätze miteinander konkurrieren.
<G-vec00121-002-s679><compete.konkurrieren><en> If you’re paying to compete in Bingo on the internet, look for well-known sites.
<G-vec00121-002-s679><compete.konkurrieren><de> Wenn Sie zahlen, um in Bingo auf dem Internet konkurrieren, suchen nach bekannten Standorten.
<G-vec00121-002-s680><compete.konkurrieren><en> Altogether, from over 2.000 entries, as well as films seen at festivals in Locarno, Venice, Barcelona, Rotterdam and Berlin, 25 films from 16 countries were chosen to compete for the Wiener Kurzfilmpreis and the audience award.
<G-vec00121-002-s680><compete.konkurrieren><de> Aus mehr als 2.000 Einreichungen sowie auf Festivals in Locarno, Venedig, Barcelona, Rotterdam und Berlin gesichteten Filmen wurden insgesamt 25 Filme aus 16 Ländern ausgewählt, die um den Wiener Kurzfilmpreis und den Publikumspreis konkurrieren.
<G-vec00121-002-s681><compete.konkurrieren><en> There may be less diversity if lesser-known publishers cannot rely on aggregators to reach new audiences and compete with the big players on a level playing field.
<G-vec00121-002-s681><compete.konkurrieren><de> Die Vielfalt könnte abnehmen, wenn weniger bekannte Verlage sich nicht mehr auf Aggregatoren verlassen können, um neue Zielgruppen zu erreichen und um auf Augenhöhe mit den Großen zu konkurrieren.
<G-vec00121-002-s682><compete.konkurrieren><en> The competition is aimed at cooking schools throughout the country, which select their best students to represent them throughout a weekend where young aspiring chefs compete for important cash prizes & work contracts.
<G-vec00121-002-s682><compete.konkurrieren><de> Der Wettbewerb richtet sich an alle Kochschulen des Landes, die ihre besten Schüler auswählen, damit diese sie an einem ganzen Wochenende vertreten und bei denen die jungen, aufstrebenden Köche um Geldpreise und bedeutende Arbeitsverträge konkurrieren.
<G-vec00121-002-s683><compete.konkurrieren><en> So long as workers are forced to fight against one another for jobs and compete for wages, whether through the provisions of NAFTA or through trade wars, living standards across the region will continue to fall.
<G-vec00121-002-s683><compete.konkurrieren><de> Solange Arbeiter gezwungen sind, um Arbeitsplätze und um Löhne zu konkurrieren, sei es unter dem NAFTA-Freihandelsabkommens oder durch Handelskriege, wird der Lebensstandard in der ganzen Region weiterhin sinken.
<G-vec00121-002-s684><compete.konkurrieren><en> New players are invited to try out the free poker download and compete for a share of the prizes in The Grand Battle.
<G-vec00121-002-s684><compete.konkurrieren><de> Neue Spieler sind eingeladen den kostenlosen Poker-Download zu probieren und um einen Anteil der Gewinne von The Grand Battle zu konkurrieren.
<G-vec00121-002-s685><compete.konkurrieren><en> These countries have begun to compete with each other, seeking foreign investment at any cost.
<G-vec00121-002-s685><compete.konkurrieren><de> Die Länder wurden dazu gebracht, untereinander um ausländische Investitionen zu konkurrieren, koste es was es wolle.
<G-vec00121-002-s686><compete.konkurrieren><en> You will be able to choose low limit rooms or high limit rooms to compete at in.
<G-vec00121-002-s686><compete.konkurrieren><de> Sie können wählen Low-Limit Räume oder High Limit Zimmer, um zu konkurrieren in.
<G-vec00121-002-s310><compete.kämpfen><en> The weather is sparkling as you compete with the other cyclists (and a skier or two).
<G-vec00121-002-s310><compete.kämpfen><de> Sie kämpfen bei strahlendem Sonnenschein mit den anderen Radfahrern (und einem oder zwei Skifahrern).
<G-vec00121-002-s311><compete.kämpfen><en> So, when adenosine has to compete for receptors with caffeine molecules, its ability to cause drowsiness is decreased.
<G-vec00121-002-s311><compete.kämpfen><de> Wenn also das Adenosin mit Koffeinmolekülen um die Rezeptoren kämpfen muss, sinkt seine Fähigkeit, uns schläfrig zu machen.
<G-vec00121-002-s312><compete.kämpfen><en> Feel belonging to the aristocratic game of favorites and compete for the longest shot in the first Golf club in Western Europe.
<G-vec00121-002-s312><compete.kämpfen><de> Fühlen Sie sich dem aristokratischen Favoritenspiel verbunden und kämpfen Sie um den längsten Wurf im ersten Golfclub in Westeuropa.
<G-vec00121-002-s313><compete.kämpfen><en> At Genan, we are proud to have supplied shock-absorbing rubber granulate for some of the pitches, where some of the best athletes in the world will soon compete for medals.
<G-vec00121-002-s313><compete.kämpfen><de> Wir bei Genan sind stolz darauf, für einige Felder stoßdämpfende Gummigranulate geliefert zu haben, auf denen weltbeste Athleten bald um Medaillen kämpfen werden.
<G-vec00121-002-s314><compete.kämpfen><en> In the game of Rummy 500 players compete against each other over multiple rounds to be the first to attain a score of 500 points or above.
<G-vec00121-002-s314><compete.kämpfen><de> Beim Rommé 500 kämpfen Spieler über mehrere Runden hinweg darum, eine Punkteanzahl von mindestens 500 zu erreichen.
<G-vec00121-002-s315><compete.kämpfen><en> 12 Teams from across the world will finally converge at the World Championship Finals later this year, where they'll compete for their share of a $280,000 prize pool.
<G-vec00121-002-s315><compete.kämpfen><de> Am Ende werden zwölf Teams aus der ganzen Welt beim Finale der World Championship aufeinandertreffen und um ihren Anteil am Preispool von 280.000 USD kämpfen.
<G-vec00121-002-s316><compete.kämpfen><en> The pulsating heart of traditional Marrakech, the Djemaa el Fna, comes to life at sunset when story tellers, musicians, snake charmers, fire-eaters and acrobats and, not least, scores of street food sellers, compete for the attention of hundreds of tourists and locals alike.
<G-vec00121-002-s316><compete.kämpfen><de> Das pulsierende Herz des traditionellen Marrakesch, der Jemaa el Fna, erwacht bei Sonnenuntergang zum Leben, wenn Geschichtenerzähler, Musikanten, Schlangenbeschwörer, Feuerschlucker und Akrobaten und nicht zuletzt jede Menge Street Food-Verkäufer um die Aufmerksamkeit von Hunderten von Touristen und Einheimischen kämpfen.
<G-vec00121-002-s317><compete.kämpfen><en> Top players from all over the world compete for the title and prize money right in the heart of Gstaad against a fabulous backdrop of mountains and chalets.
<G-vec00121-002-s317><compete.kämpfen><de> Topspieler aus der ganzen Welt kämpfen mitten in Gstaad vor traumhafter Berg- und Chaletkulisse um Titel und Preisgelder.
<G-vec00121-002-s318><compete.kämpfen><en> When crickets breed in a very confined space, they actually eat one another so that there are fewer crickets to compete for resources.
<G-vec00121-002-s318><compete.kämpfen><de> Wenn die Grillen in einer sehr beschränkten Umgebung gehalten werden, fressen sie einander und es bleiben weniger Grillen, die um den Platz kämpfen.
<G-vec00121-002-s319><compete.kämpfen><en> Matchmaking (MMR), Team, and Personal Ratings have been reset and players are once again able to compete in level-85 Arenas and Rated Battlegrounds for the best PvP gear, items, and titles.
<G-vec00121-002-s319><compete.kämpfen><de> Team- und persönliche Wertungen wurden zurückgesetzt und die Spieler haben nun die Möglichkeit, in Stufe-90-Arenen und auf gewerteten Schlachtfeldern um Gegenstände, Titel und die beste PvP-Ausrüstung zu kämpfen.
<G-vec00121-002-s320><compete.kämpfen><en> Both players should release the ball carrier as soon as possible, get back to their feet and compete for the ball
<G-vec00121-002-s320><compete.kämpfen><de> Beide Spieler sollten den Ballbesitzer schnellstmöglich freigeben, wieder aufstehen und um den Ballbesitz kämpfen.
<G-vec00121-002-s321><compete.kämpfen><en> Larry is in great shape, but towering Kassidy has immense reach, great strength and simply loves to compete.
<G-vec00121-002-s321><compete.kämpfen><de> Larry ist in großartiger Verfassung, aber die überragende Kassidy hat eine enorme Reichweite, viel Kraft und liebt es einfach zu kämpfen.
<G-vec00121-002-s322><compete.kämpfen><en> Europa-Park Arena Spectacular moves and breathtaking action – watch Germany’s best skaters when they compete for the Club of Skaters Championship at Europa-Park.
<G-vec00121-002-s322><compete.kämpfen><de> Spektakuläre Moves und atemberaubende Action – die besten Skateboarder Deutschlands kämpfen beim Club of Skaters Cup in der neuen Europa-Park Arena um die Deutsche Skateboardmeisterschaft.
<G-vec00121-002-s323><compete.kämpfen><en> Even Germany, as an export nation, has to compete for shares on its sales markets.
<G-vec00121-002-s323><compete.kämpfen><de> Selbst die Exportnation Deutschland muss um Anteile auf ihren Absatzmärkten kämpfen.
<G-vec00121-002-s324><compete.kämpfen><en> Billionaire Bitcoin investor Tim Draper commented last year, “Governments have to compete for us.
<G-vec00121-002-s324><compete.kämpfen><de> Der Bitcoin-Milliardär und Investor Tim Draper sagte letztes Jahr: „Regierungen müssen um uns kämpfen.
<G-vec00121-002-s325><compete.kämpfen><en> Companies that have not been active in the automobile industry in the past, or that have only played a peripheral role, will compete for the increased market volume.
<G-vec00121-002-s325><compete.kämpfen><de> Um das höhere Marktvolumen werden Unternehmen kämpfen, die bislang nicht oder nur am Rande in der Automobilindustrie aktiv waren.
<G-vec00121-002-s326><compete.kämpfen><en> 152 professional racers are awaiting the starting signal of this year’s challenging Tour de Suisse as they compete for the brand-new trophy: “The Hour Glass”.
<G-vec00121-002-s326><compete.kämpfen><de> Profirennfahrer warten auf den Startschuss der diesjährigen, herausfordernden Tour de Suisse und kämpfen um den brandneuen Pokal «The Hour Glass».
<G-vec00121-002-s327><compete.kämpfen><en> Up to 50 teams compete for the $50 prize pool.
<G-vec00121-002-s327><compete.kämpfen><de> Bis zu 50 Teams kämpfen um das Preisgeld in Höhe von 50 US-Dollar.
<G-vec00121-002-s328><compete.kämpfen><en> Today, more than 200 university teams compete for the title League of Legends University Champion.
<G-vec00121-002-s328><compete.kämpfen><de> Mittlerweile kämpfen bereits über 200 Hochschulteams um den Titel des League of Legends Hochschulmeisters.
<G-vec00121-002-s687><compete.kämpfen><en> During this run, there will be a corporate challenge where companies/teams will compete for prizes.
<G-vec00121-002-s687><compete.kämpfen><de> Beim 5-km-Lauf wird es eine Corporate Challenge geben, bei der Unternehmen / Teams um Preise kämpfen.
<G-vec00121-002-s688><compete.kämpfen><en> 21 elite SEs selected from around the world gathered at the company's Hamamatsu HQ to compete for the world championship title by demonstrating the abilities and knowledge cultivated in their daily work through problem-solving trials and written exams.
<G-vec00121-002-s688><compete.kämpfen><de> Zwanzig Elite-Techniker, die aus der ganzen Welt ausgewählt wurden, versammelten sich in der Unternehmenszentrale in Hamamatsu, um für den Weltmeistertitel zu kämpfen, indem sie ihre Fähigkeiten und Kenntnisse durch Problemlösungsversuche und schriftliche Prüfungen unter Beweis stellten.
<G-vec00121-002-s689><compete.kämpfen><en> “EKS Audi Sport” has ambitious plans for the upcoming World RX season: “With the intensified support, also by Sonax, we will compete for victories and the World Championship title in both the driver and the team rankings,” Mattias Ekström said at the team introduction in Silverstone.
<G-vec00121-002-s689><compete.kämpfen><de> Für die bevorstehende World-RX-Saison hat sich „EKS Audi Sport“ viel vorgenommen: „Mit verstärkter Unterstützung auch von Sonax werden wir um Siege und um die WM-Titel in der Fahrer- und der Teamwertung kämpfen“, sagte Mattias Ekström im Rahmen der Teamvorstellung.
<G-vec00121-002-s690><compete.kämpfen><en> Participation is open to players at all playing levels, from elite to amateur, and several of the world’s top players will be taking part to represent their continent and compete to win the third Bainbridge Cup trophy.
<G-vec00121-002-s690><compete.kämpfen><de> Die Teilnahme steht Spielern aller Spielstufen offen, von der Elite bis zum Amateur, und mehrere der weltbesten Spieler werden teilnehmen, um ihren Kontinent zu vertreten und um die dritte Bainbridge Cup-Trophäe zu kämpfen.
<G-vec00121-002-s691><compete.kämpfen><en> The best teams in Europe and CIS will compete for the $5,000 prize pool.
<G-vec00121-002-s691><compete.kämpfen><de> Die besten Teams aus Europa und den GUS-Staaten werden um ein Preisgeld in Höhe von 5.000 US-Dollar kämpfen.
<G-vec00121-002-s692><compete.kämpfen><en> With this change, we hope to provide a fun and balanced championship for beginners to have competitive experience and compete for valuable in-game rewards, while ensuring that veterans have their own high-level environment playing for money.
<G-vec00121-002-s692><compete.kämpfen><de> Mit dieser Änderung hoffen wir, Anfängern eine unterhaltsame und ausgewogene Meisterschaft bieten zu können, um Wettbewerbs-Erfahrung zu sammeln und um wertvolle Belohnungen im Spiel zu kämpfen, während gleichzeitig sichergestellt wird, dass Veteranen ihre eigene Umgebung auf hohem Niveau haben, die um Geld spielt.
<G-vec00121-002-s693><compete.kämpfen><en> Up to 8 players can compete for dominance of a new alien world.
<G-vec00121-002-s693><compete.kämpfen><de> Multiplayer: Bis zu acht Spieler können um die Herrschaft über eine neue fremde Welt kämpfen.
<G-vec00121-002-s336><compete.messen><en> Travel to the mythological age of feudal Japan and compete with many other players in the quest to become Shogun.
<G-vec00121-002-s336><compete.messen><de> Reise ins mythologische Zeitalter des feudalen Japans und messe dich mit vielen anderen Spielern beim Versuch, Shogun zu werden.
<G-vec00121-002-s337><compete.messen><en> Compete with other players or with embedded powerful artificial intelligence.
<G-vec00121-002-s337><compete.messen><de> Messe dich mit anderen Spielern oder der eingebauten leistungsfähigen künstlichen Intelligenz.
<G-vec00121-002-s338><compete.messen><en> Check out this award-winning MIDDLE AGES STRATEGY GAME and compete against MILLIONS of other players!Play Empire: Four Kingdoms now and discover far away countries and continents.
<G-vec00121-002-s338><compete.messen><de> Spiele das ausgezeichnete MITTELALTER-STRATEGIESPIEL und messe Dich mit MILLIONEN von anderen Spielern!Spiele jetzt Empire: Four Kingdoms und entdecke ferne Länder und Kontinente.
<G-vec00121-002-s339><compete.messen><en> Drive a huge variety of cars and compete in a series of action-packed challenges.
<G-vec00121-002-s339><compete.messen><de> Fahre eine unglaubliche Bandbreite von Autos und messe dich in zahlreichen actiongeladenen Challenges.
<G-vec00121-002-s340><compete.messen><en> Compete with your friends and find out what pictures really move the world.
<G-vec00121-002-s340><compete.messen><de> Messe dich mit deinen Freunden und finde heraus, welche Bilder die Welt wirklich bewegen.
<G-vec00121-002-s341><compete.messen><en> Be a member of national team and compete with other players all over the world.
<G-vec00121-002-s341><compete.messen><de> Sei ein Mitglied deines nationalen Teams und messe dich mit Spielern auf der ganzen Welt.
<G-vec00121-002-s342><compete.messen><en> An additional highlight aside from the numerous tournaments are the institute olympiads, where different institutes and institutions of the Aachen universities compete in exciting disciplines.
<G-vec00121-002-s342><compete.messen><de> Ein weiteres Highlight ist neben den zahlreichen Turnieren die Institutsolympiade, bei der sich die verschiedenen Institute und Einrichtungen der Aachener Hochschulen in spannenden Disziplinen messen.
<G-vec00121-002-s343><compete.messen><en> Imagine you have a HUGE SHOPPING CENTRE AT YOUR DISPOSAL, with a variety of products that can compete with any decent offline shopping center.
<G-vec00121-002-s343><compete.messen><de> Stellen Sie sich vor, SIE verfügen über ein riesiges eigenes Kaufhaus, dessen Produktvielfalt sich mit jedem guten Offline-Kaufhaus messen kann.
<G-vec00121-002-s344><compete.messen><en> With new tracks and more ways to compete, Trials® Rising is easy to pick-up and play, challenging to master and offers the best multiplayer racing experience.
<G-vec00121-002-s344><compete.messen><de> Mit neuen Strecken und noch mehr Möglichkeiten, sich zu messen, ist Trials® Rising leicht zu lernen und schwer zu meistern und bietet ein intensives Mehrspieler-Rennerlebnis.
<G-vec00121-002-s345><compete.messen><en> He has not only managed to understand the events of his time and to compete with the best, he was a visionary of his time.
<G-vec00121-002-s345><compete.messen><de> Er hat es nicht nur geschafft die Geschehnisse seiner Zeit zu verstehen und sich mit den Besten zu messen, er war ein Visionär seiner Zeit.
<G-vec00121-002-s346><compete.messen><en> The Crowhill Cabin isn't trying to compete with its landscape.
<G-vec00121-002-s346><compete.messen><de> Die Crowhill Cabin will sich keineswegs mit ihrer Landschaft messen.
<G-vec00121-002-s347><compete.messen><en> At least 30 tons of sand will be brought in to the square in order to create the competition areas, upon which the best pétanque teams will compete.
<G-vec00121-002-s347><compete.messen><de> Beträchtliche 30 Tonnen Sand werden auf dem Platz verteilt, um die Spielflächen für die Wettbewerbe herzurichten, auf denen die besten Teams ihre Kräfte messen werden.
<G-vec00121-002-s348><compete.messen><en> Quality improvement… to compete with your competitors and thereby improve their quality capability.
<G-vec00121-002-s348><compete.messen><de> Qualitätsverbesserung… sich an Ihren Wettbewerbern zu messen und dadurch ihre Qualitätsfähigkeit zu verbessern.
<G-vec00121-002-s349><compete.messen><en> Catan Championships Many players enjoy playing games for fun, but they also desire to compete against the best opponents.
<G-vec00121-002-s349><compete.messen><de> Norderwind Meisterschaften Viele Spieler wollen Spiele nicht nur einfach zum Spaß spielen sondern sich auch mit den besten Spielern messen.
<G-vec00121-002-s350><compete.messen><en> The Trixie Reptiland Reptile Rain irrigation system can also compete with the best equipment on the market when it comes to other equipment.
<G-vec00121-002-s350><compete.messen><de> Auch was die sonstige Ausstattung angeht, kann sich die Trixie Reptiland Reptile Rain Beregnungsanlage mit den besten Geräten am Markt messen.
<G-vec00121-002-s351><compete.messen><en> Any more expensive property on Mallorca must be able to compete with our houses.
<G-vec00121-002-s351><compete.messen><de> Jedes teuere Objekt auf Mallorca muss sich mit unseren Häusern messen können.
<G-vec00121-002-s352><compete.messen><en> Park Huidenvettersplein As far as size goes Huidenvettersplein (Tanners Square) cannot compete with the Market and Burg, but the tiny square which is enclosed by restaurants is pleasantly adorned by the presence of artists.
<G-vec00121-002-s352><compete.messen><de> Park Huidenvettersplein Der Huidenvettersplein (Gerberplatz) kann sich aufgrund seiner Größe zwar nicht mit dem gleich um die Ecke liegenden Marktplatz und Burg messen, die Anwesenheit von Künstlern stellt jedoch eine angenehme Bereicherung des gemütlichen, von Restaurants umgebenen Platzes dar.
<G-vec00121-002-s353><compete.messen><en> We love the challenge to compete with our project partners.
<G-vec00121-002-s353><compete.messen><de> Wir lieben die sportliche Herausforderung uns mit den Projektpartnern zu messen.
<G-vec00121-002-s354><compete.messen><en> "All I can do is to fight every opponent who gets into my way, to always compete with the best and thus being the best champion possible.
<G-vec00121-002-s354><compete.messen><de> „Alles, was ich tun kann, ist, jeden Gegner, der sich mir in den Weg stellt, zu schlagen, mich ständig mit den Besten zu messen und somit der beste Champion zu sein, der ich eben sein kann.
<G-vec00121-002-s355><compete.messen><en> With this commitment to Total Quality Management we compete on the market.
<G-vec00121-002-s355><compete.messen><de> Mit dem Bekenntnis zu Total Quality Management messen wir uns am Markt.
<G-vec00121-002-s356><compete.messen><en> You will be able to access the ranked multiplayer ladder to compete with other players to become the best of the best, complete with all of the multiplayer units from Wings of Liberty, Heart of the Swarm, and Legacy of the Void.
<G-vec00121-002-s356><compete.messen><de> Ihr erhaltet außerdem Zugriff auf den gewerteten Mehrspielermodus, wo ihr euch mit anderen Spielern messen könnt, um zum Besten der Besten zu werden.
<G-vec00121-002-s357><compete.messen><en> Here, teams are still in the age groups under 15 years and over 15 years register in advance and compete in a fair contest and play the winner.
<G-vec00121-002-s357><compete.messen><de> Hier können sich noch Teams in den Altersklassen unter 15 Jahren und über 15 Jahren vorab anmelden und in einem fairen Wettkampf messen und den Sieger ausspielen.
<G-vec00121-002-s358><compete.messen><en> This innovative mobile platform allows players to connect and compete with friends, even when away from their home console.
<G-vec00121-002-s358><compete.messen><de> Mit dieser innovativen, mobilen Plattform können Spieler sich mit ihren Freunden verbinden oder messen, sogar, wenn sie nicht zu Hause an ihrer Konsole sind.
<G-vec00121-002-s359><compete.messen><en> During development it was essential to us to ensure that the quality of this subminiature paddle can absolutely compete with its bigger brother, the Mini Paddle!
<G-vec00121-002-s359><compete.messen><de> Bei der Entwicklung wurde zudem großen Wert darauf gelegt, dass sich dieses Subminiatur-Paddle durchaus mit seinem größeren Bruder, dem Mini Paddle, messen kann.
<G-vec00121-002-s360><compete.messen><en> The green area houses a run & bike path, where people can work out in nature; the Wellness Agora, an innovative gym looking out over the lake with open air training programmes, including functional and group activities; a basketball and volleyball court where players can compete and strengthen their team spirit. RUN & BIKE PATH
<G-vec00121-002-s360><compete.messen><de> In der Grünanlage wurden eine Laufstrecke und ein Radweg eingerichtet, wo die Menschen in der Natur trainieren können; das Wellness Agora, ein innovatives Fitnessstudio mit Blick über den See mit Trainingsprogrammen im Freien, einschließlich Funktionstraining und Gruppenaktivitäten; ein Basketball und Volleyballplatz, wo Spieler ihren Teamgeist stärken und sich mit gegnerischen Mannschaften messen können.
<G-vec00121-002-s361><compete.messen><en> Visual Explorer - Compete in Bridge tournaments and receive scores based on the actual tournament results.
<G-vec00121-002-s361><compete.messen><de> Bridge Baron 23 - Messen Sie sich in Bridge-Turniere und erhalten Partituren auf der Grundlage der tatsächlichen Turnier Ergebnisse.
<G-vec00121-002-s362><compete.messen><en> In this Tournament, Commanders will compete with each other by recruiting troops.
<G-vec00121-002-s362><compete.messen><de> In diesem Wettbewerb messen Kommandanten sich in der Rekrutierung von Truppen.
<G-vec00121-002-s363><compete.messen><en> Enjoy the Engadine cross-country skiing trails from Zuoz to St. Moritz and back with traditional classic technique, and compete with top athletes or hobby skiers over a distance of 65 km.
<G-vec00121-002-s363><compete.messen><de> Rutschen Sie in das Jahr 2020 mit dem kontrastreichen Angebot zurück in der traditionsreichen klassischen Technik und messen Sie sich mit Spitzenathleten und Breitensportlern auf einer Strecke von 65 km.
<G-vec00121-002-s364><compete.messen><en> Compete with the twelve other toys.
<G-vec00121-002-s364><compete.messen><de> Messen Sie sich mit den zwölf anderen Spielsachen.
<G-vec00121-002-s365><compete.messen><en> Worldwide, HipHop Crews compete in competitions and battles.
<G-vec00121-002-s365><compete.messen><de> Weltweit messen sich heute HipHop Crews in Competitions und Battles.
<G-vec00121-002-s366><compete.messen><en> International cowboys compete in the rodeo, covered wagon races take place and with many musical events the Stampede is the annual highlight for locals and tourists.
<G-vec00121-002-s366><compete.messen><de> Internationale Cowboys messen sich im Rodeo, es finden Planwagenrennen statt und mit vielen musikalischen Veranstaltungen ist die Stampede der jährliche Höhepunkt für Einheimische und Touristen.
<G-vec00121-002-s367><compete.messen><en> The finalists who are top in the ranking based on points acquired in each competition will participate in the summer 2018 WORLD FINALS to compete to become the world's best PES 2018 player.
<G-vec00121-002-s367><compete.messen><de> Spieler, die sich am Ende der EUROPE ROUND an der Spitze der Rangliste wiederfinden, messen sich im Sommer im 2018 WORLD FINALS, um zum besten PES 2018-Spieler der Welt erkoren zu werden.
<G-vec00121-002-s368><compete.messen><en> Each year, high-profile participants compete in nine disciplines.
<G-vec00121-002-s368><compete.messen><de> Beim jährlichen Hallenmeeting messen sich hochkarätige Teilnehmer in neun Disziplinen.
<G-vec00121-002-s369><compete.messen><en> groups from all parts of Europe will compete at the Phenomenon Streetdance Showcase competition.
<G-vec00121-002-s369><compete.messen><de> Ausgewählte Gruppen aus allen Teilen Europas messen sich am Streetdance Showcase Wettbewerb.
<G-vec00121-002-s370><compete.messen><en> The winners of the local trials compete in regional heats for a place in the national finals.
<G-vec00121-002-s370><compete.messen><de> Die Gewinner/innen der lokalen Wettkämpfe messen sich in regionalen Ausscheidungskämpfen, um einen Platz in den nationalen Finalkämpfen zu ergattern.
<G-vec00121-002-s371><compete.messen><en> A good third of that time they have defended their habitat against the dinosaurs, but tonight they compete with the titans of natural selection.
<G-vec00121-002-s371><compete.messen><de> Einen guten Drittel davon verteidigten sie ihren Lebensraum gegen die Dinosaurier, und heute Nacht messen sie sich mit den Königen natürlicher Auslese.
<G-vec00121-002-s372><compete.messen><en> The world's best sports cars compete in a race that demands everything of drivers and vehicles for 24 long hours.
<G-vec00121-002-s372><compete.messen><de> Die besten Sportwagen der Welt messen sich in einem Rennen, das Fahrern und Fahrzeugen 24 Stunden lang alles abverlangt.
<G-vec00121-002-s373><compete.messen><en> Compete with colleagues at work, with friends or with family, one of you has the smartest hand.
<G-vec00121-002-s373><compete.messen><de> Messen Sie sich mit Ihren Kollegen bei der Arbeit, mit Freunden oder mit der Familie, die von Ihnen eine geschickte Hand hat.
<G-vec00121-002-s374><compete.messen><en> Compete with your friends and family in the extended Multiplayer Mode.
<G-vec00121-002-s374><compete.messen><de> Im erweiterten Mehrspieler-Modus messen Sie sich jetzt per drahtloser DS-Datenübertragung mit Familie und Freunden.
<G-vec00121-002-s375><compete.messen><en> The five Formula 1 drivers qualifying on the first five positions for the Formula 1 race compete against a maximum of19 private drivers (number of private drivers was limited to 15 in Monaco).
<G-vec00121-002-s375><compete.messen><de> Die jeweils fünf schnellsten Formel-1 Piloten des Zeittrainings messen sich mit maximal 19 Privatfahrern (15 Privatfahrer in Monaco).
<G-vec00121-002-s376><compete.messen><en> - Compete with FB friends
<G-vec00121-002-s376><compete.messen><de> - Messen Sie sich mit FB Freunde.
<G-vec00121-002-s377><compete.messen><en> In a sports competition, two athletes compete against each other.
<G-vec00121-002-s377><compete.messen><de> In einem sportlichen Wettkampf messen sich zwei Sportler aneinander.
<G-vec00121-002-s378><compete.messen><en> In this running contest international top athletes and recreational runners compete with each other.
<G-vec00121-002-s378><compete.messen><de> Im Rahmen dieses Laufwettbewerbes messen sich internationale Spitzenathleten und Freizeitläufer.
<G-vec00121-002-s379><compete.messen><en> Under the moniker BOSS GP, the fastest race cars in the world will compete.
<G-vec00121-002-s379><compete.messen><de> Unter dem Label BOSS GP messen sich die international schnellsten Rennwagen.
<G-vec00121-002-s380><compete.messen><en> Compete with friends and create community challenges with card modifiers in an all new Nightmare Mode
<G-vec00121-002-s380><compete.messen><de> Miss dich mit deinen Freunden und kreiere Community-Challenges in diesem neuen Nightmare-Modus.
<G-vec00121-002-s381><compete.messen><en> Jump in the car of your favorite racing driver and compete with the best through 12 unique tracks located around the globe including Okayama.
<G-vec00121-002-s381><compete.messen><de> Spring in das Auto Deines Lieblings-Fahrers und miss dich mit den besten durch 12 lange Strecken hindurch inklusive der Strecke von Okayama.
<G-vec00121-002-s382><compete.messen><en> Perform awesome aerial tricks like The Dragon Flip and compete against your friends in challenges such as The Dragon Hunter.
<G-vec00121-002-s382><compete.messen><de> Zeig verrückte Tricks wie das Drachennest und miss dich mit deinen Freunden bei Herausforderungen wie Die Drachenverwandlung.
<G-vec00121-002-s383><compete.messen><en> Compete against your friends and use your environment to create countless fun Spinjitzu challenges.
<G-vec00121-002-s383><compete.messen><de> Miss dich mit deinen Freunden und benutze die ganze Einrichtung, um stundenlangen Spielspaß bei immer neuen Spinjitzu-Herausforderungen zu erleben.
<G-vec00121-002-s384><compete.messen><en> - Add friends to compete against them.
<G-vec00121-002-s384><compete.messen><de> - Füge Freunde hinzu und miss dich mit ihnen.
<G-vec00121-002-s385><compete.messen><en> Compete against opponents from around the world or race against your friends in real-time challenges.
<G-vec00121-002-s385><compete.messen><de> Miss dich mit Gegnern aus aller Welt oder fahre Rennen gegen deine Freunde in Echtzeit-Herausforderungen.
<G-vec00121-002-s386><compete.messen><en> Combine stats with your friends in Bike Club to unlock rewards then compete across all events to reach the top of your club.
<G-vec00121-002-s386><compete.messen><de> Kombiniere im Bike Club deine Werte mit denen deiner Freunde, um Belohnungen freizuschalten, und miss dich in allen Events, um die Spitze deines Clubs zu erreichen.
<G-vec00121-002-s387><compete.messen><en> – Join leagues and compete with your friends!
<G-vec00121-002-s387><compete.messen><de> Schließ dich einem Club an und miss dich mit deinen Freunden.
<G-vec00121-002-s488><compete.messen><en> Every year, around 300 riders from all around Europe set out on a pilgrimage to Flims to compete with other trail foxes.
<G-vec00121-002-s488><compete.messen><de> Jahr für Jahr pilgern rund 300 Fahrer aus ganz Europa nach Flims, um sich mit den anderen Trail-Füchsen zu messen.
<G-vec00121-002-s489><compete.messen><en> 2016 is the year of the 3rd European Deaf Youth Athletics Championships. Germany assumed the task to offer an appropriate platform for young talented athletes, to compete against each other and determine the best amongst them.
<G-vec00121-002-s489><compete.messen><de> 2016 jährt sich die Leichtathletik Junioren Europameisterschaft bereits zum dritten Mal und Deutschland hat es sich zur Aufgabe gemacht, jungen Talenten aus ganz Europa die Plattform zu bieten, sich miteinander zu messen, die Besten unter sich zu bestimmen.
<G-vec00121-002-s490><compete.messen><en> They are also a venue for eSport events, where international gaming stars compete in enthralling tournaments and league games.
<G-vec00121-002-s490><compete.messen><de> Ebenso sind sie immer wieder Austragungsort von eSport Events, bei denen sich internationale Gaming Stars in spannenden Turnieren und Liga-Spielen messen.
<G-vec00121-002-s491><compete.messen><en> The Jolanda Neff's and Nino Schurter's of tomorrow can compete at the Steinböckli balance bike race.
<G-vec00121-002-s491><compete.messen><de> An der Steinböckli Laufrad Rennen können sich die Jolanda Neff’s und Nino Schurter's von Morgen messen.
<G-vec00121-002-s492><compete.messen><en> In the past, PP could not compete with the high clarity of polystyrene (PS), polyethylene terephthalate (PET) and other materials.
<G-vec00121-002-s492><compete.messen><de> In der Vergangenheit konnte sich PP nicht mit der hohen Ttransparenz von Polystyrol (PS), Polyethylenterephthalat (PET) und anderen Materialien messen.
<G-vec00121-002-s493><compete.messen><en> The best athletes of the world should have the opportunity – despite of their economic or political situation – to compete in a fair and sporty event.
<G-vec00121-002-s493><compete.messen><de> Die besten Athleten aller Länder sollen – unabhängig von den jeweiligen wirtschaftlichen und politischen Gegebenheiten – die Möglichkeit haben, sich im fairen sportlichen Wettkampf zu messen.
<G-vec00121-002-s494><compete.messen><en> Here you can continually assess your achieved time and compete with others.
<G-vec00121-002-s494><compete.messen><de> Hier kann man ständig seine erzielte Zeit begutachten und sich mit den anderen messen.
<G-vec00121-002-s495><compete.messen><en> These are rides in which you can compete with japanese cyclists.
<G-vec00121-002-s495><compete.messen><de> Hier können Sie sich an Japanischen Fahrern messen.
<G-vec00121-002-s496><compete.messen><en> Compete with virtual opponents in the Challenge mode.
<G-vec00121-002-s496><compete.messen><de> Im Challenge-Modus können Sie sich mit virtuellen Gegnern messen.
<G-vec00121-002-s497><compete.messen><en> More than 100 Herens cows will compete against the backdrop of the Matterhorn, with one of them to be crowned "Reine du Cervin".
<G-vec00121-002-s497><compete.messen><de> Über hundert Eringer-Kühe werden sich vor der Kulisse des Matterhorns messen und den Titel "Reine du Cervin" untereinander ausmachen.
<G-vec00121-002-s498><compete.messen><en> 12. Oct. 2018 The goal of the Dolomythi Cup since it´s first edition in 2007 is to motivate South Tyrolean sailors to sail offshore and to compete with the same boats in a sporting competition.
<G-vec00121-002-s498><compete.messen><de> Das Ziel des DolomythiCup seit der ersten Auflage im Jahr 2007 ist es, Südtiroler Segler zum Hochseesegeln zu aktivieren, gemeinsam an einer Regatta teilzunehmen und sich mit gleichen Booten im sportlichen Wettkampf zu messen.
<G-vec00121-002-s499><compete.messen><en> Offering more performance, more style and more driving fun, the all-new BMW M135i xDrive is not there to compete – but to set new standards.
<G-vec00121-002-s499><compete.messen><de> Mehr Performance, mehr Style, mehr Fahrspaß: Der neue BMW M135i xDrive ist nicht da, um sich zu messen – sondern um neue Maßstäbe zu setzen.
<G-vec00121-002-s500><compete.messen><en> These events bring people together who not only want to compete on different athletic levels but also tap into the social aspects of exercising a sport.
<G-vec00121-002-s500><compete.messen><de> Diese Veranstaltungen bringen Menschen zusammen, die sich auf unterschiedlichen Ebenen sportlich messen und den sozialen Aspekt des Sporttreibens nutzen wollen.
<G-vec00121-002-s501><compete.messen><en> The vertical is particularly hard hit, but even in the horizontal, the Envy 6 cannot compete with the (admittedly much more expensive) Zenbook UX32VD.
<G-vec00121-002-s501><compete.messen><de> Auf der Horizontalen bleibt er zwar etwas länger stabil, kann sich aber auch nicht mit den qualitativ besseren (und teureren) IPS-Displays messen lassen, welches etwa beim Asus Zenbook UX32VD zum Einsatz kommt.
<G-vec00121-002-s502><compete.messen><en> Different categories in which you can compete.
<G-vec00121-002-s502><compete.messen><de> Diverse Kategorien, in denen Sie sich messen können.
<G-vec00121-002-s503><compete.messen><en> In comparison to the predecessor model, the 400B5C has made a significant step forward and can now compete with Lenovo's T530.
<G-vec00121-002-s503><compete.messen><de> Im Vergleich mit dem Vorgängermodell macht das 400B5C damit einen spürbaren Schritt nach vorn und kann sich mit dem T530 von Lenovo messen.
<G-vec00121-002-s504><compete.messen><en> I would advise women to be willing to work hard and to compete on an equal footing with men.
<G-vec00121-002-s504><compete.messen><de> Ich würde Frauen raten, bereit zu sein, hart zu arbeiten und sich gleichberechtigt mit Männern zu messen.
<G-vec00121-002-s505><compete.messen><en> After crossing the Apennine Mountains at the Cerreto Pass, they reached Reggio Emilia and the Calatrava Bridges to compete for the challenging “Trofeo Tricolore”.
<G-vec00121-002-s505><compete.messen><de> Nach der Überquerung der Apenninen am Passo Cerreto erreichten sie Reggio Emilia und die Calatrava-Brücken, um sich bei der anspruchsvollen „Trofeo Tricolore“ zu messen.
<G-vec00121-002-s506><compete.messen><en> When private insurers had to compete on a level playing field with the traditional government-run plan they were almost driven from the market."
<G-vec00121-002-s506><compete.messen><de> Als die Privatversicherer sich auf gleicher Ebene mit dem traditionellen, staatlichen (Versicherungs-)Plan messen mussten, wurden sie fast vom Markt verdrängt".
<G-vec00121-002-s336><compete.sich_messen><en> Travel to the mythological age of feudal Japan and compete with many other players in the quest to become Shogun.
<G-vec00121-002-s336><compete.sich_messen><de> Reise ins mythologische Zeitalter des feudalen Japans und messe dich mit vielen anderen Spielern beim Versuch, Shogun zu werden.
<G-vec00121-002-s337><compete.sich_messen><en> Compete with other players or with embedded powerful artificial intelligence.
<G-vec00121-002-s337><compete.sich_messen><de> Messe dich mit anderen Spielern oder der eingebauten leistungsfähigen künstlichen Intelligenz.
<G-vec00121-002-s338><compete.sich_messen><en> Check out this award-winning MIDDLE AGES STRATEGY GAME and compete against MILLIONS of other players!Play Empire: Four Kingdoms now and discover far away countries and continents.
<G-vec00121-002-s338><compete.sich_messen><de> Spiele das ausgezeichnete MITTELALTER-STRATEGIESPIEL und messe Dich mit MILLIONEN von anderen Spielern!Spiele jetzt Empire: Four Kingdoms und entdecke ferne Länder und Kontinente.
<G-vec00121-002-s339><compete.sich_messen><en> Drive a huge variety of cars and compete in a series of action-packed challenges.
<G-vec00121-002-s339><compete.sich_messen><de> Fahre eine unglaubliche Bandbreite von Autos und messe dich in zahlreichen actiongeladenen Challenges.
<G-vec00121-002-s340><compete.sich_messen><en> Compete with your friends and find out what pictures really move the world.
<G-vec00121-002-s340><compete.sich_messen><de> Messe dich mit deinen Freunden und finde heraus, welche Bilder die Welt wirklich bewegen.
<G-vec00121-002-s341><compete.sich_messen><en> Be a member of national team and compete with other players all over the world.
<G-vec00121-002-s341><compete.sich_messen><de> Sei ein Mitglied deines nationalen Teams und messe dich mit Spielern auf der ganzen Welt.
<G-vec00121-002-s361><compete.sich_messen><en> Visual Explorer - Compete in Bridge tournaments and receive scores based on the actual tournament results.
<G-vec00121-002-s361><compete.sich_messen><de> Bridge Baron 23 - Messen Sie sich in Bridge-Turniere und erhalten Partituren auf der Grundlage der tatsächlichen Turnier Ergebnisse.
<G-vec00121-002-s362><compete.sich_messen><en> In this Tournament, Commanders will compete with each other by recruiting troops.
<G-vec00121-002-s362><compete.sich_messen><de> In diesem Wettbewerb messen Kommandanten sich in der Rekrutierung von Truppen.
<G-vec00121-002-s363><compete.sich_messen><en> Enjoy the Engadine cross-country skiing trails from Zuoz to St. Moritz and back with traditional classic technique, and compete with top athletes or hobby skiers over a distance of 65 km.
<G-vec00121-002-s363><compete.sich_messen><de> Rutschen Sie in das Jahr 2020 mit dem kontrastreichen Angebot zurück in der traditionsreichen klassischen Technik und messen Sie sich mit Spitzenathleten und Breitensportlern auf einer Strecke von 65 km.
<G-vec00121-002-s364><compete.sich_messen><en> Compete with the twelve other toys.
<G-vec00121-002-s364><compete.sich_messen><de> Messen Sie sich mit den zwölf anderen Spielsachen.
<G-vec00121-002-s365><compete.sich_messen><en> Worldwide, HipHop Crews compete in competitions and battles.
<G-vec00121-002-s365><compete.sich_messen><de> Weltweit messen sich heute HipHop Crews in Competitions und Battles.
<G-vec00121-002-s366><compete.sich_messen><en> International cowboys compete in the rodeo, covered wagon races take place and with many musical events the Stampede is the annual highlight for locals and tourists.
<G-vec00121-002-s366><compete.sich_messen><de> Internationale Cowboys messen sich im Rodeo, es finden Planwagenrennen statt und mit vielen musikalischen Veranstaltungen ist die Stampede der jährliche Höhepunkt für Einheimische und Touristen.
<G-vec00121-002-s367><compete.sich_messen><en> The finalists who are top in the ranking based on points acquired in each competition will participate in the summer 2018 WORLD FINALS to compete to become the world's best PES 2018 player.
<G-vec00121-002-s367><compete.sich_messen><de> Spieler, die sich am Ende der EUROPE ROUND an der Spitze der Rangliste wiederfinden, messen sich im Sommer im 2018 WORLD FINALS, um zum besten PES 2018-Spieler der Welt erkoren zu werden.
<G-vec00121-002-s368><compete.sich_messen><en> Each year, high-profile participants compete in nine disciplines.
<G-vec00121-002-s368><compete.sich_messen><de> Beim jährlichen Hallenmeeting messen sich hochkarätige Teilnehmer in neun Disziplinen.
<G-vec00121-002-s369><compete.sich_messen><en> groups from all parts of Europe will compete at the Phenomenon Streetdance Showcase competition.
<G-vec00121-002-s369><compete.sich_messen><de> Ausgewählte Gruppen aus allen Teilen Europas messen sich am Streetdance Showcase Wettbewerb.
<G-vec00121-002-s370><compete.sich_messen><en> The winners of the local trials compete in regional heats for a place in the national finals.
<G-vec00121-002-s370><compete.sich_messen><de> Die Gewinner/innen der lokalen Wettkämpfe messen sich in regionalen Ausscheidungskämpfen, um einen Platz in den nationalen Finalkämpfen zu ergattern.
<G-vec00121-002-s371><compete.sich_messen><en> A good third of that time they have defended their habitat against the dinosaurs, but tonight they compete with the titans of natural selection.
<G-vec00121-002-s371><compete.sich_messen><de> Einen guten Drittel davon verteidigten sie ihren Lebensraum gegen die Dinosaurier, und heute Nacht messen sie sich mit den Königen natürlicher Auslese.
<G-vec00121-002-s372><compete.sich_messen><en> The world's best sports cars compete in a race that demands everything of drivers and vehicles for 24 long hours.
<G-vec00121-002-s372><compete.sich_messen><de> Die besten Sportwagen der Welt messen sich in einem Rennen, das Fahrern und Fahrzeugen 24 Stunden lang alles abverlangt.
<G-vec00121-002-s373><compete.sich_messen><en> Compete with colleagues at work, with friends or with family, one of you has the smartest hand.
<G-vec00121-002-s373><compete.sich_messen><de> Messen Sie sich mit Ihren Kollegen bei der Arbeit, mit Freunden oder mit der Familie, die von Ihnen eine geschickte Hand hat.
<G-vec00121-002-s374><compete.sich_messen><en> Compete with your friends and family in the extended Multiplayer Mode.
<G-vec00121-002-s374><compete.sich_messen><de> Im erweiterten Mehrspieler-Modus messen Sie sich jetzt per drahtloser DS-Datenübertragung mit Familie und Freunden.
<G-vec00121-002-s375><compete.sich_messen><en> The five Formula 1 drivers qualifying on the first five positions for the Formula 1 race compete against a maximum of19 private drivers (number of private drivers was limited to 15 in Monaco).
<G-vec00121-002-s375><compete.sich_messen><de> Die jeweils fünf schnellsten Formel-1 Piloten des Zeittrainings messen sich mit maximal 19 Privatfahrern (15 Privatfahrer in Monaco).
<G-vec00121-002-s376><compete.sich_messen><en> - Compete with FB friends
<G-vec00121-002-s376><compete.sich_messen><de> - Messen Sie sich mit FB Freunde.
<G-vec00121-002-s377><compete.sich_messen><en> In a sports competition, two athletes compete against each other.
<G-vec00121-002-s377><compete.sich_messen><de> In einem sportlichen Wettkampf messen sich zwei Sportler aneinander.
<G-vec00121-002-s378><compete.sich_messen><en> In this running contest international top athletes and recreational runners compete with each other.
<G-vec00121-002-s378><compete.sich_messen><de> Im Rahmen dieses Laufwettbewerbes messen sich internationale Spitzenathleten und Freizeitläufer.
<G-vec00121-002-s379><compete.sich_messen><en> Under the moniker BOSS GP, the fastest race cars in the world will compete.
<G-vec00121-002-s379><compete.sich_messen><de> Unter dem Label BOSS GP messen sich die international schnellsten Rennwagen.
<G-vec00121-002-s380><compete.sich_messen><en> Compete with friends and create community challenges with card modifiers in an all new Nightmare Mode
<G-vec00121-002-s380><compete.sich_messen><de> Miss dich mit deinen Freunden und kreiere Community-Challenges in diesem neuen Nightmare-Modus.
<G-vec00121-002-s381><compete.sich_messen><en> Jump in the car of your favorite racing driver and compete with the best through 12 unique tracks located around the globe including Okayama.
<G-vec00121-002-s381><compete.sich_messen><de> Spring in das Auto Deines Lieblings-Fahrers und miss dich mit den besten durch 12 lange Strecken hindurch inklusive der Strecke von Okayama.
<G-vec00121-002-s382><compete.sich_messen><en> Perform awesome aerial tricks like The Dragon Flip and compete against your friends in challenges such as The Dragon Hunter.
<G-vec00121-002-s382><compete.sich_messen><de> Zeig verrückte Tricks wie das Drachennest und miss dich mit deinen Freunden bei Herausforderungen wie Die Drachenverwandlung.
<G-vec00121-002-s383><compete.sich_messen><en> Compete against your friends and use your environment to create countless fun Spinjitzu challenges.
<G-vec00121-002-s383><compete.sich_messen><de> Miss dich mit deinen Freunden und benutze die ganze Einrichtung, um stundenlangen Spielspaß bei immer neuen Spinjitzu-Herausforderungen zu erleben.
<G-vec00121-002-s384><compete.sich_messen><en> - Add friends to compete against them.
<G-vec00121-002-s384><compete.sich_messen><de> - Füge Freunde hinzu und miss dich mit ihnen.
<G-vec00121-002-s385><compete.sich_messen><en> Compete against opponents from around the world or race against your friends in real-time challenges.
<G-vec00121-002-s385><compete.sich_messen><de> Miss dich mit Gegnern aus aller Welt oder fahre Rennen gegen deine Freunde in Echtzeit-Herausforderungen.
<G-vec00121-002-s386><compete.sich_messen><en> Combine stats with your friends in Bike Club to unlock rewards then compete across all events to reach the top of your club.
<G-vec00121-002-s386><compete.sich_messen><de> Kombiniere im Bike Club deine Werte mit denen deiner Freunde, um Belohnungen freizuschalten, und miss dich in allen Events, um die Spitze deines Clubs zu erreichen.
<G-vec00121-002-s387><compete.sich_messen><en> – Join leagues and compete with your friends!
<G-vec00121-002-s387><compete.sich_messen><de> Schließ dich einem Club an und miss dich mit deinen Freunden.
<G-vec00121-002-s488><compete.sich_messen><en> Every year, around 300 riders from all around Europe set out on a pilgrimage to Flims to compete with other trail foxes.
<G-vec00121-002-s488><compete.sich_messen><de> Jahr für Jahr pilgern rund 300 Fahrer aus ganz Europa nach Flims, um sich mit den anderen Trail-Füchsen zu messen.
<G-vec00121-002-s489><compete.sich_messen><en> 2016 is the year of the 3rd European Deaf Youth Athletics Championships. Germany assumed the task to offer an appropriate platform for young talented athletes, to compete against each other and determine the best amongst them.
<G-vec00121-002-s489><compete.sich_messen><de> 2016 jährt sich die Leichtathletik Junioren Europameisterschaft bereits zum dritten Mal und Deutschland hat es sich zur Aufgabe gemacht, jungen Talenten aus ganz Europa die Plattform zu bieten, sich miteinander zu messen, die Besten unter sich zu bestimmen.
<G-vec00121-002-s490><compete.sich_messen><en> They are also a venue for eSport events, where international gaming stars compete in enthralling tournaments and league games.
<G-vec00121-002-s490><compete.sich_messen><de> Ebenso sind sie immer wieder Austragungsort von eSport Events, bei denen sich internationale Gaming Stars in spannenden Turnieren und Liga-Spielen messen.
<G-vec00121-002-s491><compete.sich_messen><en> The Jolanda Neff's and Nino Schurter's of tomorrow can compete at the Steinböckli balance bike race.
<G-vec00121-002-s491><compete.sich_messen><de> An der Steinböckli Laufrad Rennen können sich die Jolanda Neff’s und Nino Schurter's von Morgen messen.
<G-vec00121-002-s492><compete.sich_messen><en> In the past, PP could not compete with the high clarity of polystyrene (PS), polyethylene terephthalate (PET) and other materials.
<G-vec00121-002-s492><compete.sich_messen><de> In der Vergangenheit konnte sich PP nicht mit der hohen Ttransparenz von Polystyrol (PS), Polyethylenterephthalat (PET) und anderen Materialien messen.
<G-vec00121-002-s493><compete.sich_messen><en> The best athletes of the world should have the opportunity – despite of their economic or political situation – to compete in a fair and sporty event.
<G-vec00121-002-s493><compete.sich_messen><de> Die besten Athleten aller Länder sollen – unabhängig von den jeweiligen wirtschaftlichen und politischen Gegebenheiten – die Möglichkeit haben, sich im fairen sportlichen Wettkampf zu messen.
<G-vec00121-002-s494><compete.sich_messen><en> Here you can continually assess your achieved time and compete with others.
<G-vec00121-002-s494><compete.sich_messen><de> Hier kann man ständig seine erzielte Zeit begutachten und sich mit den anderen messen.
<G-vec00121-002-s495><compete.sich_messen><en> These are rides in which you can compete with japanese cyclists.
<G-vec00121-002-s495><compete.sich_messen><de> Hier können Sie sich an Japanischen Fahrern messen.
<G-vec00121-002-s496><compete.sich_messen><en> Compete with virtual opponents in the Challenge mode.
<G-vec00121-002-s496><compete.sich_messen><de> Im Challenge-Modus können Sie sich mit virtuellen Gegnern messen.
<G-vec00121-002-s497><compete.sich_messen><en> More than 100 Herens cows will compete against the backdrop of the Matterhorn, with one of them to be crowned "Reine du Cervin".
<G-vec00121-002-s497><compete.sich_messen><de> Über hundert Eringer-Kühe werden sich vor der Kulisse des Matterhorns messen und den Titel "Reine du Cervin" untereinander ausmachen.
<G-vec00121-002-s498><compete.sich_messen><en> 12. Oct. 2018 The goal of the Dolomythi Cup since it´s first edition in 2007 is to motivate South Tyrolean sailors to sail offshore and to compete with the same boats in a sporting competition.
<G-vec00121-002-s498><compete.sich_messen><de> Das Ziel des DolomythiCup seit der ersten Auflage im Jahr 2007 ist es, Südtiroler Segler zum Hochseesegeln zu aktivieren, gemeinsam an einer Regatta teilzunehmen und sich mit gleichen Booten im sportlichen Wettkampf zu messen.
<G-vec00121-002-s499><compete.sich_messen><en> Offering more performance, more style and more driving fun, the all-new BMW M135i xDrive is not there to compete – but to set new standards.
<G-vec00121-002-s499><compete.sich_messen><de> Mehr Performance, mehr Style, mehr Fahrspaß: Der neue BMW M135i xDrive ist nicht da, um sich zu messen – sondern um neue Maßstäbe zu setzen.
<G-vec00121-002-s500><compete.sich_messen><en> These events bring people together who not only want to compete on different athletic levels but also tap into the social aspects of exercising a sport.
<G-vec00121-002-s500><compete.sich_messen><de> Diese Veranstaltungen bringen Menschen zusammen, die sich auf unterschiedlichen Ebenen sportlich messen und den sozialen Aspekt des Sporttreibens nutzen wollen.
<G-vec00121-002-s501><compete.sich_messen><en> The vertical is particularly hard hit, but even in the horizontal, the Envy 6 cannot compete with the (admittedly much more expensive) Zenbook UX32VD.
<G-vec00121-002-s501><compete.sich_messen><de> Auf der Horizontalen bleibt er zwar etwas länger stabil, kann sich aber auch nicht mit den qualitativ besseren (und teureren) IPS-Displays messen lassen, welches etwa beim Asus Zenbook UX32VD zum Einsatz kommt.
<G-vec00121-002-s502><compete.sich_messen><en> Different categories in which you can compete.
<G-vec00121-002-s502><compete.sich_messen><de> Diverse Kategorien, in denen Sie sich messen können.
<G-vec00121-002-s503><compete.sich_messen><en> In comparison to the predecessor model, the 400B5C has made a significant step forward and can now compete with Lenovo's T530.
<G-vec00121-002-s503><compete.sich_messen><de> Im Vergleich mit dem Vorgängermodell macht das 400B5C damit einen spürbaren Schritt nach vorn und kann sich mit dem T530 von Lenovo messen.
<G-vec00121-002-s504><compete.sich_messen><en> I would advise women to be willing to work hard and to compete on an equal footing with men.
<G-vec00121-002-s504><compete.sich_messen><de> Ich würde Frauen raten, bereit zu sein, hart zu arbeiten und sich gleichberechtigt mit Männern zu messen.
<G-vec00121-002-s505><compete.sich_messen><en> After crossing the Apennine Mountains at the Cerreto Pass, they reached Reggio Emilia and the Calatrava Bridges to compete for the challenging “Trofeo Tricolore”.
<G-vec00121-002-s505><compete.sich_messen><de> Nach der Überquerung der Apenninen am Passo Cerreto erreichten sie Reggio Emilia und die Calatrava-Brücken, um sich bei der anspruchsvollen „Trofeo Tricolore“ zu messen.
<G-vec00121-002-s506><compete.sich_messen><en> When private insurers had to compete on a level playing field with the traditional government-run plan they were almost driven from the market."
<G-vec00121-002-s506><compete.sich_messen><de> Als die Privatversicherer sich auf gleicher Ebene mit dem traditionellen, staatlichen (Versicherungs-)Plan messen mussten, wurden sie fast vom Markt verdrängt".
<G-vec00121-002-s749><compete.wetteifern><en> NH, Barceló. Melià and Iberostar compete year after year for local, national and international destinations, as well as for very characteristic travellers: from sports lovers to music fans.
<G-vec00121-002-s749><compete.wetteifern><de> NH, Barceló, Melià und Iberostar wetteifern jedes Jahr mit lokalen, nationalen und internationalen Reisezielen und darunter noch einmal um sehr unterschiedliche Gästesegmente, die heute von Sportfreunden bis zu Musikliebhabern reichen.
<G-vec00121-002-s750><compete.wetteifern><en> Every two years, in Europe, Wiesbaden young circus talents to the "European Youth Circus" and compete for the popular trophy "Best European junior Artist".
<G-vec00121-002-s750><compete.wetteifern><de> Alle zwei Jahre treffen sich in Wiesbaden Europas junge Zirkustalente zum “European Youth Circus” und wetteifern um die beliebte Trophäe “Bester europäischer Nachwuchs-Artist”.
<G-vec00121-002-s751><compete.wetteifern><en> Certainly yes! Because the sound wave propagates in air irrespective of the velocity of source at signal issuing time, the first airplane (which has sent a signal) will catch up the wave front propagating in the positive direction of axis, whereas the second airplane will "compete" with the wave front propagating in the negative direction of axis .
<G-vec00121-002-s751><compete.wetteifern><de> Da sich die Schallwelle in der Luft unabhängig von der Geschwindigkeit der Quelle im Zeitpunkt der Aussendung des Signals fortpflanzt, so wird das erste Flugzeug (das Signal gesendete) die Wellenfront einholen, die sich in der positiven Richtung der Achse erstreckt, und das zweite Flugzeug wird mit der Wellenfront "wetteifern", die sich in der negativen Richtung der Achse erstreckt.
<G-vec00121-002-s752><compete.wetteifern><en> They compete with each other in everything to make it more corrupt.
<G-vec00121-002-s752><compete.wetteifern><de> Sie wetteifern in allem miteinander, um es mehr zu verderben.
<G-vec00121-002-s753><compete.wetteifern><en> Up to four players can compete, just one copy of the game required!
<G-vec00121-002-s753><compete.wetteifern><de> Bis zu vier Spieler können mit nur einem Exemplar des Spiels wetteifern.
<G-vec00121-002-s754><compete.wetteifern><en> An efficient and inexpensive thin-film module made of crystalline silicon is the dream of many PV researchers – but still various technologies compete to be the concept of the future; article in German about the 21st EU PVSEC in Dresden), in: Sonne Wind & Wärme 11/06, pp.
<G-vec00121-002-s754><compete.wetteifern><de> Ein effizientes und preiswertes Dünnschichtmodul aus kristallinem Silizium ist der Traum vieler Photovoltaikforscher – noch aber wetteifern verschiedenste Technologien um das Konzept der Zukunft (Bericht über die 21.
<G-vec00121-002-s755><compete.wetteifern><en> Many mothers and fathers also spontaneously reach for a spade here and compete with their offspring by digging.
<G-vec00121-002-s755><compete.wetteifern><de> Viele Mütter und Väter greifen dabei ebenfalls spontan zur Schippe und wetteifern buddelnd mit ihren Sprösslingen.
<G-vec00121-002-s756><compete.wetteifern><en> • Meet & compete with new people.
<G-vec00121-002-s756><compete.wetteifern><de> • Neue Leute kennenlernen und mit ihnen wetteifern.
<G-vec00121-002-s757><compete.wetteifern><en> Three years ago, the competition got a new look, it is announced by the Confederation of Industry and Transport, together with the Technical University in Brno, and exhibits compete across sectorial categories.
<G-vec00121-002-s757><compete.wetteifern><de> Vor drei Jahren wurde dieser Wettbewerb neu gestaltet: Ausgeschrieben wird er vom Industrieverband der Tschechischen Republik in Zusammenarbeit mit der Technischen Universität Brünn, und die Exponate wetteifern quer durch alle Branchenkategorien.
<G-vec00121-002-s758><compete.wetteifern><en> The second stage is the Baltic Sea Tournament Final where the 21 best black jack players of the Baltic region will compete for the individual prize money divided among top three finishers, $ 20 000, $ 10 000 and $ 5 000 respectively, and for the team prize money of $ 10 500 (divided equally among the team of seven).
<G-vec00121-002-s758><compete.wetteifern><de> Die zweite Phase der Meisterschaft ist das sogenannte „Baltic Sea Tournament“ Finale, in welchem die 21 besten Black Jack Spieler des Baltikums einerseits um die Individualpreisgelder von jeweils 20000, 10000 und 5000 US Dollars für die besten 3 Spieler und andererseits um das Teampreisgeld von 10500 US Dollars (welches zu gleichen Teilen unter den 7 Nationalteammitgliedern aufgeteilt wird) wetteifern.
<G-vec00121-002-s759><compete.wetteifern><en> Here the nature and culture seem to compete in a comparison without end.
<G-vec00121-002-s759><compete.wetteifern><de> Hier scheinen die Natur und die Kultur in einem Vergleich ohne Ende zu wetteifern.
<G-vec00121-002-s760><compete.wetteifern><en> They were people who would compete with each other in good deeds and pray to Us with love and reverence.
<G-vec00121-002-s760><compete.wetteifern><de> Sie pflegten miteinander zu wetteifern in guten Taten und sie riefen Uns an in Hoffnung und in Furcht und waren demütig vor Uns.
<G-vec00121-002-s761><compete.wetteifern><en> With it come new Quests, new Gear, and some brand new ways to compete in Strikes.
<G-vec00121-002-s761><compete.wetteifern><de> Zeitgleich erwarten euch neue Quests, neue Ausrüstung und einige neue Möglichkeiten, in Strikes zu wetteifern.
<G-vec00121-002-s762><compete.wetteifern><en> Here, student teams from all over the world will compete for the fastest, best pod system.
<G-vec00121-002-s762><compete.wetteifern><de> Studententeams aus der ganzen Welt wetteifern hier um das schnellste und beste Kapselsystem.
<G-vec00121-002-s763><compete.wetteifern><en> Similar and worse declarations can be gleaned from other Arab Knesset members who seem to compete with each other in producing hostile pronouncements against Israel.
<G-vec00121-002-s763><compete.wetteifern><de> Ähnliche und schlimmere Erklärungen stammen von anderen arabischen Mitgliedern der Knesset, die bei der Formulierung feindseliger Aussagen gegenüber Israel miteinander zu wetteifern scheinen.
<G-vec00121-002-s764><compete.wetteifern><en> Excellent restaurants compete with quite acceptable prices to cater for the guests.
<G-vec00121-002-s764><compete.wetteifern><de> Ausgezeichnete Restaurants wetteifern mit durchaus akzeptablen Preisen um die Gunst der Gäste.
<G-vec00121-002-s765><compete.wetteifern><en> The food samplings are paired to match the beers, and chefs compete to win the People’s Choice Award for best pairing.
<G-vec00121-002-s765><compete.wetteifern><de> Die einzelnen Gerichte sind sorgfältig auf spezielle Biersorten abgestimmt und die Köche wetteifern um den People‘s Choice Award für die beste Paarung.
<G-vec00121-002-s766><compete.wetteifern><en> Actually we play in the same rehearsal place with them - Amorphis are just on the other side of the wall – so we can kind of compete who plays the loudest.
<G-vec00121-002-s766><compete.wetteifern><de> Wir spielen sogar mit einigen im selben Probenraum – Amorphis zum Beispiel sind genau auf der anderen Seite der Mauer, wir können also immer wetteifern, wer am lautesten probt.
<G-vec00121-002-s767><compete.wetteifern><en> Traditional Savoyard and Dauphinoise cooking is composed of simple ingredients, making for specialty dishes that are both tasty and substantial: gratin, croziflette (made with crozets, buckwheat pasta from Savoy), tartiflette (made with potatoes and Reblochon cheese), diots (Savoyard sausages), and matafan aux pommes (a kind of apple tart). Savoy cheeses such as Beaufort, Tomme and Reblochon compete for flavor with the picodons, Ardèche and Drôme goat’s cheeses, and fourmes from the Loire!
<G-vec00121-002-s767><compete.wetteifern><de> Die Küche von Savoyen und der Dauphiné basiert – wie fast immer im Gebirge – auf einfachen Zutaten, aus denen gehaltvolle und schmackhafte Gerichte entstehen: Gratin, Croziflette (Nudelauflauf), Tartiflette (Kartoffelauflauf), Diots (Würste), Matafan aux Pommes (Apfel-Pfannkuchen)… Die Käse und Reblochon wetteifern mit den Schafskäsen der Ardèche und der Drôme sowie den Fourmes de la Loire um die Gunst der Gourmets.
