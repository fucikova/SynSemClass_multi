<G-vec00555-002-s057><cut_off.abschneiden><en> After lots of futile attempts to save the mango trees, the only remaining option is to cut and burn them.
<G-vec00555-002-s057><cut_off.abschneiden><de> Nach vielen vergeblichen Versuchen bleibt nur die Möglichkeit, die kranken Bäume abzuschneiden und zu verbrennen.
<G-vec00555-002-s058><cut_off.abschneiden><en> Product Description This Selectable Portable 3G Cell Phone WiFi Jammer & GPS Signal Jammer that you are viewing here is the new designed signal jammer that is designed with the ability to cut off the signals of GSM, DCS, PCS, 3G,4G, 4G LTE,4G WiMax and WiFi GPS, i at the same time.
<G-vec00555-002-s058><cut_off.abschneiden><de> Produkt-Beschreibung Dieser auswählbare Handy-WiFi-Störsender des Portable-3G u. GPS-Signal-Störsender, dass Sie hier ansehen, ist der neue entworfene Signalstörsender, der mit der Fähigkeit, die Signale von G/M, von DCS, von PCS, von 3G, von 4G, von 4G LTE, von 4G WiMax und von GPS Lojack abzuschneiden entworfen ist, i gleichzeitig.
<G-vec00555-002-s059><cut_off.abschneiden><en> This allows the player running at him enough time to put pressure on him and cut off other options.
<G-vec00555-002-s059><cut_off.abschneiden><de> Dies gibt dem jeweils anlaufenden Spieler Zeit, ihn unter Druck zu setzen und weitere Optionen abzuschneiden.
<G-vec00555-002-s060><cut_off.abschneiden><en> A stove cut off may be used to cut off gas or power after a specified time.
<G-vec00555-002-s060><cut_off.abschneiden><de> Ein abgeschnittener Ofen wird verwendet möglicherweise, um Gas oder Leistung nach einer festgelegten Zeit abzuschneiden.
<G-vec00555-002-s061><cut_off.abschneiden><en> The heat can damage your curl pattern and the only way to remedy the damage is to cut the torched hair off.
<G-vec00555-002-s061><cut_off.abschneiden><de> Die Hitze kann die Struktur deiner Locken schädigen und die einzige Möglichkeit, diese Schäden zu heilen, ist es die verbrannten Haare abzuschneiden.
<G-vec00555-002-s062><cut_off.abschneiden><en> The girl was very impressed when her father told her that their country doctor easily could cut off a man's arm or leg, or even rip the belly and pull out the sick inside.
<G-vec00555-002-s062><cut_off.abschneiden><de> Das Mädchen war sehr beeindruckt, als der Vater ihm erzählte, dass es ihrem Landarzt nichts ausmacht, einen Arm oder ein Bein einem Menschen abzuschneiden oder sogar den Bauch zu reiβen und das Innere des Patienten herauszuziehen.
<G-vec00555-002-s063><cut_off.abschneiden><en> "I have run all the way in order to cut you off, Dr. Watson," said she.
<G-vec00555-002-s063><cut_off.abschneiden><de> It seems, „Ich bin den ganzen Weg gerannt, um Ihnen den Weg abzuschneiden, Dr. Watson“, sagte sie.
<G-vec00555-002-s064><cut_off.abschneiden><en> It could be set, using a decibel meter to provide a visual warning when the sound level at the neighbours property exceeded 45dB and to cut off mains power from the performers equipment if they continually ignored the warning lights.
<G-vec00555-002-s064><cut_off.abschneiden><de> Es konnte mit einem Dezibel-Meter gesetzt werden, um eine Sehwarnung zur Verfügung zu stellen, als der Geräuschpegel am Nachbareigentum 45 DB überschritten hat und Hauptmacht von der Darstellerausrüstung abzuschneiden, wenn sie ständig die Warnlichter ignoriert haben.
<G-vec00555-002-s065><cut_off.abschneiden><en> Crop (in the standalone version) lets you cut off unwanted areas in the image.
<G-vec00555-002-s065><cut_off.abschneiden><de> Das Freistellen-Werkzeug (nur in der Standalone-Version verfügbar) erlaubt es, unnötige Teile des Bildes abzuschneiden.
<G-vec00555-002-s066><cut_off.abschneiden><en> conventional vehicle door includes a complete outer skin with a window and lock hardware to cut off a vehicle cabin completely from the environment.
<G-vec00555-002-s066><cut_off.abschneiden><de> Eine herkömmliche Fahrzeugtür beinhaltet eine vollständige Außenhaut mit einem Fenster und Riegelhardware, um eine Fahrzeugkabine vollständig von der Umwelt abzuschneiden.
<G-vec00555-002-s067><cut_off.abschneiden><en> Beforehand, follow the roll of wallpaper to measure and cut off several strips, the size of the height of the pasted wall.
<G-vec00555-002-s067><cut_off.abschneiden><de> Zuvor folgen Sie der Rolle der Tapete, um mehrere Streifen zu messen und abzuschneiden, die Größe der Höhe der eingefügten Wand.
<G-vec00555-002-s068><cut_off.abschneiden><en> When the operation pressure of the mud pump is greater than the setting pressure, the discharge pressure of the mud pump push piston rod and the piston of the safety valve so as to open the shear pin board, and cut off the shear pin to immediately discharge the pressure of the mud pump from the outlet of the safety valve, thus to protect the mud pump effectively.
<G-vec00555-002-s068><cut_off.abschneiden><de> Wenn der Betriebsdruck der Schlammpumpe größer als der Einstelldruck ist, drückt der Abgabedruck der Schlammpumpe die Kolbenstange und den Kolben des Sicherheitsventils, um die Scherbolzenplatte zu öffnen und den Scherbolzen abzuschneiden, um sich sofort zu entladen der Druck der Schlammpumpe vom Auslass des Sicherheitsventils, um so die Schlammpumpe effektiv zu schützen.
<G-vec00555-002-s069><cut_off.abschneiden><en> Try to hit the zombies’ heads to cut them off with the ball for double score.
<G-vec00555-002-s069><cut_off.abschneiden><de> Versuchen Sie, die zombiesâ € ™ Köpfe, um sie abzuschneiden mit dem Ball für doppelte Punktzahl zu treffen.
<G-vec00555-002-s070><cut_off.abschneiden><en> He behaved in a noble-minded way towards them, but before setting them free, he ordered to cut off the nose of Rozhoň by a sickle as an exemplary act.
<G-vec00555-002-s070><cut_off.abschneiden><de> Er verhielt sich zu den Besiegten großzügig, jedoch bevor er ihnen die Freiheit schenkte, hatte er befohlen, Rozhoň zur Warnung die Nase mit Sichel abzuschneiden.
<G-vec00555-002-s071><cut_off.abschneiden><en> That is the reason why in some countries one is required to report capital wrong doings so to cut off ways to develop usuals from wrongs and gain benefit from the wrong deeds done by others in tolerating them, better taking part.
<G-vec00555-002-s071><cut_off.abschneiden><de> Das ist der Grund, warum es in manchen Ländern von einem gefordert wird, kapitales Fehlverhalten auf/anzuzeigen, um so die Gefahr des Üblichwerdens von Fehlhandlungen, und sich an Fehlhandlungen (auch mit Mitteln des Duldens) zu bereichern, abzuschneiden.
<G-vec00555-002-s072><cut_off.abschneiden><en> Many prefer to cut the spike entirely off and count on the plant building up its energy for a renewed larger new spike next growing season.
<G-vec00555-002-s072><cut_off.abschneiden><de> Viele ziehen es vor, die Spitze völlig abzuschneiden und auf dem Betrieb zu zählen, der seine Energie für eine erneuerte größere neue Spitze folgende wachsende Jahreszeit aufbaut.
<G-vec00555-002-s073><cut_off.abschneiden><en> While rolling the wrapper skin, to prevent the double folding of dough skin that causes uneven taste, a roller cutter is equipped to cut off the extra dough skin.
<G-vec00555-002-s073><cut_off.abschneiden><de> Während die Umhüllungshaut gerollt wird, um das doppelte Falten der Teighaut zu verhindern, das einen ungleichmäßigen Geschmack verursacht, ist ein Rollenschneider ausgerüstet, um die zusätzliche Teighaut abzuschneiden.
<G-vec00555-002-s074><cut_off.abschneiden><en> Your neighbor was correct to cut off the bad roots.
<G-vec00555-002-s074><cut_off.abschneiden><de> Dein Nachbar war korrekt, die schlechten Wurzeln abzuschneiden.
<G-vec00555-002-s075><cut_off.abschneiden><en> To cut supply lines to England Germany starts unrestricted submarine warfare in 1917.
<G-vec00555-002-s075><cut_off.abschneiden><de> Um die Nachschublinien der Briten abzuschneiden, startet Deutschland 1917 einen uneingeschränkten U-Boot-Krieg.
<G-vec00555-002-s095><cut_off.auschneiden><en> Great advancements have been achieved in the Dynamic Photo function, which enables users to cut out images of a moving subject and paste them on a different still image that acts as a background.
<G-vec00555-002-s095><cut_off.auschneiden><de> Die Dynamic Photo-Funktion, mit der ein sich bewegendes Motiv ausgeschnitten und auf ein anderes unbewegtes Hintergrundbild gesetzt werden kann, wurde erheblich verbessert.
<G-vec00555-002-s096><cut_off.auschneiden><en> On the latter I stamped the first part of the sentiment and then fussy cut it out before stamping the second part as well.
<G-vec00555-002-s096><cut_off.auschneiden><de> Auf das weiße Papier habe ich den Spruch gestempelt und es dann per Hand "ausgeschnitten" bevor ich dann noch den zweiten Teil hinzugestempelt habe.
<G-vec00555-002-s097><cut_off.auschneiden><en> I stamped it once with black ink, once heat embossed it using golden embossing powder, then cut those out and put them on brown cardstock.
<G-vec00555-002-s097><cut_off.auschneiden><de> Der ist einmal mit schwarzer Tinte und einmal golden embossed gestempelt, ausgeschnitten und auf braunen Cardstock geklebt.
<G-vec00555-002-s098><cut_off.auschneiden><en> With large honeycombs, the curves are cut out of the sheet and tapered at each end.
<G-vec00555-002-s098><cut_off.auschneiden><de> Bei den großen Waben werden die Kurven an jedem Ende verjüngt und aus der Platte ausgeschnitten.
<G-vec00555-002-s099><cut_off.auschneiden><en> stamped the boy and girl images, colored them and then cut them out trimming closely.
<G-vec00555-002-s099><cut_off.auschneiden><de> Ich habe den Jungen und das Mädchen abgestempelt, coloriert und dann anschließend konturengenau ausgeschnitten.
<G-vec00555-002-s100><cut_off.auschneiden><en> I stamped the flowers again, wiped them with Distress Inks in colour, cut them out and glued them on.
<G-vec00555-002-s100><cut_off.auschneiden><de> Die Blüten habe ich nochmal extra gestempelt, mit Distress Inks farbig gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s101><cut_off.auschneiden><en> Some children cut out their footprints and draw something on it that deserves protection for them.
<G-vec00555-002-s101><cut_off.auschneiden><de> Einige Kinder haben ihren Fußabdruck ausgeschnitten und etwas aus der Natur darauf gemalt, was für sie besonders schützenswert ist.
<G-vec00555-002-s102><cut_off.auschneiden><en> Where it previously had to be tediously cut and adjusted, the pipe can now easily be inserted through the prepared inflow opening and the rainwater hopper mounted directly on the wall.
<G-vec00555-002-s102><cut_off.auschneiden><de> Wo bisher langwierig ausgeschnitten und angepasst werden musste, kann das Rohr jetzt spielend leicht in die vorbereitete Zulauföffnung eingesteckt und der Regenfangkasten direkt an der Wand montiert werden.
<G-vec00555-002-s103><cut_off.auschneiden><en> The image is colored with Copics and cut out by hand.
<G-vec00555-002-s103><cut_off.auschneiden><de> Das Motiv ist mit Copics coloriert und ausgeschnitten.
<G-vec00555-002-s104><cut_off.auschneiden><en> As a sheet material, for example textile materials such as woven or knitted fabrics, but also films are also conceivable, of which the markings are, for example punched or cut out.
<G-vec00555-002-s104><cut_off.auschneiden><de> Als flächiges Material sind zB textile Materialien wie Gewebe oder Gewirke, aber auch Folien denkbar, aus denen die Markierungen zB ausgestanzt oder ausgeschnitten sind.
<G-vec00555-002-s105><cut_off.auschneiden><en> Der Carstock mit den Motiven (eine Maus aus dem Mice Time to Celebrate Set, The paper with the stamped on images (a mouse from the Mice Time to Celebrate stamp set, one of the bears from the Joyful Heart Bears set and a piglet from the Piggy Pebbles set) ist glued behind the frame and the images were cut out so the pieces that would've been covered by the frame are on top of it.
<G-vec00555-002-s105><cut_off.auschneiden><de> Den weißen Cardstock im Hintergrund, den ich schwarz gemattet und auf eine weiße Grundkarte geklebt habe, ist mit Distress Ink Tumbled Glass und verschiedenen "Flecken" aus dem Distressed ein Bär aus dem Joyful Heart Bears Set und noch ein Schweinchen aus dem Piggy Pebbles Set) ist hinter den Rahmen geklebt und die Motive so ausgeschnitten, dass die eigentlich vom Rahmen abgedeckten Teile der Tiere vorne über den Rahmen überstehen.
<G-vec00555-002-s106><cut_off.auschneiden><en> I wiped the elephants with grey paint, cut them out and glued them on.
<G-vec00555-002-s106><cut_off.auschneiden><de> Die Elefanten habe ich mit grauer Farbe gewischt, ausgeschnitten und aufgeklebt.
<G-vec00555-002-s107><cut_off.auschneiden><en> Comprehensive editing functions (e.g., block functions such as cut, copy, paste, move, even directly moving into other windows without using the clipboard).
<G-vec00555-002-s107><cut_off.auschneiden><de> Umfangreiche Editierfunktionen (Blöcke können ausgeschnitten, eingefügt, verschoben oder in andere Programmfenster kopiert werden, auch direkt in andere Fenster ohne den Umweg über das Clipboard).
<G-vec00555-002-s108><cut_off.auschneiden><en> From the dense cardboard, two identical figures are cut out.
<G-vec00555-002-s108><cut_off.auschneiden><de> Aus dem dichten Karton werden zwei identische Figuren ausgeschnitten.
<G-vec00555-002-s109><cut_off.auschneiden><en> And some of them, being cut out, can come to be an object on the wall.
<G-vec00555-002-s109><cut_off.auschneiden><de> Einige werden dann ausgeschnitten und so kann man sie als eine Art Objekt an die Wand hängen.
<G-vec00555-002-s110><cut_off.auschneiden><en> The span is 2 meters and own parts were cut out by hand for the feathers of the wings.
<G-vec00555-002-s110><cut_off.auschneiden><de> Die Spannweite liegt bei 2 Metern und es wurden für die Federn der Flügel eigene Teile per Hand ausgeschnitten.
<G-vec00555-002-s111><cut_off.auschneiden><en> In order to ensure the desired quality standard, these small openings must be cut out precisely.
<G-vec00555-002-s111><cut_off.auschneiden><de> Um den gewünschten Qualitätsstandard gewährleisten zu können, müssen diese kleinen Öffnungen sehr passgenau ausgeschnitten werden.
<G-vec00555-002-s112><cut_off.auschneiden><en> Each photo can be cut out and send as a postcard.
<G-vec00555-002-s112><cut_off.auschneiden><de> Jedes Foto kann danach als Postkarte ausgeschnitten und weitergeschickt werden.
<G-vec00555-002-s113><cut_off.auschneiden><en> Make a collage of images you cut out from magazines by overlapping them on your cardstock.
<G-vec00555-002-s113><cut_off.auschneiden><de> Erstelle eine Collage aus Bildern, die du aus Zeitschriften ausgeschnitten hast, indem du sie überlappend auf dem Karton anbringst.
<G-vec00555-002-s076><cut_off.ausrotten><en> 6I have cut off nations; their battlements are desolate; I have made their streets waste, so that none passeth by; their cities are destroyed, so that there is no man, so that there is no inhabitant.
<G-vec00555-002-s076><cut_off.ausrotten><de> 6Ich habe Nationen ausgerottet, ihre Zinnen sind verödet; ich habe ihre Straßen verwüstet, daß niemand darüber zieht; ihre Städte sind verheert, daß niemand da ist, kein Bewohner mehr.
<G-vec00555-002-s077><cut_off.ausrotten><en> 17:14 For it is the life of all flesh; the blood of it is for the life thereof: therefore I said unto the children of Israel, All of you shall eat the blood of no manner of flesh: for the life of all flesh is the blood thereof: whosoever eats it shall be cut off.
<G-vec00555-002-s077><cut_off.ausrotten><de> 14 Denn des Leibes Leben ist in seinem Blut, solange es lebt; und ich habe den Kindern Israel gesagt: Ihr sollt keines Leibes Blut essen; denn des Leibes Leben ist in seinem Blut; wer es ißt, der soll ausgerottet werden.
<G-vec00555-002-s078><cut_off.ausrotten><en> 15 Ex 12, 15 Seven days shall ye eat unleavened bread; even the first day ye shall put away leaven out of your houses: for whosoever eateth leavened bread from the first day until the seventh day, that soul shall be cut off from Israel.
<G-vec00555-002-s078><cut_off.ausrotten><de> 15 Ex 12, 15 Sieben Tage sollt ihr Ungesäuertes essen; ja, am ersten Tage sollt ihr den Sauerteig aus euren Häusern wegtun; denn jeder, der Gesäuertes isset, von dem ersten Tage bis zu dem siebten Tage, selbige Seele soll ausgerottet werden aus Israel.
<G-vec00555-002-s079><cut_off.ausrotten><en> They are preserved forever, But the descendants of the wicked shall be cut off.
<G-vec00555-002-s079><cut_off.ausrotten><de> Ewiglich werden sie bewahrt, aber das Geschlecht der Frevler wird ausgerottet.
<G-vec00555-002-s080><cut_off.ausrotten><en> 48:9 For my name's sake will I defer my anger, and for my praise will I refrain for thee, {k} that I cut thee not off.
<G-vec00555-002-s080><cut_off.ausrotten><de> 9 Um meines Namens willen bin ich geduldig, und um meines Ruhms willen will ich mich dir zugut enthalten, daß du nicht ausgerottet werdest.
<G-vec00555-002-s081><cut_off.ausrotten><en> 20 But if those who are unclean do not purify themselves, they must be cut off from the community, because they have defiled the sanctuary of the Lord. The water of cleansing has not been sprinkled on them, and they are unclean.
<G-vec00555-002-s081><cut_off.ausrotten><de> 20 Wer aber unrein wird und sich nicht entsündigen will, der soll ausgerottet werden aus der Gemeinde; denn er hat das Heiligtum des HERRN unrein gemacht und ist nicht mit Reinigungswasser besprengt; darum ist er unrein.
<G-vec00555-002-s082><cut_off.ausrotten><en> [4] Behold, I have divided unto you by lot these nations that remain, to be an inheritance for your tribes, from Jordan, with all the nations that I have cut off, even unto the great sea westward.
<G-vec00555-002-s082><cut_off.ausrotten><de> 23:4 Seht, ich habe euch diese übriggebliebenen Völker durch das Los zugeteilt, einem jeden Stamm sein Erbteil, vom Jordan an, und alle Völker, die ich ausgerottet habe bis an das große Meer, wo die Sonne untergeht.
<G-vec00555-002-s083><cut_off.ausrotten><en> 21 And if anyone touches an unclean thing, whether human uncleanness or an unclean beast or any unclean detestable creature, and then eats some flesh from the sacrifice of the Lord's peace offerings, that person shall be cut off from his people.”
<G-vec00555-002-s083><cut_off.ausrotten><de> 7,21 Und wenn jemand mit etwas Unreinem in Berührung gekommen ist, es sei ein unreiner Mensch, ein unreines Vieh oder was sonst ein Greuel ist, und dann vom Fleisch des Dankopfers ißt, das dem HERRN gehört, der wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s084><cut_off.ausrotten><en> 9 and bringeth it not unto the door of the tent of meeting, to sacrifice it unto Jehovah; that man shall be cut off from his people.
<G-vec00555-002-s084><cut_off.ausrotten><de> 9und bringt es nicht vor die Tür der Stiftshütte, um es dem HERRN zu opfern, der wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s085><cut_off.ausrotten><en> However, many biblical scholars assert that this interpretation is false, and that the phrase "cut off from among their people" refers instead to sickness and early death sent by the all-knowing Yahweh himself.
<G-vec00555-002-s085><cut_off.ausrotten><de> Theologen sind jedoch heute der Ansicht, dass dies falsch ist und dass der Ausdruck „aus ihrem Volk ausgerottet werden" sich auf Krankheit und frühen Tod bezieht, den der allmächtige Gott schickt.
<G-vec00555-002-s086><cut_off.ausrotten><en> As for other flesh, anyone who is clean may eat such flesh. 20But the person who eats the flesh of the sacrifice of peace offerings which belong to the Lord, in his uncleanness, that person shall be cut off from his people.
<G-vec00555-002-s086><cut_off.ausrotten><de> Und was das Fleisch betrifft, jeder Reine darf das Fleisch essen; 20aber die Seele, welche Fleisch von dem Friedensopfer isset, das Jehova gehört, und ihre Unreinigkeit ist an ihr, selbige Seele soll ausgerottet werden aus ihren Völkern.
<G-vec00555-002-s087><cut_off.ausrotten><en> 30:38 Whoever makes any like it, for its sweet smell, will be cut off from his people.
<G-vec00555-002-s087><cut_off.ausrotten><de> 30:38 Wer es macht, damit er sich an dem Geruch erfreue, der soll ausgerottet werden aus seinem Volk.
<G-vec00555-002-s088><cut_off.ausrotten><en> Therefore every one that eateth it shall 9 bear his iniquity, because he hath profaned the hallowed thing of the LORD: and that soul shall be cut off from among his people.
<G-vec00555-002-s088><cut_off.ausrotten><de> 19,7 Wird aber am dritten Tage davon gegessen, so ist es ein Greuel und wird nicht wohlgefällig sein; 19,8 und wer davon ißt, muss seine Schuld tragen, weil er das Heilige des HERRN entheiligt hat, und ein solcher Mensch wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s089><cut_off.ausrotten><en> 34 Look unto Jehovah, and keep His way, And He doth exalt thee to possess the land, In the wicked being cut off -- thou seest!
<G-vec00555-002-s089><cut_off.ausrotten><de> Harre auf den HERRN und halte seinen Weg, so wird er dich erhöhen, daß du das Land erbest; du wirst es sehen, daß die Gottlosen ausgerottet werden.
<G-vec00555-002-s090><cut_off.ausrotten><en> 14 The uncircumcised male who is not circumcised in the flesh of his foreskin, that soul shall be cut off from his people.
<G-vec00555-002-s090><cut_off.ausrotten><de> 14Wenn aber ein Männlicher nicht beschnitten wird an seiner Vorhaut, wird er ausgerottet werden aus seinem Volk, weil er meinen Bund gebrochen hat.
<G-vec00555-002-s091><cut_off.ausrotten><en> 27 Whatever soul it be that eateth any manner of blood, that soul shall be cut off from his peoples.
<G-vec00555-002-s091><cut_off.ausrotten><de> 27Jeder, der Blut isst, wird ausgerottet werden aus seinem Volk.
<G-vec00555-002-s092><cut_off.ausrotten><en> 23:4 Behold, I have divided to you by lot these nations that remain, to be an inheritance for your tribes, from Jordan, with all the nations that I have cut off, even to the great sea westward.
<G-vec00555-002-s092><cut_off.ausrotten><de> 23:4 Sehet, ich habe euch die übrigen Völker durchs Los zugeteilet, einem jeglichen Stamm sein Erbteil, vom Jordan an, und alle Völker, die ich ausgerottet habe, und am großen Meer gegen der Sonnen Untergang.
<G-vec00555-002-s093><cut_off.ausrotten><en> 21 Anyone who touches something unclean—whether human uncleanness or an unclean animal or any unclean creature that moves along the groundb —and then eats any of the meat of the fellowship offering belonging to the LORD must be cut off from their people.’ ”
<G-vec00555-002-s093><cut_off.ausrotten><de> 21 Und wenn eine Person irgend etwas Unreines anrührt, die Unreinheit eines Menschen oder ein unreines Vieh oder irgend etwas unreines Abscheuliches, und sie ißt vom Fleisch des Heilsopfers, das dem HERRN gehört: diese Person soll aus ihren Volksgenossen ausgerottet werden.
<G-vec00555-002-s094><cut_off.ausrotten><en> 18If there is a man who lies with a menstruous woman and uncovers her nakedness, he has laid bare her flow, and she has exposed the flow of her blood; thus both of them shall be cut off from among their people.
<G-vec00555-002-s094><cut_off.ausrotten><de> 18Und wenn ein Mann bei einem Weibe liegt in ihrer Krankheit und ihre Blöße aufdeckt, so hat er ihre Quelle enthüllt, und sie hat die Quelle ihres Blutes aufgedeckt; sie sollen beide ausgerottet werden aus der Mitte ihres Volkes.
<G-vec00555-002-s114><cut_off.ausschneiden><en> You need to do some video editing: cut unnecessary parts out (otherwise the whole thing can easily become boring; the professional movie makers cut pretty much out, some episodes are later included as specials on the DVD, but they don't appear in the actual movie; there is also a difference between theatrical and DVD (extended) editions), add transitions between episodes to make the movie smooth, add titles or subtitles where needed, emphasize some moments by zooming in while showing the whole picture in a smaller box (picture in picture), and so on.
<G-vec00555-002-s114><cut_off.ausschneiden><de> Sie brauchen eine Videobearbeitung durchzuführen: nicht nötige Teilen ausschneiden (sonst kann das Ganze langweilig werden; bei professionellen Filmen scheidet man ziemlich viel aus, manche Episoden werden später als Extras zur DVD hinzugefügt, sie erscheinen aber nicht im Film; es gibt auch einen Unterschied zwischen Kino- und DVD-Versionen), Übergänge zwischen Episoden hinzufügen, Untertitel und andere Beschriftungen hinzufügen, einige Momenten mit Zoom betonen und das ganze Bild in kleinerer Box zeigen (Bild im Bild) usw.
<G-vec00555-002-s115><cut_off.ausschneiden><en> + Trim, cut and crop your photos and video clips.
<G-vec00555-002-s115><cut_off.ausschneiden><de> + Trimmen, Ausschneiden und Beschneiden Ihrer Fotos.
<G-vec00555-002-s116><cut_off.ausschneiden><en> Magic Wand Edit Commands: You can now use the cut, copy, paste, and duplicate edit commands on magic wand selections, allowing you to break models up into multiple pieces.
<G-vec00555-002-s116><cut_off.ausschneiden><de> Bearbeitungsbefehle für den Zauberstab: Sie können jetzt die Bearbeitungsbefehle „Ausschneiden“, „Kopieren“, „Einfügen“ und „Duplizieren“ auf Zauberstab-Auswahlen anwenden, um Modelle in mehrere Teile zu unterteilen.
<G-vec00555-002-s117><cut_off.ausschneiden><en> Then hold the orange over the bowl and cut the orange fillets out of the fruit.
<G-vec00555-002-s117><cut_off.ausschneiden><de> Danach die Orange über der Schüssel halten und Orangenfilets aus der Frucht ausschneiden.
<G-vec00555-002-s118><cut_off.ausschneiden><en> Select the content frame, and choose Edit > Cut.
<G-vec00555-002-s118><cut_off.ausschneiden><de> Markieren Sie den Inhaltsrahmen und wählen Sie „Bearbeiten“ > „Ausschneiden“.
<G-vec00555-002-s119><cut_off.ausschneiden><en> With a knife cut out a hole through the circle and the pie.
<G-vec00555-002-s119><cut_off.ausschneiden><de> Mit dem Messer aus diesm Kreis ein Loch ausschneiden.
<G-vec00555-002-s120><cut_off.ausschneiden><en> When you're working with your files in FX File Explorer, you'll find the classic options you'd expect from a the desktop computer: copy, paste, cut, create, delete, rename.
<G-vec00555-002-s120><cut_off.ausschneiden><de> In FX File Explorer findet man alle Funktionen die man auch vom Desktop-PC kennt: Kopieren, Einfügen, Ausschneiden, Erstellen, Löschen, Umbenennen.
<G-vec00555-002-s121><cut_off.ausschneiden><en> Cut out flowers - cubic...
<G-vec00555-002-s121><cut_off.ausschneiden><de> Blumen ausschneiden -...
<G-vec00555-002-s122><cut_off.ausschneiden><en> Cut 2 small squares out of the blue Gaffer tape and glue them to the head to make the eyes.
<G-vec00555-002-s122><cut_off.ausschneiden><de> Aus dem blauen Gaffer Tape 2 kleine Quadrate ausschneiden und als Augen auf den Kopf kleben.
<G-vec00555-002-s123><cut_off.ausschneiden><en> You can cut/copy/paste/move/delete/rename files using Tabbles.
<G-vec00555-002-s123><cut_off.ausschneiden><de> Du kannst Dateien ausschneiden/kopieren/einfügen/bewegen /löschen/umbenennen.
<G-vec00555-002-s124><cut_off.ausschneiden><en> If you have lousy handwriting, and no to/from cards or stickers, you can cut a square of coordinating wrapping paper, fold it into a "card", and tape it in place.
<G-vec00555-002-s124><cut_off.ausschneiden><de> Wenn du eine lausige Handschrift hast und keine von/an Karten oder Sticker, kannst du ein Quadrat aus abgestimmtem Geschenkpapier ausschneiden, es zu einer "Karte" falten und es festkleben.
<G-vec00555-002-s125><cut_off.ausschneiden><en> You can cut out pictures and set the area as a background image, the one you like best.
<G-vec00555-002-s125><cut_off.ausschneiden><de> Du kannst Fotos ausschneiden und den Bereich als Hintergrundbild einstellen, der dir am besten gefällt.
<G-vec00555-002-s126><cut_off.ausschneiden><en> Click the Cut button on the toolbar to move the folder and its contents to the clipboard.
<G-vec00555-002-s126><cut_off.ausschneiden><de> Klicken Sie in der Symbolleiste auf die Schaltfläche Ausschneiden, um den Ordner und seinen Inhalt in die Zwischenablage zu verschieben.
<G-vec00555-002-s127><cut_off.ausschneiden><en> When you scroll down, you will see that Google Cloud has built a web-based interface that lets you cut and paste any text into the page.
<G-vec00555-002-s127><cut_off.ausschneiden><de> Wenn Sie nach unten scrollen, werden Sie sehen, dass Google Cloud eine webbasierte Benutzeroberfläche entwickelt hat, mit der Sie jeden beliebigen Text in die Seite ausschneiden und einfügen können.
<G-vec00555-002-s128><cut_off.ausschneiden><en> If you selected an entire row or column and you select Edit > Cut, the entire row or column is removed from the table (not just the contents of the cells).
<G-vec00555-002-s128><cut_off.ausschneiden><de> Wenn Sie eine ganze Zeile oder Spalte und „Bearbeiten“ > „Ausschneiden“ ausgewählt haben, wird die ganze Zeile oder Spalte (und nicht nur der Inhalt der Zellen) aus der Tabelle entfernt.
<G-vec00555-002-s129><cut_off.ausschneiden><en> To make the beak for the penguin, have the child cut a small triangle out of the orange construction paper.
<G-vec00555-002-s129><cut_off.ausschneiden><de> Lasse das Kind, um den Schnabel für den Pinguin zu machen, ein kleines Dreieck aus dem orangen Bastelpapier ausschneiden.
<G-vec00555-002-s130><cut_off.ausschneiden><en> The default shortcuts Ctrl+C (copy), Ctrl+X (cut) and Ctrl+V (paste) can be used for editing.
<G-vec00555-002-s130><cut_off.ausschneiden><de> Die Standard-Tastenkürzel Strg+C (Kopieren), Strg+X (Ausschneiden) und Strg+V (Einfügen) können für das Bearbeiten verwendet werden.
<G-vec00555-002-s131><cut_off.ausschneiden><en> C. Cut: You can use the cut option to move a component from one place to another in the adaptive form.
<G-vec00555-002-s131><cut_off.ausschneiden><de> D. Ausschneiden: Sie können die Option zum Ausschneiden verwenden, um eine Komponente von einer Position in der interaktiven Kommunikation an eine andere Position zu verschieben.
<G-vec00555-002-s228><cut_off.kürzen><en> On the back of 2012 when banks added more than 534.6 tons to gold reserves, the most since 1964, the move suggests a possible shift in dynamics as several banks have now cut their gold forecasts for 2013.
<G-vec00555-002-s228><cut_off.kürzen><de> Nach 2012, als die Banken mehr als 534,6 Tonnen an Goldreserven aufstockten, die größte Reserve seit 1964, zeigt diese Bewegung, dass die Dynamik vor einer Wende steht, da zahlreiche Banken nun ihre Gold-Prognosen für 2013 gekürzt haben.
<G-vec00555-002-s229><cut_off.kürzen><en> Though UK development funds have been made available to support health systems, with some positive results, the UK recently cut its aid to both countries as it promotes greater private healthcare across Africa.
<G-vec00555-002-s229><cut_off.kürzen><de> Obwohl öffentliche Gesundheitssysteme mit britischen Entwicklungshilfegeldern gefördert wurden, mit einigen positiven Ergebnissen, hat Großbritannien kürzlich seine Entwicklungshilfe an beide Länder gekürzt, da es überall in Afrika eine private Gesundheitsversorgung fördert.
<G-vec00555-002-s230><cut_off.kürzen><en> The World Bank predicts that, even under the most optimistic growth and reform scenarios, total public spending would have to be cut by an unprecedented 6.5 percent of GDP.
<G-vec00555-002-s230><cut_off.kürzen><de> Die Weltbank geht davon aus, dass sogar unter Voraussetzung der optimistischsten Wachstums- und Reformszenarien die öffentlichen Ausgaben um nie da gewesene 6,5 Prozent des BIP gekürzt werden müssten.
<G-vec00555-002-s231><cut_off.kürzen><en> Wages would have to be cut by means of inflation, the profit rate supported by lowering the interest rate, and the remaining unemployment absorbed by public works, until these measures produced the beginning of a new prosperity, at which point the economy could be left once again to the automatic mechanism of the market.
<G-vec00555-002-s231><cut_off.kürzen><de> Die Löhne müßten auf dem Wege der Inflation gekürzt, die Profitrate durch die Senkung der Zinsrate gestützt, und der verbleibende Rest der Arbeitslosigkeit durch öffentliche Ausgaben aufgesaugt werden, bis sich durch all diese Maßnahmen eine neue Konjunktur herausbildet, womit man die Wirtschaft für eine weitere Etappe dem Automatismus des Marktes überlassen könnte.
<G-vec00555-002-s232><cut_off.kürzen><en> (Brussels, 09.05.2018) According to a proposal tabled by the EU Commissioner for Budget and Human Resources Günther Oettinger, the agriculture budget is to be cut by five percent.
<G-vec00555-002-s232><cut_off.kürzen><de> (Brüssel, 09.05.2018) Nach Vorschlag von EU-Haushaltskommissar Günther Oettinger soll der Agrarhaushalt um fünf Prozent gekürzt werden.
<G-vec00555-002-s233><cut_off.kürzen><en> A second version, now cut to two acts, was staged at the Theater an der Wien in 1806 — with greater success, but with no demand for further performances.
<G-vec00555-002-s233><cut_off.kürzen><de> Eine zweite Fassung, nunmehr gekürzt auf zwei Akte, konnte 1806 im Theater an der Wien aufgeführt werden – mit mehr Erfolg, allerdings ohne weitere Nachfrage.
<G-vec00555-002-s234><cut_off.kürzen><en> That is why we have restore funds the Council has cut for research and development programmes, such as the EU’s Horizon 2020; aid for small and medium-sized enterprises; education, including the student mobility programme Erasmus+; and aid for the most deprived.
<G-vec00555-002-s234><cut_off.kürzen><de> Deshalb haben wir die Mittel wiedereingesetzt, die der Rat für Forschungs- und Entwicklungsprogramme gekürzt hat, beispielsweise Horizont 2020; Unterstützung für kleine und mittelgroße Unternehmen; Bildung, einschließlich des Studentenmobilitätsprogramms Erasmus+; und die Hilfe für bedürftige Bürgerinnen und Bürger.
<G-vec00555-002-s235><cut_off.kürzen><en> The last block of characters, read to the variable, will be cut to the amount of bytes really read.
<G-vec00555-002-s235><cut_off.kürzen><de> Der letzte Block der zu lesenden Zeichen wird in der Variable auf die tatsächliche benötigte Menge an Bytes gekürzt.
<G-vec00555-002-s236><cut_off.kürzen><en> The rear of the vehicle frame may be cut up to the first cross member behind the rear of the last axle of the suspension.
<G-vec00555-002-s236><cut_off.kürzen><de> Der hintere Teil des Fahrzeugrahmens darf bis zum ersten Querträger hinter dem hintersten Punkt der Radaufhängung der letzten Achse gekürzt werden.
<G-vec00555-002-s237><cut_off.kürzen><en> Can be cut every 3 LEDs (12V) / 6 LEDs (24V).
<G-vec00555-002-s237><cut_off.kürzen><de> Die Leiste kann alle 5cm(12V) / 10cm(24V) gekürzt werden.
<G-vec00555-002-s238><cut_off.kürzen><en> And whenever they are exposed, or their funding is cut, they scream that it is due to a right-wing plot.
<G-vec00555-002-s238><cut_off.kürzen><de> Und wo immer sie öffentlich blossgestellt werden oder ihre Finanzierung gekürzt wird, schreien sie, das sei Folge einer rechten Verschwörung.
<G-vec00555-002-s239><cut_off.kürzen><en> Over all, I still got a slight impression, that this set tonight has been even a bit cut down, due to the circumstances.
<G-vec00555-002-s239><cut_off.kürzen><de> Alles in allem kann ich mich aber des Eindrucks nicht erwehren, dass das Set noch mal um einige Tracks gekürzt wurde, auf Grund der Umstände.
<G-vec00555-002-s240><cut_off.kürzen><en> Since I am a little bit too small for a floor-length coat, I cut mine.
<G-vec00555-002-s240><cut_off.kürzen><de> Da ich mich aber für einen bodenlangen Mantel zu klein finde, habe ich den Mantel gekürzt.
<G-vec00555-002-s241><cut_off.kürzen><en> Just tell us if you want to have cut her watchband prior to shipment.
<G-vec00555-002-s241><cut_off.kürzen><de> Sagen Sie uns einfach, wenn Sie ihr Uhrenarmband vor dem Versand gekürzt haben möchten.
<G-vec00555-002-s242><cut_off.kürzen><en> “Usually at other studios you create the story and two days before ‘script lock’ they tell you they have to cut the game in half, asking if you can ‘just go ahead and adjust the story,'” he laughs.
<G-vec00555-002-s242><cut_off.kürzen><de> „In anderen Studios entwirft man die Story, um zwei Tage vor der Deadline für das Skript gesagt zu bekommen, dass das Spiel um die Hälfte gekürzt werden muss, und darum gebeten wird, mal eben schnell die Story anzupassen”, lacht er.
<G-vec00555-002-s243><cut_off.kürzen><en> Fuel subsidies were cut twice this year.
<G-vec00555-002-s243><cut_off.kürzen><de> Treibstoffsubventionen wurden dieses Jahr zweimal gekürzt.
<G-vec00555-002-s244><cut_off.kürzen><en> The disciplinary sanction continues to perpetuate even today: the pension of the man is still cut by 25%.
<G-vec00555-002-s244><cut_off.kürzen><de> Heute wird dem Polizisten seine Pension deshalb immer noch strafweise um ein Viertel gekürzt.
<G-vec00555-002-s245><cut_off.kürzen><en> Originally, Lifetime had ordered 20 episodes of the series, the number was later cut to only 14.
<G-vec00555-002-s245><cut_off.kürzen><de> Ursprünglich hatte Lifetime 20 Folgen der Serie geordert, diese Zahl wurde später auf 14 gekürzt.
<G-vec00555-002-s246><cut_off.kürzen><en> The extremely durable 300 mm blade made of hardened steel can be cut to size to suit your crops.
<G-vec00555-002-s246><cut_off.kürzen><de> Dieses unverwüstliche Jätmesser aus 300mm dickem, gehärtetem Stahl kann gekürzt werden, um sich so gut wie möglich an Ihre Reihenabstände anzupassen.
<G-vec00555-002-s380><cut_off.reduzieren><en> He told the forum it made sense to cut the number in the French-speaking region.
<G-vec00555-002-s380><cut_off.reduzieren><de> Im RTS-Forum schrieb er, in der französischsprachigen Westschweiz würde es durchaus Sinn machen, die Anzahl der Geräte zu reduzieren.
<G-vec00555-002-s381><cut_off.reduzieren><en> With a corrugated box cutting machine, you will not only be able to cut the costs of packaging supplies that your company uses, but you will also be able to cut the shipping costs that your company is constantly incurring as well.
<G-vec00555-002-s381><cut_off.reduzieren><de> Mithilfe von Wellpappe-Schneidemaschinen werden Sie nicht nur die Kosten der Verpackungsmaterialien Ihres Unternehmens, sondern auch die Versandkosten reduzieren können, die Ihrem Unternehmen laufend entstehen.
<G-vec00555-002-s382><cut_off.reduzieren><en> Cut energy costs across your distributed office by 35 percent and gain 100 percent visibility into the energy usage of every device in your data center.
<G-vec00555-002-s382><cut_off.reduzieren><de> Reduzieren Sie die Stromkosten an verteilten Standorten um 35 Prozent und sorgen Sie für vollständige Transparenz hinsichtlich des Energieverbrauchs jedes einzelnen Geräts in Ihrem Rechenzentrum.
<G-vec00555-002-s383><cut_off.reduzieren><en> In October 2012, a cogeneration plant was taken into service at the company's largest production site in Wiesloch-Walldorf, Germany. In the future, this plant will cut the site's energy costs by 10 percent and save 3,700 metric tons of CO2 each year.
<G-vec00555-002-s383><cut_off.reduzieren><de> Im Oktober 2012 ging am Standort Wiesloch-Walldorf - dem größten Produktionsstandort des Unternehmens - ein Blockheizkraftwerk in Betrieb, das künftig die Energiekosten des Standortes um zehn Prozent reduzieren wird, und das jährlich 3.700 Tonnen CO2 einspart.
<G-vec00555-002-s384><cut_off.reduzieren><en> And best of all, a line with of OneStep technology can cut your total cost of ownership drastically.
<G-vec00555-002-s384><cut_off.reduzieren><de> Und das Beste: Eine Prozesslinie mit OneStep-Technologie kann Ihre Gesamtbetriebskosten drastisch reduzieren.
<G-vec00555-002-s385><cut_off.reduzieren><en> One of the features of the polarizing filter is that it can cut out reflections that appear in a water surface or glass window.
<G-vec00555-002-s385><cut_off.reduzieren><de> Ein Merkmal von Polfiltern besteht darin, dass er Spiegelungen auf Wasseroberflächen oder Fensterscheiben erheblich reduzieren kann.
<G-vec00555-002-s386><cut_off.reduzieren><en> Sorry,you have to pay it first,but we'll cut the costs in your next order(20GP).
<G-vec00555-002-s386><cut_off.reduzieren><de> Tut mir leid müssen Sie es zuerst zahlen, aber wir reduzieren die Kosten in Ihrem folgenden Auftrag (20GP).
<G-vec00555-002-s387><cut_off.reduzieren><en> Cut engineering time and costs to meet your customers' expectations.
<G-vec00555-002-s387><cut_off.reduzieren><de> Reduzieren Sie Entwicklungszeit und -kosten und erfüllen Sie die Anforderungen Ihrer Kunden.
<G-vec00555-002-s388><cut_off.reduzieren><en> They’re not supposed to cut costs; they’re supposed to improve processes.
<G-vec00555-002-s388><cut_off.reduzieren><de> Sie sollen nicht Kosten reduzieren, sondern Prozesse verbessern.
<G-vec00555-002-s389><cut_off.reduzieren><en> The electricity costs for one and two-family homes can be cut by 25 to 40 percent.
<G-vec00555-002-s389><cut_off.reduzieren><de> Die Stromkosten im Ein- und Zweifamilienhaus lassen sich um 25 bis 40 Prozent reduzieren.
<G-vec00555-002-s390><cut_off.reduzieren><en> If your insulin is high, you're likely consuming too much sugar and need to cut back.
<G-vec00555-002-s390><cut_off.reduzieren><de> Wenn der Insulinspiegel hoch ist, konsumieren Sie wahrscheinlich zu viel Zucker und müssen Ihre Zuckerzufuhr reduzieren.
<G-vec00555-002-s391><cut_off.reduzieren><en> Writing about what you are doing can help you explore and express what you are feeling as you cut back or quit using marijuana.
<G-vec00555-002-s391><cut_off.reduzieren><de> Darüber zu schreiben, was du machst, kann dir helfen, herauszufinden und auszudrücken, was du empfindest, während du versuchst, deinen Marihuanakonsum zu reduzieren.
<G-vec00555-002-s392><cut_off.reduzieren><en> Take advantage of innovative products that optimize your manufacturing process, cut your water consumption and improve pulp quality.
<G-vec00555-002-s392><cut_off.reduzieren><de> Profitieren Sie von innovativen Produkten, die Ihren Herstellungsprozess optimieren, den Wasser- und Energieverbrauch reduzieren und die Zellstoffqualität verbessern.
<G-vec00555-002-s393><cut_off.reduzieren><en> Around the world, businesses of all shapes and sizes trust us to deliver technology systems that cut complexity, quickly.
<G-vec00555-002-s393><cut_off.reduzieren><de> Überall auf der Welt vertrauen Unternehmen aller Formen und Größen uns, Technologiesysteme zu liefern, die die Komplexität schnell reduzieren.
<G-vec00555-002-s394><cut_off.reduzieren><en> This is a bottle for life which you can use to cut down your personal plastic consumption in a heartbeat.
<G-vec00555-002-s394><cut_off.reduzieren><de> Diese Flasche kann euer neuer, lebenslanger Begleiter werden, mit dem ihr auch euren persönlichen Plastikverbrauch einfach reduzieren könnt.
<G-vec00555-002-s395><cut_off.reduzieren><en> Most likely I will cut back in the next few years, continuing to see my regular clients, but not taking on any new people.
<G-vec00555-002-s395><cut_off.reduzieren><de> Höchstwahrscheinlich werde ich in den nächsten paar Jahren reduzieren, das heißt meine regelmäßigen Kunden weiterhin treffen, aber keine neuen mehr annehmen.
<G-vec00555-002-s396><cut_off.reduzieren><en> If you want to cut your company’s trade show costs drastically, there is no way around meticulous planning.
<G-vec00555-002-s396><cut_off.reduzieren><de> Wer die Messekosten seines Unternehmens drastisch reduzieren möchte, kommt nicht um eine detaillierte Planung herum.
<G-vec00555-002-s397><cut_off.reduzieren><en> As a result, the charging time for a lithium-ion battery could be cut from an hour to just 12 minutes.
<G-vec00555-002-s397><cut_off.reduzieren><de> Demzufolge ließe sich die Ladezeit eines Lithium-Ionen-Akkus von einer Stunde auf gerade einmal zwölf Minuten reduzieren.
<G-vec00555-002-s398><cut_off.reduzieren><en> According to the developers, this device can significantly cut costs related to lab tests for diseases such as HIV, syphilis, and Lyme disease.
<G-vec00555-002-s398><cut_off.reduzieren><de> Entsprechend den Entwicklern kann diese Einheit die Kosten beträchtlich reduzieren, die auf Laborversuchen für Krankheiten wie HIV, Syphilis und Lyme-Borreliose in Verbindung gestanden werden.
<G-vec00555-002-s304><cut_off.schneiden><en> Long cut T-shirt with logo print application.
<G-vec00555-002-s304><cut_off.schneiden><de> Länger geschnittenes T-shirt mit Logoprint.
<G-vec00555-002-s305><cut_off.schneiden><en> Classic cut T-shirt with a material density of rugged 185g / m², with double seams, manufactured from 100% cotton.
<G-vec00555-002-s305><cut_off.schneiden><de> Klassisch geschnittenes T-Shirt mit einer Stoffdichte von robusten 185g/m², mit doppelten Nähten, gefertigt aus 100% Baumwolle.
<G-vec00555-002-s306><cut_off.schneiden><en> Casual cut top for women with rolled sleeves and wide neck.
<G-vec00555-002-s306><cut_off.schneiden><de> Lässig geschnittenes Shirt für Frauen mit gekrempelten Ärmeln und weiterem Rundhalsausschnitt.
<G-vec00555-002-s307><cut_off.schneiden><en> The Sirians are usually described as about 6 ½ feet tall, blond hair cut very short, and blue eyes that have a cat's eye vertical pupil.
<G-vec00555-002-s307><cut_off.schneiden><de> Die Sirianer werden gewöhnlich als 2 m groß beschrieben, blondes, sehr kurz geschnittenes Haar und blaue Augen, die die vertikale Pupille von Katzenaugen haben.
<G-vec00555-002-s308><cut_off.schneiden><en> Details Slim-fit jeans in vintage denim, with belt loops, side pockets and rear patch pockets, branded loop on the back and straight cut hems.
<G-vec00555-002-s308><cut_off.schneiden><de> Slim-Jeans in Vintage Denim, mit Schlaufen an der Taille, Taschen an den Seiten und hinten, mit einer Schlaufenrückseite angepasst, unten geschnittenes, rohes Schnittprofil.
<G-vec00555-002-s309><cut_off.schneiden><en> longer cut back with elastic edging
<G-vec00555-002-s309><cut_off.schneiden><de> Etwas länger geschnittenes Rückenteil.
<G-vec00555-002-s310><cut_off.schneiden><en> Loosely cut top with V-neck and all-over Africa print.
<G-vec00555-002-s310><cut_off.schneiden><de> Locker geschnittenes Shirt mit V-Ausschnitt und Allover-Afrika-Print.
<G-vec00555-002-s311><cut_off.schneiden><en> This waisted cut Krieghoff Polo Shirt is made of 100 % cotton.
<G-vec00555-002-s311><cut_off.schneiden><de> Tailliert geschnittenes Krieghoff Polo Shirt aus 100 % Baumwolle.
<G-vec00555-002-s312><cut_off.schneiden><en> All Hexalite closures have a cut and folded security strip that breaks easily the first time the bottle is opened.
<G-vec00555-002-s312><cut_off.schneiden><de> Alle Hexalite-Verschlüsse verfügen über ein geschnittenes und gefaltetes Sicherungsband, welches beim ersten Öffnen leicht zu brechen ist.
<G-vec00555-002-s313><cut_off.schneiden><en> According to Gelfand, freshly cut tulipwood showed a variety of natural colours, which would have hindered the seamless quality of the structure.
<G-vec00555-002-s313><cut_off.schneiden><de> Laut Gelfand weist frisch geschnittenes tulipwood (Tulpenbaum) eine Vielfalt an natürlichen Farben auf, die die nahtlose Anmutung des Konstrukts beeinträchtigt hätte.
<G-vec00555-002-s314><cut_off.schneiden><en> Relaxed cut t-shirt in a stripe design.
<G-vec00555-002-s314><cut_off.schneiden><de> Relaxed geschnittenes T-Shirt im Streifendesign.
<G-vec00555-002-s315><cut_off.schneiden><en> The matching swim briefs take a high cut leg in a thong shape for a sexy style.
<G-vec00555-002-s315><cut_off.schneiden><de> Die passenden Badeshorts nehmen ein hoch geschnittenes Bein in einer Stringform für einen sexy Stil.
<G-vec00555-002-s316><cut_off.schneiden><en> Martef Big Game lame contre la corrosion. Due to the coating the blade moves extremely smoothly through cut meat or Factory Stores
<G-vec00555-002-s316><cut_off.schneiden><de> Durch die Beschichtung bewegt sich die Klinge extrem reibungslos durch geschnittenes Fleisch oder Fisch, und die Reinigung der Klinge nach Gebrauch ist denkbar einfach.
<G-vec00555-002-s317><cut_off.schneiden><en> Regular cut designed for a classic f... View Product
<G-vec00555-002-s317><cut_off.schneiden><de> Ein klassisch geschnittenes Sakko mit ungesäumten Kanten, fa...
<G-vec00555-002-s318><cut_off.schneiden><en> What looks like a classic cut T-shirt is transformed by the strategic opening on the back, a fashionista garment that will revolutionise any outfit. Wearing is believing!
<G-vec00555-002-s318><cut_off.schneiden><de> Was von vorne aussieht wie ein klassisch geschnittenes T-Shirt, verwandelt sich dank der strategischen Öffnung am Rücken in ein absolut modisches Teil, das jedes Outfit auf den Kopf stellt.
<G-vec00555-002-s319><cut_off.schneiden><en> Ridden around the cut cycling jersey that can be worn for racing, high intensity training, or the biggest ride of your summer.
<G-vec00555-002-s319><cut_off.schneiden><de> Ein modern geschnittenes Radfahrtrikot, das bei Rennen, anspruchsvollen Trainingsfahrten oder der längsten Tour des Sommers getragen werden kann.
<G-vec00555-002-s320><cut_off.schneiden><en> From that time on the babies were fed with beef heart, cut into stripes, and raw eggs.
<G-vec00555-002-s320><cut_off.schneiden><de> Nun wurden auch in Streifen geschnittenes Rinderherz und rohe Eier verfüttert.
<G-vec00555-002-s321><cut_off.schneiden><en> The Luís Vicente Group was representing their brands, among which we highlight Frubis with Dehydrated Fruit, Fresh Cut Fruit and Juices.
<G-vec00555-002-s321><cut_off.schneiden><de> Die Luis Vicente Gruppe hat ihre Marken, vor allem getrocknete Früchte, frisch geschnittenes Obst und Säfte, vorgestellt.
<G-vec00555-002-s322><cut_off.schneiden><en> A loosely cut men’s shirt that holds the balance between comfort and design innovation to perfection.
<G-vec00555-002-s322><cut_off.schneiden><de> Locker geschnittenes Herren-Shirt, das perfekt die Balance zwischen Tragekomfort und Design-Innovation hält.
<G-vec00555-002-s494><cut_off.senken><en> This hybrid model protects your investment in legacy STBs and infrastructure while simultaneously helping you to cut costs and benefit from the greater functionality, speed of innovation and flexibility that comes with a move to the cloud.
<G-vec00555-002-s494><cut_off.senken><de> Dieses Hybridmodell schützt Ihre Investition in ältere STB und Infrastruktur und hilft Ihnen gleichzeitig Kosten zu senken und von der größeren Funktionalität, Innovationsgeschwindigkeit und Flexibilität zu profitieren, die mit dem Wechsel in die Cloud einhergehen.
<G-vec00555-002-s495><cut_off.senken><en> It reduces spending on unemployment benefits and enables us to cut the contributions needed to fund them.
<G-vec00555-002-s495><cut_off.senken><de> Das senkt die Ausgaben fürs Arbeitslosengeld und erlaubt es, die Abgaben dafür zu senken.
<G-vec00555-002-s496><cut_off.senken><en> We do not involve external providers which is how we can cut costs and increase flexibility.
<G-vec00555-002-s496><cut_off.senken><de> Durch den Verzicht auf externe Dienstleister, senken wir die Gesamtkosten und steigern die Flexibilität.
<G-vec00555-002-s497><cut_off.senken><en> Increase your efficiency and cut your costs by optimized processes and outstanding detergents.
<G-vec00555-002-s497><cut_off.senken><de> Steigern Sie Ihre Effizienz und senken Sie Ihre Kosten durch optimierte Prozesse und einzigartige Produkte.
<G-vec00555-002-s498><cut_off.senken><en> The editorial concluded, “For eight years, Republicans mercilessly attacked President Barack Obama for doing too little to cut federal deficits.
<G-vec00555-002-s498><cut_off.senken><de> Zum Schluss hieß es: „Die Republikaner haben Präsident Barack Obama acht Jahre lang unablässig vorgeworfen, er würde zu wenig tun, um das Haushaltsdefizit zu senken.
<G-vec00555-002-s499><cut_off.senken><en> Not only does GesySense offer higher reliability, but the system also helps to cut the energy consumption of the refrigerated delivery vehicles: Delivery vehicles with eutectic accumulator cooling, which do not have their own controller, but are only refrigerated when connected to the power grid, are real energy guzzlers.
<G-vec00555-002-s499><cut_off.senken><de> GesySense bietet nicht nur höhere Zuverlässigkeit, das System hilft auch, den Energiebedarf der Kühlfahrzeuge zu senken: Fahrzeuge mit eutektischer Speicherkühlung, die ohne eigene Regelung nur durch einen Netzanschluss gekühlt werden, sind wahre Energiefresser.
<G-vec00555-002-s500><cut_off.senken><en> It will radically cut the minute price for productions and make formats possible, that were previously too time-consuming or expensive to create and will allow “the creative” to produce animated content without the technical expertise needed today.
<G-vec00555-002-s500><cut_off.senken><de> Sie wird den Minutenpreis von Produktionen radikal senken und Formate ermöglichen, die davor zu zeitaufwändig und teuer in der Herstellung waren und den Kreativen ermöglichen, animierte Inhalte ohne das heute noch dafür benötigte technische Fachwissen zu produzieren.
<G-vec00555-002-s501><cut_off.senken><en> The petition, inspired by the words of Pope Francis in Laudato Si’, urges leaders to drastically cut carbon emissions.
<G-vec00555-002-s501><cut_off.senken><de> Die Petition, inspiriert durch die Worte von Papst Franziskus in Laudato Si´, verlangt die CO2-Emissionen drastisch zu senken.
<G-vec00555-002-s502><cut_off.senken><en> Compass wants to cut its greenhouse gas emissions by 20%, and Gloor and Compass managers like him are assisted by Zurich food start-up Eaternity.
<G-vec00555-002-s502><cut_off.senken><de> Compass will seine Treibhausgas-Emissionen um 20% senken, und Gloor und die anderen Manager der Gruppe werden dabei von der Zürcher Startup-Firma Eaternity unterstützt.
<G-vec00555-002-s503><cut_off.senken><en> Optimize power consumption and cut power and cooling costs by up to 20 percent during low utilization periods by automatically putting hosts in standby mode during low use times and powering them back up as needed with Distributed Power Management.
<G-vec00555-002-s503><cut_off.senken><de> Optimieren Sie den Stromverbrauch und senken Sie die Strom- und Kühlungskosten in Zeiten mit geringer Auslastung um bis zu 20%, indem Sie Hosts während solcher Zeiten automatisch mit Distributed Power Management in den Standby-Modus versetzen und nach Bedarf wieder hochfahren lassen.
<G-vec00555-002-s504><cut_off.senken><en> But we don’t have enough revenue to offer as much of a tax cut this year as I would like.
<G-vec00555-002-s504><cut_off.senken><de> Wir haben aber in diesem Jahr nicht genug Staatseinkünfte, um die Steuern um so viel zu senken, wie ich möchte.
<G-vec00555-002-s505><cut_off.senken><en> The benefit of this is as film is an expensive medium; cheaper options to cut cost can be explored.
<G-vec00555-002-s505><cut_off.senken><de> Der Vorteil davon ist, als Film ein teures Medium ist; billigere Möglichkeiten Kosten zu senken können erkundet werden.
<G-vec00555-002-s506><cut_off.senken><en> There's a quick way to cut your expenses, and it's literally at your fingertips.
<G-vec00555-002-s506><cut_off.senken><de> Es gibt eine Möglichkeit, mit der Sie Ihre Ausgaben im Handumdrehen senken können – und sie ist greifbar nah.
<G-vec00555-002-s507><cut_off.senken><en> Offers efficiency as high as 97% to cut energy usage and cost.
<G-vec00555-002-s507><cut_off.senken><de> Bietet Effizienz so hoch wie 97% auf den Energieverbrauch und die Kosten zu senken.
<G-vec00555-002-s508><cut_off.senken><en> This allows IT departments to cut their costs and to target their budgets more accurately towards application management.
<G-vec00555-002-s508><cut_off.senken><de> Dies ermöglicht es IT-Abteilungen Kosten zu senken und Budgets für das Application Management zielgerichteter einzusetzen.
<G-vec00555-002-s509><cut_off.senken><en> He expects the Federal Reserve to raise interest rates four times this year and other central banks will cut interest rates .
<G-vec00555-002-s509><cut_off.senken><de> Er geht davon aus, dass die Federal Reserve in diesem Jahr viermal die Zinsen erhöhen wird und andere Zentralbanken die Zinsen senken werden.
<G-vec00555-002-s510><cut_off.senken><en> Optimize power consumption and cut power and cooling costs by up to 20 percent during low utilization periods by automatically putting hosts in standby mode during low use times and powering them back up as needed with Distributed Power Management.
<G-vec00555-002-s510><cut_off.senken><de> Optimieren Sie den Energieverbrauch und senken Sie die Strom- und Kühlungskosten bei geringerer Auslastung um bis zu 20%, indem Sie Hosts mit Distributed Power Management in den Standby-Modus versetzen und nach Bedarf wieder hochfahren.
<G-vec00555-002-s511><cut_off.senken><en> Cost-effective calculation of insulation thickness and professional installation by KAEFER cut your energy costs and help protect the environment by reducing CO2 emissions.
<G-vec00555-002-s511><cut_off.senken><de> Wirtschaftliche Dämmdickenberechnung und fachgerechte Ausführung von KAEFER senken Ihre Energiekosten und unterstützen den Klimaschutz durch die Reduzierung der CO2-Belastung.
<G-vec00555-002-s512><cut_off.senken><en> During the 1979 election campaign, Clark had promised to cut taxes to stimulate the economy.
<G-vec00555-002-s512><cut_off.senken><de> Während des Wahlkampfs hatte er versprochen, die Steuern zu senken, um die Wirtschaft zu stimulieren.
<G-vec00555-002-s513><cut_off.zerschneiden><en> By contrast, the unique Skrunda radar station, alas, was blown up, and Soviet submarines were cut up into scrap.
<G-vec00555-002-s513><cut_off.zerschneiden><de> Leider wurde ein unikales Objekt – das Radioteleskop von Skrunda gesprengt, die sowjetischen U-Boote wurden zerschnitten...
<G-vec00555-002-s514><cut_off.zerschneiden><en> For scanning APS films with the Super Coolscan 9000 ED anyway the film has to be removed out of its cartridge, cut up and placed in a special strip film holder with glass.
<G-vec00555-002-s514><cut_off.zerschneiden><de> Um dennoch APS-Filme mit dem Super Coolscan 9000 ED zu scannen, müssen diese aus der Filmspule herausgenommen, zerschnitten und in einen speziellen Filmstreifenhalter mit Glaseinsatz eingelegt werden.
<G-vec00555-002-s515><cut_off.zerschneiden><en> A further plus point: The integrated spring steel strips also have an anti-theft function in the vertical direction: If the curtain is wilfully cut, only the cut to the next spring steel strip is possible.
<G-vec00555-002-s515><cut_off.zerschneiden><de> Weiterer Pluspunkt: Die integrierten Federstahlstreifen übernehmen in vertikaler Richtung auch eine Diebstahlschutzfunktion: Wird die Plane mutwillig zerschnitten, ist nur der Schnitt bis zum nächsten Federstahlstreifen möglich.
<G-vec00555-002-s516><cut_off.zerschneiden><en> The bottom of the gown and the sleeves are cut in wedges.
<G-vec00555-002-s516><cut_off.zerschneiden><de> Der untere Teil des Gewandes sowie die Ärmel sind zu Spitzen zerschnitten.
<G-vec00555-002-s517><cut_off.zerschneiden><en> If the mats are cut remove them carefully with a dog detangling comb with rotating teeth.
<G-vec00555-002-s517><cut_off.zerschneiden><de> Wenn die Matten zerschnitten sind versuchen Sie diese vorsichtig mit einem Hundekamm mit rotierenden Zähnen zu entfernen.
<G-vec00555-002-s518><cut_off.zerschneiden><en> The pain became serious as if my internal organs were cut into pieces.
<G-vec00555-002-s518><cut_off.zerschneiden><de> Die Schmerzen wurden so stark, als würden meine inneren Organe zerschnitten.
<G-vec00555-002-s519><cut_off.zerschneiden><en> The protective sleeves are vital to ensure that the sharp edges of the concrete do not cut the belts during this movement.
<G-vec00555-002-s519><cut_off.zerschneiden><de> Dass bei dieser Bewegung nicht die scharfen Kanten des Betons zerschnitten werden, dafür sind die Kantenschutzschläuche von erheblicher Bedeutung.
<G-vec00555-002-s520><cut_off.zerschneiden><en> If we had had stabbing weapons, then we had cut our intestines.
<G-vec00555-002-s520><cut_off.zerschneiden><de> Hätten wir Stichwaffen gehabt, wir hätten uns die Eingeweide zerschnitten.
<G-vec00555-002-s521><cut_off.zerschneiden><en> Found material is copied, cut, mirrored and glued.
<G-vec00555-002-s521><cut_off.zerschneiden><de> Vorgefundenes Material wird kopiert, zerschnitten, gespiegelt und geklebt.
<G-vec00555-002-s522><cut_off.zerschneiden><en> The picture on the right illustrates the procedure: A sharp knife is used to cut a wiper into three pieces (holder, arm and blade).
<G-vec00555-002-s522><cut_off.zerschneiden><de> Das Bild rechts zeigt das Prozedere: Mit einem scharfen Messer wird der Wischer in drei Teile (Halterung, Arm und Blatt) zerschnitten.
<G-vec00555-002-s523><cut_off.zerschneiden><en> In order to achieve a complete removal, the 300 t tripod has to be cut in parts.
<G-vec00555-002-s523><cut_off.zerschneiden><de> Dafür muss das 300 Tonnen schwere Fundament in mehrere Teile zerschnitten werden.
<G-vec00555-002-s524><cut_off.zerschneiden><en> Under threat is Cameroon’s coherent and unique ecosystem which like in Tanzania, will be cut into two parts.
<G-vec00555-002-s524><cut_off.zerschneiden><de> Genau wie in Tansania würde auch in Kamerun ein zusammenhängendes einzigartiges Ökosystem in zwei Teile zerschnitten.
<G-vec00555-002-s525><cut_off.zerschneiden><en> But when the royal envoy came to him, Joseph said,42 "Go back to your lord and ask him to inquire about the matter of the women who cut their hands.
<G-vec00555-002-s525><cut_off.zerschneiden><de> Als der Bote zu ihm kam, sagte er: "Kehr zu deinem Herrn zurück und frag ihn, wie es mit den Frauen steht, die sich ihre Hände zerschnitten.
<G-vec00555-002-s526><cut_off.zerschneiden><en> It proved difficult though, as the volume really overran the audience and the high frequencies of the squeezebox and electric guitar in particular cut through the eardrum.
<G-vec00555-002-s526><cut_off.zerschneiden><de> Das erwies sich jedoch meist als schwierig, da die Lautstärke das Publikum regelrecht überrollte und vor allem die hohen Frequenzen von Quetsche und E-Gitarre schier das Trommelfell zerschnitten.
<G-vec00555-002-s527><cut_off.zerschneiden><en> This is cut into small pieces and then ground it into a powder along with various types of recycled plastics.
<G-vec00555-002-s527><cut_off.zerschneiden><de> Dieses wird in kleine Teile zerschnitten und im Anschluss mit verschiedenen Arten von Recyclingkunststoffen zu einem Pulver gemahlen.
<G-vec00555-002-s528><cut_off.zerschneiden><en> We cut those animal hide thongs, threw away the two bottles of potions, and prayed to God for his protection.
<G-vec00555-002-s528><cut_off.zerschneiden><de> Wir zerschnitten diese Tierhautschnüre, warfen die zwei Medizinflaschen fort und baten Gott um seinen Schutz.
<G-vec00555-002-s529><cut_off.zerschneiden><en> In the video, the interview language is cut apart into individual word fragments.
<G-vec00555-002-s529><cut_off.zerschneiden><de> Die Interviewsprache wird hier in isolierte Worte zerschnitten und mit einer monologisierenden Off-Stimme kommentiert.
<G-vec00555-002-s530><cut_off.zerschneiden><en> Beef, buffalo, venison, rabbit or rattlesnake meat was cut into small chunks, seasoned with spicy dried chili peppers and slowly simmered in a pot over a campfire.
<G-vec00555-002-s530><cut_off.zerschneiden><de> Rindfleisch, Buffalo, Reh, Kaninchen oder Schlangenfleisch wurde in kleine Stückchen zerschnitten, mit heissen getrockneten Chili Pfeffern gewürzt und dann langsam in einem Topf über einem Kampingfeuer gekocht.
<G-vec00555-002-s531><cut_off.zerschneiden><en> A geometric shape which is cut up in one place is always the same.
<G-vec00555-002-s531><cut_off.zerschneiden><de> Gleich ist immer eine geometrische Form, die an einer Stelle zerschnitten ist.
<G-vec00555-002-s551><cut_off.zuschneiden><en> Now that blocks 1 through 12 of the BERNINA Triangle Quilt Along have been sewn, it’s time to cut out the remaining pieces.
<G-vec00555-002-s551><cut_off.zuschneiden><de> Nachdem nun Block 1 bis 12 des BERNINA Triangle Quilt-Alongs genäht sind, geht es ans Zuschneiden der übrigen Teile.
<G-vec00555-002-s552><cut_off.zuschneiden><en> Start by making a template of the walls to be papered, then you can test that the pieces are large enough before you cut out the real wallpaper.
<G-vec00555-002-s552><cut_off.zuschneiden><de> Beginnen Sie damit, eine Vorlage der Wände zu erstellen, die tapeziert werden soll, und testen Sie, ob die Teile groß genug sind, bevor Sie die eigentliche Tapete zuschneiden.
<G-vec00555-002-s553><cut_off.zuschneiden><en> We assemble it ourselves, as we cut the guide rails to the exact length in our workshop and then drill the appropriate holes. ” Michael Geisler adds: “Our customers are thrilled by the overall concept.
<G-vec00555-002-s553><cut_off.zuschneiden><de> Wir konfektionieren selbst, da wir die Führungsschienen in unserer Werkstatt auf die exakte Länge zuschneiden und anschließend die entsprechenden Bohrungen vornehmen.“ Michael Geisler ergänzt dazu: „Unsere Kunden sind vom Gesamtkonzept begeistert.
<G-vec00555-002-s554><cut_off.zuschneiden><en> If your design is irregularly shaped, you'll need to cut the restraints in order to follow the edges of your design.
<G-vec00555-002-s554><cut_off.zuschneiden><de> Wenn dein Design unregelmäßig geformt ist, wirst du die Randbefestigung zuschneiden müssen, damit du der Form von deinem Design entsprechen kannst.
<G-vec00555-002-s555><cut_off.zuschneiden><en> The Tapco Power Cut-Off can be used to accurately cut aluminium, steel, zinc or copper.
<G-vec00555-002-s555><cut_off.zuschneiden><de> Die Power Cut-Off von Tapco ist eine elektrische Rollenschere, die das präzise Zuschneiden von Aluminium, Stahl, Zink und Kupfer ermöglicht.
<G-vec00555-002-s556><cut_off.zuschneiden><en> Finally cut 5 big Chocolate Protein Bars.
<G-vec00555-002-s556><cut_off.zuschneiden><de> Aus der gekühlten Masse 5 große Schoko Eiweißriegel zuschneiden.
<G-vec00555-002-s557><cut_off.zuschneiden><en> 03 Cut 5.5 x 11 cm rectangles from the white and black cardboard.
<G-vec00555-002-s557><cut_off.zuschneiden><de> 03 Aus weißem und schwarzem Karton 5,5 x 11 cm große Rechtecke zuschneiden.
<G-vec00555-002-s558><cut_off.zuschneiden><en> Noir T30 Flat Bar is 600mm wide for maximum control and can be easily cut for customized fit.
<G-vec00555-002-s558><cut_off.zuschneiden><de> Der Noir T30 Flatbar ist 600 mm breit, bietet maximale Kontrolle und lässt sich einfach inviduell zuschneiden und anpassen.
<G-vec00555-002-s559><cut_off.zuschneiden><en> Cut a slice of lemon with a sharp knife on a chopping board and place in the drink to garnish.
<G-vec00555-002-s559><cut_off.zuschneiden><de> Mit einem scharfen Messer auf einem Schneidebrett eine Zitronenscheibe zuschneiden und als Garnitur auf das Getränk geben.
<G-vec00555-002-s560><cut_off.zuschneiden><en> Cut the fabric strip to a suitable size.
<G-vec00555-002-s560><cut_off.zuschneiden><de> Die Stoffstreifen auf die geeignete Größe zuschneiden.
<G-vec00555-002-s561><cut_off.zuschneiden><en> With a sharp knife and chopping board, cut a wedge of lemon and place on top of the drink to garnish.
<G-vec00555-002-s561><cut_off.zuschneiden><de> Mit einem scharfen Messer auf einem Schneidebrett eine Zitronenspalte zuschneiden und als Garnitur auf das Getränk geben.
<G-vec00555-002-s562><cut_off.zuschneiden><en> You can cut the hair for a even better fit.
<G-vec00555-002-s562><cut_off.zuschneiden><de> Sie können die Haare für eine noch bessere Passform zuschneiden.
<G-vec00555-002-s563><cut_off.zuschneiden><en> The pin board cork can be easily cut with a utility knife and a stop rail.
<G-vec00555-002-s563><cut_off.zuschneiden><de> Der Pinwand-Kork läßt sich ganz einfach mit einem Teppichmesser und einer Anschlagschiene zuschneiden.
<G-vec00555-002-s564><cut_off.zuschneiden><en> FOAMGLAS® can be easily cut and installed on site or is available prefabricated.
<G-vec00555-002-s564><cut_off.zuschneiden><de> FOAMGLAS® Dämmung lässt sich auf der Baustelle leicht zuschneiden und montieren oder ist vorgefertigt verfügbar.
<G-vec00555-002-s565><cut_off.zuschneiden><en> Cover with the second sheet of the dough and cut out squares to form the ravioli.
<G-vec00555-002-s565><cut_off.zuschneiden><de> Mit der zweiten Teigplatte abdecken, zuschneiden und nach Belieben Ravioli formen.
<G-vec00555-002-s566><cut_off.zuschneiden><en> Attention: With the rectangle you have the seam allowance included so you can cut on your lines.
<G-vec00555-002-s566><cut_off.zuschneiden><de> Achtung: Beim Rechteck habt ihr die Nahtzugaben schon mit eingerechnet, könnt hier also auf den Linien zuschneiden.
<G-vec00555-002-s567><cut_off.zuschneiden><en> Tips Your local lumber store will most likely cut the 2 x 4s to length for you... this is far less expensive than buying the proper power saw if you don't own it.
<G-vec00555-002-s567><cut_off.zuschneiden><de> Methode 7 von 7: Wertung Tipps Dein örtliches Holzlager kann dir die 2x4 Latten sicherlich auf Länge zuschneiden – dies ist wesentlich preisgünstiger als die richtige Säge zu kaufen, wenn du keine besitzt.
<G-vec00555-002-s568><cut_off.zuschneiden><en> Thanks to our range of CNC machinery in Butzbach, which includes a CNC panel saw, we can cut our own fire protection cladding for steel girders and pillars.
<G-vec00555-002-s568><cut_off.zuschneiden><de> Dank unseres CNC-Maschinenparks in Butzbach, wo neben anderen mit einer CNC-gesteuerten Plattensäge gearbeitet wird, können wir Brandschutzbekleidungen für Stahlträger und Stahlstützen selbst zuschneiden.
<G-vec00555-002-s569><cut_off.zuschneiden><en> Make sure to cut down your paper or film in complete darkness.
<G-vec00555-002-s569><cut_off.zuschneiden><de> Auf jeden Fall musst du Fotopapier und Film in absoluter Dunkelheit zuschneiden.
