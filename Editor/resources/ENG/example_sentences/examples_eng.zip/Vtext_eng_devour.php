<G-vec00476-001-s009><devour.verzehren><en> So the Light of Israel will be for a fire, And his Holy One for a flame; It will burn and devour His thorns and his briers in one day (Isaiah 10:17, NKJV).
<G-vec00476-001-s009><devour.verzehren><de> So wird das Licht Israels zu einem Feuer werden / und sein Heiliger zu einer Flamme; / es wird brennen und sein Unkraut und Dorngestrüpp in einem einzigen Tag verzehren (Jesaja 10:17, NKJV).
<G-vec00476-001-s012><devour.auffressen><en> As Russian revolutionary leader Leon Trotsky wrote in his analysis of the degeneration of the Russian Revolution under Stalinism, The Revolution Betrayed (1937), the question is: “Will the bureaucrat devour the workers’ state, or will the working class clean up the bureaucrat?” We Trotskyists fought for a program of proletarian political revolution led by a Bolshevik party to bring revolutionary socialist consciousness to the working class in order to sweep out the bureaucracy, establish the rule of workers soviets and return the Soviet Union to its role as the headquarters of world socialist revolution.
<G-vec00476-001-s012><devour.auffressen><de> Wie der russische revolutionäre Führer Leo Trotzki 1936 in Verratene Revolution, seiner Analyse der Degenerierung der Russischen Revolution unter dem Stalinismus, schrieb, geht es um die Frage: „Wird der Beamte den Arbeiterstaat auffressen oder der Arbeiter den Beamten bezwingen?“ Wir Trotzkisten kämpften für ein Programm der proletarisch-politischen Revolution, geführt von einer bolschewistischen Partei, die revolutionäres sozialistisches Bewußtsein in die Arbeiterklasse hineinträgt, um die Bürokratie wegzufegen, die Herrschaft von Arbeitersowjets zu errichten und der Sowjetunion ihre Rolle als das Hauptquartier der sozialistischen Weltrevolution zurückzugeben.
<G-vec00476-001-s013><devour.auffressen><en> 15 But if ye bite and devour one another, take heed that ye be not consumed one of another.
<G-vec00476-001-s013><devour.auffressen><de> 15 Wenn ihr jedoch einander beißt und auffreßt, seht dann nur zu, daß ihr nicht voneinander aufgefressen werdet.
<G-vec00476-001-s015><devour.verschlingen><en> When visitors pass by the concave part of the double curve, the floor seems to tilt up before the viewer to devour his distorted reflection, while at least one of the concave areas simply reflects the surroundings in diminished form.
<G-vec00476-001-s015><devour.verschlingen><de> Geht man am konkaven Teil der Doppelkurve vorbei, scheint sich im Spiegelbild der Boden vor dem Betrachter aufzurichten und seine verzerrte Figur zu verschlingen, während zumindest einer der konvex geformten Teile die Umgebung ganz einfach nur in verkleinerter Form reflektiert.
<G-vec00476-001-s026><devour.verschlingen><en> You have no interest or respect for what you're going for; you just want to devour things.
<G-vec00476-001-s026><devour.verschlingen><de> Du hast weder Interesse noch Respekt vor dem, auf was du dich einlässt, du willst die Dinge einfach verschlingen.
<G-vec00476-001-s027><devour.verschlingen><en> However, the 'fuel' of electric cars - battery cells, also devour billions.
<G-vec00476-001-s027><devour.verschlingen><de> Aber auch der Treibstoff für die Elektroautos in Form von Batteriezellen verschlingt Milliarden.
<G-vec00476-001-s028><devour.fressen><en> 3 And she brought out one of her whelps, and he became a lion: and he learned to catch the prey, and to devour men.
<G-vec00476-001-s028><devour.fressen><de> 3 Und eins ihrer Jungen zog sie groß, und es wurde ein junger Löwe daraus; der lernte Tiere zu reißen, ja, Menschen fraß er.
<G-vec00476-001-s030><devour.fressen><en> There I will devour them like a lioness.
<G-vec00476-001-s030><devour.fressen><de> Ich fresse sie dort wie eine Löwin.
<G-vec00476-001-s031><devour.fressen><en> 34:28 And they shall no more be a prey to the nations, neither shall the beasts of the earth devour them; but they shall dwell securely, and none shall make them afraid.
<G-vec00476-001-s031><devour.fressen><de> 34:28 Sie sollen hinfort nicht mehr eine Beute der Heiden werden, noch sollen die wilden Tiere des Landes sie fressen, sondern sie sollen sicher wohnen, und niemand wird sie erschrecken.
<G-vec00476-001-s032><devour.fressen><en> There is a way towards a power that replaces our obsession for ourselves with the life of God: Gratis e con amore is the name of the new melody of existence; no longer devour and be devoured.
<G-vec00476-001-s032><devour.fressen><de> Es gibt eine Hinführung zu einer Macht, die unsere Selbstbesessenheit mit dem Leben Gottes tauscht: Gratis e con amore heißt die neue Melodie des Daseins, nicht mehr Fressen und Gefressenwerden.
<G-vec00476-001-s033><devour.fressen><en> 2:13 Behold, I am against you, says the LORD of hosts, and I will burn her chariots in the smoke, and the sword shall devour your young lions: and I will cut off your prey from the earth, and the voice of your messengers shall no more be heard.
<G-vec00476-001-s033><devour.fressen><de> 2:13 Siehe, ich will an dich, spricht der HERR Zebaoth, und deine Wagen im Rauch anzünden, und das Schwert soll deine jungen Löwen fressen; und will deines Raubens ein Ende machen auf Erden, daß man deiner Boten Stimme nicht mehr hören soll.
<G-vec00476-001-s034><devour.fressen><en> "The father, however, could not rejoice, but began to weep, and said, ""My dearest child, I have bought the little bird dear. In return for it, I have been obliged to promise thee to a savage lion, and when he has thee he will tear thee in pieces and devour thee,"" and he told her all, just as it had happened, and begged her not to go there, come what might."
<G-vec00476-001-s034><devour.fressen><de> "Der Vater aber konnte sich nicht freuen, sondern fing an zu weinen und sagte: ""Mein liebstes Kind, den kleinen Vogel habe ich teuer gekauft, ich habe dich dafür einem wilden Löwen versprechen müssen, und wenn er dich hat, wird er dich zerreißen und fressen,"" und erzählte ihr da alles wie es zugegangen war, und bat sie, nicht hinzugehen, es möchte auch kommen, was da wolle."
<G-vec00476-001-s035><devour.fressen><en> "o it will devour the whole earth and tread it down and crush it. Democracy has ""crushed and broken in pieces"" all other kingdoms (the Habsburg empire, the Soviet Union, Tito's Yugoslavia, all European kingdoms)."
<G-vec00476-001-s035><devour.fressen><de> "o es wird alle Länder fressen, zertreten und zermalmen, Die Demokratie hat alle anderen Reiche (Habsburger Reich, Sowjetunion, Tito-Jugoslawien, sämtliche europäischen Königreiche) ""zermalmt und zertrümmert""."
<G-vec00476-001-s036><devour.fressen><en> 9:15 The LORD of hosts shall defend them; and they shall devour, and subdue with sling stones; and they shall drink, and make a noise as through wine; and they shall be filled like bowls, and as the corners of the altar.
<G-vec00476-001-s036><devour.fressen><de> 9:15 Der HERR Zebaoth wird sie schützen, daß sie um sich fressen und unter sich treten die Schleudersteine, daß sie trinken und lärmen wie vom Wein und voll werden wie das Becken und wie die Ecken des Altars.
<G-vec00476-001-s037><devour.fressen><en> "27 ""Benjamin is a ravenous wolf; In the morning he shall devour the prey, And at night he shall divide the spoil."""
<G-vec00476-001-s037><devour.fressen><de> 27 Benjamin ist ein reißender Wolf; des Morgens wird er Raub fressen, und des Abends wird er Beute austeilen.
<G-vec00476-001-s038><devour.fressen><en> One exhaust juice from a plant, others damage bark, the third devour fruits.
<G-vec00476-001-s038><devour.fressen><de> Ein saugen die Säfte aus der Pflanze aus, andere beschädigen die Rinde, dritte fressen die Früchte.
<G-vec00476-001-s039><devour.fressen><en> Terrors will come over him; 20:26 total darkness lies in wait for his treasures. A fire unfanned will consume him and devour what is left in his tent.
<G-vec00476-001-s039><devour.fressen><de> 20:26 Eitel Finsternis ist aufgespart für seine Schätze; ein Feuer, das nicht angeblasen ist, wird ihn fressen, wird verzehren, was in seinem Zelte übriggeblieben.
<G-vec00476-001-s040><devour.fressen><en> "10:12 And the LORD said to Moses, ""Stretch out your hand over Egypt so that locusts will swarm over the land and devour everything growing in the fields, everything left by the hail."""
<G-vec00476-001-s040><devour.fressen><de> 10:12 Da sprach der HERR zu Mose: Recke deine Hand über Ägyptenland, daß Heuschrecken auf Ägyptenland kommen und fressen alles Kraut im Lande auf samt allem dem, was der Hagel übriggelassen hat.
<G-vec00476-001-s042><devour.fressen><en> And they said thus to it, «Arise, devour much flesh!» The bear devouring much flesh accurately describes the bloody attacks of the Medes and Persians.
<G-vec00476-001-s042><devour.fressen><de> Und man sprach zu ihm: »Steh auf und friss viel Fleisch!« Der viel Fleisch fressende Bär beschreibt sehr genau die blutigen Kriege der Meder und Perser.
<G-vec00476-001-s043><devour.fressen><en> 2:5 But I will send a fire upon Judah, and it shall devour the palaces of Jerusalem.
<G-vec00476-001-s043><devour.fressen><de> 2:5 darum schicke ich Feuer gegen Juda; / es frisst Jerusalems Paläste.
<G-vec00476-001-s044><devour.fressen><en> If we fail in this, the revolution will devour its children.
<G-vec00476-001-s044><devour.fressen><de> Wenn wir es versäumen, frisst die Revolution ihre Kinder.
<G-vec00476-001-s045><devour.fressen><en> 2:2 But I will send a fire upon Moab, and it shall devour the palaces of Kerioth: and Moab shall die with tumult, with shouting, and with the sound of the trumpet:
<G-vec00476-001-s045><devour.fressen><de> 2:2 darum schicke ich Feuer gegen Moab; / es frisst die Paläste von Kerijot und Moab geht im Getümmel zugrunde, / beim Kriegsgeschrei, beim Schall der Hörner.
<G-vec00476-001-s046><devour.fressen><en> 12 I shall send fire down on Teman to devour the palaces of Bozrah.
<G-vec00476-001-s046><devour.fressen><de> 12 schicke ich Feuer gegen Teman; es frisst Bozras Paläste.
<G-vec00476-001-s047><devour.fressen><en> 12 Over all the barren heights in the desert destroyers will swarm, for the sword of the LORD will devour from one end of the land to the other; no-one will be safe.
<G-vec00476-001-s047><devour.fressen><de> 12 Über alle kahlen Höhen der Steppe sind Zerstörer gekommen; denn das Schwert des HERRN frisst von einem Ende des Landes bis zum anderen; da gibt es keinen Frieden für al les Fleisch.
<G-vec00476-001-s048><devour.fressen><en> """Arise, devour much flesh"" indicates its insatiable appetite for conquest (5)."
<G-vec00476-001-s048><devour.fressen><de> "„Steh auf, friß viel Fleisch"" zeigt seinen unbändigen Appetit auf Eroberungen an (V. 5)."
<G-vec00476-001-s050><devour.fressen><en> 32:42 I will make my arrows drunk with blood, and my sword shall devour flesh; [and that] with the blood of the slain and of the captives from the beginning of revenges upon the enemy.
<G-vec00476-001-s050><devour.fressen><de> 42 Meine Pfeile laß ich trunken werden von Blut, und mein Schwert frißt Fleisch vom Blut der Erschlagenen und Gefangenen, vom Haupt der Fürsten des Feindes.
<G-vec00476-001-s051><devour.fressen><en> The dragon stood before the woman who was about to give birth, so that when she gave birth he might devour her child.
<G-vec00476-001-s051><devour.fressen><de> Und der Drache trat vor das Weib, die gebären sollte, auf daß, wenn sie geboren hätte, er ihr Kind fräße.
<G-vec00476-001-s053><devour.fressen><en> "21:23 ""And also concerning Jezebel the Lord says: 'Dogs will devour Jezebel by the wall of Jezreel.'"
<G-vec00476-001-s053><devour.fressen><de> 21:23 Und auch über Isebel hat der HERR geredet und gesprochen: Die Hunde sollen Isebel fressen an der Mauer Jesreels.
<G-vec00476-001-s059><devour.konsumieren><en> We devour news and content on an hourly basis thanks to social media's hold on our lives, and companies therefore need to stay on top of current affairs.
<G-vec00476-001-s059><devour.konsumieren><de> Durch den Einfluss der sozialen Medien auf unser Leben konsumieren wir Neuigkeiten und Inhalte auf stündlicher Basis, daher müssen Unternehmen am Puls des Zeitgeschehens sein.
<G-vec00476-001-s062><devour.verzehren><en> 10 And I will send a fire upon the wall of Tyre, and it shall devour the houses thereof.
<G-vec00476-001-s062><devour.verzehren><de> 10 sondern ich will ein Feuer in die Mauern von Tyrus schicken, das soll seine Paläste verzehren.
<G-vec00476-001-s063><devour.verzehren><en> And I will send a fire into Juda, and it shall devour the houses of Jerusalem.
<G-vec00476-001-s063><devour.verzehren><de> sondern ich will ein Feuer nach Juda schicken, das soll die Paläste zu Jerusalem verzehren.
<G-vec00476-001-s066><devour.verzehren><en> 21:14 And I will punish you according to the fruit of your doings, saith Jehovah; and I will kindle a fire in her forest, and it shall devour all that is round about her.
<G-vec00476-001-s066><devour.verzehren><de> 21:14 Ich will euch heimsuchen, wie es eure Taten verdienen, spricht der HERR, und will ein Feuer anzünden in ihrem Wald, das soll ihre ganze Umgebung verzehren.
<G-vec00476-001-s068><devour.verschlingen><en> devour Him and destroy Him. I shall lead on my followers
<G-vec00476-001-s068><devour.verschlingen><de> Ich will Ihn verschlin- gen und vernichten.
<G-vec00476-001-s069><devour.verschlingen><en> "The inspired warning is sounding down the centuries to our time: ""Be sober, be vigilant; because your adversary the devil, as a roaring lion, walketh about, seeking whom he may devour."""
<G-vec00476-001-s069><devour.verschlingen><de> Die inspirierte Warnung klingt durch die Jahrhunderte bis zu uns: „Seid nüchtern und wachet; denn euer Widersacher, der Teufel, geht umher wie ein brüllender Löwe und sucht, welchen er verschlinge.“ (l. Petr.
<G-vec00476-001-s070><devour.verschlingen><en> 1 Peter 5:8,9 Be sober, be vigilant; because your adversary the devil, as a roaring lion, walketh about, seeking whom he may devour:
<G-vec00476-001-s070><devour.verschlingen><de> 1.Petrus 5:8,9 Seid nüchtern und wacht; denn euer Widersacher, der Teufel, geht umher wie ein brüllender Löwe und sucht, wen er verschlinge.
<G-vec00476-001-s071><devour.verschlingen><en> Satan walketh about as a roaring lion, and he seeks whom he may devour.
<G-vec00476-001-s071><devour.verschlingen><de> Es geht der Satan umher wie ein brüllender Löwe, und er suchet, wen er verschlinge.
<G-vec00476-001-s072><devour.verschlingen><en> The caterpillars hatched from the eggs devour a great amount of nettles in the course of a few weeks.
<G-vec00476-001-s072><devour.verschlingen><de> Die Raupen schlüpfen aus den Eiern, verschlingen, im Laufe von einigen Wochen, eine große Menge von Brennnesseln.
<G-vec00476-001-s073><devour.verschlingen><en> With only a short time left, he seeks to devour all who are God's children.
<G-vec00476-001-s073><devour.verschlingen><de> Mit nur ein wenig Zeit bleibt, versucht er, alle, die Gottes Kinder sind zu verschlingen.
<G-vec00476-001-s074><devour.verschlingen><en> Our very bodily life is a constant dying and being reborn, the body itself a beleaguered city attacked by assailing, protected by defending forces whose business is to devour each other....
<G-vec00476-001-s074><devour.verschlingen><de> Unser eigentliches körperliches Leben ist ein ständiges Absterben und Wiedergeboren werden, der Körper ist selbst eine belagerte Stadt, die von anstürmenden Kräften überfallen und von verteidigenden Kräften beschützt wird, deren Zweck darin besteht sich gegenseitig zu verschlingen....
<G-vec00476-001-s075><devour.verschlingen><en> But by the time they regain their senses after the supernatural phenomenon of rapture, their end will already have come.... the earth will open and devour all those who are and remain disloyal to Me.
<G-vec00476-001-s075><devour.verschlingen><de> Doch ehe sie zur Besinnung kommen ob der übernatürlichen Erscheinung einer Entrückung, ist schon ihr Ende gekommen.... die Erde wird sich öffnen und alle verschlingen, die Mir abtrünnig sind und bleiben bis zum Ende.
<G-vec00476-001-s076><devour.verschlingen><en> They had no intention to devour their metallic prey, but they took sadistic pleasure in slamming their claws into the helpless robot, ripping it into pieces.
<G-vec00476-001-s076><devour.verschlingen><de> Sie hatten nicht die Absicht ihre metallische Beute zu verschlingen, aber es verschaffte ihnen eine sadistische Freude, ihre Klauen in den hilflosen Roboter zu schlagen und ihn in Fetzen zu reißen.
<G-vec00476-001-s077><devour.verschlingen><en> But in the end death would devour me.
<G-vec00476-001-s077><devour.verschlingen><de> Aber am Ende würde der Tod mich verschlingen.
<G-vec00476-001-s078><devour.verschlingen><en> Devour Deal 319 damage to non-Heroic units, or 114 damage to Heroes.
<G-vec00476-001-s078><devour.verschlingen><de> Verschlingen Fügt nicht heroischen Einheiten 319 oder Helden 114 Schaden zu.
<G-vec00476-001-s079><devour.verschlingen><en> While his unfortunate victims were obeying his orders, he would kick them over into the depths below, where a gigantic turtle lurked in readiness to devour them.
<G-vec00476-001-s079><devour.verschlingen><de> Während seine unglücklichen Leidtragenden seinen Reihenfolgen gehorchten, würde er sie über in travel Tiefen unten treten, wo eine riesige Schildkröte in Bereitschaft gelauert hat, sie zu verschlingen.
<G-vec00476-001-s080><devour.verschlingen><en> who devour the houses of widows under the pretense of long prayers.
<G-vec00476-001-s080><devour.verschlingen><de> welche die Häuser der Witwen verschlingen und zum Schein lange Gebete halten.
<G-vec00476-001-s081><devour.verschlingen><en> Research & development as well as large-scale field tests devour amounts of billion.
<G-vec00476-001-s081><devour.verschlingen><de> Forschung & Entwicklung sowie groÃ angelegte Feldtests verschlingen Milliardenbeträge.
<G-vec00476-001-s082><devour.verschlingen><en> In turn, the US loss of influence could accelerate the need for different international actors to make autonomous decisions beyond their previous willingness, to avoid having the crisis devour them, as the European governments did.
<G-vec00476-001-s082><devour.verschlingen><de> Andererseits könnte der Verlust an Einfluss auf Seiten Nordamerikas die Notwendigkeit der verschiedenen internationalen Akteure beschleunigen, autonome Entscheidungen zu treffen, wie dies die europäischen Regierungen gemacht haben, um zu verhindern, dass die Krise sie verschlingt.
<G-vec00476-001-s083><devour.verschlingen><en> Demolition, including the disposal of the 48 tonnes of ammonia required for producing and cooling the ice, will devour another 220 million euros.
<G-vec00476-001-s083><devour.verschlingen><de> Der Abbruch inklusive Entsorgung der 48 Tonnen Ammoniak, die es zur Herstellung und Kühlung des Eises braucht, verschlingt weitere 220 Millionen.
<G-vec00476-001-s084><devour.verschlingen><en> Devour your enemies as much as possible to keep your Burst Gauge up.
<G-vec00476-001-s084><devour.verschlingen><de> Verschlingt eure Feinde so oft wie möglich, um eure Burst Gauge hoch zu halten.
<G-vec00476-001-s085><devour.verschlingen><en> The nutrient intake required for the animal kingdom, comes from the vegetable kingdom and the animal kingdom (large fish devour on the little one).
<G-vec00476-001-s085><devour.verschlingen><de> Die für das Tierreich benötigte Nährstoffaufnahme stammt aus dem Pflanzenreich und dem Tierreich (großer Fisch verschlingt den Kleinen).
<G-vec00476-001-s086><devour.verschlingen><en> And the dragon stood before the woman, who was about to give birth, so that, when she had brought forth, he might devour her son.
<G-vec00476-001-s086><devour.verschlingen><de> Und der Drache stand vor dem Weibe, das im Begriff war zu gebären, auf daß er, wenn sie geboren hätte, ihr Kind verschlänge.
<G-vec00476-001-s087><devour.verzehren><en> And the bramble said unto the trees, If in truth ye anoint me king over you, then come and put your trust in my shadow: and if not, let fire come out of the bramble, and devour the cedars of Lebanon.
<G-vec00476-001-s087><devour.verzehren><de> Und der Dornbusch sprach zu den Bäumen: Ist's wahr, daß ihr mich zum König salbt über euch, so kommt und vertraut euch unter meinen Schatten; wo nicht, so gehe Feuer aus dem Dornbusch und verzehre die Zedern Libanons.
<G-vec00476-001-s088><devour.verzehren><en> 9:20 but if not, let fire come out from Abimelech, and devour the men of Shechem, and the house of Millo; and let fire come out from the men of Shechem, and from the house of Millo, and devour Abimelech.”
<G-vec00476-001-s088><devour.verzehren><de> 9:20 wo nicht, so gehe Feuer aus von Abimelech und verzehre die Männer zu Sichem und das Haus Millo, und gehe auch Feuer aus von den Männern zu Sichem und vom Haus Millo und verzehre Abimelech.
<G-vec00476-001-s090><devour.verzehren><en> "And responding, Elijah said to the leader of fifty, ""If I am a man of God, let fire from heaven descend and devour you and your fifty."""
<G-vec00476-001-s090><devour.verzehren><de> Doch Elija antwortete dem Hauptmann der Fünfzig: Wenn ich ein Mann Gottes bin, so falle Feuer vom Himmel und verzehre dich und deine Fünfzig.
<G-vec00476-001-s091><devour.verzehren><en> The bramble said to the trees, If in truth you anoint me king over you, then come and take refuge in my shade; and if not, let fire come out of the bramble, and devour the cedars of Lebanon.
<G-vec00476-001-s091><devour.verzehren><de> Und der Dornbusch sprach zu den Bäumen: Ist's wahr, daß ihr mich zum König salbt über euch, so kommt und vertraut euch unter meinen Schatten; wo nicht, so gehe Feuer aus dem Dornbusch und verzehre die Zedern Libanons.
<G-vec00476-001-s092><devour.verzehren><en> 9:15 “The bramble said to the trees, ‘If in truth you anoint me king over you, then come and take refuge in my shade; and if not, let fire come out of the bramble, and devour the cedars of Lebanon.’
<G-vec00476-001-s092><devour.verzehren><de> 9:15 Und der Dornbusch sprach zu den Bäumen: Ist's wahr, daß ihr mich zum König salbt über euch, so kommt und vertraut euch unter meinen Schatten; wo nicht, so gehe Feuer aus dem Dornbusch und verzehre die Zedern Libanons.
<G-vec00476-001-s093><devour.verzehren><en> 20 But if not, let fire fire come out from Abimelech Abimelech, and devour the men of Shechem Shechem, and the house house of Millo; and let fire fire come out from the men of Shechem Shechem, and from the house house of Millo, and devour Abimelech Abimelech .
<G-vec00476-001-s093><devour.verzehren><de> 20 wo nicht, so gehe Feuer Feuer aus von Abimelech und verzehre die Männer zu Sichem Sichem und das Haus Haus Millo, und gehe auch Feuer Feuer aus von den Männern zu Sichem Sichem und vom Haus Haus Millo und verzehre Abimelech.
<G-vec00476-001-s095><devour.verzehren><en> 9:15 And the bramble said unto the trees, If in truth all of you anoint me king over you, then come and put your trust in my shadow: and if not, let fire come out of the bramble, and devour the cedars of Lebanon.
<G-vec00476-001-s095><devour.verzehren><de> 9:15 Und der Dornbusch sprach zu den Bäumen: Ist's wahr, daß ihr mich zum König salbt über euch, so kommt und vertraut euch unter meinen Schatten; wo nicht, so gehe Feuer aus dem Dornbusch und verzehre die Zedern Libanons.
<G-vec00476-001-s096><devour.verzehren><en> but I will send a fire on the wall of Gaza, and it shall devour the palaces thereof.
<G-vec00476-001-s096><devour.verzehren><de> sondern ich will ein Feuer in die Mauern zu Gaza schicken, das soll ihre Paläste verzehren.
<G-vec00476-001-s097><devour.verzehren><en> But I will send a fire upon Teman, which shall devour the palaces of Bozrah.
<G-vec00476-001-s097><devour.verzehren><de> darum will ich ein Feuer nach Teman senden, das die Paläste von Bozra verzehren soll.
<G-vec00476-001-s098><devour.verzehren><en> 5:14 Therefore thus says Yahweh, the God of Armies, “Because you speak this word, behold, I will make my words in your mouth fire, and this people wood, and it shall devour them.
<G-vec00476-001-s098><devour.verzehren><de> 5:14 Darum, so spricht Jehova, der Gott der Heerscharen: Weil ihr dieses Wort redet, siehe, so will ich meine Worte in deinem Munde zu Feuer machen und dieses Volk zu Holz, und es soll sie verzehren.
<G-vec00476-001-s099><devour.verzehren><en> "5:14 Therefore thus says Yahweh, the God of Armies, ""Because you speak this word, behold, I will make my words in your mouth fire, and this people wood, and it shall devour them."
<G-vec00476-001-s099><devour.verzehren><de> 5:14 Darum, so spricht Jehova, der Gott der Heerscharen: Weil ihr dieses Wort redet, siehe, so will ich meine Worte in deinem Munde zu Feuer machen und dieses Volk zu Holz, und es soll sie verzehren.
<G-vec00476-001-s100><devour.verzehren><en> 10:27 But a certain fearful looking for of judgment and fiery indignation, which shall devour the adversaries.
<G-vec00476-001-s100><devour.verzehren><de> 10:27 sondern nur die Erwartung des furchtbaren Gerichts und ein wütendes Feuer, das die Gegner verzehren wird.
<G-vec00476-001-s101><devour.verzehren><en> 14 For Israel hath forgotten his Maker, and buildeth temples; and Judah hath multiplied fenced cities: but I will send a fire upon his cities, and it shall devour the palaces thereof.
<G-vec00476-001-s101><devour.verzehren><de> 14 Israel vergißt seinen Schöpfer und baut Paläste, und Juda macht viele feste Städte; aber ich will Feuer in seine Städte senden, das soll seine Paläste verzehren.
<G-vec00476-001-s102><devour.verzehren><en> Uncertainty and fear for the future devour the life forces.
<G-vec00476-001-s102><devour.verzehren><de> Unsicherheit und Zukunftsangst verzehren die Lebenskräfte.
<G-vec00476-001-s103><devour.verzehren><en> 5 And I will send a fire upon Judah, and it shall devour the palaces of Jerusalem.
<G-vec00476-001-s103><devour.verzehren><de> 5 so werde ich ein Feuer senden nach Juda, und es wird die Paläste Jerusalems verzehren.
<G-vec00476-001-s104><devour.verzehren><en> but a certain fearful expectation of judgment, and a fierceness of fire which will devour the adversaries.
<G-vec00476-001-s104><devour.verzehren><de> sondern ein schreckliches Warten des Gerichts und des Feuereifers, der die Widersacher verzehren wird.
<G-vec00476-001-s105><devour.verzehren><en> 18 For wickedness burneth as the fire: it shall devour the briers and thorns, and shall kindle in the thickets of the forest, and they shall mount up like the lifting up of smoke.
<G-vec00476-001-s105><devour.verzehren><de> Denn die Gottlosigkeit brennt wie Feuer: Dornen und Disteln verzehrt sie und zündet in den Dickichten des Waldes, daß sie emporwirbeln als hoch aufsteigender Rauch.
<G-vec00476-001-s106><devour.verzehren><en> The new German restaurant PeterPaul in Berlin-Mitte is where you can also share and jointly devour classic local dishes.
<G-vec00476-001-s106><devour.verzehren><de> Auch im neuen deutschen Restaurant PeterPaul in Berlin-Mitte werden die dort angebotenen Klassiker der hiesigen Küche geteilt und zusammen verzehrt.
<G-vec00476-001-s107><devour.verzehren><en> 5 And if any man will hurt them, fire shall come out of their mouths, and shall devour their enemies. And if any man will hurt them, in this manner must he be slain.
<G-vec00476-001-s107><devour.verzehren><de> 5 Und wenn ihnen jemand will Schaden tun, so geht Feuer aus ihrem Munde und verzehrt ihre Feinde; und wenn ihnen jemand will Schaden tun, der muss so getötet werden.
<G-vec00476-001-s108><devour.verzehren><en> """If ye will not hearken unto me to hallow the sabbath day, and not to bear a burden, even entering in at the gates of Jerusalem on the sabbath day; then will I kindle a fire in the gates thereof, and it shall devour the palaces of Jerusalem, and it shall not be quenched"" (verse 27)."
<G-vec00476-001-s108><devour.verzehren><de> """Werdet ihr aber nicht auf mein Gebot hören, den Sabbattag zu heiligen und keine Last am Sabbattag zu tragen durch die Tore Jerusalems, so will ich ein Feuer in ihren Toren anzünden, das die festen Häuser Jerusalems verzehrt - und nicht gelöscht werden kann"" (Vers 27)."
<G-vec00476-001-s109><devour.verzehren><en> 27 But if ye will not hearken unto me to hallow the sabbath day, and not to bear a burden, even entering in at the gates of Jerusalem on the sabbath day; then will I kindle a fire in the gates thereof, and it shall devour the palaces of Jerusalem, and it shall not be quenched.
<G-vec00476-001-s109><devour.verzehren><de> 27 Werdet ihr aber nicht auf mein Gebot hören, den Sabbattag zu heiligen und keine Last am Sabbattag zu tragen durch die Tore Jerusalems, so will ich ein Feuer in ihren Toren anzünden, das die festen Häuser Jerusalems verzehrt und nicht gelöscht werden kann.
<G-vec00476-001-s110><devour.verzehren><en> Verse 5: And if anyone will hurt them, fire shall go forth out of their mouth, and shall devour their enemies, signifies that they who wish to destroy these two essentials of the New Church, will perish from infernal love.
<G-vec00476-001-s110><devour.verzehren><de> Vers 5: Und wenn ihnen jemand will Schaden tun, so geht Feuer aus ihrem Munde und verzehrt ihre Feinde, bedeutet, daß diejenigen, die diese beiden Grundsätze der Neuen Kirche zerstören wollen, von teuflischer Liebe umkommen werden.
<G-vec00476-001-s111><devour.verzehren><en> 7 All of them are blazing like an oven; they devour their rulers.
<G-vec00476-001-s111><devour.verzehren><de> Hos 7:7 Sie glühten insgesamt wie dieser Ofen, verzehrten sie doch ihre Vorgesetzten.
<G-vec00476-001-s113><devour.verzehren><en> Dt 28:51 - And he will devour the fruit of your cattle, and the fruits of your land, until you have passed away, without leaving behind you wheat, or wine, or oil, or herds of oxen, or flocks of sheep: until he utterly destroys you.
<G-vec00476-001-s113><devour.verzehren><de> Dt 28:51 - und welche die Frucht deines Viehes und die Frucht deines Landes verzehren wird, bis du vertilgt bist; welche dir weder Getreide, noch Most, noch Öl, noch das Geworfene deiner Rinder, noch die Zucht deines Kleinviehes übriglassen wird, bis sie dich zu Grunde gerichtet hat.
<G-vec00476-002-s036><devour.einnehmen><en> Description As a Slayer, you are all that stands between your world and the Behemoths that seek to devour it.
<G-vec00476-002-s036><devour.einnehmen><de> Beschreibung Als Slayer befindest du dich zwischen deiner Welt und den Behemoths, die sie einnehmen wollen.
<G-vec00476-002-s037><devour.einnehmen><en> If you don't deal with it as soon as it starts spreading, it can quickly devour the whole middle section, making it very difficult to beat the level.
<G-vec00476-002-s037><devour.einnehmen><de> Wenn du damit nicht fertig wirst, sobald sie anfängt, sich auszubreiten, kann sie schnell den gesamten mittleren Abschnitt einnehmen, was es sehr schwierig macht, das Level zu schaffen.
<G-vec00476-002-s170><devour.verschlingen><en> And the dragon stood before the woman, who was about to give birth, so that, when she had brought forth, he might devour her son.
<G-vec00476-002-s170><devour.verschlingen><de> Der Drache stand vor der Frau, die gebären sollte; er wollte ihr Kind verschlingen, sobald es geboren war.
<G-vec00476-002-s125><devour.verschlucken><en> The vegetation grips onto its statues and is encrusted onto its facades, as if it were trying to make them disappear, to devour them.
<G-vec00476-002-s125><devour.verschlucken><de> Die Vegetation umarmt seine Statuen und frisst sich in die Fassaden, als ob es darum ginge, sie verschwinden zu lassen, sie zu verschlucken.
