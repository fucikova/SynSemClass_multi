<G-vec00389-002-s034><demolish.abbauen><en> At some point, the time will come to demolish our power stations.
<G-vec00389-002-s034><demolish.abbauen><de> Irgendwann kommt der Zeitpunkt, da unsere Kraftwerke abgebaut werden.
<G-vec00389-002-s019><demolish.abbrechen><en> Wire saws With over 325 years of innovation and passion, Husqvarna provides construction professionals with support, service and a wide range of machines, diamond tools and all accessories that you need to cut, saw, drill, demolish, grind and polish concrete.
<G-vec00389-002-s019><demolish.abbrechen><de> Mit über 325 Jahren gelebter Innovation und Leidenschaft bietet Husqvarna® Bauprofis Support, Service und ein breites Angebot an Maschinen, Diamantwerkzeugen und Zubehör, das Sie zum Schneiden, Sägen, Bohren, Abbrechen, Abschleifen und Polieren von Beton benötigen.
<G-vec00389-002-s023><demolish.abreissen><en> So it happens that many owners let the houses expire in order to be allowed to demolish the houses at the end of a period of 15 years (at least that’s how it was explained to me).
<G-vec00389-002-s023><demolish.abreissen><de> So kommt es, dass viele Besitzer die Häuser verfallen lassen, um nach Ablauf einer Frist von 15 Jahren, die Erlaubnis zu haben, die Häuser abreissen zu dürfen (so wurde es mir zumindest erklärt).
<G-vec00389-002-s021><demolish.abreißen><en> May 1985 Within 24 days, U.S. pioneer units with more than 100 troops and 60 vehicles demolish the remaining 21 buildings and level the area (official codename "Ghostbusters").
<G-vec00389-002-s021><demolish.abreißen><de> Mai 1985 Innerhalb von 24 Tagen haben die US-Pioniere mit über 100 Soldaten und 60 Fahrzeugen die weiteren 21 Bauten abgerissen (Offizielle Bezeichnung: Aktion Geisterjagd) und das Gelände eingeebnet.
<G-vec00389-002-s041><demolish.erschöpfen><en> This can likely demolish the game for the others at the table.
<G-vec00389-002-s041><demolish.erschöpfen><de> Dies ist in der Lage, das Spiel für die anderen am Tisch zu erschöpfen.
<G-vec00389-002-s048><demolish.ruinieren><en> This can likely demolish the game for the others at the table.
<G-vec00389-002-s048><demolish.ruinieren><de> Dies kann wahrscheinlich ruinieren das Spiel für die anderen an den Tisch.
<G-vec00389-002-s050><demolish.stürzen><en> Let us demolish the false gods of our mind and let us start slowly but steadily to understand the Kingdom within us so that we might recognize it everywhere as living life, to enable us to pass into our real potential.
<G-vec00389-002-s050><demolish.stürzen><de> Stürzen wir doch alle falschen Götter unseres Verstandes und beginnen wir langsam aber sicher das Reich in uns wahrzunehmen, damit wir es überall als lebendiges Leben, als Übergang zu unseren wahren Möglichkeiten wahrnehmen können.
<G-vec00389-002-s043><demolish.verlegen><en> Once the event or the trade-show is over, the floor can be recovered and re-used again elsewhere.The modules that compose the system are easy to remove and can be reused with no need to demolish and create unnecessary waste.
<G-vec00389-002-s043><demolish.verlegen><de> Nach Abschluss der Veranstaltung kann der Belag entfernt und anderswo neu verwendet werden,denn die Systemmodule lassen sich einfach und ohne jede Beschädigung und entsprechenden Entsorgungsbedarf abnehmen und neu verlegen.
<G-vec00389-002-s052><demolish.vertilgen><en> 5:14 I will uproot from among you your Asherah poles and demolish your cities.
<G-vec00389-002-s052><demolish.vertilgen><de> 5:13 und will deine Ascherabilder ausreißen aus deiner Mitte und deine Städte vertilgen.
<G-vec00389-002-s053><demolish.verwüsten><en> In August 1953, great destructive earthquakes demolish most of the island, destroying entire villages and causing incalculable damage.
<G-vec00389-002-s053><demolish.verwüsten><de> Im August 1953, die katastrophale Erdbeben verwüsten das größte Teil Ithakas.
<G-vec00389-002-s054><demolish.zerschlagen><en> Hence, if the Hasina government were sincere in its intention, it would have taken steps to demolish the nexus which is predominantly occupied by its party thugs – the cardinal “pillars” of this regime’s politics.
<G-vec00389-002-s054><demolish.zerschlagen><de> Wäre die Hasina-Regierung aufrichtig, würden sie alle ihnen zu Verfügung stehenden Schritte unternehmen, um dieses Netzwerk, welches überwiegend aus Parteigenossen der Awami-Liga besteht, zu zerschlagen.
<G-vec00389-002-s035><demolish.zerstören><en> Love is to demolish anything and everything in its way.
<G-vec00389-002-s035><demolish.zerstören><de> Liebe ist dazu da alles und jedes auf ihrem Weg zu zerstören.
<G-vec00389-002-s073><demolish.zertrümmern><en> In the scene, Bella (Kristen Stewart) tells Edward (Robert Pattinson) that "physically I feel like I could demolish a tank, [but] mentally I just feel drained."
<G-vec00389-002-s073><demolish.zertrümmern><de> In dieser Szene sagt Bella (Kristen Stewart) zu Edward (Robert Pattinson), dass sie das Gefühl habe, "körperlich so stark zu sein, dass sie einen Panzer zertrümmern könne, [aber] emotional völlig am Ende" sei.
<G-vec00389-002-s036><demolish.zurückbauen><en> Our task was to demolish the buildings, prepare the land, and subsequently sell the plots.
<G-vec00389-002-s036><demolish.zurückbauen><de> Unsere Aufgabe bestand darin, die Gebäude zurückzubauen, den Boden aufzubereiten und anschließend die Grundstücke zu veräußern.
