<EnglishT-wsj_0130-s12#EnglishT-wsj_0130-s12-t9><ev-w1072f1.v-w7903f1> Drug makers shouldn't be able <start_vauxs>to<end_vauxs> <start_vs>duck<end_vs> liability because people couldn't identify precisely which identical drug was used . 
<EnglishT-wsj_1457-s67#EnglishT-wsj_1457-s67-t4><ev-w1072f1.v-w1398f1> He evades and <start_vs>ducks<end_vs>. 
