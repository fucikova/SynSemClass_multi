<G-vec00417-002-s095><define.bestimmen><en> Shading based on the light direction or intensity is not done, so the specular highlights define the shape.
<G-vec00417-002-s095><define.bestimmen><de> Schattierung basierend auf der Lichtrichtung oder -intensität ist hier nicht möglich, weshalb der Lichtreflex das WordArt-Objekt bestimmt.
<G-vec00417-002-s096><define.bestimmen><en> The Terms of Service define the rules of using the services rendered by the Website by means of automatic processing and storing of information and data uploaded by the Website users to its database.
<G-vec00417-002-s096><define.bestimmen><de> Die Ordnung bestimmt die Grundsätze der Nutzung der von der Serviceplattform erbrachten Dienstleistungen im Wege der automatischen Verarbeitung und Erfassung von Informationen und Angaben, die von den Serviceplattformnutzern in die Serviceplattformdatenbank eingegeben werden.
<G-vec00417-002-s097><define.bestimmen><en> Handmade products and optics define this style.
<G-vec00417-002-s097><define.bestimmen><de> Bestimmt wird diese Stilwelt von handgefertigten Produkten und Optiken.
<G-vec00417-002-s098><define.bestimmen><en> The reason for leaving will define how you approach a change in your products or services.
<G-vec00417-002-s098><define.bestimmen><de> Der Grund für die Abwanderung bestimmt, ob und wie Sie Änderungen an Ihrem Produkt oder Service vornehmen sollten.
<G-vec00417-002-s099><define.bestimmen><en> Aspect Ratio: The aspect ratio is used to define and control the shape of the radial gradient.
<G-vec00417-002-s099><define.bestimmen><de> Seitenverhältnis Mit dem Seitenverhältnis wird die Form des kreisförmigen Verlaufs bestimmt.
<G-vec00417-002-s100><define.bestimmen><en> The choice of the supporting framework will define the effectiveness of the discussions around strategy, strategy awareness, and alignment of the low level strategies with the overall company’s strategy.
<G-vec00417-002-s100><define.bestimmen><de> Die Wahl des unterstützenden Rahmens bestimmt die Wirksamkeit der Diskussionen über die Strategie, das Strategiebewusstsein und die Abstimmung der Low-Level-Strategien mit der Gesamtstrategie des Unternehmens.
<G-vec00417-002-s101><define.bestimmen><en> Automated and networked driving is set to define the mobility of tomorrow.
<G-vec00417-002-s101><define.bestimmen><de> Automatisiertes und vernetztes Fahren bestimmt die Mobilität von Morgen.
<G-vec00417-002-s102><define.bestimmen><en> In this way, the vehicle can accurately define its position relative to the road and its surroundings.
<G-vec00417-002-s102><define.bestimmen><de> So bestimmt das Fahrzeug seine relative Position zu diesen Objekten.
<G-vec00417-002-s103><define.bestimmen><en> So, it’s skill not luck that define the outcome, and it’s you who decides how much time to spend competing: you can play 5 battles and call it a day if you’re happy with your score.
<G-vec00417-002-s103><define.bestimmen><de> Demnach bestimmt Können und nicht Glück das Ergebnis, und ihr entscheidet, wie viel Zeit ihr dafür verbringt: Ihr könnt fünf Gefechte spielen und es gut sein lassen, wenn ihr mit eurer Punktzahl zufrieden seid.
<G-vec00417-002-s104><define.bestimmen><en> The qualifications define your starting block – those who start at the back of the pack will ultimately end up in the bottleneck and therefore screw any chance of a decent position.
<G-vec00417-002-s104><define.bestimmen><de> Die Qualifikation bestimmt den Startblock – wer hinten startet, gerät bereits zu Anfang in den Stau und hat keine Chance auf gute Plätze.
<G-vec00417-002-s105><define.bestimmen><en> The loot-mechanisms of the financial systems are inscrutable in their abstract complexity and virtuality, the exploitation systems of totalitarian governed countries define the everyday life struggle of survival of the population.
<G-vec00417-002-s105><define.bestimmen><de> Die Beute-Mechanismen des Finanzsystems sind in ihrer Abstraktheit schwer nachzuvollziehen, im Gegensatz zu Ausbeutungssystemen in totalitär regierten Ländern, in denen Ausbeutung das alltägliche Leben und speziell den Überlebenskampf der Bevölkerung bestimmt.
<G-vec00417-002-s106><define.bestimmen><en> The terms of delivery of a sales document define, for example, whether the customer is charged for freight costs and whether they can be entered in the document lines of the sales document.
<G-vec00417-002-s106><define.bestimmen><de> Die Lieferbedingung eines Vertriebsbelegs bestimmt u.a., ob dem Kunden Frachtkosten berechnet werden und diese in den Belegpositionen des Vertriebsbelegs erfasst werden können.
<G-vec00417-002-s107><define.bestimmen><en> Our support is required for all international agreement which define the EU's role in the wider world, in particular for Association and Framework Agreements into which the Union enters with our wide array of global partners.
<G-vec00417-002-s107><define.bestimmen><de> Alle internationalen Abkommen, mit denen die Rolle der EU in der Welt bestimmt wird, bedürfen unserer Unterstützung; dies gilt insbesondere für Assoziierungs- und Rahmenabkommen, die die EU mit einer Vielfalt von Partnern weltweit abschließt.
<G-vec00417-002-s108><define.bestimmen><en> Rather than the ‘man without qualities’ that define August Sander’s portraits, Fischer is after something much more elemental and biological.
<G-vec00417-002-s108><define.bestimmen><de> Im Gegensatz zu dem „Mann ohne Eigenschaften“, der die Porträts August Sanders bestimmt, sucht Roland Fischer nach etwas, das weitaus elementarer und biologischer ist.
<G-vec00417-002-s109><define.bestimmen><en> Managers in particular have huge responsibility: “The actions of management define a department’s social climate,” says Müller.
<G-vec00417-002-s109><define.bestimmen><de> Besonders Vorgesetzte haben eine große Verantwortung: „Das Handeln der Führungskräfte bestimmt das soziale Klima in einer Abteilung“, sagt Karin Müller.
<G-vec00417-002-s110><define.bestimmen><en> For this purpose, surveys (wind monitoring) will be carried out in 2016-2017, which will help to define optimum locations for construction of wind power stations.
<G-vec00417-002-s110><define.bestimmen><de> Dafür werden Forschungen (Windmonitoring) in den Jahren 2016–2017 durchgeführt werden, nach deren Ergebnissen die optimalen Plätze für den Bau von Windanlagen bestimmt sein werden.
<G-vec00417-002-s111><define.bestimmen><en> With that said, the selection of the individual Color & Gloss shades define whether the salon treatment needs to focus on refreshing shine or whether an additional stronger pigmentation and more vibrance are necessary.
<G-vec00417-002-s111><define.bestimmen><de> Dabei bestimmt die Auswahl der individuellen Color & Gloss Nuance darüber, ob eine Glanzauffrischung im Fokus der Behandlung im Salon steht, oder ob zusätzlich eine stärkere Pigmentierung und mehr Leuchtkraft gewünscht sind.
<G-vec00417-002-s112><define.bestimmen><en> The manufacture of intaglio and relief printed wallpapers define the production profile.
<G-vec00417-002-s112><define.bestimmen><de> Das Produktionsprofil wird durch die Herstellung von Tief- und Prägedrucktapeten bestimmt.
<G-vec00417-002-s113><define.bestimmen><en> If hair loss persists, you should seek further diagnosis which will define the precise causes of hair loss so that you will then follow the appropriate course of treatment.
<G-vec00417-002-s113><define.bestimmen><de> Sollte Haarausfall weiter fortschreiten, müssen Sie sich dann an den Facharzt wenden und weitere Diagnose suchen, damit die exakten Haarausfallursachen bestimmt werden und Ihnen die angemessene Behandlung verordnet wird.
<G-vec00417-002-s265><define.definieren><en> If a certain trigger event happens, IFTTT will automatically react in a way that you can define.
<G-vec00417-002-s265><define.definieren><de> Wenn ein bestimmtes auslösendes Ereignis auftritt, reagiert IFTTT automatisch in der von Dir definierten Art und Weise.
<G-vec00417-002-s266><define.definieren><en> Values that used to define Europe as a community of social welfare states are slowly becoming obsolete.
<G-vec00417-002-s266><define.definieren><de> Jene Werte, die Europa einst als Sozialstaat definierten, rücken in die Vergangenheit.
<G-vec00417-002-s267><define.definieren><en> With our Investment Advisory, we actively support you in investing your assets, based on the investment strategy we define together.
<G-vec00417-002-s267><define.definieren><de> Im Rahmen der Anlageberatung unterstützen wir Sie aktiv beim Anlegen Ihres Vermögens basierend auf der gemeinsam definierten Anlagestrategie.
<G-vec00417-002-s268><define.definieren><en> People without the above-mentioned characteristics but are doing some good deeds like donating to orphanages, etc., though their acts are meritorious, do not necessarily qualify for what Spiritual science would define as ‘good’ people, especially if the act is done with pride.
<G-vec00417-002-s268><define.definieren><de> Menschen ohne diese Eigenschaften, die jedoch gute Taten vollbringen, wie an Waisenhäuser spenden usw., sammeln zwar viele Verdienste, bilden aber nicht notwendigerweise die von der spirituellen Wissenschaft definierten „guten Menschen“, besonders wenn ihre Taten sie stolz machen.
<G-vec00417-002-s269><define.definieren><en> And the cherry on top of the cake: in the long run each term you define will save you money, as you only pay once for each word translated.
<G-vec00417-002-s269><define.definieren><de> Die Kirsche oben drauf: Langfristig sparen Sie sich für jeden definierten Term Geld, da Sie für jedes übersetzte Wort nur einmal bezahlen müssen.
<G-vec00417-002-s270><define.definieren><en> In short our customers and we define Ria as a safe, reliable and effective company.
<G-vec00417-002-s270><define.definieren><de> Kurz gesagt, sowohl unsere Kunden als auch wir definierten Ria als ein sicheres, vertrauenswürdiges und effektives Unternehmen.
<G-vec00417-002-s271><define.definieren><en> Amazon Virtual Private Cloud lets you use security groups and network access control lists (ACLs) so that you have fine-grained control of the network traffic flowing to and from your Amazon EC2 instances in a logically isolated virtual network you define. Learn More »
<G-vec00417-002-s271><define.definieren><de> Amazon Virtual Private Cloud lässt die Nutzung von Sicherheitsgruppen und Zugriffsteuerungslisten (ACLs) für das Netzwerk zu, sodass Sie den Netzwerkdatenverkehr zu und von Ihren EC2-Instances in einem logisch isolierten von Ihnen definierten virtuellen Netzwerk differenziert steuern können.
<G-vec00417-002-s272><define.definieren><en> Amazon ECS allows you to customize how tasks are placed onto a cluster of EC2 instances based on built-in attributes such as instance type, Availability Zone, or custom attributes that you define.
<G-vec00417-002-s272><define.definieren><de> Mit Amazon ECS können Sie anpassen, wie Aufgaben auf einem Cluster von EC2-Instances basierend auf integrierten Attributen wie Instance-Typ, Availability Zone und von Ihnen definierten benutzerdefinierten Attributen platziert werden.
<G-vec00417-002-s273><define.definieren><en> In compliance with industry define norms and guidelines, these products are highly recommended by our customers for exhibiting international quality standards.
<G-vec00417-002-s273><define.definieren><de> In Übereinstimmung mit den von der Industrie definierten Normen und Richtlinien werden diese Produkte von unseren Kunden wärmstens empfohlen, um internationale Qualitätsstandards zu erfüllen.
<G-vec00417-002-s274><define.definieren><en> Purchase value – Use this filter to target those customers only whose purchase value meets the criterion you define here.
<G-vec00417-002-s274><define.definieren><de> Purchase value Verwenden Sie diesen Filter, um Kunden anzusprechen, deren Kaufwert den von Ihnen hier definierten Kriterien entspricht.
<G-vec00417-002-s275><define.definieren><en> Both types of shortcuts override the ones you define in the Specify Shortcuts dialog box. Related topics
<G-vec00417-002-s275><define.definieren><de> Beide Arten von Tastaturbefehlen überschreiben die von Ihnen im Dialogfeld „Tastaturbefehle angeben“ definierten Tastaturbefehle.
<G-vec00417-002-s276><define.definieren><en> When you design the initiation form, you choose whether or not to supply a default value for each of the parameters that you define.
<G-vec00417-002-s276><define.definieren><de> Beim Entwurf des Initiierungsformulars entscheiden Sie, ob Sie für jeden der von Ihnen definierten Parameter einen Standardwert angeben möchten.
<G-vec00417-002-s277><define.definieren><en> Now, rail vehicle manufacturers have joined to define the International Railway Industry Standard, IRIS for short, and set new standards for the future.
<G-vec00417-002-s277><define.definieren><de> Mit dem gemeinsam definierten International Railway Industry Standard, kurz IRIS, setzen die Schienenfahrzeughersteller nun neue Maßstäbe für die Zukunft.
<G-vec00417-002-s278><define.definieren><en> According to key fields you define, the Excel Adapter checks whether the record exists for updating or else will insert it into the sheet.
<G-vec00417-002-s278><define.definieren><de> Der Excel Adapter prüft anhand der definierten Schlüsselfelder automatisch ob der Datensatz aktualisiert oder aber nur an das Arbeitsblatt angefügt werden soll.
<G-vec00417-002-s279><define.definieren><en> Based on your current rankings and targets, that we define together, we use keyword research to determine possible new ranking potentials.
<G-vec00417-002-s279><define.definieren><de> Ausgehend von Ihren derzeitigen Rankings und den gemeinsam definierten Zielen ermitteln wir mithilfe einer Keyword Research neue, mögliche Rankingpotentiale.
<G-vec00417-002-s280><define.definieren><en> Due to the change in communications, we are - more than ever - in a position today, to sustainably follow and make the objectives measurable which our clients define.
<G-vec00417-002-s280><define.definieren><de> Durch den Wandel in der Kommunikation können wir heute, mehr denn je, nachhaltig die durch unsere Kunden definierten Ziele verfolgen und messbar machen.
<G-vec00417-002-s281><define.definieren><en> Your unaddressed items reach all households and all private customer P.O. Boxes in the target area you define.
<G-vec00417-002-s281><define.definieren><de> Ihre unadressierten Sendungen gelangen in alle Haushalte sowie in alle Privatkundenpostfächer in dem von Ihnen definierten Zielgebiet.
<G-vec00417-002-s282><define.definieren><en> The congress was the location of an encounter between various persons and languages which currently define what is still/already alive and what is still/already dead.
<G-vec00417-002-s282><define.definieren><de> Der Kongress inszenierte einen theatralen Ort der Wissenschaftspopularisierung, in dem verschiedene Personen und Redeweisen, Wissenschaftskulturen und spekulative Fiktionen definierten, was noch/schon lebendig und was noch/schon tot ist.
<G-vec00417-002-s283><define.definieren><en> Exhibitors can supplement the visitor data with additional, individual information such as memos of meetings, or define and then create categories using “tags”.
<G-vec00417-002-s283><define.definieren><de> Aussteller können den Besucherdaten zusätzliche, individuelle Informationen wie Gesprächsnotizen hinzufügen oder mit Hilfe von „Tags“ in selbst definierten Kategorien zusammenfassen.
<G-vec00417-002-s356><define.festlegen><en> The DMS settings define how the signature check is carried out.
<G-vec00417-002-s356><define.festlegen><de> In den DMS-Einstellungen ist festgelegt, wie die Signaturprüfung durchgeführt wird.
<G-vec00417-002-s357><define.festlegen><en> This phase will also define the mature aircraft documentation to be available for airline operators at EIS.
<G-vec00417-002-s357><define.festlegen><de> In dieser Phase wird auch festgelegt, wann die finale Flugzeugdokumentation für Flugzeugbetreiber bei der Indienststellung verfügbar ist.
<G-vec00417-002-s358><define.festlegen><en> The pension fund regulations define the vested benefits amount.
<G-vec00417-002-s358><define.festlegen><de> Die Höhe der Freizügigkeitsleistung ist im Vorsorgereglement festgelegt.
<G-vec00417-002-s359><define.festlegen><en> International electrical standards define specific tests to measure the stiffness of insulating materials based on mica.
<G-vec00417-002-s359><define.festlegen><de> Die internationalen Normen im Bezug auf elektrische Systeme haben spezifische Tests festgelegt, um die Steifheit von Isoliermaterialien aus Mika zu messen.
<G-vec00417-002-s360><define.festlegen><en> Automatic Connection Under Network > Provider > Automatic, define which provider is normally used for connection setup.
<G-vec00417-002-s360><define.festlegen><de> Unter Netzwerk > Provider > Automatik wird festgelegt, welcher Provider normalerweise für den Verbindungsaufbau verwendet wird.
<G-vec00417-002-s361><define.festlegen><en> To create a safer online environment, members of the Certificate Authorities Browser Forum met to define implementation guidelines for SSL certificates.
<G-vec00417-002-s361><define.festlegen><de> Um eine sichere Online-Umgebung zu schaffen, haben Mitglieder des Certificate Authorities Browser Forum Implementierungsrichtlinien für SSL-Zertifikate festgelegt.
<G-vec00417-002-s362><define.festlegen><en> These activities are used to define any required improvement measures, which are implemented by the responsible units and departments and then monitored on a regular basis.
<G-vec00417-002-s362><define.festlegen><de> Gegebenenfalls erforderliche Verbesserungsmaßnahmen werden auf dieser Basis festgelegt, durch die jeweils verantwortlichen Geschäftseinheiten umgesetzt und nach der Umsetzung regelmäßig auf ihren Erfolg überprüft.
<G-vec00417-002-s363><define.festlegen><en> The exception calendars of the resources define the times when the resources are not available as well as the times when the resources are available in addition to their regular capacity (exceptional times).
<G-vec00417-002-s363><define.festlegen><de> In den Ausnahmekalendern der Ressourcen ist festgelegt, wann die Ressourcen nicht zur Verfügung stehen sowie Zeiten, in denen die Ressourcen über die normale Kapazität hinaus bereitgestellt werden können (Ausnahmezeiten).
<G-vec00417-002-s364><define.festlegen><en> In the planning and project phase it is necessary to define by you along with our production manager the exact scope and sequences of the event.
<G-vec00417-002-s364><define.festlegen><de> In der Planungs- und Projektphase wird von Ihnen zusammen mit unserem Produktionsleiter der genaue Umfang und Ablauf festgelegt.
<G-vec00417-002-s365><define.festlegen><en> Part of this process is to define a target for each individual subsidiary.
<G-vec00417-002-s365><define.festlegen><de> Der angestrebte Wert wird dabei für jede Tochtergesellschaft festgelegt.
<G-vec00417-002-s366><define.festlegen><en> The Council, in accordance with the procedure laid down in Article 42, shall define the natural and legal persons subject to reporting requirements, the confidentiality regime and the appropriate provisions for enforcement.
<G-vec00417-002-s366><define.festlegen><de> Der Kreis der berichtspflichtigen natürlichen und juristischen Personen, die Bestimmungen über die Vertraulichkeit sowie die geeigneten Vorkehrungen zu ihrer Durchsetzung werden vom Rat nach dem Verfahren des Artikels 42 festgelegt.
<G-vec00417-002-s367><define.festlegen><en> Final adjustments are made during the sample creation stage and we work with you to mutually define the quality.
<G-vec00417-002-s367><define.festlegen><de> Im Rahmen einer Mustererstellung werden letzte Anpassungen vorgenommen und die Qualität gemeinsam mit Ihnen festgelegt.
<G-vec00417-002-s368><define.festlegen><en> These standards define the important rock parameters and how they has to be tested, leading to a classification of quality.
<G-vec00417-002-s368><define.festlegen><de> In ihnen wird festgelegt, was wie zu prüfen ist und wie der Dachschiefer entsprechend seiner Qualität zu klassifizieren ist.
<G-vec00417-002-s369><define.festlegen><en> Use the Edit IP and Domain Restrictions dialog box to define access restrictions for unspecified clients or to enable domain name restrictions for all rules. UI Element List
<G-vec00417-002-s369><define.festlegen><de> Im Dialogfeld IP- und Domäneneinschränkungen bearbeiten können Zugriffseinschränkungen für nicht angegebene Clients festgelegt oder Domänennameneinschränkungen für alle Regeln aktiviert werden.
<G-vec00417-002-s370><define.festlegen><en> Here you define the client group, the default currency, terms and what layouts should be used for this clients documents.
<G-vec00417-002-s370><define.festlegen><de> Hier ist auch festgelegt zu welcher Kundengruppe er gehört, welche Währung und welche Layouts bei seinen Dokumenten standardmässig verwendet werden sollen.
<G-vec00417-002-s371><define.festlegen><en> By selecting the roof structure you define the base geometry which can be adjusted by user-defined settings.
<G-vec00417-002-s371><define.festlegen><de> Durch die Wahl der Dachform wird die Grundgeometrie festgelegt welche dann benutzerspezifisch erweitert werden kann.
<G-vec00417-002-s372><define.festlegen><en> All participants are responsible to define values and goals and to agree upon behavioural patterns.
<G-vec00417-002-s372><define.festlegen><de> Werte und Ziele werden unter Verantwortung aller Teilnehmer festgelegt und Verhaltensweisen vereinbart.
<G-vec00417-002-s373><define.festlegen><en> If you are a Coresystems customer – this is also where we define how we handle your customer data.
<G-vec00417-002-s373><define.festlegen><de> Falls Sie ein Kunde von Coresystems sind – hier wird auch festgelegt, wie wir mit Ihren Kundendaten umgehen.
<G-vec00417-002-s374><define.festlegen><en> They define the line orientation that also affects the position of the line coordinate system.
<G-vec00417-002-s374><define.festlegen><de> Damit wird die Linienrichtung festgelegt, die auch die Lage des Linienkoordinatensystems beeinflusst.
