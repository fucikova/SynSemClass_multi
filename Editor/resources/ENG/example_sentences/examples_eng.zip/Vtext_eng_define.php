<G-vec00417-002-s095><define.bestimmen><en> Shading based on the light direction or intensity is not done, so the specular highlights define the shape.
<G-vec00417-002-s095><define.bestimmen><de> Schattierung basierend auf der Lichtrichtung oder -intensität ist hier nicht möglich, weshalb der Lichtreflex das WordArt-Objekt bestimmt.
<G-vec00417-002-s096><define.bestimmen><en> The Terms of Service define the rules of using the services rendered by the Website by means of automatic processing and storing of information and data uploaded by the Website users to its database.
<G-vec00417-002-s096><define.bestimmen><de> Die Ordnung bestimmt die Grundsätze der Nutzung der von der Serviceplattform erbrachten Dienstleistungen im Wege der automatischen Verarbeitung und Erfassung von Informationen und Angaben, die von den Serviceplattformnutzern in die Serviceplattformdatenbank eingegeben werden.
<G-vec00417-002-s097><define.bestimmen><en> Handmade products and optics define this style.
<G-vec00417-002-s097><define.bestimmen><de> Bestimmt wird diese Stilwelt von handgefertigten Produkten und Optiken.
<G-vec00417-002-s098><define.bestimmen><en> The reason for leaving will define how you approach a change in your products or services.
<G-vec00417-002-s098><define.bestimmen><de> Der Grund für die Abwanderung bestimmt, ob und wie Sie Änderungen an Ihrem Produkt oder Service vornehmen sollten.
<G-vec00417-002-s099><define.bestimmen><en> Aspect Ratio: The aspect ratio is used to define and control the shape of the radial gradient.
<G-vec00417-002-s099><define.bestimmen><de> Seitenverhältnis Mit dem Seitenverhältnis wird die Form des kreisförmigen Verlaufs bestimmt.
<G-vec00417-002-s100><define.bestimmen><en> The choice of the supporting framework will define the effectiveness of the discussions around strategy, strategy awareness, and alignment of the low level strategies with the overall company’s strategy.
<G-vec00417-002-s100><define.bestimmen><de> Die Wahl des unterstützenden Rahmens bestimmt die Wirksamkeit der Diskussionen über die Strategie, das Strategiebewusstsein und die Abstimmung der Low-Level-Strategien mit der Gesamtstrategie des Unternehmens.
<G-vec00417-002-s101><define.bestimmen><en> Automated and networked driving is set to define the mobility of tomorrow.
<G-vec00417-002-s101><define.bestimmen><de> Automatisiertes und vernetztes Fahren bestimmt die Mobilität von Morgen.
<G-vec00417-002-s102><define.bestimmen><en> In this way, the vehicle can accurately define its position relative to the road and its surroundings.
<G-vec00417-002-s102><define.bestimmen><de> So bestimmt das Fahrzeug seine relative Position zu diesen Objekten.
<G-vec00417-002-s103><define.bestimmen><en> So, it’s skill not luck that define the outcome, and it’s you who decides how much time to spend competing: you can play 5 battles and call it a day if you’re happy with your score.
<G-vec00417-002-s103><define.bestimmen><de> Demnach bestimmt Können und nicht Glück das Ergebnis, und ihr entscheidet, wie viel Zeit ihr dafür verbringt: Ihr könnt fünf Gefechte spielen und es gut sein lassen, wenn ihr mit eurer Punktzahl zufrieden seid.
<G-vec00417-002-s104><define.bestimmen><en> The qualifications define your starting block – those who start at the back of the pack will ultimately end up in the bottleneck and therefore screw any chance of a decent position.
<G-vec00417-002-s104><define.bestimmen><de> Die Qualifikation bestimmt den Startblock – wer hinten startet, gerät bereits zu Anfang in den Stau und hat keine Chance auf gute Plätze.
<G-vec00417-002-s105><define.bestimmen><en> The loot-mechanisms of the financial systems are inscrutable in their abstract complexity and virtuality, the exploitation systems of totalitarian governed countries define the everyday life struggle of survival of the population.
<G-vec00417-002-s105><define.bestimmen><de> Die Beute-Mechanismen des Finanzsystems sind in ihrer Abstraktheit schwer nachzuvollziehen, im Gegensatz zu Ausbeutungssystemen in totalitär regierten Ländern, in denen Ausbeutung das alltägliche Leben und speziell den Überlebenskampf der Bevölkerung bestimmt.
<G-vec00417-002-s106><define.bestimmen><en> The terms of delivery of a sales document define, for example, whether the customer is charged for freight costs and whether they can be entered in the document lines of the sales document.
<G-vec00417-002-s106><define.bestimmen><de> Die Lieferbedingung eines Vertriebsbelegs bestimmt u.a., ob dem Kunden Frachtkosten berechnet werden und diese in den Belegpositionen des Vertriebsbelegs erfasst werden können.
<G-vec00417-002-s107><define.bestimmen><en> Our support is required for all international agreement which define the EU's role in the wider world, in particular for Association and Framework Agreements into which the Union enters with our wide array of global partners.
<G-vec00417-002-s107><define.bestimmen><de> Alle internationalen Abkommen, mit denen die Rolle der EU in der Welt bestimmt wird, bedürfen unserer Unterstützung; dies gilt insbesondere für Assoziierungs- und Rahmenabkommen, die die EU mit einer Vielfalt von Partnern weltweit abschließt.
<G-vec00417-002-s108><define.bestimmen><en> Rather than the ‘man without qualities’ that define August Sander’s portraits, Fischer is after something much more elemental and biological.
<G-vec00417-002-s108><define.bestimmen><de> Im Gegensatz zu dem „Mann ohne Eigenschaften“, der die Porträts August Sanders bestimmt, sucht Roland Fischer nach etwas, das weitaus elementarer und biologischer ist.
<G-vec00417-002-s109><define.bestimmen><en> Managers in particular have huge responsibility: “The actions of management define a department’s social climate,” says Müller.
<G-vec00417-002-s109><define.bestimmen><de> Besonders Vorgesetzte haben eine große Verantwortung: „Das Handeln der Führungskräfte bestimmt das soziale Klima in einer Abteilung“, sagt Karin Müller.
<G-vec00417-002-s110><define.bestimmen><en> For this purpose, surveys (wind monitoring) will be carried out in 2016-2017, which will help to define optimum locations for construction of wind power stations.
<G-vec00417-002-s110><define.bestimmen><de> Dafür werden Forschungen (Windmonitoring) in den Jahren 2016–2017 durchgeführt werden, nach deren Ergebnissen die optimalen Plätze für den Bau von Windanlagen bestimmt sein werden.
<G-vec00417-002-s111><define.bestimmen><en> With that said, the selection of the individual Color & Gloss shades define whether the salon treatment needs to focus on refreshing shine or whether an additional stronger pigmentation and more vibrance are necessary.
<G-vec00417-002-s111><define.bestimmen><de> Dabei bestimmt die Auswahl der individuellen Color & Gloss Nuance darüber, ob eine Glanzauffrischung im Fokus der Behandlung im Salon steht, oder ob zusätzlich eine stärkere Pigmentierung und mehr Leuchtkraft gewünscht sind.
<G-vec00417-002-s112><define.bestimmen><en> The manufacture of intaglio and relief printed wallpapers define the production profile.
<G-vec00417-002-s112><define.bestimmen><de> Das Produktionsprofil wird durch die Herstellung von Tief- und Prägedrucktapeten bestimmt.
<G-vec00417-002-s113><define.bestimmen><en> If hair loss persists, you should seek further diagnosis which will define the precise causes of hair loss so that you will then follow the appropriate course of treatment.
<G-vec00417-002-s113><define.bestimmen><de> Sollte Haarausfall weiter fortschreiten, müssen Sie sich dann an den Facharzt wenden und weitere Diagnose suchen, damit die exakten Haarausfallursachen bestimmt werden und Ihnen die angemessene Behandlung verordnet wird.
<G-vec00417-002-s265><define.definieren><en> If a certain trigger event happens, IFTTT will automatically react in a way that you can define.
<G-vec00417-002-s265><define.definieren><de> Wenn ein bestimmtes auslösendes Ereignis auftritt, reagiert IFTTT automatisch in der von Dir definierten Art und Weise.
<G-vec00417-002-s266><define.definieren><en> Values that used to define Europe as a community of social welfare states are slowly becoming obsolete.
<G-vec00417-002-s266><define.definieren><de> Jene Werte, die Europa einst als Sozialstaat definierten, rücken in die Vergangenheit.
<G-vec00417-002-s267><define.definieren><en> With our Investment Advisory, we actively support you in investing your assets, based on the investment strategy we define together.
<G-vec00417-002-s267><define.definieren><de> Im Rahmen der Anlageberatung unterstützen wir Sie aktiv beim Anlegen Ihres Vermögens basierend auf der gemeinsam definierten Anlagestrategie.
<G-vec00417-002-s268><define.definieren><en> People without the above-mentioned characteristics but are doing some good deeds like donating to orphanages, etc., though their acts are meritorious, do not necessarily qualify for what Spiritual science would define as ‘good’ people, especially if the act is done with pride.
<G-vec00417-002-s268><define.definieren><de> Menschen ohne diese Eigenschaften, die jedoch gute Taten vollbringen, wie an Waisenhäuser spenden usw., sammeln zwar viele Verdienste, bilden aber nicht notwendigerweise die von der spirituellen Wissenschaft definierten „guten Menschen“, besonders wenn ihre Taten sie stolz machen.
<G-vec00417-002-s269><define.definieren><en> And the cherry on top of the cake: in the long run each term you define will save you money, as you only pay once for each word translated.
<G-vec00417-002-s269><define.definieren><de> Die Kirsche oben drauf: Langfristig sparen Sie sich für jeden definierten Term Geld, da Sie für jedes übersetzte Wort nur einmal bezahlen müssen.
<G-vec00417-002-s270><define.definieren><en> In short our customers and we define Ria as a safe, reliable and effective company.
<G-vec00417-002-s270><define.definieren><de> Kurz gesagt, sowohl unsere Kunden als auch wir definierten Ria als ein sicheres, vertrauenswürdiges und effektives Unternehmen.
<G-vec00417-002-s271><define.definieren><en> Amazon Virtual Private Cloud lets you use security groups and network access control lists (ACLs) so that you have fine-grained control of the network traffic flowing to and from your Amazon EC2 instances in a logically isolated virtual network you define. Learn More »
<G-vec00417-002-s271><define.definieren><de> Amazon Virtual Private Cloud lässt die Nutzung von Sicherheitsgruppen und Zugriffsteuerungslisten (ACLs) für das Netzwerk zu, sodass Sie den Netzwerkdatenverkehr zu und von Ihren EC2-Instances in einem logisch isolierten von Ihnen definierten virtuellen Netzwerk differenziert steuern können.
<G-vec00417-002-s272><define.definieren><en> Amazon ECS allows you to customize how tasks are placed onto a cluster of EC2 instances based on built-in attributes such as instance type, Availability Zone, or custom attributes that you define.
<G-vec00417-002-s272><define.definieren><de> Mit Amazon ECS können Sie anpassen, wie Aufgaben auf einem Cluster von EC2-Instances basierend auf integrierten Attributen wie Instance-Typ, Availability Zone und von Ihnen definierten benutzerdefinierten Attributen platziert werden.
<G-vec00417-002-s273><define.definieren><en> In compliance with industry define norms and guidelines, these products are highly recommended by our customers for exhibiting international quality standards.
<G-vec00417-002-s273><define.definieren><de> In Übereinstimmung mit den von der Industrie definierten Normen und Richtlinien werden diese Produkte von unseren Kunden wärmstens empfohlen, um internationale Qualitätsstandards zu erfüllen.
<G-vec00417-002-s274><define.definieren><en> Purchase value – Use this filter to target those customers only whose purchase value meets the criterion you define here.
<G-vec00417-002-s274><define.definieren><de> Purchase value Verwenden Sie diesen Filter, um Kunden anzusprechen, deren Kaufwert den von Ihnen hier definierten Kriterien entspricht.
<G-vec00417-002-s275><define.definieren><en> Both types of shortcuts override the ones you define in the Specify Shortcuts dialog box. Related topics
<G-vec00417-002-s275><define.definieren><de> Beide Arten von Tastaturbefehlen überschreiben die von Ihnen im Dialogfeld „Tastaturbefehle angeben“ definierten Tastaturbefehle.
<G-vec00417-002-s276><define.definieren><en> When you design the initiation form, you choose whether or not to supply a default value for each of the parameters that you define.
<G-vec00417-002-s276><define.definieren><de> Beim Entwurf des Initiierungsformulars entscheiden Sie, ob Sie für jeden der von Ihnen definierten Parameter einen Standardwert angeben möchten.
<G-vec00417-002-s277><define.definieren><en> Now, rail vehicle manufacturers have joined to define the International Railway Industry Standard, IRIS for short, and set new standards for the future.
<G-vec00417-002-s277><define.definieren><de> Mit dem gemeinsam definierten International Railway Industry Standard, kurz IRIS, setzen die Schienenfahrzeughersteller nun neue Maßstäbe für die Zukunft.
<G-vec00417-002-s278><define.definieren><en> According to key fields you define, the Excel Adapter checks whether the record exists for updating or else will insert it into the sheet.
<G-vec00417-002-s278><define.definieren><de> Der Excel Adapter prüft anhand der definierten Schlüsselfelder automatisch ob der Datensatz aktualisiert oder aber nur an das Arbeitsblatt angefügt werden soll.
<G-vec00417-002-s279><define.definieren><en> Based on your current rankings and targets, that we define together, we use keyword research to determine possible new ranking potentials.
<G-vec00417-002-s279><define.definieren><de> Ausgehend von Ihren derzeitigen Rankings und den gemeinsam definierten Zielen ermitteln wir mithilfe einer Keyword Research neue, mögliche Rankingpotentiale.
<G-vec00417-002-s280><define.definieren><en> Due to the change in communications, we are - more than ever - in a position today, to sustainably follow and make the objectives measurable which our clients define.
<G-vec00417-002-s280><define.definieren><de> Durch den Wandel in der Kommunikation können wir heute, mehr denn je, nachhaltig die durch unsere Kunden definierten Ziele verfolgen und messbar machen.
<G-vec00417-002-s281><define.definieren><en> Your unaddressed items reach all households and all private customer P.O. Boxes in the target area you define.
<G-vec00417-002-s281><define.definieren><de> Ihre unadressierten Sendungen gelangen in alle Haushalte sowie in alle Privatkundenpostfächer in dem von Ihnen definierten Zielgebiet.
<G-vec00417-002-s282><define.definieren><en> The congress was the location of an encounter between various persons and languages which currently define what is still/already alive and what is still/already dead.
<G-vec00417-002-s282><define.definieren><de> Der Kongress inszenierte einen theatralen Ort der Wissenschaftspopularisierung, in dem verschiedene Personen und Redeweisen, Wissenschaftskulturen und spekulative Fiktionen definierten, was noch/schon lebendig und was noch/schon tot ist.
<G-vec00417-002-s283><define.definieren><en> Exhibitors can supplement the visitor data with additional, individual information such as memos of meetings, or define and then create categories using “tags”.
<G-vec00417-002-s283><define.definieren><de> Aussteller können den Besucherdaten zusätzliche, individuelle Informationen wie Gesprächsnotizen hinzufügen oder mit Hilfe von „Tags“ in selbst definierten Kategorien zusammenfassen.
<G-vec00417-002-s356><define.festlegen><en> The DMS settings define how the signature check is carried out.
<G-vec00417-002-s356><define.festlegen><de> In den DMS-Einstellungen ist festgelegt, wie die Signaturprüfung durchgeführt wird.
<G-vec00417-002-s357><define.festlegen><en> This phase will also define the mature aircraft documentation to be available for airline operators at EIS.
<G-vec00417-002-s357><define.festlegen><de> In dieser Phase wird auch festgelegt, wann die finale Flugzeugdokumentation für Flugzeugbetreiber bei der Indienststellung verfügbar ist.
<G-vec00417-002-s358><define.festlegen><en> The pension fund regulations define the vested benefits amount.
<G-vec00417-002-s358><define.festlegen><de> Die Höhe der Freizügigkeitsleistung ist im Vorsorgereglement festgelegt.
<G-vec00417-002-s359><define.festlegen><en> International electrical standards define specific tests to measure the stiffness of insulating materials based on mica.
<G-vec00417-002-s359><define.festlegen><de> Die internationalen Normen im Bezug auf elektrische Systeme haben spezifische Tests festgelegt, um die Steifheit von Isoliermaterialien aus Mika zu messen.
<G-vec00417-002-s360><define.festlegen><en> Automatic Connection Under Network > Provider > Automatic, define which provider is normally used for connection setup.
<G-vec00417-002-s360><define.festlegen><de> Unter Netzwerk > Provider > Automatik wird festgelegt, welcher Provider normalerweise für den Verbindungsaufbau verwendet wird.
<G-vec00417-002-s361><define.festlegen><en> To create a safer online environment, members of the Certificate Authorities Browser Forum met to define implementation guidelines for SSL certificates.
<G-vec00417-002-s361><define.festlegen><de> Um eine sichere Online-Umgebung zu schaffen, haben Mitglieder des Certificate Authorities Browser Forum Implementierungsrichtlinien für SSL-Zertifikate festgelegt.
<G-vec00417-002-s362><define.festlegen><en> These activities are used to define any required improvement measures, which are implemented by the responsible units and departments and then monitored on a regular basis.
<G-vec00417-002-s362><define.festlegen><de> Gegebenenfalls erforderliche Verbesserungsmaßnahmen werden auf dieser Basis festgelegt, durch die jeweils verantwortlichen Geschäftseinheiten umgesetzt und nach der Umsetzung regelmäßig auf ihren Erfolg überprüft.
<G-vec00417-002-s363><define.festlegen><en> The exception calendars of the resources define the times when the resources are not available as well as the times when the resources are available in addition to their regular capacity (exceptional times).
<G-vec00417-002-s363><define.festlegen><de> In den Ausnahmekalendern der Ressourcen ist festgelegt, wann die Ressourcen nicht zur Verfügung stehen sowie Zeiten, in denen die Ressourcen über die normale Kapazität hinaus bereitgestellt werden können (Ausnahmezeiten).
<G-vec00417-002-s364><define.festlegen><en> In the planning and project phase it is necessary to define by you along with our production manager the exact scope and sequences of the event.
<G-vec00417-002-s364><define.festlegen><de> In der Planungs- und Projektphase wird von Ihnen zusammen mit unserem Produktionsleiter der genaue Umfang und Ablauf festgelegt.
<G-vec00417-002-s365><define.festlegen><en> Part of this process is to define a target for each individual subsidiary.
<G-vec00417-002-s365><define.festlegen><de> Der angestrebte Wert wird dabei für jede Tochtergesellschaft festgelegt.
<G-vec00417-002-s366><define.festlegen><en> The Council, in accordance with the procedure laid down in Article 42, shall define the natural and legal persons subject to reporting requirements, the confidentiality regime and the appropriate provisions for enforcement.
<G-vec00417-002-s366><define.festlegen><de> Der Kreis der berichtspflichtigen natürlichen und juristischen Personen, die Bestimmungen über die Vertraulichkeit sowie die geeigneten Vorkehrungen zu ihrer Durchsetzung werden vom Rat nach dem Verfahren des Artikels 42 festgelegt.
<G-vec00417-002-s367><define.festlegen><en> Final adjustments are made during the sample creation stage and we work with you to mutually define the quality.
<G-vec00417-002-s367><define.festlegen><de> Im Rahmen einer Mustererstellung werden letzte Anpassungen vorgenommen und die Qualität gemeinsam mit Ihnen festgelegt.
<G-vec00417-002-s368><define.festlegen><en> These standards define the important rock parameters and how they has to be tested, leading to a classification of quality.
<G-vec00417-002-s368><define.festlegen><de> In ihnen wird festgelegt, was wie zu prüfen ist und wie der Dachschiefer entsprechend seiner Qualität zu klassifizieren ist.
<G-vec00417-002-s369><define.festlegen><en> Use the Edit IP and Domain Restrictions dialog box to define access restrictions for unspecified clients or to enable domain name restrictions for all rules. UI Element List
<G-vec00417-002-s369><define.festlegen><de> Im Dialogfeld IP- und Domäneneinschränkungen bearbeiten können Zugriffseinschränkungen für nicht angegebene Clients festgelegt oder Domänennameneinschränkungen für alle Regeln aktiviert werden.
<G-vec00417-002-s370><define.festlegen><en> Here you define the client group, the default currency, terms and what layouts should be used for this clients documents.
<G-vec00417-002-s370><define.festlegen><de> Hier ist auch festgelegt zu welcher Kundengruppe er gehört, welche Währung und welche Layouts bei seinen Dokumenten standardmässig verwendet werden sollen.
<G-vec00417-002-s371><define.festlegen><en> By selecting the roof structure you define the base geometry which can be adjusted by user-defined settings.
<G-vec00417-002-s371><define.festlegen><de> Durch die Wahl der Dachform wird die Grundgeometrie festgelegt welche dann benutzerspezifisch erweitert werden kann.
<G-vec00417-002-s372><define.festlegen><en> All participants are responsible to define values and goals and to agree upon behavioural patterns.
<G-vec00417-002-s372><define.festlegen><de> Werte und Ziele werden unter Verantwortung aller Teilnehmer festgelegt und Verhaltensweisen vereinbart.
<G-vec00417-002-s373><define.festlegen><en> If you are a Coresystems customer – this is also where we define how we handle your customer data.
<G-vec00417-002-s373><define.festlegen><de> Falls Sie ein Kunde von Coresystems sind – hier wird auch festgelegt, wie wir mit Ihren Kundendaten umgehen.
<G-vec00417-002-s374><define.festlegen><en> They define the line orientation that also affects the position of the line coordinate system.
<G-vec00417-002-s374><define.festlegen><de> Damit wird die Linienrichtung festgelegt, die auch die Lage des Linienkoordinatensystems beeinflusst.
<G-vec00127-002-s038><define.beschreiben><en> This means that we must always define the purpose before we can define and build the model, and that there will always be several models for different purposes.
<G-vec00127-002-s038><define.beschreiben><de> Das bedeutet, dass wir immer den Zweck vordefinieren müssen, bevor wir das Modell beschreiben und erstellen können, und dass es immer mehrere Modelle für die unterschiedlichen Zwecke geben wird.
<G-vec00127-002-s039><define.beschreiben><en> Terms and conditions The terms and conditions define the appropriate use of the site.
<G-vec00127-002-s039><define.beschreiben><de> Die Nutzungsbedingungen beschreiben den angemessenen Umgang mit der Seite und seinen Möglichkeiten.
<G-vec00127-002-s040><define.beschreiben><en> In order to define a holiday among nature in Gelderland, you must visit the De Hoge Veluwe National Park here, with its extensive forests and a most beautiful atmosphere.
<G-vec00127-002-s040><define.beschreiben><de> Um einen Natururlaub in Gelderland beschreiben zu können, sollen Sie den Naturpark De Hoge Veluwe besucht haben, denn er verfügt über riesige Wälder und eine wunderbare Atmosphäre.
<G-vec00127-002-s041><define.beschreiben><en> If I had to define Link with four words, I would say that it is modular, architectural, structured, and versatile.
<G-vec00127-002-s041><define.beschreiben><de> Wenn ich die Link in vier Wörtern beschreiben sollte, würde ich sie als modular, ansprechend, strukturiert und vielseitig bezeichnen.
<G-vec00127-002-s042><define.beschreiben><en> This is one of the recipes that best define Mediterranean cuisine.
<G-vec00127-002-s042><define.beschreiben><de> Dies ist eines der Rezepte, die die mediterrane Küche am besten beschreiben.
<G-vec00127-002-s043><define.beschreiben><en> Comfort, modularity, privacy, originality, accessibility… these are words which not only define the Business Center, they are also the very foundation of its creation.
<G-vec00127-002-s043><define.beschreiben><de> Komfortabel, modulierbar, diskret, originell und gut erreichbar – diese Worte beschreiben nicht nur das Business Center, sondern das Gesamtkonzept hinter seiner Gründung.
<G-vec00127-002-s044><define.beschreiben><en> In 2017, Sulzer engaged over 150 colleagues from all across the world to refresh and re-energize how employees identify with the current Sulzer values, and to define the specific behaviors that represent our preferred ways of working.
<G-vec00127-002-s044><define.beschreiben><de> 2017 hat Sulzer mehr als 150 Kolleginnen und Kollegen aus der ganzen Welt damit beauftragt, die Identifikation der Mitarbeitenden mit den aktuellen Sulzer-Werten neu zu beleben und die für uns spezifischen Arbeitsweisen zu beschreiben.
<G-vec00127-002-s045><define.beschreiben><en> Conduct periodic or one-time surveys—scenarios include risk identification, supplier audits, business impact analysis and more. Analyze and communicate risk exposure Simulate risk events along defined business process chains; analyze dependencies between business processes, risks and controls; and use statistical methods to define risk probabilities and damage distributions.
<G-vec00127-002-s045><define.beschreiben><de> Analyse und Kommunikation der Risikolage Sie können Risikoereignisse für bestimmte Geschäftsprozessketten simulieren, Wechselbeziehungen zwischen Prozessen analysieren, mithilfe von Statistik Risikowahrscheinlichkeit und Schadensverteilung feststellen, Risikoszenarien detailliert beschreiben und untersuchen, unterschiedliche Risikoszenarien beschreiben und Dritte über Ihre Risikostrategie informieren.
<G-vec00127-002-s046><define.beschreiben><en> You can define the desired amount of products, manufacturers and the date of delivery.
<G-vec00127-002-s046><define.beschreiben><de> Du kannst die gewünschte Menge von Produkte, Hersteller und der Termin der Lieferung beschreiben.
<G-vec00127-002-s047><define.beschreiben><en> Results of that survey define the Main Homestake zone surprisingly accurately, and suggest that our previous drilling at the Homestake Silver zone tested only the northern margin of a large region of potassic alteration with sizeable on-strike potential.
<G-vec00127-002-s047><define.beschreiben><de> Die Ergebnisse dieser Untersuchungen beschreiben die Ergebnisse der Homestake Mainzone überraschend genau und geben uns Hinweise, dass die früheren Bohrungen auf der Homestake Silberzone nur den nördlichen Teil der großen Feldspatumgebung trafen und eine gute Chance auf eine Verlängerung des Trends besteht.
<G-vec00127-002-s048><define.beschreiben><en> With devices like the Rift and HTC’s Vive (hence ‘Viveport’), virtual reality has the chance to offer a new way of playing, learning and exploring, though sometimes it’s hard to define it without trying it.
<G-vec00127-002-s048><define.beschreiben><de> Mit Geräten wie dem Rift und dem Vive von HTC (daher «Viveport») kann die virtuelle Realität heute neue Wege zum Spielen, Lernen und Erkunden bieten, wobei das manchmal schwer zu beschreiben ist, ohne es selbst zu versuchen.
<G-vec00127-002-s049><define.beschreiben><en> New methodology Now an international consortium of leading physicists wants to apply novel techniques and better define, model and conceptualize turbulent flows.
<G-vec00127-002-s049><define.beschreiben><de> Jetzt möchte ein internationales Konsortium führender Physiker neuartige Techniken einsetzen und das Problem turbulenter Strömungen besser beschreiben, modellieren und konzipieren.
<G-vec00127-002-s050><define.beschreiben><en> We define aesthetics, density, color and fragrance.
<G-vec00127-002-s050><define.beschreiben><de> Wir beschreiben ästhetische Merkmale, Konsistenz, Farbe und Duft.
<G-vec00127-002-s051><define.beschreiben><en> We will define these new systems and initiates can cross check their own biology for a complete formation of each to assure that one is not having a physical problem with one's ascent.
<G-vec00127-002-s051><define.beschreiben><de> Wir werden diese neuen Systeme beschreiben, damit die Eingeweihten prüfen können, ob ihr Körper sich vollständig formt, damit man keine Probleme während des Aufstiegs hat.
<G-vec00127-002-s052><define.beschreiben><en> If we were to define ourselves in three words, we would probably use: calm, usability and nature .
<G-vec00127-002-s052><define.beschreiben><de> Wenn wir uns in drei Worten beschreiben müssten, wären das zweifellos: Ruhe, Gemütlichkeit und Natur.
<G-vec00127-002-s053><define.beschreiben><en> We will focus on the needs of your company, define requirements and reveal gaps.
<G-vec00127-002-s053><define.beschreiben><de> Wir fokussieren auf die Bedürfnisse Ihres Unternehmens, beschreiben Anforderungen und decken Lücken auf.
<G-vec00127-002-s054><define.beschreiben><en> In a three-dimensional space, for example, your office, you will need a set of three coordinates to define the point: its distance from the left wall, its distance from the back wall, and its height above the floor.
<G-vec00127-002-s054><define.beschreiben><de> In einer dreidimensionalen Welt, beispielsweise Ihrem Büro, brauchen Sie drei Koordinaten, um den Punkt zu beschreiben: seinen Abstand von der linken Wand, seinen Abstand von der hinteren Wand und seine Höhe über dem Boden.
<G-vec00127-002-s055><define.beschreiben><en> An impressionist painting. This is how we can define the breathtaking beauty of Lake Garda in spring.
<G-vec00127-002-s055><define.beschreiben><de> Ein impressionistisches Gemälde: So können wir die atemberaubende Schönheit des Gardasees im Frühling beschreiben.
<G-vec00127-002-s056><define.beschreiben><en> Below is a recap of the five key principles that define how TGM views the application of ESG factors in the research and investment process.
<G-vec00127-002-s056><define.beschreiben><de> Nachstehend sind die fünf wichtigsten Grundsätze zusammengefasst, die die Anwendung von ESG-Faktoren im Research- und Investmentprozess bei TGM beschreiben.
<G-vec00127-002-s057><define.bestimmen><en> Meaning By enabling this check box, you define that all coverage problems for a part are displayed.
<G-vec00127-002-s057><define.bestimmen><de> Bedeutung Mit dem aktiven Kontrollkästchen bestimmen Sie, dass zu einem Teil alle Deckungsprobleme angezeigt werden.
<G-vec00127-002-s058><define.bestimmen><en> There is no doubt that the mediating chain from the foundations to the ethics for the rational metaphysics is a royal road because of the circumstances, while it cannot be in Kant an occasion to define exactly the own functional and systematic place of the ethics in the three critiques.
<G-vec00127-002-s058><define.bestimmen><de> Kein Zweifel, dass die Vermittlungskette von den Fundamenten bis hin zur Ethik für die rationale Metaphysik aufgrund der Gegebenheiten geradezu ein Königsweg ist, während es bei Kant kein Anlass sein kann, den eigenen funktionalen und systematischen Ort der Ethik in den Drei Kritiken exakt zu bestimmen.
<G-vec00127-002-s059><define.bestimmen><en> The corporate SERVICE guideline for leadership and cooperation forms the basis of all company decisions and define the day-to-day business at STRABAG Property and Facility Services.
<G-vec00127-002-s059><define.bestimmen><de> Die Unternehmensleitlinien SERVICE bilden die Grundlage aller Unternehmensentscheidungen und bestimmen das tägliche Handeln bei STRABAG Property and Facility Services.
<G-vec00127-002-s060><define.bestimmen><en> Its members define the positions of IHK towards politics and administration.
<G-vec00127-002-s060><define.bestimmen><de> Ihre Mitglieder bestimmen die Positionen der IHK gegenüber Politik und Verwaltung.
<G-vec00127-002-s061><define.bestimmen><en> The "%d" placeholder must be used in the template in order to define the PDF document page.
<G-vec00127-002-s061><define.bestimmen><de> In dem Template muss der Platzhalter "%d" verwendet werden, um die Seite des PDF-Dokuments zu bestimmen.
<G-vec00127-002-s062><define.bestimmen><en> The experts define the status of your maintenance activities, examine your records and observations.
<G-vec00127-002-s062><define.bestimmen><de> Die Experten bestimmen den Status Ihrer Wartungsaktivitäten, untersuchen Ihre Aufzeichnungen und Beobachtungen.
<G-vec00127-002-s063><define.bestimmen><en> Meaning When reporting data entries for service items, resources, materials and costs, you use the billing to define whether the customer is charged for the costs.
<G-vec00127-002-s063><define.bestimmen><de> Bedeutung Beim Erfassen von Rückmeldungen für Serviceleistungen, Ressourcen, Materialien und Kosten bestimmen Sie mit der Berechnung, ob die Kosten dem Kunden in Rechnung gestellt werden.
<G-vec00127-002-s064><define.bestimmen><en> Facilitated sessions that will help you define the portfolio model that best meets your needs.
<G-vec00127-002-s064><define.bestimmen><de> Moderierte Sitzungen, die Ihnen dabei helfen sollen, zu bestimmen, welche Portfolio-Modell Ihren Bedürfnissen am meisten entgegenkommt.
<G-vec00127-002-s065><define.bestimmen><en> When creating an analysis, you use the fiscal year and posting period to define the period for which the analysis is created.
<G-vec00127-002-s065><define.bestimmen><de> Beim Erstellen einer Auswertung bestimmen Sie anhand von Geschäftsjahr und Buchungsperiode, für welchen Zeitraum die Auswertung erstellt wird.
<G-vec00127-002-s066><define.bestimmen><en> Animated images like this are pervasive in our visual culture and define everyday life to such a degree that we hardly are aware of them.
<G-vec00127-002-s066><define.bestimmen><de> Animierte Bilder wie diese durchdringen die visuelle Kultur und bestimmen unseren Alltag so selbstverständlich mit, dass wir sie kaum bewusst wahrnehmen.
<G-vec00127-002-s067><define.bestimmen><en> Meaning By enabling the check box, you define that zero values are suppressed in the data field, i.e., that they are not output in the form or report.
<G-vec00127-002-s067><define.bestimmen><de> Bedeutung Mit dem aktiven Kontrollkästchen bestimmen Sie, dass in dem Datenfeld Nullwerte unterdrückt werden, d.h. im Formular oder der Liste nicht ausgegeben werden.
<G-vec00127-002-s068><define.bestimmen><en> During the generation of such a shipping document you define the quantity of the part of the document line that is returned.
<G-vec00127-002-s068><define.bestimmen><de> Bei der Generierung eines solchen Lieferscheins bestimmen Sie, welche Menge des Teils der Belegposition zurückgeliefert wird.
<G-vec00127-002-s069><define.bestimmen><en> For clients, it’s important to define what will be measured and why.
<G-vec00127-002-s069><define.bestimmen><de> Für Kunden ist es wichtig zu bestimmen, was gemessen werden soll und warum.
<G-vec00127-002-s070><define.bestimmen><en> Speed and versatility define everyday life in Mühlacker today.
<G-vec00127-002-s070><define.bestimmen><de> Tempo und Vielfalt bestimmen heute den Alltag in Mühlacker.
<G-vec00127-002-s071><define.bestimmen><en> Content Reference You can define how the content is composed for reflection.
<G-vec00127-002-s071><define.bestimmen><de> Inhalt Referenz Du kannst bestimmen, wie sich der Inhalt für die Reflexion zusammensetzt.
<G-vec00127-002-s072><define.bestimmen><en> In October 2015 they had to leave, in the very moment when others decided to ignore the borders and define their own way themselves.
<G-vec00127-002-s072><define.bestimmen><de> Im Herbst 2015 mussten sie gehen - genau in dem Moment, als andere beschlossen, Grenzen zu ignorieren und den eigenen Weg selbst zu bestimmen.
<G-vec00127-002-s073><define.bestimmen><en> The setting up of a network and a web-based expert platform should encourage an exchange between Asian and European experts, weigh up possibilities for further development and define the steps to be taken along the path to practical implementation.
<G-vec00127-002-s073><define.bestimmen><de> Die Ausbildung eines Netzwerks und einer webbasierten Expertenplattform soll den Austausch zwischen asiatischen und europäischen Experten fördern, Ausbaumöglichkeiten abwägen und Schritte auf dem Weg zur Umsetzung bestimmen.
<G-vec00127-002-s074><define.bestimmen><en> The operations and messages are described abstractly, and then bound to a concrete network protocol and message format to define an endpoint.
<G-vec00127-002-s074><define.bestimmen><de> Operationen und Nachrichten werden abstrakt beschrieben, um dann an ein konkretes Netzwerkprotokoll und Nachrichtenformat gebunden zu werden, um einen Endpoint zu bestimmen.
<G-vec00127-002-s075><define.bestimmen><en> If you're not satisfied with the output file size, you can define it by yourself with the built-in bitrate calculator.
<G-vec00127-002-s075><define.bestimmen><de> Wenn Sie mit den Ausgabe-Dateigrößen nicht zufrieden sind, können Sie diese mit dem integrierten Bitrate-Rechner selbst bestimmen.
<G-vec00127-002-s076><define.bestimmen><en> You use the Set Rep Obligation check box to define how the report obligation is changed.
<G-vec00127-002-s076><define.bestimmen><de> Mit dem Kontrollkästchen Meldepflicht setzen bestimmen Sie, wie die Meldepflicht geändert wird.
<G-vec00127-002-s077><define.bestimmen><en> The option group is used to define whether open, archived or all records are output in the report.
<G-vec00127-002-s077><define.bestimmen><de> Mit der Optionsgruppe bestimmen Sie, ob in der Liste offene, archivierte oder alle Datensätze ausgegeben werden.
<G-vec00127-002-s078><define.bestimmen><en> You use the check box to define how negative inventory values are output.
<G-vec00127-002-s078><define.bestimmen><de> Mit dem Kontrollkästchen bestimmen Sie, wie negative Bestandswerte ausgegeben werden.
<G-vec00127-002-s079><define.bestimmen><en> Use the Personal/Global option group to define whether personal links only or global links only are displayed.
<G-vec00127-002-s079><define.bestimmen><de> Bestimmen Sie mit der Optionsgruppe Persönlich/Global, ob nur persönliche oder nur globale Verknüpfungen angezeigt werden.
<G-vec00127-002-s080><define.bestimmen><en> The Month/Year and All fields define the time period for which the data are displayed.
<G-vec00127-002-s080><define.bestimmen><de> Mit den Feldern Monat/Jahr und alle bestimmen Sie den Zeitbereich, zu dem die Daten angezeigt werden.
<G-vec00127-002-s081><define.bestimmen><en> Form Number CC The form number is used to define the form template which is used to output packaging labels.
<G-vec00127-002-s081><define.bestimmen><de> Formularnummer LT Mit der Formularnummer bestimmen Sie, welche Formularvorlage für die Ausgabe von Anhängern für Packmittel verwendet wird.
<G-vec00127-002-s082><define.bestimmen><en> The part number is used to define the service item for which the operation is created.
<G-vec00127-002-s082><define.bestimmen><de> Mit der Teilenummer bestimmen Sie, für welche Serviceleistung die Arbeitsaktivität angelegt wird.
<G-vec00127-002-s083><define.bestimmen><en> You use the tax ID type to define whether and which tax identification numbers are determined for domestic business activities during tax determination.
<G-vec00127-002-s083><define.bestimmen><de> Mit dem Steuernummerntypen bestimmen Sie, ob und welche Steuer-Identifikationsnummern bei der Steuerfindung für inländische Geschäftsvorgänge ermittelt werden.
<G-vec00127-002-s084><define.bestimmen><en> Define the selection criteria in the appropriate fields in order to filter for the parts and/or product lines for which you want to generate planned BOMs.
<G-vec00127-002-s084><define.bestimmen><de> Bestimmen Sie in den dafür vorgesehenen Feldern die Selektionskriterien, um die Teile und/oder Teilegruppen einzugrenzen, zu denen Planstücklisten generiert werden sollen.
<G-vec00127-002-s085><define.bestimmen><en> You use the optimization goal to define whether, during optimization, it is intended to schedule the production document on the requested (end) date or as early as possible.
<G-vec00127-002-s085><define.bestimmen><de> Bedeutung Mit dem Optimierungsziel bestimmen Sie, ob bei der Optimierung versucht wird, den Produktionsbeleg zum Wunschtermin (gewünschter Endtermin) oder frühestmöglich einzuplanen.
<G-vec00127-002-s086><define.bestimmen><en> Define feeding times and feed amounts in the Task Manager.
<G-vec00127-002-s086><define.bestimmen><de> Im Taskmanager bestimmen Sie Fütterungszeiten und -mengen.
<G-vec00127-002-s087><define.bestimmen><en> You use the enabled check box to define that the totals of the consolidation values of affiliated companies are determined and displayed in the total lines.
<G-vec00127-002-s087><define.bestimmen><de> Mit dem aktiven Kontrollkästchen bestimmen Sie, dass die Summen der Konsolidierungswerte von verbundenen Unternehmen ermittelt und die Summenzeilen angezeigt werden.
<G-vec00127-002-s088><define.bestimmen><en> You use the Totals check box to define whether total lines are also displayed.
<G-vec00127-002-s088><define.bestimmen><de> Mit dem Kontrollkästchen Summen bestimmen Sie, ob zusätzlich die Summenzeilen angezeigt werden.
<G-vec00127-002-s089><define.bestimmen><en> Define the selection criteria in the appropriate fields according to your requirements.
<G-vec00127-002-s089><define.bestimmen><de> Bestimmen Sie in den dafür vorgesehenen Feldern die Selektionskriterien nach Ihren Anforderungen.
<G-vec00127-002-s090><define.bestimmen><en> You use the check box to define whether intra-community business activities are tax-free or taxable.
<G-vec00127-002-s090><define.bestimmen><de> Mit dem Kontrollkästchen bestimmen Sie, ob innergemeinschaftliche Geschäftsvorgänge steuerfrei oder steuerpflichtig sind.
<G-vec00127-002-s091><define.bestimmen><en> You can use the "Post Completely" icon to define that proALPHA is to suggest the stock quantity of a document line available in the receiving storage area for transfer posting.
<G-vec00127-002-s091><define.bestimmen><de> Über das Schaltflächensymbol "Komplett umbuchen" bestimmen Sie, dass proALPHA die auf dem Wareneingangslager vorhandene Bestandsmenge einer Belegposition zum Umbuchen vorschlägt.
<G-vec00127-002-s092><define.bestimmen><en> You use the tax ID type to define in the tax rule whether and which tax identification numbers are determined during tax determination.
<G-vec00127-002-s092><define.bestimmen><de> Mit dem Steuernummerntyp bestimmen Sie in der Steuerregel, ob und welche Steuer-Identifikationsnummern bei der Steuerfindung ermittelt werden.
<G-vec00127-002-s093><define.bestimmen><en> Distance from top: Define the distance of Folder Menu from the top.
<G-vec00127-002-s093><define.bestimmen><de> Abstand von oben: Bestimmen Sie den Abstand des Folder-Menüs von oben.
<G-vec00127-002-s094><define.bestimmen><en> The operation category is used to define the way the operation of the operation line is performed.
<G-vec00127-002-s094><define.bestimmen><de> Mit der Aktivitätenart bestimmen Sie, wie die Arbeitsaktivität der Aktivitätenposition durchgeführt wird.
<G-vec00127-002-s170><define.definieren><en> Define the problem or question at hand.
<G-vec00127-002-s170><define.definieren><de> Definiere das Problem oder die Frage.
<G-vec00127-002-s171><define.definieren><en> Description Define your pout with Illamasqua's Slick Stick Lip Liner; a retractable, water-resistant lip pencil that can be used as an intense lip color, or to prevent feathering and bleeding.
<G-vec00127-002-s171><define.definieren><de> Beschreibung Definiere deinen Mund mit Illamasqua’s Slick Stick Lippenkonturenstift, einem herausdrehbaren, wasserresistenten Stift, der als intensive Lippenfarbe oder zur Vorbeugung von Verlaufen verwendet werden kann.
<G-vec00127-002-s172><define.definieren><en> Use the pointed tip of Goof Proof Brow Pencil to define the tail end of your brow.
<G-vec00127-002-s172><define.definieren><de> Definiere mit der Spitze des Goof Proof Stifts das äußere Ende deines Brauenbogens.
<G-vec00127-002-s173><define.definieren><en> Define the orgasm in one sentence.
<G-vec00127-002-s173><define.definieren><de> Definiere Orgasmus in einem Satz.
<G-vec00127-002-s174><define.definieren><en> I create an atmosphere of excitement and passion - that's how I define myself.
<G-vec00127-002-s174><define.definieren><de> Ich erschaffe eine Atmosphäre von Spannung und Leidenschaft - so definiere ich mich selbst.
<G-vec00127-002-s175><define.definieren><en> Define your own specific sustainability goals for your online business and communicate them clearly and unambiguously.
<G-vec00127-002-s175><define.definieren><de> Definiere konkrete Nachhaltigkeitsziele für dein Online-Business selbst und kommuniziere diese klar und unmissverständlich.
<G-vec00127-002-s176><define.definieren><en> Beauty Advent Calendar Define and enhance your eyes with Lancôme's Hypnôse Waterproof Custom Volume Mascara, a volumising, waterproof mascara that makes lashes look up to six times thicker with a perfectly separated finish.
<G-vec00127-002-s176><define.definieren><de> Definiere und verschönere deine Augen mit Lancôme’s Hypnôse Waterproof Custom Volume Mascara, einer volumenspendenden, wasserfesten Mascara, die deine Wimpern bis zu 65 Mal dicker erscheinen lässt und ihnen ein perfekt getrenntes Ergebnis schenkt.
<G-vec00127-002-s177><define.definieren><en> Define change management roles.
<G-vec00127-002-s177><define.definieren><de> Definiere Change-Management Rollen.
<G-vec00127-002-s178><define.definieren><en> Remove your trimmer’s comb attachment and trim your mustache to define the Pencil-thin mustache shape.
<G-vec00127-002-s178><define.definieren><de> Entferne den Kammaufsatz von deinem Trimmer und definiere die Form deines Schnurrbarts.
<G-vec00127-002-s179><define.definieren><en> As the system is more than just then machine learning and simulate human interaction, I define it as artificial intelligence.
<G-vec00127-002-s179><define.definieren><de> Da das System mehr ist als nur maschinelles Lernen und die Simulation menschlicher Interaktion, definiere ich es als künstliche Intelligenz.
<G-vec00127-002-s180><define.definieren><en> Define your round-sculpted features by framing your face with silky locks, curled to ethereal standards.
<G-vec00127-002-s180><define.definieren><de> Definiere Dein rund geformtes Gesicht, indem Du es mit seidigen Locken einrahmst.
<G-vec00127-002-s181><define.definieren><en> Therefore, define different workflow steps in which you use different intro messages.
<G-vec00127-002-s181><define.definieren><de> Definiere daher verschiedene Workflow Schritte, in denen Du unterschiedliche Intro Messages verwendest.
<G-vec00127-002-s182><define.definieren><en> Before you begin to implement your international SEO measures, you should first define your target group and goals, because every project requires its own way of proceeding.
<G-vec00127-002-s182><define.definieren><de> Bevor Du mit Deinen International SEO Maßnahmen beginnst, definiere zunächst Deine Zielgruppen und Ziele, denn jedes Projekt erfordert eine bestimmte Vorgehensweise.
<G-vec00127-002-s183><define.definieren><en> Define the two strings you want to compare.
<G-vec00127-002-s183><define.definieren><de> Definiere die beiden Strings, die du vergleichen willst.
<G-vec00127-002-s184><define.definieren><en> Or even define your very own rules for how you want the file names and paths to be determined based on the tags of the music tracks and movie files.
<G-vec00127-002-s184><define.definieren><de> Oder definiere sogar deine ganz eigenen Regeln, wie genau aus den Tags von Musikstücken, Filmdateien die Dateinamen und -Pfade bestimmt werden.
<G-vec00127-002-s185><define.definieren><en> Description Define your eyes from every angle with LOréal Paris Superliner Le Khol; a silky, long-wearing eyeliner that glides on effortlessly for professional results.
<G-vec00127-002-s185><define.definieren><de> Beschreibung Definiere deine Augen wie ein Profi mit dem LOréal Paris Superliner Le Smoky; ein Präzisions-Eyeliner mit hervorragender Deckkraft.
<G-vec00127-002-s186><define.definieren><en> Description Define your eyes from every angle with PIXI's Lash Line Ink Eyeliner in 'Velvet Cocoa'.
<G-vec00127-002-s186><define.definieren><de> Beschreibung Definiere deine Augen aus jedem Winkel während die Präzisionsspitze ein fehlerfreies Auftragen mit professionellem Ergebnis ermöglicht.
<G-vec00127-002-s187><define.definieren><en> Define, refine and outline your materials until you have sufficient evidence to write a conclusive report.
<G-vec00127-002-s187><define.definieren><de> Definiere, sortiere und bewerte deine Materialien bis du genügend Beweise hast, um einen schlüssigen Bericht zu schreiben.
<G-vec00127-002-s188><define.definieren><en> Define how objects interact with world architecture using a comprehensive inventory of brushes, including occluders, doors, triggers, area portals, soundscapes, and more.
<G-vec00127-002-s188><define.definieren><de> Definiere welche Objekte mit der Welt Architektur interagieren können, ein umfassendes Inventar aus Brushes, Türen, Triggers, Bereichs Portalen, Landschaften und vieles mehr stehen Dir dabei zur Verfügung.
<G-vec00127-002-s189><define.definieren><en> Downfire bass-reflex ports boost the deep bass, while elegant solid-metal feet define the floating nature of the sturdy MDF enclosure.
<G-vec00127-002-s189><define.definieren><de> Downfire Bassreflex-Öffnungen kräftigen den Tiefbass, schicke Vollmetall-Füße definieren den schwebenden Charakter des stabilen MDF-Gehäuses.
<G-vec00127-002-s190><define.definieren><en> Drawing Wizard to set up your drawing, define unit format, paper size, print, drawing scale annotation settings, text and dimension.
<G-vec00127-002-s190><define.definieren><de> Der Entwurfsassistent hilft in mehreren Schritten bei der Zeichnungseinrichtung, beim Definieren der Einheiten, Papiergröße, Annotationen, Text und Bema√üungen.
<G-vec00127-002-s191><define.definieren><en> A first mouse click allows to select the point where we want to position the camera and with a second click we will be able to define the direction of the scene setting (this function quickly allows to set the position and orientation of the scene setting point of view).
<G-vec00127-002-s191><define.definieren><de> Auswahl des Werkzeugs Kamera Mit einem ersten Mausklick wählen wir den Punkt aus, wo das Kameraobjektiv positioniert werden soll, mit einem zweiten Klick definieren wir die Richtung für den Bildausschnitt (Position und Orientierung der Szenen-Ansicht können schnell geändert werden).
<G-vec00127-002-s192><define.definieren><en> Our team is at your service to show you your future room, imagine its decoration and define your needs with you.
<G-vec00127-002-s192><define.definieren><de> Unser Team steht Ihnen zur Verfügung, um Ihnen Ihr zukünftiges Zimmer zu zeigen, sich seine Dekoration vorzustellen und mit Ihnen Ihre Bedürfnisse zu definieren.
<G-vec00127-002-s193><define.definieren><en> You work with the business to meet IT requirements and align projects and collaborate with other leaders to define the broader roadmap and strategy.
<G-vec00127-002-s193><define.definieren><de> Sie arbeiten mit dem Unternehmen zusammen, um die IT-Anforderungen zu erfüllen und Projekte abzustimmen, und arbeiten mit anderen Führungskräften zusammen, um eine breitere Roadmap und Strategie zu definieren.
<G-vec00127-002-s194><define.definieren><en> The function* keyword can be used to define a generator function inside an expression.
<G-vec00127-002-s194><define.definieren><de> Das function* Schlüsselwort kann benutzt werden, um Generatorfunktionen in einem Ausdruck zu definieren.
<G-vec00127-002-s195><define.definieren><en> The developer is able to define both the entire input and output for any given module.
<G-vec00127-002-s195><define.definieren><de> Der Admin kann für jedes Modul den Eingabe- und Ausgabe-Code definieren.
<G-vec00127-002-s196><define.definieren><en> Out of this situation, the idea was born, not to define user rights with fixed bit-fields, but with dynamical expressions.
<G-vec00127-002-s196><define.definieren><de> Daraus wurde die Idee geboren, die Berechtigungen nicht starr über Bit-Felder, sondern dynamisch über Gleichungen zu definieren.
<G-vec00127-002-s197><define.definieren><en> FAQ 001070 ZH Yes, RFEM allowsyou to define a surface as membrane.
<G-vec00127-002-s197><define.definieren><de> Es ist in RFEM möglich, eine Fläche als Membran zu definieren.
<G-vec00127-002-s198><define.definieren><en> We define the values and principles that play a central role in our business life.
<G-vec00127-002-s198><define.definieren><de> Wir definieren Werte und Prinzipien, die für unser Geschäftsleben gelten sollen.
<G-vec00127-002-s199><define.definieren><en> Once you accept that you are afraid, the next step is to define your fears.
<G-vec00127-002-s199><define.definieren><de> Wenn Sie akzeptieren, dass Sie Angst haben, ist der nächste Schritt, diese zu definieren.
<G-vec00127-002-s200><define.definieren><en> This allows us to define precisely which goods can be collected from which location and, of course, where the vehicle should deliver them to.
<G-vec00127-002-s200><define.definieren><de> So können wir genau definieren, welche Ware an welchem Ort abgeholt werden kann und natürlich wohin das Fahrzeug sie liefern soll.
<G-vec00127-002-s201><define.definieren><en> In the Table option, you can define the table visibility, the visibility of table elements (row sums, column sums) or the method of field aggregation.
<G-vec00127-002-s201><define.definieren><de> In der Option Tabelle können Sie die Tabellensichtbarkeit, die Sichtbarkeit von Tabellenelementen (Zeilensummen, Spaltensummen) oder die Methode der Feldaggregation definieren.
<G-vec00127-002-s202><define.definieren><en> We define the appropriate performance parameters and measure the achievement of goals.
<G-vec00127-002-s202><define.definieren><de> Wir definieren entsprechende Erfolgsgrößen und messen die Zielerreichung.
<G-vec00127-002-s203><define.definieren><en> And we define the instruments we will be using to measure it.
<G-vec00127-002-s203><define.definieren><de> Und wir definieren die Instrumente, mit denen wir messen.
<G-vec00127-002-s204><define.definieren><en> A number of attributes that define client-side scripting events are common to most elements.
<G-vec00127-002-s204><define.definieren><de> Eine Reihe von Attribute, die Client-seitige Scripting-Events definieren, sind in vielen Elementen gleich.
<G-vec00127-002-s205><define.definieren><en> Furthermore, the protocol allows you to edit texts (commands) and to define a number of properties... all this with the aim of maximising the adjustment to the application.
<G-vec00127-002-s205><define.definieren><de> Weiter ermöglicht das Protokoll Texte zu editieren (Anweisungen) und eine Reihe von Eigenschaften zu definieren … das alles mit dem Ziel der maximalen Anpassung der gegebenen Applikation.
<G-vec00127-002-s206><define.definieren><en> session.hash_bits_per_character allows you to define how many bits are stored in each character when converting the binary hash data to something readable.
<G-vec00127-002-s206><define.definieren><de> session.hash_bits_per_character integer session.hash_bits_per_character gibt Ihnen die Möglichkeit, zu definieren wieviele Bit bei der Umwandlung der binären Prüfsummen-Daten in etwas Lesbares in jedem Zeichen gespeichert werden.
<G-vec00127-002-s207><define.definieren><en> Decisive for 6G are the needs and application scenarios that industry and providers must define and create together with customers.
<G-vec00127-002-s207><define.definieren><de> Entscheidend für 6G sind jedoch die Bedürfnisse und Anwendungsszenarien, die Industrie und Anbieter zusammen mit den Kunden definieren und schaffen müssen.
<G-vec00127-002-s208><define.definieren><en> To go to layouts in an external file, define a script in that file using the Go to Layout script step, and call that script from the first file using the Perform Script script step.
<G-vec00127-002-s208><define.definieren><de> Um in Layouts in einer externen Datei zu wechseln, definieren Sie in der betreffenden Datei ein Script mit dem Scriptschritt „Gehe zu Layout“ und rufen dieses Script aus der ersten Datei mit dem Script ausführen Scriptschritt auf.
<G-vec00127-002-s209><define.definieren><en> For the given definition of the structural system, you must use the projection direction Z and define the target line by 2 points that describe the inclination of the chord.
<G-vec00127-002-s209><define.definieren><de> Nach Ihrer Systembeschreibung müssen Sie als Projektionsrichtung Z verwenden und die Ziellinie definieren Sie durch 2 Punkte, die die Neigung des Gurtes beschreiben.
<G-vec00127-002-s210><define.definieren><en> Define indicators to represent their economic, environmental, and social performance and thus fulfill important information requirements for your stakeholders.
<G-vec00127-002-s210><define.definieren><de> Definieren Sie Indikatoren zur Darstellung ihrer wirtschaftlichen, ökologischen und sozialen Leistungen und erfüllen Sie damit wichtige Informationsanforderungen Ihrer Stakeholder.
<G-vec00127-002-s211><define.definieren><en> Given a particular Relationships Graph and scenario, define a result.
<G-vec00127-002-s211><define.definieren><de> Definieren Sie ein Ergebnis anhand eines bestimmten Beziehungsdiagramms und Szenarios.
<G-vec00127-002-s212><define.definieren><en> Define the relevant target groups and deliver to them online – with extreme ease.
<G-vec00127-002-s212><define.definieren><de> Definieren Sie die relevanten Zielgruppen und beliefern Sie sie online – im Handumdrehen.
<G-vec00127-002-s213><define.definieren><en> Define the width and height of the slideshow.
<G-vec00127-002-s213><define.definieren><de> Definieren Sie die Breite und Höhe der Slideshow.
<G-vec00127-002-s214><define.definieren><en> Eventually, define additional protection, which can change the calculation for the occupants as well as for the building.
<G-vec00127-002-s214><define.definieren><de> Eventuell definieren Sie zusätzlichen Schutz, der die Berechnung für die Inhaber sowie für das Gebäude ändern kann.
<G-vec00127-002-s215><define.definieren><en> These templates help students not only define the event and the consequences, but outline the logical reasons for why the consequences occur.
<G-vec00127-002-s215><define.definieren><de> Diese Vorlagen helfen den Schülern nicht nur, das Ereignis und die Konsequenzen zu definieren, sondern sie beschreiben auch die logischen Gründe, warum die Konsequenzen auftreten.
<G-vec00127-002-s216><define.definieren><en> Define the maximum width of the carousel display.
<G-vec00127-002-s216><define.definieren><de> Definieren Sie die maximale Breite der Karussellanzeige.
<G-vec00127-002-s217><define.definieren><en> Define an area in your shop, add the Roomle code (API) and enable 3D product customization, visualization and ordering immediately.
<G-vec00127-002-s217><define.definieren><de> Definieren Sie einen Bereich in Ihrem Shop, laden Sie das Roomle-Programm (API) und beginnen Sie auf der Stelle mit 3D-Produktindividualisierung, Visualisierung und automatisiertem Bestellwesen.
<G-vec00127-002-s218><define.definieren><en> Define a suitable offset value and use the new 3D Curve as a reference for other features.
<G-vec00127-002-s218><define.definieren><de> Definieren Sie einen geeigneten Offsetwert und verwenden Sie die neue 3D Curve als Referenz für andere Features.
<G-vec00127-002-s219><define.definieren><en> The next step is to define the use of your product.
<G-vec00127-002-s219><define.definieren><de> Im nächsten Schritt definieren Sie den Nutzen Ihres Produkts.
<G-vec00127-002-s220><define.definieren><en> News PRODUCTION We produce windings according to your specifications - specify each operation and the material or define only the final properties of the desired product.
<G-vec00127-002-s220><define.definieren><de> News PRODUKTION Wir produzieren Wickelgüter nach Ihren Vorgaben – spezifizieren Sie jeden Arbeitsgang und das Material, oder definieren Sie lediglich die endgültigen Eigenschaften des gewünschten Produktes.
<G-vec00127-002-s221><define.definieren><en> After you apply this hotfix, define a memory limit for the ESE database cache of DFS Replication.
<G-vec00127-002-s221><define.definieren><de> Nachdem Sie diesen Hotfix angewendet haben, definieren Sie ein Speicherlimit für den ESE-Datenbank-Zwischenspeicher der DFS-Replikation.
<G-vec00127-002-s222><define.definieren><en> Short-cut repetitive tasks Define simple voice commands to short-cut repetitive processes, speed up document creation and boost your productivity.
<G-vec00127-002-s222><define.definieren><de> Definieren Sie einfache Sprachbefehle, mit denen Sie Routineaufgaben in einem Schritt zusammenfassen, die Erstellung von Dokumenten beschleunigen und Ihre Produktivität steigern.
<G-vec00127-002-s223><define.definieren><en> Define clear tracking goals and evaluate what makes more sense to measure: Impressions, clicks, shares, comments, repeat visits, etc.
<G-vec00127-002-s223><define.definieren><de> Definieren Sie eindeutige Tracking-Ziele und bewerten Sie, was zum Messen sinnvoller ist: Impressionen, Klicks, Freigaben, Kommentare, wiederholte Besuche usw.
<G-vec00127-002-s224><define.definieren><en> Now open the view product types in the view group Administration and define a new product type Ticket list for your Excel file.
<G-vec00127-002-s224><define.definieren><de> Öffnen Sie nun bitte die Sicht Produkttypen in der Sichtengruppe Administration und definieren Sie einen neuen Produkttyp Ticketliste für Ihre Excel-Datei.
<G-vec00127-002-s225><define.definieren><en> Define target groups based on numerous variables, such aslocation, device information, historic user behavior, purchase history, referrer, and keep your visitors engaged.
<G-vec00127-002-s225><define.definieren><de> Definieren Sie Zielgruppen anhand zahlreicher Variablen, wie zum Beispiel Location, Geräteinformationen, bisheriges Nutzerverhalten, Kaufhistorie, oder Referrer, und steigern Sie so Ihre Kundenbindung.
<G-vec00127-002-s226><define.definieren><en> Define a strategy that balances complexity and cost.
<G-vec00127-002-s226><define.definieren><de> Definieren Sie eine Strategie, die Komplexität und Kosten in Einklang bringt.
<G-vec00127-002-s227><define.definieren><en> Parameter -HINT can define an additional description that appears if you hover over the text with the mouse cursor.
<G-vec00127-002-s227><define.definieren><de> Der optionale Parameter -HINT definiert einen Informationstext, der beim Überstreichen des Eingabefelds mit der Maus angezeigt wird.
<G-vec00127-002-s228><define.definieren><en> With command you define the tool that is used to write the data.
<G-vec00127-002-s228><define.definieren><de> Mittels <command> wird das Tool definiert, das zum schreiben der Daten verwendet wird.
<G-vec00127-002-s229><define.definieren><en> One thing that occurs to me as I look at this little modification of the Tree of Life is that it sure seems to model and define in pretty simple and precise terms the relationships we are coming to understand about our reality, as well as the potentials for moving from one point on the Tree to another.
<G-vec00127-002-s229><define.definieren><de> Als ich diese kleine Modifikation des Lebensbaums vornahm, stach mir etwas besonders ins Auge; es ist zwar sicherlich noch ein Modell, aber es definiert in einigermaßen einfachen und genauen Begriffen die Beziehungen, die wir über unsere Realität zu verstehen haben, genauso wie das POTENTIAL, sich von einem Punkt des Baums zu einem anderen zu bewegen.
<G-vec00127-002-s230><define.definieren><en> It is designed to further define the Edna-West vein and will ultimately aid in the placement of an exploration adit.
<G-vec00127-002-s230><define.definieren><de> Mit diesem Programm soll der Edna-West-Gang weiter definiert und ein geeigneter Standort für einen Explorationsstollen ermittelt werden.
<G-vec00127-002-s231><define.definieren><en> This work package will define and implement interfaces which permit a directly quantified interaction between simulation and available load and generator profiles for buildings.
<G-vec00127-002-s231><define.definieren><de> In diesem Arbeitspaket werden Schnittstellen definiert und implementiert, die eine direkte quantifizierte Wechselwirkung zwischen Simulation und verfügbaren Last- und Erzeugerprofile für Gebäude ermöglichen.
<G-vec00127-002-s232><define.definieren><en> All these studies and observations have allowed to clearly define what is currently understood by Mediterranean Diet: a diet rich in foods of plant origin (cereal products, fruit and vegetables, legumes and nuts), low in saturated fat type, with a preponderance of monounsaturated fatty acids, mainly thanks to olive oil, significant amounts of omega-3 fatty acids, low cholesterol intake, plenty of antioxidant vitamins, pro-vitamins and phenolic compounds and adequate amounts of fiber.
<G-vec00127-002-s232><define.definieren><de> All diese Studien und Beobachtungen haben klar definiert, was sich unter Mittelmeer-Diät versteht: eine Diät reich an Lebensmitteln aus pflanzlichen Ursprungs (Getreide und Getreideerzeugnisse, Obst und Gemüse, Hülsenfrüchte und Nüsse), arm an gesättigten Fettsäuren Art, mit Fettsäuren, vor allem dank Olivenöl, erhebliche Mengen von Omega-3-Fettsäuren, geringe Cholesterin-Aufnahme, viele antioxidative Vitamine, Pro-Vitaminen und phenolischen Verbindungen und ausreichende Mengen von Faser.
<G-vec00127-002-s233><define.definieren><en> In addition, you can define in the wizard step System Assignment on which devices the software should be installed.
<G-vec00127-002-s233><define.definieren><de> Außerdem kann im Assistentschritt Gerätezuordnung definiert werden auf welchen Geräte die Software installiert sein soll.
<G-vec00127-002-s234><define.definieren><en> Remarks: Deletes the IP address and mask pair that define a range of addresses belonging to this area.
<G-vec00127-002-s234><define.definieren><de> Beschreibung: Löscht das IP-Adress- und -Maskenpaar, das einen zu diesem Bereich gehörigen Adressbereich definiert.
<G-vec00127-002-s235><define.definieren><en> Within the course of the UX design process, we will first define the interface’s cornerstones within the scope of the conceptual UI design and then graphically complete them by means of a consistent visual design and meaningful icons.
<G-vec00127-002-s235><define.definieren><de> Design — Kreative Lösungen Während des Design-Prozesses werden zunächst im Rahmen des konzeptionellen Designs die Eckpfeiler des UI Design definiert und anschließend grafisch durch ein stimmiges visuelles Design sowie aussagekräftige Icons abgerundet.
<G-vec00127-002-s236><define.definieren><en> Our expert engineering team will define the optimal system specifications for your refrigeration, AC, or heating system to improve quality, efficiency, and reliability.
<G-vec00127-002-s236><define.definieren><de> Unser Expertenteam aus Technikern definiert die optimalen Systemspezifikationen für Kältemittel, Klimatisierung oder Heizung, um die Qualität, Effizienz und Zuverlässigkeit zu verbessern.
<G-vec00127-002-s237><define.definieren><en> They will also focus on defining the economic viability of the project and will take advantage of the existing underground infrastructure and define the near surface potential of the deposits.
<G-vec00127-002-s237><define.definieren><de> Ebenso wird die wirtschaftliche Machbarkeit des Projekts unter Einbeziehung der vorhandenen unterirdischen Infrastruktur bewertet und das oberflächennahe Potenzial der Lagerstätten definiert.
<G-vec00127-002-s238><define.definieren><en> The Guide does not define a micro entity in quantitative terms.
<G-vec00127-002-s238><define.definieren><de> Im Leitfaden wird ein Kleinstunternehmen nicht entlang bestimmter Größenmerkmale definiert.
<G-vec00127-002-s239><define.definieren><en> Simply put: If you do not define the system context thorougly the requirements will remain fragmentary, resulting in many, often costly problems.
<G-vec00127-002-s239><define.definieren><de> Anders herum: Wird der Systemkontext nicht vollständig definiert, werden auch die Anforderungen unvollständig bleiben, die in die Entwicklung eingehen.
<G-vec00127-002-s240><define.definieren><en> “Lawyers define the term ‘error’ differently from computer scientists,” says Krupka.
<G-vec00127-002-s240><define.definieren><de> “Der Jurist definiert den Begriff “Fehler” anders als der Informatiker”, so Krupka.
<G-vec00127-002-s241><define.definieren><en> The locale options in the select box are define via element variables.
<G-vec00127-002-s241><define.definieren><de> Die Locale-Optionen in der Auswahlbox werden über Elementvariablen definiert.
<G-vec00127-002-s242><define.definieren><en> The trainer will define a training program within the simulator, with customised exercises according to the operators' current level and learning objectives.
<G-vec00127-002-s242><define.definieren><de> Der Ausbilder definiert ein Trainingsprogramm im Simulator mit spezifischen Übungen entsprechend dem laufenden Ausbildungsstand und Lernzielen der Bediener.
<G-vec00127-002-s243><define.definieren><en> This shows objects, relationships, and inheritance structures, and define class attributes and methods.
<G-vec00127-002-s243><define.definieren><de> Dies zeigt Objekte, Beziehungen und Vererbungsstrukturen und definiert Klassenattribute und -methoden.
<G-vec00127-002-s244><define.definieren><en> Elsa Huen, Quality Manager at Deutsche See GmbH, argued that processors need to define clear requirements for raw materials, which the raw material supplier has to meet within a defined quality window.
<G-vec00127-002-s244><define.definieren><de> Seitens der Verarbeiter müssen klare Anforderungen an die Rohstoffe definiert werden, die dann innerhalb eines ebenfalls definierten Qualitätsfensters von den Rohstofflieferanten einzuhalten sind, erklärte Elsa Huen, Qualitätsmanagement der Deutschen See GmbH.
<G-vec00127-002-s245><define.definieren><en> Understand how to recognize and define a particular style, analyzing all the elements that compose it.
<G-vec00127-002-s245><define.definieren><de> > Lernen Sie, wie man einen bestimmten Stil erkennt und definiert, indem man die Elemente, aus denen er besteht, analysiert.
<G-vec00127-002-s246><define.definieren><en> Version: from version 5.20 With this expert attribute, you can define the skin of the TinyMCE Editor.
<G-vec00127-002-s246><define.definieren><de> Version: ab Version 5.20 Mit diesem Expert-Attribut kann die TinyMCE-Skin definiert werden.
<G-vec00127-002-s247><define.definieren><en> It will allow to precisely define the requirements and the direction of research and development works.
<G-vec00127-002-s247><define.definieren><de> Damit können die Anforderungen und die Richtung der Forschungs- und Entwicklungsarbeiten genau definiert werden.
<G-vec00127-002-s248><define.definieren><en> You can also define additional lateral restraints in order to represent the model close to reality.
<G-vec00127-002-s248><define.definieren><de> Es können auch zusätzliche seitliche Halterungen definiert werden, um das Modell realitätsnah abzubilden.
<G-vec00127-002-s249><define.definieren><en> You can define widgets within the Dashboard itself. Widgets can also provide snapshots of and link to standard or custom reports.
<G-vec00127-002-s249><define.definieren><de> Widgets können innerhalb des Dashboards selbst definiert werden, eine Übersicht über Standard- oder benutzerdefinierte Berichte bieten und mit diesen verknüpft sein.
<G-vec00127-002-s250><define.definieren><en> The Pestalozzi Children’s Foundation was actively supported in this by a consultant from Skat Consulting, St. Gallen, which enabled us to define further steps.
<G-vec00127-002-s250><define.definieren><de> Dabei wurde die Stiftung Kinderdorf Pestalozzi tatkräftig von einem Konsulent der Firma Skat Consulting aus St. Gallen, unterstützt und es konnten weitere Schritte definiert werden.
<G-vec00127-002-s251><define.definieren><en> With GenICam as the generic programming interface in the field of machine vision, it was possible to define an implementation rule that completely abstracts and separates each property of a machine vision camera.
<G-vec00127-002-s251><define.definieren><de> Mit GenICam als einheitliche Programmierschnittstelle im Machine Vision Bereich konnte eine Implementierungs-vorschrift definiert werden, die jede Eigenschaft einer Machine Vision Kamera komplett abstrahiert und vereinzelt.
<G-vec00127-002-s252><define.definieren><en> In this mode it is possible to define the analog level of a full scale digital signal (0dBfs = 0dB full scale).
<G-vec00127-002-s252><define.definieren><de> In diesem Modus kann definiert werden, welchen analogen Pegel ein vollausgesteuertes Digitalsignal (0dBfs = 0dB full scale) haben soll.
<G-vec00127-002-s253><define.definieren><en> It is possible to define an own test sequence for each group.
<G-vec00127-002-s253><define.definieren><de> Für jede Gruppe kann ein eigener Prüfablauf definiert werden.
<G-vec00127-002-s254><define.definieren><en> The area must be analysed in more detail in order to define long-term goals and indicators.
<G-vec00127-002-s254><define.definieren><de> Ziel: Der Bereich muss detailliert analysiert werden, bevor langfristige Ziele und Schlüsselzahlen definiert werden.
<G-vec00127-002-s255><define.definieren><en> Product flyer This module allows to define the criteria of certain product groups and individual recipes that have to be complied with.
<G-vec00127-002-s255><define.definieren><de> Produktflyer Mit diesem Modul können Kriterien definiert werden, die von bestimmten Produktgruppen oder einzelnen Rezepturen einzuhalten sind.
<G-vec00127-002-s256><define.definieren><en> For example, each entirety parameter corresponding to a subset of predefined available watermarks, it is possible to define a set of entirety parameters.
<G-vec00127-002-s256><define.definieren><de> Zum Beispiel kann ein Satz Gesamtheitsparameter definiert werden, wobei jeder Gesamtheitsparameter einem vordefinierten Teilsatz der verfügbaren Wasserzeichen entspricht.
<G-vec00127-002-s257><define.definieren><en> Exactly that is what the ActiveX control UserTable features: beside normal settings like column width and row height, you can define e. g. font type/color as well as background color not only for single cells, but also overall cells for complete columns, rows or even for the whole table.
<G-vec00127-002-s257><define.definieren><de> Genau das bietet Ihnen das ActiveX-Steuerelement UserTable: Neben Standardeinstellungen wie Spaltenbreite und Zeilenhöhe, können beispielsweise Schrifttyp/-farbe sowie Hintergrundfarbe nicht nur für einzelne Zellen, sondern auch zellenübergreifend für ganze Spalten, Zeilen oder sogar die ganze Tabelle definiert werden.
<G-vec00127-002-s258><define.definieren><en> StreamInsight applications create structures that define the events, adapters, and queries used in the application.
<G-vec00127-002-s258><define.definieren><de> Mit StreamInsight-Anwendungen werden Strukturen erstellt, mit denen die in der Anwendung verwendeten Ereignisse, Adapter und Abfragen definiert werden.
<G-vec00127-002-s259><define.definieren><en> In summary, we have learned about how to use numbers to define colors and the reason behind it.
<G-vec00127-002-s259><define.definieren><de> Wir haben also gelernt, wie und wieso Farben mithilfe von Zahlen definiert werden.
<G-vec00127-002-s260><define.definieren><en> Performance is a form of artistic act that grew out of action art in the early 60s, yet because of its open structure it is hard to define comprehensively.
<G-vec00127-002-s260><define.definieren><de> Die Performance ist als eine Form der künstlerischen Darbietung Anfang der 1960er Jahre aus den Aktionskünsten heraus entstanden und kann aufgrund der offene Struktur schwer übergreifend definiert werden.
<G-vec00127-002-s261><define.definieren><en> For the contact, you can define nonlinear properties set perpendicular or parallel to the plate plane.
<G-vec00127-002-s261><define.definieren><de> Für den Kontakt können nichtlineare Eigenschaften senkrecht und parallel zur Plattenebene definiert werden.
<G-vec00127-002-s262><define.definieren><en> Semantic Relationships are a two-way street: We have to define semantics first in order for Picturepark to provide semantics to us via search results, cross-links and information display.
<G-vec00127-002-s262><define.definieren><de> Semantische Beziehungen funktionieren in beiden Richtungen: Zuerst muss die Semantik definiert werden, damit Picturepark diese Zusammenhänge bei den Suchergebnissen, Querverbindungen und der Informationsdarstellung berücksichtigen kann.
<G-vec00127-002-s263><define.definieren><en> If it is desirable to define the Lowest explosion limit, it is desirable to define the Upper explosion limit and the Explosion range as well.
<G-vec00127-002-s263><define.definieren><de> Sollte die Untere Explosionsgrenze definiert werden, so sollte ebenso die Obere Explosionsgrenze sowie der Explosionsbereich definiert werden.
<G-vec00127-002-s264><define.definieren><en> In the document properties of the PDF you can define whether the document is displayed with the file name or the document title.
<G-vec00127-002-s264><define.definieren><de> In den PDF-Dokumenteigenschaften kann definiert werden ob das Dokument mit dem Dateinamen oder dem Dokumenttitel angezeigt wird.
<G-vec00127-002-s556><define.definieren><en> Step 4: Choose or define output format.
<G-vec00127-002-s556><define.definieren><de> Schritt 4: Ausgabeformat wählen oder selbst definieren.
<G-vec00127-002-s557><define.definieren><en> Set in the streets of Baltimore, Philadelphia and Washington, D.C., the title empowers players with the freedom to define their character, story and style based on the choices they make, the paths they select and the style of skating they want.
<G-vec00127-002-s557><define.definieren><de> In den Straßen von Baltimore, Philadelphia und Washington D.C. haben die Spieler die Freiheit, ihren Charakter, die Story, ihre Fähigkeiten und ihren Stil anhand ihrer Entscheidungen, der von ihnen gewählten Wege und dem von ihnen gewollten Skatestil selbst zu definieren.
<G-vec00127-002-s558><define.definieren><en> We are usually not aware of the fact that, as a consequence of the use of these systems, the borders of privateness, towards what we define as "off limits" are eroding.
<G-vec00127-002-s558><define.definieren><de> Zumeist ist uns nicht bewusst, dass mit der Benützung dieser Systeme auch ein Erodieren der Grenze zum Privaten, zu dem, was wir für uns selbst als "off-limits" definieren, einhergeht.
<G-vec00127-002-s559><define.definieren><en> recognize and define relationships between business processes of a company and their support by information systems.
<G-vec00127-002-s559><define.definieren><de> Zusammenhänge zwischen Geschäftsprozessen eines Unternehmens und deren Unterstützung durch Informationssysteme selbst zu erkennen und zu definieren.
<G-vec00127-002-s560><define.definieren><en> I think you answered the question already – on this album we were able to really define what this version of SLS sounds like, and write the best songs we could.
<G-vec00127-002-s560><define.definieren><de> Ich glaube du hast die Frage bereits selbst beantwortet – auf diesem Album konnten wir definieren wie sich SLS anhört und haben so unsere bestmöglichsten Songs geschrieben.
<G-vec00127-002-s561><define.definieren><en> For this reason, if you need to use escapes, it may be safer to use numeric character references, or define the character entities you need inside the document.
<G-vec00127-002-s561><define.definieren><de> Wenn wirklich Escapes benötigt werden, ist es deshalb sicherer, nummerische Referenzen zu verwenden oder die benötigten Entities im Dokument selbst zu definieren.
<G-vec00127-002-s562><define.definieren><en> MODUS Patch - until now, users had to define their own paths for surface sweeps and 2D curves using manual manipulation tools to avoid collisions.
<G-vec00127-002-s562><define.definieren><de> MODUS Patch – Bis jetzt mussten Anwender die Pfade für Oberflächenscans und 2D-Kurven selbst definieren und manuelle Bearbeitungsfunktionen zum Schutz vor Kollisionen verwenden.
<G-vec00127-002-s563><define.definieren><en> They define it as a mixture of Death and Dark Metal, and I donīt have much to add to that.
<G-vec00127-002-s563><define.definieren><de> Sie selbst definieren es als eine Mischung aus Death und Dark Metal, und ich kann mich da wohl nur anschließen.
<G-vec00127-002-s564><define.definieren><en> We demand a political solution through the dialogue between the Venezuelan people and their legitimate political institutions, without interference, without sanctions and without media manipulation, in order to make the right of self-determination of the peoples, to define the strategies of their economic and social recovery under the condition of the welfare of the social collective.
<G-vec00127-002-s564><define.definieren><de> Wir sprechen uns aus für eine politische Lösung durch den Dialog zwischen dem venezolanischen Volk und seinen legitimen politischen Institutionen, ohne Eingriffe, weder durch Sanktionen noch durch mediale Manipulation, um das Recht der Völker zu respektieren, selbstbestimmt und unter der Voraussetzung des Wohls des sozialen Kollektivs, selbst die Strategien der wirtschaftlichen und sozialen Erholung zu definieren.
<G-vec00127-002-s565><define.definieren><en> She was the one to defend the autonomy of the Russian proletariat against the planned strategy of the German social democrats, proving those in the periphery the right to define their means of struggle against the leaders at its core.
<G-vec00127-002-s565><define.definieren><de> Sie war diejenige, die die Autonomie des russischen Proletariats gegen die geplante Strategie der deutschen Sozialdemokraten verteidigte, womit sie denjenigen an der Peripherie der Bewegung das Recht gab, die Mittel ihres Kampfes selbst zu definieren, entgegen den Führern, die im Zentrum standen.
<G-vec00127-002-s566><define.definieren><en> Generate thousands of personalized documents in batches, triggered by business rules that you define.
<G-vec00127-002-s566><define.definieren><de> Generieren Sie tausende personalisierter Dokumente basierend auf Verfahrensregeln, die Sie selbst definieren.
<G-vec00127-002-s567><define.definieren><en> A further benefit is that you can define the frequency of the scans (weekly, monthly) and tailor them optimally to your specific needs.
<G-vec00127-002-s567><define.definieren><de> Ein weiterer Nutzen ist, dass Sie die Frequenz der Scans (wöchentlich, monatlich) selbst definieren und optimal auf Ihre Bedürfnisse abstimmen können.
<G-vec00127-002-s568><define.definieren><en> By using these rules it is possible to define own tournament systems.
<G-vec00127-002-s568><define.definieren><de> Mit diesen Regeln ist es nun möglich eigene Turniersysteme selbst zu definieren.
<G-vec00127-002-s569><define.definieren><en> You can define the information that you would like to change, the kinds of relationships that should exist between various artefacts as well as the number of figures you require for your evaluations.
<G-vec00127-002-s569><define.definieren><de> Welche Informationen Sie zu Änderungen und Change Requests verwalten wollen, welche Beziehungen zu anderen Artefakten bestehen sollen, welche Kennzahlen Sie für Ihre Auswertungen benötigen, können Sie natürlich selbst definieren.
<G-vec00127-002-s608><define.definieren><en> Open the text file to define the policies.
<G-vec00127-002-s608><define.definieren><de> Öffnen Sie die Textdatei, um die Ausnahmeregelungen zu definieren.
<G-vec00127-002-s609><define.definieren><en> Use desktop tools, such as Azure Media Explorer and our advanced graphical Workflow Designer, to define an encoding workflow that meets your business needs and then execute it at scale.
<G-vec00127-002-s609><define.definieren><de> Mithilfe von Desktoptools wie Azure Media Explorer und unserem erweiterten grafischen Workflow-Designer können Sie einen Codierungsworkflow für Ihre Geschäftsanforderungen definieren und basierend auf diesen Anforderungen ausführen.
<G-vec00127-002-s610><define.definieren><en> To define a phone usage record, use the Phone Usages tab of Voice Properties.
<G-vec00127-002-s610><define.definieren><de> Telefonverwendungsdatensätze können Sie in Eigenschaften von VoIP auf der Registerkarte Telefonverwendungen definieren.
<G-vec00127-002-s611><define.definieren><en> cultivator share The steels used for the production of our products are all certified and first choice, meeting the standards (UNI EN 10086-3/DIN EN 10089) that define them.
<G-vec00127-002-s611><define.definieren><de> Die Stähle, die wir für die Herstellung unserer Produkte einsetzen, sind alle zertifiziert und erste Wahl, sie entsprechen den Normen (UNI EN 10086-3/DIN EN 10089), die sie definieren.
<G-vec00127-002-s612><define.definieren><en> Define yourself the nature of the consultant you require and draw up a coaching contract with the respective coach correspondingly.
<G-vec00127-002-s612><define.definieren><de> Sie definieren den Beratungsbedarf und schließen mit dem Coach einen Vertrag auf Basis unserer gründerfreundlichen Rahmenbedingungen.
<G-vec00127-002-s613><define.definieren><en> In the following 2 chapters with 4 Gambas projects you will learn how to define D-Bus objects for a data server, export them to the D-Bus and how you can use the services offered with a d-bus-capable client.
<G-vec00127-002-s613><define.definieren><de> In den folgenden 2 Kapiteln mit 4 Gambas-Projekten erfahren Sie, wie Sie für einen Daten-Server D-Bus-Objekte definieren, zum D-Bus exportieren und wie Sie mit einem d-bus-fähigen Client die angebotenen Dienste nutzen können.
<G-vec00127-002-s614><define.definieren><en> Create your own wipe algorithm with minimal effort – define up to 4 wiping patterns, number of passes for each wiping pattern and for the group of patterns, thus resulting in over 40000 possible number of passes.
<G-vec00127-002-s614><define.definieren><de> Eigene Löschmethoden Sie können ganz einfach einen eigenen Löschalgorithmus erstellen, indem Sie bis zu vier Löschmuster definieren, die Anzahl der Löschdurchgänge pro Löschmuster und für die gesamte Mustergruppe.
<G-vec00127-002-s615><define.definieren><en> After that, you must define an optimal strategy by narrowing the tag.
<G-vec00127-002-s615><define.definieren><de> Danach müssen Sie eine optimale Strategie definieren, indem Sie das Tag einschränken.
<G-vec00127-002-s616><define.definieren><en> For a detailed explanation of how to define stored procedures for deletes, see Scripted upload example.
<G-vec00127-002-s616><define.definieren><de> Eine ausführliche Erläuterung, wie Sie gespeicherte Prozeduren für Löschungen definieren, finden Sie unter Beispiel für einen skriptgesteuerten Upload.
<G-vec00127-002-s617><define.definieren><en> Launch the "Define list footer" command, and then select the corresponding lines and text.
<G-vec00127-002-s617><define.definieren><de> Starten Sie den Befehl "Fuß der Materialliste definieren" und wählen die entsprechenden Linien und Texte aus.
<G-vec00127-002-s618><define.definieren><en> Based on your trading strategy, you can define entire setups with the Setup Escort and activate them with our groundbreaking AT++.
<G-vec00127-002-s618><define.definieren><de> Mit dem SetupEscort können Sie – basierend auf Ihrer Trading-Strategie – komplette Setups definieren und diese mit dem einzigartigen AT++ aktivieren und das Risiko- und Geldmanagement macht es Ihnen wesentlich leichter, Ihr persönliches Regelwerk einzuhalten.
<G-vec00127-002-s619><define.definieren><en> Using the latest analytics platforms and global benchmarking tools, including our Work Dynamics Scan©, we work with, and guide your users and experts to define the functional requirements in the three areas of behavioural, physical and technological, that will ensure you achieve your vision.
<G-vec00127-002-s619><define.definieren><de> Unter Verwendung der neuesten Analyseplattformen und globalen Benchmarking-Tools, einschließlich unseres Work Dynamics Scan©, arbeiten wir mit Ihren Teams und Experten zusammen und leiten sie an, um die funktionalen Anforderungen in den drei Bereichen Verhalten, physikalische Arbeitsumgebung und Digitalisierung zu definieren, die sicherstellen, dass Sie Ihre Vision erreichen.
<G-vec00127-002-s620><define.definieren><en> Work with your account manager to define the attribution model that perfectly matches your goals.
<G-vec00127-002-s620><define.definieren><de> Kontaktieren Sie Ihren Account Manager, um das für Sie passende Attribution Modell zu definieren.
<G-vec00127-002-s621><define.definieren><en> Use Location and Size dimension tools to define hole sizes and assembly feature dimensions and tolerances.
<G-vec00127-002-s621><define.definieren><de> Verwenden Sie Werkzeuge zur Positions- und Größenbemaßung, um Bohrungsgrößen und Baugruppen-Feature-Bemaßungen sowie -Toleranzen zu definieren.
<G-vec00127-002-s622><define.definieren><en> Use FTP Denied URL Sequences to define the list of URL sequences for which the FTP service will deny access.
<G-vec00127-002-s622><define.definieren><de> Mithilfe der FTP-Option Abgelehnte URL-Sequenzen können Sie die Liste der URL-Sequenzen definieren, für die der FTP-Dienst den Zugriff ablehnt.
<G-vec00127-002-s623><define.definieren><en> The best way to organize your target groups is to define exactly one Google Analytics query per group, see step 1.
<G-vec00127-002-s623><define.definieren><de> Am besten organisieren Sie Ihre Zielgruppen so, dass sie pro Gruppe genau eine Google Analytics Query definieren, siehe Schritt 1.
<G-vec00127-002-s624><define.definieren><en> Use custom number fields to define any numeric set of data or to perform a custom calculation by using a custom formula.
<G-vec00127-002-s624><define.definieren><de> Mit benutzerdefinierten Zahl-Feldern können Sie jeden numerischen Satz von Daten definieren oder eine benutzerdefinierte Berechnung durch Verwenden einer benutzerdefinierten Formel ausführen.
<G-vec00127-002-s625><define.definieren><en> I think those people came 'close' to death 'dreamed' and/or 'envisioned' about such events but, I don't believe they were actually on the other side of life or, like myself, they would never say such things nor define it using religious terms.
<G-vec00127-002-s625><define.definieren><de> Ich denke jene Leute kamen dem Tod 'nahe', 'träumten' und/oder 'stellten sich' solche Ereignisse vor, aber ich glaube nicht dass sie tatsächlich auf der anderen Seite des Lebens waren, sonst würden sie wie ich nie solche Dinge sagen, noch sie definieren mit der Benutzung von religiösen Begriffen.
<G-vec00127-002-s626><define.definieren><en> Your site can define up to a total of 10 meeting types, according to your needs.
<G-vec00127-002-s626><define.definieren><de> Sie koennen für ihren Standort bis zu 10 Besprechungsarten nach ihren eigenen Beduerfnissen definieren.
<G-vec00127-002-s265><define.definierten><en> If a certain trigger event happens, IFTTT will automatically react in a way that you can define.
<G-vec00127-002-s265><define.definierten><de> Wenn ein bestimmtes auslösendes Ereignis auftritt, reagiert IFTTT automatisch in der von Dir definierten Art und Weise.
<G-vec00127-002-s266><define.definierten><en> Values that used to define Europe as a community of social welfare states are slowly becoming obsolete.
<G-vec00127-002-s266><define.definierten><de> Jene Werte, die Europa einst als Sozialstaat definierten, rücken in die Vergangenheit.
<G-vec00127-002-s267><define.definierten><en> With our Investment Advisory, we actively support you in investing your assets, based on the investment strategy we define together.
<G-vec00127-002-s267><define.definierten><de> Im Rahmen der Anlageberatung unterstützen wir Sie aktiv beim Anlegen Ihres Vermögens basierend auf der gemeinsam definierten Anlagestrategie.
<G-vec00127-002-s268><define.definierten><en> People without the above-mentioned characteristics but are doing some good deeds like donating to orphanages, etc., though their acts are meritorious, do not necessarily qualify for what Spiritual science would define as ‘good’ people, especially if the act is done with pride.
<G-vec00127-002-s268><define.definierten><de> Menschen ohne diese Eigenschaften, die jedoch gute Taten vollbringen, wie an Waisenhäuser spenden usw., sammeln zwar viele Verdienste, bilden aber nicht notwendigerweise die von der spirituellen Wissenschaft definierten „guten Menschen“, besonders wenn ihre Taten sie stolz machen.
<G-vec00127-002-s269><define.definierten><en> And the cherry on top of the cake: in the long run each term you define will save you money, as you only pay once for each word translated.
<G-vec00127-002-s269><define.definierten><de> Die Kirsche oben drauf: Langfristig sparen Sie sich für jeden definierten Term Geld, da Sie für jedes übersetzte Wort nur einmal bezahlen müssen.
<G-vec00127-002-s270><define.definierten><en> In short our customers and we define Ria as a safe, reliable and effective company.
<G-vec00127-002-s270><define.definierten><de> Kurz gesagt, sowohl unsere Kunden als auch wir definierten Ria als ein sicheres, vertrauenswürdiges und effektives Unternehmen.
<G-vec00127-002-s271><define.definierten><en> Amazon Virtual Private Cloud lets you use security groups and network access control lists (ACLs) so that you have fine-grained control of the network traffic flowing to and from your Amazon EC2 instances in a logically isolated virtual network you define. Learn More »
<G-vec00127-002-s271><define.definierten><de> Amazon Virtual Private Cloud lässt die Nutzung von Sicherheitsgruppen und Zugriffsteuerungslisten (ACLs) für das Netzwerk zu, sodass Sie den Netzwerkdatenverkehr zu und von Ihren EC2-Instances in einem logisch isolierten von Ihnen definierten virtuellen Netzwerk differenziert steuern können.
<G-vec00127-002-s272><define.definierten><en> Amazon ECS allows you to customize how tasks are placed onto a cluster of EC2 instances based on built-in attributes such as instance type, Availability Zone, or custom attributes that you define.
<G-vec00127-002-s272><define.definierten><de> Mit Amazon ECS können Sie anpassen, wie Aufgaben auf einem Cluster von EC2-Instances basierend auf integrierten Attributen wie Instance-Typ, Availability Zone und von Ihnen definierten benutzerdefinierten Attributen platziert werden.
<G-vec00127-002-s273><define.definierten><en> In compliance with industry define norms and guidelines, these products are highly recommended by our customers for exhibiting international quality standards.
<G-vec00127-002-s273><define.definierten><de> In Übereinstimmung mit den von der Industrie definierten Normen und Richtlinien werden diese Produkte von unseren Kunden wärmstens empfohlen, um internationale Qualitätsstandards zu erfüllen.
<G-vec00127-002-s274><define.definierten><en> Purchase value – Use this filter to target those customers only whose purchase value meets the criterion you define here.
<G-vec00127-002-s274><define.definierten><de> Purchase value Verwenden Sie diesen Filter, um Kunden anzusprechen, deren Kaufwert den von Ihnen hier definierten Kriterien entspricht.
<G-vec00127-002-s275><define.definierten><en> Both types of shortcuts override the ones you define in the Specify Shortcuts dialog box. Related topics
<G-vec00127-002-s275><define.definierten><de> Beide Arten von Tastaturbefehlen überschreiben die von Ihnen im Dialogfeld „Tastaturbefehle angeben“ definierten Tastaturbefehle.
<G-vec00127-002-s276><define.definierten><en> When you design the initiation form, you choose whether or not to supply a default value for each of the parameters that you define.
<G-vec00127-002-s276><define.definierten><de> Beim Entwurf des Initiierungsformulars entscheiden Sie, ob Sie für jeden der von Ihnen definierten Parameter einen Standardwert angeben möchten.
<G-vec00127-002-s277><define.definierten><en> Now, rail vehicle manufacturers have joined to define the International Railway Industry Standard, IRIS for short, and set new standards for the future.
<G-vec00127-002-s277><define.definierten><de> Mit dem gemeinsam definierten International Railway Industry Standard, kurz IRIS, setzen die Schienenfahrzeughersteller nun neue Maßstäbe für die Zukunft.
<G-vec00127-002-s278><define.definierten><en> According to key fields you define, the Excel Adapter checks whether the record exists for updating or else will insert it into the sheet.
<G-vec00127-002-s278><define.definierten><de> Der Excel Adapter prüft anhand der definierten Schlüsselfelder automatisch ob der Datensatz aktualisiert oder aber nur an das Arbeitsblatt angefügt werden soll.
<G-vec00127-002-s279><define.definierten><en> Based on your current rankings and targets, that we define together, we use keyword research to determine possible new ranking potentials.
<G-vec00127-002-s279><define.definierten><de> Ausgehend von Ihren derzeitigen Rankings und den gemeinsam definierten Zielen ermitteln wir mithilfe einer Keyword Research neue, mögliche Rankingpotentiale.
<G-vec00127-002-s280><define.definierten><en> Due to the change in communications, we are - more than ever - in a position today, to sustainably follow and make the objectives measurable which our clients define.
<G-vec00127-002-s280><define.definierten><de> Durch den Wandel in der Kommunikation können wir heute, mehr denn je, nachhaltig die durch unsere Kunden definierten Ziele verfolgen und messbar machen.
<G-vec00127-002-s281><define.definierten><en> Your unaddressed items reach all households and all private customer P.O. Boxes in the target area you define.
<G-vec00127-002-s281><define.definierten><de> Ihre unadressierten Sendungen gelangen in alle Haushalte sowie in alle Privatkundenpostfächer in dem von Ihnen definierten Zielgebiet.
<G-vec00127-002-s282><define.definierten><en> The congress was the location of an encounter between various persons and languages which currently define what is still/already alive and what is still/already dead.
<G-vec00127-002-s282><define.definierten><de> Der Kongress inszenierte einen theatralen Ort der Wissenschaftspopularisierung, in dem verschiedene Personen und Redeweisen, Wissenschaftskulturen und spekulative Fiktionen definierten, was noch/schon lebendig und was noch/schon tot ist.
<G-vec00127-002-s283><define.definierten><en> Exhibitors can supplement the visitor data with additional, individual information such as memos of meetings, or define and then create categories using “tags”.
<G-vec00127-002-s283><define.definierten><de> Aussteller können den Besucherdaten zusätzliche, individuelle Informationen wie Gesprächsnotizen hinzufügen oder mit Hilfe von „Tags“ in selbst definierten Kategorien zusammenfassen.
<G-vec00127-002-s341><define.festlegen><en> 4. Member States shall clearly define the tasks of the Managing Authority, the Paying Agency and the local action groups under LEADER as regards to the application of eligibility and selection criteria and the project selection procedure.
<G-vec00127-002-s341><define.festlegen><de> (4) Die Mitgliedstaaten legen die Aufgaben der Verwaltungsbehörde, der Zahlstelle und der lokalen Aktionsgruppen im Rahmen von LEADER hinsichtlich der Anwendung der Förderfähigkeits- und Auswahlkriterien und des Projektauswahlverfahrens genau fest.
<G-vec00127-002-s342><define.festlegen><en> With hindsight Elisàr was able to recognise components that were subsequently to define his oeuvre: the spirit of “German superiority”, the leading position of a class that continued to “refine” itself from generation to generation, a distinct appreciation of aesthetics, but also an awareness of the transience of human existence and political systems.
<G-vec00127-002-s342><define.festlegen><de> Rückblickend stellt Elisàr bereits an diesem Punkt die Komponenten fest, die sein Gesamtwerk später kennzeichnen sollten: «deutscher Herrengeist», die Führungsposition eines sich über Generationen hinweg «veredelnden» Standes, ein ausgeprägter Sinn für Ästhetik, aber auch das Wissen um die Vergänglichkeit der menschlichen Existenz und politischer Systeme.
<G-vec00127-002-s343><define.festlegen><en> In the Access options tab, you define which zimbra services are available.
<G-vec00127-002-s343><define.festlegen><de> Im Bereich Access options legen Sie fest, welche Dienste erreichbar sein sollen.
<G-vec00127-002-s344><define.festlegen><en> The Federal Council1 shall define the extent to which and the circumstances in which error tolerances may be allowed for deviations from the standard of fineness.
<G-vec00127-002-s344><define.festlegen><de> Fehlergrenze Der Bundesrat1 setzt fest, inwieweit und unter welchen Voraussetzungen Fehlergrenzen für Abweichungen vom Feingehalt eingeräumt werden können.
<G-vec00127-002-s345><define.festlegen><en> K8s define how services interact with each other.
<G-vec00127-002-s345><define.festlegen><de> K8s legt fest, wie Services miteinander interagieren.
<G-vec00127-002-s346><define.festlegen><en> Participants will create their own customized implementation roadmap in which they define how they can implement digitalization to improve their businesses’ competitiveness.
<G-vec00127-002-s346><define.festlegen><de> Anhand einer individuell erstellten „Implementierungs-Roadmap“ legen die Teilnehmenden fest, wie sie die Digitalisierung umsetzen und damit die Wettbewerbsfähigkeit ihres Unternehmens verbessern können.
<G-vec00127-002-s347><define.festlegen><en> The appearance of the defined symbol in an internal table will cause Qlik Sense to define it as all values not previously loaded in the field where it is found.
<G-vec00127-002-s347><define.festlegen><de> Taucht das definierte Symbol in einer internen Tabelle auf, setzt QlikView es für alle Werte des Felds fest, die noch nicht geladen sind.
<G-vec00127-002-s348><define.festlegen><en> By specifying two columns you define the beginning and the end of the operation area within the record.
<G-vec00127-002-s348><define.festlegen><de> Durch Angabe von 2 Spalten legst du Anfang und Ende des Operationsfeldes im Satz fest.
<G-vec00127-002-s349><define.festlegen><en> 2. Whenever it deems it necessary, the Council shall define a common position.
<G-vec00127-002-s349><define.festlegen><de> (2) In allen Fällen, in denen er dies als erforderlich erachtet, legt der Rat einen gemeinsamen Standpunkt fest.
<G-vec00127-002-s350><define.festlegen><en> Identify problems and try to define for yourself what they are.
<G-vec00127-002-s350><define.festlegen><de> Identifiziere die Probleme und stelle für dich selbst fest, was sie sind.
<G-vec00127-002-s351><define.festlegen><en> I define the top priority for my private life for the next day (if possible up to three).
<G-vec00127-002-s351><define.festlegen><de> Lege ich eine höchste Priorität für mein privates Leben am nächsten Tag fest (wenn es geht bis zu drei).
<G-vec00127-002-s352><define.festlegen><en> A third ball will be drawn from Pot E to define the team in the fifth position of Group 3.
<G-vec00127-002-s352><define.festlegen><de> Ein dritter Ball aus Topf E legte fest, welche Mannschaft in der Gruppe 3 auf Position fünf spielt.
<G-vec00127-002-s353><define.festlegen><en> 1. A CCP shall define the time horizons for the liquidation period taking into account the characteristics of the financial instrument cleared, the market where it is traded, and the period for the calculation and collection of the margins.
<G-vec00127-002-s353><define.festlegen><de> (1) Eine CCP legt die Zeithorizonte für die Liquidationsperiode unter Berücksichtigung der Merkmale des geclearten Finanzinstruments, des Markts, auf dem es gehandelt wird, und des Zeitraums für die Berechnung und Einnahme der Einschusszahlungen fest.
<G-vec00127-002-s354><define.festlegen><en> 3.3 The Articles of Association or the Supervisory Board – the latter also as necessary in individual cases – define reservations of consent in relation to the Supervisory Board for transactions of fundamental importance.
<G-vec00127-002-s354><define.festlegen><de> 3.3 Für Geschäfte von grundlegender Bedeutung legen die Satzung oder der Aufsichtsrat – dieser gegebenenfalls auch im Einzelfall –Zustimmungsvorbehalte des Aufsichtsrats fest.
<G-vec00127-002-s355><define.festlegen><en> Simply define your target population (smart list) using any combination of values, select the learning assignments to be pushed, and set the schedule.
<G-vec00127-002-s355><define.festlegen><de> Wählen Sie dann die zu erfüllenden Aufgaben, etwa Registrierungen, Lehrpläne, Ziele, Fähigkeiten oder eine Kombination daraus, und legen Sie den Zeitplan fest.
<G-vec00127-002-s375><define.festlegen><en> When in Flex mode, the user interface now updates properly when the Marquee tool is used to define areas to shift in time.
<G-vec00127-002-s375><define.festlegen><de> Wenn im Modus "Flex" mit dem Werkzeug "Marquee" Bereiche festgelegt werden, die zeitlich verschoben werden sollen, wird die Benutzeroberfläche ab sofort korrekt aktualisiert.
<G-vec00127-002-s376><define.festlegen><en> To add a "paragraph", we define its boundaries by dragging with the Type tool (fig.
<G-vec00127-002-s376><define.festlegen><de> Um einen „Absatztext“ hinzuzufügen, führen wir durch das Dokument mit dem Textwerkzeug, damit seine Grenzen festgelegt werden.
<G-vec00127-002-s377><define.festlegen><en> He is also the only one who may define the access rights for each account in the group (full access, read-only access, none).
<G-vec00127-002-s377><define.festlegen><de> Auch können die Zugriffsrechte für jedes Account in der Gruppe (Vollzugriff, schreibgeschützt oder kein Zugang) nur durch ihn festgelegt werden.
<G-vec00127-002-s378><define.festlegen><en> In order to neglect a minor moment loading about the minor axis, you can define a limit for the moments ratio Mz,Ed / Mpl,z,Rd.
<G-vec00127-002-s378><define.festlegen><de> Um eine geringe Momentenbeanspruchung um die schwache Achse zu vernachlässigen, kann eine Grenze des Momentenverhältnisses Mz,Ed / Mpl,z,Rd festgelegt werden.
<G-vec00127-002-s379><define.festlegen><en> You cannot define parameters for named ranges that contain more than one cell.
<G-vec00127-002-s379><define.festlegen><de> Für benannte Bereiche, die mehrere Zellen enthalten, können keine Parameter festgelegt werden.
<G-vec00127-002-s380><define.festlegen><en> It allows to define individual sequences in which the items are packed in the DC, based on how the goods are arranged in the shops.
<G-vec00127-002-s380><define.festlegen><de> Für jede Filiale kann entsprechend der Anordnung der Waren im Geschäft eine individuelle Reihenfolge festgelegt werden, in der die Artikel verpackt werden.
<G-vec00127-002-s381><define.festlegen><en> The course access configuration includes an option to define if users can actively leave the course or not, with a default configuration of “Anytime”.
<G-vec00127-002-s381><define.festlegen><de> In der Zugangskonfiguration eines Kurses kann festgelegt werden ob Benutzer einen Kurs selbständig verlassen können, mit der standardmässigen Einstellung auf „Jederzeit“.
<G-vec00127-002-s382><define.festlegen><en> In order to promote innovation, to avoid imposing barriers on the market and to ensure that the monitoring methodology is technology neutral, it should not define the specific tests to be applied for measuring the accessibility of websites and mobile applications.
<G-vec00127-002-s382><define.festlegen><de> Um die Innovation zu fördern, Hindernisse auf dem Markt zu vermeiden und dafür zu sorgen, dass die Überwachungsmethodik technologieneutral ist, sollten keine bestimmten Prüfverfahren für die Ermittlung der Barrierefreiheit von Websites und mobilen Anwendungen festgelegt werden.
<G-vec00127-002-s383><define.festlegen><en> The user creates a master file with which to define test parameters, positions and tolerances.
<G-vec00127-002-s383><define.festlegen><de> Der Benutzer erstellt eine Masterdatei, mit der die Prüfparameter, die Positionen und die Toleranzen festgelegt werden.
<G-vec00127-002-s384><define.festlegen><en> To give foundation to these policies in this sector, it is necessary to identify and define a European model – a system of shared ethical values for enterprises.
<G-vec00127-002-s384><define.festlegen><de> Damit man diese politischen Maßnahmen ergreifen kann, muss ein europäisches Modell gemeinsamer ethischer Werte der Unternehmenskultur festgestellt und festgelegt werden.
<G-vec00127-002-s385><define.festlegen><en> It is also possible to define under which conditions such an entry should be copied.
<G-vec00127-002-s385><define.festlegen><de> Dabei kann festgelegt werden, unter welchen Bedingungen ein solcher Eintrag kopiert wird.
<G-vec00127-002-s386><define.festlegen><en> You can define shortcut keys for all standard view types, allowing you to switch quickly between the view types in the current viewport.
<G-vec00127-002-s386><define.festlegen><de> Für alle Standard-Ansichtsarten können Tastenkombinationen festgelegt werden; so lässt sich die Ansichtsart im aktiven Fenster schnell umstellen.
<G-vec00127-002-s387><define.festlegen><en> For each check, it is possible to define who must process the inspection reports, as well as when and where the check must be performed.
<G-vec00127-002-s387><define.festlegen><de> Zu jeder Kontrolle kann festgelegt werden, wer die Prüfprotokolle abzuarbeiten hat, sowie wann und wo die Prüfung durchzuführen ist.
<G-vec00127-002-s388><define.festlegen><en> In line with its compliance policies, a company can define which transactions should be stored in the audit log.
<G-vec00127-002-s388><define.festlegen><de> Entsprechend der im Unternehmen gültigen Vorgaben kann festgelegt werden, welche Vorgänge im Audit Protokoll gespeichert werden sollen.
<G-vec00127-002-s389><define.festlegen><en> The Court notes first of all in that regard that the purpose of the directive is to define the conditions governing the exercise of the right of free movement and residence within the territory of the Member States.
<G-vec00127-002-s389><define.festlegen><de> Insoweit weist der Gerichtshof zunächst darauf hin, dass mit der Richtlinie die Bedingungen festgelegt werden sollen, unter denen Unionsbürger das Recht auf Freizügigkeit und Aufenthalt innerhalb des Hoheitsgebiets der Mitgliedstaaten genießen.
<G-vec00127-002-s390><define.festlegen><en> Digital signals generally conform to certain specifications that define the characteristics of the signal.
<G-vec00127-002-s390><define.festlegen><de> Digitalsignale entsprechen in der Regel bestimmten Spezifikationen, die die Signaleigenschaften festlegen.
<G-vec00127-002-s391><define.festlegen><en> After that you can define the text style in the Text menu.
<G-vec00127-002-s391><define.festlegen><de> Danach können Sie den Textstil und die Maßstabsabhängige Darstellung festlegen.
<G-vec00127-002-s392><define.festlegen><en> After communication with the PKI provider is successfully established, you can define which certificate to deploy to computers or mobile devices.
<G-vec00127-002-s392><define.festlegen><de> Nachdem die Verbindung zum PKI-Anbieter erfolgreich hergestellt wurde, können Sie festlegen, welches Zertifikat auf Computern oder Mobilgeräten bereitgestellt werden soll.
<G-vec00127-002-s393><define.festlegen><en> In addition to using the built-in keyboard shortcuts listed in this Appendix, you can define your own.
<G-vec00127-002-s393><define.festlegen><de> Sie können zusätzlich zu den bereits vorgegebenen und in diesem Anhang aufgelisteten Tastaturkürzeln eigene Tastaturkürzel festlegen.
<G-vec00127-002-s394><define.festlegen><en> To achieve this, PowerPoint offers Slide Masters, which let you define the basic formatting and properties for all your slides.
<G-vec00127-002-s394><define.festlegen><de> Hierzu bietet Powerpoint den Folienmaster, mit dem Sie grundsätzliche Formatierungen und Einstellungen für Ihre Folien einmalig festlegen.
<G-vec00127-002-s395><define.festlegen><en> For reports of the graphic report builder, you have to define the "Courier New" font for the report field.
<G-vec00127-002-s395><define.festlegen><de> Für Listen des grafischen Listeneditors müssen Sie für das Listenfeld die Schriftart "Courier New" festlegen.
<G-vec00127-002-s396><define.festlegen><en> Use DMARC to define how Gmail handles messages that appear to be sent from your domain but that are actually spam.
<G-vec00127-002-s396><define.festlegen><de> Mithilfe von DMARC können Sie festlegen, welche Aktionen für Spam-E-Mails in Gmail ausgeführt werden sollen, die anscheinend von Ihrer Domain aus verschickt wurden.
<G-vec00127-002-s397><define.festlegen><en> The Governing Board should define the access rights to the Union's share of access time for each supercomputer.
<G-vec00127-002-s397><define.festlegen><de> Für den auf die Union entfallenden Anteil der Zugriffszeit sollte der Verwaltungsrat die Zugangsrechte festlegen.
<G-vec00127-002-s398><define.festlegen><en> Instead of the ESC key you can also define a key combination here which will bring up the Exit dialog box.
<G-vec00127-002-s398><define.festlegen><de> Anstatt der ESC-Taste können Sie hier optional eine Tastenkombination festlegen, die den Beenden-Dialog aufruft.
<G-vec00127-002-s399><define.festlegen><en> The next aspect relates to the focus, which you can also define in Pro modes.
<G-vec00127-002-s399><define.festlegen><de> Der nächste Aspekt betrifft den Fokus, den Ihr bei den Pro-Modi ebenfalls festlegen könnt.
<G-vec00127-002-s400><define.festlegen><en> In addition to this, the program allows you to define detailed parameters of video and audio for conversion.
<G-vec00127-002-s400><define.festlegen><de> Darüber hinaus ermöglicht das Programm das detaillierte Festlegen von Video- und Audio-Parametern für die Konvertierung.
<G-vec00127-002-s401><define.festlegen><en> It is possible to define up to five different starting points for the robot mower.
<G-vec00127-002-s401><define.festlegen><de> Es lassen sich bis zu fünf unterschiedliche Startpunkte für den Mähroboter festlegen.
<G-vec00127-002-s402><define.festlegen><en> A wide range of powerful functions ensure simple, flexible installation and operation: With the Teach-in function users, even without specialist knowledge, can quickly and easily define the lux values at which the detector should switch on.
<G-vec00127-002-s402><define.festlegen><de> Eine Vielzahl leistungsfähiger Funktionen sorgt für einfache, flexible Montage und Bedienung: Mit der Teach-In-Funktion können Anwender auch ohne Fachkenntnisse einfach und schnell festlegen, bei welchen Luxwerten der Melder einschalten soll.
<G-vec00127-002-s403><define.festlegen><en> 7b. Subject to technical constraints inherent in managing networks, Member States shall promote demand response's access to and participation in balancing, reserve and other system services markets, inter alia by requiring national regulatory authorities or, where their national regulatory systems so require, transmission and distribution system operators in close cooperation with demand service providers and consumers, to define technical modalities for participation in these markets on the basis of the technical requirements of these markets and the capabilities of demand response.
<G-vec00127-002-s403><define.festlegen><de> Vorbehaltlich technischer Sachzwänge im Zusammenhang mit dem Netzmanagement fördern die Mitgliedstaaten in Bezug auf Märkte für Ausgleichsleistungen, Reservedienste und andere Systemdienste den Marktzugang und die Marktteilnahme von Laststeuerungs-Dienstleistern, unter anderem indem sie verlangen, dass die nationalen Regulierungsbehörden oder, falls dies in ihren nationalen Regulierungssystemen vorgesehen ist, die Übertragungs- und Verteilernetzbetreiber in enger Zusammenarbeit mit den Laststeuerungs-Dienstleistern und Verbrauchern auf der Grundlage der technischen Anforderungen dieser Märkte und der Laststeuerungsmöglichkeiten technische Modalitäten für die Teilnahme an diesen Märkten festlegen.
<G-vec00127-002-s404><define.festlegen><en> The hospitals can define the cost for medical treatments and medication themselves.
<G-vec00127-002-s404><define.festlegen><de> Die Krankenhäuser dürfen die Höhe der Behandlungskosten und Medikamente selbst festlegen.
<G-vec00127-002-s405><define.festlegen><en> In this video we will show you how to show and define customized properties for shapes in Visio.
<G-vec00127-002-s405><define.festlegen><de> In diesem Film zeigen wir Ihnen, wie Sie in Visio benutzerdefinierte Eigenschaften für Shapes anzeigen und festlegen.
<G-vec00127-002-s406><define.festlegen><en> Administration To define the settings, open the Settings (DMS) window in the program selection.
<G-vec00127-002-s406><define.festlegen><de> Administration Zum Festlegen von Einstellungen öffnen Sie das Fenster Einstellungen (DMS) in der Programmauswahl.
<G-vec00127-002-s407><define.festlegen><en> On this page you may define the layout of the program.
<G-vec00127-002-s407><define.festlegen><de> Auf dieser Seite können Sie das Aussehen des Programms festlegen.
<G-vec00127-002-s408><define.festlegen><en> We propose a consultancy in order to define your specific system requirements.
<G-vec00127-002-s408><define.festlegen><de> Wir schlagen daher einen 2-tägigen Workshop vor, bei dem wir gemeinsam die spezifischen Systemanforderungen festlegen.
<G-vec00127-002-s428><define.festlegen><en> The purpose of the Agreement is to enhance the fight against fraud, corruption or any other criminal offence or illegal activities affecting the EU's financial interests and to define to this end the modalities for close cooperation between the Parties.
<G-vec00127-002-s428><define.festlegen><de> Ziel dieser Vereinbarung ist es, die Bekämpfung von Betrug, Korruption and allen sonstigen strafbaren oder illegalen Handlungen, die gegen die finanziellen Interessen der EU gerichtet sind, zu verbessern und zu diesem Zweck die Modalitäten einer engen Zusammenarbeit zwischen den Parteien festzulegen.
<G-vec00127-002-s429><define.festlegen><en> The organisation shall establish a documented procedure to define the controls needed for the identification, storage, protection, retrieval, retention time and disposition of records.
<G-vec00127-002-s429><define.festlegen><de> Die Organisation muss ein dokumentiertes Verfahren erstellen, um die Lenkungsmaßnahmen festzulegen, die für die Kennzeichnung, die Aufbewahrung, den Schutz, die Wiederauffindbarkeit und die Aufbewahrungsfrist von Aufzeichnungen sowie die Verfügbarkeit über Aufzeichnungen erforderlich sind.
<G-vec00127-002-s430><define.festlegen><en> Proceed as described below to define an RRP for Amazon country platforms.
<G-vec00127-002-s430><define.festlegen><de> Gehen Sie wie im Folgenden beschrieben vor, um für Amazon-Länderplattformen einen UVP festzulegen.
<G-vec00127-002-s431><define.festlegen><en> Students will be given the “Student Copy” of the Identification Activity and will be asked to define whether the four scenarios are either a Primary or Secondary source.
<G-vec00127-002-s431><define.festlegen><de> Die Studierenden erhalten die "Student Copy" der Identification Activity und werden gebeten, festzulegen, ob die vier Szenarien entweder eine primäre oder sekundäre Quelle sind.
<G-vec00127-002-s432><define.festlegen><en> Adding a new identity requires to define both the corresponding roles and a labeling prefix which is used to assign a type to personal files (/home/user/*).
<G-vec00127-002-s432><define.festlegen><de> Um eine neue Identität hinzuzufügen, ist es erforderlich, sowohl die entsprechenden Rollen als auch ein kennzeichnendes Präfix festzulegen, das dazu benutzt wird, einem Typ persönliche Dateien (/home/benutzer/*) zuzuordnen.
<G-vec00127-002-s433><define.festlegen><en> A documented procedure shall be established to define requirements for a) determining potential nonconformities and their causes, b) evaluating the need for action to prevent occurrence of nonconformities, c) determining and implementing action needed, d) records of results of action taken (see 4.2.4), and e) reviewing the effectiveness of the preventive action taken. 14
<G-vec00127-002-s433><define.festlegen><de> Ein dokumentiertes Verfahren muss eingeführt werden, um Anforderungen festzulegen zur a) Ermittlung potentieller Fehler und ihrer Ursachen, b) Beurteilung des Handlungsbedarfs, um das Auftreten von Fehlern zu verhindern, c) Ermittlung und Verwirklichung der erforderlichen Maßnahmen, d) Aufzeichnung der Ergebnisse der ergriffenen Maßnahmen (siehe 4.2.4), und e) Bewertung der ergriffenen Vorbeugungsmaßnahmen.
<G-vec00127-002-s434><define.festlegen><en> The use of derivatives by a CCP exposes it to additional credit and market risks and it is therefore necessary to define a restrictive set of circumstances in which a CCP can invest its financial resources in derivatives.
<G-vec00127-002-s434><define.festlegen><de> Durch die Nutzung von Derivaten entstehen für CCP zusätzliche Kredit- und Marktrisiken, und es ist daher erforderlich, restriktive Bedingungen festzulegen, nach denen CCP ihre Finanzmittel in Derivate investieren können.
<G-vec00127-002-s435><define.festlegen><en> In addition the report helps to define the possible improvement actions that the hotel can adopt.
<G-vec00127-002-s435><define.festlegen><de> Die Berichte dienen dem Hotel dazu, Maßnahmen für mögliche Verbesserungen in der Zukunft festzulegen.
<G-vec00127-002-s436><define.festlegen><en> 1. The purpose of this Regulation is to define how, in accordance with the rules of Community law, competent authorities may act in the field of public passenger transport to guarantee the provision of services of general interest which are among other things more numerous, safer, of a higher quality or provided at lower cost than those that market forces alone would have allowed.
<G-vec00127-002-s436><define.festlegen><de> (1) Zweck dieser Verordnung ist es, festzulegen, wie die zuständigen Behörden unter Einhaltung des Gemeinschaftsrechts im Bereich des öffentlichen Personenverkehrs tätig werden können, um die Erbringung von Dienstleistungen von allgemeinem Interesse zu gewährleisten, die unter anderem zahlreicher, sicherer, höherwertig oder preisgünstiger sind als diejenigen, die das freie Spiel des Marktes ermöglicht hätte.
<G-vec00127-002-s437><define.festlegen><en> Before you click on "Share and confirm you would like to share the post, you can define who the post is released to.
<G-vec00127-002-s437><define.festlegen><de> Bevor Sie auf "Share" klicken und den Beitrag damit teilen, haben Sie noch die Möglichkeit, die Freigabe festzulegen.
<G-vec00127-002-s438><define.festlegen><en> Easily set complex calling rules – complex calling algorithms enable you to define the sequence and priority in which categories of interview cases are to be called.
<G-vec00127-002-s438><define.festlegen><de> Programmieren Sie mühelos komplexe Anrufregeln– komplexe Anrufalgorithmen ermöglichen Ihnen, die Reihenfolge und Prioritäten der durchzuführenden Interviews festzulegen.
<G-vec00127-002-s439><define.festlegen><en> With the help of the limit, it is possible to define the number of internal links within a page.
<G-vec00127-002-s439><define.festlegen><de> Mit Hilfe des Limits ist es dir möglich, die Anzahl an internen Verlinkungen innerhalb einer Seite festzulegen.
<G-vec00127-002-s440><define.festlegen><en> Next, options were created to define in which layer - for example when constructing the exterior walls - the geometry is to be read in the timber construction program.
<G-vec00127-002-s440><define.festlegen><de> Als nächstes wurden Möglichkeiten geschaffen, festzulegen, in welche Schicht - zum Beispiel beim Aufbau der Außenwände - die Geometrie im Holzbauprogramm eingelesen werden soll.
<G-vec00127-002-s441><define.festlegen><en> In column C, you define the number of cross-section sides that are exposed to fire.
<G-vec00127-002-s441><define.festlegen><de> In Spalte C ist die Anzahl der brandbeanspruchten Querschnittseiten festzulegen.
<G-vec00127-002-s442><define.festlegen><en> Furthermore, customers can define their own personal priorities, such as charging when electricity is less expensive.
<G-vec00127-002-s442><define.festlegen><de> Zudem hat der Kunde die Möglichkeit, individuelle Prioritäten festzulegen, etwa das Laden zu kostengünstigen Zeiten.
<G-vec00127-002-s443><define.festlegen><en> We have attempted to define some ground rules on what teams within Fedora qualify as projects inorder to establish a level of quality and holistic understanding of our developments.
<G-vec00127-002-s443><define.festlegen><de> Wir haben versucht, in ein paar Grundregeln festzulegen, welche Teams innerhalb Fedora als Projekt angesehen werden, um ein gewisses Level an Qualität und HOLISTIC Verständnis unserer Entwicklung zu sichern.
<G-vec00127-002-s444><define.festlegen><en> The purpose of this policy is to define the principles which apply within the “La Coop des Communs” association for the management of rights on the works of its members, in particular within the framework of the activities of its work-groups.
<G-vec00127-002-s444><define.festlegen><de> Zweck dieses Regelwerks ist es, Grundsätze festzulegen, die innerhalb der Vereinigung „La Coop des Communs“ für die Verwaltung der Rechte an den Werken ihrer Mitglieder_Innen gelten, insbesondere im Rahmen der Tätigkeit ihrer Arbeitsgruppen.
<G-vec00127-002-s445><define.festlegen><en> Suunto Ambit2 allows you to save your current location or define a location as a POI.
<G-vec00127-002-s445><define.festlegen><de> Suunto Ambit2 S bietet die Möglichkeit, Ihren aktuellen Standort als POI zu speichern oder einen anderen Standort als POI festzulegen.
<G-vec00127-002-s446><define.festlegen><en> Negotiations shall then be opened to define the framework for the United Kingdom’s future relationship with the European Union.
<G-vec00127-002-s446><define.festlegen><de> Im Anschluss ist die Eröffnung von Verhandlungen vorgesehen, um den Rahmen für die künftigen Beziehungen zwischen dem Vereinigten Königreich und der Europäischen Union festzulegen.
<G-vec00127-002-s484><define.festlegen><en> In addition to the adopted work-free days, you define the work-free days which only apply to this company calendar.
<G-vec00127-002-s484><define.festlegen><de> Zusätzlich zu den vererbten arbeitsfreien Tagen legen Sie in dem Betriebskalender die arbeitsfreien Tage fest, die nur für den Betriebskalender gelten.
<G-vec00127-002-s485><define.festlegen><en> For each master files record, you define the display sequence and thus specify the sequence of the analysis columns in the set analysis.
<G-vec00127-002-s485><define.festlegen><de> Je Stammdatensatz legen Sie die Anzeigefolge fest und bestimmen somit die Reihenfolge der Auswertungsspalten in der Set-Auswertung.
<G-vec00127-002-s486><define.festlegen><en> Alternatively, they can define an integration time and get the precision of the appropriate temperature range determined.
<G-vec00127-002-s486><define.festlegen><de> Oder sie legen eine Integrationszeit fest und bekommen den passenden Temperaturbereich ermittelt.
<G-vec00127-002-s487><define.festlegen><en> Conception Conception At the beginning we realize the conceptual design and define in close cooperation the basic conditions according to your requirements.
<G-vec00127-002-s487><define.festlegen><de> Konzeption Konzeption Gemäß Ihren Anforderungen machen wir uns zu Beginn an die Konzeption Ihrer Anlage und legen in enger Zusammenarbeit die Randbedingungen fest.
<G-vec00127-002-s488><define.festlegen><en> The following General Terms and Conditions (hereinafter “GTC”) define the terms under which the ukdating.expatica.com Service (hereinafter “the Service”) operated by Tyche Technologies AG a Swiss company, Reg Nr.
<G-vec00127-002-s488><define.festlegen><de> Die folgenden Allgemeinen Geschäftsbedingungen (nachfolgend „AGB“ genannt) legen die Bedingungen fest für die Nutzung der Services, die unter dem ukdating.expatica.com-Dienst (nachfolgend „Dienst“ genannt) von der Tyche Technologies AG, einem Schweizer Unternehmen mit der Registrierungsnr.
<G-vec00127-002-s489><define.festlegen><en> With this setting you define a behavior different from the default setting for CRO-controlled parts: If the stock on hand of a CRO-controlled part is "0", the average price is determined from the last warehouse-in posting.
<G-vec00127-002-s489><define.festlegen><de> Mit dieser Einstellung legen Sie ein von der Standardeinstellung abweichendes Verhalten für kommissionspflichtige Teile fest: Wenn der Lagerbestand eines kommissionspflichtigen Teils "0" ist, dann wird der Durchschnittspreis aus der letzten Zugangsbuchung ermittelt.
<G-vec00127-002-s490><define.festlegen><en> The following General Terms and Conditions (hereinafter “GTC”) define the terms under which the bumboys.za.net Service (hereinafter “the Service”) operated by Tyche Technologies AG a Swiss company, Reg Nr.
<G-vec00127-002-s490><define.festlegen><de> Die folgenden Allgemeinen Geschäftsbedingungen (nachfolgend „AGB“ genannt) legen die Bedingungen fest für die Nutzung der Services, die unter dem bumboys.za.net-Dienst (nachfolgend „Dienst“ genannt) von der Tyche Technologies AG, einem Schweizer Unternehmen mit der Registrierungsnr.
<G-vec00127-002-s491><define.festlegen><en> For each phase of the project (Initiation, Planning, Implementation, Monitoring and Control, Closing), we consult with our Customer, and we define the tasks to be performed by each party (Role and Responsibility Matrix).
<G-vec00127-002-s491><define.festlegen><de> Für die einzelnen Tätigkeitsgruppen in einem Projekt (Projektstart, Planung, Durchführung, Monitoring und Controlling, Abschluss) legen wir in Abstimmung mit dem Kunden die in den jeweiligen Gruppen zu verrichtenden Aufgaben fest (Matrix Rolle und Verantwortung).
<G-vec00127-002-s492><define.festlegen><en> The following General Terms and Conditions (hereinafter “GTC”) define the terms under which the netbuddies.se Service (hereinafter “the Service”) operated by Tyche Technologies AG a Swiss company, Reg Nr.
<G-vec00127-002-s492><define.festlegen><de> Die folgenden Allgemeinen Geschäftsbedingungen (nachfolgend „AGB“ genannt) legen die Bedingungen fest für die Nutzung der Services, die unter dem netbuddies.se-Dienst (nachfolgend „Dienst“ genannt) von der Tyche Technologies AG, einem Schweizer Unternehmen mit der Registrierungsnr.
<G-vec00127-002-s493><define.festlegen><en> Together, we define the theoretical foundation that will then lead to your video.
<G-vec00127-002-s493><define.festlegen><de> Wir legen gemeinsam mit Ihnen das theoretische Fundament, das uns zu Ihrem Video führt.
<G-vec00127-002-s494><define.festlegen><en> Member States shall define the characteristics to determine where legal arrangements have a structure or functions similar to trusts and other arrangements referred to in this subparagraph..
<G-vec00127-002-s494><define.festlegen><de> Die Mitgliedstaaten legen die Merkmale fest, durch die festgestellt werden kann, ob Rechtsvereinbarungen in ihrer Struktur und ihrer Funktion Trusts und anderen in diesem Unterabsatz genannten Regelungen ähneln.
<G-vec00127-002-s495><define.festlegen><en> Make Studio suit your way of working: reposition the Editor, select layout colors, fully customize your ribbons and define your own keyboard shortcuts that best suit your way of working
<G-vec00127-002-s495><define.festlegen><de> Ausrichten auf Ihre individuelle Arbeitsweise: Verschieben Sie den Editor in die gewünschte Position, wählen Sie Ihre bevorzugte Layout-Farbe aus, personalisieren Sie die Menübänder und legen Sie eigene Tastenkombinationen fest.
<G-vec00127-002-s496><define.festlegen><en> The following General Terms and Conditions (hereinafter “GTC”) define the terms under which the connectingromance.com Service (hereinafter “the Service”) operated by Tyche Technologies AG a Swiss company, Reg Nr.
<G-vec00127-002-s496><define.festlegen><de> Die folgenden Allgemeinen Geschäftsbedingungen (nachfolgend „AGB“ genannt) legen die Bedingungen fest für die Nutzung der Services, die unter dem buckangeldating.com-Dienst (nachfolgend „Dienst“ genannt) von der Tyche Technologies AG, einem Schweizer Unternehmen mit der Registrierungsnr.
<G-vec00127-002-s497><define.festlegen><en> We define a higher-level importance for your well-being.
<G-vec00127-002-s497><define.festlegen><de> Wir legen eine übergeordnete Wichtigkeit auf Ihr Wohlbefinden.
<G-vec00127-002-s498><define.festlegen><en> Defining Clipping Plane The ‘Clipping Plane’ function allows you to define any section through the model.
<G-vec00127-002-s498><define.festlegen><de> Die Funktion "Clippingebene" ermöglicht dem Anwender eine beliebige Schnittebene durch das Modell zu legen.
<G-vec00127-002-s499><define.festlegen><en> The following General Terms and Conditions (hereinafter “GTC”) define the terms under which the app.puertoricodatingnetwork.com Service (hereinafter “the Service”) operated by Tyche Technologies AG a Swiss company, Reg Nr.
<G-vec00127-002-s499><define.festlegen><de> Die folgenden Allgemeinen Geschäftsbedingungen (nachfolgend „AGB“ genannt) legen die Bedingungen fest für die Nutzung der Services, die unter dem community.datedienst.de-Dienst (nachfolgend „Dienst“ genannt) von der Tyche Technologies AG, einem Schweizer Unternehmen mit der Registrierungsnr.
<G-vec00127-002-s501><define.festlegen><en> Calamus offers a fantastic macro recorder which offers to define key bindings for almost all functions and keyboard input.
<G-vec00127-002-s501><define.festlegen><de> Calamus bietet bekanntlich einen fantastischen Makrorecorder, mit dem es möglich ist, nahezu alle Funktionen und Tastatureingaben auf Makrotasten zu legen.
<G-vec00127-002-s502><define.festlegen><en> Alternatively, you may define and assign OBS units in Meisterplan later.
<G-vec00127-002-s502><define.festlegen><de> Alternativ legen Sie OSP-Einheiten später in Meisterplan an und weisen diese dort auch zu.
<G-vec00127-002-s503><define.festlegen><en> You can flexibly define which property filters should be displayed in which category.
<G-vec00127-002-s503><define.festlegen><de> Legen Sie flexibel fest, welche Eigenschaften-Filter in welcher Kategorie angezeigt werden sollen.
<G-vec00127-002-s504><define.festlegen><en> With Advanced Shipping Cost, you define your own list of rules for shipping fees that suits your needs.
<G-vec00127-002-s504><define.festlegen><de> Mit Voraussichtliche Versandkosten legen Sie eine eigene Liste mit Versandgebühren fest, die auf Ihren Bedürfnissen basieren.
<G-vec00127-002-s505><define.festlegen><en> Here we define who can delete the signed document.
<G-vec00127-002-s505><define.festlegen><de> Hier legen wir fest, wer das signierte Dokument löschen darf.
<G-vec00127-002-s506><define.festlegen><en> Interchangeable capillary dies for Rosand rheometers define the applied shear field and deformation regime when a material is extruded through them.
<G-vec00127-002-s506><define.festlegen><de> Austauschbare Kapillardüsen für Rosand Rheometer legen den ausgeübten Scherratenbereich und die Deformationsparameter fest, wenn ein Material durch diese extrudiert wird.
<G-vec00127-002-s507><define.festlegen><en> When you set a goal with a time horizon, we define a growth path to get you there.
<G-vec00127-002-s507><define.festlegen><de> Anhand Ihrer finanziellen und zeitlichen Vorgaben legen wir einen Ertragsplan fest, der Sie zum Ziel bringt.
<G-vec00127-002-s508><define.festlegen><en> In addition, as part of our annual Goal Identification Programs, we define concrete measures for the continual improvement of the working environment and our occupational safety mechanisms.
<G-vec00127-002-s508><define.festlegen><de> Zudem legen wir im Rahmen unseres jährlichen Zielfindungsprozesses konkrete Maßnahmen für die ständige Verbesserung der Arbeitsumgebung und unserer Arbeitsschutzmechanismen fest.
<G-vec00127-002-s509><define.festlegen><en> The 146 Articles of the Basic Law supersede all other German legal norms and define the basic systems and values of the state.
<G-vec00127-002-s509><define.festlegen><de> Die 146 Artikel des Grundgesetzes stehen über allen anderen deutschen Rechtsnormen und legen die grundlegenden staatlichen System- und Wertentscheidungen fest.
<G-vec00127-002-s510><define.festlegen><en> This setting allows you to define a directory where machine learning backends data is stored.
<G-vec00127-002-s510><define.festlegen><de> Mit dieser Einstellung legen Sie fest, wo die Daten des Machine Learning Backends gespeichert werden.
<G-vec00127-002-s511><define.festlegen><en> Process After a thorough briefing with our clients we define the search list, work place, time line, and the "hot buttons".
<G-vec00127-002-s511><define.festlegen><de> Prozess Nach einem fundierten Briefing legen wir mit Ihnen die Suchlandschaft, das Anforderungsprofil, die Terminachse und die „Hot Buttons“ fest.
<G-vec00127-002-s512><define.festlegen><en> For variant parts, you define features and specifications in the variant builder (Classification systems).
<G-vec00127-002-s512><define.festlegen><de> Für Variantenteile legen Sie im Variantengenerator Merkmale und Ausprägungen fest (Merkmalsleisten).
<G-vec00127-002-s513><define.festlegen><en> You define who you are.
<G-vec00127-002-s513><define.festlegen><de> Sie legen fest, wer Sie sind.
<G-vec00127-002-s514><define.festlegen><en> Together we define an optimal candidate profile and use a range of tools to create a shortlist that provides you with various options.
<G-vec00127-002-s514><define.festlegen><de> Gemeinsam legen wir das optimale KandidatInnenprofil fest und verwenden ein Spektrum an Tools, um eine Shortlist zusammenzustellen, die eine Wahlmöglichkeit bietet.
<G-vec00127-002-s515><define.festlegen><en> Client parameters define what condition a client or a group of clients must meet in order to run the notification action.
<G-vec00127-002-s515><define.festlegen><de> Diese Clientparameter legen fest, welche Kriterien ein Client oder eine Gruppe von Clients erfüllen muss, damit die festgelegte Notifikationsaktion ausgeführt wird.
<G-vec00127-002-s516><define.festlegen><en> By means of the sequence of the withdrawal storage areas assigned you define the priorities of the withdrawal storage areas within the staging zone.
<G-vec00127-002-s516><define.festlegen><de> Mit der Reihenfolge der zugeordneten Entnahmelagerorte legen Sie die Prioritäten der Entnahmelagerorte innerhalb der Kommissionierzone fest.
<G-vec00127-002-s517><define.festlegen><en> Define who has read and write access individually or with role-based groups.
<G-vec00127-002-s517><define.festlegen><de> Legen Sie Lese- oder Schreibrechte fest: Individuell oder bequem in rollenbasierten Gruppen.
<G-vec00127-002-s518><define.festlegen><en> ASIL and ISO 26262 define standards for the functional safety of vehicles.
<G-vec00127-002-s518><define.festlegen><de> ASIL und ISO 26262 legen Standards für die funktionale Sicherheit von Fahrzeugen fest.
<G-vec00127-002-s519><define.festlegen><en> Together with them, we define the requirements and decide whether the tool is to be made in in-house tool making or externally.
<G-vec00127-002-s519><define.festlegen><de> Zusammen mit Ihnen legen wir die Anforderungen fest und entscheiden, ob das Werkzeug im hauseigenen Werkzeugbau oder extern gebaut wird.
<G-vec00127-002-s520><define.festlegen><en> Standards and regulations define the type and frequency of lab tests required to characterise the aggregates produced in terms of performance, thus dividing them into geometric, physical, chemical, durability and environmental test.
<G-vec00127-002-s520><define.festlegen><de> Bestimmungen Die Bestimmungen legen die Art und die Häufigkeit der Laborproben fest, die für die Charakterisierung der erzeugten Zuschlagstoffe erforderlich sind, und teilt sie dabei in geometrische, physikalische, chemische, zeitliche und umweltbezogene Untersuchungen ein.
<G-vec00127-002-s521><define.festlegen><en> With a double-click on the desired picture, you define this as the main picture.
<G-vec00127-002-s521><define.festlegen><de> Mit einem Doppelklick auf das gewünschte Bild legen Sie dieses als Hauptbild fest.
<G-vec00127-002-s522><define.festlegen><en> Font size — Define the font size that is used for web pages.
<G-vec00127-002-s522><define.festlegen><de> Schriftgröße — Legen Sie die Schriftgröße fest, die für Internetseiten verwendet werden soll.
<G-vec00127-002-s523><define.festlegen><en> Turn an estimate into a project, specify tasks and define goals, track the time and invoice it right away.
<G-vec00127-002-s523><define.festlegen><de> Machen Sie ein Angebot direkt zum Projekt, verteilen Sie Aufgaben und legen Sie Ziele fest, erfassen Sie geleistete Arbeitsstunden und stellen Sie diese gleich in Rechnung.
<G-vec00127-002-s524><define.festlegen><en> Simply define a logical view layer on top of your data vault data model, which allows users to execute queries using a classic 3NF/star schema.
<G-vec00127-002-s524><define.festlegen><de> Legen Sie dazu einfach einen logischen View Layer auf dem Data Vault Datenmodell an, der einen klassischen star/3NF Zugriff auf die Daten für die Anwender zur Verfügung stellt.
<G-vec00127-002-s525><define.festlegen><en> Define Linear, Custom or Scribble motion paths to completely control the way objects move.
<G-vec00127-002-s525><define.festlegen><de> Legen Sie lineare, benutzerdefinierte und Scribble-basierte Bewegungspfade fest, um Objektbewegungen zu steuern.
<G-vec00127-002-s526><define.festlegen><en> Define the right architecture for your Apama and webMethods environment.
<G-vec00127-002-s526><define.festlegen><de> Legen Sie die richtige Architektur für Ihre Apama- und webMethods-Umgebung fest.
<G-vec00127-002-s527><define.festlegen><en> Define in which status the task is at the moment.
<G-vec00127-002-s527><define.festlegen><de> Legen Sie, in welchem Status sich die Aufgabe derzeit befindet.
<G-vec00127-002-s528><define.festlegen><en> Define the font size of the title text.
<G-vec00127-002-s528><define.festlegen><de> Legen Sie die Schriftgröße der Titeltext.
<G-vec00127-002-s529><define.festlegen><en> Define the column name (which must be the same as the Emarsys field name to which it is mapped) for that field, then repeat for all the additional fields you want.
<G-vec00127-002-s529><define.festlegen><de> Legen Sie den Spaltennamen für das Feld fest (der dem zugewiesenen Emarsys-Feldnamen entsprechen muss) und wiederholen Sie diesen Vorgang für alle weiteren Felder.
<G-vec00127-002-s530><define.festlegen><en> Define a due date for the Runbook or Service.
<G-vec00127-002-s530><define.festlegen><de> Legen Sie ein Fälligkeitsdatum für das Runbook oder den Dienst fest.
<G-vec00127-002-s531><define.festlegen><en> Define the size of the “More” button.
<G-vec00127-002-s531><define.festlegen><de> Legen Sie die Größe der Schaltfläche "More".
<G-vec00127-002-s532><define.festlegen><en> Define a better business strategy with a tree diagram maker that’s accessible, collaborative, and easy to use.
<G-vec00127-002-s532><define.festlegen><de> Legen Sie eine bessere Geschäftsstrategie fest – mit einem Tool zur Erstellung von Baumdiagrammen, das leicht zugänglich, auf Zusammenarbeit ausgelegt und benutzerfreundlich ist.
<G-vec00127-002-s533><define.festlegen><en> Define the font size of the content for the header.
<G-vec00127-002-s533><define.festlegen><de> Legen Sie die Schriftgröße der Inhalte für die Kopfzeile.
<G-vec00127-002-s534><define.festlegen><en> Define your exit strategy and make your properties visible to suitable purchasers with strategic property marketing.
<G-vec00127-002-s534><define.festlegen><de> Legen Sie Ihre Exit-Strategie fest und machen Sie Ihre Objekte dank strategischer Immobilienvermarktung für geeignete Käufer sichtbar.
<G-vec00127-002-s535><define.festlegen><en> Define uniform quantitative and qualitative performance measures and key performance indicators and develop systems for company-wide uniform valuation bases.
<G-vec00127-002-s535><define.festlegen><de> Legen Sie einheitliche quantitative und qualitative Steuerungs- und Messgrößen fest und entwickeln Sie Systematiken für unternehmensweit einheitliche Bewertungsgrundlagen.
<G-vec00127-002-s536><define.festlegen><en> Now select the option «Standing approval» and then define the criteria for the standing approval.
<G-vec00127-002-s536><define.festlegen><de> Klicken Sie auf die Option «Dauerfreigabe» und legen Sie anschließend die Kriterien für die Dauerfreigabe fest.
<G-vec00127-002-s537><define.prägen><en> Our employees define the very nature of our company with their great ideas, drive and desire for continuous improvement.
<G-vec00127-002-s537><define.prägen><de> Unsere Mitarbeitenden prägen das Unternehmen mit guten Ideen, Tatkraft und dem Willen zur kontinuierlichen Verbesserung.
<G-vec00127-002-s538><define.prägen><en> Discover the unique history of Flagstaff on a fun and informational tour while learning about topics like the geological and cultural history of northern Arizona, the settlement of Flagstaff, and the early industries that define our town.
<G-vec00127-002-s538><define.prägen><de> Entdecken Sie die einzigartige Geschichte von Flagstaff auf einer unterhaltsamen und informativen Tour und erfahren Sie mehr über die geologische und kulturelle Geschichte des nördlichen Arizona, die Ansiedlung von Flagstaff und die frühen Industrien, die unsere Stadt prägen.
<G-vec00127-002-s539><define.prägen><en> The diverse combination of old and new trees, the well-sized pond landscaping, located in the club house area as well as stunning views of the Tyrolean mountain world define the golf course’s character.
<G-vec00127-002-s539><define.prägen><de> Der vielfältige alte und neue Baumbestand, die großzügig angelegte Teichlandschaft im Bereich um das Clubhaus sowie herrliche Ausblicke auf die Tiroler Bergwelt prägen den Charakter des Golfplatzes.
<G-vec00127-002-s540><define.prägen><en> Just like the previous year, Auriga kick-starts the new year with a list of 2020 trends, which we anticipate will define the banking sector in the upcoming 12 months.
<G-vec00127-002-s540><define.prägen><de> Wie letztes Jahr, veröffentlicht Auriga auch in diesem Jahr wieder einen Überblick über die Trends 2020, von denen wir glauben, dass sie das Bankwesen in den kommenden zwölf Monaten prägen werden.
<G-vec00127-002-s541><define.prägen><en> Digitalization, sustainability and urbanization will define the future of mobility.
<G-vec00127-002-s541><define.prägen><de> Digitalisierung, Nachhaltigkeit und Urbanisierung prägen die Mobilität der Zukunft.
<G-vec00127-002-s542><define.prägen><en> In this work, Herberstein wrote a sentence which was to define western concepts of Russia for centuries.
<G-vec00127-002-s542><define.prägen><de> Darin formulierte Herberstein einen Satz, der auf Jahrhunderte hinaus westliche Russlandvorstellungen prägen sollte.
<G-vec00127-002-s543><define.prägen><en> The Dolomites, a UNESCO natural heritage site, are the heart and horizon of our valley and define its character.
<G-vec00127-002-s543><define.prägen><de> Die Dolomiten, ein UNESCO-Naturerbe, sind das Herz und der Horizont unseres Tales und prägen seinen Charakter.
<G-vec00127-002-s544><define.prägen><en> Description Embroidered origami fishes define the original pattern of these BOSS swim shorts.
<G-vec00127-002-s544><define.prägen><de> Beschreibung Aufgestickte Origami-Fische prägen das originelle Muster der BOSS Badeshorts.
<G-vec00127-002-s545><define.prägen><en> The shimmering, slightly reflective dark blue to black surfaces of the solar modules define the elegant appearance of this wing.
<G-vec00127-002-s545><define.prägen><de> Die leicht reflektierenden dunkel-blau bis schwarz schimmernden Oberflächen der Solarmodule prägen die elegante Optik des Gebäudeflügels.
<G-vec00127-002-s546><define.prägen><en> Living share the company’s style and approach to design. Over the years Living Divani has developed a vast and varied offer in a gradual process of creation of a complete living environment, which revolves around the upholstery system, with its subtle shapes and proportions, enhanced by characterful complements - seats, armchairs, beds, tables, bookcases, carpets and the outdoor collection - that will suit and define any setting, from the essential and rigorous to the multifarious and eclectic décor.
<G-vec00127-002-s546><define.prägen><de> Im Laufe der Jahre entstand ein vielseitiges Angebot – Sofas, Polstersessel, Betten und Wohnaccessoires –, ein wachsender, kreativer und produktiver Prozess bis zu einem kompletten Wohnambiente, das sich rund um Polstermöbel mit diskreten Formen und Volumen entwickelt, ergänzt durch Accessoires von starkem Charakter - Sessel, Polstersessel und niedrige Tische - die sich gleichzeitig anpassen und den Raum prägen, von Modellen in essenziellen, rigorosen Formen bis zu stilistisch komplexen, dekorativen Einrichtungselementen.
<G-vec00127-002-s547><define.prägen><en> Commitment to research and innovation: We help define new generations of solutions based on scientific analysis and research, and on our broad experience with clients around the world.
<G-vec00127-002-s547><define.prägen><de> Engagement für Forschung und Innovation: Dank unserer wissenschaftlichen Analysen und Marktforschungen sowie unserer tiefgehenden Erfahrung mit Kunden aus aller Welt prägen wir künftige Generationen von Strategien und Lösungen.
<G-vec00127-002-s548><define.prägen><en> They serve as a guide for our actions, and define our company identity.
<G-vec00127-002-s548><define.prägen><de> Sie dienen uns als Handlungsorientierung und prägen unsere Unternehmensidentität.
<G-vec00127-002-s549><define.prägen><en> Quilted sleeve sections, distinctive zips and a buttoned band collar define the biker look of this BOSS jacket in a water-repellent fabric blend.
<G-vec00127-002-s549><define.prägen><de> Gesteppte Ärmelpartien, markante Reißverschlüsse und ein knöpfbarer Stehkragen prägen den Biker Look der BOSS Jacke aus einem wasserabweisenden Material-Mix.
<G-vec00127-002-s550><define.prägen><en> Churches of various confessions define the religious life of the town.
<G-vec00127-002-s550><define.prägen><de> Das religiöse Leben prägen Kirchen verschiedener Konfessionen in der Stadt.
<G-vec00127-002-s551><define.prägen><en> Minimalist design and natural materials define this retreat created by Tennent Brown in New Zealand.
<G-vec00127-002-s551><define.prägen><de> Reduziertes Design und Naturmaterialien prägen das Retreat des Architekturbüros Tennent Brown.
<G-vec00127-002-s552><define.prägen><en> Since 2011, Miu Miu has explored this point of view, commissioning short films directed by prominent and provocative female figures who define culture today.
<G-vec00127-002-s552><define.prägen><de> Seit 2011 beschäftigt sich Miu Miu mit diesem Thema und gibt Kurzfilme bei herausragenden und provokanten Regisseurinnen, die die heutige Kultur prägen, in Auftrag.
<G-vec00127-002-s553><define.prägen><en> There is a growing awareness that technology and automation will define the firm of the future and there are competitive advantages for early adopters.
<G-vec00127-002-s553><define.prägen><de> Infolgedessen wächst das Bewusstsein für Technologien und Automatisierung, da diese in Zukunft Unternehmen prägen und durch sie Wettbewerbsvorteile entstehen.
<G-vec00127-002-s554><define.prägen><en> Picturesque Ticinese villages, narrow mountain lanes and vast chestnut forests define the region, which is ideal for hiking and biking tours.
<G-vec00127-002-s554><define.prägen><de> Malerische Tessiner Dörfer, schmale Bergstrassen und ausgedehnte Kastanienwälder prägen die Region, die sich für Wanderungen und Bike-Touren bestens eignet.
<G-vec00127-002-s555><define.prägen><en> Thus Jesus' words and deeds already contained that which would later come to define Christian divine service: word and sacrament.
<G-vec00127-002-s555><define.prägen><de> So ist in Jesu Wort und Tat bereits angelegt, was den christlichen Gottesdienst prägen wird: Wort und Sakrament.
