<G-vec00518-002-s057><camp_out.campen><en> You can camp quietly in an alley or a field.
<G-vec00518-002-s057><camp_out.campen><de> Sie können ruhig an einem Weg campen oder auf einem Feld.
<G-vec00518-002-s058><camp_out.campen><en> Camp for €18,- a night at Naturist Camp Konobe in low season with CampingCard ACSI.
<G-vec00518-002-s058><camp_out.campen><de> Campen für €20,- pro Nacht auf Camping Bor in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s059><camp_out.campen><en> Camp for €19,- a night at Campsite La Gaviota in low season with CampingCard ACSI.
<G-vec00518-002-s059><camp_out.campen><de> Campen für €19,- pro Nacht auf Camping La Gaviota in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s060><camp_out.campen><en> Camp for €19,- a night at Safari Camping Rebild in low season with CampingCard ACSI.
<G-vec00518-002-s060><camp_out.campen><de> Campen für €19,- pro Nacht auf Safari Camping Rebild in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s061><camp_out.campen><en> Whether you want to camp with the children, enjoy taking your dog with you on holiday, or prefer the luxury and comfort of an accommodation, there is something for everyone at this campsite.
<G-vec00518-002-s061><camp_out.campen><de> Egal ob Sie mit den Kindern campen, Ihren Hund in den Urlaub mitbringen oder den Luxus und Komfort einer Unterkunft genießen möchten: Für jedermann gibt es etwas auf diesem Campingplatz.
<G-vec00518-002-s062><camp_out.campen><en> You can camp here in peace and enjoy the lovely nature of the area.
<G-vec00518-002-s062><camp_out.campen><de> Hier können Sie ungezwungen campen und die schöne Natur in der Umgebung genießen.
<G-vec00518-002-s063><camp_out.campen><en> If you have your own caravan or camper is possible to camp right next to one of the lakes where there is access to the
<G-vec00518-002-s063><camp_out.campen><de> Wenn Sie Ihren eigenen Wohnwagen oder Wohnmobil haben, ist es möglich direkt am See zu campen, wo es auch Bad/WC-Anlage und eine Außenküche gibt.
<G-vec00518-002-s064><camp_out.campen><en> With your CampingCard ACSI you can camp on one of the pitches during the following periods: 08/04 - 01/07 and 29/08 - 26/09.
<G-vec00518-002-s064><camp_out.campen><de> In der Nebensaison campen Sie in diesem Zeitraum 01/04 - 30/06 und 01/09 - 15/10 für €17,- pro Nacht auf einem der 88 Tourplätze auf Camping Les Calquières in Camping Les Calquières (Aveyron).
<G-vec00518-002-s065><camp_out.campen><en> Nick has a huge garage where we can screw and camp (according to Google translate) and we are glad that we have the new down mats and winter sleeping bag, in which we can snuggle.
<G-vec00518-002-s065><camp_out.campen><de> Nick hat eine riesige Garage, in der wir schrauben und campen können und wir sind froh, dass wir die neuen Daunenmatten und den Winterschlafsack haben, in den wir uns kuscheln können.
<G-vec00518-002-s066><camp_out.campen><en> Camp for €15,- a night at Camping & in low season with CampingCard ACSI.
<G-vec00518-002-s066><camp_out.campen><de> Campen für €15,- pro Nacht auf Camping & in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s067><camp_out.campen><en> Camp on a beautiful pitch in the heart of a magnificent woodland site, organised into terraces, and make the most of the fully renovated washrooms.
<G-vec00518-002-s067><camp_out.campen><de> Campen Sie auf wunderschönen Stellplätzen in Terrassenlage im Herzen eines herrlichen bewaldeten Naturgeländes und profitieren Sie von komplett renovierten Sanitäranlagen.
<G-vec00518-002-s068><camp_out.campen><en> Camp for €18,- a night at Resort Marina Oolderhuuske in low season with CampingCard ACSI.
<G-vec00518-002-s068><camp_out.campen><de> Campen für €18,- pro Nacht auf Resort Marina Oolderhuuske in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s069><camp_out.campen><en> Camp for €16,- a night at Campsite Le Soleil Levant in low season with CampingCard ACSI.
<G-vec00518-002-s069><camp_out.campen><de> Campen für €16,- pro Nacht auf Camping Le Soleil Levant in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s070><camp_out.campen><en> Camp for €18,- a night at Campsite Détente et Clapotis in low season with CampingCard ACSI.
<G-vec00518-002-s070><camp_out.campen><de> Campen für €18,- pro Nacht auf Camping Détente et Clapotis in der Nebensaison mit Jahresplätzen.
<G-vec00518-002-s071><camp_out.campen><en> Camp with your own equipment on a beautiful flat pitch in the shade of the pine forest or the banks of the river.
<G-vec00518-002-s071><camp_out.campen><de> Campen Sie mit Ihrer Campingausrüstung auf wunderschönen ebenen Stellplätzen im Schatten des Kiefernwaldes oder am Flussufer.
<G-vec00518-002-s072><camp_out.campen><en> You camp here in the north of Slovenia.
<G-vec00518-002-s072><camp_out.campen><de> Sie campen hier im Norden Sloweniens.
<G-vec00518-002-s073><camp_out.campen><en> Camp for €20,- a night at Moselcamping Rissbach in low season with CampingCard ACSI.
<G-vec00518-002-s073><camp_out.campen><de> Campen für €20,- pro Nacht auf Moselcamping Rissbach in der Nebensaison mit der CampingCard ACSI.
<G-vec00518-002-s074><camp_out.campen><en> One of the most important changes here is to know, as of 2015, it is illegal to camp in tents, trailers, caravans, campervans, or anything of the like, outside of a designated campsite UNLESS there is written permission from the landowner.
<G-vec00518-002-s074><camp_out.campen><de> In den drei Nationalparks von Island ist wildes Campen komplett illegal, genauso ist es dort illegal, in Zelten, Anhängern, Wohnwagen, Campervans oder Ähnlichem außerhalb eines ausgewiesenen Campingplatzes zu campen.
<G-vec00518-002-s075><camp_out.campen><en> It is the ideal accommodation for the basic camper or for the extra guests who no longer fits into the touring caravan but still want to camp comfortably.
<G-vec00518-002-s075><camp_out.campen><de> Es ist die ideale Unterkunft für den Basiscamper oder für die zusätzlichen Gäste, die nicht mehr in den Wohnwagen passen, aber trotzdem bequem campen möchten.
<G-vec00518-002-s380><camp_out.zelten><en> We couldn't camp there.
<G-vec00518-002-s380><camp_out.zelten><de> Wir konnten da nicht zelten.
<G-vec00518-002-s381><camp_out.zelten><en> In summer, guests can also camp.
<G-vec00518-002-s381><camp_out.zelten><de> Im Sommer können die Gäste auch zelten.
<G-vec00518-002-s382><camp_out.zelten><en> Around twenty of them were arrested that night and another score decided to camp overnight at the Puerta del Sol in Madrid to express their solidarity with those arrested and demand their release.
<G-vec00518-002-s382><camp_out.zelten><de> In dieser Nacht wurden 20 Personen festgenommen und weitere zwanzig entschieden, auf dem Platz „Puerta del Sol” in Madrid zu zelten, um ihre Solidarität mit den Festgenommenen zu demonstrieren und ihre sofortige Freilassung zu fordern.
<G-vec00518-002-s383><camp_out.zelten><en> We wanted to be back on the bikes, camp in a field, feel the wind and not have a clue what he day would bring.
<G-vec00518-002-s383><camp_out.zelten><de> Wir wollen radeln, irgendwo zelten, den Wind fühlen und morgens nicht wissen, was der Abend bringt.
<G-vec00518-002-s384><camp_out.zelten><en> I really was not too surprised when revival came, beginning suddenly at a summer camp in the late 1960s.
<G-vec00518-002-s384><camp_out.zelten><de> Ich war also wirklich nicht überrascht als die Erweckung kam, vorerst plötzlich beim Zelten im Sommer in den späten 60er Jahren.
<G-vec00518-002-s385><camp_out.zelten><en> They told me I could not camp here, it would be to dangerous.
<G-vec00518-002-s385><camp_out.zelten><de> Ich könne hier nicht zelten, es sei zu gefährlich.
<G-vec00518-002-s386><camp_out.zelten><en> Camp overnight at Hamilton Downs Youth Camp.
<G-vec00518-002-s386><camp_out.zelten><de> Zelten Sie anschließend im Hamilton Downs Youth Camp.
<G-vec00518-002-s387><camp_out.zelten><en> If you decide to stay and camp out, dive in and wait for the sun to set.
<G-vec00518-002-s387><camp_out.zelten><de> Tauchen Sie ein und warten Sie, bis die Sonne untergeht, wenn Sie beschließen, zum Zelten hier zu bleiben.
<G-vec00518-002-s388><camp_out.zelten><en> Or you can camp under the open sky.
<G-vec00518-002-s388><camp_out.zelten><de> Oder du kannst unter freiem Himmel zelten.
<G-vec00518-002-s389><camp_out.zelten><en> Three young policemen let me camp with them and invited me to dinner.
<G-vec00518-002-s389><camp_out.zelten><de> Drei junge Polizisten ließen mich bei ihnen zelten und luden mich zum Essen ein.
<G-vec00518-002-s390><camp_out.zelten><en> With a camping tent from Ranger it is easy to go far and be able to camp near the sites, you want to enjoy – the beach, the forest, and the mountains.
<G-vec00518-002-s390><camp_out.zelten><de> Mit einem Campingzelt von Ranger können Sie leicht auf die Reise gehen und nahe den gewünschten Plätzen zelten – dem Strand, dem Wald und den Bergen.
<G-vec00518-002-s391><camp_out.zelten><en> In the afternoon, the trainers of Burghausen and Mannheim arrived to camp with us.
<G-vec00518-002-s391><camp_out.zelten><de> Am Nachmittag reisten die Ausbilder aus Burghausen und Mannheim an, um die Nacht mit uns zusammen beim Zelten zu verbringen.
<G-vec00518-002-s392><camp_out.zelten><en> We also repeat our offer for full cooperation, in case we can finally move people over to better housing and stop creating problems artificially, which come along with building a camp in a developed country like Greece.
<G-vec00518-002-s392><camp_out.zelten><de> Wir wiederholen unsere Bereitschaft zur Kooperation, wenn die Leute endlich in Behausungen untergebracht werden, die diesen Namen auch verdienen und wir aufhören, Probleme zu erschaffen, die entstehen, wenn man in einem entwickelten Land wie Griechenland anfängt, Menschen in Zelten unterzubringen.
<G-vec00518-002-s393><camp_out.zelten><en> One can also camp out and run around.
<G-vec00518-002-s393><camp_out.zelten><de> Man kann hier auch zelten und toben.
<G-vec00518-002-s394><camp_out.zelten><en> You can pick mushrooms and berries, camp and make a campfire but don’t leave any traces behind.
<G-vec00518-002-s394><camp_out.zelten><de> Sie dürfen Pilze und Beeren sammeln, einen Tag zelten und ein Lagerfeuer machen, aber denken Sie daran, keine Spuren zu hinterlassen.
<G-vec00518-002-s395><camp_out.zelten><en> We are twice pleased: On the one hand, of course that we must camp with rain not outdoors and have got to know nice people, but on the other hand also that the employees with such a big project not only get on as half a sheriffs but also still are extremely nicely and hilfsbereits.
<G-vec00518-002-s395><camp_out.zelten><de> Wir freuen uns doppelt: Zum einen natürlich, daß wir bei Regen nicht draußen zelten müssen und nette Leute kennen gelernt haben, aber zum anderen auch, daß die Mitarbeiter bei einem so großen Projekt sich nicht nur als halbe Sheriffs verstehen sondern auch noch außergewöhnlich nett und hilfsbereits sind.
<G-vec00518-002-s396><camp_out.zelten><en> Right away I got a great place to camp: sheltered and away from the road.
<G-vec00518-002-s396><camp_out.zelten><de> Ich bekam gleich dort einen fantastischen Platz unter einem Dach, abseits der Straße, zum Zelten.
<G-vec00518-002-s397><camp_out.zelten><en> The wooden houses are equipped well, in summer time you can just camp outside.
<G-vec00518-002-s397><camp_out.zelten><de> Gemütlich eingerichtet sind die kleinen Holzhäuser.Im Sommer kann man sich beim Zelten erholen.
<G-vec00518-002-s398><camp_out.zelten><en> Why not take a canoe for a stay of 2 to 7 days and camp along the way.
<G-vec00518-002-s398><camp_out.zelten><de> Etappenwanderungen Brechen Sie im Kanu zu einem Urlaub von 2 bis 7 Tagen auf und zelten Sie entlang der Fahrtstrecke.
