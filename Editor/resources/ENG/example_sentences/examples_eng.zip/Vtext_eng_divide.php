<G-vec00296-002-s417><divide.(sich)_teilen><en> If you divide the position “current expenses” by about 6 kitten in a year, you’ll already get 920,00 €.
<G-vec00296-002-s417><divide.(sich)_teilen><de> Teilt man die Position “laufende Kosten” durch etwa 6 Katzenbabies im Jahr, kommt man bereits auf knapp 920,00 €.
<G-vec00296-002-s418><divide.(sich)_teilen><en> The client then works in tandem with the Speed Server to intelligently divide your Internet traffic and deliver the combined speed of all available Internet connections.
<G-vec00296-002-s418><divide.(sich)_teilen><de> Der Client arbeitet dann mit dem Speed-Server zusammen, teilt Ihren Internet Traffic intelligent auf und stellt die kombinierte Geschwindigkeit aller verfügbaren Internetverbindungen zur Verfügung.
<G-vec00296-002-s419><divide.(sich)_teilen><en> If, therefore, you divide 1000 mm by the number of holes, you will know the mesh width.
<G-vec00296-002-s419><divide.(sich)_teilen><de> Teilt man also 1000 mm durch die Anzahl der Maschen, ergibt sich die Maschenbreite.
<G-vec00296-002-s420><divide.(sich)_teilen><en> You divide up the day how you want, and feel free to share ideas with people in the office who are not part of your own department.
<G-vec00296-002-s420><divide.(sich)_teilen><de> Man teilt den Tag nach eigenen Vorstellungen ein und fühlt sich frei, auch mit Kollegen aus anderen Abteilungen Ideen auszutauschen.
<G-vec00296-002-s421><divide.(sich)_teilen><en> They revolutionise the principles of baking and dough processing because they divide as well as shape (or "mould") the dough balls, all in one machine. They replace a divider and a moulder (please refer to "divider-shapers" in the machine range).
<G-vec00296-002-s421><divide.(sich)_teilen><de> Dieses Gerät hat das Prinzip der Brotherstellung und der Teigverarbeitung revolutioniert, denn es teilt und formt (oder "wirkt") die Teiglinge mit nur einer Maschine.Es ersetzt einen Teiler und eine Wirkmaschine in der Maschinen-Produktpalette.
<G-vec00296-002-s422><divide.(sich)_teilen><en> Divide ye like your enemies, in Houses, and lay your laws in set sequence from the center, again like the enemy Corners of the House of Troubles, and see yourself thence as timber, or mud-slats, or sheets of resin.
<G-vec00296-002-s422><divide.(sich)_teilen><de> Teilt euch auf, wie eure Feinde, in Häuser, und legt eure Gesetze in einer Ordnung, vom Zentrum ausgehend, fest, wieder wie die feindlichen Ecken des Hauses der Sorgen, und seht euch selbst daher als Bauholz, oder Lehmziegel oder Schichten aus Harz.
<G-vec00296-002-s423><divide.(sich)_teilen><en> Important for you: a&o will gladly divide the rooms up for you – profit from our experience.
<G-vec00296-002-s423><divide.(sich)_teilen><de> Wichtig für Sie: a&o teilt gern Zimmer für Sie zu – Profitieren Sie von unserer Erfahrung.
<G-vec00296-002-s424><divide.(sich)_teilen><en> Each car will divide after hit - unless it will be as small as possible.
<G-vec00296-002-s424><divide.(sich)_teilen><de> Jedes Auto teilt nach Hit - es sei denn, es wird so klein wie möglich.
<G-vec00296-002-s425><divide.(sich)_teilen><en> The Engagement Rate is calculated by taking the total PTAT (people talking about this) and divide by the total number of likes.
<G-vec00296-002-s425><divide.(sich)_teilen><de> Engagementgrad: 0.07% Die Engagementrate wird berechnet, indem man den PTAT (people talking about this) durch die Anzahl an Likes teilt.
<G-vec00296-002-s426><divide.(sich)_teilen><en> APLUS will detect crossing points and divide the line into separate dimension lines.
<G-vec00296-002-s426><divide.(sich)_teilen><de> APLUS erkennt die Schnittpunkte und teilt die Linie in einzelne Bemaßungslinien.
<G-vec00296-002-s427><divide.(sich)_teilen><en> The Immigration Service does not divide people into groups based on religion or ethnicity, which means that people from different sides of a conflict may end up living together.
<G-vec00296-002-s427><divide.(sich)_teilen><de> Die Zuwanderungsbehörde teilt Menschen nicht auf Grund von Religion oder Ethnie in Gruppen ein, was bedeutet, dass es vorkommen kann, dass Menschen aus verschiedenen Seiten eines Konflikts zusammen leben müssen.
<G-vec00296-002-s428><divide.(sich)_teilen><en> Please divide the minutes by 60, and format cells to display numbers with 2 decimals.
<G-vec00296-002-s428><divide.(sich)_teilen><de> Bitt teilt dafür die Minuten durch 60 und formatiert die Zelle als Ziffer mit zwei Dezimalstellen.
<G-vec00296-002-s429><divide.(sich)_teilen><en> But if you divide the tunnel into two halves and design each section completely differently, the tiled wall part can suddenly enhance the whole space to the extent that it becomes delightful.
<G-vec00296-002-s429><divide.(sich)_teilen><de> Doch wenn man den Tunnel in zwei Hälften teilt und komplett anders gestaltet, erfährt der keramische Wandteil plötzlich eine Aufwertung, der wir uns sogar erfreuen können.
<G-vec00296-002-s430><divide.(sich)_teilen><en> Benjamin shall ravin [as] a wolf: in the morning he shall devour the prey, and at night he shall divide the spoil.
<G-vec00296-002-s430><divide.(sich)_teilen><de> 27 Benjamin ist ein reißender Wolf: / Am Morgen frisst er die Beute, / am Abend teilt er den Fang.
<G-vec00296-002-s431><divide.(sich)_teilen><en> If you divide a country along linguistic lines, you have to take into account, that there are areas of mixed language that do not fit into your scheme.
<G-vec00296-002-s431><divide.(sich)_teilen><de> Teilt man ein Land entlang sprachlicher Linien, so muss man berücksichtigen, daß es gemischtsprachige Gebiete gibt, die nicht in so ein Schema passen.
<G-vec00296-002-s432><divide.(sich)_teilen><en> The analysis will divide the area to be lit into specific zones to determine where the luminaires and the sensors should be installed.
<G-vec00296-002-s432><divide.(sich)_teilen><de> Diese Analyse teilt die Fläche in einzelne Zonen auf um zu bestimmen, wie viele Leuchten wo installiert werden sollten.
<G-vec00296-002-s433><divide.(sich)_teilen><en> You simply divide it with the fork!
<G-vec00296-002-s433><divide.(sich)_teilen><de> Man teilt ihn schlicht mit der Gabel.
<G-vec00296-002-s434><divide.(sich)_teilen><en> Sometimes the larger kitchen will divide the kitchen into a cooking area and a preparation area, so that kitchen cooking can be performed better, and the operating people do not interfere with each other.
<G-vec00296-002-s434><divide.(sich)_teilen><de> Manchmal teilt die größere Küche die Küche in einen Kochbereich und einen Vorbereitungsbereich auf, so dass das Kochen in der Küche besser durchgeführt werden kann und sich die Bedienungspersonen nicht gegenseitig behindern.
<G-vec00296-002-s435><divide.(sich)_teilen><en> In the 7 questions version of the game, you just divide the questions between the players.
<G-vec00296-002-s435><divide.(sich)_teilen><de> In der 7-Fragen-Variante des Spiels, teilt ihr die 21 Fragen einfach zwischen den Spielern auf.
<G-vec00296-002-s057><divide.aufteilen><en> This simply means that water will divide (dissociate)into these two components.
<G-vec00296-002-s057><divide.aufteilen><de> Dies bedeutet einfach, dass Wasser sich in diese beiden Komponenten aufteilt (disoziiert).
<G-vec00296-002-s058><divide.aufteilen><en> For larger rounds it is particularly fun, if you divide into the individual houses and each house must drink in certain scenes.
<G-vec00296-002-s058><divide.aufteilen><de> Für größere Runden macht es besonders Spaß, wenn ihr euch in die einzelnen Häuser aufteilt und jedes Haus bei gewissen Szenen trinken muss.
<G-vec00296-002-s059><divide.aufteilen><en> User groups are groups of users that divide the community into manageable sections administrators can work with.
<G-vec00296-002-s059><divide.aufteilen><de> Benutzergruppen sind Gruppen von Mitgliedern, die die Mitglieder des Boards in für die Board-Administration verwaltbare Einheiten aufteilt.
<G-vec00296-002-s060><divide.aufteilen><en> When hunt- ing, the pod will divide into several small groups.
<G-vec00296-002-s060><divide.aufteilen><de> Seine Jagdtechnik besteht im Aufspüren von Fischschwärmen, wobei eine Schule sich in Gruppen aufteilt.
<G-vec00296-002-s061><divide.aufteilen><en> To add support for an extra monitor without adding or replacing a graphics card, you can use Matrox Graphics eXpansion Modules (GXMs)—small, external boxes that connect to the monitor connector of your computer and divide the signal for two or three separate monitors.
<G-vec00296-002-s061><divide.aufteilen><de> Upgraden von Laptops für Mehrfach-Display Damit ein zusätzlicher Monitor unterstützt wird, ohne eine Grafikkarte hinzuzufügen, können Sie Matrox Grafik-Erweiterungsmodule (GXMs) verwenden – kleine, externe Kästen, die an den Monitoranschluss Ihres Computers angeschlossen werden und das Signal für zwei oder drei separate Monitore aufteilt.
<G-vec00296-002-s089><divide.austeilen><en> 6Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.
<G-vec00296-002-s089><divide.austeilen><de> Denn du sollst diesem Volk das Land zum Erbe austeilen, das zu geben ich ihren Vätern geschworen habe.
<G-vec00296-002-s090><divide.austeilen><en> And ye shall divide this land unto you according to the tribes of Israel.
<G-vec00296-002-s090><divide.austeilen><de> 21 Also sollt ihr das Land austeilen unter die Stämme Israels.
<G-vec00296-002-s091><divide.austeilen><en> So shall you divide this land to you according to the tribes of Israel.
<G-vec00296-002-s091><divide.austeilen><de> Also sollt ihr das Land austeilen unter die Stämme Israels.
<G-vec00296-002-s092><divide.austeilen><en> 14 "You shall divide it for an inheritance, each one equally with the other; for I swore to give it to your forefathers, and this land shall fall to you as an inheritance.
<G-vec00296-002-s092><divide.austeilen><de> 47:14 Und ihr sollt's gleich austeilen, einem wie dem andern; denn ich habe meine Hand aufgehoben, das Land euren Vätern und euch zum Erbteil zu geben.
<G-vec00296-002-s093><divide.austeilen><en> 13: Thus says the Lord GOD: "These are the boundaries by which you shall divide the land for inheritance among the twelve tribes of Israel. Joseph shall have two portions.
<G-vec00296-002-s093><divide.austeilen><de> 13So spricht Gott, der HERR: Das ist die Grenze, innert welcher ihr den zwölf Stämmen Israels das Land zum Erbe austeilen sollt; dem Joseph gehören zwei Lose.
<G-vec00296-002-s094><divide.austeilen><en> 34:17 These are the names of the men that shall divide the land unto you for inheritance: Eleazar the priest, and Joshua the son of Nun.
<G-vec00296-002-s094><divide.austeilen><de> 34:17 Das sind die Namen der Männer, die euch das Land als Erbe austeilen sollen: der Priester Eleasar und Josua, der Sohn des Nun.
<G-vec00296-002-s095><divide.austeilen><en> This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord Jehovah.
<G-vec00296-002-s095><divide.austeilen><de> Das ist das Land, das ihr austeilen sollt zum Erbteil unter die Stämme Israels; und das sollen ihre Erbteile sein, spricht der HERR HERR.
<G-vec00296-002-s096><divide.austeilen><en> Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.
<G-vec00296-002-s096><divide.austeilen><de> Sei getrost und unverzagt; denn du sollst diesem Volk das Land austeilen, das ich ihren Vätern geschworen habe, daß ich's ihnen geben wollte.
<G-vec00296-002-s097><divide.austeilen><en> This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord GOD.
<G-vec00296-002-s097><divide.austeilen><de> Das ist das Land, das ihr austeilen sollt zum Erbteil unter die Staemme Israels; und das sollen ihre Erbteile sein, spricht der HERR HERR.
<G-vec00296-002-s098><divide.austeilen><en> 47:13Thus saith the Lord Jehovah: This shall be the border, whereby ye shall divide the land for inheritance according to the twelve tribes of Israel: Joseph shall have two portions.
<G-vec00296-002-s098><divide.austeilen><de> 13 So spricht der Herr HERR: Dies sind die Grenzen, nach denen ihr das Land sollt austeilen den zwölf Stämmen Israels; denn zwei Teile gehören dem Stamm Joseph.
<G-vec00296-002-s099><divide.austeilen><en> 6 Be strong and 'quit thyself like a man, for thou shalt divide the land to this people, which I sware to give to † your fathers.
<G-vec00296-002-s099><divide.austeilen><de> 6 Sei getrost und unverzagt; denn du sollst diesem Volk das Land austeilen, das ich ihren Vätern geschworen habe, daß ich's ihnen geben wollte.
<G-vec00296-002-s100><divide.austeilen><en> 16 Though he heap up silver as the dust, and prepare clothing as the clay; 17 He may prepare it, but the just shall put it on; and the innocent shall divide the silver.
<G-vec00296-002-s100><divide.austeilen><de> 16 Wenn er Geld zusammenbringt wie Staub und sammelt Kleider wie Lehm, 17 so wird er es wohl bereiten; aber der Gerechte wird es anziehen, und der Unschuldige wird das Geld austeilen.
<G-vec00296-002-s101><divide.austeilen><en> Ben Iamin is a ravishing wolf. In the morning he shall devour his prey, and at night he shall divide his spoil.
<G-vec00296-002-s101><divide.austeilen><de> 27Benjamin ist ein reißender Wolf; des Morgens wird er Raub fressen, aber des Abends wird er den Raub austeilen.
<G-vec00296-002-s102><divide.austeilen><en> 28 Command Josue, and encourage and strengthen him: for he shall go before this people, and shall divide unto them the land which thou shalt see.
<G-vec00296-002-s102><divide.austeilen><de> Und gebiete dem Josua, daß er getrost und unverzagt sei; denn er soll über den Jordan ziehen vor dem Volk her und soll ihnen das Land austeilen, das du sehen wirst.
<G-vec00296-002-s147><divide.dividieren><en> Divide your annual gross income by 12 to determine your average monthly income.
<G-vec00296-002-s147><divide.dividieren><de> Dividiere dein jährliches Bruttoeinkommen durch 12, um dein durchschnittliches monatliches Einkommen zu bestimmen.
<G-vec00296-002-s148><divide.dividieren><en> Add the last number of the fourth marker and divide the result by the top number on the first marker from the bottom.
<G-vec00296-002-s148><divide.dividieren><de> Addiere dazu die unterste Zahl auf dem vierten Schild von oben und dividiere das ganze durch die oberste Zahl auf dem ersten Schild von unten.
<G-vec00296-002-s149><divide.dividieren><en> Convert the first letter into a number (A=1, B=2...), divide it by 2 in oder to derive G.
<G-vec00296-002-s149><divide.dividieren><de> Wandle den ersten Buchstaben in eine Zahl (A=1, B=2,...) um, dividiere sie durch 2 um G zu erhalten.
<G-vec00296-002-s150><divide.dividieren><en> 1 Divide your monthly debt by your monthly income.
<G-vec00296-002-s150><divide.dividieren><de> 1 Dividiere deine monatlichen Schulden durch dein monatliches Einkommen.
<G-vec00296-002-s151><divide.dividieren><en> Divide the distance by 4 and write the number down as G.
<G-vec00296-002-s151><divide.dividieren><de> Dividiere die Wegstrecke durch 4 und notiere dir die Zahl als G.
<G-vec00296-002-s181><divide.einteilen><en> It is best to divide your expenses into categories, and list the total amount spent per category.
<G-vec00296-002-s181><divide.einteilen><de> Es ist das Beste, deine Ausgaben in Kategorien einzuteilen und die Gesamtausgaben pro Kategorie anzugeben.
<G-vec00296-002-s182><divide.einteilen><en> They used their powers to form the five elements (metal, wood, water, fire, and earth), establish five seasons (spring, fall, winter, summer, and late summer), and divide the world into five regions (north, south, east, west, and center).
<G-vec00296-002-s182><divide.einteilen><de> Sie setzten ihre Kräfte ein, um die fünf Elemente hervorzubringen (Metall, Holz, Wasser, Feuer und Erde) und die fünf Jahreszeiten zu erschaffen (Frühling, Herbst, Winter, Sommer und Spätsommer), und die Welt in fünf Regionen einzuteilen (Norden, Süden, Osten, Westen und die Mitte).
<G-vec00296-002-s183><divide.einteilen><en> All editors of ASA Maestro provide a customizable ability to divide text into logical parts (regions).
<G-vec00296-002-s183><divide.einteilen><de> Alle Editoren von MS SQL Maestro ermöglichen den Text in logische Teile einzuteilen.
<G-vec00296-002-s184><divide.einteilen><en> It would be a mistake to divide the history of the Arctic simply into two periods, before and after the arrival of the Europeans.
<G-vec00296-002-s184><divide.einteilen><de> Es wäre falsch, die geschichtliche Entwicklung der Arktis in nur zwei Zeiträume einzuteilen, vor und nach dem Eindringen der Europäer.
<G-vec00296-002-s185><divide.einteilen><en> To divide my everyday life into time for duty and time for seeing is the wrong approach.
<G-vec00296-002-s185><divide.einteilen><de> Meinen Alltag einzuteilen in Zeit für Pflicht und Zeit für Sehen ist der falsche Ansatz.
<G-vec00296-002-s186><divide.einteilen><en> Please note: It's not an easy task to divide the catalog into categories.
<G-vec00296-002-s186><divide.einteilen><de> Bitte beachten Sie, dass es nur schwer möglich ist, den Katalog in Kategorien einzuteilen.
<G-vec00296-002-s187><divide.einteilen><en> Since the animals do not care about administrative borders determined by humans, it makes sense to divide the animals into biological units, so-called populations.
<G-vec00296-002-s187><divide.einteilen><de> Da Tiere sich nicht um die administrativen Grenzen des Menschen kümmern, ist es sinnvoll die Bestände in biologische Einheiten, die Populationen, einzuteilen.
<G-vec00296-002-s188><divide.einteilen><en> De prime abord, I do not proceed from “concepts,” hence neither from the “concept of value,” and am therefore in no way concerned to “divide” it.
<G-vec00296-002-s188><divide.einteilen><de> De prime abord gehe ich nicht aus von „Begriffen“, also auch nicht vom „Wertbegriff“, und habe diesen daher auch in p. 369keiner Weise „einzuteilen“.
<G-vec00296-002-s189><divide.einteilen><en> In the Winter, the Lech Ski School offers a special treat for our young guests: up to 14 years of age everyone can be taken and picked up just paying child’s fare, and depending on the car rental, an attempt is made to divide teen groups so that everyone can enjoy them
<G-vec00296-002-s189><divide.einteilen><de> Im Winter bietet die Skischule Lech für unsere jungen Gäste ein besonderes Zuckerl: bis 14 Jahre fahren alle zum Kindertarif und je nach Fahrkönnen wird versucht, Teenie-Gruppen einzuteilen, damit es auch allen mehr Spaß macht.
<G-vec00296-002-s190><divide.entzweien><en> Abandoning malicious speech, he abstains from malicious speech; he does not repeat elsewhere what he has heard here in order to divide [those people] from these, nor does he repeat to these people what he has heard elsewhere in order to divide [these people] from those; thus he remains one who reunites those who are divided, a promoter of friendships, who enjoys concord, rejoicrs in concord, delights in concord, a speaker of words that promote concord.
<G-vec00296-002-s190><divide.entzweien><de> Er enthält sich davon, gehässig zu sprechen, indem er es aufgegeben hat, gehässig zu sprechen; er verbreitet nicht woanders, was er hier gehört hat, um jene Menschen von den Menschen hier zu entzweien, auch verbreitet er nicht hier, was er woanders gehört hat, um diese Menschen von jenen Menschen dort zu entzweien; somit ist er einer, der diejenigen vereint, die vorher entzweit waren, einer, der Freundschaft fördert, Eintracht genießt, sich über Eintracht freut, an Eintracht Entzücken findet, jemand, der Worte äußert, die Eintracht säen.
<G-vec00296-002-s191><divide.entzweien><en> Dogmas divide, but living faith connects.
<G-vec00296-002-s191><divide.entzweien><de> Dogmen entzweien, gelebter Glaube aber verbindet.
<G-vec00296-002-s192><divide.entzweien><en> Obviously there are a lot of possible reasons, and while we should not divide over secondary issues, both sides agree that we must divide when it comes to primary issues.
<G-vec00296-002-s192><divide.entzweien><de> Offensichtlich gibt es viele Gründe, und während wir uns nicht wegen sekundärer Themen spalten sollten, so stimmen doch beide Seiten überein, das wir uns entzweien müssen, wenn es um elementare Fragen geht.
<G-vec00296-002-s193><divide.entzweien><en> Out of the Darkness will come the Light, you will see your fellow human beings and you will realise that what divides you was falsely placed there to divide you and give them excuses to go to War.
<G-vec00296-002-s193><divide.entzweien><de> Aus der Dunkelheit wird das Licht kommen, ihr werdet eure Mitmenschen sehen und erkennen, dass das was euch voneinander unterscheidet, fälschlicherweise zwischen euch aufgebaut wurde, um euch zu entzweien und ihnen einen Grund für Krieg zu geben.
<G-vec00296-002-s210><divide.gliedern><en> Twelve-tone scale and twelve-color circle are similar, both divide the octave space into 12 steps.
<G-vec00296-002-s210><divide.gliedern><de> Zwölftonleiter und Zwölffarbenkreis sind gleichartig, beide gliedern den Oktavraum in 12 Stufen.
<G-vec00296-002-s211><divide.gliedern><en> Now we are able to divide a space, open it up and join it with the landscape, so that we may fulfil the spatial needs of modern man.
<G-vec00296-002-s211><divide.gliedern><de> Erst jetzt kann man den Raum gliedern, öffnen und mit der Landschaft verbinden, um das Raumbedürfnis des heutigen Menschen zu erfüllen.
<G-vec00296-002-s212><divide.gliedern><en> Vertical window panels divide up the facade; the chimney lies right in the line of vision when looking down the pathway.
<G-vec00296-002-s212><divide.gliedern><de> Vertikale Fensterstreifen gliedern die Fassade, der Kamin liegt genau in der Blickachse der Erschließung.
<G-vec00296-002-s213><divide.gliedern><en> The appended narrow elements divide the room without encroaching on the living space.
<G-vec00296-002-s213><divide.gliedern><de> Die angehängten, filigran anmutenden Elemente gliedern den Raum, ohne die Wohnfläche zu beinträchtigen.
<G-vec00296-002-s214><divide.gliedern><en> The support frame, which is visible from outside, and the displayed intermediate lesenes divide the facade, which comes across as something between tectonic plates and an abstract grid.
<G-vec00296-002-s214><divide.gliedern><de> Das außen sichtbare Tragskelett und die dazwischen abgebildeten Lisenen gliedern die Fassade, die einen Zustand zwischen Tektonik und abstraktem Gitter vermittelt.
<G-vec00296-002-s215><divide.gliedern><en> Production part PREFA invest, a.s. we can divide into the basic segments: production and extraction of aggregates, production and sale of transport concrete, prefabricated custom construction, tubing and shaft program, concrete paving and bricks, commercial prefabricated.
<G-vec00296-002-s215><divide.gliedern><de> Produktionsteil PREFA invest, a.s. Wir können uns in die grundlegenden Segmente gliedern: Produktion und Gewinnung von Zuschlagstoffen, Herstellung und Verkauf von Transportbeton, vorgefertigte Spezialkonstruktion, Rohr- und Schachtprogramm, Betonpflaster und Ziegel, Fertigteilgewerbebau.
<G-vec00296-002-s216><divide.gliedern><en> Garden paths not only divide the site into zones, but also give it a neat, neat appearance.
<G-vec00296-002-s216><divide.gliedern><de> Gartenwege gliedern das Gelände nicht nur in Zonen, sondern geben ihm auch eine gepflegte, gepflegte Erscheinung.
<G-vec00296-002-s217><divide.gliedern><en> Sub-forms are used to divide a lengthy form into several logically connected portions.
<G-vec00296-002-s217><divide.gliedern><de> Subformulare eignen sich dazu, sehr lange Formulare in mehrere logisch zusammenhängende Blöcke zu gliedern.
<G-vec00296-002-s218><divide.gliedern><en> The two huge rod-shaped building elements divide the complex into a studio and workshop stage, a large hall and a stage at the lakeside.
<G-vec00296-002-s218><divide.gliedern><de> Die beiden überdimensionalen stabförmigen Gebäudeelemente gliedern den Komplex in Studio- und Werkstattbühne, Großer Saal und Seetribüne.
<G-vec00296-002-s219><divide.gliedern><en> Large shelve elements satisfy the extensive need for storage room and divide the open-space into smaller, yet fully interconnected units of communicative work.
<G-vec00296-002-s219><divide.gliedern><de> Sehr große Stauraumanforderungen wurden übersetzt in Regalelemente, die den Raum gliedern und kleinere Einheiten entstehen lassen, gleichzeitig aber auch kommunikatives Arbeiten ermöglichen.
<G-vec00296-002-s220><divide.gliedern><en> The myth rooms tell the story of the Mercedes-Benz brand and divide them into themes and epochs.
<G-vec00296-002-s220><divide.gliedern><de> Die Mythosräume erzählen die Geschichte der Marke Mercedes-Benz und gliedern sie in Themen und Epochen.
<G-vec00296-002-s221><divide.gliedern><en> Additionally, you can then divide your services into different categories.
<G-vec00296-002-s221><divide.gliedern><de> Ihre Leistungen können Sie dann zusätzlich in unterschiedliche Kategorien gliedern.
<G-vec00296-002-s222><divide.gliedern><en> In this way we succeed in surveying into the field belonging to the Spirits of Form and as abnormal Spirits of Form to bear one humanity, and that the belated Spirits of Motion enter into the field belonging to the Spirits of Form and as abnormal Spirits of Form divide up all humanity upon the globe into the several races.
<G-vec00296-002-s222><divide.gliedern><de> Wir gewinnen dadurch die Urnschau 'über den ganzen Erdenplaneten, finden den Erdenplaneten dazu bestimmt, eine Menschheit zu tragen durch die normalen Geister der Form, finden, daß sich die zurückgebliebenen Geister der Bewegung in dieses Terrain der Geister der Form hineinbegeben und als abnorme Geister der Form das Menschentum auf dem ganzen Erdenrund in die einzelnen Rassen gliedern.
<G-vec00296-002-s223><divide.gliedern><en> In order to divide the room visually and functionally, we use combinations of straight and curved elements, creating lines, curves and even radii," says Kraling.
<G-vec00296-002-s223><divide.gliedern><de> Um den Raum optisch und funktional zu gliedern, nutzen wir Kombinationen gerader und abgerundeter Elemente, bilden Linien, Kurven und sogar Radien“, sagt Kräling.
<G-vec00296-002-s224><divide.graben><en> On one side stands Moscow, which – with its self-imposed isolation from the West and rejection of the norms and processes of constitutional democracy – offers a geostrategic anchor and point of orientation for the region’s autocracies. However, it also expects loyalty, and its intransigence is gradually deepening the divide with the West.
<G-vec00296-002-s224><divide.graben><de> Auf der einen Seite steht Moskau, das mit seiner Abgrenzung vom Westen und seiner Abkehr von Normen und Prozessen der rechtsstaatlichen Demokratie den Autokratien der Region einen geostrategischen Anker und politische Orientierung bietet, aber auch Loyalität erwartet und mit seiner Kompromisslosigkeit sukzessive den Graben zum Westen vertieft.
<G-vec00296-002-s225><divide.graben><en> There is a deep divide between the paternalism of the Asian city state and the democracy of the Swiss Confederation.
<G-vec00296-002-s225><divide.graben><de> Zwischen dem Paternalismus des Stadtstaates und der Demokratie der Eidgenossenschaft klafft ein tiefer Graben.
<G-vec00296-002-s226><divide.graben><en> From the vantage point of three interdisciplinary research departments – the Department of Archaeogenetics (Director Johannes Krause), the Department of Archaeology (Director Nicole Boivin), and the Department of Cultural and Linguistic Evolution (Director Russell Gray) – the MPI-SHH pursues an integrative approach to the study of human history that bridges the traditional divide between the natural sciences and the humanities.
<G-vec00296-002-s226><divide.graben><de> Mit seinen drei interdisziplinären Abteilungen – der Abteilung für Archäogenetik (Direktor Johannes Krause), der Abteilung für Archäologie (Direktorin Nicole Boivin) sowie der Abteilung für Sprach- und Kulturevolution (Direktor Russell Gray) – verfolgt das Institut eine dezidiert integrierende Wissenschaft der Menschheitsgeschichte, die den traditionellen Graben zwischen Natur- und Geisteswissenschaften überwindet.
<G-vec00296-002-s227><divide.graben><en> This is even evident to people like Friedrich Merz, whose job description includes keeping the divide as narrow as possible.
<G-vec00296-002-s227><divide.graben><de> Das fällt selbst Leuten wie Friedrich Merz auf, zu dessen Jobbeschreibung es gehört, den Graben kleinzuhalten.
<G-vec00296-002-s378><divide.sich_teilen><en> Each day, the cells of the human body divide billions of times; this also requires duplication of their genetic information.
<G-vec00296-002-s378><divide.sich_teilen><de> Die Zellen des menschlichen Körpers und die darin enthaltene Erbinformation teilen sich milliardenfach, jeden Tag.
<G-vec00296-002-s379><divide.sich_teilen><en> They extend along the coast for more than 250km and divide into numerous layers.
<G-vec00296-002-s379><divide.sich_teilen><de> Sie erstrecken sich entlang der Küste mehr als 250km und teilen sich in vielen Schichten.
<G-vec00296-002-s380><divide.sich_teilen><en> Amphibola bests break into shorter fibers or divide into thinner fibers along their longitudinal cleavage.
<G-vec00296-002-s380><divide.sich_teilen><de> Amphibolasbeste brechen zu kürzeren Fasern oder teilen sich entlang Ihrer Längsspaltbarkeit zu dünneren Fasern.
<G-vec00296-002-s381><divide.sich_teilen><en> Employers and employees divide social security contributions in half.
<G-vec00296-002-s381><divide.sich_teilen><de> Arbeitgeber/in und Arbeitnehmer/in teilen sich die Sozialbeiträge hälftig.
<G-vec00296-002-s382><divide.sich_teilen><en> At this point the production lines divide again: some of the salmon fillets are taken away to be packaged as finished products, while the rest are cut into portion-sized pieces and then packaged up.
<G-vec00296-002-s382><divide.sich_teilen><de> Hier teilen sich die Produktionslinien erneut: Ein Teil der Lachsfilets wird als fertiges Produkt der Verpackung zugeführt, der andere Teil wird in Portionsstücke geschnitten und anschließend verpackt.
<G-vec00296-002-s383><divide.sich_teilen><en> these 15 exclusive housing units divide each other in nine, or six, apartments in two building structures, through which the distance to the the next neighbor was extended and your privacy is being protected optimally.
<G-vec00296-002-s383><divide.sich_teilen><de> Die 15 exklusiven Wohneinheiten teilen sich zu neun beziehungsweise sechs Wohnungen auf zwei Baukörper auf, wodurch die Entfernung zum nächsten Nachbarn erweitert wurde und Ihre Privatsphäre optimal geschützt wird.
<G-vec00296-002-s384><divide.sich_teilen><en> The latter divide into three LFOs and a CV modulation sequence.
<G-vec00296-002-s384><divide.sich_teilen><de> Letztere teilen sich in drei LFOs und eine CV-Sequenz auf.
<G-vec00296-002-s385><divide.sich_teilen><en> Some cells divide repeatedly, while others appear to develop into more mature cell types that no longer divide.
<G-vec00296-002-s385><divide.sich_teilen><de> Einige dieser Zellen teilen sich wiederholt, während andere sich zu ausgereiften, spezialisierten Zelltypen entwickeln, die sich nicht mehr vermehren können.
<G-vec00296-002-s386><divide.sich_teilen><en> Typically, slot machines divide by 32, 64,128, 256 or 512.
<G-vec00296-002-s386><divide.sich_teilen><de> Gewöhnlich teilen sich Spielautomaten durch 32, 64.128, 256 oder 512.
<G-vec00296-002-s387><divide.sich_teilen><en> Further crushing of the blastomeres does not occur synchronously: some cells divide faster, some slower, resulting in the formation of a morula (the so-called stage of development of the human embryo, numbering about a hundred cells).
<G-vec00296-002-s387><divide.sich_teilen><de> Eine weitere Zerkleinerung der Blastomeren findet nicht synchron statt: einige Zellen teilen sich schneller, einige langsamer, was zur Bildung einer Morula führt (das sogenannte Entwicklungsstadium des menschlichen Embryos, das etwa 100 Zellen umfasst).
<G-vec00296-002-s388><divide.sich_teilen><en> Once inside the erythrocytes, they divide again and ultimately destroy them.
<G-vec00296-002-s388><divide.sich_teilen><de> Im Inneren der Erythrocyten teilen sie sich erneut und zerstören diese schließlich.
<G-vec00296-002-s389><divide.sich_teilen><en> Almost all long-distance trains travelling from Munich to the north of Germany run in combination to Nuremberg over the high-speed link and then divide up from here.
<G-vec00296-002-s389><divide.sich_teilen><de> Fast alle von München nach Norden führenden Fernverkehrsverbindungen laufen heute gebündelt über die Schnellfahrstrecke nach Nürnberg und teilen sich erst hier auf.
<G-vec00296-002-s390><divide.sich_teilen><en> This room is easy enough to organize and divide into zones.
<G-vec00296-002-s390><divide.sich_teilen><de> Das Zimmer ist einfach genug, um zu organisieren und teilen sich in Zonen.
<G-vec00296-002-s391><divide.sich_teilen><en> They are made homogeneous, or divide into several sectors, creating the effect of the gallery.
<G-vec00296-002-s391><divide.sich_teilen><de> Sie werden homogen gemacht oder teilen sich in mehrere Sektoren auf, wodurch die Wirkung der Galerie entsteht.
<G-vec00296-002-s392><divide.sich_teilen><en> Activated T cells divide every 4-5 hours, much faster than other cell types in the body.
<G-vec00296-002-s392><divide.sich_teilen><de> Aktivierte T-Zellen teilen sich alle 4-5 Stunden, viel schneller als andere Zelltypen des Körpers.
<G-vec00296-002-s303><divide.spalten><en> Stand and believe the simplicity of salvation; for vain theologies divide those who do not understand the simplicity and the pureness of the gospel.
<G-vec00296-002-s303><divide.spalten><de> Steht und glaubt an die Einfachheit der Erlösung; denn vergebliche Gotteslehren spalten jene, die die Einfachheit und die Reinheit der Heilsbotschaft nicht verstehen.
<G-vec00296-002-s304><divide.spalten><en> It is the sign and proof of God's victory over the forces of evil which divide humanity.
<G-vec00296-002-s304><divide.spalten><de> Sie ist Zeichen und Beweis für den Sieg Gottes über die Kräfte des Bösen, die die Menschheit spalten.
<G-vec00296-002-s305><divide.spalten><en> 14:7 Nevertheless these all of you shall not eat of them that chew the cud, or of them that divide the cloven hoof; as the camel, and the hare, and the coney: for they chew the cud, but divide not the hoof; therefore they are unclean unto you.
<G-vec00296-002-s305><divide.spalten><de> 14:7 Das sollt ihr aber nicht essen von dem, das wiederkäut, und von dem, das die Klauen spaltet: das Kamel, der Hase und Kaninchen, die wiederkäuen und doch ihre Klauen nicht spalten, sollen euch unrein sein; 14:8 das Schwein, ob es wohl die Klauen spaltet, so wiederkäut es doch nicht: es soll euch unrein sein.
<G-vec00296-002-s306><divide.spalten><en> „We look forward to playing our part in shaping the association for living together in diversity,“ says Peter Oppinger, Head of Global Marketing with the VAG Group. However, „If we manage to incorporate consistent values for all and develop ideas to unite instead of divide, we will be making the Mannheim Statement a sustained living declaration, also on the part of companies operating internationally here in our city.
<G-vec00296-002-s306><divide.spalten><de> “Wir freuen uns darüber, die Vereinigung für ein Zusammenleben in Vielfalt mit zu gestalten”, so Peter Oppinger, Leiter Globales Marketing der VAG-Gruppe, aber: “Wenn es uns gelingt, für alle stimmige Werte zu verankern und Ideen zu entwickeln, die verbinden, statt spalten, werden wir die Mannheimer Erklärung auch seitens der international tätigen Unternehmen hier in der Stadt nachhaltig mit Leben erfüllen”.
<G-vec00296-002-s307><divide.spalten><en> This move is simply intended to divide and demobilise the protests and give the government time to gather its breath and regroup.
<G-vec00296-002-s307><divide.spalten><de> Mit diesem Schachzug will die Regierung die Proteste spalten und demobilisieren, um eine Verschnaufpause zu bekommen und sich neu aufstellen zu können.
<G-vec00296-002-s308><divide.spalten><en> New tax rules divide owners.
<G-vec00296-002-s308><divide.spalten><de> Neue Steuerregeln spalten Eigentümer.
<G-vec00296-002-s309><divide.spalten><en> In order to digest foods and recycle the proteins of the billions of cells that die each day in every human being, a delicate and complex balance must be maintained within each cell between the proteases, which divide proteins, natural protease inhibitors, which provisionally block the action of the proteases, and protease activators, which reactivate them.
<G-vec00296-002-s309><divide.spalten><de> Um die Nahrung zu verdauen und die Proteine der Milliarden von Zellen, die täglich in jedem Menschen sterben, zu entsorgen, existiert in jeder Zelle ein empfindliches und sehr komplexes Gleichgewicht unter den Proteasen, die die Proteine spalten, zum einen die natürlichen Proteasehemmer, die vorübergehend die Wirkung der Proteasen desaktivieren und zum anderen die Proteaseaktivatoren, die sie wieder zum Einsatz bringen lassen.
<G-vec00296-002-s310><divide.spalten><en> When one steps forward, then will others step up in solidarity and move this world forward and reject the perverse manipulations of groups and governments to control and divide men and nations.
<G-vec00296-002-s310><divide.spalten><de> Wenn einer vorwärts geht, dann werden andere in Solidarität vortreten und diese Welt voran bringen und die perversen Manipulationen von Gruppen und Regierungen ablehnen, Menschen und Nationen zu kontrollieren und zu spalten.
<G-vec00296-002-s311><divide.spalten><en> These unions that participated in this labor mobilization are acutely aware of how racist attacks are used to divide and weaken labor.
<G-vec00296-002-s311><divide.spalten><de> Diese Gewerkschaften, die an der Arbeiter-Mobilisierung beteiligt waren, sind sich darüber tatsächlich bewusst, wie rassistische Angriffe benutzt werden, um die Arbeiterbewegung zu spalten und zu schwächen.
<G-vec00296-002-s312><divide.spalten><en> It is not new but they made it more concrete: they divide refugees in the groups of good and bad.
<G-vec00296-002-s312><divide.spalten><de> Es ist nicht neu, aber jetzt haben sie es konkret gemacht: Sie spalten Geflüchtete in Gut und Böse.
<G-vec00296-002-s313><divide.spalten><en> Contrary to the city center, which for the majority of those passing through is big, bright, sparkling and inviting to use, acts of repression have the goal of incapacitating activists, and to socially marginalize and divide movements.
<G-vec00296-002-s313><divide.spalten><de> Entgegen der Innenstadt, die auf den Großteil der Passant_innen groß, hell, glitzernd und zum Konsum einladend wirkt, haben Repressionen das Ziel, Aktivist_innen handlungsunfähig zu machen, sozial auszugrenzen und soziale Bewegungen zu spalten.
<G-vec00296-002-s314><divide.spalten><en> It’s almost as if players like games which get bigger and better over time with free updates, rather than ones which divide and drain players with a swarm of paid DLC.
<G-vec00296-002-s314><divide.spalten><de> Es ist fast so, als mögen die Spieler Titel, die mit der Zeit und kostenlosen Updates größer und besser werden, statt solcher, die die Spielerbasis mit einem Bezahl-DLC-Schwarm spalten.
<G-vec00296-002-s315><divide.spalten><en> This potential threat should unite – rather than divide – us.
<G-vec00296-002-s315><divide.spalten><de> Diese potenzielle Bedrohung sollte uns einigen – nicht spalten.
<G-vec00296-002-s316><divide.spalten><en> "Even four years after Jiang's regime started to persecute Falun Gong, the Chinese Consulate in Toronto is still using hateful propaganda and manipulating measures to divide Canadian communities.
<G-vec00296-002-s316><divide.spalten><de> Sogar vier Jahre nachdem das Regime Jiangs die Verfolgung von Falun Gong begonnen hatte, setzt das chinesische Konsulat immer noch Hasspropaganda und manipulierende Maßnahmen ein, um die kanadischen Gemeinden zu spalten.
<G-vec00296-002-s317><divide.spalten><en> The Christians in Corinth are described here by Paul as being carnal because they follow men; they have started to divide themselves into groups showing preference to specific people.
<G-vec00296-002-s317><divide.spalten><de> Die Christen in Korinth werden hier von Paulus als fleischlich bezeichnet, da sie Menschen folgen: sie haben begonnen sich in Gruppen zu spalten indem sie Vorliebe für bestimmte Personen zeigen.
<G-vec00296-002-s318><divide.spalten><en> We are not going to let the state split divide us into “good” and “bad” protestors.
<G-vec00296-002-s318><divide.spalten><de> Wir lassen uns nicht spalten in “gute” und “böse” Demonstrierende.
<G-vec00296-002-s319><divide.spalten><en> “A 'leftist' candidate can't win because he'd divide his own camp.
<G-vec00296-002-s319><divide.spalten><de> „Ein 'linker' Kandidat kann nicht siegen, denn er würde sein eigenes Lager spalten.
<G-vec00296-002-s320><divide.spalten><en> Racist immigration and asylum laws have been passed to divide the workers and play one section against the others.
<G-vec00296-002-s320><divide.spalten><de> Rassistische Einwanderungs- und Asylgesetze sollten die ArbeiterInnen spalten und gegeneinander ausspielen.
<G-vec00296-002-s321><divide.spalten><en> Promoting a social, economic, and cultural sense of community and helping to bridge gaps that continue to divide us
<G-vec00296-002-s321><divide.spalten><de> Und drittens, einen sozialen, ökonomischen und kulturellen Gemeinschaftssinn zu fördern, und zu helfen die Unterschiede welche uns bis heute spalten zu überbrücken.
<G-vec00296-002-s254><divide.teilen><en> Divide the dough into 8 equally sized pieces.
<G-vec00296-002-s254><divide.teilen><de> Den Teig in 8 gleich große Portionen teilen und zu Bällen rollen.
<G-vec00296-002-s255><divide.teilen><en> Divide the dough in two and roll out each portion on a floured surface to a roll of about 12 inches (30cm) length.
<G-vec00296-002-s255><divide.teilen><de> Den Teig in zwei Portionen teilen und dann auf einer bemehlten Fläche jeweils zu einer etwa 30m (12 inch) langen Rolle formen.
<G-vec00296-002-s256><divide.teilen><en> Divide the dough into 16 equal pieces.
<G-vec00296-002-s256><divide.teilen><de> Den Kloßteig in 16 gleich große Portionen teilen.
<G-vec00296-002-s257><divide.teilen><en> Divide the dough into 10 equal pieces and cover with a damp towel.
<G-vec00296-002-s257><divide.teilen><de> Den Teig in vier gleich große Portionen teilen.
<G-vec00296-002-s442><divide.trennen><en> Crop and divide audio files in a few clicks.
<G-vec00296-002-s442><divide.trennen><de> Zuschneiden und Trennen von Audio-Dateien mit wenigen Clicks.
<G-vec00296-002-s443><divide.trennen><en> Thus, every presenter has 5 minutes to divide the important from the unimportant.
<G-vec00296-002-s443><divide.trennen><de> Damit hat jeder Präsentierende 5 Minuten Zeit, wichtiges von unwichtigem zu trennen.
<G-vec00296-002-s444><divide.trennen><en> They cushion, insulate, filter, divide, connect and seal: molded parts made of rubber and thermoplastic elastomers.
<G-vec00296-002-s444><divide.trennen><de> Sie dämpfen, isolieren, filtern, trennen, verbinden und dichten: Formteile aus Gummi oder thermoplastischen Elastomeren.
<G-vec00296-002-s445><divide.trennen><en> Satan will always target such a core seeking to split it up and divide it.
<G-vec00296-002-s445><divide.trennen><de> Satan wird immer versuchen, auf einen solchen Kern zu zielen, um ihn zu spalten und zu trennen.
<G-vec00296-002-s446><divide.trennen><en> Ever since the great Situationist and expert on urban complexities Guy Debord, if not before, we have known that communication, especially telematics, not only connects, but can also divide.
<G-vec00296-002-s446><divide.trennen><de> Spätestens seit dem großen Situationisten Guy Debord, dem Experten für urbane Unübersichtlichkeiten, wissen wir, dass Kommunikation, zumal telematisch verfasste, nicht nur verbindet; sie kann auch trennen.
<G-vec00296-002-s447><divide.trennen><en> The work will not grow and expand and enlarge if Satan is allowed a place to divide the people of God.
<G-vec00296-002-s447><divide.trennen><de> Das Werk wird nicht wachsen und sich ausdehnen und größer werden, wenn man Satan Raum lässt, das Volk Gottes zu trennen.
<G-vec00296-002-s448><divide.trennen><en> What we must do is find ways of debating our choices respectfully and in a way that doesn’t just focus on the issues that divide us but seeks to find maximum areas of agreement as well.
<G-vec00296-002-s448><divide.trennen><de> Was wir tun müssen, ist, Wege zu finden, um unsere Entscheidungen respektvoll und auf eine Weise zu diskutieren, die sich nicht nur auf die Probleme konzentriert, die uns trennen, sondern auch versucht, maximale Einigungsbereiche zu finden.
<G-vec00296-002-s449><divide.trennen><en> As the older ones are telling us, when the beehive is filling up, then you have to divide the bees, as they cannot live together anymore."
<G-vec00296-002-s449><divide.trennen><de> Denn wenn der Bienenkorb sich ausfüllt, sagen die Älteren, wenn der Bienenkorb sich ausfüllt, dann muss man die Bienen trennen, weil sie nicht mehr zusammen bleiben können.
<G-vec00296-002-s450><divide.trennen><en> Divide the eggs and whip the egg whites with a dash of salt until stiff.
<G-vec00296-002-s450><divide.trennen><de> Die Eier trennen und das Eiweiß mit einer Prise Salz steifschlagen.
<G-vec00296-002-s451><divide.trennen><en> That is why the greatest danger of all is to allow new walls to divide us from one another.
<G-vec00296-002-s451><divide.trennen><de> Deshalb ist die größte Gefahr von allen, zuzulassen, dass uns neue Mauern von einander trennen...
<G-vec00296-002-s452><divide.trennen><en> PhenQ active ingredients are exactly what divide it from the remainder of the area, and as we shall see, each one supplies a particular set of benefits.
<G-vec00296-002-s452><divide.trennen><de> PhenQ Zutaten sind genau das, was sie von dem Rest des Feldes trennen, und wie wir sehen werden, bietet jeder eine bestimmte Sammlung von Vorteilen.
<G-vec00296-002-s453><divide.trennen><en> We must tear down the barriers of fear, holding grudges and injustice, which divide people and eliminate their dreams and hopes of peace.” The religious leaders were united in acknowledging that the current conflict in Iraq and Syria targets followers of every religion.
<G-vec00296-002-s453><divide.trennen><de> Wir müssen die Mauern der Angst, der Missgunst und der Ungerechtigkeit einreißen, denn diese trennen die Menschen und zerstören ihre Träume und ihre Hoffnung auf Frieden.“ Die religiösen Würdenträger stellten gemeinsam fest, dass der derzeitige Konflikt in Irak und Syrien die Anhänger aller Religionen betrifft.
<G-vec00296-002-s454><divide.trennen><en> With room Panel Curtains large living rooms can be separated into cosy lounges or dining areas and you can divide your workplace from your living space.
<G-vec00296-002-s454><divide.trennen><de> Zu Hause lassen sich große Wohnzimmer mit den textilen Paravents ideal in gemütliche Lounges oder Essecken separieren und der Arbeitsplatz vom Wohnbereich trennen.
<G-vec00296-002-s455><divide.trennen><en> In order to defeat us, the forces of Capital are still using the same tactics, trying to divide us across old nation-state borders, and the new internal borders caused by the latest wave of migration.
<G-vec00296-002-s455><divide.trennen><de> Die Kräfte des Kapitals nutzen noch immer dieselben Taktiken, um uns zu bezwingen: Sie versuchen uns auseinanderzubringen, uns nach den alten national-staatlichen Grenzen und nach den neuen inneren Grenzen, die durch die jüngste Migrationswellen entstanden sind, zu trennen.
<G-vec00296-002-s456><divide.trennen><en> PhenQ active ingredients are exactly what divide it from the remainder of the area, and as we will see, each one gives a certain set of advantages.
<G-vec00296-002-s456><divide.trennen><de> PhenQ Komponenten sind genau das, was sie von dem Rest des Feldes trennen, und wie wir sehen werden, gibt jeder eine bestimmte Sammlung von Vorteilen.
<G-vec00296-002-s457><divide.trennen><en> If you want to make a gate out of wedges, the distance between two wedges has to be bigger than the things you want to divide.
<G-vec00296-002-s457><divide.trennen><de> Wenn Sie ein Gatter aus Keilen machen, dann muss der Abstand zwischen zwei Keilen größer sein, als die Teile, die Sie trennen wollen.
<G-vec00296-002-s458><divide.trennen><en> Reaching into the sea in order to divide the waters of the Atlantic from those of the Bay of Biscay...
<G-vec00296-002-s458><divide.trennen><de> Greift tief ins Meer, um den offenen Atlantik vom Golf von Biskaya zu trennen...
<G-vec00296-002-s459><divide.trennen><en> The EU didn’t anticipate the extent to which the US would exploit it amidst the New Cold War, but as has been widely analyzed, the whole point of renewed US-Russian tensions has been for Washington to divide the EU from Russia and preempt the type of collusion between the two that would torpedo America’s Eurasian hegemony (as per Brzezinski’s forecast in “The Grand Chessboard”).
<G-vec00296-002-s459><divide.trennen><de> Die EU hat nicht vorhergesehen, in welchem Maße die USA sie inmitten des neuen Kalten Krieges ausnutzen würden, aber wie weitgehend analysiert, war der ganze Sinn der erneuerten amerikanisch-russischen Spannungen, dass Washington die EU von Russland trennen und der Verständigung, die Amerikas eurasische Hegemonie torpedieren würde (wie von Brzezinski in seinem “Grand Chessboard/Die Einzige Weltmacht” vorhergesagt), zwischen den beiden vorbeugen könnte.
<G-vec00296-002-s460><divide.trennen><en> 17 God set them in the firmament of the heavens to give light on the earth, 18 and to rule over the day and over the night, and to divide the light from the darkness.
<G-vec00296-002-s460><divide.trennen><de> 17Und Gott setzte sie an das Gewölbe des Himmels, um die Erde zu beleuchten, 18um über den Tag und über die Nacht zu herrschen und um das Licht von der Finsternis zu trennen.
<G-vec00296-002-s473><divide.unterteilen><en> Divide the page into five columns labeled Name, Address, E-mail Address, Phone Number, and Signature.
<G-vec00296-002-s473><divide.unterteilen><de> Unterteile die Seite in fünf Spalten, je eine für Name, Adresse, Email, Telefonnummer und die Unterschrift selbst.
<G-vec00296-002-s474><divide.unterteilen><en> [13] Divide up the hours in the day and decide what you will focus on when.
<G-vec00296-002-s474><divide.unterteilen><de> [13] Unterteile die Stunden des Tages und entscheide, worauf du dich wann konzentrieren willst.
<G-vec00296-002-s475><divide.unterteilen><en> They knew the different between day and night, black and white, and if you draw that you got a cross, overlap this with the southern cross- then divide every quarter in 3 up and down left and right, like puma, snake, condor or past future and present, connect all the points you get 12 angles or 12 months.
<G-vec00296-002-s475><divide.unterteilen><de> Sie kannten den Unterschied zwischen Tag und Nacht, Schwarz und Weiß, und wenn du das aufmalst siehst du ein Kreuz, man lege das Kreuz des Süden da drauf und unterteile jedes Viertel in 3 (oben unten links rechts), wie Puma, Schlange Condor oder Vergangenheit Gegenwart Zukunft, verbindet all die Punkte und man hat 12 ecken oder?= 12 Monate.
<G-vec00296-002-s476><divide.unterteilen><en> Create another ponytail (ponytail C) and divide into two.
<G-vec00296-002-s476><divide.unterteilen><de> Kreiere einen weiteren Zopf (C) und unterteile in zwei Parts.
<G-vec00296-002-s477><divide.unterteilen><en> If needed, divide your project further.
<G-vec00296-002-s477><divide.unterteilen><de> Falls nötig, unterteile dein Projekt weiter.
<G-vec00296-002-s478><divide.unterteilen><en> Divide different styles of songs into different sections.
<G-vec00296-002-s478><divide.unterteilen><de> Unterteile Songs in verschiedene Teile.
<G-vec00296-002-s479><divide.unterteilen><en> Divide your hair into 4-6 sections, depending on how thick your hair is.
<G-vec00296-002-s479><divide.unterteilen><de> Unterteile dein Haar in vier bis sechs Abschnitte, je nach Haardicke.
<G-vec00296-002-s480><divide.unterteilen><en> I divide the days into two types: first the "improve days" and then the "network days".
<G-vec00296-002-s480><divide.unterteilen><de> Ich unterteile die Tage in zwei Typen: zuerst die "improve days" und dann die "network days".
<G-vec00296-002-s535><divide.verteilen><en> In doing so, the cover becomes a second bottom allowing you to divide the contents into two separate halves after opening.
<G-vec00296-002-s535><divide.verteilen><de> So wird der Deckel zum zweiten Boden und der Inhalt kann nach dem Öffnen auf die beiden Hälften verteilt werden.
<G-vec00296-002-s536><divide.verteilen><en> 22but when the stronger than he coming upon [him] overcomes him, he takes away his panoply in which he trusted, and he will divide the spoil [he has taken] from him.
<G-vec00296-002-s536><divide.verteilen><de> 22 wenn aber ein Stärkerer als er über ihn kommt und ihn besiegt, so nimmt er seine ganze Waffenrüstung weg, auf die er vertraute, und seine Beute verteilt er.
<G-vec00296-002-s537><divide.verteilen><en> Generally four air bearing modules are used to move large and heavy loads, but to ensure maximum stability, at least three air bearing modules (preferably four) are required. They should be placed under the load, as far apart from each as possible, and in such way as to divide the weight of the load evenly between them.
<G-vec00296-002-s537><divide.verteilen><de> Um maximale Stabilität zu gewährleisten, sollten mindestens drei Luftkissen-Modulsysteme (besser vier) so weit wie möglich voneinander entfernt und auf solche Weise unter der Last platziert werden, dass das Gewicht der Last gleichmäßig auf sie verteilt ist.
<G-vec00296-002-s538><divide.verteilen><en> By inserting a pause during programming, you can divide the programme into two for recording on both sides of a tape.
<G-vec00296-002-s538><divide.verteilen><de> Sie können bei der Programmierung eine Pause einfügen, so daß Sie Ihr Programm auf die beiden Seiten einer Kassette verteilt aufnehmen können.
<G-vec00296-002-s551><divide.zerlegen><en> We went to the Lufthansa workshop and I was able to divide the split rim with outstanding tools and take the inner tube.
<G-vec00296-002-s551><divide.zerlegen><de> Wir begaben uns zur Lufthansa-Werkstatt, und ich konnte mit hervorragendem Werkzeug die zweigeteilte Felge zerlegen und den Schlauch entnehmen.
<G-vec00296-002-s552><divide.zerlegen><en> ➋ The black cells form dominoes which do not touch orthogonally (diagonally is allowed and necessary). ➌ The black cells divide the diagram into orthogonally contiguous areas of white cells.
<G-vec00296-002-s552><divide.zerlegen><de> ➋ Die schwarzen Felder dürfen nirgendwo eine Fläche der Größe 2x2 überdecken und zerlegen das Diagramm in rechteckige Bereiche orthogonal zusammenhängender weißer Felder.
<G-vec00296-002-s553><divide.zerlegen><en> “We divide up the projects based on what’s known as a scrum principle in software development,” explains Tönnis. “That means clearly defined development tasks with short iteration cycles of two to four weeks.
<G-vec00296-002-s553><divide.zerlegen><de> Andreas Tönnis: „Wir zerlegen die Projekte nach dem,Scrum‘-Prinzip, das in der Softwareentwicklung bekannt ist, in klar definierte Entwicklungsaufgaben mit kurzen Iterationszyklen von zwei bis vier Wochen.
<G-vec00296-002-s554><divide.zerlegen><en> If the railing does not divide into four pieces, you will likely need an assistant to transport it safely.
<G-vec00296-002-s554><divide.zerlegen><de> [1] Wenn sich die Bande nicht in vier Teile zerlegen lässt, wirst du wahrscheinlich einen Helfer brauchen, um sie sicher zu transportieren.
<G-vec00296-002-s555><divide.zerlegen><en> Now pick a few dozen words and divide them into syllables.
<G-vec00296-002-s555><divide.zerlegen><de> Suchen Sie sich aus einem Artikel mindestens ein Dutzend Wörter aus und zerlegen Sie sie in ihre Silben.
<G-vec00296-002-s556><divide.zerlegen><en> We discuss the order with you, advise you with regard to the options, setup the project, divide it into small, individual research jobs and offer these tasks to qualified Clickworkers for processing. After consulting with you, we implement appropriate quality assurance measures and make the payments to the Clickworkers for you.
<G-vec00296-002-s556><divide.zerlegen><de> Wir besprechen den Auftrag mit Ihnen, beraten Sie bezüglich der Möglichkeiten, setzen das Projekt für Sie auf, zerlegen es in Microtasks, bieten diese nur qualifizierten Autoren-Clickworkern zur Bearbeitung an und übernehmen sowohl die Qualitätssicherung als auch die Bezahlung der Clickworker für Sie.
<G-vec00296-002-s557><divide.zerlegen><en> Now it’s time to get together in a joint workshop with the project team and your chosen partner to analyse your timetable and divide the project into work packages.
<G-vec00296-002-s557><divide.zerlegen><de> Nun geht es darum in einem gemeinsamen Workshop mit dem Projektteam und dem Partner den Zeitplan zu analysieren und in Pakete zu zerlegen.
<G-vec00296-002-s559><divide.zerteilen><en> Many wire loops are used to divide up the crystal ingot within a sawing step.
<G-vec00296-002-s559><divide.zerteilen><de> Dabei zerteilen viele Drahtschlaufen den Kristallblock innerhalb eines Sägeschritts.
<G-vec00296-002-s560><divide.zerteilen><en> The goulash is done if the meat can be easily divide up with a spoon & the sauce has a creamy consistency.
<G-vec00296-002-s560><divide.zerteilen><de> Sobald sich das Fleisch leicht mit einem Löffel zerteilen lässt & die Sauce eine cremige Konsistenz hat, ist das Gulasch fertig & kann serviert werden.
<G-vec00296-002-s561><divide.zerteilen><en> All of them combine at a moment or another, consciously or not, to divide us, to set one against the other, to represent us by force, to rob us, to enlist us to go to the army, to analyze us, to threaten us, to buy and sell us, or, more basically, to club us.
<G-vec00296-002-s561><divide.zerteilen><de> All jene verbünden sich früher oder später, ob sie sich dessen bewusst sind oder nicht, um uns zu zerteilen, uns gegeneinander aufzubringen, unserem Dasein ihren Sinn aufzudrücken, uns auszunehmen, uns einzugliedern, uns zu analysieren, uns zu bedrohen, uns zu kaufen und zu verkaufen, oder uns ganz einfach nur niederzuknüppeln.
<G-vec00296-002-s562><divide.zerteilen><en> By setting marks between songs during a live recording, for instance, you can later easily divide that continuous live recording into single tracks. Variable Speed Audition
<G-vec00296-002-s562><divide.zerteilen><de> Wenn Sie beispielsweise während einer Live-Aufnahme Marken zwischen den einzelnen Songs setzen, können Sie die durchgehende Live-Aufnahme später leicht in einzelne Titel zerteilen.
<G-vec00296-002-s563><divide.zerteilen><en> Divide the lettuce heads into leaves, wash and drain as usual and distribute in a large salad bowl.
<G-vec00296-002-s563><divide.zerteilen><de> Die Salate wie üblich zerteilen, waschen, abtropfen lassen, in einer möglichst großen weiten Schüssel auflegen.
<G-vec00296-002-s564><divide.zerteilen><en> Cut the cauliflower in half and divide into florets.
<G-vec00296-002-s564><divide.zerteilen><de> Die Hälfte des Blumenkohls in schöne Röschen zerteilen.
