<G-vec00539-002-s020><bolster.auspolstern><de> Das alles sind Ausflüchte, um deinen Glauben auszupolstern, dass du ohne Mich besser auskommst.
<G-vec00539-002-s020><bolster.auspolstern><en> Those are all excuses to bolster your belief that you may be better off without Me.
