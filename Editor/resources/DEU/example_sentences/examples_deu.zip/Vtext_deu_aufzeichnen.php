<G-vec00169-001-s070><capture.aufzeichnen><de> Unabhängige analytische Studien haben ein schockierendes Ergebnis geliefert - einige IPhone-Anwendungen können alles aufzeichnen, was auf dem Telefonbildschirm passiert.
<G-vec00169-001-s070><capture.aufzeichnen><en> Independent analytical studies produced a shocking result - some IPhone applications are able to capture everything that happens on the phone screen.
<G-vec00169-001-s071><capture.aufzeichnen><de> Wir haben zuhause die Kinect und ähnliche Technologien, die unsere Bewegungen aufzeichnen und uns so Videospiele kontrollieren lassen.
<G-vec00169-001-s071><capture.aufzeichnen><en> We also have the Kinect and its comrades that capture motion and allow us to control games.
<G-vec00169-001-s072><capture.aufzeichnen><de> Wenn Sie auf die Schaltfläche Aufzeichnen klicken, gelangen Sie zum Aufzeichnen-Fenster.
<G-vec00169-001-s072><capture.aufzeichnen><en> When you click the Capture button you enter the capture window.
<G-vec00169-001-s073><capture.aufzeichnen><de> Kaufen Herunterladen Herunterladen Herunterladen Debut Mit diesem Video-Aufnahme-Programm kann man Videodateien mittels Webcam (Videokamera) oder Aufnahmegerät (von Video) direkt auf dem Computer aufzeichnen.
<G-vec00169-001-s073><capture.aufzeichnen><en> This video recorder lets you capture video files directly on your PC or Mac using a webcam (video camera), or capture device (from video).
<G-vec00169-001-s074><capture.aufzeichnen><de> Erfahren Sie, welche 4K HDR-Spielclips Sie auf Ihrer Xbox One X aufzeichnen können.
<G-vec00169-001-s074><capture.aufzeichnen><en> Find out which 4K HDR game clips you can capture on your Xbox One X.
<G-vec00169-001-s075><capture.aufzeichnen><de> Und du erhältst eine Anfrage, bevor eine App Tastatur aktivitäten aufzeichnen oder ein Foto oder Video von deinem Bildschirm machen kann.
<G-vec00169-001-s075><capture.aufzeichnen><en> And you’ll be prompted before any app can capture keyboard activity or a photo or video of your screen.
<G-vec00169-001-s076><capture.aufzeichnen><de> Zur Auswahl stehen Modelle mit 100 MHz oder 200 MHz Bandbreite, schnellen Abtastraten bis 2,5 GS/s und einer Auflösung von 400 ps zum Aufzeichnen von Rausch- und anderen Störsignalen.
<G-vec00169-001-s076><capture.aufzeichnen><en> Choose from 100 MHz or 200 MHz bandwidth models, with fast sampling rates up to 2.5 GS/s and 400 ps resolution to capture noise and other disturbances.
<G-vec00169-001-s077><capture.aufzeichnen><de> Mit der automatischen Stapelaufzeichnung können Sie schnell Szenen von einer Videokassette aufzeichnen.
<G-vec00169-001-s077><capture.aufzeichnen><en> Automatic batch capture is a quick way to capture scenes from a video tape.
<G-vec00169-001-s078><capture.aufzeichnen><de> Zum Aufzeichnen des Traces klicken Sie in der Menüleiste auf Übertragen / Text aufzeichnen.
<G-vec00169-001-s078><capture.aufzeichnen><en> You record the traces by clicking on Transmit / Capture text.
<G-vec00169-001-s079><capture.aufzeichnen><de> Nach unserer Erfahrung ist im Grunde die Sammlung von Informationen durch die Einrichtung von CCTV Foto durchgefÃ1⁄4hrt, die eine Miniaturkamera, die auch Ton aufnehmen kann, kann verwendet werden, und nur Video aufzeichnen können.
<G-vec00169-001-s079><capture.aufzeichnen><en> In our experience, basically the collection of information is carried out by establishing covert surveillance photo, which can be used a miniature camera that can also record sound, and can only capture video.
<G-vec00169-001-s080><capture.aufzeichnen><de> Um den Trace wieder zu stoppen, klicken Sie im HyperTerminal in der oberen Menüleiste auf Übertragen / Text aufzeichnen beenden.
<G-vec00169-001-s080><capture.aufzeichnen><en> To stop the trace, click on the HyperTerminal menus Transmit / Stop text capture.
<G-vec00169-001-s081><capture.aufzeichnen><de> Mit CyberLink PowerDVD können Sie den gewünschten Aufnahmetyp und die Aufnahmegröße schnell und praktisch auswählen, bevor Sie ein Einzelbild aufzeichnen.
<G-vec00169-001-s081><capture.aufzeichnen><en> CyberLink PowerDVD lets you select your desired capture type and size quickly and conveniently before you are ready to capture a frame.
<G-vec00169-001-s082><capture.aufzeichnen><de> Im Kunstgewerbe, beim Vordruck, in Werbeunternehmen und in anderen Kunstmanufakturen werden Scanner benötigt, die Bilder mit hoher Auflösung aufzeichnen und eine perfekte Bildqualität liefern.
<G-vec00169-001-s082><capture.aufzeichnen><en> For the art, pre-press, billboard shops and other art manufactories, they need scanners presents high resolution to deliver perfect image quality to capture images.
<G-vec00169-001-s083><capture.aufzeichnen><de> Um genauere Ergebnisse zu erzielen, können Sie die Wiedergabe anhalten, die Szene im Zeitlupenmodus abspielen oder schrittweise Einzelbild für Einzelbild ansehen und anschließend das gewünschte Einzelbild aufzeichnen.
<G-vec00169-001-s083><capture.aufzeichnen><en> To be more precise, you may pause the scene, play it in slow motion, or step frame, and then capture the exact desired frame of video.
<G-vec00169-001-s084><capture.aufzeichnen><de> Alle Kameraparameter via Fernbedienung einstellen und Bilder oder Movieclips durch einfachen Knopfdruck aufzeichnen/betrachten.
<G-vec00169-001-s084><capture.aufzeichnen><en> Set all camera parameters via wireless remote control and capture / review images or movie clips by simply pushing of a button.
<G-vec00169-001-s085><capture.aufzeichnen><de> Sie können Videos von jeder Quelle direkt in jedes Format aufzeichnen, das Ihrem vorinstallierten Codec unterstützt (wie die beliebten WebM, XviD, 3IVX...).
<G-vec00169-001-s085><capture.aufzeichnen><en> You can capture video from any source directly into any format that your preinstalled codecs support (such as most popular WebM, XviD, 3IVX...).
<G-vec00169-001-s086><capture.aufzeichnen><de> Sie können Videoszenen (inklusive Audioteil) von einer DVD aufzeichnen, um sie in Ihrem CyberLink PowerDirector-Projekt zu verwenden.
<G-vec00169-001-s086><capture.aufzeichnen><en> You can capture video scenes (including the audio portion) from a DVD for use in your CyberLink PowerDirector project.
<G-vec00169-001-s087><capture.aufzeichnen><de> Aufgezeichnete Dateien zur Medienbibliothek hinzufügen: Wählen Sie diese Option aus, um aufgezeichnete Dateien direkt nach dem Aufzeichnen in die Medienbibliothek zu importieren.
<G-vec00169-001-s087><capture.aufzeichnen><en> Add captured files to media library: select this option to import captured files into the media library directly after capture.
<G-vec00169-001-s088><capture.aufzeichnen><de> Sie veränderten ein für allemal das Verhältnis zwischen Künstlern und Studio: Es war nun zu einem Ort für Experimente und Komposition geworden, und das Ziel einer Aufnahme überstieg das bloße Aufzeichnen einer Darbietung für die Reproduktion.
<G-vec00169-001-s088><capture.aufzeichnen><en> In the process, they once and for all changed the relationship between the artist and the studio: it had now become a place for experimentation and composition, and the aim of recording was no longer to merely capture a performance for playback.
<G-vec00169-001-s108><capture.aufzeichnen><de> BG SEX gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s108><capture.aufzeichnen><en> BG SEX does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s109><capture.aufzeichnen><de> Es verbindet ein ultraschnelles chromatisches Stimmgerät mit einem Metronom und einem digitalen Audiorecorder, um eine Übungssession aufzuzeichnen und das Ergebnis zu überprüfen.
<G-vec00169-001-s109><capture.aufzeichnen><en> It combines a digital audio recorder with a built-in high-speed chromatic tuner with metronome to capture a training session and review the results.
<G-vec00169-001-s110><capture.aufzeichnen><de> BongaCam Chat gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s110><capture.aufzeichnen><en> BongaCam Chat does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s111><capture.aufzeichnen><de> Das Gerät kann auch drahtlos eine Verbindung mit externen ANT+ Sensoren und anderen Geräten von Garmin herstellen, um zusätzliche Leistungsdaten aufzuzeichnen.
<G-vec00169-001-s111><capture.aufzeichnen><en> Your device can also wirelessly connect to external ANT+ sensors and other Garmin devices to capture even more performance data.
<G-vec00169-001-s112><capture.aufzeichnen><de> Einige Drohnen sind mit einer Kamera ausgestattet um die Umgebung während dem Flug aufzuzeichnen.
<G-vec00169-001-s112><capture.aufzeichnen><en> It is for internal use drone equipped with a camera to capture the surroundings from a height.
<G-vec00169-001-s113><capture.aufzeichnen><de> CAMSEX.SU gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s113><capture.aufzeichnen><en> CAMSEX.SU does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s114><capture.aufzeichnen><de> BBW Cams gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s114><capture.aufzeichnen><en> BBW Cams does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s115><capture.aufzeichnen><de> Darmowe Sex Kamerki gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s115><capture.aufzeichnen><en> Darmowe Sex Kamerki does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s116><capture.aufzeichnen><de> Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s116><capture.aufzeichnen><en> The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s117><capture.aufzeichnen><de> 69chat.me gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s117><capture.aufzeichnen><en> 69chat.me does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s118><capture.aufzeichnen><de> • Ereignisse von anderer Anwendung abfangen - Die Quellanwendung versucht, für die Zielanwendung bestimmte Ereignisse abzufangen (Beispiel: ein Keylogger versucht, Ereignisse im Browser aufzuzeichnen).
<G-vec00169-001-s118><capture.aufzeichnen><en> • Intercept events from another application - The source application is attempting to catch events targeted at a specific application (for example a keylogger trying to capture browser events).
<G-vec00169-001-s119><capture.aufzeichnen><de> Benutzerdefinierte Größe: Wählen Sie diese Option aus, um Bilder in der Größe aufzuzeichnen, die Sie auf der Registerkarte Screenshot im Fenster Einstellungen festgelegt haben.
<G-vec00169-001-s119><capture.aufzeichnen><en> Custom Size: select this option to capture images in the customized size specified on the Capture tab in the Settings window.
<G-vec00169-001-s121><capture.aufzeichnen><de> Cams Avenue gestattet seinen Darstellern nicht den persönlichen Camera-Feed der Mitglieder während privater Shows aufzunehmen oder aufzuzeichnen.
<G-vec00169-001-s121><capture.aufzeichnen><en> Cams Avenue does not allow its performers to record or capture the members’ personal camera feeds during private shows.
<G-vec00169-001-s122><capture.aufzeichnen><de> Befolgen Sie nach dem Erstellen des Aufzeichnungsabbilds die Anweisungen im nächsten Abschnitt, um einen Computer mit dem Aufzeichnungsabbild zu starten und das Betriebssystem aufzuzeichnen.
<G-vec00169-001-s122><capture.aufzeichnen><en> After you have created the capture image, follow the instructions in the next section to boot a computer into the capture image and capture the operating system.
<G-vec00169-001-s123><capture.aufzeichnen><de> Verfügt über einen integrierten Datenlogger, um den Ereignisverlauf, Alarme und Kalibrierinformationen für den späteren Gebrauch aufzuzeichnen und zu speichern.
<G-vec00169-001-s123><capture.aufzeichnen><en> Incorporates a built-in logger to capture and store event history, alarms, and calibration information for later use.
<G-vec00169-001-s124><capture.aufzeichnen><de> Benutze eine Software wie tcpdump oder Wireshark, um die Daten aufzuzeichnen.
<G-vec00169-001-s124><capture.aufzeichnen><en> Use a software like tcpdump or wireshark to capture the data.
<G-vec00169-001-s125><capture.aufzeichnen><de> Das Bild wird Space sichtbar und Ihre Hologramme darüber platziert aufzuzeichnen.
<G-vec00169-001-s125><capture.aufzeichnen><en> The picture will capture both your visible space and your holograms placed on top of it.
<G-vec00169-001-s126><capture.aufzeichnen><de> Klinische Ausbildung auf höchstem Niveau An der Fakultät für Gesundheits- und Sozialwesen kommen darüber hinaus auch Panasonic Remote-Kameras zum Einsatz, um praktische Elemente der Kurse für Perioperativmediziner (ODPs) aufzuzeichnen.
<G-vec00169-001-s126><capture.aufzeichnen><en> Elsewhere within the Health and Social Care faculty, Panasonic remote cameras are used to capture practical elements of the University's Operating Department Practitioner (ODP) course.
<G-vec00254-002-s131><sway.aufzeichnen><de> Die TMS werden verwendet, um die tatsächliche dynamische Schwingbewegung des Baumes in natürlichem Wind aufzuzeichnen.
<G-vec00254-002-s131><sway.aufzeichnen><en> The Tree Motion Sensors (TMS) are used to measure the real dynamic sway motion of trees in natural winds.
<G-vec00115-002-s038><monitor.aufzeichnen><de> Diese anderen Websites können Daten über Sie sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und Ihre Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive Ihrer Interaktion mit dem eingebetteten Inhalt, falls Sie ein Konto haben und auf dieser Website angemeldet sind.
<G-vec00115-002-s038><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s039><monitor.aufzeichnen><de> Diese Websites können Daten über dich sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und deine Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive deiner Interaktion mit dem eingebetteten Inhalt, falls du ein Konto hast und auf dieser Website angemeldet bist.
<G-vec00115-002-s039><monitor.aufzeichnen><en> These websites may collect datas about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s040><monitor.aufzeichnen><de> Diese Websites k├Ânnen Daten ├╝ber dich sammeln, Cookies benutzen, zus├Ątzliche Tracking-Dienste von Dritten einbetten und deine Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive deiner Interaktion mit dem eingebetteten Inhalt, falls du ein Konto hast und auf dieser Website angemeldet bist.
<G-vec00115-002-s040><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s043><monitor.aufzeichnen><de> Wenn diese Konditionen sich entwickeln, können GOES Satelliten die Sturmentwicklung aufzeichnen und ihre Bewegung verfolgen.
<G-vec00115-002-s043><monitor.aufzeichnen><en> When these conditions develop the GOES satellites are able to monitor storm development and track their movements.
<G-vec00115-002-s045><monitor.aufzeichnen><de> Diese Websites können Daten über Sie sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und ihre Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive ihrer Interaktion mit dem eingebetteten Inhalt, falls Sie ein Konto besitzen und auf dieser Website angemeldet sind.
<G-vec00115-002-s045><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s046><monitor.aufzeichnen><de> Diese Websites können Daten über Personen sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und eine Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive einer Interaktion mit dem eingebetteten Inhalt, falls der Nutzer ein Konto hat und auf dieser Website angemeldet ist.
<G-vec00115-002-s046><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s047><monitor.aufzeichnen><de> Diese Websites können persönliche Daten sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und Interaktionen mit diesem eingebetteten Inhalt aufzeichnen, inklusive deiner Interaktion mit dem eingebetteten Inhalt, falls du ein Konto hast und auf dieser Website angemeldet bist.
<G-vec00115-002-s047><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s048><monitor.aufzeichnen><de> Ihr Internetanbieter kann Ihre Aktivität aufzeichnen und mit anderen Organisationen teilen.
<G-vec00115-002-s048><monitor.aufzeichnen><en> Your ISP can monitor your activity and share it with other organizations.
<G-vec00115-002-s049><monitor.aufzeichnen><de> Diese Websites könnten Daten über dich sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und deine Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive deiner Interaktion mit dem eingebetteten Inhalt, falls du ein Konto hast und auf dieser Website angemeldet bist.
<G-vec00115-002-s049><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and logged into that website.
<G-vec00115-002-s051><monitor.aufzeichnen><de> Ich suche kein Smartphone für das Handgelenk, dass meine eingeschränkten körperlichen Aktivitäten bis ins letzte Detail aufzeichnen kann.
<G-vec00115-002-s051><monitor.aufzeichnen><en> I’m not looking for a wearable device that can monitor my (limited) physical activity in great depth.
<G-vec00115-002-s052><monitor.aufzeichnen><de> Diese Websites können Daten über Sie sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und Ihre Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive Ihrer Interaktion mit dem eingebetteten Inhalt, falls Sie ein Konto haben und auf dieser Website angemeldet sind.
<G-vec00115-002-s052><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you Conditions
<G-vec00115-002-s054><monitor.aufzeichnen><de> Diese Websites können Daten √ľber dich sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und deine Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive deiner Interaktion mit dem eingebetteten Inhalt, falls du ein Konto hast und auf dieser Website angemeldet bist.
<G-vec00115-002-s054><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00115-002-s055><monitor.aufzeichnen><de> Diese Websites können Daten über dich sammeln, Cookies benutzen, zusätzliche Tracking-Dienste von Dritten einbetten und Ihre Interaktion mit diesem eingebetteten Inhalt aufzeichnen, inklusive Ihrer Interaktion mit dem eingebetteten Inhalt, falls Sie ein Konto haben und auf dieser Website angemeldet bist.
<G-vec00115-002-s055><monitor.aufzeichnen><en> These websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.
<G-vec00640-002-s076><record.aufzeichnen><de> Dank der MIDI-Funktionalität dieser Instrumente kann das Spiel zur optimalen Beurteilung mit einem Computer aufgezeichnet werden.
<G-vec00640-002-s076><record.aufzeichnen><en> Thanks to the instrument's MIDI functionality, students can even record their performance on their computer.
<G-vec00640-002-s077><record.aufzeichnen><de> Ob und wann aufgezeichnet wird, entscheiden selbstverständlich Sie.
<G-vec00640-002-s077><record.aufzeichnen><en> Of course, you decide if and when you record.
<G-vec00640-002-s078><record.aufzeichnen><de> - In seltenen Fällen wurden Bilder nicht korrekt aufgezeichnet, wenn HDR (High Dynamic Range) im Menü AUFNAHME gewählt war.
<G-vec00640-002-s078><record.aufzeichnen><en> - Images would in rare cases fail to record correctly with HDR (high dynamic range) selected in the SHOOTING MENU.
<G-vec00640-002-s079><record.aufzeichnen><de> Mit zwei SxS-Karten à 64 GB in beiden SxS-Steckplätzen können circa 240 Minuten an Video aufgezeichnet werden.
<G-vec00640-002-s079><record.aufzeichnen><en> Using 64 GB SxS cards in both SxS slots enables you to record approximately 240 minutes of video.
<G-vec00640-002-s080><record.aufzeichnen><de> Denn was ich euch sagen werde, ist nicht in eurer Akasha Chronik aufgezeichnet.
<G-vec00640-002-s080><record.aufzeichnen><en> For what Iím going to tell you is not recorded in your Akashic Record.
<G-vec00640-002-s081><record.aufzeichnen><de> Es werden kurze Videos des Bildschirms aufgezeichnet und an das Webportal gesendet.
<G-vec00640-002-s081><record.aufzeichnen><en> It will record short videos of the screen and send to web portal.
<G-vec00640-002-s082><record.aufzeichnen><de> Das Alarmvideo wird automatisch auf der Micro SD-Karte aufgezeichnet.
<G-vec00640-002-s082><record.aufzeichnen><en> The alarm video will automatically record on the Micro SD card.
<G-vec00640-002-s083><record.aufzeichnen><de> Mithilfe von Cookies (siehe Punkt 2.1 b) werden Deine Mausbewegungen, Dein Klickverhalten, Scrolling sowie Texteingaben auf der Website aufgezeichnet und analysiert.
<G-vec00640-002-s083><record.aufzeichnen><en> Cookies (see Section 2.1 b) are used to record and analyse your mouse movements, click behaviour, scrolling and text input on the website.
<G-vec00640-002-s085><record.aufzeichnen><de> Mit Enable diagnostic packet and event recordings werden alle aufgetretenen Ereignisse aufgezeichnet.
<G-vec00640-002-s085><record.aufzeichnen><en> Enable diagnostic packet and event recordings will record any events that occurred. 3.
<G-vec00640-002-s086><record.aufzeichnen><de> Hospitality-Betriebe können ZyWALL VPN mit Hotspot-Verwaltungsfunktionen implementieren, die sichere Netzwerkdienste, wie etwa hochentwickelte Abrechnung für flexible kostenlose und gestaffelte WLAN-Dienste, zur Verfügung stellen, wobei gleichzeitig die Internetnutzung aufgezeichnet wird, um lokale Regelungen zur Vorratsdatenspeicherung zu erfüllen.
<G-vec00640-002-s086><record.aufzeichnen><en> Hospitality businesses can deploy ZyWALL VPN with Hotspot Management features that provide secure network services such as advanced billing for flexible free and tiered Wi-Fi services while retaining the Internet usage record to comply with local regulations.
<G-vec00640-002-s087><record.aufzeichnen><de> Klicken Sie auf der letzten Seite unbedingt auf Fertig, damit die Umfragebeantwortung aufgezeichnet wird.
<G-vec00640-002-s087><record.aufzeichnen><en> Make sure to click Done on the last page to record the survey response.
<G-vec00640-002-s088><record.aufzeichnen><de> Durch den 54 MB großen internen Speicher kann eine große Menge hochauflösender Bilddaten aufgezeichnet werden.
<G-vec00640-002-s088><record.aufzeichnen><en> The 54 MB of internal memory makes it possible to record large-volume high-definition image data.
<G-vec00640-002-s089><record.aufzeichnen><de> Nein, derzeit können Sitzungen nicht mit einem iOS-Gerät aufgezeichnet werden.
<G-vec00640-002-s089><record.aufzeichnen><en> No, you cannot currently record sessions from an Android device.
<G-vec00640-002-s090><record.aufzeichnen><de> Wie Sie vielleicht gehört haben, müssen Websites nach EU-Recht nun die Erlaubnis zur Verwendung von Cookies einholen, und Benutzer können Cookies deaktivieren, mit denen ihre Surfgewohnheiten jederzeit aufgezeichnet werden können.
<G-vec00640-002-s090><record.aufzeichnen><en> As you may have heard, according to EU law, websites now have to ask for permission to use cookies, and users can turn off cookies that may record their browsing habits at any time.
<G-vec00640-002-s091><record.aufzeichnen><de> In Transportprotokollen wird aufgezeichnet, welche Aktionen für Nachrichten ausgeführt werden, während diese über die Transportpipeline übermittelt werden.
<G-vec00640-002-s091><record.aufzeichnen><en> Transport logs record what happens to messages as they flow through the transport pipeline.
<G-vec00640-002-s092><record.aufzeichnen><de> Sobald sie in der Lage waren, Informationen über mindestens 10 Spins zu sammeln, wurde aufgezeichnet, wie viele Spins sie jedes Mal benötigten.
<G-vec00640-002-s092><record.aufzeichnen><en> Once they have been able to gather the information on at least 10 spins, keeping a record of how many spins it took each time.
<G-vec00640-002-s093><record.aufzeichnen><de> Wenn Sie diese Funktion auswählen, werden Ihr Reiseverlauf sowie Ihre Streckenstatistiken und Kilometerleistung automatisch aufgezeichnet.
<G-vec00640-002-s093><record.aufzeichnen><en> JOURNEY HISTORY This opt-in feature can automatically record your journey history including your route and mileage statistics.
<G-vec00640-002-s094><record.aufzeichnen><de> DIES ist IHR Aufstieg, und es ist nicht der einzige, nur der erste, der aufgezeichnet wird.
<G-vec00640-002-s094><record.aufzeichnen><en> THIS is HER Ascension, and its not the only one, just the first one of record.
<G-vec00640-002-s133><record.aufzeichnen><de> Schritt 1: Klicken Sie auf die Taste Video aufzeichnen.
<G-vec00640-002-s133><record.aufzeichnen><en> Step 1 Click the Record Video button
<G-vec00640-002-s134><record.aufzeichnen><de> Das ist vor allem dann interessant, wenn man Musik von Webseiten wie YouTube, Pandora oder Spotify aufzeichnen will.
<G-vec00640-002-s134><record.aufzeichnen><en> The gist of it is that this lets you record audio from websites such as YouTube, Pandora, and Spotify.
<G-vec00640-002-s135><record.aufzeichnen><de> Start8_32.dll kann Eingaben aufzeichnen und andere Programme manipulieren.
<G-vec00640-002-s135><record.aufzeichnen><en> Start8_32.dll is able to record keyboard and mouse inputs and manipulate other programs.
<G-vec00640-002-s136><record.aufzeichnen><de> Sie können Grüße hochladen oder aufzeichnen, Menüs erstellen und im Handumdrehen Änderungen vornehmen, um das Kundenerlebnis wie gewünscht anzupassen.
<G-vec00640-002-s136><record.aufzeichnen><en> Upload or record greetings, build menus and easily make changes to customise your customers' experiences. More Resources Phone support 101
<G-vec00640-002-s137><record.aufzeichnen><de> Außerdem muss die Organisation die Gültigkeit früherer Messergebnisse bewerten und aufzeichnen, wenn festgestellt wird, dass die Messmittel die Anforderungen nicht erfüllen.
<G-vec00640-002-s137><record.aufzeichnen><en> In addition, the organization shall assess and record the validity of the previous measuring results when the equipment is found not to confirm to requirements.
<G-vec00640-002-s138><record.aufzeichnen><de> Sobald die beiden Satelliten als gemeinsames "Augenpaar" ihre Daten aufzeichnen, beginnt das "diffizile Zusammenspiel", sagt Projektleiter Michael Bartusch.
<G-vec00640-002-s138><record.aufzeichnen><en> As soon as the satellites begin to record data as a combined ‘pair of eyes’, the ‘complex interactions’ begin, says project leader Michael Bartusch.
<G-vec00640-002-s139><record.aufzeichnen><de> Alle mit Benachrichtigung aufzeichnen: Bei Auswahl dieser Richtlinie werden alle Sitzungen aufgezeichnet.
<G-vec00640-002-s139><record.aufzeichnen><en> Record everyone with notification. If you choose this policy, all sessions are recorded.
<G-vec00640-002-s140><record.aufzeichnen><de> Die Datei GDKBFlt64.sys ist ein Tastaturtreiber und kann Tastatureingaben aufzeichnen.
<G-vec00640-002-s140><record.aufzeichnen><en> The file is a keyboard driver, can record inputs.
<G-vec00640-002-s141><record.aufzeichnen><de> Wir können Telefonanrufe zu Schulungs- und Qualitätskontrollzwecken aufzeichnen und überwachen sowie zur Überprüfung von Vertragsdetails, die wir mit Ihnen telefonisch vereinbaren, nutzen.
<G-vec00640-002-s141><record.aufzeichnen><en> We may record and monitor telephone calls for training and quality control purposes as well as to verify the details of any contract we may agree with you over the phone.
<G-vec00640-002-s142><record.aufzeichnen><de> BRNIPMON.exe kann Eingaben aufzeichnen.
<G-vec00640-002-s142><record.aufzeichnen><en> BRNIPMON.exe is able to record keyboard and mouse inputs.
<G-vec00640-002-s143><record.aufzeichnen><de> Ein Thermotransfer kann in einfacher Weise verschiedene Informationen aufzeichnen und wird folglich bei vielen Anwendungen umfangreich verwendet.
<G-vec00640-002-s143><record.aufzeichnen><en> Thermal transfer can easily record variable information and thus is extensively used in a wide variety of applications.
<G-vec00640-002-s144><record.aufzeichnen><de> Dragon.exe kann andere Programme manipulieren, Programme überwachen und Eingaben aufzeichnen.
<G-vec00640-002-s144><record.aufzeichnen><en> Shellker.exe is able to monitor applications and record keyboard and mouse inputs.
<G-vec00640-002-s145><record.aufzeichnen><de> Mit der optionalen internen Festplatte lassen sich Messungen in Echtzeit auf einer Festplatte aufzeichnen.
<G-vec00640-002-s145><record.aufzeichnen><en> With the optional internal hard drive, you can record measurements to the hard drive in real time.
<G-vec00640-002-s146><record.aufzeichnen><de> Dieser Keylogger für iPad kann auch alle Web- und E-Mail-Aktivitäten aufzeichnen, Momentaufnahmen machen, den genauen Standort des iPads anhand der IP-Adresse nachverfolgen und verhindern, dass unerwünschte Anwendungen auf dem iPad ausgeführt werden.
<G-vec00640-002-s146><record.aufzeichnen><en> This keylogger for iPad can also record all web and email activities, take snapshots, track the exact location of the iPad by IP address, and block some unwanted applications from running on the iPad.
<G-vec00640-002-s147><record.aufzeichnen><de> Stellen Sie einfach eine bestimmte Zeitspanne ein, in der Ihr Samsung Audiosystem aufzeichnen soll, und schon verpassen Sie kein Radioprogramm mehr.
<G-vec00640-002-s147><record.aufzeichnen><en> By letting your audio start recording at a particular time that you’ve set and record only for a certain length of time as you like, Samsung Audio System allows you not to miss any single radio program that you like.
<G-vec00640-002-s148><record.aufzeichnen><de> Vncserver.exe kann Internet Verbindung aufbauen, Eingaben aufzeichnen und andere Programme manipulieren.
<G-vec00640-002-s148><record.aufzeichnen><en> Vncserver.exe is able to connect to the Internet, record keyboard and mouse inputs and manipulate other programs.
<G-vec00640-002-s149><record.aufzeichnen><de> * Fügen Sie Ihre eigenen Notizen zu allen Anlagen, die besten Sorten und Erfolge und Misserfolge aufzeichnen.
<G-vec00640-002-s149><record.aufzeichnen><en> * Add your own notes to any plants to record the best varieties and successes and failures.
<G-vec00640-002-s150><record.aufzeichnen><de> Beim Aufzeichnen eines Makros zeichnet Excel einige Befehle mithilfe von Z1S1-Bezügen auf.
<G-vec00640-002-s150><record.aufzeichnen><en> When you record a macro, Excel records some commands by using the R1C1 reference style.
<G-vec00640-002-s151><record.aufzeichnen><de> Es kann sein, dass wir, um unsere Dienstleistungen (nachstehend definiert) erbringen zu können, automatisch Ihre personenbezogenen Daten (nachstehend definiert) erheben und aufzeichnen, die direkt von Benutzern durch ihre Nutzung der Dienstleistungen oder durch von Dritten zur Verfügung gestellte öffentliche Informationen erhalten werden.
<G-vec00640-002-s151><record.aufzeichnen><en> In order to provide our Services (defined below), we may automatically collect and record your Personal Data (defined below), provided directly by users through their use of the Services or public information provided by third parties.
<G-vec00640-002-s209><record.aufzeichnen><de> - "Web Beacons", "Tags" und "Pixel" sind elektronische Dateien, die dazu verwendet werden, Informationen darüber aufzuzeichnen, wie Sie die Site durchsuchen.
<G-vec00640-002-s209><record.aufzeichnen><en> – “Web beacons”, “tags”, and “pixels” are electronic files used to record information about how you browse the Site. – Google analytics
<G-vec00640-002-s210><record.aufzeichnen><de> Es besagt, dass dieser Keylogger für Mac vorzuziehen ist und über die Funktionen verfügt, um die vom Benutzer eingegebenen Tastenanschläge aufzuzeichnen.
<G-vec00640-002-s210><record.aufzeichnen><en> It says that this keylogger is preferable for mac and it has the features to record the keystrokes typed by the user.
<G-vec00640-002-s211><record.aufzeichnen><de> GIS-Vertragspartner verwenden den robusten Handheld Nautiz X8 um Leitungsmastmessungen für Telekommunikationsunternehmen aufzuzeichnen und dadurch erhöhen sie die Effizienz, sparen viel Zeit und steigern die Gewinne.
<G-vec00640-002-s211><record.aufzeichnen><en> GIS contractors are using Handheld’s Nautiz X8 rugged data collector to record utility pole measurements for telecommunications companies — and as a result they’re improving efficiency, saving significant time, and increasing profits.
<G-vec00640-002-s212><record.aufzeichnen><de> - FireDTV Viewer-Software zum Fernsehkanäle anschauen und aufzuzeichnen.
<G-vec00640-002-s212><record.aufzeichnen><en> - FireDTV Viewer Software to watch and record TV channels.
<G-vec00640-002-s213><record.aufzeichnen><de> Es sollte nicht verwendet werden, um die Sicherheit zu überwachen oder um vertrauliche oder herstellereigene Informationen aufzuzeichnen.
<G-vec00640-002-s213><record.aufzeichnen><en> It should not be used to audit security or to record confidential or proprietary information.
<G-vec00640-002-s214><record.aufzeichnen><de> Das bedeutet, dass Cookies von Dritten gesetzt werden können, um Deine Online-Aktivitäten aufzuzeichnen.
<G-vec00640-002-s214><record.aufzeichnen><en> This means that cookies can be set by third parties to record your online activity.
<G-vec00640-002-s215><record.aufzeichnen><de> Allerdings behält sich BNEE das Recht vor, Online-Aktivitäten in den Diensten zu überwachen und/oder aufzuzeichnen und Sie erteilen BNEE Ihr ausdrückliches Einverständnis zur Überwachung und Aufzeichnung Ihrer Aktivitäten.
<G-vec00640-002-s215><record.aufzeichnen><en> However, BNEE reserves the right to monitor and/or record any online activity on the Services and you give BNEE your express consent to monitor and record your activities.
<G-vec00640-002-s216><record.aufzeichnen><de> Euro Babble verwendet Google Analytics, um das Engagement der Nutzer zu verfolgen und aufzuzeichnen.
<G-vec00640-002-s216><record.aufzeichnen><en> Euro Babble utilises Google Analytics, to track and record user engagement.
<G-vec00640-002-s217><record.aufzeichnen><de> Es ist der Versuch, etwas aufzuzeichnen.
<G-vec00640-002-s217><record.aufzeichnen><en> It is an attempt at a record.
<G-vec00640-002-s218><record.aufzeichnen><de> “Durch die Steigerungen sowohl beim Arbeitsanfall als auch bei der Notwendigkeit, mehr Informationen aufzuzeichnen, wurde es für uns wichtig, an Ort und Stelle und auf Knopfdruck aktuelle Informationen und Vorschriften abrufen zu können anstatt ins Büro zurückzukehren und sich vor den PC setzen zu müssen.
<G-vec00640-002-s218><record.aufzeichnen><en> “With an increase in both workloads and the need to record greater levels of information, it became important for us to be able to access up-to-date information and legislation at the point required and at the touch of a button, rather than having to be back in the office in front of the PC.
<G-vec00640-002-s219><record.aufzeichnen><de> Beispielsweise zeigen uns Analyse-Cookies, welche Seiten auf den Websites am häufigsten besucht werden, helfen uns, Ihre Schwierigkeiten mit den Websites aufzuzeichnen und geben an, ob unsere Werbung effektiv ist oder nicht.
<G-vec00640-002-s219><record.aufzeichnen><en> For example, analytics cookies show us which are the most frequently visited pages on the Sites, help us record any difficulties you have with the Sites, and show us whether our advertising is effective or not.
<G-vec00640-002-s220><record.aufzeichnen><de> Die Verdichtungsmesserwert-Technologie arbeitet mit einem Beschleunigungsmesser an der Bandage, um die Kräfte der Vibrationsbandage zu messen und aufzuzeichnen.
<G-vec00640-002-s220><record.aufzeichnen><en> Compaction Meter Value technology uses a drum-mounted accelerometer to measure and record forces of the vibrating drums.
<G-vec00640-002-s221><record.aufzeichnen><de> Wir verwenden diese Cookies, um uns die Daten und Uhrzeiten Ihrer Besuche zu merken, um Sie als Besucher über Geräte hinweg zu erkennen, um uns Verlauf und Inhalt Ihrer Bestellungen zu merken und um Ihre Präferenzen aufzuzeichnen, damit Sie bestimmte Informationen nicht erneut eingeben müssen.
<G-vec00640-002-s221><record.aufzeichnen><en> We use these cookies to remember the dates and times of your visits, to recognise you as a visitor across devices, to remember the history and content of your orders and to record your preferences, so that you do not have to enter certain information again.
<G-vec00640-002-s222><record.aufzeichnen><de> Es ist jetzt möglich, jede Audio-Quelle (n) mit jeder Audio-Anwendung (en) auf einfache Weise zu verbinden, zu mischen und aufzuzeichnen, mit einer unübertroffenen...
<G-vec00640-002-s222><record.aufzeichnen><en> It is now possible to connect, mix and record any audio source(s) with any audio application(s) in an easy way with unparalleled control on sound quality.
<G-vec00640-002-s223><record.aufzeichnen><de> Die in der Vollversion von Photoshop angebotenen Aktionen sparen sehr viel Zeit ein und ermöglichen Nutzern, sich wiederholende Aufgaben aufzuzeichnen und sie anschließend mit einem Klick abzuspielen.
<G-vec00640-002-s223><record.aufzeichnen><en> Buy Full Version In full Photoshop, actions are a great time saver allowing users to record their repeating tasks and replay those afterwards with a click.
<G-vec00640-002-s224><record.aufzeichnen><de> Ihre Zweckbestimmung ist es, Daten im Zusammenhang mit Fahreraktivitäten aufzuzeichnen, zu speichern, anzuzeigen, zu drucken und auszugeben.
<G-vec00640-002-s224><record.aufzeichnen><en> Its purpose is to record, store, display, print and output data related to driver activities.
<G-vec00640-002-s225><record.aufzeichnen><de> Es ist möglich, Aobo Mac Keylogger auf Mac-Computern aufzuzeichnen.
<G-vec00640-002-s225><record.aufzeichnen><en> It’s possible to record make Aobo Mac Keylogger record passwords on Mac computers.
<G-vec00640-002-s226><record.aufzeichnen><de> Pasteboard Recorder ist eine Anwendung, ein Inhalt Ihrer Zwischenablage von Mac OS X automatisch aufzuzeichnen.
<G-vec00640-002-s226><record.aufzeichnen><en> Pasteboard Recorder is an application to record a content of your pasteboard of Mac OS X automatically.
<G-vec00640-002-s227><record.aufzeichnen><de> Ich autorisiere VIP VideoChat ausdrücklich dazu, all meine Online-Aktivitäten auf der Webseite (einschließlich Chat, Video, E-Mail) zu überwachen, aufzuzeichnen und protokollieren.
<G-vec00640-002-s227><record.aufzeichnen><en> I expressly authorize VIP VideoChat to monitor, record and log all my online activities on the website (including chat, video, email).
<G-vec00640-002-s760><record.aufzeichnen><de> Halten Sie besondere Momente in einem Skype-Anruf mit Ihren Lieben fest oder zeichnen Sie wichtige Besprechungen mit Kollegen auf.
<G-vec00640-002-s760><record.aufzeichnen><en> Capture those special moments in a Skype call with your loved ones or record important meeting with colleagues.
<G-vec00640-002-s761><record.aufzeichnen><de> Wenn Sie Google kontaktieren, zeichnen wir möglicherweise Ihre Kommunikation auf, um Ihnen bei der Lösung etwaiger bei Ihnen auftretender Probleme behilflich zu sein.
<G-vec00640-002-s761><record.aufzeichnen><en> When you contact CSI, we may keep a record of your communication to help resolve any issues that you might be facing.
<G-vec00640-002-s762><record.aufzeichnen><de> Um das zu erreichen, zeichnen wir Daten des Fahrzeuges auf, während Sie es auf der Rennstrecke bewegen.
<G-vec00640-002-s762><record.aufzeichnen><en> In order to obtain that, we record the vehicle data during your efforts on the race track.
<G-vec00640-002-s763><record.aufzeichnen><de> Für beste Ergebnisse zeichnen Sie die Sprachbefehle am besten auf, während Sie das Headset tragen.
<G-vec00640-002-s763><record.aufzeichnen><en> For better reception, record the voice tags from the headset if your phone allows you to do so.
<G-vec00640-002-s764><record.aufzeichnen><de> Zum Beispiel bieten L-GATE Gateways neben der reinen Gateway-Funktionalität auch eine grafische Benutzerschnittstelle zur dynamischen Anlagenvisualisierung über Webtechnologien oder sie funktionieren als Alarm-Server, zeichnen Trenddaten auf oder arbeiten Zeitschaltprogramme ab.
<G-vec00640-002-s764><record.aufzeichnen><en> For example, the L-GATE as a typical gateway also has the ability to host a graphical user interface to dynamically visualize a site or record historic data in trend logs.
<G-vec00640-002-s765><record.aufzeichnen><de> Sie zeichnen ihre erstaunliche Wahrheit und Auswirkung auf.
<G-vec00640-002-s765><record.aufzeichnen><en> They record its amazing truth and effect.
<G-vec00640-002-s766><record.aufzeichnen><de> Zeichnen Sie Ihre PowerPoint-Inhalte als Video auf, und fügen Sie Interaktionen und Fragen zur Wissensüberprüfung als Overlays hinzu.
<G-vec00640-002-s766><record.aufzeichnen><en> Record your PowerPoint content as a video and add interactive overlays
<G-vec00640-002-s767><record.aufzeichnen><de> Zeichnen Sie automatisch die Lage Ihrer Tauchplätze auf, basierend auf den GPS-Daten Ihres Mobilgeräts.
<G-vec00640-002-s767><record.aufzeichnen><en> Automatically record the location of your dives, based on your mobile device’s GPS locator Other details
<G-vec00640-002-s768><record.aufzeichnen><de> Hören Sie laufenden Gesprächen zu oder zeichnen Sie diese zur späteren Prüfung auf.
<G-vec00640-002-s768><record.aufzeichnen><en> Listen live to interviews in progress or record them for future review.
<G-vec00640-002-s769><record.aufzeichnen><de> Protokollinformationen – Wenn Sie HostBox-Dienstleistungen nutzen, zeichnen unsere Server automatisch Informationen auf, die Ihr Browser immer dann sendet, wenn Sie eine Webanwendung nutzen.
<G-vec00640-002-s769><record.aufzeichnen><en> Log information – When you access The Proper Moose services, our servers automatically record information that your browser sends whenever you visit a website.
<G-vec00640-002-s770><record.aufzeichnen><de> Zusätzlich zeichnen unsere Server weder deine Nutzungsdaten noch Verbindungsinformationen auf.
<G-vec00640-002-s770><record.aufzeichnen><en> For your safety, we do not record any usage data or connection logs.
<G-vec00640-002-s771><record.aufzeichnen><de> Die beiden Stereo-Array-Mikrofone an der Oberkante des Surface zeichnen Ton in verhältnismäßig guter Qualität auf und erzeugen eine gute Stimmwiedergabe bei Videotelefonie.
<G-vec00640-002-s771><record.aufzeichnen><en> The two stereo-array microphones on the top edge of the Surface record sound in relatively good quality and provide good voice quality in video chats.
<G-vec00640-002-s772><record.aufzeichnen><de> Targeting-Cookies zeichnen Ihre Besuche auf unserer Seite, die einzelnen besuchten Seiten und die Links auf, denen Sie gefolgt sind.
<G-vec00640-002-s772><record.aufzeichnen><en> These cookies record your visit to our site, the pages you have visited and the links you have followed.
<G-vec00640-002-s773><record.aufzeichnen><de> Die Leistungsindikatoren des Objekts "Sammlungsclient" zeichnen die Leistungsstatistik aus der Perspektive einer einzelnen Weiterleitung auf.
<G-vec00640-002-s773><record.aufzeichnen><en> The Collector Client counters record performance statistics from the perspective of a single ACS forwarder.
<G-vec00640-002-s774><record.aufzeichnen><de> Diese Cookies zeichnen Ihren Besuch auf unserer Website, die von Ihnen besuchten Seiten und die von Ihnen angeklickten Links auf.
<G-vec00640-002-s774><record.aufzeichnen><en> These record your visit to this Site, the pages you have visited and the links you have followed.
<G-vec00640-002-s775><record.aufzeichnen><de> Verwaltungsereignisse sind bei der Konfiguration eines Pfads standardmäßig aktiviert und zeichnen unterstützte Aktivitäten auf Kontoebene auf.
<G-vec00640-002-s775><record.aufzeichnen><en> Management events are enabled by default when you configure a trail and record supported activity at the account level.
<G-vec00640-002-s776><record.aufzeichnen><de> - Zeichnen Sie Ihre Blutzuckermesswerte in mg/dl oder mmol/l auf.
<G-vec00640-002-s776><record.aufzeichnen><en> - Record your blood glucose either in mg/dl or mmol/l
<G-vec00640-002-s777><record.aufzeichnen><de> Sie zeichnen Transaktionen auf und bestätigen sie, danach werden sie Teil des neuen Systems.
<G-vec00640-002-s777><record.aufzeichnen><en> They record transactions and confirm them, after which they become a part of the new system.
<G-vec00640-002-s778><record.aufzeichnen><de> Erstellen Sie benutzerdefinierte Daten-, Audio- und Mixed-Mode-Projekte und zeichnen Sie diese sowohl auf physische Disks als auch auf Disk-Images auf.
<G-vec00640-002-s778><record.aufzeichnen><en> Create custom data, audio and mixed-mode projects and record them to physical discs as well as disc images.
<G-vec00640-002-s779><record.aufzeichnen><de> Dieses Video Capture-Gerät zeichnet keine digital verschlüsselten Inhalte auf.
<G-vec00640-002-s779><record.aufzeichnen><en> This video capture device will not record digitally encrypted content.
<G-vec00640-002-s780><record.aufzeichnen><de> Haben Sie das Pech, dass Ihr Fahrzeug zweimal hintereinander angestoßen wird, zeichnet die Dashcam auch dies wieder automatisch auf und erfasst beide Vorfälle.
<G-vec00640-002-s780><record.aufzeichnen><en> If you are unlucky enough to be hit twice in a row then the dash cam would automatically record again and capture both events.
<G-vec00640-002-s781><record.aufzeichnen><de> Hotjar verfolgt oder zeichnet keine Besucher auf, bei denen Cookies deaktiviert sind.
<G-vec00640-002-s781><record.aufzeichnen><en> Hotjar does not track or record visitors which have cookies disabled.
<G-vec00640-002-s783><record.aufzeichnen><de> Google zeichnet diese personenbezogenen Informationen ferner mit dem Zweck auf, die unterschiedlichen Dienste von Google zu verbessern oder zu optimieren.
<G-vec00640-002-s783><record.aufzeichnen><en> Google will also record this personal information with the purpose of improving or optimizing the different services of Google.
<G-vec00640-002-s784><record.aufzeichnen><de> Es zeichnet die Botschaften auf, die zwischen dem AUT und seinen eingeschränkten Abhängigkeiten ausgetauscht werden – und lernt auf diese Weise automatisch die erwarteten Interaktionen.
<G-vec00640-002-s784><record.aufzeichnen><en> We record the messages exchanged between the AUT and its constrained dependencies— automatically learning the expected interactions by listening in on their “conversations.”
<G-vec00640-002-s785><record.aufzeichnen><de> Er zeichnet für jede dieser Schweißungen Einzelheiten der Schweißprogramme und alle Schweißparameter wie den Schweißstrom, die Elektrodenspannung, die Energie, den Widerstand, sowie Eindringtiefe und Kraft auf.
<G-vec00640-002-s785><record.aufzeichnen><en> Each data record is comprised of the weld values like current, voltage, energy, resistance, penetration and force. Further a time/date tag and information about the crossed limits and fault status are stored.
<G-vec00640-002-s786><record.aufzeichnen><de> Diese Software zeichnet möglicherweise Daten auf, beispielsweise wie oft Sie die App nutzen, die Ereignisse in der App, aggregierte Nutzungsdaten, Performance-Daten und von wo die App heruntergeladen wurde.
<G-vec00640-002-s786><record.aufzeichnen><en> This software may record information such as how often you use the application, the events that occur within the application, aggregated usage, performance data, and where the application was downloaded from.
<G-vec00640-002-s787><record.aufzeichnen><de> Es zeichnet die iPad-Aktivitäten auf und sendet die Aktivitätsprotokolle über die Internetverbindung an Ihre E-Mail-Adresse oder Ihren FTP-Bereich.
<G-vec00640-002-s787><record.aufzeichnen><en> It will record the iPad activities and send the activity logs to your email or FTP space via the Internet connection.
<G-vec00640-002-s788><record.aufzeichnen><de> Unter 'Bei Bewegungserkennung' oder 'Immer aufnehmen' zeichnet die Kamera auf.
<G-vec00640-002-s788><record.aufzeichnen><en> At 'Only on detection' or 'Always record' the camera will record.
<G-vec00640-002-s789><record.aufzeichnen><de> Ein kleiner Sensor am Handgelenk wird die ganze Zeit getragen und zeichnet die Bewegungsaktivität auf.
<G-vec00640-002-s789><record.aufzeichnen><en> A small sensor on the wrist needs to be worn all the time to record the movement activity.
<G-vec00640-002-s790><record.aufzeichnen><de> Wenn Sie diese Option nicht aktivieren, zeichnet Document Security keine Ereignisse für Dokumente auf, die der Richtlinie zugeordnet sind.
<G-vec00640-002-s790><record.aufzeichnen><en> If you do not select this option, document security does not record events for documents that are associated with the policy.
<G-vec00640-002-s791><record.aufzeichnen><de> Der Timer unten links zeichnet die Zeit auf, die Sie brauchen, wogegen die Anzahl Ihrer Spielzüge über dem Timer gezählt wird.
<G-vec00640-002-s791><record.aufzeichnen><en> The timer at the lower left corner will record the time you have spent, while your number of moves will be counted above the timer.
<G-vec00640-002-s792><record.aufzeichnen><de> Die Funktion „Support Tickets“ zeichnet alle laufenden und gelösten Tickets für Sie auf, die nach Ticket-ID, Auftrags-ID oder Transaktions-ID durchsucht werden können.
<G-vec00640-002-s792><record.aufzeichnen><en> Support Tickets keeps a record of all on-going and resolved tickets for you, and they are searchable by ticket id, order id, or transaction id.
<G-vec00640-002-s793><record.aufzeichnen><de> Time Doctor Desktop-Anwendung zeichnet die Anzahl Ihrer Tastatureingaben oder Mausbewegungen auf.
<G-vec00640-002-s793><record.aufzeichnen><en> The Time Doctor desktop app does record the number of keystrokes or mouse movements you make.
<G-vec00640-002-s794><record.aufzeichnen><de> Die von DVB-Karten mitgelieferte Software zeichnet Aufnahmen jedoch NICHT im Format TS (Transport Stream) auf, welches zur Nutzung unserer Produkte zwingend erforderlich ist.
<G-vec00640-002-s794><record.aufzeichnen><en> However, the DVB PC TV Card's accompanying producer software does NOT record recordings in the TS format, which is mandatory for the use of our products.
<G-vec00640-002-s795><record.aufzeichnen><de> Er zeichnet einen Datensatz von jedem der Latino White und African-American Säuglinge zwischen 1989 und 1991 mit ihrer Mutter zwischen 1956 und 1975 basierend auf angehängten United States Volkseinkommensinformationen.
<G-vec00640-002-s795><record.aufzeichnen><en> He record a dataset of each of -Latino White and African-American infants between 1989 and 1991with their mother between 1956 and 1975 base on appended United States census income information.
<G-vec00640-002-s796><record.aufzeichnen><de> Die App zeichnet alle Funktionen auf, die mit dem Android-Telefon ausgeführt werden, einschließlich Kurzmitteilungen, Anrufen, Surfen im Internet, Bildern und Videos, GPS-Navigation, installierten Apps und bestimmten Social Media- und Kommunikations-Apps wie Facebook, Twitter, Youtube, Gmail, Whatsapp, Viber und so weiter.
<G-vec00640-002-s796><record.aufzeichnen><en> The app will record each and every function performed using the Android phone including text messages, calls, internet browsing, pictures and videos, GPS navigation, apps installed, and certain social media and communication apps such as Facebook, Twitter, Youtube, Gmail, Whatsapp, Viber and so on.
<G-vec00640-002-s797><record.aufzeichnen><de> Ein Cookie identifiziert nicht den Internetnutzer; jedoch zeichnet es Informationen zur Navigation auf einer Webseite auf, insbesondere angesehene Seiten, Datum und Uhrzeit des Besuchs.
<G-vec00640-002-s797><record.aufzeichnen><en> A cookie does not contain information that identifies Internet Users; however, it does record information about their browsing on a Site, including the pages viewed and the time and date of viewing.
