<G-vec00057-001-s076><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Mandarin, Englisch.
<G-vec00057-001-s076><speak.beherrschen><en> I can speak the following languages fluently: Chinese Mandarin, English.
<G-vec00057-001-s077><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Francés, Español, Inglés, Latín.
<G-vec00057-001-s077><speak.beherrschen><en> I can speak the following languages fluently: French, English, Latin, Spanish.
<G-vec00057-001-s078><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Hindi, Bengalí.
<G-vec00057-001-s078><speak.beherrschen><en> I can speak the following languages fluently: Hindi, Bengali.
<G-vec00057-001-s079><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Inglés, Alemán, Francés.
<G-vec00057-001-s079><speak.beherrschen><en> I can speak the following languages fluently: English, French, German.
<G-vec00057-001-s080><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Español, Catalán, Inglés, Italiano.
<G-vec00057-001-s080><speak.beherrschen><en> I can speak the following languages fluently: Spanish, Catalan, English, Italian.
<G-vec00057-001-s081><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Japanisch, Englisch, Niederländisch.
<G-vec00057-001-s081><speak.beherrschen><en> I can speak the following languages fluently: Japanese, Dutch, English.
<G-vec00057-001-s082><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Chino Mandarín, Inglés.
<G-vec00057-001-s082><speak.beherrschen><en> I can speak the following languages fluently: Chinese Mandarin, English.
<G-vec00057-001-s083><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Isländisch, Dänisch, Englisch, Norwegisch, Schwedisch.
<G-vec00057-001-s083><speak.beherrschen><en> I can speak the following languages fluently: Icelandic, Danish, English, Norwegian, Swedish.
<G-vec00057-001-s084><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Deutsch, Englisch, Koreanisch.
<G-vec00057-001-s084><speak.beherrschen><en> I can speak the following languages fluently: German, English, Korean.
<G-vec00057-001-s085><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Englisch, Französisch, Russisch.
<G-vec00057-001-s085><speak.beherrschen><en> I can speak the following languages fluently: English, French, Russian.
<G-vec00057-001-s086><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Chino Mandarín, Chino Cantonés, Inglés.
<G-vec00057-001-s086><speak.beherrschen><en> I can speak the following languages fluently: Chinese Mandarin, Chinese Cantonese, English.
<G-vec00057-001-s087><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Spanisch, Deutsch, Englisch, Französisch, Russisch.
<G-vec00057-001-s087><speak.beherrschen><en> I can speak the following languages fluently: Spanish, English, French, German, Russian.
<G-vec00057-001-s088><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Englisch, Deutsch, Portugiesisch - Bras, Spanisch.
<G-vec00057-001-s088><speak.beherrschen><en> I can speak the following languages fluently: English, German, Portuguese - Brazil, Spanish.
<G-vec00057-001-s089><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Norwegisch, Englisch, Russisch.
<G-vec00057-001-s089><speak.beherrschen><en> I can speak the following languages fluently: Norwegian, English, Russian.
<G-vec00057-001-s090><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Französisch, Englisch.
<G-vec00057-001-s090><speak.beherrschen><en> I can speak the following languages fluently: French, English.
<G-vec00057-001-s091><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Español, Catalán, Francés, Inglés.
<G-vec00057-001-s091><speak.beherrschen><en> I can speak the following languages fluently: Spanish, Catalan, English, French.
<G-vec00057-001-s092><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Griego, Inglés, Italiano.
<G-vec00057-001-s092><speak.beherrschen><en> I can speak the following languages fluently: Greek, English, Italian.
<G-vec00057-001-s093><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Griego, Inglés, Italiano, Portugués - Europa.
<G-vec00057-001-s093><speak.beherrschen><en> I can speak the following languages fluently: Greek, English, Italian, Portuguese - Europe.
<G-vec00057-001-s094><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Dutch, English, Flemish, French, Norwegian.
<G-vec00057-001-s094><speak.beherrschen><en> I can speak the following languages fluently: Dutch, English, Flemish, French, Norwegian.
<G-vec00367-001-s029><restrain.beherrschen><de> Und dann kam der alte Großmeister auch noch aus der Umkleidekabine heraus und konnte sich kaum beherrschen.
<G-vec00367-001-s029><restrain.beherrschen><en> Soon the grandmastercame out of the locker room. He was completely pissed off and could hardly restrain himself.
<G-vec00367-001-s030><restrain.beherrschen><de> Erst als ein Falun Gong-Praktizierender namens Li Xinze, der zur gleichen Zeit eingesperrt und zu Tode gefoltert wurde, die Aufmerksamkeit der internationalen Gemeinschaft erregte, fing die Gefängnispolizei an sich zu beherrschen.
<G-vec00367-001-s030><restrain.beherrschen><en> It was not until a Falun Gong practitioner named Li Xinze, who was jailed with him at the same time was tortured to death and it aroused the concern of the international community that the prison police started to restrain themselves.
<G-vec00367-001-s031><restrain.beherrschen><de> Als ich Euch dort hinauf schickte, vergaß ich Euch gegenüber zu erwähnen, daß die Höhle von Devas beschützt ist, und Euch zu warnen, daß Ihr Euch beherrscht und die ganze Zeit passend benehmt.
<G-vec00367-001-s031><restrain.beherrschen><en> When I sent you up there, I forgot to mention that the cave is protected by devas and to warn you to restrain yourselves and behave properly the whole time.
<G-vec00214-002-s048><dominate.beherrschen><de> Der „Gefällt mir „ Knopf erscheint heutzutage auf fast allen Webseiten, und Facebook beherrscht immer noch die sozialen Raum.
<G-vec00214-002-s048><dominate.beherrschen><en> The 'Like' button appears almost everywhere on the web these days, and Facebook continues to dominate the social space.
<G-vec00214-002-s049><dominate.beherrschen><de> Werden Sie zur wissenschaftlich fortschrittlichsten Zivilisation, die von militärischer Macht beherrscht wird, oder zum wichtigsten Ziel der kulturellen Künste.
<G-vec00214-002-s049><dominate.beherrschen><en> Become the most scientifically advanced civilization, dominate through sheer military power or become the foremost destination for the cultural arts;
<G-vec00214-002-s050><dominate.beherrschen><de> Eure Bourgeoisie zhlt auf Euch, auf Euer Durchhaltevermgen und auf Eure produktive Kraft, um einen Raum des Imperialismus einzunehmen, der das industrielle und landwirtschaftliche Zentrum Europas beherrscht.
<G-vec00214-002-s050><dominate.beherrschen><en> Your bourgeoisie counted on you, on your endurance and your productive power, to win a place for imperialism, to dominate the industrial and agricultural basis of Europe.
<G-vec00214-002-s051><dominate.beherrschen><de> Diese fast banale Vorgehensweise, die auch bei Ausstellungseröffnungen zum unabdingbaren Teil des Rituals gehört, bekommt plötzlich Brisanz und deckt in subtiler Art und Weise auf, wie sehr der männliche Teil der Bevölkerung die gesellschaftliche und administrative Matrix beherrscht.
<G-vec00214-002-s051><dominate.beherrschen><en> This somewhat banal practice, which is also an indispensable ritual at any exhibition opening, is suddenly invested with poignancy and discloses, ever so subtly, the extent to which men dominate our social and administrative fabric.
<G-vec00214-002-s052><dominate.beherrschen><de> Es wird gezeigt, dass die Debatte über die strategische Konzeption der regionalen Entwicklungspolitik von fünf großen Konflikten beherrscht wird.
<G-vec00214-002-s052><dominate.beherrschen><en> It points out that five major conflicts dominate the debate on the strategic conception of the regional development policy.
<G-vec00214-002-s053><dominate.beherrschen><de> Es gibt nichts Schöneres als einen Papa zu haben, der Sie beherrscht und Sie antworten mit "Ja, Sir".
<G-vec00214-002-s053><dominate.beherrschen><en> There’s nothing hotter than having a daddy dominate you and you responding “yes sir”.
<G-vec00214-002-s054><dominate.beherrschen><de> Wird diese Achse besonders stark polarisiert, so kann die abgespaltene Seite so mächtig werden, dass sie allmählich unser ganzes Leben beherrscht.
<G-vec00214-002-s054><dominate.beherrschen><en> If this axis becomes particularly polarised, the split-off side can become so powerful that it can start to dominate our lives.
<G-vec00214-002-s055><dominate.beherrschen><de> Mit ihrem nackten Arsch beherrscht sie ihn und sitzt in verschiedenen Positionen auf seinem Gesicht.
<G-vec00214-002-s055><dominate.beherrschen><en> With her naked ass she dominate him and sit in different positions on his face.
<G-vec00214-002-s056><dominate.beherrschen><de> Karo beherrscht die Mode des kommenden Herbstes.
<G-vec00214-002-s056><dominate.beherrschen><en> Checks dominate fashion this autumn.
<G-vec00214-002-s095><rule.beherrschen><de> Jedes Mitglied der Partei-Kern sei auf mysteriöse Weise davon überzeugt, dass der Krieg stattfinde, und dass er mit einem Sieg für Ozeanien enden werde, das die Welt am Ende beherrschen werde.
<G-vec00214-002-s095><rule.beherrschen><en> And every member of the party core is mysteriously convinced that the war does take place and that it will end with victory for Oceania, which will come to rule the world.
<G-vec00214-002-s096><rule.beherrschen><de> Und ihr werdet ihn meiden und in Meine Arme flüchten, denn die Wahrheit zeigt euch auch Mein Wesen, das nur Liebe ist für alle Meine Geschöpfe - nimmermehr werde Ich es zulassen, daß euch Menschen das Wissen um eure Bestimmung gänzlich vorenthalten wird, nimmermehr werde Ich euch Meinem Gegner kampflos überlassen, und nimmermehr wird er sich auf den Thron schwingen dürfen, indem er euch, Meine Geschöpfe, gänzlich beherrschen und euch von Mir mit Gewalt abdrängen kann.
<G-vec00214-002-s096><rule.beherrschen><en> And you will avoid him and flee into my arms, because truth also shows you my nature, which is just love for all my creatures – never ever will I allow that the knowledge about your destiny is completely withheld from you men, never ever will I leave you to my opponent without a fight, and never ever will he be allowed to be able to usurp the throne by him being able to rule completely over you, my creatures, and to push you away from me by force.
<G-vec00214-002-s097><rule.beherrschen><de> »Seine Anhänger lehnten ihn ab, weil er nicht die Welt beherrschen oder wenigstens eine politische Revolution führen wollte.
<G-vec00214-002-s097><rule.beherrschen><en> Wuju asked, fascinated. “His followers rejected him because he wouldn’t rule the world, or lead a political revolution.
<G-vec00214-002-s098><rule.beherrschen><de> Es sind die ungezählten Grautöne, die ihre Kunst beherrschen.
<G-vec00214-002-s098><rule.beherrschen><en> Instead, it's the myriad shades of grey that rule their art.
<G-vec00214-002-s099><rule.beherrschen><de> Der innere Reichtum seines Geistes und seines Herzens gestatten ihm, sich über die Dinge zu erheben und sie zu beherrschen.
<G-vec00214-002-s099><rule.beherrschen><en> It is the internal resources of his mind and heart that allow him to rise above things and rule over them.
<G-vec00214-002-s100><rule.beherrschen><de> Aus diesem Grund sind Menschen, die das außerkörperliche Reisen beherrschen, immer sehr gern gesehen, da sie aufgrund ihrer Frequenz von Verstorbenen sehr leicht wahrgenommen werden können.
<G-vec00214-002-s100><rule.beherrschen><en> For this reason, people who rule out-of-body travel are always welcome because they are very easily perceived by the deceased because of their frequency.
<G-vec00214-002-s101><rule.beherrschen><de> Da waren Menschen in der Gemeinde die das Volk beherrschen wollten.
<G-vec00214-002-s101><rule.beherrschen><en> There are people in the church who want to rule over the people.
<G-vec00214-002-s102><rule.beherrschen><de> Beherrschen Sie alle drei Command & Conquer-Universen und mehr mit dieser unglaublichen Sammlung...
<G-vec00214-002-s102><rule.beherrschen><en> Rule all three Command & Conquer universes with this incredible value – including 17 games and more!
<G-vec00214-002-s103><rule.beherrschen><de> Ihre Klasseninteressen und Klassenprivilegien stimmen mit dem Typ der Gesellschaft überein, die sie beherrschen; sie haben also ein Interesse daran, den beherrschten und ausgebeuteten Klassen zu predigen, auf ihren Kampf zu verzichten, die bestehende Ordnung zu akzeptieren, sich den „historischen Gesetzen“ zu unterwerfen, die die Herrschenden als unveränderlich ausgeben.
<G-vec00214-002-s103><rule.beherrschen><en> Their class interests and privileges are identified with the kind of society they rule over; they have an interest in preaching to the exploited, oppressed classes that they should renounce struggle, accept the existing order, submit to ‘historical laws’ which are supposed to be immutable.
<G-vec00214-002-s104><rule.beherrschen><de> Sie inspirierten die Errichtung der Vereinten Nationen und des Sicherheitsrats, um den Völkerbund zu ersetzen und die Welt mithilfe ihrer Mittelsmänner zu beherrschen.
<G-vec00214-002-s104><rule.beherrschen><en> They inspired the establishment of the United Nations and the Security Council to replace the League of Nations, in order to rule the world by their intermediary.
<G-vec00214-002-s105><rule.beherrschen><de> Die meisten von euch haben von einer mysteriösen, gesichtslosen machtvollen Elite erfahren, die unser Leben zu beherrschen scheint.
<G-vec00214-002-s105><rule.beherrschen><en> Most of you have come to know of some mysterious, faceless, powerful elite that seems to rule our life.
<G-vec00214-002-s106><rule.beherrschen><de> An der Ostküste liegt Mega City One - eine riesige, gewalttätige Metropole wo Kriminelle die chaotischen Straßen beherrschen.
<G-vec00214-002-s106><rule.beherrschen><en> On its East Coast, running from Boston to Washington DC, lies Mega City One- a vast, violent metropolis where criminals rule the chaotic streets.
<G-vec00214-002-s107><rule.beherrschen><de> Die Ideologie hinter der neuen Weltordnung kann jüdischer Messianismus sein, die Ansicht, dass Gott “den König der Juden” gewählt habe, um die Welt zu beherrschen.
<G-vec00214-002-s107><rule.beherrschen><en> The ideology behind the New World Order may be Jewish Messianism, the view that God has chosen “the King of the Jews” to rule the world.
<G-vec00214-002-s108><rule.beherrschen><de> Die Auflösung von Farben und Formen, Farbkontraste und Linien beherrschen in spannungsreichen Kompositionen ihre Bilder, die überwiegend in Aquarell und Acryl gemalt sind.
<G-vec00214-002-s108><rule.beherrschen><en> The resolution of colours and shapes, colour contrasts and lines rule her pictures in suspense filled compostions, which are mostly painted in watercolour and acrylic.
<G-vec00214-002-s109><rule.beherrschen><de> Vermutlich wird sich der Antichrist in diesen dritten Tempel setzen, um von Jerusalem aus die Welt zu beherrschen.
<G-vec00214-002-s109><rule.beherrschen><en> Presumably, in this third temple the anti-Christ will go and sit down so as to rule the world from Jerusalem.
<G-vec00214-002-s110><rule.beherrschen><de> Sie kämpften um die Eroberung oder Neuschaffung von Organisationen der zentralistischen Bürokratie, die sie von ihren Kommandostellen aus zu beherrschen gedachten.
<G-vec00214-002-s110><rule.beherrschen><en> The Bolsheviks fought for the conquest or renovation of organizations controlled by the centralistic bureaucracy, which they thought to rule from their own command posts.
<G-vec00214-002-s111><rule.beherrschen><de> Die Meta wird sich sicherlich noch ändern, wenn diese Decks effektiv gekontert werden, aber für den Moment beherrschen sie die Straßen von Gadgetzan.
<G-vec00214-002-s111><rule.beherrschen><en> The Meta is sure to keep changing. These decks can be countered, but for now, they rule these streets.
<G-vec00214-002-s112><rule.beherrschen><de> Wir wissen, dass Er dieses ungezähmte Glied unseres Körpers beherrschen möchte, und wir wissen, dass dies - die Zungenrede - das von Ihm gewählte Zeichen dafür ist.
<G-vec00214-002-s112><rule.beherrschen><en> We know He wants to rule that unruly member of our body, and we know that this is the sign He has chosen.
<G-vec00214-002-s113><rule.beherrschen><de> Wahrlich, diese allgemeine Blasiertheit, diese feige ängstlichkeit, dieses Schaudern vor dem Tode, diese niedrigen, entwürdigenden Anschauungen dürfen den Geist, der die zukünftige Gesellschaft durchdringen soll, nicht auf immer beherrschen, wie es in der Vergangenheit der Fall war und jetzt ist.
<G-vec00214-002-s113><rule.beherrschen><en> Surely, this universal ennui, Page 989 this coward fear, this shuddering at death, these low, degrading views, are not always to rule the spirit pervading future society, as it has the past, and does the present.
<G-vec00251-002-s089><deter.beherrschen><de> Der Arbeitsmarkt beherrscht weiterhin die Gründungstätigkeit in Deutschland: Die Anzahl der Existenzgründer ist im Jahr 2016 auf einen neuen Tiefstand gesunken.
<G-vec00251-002-s089><deter.beherrschen><en> The healthy labour market continues to deter start-up activity in Germany. The number of business start-ups fell to a new low in 2016.
<G-vec00280-002-s081><overtake.beherrschen><de> Langfristig, so schätzen Experten, wird China auch den IT-Sektor beherrschen.
<G-vec00280-002-s081><overtake.beherrschen><en> Experts estimate that, in the long term, China will overtake India in the IT sector.
<G-vec00302-002-s033><govern.beherrschen><de> Das Erlebnis bewusster Willensentscheidung, das Freiheitsempfinden, mit dem eigenen Körper machen zu dürfen, was man will – ja ihn so zu gestalten, dass man sich mit ihm identifizieren und ihn als seinen eigenen zeigen kann – all dies beherrscht jetzt das Bewusstsein der Jugendlichen.
<G-vec00302-002-s033><govern.beherrschen><en> The experience of deliberate decision-making, the sense of freedom, of being able to do with their own body what they want – indeed, to turn it into something with which they can identify and show as their own – all these things now govern the consciousness of the young person.
<G-vec00302-002-s034><govern.beherrschen><de> Je mehr wir zulassen, dass die Liebe Gottes unsere Gedanken und Gefühle beherrscht, desto mehr lassen wir zu, dass die Liebe für den Vater im Himmel in unserem Herzen anschwillt, und desto leichter ist es, andere mit der reinen Christusliebe zu lieben.
<G-vec00302-002-s034><govern.beherrschen><en> The more we allow the love of God to govern our minds and emotions—the more we allow our love for our Heavenly Father to swell within our hearts—the easier it is to love others with the pure love of Christ.
<G-vec00302-002-s035><govern.beherrschen><de> Unter der heutigen Wirtschaftsordnung ist die Natur nicht der Menschheit sondern den Kapital dienstbar; nicht das Bedürfnis der Menschheit nach Kleidung, Nahrung und Kultur sondern das Bedürfnis des Kapitals nach Profit, nach Gold beherrscht die Produktion.
<G-vec00302-002-s035><govern.beherrschen><en> In today’s economic order, nature does not serve humanity, but capital. It is not the clothing, food or cultural needs of humanity that govern production, but capital’s appetite for profit, for gold.
<G-vec00367-002-s021><restrain.beherrschen><de> Mit Hilfe von Tyrandes geduldiger Unterstützung konnte er sich beherrschen und seinem Bruder helfen, den einsiedlerischen Halbgott Cenarius zu finden.
<G-vec00367-002-s021><restrain.beherrschen><en> However, with Tyrande's patient support, he was able to restrain himself and help his brother find the reclusive demigod, Cenarius.
