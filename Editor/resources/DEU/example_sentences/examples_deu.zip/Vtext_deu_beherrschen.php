<G-vec00057-001-s076><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Mandarin, Englisch.
<G-vec00057-001-s076><speak.beherrschen><en> I can speak the following languages fluently: Chinese Mandarin, English.
<G-vec00057-001-s077><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Francés, Español, Inglés, Latín.
<G-vec00057-001-s077><speak.beherrschen><en> I can speak the following languages fluently: French, English, Latin, Spanish.
<G-vec00057-001-s078><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Hindi, Bengalí.
<G-vec00057-001-s078><speak.beherrschen><en> I can speak the following languages fluently: Hindi, Bengali.
<G-vec00057-001-s079><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Inglés, Alemán, Francés.
<G-vec00057-001-s079><speak.beherrschen><en> I can speak the following languages fluently: English, French, German.
<G-vec00057-001-s080><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Español, Catalán, Inglés, Italiano.
<G-vec00057-001-s080><speak.beherrschen><en> I can speak the following languages fluently: Spanish, Catalan, English, Italian.
<G-vec00057-001-s081><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Japanisch, Englisch, Niederländisch.
<G-vec00057-001-s081><speak.beherrschen><en> I can speak the following languages fluently: Japanese, Dutch, English.
<G-vec00057-001-s082><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Chino Mandarín, Inglés.
<G-vec00057-001-s082><speak.beherrschen><en> I can speak the following languages fluently: Chinese Mandarin, English.
<G-vec00057-001-s083><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Isländisch, Dänisch, Englisch, Norwegisch, Schwedisch.
<G-vec00057-001-s083><speak.beherrschen><en> I can speak the following languages fluently: Icelandic, Danish, English, Norwegian, Swedish.
<G-vec00057-001-s084><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Deutsch, Englisch, Koreanisch.
<G-vec00057-001-s084><speak.beherrschen><en> I can speak the following languages fluently: German, English, Korean.
<G-vec00057-001-s085><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Englisch, Französisch, Russisch.
<G-vec00057-001-s085><speak.beherrschen><en> I can speak the following languages fluently: English, French, Russian.
<G-vec00057-001-s086><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Chino Mandarín, Chino Cantonés, Inglés.
<G-vec00057-001-s086><speak.beherrschen><en> I can speak the following languages fluently: Chinese Mandarin, Chinese Cantonese, English.
<G-vec00057-001-s087><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Spanisch, Deutsch, Englisch, Französisch, Russisch.
<G-vec00057-001-s087><speak.beherrschen><en> I can speak the following languages fluently: Spanish, English, French, German, Russian.
<G-vec00057-001-s088><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Englisch, Deutsch, Portugiesisch - Bras, Spanisch.
<G-vec00057-001-s088><speak.beherrschen><en> I can speak the following languages fluently: English, German, Portuguese - Brazil, Spanish.
<G-vec00057-001-s089><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Norwegisch, Englisch, Russisch.
<G-vec00057-001-s089><speak.beherrschen><en> I can speak the following languages fluently: Norwegian, English, Russian.
<G-vec00057-001-s090><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Französisch, Englisch.
<G-vec00057-001-s090><speak.beherrschen><en> I can speak the following languages fluently: French, English.
<G-vec00057-001-s091><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Español, Catalán, Francés, Inglés.
<G-vec00057-001-s091><speak.beherrschen><en> I can speak the following languages fluently: Spanish, Catalan, English, French.
<G-vec00057-001-s092><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Griego, Inglés, Italiano.
<G-vec00057-001-s092><speak.beherrschen><en> I can speak the following languages fluently: Greek, English, Italian.
<G-vec00057-001-s093><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Griego, Inglés, Italiano, Portugués - Europa.
<G-vec00057-001-s093><speak.beherrschen><en> I can speak the following languages fluently: Greek, English, Italian, Portuguese - Europe.
<G-vec00057-001-s094><speak.beherrschen><de> Ich beherrsche die folgenden Sprachen fließend: Dutch, English, Flemish, French, Norwegian.
<G-vec00057-001-s094><speak.beherrschen><en> I can speak the following languages fluently: Dutch, English, Flemish, French, Norwegian.
<G-vec00367-001-s029><restrain.beherrschen><de> Und dann kam der alte Großmeister auch noch aus der Umkleidekabine heraus und konnte sich kaum beherrschen.
<G-vec00367-001-s029><restrain.beherrschen><en> Soon the grandmastercame out of the locker room. He was completely pissed off and could hardly restrain himself.
<G-vec00367-001-s030><restrain.beherrschen><de> Erst als ein Falun Gong-Praktizierender namens Li Xinze, der zur gleichen Zeit eingesperrt und zu Tode gefoltert wurde, die Aufmerksamkeit der internationalen Gemeinschaft erregte, fing die Gefängnispolizei an sich zu beherrschen.
<G-vec00367-001-s030><restrain.beherrschen><en> It was not until a Falun Gong practitioner named Li Xinze, who was jailed with him at the same time was tortured to death and it aroused the concern of the international community that the prison police started to restrain themselves.
<G-vec00367-001-s031><restrain.beherrschen><de> Als ich Euch dort hinauf schickte, vergaß ich Euch gegenüber zu erwähnen, daß die Höhle von Devas beschützt ist, und Euch zu warnen, daß Ihr Euch beherrscht und die ganze Zeit passend benehmt.
<G-vec00367-001-s031><restrain.beherrschen><en> When I sent you up there, I forgot to mention that the cave is protected by devas and to warn you to restrain yourselves and behave properly the whole time.
