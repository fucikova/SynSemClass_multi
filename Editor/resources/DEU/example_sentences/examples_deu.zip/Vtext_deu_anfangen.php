<G-vec00179-001-s076><start.anfangen><de> Innovation war das Markenzeichen von Grote Industries von Anfang an.
<G-vec00179-001-s076><start.anfangen><en> Innovation has been the hallmark of Grote Industries from the start.
<G-vec00179-001-s077><start.anfangen><de> Diese begann im Urwald weit oben im Whakarewarewa Forest, aber war sehr viel besser fahrbar als Stage eins, und es ging netterweise von Anfang an bergab.
<G-vec00179-001-s077><start.anfangen><en> Stage four began in the native forest up high in the Whakarewarea Forest but was a good deal more rideable than stage one and began descending from the very start which was nice!
<G-vec00179-001-s078><start.anfangen><de> Unsere Strukturen sind Kosten wettbewerbsfähig von Anfang an, aber wir wissen, dass die Anfangskosten nur ein Teil des Bildes sind.
<G-vec00179-001-s078><start.anfangen><en> Sprung buildings are cost-competitive from the start, but we know that up-front costs are only part of the picture.
<G-vec00179-001-s079><start.anfangen><de> Und in dieser Berufung ruft Gott Abraham nicht allein, als Einzelnen, sondern er bezieht von Anfang an seine Familie, seine Verwandtschaft und alle ein, die im Dienst an seinem Haus stehen.
<G-vec00179-001-s079><start.anfangen><en> And in this vocation God did not call Abraham alone, as an individual, but involved from the start his family, his household and all those in service to his house.
<G-vec00179-001-s080><start.anfangen><de> Der flinke und wendige Kleintransporter stellte von Anfang an einen echten Verkaufsschlager dar und wird heute europaweit eingesetzt.
<G-vec00179-001-s080><start.anfangen><en> The swift and agile utility vehicle has been a real bestseller right from the start and is used all over Europe today.
<G-vec00179-001-s081><start.anfangen><de> "Es gibt so viele Anpassungen von Anfang an, dass es normal ist, ein paar schwierige Momente zu machen "", bot Lefebvre über seine Schüler Nygren, der den Sprung von Europa nach Nordamerika im Laufe des Sommers gemacht."
<G-vec00179-001-s081><start.anfangen><en> There are so many adjustments to make right from the start that it’s normal to have a few difficult moments,” offered Lefebvre about his pupil Nygren, who made the jump from Europe to North America over the course of the summer.
<G-vec00179-001-s082><start.anfangen><de> Wir erforschen neue methodologische Mittel als Alternativen zur akademischen Erklärung, weil wir glauben, dass man sich dort, wo diese Erklärung vorherrscht, vor allem auf ein rein erklärendes Wissen beruft; ein Wissen, das kaum jemals in Situationen zur Anwendung kommt, da die theoretischen Mittel von Anfang an nicht als konzeptuelle Werkzeuge für ein Operieren in konkreten Situationen gedacht werden, sondern vielmehr ein konzeptuelles Wissen darstellen, das erst erlernt und dann abspeichert.
<G-vec00179-001-s082><start.anfangen><en> If we explore methodologies that are alternative to academic-lecture like explanations, it is because we believe that where explanation predominates- so does a type of purely declarative knowledge. This type of knowledge is difficult to reuse in a concrete situation given that, from the start, the theory used is not understood as a conceptual tool that can act in a concrete situation but rather as conceptual knowledge that must be learned in order to be archived.
<G-vec00179-001-s083><start.anfangen><de> Der Aufstieg ist von Anfang an sehr steil.
<G-vec00179-001-s083><start.anfangen><en> The ascent is very zooming right from the start.
<G-vec00179-001-s084><start.anfangen><de> Dadurch bieten sie genügend Robustheit für Ihre spezifische Applikation und liefern Ihnen zuverlässige Ergebnisse von Anfang an.
<G-vec00179-001-s084><start.anfangen><en> They therefore offer sufficient robustness for your specific application and provide you with reliable results from the start. Available product versions
<G-vec00179-001-s085><start.anfangen><de> Da ich von Anfang an dabei war, habe ich ein besonderes Verhältnis zu dem Spiel.
<G-vec00179-001-s085><start.anfangen><en> Since I have been there from the very start, I have a special relationship with the game.
<G-vec00179-001-s086><start.anfangen><de> Eine professionelle Installation gewährleistet die direkte Bereitstellung, sofortige Verwendung und optimale Produktivität von Anfang an.
<G-vec00179-001-s086><start.anfangen><en> Professional installation ensures direct deployment, immediate use and optimal productivity right from the start.
<G-vec00179-001-s087><start.anfangen><de> Die Kinder waren von Anfang an ein Teil des Projekts.
<G-vec00179-001-s087><start.anfangen><en> The children have been a part of the project right from the start.
<G-vec00179-001-s088><start.anfangen><de> Von Anfang an und in allen Varianten verfügte es über eine Automatikblende, d. h. die Kamera schließt die Blende im Moment der Aufnahme von alleine auf den vorher am Objektiv eingestellten Wert.
<G-vec00179-001-s088><start.anfangen><en> Right from the start and in all variations it had an automatic aperture, the camera body automatically closes the aperture to the value set on the lens prior to exposure.
<G-vec00179-001-s089><start.anfangen><de> Ebenso sind die wesentlichen Fragen der proletarischen Diktatur und der Aufgabe der Partei richtig und konsequent gestellt worden, wie es sich auch in der von Anfang an gestellten Forderung nach Spaltung der SPI zeigte.
<G-vec00179-001-s089><start.anfangen><en> It correctly set out the essential problems of the proletarian dictatorship and the party’s tasks, and from the very start defended the necessity of a split in the Socialist Party.
<G-vec00179-001-s090><start.anfangen><de> Erinnere dich daran, dass diese ersten 3 1⁄2 Jahre schreckliche Jahre von wirtschaftlichen und politischen Durcheinander, Verfolgung und Bedrängnis sein werden, wie wir es auch in der Offenbarung sehen können – jeder, der am Leben ist und die Schrift kennt, wird von Anfang an wissen wer er ist.
<G-vec00179-001-s090><start.anfangen><en> Remember, those first 3 1/2 years will be horrible years of economic and political turmoil, persecution, and hardship as seen also in The Revelation - anyone alive who knows scripture will know who he is from the start.
<G-vec00179-001-s091><start.anfangen><de> Dies werden wir aber Schritt für Schritt und NICHT von Anfang an machen, denn dann kann man besser reagieren und es bleibt auch übersichtlicher.
<G-vec00179-001-s091><start.anfangen><en> But this we will do step by step and NOT just immediately after the start, because then we can act better and everything stays clean.
<G-vec00179-001-s092><start.anfangen><de> """Durch die Zusammenarbeit mit COA-Entwicklern können wir ihnen dabei helfen, von Anfang an Übersetzbarkeit in Maßnahmen zu übertragen."
<G-vec00179-001-s092><start.anfangen><en> """Working together with COA developers we can help them design translatability into measures from the start."
<G-vec00179-001-s093><start.anfangen><de> Fachleute sind wählerischer: Sie greifen von Anfang an in das PB Swiss Tools Werkzeugset.
<G-vec00179-001-s093><start.anfangen><en> They pick tools from the PB Swiss Tools set right from the start.
<G-vec00179-001-s094><start.anfangen><de> Wir begleiten Ihr Projekt von Anfang an – mit kompetenter Beratung, einer vollständigen CAD-Datenbank und schneller Lieferung.
<G-vec00179-001-s094><start.anfangen><en> We can support your project right from the start with expert advice, a complete CAD database and fast delivery.
<G-vec00097-001-s076><begin.anfangen><de> Seine Triebe und Samen sicher überwintern, und sie entwickelte sich aus den Pflanzen anfangen, im Mai und Juni blühen.
<G-vec00097-001-s076><begin.anfangen><en> Its shoots and seeds safely overwinter, and they developed from the plants begin to bloom in May and June.
<G-vec00097-001-s077><begin.anfangen><de> Eine gegenwärtige Philosophie schlägt vor, daß Brustgesundheit Siebung an Alter 25 anfangen sollte.
<G-vec00097-001-s077><begin.anfangen><en> One current philosophy suggests breast health screening should begin at age 25.
<G-vec00097-001-s078><begin.anfangen><de> Bei der Frage nach seinen Eindrücken zur Passage in den Pyrenäen hat der Kapitän von Team Sky im Übrigen schon eine Art Ungeduld durchscheinen lassen: „Alles wird von der ersten Woche und deren Ablauf abhängen, doch das Rennen wird in den Bergen wirklich anfangen.
<G-vec00097-001-s078><begin.anfangen><en> Asked to comment on the Pyrenees, the Team Sky leader showed signs of impatience: “It will all depend on how the first week goes, but the race will really begin in the mountains.
<G-vec00097-001-s079><begin.anfangen><de> Der Feind rechnete, dass der Eintritt mit dem Süden anfangen wird, wo unsere Truppen weit vorwärts gegangen sind, die Karpaten erreicht.
<G-vec00097-001-s079><begin.anfangen><en> The enemy counted that approach will begin with the South where our troops far moved ahead, having reached the Carpathians.
<G-vec00097-001-s080><begin.anfangen><de> Wenn Sie aufgeregt, unruhig, oder nachlässige, werden Sie anfangen zu spielen, zu viel, und du wirst anfangen zu verlieren.
<G-vec00097-001-s080><begin.anfangen><en> If you start to get alarmed, restless, or apathetic, you can start betting a lot, and you most likely will begin losing.
<G-vec00097-001-s081><begin.anfangen><de> Das ist fantastisch, da es bedeutet, wenn man zweifelhaft sind Sie klein anfangen, und gehen Sie zurück, um eine größere Flasche später zu kaufen, wenn Sie die Ergebnisse, die Sie wünschen, zu erwerben wahrscheinlich.
<G-vec00097-001-s081><begin.anfangen><en> This is wonderful considering that it indicates if you are skeptical you can begin little, and maybe return to buy a larger container later on if you get the outcomes you wish.
<G-vec00097-001-s082><begin.anfangen><de> "Wir können hier gleich anfangen, danach zu fragen, was mit ""des Lebens wichtig"" gemeint ist."
<G-vec00097-001-s082><begin.anfangen><en> "We can begin just here and ask the question, What does ""vital"" mean?"
<G-vec00097-001-s083><begin.anfangen><de> """Dann könnte ich ja gleich anfangen, mich zu erholen"", sagte Robinson und sah Karl an."
<G-vec00097-001-s083><begin.anfangen><en> “Then I can begin recovering immediately,” Robinson said as he looked at Karl.
<G-vec00097-001-s084><begin.anfangen><de> Texas Einfluß' EM - ein Siebenkarte Spiel mit einfachen Richtlinien, die ein Anfänger leicht erarbeiten und anfangen kann, um sofort zu spielen.
<G-vec00097-001-s084><begin.anfangen><en> Texas Hold 'em - A seven-card game with simple rules that a beginner can easily master and begin to play right away.
<G-vec00097-001-s085><begin.anfangen><de> Sind diese Hauptstützen des alten, finstern und bösen Aberglaubens aus dem Wege geräumt, und das blitzschnell zu gleicher Zeit an allen Orten der Erde, so werden die Menschen sicher darüber erschrecken und darauf bald nachzudenken anfangen, wie und warum solches geschehen ist, und was es zu bedeuten hat.
<G-vec00097-001-s085><begin.anfangen><en> If these most important pillars of the old, dark and evil superstition are done away with, and as fast as lightning on all places of the Earth at once, that will certainly frighten the people and they will soon begin to think about how and why that happened and about its meaning.
<G-vec00097-001-s086><begin.anfangen><de> """Hört die süßen, kleinen Vögel da oben"" sagten die Rosen, ""sie wollen jetzt auch anfangen zu singen."
<G-vec00097-001-s086><begin.anfangen><en> """Listen to the dear little birds up there,"" said the roses; ""they begin to want to sing too, but are not able to manage it yet."
<G-vec00097-001-s087><begin.anfangen><de> Die Katzen haben eine interessante Besonderheit: nach der Geburt einiger Kätzchen kann die Geburt für die Zeit aufhören, und dann, wieder anfangen.
<G-vec00097-001-s087><begin.anfangen><en> Cats have an interesting feature: after the birth of several kittens childbirth can stop for a while, and then again begin.
<G-vec00097-001-s088><begin.anfangen><de> Wer nicht mehr wartet, kann anfangen zu handeln.
<G-vec00097-001-s088><begin.anfangen><en> And anyone who ceases to hope can begin to act.
<G-vec00097-001-s089><begin.anfangen><de> Irgendwo musste der Mensch anfangen, und es sei besser, es dort zu tun, wo ein anderer aufhören würde.
<G-vec00097-001-s089><begin.anfangen><en> Somewhere a man must begin, and it had better be just where another man might stop.
<G-vec00097-001-s090><begin.anfangen><de> Doch kann ich mir vorstellen, dass ein Künstler in England, der ein Kunstwerk hervorbrächte, das sogleich bei seinem Erscheinen vom Publikum durch dessen Medium, die öffentliche Presse, als ein ganz verständliches und höchst moralisches Werk anerkannt wird, anfangen würde ernsthaft zu zweifeln, ob er sich in seiner Schöpfung wirklich selbst ausgedrückt habe und ob darum dieses Werk seiner nicht ganz unwürdig und entweder absolut zweitrangig sei oder überhaupt keinen künstlerischen Wert besäße.
<G-vec00097-001-s090><begin.anfangen><en> But I can fancy that if an artist produced a work of art in England that immediately on its appearance was recognised by the public, through their medium, which is the public press, as a work that was quite intelligible and highly moral, he would begin to seriously question whether in its creation he had really been himself at all, and consequently whether the work was not quite unworthy of him, and either of a thoroughly second-rate order, or of no artistic value whatsoever.
<G-vec00097-001-s091><begin.anfangen><de> Außerhalb des Gerichtsgebäude sagten die Opfer, sie seien über das Urteil erleichtert und jetzt könnten sie anfangen, weiterzuleben.
<G-vec00097-001-s091><begin.anfangen><en> Outside court the victims said they were relieved by the sentence and that they could now begin to move on with their lives.
<G-vec00097-001-s092><begin.anfangen><de> Ich persönlich bin jedoch aus beruflichen und weltanschaulichen Gründen an Debian Sid gebunden, und kann daher mit den obigen Optionen nichts anfangen.
<G-vec00097-001-s092><begin.anfangen><en> I personally am however bound for vocational and world-descriptive reasons at Debian Sid, and can begin therefore with the above options nothing.
<G-vec00097-001-s093><begin.anfangen><de> Andere unbegreifliche Symptome der neuen Zustände des Organismus werden ebenfalls anfangen, sich im Leben zu offenbaren.
<G-vec00097-001-s093><begin.anfangen><en> Likewise, other incomprehensible symptoms of the new conditions of the organism will begin to disclose themselves in life.
<G-vec00097-001-s094><begin.anfangen><de> Denn nun beachten sie alle Anzeichen, weil sie zu glauben anfangen, daß das Ende nahe ist.
<G-vec00097-001-s094><begin.anfangen><en> For then they will pay heed to all the signs because they will begin to believe that the end is near.
<G-vec00097-001-s095><start.anfangen><de> Wenn Sie mit den besten Blättern anfangen und darauf abzielen, die Nuts zu erreichen, haben Sie bei Omaha eine wesentlich bessere Chance auf Erfolg.
<G-vec00097-001-s095><start.anfangen><en> If you start with the best hands and look to aim for The Nuts then your chances of success in Omaha are all that much greater.
<G-vec00097-001-s096><start.anfangen><de> Lass uns mit Facebook anfangen.
<G-vec00097-001-s096><start.anfangen><en> Let’s start with Facebook.
<G-vec00097-001-s097><start.anfangen><de> Wir können auch anfangen, einige neue Kleidungsstücke zu kaufen oder Bücher oder Musik oder was immer wahrhaftiger widerspiegelt, wer wir jetzt geworden sind.
<G-vec00097-001-s097><start.anfangen><en> We can also start buying some new clothes or books or music or whatever which more truly reflects who we have now become.
<G-vec00097-001-s098><start.anfangen><de> Anfangen muss man an den Wurzeln, d.h. bei der politischen Bildung der jungen Menschen.
<G-vec00097-001-s098><start.anfangen><en> You have to start at the roots, i. e. with the political education of young people.
<G-vec00097-001-s099><start.anfangen><de> "In seinen eigenen Worten: ""Ich bin dabei meine Eid auf die nationale Sicherheit zu verletzen... Ich habe die Regierungslügen so satt, dass ich nicht einmal weiß, wo ich anfangen soll""."
<G-vec00097-001-s099><start.anfangen><en> "In his own words; ""I'm about to violate my national security oath…I'm so fed up with government lies I don't even know where to start""."
<G-vec00097-001-s100><start.anfangen><de> Der Vater zweier Kinder aus der Region Casablanca war schon immer von Autoblech und Motoren fasziniert: „Ich war früher Chef in einer Autowerkstatt.“ Trotzdem musste er bei Renault da anfangen, wo fast alle Neulinge landen: in dem langgestreckten Ausbildungszentrum, das gleich am Eingang des 300 Hektar großen Fabrikgeländes liegt.
<G-vec00097-001-s100><start.anfangen><en> The father of two children from the Casablanca region has always been fascinated by car engines and bodywork: “I used to run a car workshop.” Nevertheless, when he joined Renault he had to start where nearly all new employees do: inside the long and narrow training centre that stands right by the entrance to the 300-hectare factory site.
<G-vec00097-001-s101><start.anfangen><de> „Aber jetzt möchte ich mit Karate anfangen.“ Da kann sich ihr Gatte und ständiger Begleiter Marcelo wohl auf einiges gefasst machen.
<G-vec00097-001-s101><start.anfangen><en> “But now I want to start doing karate.” So her husband and constant companion Marcelo can prepare himself for quite a lot.
<G-vec00097-001-s102><start.anfangen><de> Warnungen Dein Partner könnte einen Vorteil darin sehen und anfangen, dich zu zwingen, seine oder ihre Füße für lange Zeit zu riechen/lecken/küssen.
<G-vec00097-001-s102><start.anfangen><en> Warnings Your partner may see an advantage to this, and start forcing you to smell/lick/kiss her feet for long amounts of time.
<G-vec00097-001-s103><start.anfangen><de> Nach 45 Minuten können Sie anfangen zu essen.
<G-vec00097-001-s103><start.anfangen><en> After 45 minutes you can start eating.
<G-vec00097-001-s104><start.anfangen><de> Die Jungs, die in die Arabischen Emirate gehen wollen, warten immer noch auf den Moment, in dem sie anfangen können, und machen in der Zwischenzeit Gelegenheitsjobs.
<G-vec00097-001-s104><start.anfangen><en> The boys who want to go for work to the Arabian Emirates are still waiting for the moment they can start and are doing odd jobs in the meantime.
<G-vec00097-001-s105><start.anfangen><de> Deine Freunde werden keine Empfehlungen wenn sie anfangen Top Eleven zu spielen nachdem sie die Benachrichtigung per E-Mail, SMS oder Twitter öffnen.
<G-vec00097-001-s105><start.anfangen><en> Your friends will not become your referrals if they start playing after receiving a message via email, Twitter or SMS).
<G-vec00097-001-s106><start.anfangen><de> Am praktischen Beispiel wird das Thema »Ausgrenzung« thematisiert und reflektiert.Quer durch den großen Ausstellungsraum entsteht aus Obstkisten und Umzugskartons eine selbstgestaltete Mauer, die uns zeigen soll, dass Veränderungen im Kopf anfangen.
<G-vec00097-001-s106><start.anfangen><en> Right across the large exhibition showroom a self-designed wall will be created from fruit crates and moving boxes to demonstrate that changes start in the mind.
<G-vec00097-001-s107><start.anfangen><de> Bevor wir anfangen im Gespräch mit Fremden Omegle, wir müssen die Regeln kennen.
<G-vec00097-001-s107><start.anfangen><en> Before we start talking to strangers Omegle, we need to know the rules.
<G-vec00097-001-s108><start.anfangen><de> Wenn Sie aufgeregt, unruhig, oder nachlässige, werden Sie anfangen zu spielen, zu viel, und du wirst anfangen zu verlieren.
<G-vec00097-001-s108><start.anfangen><en> If you start to get alarmed, restless, or apathetic, you can start betting a lot, and you most likely will begin losing.
<G-vec00097-001-s109><start.anfangen><de> A.M.: Ich möchte untypisch anfangen.
<G-vec00097-001-s109><start.anfangen><en> A.M.: I will not start typically...
<G-vec00097-001-s110><start.anfangen><de> Du beginnst festzustellen, dass du innerlich wütend bist, und du magst anfangen jemand anderen zu verletzen, weil du im Moment in dem Bestreben gefangen bist, die verlorene Zeit wieder wettzumachen, die Welt geradewegs auf deine Repräsentationsrechte hin auszurichten.
<G-vec00097-001-s110><start.anfangen><en> You begin to notice that you are irate inside, and you may start to infringe on another because, at the moment, you are caught up in making up for lost time, setting the world straight on your rights of representation.
<G-vec00097-001-s111><start.anfangen><de> Die ganze Zeit werden Sie die Polnische Sprache hören und durch Spiele mit Aufnahmen über Mikrofon werden Sie direkt anfangen zu sprechen.
<G-vec00097-001-s111><start.anfangen><en> You will hear the Polish language all of the time and, using the recording games, you can start speaking straight away.
<G-vec00097-001-s112><start.anfangen><de> dann können Sie anfangen, ein...
<G-vec00097-001-s112><start.anfangen><en> then you may have to start thinking a...
<G-vec00097-001-s113><start.anfangen><de> Der Vergleich, dass die Themen, die Patti ist enttäuschender Gleichgültigkeit gegenüber den Tod eines von ihnen sogar; sieht aus wie es sein wird eine Art von Offenbarung und stattdessen die gleichen Gehirnwäsche sahen wir tun Meg: Nicht durch Erinnerungen an die Vergangenheit schwankte, denn das ist, wenn Sie anfangen, etwas zu fühlen.
<G-vec00097-001-s113><start.anfangen><en> The comparison that the subjects Patti is even more disappointing indifference to the death of one of them; looks like it's going to be some kind of revelation and instead is the same brainwashing we saw do Meg: Don't be swayed by memories of the past because that is when you start to feel something.
<G-vec00097-001-s095><begin.anfangen><de> Das bedeutet, dass es das Wort Gottes ist, das redet und es der Geist des HERRN ist, der dem Wort Gottes die Stimme gibt, die anfängt das Wort zu sprechen.
<G-vec00097-001-s095><begin.anfangen><en> This means, it is the Word of God which speaks, and it is the Spirit of the Lord who gives the Word of God voice when we begin to speak the Word.
<G-vec00097-001-s096><begin.anfangen><de> Wenn in irgend einen Bereich ein Einbruch dieser unterbrechenden, schismatischen unordentlichen Mächte sei es in ein individuelles oder in ein Gemeinschaftsleben oder sonstwo geschieht, ist der übliche Weg der, dass man einen Sündenbock findet, dass man jemandem die Schuld geben kann, dass man anfängt, einander schräg anzusehen, dass man es auf dies oder jenes zurückführt, und wenn wir das tun, verfehlen wir den Punkt und den Weg, und wir werden die Sache auf diese Weise nie aufklären.
<G-vec00097-001-s096><begin.anfangen><en> When there is a breaking in, in any realm, of those disruptive, schismatic, disordering forces, in an individual life, or in a community, or anywhere, the usual way is to find a scapegoat, to blame somebody, to begin to look at one another, to put it down to this, and that, and something else, and in so doing we are missing the point and missing the way, and we will never clear it up like that.
<G-vec00097-001-s097><begin.anfangen><de> Ich wollte doch einmal ‚richtig‘ sticken (d.h., nicht auf Papier;-)) und musste jetzt heraus finden, wie man eigentlich anfängt und am Ende aufhört (auf Papier klebe ich den Faden einfach fest und ich dachte, dass man das auf Stoff anders macht;-)).
<G-vec00097-001-s097><begin.anfangen><en> I just wanted to try ‘real’ embroidery (viz. not on paper;-)) and had to find out how actually to begin and to end (on paper I simply glue on the threads but I thought that this must be done differently on fabric;-)).
<G-vec00097-001-s098><begin.anfangen><de> Die bestehende Vorstellung, dass die Eier oder die Läuse selbst in der Kopfhaut einnicken, während die Person ruhig ist und anfängt, nur mit nervöser Erregung zu basteln und zu jucken, sind pseudowissenschaftliche Mythen, unlogisch und durch keine Forschung bestätigt.
<G-vec00097-001-s098><begin.anfangen><en> The existing notion that the eggs or the lice themselves doze in the scalp while the person is calm, and they begin to tinker and itch only with nervous agitation, are pseudoscientific myths, illogical and not confirmed by any research.
<G-vec00097-001-s099><begin.anfangen><de> 28 Wenn aber dieses anfängt zu geschehen, so sehet auf und erhebet eure Häupter, darum daß sich eure Erlösung naht.
<G-vec00097-001-s099><begin.anfangen><en> 28 And when these things begin to come to pass, then look up, and lift up your heads; for your redemption draweth nigh.
<G-vec00097-001-s100><begin.anfangen><de> 9 Sieben Wochen sollst du dir abzählen; wenn man anfängt, die Sichel an die Saat zu legen, sollst du anfangen, sieben Wochen zu zählen.
<G-vec00097-001-s100><begin.anfangen><en> "9 ""You shall count seven weeks for yourself; you shall begin to count seven weeks from the time you begin to put the sickle to the standing grain."
<G-vec00097-001-s101><begin.anfangen><de> Das Substrat sollte im Winter fast durchgehend trocken gehalten werden, damit die Winterrosette, die relativ tief im Boden steckt, nicht anfängt zu faulen.
<G-vec00097-001-s101><begin.anfangen><en> In winter substrate should be kept almost dry, so that the winter leaves do not begin to rot, because the winter rosette is partly buried in the soil.
<G-vec00097-001-s102><begin.anfangen><de> Wenn es um Management, Männer und Frauen oft mit, wie man anfängt und vor allem, wie man Ergebnisse sehen Gewicht.
<G-vec00097-001-s102><begin.anfangen><en> When it comes to weight management, men and women alike often struggle with how to begin and, most importantly, how to see the results.
<G-vec00097-001-s103><begin.anfangen><de> Verfüge, dass sich in dir eine neue Salbung anfängt zu manifestieren, in den nächsten Monaten.
<G-vec00097-001-s103><begin.anfangen><en> Declare that a new anointing will begin to manifest in you in the next several months.
<G-vec00097-001-s104><begin.anfangen><de> Jedes Mal, wenn Sie wetten, nicht nur für typische Freizeit und Unterhaltung; auch anfängt zu gastronomischen Erlebnissen zu nehmen, Thematisierung und Customizing neue Erfahrungen.
<G-vec00097-001-s104><begin.anfangen><en> Every time you are betting, for not only typical leisure and entertainment; also begin to take place gastronomic experiences, theming and customizing new experiences.
<G-vec00097-001-s105><begin.anfangen><de> Der Ausruf des Gottessohnes aus Lukas 21,28: „Wenn aber dieses anfängt zu geschehen, dann seht auf und erhebt eure Häupter, weil eure Erlösung naht“ war Grundlage des Gottesdienstes, an dem über 3.500 Gläubige teilnahmen.
<G-vec00097-001-s105><begin.anfangen><en> The divine service, which was attended by over 3,500 believers, was based on the statement of the Son of God recorded in Luke 21: 28: “Now when these things begin to happen, look up and lift up your heads, because your redemption draws near.”
<G-vec00097-001-s106><begin.anfangen><de> Wenn aber dies anfängt zu geschehen, so richtet euch auf und erhebt eure Häupter, weil eure Erlösung naht.
<G-vec00097-001-s106><begin.anfangen><en> "But when these things begin to happen, look up, and lift up your heads, because your redemption is near."""
<G-vec00097-001-s107><begin.anfangen><de> Der Schaden an den Belägen wird normalerweise durch übermäßige Hitze hervorgerufen, die das Reibmaterial brüchig machen, sodass es anfängt zu brechen.
<G-vec00097-001-s107><begin.anfangen><en> A damaged pad is usually caused by excessive heat which causes the friction material to become brittle and begin to break up.
<G-vec00097-001-s108><begin.anfangen><de> Sorgen Sie nicht sich um das Vollenden sie, aber suchen Sie neuen Ideen, Antrieben, Darmgefühlen und nach neuer Energie, die anfängt, zu führen Sie zu, was Sie wünschen.
<G-vec00097-001-s108><begin.anfangen><en> Don't worry about accomplishing it, but do look for new ideas, impulses, gut feelings, and new energy that will begin to guide you to what you want.
<G-vec00097-001-s109><begin.anfangen><de> 12:45 Wenn aber jener Knecht in seinem Herzen sagt: Mein Herr verzieht zu kommen, und anfängt, die Knechte und Mägde zu schlagen und zu essen und zu trinken und sich zu berauschen, < 12:46 so wird der Herr jenes Knechtes kommen an einem Tage, an welchem er es nicht erwartet, und in einer Stunde, die er nicht weiß, und wird ihn entzweischneiden und ihm sein Teil setzen mit den Untreuen.
<G-vec00097-001-s109><begin.anfangen><en> 12:45 But if that servant shall say in his heart, My lord delayeth his coming; and shall begin to beat the menservants and the maidservants, and to eat and drink, and to be drunken; < 12:46 the lord of that servant shall come in a day when he expecteth not, and in an hour when he knoweth not, and shall cut him asunder, and appoint his portion with the unfaithful.
<G-vec00097-001-s110><begin.anfangen><de> Wenn unsere Protagonistin sehr geil ist, bis auf den Schwanz des Jungen und beginnt zu saugen, werden wir Mary Jean saugen sehen, dann wird unsere vollbusige Protagonistin in Position des Hundes gebracht, damit der Junge anfängt zu ficken, was zu einem sehr harten Ergebnis führt gute interrassische Sexszene in der Öffentlichkeit mit einer vollbusigen Frau, die einen Mann auf einem Fußballfeld fickt.
<G-vec00097-001-s110><begin.anfangen><en> When our protagonist is very horny, down to the boy’s cock and begin to suck, so we will see Mary Jean sucking cock, then our busty protagonist will be placed in position of the dog for the boy to begin to fuck, resulting in a very good Interracial sex scene in public with a busty woman fucking a man on a soccer field.
<G-vec00097-001-s112><begin.anfangen><de> 2007-11-13 22:16:19 - Grundlegende organisierende Grundregeln So haben Sie entschieden, organisiert zu erhalten, aber Sie gerade wissen nicht, wo man anfängt.
<G-vec00097-001-s112><begin.anfangen><en> 2007-11-13 22:16:19 - Basic organizing principles So you've decided to get organized, but you just don't know where to begin.
<G-vec00097-001-s113><begin.anfangen><de> Wir möchten hoffen, dass Jeschows Fehler ausgemerzt und berichtigt werden, dass das NKWD anfängt, richtig die feindlichen Elemente der Sowjetmacht zu bekämpfen und dass ehrliche Arbeiter die Garantie haben werden, normale und ruhige Arbeitsbedingungen zu haben.
<G-vec00097-001-s113><begin.anfangen><en> We want to hope that Yezhov's mistakes will be eliminated and corrected, that the NKVD will begin to really fight elements hostile to Soviet rule and that honest workers will be assured normal and tranquil working conditions.
<G-vec00097-001-s114><begin.anfangen><de> Und wie oft er auch kaputtgeht und verbrennt, hat er doch normalerweise immer genug Vertrauen und Zuversicht, um von vorne anzufangen und sich wieder auszudehnen.
<G-vec00097-001-s114><begin.anfangen><en> However often it crashes and burns, there is normally enough faith to begin again and repeat the expansion all over again.
<G-vec00097-001-s115><begin.anfangen><de> Die Hoffnung entsteht, wenn man erfahren kann, dass nicht alles verloren ist, und deswegen ist die Übung notwendig, „zu Hause“ anzufangen, bei sich selbst anzufangen.
<G-vec00097-001-s115><begin.anfangen><en> Hope is born when you are able to feel that all is not lost; and for this to happen it is necessary to start “at home”, to begin with yourself.
<G-vec00097-001-s116><begin.anfangen><de> Es ist allgemein, mit einer Dosis von mg 30 anzufangen und sie auf mg 50 allmählich pro Tag zu erhöhen.
<G-vec00097-001-s116><begin.anfangen><en> It is common to begin with a dose of 30 mg and gradually increase it to 50 mg per day.
<G-vec00097-001-s117><begin.anfangen><de> Gefunden sehr bequem in Beijing ist unser Hotel ein bevorzugter Platz, zum und des Platzes, zu erforschen anzufangen zu bleiben.
<G-vec00097-001-s117><begin.anfangen><en> Located very conveniently in Beijing our hotel is a preferred place to stay and begin exploring the place.
<G-vec00097-001-s118><begin.anfangen><de> Dort sind viel von Gründe, warum schlecht klein Neulinge kommen in dünn (ich weiß, daß... wir bilden müssen, ihnen zu glauben kamen in dünnes, mit anzufangen) und gehen Sie zurück nach Hause nach dem Jahr eins, das in Zwanzig wiegt, zerstoße schwereres.
<G-vec00097-001-s118><begin.anfangen><en> There are plenty of reasons why poor little freshmen come in skinny (I know... we'll have to make believe they came in skinny to begin with) and go back home after year one weighing in twenty pounds heavier.
<G-vec00097-001-s119><begin.anfangen><de> Gefunden sehr bequem in Budapest ist unser Hotel ein bevorzugter Platz, zum und des Platzes, zu erforschen anzufangen zu bleiben.
<G-vec00097-001-s119><begin.anfangen><en> Located very conveniently in Budapest our hotel is a preferred place to stay and begin exploring the place.
<G-vec00097-001-s120><begin.anfangen><de> """Um mit etwas Positivem anzufangen: Die kurzen, rhythmischen Sätze in Gegenwartsform und dritter Person entsprechen der Situation des Helden"", so Hubert Winkels."
<G-vec00097-001-s120><begin.anfangen><en> """To begin with something positive: the short, rhythmic sentences in the present tense and the third person correspond to the situation of the hero,"" Hubert Winkels commented."
<G-vec00097-001-s121><begin.anfangen><de> Um anzufangen das herunterladen Sie, Sie sollten Ihrem blocker von herausragenden Fenstern (Pop Up blocker) und Presse den leichten blauen Knopf lahmlegen.
<G-vec00097-001-s121><begin.anfangen><en> To begin the download you should disable your blocker of emergent windows (Pop Up blocker) and press the light blue button.
<G-vec00097-001-s122><begin.anfangen><de> Item, daß im Menschen nicht gar verderbt sei menschlich Natur und Wesen, sondern der Mensch habe noch etwas Gutes an ihm [an sich], auch in geistlichen Sachen, als nämlich Frömmigkeit [*Fähigkeit], Geschicklichkeit, Tüchtigkeit oder Vermögen, in geistlichen Sachen etwas anzufangen, zu wirken oder mitzuwirken.
<G-vec00097-001-s122><begin.anfangen><en> Also, that in man the human nature and essence are not entirely corrupt, but that man still has something good in him, even in spiritual things, namely, capacity, skill, aptness, or ability in spiritual things to begin, to work, or to help working for something [good].
<G-vec00097-001-s123><begin.anfangen><de> Ich habe die Erfahrung gemacht, dass Heilung für viele, die mit diesen Aspekten geboren sind, damit anzufangen scheint, die Verbitterung wahrzunehmen und zu akzeptieren, dass das Misstrauen seine Gültigkeit und Berechtigung hat, in Anbetracht unserer erbärmlichen Menschheitsgeschichte.
<G-vec00097-001-s123><begin.anfangen><en> I have found that healing, for many born with these aspects, seems to begin first with recognising the bitterness, and accepting that some of the mistrust is valid and true, given our sorry human history.
<G-vec00097-001-s124><begin.anfangen><de> Niemand braucht jedoch erst zu warten, bis das Königreich tatsächlich aufgerichtet ist, um das Gesetz Gottes kennenzulernen und anzufangen, danach zu handeln.
<G-vec00097-001-s124><begin.anfangen><en> No one needs to wait, however, until the kingdom is actually established in order to begin learning and putting into practice the law of God.
<G-vec00097-001-s125><begin.anfangen><de> Es ist nötig von vorne anzufangen: das Begießen, die Beleuchtung, die Lufttemperatur.
<G-vec00097-001-s125><begin.anfangen><en> It is necessary to begin from scratch: watering, lighting, air temperature.
<G-vec00097-001-s126><begin.anfangen><de> Che wusste, dass die einzige Weise um die Situation zu beheben, war eine Weltrevolution anzufangen.
<G-vec00097-001-s126><begin.anfangen><en> In Che’s eyes, the only way to remedy the situation was to begin a world revolution.
<G-vec00097-001-s127><begin.anfangen><de> übrigens kompetent Ihnen ist erklärt: jede Kunst hat die Gewohnheit von etwas, anzufangen.
<G-vec00097-001-s127><begin.anfangen><en> By the way, it is competent to you it is declared: any art is accustomed from something to begin.
<G-vec00097-001-s128><begin.anfangen><de> Sie neigen, an der Oberseite anzufangen und in Richtung zur Unterseite zu lesen.
<G-vec00097-001-s128><begin.anfangen><en> They tend to begin at the top and read towards the bottom.
<G-vec00097-001-s129><begin.anfangen><de> Unsere Kinder haben das Potential, das Bewußtsein zu erlangen, das sie brauchen werden, um die Richtung der Zivilisation umzukehren und anzufangen, die Biosphäre unserer Erde wiederherzustellen.
<G-vec00097-001-s129><begin.anfangen><en> Our children have the potential for achieving the awareness needed to reverse civilization’s direction and begin restoring Earth’s biosphere.
<G-vec00097-001-s130><begin.anfangen><de> Um anzufangen, um sich zu verbessern und um sich zu bestätigen.
<G-vec00097-001-s130><begin.anfangen><en> To begin to improve and to get confirmation.
<G-vec00097-001-s131><begin.anfangen><de> Das Nachdenken über die drei Prinzipien kann unseren Begriff der drei Körper bereichern, doch ist es eine Sache, anzufangen zu denken, und eine ganz andere, sein Denken fortgesetzt zu entwickeln.
<G-vec00097-001-s131><begin.anfangen><en> Thought about the three principles can enrich one's conception of the three vehicles, but it is one thing to begin to think and quite another to continue and to develop one's thinking.
<G-vec00097-001-s132><begin.anfangen><de> Ihr könnt andere bitten anzufangen, gemeinsam Meditationen zu halten.
<G-vec00097-001-s132><begin.anfangen><en> You can ask others to begin holding meditations together.
<G-vec00097-001-s114><start.anfangen><de> Ich erzähle dir auch nicht, mein/e Liebe/r, anzufangen über diejenigen nachzudenken, die es härter haben als du.
<G-vec00097-001-s114><start.anfangen><en> Nor am I telling you, dear one, to start thinking about others who have it harder than you.
<G-vec00097-001-s115><start.anfangen><de> Die Hoffnung entsteht, wenn man erfahren kann, dass nicht alles verloren ist, und deswegen ist die Übung notwendig, „zu Hause“ anzufangen, bei sich selbst anzufangen.
<G-vec00097-001-s115><start.anfangen><en> Hope is born when you are able to feel that all is not lost; and for this to happen it is necessary to start “at home”, to begin with yourself.
<G-vec00097-001-s116><start.anfangen><de> Wir hatten einen Millionär als Unterstützung (Chris Curtis von Searchers fame) -- es ist sehr schwierig etwas anzufangen ohne finanzielle Unterstützung.
<G-vec00097-001-s116><start.anfangen><en> We had a millionaire backer (Chris Curtis, of Searchers fame) -- it's very hard to start without
<G-vec00097-001-s117><start.anfangen><de> Der leidgeprüften Bevölkerung möchte ich in diesem Augenblick meine Solidarität zusichern und sie zur Hoffnung ermutigen, um mit der Hilfe aller neu anzufangen.
<G-vec00097-001-s117><start.anfangen><en> At this time I would like to offer those people the assurance of my solidarity, together with a particular encouragement to have the confidence to start again with the help of all.
<G-vec00097-001-s118><start.anfangen><de> Der treue Diener besann sich lange, wie die Sache anzufangen wäre, denn es hielt schwer, nur vor das Angesicht der Königstochter zu kommen.
<G-vec00097-001-s118><start.anfangen><en> The faithful servant long thought about how to start the thing, because it was hard to come just before the face of the Kings daughter.
<G-vec00097-001-s119><start.anfangen><de> Zustand Neu Mit diesen Tees ist Ihr Ball in 5cm Höhe immer die ideale Höhe, um mit Ihrem Driver anzufangen.
<G-vec00097-001-s119><start.anfangen><en> Condition New With these tees, your ball is always at 5cm height the ideal height to start with your driver.
<G-vec00097-001-s120><start.anfangen><de> Da sich der Pariser Herbst schnell nähert, könnte der Zeitpunkt nicht besser sein, um anzufangen, Ihren Trip in diese historische, atemberaubende und romantische Stadt zu planen.
<G-vec00097-001-s120><start.anfangen><en> As autumn in Paris is fast approaching, the time could not be better to start planning your trip to this historical, breathtaking and romantic city .
<G-vec00097-001-s121><start.anfangen><de> Alles in allem ist es offensichtlich die Unfähigkeit, der Bewegung des Fortschritts zu folgen: das Bedürfnis, alles wieder in den Topf zu werfen, um von vorne anzufangen.
<G-vec00097-001-s121><start.anfangen><en> Of course, looking at it as a whole, it is the incapacity to follow the movement of progress: the need to mix everything together again in order to start all over again.
<G-vec00097-001-s122><start.anfangen><de> Der einzige Weg, diese Situation zu überwinden, ist diese Situation rückgängig zu machen, ist die Zurückweisung Gottes zu stoppen und anzufangen, seinen Gegner zurückzuweisen.
<G-vec00097-001-s122><start.anfangen><en> The only way to overcome this situation is to reverse the situation, is to stop the rejection of God and to start the rejection of his opponent.
<G-vec00097-001-s123><start.anfangen><de> Jede Bewegung unterbricht die Kontinuität der Übung und veranlaßt den Meditierenden, von vorn anzufangen.
<G-vec00097-001-s123><start.anfangen><en> Any movement breaks the continuity of the practice and this causes the meditator to start all over again.
<G-vec00097-001-s124><start.anfangen><de> um mit dem Einfachsten anzufangen: die ohmsche Serien-Impedanz.
<G-vec00097-001-s124><start.anfangen><en> Let's start with an easy aspect: the ohmic serial impedance.
<G-vec00097-001-s125><start.anfangen><de> Die Methode, klein anzufangen und dann nach und nach auszubauen, funktioniert nur im Süßwasserbereich (erst ein kleines Becken für Kaltwasserfische, dann wird für Warmwasserfische eine Heizung eingebaut, danach wird für guten Pflanzenwuchs eine gute Beleuchtung und eine Kohlendioxiddüngung installiert).
<G-vec00097-001-s125><start.anfangen><en> "The method ""start small and get larger"" is only suitable with fresh water tanks. There you can start with a small cold water tank, then expanding with a heater to a tropical fish tank. Afterwards you install a carbon dioxide fertilizer and a professional lighting to support the growth of the plants."
<G-vec00097-001-s126><start.anfangen><de> Es ist okay, mit einfachen Büchern anzufangen, so lange wie du später schwierigere liest.
<G-vec00097-001-s126><start.anfangen><en> It is okay to start off with easy books and work your way up.
<G-vec00097-001-s127><start.anfangen><de> Die wirst Du brauchen, um anzufangen, eine Beziehung zu dem Blogger aufzubauen.
<G-vec00097-001-s127><start.anfangen><en> You’ll need those to start building a relationship with the blogger.
<G-vec00097-001-s128><start.anfangen><de> Solche Wettbewerbe geben die Möglichkeit, zu traden am Forex ohne der Abschlagszahlung anzufangen.
<G-vec00097-001-s128><start.anfangen><en> Such contests give a chance to start trading on Forex without deposits.
<G-vec00097-001-s129><start.anfangen><de> Wenn man übel gelaunt ist, beispielsweise, ist es selbstverständlich, dass man nicht das Recht besitzt, zu seinem Arbeitsplsatz zu gehen und anzufangen, auf jeden zu schießen, der sich blicken lässt, wie es in den vergangenen Jahren mehr als einmal in den Vereinigten Staaten geschehen ist.
<G-vec00097-001-s129><start.anfangen><en> If he is disgruntled, for example, he understands that he does not have the right to go to his workplace and start shooting at everyone in sight, as has happened on more than one occasion in the United States in recent years.
<G-vec00097-001-s130><start.anfangen><de> Alles, was du tun musst, ist einen ruhigen, friedlichen Platz zu finden und anzufangen, den Fokus auf deinen Atem zu richten.
<G-vec00097-001-s130><start.anfangen><en> All you have to do is find a quiet, peaceful place and start focusing on your breath.
<G-vec00097-001-s131><start.anfangen><de> „Ja“, flüstert sie und nötigt mich, endlich anzufangen.
<G-vec00097-001-s131><start.anfangen><en> “Yes,” she whispers wanting me to start already.
<G-vec00097-001-s132><start.anfangen><de> Ihr aller sehnlichster Wunsch ist es, ganz unten anzufangen, auf der tiefstmöglichen Stufe des Dienens; so können sie hoffen, die höchstmögliche Ebene erfahrungsmäßiger Bestimmung zu erreichen.
<G-vec00097-001-s132><start.anfangen><en> And they all crave to start at the bottom, on the lowest possible level of ministry; thus may they hope to achieve the highest possible level of experiential destiny.
<G-vec00272-002-s031><beg.anfangen><de> Vorne in der Mitte anfangen (von der rechten Seite).
<G-vec00272-002-s031><beg.anfangen><en> Beg mid front (from the RS).
<G-vec00328-002-s019><relate.anfangen><de> Aber dieses Cardboardium war in unserem Van und irgendwann sagte ich mir dann „Ok, ich werde jetzt etwas damit machen!“ Am Anfang konnte ich nicht wirklich etwas damit anfangen.
<G-vec00328-002-s019><relate.anfangen><en> And this cardboardium was in our van and I was like „Ok, I’m going to do something with it“. I couldn’t really relate to it.
<G-vec00328-002-s020><relate.anfangen><de> Ich habe versucht, einen traurigen Song zu schreiben, mit dem jeder was anfangen kann; egal, ob er gerade seine Partner, seinen Job oder ein Fußballspiel verloren hat.
<G-vec00328-002-s020><relate.anfangen><en> I tried to write a melancholic song that everyone could relate to; whether they just lost their partner, their job or a soccer game.
<G-vec00328-002-s021><relate.anfangen><de> Ich denke, unser neues Material ist mehr auf den Punkt, behandelt allgemeinere Themen, mit denen jeder etwas anfangen kann, anstatt doch eher persönliche Texte zu haben.
<G-vec00328-002-s021><relate.anfangen><en> I think our new material's going to be more to the point, about more general topics that everyone can relate to rather than having more personal lyrics.
<G-vec00038-002-s076><begin.anfangen><de> Es geht darin um vier Intellektuelle aus Jugoslawien, Rumänien, Mazedonien und Ungarn, die mit dem Zerfall des Kommunismus ihre Existenz verloren haben und nun als Handlungsreisende noch einmal von vorne anfangen.
<G-vec00038-002-s076><begin.anfangen><en> The story revolves around four intellectuals from Yugoslavia, Romania, Macedonia and Hungary, who lost to the collapse of communism and now begin their existence as traveling salesman all over again.
<G-vec00038-002-s077><begin.anfangen><de> Bitten Sie um eine kurze Pause, wenn Ihre Hände oder Beine zu zittern anfangen.
<G-vec00038-002-s077><begin.anfangen><en> Request a short break if your hands or legs begin to tremble.
<G-vec00038-002-s078><begin.anfangen><de> Nur dann werdet ihr anfangen, Mich kennen zu lernen, nur dann werdet ihr beginnen, Mich zu sehen, wie Ich wirklich bin.
<G-vec00038-002-s078><begin.anfangen><en> Only then shall you begin to know Me, only then shall you begin to see Me as I truly am.
<G-vec00038-002-s079><begin.anfangen><de> Wenn die Tomaten anfangen rot zu werden, sollte das Gießen reduziert werden, damit die Früchte nicht durch übermäßige Feuchtigkeit gerissen werden.
<G-vec00038-002-s079><begin.anfangen><en> If the tomatoes begin to turn red, then watering should be reduced so that the fruits are not cracked due to excess moisture.
<G-vec00038-002-s080><begin.anfangen><de> Nagelpilz kann dazu führen, dass Ihr Nagel anfangen sich zu verfärben, verdicken und am Rand zu bröckeln.
<G-vec00038-002-s080><begin.anfangen><en> Over time, the nail will begin to discolor as well as thicken and crumble without proper treatment.
<G-vec00038-002-s081><begin.anfangen><de> Bevor wir mit dem Interview anfangen, stellen Sie sich doch in 3-4 Sätzen kurz vor.
<G-vec00038-002-s081><begin.anfangen><en> Mr. Suriyadi,before we begin with the interview, please introduce yourself in 3-4 sentences briefly.
<G-vec00038-002-s082><begin.anfangen><de> Wir werden dadurch eine gute Nachbarschaft herstellen und anfangen, eine gemeinsame eurasische Bestimmung aufzubauen.“ Das sei auch schon die Idee gewesen, die dem Vorschlag der Eurasischen Landbrücke zugrunde lag, die das Schiller-Institut in den 1990er Jahren vorgeschlagen hatte, sagte er.
<G-vec00038-002-s082><begin.anfangen><en> We will thereby create a good neighborhood and begin to build a European common destiny.” This was also the idea behind the notion of the Eurasian Land-Bridge put forward by the Schiller Institute in the 1990s, he said.
<G-vec00038-002-s083><begin.anfangen><de> 13:26 alsdann werdet ihr anfangen zu sagen: Wir haben vor dir gegessen und getrunken, und auf unseren Straßen hast du gelehrt.
<G-vec00038-002-s083><begin.anfangen><en> 13:26 Then ye will begin to say, We have eaten and drank in thy presence, and thou hast taught in our streets.
<G-vec00038-002-s084><begin.anfangen><de> Beim Ansehen dieses Films wird dein Spirit anfangen zu träumen vom Leben in der freien Natur – ganz so, wie es für einen Spirit wie dich vorgesehen ist.
<G-vec00038-002-s084><begin.anfangen><en> While watching this film, your spirit will begin to dream of living in the wild nature - just as it is for a Spirit as you provided.
<G-vec00038-002-s085><begin.anfangen><de> Jedwede eventuelle Gerichtsverhandlung, Streit oder Maßnahme, die aus dieser Vereinbarung erfolgt oder sie angeht, muss am zuständigen Gebiet der Gerichtsbarkeit in der Tschechischen Republik anfangen.
<G-vec00038-002-s085><begin.anfangen><en> Any potential legal proceedings, conflict or action arising from this Agreement or relating to this Agreement must be begin before the court of the judicial authority in the Czech Republic.
<G-vec00038-002-s086><begin.anfangen><de> "Ei," sagte das Brünnchen, "so will ich anfangen zu fließen," und fing an entsetzlich zu fließen.
<G-vec00038-002-s086><begin.anfangen><en> "Oh, ho," said the spring, "then I will begin to flow," and began to flow violently.
<G-vec00038-002-s087><begin.anfangen><de> Ungefähr 7 - 22% von chronischen Nierenerkrankungspatienten beginnen, erworbene Nierenerkrankung zu entwickeln, bevor sie mit ihrer Dialyse anfangen.
<G-vec00038-002-s087><begin.anfangen><en> Approximately 7 – 22% of chronic kidney disease patients start to develop acquired kidney disease before they begin with their dialysis treatment.
<G-vec00038-002-s088><begin.anfangen><de> Und so beginnt ihr euer Lied im Stillen, vielleicht steigt es in eurem Herzen auf, und schafft seinen Weg geradewegs zu euren Lippen, auf denen es zu einer Melodie wird, die zu einer Erinnerung inspiriert, und einen weiteren Jemand inspiriert, mit euch mitzusingen; und wenn dieses Lied zu einem Choral wird, und dieser anfängt, die Ohren und den Geist und die Herzen einer weiteren Person zu füllen, deren Erinnerung mit diesem Lied mitschwingt, dann wird dieser Energiekomplex anfangen, anders zu schwingen; wird anfangen, als ein sozialer Erinnerungskomplex zu schwingen und dann, an diesem Punkt, werdet ihr auf eurem Weg in Richtung eines Eintritts in eine neue Morgendämmerung von Erfahrung gut vorangekommen sein.
<G-vec00038-002-s088><begin.anfangen><en> So you begin your song silently, perhaps it bubbles up within your heart, and makes its way to your very lips, whereupon it becomes a melody which inspires a memory, another to sing along with you, and when the song becomes a chorus, and when it begins to fill the ears and the minds and the hearts of one more whose memory resonates with this song, that energy complex will begin to vibrate differently, will begin to vibrate as a social memory complex, and then, at that point, you will be well on your way towards entering a new dawn of experience.
<G-vec00038-002-s090><begin.anfangen><de> Tatsächlich ist das Zurückschlagen der Einsparungen der einzige Weg, dass Werktätige – die große Mehrheit – anfangen können, ihr Recht auf eine sichere materielle Existenz zu verteidigen.
<G-vec00038-002-s090><begin.anfangen><en> Indeed, beating back austerity is the only way that working people—the vast majority—can begin to defend their right to a secure material existence.
<G-vec00038-002-s091><begin.anfangen><de> Viele der Menschen, die sich derzeit noch nicht auf dem Pfad des bewussten Aufstiegs befinden, werden nun diesen Prozess anfangen, und eine weitere Aufstiegswelle wird sich anbahnen.
<G-vec00038-002-s091><begin.anfangen><en> Many who are not yet on the path of Conscious Ascension will begin through process at this time, and another wave will commence.
<G-vec00038-002-s092><begin.anfangen><de> Wir müssen anfangen in Nährstoffen zu denken, und nicht in Größe der Portionen.
<G-vec00038-002-s092><begin.anfangen><en> We must begin to think in nutrients, and not in the size of the portions.
<G-vec00038-002-s093><begin.anfangen><de> Schließlich war jede Person einmal ein bezauberndes Baby mit nicht weniger charmanten Fersen, aber aus irgendeinem Grund, in ein paar Jahrzehnten (und noch früher), hören die Fersen auf, nicht berührt zu werden, sondern einfach zu gefallen, weil sie anfangen zu knacken.
<G-vec00038-002-s093><begin.anfangen><en> After all, each person was once a charming baby with no less charming heels, but for some reason, in a few decades (and even earlier), the heels cease not to be touched, but simply to please, because they begin to crack.
<G-vec00038-002-s094><begin.anfangen><de> Doch wenn ihr diese Loslösung von eurem eigenen physischen Körper bekommt und ihr an ihn mit (neuer) Frische, Verwunderung und Neugier herangeht, könnt ihr immer noch genug bekommen, um anfangen zu können, euer eigenes Herz schlagen zu fühlen.
<G-vec00038-002-s094><begin.anfangen><en> Yet if you get this detachment from your own physical body and approach it with newness and wonder and curiosity, you can get still enough to begin to feel your own heart beating.
<G-vec00038-002-s096><begin.anfangen><de> Aber wenn ein Kind im Alter von 1 Jahr nicht anfängt zu reden oder zu essen, obwohl sie versuchen, ihn daran zu gewöhnen, werden mitfühlende Eltern tausendundeine Gründe finden, diese Phänomene zu erklären.
<G-vec00038-002-s096><begin.anfangen><en> But if a kid at one-year-old age did not begin to talk or eat independently, although they try to accustom him to this, compassionate parents will find a thousand and one reasons for explaining these phenomena.
<G-vec00038-002-s097><begin.anfangen><de> Nun, ihr wisst, wie es ist, wenn man anfängt zu beten und eine Million Dinge aus dem Nichts aufzutauchen.
<G-vec00038-002-s097><begin.anfangen><en> Well, you know how it is when you begin to pray, a million things start to bring themselves up from out of nowhere.
<G-vec00038-002-s098><begin.anfangen><de> Also, wie schnell man in einem Gespräch über die Menopause anfängt, sich ebenfalls vorgefasster Meinungen über Menschen zu bedienen, die zu rassisierten Anderen gemacht worden sind, und zwar auf eine Art und Weise, die „nicht beleidigend gemeint ist“, sondern „die tatsächlichen Lebenserfahrungen der rassisierten Anderen thematisiert“.
<G-vec00038-002-s098><begin.anfangen><en> So how easy it is in a conversation about the menopause to begin to also tap into taken-for-granted ideas on people who have been made into racialized others in ways which “aren’t about giving offence” but “speaking about real life experiences of racialized others”.
<G-vec00038-002-s099><begin.anfangen><de> Ich hoffe sehr, dass die Befreiung der Krim bereits diesen Sommer anfängt.
<G-vec00038-002-s099><begin.anfangen><en> I really hope that the liberation of the Crimea will begin this summer.
<G-vec00038-002-s100><begin.anfangen><de> 28 Wenn aber dieses anfängt zu geschehen, so sehet auf und erhebet eure Häupter, darum daß sich eure Erlösung naht”.
<G-vec00038-002-s100><begin.anfangen><en> And when these things begin to come to pass, then look up, and lift up your heads; for your redemption draweth nigh”.
<G-vec00038-002-s101><begin.anfangen><de> Es ist schwer zu sagen, wo das Märchenland anfängt.
<G-vec00038-002-s101><begin.anfangen><en> It's hard to say where the fairyland begin.
<G-vec00038-002-s102><begin.anfangen><de> Selleriewürfel in Butter und einer Prise Salz weich dünsten bis es anfängt am Topfboden anzuhängen, dann mit der Sahne aufgießen, sodass noch ein paar Selleriewürfel herausschauen.
<G-vec00038-002-s102><begin.anfangen><en> Sauté the celeriac cubes in butter and pinch of salt until they soften or until they begin to cling to the bottom of the pan. Add the cream until just it almost covers the cubes.
<G-vec00038-002-s103><begin.anfangen><de> Das Problem ist, je klarer ich Sein Gesicht sehe, um so überwältigter bin ich von der Sehnsucht und von der Intensität, von Ihm getrennt zu sein, bis Ich kaum noch bei Bewusstsein bin und es anfängt, vor Kummer zu schmerzen.
<G-vec00038-002-s103><begin.anfangen><en> The problem is, the more clearly I see His face the more longing and intensity of being separated from Him, overtakes me, until I can hardly stay conscious, and I begin to ache with grief.
<G-vec00038-002-s104><begin.anfangen><de> 21:28 Wenn aber dieses zu geschehen anfängt, so richtet euch auf und erhebet eure Häupter, weil eure Erlösung naht.
<G-vec00038-002-s104><begin.anfangen><en> 21:28 When these things begin to take place, stand up and lift up your heads, because your redemption is drawing near."
<G-vec00038-002-s105><begin.anfangen><de> Wenn ihr anfängt, euch über die 3D Schachtel hinaus zu strecken, wird eure Wissenschaft eines Tages das Esoterische tatsächlich rechtfertigen.
<G-vec00038-002-s105><begin.anfangen><en> As you begin to reach out of the 3D box, someday your science will indeed justify the esoteric.
<G-vec00038-002-s106><begin.anfangen><de> Das ist in etwa so, wie wenn man einen kleinen Garten vor der Küchentür anlegen möchte und dann anfängt, nach einem Traktor zu suchen, um alles zu ackern.
<G-vec00038-002-s106><begin.anfangen><en> It is as if one were to establish a small garden by the kitchen door, and then at once begin looking for a tractor to till it with.
<G-vec00038-002-s107><begin.anfangen><de> Sobald man zu schwitzen anfängt oder das Spray mit Wasser in Berühung kommt wird es bröselig und brökelt ab.
<G-vec00038-002-s107><begin.anfangen><en> As soon as I begin to sweat or the spray comes into contact with water it becomes crumbly and flakes off.
<G-vec00038-002-s108><begin.anfangen><de> Wenn ihr anfängt, müde zu werden, verändert die Balance von Gebet und Arbeit – betet mehr und arbeitet weniger.
<G-vec00038-002-s108><begin.anfangen><en> When you begin to grow weary, change the balance of prayer and work; get more prayer, less work.
<G-vec00038-002-s110><begin.anfangen><de> Sprühen Sie nicht den Schaum direkt auf Ihre Hände oder Gesicht, weil der Schaum anfängt, auf Kontakt mit warmer Haut zu schmelzen.
<G-vec00038-002-s110><begin.anfangen><en> Do not spray the foam directly onto your hands or face, because the foam will begin to melt on contact with warm skin.
<G-vec00038-002-s111><begin.anfangen><de> In der Tat gibt es kein einziges 100% zuverlässiges Zeichen, zumindest nicht im ersten Trimester, bis der Magen zu wachsen beginnt und der Fetus sich nicht anfängt zu bewegen.
<G-vec00038-002-s111><begin.anfangen><en> In fact, there is not a single 100% reliable sign, at least in the first trimester, until the stomach has started to grow, and the fetus does not begin to feel moving.
<G-vec00038-002-s112><begin.anfangen><de> Denn das ist der Zeitpunkt, zu dem die Erde anfängt, ihre Schwingung zu verändern.
<G-vec00038-002-s112><begin.anfangen><en> For that is the date when this earth will begin to change its vibration.
<G-vec00038-002-s113><begin.anfangen><de> Nach ein paar Minuten wird der Junge vorschlagen, Bareback-Sex zu haben, in dem Wissen, dass er die Königin nach den Videos von jungen Schulmädchen fragt, mit denen sie akzeptiert und anfängt, sich in demselben Park zu paaren.
<G-vec00038-002-s113><begin.anfangen><en> After a few minutes the boy will propose to have bareback sex knowing that he is asking the queen of the videos of young schoolgirls with which she will accept and begin to copulate in that same park.
<G-vec00038-002-s114><begin.anfangen><de> „Zweifellos spielt Hartnäckigkeit eine Rolle… aber du brauchst sicher noch andere Dinge, um anzufangen“, meinte der Sergeant, um es nicht einfach erscheinen zu lassen.
<G-vec00038-002-s114><begin.anfangen><en> — Without a doubt, tenacity has a part to play in it… but still, you probably need other things going for you to begin with, said the sergeant, trying not to make thing seem too easy.
<G-vec00038-002-s115><begin.anfangen><de> I war versucht mit etwas zu anzufangen wie zu erwähnen, dass mich niemand mehr erinnert oder so.
<G-vec00038-002-s115><begin.anfangen><en> I was tempted to begin with something like mentioning that no one will remember me or anything like that.
<G-vec00038-002-s116><begin.anfangen><de> • Es ist geplant, mit einem Anschlag von Israel auf den Iran anzufangen.
<G-vec00038-002-s116><begin.anfangen><en> It is planned to begin with a strike by Israel on Iran.
<G-vec00038-002-s117><begin.anfangen><de> Ziehen Sie das Kabel vertikal mit Last mit bewerteter verbiegender Geschwindigkeit, Winkel und Zeiten, den Biegeversuch dann anzufangen.
<G-vec00038-002-s117><begin.anfangen><en> Pull the cable vertically with load at rated bending speed, angle and times then to begin the bending test.
<G-vec00038-002-s118><begin.anfangen><de> Der befreiende und erfolgreichere Weg ist es, in dir selbst anzufangen, bevor du auch nur irgendetwas unternimmst.
<G-vec00038-002-s118><begin.anfangen><en> The liberating and more successful path to take is to begin from inside yourself before doing anything.
<G-vec00038-002-s120><begin.anfangen><de> Um mit dem Spielen anzufangen, brauchen Sie sich nur als Benutzer zu registrieren und gehen dann direkt zu dem Spiel, dass Sie gerne spielen möchten.
<G-vec00038-002-s120><begin.anfangen><en> To begin playing, all you need to do is register as a user and go directly to the game you wish to play.
<G-vec00038-002-s121><begin.anfangen><de> Die Parteien erwarten auch eine vierte Phase des Projektes, mindestens der gleichen Größe, um im Oktober 2009 anzufangen, die Anwendungen zu erweitern.
<G-vec00038-002-s121><begin.anfangen><en> The parties also expect a fourth phase of the project, of at least the same magnitude, to begin in October 2009 to expand the applications.
<G-vec00038-002-s122><begin.anfangen><de> In Der letzte Sommer der Reichen gibt es auch eine Perversionsspirale, in die sich die global aufgewachsene Dame Stezewitz verstrickt, wenn sie als jüdisch konnotierte Millionärsadelserbin darauf wartet, dass ihr verhasster Nazi-Großvater endlich stirbt, um dann ein Verhältnis mit dessen Pflegerin anzufangen.
<G-vec00038-002-s122><begin.anfangen><en> Der letzte Sommer der Reichen also contains a spiral of perversion in which global citizen Lady Stezewitz becomes entangled as, being an heir to an aristocrat's millions and of a Jewish background, she awaits the death of her hated Nazi grandfather only to then begin a relationship with his female carer.
<G-vec00038-002-s123><begin.anfangen><de> Wenn wir jetzt auf die einzelnen wichtigeren Zweige des englischen Industrieproletariats näher eingehen sollen, so werden wir, dem oben aufgestellten Prinzip zufolge, mit den Fabrikarbeitern, d.h. denen, die unter dem Fabrikakt stehen, anzufangen haben.
<G-vec00038-002-s123><begin.anfangen><en> FACTORY-HANDS In dealing now with the more important branches of the English manufacturing proletariat, we shall begin, according to the principle already laid down, with the factory-workers, i.e., those who are comprised under the Factory Act.
<G-vec00038-002-s124><begin.anfangen><de> Der gemütliche Seat-Gangart-Trainer stützt ein Kind in einem vertikalen und aufrechten Stand, gehende Bewegungen anzufangen, obwohl das Kind nicht imstande ist, volles Gewicht auf seine Beine zu setzen oder bei der Stellung zu balancieren.
<G-vec00038-002-s124><begin.anfangen><en> The Snug Seat Gait Trainer supports a child in a vertical and upright standing position to begin walking movements even though the child is unable to put full weight on his legs or balance while standing.
<G-vec00038-002-s125><begin.anfangen><de> Doch sind wir nicht bereit, mit den Lehren anzufangen - noch nicht.
<G-vec00038-002-s125><begin.anfangen><en> But we're not ready to begin the teaching - not yet.
<G-vec00038-002-s126><begin.anfangen><de> Er hatte den Mut, alles mit einem kleinen Grüppchen von etwa dreißig oder auch weniger jungen Leuten anzufangen.
<G-vec00038-002-s126><begin.anfangen><en> He had the courage to begin everything with a small group of maybe not even thirty people, and from this seed grew a great tree.
<G-vec00038-002-s127><begin.anfangen><de> Mit diesem Bausatz kann man die verschiedenen Komponente verbinden, um Daten- und Befehlstransport zu prüfen und sie dann als Plattform benutzen, um die Entwicklung von neuen und innovativen medizinischen Anwendungen zuversichtlich anzufangen.
<G-vec00038-002-s127><begin.anfangen><en> By connecting the components in the kit as shown, the developer can verify transfer of data and commands and use them as a platform to reliably begin development of unique and innovative medical and healthcare applications.
<G-vec00038-002-s129><begin.anfangen><de> Diese Sitzung wurde festgelegt, um um 6 P.M. anzufangen.
<G-vec00038-002-s129><begin.anfangen><en> That meeting was scheduled to begin at 6 p.m.
<G-vec00038-002-s130><begin.anfangen><de> ‘Tauchen Sie jetzt mit Empfehlungsform’ mit PADI – das ermöglicht Ihnen Ihr Tauchabenteuer schon zu Hause anzufangen und den Kurs bei uns fertigzumachen.
<G-vec00038-002-s130><begin.anfangen><en> ‘Dive Now Referral Form’ with PADI – which allows you to begin your dive adventure back home and complete the course with us.
<G-vec00038-002-s131><begin.anfangen><de> Nochmals, in diesen Zeiten ist es wichtig anzufangen sich in Bescheidenheit zu üben, Bescheidenheit der Gedanken, Mäßigkeit der Aktionen, Mäßigkeit der Ausgaben, und die Menschheit schreitet in ein Zeitalter in dem sie beginnt den Zug des spirituellen Druckes der Brüderschaft der Menschheit zu spüren.
<G-vec00038-002-s131><begin.anfangen><en> Again, in these times it is important to begin to exercise modesty, modesty in thought, modesty in action, modesty in spending, and mankind is moving into an era where he is beginning to experience the pull of the spiritual pressure of the brotherhood of man.
<G-vec00038-002-s132><begin.anfangen><de> Um anzufangen, PGP zu benutzen, muss man sein eigenes Schlüsselpaar (Öffentlich/Privat) erzeugen.
<G-vec00038-002-s132><begin.anfangen><en> To begin using PGP one has to create his or her own pair of keys (Public/Private).
<G-vec00038-002-s057><start.anfangen><de> Sie finden eine wirklich schöne Urlaubsumgebung vor, in der Sie sich von Anfang an wohl fühlen werden.
<G-vec00038-002-s057><start.anfangen><en> You can find a really nice holiday environment where you will feel from the start.
<G-vec00038-002-s058><start.anfangen><de> Kritische Bau- und Schaltungsteile werden von Anfang an genau definiert.
<G-vec00038-002-s058><start.anfangen><en> Critical parts and circuit components are precisely defined right from the start.
<G-vec00038-002-s059><start.anfangen><de> Behrends war als Ethnologin von Anfang an dabei.
<G-vec00038-002-s059><start.anfangen><en> Behrends was there as an ethnologist right from the start.
<G-vec00038-002-s060><start.anfangen><de> Selbstverständlich begleiten sie auch die Beratung und Planung von Anfang an.
<G-vec00038-002-s060><start.anfangen><en> Naturally, they also accompany consulting and planning from the start.
<G-vec00038-002-s061><start.anfangen><de> Mein Chef hat mich von Anfang an bei meiner Elternzeit-Planung unterstützt.
<G-vec00038-002-s061><start.anfangen><en> My boss supported me in planning my parental leave right from the start.
<G-vec00038-002-s062><start.anfangen><de> Die Anwender der instrumentellen Analytik als unsere Kunden mussten vom Kauf unserer Geräte nicht so sehr überzeugt werden, weil wir von Anfang an ein rundum sorglos Garantiepaket geschnürt haben, das heute in der Summe aller Garantien, die wir geben, weltweit einzigartig in unserem Bereich ist.
<G-vec00038-002-s062><start.anfangen><en> The users of instrumental analysis as our customers did not have to be so much convinced by the purchase of our equipment, because right from the start we put together an all-round carefree guarantee package, which today, in the total of all guarantees we give, is unique in our field worldwide.
<G-vec00038-002-s063><start.anfangen><de> Das Ziel, welches sich Oerlikon mit der Neuausrichtung der Business Unit Oerlikon Systems gesetzt hat, ist, in der nächsten Evolutionsstufe der Nanotechnologie von Anfang an eine führende Rolle einzunehmen.
<G-vec00038-002-s063><start.anfangen><en> Assuming a leadership role in the next evolutionary phase of nanotechnology right from the start is the stated goal of Oerlikon's realignment of the Oerlikon Systems business unit.
<G-vec00038-002-s064><start.anfangen><de> Durch eine Kindersicherung wird von Anfang an der Zugriff auf Seiten verwehrt, die das Kind nicht sehen soll.
<G-vec00038-002-s064><start.anfangen><en> Parental controls prevent access to pages that the child should not see from the start.
<G-vec00038-002-s065><start.anfangen><de> Bei der Entwicklung neuer Steckverbindungen arbeitet Bosch von Anfang an eng mit den Fahrzeugherstellern zusammen.
<G-vec00038-002-s065><start.anfangen><en> Right from the start, Bosch works closely with the vehicle manufactures to develop new plug-in connections.
<G-vec00038-002-s066><start.anfangen><de> Gerade im Bereich der Kunst sind wir auf allen Ebenen der modernen Reproduktionstechnik von Anfang an dabei und können unsere jahrelange Erfahrung in der Bildbranche sinnvoll einsetzen.
<G-vec00038-002-s066><start.anfangen><en> In the specific area of art, we are with you right from the start at all levels of modern reproduction technology and can make wise use of our many years of experience in the image sector.
<G-vec00038-002-s067><start.anfangen><de> Dabei lavierte Venedig fast von Anfang an zwischen den Großmächten, wie Byzanz und dem Heiligen Römischen Reich oder der päpstlichen Macht, nutzte rigoros die Schlagkraft seiner Kriegsflotte und seiner überlegenen Diplomatie, setzte Handelsblockaden und Berufsarmeen ein.
<G-vec00038-002-s067><start.anfangen><en> In this way, right from the start, Venice manoeuvred between the Great Powers, such as Byzantium and the Holy Roman Empire or the Papacy, rigorously used the power of its war fleet and its deliberate diplomacy, set up trading blockades and employed armies of mercenaries.
<G-vec00038-002-s068><start.anfangen><de> Und Sie haben mir bewiesen, dass ich Sie von Anfang an gewaltig unterschätzt habe, denn Sie sind viel stärker, als ich angenommen hatte.
<G-vec00038-002-s068><start.anfangen><en> And now you have shown it to me and with it, you demonstrated that I have underestimated and perhaps misjudged you from the start. For you are much stronger than I ever thought.
<G-vec00038-002-s069><start.anfangen><de> Wenn Sie Ihr Dichtemessgerät oder Refraktometer professionell durch unsere werksgeschulten Servicetechniker installieren lassen, können Sie sich darauf verlassen, dass Ihr Gerät von Anfang an perfekt funktioniert.
<G-vec00038-002-s069><start.anfangen><en> By having your density meter or refractometer professionally installed by our factory-trained Service Technicians, you are assured that your equipment is up and running perfectly from the start.
<G-vec00038-002-s070><start.anfangen><de> Von Anfang an verhandelte die AEC mit der Bildungsabteilung von Western Cape um die Registrierung der Schule.
<G-vec00038-002-s070><start.anfangen><en> From the start the AEC entered negotiations with the Western Cape Department of Education for registration of the school.
<G-vec00038-002-s071><start.anfangen><de> Oh eine Dame namens Julia war die beste, sie war von Anfang an mit mir in Kontakt und ist immer noch, danke Julia, dass du für mich da bist.
<G-vec00038-002-s071><start.anfangen><en> Oh a lady called Julia was the best, she has been in contact with me from the start, and still is, thank you Julia for being there for me.
<G-vec00038-002-s072><start.anfangen><de> „Blood in the Mobile“ wurde von Anfang an als crossmediale Kampagne geplant, die im Vorfeld und während der Dreharbeiten das Publikum mit einbeziehen sollte.
<G-vec00038-002-s072><start.anfangen><en> Right from the start “Blood in the Mobile” was designed as a crossmedia campagne to involve the audience before and while shooting.
<G-vec00038-002-s073><start.anfangen><de> Die perfekte Verbindung der klassischen Optik des Porsche 911 mit hohem Komfort und ausgereifter Technik hat uns von Anfang an gereizt.
<G-vec00038-002-s073><start.anfangen><en> The perfect combination between the classic look of the Porsche 911 and high comfort and well-engineered technology has been appealing to us from the very start.
<G-vec00038-002-s074><start.anfangen><de> Wenn Sie Ihre Schmelz- und Tropfpunktinstrumente professionell durch unsere werksgeschulten Servicetechniker installieren lassen, können Sie sicher sein, dass Ihre Geräte von Anfang an perfekt funktionieren.
<G-vec00038-002-s074><start.anfangen><en> By having your STARe System professionally installed by our factory-trained Service Technicians, you can be assured that your system is up and running perfectly from the start.
<G-vec00038-002-s075><start.anfangen><de> Fujitsus umfassendes Portfolio enthält natürlich von Anfang an Microsoft Hyper-V zur Servervirtualisierung.
<G-vec00038-002-s075><start.anfangen><en> Fujitsu’s comprehensive portfolio of course includes Microsoft’s server virtualization Hyper-V from the very start.
<G-vec00038-002-s076><start.anfangen><de> Für alle wesentlichen Neuerungen in der Gesellschaft braucht es Pioniere, die anfangen.
<G-vec00038-002-s076><start.anfangen><en> Any essential change in society requires pioneers who make a start.
<G-vec00038-002-s077><start.anfangen><de> Beachte, dass Amazon Regeln für alle Verkäufer hat, so dass es einige Zeit dauern kann, bis du tatsächlich anfangen kannst, Schmuck auf deinem Marktplatz zu verkaufen.
<G-vec00038-002-s077><start.anfangen><en> Just note that Amazon has rules in place for all sellers, so it may take some time for you to actually start selling jewelry on their marketplace.
<G-vec00038-002-s078><start.anfangen><de> Ihr Video wird anfangen, den Leuten empfohlen zu werden, und es wird oben auf den Suchergebnissen erscheinen.
<G-vec00038-002-s078><start.anfangen><en> Your video will start getting recommended to people and it will show up on top of searches.
<G-vec00038-002-s079><start.anfangen><de> Die Aufstellung Ihrer Seite mit der Mambo-Bewirtung ist einfach und schnell, so kann jeder ihre eigenen persönlichen oder Geschäftsseiten anfangen.
<G-vec00038-002-s079><start.anfangen><en> Setting up your site with Mambo hosting is simple and quick, so everyone can start their own business or personal sites.
<G-vec00038-002-s080><start.anfangen><de> Malwarebytes Anti-Malware überwacht alle Prozesse und stoppt schädliche Prozesse, bevor sie anfangen.
<G-vec00038-002-s080><start.anfangen><en> Malwarebytes' Anti-Malware monitors every process and stops malicious processes before they even start.
<G-vec00038-002-s081><start.anfangen><de> Sie haben den Import Ihrer Lieder abgeschlossen, nun können Sie OceanKTV TVplayer in HD Station öffnen und anfangen zu singen.
<G-vec00038-002-s081><start.anfangen><en> You have finished importing your songs, now you can open OceanKTV TVplayer on HD Station and start singing.
<G-vec00038-002-s082><start.anfangen><de> Da ich mit einem Naturschwarm (also einer Gruppe Bienen, die sich mit ihrer Königin vom Rest des Volkes getrennt hat und nun nach einem neuen Zuhause sucht) anfangen wollte, sagte ich den Imkerkollegen in der Gegend Bescheid, dass sie in mir einen dankbaren Abnehmer für Schwärme haben – und wurde belacht.
<G-vec00038-002-s082><start.anfangen><en> I wanted to start with a natural swarm (a group of bees and a queen who have decided to split off from the rest off the colony and are looking for a new home), so I told my beekeeper colleagues in the area that I was happy to take any swarms they didn’t want – and they laughed.
<G-vec00038-002-s083><start.anfangen><de> Er muss anfangen zu glauben, daß was er erreichen will möglich ist, daß andere es erreicht haben und daß er es kann.
<G-vec00038-002-s083><start.anfangen><en> He must start to believe that what he wants to achieve is possible, that others have done so and that he can do it.
<G-vec00038-002-s084><start.anfangen><de> Wenn wir auch nur anfangen zu begreifen, wie wunderbar es ist, dass Gott uns dieses Geschenk gewährt, fällt es uns nicht schwer, das Priestertum zu ehren: Sei dankbar und achte die Macht, die dir anvertraut wurde, und verhalte dich entsprechend.
<G-vec00038-002-s084><start.anfangen><en> Act Like a Representative of God If we can start to understand how wonderful it is that God granted us this gift, then honoring the priesthood becomes simple: act with gratitude and respect towards the power you were entrusted.
<G-vec00038-002-s085><start.anfangen><de> Konsequenz dieser Entwicklung ist, dass sie mit dem damit verbundenen Verwaltungsaufwand ab einem bestimmten Punkt uberfordert ¨ sind und anfangen den Schutz ihrer pers¨ onlichen Daten zu vernachl¨ assigen.
<G-vec00038-002-s085><start.anfangen><en> Consequently, at some point they are overwhelmed with the administrative effort and start to neglect protection of their private data. The results are increased risks of identity theft and subsequent fraud.
<G-vec00038-002-s086><start.anfangen><de> Wenn die Menschen anfangen Juice Plus zu nehmen, ändern sie ihr gesamtes Verhalten.
<G-vec00038-002-s086><start.anfangen><en> When people start taking Juice Plus, they change their entire behavior.
<G-vec00038-002-s087><start.anfangen><de> Bleibt noch zu sagen, dass ich mich demnächst in eine Fahrschule einschreiben möchte und endlich anfangen kann, bei einer Bank Geld zu sparen.
<G-vec00038-002-s087><start.anfangen><en> For the rest I will be enrolling into a driving school and can start saving up at the bank.
<G-vec00038-002-s088><start.anfangen><de> Ab Mai wollen wir anfangen, neue Projekte zu planen und werden euch auf dem Laufenden halten.
<G-vec00038-002-s088><start.anfangen><en> We would like to start planning new projects from May and will keep you up to date with this.
<G-vec00038-002-s089><start.anfangen><de> Es besteht auch die Chance, dass Weizen und Rote Bete Samen abgeben, so dass du mit einem neuen Bauernhof anfangen kannst.
<G-vec00038-002-s089><start.anfangen><en> Wheat and beetroot has a chance of dropping seeds as well, so you can start a new farm.
<G-vec00038-002-s090><start.anfangen><de> Der Wert eines Attributes des Typs ID kann nur solche Zeichen enthalten, die auch für NMTOKEN erlaubt sind, und muss zusätzlich mit einem Buchstaben anfangen.
<G-vec00038-002-s090><start.anfangen><en> Description The value of an attribute of ID type can contain only characters permitted for NMTOKEN and must start with a letter.
<G-vec00038-002-s091><start.anfangen><de> Wenn du lieber keine Vokabellektion selbst erstellen möchtest, kannst du auch schon existierende Lektionen von anderen bab.la Nutzern auswählen und sofort mit dem Lernen anfangen.
<G-vec00038-002-s091><start.anfangen><en> If you would rather skip the vocabulary lesson drafting process, you can choose among existing lessons created by other bab.la users and start learning straight away.
<G-vec00038-002-s092><start.anfangen><de> Von dem Platz vor dem Hotel können Sie verschiedene Bergwanderungen anfangen.
<G-vec00038-002-s092><start.anfangen><en> From the square in front of the hotel you can start several different mountain hikes, which all end again at the hotel.
<G-vec00038-002-s093><start.anfangen><de> Wie ich euch beim letzten Post schon erzählte, haben wir schon früher mit der Arbeit anfangen können, als geplant.
<G-vec00038-002-s093><start.anfangen><en> told you in the last Post, that we could start our work earlier, than we thougt.
<G-vec00038-002-s094><start.anfangen><de> Reiche Länder wie Schweden müssen anfangen, die Emissionen wenigstens um 15 % pro Jahr zu verringern.
<G-vec00038-002-s094><start.anfangen><en> Rich countries like Sweden need to start reducing emissions by at least 15 percent every year.
<G-vec00038-002-s095><start.anfangen><de> Ich habe mich zwar gegen gute Vorsätze für's neue Jahr entschieden, aber wenn ich welche gemacht hätte, wäre es, nicht nur neue Projekte anzufangen, sondern auch fertig zu stellen - und sie Euch zu zeigen....
<G-vec00038-002-s095><start.anfangen><en> opted against New Year's resolutions for 2010, but if I made any, I would have decided not only to start but to finish new projects - and, of course, to show you...
<G-vec00038-002-s096><start.anfangen><de> Ein Praktikum in einer unbekannte Stadt anzufangen, mit Leute die du noch nicht kennst, ohne dafür ausgebildet zu sein verlangt viele Mut, Gelassenheit und Motivation.
<G-vec00038-002-s096><start.anfangen><en> To start a new working experience in an unknown city, with people you never saw in your life, doing a job you never did before requires a lot of courage, calm and motivation.
<G-vec00038-002-s097><start.anfangen><de> Der komfortable Transfer mit Autobuses Mesa ist eine beliebte Alternative um den Urlaub auf La Gomera entspannt anzufangen.
<G-vec00038-002-s097><start.anfangen><en> The comfortable transfer with buses Mesa is a popular alternative to start your holiday on La Gomera relaxed.
<G-vec00038-002-s098><start.anfangen><de> Jetzt ist eine gute Zeit, mit einer gesunden Ernährung anzufangen.
<G-vec00038-002-s098><start.anfangen><en> Now is a great time to start eating healthy.
<G-vec00038-002-s099><start.anfangen><de> Um anzufangen, gib deine E-Mail und dein Passwort (zur Überprüfung zweimal) ein, damit du nächstes Mal wiederkommen und dein Abenteuer fortsetzen kannst.
<G-vec00038-002-s099><start.anfangen><en> To start, provide us your email and double check your password so you could come again and continue your adventure.
<G-vec00038-002-s100><start.anfangen><de> Sie befinden sich sicherlich in einem Park oder am Schulausgang und haben zum ersten Mal verspürt, was wir die „erste Liebe“ nennen, das Gefühl des geheimen Einverständnisses, mit dem sie zu träumen anzufangen.
<G-vec00038-002-s100><start.anfangen><en> They are probably in the park or coming out of the school and have just felt, for the first time, what we call ‘the first love’, that feeling of complicity that makes them start to dream.
<G-vec00038-002-s101><start.anfangen><de> Und manchen Persönlichkeiten fällt es von Natur aus schwieriger mit neuen Kunden einfach ein Gespräch anzufangen.
<G-vec00038-002-s101><start.anfangen><en> This, sometimes, can translate into feeling awkward when having to start a conversation with a new client.
<G-vec00038-002-s102><start.anfangen><de> Zum Beispiel habe ich geplant mehr Sport zu machen, oder besser gesagt, wieder damit anzufangen.
<G-vec00038-002-s102><start.anfangen><en> For example I've planned to do more sport, or rather to start again with it.
<G-vec00038-002-s103><start.anfangen><de> Die Studenten sind herzlich eingeladen, mit dem Unterricht an jedem Tag der Woche, zu jeder Zeit des Jahres anzufangen und können wählen, wie viele Stunden pro Tag/Woche sie studieren möchten.
<G-vec00038-002-s103><start.anfangen><en> Students are welcome to start their classes any day of the week, at any time of the year, with a choice of how many hours per day/ per week they wish to study.
<G-vec00038-002-s104><start.anfangen><de> Um das Besuchen anzufangen, klicken Sie auf das Departement Ihres Standortes.
<G-vec00038-002-s104><start.anfangen><en> To start your visit, click on the department according to your position.
<G-vec00038-002-s105><start.anfangen><de> Klicke "Next" an, um anzufangen.
<G-vec00038-002-s105><start.anfangen><en> Click "Next" to start.
<G-vec00038-002-s106><start.anfangen><de> Wählen sie das gewünschte Volume von der 'Volume(s)' Liste aus und klicken sie auf die Pfeil Taste in der unteren rechten Ecke des Bildschirms um mit dem scannen anzufangen.
<G-vec00038-002-s106><start.anfangen><en> On the flying pane to the right, click the desired data recovery option to start scanning. Scanning Process
<G-vec00038-002-s107><start.anfangen><de> Vorsicht hiermit: Es kann dir leicht passieren, dass du in der Theorie viel weißt, aber einfach nicht den richtigen Moment findest, um mit dem Sprechen anzufangen.
<G-vec00038-002-s107><start.anfangen><en> He certainly knows a lot of theory, and it all sounds right in his head, but he struggles to find the right moment to actually start talking.
<G-vec00038-002-s108><start.anfangen><de> Global Research 9 May 2011: Es gab nie eine solche Gelegenheit für die US-Regierung, ein Ereignis unter falscher Flagge zu inszenieren, um noch einen weiteren Krieg anzufangen, wie heute.
<G-vec00038-002-s108><start.anfangen><en> Global Research 9 May 2011: There has never been such an opportunity for the US government to stage a false flag event in order to start yet another war as there is today.
<G-vec00038-002-s109><start.anfangen><de> Grabe ein paar klobige Diamanten aus, welche das Scatter-Symbol darstellen, um anzufangen, deine mächtigen Belohnungen einzusammeln.
<G-vec00038-002-s109><start.anfangen><en> Dig out some chunky diamonds, which represent the scatters, to start collecting your mighty rewards.
<G-vec00038-002-s110><start.anfangen><de> Nach dem Einchecken ins Hotel am Mittag treffen Sie Ihren Reiseführer um die Besichtigung in der Hauptstadt von Usbekistan anzufangen, die größte Stadt in Zentralasien.
<G-vec00038-002-s110><start.anfangen><en> Check in to the hotel from noon. Meet your guide to start sightseeing in the capital of Uzbekistan, the biggest city in Central Asia.
<G-vec00038-002-s111><start.anfangen><de> Es könnte sein, daß die Fähigkeit, Weltkriege anzufangen, nicht mehr das Privileg der Deutschen ist.
<G-vec00038-002-s111><start.anfangen><en> It could be that the ability to start world wars is no longer the privilege of Germans.
<G-vec00038-002-s112><start.anfangen><de> Ihr habt keine Ahnung wie ich und wir alle uns darauf freuen wieder anzufangen zu arbeiten, nach Europa zu kommen und die TV Show aufzunehmen.
<G-vec00038-002-s112><start.anfangen><en> You have NO idea how READY I am, and WE are, to start working again, coming to Europe, and start filming our new TV show.
<G-vec00038-002-s113><start.anfangen><de> Es gibt genug Zeit, auf viele Links zu klicken, das Internet zu erforschen und anzufangen, Menschen online zu folgen.
<G-vec00038-002-s113><start.anfangen><en> Time to click on plenty of links, go down the rabbit holes, and start to follow people.
<G-vec00038-002-s076><start_off.anfangen><de> Für alle wesentlichen Neuerungen in der Gesellschaft braucht es Pioniere, die anfangen.
<G-vec00038-002-s076><start_off.anfangen><en> Any essential change in society requires pioneers who make a start.
<G-vec00038-002-s077><start_off.anfangen><de> Beachte, dass Amazon Regeln für alle Verkäufer hat, so dass es einige Zeit dauern kann, bis du tatsächlich anfangen kannst, Schmuck auf deinem Marktplatz zu verkaufen.
<G-vec00038-002-s077><start_off.anfangen><en> Just note that Amazon has rules in place for all sellers, so it may take some time for you to actually start selling jewelry on their marketplace.
<G-vec00038-002-s078><start_off.anfangen><de> Ihr Video wird anfangen, den Leuten empfohlen zu werden, und es wird oben auf den Suchergebnissen erscheinen.
<G-vec00038-002-s078><start_off.anfangen><en> Your video will start getting recommended to people and it will show up on top of searches.
<G-vec00038-002-s079><start_off.anfangen><de> Die Aufstellung Ihrer Seite mit der Mambo-Bewirtung ist einfach und schnell, so kann jeder ihre eigenen persönlichen oder Geschäftsseiten anfangen.
<G-vec00038-002-s079><start_off.anfangen><en> Setting up your site with Mambo hosting is simple and quick, so everyone can start their own business or personal sites.
<G-vec00038-002-s080><start_off.anfangen><de> Malwarebytes Anti-Malware überwacht alle Prozesse und stoppt schädliche Prozesse, bevor sie anfangen.
<G-vec00038-002-s080><start_off.anfangen><en> Malwarebytes' Anti-Malware monitors every process and stops malicious processes before they even start.
<G-vec00038-002-s081><start_off.anfangen><de> Sie haben den Import Ihrer Lieder abgeschlossen, nun können Sie OceanKTV TVplayer in HD Station öffnen und anfangen zu singen.
<G-vec00038-002-s081><start_off.anfangen><en> You have finished importing your songs, now you can open OceanKTV TVplayer on HD Station and start singing.
<G-vec00038-002-s082><start_off.anfangen><de> Da ich mit einem Naturschwarm (also einer Gruppe Bienen, die sich mit ihrer Königin vom Rest des Volkes getrennt hat und nun nach einem neuen Zuhause sucht) anfangen wollte, sagte ich den Imkerkollegen in der Gegend Bescheid, dass sie in mir einen dankbaren Abnehmer für Schwärme haben – und wurde belacht.
<G-vec00038-002-s082><start_off.anfangen><en> I wanted to start with a natural swarm (a group of bees and a queen who have decided to split off from the rest off the colony and are looking for a new home), so I told my beekeeper colleagues in the area that I was happy to take any swarms they didn’t want – and they laughed.
<G-vec00038-002-s083><start_off.anfangen><de> Er muss anfangen zu glauben, daß was er erreichen will möglich ist, daß andere es erreicht haben und daß er es kann.
<G-vec00038-002-s083><start_off.anfangen><en> He must start to believe that what he wants to achieve is possible, that others have done so and that he can do it.
<G-vec00038-002-s084><start_off.anfangen><de> Wenn wir auch nur anfangen zu begreifen, wie wunderbar es ist, dass Gott uns dieses Geschenk gewährt, fällt es uns nicht schwer, das Priestertum zu ehren: Sei dankbar und achte die Macht, die dir anvertraut wurde, und verhalte dich entsprechend.
<G-vec00038-002-s084><start_off.anfangen><en> Act Like a Representative of God If we can start to understand how wonderful it is that God granted us this gift, then honoring the priesthood becomes simple: act with gratitude and respect towards the power you were entrusted.
<G-vec00038-002-s085><start_off.anfangen><de> Konsequenz dieser Entwicklung ist, dass sie mit dem damit verbundenen Verwaltungsaufwand ab einem bestimmten Punkt uberfordert ¨ sind und anfangen den Schutz ihrer pers¨ onlichen Daten zu vernachl¨ assigen.
<G-vec00038-002-s085><start_off.anfangen><en> Consequently, at some point they are overwhelmed with the administrative effort and start to neglect protection of their private data. The results are increased risks of identity theft and subsequent fraud.
<G-vec00038-002-s086><start_off.anfangen><de> Wenn die Menschen anfangen Juice Plus zu nehmen, ändern sie ihr gesamtes Verhalten.
<G-vec00038-002-s086><start_off.anfangen><en> When people start taking Juice Plus, they change their entire behavior.
<G-vec00038-002-s087><start_off.anfangen><de> Bleibt noch zu sagen, dass ich mich demnächst in eine Fahrschule einschreiben möchte und endlich anfangen kann, bei einer Bank Geld zu sparen.
<G-vec00038-002-s087><start_off.anfangen><en> For the rest I will be enrolling into a driving school and can start saving up at the bank.
<G-vec00038-002-s088><start_off.anfangen><de> Ab Mai wollen wir anfangen, neue Projekte zu planen und werden euch auf dem Laufenden halten.
<G-vec00038-002-s088><start_off.anfangen><en> We would like to start planning new projects from May and will keep you up to date with this.
<G-vec00038-002-s089><start_off.anfangen><de> Es besteht auch die Chance, dass Weizen und Rote Bete Samen abgeben, so dass du mit einem neuen Bauernhof anfangen kannst.
<G-vec00038-002-s089><start_off.anfangen><en> Wheat and beetroot has a chance of dropping seeds as well, so you can start a new farm.
<G-vec00038-002-s090><start_off.anfangen><de> Der Wert eines Attributes des Typs ID kann nur solche Zeichen enthalten, die auch für NMTOKEN erlaubt sind, und muss zusätzlich mit einem Buchstaben anfangen.
<G-vec00038-002-s090><start_off.anfangen><en> Description The value of an attribute of ID type can contain only characters permitted for NMTOKEN and must start with a letter.
<G-vec00038-002-s091><start_off.anfangen><de> Wenn du lieber keine Vokabellektion selbst erstellen möchtest, kannst du auch schon existierende Lektionen von anderen bab.la Nutzern auswählen und sofort mit dem Lernen anfangen.
<G-vec00038-002-s091><start_off.anfangen><en> If you would rather skip the vocabulary lesson drafting process, you can choose among existing lessons created by other bab.la users and start learning straight away.
<G-vec00038-002-s092><start_off.anfangen><de> Von dem Platz vor dem Hotel können Sie verschiedene Bergwanderungen anfangen.
<G-vec00038-002-s092><start_off.anfangen><en> From the square in front of the hotel you can start several different mountain hikes, which all end again at the hotel.
<G-vec00038-002-s093><start_off.anfangen><de> Wie ich euch beim letzten Post schon erzählte, haben wir schon früher mit der Arbeit anfangen können, als geplant.
<G-vec00038-002-s093><start_off.anfangen><en> told you in the last Post, that we could start our work earlier, than we thougt.
<G-vec00038-002-s094><start_off.anfangen><de> Reiche Länder wie Schweden müssen anfangen, die Emissionen wenigstens um 15 % pro Jahr zu verringern.
<G-vec00038-002-s094><start_off.anfangen><en> Rich countries like Sweden need to start reducing emissions by at least 15 percent every year.
<G-vec00038-002-s095><start_off.anfangen><de> Ich habe mich zwar gegen gute Vorsätze für's neue Jahr entschieden, aber wenn ich welche gemacht hätte, wäre es, nicht nur neue Projekte anzufangen, sondern auch fertig zu stellen - und sie Euch zu zeigen....
<G-vec00038-002-s095><start_off.anfangen><en> opted against New Year's resolutions for 2010, but if I made any, I would have decided not only to start but to finish new projects - and, of course, to show you...
<G-vec00038-002-s096><start_off.anfangen><de> Ein Praktikum in einer unbekannte Stadt anzufangen, mit Leute die du noch nicht kennst, ohne dafür ausgebildet zu sein verlangt viele Mut, Gelassenheit und Motivation.
<G-vec00038-002-s096><start_off.anfangen><en> To start a new working experience in an unknown city, with people you never saw in your life, doing a job you never did before requires a lot of courage, calm and motivation.
<G-vec00038-002-s097><start_off.anfangen><de> Der komfortable Transfer mit Autobuses Mesa ist eine beliebte Alternative um den Urlaub auf La Gomera entspannt anzufangen.
<G-vec00038-002-s097><start_off.anfangen><en> The comfortable transfer with buses Mesa is a popular alternative to start your holiday on La Gomera relaxed.
<G-vec00038-002-s098><start_off.anfangen><de> Jetzt ist eine gute Zeit, mit einer gesunden Ernährung anzufangen.
<G-vec00038-002-s098><start_off.anfangen><en> Now is a great time to start eating healthy.
<G-vec00038-002-s099><start_off.anfangen><de> Um anzufangen, gib deine E-Mail und dein Passwort (zur Überprüfung zweimal) ein, damit du nächstes Mal wiederkommen und dein Abenteuer fortsetzen kannst.
<G-vec00038-002-s099><start_off.anfangen><en> To start, provide us your email and double check your password so you could come again and continue your adventure.
<G-vec00038-002-s100><start_off.anfangen><de> Sie befinden sich sicherlich in einem Park oder am Schulausgang und haben zum ersten Mal verspürt, was wir die „erste Liebe“ nennen, das Gefühl des geheimen Einverständnisses, mit dem sie zu träumen anzufangen.
<G-vec00038-002-s100><start_off.anfangen><en> They are probably in the park or coming out of the school and have just felt, for the first time, what we call ‘the first love’, that feeling of complicity that makes them start to dream.
<G-vec00038-002-s101><start_off.anfangen><de> Und manchen Persönlichkeiten fällt es von Natur aus schwieriger mit neuen Kunden einfach ein Gespräch anzufangen.
<G-vec00038-002-s101><start_off.anfangen><en> This, sometimes, can translate into feeling awkward when having to start a conversation with a new client.
<G-vec00038-002-s102><start_off.anfangen><de> Zum Beispiel habe ich geplant mehr Sport zu machen, oder besser gesagt, wieder damit anzufangen.
<G-vec00038-002-s102><start_off.anfangen><en> For example I've planned to do more sport, or rather to start again with it.
<G-vec00038-002-s103><start_off.anfangen><de> Die Studenten sind herzlich eingeladen, mit dem Unterricht an jedem Tag der Woche, zu jeder Zeit des Jahres anzufangen und können wählen, wie viele Stunden pro Tag/Woche sie studieren möchten.
<G-vec00038-002-s103><start_off.anfangen><en> Students are welcome to start their classes any day of the week, at any time of the year, with a choice of how many hours per day/ per week they wish to study.
<G-vec00038-002-s104><start_off.anfangen><de> Um das Besuchen anzufangen, klicken Sie auf das Departement Ihres Standortes.
<G-vec00038-002-s104><start_off.anfangen><en> To start your visit, click on the department according to your position.
<G-vec00038-002-s105><start_off.anfangen><de> Klicke "Next" an, um anzufangen.
<G-vec00038-002-s105><start_off.anfangen><en> Click "Next" to start.
<G-vec00038-002-s106><start_off.anfangen><de> Wählen sie das gewünschte Volume von der 'Volume(s)' Liste aus und klicken sie auf die Pfeil Taste in der unteren rechten Ecke des Bildschirms um mit dem scannen anzufangen.
<G-vec00038-002-s106><start_off.anfangen><en> On the flying pane to the right, click the desired data recovery option to start scanning. Scanning Process
<G-vec00038-002-s107><start_off.anfangen><de> Vorsicht hiermit: Es kann dir leicht passieren, dass du in der Theorie viel weißt, aber einfach nicht den richtigen Moment findest, um mit dem Sprechen anzufangen.
<G-vec00038-002-s107><start_off.anfangen><en> He certainly knows a lot of theory, and it all sounds right in his head, but he struggles to find the right moment to actually start talking.
<G-vec00038-002-s108><start_off.anfangen><de> Global Research 9 May 2011: Es gab nie eine solche Gelegenheit für die US-Regierung, ein Ereignis unter falscher Flagge zu inszenieren, um noch einen weiteren Krieg anzufangen, wie heute.
<G-vec00038-002-s108><start_off.anfangen><en> Global Research 9 May 2011: There has never been such an opportunity for the US government to stage a false flag event in order to start yet another war as there is today.
<G-vec00038-002-s109><start_off.anfangen><de> Grabe ein paar klobige Diamanten aus, welche das Scatter-Symbol darstellen, um anzufangen, deine mächtigen Belohnungen einzusammeln.
<G-vec00038-002-s109><start_off.anfangen><en> Dig out some chunky diamonds, which represent the scatters, to start collecting your mighty rewards.
<G-vec00038-002-s110><start_off.anfangen><de> Nach dem Einchecken ins Hotel am Mittag treffen Sie Ihren Reiseführer um die Besichtigung in der Hauptstadt von Usbekistan anzufangen, die größte Stadt in Zentralasien.
<G-vec00038-002-s110><start_off.anfangen><en> Check in to the hotel from noon. Meet your guide to start sightseeing in the capital of Uzbekistan, the biggest city in Central Asia.
<G-vec00038-002-s111><start_off.anfangen><de> Es könnte sein, daß die Fähigkeit, Weltkriege anzufangen, nicht mehr das Privileg der Deutschen ist.
<G-vec00038-002-s111><start_off.anfangen><en> It could be that the ability to start world wars is no longer the privilege of Germans.
<G-vec00038-002-s112><start_off.anfangen><de> Ihr habt keine Ahnung wie ich und wir alle uns darauf freuen wieder anzufangen zu arbeiten, nach Europa zu kommen und die TV Show aufzunehmen.
<G-vec00038-002-s112><start_off.anfangen><en> You have NO idea how READY I am, and WE are, to start working again, coming to Europe, and start filming our new TV show.
<G-vec00038-002-s113><start_off.anfangen><de> Es gibt genug Zeit, auf viele Links zu klicken, das Internet zu erforschen und anzufangen, Menschen online zu folgen.
<G-vec00038-002-s113><start_off.anfangen><en> Time to click on plenty of links, go down the rabbit holes, and start to follow people.
<G-vec00097-002-s380><begin.anfangen><de> Sobald Schlüsselbakterien dieses Melatonin bemerken, fangen sie an auszuschwärmen und werden aktiver.
<G-vec00097-002-s380><begin.anfangen><en> Once key bacteria sense this melatonin, they begin swarming and become more active.
<G-vec00097-002-s381><begin.anfangen><de> Männchen fangen an, im März und bis Mai Rufe auszustossen.
<G-vec00097-002-s381><begin.anfangen><en> Males begin to call around March and throughout May.
<G-vec00097-002-s382><begin.anfangen><de> Widerstehen Sie dem stärksten Drang zu hungern geht nicht, und Sie fangen an, mehr zu essen, was weiter verstanden wird: Sie gewinnen noch mehr überschüssiges Fett als vor der Diät.
<G-vec00097-002-s382><begin.anfangen><en> Resist the strongest urge to hunger does not go, and you begin to eat more, which is further understood: you gain even more excess fat than before the diet.
<G-vec00097-002-s383><begin.anfangen><de> 2.PaymentTerms: T / T, L / C, Wir fangen an, Ihre Waren nach Eingang Ihrer 30% -Zahlung im Voraus zu produzieren.
<G-vec00097-002-s383><begin.anfangen><en> 2.PaymentTerms: T/T,L/C, We'll begin to produce your goods afterreceipt of your 30% payment in advance.
<G-vec00097-002-s384><begin.anfangen><de> Sobald Sie darauf klicken, fangen die Rollen an sich zu drehen.
<G-vec00097-002-s384><begin.anfangen><en> If you click on this, the reels will then begin to spin.
<G-vec00097-002-s385><begin.anfangen><de> Dann fangen wir mit der Erwähnung an, dass der Jamón aus iberischen Schweinen hergestellt wird, Tieren, die einzigartig in der Welt sind und die die Fähigkeit haben, Fett in den Muskel einzudringen.
<G-vec00097-002-s385><begin.anfangen><en> Then, we begin with the mention that the jamón is made from Iberian pigs, animals unique in the world, which have the ability to infiltrate fat into the muscle.
<G-vec00097-002-s386><begin.anfangen><de> Gepostet Fangen wir mit der Anführerin an: Christine von "Simply Nailogical" ist die YouTuberin, die das Ganze ins Rollen gebracht hat, indem sie ihre Nägel mit mehr als 100 Schichten Nagellack lackierte.
<G-vec00097-002-s386><begin.anfangen><en> Share On snapchat 1. Let's begin with the ringleader: the YouTuber who started this whole thing by painting her nails with more than 100 layers of nail polish.
<G-vec00097-002-s387><begin.anfangen><de> Rhein-Main-Basis, Deutschland (UNSAFENS) - So wie der Irak sich nach 35 Jahren der Unterdrückung und Grausamkeit unter Saddam Hussein aufbaut, so fangen schließlich sieben Männer und ihre Familien an, die Stücke ihrer Leben zu reparieren, die durch Saddam´s Ungerechtigkeit zerstört wurde.
<G-vec00097-002-s387><begin.anfangen><en> Seven Iraqis head to Houston for treatment As Iraq rebuilds after 35 years of oppression and cruelty under Saddam Hussein, seven men and their families will finally begin to repair the pieces of their lives destroyed by the former leader’s injustice.
<G-vec00097-002-s388><begin.anfangen><de> Krimis fangen fast immer mit einem Mord an.
<G-vec00097-002-s388><begin.anfangen><en> Mysteries almost always begin with a murder.
<G-vec00097-002-s389><begin.anfangen><de> Fangen wir jedoch an, das Gegebene anzuzweifeln, entsteht Bewegung.
<G-vec00097-002-s389><begin.anfangen><en> But if we begin to doubt the given, there is movement.
<G-vec00097-002-s390><begin.anfangen><de> «Wir fangen mit ersten kleineren Optimierungen an, die bald schon große Wirkung zeigen.
<G-vec00097-002-s390><begin.anfangen><en> “We begin with some minor optimisations, which soon have a major impact.
<G-vec00097-002-s391><begin.anfangen><de> Wir fangen jetzt schon mal an, alles im Detail zu planen - also trag Du/tragen Sie diesen Termin schon einmal rot markiert im Kalender 2017 ein.
<G-vec00097-002-s391><begin.anfangen><en> Now we begin to plan everything in detail - while you add this date marked in red in your 2017th calendar.
<G-vec00097-002-s392><begin.anfangen><de> Wir fangen an, das Leben ganz anders wahrzunehmen: nicht durch einige hundert Jahre begrenzt, sondern endlos in Zeit und Raum, über allen Beschränkungen.
<G-vec00097-002-s392><begin.anfangen><en> We begin to perceive life completely differently: not limited by some hundred years, but endless in time and space, above all limitations.
<G-vec00097-002-s393><begin.anfangen><de> Leckere Buds fangen als einzigartig geformte und oftmals marmorierte Samen an.
<G-vec00097-002-s393><begin.anfangen><en> Mouth-watering buds begin as uniquely shaped and often marbled seeds.
<G-vec00097-002-s394><begin.anfangen><de> Wenn wir zu viel auf dieses Teil richten, fangen wir an, getrennt vom Rest von Menschlichkeit zu werden, und Außenseite Kräfte haben mehr Steuerung über uns.
<G-vec00097-002-s394><begin.anfangen><en> When we focus too much on this part, we begin to become separated from the rest of humanity, and outside forces have more control over us.
<G-vec00097-002-s395><begin.anfangen><de> Um noch mehr Bewegung in Ihren Arbeitstag hinzuzufügen, rollen Sie einfach das Fahrrad unter Ihren stehenden Schreibtisch und fangen Sie an zu treten.
<G-vec00097-002-s395><begin.anfangen><en> To add even more movement into your workday, simply roll the desk bike pedaler under your adjustable height standing desk and begin pedaling.
<G-vec00097-002-s396><begin.anfangen><de> Die Vorführungen fangen jede 10-15 Minuten an.
<G-vec00097-002-s396><begin.anfangen><en> Shows begin in every 10-15 minutes.
<G-vec00097-002-s397><begin.anfangen><de> Schaltend zu den männlichen Benutzern, vor der Erhöhung dieser Menge während eines Zyklus fangen viele Kerle mit einer Dosierung 20mg täglich Anavar an.
<G-vec00097-002-s397><begin.anfangen><en> Switching to male users, many guys begin with a 20mg daily Anavar dosage before increasing this amount throughout a cycle.
<G-vec00097-002-s398><begin.anfangen><de> Nach Stimulierung fangen Stammzellen innerhalb der subventricular und subgranular Zonen an sich stark zu vermehren, um die Neuroblasts zu bilden und schließlich reifen in Neuronen.
<G-vec00097-002-s398><begin.anfangen><en> Upon stimulation, stem cells within the subventricular and subgranular zones begin to proliferate to form neuroblasts, eventually maturing into neurons.
