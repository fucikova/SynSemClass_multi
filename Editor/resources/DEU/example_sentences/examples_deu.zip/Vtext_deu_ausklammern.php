<G-vec00460-002-s044><omit.ausklammern><de> Hier ist etwas gescheitert, dessen Ursprung verborgen bleibt und dessen Kontext die Fotografien ganz bewußt ausklammern.
<G-vec00460-002-s044><omit.ausklammern><en> Here something has failed whose origin remains hidden and whose context the images deliberately omit.
