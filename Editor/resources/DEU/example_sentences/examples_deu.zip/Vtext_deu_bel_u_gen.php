<G-vec00003-001-s038><lie.belügen><de> Zweitens möchte ich darauf hinweisen, dass nicht alle von uns Kunden belügen werden.
<G-vec00003-001-s038><lie.belügen><en> Second, I’d like to point out that not all of us are going to lie to customers.
<G-vec00003-001-s039><lie.belügen><de> Ich kann Sie nicht überzeugen, mir zu glauben, aber Sie belügen sich wenigstens nicht.
<G-vec00003-001-s039><lie.belügen><en> I do not convince you to believe me, but you at least do not lie to yourself.
<G-vec00003-001-s040><lie.belügen><de> "Vielleicht kann man ""Rashomon"" für sein etwas emotionales und moralisches Ende kritisieren, Kurosawa schafft es aber dennoch gekonnt ein Bild zu kreieren, in dem Hoffnung, dank einer Welt voller Menschen, die sich und andere belügen, nicht mehr greifbar zu sein scheint."
<G-vec00003-001-s040><lie.belügen><en> "Maybe you can criticize ""Rashomon"" for its somewhat emotional and morally correct ending, yet, Kurosawa manages to create a picture, in which hope seems to be out of reach, thanks to a world full of humans who lie to others and themselves."
<G-vec00003-001-s041><lie.belügen><de> Wir reißen Sie nicht ab, und wir belügen Ihr Gesicht nicht gerade, um Ihr Geld zu bekommen.
<G-vec00003-001-s041><lie.belügen><en> We won't rip you off, and we won't lie to your face just to get your money.
<G-vec00003-001-s042><lie.belügen><de> Ich weiß, es gibt immer noch manche, die glauben, dass ihre Regierungen sie nicht belügen würden.
<G-vec00003-001-s042><lie.belügen><en> I know that there are still some who want to believe that their governments would not lie to them.
<G-vec00003-001-s043><lie.belügen><de> Ein Meister namens Satan führt sie an und eines ihrer vorrangigsten Ziele ist, uns zu belügen (Johannes 8,44).
<G-vec00003-001-s043><lie.belügen><en> A master called Satan leads them, and one of their primary objectives is to lie to us (John 8:44).
<G-vec00003-001-s044><lie.belügen><de> Aber wir belügen Sie nicht und behaupten, dass unsere Produkte niemals kaputt gehen.
<G-vec00003-001-s044><lie.belügen><en> But we won’t lie that our products never break down.
<G-vec00003-001-s045><lie.belügen><de> Und dies ist auch genau das, was die khasarischen Juden und die samaritanischen Juden gemeinsam haben, nämlich ihren Glauben seit Anbeginn ihrer Religion, dass es ihnen von ihrem Gott erlaubt ist, Nichtjuden zu belügen und zu betrügen.
<G-vec00003-001-s045><lie.belügen><en> And that is also exactly what the Khazar Jews and the Samaritan Jews have in common, namely their believe since the very start of their religion that they are allowed by their god to lie and deceive non-Jews.
<G-vec00003-001-s046><lie.belügen><de> Wenn wir die Erde vom Krieg befreien wollen, müssen wir Formen des Zusammenlebens finden, in der Menschen sich nicht mehr belügen müssen, oder dem anderen keine Schuld mehr zuschieben für die eigenen Fehler.
<G-vec00003-001-s046><lie.belügen><en> If we want to free this world from war, we need to find forms of co-existence where people no longer lie to each other, and no longer blame others for their own mistakes.
<G-vec00003-001-s047><lie.belügen><de> Nachteile Lügen leichtgemacht: Dadurch, dass Sie Ihr Gegenüber zuerst einmal nicht persönlich zu Gesicht bekommen, kann man Sie natürlich sehr leicht belügen.
<G-vec00003-001-s047><lie.belügen><en> Lying made easy: as you don't personally set eyes upon your counterpart at first, you can of course lie to them very easily.
<G-vec00003-001-s048><lie.belügen><de> "Aus dieser Zwickmühle gibt es für die Moslems nur drei Auswege: entweder leugnen und sich selbst belügen, aussteigen oder ""für Allah und den Propheten"" sterben."
<G-vec00003-001-s048><lie.belügen><en> "This is a predicament that Moslems cannot escape from except by three possible ways: either they deny it and lie to themselves, or they give up their religion, or they die ""for Allah and the prophet""."
<G-vec00003-001-s049><lie.belügen><de> In dieser Artikelserie, die von Mike Baillie s Buch New Light on the Black Death inspiriert wurde, sind wir häufig der offensichtlichen Tatsache begegnet, dass diejenigen in Stellungen der Macht und Autorität in der Regel eher die Menschheit belügen als ausnahmsweise die Wahrheit zu sagen.
<G-vec00003-001-s049><lie.belügen><en> In this series of articles that were kicked off by Mike Baillie's book New Light on the Black Death, we have repeatedly come face to face with the obvious fact that those in positions of power and authority lie to the masses of humanity as a rule rather than an exception.
<G-vec00003-001-s050><lie.belügen><de> Du kannst solange lügen, wie du die Wahrheit kennst, d.h., um jemanden zu belügen, musst du ihn über eine gekannte Wahrheit belügen.
<G-vec00003-001-s050><lie.belügen><en> You can lie until you have the truth, i.e. in order to lie to someone you should lie to him about a certain truth.
<G-vec00003-001-s052><lie.belügen><de> Genauso belügen uns unsere Stimmungen fortwährend.
<G-vec00003-001-s052><lie.belügen><en> Our moods lie to us constantly.
<G-vec00003-001-s053><lie.belügen><de> Otto baut ein neues Wohnhaus von Steinen, er hat viel Ärger dabei, indem er das nöthige Bauholz nicht bekommen kann, und ihn die Leute belügen und hinhalten.
<G-vec00003-001-s053><lie.belügen><en> Otto is building a new house of stone. He has lots of annoyances with it, as he cannot get the necessary building timber, and people lie to him and cause delays.
<G-vec00003-001-s054><lie.belügen><de> Inhalt: Clark entschließt sich, dass er Lana nicht länger belügen kann.
<G-vec00003-001-s054><lie.belügen><en> Synopsis: Clark decides that he can no longer lie to Lana.
<G-vec00003-001-s055><lie.belügen><de> Die den Geist Gottes belügen wollen.
<G-vec00003-001-s055><lie.belügen><en> Those who try to lie to the Spirit of God.
<G-vec00003-001-s056><lie.belügen><de> Wenn Ihr übererfülltes Kind schlechte Noten bekommt oder wenn Ihr Teenager ein Pop-Quiz nicht besteht, belügen sie normalerweise ihre Eltern über ihr tatsächliches Ergebnis, weil ihre Eltern sie darüber beschimpfen können, oder, schlimmer noch, sie sind gebrochen, weil sie sie enttäuscht haben.
<G-vec00003-001-s056><lie.belügen><en> When your overachieving child gets poor grades or when your teen fails a pop quiz, they usually lie to their parents about their actual result because their parents might scold them about it, or worse, they might be broken-hearten because they disappointed them.
<G-vec00317-002-s048><lie.belügen><de> Versuchen sie einen Augenblick zu akzeptieren, dass sie nicht das sind, was sie glauben zu sein, dass sie sich überschätzen und dass sie sich deshalb selbst belügen.
<G-vec00317-002-s048><lie.belügen><en> Try for a moment to accept the idea that you are not what you think you are, that you overestimate yourself, therefore that you lie to yourself.
<G-vec00317-002-s049><lie.belügen><de> Als der Dorfleiter den diensthabenden Beamten des Büros zum Schutz der Staatssicherheit, Wei Jinkui, fragte, warum die Polizei ihn angelogen und ihn sogar dafür benutzt hätte, andere zu belügen und fragte, wie er das den anderen Dorfbewohnern erklären solle, sagte Wei: „Dies sind keine ‚Lügen’, sondern ‚Strategie’.
<G-vec00317-002-s049><lie.belügen><en> When the village director asked the domestic security division officer, Wei Jinkui, why the police had lied to him and used him to lie to others, and inquired of how he would be able to explain this to all of the villagers, Wei said, "This is not 'lying', it is 'strategy.'
<G-vec00317-002-s050><lie.belügen><de> Eine andere Stelle spricht von der Erlaubnis, einen „Ungläubigen” im Dienste Allahs zu belügen.
<G-vec00317-002-s050><lie.belügen><en> Another passage speaks of the permission to lie to an "infidel" in the service of Allah.
<G-vec00317-002-s051><lie.belügen><de> Eine Niederlage kann niemals als Sieg anerkannt werden, auch wenn Sie versuchen, sich selbst zu belügen.
<G-vec00317-002-s051><lie.belügen><en> Defeat can not be seen as a victory, even you want to lie to yourself in that sense.
<G-vec00317-002-s052><lie.belügen><de> Bis dahin, nun, werde ich sie belügen müssen.
<G-vec00317-002-s052><lie.belügen><en> Until then, well, I'm gonna have to lie to her
<G-vec00317-002-s054><lie.belügen><de> Belügen Sie sich nicht selbst.
<G-vec00317-002-s054><lie.belügen><en> “Never lie to yourself.
<G-vec00317-002-s055><lie.belügen><de> «Es ist gefährlich, sich selbst zu belügen, das heißt, sich von sich selber ein falsches Bild zu machen und so zu leben.
<G-vec00317-002-s055><lie.belügen><en> « It is dangerous to lie to oneself, that is to accept to live with a false image of oneself.
<G-vec00317-002-s056><lie.belügen><de> Ihr Wunsch, ihn zu schützen, sollte kein Grund dafür sein, daß Sie andere Menschen belügen, wenn diese ein Recht darauf haben, zu erfahren, wo er ist und was er tut.
<G-vec00317-002-s056><lie.belügen><en> Your desire to protect him should not cause you to lie to people when they have a right to know where he is and what he is doing.
<G-vec00317-002-s057><lie.belügen><de> Und er konnte die Welt nie belügen.
<G-vec00317-002-s057><lie.belügen><en> And he could never lie to the world.
<G-vec00317-002-s058><lie.belügen><de> Lügen leichtgemacht: Dadurch, dass Sie Ihr Gegenüber zuerst einmal nicht persönlich zu Gesicht bekommen, kann man Sie natürlich sehr leicht belügen.
<G-vec00317-002-s058><lie.belügen><en> Lying made easy: as you don't personally set eyes upon your counterpart at first, you can of course lie to them very easily.
<G-vec00317-002-s059><lie.belügen><de> Die Wahrheit der Sache ist, dass wir alle sind ausgezeichnete Lügner, zumindest dann, wenn wir uns selbst belügen.
<G-vec00317-002-s059><lie.belügen><en> The truth of the matter is that we all are excellent liars, at least when we lie to ourselves.
<G-vec00317-002-s060><lie.belügen><de> Natürlich sei es schlimm, Behörden zu belügen, aber umgekommen sei schließlich niemand.
<G-vec00317-002-s060><lie.belügen><en> “Of course it was bad to lie to the authorities, but no one died.”
<G-vec00317-002-s061><lie.belügen><de> Drittens, unsere Untersuchung der Bestrebungen, die Untersuchung zu behindern und die Ermittler zu belügen, war von entscheidender Bedeutung.
<G-vec00317-002-s061><lie.belügen><en> "Third, our investigation of efforts to obstruct the investigation and lie to investigators was of critical importance.
<G-vec00317-002-s062><lie.belügen><de> Sie belügen Freunde und Familie, um zu vertuschen wie viel sie spielen.
<G-vec00317-002-s062><lie.belügen><en> They lie to loved ones in order to conceal how much they gamble.
<G-vec00317-002-s063><lie.belügen><de> Licht aus... man kann seine Verwandten beim Weihnachtsessen belügen und ihnen erzählen, dass zu Hause alles in Butter ist.
<G-vec00317-002-s063><lie.belügen><en> Lights out... you can lie to your relatives at Christmas dinner and tell them everything on the home front is just peachy.
<G-vec00317-002-s064><lie.belügen><de> Bobby sagt, er wollte Dean nicht belügen, aber er wäre einfach froh gewesen, dass Dean das Jägerleben hinter sich lassen konnte.
<G-vec00317-002-s064><lie.belügen><en> He also admits he didn't want to lie to him, but Dean was out of hunting.
<G-vec00317-002-s065><lie.belügen><de> Dieses soll ihn glauben machen, dass er bis zum nächsten Versöhnungstag Heiden straflos belügen darf.
<G-vec00317-002-s065><lie.belügen><en> To the mind of the Jew, this lets them lie to gentiles with impunity until the next Day of Atonement.
<G-vec00317-002-s066><lie.belügen><de> Sie belügen nicht nur alle, sondern sammeln auch Nutzergelder und verschwinden dann aus dem Internet.
<G-vec00317-002-s066><lie.belügen><en> They not only lie to everyone, but also collect users’ money and disappear from the Internet then.
