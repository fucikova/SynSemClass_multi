<G-vec00460-002-s040><omit.auslassen><de> Nach bestem Wissen von DoubleLine entsprechen die Angaben in diesem Abschnitt der Website den Tatsachen und es wird nichts ausgelassen, was die Bedeutung dieser Angaben beeinträchtigen könnte.
<G-vec00460-002-s040><omit.auslassen><en> The information contained on this section of the Website is to the best of the knowledge of DoubleLine in accordance with the facts and does not omit anything likely to affect the import of such information.
<G-vec00560-002-s038><miss.auslassen><de> Ein weiteres Highlight, dass wir in der Umgebung nicht auslassen wollen, ist der Bernia Grat.
<G-vec00560-002-s038><miss.auslassen><en> Another highlight that we do not want to miss in the area is the Bernia Grat.
<G-vec00560-002-s039><miss.auslassen><de> Wenn Sie Ihren Urlaub in der UNESCO Welterberegion Hallstatt Dachstein Salzkammergut planen, sollten Sie einen Besuch dieses Naturwunders nicht auslassen.
<G-vec00560-002-s039><miss.auslassen><en> When planning your vacation to the UNESCO World Heritage region of Hallstatt Dachstein Salzkammergut, you should not miss a visit to this natural wonder.
<G-vec00560-002-s040><miss.auslassen><de> Los Roques ist zweifelsohne ein Reiseziel Venezuelas, das man nicht auslassen darf.
<G-vec00560-002-s040><miss.auslassen><en> Los Roques is without a doubt one of the destinations in Venezuela that you cannot miss experiencing.
<G-vec00560-002-s041><miss.auslassen><de> Viel Auswahl hat man in der südlichen Karibik nicht, daher sollte man diesen nicht auslassen.
<G-vec00560-002-s041><miss.auslassen><en> Plenty of choice one has not in the southern Caribbean, so you should not miss this.
<G-vec00560-002-s042><miss.auslassen><de> Für Kinder gibt es eine Art Streichelzoo, und im Sommer sollten Sie eine erfrischende Dusche unter einem der Wasserfälle nicht auslassen.
<G-vec00560-002-s042><miss.auslassen><en> There is a small petting zoo for children, and in the summer you should not miss a refreshing shower under one of the many waterfalls.
<G-vec00560-002-s043><miss.auslassen><de> Dies liegt daran, dass jedem Aufstieg ein Abstieg voraus geht und sie den Abstieg nicht auslassen sollten, sondern durch eben diesen aufsteigen sollten, mit einer Anstrengung, indem Sie die Größe des Ziels erheben und durch die Gewissheit, dass das Licht des Studiums sie erheben wird.
<G-vec00560-002-s043><miss.auslassen><en> It’s because every ascent is preceded by a descent, and you shouldn’t miss the descent, but ascend through it, with an effort, elevating the greatness of the goal and the certainty that the Light of studying will elevate you.
<G-vec00560-002-s044><miss.auslassen><de> Und da die Menschen jetzt völlig die benötigten Gegenmittel übergehen, jetzt bei verhältnismäßig unwichtigen Problemen, werden sie in einem viel größeren Umfang die erforderlichen Mittel auslassen, wenn ein richtiges Handeln viel mehr notwendig ist.
<G-vec00560-002-s044><miss.auslassen><en> And as men now completely miss the required remedy, now with relative unimportant problems, they will miss even to a much greater extent the necessary action, when right action is much more required.
<G-vec00560-002-s045><miss.auslassen><de> Und dann gibt es ja noch den Universitätsplatz mit der Kollegienkirche, die man nicht auslassen sollte.
<G-vec00560-002-s045><miss.auslassen><en> And there is also the Universitätsplatz (university square) with its church you should not miss.
<G-vec00560-002-s046><miss.auslassen><de> Es gibt viel Sehenswertes, das Sie in den wichtigsten Städten keinesfalls auslassen sollten.
<G-vec00560-002-s046><miss.auslassen><en> There are numerous cultural sites in all the major cities which no visitor should miss.
<G-vec00560-002-s047><miss.auslassen><de> Veranstaltungen in Deutschland sind sowohl bei Deutschen, als auch Touristen, ein sehr interessanter und beliebter Teil, welche die Chance nicht auslassen während dieser Zeit die Stadt zu erkunden.
<G-vec00560-002-s047><miss.auslassen><en> In Germany, the events are a very interesting and sought-after part by both Germans and tourists whom never miss the opportunity to visit some cities during an event.
<G-vec00560-002-s048><miss.auslassen><de> Lasst eure Augen mit Liebe schauen und nichts auslassen.
<G-vec00560-002-s048><miss.auslassen><en> Let your eyes look with love and miss nothing.
<G-vec00560-002-s049><miss.auslassen><de> Ja, Sie können Teller überspringen, aber jedes Chefs Table Menü hat den gleichen Preis, unabhängig davon, ob Sie Gänge auslassen.
<G-vec00560-002-s049><miss.auslassen><en> Yes, you can skip plates, but every tasting menu has the same price whether or not you choose to miss courses.
<G-vec00560-002-s050><miss.auslassen><de> Solltet ihr einen Tag in diesem Zeitraum auslassen, so hat das keinen Einfluss auf die übrigen Geschenke.
<G-vec00560-002-s050><miss.auslassen><en> Even if you miss a day during this period, it won't have any effect on the remaining presents.
<G-vec00560-002-s051><miss.auslassen><de> Wenn Sie schon dort sind, sollten Sie bestimmt auch den neu eröffneten Garten nicht auslassen, der im romantischen Barockstil angelegt ist.
<G-vec00560-002-s051><miss.auslassen><en> While you’re there, don’t miss a newly opened garden that is planted in a romantic baroque style.
<G-vec00560-002-s052><miss.auslassen><de> In Hotton können Sie die herrlichen Höhlen aus 1001 Nacht besuchen, eine Sehenswürdigkeit, die Sie nicht auslassen sollten.
<G-vec00560-002-s052><miss.auslassen><en> In Hotton you should visit the magnificent caves from 1001 night, a sight that you cannot miss.
<G-vec00560-002-s053><miss.auslassen><de> Wenn Sie bereits am Strand stehen und sich im Stand-Up Paddeln versuchen möchten, sollten Sie auch das alljährlich im Juni stattfindende Beach Master Volleyball-Turnier nicht auslassen.
<G-vec00560-002-s053><miss.auslassen><en> If you’re already down at the beach trying your hand at paddle surfing, make sure not to miss the Beach Masters volleyball tournament, held annually in June.
<G-vec00560-002-s054><miss.auslassen><de> Zu Beginn des Trainings für die heurige Saison brach sich der Salzburger im August den Außenknöchel, sodass er den Weltcup-Auftakt in Sölden auslassen musste.
<G-vec00560-002-s054><miss.auslassen><en> At the start of his training in August for the current season Hirscher broke his ankle, which meant he had to miss the World Cup opener in Sölden.
<G-vec00560-002-s055><skip.auslassen><de> Zeitnah entschied unser Fahrtleiter Torben, einige Stationen auszulassen, um zum nächsten Meeresbodenobservatorium (Mooring) zu gelangen.
<G-vec00560-002-s055><skip.auslassen><en> Soon, our cruise leader Torben decided that we skip some stations to reach the next mooring, which is called OSL2D, as soon as possible and to recover it during fair weather conditions.
<G-vec00560-002-s056><skip.auslassen><de> Wenn du jedoch mit Kindern Keramik glasierst, wird es dir vielleicht leichter fallen, diesen Schritt auszulassen und die glasierten Objekte der Kinder vor dem Brennen mit der Heißklebepistole auf einen Keramikteller zu kleben, welcher tropfende Glasur auffängt.
<G-vec00560-002-s056><skip.auslassen><en> If you are glazing pottery with children, you may find it easier to skip this step and hot glue the children's glazed objects to a clay disc immediately before firing, in order to catch dripping glaze.
<G-vec00560-002-s057><skip.auslassen><de> Ich habe es mir zur Angewohnheit gemacht, eine Zeile auszulassen, wenn ich schreibe.
<G-vec00560-002-s057><skip.auslassen><en> As a permanent habit I skip a line when writing.
<G-vec00560-002-s058><skip.auslassen><de> Sobald Sie eine Wette über den Tisch gelegt haben, können Sie beschließen, das gegebene Geschäft auszulassen (bevor Ihre erste Karte befasst wird), auf den Knopf "Pass" klickend oder mit der Wette fortzufahren, "Geschäft" drückend.
<G-vec00560-002-s058><skip.auslassen><en> Once you have placed a bet on the table, you may choose to skip the given deal (before your first card is dealt) by clicking on the "Pass" button or to proceed with the bet by pressing "Deal".
<G-vec00560-002-s059><skip.auslassen><de> Wenn alles, was du tun musst, ist, dein Essen zu schnappen und aus dem Haus zu gehen, wirst du weniger versucht sein, das Frühstück auszulassen, weil du es eilig hast, und du kannst ungesundes Fast Food zum Mittagessen vermeiden.
<G-vec00560-002-s059><skip.auslassen><en> When all you have to do is grab your meal and go, you’re less likely to skip breakfast because you’re in a rush and you’ll avoid grabbing unhealthy fast food for lunch.
<G-vec00560-002-s060><skip.auslassen><de> Wenn Sie sich jedoch im Erholungsmodus befinden und nicht gut geschlafen haben oder ein hartes Training hinter sich haben, ist es in Ordnung, es auszulassen.
<G-vec00560-002-s060><skip.auslassen><en> However, if you are in recovery mode and have not slept well or had a hard workout it is fine to skip it.
<G-vec00560-002-s061><skip.auslassen><de> Im Laden gekaufte Zunge ist normalerweise sauber genug, um diesen Schritt auszulassen, aber er kann den Geschmack der Zunge auffrischen.
<G-vec00560-002-s061><skip.auslassen><en> Store-bought tongue is usually clean enough to skip this step, but it can freshen up the tongue's flavor.
<G-vec00560-002-s062><skip.auslassen><de> Ich habe es mir zur Regel gemacht, keinen der drei Durchläufe zum Bestimmen der Melodietonart auszulassen: In manchen Fällen musste ich bei einem zweiten oder dritten Anhören meine Annahme, dass sich ein Stück "sicher nur in dieser Tonart" arrangieren lässt, über Bord werfen.
<G-vec00560-002-s062><skip.auslassen><en> I have made a rule for myself that I never skip any of the three passes where I try to place the melody into the three main keys: On some occasions, I had to throw away my assumption that a piece "could only be arranged in the key of..."
<G-vec00560-002-s063><skip.auslassen><de> Es ist nicht notwendig, eine Mahlzeit auszulassen; will man das trotzdem tun, verzichtet man am besten auf das Abendessen.
<G-vec00560-002-s063><skip.auslassen><en> 4. Have breakfast, have lunch. It's not necessary to skip a meal, but if you want to, skip dinner.
<G-vec00560-002-s064><skip.auslassen><de> Es ist relativ sicher, die farblosen Pillen auszulassen und direkt mit einer neuen Packung weiterzumachen, wenn du die Pille nimmst.
<G-vec00560-002-s064><skip.auslassen><en> If you’re on the pill, it’s relatively safe to skip the blanks and go straight into another packet.
<G-vec00560-002-s065><skip.auslassen><de> Jedes einzelne dieser Elemente ist wichtig, und es kommt leicht vor einen Platz oder ein Gänsefüßchen auszulassen (und vergessen Sie nicht den Grundstrich vor dem leeren Platz).
<G-vec00560-002-s065><skip.auslassen><en> Each one of those elements is important and it’s easy to skip a space or a quotation (and don’t forget the underscore before blank).
