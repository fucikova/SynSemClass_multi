<G-vec00547-001-s261><trouble.bereiten><de> Dies Schwierigkeit jedoch ist weitgehend die, wie im Falle Davids, dass der Drang und die Hingabe in Verbindung mit einer großen Idee für Gott das stille Warten auf Gott und das Fragen nach dem, was er bezüglich der Mittel und Methoden, die anzuwenden sind, im Sinn hat, einfach überrennt.
<G-vec00547-001-s261><trouble.bereiten><en> The trouble so largely is that, as in David's case, the drive and abandon associated with a great idea for God just ride rough-shod over quiet waiting upon God and enquiry of Him as to His mind concerning the means and methods to be employed.
<G-vec00547-001-s262><trouble.bereiten><de> Und wenn der Herr wirklich jemandem die Augen öffnet und ihm geistliche Offenbarung schenkt, geraten sie in Schwierigkeiten - und die Schwierigkeit wird aus der religiösen Welt kommen.
<G-vec00547-001-s262><trouble.bereiten><en> And if the Lord really does open someone's eyes and give them spiritual revelation, they are in for trouble - and their trouble will come from the religious world.
<G-vec00547-001-s263><trouble.bereiten><de> Die Schwierigkeit war, dass in dem Prozess der zionistische Nationalismus nie wirklich die alte jüdische religiöse Identität überwand.
<G-vec00547-001-s263><trouble.bereiten><en> The trouble was that in the process, Zionist nationalism never really overcame the old Jewish religious identity.
<G-vec00547-001-s264><trouble.bereiten><de> Beschreibung Rii i8 Classic Mini Drahtloses Tastatur-Touchpad wird Sie sicher von der Schwierigkeit des begrenzten Betriebes befreien, der durch verdrahtete Maus verursacht wird.
<G-vec00547-001-s264><trouble.bereiten><en> Description Rii i8 Classic Mini Wireless Keyboard Touchpad will surely rid you of the trouble of limited operation caused by wired mouse.
<G-vec00547-001-s265><trouble.bereiten><de> Zu den Themen, dass viele Leute die Verwaltung aktiv Weg von Pfründen, konsequente Arbeit-out-Schemata und entsprechende Ergänzungen Erfahrung ist die Schwierigkeit, die Ergänzungen zu verabreichen.
<G-vec00547-001-s265><trouble.bereiten><en> Among the troubles that lots of people handling hectic way of lives, extensive workout regimens and proper supplementation encounter is the trouble to carry out the supplements.
<G-vec00547-001-s266><trouble.bereiten><de> Bevor wir mit der Diskussion beginnen, warum das Kreuz stets ein Verursacher von Schwierigkeit und Ärgernissen gewesen ist, müssen wir klarstellen, dass damit nichts von der Heldenhaftigkeit und Ästhetik des Kreuzes weggenommen werden soll.
<G-vec00547-001-s266><trouble.bereiten><en> Before we begin to discuss why the Cross has always been such a maker of trouble and cause of offence, we need to make it plain that no exception is taken to the heroics of the Cross or its aesthetics.
<G-vec00547-001-s267><trouble.bereiten><de> Die einzige Schwierigkeit die ich damit habe ist ob es real war oder nur ein Traum.
<G-vec00547-001-s267><trouble.bereiten><en> The only trouble that I have with it was it real or just a dream.
<G-vec00547-001-s268><trouble.bereiten><de> Unsere größte Schwierigkeit ist es, unsere Schüler zu lehren, sich nicht von der äußeren Erscheinung täuschen zu lassen.
<G-vec00547-001-s268><trouble.bereiten><en> Our greatest trouble is to teach pupils not to be befooled by appearances.
<G-vec00547-001-s269><trouble.bereiten><de> Aber seht, die Schwierigkeit ist, sie haben nicht das geeignete Spektrometer, so etwas haben sie nicht.
<G-vec00547-001-s269><trouble.bereiten><en> But you see the trouble is that they don't have that kind of spectrometer so far.
<G-vec00547-001-s270><trouble.bereiten><de> Wenn Sie Schwierigkeit haben, die das richtige Produkt findet, wir empfehlen, daß IhnenVerbindung Pheromones TM bedenken.
<G-vec00547-001-s270><trouble.bereiten><en> If you are having trouble finding the right product, we recommend you consider Nexus PheromonesTM .
<G-vec00547-001-s271><trouble.bereiten><de> Rii i8 Classic Mini Drahtloses Tastatur-Touchpad wird Sie sicher von der Schwierigkeit des begrenzten Betriebes befreien, der durch verdrahtete Maus verursacht wird.
<G-vec00547-001-s271><trouble.bereiten><en> Rii i8 Classic Mini Wireless Keyboard Touchpad will surely rid you of the trouble of limited operation caused by wired mouse.
<G-vec00547-001-s272><trouble.bereiten><de> "Hier haben wir es also: ""ich, verkrüppelt und halb tot,"" und ""die Schwierigkeit, die auf uns zu kommt"" und "" Meine gegenwärtige Krankheit""."
<G-vec00547-001-s272><trouble.bereiten><en> "So here we have it: ""I, crippled down and half dead"" and ""the trouble that comes upon us"" and ""My present illness""."
<G-vec00547-001-s273><trouble.bereiten><de> Es kommt nicht darauf an, in welcher Art von Schwierigkeit Sie stecken.
<G-vec00547-001-s273><trouble.bereiten><en> It doesn't matter what kind of trouble youre in.
<G-vec00547-001-s274><trouble.bereiten><de> Beachten Sie, dass uneheliche bedeutet erwirbt Steroide könnte auf jeden Fall erhalten Sie rechts in die Schwierigkeit.
<G-vec00547-001-s274><trouble.bereiten><en> Remember that bogus means to buy steroids can certainly get you right into trouble.
<G-vec00547-001-s275><trouble.bereiten><de> Die Schwierigkeit mit der Wahrheit ist, dass man mit ihr keine Kompromisse schließen kann.
<G-vec00547-001-s275><trouble.bereiten><en> The trouble with the Truth is that it cannot compromise.
<G-vec00547-001-s276><trouble.bereiten><de> Es ist eine keine Schwierigkeit, keine Hektik 100% Garantie.
<G-vec00547-001-s276><trouble.bereiten><en> It is a no fuss, no trouble 100% guarantee.
<G-vec00547-001-s277><trouble.bereiten><de> Das sind alles kleine Dinge, die euch den notwendigen Halt geben können, um in Momenten der Schwierigkeit nicht aufzugeben, sondern einen Hoffnungsspalt zu öffnen; einen Spalt, der euch helfen wird, euren Einfallsreichtum einzubringen als auch neue Wege und Räume zu finden, um den Problemen im Geist der Solidarität zu begegnen.
<G-vec00547-001-s277><trouble.bereiten><en> All of these are little things, but they can give you the support you need not to give up in times of trouble but to move forward with hope, to find new ways and outlets for expressing your creativity, and to face problems together in a spirit of solidarity.
<G-vec00547-001-s278><trouble.bereiten><de> Sie kennen die Umstände dieser Familien und ihre Denkweisen sehr genau und bei dem geringsten Anzeichen einer Schwierigkeit berichtet das Nachbarschaftskomitee direkt an die Partei.
<G-vec00547-001-s278><trouble.bereiten><en> "They know these families' circumstances and their thinking quite well. At the slightest sign of any ""trouble,"" the neighbourhood committee directly reports it to the Party."
<G-vec00547-001-s279><trouble.bereiten><de> Und so ist es wie es ist, im Laufe unserer Leben; die Schwierigkeit, die auf uns zu kommt, ist immer die, von der wir fühlen, daß sie die schwerste ist, die irgendwie passieren konnte – es ist immer die eine Sache, von der wir fühlen, daß wir sie nicht tragen können.
<G-vec00547-001-s279><trouble.bereiten><en> And this is how it is, in the course of our lives; the trouble that comes upon us is always just the one we feel to be the hardest that could possibly happen – it is always the one thing we feel we cannot possibly bear.
<G-vec00213-002-s064><finalize.bereiten><de> Bereiten Sie Ihren Messebesuch detailliert vor und profitieren Sie von den Features der neuen App - Ihrem mobilen Planer vor, während und nach der Messe.
<G-vec00213-002-s064><finalize.bereiten><en> Finalize the details for your visit to INHORGENTA MUNICH and benefit from the features of the new app – your mobile planner before, during, and after the show.
<G-vec00243-002-s327><trouble.bereiten><de> In den Bereichen, die der Menschheit die größten Schwierigkeiten bereiten, findet man die meisten Abänderungen der Wirklichkeit, die meisten verwirrten und einander widersprechenden Ideen und natürlich die größte Zahl missverstandener Wörter.
<G-vec00243-002-s327><trouble.bereiten><en> In those areas which give man the most trouble, you will find the most alteration of fact, the most confused and conflicting ideas and of course the greatest number of misunderstood words.
<G-vec00243-002-s328><trouble.bereiten><de> Er fleht Jesus an, ihm keine Schwierigkeiten zu bereiten und seine dämonische Existenz nicht noch erbärmlicher zu machen.
<G-vec00243-002-s328><trouble.bereiten><en> He begs Jesus not to trouble him, not to make his demonic existence more miserable.
<G-vec00243-002-s329><trouble.bereiten><de> Aber er kann uns Schwierigkeiten bereiten, wenn er das will.
<G-vec00243-002-s329><trouble.bereiten><en> But he can trouble us, if he chooses.
<G-vec00243-002-s330><trouble.bereiten><de> Man sollte erwarten, dass „höhere Wesen“, die höheren Ebenen als derjenigen eines Lokaluniversums entstammen, einem Schöpfersohn wohl kaum je Schwierigkeiten bereiten würden, und dem ist auch so.
<G-vec00243-002-s330><trouble.bereiten><en> It might be inferred that “higher beings,” those of origin on levels above a local universe, would be unlikely to trouble a Creator Son, and this is true.
<G-vec00243-002-s331><trouble.bereiten><de> Das ist für niemanden gut und wenn diese Situation weiter anhält, könnten die alten Mächte dies als Ausrede für „nicht dem Lehrer, sondern Menschen folgen“ nehmen, um Schwierigkeiten zu bereiten oder dem Betreuer sogar zu schaden.
<G-vec00243-002-s331><trouble.bereiten><en> This is not good for anyone, and if this situation continues, the old forces could use the excuse of "not following Teacher but following people" to make trouble, or even damage the assistant.
<G-vec00243-002-s332><trouble.bereiten><de> In diesem Zeitraum kannst Du sehen, ob sie Schwierigkeiten bereiten.
<G-vec00243-002-s332><trouble.bereiten><en> In that space of time, you can see if they’re going to be trouble.
<G-vec00243-002-s333><trouble.bereiten><de> Ich habe mehr als oft genug erklärt, daß es keinen Deutschen und vor allem keinen Nationalsozialisten gibt, der auch nur in Gedanken die Absicht besäße, dem englischen Weltreich Schwierigkeiten bereiten zu wollen.
<G-vec00243-002-s333><trouble.bereiten><en> I have stated more than enough that there is no German, and especially no National Socialist, who even in his thoughts had the intention of trying to cause trouble for the English Empire.
<G-vec00243-002-s334><trouble.bereiten><de> Der Tathāgata, Aggivessana, hat die Triebe überwunden, die beflecken, neues Werden bringen, Schwierigkeiten bereiten, in Leiden heranreifen und zu künftiger Geburt, Altern und Tod führen; er hat sie an der Wurzel abgeschnitten, hat sie einem Palmenstrunk gleich gemacht, sie beseitigt, so daß sie künftigem Entstehen nicht mehr unterworfen sind.
<G-vec00243-002-s334><trouble.bereiten><en> In the Tathāgata, Aggivessana, the effluents that defile, that lead to renewed becoming, that give trouble, that ripen in stress, and lead to future birth, aging, & death have been abandoned, their root destroyed, made like a palmyra stump, deprived of the conditions of development, not destined for future arising.
<G-vec00243-002-s335><trouble.bereiten><de> Sie kommt, weil du das Wort in dein Herz gepflanzt hast, und er weiß, dass du ihm mehr Schwierigkeiten bereiten wirst, als er verkraften kann, wenn er es dir nicht wieder wegnimmt.
<G-vec00243-002-s335><trouble.bereiten><en> It comes because you've put the Word in your heart, and he knows that if he doesn't get it out, you're going to cause him more trouble than he can handle.
<G-vec00243-002-s336><trouble.bereiten><de> ACHTUNG: Falls eine Schrift irgendwo im Internet meinen Namen trägt, aber NICHT in dieser Liste aufgeführt wird, so stammt sie höchstwahrscheinlich NICHT von mir sondern von jemandem, der sich fälschlicherweise als mich ausgibt, um mir Schwierigkeiten zu bereiten.
<G-vec00243-002-s336><trouble.bereiten><en> CAVEAT: If an item posted somewhere on the internet has my name on it but is NOT included in this list, then it was most likely NOT authored by me but by some impostor trying to cause trouble.
<G-vec00243-002-s337><trouble.bereiten><de> Nebenbei, Falun Gong-Praktizierende sind eine Gruppe freundlicher Menschen, die nicht darauf aus ist, Schwierigkeiten zu bereiten.
<G-vec00243-002-s337><trouble.bereiten><en> Besides, Falun Gong practitioners are a group of nice people who are not out to cause trouble.
<G-vec00243-002-s338><trouble.bereiten><de> Als Teil dieses feinstofflichen Kampfes zwingen höhere negative Wesenheiten wie Mantriks (feinstoffliche Zauberer) die spirituell schwächeren feinstofflichen Körper verstorbener Vorfahren, von ihrer Geben-Nehmen-Rechnung mit ihren “guten” Nachkommen Gebrauch zu machen, um ihnen Schwierigkeiten zu bereiten.
<G-vec00243-002-s338><trouble.bereiten><en> As a part of this subtle-battle, negative energies such as subtle-sorcerers (māntriks) force the spiritually weaker ancestors’ subtle-bodies to make use of their give-and-take accounts with their ‘good’ descendants to trouble them.
<G-vec00290-002-s046><brace.bereiten><de> So bereiten Sie sich auf eine Tonne Aufregung und awesome Glücksspiel.
<G-vec00290-002-s046><brace.bereiten><en> So brace yourself for a ton of excitement and great gambling.
<G-vec00290-002-s047><brace.bereiten><de> Bereiten Sie sich auf ein wahrlich aufregendes Abenteuer bei der Chiang Mai Night Safari vor.
<G-vec00290-002-s047><brace.bereiten><en> Brace yourself for a truly exciting adventure at the Chiang Mai Night Safari.
<G-vec00290-002-s048><brace.bereiten><de> So bereiten Sie sich auf eine Menge Spaß und tolle Spiele.
<G-vec00290-002-s048><brace.bereiten><en> So brace yourself for a ton of excitement and awesome gambling.
<G-vec00290-002-s049><brace.bereiten><de> Fazit: Tragen Sie, was Ihnen steht, urteilen Sie nicht über andere, die das gleiche tun, ignorieren Sie Hater und bereiten Sie sich auf das Ende der Sport-BHs vor.
<G-vec00290-002-s049><brace.bereiten><en> Bottom line: Wear what suits you, don’t judge others who do the same, ignore the haters, and brace yourself for the eventual takedown on sports bras.
<G-vec00290-002-s095><prepare.bereiten><de> Ich bereite auch Gänseleber und schwarze Trüffelpastete mit Hirschschulter zu – ein Rezept, das vom Finale des Wettbewerbs Best Craftsman of France inspiriert wurde.
<G-vec00290-002-s095><prepare.bereiten><en> I also prepare a foie gras and black truffle pie with shoulder of venison, a recipe inspired by the final of the Best Craftsman of France competition.
<G-vec00290-002-s096><prepare.bereiten><de> 22 Zugleich bereite mir eine Herberge; denn ich hoffe, dass ich durch eure Gebete euch geschenkt werde.
<G-vec00290-002-s096><prepare.bereiten><en> 22 But withal prepare me also a lodging: for I trust that through your prayers I shall be given to you.
<G-vec00290-002-s097><prepare.bereiten><de> Schritt 1: Bereite die Figur mit Grey Primer...
<G-vec00290-002-s097><prepare.bereiten><en> Step 1: Prepare the miniature with Grey Primer.
<G-vec00290-002-s098><prepare.bereiten><de> Ohne Ankündigung bereite ich mir an einem öffentlichen Ort eine Schale mit frischen Erdbeeren.
<G-vec00290-002-s098><prepare.bereiten><en> Without prior notice I prepare a bowl with fresh strawberries in a public space.
<G-vec00290-002-s099><prepare.bereiten><de> Entdecke die Geheimnisse der italienischen Küche und bereite ein authentisches Menü inklusive Antipasti und Dessert zu.
<G-vec00290-002-s099><prepare.bereiten><en> Discover how to create true Italian cuisine as you prepare an authentic Italian meal complete with the antipasto to the dessert.
<G-vec00290-002-s100><prepare.bereiten><de> Bestelle zusätzlich zur Kalbshaxe 2 kg klein gehackte Kalbsknochen und bereite einen Kalbsfond zu.
<G-vec00290-002-s100><prepare.bereiten><en> In addition to the veal shank, order 2 kg of finely chopped veal bones and prepare a veal stock.
<G-vec00290-002-s101><prepare.bereiten><de> Bereite die Pudding Mischung zu.
<G-vec00290-002-s101><prepare.bereiten><en> Prepare the pudding mix.
<G-vec00290-002-s102><prepare.bereiten><de> Bereite nun den Schokoladenteig zu und beginne mit dem Schmelzen der Schokolade.
<G-vec00290-002-s102><prepare.bereiten><en> Then prepare your chocolate dough and start with melting the chocolate.
<G-vec00290-002-s103><prepare.bereiten><de> Nach einigen Tests fand ich, dass ich bevorzuge es mehr so bereite ich vor Drücken der Taste auf dem Couch nach unten und dann Kaffee.
<G-vec00290-002-s103><prepare.bereiten><en> After some testing I found that I prefer it longer so I prepare before pushing the button on the coffee down and then coffee.
<G-vec00290-002-s104><prepare.bereiten><de> Bereite die Austern auf dem Kugelgrill zu.
<G-vec00290-002-s104><prepare.bereiten><en> Prepare your oysters on a charcoal barbecue
<G-vec00290-002-s105><prepare.bereiten><de> Aber lass mich einen Vergleich anstellen: angenommen, ich bereite jemandem einen tollen Cocktail mit wirklich feinen Zutaten zu und ich mische einen Tropfen Blut rein – der/diejenige wird diesen Tropfen womöglich gar nicht wahrnehmen, aber er ist da und die Eigenschaften von diesem Tropfen Blut werden den Drink durchziehen, obwohl er immer noch gut schmeckt.
<G-vec00290-002-s105><prepare.bereiten><en> But I see it like this: if I prepare someone a cocktail with some really fine ingredients that tastes really well and I add one drop of blood into it – the person might not notice it but the blood will be there and the characteristics of the blood will permeate the entire drink, you know, and it still might taste very well.
<G-vec00290-002-s106><prepare.bereiten><de> 3Und wenn ich hingehe und euch eine Stätte bereite, so komme ich wieder und werde euch zu mir nehmen, auf daß, wo ich bin, auch ihr seiet.
<G-vec00290-002-s106><prepare.bereiten><en> 3And if I shall go, and prepare a place for you, I will come again, and will take you to myself; that where I am, you also may be.
<G-vec00290-002-s107><prepare.bereiten><de> Bereite dich auf diesen Fall vor, damit du nicht das zweite Mal blind in dein Unglück läufst.
<G-vec00290-002-s107><prepare.bereiten><en> Prepare yourself for this beforehand to avoid being blindsided by heartbreak a second time.
<G-vec00290-002-s108><prepare.bereiten><de> Das Frühstück bereite ich nach Ihren Wünsche zu.
<G-vec00290-002-s108><prepare.bereiten><en> The breakfast, I prepare to according to your wishes.
<G-vec00290-002-s109><prepare.bereiten><de> Oder bereite es in der Mikrowelle zu.
<G-vec00290-002-s109><prepare.bereiten><en> Or prepare it in the microwave.
<G-vec00290-002-s110><prepare.bereiten><de> Maleachi 3, Vers 1 Siehe, ich sende meinen Boten, dass er den Weg bereite vor mir her.
<G-vec00290-002-s110><prepare.bereiten><en> Malachi 3, verse 1 “I will send my messenger, who will prepare the way before me.
<G-vec00290-002-s111><prepare.bereiten><de> • Wenn es mal schnell gehen soll, bereite ich die Wraps mit Mozzarella und Tomaten zu - eine leichte und leckere Mahlzeit.
<G-vec00290-002-s111><prepare.bereiten><en> • When I don’t have a lot of time, I prepare the wraps using mozzarella and tomatoes – a light and delicious meal.
<G-vec00290-002-s112><prepare.bereiten><de> Bediene deine Kunden, bereite die gefragten Gerichte zu und sorge dafür dass du pünktlich bist.
<G-vec00290-002-s112><prepare.bereiten><en> About Serve your customers, prepare their meals and always be on time. Share this
<G-vec00290-002-s113><prepare.bereiten><de> Bereite in der Küche köstliche Hotdogs zu und lass sie dir draußen unter dem ausklappbaren Vordach schmecken.
<G-vec00290-002-s113><prepare.bereiten><en> Prepare delicious hot dogs in the kitchen and enjoy them outside under the folding canopy of this cool toy for kids.
<G-vec00329-002-s006><predispose.bereiten><de> In einigen Fällen bereitet ein anormales Wachstum möglicherweise eine Einzelperson zur Entwicklung von analen Fisteln vor.
<G-vec00329-002-s006><predispose.bereiten><en> In some cases, an abnormal growth may predispose an individual to the development of anal fistulas.
