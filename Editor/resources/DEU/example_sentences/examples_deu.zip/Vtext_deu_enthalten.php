<G-vec00206-001-s192><comprise.enthalten><de> Frauen enthalten jetzt mehr als 50 Prozent von der US-Belegschaft.
<G-vec00206-001-s192><comprise.enthalten><en> Women now comprise more than 50 percent of the U.S. work force.
<G-vec00206-001-s193><comprise.enthalten><de> Dieser beeindruckende High-Technology Hafen wird etwa 858 Liegeplätze, zwei Anleger für Kreuzfahrtschiffe mit einer Länge bis 175 Meter, Freizeitangebote, Restaurants und Shoppingbereiche enthalten, sowie ein 5-Sterne Hotel und Tiefgaragen für 450 Autos.
<G-vec00206-001-s193><comprise.enthalten><en> This amazing, high tech port will comprise some 858 berths, two berths for cruise ships up to 175 meters in length, leisure, restaurant and shopping areas, a five-star hotel and underground parking for 450 cars.
<G-vec00206-001-s194><comprise.enthalten><de> Die Finanzbeteiligungen enthalten im Wesentlichen die Beteiligung an der Balyo SA in Höhe von 5,2Mio.
<G-vec00206-001-s194><comprise.enthalten><en> The financial investments essentially comprise the equity investment in Balyo SA of €5.2million .
<G-vec00206-001-s195><comprise.enthalten><de> Diese Kapitel enthalten die Essenz der Rachel Lehre - was gibt sie an Kirchen und Konferenzen auf der ganzen Welt.
<G-vec00206-001-s195><comprise.enthalten><en> These chapters comprise the essence of Rachel’s teaching – which she gives to churches and conferences around the world.
<G-vec00206-001-s196><comprise.enthalten><de> Die Quickinfo zu Objekten kann bei Bedarf auch die Materialnummer enthalten.
<G-vec00206-001-s196><comprise.enthalten><en> If needed, the tooltip of objects can also comprise the material number.
<G-vec00206-001-s197><comprise.enthalten><de> Im Zuge meist nur selektiven Ausdruckens von Adreßträgern können diese Speicherungen von Name/Anschrift zusätzliche Von-Fall-zu-Fall-Kennungen enthalten.
<G-vec00206-001-s197><comprise.enthalten><en> In the course of mostly only selective printing of address labels such storing of name/address may comprise additional identifiers on a case-by-case basis.
<G-vec00206-001-s198><comprise.enthalten><de> Diese Daten enthalten Angaben zu 235,933 Patenten, welche von Erfindern in Deutschland zwischen 1999 und 2011 beim Europäischen Patentamt angemeldet wurden.
<G-vec00206-001-s198><comprise.enthalten><en> The data comprise 235,933 patents filed between 1999 and 2011 at the European Patent Office.
<G-vec00206-001-s199><comprise.enthalten><de> Der Regierungssektor soll Funktionen einerseits enthalten, die Gerechtigkeit der Verwaltung oder der kenntnisreichen Durchführung der vorbestimmten Programme erfordern.
<G-vec00206-001-s199><comprise.enthalten><en> The government sector, on the other hand, ought to comprise functions that require fairness of administration or the knowledgeable execution of predetermined routines.
<G-vec00206-001-s200><comprise.enthalten><de> Die flüssigen Mittel enthalten Barmittel und kurzfristige liquide Anlagen mit einer Fälligkeit von ursprünglich bis zu drei Monaten.
<G-vec00206-001-s200><comprise.enthalten><en> Cash and cash equivalents comprise cash funds and all short-term liquid investments with original maturities of up to three months.
<G-vec00206-001-s201><comprise.enthalten><de> Die meisten Scheidungsabkommen enthalten drei Hauptelemente: Regelmäßige Zahlungen, Kapitalverfügungen (Pauschalbetrag und/oder Eigentumsübertragung) und eine langfristige Absicherung (Rentenpfändung und Rententeilung, Vorsorge durch eine Lebensversicherung).
<G-vec00206-001-s201><comprise.enthalten><en> Most divorce settlements comprise three main elements; periodical payments, capital orders (lump sum and/or transfer of property) and long term security (pension attachment and pension sharing orders, provision of life insurance cover).
<G-vec00206-001-s202><comprise.enthalten><de> Etwas von der allgemein benutzten Ausrüstung, die an den kundenspezifischen forklifts Verkäufen vorhanden ist, enthalten Zugang Plattformen für anhebende Arbeiter.
<G-vec00206-001-s202><comprise.enthalten><en> Some of the commonly used equipment available at custom forklifts sales comprise access platforms for lifting workers.
<G-vec00206-001-s203><comprise.enthalten><de> Die fünf CDs in dieser Box enthalten alle Lieder, die Johnnie Ray zwischen 1951 und 1956 für Columbia Records aufnahm, inklusive seines ersten großen Hits, Cry, sowie Top 10 Hits wie Walkin' My Baby Back Home, The Little White Cloud That Cried, Please Mister Sun, Somebody Stole My Gal, Such A Night und Just Walkin' In The Rain .
<G-vec00206-001-s203><comprise.enthalten><en> The five CDs in this set comprise everything that Johnnie Ray recorded for Columbia Records and its subsidiaries between 1951 and 1956, including his breakthrough hit, Cry, as well as Top 10 chartbusters like Walkin' My Baby Back Home, The Little White Cloud That Cried, Please Mister Sun, Somebody Stole My Gal, Such A Night, and Just Walkin' In The Rain .
<G-vec00206-001-s204><comprise.enthalten><de> Die Editionen enthalten die Gesamtausgabe der Briefe Friedrich Fröbels und den Briefwechsel zwischen Eduard Spranger und Käthe Hadlich .
<G-vec00206-001-s204><comprise.enthalten><en> The Editions comprise the Complete letters by Friedrich Fröbel and Correspondence between Eduard Spranger and Käthe Hadlich .
<G-vec00206-001-s205><comprise.enthalten><de> Vorlesen Die OECD-Leitsätze für multinationale Unternehmen enthalten anerkannte Grundsätze für verantwortliches unternehmerisches Verhalten bei Auslandsinvestitionen, u. a. in den Bereichen Menschenrechte, Soziales, Umwelt, Antikorruption, Steuern und Verbraucher.
<G-vec00206-001-s205><comprise.enthalten><en> The OECD guidelines for multinational enterprises comprise recognised principles for responsible business conduct in relation to foreign investments, inter alia in the areas of human rights, labour standards, environment, anti-corruption, taxes and consumers.
<G-vec00206-001-s206><comprise.enthalten><de> Sie könnten weder Vertragsverpflichtungen festsetzen noch eine Garantie von der Ernte enthalten.
<G-vec00206-001-s206><comprise.enthalten><en> They could neither constitute contractual engagements nor to comprise a guarantee of harvest.
<G-vec00206-001-s207><comprise.enthalten><de> GPCRs enthalten ein einzelnes Polypeptid, das in eine kugelförmige Form gefaltet wird und in der Plasmamembran beibehalten.
<G-vec00206-001-s207><comprise.enthalten><en> GPCRs comprise a single polypeptide that is folded into a spherical shape and retained in the plasma membrane.
<G-vec00206-001-s208><comprise.enthalten><de> Bewerbungen sollen ausführliche Unterlagen hinsichtlich der geforderten Qualifikations-voraussetzungen enthalten, insbesondere eine umfassende Dokumentation bisheriger Tätigkeiten, Nachweise organisatorischer Fähigkeiten, Vorstellungen zur Rektoratsführung mit Bezug zum aktuellen Profil sowie zur weiteren Entwicklung der Kunstuniversität Linz.
<G-vec00206-001-s208><comprise.enthalten><en> Applications should comprise extensive information with regard to the stated qualification requirements and should in particular include comprehensive documentation of previous work experience, proof of organizational skills, ideas regarding the exercise of the position of Rector in connection with the current profile and further development of the University of Art and Design Linz.
<G-vec00206-001-s209><comprise.enthalten><de> "(a) Nach Möglichkeit sollten alle außerschulischen Bildungsprogramme globale Sichtweisen vermitteln, die die moralischen, staatsbürgerlichen, kulturellen, wissenschaftlichen und technischen Aspekte einer ""internationalen Erziehung"" enthalten."
<G-vec00206-001-s209><comprise.enthalten><en> (a) as far as possible a global approach should be applied in all out-of-school education programs, which should comprise the appropriate moral, civic, cultural, scientific and technical elements of international education;
<G-vec00206-001-s210><comprise.enthalten><de> Anspruch 1 ist in allen Anträgen geändert worden, um deutlich zu machen, daß die Darreichungssysteme tatsächlich eine LHRH- Zusammensetzung und ein oder mehrere Steroide enthalten, und so den von der Kammer in ihrem ersten Bescheid erhobenen Einwand der mangelnden Klarheit auszuräumen.
<G-vec00206-001-s210><comprise.enthalten><en> Claim 1 of each request has been amended to make clear that the delivery systems actually comprise an LHRH composition and one or more steroids, thus overcoming the clarity objection raised in the first official communication by the board.
<G-vec00057-001-s209><hold.enthalten><de> Die Silos enthalten Mikroorganismen, Schnecken, Schalentiere und Pflanzen wie Maiglöckchen (Hyazinthe) und Wasserkresse, während einige auch Fisch enthalten.
<G-vec00057-001-s209><hold.enthalten><en> The silos contain microorganisms, snails, shellfish, and plants such as hyacinths and watercress; some also hold fish.
<G-vec00057-001-s210><hold.enthalten><de> Dort wo Mathematik, Geometrie und Spiritualität zusammenkommen Die Form Blume des Lebens beinhaltet eine geheimnisvolle Form die als die Frucht des Lebens bekannt ist und die aus 13 Sphären besteht, die viele mathematische und geometrische Gesetze enthalten.
<G-vec00057-001-s210><hold.enthalten><en> Where Math, Geometry, and SpiritualityÂ meet The Â flower of life Â shape contains a secret shape known as theÂ fruit of lifeÂ - that consists of 13 circles Â that hold many mathematical and geometrical laws.
<G-vec00057-001-s211><hold.enthalten><de> "In Anti-Springer-Sudoku (""Anti-Knight Sudoku"") müssen alle Zellen an einem Springer-Schachzug (in einer Entfernung von 2 zu 1) unterschiedliche Zahlen enthalten."
<G-vec00057-001-s211><hold.enthalten><en> In Anti-Knight Sudoku all cells at a chess knight move (at a distance of 2 by 1) must hold different numbers.
<G-vec00057-001-s212><hold.enthalten><de> Die Register R0 (LSB) und R1 (MSB) enthalten das Ergebnis hex 61A8 oder dezimal 25,000.
<G-vec00057-001-s212><hold.enthalten><en> The registers R0 (LSB) and R1 (MSB) hold the result hex 61A8 or decimal 25,000.
<G-vec00057-001-s213><hold.enthalten><de> Unter Ausnutzung der Eigenschaften der PE-Heißsiegelleistung können die Behälter aus verschiedenen Verbundmaterialien verschiedene Getränke wie Zitronensaft und Saft enthalten.
<G-vec00057-001-s213><hold.enthalten><en> Utilizing the characteristics of PE heat sealing performance, the containers made of various composite materials can hold various beverages such as lemon juice and juice.
<G-vec00057-001-s214><hold.enthalten><de> Diese Meldungen können aber dennoch sehr interessante Informationen enthalten und ihre Berücksichtigung verbessert die Sicherheit Ihres Netzes und Ihrer Systeme.
<G-vec00057-001-s214><hold.enthalten><en> These findings can hold very interesting information however and considering them will increase the security of your network and systems.
<G-vec00057-001-s215><hold.enthalten><de> Die Seiten siebzehn & achtzehn enthalten eine CD mit den digitalen Collagen.
<G-vec00057-001-s215><hold.enthalten><en> The pages seventeen & eighteen hold a CD with the digital collages.
<G-vec00057-001-s216><hold.enthalten><de> Die Spezialwannen enthalten 480 Liter Thermalwasser mit einer Badetemperatur von 36 bis 38° Celsius.
<G-vec00057-001-s216><hold.enthalten><en> The special tubs hold 480 liters of spring water kept at a bathing temperature of 36 to 38° Celsius.
<G-vec00057-001-s217><hold.enthalten><de> Die ersten Orte enthalten jedoch immer recht alte und bewährte Medikamente.
<G-vec00057-001-s217><hold.enthalten><en> However, the first places invariably hold fairly old and well-proven drugs.
<G-vec00057-001-s218><hold.enthalten><de> Das Audio Toolkit kann nun auch zusätzlich einen Audio Compression Manager enthalten.
<G-vec00057-001-s218><hold.enthalten><en> The audio toolkit can now also additionally hold an Audio Compression Manager.
<G-vec00057-001-s219><hold.enthalten><de> In Eurer DNS sind ätherische Zeitkapseln gelagert, die die Erinnerungsessenz von all Euren vergangenen Leben enthalten.
<G-vec00057-001-s219><hold.enthalten><en> Stored within your DNA are etheric time capsules which hold the memory Essence of all your past lives.
<G-vec00057-001-s220><hold.enthalten><de> Und ich, mich erinnernd, wie ich sie gesehen, als sie der holdseligsten Gesellschaft leistete, konnte mich der Tränen nicht enthalten; ich weinte und nahm mir vor, einige Worte auf ihren Tod zu sprechen, ihr zum Entgelt dafür, daß ich sie einmal mit meiner Herrin gesehen hatte.
<G-vec00057-001-s220><hold.enthalten><en> Then, remembering that I had seen her before accompanying the most graceful lady, I could not hold back tears: so weeping I decided to speak a few words about her death, in tribute to the fact that I had once seen her with my lady.
<G-vec00057-001-s221><hold.enthalten><de> Sie enthalten Meine ganze Vaterliebe zu Meinen Kindern.
<G-vec00057-001-s221><hold.enthalten><en> They hold My entire fatherly love for My children.
<G-vec00057-001-s222><hold.enthalten><de> Verzeichnisse, die sich überhaupt nicht komprimieren lassen, da sie etwa dieselbe Anzahl von Einträgen enthalten wir ihre Original-Instanz innerhalb des Webspace.
<G-vec00057-001-s222><hold.enthalten><en> directories which don't compress at all, as they hold about the same number of entries as their original instances in the web space.
<G-vec00057-001-s223><hold.enthalten><de> Das Beta-Stadium wird oft Kultbeschützer, innere Krieger und militärische Systeme enthalten.
<G-vec00057-001-s223><hold.enthalten><en> Beta state will often hold cult protectors, internal warriors, and military systems.
<G-vec00057-001-s224><hold.enthalten><de> Beispielsweise markiert das System diejenigen Greifbehälter mit Lichtsignalen, in denen Schrauben und andere Teile für den jeweils nächsten Arbeitsschritt enthalten sind.
<G-vec00057-001-s224><hold.enthalten><en> For instance, the system uses light signals to mark those grab containers that hold the screws or other parts required to complete the next step.
<G-vec00057-001-s225><hold.enthalten><de> Doch die vielen lokalen und grenzüberschreitenden Initiativen enthalten das Potenzial für einen Bruch sowohl mit dem Grenzregime als auch mit dem Spardiktat.
<G-vec00057-001-s225><hold.enthalten><en> But the many local and transborder initiatives hold the potential for a break both with the border regime as well as with the austerity dictate.
<G-vec00057-001-s226><hold.enthalten><de> Beide Bereiche können bis zu acht Farben enthalten.
<G-vec00057-001-s226><hold.enthalten><en> Both sections can hold up to 8 colors.
<G-vec00057-001-s227><hold.enthalten><de> Diese fantastische Reise ist nichts anderes als das Leben (individuell oder kollektiv) und diese Geschichten enthalten Hinweise darauf, wie das Leben funktioniert und wie man darin navigieren kann.
<G-vec00057-001-s227><hold.enthalten><en> The fantastic voyage is life, individual or collective, and these stories hold the clues on how it works and how to navigate.
<G-vec00185-001-s209><hold.enthalten><de> Die Silos enthalten Mikroorganismen, Schnecken, Schalentiere und Pflanzen wie Maiglöckchen (Hyazinthe) und Wasserkresse, während einige auch Fisch enthalten.
<G-vec00185-001-s209><hold.enthalten><en> The silos contain microorganisms, snails, shellfish, and plants such as hyacinths and watercress; some also hold fish.
<G-vec00185-001-s210><hold.enthalten><de> Dort wo Mathematik, Geometrie und Spiritualität zusammenkommen Die Form Blume des Lebens beinhaltet eine geheimnisvolle Form die als die Frucht des Lebens bekannt ist und die aus 13 Sphären besteht, die viele mathematische und geometrische Gesetze enthalten.
<G-vec00185-001-s210><hold.enthalten><en> Where Math, Geometry, and SpiritualityÂ meet The Â flower of life Â shape contains a secret shape known as theÂ fruit of lifeÂ - that consists of 13 circles Â that hold many mathematical and geometrical laws.
<G-vec00185-001-s211><hold.enthalten><de> "In Anti-Springer-Sudoku (""Anti-Knight Sudoku"") müssen alle Zellen an einem Springer-Schachzug (in einer Entfernung von 2 zu 1) unterschiedliche Zahlen enthalten."
<G-vec00185-001-s211><hold.enthalten><en> In Anti-Knight Sudoku all cells at a chess knight move (at a distance of 2 by 1) must hold different numbers.
<G-vec00185-001-s212><hold.enthalten><de> Die Register R0 (LSB) und R1 (MSB) enthalten das Ergebnis hex 61A8 oder dezimal 25,000.
<G-vec00185-001-s212><hold.enthalten><en> The registers R0 (LSB) and R1 (MSB) hold the result hex 61A8 or decimal 25,000.
<G-vec00185-001-s213><hold.enthalten><de> Unter Ausnutzung der Eigenschaften der PE-Heißsiegelleistung können die Behälter aus verschiedenen Verbundmaterialien verschiedene Getränke wie Zitronensaft und Saft enthalten.
<G-vec00185-001-s213><hold.enthalten><en> Utilizing the characteristics of PE heat sealing performance, the containers made of various composite materials can hold various beverages such as lemon juice and juice.
<G-vec00185-001-s214><hold.enthalten><de> Diese Meldungen können aber dennoch sehr interessante Informationen enthalten und ihre Berücksichtigung verbessert die Sicherheit Ihres Netzes und Ihrer Systeme.
<G-vec00185-001-s214><hold.enthalten><en> These findings can hold very interesting information however and considering them will increase the security of your network and systems.
<G-vec00185-001-s215><hold.enthalten><de> Die Seiten siebzehn & achtzehn enthalten eine CD mit den digitalen Collagen.
<G-vec00185-001-s215><hold.enthalten><en> The pages seventeen & eighteen hold a CD with the digital collages.
<G-vec00185-001-s216><hold.enthalten><de> Die Spezialwannen enthalten 480 Liter Thermalwasser mit einer Badetemperatur von 36 bis 38° Celsius.
<G-vec00185-001-s216><hold.enthalten><en> The special tubs hold 480 liters of spring water kept at a bathing temperature of 36 to 38° Celsius.
<G-vec00185-001-s217><hold.enthalten><de> Die ersten Orte enthalten jedoch immer recht alte und bewährte Medikamente.
<G-vec00185-001-s217><hold.enthalten><en> However, the first places invariably hold fairly old and well-proven drugs.
<G-vec00185-001-s218><hold.enthalten><de> Das Audio Toolkit kann nun auch zusätzlich einen Audio Compression Manager enthalten.
<G-vec00185-001-s218><hold.enthalten><en> The audio toolkit can now also additionally hold an Audio Compression Manager.
<G-vec00185-001-s219><hold.enthalten><de> In Eurer DNS sind ätherische Zeitkapseln gelagert, die die Erinnerungsessenz von all Euren vergangenen Leben enthalten.
<G-vec00185-001-s219><hold.enthalten><en> Stored within your DNA are etheric time capsules which hold the memory Essence of all your past lives.
<G-vec00185-001-s220><hold.enthalten><de> Und ich, mich erinnernd, wie ich sie gesehen, als sie der holdseligsten Gesellschaft leistete, konnte mich der Tränen nicht enthalten; ich weinte und nahm mir vor, einige Worte auf ihren Tod zu sprechen, ihr zum Entgelt dafür, daß ich sie einmal mit meiner Herrin gesehen hatte.
<G-vec00185-001-s220><hold.enthalten><en> Then, remembering that I had seen her before accompanying the most graceful lady, I could not hold back tears: so weeping I decided to speak a few words about her death, in tribute to the fact that I had once seen her with my lady.
<G-vec00185-001-s221><hold.enthalten><de> Sie enthalten Meine ganze Vaterliebe zu Meinen Kindern.
<G-vec00185-001-s221><hold.enthalten><en> They hold My entire fatherly love for My children.
<G-vec00185-001-s222><hold.enthalten><de> Verzeichnisse, die sich überhaupt nicht komprimieren lassen, da sie etwa dieselbe Anzahl von Einträgen enthalten wir ihre Original-Instanz innerhalb des Webspace.
<G-vec00185-001-s222><hold.enthalten><en> directories which don't compress at all, as they hold about the same number of entries as their original instances in the web space.
<G-vec00185-001-s223><hold.enthalten><de> Das Beta-Stadium wird oft Kultbeschützer, innere Krieger und militärische Systeme enthalten.
<G-vec00185-001-s223><hold.enthalten><en> Beta state will often hold cult protectors, internal warriors, and military systems.
<G-vec00185-001-s224><hold.enthalten><de> Beispielsweise markiert das System diejenigen Greifbehälter mit Lichtsignalen, in denen Schrauben und andere Teile für den jeweils nächsten Arbeitsschritt enthalten sind.
<G-vec00185-001-s224><hold.enthalten><en> For instance, the system uses light signals to mark those grab containers that hold the screws or other parts required to complete the next step.
<G-vec00185-001-s225><hold.enthalten><de> Doch die vielen lokalen und grenzüberschreitenden Initiativen enthalten das Potenzial für einen Bruch sowohl mit dem Grenzregime als auch mit dem Spardiktat.
<G-vec00185-001-s225><hold.enthalten><en> But the many local and transborder initiatives hold the potential for a break both with the border regime as well as with the austerity dictate.
<G-vec00185-001-s226><hold.enthalten><de> Beide Bereiche können bis zu acht Farben enthalten.
<G-vec00185-001-s226><hold.enthalten><en> Both sections can hold up to 8 colors.
<G-vec00185-001-s227><hold.enthalten><de> Diese fantastische Reise ist nichts anderes als das Leben (individuell oder kollektiv) und diese Geschichten enthalten Hinweise darauf, wie das Leben funktioniert und wie man darin navigieren kann.
<G-vec00185-001-s227><hold.enthalten><en> The fantastic voyage is life, individual or collective, and these stories hold the clues on how it works and how to navigate.
<G-vec00042-001-s473><involve.enthalten><de> "Ein spezieller rechtlicher Schutz von Daten, die Informationen zum Gesundheitszustand eines Menschen enthalten, wäre denkbar: ""KÃ1⁄4nftig könnte ein Algorithmus voraussagen, ob ein Mensch in nächster Zeit eine depressive Episode erleiden wird, weil der Algorithmus zuvor dessen Textbeiträge sowie sein Surfverhalten analysiert und darÃ1⁄4ber hinaus vielleicht noch verzeichnet hat, wie oft er das Haus verlässt."
<G-vec00042-001-s473><involve.enthalten><en> "A conceivable solution might involve special legal protection for data containing information on the state of a person's health: ""In the future, an algorithm that has previously analyzed a person's posts and browsing patterns and perhaps also recorded how often he or she leaves the house could predict whether that person will soon suffer a depressive episode."
<G-vec00042-001-s474><involve.enthalten><de> Obwohl Osisko glaubt, dass die in diesen vorausschauenden Aussagen aufgeführten auf angemessenen Annahmen basieren, so enthalten solche Aussagen bekannte und unbekannte Risiken, Unsicherheiten und andere Faktoren und sind keine Garantie der zukünftigen Leistung und die tatsächlichen Ergebnisse könnten sich entsprechend von jenen in den zukunftsgerichteten Aussagen wesentlich unterscheiden.
<G-vec00042-001-s474><involve.enthalten><en> Although Osisko believes the expectations expressed in such forward-looking statements are based on reasonable assumptions, such statements involve known and unknown risks, uncertainties and other factors and are not guarantees of future performance and actual results may accordingly differ materially from those in forward looking statements.
<G-vec00042-001-s475><involve.enthalten><de> Aussagen im Hinblick auf die Zukunft der Mine Hitura, die zukünftige Machbarkeit, Genehmigung und Erschließung des Goldprojekts Kopsa sowie die zukünftigen Pläne und Ziele des Unternehmens gelten uneingeschränkt als zukunftsgerichtete Aussagen, die unterschiedliche Risiken enthalten.
<G-vec00042-001-s475><involve.enthalten><en> Without limitation, statements regarding the future of the Hitura Mine and the future feasibility, permitting and development of the Kopsa gold project, as well as the future plans and objectives of the Company are forward looking statements that involve various degrees of risk.
<G-vec00042-001-s476><involve.enthalten><de> Aussagen im Hinblick auf die zukünftigen Pläne und Ziele des Unternehmens (einschließlich Aussagen zu zukünftigen Bohrergebnissen) gelten uneingeschränkt als zukunftsgerichtete Aussagen, die unterschiedliche Risiken enthalten.
<G-vec00042-001-s476><involve.enthalten><en> Without limitation, statements regarding future plans and objectives of the Company (including statements relating to future cash flows and operating costs) are forward-looking statements that involve various degrees of risk.
<G-vec00042-001-s477><involve.enthalten><de> "Einige enthalten emotionale Meisterschaft und das, was wir ""Ekstase und das Herz"" nennen."
<G-vec00042-001-s477><involve.enthalten><en> "Some of them involve emotional mastery and what we call ""ecstasy and the heart."""
<G-vec00042-001-s478><involve.enthalten><de> Die Informationen in dieser Pressemitteilung enthalten möglicherweise zukunftsgerichtete Aussagen gemäß anwendbarer Wertpapiergesetze.
<G-vec00042-001-s478><involve.enthalten><en> Forward-Looking Information Information set forth in this news release may involve forward-looking statements under applicable securities laws.
<G-vec00042-001-s479><involve.enthalten><de> Solche zukunftsgerichteten Aussagen enthalten Risiken und Unsicherheiten, wie sie bei Geschäftsvorhersagen unvermeidbar sind und die in unseren unter dem Securities Exchange Act eingereichten Dokumenten näher beschrieben sind.
<G-vec00042-001-s479><involve.enthalten><en> Such forward-looking statements involve risks and uncertainties inherent in business forecasts as further described in our filings under the Securities Exchange Act.
<G-vec00042-001-s480><involve.enthalten><de> Solche Aussagen enthalten gewisse bekannte und unbekannte Risiken, Unsicherheiten und sonstige Faktoren, die dazu führen können, dass die tatsächlichen Ergebnisse, die tatsächliche finanzielle Stellung, Performance oder die tatsächlichen Leistungen der WISeKey International Holding Ltd erheblich von den in den zukunftsgerichteten Aussagen ausdrücklich oder implizit enthaltenen Angaben zu künftigen Ergebnissen, künftiger Performance oder künftigen Leistungen abweichen.
<G-vec00042-001-s480><involve.enthalten><en> Such statements involve certain known and unknown risks, uncertainties and other factors, which could cause the actual results, financial condition, performance or achievements of WISeKey International Holding Ltd to be materially different from any future results, performance or achievements expressed or implied by such forward-looking statements.
<G-vec00042-001-s481><involve.enthalten><de> "Aussagen hinsichtlich des Unternehmens, die keine historischen Tatsachen sind, sind""vorausschauende Aussagen"", die Risiken und Unsicherheiten enthalten."
<G-vec00042-001-s481><involve.enthalten><en> "Statements regarding the Company which are not historical facts are ""forward-looking statements"" that involve risks and uncertainties."
<G-vec00042-001-s482><involve.enthalten><de> Aussagen im Hinblick auf die zukünftigen Pläne und Ziele des Unternehmens (einschließlich Aussagen zu zukünftigen Bohrergebnissen) gelten uneingeschränkt als zukunftsgerichtete Aussagen, die unterschiedliche Risiken enthalten.
<G-vec00042-001-s482><involve.enthalten><en> Without limitation, statements regarding future plans and objectives of the Company (including statements relating to future drilling and interpreted continuity of the new mineralised zones) are forward-looking statements that involve various degrees of risk.
<G-vec00042-001-s483><involve.enthalten><de> enthalten, die Risiken und Unsicherheiten.
<G-vec00042-001-s483><involve.enthalten><en> that involve risks and uncertainties.
<G-vec00042-001-s484><involve.enthalten><de> Patente Patente werden für Erfindungen erteilt, die neu sind, ein Element der erfinderischen Tätigkeit enthalten und gewerblich anwendbar sind.
<G-vec00042-001-s484><involve.enthalten><en> The patents are granted for inventions that are new, involve an inventive step and are susceptible of industrial application.
<G-vec00169-001-s024><glean.enthalten><de> Sie enthalten zum Beispiel Informationen darüber, wo und wie viel Reis in der laufenden Saison angebaut wurde, wie sich die Saat entwickelt oder ob zu viel oder zu wenig Wasser auf den Feldern steht.
<G-vec00169-001-s024><glean.enthalten><en> The information they glean tells them where and how much rice is being grown in the current season, how the seed is developing and whether the fields have too much or too little water.
<G-vec00206-001-s211><comprise.enthalten><de> Der mittlere Himalaja enthält die Region zwischen den Höhen von 1.500 Metern und 4.500 Metern.
<G-vec00206-001-s211><comprise.enthalten><en> The middle Himalayas comprise the region between the altitudes of 1,500 meters and 4,500 meters.
<G-vec00206-001-s212><comprise.enthalten><de> Diese Doppel-CD mit insgesamt 48 Einzeltiteln enthält alles, was Jimmy Work zwischen 1945 und 1959 aufgenommen hat.
<G-vec00206-001-s212><comprise.enthalten><en> 126 mns. These 48 tracks comprise everything that Jimmy Work recorded between 1945 and 1959.
<G-vec00206-001-s213><comprise.enthalten><de> Die dritte Gruppe von Studien enthält wirklich detaillierte neuronale Untersuchungen und Modellierung von Verarbeitungsprozessen des Gehirns.
<G-vec00206-001-s213><comprise.enthalten><en> The third group of studies comprise actual detailed neuronal investigations and modelling of how certain kinds of processing are accomplished by the brain.
<G-vec00206-001-s214><comprise.enthalten><de> B. eine Stadt oder ein Bundesland) ab und enthält verschiedene Radio-Sender.
<G-vec00206-001-s214><comprise.enthalten><en> a city or region) and comprise various radio stations.
<G-vec00206-001-s215><comprise.enthalten><de> Weiße Leute sind wahrscheinlich in sich selbst privilegiert, weil Weiß die Majorität von den Leuten in den Vereinigten Staaten enthält.
<G-vec00206-001-s215><comprise.enthalten><en> White people are thought to be inherently privileged because whites comprise the majority of people in the United States.
