<G-vec00486-002-s020><postpone.absagen><de> Leider müssen wir alle für dieses Semester geplanten Veranstaltungen, Länderabende und Exkursionen absagen.
<G-vec00486-002-s020><postpone.absagen><en> Due to the spread of the Coronavirus SARS-CoV-2 we are forced to cancel or postpone our events which were planned for this semester.
