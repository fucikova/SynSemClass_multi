<G-vec00476-001-s174><absorb.einziehen><de> Nach Einziehen der Creme die Cellular Eye Cream Platinum Rare oder Ihre bevorzugte Augencreme von la prairie auftragen.
<G-vec00476-001-s174><absorb.einziehen><en> Let product absorb and follow with Cellular Eye Cream Platinum Rare or preferred la prairie eye cream
<G-vec00476-001-s175><absorb.einziehen><de> Lassen Sie die Creme komplett einziehen bevor Sie andere Produkte auftragen.
<G-vec00476-001-s175><absorb.einziehen><en> Let the cream fully absorb into your skin before applying any other (tanning) products.
<G-vec00476-001-s176><absorb.einziehen><de> Dafür vorher ein Lippenpeeling benutzen und einen pflegenden Balsam auftragen und einziehen lassen.
<G-vec00476-001-s176><absorb.einziehen><en> Use a lip peeling before applying a nourishing balm and let it absorb into the skin.
<G-vec00476-001-s177><absorb.einziehen><de> Verfügt der Teig eine nicht zufriedenstellender Konsistenz und ist zu trocken, vorsichtig mehr Wasser hinzugeben und einziehen lassen, bevor Sie die Wassermenge erhöhen.
<G-vec00476-001-s177><absorb.einziehen><en> If the dough doesn't hold together and is too dry, carefully add more water and let it absorb before you add any additional water.
<G-vec00476-001-s178><absorb.einziehen><de> Energizing Eye Roll-On täglich morgens und abends nach der Reinigung, vor der Pflege unter dem Auge auftragen und einziehen lassen.
<G-vec00476-001-s178><absorb.einziehen><en> Apply Energizing Eye Roll-On under the eyes every morning and evening after washing and before your skincare routine, and allow it to absorb.
<G-vec00476-001-s179><absorb.einziehen><de> Massieren Sie die Nagelhaut mit kreisenden Bewegungen (von den Fingern zur Hand hin) und lassen es einziehen.
<G-vec00476-001-s179><absorb.einziehen><en> Massage cuticles with rotary movements (from finger towards hand) and leave on to absorb.
<G-vec00476-001-s180><absorb.einziehen><de> Beim anschließenden Auftragen von Seren oder Konzentraten darauf achten, dass die Haut vom Toner noch leicht feucht ist, denn so können die Wirkstoffe der anschließenden Pflege besser einziehen.
<G-vec00476-001-s180><absorb.einziehen><en> When applying serums or concentrates, make sure that the skin is still slightly moist, as this allows the active ingredients to better absorb the subsequent care.
<G-vec00476-001-s181><absorb.einziehen><de> Vor dem Anziehen das Produkt einziehen lassen.
<G-vec00476-001-s181><absorb.einziehen><en> Allow the product to absorb before tightening.
<G-vec00169-001-s133><collect.einziehen><de> Münch wird jedoch die Forderung nicht einziehen, solange der Kunde seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und insbesondere kein Antrag auf Eröffnung eines Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00169-001-s133><collect.einziehen><en> This shall not affect the authority of Münch to collect the receivables itself. Münch shall not collect the receivables, however, while the customer duly discharges its payment obligations from the proceeds received, is not in arrears with payments and, most importantly, if no request has been made to open insolvency proceedings or payments have been discontinued.
<G-vec00169-001-s134><collect.einziehen><de> Damit wir die SEPA-Lastschrift vom angegebenen Konto einziehen können, benötigen wir ein SEPA-Lastschriftmandat.
<G-vec00169-001-s134><collect.einziehen><en> So that we can collect the SEPA direct debit from the indicated account, we need a SEPA direct debit mandate.
<G-vec00169-001-s135><collect.einziehen><de> Nicht nur für feste Beträge Sobald eine Lastschrift eingerichtet ist, können Sie damit einmalige oder wiederkehrende Zahlungen jeder Größe einziehen.
<G-vec00169-001-s135><collect.einziehen><en> Not just for fixed amounts Once a Direct Debit is in place, you can use it to collect one-off or recurring payments of any amount.
<G-vec00169-001-s136><collect.einziehen><de> Unberührt bleibt unsere Befugnis, die Forderung selbst einzuziehen, wobei wir die Forderung nicht einziehen dürfen, solange der Kunde seinen Zahlungsverpflichtungen ordnungsgemäß nachkommt.
<G-vec00169-001-s136><collect.einziehen><en> Our right to collect the claim ourselves remains untouched whereas we are not allowed to collect the claim as long as the customer duly meets his obligation to pay.
<G-vec00169-001-s137><collect.einziehen><de> Das Team kann nun an jedem Tag des Monats Zahlungen einziehen und ändern und dabei jederzeit den Status der Zahlungen einsehen.
<G-vec00169-001-s137><collect.einziehen><en> The team can now collect and amend payments on any day of the month and see the status of payments at any time.
<G-vec00169-001-s138><collect.einziehen><de> Um unbefugten Zugang zu Ihren Daten oder Offenbarung Ihrer Daten zu vermeiden, haben wir passende physikalische, elektronische und unternehmerische Maßnahmen getroffen, mit denen wir die Informationen, die wir online einziehen, absichern und schützen.
<G-vec00169-001-s138><collect.einziehen><en> In order to prevent unauthorised access or disclosure, we have put in place suitable physical, electronic and managerial procedures to safeguard and secure the information we collect online.
<G-vec00169-001-s139><collect.einziehen><de> Nationaler Fall: sofern wir die zusätzlichen Kosten einziehen können, werden wir diese an Sie zurück zahlen.
<G-vec00169-001-s139><collect.einziehen><en> Domestic case – if we are able to collect these costs and interest, we will pay back this amount to you.
<G-vec00169-001-s140><collect.einziehen><de> BUTSCH wird jedoch die Forderung nicht einziehen, solange der Vertragspartner seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und insbesondere kein Antrag auf Eröffnung eines Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00169-001-s140><collect.einziehen><en> At the same time, BUTSCH will not collect the claims while contractual partner meets its payment obligations from the revenues received, while it is not late with its payments, and especially if they did not initiate the starting of an insolvency procedure, or the performance of payments is not suspended.
<G-vec00169-001-s141><collect.einziehen><de> Was für Sie richtig ist, hängt von Ihrem Unternehmen und der Höhe der Zahlungen ab, die Sie einziehen.
<G-vec00169-001-s141><collect.einziehen><en> Which is right for you will depend on your business and the amount of payments you collect.
<G-vec00169-001-s142><collect.einziehen><de> Wir selbst werden die Forderungen nicht einziehen, solange der Kunde seinen Zahlungsverpflichtungen uns gegenüber ordnungsgemäß nachkommt.
<G-vec00169-001-s142><collect.einziehen><en> We shall not collect the claims ourselves as long as Customer duly fulfils its payment obligations to us.
<G-vec00169-001-s143><collect.einziehen><de> Hansgrohe wird die Forderung nicht selbst einziehen, solange der Käufer seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug ist und kein Antrag auf Eröffnung eines Insolvenzverfahrens vorliegt.
<G-vec00169-001-s143><collect.einziehen><en> Hansgrohe will not collect the claim itself if the buyer meets its payment obligations resulting from the proceeds collected, is not overdue with its payments and there is no application for opening insolvency proceedings.
<G-vec00169-001-s144><collect.einziehen><de> Wenn Sie über ihn die Informationen im Internet, t einziehen werden...
<G-vec00169-001-s144><collect.einziehen><en> If collect about it information on the Internet, t...
<G-vec00169-001-s145><collect.einziehen><de> Aber trotz dieser explosionsartigen Zunahme wiederkehrender Zahlungen ist die Art und Weise, wie Unternehmen diese einziehen, nicht für das digitale Zeitalter geeignet.
<G-vec00169-001-s145><collect.einziehen><en> But despite this explosion in recurring payments, the way companies collect them isn’t fit for the digital age.
<G-vec00169-001-s146><collect.einziehen><de> Forderungen gegen uns darf der Kunde nur mit unserer vorherigen schriftlichen Zustimmung an Dritte abtreten oder durch Dritte einziehen lassen, es sei denn, es handelt sich um Forderungen, die unbestritten, entscheidungsreif oder rechtskräftig festgestellt sind.
<G-vec00169-001-s146><collect.einziehen><en> Claims against us may only be assigned by the Customer to third parties and he may only allow third parties to collect them with our prior written consent, unless they are accounts which are not contested, ready for judgment or have been adjudicated.
<G-vec00169-001-s147><collect.einziehen><de> Wir werden die abgetretenen Forderungen, solange unser Besteller seinen Zahlungsverpflichtungen nachkommt, nicht einziehen.
<G-vec00169-001-s147><collect.einziehen><en> We shall not collect the claims assigned as long as the purchaser meets his payment obligations.
<G-vec00169-001-s148><collect.einziehen><de> Kommt der Kunde seinen wesentlichen Pflichten nicht nach, ist er verpflichtet, auf Verlangen von uns die erforderlichen Daten mitzuteilen, insbesondere Name, Adresse, Telefonnummer des Käufers und die an ihn veräußerten Waren, damit wir dem Käufer gegenüber die Abtretung der Forderung anzeigen und diese selbst einziehen kann.
<G-vec00169-001-s148><collect.einziehen><en> In this case we shall have the right to request the necessary data, in particular name, address, phone number of the Customer´s clients and the resold products to give us the opportunity to notify the assignment of the claim and to collect the claim.
<G-vec00169-001-s149><collect.einziehen><de> Der Kunde verpflichtet sich, alle erforderlichen Handlungen auf Anforderung von AID zu unternehmen, damit AID die Anbietervergütung nach den Bestimmungen dieses Vertrages abrechnen und einziehen kann.
<G-vec00169-001-s149><collect.einziehen><en> The customer is obliged to undertake all the required actions upon request from AID so that AID can calculate and collect the supplier compensation in accordance with the determinations of this contract.
<G-vec00169-001-s150><collect.einziehen><de> "Bevor Sie eine SEPA-Lastschrift von einem Kunden einziehen können, müssen Sie ihm eine ""Vorabankündigung"" zukommen lassen."
<G-vec00169-001-s150><collect.einziehen><en> "Before you can collect a SEPA Direct Debit payment from a customer, you must give them ""Pre-notification""."
<G-vec00169-001-s151><collect.einziehen><de> Wenn du eine zusätzliche Gebühr erheben möchtest, kannst du diese Einzelheiten in deinen Hausregeln festhalten und die Gebühr über unser Mediations-Center einziehen.
<G-vec00169-001-s151><collect.einziehen><en> If you want to charge an additional fee, put those details in your House Rules and collect the fee using the Resolutions Center .
<G-vec00476-001-s121><soak_up.einziehen><de> Verarbeitungshinweise Mit einem feinen Schleifvlies einschleifen, kurz einziehen lassen und den Überschuss mit einem Baumwolltuch abnehmen.
<G-vec00476-001-s121><soak_up.einziehen><en> Processing instructions Rub with a fine sanding fleece, leave to soak in for a short while and then remove the excess with a cotton cloth.
<G-vec00476-001-s122><soak_up.einziehen><de> Für eine tiefe bronzefarbene Bräune - 3 Stunden einziehen lassen.
<G-vec00476-001-s122><soak_up.einziehen><en> For a deep bronze tan - leave to soak for 3 hours.
<G-vec00476-001-s123><soak_up.einziehen><de> Mit Schleifvlies einschleifen, kurz einziehen lassen und Überschuss mit Baumwolltuch abnehmen.
<G-vec00476-001-s123><soak_up.einziehen><en> Rub in with sanding fleece, allow to soak in briefly and remove excess with a cotton cloth.
<G-vec00476-001-s124><soak_up.einziehen><de> Fütterungsempfehlung sera Fishtamin: Zur regelmäßigen Nahrungsergänzung wöchentlich 2 – 3 Tropfen (bei normalbesetztem, mittelgroßen Aquarium) auf das Futter träufeln, kurz einziehen lassen und danach sofort verfüttern.
<G-vec00476-001-s124><soak_up.einziehen><en> Feeding recommendation sera Fishtamin:Weekly drip 2 – 3 drops (in case of normally stocked, medium sized aquarium) onto the food, let soak briefly and then feed immediately for regular diet enhancement.
<G-vec00169-001-s152><collect.einziehen><de> Die Berechtigung zur Einziehung erlischt, wenn der Kunde in Zahlungsverzug gerät, wenn ein Antrag auf Eröffnung des Insolvenzverfahrens gestellt wurde oder er seine Zahlungen eingestellt hat.
<G-vec00169-001-s152><collect.einziehen><en> The authorization to collect the claims expires when the customer is in delay of payment, when a decree of insolvency is applied for, or when he suspends payments.
<G-vec00169-001-s153><collect.einziehen><de> Nach der Abtretung ist der Unternehmer zur Einziehung der Forderung ermächtigt.
<G-vec00169-001-s153><collect.einziehen><en> After the assignment, the entrepreneur is authorised to collect the claim.
<G-vec00169-001-s154><collect.einziehen><de> Der Besteller bleibt jedoch berechtigt, die Einziehung der Forderung treuhänderisch für uns vorzunehmen.
<G-vec00169-001-s154><collect.einziehen><en> The buyer still remains entitled to collect on this claim for us in trust.
<G-vec00169-001-s155><collect.einziehen><de> (c) Zur Einziehung der Forderung bleibt der Käufer neben uns ermächtigt.
<G-vec00169-001-s155><collect.einziehen><en> (c) The buyer shall remain authorised to collect the claim in addition to us.
<G-vec00169-001-s156><collect.einziehen><de> 6.5 Bis auf Widerruf ist der Käufer zur Einziehung abgetretener Forderungen aus der Weiterveräußerung befugt.
<G-vec00169-001-s156><collect.einziehen><en> 6.5 The purchaser is authorised to collect assigned claims from the resale until this right is revoked.
<G-vec00169-001-s157><collect.einziehen><de> Wenn und soweit die an uns abgetretenen Forderungen den Betrag von 110 % unserer Forderungen gegen den Kunden nicht erreichen, tritt dieser zur Auffüllung hiermit seine gegenwärtigen und zukünftigen Ansprüche, die ihm - gleich aus welchem Rechtsgrund - zustehen, bis zum vorgenannten Höchstbetrag an uns ab und ermächtigt uns zur Einziehung und anschließenden Verrechnung, solange und soweit unsererseits Forderungen gegen den Kunden besteht.
<G-vec00169-001-s157><collect.einziehen><en> If and insofar as the receivables assigned to us amount to less than 110% of our claims against the customer, the customer hereby assigns to us, in order to reach this level, the current and future claims due to them – irrespective of the legal reason – up to the level of the above-mentioned maximum amount and authorises us to collect and then offset them as long and insofar as claims exist on our side against the customer.
<G-vec00169-001-s158><collect.einziehen><de> Der Besteller ist zur Einziehung der Forderungen aus der Weiterveräußerung trotz der Abtretung ermächtigt.
<G-vec00169-001-s158><collect.einziehen><en> In spite of the assignment the Customer shall be entitled to collect the receivables from the resale.
<G-vec00169-001-s159><collect.einziehen><de> Der Käufer bleibt zur Einziehung der Forderung auch nach der Abtretung ermächtigt.
<G-vec00169-001-s159><collect.einziehen><en> The Purchaser remains authorised to collect the receivables, even after cession.
<G-vec00169-001-s160><collect.einziehen><de> Zur Einziehung dieser Forderung bleibt der Besteller auch nach der Abtretung ermächtigt.
<G-vec00169-001-s160><collect.einziehen><en> The purchaser shall remain authorized to collect on the claim even after the assignment.
<G-vec00169-001-s161><collect.einziehen><de> Nach Abtretung ist der Besteller zur Einziehung der Forderung bis auf Widerruf ermächtigt.
<G-vec00169-001-s161><collect.einziehen><en> After assignment of Buyer to collect outstanding payments until further notice.
<G-vec00169-001-s162><collect.einziehen><de> Auf unser Verlangen ist er verpflichtet, uns die zur Einziehung abgetretener Forderungen erforderlichen Auskünfte und Unterlagen vollständig unverzüglich zu geben und, sofern wir dies nicht selbst tun, seine Abnehmer unverzüglich von der Abtretung an uns zu unterrichten.8.
<G-vec00169-001-s162><collect.einziehen><en> At our request, the customer shall be obliged to give us in full the information and documents required to collect assigned claims without delay and, if we do not do so ourselves, to notify its buyers immediately of the assignment to us.8.
<G-vec00169-001-s163><collect.einziehen><de> Der Käufer ist zur Einziehung seiner Forderungen trotz der Abtretung berechtigt.
<G-vec00169-001-s163><collect.einziehen><en> Regardless of this assignment, the purchaser is entitled to collect the accounts receivable.
<G-vec00169-001-s164><collect.einziehen><de> 3) Trotz Abtretung ist der Besteller zur Einziehung seiner Forderung gegenüber dem Abnehmer berechtigt.
<G-vec00169-001-s164><collect.einziehen><en> 3) Despite assignment, the ordering party shall be permitted to collect his/her claims towards the buyer.
<G-vec00169-001-s165><collect.einziehen><de> Zur Einziehung dieser Forderung bleibt der Kunde auch nach der Abtretung ermächtigt.
<G-vec00169-001-s165><collect.einziehen><en> The customer remains entitled to collect this claim, even subsequent to the assignment.
<G-vec00169-001-s166><collect.einziehen><de> (c) Zur Einziehung der Forderung bleibt der Kunde neben uns ermächtigt.
<G-vec00169-001-s166><collect.einziehen><en> (c) The Customer shall remain entitled to collect the claim alongside us.
<G-vec00169-001-s167><collect.einziehen><de> Unser Recht zur Einziehung der Forderung beim Abnehmer tritt nur in Kraft, wenn der Besteller seinen Zahlungspflichten nicht nachkommt, mit Beauftragung des Insolvenzverfahrens, einem Scheck- oder Wechselprotest oder einer erfolgten Pfändung beim Kunden.
<G-vec00169-001-s167><collect.einziehen><en> Our right to collect the claims from the buyer shall be effective only, if the ordering party does not fulfil his/her payment obligations, if insolvency proceedings are instituted, a cheque or bill is protested or seizure is carried out.
<G-vec00169-001-s168><collect.einziehen><de> Zur Einziehung dieser Forderungen ist der Käufer auch nach Abtretung ermächtigt.
<G-vec00169-001-s168><collect.einziehen><en> The Buyer is also authorised to collect receivables even after the reassignment.
<G-vec00169-001-s169><collect.einziehen><de> (c) Zur Einziehung der Forderung bleibt der Kunde neben uns ermächtigt.
<G-vec00169-001-s169><collect.einziehen><en> (c) The customer shall remain entitled to collect the claim in addition to us.
<G-vec00169-001-s170><collect.einziehen><de> Auf unser Verlangen ist er verpflichtet, uns die zur Einziehung abgetretener Forderungen erforderlichen Auskünfte und Unterlagen vollständig zu geben und, sofern wir dies nicht selbst tun, seine Abnehmer unverzüglich von der Abtretung an uns zu unterrichten.
<G-vec00169-001-s170><collect.einziehen><en> At our request, the customer shall be obliged to give us in full the information and documents required to collect assigned claims and, if we do not do so ourselves, to notify its buyers immediately of the assignment to us.
<G-vec00169-001-s190><collect.einziehen><de> Wir behalten uns vor, die Forderung selbst einzuziehen, wenn der Kunde seinen Zahlungsverpflichtungen nicht ordnungsgemäß nachkommt und in Zahlungsverzug gerät.
<G-vec00169-001-s190><collect.einziehen><en> We reserve the right to collect payment ourselves, should the customer fail to fulfil his obligation to pay and be in arrears.
<G-vec00169-001-s191><collect.einziehen><de> Bei Zahlungsverzug des Bestellers ist der Lieferer berechtigt, die abgetretene Forderung beim Drittschuldner direkt einzuziehen.
<G-vec00169-001-s191><collect.einziehen><en> If the Buyer fails to pay on time, Supplier is entitled to collect the assigned receivable directly from the third-party debtor.
<G-vec00169-001-s192><collect.einziehen><de> Unsere Befugnis, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s192><collect.einziehen><en> This is without prejudice to our right to collect such receivables ourselves.
<G-vec00169-001-s193><collect.einziehen><de> § 49 Aufgaben der Liquidatoren (1) Die Liquidatoren haben die laufenden Geschäfte zu beendigen, die Forderungen einzuziehen, das übrige Vermögen in Geld umzusetzen, die Gläubiger zu befriedigen und den Überschuss den Anfallberechtigten auszuantworten.
<G-vec00169-001-s193><collect.einziehen><en> (1) The liquidators must complete the current business, collect the receivables, convert the rest of the assets into cash, satisfy the creditors and pay out the surplus to those entitled to receive it.
<G-vec00169-001-s194><collect.einziehen><de> Er ist ermächtigt, diese bis zum Widerruf oder zur Einstellung seiner Zahlungen an uns für unsere Rechnung einzuziehen.
<G-vec00169-001-s194><collect.einziehen><en> He is entitled to collect the amount of such claims on our behalf until revoked or until cessation of his payments made to us.
<G-vec00169-001-s195><collect.einziehen><de> Wir verpflichten uns jedoch, die Forderung nicht einzuziehen, solange der Kunde seinen Zahlungsverpflichtungen aus den vereinnahmten Erlösen nachkommt, nicht in Zahlungsverzug gerät und insbesondere kein Antrag auf Eröffnung eines Vergleichs- oder Insolvenzverfahrens gestellt ist oder Zahlungseinstellung vorliegt.
<G-vec00169-001-s195><collect.einziehen><en> However, we undertake not to collect the debt if purchasers meet their payment obligations from the sales proceeds, do not fall into arrears, and, in particular, have not filed for settlement or bankruptcy proceedings, nor ceased making payments.
<G-vec00169-001-s196><collect.einziehen><de> Wir bleiben befugt, die Forderung selbst einzuziehen, das Recht des Bestellers, die Einziehung vorzunehmen, bleibt auch nach Abtretung bestehen.
<G-vec00169-001-s196><collect.einziehen><en> We retain the right to collect the receivable ourselves; the orderer's right to undertake the collection shall remain in force even after the assignment.
<G-vec00169-001-s197><collect.einziehen><de> Die Nouvag AG ist jederzeit berechtigt, die Abtretung offen zu legen und die abgetretenen Forderungen selbst einzuziehen.
<G-vec00169-001-s197><collect.einziehen><en> Nouvag AG shall be entitled at any time to disclose the assignment and to collect the claims assigned.
<G-vec00169-001-s198><collect.einziehen><de> In diesem Zusammenhang verpflichten wir uns, die Forderung nicht einzuziehen, solange und soweit der Käufer seinen Zahlungsverpflichtungen nachkommt, kein Antrag auf Eröffnung eines Insolvenz- oder ähnlichen Verfahrens gestellt ist und keine Zahlungseinstellung vorliegt.
<G-vec00169-001-s198><collect.einziehen><en> In this context, we are obliged not to collect the claim as long and insofar as the buyer meets his payment obligations, there has been no application for the opening of insolvency or similar proceedings or cessation of payment.
<G-vec00169-001-s199><collect.einziehen><de> Die Befugnis von Hematris, die Forderung selbst einzuziehen, bleibt hiervon unberührt; jedoch verpflichtet sich Hematris, die Forderung nicht einzuziehen, solange der Kunde seinen Zahlungsverpflichtungen ordnungsgemäß nachkommt und nicht in Zahlungsverzug ist.
<G-vec00169-001-s199><collect.einziehen><en> The authority of Hematris to collect the receivable itself will remain unaffected by this; however Hematris undertakes not to collect the receivable provided the Customer properly fulfils his payment obligations and is not in default of payment.
<G-vec00169-001-s200><collect.einziehen><de> Die Befugnis von Hematris, die Forderung selbst einzuziehen, bleibt hiervon unberührt; jedoch verpflichtet sich Hematris, die Forderung nicht einzuziehen, solange der Kunde seinen Zahlungsverpflichtungen ordnungsgemäß nachkommt und nicht in Zahlungsverzug ist.
<G-vec00169-001-s200><collect.einziehen><en> The authority of Hematris to collect the receivable itself will remain unaffected by this; however Hematris undertakes not to collect the receivable provided the Customer properly fulfils his payment obligations and is not in default of payment.
<G-vec00169-001-s201><collect.einziehen><de> Die Befugnis des Verkäufers, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s201><collect.einziehen><en> The authority of the supplier, to collect the claim themselves, remains hereof unaffected.
<G-vec00169-001-s202><collect.einziehen><de> Unsere Befugnis, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s202><collect.einziehen><en> Our authority to collect the claim ourselves remains thereby unaffected.
<G-vec00169-001-s203><collect.einziehen><de> Mittels einer europäischen Lastschrift können Sie einem europäischen Gläubiger (dem belgischen oder europäischen Lieferanten Ihrer Waren oder Dienstleistungen) die Erlaubnis erteilen, Ihre zukünftigen Rechnungen automatisch einzuziehen.
<G-vec00169-001-s203><collect.einziehen><en> The SEPA Direct Debit allows you to give a European creditor (the Belgian or European supplier of your goods or services) permission to collect payment automatically for your future invoices.
<G-vec00169-001-s204><collect.einziehen><de> In diesem Falle wird der Verkäufer hiermit vom Käufer bevollmächtigt, die Abnehmer von der Abtretung zu unterrichten und die Forderungen selbst einzuziehen.
<G-vec00169-001-s204><collect.einziehen><en> In this case the seller is hereby authorized by the purchaser to inform his buyers about the assignment and to collect the claims himself.
<G-vec00169-001-s205><collect.einziehen><de> Die Befugnis des Lieferanten, die Forderung selbst einzuziehen, bleibt hiervon unberührt.
<G-vec00169-001-s205><collect.einziehen><en> This shall not affect the entitlement of the Supplier to collect the receivables himself.
<G-vec00169-001-s206><collect.einziehen><de> Wir behalten uns vor, die Forderung selbst einzuziehen, sobald der Unternehmer seinen Zahlungsverpflichtungen nicht ordnungsgemäß nachkommt und in Zahlungsverzug gerät.
<G-vec00169-001-s206><collect.einziehen><en> We reserve the right to collect the outstanding payments ourselves should the entrepreneur not properly fulfil his payment duties and fall into default with payment.
<G-vec00169-001-s207><collect.einziehen><de> Unberührt bleibt unsere Befugnis, die Forderung selbst einzuziehen, wobei wir die Forderung nicht einziehen dürfen, solange der Kunde seinen Zahlungsverpflichtungen ordnungsgemäß nachkommt.
<G-vec00169-001-s207><collect.einziehen><en> Our right to collect the claim ourselves remains untouched whereas we are not allowed to collect the claim as long as the customer duly meets his obligation to pay.
<G-vec00169-001-s208><collect.einziehen><de> Der Käufer ist - bis auf Widerruf - berechtigt, die Forderung für HTV-Conservation GmbH einzuziehen.
<G-vec00169-001-s208><collect.einziehen><en> The Buyer is entitled to collect claims resulting from the reselling until revoked by the supplier.
