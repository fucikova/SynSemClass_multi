<G-vec00614-002-s005><spew.ausspeien><de> 22 (ELB) Und ihr sollt alle meine Satzungen und alle meine Rechte beobachten und sie tun, damit euch das Land nicht ausspeie, wohin ich euch bringe, um darin zu wohnen.
<G-vec00614-002-s005><spew.ausspeien><en> 22 (UKJV) All of you shall therefore keep all my statutes, and all my judgments, and do them: that the land, where I bring you to dwell therein, spew you not out.
<G-vec00614-002-s006><spew.ausspeien><de> 3,16 Also, weil du lau bist und weder heiß noch kalt, werde ich dich ausspeien aus meinem Munde.
<G-vec00614-002-s006><spew.ausspeien><en> 3,16 So, because you are lukewarm, and neither cold nor hot, I will spew you out of my mouth.
<G-vec00614-002-s007><spew.ausspeien><de> 16Weil du aber lau bist und weder warm noch kalt, werde ich dich ausspeien aus meinem Munde.
<G-vec00614-002-s007><spew.ausspeien><en> So then because thou art lukewarm, and neither cold nor hot, I will spew thee out of my mouth.
