<G-vec00507-002-s019><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die FAT-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s019><file.anklicken><en> Simply right-click on the IBAK file, then from the available list select "Choose default program".
<G-vec00507-002-s020><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die CVM-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s020><file.anklicken><en> Simply right-click on the CVM file, then from the available list select "Choose default program".
<G-vec00507-002-s021><file.anklicken><de> Viele XML-Programme richten sich selbst als Standardprogramm für XML-Dateien ein, was es dir erlaubt, die XML-Datei einfach doppelt anzuklicken, um sie zu öffnen.
<G-vec00507-002-s021><file.anklicken><en> Many XML programs will set themselves as the default program for XML files, allowing you to simply double-click the XML file to open it.
<G-vec00507-002-s022><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die PDI-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s022><file.anklicken><en> Simply right-click on the PDI file, then from the available list select "Choose default program".
<G-vec00507-002-s023><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die BWP-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s023><file.anklicken><en> Simply right-click on the BUR file, then from the available list select "Choose default program".
<G-vec00507-002-s024><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die TRK-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s024><file.anklicken><en> Simply right-click on the TRK file, then from the available list select "Choose default program".
<G-vec00507-002-s025><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die PQW-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s025><file.anklicken><en> Simply right-click on the CPO file, then from the available list select "Choose default program".
<G-vec00507-002-s026><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die XLV-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s026><file.anklicken><en> Simply right-click on the XLV file, then from the available list select "Choose default program".
<G-vec00507-002-s027><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die PACK-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s027><file.anklicken><en> Simply right-click on the PACK file, then from the available list select "Choose default program".
<G-vec00507-002-s028><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die NUC-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s028><file.anklicken><en> Simply right-click on the NUC file, then from the available list select "Choose default program".
<G-vec00507-002-s029><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die WMZ-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s029><file.anklicken><en> Simply right-click on the WMZ file, then from the available list select "Choose default program".
<G-vec00507-002-s030><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die CATALOG-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s030><file.anklicken><en> Simply right-click on the CATALOG file, then from the available list select "Choose default program".
<G-vec00507-002-s031><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die XTREME-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s031><file.anklicken><en> Simply right-click on the XTREME file, then from the available list select "Choose default program".
<G-vec00507-002-s032><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die LWV-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s032><file.anklicken><en> Simply right-click on the MPD file, then from the available list select "Choose default program".
<G-vec00507-002-s033><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die SSM-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s033><file.anklicken><en> Simply right-click on the SSM file, then from the available list select "Choose default program".
<G-vec00507-002-s034><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die FDE-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s034><file.anklicken><en> Simply right-click on the FDE file, then from the available list select "Choose default program".
<G-vec00507-002-s035><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die VRH-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s035><file.anklicken><en> Simply right-click on the VRH file, then from the available list select "Choose default program".
<G-vec00507-002-s036><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die JMP-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s036><file.anklicken><en> Simply right-click on the JMP file, then from the available list select "Choose default program".
<G-vec00507-002-s037><file.anklicken><de> Es reicht aus, mit der rechten Maustaste die EPD-Datei anzuklicken, und dann aus den angegebenen Optionen „Standardprogramm auswählen..“ auszuwählen.
<G-vec00507-002-s037><file.anklicken><en> Simply right-click on the EPD file, then from the available list select "Choose default program".
