<G-vec00291-001-s020><peg.abstecken><de> Ein Mitglied der Partnerschaft wird zum Abstecken ausgewählt, und diese beiden Spieler heben für die erste Krippe ab.
<G-vec00291-001-s020><peg.abstecken><en> One member of the partnership is elected to peg and these two players cut for first box.
