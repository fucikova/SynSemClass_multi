<G-vec00078-001-s161><uphold.einhalten><de> Mit jeder Sicherheitsfunktion, die wir hinzufügen, und mit jedem Standard in unseren Community-Richtlinien, den wir einhalten, setzen wir uns für deine Sicherheit auf deinen zukünftigen Wegen ein.
<G-vec00078-001-s161><uphold.einhalten><en> With every safety feature we add and every standard in our Community Guidelines we uphold, we’re committed to protecting you on the road ahead.
<G-vec00078-001-s162><uphold.einhalten><de> Genau wie unsere NATO-Verbündeten, haben wir eine feierliche Verpflichtung zu unserer kollektiven Verteidigung, und wir werden diese Verpflichtung einhalten.
<G-vec00078-001-s162><uphold.einhalten><en> As NATO allies, we have a solemn commitment to our collective defense, and we will uphold this commitment.
<G-vec00078-001-s163><uphold.einhalten><de> Wenn Sie eine Lieferfrist überschreiten, haben Sie keinen Anspruch auf Entschädigung oder das Recht, Ihre Bestellung zu stornieren oder den Vertrag zu kündigen, es sei denn, die Lieferfrist wird so überschritten, dass Sie den Vertrag in angemessener Weise nicht einhalten können.
<G-vec00078-001-s163><uphold.einhalten><en> Exceeding any delivery period does not entitle you to compensation or the right to cancel your order or terminate the agreement, unless the delivery period is exceeded in such a way that you could not reasonably be expected to uphold the agreement.
<G-vec00078-001-s164><uphold.einhalten><de> Wir werden den Grundsatz der Bescheidenheit und Strenge einhalten.
<G-vec00078-001-s164><uphold.einhalten><en> we will uphold the principle of modesty, rigorous.
<G-vec00078-001-s165><uphold.einhalten><de> Ob nun alle Christen diesem Auftrag folgten, spielt eigentlich keine Rolle; genauso wie, ob nun alle Muslime die Verpflichtung zum Jihad einhalten oder es nicht tun kaum eine Rolle spielt.
<G-vec00078-001-s165><uphold.einhalten><en> Whether or not all Christians follow such mandates is hardly the point; just as whether or not all Muslims uphold the obligation of jihad is hardly the point.
<G-vec00078-001-s166><uphold.einhalten><de> Deswegen überprüfen wir sie sehr vorsichtig, damit wir die höchsten Standarte der Industrie einhalten können.
<G-vec00078-001-s166><uphold.einhalten><en> Therefore we screen them carefully, so we can uphold the highest standards in the industry.
<G-vec00078-001-s174><uphold.einhalten><de> Ich fordere Saudi-Arabien auf, die Standards dieser Konvention einzuhalten und die Todesstrafe auszusetzen.
<G-vec00078-001-s174><uphold.einhalten><en> I call on Saudi Arabia to uphold the standards of this Convention and to commute the death penalty.
<G-vec00078-001-s175><uphold.einhalten><de> Sie sind auch als Mitglied verpflichtet, unsere Statuten einzuhalten und zu befolgen.
<G-vec00078-001-s175><uphold.einhalten><en> You are also obliged as a member to uphold and follow our statutes.
<G-vec00078-001-s176><uphold.einhalten><de> "Die IGMENA- Kampagne ""Click Rights"" will bei Bürgern ein Bewusstsein für digitale Rechte schaffen, so dass sie auf ihre Regierungen und den Privatsektor Druck ausüben können, diese Rechte einzuhalten."
<G-vec00078-001-s176><uphold.einhalten><en> "The IGMENA campaign ""Click Rights"" aims to bring more awareness of digital rights to citizens, so they in turn can pressure governments and the private sector to uphold them."
<G-vec00078-001-s177><uphold.einhalten><de> Es muss alles getan werden, um zivile Opfer zu vermeiden und das humanitäre Völkerrecht einzuhalten.
<G-vec00078-001-s177><uphold.einhalten><en> Everything possible must be done to avoid civilian casualties and uphold international humanitarian law.
<G-vec00078-001-s178><uphold.einhalten><de> Als Turandot sich weigert, ihren Teil der Vereinbarung einzuhalten, kontert der Prinz mit einem eigenen Rätsel: Wenn sie bis zum Sonnenaufgang seinen richtigen Namen erraten kann, so darf sie ihn wie die anderen hinrichten.
<G-vec00078-001-s178><uphold.einhalten><en> When Turandot refuses to uphold her part of the deal, the prince counters with a riddle of his own: if she can guess his true name by sunrise, she can execute him like the others.
