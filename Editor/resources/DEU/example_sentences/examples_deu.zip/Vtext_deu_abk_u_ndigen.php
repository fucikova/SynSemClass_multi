<G-vec00081-001-s036><discontinue.abkündigen><de> Deshalb sind wir gezwungen, die davon betroffenen Produkte kurzfristiger abzukündigen.
<G-vec00081-001-s036><discontinue.abkündigen><en> Consequently, we are forced to discontinue the affected products at short notice.
<G-vec00081-001-s216><discontinue.abkündigen><de> Allerdings haben die Hersteller die Entwicklung neuer Produkte schon vor längerem eingestellt und kündigen zunehmend auch die Produktion und den Support von verfügbaren Karten ab.
<G-vec00081-001-s216><discontinue.abkündigen><en> However, manufacturers have stopped the development of new products some time ago and increasingly discontinue the production and support of available cards.
