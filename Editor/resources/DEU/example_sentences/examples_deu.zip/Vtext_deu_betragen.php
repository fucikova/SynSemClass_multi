<G-vec00206-001-s114><amount.betragen><de> Die Mindestabstände von Motor- und Segelbooten mit weniger als 12 Meter Länge zur Küste betragen 50 Meter, bei längeren Schiffen 150 Meter.
<G-vec00206-001-s114><amount.betragen><en> The minimum distance of motor and sailboats with less than twelve meters in length to the coast amount to 50 meters, and for longer boats it is 150 meters.
<G-vec00206-001-s115><amount.betragen><de> Die Stückkosten der eingekauften Güter und Leistungen sowie die Prozesskosten betragen durchschnittlich über 50% der Gesamtkosten eines Unternehmens.
<G-vec00206-001-s115><amount.betragen><en> The cost per unit of the purchased goods and services as well as the process costs amount to an average of more than 50% of the overall costs of a company.
<G-vec00206-001-s116><amount.betragen><de> """Wir bauen Anlagen, die 5 bis 8 MW groß sind, das bedeutet, dass allein die Grundstücksflächen zwischen 80.000 und 150.000 m2 betragen müssen"", so Andreas Fleischmann."
<G-vec00206-001-s116><amount.betragen><en> """We build plants of sizes 5 to 8 MW, which means that the plot sizes alone should amount to 80,000 and 150,000 mÂ2,"" says Andreas Fleischmann."
<G-vec00206-001-s117><amount.betragen><de> Werden die jährlich festgelegten Jahresziele übertroffen, kann der Performance Bonus über dem Zielbonus liegen; er kann jedoch maximal 200 Prozent des Zielbonus (Cap) betragen.
<G-vec00206-001-s117><amount.betragen><en> If the annual targets are exceeded, the performance bonus may also exceed the target bonus; however, it may not amount to more than 200% of the target bonus (cap).
<G-vec00206-001-s118><amount.betragen><de> Negative Sauerstoffionen und negative Ionen betragen bis zu 10 Millionen Ionen/cmÂ3.
<G-vec00206-001-s118><amount.betragen><en> Negative oxygen ions and negative ions amount to up to 10,000,000 ions/cc.
<G-vec00206-001-s119><amount.betragen><de> Bei Lagerung durch den Verkäufer betragen die Lagerkosten 0,25% des Rechnungsbetrages der zu lagernden Liefergegenstände pro abgelaufene Woche.
<G-vec00206-001-s119><amount.betragen><en> If the goods are stored by the seller then the storage costs amount to 0.25% of the invoiced amount of the stored items for delivery per lapsed week.
<G-vec00206-001-s120><amount.betragen><de> Nach aktuellen Berechnungen betragen die Baukosten insgesamt rund 76 Millionen Euro brutto.
<G-vec00206-001-s120><amount.betragen><en> According to the latest calculations, the construction costs amount in total to about 76 million Euros gross.
<G-vec00206-001-s121><amount.betragen><de> Diese Finanzierungsanteile können bis zu 65% des kalkulierten Budgets betragen.
<G-vec00206-001-s121><amount.betragen><en> Such funding can amount to as much as 65% of the calculated budget.
<G-vec00206-001-s122><amount.betragen><de> Die Kosten für den Standard Test, der übrigens die gesetzlich weltweit vorgeschriebene UN-T Prüfung (United Nations Transportation Test - Transportvorschriften für Lithiumbatterien) beinhaltet, betragen etwa 5.000 bis 6.000 Euro.“ Günstiger, als ein eigenes Labor aufzubauen, in das nach Steinkes Angaben problemlos mehrere Millionen Euro investiert werden können.
<G-vec00206-001-s122><amount.betragen><en> The cost of the standard test amount to 5,000 to 6,000 €. The cost of the United Nations Transportation (UN-T) Test is included in the price. This is cheaper than building an own lab, since the investment for a company-owned laboratory can amount to several million euros.
<G-vec00206-001-s123><amount.betragen><de> Die Studiengebühren zum Studienbeginn 2018 betragen 630 Euro pro Monat.
<G-vec00206-001-s123><amount.betragen><en> The course fees at the beginning of the 2018 academic year amount to EUR 630 per month.
<G-vec00206-001-s124><amount.betragen><de> Die Übertragungsraten betragen 10 MB und mehr, wobei Weiterentwicklungen wie SCSI 2, Fast SCSI, Wide SCSI und andere höhere Raten bieten und zusätzlich einen Anschluss von mehr Geräten ermöglichen.
<G-vec00206-001-s124><amount.betragen><en> The data transmission rates amount to 10 MT and more, whereby advancements offer such as SCSI 2, nearly SCSI, Wide SCSI and other higher rates and make additionally a connection possible of more devices.
<G-vec00206-001-s125><amount.betragen><de> 2 Die monatliche Rückzahlung muss gesetzlich mindestens 5,6% Ihres geschuldeten Saldos betragen.
<G-vec00206-001-s125><amount.betragen><en> 2 By law, the amount you repay monthly must be at least 5.6% of your outstanding balance.
<G-vec00206-001-s126><amount.betragen><de> betragen pauschal 6,95 Euro.
<G-vec00206-001-s126><amount.betragen><en> amount to a lump sum of 6.95 Euros.
<G-vec00206-001-s127><amount.betragen><de> Die Jahreskapazität wird im Normalbetrieb 180.000 Tonnen betragen, bei Spitzenlast bis zu 220.000 Tonnen.
<G-vec00206-001-s127><amount.betragen><en> The yearly capacity will amount to in the normal operation 180,000 tons, with peak load up to 220.000 tons.
<G-vec00206-001-s128><amount.betragen><de> Um auf Dauer in solchen Situationen zu gewinnen muss unsere Gewinnerwartung (Gewinnchance) mindestens 33% (2 zu 1) betragen.
<G-vec00206-001-s128><amount.betragen><en> To continuously win in such situations our chances of winning have to amount to at least 50%.
<G-vec00206-001-s129><amount.betragen><de> 9.2 Die außergerichtlichen Inkassokosten betragen höchstens 15 % der Forderung(en) und mindestens 40,- €.
<G-vec00206-001-s129><amount.betragen><en> 9.2 The extrajudicial costs will amount to fifteen per cent (15%) maximum of the amount or amounts owed, with a minimum of € 40.
<G-vec00206-001-s130><amount.betragen><de> Dieser Einfluß kann durchaus 30% +- betragen.
<G-vec00206-001-s130><amount.betragen><en> This influence varies but can by all means amount up to 30%.
<G-vec00206-001-s131><amount.betragen><de> Die eingereichten Schätzungen der Schäden der Gemeinden betragen 613.000 Euro.Angefordert werden in etwa 552.000 Euro, denn einige Kostenanteile konnten von verschiedenen Gemeinden übernommen werden.
<G-vec00206-001-s131><amount.betragen><en> The submitted estimates of the damage to municipalities amount to 613,000 euros. About 552,000 euros are being called for, because the various municipalities were able to take on some parts of the costs.
<G-vec00206-001-s132><amount.betragen><de> In Bezug auf Enteignung, das Schiedsgericht entschieden, dass Respondents Notfallmaßnahmen nicht zu einem Verlust der des Antragstellers Eigentumsrecht oder Konzession zu betragen hat.
<G-vec00206-001-s132><amount.betragen><en> With respect to expropriation, the Arbitral Tribunal ruled that Respondent’s emergency measures did not amount to a loss of Claimant’s property right or concession.
<G-vec00206-002-s133><amount.betragen><de> Die Differenz zwischen beiden sollte beim Rotwein etwa zehn Grad betragen.
<G-vec00206-002-s133><amount.betragen><en> The difference between both of them, should amount to about ten degrees, with red wine.
<G-vec00206-002-s134><amount.betragen><de> Die Kosten für Schüler der weiterführenden Schulen betragen 250 € jährlich.
<G-vec00206-002-s134><amount.betragen><en> The costs for pupils of the secondary schools amount to 250 € per year.
<G-vec00206-002-s135><amount.betragen><de> Diese Inkassokosten betragen maximal: 15% für offene Beträge bis EUR 2.500; 10% auf die darauf folgenden EUR 2.500; und 5% auf die folgenden EUR 5.000 bei einem Minimum von EUR 40,-.
<G-vec00206-002-s135><amount.betragen><en> These collection costs amount to no more than: 15% for outstanding amounts up to EUR 2,500.00; 10% for the following EUR 2,500.00; and 5% for the following EUR 5,000.00, with a minimum of EUR 40.00.
<G-vec00206-002-s136><amount.betragen><de> Wenn Sie eine internationale persönliche Zahlung mithilfe Ihres PayPal-Guthabens oder Bankkontos überweisen oder empfangen, berechnet PayPal eine Auslandsgebühr, die zwischen 0,5 % und 2 % des Zahlungsbetrags betragen kann.
<G-vec00206-002-s136><amount.betragen><en> If you send or receive an international personal payment using your PayPal balance or bank account, PayPal will charge a cross border fee, which can range from 0.5% to 2% of the payment amount.
<G-vec00206-002-s137><amount.betragen><de> Politiker und Wirtschaftsexperten fragen, ob der Aufschwung 1.3, 2.0 oder 0.9 Prozent betragen wird, doch Unternehmen aller Art und aller Größen vergeuden das Vielfache davon.
<G-vec00206-002-s137><amount.betragen><en> Politicians and economy experts are asking the question whether the economic upswing will amount to 1,3 or 2,0 or 0,9 percent, but companies of all kind and all sizes are wasting a multiple of that.
<G-vec00206-002-s138><amount.betragen><de> 100 PLN betragen einen Stempel.
<G-vec00206-002-s138><amount.betragen><en> 100 PLN amount to one stamp.
<G-vec00206-002-s139><amount.betragen><de> (4) Die Versandkosten betragen 3,99 Euro.
<G-vec00206-002-s139><amount.betragen><en> (4) The shipping costs amount to 3,99 Euro.
<G-vec00206-002-s140><amount.betragen><de> Das Gesamtinvestitionsvolumen inklusive der projektbezogenen Fremdfinanzierung wird rund 19 Millionen Euro betragen.
<G-vec00206-002-s140><amount.betragen><en> The total investment including project-related debt financing will amount to approximately EUR 19 million.
<G-vec00206-002-s141><amount.betragen><de> Diese Inkasso-Kosten betragen maximal: 15% von noch nicht beglichenen Beträgen bis € 2.500,- 10% über die nachfolgenden € 2.500,- und 5% über die nachfolgenden € 5.000,- mit einem Minimum von € 40,-.
<G-vec00206-002-s141><amount.betragen><en> These collection costs amount to a maximum of: 15% over outstanding amounts up to € 2,500, =; 10% over the next € 2,500, = and 5% over the next € 5,000, = with a minimum of € 40, =.
<G-vec00206-002-s142><amount.betragen><de> Der Feststoffgehalt des Fördermediums kann bis weit über 50 % betragen.
<G-vec00206-002-s142><amount.betragen><en> The solid content of the feeding medium may amount to far above 50 %.
<G-vec00206-002-s143><amount.betragen><de> 2) Der Wert der im Online-Shop AGDhome.pl gekauften Waren muss bei einem einmaligen Kaufvorgang mindestens 300,00 Zloty brutto betragen.
<G-vec00206-002-s143><amount.betragen><en> 2) The value of purchases made in the online store AGDhome.pl, has to be 300.00 PLN, gross amount
<G-vec00206-002-s144><amount.betragen><de> Die Kosten für einen Hund betragen auf einem Camping-Stellplatz € 5,-- pro Nacht und in einem Ferienhaus € 40,-- pro Urlaubsperiode (Wochenende, Kurzwoche oder ganze Woche).
<G-vec00206-002-s144><amount.betragen><en> The costs for a dog at a campsite amount to €5 per night, and up to €40 per period (weekend, midweek or week) in one of our holiday homes.
<G-vec00206-002-s145><amount.betragen><de> Die Abmessungen der Uhr betragen 30 x 30 cm.
<G-vec00206-002-s145><amount.betragen><en> The dimensions of the clock amount to 30 x 30 cm.
<G-vec00206-002-s146><amount.betragen><de> Diese Inkassokosten betragen maximal: 15% über den ausstehenden Betrag bis zu € 2.500, =; 10% über die nächsten € 2.500, = und 5% über die nächsten € 5.000, = mit einem Minimum von € 40, =.
<G-vec00206-002-s146><amount.betragen><en> These collection fees amount to a maximum of: 15% over any outstanding amounts up to € 2,500.=; 10% over the following € 2,500.= and 5% over the following € 5,000.= with a minimum of € 40.=.
<G-vec00206-002-s147><amount.betragen><de> Das reduzierte EBITDA wirkt sich auch in voller Höhe auf den Free Cashflow aus, der somit nun mindestens 6 Millionen Euro betragen wird.
<G-vec00206-002-s147><amount.betragen><en> The full amount of the lower EBITDA will impact free cash flow, which will now thus amount to at least € 6 million.
<G-vec00206-002-s148><amount.betragen><de> Diese Inkassokosten betragen maximal 15 % für ausstehende Beträge bis zu 2.500,00 €, 10 % für die darauf folgenden 2.500,00 € und 5 % für alle hierauf folgenden Beträge, mindestens jedoch 40,00 €.
<G-vec00206-002-s148><amount.betragen><en> These collection costs amount to a maximum of: 15% on outstanding amounts up to € 2,500; 10% on the subsequent € 2,500 and 5% on the next € 5,000, = with a minimum of € 40.
<G-vec00206-002-s149><amount.betragen><de> Die Baukosten betragen 120 Millionen Schweizer Franken und der Betriebsfonds wird 50 Millionen Schweizer Franken umfassen und allfällige Betriebsdefizite, Unterhalt und Erneuerungen decken.
<G-vec00206-002-s149><amount.betragen><en> Construction costs amount to 120 million Swiss francs. The operating fund of 50 million Swiss francs is intended to cover possible operating losses, maintenance and refurbishment costs.
<G-vec00206-002-s150><amount.betragen><de> Die Kosten für den Aufbau eines Datenzentrums betragen auch mehrere tausend Euro pro Quadratmeter, bei einer Anmietung fallen die Kosten für Nutzung und Verwaltung geringer aus.
<G-vec00206-002-s150><amount.betragen><en> The costs of constructing a data centre can amount to thousands of euros per square meter; whereas, the costs of rental include both lower utility and management costs.
<G-vec00206-002-s151><amount.betragen><de> „d) Bei Verstößen nach Anhang III Abschnitt II Nummern 1, 6, 7, 8 und 9 betragen die Geldbußen mindestens 50 000 EUR und nicht mehr als 150 000 EUR.
<G-vec00206-002-s151><amount.betragen><en> for the infringements referred to in points 1, 6, 7, 8 and 9 of Section II of Annex III, the fines shall amount to at least EUR 50 000 and shall not exceed EUR 150 000;
<G-vec00206-002-s084><approximate.betragen><de> Für mich, die ich selbst digitalisiere und mit meiner Maschine sticke, betragen die Kosten ~$30 für Stickvlies, Filz und Stickgarn.
<G-vec00206-002-s084><approximate.betragen><en> Approximate costs for me (I have an embroidery machine AND have already digitized the embroideries!): $30 in stabilizers and embroidery thread.
<G-vec00206-002-s085><approximate.betragen><de> Mehr über Ferienwohnung in Südfrankreich Reiseangebote in Südfrankreich Ein möglichst genaues Abreisedatum wird benötigt, um eine geeignete Wohnung finden zu können Ein möglichst genaues Anreisedatum wird benötigt, um eine geeignete Wohnung finden zu können Ungültiges Buchungsdatum Die Dauer des Aufenthaltes sollte mindestens 2 Nächte betragen Die Dauer des Aufenthaltes sollte mindestens 28 Nächte betragenBitte füllen Sie die hervorgehobenen Felder aus Buchung max.
<G-vec00206-002-s085><approximate.betragen><en> South of France B&B Deals We need an ending date in order to search the right apartments, even if approximate We need a starting date in order to search the right apartments, even if approximate Invalid booking dates The length of stay should be 2 nights minimum The length of stay should be 28 nights minimumPlease complete the highlighted fields below No booking more than 3 years ahead
<G-vec00206-002-s086><approximate.betragen><de> Angebote in Südfrankreich Ein möglichst genaues Abreisedatum wird benötigt, um eine geeignete Wohnung finden zu können Ein möglichst genaues Anreisedatum wird benötigt, um eine geeignete Wohnung finden zu können Ungültiges Buchungsdatum Die Dauer des Aufenthaltes sollte mindestens 2 Nächte betragen Die Dauer des Aufenthaltes sollte mindestens 28 Nächte betragenBitte füllen Sie die hervorgehobenen Felder aus Buchung max.
<G-vec00206-002-s086><approximate.betragen><en> We need an ending date in order to search the right apartments, even if approximate We need a starting date in order to search the right apartments, even if approximate Invalid booking dates The length of stay should be 1 night minimum The length of stay should be 28 nights minimumPlease complete the highlighted fields below No booking more than 3 years ahead
<G-vec00206-002-s087><approximate.betragen><de> Mehr über Bed and Breakfast in Südfrankreich B&B Rabatte in Südfrankreich Ein möglichst genaues Abreisedatum wird benötigt, um eine geeignete Wohnung finden zu können Ein möglichst genaues Anreisedatum wird benötigt, um eine geeignete Wohnung finden zu können Ungültiges Buchungsdatum Die Dauer des Aufenthaltes sollte mindestens 2 Nächte betragen Die Dauer des Aufenthaltes sollte mindestens 28 Nächte betragenBitte füllen Sie die hervorgehobenen Felder aus Buchung max.
<G-vec00206-002-s087><approximate.betragen><en> Info: South of France Bed & Breakfast South of France B&B Deals We need an ending date in order to search the right apartments, even if approximate We need a starting date in order to search the right apartments, even if approximate Invalid booking dates The length of stay should be 2 nights minimum The length of stay should be 28 nights minimumPlease complete the highlighted fields below No booking more than 3 years ahead
<G-vec00206-002-s088><approximate.betragen><de> Im Todesfall sollte diese Vorauszahlung mindestens 16.000 SDR betragen.
<G-vec00206-002-s088><approximate.betragen><en> In the event of death, this advance payment shall not be less than 16 000 SDRs (approximate amount in local currency).
<G-vec00356-002-s066><counterbalance.betragen><de> HINWEIS: Bei Gegengewicht-Staplern muss die Nennkapazität des Gabelstaplers 1800 kg oder das Fünffache des Gesamtgewichts des Arbeitskorbes und der Arbeiter sowie aller Werkzeuge und Materialien betragen.
<G-vec00356-002-s066><counterbalance.betragen><en> Note: For counterbalance forklifts, the rated capacity of the forklift must be 1800 kg or 5 times the total weight of the work cage, plus workers, plus tools and other materials.
