<G-vec00081-001-s045><suspend.aufheben><de> Die Arbeiterklasse muss demokratische Freiheiten in der kapitalistischen Gesellschaft gegen alle Versuche, sie zu beschneiden oder aufzuheben, verteidigen.
<G-vec00081-001-s045><suspend.aufheben><en> The working class must defend democratic liberties in capitalist society against all attempts to curtail or suspend them.
<G-vec00081-001-s046><suspend.aufheben><de> Wenn Sie die fälligen Zahlungen für kostenpflichtige Services nicht termingerecht leisten, behalten wir uns das Recht vor, Ihren Zugang zu den kostenpflichtigen Services aufzuheben oder zu widerrufen.
<G-vec00081-001-s046><suspend.aufheben><en> If you don't pay for Paid Services on time, we reserve the right to suspend or cancel your access to the Paid Services.
<G-vec00081-001-s047><suspend.aufheben><de> Und dass keine Institution außer Gott die Macht hat, diese Rechte aufzuheben oder außer Kraft zu setzen, sei es in offener oder verdeckter Weise.
<G-vec00081-001-s047><suspend.aufheben><en> And that no agency less than God has the power to suspend or set aside these rights, overtly or covertly.
<G-vec00081-001-s048><suspend.aufheben><de> Die British American Tobacco Switzerland SA behält sich das Recht vor, die gesamte Website oder Teile dieser jederzeit und ohne Vorankündigung weiterzuentwickeln, zu modifizieren, abzuändern, aufzuheben oder dauerhaft einzustellen sowie den Zugriff auf diese einzuschränken oder zu untersagen.
<G-vec00081-001-s048><suspend.aufheben><en> British American Tobacco Trading EOOD reserves the right at any time and without notice to enhance, modify, alter, suspend or permanently discontinue all or any part of this website and to restrict or prohibit access to it.
<G-vec00081-001-s049><suspend.aufheben><de> 116: Die Kommission empfiehlt den Mitgliedstaaten und regionalen Organisationen, insbesondere der Liga der Arabischen Staaten: (a) Unterstützung der Bemühungen, um die Bevölkerung der Arabischen Republik Syrien zu schützen und ein sofortiges Ende der schweren Menschenrechtsverletzungen zu bringen - sowie die Lieferung von Waffen und anderes militärisches Material an alle Parteien aufzuheben.
<G-vec00081-001-s049><suspend.aufheben><en> 116: The commission recommends that Member States and regional organizations, particularly the League of Arab States: (a) Support efforts to protect the population of the Syrian Arab Republic and to bring an immediate end to gross human rights violations, and suspend the provision of arms and other military material to all parties; *
<G-vec00081-001-s050><suspend.aufheben><de> "Die äthiopische Regierung wirft nun den Bloggern von Zone 9 vor, diese Instrumente eingesetzt zu haben, um ""die staatliche Verfassung zu stürzen, anzupassen oder aufzuheben, mittels Gewalt, Bedrohung oder Verschwörung""."
<G-vec00081-001-s050><suspend.aufheben><en> "The Ethiopian government accuses the Zone 9 bloggers of using these tools in an attempt to ""overthrow, modify or suspend the Federal or State Constitution; or by violence, threats, or conspiracy."""
<G-vec00081-001-s051><suspend.aufheben><de> Strategic essentialism ist der Beweis dafür, dass es keine Möglichkeit gibt, diese zwei Sprachen aufeinander zurückzuführen oder sie in einer anderen, universalen Sprache dialektisch aufzuheben.
<G-vec00081-001-s051><suspend.aufheben><en> Strategic essentialism is proof that there is no way to relate these two languages back to one another or to suspend them in another, universal language.
<G-vec00081-001-s052><suspend.aufheben><de> Der Staat will aber die Entwertung seiner Valuta hindern; dazu braucht er nur die freie Silberprägung aufzuheben.
<G-vec00081-001-s052><suspend.aufheben><en> If the state wishes to prevent any further depreciation of its currency it need only suspend the free coinage of silver.
<G-vec00279-002-s019><override.aufheben><de> Falls dennoch nötig, sorgt eine spezielle Rutschkupplung im Zylinder dafür, dass Lehrer und Hausmeister die Knauffunktion jederzeit per Schlüssel aufheben und die Tür problemlos von außen öffnen können.
<G-vec00279-002-s019><override.aufheben><en> But if necessary, teachers or the caretaker can always override the knob function with the key thanks to a slip clutch inside the cylinder so that they can easily open the door from the outside.
<G-vec00279-002-s020><override.aufheben><de> Deshalb sind wir der Auffassung, dass unsere Interessen berechtigt sind und gleichzeitig nicht die Rechte oder Freiheiten unserer Benutzer oder Kunden verletzen, welche diese aufheben können.
<G-vec00279-002-s020><override.aufheben><en> That’s why we decided that our interests are justified, legitimate, and at the same time, they don’t violate the rights or freedoms of our Users or Customers, which may override them.
<G-vec00279-002-s021><override.aufheben><de> Historisch-kritische Methode sowie Multiperspektivität und Kontroversität der Darstellung können diesen Umstand sehr entschärfen, aber aufgrund der Deutungsmacht über die Auswahl (Selektivität) nicht aufheben.
<G-vec00279-002-s021><override.aufheben><en> The historical-critical method as well as multi-perspective and controversial portrayal can defuse this circumstance, but not override it, because of the interpretative power over the selection (selectivity).
<G-vec00279-002-s022><override.aufheben><de> Aktivieren Sie "Automatische Cookiebehandlung aufheben".
<G-vec00279-002-s022><override.aufheben><en> Check the box for "Override automatic cookie handling"
<G-vec00298-002-s057><lift.aufheben><de> Bevor wir die Einschränkung aufheben, haben wir die Pflicht, Sie darüber zu unterrichten.
<G-vec00298-002-s057><lift.aufheben><en> We have a duty to inform you before we lift the restriction.
<G-vec00298-002-s058><lift.aufheben><de> 3:41 Laßt uns unser Herz samt den Händen aufheben zu Gott im Himmel.
<G-vec00298-002-s058><lift.aufheben><en> 3:41 Nun. Let us lift up our hearts with our hands to the Lord in the heavens.
<G-vec00298-002-s059><lift.aufheben><de> Israel muss seinen kriminellen Krieg und das Gemetzel an unserem Volk beenden, die illegale Blockade des Gazastreifens vollständig und bedingungslos aufheben, all unsere Grenzübergänge öffnen und sich vollständig aus Gaza zurückziehen.
<G-vec00298-002-s059><lift.aufheben><en> Israel must end its criminal war and slaughter of our people, lift completely and unconditionally its illegal siege of the Gaza Strip, open all our border crossings and completely withdraw from Gaza.
<G-vec00298-002-s060><lift.aufheben><de> Liegt das LG G2 mit dem Display nach oben, muss man das Gerät nicht mehr extra aufheben, um es anzuschalten.
<G-vec00298-002-s060><lift.aufheben><en> And if the LG G2 is lying on a surface face up, there’s no need to lift the phone to press the power button on the back.
<G-vec00298-002-s061><lift.aufheben><de> 25 Dann wirst du deine Lust haben an dem Allmächtigen und dein Antlitz zu Gott aufheben.
<G-vec00298-002-s061><lift.aufheben><en> Tools 26 "For then you will delight in the Almighty And lift up your face to God.
<G-vec00298-002-s062><lift.aufheben><de> 4Also werde ich dich preisen während meines Lebens, meine Hände aufheben in deinem Namen.
<G-vec00298-002-s062><lift.aufheben><en> 4 So will I bless You while I live; I will lift up my hands in Your name.
<G-vec00298-002-s063><lift.aufheben><de> Die Dinge, die die Menschen tragen, sind für die Leser zugänglich, da wir alle Dinge mit uns im Leben tragen, die uns aufheben oder uns herunterziehen.
<G-vec00298-002-s063><lift.aufheben><en> The things the men carry are relatable to the readers, as we all carry things with us in life that lift us up, or drag us down.
<G-vec00298-002-s064><lift.aufheben><de> Es war ihm wohl bewusst, und so erklärte er es, dass die Vereinigten Staaten ihrerseits die Zollschranken und Subventionen aufheben müssten, die die Ausfuhr des Äthanols in die Vereinigten Staaten behindern.
<G-vec00298-002-s064><lift.aufheben><en> He was well aware -and he said it– that the United States should in turn lift the custom tariffs and the subsidies affecting ethanol exports to that country.
<G-vec00298-002-s065><lift.aufheben><de> Im selben Menü können Sie die Einschränkung auch wieder aufheben.
<G-vec00298-002-s065><lift.aufheben><en> You can request to lift the restriction using the same 'Tools' menu.
<G-vec00298-002-s066><lift.aufheben><de> Drieteilige Cups, die die Brust aufheben.
<G-vec00298-002-s066><lift.aufheben><en> Three-section cups that firmly lift your breasts.
<G-vec00298-002-s067><lift.aufheben><de> Zudem wollte Frankreich Ende des Monats den Ausnahmezustand aufheben.
<G-vec00298-002-s067><lift.aufheben><en> France was getting ready to lift the state of emergency at the end of the month.
<G-vec00298-002-s068><lift.aufheben><de> Die Türkei müsse ferner die Einschränkungen des freien Warenverkehrs bei bestimmten Verkehrsmitteln aufheben.
<G-vec00298-002-s068><lift.aufheben><en> Lastly, Turkey needed to lift restrictions on the free circulation of goods affecting certain means of transport.
<G-vec00298-002-s069><lift.aufheben><de> Falls Ihr Konto gesperrt wurde, können Sie die Sperre aufheben, indem Sie die erforderliche Zahlung vornehmen, um Ihren Zahlungsrückstand auszugleichen.
<G-vec00298-002-s069><lift.aufheben><en> If your account is suspended, you can lift your suspension by making a manual payment.
<G-vec00298-002-s070><lift.aufheben><de> Ich bin kein Experte für internationale Politik, aber wir hoffen natürlich, dass wir beziehungsweise die russische Regierung das Embargo aufheben können.
<G-vec00298-002-s070><lift.aufheben><en> I’m not an expert on international politics, but we certainly hope that we would be able to lift the Russian embargo, or the Russian federal government would lift them.
<G-vec00298-002-s071><lift.aufheben><de> + mehr Überblick: Ein Bruststraffungsverfahren, auch Mastopexie genannt, ist ein chirurgischer Eingriff, der zum Aufheben und Anziehen von abfallenden Brüsten (auch Brustptose genannt) eingesetzt wird.
<G-vec00298-002-s071><lift.aufheben><en> + More Overview: A breast lift procedure, also referred to as a mastopexy, is a surgical procedure used to lift and tighten sagging breasts (also called breast ptosis).
<G-vec00298-002-s072><lift.aufheben><de> Musik kann Menschen Energie geben, aufheben, rühren, trösten, heilen und tief beglücken.
<G-vec00298-002-s072><lift.aufheben><en> Music can give you energy, lift you up, move you, comfort you and make you immensely happy.
<G-vec00298-002-s073><lift.aufheben><de> Doch der Mensch stolpert laufend in dieser Welt und so muss er laufend zu Mir kommen… Und auch siebzig mal sieben mal werde Ich ihn reinigen und aufheben.
<G-vec00298-002-s073><lift.aufheben><en> Yet man does continually stumble in this world, and so he must continually come to Me… And even seventy times seven times shall I cleanse him and lift him up.
<G-vec00298-002-s074><lift.aufheben><de> 4 Daselbst wollte ich dich gerne loben mein Leben lang und meine Hände in deinem Namen aufheben.
<G-vec00298-002-s074><lift.aufheben><en> 4 Thus I will bless You while I live; I will lift up my hands in Your name.
<G-vec00298-002-s075><lift.aufheben><de> Auch möchte er Obamas Beschränkungen für Offshore-Öl- und Gasbohrungen aufheben.
<G-vec00298-002-s075><lift.aufheben><en> He also wants to lift the constraints Obama placed on offshore oil and gas drilling.
<G-vec00356-002-s022><neutralize.aufheben><de> Da die meisten Waschmittel alkalisch sind und den eben beschriebenen Effekt aufheben, sollte man mit speziellen Wollwaschmitteln oder Shampoo waschen, am besten mit der Hand.
<G-vec00356-002-s022><neutralize.aufheben><en> Most washing detergents are alkaline and neutralize the above mentioned effect, hence you should wash Hirsch wool socks with wool detergents or shampoo, and if possible by hand
<G-vec00376-002-s044><discontinue.aufheben><de> Ist die Verbindung erfolgreich, wird das Fenster sich neu öffnen und der Name des Kontos und der beauftragten Person wird angezeigt; deren Hausanschrift, - Adresse, Mobiltelefonnummer, Vertragsschlüssel und das Datum der Delegationsvergabe, siehe Abbildung 5-20 auf Seite ABBILDUNG Remote-Verwaltung: Delegierte Kontenverwaltung Sie können die Delegation jederzeit aufheben.
<G-vec00376-002-s044><discontinue.aufheben><en> If the connection is successful, the screen will reload showing the name of the account and the designee, that person s street address, address, mobile telephone number, the contract key, and the date that the delegation began, as shown in figure 5-20 on page FIGURE Remote management: account management delegated You can discontinue the delegation at any time by clicking Discontinue on this screen.
<G-vec00376-002-s045><discontinue.aufheben><de> A. Campayn kann den Einsatz jeglicher Dienstleistung, Produkte oder Teile der Campayn Webseite jederzeit und ohne Ankündigung oder Haftungsübernahme ändern, auszusetzen, aufheben oder beschränken, einschließlich der Verfügbarkeit von jeglichem Inhalten oder Teilen davon.
<G-vec00376-002-s045><discontinue.aufheben><en> A. Campayn may modify, suspend, discontinue or restrict the use of any Service, product or portion of the Campayn website, including the availability of any portion of the content at any time, without notice or liability.
