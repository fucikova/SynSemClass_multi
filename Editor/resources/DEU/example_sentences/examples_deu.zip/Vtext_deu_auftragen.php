<G-vec00272-001-s171><apply.auftragen><de> Schrauben reinigen, GLEITMO 165 mit Pinsel bis auf den Gewindegrund und auf der Auflagefläche des Schraubenkopfes ohne Überschuss auftragen oder aufsprühen.
<G-vec00272-001-s171><apply.auftragen><en> Clean the screws, apply GLEITMO 165 to the thread root and the contact surface of the screw head without excess using a paint brush or spray on.
<G-vec00272-001-s172><apply.auftragen><de> Strobing Powder mit dem Eye Shadow Brush large auftragen und verblenden.
<G-vec00272-001-s172><apply.auftragen><en> Apply Strobing Powder using the Eye Shadow Brush large and blend in.
<G-vec00272-001-s173><apply.auftragen><de> Anwendung: Großzügig auf sauberes, feuchtes Haar von den Wurzeln bis zu den Spitzen auftragen, einmassieren und 3 bis 5 Minuten einwirken lassen.
<G-vec00272-001-s173><apply.auftragen><en> Use: Apply generously to clean, wet hair from roots to ends, massage in and leave for 3 to 5 minutes.
<G-vec00272-001-s174><apply.auftragen><de> Das Nude Illusion Make Up dünn auftragen und mit der Camouflage Cream verblenden.
<G-vec00272-001-s174><apply.auftragen><en> Apply a thin layer of the Nude Illusion Make Up and blend with the Camouflage Cream.
<G-vec00272-001-s175><apply.auftragen><de> Keiki initiation ist höher: wenn Sie KEIKIBOOST eine Woche nach den Verlust der letzten Blüte auftragen, tragen Sie KEIKIBOOST auf den ersten Knoten auf, im falle das Sie neue Blüten möchten tragen Sie KEIKIBOOST auf den höhern Knoten auf.
<G-vec00272-001-s175><apply.auftragen><en> Keiki initiation will be better if: you apply KEIKIBOOST one week at least after the last flower fell, apply KEIKI on the lower nodes only or if you want to higher your chance for a flower spike, then apply KEIKIBOOST to the upper nodes.
<G-vec00272-001-s176><apply.auftragen><de> Zur Behandlung verschiedener Beschwerden die Blätter der Kultur auftragen, die vor Gebrauch kneten oder daraus Saft herstellen.
<G-vec00272-001-s176><apply.auftragen><en> To treat various ailments apply the leaves of the culture, which knead before use or make from them juice.
<G-vec00272-001-s177><apply.auftragen><de> Großzügig auf die gereinigte, gepeelte Haut auftragen.
<G-vec00272-001-s177><apply.auftragen><en> Apply generously to clean, exfoliated skin.
<G-vec00272-001-s178><apply.auftragen><de> Unterhaltsreinigung: Konzentrat 1:50 (200 ml auf 10 Liter) verdünnen und auftragen.
<G-vec00272-001-s178><apply.auftragen><en> Maintenance cleaning: dilute concentrate 1:50 (200 ml to 10 liters) and apply.
<G-vec00272-001-s179><apply.auftragen><de> Mehrmals täglich auf die Hände auftragen und sanft einmassieren.
<G-vec00272-001-s179><apply.auftragen><en> Apply several times a day to hands and gently massage in.
<G-vec00272-001-s180><apply.auftragen><de> Bei stark verschmutzten Teilen und Oberflächen: Konzentriertes Produkt mit einer weichen Bürste oder einem Sprühgerät auftragen.
<G-vec00272-001-s180><apply.auftragen><en> For heavily soiled parts and surfaces: Apply concentrated product with a soft brush or spray.
<G-vec00272-001-s181><apply.auftragen><de> Wichtig: Erst das Gesicht abpudern und danach den Cream To Powder Blush als farbliches Highlight auftragen.
<G-vec00272-001-s181><apply.auftragen><en> It's important to powder the face first and then apply the Cream to Powder Blush as a colour highlight.
<G-vec00272-001-s182><apply.auftragen><de> Haut auftragen und Massage unitl Öl wird vollständig resorbiert.
<G-vec00272-001-s182><apply.auftragen><en> Apply to skin and massage unitl oil is completely absorbed.
<G-vec00272-001-s183><apply.auftragen><de> Extrahiert aus der Schale von Cashew-Nüssen Öl auftragen.
<G-vec00272-001-s183><apply.auftragen><en> Apply oil extracted from the shell of the cashew nuts.
<G-vec00272-001-s184><apply.auftragen><de> Für sofortiges Strahlen und Glanz eine dicke Schicht der Resurfacing Mask auf das gereinigte Gesicht auftragen.
<G-vec00272-001-s184><apply.auftragen><en> For immediate glow, apply a thick layer of the Resurfacing Mask on a clean face.
<G-vec00272-001-s185><apply.auftragen><de> Großzügig auf nasse Schuhe auftragen; Spray (aus einer Entfernung von 5cm) oder Schwammapplikator.
<G-vec00272-001-s185><apply.auftragen><en> Apply generously to wet footwear; Spray-On (from a distance of 5cm) or Sponge-On.
<G-vec00272-001-s186><apply.auftragen><de> Morgens lokal auf die entzündlichen Partien auftragen.
<G-vec00272-001-s186><apply.auftragen><en> In the morning apply locally on the inflammatory areas.
<G-vec00272-001-s187><apply.auftragen><de> Um die Prozedur zu erleichtern, kann sich Ihnen der Helfer benötigen, der das Paraffin auftragen wird.
<G-vec00272-001-s187><apply.auftragen><en> To facilitate procedure, the assistant who will apply paraffin can be necessary for you.
<G-vec00272-001-s188><apply.auftragen><de> Auf das Gesicht mit einer Quaste oder einem Pinsel auftragen.
<G-vec00272-001-s188><apply.auftragen><en> Apply onto the face with a puff or powder brush.
<G-vec00272-001-s189><apply.auftragen><de> Die Klebstoffauftrags- und Schmelzklebstoffsysteme von Nordson dienen zum Auftragen von Klebstoffen, Dichtstoffen und Beschichtungen in verschiedensten Formen für Verbraucher- und Industrieprodukte bei Verpackungen, Anwendungen in der Produktmontage und Vliesstoffen.
<G-vec00272-001-s189><apply.auftragen><en> Nordson hot melt machines and adhesive dispensing systems apply adhesives, sealants and coatings in a variety of patterns to consumer and industrial products in packaging, product assembly and nonwoven applications.
<G-vec00272-001-s190><apply.auftragen><de> Um ein anständiges Ergebnis zu erzielen, reicht es aus, diese Mischung jeden Monat jeden Tag auf Ihr Gesicht aufzutragen.
<G-vec00272-001-s190><apply.auftragen><en> To get a decent result, it is enough to apply this mixture on your face every day for a month.
<G-vec00272-001-s191><apply.auftragen><de> Die hervorragende Qualität der Wachse verwendet diese Stifte einfach aufzutragen und perfekt für alle Färbung-Techniken sind, einschließlich der Graffiti macht.
<G-vec00272-001-s191><apply.auftragen><en> The excellent quality of waxes used makes these crayons are easy to apply and perfect for all coloring techniques, including the graffiti.
<G-vec00272-001-s192><apply.auftragen><de> Es stellt eine spezielle und zugleich besonders noble Art dar, Parfum aufzutragen: Mit dem geschmeidigen Kabuki-Pinsel wird die Haut mit zart duftendem Parfum-Puder bestäubt.
<G-vec00272-001-s192><apply.auftragen><en> It is a very special and very noble way to apply perfume: with the Kabuki brush, you can apply deliciously scented perfume powder to your skin.
<G-vec00272-001-s193><apply.auftragen><de> Vor der Abgabe von der flüssigen schwarzen Schokolade, auf die weiße Oberfläche die Zeichnung aufzutragen.
<G-vec00272-001-s193><apply.auftragen><en> Before giving by liquid dark chocolate to apply drawing on a white surface.
<G-vec00272-001-s194><apply.auftragen><de> Es reicht aus, den Pavillon zunächst wie eine Mundharmonika seitwärts zu strecken, das Material aufzutragen und dann die Ecken nach oben zu ziehen, bis das Schloss einrastet.
<G-vec00272-001-s194><apply.auftragen><en> "It is enough to first stretch the pavilion sideways like a harmonica, apply the material, and then pull up the corners upwards until it ""clicks"" the lock."
<G-vec00272-001-s195><apply.auftragen><de> Zahnspachtel werden eingesetzt, um Klebstoffe und Leime bei großflächigen Verklebungen aufzutragen.
<G-vec00272-001-s195><apply.auftragen><en> Serrated scrapers are used to apply adhesives and paste glues to large areas when doing bonding work.
<G-vec00272-001-s196><apply.auftragen><de> Im Allgemeinen brauchst du die Spülung nicht weiter als bis zur Hälfte der Haarlänge aufzutragen, es sei denn, dein Haar ist auch nahe der Kopfhaut merklich trocken.
<G-vec00272-001-s196><apply.auftragen><en> Generally, you won't need to apply conditioner higher than halfway up the length of your hair unless hair is noticeably dry near your scalp.
<G-vec00272-001-s197><apply.auftragen><de> Achtet deshalb darauf, ihn nicht flächig, sondern nur punktuell oder in (Wellen-)Linien aufzutragen.
<G-vec00272-001-s197><apply.auftragen><en> Therefore, be careful not to apply it over a wide area, but only selectively or in (wave) lines.
<G-vec00272-001-s198><apply.auftragen><de> Am meisten ist es leichter, den Leim schpatelem aufzutragen.
<G-vec00272-001-s198><apply.auftragen><en> It is easiest to apply glue with the pallet.
<G-vec00272-001-s199><apply.auftragen><de> 1000 Möglichkeiten, .Parfüm aufzutragen...
<G-vec00272-001-s199><apply.auftragen><en> Technical Sheet 1,000 ways to apply fragrance...
<G-vec00272-001-s200><apply.auftragen><de> Bei schwach deckenden Farbtönen kann es nach entsprechender Ablüftzeit (matt abgezogen) notwendig sein, weitere Spritzgänge aufzutragen.
<G-vec00272-001-s200><apply.auftragen><en> When using barely opaque colour tones, after a corresponding flash time (matt stripped) it might be necessary to apply additional paint processes.
<G-vec00272-001-s201><apply.auftragen><de> Hitzebeständigkeit Edelstahl 316 hat eine gute Oxidationsbeständigkeit bei intermittierender Verwendung unter 1600 ° C und kontinuierlicher Verwendung unter 1700 ° C. Im Bereich von 800 bis 1575 Grad ist es bevorzugt, 316-Edelstahl nicht kontinuierlich aufzutragen, aber wenn 316-Edelstahl kontinuierlich außerhalb dieses Temperaturbereichs verwendet wird, weist der Edelstahl eine gute Wärmebeständigkeit auf.
<G-vec00272-001-s201><apply.auftragen><en> Heat resistance 316 stainless steel has good oxidation resistance in intermittent use below 1600 °C and continuous use below 1700 °C. In the range of 800-1575 degrees, it is preferable not to continuously apply 316 stainless steel, but when 316 stainless steel is continuously used outside this temperature range, the stainless steel has good heat resistance.
<G-vec00272-001-s202><apply.auftragen><de> Es ist zulässig, einmal Ginseng oder Eleutherococcus Tinktur vor der Ankunft des Arztes aufzutragen.
<G-vec00272-001-s202><apply.auftragen><en> It is permissible to apply tincture of ginseng or eleutherococcus once before the arrival of the doctor.
<G-vec00272-001-s203><apply.auftragen><de> Nach dem Austrocknen des Leims genug einfach akkurat, die Schneeflocke vom Papier abzutrennen, auf sie den Leim mit Hilfe des kleinen Pinsels aufzutragen und, blestkami zu bestreuen.
<G-vec00272-001-s203><apply.auftragen><en> After drying of glue rather simply accurately to separate a snowflake from paper, to apply on it glue by means of a brush and to strew with spangles.
<G-vec00272-001-s204><apply.auftragen><de> Bei der äusserlichen Nutzung oblepichowogo die Öle muss man das beschädigte Grundstück der Haut reinigen, das Öl mit Hilfe der Pipette aufzutragen und, marlewuju die Binde aufzuerlegen.
<G-vec00272-001-s204><apply.auftragen><en> At external use of sea-buckthorn oil it is necessary to clear the damaged skin site, to apply oil by means of a pipette and to apply a gauze bandage.
<G-vec00272-001-s205><apply.auftragen><de> Die natürliche Farbe hält bis zu 24 Stunden und ist einfach aufzutragen.
<G-vec00272-001-s205><apply.auftragen><en> The natural colour lasts up to 24 hours and is easy to apply.
<G-vec00272-001-s206><apply.auftragen><de> Ballonzerstäuber garantiert ohne PVC Zahllose individualisierbare Optionen 1000 Möglichkeiten, .Parfüm aufzutragen...
<G-vec00272-001-s206><apply.auftragen><en> A bulb guaranteed to contain no PVC Countless customization options 1,000 ways to apply fragrance...
<G-vec00272-001-s207><apply.auftragen><de> Nun, um das Make-up aufzutragen, einfach eine kleine Menge von Make-up auf obere oder untere Oberfläche des beautyblender® oder direkt auf die Haut geben.
<G-vec00272-001-s207><apply.auftragen><en> Now to apply makeup, simply introduce a small amount of makeup onto beautyblender® top or bottom surface.
<G-vec00272-001-s208><apply.auftragen><de> Es gibt drei Haupt- Weisen der Festigung der Wimpern: die nahrhafte Mischung auf die Wimpern aufzutragen, auf die Haut Jahrhundert und ihre Massage zu machen.
<G-vec00272-001-s208><apply.auftragen><en> There are three main ways of strengthening of eyelashes: to apply nutritious mix on eyelashes, on skin of eyelids and to do their massage.
