<G-vec00296-002-s089><divide.austeilen><de> Denn du sollst diesem Volk das Land zum Erbe austeilen, das zu geben ich ihren Vätern geschworen habe.
<G-vec00296-002-s089><divide.austeilen><en> 6Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.
<G-vec00296-002-s090><divide.austeilen><de> 21 Also sollt ihr das Land austeilen unter die Stämme Israels.
<G-vec00296-002-s090><divide.austeilen><en> And ye shall divide this land unto you according to the tribes of Israel.
<G-vec00296-002-s091><divide.austeilen><de> Also sollt ihr das Land austeilen unter die Stämme Israels.
<G-vec00296-002-s091><divide.austeilen><en> So shall you divide this land to you according to the tribes of Israel.
<G-vec00296-002-s092><divide.austeilen><de> 47:14 Und ihr sollt's gleich austeilen, einem wie dem andern; denn ich habe meine Hand aufgehoben, das Land euren Vätern und euch zum Erbteil zu geben.
<G-vec00296-002-s092><divide.austeilen><en> 14 "You shall divide it for an inheritance, each one equally with the other; for I swore to give it to your forefathers, and this land shall fall to you as an inheritance.
<G-vec00296-002-s093><divide.austeilen><de> 13So spricht Gott, der HERR: Das ist die Grenze, innert welcher ihr den zwölf Stämmen Israels das Land zum Erbe austeilen sollt; dem Joseph gehören zwei Lose.
<G-vec00296-002-s093><divide.austeilen><en> 13: Thus says the Lord GOD: "These are the boundaries by which you shall divide the land for inheritance among the twelve tribes of Israel. Joseph shall have two portions.
<G-vec00296-002-s094><divide.austeilen><de> 34:17 Das sind die Namen der Männer, die euch das Land als Erbe austeilen sollen: der Priester Eleasar und Josua, der Sohn des Nun.
<G-vec00296-002-s094><divide.austeilen><en> 34:17 These are the names of the men that shall divide the land unto you for inheritance: Eleazar the priest, and Joshua the son of Nun.
<G-vec00296-002-s095><divide.austeilen><de> Das ist das Land, das ihr austeilen sollt zum Erbteil unter die Stämme Israels; und das sollen ihre Erbteile sein, spricht der HERR HERR.
<G-vec00296-002-s095><divide.austeilen><en> This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord Jehovah.
<G-vec00296-002-s096><divide.austeilen><de> Sei getrost und unverzagt; denn du sollst diesem Volk das Land austeilen, das ich ihren Vätern geschworen habe, daß ich's ihnen geben wollte.
<G-vec00296-002-s096><divide.austeilen><en> Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.
<G-vec00296-002-s097><divide.austeilen><de> Das ist das Land, das ihr austeilen sollt zum Erbteil unter die Staemme Israels; und das sollen ihre Erbteile sein, spricht der HERR HERR.
<G-vec00296-002-s097><divide.austeilen><en> This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord GOD.
<G-vec00296-002-s098><divide.austeilen><de> 13 So spricht der Herr HERR: Dies sind die Grenzen, nach denen ihr das Land sollt austeilen den zwölf Stämmen Israels; denn zwei Teile gehören dem Stamm Joseph.
<G-vec00296-002-s098><divide.austeilen><en> 47:13Thus saith the Lord Jehovah: This shall be the border, whereby ye shall divide the land for inheritance according to the twelve tribes of Israel: Joseph shall have two portions.
<G-vec00296-002-s099><divide.austeilen><de> 6 Sei getrost und unverzagt; denn du sollst diesem Volk das Land austeilen, das ich ihren Vätern geschworen habe, daß ich's ihnen geben wollte.
<G-vec00296-002-s099><divide.austeilen><en> 6 Be strong and 'quit thyself like a man, for thou shalt divide the land to this people, which I sware to give to † your fathers.
<G-vec00296-002-s100><divide.austeilen><de> 16 Wenn er Geld zusammenbringt wie Staub und sammelt Kleider wie Lehm, 17 so wird er es wohl bereiten; aber der Gerechte wird es anziehen, und der Unschuldige wird das Geld austeilen.
<G-vec00296-002-s100><divide.austeilen><en> 16 Though he heap up silver as the dust, and prepare clothing as the clay; 17 He may prepare it, but the just shall put it on; and the innocent shall divide the silver.
<G-vec00296-002-s101><divide.austeilen><de> 27Benjamin ist ein reißender Wolf; des Morgens wird er Raub fressen, aber des Abends wird er den Raub austeilen.
<G-vec00296-002-s101><divide.austeilen><en> Ben Iamin is a ravishing wolf. In the morning he shall devour his prey, and at night he shall divide his spoil.
<G-vec00296-002-s102><divide.austeilen><de> Und gebiete dem Josua, daß er getrost und unverzagt sei; denn er soll über den Jordan ziehen vor dem Volk her und soll ihnen das Land austeilen, das du sehen wirst.
<G-vec00296-002-s102><divide.austeilen><en> 28 Command Josue, and encourage and strengthen him: for he shall go before this people, and shall divide unto them the land which thou shalt see.
