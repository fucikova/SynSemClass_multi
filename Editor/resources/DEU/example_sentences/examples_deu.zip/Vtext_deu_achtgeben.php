<G-vec00540-002-s165><heed.achtgeben><de> Aber gebt Acht, denn eure Feinde werden euch vor ihre Behörden bringen, und in ihren Synagogen werden sie euch scharf kritisieren.
<G-vec00540-002-s165><heed.achtgeben><en> But take heed, for your enemies will bring you up before their councils, while in their synagogues they will castigate you.
