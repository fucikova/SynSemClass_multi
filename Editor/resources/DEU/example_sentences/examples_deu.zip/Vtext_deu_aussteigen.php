<G-vec00407-001-s069><fold.aussteigen><de> Ein weiterer Vorteil von Rush Poker ist der, dass Sie verschiedene Strategien ausprobieren und aussteigen können, bis Sie eine gute Hand haben.
<G-vec00407-001-s069><fold.aussteigen><en> Another advantage of Rush poker is that you can try out various strategies and fold until you have a good hand.
<G-vec00407-001-s070><fold.aussteigen><de> Nicht wenige mittelmäßige Hold em Poker-Spieler, speziell wenn sie sehr erst lernen, Wette auf, in der Regel werden nicht zulassen, eine negative Hand gehen, während ein sehr guter Pokerspieler weiß, wann er aussteigen.
<G-vec00407-001-s070><fold.aussteigen><en> Quite a few mediocre Holdem poker gamblers, especially when they very first learn to wager on, usually won’t let a bad hand go, whereas a good poker player knows when to fold.
<G-vec00407-001-s071><fold.aussteigen><de> aufpassen müssen Spieler, auf verdächtige Aktivitäten, oder eine von plötzliche erhöhen aussteigen ein paar und so weiter Spieler.
<G-vec00407-001-s071><fold.aussteigen><en> Players need to watch out for suspicious activity, a sudden raise or fold by a couple of players and so on.
<G-vec00407-001-s072><fold.aussteigen><de> Wenn Sie aussteigen, hat der nächste Spieler die gleichen Möglichkeiten.
<G-vec00407-001-s072><fold.aussteigen><en> If you fold, the next player has the same choices.
<G-vec00407-001-s073><fold.aussteigen><de> Ein schwacher-passive Spieler, der viel fordert, aber nicht erhöhen oder aussteigen viel.
<G-vec00407-001-s073><fold.aussteigen><en> A weak-passive player who calls a lot, but doesn't raise or fold much.
<G-vec00407-001-s074><fold.aussteigen><de> Der Gegner muss nur in etwas mehr als 1/3 der Fälle aussteigen, damit dieser Einsatz profitabel ist.
<G-vec00407-001-s074><fold.aussteigen><en> The opponent must fold only 1/3 times in order to make this play profitable.
<G-vec00407-001-s075><fold.aussteigen><de> Wenn Sie denken Ihre Hand ist nicht gut genug und Sie wollen aussteigen, klicken Sie diesen.
<G-vec00407-001-s075><fold.aussteigen><en> Fold If you feel your hand is not strong enough and you want to fold, click this.
