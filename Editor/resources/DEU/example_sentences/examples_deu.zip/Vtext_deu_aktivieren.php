<G-vec00012-001-s019><enable.aktivieren><de> Markieren Sie dieses Feld, um das SuchfeldFertigungsaufträgeim Suchfenster des Explorers zu aktivieren.
<G-vec00012-001-s019><enable.aktivieren><en> Check this option to enable the Work Orders search field in the Explorer Search Panel.
<G-vec00012-001-s020><enable.aktivieren><de> Aktivieren können Sie diese Teilen-Schaltflächen im Bereich Soziale Netzwerke + Teilen über das Menü Konfiguration .
<G-vec00012-001-s020><enable.aktivieren><en> You can enable these share buttons in the Social networks & sharing section, in the Configuration menu
<G-vec00012-001-s021><enable.aktivieren><de> Hier können Sie die Seitenleiste anheften, eine schmale Seitenleiste aktivieren oder Messenger-Benachrichtigungsbuttons aktivieren.
<G-vec00012-001-s021><enable.aktivieren><en> Here you can select to pin sidebar, enable a narrow sidebar, or enable messenger notification badges.
<G-vec00012-001-s023><enable.aktivieren><de> "OZON Zum Aktivieren oder Deaktivieren des Programms, drücken Sie die Taste ""on/off"" unter dem Wort ""Ozon""."
<G-vec00012-001-s023><enable.aktivieren><en> "OZONE To enable or disable the program, press the button ""on/off"" under the word ""Ozone""."
<G-vec00012-001-s024><enable.aktivieren><de> Download-Tool zum EntfernenXbotcode@gmail.com Ransomware entfernen Aktivieren Sie dieses Tier, es zielt auf die meisten Ihrer Fotos, Videos, Musikdateien, Archive und die gemeinsamen Dateien, die für Sie sehr wichtig sind und sie mit dem am häufigsten verwendeten AES-256-Algorithmus verschlüsselt.
<G-vec00012-001-s024><enable.aktivieren><en> If you enable this beast, it aims at most of your photos, videos, music files, archives and the common files that are very important to you, and encrypts them using the most common AES-256 algorithm.
<G-vec00012-001-s025><enable.aktivieren><de> libvirt versucht daraufhin, den ip_forward -Parameter zu aktivieren.
<G-vec00012-001-s025><enable.aktivieren><en> libvirt then attempts to enable the ip_forward parameter.
<G-vec00012-001-s026><enable.aktivieren><de> Das Programm hat einen Anstieg der Popularität seit der Einführung der Start-Bildschirm unter Windows 8, wie es erlaubt Benutzern, das Betriebssystem zu aktivieren, ein klassisches start-Menü auf Geräten mit dem Microsoft-Betriebssystem.
<G-vec00012-001-s026><enable.aktivieren><en> The program has seen a rise in popularity since the introduction of the Start Screen on Windows 8 as it allowed users of the operating system to enable a classic start menu on devices running the Microsoft operating system.
<G-vec00012-001-s027><enable.aktivieren><de> Verbinden Sie den 3v3 / 5v Eingang mit dem + Pin, verbinden Sie den - an den entsprechenden Pin an Ihrer Elektronik und den Erkennungsstift an S. Sie müssen die Pullups in Ihrer Firmware aktivieren, wenn Sie dieses Modul verwenden und invertieren, da das Modul ein LOW-Signal gibt, wenn es die Erkennung misst.
<G-vec00012-001-s027><enable.aktivieren><en> Connect the 3v3/5v input to the + pin, connect the - to the corresponding pin on your electronics and the detection pin to S. You will need to enable the pull-ups in your firmware when using this module and put inverting to true, as the module will give a LOW signal when it measures detection.
<G-vec00012-001-s028><enable.aktivieren><de> Klicken Sie, um Videoeinbettungen zu aktivieren/deaktivieren.
<G-vec00012-001-s028><enable.aktivieren><en> Click to enable/disable video embeds.
<G-vec00012-001-s029><enable.aktivieren><de> – Aktiviert – Diese Einstellung wird das Gateway aktivieren, die von Kunden zur Kasse verwendet wird.
<G-vec00012-001-s029><enable.aktivieren><en> – Enabled – this setting will enable the gateway which will be used by customers to checkout.
<G-vec00012-001-s030><enable.aktivieren><de> Aktivieren Sie das Kontrollkästchen für jedes Dokument, das Sie speichern möchten.
<G-vec00012-001-s030><enable.aktivieren><en> Enable the check box for each document you want to save.
<G-vec00012-001-s031><enable.aktivieren><de> Dann, Möglicherweise müssen Sie aktivieren die “Debuggen von USB” Modus am Handy.
<G-vec00012-001-s031><enable.aktivieren><en> Then, you may need to enable the “USB Debugging” mode on your phone.
<G-vec00012-001-s032><enable.aktivieren><de> "Booten Sie die Einrichtung mit einer der Optionen in Abschnitt 2.4.1, ""Boot-Medien"" Weitere Informationen zum Aktivieren der verschiedenen Steuerungsmethoden finden Sie in Abschnitt 7.3.4, ""Festlegen des Fernzugriffs"" ."
<G-vec00012-001-s032><enable.aktivieren><en> "Boot the setup with one of the options listed in Section 2.4.1, ""Boot Media"" . To enable the different control methods refer to Section 7.3.4, ""Specifying Remote Access"" ."
<G-vec00012-001-s033><enable.aktivieren><de> Um unerwünschten Zugriff auf dein Telefon zu verhindern, ist es immer klug, bestimmte Sicherheitsmaßnahmen zu aktivieren.
<G-vec00012-001-s033><enable.aktivieren><en> To prevent unwanted access to your phone, it is always wise to enable certain security measures.
<G-vec00012-001-s034><enable.aktivieren><de> Standardmäßig, es öffnet sich nicht im Vollbildmodus, aber Sie können diesen Modus durch Antippen aktivieren F11.
<G-vec00012-001-s034><enable.aktivieren><en> By default, it doesn’t open full-screen, but you can enable that mode by tapping F11.
<G-vec00012-001-s035><enable.aktivieren><de> Wählen Sie diese Option aus, um das Einfügen von Werkzeugdefinitionen mit dem oben definierten Werkzeugformat in das NC-Programm zu aktivieren.
<G-vec00012-001-s035><enable.aktivieren><en> Check this option to enable to insertion of tool definitions into NC file, using the tool format defined above.
<G-vec00012-001-s036><enable.aktivieren><de> • Klicken Sie zum Aktivieren oder Deaktivieren einer App auf .
<G-vec00012-001-s036><enable.aktivieren><en> • Click to enable or disable an app.
<G-vec00012-001-s037><enable.aktivieren><de> Die Speicherverwaltung in Hyper-V hat eine Option benannt als Dynamic Memory; Sie können das Kontrollkästchen sehen, das ausgewählt werden kann, um das Feature in diesem Stadium zu aktivieren.
<G-vec00012-001-s037><enable.aktivieren><en> The memory management in Hyper-V has an option called Dynamic Memory; you can see the checkbox that can be selected to enable the feature at this stage.
<G-vec00179-001-s048><trigger.aktivieren><de> 3 Scatter-Symbole aktivieren das Bonus Twister Wheel.
<G-vec00179-001-s048><trigger.aktivieren><en> 3 Scatter symbols trigger the Bonus Twister Wheel.
<G-vec00179-001-s049><trigger.aktivieren><de> Wie bei jeder Art von Standard oder Standard – Arzneimittel / Nahrungsergänzungsmittel, Dianabol Einnahme ungünstigen physikalischen Reaktionen des Körpers aktivieren können und mehr Menschen haben tatsächlich mit verschiedenen negativen Auswirkungen zu kämpfen.
<G-vec00179-001-s049><trigger.aktivieren><en> Like any typical or standard medicines/supplements, taking dianabol could trigger unfavorable physical body reactions and more individuals have dealt with various adverse effects.
<G-vec00179-001-s050><trigger.aktivieren><de> Wenn Sie sich für das Kätzchen entscheiden, können Sie 8 kostenlose Drehungen gewinnen und das erweiternde Joker-Feature aktivieren.
<G-vec00179-001-s050><trigger.aktivieren><en> If you choose the kitten, you can get 8 free spins and trigger the expanding wild feature.
<G-vec00179-001-s051><trigger.aktivieren><de> "Es reicht eine ""wpa-"" Option in der interfaces(5) Datei um damit der wpa_supplicant daemon zu aktivieren."
<G-vec00179-001-s051><trigger.aktivieren><en> Any 'wpa-' option given for a device in the interfaces(5) file is sufficient to trigger the wpa_supplicant daemon into action.
<G-vec00179-001-s052><trigger.aktivieren><de> Pheromone sind chemische Stoffe, die unser Körper natürlich absondert, um sexuelle Reize zu aktivieren.
<G-vec00179-001-s052><trigger.aktivieren><en> Pheromones are chemical substances that our body segregates in a natural way aiming to trigger sexual responses.
<G-vec00179-001-s053><trigger.aktivieren><de> Doch nicht alle Bonus-Symbole aktivieren ausschließlich Bonusspiele.
<G-vec00179-001-s053><trigger.aktivieren><en> Not all bonus symbols trigger bonus games exclusively though.
<G-vec00179-001-s054><trigger.aktivieren><de> Wie bei jeder Art von traditionellen oder typische Arzneimittel / Nahrungsergänzungsmittel, Dianabol Einnahme unerwünschte Reaktionen des Körpers aktivieren konnte und noch mehr Menschen haben tatsächlich mit verschiedenen negativen Auswirkungen behandelt.
<G-vec00179-001-s054><trigger.aktivieren><en> Like any typical or standard medicines/supplements, taking dianabol could trigger unfavorable physical body reactions and more individuals have dealt with various adverse effects.
<G-vec00179-001-s055><trigger.aktivieren><de> Dieses Buch enthält den Unsichtbaren Tempel, aufgeschlüsselte Abhandlungen aus dem Unsichtbaren, die deine zellularen Zellgedächtnisbänke aktivieren werden.
<G-vec00179-001-s055><trigger.aktivieren><en> This book contains the Temple Invisible, encoded discourses from the Invisible which will trigger your cellular memory banks.
<G-vec00179-001-s056><trigger.aktivieren><de> Wie bei jeder Art von konventionellen oder traditionellen Arzneimittel / Nahrungsergänzungsmittel unter Dianabol kann negativen physischen Körper Antworten und noch mehr Menschen zu aktivieren haben aus verschiedenen negativen Auswirkungen gelitten.
<G-vec00179-001-s056><trigger.aktivieren><en> Like any type of traditional or conventional medicines/supplements, taking dianabol can trigger negative physical body reactions and even more people have actually experienced different adverse effects.
<G-vec00179-001-s057><trigger.aktivieren><de> Wie bei jeder Art von traditionellen oder herkömmlichen Medikamente / Ergänzungen, Dianabol Einnahme ungünstige Körperreaktionen aktivieren konnte und noch mehr Gäste haben mit verschiedenen negativen Auswirkungen zu kämpfen.
<G-vec00179-001-s057><trigger.aktivieren><en> Like any typical or standard medicines/supplements, taking dianabol could trigger unfavorable physical body reactions and more individuals have dealt with various adverse effects.
<G-vec00179-001-s058><trigger.aktivieren><de> Vorbeugende Maßnahme Versus Art 2 Diabetiker issues-- Genauso, wenn es um Herzerkrankungen kommen, fettleibig können Typ-2-Diabetes-Themen, die in einer Vielzahl von verschiedenen anderen ernsten Problemen führen kann, zu aktivieren.
<G-vec00179-001-s058><trigger.aktivieren><en> Preventative Procedure Versus Type 2 Diabetic issues-- Equally as in the case of heart problem, being overweight can trigger kind 2 diabetes, which can result in a number of other serious issues.
<G-vec00179-001-s059><trigger.aktivieren><de> Mit der Hilfe von Training und Diät-Plan, wird grüner Tee mit Sicherheit aktivieren thermogenen Verfahren, die Ihren Körper Fett schnell verbrennen.
<G-vec00179-001-s059><trigger.aktivieren><en> With the help of exercise and diet, green tea will certainly trigger thermogenic processes that blaze your physical body fat quickly.
<G-vec00012-001-s038><enable.aktivieren><de> Wählen Sie die Optionen Sicherheit > Sicheres Löschen und aktivieren Sie anschließend das Kontrollkästchen Sicheres Löschen aktivieren (wenn die Funktion von Ihrem Fiery Server unterstützt wird).
<G-vec00012-001-s038><enable.aktivieren><en> Select Security > Secure Erase and then select the Enable Secure Erase check box (if the feature is supported by your Fiery server).
<G-vec00012-001-s039><enable.aktivieren><de> • Optionale Informationsmeldungen - Hiermit können Sie alle Informationsmeldungen deaktivieren (Alle deaktivieren) oder aktivieren (Alle aktivieren).
<G-vec00012-001-s039><enable.aktivieren><en> • Optional information messages – Disables (Disable All) or enables (Enable All) all informative messages.
<G-vec00012-001-s040><enable.aktivieren><de> Wenn Sie Internet Explorer-Einstellungen nach der Bereitstellung an die Benutzer regelmäßig ändern möchten und dies automatisch durch die Bereitstellung von Konfigurationsdateien geschehen soll, aktivieren Sie das Kontrollkästchen Automatische Konfiguration aktivieren, um das Intervall für Updates festzulegen und dann den Speicherort für die Konfigurationsdateien anzugeben.
<G-vec00012-001-s040><enable.aktivieren><en> If you want to regularly change Internet Explorer settings after the browser is deployed to your users, and you want to do this automatically by providing configuration files, select the Enable Automatic Configuration check box to set the interval for updates and then specify the location for configuration files.
<G-vec00012-001-s041><enable.aktivieren><de> Wählen Sie „Netzwerk“ > „Bonjour“ und aktivieren Sie die Option „ Bonjour aktivieren “.
<G-vec00012-001-s041><enable.aktivieren><en> Click Network > Bonjour and select Enable Bonjour .
<G-vec00012-001-s042><enable.aktivieren><de> Passen Sie eine neue Regel für das Verschieben an und aktivieren Sie das Kontrollkästchen Regel aktivieren .
<G-vec00012-001-s042><enable.aktivieren><en> Click Add . Configure a new rule and select the Enable rule checkbox.
<G-vec00012-001-s043><enable.aktivieren><de> Aktivieren oder deaktivieren Sie bei Bedarf die folgenden Optionen: Schreibgeschützt, Auto-Mount und Dauerhaft machen, indem Sie die Kontrollkästchen aktivieren.
<G-vec00012-001-s043><enable.aktivieren><en> If needed enable or disable the following options: Read-only, Auto Mount, and Make Permanent by checking the boxes.
<G-vec00012-001-s044><enable.aktivieren><de> Es ist erforderlich, dass Sie diese beiden Dienste für alle Nutzer aktivieren, für die Sie auch Google+ aktivieren.
<G-vec00012-001-s044><enable.aktivieren><en> You'll need to enable all of these services for any users for whom you enable Google+.
<G-vec00012-001-s045><enable.aktivieren><de> Im Menü Sicherheit > Globale Sicherheit müssen die Einträge Verwaltungssicherheit aktivieren und Anwendungssicherheit aktivieren ausgewählt sein.
<G-vec00012-001-s045><enable.aktivieren><en> In the Security > Global Security menu, ensure that Enable administrative security and Enable application security are both selected.
<G-vec00012-001-s046><enable.aktivieren><de> Wählen Sie Schnelle Wiederherstellung der Verbindung aktivieren aus, um die schnelle PEAP-Wiederherstellung zu aktivieren.
<G-vec00012-001-s046><enable.aktivieren><en> To specify that PEAP Fast Reconnect is enabled, select Enable Fast Reconnect.
<G-vec00012-001-s047><enable.aktivieren><de> "Aktivieren Sie im Dialogfeld ""Printers"" das Kontrollkästchen neben den Druckern, die sie aktivieren möchten."
<G-vec00012-001-s047><enable.aktivieren><en> On the Printers dialog, enable the checkbox next to each printer to enable or disable it.
<G-vec00012-001-s048><enable.aktivieren><de> Aktivieren Sie das Kontrollkästchen, um den E-Mail-Anspruch zu aktivieren.
<G-vec00012-001-s048><enable.aktivieren><en> Select the check box to enable the e-mail claim.
<G-vec00012-001-s049><enable.aktivieren><de> Wenn Sie die automatische Wartung nicht kompatibler NAP-Clients aktivieren möchten, überprüfen Sie, ob das Kontrollkästchen Automatische Wartung von Clientcomputern aktivieren aktiviert ist.
<G-vec00012-001-s049><enable.aktivieren><en> Verify that the Enable auto-remediation of client computers check box is selected if you wish to enable automatic remediation of noncompliant NAP clients.
<G-vec00012-001-s050><enable.aktivieren><de> "Aktivieren Sie das Kontrollkästchen ""Webserver aktivieren"" und wählen Sie ""Übernehmen""."
<G-vec00012-001-s050><enable.aktivieren><en> "Tick the checkbox ""Enable Web server"" and select ""Apply""."
<G-vec00012-001-s051><enable.aktivieren><de> Aktivieren Sie das Kontrollkästchen Anforderungsfilter aktivieren.
<G-vec00012-001-s051><enable.aktivieren><en> Select the Enable Requirements Filters check box.
<G-vec00012-001-s052><enable.aktivieren><de> Diesen Kontospeicher aktivieren – Aktivieren Sie das Kontrollkästchen, um den Kontospeicher für Active Directory-Domänendienste (Active Directory Domain Services, AD DS) zu aktivieren.
<G-vec00012-001-s052><enable.aktivieren><en> Enable this account store—Select the check box to enable the Active Directory Domain Services (AD DS) account store.
<G-vec00012-001-s053><enable.aktivieren><de> Wenn Sie weiterhin auf dieser Website surfen, stimmen Sie der Verwendung von Cookies zu, um bestimmte Funktionen dieser Website zu aktivieren, Ihr Browser-Erlebnis zu personalisieren und zu optimieren, Anzeigen basierend auf Ihrem Verhalten und für andere Zwecke zu aktivieren.
<G-vec00012-001-s053><enable.aktivieren><en> By continuing to browse this site you agree to the use of cookies to enable certain functions of this website, to personalize and optimize your browsing experience, to enable ads based on your behavior, and for other purposes.
<G-vec00012-001-s054><enable.aktivieren><de> Aktivieren Sie Aktionen bei Unterbrechungen mit Fehlern aktivieren, um die Wiederherstellungsaktionen auszulösen, die von dem Dienst mit einem Fehler beendet wurde.
<G-vec00012-001-s054><enable.aktivieren><en> Select Enable actions for stops with errors in order to trigger the recovery actions that the service stopped with an error.
<G-vec00012-001-s055><enable.aktivieren><de> Aktivieren Sie auch die Option Für Computer im lokalen Netzwerk und aktivieren Sie den Browsing-Modus, indem Sie außerdem die Option Drucker standardmäßig im lokalen Netzwerk veröffentlichen aktivieren.
<G-vec00012-001-s055><enable.aktivieren><en> Also check For computers within the local network and enable browsing mode by also checking Publish printers by default within the local network .
<G-vec00012-001-s056><enable.aktivieren><de> Aktivieren Sie im Fenster Mailbox zu Ordner zuordnen die Option Zuordnung von Mailbox zu Ordner aktivieren .
<G-vec00012-001-s056><enable.aktivieren><en> In the Map mailbox to folder dialog box, select Enable mailbox to folder mapping .
<G-vec00012-001-s057><enable.aktivieren><de> "Bravocamz empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s057><enable.aktivieren><en> DrDick Live Cams suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s058><enable.aktivieren><de> "BиpTcekc empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s058><enable.aktivieren><en> BиpTcekc suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s059><enable.aktivieren><de> "Bongacams.nl empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s059><enable.aktivieren><en> BongaCams - Live Sex Chat suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s060><enable.aktivieren><de> War diese Option bisher nicht aktiviert, öffnen Sie jetzt die Konfiguration, aktivieren die Option und bauen den Port anschließend neu.
<G-vec00012-001-s060><enable.aktivieren><en> If that option was not enabled, display the options menu and enable it, then reinstall the port:
<G-vec00012-001-s061><enable.aktivieren><de> "Adultter empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s061><enable.aktivieren><en> Adultter suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s062><enable.aktivieren><de> Komprimierte VPN-Verbindung aktivieren: Damit werden die Daten vor der Übertragung über VPN komprimiert.
<G-vec00012-001-s062><enable.aktivieren><en> Enable compressed VPN link: This will compress data before transferring via VPN.
<G-vec00012-001-s063><enable.aktivieren><de> "Wichtig: Aktivieren Sie die Richtlinie ""Unterstützung von Offlineprofilen"" nicht mit Citrix VDI-in-a-Box."
<G-vec00012-001-s063><enable.aktivieren><en> Important: Do not enable Offline profile support with Citrix VDI-in-a-Box.
<G-vec00012-001-s064><enable.aktivieren><de> "Bongacams.ch empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s064><enable.aktivieren><en> Free Live Sex Chat suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s065><enable.aktivieren><de> "10.2. hitdown empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s065><enable.aktivieren><en> 10.2. hitdown suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s066><enable.aktivieren><de> • Diagnose - Aktivieren oder deaktivieren Sie die Übermittlung von Absturzberichten an ESET.
<G-vec00012-001-s066><enable.aktivieren><en> • Diagnostics - Enable or disable transmission of crash reports to ESET.
<G-vec00012-001-s067><enable.aktivieren><de> Falls der ISP hilfsbereit ist, sollte er in der Lage sein, an seinem Ende das Logging zu aktivieren und wenn das nächste Mal die Verbindung abbricht, könnte er Ihnen mitteilen, worin das Problem auf seiner Seite besteht.
<G-vec00012-001-s067><enable.aktivieren><en> If the ISP is helpful, they should be able to enable logging on their end, then when the next link drop occurs, they may be able to tell why their side is having a problem.
<G-vec00012-001-s068><enable.aktivieren><de> "Bongacams.lt empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s068><enable.aktivieren><en> BongaCams - Live Sex Chat suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s069><enable.aktivieren><de> Aktivieren Sie am Server abhängig von Ihrer Konfiguration entweder die Lese- oder die Schreibrechte oder beides.
<G-vec00012-001-s069><enable.aktivieren><en> Depending on your configuration, enable either read or write permissions or both on the server.
<G-vec00012-001-s070><enable.aktivieren><de> "CamCam - Community Chat empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s070><enable.aktivieren><en> CamCam - Community Chat suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s071><enable.aktivieren><de> Wieder zu aktivieren Flugmodus auf dem Gerät auf die Frage,.
<G-vec00012-001-s071><enable.aktivieren><en> Enable Airplane Mode again on the device when asked .
<G-vec00012-001-s072><enable.aktivieren><de> Users ' Daten erhoben und verwendet werden, um die Navigation auf der Website zu ermöglichen, um das Surferlebnis zu verbessern und um die Reservierung zu aktivieren, oder die Antworten auf die Anfragen und Mitteilungen der Verlader.
<G-vec00012-001-s072><enable.aktivieren><en> Users' data are collected and used to allow navigation on the Site, to enhance the browsing experience and to enable the reservation, or respond to any requests and communications from the shippers.
<G-vec00012-001-s073><enable.aktivieren><de> Aktivieren Sie bitte die Cookies für eine bessere Erfahrung.
<G-vec00012-001-s073><enable.aktivieren><en> Please enable cookies for a better experience.
<G-vec00012-001-s074><enable.aktivieren><de> "Camilfo empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s074><enable.aktivieren><en> Camilfo suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s075><enable.aktivieren><de> "Bongacams.at empfiehlt den Abonnenten ""Cookies"" in ihren Browsern zu aktivieren, um die volle Funktionalität sicherzustellen."
<G-vec00012-001-s075><enable.aktivieren><en> BongaCams - Live Sex Chat suggests for the Subscribers to enable “Cookies” in their browsers to ensure full functionality.
<G-vec00012-001-s076><enable.aktivieren><de> Um Javascript in Chrome auf Android zu aktivieren, öffnen Sie die App Chrome und tippen Sie dann auf die Menütaste.
<G-vec00012-001-s076><enable.aktivieren><en> To enable Javascript in Chrome on Android, open the Chrome app, then tap the menu button.
<G-vec00012-001-s077><enable.aktivieren><de> "Aktivieren Sie die Option fÃ1⁄4r die gemeinsame Nutzung einfacher Daten, indem Sie in Ihrer Datei AndroidManifest.xml im Tag ""manifest"" den Namen der Anwendungsfamilie mit dem Element android:sharedUserId angeben."
<G-vec00012-001-s077><enable.aktivieren><en> Android Enable the Simple Data Sharing option by specifying the application family name as the android:sharedUserId element in the manifest tag of your AndroidManifest.xml file.
<G-vec00012-001-s078><enable.aktivieren><de> Schritt #1 -Entsperren Sie Ihr iPhone X und gehen Sie zu “Einstellungen > Allgemeine > Barrierefreiheit”, und aktivieren Sie dann die “Unterstützende Touch” Möglichkeit.
<G-vec00012-001-s078><enable.aktivieren><en> Step #1 – Unlock your iPhone X and go to “Settings > General > Accessibility”, and then enable the “Assistive Touch” option.
<G-vec00012-001-s079><enable.aktivieren><de> Aktivieren Sie Messaging und Authentifizierung für text- und stimmbasierte Interaktionen – für mehr Kundenzufriedenheit und niedrigere Contact-Center-Kosten.
<G-vec00012-001-s079><enable.aktivieren><en> Enable messaging and authentication for both text and voice based engagements for higher customer satisfaction and lower contact centre costs.
<G-vec00012-001-s080><enable.aktivieren><de> Aktivieren Sie Ableton Link in einer anderen kompatiblen Anwendung, und diese werden automatisch verbunden.Deck-Effekte Master Panel Durch Klicken auf das Symbol im Deck Effect- oder Master-Panel rechts neben dem Ableton Link-Effekt in der Effektauswahlliste wird die Ableton Link-Benutzeroberfläche geöffnet und an der unteren rechten Ecke der Software-Oberfläche neben dem Info-Panel verankert.Die GUI bietet Optionen zum Vorwärts- oder Rückwärtsschieben (für Verbindungen mit einer Verzögerung oder Verzögerung) sowie die Anzahl der verknüpften Anwendungen.Sobald Ableton Link eingerichtet ist, synchronisiert es musikalischen Beat, Tempo und Phase über mehrere Anwendungen hinweg, die auf einem oder mehreren Geräten ausgeführt werden.
<G-vec00012-001-s080><enable.aktivieren><en> Enable Ableton Link in another compatible application and they will automatically be connected. Deck Effects Master Panel Clicking on the icon in the Deck Effect or Master Panel to the right of the Ableton Link Effect in the Effect Selection List will open the Ableton Link GUI and dock it to the lower right of the software interface beside the Info Panel.The GUI will provide options to nudge forward or back (for connections that have some delay or lag) as well as display the number of applications that are linked.
<G-vec00012-001-s081><enable.aktivieren><de> Sicherheit Kompromisse zu Rogue Browser-Erweiterungen basieren, sind auch beständiger als solche auf Basis von Passwort-Klau oder andere Methoden, weil diese Erweiterungen können Ã1⁄4ber aktive Sitzungen huckepack auf unbefugte Aktionen ausfÃ1⁄4hren, auch wenn die Kontoinhaber ihre Passwörter ändern oder aktivieren Sie die Zwei-Faktor-Authentifizierung.
<G-vec00012-001-s081><enable.aktivieren><en> Security compromises based on rogue browser extensions are also more persistent than those based on password theft or other methods, because these extensions can piggyback on active sessions to perform unauthorized actions even if the account owners change their passwords or enable two-factor authentication.
<G-vec00012-001-s082><enable.aktivieren><de> Aktivieren Sie die JMX-Kommunikation zwischen den Liberty-Servern.
<G-vec00012-001-s082><enable.aktivieren><en> Enable the JMX communication between the Liberty servers.
<G-vec00012-001-s083><enable.aktivieren><de> Aktivieren Sie diese Option, damit das Formular im Front-End der Website angezeigt wird, wenn Sie es mit einem der Formulare von Form Maker D veröffentlichen isplay Optionen.
<G-vec00012-001-s083><enable.aktivieren><en> Enable this option, so the form will be visible on the site front-end when you publish it with one of Form Maker’s Display Options.
<G-vec00012-001-s084><enable.aktivieren><de> Aktivieren Sie diese Funktion durch Klicken auf Kutoolen > Super LOOKUP > LOOKUP und Summe.
<G-vec00012-001-s084><enable.aktivieren><en> Enable this function by clicking Kutools > Super LOOKUP > LOOKUP and Sum.
<G-vec00012-001-s085><enable.aktivieren><de> Aktivieren Sie zusätzlich die Option Remote Printer is on a BSD System.
<G-vec00012-001-s085><enable.aktivieren><en> Also enable the option Remote Printer is on a BSD System there.
<G-vec00012-001-s086><enable.aktivieren><de> Aktivieren Sie die H.264-Codierung fÃ1⁄4r den Vollbildmodus, um die beste Erfahrung mit dem Citrix Ready Workspace Hub (und dem SDA) zu erzielen.
<G-vec00012-001-s086><enable.aktivieren><en> Performance policy To get the best experience on your Citrix Ready workspace hub (and the SDA), enable H.264 encoding for full-screen mode.
<G-vec00012-001-s087><enable.aktivieren><de> Step 5: Als nächstes aktivieren Sie scheduler um eine automatische Sicherung zu erstellen Daily, Weekly oder Monthly Basis.
<G-vec00012-001-s087><enable.aktivieren><en> Step 5: Next, enable scheduler to create an automatic backup on Daily, Weekly or Monthly basis.
<G-vec00012-001-s088><enable.aktivieren><de> Schritt 4: Aktivieren Sie den Bereich Bearbeitung einschränken (oder Bereich Formatierung und Bearbeitung einschränken), indem Sie auf klicken Bearbeiten einschränken Taste auf der Entwickler Tab.
<G-vec00012-001-s088><enable.aktivieren><en> Step 4: Enable the Restrict Editing pane (or Restrict Formatting and Edit pane) with clicking the Restrict Editing button on the Developer tab.
<G-vec00012-001-s089><enable.aktivieren><de> Aktivieren Sie die permanenten Objektfänge Tangente und Ende .
<G-vec00012-001-s089><enable.aktivieren><en> Enable the persistent tangent and end object snaps.
<G-vec00012-001-s090><enable.aktivieren><de> Klicken Sie Kutoolen > vorwärts (in dem Vordergrundautomatik Gruppe)> Aktivieren Sie die automatische Weiterleitung um das Dialogfeld Einstellungen für automatische Weiterleitung zu öffnen.
<G-vec00012-001-s090><enable.aktivieren><en> Click Kutools > Forward (in the Automatic group) > Enable Auto Forward to open the Auto Forward Settings dialog box.
<G-vec00012-001-s091><enable.aktivieren><de> Aktivieren Sie diese Option, wenn Sie die Bilder verwenden möchten, die bereits in Ihrem Beitrag sind eine Miniaturansicht zu erstellen, ohne dass benutzerdefinierte Felder verwenden.
<G-vec00012-001-s091><enable.aktivieren><en> Enable this option if you want to use the images that are already in your post to create a thumbnail without using custom fields.
<G-vec00012-001-s092><enable.aktivieren><de> Aktivieren Sie unter Stationen > Verbindungs-Ziel die Option Verbindungen an folgende Stationen und wählen Sie Hinzufügen… den Eintrag LOCALNET .
<G-vec00012-001-s092><enable.aktivieren><en> In Stations > Connection destination, enable the option Connections to the following stations and after selection Add... choose LOCALNET .
<G-vec00012-001-s093><enable.aktivieren><de> Aktivieren Sie Passthrough für Hardware-Decoder - AC3 oder DTS für Surround-Audio.
<G-vec00012-001-s093><enable.aktivieren><en> Enable passthrough for hardware decoders – AC3 or DTS for surround audio.
<G-vec00012-001-s094><enable.aktivieren><de> Aktivieren Sie vorübergehend General - Throttle/Governor - Governor und stellen Sensing Divider und Gear Ratio ein.
<G-vec00012-001-s094><enable.aktivieren><en> Temporarily enable General - Throttle/Governor - Governor and set Sensing Divider and Gear Ratio .
<G-vec00012-001-s095><enable.aktivieren><de> Wenn der Debugmodus aktiviert wird, erscheint rechts ein Fenster mit den aktuell vorhandenen Variablen.
<G-vec00012-001-s095><enable.aktivieren><en> If the debug mode is enable the variable view will be visible on the right side of the main window.
<G-vec00012-001-s096><enable.aktivieren><de> Haben Sie „Gelöschte Dateien/Ordner überspringen“ aktiviert, werden die als gelöscht gekennzeichneten Sicherungsdaten nicht wiederhergestellt.
<G-vec00012-001-s096><enable.aktivieren><en> If you enable “Skip deleted files/folders”, the backup data marked as deleted will not be restored.
<G-vec00012-001-s097><enable.aktivieren><de> #PB_Terrain_NormalMapping: aktiviert das normale Mapping (Anzeige) für die Terrains.
<G-vec00012-001-s097><enable.aktivieren><en> #PB_Terrain_NormalMapping: enable the normal mapping for the terrains.
<G-vec00012-001-s098><enable.aktivieren><de> Aktiviert WPA und gibt an welches WPA-Authentifizierungprotokoll benötigt wird.
<G-vec00012-001-s098><enable.aktivieren><en> Enable WPA and specify which WPA authentication protocol will be required.
<G-vec00012-001-s099><enable.aktivieren><de> Wenn Sie Seller Ratings in Ihrer Conversations-Implementierung aktiviert haben, können Beurteilungen und Bewertungen Ihres Unternehmens in GoogleÂ AdWords angezeigt werden.
<G-vec00012-001-s099><enable.aktivieren><en> After you enable Seller Ratings in your Conversations implementation, ratings and reviews about your company can appear in Google AdWords.
<G-vec00012-001-s100><enable.aktivieren><de> Dies ist ziemlich wahrscheinlich, da Sie die iCloud Backup für die Camera Roll aktiviert haben.
<G-vec00012-001-s100><enable.aktivieren><en> This’s pretty likely as you didn’t enable the iCloud back up for the Camera Roll.
<G-vec00012-001-s101><enable.aktivieren><de> Das Protokoll IPP (Internet Printing Protocol) kann nur aktiviert werden, wenn die Webdienste aktiviert wurden.
<G-vec00012-001-s101><enable.aktivieren><en> After enabling Web services, you can enable Internet Printing Protocol (IPP).
<G-vec00012-001-s102><enable.aktivieren><de> Wenn Sie diese Richtlinie nicht an Geräte senden und Google FCM nicht aktiviert haben, kann das Gerät keine Verbindung mit dem Server herstellen.
<G-vec00012-001-s102><enable.aktivieren><en> If you don't send this policy to devices and don't enable Google FCM, a device can't connect back to the server.
<G-vec00012-001-s103><enable.aktivieren><de> Aktivieren Aktiviert oder deaktiviert die Verwendung einer benutzerdefinierten Gierachse.
<G-vec00012-001-s103><enable.aktivieren><en> Enable Enable or disable the use of a custom yaw axis.
<G-vec00012-001-s104><enable.aktivieren><de> Falls Ihre Firewall keine Funktionsgruppe zur Durchführung von H.323 oder SIP NAT verwendet, muss NAT auf Ihrem privaten Lifesize-System aktiviert werden.
<G-vec00012-001-s104><enable.aktivieren><en> If your firewall does not employ a feature set that performs H.323 or SIP NAT, you must enable NAT on your private Lifesize system.
<G-vec00012-001-s105><enable.aktivieren><de> Das Plugin aktiviert automatisch die Meta-Informationen für Suchmaschinen.
<G-vec00012-001-s105><enable.aktivieren><en> The plugin automatically enable the meta information for search engines.
<G-vec00012-001-s106><enable.aktivieren><de> Wenn das Kästchen aktiviert ist, wird das Dialogfenster Datei öffnen/speichern des Betriebssystems verwendet, wenn deaktiviert - des Programms.
<G-vec00012-001-s106><enable.aktivieren><en> Enable this option if you want to use the System Open/Save Dialog. Otherwise, the AKVIS File Dialog is used.
<G-vec00012-001-s107><enable.aktivieren><de> Wer ganz auf Nummer Sicher gehen will, aktiviert auch die automatische Installation von größeren Versionssprüngen.
<G-vec00012-001-s107><enable.aktivieren><en> Those who prefer to be on the safe side can also enable the automatic installation of major updates.
<G-vec00012-001-s108><enable.aktivieren><de> Mit diesen Cookies werden bestimmte zusätzliche Features auf unseren Websites aktiviert, beispielsweise das Speichern Ihrer Einstellungen (wie Benutzername und Sprachauswahl) und das Verhindern der mehrmaligen Teilnahme an ein und derselben Umfrage.
<G-vec00012-001-s108><enable.aktivieren><en> These cookies are used to enable certain additional functionality on our websites, such as storing your preferences like username and language selection, and preventing users from taking the same survey multiple times.
<G-vec00012-001-s109><enable.aktivieren><de> Es aktiviert einen Benutzer Höre die Umgebungsgeräusche und Anrufe von 1-Minute zu 45-Minuten.
<G-vec00012-001-s109><enable.aktivieren><en> It enable a user listen the surrounding sounds and calls from 1 minute to 45 minutes.
<G-vec00012-001-s110><enable.aktivieren><de> "System =>""Check/Uncheck Enable Patches"": Dies aktiviert/deaktiviert die Spiel Patches."
<G-vec00012-001-s110><enable.aktivieren><en> System =>Check/Uncheck Enable Patches: This will enable/disable game patches.
<G-vec00012-001-s111><enable.aktivieren><de> "Wird die Option ""Keine Antworten senden"" aktiviert, sendet der Miniserver kein Acknowledge (EIB-Bestätigung)."
<G-vec00012-001-s111><enable.aktivieren><en> If you enable the option 'Do not send a response ', the Miniserver will not send acknowledgements (no EIB confirmation).
<G-vec00012-001-s112><enable.aktivieren><de> Wir empfolen, dass Sie JavaScript aktiviert, um die Funktionen auf dieser Seite am besten auszunützen können.
<G-vec00012-001-s112><enable.aktivieren><en> We recommend that you enable JavaScript to be able to use all functions on this page.
<G-vec00012-001-s113><enable.aktivieren><de> Wenn Sie verstärkte Sicherheit des privaten Schlüssels aktiviert haben, werden Sie bei jeder Verwendung des privaten Schlüssels zur Eingabe eines Kennworts aufgefordert.
<G-vec00012-001-s113><enable.aktivieren><en> When you enable strong private key protection, you will be prompted for a password every time the private key needs to be used.
<G-vec00012-001-s342><enable.aktivieren><de> Daher müssen Sie die GPU aktivieren, um die Dekodierungsfunktion in VLC zu beschleunigen.
<G-vec00012-001-s342><enable.aktivieren><en> So, you need to enable GPU to accelerate decoding feature in VLC.
<G-vec00012-001-s343><enable.aktivieren><de> Erforderlich für die Erfüllung Ihres Spielvertrags oder anderer Funktionen, die Sie anfordern oder aktivieren.
<G-vec00012-001-s343><enable.aktivieren><en> Necessary for the performance of your game contract or any other feature you request or enable.
<G-vec00012-001-s344><enable.aktivieren><de> Haupteigenschaften: Intelligente Sprachsteuerung: Funktioniert nahtlos mit Amazon Alexa und Google Home, um die Sprachsteuerung zu aktivieren.
<G-vec00012-001-s344><enable.aktivieren><en> Main Features: ●Smart Voice Control: Works seamlessly with Amazon Alexa and Google Home to enable voice control.
<G-vec00012-001-s345><enable.aktivieren><de> An der NAP-Clientkonfigurationskonsole (Network Access Protection, Netzwerkzugriffsschutz) können Sie über die NAP-Clientkonfigurationseinstellungen in den Gruppenrichtlinien oder über Netsh-Befehle für die NAP-Clientkonfiguration NAP-Erzwingungsclients aktivieren oder deaktivieren.
<G-vec00012-001-s345><enable.aktivieren><en> You can use the Network Access Protection (NAP) Client Configuration console, NAP client configuration settings in Group Policy, or Netsh commands for NAP client configuration to enable and disable NAP enforcement clients.
<G-vec00012-001-s346><enable.aktivieren><de> Wenn Sie die Filterfunktion nicht aktivieren möchten, auch nicht zu VBA, hier stelle ich Ihnen ein praktisches Tool vor - Wählen Sie bestimmte Zellen aus of Kutools for Excel Um schnell ganze Zeilen basierend auf dem Zellenwert auszuwählen, können Sie sie ausblenden.
<G-vec00012-001-s346><enable.aktivieren><en> IF you do not like to enable Filter function, neither to VBA, here I introduce you a handy tool – Select Specific Cells of Kutools for Excel to quickly select entire rows based on cell value, then you can hide them.
<G-vec00012-001-s347><enable.aktivieren><de> "Cookies werden nicht verwendet, wenn Sie die Einstellung ""Authentifizierung bei automatischer Wiederverbindung von Clients"" aktivieren."
<G-vec00012-001-s347><enable.aktivieren><en> Cookies are not used if you enable the Auto client reconnection authentication setting.
<G-vec00012-001-s348><enable.aktivieren><de> Wenn Sie dem Gerät (oder genauer gesagt, dem Besitzer) vertrauen, können Sie schließlich die Serveraktionen aktivieren.
<G-vec00012-001-s348><enable.aktivieren><en> If you trust the device (or more exactly the owner), you can finally enable server actions.
<G-vec00012-001-s349><enable.aktivieren><de> Wählen Sie Alle Vorgänge aus, falls Sie die RMM-Schnittstelle für alle Vorgänge aktivieren möchten.
<G-vec00012-001-s349><enable.aktivieren><en> Select All operations if you want to enable RMM interface for all operations.
<G-vec00012-001-s350><enable.aktivieren><de> Ein Administrator kann die Unterstützung für den hohen Durchsatzmodus aktivieren oder deaktivieren, um den Stromverbrauch zu reduzieren oder Konflikten mit anderen Bändern oder Kompatibilitätsproblemen entgegenzuwirken.
<G-vec00012-001-s350><enable.aktivieren><en> An administrator can enable or disable support for high throughput mode to reduce power consumption or conflicts with other bands or compatibility issues.
<G-vec00012-001-s351><enable.aktivieren><de> Wir nutzen die lokale Speicherung, um bestimmte Funktionen zu aktivieren, einschließlich der Speicherung bestimmter Teile unserer Seite auf Ihrem Gerät, sodass diese Seiten bei Ihrem nächsten Besuch schneller hochgeladen werden.
<G-vec00012-001-s351><enable.aktivieren><en> We use local storage to enable certain features, including to store certain parts of our site on your device so that those pages load more quickly when you next visit them.
<G-vec00012-001-s352><enable.aktivieren><de> Wenn Bronto Ihr ESP ist, wählen Sie einfach Bronto auf der Integrationsseite in den Einstellungen für dynamisches Yield und klicken Sie, um die Integration zu aktivieren.
<G-vec00012-001-s352><enable.aktivieren><en> If Bronto is your ESP, simply find Bronto on the integrations page within your Dynamic Yield settings, and click to enable integration.
<G-vec00012-001-s353><enable.aktivieren><de> Diese Cookies werden verwendet, um die Funktionalität der Website zu aktivieren.
<G-vec00012-001-s353><enable.aktivieren><en> Functional Cookies These cookies are used to enable site functionality.
<G-vec00012-001-s354><enable.aktivieren><de> "Sie können die Option ""Suchen"" aktivieren, die bestimmte Dateien aus der Liste der erhaltenen Daten nach Dateinamen, Datum, Erstellungsdatum, Erweiterung & Größe durchsuchen kann."
<G-vec00012-001-s354><enable.aktivieren><en> "You can enable ""Find"" option that is able to search out specific files from the list of obtained data according to their file name, date, creation date, extension & size."
<G-vec00012-001-s355><enable.aktivieren><de> Wir empfehlen Ihnen, alle Daten auf dem Intel® OptaneTM Arbeitsspeichermodul zu sichern, bevor Sie die Systembeschleunigung aktivieren.
<G-vec00012-001-s355><enable.aktivieren><en> We recommend you back up all data on the Intel® OptaneTM memory module before you enable system acceleration.
<G-vec00012-001-s356><enable.aktivieren><de> Deaktivieren Sie das Kontrollkästchen, um die Umleitung für diesen Typ eines lokalen Geräts oder einer Ressource zu aktivieren.
<G-vec00012-001-s356><enable.aktivieren><en> Clear the check box to enable redirection of that type of local device or resource.
<G-vec00012-001-s357><enable.aktivieren><de> "In einigen Fällen können schädliche Viren oder unerwartete Katastrophen wesentliche Dateien auf dem USB-Laufwerk verbergen, auch wenn Sie die Option ""Versteckte Dateien und Ordner anzeigen"" aktivieren."
<G-vec00012-001-s357><enable.aktivieren><en> In some instances harmful viruses or unexpected disasters may hide essential files on USB drive even if you enable “Shown hidden files and folders” option.
<G-vec00012-001-s358><enable.aktivieren><de> Du hast bei der anfänglichen Einrichtung deines Geräts die Möglichkeit, die Ortungsdienste zu aktivieren – sie sind nicht standardmäßig eingeschaltet.
<G-vec00012-001-s358><enable.aktivieren><en> You have the choice to enable Location Services when you first set up your device — it’s not on by default.
<G-vec00012-001-s359><enable.aktivieren><de> HINWEIS Um die vollständige Protokollierung zu aktivieren, erstellen Sie eine Dummy-Datei mit dem Namen traceAll ohne Dateierweiterung im gleichen Ordner wie „trace.log“.
<G-vec00012-001-s359><enable.aktivieren><en> NOTE: To enable full logging, create a dummy file named traceAll without an extension in the same folder as a trace.log and then restart the ESET Remote Administrator Server service.
<G-vec00012-001-s360><enable.aktivieren><de> Um die entfernte Verwaltung Ihres Computers übers VNC zu aktivieren, klicken Sie auf Verwaltung von entfernten Rechnern aus (remote) über VNC .
<G-vec00012-001-s360><enable.aktivieren><en> To enable remote administration of your machine via VNC, click VNC Remote Administration .
<G-vec00246-002-s134><reactivate.aktivieren><de> Wenn Ihr Account aufgrund von mangelnder Aktivität deaktiviert wurde und Sie noch immer Zugriff auf die bei CJ hinterlegte E-Mail Adresse haben, kann dieser wahrscheinlich wieder reaktiviert werden.
<G-vec00246-002-s134><reactivate.aktivieren><en> If your account was deactivated due to dormancy and you still have access to the old email address, we can probably reactivate it.
