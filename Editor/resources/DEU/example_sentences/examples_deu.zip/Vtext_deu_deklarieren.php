<G-vec00060-001-s174><declare.deklarieren><de> Jeder Benutzer, der mit der Datenbank verbunden ist, kann eine externe Funktion (UDF) deklarieren.
<G-vec00060-001-s174><declare.deklarieren><en> Any user connected to the database can declare an external function (UDF).
<G-vec00060-001-s175><declare.deklarieren><de> Ein Versuch, mehr als einen BLOB -Filter mit derselben Kombination der Ein- und Ausgabetypen zu deklarieren, schlägt mit einem Fehler fehl.
<G-vec00060-001-s175><declare.deklarieren><en> An attempt to declare more than one BLOB filter with the same combination of the input and output types will fail with an error.
<G-vec00060-001-s176><declare.deklarieren><de> In diesem Fall fordert DHL Express den Absender auf, die Sendung auf dem Versandauftragsschein/ Luftfrachtbrief und/oder der Rechnung als „nicht eingeschränkt“ oder als „nach der Sonderbedingung A... nicht eingeschränkt“ zu deklarieren.
<G-vec00060-001-s176><declare.deklarieren><en> "In this case DHL Express requires shippers to declare the shipment as ""Not Restricted"" or ""not restricted as per special provision A..."" on the waybill and/or invoice."
<G-vec00060-001-s177><declare.deklarieren><de> Extrakt-Komponenten bestehen, sind sie einfach zu deklarieren.
<G-vec00060-001-s177><declare.deklarieren><en> of extract components, they are easy to declare.
<G-vec00060-001-s178><declare.deklarieren><de> Nebenbei haben sie auch Mandate bei Institutionen und Unternehmen – sogenannte Interessenbindungen, die sie beim Eintritt ins Parlament deklarieren und jährlich aktualisieren müssen.
<G-vec00060-001-s178><declare.deklarieren><en> They also have roles in institutions and companies – so-called interest connections – which they must declare on entering Parliament and must update annually.
<G-vec00060-001-s179><declare.deklarieren><de> "Es gibt zwei Schreibtische an jedem Grenzkontrollpunkt bei der Einreise nach Rumänien: ""Nichts zu deklarieren"" und ""Waren zu deklarieren""."
<G-vec00060-001-s179><declare.deklarieren><en> "There are two desks at any border check point when entering Romania: ""Nothing to Declare"" and ""Goods to Declare""."
<G-vec00060-001-s181><declare.deklarieren><de> Ein Benutzer kann sich während einer Intervention oder einer Besprechung als nicht verfügbar deklarieren.
<G-vec00060-001-s181><declare.deklarieren><en> An operator can now declare himself unavailable, for example during an intervention or a meeting.
<G-vec00060-001-s182><declare.deklarieren><de> Eine Marke dauerhaft zu kultivieren und zu behaupten, heißt definieren, deklarieren, ausdauern…weissagen.
<G-vec00060-001-s182><declare.deklarieren><en> To cultivate and maintain an enduring brand is to define, declare, go forth…to divine.
<G-vec00060-001-s183><declare.deklarieren><de> Um private Variablen zu deklarieren, kann das Wort privat nicht als vorhersehbare Prozedur innerhalb der Prozedur verwendet werden, und es ist klarer, sie anstelle von Dim zu verwenden.
<G-vec00060-001-s183><declare.deklarieren><en> To declare private variables, the word Private can not be used within the procedure as a predictable procedure, and it is clearer to use it rather than Dim.
<G-vec00060-001-s184><declare.deklarieren><de> "Man meint, im Rahmen einer ""Interreligiösen Ökumene"" alle Religionen als ""verschiedene Wege zum Heil"" deklarieren zu können und verkauft den biblisch-christlichen Glauben als Massenware im Sonderangebot."
<G-vec00060-001-s184><declare.deklarieren><en> "People think, based on ""interreligious ecumenism"", that they are entitled to declare all religions to be ""different paths to salvation"", and so peddle the Christian biblical faith as mass goods on special offer."
<G-vec00060-001-s185><declare.deklarieren><de> Dr. Tharwat Nafe: Sisi bekannt Absichten, die Phase der Diktatur einzuleiten nicht gehen und friedlich und somit den kommenden Bürgerkrieg zu deklarieren..
<G-vec00060-001-s185><declare.deklarieren><en> Dr. Tharwat Nafe: Sisi announced intentions to launch the phase of the dictatorship will not go and peacefully and thus declare the coming civil war..
<G-vec00060-001-s186><declare.deklarieren><de> Deklarieren Sie die Variable in der Objektmethode als feste Zeit, erscheint sie im Anzeigebereich als statisches Objekt.
<G-vec00060-001-s186><declare.deklarieren><en> When you declare the associated variable as a specific time in the object method, this time is displayed as a static object.
<G-vec00060-001-s187><declare.deklarieren><de> Unabhängig von PPCmetrics gilt, dass Berater nicht deklarieren müssen, was sie an Provisionen und Kickbacks von den Banken erhalten.
<G-vec00060-001-s187><declare.deklarieren><en> PPCmetrics aside, consultants are not obliged to declare the commissions and kickbacks they are granted by banks.
<G-vec00060-001-s188><declare.deklarieren><de> Diese Karte kann in dem Spielzug, in dem dieser Effekt aktiviert wird, keinen Angriff deklarieren.
<G-vec00060-001-s188><declare.deklarieren><en> This card cannot declare an attack the turn this effect is activated.
<G-vec00060-001-s189><declare.deklarieren><de> Einreisende, die mehr als 3.000,00 US$ mit sich führen werden gebeten den Betrag an der Central Bank in der Abfertigungshalle des Flughafens zu deklarieren.
<G-vec00060-001-s189><declare.deklarieren><en> Visitors entering the Philippines with more than 3,000,00 US$ are requested to declare the amount at the central bank in the arrival hall of the airport.
<G-vec00060-001-s190><declare.deklarieren><de> Sie deklarieren sich in Ihrer Geschäftskorrespondenz als Auslieferungspartner von SheetMusicDB.net.
<G-vec00060-001-s190><declare.deklarieren><en> You declare in your business correspondence that you are a distribution partner of SheetMusicDB.net.
<G-vec00060-001-s191><declare.deklarieren><de> "Es gibt normalerweise zwei Linien an einem Punkt der Eintrag: ""So deklarieren"" und ""Nichts zu deklarieren""."
<G-vec00060-001-s191><declare.deklarieren><en> "There are usually two lines at a point of entry: ""To Declare"" and ""Nothing to Declare""."
<G-vec00060-001-s193><declare.deklarieren><de> Nachdem wir die Instanzvariablen x_speed und y_speed deklariert und im Konstruktor initialisiert haben, können wir sie in jedem Aufruf von move() zu den aktuellen Koordinaten hinzuzählen.
<G-vec00060-001-s193><declare.deklarieren><en> First of all we have to declare four instance variables (x_speed, y_speed, x_pos, y_pos) and initialize them in the constructor of our ball object.
<G-vec00060-001-s194><declare.deklarieren><de> Es gibt keine Währungsbeschränkungen, Beträge über 10.000 AUS müssen jedoch deklariert werden.
<G-vec00060-001-s194><declare.deklarieren><en> There is no limit on currency but you will need to declare amounts over $10000.
<G-vec00060-001-s195><declare.deklarieren><de> Mit token = können Sie bis zu 26 Token angeben, vorausgesetzt, dass ein Tentakel keine Variable deklariert, die höher ist als der Buchstabe 'z' oder 'Z'.
<G-vec00060-001-s195><declare.deklarieren><en> You can specify up to 26 tokens using tokens = provided that it does not cause a tentacle to declare a variable higher than the letter 'z' or 'Z'.
<G-vec00060-001-s196><declare.deklarieren><de> Es bestehen keine Währungsbeschränkungen, Beträge über 10.000 AUS müssen jedoch deklariert werden.
<G-vec00060-001-s196><declare.deklarieren><en> There is no limit on currency but you will need to declare amounts over $10,000.
<G-vec00060-001-s197><declare.deklarieren><de> 80x86 MODUS: M[Einstellung] Der aktuellen Prozessortyp (zum Zwecke der Assembler und Disassembler Warnungen, siehe oben) kann als etwas anderes vereinbart wer- den, ueber die folgenden Befehle: m0 Deklariert den aktuellen Typ als 8088 m1 Deklariert als 80186 m2 Deklariert als 286 m3 Deklariert als 386 m4 Deklariert als 486 m5 Deklariert als Pentium m6 Deklariert als Pentium Pro MC Vereinbart die Existenz eines mathematischen Coprozessors.
<G-vec00060-001-s197><declare.deklarieren><en> UNASSEMBLE: U [range] Unassemble. 80x86 MODE: M[setting] The current processor (for the purposes of assembler and disassembler warnings, above) can be declared to be something else via the following commands: m0 Declare current processor to be an 8088 m1 Declare 80186 m2 Declare 286 m3 Declare 386 m4 Declare 486 m5 Declare Pentium m6 Declare Pentium Pro MC Declare the existence of a math coprocessor.
<G-vec00060-001-s204><declare.deklarieren><de> Wenn Ihr also Geld aus dem Ausland erhaltet, dann deklariert das, denn wir wollen wissen, wer Ihr seid, wer Euch finanziert, wer hinter Eurem Rücken steht.
<G-vec00060-001-s204><declare.deklarieren><en> So if you receive money from abroad, declare it; because we want to know who you are, who finances you, and who is behind you.
<G-vec00060-001-s205><declare.deklarieren><de> Das Ergebnis dieses Schritts muss, wie unten gezeigt, deklariert werden (in diesem Beispiel haben wir es output genannt).
<G-vec00060-001-s205><declare.deklarieren><en> Make sure to declare the result of this step, as shown below (in this example, we called it output).
<G-vec00060-001-s206><declare.deklarieren><de> Obwohl die title -Eigenschaft in der Post -Klasse nicht explizit deklariert wurde, können wir doch mit dem obigen Code auf sie zugreifen.
<G-vec00060-001-s206><declare.deklarieren><en> Although we never explicitly declare the title property in the Post class, we can still access it in the above code.
<G-vec00060-001-s207><declare.deklarieren><de> In Ihrem XSLT 2.0 Stylesheet sollten die folgenden Namespaces deklariert sein, damit Sie die in XSLT 2.0 verfügbaren Typ-Konstruktoren und Funktionen verwenden können.
<G-vec00060-001-s207><declare.deklarieren><en> Your XSLT 2.0 stylesheet should declare the following namespaces in order for you to be able to use the type constructors and functions available in XSLT 2.0.
<G-vec00060-001-s208><declare.deklarieren><de> "Damit automatisch die ""richtige"" Methode verwendet wird, auch wenn der Zeiger oder die Referenz vom Typ der Basisklasse ist, muss die Methode als virtual deklariert werden."
<G-vec00060-001-s208><declare.deklarieren><en> "We need to declare the method as virtual to change this behavior. With a virtual method the ""right"" method is selected automatically, even if the pointer or the reference is from the type of a base class."
<G-vec00060-001-s209><declare.deklarieren><de> Auch wenn alle Parameter explizit definiert wurden, muss die // Funktion oder Klasse als template deklariert werden.
<G-vec00060-001-s209><declare.deklarieren><en> // Note that you still need to declare the function (or class) as a template // even if you explicitly specified all parameters.
<G-vec00060-001-s210><declare.deklarieren><de> Verwenden Sie den Gültigkeitsbereich Arguments als Datenfeld für optionale Argumente, die in der Funktionsdefinition nicht deklariert werden.
<G-vec00060-001-s210><declare.deklarieren><en> Use the Arguments scope as an array for optional arguments that you do not declare in the function definition.
<G-vec00060-001-s211><declare.deklarieren><de> So wird als Rechtfertigung im Stil des psychologischen Konzepts „Blaming the Victim“ das Unternehmen selbst als „betrügerisch“ deklariert.
<G-vec00060-001-s211><declare.deklarieren><en> They therefore justify their actions using the psychological concept of “blaming the victim” and declare the company itself to be fraudulent.
