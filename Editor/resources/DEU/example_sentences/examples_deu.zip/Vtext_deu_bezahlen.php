<G-vec00301-001-s211><settle.bezahlen><de> Berücksichtigen Sie, dass Sie für den Pfand mit Ihrer Kreditkarte bei der Abholung bezahlen müssen.
<G-vec00301-001-s211><settle.bezahlen><en> Please note that you must settle the deposit bill with your credit card when picking up the car.
<G-vec00301-001-s212><settle.bezahlen><de> Bei Ankünften nach 20.00 Uhr nicht im Voraus mit der Anlage vereinbart, gibt es einen Aufpreis von Euro 50,00, vor Ort zu bezahlen.
<G-vec00301-001-s212><settle.bezahlen><en> For arrivals after 20.00 o'clock not previously agreed with the property, there will be a supplement of Euro 50,00 to settle on property.
<G-vec00301-001-s213><settle.bezahlen><de> - Kinder von 0 bis 2 Jahren: kostenloser Aufenthalt, Mahlzeiten nach Verzehr, vor Ort zu bezahlen.
<G-vec00301-001-s213><settle.bezahlen><en> - Children from 0 to 2 years: free of charge, meals upon consumption to settle on property;
<G-vec00301-001-s214><settle.bezahlen><de> "- Buffet-Mittagessen (Restaurant ""Le Piscine""): Buffet-Mittagessen, vom Hotel angeboten, von 13.00 bis 14.30 Uhr, Getränke nicht inbegriffen (vor Ort zu bezahlen)."
<G-vec00301-001-s214><settle.bezahlen><en> "- Buffet lunch (Restaurant ""Le Piscine""): Buffet lunch offered by the property 13.00 to 14.30, drinks not included (to settle on property)."
<G-vec00301-001-s215><settle.bezahlen><de> Bezahlen Sie wiederkehrende Rechnungen bequem mittels SEPA Lastschriftverfahren.
<G-vec00301-001-s215><settle.bezahlen><en> Use SEPA Direct Debit to conveniently settle your recurring subscription invoices.
<G-vec00301-002-s184><settle.bezahlen><de> Wenn Sie sich dafür entscheiden, vor dem normalen Zahlungsplan vollständig zu bezahlen und von der Frühbucherrabatt von 3%, 4% oder 5% profitieren, ist dies die verlängerte Gesamtreduktion.
<G-vec00301-002-s184><settle.bezahlen><en> Should you choose to settle in full ahead of the normal payment schedule, and benefit from the early payment reduction of 3%, 4% or 5%, this is the total reduction extended.
<G-vec00301-002-s186><settle.bezahlen><de> Nach der Buchung müssen Sie innerhalb von 5 Werktagen 30% des Mietpreises bezahlen.
<G-vec00301-002-s186><settle.bezahlen><en> After the booking has been made, you will have to settle 30% of the rental price within 5 working days.
<G-vec00301-002-s187><settle.bezahlen><de> Hier finden Sie zudem zwei Kassenautomaten, an denen Sie Rechnungen und offene Forderungen bar bezahlen können.
<G-vec00301-002-s187><settle.bezahlen><en> You will also find two pay stations here where you can settle invoices and outstanding payments in cash.
<G-vec00301-002-s188><settle.bezahlen><de> Ihre Rechnungen online bezahlen, um den Zahlungszeitraum zu beschleunigen.
<G-vec00301-002-s188><settle.bezahlen><en> Settle your bills online, thus speeding up the reimbursement period.
<G-vec00301-002-s189><settle.bezahlen><de> Der Fallverantwortliche – AUAN Mitglied ist dafür zuständig die Bedürfnisse gemeinsam mit dem Begünstigten zu analysieren, die Einkäufe zu bestätigen und in maximal 2 Tage die Rechnungen die vom Begünstigten übergeben wurden zu bezahlen, wie in dem Individualvertrag zwischen AUAN und dem Begünstigten aufgeführt wurde.
<G-vec00301-002-s189><settle.bezahlen><en> The case administrator – AUAN member – had the responsibility to prioritize the beneficiary’s needs, to give their consent on purchases that would make them beneficial, and, within two days, to settle the invoices received by the beneficiary in accordance with the individual contract concluded between AUAN and the beneficiary.
<G-vec00301-002-s191><settle.bezahlen><de> Der Gast ist verpflichtet, den in den Unterkunftskapazitäten entstandenen Schaden vor der Abreise zu bezahlen.
<G-vec00301-002-s191><settle.bezahlen><en> The guest is obliged to settle the damage caused in the accommodation capacities before departure.
<G-vec00301-002-s192><settle.bezahlen><de> Wir helfen Ihnen, Ihre Schulden zu bezahlen.
<G-vec00301-002-s192><settle.bezahlen><en> We help you settle your debts!
<G-vec00301-002-s193><settle.bezahlen><de> Die erste reale Zahlungslösung für Krypto – ermöglicht Shops, Bars und Geschäften, automatisch durch eine einfache POS App bezahlen zu können.
<G-vec00301-002-s193><settle.bezahlen><en> The first real-world payment solution for crypto – allowing shops, bars and businesses to settle automatically in fiat through a simple POS app.
<G-vec00301-002-s195><settle.bezahlen><de> Wenn ein Zahlungsvorgang nicht erfolgreich war und der Betrag von Ihrem Konto nicht abgezogen wurde, werden Sie bei Ihrem nächsten Kauf über LaterPay erneut gebeten die Rechnung zu bezahlen.
<G-vec00301-002-s195><settle.bezahlen><en> If a payment process was not successful and you were not debited, you will be asked to settle your invoice again when you make your next purchase with LaterPay.
