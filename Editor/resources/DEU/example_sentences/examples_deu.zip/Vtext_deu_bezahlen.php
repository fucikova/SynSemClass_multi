<G-vec00301-001-s211><settle.bezahlen><de> Berücksichtigen Sie, dass Sie für den Pfand mit Ihrer Kreditkarte bei der Abholung bezahlen müssen.
<G-vec00301-001-s211><settle.bezahlen><en> Please note that you must settle the deposit bill with your credit card when picking up the car.
<G-vec00301-001-s212><settle.bezahlen><de> Bei Ankünften nach 20.00 Uhr nicht im Voraus mit der Anlage vereinbart, gibt es einen Aufpreis von Euro 50,00, vor Ort zu bezahlen.
<G-vec00301-001-s212><settle.bezahlen><en> For arrivals after 20.00 o'clock not previously agreed with the property, there will be a supplement of Euro 50,00 to settle on property.
<G-vec00301-001-s213><settle.bezahlen><de> - Kinder von 0 bis 2 Jahren: kostenloser Aufenthalt, Mahlzeiten nach Verzehr, vor Ort zu bezahlen.
<G-vec00301-001-s213><settle.bezahlen><en> - Children from 0 to 2 years: free of charge, meals upon consumption to settle on property;
<G-vec00301-001-s214><settle.bezahlen><de> "- Buffet-Mittagessen (Restaurant ""Le Piscine""): Buffet-Mittagessen, vom Hotel angeboten, von 13.00 bis 14.30 Uhr, Getränke nicht inbegriffen (vor Ort zu bezahlen)."
<G-vec00301-001-s214><settle.bezahlen><en> "- Buffet lunch (Restaurant ""Le Piscine""): Buffet lunch offered by the property 13.00 to 14.30, drinks not included (to settle on property)."
<G-vec00301-001-s215><settle.bezahlen><de> Bezahlen Sie wiederkehrende Rechnungen bequem mittels SEPA Lastschriftverfahren.
<G-vec00301-001-s215><settle.bezahlen><en> Use SEPA Direct Debit to conveniently settle your recurring subscription invoices.
