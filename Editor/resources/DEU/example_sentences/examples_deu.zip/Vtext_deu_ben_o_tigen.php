<G-vec00092-001-s076><need.benötigen><de> Zwar gibt es einige Zeugnisse von Personen, die PhenQ behaupten, dass sie nicht mehr benötigen erarbeiten aufgrund der Tatsache, dass sie zusätzlich auf seine eigene Arbeit zu erwerben Ursprung, medizinische Fachleute empfehlen, immer noch, dass ein Training mit der richtigen Diät-Schema fertig eingebaut werden während der Einnahme diese Ergänzung für garantierte Ergebnisse.
<G-vec00092-001-s076><need.benötigen><en> Though there are some evaluations coming from those that purchase PhenQ stating that it doesn't need anymore exercising due to the fact that it could likewise work on its own, physicians still advise that a workout be performed combined with proper diet plan while taking this supplement for ensured outcomes.
<G-vec00092-001-s077><need.benötigen><de> Diese Cookies enthalten Informationen, die dabei helfen, dem Nutzer bessere Produkte anbieten zu können und Bereiche zu identifizieren, die eine Wartung benötigen.
<G-vec00092-001-s077><need.benötigen><en> These cookies provide information that helps the site owner provide better products to their users and also to identify any areas that may need maintenance.
<G-vec00092-001-s078><need.benötigen><de> Um die Google +1-Schaltfläche verwenden zu können, benötigen Sie ein weltweit sichtbares, öffentliches Google-Profil, das zumindest den für das Profil gewählten Namen enthalten muss.
<G-vec00092-001-s078><need.benötigen><en> In order to use the Google +1 button, you need a globally visible, public Google profile, which must contain at least the chosen name for the profile.
<G-vec00092-001-s079><need.benötigen><de> Damit hier das bloße Atmen nicht bereits zu einer Gefahr wird, benötigen wir ein zuverlässiges Partikelmessgerät wie das BQ20 – unsere kompakte neue Umweltmesseinheit zur Erfassung von Feinstaubbelastung, Lufttemperatur und -feuchte.
<G-vec00092-001-s079><need.benötigen><en> To prevent the simple act of breathing from becoming a hazard, we need a reliable particle measuring device such as the BQ20 – our compact new environment measuring unit for determining fine dust pollution, air temperature and humidity.
<G-vec00092-001-s080><need.benötigen><de> Diese sind wohles gesprochen der Wörter, weil, ob Sie auf ganztägig freiberuflich tätig sein oder den Verkauf Ihrer Romane hinarbeiten, Sie benötigen einen Schaltplan.Ziele sind unentbehrlich.
<G-vec00092-001-s080><need.benötigen><en> These are words well spoken, because whether you're working toward freelancing full-time or selling your novels, you need a roadmap.Goals are indispensable.
<G-vec00092-001-s081><need.benötigen><de> Als ein sehr starkes und leistungsfähiges Produkt sollte nur von denen, die Hilfe benötigen vergießen Pfunde verwendet werden, jedoch nicht in der Lage, den Erfolg mit regelmäßigen Ernährung und Training zu entdecken.
<G-vec00092-001-s081><need.benötigen><en> As a quite powerful and also effective product it need to only be used by those who need aid losing extra pounds, however have not been able to locate success with normal diet plan as well as exercise.
<G-vec00092-001-s082><need.benötigen><de> Alles, was Sie tun müssen, ist die App zum Download, installieren und den Film abspielen Sie benötigen.
<G-vec00092-001-s082><need.benötigen><en> All you have to do is to download the app, install it and play the movie you need.
<G-vec00092-001-s083><need.benötigen><de> Deshalb MVTEAM Hat nicht Aktien, für jeden Auftrag, benötigen wir Bestätigungsobjektiv mit Kunden zuerst, dann wählen zusammengebrachte IR-LED, um zu produzieren.
<G-vec00092-001-s083><need.benötigen><en> That's why MVTEAM doesn't have stocks,for each order,we need confirm lens with customers firstly,then choose matched IR leds to produce.
<G-vec00092-001-s084><need.benötigen><de> Folgend gibt es eine Liste der Dokumente, die Teilnehmer für die Beantragung des Visums benötigen.
<G-vec00092-001-s084><need.benötigen><en> Below is the core list of documents the participant will need for the visa application.
<G-vec00092-001-s085><need.benötigen><de> Greifen Sie über unsere Website auf Ihre Dateien zu, suchen Sie die, die Sie benötigen, und laden Sie sie herunter.
<G-vec00092-001-s085><need.benötigen><en> Access your files from our website, look for the ones you need and download them.
<G-vec00092-001-s086><need.benötigen><de> Die meisten unserer gedruckten Banner sind fertig mit Saum und Ösen, wenn Sie besondere Anforderungen benötigen, können wir auch tun, bitte sagen Sie uns.
<G-vec00092-001-s086><need.benötigen><en> Most of our printed banners are finished with hem&grommets, if you need special requirement, we also can do, please tell us .
<G-vec00092-001-s087><need.benötigen><de> Wenn Sie Probleme mit Malware Protector haben oder nur einen Neustart benötigen, empfehlen wir Ihnen, das Programm auf Ihrem PC neu zu installieren.
<G-vec00092-001-s087><need.benötigen><en> If you are having problems with Malware Protector or just need a fresh start, we highly recommend that you reinstall the program on your PC.
<G-vec00092-001-s088><need.benötigen><de> Wir benötigen eine alternative Visualisierung, die nur bei Verwendung des Filters angezeigt wird.
<G-vec00092-001-s088><need.benötigen><en> We need an alternative visualization, that will only be displayed if the filter is used.
<G-vec00092-001-s089><need.benötigen><de> Er ist größer als die Devas; sie benötigen einen menschlichen Körper, um auf die Erde herabzukommen.
<G-vec00092-001-s089><need.benötigen><en> He is greater than the Devas; they need a human body to come down to earth.
<G-vec00092-001-s090><need.benötigen><de> Gemeinsam mit unseren langjährigen Finanzierungspartnern werden wir ganz sicher zahlreiche spanische KMU erreichen, die Kredite benötigen.
<G-vec00092-001-s090><need.benötigen><en> Working with our long-term partners, I am convinced that together we will be able to reach out to many Spanish SMEs in need of finance.
<G-vec00092-001-s091><need.benötigen><de> Um das Abspielen zu ermöglichen, benötigen wir einen Link zu einer Seite mit einem Brightcove-Player.
<G-vec00092-001-s091><need.benötigen><en> To enable playback, we need to link to a page with a Video Player player on it.
<G-vec00092-001-s092><need.benötigen><de> Für die Anzeige benötigen Sie denAdobe Reader.
<G-vec00092-001-s092><need.benötigen><en> For the opening the document you need Adobe Reader.
<G-vec00092-001-s093><need.benötigen><de> Gesunder, biologisch aktiver Boden stellt nicht nur alle Nährstoffe zur Verfügung, die Deine Cannabispflanzen ihr ganzes Leben lang benötigen, sondern ein guter Boden wird Dir auch helfen, mehrere andere Variablen im Wachstum Deiner Pflanzen zu steuern.
<G-vec00092-001-s093><need.benötigen><en> Healthy, bio active soil not only provides all the nutrients your cannabis plants will need for their whole life, but good soil will help control several other variables in the growth of your plants.
<G-vec00092-001-s094><need.benötigen><de> Die Menschen benötigen dringend internationale Hilfe.
<G-vec00092-001-s094><need.benötigen><en> The people there are in urgent need of international help.
<G-vec00092-001-s076><require.benötigen><de> Hierzu benötigen Sie eine Unbedenklichkeitsbescheinigung für Ihre Firma, die Geschäftsführer sowie (falls erforderlich) Mitglieder der Firma angibt.
<G-vec00092-001-s076><require.benötigen><en> For this, you will require a Certificate of Good Standing for your company, stating the directors and (if required) the shareholders of the company.
<G-vec00092-001-s077><require.benötigen><de> Die Membranfilter sind sehr einfach im Unterhalt, sie funktionieren ohne permanente Zugabe von Chemikalien und benötigen keine Energie – außer zum Pumpen des Wassers aus dem Viktoriasee zur Station.
<G-vec00092-001-s077><require.benötigen><en> Maintenance of the membrane filters is very easy; they function without permanent addition of chemicals and require no energy input – except for pumping the water from Lake Victoria to the station.
<G-vec00092-001-s078><require.benötigen><de> Ihr Geburtsdatum benötigen wir zur Prüfung der bedingungsgemäßen Voraussetzungen für den Abschluss des gewählten Tarifs sowie zu statistischen Zwecken.
<G-vec00092-001-s078><require.benötigen><en> We require your date of birth in order to check the conditional requirements for concluding the selected tariff, as well as for statistical purposes.
<G-vec00092-001-s079><require.benötigen><de> Damit dieser Umwandlungsprozess stattfinden kann, benötigen die Mikroben eine Energiequelle.
<G-vec00092-001-s079><require.benötigen><en> For this transformation process to take place, the microbes require a source of energy.
<G-vec00092-001-s080><require.benötigen><de> Gerade unerfahrene Gründer benötigen Zugang zu Wissen.
<G-vec00092-001-s080><require.benötigen><en> Inexperienced founders in particular require access to knowledge.
<G-vec00092-001-s081><require.benötigen><de> Das bedeutet, dass es auf die Größe und Besonderheiten Ihres speziellen Netzes zugeschnitten werden kann.Sie verwenden einfach die Module, die Sie benötigen, ohne das ganze Paket kaufen zu müssen.
<G-vec00092-001-s081><require.benötigen><en> This means it can be tailored to suit the size and specifics of your particular network. You just use the modules you require without having to buy the entire package.
<G-vec00092-001-s082><require.benötigen><de> Um die Audioqualität auf Perfektion zu tunen, benötigen auch aktive Subwoofer High-End-Kabel.
<G-vec00092-001-s082><require.benötigen><en> In order to ensure perfect audio quality active subwoofers also require high-end cables.
<G-vec00092-001-s083><require.benötigen><de> ConSense-Lösungen sind immer so groß, wie Sie es benötigen und kommen daher in nationalen und internationalen kleinen, mittelständischen und großen Unternehmen zum Einsatz.
<G-vec00092-001-s083><require.benötigen><en> ConSense solutions have just the scope that you require; therefore, they can be used in national and international small, medium-sized and large companies.
<G-vec00092-001-s084><require.benötigen><de> Viele Pflanzen benötigen zwei Haarschnitte für die Saison: Der erste - im Juli oder August, die zweite - von Oktober bis März.
<G-vec00092-001-s084><require.benötigen><en> Many plants require two haircuts for the season: the first - in July or August, the second - from October to March.
<G-vec00092-001-s085><require.benötigen><de> Denn die Folien werden oft nicht ausreichend recycelt, und beide benötigen fossile Brennstoffe zur Herstellung, was wiederum Treibhausgase erzeugt, die zum Klimawandel beitragen.
<G-vec00092-001-s085><require.benötigen><en> Neither is regularly recycled and both require fossil fuels to produce, the Slate reported, which generates greenhouse gases that contribute to climate change.
<G-vec00092-001-s086><require.benötigen><de> Pokerspiele können Herausforderung werden, wie Sie eine Mischung aus wissen, Fähigkeiten und Kontrolle benötigen.
<G-vec00092-001-s086><require.benötigen><en> Poker games can be challenging as they require a mixture of knowledge, skill and control.
<G-vec00092-001-s087><require.benötigen><de> Alle Passagiere (Inlands- oder Auslandsflüge), die Sauerstoff benötigen, jedoch mit einem tragbaren Sauerstoffkonzentrator zurecht kommen und deren Gesundheitszustand dies auch zulässt.
<G-vec00092-001-s087><require.benötigen><en> All passengers (international or domestic) who require oxygen but will be able to cope with portable oxygen concentrator and their medical condition permit use of POC.
<G-vec00092-001-s088><require.benötigen><de> Kompressionskältemaschinen, die große Mengen an elektrischer Energie benötigen, können mittels Absorptionsprozess sowie verfügbare Abwärmepotenziale ersetzt werden.
<G-vec00092-001-s088><require.benötigen><en> Vapour-compression chillers, which require a considerable amount of electrical energy, can be replaced by utilising absorption processes and the available waste heat potential.
<G-vec00092-001-s089><require.benötigen><de> Lokalität: Civic Centre, Preis ab: 150 € pro Nacht Die ungefähren Übersetzung der Beschreibung des Hotels: Wenn Sie möchten Ihren Urlaub in San Francisco verbringen, dann wählen Sie das Hotel Del Sol, die den Komfort und Privatsphäre, die jeder und verdienen benötigen für einen Urlaub bietet.
<G-vec00092-001-s089><require.benötigen><en> Locality: Civic Centre, price from: 150 € per night If you like to spend your holidays in San Francisco, then choose the Hotel Del Sol that offers the comfort and privacy that anyone deserve and require for a vacation.
<G-vec00092-001-s090><require.benötigen><de> Stärkere Kupferlagen für höhere Stromstärken, Aluminium oder Keramik als Trägermaterial benötigen speziell angepasste Fertigungsmaschinen.
<G-vec00092-001-s090><require.benötigen><en> Thicker layers of copper for higher currents, aluminium or ceramic as carrier material require specially adapted production equipment.
<G-vec00092-001-s091><require.benötigen><de> Sollten Sie weitere Optionen anzuzeigen benötigen, Wir haben auch eine leicht zu bedienende Farbwähler enthalten, mit dem Sie jede beliebige Farbe auswählen, die Sie mögen.
<G-vec00092-001-s091><require.benötigen><en> Should you require more color options, we have also included an easy to use color picker that allows you to select any color you like.
<G-vec00092-001-s092><require.benötigen><de> If you have allowed the Untotlowith.info site to send notifications in your browser, dann benötigen Sie diese Berechtigungen löschen.
<G-vec00092-001-s092><require.benötigen><en> If you have allowed the Untotlowith.info site to send notifications in your browser, then you will require to erase these authorizations.
<G-vec00092-001-s093><require.benötigen><de> Beispielsweise benötigen wir personenbezogene Daten, um Kauf- und Lizenzverträge abwickeln und Ihnen bestellte Ware liefern zu können.
<G-vec00092-001-s093><require.benötigen><en> For example, we require personal data in order to process sale and license agreements and so that we can send you the products that you have ordered.
<G-vec00092-001-s094><require.benötigen><de> Diese benötigen 6,400 Reagenzien-Sets, mit 14,000 Reagenzien und Kontrollsubstanzen, sowie 160 Zubehörartikeln wie Pipetten und Küvetten.
<G-vec00092-001-s094><require.benötigen><en> These require 6,400 reagent kits, with 14,000 reagent and control components, and 160 consumables such as pipettes and cuvettes.
<G-vec00092-001-s095><require.benötigen><de> Die Anlagen zur Gewinnung der erneuerbaren Energien benötigen dagegen eine kontinuierliche Wartung und Instandhaltung.
<G-vec00092-001-s095><require.benötigen><en> Systems for the generation of renewable energy require continuous repair and maintenance works.
<G-vec00092-001-s096><require.benötigen><de> Anfänger, die den Forex-Handel noch nicht gänzlicherforscht haben, benötigen möglicherweise eine Erläuterung der Berechnungsdaten, die sie vom Handelsrechner erhalten.
<G-vec00092-001-s096><require.benötigen><en> Beginner traders, who haven’t sifted the Forex trading to the bottom, may require explanation of the calculation data they get from the Trading calculator.
<G-vec00092-001-s097><require.benötigen><de> Darüber hinaus benötigen temporäre Mieter eine Unterkunft in allen Segmenten des Kapitalimmobilienmarktes.
<G-vec00092-001-s097><require.benötigen><en> Moreover, temporary renters require accommodation in all segments of the capital real estate market.
<G-vec00092-001-s098><require.benötigen><de> Wir benötigen dabei eine besonders hohe Qualität der Lithium-Vorprodukte vom Markt.
<G-vec00092-001-s098><require.benötigen><en> Therefore we require lithium of especially high quality from the market.
<G-vec00092-001-s099><require.benötigen><de> Computer müssen nicht nur auf ihr Netzwerk synchronisiert werden, sondern auch zeitempfindliche Transaktionen mit anderen Netzwerken, Computern oder über das Internet benötigen auch eine Synchronisation.
<G-vec00092-001-s099><require.benötigen><en> Computers need to not only be synchronized to their network but and time sensitive transactions with other networks, computers or over the Internet also require synchronization.
<G-vec00092-001-s100><require.benötigen><de> Einige medizintechnischen Geräte benötigen eine Registrierung von der chilenischen Behörde für öffentliche Gesundheit (ISP); Der Prozess braucht im Schnitt 60 Arbeitstage.
<G-vec00092-001-s100><require.benötigen><en> Some medical devices require registration by the Chilean Institute of Public Health (ISP); the process takes an average of 60 working days.
<G-vec00092-001-s101><require.benötigen><de> Sicherheitskräfte benötigen eine robuste Technologie, die einfach zu bedienen ist und eine optimale Klangqualität garantiert.
<G-vec00092-001-s101><require.benötigen><en> Security guards require sturdy technology that is simple to use and provides the best sound quality possible.
<G-vec00092-001-s102><require.benötigen><de> Newsletterdaten Wenn Sie den auf der Webseite angebotenen Newsletter beziehen möchten, benötigen wir von Ihnen eine E-Mail-Adresse sowie Informationen, welche uns die Überprüfung gestatten, dass Sie der Inhaber der angegebenen E-Mail-Adresse sind und mit dem Empfang des Newsletters einverstanden sind.
<G-vec00092-001-s102><require.benötigen><en> Newsletter data When you would like to receive the newsletter offered on this website, we require your e-mail address as well information, which allow us to check whether your are the owner of the e-mail address and agree with receiving the newsletter.
<G-vec00092-001-s103><require.benötigen><de> In einer Sache sind die Kräuter aber gleich: Alle Sorten mögen es warm und sonnig und benötigen eine ausreichende Bewässerung.
<G-vec00092-001-s103><require.benötigen><en> However, in one respect, the herbs are the same: all varieties like warm, sunny places and require sufficient watering.
<G-vec00092-001-s104><require.benötigen><de> Wenn die Hecke über dichte Blätter und dicke Äste verfügt, benötigen Sie eine leistungsfähigere Maschine mit einem breiteren Zahnabstand als eine Maschine, die für kleine Hecken im privaten Garten entwickelt wurde.
<G-vec00092-001-s104><require.benötigen><en> If the hedge has dense leaves and thick branches you will require more powerful machine with a wider blade gap than a machine designed for small domestic garden hedges.
<G-vec00092-001-s105><require.benötigen><de> Unternehmen, die Schlachtkörper von Rindern, Schweinen und Schafen in gesetzliche Handelsklassen und Kategorien (Fleischklassifizierung) einstufen, benötigen nach den Vorschriften des Fleischgesetzes eine Zulassung.
<G-vec00092-001-s105><require.benötigen><en> Enterprises which grade carcasses of bovines, pigs, and sheep according to classes and categories (meat classification) require accreditation pursuant to the Meat Law.
<G-vec00092-001-s106><require.benötigen><de> Polizeibeamte benötigen im Allgemeinen eine robuste körperliche Eignung und emotionale Stabilität.
<G-vec00092-001-s106><require.benötigen><en> Police officers generally require robust physical qualifications and emotional stability.
<G-vec00092-001-s107><require.benötigen><de> Reisende aus Deutschland benötigen für eine Einreise in Mauritius lediglich einen Reisepass, der noch über das Ende der Reise hinaus gültig sein muss.
<G-vec00092-001-s107><require.benötigen><en> Travellers from Germany require only their passport to enter Mauritius, however, it has to be valid beyond their travel dates.
<G-vec00092-001-s108><require.benötigen><de> Um den Vorgang abzuschließen und auch die ganzen Vorteile der wichtigen physikalischen zu erhalten und auch geistige Wiederherstellungsprozedur, benötigen Sie eine angemessene Ruhezeiten jeden Abend.
<G-vec00092-001-s108><require.benötigen><en> To complete the procedure and also obtain the whole advantages of the important physical and also mental recovery procedure, you require adequate hours of rest each evening.
<G-vec00092-001-s109><require.benötigen><de> Wearables benötigen heute meist eine Batterie oder einen Akku für den Betrieb.
<G-vec00092-001-s109><require.benötigen><en> Teilen Sie diese Seite auf Xing. Today wearables require a battery for operation.
<G-vec00092-001-s110><require.benötigen><de> Pressekontakte Pressedienste AKKREDITIERUNG Journalisten, Filmteams und Fotografen benötigen eine Akkreditierung, um Zugang zu den Gebäuden der EU-Institutionen zu erhalten.
<G-vec00092-001-s110><require.benötigen><en> Press facilities ACCREDITATION Journalists, film crews and photographers require accreditation in order to access the EU institution buildings.
<G-vec00092-001-s111><require.benötigen><de> Allerdings: IoT-Anwendungen wie autonomes Fahren, Connected Car oder auch Fern-Operationen benötigen eine Technik, die Daten nahezu in Echtzeit übertragen kann.
<G-vec00092-001-s111><require.benötigen><en> IoT applications such as autonomous driving, connected car and remote operations require data to be transmitted almost in real-time.
<G-vec00092-001-s112><require.benötigen><de> Lebensmittelproduzenten, -logistiker und -händler stehen vor der gleichen Herausforderung: Sie alle benötigen eine Zertifizierung nach einem GFSI-Standard.
<G-vec00092-001-s112><require.benötigen><en> Food producers, logistics service providers and retailers all face the same challenge: they all require certification according to a GFSI standard.
<G-vec00092-001-s113><require.benötigen><de> "Menschen, die aus welchem Grunde auch immer, nicht in der Lage sind, Treppen zu begehen benötigen eine Alternative, einen ""Zweiten Kanal""."
<G-vec00092-001-s113><require.benötigen><en> People, who for whatever reason are not capable of climbing stairs, require a second, alternative channel.
<G-vec00092-001-s095><need.benötigen><de> Wenn Du Unterstützung bei der Installation des Plugins benötigst kannst Du gerne Kontakt zu uns aufnehmen.
<G-vec00092-001-s095><need.benötigen><en> If you need support with the installation of the plugin you can contact us.
<G-vec00092-001-s096><need.benötigen><de> Ganze Mengen davon, besonders dann, wenn es sich um ein langfristiges Projekt handelt oder du teure Ausrüstung benötigst, um was immer du auch erforscht, zu erforschen.
<G-vec00092-001-s096><need.benötigen><en> Buckets and buckets of money, especially if you're doing it long-term or need expensive supplies to get whatever it is you're studying studied.
<G-vec00092-001-s097><need.benötigen><de> Wenn Du bei Problemen Hilfestellung benötigst, hast Du die Möglichkeit, Dich per E-Mail, Telefon oder Live-Chat mit dem Support in Verbindung zu setzen.
<G-vec00092-001-s097><need.benötigen><en> If you need customer support, you will have the option to reach out via email, phone, or live chat.
<G-vec00092-001-s098><need.benötigen><de> Wie mit alles mußt du eine Schule finden, die dich mit allen Materialien versehen kann, die, du bei der Rechtfertigung der Rechnung ihres Lehrplans benötigst.
<G-vec00092-001-s098><need.benötigen><en> Like with everything, you need to find a school that can provide you with all the stuffs you need while justifying the bill of their curriculum.
<G-vec00092-001-s099><need.benötigen><de> Wenn du weniger Klebstoff benötigst, beginne mit deiner gewünschten Mehlmenge und gib das Wasser teelöffelweise hinzu, bis die Masse die richtige Konsistenz hat.
<G-vec00092-001-s099><need.benötigen><en> If you need less glue, start with the amount of flour you will use, then add water, a teaspoon at a time, until it reaches the right consistency.
<G-vec00092-001-s100><need.benötigen><de> Eine Agentur ist dann zu empfehlen, wenn Du viele Freelancer mit unterschiedlichen Fähigkeiten für viele unterschiedliche Aufgaben benötigst.
<G-vec00092-001-s100><need.benötigen><en> An agency is more beneficial when you need freelancers with different skill sets and have a high volume of work that needs to be done.
<G-vec00092-001-s101><need.benötigen><de> TIERHANDLUNG: Hier findest du alles, was du für deine Haustiere benötigst – zum Bürsten, Pflegen, Füttern und Spielen.
<G-vec00092-001-s101><need.benötigen><en> PET SHOP: Find everything you need for to groom, feed, play with and care for your pets at the pet shop.
<G-vec00092-001-s102><need.benötigen><de> Wenn du zusätzliche Abdeckung benötigst oder dein Teint unregelmäßig ist, dann verwende dazu noch Foundation.
<G-vec00092-001-s102><need.benötigen><en> Use foundation if you need extra coverage or if your skin tone is uneven.
<G-vec00092-001-s103><need.benötigen><de> Durch die neuesten Innovationen im Bereich der Wearable-Technologie bietet dir die Polar Vantage V Multisportuhr die genauesten Daten, die du zur Optimierung deiner Leistung benötigst.
<G-vec00092-001-s103><need.benötigen><en> Cutting-edge sports technology The latest wearable tech innovations make sure Polar Vantage V gives you all the accurate data you need to maximize your performance.
<G-vec00092-001-s104><need.benötigen><de> SPORTHOSEN & TIGHTS Alles, was du in Sachen Sporthosen benötigst.
<G-vec00092-001-s104><need.benötigen><en> TRAINING PANTS & TIGHTS Everything you need in sport pants.
<G-vec00092-001-s105><need.benötigen><de> Nur Sonderangebote Beschreibung Zur Wasserpflege im Aquarium gehört alles, was Du zur Wasseraufbereitung, Mineralienversorgung, Aquariendüngung der Pflanzen, zur Sauerstoffversorgung für die Garnelen und Fische und zum Testen des Aquariumwassers selbst benötigst.
<G-vec00092-001-s105><need.benötigen><en> Description The water treatment in the aquarium includes everything that you need for water conditioning, mineral supply, fertilize the water plants, oxygen supply for shrimp and fish, and to test the aquarium water itself.
<G-vec00092-001-s106><need.benötigen><de> Um starke Firewalls umgehen zu können, benötigst Du ein VPN mit mehreren Sicherheitsprotokollen und verschiedenen Verschlüsselungsebenen.
<G-vec00092-001-s106><need.benötigen><en> To bypass strong firewalls, you’re going to need a VPN with multiple security protocols and various layers of encryptions.
<G-vec00092-001-s107><need.benötigen><de> Das SuperNOVA 1600 gibt Dir die Power, die Du benötigst, um solch anspruchsvolle Systeme zu betreiben und beste Overclocking Ergebnisse zu erzielen.
<G-vec00092-001-s107><need.benötigen><en> The SuperNOVA 1600 gives you the power you need to drive these demanding systems and achieve the best overclocks.
<G-vec00092-001-s108><need.benötigen><de> Wenn Du ein SSL-Zertifikat benötigst, musst Du dafür bezahlen.
<G-vec00092-001-s108><need.benötigen><en> If you need an SSL certificate, you’re going to pay for it.
<G-vec00092-001-s109><need.benötigen><de> Du benötigst eventuell einen Zahnstocher oder ein Wattestäbchen, um an die schwer zu erreichenden Stellen zu kommen.
<G-vec00092-001-s109><need.benötigen><en> You may need to use a toothpick or a Q-tip to get in those hard-to-reach places.
<G-vec00092-001-s110><need.benötigen><de> - Du benötigst einen Account für jeden Nutzer.
<G-vec00092-001-s110><need.benötigen><en> - You need an account for each user.
<G-vec00092-001-s111><need.benötigen><de> Du benötigst alle diese Tools für die Übersetzung.
<G-vec00092-001-s111><need.benötigen><en> You need these tools in the process of compiling.
<G-vec00092-001-s112><need.benötigen><de> Mit einer Helligkeit von 400 Lumen und einer Akkulaufzeit von bis zu 15 Stunden kannst du so lange draußen bleiben, wie du zum Abspulen deiner Laufkilometer benötigst.
<G-vec00092-001-s112><need.benötigen><en> With 400 lumens of brightness and up to 15 hours of battery life, you can stay out as long as you need in order to check off the miles.
<G-vec00092-001-s113><need.benötigen><de> Mit aller Wahrscheinlichkeit hat die erweckte göttliche Kraft in dir beschlossen, dass du diese Erfahrungen nicht benötigst.
<G-vec00092-001-s113><need.benötigen><en> In all probability, the divine force awakened in you has perhaps decided that you don't need these experiences.
<G-vec00092-001-s114><need.benötigen><de> Vollständige Details Pflanzen-Haarfarbe 060 Nußbraun-Kastanie$7,73 $7,35 100 g Produktinformationen Calcium & Magnesium complex - bioPreis: $28,80 $27,37 Magnesium und Calcium sind zwei lebensnotwendige Mineralstoffe, die unser Körper für die Aktivierung und Erhaltung zahlreicher biologischer Prozesse benötigt.
<G-vec00092-001-s114><need.benötigen><en> Full details Inner Strength Tea - organic$5.78 $5.21 70 g Product information Calcium & Magnesium complex - organicPrice: $28.80 $27.37 Magnesium and calcium are two vital minerals that our body need to activate and maintain numerous biological processes.
<G-vec00092-001-s115><need.benötigen><de> Wer für Veranstaltungen werben möchte oder ein einfaches wie effizientes Beschilderungssystem für Events oder Wahlen benötigt, hat mit Hohlkammerplakaten das perfekte Produkt gefunden.
<G-vec00092-001-s115><need.benötigen><en> If you want to advertise an event or need a simple and efficient signage system for events or elections, corrugated plastic posters are the perfect product for you.
<G-vec00092-001-s116><need.benötigen><de> Der Herr benötigt ein gefestigtes Herz Natürlich war Elijahs große Manifestation davon das Geschehen auf dem Karmel.
<G-vec00092-001-s116><need.benötigen><en> The Lord's Need of a Fixed Heart Of course Elijah's great manifestation of this was at Carmel.
<G-vec00092-001-s117><need.benötigen><de> Salatgewürz - bio9,08 € 8,63 € 250 g Produktinformationen Calcium & Magnesium complex - bioPreis: 24,66 € 23,43 € Magnesium und Calcium sind zwei lebensnotwendige Mineralstoffe, die unser Körper für die Aktivierung und Erhaltung zahlreicher biologischer Prozesse benötigt.
<G-vec00092-001-s117><need.benötigen><en> Borage oil - organic11.50 € 9.35 € 100 ml Product information Calcium & Magnesium complex - organicPrice: 24.66 € 23.43 € Magnesium and calcium are two vital minerals that our body need to activate and maintain numerous biological processes.
<G-vec00092-001-s118><need.benötigen><de> CalenGoo Google Calendar Die App ermöglicht es, lange Notizen zu den Aufgaben zu verfassen, ein nützliches Feature, wenn man viele Informationen für eine Aufgabe benötigt.
<G-vec00092-001-s118><need.benötigen><en> CalenGoo Google Calendar The app allows you to attach long notes to your tasks, a useful feature when you need to write down a lot of information about a task.
<G-vec00092-001-s119><need.benötigen><de> Nach Riva läuft man außerdem nur 20min, wofür man kein Auto benötigt.
<G-vec00092-001-s119><need.benötigen><en> Riva also you just walk 20 minutes, for which you need a car.
<G-vec00092-001-s120><need.benötigen><de> Durch die aktive Stromverteilung gelangt die benötigte Energie genau dorthin, wo man sie benötigt, hat man also nur zwei Akkus im Ladeschacht, können diese mit kraftvollen 750mA pro Zelle geladen werden.
<G-vec00092-001-s120><need.benötigen><en> Due to the active power distribution, the required energy reaches exactly where you need it, so if you only have two batteries in the charging bay, they can be charged with powerful 750mA per cell.
<G-vec00092-001-s121><need.benötigen><de> Die Menschheit benötigt moralische Integrität.
<G-vec00092-001-s121><need.benötigen><en> Humanity is in need of moral integrity.
<G-vec00092-001-s122><need.benötigen><de> OpenBSD benötigt andauernd bestimmte Arten von Unterstützung von der Benutzergemeinschaft.
<G-vec00092-001-s122><need.benötigen><en> OpenBSD has a constant need for several types of support from the user community.
<G-vec00092-001-s123><need.benötigen><de> Wenn mal wieder alle USB 3.0 Ports belegt sind, man doch aber dringend die Daten vom USB- Stick benötigt, könnte dieser Kandidat echte Abhilfe schaffen.
<G-vec00092-001-s123><need.benötigen><en> If all USB 3.0 ports are occupied but you urgently need the data from the USB stick, this Hub could provide real help.
<G-vec00092-001-s124><need.benötigen><de> "In einem Flugzeit-Instrument wird die Energie des Neutrons durch die ""Flugzeit"", die das Neutron für das Zurücklegen einer wohldefinierten Strecke benötigt, bestimmt."
<G-vec00092-001-s124><need.benötigen><en> In a time-of-flight instrument the energy of the neutron is determined by the 'time-of-flight' the neutrons need to travel a well-defined distance.
<G-vec00092-001-s125><need.benötigen><de> "Das ""Black Prince"" Kit beinhaltet beinahe alle Teile die benötigt werden um sich sein eigenes Custom Bike bauen zu können."
<G-vec00092-001-s125><need.benötigen><en> "The ""Black Prince"" kits contain almost any part you need to build your own Custom motorcycle."
<G-vec00092-001-s126><need.benötigen><de> Unser Team benötigt Details dazu, welche Artikel du verloren hast (wenn dies der Fall ist), sowie das genaue Datum und die Uhrzeit des Verlusts.
<G-vec00092-001-s126><need.benötigen><en> Our team will need information about what items (if any) you have lost, plus the date and time that you lost them.
<G-vec00092-001-s127><need.benötigen><de> Alle durch BERCHTOLD zugänglich gemachten geschäftlichen oder technischen Informationen (einschließlich Merkmalen, auch wenn sie sich mittelbar aus den übergebenen Gegenständen, Dokumenten oder Software ergeben, und sonstige Kenntnisse oder Erfahrungen) sind, solange und soweit sie nicht nachweislich öffentlich bekannt sind, Dritten gegenüber geheim zu halten und dürfen im eigenen Betrieb des LIEFERANTEN nur solchen Personen zur Verfügung gestellt werden, die zur Erbringung der Leistung BERCHTOLD gegenüber von diesen notwendigerweise benötigt werden und die ebenfalls zur Geheimhaltung verpflichtet sind.
<G-vec00092-001-s127><need.benötigen><en> All commercial and technical information made available by BERCHTOLD (including features, even if these are indirectly derivable from objects, documents or software provided, and any other knowledge or experience) must be kept secret for as long and to the extent that it is not proven public knowledge and may only be made accessible to those persons at Supplier's facility who necessarily need to use it for the purpose of supply to BERCHTOLD and who have likewise been bound to secrecy.
<G-vec00092-001-s128><need.benötigen><de> Ein idealer Transformator weist keinen Verlust auf, speichert keine Energie und benötigt keinen Magnetisierungsstrom.
<G-vec00092-001-s128><need.benötigen><en> An ideal transformer shows no loss, does not accumulate energy and does not need magnetising current.
<G-vec00092-001-s129><need.benötigen><de> Der Regler benötigt während der Programmierung keine zusätzliche Spannungsversorgung, sondern wird via USB-Schnittstelle gespeist.
<G-vec00092-001-s129><need.benötigen><en> The controller does not need to be connected to another voltage supply during programming because the power comes from a USB interface.
<G-vec00092-001-s130><need.benötigen><de> Für den Fall, dass man sich entschieden hat, dass man als gelernter Masseur sich selbstständig macht und vor allem auf die Kundschaft abzielen, die in ihrem eigenen Haus behandelt werden möchte, der benötigt einige wesentliche Utensilien, die möglichst leicht natürlich auch noch transportiert werden können.
<G-vec00092-001-s130><need.benötigen><en> If you have decided that you are a qualified massage therapist and you want to be treated in your own house, you need some essential utensils, which can be transported as easily as possible, Because if the masseur goes to a customer, then of course it does not look as if he would move out of his house or move into the patient.
<G-vec00092-001-s131><need.benötigen><de> Für das Lesen eines heruntergeladenen Titels wird die Software Adobe Digital Editions benötigt.
<G-vec00092-001-s131><need.benötigen><en> To read a downloaded item you will need the Adobe Digital Editions software.
<G-vec00092-001-s132><need.benötigen><de> Man benötigt 1kg Hokkaidokürbis-Fruchtfleisch, 4 Äpfel, 2 Mohrrüben, ½ Zitrone, 100ml Honig, 20g frisch geriebenen Ingwer (oder 1 TL zerhackten Ingwer) und ½ Vanillestange.
<G-vec00092-001-s132><need.benötigen><en> You will need 1 kg hokkaido meat, 4 apples, 2 carrots, ½ of a lemon, 1 dl. Honey, 20 g freshly grated ginger (or 1 tsp. ginger powder), and ½ pod vanilla.
<G-vec00092-001-s114><require.benötigen><de> Beachten Sie bitte, dass für Dienste die MobileTogether Server Advanced Edition benötigt wird.
<G-vec00092-001-s114><require.benötigen><en> Please note that services require use of the MobileTogether Server Advanced Edition.
<G-vec00092-001-s115><require.benötigen><de> Um den Bedarf der 3,3 Millionen Einwohner des Landes zu decken, wird nach Regierungsschätzungen eine jährliche Produktion von etwa 29,8 Tonnen benötigt.
<G-vec00092-001-s115><require.benötigen><en> Meeting the needs of the nation of 3.3 million people will require annual production of about 29.8 tons, the government estimates, and cannabis will be cultivated in a plantation of roughly 100 hectares.
<G-vec00092-001-s116><require.benötigen><de> TSCHECHISCHE REPUBLIK INTERRAIL ZUGRESERVIERUNGEN Welcher Zug benötigt eine Interrail Reservierung.
<G-vec00092-001-s116><require.benötigen><en> CZECH REPUBLIC INTERRAIL TRAIN RESERVATIONS What trains require an Interrail reservation.
<G-vec00092-001-s117><require.benötigen><de> Der CSV-6200H ist Plug & Play und benötigt keine Treiberinstallation.
<G-vec00092-001-s117><require.benötigen><en> The CSV-6200H is Plug & Play and does not require any driver installation.
<G-vec00092-001-s118><require.benötigen><de> Klassik Die komponierte Musik der Vergangenheit und Gegenwart benötigt für ihre konkrete Realisierung handwerklich und künstlerisch fundiert ausgebildete Interpreten und Interpretinnen.
<G-vec00092-001-s118><require.benötigen><en> Classical The musical compositions of the past and present require technically and artistically well-educated interpreters for their performance.
<G-vec00092-001-s119><require.benötigen><de> Die energetisch gekoppelte Lufthaube wird ausschließlich durch die IR-Abwärme erwärmt und benötigt daher keine eigene Wärmequelle.
<G-vec00092-001-s119><require.benötigen><en> The energetically coupled air hood is heated solely by the IR waste heat and thus does not require its own heat source.
<G-vec00092-001-s120><require.benötigen><de> In der PTB wurde ein Kriterium für diese Wahl entwickelt, welches keine Parameter benötigt, um die optimale Anzahl zu bestimmen.
<G-vec00092-001-s120><require.benötigen><en> At PTB, a criterion for the selection of the number of iterations has been developed which does not require any parameters in order to determine the optimal number.
<G-vec00092-001-s121><require.benötigen><de> Zudem benötigt diese Monatslinse keine zusätzliche Oberflächenbeschichtung, so dass Sie mittels der ausgewogenen Materialeigenschaft Ihren Augen eine gelungene Balance zwischen guter Benetzbarkeit und hoher Sauerstoffdurchlässigkeit bieten.
<G-vec00092-001-s121><require.benötigen><en> Moreover, these monthly disposable lenses do not require additional surface coating, so that they offer your eyes a successful balance between good lubrication and high permeability to oxygen due to their well-balanced material properties.
<G-vec00092-001-s122><require.benötigen><de> Diese Version benötigt Origin nicht und du konntest bis jetzt den Launcher/Origin überspringen.
<G-vec00092-001-s122><require.benötigen><en> This version does not require Origin in any way and let you bypass the launcher/Origin in the past.
<G-vec00092-001-s123><require.benötigen><de> Die SLCI4404 rechten Winkel Laptop 44-Pin IDE Female To CF Card Adapter ist transparent für das Betriebssystem und benötigt keine Treiber.
<G-vec00092-001-s123><require.benötigen><en> The SLCI4404 Right-angle Laptop 44-Pin Female IDE To CF Card Adapter is transparent to the operating system and does not require any drivers.
<G-vec00092-001-s124><require.benötigen><de> Der Benutzer, der den zugehörigen Job aufgezeichnet hat oder den AppServer aufruft, benötigt hingegen keine Berechtigung.
<G-vec00092-001-s124><require.benötigen><en> The user who has recorded the corresponding job or accesses the AppServer, however, does not require any authorization.
<G-vec00092-001-s125><require.benötigen><de> BOSNIEN-HERZEGOWINA INTERRAIL ZUGRESERVIERUNGEN Welcher Zug benötigt eine Interrail Reservierung.
<G-vec00092-001-s125><require.benötigen><en> BOSNIA-HERZEGOVINA INTERRAIL TRAIN RESERVATIONS What trains require an Interrail reservation.
<G-vec00092-001-s126><require.benötigen><de> ** NVIDIA 3D Vision und Surround benötigt 3D Vision Brille und 3D Vision ready displays.
<G-vec00092-001-s126><require.benötigen><en> ** NVIDIA 3D Vision and Surround require 3D Vision glasses and 3D Vision ready displays.
<G-vec00092-001-s127><require.benötigen><de> Die ToonTalk Test-Version benötigt kein Passwort.
<G-vec00092-001-s127><require.benötigen><en> The trial version of ToonTalk does not require a password.
<G-vec00092-001-s128><require.benötigen><de> Im Gegensatz zu anderen LED Lampen benötigt die Radii Plus keinen Ventilator.
<G-vec00092-001-s128><require.benötigen><en> Unlike other LED lights, the Radii Plus does not require a fan.
<G-vec00092-001-s129><require.benötigen><de> """In Gasanalysesystemen werden Messgaspumpen benötigt, wenn der Prozessdruck nicht ausreicht, um Messgas sicher und in genügender Menge zu den Analysatoren zu fördern."
<G-vec00092-001-s129><require.benötigen><en> """Sample gas analysis systems require sample gas pumps if the process pressure is not sufficient to safely transport adequate volumes of sample gas to the analysers."
<G-vec00092-001-s130><require.benötigen><de> Nicht zuletzt können Sie die NOCK Döner- und Gyros-Schneidemaschinen mit dem einmaligen NOCK Produkt-Rückführsystem® kaufen, welches keinerlei zusätzlichen Platz benötigt, sehr preisgünstig ist und Ihre Produktionskosten erheblich senkt.
<G-vec00092-001-s130><require.benötigen><en> Last but not least the NOCK Doner and Gyros cutting machines can be purchased with the unequalledÂ NOCK Integrated Product Return System® Â . This does not require any extra space, is very good value and considerably reduces the production costs.
<G-vec00092-001-s131><require.benötigen><de> Die älteren Methoden basieren auf verschiedenen biologischen Prozessen, bei denen fäkale Feststoffe enthaltende Abwässer(Schwarzwasser von Vakuumtoiletten und Küchen) nach weniger strengen internationalen Standards behandelt werden, während Grauwasserströme (von Wohnkabinen und Wäscherei, möglicherweise auch von Swimmingpools) direkt und unbehandelt ins Meer geleitet werden.Der MBR-Prozess ist vollautomatisiert, leicht kontrollierbar und benötigt keine Überwachung durch geschultes Personal, um effektiv zu arbeiten.
<G-vec00092-001-s131><require.benötigen><en> These normally rely on various biological processes to treat 'black' waste water streams (from vacuum toilets and galley waters) to less stringent international standards, with 'grey' waste water streams (from accommodation, the laundry and possibly also swimming pools) discharged straight to the sea, untreated.The MBR process is fully automated and highly controllable, and does not require monitoring by skilled personnel to work effectively.
<G-vec00092-001-s132><require.benötigen><de> Denjenigen, die Angst vor dem Verlust ihrer materiellen Besitztümer haben, sage ich, wisst, dass ihr nur das verliert, was ihr in der fünften Dimension nicht mehr benötigt.
<G-vec00092-001-s132><require.benötigen><en> To those who are in fear of losing their material possessions, I say, know that you will lose only that which you no longer require in the fifth dimension.
<G-vec00092-001-s133><require.benötigen><de> Es enthält auch ein umfangreiches englisch-indogermanisches, indogermanisch-englisches Vokabular sowie detaillierte etymologische Notizen, die den Lesern einen leichten Zugang zu den benötigten Informationen ermöglichen.
<G-vec00092-001-s133><require.benötigen><en> It also contains an extensive English – Indo-European, Indo-European – English vocabulary, as well as detailed etymological notes, designed to provide readers with an easy access to the information they require.
<G-vec00092-001-s134><require.benötigen><de> Basierend auf der von Ihnen benötigten Unterstützung weisen wir Ihnen kostenlos einen geeigneten Sitzplatz zu – es ist nicht notwendig, dass Sie bei der Buchung einen Sitzplatz reservieren.
<G-vec00092-001-s134><require.benötigen><en> It's not necessary for you to reserve a seat when making a booking if you request special assistance. We'll assign you a suitable seat free of charge when you check in at the airport, based on the type of assistance you require.
<G-vec00092-001-s135><require.benötigen><de> Gelangen Sie hier direkt zu Ihrem benötigten Kunststoff.
<G-vec00092-001-s135><require.benötigen><en> Here you can get directly to the plastic you require.
<G-vec00092-001-s136><require.benötigen><de> Einige Seiten auf dieser Website benötigten Cookies, um richtig zu funktionieren.
<G-vec00092-001-s136><require.benötigen><en> Some pages on this website require Cookies to be enabled to work correctly.
<G-vec00092-001-s137><require.benötigen><de> Ab sofort erhalten Sie Ihre benötigten Produkte noch schneller: Sie sehen sofort Ihren individuellen Preis und die aktuelle, tatsächliche Verfügbarkeit.
<G-vec00092-001-s137><require.benötigen><en> You can receive the products you require even quicker: you see your personalised price and current, actual availability immediately.
<G-vec00092-001-s138><require.benötigen><de> Sehr viele Besucher nutzten die Gelegenheit um der Laborgerätebörse ihre nicht mehr benötigten Laborgeräte anzubieten.
<G-vec00092-001-s138><require.benötigen><en> A large number of visitors took the opportunity of offering Labexchange pieces of laboratory equipment which they no longer require.
<G-vec00092-001-s139><require.benötigen><de> Sollten Sie dennoch keinen Zugang zu benötigten Informationen haben, können Sie uns gerne per Telefon oder E-Mail kontaktieren.
<G-vec00092-001-s139><require.benötigen><en> Should you nevertheless have no access to the information you require you are very welcome to phone or e-mail us.
<G-vec00092-001-s140><require.benötigen><de> Es ist durchaus möglich, dass dieses Verhalten zu Infektionen mit Trojanern führen kann - dies die Betreiber ermöglichen, weiterhin Systemprobleme verursachen und mehr Geld von dem getäuscht Benutzer benötigten.
<G-vec00092-001-s140><require.benötigen><en> It is very possible that this behavior can lead to infections with Trojan Horses — this will allow the operators to continue to cause system issues and require more money from the deceived users.
<G-vec00092-001-s141><require.benötigen><de> Die für solche Bauteile benötigten hochkomplexen Strukturen sind so fein, dass ein einziges Staubkorn, das im Herstellungsprozess auf den Wafer fiele, eine Katastrophe wäre.
<G-vec00092-001-s141><require.benötigen><en> The highly complex structures such components require are so fine that a single speck of dust falling onto the wafer during the production process would be catastrophic.
<G-vec00092-001-s142><require.benötigen><de> Wählen Sie die von Ihrem Gesprächspartner benötigten Informationen komfortabel aus einem frei konfigurierbaren Katalog aus.
<G-vec00092-001-s142><require.benötigen><en> Comfortably choose the information you require for your conversation partner from a configurable catalog.
<G-vec00092-001-s143><require.benötigen><de> Alle Job Ticket Vorlagen und Job Tickets in der ausgewählten Datei werden zusammen mit den von ihnen benötigten Ressourcen in die ausgewählte Job Jackets Struktur importiert.
<G-vec00092-001-s143><require.benötigen><en> All Job Ticket templates and Job Tickets in the selected file are imported into the selected Job Jackets structure, along with any Resources they require.
<G-vec00092-001-s144><require.benötigen><de> In Nordamerika haben wir einen langfristigen Liefervertrag für Ethylen ausgehandelt, der ab dem Jahr 2015 die bisher kurzfristige Versorgung mit teurerem kryogenen Ethylen (Ethylen in tiefkalter Form, transportiert in Kesselwagen) ablösen wird, da wir dann den Großteil des benötigten Ethylens über eine Pipeline beziehen.
<G-vec00092-001-s144><require.benötigen><en> In North America, we negotiated a long-term supply contract for ethylene that, effective January 1, 2015, will replace the previous short-term supply contract for more costly cryogenic ethylene (i.e. frozen ethylene transported in tank cars). As of that date, the majority of the ethylene we require will be supplied via a pipeline.
<G-vec00092-001-s145><require.benötigen><de> Konsultieren Sie unseren Web-Katalog, in dem einige unserer angebotenen Ferienhäuser enthalten sind und informieren Sie uns über die Anzahl der Personen oder benötigten Zimmer und den Reisezeitraum, an dem Sie interessiert sind und wir schicken Ihnen ein detailliertes Angebot.
<G-vec00092-001-s145><require.benötigen><en> Please visit our website with some of the villas we can offer or inform us on the number of persons or bedrooms you require, along with the period of your holidays and we will be pleased to send you a detailed offer.
<G-vec00092-001-s146><require.benötigen><de> Metallische Kugellager schieden daher wegen ihres Gewichts aus, außerdem waren sie anfällig für Korrosion und benötigten Schmiermittel.
<G-vec00092-001-s146><require.benötigen><en> Metallic ball bearings cannot be used because of their weight, and they would also be prone to corrosion and require lubrication.
<G-vec00092-001-s147><require.benötigen><de> Diese internationalen Gremien haben damit Stellplätze haben die gewünschten Spieleigenschaften und bieten den notwendigen Schutz der Spieler, die Leistung angegeben, aus Kunstrasen Stellplätze benötigten.
<G-vec00092-001-s147><require.benötigen><en> To ensure pitches have the desired playing characteristics and provide the necessary levels of player protection, these international governing bodies have specified the performance they require from artificial grass pitches.
<G-vec00092-001-s148><require.benötigen><de> Wählen Sie die Beschwerde und das Medikament in der entsprechenden Dosierung und benötigten Menge aus.
<G-vec00092-001-s148><require.benötigen><en> Select the condition and medication along with the appropriate dosage and quantity you require.
<G-vec00092-001-s149><require.benötigen><de> Wir empfehlen, unerwünschte Richtlinien zunächst zu deaktivieren und anschließend die benötigten Richtlinien zu aktivieren.
<G-vec00092-001-s149><require.benötigen><en> We recommend to first disable unwanted policies, and then enable the policies you require.
<G-vec00092-001-s150><require.benötigen><de> Der Auftraggeber stellt auf seine Kosten das erforderliche Hilfspersonal mit dem von diesem benötigten Werkzeug in der erforderlichen Zahl zur Verfügung.
<G-vec00092-001-s150><require.benötigen><en> At its own cost, the customer shall provide the necessary support staff with the tools they require in the necessary number.
<G-vec00092-001-s151><require.benötigen><de> Nennen Sie uns die Serien-Nummer Ihres Kompressors und alle benötigten Teile.
<G-vec00092-001-s151><require.benötigen><en> Give us the serial number of your compressor and details of all the parts you require.
<G-vec00092-001-s228><require.benötigen><de> Während dieser Zeit ihres Lebens wird die Cannabispflanze sehr viel Energie benötigen und braucht viel Licht und Nährstoffe, um sie zu produzieren.
<G-vec00092-001-s228><require.benötigen><en> During this time of their lives, cannabis plants will require a lot of energy, and need a lot of light and nutrition to produce it.
<G-vec00092-001-s229><require.benötigen><de> Bringen Sie Medikamente, die Sie regelmäßig benötigen, in ausreichender Menge mit.
<G-vec00092-001-s229><require.benötigen><en> Bring adequate supplies of drugs you require regularly.
<G-vec00092-001-s230><require.benötigen><de> Gerade die produzierende Industrie, das Baustoffgewerbe und die Energiewirtschaft benötigen immense Rohstoffmengen.
<G-vec00092-001-s230><require.benötigen><en> Manufacturing industry and the energy sector in particular require immense amounts of such materials.
<G-vec00092-001-s231><require.benötigen><de> Die Hotels benötigen Kreditkarteninformationen, um die Buchung zu garantieren.
<G-vec00092-001-s231><require.benötigen><en> Hotels require credit card details in order to guarantee your reservation.
<G-vec00092-001-s232><require.benötigen><de> Ob PDCA, KVP, DMAIC oder Kaizen: CAQ .Net ® extrahiert die besten Werkzeuge aus den bestehenden Qualitätsphilosophien und gibt Ihnen die Mittel, die Sie für das Erreichen Ihrer Qualitätsziele und Erfolgsperspektiven benötigen.
<G-vec00092-001-s232><require.benötigen><en> Whether PDCA, DMAIC, or Kaizen: CAQ .Net ® extracts the most suitable measures from existing quality philosophies in order to give you everything you require to achieve your quality goals and production targets.
<G-vec00092-001-s233><require.benötigen><de> Pressezentrum Kontaktieren Sie uns, wenn Sie eine Evaluierungsversion der Software für die Überprüfung, Screenshots, Box Shots oder andere Grafiken benötigen.
<G-vec00092-001-s233><require.benötigen><en> Contact us if you require an evaluation copy of the software for review, screenshots, box shots or other graphics.
<G-vec00092-001-s234><require.benötigen><de> "Der Pressesprecher hat richtig bemerkt, daß Erzbischof Bertone die bischöfliche Erklärung dort gut wiedergegeben hat, wo sie sagt, daß ""die zahlreichen Gläubigen, die sich nach Medjugorje begeben, die pastorale Hilfe der Kirche benötigen"" (also die Hilfe der Priester während der Wallfahrten)."
<G-vec00092-001-s234><require.benötigen><en> "The director of the press office noted correctly that Archbishop Bertone had echoed the Bishops Declaration where it is said that ""the many faithful who go to Medjugorje require pastoral assistance of the Church"" (therefore, the help of priests with their pilgrimage)."
<G-vec00092-001-s235><require.benötigen><de> Dafür nutzen wir Sicherheitsmechanismen wie Firewalls und Datenverschlüsselung, wir haben physische Zugangsbeschränkungen für unsere Gebäude und Datenspeicher und erteilen Zugriff auf persönliche Daten nur jenen Mitarbeitern, die diesen für die Erfüllung ihrer beruflichen Aufgaben benötigen.
<G-vec00092-001-s235><require.benötigen><en> We use computer safeguards such as firewalls and data encryption, we enforce physical access controls to our buildings and files, and we authorise access to personal information only for those employees who require it to fulfill their job responsibilities.
<G-vec00092-001-s236><require.benötigen><de> Geben Sie an, in welchem Format Sie die Transkription benötigen (MS-Word, HTML, RTF, Klartext) und vergewissern Sie sich, dass Sie uns die richtige E-Mail-Lieferadresse mitgeteilt haben.
<G-vec00092-001-s236><require.benötigen><en> Specify what document format you require (MS Word, HTML, RTF, plain text), and make sure that we have the correct email address for delivery.
<G-vec00092-001-s237><require.benötigen><de> Sehen Sie hier die Liste der Drittländer ein, deren Staatsangehörige kein Visum für die Einreise nach Portugal benötigen.
<G-vec00092-001-s237><require.benötigen><en> Click here to access the list of third countries which do not require an entry visa in Portugal.
<G-vec00092-001-s238><require.benötigen><de> eKapija Software Services ist heute unersetzlicher Partner zahlreicher Organisationen, die die Unterstützung in der Entwicklung ihrer IT-Systeme benötigen.
<G-vec00092-001-s238><require.benötigen><en> eKapija Software Services is now an irreplaceable partner to many organizations that require support in the development of their IT system.
<G-vec00092-001-s239><require.benötigen><de> Obwohl das Tool weniger effektiv als Photoshop und GIMP ist, bietet es Ihnen ausreichend Funktionen, die Sie für die Bildbearbeitung benötigen.
<G-vec00092-001-s239><require.benötigen><en> Even though the tool is less effective than Photoshop as well as GIMP, it is capable of providing you with enough functionalities that you would require for image editing.
<G-vec00092-001-s240><require.benötigen><de> Mehrere beliebte Hacking Dienstleistungen, die Sie benötigen eine vage Vorstellung von Hacking zu haben, die Begrenzung werden kann, aber diese Lösung nicht.
<G-vec00092-001-s240><require.benötigen><en> Several popular hacking services require you to have a vague understanding of hacking which can be limiting, but this solution doesn’t.
<G-vec00092-001-s241><require.benötigen><de> In der Ecke steht eine mittelalterliche Webmaschine und die Küche ist überfüllt mit Sachen, die die Ziegen benötigen, oder die zur Käseherstellung gebraucht werden.
<G-vec00092-001-s241><require.benötigen><en> In the corner stands a medieval loom and the kitchen is crowded with stuff, require the goats, or that are used to make cheese.
<G-vec00092-001-s242><require.benötigen><de> Diese Serie ist für Kunden gedacht, die einen einfachen, aber zuverlässigen und langlebigen benzinbetriebenen Rasenmäher benötigen.
<G-vec00092-001-s242><require.benötigen><en> It is aimed towards customers who require a simple, yet reliable and durable petrol powered lawnmower.
<G-vec00092-001-s243><require.benötigen><de> Vielleicht würde die Gesellschaft entscheiden, dass es eine Verschwendung von Ressourcen, eine teure Ausbildung am vorderen Ende einer Laufbahn benötigen.
<G-vec00092-001-s243><require.benötigen><en> Maybe society would decide that it's a waste of resources to require a high-priced education on the front end of a career.
<G-vec00092-001-s244><require.benötigen><de> Anstatt sich auf E-Wallets, dass die Spieler benötigen, um ihre Bankdaten oder Futtermittel in den 16-stelligen Codes vorzulegen, ist es viel besser zu nutzen, um die Pay-per Telefon Kredit-Funktion.
<G-vec00092-001-s244><require.benötigen><en> Rather than relying on e-wallets that require players to submit their bank details or feed in 16-digit codes, it is way better to use the pay by phone credit feature.
<G-vec00092-001-s245><require.benötigen><de> Durch die Integration von zwei Lösungen in einem einzigen, umfassenden Gewichtsreduzierung Option, Phen24 bietet Ihnen die Unterstützung, die Sie Tag und Nacht benötigen Freude in erfolgreiche, langfristige Gewichtsmanagement zu übernehmen.
<G-vec00092-001-s245><require.benötigen><en> By incorporating 2 solutions into one, extensive weight reduction option, Phen24 provides you the assistance you require both night and day to take pleasure in successful, long-term weight management.
<G-vec00092-001-s246><require.benötigen><de> Mit unserer Blitzabhebung erhalten Sie Ihr Geld innerhalb von 24 Stunden, insofern uns alle Informationen, die wir gemäß unseren Allgemeinen Geschäftsbedingungen benötigen, vorliegen.
<G-vec00092-001-s246><require.benötigen><en> Our Lightning Withdrawals means you'll get your cash within 24 hours, subject to providing any information we require in accordance with our terms and conditions.
<G-vec00092-001-s304><require.benötigen><de> Bitte seien Sie sich darüber bewusst, dass wir manchmal von Ihnen einen Gerichtsbeschluss oder eine behördliche Anweisung benötigen, bevor wir Ihnen helfen können.
<G-vec00092-001-s304><require.benötigen><en> Please be aware that in some cases we may require you to provide us with a court order or administrative order before we are able to assist you.
<G-vec00092-001-s305><require.benötigen><de> Wenn Sie eine Sehkorrektion benötigen, können Sie durch das Tragen einer Korrektions-Sonnenbrille das Maximum aus Ihrem Aufenthalt im Freien herausholen.
<G-vec00092-001-s305><require.benötigen><en> If you require visual correction, wearing corrective sunglasses will help you make the most of your outdoor> Read more
<G-vec00092-001-s306><require.benötigen><de> Dieses Set ist die ideale Studio-Grundausstattung für ambitionierte Fotografen, die bereits erste Erfahrung in der Studiofotografie gesammelt haben und eine hohe Leistung für ihre Bilder benötigen.
<G-vec00092-001-s306><require.benötigen><en> This set represents the ideal studio equipment for ambitious hobby photographers, who already have experience in studio photography and require high power for their images.
<G-vec00092-001-s307><require.benötigen><de> Dies ist ein großer Vorteil, wenn Sie eine schnelle Einführung neuer Dienste benötigen oder zum Testen neuer Anwendungen oder IS .
<G-vec00092-001-s307><require.benötigen><en> This is a great advantage when you require fast deployment of new services or for testing new applications or IS .
<G-vec00092-001-s308><require.benötigen><de> Wenn Sie eine Nachbetreuung benötigen, besprechen Sie diese frühzeitig mit Ihrem Arzt.
<G-vec00092-001-s308><require.benötigen><en> If you require follow-up care, please discuss this with your doctor as soon as possible.
<G-vec00092-001-s309><require.benötigen><de> Für Anwendungen, die eine höhere Empfindlichkeit benötigen, werden TDI-Zeilenkameras eingesetzt.
<G-vec00092-001-s309><require.benötigen><en> For applications that require higher sensitivities, TDI line scan cameras are used.
<G-vec00092-001-s310><require.benötigen><de> Drahtösengliederbänder kombinieren eine flache, stabile Oberfläche mit der Dimensionsstabilität und Robustheit von Metall und eignen sich hervorragend für schwere Lasten oder unstabile, zerbrechliche Produkte, die eine gute Stütze benötigen.
<G-vec00092-001-s310><require.benötigen><en> Eyelink belts combine a flat, stable surface with the dimensional stability and robustness of metal and are well suited to heavy loads and unstable or fragile products that require good support.
<G-vec00092-001-s311><require.benötigen><de> A: Ja, der Körper wandelt ALA in DHA und EPA um, es gibt jedoch im Körper viele andere essentielle Prozesse, die für eine optimale Funktion ALA benötigen.
<G-vec00092-001-s311><require.benötigen><en> A: In short, yes, the body converts ALA over to DHA and EPA, however, there are many other essential processes in the body that require straight ALA in order to properly function.
<G-vec00092-001-s312><require.benötigen><de> Diese Liste ist nicht erschöpfend, und wenn Sie unsicher sind, ob Sie eine ärztliche Bescheinigung benötigen, kontaktieren Sie bitte SAA Sonderbuchungen vor dem Abflug.
<G-vec00092-001-s312><require.benötigen><en> This list is not exhaustive and if you are in any doubt as to whether your condition may require clearance, we urge you to contact SAA Special Bookings before flying.
<G-vec00092-001-s313><require.benötigen><de> Studioset Start400List die ideale Studio-Grundausstattung für den professionelle Anwender mit hohen Ansprüchen und eine hohe Leistung für ihre Bilder benötigen.
<G-vec00092-001-s313><require.benötigen><en> This set represents the ideal studio equipment for ambitious hobby photographers, who already have experience in studio photography and require high power for their images.
<G-vec00092-001-s314><require.benötigen><de> Für eine wirksame Registrierung benötigen wir eine valide E-Mail-Adresse.
<G-vec00092-001-s314><require.benötigen><en> We require a valid email address for effective registration.
<G-vec00092-001-s315><require.benötigen><de> Über LHKX Capital AG: LHKX Capital AG ist eine Beteiligungsgesellschaft aus Zürich, deren Ziel es ist, Zugang zu den Kapitalmarktdienstleistungen zu bieten, die sich an den Finanzierungsanforderungen von zwei Arten von internationalen Wachstumsunternehmen orientieren: (1) Unternehmen, die bereit für den Börsengang auf einem geeigneten Aktienmarkt sind, und (2) Unternehmen, die sich für einen Börsengang innerhalb eines Zeitraums von drei bis sechs Monaten vorbereiten und eine Pre-IPO-Finanzierung und/oder Unterstützung bei der Unternehmensentwicklung benötigen.
<G-vec00092-001-s315><require.benötigen><en> About LHKX Capital AG: LHKX │Capital AG is a Zurich based holding company that aims to provide access to capital market services that address the financing requirements of two types of international growth companies: (1) companies that are ready for IPO on a suitable stock market, and (2) companies that are preparing for an IPO within 3 to 6 months and require pre-IPO finance and/or corporate development support.
<G-vec00092-001-s316><require.benötigen><de> Unabhängig davon, ob Sie eine Lösung auf der Innen- oder der Außenfläche benötigen, BONDERITE® entfernt Metalloxidschuppen, Sulfationen und kohlenstoffhaltiges Material.
<G-vec00092-001-s316><require.benötigen><en> Whether you require an on-wing or off-wing solution, BONDERITE removes metal oxide scales, sulfadations and carbonaceous material.
<G-vec00092-001-s317><require.benötigen><de> Seit 2016 erhalten wir auch oft reine Planungsaufträge von unseren Partnern, wenn sie nur eine 3D- und/oder eine Herstellungsdokumentation benötigen, oder etwa einen Ansichtsplan.
<G-vec00092-001-s317><require.benötigen><en> From 2016, our partners can take advantage of our design activities as a standalone service, if they only require 3D and/or manufacturing documentation, or a conceptual plan.
<G-vec00092-001-s318><require.benötigen><de> Sie können jederzeit entfernt in einem Tag zu betrügen weil man manchmal eine besondere Behandlung benötigen.
<G-vec00092-001-s318><require.benötigen><en> You can always throw in fraud the day, because sometimes require special treatment.
<G-vec00092-001-s319><require.benötigen><de> Es ist ideal für Anwendungen, die keine dauerhafte Verbindung, aber eine Batterie mit langer Lebensdauer benötigen.
<G-vec00092-001-s319><require.benötigen><en> It is ideal for applications that do not require continuous connection but depend on long battery life.
<G-vec00092-001-s320><require.benötigen><de> Mit einem hohen Durchsatz sowie einer hohen Kapazität für unerwartete Rechenlasten sind die Switches der N3000 Serie die ideale Layer-3-Lösung für schnell wachsende GbE-Netzwerke, die eine Aggregation mit hoher Dichte mit nahtloser Redundanz und Verfügbarkeit benötigen.
<G-vec00092-001-s320><require.benötigen><en> With high throughput and capacity to handle unexpected workloads, the N3000 Series switches are ideal Layer 3 solutions for fast-growing GbE networks that require high-density aggregation with seamless redundancy and availability.
<G-vec00092-001-s321><require.benötigen><de> Das Ergebnis ist eine wundervolle, offensive Waffe für Spieler in allen Niveaus die eine gute Spin-Entwicklung, eine Prima Kontrolle und viel Tempo benötigen.
<G-vec00092-001-s321><require.benötigen><en> Â The result is a wonderful, offensive weapon for players of all levels who require good spin development, control and speed.
<G-vec00092-001-s322><require.benötigen><de> Die spezielle Schutzumwicklung im unteren Teil der Stange macht sie zu einer Rute mit einer riesigen Leistungsreserve, die es uns ermöglicht, die Drills der Brassen, Barben, Karpfen und anderer Arten zu kontrollieren, die eine zuverlässige und ausgefeilte Ausrüstung benötigen.
<G-vec00092-001-s322><require.benötigen><en> A special cross wrapping reinforcement in the lower section of the rod increased the power reserve to make it easier to control big bream, barbel, carp and other fish that require sure and well-made tackle.
<G-vec00260-002-s040><insure.benötigen><de> Dazu benötigen Sie möglichst genaue Angaben zu Ihrem Velo wie Kaufpreis (am besten mit Quittung), Marke, Farbe, Rahmennummer und den Tatort des Diebstahls.
<G-vec00260-002-s040><insure.benötigen><en> To insure proper compensation, you should be able to provide as many details about your bike as possible (ideally, show a receipt), including the brand, color, frame number and the exact location in which the theft took place.
<G-vec00270-002-s076><need.benötigen><de> Falls du ein zusätzliches Kabel oder einen speziellen Adapter benötigst, findest du den in unserem Webshop.
<G-vec00270-002-s076><need.benötigen><en> If you need another cable to carry with you or a special adapter, go get it in our Webshop.
<G-vec00270-002-s077><need.benötigen><de> Für den Single-Rider-Eingang benötigst du keinen Boarding Pass.
<G-vec00270-002-s077><need.benötigen><en> You do not need a Boarding Pass in the single rider queue.
<G-vec00270-002-s078><need.benötigen><de> Um die Elfe zu kontaktieren, halte ihr Abbild in Deinen Händen, schließe die Augen und meditiere einige Minuten über die Führung oder Hilfestellung, die Du benötigst.
<G-vec00270-002-s078><need.benötigen><en> To contact your fairy hold the pendant in your hand, close your eyes and meditate for a few minutes about the guidance or help you need.
<G-vec00270-002-s079><need.benötigen><de> In unseren ARP Kits bekommst du alles, was du für die Montage deiner Bauteile benötigst: Einen kompletten Satz Schrauben oder Bolzen für VW, Muttern, Unterlegscheiben und sogar den Befestigungs-Schmierstoff (ARP Ultra Torque).
<G-vec00270-002-s079><need.benötigen><en> With our ARP kits, you get everything you need for the installation of your components: a complete set of fasteners or bolts for VW, nuts, washers and even the mounting lubricant (ARP Ultra Torque).
<G-vec00270-002-s080><need.benötigen><de> Zum Laden von PDF Reader Pro - All-in-One PDF Office aus dem Mac App Store benötigst du einen Mac mit OS X 10.6.6 oder neuer.
<G-vec00270-002-s080><need.benötigen><en> To download PDF Reader Pro Free - All-in-One PDF Office from the Mac App Store, you need a Mac with OS X 10.6.6 or later.
<G-vec00270-002-s081><need.benötigen><de> Ob Du nur einen Tag, eine ganze Woche oder sogar einen Monat benötigst, Du findest einen erfahrenen Tiersitter in Wien, der auf Deine Bedürfnisse und die Deines Haustieres eingeht.
<G-vec00270-002-s081><need.benötigen><en> So whether you need just one day, a whole week or even a month, you’ll be able to find an experienced pet carer to accommodate you and your pet’s needs in Tempelhof-Schöneberg.
<G-vec00270-002-s082><need.benötigen><de> Für die Anmeldung auf YouTube benötigst du ein Google-Konto.
<G-vec00270-002-s082><need.benötigen><en> You need a Google Account to sign into YouTube.
<G-vec00270-002-s083><need.benötigen><de> Falls du einen Transfer vom Flughafen benötigst, informiere uns möglichst bald unter Kontakte.
<G-vec00270-002-s083><need.benötigen><en> If you need a transfer from the airport, please inform us as early as possible, see contacts.
<G-vec00270-002-s084><need.benötigen><de> Zum Laden von ChronoDB aus dem Mac App Store benötigst du einen Mac mit OS X 10.6.6 oder neuer.
<G-vec00270-002-s084><need.benötigen><en> To download CurRates from the Mac App Store, you need a Mac with OS X 10.6.6 or later.
<G-vec00270-002-s085><need.benötigen><de> Bei gleichem Gewicht benötigst Du im Vergleich mit Kurzhanteln mehr Konzentration und mentale Stärke, um die Kugel unter Kontrolle zu halten.
<G-vec00270-002-s085><need.benötigen><en> At the same weight, you need more concentration and mental strength compared to dumbbells to keep the ball under control.
<G-vec00270-002-s086><need.benötigen><de> Du benötigst eine Chat-Anwendung, die IRC-Links unterstützt, um von hier aus einen Chatraum zu betreten.
<G-vec00270-002-s086><need.benötigen><en> You need a chat application that supports IRC links to be able to enter this England chat room from here.
<G-vec00270-002-s087><need.benötigen><de> Damit Dein Look die ganze Nacht hält, fixiere ihn mit einem Spritzer jetzt die Produkte, die Du benötigst, um den Look zu Hause nachzustylen.
<G-vec00270-002-s087><need.benötigen><en> GET INSPIRED SHOP THE LOOK Select the products you need to recreate the look at home, with Shop the Look.
<G-vec00270-002-s088><need.benötigen><de> Wenn du nicht das "#3.7.0-sabayon" im Paketnamen angibst und eine frühere Fassung des Pakets für den Kernel verfügbar ist, den du im Moment der Installation verwendest, so wird einfach nur dieses Paket erneut aus den Paketquellen installiert, anstelle des neuen Kernelmoduls, das du benötigst.
<G-vec00270-002-s088><need.benötigen><en> do not include the "#2.6.36-sabayon" in the package name then, if the ati-drivers-10.10 package for an earlier version of the kernel happens to be in the repositories, it would be installed/re-installed instead of the module you need. +
<G-vec00270-002-s089><need.benötigen><de> Du bist jederzeit herzlich willkommen uns zu kontaktieren, wenn Du Fragen zu unseren Produkten hast oder Hilfe bei der Bestellung benötigst.
<G-vec00270-002-s089><need.benötigen><en> Please do not hesitate to contact us, if you have questions regarding our bamboo yarn or if you need help placing an order.
<G-vec00270-002-s090><need.benötigen><de> Die EVA-Mittelsohle und die GEL™-Technologie im Rückfußbereich ermöglichen eine beispiellose Stoßabsorption und Dämpfung, wo du sie am meisten benötigst.
<G-vec00270-002-s090><need.benötigen><en> Meanwhile, the EVA midsole and GEL™ technology strategically positioned in the rearfoot combine to give unparalleled levels of shock absorption and cushioning where you need it most.
<G-vec00270-002-s091><need.benötigen><de> In diesem Fall benötigst du nur ein niedriges Kissen, um dein Becken ein wenig nach vorne zu neigen.
<G-vec00270-002-s091><need.benötigen><en> In that case you only need a low pillow, just to tilt your pelvis a little bit forward.
<G-vec00270-002-s092><need.benötigen><de> Auf dem nächsten Bildschirm siehst du den Zugriffscode, den du benötigst.
<G-vec00270-002-s092><need.benötigen><en> On the next screen, you’ll see the access code that you need.
<G-vec00270-002-s093><need.benötigen><de> Du bist gerade dabei dich für einen Job bei einem japanischen Unternehmen zu bewerben und hierfür benötigst du deinen japanischen Lebenslauf.
<G-vec00270-002-s093><need.benötigen><en> You’re about to apply for a job in a Japanese company and, to do so, you need to get your Japanese Curriculum Vitae.
<G-vec00270-002-s228><require.benötigen><de> Egal, ob Sie eine ständige Überwachung mit automatisierter Benachrichtigung oder eine Überwachung kombiniert mit einem Maßnahmenplan für die eingreifenden Techniker benötigen, Trane hat eine kostengünstige Lösung.
<G-vec00270-002-s228><require.benötigen><en> Whether you require continuous monitoring and automated notification, or monitoring plus an action plan for remediation services, Trane can provide a cost-effective solution.
<G-vec00270-002-s230><require.benötigen><de> Die selbe Syntax kann verwendet werden, um auf Dateien via HTTP zuzugreifen, wenn diese eine Basic-Authentifizierung benötigen.
<G-vec00270-002-s230><require.benötigen><en> (You can use the same sort of syntax to access files via HTTP when they require Basic authentication.)
<G-vec00270-002-s231><require.benötigen><de> Bioinerte Hochleistungskeramiken erlauben die Herstellung von Komponenten für medizinische Geräte, die eine perfekte Oberflächenqualität sowie höchste Genauigkeit benötigen.
<G-vec00270-002-s231><require.benötigen><en> Bioinert high-performance ceramics allow for the manufacture of components for medical devices which require perfect surface quality and accuracy.
<G-vec00270-002-s232><require.benötigen><de> Die TB-0708-Serie ist eine horizontale Ballenpresse, die für Benutzer konzipiert wurde, die eine Recycling-Ballenpresse mit geringer Kapazität und geringerer Kapazität benötigen, einschließlich Recycling-Kollektoren, Druckern und Papierherstellern.
<G-vec00270-002-s232><require.benötigen><en> TB-0708 Series is a horizontal baler which is designed for users that require recycling baler on a small scale and lower capacity, including recycling collectors, printers and paper manufacturers.
<G-vec00270-002-s233><require.benötigen><de> Bitte bewahren Sie das Produkt auf, bis Sie mit unserem Team gesprochen haben welches Ihnen mitteilen wird, ob wir das Produkt für eine weitere Analyse zurück benötigen.
<G-vec00270-002-s233><require.benötigen><en> Please keep the product until you have spoken with our team who will advise whether or not we require it back for further analysis.
<G-vec00270-002-s234><require.benötigen><de> Ebenso sollten Sie beachten das sie eine Versicherung für die Dauer der Tauchsafari benötigen.
<G-vec00270-002-s234><require.benötigen><en> It is important to know that you will require having insurance for the duration of your trip.
<G-vec00270-002-s235><require.benötigen><de> Es wird angenommen, dass viele Tiere, wie auch Menschen, eine zusätzliche Glucosaminaufnahme benötigen, um den körpereigenen Glucosaminspeicher zu unterstützen.
<G-vec00270-002-s235><require.benötigen><en> It seems that many animals, as with humans, require additional glucosamine in order to maintain/build up the body’s store.
<G-vec00270-002-s237><require.benötigen><de> Je nach Ihrer speziellen Situation kann eine dieser Anwendungen für Sie funktionieren, wenn Sie eine serielle Schnittstelle über IP-Konnektivität benötigen.
<G-vec00270-002-s237><require.benötigen><en> Based on your particular situation, one of these applications may work for you when you require serial port over IP connectivity.
<G-vec00270-002-s239><require.benötigen><de> Unsere Kunden sind kleine und mittelständische Hersteller, die teilweise eine professionelle Umsetzungsberatung vor Ort benötigen.
<G-vec00270-002-s239><require.benötigen><en> MRPeasy’s clients are small and medium-sized manufacturers who sometimes require professional implementation consultation at their location.
<G-vec00270-002-s240><require.benötigen><de> Ganz in der Nähe Wenn Sie eine Buchung mit Vorauszahlung vornehmen und eine Rechnung benötigen, geben Sie bitte Ihre Firmendaten im Feld für besondere Anfragen an und kontaktieren Sie die Unterkunft.
<G-vec00270-002-s240><require.benötigen><en> If you are booking a pre paid rate and require an invoice, please include your company details in the Special Requests box when booking and contact the property.
<G-vec00270-002-s241><require.benötigen><de> Da Softwarepatente keinen Konzeptnachweis oder eine Implementierung benötigen, kann es sich der Patentinhaber auf einfache Weise leisten, abstrakte Methoden anzumelden und eigenmächtig entscheiden, Lizenzen herauszugeben oder zu verweigern.
<G-vec00270-002-s241><require.benötigen><en> As software patents do not require proof of concept or implementation, the patentee can easily afford to file abstract methods and decide to give or deny licenses arbitrarily.
<G-vec00270-002-s242><require.benötigen><de> Das Display ist ideal geeignet für Multi-oder Einzelhandelsgeschäften, die eine automatisierte Steuerung und anpassbare Voreinstellungen benötigen.
<G-vec00270-002-s242><require.benötigen><en> This display is great for multi-screen setups in hotels, restaurants, sports bars, or retail outlets that require automated control and customizable presets.
<G-vec00270-002-s243><require.benötigen><de> Es handelt sich ausschließlich um deutschsprachige Unternehmen aus dem deutschen, österreichischen, schweizerischen und luxemburgischen Raum, welche häufig über Filialen in Frankreich verfügen und eine Begleitung in der deutschen Sprache benötigen.
<G-vec00270-002-s243><require.benötigen><en> These are often companies that speak only German (German, Austrian, Swiss and Luxembourgish) which often have subsidiaries in France and require support in German.
<G-vec00270-002-s245><require.benötigen><de> Ihr Fazit: „Diese Studie zeigt uns wichtige Mechanismen, die Zellen für eine robuste Ziliaranlage benötigen.
<G-vec00270-002-s245><require.benötigen><en> She concludes: “This study reveals important mechanisms cells require for robust ciliary assembly.
<G-vec00270-002-s246><require.benötigen><de> Es ist wichtig zu beachten, dass alle Protokolle mit Ausnahme von HTTP eine funktionierende Git Installation auf dem Server benötigen.
<G-vec00270-002-s246><require.benötigen><en> It’s important to note that with the exception of the HTTP protocols, all of these require Git to be installed and working on the server.
<G-vec00355-002-s078><fetch.benötigen><de> Anschließend benötigen Sie einen Eimer, sowie ein Flachwischgerät und geben einen halben Dosierkopf green & clean natural in 5 Liter kaltes Wasser.
<G-vec00355-002-s078><fetch.benötigen><en> Now fetch a bucket as well as a floor cleaner set and add half a dosage cap of clean & green natural to 5 litres of cold water.
<G-vec00373-002-s057><occupy.benötigen><de> Seine speziell geformte hochisolierende Box bedeutet, dass die beiden Elemente einen minimalen Platz benötigen, zur Vermeidung von Wärmebrücken.
<G-vec00373-002-s057><occupy.benötigen><en> Its specially shaped high-insulation box means that the two elements occupy a minimal amount of space, while avoiding thermal bridges.
<G-vec00373-002-s058><occupy.benötigen><de> Damals wurde deutlich, dass die ARCTIC CAT AG bald ein wesentlich größeres Werk benötigen würde.
<G-vec00373-002-s058><occupy.benötigen><en> Looking ahead from this point, ARCTIC CAT AG knew that they would eventually have to locate and occupy a much larger facility.
<G-vec00373-002-s059><occupy.benötigen><de> Alle Möbel sind übergroß und benötigen keinen zusätzlichen Platz.
<G-vec00373-002-s059><occupy.benötigen><en> All furniture is oversized and does not occupy extra space.
<G-vec00373-002-s060><occupy.benötigen><de> Finden Sie schnell die Dateien, die mehrere Kopien haben oder den meisten Speicherplatz benötigen und identifizieren Sie redundante oder leere Ordner.
<G-vec00373-002-s060><occupy.benötigen><en> Easily spot files that have multiple copies, determine which files occupy the most storage, and identify redundant or empty folders.
<G-vec00373-002-s061><occupy.benötigen><de> Es gibt sehr viele Situationen, in denen es sehr nützlich ist Bilder oder Fotografien zu komprimieren damit Sie weniger Speicherplatz benötigen: um Fotografien per E-Mail zu senden, damit Ihre Webseite schneller ladet, um Fotos auf sozialen Netzwerken zu teilen oder einfach nur, um Sie auf Ihrer Festplatte zu speichern und dabei wenig Speicherplatz verwenden.
<G-vec00373-002-s061><occupy.benötigen><en> There are many times when it can come in very handy for us to be able to compress photographs or images so as to occupy less space: whether to send photographs by email, to manage to make our website take less to load, to upload photographs to our social networks, or simply, to store images on our hard drive without taking up so much space.
<G-vec00373-002-s062><occupy.benötigen><de> Drehverschlüsse benötigen im Vergleich zu herkömmlichen Hebeln weniger Platz und machen das Stativ leicht und kompakt.
<G-vec00373-002-s062><occupy.benötigen><en> The locks also occupy less space than traditional levers, enhancing the tripod's compact design.
<G-vec00386-002-s247><upgrade.benötigen><de> Sie benötigen für eine korrekte Darstellung dieser Seite einen Web-Browser, der Frames unterstützt.
<G-vec00386-002-s247><upgrade.benötigen><en> The LaChapelle Legacy site - Welcome Please upgrade to a browser that supports frames.
<G-vec00386-002-s248><upgrade.benötigen><de> Sie benötigen einen Browser, der Frames unterstützt, um diese Seite anzeigen zu können.
<G-vec00386-002-s248><upgrade.benötigen><en> Please upgrade to a browser that supports frames. Location:
<G-vec00386-002-s251><upgrade.benötigen><de> Sie benötigen einen Browser der Frames unterstützt.
<G-vec00386-002-s251><upgrade.benötigen><en> Please upgrade to a browser that supports frames.
<G-vec00386-002-s252><upgrade.benötigen><de> Sie benötigen für diese Seite einen Browser, der frames unterstützt.
<G-vec00386-002-s252><upgrade.benötigen><en> Please upgrade to a browser that supports frames. Home |
<G-vec00386-002-s255><upgrade.benötigen><de> Sie benötigen einen Browser, der Frames unterstützt, um diese Seite anzeigen zu können..
<G-vec00386-002-s255><upgrade.benötigen><en> You should upgrade to a browser that supports frames, such as:
<G-vec00386-002-s257><upgrade.benötigen><de> Tut uns leid aber Sie benötigen einen Browser der Frames unterstützt.
<G-vec00386-002-s257><upgrade.benötigen><en> I recommend you upgrade to a browser that supports frames.
<G-vec00386-002-s259><upgrade.benötigen><de> Wenn Sie Informationen zur Erneuerung des Netop Advantage Support- und Upgrade-Jahresprogramms benötigen, wenden Sie sich bitte an Kundenservice oder Ihren lokalen Netop Partner.
<G-vec00386-002-s259><upgrade.benötigen><en> If you need information on renewing your Netop Advantage annual support and upgrade program, contact Netop customer service or your local Netop partner.
<G-vec00386-002-s260><upgrade.benötigen><de> Um diese Webseite ansehen zu können, benötigen Sie einen Browser, der Frames unterstützt.
<G-vec00386-002-s260><upgrade.benötigen><en> TOP Please upgrade to a browser that supports frames.
<G-vec00389-002-s025><thwart.benötigen><de> Einzig Grindelwalds ehemals bester Freund Albus Dumbledore (Jude Law) wäre in der Lage, ihn zu stoppen, aber dazu wiederum benötigt dieser die Hilfe seines früheren Schülers Scamander, der so in sein nächstes Abenteuer stürzt – und dieses Mal verschlägt es ihn nach Europa, genauer gesagt nach Paris.
<G-vec00389-002-s025><thwart.benötigen><en> In an effort to thwart Grindelwald’s plans, Albus Dumbledore (Law) enlists his former student Newt Scamander, who agrees to help, unaware of the dangers that lie ahead.
<G-vec00270-003-s244><require.benötigen><de> Die TB-0708-Serie ist eine horizontale Ballenpresse, die für Benutzer konzipiert wurde, die eine Recycling-Ballenpresse mit geringer Kapazität und geringerer Kapazität benötigen, einschließlich...
<G-vec00270-003-s244><require.benötigen><en> TB-0708 Series is a horizontal baler which is designed for users that require recycling baler on a small scale and lower capacity, including recycling collectors, printers and paper...
