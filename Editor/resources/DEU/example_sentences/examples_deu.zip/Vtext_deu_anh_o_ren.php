<G-vec00313-002-s019><hear.anhören><de> Wir arbeiten gerade aktiv an der Erstellung von Sound Bytes für alle Namen auf dieser Liste, um sich die korrekte Aussprache anhören zu können.
<G-vec00313-002-s019><hear.anhören><en> We are actively working on creating sound bytes for all the names on this list so that you can hear how each name is pronounced correctly.
<G-vec00313-002-s020><hear.anhören><de> Sie wollen die Erklärungen anhören und die Plakate ansehen.
<G-vec00313-002-s020><hear.anhören><en> They want to hear the explanations and look at the posters.
<G-vec00313-002-s021><hear.anhören><de> (1) Das Gericht kann das persönliche Erscheinen eines Beteiligten zu einem Termin anordnen und ihn anhören, wenn dies zur Aufklärung des Sachverhalts sachdienlich erscheint.
<G-vec00313-002-s021><hear.anhören><en> (1) The court may order the personal appearance of a participant at a court hearing and hear him when this appears relevant for clarifying the factual circumstances.
<G-vec00313-002-s022><hear.anhören><de> Sie können bereits jetzt Videos von den Bands auf Tournee ansehen und anhören.
<G-vec00313-002-s022><hear.anhören><en> You can already hear and see videos of the bands on tour.
<G-vec00313-002-s023><hear.anhören><de> Sie können die beteiligten Parteien anhören und Zugang zur Unternehmensverwaltung beantragen.
<G-vec00313-002-s023><hear.anhören><en> They may hear the parties involved, and can require access to the administration of the company.
<G-vec00313-002-s024><hear.anhören><de> Hyo Jin konnte nicht an dem zweitägigen Symposion in der großen Halle des National Building Museums teilnehmen und sich die Redner anhören, die über den weltweiten Verfall der Familienwerte referierten, unter ihnen auch die ehemaligen Präsidenten Gerald Ford und George Bush sowie der ehemalige britische Premierminister Edward Heath, der ehemalige Präsident von Costa Rica und Träger des Friedensnobelpreises Oscar Arias und der republikanische Präsidentschaftskandidat Jack Kemp.
<G-vec00313-002-s024><hear.anhören><en> Hyo Jin Moon could not attend the two-day symposium in the Great Hall of the National Building Museum to hear speakers such as former presidents Gerald Ford and George Bush, former British prime minister Edward Heath, former Costa Rican president and Nobel Peace Prize winner Oscar Arias, and Republican presidential hopeful Jack Kemp address the erosion of family values around the world.
<G-vec00313-002-s025><hear.anhören><de> Niemand möchte sich Ihre Ausreden anhören, noch möchte jemand das Gefühl haben, dass Sie etwas vor ihnen verstecken.
<G-vec00313-002-s025><hear.anhören><en> Nobody wants to hear your excuses, nor do they want to feel like you’re hiding something from them.
<G-vec00313-002-s026><hear.anhören><de> Wir sehen die ersten Bilder von Kindern unserer Bekannten und können uns anhören und anschauen, was die lokalen Politiker gerade auf ihrer Wahlkampftour oder im Bundestag treiben.
<G-vec00313-002-s026><hear.anhören><en> We see the first pictures of our acquaintances’ children, and we can hear and see what local politicians are doing during their election campaigns or in parliament.
<G-vec00313-002-s027><hear.anhören><de> Genau 1 Minute Dampfnostalgie Original-Sound bei der Ausfahrt mit Pfiff zum Anhören und downloaden als mp3-File.
<G-vec00313-002-s027><hear.anhören><en> The result is exact 1 minute steam train original sound at the exit with whistle as a mp3 file ready to hear and to download.
<G-vec00313-002-s028><hear.anhören><de> In unserem Shop finden Sie nachgespielte Playbacks in einer Instrumentalversion, mit Begleitstimmen und manchmal auch mit Hauptstimme, damit Sie sich anhören können, wie der Song gesungen wird.
<G-vec00313-002-s028><hear.anhören><en> On this website you will find reproduced backing tracks, available in an instrumental version, instrumental with backing vocals, and sometimes also with lead (reproduced) vocals to hear how the song is sung.
<G-vec00313-002-s029><hear.anhören><de> 17 Ihr sollet nicht die Person ansehen im Gericht; den Kleinen, wie den Großen sollet ihr anhören; ihr sollet euch vor Niemand scheuen, denn das Gericht ist Gottes; und was euch zu schwer ist, bringet vor mich, so will ich es verhören.
<G-vec00313-002-s029><hear.anhören><en> [17] Ye shall not respect persons in judgment; but ye shall hear the small as well as the great; ye shall not be afraid of the face of man; for the judgment is God's and the cause that is too hard for you, bring it unto me, and I will hear it.
<G-vec00313-002-s030><hear.anhören><de> Eine CD, die man sich anhören sollte.
<G-vec00313-002-s030><hear.anhören><en> A CD you should hear.
<G-vec00313-002-s031><hear.anhören><de> (2) Das Gericht kann in zweifelhaften Fällen die berufsständischen Organe anhören, soweit dies zur Vornahme der gesetzlich vorgeschriebenen Eintragungen sowie zur Vermeidung unrichtiger Eintragungen in das Register erforderlich ist.
<G-vec00313-002-s031><hear.anhören><en> (2) In cases of doubt the court may hear the professional bodies to the extent this is necessary for the performance of the statutorily prescribed registrations as well as for the avoidance of incorrect registrations in the register.
<G-vec00313-002-s032><hear.anhören><de> Vielleicht will er sich nur das eine Lied noch zu Ende anhören.
<G-vec00313-002-s032><hear.anhören><en> Perhaps he just wants to hear the song to the end.
<G-vec00313-002-s033><hear.anhören><de> Die Antwort Tschurkins ließ nicht lange auf sich warten: „Wenn wir beichten wollten, würden wir in die Kirche gehen, wenn wir Gedichte anhören wollten, würden wir ins Theater gehen.
<G-vec00313-002-s033><hear.anhören><en> Churkin's response wasn't long in coming: "If we had needed a sermon, we would have gone to a church. If we had wanted to hear poetry, we would have gone to the theater.
<G-vec00313-002-s034><hear.anhören><de> (3) Der Wahlausschuss kann sich die die Eiwendung machende Person anhören.
<G-vec00313-002-s034><hear.anhören><en> (3) The election committee may hear the person who has submitted the reserve.
<G-vec00313-002-s035><hear.anhören><de> Sicherlich kein Lied zum einmal anhören - das ist eines jener Lieder, die sich mir erst im Laufe der Zeit erschließen, richtig ans Herz wachsen, ein Prozess der wohl am ehesten mit manchen Freundschaften zu vergleichen ist, die ebenfalls mitunter ihre Zeit brauchen, um sich zu entwickeln - und oft sind genau diese die dauerhaftesten... na, wie auch immer, der Beginn von Otherworld ist jedenfalls recht schwungvoll, dann wird es ein bißchen langsamer...
<G-vec00313-002-s035><hear.anhören><en> Surely not a song to hear only once - this is one of the songs that reveal themselves before me, that I grow fond of, after some time only; a process that's best compared to some friendships, that sometimes need time to develop, too - and it's these that tend to be the most durable... well, however, the begin of Otherworld is quite swinging, then it continues a bit more moderate...
<G-vec00313-002-s036><hear.anhören><de> Wenn Sie mit der Maus auf ein Wort oder einen Satz in einer Fremdsprache zeigen, wird in einem kleinen Fenster die Übersetzung in Ihre Muttersprache angezeigt (mithilfe der Schaltfläche Wiedergabe können Sie die Aussprache des Worts oder des Satzes anhören und mit der Schaltfläche Kopieren die Übersetzung an eine andere Stelle des Notizbuchs kopieren).
<G-vec00313-002-s036><hear.anhören><en> Mini Translator, which lets you use your mouse to point to a foreign word or phrase and see a translation into your native language in a small window (you can also use the Play button to hear the pronunciation of the word or phrase, and use a Copy button to paste the translation elsewhere in your notebook).
<G-vec00313-002-s037><hear.anhören><de> Das muss sich die österreichische Hauptstadt nur allzu oft anhören – zu Unrecht.
<G-vec00313-002-s037><hear.anhören><en> Or at least, that's what the citizens of the Austrian capital hear all too often – and unfairly so.
<G-vec00445-002-s019><hear_out.anhören><de> Wir arbeiten gerade aktiv an der Erstellung von Sound Bytes für alle Namen auf dieser Liste, um sich die korrekte Aussprache anhören zu können.
<G-vec00445-002-s019><hear_out.anhören><en> We are actively working on creating sound bytes for all the names on this list so that you can hear how each name is pronounced correctly.
<G-vec00445-002-s020><hear_out.anhören><de> Sie wollen die Erklärungen anhören und die Plakate ansehen.
<G-vec00445-002-s020><hear_out.anhören><en> They want to hear the explanations and look at the posters.
<G-vec00445-002-s021><hear_out.anhören><de> (1) Das Gericht kann das persönliche Erscheinen eines Beteiligten zu einem Termin anordnen und ihn anhören, wenn dies zur Aufklärung des Sachverhalts sachdienlich erscheint.
<G-vec00445-002-s021><hear_out.anhören><en> (1) The court may order the personal appearance of a participant at a court hearing and hear him when this appears relevant for clarifying the factual circumstances.
<G-vec00445-002-s022><hear_out.anhören><de> Sie können bereits jetzt Videos von den Bands auf Tournee ansehen und anhören.
<G-vec00445-002-s022><hear_out.anhören><en> You can already hear and see videos of the bands on tour.
<G-vec00445-002-s023><hear_out.anhören><de> Sie können die beteiligten Parteien anhören und Zugang zur Unternehmensverwaltung beantragen.
<G-vec00445-002-s023><hear_out.anhören><en> They may hear the parties involved, and can require access to the administration of the company.
<G-vec00445-002-s024><hear_out.anhören><de> Hyo Jin konnte nicht an dem zweitägigen Symposion in der großen Halle des National Building Museums teilnehmen und sich die Redner anhören, die über den weltweiten Verfall der Familienwerte referierten, unter ihnen auch die ehemaligen Präsidenten Gerald Ford und George Bush sowie der ehemalige britische Premierminister Edward Heath, der ehemalige Präsident von Costa Rica und Träger des Friedensnobelpreises Oscar Arias und der republikanische Präsidentschaftskandidat Jack Kemp.
<G-vec00445-002-s024><hear_out.anhören><en> Hyo Jin Moon could not attend the two-day symposium in the Great Hall of the National Building Museum to hear speakers such as former presidents Gerald Ford and George Bush, former British prime minister Edward Heath, former Costa Rican president and Nobel Peace Prize winner Oscar Arias, and Republican presidential hopeful Jack Kemp address the erosion of family values around the world.
<G-vec00445-002-s025><hear_out.anhören><de> Niemand möchte sich Ihre Ausreden anhören, noch möchte jemand das Gefühl haben, dass Sie etwas vor ihnen verstecken.
<G-vec00445-002-s025><hear_out.anhören><en> Nobody wants to hear your excuses, nor do they want to feel like you’re hiding something from them.
<G-vec00445-002-s026><hear_out.anhören><de> Wir sehen die ersten Bilder von Kindern unserer Bekannten und können uns anhören und anschauen, was die lokalen Politiker gerade auf ihrer Wahlkampftour oder im Bundestag treiben.
<G-vec00445-002-s026><hear_out.anhören><en> We see the first pictures of our acquaintances’ children, and we can hear and see what local politicians are doing during their election campaigns or in parliament.
<G-vec00445-002-s027><hear_out.anhören><de> Genau 1 Minute Dampfnostalgie Original-Sound bei der Ausfahrt mit Pfiff zum Anhören und downloaden als mp3-File.
<G-vec00445-002-s027><hear_out.anhören><en> The result is exact 1 minute steam train original sound at the exit with whistle as a mp3 file ready to hear and to download.
<G-vec00445-002-s028><hear_out.anhören><de> In unserem Shop finden Sie nachgespielte Playbacks in einer Instrumentalversion, mit Begleitstimmen und manchmal auch mit Hauptstimme, damit Sie sich anhören können, wie der Song gesungen wird.
<G-vec00445-002-s028><hear_out.anhören><en> On this website you will find reproduced backing tracks, available in an instrumental version, instrumental with backing vocals, and sometimes also with lead (reproduced) vocals to hear how the song is sung.
<G-vec00445-002-s029><hear_out.anhören><de> 17 Ihr sollet nicht die Person ansehen im Gericht; den Kleinen, wie den Großen sollet ihr anhören; ihr sollet euch vor Niemand scheuen, denn das Gericht ist Gottes; und was euch zu schwer ist, bringet vor mich, so will ich es verhören.
<G-vec00445-002-s029><hear_out.anhören><en> [17] Ye shall not respect persons in judgment; but ye shall hear the small as well as the great; ye shall not be afraid of the face of man; for the judgment is God's and the cause that is too hard for you, bring it unto me, and I will hear it.
<G-vec00445-002-s030><hear_out.anhören><de> Eine CD, die man sich anhören sollte.
<G-vec00445-002-s030><hear_out.anhören><en> A CD you should hear.
<G-vec00445-002-s031><hear_out.anhören><de> (2) Das Gericht kann in zweifelhaften Fällen die berufsständischen Organe anhören, soweit dies zur Vornahme der gesetzlich vorgeschriebenen Eintragungen sowie zur Vermeidung unrichtiger Eintragungen in das Register erforderlich ist.
<G-vec00445-002-s031><hear_out.anhören><en> (2) In cases of doubt the court may hear the professional bodies to the extent this is necessary for the performance of the statutorily prescribed registrations as well as for the avoidance of incorrect registrations in the register.
<G-vec00445-002-s032><hear_out.anhören><de> Vielleicht will er sich nur das eine Lied noch zu Ende anhören.
<G-vec00445-002-s032><hear_out.anhören><en> Perhaps he just wants to hear the song to the end.
<G-vec00445-002-s033><hear_out.anhören><de> Die Antwort Tschurkins ließ nicht lange auf sich warten: „Wenn wir beichten wollten, würden wir in die Kirche gehen, wenn wir Gedichte anhören wollten, würden wir ins Theater gehen.
<G-vec00445-002-s033><hear_out.anhören><en> Churkin's response wasn't long in coming: "If we had needed a sermon, we would have gone to a church. If we had wanted to hear poetry, we would have gone to the theater.
<G-vec00445-002-s034><hear_out.anhören><de> (3) Der Wahlausschuss kann sich die die Eiwendung machende Person anhören.
<G-vec00445-002-s034><hear_out.anhören><en> (3) The election committee may hear the person who has submitted the reserve.
<G-vec00445-002-s035><hear_out.anhören><de> Sicherlich kein Lied zum einmal anhören - das ist eines jener Lieder, die sich mir erst im Laufe der Zeit erschließen, richtig ans Herz wachsen, ein Prozess der wohl am ehesten mit manchen Freundschaften zu vergleichen ist, die ebenfalls mitunter ihre Zeit brauchen, um sich zu entwickeln - und oft sind genau diese die dauerhaftesten... na, wie auch immer, der Beginn von Otherworld ist jedenfalls recht schwungvoll, dann wird es ein bißchen langsamer...
<G-vec00445-002-s035><hear_out.anhören><en> Surely not a song to hear only once - this is one of the songs that reveal themselves before me, that I grow fond of, after some time only; a process that's best compared to some friendships, that sometimes need time to develop, too - and it's these that tend to be the most durable... well, however, the begin of Otherworld is quite swinging, then it continues a bit more moderate...
<G-vec00445-002-s036><hear_out.anhören><de> Wenn Sie mit der Maus auf ein Wort oder einen Satz in einer Fremdsprache zeigen, wird in einem kleinen Fenster die Übersetzung in Ihre Muttersprache angezeigt (mithilfe der Schaltfläche Wiedergabe können Sie die Aussprache des Worts oder des Satzes anhören und mit der Schaltfläche Kopieren die Übersetzung an eine andere Stelle des Notizbuchs kopieren).
<G-vec00445-002-s036><hear_out.anhören><en> Mini Translator, which lets you use your mouse to point to a foreign word or phrase and see a translation into your native language in a small window (you can also use the Play button to hear the pronunciation of the word or phrase, and use a Copy button to paste the translation elsewhere in your notebook).
<G-vec00445-002-s037><hear_out.anhören><de> Das muss sich die österreichische Hauptstadt nur allzu oft anhören – zu Unrecht.
<G-vec00445-002-s037><hear_out.anhören><en> Or at least, that's what the citizens of the Austrian capital hear all too often – and unfairly so.
<G-vec00445-002-s019><listen.anhören><de> Während ihr entspannt herumfliegt, könnt ihr Echos finden und anhören, die euch mehr über die Hintergrundgeschichte und das Universum von Valkyrie verraten.
<G-vec00445-002-s019><listen.anhören><en> While cruising around you’ll be able to locate and listen to Echoes, which provide more backstory and Valkyrie lore.
<G-vec00445-002-s020><listen.anhören><de> Wenn Sie diese Qr-Codes scannen, finden Sie auf unserer Website Informationen zum Lesen oder zum Anhören von Audioführern über die Häuser im Freilichtmuseum.
<G-vec00445-002-s020><listen.anhören><en> If you scan these Qr-codes, you can find information on our website to read, or listen to audioguide about the houses on the Open-air Museum.
<G-vec00445-002-s021><listen.anhören><de> Sie können die Aussprache von chuan nicht anhören weil Ihr Browser keine audio Elemente unterstützt.
<G-vec00445-002-s021><listen.anhören><en> You cannot listen to the pronunciation of xin because your browser does not support the audio element.
<G-vec00445-002-s022><listen.anhören><de> Sie können die Aussprache von shen tang nicht anhören weil Ihr Browser keine audio Elemente unterstützt.
<G-vec00445-002-s022><listen.anhören><en> You cannot listen to the pronunciation of shen feng because your browser does not support the audio element.
<G-vec00445-002-s023><listen.anhören><de> Mit der auf Streaming-Technologie basierenden Vorhörfunktion können die Empfänger Ihre Musiktitel sofort anhören und in den Titeln auch vor- und zurückspulen.
<G-vec00445-002-s023><listen.anhören><en> Based upon streaming technology, iPool's preview function enables the recipients to listen to your music titles instantly, and they can even jump within the tracks.
<G-vec00445-002-s024><listen.anhören><de> Ihr werdet zwar erst dann darüber sprechen können, wenn die ersten Vorgänge stattgefunden haben, denn zuvor wird kein Mensch eure Rede anhören wollen - ihr werdet erst dann offene Ohren und Herzen finden, wenn eine Erschütterung vorangegangen ist, die die Menschen fragen lässet, und dann erst sollet ihr reden, und von der Willigkeit der Menschen wird es abhängen, welchen Nutzen er/sie aus jenen Geschehen ziehen.
<G-vec00445-002-s024><listen.anhören><en> You will in fact only then be able to speak about it when the first events have taken place because beforehand no man wants to listen to your talk – you will only then find open ears and hearts when one tremor has preceded it, which lets men ask, and only then you are to speak, and it will depend on the willingness of men which benefit he/she is reaping from those happenings.
<G-vec00445-002-s025><listen.anhören><de> Das Album ist Teil der Choro Kollektion 'Classics of the Brazilian Choro' für Playalong, zum lernen, zum solieren oder einfach zum anhören.
<G-vec00445-002-s025><listen.anhören><en> Waldir Azevedo Songbook 1 Beautiful collection of well-known choro pieces Part 1 for playalong, to learn, to solo or simply to listen to.
<G-vec00445-002-s026><listen.anhören><de> Sie können die Aussprache von fu tu nicht anhören weil Ihr Browser keine audio Elemente unterstützt.
<G-vec00445-002-s026><listen.anhören><en> You cannot listen to the pronunciation of fu tu because your browser does not support the audio element.
<G-vec00445-002-s027><listen.anhören><de> Hier können Sie Ihre Mediendateien anhören und ansehen, Wiedergablisten erstellen, Mediendateien exportieren und Lieder bearbeiten.
<G-vec00445-002-s027><listen.anhören><en> Here, you can listen to and watch your media files, create playlists, export media files or edit your songs.
<G-vec00445-002-s028><listen.anhören><de> Nachrichten anhören / einzelne Nachrichten löschen / / Drücken Sie den Softkey Menü.
<G-vec00445-002-s028><listen.anhören><en> Listen new messages / deleting single messages / / Press the Menu softkey.
<G-vec00445-002-s029><listen.anhören><de> “Burlesque” auf Youtube anhören.
<G-vec00445-002-s029><listen.anhören><en> Listen to “Burlesque” on Youtube.
<G-vec00445-002-s030><listen.anhören><de> Auf dieser Seite können Sie den Klingelton "Too Many Clocks" anhören und herunterladen.
<G-vec00445-002-s030><listen.anhören><en> On this page you can listen to and download ringtone Too Many Clocks, use the button "Play" to listen or "Download" to download a ringtone.
<G-vec00445-002-s031><listen.anhören><de> Stellen Sie sich vor, dass Sie auf alle Lyriktexte sämtlicher Lieder, die Sie auf Ihrem Gerät anhören, ohne Schwierigkeiten zugreifen können.
<G-vec00445-002-s031><listen.anhören><en> Imagine having all the lyrics of any song you listen to on your device without any kind of effort.
<G-vec00445-002-s032><listen.anhören><de> Dabei stehen mehr als 50 Millionen Songs und tausende Hörbücher aller Genres zum Anhören auf dem PC, Mac, Smartphone, Tablet oder Home-Entertainment-System zur Verfügung.
<G-vec00445-002-s032><listen.anhören><en> 18 million songs and thousands of audio books of all genres are available to listen to on PC, smartphone or home entertainment system.
<G-vec00445-002-s033><listen.anhören><de> Sie können die Aussprache von shen dao nicht anhören weil Ihr Browser keine audio Elemente unterstützt.
<G-vec00445-002-s033><listen.anhören><en> You cannot listen to the pronunciation of shen dao because your browser does not support the audio element.
<G-vec00445-002-s034><listen.anhören><de> Sie können die Aussprache von ruanmu nicht anhören weil Ihr Browser keine audio Elemente unterstützt.
<G-vec00445-002-s034><listen.anhören><en> You cannot listen to the pronunciation of buru because your browser does not support the audio element.
<G-vec00445-002-s035><listen.anhören><de> Auf dieser Seite können Sie den Klingelton "iPhone 5 - SMS ver2" anhören und herunterladen.
<G-vec00445-002-s035><listen.anhören><en> On this page you can listen to and download ringtone BlackBerry - SMS ver3, use the button "Play" to listen or "Download" to download a ringtone.
<G-vec00445-002-s036><listen.anhören><de> Auf dieser Seite können Sie den Klingelton "Samsung Ring" anhören und herunterladen.
<G-vec00445-002-s036><listen.anhören><en> On this page you can listen to and download ringtone Samsung Ring, use the button "Play" to listen or "Download" to download a ringtone.
<G-vec00445-002-s037><listen.anhören><de> Oft gibt es äußerst plausible Erklärungen, die man sich anhören sollte, um zu einem Urteil über Eignung oder Nicht-Eignung zu gelangen.
<G-vec00445-002-s037><listen.anhören><en> Often there are very plausible explanations you should listen to in order to understand and to make an accurate judgement on a candidate’s job fit.
