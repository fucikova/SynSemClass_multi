<G-vec00407-001-s163><pour_in.einfüllen><de> Zuletzt in die Pfanne werfen und 100 ml Wasser einfüllen.
<G-vec00407-001-s163><pour_in.einfüllen><en> Last throw in the pan and pour 100 ml of water.
<G-vec00407-001-s164><pour_in.einfüllen><de> In eine Glasschale 1 Liter Wasser einfüllen und 100 g Kupfersulfat darin auflösen.
<G-vec00407-001-s164><pour_in.einfüllen><en> In a glass dish pour 1 liter of water and dissolve 100 g of copper sulfate in it.
<G-vec00407-001-s165><pour_in.einfüllen><de> Im Anschluss das zu sprühende Material gut aufrühren (Bild rechts) und in den Farbbehälter einfüllen.
<G-vec00407-001-s165><pour_in.einfüllen><en> Then thoroughly stir the material to be sprayed (right image) and pour it into the paint container.
<G-vec00407-001-s166><pour_in.einfüllen><de> Getrocknetes Lungenkraut (1 Handvoll) in gleichen Anteilen mit gemahlenem Leinsamen vermischen und kochendes Wasser (1 l) einfüllen.
<G-vec00407-001-s166><pour_in.einfüllen><en> Dried lungwort (1 handful) mix in equal proportions with ground flax seed and pour boiling water (1 l).
<G-vec00407-001-s167><pour_in.einfüllen><de> Sonnenblumenöl und etwas Wasser einfüllen.
<G-vec00407-001-s167><pour_in.einfüllen><en> Pour in sunflower oil and some water.
<G-vec00407-001-s168><pour_in.einfüllen><de> Dann die Brühe einfüllen.
<G-vec00407-001-s168><pour_in.einfüllen><en> Then pour in the broth.
<G-vec00407-001-s169><pour_in.einfüllen><de> "In eine kleine Kastenform etwas von der Gemüsebrühe als ""Spiegel"" einfüllen und im Kühlschrank erstarren lassen."
<G-vec00407-001-s169><pour_in.einfüllen><en> Pour a little of the gelatine mixture into a small baking dish. Put it to set in the fridge.
<G-vec00407-001-s170><pour_in.einfüllen><de> Die weiße Spargelcremesuppe aufschäumen und kochend heiß in eine schlanke Suppentasse einfüllen.
<G-vec00407-001-s170><pour_in.einfüllen><en> Froth up the white cream of asparagus soup and pour into a slim soup bowl.
<G-vec00407-001-s171><pour_in.einfüllen><de> Für die Zubereitung müssen Sie nur eine kleine Menge pflanzlicher Rohstoffe mit kochendem Wasser einfüllen und 4-5 Minuten warten.
<G-vec00407-001-s171><pour_in.einfüllen><en> For their preparation, you just need to pour a small amount of vegetable raw materials with boiling water and wait 4-5 minutes.
<G-vec00407-001-s172><pour_in.einfüllen><de> Einfach Flasche aufschrauben und Reinigungsmittel in den Reinigungsmitteltank des Hochdruckreinigers einfüllen.
<G-vec00407-001-s172><pour_in.einfüllen><en> Simply unscrew bottle and pour detergent into the detergent tank of the pressure washer.
<G-vec00407-001-s173><pour_in.einfüllen><de> Dann 5 Minuten unter ständigem Rühren sprudelnd kochen lassen und sofort in saubere Gläser einfüllen.
<G-vec00407-001-s173><pour_in.einfüllen><en> Then cook with bubbly stirring for 5 minutes and immediately pour into clean glasses.
<G-vec00407-001-s174><pour_in.einfüllen><de> Zum Abdecken einfüllen und auf 3 Stunden stehen lassen.
<G-vec00407-001-s174><pour_in.einfüllen><en> Pour in to cover and leave on 3 hours.
<G-vec00407-001-s175><pour_in.einfüllen><de> Nachdem Sie ein Eigelb einfüllen und gut mischen müssen.
<G-vec00407-001-s175><pour_in.einfüllen><en> After you need to pour one yolk and mix well.
