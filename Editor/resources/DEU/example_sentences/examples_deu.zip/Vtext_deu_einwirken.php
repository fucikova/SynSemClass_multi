<G-vec00225-001-s266><act.einwirken><de> Die Früchte dieses Pflanzenschatzes besitzen einzigartige Fähigkeiten, die auf alle Anzeichen der Hautalterung einwirken.
<G-vec00225-001-s266><act.einwirken><en> A botanical treasure, this fruit boasts unique properties that act on all signs of aging.
<G-vec00225-001-s267><act.einwirken><de> Wichtig: Wenn die Decke keine Flecken geweißt wurden, wie Fett oder Rost, dann ist es notwendig, sie an den Deckenplatten zu entfernen, sonst werden sie immer wieder auf die Oberfläche einwirken.
<G-vec00225-001-s267><act.einwirken><en> Important: If the ceiling were whitewashed any stains, such as grease or rust, then it is necessary to remove them on the ceiling plates, otherwise they will again and again to act on the surface.
<G-vec00225-001-s268><act.einwirken><de> Wenn Sie mit der Einnahme von Kapseln beginnen, wird Ihr Körper mit Nährstoffen, Vitaminen und Mineralien angereichert, die auf die Ursache der Krankheit einwirken.
<G-vec00225-001-s268><act.einwirken><en> When you start taking capsules, your body is enriched with nutrients, vitamins and minerals that act on the root cause of the disease.
<G-vec00225-001-s269><act.einwirken><de> Natürlich überdauern die Zentren als solche, denn sie befinden sich im feinstofflichen Leib, von wo sie auf die entsprechenden physischen Zentren einwirken können.
<G-vec00225-001-s269><act.einwirken><en> Of course the centres themselves remain – for they are in the subtle body and it is from there that they act on the corresponding physical centres.
<G-vec00225-001-s270><act.einwirken><de> Frage stellen Beschreibung 100 ml = 49,90 € Tragen Sie unseren Cuticle Remover auf die Nagelhaut auf und lassen Sie ihn einwirken.
<G-vec00225-001-s270><act.einwirken><en> Description 100 ml = 49.90 € Enter our Cuticle Remover on the cuticle and allow it to act.
<G-vec00225-001-s271><act.einwirken><de> Du bist nicht mehr in deinem Körper, du kannst nicht mehr auf ihn einwirken.
<G-vec00225-001-s271><act.einwirken><en> You are no longer in your body, you understand, you can't act on it any more.
<G-vec00225-001-s272><act.einwirken><de> Innerhalb der Schirmkabine können äußere Einflüsse wie Licht, Temperatur und Umgebungsgeräusche, die auf den Probanden einwirken, sehr gut kontrolliert werden.
<G-vec00225-001-s272><act.einwirken><en> Inside the shielding cabin, external influences such as light, temperature, and ambient noise, which act on the subject, are very well controlled.
<G-vec00225-001-s273><act.einwirken><de> PTFE Nähfäden für die Filtration werden fast immer unter solchen Umständen verwendet, in denen aggressive Chemikalien oder Gase bei sehr hohen Temperaturen von 200°C - 260°C auf das Filtermedium und dessen Nähte einwirken.
<G-vec00225-001-s273><act.einwirken><en> PTFE Filtration Sewing Threads are almost always used in situations where aggressive chemicals or gases at very high temperatures of 200°C - 260°C act on the filter media and their seams.
<G-vec00225-001-s274><act.einwirken><de> Aber diese Kraft kann auf die Gesellschaft nur unter einer Bedingung einwirken: daß sie nämlich nicht von einer anderen Summe unmoralischer, aus der Praxis der Institutionen resultierender Lehren contrecarriert wird.
<G-vec00225-001-s274><act.einwirken><en> But this force can only act on society under one condition, that of not being crossed by a mass of contradictory immoral teachings resulting from the practice of institutions.
<G-vec00225-001-s275><act.einwirken><de> Produkt anschließend einwirken lassen, damit die Pflegeöle tief in das Leder eindringen können und es geschmeidig und griffig machen.
<G-vec00225-001-s275><act.einwirken><en> Allow the product to act afterwards so that the care oils can penetrate deep into the leather and make it supple and handy.
<G-vec00225-001-s276><act.einwirken><de> Das Gel Peeling lässt man auf der Haut einwirken und wird im Anschluss nicht abgewaschen.
<G-vec00225-001-s276><act.einwirken><en> The gel peeling is left to act on the skin and is not washed off afterwards.
<G-vec00225-001-s277><act.einwirken><de> Alle Masse – organisierte Energie – unterliegt dieser Anziehung außer in dem Maße, wie Bewegung und Verstand auf sie einwirken.
<G-vec00225-001-s277><act.einwirken><en> All mass—organized energy—is subject to this grasp except as motion and mind act upon it.
<G-vec00225-001-s278><act.einwirken><de> Sein Stück „Looking for a Missing Employee“ ist eine investigative Performance, in der der Künstler zum ‚Detektiv’ wird, der aktuelle Dokumente verwendet, um zu verstehen, wie Gerüchte, öffentliche Beschuldigungen, nationale politische Konflikte und Skandale in der von den Printmedien geformten Öffentlichkeit einwirken.
<G-vec00225-001-s278><act.einwirken><en> His piece “Looking for a Missing Employee” is an investigative performance in which the artist becomes a ‘detective’ interested in using actual documents to understand how rumours, public accusations, national political conflicts, and scandals act on the public sphere as shaped by print media.
<G-vec00225-001-s279><act.einwirken><de> Unter der klassischen physikalischen Therapie versteht man Behandlungsmethoden, die unter Nutzung physikalischer Gesetze auf den Körper einwirken, z.
<G-vec00225-001-s279><act.einwirken><en> Conventional physical therapy is understood as treatment methods that act on the body using physical laws, e.g.
<G-vec00225-001-s280><act.einwirken><de> Wie bei jedem Thermostat Thermostat im Gegensatz zu herkömmlichen, GSMT1S jeder Anlage mit dem Klimawandel verbunden und ermöglichen es uns, die Temperatur des Gehäuses durch SMS-Nachrichten ohne physisch auf ihn einwirken zu überprüfen.
<G-vec00225-001-s280><act.einwirken><en> As with any thermostat thermostat unlike traditional, GSMT1S any facility associated with climate change and allow us to check the temperature of the enclosure through SMS messages without having to physically act on it.
<G-vec00225-001-s281><act.einwirken><de> "Gerade heute, wo die aufgeheizte politische Stimmung online genutzt wird, um hyperreale Aufmerksamkeit zu erregen, ohne sich um die Konsequenzen des Gesagten im ""wahren Leben"" zu kümmern – gerade hier wird es wichtig zu bedenken, dass das ""Individuum"" kein abgeschlossenes ist, sondern ein Produkt der gesellschaftlichen Kräfte, die auf verschiedene und widersprüchliche, aber sicher spürbare Weise auf das Selbst einwirken."
<G-vec00225-001-s281><act.einwirken><en> "Especially at present – and particularly online, where, for example, an incendiary political climate can be harnessed to accrue hyperreal attention without regard for real life repercussions of one's words – it is important to consider that the ""individual"" is not an absolute but a product of social forces; ones that act upon the self in various, conflicting and certainly palpable ways."
<G-vec00225-001-s282><act.einwirken><de> Über einen Abstand von vielen Zentimetern, also ohne dem Stift zu nahe zu kommen, lässt der Magier nun seine kosmische Energie auf den Schreiber einwirken, dieser fängt an, sich geheimnisvoll zu bewegen und fällt schließlich von der Flasche.
<G-vec00225-001-s282><act.einwirken><en> At a distance of several centimetres, i.e. without getting too close to the pen, the magician now causes his cosmic energy to act on the pen, which begins to move mysteriously and finally falls off the bottle.
<G-vec00225-001-s283><act.einwirken><de> Der Vorteil ist, dass es auf jedes Metallmaterial einwirken kann, Sie können es nur verwenden.
<G-vec00225-001-s283><act.einwirken><en> The advantage is that it can act on any metal material, you can only use it.
<G-vec00225-001-s284><act.einwirken><de> Ihr werdet der leiblichen Persönlichkeit nach auch nicht länger auf dieser Erde zu leben haben wie irgendein anderer ordentlicher und gesunder Mensch; aber ihr werdet teils fortleben geistig wirkend in allen jenen, die euch in Meinem Namen nachfolgen werden, – andern Hauptteiles nach aber werdet ihr ewig fortleben bei Mir in Meinen Himmeln und werdet von da aus mehr denn jetzt einfließen und einwirken können auf die Menschen dieser Erde, die vor allem aus euch schon bekannten Gründen die Bestimmung haben, Meine Kinder gleich euch zu werden.
<G-vec00225-001-s284><act.einwirken><en> What your physical personality is concerned you also will not have to live longer on this Earth than any other normal healthy person, but you will continue to live and partly remain spiritually active in all those who will follow you in My name, but for another important part you will continue to live with Me in My Heavens forever and from there be able to act upon the people of this Earth, who, as you know, have above all the destination to become My children, just like all of you.
<G-vec00225-002-s209><act.einwirken><de> Erfindungsgemäß werden insbesondere Wirkstoffe eingesetzt, deren Hauptangriffspunkt die Gefäßwand ist, im Gegensatz zu Arzneistoffen, die primär die Blutgerinnung hemmen oder fördern oder Blutgerinnsel auflösen oder sonst wie auf Blutkomponenten einwirken.
<G-vec00225-002-s209><act.einwirken><en> According to the invention active ingredients are used in particular, whose main target is the vascular wall, as opposed to drugs that primarily inhibit blood clotting or promoting or dissolve blood clots or otherwise act as on blood components.
<G-vec00225-002-s210><act.einwirken><de> Natürliche Methoden sind sehr gut, weil sie nur dann auf den Körper einwirken, wenn er vollständig auf die Geburt vorbereitet ist.
<G-vec00225-002-s210><act.einwirken><en> Natural methods are very good because they act on the body only when it is fully prepared for childbirth.
<G-vec00225-002-s211><act.einwirken><de> Während es auf den astralen Formkörper einwirkt oder diesen durchflutet, werden alle Arten von Emotionen oder Empfindungen erzeugt, die insbesondere auf den Tastsinn, die innere Berührung, einwirken.
<G-vec00225-002-s211><act.einwirken><en> As it bears in upon or through or floods the astral form body, all manner of emotions or sensations are produced and these act particularly on the sense of touch, the inner touch.
<G-vec00225-002-s213><act.einwirken><de> Dank seiner Fähigkeit, freie Radikale einzufangen, kann es auch auf bestimmte Enzyme einwirken, die für die Hautalterung verantwortlich sind.
<G-vec00225-002-s213><act.einwirken><en> Thanks to its ability to capture free radicals, it can also act on certain enzymes responsible for skin aging.
<G-vec00225-002-s214><act.einwirken><de> Einfach mit einem GLORIA Drucksprühgerät wie der prima 5 ausbringen und einwirken lassen.
<G-vec00225-002-s214><act.einwirken><en> Simply apply with a GLORIA pressure sprayer like the prima 5 and let it act.
<G-vec00225-002-s215><act.einwirken><de> Nachteile zu vermeiden und eine Klemmvorrichtung zum Einklemmen, Ziehen oder Nachlassen eines durchlaufenden Seiles zu schaffen, die aus einfachen, leicht und mit geringen Kosten herstellbaren Teilen besteht, auf das einzuklemmende Zugmittel keine Schubspannungen in dessen Längsrichtung ausübt und den vollen Klemmdruck nur quer zur Zugmittellängsrichtung auf das Zugmittel einwirken läßt.
<G-vec00225-002-s215><act.einwirken><en> Object of the invention is to avoid these disadvantages and to provide a clamping device for clamping, pulling or easing of a continuous rope, which consists of simple, producible easily and at low cost parts, exerts on the be clamped traction means no shear stresses in the longitudinal direction and full clamping pressure is allowed to act only transversely to Zugmittellängsrichtung on the traction means.
<G-vec00225-002-s216><act.einwirken><de> 5 bis 10 Minuten einwirken lassen und dann abspülen.
<G-vec00225-002-s216><act.einwirken><en> Let it act for 5 to 10 min then rinse.
<G-vec00225-002-s218><act.einwirken><de> Den FLECKENENTFERNER für 15-30 Minuten einwirken lassen.
<G-vec00225-002-s218><act.einwirken><en> Let the Bloom Eliminator act for 15-30.
<G-vec00225-002-s219><act.einwirken><de> Anwendung: Felgen-Reiniger GEL auf die Felgen sprühen und bis zu 5 Minuten einwirken lassen.
<G-vec00225-002-s219><act.einwirken><en> Spray rim cleaner GEL on the rims and allow to act for up to 5 minutes.
<G-vec00225-002-s220><act.einwirken><de> Im Allgemeinen werden diese Dateien Dateien auflisten, auf die sie einwirken, eine Datei pro Zeile.
<G-vec00225-002-s220><act.einwirken><en> Generally, these files will list files to act on, one file per line.
<G-vec00225-002-s221><act.einwirken><de> Wenn man in diesem Bewußtsein verharren und die äußeren Ereignisse von oben betrachten kann, erkennt man, wie klein und unnütz sie sind, und man kann mit großer Macht auf sie einwirken.
<G-vec00225-002-s221><act.einwirken><en> If one can stand in that consciousness and watch the happenings from above, one can see how small and futile they are and one can then act upon them with a great Power.
<G-vec00225-002-s222><act.einwirken><de> Das langfristige Ziel ist es, die komplizierten Mechanismen zu entdecken, durch die diese Proteinkomplexe auf die Chromosomstruktur einwirken und Gene an- und ausschalten können.
<G-vec00225-002-s222><act.einwirken><en> The long-term goal is to discover the intricate mechanisms by which these protein complexes can act on chromosome structure, switching genes on and off.
<G-vec00225-002-s224><act.einwirken><de> Durch die zwei Betätigungsbereiche der Erfassungseinrichtung können an einer einzigen Kupplungsstelle der Küchenmaschine Bearbeitungsgeräte an betrieben werden, die auf unterschiedliche Weise auf die Betätigungseinrichtung einwirken.
<G-vec00225-002-s224><act.einwirken><en> By the two operation regions of the detection means can be operated at a single coupling point of the food processor processing devices that act in different ways on the control device.
<G-vec00225-002-s226><act.einwirken><de> Die Entwürfe werden von der Videokamera in zweidimensionale Skizzen übersetzt, die über die Projektion wiederum direkt in den realen Raum einwirken.
<G-vec00225-002-s226><act.einwirken><en> The drafts are translated by the video camera into two-dimensional sketches, which, in turn, act directly on the real space via the projection.
<G-vec00225-002-s227><act.einwirken><de> Der Troy Lee Designs "D3 Carbon" Fullface Helm - Nightfall Green (MIPS) kommt mit dem sogenannten MIPS-Sytem, welches die Rotationskräfte, die bei einem Aufprall auf den Kopf einwirken, reduziert.
<G-vec00225-002-s227><act.einwirken><en> The Troy Lee Designs "D3 Carbon" Fullface Helmet - Cadence Gray (MIPS) comes with the MIPS System which reduces the rotational forces that act on the head during an impact.
<G-vec00254-002-s323><influence.einwirken><de> Der Führer soll nicht einwirken.
<G-vec00254-002-s323><influence.einwirken><en> The handler should not influence the dog.
<G-vec00254-002-s324><influence.einwirken><de> Aus der Ferne kann das Umgebende Licht auf etwas einwirken, das von Ihm abgelöst und Ihm entgegengesetzt ist (Egoismus) – in Übereinstimmung mit der Sehnsucht eines Menschen nach Korrektur.
<G-vec00254-002-s324><influence.einwirken><en> From afar, the Surrounding Light can influence something that is removed and opposite to it (egoism) in accordance with a person’s yearning for correction.
<G-vec00254-002-s325><influence.einwirken><de> Durch das Einwirken weiterer, externer Prozesse stellt sich schließlich eine erhöhte Resilienz ostdeutscher Regionen gegenüber dem rückläufigen Erwerbspersonenpotenzial ein.
<G-vec00254-002-s325><influence.einwirken><en> The influence of additional external processes eventually creates an increase in regional resilience towards the declining labour force potential.
<G-vec00254-002-s326><influence.einwirken><de> Wenn ihr aber zweifelt, daß euch reine Wahrheit zugehen kann.... wenn ihr immer das Einwirken von Gegenkräften fürchtet, so sprechet ihr Mir wahrlich auch Meine Liebe, Weisheit und Macht ab und erkennet Meinem Gegner die Oberherrschaft zu.... die er wohl besitzt den Menschen gegenüber, die nicht ernstlich Mich anstreben, die ihm also die Macht über sich noch einräumen....
<G-vec00254-002-s326><influence.einwirken><en> But if you doubt that pure truth can be given to you.... if you always fear the influence of opposing forces, then you truly also deny My love, wisdom and might and give supreme control to My adversary.... which he has indeed over people who do not genuinely strive for Me, who thus still grant him power over themselves....
<G-vec00254-002-s327><influence.einwirken><de> Ich will euch Menschen nur retten, nicht aber dem Untergang verfallen lassen, aber Ich kann nicht wider euren Willen auf euch einwirken.
<G-vec00254-002-s327><influence.einwirken><en> I just want to save you humans but not leave you to perish, but I cannot influence you against your will.
<G-vec00254-002-s328><influence.einwirken><de> Für den Krisenzeitraum kann dagegen kein aussagefähiges Ergebnis ermittelt werden, woraus abgeleitet werden kann, dass im Krisenzeitraum andere Einflussfaktoren als die in dieser Arbeit geprüften auf das Working Capital Management einwirken.
<G-vec00254-002-s328><influence.einwirken><en> In contrast, no meaningful result can be identified for the crisis period, from which it can be deduced that influence factors other than those reviewed in this work affected working capital management during the crisis period.
<G-vec00254-002-s329><influence.einwirken><de> Jeder denkende Mensch wird berührt werden durch Mein Einwirken, und besonders die Menschen, die sich selbst betroffen fühlen, die ein ungewöhnlicher Eingriff indirekt berührt.
<G-vec00254-002-s329><influence.einwirken><en> Every thinking man will be touched through my influence, and particularly those men, who feel themselves concerned, who an unusual intervention touches directly.
<G-vec00254-002-s330><influence.einwirken><de> Bei ständigem Einwirken eines Wasserdrucks ist eine Mindestmembrandicke von 2,0 mm vorzusehen.
<G-vec00254-002-s330><influence.einwirken><en> Under the influence of permanent water pressure a minimum thickness of 2.0 mm of the geomembrane has to be foreseen.
<G-vec00254-002-s331><influence.einwirken><de> Jedoch können die Lichtwesen gedanklich einwirken auch insofern, als daß sie die Mitmenschen zur Fürbitte anregen, und diese wird dann wahrlich nicht ohne Wirkung sein.
<G-vec00254-002-s331><influence.einwirken><en> However, the beings of light can use mental influence and motivate other people to intercede, and this certainly will not fail to have an effect.
<G-vec00254-002-s332><influence.einwirken><de> Es können oft schon winzige Anlässe sein, (3.8.1951) die ihm sein Einwirken möglich machen.... wenn weltliche Gedanken einen Menschen bewegen, die dann stets Versuchungen sind, durch welche der Satan sich einzudrängen sucht.
<G-vec00254-002-s332><influence.einwirken><en> Often the slightest occasions will enable him to exert his influence.... if worldly thoughts occupy a person, which will then always be temptations by which Satan will try to push himself in.
<G-vec00254-002-s333><influence.einwirken><de> Um Komplikationen mit der Kausalität zu vermeiden müssen wir verbieten, dass Rot, der in O mit A eine Wechselwirkung hatte, je in die zeitliche Vergangenheit von Schwarz vor O einwirken kann.
<G-vec00254-002-s333><influence.einwirken><en> In order to avoid complications with causality we must forbid that red, which had an interaction at O with A, can ever influence the temporal past of black before point O.
<G-vec00254-002-s334><influence.einwirken><de> Ich kann nicht bestimmend auf euer Erdenleben einwirken, solange ihr nicht freiwillig Mir die Zusicherung gegeben habt, aber Ich kann sofort euer Schicksal in Meine Hand nehmen, wenn diese Zusicherung freiwillig erfolgt ist.
<G-vec00254-002-s334><influence.einwirken><en> I cannot have a decisive influence on your earthly life as long as you have not voluntarily given Me this assurance, but I can instantly take your destiny into My hands as soon as this assurance has voluntarily taken place.
<G-vec00254-002-s335><influence.einwirken><de> Unter Zuhilfenahme des Fixed Effects Modells kann für den Gesamtzeitraum ein signifikanter Einfluss der Determinanten Innenfinanzierungskraft und Investitionen auf das Working Capital Management nachgewiesen werden, während im Vorkrisenzeitraum das Wachstumspotential und im Nachkrisenzeitraum die Innenfinanzierungskraft als einzige Einflussfaktoren signifikant auf den Cash Conversion Cycle einwirken.
<G-vec00254-002-s335><influence.einwirken><en> With the aid of the fixed effects model a significant influence of the determinants internal financing capability and investments on working capital management can be proven for the entire period, while in the pre-crisis period growth potential and in the post-crisis period internal financing capacity are the only influence factors with a significant effect on the cash conversion cycle.
<G-vec00254-002-s336><influence.einwirken><de> Es ist darum sehr wichtig, dass die Elefantenpfleger beruhigend auf das Muttertier einwirken und das Neugeborene vor ihrer gestressten Mutter schützen können.
<G-vec00254-002-s336><influence.einwirken><en> That’s why it is very important that the elephant keepers have a calming influence on the mother and are capable of protecting the new-born animal against its stressed out mother.
<G-vec00254-002-s337><influence.einwirken><de> Vor dem Hintergrund der Einbeziehung Osteuropas in die europäische Integration ist von besonderem Interesse, inwieweit der innere Demokratisierungsprozeß und der Übergang zur Marktwirtschaft nach der Spaltung fortgeführt werden oder aber alte kommunistische oder neue autoritäre Strukturen, die den Transformationsprozeß gleichwohl beeinflussen, wieder an Gewicht gewinnen oder sogar maßgeblich auf die weitere Entwicklung einwirken.
<G-vec00254-002-s337><influence.einwirken><en> Against the backdrop of drawing Eastern Europe more into the European integration process, it is of particular interest to what extent the democratization process and the transition to a market economy continued once the division took place, or whether old communist or new authoritarian structures that also exert influence on the transformation process have increased in importance, or have even had a decisive influence.
<G-vec00254-002-s338><influence.einwirken><de> Sie analysierten das Zusammenspiel zwischen microRNA und der Genexpression und identifizierten konkrete Paare aus microRNA und Genen, die aufeinander einwirken.
<G-vec00254-002-s338><influence.einwirken><en> They analyzed the interaction between microRNA and gene expression, identifying specific pairs of microRNAs and genes that influence each other.
<G-vec00254-002-s339><influence.einwirken><de> Die Gegenkraft Gottes kann gerade auf die Gedankenwelt dieses Menschen erfolgreich einwirken insofern, als dieser sich gern damit befaßt, was der Welt angehört, weil er zumeist irdische Ziele anstrebt.
<G-vec00254-002-s339><influence.einwirken><en> The opposition power of God can particularly successfully have an influence on the thought world of this man insofar, as he likes to deal with that, what belongs to the world, because he mostly strives for earthly aims.
<G-vec00254-002-s340><influence.einwirken><de> Die sogenannten Volksmärchen nehmen ihren Ausgangspunkt in einer realistischen, unglücklichen Situation, die durch das Einwirken eines wunderbaren Elements verbessert wird.
<G-vec00254-002-s340><influence.einwirken><en> The so-called folktales have their starting point in a realistic, unfortunate situation, that is improved by the influence of a miraculous element.
<G-vec00254-002-s341><influence.einwirken><de> In diesem Bereich obliegt gerade die sozialpolitische Verantwortung dem demokratischen Entscheidungsprozess, auf den die Bürger mit der freien und gleichen Wahl einwirken wollen.
<G-vec00254-002-s341><influence.einwirken><en> In this area, the responsibility concerning social policy in particular is subject to the democratic decision-making process, which citizens want to influence through free and equal elections.
<G-vec00305-002-s038><sit.einwirken><de> Bedecke die Pickel mit Maisstärke und lasse sie 20 Minuten lang einwirken.
<G-vec00305-002-s038><sit.einwirken><en> Douse the bumps in cornstarch and let it sit for 20 minutes.
<G-vec00305-002-s039><sit.einwirken><de> Lasse den Fleck ein paar Minuten lang einwirken.
<G-vec00305-002-s039><sit.einwirken><en> Let the stain sit for a few minutes.
<G-vec00305-002-s040><sit.einwirken><de> Lasse alles mindestens eine Stunde oder über Nacht einwirken.
<G-vec00305-002-s040><sit.einwirken><en> Let it sit for at least an hour or up to overnight.
<G-vec00305-002-s041><sit.einwirken><de> Streichen Sie diese Paste auf die vergilbten Stellen und lassen diese 10 Minuten einwirken.
<G-vec00305-002-s041><sit.einwirken><en> Combine the two to make a paste and let it sit for 10-15 minutes.
<G-vec00305-002-s042><sit.einwirken><de> Geben Sie ein Päckchen Backpulver oder eine Teelöffel Salz zusammen mit heißem Wasser in das betroffene Gefäß und lassen Sie dies über Nacht einwirken.
<G-vec00305-002-s042><sit.einwirken><en> Pour a packet of baking soda or salt along with hot water into the vessel and let this sit over night.
<G-vec00305-002-s043><sit.einwirken><de> 1 Decke den Abfluss zu und lasse die Mischung einwirken.
<G-vec00305-002-s043><sit.einwirken><en> 1 Cover and let the mixture sit.
<G-vec00305-002-s044><sit.einwirken><de> Bei Schuppen können Sie versuchen, Ihre Kopfhaut mit gleichen Teilen Essig und Wasser (gemischt) zu behandeln, wickeln Sie ein Handtuch um den Kopf, und lassen Sie es für eine Stunde einwirken.
<G-vec00305-002-s044><sit.einwirken><en> Spraying your scalp with equal parts vinegar and water (mixed). 2. Wrap a towel around your head and leave it to sit for an hour.
<G-vec00305-002-s045><sit.einwirken><de> Lasse es daher einige Minuten einwirken.
<G-vec00305-002-s045><sit.einwirken><en> Let it sit for a few minutes.
<G-vec00305-002-s046><sit.einwirken><de> Bedecke dein Haar und lass sie einwirken.
<G-vec00305-002-s046><sit.einwirken><en> Cover your hair and let it sit.
<G-vec00305-002-s047><sit.einwirken><de> Lass die Maske für etwa 15 Minuten bis sie getrocknet ist einwirken.
<G-vec00305-002-s047><sit.einwirken><en> Allow it to sit until it dries, about 15 minutes.
<G-vec00305-002-s048><sit.einwirken><de> Lassen Sie die Klimaanlage 10 bis 15 Minuten einwirken.
<G-vec00305-002-s048><sit.einwirken><en> Let the conditioner sit for 10 to 15 minutes.
<G-vec00305-002-s049><sit.einwirken><de> Lasse den Ketchup ein paar Minuten lang auf dem Gegenstand einwirken.
<G-vec00305-002-s049><sit.einwirken><en> Let the ketchup sit on the item for a few minutes.
<G-vec00305-002-s050><sit.einwirken><de> Lass die Cola einwirken.
<G-vec00305-002-s050><sit.einwirken><en> Let the Coke sit.
<G-vec00305-002-s051><sit.einwirken><de> Streu Natron auf den Fleck und lass es ein bis zwei Minuten lang einwirken.
<G-vec00305-002-s051><sit.einwirken><en> Sprinkle baking soda on a stain and let it sit for 1-2 minutes.
<G-vec00305-002-s052><sit.einwirken><de> Trage diese Maske auf deine Wangen auf und lass sie 10 Minuten einwirken, bevor du sie mit lauwarmem Wasser abspülst.
<G-vec00305-002-s052><sit.einwirken><en> Apply this pack to your cheeks and let it sit for 10 minutes before rinsing it off with lukewarm water.
<G-vec00305-002-s053><sit.einwirken><de> Besprühe den Bereich und wickle ihn in die Alufolie ein, um zu verhindern, dass er den Rest deiner Haare berührt, während du das Peroxid einwirken lässt.
<G-vec00305-002-s053><sit.einwirken><en> Spray these chunks and wrap them in the foil sheets to keep them from touching the rest of your hair while you let the peroxide sit in your hair.
<G-vec00305-002-s054><sit.einwirken><de> Dafür einfach die Trockenmarinaden ohne Öl vor dem Grillen auf das Gargut aufgetragen und für einige Zeit einwirken lassen.
<G-vec00305-002-s054><sit.einwirken><en> Before you start grilling, simply spread the dry marinade onto the food (without oil)and let it sit for a few minutes.
<G-vec00305-002-s055><sit.einwirken><de> Nehme eine großzügige Menge Schuhputzmittel, reibe es an die Lederschuhe oder Stiefel und lasse es 10-15 Minuten einwirken.
<G-vec00305-002-s055><sit.einwirken><en> Take a generous amount of shoe shine, rub it on your leather shoes or boots, and let it sit for 10-15 minutes.
<G-vec00305-002-s056><sit.einwirken><de> Trage die Paste mit einer Nagelbürste auf die gelben Bereiche deiner Haut auf und lasse sie 15 Minuten lang einwirken.
<G-vec00305-002-s056><sit.einwirken><en> Use a nail brush to apply the paste to the yellow areas of your skin and let it sit for 15 minutes.
