<G-vec00394-002-s570><rest.ausruhen><de> Kein Trauma, keine Notwendigkeit, sich auszuruhen, beeinflusst die Arbeit nicht.
<G-vec00394-002-s570><rest.ausruhen><en> No trauma, no need to rest, does not affect the work.
<G-vec00394-002-s571><rest.ausruhen><de> 2730711 Dieses milde, beruhigende Shampoo bringt sogar die empfindliche Kopfhaut, um sich auszuruhen.
<G-vec00394-002-s571><rest.ausruhen><en> 2730711 This mild, soothing shampoo brings even the most sensitive scalp to rest.
<G-vec00394-002-s572><rest.ausruhen><de> Guter Ort, um sich auszuruhen.
<G-vec00394-002-s572><rest.ausruhen><en> Good place to rest.
<G-vec00394-002-s573><rest.ausruhen><de> Wenn Sie den Tag in ruhiger Atmosphären ausklingen lassen haben, finden Sie 4 sehr komfortable Zimmer, die Ihnen erlauben, sich auszuruhen und aufzuladen.
<G-vec00394-002-s573><rest.ausruhen><en> When you have finished the day in a quiet atmosphere, you will find 4 very comfortable rooms that allow you to rest and recharge your batteries.
<G-vec00394-002-s574><rest.ausruhen><de> Sie müssen zusätzlich Zeit in Anspruch nehmen, um sich auszuruhen und auch zu schlafen.
<G-vec00394-002-s574><rest.ausruhen><en> You should additionally take time to rest and rest.
<G-vec00394-002-s575><rest.ausruhen><de> Bevor sie in die Truhen gehen, um sich auszuruhen, werden die Trauben in den Weinbergen sorgfaltig ausgewahlt und beschadigte oder unvollstandige Exemplare weggeworfen.
<G-vec00394-002-s575><rest.ausruhen><en> Before they go into chests to rest, the grapes are carefully selected in the vineyards. Any damaged or imperfect specimens are discarded.
<G-vec00394-002-s576><rest.ausruhen><de> Sie ließ ihm die Zeit nicht, sich auszuruhen und kam auf ihn, wie er so sehr mochte, daß sie es macht.
<G-vec00394-002-s576><rest.ausruhen><en> It did not leave him time to rest and came on him as it liked so much that it does it.
<G-vec00394-002-s577><rest.ausruhen><de> Nach dem Ausflug nach Florenz haben die Gäste etwas Zeit, um sich auszuruhen und um sich geistig auf den Kochabend vorzubereiten.
<G-vec00394-002-s577><rest.ausruhen><en> Once back to the campsite, you will have some time to rest and to get ready for the first workshop at the cooker’s home
<G-vec00394-002-s578><rest.ausruhen><de> Never work out an aufeinander folgenden Tagen zu geben, Ihre Muskeln eine Chance, um sich auszuruhen und wieder aufzubauen.
<G-vec00394-002-s578><rest.ausruhen><en> Never Work Out On consecutive days, to allow muscles to rest and recover.
<G-vec00394-002-s579><rest.ausruhen><de> Ein echtes Geschenk für die Hedonisten, die Epikureer und Liebhaber, um sich auszuruhen.
<G-vec00394-002-s579><rest.ausruhen><en> A real gift for the hedonists, the Epicureans and lovers to have a good rest.
<G-vec00394-002-s580><rest.ausruhen><de> Versuchen Sie gelegentlich, Ihr iOS-Gerät herunterzufahren, und geben Sie ihm Zeit, um sich auszuruhen.
<G-vec00394-002-s580><rest.ausruhen><en> Every once in awhile, try to shut down your iOS device and give it time to rest.
<G-vec00394-002-s581><rest.ausruhen><de> Gleichzeitig argumentieren Befürworter der Herbsttransplantation, dass es den Trieben in dieser Zeit gelingt, im Winter gut zu wurzeln und sich auszuruhen.
<G-vec00394-002-s581><rest.ausruhen><en> At the same time, supporters of the autumn transplant argue that during this time the shoots manage to root well and rest in the winter.
<G-vec00394-002-s582><rest.ausruhen><de> Es ist nötig, meine Freunde, sich auszuruhen und das zu verinnerlichen, was ihr vielleicht lernt.
<G-vec00394-002-s582><rest.ausruhen><en> It is necessary my friends to rest and absorb that which you perhaps are learning.
<G-vec00394-002-s583><rest.ausruhen><de> Sie gingen in das Gebäude des zerstörten Cafes und beschlossen, sich auszuruhen.
<G-vec00394-002-s583><rest.ausruhen><en> Going into the building of the destroyed cafe they decided to rest.
<G-vec00394-002-s584><rest.ausruhen><de> Es ist ein erstaunlicher Ort, um sich auszuruhen und der Besitzer war sehr charmant.
<G-vec00394-002-s584><rest.ausruhen><en> It's an amazing place to rest and the owner was very charming.
<G-vec00394-002-s585><rest.ausruhen><de> Ein Hotelzimmer ist ein Ort, um sich auszuruhen.
<G-vec00394-002-s585><rest.ausruhen><en> A hotel room is a place of rest.
<G-vec00394-002-s586><rest.ausruhen><de> Der alte Bettler benutzte Trevors Abwesenheit, sich ein Weilchen auf einer Holzbank auszuruhen, die hinter ihm stand.
<G-vec00394-002-s586><rest.ausruhen><en> absence to rest for a moment on a wooden bench that was behind him.
<G-vec00394-002-s587><rest.ausruhen><de> Je nach Anzahl der Urlauber wohnen Sie in einem Ferienhaus / Bungalow, um sich auszuruhen und den Service eines ruhigen und sonnigen Campingplatzes zu genießen.
<G-vec00394-002-s587><rest.ausruhen><en> Depending on the number of holidaymakers stay in a cottage / bungalow to rest while enjoying the services of a quiet and sunny campsite.
<G-vec00394-002-s588><rest.ausruhen><de> Wie immer war es nach einem Kampf Zeit, aufzuessen und sich auszuruhen.
<G-vec00394-002-s588><rest.ausruhen><en> As always, it was time to eat up and rest after a match.
<G-vec00545-002-s019><relax.ausruhen><de> Die einzigartige Schönheit und die umfangreiche Vielfalt der Flora und Fauna der Seiser Alm sind außergewöhnlich und laden zum Wandern, Bergsteigen, Klettern, Ausruhen und einfach nur zum Genießen ein.
<G-vec00545-002-s019><relax.ausruhen><en> The incomparable beauty and incredible variety of Alpe di Siusi's flora and fauna are truly unique around the world. The irresistible charm of such a special environment will entice you to go hiking, climbing or just relax, admiring the splendour of the surrounding natural wonderland.
<G-vec00545-002-s020><relax.ausruhen><de> [13.9.2012 - 15.10.2012] Resident Evil 5 - Bielik bevorzugt Themen wie Engel, Tiger, Porträte bekannter Menschen, Selbstporträte, bei denen er psychisch ausruhen kann.
<G-vec00545-002-s020><relax.ausruhen><en> Starring: Milla Robert Bielik prefers themes such as angels, tigers, portraits of famous people, self-portraits, during creation of which he can mentally relax.
<G-vec00545-002-s021><relax.ausruhen><de> Dank über 40 modernsten Transportanlagen können Sie im Nu von einer Talseite zur nächsten wechseln, variantenreiche Abfahrten genießen oder in den gemütlichen Hütten ausruhen.
<G-vec00545-002-s021><relax.ausruhen><en> The more than 40 state-of-the-art lifts allow you to switch from one side of the valley to the other in no time, enjoy the great variety of ski runs or relax in the cosy mountain restaurants.
<G-vec00545-002-s022><relax.ausruhen><de> Unsere urgemütlichen Wohnungen laden zum Erholen, Ausruhen und Kuscheln ein.
<G-vec00545-002-s022><relax.ausruhen><en> Our apartments are very cosy and invite you to rest, relax and unwind.
<G-vec00545-002-s023><relax.ausruhen><de> Gerade richtig zum Verweilen und Ausruhen.
<G-vec00545-002-s023><relax.ausruhen><en> Just right to linger and relax.
<G-vec00545-002-s024><relax.ausruhen><de> Einfach zurücklehnen und ausruhen im Urlaubshotel Zum Stern in Bad Hofgastein.
<G-vec00545-002-s024><relax.ausruhen><en> Just lean back and relax at the vacation hotel Zum Stern in Bad Hofgastein.
<G-vec00545-002-s025><relax.ausruhen><de> Was ich wichtig finde: eine kleine Gruppe oder Einzelpersonen behandeln, damit ich mehr persönliche Unterstützung hinsichtlich Loslassen und Ausruhen, Achtsamkeit und Tiefe verleihen kann.
<G-vec00545-002-s025><relax.ausruhen><en> What I find important: work with small groups or give private sessions for personal attention and guidance to work on letting go and relax, mindfulness and depth.
<G-vec00545-002-s026><relax.ausruhen><de> Auf der Kriegeralpe angekommen kann man sich am Kamin aufwärmen oder an warmen Tagen auch vor der Hütte auf der Bank ausruhen oder im Liegestuhl sonnen.
<G-vec00545-002-s026><relax.ausruhen><en> Once at the Kriegeralpe, you can warm up by the fireplace or on warm days, relax on the bench outside the lodge or sunbathe on a recliner.
<G-vec00545-002-s027><relax.ausruhen><de> Es ist ideal für Naturliebhaber und diejenigen die sich weg vom Verkehr ausruhen möchten aber gleichzeitig in der Nähe von den Touristischen Veranstaltungen sein möchten.
<G-vec00545-002-s027><relax.ausruhen><en> It is an ideal place for nature lovers and for those who want to relax away from the traffic, while at the same time staying close to the center of entertainment.
<G-vec00545-002-s028><relax.ausruhen><de> Noch bevor wir uns ausruhen konnten, mussten wir eine Pressekonferenz geben, da mehrere Pressevertreter anwesend waren.
<G-vec00545-002-s028><relax.ausruhen><en> Before we could relax, we had to give a press conference, as several members of the media were attending.
<G-vec00545-002-s029><relax.ausruhen><de> Die Sonnenterasse mit bunten Liegen ist ideal zum Energie tanken und ausruhen.
<G-vec00545-002-s029><relax.ausruhen><en> The sun terrace with its colourful loungers is the ideal place to chill and relax.
<G-vec00545-002-s030><relax.ausruhen><de> Die harmonischen Klänge in C+E und C+G dienen der Beruhigung sämtlicher Körperfunktionen und helfen beim Ausruhen.
<G-vec00545-002-s030><relax.ausruhen><en> The balanced sounds heard in C+E and C+G help to relax the body in a number of ways and put the listener at ease.
<G-vec00545-002-s031><relax.ausruhen><de> Zum Plaudern, Ausruhen und Revitalisieren bieten 60 Sitzplätze und eine kleine Terrasse genügend Platz.
<G-vec00545-002-s031><relax.ausruhen><en> In order to chat, to relax and to rejuvenate 60 seats and a small terrace offer sufficient space.
<G-vec00545-002-s032><relax.ausruhen><de> Harmonische,ruhige und freundliche Atmosphare, macht dieses Hostel atraktiv genauso wie der bedeckte Hof mit den Sitzplätzen draußen unter den Schirmen, bestimmt zum Ausruhen und Treffen mit Freunden.HOSTELAUSSTATTUNG: Kapazität: 17 Betten 2x 2 Betten, 1x 3 Betten, 1x 4 Betten und 1x 6 Betten.Zu jedem Bett im Zimmer stöht ein Sperrkasten zur Verfügung.Zur Verfügung gibt es 2 Badezimmer(3 Duschen und 3 Toaletten).Ungeteilt ist eine vollausgestattete gemeinsame Küche mit Speisezimmer,einschließlich TV+Satelit (ein Sparherd, ein Kühlschrank, eine Mikrowelle, eine Kanne, eine Kaffeemaschine).WIR BIETEN KOSTENLOS: - in der Küche: Tee, Kaffe und Zucker - in der Reception: Wir leihen: Handtücher, gesellschaftliche Spiele, touristenlandkarten.
<G-vec00545-002-s032><relax.ausruhen><en> It is a newly equipped place providing all the service necessary for independent travellers. The highlight of the hostel is definitely a friendly atmosphere right in the middle of all the events. There is also a nice romantic courtyard with greenery and outside sitting under the umbrellas for a relax with friends.FACILITIES:Hostel capacity is for 17 people 2x 2 beds, 1x triple room, 1x 4 beds and 1x 6 bedsEverybody has their own locker.There are 2 bathrooms (3 showers and 3 toilettes).There is a shared kitchen with a dining room including TV+satellite (cooker, fridge, microwave, electric kettle, coffee machine).
<G-vec00545-002-s033><relax.ausruhen><de> Wir schaffen private, ruhige und vom übrigen Terminal T4 abgegrenzte Bereiche, damit Sie sich entspannen, ausruhen und die Zeit am Flughafen nutzen können.
<G-vec00545-002-s033><relax.ausruhen><en> We create private, silent spaces isolated from the rest of T4 so you can unwind, relax and make the most of your time at the airport.
<G-vec00545-002-s034><relax.ausruhen><de> Natürlich darf man sich darauf nicht ausruhen.
<G-vec00545-002-s034><relax.ausruhen><en> Of course, we cannot afford to relax.
<G-vec00545-002-s035><relax.ausruhen><de> Nach dem Abstieg erwartet Sie ein Essen im Lager; Freizeit und Ausruhen; Übernachtung wieder in Lager 1.
<G-vec00545-002-s035><relax.ausruhen><en> After the descent a meal is waiting for you in the camp. Free time and time to relax. Overnight stay again in camp 1.
<G-vec00545-002-s036><relax.ausruhen><de> Oben angekommen kann man sich auf der gewundenen Bank ausruhen und die Landschaft bestaunen.
<G-vec00545-002-s036><relax.ausruhen><en> Once you reached the top, you can sit back and relax on the winding bench and admire the surroundings.
<G-vec00545-002-s037><relax.ausruhen><de> Durch die gro├če Glasfront im Wohnraum haben Sie einen tollen Blick auf die von D├╝nengras umgebene Sonnenterrasse (30 qm), die zum Sonnenbaden, Ausruhen und Verweilen, aber auch zum Grillen und Beisammensein einl├Ądt.
<G-vec00545-002-s037><relax.ausruhen><en> A large glass front in the living room offers a beautiful view on the sun patio which is surrounded by marram grass. This 30 qm patio invites our guests not only to sunbathe, relax and linger but also to meet friends or have a barbecue.
