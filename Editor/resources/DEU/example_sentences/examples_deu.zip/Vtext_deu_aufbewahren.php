<G-vec00211-002-s038><keep.aufbewahren><de> Der Fisch ist frisch und ist ein Souvenir, das man in Lissabon kaufen kann, um es aufzubewahren und jemandem zu verschenken.
<G-vec00211-002-s038><keep.aufbewahren><en> The fish are fresh and are souvenirs that can be bought from Lisbon to keep and to give as a gift to someone.
<G-vec00211-002-s039><keep.aufbewahren><de> Bei äußerlich erkennbaren Transportschäden ist für den Fall, dass die Lieferung trotzdem angenommen wird, schon bei Annahme der Lieferung der Schaden auf den jeweiligen Versanddokumenten zu vermerken und vom Zusteller quittieren zu lassen; die Verpackung ist aufzubewahren.
<G-vec00211-002-s039><keep.aufbewahren><en> In the event of acceptance of the delivery despite apparent transport damages, the damage shall be recorded on the respective shipping documents upon acceptance of the delivery and this shall be signed by the deliverer; the customer shall keep the packaging.
<G-vec00211-002-s040><keep.aufbewahren><de> Es wird empfohlen, eine Kopie der Transaktionsdaten aufzubewahren.
<G-vec00211-002-s040><keep.aufbewahren><en> It is recommended that you keep a copy of transaction data.
<G-vec00211-002-s041><keep.aufbewahren><de> Wir empfehlen Ihnen, eine Kopie des Fahrzeugmietvertrags und der Unterlagen der Miettransaktion aufzubewahren, einschließlich der Unterlagen für die Rückgabe des Fahrzeugs, falls es später Untersuchungen bezüglich des von Ihnen unterzeichneten Fahrzeugmietvertrags gibt.
<G-vec00211-002-s041><keep.aufbewahren><en> We recommend that you keep a copy of the Car Rental Agreement and any other document related to the Car Rental Transaction, including documents pertaining to the drop-off of the car, in case of a future inquiry related to the Car Rental Agreement signed by you.
<G-vec00211-002-s042><keep.aufbewahren><de> Wenn wir personenbezogene Daten mit anderen Organisationen teilen, verlangen wir von diesen, die Daten sicher aufzubewahren.
<G-vec00211-002-s042><keep.aufbewahren><en> When we share personal information with other organisations we require them to keep the information secure.
<G-vec00211-002-s043><keep.aufbewahren><de> Wir mögen SPAM gar nicht und versprechen, Ihre Email-Addresse sicher aufzubewahren.
<G-vec00211-002-s043><keep.aufbewahren><en> - - We hate SPAM and promise to keep your email address safe.
<G-vec00211-002-s044><keep.aufbewahren><de> Zum Schutz vor Missbrauch empfehlen wir, airberlin-Wertgutscheine für Dritte unzugänglich aufzubewahren, da mit Hilfe des Gutschein-Codes und zugehöriger PIN jedermann zulasten Ihres Guthabens buchen kann.
<G-vec00211-002-s044><keep.aufbewahren><en> To safeguard your voucher against unauthorised use, we recommend that you keep airberlin flight vouchers in a safe place and inaccessible to third parties, since anyone can use your voucher code and PIN to book a flight on your credit.
<G-vec00211-002-s045><keep.aufbewahren><de> Nur befugtes Personal der Galderma Gruppe oder unsere Beauftragten (die sich verpflichtet haben, Informationen sicher aufzubewahren) haben Zugang zu personenbezogenen Daten.
<G-vec00211-002-s045><keep.aufbewahren><en> Only authorized Galderma group staff or our agents (who have agreed to keep information secure) have access to personally identifiable information.
<G-vec00211-002-s046><keep.aufbewahren><de> Darin werden Arbeitgeber verpflichtet, eine Risikoanalyse durchzuführen und diesbezügliche Unterlagen aufzubewahren, außerdem müssen sie Schutz- und Präventionsdienste für Sicherheit und Gesundheitsschutz im Unternehmen und/oder Betrieb einrichten.
<G-vec00211-002-s046><keep.aufbewahren><en> It obliges employers to carry out risk assessment and keep documentation of it, as well as to create occupational health and safety protective and preventive services in the company and/or establishment.
<G-vec00211-002-s047><keep.aufbewahren><de> Es hat einen glatten Bund mit einem Kordelzug, der eine zuverlässige Passform bietet, und eine Reißverschlusstasche an der Seite, um Ihre Brieftasche und Trainingsnotizen sicher aufzubewahren.
<G-vec00211-002-s047><keep.aufbewahren><en> It has a smooth waistband with a drawstring that offers a reliable fit and a zipper pocket on the side to keep your wallet and workout notes safe.
<G-vec00211-002-s048><keep.aufbewahren><de> Es kann hilfreich sein, eine Aufgabenliste zu erstellen und sie an einem Ort aufzubewahren, den jeder sehen kann.
<G-vec00211-002-s048><keep.aufbewahren><en> It can be helpful to make a chore list and keep it in a place that everyone can see.
<G-vec00211-002-s049><keep.aufbewahren><de> f) personenbezogene Informationen über andere Benutzer zu sammeln oder aufzubewahren, außer in den Fällen, in denen von diesen Benutzern eine besondere Genehmigung erteilt wurde.
<G-vec00211-002-s049><keep.aufbewahren><en> f) collect or keep any personal information concerning other users except in cases where specific authorisation has been granted by the said users.
<G-vec00211-002-s050><keep.aufbewahren><de> Achte darauf, eine Kopie deiner Ersatzcodes an einem sicheren Ort aufzubewahren.
<G-vec00211-002-s050><keep.aufbewahren><en> Make sure you keep a copy of your Backup codes in a safe place.
<G-vec00211-002-s051><keep.aufbewahren><de> Aus Sicherheitsgründen behalten wir uns jedoch vor, Daten in jedem Fall für mindestens sechs Monate aufzubewahren.
<G-vec00211-002-s051><keep.aufbewahren><en> For security reasons however, we reserve the right to keep data available for a period of six months.
<G-vec00211-002-s052><keep.aufbewahren><de> In dieser Anwendung werden Sie als junges Mädchen auftreten, das die Macht hat, jede Art von Objekt zu absorbieren und diese in ihrem Körper aufzubewahren, um sie vor dem mächtigen Dämonen, der den Planeten zerstören will, zu schützen.
<G-vec00211-002-s052><keep.aufbewahren><en> In this application you’ll play as a young girl who has the power to absorb any type of object and keep it in her body to protect it from the powerful demon who will destroy the planet.
<G-vec00211-002-s053><keep.aufbewahren><de> Die betroffenen Wirtschaftsbeteiligten müssen diese Aktivitäten in einem Register aufzeichnen, das drei Jahre lang aufzubewahren ist.
<G-vec00211-002-s053><keep.aufbewahren><en> The operators concerned must keep records of all transactions for a period of three years.
<G-vec00211-002-s054><keep.aufbewahren><de> Vielen Wimpernstylisten wird empfohlen, den Kleber im Kühlschrank aufzubewahren, das ist jedoch ziemlich umstritten, weil es einen negativen Einfluss auf die Integrität des Fläschchens haben kann.
<G-vec00211-002-s054><keep.aufbewahren><en> Many stylists were recommended to keep it in the refrigerator, but this proves to be risky as it can harm the integrity of the bottle, and the reason for that is this.
<G-vec00211-002-s055><keep.aufbewahren><de> Milch war schwer aufzubewahren und oft verunreinigt.
<G-vec00211-002-s055><keep.aufbewahren><en> Milk was difficult to keep and sometimes not pure.
<G-vec00211-002-s056><keep.aufbewahren><de> Es liegt in der alleinigen Verantwortung des Spielers alle Benutzernamen und Passwörter, die mit dem Casino verbunden sind, sicher und geschützt aufzubewahren.
<G-vec00211-002-s056><keep.aufbewahren><en> It is the sole responsibility of the player to keep all user names and passwords related to their casino account safe and secure.
<G-vec00260-002-s072><insure.aufbewahren><de> Beim Transport und Aufstellen des TV-Geräts muss das Netzkabel ordnungsgemäß in dem entsprechenden Fach am Gehäuse aufbewahrt werden.
<G-vec00260-002-s072><insure.aufbewahren><en> When placing or moving the TV set, take care to insure that the power cord is fitted into the allocated slot.
<G-vec00412-002-s019><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Whirlpool Refrigerator WRT351SFYF00 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s019><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Whirlpool Refrigerator WRT351SFYF00 to your computer and keep it in your files.
<G-vec00412-002-s020><keep.aufbewahren><de> Menhart von Hradec, seit 1436 der höchste Burggraf von Karlštejn (Karlstein), wollte die Burg befestigen, um hier die Krönungskleinodien aufbewahren zu können, die hierorts während des Streits von Menhart und Jiří von Poděbrady verlagert wurden.
<G-vec00412-002-s020><keep.aufbewahren><en> Menhart of Hradec, since 1436 the most important ruler of Karlštejn, intended to reinforce the castle and keep the treasure of the crown jewels in it.
<G-vec00412-002-s021><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Epson Printer 525 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s021><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Epson Printer 525 to your computer and keep it in your files.
<G-vec00412-002-s022><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Toshiba MULTIFUNCTIONAL DIGITAL SYSTEMS 245 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s022><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Toshiba MULTIFUNCTIONAL DIGITAL SYSTEMS 245 to your computer and keep it in your files.
<G-vec00412-002-s023><keep.aufbewahren><de> An einem dunklen, kühlen Ort lagern und außerhalb der Reichweite von Kindern aufbewahren.
<G-vec00412-002-s023><keep.aufbewahren><en> Store in a cool dry place and keep out of reach of children.
<G-vec00412-002-s024><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Canon A720IS auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s024><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Canon A720IS to your computer and keep it in your files.
<G-vec00412-002-s025><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Nokia RAE-3N auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s025><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Nokia RAE-3N to your computer and keep it in your files.
<G-vec00412-002-s026><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Ricoh FT6655 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s026><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Ricoh FT6655 to your computer and keep it in your files.
<G-vec00412-002-s027><keep.aufbewahren><de> Sie können den Großteil Ihrer Anwendung dann mit den synchronen Methoden aufbewahren und nur eine kleines vertikales Stück Asynchronie erstellen.
<G-vec00412-002-s027><keep.aufbewahren><en> You can then keep most of your application using the synchronous methods and just create a small vertical slice of asynchrony.
<G-vec00412-002-s028><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Philips PLASMA HD-KLARGJORT 50PF7321 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s028><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Philips PLASMA HD-KLARGJORT 50PF7321 to your computer and keep it in your files.
<G-vec00412-002-s029><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung KitchenAid Side by Side Built-In Refrigerator KSSS48FMB01 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s029><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual KitchenAid Side by Side Built-In Refrigerator KSSS48FMB01 to your computer and keep it in your files.
<G-vec00412-002-s030><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung IBM THINKPAD Z61E auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s030><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual IBM THINKPAD Z61E to your computer and keep it in your files.
<G-vec00412-002-s031><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Kyocera Royale K10 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s031><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Kyocera Royale K10 to your computer and keep it in your files.
<G-vec00412-002-s032><keep.aufbewahren><de> In diesen kompakten Boxen von Really Useful Products können Sie Gegenstände platzsparend sauber und ordentlich aufbewahren.
<G-vec00412-002-s032><keep.aufbewahren><en> Keep things neat and tidy with this office divider from Really Useful Products, which allows you to store things with only a limited amount of space.
<G-vec00412-002-s033><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Samsung BN68-01899D-00 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s033><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Samsung BN68-01899D-00 to your computer and keep it in your files.
<G-vec00412-002-s034><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Canon Eos Rebel T5i 8595B003 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s034><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Canon Eos Rebel T5i 8595B003 to your computer and keep it in your files.
<G-vec00412-002-s035><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung 3M Series 56ZZ auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s035><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Philips 60 PO 60PL9220D to your computer and keep it in your files.
<G-vec00412-002-s036><keep.aufbewahren><de> Auf Computer herunterladen – Sie können die Anleitung Whirlpool Side by Side Refrigerator 6GD25DCXHW06 auch auf Ihren Computer herunterladen und sie in Ihren Sammlungen aufbewahren.
<G-vec00412-002-s036><keep.aufbewahren><en> Downloading to your computer - You can also download the user manual Whirlpool Side by Side Refrigerator 6GD25DCXHW06 to your computer and keep it in your files.
<G-vec00412-002-s037><keep.aufbewahren><de> Sorgfältig aufbewahren.
<G-vec00412-002-s037><keep.aufbewahren><en> Keep it with care.
