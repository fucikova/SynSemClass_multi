<G-vec00426-002-s029><scream.aufkreischen><de> So werden Klänge wach, die rauschen, strömen, sanft aufkreischen, rufen und dabei immer wieder in flüsternden Klangfarben in sich ruhen.
<G-vec00426-002-s029><scream.aufkreischen><en> They roar, flow, gently scream, call out, and time and again find rest in murmuring sound colours.
