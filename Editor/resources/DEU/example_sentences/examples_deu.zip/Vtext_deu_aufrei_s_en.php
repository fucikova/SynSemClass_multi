<G-vec00389-003-s078><tear_up.aufreißen><de> Den Beutel vorsichtig aufschneiden oder aufreißen.
<G-vec00389-003-s078><tear_up.aufreißen><en> Carefully cut or tear the pouch.
<G-vec00389-003-s079><tear_up.aufreißen><de> Zur schnellen Magnesiumversorgung an der Markierung aufreißen, Granulat auf die Zunge geben, zergehen lassen und schlucken.
<G-vec00389-003-s079><tear_up.aufreißen><en> For fast magnesium supply, tear open at the marking, place granules on the tongue, allow to melt and swallow.
<G-vec00389-003-s080><tear_up.aufreißen><de> Einfacher geht es nicht: Die Verpackung aufreißen, das getränkte Pflegetuch entnehmen.
<G-vec00389-003-s080><tear_up.aufreißen><en> Could not be simpler: The packaging tear, remove the soaked cleaning cloth.
<G-vec00389-003-s081><tear_up.aufreißen><de> Eine Perforierung sollte sich leicht aufreißen lassen, während eine Einstecklasche auch nach mehrmaligem Öffnen und Verschließen der Verpackung nicht einreißen darf.
<G-vec00389-003-s081><tear_up.aufreißen><en> A perforated opening should be easy to tear, whilst a hinged tuck-in flap must not tear after repeated opening and reclosing during the life of the package.
<G-vec00389-003-s082><tear_up.aufreißen><de> Jedes Tüchlein ist einzeln verpackt und kann so beim Aufreißen seine volle Reinigungskraft auf Mineral- und Kunststoffgläsern entfalten.
<G-vec00389-003-s082><tear_up.aufreißen><en> Each tissue is individually packed, so that when you tear it open, the full cleaning power can take effect on glass or plastic lenses.
<G-vec00389-003-s083><tear_up.aufreißen><de> Wie aus einem Meer aus Magma lässt das matte Schwarz der verschiedenen Uhren sattes Rot und leuchtendes Gold aufblitzen, so wie die Ströme der Urgewalt die dunkle Oberfläche immer wieder aufs neue aufreißen lassen und mit einem fließenden Netz aus Feuer und Hitze überziehen.
<G-vec00389-003-s083><tear_up.aufreißen><en> Like a sea of magma, the matt black of the various watches flashes red and gold, just as the streams of primordial force repeatedly tear open the dark surface and cover it with a flowing network of fire and heat.
