<G-vec00169-001-s008><recoup.ausgleichen><de> Dies bedeutet einen Nettoanstieg der Zahl von Arbeitsplätzen in den KMU um 740 000, ein Wert, der den seit 2008 erfolgten Rückgang trotzdem nicht voll ausgleichen kann.
<G-vec00169-001-s008><recoup.ausgleichen><en> This amounts to a net increase of roughly 740,000 jobs in SMEs, which is still not enough to fully recoup losses incurred since 2008.
<G-vec00169-001-s009><recoup.ausgleichen><de> So konnte Nordex die Verluste aus dem ersten Halbjahr 2005 voll ausgleichen.
<G-vec00169-001-s009><recoup.ausgleichen><en> Thus, Nordex was able to fully recoup the losses sustained in the first half of 2005.
