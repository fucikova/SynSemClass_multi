<G-vec00169-001-s008><recoup.ausgleichen><de> Dies bedeutet einen Nettoanstieg der Zahl von Arbeitsplätzen in den KMU um 740 000, ein Wert, der den seit 2008 erfolgten Rückgang trotzdem nicht voll ausgleichen kann.
<G-vec00169-001-s008><recoup.ausgleichen><en> This amounts to a net increase of roughly 740,000 jobs in SMEs, which is still not enough to fully recoup losses incurred since 2008.
<G-vec00169-001-s009><recoup.ausgleichen><de> So konnte Nordex die Verluste aus dem ersten Halbjahr 2005 voll ausgleichen.
<G-vec00169-001-s009><recoup.ausgleichen><en> Thus, Nordex was able to fully recoup the losses sustained in the first half of 2005.
<G-vec00301-002-s081><settle.ausgleichen><de> In der Finanzbuchhaltung können Sie die Rechnungen der Verbände und der Verbandsmitglieder ausgleichen.
<G-vec00301-002-s081><settle.ausgleichen><en> In financial accounting, you can settle the invoices of the associations and association members.
<G-vec00301-002-s082><settle.ausgleichen><de> Sie öffnet anschließend die Seite Buchungen ausgleichen, sodass sie die Rechnung zum Ausgeleichen markieren kann.
<G-vec00301-002-s082><settle.ausgleichen><en> She then opens the Settle transactions page, so that she can mark the invoice for settlement.
<G-vec00301-002-s083><settle.ausgleichen><de> Wenn du Ware nach der Widerrufsfrist an uns zurücksendest, die noch nicht bezahlt worden ist und wir diese aus Kulanz akzeptieren, musst du dennoch die Mahnkosten gegenüber PayPal ausgleichen.
<G-vec00301-002-s083><settle.ausgleichen><en> If you return unpaid goods to us after the withdrawal period, and we accept them out of goodwill, you'll still have to settle the dunning costs towards PayPal.
<G-vec00301-002-s084><settle.ausgleichen><de> Um diese unproduktive Arbeitszeit wieder ausgleichen zu können, müssten wir unsere Preise entsprechend erhöhen.
<G-vec00301-002-s084><settle.ausgleichen><en> In order to settle this unproductive working time, we would have to raise our prices accordingly.
<G-vec00301-002-s085><settle.ausgleichen><de> Sie kann die Seite Buchungen ausgleichen verwenden, um die Datumsangaben und Beträge von Skonti anzuzeigen.
<G-vec00301-002-s085><settle.ausgleichen><en> She can use the Settle transactions page to view the dates and amounts of cash discounts.
<G-vec00356-002-s030><counterbalance.ausgleichen><de> In der Regel hat man sie auch recht wenig im Schnee und nutzt oftmals nur ihr Eigengewicht um Balancen auszugleichen.
<G-vec00356-002-s030><counterbalance.ausgleichen><en> Generally, you don’t touch the snow much with them and often only use their weight to counterbalance.
<G-vec00356-002-s023><neutralize.ausgleichen><de> Verwenden Sie FIX IT COLOUR als Primer zur Perfektionierung der 3 wichtigsten Gesichtspartien – Teint, Lippen & Augenkonturen – um Farbunregelmäßigkeiten gezielt zu korrigieren und auszugleichen.
<G-vec00356-002-s023><neutralize.ausgleichen><en> DE Use FIX IT COLOUR as a skin-perfecting primer on the 3 key areas of the face – complexion, lips & eye contours – to target, correct and neutralize colour imperfections.
<G-vec00356-002-s024><neutralize.ausgleichen><de> Diese Verpackungen sind in der Lage, elektrostatische Ladung auszugleichen – bei gleichbleibend hoher mechanischer Schutzleistung.
<G-vec00356-002-s024><neutralize.ausgleichen><en> This packaging is able to neutralize an electrical charge – while also maintaining a high and consistent mechanical protection.
<G-vec00356-002-s072><offset.ausgleichen><de> Die entgangenen Umsatzbeiträge aus dem Ausstieg aus der Magnetiktechnologie sowie aus dem Verkauf von Verbindungsklemmen konnten in großen Teilen ausgeglichen werden.
<G-vec00356-002-s072><offset.ausgleichen><en> This growth also largely offset the end of revenues due to the exit from magnetic technology and the sale of the connecting clamp business.
<G-vec00356-002-s073><offset.ausgleichen><de> Dabei konnten die weiterhin rückläufigen Erlöse bei Apfelsaftkonzentraten durch Absatz- und Erlössteigerungen im Fruchtzubereitungsgeschäft mehr als ausgeglichen werden.
<G-vec00356-002-s073><offset.ausgleichen><en> Sales revenues for apple juice concentrates continued to decline, but higher volumes and sales revenues in the fruit preparations business more than offset the drop.
<G-vec00356-002-s074><offset.ausgleichen><de> Das Aroma und der Geschmack der aus Verdejo-Trauben gekelterten Weine weisen Noten von Kräutern und Unterholz auf, mit fruchtigen, dank des kräftigen Alkoholgehalts leicht süßlichen Anklängen, die jedoch von einer hervorragenden Säure ausgeglichen werden.
<G-vec00356-002-s074><offset.ausgleichen><en> The aromas and flavours of the Verdejo wine has nuances of herbal scrubs, with fruity hints slightly sweetened by a powerful alcohol content offset by an excellent acidity.
<G-vec00356-002-s075><offset.ausgleichen><de> Die im vierten Quartal gegenüber dem Vorjahreszeitraum deutlich rückläufigen Ethanolerlöse konnten damit mehr als ausgeglichen werden.
<G-vec00356-002-s075><offset.ausgleichen><en> This was enough to more than offset sharply lower ethanol sales revenues in the fourth quarter compared to the same period in the prior year.
<G-vec00356-002-s076><offset.ausgleichen><de> Diese Ergebnisbelastungen konnten nur zum Teil durch weitere Effizienzverbesserungen ausgeglichen werden.
<G-vec00356-002-s076><offset.ausgleichen><en> These burdens on earnings were only partially offset by further efficiency improvements.
<G-vec00356-002-s077><offset.ausgleichen><de> Bei den Absatzpreisen konnten Rückgänge in Asien/Pazifik durch Steigerungen in allen anderen Regionen nahezu ausgeglichen werden.
<G-vec00356-002-s077><offset.ausgleichen><en> Selling price declines in Asia/Pacific were nearly offset by increases in the other regions.
<G-vec00356-002-s078><offset.ausgleichen><de> Die damit verbundenen Umsatzabgänge konnten durch ein wachsendes Geschäft in fast allen anderen Geschäftsbereichen mehr als ausgeglichen werden.
<G-vec00356-002-s078><offset.ausgleichen><en> Thus, all respective sales disposals associated with these areas were more than offset by the financial improvements in almost every other business segment.
<G-vec00356-002-s079><offset.ausgleichen><de> Die tiefe Rezession im Jahresübergang 2008/09 konnte in 2010 und 2011 nur teilweise ausgeglichen werden.
<G-vec00356-002-s079><offset.ausgleichen><en> The deep recession at the turn of year 2008/09 was only partially offset in 2010 and 2011.
<G-vec00356-002-s080><offset.ausgleichen><de> Damit konnte die durch eine niedrigere Aktienmarktvolatilität verursachte anhaltende Schwäche im Indexderivategeschäft mehr als ausgeglichen werden.
<G-vec00356-002-s080><offset.ausgleichen><en> Against this background, the weak index derivatives business caused by low equity market volatility was more than offset.
<G-vec00356-002-s081><offset.ausgleichen><de> Das Emissions- und Beratungsgeschäft verzeichnete gegenüber dem Vorjahresquartal einen um 3% tieferen Ertrag von CHF 951 Mio., was insbesondere auf die geringeren Erträge aus Anleihenemissionen und aus dem Beratungsgeschäft zurückzuführen ist, die vom guten Ergebnis bei Aktienemissionen nicht ausgeglichen werden konnten.
<G-vec00356-002-s081><offset.ausgleichen><en> Compared to 3Q13, equity sales and trading revenues were stable. Underwriting and advisory revenues of CHF 951 million were 3% lower compared to 4Q12, as robust equity underwriting performance was offset by lower debt underwriting and advisory revenues.
<G-vec00356-002-s082><offset.ausgleichen><de> So sind auch Abweichungen in einer Spanne von 15 bis 21 Schichten pro Woche möglich, die über Arbeitszeitkonten ausgeglichen werden.
<G-vec00356-002-s082><offset.ausgleichen><en> Shifts may vary in a range from 15 to 21 per week, with the differences being offset by working time accounts.
