<G-vec00078-001-s190><admit.einsehen><de> Dann musste selbst der Präsident einsehen, dass der Entwurf des Künstlers für eine Massenprägung nicht geeignet war: Bis zu 11 Prägevorgänge waren notwendig, um das gewünschte Relief zu erhalten.
<G-vec00078-001-s190><admit.einsehen><en> Then, even the president had to admit that the design of the artist was not qualified for mass production: Up to 11 processes of striking were necessary to obtain the relief as requested.
<G-vec00078-001-s191><admit.einsehen><de> Und so ihr dies erkennet, werdet ihr auch die Notwendigkeit eines Eingriffs Meinerseits einsehen müssen, oder ihr glaubet nicht an Mich und den Zusammenhang von Mir mit Meinen Geschöpfen.
<G-vec00078-001-s191><admit.einsehen><en> And once you recognise this you will also have to admit that My intervention will be necessary, or you don't believe in Me and the correlation between Me and My living creations.
<G-vec00078-001-s192><admit.einsehen><de> Wenn man also der supramentalen Aktion keinen dunklen, starren, hartnäckigen Widerstand entgegensetzen will, muss man ein für allemal einsehen, daß wir nichts von all dem anerkennen dürfen.
<G-vec00078-001-s192><admit.einsehen><en> Therefore, if we do not want to oppose the supramental action by an obscure, inert and obstinate resistance, we have to admit once and for all that none of these things should be legitimized.
<G-vec00078-001-s193><admit.einsehen><de> Bald mubte Mila einsehen, dab mit ihrem Mann tiefgreifendere Veränderungen vor sich gingen, als sie anfangs vermutet hatte: Etwas Unbekanntes hatte sich als ihr überlegen erwiesen, irgendein neues Element war in sein Leben getreten, das stärker war als sie, etwas, das die Mauer seines tierhaften Stumpfsinns durchbrochen und sie beide innerlich noch weiter voneinander entfernt hatte.
<G-vec00078-001-s193><admit.einsehen><en> She had to admit that the change was greater than she had supposed, that something or other had been stronger than herself, that some new element had entered his life, toppling those walls of dull indifference and estranging the two of them even more than before.
<G-vec00078-001-s194><admit.einsehen><de> Wir müssen einsehen, dass selbst wenn wir heute die Fähigkeit der Beeinflussung der Ereignisse der Welt außerhalb unseres eigenen Gebietes besitzen, so beschränkt sich dies auf die uns umgebende Region.
<G-vec00078-001-s194><admit.einsehen><en> We must admit that, even if we do have some influence over events taking place outside our own territory, our influence is confined to the region immediately surrounding us.
<G-vec00078-001-s195><admit.einsehen><de> Doch bald musste ich einsehen, dass meine plastischen und malerischen Kenntnisse nicht ausreichten, meine Vorstellungen an solchen Objekten zu erproben, und erkannte, dass es mir vor allem an zeichnerischem Können gebrach, das für beide Kunstgattungen die Grundlage abgibt.
<G-vec00078-001-s195><admit.einsehen><en> But I soon had to admit that my plastic and pictorial knowledge was not good enough to test my ideas on these objects and that I lacked the drawing skills needed as basis for both arts.
<G-vec00078-001-s196><admit.einsehen><de> Diejenigen, die die Globalisierung immer auf ein rein wirtschaftliches Phänomen beschränkt haben, müssen heute einsehen, dass sie viel zu eindimensional an die Frage herangegangen sind.
<G-vec00078-001-s196><admit.einsehen><en> People who have always viewed globalization as a purely economic phenomenon are now having to admit that they have addressed the issue in a far too one-dimensional manner.
<G-vec00078-001-s197><admit.einsehen><de> Wir kämpfen gegen unser eigenes Dukkha und wollen nicht einsehen, daß die Windmühlen in unserem Herzen selbst-gemacht sind.
<G-vec00078-001-s197><admit.einsehen><en> We are fighting against our own dukkha and don't want to admit that the windmills in our heart are self-generated.
<G-vec00169-001-s181><realize.einsehen><de> Dem liegt die Einsicht zu-grunde, dass kein Beruf allein heute die Probleme psychisch Kranker einsehen, verstehen und behandeln kann, sondern dass es der angemessenen Zusammenschau und Zusammenarbeit der Berufe bedarf.
<G-vec00169-001-s181><realize.einsehen><en> This is based on the insight that there is no profession today which can realize, understand and treat the problems of psychologically sick persons, but that it is necessary that the occupational groups look at the problems together and cooperate in a reasonable way.
<G-vec00169-001-s182><realize.einsehen><de> Sie müssen jedoch einsehen, dass Sie Vergleichsdaten und keine absoluten Daten erhalten.
<G-vec00169-001-s182><realize.einsehen><en> But you must realize that the data you get is comparative data, not absolute data.
<G-vec00169-001-s183><realize.einsehen><de> Aber du wirst es nun auch selbst einsehen, dass nicht wir es sind, die das vermögen, sondern nur der Herr in uns und durch uns.
<G-vec00169-001-s183><realize.einsehen><en> But now you will also realize yourself that we are not the ones who can do that, but only the Lord in and through us.
<G-vec00169-001-s184><realize.einsehen><de> Die Welt steht unter göttlicher Führung; aber der Mensch soll nicht gezwungen werden, das zuzugeben, sondern er soll in freier Überlegung es einsehen und begreifen.
<G-vec00169-001-s184><realize.einsehen><en> The world is under divine direction, but man is not to be forced to admit this; he is to realize and to understand it by free reflection.
<G-vec00169-001-s185><realize.einsehen><de> Treten aber hier keine Reaktionen auf, da müsst ihr selbst einsehen, dass unsereiner in den Leib nicht hineinschauen kann, um den Sitz der Krankheit nebst ihrer Beschaffenheit ausfindig zu machen.
<G-vec00169-001-s185><realize.einsehen><en> But if no reactions occur here, then you must realize for yourself that someone cannot look into our bodies to find out the location of the disease and its condition.
<G-vec00169-001-s186><realize.einsehen><de> "– Jetzt aber ums der gute Dreyfus wohl einsehen, daß es wichtigere Fragen in der Welt gibt als seine ""nutzlosen und ermüdenden Prozesse""."
<G-vec00169-001-s186><realize.einsehen><en> """There will come a time"" but right now the good Dreyfus must realize that there are more important problems in the world than these ""useless and boring trials""."
<G-vec00169-001-s187><realize.einsehen><de> Nun wirst du es schon einsehen, dass beim Menschen hier auf dieser Erde, wo er sein innerstes Lebensprinzip selbst, ohne irgendeine fremde, gewaltsame Beihilfe, rein nach seinen Erkenntnissen und ganz nach seinem freiesten Willen, zu konsolidieren hat, sich nicht mit den dicksten Prügeln dreinschlagen lässt.
<G-vec00169-001-s187><realize.einsehen><en> You will realize now that with a person here on this earth where he has to consolidate his innermost life principle, without any foreign, forcible assistance, purely according to his knowledge and completely according to his most free will, one cannot lay about one with the heaviest beating.
<G-vec00169-001-s188><realize.einsehen><de> Die Hanochiter haben von uns eine so eindringliche Lektion nun erhalten, dass sie sicher zu der Einsicht gelangen werden, dass ihnen ihre Ringmauer wenig nützt, und sie werden es auch bald einsehen, dass es besser ist, mit uns als offene Freunde und Brüder zu leben, als sich von uns feindselig abzusperren.
<G-vec00169-001-s188><realize.einsehen><en> The Hanochites have now received such a powerful lesson from us that they will come to the conclusion that the ring wall will be of little benefit to them and they will also soon realize that it is better to live in open friendship and as brothers with us than to isolate themselves from us in hostility.
<G-vec00169-001-s189><realize.einsehen><de> Man muss einsehen, dass diese jungen Tulkus Kinder sind.
<G-vec00169-001-s189><realize.einsehen><en> One has to realize that these young tulkus are children.
<G-vec00169-001-s190><realize.einsehen><de> Die Menschheit wird, wenn erst die Kinderkrankheiten der neueren Naturwissenschaft ganz abgestreift sind, schon einsehen, was das bedeutet, daß der Ausgangspunkt der neueren Naturwissenschaft, konsequent verfolgt, wirklich in die Geisteswissenschaft hineinführt, daß es einen ganz konsequenten Weg gibt von Haeckel in die Geisteswissenschaft hinein.
<G-vec00169-001-s190><realize.einsehen><en> Once the teething problems of natural science have been overcome, humanity will realize what it means that the starting point of modern natural science, logically followed, leads directly to spiritual science, that there is a logical path from Haeckel to spiritual science.
<G-vec00169-001-s191><realize.einsehen><de> Nimmt man jetzt auch die Impulse, die von der modernen Kunst ausgingen (von Wagner bis Nietzsche) hinzu, so laesst sich einsehen, dass auch diese ursprünglich von der künstlerischen Moderne ausgegangenen Impulse politisiert werden mussten, wie es beispielsweise mit Richard Wagners Opernkunst auf exemplarische Weise der Fall gewesen ist.
<G-vec00169-001-s191><realize.einsehen><en> If now we take besides also the impetus, that come from the modern art (from Wagner to Nietzsche), we can realize that these impetus also coming initially from the artistic Modern Age must be politicized, like it has been the case in an exemplary way with Richard Wagner's art of the opera.
<G-vec00169-001-s192><realize.einsehen><de> Wir müssen einsehen, dass der Staat einen Ruhestand von 30 Jahren nicht finanzieren kann.
<G-vec00169-001-s192><realize.einsehen><en> We have to realize that the state can't finance 30 years of retirement.
<G-vec00169-001-s193><realize.einsehen><de> Es wickelt sich alles nach Meinem ewigen Ratschluß ab, und so ihr nun das eine bedenket, daß bis ins kleinste jegliches Geschehen in eurem Erdenleben vorbestimmt ist, daß auch euer irdisches Ende vorgesehen ist seit Ewigkeit, müsset ihr es einsehen, daß ihr nichts daran ändern könnet und daß daher auch jede Sorge unnötig ist, weil doch alles kommet, wie es kommen muss nach Meinem Willen.
<G-vec00169-001-s193><realize.einsehen><en> Everything unwinds according to my eternal decision, and so you now consider the one thing, that all events in your earth life are predetermined to the smallest detail, that for eternity also your earthly end is provided for, you must realize that you can change nothing of it and that for that reason also all worry is unnecessary, because still everything comes as it must come according to my will.
<G-vec00169-001-s194><realize.einsehen><de> Außerdem wäre es zu begrüßen, wenn Ärzte und Krankenkassen endlich einsehen würden, dass es, wenn die Schulmedizin nicht mehr weiterhelfen kann, alternative Medizin gibt, und mit und nicht gegen Heilpraktiker arbeiten.
<G-vec00169-001-s194><realize.einsehen><en> Besides, it would be welcomed if doctors and health insurances finally realize if the conventional medicine cannot help anymore that there is alternative medicine and would work with instead against practitioners.
<G-vec00169-001-s195><realize.einsehen><de> [GEJ 10.184.9] Wenn aber du eins wirst mit Meinem Geiste in deiner Seele, so wirst du auch in einem Augenblick mehr einsehen und begreifen, als du jetzt selbst auf dem Wege des mühsamsten Forschens in tausend Jahren begreifen und einsehen würdest.
<G-vec00169-001-s195><realize.einsehen><en> [GGJ 10.184.9] But when you will become one with My Spirit in your soul, in one moment you will realize and understand more than you would do now yourself in a 1,000 years by means of difficult research.
<G-vec00169-001-s196><realize.einsehen><de> Bei gutem Willen wird sie bald eine Besserung spüren, denn sowie sie Reue empfindet, nützet sie auch jede Gelegenheit, liebend sich zu betätigen den notleidenden Seelen gegenüber, denn eine Seele, die verhärtet ist, wendet sich mehr nach unten und empfindet auch niemals Reue über ihre eigene Schuld, weil eine solche Seele durch Beeinflussung böser Kräfte niemals ihr Unrecht einsehen kann und sonach auch keine Reue empfindet.
<G-vec00169-001-s196><realize.einsehen><en> With good will it will soon feel an improvement, because as soon as it feels remorse it also uses every opportunity to be lovingly active towards the needy souls, because a soul which is hardened, turns more down and also never feels remorse about its own guilt, because such a soul can never realize its wrong through influencing of evil powers and therefore also feels no remorse.
<G-vec00169-001-s197><realize.einsehen><de> [HG 2.86.14] Habt ihr mit eurem Liebelichte da alles gefunden, so werdet ihr wohl einsehen, wie viel die ganze Erde wert ist gegen den geringsten inneren Schatz des Lebens aus Mir.
<G-vec00169-001-s197><realize.einsehen><en> "[HG 2.86.14] ""Once you have found it all with the light of your love, you will certainly realize how much the whole earth is worth compared with the least inner treasure of life out of Me."
<G-vec00169-001-s198><realize.einsehen><de> [GEJ 10.186.6] Aber dann werdet ihr es auch einsehen, daß man mit derlei Erklärungen in dieser noch stockfinsteren Zeit nicht auftreten kann, namentlich unter den Juden, die bis jetzt – besonders von dem Sinne des ersten Buches Mosis – noch keinen Dunst von einem Verständnisse haben und die Decke Mosis noch immer ihre innere Sehe verhüllt.
<G-vec00169-001-s198><realize.einsehen><en> [GGJ 10.186.6] Then you will also realize that one cannot give these kind of explanations in this still totally dark time, especially among the Jews who do not have even a bit of understanding up to now, especially of the meaning of the first book of Moses. And the covering of Moses' face still covers their inner sight.
<G-vec00169-001-s199><realize.einsehen><de> [HG 2.262.18] Daher liebe Ihn auch du über alles, und du wirst alsbald das einsehen; denn der Vater will eher geliebt als erkannt sein.
<G-vec00169-001-s199><realize.einsehen><en> "[HG 2.262.18] ""So you, too, love Him above all and you will soon realize it; for the Father wants to be loved rather than recognized."
<G-vec00078-001-s069><concede.einsehen><de> Gehen wir nicht mit menschlicher Überlegung an die Sache heran, sonst müssen wir bald einsehen, dass wir nicht weiterkommen.
<G-vec00078-001-s069><concede.einsehen><en> Let us not approach the matter with reason – otherwise we will soon have to concede that we were unable to make any progress.
<G-vec00310-002-s323><view.einsehen><de> Zuvor kann der Kunde die Bestellung über das Warenkorb-Symbol jederzeit einsehen und ändern.
<G-vec00310-002-s323><view.einsehen><en> The customer can view and amend the order at any time prior to this by clicking on the shopping basket symbol.
<G-vec00310-002-s324><view.einsehen><de> Zusätzlich können Sie die Anhänge eines Gesprächs sowie den Platzbedarf einsehen.
<G-vec00310-002-s324><view.einsehen><en> Additionally, you can view the attachments of a conversation along with the space consumption.
<G-vec00310-002-s325><view.einsehen><de> Klicke unten zum Beispiel auf Gelderland, Noord-Brabant und Noord-Holland um eine Übersicht von Städten in der Region einsehen zu können.
<G-vec00310-002-s325><view.einsehen><en> Click below to continue to for example 1606 view a listing of cities in the region.
<G-vec00310-002-s326><view.einsehen><de> Er darf auch Rechnungen einsehen.
<G-vec00310-002-s326><view.einsehen><en> He may also view the invoices.
<G-vec00310-002-s327><view.einsehen><de> Deine autorisierten mobilen Apps kannst du jederzeit in den App-Einstellungen einsehen und ändern.
<G-vec00310-002-s327><view.einsehen><en> You can always view and manage your authorized mobile apps on the apps settings page.
<G-vec00310-002-s328><view.einsehen><de> Die Bewertungskalkulation können Sie nach dem Bewertungslauf einsehen.
<G-vec00310-002-s328><view.einsehen><en> You can view the valuation costing after the valuation run.
<G-vec00310-002-s329><view.einsehen><de> Es sollten lediglich die Zugangsrechte geregelt werden: wer darf einsehen, wer darf die Daten zur Weiterverwendung nutzen, wer darf sie im Lauf der Zeit ändern.
<G-vec00310-002-s329><view.einsehen><en> It is simply a question of regulating data access rights: who can view the data, who can recover data elements for their own use, and who can make amendments during the data’s life cycle?
<G-vec00310-002-s330><view.einsehen><de> Wählen Sie in dem Menü auf der linken Seite unter "Hosting-Pakete" den Domainnamen aus, für den Sie die Statistiken einsehen möchten.
<G-vec00310-002-s330><view.einsehen><en> Once logged on, select the "hosting" platform that you want to view the statistics for in the left-hand menu.
<G-vec00310-002-s331><view.einsehen><de> Zudem können Sie je Datensatz weitere Informationen einsehen, die für die Kontrolle hilfreich sein können.
<G-vec00310-002-s331><view.einsehen><en> In addition, you can view further information about every record, which might be useful for the check.
<G-vec00310-002-s332><view.einsehen><de> Vor Abschicken der Bestellung kann der Kunde die Daten jederzeit ändern und einsehen sowie mithilfe der Browserfunktion „zurück“ zum Warenkorb zurückgehen oder den Bestellvorgang insgesamt abbrechen.
<G-vec00310-002-s332><view.einsehen><en> Before submitting the order, the customer can always change and view the data, as wall as using the bbrowser function “back” to return to the shopping cart or cancel the entire order process.
<G-vec00310-002-s333><view.einsehen><de> Die Jobs werden in einer Warteschlange, der Queue, organisiert, die jeder KeyShot-Anwender einsehen kann.
<G-vec00310-002-s333><view.einsehen><en> The jobs are organized into a queue that all users can view.
<G-vec00310-002-s334><view.einsehen><de> Tracking-Informationen zur Verfügung stellen, welche die Mitglieder nach dem Versand der Proben einsehen können.
<G-vec00310-002-s334><view.einsehen><en> Provide tracking information that members can view after you ship samples.
<G-vec00310-002-s335><view.einsehen><de> Du kannst eine Landing-Page erstellen, deinen Gästen E-Mails senden und Datenberichte einsehen.
<G-vec00310-002-s335><view.einsehen><en> You can create a landing page, email your guests, and view data reports.
<G-vec00310-002-s336><view.einsehen><de> Die AGB kann der Kunde jederzeit auch hier einsehen und herunterladen.
<G-vec00310-002-s336><view.einsehen><en> The customer can view and download the general terms and conditions here at any time.
<G-vec00310-002-s337><view.einsehen><de> Ab dem Standard-Plan können Workspace-Inhaber Analytik- und Nutzungsdaten einsehen, um festzustellen, wie ihre Mitglieder Slack nutzen.
<G-vec00310-002-s337><view.einsehen><en> On the Standard subscription and above, workspace owners can view analytics and usage for insight into how your members use Slack.
<G-vec00310-002-s338><view.einsehen><de> >> Verwaltung persönlicher Daten: Kundendaten einsehen und ändern.
<G-vec00310-002-s338><view.einsehen><en> >> Personal information management: view and modify customer information.
<G-vec00310-002-s339><view.einsehen><de> Die Benutzer können ihre Social Media-Benachrichtigungen auch mit dieser Uhr einsehen, ohne jedes Mal auf das Telefon schauen zu müssen.
<G-vec00310-002-s339><view.einsehen><en> The users can also view their social media alerts using this watch without having to look at the phone every time.
<G-vec00310-002-s340><view.einsehen><de> Sie können diese Kosten im Kontomenü unter ‚Verlauf‘ einsehen.
<G-vec00310-002-s340><view.einsehen><en> You can view these costs in the Account menu under ‘History’.
<G-vec00310-002-s341><view.einsehen><de> Hier werden Sie die neuesten Entwicklungen bezüglich Ihrer Investments einsehen können.
<G-vec00310-002-s341><view.einsehen><en> Here you will be able to view the latest developments regarding your investments.
<G-vec00341-002-s168><realize.einsehen><de> Verkennen kann man das in diesem Abschnitt Dargestellte, wenn man sich festbeißt in den scheinbaren Einwand: das Wollen des Menschen als solches ist eben das Unvernünftige: man müsse ihm diese Unvernünftigkeit nachweisen, dann wird er einsehen, daß in der endlichen Befreiung von dem Wollen das Ziel des ethischen Strebens liegen müsse.
<G-vec00341-002-s168><realize.einsehen><en> [1] What is presented in this chapter can be misunderstood if one clings to the apparent objection that the will is simply the irrational factor in man and that this must be proved to him because then he will realize that his ethical striving must consist in working toward ultimate emancipation from the will.
<G-vec00341-002-s169><realize.einsehen><de> Man sollte meinen, dass ein Land wie die USA mit einem Leistungsbilanzdefizit von etwa $800 Milliarden Dollar pro Jahr einsehen würde, dass eine derart gähnende Kluft in der Zahlungsbilanz unweigerlich durch das Abstoßen von Vermögenswerten finanziert wird, was bedeutet, dass liquide Ausländer in den USA angesiedelte Unternehmen in ihren Besitz und unter ihre Kontrolle bringen.
<G-vec00341-002-s169><realize.einsehen><en> One would think that a country like the US, with a current account deficit of roughly $800 billion a year, would realize that such a yawning external gap is inevitably financed only by selling off assets, which means that foreigners with money acquire ownership and control of US-based businesses.
<G-vec00341-002-s170><realize.einsehen><de> Das deutsche Volk muss einsehen, daß es Hitler und seine Günstlinge waren, die unschuldige Männer, Frauen und Kinder quälten und ausrotteten und die versuchten, mit den deutschen Waffen die Welt zu beherrschen und zu erniedrigen.
<G-vec00341-002-s170><realize.einsehen><en> The German people must realize that it was Hitler and his minions who tortured and exterminated innocent men, women, and children and sought with German arms to dominate and degrade the world.
<G-vec00341-002-s171><realize.einsehen><de> Durch die Balkanmusik werden die Menschen schließlich einsehen, wie cool Manches von dieser doch sehr fremden Musik ist.
<G-vec00341-002-s171><realize.einsehen><en> Through Balkan music people will eventually realize how cool some of this very foreign stuff is.
<G-vec00341-002-s172><realize.einsehen><de> Und leider musste ich auch einsehen, dass wir ihnen in Sachen Giftigkeit und Bösartigkeit in keiner Weise nachstanden.
<G-vec00341-002-s172><realize.einsehen><en> And unfortunately, I also had to realize that we were in no way inferior in terms of toxicity and malignancy.
<G-vec00341-002-s173><realize.einsehen><de> Ich musste einsehen: Auf diesem Wege würde der Fehler nicht behoben werden.
<G-vec00341-002-s173><realize.einsehen><en> I had to realize: In this way, the issue had no chance of going to be solved.
<G-vec00341-002-s174><realize.einsehen><de> Auch wenn das bedeutet, dass man als Halter einsehen muss, dass man eigentlich gar nicht die Möglichkeiten hat, diese Tiere richtig zu halten.
<G-vec00341-002-s174><realize.einsehen><en> Even if this means, that the animal owner has to realize, that he may not really have the capability to keep this animal species appropriately.
<G-vec00341-002-s176><realize.einsehen><de> Dačić teilte mit, Deutschland sollte einsehen, dass man volle Stabilität erst mit den EU-Beitritt aller Länder der Region erreichen könne.
<G-vec00341-002-s176><realize.einsehen><en> Dacic said that Germany also needs to realize that stability can be achieved only with the EU accession of all regional countries.
<G-vec00341-002-s177><realize.einsehen><de> [HG 2.86.14] Habt ihr mit eurem Liebelichte da alles gefunden, so werdet ihr wohl einsehen, wie viel die ganze Erde wert ist gegen den geringsten inneren Schatz des Lebens aus Mir.
<G-vec00341-002-s177><realize.einsehen><en> [HG 2.86.14] "Once you have found it all with the light of your love, you will certainly realize how much the whole earth is worth compared with the least inner treasure of life out of Me.
<G-vec00341-002-s178><realize.einsehen><de> Ich muss einfach einsehen, daß ich nicht jedem interessanten link folgen kann, daß ich nicht jeden Kurs buchen kann.
<G-vec00341-002-s178><realize.einsehen><en> I just have to realize that I cannot follow every interesting link, cannot participate in every workshop.
<G-vec00341-002-s179><realize.einsehen><de> In den achtziger Jahren war es aber überall so, dass ein Forscher, wenn er sich in die den Erwartungen entsprechende Tiefe seines Gegenstandes versinken wollte, bald einsehen musste, er kann mit immer weniger Kollegen sinnvoll über sein Thema sprechen und diese Kollegen wohnen in der Regel nicht alle in seinem Land.
<G-vec00341-002-s179><realize.einsehen><en> In the eighties, it was however everywhere so that a researcher, if he wanted to sink in the profoundness of his object meeting the expectations, he had soon to realize, that he could talk meaningfully with fewer colleagues about his topic and these colleagues are in the rule not all living in his country.
<G-vec00341-002-s180><realize.einsehen><de> Wir hoffen, dass andere Tierärzte, die noch immer den Job eines “bezahlten Henkers” ausüben, endlich einsehen, wie disqualifizierend und entehrend diese Beschäftigung ist.
<G-vec00341-002-s180><realize.einsehen><en> We hope that other veterinaries who are still practicing the job of “paid executioners” will eventually realize how disqualifying and dishonorable this activity is.
<G-vec00341-002-s181><realize.einsehen><de> Ich hatte die Baracke schon für CHF 2000.- gekauft, als ich einsehen musste, dass ich diese nur auf Bauland stellen kann.
<G-vec00341-002-s181><realize.einsehen><en> I had bought the shack already for CHF 2000 when I had to realize that I can set it only on building land.
<G-vec00211-003-s133><see_to.einsehen><de> Du kannst außerdem im Backend die Meldungen des System-Logs einsehen.
<G-vec00211-003-s133><see_to.einsehen><en> You can also see the messages of the system log in backend.
<G-vec00211-003-s134><see_to.einsehen><de> Bitte den Buchungskalender einsehen .
<G-vec00211-003-s134><see_to.einsehen><en> Please see the booking calendar.
<G-vec00211-003-s135><see_to.einsehen><de> - Ihr könnt nun die Bestzeiten von allen Skipisten und Bobbahnen beim „Ranking Master“ im Info Centre einsehen.
<G-vec00211-003-s135><see_to.einsehen><en> - Now you can see your best times on every Ski and Bobsleigh track. You just have to talk with the “Ranking Master” in the information centre.
<G-vec00211-003-s136><see_to.einsehen><de> Jeder ITscope-Nutzer, der die Person in seinem Netzwerk hat, kann dies einsehen.
<G-vec00211-003-s136><see_to.einsehen><en> Any ITscope user who has added the person in their network will be able to see it.
<G-vec00211-003-s137><see_to.einsehen><de> Wir belassen GD435 jedoch in der Detailanzeige des Abfrageprofils Stammdaten um insbesondere für ältere, inaktive Wertpapiere den damaligen (letztmaligen) Informationsinhalt einsehen zu können.
<G-vec00211-003-s137><see_to.einsehen><en> We keep GD435 in the detail view of the query profile master data especially for older, inactive securities to be able to see their information content.
<G-vec00211-003-s138><see_to.einsehen><de> Visibility beschreibt die Möglichkeit, detaillierte Informationen verschiedener Abläufe innerhalb einer Supply Chain einsehen zu können.
<G-vec00211-003-s138><see_to.einsehen><en> Visibility describes the fact of being able to see detailed information on the different processes within a supply chain.
<G-vec00211-003-s139><see_to.einsehen><de> Dann wird jeder einzelne einsehen, welchen Weg das Produkt nimmt, zu dem er seine Arbeit beisteuert, das Produkt des handwerklichen Arbeiters und desjenigen, der diese handarbeitliche Arbeit durch seine besonderen individuellen Fähigkeiten zu leiten hat.
<G-vec00211-003-s139><see_to.einsehen><en> Each individual will then see the direction taken by the product to which they have contributed their work, where the product of their particular individual capabilities of manual work leads to.
<G-vec00211-003-s140><see_to.einsehen><de> Wenn Ihnen Ihre Kunden bei Stornierungen von Bestellungen oder bei Kündigungen von wiederkehrenden Zahlungen ein Feedback hinterlassen, können Sie es hier einsehen.
<G-vec00211-003-s140><see_to.einsehen><en> If your customers leave feedback when they cancel orders or stop recurring payments, you can see it here.
<G-vec00211-003-s141><see_to.einsehen><de> Aber wenn du dich wieder beruhigt hast und dann darüber nachdenkst, wirst du einsehen, daß dich keine meiner Handlungen dazu verpflichten wird, die Mathematik aufzugeben.
<G-vec00211-003-s141><see_to.einsehen><en> But if you think about it when you're calmer, you'll see that nothing I have done is going to oblige you to abandon mathematics. Nothing!
<G-vec00211-003-s142><see_to.einsehen><de> Andere können Ihre E-Mail-Adresse oder Ihren Namen nicht einsehen.
<G-vec00211-003-s142><see_to.einsehen><en> As a default, other subscribers do not see your email address or your name.
<G-vec00211-003-s143><see_to.einsehen><de> Bei der Bestellung in unserem Onlineshop wird automatisch ein Nutzerkonto angelegt, indem sie insbesondere ihre Bestellungen einsehen können.
<G-vec00211-003-s143><see_to.einsehen><en> When placing orders via our online shop, a user account is automatically set up, which in particular allows you to see your orders.
<G-vec00211-003-s144><see_to.einsehen><de> Die AGB können Sie jederzeit auch hier einsehen.
<G-vec00211-003-s144><see_to.einsehen><en> You can also see the general terms and conditions at any time here.
<G-vec00211-003-s145><see_to.einsehen><de> Jeder kann den Kontostand und alle Transaktionen einer Adresse einsehen.
<G-vec00211-003-s145><see_to.einsehen><en> Anyone can see the balance and all transactions of any address.
<G-vec00211-003-s146><see_to.einsehen><de> Über das Menü Datei -> Offline-Modus -> Datenbank-Übersicht können Sie einsehen, wie der aktuelle Status Ihrer Offline-Datenbank ist.
<G-vec00211-003-s146><see_to.einsehen><en> Via the menu "file" -> "offline mode" -> "database overview" you can see what the current status of your offline database is.
<G-vec00211-003-s147><see_to.einsehen><de> Auf dem neuen Internetauftritt von cleanroomshop.com ist es auch möglich, ein praktisches Benutzerkonto anzulegen, in dem Kunden ihre Kontaktdaten speichern, vorherige Bestellungen einsehen und ihre Lieblingsprodukte ohne großen Aufwand erneut bestellen können.
<G-vec00211-003-s147><see_to.einsehen><en> On the new Internet appearance of cleanroomshop.com it is also possible to put on a practical user account in which customers store their contact contacts, previous orders to see and their favourite products without large expenditure again to order can.
<G-vec00211-003-s148><see_to.einsehen><de> Benutzer mit dem Zugriffsrecht 1 können die Feedbacks nur einsehen und weiterleiten.
<G-vec00211-003-s148><see_to.einsehen><en> Level 1 users can only see and forward feedback in the Feedback section.
<G-vec00211-003-s149><see_to.einsehen><de> Kontobewegungen auf Ihrem Print-Konto können Sie über das TU-Portal mit der Anwendung „print@campus“ einsehen.
<G-vec00211-003-s149><see_to.einsehen><en> You can see your account movements at TU Portal using the "print@campus" application.
<G-vec00211-003-s150><see_to.einsehen><de> Eine Übersicht dieser Anpassungen können Sie hier (PDF, 12 kB) noch einsehen.
<G-vec00211-003-s150><see_to.einsehen><en> You can still see an overview of these adjustments here (PDF, 9,7 kB).
<G-vec00211-003-s151><see_to.einsehen><de> Ansicht der Bestätigungsdetails: Ihr könnt nun die verwendete Bestätigungsmethode für Inhaber einsehen.
<G-vec00211-003-s151><see_to.einsehen><en> Verification details view: You can now see the methods used to verify an owner for your site.
