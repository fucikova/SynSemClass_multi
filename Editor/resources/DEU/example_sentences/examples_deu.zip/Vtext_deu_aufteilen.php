<G-vec00296-002-s057><divide.aufteilen><de> Dies bedeutet einfach, dass Wasser sich in diese beiden Komponenten aufteilt (disoziiert).
<G-vec00296-002-s057><divide.aufteilen><en> This simply means that water will divide (dissociate)into these two components.
<G-vec00296-002-s058><divide.aufteilen><de> Für größere Runden macht es besonders Spaß, wenn ihr euch in die einzelnen Häuser aufteilt und jedes Haus bei gewissen Szenen trinken muss.
<G-vec00296-002-s058><divide.aufteilen><en> For larger rounds it is particularly fun, if you divide into the individual houses and each house must drink in certain scenes.
<G-vec00296-002-s059><divide.aufteilen><de> Benutzergruppen sind Gruppen von Mitgliedern, die die Mitglieder des Boards in für die Board-Administration verwaltbare Einheiten aufteilt.
<G-vec00296-002-s059><divide.aufteilen><en> User groups are groups of users that divide the community into manageable sections administrators can work with.
<G-vec00296-002-s060><divide.aufteilen><de> Seine Jagdtechnik besteht im Aufspüren von Fischschwärmen, wobei eine Schule sich in Gruppen aufteilt.
<G-vec00296-002-s060><divide.aufteilen><en> When hunt- ing, the pod will divide into several small groups.
<G-vec00296-002-s061><divide.aufteilen><de> Upgraden von Laptops für Mehrfach-Display Damit ein zusätzlicher Monitor unterstützt wird, ohne eine Grafikkarte hinzuzufügen, können Sie Matrox Grafik-Erweiterungsmodule (GXMs) verwenden – kleine, externe Kästen, die an den Monitoranschluss Ihres Computers angeschlossen werden und das Signal für zwei oder drei separate Monitore aufteilt.
<G-vec00296-002-s061><divide.aufteilen><en> To add support for an extra monitor without adding or replacing a graphics card, you can use Matrox Graphics eXpansion Modules (GXMs)—small, external boxes that connect to the monitor connector of your computer and divide the signal for two or three separate monitors.
<G-vec00296-002-s006><segregate.aufteilen><de> VLANs (Virtual Local Area Networks) können auch genutzt werden, um Netzwerke aufzuteilen, und die Priorisierung der Daten kann die Lieferung von kritischen Paketen auf Zeit garantieren.
<G-vec00296-002-s006><segregate.aufteilen><en> VLANs (Virtual Local Area Networks) can also be used to segregate networks, and prioritisation of data can guarantee delivery of critical packets on time. Read more
<G-vec00296-002-s125><split.aufteilen><de> So können Sie das Tool verwenden, um das Video aufzuteilen, zu schneiden oder zu bearbeiten und Intro, Titel, Filter, Übergänge und andere Spezialeffekte zu Ihrem Video hinzuzufügen, wie Sie möchten.
<G-vec00296-002-s125><split.aufteilen><en> So that you can use the tool to split, cut or edit the video, and add intro, title, filters, transitions and other special effects to your video as you like.
<G-vec00296-002-s126><split.aufteilen><de> Es ist nicht möglich, die erste Probestunde in 2 oder mehr Unterrichtsstunden aufzuteilen.
<G-vec00296-002-s126><split.aufteilen><en> It is not possible to split the first trial lesson into 2 or more sessions.
<G-vec00296-002-s127><split.aufteilen><de> Um zusätzliche erneuerbare Energieerzeuger in das Stromnetz zu integrieren wird oftmals vorgeschlagen, das Netz in kleine autonome Zellen aufzuteilen, sogenannte „Microgrids“.
<G-vec00296-002-s127><split.aufteilen><en> For the integration of additional renewable generation into the power grid, it is often proposed to split the grid into smaller autonomous cells, also called “microgrids”.
<G-vec00296-002-s128><split.aufteilen><de> Diese Version fügt die Möglichkeit hinzu, einen Artikel aufzuteilen auch wenn der ursprüngliche Artikel keine laufenden Nummer hat.
<G-vec00296-002-s128><split.aufteilen><en> This release adds the ability to split a part even if the original item did not have a sequence number.
<G-vec00296-002-s129><split.aufteilen><de> Es ist möglich, das Land aufzuteilen.
<G-vec00296-002-s129><split.aufteilen><en> It is possible to split the parcel.
<G-vec00296-002-s130><split.aufteilen><de> Ihr bewirtschaftet weiterhin einen von zwei voll funktionstüchtigen kleineren Höfen, was die Möglichkeit schafft sich im Multiplayer aufzuteilen.
<G-vec00296-002-s130><split.aufteilen><en> You manage one of two fully functional smaller courtyards, which creates the possibility to split up in multiplayer.
<G-vec00296-002-s131><split.aufteilen><de> Bei der Abrechnung von einem Deal haben Sie auch die Möglichkeit, die Zahlungen aufzuteilen und eine Anzahlungsrechnung zu erstellen.
<G-vec00296-002-s131><split.aufteilen><en> When creating an invoice out of a deal, you also have the option to split up payments and create an advance invoice.
<G-vec00296-002-s132><split.aufteilen><de> Es gibt auch exklusive Details über das, woran die Design-, Produktions- und Regie-Teams arbeiteten, wie und warum sie beschlossen, Harry Potter und die Heiligtümer des Todes in zwei Filme aufzuteilen und bestimmte Szenen wie die Hochzeit von Bill Weasley und Fleur Delacour, der 1998er Einbruch in die Gringotts Zaubererbank, das Zaubereiministerium und der Raum der Wünsche.
<G-vec00296-002-s132><split.aufteilen><en> There is also exclusive details about what the design, production and directing teams worked on how and why they decided to split Harry Potter and the Deathly Hallows into two films and specific scenes such as the Wedding of Bill Weasley and Fleur Delacour, the 1998 Break-in of Gringotts Wizarding Bank, the Ministry of Magic, and the Room of Requirement.
<G-vec00296-002-s133><split.aufteilen><de> Wenn Sie nur ein Produkt bestellen, ist es nicht möglich, es aufzuteilen und an verschiedene Adressen zu liefern.
<G-vec00296-002-s133><split.aufteilen><en> If you order one product, it is not possible to have it split up and delivered it to different addresses.
<G-vec00296-002-s134><split.aufteilen><de> Es ist auch möglich, den Raum in Zonen aufzuteilen.
<G-vec00296-002-s134><split.aufteilen><en> It is also possible to split the room into zones.
<G-vec00296-002-s135><split.aufteilen><de> Viele der kleineren Strandanlagen liegen in der Nähe größerer Resorts, sodass es möglich ist, Gruppen auf mehrere Hotels aufzuteilen.
<G-vec00296-002-s135><split.aufteilen><en> Many of the smaller beachfront properties sit near bigger resorts, making it possible to split groups across several hotels.
<G-vec00296-002-s136><split.aufteilen><de> Einige, ziemlich große Villen sind auch eine ideale Lösung, um den Urlaub und die Kosten zwischen zwei oder mehreren befreundeten Familien aufzuteilen.
<G-vec00296-002-s136><split.aufteilen><en> Some villas are quite large, so an ideal solution for two or more families of friends to go on holiday together and split costs.
<G-vec00296-002-s137><split.aufteilen><de> Der Nutzer ist dazu fähig TIFF in verschiedene Bildformate, wie png, jpg, gif, bmp, sowie tiff, aufzuteilen.
<G-vec00296-002-s137><split.aufteilen><en> Users can split TIFF documents into different image formats, such as jpeg, png, tiff, gif, and bmp.
<G-vec00296-002-s138><split.aufteilen><de> Ziehen Sie den Schieberegler auf den Startpunkt und den Endpunkt des unerwünschten Teils des Videos und drücken Sie das Scherensymbol, um das Video zuerst aufzuteilen.
<G-vec00296-002-s138><split.aufteilen><en> Drag the slider to the start point and the end point of the unwanted part of the video, and press the scissor icon to split the video first.
<G-vec00296-002-s139><split.aufteilen><de> Dieses vierstöckige Haus wurde 2011 gebaut und mit der Fähigkeit ausgestattet, sich in zwei Doppelhaushälften aufzuteilen.
<G-vec00296-002-s139><split.aufteilen><en> This four-story house was built in 2011 and designed with the ability to split into two semi-detached houses.
<G-vec00296-002-s140><split.aufteilen><de> Die Abluftsammelleitungen am Rottetunnel ermöglichen es, die Abluftströme der biologischen Behandlung je nach Belastungsgrad aufzuteilen und separat zu behandeln.
<G-vec00296-002-s140><split.aufteilen><en> The exhaust air pipes on the rotting box allow to split the exhaust flows of the biological treatment depending on the degree of exposure and to treat them separately.
<G-vec00296-002-s141><split.aufteilen><de> Nach Auswahl der Aufteilungsmethode klicken Sie auf die Schaltfläche "OK", um das ausgewählte Dokument aufzuteilen.
<G-vec00296-002-s141><split.aufteilen><en> After selecting the splitting method, click on the "OK" button to split your selected document.
<G-vec00296-002-s142><split.aufteilen><de> Zum Einen könnte er sich dazu entscheiden seine Hand aufzuteilen und eine zweite Wette abzuschließen.
<G-vec00296-002-s142><split.aufteilen><en> The player chooses to split his hand of eights by making a second bet.
<G-vec00296-002-s143><split.aufteilen><de> FASTANDLIGHT.CH behält sich das Recht vor, eine Bestellung für mehrere Pakete aufzuteilen oder Bestellungen desselben Kunden zu gruppieren, um an dieselbe Adresse zu liefern.
<G-vec00296-002-s143><split.aufteilen><en> FASTANDLIGHT.CH reserves the right to split an order in to several packages, or to regroup orders made by the same customer in order to deliver to the same address.
<G-vec00296-003-s125><split_up.aufteilen><de> So können Sie das Tool verwenden, um das Video aufzuteilen, zu schneiden oder zu bearbeiten und Intro, Titel, Filter, Übergänge und andere Spezialeffekte zu Ihrem Video hinzuzufügen, wie Sie möchten.
<G-vec00296-003-s125><split_up.aufteilen><en> So that you can use the tool to split, cut or edit the video, and add intro, title, filters, transitions and other special effects to your video as you like.
<G-vec00296-003-s126><split_up.aufteilen><de> Es ist nicht möglich, die erste Probestunde in 2 oder mehr Unterrichtsstunden aufzuteilen.
<G-vec00296-003-s126><split_up.aufteilen><en> It is not possible to split the first trial lesson into 2 or more sessions.
<G-vec00296-003-s127><split_up.aufteilen><de> Um zusätzliche erneuerbare Energieerzeuger in das Stromnetz zu integrieren wird oftmals vorgeschlagen, das Netz in kleine autonome Zellen aufzuteilen, sogenannte „Microgrids“.
<G-vec00296-003-s127><split_up.aufteilen><en> For the integration of additional renewable generation into the power grid, it is often proposed to split the grid into smaller autonomous cells, also called “microgrids”.
<G-vec00296-003-s128><split_up.aufteilen><de> Diese Version fügt die Möglichkeit hinzu, einen Artikel aufzuteilen auch wenn der ursprüngliche Artikel keine laufenden Nummer hat.
<G-vec00296-003-s128><split_up.aufteilen><en> This release adds the ability to split a part even if the original item did not have a sequence number.
<G-vec00296-003-s129><split_up.aufteilen><de> Es ist möglich, das Land aufzuteilen.
<G-vec00296-003-s129><split_up.aufteilen><en> It is possible to split the parcel.
<G-vec00296-003-s130><split_up.aufteilen><de> Ihr bewirtschaftet weiterhin einen von zwei voll funktionstüchtigen kleineren Höfen, was die Möglichkeit schafft sich im Multiplayer aufzuteilen.
<G-vec00296-003-s130><split_up.aufteilen><en> You manage one of two fully functional smaller courtyards, which creates the possibility to split up in multiplayer.
<G-vec00296-003-s131><split_up.aufteilen><de> Bei der Abrechnung von einem Deal haben Sie auch die Möglichkeit, die Zahlungen aufzuteilen und eine Anzahlungsrechnung zu erstellen.
<G-vec00296-003-s131><split_up.aufteilen><en> When creating an invoice out of a deal, you also have the option to split up payments and create an advance invoice.
<G-vec00296-003-s132><split_up.aufteilen><de> Es gibt auch exklusive Details über das, woran die Design-, Produktions- und Regie-Teams arbeiteten, wie und warum sie beschlossen, Harry Potter und die Heiligtümer des Todes in zwei Filme aufzuteilen und bestimmte Szenen wie die Hochzeit von Bill Weasley und Fleur Delacour, der 1998er Einbruch in die Gringotts Zaubererbank, das Zaubereiministerium und der Raum der Wünsche.
<G-vec00296-003-s132><split_up.aufteilen><en> There is also exclusive details about what the design, production and directing teams worked on how and why they decided to split Harry Potter and the Deathly Hallows into two films and specific scenes such as the Wedding of Bill Weasley and Fleur Delacour, the 1998 Break-in of Gringotts Wizarding Bank, the Ministry of Magic, and the Room of Requirement.
<G-vec00296-003-s133><split_up.aufteilen><de> Wenn Sie nur ein Produkt bestellen, ist es nicht möglich, es aufzuteilen und an verschiedene Adressen zu liefern.
<G-vec00296-003-s133><split_up.aufteilen><en> If you order one product, it is not possible to have it split up and delivered it to different addresses.
<G-vec00296-003-s134><split_up.aufteilen><de> Es ist auch möglich, den Raum in Zonen aufzuteilen.
<G-vec00296-003-s134><split_up.aufteilen><en> It is also possible to split the room into zones.
<G-vec00296-003-s135><split_up.aufteilen><de> Viele der kleineren Strandanlagen liegen in der Nähe größerer Resorts, sodass es möglich ist, Gruppen auf mehrere Hotels aufzuteilen.
<G-vec00296-003-s135><split_up.aufteilen><en> Many of the smaller beachfront properties sit near bigger resorts, making it possible to split groups across several hotels.
<G-vec00296-003-s136><split_up.aufteilen><de> Einige, ziemlich große Villen sind auch eine ideale Lösung, um den Urlaub und die Kosten zwischen zwei oder mehreren befreundeten Familien aufzuteilen.
<G-vec00296-003-s136><split_up.aufteilen><en> Some villas are quite large, so an ideal solution for two or more families of friends to go on holiday together and split costs.
<G-vec00296-003-s137><split_up.aufteilen><de> Der Nutzer ist dazu fähig TIFF in verschiedene Bildformate, wie png, jpg, gif, bmp, sowie tiff, aufzuteilen.
<G-vec00296-003-s137><split_up.aufteilen><en> Users can split TIFF documents into different image formats, such as jpeg, png, tiff, gif, and bmp.
<G-vec00296-003-s138><split_up.aufteilen><de> Ziehen Sie den Schieberegler auf den Startpunkt und den Endpunkt des unerwünschten Teils des Videos und drücken Sie das Scherensymbol, um das Video zuerst aufzuteilen.
<G-vec00296-003-s138><split_up.aufteilen><en> Drag the slider to the start point and the end point of the unwanted part of the video, and press the scissor icon to split the video first.
<G-vec00296-003-s139><split_up.aufteilen><de> Dieses vierstöckige Haus wurde 2011 gebaut und mit der Fähigkeit ausgestattet, sich in zwei Doppelhaushälften aufzuteilen.
<G-vec00296-003-s139><split_up.aufteilen><en> This four-story house was built in 2011 and designed with the ability to split into two semi-detached houses.
<G-vec00296-003-s140><split_up.aufteilen><de> Die Abluftsammelleitungen am Rottetunnel ermöglichen es, die Abluftströme der biologischen Behandlung je nach Belastungsgrad aufzuteilen und separat zu behandeln.
<G-vec00296-003-s140><split_up.aufteilen><en> The exhaust air pipes on the rotting box allow to split the exhaust flows of the biological treatment depending on the degree of exposure and to treat them separately.
<G-vec00296-003-s141><split_up.aufteilen><de> Nach Auswahl der Aufteilungsmethode klicken Sie auf die Schaltfläche "OK", um das ausgewählte Dokument aufzuteilen.
<G-vec00296-003-s141><split_up.aufteilen><en> After selecting the splitting method, click on the "OK" button to split your selected document.
<G-vec00296-003-s142><split_up.aufteilen><de> Zum Einen könnte er sich dazu entscheiden seine Hand aufzuteilen und eine zweite Wette abzuschließen.
<G-vec00296-003-s142><split_up.aufteilen><en> The player chooses to split his hand of eights by making a second bet.
<G-vec00296-003-s143><split_up.aufteilen><de> FASTANDLIGHT.CH behält sich das Recht vor, eine Bestellung für mehrere Pakete aufzuteilen oder Bestellungen desselben Kunden zu gruppieren, um an dieselbe Adresse zu liefern.
<G-vec00296-003-s143><split_up.aufteilen><en> FASTANDLIGHT.CH reserves the right to split an order in to several packages, or to regroup orders made by the same customer in order to deliver to the same address.
<G-vec00488-002-s014><categorize.aufteilen><de> Für die Einen bedeutet es, dass sie jeden Abend ihre Tätigkeiten auf fünf Minuten genau auf verschiedene Kategorien aufteilen müssen.
<G-vec00488-002-s014><categorize.aufteilen><en> For some, it means that they categorize precisely their daily activities into different categories, for every 5 minutes period.
<G-vec00488-002-s247><designate.aufteilen><de> Durch linienartige Markierungen wird der Verkehr in verschiedene Spuren und Fahrtrichtungen aufgeteilt.
<G-vec00488-002-s247><designate.aufteilen><en> Lines marked on the road surface designate different lanes and directions.
