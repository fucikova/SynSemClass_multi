<G-vec00296-002-s057><divide.aufteilen><de> Dies bedeutet einfach, dass Wasser sich in diese beiden Komponenten aufteilt (disoziiert).
<G-vec00296-002-s057><divide.aufteilen><en> This simply means that water will divide (dissociate)into these two components.
<G-vec00296-002-s058><divide.aufteilen><de> Für größere Runden macht es besonders Spaß, wenn ihr euch in die einzelnen Häuser aufteilt und jedes Haus bei gewissen Szenen trinken muss.
<G-vec00296-002-s058><divide.aufteilen><en> For larger rounds it is particularly fun, if you divide into the individual houses and each house must drink in certain scenes.
<G-vec00296-002-s059><divide.aufteilen><de> Benutzergruppen sind Gruppen von Mitgliedern, die die Mitglieder des Boards in für die Board-Administration verwaltbare Einheiten aufteilt.
<G-vec00296-002-s059><divide.aufteilen><en> User groups are groups of users that divide the community into manageable sections administrators can work with.
<G-vec00296-002-s060><divide.aufteilen><de> Seine Jagdtechnik besteht im Aufspüren von Fischschwärmen, wobei eine Schule sich in Gruppen aufteilt.
<G-vec00296-002-s060><divide.aufteilen><en> When hunt- ing, the pod will divide into several small groups.
<G-vec00296-002-s061><divide.aufteilen><de> Upgraden von Laptops für Mehrfach-Display Damit ein zusätzlicher Monitor unterstützt wird, ohne eine Grafikkarte hinzuzufügen, können Sie Matrox Grafik-Erweiterungsmodule (GXMs) verwenden – kleine, externe Kästen, die an den Monitoranschluss Ihres Computers angeschlossen werden und das Signal für zwei oder drei separate Monitore aufteilt.
<G-vec00296-002-s061><divide.aufteilen><en> To add support for an extra monitor without adding or replacing a graphics card, you can use Matrox Graphics eXpansion Modules (GXMs)—small, external boxes that connect to the monitor connector of your computer and divide the signal for two or three separate monitors.
<G-vec00296-002-s006><segregate.aufteilen><de> VLANs (Virtual Local Area Networks) können auch genutzt werden, um Netzwerke aufzuteilen, und die Priorisierung der Daten kann die Lieferung von kritischen Paketen auf Zeit garantieren.
<G-vec00296-002-s006><segregate.aufteilen><en> VLANs (Virtual Local Area Networks) can also be used to segregate networks, and prioritisation of data can guarantee delivery of critical packets on time. Read more
<G-vec00296-002-s125><split.aufteilen><de> So können Sie das Tool verwenden, um das Video aufzuteilen, zu schneiden oder zu bearbeiten und Intro, Titel, Filter, Übergänge und andere Spezialeffekte zu Ihrem Video hinzuzufügen, wie Sie möchten.
<G-vec00296-002-s125><split.aufteilen><en> So that you can use the tool to split, cut or edit the video, and add intro, title, filters, transitions and other special effects to your video as you like.
<G-vec00296-002-s126><split.aufteilen><de> Es ist nicht möglich, die erste Probestunde in 2 oder mehr Unterrichtsstunden aufzuteilen.
<G-vec00296-002-s126><split.aufteilen><en> It is not possible to split the first trial lesson into 2 or more sessions.
<G-vec00296-002-s127><split.aufteilen><de> Um zusätzliche erneuerbare Energieerzeuger in das Stromnetz zu integrieren wird oftmals vorgeschlagen, das Netz in kleine autonome Zellen aufzuteilen, sogenannte „Microgrids“.
<G-vec00296-002-s127><split.aufteilen><en> For the integration of additional renewable generation into the power grid, it is often proposed to split the grid into smaller autonomous cells, also called “microgrids”.
<G-vec00296-002-s128><split.aufteilen><de> Diese Version fügt die Möglichkeit hinzu, einen Artikel aufzuteilen auch wenn der ursprüngliche Artikel keine laufenden Nummer hat.
<G-vec00296-002-s128><split.aufteilen><en> This release adds the ability to split a part even if the original item did not have a sequence number.
<G-vec00296-002-s129><split.aufteilen><de> Es ist möglich, das Land aufzuteilen.
<G-vec00296-002-s129><split.aufteilen><en> It is possible to split the parcel.
<G-vec00296-002-s130><split.aufteilen><de> Ihr bewirtschaftet weiterhin einen von zwei voll funktionstüchtigen kleineren Höfen, was die Möglichkeit schafft sich im Multiplayer aufzuteilen.
<G-vec00296-002-s130><split.aufteilen><en> You manage one of two fully functional smaller courtyards, which creates the possibility to split up in multiplayer.
<G-vec00296-002-s131><split.aufteilen><de> Bei der Abrechnung von einem Deal haben Sie auch die Möglichkeit, die Zahlungen aufzuteilen und eine Anzahlungsrechnung zu erstellen.
<G-vec00296-002-s131><split.aufteilen><en> When creating an invoice out of a deal, you also have the option to split up payments and create an advance invoice.
<G-vec00296-002-s132><split.aufteilen><de> Es gibt auch exklusive Details über das, woran die Design-, Produktions- und Regie-Teams arbeiteten, wie und warum sie beschlossen, Harry Potter und die Heiligtümer des Todes in zwei Filme aufzuteilen und bestimmte Szenen wie die Hochzeit von Bill Weasley und Fleur Delacour, der 1998er Einbruch in die Gringotts Zaubererbank, das Zaubereiministerium und der Raum der Wünsche.
<G-vec00296-002-s132><split.aufteilen><en> There is also exclusive details about what the design, production and directing teams worked on how and why they decided to split Harry Potter and the Deathly Hallows into two films and specific scenes such as the Wedding of Bill Weasley and Fleur Delacour, the 1998 Break-in of Gringotts Wizarding Bank, the Ministry of Magic, and the Room of Requirement.
<G-vec00296-002-s133><split.aufteilen><de> Wenn Sie nur ein Produkt bestellen, ist es nicht möglich, es aufzuteilen und an verschiedene Adressen zu liefern.
<G-vec00296-002-s133><split.aufteilen><en> If you order one product, it is not possible to have it split up and delivered it to different addresses.
<G-vec00296-002-s134><split.aufteilen><de> Es ist auch möglich, den Raum in Zonen aufzuteilen.
<G-vec00296-002-s134><split.aufteilen><en> It is also possible to split the room into zones.
<G-vec00296-002-s135><split.aufteilen><de> Viele der kleineren Strandanlagen liegen in der Nähe größerer Resorts, sodass es möglich ist, Gruppen auf mehrere Hotels aufzuteilen.
<G-vec00296-002-s135><split.aufteilen><en> Many of the smaller beachfront properties sit near bigger resorts, making it possible to split groups across several hotels.
<G-vec00296-002-s136><split.aufteilen><de> Einige, ziemlich große Villen sind auch eine ideale Lösung, um den Urlaub und die Kosten zwischen zwei oder mehreren befreundeten Familien aufzuteilen.
<G-vec00296-002-s136><split.aufteilen><en> Some villas are quite large, so an ideal solution for two or more families of friends to go on holiday together and split costs.
<G-vec00296-002-s137><split.aufteilen><de> Der Nutzer ist dazu fähig TIFF in verschiedene Bildformate, wie png, jpg, gif, bmp, sowie tiff, aufzuteilen.
<G-vec00296-002-s137><split.aufteilen><en> Users can split TIFF documents into different image formats, such as jpeg, png, tiff, gif, and bmp.
<G-vec00296-002-s138><split.aufteilen><de> Ziehen Sie den Schieberegler auf den Startpunkt und den Endpunkt des unerwünschten Teils des Videos und drücken Sie das Scherensymbol, um das Video zuerst aufzuteilen.
<G-vec00296-002-s138><split.aufteilen><en> Drag the slider to the start point and the end point of the unwanted part of the video, and press the scissor icon to split the video first.
<G-vec00296-002-s139><split.aufteilen><de> Dieses vierstöckige Haus wurde 2011 gebaut und mit der Fähigkeit ausgestattet, sich in zwei Doppelhaushälften aufzuteilen.
<G-vec00296-002-s139><split.aufteilen><en> This four-story house was built in 2011 and designed with the ability to split into two semi-detached houses.
<G-vec00296-002-s140><split.aufteilen><de> Die Abluftsammelleitungen am Rottetunnel ermöglichen es, die Abluftströme der biologischen Behandlung je nach Belastungsgrad aufzuteilen und separat zu behandeln.
<G-vec00296-002-s140><split.aufteilen><en> The exhaust air pipes on the rotting box allow to split the exhaust flows of the biological treatment depending on the degree of exposure and to treat them separately.
<G-vec00296-002-s141><split.aufteilen><de> Nach Auswahl der Aufteilungsmethode klicken Sie auf die Schaltfläche "OK", um das ausgewählte Dokument aufzuteilen.
<G-vec00296-002-s141><split.aufteilen><en> After selecting the splitting method, click on the "OK" button to split your selected document.
<G-vec00296-002-s142><split.aufteilen><de> Zum Einen könnte er sich dazu entscheiden seine Hand aufzuteilen und eine zweite Wette abzuschließen.
<G-vec00296-002-s142><split.aufteilen><en> The player chooses to split his hand of eights by making a second bet.
<G-vec00296-002-s143><split.aufteilen><de> FASTANDLIGHT.CH behält sich das Recht vor, eine Bestellung für mehrere Pakete aufzuteilen oder Bestellungen desselben Kunden zu gruppieren, um an dieselbe Adresse zu liefern.
<G-vec00296-002-s143><split.aufteilen><en> FASTANDLIGHT.CH reserves the right to split an order in to several packages, or to regroup orders made by the same customer in order to deliver to the same address.
<G-vec00296-003-s125><split_up.aufteilen><de> So können Sie das Tool verwenden, um das Video aufzuteilen, zu schneiden oder zu bearbeiten und Intro, Titel, Filter, Übergänge und andere Spezialeffekte zu Ihrem Video hinzuzufügen, wie Sie möchten.
<G-vec00296-003-s125><split_up.aufteilen><en> So that you can use the tool to split, cut or edit the video, and add intro, title, filters, transitions and other special effects to your video as you like.
<G-vec00296-003-s126><split_up.aufteilen><de> Es ist nicht möglich, die erste Probestunde in 2 oder mehr Unterrichtsstunden aufzuteilen.
<G-vec00296-003-s126><split_up.aufteilen><en> It is not possible to split the first trial lesson into 2 or more sessions.
<G-vec00296-003-s127><split_up.aufteilen><de> Um zusätzliche erneuerbare Energieerzeuger in das Stromnetz zu integrieren wird oftmals vorgeschlagen, das Netz in kleine autonome Zellen aufzuteilen, sogenannte „Microgrids“.
<G-vec00296-003-s127><split_up.aufteilen><en> For the integration of additional renewable generation into the power grid, it is often proposed to split the grid into smaller autonomous cells, also called “microgrids”.
<G-vec00296-003-s128><split_up.aufteilen><de> Diese Version fügt die Möglichkeit hinzu, einen Artikel aufzuteilen auch wenn der ursprüngliche Artikel keine laufenden Nummer hat.
<G-vec00296-003-s128><split_up.aufteilen><en> This release adds the ability to split a part even if the original item did not have a sequence number.
<G-vec00296-003-s129><split_up.aufteilen><de> Es ist möglich, das Land aufzuteilen.
<G-vec00296-003-s129><split_up.aufteilen><en> It is possible to split the parcel.
<G-vec00296-003-s130><split_up.aufteilen><de> Ihr bewirtschaftet weiterhin einen von zwei voll funktionstüchtigen kleineren Höfen, was die Möglichkeit schafft sich im Multiplayer aufzuteilen.
<G-vec00296-003-s130><split_up.aufteilen><en> You manage one of two fully functional smaller courtyards, which creates the possibility to split up in multiplayer.
<G-vec00296-003-s131><split_up.aufteilen><de> Bei der Abrechnung von einem Deal haben Sie auch die Möglichkeit, die Zahlungen aufzuteilen und eine Anzahlungsrechnung zu erstellen.
<G-vec00296-003-s131><split_up.aufteilen><en> When creating an invoice out of a deal, you also have the option to split up payments and create an advance invoice.
<G-vec00296-003-s132><split_up.aufteilen><de> Es gibt auch exklusive Details über das, woran die Design-, Produktions- und Regie-Teams arbeiteten, wie und warum sie beschlossen, Harry Potter und die Heiligtümer des Todes in zwei Filme aufzuteilen und bestimmte Szenen wie die Hochzeit von Bill Weasley und Fleur Delacour, der 1998er Einbruch in die Gringotts Zaubererbank, das Zaubereiministerium und der Raum der Wünsche.
<G-vec00296-003-s132><split_up.aufteilen><en> There is also exclusive details about what the design, production and directing teams worked on how and why they decided to split Harry Potter and the Deathly Hallows into two films and specific scenes such as the Wedding of Bill Weasley and Fleur Delacour, the 1998 Break-in of Gringotts Wizarding Bank, the Ministry of Magic, and the Room of Requirement.
<G-vec00296-003-s133><split_up.aufteilen><de> Wenn Sie nur ein Produkt bestellen, ist es nicht möglich, es aufzuteilen und an verschiedene Adressen zu liefern.
<G-vec00296-003-s133><split_up.aufteilen><en> If you order one product, it is not possible to have it split up and delivered it to different addresses.
<G-vec00296-003-s134><split_up.aufteilen><de> Es ist auch möglich, den Raum in Zonen aufzuteilen.
<G-vec00296-003-s134><split_up.aufteilen><en> It is also possible to split the room into zones.
<G-vec00296-003-s135><split_up.aufteilen><de> Viele der kleineren Strandanlagen liegen in der Nähe größerer Resorts, sodass es möglich ist, Gruppen auf mehrere Hotels aufzuteilen.
<G-vec00296-003-s135><split_up.aufteilen><en> Many of the smaller beachfront properties sit near bigger resorts, making it possible to split groups across several hotels.
<G-vec00296-003-s136><split_up.aufteilen><de> Einige, ziemlich große Villen sind auch eine ideale Lösung, um den Urlaub und die Kosten zwischen zwei oder mehreren befreundeten Familien aufzuteilen.
<G-vec00296-003-s136><split_up.aufteilen><en> Some villas are quite large, so an ideal solution for two or more families of friends to go on holiday together and split costs.
<G-vec00296-003-s137><split_up.aufteilen><de> Der Nutzer ist dazu fähig TIFF in verschiedene Bildformate, wie png, jpg, gif, bmp, sowie tiff, aufzuteilen.
<G-vec00296-003-s137><split_up.aufteilen><en> Users can split TIFF documents into different image formats, such as jpeg, png, tiff, gif, and bmp.
<G-vec00296-003-s138><split_up.aufteilen><de> Ziehen Sie den Schieberegler auf den Startpunkt und den Endpunkt des unerwünschten Teils des Videos und drücken Sie das Scherensymbol, um das Video zuerst aufzuteilen.
<G-vec00296-003-s138><split_up.aufteilen><en> Drag the slider to the start point and the end point of the unwanted part of the video, and press the scissor icon to split the video first.
<G-vec00296-003-s139><split_up.aufteilen><de> Dieses vierstöckige Haus wurde 2011 gebaut und mit der Fähigkeit ausgestattet, sich in zwei Doppelhaushälften aufzuteilen.
<G-vec00296-003-s139><split_up.aufteilen><en> This four-story house was built in 2011 and designed with the ability to split into two semi-detached houses.
<G-vec00296-003-s140><split_up.aufteilen><de> Die Abluftsammelleitungen am Rottetunnel ermöglichen es, die Abluftströme der biologischen Behandlung je nach Belastungsgrad aufzuteilen und separat zu behandeln.
<G-vec00296-003-s140><split_up.aufteilen><en> The exhaust air pipes on the rotting box allow to split the exhaust flows of the biological treatment depending on the degree of exposure and to treat them separately.
<G-vec00296-003-s141><split_up.aufteilen><de> Nach Auswahl der Aufteilungsmethode klicken Sie auf die Schaltfläche "OK", um das ausgewählte Dokument aufzuteilen.
<G-vec00296-003-s141><split_up.aufteilen><en> After selecting the splitting method, click on the "OK" button to split your selected document.
<G-vec00296-003-s142><split_up.aufteilen><de> Zum Einen könnte er sich dazu entscheiden seine Hand aufzuteilen und eine zweite Wette abzuschließen.
<G-vec00296-003-s142><split_up.aufteilen><en> The player chooses to split his hand of eights by making a second bet.
<G-vec00296-003-s143><split_up.aufteilen><de> FASTANDLIGHT.CH behält sich das Recht vor, eine Bestellung für mehrere Pakete aufzuteilen oder Bestellungen desselben Kunden zu gruppieren, um an dieselbe Adresse zu liefern.
<G-vec00296-003-s143><split_up.aufteilen><en> FASTANDLIGHT.CH reserves the right to split an order in to several packages, or to regroup orders made by the same customer in order to deliver to the same address.
<G-vec00488-002-s014><categorize.aufteilen><de> Für die Einen bedeutet es, dass sie jeden Abend ihre Tätigkeiten auf fünf Minuten genau auf verschiedene Kategorien aufteilen müssen.
<G-vec00488-002-s014><categorize.aufteilen><en> For some, it means that they categorize precisely their daily activities into different categories, for every 5 minutes period.
<G-vec00488-002-s247><designate.aufteilen><de> Durch linienartige Markierungen wird der Verkehr in verschiedene Spuren und Fahrtrichtungen aufgeteilt.
<G-vec00488-002-s247><designate.aufteilen><en> Lines marked on the road surface designate different lanes and directions.
<G-vec00694-002-s030><divide.aufteilen><de> Brühe aufgeteilt in gleiche Portionen und trinken während des Tages.
<G-vec00694-002-s030><divide.aufteilen><en> Decoction to divide into equal portions and drink during the day.
<G-vec00694-002-s031><divide.aufteilen><de> Jede einzelne Urkunde ist dabei als eine PDF-Datei zu übergeben, d.h. die einzelne Urkunde darf nicht in mehrere Dokumente aufgeteilt werden, und mehrere Urkunden dürfen nicht in eine PDF-Datei zusammengefasst werden.
<G-vec00694-002-s031><divide.aufteilen><en> In so doing, each individual document (deed) is to be submitted as one PDF document, i.e., don't divide one deed into several documents nor merge several deeds into one PDF.
<G-vec00694-002-s032><divide.aufteilen><de> So können in der Büroplanung einzelne Räume entstehen oder auch ganze Bereiche in kleinere Räume aufgeteilt und damit strukturiert werden.
<G-vec00694-002-s032><divide.aufteilen><en> The walls can be used in office planning to create individual rooms or even divide a large area into smaller rooms to provide additional structure.
<G-vec00694-002-s033><divide.aufteilen><de> b. Unter Berücksichtigung dieser Schilderungen formuliert der Relator der Synode eine Reihe von Diskussionspunkten für die zweite Phase, bei der die Synodenmitglieder, aufgeteilt nach Sprachen in kleinen Gruppen zusammenkommen - den so genannten “Circuli minores”.
<G-vec00694-002-s033><divide.aufteilen><en> In light of these presentations, the Relator of the Synod formulates a series of points for discussion during the second phase, when all the Synodal members divide into small groups (circuli minores) according to the various languages spoken.
<G-vec00694-002-s034><divide.aufteilen><de> Eat diese Arten von Lebensmitteln täglich in kleinen Portionen und in kleine Mahlzeiten aufgeteilt.
<G-vec00694-002-s034><divide.aufteilen><en> Eat these types of food daily in small portions and divide into small portions of food.
<G-vec00694-002-s035><divide.aufteilen><de> Im Falle der Beendigung der Gütergemeinschaft sind die Gesamtgutverbindlichkeiten zunächst abzuziehen, bevor ein verbleibender Überschuss unter den Ehegatten hälftig aufgeteilt wird (§ 1476 Abs.
<G-vec00694-002-s035><divide.aufteilen><en> When the community property arrangement comes to an end, the debts incurred in respect of the joint property must be deducted in order to divide the excess remaining into two equal shares for the two spouses (§ 1476 par.
<G-vec00694-002-s036><divide.aufteilen><de> Mittels des Feldes "Typ" können die Unternehmen in potentielle Kunden (Potentials) und reelle Kunden (Clients) aufgeteilt werden.
<G-vec00694-002-s036><divide.aufteilen><en> Using the "Type" field we can divide the companies to potential clients (Potential) and real clients (Clients).
<G-vec00694-002-s037><divide.aufteilen><de> In Allplan Engineering 2016 wurde die Direktmodifikation von Verlegungen verbessert, so dass sie nun einfach aufgeteilt und verändert werden können.
<G-vec00694-002-s037><divide.aufteilen><en> In Allplan Engineering 2016, the direct modification of placements has been improved so they are now easy to divide and change.
<G-vec00694-002-s038><divide.aufteilen><de> Ein Partitionstyp, den Sie zum Aufteilen Ihrer großen Datenbank in kleinere Datenbanken verwenden können, um diese so schneller und einfacher auf Servern verwalten zu können.
<G-vec00694-002-s038><divide.aufteilen><en> A type of partitioning that lets you divide your large database into smaller databases, which can be managed faster more easily across servers.
<G-vec00694-002-s039><divide.aufteilen><de> Schiebeelemente können die Wohnung in 6 Bereiche (Wohnen, Eltern, Kind, Großmutter, Gäste und Service) aufteilen.
<G-vec00694-002-s039><divide.aufteilen><en> Sliding elements can be used to divide the home into 6 areas (living room, master bedroom, kid’s bedroom, grandmother’s bedroom, guestroom, and service room).
<G-vec00694-002-s040><divide.aufteilen><de> Den Teig in 12 gleichgroße Portionen aufteilen und mit etwas Abstand auf das Blech legen.
<G-vec00694-002-s040><divide.aufteilen><en> Divide the cookie dough into 12 equal portions and place with enough space between on the baking sheet.
<G-vec00694-002-s041><divide.aufteilen><de> Technologie verbergen, Strukturen aufteilen oder zusammenfassen, als Schutz, aus Zweckmäßigkeit oder aus dekorativen Aspekten – für den Einsatz von Verkleidungen aus metallischen Werkstoffen sprechen viele Faktoren.
<G-vec00694-002-s041><divide.aufteilen><en> There are many factors involved in the deployment of metallic paneling. To hide technology, divide or combine structures, as protection, or for practical or decorative reasons.
<G-vec00694-002-s042><divide.aufteilen><de> Der Dienst kann Seiten aus dem Quelldokument extrahieren oder ein Quelldokument basierend auf Lesezeichen aufteilen.
<G-vec00694-002-s042><divide.aufteilen><en> The service can extract pages from the source document or divide a source document based on bookmarks.
<G-vec00694-002-s043><divide.aufteilen><de> Sie werden »alle Neune« – analog zum Symphonien-Zyklus im März – unter sich aufteilen.
<G-vec00694-002-s043><divide.aufteilen><en> They will divide all nine symphonies among themselves, much as in the symphony cycle 4 September
<G-vec00694-002-s044><divide.aufteilen><de> Da ihr alle Freunde seit, wollt ihr die Pizza ganz gerecht aufteilen.
<G-vec00694-002-s044><divide.aufteilen><en> Since you are all friends, you want to divide the pizza fairly.
<G-vec00694-002-s045><divide.aufteilen><de> Den aufgegangenen Teig in drei Stücke aufteilen, ausrollen und in eine runde befettete Backform legen.
<G-vec00694-002-s045><divide.aufteilen><en> Divide the risen dough in three parts, roll out and place on an oiled round baking pan.
<G-vec00694-002-s046><divide.aufteilen><de> Da sich in den Transceivern zwei parallele CS-Anschlüsse befinden, lassen sich Breakout-Anwendungen realisieren: Netzwerktechniker können zwei CS-Patchkabel in einen Transceiver stecken und die 200G in 2 x 100G aufteilen.
<G-vec00694-002-s046><divide.aufteilen><en> Since the transceivers have two parallel CS connectors, breakout applications can be realised: Network engineers can plug two CS patch cables into one transceiver and divide the 200G into 2 100G.
<G-vec00694-002-s047><divide.aufteilen><de> Doch mit der Zeit haben sich unsere Stärken herauskristallisiert und so konnten wir uns die Bereiche untereinander aufteilen.
<G-vec00694-002-s047><divide.aufteilen><en> But over time our strengths showed themselves and we could therefore divide the areas among ourselves.
<G-vec00694-002-s048><divide.aufteilen><de> Unterteilen wir nun die verschiedenen Anreize in drei Optionen, nämlich Stoffwechsel, Hypertrophie und Neuro / Power (wir könnten diese immer noch untereinander aufteilen, aber im Moment werde ich das so belassen, dass die Geschichte nicht zu kompliziert wird).
<G-vec00694-002-s048><divide.aufteilen><en> Let us now subdivide the different incentives into 3 options, namely metabolic, hypertrophy and neuro / power (we could still divide these between themselves, but for now I will leave that for what it is to make the story not too complicated).
<G-vec00694-002-s049><divide.aufteilen><de> Mit Hilfe von Fadenvorhängen können Sie den Raum problemlos in Zonen aufteilen, ohne dass Sie sich fest fühlen.
<G-vec00694-002-s049><divide.aufteilen><en> With the help of thread curtains, you can easily divide the room into zones, without the feeling of tightness.
<G-vec00694-002-s050><divide.aufteilen><de> Um Ihren Aufenthalt besser zu organisieren, können Sie die Insel in drei Gebiete aufteilen: der Süden, in dem sich der internationale Flughafen Tenerife Sur befindet, der Norden mit dem Flughafen Tenerife Norte und das Gebiet um die Hauptstadt.
<G-vec00694-002-s050><divide.aufteilen><en> When it comes to organising your getaway, you can divide the island into three large areas: the south, where you will find the Tenerife-South International Airport; the north, which is home to the Tenerife-North International Airport; and the metropolitan area.
<G-vec00694-002-s051><divide.aufteilen><de> Sie können entweder ein Segment für jede Zeitzone erstellen, in der Ihre Empfänger leben, oder Ihre Abonnenten in einfacher verwaltbare Segmente aufteilen.
<G-vec00694-002-s051><divide.aufteilen><en> You could either create a segment for every time zone your recipients live in or divide your subscribers into manageable segments.
<G-vec00694-002-s052><divide.aufteilen><de> Wenn Sie diesen Befehl verwenden möchten, wählen Sie „Objekt“ > „Pfad“ > „Darunter liegende Objekte aufteilen“.
<G-vec00694-002-s052><divide.aufteilen><en> To use this command, choose Object > Path > Divide Objects Below.
<G-vec00694-002-s053><divide.aufteilen><de> Das Tool "Text zu Spalten" in Excel kann schnell das richtige Trennzeichen auswählen und die Daten richtig auf die Spalten aufteilen.
<G-vec00694-002-s053><divide.aufteilen><en> The Text to Columns tool in Excel can quickly select the proper delimiter and divide the data into columns correctly.
<G-vec00694-002-s054><divide.aufteilen><de> Eine Sitzungsmoderator-Browseransicht von Collaborate kann Teilnehmer für kleinere Projekte und Gruppenarbeiten in Gruppen aufteilen.
<G-vec00694-002-s054><divide.aufteilen><en> A session moderator on the web browser view of Collaborate can divide participants into groups for smaller projects and collaboration.
<G-vec00694-002-s055><divide.aufteilen><de> Dazwischenliegen unzählige Regionen, welche diejenigen, die von einem Ende zum anderen gelangt sind, oftmals in drei unterschiedliche Ebenen aufteilen, entsprechend dem besonderen Ausgleich von positiv-spirituellen und negativ-materiellen Kräften.
<G-vec00694-002-s055><divide.aufteilen><en> In between are countless regions which those who have journeyed from one end to the other often divide into three distinct planes in accordance with the balance of positive – spiritual and Negative – material forces in each plane .
<G-vec00694-002-s056><divide.aufteilen><de> Industrie Wir können unsere Produktion in vielen Produktlinien aufteilen.
<G-vec00694-002-s056><divide.aufteilen><en> Industry We can divide our production into several product ranges.
<G-vec00694-002-s070><divide.aufteilen><de> Viele Menschen entscheiden sich dafür, ihre Seagate externen Festplatten in verschiedene Partitionen aufzuteilen und das könnte auch bei Ihnen der Fall sein.
<G-vec00694-002-s070><divide.aufteilen><en> Many people choose to divide their Seagate external hard drives into different partitions and this could apply to your case.
<G-vec00694-002-s071><divide.aufteilen><de> Versuchen Sie, die Übung nur in Ihrem Kopf aufzuteilen und die 100 Wiederholungen nacheinander durchzuführen.
<G-vec00694-002-s071><divide.aufteilen><en> Try to divide the exercise only in your head, and do the 100 repetitions one after the other.
<G-vec00694-002-s072><divide.aufteilen><de> Momentan versucht die Foundation ihre SCPs auf Himmel und Erde gleichmäßig aufzuteilen und weitere Anomalien einzudämmen.
<G-vec00694-002-s072><divide.aufteilen><en> At the moment, the Foundation is trying to divide its SCPs equally upon the sky and the underground and to contain further anomalies.
<G-vec00694-002-s073><divide.aufteilen><de> Sogar ein einfaches Thread kann Theateraufführung werden, wenn man es in der Luft macht, ein scharfes Messer winkend, versucht, das Aufsteigen von Obst und Gemüse aufzuteilen.
<G-vec00694-002-s073><divide.aufteilen><en> Even a simple thread can become theatrical performance, if you do it in the air, waving a sharp knife, trying to divide soaring up fruits and vegetables.
<G-vec00694-002-s074><divide.aufteilen><de> Es ist notwendig, Essen in kleine Portionen aufzuteilen und 5-8 mal am Tag zu essen.
<G-vec00694-002-s074><divide.aufteilen><en> It is necessary to divide food into small portions and eat 5-8 times a day.
<G-vec00694-002-s075><divide.aufteilen><de> Als Zeus beschloss sein Reich aufzuteilen, bekam jeder Gott ein Gebiet.
<G-vec00694-002-s075><divide.aufteilen><en> When Zeus decided to divide his kingdom, each god was given a field.
<G-vec00694-002-s076><divide.aufteilen><de> Bitten Sie die Gruppen, die einzelnen Abschnitte des Kapitels innerhalb der Gruppe aufzuteilen.
<G-vec00694-002-s076><divide.aufteilen><en> Ask each group to divide the sections of the chapter among themselves.
<G-vec00694-002-s077><divide.aufteilen><de> Da sich elf Teams für das Turnier angemeldet hatten, entschied der Veranstalter Berlin Sluggers, die Teams in zwei Gruppen aufzuteilen.
<G-vec00694-002-s077><divide.aufteilen><en> Since eleven teams were registered for the tournament, the organizers had decided to divide the teams into two groups.
<G-vec00694-002-s078><divide.aufteilen><de> Die Idee des Verfahrens selbst ist ein Magenband, die eine besondere Band ausgebildet, um den Magen in zwei Teile aufzuteilen ist: ein oberes Volumen von etwa 25 ml (die Tasche), und einen unteren Teil.
<G-vec00694-002-s078><divide.aufteilen><en> The idea of the procedure itself is an adjustable gastric band, which is a special belt designed to divide the stomach into two parts: an upper volume of about 25ml (the pouch), and a bottom part.
<G-vec00694-002-s079><divide.aufteilen><de> Das Ziel ist, das Rastergitter in L-förmige Bereiche aufzuteilen.
<G-vec00694-002-s079><divide.aufteilen><en> The goal is to divide the grid into L-shaped regions.
<G-vec00694-002-s080><divide.aufteilen><de> Es hat die beste Dateiverwaltung auf dem Markt und hat die Fähigkeit, die Hörbücher in zwei Hauptkategorien aufzuteilen; iPod-Bibliothek-Inhalte und hörbare direkte Downloads.
<G-vec00694-002-s080><divide.aufteilen><en> It has the best file management in the market and has the ability to divide the audio books into two main categories; iPod library content and audible direct downloads.
<G-vec00694-002-s081><divide.aufteilen><de> Sie enthielten auch eine Anzahl von Rechtseinrichtungen, wie das patriarchische System (um die Herrschaft des Geburtsadelssystems zu bewahren, was heißt, der älteste Sohn des Gemahls würde den Thron erben und andere Söhne des Gemahls, Konkubinen und Gebieterinnen würden Titel erhalten), das Feudalsystem (um Land zu benennen und unter den königlichen Familienmitgliedern aufzuteilen) und das Ritualsystem (Zeremonien und Prozeduren, die bei den wichtigen nationalen Angelegenheiten angewendet wurden).
<G-vec00694-002-s081><divide.aufteilen><en> The Zhou rites contained a number of legal institutions such as a patriarchal system (to maintain the rule of the hereditary nobility, including that the eldest son of the consort would inherit the throne and other sons from the consort, concubines, and mistresses would be given titles), a feudal system (to nominate and divide land among the royal family members), and ritual system (ceremonies and procedures used for the important national affairs).
<G-vec00694-002-s082><divide.aufteilen><de> Die Kamera verwendet ein Prisma und eine Kombination aus Bandpass-Filtern, um das einfallende Licht in die beiden Wellenlängenbereiche, 900 – 1400 nm und 1400 – 1700 nm, aufzuteilen und auf zwei separate INGaAs-Zeilensensoren zu lenken.
<G-vec00694-002-s082><divide.aufteilen><en> The camera uses a prism and a combination of bandpass filters to divide the incoming light into the 900 – 1400 nm and 1400 – 1700 nm wavelength bands and direct it to two separate indium gallium arsenide image sensors.
<G-vec00694-002-s083><divide.aufteilen><de> Schön war auch, dass die beiden uns ermöglichten, das Shooting auf zwei verschiedene Locations aufzuteilen.
<G-vec00694-002-s083><divide.aufteilen><en> It was also nice that the two of us made it possible to divide the shoot into two different locations.
<G-vec00694-002-s084><divide.aufteilen><de> Wegen der steigenden Zahl von Einträgen pro Staffel, was oft zu langen Ladezeiten der Website geführt hat, haben wir uns entschieden, jede Saison in episodenbezogene Unterbereiche aufzuteilen.
<G-vec00694-002-s084><divide.aufteilen><en> Due to the increasing number of entries per season, which often took a long time to load the site, we decided to divide each season in episodic sub-sites.
<G-vec00694-002-s085><divide.aufteilen><de> Eine Kombination mit den unmittelbar angrenzenden Tagungsräumen „Vollschiff“ und „Schoner“ erlaubt es, Veranstaltungen auf mehrere Orte aufzuteilen oder parallel laufen zu lassen.
<G-vec00694-002-s085><divide.aufteilen><en> A combination with the directly adjacent conference rooms "Vollschiff" and "Schoner" makes it possible to divide events into several locations or to run them in parallel.
<G-vec00694-002-s086><divide.aufteilen><de> Für das Layout kann es nützlich sein, die Seite in Spalten aufzuteilen, indem der detaillierte Plan, die synthetisierten Informationen und Schlüsselfiguren, Grafiken und Bilder zur Veranschaulichung der Bemerkungen erwähnt werden.
<G-vec00694-002-s086><divide.aufteilen><en> For the layout, it can be useful to divide the page in columns by mentioning the detailed plan, synthesized information and key figures, graphics, images to illustrate the remarks.
<G-vec00694-002-s087><divide.aufteilen><de> Wenn du einen längeren Artikel schreibst, ist es hilfreich, ihn in mehrere Absätze aufzuteilen.
<G-vec00694-002-s087><divide.aufteilen><en> If you're writing a longer article, it's useful to divide it into sections.
<G-vec00694-002-s088><divide.aufteilen><de> Wenn Sie in Ihrem Unternehmen ein großes Netzwerk betreiben, unterstützt die rollenbasierte Zugriffssteuerung Sie dabei, die Sicherheitsverwaltungsaufgaben auf mehrere Administratoren aufzuteilen.
<G-vec00694-002-s088><divide.aufteilen><en> If your business runs a large network, Role-Based Access Control can help you to divide security management responsibilities between multiple administrators.
<G-vec00694-002-s068><split.aufteilen><de> Gemäss KGB-Informationen soll die "USA" aufgeteilt werden und Kalifornien an China gehen...
<G-vec00694-002-s068><split.aufteilen><en> According to KGB informations the "U.S.A." should be split and California should go to China...
<G-vec00694-002-s069><split.aufteilen><de> Im Haus gibt es insgesamt 22 Wohnungen auf drei Stockwerken aufgeteilt (kein Lift).
<G-vec00694-002-s069><split.aufteilen><en> Apartments are split over three floors, but there is no lift in the building.
<G-vec00694-002-s070><split.aufteilen><de> Im Server wird das Bild aufgeteilt für Tausende von Zuschauer überall auf der Welt, die am Geschehen auf dem Horst teilhaben wollen.
<G-vec00694-002-s070><split.aufteilen><en> In the server the image is split for thousands of viewers all over the world who want take part in what happens in the nest.
<G-vec00694-002-s071><split.aufteilen><de> Wir setzen das Projekt zur Video-Analyse / Video-Auswertung online auf und stellen es, aufgeteilt in einzelne Microtasks, geeigneten Clickworkern zur Bearbeitung zur Verfügung.
<G-vec00694-002-s071><split.aufteilen><en> We will put the project online, split up into individual micro tasks, and make it available to suitable clickworkers for processing.
<G-vec00694-002-s072><split.aufteilen><de> Durch das Aufteilen der Footage konnten die Renderzeiten auf kleinere Portionen aufgeteilt werden.
<G-vec00694-002-s072><split.aufteilen><en> Because we divided the footage we could split the rendering times into smaller portions.
<G-vec00694-002-s073><split.aufteilen><de> Nach den AnaCredit-Regeln werden Daten in Vorlage 1 und Vorlage 2 aufgeteilt.
<G-vec00694-002-s073><split.aufteilen><en> The AnaCredit rules split data into Template 1 and Template 2.
<G-vec00694-002-s074><split.aufteilen><de> - Volt – Überladen - Aufnahmefähigkeit: Wandelt 3 % des erhaltenen Schaden in Schilde um, die zwischen Volt und Verbündeten aufgeteilt werden.
<G-vec00694-002-s074><split.aufteilen><en> - Volt: Overload - Capacitance: Converts 3% of damage dealt into shields split between Volt and allied Tenno.
<G-vec00694-002-s075><split.aufteilen><de> Aufgeteilt in verschiedenen Elementen kann das Sideboard nach eigenen Wünschen “beladen” werden.
<G-vec00694-002-s075><split.aufteilen><en> As if a regular sideboard had been split into different elements, different “containers”.
<G-vec00694-002-s076><split.aufteilen><de> Der Kreis Fulda wurde 1821 geschaffen, nachdem das Großherzogtum Fulda 1816 zum Kurfürstentum Hessen gekommen war und in vier Kreise aufgeteilt wurde.
<G-vec00694-002-s076><split.aufteilen><en> History[edit] The district was created in 1821, when the duchy of Fulda became a province of Hesse, and was split into four districts.
<G-vec00694-002-s077><split.aufteilen><de> Wenn die Hände nicht in Betracht kommen, dann ist die hohe Hand nimmt das Geld und im Falle eines Unentschieden, wird das Geld dann aufgeteilt auf der Grundlage der ausgezeichneten High Hand.
<G-vec00694-002-s077><split.aufteilen><en> If hands do not qualify, then the high hand takes the money and in the case of a tie, the money is then split based on the winning high hand.
<G-vec00694-002-s078><split.aufteilen><de> Je weiter nach rechts (Erkennen Sie weniger Szenen) Ziehen Sie den Schieberegler, je höher die Punktzahl und je weniger Szenen in das Video aufgeteilt wird.
<G-vec00694-002-s078><split.aufteilen><en> The farther to the right (Detect Less Scenes) you drag the slider, the higher the score, and the fewer scenes the video will be split into.
<G-vec00694-002-s079><split.aufteilen><de> Es sind immer mehrere Reiseleiter da um sicherzugehen das jeder untergebracht wird (Jede Gruppe wird von den Reiseleitern aufgeteilt mit einer maximalen Größe von 40 Personen pro Reiseleiter).
<G-vec00694-002-s079><split.aufteilen><en> There are always multiple guides to ensure that everyone can be accommodated (each group is split between the guides, with a maximum of 40 people per guide).
<G-vec00694-002-s080><split.aufteilen><de> -Diese 1.300 QTUM werden in einem einzigen UTXO ankommen, das für den Super Staker-Betrieb aufgeteilt werden muss.
<G-vec00694-002-s080><split.aufteilen><en> This 1,300 QTUM will arrive in a single UTXO, which must be split for the Super Staker operation.
<G-vec00694-002-s081><split.aufteilen><de> Die Bibel ist aufgeteilt in 66 kleinere Bücher.
<G-vec00694-002-s081><split.aufteilen><en> The Bible is split into 66 smaller books.
<G-vec00694-002-s082><split.aufteilen><de> E und Offset G Mechanismen aufgeteilt.
<G-vec00694-002-s082><split.aufteilen><en> Split E and Offset G Mechanisms
<G-vec00694-002-s083><split.aufteilen><de> Panamaische Münzen werden in 1, 5, 10, 25, 50 Cent und eine eigene 1-Dollar-Münze aufgeteilt.
<G-vec00694-002-s083><split.aufteilen><en> Panamanian coins are split into 1, 5, 10, 25, 50 cents, as well as its own $1 coin.
<G-vec00694-002-s084><split.aufteilen><de> Mit diesen Filtern kann die Strahlung, die ALMA beobachtet, in 32 mal so viele Wellenlängenbereiche aufgeteilt werden wie zu Beginn vorgesehen.
<G-vec00694-002-s084><split.aufteilen><en> With these filters, the wavelengths of light which ALMA sees can be split up 32 times more finely than in the initial design, into ranges that can be finely tuned.
<G-vec00694-002-s085><split.aufteilen><de> Sie können diese Option auf Automatisch setzen und Windows entscheiden lassen, wie die Abbild-Datei aufgeteilt wird.
<G-vec00694-002-s085><split.aufteilen><en> You may set this option to Automatic and let Windows decide how to split the image file.
<G-vec00694-002-s086><split.aufteilen><de> Noch heute werden nach diesem Prinzip Dateien in kleine Pakete aufgeteilt und einzeln verschickt.
<G-vec00694-002-s086><split.aufteilen><en> Until this day data is being split up in “packets” and sent separately after this principle.
<G-vec00694-002-s087><split.aufteilen><de> Sports Direct kann die Lieferung Ihrer Bestellung, je nach Lagerverfügbarkeit, in mehrere Pakete aufteilen.
<G-vec00694-002-s087><split.aufteilen><en> Sports Direct may split delivery of your order into several parcels based on stock availability.
<G-vec00694-002-s088><split.aufteilen><de> In diesem Fall sollten Sie Ihre Karten aufteilen und hoffen, mindestens eine und vorzugsweise beide Hände zu verbessern.
<G-vec00694-002-s088><split.aufteilen><en> In that case, you would split your cards and hope to improve at least one and preferably both hands.
<G-vec00694-002-s089><split.aufteilen><de> Zusätzlich können Sie im Menü "Seite" PDF-Seiten einfügen, löschen, ersetzen, extrahieren, drehen, aufteilen.
<G-vec00694-002-s089><split.aufteilen><en> Additionally, you can insert, delete, replace, extract, rotate, or split PDF pages in the "Page" menu.
<G-vec00694-002-s090><split.aufteilen><de> Hier ist ein interessantes Produkt von LDT, um den S88 Bus aufteilen zu können.
<G-vec00694-002-s090><split.aufteilen><en> Here is an interesting product from LDT, to split the S88 Bus.
<G-vec00694-002-s091><split.aufteilen><de> Alle Proben der GT Probe, RAB-, RC- und Kernbohrungen wurden mittels Verfahren PRP70-250 (zerkleinern, aufteilen und pulverisieren von 250 Gramm auf 200 Mesh) aufbereitet und analysiert mittels Verfahren FA430 (Brandprobe einer 30-Gramm-Einwaage mit anschließender AAS-Analyse) und AQ200 (lösen von 0,5 Gramm in Königswasser mit anschließender ICP-MS-Analyse).
<G-vec00694-002-s091><split.aufteilen><en> All GT Probe, RAB, RC, and diamond core samples were prepared using procedure PRP70-250 (crush, split and pulverize 250 g to 200 mesh) and analyzed by method FA430 (30g fire assay with AAS finish) and AQ200 (0.5g, aqua regia digestion and ICP-MS analysis).
<G-vec00694-002-s092><split.aufteilen><de> Neben der Reparatur von PST-Dateien kann die Technical Edition auch großformatige PST-Dateien aufteilen und komprimieren, um die Outlook-Performance zu optimieren und die Wahrscheinlichkeit einer Dateibeschädigung zu minimieren.
<G-vec00694-002-s092><split.aufteilen><en> Technician edition of the software can also Split and Compact large-sized PST file to optimize Outlook performance, improve manageability, and reduce chances of corruption.
<G-vec00694-002-s093><split.aufteilen><de> Sie können die Daten auf jede erdenkliche Weise aufteilen und klassifizieren und so beim Entscheidungsprozess von den Dashboards ausgiebigen Gebrauch machen.
<G-vec00694-002-s093><split.aufteilen><en> You can split and classify your data in every way imaginable, enabling you to make full use of the dashboards in your decision-making process.
<G-vec00694-002-s094><split.aufteilen><de> Wenn der Kunde bei der Bestellung mehrere Zahlungsmethoden verwendet hat, können Sie die Erstattung auf die vom Kunden verwendeten Zahlungsmethoden aufteilen.
<G-vec00694-002-s094><split.aufteilen><en> If the customer used more than one payment method, then you can split the refund between the same payment methods that they used.
<G-vec00694-002-s095><split.aufteilen><de> Seiten aus einer PDF-Datei extrahieren, mehrseitige Dokumente in separate PDF-Dateien aufteilen.
<G-vec00694-002-s095><split.aufteilen><en> Extract pages to PDF file, split multipage document to PDF files.
<G-vec00694-002-s096><split.aufteilen><de> Klicken Sie hier zum Anzeigen der Schritte zum Aufteilen einer Region in zwei Regionen Wählen Sie das Werkzeug Leserichtung aus.
<G-vec00694-002-s096><split.aufteilen><en> Split a region into two regions Select the Touch Up Reading Order tool.
<G-vec00694-002-s097><split.aufteilen><de> Verschiedene Dateien in ein PDF zusammenfügen und ein PDF in mehrere Dateien aufteilen.
<G-vec00694-002-s097><split.aufteilen><en> Combine multiple files into PDF and split PDF into several files.
<G-vec00694-002-s098><split.aufteilen><de> Der Mann bestritt, dass die Bettler selbst für ihn arbeiteten - er behauptete, sie seien alle Teil eines bulgarischen Teams und sie würden ihr Einkommen unter sich aufteilen.
<G-vec00694-002-s098><split.aufteilen><en> The man denied that the beggars themselves worked for him -- he claimed they were all part of a Bulgarian team, and split the income between them.
<G-vec00694-002-s099><split.aufteilen><de> Es kann PDF-Dateitexte, Bilder und Seiten konvertieren, erstellen, aufteilen und zusammenführen.
<G-vec00694-002-s099><split.aufteilen><en> It can convert, create, split and merge PDF File texts, images, pages.
<G-vec00694-002-s100><split.aufteilen><de> Solltet ihr euch nicht frewillig aufteilen, werden die Admins von der Funktion zum Verschieben von Spielern Gebrauch machen.
<G-vec00694-002-s100><split.aufteilen><en> In case your players doesn't split up our admins will use the RCON function.
<G-vec00694-002-s101><split.aufteilen><de> Sie können zwei Karten aufteilen, die gleiche Werte wie Q-10 und zwei Achter haben.
<G-vec00694-002-s101><split.aufteilen><en> Splitting You can split two cards that have the same denomination or value.
<G-vec00694-002-s102><split.aufteilen><de> Die Verteidigung muss sich aufteilen um die Position zu halten, da die Angreifer an vier Punkten mit Sprengstoff durch die Haupttore auf die obere Etage eindringen können.
<G-vec00694-002-s102><split.aufteilen><en> The defense team will have to split up to hold the position as the attackers have four points where they can penetrate with explosives such as the main gates and the upper floor.
<G-vec00694-002-s103><split.aufteilen><de> Nachfolgend zeigen wir Ihnen, wie Sie PDF-Dateien online aufteilen können.
<G-vec00694-002-s103><split.aufteilen><en> Below we show how to split PDF pages with double page layout in two, down the middle.
<G-vec00694-002-s104><split.aufteilen><de> Mit dem split Operation-Element lassen sich Dokumente aufteilen.
<G-vec00694-002-s104><split.aufteilen><en> The split operation element can be used to split documents.
<G-vec00694-002-s105><split.aufteilen><de> Schon die U-Bahn selbst wird von zwei verschiedenen Anbietern betrieben, die sich das Netz aufteilen.
<G-vec00694-002-s105><split.aufteilen><en> The tube alone is being run by two different providers that split the net between each other.
