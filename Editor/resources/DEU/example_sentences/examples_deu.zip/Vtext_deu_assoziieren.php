<G-vec00318-002-s044><associate.assoziieren><de> Assoziiere mental ein gutes Gefühl und Gesundheit mit diesen Nahrungsmitteln, die günstig für dich sind.
<G-vec00318-002-s044><associate.assoziieren><en> Mentally associate positive health and feeling good with the foods that are beneficial, and remember the consequences of the foods that are off-limits.
<G-vec00318-002-s045><associate.assoziieren><de> Assoziiere Mich nicht bloß mit dem Donner und Blitz.
<G-vec00318-002-s045><associate.assoziieren><en> Do not associate Me only with thunder and lightning.
<G-vec00318-002-s046><associate.assoziieren><de> Visualisiere und assoziiere.
<G-vec00318-002-s046><associate.assoziieren><en> Visualize and associate.
<G-vec00318-002-s047><associate.assoziieren><de> Er besitzt eine Geistesgegenwart und eine Art sich auszudrücken, bestimmte Themen auszulassen und andere hervorzuheben, die ich mit erfahrenen Politiker/ innen und Diplomat/ innen assoziiere.
<G-vec00318-002-s047><associate.assoziieren><en> He has the presence of mind and way of expressing things—avoiding certain issues and emphasising others—that I associate with experienced politicians and diplomats.
<G-vec00318-002-s048><associate.assoziieren><de> Zu mehreren deiner Stücke assoziiere ich Romantisches.
<G-vec00318-002-s048><associate.assoziieren><en> I associate something Romantic with quite a few of your pieces.
<G-vec00318-002-s049><associate.assoziieren><de> Ich assoziiere mit einem Operator der linearen Algebra zum Beispiel ein sehr klares Bild.
<G-vec00318-002-s049><associate.assoziieren><en> For instance, I have a very clear image of an associate operator from linear algebra.
<G-vec00318-002-s050><associate.assoziieren><de> Diese Jahreszeit assoziiere ich mit Feiern, da nicht nur mein Geburtstag in diese Jahreszeit fällt, sondern auch mehrere Geburtstage meiner Freunde.
<G-vec00318-002-s050><associate.assoziieren><en> Autumn is the season, which I associate with celebrations, not only because my birthday falls in this season, but also several birthdays of my friends.
