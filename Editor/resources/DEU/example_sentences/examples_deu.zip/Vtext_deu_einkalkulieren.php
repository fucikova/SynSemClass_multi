<G-vec00345-001-s062><reckon.einkalkulieren><de> Auch müssen wir mit einkalkulieren, dass die kleinen Zellen am besten IM Brutnest gebaut werden.
<G-vec00345-001-s062><reckon.einkalkulieren><en> We must also reckon with, that small cells can be built best IN the brood nest.
