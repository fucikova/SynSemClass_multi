<G-vec00081-001-s022><halt.anhalten><de> Höhepunkt dieser insgesamt außergewöhnlichen Reise nach Bosnien war der Besuch des nahegelegenen Naturschutzgebiets Hutovo Blato: Kaum angehalten, sprangen 30 Vogel-Expert/innen mit Ferngläsern aus den Autos und fingen an, die Landschaft abzusuchen – ein für uns als Laien unvergessliches Bild.
<G-vec00081-001-s022><halt.anhalten><en> The highlight of this altogether extraordinary trip to Bosnia was a visit to the nearby Hutovo Blato nature reserve: as soon as our convoy came to a halt, 30 bird experts jumped out of their vehicles and started to scan the landscape with binoculars – an unforgettable picture.
<G-vec00081-001-s023><halt.anhalten><de> In einigen Fällen muss möglicherweise der gesamte Cluster angehalten oder neugestartet werden.
<G-vec00081-001-s023><halt.anhalten><en> In some cases it may be necessary to halt or reboot the whole cluster.
<G-vec00081-001-s024><halt.anhalten><de> Wir hielten an und schauten auf einen Rollstuhl, der neben uns angehalten hatte.
<G-vec00081-001-s024><halt.anhalten><en> We stopped and looked at the wheelchair, which had glided to a halt beside us.
<G-vec00081-001-s025><halt.anhalten><de> Diese regelmäßige Datenübertragung kann aber vorübergehend angehalten werden, um Einstellungsänderungen oder andere Vorgänge durchzuführen.
<G-vec00081-001-s025><halt.anhalten><en> It is however possible to temporarily halt the periodic communications in order to carry out setting changes or other processes.
<G-vec00081-001-s026><halt.anhalten><de> Der Eindruck entsteht, als wäre der Darstellungsprozeß hier an einem Punkt angehalten worden, an dem die Materialität der Farbe noch nicht in die Materialität des darzustellenden Gegenstandes übergegangen ist.
<G-vec00081-001-s026><halt.anhalten><en> The impression is generated as if the representational process is here brought to a halt at a point where the materiality of the paint has not yet switched over into the materiality of the object to be represented.
<G-vec00081-001-s027><halt.anhalten><de> So hatte die Gruppe also angehalten, und wie zu vermuten waren die Männer weitaus nüchterner als zum Zeitpunkt ihres Aufbruchs.
<G-vec00081-001-s027><halt.anhalten><en> """The company had come to a halt, more sober men, as you may guess, than when they started."
<G-vec00081-001-s019><pause.anhalten><de> Im ausgeschalteten Zustand wird das Bewerben veröffentlichter Tweets angehalten, und neue Tweets werden erst wieder beworben, wenn diese Option wieder eingeschaltet wird.
<G-vec00081-001-s019><pause.anhalten><en> When toggled off, the promotion of published Tweets will pause and new Tweets will not be promoted until you resume promotion by toggling back on.
<G-vec00081-001-s020><pause.anhalten><de> Der Plan beinhaltet, dass ein Energiestrahl zur Erde gesandt wird, der eine solche Frequenz hat, dass er bewirkt, dass die Grundgeschwindigkeit des Energietransfers in seiner Bewegung angehalten wird.
<G-vec00081-001-s020><pause.anhalten><en> "The Plan of the ""Stasis Process"" involves sending a beam of energy to Earth that is of such a frequency that it causes the basic speed of energy transfer to pause in its movement."
<G-vec00081-001-s021><pause.anhalten><de> Wenn Kontakte immer noch nicht angezeigt: Blühen Eingabeaktion Skype angehalten werden soll.
<G-vec00081-001-s021><pause.anhalten><en> If contacts still don't appear: Bloom gesture to pause Skype.
<G-vec00081-001-s022><pause.anhalten><de> Somit kann digitales Fernsehen (DVB-T) live auf dem iPad 2 angesehen, angehalten, gespult oder aufge-nommen werden, ohne dass zusätzliche Verbindungskosten entstehen.
<G-vec00081-001-s022><pause.anhalten><en> This makes it possible to watch, pause, and rewind digital television (DVB-T) live on the iPad 2, without incurring any additional connection fees.
<G-vec00081-001-s023><pause.anhalten><de> Die Sitzung wird angehalten, der Computer bleibt jedoch eingeschaltet.
<G-vec00081-001-s023><pause.anhalten><en> Locking the Computer. Pause your session, but keep the computer on.
<G-vec00081-001-s028><halt.anhalten><de> Stups durch SamMobile hat ergeben, dass einige Anwender wurden mit Blick auf zufälligen Neustarts nach dem update das verursacht hat Samsung das anhalten der rollout vorübergehend, bis Sie herausfinden, das Problem.
<G-vec00081-001-s028><halt.anhalten><en> Prodding by SamMobile has revealed that some users were facing random reboots after the update, which has caused Samsung to halt the rollout temporarily until they figure out the issue.
<G-vec00081-001-s029><halt.anhalten><de> Beim Anhalten aufgrund eines Speicherfehlers werden die Adresse des fehlerhaften MCB sowie die Daten (4 Langworte) ausgegeben.
<G-vec00081-001-s029><halt.anhalten><en> For a halt due to a memory error the address of the faulty MCB as well as the data (4 LONGwords) are output.
<G-vec00081-001-s030><halt.anhalten><de> B. Funktionen anpassen, Alarme ansehen/löschen, Programme starten/stoppen/anhalten, etc.
<G-vec00081-001-s030><halt.anhalten><en> change functions, view/cancel alarms, start/stop/halt program, etc.
<G-vec00081-001-s031><halt.anhalten><de> Es sind Emotionen welche motivieren, oder jegliche Aktivität anhalten, Emotionen die vor Gefahr warnen, und Emotionen die euch mit euren Geliebten verbinden.
<G-vec00081-001-s031><halt.anhalten><en> It is emotions that motivate or halt any activity, emotions that warn of danger, and emotions that connect you to your beloved.
<G-vec00081-001-s032><halt.anhalten><de> Die oben genannten Szenarien können schwere Katastrophen sein, da sie Ihre Arbeit anhalten, ohne weiter zu gehen.
<G-vec00081-001-s032><halt.anhalten><en> The above scenarios may be severe disasters as they put halt to your work without proceeding any more.
<G-vec00081-001-s033><halt.anhalten><de> Wie der König das hörte, ließ er anhalten und einer seiner Leute musste zurückjagen und von des Königs Kleider holen.
<G-vec00081-001-s033><halt.anhalten><en> When the king heard that, he called halt and one of his people had to chase back and of the king's clothes bring hack.
<G-vec00081-001-s034><halt.anhalten><de> Das Einsteigen und Aussteigen aus dem Fahrzeug ist nur nach dem Anhalten auf Haltestellen oder Stationen zugelassen.
<G-vec00081-001-s034><halt.anhalten><en> Boarding and leaving vehicles is only allowed at stops or stations after the vehicle has come to a halt.
<G-vec00081-001-s035><halt.anhalten><de> Wenn der Penis wirklich beginnen fühlt steigen, könnten Sie verwenden, für 1-2 Tage anhalten.
<G-vec00081-001-s035><halt.anhalten><en> If the penile begin feels rise, you could halt from making use of for 1-2 days.
<G-vec00081-001-s024><pause.anhalten><de> Über das Inline-Mikrofon können Sie Anrufe annehmen und beenden, Titel wiedergeben und anhalten oder die Lautstärke anpassen ohne dafür Ihr Gerät in die Hand nehmen zu müssen.
<G-vec00081-001-s024><pause.anhalten><en> About the inline microphone lets you answer and end calls, play songs and pause or adjust the volume - without having to take your device in the hand.
<G-vec00081-001-s025><pause.anhalten><de> Die Trainer können durch das Touch Control Interface in ihren Präsentationen vor- und zurückspringen, die Präsentation anhalten und selbst die Lautstärke steuern.
<G-vec00081-001-s025><pause.anhalten><en> The trainer has a touch control interface that allows them to forward, pause and rewind all aspects of the presentation and even control the sound levels.
<G-vec00081-001-s026><pause.anhalten><de> Wenn Sie sehen ein YouTube-Clip und brauchen das Video anhalten,, statt des Schlagens Pause auf der YouTube-Player selbst., klicken Sie auf die Pause-Taste Pause für später in der Chrome-Toolbar installiert.
<G-vec00081-001-s026><pause.anhalten><en> When you are viewing a YouTube clip and need to pause the video, instead of hitting pause on the YouTube player itself, click the pause button Pause For Later installed in the Chrome toolbar.
<G-vec00081-001-s027><pause.anhalten><de> Es nutzt Gesten erkannt über eingebaute Webcam auf dem Gerät zu spielen, anhalten und überspringen Songs und Videos in iTunes, Spotify, Rdio, MPlayerX (neueste Version), VLC (neueste Version), Ecoute, Quicktime, Keynote und .
<G-vec00081-001-s027><pause.anhalten><en> It uses HAND GESTURES detected via built-in webcam in your device to play, pause and skip songs & videos in iTunes, Spotify, Rdio, MPlayerX (latest version), VLC (latest version), Ecoute, Quicktime, and Keynote.
<G-vec00081-001-s028><pause.anhalten><de> Danach werden sie die Rangers am Dienstag spielen, bevor sie die Leafs konfrontiert nächsten Samstagabend anhalten.
<G-vec00081-001-s028><pause.anhalten><en> After that they will play the Rangers on Tuesday before they pause to face the Leafs next Saturday night.
<G-vec00081-001-s029><pause.anhalten><de> Es gibt interaktive Features, wie anhalten und zurückspulen Optionen für Live-TV-Wiedergabe.
<G-vec00081-001-s029><pause.anhalten><en> There are interactive features, such as pause and rewind options for Live TV playback.
<G-vec00081-001-s030><pause.anhalten><de> Suchen Sie nach Orten, wo Sie logisch für Atem anhalten können.
<G-vec00081-001-s030><pause.anhalten><en> Look for places where you can logically pause for breath.
<G-vec00081-001-s031><pause.anhalten><de> Springdale liegt direkt außerhalb des Zion Nationalparks und dort werden wir kurz anhalten, um die Lunchpakete abzuholen, welche wir im Bryce Canyon genießen werden.
<G-vec00081-001-s031><pause.anhalten><en> Springdale is just outside Zion, and we'll pause there briefly to pick up sack lunches, which we generally enjoy in Bryce.
<G-vec00081-001-s032><pause.anhalten><de> Das laufende Programm kann jederzeit aufgenommen werden und es werden bis zu 30 Minuten gepuffert, so dass man jederzeit die Wiedergabe anhalten und später an der selben Stelle fortsetzen kann.
<G-vec00081-001-s032><pause.anhalten><en> The current programme can be recorded at any time and up to 30 minutes will be buffered, so you can pause the play back any time and continue at the same position later.
<G-vec00081-001-s033><pause.anhalten><de> "HomePod ist an der Spitze mit einem Oberfläche berühren, über die der Benutzer die Lautstärke ändern, Siri anhalten, überspringen oder ""fragen"" kann."
<G-vec00081-001-s033><pause.anhalten><en> "HomePod is provided at the top with a touch surface, through which the user will be able to change the volume, pause, skip or ""ask"" Siri."
<G-vec00081-001-s034><pause.anhalten><de> Zwischen den Hohlräumen, Man spürt die Musik Ihren Chor anhalten, wieder weiter mit neuen Noten und mit neuen refrãos.
<G-vec00081-001-s034><pause.anhalten><en> Between the empty spaces, You can feel the music pause your chorus, to continue again with new notes and with new refrãos.
<G-vec00081-001-s035><pause.anhalten><de> Wenn Sie eine ausgehende Warteschlange anhalten, wird der Nachrichtenversand aus dieser Warteschlange an die entsprechende Zielwarteschlange zeitlich verzögert.
<G-vec00081-001-s035><pause.anhalten><en> When you pause the operation of an outgoing queue, you postpone the sending of messages from that queue to the corresponding destination queue.
<G-vec00081-001-s036><pause.anhalten><de> Der Weg ist eine schöne Strecke durch Schluchten entlang eines Flusses, mit vielen Möglichkeiten zum anhalten und um im Wasser zu spielen.
<G-vec00081-001-s036><pause.anhalten><en> This is a great route along the river and gorges, where there are many places to pause and play in the water.
<G-vec00081-001-s037><pause.anhalten><de> Als Musik zu spielen, der Taste anhalten und abspielen.
<G-vec00081-001-s037><pause.anhalten><en> When music playing, press the button to pause and play.
<G-vec00081-001-s038><pause.anhalten><de> Das neue Elgato EyeTV Lite ist eine Software für Macs, mit der der Nutzer Live-Fernsehübertragungen ansehen, anhalten und zurückspulen sowie mehrere Stunden an TV Sendungen direkt auf dem Mac aufnehmen kann.
<G-vec00081-001-s038><pause.anhalten><en> • New Elgato EyeTV Lite Software for Mac, which enables users to watch, pause and rewind live TV and record hours of shows directly onto the Mac.
<G-vec00081-001-s039><pause.anhalten><de> Der Begriff 'Wechseljahre' wird verwendet, um die endgültige Stilllegung oder Anhalten der Hauptfunktionen der Eierstöcke im Körper einer Frau zu definieren.
<G-vec00081-001-s039><pause.anhalten><en> The term 'menopause' is used to define the permanent cessation or pause of the primary functions of the ovaries in a woman's body.
<G-vec00081-001-s040><pause.anhalten><de> Auf einem Computer unter Windows Server 2008 R2 können Sie den Serverdienst für verteilte Scanvorgänge starten, beenden oder anhalten.
<G-vec00081-001-s040><pause.anhalten><en> On a computer running Windows Server 2008 R2, you can start, stop, or pause the Distributed Scan Server service for a scan server.
<G-vec00081-001-s041><pause.anhalten><de> Klicken Sie auf Anhalten, um diesen Dienst anzuhalten.
<G-vec00081-001-s041><pause.anhalten><en> Click Pause to pause this service.
<G-vec00081-001-s042><pause.anhalten><de> Darüber hinaus können Sie eine automatische Antwort an den Absender der Kette / Witz / E-Mails weitergeleitet werden, dass sie informiert hat, dass sie wirklich länger anhalten sollte, bevor Nachrichten an Personen, wie es füllt sich Menschen Posteingänge unnötig, die blonde Witze waren nicht sehr lustig an erster Stelle, und nicht, Bill Gates ist nicht wirklich Verfolgung dieser Kette E-Mail und wird nicht geben Ihnen eine Million Dollar für die Weiterleitung.
<G-vec00081-001-s042><pause.anhalten><en> In addition, you can enable an automatic reply to the sender of chain/joke/forwarded emails that informs them that they really should pause longer before forwarding messages to people, as it fills up people's inboxes needlessly, the blonde jokes weren't very funny in the first place, and no, Bill Gates isn't really tracking this chain email and won't give you a million dollars for forwarding it.
<G-vec00081-001-s019><stop.anhalten><de> "Wir beschäftigen derzeit mehr als 100 Menschen mit Behinderungen und nicht dort anhalten "", sagte in seinem Vortrag Bruno Kostelac Košir, INA Direktor für Entwicklung und Bildung, Vertreter von Verbänden und Organisationen von Menschen mit Behinderungen auf eine verstärkte Zusammenarbeit in diesem Bereich eingeladen."
<G-vec00081-001-s019><stop.anhalten><en> "We currently employ more than 100 persons with disabilities and do not stop there "", said in his presentation Bruno Kostelac Košir, INA Director of Development and Education, inviting representatives of associations and organizations of persons with disabilities on enhanced cooperation in this area."
<G-vec00081-001-s020><stop.anhalten><de> Wir werden an einem abgelegenen Strand anhalten, wo die Crew kochen und das Barbecue-Mittagessen servieren wird.
<G-vec00081-001-s020><stop.anhalten><en> We will stop on a secluded beach, where the crew will cook and serve the barbecue lunch.
<G-vec00081-001-s021><stop.anhalten><de> Je länger ich fuhr, desto weniger wollte ich anhalten, verrückt.
<G-vec00081-001-s021><stop.anhalten><en> The longer I went, the less I wanted to stop, crazy.
<G-vec00081-001-s022><stop.anhalten><de> Diese Muskeln zu beschränken, für fünf Sekunden anhalten und dann zu entspannen.
<G-vec00081-001-s022><stop.anhalten><en> Constrain these muscles, stop for five second and then relax them.
<G-vec00081-001-s023><stop.anhalten><de> "Orthon schien mein Erstaunen zu genießen und erklärte: ""Wir haben einen Projektor, der in einem beliebigen Abstand wie gewünscht die Strahlen senden und anhalten kann."
<G-vec00081-001-s023><stop.anhalten><en> "Orthon seemed to enjoy my amazement and explained, ""We have a certain type of projector that can send out and stop beams at any distance desired."
<G-vec00081-001-s024><stop.anhalten><de> Wenn sie gemeinsam spazieren gingen, musste ihre Oma immer beim Juwelier anhalten.
<G-vec00081-001-s024><stop.anhalten><en> When they went for a walk together, her grandma always had to stop at the jeweller.
<G-vec00081-001-s025><stop.anhalten><de> Es klang ja allerdings sonderbar, wenn er vor den in die lärmerfüllte Luft geöffneten Fenstern ein altes Soldatenlied seiner Heimat spielte, das die Soldaten am Abend, wenn sie in den Kasernenfenstern liegen und auf den finstern Platz hinausschauen, von Fenster zu Fenster einander zusingen – aber sah er dann auf die Straße, so war sie unverändert und nur ein kleines Stück eines großen Kreislaufes, das man nicht an und für sich anhalten konnte, ohne alle Kräfte zu kennen, die in der Runde wirkten.
<G-vec00081-001-s025><stop.anhalten><en> When he played an old soldier's song from his homeland, which the soldiers sing from window to window as they lean out of the barracks windows and look out at the dark square, it resonated oddly in the noise-filled air of his open window – but he looked across the street, it was so unchanged and just a small piece of a giant cycle that no one could stop without knowing all the powers effecting that cycle.
<G-vec00081-001-s026><stop.anhalten><de> Das Bewusstsein entwickelt sich und wenn wir wirklich anhalten und darüber nachdenken, dann begann die Abhängigkeit von Großunternehmen uns zu kurieren ungefähr mit der Erfindung des Penizillins zur Zeit des Zweiten Weltkriegs.
<G-vec00081-001-s026><stop.anhalten><en> Consciousness is evolving, and if we really stop and think, this dependency upon large companies to cure us only began at about World War II, with the invention of penicillin.
<G-vec00081-001-s027><stop.anhalten><de> Du brauchst nichts weiter zu tun als anhalten und entspannen - etwas Musik hören, nichts weiter.
<G-vec00081-001-s027><stop.anhalten><en> All you need to do is stop and relax - listen to some music, nothing more.
<G-vec00081-001-s028><stop.anhalten><de> Ich brauchte etwa eine Stunde um die drei Blocks zurück zur Klinik zu gehen, weil ich ziemlich betrunken war von der Mixtur der Pillen und dem Alkohol, also musste ich mehrere Male anhalten um auszuruhen.
<G-vec00081-001-s028><stop.anhalten><en> It took me about an hour to walk three blocks back to the hospital because I was quite inebriated from the mixture of pills and alcohol, so I had to stop several times to rest.
<G-vec00081-001-s029><stop.anhalten><de> Aber die Pfeile fielen in solche Fülle, dass er anhalten musste.
<G-vec00081-001-s029><stop.anhalten><en> But arrows were falling in such exuberance that he had to stop.
<G-vec00081-001-s030><stop.anhalten><de> Als ich an diesen Punkt kam, war ich aber an einer ganz falschen Stelle, bremste zu spät und verpasste die Linie komplett, fast hätte ich anhalten müssen.
<G-vec00081-001-s030><stop.anhalten><en> I came to that point in the track, entirely in the wrong place, braked too late, and completely messed up the line, almost coming to a stop!
<G-vec00081-001-s031><stop.anhalten><de> Wir gehen weiter der Via Biagio ai Librai entlang bis auf die Piazza San Domenico Maggiore, wo wir anhalten, um die gleichnamige Kirche zu besichtigen.
<G-vec00081-001-s031><stop.anhalten><en> We continue along Via Biagio ai Librai until Piazza San Domenico Maggiore where we stop to visit the church.
<G-vec00081-001-s032><stop.anhalten><de> Beim Verlassen von Sedona musste sie für eine Schlage anhalten, die gemächlich die Straße überquerte.
<G-vec00081-001-s032><stop.anhalten><en> Upon leaving Sedona, she had to stop for a snake taking its sweet time crossing her driveway.
<G-vec00081-001-s033><stop.anhalten><de> Über die Tasten können Sie Titel wiedergeben, anhalten oder überspringen sowie die Lautstärke anpassen.
<G-vec00081-001-s033><stop.anhalten><en> Use the buttons to play, stop or skip through tracks and adjust the volume.
<G-vec00081-001-s034><stop.anhalten><de> Wenn Sie anhalten sollen, signalisiert man dies Ihnen mit einer Kelle oder einer Leuchtschrift.
<G-vec00081-001-s034><stop.anhalten><en> If you are to stop, a police officer signals you with a round paddle or a lighted sign.
<G-vec00081-001-s035><stop.anhalten><de> Das Roping-Pferd muss schnell anhalten, wenn die Schlinge sich um den Nacken des Kalbes legt.
<G-vec00081-001-s035><stop.anhalten><en> The calf roping horse is asked to slide to a stop as the loop settles over the calf's neck.
<G-vec00081-001-s036><stop.anhalten><de> Nach Marvin Gayes Worten, müssen Sie kurz anhalten, beobachten und zuhören – nicht auf Ihr Herz- sondern auf einzelne Bedürfnisse Ihrer Kunden und erstellen Sie eine Strategie, wie Sie am erfolgreichsten mit ihnen auf Social Media engagieren.
<G-vec00081-001-s036><stop.anhalten><en> In the words of Marvin Gaye, you've got to stop, look and listen – not to your heart – but to your customers' every need and want, then structure a strategy on how to engage successfully with them on social media.
<G-vec00081-001-s037><stop.anhalten><de> Auch bei den Wanderungen mussten wir ständig anhalten, damit sie Verschnaufpausen einlegen konnte.
<G-vec00081-001-s037><stop.anhalten><en> We also had to constantly stop during our hike to give her time to catch her breath.
<G-vec00081-001-s036><halt.anhalten><de> Wie sie Ihre Flosse fast quer stellt, um anzuhalten.
<G-vec00081-001-s036><halt.anhalten><en> How she crosses her fluke to a halt.
<G-vec00081-001-s037><halt.anhalten><de> Ihr Wachstum man anzuhalten sollte das vorhandene Bewußtsein in der Seele Kraft zentralisieren.
<G-vec00081-001-s037><halt.anhalten><en> To halt their growth one should centralise the available consciousness in the soul force.
<G-vec00081-001-s038><halt.anhalten><de> Es ist außerdem möglich, jede CPU anzuhalten, die sich im Idle-Loop befindet, dazu dient die sysctl-Variable machdep.hlt_cpus.
<G-vec00081-001-s038><halt.anhalten><en> It is also possible to halt any CPU in the idle loop with the machdep.hlt_cpus sysctl variable.
<G-vec00081-001-s039><halt.anhalten><de> In Pittsburgh, waren die Flammen nicht in der Lage, ihre letzten Dia entweder anzuhalten, trotz der Abwesenheit von Sidney Crosby, der für die Mumps getestet wurde.
<G-vec00081-001-s039><halt.anhalten><en> In Pittsburgh, the Flames were not able to halt their recent slide either, despite the absence of Sidney Crosby, who was tested for the mumps.
<G-vec00081-001-s040><halt.anhalten><de> Er reagierte nicht auf Aufrufe, anzuhalten, und schritt auch weiter, nachdem Warnschüsse in die Luft gefeuert wurden.
<G-vec00081-001-s040><halt.anhalten><en> He did not heed their calls to halt and continued walking even after they fired shots into the air.
<G-vec00081-001-s041><halt.anhalten><de> In nuun für zwei Klavier und Orchester von 1996 lässt Furrer sogar die mythische Figur Nu, die der Legende nach die Zeit anzuhalten vermag, im Stück-Titel auftauchen und spannt in dem Werk einen großen Bogen vom Ensembletutti zum vereinzelten Klavierton, vom Fortissimo zum Pianissimo, von einer wahren Sturzflut gleichzeitiger musikalischer Ereignisse zur Stille.
<G-vec00081-001-s041><halt.anhalten><en> In nuun (1996) for two pianos and orchestra, Furrer's title even evokes the mythical figure of Nu, who, according to legend, was able to bring time to a halt, and the work spans a range from the tutti ensemble to isolated piano notes, from fortissimo to pianissimo, from a true flood of simultaneous musical events to silence.
<G-vec00081-001-s042><halt.anhalten><de> Solch ein Ergebnis könnte sein, dass die Sonne 180° weg von, dem, wie in Wans Traum Königs sein sollte, würde veranlassen das Programm anzuhalten war.
<G-vec00081-001-s042><halt.anhalten><en> Such a result could be that the sun was 180° away from where should be, like in king Wan's dream, would cause the program to halt.
<G-vec00081-001-s043><halt.anhalten><de> Durch die Erhöhung der Glycosaminoglycans wird dabei geholfen, den Knorpel wieder aufzubauen und die Entwicklung bestimmter Arten von Arthritis zu verlangsamen oder anzuhalten.
<G-vec00081-001-s043><halt.anhalten><en> By increasing glycosaminoglycans, users of supplemental glucosamine may help to rebuild cartilage and slow or halt the advancement of certain types of arthritis.
<G-vec00081-001-s044><halt.anhalten><de> Die UN-Mitglieder zielen darauf, bis 2015 die Ausbreitung von HIV /AIDS, Malaria und anderen schweren Krankheiten anzuhalten.
<G-vec00081-001-s044><halt.anhalten><en> The UN (United Nations) members target to halt the spread of HIV/AIDS, malaria, and other major infectious diseases by 2015. Trends: 0 / −
<G-vec00081-001-s046><halt.anhalten><de> Der richtige Moment, die Zeit anzuhalten.
<G-vec00081-001-s046><halt.anhalten><en> The right moment to halt the turn of time.
<G-vec00081-001-s047><halt.anhalten><de> Die einfachste Lösung besteht häufig darin, den Server brutal anzuhalten (nachdem der Befehl sync ausgeführt wurde) und dann den Rechner mit einer Rettungs-CD neu zu starten.
<G-vec00081-001-s047><halt.anhalten><en> The simplest solution is often to halt the server brutally (after running sync) and reboot it on a rescue CD.
<G-vec00081-001-s043><pause.anhalten><de> Es empfiehlt sich aber vor dem Betrachten der vergrößerten Bilder die Slideshow anzuhalten (II), weil sie sonst im Hintergrund weiterläuft und Sie dann wieder manuell zu Ihrem zuletzt besuchten Bild zurückkehren müssen.
<G-vec00081-001-s043><pause.anhalten><en> It is useful to pause (II) the slideshow if You want to see the enlarged version of a picture or watch a video. Otherwise it is marching on in the background and You have to go manually to Your last viewed picture within the slideshow window.
<G-vec00081-001-s044><pause.anhalten><de> Sie können Ihr Gerät sogar verwenden, um das Gerät Ihres Kindes anzuhalten oder zusätzliche Zeit zu gewähren, und unterstützt Sie bei der Erstellung einer Checkliste von Internetseiten, die Ihr Kind besuchen und von denen es lernen sollte.
<G-vec00081-001-s044><pause.anhalten><en> Even use your device to pause your child's device or give additional time and helps you create a checklist of the sites you want your child to visit and learn from.
<G-vec00081-001-s045><pause.anhalten><de> Es besteht auch die Möglichkeit, die Methode während eines Laufs anzuhalten.
<G-vec00081-001-s045><pause.anhalten><en> There is also a possibility to pause your method during a run.
<G-vec00081-001-s046><pause.anhalten><de> Verwende mehrzeiliges Bearbeiten, um Kampagnen, Anzeigengruppen und Promoted Pins anzuhalten, zu aktivieren und zu archivieren.
<G-vec00081-001-s046><pause.anhalten><en> Use multi-row editing to pause, activate, and archive campaigns, ad groups, and Promoted Pins.
<G-vec00081-001-s047><pause.anhalten><de> Verwenden Sie net pause, um den Dienst anzuhalten, wodurch neue Verbindungen verhindert werden.
<G-vec00081-001-s047><pause.anhalten><en> Use net pause to pause the service, which prevents new connections.
<G-vec00081-001-s048><pause.anhalten><de> Es hilft oft, für eine oder zwei Sekunden in der vollständig gestreckten und der vollständig kontrahierten Position jeder Wiederholung anzuhalten.
<G-vec00081-001-s048><pause.anhalten><en> It often helps to pause for one or two seconds in the fully stretched and the fully contracted position of each repetition.
<G-vec00081-001-s049><pause.anhalten><de> Breakpoints erlauben es, die Ausführung des Programms an einer bestimmten Zeile anzuhalten, damit man in Ruhe Variablen inspizieren und den Programmfluss besser nachvollziehen kann.
<G-vec00081-001-s049><pause.anhalten><en> Breakpoints allow to pause the execution of a program at a specific line. This way you can inspect variables without a hurry, and it allows you to comprehend the program flow much better.
<G-vec00081-001-s050><pause.anhalten><de> Klicken Sie auf ESC, um das Spiel anzuhalten.
<G-vec00081-001-s050><pause.anhalten><en> Click ESC to pause the game.
<G-vec00081-001-s051><pause.anhalten><de> Mit P-Taste, um das Spiel anzuhalten.
<G-vec00081-001-s051><pause.anhalten><en> Use P key to pause the game.
<G-vec00081-001-s052><pause.anhalten><de> Praxis, allein oder mit Ihrem Partner, bringen Sie sich selbst in der Nähe der Ejakulation und dann anzuhalten.
<G-vec00081-001-s052><pause.anhalten><en> Practice, alone or with your partner, bringing your self close to ejaculation and then pause.
<G-vec00081-001-s054><pause.anhalten><de> Beim Betreten, sofort nach rechts, lassen Sie uns anzuhalten, um die schöne romanische Schrift, deren kreisförmige Becken sind Reliefs mit Szenen aus dem Leben von Moses und Figuren bewundern.
<G-vec00081-001-s054><pause.anhalten><en> Upon entering, immediately right, let us pause to admire the beautiful Romanesque font whose circular basin are reliefs with scenes from the life of Moses and figures.
<G-vec00081-001-s055><pause.anhalten><de> Wie das Dialogfeld Eigenschaften für bestimmte Dienste im Snap-In Dienste können Sie die Befehle am Rand des Bereichs Systemdienste verwenden, um der Verwendung einer Rolle zugeordnete Dienste zu starten, zu beenden, anzuhalten und neu zu starten.
<G-vec00081-001-s055><pause.anhalten><en> Just as you can by using the Properties dialog box for specific services in the Services snap-in, you can use commands in the margin of the System Services area to start, stop, pause, and restart services associated with the operation of a role.
<G-vec00081-001-s056><pause.anhalten><de> Klicken Sie auf Bomben zu benachbarten Kugeln oder Uhren anzuhalten der Bewegung zu entfernen.
<G-vec00081-001-s056><pause.anhalten><en> Click bombs to remove adjacent orbs or clocks to pause the movement.
<G-vec00081-001-s057><pause.anhalten><de> Geben Sie beispielsweise auf dem Clientcomputer den Befehl ipconfig /all|more ein, um die Anzeige anzuhalten, damit Sie die IP-Adressen anzeigen und notieren können, die für die Befehlsausgabe unter DNS-Server aufgeführt werden.
<G-vec00081-001-s057><pause.anhalten><en> For example, at the client computer, type ipconfig /all|more if necessary to pause the display so that you can read and note any IP addresses that are listed in DNS servers for the command output.
<G-vec00081-001-s058><pause.anhalten><de> P-Taste ist für das Spiel anzuhalten.
<G-vec00081-001-s058><pause.anhalten><en> P key is for pause the game.
<G-vec00081-001-s059><pause.anhalten><de> Der Lizenzgeber ist jederzeit ohne Ankündigung des Lizenznehmers und ohne Erklärung der Gründe berechtigt, den Zugang und die Möglichkeit anzuhalten, das Professionelle Netz ohne Ersatz irgendwelcher Aufwände, der Schäden oder der Rückgabe bekommen laut Abkommen, einschließlich im Falle jedes, einschließlich einmalig, des Verstoßes vom Lizenznehmer der Bedingungen des gegenwärtigen Abkommens zu verwenden.
<G-vec00081-001-s059><pause.anhalten><en> The Licensor has the right at any time without notice the Licensee and without explanation to pause access and opportunity to use the Professional network without reimbursing of any expenses, losses or return received under the Agreement, including in case of any, including one-fold, violations by the Licensee of conditions of the present Agreement.
<G-vec00081-001-s060><pause.anhalten><de> Drücken Sie die Leertaste, um den Timer anzuhalten.
<G-vec00081-001-s060><pause.anhalten><en> To pause the boot timer in order to review the selections, press Space .
<G-vec00081-001-s061><pause.anhalten><de> Zwar ist dies viel einfacher für die Leute, die nicht über eine Steckdose in der Toilette, bedeutet es, Sie brauchen, um anzuhalten und darüber nachdenken, die Batterielebensdauer.
<G-vec00081-001-s061><pause.anhalten><en> While this is lots more simple for those people that don’t have a power outlet in the toilet, it does mean you will need to pause and think about battery life.
<G-vec00081-001-s057><stop.anhalten><de> Diese verbindet die zwei Hauptinseln der Inselgruppe und viele Busfahrer und Reiseleiter machen sich einen Spaß daraus dort anzuhalten und den Besuchern zu ihrer ganz persönlichen „Transatlaniküberfahrt“ zu verhelfen.
<G-vec00081-001-s057><stop.anhalten><en> "It combines the two main islands of the archipelago and many bus drivers and guide will make a fun from it there stop and visitors of their own personal """"Transatlaniküberfahrt""to help."""
<G-vec00081-001-s058><stop.anhalten><de> Ungeachtet ihrer großen Vielfältigkeit, die Auswahl ist es besser, auf der klassischen Variante aus dem Wein und den Gewürzen anzuhalten.
<G-vec00081-001-s058><stop.anhalten><en> Despite their big variety, a choice it is better to stop on classical option from wine and spices.
<G-vec00081-001-s059><stop.anhalten><de> Es gibt den Motor zur Ausgabe, und der Mensch nicht im Zustand, es anzuhalten.
<G-vec00081-001-s059><stop.anhalten><en> There is a drive towards release and person is not able to stop it.
<G-vec00081-001-s060><stop.anhalten><de> Die anmutigen Bewegungen die friedliche Musik veranlasste viele Passanten, anzuhalten und zuzusehen.
<G-vec00081-001-s060><stop.anhalten><en> The graceful movements and peaceful music attracted many passers-by to stop and watch.
<G-vec00081-001-s061><stop.anhalten><de> So ist es den Mädchen mit den Fingern fein und lang besser, die Auswahl auf den kurzen ovalen oder quadratischen Nägeln anzuhalten.
<G-vec00081-001-s061><stop.anhalten><en> So, with fingers thin and long it is better for girls to stop the choice on short oval or square nails.
<G-vec00081-001-s062><stop.anhalten><de> von einer wertvollen Hilfe für die Raucher, die wünschen, sich den Tabak anzuhalten, sie beruhigt die Angst, die Ängste und die Nervosität die das Entwöhnen in Nikotin begleiten.
<G-vec00081-001-s062><stop.anhalten><en> of an invaluable help for the smokers wishing to stop the tobacco, it calms the anxiety, the anguishes and the nervousness which accompany weaning with nicotine.
<G-vec00081-001-s063><stop.anhalten><de> Das Auto parallel der Borte (4) geebnet und endgültig abgebremst, ist nötig es das Signal der Wendung abzuschalten und, den Motor anzuhalten.
<G-vec00081-001-s063><stop.anhalten><en> Having levelled the car in parallel a border (4) and definitively having braked, it is necessary to disconnect a signal of turn and to stop the engine.
<G-vec00081-001-s064><stop.anhalten><de> Da hilft nur, anzuhalten, das Auto zu reparieren und die fehlerhaften Teile auszuwechseln.
<G-vec00081-001-s064><stop.anhalten><en> The only thing to do is stop and get the car repaired and the faulty components replaced.
<G-vec00081-001-s065><stop.anhalten><de> Khiray war versucht, in der nächsten größeren Stadt anzuhalten und einen Arzt oder Kräuterheiler danach zu fragen.
<G-vec00081-001-s065><stop.anhalten><en> Khiray was tempted to stop at the next big city and ask a doctor or herb healer for it.
<G-vec00081-001-s066><stop.anhalten><de> Versuchen Sie, das nächste Auto anzuhalten (was auf einer abgelegenen Straße Stunden dauern kann), berichten Sie, was Sie beobachtet haben und fragen Sie um Rat.
<G-vec00081-001-s066><stop.anhalten><en> Try to stop the next car (which can take hours on a remote road), report what you have observed, and ask for advice.
<G-vec00081-001-s067><stop.anhalten><de> Ich fühlte als würde ich darum kämpfen mich anzuhalten von diesem Zurückziehen und ich wollte weiter gehen, aber das sollte nicht sein.
<G-vec00081-001-s067><stop.anhalten><en> I felt as if I was fighting to stop myself from being pulled out and I wanted to continue forward but that wasn't meant to be.
<G-vec00081-001-s068><stop.anhalten><de> Angesichts der endlosen Kurven besteht fast die Gefahr in einen meditativen Zustand zu verfallen, was man aber aufgrund der schwierigen Strecke und der ablenkenden, wunderschön-schaurigen Landschaft besser vermeiden sollte.Die Straße ist eng und es gibt nur wenige Möglichkeiten anzuhalten.
<G-vec00081-001-s068><stop.anhalten><en> In view of the endless curves almost the danger exists to go to ruin in a meditative state, what one, however should prevent.The street is narrow and there are only few possibilities to stop.
<G-vec00081-001-s069><stop.anhalten><de> Andere sehenswerte Orte: Wenn du vom Westen kommst, lohnt es sich auf jeden Fall in Transsylvanien anzuhalten.
<G-vec00081-001-s069><stop.anhalten><en> Other places to see: If you come from the west, there's a use to stop in Transylvania.
<G-vec00081-001-s070><stop.anhalten><de> Wir rufen zu keiner physischen Gewalt auf, veröffentlichen aber diese Angaben in der Hoffnung, dass es diese Menschen wie auch ihre Kampfgefährten dazu bewegt, anzuhalten und mit allen möglichen Mitteln die verbrecherischen Befehle des Kreml-Regimes zu sabotieren.
<G-vec00081-001-s070><stop.anhalten><en> We do not call for the physical liquidation of these people, we publish their data in the hope that it will encourage them and their comrades to stop and to sabotage the criminal orders of the Kremlin's regime in every possible way.
<G-vec00081-001-s071><stop.anhalten><de> Die moderne Bundesstraße 14 folgt dem Verlauf der römischen Via Annia und gibt dem Besucher die Gelegenheit, dieses Erbe des DOC-Gebiets DOC Friuli Latisana zu bewundern, anzuhalten und zu genießen.
<G-vec00081-001-s071><stop.anhalten><en> State road 14, which today retraces the path of the old Via Annia, offers an opportunity to stop, admire and enjoy the heritage of the Friuli Latisana DOC area, the products of which the chairman and members of this consortium are pleased to offer the consumer.
<G-vec00081-001-s072><stop.anhalten><de> Unter diesen internationalen Richtlinien wäre es für die US-Marine illegal, ein Seefahrzeug in internationalen Gewässern anzuhalten, das der Regierung Nordkoreas, Syriens oder China gehört.
<G-vec00081-001-s072><stop.anhalten><en> Under these international guidelines it would be illegal for the U.S. Navy to stop a vessel belonging to the government of North Korea or Syria or China in international waters.
<G-vec00081-001-s073><stop.anhalten><de> drücken Sie dann abzuspielen oder anzuhalten, um die Musik auf each.you Steuerung können auch auf den Tasten 1, 2 oder 3, um zwischen verschiedenen Loops zu wechseln.
<G-vec00081-001-s073><stop.anhalten><en> Then press Play or Stop to control the music on each.You can also click buttons 1, 2, or 3 to switch between different loops.
<G-vec00081-001-s074><stop.anhalten><de> Da es zu spät war, den Wagen abzubremsen und anzuhalten, krachte der Wagen in die Leitplanke.
<G-vec00081-001-s074><stop.anhalten><en> As it was too late to brake and stop the car, the car ran in to the safety barrier.
<G-vec00081-001-s075><stop.anhalten><de> dass Sie genug Platz haben, um plötzlich anzuhalten, das Gleichgewicht zu halten und zu steuern.
<G-vec00081-001-s075><stop.anhalten><en> that you have enough room to suddenly stop, re-balance and steer.
<G-vec00213-002-s028><halt.anhalten><de> Sie wissen, was sie tun müssen, um ihre Entwicklung anzuhalten, wenn sie entsprechende Bedingungen fühlen und um sie fortzusetzen, wenn die Temperatur das gewünschte Niveau erreicht hat.
<G-vec00213-002-s028><halt.anhalten><en> They know what to do to halt their development when they sense these conditions, and continue to develop when the temperature reaches the desired level.
<G-vec00213-002-s057><stop.anhalten><de> Sollte der Fahrer beispielsweise im Notfall keinerlei Reaktion zeigen, nutzt der Cadillac CT6 die ganze Bandbreite an Fahrassistenz-Technologien an Bord, um das Auto kontrolliert anzuhalten.
<G-vec00213-002-s057><stop.anhalten><en> In the limited event when a driver becomes completely unresponsive, the Cadillac CT6 utilizes the full capability of onboard driver assistance technologies to bring the car to a controlled stop.
<G-vec00213-002-s058><stop.anhalten><de> Die Zahlung kann in der Tat in vielen Fällen nur auf elektronischem Wege entrichtet werden, somit gibt es keine Möglichkeit, an der Mautstelle anzuhalten und bar zu bezahlen.
<G-vec00213-002-s058><stop.anhalten><en> In fact in many cases the payment can only be made electronically, so there is no possibility to stop at the toll booth and pay cash.
<G-vec00213-002-s059><stop.anhalten><de> Das Gesetz in Brünn schreibt vor, für Fußgänger anzuhalten, sobald sie auf die Straße treten, aber viele Fahrer tun dies nicht und Unfälle kommen vor.
<G-vec00213-002-s059><stop.anhalten><en> The law in Brno is to stop for pedestrians as soon as they step into the street, but many drivers don’t and accidents do occur.
<G-vec00213-002-s060><stop.anhalten><de> Um die Aktion langsamer abzuspielen oder die Aktion nach jedem Schritt anzuhalten, benutzen Sie den Menüpunkt "Ausführen-Optionen" im Bedienfeldmenü.
<G-vec00213-002-s060><stop.anhalten><en> To play the actions more slowly or to make the actions stop after each step try the "Playback Options" panel menu item. 9.
<G-vec00213-002-s061><stop.anhalten><de> Ein Beispiel ist der Fall eines [Meditations]-Jüngers, der versuchte (mit der „Kraft des Geistes“, wie er glaubte), einen Zug anzuhalten.
<G-vec00213-002-s061><stop.anhalten><en> An example is the case of a follower who attempted (with his "power of the mind" as he believed) to stop a train.
<G-vec00213-002-s062><stop.anhalten><de> Bei der klassischen Meditation wird der Geist beruhigt und versucht alle Gedankenregungen anzuhalten.
<G-vec00213-002-s062><stop.anhalten><en> In classical meditation, we try to calm the mind and stop all thought impulses.
<G-vec00213-002-s063><stop.anhalten><de> Treffen Sie Maßnahmen, um die Mitfahrer in Sicherheit zu bringen (helfen Sie Ihren Mitfahrern, die gefährliche Zone der Autobahn zu verlassen) und den Unfallort abzusichern (stellen Sie das Warndreieck in einem angemessenen Abstand auf; falls sie gezwungen sind, auf der Notspur anzuhalten, stellen sie es 150 Meter vor dem Wagen auf).
<G-vec00213-002-s063><stop.anhalten><en> Take measures ensure your passenger’s safety (help your passengers to leave the risky area of the motorway) and to safeguard the accident scene (place the breakdown triangle at a proper distance; if you are obliged to stop on the hard shoulder place triangle 150 metres ahead of the car)
<G-vec00213-002-s064><stop.anhalten><de> Um einen Garvorgang anzuhalten, reicht es aus, den Timer-Schaltknopf gegen den Uhrzeigersinn auf Null zu stellen.
<G-vec00213-002-s064><stop.anhalten><en> To stop a cooking cycle, turn the timer button clockwise or anticlockwise to zero.
<G-vec00213-002-s066><stop.anhalten><de> Bitte, wir brauchen Ihre Hilfe, um diese Maschine anzuhalten.
<G-vec00213-002-s066><stop.anhalten><en> Please, we need you to help us to stop the machine.
<G-vec00213-002-s067><stop.anhalten><de> Neben den feinsandigen Stränden, die immer noch ihren Scharm beibehalten konnten und dem kristallklaren Wasser des Mittelmeeres gibt es eine Vielzahl kultureller und sportlicher Aktivitäten, die häufig den Wunsch aufkommen lassen, einfach die Zeit anzuhalten.
<G-vec00213-002-s067><stop.anhalten><en> Besides the beaches that preserve their charm at any given moment with their fine sand and the crystal waters of the Mediterranean through which she shows her entire adorableness, with various cultural and sporting activities, Side is a heavenly resort, where you will wish that you could stop the time.
<G-vec00213-002-s068><stop.anhalten><de> 3. danach auf "Senden" klicken, um den Timer anzuhalten.
<G-vec00213-002-s068><stop.anhalten><en> 3. click “Submit” once completed to stop the timer.
<G-vec00213-002-s069><stop.anhalten><de> Wir deuten auf die Notwendigkeit hin, anzuhalten, sich neu zu orientieren und eine etwas distanzierte Sicht auf Situationen (oder Überzeugungen oder Personen) einzunehmen, die ihr bisher als vertraut angesehen habt.
<G-vec00213-002-s069><stop.anhalten><en> We state the need to stop, refocus, taking a somewhat distant view of a situation (or belief, or person) which you considered familiar.
<G-vec00213-002-s070><stop.anhalten><de> Einige Menschen sind in der Lage anzuhalten, aber sobald eine Person eine Gewinnen-Wette abschließt, wird er oder sie gewöhnlich vom Spielprogrammfehler angehakt.
<G-vec00213-002-s070><stop.anhalten><en> Some people have the ability to stop but once a person makes a winning bet, he or she is usually hooked by the gambling bug.
<G-vec00213-002-s071><stop.anhalten><de> Bei jeder Störung, die die Weiterfahrt verhindert, ist der Kunde verpflichtet anzuhalten, den KD darüber telefonisch zu verständigen und, falls möglich, das Fahrrad an nächst gelegener KRM-Station abzustellen.
<G-vec00213-002-s071><stop.anhalten><en> In case of any failure preventing further riding, the Customer is obliged to stop and notify the Customer Service Centre/BOK by phone and, if possible, escort the Bicycle to the nearest KRM Station.
<G-vec00213-002-s072><stop.anhalten><de> Sie können Ihren Reiseleiter bitten, am geheimnisvollen „Confusion Hill“ anzuhalten.
<G-vec00213-002-s072><stop.anhalten><en> You can ask your guide to make a stop at the Gravity House and roadside attraction known as "Confusion Hill."
<G-vec00213-002-s073><stop.anhalten><de> Bei einigen Karussells gibt es Steuerelemente für Wiedergabe und Pause, um diese Animation anzuhalten oder fortzusetzen.
<G-vec00213-002-s073><stop.anhalten><en> On some carousels, there are play and pause controls to stop and resume the animation.
<G-vec00213-002-s074><stop.anhalten><de> Auf der Fahrt sehen sie einen Menschen mit einem Rucksack, der verzweifelt versucht, sie anzuhalten.
<G-vec00213-002-s074><stop.anhalten><en> On the way, they notice a man by the road begging them to stop the car, but they simply ignore him.
<G-vec00213-002-s075><stop.anhalten><de> Dies wird Sie auf jeden Fall dazu ermutigen, für eine lange Zeit anzuhalten und die wunderbaren Momente der Leidenschaft und des Sex zu genießen.
<G-vec00213-002-s075><stop.anhalten><en> For sure, this will encourage you to stop for a long time and taste the wonderful moments of passion and sex.
<G-vec00261-002-s034><persist.anhalten><de> Die Wirkung des Medikaments kann bis zu 36 Stunden anhalten.
<G-vec00261-002-s034><persist.anhalten><en> The effect of the drug can persist up to 36 hours.
<G-vec00261-002-s035><persist.anhalten><de> Wenn jedoch nach internationalen Standards solche Zustände wie Depression, Apathie, Schlafstörungen, Angst länger als zwei Wochen anhalten, kann auf Medikamente nicht verzichtet werden.
<G-vec00261-002-s035><persist.anhalten><en> However, according to international standards, if such conditions as depression, apathy, sleep disturbance, anxiety persist for more than two weeks, drugs can not be dispensed with.
<G-vec00261-002-s036><persist.anhalten><de> Es ist jedoch auch möglich, dass Schwellungen und schwarze Flecken bis zu drei Wochen anhalten, abhängig vom Organismus.
<G-vec00261-002-s036><persist.anhalten><en> It is possible that the swelling and bruising persist for up to three weeks but it depends on the body.
<G-vec00261-002-s037><persist.anhalten><de> Die Abweichung muss länger als die Zeit in diesem Objekt anhalten.
<G-vec00261-002-s037><persist.anhalten><en> The deviation must persist for longer than the time defined in this object.
<G-vec00261-002-s038><persist.anhalten><de> In den kommenden Monaten dürfte diese Dynamik insgesamt aber nicht anhalten, darauf weist das leicht abgekühlte Wirtschaftsklima hin.
<G-vec00261-002-s038><persist.anhalten><en> This momentum is unlikely to persist in the coming months, or so the slightly cooler economic climate would suggest.
<G-vec00261-002-s039><persist.anhalten><de> Wenn ihr von einem derartigen Flächenangriff getroffen werdet, dann werden einige der Effekte unausweichlich sein oder für einen längeren Zeitraum anhalten.
<G-vec00261-002-s039><persist.anhalten><en> If you do find yourself caught in one such AoE, some of the effects will be unavoidable or they will persist for a short time.
<G-vec00261-002-s040><persist.anhalten><de> Wenn diese Wirkungen anhalten oder sich verschlimmern, Benachrichtigen Sie sofort Ihren Arzt oder Apotheker.
<G-vec00261-002-s040><persist.anhalten><en> If any of these effects persist or worsen, tell your doctor or pharmacist promptly.
<G-vec00261-002-s041><persist.anhalten><de> Sie ist auch die richtige Ansprechsperson im Falle von Verletzungen oder Schmerzen, die anhalten und Dich beim Tanzen einschränken.
<G-vec00261-002-s041><persist.anhalten><en> She is also the person to go to and ask if you have some injuries or %persistent pain while% during dancing that does persist.
<G-vec00261-002-s042><persist.anhalten><de> Der Regen wird ziemlich lange anhalten.
<G-vec00261-002-s042><persist.anhalten><en> The rain will persist for a considerable time.
<G-vec00261-002-s043><persist.anhalten><de> Eine stärkere Erektion und ein größeres Potential und eine erhöhte sexuelle Spannung können viele Monate und Jahre nach dem Ende der Therapie anhalten, die von kaum einem anderen Medikament auf dem Markt bereitgestellt wird.
<G-vec00261-002-s043><persist.anhalten><en> Greater erection and greater potential and increased sexual tension can persist for many months and years after the end of therapy, which is not provided by virtually no other medicine on the market.
<G-vec00261-002-s044><persist.anhalten><de> Damit könnte der Abwertungsdruck auf den Yen selbst dann anhalten, wenn Japan sein quantitatives Lockerungsprogramm längst beendet hat.
<G-vec00261-002-s044><persist.anhalten><en> The pressure on the yen to devalue may continue to persist for longer well after Japan exists QE.
<G-vec00261-002-s045><persist.anhalten><de> Wenn die Symptome anhalten, ist es unbedingt erforderlich, die Einnahme von NONI-Saft zu beenden.
<G-vec00261-002-s045><persist.anhalten><en> When the symptoms persist, it is essential to stop taking NONI Juice.
<G-vec00261-002-s046><persist.anhalten><de> Wenn die Symptome anhalten, wird dies gemeinhin als Krankheitsschübe bezeichnet.
<G-vec00261-002-s046><persist.anhalten><en> When symptoms persist, it is commonly called a flare.
<G-vec00261-002-s047><persist.anhalten><de> Die Magie dieser Berührung ermöglicht es Ihnen, Ihren Orgasmus für eine lange Zeit zu kontrollieren, und die Aufregung wird vom Anfang bis zum Ende der Sitzung anhalten.
<G-vec00261-002-s047><persist.anhalten><en> The magic of this touch will allow you to control your orgasm for a long time, and the excitement will persist from the beginning to the very end of the session.
<G-vec00261-002-s048><persist.anhalten><de> Wenn aber solche Entzündungsreaktionen überschießen oder auch über einen längeren Zeitraum anhalten, könne dies zu typischen Zivilisationskrankheiten wie Gicht, Alzheimer-Demenz, Diabetes oder Arterienverkalkung beitragen.
<G-vec00261-002-s048><persist.anhalten><en> However, if such inflammatory reactions are excessive or if they persist for longer than necessary, this may contribute to common diseases of Western society, such as gout, Alzheimer's disease, diabetes or atherosclerosis.
<G-vec00261-002-s049><persist.anhalten><de> In Szenarien, in denen die Erektionsschwierigkeiten anhalten, vermeiden Menschen oft Sex, aber auch Entspannung und Kuscheln.
<G-vec00261-002-s049><persist.anhalten><en> Frequently in scenarios where erection difficulties persist, individuals avoid sex but additionally prevent relaxation and cuddles.
<G-vec00261-002-s050><persist.anhalten><de> - Wenn die Symptome nach 5 Tagen verschlechtern oder anhalten, sollten Sie Ihren Arzt aufsuchen.
<G-vec00261-002-s050><persist.anhalten><en> - If symptoms worsen or persist after 5 days, you should consult your doctor.
<G-vec00261-002-s051><persist.anhalten><de> Das BIBB geht davon aus, dass diese Trends auch im kommenden Jahr anhalten werden.
<G-vec00261-002-s051><persist.anhalten><en> BIBB expects these trends to persist over the coming year.
<G-vec00261-002-s052><persist.anhalten><de> Der Gegenwind durch die geldpolitische Straffung in den USA und den stärkeren Dollar dürfte zwar anhalten, doch ein Großteil der Abwärtsrisiken ist am Markt inzwischen eingepreist.
<G-vec00261-002-s052><persist.anhalten><en> While the headwind from U.S. monetary tightening and a stronger dollar will likely persist, much of the downside has now been priced into the market.
<G-vec00486-002-s019><pause.anhalten><de> Die eigentliche FlowHeater Verarbeitung wird dafür solange angehalten bis die Ausführung beendet wurde.
<G-vec00486-002-s019><pause.anhalten><en> The actual FlowHeater process will pause until the external processing is complete.
<G-vec00486-002-s020><pause.anhalten><de> Wenn die Diaschau angehalten wird, können Sie das Daumenrad <5> drehen, um ein anderes Bild anzuzeigen.
<G-vec00486-002-s020><pause.anhalten><en> During auto playback or pause, you can turn the <5> dial to view another image.
<G-vec00486-002-s021><pause.anhalten><de> Wenn ein Upload diese Geschwindigkeit (gezählt in Bytes pro Sekunde) im Gesamtdurchschnitt während der Übertragung überschreitet, wird die Übertragung angehalten, um die durchschnittliche Rate kleiner oder gleich dem Parameter-Wert zu halten.
<G-vec00486-002-s021><pause.anhalten><en> If an upload exceeds this speed (counted in bytes per second) on cumulative average during the transfer, the transfer will pause to keep the average rate less than or equal to the parameter value.
<G-vec00486-002-s023><pause.anhalten><de> OneDrive hält die Synchronisierung nicht automatisch an.Wenn Sie diese Einstellung deaktivieren oder nicht konfigurieren, wird die Synchronisierung automatisch angehalten, wenn der Stromsparmodus erkannt und eine Benachrichtigung angezeigt wird.
<G-vec00486-002-s023><pause.anhalten><en> OneDrive will not automatically pause syncing. If you disable or do not configure this setting, syncing will pause automatically when battery saver mode is detected and a notification will be displayed.
<G-vec00486-002-s024><pause.anhalten><de> Stop & Go: Der Druckvorgang kann jederzeit angehalten werden, um die Filamentfarbe zu wechseln.
<G-vec00486-002-s024><pause.anhalten><en> Stop & go: pause printing and change the colour of the filament when you want
<G-vec00486-002-s025><pause.anhalten><de> Wenn Sie einen Podcast 15 Tage lang nicht anhören oder darauf zugreifen, werden die Aktualisierungen angehalten.
<G-vec00486-002-s025><pause.anhalten><en> If you don't listen to or access a podcast subscription within 15 days, updates will pause.
<G-vec00486-002-s026><pause.anhalten><de> Sie sind der einzige Administrator, der die Standortverfolgung deaktivieren kann, sie kann jedoch von allen Administratoren angehalten werden.
<G-vec00486-002-s026><pause.anhalten><en> You're the only administrator who can disable location tracking, although all administrators can pause it.
<G-vec00486-002-s027><pause.anhalten><de> Mithilfe von Unterbrechungspunkten kann die Ausführung angehalten und im Einzelschrittbetrieb Schritt-für-Schritt auch innerhalb aufgerufener Prozeduren fortgeführt werden.
<G-vec00486-002-s027><pause.anhalten><en> Breakpoints allows to pause the execution and to continue step by step in single-step mode, even within called procedures.
<G-vec00486-002-s022><suspend.anhalten><de> Falls Sie ein vMotion-fähiges USB-Gerät mit einer virtuellen Maschine verbunden haben, die auf ESXi 6.5 ausgeführt wird, ist das Gerät im vSphere Web Client nicht sichtbar, nachdem Sie die virtuelle Maschine angehalten und wieder fortgesetzt haben.
<G-vec00486-002-s022><suspend.anhalten><en> If you connect a USB device that is enabled with vMotion to a virtual machine running on ESXi 6.5, the device is not visible in the vSphere Web Client after you suspend and then resume the virtual machine.
<G-vec00486-002-s023><suspend.anhalten><de> Maschinen werden zum Beispiel automatisch außerhalb der Bürostunden angehalten, wenn die Verbindung mindestens 10 Minuten lang getrennt war.
<G-vec00486-002-s023><suspend.anhalten><en> For example, machines will suspend automatically outside of office hours if users have been disconnected for at least ten minutes.
<G-vec00486-002-s024><suspend.anhalten><de> Ein Sortiervorgang, der sich nicht in der Zeileneingabephase befindet, kann nicht angehalten werden.
<G-vec00486-002-s024><suspend.anhalten><en> Cannot suspend a sort that is not in row input phase. Search by Google
<G-vec00486-002-s025><suspend.anhalten><de> Wenn Sie die App anhalten, wird auch das Update angehalten, oder die Installation wird nicht ausgeführt.
<G-vec00486-002-s025><suspend.anhalten><en> Suspending the app will also suspend the update or may cause it to fail.
<G-vec00579-002-s057><stop_by.anhalten><de> Sollte der Fahrer beispielsweise im Notfall keinerlei Reaktion zeigen, nutzt der Cadillac CT6 die ganze Bandbreite an Fahrassistenz-Technologien an Bord, um das Auto kontrolliert anzuhalten.
<G-vec00579-002-s057><stop_by.anhalten><en> In the limited event when a driver becomes completely unresponsive, the Cadillac CT6 utilizes the full capability of onboard driver assistance technologies to bring the car to a controlled stop.
<G-vec00579-002-s058><stop_by.anhalten><de> Die Zahlung kann in der Tat in vielen Fällen nur auf elektronischem Wege entrichtet werden, somit gibt es keine Möglichkeit, an der Mautstelle anzuhalten und bar zu bezahlen.
<G-vec00579-002-s058><stop_by.anhalten><en> In fact in many cases the payment can only be made electronically, so there is no possibility to stop at the toll booth and pay cash.
<G-vec00579-002-s059><stop_by.anhalten><de> Das Gesetz in Brünn schreibt vor, für Fußgänger anzuhalten, sobald sie auf die Straße treten, aber viele Fahrer tun dies nicht und Unfälle kommen vor.
<G-vec00579-002-s059><stop_by.anhalten><en> The law in Brno is to stop for pedestrians as soon as they step into the street, but many drivers don’t and accidents do occur.
<G-vec00579-002-s060><stop_by.anhalten><de> Um die Aktion langsamer abzuspielen oder die Aktion nach jedem Schritt anzuhalten, benutzen Sie den Menüpunkt "Ausführen-Optionen" im Bedienfeldmenü.
<G-vec00579-002-s060><stop_by.anhalten><en> To play the actions more slowly or to make the actions stop after each step try the "Playback Options" panel menu item. 9.
<G-vec00579-002-s061><stop_by.anhalten><de> Ein Beispiel ist der Fall eines [Meditations]-Jüngers, der versuchte (mit der „Kraft des Geistes“, wie er glaubte), einen Zug anzuhalten.
<G-vec00579-002-s061><stop_by.anhalten><en> An example is the case of a follower who attempted (with his "power of the mind" as he believed) to stop a train.
<G-vec00579-002-s062><stop_by.anhalten><de> Bei der klassischen Meditation wird der Geist beruhigt und versucht alle Gedankenregungen anzuhalten.
<G-vec00579-002-s062><stop_by.anhalten><en> In classical meditation, we try to calm the mind and stop all thought impulses.
<G-vec00579-002-s063><stop_by.anhalten><de> Treffen Sie Maßnahmen, um die Mitfahrer in Sicherheit zu bringen (helfen Sie Ihren Mitfahrern, die gefährliche Zone der Autobahn zu verlassen) und den Unfallort abzusichern (stellen Sie das Warndreieck in einem angemessenen Abstand auf; falls sie gezwungen sind, auf der Notspur anzuhalten, stellen sie es 150 Meter vor dem Wagen auf).
<G-vec00579-002-s063><stop_by.anhalten><en> Take measures ensure your passenger’s safety (help your passengers to leave the risky area of the motorway) and to safeguard the accident scene (place the breakdown triangle at a proper distance; if you are obliged to stop on the hard shoulder place triangle 150 metres ahead of the car)
<G-vec00579-002-s064><stop_by.anhalten><de> Um einen Garvorgang anzuhalten, reicht es aus, den Timer-Schaltknopf gegen den Uhrzeigersinn auf Null zu stellen.
<G-vec00579-002-s064><stop_by.anhalten><en> To stop a cooking cycle, turn the timer button clockwise or anticlockwise to zero.
<G-vec00579-002-s065><stop_by.anhalten><de> Da es zu spät war, den Wagen abzubremsen und anzuhalten, krachte der Wagen in die Leitplanke.
<G-vec00579-002-s065><stop_by.anhalten><en> As it was too late to brake and stop the car, the car ran in to the safety barrier.
<G-vec00579-002-s066><stop_by.anhalten><de> Bitte, wir brauchen Ihre Hilfe, um diese Maschine anzuhalten.
<G-vec00579-002-s066><stop_by.anhalten><en> Please, we need you to help us to stop the machine.
<G-vec00579-002-s067><stop_by.anhalten><de> Neben den feinsandigen Stränden, die immer noch ihren Scharm beibehalten konnten und dem kristallklaren Wasser des Mittelmeeres gibt es eine Vielzahl kultureller und sportlicher Aktivitäten, die häufig den Wunsch aufkommen lassen, einfach die Zeit anzuhalten.
<G-vec00579-002-s067><stop_by.anhalten><en> Besides the beaches that preserve their charm at any given moment with their fine sand and the crystal waters of the Mediterranean through which she shows her entire adorableness, with various cultural and sporting activities, Side is a heavenly resort, where you will wish that you could stop the time.
<G-vec00579-002-s068><stop_by.anhalten><de> 3. danach auf "Senden" klicken, um den Timer anzuhalten.
<G-vec00579-002-s068><stop_by.anhalten><en> 3. click “Submit” once completed to stop the timer.
<G-vec00579-002-s069><stop_by.anhalten><de> Wir deuten auf die Notwendigkeit hin, anzuhalten, sich neu zu orientieren und eine etwas distanzierte Sicht auf Situationen (oder Überzeugungen oder Personen) einzunehmen, die ihr bisher als vertraut angesehen habt.
<G-vec00579-002-s069><stop_by.anhalten><en> We state the need to stop, refocus, taking a somewhat distant view of a situation (or belief, or person) which you considered familiar.
<G-vec00579-002-s070><stop_by.anhalten><de> Einige Menschen sind in der Lage anzuhalten, aber sobald eine Person eine Gewinnen-Wette abschließt, wird er oder sie gewöhnlich vom Spielprogrammfehler angehakt.
<G-vec00579-002-s070><stop_by.anhalten><en> Some people have the ability to stop but once a person makes a winning bet, he or she is usually hooked by the gambling bug.
<G-vec00579-002-s071><stop_by.anhalten><de> Bei jeder Störung, die die Weiterfahrt verhindert, ist der Kunde verpflichtet anzuhalten, den KD darüber telefonisch zu verständigen und, falls möglich, das Fahrrad an nächst gelegener KRM-Station abzustellen.
<G-vec00579-002-s071><stop_by.anhalten><en> In case of any failure preventing further riding, the Customer is obliged to stop and notify the Customer Service Centre/BOK by phone and, if possible, escort the Bicycle to the nearest KRM Station.
<G-vec00579-002-s072><stop_by.anhalten><de> Sie können Ihren Reiseleiter bitten, am geheimnisvollen „Confusion Hill“ anzuhalten.
<G-vec00579-002-s072><stop_by.anhalten><en> You can ask your guide to make a stop at the Gravity House and roadside attraction known as "Confusion Hill."
<G-vec00579-002-s073><stop_by.anhalten><de> Bei einigen Karussells gibt es Steuerelemente für Wiedergabe und Pause, um diese Animation anzuhalten oder fortzusetzen.
<G-vec00579-002-s073><stop_by.anhalten><en> On some carousels, there are play and pause controls to stop and resume the animation.
<G-vec00579-002-s074><stop_by.anhalten><de> Auf der Fahrt sehen sie einen Menschen mit einem Rucksack, der verzweifelt versucht, sie anzuhalten.
<G-vec00579-002-s074><stop_by.anhalten><en> On the way, they notice a man by the road begging them to stop the car, but they simply ignore him.
<G-vec00579-002-s075><stop_by.anhalten><de> Dies wird Sie auf jeden Fall dazu ermutigen, für eine lange Zeit anzuhalten und die wunderbaren Momente der Leidenschaft und des Sex zu genießen.
<G-vec00579-002-s075><stop_by.anhalten><en> For sure, this will encourage you to stop for a long time and taste the wonderful moments of passion and sex.
<G-vec00198-002-s019><stop.anhalten><de> Stoppschilder zeigen an, dass Sie vollständig anhalten müssen, bevor Sie weiterfahren.
<G-vec00198-002-s019><stop.anhalten><en> Stop signs indicate that you must come to a complete stop before giving way.
<G-vec00198-002-s020><stop.anhalten><de> Wir mussten immer wieder anhalten und die Karte checken.
<G-vec00198-002-s020><stop.anhalten><en> We had to stop very often to check the map.
<G-vec00198-002-s021><stop.anhalten><de> Diese Route 75 hat viele Orte, wo man anhalten kann, um das Grassmeer oder die wilden Tiere zu sehen oder vielleicht sogar angeln kann.
<G-vec00198-002-s021><stop.anhalten><en> Route 75 has many rest areas where you can stop to view the sea of grass, to observe the wildlife or even to try your hand at fishing.
<G-vec00198-002-s022><stop.anhalten><de> Der Chirurg kann dann die Geschwindigkeit einstellen, mit der die Klinge durch das Gewebe bewegt wird, die Klinge anhalten oder die Klinge weg von dem Gewebe zurückholen.
<G-vec00198-002-s022><stop.anhalten><en> The surgeon may then adjust the speed at which the blade is moved through the tissue, stop the blade, or bring back the blade away from the tissue.
<G-vec00198-002-s023><stop.anhalten><de> Mit dem e-Pedal[[4]] haben sie alles – in nur einem Gaspedal: starten, beschleunigen, abbremsen und anhalten.
<G-vec00198-002-s023><stop.anhalten><en> The e-Pedal gives you a fun, easy way to drive using only the accelerator pedal to start, accelerate, decelerate, and stop.
<G-vec00198-002-s024><stop.anhalten><de> Wenn Sie sich entscheiden, bei Under Linden zu bleiben, werden Sie die Ruhe spüren, sobald Sie Ihr Auto auf unserem kostenlosen Parkplatz anhalten.
<G-vec00198-002-s024><stop.anhalten><en> When you decide to stay at Under Linden, you will feel the quietness the moment you stop your car at our free parking lot.
<G-vec00198-002-s025><stop.anhalten><de> Die Tradition des Jakobsweges besagt, dass die Pilger hier anhalten müssen, um auf das Glück anzustoßen.
<G-vec00198-002-s025><stop.anhalten><en> According to the tradition on the Camino de Santiago, pilgrims must stop at it to toast happiness. Linking to other Caminos
<G-vec00198-002-s026><stop.anhalten><de> Zuerst einige Minuten fahren, um den Motor aufzuheizen, dann anhalten.
<G-vec00198-002-s026><stop.anhalten><en> Drive for a few minutes to warm up your engine, and then stop.
<G-vec00198-002-s027><stop.anhalten><de> Permanent mussten wir anhalten, um Kühlflüssigkeit nachzufüllen und den heißgelaufenen Motor abzukühlen.
<G-vec00198-002-s027><stop.anhalten><en> We frequently had to stop to fill up cooling liquid and to cool down the hot engine.
<G-vec00198-002-s028><stop.anhalten><de> Idealerweise nehmen Sie sich ungefähr 14 Tage Zeit für diese Reise, aber es könnte auch schneller gehen, je nachdem, wie oft und wie lange Sie anhalten.
<G-vec00198-002-s028><stop.anhalten><en> Ideally, you would give yourself around 14 days for this trip, but it could be done in much less depending on how often and how long you stop for..
<G-vec00198-002-s029><stop.anhalten><de> Du trägst einen Beta-Anzug, der eine Fehlfunktion aufweist, durch die du den Fluss der Zeit zu verlangsamen, anhalten und umkehren kannst.
<G-vec00198-002-s029><stop.anhalten><en> Armed with the experimental Beta Suit, a malfunction has given you the ability to slow, stop, and reverse the flow of time itself.
<G-vec00198-002-s030><stop.anhalten><de> Polizei und Gendarmerie Kontrollpunkte auf der Straße sind etwas Alltägliches und du musst langsamer fahren oder sogar anhalten um darauf zu warten, durchgewinkt zu werden.
<G-vec00198-002-s030><stop.anhalten><en> Police and gendarmerie checkpoints are common along the routes and you must slow down or even stop and wait for them to wave you through.
<G-vec00198-002-s031><stop.anhalten><de> Wenn ich vorher noch mit der Idee gespielt hatte, die Überquerung nur mit der Solarzelle zu versuchen, war jetzt klar, dass ich auf den Kap Verden anhalten musste.
<G-vec00198-002-s031><stop.anhalten><en> While I had played with the idea of attempting the crossing on solar power alone, I now knew for sure that I needed to stop on the Cape Verdes.
<G-vec00198-002-s032><stop.anhalten><de> Wenn Sie nicht planen, einen Livekanal rund um die Uhr laufen zu lassen, sollten Sie den Kanal und die zugehörigen Programme anhalten, wenn sie nicht verwendet werden.
<G-vec00198-002-s032><stop.anhalten><en> If you don’t plan on running a 24x7 live channel, you should stop the channel and associated programs when they’re not being used.
<G-vec00198-002-s033><stop.anhalten><de> Mit dem Boot ist der nächstgelegene Hafen Skagway Alaska, der 2 Stunden von Whitehorse auf dem Klondyke Highway entfernt ist, oder Sie können auch in Anchorage anhalten.
<G-vec00198-002-s033><stop.anhalten><en> By boat the closest port is Skagway Alaska which is 2 hours away from Whitehorse on the Klondike Highway or you can also stop in Anchorage.
<G-vec00198-002-s034><stop.anhalten><de> Fahren Sie auf Lokalstraßen, können Ihnen Busfahrer an Haltestellen in jeder Ortschaft anhalten.
<G-vec00198-002-s034><stop.anhalten><en> If they run along local roads, the drivers can stop at a bus stop in any settlement.
<G-vec00198-002-s035><stop.anhalten><de> Falls Sie Einstellungen ändern möchten, müssen Sie zuvor mit Anhalten den crossTank-Server stoppen.
<G-vec00198-002-s035><stop.anhalten><en> If you would like to modify settings, it is necessary to click Stop to stop the crossTank Server first.
<G-vec00198-002-s036><stop.anhalten><de> Trotz der Warnung blieb er auf Hochtouren… Zum Glück konnte das letzte Fahrzeug auf einem Stück harten Sandes anhalten.
<G-vec00198-002-s036><stop.anhalten><en> Despite the warning, he remained in high gear …. Fortunately, the last vehicle was able to stop on a patch of hard sand.
<G-vec00198-002-s037><stop.anhalten><de> Der Spaß geht weiter mit jedem Mädchen, das den nackten Körper ihrer Freunde erforscht und genießt, bis sie so geil sind, dass sie anhalten und ins Schlafzimmer gehen müssen, damit sie sich leichter im Bett umeinander bewegen können.
<G-vec00198-002-s037><stop.anhalten><en> The fun continues with each gal exploring and enjoying her friends naked body until they are so horny they have to stop and head into the bedroom so they can more easily maneuver around each other in bed. Category: BODY KISSING
<G-vec00198-002-s456><stop.anhalten><de> Die Fernbuslinien halten auf der Südseite des Hauptbahnhofs.
<G-vec00198-002-s456><stop.anhalten><en> The bus stop is on the south side of the Central Station.
<G-vec00198-002-s457><stop.anhalten><de> Mike Rockenfeller konnte sich im Vorjahres-A4 des Audi Sport Team Rosberg mit einem guten Start vom dritten auf den zweiten Platz nach vorne schieben und bis zu seinem ersten Boxenstopp Vorjahressieger Paul Di Resta in Schach halten.
<G-vec00198-002-s457><stop.anhalten><en> After a good start from third place on the grid, Mike Rockenfeller in the year-old A4 of Audi Sport Team Rosberg was able to advance to second and keep last year’s winner Paul di Resta at bay up until his first pit stop.
<G-vec00198-002-s458><stop.anhalten><de> Auf allen Wegen bewegen Sie sich auf einer gut ausgebauten Bundesstraße fort und Sie haben den Komfort, dass die öffentlichen Verkehrsmittel direkt vor unserem Hotel in regelmäßigen Abständen halten.
<G-vec00198-002-s458><stop.anhalten><en> You also enjoy the convenience of having public transportation stop regularly right in front of our hotel.
<G-vec00198-002-s459><stop.anhalten><de> Alster und die vielen Sehenswürdigkeiten der City sind von diesem wunderschönen historischen Gebäude aus schnell zu Fuß zu erreichen; am nahegelegenen Jungfernstieg halten außerdem viele S- und U-Bahnen.
<G-vec00198-002-s459><stop.anhalten><en> The Alster and the city’s many sights can quickly be reached by foot from this beautiful historical building. Many S-Bahn and U-Bahn lines also stop at the nearby Jungfernstieg station.
<G-vec00198-002-s460><stop.anhalten><de> Sie halten auch am Old Burying Point, dem zweitältesten Begräbnisplatz des Landes, und sehen das legendäre Witch Trials Memorial, das zu Ehren der Opfer der Witchcraft Hysteria von 1962 errichtet wurde.
<G-vec00198-002-s460><stop.anhalten><en> You’ll also make a stop at Old Burying Point—the second oldest burial ground in the country—and see the iconic Witch Trials Memorial built to honor the victims of the 1962 Witchcraft Hysteria.
<G-vec00198-002-s461><stop.anhalten><de> Wo eine direkte Verbindung fehlt, halten die Skibusse (blau) und bringen Sie zum nächsten Spot.
<G-vec00198-002-s461><stop.anhalten><en> Where there isn't a direct link, the ski buses (blue) stop and take you to the next spot.
<G-vec00198-002-s462><stop.anhalten><de> Lokale Busse halten in nur 200 m Entfernung vom Guest House Ida, während Sie den Busbahnhof nach 1,5 km erreichen.
<G-vec00198-002-s462><stop.anhalten><en> Local buses stop 200 metres away, while the Main Bus Station is 1.5 km from Guest House Ida.
<G-vec00198-002-s463><stop.anhalten><de> Sandsoldaten halten zwar vor Yasuos Windmauer und Braums Unverwüstlich an, verschwinden aber nicht.
<G-vec00198-002-s463><stop.anhalten><en> Notes The Sand Soldiers will stop when encountering Wind Wall and Unbreakable during the charge.
<G-vec00198-002-s464><stop.anhalten><de> Bis dahin halten einige Fernbusse auch auf dem Bahnhofs-Vorplatz (roter Marker 2) und auf der gut 1 km entfernten Piazza Marina (roter Marker 3).
<G-vec00198-002-s464><stop.anhalten><en> Some additional shuttle buses and coaches stop in the railway station forecourt (red marker 2) and at Piazza Marina (red marker 3) which is approx. 1km away.
<G-vec00198-002-s465><stop.anhalten><de> Das Stadtzentrum erreichen Sie mit einer der zahlreichen Buslinien, die vor dem Andorra B&B halten.
<G-vec00198-002-s465><stop.anhalten><en> The city centre is reachable via one of several bus lines that stop in front of Andorra B&B.
<G-vec00198-002-s466><stop.anhalten><de> Am Bahnhof von Ora halten alle Regionalzüge.
<G-vec00198-002-s466><stop.anhalten><en> All regional trains stop at Ora station.
<G-vec00198-002-s467><stop.anhalten><de> Wir halten in der Quelle des Fluss Mina Clavero an.
<G-vec00198-002-s467><stop.anhalten><en> We stop where the Mina Clavero River starts.
<G-vec00198-002-s468><stop.anhalten><de> Öffentliche Busse halten in der Daliborova Straße, etwa 7 Minuten vom Hotel entfernt.
<G-vec00198-002-s468><stop.anhalten><en> Public buses stop in Daliborova Street, about 7 minutes from the hotel.
<G-vec00198-002-s469><stop.anhalten><de> Mit ihnen können Sie in das generell dem Verkehr verschlossene Zentrum der Kunststädte fahren und an den schönsten Panoramablicken halten.
<G-vec00198-002-s469><stop.anhalten><en> With them you will be able to enter art city centers normally closed to traffic and stop at the most beautiful panoramic spots.
<G-vec00198-002-s470><stop.anhalten><de> Halten Sie anschließend am Museum und sehen Sie eine Sammlung moderner Gemälde mit Werken von Dali, Casas, Picasso, Rusinol, Monet und vielen mehr, bevor Sie zurück nach Barcelona fahren.
<G-vec00198-002-s470><stop.anhalten><en> Then stop off at the museum to view a collection of modern paintings with works by Dali, Casas, Picasso, Rusinol, Monet, and more, before returning to Barcelona.
<G-vec00198-002-s471><stop.anhalten><de> Zuerst halten wir an der "Römer"-Brücke (ein Nachbau) bei Lavertezzo.
<G-vec00198-002-s471><stop.anhalten><en> Our first stop is at the "roman" bridge in Lavertezzo.
<G-vec00198-002-s472><stop.anhalten><de> Wir halten für ein Foto vor einem sehr kühlen Wasserfall.
<G-vec00198-002-s472><stop.anhalten><en> We stop for a photo in front of a very cool waterfall.
<G-vec00198-002-s473><stop.anhalten><de> Lokale Busse halten nur 50 m entfernt, vom Busbahnhof trennen Sie 600 m. Der Flughafen Tivat befindet sich 25 km von den Huter Apartments entfernt, der Flughafen Dubrovnik 30 km.
<G-vec00198-002-s473><stop.anhalten><en> The local buses stop just 165 feet away, while the Bus Station can be reached in 1,969 feet. Tivat Airport is 15.5 miles away, while Dubrovnik Airport is 18.6 miles from Huter Apartments.
<G-vec00198-002-s474><stop.anhalten><de> Kostenlose Skibusse halten 300 m entfernt.
<G-vec00198-002-s474><stop.anhalten><en> Free ski buses stop 300 metres away.
<G-vec00198-002-s475><stop.anhalten><de> Halten Sie den Server nicht sofort an.
<G-vec00198-002-s475><stop.anhalten><en> Do not immediately stop the server.
<G-vec00198-002-s476><stop.anhalten><de> Halten Sie an einer Holzhütte, wo Sie mit Hilfe Ihres Führers Feuer machen.
<G-vec00198-002-s476><stop.anhalten><en> Stop at a wooden hut where you will be making fire with help of your guide.
<G-vec00198-002-s477><stop.anhalten><de> Wenn Sie diese Prozedur im Zuge der Löschung eines Arbeitscomputerknotens aus der Tableau Server-Konfiguration (analog zur Beschreibung unter Entfernen eines Arbeitscomputerknotens) durchführen, halten Sie den Tableau Server erneut an, bevor Sie fortfahren.
<G-vec00198-002-s477><stop.anhalten><en> If you are performing this procedure as part of deleting a worker node from the Tableau Server configuration (as described in Remove a Worker Node) stop Tableau Server again before proceeding.
<G-vec00198-002-s478><stop.anhalten><de> - Halten sie an Raststätten und Aussichtspunkten an, machen Sie Fotos und teilen Sie das Erlebnis mit anderen, genießen Sie.
<G-vec00198-002-s478><stop.anhalten><en> - stop at rest and vantage points, take photographs and share your experience, enjoy yourself.
<G-vec00198-002-s479><stop.anhalten><de> Halten Sie einen sicheren Abstand bei der Beobachtung von Meereslebewesen, nähern Sie sich seitlich und halten Sie mit dem Propeller im Leerlauf an.
<G-vec00198-002-s479><stop.anhalten><en> Remembering to keep a safe distance from marine life, and if viewing, approach side-on and stop with propellers in neutral.
<G-vec00198-002-s480><stop.anhalten><de> Als nächstes halten Sie im Merlion Park und genießen die beeindruckende Aussicht auf die Marina Bay.
<G-vec00198-002-s480><stop.anhalten><en> Next, stop at the Merlion Park and enjoy the impressive views of Marina Bay.
<G-vec00198-002-s481><stop.anhalten><de> Auf dem Weg halten Sie am hölzernen Kloster von Shwe Yan Pyay, das schöne Schnitzereien und eine Sammlung von Buddha-Bildern beherbergt.
<G-vec00198-002-s481><stop.anhalten><en> Along the way, stop at the wooden Shwe Yan Pyay Monastery which features beautiful carvings and a collection of Buddha images.
<G-vec00198-002-s482><stop.anhalten><de> Halten Sie an vulkanischen Stränden und sehen Sie den Sonnenuntergang in Ia.
<G-vec00198-002-s482><stop.anhalten><en> Stop at volcanic beaches and experience an Oia sunset.
<G-vec00198-002-s483><stop.anhalten><de> Um die Protokolldateien zu verwerfen, halten Sie die Anwendung an, entfernen Sie die Protokolldateien aus dem Ordner %ProgramData%\Kaspersky Lab\ und starten Sie die Anwendung neu.
<G-vec00198-002-s483><stop.anhalten><en> To discard trace files, stop the application, remove the trace files from the %ProgramData%\Kaspersky Lab\ folder and restart the application.
<G-vec00198-002-s484><stop.anhalten><de> Halten Sie für ein paar Tage zu Hause, wird Sie begeistert.
<G-vec00198-002-s484><stop.anhalten><en> Stop for a few days at home, you will leave delighted.
<G-vec00198-002-s485><stop.anhalten><de> Nehmen Sie anschließend vor dem verglasten Sudhaus mit den gut sichtbaren Kupferkesseln, die rechtsseitig liegende Einfahrt: "Technik, HUBINET" und halten Sie sich rechts.
<G-vec00198-002-s485><stop.anhalten><en> Then, in front of the glazed brewhouse with the clearly visible copper kettle, take the entrance to the right: "Technik, HUBINET" and stop to the right.
<G-vec00198-002-s486><stop.anhalten><de> Drehen Sie das Einstellrad nach links, überspringen Sie die erste Zahl der Reihenfolge und halten Sie bei der zweiten Zahl an.
<G-vec00198-002-s486><stop.anhalten><en> Turn the dial to the left, pass the first number of the sequence and stop on the second number.
<G-vec00198-002-s487><stop.anhalten><de> Halten Sie als nächstes an der Dubai Mall, wo tausende Geschäfte mit tausenden Touristen und Einheimischen gefüllt sind.
<G-vec00198-002-s487><stop.anhalten><en> Stop at the Dubai Mall next, where there are thousands of shops filled with thousands of tourists and locals.
<G-vec00198-002-s488><stop.anhalten><de> Halten Sie an, um den atemberaubenden Urwald zu erkunden, und lassen Sie sich von unseren lokalen Führern alles über die Geschichte des Landes erzählen.
<G-vec00198-002-s488><stop.anhalten><en> Stop to explore stunning native forest and let our local guides tell you all about the history of the land.
<G-vec00198-002-s489><stop.anhalten><de> Am Tag der Abreise halten Sie an der Rezeption an, um Ihr Armband abgenommen zu bekommen und alle Hotelkarten abzugeben.
<G-vec00198-002-s489><stop.anhalten><en> On the day of departure, stop at reception to get your bracelet down and hand over all the hotel cards.
<G-vec00198-002-s490><stop.anhalten><de> Fahren Sie entlang der Küste, halten Sie an, um schwimmen zu gehen und das Grundfischen zu genießen.
<G-vec00198-002-s490><stop.anhalten><en> Ride along the coast, stop for having a swim and enjoy bottom fishing.
<G-vec00198-002-s491><stop.anhalten><de> Halten Sie für ein traditionelles brasilianisches Mittagessen an und machen Sie dann einen Spaziergang durch die historischen Straßen, die von architektonischen Meisterwerken aus verschiedenen Epochen gesäumt sind.
<G-vec00198-002-s491><stop.anhalten><en> Stop for a traditional Brazilian lunch, then take a walking tour of the historic streets lined with examples of architecture from different eras.
<G-vec00198-002-s492><stop.anhalten><de> Falls Sie sich in der Nähe von Zadar oder Šibenik aufhalten, halten Sie in der Marine Dalmacija, Sukošan an, um das slowenische Produkt Eminence „White Dreams“ zu buchen und die fabelhaften Inseln dieses Bereiches entdecken zu können.
<G-vec00198-002-s492><stop.anhalten><en> If you are staying close to Zadar or Šibenik, stop in marina Dalmacija, Sukošan, charter the slovenian domestic production full batten sailing boat Eminence 40 'White dreams' and explore fabulous islands of this area.
<G-vec00198-002-s493><stop.anhalten><de> Unterwegs halten Sie an, um den Hawa Mahal Palace of Winds zu sehen, das berühmteste Symbol von Jaipur.
<G-vec00198-002-s493><stop.anhalten><en> On the way, we stop at Fatehpur Sikri, the abandoned Mughal city.
<G-vec00199-002-s053><persist.anhalten><de> Wenn eine dieser Wirkungen anhält oder sich verschlechtert, informieren Sie unverzüglich Ihren Arzt oder Apotheker.
<G-vec00199-002-s053><persist.anhalten><en> If any of these effects persist or worsen, notify your doctor or pharmacist promptly.
