<G-vec00510-001-s094><blossom.blühen><de> Aber auch wenn es Menschen im Unternehmen gibt, die in der Arbeitszeit halt so ihre Pflicht erfüllen und in der Freizeit auf blühen, ist etwas faul im „ethischen Unternehmen“.
<G-vec00510-001-s094><blossom.blühen><en> Apart from that, something is rotten in an “ethical enterprise” if there are people who just do their duty during work hours and then really blossom in their leisure time.
<G-vec00510-001-s095><blossom.blühen><de> Freilich, blühen nur die erwachsenen Pflanzen auf 4-6 Jahr des Lebens.
<G-vec00510-001-s095><blossom.blühen><en> However, only adult plants for 4-6 year of life blossom.
<G-vec00510-001-s096><blossom.blühen><de> Frau Ye verglich die Fotos dieser Blumen mit denen in Berichten, die von Udumbaras handelten und kam zu dem Schluss, dass es sich bei diesen drei winzigen weißen Blumen tatsächlich um Udumbaras handelte - Blumen, die laut den buddhistischen Sutren nur alle dreitausend Jahre blühen.
<G-vec00510-001-s096><blossom.blühen><en> Ms. Ye compared the photos of these flowers with those of Udumbara and read related reports. She decided that these three tiny white flowers were indeed Udumbara - flowers that blossom once every three thousand years as described in Buddhist sutras.
<G-vec00510-001-s097><blossom.blühen><de> Deshalb ist es besser, im Verkauf die Samen der Zwergsorten zu suchen, sie nehmen die Plätze wenig ein, und blühen schon auf das zweite-dritte Jahr auf.
<G-vec00510-001-s097><blossom.blühen><en> Therefore it is better to look for seeds of dwarfish grades on sale, they take not enough place, and blossom for second or third.
<G-vec00510-001-s098><blossom.blühen><de> Dimethyl-Pentylamine-- ist Essenz Geranien blühen.
<G-vec00510-001-s098><blossom.blühen><en> Dimethyl-Pentylamine-- is extract of geranium blossom.
<G-vec00510-001-s099><blossom.blühen><de> Hier ganz exklusiv: Sie können bequem auf Augenhöhe betrachtet werden – nach der Überquerung des Triftbaches, nach ein paar Hundert Metern.Da so viele unterschiedliche Blumen blühen, ist die Artenvielfalt der Insekten und Falter ebenfalls enorm.
<G-vec00510-001-s099><blossom.blühen><en> A special feature along this walk: you can observe edelweiss comfortably at eye level, just a couple of hundred metres after crossing the Triftbach river.Because so many different flowers blossom here, the variety of butterflies and other insects is also enormous.
<G-vec00510-001-s100><blossom.blühen><de> Sonnenblumen blühen je nach Sorte zwischen Juli und Oktober.
<G-vec00510-001-s100><blossom.blühen><en> Depending on the variety, sunflowers blossom between July and October.
<G-vec00510-001-s101><blossom.blühen><de> Wir finden die vorteilhaften Eigenschaften der Orangen blühen und seinen Duft in diesem erstaunlichen Honig und parfümiert, in der Konditorei verwendet, sondern auch als Hilfsstoff für Grippesymptomen weil es scheint, dass die Kombination von Honig mit der Zitrusfrüchten antibakterielle Wirkung hat .
<G-vec00510-001-s101><blossom.blühen><en> We will find the beneficial properties of orange blossom and its fragrance, in this amazing honey and perfumed, used in confectionery, but also as an adjuvant in flu symptoms because it seems that the combination of honey with the citrus fruits has antibacterial effects .
<G-vec00510-001-s102><blossom.blühen><de> im Frühen Frühling auf den lehmhaltigen und lehmhaltig-Kreidböden der Abhänge der Hügel, der Schluchten, sowie auf meschach, die Ränder der Felder, in den trockenen Gräben, die Ränder der Wiesen, die ins Pflügen übergehen, erscheinen die gelben Blumen, die auf den Löwenzahn ähnlich sind, die bis zur Mitte Mai blühen.
<G-vec00510-001-s102><blossom.blühen><en> In the Early spring on clay and glinisto-cretaceous soils of slopes of hills, ravines, and also on mezhah, suburbs of fields, in dry ditches, suburbs of the meadows passing in a ploughed land, there are the yellow flowers similar on a dandelion which blossom to the middle of May.
<G-vec00510-001-s103><blossom.blühen><de> Es ist nötig zu berücksichtigen, dass krupnozwetkowyje die Formen mehr wählerisch, als melkozwetkowyje, wenn das feuchte und kalte Wetter kostet, so hören solche Petunien auf zu blühen.
<G-vec00510-001-s103><blossom.blühen><en> It is necessary to consider that krupnotsvetkovy forms more whimsical, than melkotsvetkovy if there is a wet and cold weather, such petunias cease to blossom.
<G-vec00510-001-s104><blossom.blühen><de> Sie blühen im Sommer, wenn die meisten Touristen dort sind.
<G-vec00510-001-s104><blossom.blühen><en> They blossom in the summer, in the tourist season.
<G-vec00510-001-s105><blossom.blühen><de> Wenn ich neue Zweige an einem Baum wachsen sehe, wenn ich Blumen blühen sehe, erinnere ich mich an den Alten Wang und an mein fernes Heimatland.
<G-vec00510-001-s105><blossom.blühen><en> When I see new branches grow on a tree, when I see flowers blossom, I'm reminded of Old Wang and my far away homeland.
<G-vec00510-001-s106><blossom.blühen><de> Eine Wirtschaft, deren Leistung im billigsten Herstellungspreis und niedrigsten Kosten wurzelt, kann nicht blühen und was nicht blüht, wird auch keine Früchte tragen können.
<G-vec00510-001-s106><blossom.blühen><en> An economy routed in the cheapest production costs and the lowest overall costs is not going to be able to blossom. And what does not blossom is not going to bear fruits.
<G-vec00510-001-s107><blossom.blühen><de> Die Wände mit ihren Bildern erscheinen bunter, die Blumen und Bäume auf dem Spielplatz blühen intensiver, und die Möbel sind “markiert”, XD.
<G-vec00510-001-s107><blossom.blühen><en> The wall with the pictures from the kids are colorful. The flowers and the trees on the playground blossom intensely . The furniture are “marked” XD
<G-vec00510-001-s108><blossom.blühen><de> Viele der Pflanzen haben sich an das trockene Klima der Inseln angepasst und blühen daher später als ihre Verwandten auf dem Festland.
<G-vec00510-001-s108><blossom.blühen><en> Many of the plants that have adapted to the islands' dry climate blossom later than typical mainland wildflowers.
<G-vec00510-001-s109><blossom.blühen><de> Unter unseren Füßen wurden lange Wurzeln in ein tiefes und weitreichendes Netz verwoben, um zu blühen und unsere Energiesphäre zu erheben in Richtung des lang erwarteten Goldenen Zeitalters.
<G-vec00510-001-s109><blossom.blühen><en> Beneath our feet long roots were becoming knitted into one deep and far-reaching web, to blossom and to uplift our energy sphere onto the long awaited Golden Age.
<G-vec00510-001-s110><blossom.blühen><de> Von März bis April blühen Pulmonaria angustifolia, gut aussehend, Tulpen und gelbe Gänseblümchen doronicum.
<G-vec00510-001-s110><blossom.blühen><en> From March-April blossom Pulmonaria angustifolia, handsome, tulips and yellow daisies doronicum.
<G-vec00510-001-s111><blossom.blühen><de> Die Bäume blühen schon, auch wenn noch viel Schnee auf den Bergen liegt, als die Beatus in Oberhofen ankommt.
<G-vec00510-001-s111><blossom.blühen><en> The trees blossom, though there is still plenty of snow on the mountains, as the Beatus arrives in Oberhofen.
<G-vec00510-001-s112><blossom.blühen><de> Trotz der Tatsache, dass seine Blumen blühen voll, oder absolut, das heiÃ t, all die StaubgefäÃ e und Stempel wird geworden Blütenblätter, und Pflanzen mit gefüllten Blüten produzieren keine Samen, durch Samen vermehrt gillyflower.
<G-vec00510-001-s112><blossom.blühen><en> Despite the fact that its flowers blossom full, or absolute, that is, all the stamens and pistils have become petals, and plants with double flowers do not produce seeds, propagated by seeds gillyflower.
<G-vec00510-001-s035><thrive.blühen><de> Ein Baum muss erst blühen, ehe er Früchte trägt.
<G-vec00510-001-s035><thrive.blühen><en> A tree often transplanted does not thrive.
<G-vec00510-001-s036><thrive.blühen><de> Es handelt sich nicht nur um die verwerfliche Anzahl von Verbrechen der Camorra, sondern auch um die Tatsache, daß die Gewalt leider immer mehr dazu neigt, zu einer verbreiteten Mentalität zu werden und dabei in die Struktur des gesellschaftlichen Lebens einzudringen, in den historischen Stadtvierteln des Zentrums sowie in den neuen und anonymen Peripherien, mit der Gefahr, vor allem die Jugend anzuziehen, die in Umfeldern aufwächst, in der die Illegalität, die Schattenwirtschaft und die Kultur des Improvisierens blühen.
<G-vec00510-001-s036><thrive.blühen><en> "It is not only a question of the deplorable crimes of the Camorra but also of the fact that violence unfortunately tends to breed a widespread mentality, creeping into the recesses of social life in the historical districts of the centre and in the new and anonymous suburbs, with the risk of attracting especially young people who grow up in contexts where unlawfulness, the ""black economy"" and the culture of ""fending for oneself"" thrive."
<G-vec00510-001-s037><thrive.blühen><de> Unser Land wird wieder blühen und gedeihen.
<G-vec00510-001-s037><thrive.blühen><en> Our country will thrive and prosper again.
<G-vec00510-001-s038><thrive.blühen><de> Darum, anstatt vollwertiger Kampfformationen blühen in der russischen Armee die Kaderformationen, Fallschirmspringer und allerlei SEKs auf.
<G-vec00510-001-s038><thrive.blühen><en> So, instead of full-fledged military units, paratroopers and other special forces of all kinds thrive in the Russian army.
<G-vec00510-001-s039><thrive.blühen><de> So kann der Park sogar im Winter blühen.
<G-vec00510-001-s039><thrive.blühen><en> It's a park that can thrive, even in winter.
<G-vec00510-001-s040><thrive.blühen><de> Besonders schön zeigt sich das Dorf im Sommer, wenn die bunten Rosen im Dorf blühen.
<G-vec00510-001-s040><thrive.blühen><en> Particularly atmospheric is the village in summer, when the colourful roses thrive in the village.
<G-vec00510-001-s041><thrive.blühen><de> Umgebung: Sucher blühen in sich ändernden Unternehmensumfeldern auf, die ein Element der Unvorhersagbarkeit haben, und sind erfolgreich durch ständige Überprüfung des Marktes, auf der Suche nach neuen Möglichkeiten.
<G-vec00510-001-s041><thrive.blühen><en> Environment: Prospectors thrive in changing business environments that have an element of unpredictability, and succeed by constantly examining the market in a search for new opportunities.
<G-vec00510-001-s113><blossom.blühen><de> Und ich glaube, dass Jesaja oder Jeremia – ich habe da einen Zweifel – sagt, dass der Herr wie die Blüte des Mandelbaums ist: er ist der Erste, der im Frühling blüht.
<G-vec00510-001-s113><blossom.blühen><en> And I believe that Isaiah or Jeremiah — I have doubt — says that the Lord comes like the almond flower, which is the first to blossom in spring.
<G-vec00510-001-s114><blossom.blühen><de> Entweder ihr blüht auf oder ihr verwelkt an dem Weinstock.
<G-vec00510-001-s114><blossom.blühen><en> Either you blossom or you wither on the vine.
<G-vec00510-001-s115><blossom.blühen><de> Ihr könnt sehr wohl aus diesem irdischen Garten gepflückt werden, bevor ihr blüht.
<G-vec00510-001-s115><blossom.blühen><en> You may very well get picked from this earthly garden before you blossom.
<G-vec00510-001-s116><blossom.blühen><de> Wenn die Pflanze ins prächtige Laub bekleidet ist, aber blüht, möglich nicht, haben Sie den Boden mit den salpetrigen Düngern viel zu stark gesättigt.
<G-vec00510-001-s116><blossom.blühen><en> If the plant is dressed in magnificent foliage, but does not blossom, perhaps, you too strongly sated the soil with nitrogenous fertilizers.
<G-vec00510-001-s117><blossom.blühen><de> In der Kultur blüht nicht.
<G-vec00510-001-s117><blossom.blühen><en> In culture does not blossom.
<G-vec00510-001-s118><blossom.blühen><de> Während der Trockenzeit wächst die Pflanze nur sehr langsam und befindet sich in einer Phase in der sie nicht blüht, aber mit den ersten Regenfällen beginnt sie wieder ihr vegetatives Wachstum und blüht auf.
<G-vec00510-001-s118><blossom.blühen><en> During the dry season the plant grows slowly and does not blossom, but with the first rains the plant resumes its vegetative phase and blossoms.
<G-vec00510-001-s119><blossom.blühen><de> Basel ist dafür besonders geeignet, weil Innovation dort blüht, wo Kulturen überlappen.
<G-vec00510-001-s119><blossom.blühen><en> Basel is especially suited for this because innovation tends to blossom where cultures overlap.
<G-vec00510-001-s120><blossom.blühen><de> Wie es schon gesagt war, blüht die Orchidee nicht, wenn alle Bedingungen des Inhalts nicht ertragen sind.
<G-vec00510-001-s120><blossom.blühen><en> As it was already told, the orchid does not blossom if all conditions of keeping are not sustained.
<G-vec00510-001-s121><blossom.blühen><de> Der Online-Handel und Geldverkehr blüht - an der Technik muss noch vieles verbessert und verfeinert werden, was ständige Nachfrage nach Fachkräften mit sich bringt.
<G-vec00510-001-s121><blossom.blühen><en> The online trade- and money transactions blossom – there only needs to be a lot more improvement done on the technique. All this brings about a constant demand for specialists.
