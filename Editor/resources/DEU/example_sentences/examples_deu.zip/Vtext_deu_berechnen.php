<G-vec00272-001-s152><charge.berechnen><de> Bei Stornierungen innerhalb von 7 Tagen nach Anreise berechnen wir die Hälfte der Gesamtfläche des Zimmers Gebühren für Ihre Reservierung.
<G-vec00272-001-s152><charge.berechnen><en> For cancellations received within 7 days of your scheduled arrival date, we will charge one-half of the total room charges for your reservation.
<G-vec00272-001-s153><charge.berechnen><de> Hunde sind bei uns willkommen, wir berechnen Ihnen CHF 15.00 pro Tag für Ihren Vierbeiner.
<G-vec00272-001-s153><charge.berechnen><en> Dogs are welcome in our hotel. We will charge CHF 15.00 per day & pet.
<G-vec00272-001-s154><charge.berechnen><de> Wir berechnen nur nach der Anzahl der gesendeten E-Mails.
<G-vec00272-001-s154><charge.berechnen><en> We only charge based on the amount of emails you send.
<G-vec00272-001-s155><charge.berechnen><de> "Von herauszufinden, die rate zu berechnen, die der Kunde für den Umgang mit komplizierten Umsatz-Steuer-ausfüllen von Formularen, es ist verständlich, dass Sie möchten, um zu schieben ""sales tax"" an die Nummer 39 auf Ihre riesige to-do-Liste."
<G-vec00272-001-s155><charge.berechnen><en> From figuring out which rate to charge which customer to dealing with complicated sales tax filing forms, it's understandable that you want to shove “sales tax” to number 39 on your massive to-do list.
<G-vec00272-001-s156><charge.berechnen><de> Wenn Sie am Flughafen ankommen und Ihr Gepäck mehr als Ihre Freigepäckgrenze wiegt, berechnen wir Ihnen eine Gebühr für jedes Kilogramm Übergewicht.
<G-vec00272-001-s156><charge.berechnen><en> If your hold luggage weighs more than your allowance when you arrive at the airport we charge you a fee for each 1kg of excess weight.
<G-vec00272-001-s157><charge.berechnen><de> (2) Entsteht uns durch die verspätete Abnahme ein Schaden, so sind wir berechtigt, pauschal 10 % des für die nicht abgenommene Leistung vereinbarten Entgelts als Schadensersatz zu berechnen, sofern uns der Kunde keinen niedrigeren Schaden nachweist.
<G-vec00272-001-s157><charge.berechnen><en> (2) If we suffer a loss due to the belated purchase, we are entitled to charge a lump sum of 10% of the value of the not rendered service as compensation, unless the customer can prove the damage is worth less.
<G-vec00272-001-s158><charge.berechnen><de> Versandkosten (inklusive gesetzliche Mehrwertsteuer) Lieferungen im Inland (Deutschland): Wir berechnen die Versandkosten pauschal mit 4,95 € pro Bestellung.
<G-vec00272-001-s158><charge.berechnen><en> Dispatch costs (inclusive of legally applicable VAT) Domestic deliveries (Germany): We charge a flat shipping fee of 4,95 € per order.
<G-vec00272-001-s159><charge.berechnen><de> Um Ihr Geld wieder Ihrem Konto gutzuschreiben, berechnen wir 10% Kosten mit einem Mindestbetrag von € 5,-.
<G-vec00272-001-s159><charge.berechnen><en> In this case we will transfer money to your account charging you 10% of the order’s amount and the minimum charge is € 5, -.
<G-vec00272-001-s160><charge.berechnen><de> Bei keiner Rückmeldung sehen wir uns leider gezwungen Ihnen ein day-use von EUR 20,– zu berechnen.
<G-vec00272-001-s160><charge.berechnen><en> Failure to notify us will result in a day-use charge of EUR 20.– .
<G-vec00272-001-s161><charge.berechnen><de> 3.2 Erhöhen sich bei Aufträgen, die später als vier Monate nach Abschluss ausgeliefert werden sollen, unsere Einkaufspreise und/oder der für uns gültige Lohn- und Gehaltstarif bis zur Ausführung des Auftrags, dürfen wir einen im Rahmen des prozentualen Anteils des Einkaufspreises und/oder der Lohnkosten am vereinbarten Preis verhältnismäßig entsprechend erhöhten Preis berechnen.
<G-vec00272-001-s161><charge.berechnen><en> 3.2 The following shall apply to orders which are to be delivered more than four months after conclusion of the contract: should our purchase prices and/or our applicable wages and salaries increase until the time the contract is executed, we shall be entitled to charge a higher price on a pro rata basis as a percentage of the purchase price and/or the labour costs.
<G-vec00272-001-s162><charge.berechnen><de> Und während App-Design-Firmen dir teure Entwickler- und Designergebühren berechnen würden, ist nichts davon mit dem Angebot von Phorest Salon Software erforderlich.
<G-vec00272-001-s162><charge.berechnen><en> While app design companies would charge you expensive developer and designer fees, none of that is required with Phorest Salon Software’s proposition.
<G-vec00272-001-s163><charge.berechnen><de> Wenn Sie später stornieren, als die Unterkunft als Termin festlegt oder nicht über die Stornierung der Reservierung informiert, kann die Unterkunft Ihnen einen Betrag berechnen, der in den meisten Fällen der Höhe der ersten Nacht entspricht.
<G-vec00272-001-s163><charge.berechnen><en> If you cancel later than the accommodation establishes as a deadline or does not notify of the cancellation of the reservation, the accommodation may charge you an amount which in most cases is equivalent to the amount of the first night.
<G-vec00272-001-s164><charge.berechnen><de> Unser Arrangement für eine Stornierung ist wie folgt: Wenn Sie mehr als zehn Tage im Voraus kündigen, wird nicht berechnen wir Ihnen nichts.
<G-vec00272-001-s164><charge.berechnen><en> Our arrangement for a cancellation is as follows: If you cancel more than ten days in advance, we will not charge you anything.
<G-vec00272-001-s165><charge.berechnen><de> Die Preise berechnen wir 1 € Kurtaxe pro Person pro Nacht.
<G-vec00272-001-s165><charge.berechnen><en> The prices we charge 1 EUR City tax per person per night.
<G-vec00272-001-s166><charge.berechnen><de> Wir berechnen eine einmalige Bearbeitungs- und Versandpauschale von 14,90 € pro Buchung.
<G-vec00272-001-s166><charge.berechnen><en> We charge a one time handling fee of € 14.90 per booking.
<G-vec00272-001-s167><charge.berechnen><de> Werden vom Kunden Abruftermine nicht eingehalten, so sind wir berechtigt, vier Wochen nach schriftlicher Ankündigung unter Hinweis auf die Folgen des unterbliebenen Abrufes, die Gesamtmenge vollständig zu liefern und zu berechnen.
<G-vec00272-001-s167><charge.berechnen><en> If release order dates are not adhered to by the customer then we are entitled to delivery and to charge in full four weeks after the written announcement with reference to the consequences of the release order which was not carried out.
<G-vec00272-001-s168><charge.berechnen><de> Bei Zahlungsverzug ist Firma TUNZE Aquarientechnik GmbH, berechtigt, Verzugszinsen in Höhe von 1 % über dem jeweiligen Eigendiskontsatz zu berechnen.
<G-vec00272-001-s168><charge.berechnen><en> In the event of delayed payment TUNZE Aquarientechnik GmbH is entitled to charge interest on arrears amounting to 1% above our rate of discount.
<G-vec00272-001-s169><charge.berechnen><de> Ein Vermerk, wie etwa „zuzüglich der üblichen Nebenspesen“ berechtigt den Spediteur, Sondergebühren und Sonderauslagen zusätzlich zu berechnen.
<G-vec00272-001-s169><charge.berechnen><en> A note, such as “plus the usual ancillary charges” entitles the freight forwarder, Special charges and to charge for supplements.
<G-vec00272-001-s170><charge.berechnen><de> Wir berechnen eine Versandkostenpauschale in Höhe von 2,95 Euro für alle Lieferungen innerhalb von Deutschland und unabhängig von der Anzahl der bestellten Artikel oder der Höhe des Bestellwertes.
<G-vec00272-001-s170><charge.berechnen><en> We charge a shipping fee of EUR 2.95 for all deliveries within Germany, regardless of the number of items ordered or the amount of the order value.
<G-vec00003-001-s097><estimate.berechnen><de> Berechnen wir die benötigte Zeit, die der Kühler benötigt, um eine stabile Temperaturlage zu erreichen.
<G-vec00003-001-s097><estimate.berechnen><en> Let us estimate the time required for the device to reach a steady thermal state.
<G-vec00003-001-s098><estimate.berechnen><de> Ich würde vorschlagen $16 für diese Situation zu berechnen.
<G-vec00003-001-s098><estimate.berechnen><en> I’d be inclined to estimate $16 or so for this situation.
<G-vec00003-001-s099><estimate.berechnen><de> Berechnen Sie Ihre Fahrtstrecke nach Zagora mit Hilfe der google Landkarte.
<G-vec00003-001-s099><estimate.berechnen><en> Estimate the distance of your trip using the google map.
<G-vec00003-001-s100><estimate.berechnen><de> Die vorherige Positionsvorhersage wird mit der durch das Radar gemessenen Position verglichen, um eine neue genauere Vorhersage für den nächsten Scan zu berechnen.
<G-vec00003-001-s100><estimate.berechnen><en> The latest track prediction is combined with the associated plot to provide a new, improved estimate of the next target state.
<G-vec00003-001-s101><estimate.berechnen><de> Außerdem müssen Sie die Endgröße des fertigen Produkts manuell berechnen, indem Sie die Randanschnittgröße von der Größe des Maskenrahmens subtrahieren.
<G-vec00003-001-s101><estimate.berechnen><en> In this workflow, you must manually estimate the finish size of the final product by subtracting bleed size from the size of the crop box.
<G-vec00345-001-s029><reckon.berechnen><de> Jetzt nach mehr als ein Jahrhundert und mit der Bestätigung von Tausenden der wissenschaftlichen Reports, gibt CO2 die bemerkenswerteste Antwort aller Nährstoffe in der Betriebsmasse, ist- normalerweise im kurzen Versorgungsmaterial und begrenzt fast immer für Fotosynthese…, welches das steigende Niveau des atmosphärischen CO2 eine allgemeinhin freie Prämie ist und gewinnt in der Größe mit Zeit, auf der alle wir während der absehbaren Zukunft berechnen können.
<G-vec00345-001-s029><reckon.berechnen><en> Now, after more than a century, and with the confirmation of thousands of scientific reports, CO2 gives the most remarkable response of all nutrients in plant bulk, is usually in short supply, and is nearly always limiting for photosynthesis … The rising level of atmospheric CO2 is a universally free premium, gaining in magnitude with time, on which we can all reckon for the foreseeable future.
<G-vec00345-001-s030><reckon.berechnen><de> Nestle-Stahl ist eine Kraft, zum mit im Feld der Herstellung zu berechnen und erstklassige Qualität 17-4PH ASTM A564 Stangen exportierend, ordnen Sie 630 Produkte AISI 630.
<G-vec00345-001-s030><reckon.berechnen><en> Nestle Steel is a force to reckon with in the field of manufacturing and exporting premium quality 17-4PH ASTM A564 Bars Grade 630 AISI 630 Products.
<G-vec00345-001-s031><reckon.berechnen><de> 23 so soll der Priester berechnen, was er gilt bis an das Halljahr; und soll desselben Tages solche Schätzung geben, daß sie dem HERRN heilig sei.
<G-vec00345-001-s031><reckon.berechnen><en> 23 then the priest shall reckon to him the worth of your valuation up to the Year of Jubilee; and he shall give your valuation on that day, as a holy thing to the Lord.
<G-vec00345-001-s032><reckon.berechnen><de> 23 so soll ihm der Priester den Betrag nach deiner Schatzung berechnen bis zum Jubeljahr, und er soll an demselben Tage den Schatzungswert geben, daß es dem HERRN geweiht sei.
<G-vec00345-001-s032><reckon.berechnen><en> 23 the priest shall reckon unto him the amount of thy valuation, unto the year of the jubilee; and he shall give thy valuation on that day, as holy to Jehovah.
<G-vec00345-001-s034><reckon.berechnen><de> 23 so soll der Priester berechnen, was er gilt bis zum Erlaßjahr, und er soll diese Summe am selben Tage geben, daß sie dem HERRN heilig sei.
<G-vec00345-001-s034><reckon.berechnen><en> 23 The priest shall reckon the price according to the number of years: unto the jubilee: and he that had vowed, shall give that to the Lord.
<G-vec00272-001-s171><charge.berechnen><de> Wenn Sie weniger als 48 Stunden im voraus, oder im Falle eines no-Show abbrechen, we.ll berechnet Ihnen den vollen Betrag.
<G-vec00272-001-s171><charge.berechnen><en> If you cancel less than 48 hours in advance, or in the case of a no show, we.ll charge you the full amount.
<G-vec00272-001-s172><charge.berechnen><de> Bei allen Buchungen von 7 Nächten oder mehr berechnet das Hotel eine nicht erstattbare Anzahlung in der Höhe von 3 Übernachtungen.
<G-vec00272-001-s172><charge.berechnen><en> For all reservations of 7 nights or more, the hotel will charge a non-refundable deposit equivalent to 3 nights.
<G-vec00272-001-s173><charge.berechnen><de> Bitte beachten Sie, dass das Hotel im Falle einer vorzeitigen Abreise den gesamten Betrag des gebuchten Aufenthalts berechnet.
<G-vec00272-001-s173><charge.berechnen><en> Please note that in case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s174><charge.berechnen><de> Bitte beachten Sie, dass für die Buchung des Frühstücks ein Aufpreis berechnet wird.
<G-vec00272-001-s174><charge.berechnen><en> Please note that extra charge will apply if guests upgrade the breakfast.
<G-vec00272-001-s175><charge.berechnen><de> Bitte beachten Sie, dass für die Nutzung der Sauna ein Aufpreis berechnet wird.
<G-vec00272-001-s175><charge.berechnen><en> Please note there is an extra charge for using the sauna.
<G-vec00272-001-s176><charge.berechnen><de> Reisen Sie vor dem gebuchten Zeitpunkt ab, berechnet das Hotel den Betrag für den gesamten Aufenthalt.
<G-vec00272-001-s176><charge.berechnen><en> In case of early departure, the hotel will charge the entire amount of the booked stay.
<G-vec00272-001-s177><charge.berechnen><de> Für den Zimmerservice und die Nutzung des Konferenzraums wird kein Aufschlag berechnet.
<G-vec00272-001-s177><charge.berechnen><en> Room service and use of the conference hall are free of any surplus charge.
<G-vec00272-001-s178><charge.berechnen><de> WLAN-Internetzugang; geräumige, helle Zimmer; ein Restaurant und eine Bar; eine wunderschöne Sommerterrasse mit Blick auf den See und den Garten; eine große, helle Lobby, Parkplatz (wird extra berechnet); 3 Konferenzräume mit Tageslichteinfall, Klimaanlage und Platz für bis zu 140 Teilnehmer.
<G-vec00272-001-s178><charge.berechnen><en> The hotel provides WiFi internet; spacious and bright rooms; a restaurant and a bar; a pretty terrace with fabulous views of the lake and gardens; a large, well-lit hall, outdoor parking (additional charge); 3 meeting rooms with natural light, air conditioning and a maximum capacity for up to 140 people.
<G-vec00272-001-s179><charge.berechnen><de> Stornierungen müssen bis spätestens 2 Wochen vor der Ankunft erfolgen, andernfalls werden Stornierungsgebühren berechnet.
<G-vec00272-001-s179><charge.berechnen><en> Cancellations must be made no later than 2 weeks prior to arrival or a cancellation charge applies.
<G-vec00272-001-s180><charge.berechnen><de> [1] Das Abheben von Bargeld über die DKB-Karten ist in der Praxis zu über 99 Prozent kostenlos, weil die DKB ihren Kunden keine Gebühren berechnet und die Gebühren der Fremdautomaten automatisch übernimmt.
<G-vec00272-001-s180><charge.berechnen><en> [1] Withdrawing cash through the DKB-card is in practice free of charge in more than 99 per cent of cases, because the DKB does not charge its customers any fees and takes the fees of foreign ATMs automatically.
<G-vec00272-001-s181><charge.berechnen><de> Bei Auslandsfahrten wird kein Nachtzuschlag berechnet.
<G-vec00272-001-s181><charge.berechnen><en> No additional night charge is made for journeys abroad.
<G-vec00272-001-s182><charge.berechnen><de> Bitte beachten Sie, dass die Unterkunft bei der Buchung eine Anzahlung von 25 % des Gesamtpreises berechnet.
<G-vec00272-001-s182><charge.berechnen><en> Please note that the property will charge a 25% deposit at the moment of booking.
<G-vec00272-001-s183><charge.berechnen><de> Wenn Sie eine Kredit- oder Debitkarte für die vollständige oder teilweise Finanzierung von internationalen persönlichen Zahlungen verwenden, berechnet PayPal eine Auslandsgebühr, die zwischen 2,9 % und 7,4 % zuzüglich einer festen Gebühr betragen kann.
<G-vec00272-001-s183><charge.berechnen><en> If you use a credit or debit card to fully or partially fund international personal payments, PayPal will charge a cross border fee, which can range from 2.9% to 7.4% plus an additional fixed fee.
<G-vec00272-001-s184><charge.berechnen><de> • Das Kreditkarteninstitut berechnet in der Regel bei Käufen in fremder Währung eine zusätzliche Gebühr (Fremdwährungszuschlag).
<G-vec00272-001-s184><charge.berechnen><en> • Credit card companies usually charge an additional fee for purchases in foreign currencies (foreign currency fee).
<G-vec00272-001-s185><charge.berechnen><de> mit Küchenzeile, Kaffeemaschine, Toaster, Wasserkocher,Terrasse, Bettwäsche ist vorhanden, Handtücher und Geschirrtücher sind selber mitzubringen oder zu mieten (wird extra berechnet).
<G-vec00272-001-s185><charge.berechnen><en> with kitchenette, coffee maker, toaster, electric kettle, terrace, bed linen is available, towels and tea towels are not themselves or rent (extra charge) .
<G-vec00272-001-s186><charge.berechnen><de> Bitte beachten Sie, dass die NürnbergMesse GmbH im Falle von Zuwiderhandlung eine Gebühr von EUR 800 berechnet.
<G-vec00272-001-s186><charge.berechnen><en> Please note that NÃ1⁄4rnbergMesse GmbH will charge a fee of EUR 800 in the event of a contravention of this.
<G-vec00272-001-s187><charge.berechnen><de> Bitte beachten Sie, dass ein Aufpreis berechnet wird und diese Anfragen der Verfügbarkeit unterliegen.
<G-vec00272-001-s187><charge.berechnen><en> Please note that there is an extra charge and these requests are based on availability.
<G-vec00272-001-s188><charge.berechnen><de> Pro Hund und Nacht wird ein Aufpreis berechnet.
<G-vec00272-001-s188><charge.berechnen><en> There will be an extra charge per dog per night.
<G-vec00272-001-s189><charge.berechnen><de> 2.7 Für die Abwicklung bloßer Lieferaufträge ohne Montage mit einem Rechnungswert bis zu 50,00 € netto berechnet ABASS GMBH eine Bearbeitungspauschale von 5,00 € zuzüglich Mehrwertsteuer.
<G-vec00272-001-s189><charge.berechnen><en> 2.7 For the processing of mere supply contracts without set-up with an invoice amount of 50,00€, ABASS GmbH shall charge a processing fee of 5,00€ plus value-added tax.
<G-vec00345-001-s035><reckon.berechnen><de> Berechnet, wieviel jeder gegeben hat.
<G-vec00345-001-s035><reckon.berechnen><en> """Reckon how much each one has given."
<G-vec00345-001-s036><reckon.berechnen><de> Manchmal werden, wenn ein Spieler fertig wird, für jedes Blatt mit 8 oder mehr Karten doppelte Strafpunkte berechnet.
<G-vec00345-001-s036><reckon.berechnen><en> Some reckon double penalty points for any hand with 8 or more cards when someone finishes.
<G-vec00169-001-s038><reclaim.berechnen><de> In bestimmten Fällen kann der Bauherr jedoch die berechnete Umsatzsteuer in den auf seinen Namen ausgestellten Rechnungen im Wert von 5 Millionen HUF (ca.
<G-vec00169-001-s038><reclaim.berechnen><en> In specific cases, however, the builder may reclaim the VAT content of invoices issued in its name up to HUF 5 million (approx.
<G-vec00169-001-s068><reclaim.berechnen><de> Im Falle einer Rechnung mit Ausweis der ausländischen Mehrwertsteuer kann die inländische Gesetzgebung im gegebenen Land die Geltendmachung der berechneten ausländischen Mehrwertsteuer im Rahmen des Vorsteuervergütungsverfahrens einschränken.
<G-vec00169-001-s068><reclaim.berechnen><en> With an invoice including foreign VAT, local legislation may restrict the amount of refundable VAT – through a foreign VAT reclaim – in the given country.
<G-vec00206-002-s019><compute.berechnen><de> FAHRTREGLER 32 So berechnen Sie den Stromverbrauch richtig.
<G-vec00206-002-s019><compute.berechnen><en> SPEED CONTROLLERS 32 How to compute current consumption properly.
<G-vec00206-002-s020><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Araguanã im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s020><compute.berechnen><en> To characterize how pleasant the weather is in Chinchinim throughout the year, we compute two travel scores.
<G-vec00206-002-s021><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Brooks im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s021><compute.berechnen><en> To characterize how pleasant the weather is in Brooks throughout the year, we compute two travel scores.
<G-vec00206-002-s022><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in El Arador im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s022><compute.berechnen><en> To characterize how pleasant the weather is in El Monte throughout the year, we compute two travel scores.
<G-vec00206-002-s023><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Yarkovo im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s023><compute.berechnen><en> To characterize how pleasant the weather is in Rūdiškės throughout the year, we compute two travel scores.
<G-vec00206-002-s024><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Ağrı Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s024><compute.berechnen><en> To characterize how pleasant the weather is at Davenport Municipal Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s025><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Osasco im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s025><compute.berechnen><en> To characterize how pleasant the weather is in Manhiça throughout the year, we compute two travel scores.
<G-vec00206-002-s026><compute.berechnen><de> Mit dem Interface Ray Acoustics können Sie die Trajektorien, die Phase und die Intensität der Schallwellen berechnen.
<G-vec00206-002-s026><compute.berechnen><en> With the Ray Acoustics interface, you can compute the trajectories, phase, and intensity of acoustic rays.
<G-vec00206-002-s027><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Pablo L. Sidar im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s027><compute.berechnen><en> To characterize how pleasant the weather is in Cienfuegos throughout the year, we compute two travel scores.
<G-vec00206-002-s028><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Barstow Daggett County Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s028><compute.berechnen><en> To characterize how pleasant the weather is at Edwards County Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s029><compute.berechnen><de> Ein Kernaspekt unserer Methode im Vergleich zu anderen Methoden ist, dass wir nicht nur einen standardisierten Notendurchschnitt berechnen sondern standardisierte Noten für die einzelnen Prüfungen erstellen.
<G-vec00206-002-s029><compute.berechnen><en> A key feature as compared to other methods to standardize grades is that we do not only compute a standardized grade point average (GPA) but also provide standardized grades at the level of individual exams.
<G-vec00206-002-s030><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Ayapa im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s030><compute.berechnen><en> To characterize how pleasant the weather is in Kayan throughout the year, we compute two travel scores.
<G-vec00206-002-s031><compute.berechnen><de> Sie beherrschen die Operationen der Vektorrechnung und deren Anwendung in der linearen Geometrie; sie kennen das Lösungsverhalten linearer Gleichungssysteme und können die Lösungen berechnen; sie beherrschen das grundlegende Rechnen mit Matrizen und Determinanten einschließlich der Bestimmung von Eigenwerten und Eigenvektoren.
<G-vec00206-002-s031><compute.berechnen><en> They have mastered the operations of vector algebra and their applications to linear geometry; they know the behaviour of the solutions of systems of linear equations and are able to compute the solutions; they can do basic calculations with matrices and determinants including finding eigenvalues and eigenvectors.
<G-vec00206-002-s032><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Gobernador Edgardo Castello Airport im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s032><compute.berechnen><en> To characterize how pleasant the weather is at Redding Municipal Airport throughout the year, we compute two travel scores.
<G-vec00206-002-s033><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter am Gioia Del Colle im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s033><compute.berechnen><en> To characterize how pleasant the weather is at Gioia Del Colle throughout the year, we compute two travel scores.
<G-vec00206-002-s034><compute.berechnen><de> Für den Fall, dass die zugehörigen Daten eine Grundgesamtheit angeben, sollten Sie die Standardabweichung mit der Funktion STABWNA berechnen.
<G-vec00206-002-s034><compute.berechnen><en> If your data represents the entire population, then compute the standard deviation using STDEVP.
<G-vec00206-002-s035><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Huaranchal im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s035><compute.berechnen><en> To characterize how pleasant the weather is in Tarxien throughout the year, we compute two travel scores.
<G-vec00206-002-s036><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Calatañazor im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s036><compute.berechnen><en> To characterize how pleasant the weather is in Kirchhundem throughout the year, we compute two travel scores.
<G-vec00206-002-s037><compute.berechnen><de> Um zu beschreiben, wie angenehm das Wetter in Tepango im Verlauf des Jahres ist, berechnen wir zwei Reisebewertungen.
<G-vec00206-002-s037><compute.berechnen><en> To characterize how pleasant the weather is in Tapalpa throughout the year, we compute two travel scores.
<G-vec00230-002-s152><charge.berechnen><de> Cathay Pacific berechnet für die Abgabe eines Angebots keine Buchungs- oder Kartengebühren.
<G-vec00230-002-s152><charge.berechnen><en> Cathay Pacific does not charge any booking fees or card fees for making an offer.
<G-vec00230-002-s153><charge.berechnen><de> Gästerichtlinien Bitte beachten Sie, dass für Gäste, die nicht auf der ursprünglichen Buchungsbestätigung aufgeführt sind, beim Check-in eine Zusatzgebühr berechnet wird.
<G-vec00230-002-s153><charge.berechnen><en> Please note that if guests check-in with extra person not mentioned on the original booking, the additional charge will be applied.
<G-vec00230-002-s154><charge.berechnen><de> Unsere Partnerbank, die FinTech Group Bank AG, berechnet für zusätzliche Kontodienstleistungen und Inaktivität möglicherweise Gebühren.
<G-vec00230-002-s154><charge.berechnen><en> Our partner bank, FinTech Group Bank AG, may charge fees for additional account services and account inactivity.
<G-vec00230-002-s155><charge.berechnen><de> Erst wenn Sie eine Buchung bestätigt haben, berechnet TUI Villas eine Vermittlungsprovision.
<G-vec00230-002-s155><charge.berechnen><en> TUI Villas will only charge a commission when you have confirmed a booking.
<G-vec00230-002-s156><charge.berechnen><de> Bitte beachten Sie, dass bei Zahlungen mit Kreditkarten von Visa oder Mastercard eine Gebühr von 1,4 % und bei Zahlungen mit Kreditkarten von American Express eine Gebühr von 3,3 % berechnet wird.
<G-vec00230-002-s156><charge.berechnen><en> Please note that there is a 1.4% charge when you pay with a Visa or MasterCard credit card and a 3.3% charge when you pay with an American Express credit card.
<G-vec00230-002-s157><charge.berechnen><de> Jedes Jahr am Ende einer Vertragslaufzeit berechnet Ihre Miet-/Reinigungsfirma Ihnen einen Betrag für den natürlichen Schwund an Servietten.
<G-vec00230-002-s157><charge.berechnen><en> Every year or at the end of a contract period, the linen lease company/laundry firm will do a settlement and charge you for the napkins that you have not returned.
<G-vec00230-002-s158><charge.berechnen><de> Die Plattform berechnet keine Transaktionsgebühr und bittet Sie, einen freien Betrag zu kippen.
<G-vec00230-002-s158><charge.berechnen><en> The platform does not charge a transaction fee and will solicit you to tip a free amount.
<G-vec00230-002-s159><charge.berechnen><de> Wenn Sie eine internationale persönliche Zahlung mithilfe Ihres PayPal-Guthabens oder Bankkontos überweisen oder empfangen, berechnet PayPal eine Auslandsgebühr, die zwischen 0,5 % und 2 % des Zahlungsbetrags betragen kann.
<G-vec00230-002-s159><charge.berechnen><en> If you send or receive an international personal payment using your PayPal balance or bank account, PayPal will charge a cross border fee, which can range from 0.5% to 2% of the payment amount.
<G-vec00230-002-s160><charge.berechnen><de> Für jedes Kind von 12 Jahren bis 16 Jahren werden pro Übernachtung € 40,00 inklusive Frühstück berechnet.
<G-vec00230-002-s160><charge.berechnen><en> For children from 12-16 years we charge € 40 per nights including breakfast.
<G-vec00230-002-s161><charge.berechnen><de> Jede weitere Minute wird mit 1,00 Euro berechnet.
<G-vec00230-002-s161><charge.berechnen><en> For each additional minute we charge 1 Euro.
<G-vec00230-002-s162><charge.berechnen><de> 4.We berechnet den Käuferselbstkostenpreis von Ersatzteilen über 2 Jahren hinaus und liefert langfristigen technischen Führer.
<G-vec00230-002-s162><charge.berechnen><en> 4.We will charge the buyer cost price of spare parts beyond 2 years and provide long-term technical guide.
<G-vec00230-002-s163><charge.berechnen><de> Im Falle von Privatlocations ist Johannes Adler bei der Erstbesichtigung immer anwesend und berechnet diese stundenweise.
<G-vec00230-002-s163><charge.berechnen><en> In the case of private locations we always accompany the first inspection and charge it by hours.
<G-vec00230-002-s164><charge.berechnen><de> In diesem Fall wird eine Zusatzgebühr berechnet.
<G-vec00230-002-s164><charge.berechnen><en> An extra charge is applicable in this case.
<G-vec00230-002-s165><charge.berechnen><de> Reeltastic Casino berechnet keine Gebühren für Auszahlungen.
<G-vec00230-002-s165><charge.berechnen><en> Reeltastic Casino does not charge a fee for processing withdrawals.
<G-vec00230-002-s166><charge.berechnen><de> Für zwei Erwachsene und zwei Kinder in der Hauptsaison werden 295 Euro berechnet – alle anderen Tarife liegen dazwischen.
<G-vec00230-002-s166><charge.berechnen><en> For two adults and two children in the high season we charge 295 Euro – all other rates are in between.
<G-vec00230-002-s167><charge.berechnen><de> Wenn Sie Ihre Reservierung nach dieser Zeit stornieren oder am Anreisetag nicht in der Unterkunft erscheinen, berechnet die Unterkunft 30,00% des Buchungswerts.
<G-vec00230-002-s167><charge.berechnen><en> If you cancel your reservation after this time or you do not show up at the property on the day of arrival, the property will charge 30.00% of the booking value.
<G-vec00230-002-s168><charge.berechnen><de> Wenn Sie Ihre Reservierung nach dieser Zeit stornieren oder am Anreisetag nicht in der Unterkunft erscheinen, berechnet der Gast 50% des Buchungswertes.
<G-vec00230-002-s168><charge.berechnen><en> If you cancel your reservation after this time or you do not show up at the property on the day of arrival, the guest will charge 50.00% of the booking value.
<G-vec00230-002-s169><charge.berechnen><de> Strom wird bei 6 Baht pro kw, Wasser bei 60 Baht pro m³ berechnet.
<G-vec00230-002-s169><charge.berechnen><en> Electricity is charge of 6 Baht kWp, water is 60 Baht per m³.
<G-vec00230-002-s170><charge.berechnen><de> Sofern Germania aufgrund der vertraglichen Vereinbarung die Kosten der Verpackung trägt, berechnet der Lieferant Germania diese Kosten zum Selbstkostenpreis.
<G-vec00230-002-s170><charge.berechnen><en> If Germania bears the costs of the packaging on the basis of a contractual arrangement, the supplier shall charge Germania for these costs at cost price.
<G-vec00322-002-s168><calculate.berechnen><de> Der Programmierer der Windows-Version, Thomas F. Carroll, half dem Programmierer der Mac-Version, die Taipan-Statistiken zu berechnen.
<G-vec00322-002-s168><calculate.berechnen><en> The Windows programmer, Thomas F. Carroll helped the Classics For X programmer to calculate the Taipan statistics.
<G-vec00322-002-s169><calculate.berechnen><de> EtherNet/IP-Kapazitätstool – Die von einem vorgeschlagenen EtherNet/IP™-Netzwerk verwendeten Ressourcen berechnen.
<G-vec00322-002-s169><calculate.berechnen><en> EtherNet/IP Capacity Tool — Calculate resources used by a proposed EtherNet/IP™ network.
<G-vec00322-002-s170><calculate.berechnen><de> Die Wissenschaft kann die Zeit null berechnen, das war der Big Bang.
<G-vec00322-002-s170><calculate.berechnen><en> Science can calculate time zero, which was the Big Bang.
<G-vec00322-002-s171><calculate.berechnen><de> Die Signale werden von GPS-Geräten, wie beispielsweise Satellitennavigationsgeräten, empfangen und dazu verwendet, die exakte Position, die Geschwindigkeit des Empfängers sowie die genaue Zeit am Standort des Empfängers zu berechnen.
<G-vec00322-002-s171><calculate.berechnen><en> The signals are obtained by GPS receivers, such as navigation devices and are used to calculate the exact position, speed and time at the vehicles location.
<G-vec00322-002-s172><calculate.berechnen><de> Sie sammelt Job-Protokolle und ist in der Lage, automatisch die Kosten über einen konkreten Auftrag oder über einen längeren Zeitraum zu berechnen.
<G-vec00322-002-s172><calculate.berechnen><en> It collects job logs and is able to automatically calculate costs for a specific job, or over a longer period of time.
<G-vec00322-002-s173><calculate.berechnen><de> Wenn Sie Barcodesoft Code 11 zum Drucken von Barcodes verwenden, verwenden Sie unseren Encoder, um die Prüfsumme zu berechnen.
<G-vec00322-002-s173><calculate.berechnen><en> If you use Barcodesoft EAN13 fonts to print bar code, please use our Encoder to calculate checksum for you.
<G-vec00322-002-s174><calculate.berechnen><de> Im Infobrief 167 vor einem Jahr wurde gezeigt, wie man mit ZAR1+ die Zahnradpaarung für Exzenter-Abwälzgetriebe aus außen- und innenverzahntem Zahnrad berechnen kann.
<G-vec00322-002-s174><calculate.berechnen><en> In the newsletter 167 one year ago was shown how to calculate externally and internally toothed gear wheel for an eccentric gear by means of ZAR1+.
<G-vec00322-002-s175><calculate.berechnen><de> Mit dieser Plattform können Anwender zudem sehen, welche Vorteile eine Ergänzung neuer Technologien und Ansätze bringen könnte, indem sie ihre eigenen Daten nutzen, um die Möglichkeit zu bewerten und die Kapitalrendite zu berechnen.
<G-vec00322-002-s175><calculate.berechnen><en> It will also give users the ability to see what benefits the addition of new technologies and approaches could bring, using their own data to assess the opportunity and calculate return on investment.
<G-vec00322-002-s176><calculate.berechnen><de> Auf der Webseite können Sie die Blindwiderstände zweier Spulen, zweier Kondensatoren oder eines Kondensators zusammen mit einer Spule berechnen.
<G-vec00322-002-s176><calculate.berechnen><en> On this webpage you can calculate reactances with two coils, two capacitors and a capacitor and a coil.
<G-vec00322-002-s102><estimate.berechnen><de> Es ist also vorher wichtig zu berechnen, wie viel Spachtelmasse für die Reparatur notwendig ist.
<G-vec00322-002-s102><estimate.berechnen><en> When you use Powder Filler it is important to estimate how much you need to use and mix this amount.
<G-vec00322-002-s103><estimate.berechnen><de> Teilprojekt I verfolgt die Ziele, für das Gesamtsystem des nichtenergetischen Verbrauchs in Deutschland im Jahr 1995 die wesentlichen Stoffströme zu erfassen, den Energieeinsatz in den Bereichen der Produktion und der Abfallwirtschaft (inklusive Transportleistungen) zu quantifizieren und die CO2-Emissionen zu berechnen (bedingt durch den Energieeinsatz, die prozeßbedingten Stoffverluste und die Abfallverbrennung).
<G-vec00322-002-s103><estimate.berechnen><en> The goals of Subproject I are to make an inventory of the material flows for the total system of non-energy use in Germany in 1995, to quantify the energy requirements in the areas of production and waste management (including transport) and to estimate the CO2 emissions released by the system (from energy use, material losses of the processes and waste incineration).
<G-vec00322-002-s104><estimate.berechnen><de> Nutzen Sie den TEI-Rechner, um Ihre Vorteile zu berechnen.
<G-vec00322-002-s104><estimate.berechnen><en> And try the TEI calculator to estimate your own benefits.
<G-vec00322-002-s105><estimate.berechnen><de> Berechnen Sie zusätzlich 1 bis 3 Tage zu Ihrer Lieferschätzung, um die voraussichtliche Gesamtlieferzeit zu erhalten.
<G-vec00322-002-s105><estimate.berechnen><en> Add 1-3 business days to your shipping estimate for total estimated delivery time.
<G-vec00322-002-s106><estimate.berechnen><de> Unsere Fachleute berechnen die ganze Technologie vom Grundsteinlegen genau für Ihr Projekt, sowie das Dach und das Material nach Ihrer Wahl und leisten fachgemäß diese Arbeiten.
<G-vec00322-002-s106><estimate.berechnen><en> Our specialists will work out a foundation laying technology specially for your project, prepare a roof estimate with the material of your choice, and execute all these works professionally.
<G-vec00322-002-s107><estimate.berechnen><de> Diese berechnen anhand einer Reihe von HDR-Bildern (High Dynamic Range) des Studios ein Modell der Studiobeleuchtung.
<G-vec00322-002-s107><estimate.berechnen><en> These tools estimate a model of the studio lighting by using a set of HDR images (high dynamic range) of the studio.
<G-vec00322-002-s108><estimate.berechnen><de> In diesem Abschnitt können Sie Ihren Aufenthalt berechnen.
<G-vec00322-002-s108><estimate.berechnen><en> In this section you can receive an estimate for your stay.
<G-vec00322-002-s109><estimate.berechnen><de> Berechnen Sie die Zustelldauer und -kosten für Ihre Sendung mit unserem Online-Rechner.
<G-vec00322-002-s109><estimate.berechnen><en> Easily estimate your shipment’s transit time and cost with our online calculator.
<G-vec00322-002-s110><estimate.berechnen><de> Bei dieser Methode fügt der Rechner 266 Tage (38 Wochen) hinzu, um den voraussichtlichen Geburtstermin zu berechnen.
<G-vec00322-002-s110><estimate.berechnen><en> Using this method, the calculator will add 266 days (38 weeks) to estimate your due date.
<G-vec00322-002-s111><estimate.berechnen><de> Die Taktzeit zu kennen hilft dir den Vorgang der Bereitstellung deiner Dienstleistung und das Resultat eines Prozesses/ einer Software zu berechnen.
<G-vec00322-002-s111><estimate.berechnen><en> Learn more... Knowing Takt time helps you to estimate your service delivery process and process/software outcome.
<G-vec00322-002-s112><estimate.berechnen><de> Sein Paper erklärt, wie der Wasserfußabdruck genutzt werden kann, um den Wasserverbrauch für die Herstellung von Biokraftstoffen in Deutschland zu berechnen.
<G-vec00322-002-s112><estimate.berechnen><en> The paper, entitled "Germany’s Water Footprint of Transport Fuels," details how the water footprint indicator can be used to estimate the water resource use necessary to produce fuels in Germany under the requirements of the EU Biofuels Directive.
<G-vec00322-002-s113><estimate.berechnen><de> Wir empfehlen Ihnen, die Versandkosten auf der Seite "Warenkorb" zu berechnen, bevor Sie Ihre Bestellung bezahlen.
<G-vec00322-002-s113><estimate.berechnen><en> Before proceeding to check-out, you can get a shipping estimate in the "Shopping cart" section.
<G-vec00347-002-s133><charge.berechnen><de> Beispiel Wenn Sie beispielsweise 150 € für Ihre Veranstaltung berechnen, kostet die Nutzung unseres Zahlungsmoduls: 150 * 0,016 = 2,40 € (ohne MwSt).
<G-vec00347-002-s133><charge.berechnen><en> Example For example, you charge DKK 500 for your event, you pay the following to use our payment module: 500 * 0.016 = 8 DKK ex.
<G-vec00347-002-s134><charge.berechnen><de> Bei Übernachtungen kürzer als 2 Nächte berechnen wir pro Person einen Zuschlag von 7,50 €.
<G-vec00347-002-s134><charge.berechnen><en> For overnight stays shorter than 2 nights we charge a surcharge of € 7.50 per person.
<G-vec00347-002-s135><charge.berechnen><de> D: nach Deutschland und in die Schweiz berechnen wir eine Pauschale von 7,00 Euro.
<G-vec00347-002-s135><charge.berechnen><en> GER: For mailing to Germany and Switzerland the flat charge for packaging and mailing costs is Eur 7,00.
<G-vec00347-002-s136><charge.berechnen><de> Bei Überschreiten der vereinbarten Zahlungsfristen müssen wir Mahn- und Bearbeitungsgebühren berechnen.
<G-vec00347-002-s136><charge.berechnen><en> If the period allowed for payment is exceeded, we must charge reminder and handling fees.
<G-vec00347-002-s137><charge.berechnen><de> Hunde und Katzen sind willkommen: wir berechnen € 9,00 pro Tag ohne Futter.
<G-vec00347-002-s137><charge.berechnen><en> Dogs and cats are welcome: we charge € 9.00 per day excluding food.
<G-vec00347-002-s138><charge.berechnen><de> § 4.1 Für die Lieferung innerhalb Deutschlands berechnen wir pauschal 4,95 Euro pro Bestellung für den Standardversand.
<G-vec00347-002-s138><charge.berechnen><en> § 4.1 For delivery within Germany we charge a flat rate of € 4.95 per order for standard delivery.
<G-vec00347-002-s139><charge.berechnen><de> Für die Reservierung berechnen wir keine Gebühren und bieten Gruppen Rabatte.
<G-vec00347-002-s139><charge.berechnen><en> We do not charge any booking fees, groups may get discounts.
<G-vec00347-002-s140><charge.berechnen><de> Für den uns entstehenden Bearbeitungsaufwand sind wir berechtigt, dem Lieferanten –zuzüglich Verpackung und Versendungsauslagen- eine Pauschale von 10 Euro zu berechnen.
<G-vec00347-002-s140><charge.berechnen><en> We have the right to charge the supplier a standard rate of 10 Euros – plus packaging and forwarding expenses – for handling costs incurred.
<G-vec00347-002-s141><charge.berechnen><de> Für Lieferungen nach Österreich, Niederlande, Belgien, Vereinigtes Königreich, Irland, Frankreich, Italien, Polen, Tschechische Republik, Dänemark und Schweden berechnen wir für die Lieferung von Paketsendungen bis 10 kg pauschal 69,00 €, sowie für Speergut- und Speditionssendungen bis 20 kg 99,00 € pro Bestellung.
<G-vec00347-002-s141><charge.berechnen><en> For deliveries to Austria, Switzerland, Liechtenstein, the Netherlands, Belgium, UK, Ireland, France, Italy, Poland, Czech Republic, Denmark and Sweden we charge for delivery of parcels up to 31 kg overall 12.50 €, and for Speergut- and forwarding consignments 95.00 € per order.
<G-vec00347-002-s142><charge.berechnen><de> Wir berechnen unseren Künstlern keine Gebühren, wenn sie etwas verkaufen.
<G-vec00347-002-s142><charge.berechnen><en> We don't charge artists any sales fees or commissions.
<G-vec00347-002-s143><charge.berechnen><de> Wenn Ihre Bestellung in ein Land außerhalb der Europäischen Union (EU) geliefert wird, werden wir Ihnen keine Mehrwertsteuer berechnen.
<G-vec00347-002-s143><charge.berechnen><en> If your order is shipped to a country outside of the European Union (EU), then we will not charge you VAT.
<G-vec00347-002-s144><charge.berechnen><de> Hierfür berechnen wir jeweils € 8,50 p.P.
<G-vec00347-002-s144><charge.berechnen><en> For breakfast we charge € 8.50 per person
<G-vec00347-002-s145><charge.berechnen><de> Unabhängig davon, wie hoch die Kosten für Porto und Verpackung tatsächlich sind, berechnen wir für die Versandkosten eine Kostenpauschale abhängig vom Land.
<G-vec00347-002-s145><charge.berechnen><en> Regardless of how high the cost of postage and packaging are, actually we charge (depending on the country) for the delivery costs a flat fee.
<G-vec00347-002-s146><charge.berechnen><de> 7.2 Zusätzlich zu den angegebenen Preisen berechnen wir für die Lieferung Versandkosten.
<G-vec00347-002-s146><charge.berechnen><en> 7.2 In addition to the prices quoted, we shall charge shipping costs for delivery.
<G-vec00347-002-s147><charge.berechnen><de> Um die Kosten zu decken, berechnen wir einen Betrag von jedem der Teilnehmer.
<G-vec00347-002-s147><charge.berechnen><en> To cover expenses we will charge an amount from each of the participants.
<G-vec00347-002-s148><charge.berechnen><de> Wir berechnen keine monatliche oder wiederkehrende Gebühr, um die Website anzusehen.
<G-vec00347-002-s148><charge.berechnen><en> We do not charge a monthly or recurring fee to view the site.
<G-vec00347-002-s149><charge.berechnen><de> Wenn Sie uns Ihr Haus auf unserer Website präsentieren möchten, nur berechnen wir Ihnen eine kleine Menge für jede Buchung, die wir erzeugen, um unsere Variable Kosten zu decken.
<G-vec00347-002-s149><charge.berechnen><en> If you would like us to present your house at our site, we will only charge you a small amount for every booking we generate in order to cover our variable costs.
<G-vec00347-002-s150><charge.berechnen><de> Beträgt die Reisezeit mehr als 4 Stunden berechnen wir pauschal 1/3 unseres Tagessatzes.
<G-vec00347-002-s150><charge.berechnen><en> If the travel time amounts to more than 4 hours, we charge a fixed rate of 1/3 of our daily rate.
<G-vec00347-002-s151><charge.berechnen><de> Wir behalten uns das Recht vor, für extra große oder extra schwere Lieferungen wie zum Beispiel Mischpulte und Monitore/Lautsprecher eine zusätzliche Liefergebühr zu berechnen.
<G-vec00347-002-s151><charge.berechnen><en> We reserve the right to charge extra for some heavy or large items (like consoles or big studio monitors).
