<G-vec00503-002-s020><plead.anklopfen><de> Es verging ja kaum ein Monat, wo nicht irgendjemand angeblich anklopfte, um Aufnahme im Deutschen Reich zu finden.
<G-vec00503-002-s020><plead.anklopfen><en> Hardly a month passed in which somebody didn't allegedly plead to be incorporated into the German Empire.
