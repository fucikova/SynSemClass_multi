<G-vec00510-001-s247><expand.dehnen><de> Die heute berichteten Ergebnisse dehnen den Westteil der Zone Waite über die im Jahr 2017 erbohrten Bereiche aus und bestätigen die Korrelation der früher durchteuften Kobalt-Kupfer- Vererzung (Tabelle 1).
<G-vec00510-001-s247><expand.dehnen><en> Results reported today expand the extension of the western portion of the Waite Zone outside of the areas drilled in 2017 and validate the correlation of cobalt-copper mineralization previously intersected (Table 1) .
<G-vec00510-001-s248><expand.dehnen><de> Die rein sexuellen Beziehungen der Post-1960er wie auch Junggesellentum und die Ehelosigkeit unter Frauen, sowohl mit als auch ohne Kinder, erhalten offensichtlich nicht die bestehende Volkszahl der weißen Völker oder dehnen sie aus, erhalten nicht unsere Kultur, oder befördern Eigengruppen-Kohäsion (Gemeinschaftsgefühl).
<G-vec00510-001-s248><expand.dehnen><en> Post-1960s post-family sexual arrangements as well as bachelorhood and spinsterhood, with or without children, clearly do not replace or expand the white population, preserve our culture, or provide in-group cohesion (belongingness).
<G-vec00510-001-s249><expand.dehnen><de> Dabei dehnen sie die physische Drangsal und Folterung weiter aus, damit sie bei extremer Erschöpfung physisch und spirituell einwirken können.
<G-vec00510-001-s249><expand.dehnen><en> They further expand the physical persecution and torture so that they can take the opportunity when you are extremely exhausted, physically and spiritually.”
<G-vec00510-001-s250><expand.dehnen><de> So halten wir unser Bewusstsein offen und dehnen uns in immer größere Dimensionen des Lebens und der Erfahrung aus.
<G-vec00510-001-s250><expand.dehnen><en> Thus, we keep our minds open and expand ourselves into ever greater dimensions of life and of experience.
<G-vec00510-001-s251><expand.dehnen><de> das Netz (den Henkel) dehnen vom Stemmeisen auf 2-3 mm in beide Seiten unten aus so, dass es nicht rechteckig, und trapezijewidnym wurde.
<G-vec00510-001-s251><expand.dehnen><en> The Nest (eye) from below expand with a chisel on 2-3 mm in both parties so that it became not rectangular, but trapezoid.
<G-vec00510-001-s252><expand.dehnen><de> Übung: Mit dem Ausatmen dehnen Sie Ihr Bewußtsein aus - mit der Folge, daß sich Ihr Identitätsgefühl jenseits der persönlichen Dimension erweitert.
<G-vec00510-001-s252><expand.dehnen><en> PRACTICE:As you exhale expand your consciousness with the effect of expanding your sense of identity beyond the personal dimension.
<G-vec00510-001-s253><expand.dehnen><de> Zum einen, dass Fehlmann und Paterson befähigt sind, die Zeit nicht nur ins Unendliche zu dehnen, wie es Psychedelica, Ambient und Dub, die Genres, denen sich The Orb nah fühlen, so sehr auszeichnet, sie können den Prozess auch umkehren.
<G-vec00510-001-s253><expand.dehnen><en> One the one hand that Fehlmann and Paterson are able to expand time into the infinite, just like the genres that The Orb are feeling close to, like Psych, Ambient, and Dub. They are so good at it, that they can even reverse the process.
<G-vec00510-001-s254><expand.dehnen><de> Diese dehnen sich nun aus, um so viel vom Bildschirm einzunehmen wie nur möglich, ohne dabei ihre allgemeine Form zu verlieren.
<G-vec00510-001-s254><expand.dehnen><en> These now expand to fill as much of the screen as possible while still retaining their overall shape.
<G-vec00510-001-s255><expand.dehnen><de> Die Sicherheits-Einlage besteht aus Weich-Kunststoff und lässt sich entsprechend dehnen.
<G-vec00510-001-s255><expand.dehnen><en> The safety insert consists of soft plastic and accordingly it can expand.
<G-vec00510-001-s256><expand.dehnen><de> Wir dehnen unserer Standpunkt aus und stehen da als König der Könige und Königin der Königinnen, die wir wirklich sind.
<G-vec00510-001-s256><expand.dehnen><en> We expand our stance and stand as the true King of Kings or Queen of Queens that we really are.
<G-vec00510-001-s257><expand.dehnen><de> Die Lösungen und Technologien von IFS für Zusammenarbeit und Datenaustausch dehnen die Geschäftsprozesse auf ein erweitertes Netzwerk von Subunternehmern, Partnern und Kunden aus.
<G-vec00510-001-s257><expand.dehnen><en> IFS' technology for collaborative solutions and data exchange expand business processes out into your extended network of subcontractors, partners and customers.
<G-vec00510-001-s258><expand.dehnen><de> Durch falsche Impulse des Nervensystems dehnen sich die Blutgefäße aus, was unweigerlich zu einer Überhitzung des Körpers führt, was wiederum die Schweissdrüsen stimuliert, und sie beginnen aktiv, Schweiß auszusondern, um die Körpertemperatur zu normalisieren.
<G-vec00510-001-s258><expand.dehnen><en> Incorrect impulses of the nervous system cause the blood vessels to expand, which inevitably leads to overheating of the body, which in turn gives impetus to the sweat glands, and they begin to actively secrete sweat to normalize the body temperature.
<G-vec00510-001-s259><expand.dehnen><de> Mit dem Ausatmen dehnen Sie Ihr Bewußtsein aus - mit der Folge, daß sich Ihr Identitätsgefühl jenseits der persönlichen Dimension erweitert.
<G-vec00510-001-s259><expand.dehnen><en> As you exhale expand your consciousness with the effect of expanding your sense of identity beyond the personal dimension.
<G-vec00510-001-s260><expand.dehnen><de> Unter den Bedingungen des feuchten Klimas dehnen die Sommerräume die Funktionen der Wohnfläche aus, ermöglichen während der häufigen Regen, geöffnet die Fenster zu halten, sowie, die Zeit der Freizeit durchzuführen oder, die abgesonderten wirtschaftlichen Arbeiten in der Luft zu erfüllen.
<G-vec00510-001-s260><expand.dehnen><en> In the conditions of a damp climate summer premises expand habitation functions, give the chance to hold during frequent rains opened windows, and also to spend time leisure or to perform separate economic works on air.
<G-vec00510-001-s261><expand.dehnen><de> Sie reduzieren sie zuerst, dehnen sie dann aus und reduzieren sie dann wieder, und dies dauert, bis die Stickstoffverbindungen die Konzentration im Körper verringern.
<G-vec00510-001-s261><expand.dehnen><en> They first reduce, then expand them, then reduce them again, and this lasts until the nitrogen compounds reduce the concentration in the body.
<G-vec00510-001-s262><expand.dehnen><de> Bewegungen, die den Brust- und Bauchraum dehnen, werden stets mit der Einatmung verbunden.
<G-vec00510-001-s262><expand.dehnen><en> Movements that expand the chest and abdominal cavity, are always connected with the inhalation
<G-vec00510-001-s263><expand.dehnen><de> Wahrenddessen dehnen sich die ausseren Schichten aus inerten Wasserstoffatomen aus.
<G-vec00510-001-s263><expand.dehnen><en> Meanwhile the outer layers comprised of inert hydrogen atoms expand.
<G-vec00510-001-s264><expand.dehnen><de> Das heißt, Adrenalin-verengte Blutgefäße dehnen sich erneut aus, wodurch ein normaler Betrieb sichergestellt wird, der Druck normalisiert sich wieder, die Bronchien kehren in den gewünschten Zustand zurück und der Blutzuckerspiegel kehrt wieder normal zurück.
<G-vec00510-001-s264><expand.dehnen><en> That is, adrenaline-contracted blood vessels expand again, ensuring normal operation, the pressure returns to normal, the bronchi return to the desired state, and the glucose level returns to normal.
<G-vec00510-001-s265><expand.dehnen><de> Mit dem allumfassenden Yoga dehnen wir Herz und Bewusstsein an genau diesem Punkt, gerade bevor wir den Mandalapalast betreten, mit diesen beiden Bodhichittas aus.
<G-vec00510-001-s265><expand.dehnen><en> With the yoga encompassing everything, we expand our heart and mind at this point, just before entering the mandala palace, with these two bodhichittas.
<G-vec00261-002-s186><stretch.dehnen><de> Warnungen Dehne dich immer vor und nach dem Trainieren deiner Bauchmuskeln, um die Muskeln korrekt aufzuwärmen und nach dem Training zu entspannen.
<G-vec00261-002-s186><stretch.dehnen><en> Warnings Always stretch before and after you work your lower abdominals to warm up the muscles properly and to relax the muscles after a workout.
<G-vec00261-002-s187><stretch.dehnen><de> Dehne Deinen großen Zeh.
<G-vec00261-002-s187><stretch.dehnen><en> Stretch your big toe.
<G-vec00261-002-s188><stretch.dehnen><de> Halte deine Beine in der 90-Grad-Position, lehne und dehne deinen Körper nach vorn, zwischen deinen Beinen und mit geradem Rücken, halte dies30 Sekunden lang.
<G-vec00261-002-s188><stretch.dehnen><en> 3 Stretch forward. Keep your legs in the 90 degrees position, and lean and stretch your body forward between your legs with a straight back.
<G-vec00261-002-s189><stretch.dehnen><de> Dehne deinen Körper vor und nach jeder sportlichen Betätigung.
<G-vec00261-002-s189><stretch.dehnen><en> Stretch before and after a workout.
<G-vec00261-002-s190><stretch.dehnen><de> Dehne die Schamlippen.
<G-vec00261-002-s190><stretch.dehnen><en> Stretch your labia.
<G-vec00261-002-s191><stretch.dehnen><de> Dehne dein bevorzugtes Bein nach vorn.
<G-vec00261-002-s191><stretch.dehnen><en> Stretch your preferred leg forward in front of you.
<G-vec00261-002-s192><stretch.dehnen><de> Dehne deine Handgelenke, Arme und Beine.
<G-vec00261-002-s192><stretch.dehnen><en> Stretch your wrists, arms, and legs.
<G-vec00261-002-s193><stretch.dehnen><de> Dehne das letzte Stück der Bandage ein wenig und befestige das Ende mit der kleinen Metallklammer oder Klett, um das Ende der Bandage zu befestigen.
<G-vec00261-002-s193><stretch.dehnen><en> Stretch the last segment of the bandage a bit and use the small metal prongs or velcro adhesive to secure the end of the bandage in place.
<G-vec00261-002-s194><stretch.dehnen><de> Dehne deine Zunge für eine bessere Artikulation.
<G-vec00261-002-s194><stretch.dehnen><en> Stretch your tongue for better articulation.
<G-vec00261-002-s195><stretch.dehnen><de> Dehne deine Hüften.
<G-vec00261-002-s195><stretch.dehnen><en> Stretch your hips.
<G-vec00261-002-s196><stretch.dehnen><de> Dehne deinen Mund und die Masseter-Muskeln.
<G-vec00261-002-s196><stretch.dehnen><en> Stretch your mouth and masseter muscles.
<G-vec00261-002-s197><stretch.dehnen><de> Dehne deine beanspruchten Muskeln nach jedem Lauftraining, damit du beweglich bleibst.
<G-vec00261-002-s197><stretch.dehnen><en> Stretch the muscles used after each running workout so you remain flexible.
<G-vec00261-002-s198><stretch.dehnen><de> Dehne deine Brustmuskeln und konzentriere dich auf diese Dehnung.
<G-vec00261-002-s198><stretch.dehnen><en> Stretch your chest muscles and concentrate on this stretch.
<G-vec00261-002-s199><stretch.dehnen><de> Dehne das Kondom nicht, um es auf Risse zu untersuchen.
<G-vec00261-002-s199><stretch.dehnen><en> Do not stretch the condom to examine it for tears.
<G-vec00261-002-s200><stretch.dehnen><de> Dehne dein Kiefer.
<G-vec00261-002-s200><stretch.dehnen><en> Stretch your jaw.
<G-vec00274-002-s008><lengthen.dehnen><de> Dehne die Vokale und übertreibe bei der Aussprache jedes Wortes, das du sagst oder singst.
<G-vec00274-002-s008><lengthen.dehnen><en> Lengthen the vowels and exaggerate the vocalization of each word as you say and/or sing it.
<G-vec00274-002-s035><prolong.dehnen><de> Für schwer beschmutzte Kleidung erhöhen Sie bitte die Menge und dehnen Sie richtig die Haltedauer aus.
<G-vec00274-002-s035><prolong.dehnen><en> For heavily soiled clothes, please increase the amount and properly prolong the soaking time.
<G-vec00274-002-s036><prolong.dehnen><de> Die neue Technologie, die in die Scan-Maschinenhilfen integriert wird, verringern die Leistungsaufnahme und dehnen die Nutzungsdauer des Gerätes aus.
<G-vec00274-002-s036><prolong.dehnen><en> Outstanding Power Efficiency The advanced technology incorporated in the scan engine helps reduce the power consumption and prolong the service life of the device.
<G-vec00298-002-s228><expand.dehnen><de> Die Gefäße dehnen sich aus, der Blutfluss wird intensiver - dies kann Ihre Schwangerschaft gefährden, wenn eine Fehlgeburt droht.
<G-vec00298-002-s228><expand.dehnen><en> Vessels expand, the blood flow becomes more intense - this can jeopardize your pregnancy if there is a threat of miscarriage.
<G-vec00298-002-s229><expand.dehnen><de> Dabei dehnen sich sowohl Werkstück als auch Werkzeug aus.
<G-vec00298-002-s229><expand.dehnen><en> Both the workpiece and the tool expand.
<G-vec00298-002-s230><expand.dehnen><de> Eingeengte Bildformate brechen auf, gebogene und gekrümmte Flächen dehnen sich in den Raum aus und transzendieren zu Installationen und skulpturalen Formen.
<G-vec00298-002-s230><expand.dehnen><en> Constricted image formats burst open, curved and contorted surfaces expand space and transcend into installations and sculptural shapes.
<G-vec00298-002-s231><expand.dehnen><de> Da Kapseln von Feuchtigkeit beeinträchtigt werden (sie dehnen sich aus), hat die Füllmaschine einen Trocknungsbeutel.
<G-vec00298-002-s231><expand.dehnen><en> Since capsules are affected by humidity (they expand), the filling machine includes a moisture-sucking drying bag.
<G-vec00298-002-s232><expand.dehnen><de> Es enthält mehr Sauerstoff und negative Ionen, die sich positiv auf das Lungengewebe auswirken: die Bronchien dehnen sich aus und das Baby beginnt leichter und tiefer zu atmen.
<G-vec00298-002-s232><expand.dehnen><en> It contains more oxygen and negative ions, which have a beneficial effect on lung tissue: the bronchi expand, and the baby begins to breathe easier and deeper.
<G-vec00298-002-s233><expand.dehnen><de> Eine Variante derselben Serie - Falttüren, sie sind kompakt, leicht, dehnen sich aus, ohne übermäßigen Lärm zu erzeugen.
<G-vec00298-002-s233><expand.dehnen><en> A variant of the same series - folding doors, they are compact, light, expand without creating excessive noise.
<G-vec00298-002-s234><expand.dehnen><de> Gefälschte Akkus lassen nach regelmäßiger Verwendung schnell an Qualität nach, zeigen den falschen Akkuladestand an, dehnen sich aus und klemmen dann im Steckplatz der Kamera fest, sorgen für einen schnellen Leistungsabfall oder beschädigen die Kameradaten.
<G-vec00298-002-s234><expand.dehnen><en> Counterfeit batteries may also deteriorate quickly after frequent use, inaccurately show battery power levels, expand and become stuck into the camera slot, cause sudden power loss, or damage camera data.
<G-vec00298-002-s235><expand.dehnen><de> Wenn es zunimmt, dehnen sich die Hautgefäße aus, wodurch die Wärmeübertragung erhöht wird.
<G-vec00298-002-s235><expand.dehnen><en> When it increases, the skin vessels expand, thereby increasing the heat transfer.
<G-vec00298-002-s236><expand.dehnen><de> Im Ohr dehnen sie sich wieder aus und ermöglichen so einen perfekten Halt und eine Abschirmung von Umgebungsgeräuschen.
<G-vec00298-002-s236><expand.dehnen><en> Once in place, they expand again, giving a perfect fit and blocking out ambient noise.
<G-vec00298-002-s237><expand.dehnen><de> Sind Ihre Lungenmuskeln entspannt, dehnen sich die Atemwege, die das Herz mit Sauerstoff versorgen, aus und ermöglichen so eine leichtere Atmung.
<G-vec00298-002-s237><expand.dehnen><en> By relaxing your lung muscles, the airways supplying oxygen to the heart expand, allowing easy breathing. Pain Relief
<G-vec00298-002-s239><expand.dehnen><de> Diese Lösungen dehnen sich beim Einfrieren aus.
<G-vec00298-002-s239><expand.dehnen><en> These solutions expand while freezing.
<G-vec00298-002-s240><expand.dehnen><de> Während des Eingriffs öffnen sich die Gesichtsgefäße, die Durchblutung steigt, die Poren dehnen sich aus, die Hautzellen sind mit Sauerstoff gesättigt, was zur Verbesserung des Teints beiträgt.
<G-vec00298-002-s240><expand.dehnen><en> The vessels of the face open during the procedure, blood flow increases, the pores expand, skin cells are saturated with oxygen, which helps to improve complexion.
<G-vec00298-002-s241><expand.dehnen><de> Sobald wir unsere Körper verlassen, dehnen wir uns aus und schließen uns wieder einmal etwas viel Größerem an.
<G-vec00298-002-s241><expand.dehnen><en> Once we leave our bodies we expand and once again join something much greater.
<G-vec00298-002-s242><expand.dehnen><de> Im Laufe des Tages dehnen sich Füße aus.
<G-vec00298-002-s242><expand.dehnen><en> Feet expand during the day.
<G-vec00298-002-s243><expand.dehnen><de> Die Drain_Holes sind von innen befestigt und dehnen sich nicht aus.
<G-vec00298-002-s243><expand.dehnen><en> The Drain_Holes are secured in place from the inside and won't expand.
