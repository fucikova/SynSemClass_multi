<G-vec00092-001-s114><call.anrufen><de> Anrufen: Wählen und bestätigen Sie die gewünschte Telefonnummer.
<G-vec00092-001-s114><call.anrufen><en> Call: Select and confirm the desired telephone number.
<G-vec00092-001-s115><call.anrufen><de> Unternehmen spezialisiert auf den Verkauf von Minuten, Unternehmen anrufen und Mehr... bieten auch die Anrufzustellung Ausrüstung Verkäufe ip virtuale nuemros recargs s virtuell.
<G-vec00092-001-s115><call.anrufen><en> Company dedicated to the sale of minutes to call centers, More... companies and also offer call termination equipment sales ip virtuale nuemros recargs s virtual.
<G-vec00092-001-s116><call.anrufen><de> Er hat Seine wundervolle Errettung ALLEN verheißen, die Seinen Namen anrufen und Buße tun, ganz gleich welcher Herkunft: RÖMER 9:6-8 und RÖMER 11:17-27 machen das sehr deutlich.
<G-vec00092-001-s116><call.anrufen><en> He has extended His wonderful salvation to ALL who call upon His Name and repent, whatever their background: ROMANS 9:6-8 and ROMANS 11:17-27 demonstrate this clearly.
<G-vec00092-001-s117><call.anrufen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00092-001-s117><call.anrufen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00092-001-s118><call.anrufen><de> Es ist sehr einfach, und Sie haben nichts zu befürchten, sie werden alles tun, damit Sie unsere Agentur anrufen und eine Reservierung vorzunehmen Wir Sie alle Informationen erhalten Sie brauchen die besten Begleiter von Amsterdam zu begegnen.
<G-vec00092-001-s118><call.anrufen><en> It is very easy and you have nothing to worry about, she will do everything for you Call our agency and make a booking We will give you all the information you need to encounter the best escorts of Amsterdam.
<G-vec00092-001-s119><call.anrufen><de> Wenn Sie nicht, bis die Download-Webseite warten möchten, und es war eine logische Frage, wie Verkehr zu „Tele2“ hinzufügen möchte, sollten Sie die offizielle Website Betreiber besuchen oder das Contact Center anrufen und klären, wie es getan werden kann.
<G-vec00092-001-s119><call.anrufen><en> "If you do not want to wait until the web page loads and a logical question emerges about how to add traffic to ""Tele2"", you should visit the official website of the operator or call the contact center and specify how it can be done."
<G-vec00092-001-s120><call.anrufen><de> Wenn Sie die 112 anrufen, werden Sie mit einem Mitarbeiter verbunden, der Sie an den passenden Notdienst weiterleitet.
<G-vec00092-001-s120><call.anrufen><en> When you call 112, you will be connected to an operator who will pass you on to the emergency service you require.
<G-vec00092-001-s121><call.anrufen><de> Wenn du dich auch so sehr nach diesen Momenten sehnst, wie ich, dann solltest du nicht noch länger warten sondern mich direkt anrufen.
<G-vec00092-001-s121><call.anrufen><en> If you are so hungry for these moments, like me, then you should not wait any longer but call me directly.
<G-vec00092-001-s122><call.anrufen><de> 2 an die Gemeinde Gottes, die in Korinth ist, den Geheiligten in Christus Jesus, den berufenen Heiligen, samt allen, die an jedem Ort den Namen unseres Herrn Jesus Christus anrufen, ihres und unseres [Herrn].
<G-vec00092-001-s122><call.anrufen><en> 2 To the church of God which is at Corinth, to those who are sanctified in Christ Jesus, called to be saints, with all who in every place call on the name of Jesus Christ our Lord, both theirs and ours:
<G-vec00092-001-s123><call.anrufen><de> Aufruf irgendwo außerhalb Kuwait ist extrem teuer, unabhängig davon, wann Sie anrufen.
<G-vec00092-001-s123><call.anrufen><en> Calling anywhere outside Kuwait is extremely expensive, regardless of when you call.
<G-vec00092-001-s124><call.anrufen><de> "Um Europa neue Hoffnung zu geben, müssen die Kirchen auf Maria schauen und sie anrufen, damit sie sich weiterhin als Mutter der Hoffnung zeigt und ganz Europa auf dem Weg des Erbarmens zur erneuernden Begegnung mit ""Jesus Christus, unsere Hoffnung"" (1 Tim 1, 1) führt."
<G-vec00092-001-s124><call.anrufen><en> "To restore hope to Europe, therefore, the Churches must look to her and call upon her to continue to show herself as Mother of Hope and lead the entire European continent through the paths of mercy to a revitalising encounter with ""Jesus Christ, our Hope"" (1 Tim1:1)."
<G-vec00092-001-s125><call.anrufen><de> Cortana kann Sie an etwas erinnern, wenn Sie jemanden anrufen oder ihm eine SMS senden oder wenn die betreffende Person Sie anruft oder Ihnen eine SMS sendet.
<G-vec00092-001-s125><call.anrufen><en> Cortana can remind you of something when you call or text someone, or when they call or text you.
<G-vec00092-001-s126><call.anrufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00092-001-s126><call.anrufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00092-001-s127><call.anrufen><de> Wenn Sie weitere Fragen haben, können Sie auch anrufen 0800 098 8202 (GB), 24 Stunden am Tag, 7 Tage die Woche.
<G-vec00092-001-s127><call.anrufen><en> If you have additional questions you may also call toll free: 0800 098 8202 (GB), 24 hours a day, 7 days a week.
<G-vec00092-001-s128><call.anrufen><de> Wenn Sie eine CD bestellen möchten, können Sie mir gerne eine Email schreiben oder mich anrufen.
<G-vec00092-001-s128><call.anrufen><en> If you would like to purcase a CD, you are most welcome to email or call me.
<G-vec00092-001-s129><call.anrufen><de> Diese Entscheidung kam aus dem Bewusstsein, dass die meisten Studenten und Umstehenden den Krankenwagen nur dann anrufen, wenn der Gesundheitszustand kritisch wurde.
<G-vec00092-001-s129><call.anrufen><en> This decision came from the awareness that most students and bystanders call the ambulance only when the health condition came critical.
<G-vec00092-001-s130><call.anrufen><de> Wenn jemand, der regelmäßig das Zentrum besucht, nicht mehr kommt, insbesondere wenn es sich um jemanden handelt, der allein lebt, sollte man anrufen und sich erkundigen, ob er krank ist oder Hilfe braucht.
<G-vec00092-001-s130><call.anrufen><en> If somebody who regularly comes to the center stops coming, especially if it is someone living alone, call and find out if they are sick, if they need any help.
<G-vec00092-001-s131><call.anrufen><de> Anrufen: Wählen und bestätigen Sie einen Favoriten/die Heimatadresse.
<G-vec00092-001-s131><call.anrufen><en> Call: Select and confirm a favourite/your home address.
<G-vec00092-001-s132><call.anrufen><de> Wenn ihr euch nicht sicher seit, ob ein Gutschein oder Coupon gültig ist, dann könnt ihr uns gerne anrufen oder eine Mail schreiben.
<G-vec00092-001-s132><call.anrufen><en> If you are not sure since, if a voucher or coupon is valid, then you can call us or write an email.
<G-vec00272-001-s114><call.anrufen><de> Anrufen: Wählen und bestätigen Sie die gewünschte Telefonnummer.
<G-vec00272-001-s114><call.anrufen><en> Call: Select and confirm the desired telephone number.
<G-vec00272-001-s115><call.anrufen><de> Unternehmen spezialisiert auf den Verkauf von Minuten, Unternehmen anrufen und Mehr... bieten auch die Anrufzustellung Ausrüstung Verkäufe ip virtuale nuemros recargs s virtuell.
<G-vec00272-001-s115><call.anrufen><en> Company dedicated to the sale of minutes to call centers, More... companies and also offer call termination equipment sales ip virtuale nuemros recargs s virtual.
<G-vec00272-001-s116><call.anrufen><de> Er hat Seine wundervolle Errettung ALLEN verheißen, die Seinen Namen anrufen und Buße tun, ganz gleich welcher Herkunft: RÖMER 9:6-8 und RÖMER 11:17-27 machen das sehr deutlich.
<G-vec00272-001-s116><call.anrufen><en> He has extended His wonderful salvation to ALL who call upon His Name and repent, whatever their background: ROMANS 9:6-8 and ROMANS 11:17-27 demonstrate this clearly.
<G-vec00272-001-s117><call.anrufen><de> Sehr große Fahrer wünschen konnte, vorher anrufen und fragen, ob es irgendwelche Pferde, die ihnen passen können, sind, da es Gewichtsgrenzen für die Pferde sind, aber in der Regel die meisten jeder mitmachen kann .
<G-vec00272-001-s117><call.anrufen><en> Very large riders might want to call ahead and ask if there are any horses that can fit them, since there are weight limits for the horses, but in general most everyone can participate.
<G-vec00272-001-s118><call.anrufen><de> Es ist sehr einfach, und Sie haben nichts zu befürchten, sie werden alles tun, damit Sie unsere Agentur anrufen und eine Reservierung vorzunehmen Wir Sie alle Informationen erhalten Sie brauchen die besten Begleiter von Amsterdam zu begegnen.
<G-vec00272-001-s118><call.anrufen><en> It is very easy and you have nothing to worry about, she will do everything for you Call our agency and make a booking We will give you all the information you need to encounter the best escorts of Amsterdam.
<G-vec00272-001-s119><call.anrufen><de> Wenn Sie nicht, bis die Download-Webseite warten möchten, und es war eine logische Frage, wie Verkehr zu „Tele2“ hinzufügen möchte, sollten Sie die offizielle Website Betreiber besuchen oder das Contact Center anrufen und klären, wie es getan werden kann.
<G-vec00272-001-s119><call.anrufen><en> "If you do not want to wait until the web page loads and a logical question emerges about how to add traffic to ""Tele2"", you should visit the official website of the operator or call the contact center and specify how it can be done."
<G-vec00272-001-s120><call.anrufen><de> Wenn Sie die 112 anrufen, werden Sie mit einem Mitarbeiter verbunden, der Sie an den passenden Notdienst weiterleitet.
<G-vec00272-001-s120><call.anrufen><en> When you call 112, you will be connected to an operator who will pass you on to the emergency service you require.
<G-vec00272-001-s121><call.anrufen><de> Wenn du dich auch so sehr nach diesen Momenten sehnst, wie ich, dann solltest du nicht noch länger warten sondern mich direkt anrufen.
<G-vec00272-001-s121><call.anrufen><en> If you are so hungry for these moments, like me, then you should not wait any longer but call me directly.
<G-vec00272-001-s122><call.anrufen><de> 2 an die Gemeinde Gottes, die in Korinth ist, den Geheiligten in Christus Jesus, den berufenen Heiligen, samt allen, die an jedem Ort den Namen unseres Herrn Jesus Christus anrufen, ihres und unseres [Herrn].
<G-vec00272-001-s122><call.anrufen><en> 2 To the church of God which is at Corinth, to those who are sanctified in Christ Jesus, called to be saints, with all who in every place call on the name of Jesus Christ our Lord, both theirs and ours:
<G-vec00272-001-s123><call.anrufen><de> Aufruf irgendwo außerhalb Kuwait ist extrem teuer, unabhängig davon, wann Sie anrufen.
<G-vec00272-001-s123><call.anrufen><en> Calling anywhere outside Kuwait is extremely expensive, regardless of when you call.
<G-vec00272-001-s124><call.anrufen><de> "Um Europa neue Hoffnung zu geben, müssen die Kirchen auf Maria schauen und sie anrufen, damit sie sich weiterhin als Mutter der Hoffnung zeigt und ganz Europa auf dem Weg des Erbarmens zur erneuernden Begegnung mit ""Jesus Christus, unsere Hoffnung"" (1 Tim 1, 1) führt."
<G-vec00272-001-s124><call.anrufen><en> "To restore hope to Europe, therefore, the Churches must look to her and call upon her to continue to show herself as Mother of Hope and lead the entire European continent through the paths of mercy to a revitalising encounter with ""Jesus Christ, our Hope"" (1 Tim1:1)."
<G-vec00272-001-s125><call.anrufen><de> Cortana kann Sie an etwas erinnern, wenn Sie jemanden anrufen oder ihm eine SMS senden oder wenn die betreffende Person Sie anruft oder Ihnen eine SMS sendet.
<G-vec00272-001-s125><call.anrufen><en> Cortana can remind you of something when you call or text someone, or when they call or text you.
<G-vec00272-001-s126><call.anrufen><de> Rufen Sie jemand - ob Sie es glauben oder nicht, eines der am wenigsten verwendete Funktionen unserer Telefone ist, um tatsächlich jemanden anrufen.
<G-vec00272-001-s126><call.anrufen><en> Call Someone – Believe it or not, one of the least used features of our phones is to actually call someone.
<G-vec00272-001-s127><call.anrufen><de> Wenn Sie weitere Fragen haben, können Sie auch anrufen 0800 098 8202 (GB), 24 Stunden am Tag, 7 Tage die Woche.
<G-vec00272-001-s127><call.anrufen><en> If you have additional questions you may also call toll free: 0800 098 8202 (GB), 24 hours a day, 7 days a week.
<G-vec00272-001-s128><call.anrufen><de> Wenn Sie eine CD bestellen möchten, können Sie mir gerne eine Email schreiben oder mich anrufen.
<G-vec00272-001-s128><call.anrufen><en> If you would like to purcase a CD, you are most welcome to email or call me.
<G-vec00272-001-s129><call.anrufen><de> Diese Entscheidung kam aus dem Bewusstsein, dass die meisten Studenten und Umstehenden den Krankenwagen nur dann anrufen, wenn der Gesundheitszustand kritisch wurde.
<G-vec00272-001-s129><call.anrufen><en> This decision came from the awareness that most students and bystanders call the ambulance only when the health condition came critical.
<G-vec00272-001-s130><call.anrufen><de> Wenn jemand, der regelmäßig das Zentrum besucht, nicht mehr kommt, insbesondere wenn es sich um jemanden handelt, der allein lebt, sollte man anrufen und sich erkundigen, ob er krank ist oder Hilfe braucht.
<G-vec00272-001-s130><call.anrufen><en> If somebody who regularly comes to the center stops coming, especially if it is someone living alone, call and find out if they are sick, if they need any help.
<G-vec00272-001-s131><call.anrufen><de> Anrufen: Wählen und bestätigen Sie einen Favoriten/die Heimatadresse.
<G-vec00272-001-s131><call.anrufen><en> Call: Select and confirm a favourite/your home address.
<G-vec00272-001-s132><call.anrufen><de> Wenn ihr euch nicht sicher seit, ob ein Gutschein oder Coupon gültig ist, dann könnt ihr uns gerne anrufen oder eine Mail schreiben.
<G-vec00272-001-s132><call.anrufen><en> If you are not sure since, if a voucher or coupon is valid, then you can call us or write an email.
<G-vec00092-001-s152><call.anrufen><de> Er bat die Usbeken, ihn für eine Aufnahmesession anzurufen, sobald sie wieder eine Leiche finden würden, die bestattet werden musste.
<G-vec00092-001-s152><call.anrufen><en> He asked the Uzbeks to call him to snap a session, if they suddenly found a new corpse and decide to bury it.
<G-vec00092-001-s153><call.anrufen><de> "In meinem Fall, bin ich sehr traurig, weil ich sie vor 1 1/2 Monaten verloren habe, aber nicht ein Tag vergeht, an dem ich nicht durch die Abspeicherungstaste ""Grosseltern"" am Telefon an sie erinnert werde und das Bedürfnis verspüre, sie anzurufen, um ihre Stimme zu hören."
<G-vec00092-001-s153><call.anrufen><en> "In my case, I am sorrowful, because I lost her 1 1/2 month ago, but it not pass one day, in which I not be remember in her about the memory key ""Grandparents"" of the phone and the need to call her for hear her voice."
<G-vec00092-001-s154><call.anrufen><de> Wenn Sie uns näher kennen lernen wollen, laden wir Sie ein, einen Blick auf unsere Homepage zu werfen oder uns anzurufen oder zu schreiben.
<G-vec00092-001-s154><call.anrufen><en> If you would like to become better acquainted with us, we invite you to take a look at our home page or call us or write to us.
<G-vec00092-001-s155><call.anrufen><de> Die Wahrheit ist, du hast die Macht, Engel anzurufen, um deinen Weg zu beleuchten.
<G-vec00092-001-s155><call.anrufen><en> The truth is, you have the power to call on angels to light your way.
<G-vec00092-001-s156><call.anrufen><de> Die Menschen sollen aber darüber aufgeklärt werden, daß die Erde ein Gestirn für sich ist, das keine Verbindung hat mit anderen Welten, und daß jegliche Bindung mit deren Bewohnern nur geistig herzustellen ist.... daß also sich der Mensch wohl den Bewohnern höherer Welten, des Lichtreiches, verbinden kann durch gute bittende Gedanken um Hilfe in geistiger Not.... die ihm geistig wohl auch geleistet wird.... daß es aber für ihn nicht ratsam ist, Wesen anzurufen von Gestirnen, von denen er nicht weiß, in welchem geistigen Reifegrad diese stehen und ob sie ihm geistige Hilfe gewähren können.
<G-vec00092-001-s156><call.anrufen><en> But people should be informed that earth is a planet on its own which has no connection with other worlds, and that any connection with other worlds can only be spiritually established.... Hence the human being is, in fact, able to make contact with inhabitants of advanced worlds, with the kingdom of light, by way of good and appealing thoughts for help at times of spiritual hardship.... which will then be given to him spiritually.... but that it is not advisable for him to call on beings on other stars whose spiritual degree of maturity and their ability to offer spiritual help is unknown to him.
<G-vec00092-001-s157><call.anrufen><de> Wir haben versucht, den Besitzer anzurufen, aber die Telefonnummer in der Reservierungsbestätigung war falsch.
<G-vec00092-001-s157><call.anrufen><en> We tried to call the owner, but the phone number in the reservation confirmation was wrong.
<G-vec00092-001-s158><call.anrufen><de> Sollten Sie Fragen haben, zögern Sie nicht, das Kontaktformular zu nutzen oder uns direkt anzurufen.
<G-vec00092-001-s158><call.anrufen><en> Should you have further questions, do not hesitate to use the contact form or to call us directly.
<G-vec00092-001-s159><call.anrufen><de> Beispielszene: Joe versucht Mary anzurufen, aber der Operator weiß nicht, wer Mary ist.
<G-vec00092-001-s159><call.anrufen><en> Scenario: Joe is trying to call Mary but the operator doesn't know who Mary is.
<G-vec00092-001-s160><call.anrufen><de> Ich will nicht, daß die Menschen leiden müssen, aber Ich erkenne die Notwendigkeit, sie durch ungewöhnliches Leid auf den rechten Weg zu führen, Ich erkenne ihren oft unbeugsamen Willen, der Mir trotzet und den Ich nicht gewaltsam brechen kann, um nicht seine Vollendung zu gefährden; Ich kann also diesen Willen nur zu wandeln suchen durch Mittel, die den Menschen zuletzt selbst bestimmen, Mich anzurufen, um ihnen dann durch Hilfeleistung für ihren Glauben den Beweis zu liefern, daß Ich bin von Ewigkeit zu Ewigkeit und mit Meinen Geschöpfen in unauflösbarer Verbindung stehe.
<G-vec00092-001-s160><call.anrufen><en> I do not want that men must suffer, but I recognize the necessity, to lead them on to the right way through unusual suffering; I recognize their often uncompromising will, which defies me and which I cannot break forcibly to not endanger its perfection; I therefore can only seek to change this will through means, which finally men determine themselves, to call me, to then supply the proof to them through help for their faith that I am from eternity to eternity and stand in indissoluble connection with my creatures.
<G-vec00092-001-s161><call.anrufen><de> Nach diesem Gespräch erhielt ich keine weiteren Informationen bezüglich der Verlängerung meines Passes und so entschloss ich mich, das Konsulat anzurufen um zu erfahren, wie der Stand der Dinge sei.
<G-vec00092-001-s161><call.anrufen><en> After that talk, I never received any further information regarding my passport, so I decided to call the Consulate to get an update on the situation.
<G-vec00092-001-s162><call.anrufen><de> Sofern wir für die weitere Bearbeitung zusätzliche Informationen benötigen, werden Sie gebeten, uns anzurufen.
<G-vec00092-001-s162><call.anrufen><en> If we need more information before we can complete it, you'll be asked to call us.
<G-vec00092-001-s163><call.anrufen><de> 2007-11-13 22:16:19 - Ein Wirklicher Mann Etwas, die ich die 100%-Stimmung ist finde innen, die Tatsache, daß Männer so schnell sind, Frauen anzurufen Weibchen.
<G-vec00092-001-s163><call.anrufen><en> 2007-11-13 22:16:19 - A real man Something I find 100% humor in is the fact that men are so quick to call women bitches.
<G-vec00092-001-s164><call.anrufen><de> Wir wissen, dass er in seinen eigenen Bittgebeten zu Gott sagte: “Oh Gott, ich bitte Dich bei jedem Namen, mit dem du Dich Selbst bezeichnet hast oder den Du in Deinem Buch offenbart hast oder den Du jemandem von Deiner Schöpfung gelehrt hast oder den Du mit dem Wissen von der Verborgenheit für Dich behalten hast.”[2] Wir werden aufgefordert, Gott mit dem Namen anzurufen, der speziell zu der Art der Sorge und Hilfe, um die wir bitten wollen, passt.
<G-vec00092-001-s164><call.anrufen><en> In his own supplications to God, he is known to have said, “Oh God, I ask you of you by every name that You have named yourself, or that You have revealed in Your book, or that You have taught any of Your creation, or that You have kept hidden in the unseen knowledge with Yourself.”[2] We are encouraged to call upon God by the name that is specific to the kind of care and help we need.
<G-vec00092-001-s165><call.anrufen><de> Um das Mädchen oder den Kerl anzurufen, der gern in einen Film ging, plötzlich ein Ticket zu irgendwo zu kaufen und am Wochenende zu fliegen (oder zu fliegen).
<G-vec00092-001-s165><call.anrufen><en> To call the girl or guy who liked to go to a movie, all of a sudden to buy a ticket to somewhere and go (or fly) on the weekend.
<G-vec00092-001-s166><call.anrufen><de> Mit uns wird eine Gesellschaft eins zwei drei gegründet, es genügt, uns anzurufen oder uns zu schreiben und wir finden gemeinsam die beste Lösung für Sie.
<G-vec00092-001-s166><call.anrufen><en> It’s as easy as one, two, three. three. Just call or write us and together we will find the best solution for you.
<G-vec00092-001-s167><call.anrufen><de> Ich rannte buchstäblich zum Telefon, um ihn anzurufen.
<G-vec00092-001-s167><call.anrufen><en> I literally ran to the phone to call him.
<G-vec00092-001-s168><call.anrufen><de> Schließlich hat jeder das Recht, 911 anzurufen...
<G-vec00092-001-s168><call.anrufen><en> After all, anyone has the right to call 911…
<G-vec00092-001-s169><call.anrufen><de> Sollten Sie den Fahrer Ihres privaten Transfers oder den Vertreter des Shuttle-Transportunternehmens bei der Ankunft am Flughafen nicht finden, liegt es in Ihrer Verantwortung, uns über die 24-Stunden-Telefonnummern, die auf dem Transferbeleg aufgeführt sind, zu kontaktieren Versäumen Sie es, diese Nummern anzurufen, und vereinbaren stattdessen alternative Reisearrangements, wird die Leistung nicht erbracht, das Transportunternehmen wird von seinen Verpflichtungen entbunden und eine Erstattung wird nicht fällig.
<G-vec00092-001-s169><call.anrufen><en> In the event that you are unable to locate the driver of your private transfer or the representative of the shuttle Transport Operator, it is your responsibility to contact us on the 24/7 telephone numbers printed on your Transfer Voucher. If you fail to call these numbers and make alternative travel arrangements, we will be unable to provide the service, the Transport Operator will be relieved of their obligations and a refund will not be due.
<G-vec00092-001-s170><call.anrufen><de> Wenn Sie Ihr Mobiltelefon in anderen EU-Ländern verwenden – um anzurufen, eine SMS zu verschicken oder im Internet zu surfen –, kann Ihnen Ihr Mobilfunkanbieter nicht beliebig viel berechnen.
<G-vec00092-001-s170><call.anrufen><en> When you use your mobile phone in other EU countries – to call, text (send SMS messages) or go online – there's a limit on what your operator can charge you.
<G-vec00272-001-s152><call.anrufen><de> Er bat die Usbeken, ihn für eine Aufnahmesession anzurufen, sobald sie wieder eine Leiche finden würden, die bestattet werden musste.
<G-vec00272-001-s152><call.anrufen><en> He asked the Uzbeks to call him to snap a session, if they suddenly found a new corpse and decide to bury it.
<G-vec00272-001-s153><call.anrufen><de> "In meinem Fall, bin ich sehr traurig, weil ich sie vor 1 1/2 Monaten verloren habe, aber nicht ein Tag vergeht, an dem ich nicht durch die Abspeicherungstaste ""Grosseltern"" am Telefon an sie erinnert werde und das Bedürfnis verspüre, sie anzurufen, um ihre Stimme zu hören."
<G-vec00272-001-s153><call.anrufen><en> "In my case, I am sorrowful, because I lost her 1 1/2 month ago, but it not pass one day, in which I not be remember in her about the memory key ""Grandparents"" of the phone and the need to call her for hear her voice."
<G-vec00272-001-s154><call.anrufen><de> Wenn Sie uns näher kennen lernen wollen, laden wir Sie ein, einen Blick auf unsere Homepage zu werfen oder uns anzurufen oder zu schreiben.
<G-vec00272-001-s154><call.anrufen><en> If you would like to become better acquainted with us, we invite you to take a look at our home page or call us or write to us.
<G-vec00272-001-s155><call.anrufen><de> Die Wahrheit ist, du hast die Macht, Engel anzurufen, um deinen Weg zu beleuchten.
<G-vec00272-001-s155><call.anrufen><en> The truth is, you have the power to call on angels to light your way.
<G-vec00272-001-s156><call.anrufen><de> Die Menschen sollen aber darüber aufgeklärt werden, daß die Erde ein Gestirn für sich ist, das keine Verbindung hat mit anderen Welten, und daß jegliche Bindung mit deren Bewohnern nur geistig herzustellen ist.... daß also sich der Mensch wohl den Bewohnern höherer Welten, des Lichtreiches, verbinden kann durch gute bittende Gedanken um Hilfe in geistiger Not.... die ihm geistig wohl auch geleistet wird.... daß es aber für ihn nicht ratsam ist, Wesen anzurufen von Gestirnen, von denen er nicht weiß, in welchem geistigen Reifegrad diese stehen und ob sie ihm geistige Hilfe gewähren können.
<G-vec00272-001-s156><call.anrufen><en> But people should be informed that earth is a planet on its own which has no connection with other worlds, and that any connection with other worlds can only be spiritually established.... Hence the human being is, in fact, able to make contact with inhabitants of advanced worlds, with the kingdom of light, by way of good and appealing thoughts for help at times of spiritual hardship.... which will then be given to him spiritually.... but that it is not advisable for him to call on beings on other stars whose spiritual degree of maturity and their ability to offer spiritual help is unknown to him.
<G-vec00272-001-s157><call.anrufen><de> Wir haben versucht, den Besitzer anzurufen, aber die Telefonnummer in der Reservierungsbestätigung war falsch.
<G-vec00272-001-s157><call.anrufen><en> We tried to call the owner, but the phone number in the reservation confirmation was wrong.
<G-vec00272-001-s158><call.anrufen><de> Sollten Sie Fragen haben, zögern Sie nicht, das Kontaktformular zu nutzen oder uns direkt anzurufen.
<G-vec00272-001-s158><call.anrufen><en> Should you have further questions, do not hesitate to use the contact form or to call us directly.
<G-vec00272-001-s159><call.anrufen><de> Beispielszene: Joe versucht Mary anzurufen, aber der Operator weiß nicht, wer Mary ist.
<G-vec00272-001-s159><call.anrufen><en> Scenario: Joe is trying to call Mary but the operator doesn't know who Mary is.
<G-vec00272-001-s160><call.anrufen><de> Ich will nicht, daß die Menschen leiden müssen, aber Ich erkenne die Notwendigkeit, sie durch ungewöhnliches Leid auf den rechten Weg zu führen, Ich erkenne ihren oft unbeugsamen Willen, der Mir trotzet und den Ich nicht gewaltsam brechen kann, um nicht seine Vollendung zu gefährden; Ich kann also diesen Willen nur zu wandeln suchen durch Mittel, die den Menschen zuletzt selbst bestimmen, Mich anzurufen, um ihnen dann durch Hilfeleistung für ihren Glauben den Beweis zu liefern, daß Ich bin von Ewigkeit zu Ewigkeit und mit Meinen Geschöpfen in unauflösbarer Verbindung stehe.
<G-vec00272-001-s160><call.anrufen><en> I do not want that men must suffer, but I recognize the necessity, to lead them on to the right way through unusual suffering; I recognize their often uncompromising will, which defies me and which I cannot break forcibly to not endanger its perfection; I therefore can only seek to change this will through means, which finally men determine themselves, to call me, to then supply the proof to them through help for their faith that I am from eternity to eternity and stand in indissoluble connection with my creatures.
<G-vec00272-001-s161><call.anrufen><de> Nach diesem Gespräch erhielt ich keine weiteren Informationen bezüglich der Verlängerung meines Passes und so entschloss ich mich, das Konsulat anzurufen um zu erfahren, wie der Stand der Dinge sei.
<G-vec00272-001-s161><call.anrufen><en> After that talk, I never received any further information regarding my passport, so I decided to call the Consulate to get an update on the situation.
<G-vec00272-001-s162><call.anrufen><de> Sofern wir für die weitere Bearbeitung zusätzliche Informationen benötigen, werden Sie gebeten, uns anzurufen.
<G-vec00272-001-s162><call.anrufen><en> If we need more information before we can complete it, you'll be asked to call us.
<G-vec00272-001-s163><call.anrufen><de> 2007-11-13 22:16:19 - Ein Wirklicher Mann Etwas, die ich die 100%-Stimmung ist finde innen, die Tatsache, daß Männer so schnell sind, Frauen anzurufen Weibchen.
<G-vec00272-001-s163><call.anrufen><en> 2007-11-13 22:16:19 - A real man Something I find 100% humor in is the fact that men are so quick to call women bitches.
<G-vec00272-001-s164><call.anrufen><de> Wir wissen, dass er in seinen eigenen Bittgebeten zu Gott sagte: “Oh Gott, ich bitte Dich bei jedem Namen, mit dem du Dich Selbst bezeichnet hast oder den Du in Deinem Buch offenbart hast oder den Du jemandem von Deiner Schöpfung gelehrt hast oder den Du mit dem Wissen von der Verborgenheit für Dich behalten hast.”[2] Wir werden aufgefordert, Gott mit dem Namen anzurufen, der speziell zu der Art der Sorge und Hilfe, um die wir bitten wollen, passt.
<G-vec00272-001-s164><call.anrufen><en> In his own supplications to God, he is known to have said, “Oh God, I ask you of you by every name that You have named yourself, or that You have revealed in Your book, or that You have taught any of Your creation, or that You have kept hidden in the unseen knowledge with Yourself.”[2] We are encouraged to call upon God by the name that is specific to the kind of care and help we need.
<G-vec00272-001-s165><call.anrufen><de> Um das Mädchen oder den Kerl anzurufen, der gern in einen Film ging, plötzlich ein Ticket zu irgendwo zu kaufen und am Wochenende zu fliegen (oder zu fliegen).
<G-vec00272-001-s165><call.anrufen><en> To call the girl or guy who liked to go to a movie, all of a sudden to buy a ticket to somewhere and go (or fly) on the weekend.
<G-vec00272-001-s166><call.anrufen><de> Mit uns wird eine Gesellschaft eins zwei drei gegründet, es genügt, uns anzurufen oder uns zu schreiben und wir finden gemeinsam die beste Lösung für Sie.
<G-vec00272-001-s166><call.anrufen><en> It’s as easy as one, two, three. three. Just call or write us and together we will find the best solution for you.
<G-vec00272-001-s167><call.anrufen><de> Ich rannte buchstäblich zum Telefon, um ihn anzurufen.
<G-vec00272-001-s167><call.anrufen><en> I literally ran to the phone to call him.
<G-vec00272-001-s168><call.anrufen><de> Schließlich hat jeder das Recht, 911 anzurufen...
<G-vec00272-001-s168><call.anrufen><en> After all, anyone has the right to call 911…
<G-vec00272-001-s169><call.anrufen><de> Sollten Sie den Fahrer Ihres privaten Transfers oder den Vertreter des Shuttle-Transportunternehmens bei der Ankunft am Flughafen nicht finden, liegt es in Ihrer Verantwortung, uns über die 24-Stunden-Telefonnummern, die auf dem Transferbeleg aufgeführt sind, zu kontaktieren Versäumen Sie es, diese Nummern anzurufen, und vereinbaren stattdessen alternative Reisearrangements, wird die Leistung nicht erbracht, das Transportunternehmen wird von seinen Verpflichtungen entbunden und eine Erstattung wird nicht fällig.
<G-vec00272-001-s169><call.anrufen><en> In the event that you are unable to locate the driver of your private transfer or the representative of the shuttle Transport Operator, it is your responsibility to contact us on the 24/7 telephone numbers printed on your Transfer Voucher. If you fail to call these numbers and make alternative travel arrangements, we will be unable to provide the service, the Transport Operator will be relieved of their obligations and a refund will not be due.
<G-vec00272-001-s170><call.anrufen><de> Wenn Sie Ihr Mobiltelefon in anderen EU-Ländern verwenden – um anzurufen, eine SMS zu verschicken oder im Internet zu surfen –, kann Ihnen Ihr Mobilfunkanbieter nicht beliebig viel berechnen.
<G-vec00272-001-s170><call.anrufen><en> When you use your mobile phone in other EU countries – to call, text (send SMS messages) or go online – there's a limit on what your operator can charge you.
<G-vec00092-001-s608><call.anrufen><de> Wenn sie sich den Urlaub ohne Sorgen wünschen, rufen Sie sie an, und sie werden sie auf die gefragte Stelle bringen.
<G-vec00092-001-s608><call.anrufen><en> For relaxed vacation moments, call them and they will take you to the desired location.
<G-vec00092-001-s609><call.anrufen><de> Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zumarketing@kse.nlfür kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00092-001-s609><call.anrufen><en> Call +31 (0)497 383818 or e-mail marketing@kse.nl to request free entry tickets or to pre-arrange an appointment at the event.
<G-vec00092-001-s610><call.anrufen><de> Besuchen Sie KSE auf Stand G028 in Halle 5.Â Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zu marketing@kse.nlÂ für kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00092-001-s610><call.anrufen><en> Visit KSE on stand G028 in hall 5.Â Call +31 (0)497 383818 or e-mail marketing@kse.nlÂ to request free entry tickets or to pre-arrange an appointment on the stand.
<G-vec00092-001-s611><call.anrufen><de> Rufen Sie uns an.
<G-vec00092-001-s611><call.anrufen><en> Please call:
<G-vec00092-001-s612><call.anrufen><de> Bitte rufen Sie uns während der Öffnungszeiten an.
<G-vec00092-001-s612><call.anrufen><en> Please call us at the opening times.
<G-vec00092-001-s613><call.anrufen><de> Reservierungen sind unabdingbar, um bedient zu werden, rufen Sie deshalb unbedingt im Vorfeld an.
<G-vec00092-001-s613><call.anrufen><en> The cafe is strictly reservation only, so make sure to call in advance.
<G-vec00092-001-s614><call.anrufen><de> Rufen Sie uns an, sofern Sie im Zweifel sind oder selbst Rat und Auskunft benötigen.
<G-vec00092-001-s614><call.anrufen><en> Call if you are in doubt or need advice and information yourself.
<G-vec00092-001-s615><call.anrufen><de> Rufen Sie uns an (oder lassen Sie Ihren Anwalt anrufen) um weitere Informationen zu bekommen: Tel.
<G-vec00092-001-s615><call.anrufen><en> Please call (or have your lawyer call) us for more details: Tel.
<G-vec00092-001-s616><call.anrufen><de> Rufen Sie uns einfach an oder senden Sie uns eine E- Mail.
<G-vec00092-001-s616><call.anrufen><en> Just call us or send us e-mail.
<G-vec00092-001-s617><call.anrufen><de> und ausführlichere Informationen finden Sie auf unserer Homepage oder rufen Sie uns an.
<G-vec00092-001-s617><call.anrufen><en> You can find more detailed information on our homepage Or call us
<G-vec00092-001-s618><call.anrufen><de> Nur Experten rufen an, aber dann geben sie keine Garantie.
<G-vec00092-001-s618><call.anrufen><en> Only experts call, but then they do not give a guarantee.
<G-vec00092-001-s619><call.anrufen><de> Rufen Sie die 150 an und folgen Sie den Sprachanweisungen, um die Scratch-Karte auf Ihre SIM-Karte aufzuladen.
<G-vec00092-001-s619><call.anrufen><en> Call 150 and follow voice prompts to enter scratch card details.
<G-vec00092-001-s620><call.anrufen><de> Rufen Sie an und organisieren...
<G-vec00092-001-s620><call.anrufen><en> Call and organize all your...
<G-vec00092-001-s621><call.anrufen><de> Oder rufen Sie uns einfach an.
<G-vec00092-001-s621><call.anrufen><en> Or simply call us.
<G-vec00092-001-s622><call.anrufen><de> Bitte rufen Sie an, wenn Ihr Fahrzeug höher als 1,95 m ist.
<G-vec00092-001-s622><call.anrufen><en> Please call if your vehicle is higher than 1.95 metres
<G-vec00092-001-s623><call.anrufen><de> Besuchen Sie KSE auf Stand B7878, Halle B. Rufen Sie an: +31 (0)497 383818 oder senden Sie eine E-Mail:marketing@kse.nlfür kostenlose Eintrittskarten oder für einen vorher vereinbarten Termin auf der Stand.
<G-vec00092-001-s623><call.anrufen><en> Visit KSE on stand B7878, hall B. Call +31 (0)497 383818 or e-mailmarketing@kse.nlto request free entry tickets or to pre-arrange an appointment on the stand. During the IPPE, KSE gives a TECHTalk with the title ‘Dosing Slide vs. Dosing Screw.
<G-vec00092-001-s624><call.anrufen><de> Rufen Sie uns fÃ1⁄4r weitere Informationen an.
<G-vec00092-001-s624><call.anrufen><en> Call us for more information.
<G-vec00092-001-s625><call.anrufen><de> Rufen Sie uns an, oder senden Sie uns eine mail, schnell erhalten Sie Ihren ganz persönlichen Gutschein zum verschenken.
<G-vec00092-001-s625><call.anrufen><en> Call us, or send us an e-mail, and you will quickly receive your personalized gift certificate.
<G-vec00092-001-s626><call.anrufen><de> Rufen Sie uns an Maut.
<G-vec00092-001-s626><call.anrufen><en> Call us toll free.
<G-vec00272-001-s608><call.anrufen><de> Wenn sie sich den Urlaub ohne Sorgen wünschen, rufen Sie sie an, und sie werden sie auf die gefragte Stelle bringen.
<G-vec00272-001-s608><call.anrufen><en> For relaxed vacation moments, call them and they will take you to the desired location.
<G-vec00272-001-s609><call.anrufen><de> Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zumarketing@kse.nlfür kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00272-001-s609><call.anrufen><en> Call +31 (0)497 383818 or e-mail marketing@kse.nl to request free entry tickets or to pre-arrange an appointment at the event.
<G-vec00272-001-s610><call.anrufen><de> Besuchen Sie KSE auf Stand G028 in Halle 5.Â Rufen Sie an: +31 497 383818 oder senden Sie eine E-Mail zu marketing@kse.nlÂ für kostenlose Eintrittskarten oder um einen Termin am Stand zu verabreden.
<G-vec00272-001-s610><call.anrufen><en> Visit KSE on stand G028 in hall 5.Â Call +31 (0)497 383818 or e-mail marketing@kse.nlÂ to request free entry tickets or to pre-arrange an appointment on the stand.
<G-vec00272-001-s611><call.anrufen><de> Rufen Sie uns an.
<G-vec00272-001-s611><call.anrufen><en> Please call:
<G-vec00272-001-s612><call.anrufen><de> Bitte rufen Sie uns während der Öffnungszeiten an.
<G-vec00272-001-s612><call.anrufen><en> Please call us at the opening times.
<G-vec00272-001-s613><call.anrufen><de> Reservierungen sind unabdingbar, um bedient zu werden, rufen Sie deshalb unbedingt im Vorfeld an.
<G-vec00272-001-s613><call.anrufen><en> The cafe is strictly reservation only, so make sure to call in advance.
<G-vec00272-001-s614><call.anrufen><de> Rufen Sie uns an, sofern Sie im Zweifel sind oder selbst Rat und Auskunft benötigen.
<G-vec00272-001-s614><call.anrufen><en> Call if you are in doubt or need advice and information yourself.
<G-vec00272-001-s615><call.anrufen><de> Rufen Sie uns an (oder lassen Sie Ihren Anwalt anrufen) um weitere Informationen zu bekommen: Tel.
<G-vec00272-001-s615><call.anrufen><en> Please call (or have your lawyer call) us for more details: Tel.
<G-vec00272-001-s616><call.anrufen><de> Rufen Sie uns einfach an oder senden Sie uns eine E- Mail.
<G-vec00272-001-s616><call.anrufen><en> Just call us or send us e-mail.
<G-vec00272-001-s617><call.anrufen><de> und ausführlichere Informationen finden Sie auf unserer Homepage oder rufen Sie uns an.
<G-vec00272-001-s617><call.anrufen><en> You can find more detailed information on our homepage Or call us
<G-vec00272-001-s618><call.anrufen><de> Nur Experten rufen an, aber dann geben sie keine Garantie.
<G-vec00272-001-s618><call.anrufen><en> Only experts call, but then they do not give a guarantee.
<G-vec00272-001-s619><call.anrufen><de> Rufen Sie die 150 an und folgen Sie den Sprachanweisungen, um die Scratch-Karte auf Ihre SIM-Karte aufzuladen.
<G-vec00272-001-s619><call.anrufen><en> Call 150 and follow voice prompts to enter scratch card details.
<G-vec00272-001-s620><call.anrufen><de> Rufen Sie an und organisieren...
<G-vec00272-001-s620><call.anrufen><en> Call and organize all your...
<G-vec00272-001-s621><call.anrufen><de> Oder rufen Sie uns einfach an.
<G-vec00272-001-s621><call.anrufen><en> Or simply call us.
<G-vec00272-001-s622><call.anrufen><de> Bitte rufen Sie an, wenn Ihr Fahrzeug höher als 1,95 m ist.
<G-vec00272-001-s622><call.anrufen><en> Please call if your vehicle is higher than 1.95 metres
<G-vec00272-001-s623><call.anrufen><de> Besuchen Sie KSE auf Stand B7878, Halle B. Rufen Sie an: +31 (0)497 383818 oder senden Sie eine E-Mail:marketing@kse.nlfür kostenlose Eintrittskarten oder für einen vorher vereinbarten Termin auf der Stand.
<G-vec00272-001-s623><call.anrufen><en> Visit KSE on stand B7878, hall B. Call +31 (0)497 383818 or e-mailmarketing@kse.nlto request free entry tickets or to pre-arrange an appointment on the stand. During the IPPE, KSE gives a TECHTalk with the title ‘Dosing Slide vs. Dosing Screw.
<G-vec00272-001-s624><call.anrufen><de> Rufen Sie uns fÃ1⁄4r weitere Informationen an.
<G-vec00272-001-s624><call.anrufen><en> Call us for more information.
<G-vec00272-001-s625><call.anrufen><de> Rufen Sie uns an, oder senden Sie uns eine mail, schnell erhalten Sie Ihren ganz persönlichen Gutschein zum verschenken.
<G-vec00272-001-s625><call.anrufen><en> Call us, or send us an e-mail, and you will quickly receive your personalized gift certificate.
<G-vec00272-001-s626><call.anrufen><de> Rufen Sie uns an Maut.
<G-vec00272-001-s626><call.anrufen><en> Call us toll free.
