<G-vec00060-001-s019><release.abgeben><de> Abhängig von der Temperatur ist die Umgebungsluft in der Lage, einen bestimmten Wasseranteil zu absorbieren und kann die Feuchtigkeit auch wieder an die Umgebung abgeben.
<G-vec00060-001-s019><release.abgeben><en> Depending on the temperature, ambient air is able to absorb a certain percentage of water and it can also release its humidity to the environment.
<G-vec00060-001-s020><release.abgeben><de> Das hängt davon ab, ob wir weiter so viel CO2 in die Atmosphäre abgeben wie bisher.
<G-vec00060-001-s020><release.abgeben><en> That depends on whether we continue to release as much CO2 into the atmosphere as we are doing now.
<G-vec00060-001-s021><release.abgeben><de> Die Merinowolle kann große Mengen Wasserdampf aufnehmen und wieder abgeben (besser als Kunstfaser).
<G-vec00060-001-s021><release.abgeben><en> Merino wool can absorb and release large quantities of moisture (better than synthetic fibers).
<G-vec00060-001-s022><release.abgeben><de> Hinzu kommt, dass die Kathoden bei starker Erhitzuung Sauerstoff abgeben können und somit der Brand ohne externe Luftzufuhr aufrechterhalten werden kann.
<G-vec00060-001-s022><release.abgeben><en> Also, the cathode can release oxygen under severe heat and hence the fire can be maintained without an external air supply.
<G-vec00060-001-s023><release.abgeben><de> Massive, freiliegende Gebäudeteile fungieren als Wärmepuffer – sie können tagsüber Wärme aufnehmen und diese während der Nacht wieder abgeben.
<G-vec00060-001-s023><release.abgeben><en> Solid, exposed building components function as heat buffers – they can absorb heat during the day and then release it again at night.
<G-vec00060-001-s024><release.abgeben><de> In Kontakt mit Wasser können diese Flächen Nickel in erheblichem Umfang an das Wasser abgeben.
<G-vec00060-001-s024><release.abgeben><en> In contact with water, these surfaces can release nickel in a significant amount into water.
<G-vec00060-001-s025><release.abgeben><de> Mit freundlicher Genehmigung von NASA / JPL / University of Arizona Um in ihren normalen Zustand zurückzukehren, müssen die Atome entweder chemische Reaktionen eingehen oder die Energie, die sie gerade aufgenommen haben in Form von Licht abgeben.
<G-vec00060-001-s025><release.abgeben><en> Image courtesy of NASA / JPL / University of Arizona To return to their normal state, they must either undergo chemical reactions or release the energy they have just absorbed as light.
<G-vec00060-001-s026><release.abgeben><de> Leif muss von seinem deutlichen Plus für RZE im August einen Teil wieder abgeben (RZE 118).
<G-vec00060-001-s026><release.abgeben><en> Leif has to release a part of his clear plus for RZE in August to now 118.
<G-vec00060-001-s027><release.abgeben><de> Nickelelektroden sind allerdings keine gute Wahl, weil sie während der Elektrolyse Nickelionen in die Lösung abgeben.
<G-vec00060-001-s027><release.abgeben><en> Nickel electrodes are not suitable, because they corrode and release nickel ions into the solution.
<G-vec00060-001-s028><release.abgeben><de> In diesem Fall würde die elektroDünnbettheizung nur 10 Watt/m² an den Wohnraum abgeben.
<G-vec00060-001-s028><release.abgeben><en> In this case the floor heating would only release 10 Watt/m² into the room.
<G-vec00060-001-s029><release.abgeben><de> Akustische Sonden, die bei Anregung mit periodisch moduliertem, monochromatischem Licht aufgenommene Energie in Wärme umwandeln und diese an ihre Umgebung abgeben, wurden in Pflegebefilmungen inkludiert.
<G-vec00060-001-s029><release.abgeben><en> Acoustic probes which, when excited with periodically modulated monochromatic light, convert absorbed energy into heat and release it into their environment, were included in floorcare coatings.
<G-vec00060-001-s030><release.abgeben><de> Geldschätze, welche sich an den verschiedensten Punkten anhäufen, bilden Sammelbecken, welche bald Geld aufnehmen, bald wieder abgeben und so Störungen im Zirkulationsprozeß ausgleichen.
<G-vec00060-001-s030><release.abgeben><en> Hoards of money which accumulate in the most diverse places form conduits which serve now to absorb, now to release money, thus neutralising disturbances in the process of circulation.
<G-vec00060-001-s031><release.abgeben><de> Auch der Nachweis, dass die Kapseln, wenn nötig, aber auch nur dann die Heilmittel für Defekte in einem Lack abgeben, ist nicht gerade simpel.
<G-vec00060-001-s031><release.abgeben><en> Moreover, it is not exactly easy to prove that the capsules only release the remedy for healing the defects in a coating when necessary.
<G-vec00060-001-s032><release.abgeben><de> Dieser kann überschüssige Nährstoffe aufnehmen und bei Bedarf wieder abgeben.
<G-vec00060-001-s032><release.abgeben><en> Is capable of storing excess nutrients, to release them again when needed.
<G-vec00060-001-s033><release.abgeben><de> Die Werte sind repräsentativ für eine größere Region: Sie zeigen, wie die Pflanzen im Umkreis von vielen hundert Kilometern im Laufe eines Jahres Kohlendioxid aufnehmen und wieder abgeben.
<G-vec00060-001-s033><release.abgeben><en> The values are representative for a larger region: they show how the plants within a radius of many hundred kilometers take up carbon dioxide and release it again over the course of a year.
<G-vec00060-001-s034><release.abgeben><de> Damit eignet sich Tencel optimal für sensible Haut.Tencel-Fasern können durch ihre besondere Struktur 50% mehr Feuchtigkeit aufnehmen und abgeben als Baumwolle.
<G-vec00060-001-s034><release.abgeben><en> This means Tencel is particularly suitable for sensitive skin. Tencel fibres, with their distinctive structure, can absorb and release 50% more moisture than cotton.
<G-vec00060-001-s035><release.abgeben><de> Nach dieser Nutzung werden die Elektronenpakete zum Linearbeschleuniger zurückgeleitet, wo sie nahezu ihre gesamte restliche Energie abgeben.
<G-vec00060-001-s035><release.abgeben><en> After use, the electron bunches are directed back to the superconducting linear accelerator, where they release almost all their remaining energy.
<G-vec00060-001-s036><release.abgeben><de> Seine Blätter und Stängel können Wasser speichern und bei Bedarf abgeben – eine Fähigkeit, die reifer Haut zugutekommt.
<G-vec00060-001-s036><release.abgeben><en> Its leaves and stem can store water and release it if necessary – a skill that greatly benefits mature skin.
<G-vec00060-001-s037><release.abgeben><de> Im Speichel der Stinkwanze gibt es Gift, das sie am Ende der Mahlzeit in die Pflanzen abgeben.
<G-vec00060-001-s037><release.abgeben><en> In the saliva of the stink bug, there is poison that they release into the plants at the end of the meal.
<G-vec00120-001-s015><concede.abgeben><de> Die Mitgliedsstaaten sind zögerlich, Mittel an die EU abzugeben, besonders in der gegenwärtigen ökonomischen Krise.
<G-vec00120-001-s015><concede.abgeben><en> Member states are reluctant to concede their resources to the EU, especially during the current economic crisis.
<G-vec00120-001-s064><concede.abgeben><de> Andererseits könnten gedemütigte Demokraten eher bereit sein, genug Boden an die andere Seite für die vorstehend erwähnten Infrastrukturpläne abzugeben.
<G-vec00120-001-s064><concede.abgeben><en> On the other, humbled Democrats may be more willing to concede enough ground to the other side for the aforementioned infrastructure plan to get off the ground.
<G-vec00078-001-s248><vote.abgeben><de> Theoretisch sind Araber berechtigt, bei den Gemeindewahlen ihre Stimme abzugeben, aber nur wenige taten dies – aus denselben Gründen.
<G-vec00078-001-s248><vote.abgeben><en> In theory, Arabs are entitled to vote in municipal elections, but only a handful do so, for the same reasons.
<G-vec00078-001-s249><vote.abgeben><de> ist dazu eingeladen, eine Stimme abzugeben.
<G-vec00078-001-s249><vote.abgeben><en> is invited to cast their vote.
<G-vec00078-001-s250><vote.abgeben><de> Am Eröffnungswochenende ist das Publikum eingeladen, seine Stimme für das Werk eines Künstlers oder einer Künstlerin unter 35 Jahren abzugeben.
<G-vec00078-001-s250><vote.abgeben><en> On the opening weekend the audience is invited to vote for an artistic position by an artist under the age of 35.
<G-vec00078-001-s251><vote.abgeben><de> Der Vorsitzende kam zur Erkenntnis, dass Pala nicht die Anforderungen erfüllt, um bei der Versammlung seine Stimme abzugeben.
<G-vec00078-001-s251><vote.abgeben><en> The Chair ruled that Pala had not met the requirements to vote at the meeting.
<G-vec00078-001-s252><vote.abgeben><de> Um Ihre Stimme abzugeben, geben Sie bitte Ihre E-Mail-Adresse ein und klicken auf den Bestätigungslink, der Ihnen per E-Mail zugesandt wird.
<G-vec00078-001-s252><vote.abgeben><en> To cast your vote, please enter your email address and click on the verification link that will be sent to you via email.
<G-vec00078-001-s253><vote.abgeben><de> Wenn Sie ein registrierter CDI-Inhaber sind und planen, an der Versammlung teilzunehmen und Ihre Stimme persönlich abzugeben, müssen Sie im Stimmabgabeformular IHREN NAMEN als Vollmachtausübender angeben und das Stimmabgabeformular zurücksenden.
<G-vec00078-001-s253><vote.abgeben><en> If you are a registered holder of a CDI and you plan to attend and vote in person at the Meeting, you must provide YOUR NAME as the Proxy appointee on the voting form and return the voting form as directed.
<G-vec00078-001-s254><vote.abgeben><de> "Bei den griechischen Wahlen haben unsere Genossen von der Trotzkistischen Gruppe Griechenlands dazu aufgerufen, ""keine Stimme für Syriza"" abzugeben, und der Kommunistischen Partei kritische Unterstützung gegeben, die in Opposition zur EU und allen Pro-EU-Parteien einschließlich Syrizas auftrat."
<G-vec00078-001-s254><vote.abgeben><en> "In the Greek elections, our comrades of the Trotskyist Group of Greece called for ""no vote to Syriza"" and gave critical support to the Communist Party, which stood in opposition to the EU and all pro-EU parties, including Syriza."
<G-vec00078-001-s255><vote.abgeben><de> Finnlands offizielles Girlpower-Emoji: 1906 wurde Finnland zum ersten Land der Welt, das ein Gesetz verabschiedete, welches Frauen gestattete, nicht nur ihre Stimme abzugeben, sondern auch für die Wahlen zu kandidieren.
<G-vec00078-001-s255><vote.abgeben><en> Finland's official Girl Power emoji: In 1906, Finland became the first country in the world to pass a law that allowed women both to vote and to run for election.
<G-vec00078-001-s256><vote.abgeben><de> Der interaktive Teil des Experiments ermöglicht es, eine Stimme in jedem Wahlsystem abzugeben.
<G-vec00078-001-s256><vote.abgeben><en> The interactive part of the website allows to cast a vote under each electoral system.
<G-vec00078-001-s257><vote.abgeben><de> Finnland wurde 1906 das erste Land der Welt, das Frauen volle politische Rechte zugestand und ein Gesetz verabschiedete, welches Frauen gestattete, sowohl ihre Stimme abzugeben als auch zu kandidieren.
<G-vec00078-001-s257><vote.abgeben><en> In 1906, Finland became the first country in the world to award women full political rights, passing a law that allowed women both to vote and to run for election.
<G-vec00078-001-s258><vote.abgeben><de> Arbeitnehmer der regionalen Wahlkommission wollen den Wählern nicht nur die Möglichkeit geben, eine Stimme abzugeben, sondern auch die Atmosphäre eines echten Festes zu spüren.
<G-vec00078-001-s258><vote.abgeben><en> Workers of the precinct election commissions intend to provide voters with not only the opportunity to cast a vote, but also to feel the atmosphere of a real holiday.
<G-vec00078-001-s259><vote.abgeben><de> Um dem vorzubeugen, ist es wichtig die eigene Stimme abzugeben.
<G-vec00078-001-s259><vote.abgeben><en> To prevent this, it is important to cast your vote.
<G-vec00078-001-s260><vote.abgeben><de> Im spezifi schen Fall, wo bei einer Abstimmung Briefwahlkarten teilnehmen, werden Vollmachten nicht zur Wahl zugelassen, weil ja jedes Mitglied die Möglichkeit hatte, seine persönliche Stimme durch die Briefwahl abzugeben.
<G-vec00078-001-s260><vote.abgeben><en> In the specific case where a ballot includes postal votes, proxies are not admitted to participate, since every member has had the possibility of casting his personal postal vote.
<G-vec00078-001-s261><vote.abgeben><de> Nur 87 Personen, von denen einige bestochen waren (von 1800 Einwohnern) hatten die Gelegenheit, ihre Stimme abzugeben, und das nur zustimmend.
<G-vec00078-001-s261><vote.abgeben><en> Only 87 people, some of whom were bribed (out of 1800 residents) had an opportunity to cast a vote, by applause only.
<G-vec00078-001-s262><vote.abgeben><de> Am Triennale Eröffnungswochenende war das Publikum eingeladen, seine Stimme für das Werk eines Künstlers oder einer Künstlerin unter 35 Jahren abzugeben.
<G-vec00078-001-s262><vote.abgeben><en> During the opening weekend (Thu, June 3 - Sat, June 5) the public is invited to vote for the work of an artist under 35 years.
<G-vec00078-001-s263><vote.abgeben><de> Den Finnen wurde das schon früh bewusst: Finnland war 1906 das erste Land der Welt, das ein Gesetz verabschiedete, welches Frauen gestattete, sowohl ihre Stimme abzugeben als auch gewählt zu werden.
<G-vec00078-001-s263><vote.abgeben><en> Finns noticed this early; in 1906 Finland became the first country in the world to pass a law that allowed women both to vote and to run for election.
<G-vec00301-002-s197><rectify.abgeben><de> Sie können Ihr Recht auf Korrektur ausüben, indem Sie eine ergänzende Erklärung an die für die Verarbeitung Verantwortliche abgeben.
<G-vec00301-002-s197><rectify.abgeben><en> You can exercise your right to rectify by providing an additional declaration to the Data Controller.
<G-vec00311-002-s142><vow.abgeben><de> Lionel ging in die Politik und wurde sechs Mal in London gewählt, ohne den obligatorischen Schwur auf den christlichen Glauben abzugeben, sodass er jedes Mal geblockt wurde.
<G-vec00311-002-s142><vow.abgeben><en> Lionel went into politics and was elected six times in London without making the obligatory vow on the Christian faith, so that he was blocked each time.
<G-vec00380-002-s009><abdicate.abgeben><de> 1567 Mary, Königin der Schotten, wird gezwungen, den Thron abzugeben.
<G-vec00380-002-s009><abdicate.abgeben><en> 1567 Mary, Queen of Scots, is forced to abdicate the throne.
<G-vec00380-002-s166><dispense.abgeben><de> [0023] Die "Subjective Logic" ermöglicht es einem Experten eine Bewertung sehr intuitiv als eine "Subjective Opinion" mit Hilfe eines Opinion-Dreiecks abzugeben.
<G-vec00380-002-s166><dispense.abgeben><en> Die „Subjective Logic" The "Subjective Logic" allows an Expert Be ¬ valuation very intuitive as a "Subjective Opinion" dispense with the aid of an Opinion triangle.
