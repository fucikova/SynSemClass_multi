<G-vec00001-001-s076><form.ausfüllen><de> Wenn Sie das Antragsformular auf der Seite für zusätzliche Informationen zu diesem Dienst ausfüllen, können wir Ihnen Informationen auch über Ihre E-Mail-Adresse zuschicken.
<G-vec00001-001-s076><form.ausfüllen><en> If you complete the request form on the Site for additional information about the Service, we may also use your email address to send you information.
<G-vec00001-001-s077><form.ausfüllen><de> Clients müssen nur ihre Nation des Hauses wählen, wenn ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s077><form.ausfüllen><en> Clients just have to pick their country of residence when completing their specifics on the order form.
<G-vec00001-001-s078><form.ausfüllen><de> Verbraucher haben einfach, ihr Land von Haus zu wählen, wenn Sie ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s078><form.ausfüllen><en> Consumers simply have to pick their nation of house when completing their specifics on the order form.
<G-vec00001-001-s079><form.ausfüllen><de> Clients müssen nur ihr Land von zu Hause auswählen, wenn ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s079><form.ausfüllen><en> Customers simply need to pick their country of home when filling out their specifics on the order form.
<G-vec00001-001-s080><form.ausfüllen><de> Verbraucher müssen nur ihre Nation von zu Hause auswählen, wenn Sie ihre Besonderheiten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s080><form.ausfüllen><en> Customers merely need to pick their nation of residence when filling out their details on the order form.
<G-vec00001-001-s081><form.ausfüllen><de> Kunden müssen nur ihr Land von zu Hause abholen, wenn Sie ihre Daten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s081><form.ausfüllen><en> Customers simply have to select their country of residence when filling in their specifics on the order form.
<G-vec00001-001-s082><form.ausfüllen><de> Allen voran sei da das automatische Ausfüllen von Formularen erwähnt, hinzu kommen veränderbare Icons mit Kontextmenüs, Bild-in-Bild, verbessertes Bluetooth, App-Links für markierte Textpassagen, Support für mehrere Displays und Vorbereitung für Themes mit Substratum sind nur einige der Vorzüge des großen Updates.
<G-vec00001-001-s082><form.ausfüllen><en> The first improvement that deserves mention is automatic form filling followed by changeable icons with context menus, Picture-In-Picture, improved Bluetooth, app links for highlighted text massages, support for multiple displays and theme preparation using Substratum, all of which are some of the benefits of this major update.
<G-vec00001-001-s083><form.ausfüllen><de> Das Ausfüllen des Online-Bogens dauert dann höchstens 5 Minuten.
<G-vec00001-001-s083><form.ausfüllen><en> Completing the online form will take no longer than 5 minutes.
<G-vec00001-001-s084><form.ausfüllen><de> Verbraucher müssen einfach nur ihr Land von Haus zu wählen, wenn ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s084><form.ausfüllen><en> Consumers merely need to choose their nation of home when completing their details on the order form.
<G-vec00001-001-s085><form.ausfüllen><de> Kunden müssen einfach ihre Nation von zu Hause zu holen, wenn ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s085><form.ausfüllen><en> Consumers just have to pick their nation of residence when filling in their information on the order form.
<G-vec00001-001-s086><form.ausfüllen><de> Um auf diesen Foren interagieren zu können, muss eine Person zuerst das entsprechende Anmeldeformular ausfüllen.
<G-vec00001-001-s086><form.ausfüllen><en> In order to interact in these forums, an individual must first complete the applicable registration form.
<G-vec00001-001-s087><form.ausfüllen><de> Verbraucher müssen lediglich ihre Nation des Hauses wählen, wenn Sie ihre Besonderheiten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s087><form.ausfüllen><en> Consumers just have to choose their country of home when filling out their details on the order form.
<G-vec00001-001-s088><form.ausfüllen><de> Kunden müssen lediglich Land Ihres Wohnsitzes wählen, wenn ihre Besonderheiten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s088><form.ausfüllen><en> Clients simply need to pick their country of house when completing their specifics on the order form.
<G-vec00001-001-s089><form.ausfüllen><de> Verbraucher müssen lediglich ihr Land von Haus zu holen, wenn ihre Daten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s089><form.ausfüllen><en> Consumers merely need to pick their country of residence when filling out their details on the order form.
<G-vec00001-001-s090><form.ausfüllen><de> Kunden müssen lediglich ihr Land von zu Hause zu wählen, wenn Sie ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s090><form.ausfüllen><en> Clients just have to pick their nation of house when filling in their information on the order form.
<G-vec00001-001-s091><form.ausfüllen><de> Verbraucher müssen einfach Land Ihres Wohnsitzes zu wählen, wenn Sie ihre Besonderheiten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s091><form.ausfüllen><en> Consumers just need to pick their country of residence when filling in their information on the order form.
<G-vec00001-001-s092><form.ausfüllen><de> Kunden müssen einfach Land Ihres Wohnsitzes zu holen, wenn ihre Daten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s092><form.ausfüllen><en> Customers simply have to choose their country of residence when completing their details on the order form.
<G-vec00001-001-s093><form.ausfüllen><de> Kunden müssen nur Land Ihres Wohnsitzes wählen, wenn Sie ihre Besonderheiten auf dem Bestellformular ausfüllen.
<G-vec00001-001-s093><form.ausfüllen><en> Clients simply need to choose their country of residence when completing their specifics on the order form.
<G-vec00001-001-s094><form.ausfüllen><de> Verbraucher müssen lediglich ihre Nation des Wohnsitzes zu holen, wenn Sie ihre Informationen auf dem Bestellformular ausfüllen.
<G-vec00001-001-s094><form.ausfüllen><en> Customers merely need to pick their nation of house when filling out their specifics on the order form.
<G-vec00213-002-s152><complete.ausfüllen><de> Bitte lassen Sie es von Ihrem Arzt ausfüllen und schicken es uns über meda@brusselsairlines.com oder per Fax (+32 2 723 3705).
<G-vec00213-002-s152><complete.ausfüllen><en> Please don't forget to let your physician complete it, and return it via meda@brusselsairlines.com or fax (+32 2 723 3705).
<G-vec00213-002-s153><complete.ausfüllen><de> Wenn Sie das Antragsformular auf der Seite für zusätzliche Informationen zu diesem Dienst ausfüllen, können wir Ihnen Informationen auch über Ihre E-Mail-Adresse zuschicken.
<G-vec00213-002-s153><complete.ausfüllen><en> If you complete the request form on the Site for additional information about the Service, we may also use your email address to send you information.
<G-vec00213-002-s154><complete.ausfüllen><de> Das Ausfüllen des Fragebogens dauert im Durchschnitt weniger als 1 Minute.
<G-vec00213-002-s154><complete.ausfüllen><en> On average, the quiz takes less than 1 minute to complete.
<G-vec00213-002-s155><complete.ausfüllen><de> Vorgänge mit langer Lebensdauer umfassen möglicherweise Systeme oder gehen über das Unternehmen hinaus, beispielsweise wenn ein Kunde ein Antragsformular für eine Hypothek ausfüllen und einreichen muss und dies Teil einer umfangreicheren Lösung ist, die mehrere automatisierte und von Menschen durchgeführte Aufgaben umfasst.
<G-vec00213-002-s155><complete.ausfüllen><en> Long-lived operations may span systems or even extend beyond the organization, such as when a client must complete and submit a loan application form as part of a larger solution that integrates multiple automated and human tasks.
<G-vec00213-002-s156><complete.ausfüllen><de> Zugriff auf Formulare und Dokumente – jederzeit und überall: Bewerber und Mitarbeiter können Dokumente zuverlässig und bequem ausfüllen, mit einer rechtsgültigen elektronischen Unterschrift versehen und zurücksenden – auf dem Gerät ihrer Wahl.
<G-vec00213-002-s156><complete.ausfüllen><en> Anyone can access forms and documents from anywhere. Applicants and employees can complete, e-sign, and return documents — legally and securely, with the device that’s most convenient for them.
<G-vec00213-002-s157><complete.ausfüllen><de> Wenn Sie ein Formular auf unserer Website ausfüllen und absenden, uns eine E-Mail oder uns telefonisch kontaktieren, um Informationen über unsere Dienstleistungen oder das Unternehmen im Allgemeinen zu erhalten, kann Correct.email die Anfragen und deren Inhalt speichern.
<G-vec00213-002-s157><complete.ausfüllen><en> If you complete and submit a form on our Website, send us an email or contact us by telephone with the aim of obtaining information about our services or the company in general, Correct.email may store the inquiries and their contents.
<G-vec00213-002-s158><complete.ausfüllen><de> Um am Gewinnspiel teilzunehmen, ist ein Ausfüllen und Absenden des angezeigten Teilnahmeformulars notwendig.
<G-vec00213-002-s158><complete.ausfüllen><en> In order to participate in the contest, you must complete and submit the displayed participation form, which comprises registration to receive the Context Solar newsletter.
<G-vec00213-002-s159><complete.ausfüllen><de> Zum Beispiel erheben wir die persönlichen Angaben, die Sie uns über sich mitteilen, wenn Sie unsere Online-Formulare ausfüllen, wenn Sie über die „Kontakt“-Seite unserer Webseite Informationen anfordern, oder wenn Sie uns eine E-Mail schicken.
<G-vec00213-002-s159><complete.ausfüllen><en> For example, we collect the personal information you tell us about yourself when you complete our online forms, when you request information through the "Contact Us" page of our website, or when you send us an e-mail.
<G-vec00213-002-s160><complete.ausfüllen><de> Soweit gesetzlich erforderlich, kann der Teilnehmer zum Ausfüllen von bundes-, landes-, provinz- oder regionalweit geltenden Steuerformularen und zum Zahlen von Steuern für den erhaltenen Preis verpflichtet sein.
<G-vec00213-002-s160><complete.ausfüllen><en> Where required by law, Participant may be obligated to complete federal, state, provincial or local country tax forms and pay taxes against the prize obtained.
<G-vec00213-002-s161><complete.ausfüllen><de> Geben Sie den Schülern vor dem Lesen das Zeichentabellen-Arbeitsblatt, das Sie ausfüllen möchten, damit sich die Schüler mit den Charakternamen vertraut machen und beim Lesen darauf achten können.
<G-vec00213-002-s161><complete.ausfüllen><en> Give students the character map worksheet you wish them to complete before reading, so students can familiarize themselves with character names and be watching for them as they read.
<G-vec00213-002-s162><complete.ausfüllen><de> Wir senden Ihnen dann einen offiziellen Auszahlungsantrag zu, den Sie ausfüllen und zurücksenden müssen.
<G-vec00213-002-s162><complete.ausfüllen><en> We will send you an official “Withdrawal Request” form, which you must complete and return.
<G-vec00213-002-s163><complete.ausfüllen><de> Das Anmeldeformular bitte ausfüllen, speichern und ausdrucken.
<G-vec00213-002-s163><complete.ausfüllen><en> Complete, save, and print the Application Form.
<G-vec00213-002-s164><complete.ausfüllen><de> In den meisten Fällen erhalten wir Ihre personenbezogenen Daten von Ihnen selbst, etwa wenn Sie uns einen Auftrag für eine juristische oder steuerberaterliche Dienstleistung erteilen, wenn Sie unsere Website besuchen, ein Formular auf unserer Website ausfüllen, sich bei uns bewerben, uns Ihre Visitenkarte aushändigen, oder aus Informationen, die wir im Rahmen von (Telefon-)Gesprächen und E-Mail-Kontakten mit Ihnen erhalten.
<G-vec00213-002-s164><complete.ausfüllen><en> In most cases, we acquire your personal data from you, for example if you ask us to carry out an assignment for legal or taks services, you visit our website, you complete a form on our website, you apply for a job with us, you give us your business card or from information we acquire during (telephone) conversations and e-mail contact with you.
<G-vec00213-002-s165><complete.ausfüllen><de> Mit Dr. Tax Privat erstellen Lohnempfänger ihre Arbeitnehmerveranlagung rasch und unkompliziert und maximieren gleichzeitig ihre Steuerrückerstattung: Die benutzerfreundliche Software führt den Anwender mit Hilfe eines Eingabeassistenten Schritt für Schritt durch die so genannte Lohnsteuererklärung und unterstützt ihn mit einer kontextsensitiven Hilfefunktion beim Ausfüllen der amtlichen Formulare.
<G-vec00213-002-s165><complete.ausfüllen><en> With Dr. Tax Private wage earners can create their employee assessments quickly and easily and simultaneously maximise their tax refund: The user-friendly software guides the user, with the help of an assistant, step by step through the tax return and helps the user to complete official forms with a context-sensitive help function.
<G-vec00213-002-s166><complete.ausfüllen><de> Wir bei Ecolab verlangen von unseren wichtigsten Lieferanten in den Kategorien Chemikalien, Verpackung, Anlagen und Auftragsfertigung das Ausfüllen der Beurteilungsskala und wir werden weiterhin mehr Lieferanten im größeren Umfang dazu verpflichten, diese Beurteilungsskala auszufüllen.
<G-vec00213-002-s166><complete.ausfüllen><en> Ecolab has required our top suppliers in the chemical, packaging, equipment and contract manufacturing categories to complete the assessment, and we continue to expand the number and scope of suppliers required to complete the assessment.
<G-vec00213-002-s167><complete.ausfüllen><de> Wenn Sie anschließend aus Deutschland ausreisen, lassen Sie sich das Dokument vom deutschen Zoll ausfüllen und an uns zurückschicken.
<G-vec00213-002-s167><complete.ausfüllen><en> As soon as you leave Germany, please have the German customs office complete the form and sent back to you.
<G-vec00213-002-s168><complete.ausfüllen><de> Sie erhalten dann ein Formular, das Sie ausfüllen müssen und an den Betreiber zurücksenden müssen.
<G-vec00213-002-s168><complete.ausfüllen><en> You'll be given a form to complete and return to the toll operator.
<G-vec00213-002-s169><complete.ausfüllen><de> Wenn eine Gutschrift nicht korrekt auf dem Kontoauszug eines Mitglieds erscheint, sollte das Mitglied ein Antragsformular über fehlende Übernachtungen ausfüllen und das Formular dann per Fax oder Post zusammen mit einer Kopie der bezahlten Hotelrechnung an den Kundenservice des Rewards Programms senden.
<G-vec00213-002-s169><complete.ausfüllen><en> If proper credit does not appear on the Member's activity statement, the Member should complete a Missing Stay Request Form, then mail or fax the form, along with a copy of the paid hotel receipt, to the Rewards Program Guest Services listed above.
<G-vec00213-002-s170><complete.ausfüllen><de> 1.8 Sie müssen das Anmeldeformular auf der Anmeldeseite ausfüllen, um Anspruch auf die Dienstleistungen zu haben.
<G-vec00213-002-s170><complete.ausfüllen><en> 1.8 You must complete the registration form on the Sign Up page in order to use the Services.
<G-vec00316-002-s095><fill.ausfüllen><de> Sollten Sie bereits eine konkrete technische Anfrage an uns haben, bitten wir Sie das im Download-Bereich vorhandene Anfrageformular herunter zu laden und uns ausgefüllt per E-Mail oder Post zurück zu schicken.
<G-vec00316-002-s095><fill.ausfüllen><en> ATTENTION! - If you already have a specific technical enquiry, please download our enquiry form in the download area, fill it and send it by email or mail back to us.
<G-vec00316-002-s096><fill.ausfüllen><de> Achtung: Nicht alle Felder müssen ausgefüllt werden.
<G-vec00316-002-s096><fill.ausfüllen><en> Note: You don't have to fill all fields.
<G-vec00316-002-s097><fill.ausfüllen><de> Wenn Sie "Bild strecken (aktuelle Einstellung beibehalten)" anklicken, werden die Proportionen des ausgewählten Bildes beim eventuellen Vergrößern oder Verkleinern beibehalten und die restlichen Flächen des Fensters in der von Ihnen gewählten Farbe ausgefüllt.
<G-vec00316-002-s097><fill.ausfüllen><en> If ‘Stretch image (keep aspect ratio)’ is selected, the image will be stretched to the limit while remaining in correct proportions and the color selected will be used to fill the remaining space.
<G-vec00316-002-s098><fill.ausfüllen><de> Dieses Online-Formular muss ausgefüllt und per E-Mail an hier geschickt werden.
<G-vec00316-002-s098><fill.ausfüllen><en> They must fill out this online form and send it by mail here.
<G-vec00316-002-s099><fill.ausfüllen><de> Hinweis: Das Textfeld „Name“ ist das einzige Textfeld, das bei der Erstellung eines Moderatorenprofils ausgefüllt werden muss.
<G-vec00316-002-s099><fill.ausfüllen><en> Huomautus: The Name text box is the only text box that you must fill in to create a Presenter.
<G-vec00316-002-s100><fill.ausfüllen><de> Klare Anweisungen – Durchschnittlich 20 Kommentare pro Dokument, Vorlagen enthalten klare Anweisungen, was ausgefüllt werden muss - und wie dies geschehen muss.
<G-vec00316-002-s100><fill.ausfüllen><en> Clear guidelines – Averaging 20 comments per document, templates provide clear direction on what to fill in – and how to do so.
<G-vec00316-002-s101><fill.ausfüllen><de> Formulare werden automatisch mit nur einem Klick ausgefüllt.
<G-vec00316-002-s101><fill.ausfüllen><en> It takes just one click to fill out a form.
<G-vec00316-002-s102><fill.ausfüllen><de> Falls der Käufer den Kaufzettel nicht vollständig ausgefüllt oder nicht ordnungsgemäß unterschreibt, kann das Fohlen nach Ermessen der Auktionsleitung nochmals versteigert werden, bei Haftung des ersten Käufers für einen etwaigen Mindererlös.
<G-vec00316-002-s102><fill.ausfüllen><en> If the purchaser does not completely fill in the purchase note or does not correctly sign it, the foal may be put up for auction again on the judgement of the auction management, with the first purchaser being liable for a possible reduction in price.
<G-vec00316-002-s103><fill.ausfüllen><de> Die unebenen Stellen an der Oberfläche werden sorgfältig mit Kleinholz ausgefüllt.
<G-vec00316-002-s103><fill.ausfüllen><en> Small pieces of wood are used to fill in any uneven areas on the surface.
<G-vec00316-002-s104><fill.ausfüllen><de> Pflichtfelder: Wählen Sie die Felder aus, die von allen Nutzern ausgefüllt werden sollen.
<G-vec00316-002-s104><fill.ausfüllen><en> Mandatory fields: Select the fields that you wish all users to fill in.
<G-vec00316-002-s105><fill.ausfüllen><de> Lassen Sie Ihren Körper und Geist sagen Sie, wenn Sie ausgefüllt sind.
<G-vec00316-002-s105><fill.ausfüllen><en> Let your mind and body tell you when you fill.
<G-vec00316-002-s106><fill.ausfüllen><de> In unserem Download-Bereich finden Sie unsere aktuellen Preise und Daten sowie ein ausdruckbares Anmeldeformular, dass Sie uns ausgefüllt per Email zuschicken können.
<G-vec00316-002-s106><fill.ausfüllen><en> In our download section you will find current data & fee sheets with a paper signup form you can fill in and send us back by email.
<G-vec00316-002-s107><fill.ausfüllen><de> Die beim Trimmen entstandenen Lücken werden durch die Clips in der Spur ausgefüllt.
<G-vec00316-002-s107><fill.ausfüllen><en> The clips on the track will close in to fill any gap left by the trim.
<G-vec00316-002-s108><fill.ausfüllen><de> Alle Felder müssen ausgefüllt werden.
<G-vec00316-002-s108><fill.ausfüllen><en> You have to fill out all fields.
<G-vec00316-002-s109><fill.ausfüllen><de> Senden Sie diese bitte ausgefüllt zusammen mit dem Untersuchungsmaterial an die Zentrale Labordiagnostik, Postfach 304120, 20324 Hamburg.
<G-vec00316-002-s109><fill.ausfüllen><en> Please fill in Order Forms and send them together with specimens to BNITM Laboratory Diagnostics, P. O. Box 30 41 20, D-20324 Hamburg, Germany
<G-vec00316-002-s110><fill.ausfüllen><de> Hier können sie den Mitgliedsantrag als PDF herunterladen; den müssen Sie an uns ausgefüllt und unterschrieben zuschicken.
<G-vec00316-002-s110><fill.ausfüllen><en> Here you can download the application form as a pdf file. You must fill it in, sign it and send it to us.
<G-vec00316-002-s111><fill.ausfüllen><de> Dieses Feld muss nur ausgefüllt werden, wenn sich der Eintrag von der normalen Adresse (die für die Felder Name und E-Mail-Adresse auf der Karteikarte Allgemein verwendet wurde) unterscheidet, da Antworten standardmäßig immer an die Absenderadresse geschickt werden.
<G-vec00316-002-s111><fill.ausfüllen><en> Only fill out this field if it is different from your normal address (specified using the Name and Email Address on the General tab), since replies default to the sender's address anyway.
<G-vec00316-002-s112><fill.ausfüllen><de> Erstellen Sie eine eMail-Vorlage, die vom System ausgefüllt und versandt wird.
<G-vec00316-002-s112><fill.ausfüllen><en> Create an email template which the system will fill out and send.
<G-vec00316-002-s113><fill.ausfüllen><de> Vertrieb: Um Releases für Cassette Store Day anzumelden, muss das Formular auf der Webseite ausgefüllt werden.
<G-vec00316-002-s113><fill.ausfüllen><en> Distribution You will need to sign up via the Cassette Store Day website and fill out the form asking for all the gory details about your intended release.
