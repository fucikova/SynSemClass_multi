<G-vec00135-001-s125><embrace.begrüßt><de> Ganz unbestreitbar gibt es auch liberale und sogar progressive Themen, die in diesem Skript am Rande auftauchen, so werden etwa soziale Vielfalt, Kunst und Kultur explizit begrüßt und auch ihre positive wirtschaftliche Bedeutung für metropolitane Innenstädte findet Erwähnung.
<G-vec00135-001-s125><embrace.begrüßt><en> Undeniably, there are liberal and even progressive themes running through the creativity script – notably, its explicit embrace of social diversity, arts, and culture, together with its articulation of a positive economic role for (central) cities.
<G-vec00135-001-s126><embrace.begrüßt><de> Als Teil des Grand Prix-Fahrerlagers beobachtet und begrüßt Aki Ajo derartige Veränderungen schon seit langer Zeit.
<G-vec00135-001-s126><embrace.begrüßt><en> Aki Ajo has long been part of the Grand Prix paddock to observe and embrace such changes.
<G-vec00135-001-s127><embrace.begrüßt><de> "Selbst die normalerweise beunruhigende Wikipedia begrüßt Hansens ""Runaway Greenhouse-Effekt"" auf der Erde nicht."
<G-vec00135-001-s127><embrace.begrüßt><en> "Even the normally alarmist Wikipedia does not embrace Hansen's ""runaway greenhouse effect"" on Earth."
<G-vec00135-001-s128><embrace.begrüßt><de> Du begrüßt andere Sichtweisen und Meinungen, um bessere Entscheidungen zu treffen.
<G-vec00135-001-s128><embrace.begrüßt><en> You nurture and embrace differing perspectives to make better decisions.
