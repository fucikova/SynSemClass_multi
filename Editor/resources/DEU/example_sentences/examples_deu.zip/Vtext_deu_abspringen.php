<G-vec00390-003-s040><bounce_back.abspringen><de> Besucher, die sofort abspringen (was Sie nicht wollen), wenn die alte Webseite weitergeleitet wird, merken: „Das ist nicht die Seite, nach der ich gesucht habe“.
<G-vec00390-003-s040><bounce_back.abspringen><en> Visitors that bounce immediately (which you don’t want) when the old website gets forwarded they realize, “This isn’t the site I was looking for.”
<G-vec00390-003-s041><bounce_back.abspringen><de> Der Ball sollte weder zu hoch noch zu tief abspringen, weder zu schnell noch zu langsam sein und weder zu steil noch zu flach wegspringen.
<G-vec00390-003-s041><bounce_back.abspringen><en> The ball should not bounce too high or too low, should not be too fast or too slow, and a ball hit at an angle should not rebound steeply, nor should it skid quickly off the surface.
<G-vec00390-003-s042><bounce_back.abspringen><de> Wenn Besucher abspringen ist das schlecht fürs Ranking.
<G-vec00390-003-s042><bounce_back.abspringen><en> When people bounce, it’s bad for your rankings.
<G-vec00390-003-s043><bounce_back.abspringen><de> Kontakte zu haben, die ständig abspringen und Ihre E-Mails einfach nicht öffnen sind furchtbar für Ihre Liste.
<G-vec00390-003-s043><bounce_back.abspringen><en> Having contacts that constantly bounce and just plain not open your emails is like cancer to your list.
