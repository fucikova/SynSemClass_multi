<G-vec00242-002-s019><wear.abnutzen><de> Außerdem können sich Bauteile lösen oder einfach abnutzen, was zu Vibrationen und Geräuschen führt.
<G-vec00242-002-s019><wear.abnutzen><en> Parts can also come loose, or just wear out, increasing vibrations and noise.
<G-vec00242-002-s020><wear.abnutzen><de> Es ist wichtig, daran zu erinnern, dass auch nach der anfänglichen Heilung einige Aktivitäten den Katheter abnutzen können.
<G-vec00242-002-s020><wear.abnutzen><en> It’s important to remember that even after the initial healing period, some activities may cause wear on your catheter.
<G-vec00242-002-s021><wear.abnutzen><de> Da Metalle sich aneinander abreiben und abnutzen, sollte man nur Ringe aus demselben Material nebeneinander tragen.
<G-vec00242-002-s021><wear.abnutzen><en> Note that, since metals rub and wear on one another, you should only wear rings of the same metal next to each other.
<G-vec00242-002-s022><wear.abnutzen><de> Wenn Ihre Ausrüstung bereits mit Wachs bestückt ist, wird sich ein Teil des Instant Glide mit dem Wachs abnutzen.
<G-vec00242-002-s022><wear.abnutzen><en> If your equipment is already waxed some of the Instant Glide will wear off with the wax.
<G-vec00242-002-s023><wear.abnutzen><de> Wandbordüren "Kinder" werden von einem selbstklebenden Mattmaterial gebildet, bedienungsfreundlich, beständig und abnutzen sich nicht.
<G-vec00242-002-s023><wear.abnutzen><en> Decorative borders (Children) are made from a matte self-adhesive material, easy to use, resistant and do not wear off.
<G-vec00242-002-s024><wear.abnutzen><de> Richtig ist aber auch: Solange sich die syrischen Bürgerkriegsparteien nur untereinander bekriegen und abnutzen, bleibt ISIS der lachende Dritte.
<G-vec00242-002-s024><wear.abnutzen><en> Zusatzinformationen As long as the Syrian parties to the civil war only fight each other and wear themselves down, ISIS will have the last laugh.
<G-vec00242-002-s025><wear.abnutzen><de> Indem sich die Reifen abnutzen, werden Nassgriff- und Aquaplaning-Eigenschaften schwächer und das Unfallrisiko steigt.
<G-vec00242-002-s025><wear.abnutzen><en> When tyres wear out, the tyres’ wet grip and aquaplaning properties essentially deteriorate, and the risk of accidents increases.
<G-vec00242-002-s026><wear.abnutzen><de> Nach wiederholter Verwendung und Reinigung und Desinfektion von Edelstahlprodukten wird die Oberflächenbeschichtung jedoch abnutzen, und Bakterien wie Escherichia coli und Staphylococcus aureus können leicht wachsen und zu Infektionskrankheiten führen.
<G-vec00242-002-s026><wear.abnutzen><en> However, after repeated use and cleaning and disinfection of stainless steel products, the surface coating will wear, and bacteria such as Escherichia coli and Staphylococcus aureus can easily grow, leading to infectious diseases.
<G-vec00242-002-s027><wear.abnutzen><de> Dies kann einen wesentlichen Beitrag für eine lange und zuverlässige Lebensdauer ohne vorzeitiges Abnutzen, Präzisionsverlust oder unvorhersehbares Versagen leisten.
<G-vec00242-002-s027><wear.abnutzen><en> This can make a major contribution to a long reliable service life without premature wear, loss of accuracy or unexpected failure.
<G-vec00242-002-s028><wear.abnutzen><de> Es hilft, Ihre Tücher mit DEED zu sprühen, aber seine Wirkung wird nach ein paar Stunden abnutzen.
<G-vec00242-002-s028><wear.abnutzen><en> It does help lightly spraying your cloths with DEED, but its effect will wear off after a few hours.
<G-vec00242-002-s029><wear.abnutzen><de> Als die Wochen abnutzen, sitzt ein kalter Ungehorsam über der Stadt.
<G-vec00242-002-s029><wear.abnutzen><en> As the weeks wear on, a cold disobedience settles over the town.
<G-vec00242-002-s030><wear.abnutzen><de> Mit einem Trailschuh können Sie fast überall laufen, aber sie sind nicht so gut im anhaltenden Straßenlauf, da sie häufig Gummimischungen haben, die sich auf Asphalt schnell abnutzen und eine härtere Dämpfung aufweisen.
<G-vec00242-002-s030><wear.abnutzen><en> You can run almost anywhere with a trail shoe, but they aren’t so good at sustained road running as often they have rubber compounds that will wear out quickly on tarmac and have harder cushioning.
<G-vec00242-002-s031><wear.abnutzen><de> Ja, das Werkzeug und Grundersatzteile, die sich durch Betrieb am häufigsten abnutzen, sind der Bestandteil der Lieferung der Verpackungsmaschine.
<G-vec00242-002-s031><wear.abnutzen><en> Yes, tools and essential spare parts that wear out most by operations are included.
<G-vec00242-002-s032><wear.abnutzen><de> Dieses Griptape lässt sich leicht montieren und nur schwer abnutzen.
<G-vec00242-002-s032><wear.abnutzen><en> Easy to mount, hard to wear down Specifications
<G-vec00242-002-s033><wear.abnutzen><de> Das sind hauptsächlich die beweglichen Teile, die relativ schnell abnutzen.
<G-vec00242-002-s033><wear.abnutzen><en> These are mainly the moving parts, which wear out relatively fast.
<G-vec00242-002-s034><wear.abnutzen><de> Wie bei allen mechanischen Geräten, gibt es immer Komponenten, die sich abnutzen und deshalb Service oder eine Reparatur erfordern.
<G-vec00242-002-s034><wear.abnutzen><en> However, as with any mechanical product, there are some components that may wear and require service or repair.
<G-vec00242-002-s035><wear.abnutzen><de> Die Dada-Künstler selbst wussten, dass sich Schock-Effekte irgendwann einmal abnutzen und trauerten der organisierten Form von Dada offenbar nicht nach.
<G-vec00242-002-s035><wear.abnutzen><en> The Dada artists themselves were well aware that the shock effects would soon wear off, and they did not mourn the passing of Dada in its organized form.
<G-vec00242-002-s036><wear.abnutzen><de> Die invisibleSHIELD HD-Folie ist ein großer Beschützer und Helfer, aber immer noch kann sie sich abnutzen, verschmutzen oder beschädigen.
<G-vec00242-002-s036><wear.abnutzen><en> InvisibleSHIELD Original is a great protector and helper, yet it can wear, smear or damage.
<G-vec00242-002-s037><wear.abnutzen><de> Durchfluss und Stärke des Ionisators lassen sich leicht steuern, und es gibt keine beweglichen Teile, die sich abnutzen können.
<G-vec00242-002-s037><wear.abnutzen><en> Flow and force are easily controlled and there are no moving parts to wear out. Added Features
