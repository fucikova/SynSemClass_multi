<G-vec00003-001-s057><look.ansehen><de> Um dies zu verstehen, sollten wir uns einige wichtige Ereignisse rund um das Ereignis in Paris ansehen.
<G-vec00003-001-s057><look.ansehen><en> To understand this, let us look at some key events surrounding the events in Paris.
<G-vec00003-001-s058><look.ansehen><de> Sie wollen die Erklärungen anhören und die Plakate ansehen.
<G-vec00003-001-s058><look.ansehen><en> They want to hear the explanations and look at the posters.
<G-vec00003-001-s059><look.ansehen><de> Dies sind die Spit-Karten, und die Spieler dürfen sie nicht ansehen.
<G-vec00003-001-s059><look.ansehen><en> These are the spit cards, and the players should not look at them.
<G-vec00003-001-s060><look.ansehen><de> Die kleine Auswahl an Speisen sind bereits vorbereitet und in der Theke zu sehen – so kann man sich vorher ansehen, was man bestellen kann.
<G-vec00003-001-s060><look.ansehen><en> There's a small selection of dishes which are already prepared and visible behind the counter, so you can take a look before placing your order.
<G-vec00003-001-s061><look.ansehen><de> Mit diesen Produkten der landwirtschaftlichen Flächen und geistigen Tavern Bibbiano erzeugt romantische begünstigt natürlichen, ursprünglichen Platzhalter, süß shabby chic Kränze, Blumenschmuck, romantische Geschenkideen und immer originell Online ansehen romantische Geschenke aus unserer Produktion kommen und besuchen Sie unseren Shop bei Tavern Bibbiano maggiri oder schreiben für Informationen.
<G-vec00003-001-s061><look.ansehen><en> With these products of the land and of the intellect, the farm house Taverna di Bibbiano produces romantic perfumed gifts, lavender bags, dolls and pillows, original placeholders, sweet shabby chic garlands, floral arrangements and romantic original gift ideas Look at our romantic products on the Products page and don't hesitate to contact us for more information.
<G-vec00003-001-s062><look.ansehen><de> Wenn Licht wirklich sichtbar wäre, dann würden wir unseren Nachthimmel ansehen, und den Halbmond sehen, und die Seite des Mondes, die der Sonne zugekehrt ist, wäre erleuchtet und die Seite des Mondes die der Sonne abgekehrt ist, wäre dunkel, wäre deshalb also im Schatten des Mondes selbst, und das gesamte Gebiet hinter dem Mond, von der Sonne gesehen, wäre ein sehr langer Streifen von der Breite des Durchmessers des Mondes, und dieser Streifen wäre auch dunkel und wäre auch im Schatten, im Schatten des Mondes, und die Strahlen der Sonne wären nicht in der Lage, ihn zu erleuchten.
<G-vec00003-001-s062><look.ansehen><en> If light really would be visible then we would look at the night sky and see the half-moon and that side of the moon that is turned towards the Sun would be illuminated and that side of the moon that is turned away from the Sun would be dark, would therefore be in the shade of the moon itself, and the entire region behind the moon, seen from the Sun, would be a very long strip of the width of the diameter of the moon, and this strip would also be dark and would also be in the shade, in the shade of the moon, and the rays of the Sun would not be able to illuminate it.
<G-vec00003-001-s063><look.ansehen><de> "Hier wird nicht nur der vollbrachte Ehebruch, sondern auch der ""gedachte"", ja mehr noch, das bloße Ansehen einer Frau verurteilt."
<G-vec00003-001-s063><look.ansehen><en> "Not only adultery already carried out will be condemned here but also the ""thought"" of adultery or what is more, the mere look at a woman."
<G-vec00003-001-s064><look.ansehen><de> Das Ziel besteht nicht darin, etwas Monumentales zu schaffen, den ganzen Raum einzunehmen, sondern eher eine Situation hervorzurufen, in der sich die Größenordnungen plötzlich verändert haben und die BesucherInnen in Dinge und Objekte hineingehen können, die sie gewöhnlich nur von außen ansehen.
<G-vec00003-001-s064><look.ansehen><en> The aim is not to create something monumental, occupying the whole space but rather a situation where the scale has suddenly changed and visitors have a chance to walk into things and objects that they usually just look at from the outside.
<G-vec00003-001-s065><look.ansehen><de> Desweiteren verfügt das 1050 Watt Cooler Master Netzteil über einen speziellen 7 Volt Lüfteranschluss und dutzende weitere Features, die wir uns im Review ansehen werden.
<G-vec00003-001-s065><look.ansehen><en> Additionally, the Cooler Master 1050W power supply has a special 7 Volt fan connector and dozens more features, which we will take a look at in this review.
<G-vec00003-001-s066><look.ansehen><de> Wir starten unsere Reise indem wir uns in den nächsten zwei Wochen die Klassiker der originalen PlayStation ansehen – eine Konsole, die so beliebt wurde, dass sie weltweit über 100 Millionen mal verkauft wurde.
<G-vec00003-001-s066><look.ansehen><en> We will start our journey by spending the next two weeks taking a look back at the original PlayStation – a console so popular it went on to become the first platform to sell over 100 million units worldwide.
<G-vec00003-001-s067><look.ansehen><de> Abschließend möchte ich noch sagen, daß jeder, der all diesem gegenüber einen logischen und analytischen Blickwinkel hat, sich alle schriftlichen Werke der Menschheit ansehen kann, alle Bücher, und keinen finden wird, der so klar und vollständig ausgedrückt hat, wie die Dynamiken überleben können.
<G-vec00003-001-s067><look.ansehen><en> And to finish off, I just want to say, anyone who has a logical and analytical viewpoint of all this can look through all the written works of man, all the written books, and they will never find anyone who has put it so clearly, and so fully there on how the dynamics can survive.
<G-vec00003-001-s068><look.ansehen><de> Im ersten Teil dieses Artikels werden wir uns die einfachste Methode ansehen, einem PDF-Dokument Seitenzahlen hinzuzufügen.
<G-vec00003-001-s068><look.ansehen><en> In the first part of this article, we'll look at how to apply basic numbering to your document.
<G-vec00003-001-s069><look.ansehen><de> DOGGETT: Es gibt einen anderen Fall, von dem ich möchte, daß Sie ihn sich ansehen.
<G-vec00003-001-s069><look.ansehen><en> DOGGETT: There's another case I'd like you to take a look at.
<G-vec00003-001-s070><look.ansehen><de> Titel nach Uploader: Moonlight Sonata Ansehen Notendatei, inklusive der Lizenz für eine unbegrenzte Anzahl an Aufführungen, zeitlich beschränkt auf ein Jahr.
<G-vec00003-001-s070><look.ansehen><en> Title by uploader: Moonlight Sonata Look inside Sheet music file including a license for an unlimited number of performances, limited to one year.
<G-vec00003-001-s071><look.ansehen><de> Ich habe schon so scharf gegessen, dass ich einen Schluckauf hatte.thai-fussball.com: Gehst Du gerne ins Fitnessstudio?Björn Lindemann: Naja also ich brauche die Geräte nur ansehen dann nehm ich schon an Muskelmasse zu.
<G-vec00003-001-s071><look.ansehen><en> If not, I could remain at home. thai-fussball.com: Do you like to head into the gym? Bjorn Lindemann: Well, I only need to look at the devices then I bulk up.
<G-vec00003-001-s072><look.ansehen><de> Ich werde mir mal unsere alte Titelfolge ansehen.
<G-vec00003-001-s072><look.ansehen><en> I’ll have to look at the old set list.
<G-vec00003-001-s073><look.ansehen><de> Wir wollen uns ein Beispiel ansehen, wie Hexerei funktioniert.
<G-vec00003-001-s073><look.ansehen><en> Let us look at an example how sorcery works.
<G-vec00003-001-s074><look.ansehen><de> Der Schein spielte auf seinen Zügen und gab ihnen ein widriges Ansehen von Magerkeit und ängstlichem Zucken.
<G-vec00003-001-s074><look.ansehen><en> The glow played across his features and gave them a repulsive look of thinness and frightened twitching.
<G-vec00003-001-s075><look.ansehen><de> Dazu gibt es noch weitere Videos im Test und zwei brandneue 360 Grad Aufnahmen auf der dritten Seite, die wir nun des Öfteren auf OCinside.de einsetzen werden, damit man sich die Kühler und ein paar andere Produkte von allen Seiten ansehen kann.
<G-vec00003-001-s075><look.ansehen><en> There are also more videos in the review and two brand new 360 degree views on the third page, which we will use more often now on OCinside.de, so you can look at the cooler and a few other products from all sides.
<G-vec00003-001-s057><see.ansehen><de> Aber, auch andere Sehenswürdigkeiten in Kärnten sollten Sie wirklich ansehen, wie zum Beispiel die Tscheppaschlucht Ferlach, die Höhlen Obir, das Landhaus in Klagenfurt, das Automuseum in Villach, das Museum für moderne Kunst, das römische Museum Teurnia, der Reptilienzoo Nockalm, Naturstadel Feld am See, und die Burg Landskron, teilweise Ruine, mit einem sehr beeindruckenden Adlershow.
<G-vec00003-001-s057><see.ansehen><en> But, also other attractions in Carinthia you should really go see, like the Tscheppaschlucht Ferlach, the caves Obir, the Landhaus in Klagenfurt, the car museum in Villach, the museum of modern arts, the Roman Museum Teurnia, the reptile zoo Nockalm, Naturstadel Feld am See, and the castle Landskron, partly ruin, with a very impressive Eagle show.
<G-vec00003-001-s058><see.ansehen><de> Das häufige Wasserlassen, die, das viele Männer erleben, kann erschweren, Freunde besuchen, Essen gehen oder einen Film ansehen.
<G-vec00003-001-s058><see.ansehen><en> The frequent urination many men experience can make it difficult to visit friends, dine out, or see a movie.
<G-vec00003-001-s059><see.ansehen><de> Hier können Sie sich den aktuellen Kursder Dürkopp Adler Aktie ansehen.
<G-vec00003-001-s059><see.ansehen><en> In order to see the actual stock quotation of the Dürkopp Adler share please click here.
<G-vec00003-001-s060><see.ansehen><de> City Partner Hotels Weitere Hotels der gleichen Kette ansehen.
<G-vec00003-001-s060><see.ansehen><en> Park Plaza See more hotels in the same chain
<G-vec00003-001-s061><see.ansehen><de> Meine Rezension findest du hier oder du kannst dir auf der Turnament Indicator Webseite ein paar Screenshots ansehen.
<G-vec00003-001-s061><see.ansehen><en> My review is here, or you can see some screenshots over at the Tournament Indicator Website .
<G-vec00003-001-s062><see.ansehen><de> „Stolz machen mich insbesondere die Bilder, bei denen man den Leuten die Freude ansehen kann, die sie beim Betrachten der Fotos haben.
<G-vec00003-001-s062><see.ansehen><en> “I am particularly proud of photos in which you can see people enjoying themselves when you look at the photos.
<G-vec00003-001-s063><see.ansehen><de> Dass es eine gute Sache ist, zu einem Netzwerk vom RWTH-Absolventen, Freunden und Förderern zu gehören, die sich der RWTH verbunden fühlen und es als eine lohnenswerte Aufgabe ansehen, die RWTH Aachen als Spitzenuniversität weiterhin zu stärken.
<G-vec00003-001-s063><see.ansehen><en> That it is a good thing, to belong to a network of RWTH graduate, friends and promoters, who feel connected to RWTH Aachen and who see it as a worthwhile task to strengthen RWTH Aachen as a top level university.
<G-vec00003-001-s064><see.ansehen><de> Sie können ansehen Guardians of the Galaxy Online-streaming in hd jetzt.
<G-vec00003-001-s064><see.ansehen><en> Now you can see High Rise in HD format.
<G-vec00003-001-s065><see.ansehen><de> 0.3 km zu Bazar de l'Hotel de Ville (Auf der Karte ansehen) Auf der Karte ansehen Das Apartment Simon Le Franc bietet eine gute Unterkunftsmöglichkeit in Paris für 4 Personen.
<G-vec00003-001-s065><see.ansehen><en> 0.3 km to Bazar de l'Hotel de Ville (See on map) See on map Simon Le Franc is an apartment in Paris set close to a cathedral and a museum.
<G-vec00003-001-s067><see.ansehen><de> Wenn Sie sich Rom wirklich stilvoll ansehen wollen, können Sie an der Rezeption einen Lamborghini Sportwagen mieten.
<G-vec00003-001-s067><see.ansehen><en> If you really want to see Rome in style, you can rent a Lamborghini sports car from reception.
<G-vec00003-001-s068><see.ansehen><de> Seine Heiligkeit sagt es sehr schön: wenn wir nicht zurückschlagen mögen wir zwar Angst haben, dass andere Menschen das als ein Zeichen der Schwäche ansehen, doch tatsächlich ist es ein Zeichen großer Stärke.
<G-vec00003-001-s068><see.ansehen><en> His Holiness puts it very nicely: if we don't strike back, we're often afraid that other people will see it as a sign of weakness, but actually it's a sign of great strength.
<G-vec00003-001-s069><see.ansehen><de> Leser können dann auf den Link klicken und sich ansehen, wohin verwiesen wird.
<G-vec00003-001-s069><see.ansehen><en> Readers can click on the link to see what you are referring to.
<G-vec00003-001-s070><see.ansehen><de> Ihr könnt Sie hier ansehen: YouTube.
<G-vec00003-001-s070><see.ansehen><en> You can see them here on YouTube.
<G-vec00003-001-s071><see.ansehen><de> 0.1 km zu Gaîté Montparnasse Theatre (Auf der Karte ansehen) Auf der Karte ansehen Das hervorragende Mercure Paris Gare Montparnasse ist eine 4-Sterne Unterkunft, die eine 24-Stunden Rezeption, Trockenreinigung und Unterstützung bei Tourenplannung/Ticketkauf Gästen zur Verfügung...
<G-vec00003-001-s071><see.ansehen><en> 0.1 km to Gaîté Montparnasse Theatre (See on map) See on map Mercure Paris Gare Montparnasse Hotel is an excellent 4-star property featuring 24-hour reception, dry cleaning and newspaper service.
<G-vec00003-001-s072><see.ansehen><de> Sie können ansehen Mission: Impossible Online-streaming in hd jetzt.
<G-vec00003-001-s072><see.ansehen><en> Now you can see Schindler's List in best look.
<G-vec00003-001-s073><see.ansehen><de> Das führt aber auch dazu, dass zahlreiche andere Männchen der Bärenpopulation den folgenden Nachwuchs nicht als eigenen ansehen und eventuell umbringen.
<G-vec00003-001-s073><see.ansehen><en> This however means that many other males will not see the cubs as their own and could possibly kill them.
<G-vec00003-001-s074><see.ansehen><de> An der Grenze zu dem Dörfchen Salföld können Sie sich auf dem Meierhof einheimische ungarische Haustierrassen wie Zackelschafe, Büffel, Graurinder, Hirtenhunde und Geflügel ansehen.
<G-vec00003-001-s074><see.ansehen><en> The Manor situated in the border of the tiny village of Salföld provides an opportunity to see indigenous Hungarian domestic animals and livestock, such as the racka sheep, buffalo, gray cattle, shepherd dogs and fowl.
<G-vec00003-001-s075><see.ansehen><de> Nach Auswahl deiner Antwort kannst du dir eine kurze Erklärung ansehen,...
<G-vec00003-001-s075><see.ansehen><en> By clicking your answer, you will immediately see... Continue Reading
<G-vec00003-001-s095><look.ansehen><de> Eine Gießkanne aus Kupfer ist nicht nur besonders schön anzusehen, sondern auch noch das beste was Sie Ihren Pflanzen bieten können.
<G-vec00003-001-s095><look.ansehen><en> A watering can made of copper is not only particularly pretty to look at, but also the best thing you can do for your plants.
<G-vec00003-001-s096><look.ansehen><de> Der Schmuck ist nicht nur schön anzusehen, sondern auch sehr praktisch.
<G-vec00003-001-s096><look.ansehen><en> The jewelry is not only beautiful to look at, but also very practical.
<G-vec00003-001-s097><look.ansehen><de> Sportlich anzusehen und zu fahren – exklusiv, nicht nur im Preis.
<G-vec00003-001-s097><look.ansehen><en> The sporty look and ride. Very exclusive - not only when it comes to the price.
<G-vec00003-001-s098><look.ansehen><de> Sie lesen jetzt die sechste Seite dieses Abschnitts der Web-Site, und es kann angebracht sein, die vorigen und folgenden Seiten anzusehen.
<G-vec00003-001-s098><look.ansehen><en> ...you are on Page 4 of this section of the site now, and it may be expedient to have a look at the previous and following pages.
<G-vec00003-001-s099><look.ansehen><de> Um solch eine stressige Situation zu vermeiden, wird empfohlen, ruhig zu bleiben und das Kind 3 Minuten lang anzusehen oder ruhig mit ihm zu sprechen.
<G-vec00003-001-s099><look.ansehen><en> To avoid such a stressful situation, it is recommended to remain calm and look at the child for 3 minutes or talk with him calmly.
<G-vec00003-001-s100><look.ansehen><de> Das alles ist zwar sehr schön anzusehen, aber entfremdet doch etwas.
<G-vec00003-001-s100><look.ansehen><en> This is all very nice to look at, yet is also a bit alienating.
<G-vec00003-001-s101><look.ansehen><de> Die Kürbiskopf Servietten sind sowohl auf Halloween Feiern als auch auf Horror Partys schön anzusehen und ziemlich praktisch.
<G-vec00003-001-s101><look.ansehen><en> The Halloween pumpkin napkins are beautiful to look at both Halloween parties and horror parties and quite handy.
<G-vec00003-001-s102><look.ansehen><de> Wäre er ernsthaft, würde ich ihn drängen, sich Israels Besatzungspolitik und rassistische Diskriminierung näher anzusehen.
<G-vec00003-001-s102><look.ansehen><en> Were he serious, I would urge him to have a close look at Israel's policies of occupation and racial discrimination.
<G-vec00003-001-s103><look.ansehen><de> Ungeachtet dessen griff sie nach seinem Kinn und zwang ihn, sie anzusehen.
<G-vec00003-001-s103><look.ansehen><en> Nonetheless, she cupped his chin, made him look at her.
<G-vec00003-001-s104><look.ansehen><de> Die Schießereien in der Kanalisation sind auch schön anzusehen, wobei hier vor allem die visuelle Stärke des Films durchscheint.
<G-vec00003-001-s104><look.ansehen><en> The shootouts in the canalisation are nice to look at, too, since this is where the film's visual strength shines through the best.
<G-vec00003-001-s105><look.ansehen><de> Die Software von Tiger Gaming ist schön anzusehen und nicht besonders funktional.
<G-vec00003-001-s105><look.ansehen><en> Tiger Gaming 's software is nice to look at, it is not particularly functional.
<G-vec00003-001-s106><look.ansehen><de> Die kleinen Gassen, die schön renovierten/sanierten Fachwerkhäuser und Läden sind schön anzusehen.
<G-vec00003-001-s106><look.ansehen><en> The small streets, the beautifully renovated / renovated half-timbered houses and shops are beautiful to look at.
<G-vec00003-001-s107><look.ansehen><de> Sie, geehrter Besucher haben hier nun die Möglichkeit einen freundlichen Gästebucheintrag zu hinterlassen, meine Bildergalerie anzusehen, mich persönlich kennen zu lernen oder mir einen Auftrag zu erteilen, für ein Bild, was ich ihnen zeichnen soll… zum Beispiel ein Portrait eines Familienmitgliedes, einer Berühmtheit oder eine Zeichentrickfigur.
<G-vec00003-001-s107><look.ansehen><en> You, honoured visitor have to leave here now the possibility a friendly guestbook entry, to look at my Picture gallery, to get to know me personally or to give to me an order, for a picture what I should draw to them …, for example, a portrait of members of the family, a famous Person or a trick figure.
<G-vec00003-001-s108><look.ansehen><de> Die sehr gelungene Regie von Yuen Woo-Ping stellt einfach die Stärken eines Martial Arts Films heraus, weshalb er schön anzusehen ist.
<G-vec00003-001-s108><look.ansehen><en> The very well done directing of Yuen Woo-Ping underlines the strength of a martial arts film and is thus nice to look at.
<G-vec00003-001-s109><look.ansehen><de> Dabei sind die Wandbeläge nicht nur schön anzusehen, sie sind aufgrund ihrer hohen Materialqualität auch besonders haltbar und zum Teil sogar so robust, dass sie auch gereinigt werden können.
<G-vec00003-001-s109><look.ansehen><en> The wall coverings are not only nice to look at, but because of their material quality, they are also very durable and even so robust that they can be cleaned.
<G-vec00003-001-s110><look.ansehen><de> Der Junior wagte es nicht, seinen Schöpfer anzusehen.
<G-vec00003-001-s110><look.ansehen><en> The Junior didn't even look at his creator.
<G-vec00003-001-s111><look.ansehen><de> """Den meisten neuen Neonazis ist nicht anzusehen, dass sie Nazis sind."
<G-vec00003-001-s111><look.ansehen><en> """Most of the new neo-Nazis simply don't look like Nazis."
<G-vec00003-001-s112><look.ansehen><de> "Sie sind sogar recht lustig anzusehen und gehen mit Songs wie ""Back With A Vengeance"" und eben ""The Sack Of Rome"" beinahe als lediglich sleazig-angehauchte Punk-Band durch."
<G-vec00003-001-s112><look.ansehen><en> "They are actually quite funny to look at and and their songs like ""Back With A Vengeance"" and ""The Sack Of Rome"" rather sound like Sleaze-tinged Punk."
<G-vec00003-001-s113><look.ansehen><de> Eine Freundin von mir, die in den USA bereits veröffentlicht wird, sagte mir, daß ihr Verleger an meinem Buch jetzt schon genug Interesse hat, um es sich anzusehen – darüber bin ich unglaublich glücklich und dankbar.
<G-vec00003-001-s113><look.ansehen><en> A friend of mine, who is a published author of historical books in the US, told me that her publisher finds the subject of my book interesting enough to take a look at it – about which I am unbelievable happy and thankful.
<G-vec00226-002-s019><regard.ansehen><de> Bereits in Italien wurde Gomez von den Fans gefeiert und hatte ein hohes Ansehen in der Öffentlichkeit.
<G-vec00226-002-s019><regard.ansehen><en> In Italy, Gómez already was celebrated by the fans and was held in high regard by the public.
<G-vec00226-002-s020><regard.ansehen><de> 4Und das Wort Jehovas geschah zu mir also: 5So spricht Jehova, der Gott Israels: Wie diese guten Feigen, also werde ich die Weggeführten von Juda, die ich aus diesem Orte in das Land der Chaldäer weggeschickt habe, ansehen zum Guten.
<G-vec00226-002-s020><regard.ansehen><en> 4Then the word of the LORD came to me: 5“Thus says the LORD, the God of Israel: Like these good figs, so I will regard as good the exiles from Judah, whom I have sent away from this place to the land of the Chaldeans.
<G-vec00226-002-s021><regard.ansehen><de> Der „Sozialismus“ der SWP und anderer trotzkistischer Gruppen unterscheidet sich nicht im Geringsten vom staatskapitalistischen Programm der Labour-Linken (soweit diese noch existiert), die sie zudem auch noch als „Genossen“ ansehen.
<G-vec00226-002-s021><regard.ansehen><en> The ‘socialism’ of the SWP and other Trotskyist groups is indistinguishable from the state capitalist programme of the Labour left (as far as it still exists) who they regard as comrades.
<G-vec00226-002-s022><regard.ansehen><de> Anders ausgedrückt: Es war wichtig, dass der Kreis der Befragten keine Personen umfasste, die Patentinformationen von vornherein als wichtig ansehen.
<G-vec00226-002-s022><regard.ansehen><en> In other words, it was important to avoid having respondents who would naturally regard patent information as important.
<G-vec00226-002-s023><regard.ansehen><de> Einige französische Verleger geisteswissenschaftlicher Zeitschriften haben Bedenken gegen diese Empfehlung geäußert, die sie als Bedrohung für ein wirtschaftlich zerbrechliches Modell ansehen.
<G-vec00226-002-s023><regard.ansehen><en> Some French editors of journals in the Humanities and Social Sciences (HSS) have expressed their concern with regard to this recommendation, which they saw as a threat to a vulnerable business model.
<G-vec00226-002-s024><regard.ansehen><de> Die Isländer verdanken ihren Seemännern einiges, obwohl Matrosen nicht immer ein so hohes Ansehen genossen haben.
<G-vec00226-002-s024><regard.ansehen><en> Icelanders owe much to their fishermen, although seamen have not always been held in such high regard.
<G-vec00226-002-s025><regard.ansehen><de> Als die Züchter von Royal Queen Seeds Shining Silver Haze entwickelten, erschufen sie das, was viele Erzeuger als die endgültige Haze-Variante ansehen.
<G-vec00226-002-s025><regard.ansehen><en> When the breeders at Royal Queen Seeds developed the Shining Silver Haze they created what many growers regard as the definitive Haze variety.
<G-vec00226-002-s026><regard.ansehen><de> Die im Jahre 1447 in Krems gegründete Hauerinnung, die älteste Weinhauerszunft im deutschen Sprachraum, genoss großes Ansehen.
<G-vec00226-002-s026><regard.ansehen><en> The guild "HAUERINNUNG KREMS und STEIN", founded in Krems in 1442, was held in high regard.
<G-vec00226-002-s027><regard.ansehen><de> Und der Herr wird dich in deinem Gehorsame sicher gnädiger ansehen, als so du eigenmächtigerweise dich töricht vor dem Herrn verbirgst, vor dem sich doch ewig niemand verbergen kann.
<G-vec00226-002-s027><regard.ansehen><en> And the Lord will surely regard you with more mercy, being an obedient servant, as when you would hide in thy own foolishness from the Lord, before Whom no man can ever hide.
<G-vec00226-002-s028><regard.ansehen><de> Der Betrachter kann so das Fahrzeug von allen Seiten ansehen.
<G-vec00226-002-s028><regard.ansehen><en> The viewer can regard so the vehicle from all sides.
<G-vec00226-002-s029><regard.ansehen><de> Er muss das Denken als eine bloß subjektive Tätigkeit ansehen, die ein abstraktes Bild von der Natur entwerfen kann.
<G-vec00226-002-s029><regard.ansehen><en> He must then regard his thinking as a merely subjective activity, which can sketch an abstract picture of nature.
<G-vec00226-002-s030><regard.ansehen><de> Dass manche Dingos Menschen als Beute ansehen könnten, wird ebenfalls für möglich gehalten, weil Menschen, insbesondere Kinder, theoretisch überwältigt werden können.
<G-vec00226-002-s030><regard.ansehen><en> That some dingoes might regard humans as prey was also deemed possible because humans, especially children, could be theoretically overpowered.
<G-vec00226-002-s031><regard.ansehen><de> Wenn ihr so euer Mensch-Sein betrachtet, dann werdet ihr es verstehen lernen, wie bedeutungsvoll dieses ist für euch; ihr werdet das Erdenleben nicht mehr als Selbstzweck, sondern als Mittel zum Zweck ansehen, und ihr werdet es bewußt leben.
<G-vec00226-002-s031><regard.ansehen><en> If you look at your human existence in this light you will learn to understand how significant it is for you; you will no longer regard earthly life as an end in itself but as a means to an end, and you will live it consciously.
<G-vec00226-002-s032><regard.ansehen><de> Ich hoffe auf die Integration der neuen Niederländer und auf weniger Aggressivität, wenn es um Einstellungen geht, die wir mitunter als überholt ansehen, auch wenn sie vor fünfzig Jahren auch in unserer Gesellschaft noch vorherrschten.
<G-vec00226-002-s032><regard.ansehen><en> I hope for an integration of new Dutchmen with less aggression when it comes to notions which we now might regard as obsolete, but which were still prevalent in our society fifty years ago.
<G-vec00226-002-s033><regard.ansehen><de> "Leader haben bestimmte Werte, die sie als ihre führende Kraft ansehen, und sie wenden sie gleichermaßen ohne Diskriminierung an allen Menschen an", sagte ein Teilnehmer aus dem Vereinigten Königreich.
<G-vec00226-002-s033><regard.ansehen><en> “Leaders have certain values which they regard as their guiding force and they apply them to all human beings equally without any discrimination”, said a participant from the UK.
<G-vec00226-002-s034><regard.ansehen><de> Es sind spezielle Einrichtungen notwendig, die den Verfolgten ohne Ansehen ihrer ethnischen Herkunft, ihrer Religion und Weltanschauung medizinische sowie psychosoziale Betreuung anbieten und ihnen helfen, den schwierigen Weg in ein menschenwürdiges Leben zurückzufinden.
<G-vec00226-002-s034><regard.ansehen><en> Special institutions are required to offer victims medical and psychosocial care without regard to their ethnic origins, religion or ideology, and to assist them on the difficult path back to a decent and dignified life.
<G-vec00226-002-s035><regard.ansehen><de> Gemäß der Scharia machen sie sich strafbar, weil sie Mohamed nicht als den letzten Gesandten Gottes ansehen.
<G-vec00226-002-s035><regard.ansehen><en> According to the Sharia they are liable to prosecution because they don’t regard Mohammed to be God’s last envoy.
<G-vec00226-002-s036><regard.ansehen><de> In unserer schriftlichen Antwort auf den Brief wiesen wir darauf hin, dass wir es unfair fänden, dass uns erst jetzt – sozusagen in letzter Minute – genaue Vorschriften zur Zahl der auf HIV getesteten Kinder gemacht würden, aber wir rechneten damit, dass SACBC erwidern würde, dieser Druck käme nicht von ihnen, sondern vom Aurum Institute, die das Testen auf HIV als den wichtigsten Dienst ansehen.
<G-vec00226-002-s036><regard.ansehen><en> In our written reply to the letter from SACBC we complained that it is unfair to give us such high targets in such a short period of time. We were however aware that SACBC would reply that this pressure is not coming from them but rather from Aurum Institute who regard the testing for HIV as the most important service.
<G-vec00226-002-s037><regard.ansehen><de> Sie genießt dafür national wie international sehr hohes Ansehen.
<G-vec00226-002-s037><regard.ansehen><en> As a result, it is held in the highest regard, both nationally and internationally.
<G-vec00310-002-s038><view.ansehen><de> Dies geschieht, indem der USB-C-Anschluss eines kompatiblen Handys in einen normalen HDMI-Anschluss umgewandelt wird, so dass Sie Videos streamen, Spiele spielen, Fotos und mehr von Ihrem Gerät auf Ihren Fernseher, Monitor oder Projektor mit HDMI-Anschluss ansehen können.
<G-vec00310-002-s038><view.ansehen><en> It does this by turning a compatible phone's USB-C port into a standard HDMI port, so you can easily stream videos, play games, view photos and more from your Samsung Galaxy S8 to your TV, monitor or projector that features an HDMI port.
<G-vec00310-002-s039><view.ansehen><de> Signature Ähnliche Bilder ansehen Happy business-Leute klatschen mit Arme heben in celebration...
<G-vec00310-002-s039><view.ansehen><en> Signature View similar images Happy business people clapping with arms raised in celebration...
<G-vec00310-002-s040><view.ansehen><de> Dies kann verwendet werden, um nur bestimmte Felder und nicht zum Löschen die gesamte Spalte ansehen zu können.
<G-vec00310-002-s040><view.ansehen><en> This can be used to view only specific fields and not for deleting the entire column.
<G-vec00310-002-s041><view.ansehen><de> Wählen Sie eine Software aus der folgenden Liste, wenn Sie eine pps Datei öffnen, bearbeiten, erstellen, konvertieren, abspielen oder ansehen möchten.
<G-vec00310-002-s041><view.ansehen><en> Select a software from the list below if you want to open, edit, create, convert, play, use or view pps file.
<G-vec00310-002-s042><view.ansehen><de> Mit der mobilen Recruitment Software von Bullhorn können Sie immer und mit jedem Smartphone Kandidatenprofile ansehen und bearbeiten, Notizen hinzufügen und sich alle relevanten Informationen für Ihre Aufträge einholen.
<G-vec00310-002-s042><view.ansehen><en> Bullhorn's recruiter software offers mobile recruiting capabilities that let you view and edit candidate records, create notes, and access placement data on any device. Live Demo
<G-vec00310-002-s043><view.ansehen><de> Registrieren Sie Ihr Benutzerkonto online oder über die von unserem Partner Fujifilm betriebene Disneyland Paris PhotoPass App*(1), um Ihre Fotos ansehen, teilen und herunterladen zu können.
<G-vec00310-002-s043><view.ansehen><en> Register your account online or using the Disneyland Paris PhotoPass App*(1), operated by our partner Fujifilm, to view, share and download your photos.
<G-vec00310-002-s044><view.ansehen><de> Mit dieser Software kann man Probleme entwerfen und abändern, Heuristiken aufrufen, und Lösungen ansehen.
<G-vec00310-002-s044><view.ansehen><en> Using this application one can create and modify problem instances, solve using a variety of heuristic methods, and view the solutions.
<G-vec00310-002-s045><view.ansehen><de> Hier können Sie unseren aktuellen TW AUDiO Katalog ansehen und herunterladen.
<G-vec00310-002-s045><view.ansehen><en> Distributors Download AUDiO View and download the TW AUDiO catalogue.
<G-vec00310-002-s046><view.ansehen><de> Wählen Sie eine Software aus der folgenden Liste, wenn Sie eine d64 Datei öffnen, bearbeiten, erstellen, konvertieren, abspielen oder ansehen möchten.
<G-vec00310-002-s046><view.ansehen><en> Select a software from the list below if you want to open, edit, create, convert, play, use or view d64 file.
<G-vec00310-002-s047><view.ansehen><de> Nutzer, die Ihre Inhalte ansehen, können die Betrachterinfo für von Ihnen freigegebene Dateien und Ordner ebenfalls nicht deaktivieren.
<G-vec00310-002-s047><view.ansehen><en> People who view your content also can’t disable viewer info on your shared file or folder.
<G-vec00310-002-s048><view.ansehen><de> Öffne das Abo, das du bearbeiten möchtest, mit einem Klick auf „Bestellung ansehen“.
<G-vec00310-002-s048><view.ansehen><en> Open the subscription you want to manage by clicking on "View delivery".
<G-vec00310-002-s049><view.ansehen><de> Bitte zwischen Karten- oder Satellitenansicht wählen und nach verfügbaren Hostels in Glenbeigh suchen, Preise vergleichen, Bilder ansehen und ohne Buchungsgebühren buchen.
<G-vec00310-002-s049><view.ansehen><en> You can also search for available hostels in Te Anau, check prices, view pictures and book online with no booking fee.
<G-vec00310-002-s050><view.ansehen><de> Wer Schwierigkeiten mit der Anzeige der Präsentation hat, kann das Studium auch als PDF-Datei über diesen Link ansehen: Das Schiff der Zeit - PDF-Version.
<G-vec00310-002-s050><view.ansehen><en> If you have any problems viewing the study, you can also view it as a PDF file by clicking the following link: The Vessel of Time - PDF Version.
<G-vec00310-002-s051><view.ansehen><de> Wählen Sie eine Software aus der folgenden Liste, wenn Sie eine xmp Datei öffnen, bearbeiten, erstellen, konvertieren, abspielen oder ansehen möchten.
<G-vec00310-002-s051><view.ansehen><en> Select a software from the list below if you want to open, edit, create, convert, play, use or view tp file.
<G-vec00310-002-s052><view.ansehen><de> Loggen Sie sich ein, rufen Sie oben auf dem Banner "Live" auf und wählen Sie das Event, welches Sie ansehen möchten, aus.
<G-vec00310-002-s052><view.ansehen><en> Login, select IN-PLAY on the top banner and choose the event you wish to view.
<G-vec00310-002-s053><view.ansehen><de> Dann können Sie dessen Eigenschaften/Inhalte ansehen oder verändern.
<G-vec00310-002-s053><view.ansehen><en> Then you may view or modify its properties/contents.
<G-vec00310-002-s054><view.ansehen><de> CheapTickets$ 197 Alle 11 Angebote ansehen Die Preise werden von unseren Partnern bereitgestellt und beinhalten den durchschnittlichen Zimmerpreis pro Nacht sowie alle Steuern und Gebühren, die zum Zeitpunkt der Buchung feststehen, anfallen und unseren Partnern bekannt sind.
<G-vec00310-002-s054><view.ansehen><en> View provided by our partners, and reflect the total stay price payable through our partners, including taxes and fees that are known to our partners and which are due at time of booking.
<G-vec00310-002-s055><view.ansehen><de> Daten, die wir aufgrund Ihrer Nutzung unserer Dienste erhalten: Wir erfassen Informationen über die von Ihnen genutzten Dienste und die Art Ihrer Nutzung beispielsweise dann, wenn Sie sich ein Video auf YouTube ansehen, eine Website besuchen, auf der unsere Werbedienste verwendet werden, oder wenn Sie unsere Werbung und unsere Inhalte ansehen und damit interagieren.
<G-vec00310-002-s055><view.ansehen><en> Etihad Airways Partners Privacy) Information we get from your use of our services.We collect information about the services that you use and how you use them, like when you watch a video on YouTube, visit a website that uses our advertising services, or view and interact with our ads and content.
<G-vec00310-002-s056><view.ansehen><de> Diesen anzutippen speichert den Snap, so dass du ihn dir sooft ansehen kannst, wie du möchtest.
<G-vec00310-002-s056><view.ansehen><en> Tapping this will save the Snap so you can view it as many times as you'd like.
<G-vec00310-002-s095><watch.ansehen><de> Wenn Sie heiße Frauenvideos mögen, empfehlen wir Ihnen dringend, diese anzusehen, da Sie von den schönen Frauen überrascht sein werden, die wir hier zu Ihrem persönlichen Vergnügen zeigen.
<G-vec00310-002-s095><watch.ansehen><en> If you like hot women videos we strongly recommend that you watch it because you will be surprised by the beautiful women that we will show here for your personal enjoyment.
<G-vec00310-002-s096><watch.ansehen><de> Mit dem Klick auf das folgende Videosymbolbild werden Sie zu YouTube weitergeleitet um das Video anzusehen.
<G-vec00310-002-s096><watch.ansehen><en> By clicking on the following video icon you will be redirected to YouTube to watch the video.
<G-vec00310-002-s097><watch.ansehen><de> Der Balztanz der Finken war schön anzusehen, und ich lernte bald, die Weibchen anhand ihres Gesangs von den Männchen zu unterscheiden.
<G-vec00310-002-s097><watch.ansehen><en> The mating dance of the finches was a pleasure to watch, and I soon learned to distinguish the female from the male, based on her song.
<G-vec00310-002-s098><watch.ansehen><de> Die Praktizierenden wurden gezwungen, Videos anzusehen und Materialien zu lesen, die Falun Dafa diffamierten.
<G-vec00310-002-s098><watch.ansehen><en> They are forced to watch videos and read materials slandering Falun Gong.
<G-vec00310-002-s099><watch.ansehen><de> Es eignet sich gut, um die Spiele aus dem Android Store zu spielen oder unterwegs Videos anzusehen.
<G-vec00310-002-s099><watch.ansehen><en> It is well suitable to play games from the Android store or watch videos on the go.
<G-vec00310-002-s100><watch.ansehen><de> Nutzungseinschränkung: Die Microsoft Movies & TV App ermöglicht es dir, Filme und TV-Serien anzusehen, die du durch den Windows Store, den Xbox Store und den Microsoft Store gekauft hast, sowie Filme und TV-Shows, die du vorher durch Xbox Video oder Zune Marketplace gekauft hast.
<G-vec00310-002-s100><watch.ansehen><en> Usage Restrictions: The Microsoft Movies & TV app allows you to watch movies and TV shows purchased from the Windows Store, the Xbox Store and the Microsoft Store, as well as movies & TV shows previously purchased on Xbox Video or Zune Marketplace.
<G-vec00310-002-s101><watch.ansehen><de> Zögern Sie nicht, sich Anhänger und Bewertungen von anderen Benutzern anzusehen.
<G-vec00310-002-s101><watch.ansehen><en> Feel free to watch trailers and reviews made by other users as well.
<G-vec00310-002-s102><watch.ansehen><de> Halten Sie einen Moment inne, um sich dieses Video anzusehen und sich in Odisha vorzustellen.
<G-vec00310-002-s102><watch.ansehen><en> Pause for a moment from your bustling day to watch this video and imagine yourself in Odisha.
<G-vec00310-002-s103><watch.ansehen><de> Warm, beruhigend und zugleich faszinierend anzusehen – so sind Sonnenuntergänge am Kap der Guten Hoffnung, und genau so ist auch dieses Tuch.
<G-vec00310-002-s103><watch.ansehen><en> Warm, calming and fascinating to watch at the same time – that’s how sunsets are at the Cape of Good Hope, and this is the shawl that channels this feeling!
<G-vec00310-002-s104><watch.ansehen><de> Mit integriertem Web-Browser musst du deinen Video-Player nicht mehr verlassen, um Videos zu finden und anzusehen.
<G-vec00310-002-s104><watch.ansehen><en> With a built-in web browser, you don’t even have to leave your video player to find something to watch.
<G-vec00310-002-s105><watch.ansehen><de> Wählen Sie Weiter, um sich die Anleitungen anzusehen.
<G-vec00310-002-s105><watch.ansehen><en> Tap Next to watch the tutorials.
<G-vec00310-002-s106><watch.ansehen><de> Sie benutzen das Tablet der Eltern oft einfach mit – sei es um das Lesen zu üben oder um ihre Lieblingsserien anzusehen.
<G-vec00310-002-s106><watch.ansehen><en> They use their parent’s tablet to practice reading or watch their favorite TV shows.
<G-vec00310-002-s107><watch.ansehen><de> Ein Fernseher mit großem Bildschirm ermöglicht Ihnen, lokale Programme anzusehen und Ihre Eindrücke mit Ihren internationalen Freunden auszutauschen.
<G-vec00310-002-s107><watch.ansehen><en> Use the flat-screen TV to watch the latest American TV shows with your new international friends!
<G-vec00310-002-s108><watch.ansehen><de> Spontane Transkodierung* ermöglicht es Ihnen, ein Video anzusehen, während es in Echtzeit konvertiert wird.
<G-vec00310-002-s108><watch.ansehen><en> On-the-fly transcoding* allows you to watch a video while it is being converted in real time.
<G-vec00310-002-s109><watch.ansehen><de> Sie zwangen sogar die beiden anderen Frauen, diese sadistische Tortur anzusehen, was die Übeltäter unterhaltend fanden.
<G-vec00310-002-s109><watch.ansehen><en> They even forced the other two female Dafa practitioners to watch this sadistic torture, which the torturers found entertaining.
<G-vec00310-002-s110><watch.ansehen><de> Vom Live-Video-Streaming zur Echtzeit-Interaktion, BIGO ermöglicht es Ihnen, sich Live-Videos anzusehen, Ihr Leben zu übertragen, mit Ihren Freunden via Videos chatten und weltweit neue Freunde zu finden.
<G-vec00310-002-s110><watch.ansehen><en> It allows you to live stream your special moments, live talk with your friends, make video calls and watch hottest videos.
<G-vec00310-002-s111><watch.ansehen><de> Konvertierung DVD in QuickTime hilft, das Format zu konvertieren, um es sich auf jedem tragbaren Gerät anzusehen.
<G-vec00310-002-s111><watch.ansehen><en> Converting DVD to QuickTime will help to convert a format to watch it on any portable device.
<G-vec00310-002-s112><watch.ansehen><de> Ihre Freizeit können Sie ganz nach Ihren Wünschen gestalten, mittwochs bieten wir Ihnen einen gemeinsamen Kinobesuch an, um einen aktuellen deutschen Film anzusehen.
<G-vec00310-002-s112><watch.ansehen><en> You can plan your leisure time according to your own preferences. On Wednesdays we offer you a joint visit to the cinema to watch a new German movie.
<G-vec00310-002-s113><watch.ansehen><de> Zuerst zwangen sie mich, Filme anzusehen, die Falun Gong verleumden und dann redeten die Wachen in Gruppen auf mich ein, eine Gruppe nach der anderen, ohne jegliche Pause.
<G-vec00310-002-s113><watch.ansehen><en> First they forced me to watch a movie that slanders Falun Gong, and then guards talked with me in groups, one group after another, without giving me any time to rest.
<G-vec00211-003-s038><see_to.ansehen><de> Wer mehr über das Zusammenführen (Merge) der Patches wissen will, sollte sich die diffutils-Referenz ansehen.
<G-vec00211-003-s038><see_to.ansehen><en> For more on how patches are merged, see the diffutils reference.
<G-vec00211-003-s039><see_to.ansehen><de> Alle Restaurants in Dresden ansehen.
<G-vec00211-003-s039><see_to.ansehen><en> See all restaurants in Dresden.
<G-vec00211-003-s040><see_to.ansehen><de> Ich werde dieses Körbchen immer als ein ganz besonderes Geschenk ansehen und in Ehren halten.Ich hoffe auch, dass ich Britta demnächst persönlich kennenlernen werde.
<G-vec00211-003-s040><see_to.ansehen><en> I think it´s very interesting to see how other people found the amazing world of miniatures. I will always keep this little basket as a very special present.
<G-vec00211-003-s041><see_to.ansehen><de> Am Ende konnte ich das nicht mit ansehen, wie die Biene sich immer noch abquälte und habe ihr mit einem kleine Stock geholfen.
<G-vec00211-003-s041><see_to.ansehen><en> In the end I couldn’t see how the bee was still tormenting herself and helped her with a small stick.
<G-vec00211-003-s042><see_to.ansehen><de> 4 Öfen (1 Kachelofen traditionell gebaut, 1 Kachelofen mit doppelter Hülle gebaut, 1 Kamin, 1 Konvektionsofen) haben wir so erbaut, dass Sie sich auch den inneren Aufbau und Betrieb ansehen können.
<G-vec00211-003-s042><see_to.ansehen><en> The 32 built stoves were designed in order to show every style and 4 stoves (1 traditional stove, 1 stove with double shell, 1 fireplace and 1 convection stove) were built in a way that you can see their inside construction and operation.
<G-vec00211-003-s043><see_to.ansehen><de> Längsschleifen mehr Ansehen...
<G-vec00211-003-s043><see_to.ansehen><en> Linear Grinding see More...
<G-vec00211-003-s044><see_to.ansehen><de> Und wenn er gerade, sozusagen, Unsinn erzählt, muss ich das ansehen, als verstünde ich nicht, was er sagt: Ich verstehe nicht.
<G-vec00211-003-s044><see_to.ansehen><en> And if he just, so to speak, is saying nonsense, I have to see it as I don’t understand what he says: I don’t understand.
<G-vec00211-003-s045><see_to.ansehen><de> Die perfekte Wahl für diejenigen, die die Einfachheit gerader Linien in ihrem Bad als eine unabdingbare Entscheidung ansehen.
<G-vec00211-003-s045><see_to.ansehen><en> The perfect choice for those who see the simplicity of straight lines in their bath will be an outstanding decision
<G-vec00211-003-s046><see_to.ansehen><de> Es ist ein Jammer, so sagte ich, dass das Seelenheil ein Teil dieses Pakets ist, aber schwarze und weiße Christen, die in Afrika arbeiten, heilen die Kranken, lehren die Leute lesen und schreiben; und nur ein Säkularist der härtesten Sorte kann sich ein Missionshospital oder eine Schule ansehen und dann sagen, die Welt wäre besser ohne sie.
<G-vec00211-003-s046><see_to.ansehen><en> It's a pity, I would say, that salvation is part of the package, but Christians black and white, working in Africa, do heal the sick, do teach people to read and write; and only the severest kind of secularist could see a mission hospital or school and say the world would be better without it.
<G-vec00211-003-s047><see_to.ansehen><de> Angebot ansehen Besuchen Sie Hot Springs Unsere moderne Hotelsuchmaschine ist dazu ausgelegt, 1-Sterne-Hotels in Hot Springs zum bestmöglichen Preis und Angebote speziell auf die Vorlieben unserer Kunden ausgerichtet zu finden.
<G-vec00211-003-s047><see_to.ansehen><en> See Offer Visit Rock Springs Our modern hotel search engine is able to find one-star hotels in Rock Springs at the best price and with the offers that best suit our clients.
<G-vec00211-003-s048><see_to.ansehen><de> Frederick Fairgrounds: Nahegelegene Hotels auf der Karte ansehen Hotels nahe Frederick Fairgrounds finden und buchen Wenn Sie in der Nähe von Frederick Fairgrounds in Frederick übernachten möchten, bietet Hotels.com viele praktische Suchfunktionen, die Ihnen dabei helfen, die passende Unterkunft in der Gegend zu finden.
<G-vec00211-003-s048><see_to.ansehen><en> You just landed in the best site to find the best deals and offers on the most amazing accommodations for your stay. When you search for hotels near Frederick with Hotels.com, you need to first check our online map and see the distance you will be from Frederick, Maryland.
<G-vec00211-003-s049><see_to.ansehen><de> Mit Ausnahme des Benutzernamens können Besucher ihre persönlichen Daten jederzeit ansehen, bearbeiten oder löschen.
<G-vec00211-003-s049><see_to.ansehen><en> All users can see, edit, or delete their personal information at any time (except they cannot change their username).
<G-vec00211-003-s050><see_to.ansehen><de> Sie können alle Funktionen des Kontos beiFibo Group hier ansehen.
<G-vec00211-003-s050><see_to.ansehen><en> You can see all of the account features offered by Fibo Group here.
<G-vec00211-003-s051><see_to.ansehen><de> - Als Fahrer können Sie eine Bewertung Ihres Fahrverhaltens ansehen.
<G-vec00211-003-s051><see_to.ansehen><en> - As a driver, you can see an evaluation of your driving behaviour.
<G-vec00211-003-s052><see_to.ansehen><de> Sie können sich den Verlauf von bis zu 14 Tagen ansehen.
<G-vec00211-003-s052><see_to.ansehen><en> You can see up to 14 days of history.
<G-vec00211-003-s053><see_to.ansehen><de> Wenn Sie ein paar Kuratoren auf Steam folgen, werden die Empfehlungen nicht nur beim Erforschen im Steam-Shop angezeigt (oben auf Ihrer Startseite und ganz oben auf Tag- und Genre-Seiten), sondern Sie können jetzt auch jeden der angepassten Kuratorräume in Steam erkunden und alle Titel ansehen, die Kuratoren bereits bewertet haben.
<G-vec00211-003-s053><see_to.ansehen><en> By following a few Curators on Steam, you'll not only start to see their recommendations appear prominently when browsing the Steam Store (such as at the top of your home page and at the top of tag and genre pages), but you can also explore each of their customized spaces within Steam and see all the titles they have reviewed.
<G-vec00211-003-s054><see_to.ansehen><de> Diese Daten helfen uns zu erfahren, welche Informationen von besonderem Interesse für unsere Kunden sind, was unsere Kunden möchten und was sie sich am liebsten ansehen.
<G-vec00211-003-s054><see_to.ansehen><en> The data collected helps us learn what information is of most interest to our customers and what our customers would most like to see.
<G-vec00211-003-s055><see_to.ansehen><de> Lassen Sie uns die Schritte ansehen denen Sie folgen müssen.
<G-vec00211-003-s055><see_to.ansehen><en> Let us see the steps you need to follow.
<G-vec00211-003-s056><see_to.ansehen><de> Unter Übersicht oder Kursansicht kannst du Bewertungen lesen und beantworten, die Teilnehmer zu einem bestimmten Kurs abgegeben haben, indem du auf Bewertungen ansehen tippst.
<G-vec00211-003-s056><see_to.ansehen><en> In either Overview or Course View, you can read and respond to reviews that students have left for a particular course, by tapping See Reviews.
<G-vec00211-003-s057><watch_over.ansehen><de> TV Girl — It's Not Something — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s057><watch_over.ansehen><en> Aaron Switzer — Not Something — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s058><watch_over.ansehen><de> Stellardrone — Mars — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s058><watch_over.ansehen><en> Carbon Based Lifeforms — Proton / Electron — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s059><watch_over.ansehen><de> Mercyful Fate — Under The Spell — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s059><watch_over.ansehen><en> Vincent Chancey — The Spell — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s060><watch_over.ansehen><de> Barmy Army — Civil Liberty — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s060><watch_over.ansehen><en> Tackhead — Free South Africa — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s061><watch_over.ansehen><de> Paradime — Paragraphs (Remix) — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s061><watch_over.ansehen><en> Listen, watch, download and discover music for free at Last.fm Previous Play
<G-vec00211-003-s062><watch_over.ansehen><de> Nicola Hitchcock — Heart — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s062><watch_over.ansehen><en> Puracane — Take — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s063><watch_over.ansehen><de> Youth of Today — Take a Stand — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s063><watch_over.ansehen><en> Youth of Today — Youth of Today — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s064><watch_over.ansehen><de> Raphael Saadiq — You're The One That I Like — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s064><watch_over.ansehen><en> Raphael Saadiq — Day Dreams — Listen, watch, download and discover music for free at Last.fm Previous Play
<G-vec00211-003-s065><watch_over.ansehen><de> Sarah Slean — Twin Moon — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s065><watch_over.ansehen><en> Sarah Slean — Pie Jesu — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s066><watch_over.ansehen><de> Marek Hemmann — Roundabout — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s066><watch_over.ansehen><en> Joris Delacroix — La Mat — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s067><watch_over.ansehen><de> Triple Fast Action — Rest My Head — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s067><watch_over.ansehen><en> Triple Fast Action — Aerosmith — Listen, watch, download and discover music for free at Last.fm Previous
<G-vec00211-003-s068><watch_over.ansehen><de> TAKE THE LEAD — One O'Clock Jump (Backing Track) — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s068><watch_over.ansehen><en> Hawkins — Jesus Christ Walks — Listen, watch, download and discover music for free at Last.fm Previous Play
<G-vec00211-003-s069><watch_over.ansehen><de> XYP — The End Of Summer (Acoustic) — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s069><watch_over.ansehen><en> Abstracode — The End Of Summer — Listen, watch, download and discover music for free at Last.fm Previous Play
<G-vec00211-003-s070><watch_over.ansehen><de> Engineers — Emergency Room — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s070><watch_over.ansehen><en> Engineers — Sometimes I Realise — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s071><watch_over.ansehen><de> Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s071><watch_over.ansehen><en> Endzweck — Tolerance — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s072><watch_over.ansehen><de> Elastinen — Nuku vaan — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s072><watch_over.ansehen><en> Eksu — Tytölleni — Listen, watch, download and discover music for free at Last.fm
<G-vec00211-003-s073><watch_over.ansehen><de> Los Pericos — Sin Cadenas (Live) — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s073><watch_over.ansehen><en> Los Pericos — Runaway — Listen, watch, download and discover music for free at Last.fm Previous Play
<G-vec00211-003-s074><watch_over.ansehen><de> Matthew Florianz — Herfst — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s074><watch_over.ansehen><en> Matthew Florianz — Dwaallicht — Listen, watch, download and discover music for free at Last.fm Previous Play
<G-vec00211-003-s075><watch_over.ansehen><de> Sleepingdog — when it lies — Auf Last.fm kannst du kostenlos Musik hören, ansehen, herunterladen und entdecken.
<G-vec00211-003-s075><watch_over.ansehen><en> Sleepingdog — polar life — Listen, watch, download and discover music for free at Last.fm Previous Play
