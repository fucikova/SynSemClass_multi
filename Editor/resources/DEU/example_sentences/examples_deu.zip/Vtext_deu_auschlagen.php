<G-vec00169-001-s020><capitalize.auschlagen><de> Jack und Woody beschlossen, ein musikalisches Team zu werden und versuchten, aus der sich entwickelnden Country-Western-Musik- und Radioindustrie Kapital zu schlagen.
<G-vec00169-001-s020><capitalize.auschlagen><en> Jack and Woody decided to become a musical team, trying to capitalize on the developing country-western music and radio industries.
