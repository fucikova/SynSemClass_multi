<G-vec00121-002-s044><compete.antreten><de> Wieder auf Ripley Land Matchless wird Michael Rutter antreten.
<G-vec00121-002-s044><compete.antreten><en> Michael Rutter will again compete on Ripley Land Matchless.
<G-vec00121-002-s045><compete.antreten><de> Du kannst innerhalb jedes verfügbaren Tippspiels deinen eigenen Wettbewerb starten und gegen deine Freunde und Kollegen antreten.
<G-vec00121-002-s045><compete.antreten><en> You can setup your own contest within each of the available prediction games and compete against your friends and colleagues.
<G-vec00121-002-s046><compete.antreten><de> “Du darfst niemals antreten, um zweiter Sieger zu werden, denn dann hast du bereits im Vorfeld verloren.
<G-vec00121-002-s046><compete.antreten><en> “You must never compete in order to win second place because then you have already lost.
<G-vec00121-002-s047><compete.antreten><de> Matchplayer können sowohl im Single Match Play gegeneinander antreten, als auch im Match Play Foursome im Zweier-Team gegen ein anderes Team um den niedrigsten Punktestand spielen.
<G-vec00121-002-s047><compete.antreten><en> Matchplayer can compete against each other within a single match play as well as in a match play foursome. In the end of the round, the winner is the Matchplayer or team with the lowest score.
<G-vec00121-002-s048><compete.antreten><de> Alle Spieler werden von den großen Veränderungen, die im VIP Club stattgefunden haben, profitieren und in ausgewählten Freerolls und All Points Races antreten können, sowie die gewinnbringenden monatlichen Points Boosts erhalten.
<G-vec00121-002-s048><compete.antreten><en> All players will benefit from the big changes that have been made to the VIP Club by being able to compete in selected freerolls and all points races, as well as getting those high paying monthly points boosts.
<G-vec00121-002-s049><compete.antreten><de> Die auf der FEO Media Applikation basierende Spielidee, bei der App-Nutzer gegen Freunde oder unbekannte Herausforderer in verschiedenen Kategorien antreten, wird live im TV übertragen.
<G-vec00121-002-s049><compete.antreten><en> The game idea is based on the FEO media application and contains that the users of the application compete against friends or unknown challengers in different categories, which will be broadcasted live on TV.
<G-vec00121-002-s050><compete.antreten><de> Zarco sollte ursprünglich bis Ende 2020 als KTM-Werksfahrer antreten, nach der gemeinsamen Vertragsauflösung dann noch bis zum Ende dieser Saison.
<G-vec00121-002-s050><compete.antreten><en> Zarco was originally supposed to compete as a KTM factory driver until the end of 2020, after the joint contract resolution, he should then drive for KTM […weiter lesen]
<G-vec00121-002-s051><compete.antreten><de> Die Formula E ist eine von der FIA ins Leben gerufene Meisterschaft, in der die Piloten in rein elektrisch betriebenen Formelrennwagen gegeneinander antreten.
<G-vec00121-002-s051><compete.antreten><en> The FIA Formula E is a series that was established by the FIA in 2014 in which leading professional race drivers compete against one another in fully electrical powertrain formula racing cars.
<G-vec00121-002-s052><compete.antreten><de> Die Sängerinnen und Sänger werden auch beim Grand Prix of Nations Berlin 2017 in der Kategorie „Folklore“ antreten und Musik und Tanz aus ihrer Heimat präsentieren.
<G-vec00121-002-s052><compete.antreten><en> The singers will also compete in the "Folklore" category at the Grand Prix of Nations Berlin 2017 and will present music and dances from their homeland.
<G-vec00121-002-s053><compete.antreten><de> Jeweils drei Buben und drei Mädchen (U16 – Jahrgänge 2002/2003) dürfen beim Junior Race antreten.
<G-vec00121-002-s053><compete.antreten><en> Three boys and three girls respectively (U 16 – born in 2002 and 2003) are allowed to compete at the Junior Race.
<G-vec00121-002-s054><compete.antreten><de> Insgesamt werden 10 Teams antreten.
<G-vec00121-002-s054><compete.antreten><en> A total of 10 teams will compete.
<G-vec00121-002-s055><compete.antreten><de> 4) Jeder Spieler meldet (per PM) 3 Völker mit dennen er antreten will.
<G-vec00121-002-s055><compete.antreten><en> 4) Each player announces (via PM) 3 factions with which he wants to compete, this happens via PM to the Manager.
<G-vec00121-002-s056><compete.antreten><de> Jedes Jahr gibt es auch ein Special: 2016 konnten die Spieler beim „Challenge A Champion“ gegen einen Gewinner der Deutschen oder sogar Europäischen Meisterschaften antreten.
<G-vec00121-002-s056><compete.antreten><en> Every year there is also a special: In 2016, the players could compete against a winner of the German or even European Championships in the “Challenge A Champion”.
<G-vec00121-002-s057><compete.antreten><de> Dort will jeder antreten.
<G-vec00121-002-s057><compete.antreten><en> Everyone wants to compete there.
<G-vec00121-002-s058><compete.antreten><de> Im sechsten Schuljahr war dieses Rebecca Arenz, die jetzt in der nächsten Runde auf der alten Burg Bilstein Anfang 2008 antreten wird.
<G-vec00121-002-s058><compete.antreten><en> At Year Six this was Rebecca Arenz who will now compete a the next level at the old castle Bilstein at the beginning of 2008.
<G-vec00121-002-s059><compete.antreten><de> Im Wettkampfbereich entwickelte Ducati, die offiziell nicht mit einem Team antreten konnte, die Mach 250, die die 150-km/h-Schwelle überschritt und damit die Herzen der Sportgemeinde eroberte.
<G-vec00121-002-s059><compete.antreten><en> Despite not being able to officially compete in racing competitions, Ducati developed the Mach 250, capable of exceeding the 150km/h threshold, which gained it a special place in the heart of all sporting enthusiasts.
<G-vec00121-002-s060><compete.antreten><de> Teilnehmer*innen können mit einer Person in der Standard-Sektion antreten und mit einer anderen Person in der Latein- Sektion.
<G-vec00121-002-s060><compete.antreten><en> A dancer can compete together with one dancer in the standard section and with another dancer in the latin section.
<G-vec00121-002-s061><compete.antreten><de> Selbst Opernsänger dürfen antreten.
<G-vec00121-002-s061><compete.antreten><en> Even opera singers are allowed to compete.
<G-vec00121-002-s062><compete.antreten><de> Michael Brandner: Auch in der breiten Masse müssen Frauen antreten und mitwirken in der Politik, in der Kunst und Kultur.
<G-vec00121-002-s062><compete.antreten><en> Michael Brandner: Women must also compete and participate in politics, art and culture, even among the broad masses.
<G-vec00121-002-s063><compete.antreten><de> Kunden haben ab Ende 2015 die Möglichkeit, einen BMW M6 GT3 zu erwerben und damit ab 2016 in verschiedenen Rennserien und im Rahmen der BMW Sports Trophy anzutreten.
<G-vec00121-002-s063><compete.antreten><en> Customers will be able to purchase the BMW M6 GT3 from the end of 2015, allowing them to compete in the 2016 BMW Sports Trophy with the new car.
<G-vec00121-002-s064><compete.antreten><de> Der sogenannte König der Street Fighter, ein thailändischer Kickboxer namens Sagat, rief die begabtesten Kämpfer aus allen Ländern auf, in den Tournament anzutreten.
<G-vec00121-002-s064><compete.antreten><en> The so-called king of street fighters, a Thai kick boxer named Sagat, challenges the most talented fighters from all countries to compete in the tournament.
<G-vec00121-002-s065><compete.antreten><de> In FUT 17 hast du noch mehr Möglichkeiten, gegen deine Freunde anzutreten.
<G-vec00121-002-s065><compete.antreten><en> There are more ways to compete against your friends in FUT 17.
<G-vec00121-002-s066><compete.antreten><de> "Ich bin am Boden zerstört, mitteilen zu müssen, dass ich nicht in der Lage sein werde in Sotschi anzutreten.
<G-vec00121-002-s066><compete.antreten><en> "I am devastated to announce that I will not be able to compete in Sochi," the alpine skier wrote in a post on her Facebook page.
<G-vec00121-002-s067><compete.antreten><de> Statistiken und Mehrspieler Profile ermöglichen es Ihnen, gegen Ihre Freunde / Familie anzutreten.
<G-vec00121-002-s067><compete.antreten><en> Statistics and multipler profiles make it possible to compete against your family / friends.
<G-vec00121-002-s068><compete.antreten><de> Was Mirko vor allem antreibt, ist die Motivation, gegen andere anzutreten und die Möglichkeit, die Schweiz während dieser Rennen kennenzulernen.
<G-vec00121-002-s068><compete.antreten><en> Yet what keeps Mirko ‘fueled’ more than anything, is his motivation to compete against others and to have the chance to explore Switzerland during these competitions.
<G-vec00121-002-s069><compete.antreten><de> Damit es seinen Zweck erfüllen kann, einschließlich der Chancengleichheit von Frauen und Männern, muss es über Zulassungsstandards verfügen, die sicherstellen, dass Athleten, die sich als weiblich identifizieren, aber Hoden und Testosteronspiegel im männlichen Bereich haben, zumindest ihre Testosteronspiegel in den weiblichen Bereich herabsetzen, um auf der obersten Elite-Ebene in der weiblichen Klassifizierung anzutreten.
<G-vec00121-002-s069><compete.antreten><en> For it to serve its purposes, which include providing females opportunities equal to males, it must have eligibility standards that ensure that athletes who identify as female but have testes, and testosterone levels in the male range, at least drop their testosterone levels into the female range in order to compete at the elite level in the female classification.
<G-vec00121-002-s070><compete.antreten><de> Bereite dich dann darauf vor, weltweit anzutreten.
<G-vec00121-002-s070><compete.antreten><en> Then, prepare to compete around the world.
<G-vec00121-002-s071><compete.antreten><de> Beschreibung Ihr seid fast bereit, beim großen Arenakampf anzutreten.
<G-vec00121-002-s071><compete.antreten><en> Description You are nearly ready to compete in the grand melee.
<G-vec00121-002-s072><compete.antreten><de> Denn dieses Spiel ermöglicht den Spieler in die Rolle der Bank zu schlüpfen und gegen andere anzutreten.
<G-vec00121-002-s072><compete.antreten><en> Because this game enables the player to slip into the role of bank and to compete against others.
<G-vec00121-002-s073><compete.antreten><de> Die Saison in FIFA 13 wird durch Ereignisse in der realen Fußballwelt beeinflusst.,,Support Your Club" ermöglicht es den Fans, ihren Verein zu repräsentieren und in jedem Bereich von FIFA 13 gegen rivalisierende Vereine anzutreten.
<G-vec00121-002-s073><compete.antreten><en> Support your club and compete against rivals in every area of the game, lifting your club higher in the league tables or helping them avoid relegation.
<G-vec00121-002-s074><compete.antreten><de> Aber das ist nur einer der verfügbaren Modi, da Sie in der Lage sind, in einzelnen Rennen oder für eine bestimmte Zeit auch in Rennen gegen die Uhr anzutreten.
<G-vec00121-002-s074><compete.antreten><en> But this is only one of the available modes, since you will be able to compete in single races or for a fixed time as well as in races against the clock.
<G-vec00121-002-s075><compete.antreten><de> TEAM BATTLES Hockey Ultimate Team führt mit Team Battles eine neue Spielweise ein, die dir ermöglicht, in Duellen anzutreten, um tolle Belohnungen zu erhalten.
<G-vec00121-002-s075><compete.antreten><en> SQUAD BATTLES Hockey Ultimate Team introduces a new way to play in Squad Battles that allows you to compete and earn big rewards.
<G-vec00121-002-s076><compete.antreten><de> SAFT räumt ein, dass es im Telekommunikations- und Konsumenten-Sektor schwierig ist, gegen Chinesische Produkte anzutreten.
<G-vec00121-002-s076><compete.antreten><en> SAFT admits, that in the telecommunication and consumer markets it is hard to compete against China.
<G-vec00121-002-s077><compete.antreten><de> Ehret: „Ich freue mich wieder mit Michele und seinem Team in der diesjährigen Blancpain Endurance Series anzutreten.
<G-vec00121-002-s077><compete.antreten><en> Ehret: „I am pleased to compete together with Michele and the team in the Blancpain Endurance Series.
<G-vec00121-002-s078><compete.antreten><de> Sammeln Sie Punkte, um gegen frühere Scavenger-Jagdteams anzutreten, oder genießen Sie einfach die selbstgeführte Tour in Ihrem eigenen Tempo mit vielen Stopps zum Essen, Trinken und Besichtigen.
<G-vec00121-002-s078><compete.antreten><en> Rack up points to compete against prior scavenger hunt teams, or simply enjoy the self-guided tour at your own pace, with plenty of stops to eat, drink and sightsee.
<G-vec00121-002-s138><compete.antreten><de> Ach übrigens, Verizon hat die Enterprise Cloud neu erfunden und möchte damit gegen die Amazon Web Services antreten.
<G-vec00121-002-s138><compete.antreten><en> Oh by the way, Verizon has reinvented the enterprise cloud and thus would compete with the Amazon Web Services.
<G-vec00121-002-s139><compete.antreten><de> Sie können gegen Ihre Freunde antreten, sobald Ihr Samsung Account registriert wurde.
<G-vec00121-002-s139><compete.antreten><en> You can compete with your friends once your Samsung account is registered.
<G-vec00121-002-s140><compete.antreten><de> Hier kannst du deine Daten analysieren, tief eintauchen in deine Statistiken, deinen Fortschritt verfolgen und mit anderen Leuten auf der ganzen Welt interagieren sowie gegen sie antreten.
<G-vec00121-002-s140><compete.antreten><en> Here, you can analyze your data, deep dive into your stats, track your progress, and interact and compete with people all around the world.
<G-vec00121-002-s141><compete.antreten><de> The Fancy Pants Adventures für PlayStation 3 verfügt über einen tollen Multiplayermodus, bei dem du über PlayStation Network gegen bis zu drei Freunde antreten kannst.
<G-vec00121-002-s141><compete.antreten><en> Fancy Pants Adventures on PlayStation 3 features an addictive multiplayer mode that you can compete in with up to three of your friends via PlayStation Network.
<G-vec00121-002-s142><compete.antreten><de> Beim Rennfahren musste er stets gegen Jungs antreten, die größer und stärker als er waren.
<G-vec00121-002-s142><compete.antreten><en> When racing, he always had to compete guys who were bigger and stronger than him.
<G-vec00121-002-s143><compete.antreten><de> Aber auch im Familienverbund wartet einiges an Unterhaltung: Spaziergänge, bei denen Sie die schönsten Seiten der Bergwelt kennenlernen, Pferdekutschenfahrten in Zug, beim Schneemannbau-Wettbewerb vor der Haustüre des Hotels Goldener Berg gegen andere Familien antreten oder auf der mit Flutlicht beleuchteten Bobbahn in Lech mit der Rodel ins Tal sausen.
<G-vec00121-002-s143><compete.antreten><en> Finally holidays with the family But also together as a family you will experience a lot of fun and entertainment: Walks that show you the most beautiful parts of the mountains, horse-drawn carriage rides in Zug, compete with other families at the snowman building contest in front of the Goldener Berg Hotel or dash down the bobsleigh run in Lech.
<G-vec00121-002-s144><compete.antreten><de> Ferner bilden “Explore”, Globale Events und RiderNet – die Empfehlungs-Engine von SSX – den Mittelpunkt eines Online-Modus, der den sozialen Wettbewerb für Videospieler revolutionieren wird und dir ermöglicht, nach deinem persönlichen Zeitplan gegen deine Freunde anzutreten.
<G-vec00121-002-s144><compete.antreten><en> In addition, Explore, Global Events and RiderNet - SSX’s recommendation engine - headline an online feature set that will revolutionize social competition for gamers, making it fun and easy to compete with friends on your schedule. LATEST POSTS
<G-vec00121-002-s145><compete.antreten><de> Die beiden Teams nehmen an der Formula Student Germany (FSG) teil und entwickeln, konstruieren und bauen Semester für Semester neue Rennfahrzeuge, um gegen andere Studenten aus der ganzen Welt anzutreten.
<G-vec00121-002-s145><compete.antreten><en> Both teams participate in the Formula Student Germany (FSG) and term for term they develop, construct and build racing cars to compete with other student from all over the world.
<G-vec00121-002-s146><compete.antreten><de> Wende Strategie und magische Verstärkungen an, um mehr Punkte zu erlangen und gegen Freunden aus der ganzen Welt anzutreten.
<G-vec00121-002-s146><compete.antreten><en> Use strategy and magical boosts to score more points and compete with friends from all over the world.
<G-vec00121-002-s147><compete.antreten><de> Jedes Level hat seine eigene Bestenliste, was es dir einfach macht, deinen Fortschritt nachzuverfolgen, gegen Freunde anzutreten und deine coolen Skills zu zeigen.
<G-vec00121-002-s147><compete.antreten><en> Each level has its own leaderboard, making it easy to track progress in the game, compete with friends, and show off your powerful skills.
<G-vec00121-002-s148><compete.antreten><de> Diese Mannschaft war so gut, dass sich die Auswahl des Ödlands nie getraut hat, gegen sie anzutreten.
<G-vec00121-002-s148><compete.antreten><en> The team was so good, in fact, the Wasteland team was so scared it never showed up to compete.
<G-vec00121-002-s166><compete.antreten><de> Von anspruchsvollen Kletterrouten bis zu Labyrinthen: Die Kletterer können gegeneinander antreten, miteinander kooperieren und ihre Fähigkeiten verbessern.
<G-vec00121-002-s166><compete.antreten><en> From challenging climbing routes to mazes: climbers can compete with each other, cooperate and improve their skills.
<G-vec00121-002-s167><compete.antreten><de> Unser Wettbewerber ist stark und wir haben uns entschlossen, unsere beiden Autos nicht strategisch zu positionieren, sondern sie gegeneinander antreten zu lassen.
<G-vec00121-002-s167><compete.antreten><en> Our competitor is strong and we decided not to strategically position our two cars but to let them compete against each other.
<G-vec00121-002-s168><compete.antreten><de> Seit Beginn des XIX in London an der Themse findet eine klassische Royal Regatta statt, bei der die Mannschaften von Oxford und Cambridge gegeneinander antreten.
<G-vec00121-002-s168><compete.antreten><en> From the beginning of XIX in London on the River Thames a classic Royal Regatta has been held, in which the crews of Oxford and Cambridge compete.
<G-vec00121-002-s169><compete.antreten><de> Der McLaren Ultimate Vision Gran Turismo wurde als Reaktion auf einen Aufruf des Spieleschöpfers Kazunori Yamauchi entworfen: Fahrzeughersteller sollten “visionäre GT Autos” designen, die in „Gran Turismo Sport“ gegeneinander antreten würden.
<G-vec00121-002-s169><compete.antreten><en> The McLaren Ultimate Vision Gran Turismo was designed in response to a call from game creator, Kazunori Yamauchi, for vehicle manufacturers to design ‘visionary GT cars’ to compete in Gran Turismo Sport.
<G-vec00121-002-s170><compete.antreten><de> Secret Hitler ist ein Brettspiel, in dem Liberale und Faschisten gegeneinander antreten.
<G-vec00121-002-s170><compete.antreten><en> Secret Hitler is a board game in which liberals and fascists compete against each other.
<G-vec00121-002-s171><compete.antreten><de> Sechzehn Nationalmannschaften werden in insgesamt 31 Spielen gegeneinander antreten und um den Meistertitel kämpfen.
<G-vec00121-002-s171><compete.antreten><en> Sixteen national teams will compete in a total of 31 matches to be crowned champions.
<G-vec00121-002-s172><compete.antreten><de> Ihrerseits haben sowohl Xavi Torres, als auch Lorena Homar ihre Zufriedenheit über die Aufstellung gezeigt, um an diesen Spielen teilnehmen zu dürfen, an denen mehr als 4200 Sportler aus mehr als 160 verschiedenen Ländern gegeneinander antreten, um eine der mehr als 500 Medaillen zu gewinnen.
<G-vec00121-002-s172><compete.antreten><en> For their part, both Xavi Torres and Lorena Homar showed their satisfaction about their nomination to participate in those games in which more than 4200 sportsmen of more than 160 different countries will compete for one of the 500 Paralympics’ medals.
<G-vec00121-002-s173><compete.antreten><de> Zum einen aufgrund des beeindruckenden Niveaus im Finale in Genf und des spannenden Modus, bei dem unterschiedliche Instrumente und Besetzungen gegeneinander antreten.
<G-vec00121-002-s173><compete.antreten><en> For one thing, because of the impressive standard at the final in Geneva and the exciting way that different instruments and line-ups come together to compete.
<G-vec00121-002-s174><compete.antreten><de> Ein anderer bekannter Kampftyp ist máscara contra cabellera (Maske gegen Haare), wo ein maskierter und ein unmaskierter Wrestler gegeneinander antreten (für gewöhnlich hat der unmaskierte seine Maske gegen den maskierten Wrestler in einem vorherigen Kampf verloren); wenn der maskierte Luchador gewinnt, muss der unmaskierte seine Haare abrasieren lassen, was ein weiteres Zeichen der Erniedrigung darstellt.
<G-vec00121-002-s174><compete.antreten><en> luchadores bet their masks, the loser is unmasked by the winner. Máscara contra cabellera ("mask versus hair"): a masked wrestler and an unmasked one compete, sometimes after the unmasked one has lost his mask to the masked one in a prior bout.
<G-vec00121-002-s175><compete.antreten><de> Lass 32 Konsolen und zusätzlich Handhelds und Raritäten im Supertrumpf gegeneinander antreten.
<G-vec00121-002-s175><compete.antreten><en> Console Quartets Let 32 consoles and additionally handhelds and special rarities compete in Top Trumps.
<G-vec00121-002-s176><compete.antreten><de> In insgesamt neun Disziplinen können Läufer, Skater, Walker, Tretrollerfahrer und Handbiker auf der grenzüberschreitenden, anspruchsvollen Strecke gegeneinander antreten.
<G-vec00121-002-s176><compete.antreten><en> In a total of nine disciplines runners, skaters, walkers, pedal scooters and handbikers can compete against each other on the cross-country, demanding route.
<G-vec00121-002-s177><compete.antreten><de> Im Finalen Event werden die 16 besten Melee Singles Spieler, die 8 besten Melee Doubles Teams sowie die Top 2 der Crews in ihrem jeweiligen Format gegeneinander antreten.
<G-vec00121-002-s177><compete.antreten><en> In the final event, the 16 best Melee Singles players, the 8 best Melee Doubles teams and the top 2 crews will compete against each other in their respective formats.
<G-vec00121-002-s178><compete.antreten><de> “Die Leute wollen immer Menschen gegeneinander antreten sehen.
<G-vec00121-002-s178><compete.antreten><en> “People always want to see people compete against each other.
<G-vec00121-002-s179><compete.antreten><de> Die Limit Hold'em Challenge ist eine neue Serie von High Stakes Matches, in denen die großen Namen der Szene Heads-up gegeneinander antreten.
<G-vec00121-002-s179><compete.antreten><en> The Limit Hold'em Challenge is a series of heads-up matches where the biggest names in poker compete for high-stakes.
<G-vec00121-002-s180><compete.antreten><de> Das Dorf ist Zentrum einiger Kampfsportschulen, die gelegentlich gegeneinander antreten, um voneinander zu lernen.
<G-vec00121-002-s180><compete.antreten><en> In the 1930s, Foshan is a hub of Southern Chinese martial arts, where various schools actively recruit disciples and compete against each other.
<G-vec00121-002-s181><compete.antreten><de> Heute sind es Jungen und Mädchen von über 150 Schulen, die in verschiedenen Disziplinen jedes Jahr gegeneinander antreten.
<G-vec00121-002-s181><compete.antreten><en> Today boys and girls from over 150 schools compete in various track and field disciplines.
<G-vec00121-002-s182><compete.antreten><de> Zum zweiten Mal findet auf der BTW-Konferenzreihe die Data Science Challenge statt, auf der in diesem Jahr fünf Forschergruppen gegeneinander antreten.
<G-vec00121-002-s182><compete.antreten><en> For the second time, the Data Science Challenge will take place at the BTW conference series, where five research groups will compete against each other this year.
<G-vec00121-002-s183><compete.antreten><de> Sie alle werden von der grandiosen Schauspielerin Tilda Swinton gespielt, die ihre sehr unterschiedlichen Charaktere selbstironisch gegeneinander antreten lässt.
<G-vec00121-002-s183><compete.antreten><en> They are all played by the outstanding actress Tilda Swinton, who has the very diverse characters she is playing compete which each other with self-irony.
<G-vec00121-002-s184><compete.antreten><de> Benutzer können sich sogar in Sprachclubs treffen und gegeneinander antreten.
<G-vec00121-002-s184><compete.antreten><en> Users can even meet in language clubs and compete against each other.
<G-vec00121-002-s581><compete.antreten><de> Die Gestalter treten in den fünf Hauptkategorien Getränke, Nahrung, Körperpflege, Luxusartikel und Andere Märkte sowie in nicht weniger als 44 Unterkategorien an.
<G-vec00121-002-s581><compete.antreten><en> Designers compete in five main categories—beverages, food, body, luxury, and other markets—and no fewer than 44 sub-categories.
<G-vec00121-002-s582><compete.antreten><de> In der neuen fünfteiligen Musikshowreihe treten neun Prominente zum großen Gesangswettstreit an.
<G-vec00121-002-s582><compete.antreten><en> In the new five-part music show series, nine celebrities compete in this major singing contest.
<G-vec00121-002-s583><compete.antreten><de> Athleten aus aller Welt treten zum Wettlauf auf einer 119 km langen, einmalig schönen Strecke an.
<G-vec00121-002-s583><compete.antreten><en> Elite and amateur trail runners from all over the world compete in this punishing 119 km race featuring 5,850 metres elevation gain.
<G-vec00121-002-s584><compete.antreten><de> Was die Priestertalente betrifft, versuchen wir ein letztes Mal, 'Engelsfeder' in Konkurrenz mit den anderen Bewegungstalenten treten zu lassen.
<G-vec00121-002-s584><compete.antreten><en> For Priest talents, we are trying one more time to make Angelic Feather compete with the other movement talents, and let Mindbender and From Darkness, Comes Light compete better with Solace and Insanity.
<G-vec00121-002-s585><compete.antreten><de> Die Frage ist, ob es für einen Kleinhersteller wie die Fruchtsaftkooperative "El Paraiso" überhaupt Sinn ergibt, mit Mainstream-Produkten wie Orangensaft an den Markt zu treten, für den es viele Mitbewerber gibt, oder ob nicht Nischenprodukte zu höheren Gewinnspannen verkauft werden können.
<G-vec00121-002-s585><compete.antreten><en> The question is, whether it makes even sense for a small producer such as the fruit juice cooperative "El Paraiso" to compete on the market with a mainstream product such as orange juice, or whether it isn’t better to focus on niche products that might be sold with higher margins.
<G-vec00121-002-s586><compete.antreten><de> Dabei gibt es ein Novum: Zum ersten Mal treten bei der RCCO auf einer digitalen Slotfire-Bahn acht Autos gleichzeitig im Rennen an.
<G-vec00121-002-s586><compete.antreten><en> There is a novelty: For the first time in the RCCO, eight cars will compete against each other at the same time on a digital “Slotfire” track.
<G-vec00121-002-s587><compete.antreten><de> Im Finale treten die besten Junior Handler der Halbfinals gegen die Teilnehmer aus dem Ausland an, die von ihrem Land nominiert wurden.
<G-vec00121-002-s587><compete.antreten><en> Final, the best junior handlers from the semi-finals compete in the final together with the participants sent by the national organisations.
<G-vec00121-002-s588><compete.antreten><de> Die anderen vier Kategorien sind dagegen stark besetzt, über 100 Fahrerinnen und Fahrer haben ihr Kommen zugesagt und treten in den finalen Rennen der DKM-Saison 2020.
<G-vec00121-002-s588><compete.antreten><en> The other four categories, on the other hand, are heavily occupied, with more than 100 drivers having agreed to come and compete in the final races of the DKM season 2020.
<G-vec00121-002-s589><compete.antreten><de> In der hochdotierten Golden League treten die Gewinner aller DWM Trophies eines Kalenderjahres wettbewerbsübergreifend gegeneinander an: gesucht werden die Besten der Besten.
<G-vec00121-002-s589><compete.antreten><en> In the highly remunerated Golden League, the winners of all DWM trophies from a calendar year enter compete against each other in the search for the best of the best.
<G-vec00121-002-s590><compete.antreten><de> Drei Wochen lang treten in verschiedenen Disziplinen die besten Jockeys Europas mit ihren feurigen Vollblütern gegeneinander an.
<G-vec00121-002-s590><compete.antreten><en> For three weeks, the best jockeys in Europe compete against each other in different disciplines with their fiery thoroughbreds.
<G-vec00121-002-s591><compete.antreten><de> Seine U8 und U10 Buben- und Mädchen-Teams, und seine U14 und U16 Mädchen-Teams treten national an.
<G-vec00121-002-s591><compete.antreten><en> Its U8’s and U10’s boys and girls teams, plus its U14’s and U16’s girls teams compete nationally.
<G-vec00121-002-s592><compete.antreten><de> Treten Sie bei epischen 24-Stunden-Rennen und Forza-Rennligen an 26 weltbekannten Veranstaltungsorten an, all das in atemberaubender 1080p-Auflösung und mit 60 fps.
<G-vec00121-002-s592><compete.antreten><en> Compete in epic 24-player races and Forza Race Leagues across 26 world-famous locales, all at a stunning 1080p resolution and 60 frames per second.
<G-vec00121-002-s593><compete.antreten><de> Treten Sie gegen CART Autos, die durch anspruchsvolle künstliche Intelligenz gesteuert werden.
<G-vec00121-002-s593><compete.antreten><en> Compete against CART cars that are controlled by exacting artificial intelligence.
<G-vec00121-002-s594><compete.antreten><de> Sie treten in den Raum mit aliens.
<G-vec00121-002-s594><compete.antreten><en> You will compete in the space with aliens.
<G-vec00121-002-s595><compete.antreten><de> Explorer treten einzeln oder in Paaren an und dürfen sich von einem Mentor in Bezug auf wissenschaftliche oder technische Aspekte ihrer Projektbeiträge beraten lassen.
<G-vec00121-002-s595><compete.antreten><en> Explorers compete as individuals, or in pairs and they may choose to be advised by a mentor on scientific and technical aspects of their project entry.
<G-vec00121-002-s596><compete.antreten><de> Im globalen MARGA Online Planspiel-Wettbewerb treten die Teilnehmenden als Management-Team an, ein simuliertes Unternehmen zu führen – webbasiert, selbstgesteuert und ortsunabhängig.
<G-vec00121-002-s596><compete.antreten><en> In the global MARGA Online Competition the participants compete as a management team and run a simulated company - web-based, self-directed and independent of location.
<G-vec00121-002-s597><compete.antreten><de> Männer und Frauen treten in einzelnen Fitnessklassen an.
<G-vec00121-002-s597><compete.antreten><en> Men and women compete in separate fitness categories.
<G-vec00121-002-s598><compete.antreten><de> Dementsprechend treten die Teams nur innerhalb ihrer Altersklasse gegen andere Teams an.
<G-vec00121-002-s598><compete.antreten><en> Accordingly, the teams compete against other teams only within their age group.
<G-vec00121-002-s599><compete.antreten><de> Die jeweils besten 17 aus den beiden Rennen treten dann im Finale gegeneinander an.
<G-vec00121-002-s599><compete.antreten><en> The 17 best respective drivers of both races are then going to compete against each other in the final race.
<G-vec00121-002-s600><compete.antreten><de> Im Meisteropen treten 132 Spieler an.
<G-vec00121-002-s600><compete.antreten><en> In the open Master tournament, 132 players compete.
<G-vec00121-002-s601><compete.antreten><de> Ab der Formel-1-Weltmeisterschaft 2019 treten die zwei historischen Marken, Sauber und Alfa Romeo, mit einem neuen Namen als Alfa Romeo Racing an.
<G-vec00121-002-s601><compete.antreten><en> From the 2019 Formula 1 World Championship, the two historic brands, Sauber and Alfa Romeo, will compete with a new name as Alfa Romeo Racing.
<G-vec00121-002-s602><compete.antreten><de> In diesem Turnier treten Teams aus ganz Deutschland an.
<G-vec00121-002-s602><compete.antreten><en> In this tournament teams from all over Germany compete.
<G-vec00121-002-s603><compete.antreten><de> KRIEGSGEBIET-MULTIPLAYER Spielen Sie mit Freunden und treten Sie gegen Rivalen in drei neuen, massiven Multiplayer-Modi an – Kriegsgebiet, Kriegsgebiet-Angriff und Kriegsgebiet-Feuergefecht: – KRIEGSGEBIET ist ein massiver Multiplayer-Modus, in dem 24 Spieler gegeneinander antreten und von der KI kontrollierte Verbündete und Gegner das Kampfgeschehen interessant halten.
<G-vec00121-002-s603><compete.antreten><en> WARZONE MULTIPLAYER Play with friends and compete against rivals in three massive multiplayer modes new to the Halo franchise: Warzone, Warzone Assault, and Warzone Firefight: -WARZONE is a massive-scale multiplayer mode that supports 24-player battles with both friendly and enemy AI constantly dropping in to mix up the experience.
<G-vec00121-002-s604><compete.antreten><de> Beim Qualifikationsturnier treten an 2 Tagen jeweils 4 Spieler einer Mannschaft an, wobei jeweils die 3 besten Resultate in die Wertung kommen.
<G-vec00121-002-s604><compete.antreten><en> During the qualifying tournament, 4 players of a team compete over 2 days with the best 3 results being included in the rankings.
<G-vec00121-002-s605><compete.antreten><de> Die Gestalter treten an in den fünf Hauptkategorien Getränke, Nahrung, Körperpflege, Luxusartikel und Andere Märkte sowie in nicht weniger als 50 Unterkategorien.
<G-vec00121-002-s605><compete.antreten><en> Designers compete in five main catégories - beverages, food, body, luxury and other markets - and no fewer than 50 sub-categories. Autre présentation Pentawards
<G-vec00121-002-s606><compete.antreten><de> Bei Vancouvers größter Veranstaltung treten drei Länder über drei Abende hinweg beim weltgrößten Feuerwerks-Wettbewerb über Wasser an.
<G-vec00121-002-s606><compete.antreten><en> Vancouver’s biggest event sees three countries compete over three evenings in the world’s largest offshore fireworks competition.
<G-vec00121-002-s607><compete.antreten><de> Bei diesem nie dagewesenen Stunt in der eisigen Wildnis des Yukons in Kanada treten die Stuntfahrerin Debbie Evans und ihr modifizierter Jaguar F-TYPE SVR mit 5,0-Liter-V8-Motor – und der Stärke von Castrol EDGE – gegen eine Mixed-Reality-Armee aus realen und animierten Panzern, Atom-U-Booten, Helikoptern, Raketen, Explosionen und zersplitterndem Eis an.
<G-vec00121-002-s607><compete.antreten><en> In a world-first stunt staged in the wild, icy landscape of the Yukon in Canada, stunt driver Debbie Evans, and Evans' Jaguar F-TYPE 5.0 Supercharged V8 R AWD - with the strength of Castrol EDGE - compete against a mixed-reality army of military tanks, nuclear submarines, helicopters, missiles, explosions and shattering ice.
<G-vec00121-002-s608><compete.antreten><de> Um mit einer besonderen Incentiverung zu motivieren, wurde ein Verkaufswettbewerb der besonderen Art veranstaltet: Die Teams treten auf einer Microsite in einem virtuellen Formel 1 Rennen gegeneinander an.
<G-vec00121-002-s608><compete.antreten><en> In order to motivate these with a particular trigger, a special kind of sales competition was developed: The teams compete in a virtual Formula 1 race against each other on a microsite.
<G-vec00121-002-s609><compete.antreten><de> In acht internationalen Teams treten die weltweit besten Drohnenpiloten gegeneinander an und versuchen, ihre selbstgebauten Drohnen schnellstmöglich durch einen aufregenden Parcours zu steuern.
<G-vec00121-002-s609><compete.antreten><en> In eight international teams, the world’s best drone pilots compete against each other and try to steer their custom-made drones through an exciting course as quickly as possible.
<G-vec00121-002-s610><compete.antreten><de> Edle Materialien wie Seide, Woll- und Kaschmirtuch und Ponyfell treten an gegen Zeltplane, Reflektorstoff und bestickten Filz.
<G-vec00121-002-s610><compete.antreten><en> Fine materials such as silk, wool and cashmere cloth and pony fur compete against tarpaulin, reflector material and embroidered felt.
<G-vec00121-002-s611><compete.antreten><de> Auch die beiden deutschen Finalisten Julian Genisi (Deutscher Wizard-Meister 2014) und Mareike Mutz (Deutsche Vizemeisterin 2014) sind heute in Athen dabei und treten gegen die internationale Konkurrenz an.
<G-vec00121-002-s611><compete.antreten><en> The two German finalists, Julian Genesi (German Wizard Champion 2014) and Mareike Mutz (German Vice Champion 2014), have come to Athens, too, and will compete against the international März 2013
<G-vec00121-002-s612><compete.antreten><de> Treten Sie während der Turniere mit anderen Spielern an.
<G-vec00121-002-s612><compete.antreten><en> Compete with other players during tournaments.
<G-vec00121-002-s613><compete.antreten><de> Ab heute treten die Teilnehmerchören in verschiedenen Wettbewerbskategorien an.
<G-vec00121-002-s613><compete.antreten><en> Starting today the choirs compete in competitions of different categories.
<G-vec00121-002-s614><compete.antreten><de> Die Teams gehören der Big Sky Conference an und treten in den Wettbewerben der NCAA Division I an.
<G-vec00121-002-s614><compete.antreten><en> They have 14 varsity teams and they compete in the Big Sky Conference.
<G-vec00121-002-s615><compete.antreten><de> Darüber hinaus treten Topathleten aus den U.S.A., Australien, Polen, Italien, Schweden, Österreich und Großbritannien bei der Champions Trophy in Marseille an.
<G-vec00121-002-s615><compete.antreten><en> In Marseille more top athletes from the U.S.A., Australia, Poland, Italy, Sweden, Austria and Great Britain will compete.
<G-vec00121-002-s616><compete.antreten><de> ISTAF-Geschäftsführer Martin Seeber: „Das Erfolgsrezept des ISTAF besteht seit über 90 Jahren aus den gleichen Zutaten: Die besten deutschen Athletinnen und Athleten treten gegen die besten der Welt an.
<G-vec00121-002-s616><compete.antreten><en> ISTAF Managing Director Martin Seeber, „The success story of the ISTAF consists of the same ingredients for over 90 years now: The best German athletes compete against the best in the world.
<G-vec00121-002-s617><compete.antreten><de> Vier Promi-Teams treten gegeneinander an: Die Teams Norden, Süden, Osten und Westen nehmen Sie die Herausforderung an, ein Vier-Gänge-Grill-Menü in nur 150 Minuten zuzubereiten.
<G-vec00121-002-s617><compete.antreten><en> Four celebrity teams come together to compete against each other in front of an audience: teams North, South, East and West accept the challenge of cooking a four-course barbecue meal in only 150 minutes.
<G-vec00121-002-s618><compete.antreten><de> Die 90 Besten Deutschlands treten gegeneinander an und diese rasanten Rennen sind sicher einen Blick wert.
<G-vec00121-002-s618><compete.antreten><en> The 90 best in Germany compete against each other and this breathtaking event is worth having a look at.
<G-vec00121-002-s619><compete.antreten><de> Drei Coaches treten mit der Aufgabe gegeneinander an, in 300 Sekunden komplexe Themen rund um FMEA möglichst anschaulich und unterhaltsam vorzutragen.
<G-vec00121-002-s619><compete.antreten><en> Three coaches compete against each other with the task of presenting complex FMEA topics as vividly and entertainingly as possible in 300 seconds.
<G-vec00121-002-s620><compete.antreten><de> 12 Teams treten im Prater auf kreativ umgestalteten Draisinen in Wettfahrten gegeneinander an.
<G-vec00121-002-s620><compete.antreten><en> At the Prater, 12 teams will compete against each other on creatively redesigned rail trolleys.
<G-vec00121-002-s621><compete.antreten><de> Sechs internationale Teams treten an drei Spieltagen gegeneinander an.
<G-vec00121-002-s621><compete.antreten><en> Six international teams will compete against each other on three match days.
<G-vec00121-002-s622><compete.antreten><de> Verschicke Showdown Challenges (Showdown-Herausforderungen) und tritt selbst dann gegen deine Freunde an, wenn einer von euch nicht online ist.
<G-vec00121-002-s622><compete.antreten><en> Send Showdown Challenges to compete against friends even when you are not both online.
<G-vec00121-002-s623><compete.antreten><de> Das Team aus Aachen tritt in der Challenger Kategorie an.
<G-vec00121-002-s623><compete.antreten><en> The Team from Aachen to compete in the Challenger category.
<G-vec00121-002-s624><compete.antreten><de> Tritt bei über 200 Rennen mit 500 Etappen rund um den Globus an, natürlich auch bei so berühmten Rennen wie La Vuelta und der legendären Tour de France.
<G-vec00121-002-s624><compete.antreten><en> Compete in over 200 races across 500 stages around the world, including famous Tours such as La Vuelta and the iconic Tour de France.
<G-vec00121-002-s625><compete.antreten><de> Stelle aus Tausenden von Spielern die perfekte Mannschaft zusammen, tritt im populärsten FIFA-Modus an und nutze Inhalte aus UEFA Champions League und UEFA Europa League.
<G-vec00121-002-s625><compete.antreten><en> Build your perfect line-up from thousands of players and compete in the most popular mode in FIFA, featuring content from the UEFA Champions League and Europa League.
<G-vec00121-002-s626><compete.antreten><de> Der Gewinner dieses Turniers fährt dann im kommenden Sommer nach Addis Abeba und tritt gegen 10 regionale Mannschaften an.
<G-vec00121-002-s626><compete.antreten><en> The winner of this tournament will travel to Addis Ababa next summer to compete against ten regional teams there.
<G-vec00121-002-s627><compete.antreten><de> Vergrößern Vergrößern Vergrößern Features: * Gewinne die FIFA Fussball-Weltmeisterschaft 2010 — Tritt als eine von 199 Mannschaften von der Qualifikation bis hin zur virtuellen Nachbildung der Endrunde der FIFA Fussball-Weltmeisterschaft 2010 an.
<G-vec00121-002-s627><compete.antreten><en> Win the 2010 FIFA World Cup – Compete as one of 199 teams from qualification right through to a virtual reproduction of the 2010 FIFA World Cup Final.
<G-vec00121-002-s628><compete.antreten><de> Beherrsche die Ranglisten - Tritt zu jeder Jahreszeit gegen andere Gegner an, um zu sehen, wer der beste Drachenlord ist und die exklusiven Gewinner-Avatare vorzuzeigen.
<G-vec00121-002-s628><compete.antreten><en> Dominate the leaderboards – compete against other opponents each Season to see who the ultimate Dragon Lords are and show off with exclusive winner avatars. System Requirements
<G-vec00121-002-s629><compete.antreten><de> Tritt in herausfordernden Ski- und Snowboard-Freestyle-Events an und schalte beim Spielen sogar noch mehr Events frei.
<G-vec00121-002-s629><compete.antreten><en> Compete in challenging new ski and snowboard freestyle events and unlock even more events by playing.
<G-vec00121-002-s630><compete.antreten><de> Wichtiger jedoch: Der Präsident tritt nicht nur gegen Capriles an, sondern auch gegen seine eigene Krebskrankheit.
<G-vec00121-002-s630><compete.antreten><en> More important, however, the president must compete against not only Capriles, but also cancer.
<G-vec00121-002-s631><compete.antreten><de> Stecke deinen Claim ab, manage deine Mannschaft und tritt für kurze Zeit täglich um eine Chance an, 1/8 Unze echtes Gold* zu gewinnen.
<G-vec00121-002-s631><compete.antreten><en> Stake your claim, run your crew, and for a limited time, compete daily for your chance to win 1/8 ounce of real gold*.
<G-vec00121-002-s632><compete.antreten><de> Der Weltstar und Gastgeber tritt mit einer illustren Auswahl absoluter Topsportler gegen die 1981 gegründete „Fußball-Nationalmannschaft der Rennfahrer“ an.
<G-vec00121-002-s632><compete.antreten><en> The NBA superstar and host will compete with other top athletes against the soccer team of racers founded in 1981.
<G-vec00121-002-s633><compete.antreten><de> Für noch mehr Abwechslung schalte das komplette Basisspiel sowie die Erweiterungen „Städte & Ritter“ und „Seefahrer“ als In-App-Kauf frei, wehre dich gegen Barbarenüberfälle, brich zu neuen Ufern auf und tritt gegen gewiefte Computergegner an.
<G-vec00121-002-s633><compete.antreten><en> For even more variety activate the complete basic game as well as the add-ons “Cities & Knights” and “Seafarers” as in-app purchases, defend yourself against barbarian invasions, conquer new frontiers, and compete against shrewd computer opponents.
<G-vec00121-002-s634><compete.antreten><de> Verbessere im herausfordernden Karrieremodus in vier Schwierigkeitsgraden deine Fähigkeiten und tritt dann in Matches für zwei Spieler und Multiplayer-Turnieren gegen den Rest der Welt an.
<G-vec00121-002-s634><compete.antreten><en> Hone your skills through four levels of challenging career mode, then compete against the globe in one-on-one matches and multiplayer tournaments.
<G-vec00121-002-s635><compete.antreten><de> ZEITRENNEN: Tritt gegen die Geisterfahrzeuge deiner eigenen sowie der gegnerischen Rundenbestzeiten an und lege die schnellstmögliche Rundenzeit hin.
<G-vec00121-002-s635><compete.antreten><en> TIME TRIAL: compete against your own best performance times, and your rivals’ ghost laps, to set the fastest lap time you possibly can.
<G-vec00121-002-s636><compete.antreten><de> Probiere verschiedene Techniken, denk dir eigene Herausforderungen aus und tritt gegen deine Freunde an – es gibt unendlich viele Möglichkeiten.
<G-vec00121-002-s636><compete.antreten><en> Experiment with different techniques, create your own challenges and compete against your friends—the possibilities are endless.
<G-vec00121-002-s637><compete.antreten><de> Rumänien tritt gemeinsam mit der Schweiz, Schweden, Irland, Österreich, der Republik Moldau, Lettland, Dänemark und Armenien im zweiten Halbfinale des Wettbewerbs an.
<G-vec00121-002-s637><compete.antreten><en> Romania will compete in the second semi-final, alongside Switzerland, Sweden, Ireland, Austria, the Republic of Moldova, Latvia, Denmark and Armenia.
<G-vec00121-002-s638><compete.antreten><de> Hol dir deine Lieblingskämpfer, passe sie an und tritt mit ihnen an.
<G-vec00121-002-s638><compete.antreten><en> Collect, play and compete with your favorite UFC fighters.
<G-vec00121-002-s639><compete.antreten><de> • Tritt jede Woche in zeitlich begrenzten Events mit einer neuen Herausforderung an.
<G-vec00121-002-s639><compete.antreten><en> • Compete in time limited events with a new challenge every week.
<G-vec00121-002-s640><compete.antreten><de> Tritt gegen den Computer oder deine Freunde an in einer farbenfrohen, stimmungsvollen Umgebung.
<G-vec00121-002-s640><compete.antreten><en> Compete against the computer or your friends in a colorful, comforting environment.
<G-vec00121-002-s641><compete.antreten><de> Tritt alleine oder online mit bis zu sieben Freunden an und versuche, Rekorde zu brechen und mit dem Nationalkader deiner Wahl den Sieg zu holen.
<G-vec00121-002-s641><compete.antreten><en> Compete alone or with up to seven friends online and strive to break records as you lead your chosen national squad to victory.
<G-vec00121-002-s642><compete.antreten><de> Wähle dein eigenes Land aus und tritt in der Europa-Meisterschaft an.
<G-vec00121-002-s642><compete.antreten><en> Choose your own country, and compete in the European tournament.
<G-vec00121-002-s643><compete.antreten><de> Tritt an gegen 100 der besten Angler der Welt, darunter Ali Hamidi, im Karpfen-, Barsch- und Raubfisch-Angeln.
<G-vec00121-002-s643><compete.antreten><en> Compete against over 100 of the best anglers on the planet including Ali Hamidi across Carp, Bass and Predator fishing.
<G-vec00121-002-s644><compete.antreten><de> ๏ Tritt in globalen Turnieren gegen andere Spieler auf der ganzen Welt an, zeige deine Stärke und gewinne tolle Preise.
<G-vec00121-002-s644><compete.antreten><en> ๏ COMPETE against other players around the world in global tournaments to show off your strength and earn amazing prizes
<G-vec00121-002-s646><compete.antreten><de> Tritt an gegen Freunde, Zufallsgegner oder einen von vier verschiedenen Computergegner, in einem Spiel das man als "Zwei-Spieler Solitär mit einer gehörigen Portion Spannung" beschreiben könnte.
<G-vec00121-002-s646><compete.antreten><en> Compete against a friend, a stranger or one of 4 different com- puter players, in what has been called a "two player Solitaire with an extra portion of suspense".
<G-vec00121-002-s647><compete.antreten><de> In dieser Saison tritt BLACK FALCON mit fünf Fahrzeugen von Mercedes-AMG und zwei Fahrzeugen von Porsche an.
<G-vec00121-002-s647><compete.antreten><en> This season BLACK FALCON will compete with five Mercedes-AMG cars and two cars from Porsche.
<G-vec00121-002-s648><compete.antreten><de> Tritt in einer wöchentlichen Herausforderung an.
<G-vec00121-002-s648><compete.antreten><en> Compete in a weekly challenge.
