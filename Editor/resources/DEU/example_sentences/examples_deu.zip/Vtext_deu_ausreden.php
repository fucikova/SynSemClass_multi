<G-vec00251-002-s018><dissuade.ausreden><de> Der Künstler erzählt, wie ihm während seines Studiums in den Neunzigern in Karlsruhe sein Professor das Malen mit Neonfarben auszureden versuchte.
<G-vec00251-002-s018><dissuade.ausreden><en> The artist relates that when he was studying in Karlsruhe in the nineties his painting professor tried to dissuade him from using neon colors.
<G-vec00555-002-s064><dismiss.ausreden><de> Beide hörten zu und schienen mitfühlend, aber versuchten auch mir das Ereignis auszureden oder mir zu sagen, warum es nicht real war.
<G-vec00555-002-s064><dismiss.ausreden><en> They both listened and seemed sympathetic, but also tried to dismiss the event or tell me why it wasn't real.
