<G-vec00403-002-s030><migrate.auswandern><de> Später im gleichen Jahrhundert zwang Verfolgung in Deutschland die Roma, nach Polen und Litauen auszuwandern, wo polnische Amtsträger ihre Ausweisung verlangten.
<G-vec00403-002-s030><migrate.auswandern><en> Later in that century, persecution in Germany forced Gypsies to migrate into Poland and Lithuania, where Polish officials demanded that they be expelled.
<G-vec00403-002-s031><migrate.auswandern><de> Darüber hinaus haben wir ängstlich beobachtet, dass viele unserer Brüder verpflichtet wurden, als Folge der Auseinandersetzungen, die vor kurzem im Irak ausgebrochen sind, auszuwandern.
<G-vec00403-002-s031><migrate.auswandern><en> Moreover, we have been anxiously witnessing that many of our brethren have been obliged to migrate as a result of the clashes that have recently erupted in Iraq.
<G-vec00403-002-s032><migrate.auswandern><de> Ihnen blieb nichts weiter übrig, als ihr Land aufzugeben und auszuwandern, vorwiegend nach Kalifornien.
<G-vec00403-002-s032><migrate.auswandern><en> Here, in what became known as the Dust Bowl, the inhabitants were battered so hard by sandstorms that they had no choice but to abandon their land and migrate, mostly to California.
<G-vec00403-002-s033><migrate.auswandern><de> Nach dem Ende des Zweiten Weltkrieges waren die Parier gezwungen auszuwandern, zuerst nach Piraeus und dann ins Ausland.
<G-vec00403-002-s033><migrate.auswandern><en> After the end of World War II, the Parians were forced to migrate, first to Piraeus and then abroad.
<G-vec00403-002-s034><migrate.auswandern><de> Kommt es zu einem harten, sprich vollkommen vertragslosen Brexit, sehen gerade viele mittelständische, britische Online-Händler, die auch international versenden, derzeit nur eine Lösung: Sie planen, mit ihrem Business teilweise auszuwandern – nach Deutschland.
<G-vec00403-002-s034><migrate.auswandern><en> If it comes to a hard (non-contractual) Brexit, just see many medium-sized, British online retailers who also ship internationally, have only one solution: They plan to migrate their businesses partially to Germany.
<G-vec00403-002-s035><migrate.auswandern><de> Der Anteil derer mit der „festen Absicht“, in den nächsten zwölf Monaten auszuwandern, hat sich von 0,5 % auf 1,2 % (d. h. von 2 auf 5 Millionen) verdoppelt und ist in Griechenland am höchsten.
<G-vec00403-002-s035><migrate.auswandern><en> The proportion of people with 'firm intentions' to migrate in the following 12 months has more than doubled, from 0.5 % to 1.2 %, i.e. from 2 to 5 million, and is highest in Greece.
<G-vec00048-002-s025><relocate.auswandern><de> Jede Note, jede Zeile ist inspiriert vom Meer, welches nicht nur seit Jahren der Grund für unzählige Roadtrips ist, sondern auch für die Entscheidung, im Frühjahr 2015 nach Südfrankreich auszuwandern.
<G-vec00048-002-s025><relocate.auswandern><en> Every note, every line is inspired by the sea, which is not only the reason for innumerable road trips, but also for his decision to relocate to the south of France in spring 2015.
<G-vec00048-002-s646><walk.auswandern><de> Wir wandern durch die imposante üppig grüne Mili Schlucht – ein altes Mühlental – mehrfach das Bachbett kreuzend.
<G-vec00048-002-s646><walk.auswandern><en> We walk through the imposing and very green gorge of Mili - a valley of former mills - crossing a small stream several times.
<G-vec00048-002-s647><walk.auswandern><de> Hier können Sie angeln gehen, Sonnenbaden, Schwimmen, Radfahren, Wandern in den Wald oder nur nehmen Sie es einfach und genießen Sie die schöne Aussicht auf den See mit seinen 24 kleinen Inseln.
<G-vec00048-002-s647><walk.auswandern><en> Here you can fish, sunbath, swim, bicycling, walk in the forest or just relax and enjoy the beautiful views over the lake with their 24 small islands.
<G-vec00048-002-s648><walk.auswandern><de> All das spürt man beim Wandern, wenn man den Geruch des Waldes und den Duft der Tannennadeln einatmet, wenn man ein Eichhörnchen auf dem Baum sieht, wenn man den schönsten Vogelkonzerten lauscht.
<G-vec00048-002-s648><walk.auswandern><en> All these emotions come for a walk, when smell the forest, the smell of pine needles, when you see the trees, jumping headlong nimble squirrel, when you listen to the wonderful bird shows.
<G-vec00048-002-s649><walk.auswandern><de> Ein feines Picknick oder ein gemütlicher Zwischenstopp in einem urigen Bergrestaurant gehören zum Wandern dazu.
<G-vec00048-002-s649><walk.auswandern><en> Your walk can include a fine picnic or a cosy stopover at a rustic mountain restaurant.
<G-vec00048-002-s650><walk.auswandern><de> In unseren Bed and Breakfast Unterkünften wandern Sie zwischen unseren durchstreifenden Hühnern, die Sie täglich mit köstlichen frischen Eiern versorgen.
<G-vec00048-002-s650><walk.auswandern><en> In our Bed and Breakfast accommodation you will walk between our roaming chickens, which provide you daily with delicious fresh eggs.
<G-vec00048-002-s651><walk.auswandern><de> Sie können ganz individuell zusammenstellen wann, wohin und wieviel Sie wandern möchten.
<G-vec00048-002-s651><walk.auswandern><en> You can individually customise your route as to when, where and how much you would like to walk.
<G-vec00048-002-s652><walk.auswandern><de> Wenn Du die Natur liebst, kannst Du durch die Wälder wandern, die Dante Alighieri vor Jahrhunderten durchquerte und die ihn wahrscheinlich zur berühmten Beschreibung der 'Selva oscura' inspirierten, dem Beginn der Göttlichen Komödie.
<G-vec00048-002-s652><walk.auswandern><en> If you love nature, you can walk in the woods that Dante Alighieri walked centuries ago and that probably inspired the famous description of the 'selva oscura' (dark forest) named at the beginning of the Divine Comedy.
<G-vec00048-002-s653><walk.auswandern><de> Von hier aus kann man direkt in unber├╝hrter Natur durch das Hochgebirge wandern.
<G-vec00048-002-s653><walk.auswandern><en> From here, you can walk directly into unspoilt nature through the high mountains.
<G-vec00048-002-s654><walk.auswandern><de> Von Maribor aus können Sie eine faszinierende Wein Tour durch die hiesigen Weinberge unternehmen oder durch die malerische Umgebung wandern.
<G-vec00048-002-s654><walk.auswandern><en> From Maribor you can take a walk through the picturesque surroundings through local wine-growing areas or join one of the interesting wine tours.
<G-vec00048-002-s655><walk.auswandern><de> Sie nach einem Ort in den Niederlanden auf der Suche sind, wo Sie zu jeder Jahreszeit wunderbar wandern und Fahrrad fahren können, ist die Provinz Brabant ein echter Geheimtipp.
<G-vec00048-002-s655><walk.auswandern><en> looking for a place in the Netherlands where you can walk and cycle at any time of the year, then the Province of Brabant is highly recommended.
<G-vec00048-002-s656><walk.auswandern><de> Wer im Hochsommer etwas Abkühlung sucht, kann zu den Eislöchern wandern.
<G-vec00048-002-s656><walk.auswandern><en> Anyone seeking a spot to cool off in summer can walk to the Ice Holes.
<G-vec00048-002-s657><walk.auswandern><de> In der Umgebung erwarten Sie verschiedene Möglichkeiten zum Wandern und Radfahren.
<G-vec00048-002-s657><walk.auswandern><en> There are various possibilities to walk and cycle in the surrounding area.
<G-vec00048-002-s658><walk.auswandern><de> Fünf Minuten vor 9 Uhr wurden wir schon mit Knütteln auf die Straße getrieben und mussten zuerst 25 Kilometer zu Fuß wandern.
<G-vec00048-002-s658><walk.auswandern><en> Five minuted before nine o'clock we were driven with blows from cudgels out into the street, and for starters we then had to walk 25 kilometers by foot.
<G-vec00048-002-s659><walk.auswandern><de> Wandern im bunten Laub, bei goldener Sonne und angenehmen Temperaturen.
<G-vec00048-002-s659><walk.auswandern><en> Walk amidst colourful trees, basking in the glorious sunshine and the pleasant temperatures.
<G-vec00048-002-s660><walk.auswandern><de> Von dort können Sie mit der Seilbahn nach Compatsch fahren und in zweieinhalb Stunden wieder zurück zu uns wandern.
<G-vec00048-002-s660><walk.auswandern><en> From there, you can take the cableway to Compatsch and in two and a half hours walk back to our house.
<G-vec00048-002-s661><walk.auswandern><de> Wenn Sie sich jedoch in Muxía in Richtung Santiago begeben, werden Sie im Vergleich zu den anderen Pilgern nicht nur in entgegengesetzte Richtung wandern, sondern Sie können bei Ihrer Ankunft an der Kathedrale von Compostela auch die Pilgerurkunde beantragen.
<G-vec00048-002-s661><walk.auswandern><en> However, if you leave from Muxía towards Santiago, you will not only walk in the reverse direction to the rest of the pilgrims but also upon your arrival at the Cathedral in Santiago de Compostela you can request your pilgrim’s certificate.
<G-vec00048-002-s662><walk.auswandern><de> Von dort aus wandern wir zur Ruine Drachenfels, die, ähnlich den Dahner Burgen, auf einem massiven Felsblock aus rotem Sandstein steht.
<G-vec00048-002-s662><walk.auswandern><en> From there we can walk to the ruins of Drachenfels Castle, which stands, like the castles at Dahn, on a massive red sandstone rock.
<G-vec00048-002-s663><walk.auswandern><de> Alle Schlafzimmer haben Zugang zu zwei weiteren Aussenterrassen, die es einem somit ermöglichen mit der Sonne zu wandern.
<G-vec00048-002-s663><walk.auswandern><en> All bedrooms have access to two further outside terraces, which allows to walk with the sun.
<G-vec00048-002-s664><walk.auswandern><de> Das heißt: tagsüber durch den wilden australischen Busch wandern, und nachts komfortabel wie die Könige speisen, trinken und im Luxus-Swag – der typischen australischen Kombination aus Zelt und Schlafsack – schlafen.
<G-vec00048-002-s664><walk.auswandern><en> That means during the day you walk through the wild, Australian bush, and at night you eat and drink like kings and enjoy a good night’s sleep in a deluxe swag – the typical Australian combination of tent and sleeping bag.
