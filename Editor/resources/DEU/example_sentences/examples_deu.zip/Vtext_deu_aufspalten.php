<G-vec00296-002-s052><split.aufspalten><de> Im Gegensatz zu Proteinen, die ja bekanntlich aus Aminosäuren bestehen, sind diese bereits in Peptide aufgespalten.
<G-vec00296-002-s052><split.aufspalten><en> In contrast to proteins which consist of amino acids is well known, they have already been split into peptides.
<G-vec00296-002-s053><split.aufspalten><de> § Eine Frau, die zusammen mit Ajahn Fuang die Meditation ausübte, fühlte sich mit der Zeit, als sei sie in zwei Personen aufgespalten: eine Person, die handelte, und eine Person, die zusah.
<G-vec00296-002-s053><split.aufspalten><en> § One woman who practiced meditation with Ajaan Fuang came to feel that she had split into two people: one person acting, and one watching.
<G-vec00296-002-s054><split.aufspalten><de> Dabei vollzieht sich ein komplexer Prozess, in dessen Verlauf die Polymermischung in kleine und kleinste Fasern und Gespinste aufgespalten wird, die sich auf der Gegenelektrode als Vlies ablagern.
<G-vec00296-002-s054><split.aufspalten><en> In the course of this operation, a complex process is carried out, during which the polymer blend is split up into fine and extremely fine fibres and webs that are deposited on the second electrode as a non-woven fabric.
<G-vec00296-002-s055><split.aufspalten><de> Bei der Photosynthese wird mit der Energie des Sonnenlichts Wasser in Sauerstoff, Protonen und Elektronen aufgespalten.
<G-vec00296-002-s055><split.aufspalten><en> When photosynthesis is split with the energy of sunlight water into oxygen, protons and electrons.
<G-vec00296-002-s056><split.aufspalten><de> Durch die freie Form ist es bereits aufgespalten und benötigt keinerlei Spaltenzyme.
<G-vec00296-002-s056><split.aufspalten><en> Its free form means that it is already split so it doesn't require any splitting enzymes.
<G-vec00296-002-s057><split.aufspalten><de> Also wurde Zork in drei Teile aufgespalten - dies ist der erste.
<G-vec00296-002-s057><split.aufspalten><en> So Zork was split into three parts - this one being the first.
<G-vec00296-002-s058><split.aufspalten><de> Auch wenn sich die mitteleuropäischen Ereignisse jenes Jahres aus einer Kette von Begebenheiten mit internationalen Ursachen zusammensetzten, zogen sie nationale Folgen nach sich: Die Geschichtstraditionen wurden aufgespalten und voneinander durch eigene nationale Bildungssysteme, Unwissenheit gegenüber den anderen Kulturen und durch ihre Bindung an ein eigenes nationales Publikum abgegrenzt.
<G-vec00296-002-s058><split.aufspalten><en> Although the Central European events of 1848 were imbedded in a concatenation of international causes, their consequences made themselves felt in a national manner: the traditions of history in Central and Eastern Europe were split and separated from each other by educational systems, ignorance of neighbouring cultures, and appeal to a restricted public.
<G-vec00296-002-s059><split.aufspalten><de> Durch chemische Umsetzungen können einige Polymere in ihre Monomerkomponenten aufgespalten werden, die dann für neue Synthesen zur Verfügung stehen.
<G-vec00296-002-s059><split.aufspalten><en> Through chemical processes, some polymers can be split up into their monomeric components, which are then available for new syntheses.
<G-vec00296-002-s060><split.aufspalten><de> Alles was wir essen und trinken, gelangt zunächst in Magen und Darm und wird dort aufgespalten.
<G-vec00296-002-s060><split.aufspalten><en> Everything we eat and drink, finds its way into stomach and bowel and is split there.
<G-vec00296-002-s061><split.aufspalten><de> Wenn du große Bälle triffst, werden sie in kleinere Teile aufgespalten.
<G-vec00296-002-s061><split.aufspalten><en> When you hit large balls, they will split into smaller pieces.
<G-vec00296-002-s062><split.aufspalten><de> Der Bundesfinanzhof führt als Gestaltungsbeispiel an, dass ein Betrieb mit mehr als 20 Beschäftigten in eine Besitzgesellschaft und eine Betriebsgesellschaft aufgespalten wird.
<G-vec00296-002-s062><split.aufspalten><en> The Federal Finance Court cites as an example for such a constellation a company with more than 20 employees that is split into a holding company and an operating company.
<G-vec00296-002-s063><split.aufspalten><de> Bei Anwahl der Checkbox Dreiecke separieren wird die Scherbe in die ursprünglichen Dreiecke aufgespalten, die jeweils ein eigenes Material bekommen können.
<G-vec00296-002-s063><split.aufspalten><en> When you select the checkbox Separate Triangles the shard is split into the original triangles which can get their own material respectively.
<G-vec00296-002-s064><split.aufspalten><de> Experimentieren Sie mit den Eigenschaften des Lichts und finden Sie heraus, wie es reflektiert, gebeugt und in ein unendliches Farbspektrum aufgespalten werden kann.
<G-vec00296-002-s064><split.aufspalten><en> Experiment with the properties of light and explore how it can be reflected, bent, or split into an infinite spectrum of colours.
<G-vec00296-002-s065><split.aufspalten><de> Auf Grund des Gesteinsmaterials wurde durch die zerstörenden Kräfte der Verwitterung der Komplex in einzelne Kuppeln aufgespalten.
<G-vec00296-002-s065><split.aufspalten><en> Due to the material of the rocks, the destroying forces of the alteration, the complex has been split into single cupolas.
<G-vec00296-002-s066><split.aufspalten><de> 3.5 Einzelne Editionen mit mehreren Lizenzen dürfen nicht aufgespalten und einzeln verkauft werden.
<G-vec00296-002-s066><split.aufspalten><en> 3.5 Individual editions containing several licenses may not be split up and sold separately.
<G-vec00296-002-s067><split.aufspalten><de> Die Armee bestand größtenteils aus "Barbaren", und das Reich selbst hatte sich in zwei aufgespalten.
<G-vec00296-002-s067><split.aufspalten><en> The army was largely manned by "barbarians" and the Empire itself had split in two.
