<G-vec00081-001-s051><halt.aufhalten><de> Aber bekannt sind auch Tatsachen anderer Art, die davon zeugen, dass die Entwicklung der Technik im Kapitalismus aufgehalten wird, wo die Kapitalisten als Reaktionäre auf dem Gebiet der Entwicklung der neuen Technik auftreten und nicht selten zur Handarbeit übergehen.
<G-vec00081-001-s051><halt.aufhalten><en> But we are also familiar with facts of a different kind, illustrative of a halt in technical development under capitalism, when the capitalists appear as reactionaries in the development of new techniques and not infrequently resort to hand labour.
<G-vec00081-001-s052><halt.aufhalten><de> Die nichtlinearen Prozesse verstärken sich danach so lange durch positive Rückkopplungen, bis sie eventuell durch eine natürliche negative Rückkopplung aufgehalten werden.
<G-vec00081-001-s052><halt.aufhalten><en> Thereafter, the nonlinear processes amplify through positive feedback, until they may possibly be brought to a halt by natural negative feedback.
<G-vec00081-001-s053><halt.aufhalten><de> Bis heute gibt es keine Behandlung, mit der die Krankheit aufgehalten oder rückgängig gemacht werden kann.
<G-vec00081-001-s053><halt.aufhalten><en> To date, there is still no treatment that can halt or reverse the progress of the disease.
<G-vec00185-001-s021><detain.aufhalten><de> Im Endeffekt musste man das Konzert auf zwei ganze Stunden aufhalten.
<G-vec00185-001-s021><detain.aufhalten><en> As a result a concert it was necessary to detain at the whole two o'clock.
<G-vec00185-001-s022><detain.aufhalten><de> Dieses unvorhergesehene und über ihre menschliche Macht gehende Ergebnis wird sie auf ihrem atemberaubenden und wahnwitzigen Laufe aufhalten.
<G-vec00185-001-s022><detain.aufhalten><en> This result, unforeseen and superior to their human power, will detain them in their frenzied and senseless journey.
<G-vec00185-001-s023><detain.aufhalten><de> Normalerweise zurren wir die Räder immer fest, doch diesmal wollten wir die netten Autofahrer nicht länger aufhalten (die haben nämlich an der Kreuzung einen anderen Radler abgeladen und und dann mitgenommen).
<G-vec00185-001-s023><detain.aufhalten><en> Ordinarily we lash the wheels always firmly, however, this time we wanted to detain the nice drivers no longer (they have off-loaded because at the crossroad another cyclist and and then have puck up).
<G-vec00185-001-s024><detain.aufhalten><de> Das arabische Wort für Geduld ist Sabr und es stammt von einem Wurzelwort das bedeutet, stoppen, aufhalten oder unterlassen.
<G-vec00185-001-s024><detain.aufhalten><en> The Arabic word for patience is sabr and it comes from a root word meaning to stop, detain, or refrain.
<G-vec00185-001-s025><detain.aufhalten><de> Denn Gottes Zorn vom Himmel wird offenbart über alles gottlose Wesen und Ungerechtigkeit der Menschen, die die Wahrheit in Ungerechtigkeit aufhalten.
<G-vec00185-001-s025><detain.aufhalten><en> For the wrath of God is revealed from heaven against all ungodliness and injustice of those men that detain the truth of God in injustice:
<G-vec00185-001-s026><detain.aufhalten><de> Nach SniPu П-3-79, soll die schallisolierte Tür nicht weniger als 26 Dezibel (db) aufhalten.
<G-vec00185-001-s026><detain.aufhalten><en> On SniPu П-3-79, the sound-proof door should detain not less than 26 decibels (db).
<G-vec00185-001-s027><detain.aufhalten><de> 15 Und Manoah sprach zu dem Engel Jehovas: Laß dich doch von uns aufhalten, so wollen wir dir ein Ziegenböcklein zubereiten.
<G-vec00185-001-s027><detain.aufhalten><en> 15 And Manoah said to the Angel of Jehovah, I pray thee, let us detain thee, and we will make ready a kid of the goats for thee.
<G-vec00185-001-s028><detain.aufhalten><de> Eine wasserdichte Tasche ist ein untrennbarer und äußerst praktischer Begleiter für Sportbegeisterte und Menschen welche sich häufig in der Natur und auch am oder im Wasser aufhalten.
<G-vec00185-001-s028><detain.aufhalten><en> A watertight pocket is an inseparable and extremely practical companion for keen on sport and people which often in the nature and also in or in the water detain.
<G-vec00081-001-s054><halt.aufhalten><de> Wirkstoffe, die das Enzym blockieren und bereits als Medikament zugelassen sind, könnten das Wachstum der Hirntumoren aufhalten.
<G-vec00081-001-s054><halt.aufhalten><en> Agents that block this enzyme have already been approved as drugs and may consequently be utilized to halt the growth of these brain tumors.
<G-vec00081-001-s055><halt.aufhalten><de> Und es dauert Millionen Jahre, manchmal Hunderte von Millionen Jahren, bis ein Planet sich erholt, wenn er sich überhaupt erholt.Je schneller wir etwas ändern, umso besser, dann können wir den Klimawandel aufhalten.
<G-vec00081-001-s055><halt.aufhalten><en> And it takes millions of years, sometimes hundreds of millions of years until any planet recovers, if it recovers at all. The quicker we change, the better, and then we can halt the climate change.
<G-vec00081-001-s056><halt.aufhalten><de> "December 10, 2018 / in Klima, Energie & Städte, Nachrichten, Pressemitteilungen / von Miriam Petersen Die neue parteien- und länderübergreifende Plattform für Parlamentarier verfolgt das Ziel, Lösungen zur umfangreichen und schnellen Förderung von erneuerbaren Energien zu entwickeln, denn ""nur eine zeitnahe Energiewende hin zu erneuerbaren Energien kann die Klimakrise noch aufhalten und uns vor den verheerenden Auswirkungen schützen""."
<G-vec00081-001-s056><halt.aufhalten><en> "December 10, 2018 / in Climate, Energy & Cities, News, Press Releases / by Miriam Petersen A new cross-country and cross-party platform for parliamentarians aims for the rapid and large-scale deployment of renewable energy solutions, as ""Only a swift transition to renewable energies can halt climate crisis and save us from its devastating impacts."""
<G-vec00081-001-s057><halt.aufhalten><de> Sie sehen, wenn Unternehmen gefrorene Produkte verpacken, sie schnell einfrieren und dabei den Verlust von Vitamin- und Mineralgehalt aufhalten.
<G-vec00081-001-s057><halt.aufhalten><en> You see, when companies package frozen produce, they quick-freeze it and, in doing so, halt the loss of vitamin and mineral content.
<G-vec00081-001-s058><halt.aufhalten><de> Der Anschlag versetzte die Hamas in eine heikle Situation, da sie befürchten muss, dass der Anschlag die Verbesserung ihrer Beziehungen mit Ägypten, die sich nach der Verstärkung der Einflusses der Muslimbruderschaft abzeichnet, aufhalten kann.
<G-vec00081-001-s058><halt.aufhalten><en> The attack caused Hamas great embarrassment because of its concern that the attack would halt the improvement in the movement's relations with Egypt, following the strengthening of the Muslim Brotherhood's influence in Egyptian politics.
<G-vec00081-001-s059><halt.aufhalten><de> Räte können die Enteignung der Dächer, Antennen zu finden nicht aufhalten.
<G-vec00081-001-s059><halt.aufhalten><en> Councils may not halt the expropriation of roofs to locate antennas – EHR
<G-vec00081-001-s060><halt.aufhalten><de> Dann fühlen Sie den Frust dieser Phase in Ihrem Körper, während unvorhergesehene Schwierigkeiten Sie in Ihrem Vorwärtsdrang aufhalten.
<G-vec00081-001-s060><halt.aufhalten><en> You'll feel the frustration in your body, as unforeseen troubles conspire to halt your forward movement.
<G-vec00081-001-s061><halt.aufhalten><de> Sie können weder flüchten, noch ihr Wüten aufhalten oder verringern, sie sind ihnen ausgeliefert und haben nur einen Retter, Dem sie sich anvertrauen können in ihrer Not, Den sie anrufen können um Hilfe und Der die Macht hat, ihnen zu helfen.
<G-vec00081-001-s061><halt.aufhalten><en> They can’t either flee nor halt or reduce their [the power’s] raging, they are at their mercy and have but one Savior whom they can entrust themselves in their misery, Whom they can call upon for help and who has the power to help them.
<G-vec00081-001-s062><halt.aufhalten><de> Sie wollen die Verlagerung wirtschaftlicher Macht zugunsten anderer Länder aufhalten.
<G-vec00081-001-s062><halt.aufhalten><en> They want to halt the shift of global economic power in favour of other countries.
<G-vec00081-001-s063><halt.aufhalten><de> Ohne strikte und verbindliche Vorschriften werden marktfreundliche soziale und Umweltmaßnahmen die Nivellierung nach unten nicht aufhalten, die durch die FHA selbst nachdrücklich ausgelöst wird.
<G-vec00081-001-s063><halt.aufhalten><en> Without strict and compulsory rules, market-friendly social and environmental measures will not halt the race-to-the-bottom which the FTAs themselves strongly induce.
<G-vec00081-001-s064><halt.aufhalten><de> Die Frage ist, wann wir den demographischen Niedergang werden aufhalten können.
<G-vec00081-001-s064><halt.aufhalten><en> So the question is when we will be able to halt the demographic decline.
<G-vec00081-001-s065><halt.aufhalten><de> Während Augenerkrankungen ein erhebliches globales Gesundheitsproblem darstellen, kann die Anwendung der Zellular Medizin diese Epidemie aufhalten und umkehren.
<G-vec00081-001-s065><halt.aufhalten><en> While visual impairment is a major global health issue, use of the Cellular Medicine approach can help halt and reverse this epidemic.
<G-vec00081-001-s066><halt.aufhalten><de> Die Änderung der Komsomolstatuten wird, sei sie auch durch Androhung neuer Polizeistrafen verstärkt, die politische Reifung der Jugend nicht aufhalten und ihren feindlichen Zusammenstoß mit der Bürokratie nicht verhüten.
<G-vec00081-001-s066><halt.aufhalten><en> The change in the constitution of the Communist Youth League, although reinforced with fresh police threats, will not, of course, halt the political maturing of the youth, and will not prevent their hostile clash with the bureaucracy.
<G-vec00081-001-s067><halt.aufhalten><de> Ihr seid jetzt so wie fortgeschritten, dass nichts den Prozess mehr aufhalten kann, dem Erfolg bestimmt ist.
<G-vec00081-001-s067><halt.aufhalten><en> You are so far advanced that nothing can halt the process, which is bound to succeed.
<G-vec00081-001-s068><halt.aufhalten><de> Das Tragen einer Halskrause in den frühen Stadien der Krankheit konnte in einigen Fällen die Progredienz aufhalten, da eine Beugung des Halses verhindert wird.
<G-vec00081-001-s068><halt.aufhalten><en> A cervical collar worn in the early stages of disease has been shown to halt progress of the disease in some cases, as it prevents neck flexion.
<G-vec00081-001-s069><halt.aufhalten><de> Frühzeitig eingesetzt, kann Thymuskin das Fortschreiten der androgenetischen Alopezie aufhalten, vorhandenes Haar erhalten und neues Haarwachstum anregen.
<G-vec00081-001-s069><halt.aufhalten><en> If used in good time, Thymuskin can halt the progression of androgenetic alopecia, preserve the existing hair and stimulate new hair growth.
<G-vec00081-001-s070><halt.aufhalten><de> Jüngste Klimamodelle zeigen, dass nur eine völlige Umkehrung der momentanen Kohlendioxid Emissionstrends mit dem Ziel von Null Kohlenstoffemissionen den gegenwärtigen Trend zur Erderwärmung aufhalten kann.
<G-vec00081-001-s070><halt.aufhalten><en> Recent climate models show that only a complete reversal of current carbon emission trends, with the target of zero carbon emissions globally, will halt the current global warming trends.
<G-vec00081-001-s095><stop.aufhalten><de> "Seinen Worten zufolge wird dieser Schritt die Pläne des ""Widerstands"" nicht aufhalten, sondern nur stärken."
<G-vec00081-001-s095><stop.aufhalten><en> "He said the bill would not stop the ""resistance"" program, but rather strengthen it."
<G-vec00081-001-s096><stop.aufhalten><de> „Die Entwicklung des Reiches Gottes kann niemand aufhalten“, erinnerte der Stammapostel an die Jesu-Worte von der Saat in der Erde.
<G-vec00081-001-s096><stop.aufhalten><en> “No one can stop the development of the kingdom of God,” the Chief Apostle reminded the congregation of Jesus’ words concerning the seed in the ground.
<G-vec00081-001-s097><stop.aufhalten><de> Ist daher der Geist zur Verschiebung angespannt, dann kann ihn nichts aufhalten.
<G-vec00081-001-s097><stop.aufhalten><en> Hence, when the spirit is strained toward a shifting, nothing can stop it.
<G-vec00081-001-s098><stop.aufhalten><de> Musik ist generell ein Erlebnis, das einen nicht aufhalten lässt.
<G-vec00081-001-s098><stop.aufhalten><en> Music, in general, is an experience that does not let you stop.
<G-vec00081-001-s099><stop.aufhalten><de> „Ich habe auch etwas Angst, Pan, aber das wird mich nicht aufhalten“, erklärte Uub.
<G-vec00081-001-s099><stop.aufhalten><en> “I’m a bit scared too, Pan, but I’m not going to let that stop me,” Uub said.
<G-vec00081-001-s100><stop.aufhalten><de> Dafür mussten viele Arbeitsschritte wie das Modeling, die Gestaltung des Sets, die Animation, das Lighting und das Compositing im Prozess parallel laufen; und damit sich das Team nicht an technischen Details aufhalten musste, lief der Entstehungsprozess mehr organisch und weniger formell.
<G-vec00081-001-s100><stop.aufhalten><en> In order to achieve their goal, many of the work phases had to run parallel to one another, including the modelling, set design, animation, lighting and compositing. This way, the team didn't have to stop for technical details; it also made the creation process more organic and less formal.
<G-vec00081-001-s101><stop.aufhalten><de> Selbst das Alter konnte den ambitionierten Boxer nicht aufhalten.
<G-vec00081-001-s101><stop.aufhalten><en> Even the age could not stop the ambitious boxer.
<G-vec00081-001-s102><stop.aufhalten><de> Es ist für jeden etwas dabei, so lass mich nicht aufhalten.
<G-vec00081-001-s102><stop.aufhalten><en> There is something for everyone here, so don’t let me stop you.
<G-vec00081-001-s103><stop.aufhalten><de> Erinnert euch, wir werden nie aufhalten, nie zurücktreten, und nie aufgeben.
<G-vec00081-001-s103><stop.aufhalten><en> Remember, we will never stop, never retreat, and never give up.
<G-vec00081-001-s104><stop.aufhalten><de> Das Regime setzte jedes mögliche Mittel ein, um den Kultivierungsweg zu verleumden und zu diffamieren, doch diese Maßnahmen konnten die weite Ausbreitung von Falun Gong auf der ganzen Welt nicht aufhalten oder gar verhindern, dass Menschen die Wahrheit erfahren.
<G-vec00081-001-s104><stop.aufhalten><en> The regime used every possible means to slander and defame the practice, however these measures couldn't stop the wide spread of Falun Gong around the world and prevent people from learning the truth.
<G-vec00081-001-s105><stop.aufhalten><de> Schon ein Tag Fleischverzicht pro Woche kann enorm viel Positives bewirken: Berechnungen zufolge könnte nur ein einziger Tag Fleischverzicht pro Woche in Deutschland, konsequent durchgehalten, den Klimawandel aufhalten.
<G-vec00081-001-s105><stop.aufhalten><en> Just one day a week without meat can have an enormous positive effect: According to calculations, only a single day of meat abstinence per week in Germany, consistently maintained, could stop climate change.
<G-vec00081-001-s106><stop.aufhalten><de> Der Erkenntnisprozeß läßt sich durch keine Macht der Welt aufhalten.
<G-vec00081-001-s106><stop.aufhalten><en> No power on earth can stop the perception process.
<G-vec00081-001-s107><stop.aufhalten><de> LEISTUNG Sicherheit Angesichts mehrerer in Echtzeit arbeitender Schutzstufen können wir alle Arten von Malware erkennen und Bedrohungen aufhalten, bevor diese Schaden an Ihrem Computer anrichten.
<G-vec00081-001-s107><stop.aufhalten><en> PERFORMANCE Security With multiple layers of security protecting you in real-time, we can detect all types of malware and stop threats before they harm your computer.
<G-vec00081-001-s108><stop.aufhalten><de> Ich werde aufschreiben, was die Stimmen aus China sagen, damit jedermann weiß, dass die KPC und Jiang Zemin die rechten Gedanken der Menschen in der Welt und ihre Unterstützung für Falun Dafa nicht aufhalten können.
<G-vec00081-001-s108><stop.aufhalten><en> Here I will note what the voices from China are saying so that everyone will know that the Chinese Communsit Party (CCP) and Jiang's persecution of Falun Gong can't stop the righteous thoughts of the world's people, or their support for Falun Dafa.
<G-vec00081-001-s109><stop.aufhalten><de> Babidi befreite Majin Buu mit Erfolg und unsere Helden konnten ihn nicht aufhalten.
<G-vec00081-001-s109><stop.aufhalten><en> Babidi successfully released Buu, and obviously, our heroes couldn't stop it.
<G-vec00081-001-s110><stop.aufhalten><de> Meiner Überzeugung nach denken sehr viele gutwillige Menschen auf naive Weise, dass wir sie sowieso nicht aufhalten können, und wenn wir sie schon nicht aufhalten können, dann ist es besser, wenn wir darüber nachdenken, wie wir sie integrieren sollen.
<G-vec00081-001-s110><stop.aufhalten><en> I'm convinced that a great many well-intentioned people naively believe that we can't stop them anyway, and if we can't stop them, it's better to start thinking about how we should take them in.
<G-vec00081-001-s112><stop.aufhalten><de> Auch noch im nächsten Jahrhundert, denn das Schicksal eines Volkes kann man nicht aufhalten.
<G-vec00081-001-s112><stop.aufhalten><en> It will be still there next century, there is no way to stop the destiny of these people.
<G-vec00081-001-s113><stop.aufhalten><de> Wenn ihr erst versteht, wie Liebe alles verändern kann, wird euch nichts mehr aufhalten können.
<G-vec00081-001-s113><stop.aufhalten><en> Once you fully understand how love can change everything, then nothing can stop you.
<G-vec00185-001-s029><detain.aufhalten><de> Das ungünstige Wetter kann den Ausgang aufhalten, auf etwas Tage grabend.
<G-vec00185-001-s029><detain.aufhalten><en> Adverse weather can detain a plenty exit for some days.
<G-vec00185-001-s030><detain.aufhalten><de> Die niedrigsten Classen werden uns nur für eine sehr kurze Zeit aufhalten, aber die höheren Thiere, besonders die Vögel, müssen in einer ziemlichen Ausführlichkeit betrachtet werden.
<G-vec00185-001-s030><detain.aufhalten><en> The lowest classes will detain us for a very short time, but the higher animals, especially birds, must be treated at considerable length.
<G-vec00185-001-s031><detain.aufhalten><de> Manchmal werden Sie aber von Amtspersonen, Inspektoren für öffentliche Ordnung begleitet, die berechtigt sind, Sie zum Ausweisen Ihrer Identität aufzufordern und bis zur Ankunft der Polizei aufzuhalten.
<G-vec00185-001-s031><detain.aufhalten><en> However, in some cases they are accompanied with security offi cials who have the right to ask for identifi cation and to detain you until the police arrives.
<G-vec00185-001-s032><detain.aufhalten><de> Zurücktretend, sprengten die Nazis die Brücken, veranstalteten die Sperren auf den Wegen, auf den vorteilhaften Grenzen des Geländes und in den zur Verteidigung vorbereiteten Orten versuchend, den Eintritt unserer Truppen aufzuhalten.
<G-vec00185-001-s032><detain.aufhalten><en> Receding, Hitlerites undermined bridges, arranged obstacles on roads, trying at favorable boundaries of the district and in the settlements prepared for defense to detain approach of our troops.
<G-vec00185-001-s033><detain.aufhalten><de> Dank wütend und neustraschimomu dem Charakter, übrigens werden die russisch-europäischen Eskimohunde nach speziell dressury sogar als dienstliche Hunde nicht selten verwendet und können helfen, die Verbrecher aufzuhalten.
<G-vec00185-001-s033><detain.aufhalten><en> Thanks to the furious and fearless character, by the way, the Russian-European likes after special training are quite often used even as guard dogs and can help to detain criminals.
<G-vec00081-001-s078><halt.aufhalten><de> Die Halbzeitbewertung hat aber auch gezeigt, dass ein zweites Ziel nur sehr schwer zu erreichen sein wird: den Verlust an biologischer Vielfalt bis 2020 aufzuhalten.
<G-vec00081-001-s078><halt.aufhalten><en> The mid-term review has also shown that it will be very difficult to achieve another target: to halt the loss of biodiversity by the year 2020.
<G-vec00081-001-s079><halt.aufhalten><de> Trump hat versprochen, etwa 10.000 bis 15.000 Soldaten an die mexikanische Grenze zu schicken, um die Karawane aufzuhalten und behauptet, dass die Flüchtlinge gar nicht aus Honduras kommen, sondern Terroristen aus dem Nahen Osten sind.
<G-vec00081-001-s079><halt.aufhalten><en> Trump promised to send 10 to 15,000 troops to the Mexican border to halt the caravan, and claimed that these refugees aren't even really from Honduras but are terrorists from the Middle East.
<G-vec00081-001-s080><halt.aufhalten><de> Die Partner des Deutschen Zentrums für Diabetesforschung (DZD), so auch das Helmholtz Zentrum München, forschen gemeinsam nach den Ursachen der Stoffwechselerkrankung, nach Möglichkeiten der Vorbeugung und nach neuen Behandlungsmöglichkeiten, um das Entstehen zu verhindern und/oder ein Fortschreiten der Erkrankungen aufzuhalten.
<G-vec00081-001-s080><halt.aufhalten><en> The partners of the German Center for Diabetes Research (DZD), thus also Helmholtz Zentrum München, conduct joint research into the causes of metabolic disease, approaches to prevention, and new treatment options to prevent the emergence and / or to halt the progression of the disease.
<G-vec00081-001-s081><halt.aufhalten><de> Die Demonstranten telefonierten mit Frau McLellan und dem Minister für Bürgerinteressen und Einwanderung Joe Volpe, um durch ihren politischen Willen die Abschiebung von Frau Hu aus humanitären Gründen aufzuhalten.
<G-vec00081-001-s081><halt.aufhalten><en> They called on Ms. McLellan and Joe Volpe, the minister of Citizen and Immigration, to use their political will to halt Ms. Hu's deportation on humanitarian grounds.
<G-vec00081-001-s082><halt.aufhalten><de> Zentral wird sein, ob es uns gelingen wird, den Klima­wandel aufzuhalten und uns darauf einzustellen.
<G-vec00081-001-s082><halt.aufhalten><en> The crucial question is whether we will manage to halt climate change and adapt to it.
<G-vec00081-001-s083><halt.aufhalten><de> In ihrer Sehnsucht nach greifbarer Wirklichkeit und unmittelbarer Wirkung versuchen sie die Verflüchtigung von Wirklichkeit und Identität aufzuhalten.
<G-vec00081-001-s083><halt.aufhalten><en> In their yearning to get a grip on reality and to experience immediate effect they attempt to halt the evaporation of reality and identity.
<G-vec00081-001-s084><halt.aufhalten><de> Um den Trend in Richtung Staatskapitalismus in den Marktwirtschaften aufzuhalten, ist die Eindämmung und möglichst ein „roll-back“ der bereits etablierten staatskapitalistischen Systeme erforderlich.
<G-vec00081-001-s084><halt.aufhalten><en> To halt the trend toward state-capitalism in the market economies requires the containment and possibly the “roll-back” of the already-established state-capitalist systems.
<G-vec00081-001-s085><halt.aufhalten><de> Anders ausgedrückt: Es ist im Fußball sehr schwer, einen negativen Trend aufzuhalten.
<G-vec00081-001-s085><halt.aufhalten><en> In other words: it is very difficult in football to halt a negative trend.
<G-vec00081-001-s086><halt.aufhalten><de> Mit dem Verschwinden der positiven Handelsbilanz wurde der Druck auf die Zahlungsbilanz durch weitere Kapitalexporte und die Kosten des Imperialismus immer stärker und führte zu dem Entschluß, den inflationistischen Kurs aufzuhalten.
<G-vec00081-001-s086><halt.aufhalten><en> With the disappearance of the trade surplus, the pressure is on the payments balance through greater capital exports and the costs of imperialism continued to grow, and thus contributed to the decision to halt the inflationary trend.
<G-vec00081-001-s087><halt.aufhalten><de> „Deutschland schafft sich ab“, warnt Sarrazin und ruft die Deutschen auf, diesen Prozess aufzuhalten.
<G-vec00081-001-s087><halt.aufhalten><en> “Germany is abolishing itself,” warns Sarrazin, and he calls on the Germans to halt this process.
<G-vec00081-001-s088><halt.aufhalten><de> Die 193 Vertragsstaaten des Übereinkommens über die biologische Vielfalt (CBD) haben sich das Ziel gesetzt, bis zum Jahr 2020 die nötigen Maßnahmen zu ergreifen, um den Verlust an biologischer Vielfalt aufzuhalten.
<G-vec00081-001-s088><halt.aufhalten><en> The 193 parties to the Convention on Biological Diversity (CBD) set themselves the target of taking the necessary measures to halt the loss of biodiversity by 2020.
<G-vec00081-001-s089><halt.aufhalten><de> Diese Machtverhältnisse müssten verändert werden, um den Vormarsch des Autos aufzuhalten.
<G-vec00081-001-s089><halt.aufhalten><en> This balance of power needs to be changed to halt the advance of the car.
<G-vec00081-001-s090><halt.aufhalten><de> Hier ist der Schlüssel, um die Abwärtsspirale aufzuhalten und ein Wesen von zwanghafter Beingness zu selbstbestimmter Beingness und direkt weiter hinauf zu Knowingness zu bringen.
<G-vec00081-001-s090><halt.aufhalten><en> Here is the key to halt the downward spiral and move a being from Compulsive Beingness to Self‐determined Beingness —and straight on up to Knowingness .
<G-vec00081-001-s091><halt.aufhalten><de> Ich möchte jetzt nicht lange über sie sprechen, nur soviel sagen, dass es gut wäre, wenn man hier in Tusnádfürdő und auch im Szeklerland wüsste, dass die Sicherheit Ungarns, des Szeklerlandes, des Karpatenbeckens und ganz Europas heute davon abhängt, ob die Türkei, Israel und Ägypten ausreichend stabile Länder sind, um das von dort aus nach Europa erfolgende Heraufströmen von Muslimen zu bremsen und aufzuhalten.
<G-vec00081-001-s091><halt.aufhalten><en> I don't want to talk about them at length now. It's enough for you to be aware, here also in TusnádfÃ1⁄4rdÅ‘ and Székely Land, that today the security of Hungary, of Székely Land, of the Carpathian Basin and of the whole of Europe depends on whether Turkey, Israel and Egypt are stable enough to curb and halt the Muslim influx coming into Europe from that region.
<G-vec00081-001-s092><halt.aufhalten><de> "Genau so verdutzt wie die heutige Generation werden sich die künftigen die gleichen Fragen über eine Reihe von Mythen des Zweiten Weltkrieges stellen, abgesehen von dem über die NS-Gaskammern: Zusätzlich zu den oben erwähnten Geschichten über die ""jüdische Seife"", gegerbte Menschenhaut, ""Schrumpfköpfe"", und ""Gaswagen"", könnte man auch die Geschichten hinzufügen über die wahnsinnigen medizinischen Experimente, die Dr. Mengele zugeschrieben werden, Adolf Hitlers Befehl, die Juden zu vernichten, Heinrich Himmlers Befehl, die genannten Vernichtungen aufzuhalten, und die Massentötungen von Juden durch Elektrizität, Dampf, ungelöschten Kalk, Krematorien, brennende Gruben und Vakuum-Pumpen."
<G-vec00081-001-s092><halt.aufhalten><en> "Just as perplexed as today's generation, those of the future will ask themselves identical questions about a number of Second World War myths besides that of the Nazi gas chambers: in addition to the stories already mentioned of ""Jewish soap,"" tanned human skins, ""shrunken heads,"" and ""gas vans,"" one may also cite the stories of the insane medical experiments attributed to Dr. Mengele, Adolf Hitler's orders to exterminate the Jews, Heinrich Himmler's order to halt said extermination, and the mass killings of Jews by electricity, steam, quicklime, crematories, burning pits, and vacuum pumps."
<G-vec00081-001-s093><halt.aufhalten><de> """Die EU-Länder, die auf die Führung der Türkei angewiesen sind, um die Migrationswelle aus Syrien aufzuhalten, müssen diesmal wohl ihre Gewohnheit aufgeben, das EU-Abenteuer der Türkei ständig zu blockieren."
<G-vec00081-001-s093><halt.aufhalten><en> """This time the EU countries that are relying on the Turkish leadership to halt the migratory wave from Syria will have to give up their habit of blocking Turkey's EU adventure."
<G-vec00081-001-s094><halt.aufhalten><de> B. aggregierte Formen von a -Synuklein, Störungen der Mitochondrienfunktion, um die Progression der Parkinson Erkrankung zu verlangsamen oder aufzuhalten, indem die Ausbreitung der Pathologie verhindert wird.
<G-vec00081-001-s094><halt.aufhalten><en> aggregated forms of a-synuclein, oxidative stress-induced cell death) to slow down or halt the progression of PD by preventing cell-to-cell spreading of pathology.
<G-vec00081-001-s095><halt.aufhalten><de> Ein Veto ist ein Weg für einen Entwickler eine übereilte oder schlecht überlegte Änderung aufzuhalten, zumindest lange genug, um weiter darüber zu diskutieren.
<G-vec00081-001-s095><halt.aufhalten><en> A veto is a way for a developer to put a halt to a hasty or ill-considered change, at least long enough for everyone to discuss it more.
<G-vec00081-001-s096><halt.aufhalten><de> Sie waren sich bewusst, dass die Kriege aus der Absicht entstehen, Räume in Besitz zu nehmen, die weiterlaufenden Prozesse einzufrieren und zu versuchen, sie aufzuhalten; dagegen suchten sie den Frieden, der nur verwirklicht werden kann in der ständigen Haltung, Prozesse in Gang zu setzen und sie voranzubringen.
<G-vec00081-001-s096><halt.aufhalten><en> They realized that wars arise from the effort to occupy spaces, to crystallize ongoing processes and to attempt to halt them. Instead, the founders sought peace, which can be achieved only when we are constantly open to initiating processes and carrying them forward.
<G-vec00081-001-s171><stop.aufhalten><de> "Doch ""das Schlimmste zu verhüten"" wird nicht ausreichen, um die Erosion von Demokratie und globaler Kooperationskultur aufzuhalten."
<G-vec00081-001-s171><stop.aufhalten><en> "But simply ""preventing the worst from happening"" will not be enough to stop the erosion of democracy and a global cooperation culture."
<G-vec00081-001-s172><stop.aufhalten><de> Aber an diesem Punkt sehe ich die zornige Gestalt Shachtmans sich erheben, um mich mit einer Gebärde des Protestes aufzuhalten: Die Opposition trägt keine Verantwortung für Burnhams Ansicht über das Dies-Komitee.
<G-vec00081-001-s172><stop.aufhalten><en> "But at this point I see the irate figure of Shachtman rising to stop me with a gesture of protest: ""The opposition bears no responsibility for Burnham's views on the Dies Committee."
<G-vec00081-001-s173><stop.aufhalten><de> Dann war dieser Sport nicht mehr aufzuhalten.
<G-vec00081-001-s173><stop.aufhalten><en> Then nobody was able to stop this sport.
<G-vec00081-001-s174><stop.aufhalten><de> "Doch das Bekämpfen lokaler ""Symptome"" reicht nicht aus, um Bodendegradierung und Desertifikation aufzuhalten."
<G-vec00081-001-s174><stop.aufhalten><en> "Fighting local ""symptoms"" alone is not enough to stop soil degradation and desertification."
<G-vec00081-001-s175><stop.aufhalten><de> Antioxidantien sind außerdem notwendig, um den Zellabbau aufzuhalten und stattdessen die Produktion von Kollagen und Elastin stimulieren – den grundlegenden Bausteinen der Haut, die diese prall, voll und gesund erscheinen lassen.
<G-vec00081-001-s175><stop.aufhalten><en> Antioxidants are also needed to stop cellular destruction while igniting the production of collagen and elastin — the very essence of skin structure that makes it appear plump, full and healthy.
<G-vec00081-001-s176><stop.aufhalten><de> Japans Wirtschaft erlebt eine schwere Depression; über die nächsten drei Jahre werden radikale Veränderungen in Regierung und Unternehmensstrukturen vorgenommen, um den umgreifenden Kollaps aufzuhalten.
<G-vec00081-001-s176><stop.aufhalten><en> Japan‘s economy enters a serious downturn; over the next three years, the nation goes through radical changes within its governmental and corporate structures in an attempt to stop the encroaching collapse.
<G-vec00081-001-s177><stop.aufhalten><de> Xena versucht ein paar Passanten aufzuhalten um ihnen Fragen zu stellen, aber die ignorieren sie und stürzen vorbei.
<G-vec00081-001-s177><stop.aufhalten><en> Xena tries to stop a few passersby to ask them questions, but they ignore her and rush past.
<G-vec00081-001-s178><stop.aufhalten><de> Keiner der sich in der Nähe befindenden Personen versuchte ihn aufzuhalten.
<G-vec00081-001-s178><stop.aufhalten><en> None of the people nearby tried to stop him.
<G-vec00081-001-s179><stop.aufhalten><de> In einem höchst ungewöhnlichen Schritt erklärte der Staatsanwalt, dass das deutsche Justizministerium und das deutsche Außenministerium befugt seien, das Auslieferungsverfahren aus politischen Gründen aufzuhalten.
<G-vec00081-001-s179><stop.aufhalten><en> In a highly unusual move, the Public Prosecutor stated that the German Ministry of Justice and the German Ministry of Foreign Affairs have the power to stop the extradition procedures on political grounds.
<G-vec00081-001-s180><stop.aufhalten><de> Insgesamt aber hat es der Naturschutz nicht geschafft, Entwicklungen wie den Verlust von Arten und die negativen Auswirkungen von intensiver Landnutzung in einem dicht besiedelten Land aufzuhalten.
<G-vec00081-001-s180><stop.aufhalten><en> However, conservation has been unable to stop biodiversity loss and the negative effects of intensive land use in such a closely populated country.
<G-vec00081-001-s181><stop.aufhalten><de> Es ist schwer, den Fluss psychischer Kräfte aufzuhalten, aber es ist stets zweckmäßig, seine physischen Kräfte zu schützen.
<G-vec00081-001-s181><stop.aufhalten><en> It is difficult to stop the flow of psychic forces, but it is always useful to protect one's physical forces.
<G-vec00081-001-s182><stop.aufhalten><de> Sie war vorne am Schiff aufgestellt, um als erste die gefährlichen Wellen zu sehen und sie nach Möglichkeit aufzuhalten.
<G-vec00081-001-s182><stop.aufhalten><en> It was situated at the ships' front in order to be the first to spot the dangerous waves and, wherever possible, stop them.
<G-vec00081-001-s183><stop.aufhalten><de> Um die Polizisten aufzuhalten, lief der alte Mann zu dem Polizeiauto und riskierte damit sein Leben, um die tückischen Polizisten aufzuhalten.
<G-vec00081-001-s183><stop.aufhalten><en> In order to stop the policemen, the elderly man ran to the police car wanting to stop the vicious policemen.
<G-vec00081-001-s184><stop.aufhalten><de> Nach Angaben der Behörden bemerkten die Wärter die Vandalen, versuchten sie aufzuhalten, sprühten sie jedoch mit Gasspray und flohen.
<G-vec00081-001-s184><stop.aufhalten><en> According to the authorities, the guards noticed the vandals, tried to stop them, but they sprayed them with gas spray and fled.
<G-vec00081-001-s185><stop.aufhalten><de> All dies geschieht bereits – trotz jener, die versuchen es aufzuhalten und jener, die die Leute angreifen, die ein Teil dieses Vorgangs sind.
<G-vec00081-001-s185><stop.aufhalten><en> All this is in the process of happening in spite of those who try to stop it and those who attack the people who are part of the process.
<G-vec00081-001-s186><stop.aufhalten><de> Da eilte eine Gruppe Polizisten auf uns zu, um uns aufzuhalten.
<G-vec00081-001-s186><stop.aufhalten><en> A group of police rushed over to stop us.
<G-vec00081-001-s187><stop.aufhalten><de> Die alten Energien zeigen zwar immer noch gewisse Auswirkungen, verlieren aber allmählich ihre Kraft, die kontinuierlichen Fortschritte ins Neue Zeitalter noch aufzuhalten.
<G-vec00081-001-s187><stop.aufhalten><en> The old energies still have some effects but are slowly losing their power to stop continuing progress into the New Age.
<G-vec00081-001-s188><stop.aufhalten><de> Außer meiner AK-47 hatte ich nur 2 ferngesteuerte Minen und einige Handgranaten zur Verfügung, um die Amerikaner aufzuhalten.
<G-vec00081-001-s188><stop.aufhalten><en> Beside of my AK-47 I only had two remote controlled mines and a few grenades to stop the Americans.
<G-vec00081-001-s189><stop.aufhalten><de> Die drei Alliierten beschließen, die Gründung eines westdeutschen Staates voranzutreiben und so den Vormarsch des Kommunismus aufzuhalten.
<G-vec00081-001-s189><stop.aufhalten><en> The three Allies decide to speed up the creation of a West German state that will help stop the spread of Communism.
<G-vec00185-001-s115><detain.aufhalten><de> Ich möchte das Parlament nicht lange aufhalten, weil einerseits auch andere Abgeordnete das Wort ergreifen wollen und weil ich andererseits über einen Aspekt der Menschenrechte in China sprechen will.
<G-vec00185-001-s115><detain.aufhalten><en> I do not intend to detain the House for long, partly because other hon. Members will be anxious to speak and partly because I want to raise an aspect of human rights in China.
<G-vec00205-002-s023><confront.aufhalten><de> Gypsys Anwalt, Michael Stanfield, hatte sie auch bemerkt und eilte aus dem Gerichtssaal, um sie aufzuhalten.
<G-vec00205-002-s023><confront.aufhalten><en> Gypsy’s attorney, Michael Stanfield, saw them too, and tried to hurry out of the courtroom to confront them.
<G-vec00205-002-s024><confront.aufhalten><de> Daraufhin lehnt er ab seinem Großonkel weiterhin zu helfen, und die anderen ziehen ohne ihn los, um Bill aufzuhalten.
<G-vec00205-002-s024><confront.aufhalten><en> Dipper refuses to offer further help, and the others go to confront Bill without him.
<G-vec00213-002-s030><halt.aufhalten><de> Hybride Kriegsführung, die militärische und nichtmilitärische Einrichtungen und Fähigkeiten kombiniert – ein Gebiet, auf dem Russland Pionierarbeit leistet –, kann den Niedergang verlangsamen, aber nicht aufhalten.
<G-vec00213-002-s030><halt.aufhalten><en> Hybrid warfare combining military and non-military assets and skills, an area pioneered by Russia, can slow but not halt the demise.
<G-vec00213-002-s032><halt.aufhalten><de> Weiterhin sollen maßgeschneiderte, kausale Therapien entwickelt werden, die die Krankheitsprogression aufhalten und zu einer Verbesserung der Patientenversorgung führen.
<G-vec00213-002-s032><halt.aufhalten><en> The DZD also strives to devise individualized causal therapies to halt disease progression and improve patient care.
<G-vec00213-002-s033><halt.aufhalten><de> Um es auf den Punkt zu bringen: Wir können die Entwicklung nicht aufhalten, sondern müssen sie für uns nutzen.
<G-vec00213-002-s033><halt.aufhalten><en> To put it in a nutshell: We cannot halt the development; rather, we have to make use of it.
<G-vec00213-002-s034><halt.aufhalten><de> Aber auch die Fertigstellung des Rothschönberger Stollns im Jahre 1877 als größter und bedeutendster sächsischer Stollen, der der Entwässerung des gesamten Freiberger Reviers diente, konnte den Niedergang nicht aufhalten.
<G-vec00213-002-s034><halt.aufhalten><en> But even the completion of the Rothschönberg adit in 1877, the largest and most important adit in Saxony, which drained the entire Freiberg ore fields, could do little to halt the decline.
<G-vec00213-002-s038><halt.aufhalten><de> Nur so kann sich die Menschheit dauerhaft und nachhaltig ernähren, nur so ist eine Zukunft ohne Ackergifte denkbar, nur so lässt sich der Verlust der biologischen Vielfalt aufhalten, und nur so können Klimawandel und extreme Wetterereignisse eingedämmt werden.
<G-vec00213-002-s038><halt.aufhalten><en> Without protecting the soil, bringing it back to life and building topsoil, it will be impossible to feed people, keep global warming below 2°C, transition to a toxic-free future, halt the loss of biodiversity and adapt to the challenges of climate change and extreme weather events.
<G-vec00213-002-s152><stop.aufhalten><de> Wenn dies geschieht, können die Ärzte eingreifen, um das Fortschreiten der Krankheit mit Medikamenten und Veränderungen des Lebensstils aufzuhalten oder zu verlangsamen.
<G-vec00213-002-s152><stop.aufhalten><en> When that happens, doctors can intervene to try to stop or lessen the progression of the disease with medication and lifestyle changes.
<G-vec00213-002-s153><stop.aufhalten><de> Später, als Lloyd seine Rede hielt, versuchte Harumi, eine Aufzeichnung seiner Niederlage gegen seinen Vater zu verwenden, um ihn aufzuhalten, aber er überwand seinen Schmerz und sprach weiter.
<G-vec00213-002-s153><stop.aufhalten><en> As Lloyd made his speech, Harumi tried using a recording of his loss against his father to stop him.
<G-vec00213-002-s154><stop.aufhalten><de> Jetzt müssen die Drachenreiter einen neuen Weg finden, um den tobenden Drachen aufzuhalten.
<G-vec00213-002-s154><stop.aufhalten><en> Hiccup and the Riders must choose a new course of action to stop the rampaging dragon.
<G-vec00213-002-s155><stop.aufhalten><de> Dort griff Kendra wütend Rip an, weil er Aldus getötet und schließlich getötet hatte.Schließlich stellte er fest, dass er ein ehemaliger Time Master war, der gegen Befehle verstossen hatte, um Savage zu töten, und Chronos war geschickt worden, um ihn aufzuhalten.
<G-vec00213-002-s155><stop.aufhalten><en> While there, Kendra angrily attacked Rip for getting Aldus killed and Rip finally revealed that he was a former Time Master, who had, against orders, assembled them to kill Savage, and Chronos had been sent to stop him.
<G-vec00213-002-s156><stop.aufhalten><de> Wir müssen Wege finden, Menschen aufzuhalten, die vor nichts Halt machen.
<G-vec00213-002-s156><stop.aufhalten><en> We have to find ways to stop people who will stop at nothing.
<G-vec00213-002-s157><stop.aufhalten><de> Wenn Brazil versucht, über See heranzukommen, besitzen wir eigentlich nichts an eine Marine Heranreichendes, das wir einsetzen könnten, um ihn aufzuhalten, und es bleibt keine Zeit, eine solche aufzubauen.
<G-vec00213-002-s157><stop.aufhalten><en> If Brazil tries to run by sea, we really don’t have anything like a navy to stop him, and there’s no time to build one.
<G-vec00213-002-s158><stop.aufhalten><de> Gleichzeitig gab die US-Regierung ihrer besten Spezialeinheit den Auftrag, die Wahrheit aufzudecken und den Ausbruch aufzuhalten.
<G-vec00213-002-s158><stop.aufhalten><en> Whilst the US govt have sent in their top Spec Ops team to find the truth and do what they can to stop the outbreak.
<G-vec00213-002-s159><stop.aufhalten><de> Hilf ihm dabei, das Auto aufzuhalten, bevor es gegen den Hydranten fährt und fliege danach schnell zurück zur Arbeit in das Büro im Daily Planet.
<G-vec00213-002-s159><stop.aufhalten><en> Help him to stop the car before it goes to the hydrant and then quickly fly back to work in the office at the Daily Planet .
<G-vec00213-002-s160><stop.aufhalten><de> Nichts hat die Macht, das aufzuhalten, was Ich angeordnet habe.
<G-vec00213-002-s160><stop.aufhalten><en> Nothing has the power to stop what I have ordained.
<G-vec00213-002-s161><stop.aufhalten><de> Bewaffnet und bereit begann Jayce seinen Angriff, indem er Viktors Gefolgsmänner, die herbeiströmten, um ihn aufzuhalten, einfach beiseite räumte.
<G-vec00213-002-s161><stop.aufhalten><en> Armed and ready, Jayce began his assault, easily smashing aside Viktor's acolytes as they rushed to stop him.
<G-vec00213-002-s162><stop.aufhalten><de> Die bis jetzt getroffenen Maßnahmen reichen nicht aus, den Rückgang der Artenvielfalt in Europa aufzuhalten.
<G-vec00213-002-s162><stop.aufhalten><en> Measures taken to date are not enough to stop the loss of biodiversity in Europe.
<G-vec00213-002-s163><stop.aufhalten><de> Die Frauen mochten ruhig rebellieren — die Männer brauchten nur zu warten, bis die ›Zeit‹ die Rebellen zwang, zurückzukriechen und zu flehen, so inbrünstig, daß sie vermutlich ihre beste Freundin getötet hätten, sollte diese versuchen, sie aufzuhalten.
<G-vec00213-002-s163><stop.aufhalten><en> The women could rebel, all right—and the men would simply wait for the Time to bring the rebels crawling, begging, so much in heat they’d probably kill their best friend if that friend tried to stop them.
<G-vec00213-002-s164><stop.aufhalten><de> Was immer bestimmt ist zu geschehen, wird geschehen, was immer du auch unternimmst, es aufzuhalten.
<G-vec00213-002-s164><stop.aufhalten><en> Whatever is destined to happen will happen, do what you may to stop it.
<G-vec00213-002-s165><stop.aufhalten><de> Danach unternehmen Sie eine Reise durch majestätische Wälder, gehen über neblige Berge, in spärlich beleuchtete Tavernen und hinunter in feuchte Minen, während Sie versuchen, die schattenhaften Kräfte des Bösen aufzuhalten, die versuchen das Land zu erobern.
<G-vec00213-002-s165><stop.aufhalten><en> You will then undertake a quest through majestic forests, go over misty mountains, into darkly lit taverns, and down dank mines as you try to stop the shadowy forces of evil trying to take hold of the land.
<G-vec00213-002-s166><stop.aufhalten><de> Aber Riddle in die LED-Boards am Eingang zu slammen trug wenig dazu bei, um The Original Bro aufzuhalten.
<G-vec00213-002-s166><stop.aufhalten><en> But slamming Riddle into the LED boards at the entranceway did little to stop The Original Bro.
<G-vec00213-002-s167><stop.aufhalten><de> Ich bitte euch dringend, dieses Kreuzzug-Gebet (31) zu sprechen, um sie aufzuhalten.
<G-vec00213-002-s167><stop.aufhalten><en> I urge you to say this Crusade Prayer (31) to stop them.
<G-vec00213-002-s168><stop.aufhalten><de> Da das weiße Kaninchen und der verrückte Hutmacher verschwunden sind, liegt es an Alice einen Weg zu finden, die böse Pik-Dame aufzuhalten, um ihre Freunde zu retten.
<G-vec00213-002-s168><stop.aufhalten><en> With the White Rabbit and Mad Hatter missing, it’s up to Alice to overcome her fears and find a way to stop the evil Queen of Spades to save her friends.
<G-vec00213-002-s169><stop.aufhalten><de> Sie sind jedoch durch Pfeile und andere Geräte geschützt, die es eilig haben, Sie aufzuhalten.
<G-vec00213-002-s169><stop.aufhalten><en> However, they are protected by arrows and other equipment that are in a hurry to stop you.
<G-vec00213-002-s170><stop.aufhalten><de> Wir müssen die Rolle des Stahlsektors bewahren und versuchen, den Niedergang der europäischen Industrie durch eine gerechte und ausgewogene Handelspolitik aufzuhalten.
<G-vec00213-002-s170><stop.aufhalten><en> We must preserve the role of the steel sector and try to stop Europe's industrial decline through a fair and balanced trade policy.
<G-vec00308-002-s049><reside.aufhalten><de> (3) Der Wegzug des Unionsbürgers aus dem Aufnahmemitgliedstaat oder sein Tod führt weder für seine Kinder noch für den Elternteil, der die elterliche Sorge für die Kinder tatsächlich wahrnimmt, ungeachtet ihrer Staatsangehörigkeit, bis zum Abschluss der Ausbildung zum Verlust des Aufenthaltsrechts, wenn sich die Kinder im Aufnahmemitgliedstaat aufhalten und in einer Bildungseinrichtung zu Ausbildungszwecken eingeschrieben sind.
<G-vec00308-002-s049><reside.aufhalten><en> 3. The Union citizen's departure from the host Member State or his/her death shall not entail loss of the right of residence of his/her children or of the parent who has actual custody of the children, irrespective of nationality, if the children reside in the host Member State and are enrolled at an educational establishment, for the purpose of studying there, until the completion of their studies.
<G-vec00308-002-s050><reside.aufhalten><de> Mit anderen Worten, niemand, wo auch immer er sich auf dem Planeten aufhalten mag, wird sicher sein, nur weil er nicht in Europa lebt.
<G-vec00308-002-s050><reside.aufhalten><en> In other words, no one, wherever they may reside on the planet, will be safe just because they don’t live in Europe.
<G-vec00308-002-s051><reside.aufhalten><de> Wenn das Konstanz-Prinzip im Sinne Fechners das Leben beherrscht, welches also dann ein Gleiten in den Tod sein sollte, so sind es die Ansprüche des Eros, der Sexualtriebe, welche als Triebbedürfnisse das Herabsinken des Niveaus aufhalten und neue Spannungen einführen.
<G-vec00308-002-s051><reside.aufhalten><en> If the consistency principle in the sense Fechner dominates life, which should be so then slipping into death, so are the claims of Eros, the sexual instincts, which reside as a driver needs the dropping of levels and introduce new tensions.
<G-vec00308-002-s052><reside.aufhalten><de> Das Supernal Realm ist das Reich der Magie, wo sich die Magi, die die Leiter erklommen haben, nun aufhalten.
<G-vec00308-002-s052><reside.aufhalten><en> The Supernal realm is the realm of magic, where the mages who climbed the ladder now reside.
<G-vec00325-002-s019><spend.aufhalten><de> Cookies helfen Sony dabei zu verstehen, welcher Teil der Webseiten der beliebteste ist, wohin Sony Besucher gehen und wie lange sie sich dort aufhalten.
<G-vec00325-002-s019><spend.aufhalten><en> Cookies help Sony understand which parts of its websites are the most popular, where Sony visitors are going, and how much time they spend there.
<G-vec00325-002-s020><spend.aufhalten><de> Nichts kann Sie mehr aufhalten, weder Berg noch Tal, ob flach oder steil.
<G-vec00325-002-s020><spend.aufhalten><en> Nothing you can spend more, neither hill nor valley, whether flat or steep.
<G-vec00325-002-s021><spend.aufhalten><de> Wir garantieren auch eine Erholungsfunktion für Personen, die sich bei uns für eine längere Zeit aufhalten wollen, um die Gegend zu besuchen oder die Umgebung und Ausstattung des Erholungszentrums zu nutzen.
<G-vec00325-002-s021><spend.aufhalten><en> However, at the same time we also provide recreation for people who wish to spend a longer time in our place, visiting the surroundings or enjoying the environment and using the equipment the centre provides.
<G-vec00325-002-s022><spend.aufhalten><de> Dürres wirkt beschäftigt und nicht sehr ordentlich, aber wir wollen uns hier nicht aufhalten, sondern nur das historische Amphitheater besichtigen.
<G-vec00325-002-s022><spend.aufhalten><en> Durrës is busy and not very tidy, but we do not want to spend much time here. We only want to visit the historic amphitheatre.
<G-vec00325-002-s023><spend.aufhalten><de> Auf dem Hauptbahnhof in Frankfurt gibt es glücklicherweise einen großen Buchladen, in dem man sich eine ganze Weile aufhalten kann.
<G-vec00325-002-s023><spend.aufhalten><en> Fortunately there is a large book store on Frankfurt Main Station, where you can spend a lot of time if you like to read.
<G-vec00325-002-s024><spend.aufhalten><de> Das von der Leinwand reflektierte Licht des Video-Beamers beleuchtet das alte, zerschlissene Mobiliar des Kinos und die erschöpften Gesichter der jungen Männer, die sich dort aufhalten oder schlafen.
<G-vec00325-002-s024><spend.aufhalten><en> The light of the video projector reflected off the screen illuminates the old, tattered furnishings of the cinema and the exhausted faces of the young men who spend time or sleep there.
<G-vec00325-002-s025><spend.aufhalten><de> Da die Camping-Information nicht rund um die Uhr geöffnet ist, ist nach Ladenschluss ein vorübergehendes Transitgebiet eingerichtet, wo man sich während der Nacht aufhalten kann und dann am nächsten Morgen einchecken kann.
<G-vec00325-002-s025><spend.aufhalten><en> Camping Information is not open round the clock. After closing time, a temporary holding area will be established, so you can spend the night and check in the following morning.
<G-vec00325-002-s026><spend.aufhalten><de> Wenn eine zentrale Stelle vorhanden ist, an der sich die Mitarbeiter während der Produktion üblicherweise aufhalten, hat sich der Einsatz von handelsüblichen Tablets zur Erfassung der Ursachen für Verfügbarkeits-, Leistungs- und Qualitätsverluste bewährt.
<G-vec00325-002-s026><spend.aufhalten><en> If there is a central location where employees usually spend time during production, the use of standard tablets to detect the causes of availability, performance, and quality losses has been proven.
<G-vec00325-002-s027><spend.aufhalten><de> Die Straßen von Shenzhen im chinesischen Pearl River Delta werden zu Orten, an denen Menschen sich wieder gern aufhalten.
<G-vec00325-002-s027><spend.aufhalten><en> The streets of Shenzhen in the Pearl River Delta in China once again become places where people like to spend time.
<G-vec00325-002-s028><spend.aufhalten><de> Produkterklärung Strapazierfähiger, warmer Daunenparka in Anorakform für alle, die sich viel bei strenger Kälte im Freien aufhalten.
<G-vec00325-002-s028><spend.aufhalten><en> Durable, warm down parka with anorak design for people who spend a lot of time outdoors in the extreme cold.
<G-vec00325-002-s029><spend.aufhalten><de> Toll wäre ein Haus mit eingezäunten Garten, wo er sich auch mal tagsüber aufhalten könnte.
<G-vec00325-002-s029><spend.aufhalten><en> Toll would have a house with a fenced yard where he could also spend time during the day.
<G-vec00325-002-s030><spend.aufhalten><de> Aber mein Favorit war natürlich der 1.000 m2 große Pool, wo man sich den ganzen Tag bei meditativen Musikklängen aufhalten konnte.
<G-vec00325-002-s030><spend.aufhalten><en> But my favorite was, of course, the 1,000 m2 pool, where you could spend the whole day with meditative music.
<G-vec00325-002-s031><spend.aufhalten><de> Wenn Sie über die Erlaubnis verfügen, den Gipfel des Teide zu besteigen, dürfen Sie sich bis zu 2 Stunden oben aufhalten.
<G-vec00325-002-s031><spend.aufhalten><en> If you have a permit to access the peak of Teide, you can stay longer at the summit, without exceeding the 2 hours you’re allowed to spend in this area.
<G-vec00325-002-s032><spend.aufhalten><de> Übergewichtige Katzen Genau wie Menschen, neigen auch Katzen häufig zu Übergewicht, vor allem wenn sie älter werden, weniger aktiv sind oder sich hauptsächlich im Haus aufhalten.
<G-vec00325-002-s032><spend.aufhalten><en> Just like us, cats can put on a few extra pounds, especially as they get older and become less active, or if they spend every day indoors.
<G-vec00325-002-s033><spend.aufhalten><de> ZEISS DuraVision BlueProtect ist eine spezielle Brillenglasveredelung für Menschen, die sich besonders viel in Innenräumen aufhalten und schädlichem blauem Licht ausgesetzt sind, das von LEDs, Fernsehern, Computerbildschirmen oder Tablets ausgestrahlt wird, und sich dadurch gestört fühlen.
<G-vec00325-002-s033><spend.aufhalten><en> DuraVision BlueProtect by ZEISS is a coating specially developed for people who spend a lot of their time indoors and are exposed to blue-violet light from LEDs as well as TV, computer or tablet screens.
<G-vec00325-002-s034><spend.aufhalten><de> In Ihrem Wanderurlaub in den Dolomiten können Sie sich wochenlang in der Region aufhalten, ohne eine Strecke zweimal zu begehen.
<G-vec00325-002-s034><spend.aufhalten><en> During your hiking holidays in the Dolomites you could spend entire weeks in this region, without walking twice on the same path.
<G-vec00325-002-s035><spend.aufhalten><de> Man kann sich auf einem Frachtschiff stundenlang auf der Brücke aufhalten, sich sämtliche Details der Navigation erklären lassen, oder sich vom Kapitän oder einem der Offiziere Tipps für den nächsten Landgang holen.
<G-vec00325-002-s035><spend.aufhalten><en> For example you can spend hours on the bridge and ask one of the friendly officers to explain you some of the technical equipment, or asking for advises considering your next excursion going ashore.
<G-vec00325-002-s036><spend.aufhalten><de> Flüsterleiser Betrieb Ob in Büroräumen oder in Hotelzimmern – Gebläsekonvektoren befinden sich meist dort, wo sich Menschen aufhalten.
<G-vec00325-002-s036><spend.aufhalten><en> Fan coil units are mostly used in offices and hotel rooms – places where people spend a lot of time.
<G-vec00325-002-s037><spend.aufhalten><de> Für alle anderen Berliner mit Ausnahme der Touristen ist die Mitte der Stadt kein Ort der Identifikation mehr, an dem man wohnen, essen gehen und sich aufhalten kann.
<G-vec00325-002-s037><spend.aufhalten><en> For all other citizens of Berlin, with the exception of tourists, the centre of the city is no longer a place one can identify with, where one can live, go out to eat, and spend time.
<G-vec00389-002-s021><thwart.aufhalten><de> Er katalogisiert Wissen über Abenteurer und sinnt darüber nach, wie er sie aufhalten kann.
<G-vec00389-002-s021><thwart.aufhalten><en> The beholder catalogs lore about adventurers and ponders methods to thwart them.
