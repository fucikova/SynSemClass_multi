<G-vec00279-002-s025><outperform.abschneiden><de> Mit einfachen Worten: Wir haben keine Ahnung, ob US- oder europäische Aktien besser abschneiden werden; gleichwohl gefällt uns der Risiko-Rendite-Tradeoff in Europa besser.
<G-vec00279-002-s025><outperform.abschneiden><en> Simply put, we have no idea whether US or European stocks will outperform, but we like the risk/return trade-off in Europe better.
<G-vec00555-002-s057><cut.abschneiden><de> Nach vielen vergeblichen Versuchen bleibt nur die Möglichkeit, die kranken Bäume abzuschneiden und zu verbrennen.
<G-vec00555-002-s057><cut.abschneiden><en> After lots of futile attempts to save the mango trees, the only remaining option is to cut and burn them.
<G-vec00555-002-s058><cut.abschneiden><de> Produkt-Beschreibung Dieser auswählbare Handy-WiFi-Störsender des Portable-3G u. GPS-Signal-Störsender, dass Sie hier ansehen, ist der neue entworfene Signalstörsender, der mit der Fähigkeit, die Signale von G/M, von DCS, von PCS, von 3G, von 4G, von 4G LTE, von 4G WiMax und von GPS Lojack abzuschneiden entworfen ist, i gleichzeitig.
<G-vec00555-002-s058><cut.abschneiden><en> Product Description This Selectable Portable 3G Cell Phone WiFi Jammer & GPS Signal Jammer that you are viewing here is the new designed signal jammer that is designed with the ability to cut off the signals of GSM, DCS, PCS, 3G,4G, 4G LTE,4G WiMax and WiFi GPS, i at the same time.
<G-vec00555-002-s059><cut.abschneiden><de> Dies gibt dem jeweils anlaufenden Spieler Zeit, ihn unter Druck zu setzen und weitere Optionen abzuschneiden.
<G-vec00555-002-s059><cut.abschneiden><en> This allows the player running at him enough time to put pressure on him and cut off other options.
<G-vec00555-002-s060><cut.abschneiden><de> Ein abgeschnittener Ofen wird verwendet möglicherweise, um Gas oder Leistung nach einer festgelegten Zeit abzuschneiden.
<G-vec00555-002-s060><cut.abschneiden><en> A stove cut off may be used to cut off gas or power after a specified time.
<G-vec00555-002-s061><cut.abschneiden><de> Die Hitze kann die Struktur deiner Locken schädigen und die einzige Möglichkeit, diese Schäden zu heilen, ist es die verbrannten Haare abzuschneiden.
<G-vec00555-002-s061><cut.abschneiden><en> The heat can damage your curl pattern and the only way to remedy the damage is to cut the torched hair off.
<G-vec00555-002-s062><cut.abschneiden><de> Das Mädchen war sehr beeindruckt, als der Vater ihm erzählte, dass es ihrem Landarzt nichts ausmacht, einen Arm oder ein Bein einem Menschen abzuschneiden oder sogar den Bauch zu reiβen und das Innere des Patienten herauszuziehen.
<G-vec00555-002-s062><cut.abschneiden><en> The girl was very impressed when her father told her that their country doctor easily could cut off a man's arm or leg, or even rip the belly and pull out the sick inside.
<G-vec00555-002-s063><cut.abschneiden><de> It seems, „Ich bin den ganzen Weg gerannt, um Ihnen den Weg abzuschneiden, Dr. Watson“, sagte sie.
<G-vec00555-002-s063><cut.abschneiden><en> "I have run all the way in order to cut you off, Dr. Watson," said she.
<G-vec00555-002-s064><cut.abschneiden><de> Es konnte mit einem Dezibel-Meter gesetzt werden, um eine Sehwarnung zur Verfügung zu stellen, als der Geräuschpegel am Nachbareigentum 45 DB überschritten hat und Hauptmacht von der Darstellerausrüstung abzuschneiden, wenn sie ständig die Warnlichter ignoriert haben.
<G-vec00555-002-s064><cut.abschneiden><en> It could be set, using a decibel meter to provide a visual warning when the sound level at the neighbours property exceeded 45dB and to cut off mains power from the performers equipment if they continually ignored the warning lights.
<G-vec00555-002-s065><cut.abschneiden><de> Das Freistellen-Werkzeug (nur in der Standalone-Version verfügbar) erlaubt es, unnötige Teile des Bildes abzuschneiden.
<G-vec00555-002-s065><cut.abschneiden><en> Crop (in the standalone version) lets you cut off unwanted areas in the image.
<G-vec00555-002-s066><cut.abschneiden><de> Eine herkömmliche Fahrzeugtür beinhaltet eine vollständige Außenhaut mit einem Fenster und Riegelhardware, um eine Fahrzeugkabine vollständig von der Umwelt abzuschneiden.
<G-vec00555-002-s066><cut.abschneiden><en> conventional vehicle door includes a complete outer skin with a window and lock hardware to cut off a vehicle cabin completely from the environment.
<G-vec00555-002-s067><cut.abschneiden><de> Zuvor folgen Sie der Rolle der Tapete, um mehrere Streifen zu messen und abzuschneiden, die Größe der Höhe der eingefügten Wand.
<G-vec00555-002-s067><cut.abschneiden><en> Beforehand, follow the roll of wallpaper to measure and cut off several strips, the size of the height of the pasted wall.
<G-vec00555-002-s068><cut.abschneiden><de> Wenn der Betriebsdruck der Schlammpumpe größer als der Einstelldruck ist, drückt der Abgabedruck der Schlammpumpe die Kolbenstange und den Kolben des Sicherheitsventils, um die Scherbolzenplatte zu öffnen und den Scherbolzen abzuschneiden, um sich sofort zu entladen der Druck der Schlammpumpe vom Auslass des Sicherheitsventils, um so die Schlammpumpe effektiv zu schützen.
<G-vec00555-002-s068><cut.abschneiden><en> When the operation pressure of the mud pump is greater than the setting pressure, the discharge pressure of the mud pump push piston rod and the piston of the safety valve so as to open the shear pin board, and cut off the shear pin to immediately discharge the pressure of the mud pump from the outlet of the safety valve, thus to protect the mud pump effectively.
<G-vec00555-002-s069><cut.abschneiden><de> Versuchen Sie, die zombiesâ € ™ Köpfe, um sie abzuschneiden mit dem Ball für doppelte Punktzahl zu treffen.
<G-vec00555-002-s069><cut.abschneiden><en> Try to hit the zombies’ heads to cut them off with the ball for double score.
<G-vec00555-002-s070><cut.abschneiden><de> Er verhielt sich zu den Besiegten großzügig, jedoch bevor er ihnen die Freiheit schenkte, hatte er befohlen, Rozhoň zur Warnung die Nase mit Sichel abzuschneiden.
<G-vec00555-002-s070><cut.abschneiden><en> He behaved in a noble-minded way towards them, but before setting them free, he ordered to cut off the nose of Rozhoň by a sickle as an exemplary act.
<G-vec00555-002-s071><cut.abschneiden><de> Das ist der Grund, warum es in manchen Ländern von einem gefordert wird, kapitales Fehlverhalten auf/anzuzeigen, um so die Gefahr des Üblichwerdens von Fehlhandlungen, und sich an Fehlhandlungen (auch mit Mitteln des Duldens) zu bereichern, abzuschneiden.
<G-vec00555-002-s071><cut.abschneiden><en> That is the reason why in some countries one is required to report capital wrong doings so to cut off ways to develop usuals from wrongs and gain benefit from the wrong deeds done by others in tolerating them, better taking part.
<G-vec00555-002-s072><cut.abschneiden><de> Viele ziehen es vor, die Spitze völlig abzuschneiden und auf dem Betrieb zu zählen, der seine Energie für eine erneuerte größere neue Spitze folgende wachsende Jahreszeit aufbaut.
<G-vec00555-002-s072><cut.abschneiden><en> Many prefer to cut the spike entirely off and count on the plant building up its energy for a renewed larger new spike next growing season.
<G-vec00555-002-s073><cut.abschneiden><de> Während die Umhüllungshaut gerollt wird, um das doppelte Falten der Teighaut zu verhindern, das einen ungleichmäßigen Geschmack verursacht, ist ein Rollenschneider ausgerüstet, um die zusätzliche Teighaut abzuschneiden.
<G-vec00555-002-s073><cut.abschneiden><en> While rolling the wrapper skin, to prevent the double folding of dough skin that causes uneven taste, a roller cutter is equipped to cut off the extra dough skin.
<G-vec00555-002-s074><cut.abschneiden><de> Dein Nachbar war korrekt, die schlechten Wurzeln abzuschneiden.
<G-vec00555-002-s074><cut.abschneiden><en> Your neighbor was correct to cut off the bad roots.
<G-vec00555-002-s075><cut.abschneiden><de> Um die Nachschublinien der Briten abzuschneiden, startet Deutschland 1917 einen uneingeschränkten U-Boot-Krieg.
<G-vec00555-002-s075><cut.abschneiden><en> To cut supply lines to England Germany starts unrestricted submarine warfare in 1917.
<G-vec00555-002-s057><cut_off.abschneiden><de> Nach vielen vergeblichen Versuchen bleibt nur die Möglichkeit, die kranken Bäume abzuschneiden und zu verbrennen.
<G-vec00555-002-s057><cut_off.abschneiden><en> After lots of futile attempts to save the mango trees, the only remaining option is to cut and burn them.
<G-vec00555-002-s058><cut_off.abschneiden><de> Produkt-Beschreibung Dieser auswählbare Handy-WiFi-Störsender des Portable-3G u. GPS-Signal-Störsender, dass Sie hier ansehen, ist der neue entworfene Signalstörsender, der mit der Fähigkeit, die Signale von G/M, von DCS, von PCS, von 3G, von 4G, von 4G LTE, von 4G WiMax und von GPS Lojack abzuschneiden entworfen ist, i gleichzeitig.
<G-vec00555-002-s058><cut_off.abschneiden><en> Product Description This Selectable Portable 3G Cell Phone WiFi Jammer & GPS Signal Jammer that you are viewing here is the new designed signal jammer that is designed with the ability to cut off the signals of GSM, DCS, PCS, 3G,4G, 4G LTE,4G WiMax and WiFi GPS, i at the same time.
<G-vec00555-002-s059><cut_off.abschneiden><de> Dies gibt dem jeweils anlaufenden Spieler Zeit, ihn unter Druck zu setzen und weitere Optionen abzuschneiden.
<G-vec00555-002-s059><cut_off.abschneiden><en> This allows the player running at him enough time to put pressure on him and cut off other options.
<G-vec00555-002-s060><cut_off.abschneiden><de> Ein abgeschnittener Ofen wird verwendet möglicherweise, um Gas oder Leistung nach einer festgelegten Zeit abzuschneiden.
<G-vec00555-002-s060><cut_off.abschneiden><en> A stove cut off may be used to cut off gas or power after a specified time.
<G-vec00555-002-s061><cut_off.abschneiden><de> Die Hitze kann die Struktur deiner Locken schädigen und die einzige Möglichkeit, diese Schäden zu heilen, ist es die verbrannten Haare abzuschneiden.
<G-vec00555-002-s061><cut_off.abschneiden><en> The heat can damage your curl pattern and the only way to remedy the damage is to cut the torched hair off.
<G-vec00555-002-s062><cut_off.abschneiden><de> Das Mädchen war sehr beeindruckt, als der Vater ihm erzählte, dass es ihrem Landarzt nichts ausmacht, einen Arm oder ein Bein einem Menschen abzuschneiden oder sogar den Bauch zu reiβen und das Innere des Patienten herauszuziehen.
<G-vec00555-002-s062><cut_off.abschneiden><en> The girl was very impressed when her father told her that their country doctor easily could cut off a man's arm or leg, or even rip the belly and pull out the sick inside.
<G-vec00555-002-s063><cut_off.abschneiden><de> It seems, „Ich bin den ganzen Weg gerannt, um Ihnen den Weg abzuschneiden, Dr. Watson“, sagte sie.
<G-vec00555-002-s063><cut_off.abschneiden><en> "I have run all the way in order to cut you off, Dr. Watson," said she.
<G-vec00555-002-s064><cut_off.abschneiden><de> Es konnte mit einem Dezibel-Meter gesetzt werden, um eine Sehwarnung zur Verfügung zu stellen, als der Geräuschpegel am Nachbareigentum 45 DB überschritten hat und Hauptmacht von der Darstellerausrüstung abzuschneiden, wenn sie ständig die Warnlichter ignoriert haben.
<G-vec00555-002-s064><cut_off.abschneiden><en> It could be set, using a decibel meter to provide a visual warning when the sound level at the neighbours property exceeded 45dB and to cut off mains power from the performers equipment if they continually ignored the warning lights.
<G-vec00555-002-s065><cut_off.abschneiden><de> Das Freistellen-Werkzeug (nur in der Standalone-Version verfügbar) erlaubt es, unnötige Teile des Bildes abzuschneiden.
<G-vec00555-002-s065><cut_off.abschneiden><en> Crop (in the standalone version) lets you cut off unwanted areas in the image.
<G-vec00555-002-s066><cut_off.abschneiden><de> Eine herkömmliche Fahrzeugtür beinhaltet eine vollständige Außenhaut mit einem Fenster und Riegelhardware, um eine Fahrzeugkabine vollständig von der Umwelt abzuschneiden.
<G-vec00555-002-s066><cut_off.abschneiden><en> conventional vehicle door includes a complete outer skin with a window and lock hardware to cut off a vehicle cabin completely from the environment.
<G-vec00555-002-s067><cut_off.abschneiden><de> Zuvor folgen Sie der Rolle der Tapete, um mehrere Streifen zu messen und abzuschneiden, die Größe der Höhe der eingefügten Wand.
<G-vec00555-002-s067><cut_off.abschneiden><en> Beforehand, follow the roll of wallpaper to measure and cut off several strips, the size of the height of the pasted wall.
<G-vec00555-002-s068><cut_off.abschneiden><de> Wenn der Betriebsdruck der Schlammpumpe größer als der Einstelldruck ist, drückt der Abgabedruck der Schlammpumpe die Kolbenstange und den Kolben des Sicherheitsventils, um die Scherbolzenplatte zu öffnen und den Scherbolzen abzuschneiden, um sich sofort zu entladen der Druck der Schlammpumpe vom Auslass des Sicherheitsventils, um so die Schlammpumpe effektiv zu schützen.
<G-vec00555-002-s068><cut_off.abschneiden><en> When the operation pressure of the mud pump is greater than the setting pressure, the discharge pressure of the mud pump push piston rod and the piston of the safety valve so as to open the shear pin board, and cut off the shear pin to immediately discharge the pressure of the mud pump from the outlet of the safety valve, thus to protect the mud pump effectively.
<G-vec00555-002-s069><cut_off.abschneiden><de> Versuchen Sie, die zombiesâ € ™ Köpfe, um sie abzuschneiden mit dem Ball für doppelte Punktzahl zu treffen.
<G-vec00555-002-s069><cut_off.abschneiden><en> Try to hit the zombies’ heads to cut them off with the ball for double score.
<G-vec00555-002-s070><cut_off.abschneiden><de> Er verhielt sich zu den Besiegten großzügig, jedoch bevor er ihnen die Freiheit schenkte, hatte er befohlen, Rozhoň zur Warnung die Nase mit Sichel abzuschneiden.
<G-vec00555-002-s070><cut_off.abschneiden><en> He behaved in a noble-minded way towards them, but before setting them free, he ordered to cut off the nose of Rozhoň by a sickle as an exemplary act.
<G-vec00555-002-s071><cut_off.abschneiden><de> Das ist der Grund, warum es in manchen Ländern von einem gefordert wird, kapitales Fehlverhalten auf/anzuzeigen, um so die Gefahr des Üblichwerdens von Fehlhandlungen, und sich an Fehlhandlungen (auch mit Mitteln des Duldens) zu bereichern, abzuschneiden.
<G-vec00555-002-s071><cut_off.abschneiden><en> That is the reason why in some countries one is required to report capital wrong doings so to cut off ways to develop usuals from wrongs and gain benefit from the wrong deeds done by others in tolerating them, better taking part.
<G-vec00555-002-s072><cut_off.abschneiden><de> Viele ziehen es vor, die Spitze völlig abzuschneiden und auf dem Betrieb zu zählen, der seine Energie für eine erneuerte größere neue Spitze folgende wachsende Jahreszeit aufbaut.
<G-vec00555-002-s072><cut_off.abschneiden><en> Many prefer to cut the spike entirely off and count on the plant building up its energy for a renewed larger new spike next growing season.
<G-vec00555-002-s073><cut_off.abschneiden><de> Während die Umhüllungshaut gerollt wird, um das doppelte Falten der Teighaut zu verhindern, das einen ungleichmäßigen Geschmack verursacht, ist ein Rollenschneider ausgerüstet, um die zusätzliche Teighaut abzuschneiden.
<G-vec00555-002-s073><cut_off.abschneiden><en> While rolling the wrapper skin, to prevent the double folding of dough skin that causes uneven taste, a roller cutter is equipped to cut off the extra dough skin.
<G-vec00555-002-s074><cut_off.abschneiden><de> Dein Nachbar war korrekt, die schlechten Wurzeln abzuschneiden.
<G-vec00555-002-s074><cut_off.abschneiden><en> Your neighbor was correct to cut off the bad roots.
<G-vec00555-002-s075><cut_off.abschneiden><de> Um die Nachschublinien der Briten abzuschneiden, startet Deutschland 1917 einen uneingeschränkten U-Boot-Krieg.
<G-vec00555-002-s075><cut_off.abschneiden><en> To cut supply lines to England Germany starts unrestricted submarine warfare in 1917.
<G-vec00047-002-s019><cut.abschneiden><de> Ordnen Sie längeren Text über mehrere Zeilen an, um zu vermeiden, dass Text an kleineren Umbruchpunkten abgeschnitten wird.
<G-vec00047-002-s019><cut.abschneiden><en> Wrap longer text over multiple lines to avoid text getting cut off in smaller breakpoints.
<G-vec00047-002-s020><cut.abschneiden><de> Ein runder Schokoladenkuchen (28cm Durchmesser) - die Seiten abgeschnitten und als Ohren wieder seitlich angesetzt, 1 Rezept Schokoladenbuttercreme und ein paar Löffel baubles.
<G-vec00047-002-s020><cut.abschneiden><en> A round chocolate cake (28 cm diameter) - the sides cut off and moved to the side as ears, one recipe of Cream Cheese Frosting.
<G-vec00047-002-s021><cut.abschneiden><de> Achtung: Bitte halten Sie die Verbindung zwischen Ihrem iPhone und Ihrem PC, so dass das Prozess nicht abgeschnitten werden wird.
<G-vec00047-002-s021><cut.abschneiden><en> Note: Please keep your iPhone connecting with PC lest the process would be cut off.
<G-vec00047-002-s022><cut.abschneiden><de> Im Herbst, vor dem Einsetzen des ersten Frosts, sollten die Triebe des letzten Jahres, in denen die stärkste Blüte stattfand, fast bis zum Boden abgeschnitten werden (etwa 10 cm Abstand lassen).
<G-vec00047-002-s022><cut.abschneiden><en> In the autumn, before the onset of the first frost, last year's shoots, where the most powerful flowering took place, should be cut off almost to the ground (leave about 10 cm).
<G-vec00047-002-s023><cut.abschneiden><de> Als die Polizei sie schließlich ins Krankenhaus brachte, sagte der Arzt, dass die Blutzirkulation in ihren Beinen abgeschnitten sei.
<G-vec00047-002-s023><cut.abschneiden><en> When the police eventually took her to a hospital, a doctor said the that circulation in her legs was cut off.
<G-vec00047-002-s024><cut.abschneiden><de> Wenn Sie ein großes Badezimmer mit einem Fenster, einem französischen oder einem vollen Balkon haben, dann wird die Dekoration Blumen sein: Zimmerpflanzen, die für das Wachstum in einem warmen und feuchten Klima geeignet sind oder abgeschnitten werden und in Vasen stehen.
<G-vec00047-002-s024><cut.abschneiden><en> If you have a large bathroom with a window, a French or a full balcony, then its decoration will be flowers: houseplants suitable for growing in a warm and humid climate or cut off, standing in vases.
<G-vec00047-002-s025><cut.abschneiden><de> •"Abgeschnitten und verkauft," sagte Della.
<G-vec00047-002-s025><cut.abschneiden><en> •“Cut it off and sold it,” said Della.
<G-vec00047-002-s026><cut.abschneiden><de> Ausgestattet mit 22" in der Länge, 17" in der Breite; 18" in Kammer Produkttiefe mit 40" Long x 7" OD Selbstschärf abgeschnitten Klingen, 7½ ‚ID Gewindeproduktabgabeöffnung mit 8-5 / 8‘ Durchmesser plate OD Schraube mit 8" Schleifen und hat 42" Bodenfreiheit.
<G-vec00047-002-s026><cut.abschneiden><en> Equipped with 22" in Length; 17" in Width; 18" in Depth product chamber with 40" Long x 7" OD grinding screw with 8" OD self sharpening cut off blades, 7½"ID threaded product discharge port with 8-5/8" diameter plate and has 42" floor clearance.
<G-vec00047-002-s027><cut.abschneiden><de> Es gibt ein gemeinsames Netz, doch dessen Fäden sind abgeschnitten, und wir müssen sie wieder verbinden.
<G-vec00047-002-s027><cut.abschneiden><en> There is a common network; however, its threads are cut off, and we have to reconnect them.
<G-vec00047-002-s028><cut.abschneiden><de> Hinter dem Bullen ritt ein Junge genäht in ein Bärenfell auf einem Pferd, dessen Ohren und Schwanz abgeschnitten worden waren.
<G-vec00047-002-s028><cut.abschneiden><en> Behind the bull a young boy sewn into a bear skin rode on a horse whose ears and tail were cut off.
<G-vec00047-002-s029><cut.abschneiden><de> Beim Bau der Mauer 1961 wurde der Zipfel durch die Sperranlagen abgeschnitten und blieb als nur provisorisch umzäunte, nach West-Berlin hinragende Brachfläche bestehen.
<G-vec00047-002-s029><cut.abschneiden><en> When the Wall went up in 1961, this triangular piece of land was cut off by the border installations; projecting into West Berlin, it was surrounded by a makeshift fence and left undeveloped.
<G-vec00047-002-s030><cut.abschneiden><de> Der Krieg und die Ereignisse des Krieges haben die Entwicklungslinie des Bewusstseins der ArbeiterInnen völlig abgeschnitten und ihr eine andere Richtung gegeben, als man es vorhersehen konnte.
<G-vec00047-002-s030><cut.abschneiden><en> The war and the events of the war have cut completely across the line of development of the consciousness of the workers and given it a different direction to what might have been anticipated.
<G-vec00047-002-s031><cut.abschneiden><de> Für den Stamm des Tannenbaumes wird eine der Scheiben flach abgeschnitten.
<G-vec00047-002-s031><cut.abschneiden><en> For the trunk of the Christmas tree, one of the slices has to be cut flat.
<G-vec00047-002-s032><cut.abschneiden><de> Kronos, fuhr Sandro fort, war der Sohn des Gottes Uranus und der Göttin der Erde und als Kronos die Gonaden seines Vaters abgeschnitten hatte und ins Meer warf, erschien Venus, die Göttin der Liebe und der Sexualität, römische Erbin der griechischen Göttin Aphrodite, aus dem Meerschaum.
<G-vec00047-002-s032><cut.abschneiden><en> Cronus, continued Sandro, was the son of the Earth Goddess and the God Uranus, and it was Cronus himself who cut off the gonads of his father and when he threw them into the sea from the foam appeared Aphrodite, goddess of love and sexuality. Venus, he continued saying, was the Roman heiress of the Greek Goddess Aphrodite.
<G-vec00047-002-s033><cut.abschneiden><de> Auch als ich Ihre Motive noch gar nicht kannte – die Verbindungen waren doch abgeschnitten –, wie beim Frieden von Brest-Litowsk, verteidigte ich Sie mit Ihren Motiven.
<G-vec00047-002-s033><cut.abschneiden><en> Also when I did not know your motives as yet – the connections being cut off – as at the time of the Brest-Litovsk peace, I defended you with your own motives.
<G-vec00047-002-s034><cut.abschneiden><de> 13 Wenn dann die Fußsohlen der Priester, welche die Lade des HERRN, des Herrn der ganzen Erde, tragen, im Wasser des Jordan stillstehen, so wird das Wasser des Jordan, das Wasser, das von oben herabfließt, abgeschnitten werden, und es wird stehen bleiben wie ein Damm.
<G-vec00047-002-s034><cut.abschneiden><en> And it shall come to pass, as soon as the soles of the feet of the priests who bear the ark of the Lord, the Lord of all the earth, shall rest in the waters of the Jordan, that the waters of the Jordan shall be cut off, the waters that come down from upstream, and they shall stand as a heap.”
<G-vec00047-002-s035><cut.abschneiden><de> Von einer Integrationsmöglichkeit in die kanadische Gesellschaft sind sie oft genauso abgeschnitten wie von der meist mündlich überlieferten Geschichte ihrer Vorfahren, die zusammen mit den verbotenen Dialekten ausstarb.
<G-vec00047-002-s035><cut.abschneiden><en> Many of them are just as cut off from any path toward integration into Canadian society as from the histories of their forebears, which was usually transmitted in the form of oral traditions and died out together with the banned dialects.
<G-vec00047-002-s036><cut.abschneiden><de> An manchen Stellen kann das Muster gebogen oder abgeschnitten sein, damit es akkurater aussieht.
<G-vec00047-002-s036><cut.abschneiden><en> It may need to bend or be cut off at certain points to look accurate.
<G-vec00047-002-s037><cut.abschneiden><de> Intellektuelle sollten Netznutzer nicht länger als sekundäre Amateure zeichnen, die von einem primären und ursprünglichen Verhältnis zur Welt abgeschnitten sind.
<G-vec00047-002-s037><cut.abschneiden><en> Intellectuals should no longer portray Internet users as secondary amateurs, cut off from a primary and primordial relationship with the world.
<G-vec00047-002-s038><cut.abschneiden><de> Machen Sie das Gerät vor der Verschrottung unbrauchbar, indem Sie das Netzkabel abschneiden.
<G-vec00047-002-s038><cut.abschneiden><en> Before scrapping it, make sure to cut off the mains cord so that the appliance cannot be re-used.
<G-vec00047-002-s039><cut.abschneiden><de> - Aufrecht stehend (verwelkt), die kann man einfach mit dem Schwert abschneiden (hinterlässt meistens einen Deku-Stab).
<G-vec00047-002-s039><cut.abschneiden><en> - Standing upright, these you can simply cut with the Sword (usually leaves behind a Deku Stick).
<G-vec00047-002-s040><cut.abschneiden><de> Auf den ersten Blick wirkt er etwas kalt und brutal, da er eine ziemlich ernste Person ist, vieles im Alleingang macht, brutale Methoden wählt (zB wollte er sich die Beine abschneiden, als er im Wachs drinsteckte) und unsentimentale Sprüche abgibt.
<G-vec00047-002-s040><cut.abschneiden><en> He seems to be cold and brutal at first because he is quite serious, does many things on his own, chose brutal methods (e.g. he wanted to cut off his feet to free himself from wax) and talks in an insensitive way.
<G-vec00047-002-s041><cut.abschneiden><de> Nur das harmonische Lied der Vögel wird dieses Schweigen abschneiden.
<G-vec00047-002-s041><cut.abschneiden><en> Only the harmonious song of the birds will cut off this silence.
<G-vec00047-002-s042><cut.abschneiden><de> Abschneiden aller überstehenden Teile an der Trix C-Gleis-Anschlussstelle und der Kleineisen an der ersten Schwelle.
<G-vec00047-002-s042><cut.abschneiden><en> Cut away all protruding parts on the Trix C Track connection points and the fasteners on the first tie.
<G-vec00047-002-s043><cut.abschneiden><de> Wickle es dafür um dein Handgelenk, um zu bestimmen, wie lange du die Stücke abschneiden musst.
<G-vec00047-002-s043><cut.abschneiden><en> Wrap the leather around your wrist to determine how long to cut your pieces.
<G-vec00047-002-s044><cut.abschneiden><de> Faden abschneiden und Faden vernähen.
<G-vec00047-002-s044><cut.abschneiden><en> Cut and sew the threads.
<G-vec00047-002-s045><cut.abschneiden><de> Einfach perfekt abschneiden: Mit Diamantscheiben für Trennschneider Das Diamantscheiben-Sortiment von Wacker Neuson ist speziell auf die Trennschneider-Modelle der BTS-Reihe von Wacker Neuson zugeschnitten.
<G-vec00047-002-s045><cut.abschneiden><en> Diamond Blades for Cut-Off Saws - Simply a cut above: The diamond blades for cut-off saws Wacker Neuson's diamond blade range is tailor-made for the BTS range of Wacker Neuson cut-off saws.
<G-vec00047-002-s046><cut.abschneiden><de> Aber Griechenland oder Italien oder die Länder auf der Balkanroute – ob EU oder nicht – haben keine Wahl: sie werden von Flüchtlingen überrannt, ganz egal, was sie tun, um das zu verhindern – denn solange die EU sich nicht entschließt, Stacheldraht auf Mittelmeerstränden zu verlegen oder Flüchtlingsboote mit Waffengewalt abzuwehren, kann die Wassergrenze der EU nach Süden gar nicht ‚geschützt’ werden: die EU kann sich nicht vom Mittelmeer abschneiden, das übrigens als Mare Nostrum kulturgeschichtlich das europäische Meer schlechthin ist – und von dessen Handelsrouten sich die EU keinesfalls abschneiden will.
<G-vec00047-002-s046><cut.abschneiden><en> Because as long as the EU doesn’t decide to lay barbed wire across Mediterranean beaches, or to turn back refugee boats with armed force, the sea border of the EU to the south cannot be ‘defended’: the EU cannot cut itself off from the Mediterranean – which, it is worth remembering, is in cultural historical terms, as the Mare Nostrum, the quintessential European sea – and from whose trade routes the EU most certainly does not want to cut itself off.
<G-vec00047-002-s047><cut.abschneiden><de> Dies würde dann tatsächlich den nördlichen Teil der Westbank vom südlichen Teil abschneiden, abgesehen von einem engen Flaschenhals bei Jericho.
<G-vec00047-002-s047><cut.abschneiden><en> This would in effect cut off the northern West Bank from the southern part, apart from a narrow bottleneck near Jericho.
<G-vec00047-002-s048><cut.abschneiden><de> Wenn A.1 zu Ende gehäkelt wurde, den Faden abschneiden und vernähen.
<G-vec00047-002-s048><cut.abschneiden><en> When diagram A.1 has been completed, cut and fasten the strand.
<G-vec00047-002-s049><cut.abschneiden><de> Um Rosen mit dieser Methode zu vermehren, musst du eine gesunde Rosenpflanze aussuchen und einen Stängel abschneiden.
<G-vec00047-002-s049><cut.abschneiden><en> To propagate roses using this method, you need to select a healthy rose plant and cut off a stem.
<G-vec00047-002-s050><cut.abschneiden><de> Lesen Sie den Abschnitt “Einstellung der DIP-Schalter” (auf Seite 10) hinsichtlich der Auswahl des Modus zum automatischen Einzug und Abschneiden.
<G-vec00047-002-s050><cut.abschneiden><en> For how to select the auto feed & cut mode, see "Setting of the DIP switches" (on page 11).
<G-vec00047-002-s051><cut.abschneiden><de> Das untere Drittel des Spargels schälen und die Enden abschneiden.
<G-vec00047-002-s051><cut.abschneiden><en> Peel the lower third of the asparagus and cut the ends.
<G-vec00047-002-s052><cut.abschneiden><de> Die stachligen Blätter kann man etwas abschneiden.
<G-vec00047-002-s052><cut.abschneiden><en> The prickly leaves can be cut slightly.
<G-vec00047-002-s053><cut.abschneiden><de> Machen Sie zuerst einen Schnitt an der Unterseite, bevor Sie eine Länge von oben abschneiden.
<G-vec00047-002-s053><cut.abschneiden><en> First make a cut in the underside before you cut off a length from above.
<G-vec00047-002-s054><cut.abschneiden><de> In diesem Fall müssen Sie die Stiele nicht abschneiden.
<G-vec00047-002-s054><cut.abschneiden><en> In this case, you do not need to cut the stems.
<G-vec00047-002-s055><cut.abschneiden><de> An den Enden je 1 Quaste einziehen: 12 Fäden Cotton Viscose und 8 Fäden Vivaldi à 20 cm abschneiden.
<G-vec00047-002-s055><cut.abschneiden><en> Make a tassel for each end of the string as follows: Cut 12 threads of Cotton Viscose and 8 threads Vivaldi measuring 20 cm each.
<G-vec00047-002-s056><cut.abschneiden><de> Er gibt uns direkt den Schritt, durch den wir alle unnötigen Handlungen abschneiden können.
<G-vec00047-002-s056><cut.abschneiden><en> He gives us directly the step by which we can cut off all unnecessary actions.
<G-vec00047-002-s418><cut.abschneiden><de> Schneide die Tabellen aus und verstaue eine dieser Karten in deiner Brieftasche.
<G-vec00047-002-s418><cut.abschneiden><en> Cut the cards out and put one in your wallet for the upcoming week.
<G-vec00047-002-s419><cut.abschneiden><de> Schneide, wenn du weitermachst, jede Schnur 5 cm länger ab.
<G-vec00047-002-s419><cut.abschneiden><en> As you go along, cut each string 2 inches longer.
<G-vec00047-002-s420><cut.abschneiden><de> Platziere den Schaumstoff auf dem Leinen und schneide ein passendes Rechteck zum Einschlagen zu.
<G-vec00047-002-s420><cut.abschneiden><en> Place the foam on the linen and cut a fitting rectangle.
<G-vec00047-002-s421><cut.abschneiden><de> Wasche und schneide inzwischen dein gewähltes Obst.
<G-vec00047-002-s421><cut.abschneiden><en> Meanwhile, wash and cut your chosen fruits.
<G-vec00047-002-s422><cut.abschneiden><de> Schneide den Blätterteig in Quadrate.
<G-vec00047-002-s422><cut.abschneiden><en> Cut the puff pastry into squares.
<G-vec00047-002-s423><cut.abschneiden><de> Schneide einen langen 1cm Klebebandstreifen.
<G-vec00047-002-s423><cut.abschneiden><en> Then, cut a leaf shape.
<G-vec00047-002-s424><cut.abschneiden><de> Schneide den vorgefertigten Plätzchenteig in gleichmäßige, runde Stücke.
<G-vec00047-002-s424><cut.abschneiden><en> Cut a log of pre-made cookie dough into even rounds.
<G-vec00047-002-s425><cut.abschneiden><de> 1Mo 15,9 [9/10] Da sagte der Herr: »Bring mir eine dreijährige Kuh, eine dreijährige Ziege, einen dreijährigen Schafbock, eine Turteltaube und eine junge Taube; schneide sie mittendurch, und lege die Hälften einander gegenüber.
<G-vec00047-002-s425><cut.abschneiden><en> 9 Then He said: Take for me a three-year-old cow, a three-year-old goat, a three-year-old male sheep, a dove, and a young pigeon. 10 And he took all these animals, cut them up in halves for sacrifice, laying each half opposite the other half, but he did not cut the birds in half.
<G-vec00047-002-s426><cut.abschneiden><de> Lass sie komplett auskühlen, schneide sie dann halb durch und fülle sie mit Hilfe eines Spritzbeutels mit der Crème und Marmelade.
<G-vec00047-002-s426><cut.abschneiden><en> Let cool completely, then cut in half and fill with pastry cream and fruit preserve or jam.
<G-vec00047-002-s427><cut.abschneiden><de> Schneide deinen Stoff.
<G-vec00047-002-s427><cut.abschneiden><en> Cut your pieces out.
<G-vec00047-002-s428><cut.abschneiden><de> Schneide den Schwanz ab, wenn du es nicht bereits getan hast und schneide den Kopf mit dem großen Messer ab.
<G-vec00047-002-s428><cut.abschneiden><en> 2 Poke the knife through the belly of the fish and cut towards the tail.
<G-vec00047-002-s429><cut.abschneiden><de> Schneide die freiliegenden Haare mit deiner Schere senkrecht zu deinem Kamm oder einen Fingern ab.
<G-vec00047-002-s429><cut.abschneiden><en> Cut the exposed hair, with your scissors perpendicular to the comb or your fingers.
<G-vec00047-002-s430><cut.abschneiden><de> Schneide den Faden nicht ab; du fährst damit fort, ihn zu weben.
<G-vec00047-002-s430><cut.abschneiden><en> Do not cut off the thread or yarn; you will continue weaving with it.
<G-vec00047-002-s431><cut.abschneiden><de> Falls du ein langes Lachsfilet gekauft hast, schneide es mit einem scharfen Messer vorsichtig in einzelne Filets.
<G-vec00047-002-s431><cut.abschneiden><en> If you bought a long fillet of salmon, carefully use a sharp knife to cut the salmon into individual fillets.
<G-vec00047-002-s432><cut.abschneiden><de> Schneide eine Ecke an der richtigen Stelle mit einer Schere ein, bevor du es anbringst.
<G-vec00047-002-s432><cut.abschneiden><en> Cut an end in the proper place with a scissors before laying it down.
<G-vec00047-002-s433><cut.abschneiden><de> Schneide auch ein Stück vom Stiel ab.
<G-vec00047-002-s433><cut.abschneiden><en> Cut off (a part of) the stem.
<G-vec00047-002-s434><cut.abschneiden><de> Um einen Sporenabdruck zu nehmen, nimm einen Pilz, schneide die Kappe mit einem scharfen Messer vom Stiel und leg sie mit den Lamellen nach unten auf ein Stück Papier.
<G-vec00047-002-s434><cut.abschneiden><en> To take a spore print, take a mushroom, cut the cap away from the stem using a sharp knife, and place it gills down on a piece of paper.
<G-vec00047-002-s435><cut.abschneiden><de> 1 Schneide Baumwollstoff in kleine Quadrate.
<G-vec00047-002-s435><cut.abschneiden><en> 1 Cut cotton cloth into small squares.
<G-vec00047-002-s436><cut.abschneiden><de> Schneide mit einer scharfen Schere an der Kante der Faltung entlang.
<G-vec00047-002-s436><cut.abschneiden><en> Cut along the edge of the fold with sharp scissors.
<G-vec00047-002-s456><cut.abschneiden><de> Mit einem Sägeaggregat schneidet die Maschine diagonal durch den rechteckigen Rohling und fährt beide Hälften soweit auseinander, dass die Vier- oder Fünfachsspindel die Stufen ringsherum fräsen und profilieren kann.
<G-vec00047-002-s456><cut.abschneiden><en> The machine uses a sawing unit to cut diagonally through the rectangular unprocessed part. It moves the two halves apart so that the four- or five-piece spindles can trim and profile the steps from all sides.
<G-vec00047-002-s457><cut.abschneiden><de> Peter Breuer hingegen bereitet noch den Plan für die nächsten Tage vor und schneidet mit seinem Ton-Verantwortlichen die Songs auf die richtige Länge zu.
<G-vec00047-002-s457><cut.abschneiden><en> Peter Breuer, on the other hand, now prepares the schedule for the next several days, and works with his “music guy” to cut the songs down to a suitable length.
<G-vec00047-002-s458><cut.abschneiden><de> Wiederholt das mit dem anderen Stück noch einmal genau Jetzt nehmt ihr euch eine Schere und schneidet beim ersten Stück Cardstock von oben bis zum markierten Mittelpunkt die Falzlinie ein, genau wie die lilafarbenen Linien in der Skizze es zeigen.
<G-vec00047-002-s458><cut.abschneiden><en> Zum Vergrößern bitte anklicken / click to enlarge Take your scissors and your first piece of cardstock and cut your score lines exactly like the purple lines in the sketch show from the upper line to the middle mark you just made.
<G-vec00047-002-s459><cut.abschneiden><de> Schneidet dann in einen der Deckel ein Fenster.
<G-vec00047-002-s459><cut.abschneiden><en> Then cut a window in one of the large sections.
<G-vec00047-002-s460><cut.abschneiden><de> Wenn ihr in den oberen Teil des Körpers schneidet, sobald ihr hineinseht, ist alles darin abstoßend und grässlich.
<G-vec00047-002-s460><cut.abschneiden><en> If you cut the upper portion of your body, as soon as you see inside, it is all obnoxious horrible things.
<G-vec00047-002-s461><cut.abschneiden><de> Das 2-Klingen-System dieses Elektrorasierers hebt die Haare an und schneidet sie direkt für eine sanfte Rasur an der Hautoberfläche ab.
<G-vec00047-002-s461><cut.abschneiden><en> The dual blade system of this electric shaver lifts hairs to cut comfortably below skin level. Spring-released pop-up trimmer
<G-vec00047-002-s462><cut.abschneiden><de> Wenn der Laserkopf Metalle schneidet, wird im Laserkopf und im Lasergerät etwas heiße Energie erzeugt.
<G-vec00047-002-s462><cut.abschneiden><en> When laser head cut metals, there will produce some hot energy in laser head and laser device.
<G-vec00047-002-s463><cut.abschneiden><de> Der Arzt unter örtlicher Betäubung schneidet einen Zaum oder eine spezielle Schere oder einen Laser.
<G-vec00047-002-s463><cut.abschneiden><en> The doctor under local anesthesia will cut a bridle or special scissors, or a laser.
<G-vec00047-002-s464><cut.abschneiden><de> Immer wieder findet man File Folder Karten, die mit dem Punchboard gefertigt werden...allerdings hat ja nicht jeder so ein tolles Board zur Hand...und so habe ich eine File Folder Card ohne Punchboard für euch Als erstes schneidet ihr euren Cardstock auf die passende Größe zu...anschließend legt ihr euch den Cardstock mit der langen Seite oben am ScorPal an und falzt ihn bei 10,5cm...
<G-vec00047-002-s464><cut.abschneiden><en> File folder cards can be found many made with the punchboard....but not everyone has it...so I made one without First you cut your cardstock to the given size and lay it along the short side to the ScorPal and score at 10,5 cm...
<G-vec00047-002-s465><cut.abschneiden><de> Schneidet den Limettenkeil ein und streicht damit den Glasrand eines Bierglases ein.
<G-vec00047-002-s465><cut.abschneiden><en> Cut a slit in the lime wedge and rub it around the rim of a tall beer glass.
<G-vec00047-002-s466><cut.abschneiden><de> Und auf diese Weise schneidet ihr euch selbst ab.
<G-vec00047-002-s466><cut.abschneiden><en> And so you cut yourself off.
<G-vec00047-002-s467><cut.abschneiden><de> Man schneidet die Stücke 2 cm dick, salzt und pfeffert sie und wendet sie leicht in Mehl um.
<G-vec00047-002-s467><cut.abschneiden><en> When nearly dry cut the bread into small squares and season it well with powdered sage, salt and pepper.
<G-vec00047-002-s468><cut.abschneiden><de> Man nimmt im einfachsten Fall eine Pappscheibe, die die Teleskopöffnung abdeckt, schneidet zwei runde Löcher hinein und plaziert die Scheibe vor der Teleskopöffnung.
<G-vec00047-002-s468><cut.abschneiden><en> Take a cardboard disk with the diameter of the telescope's optic, cut two (or three) holes in it and place it in front of the telescope.
<G-vec00047-002-s469><cut.abschneiden><de> Grob schneidet man nun 2 ungefähr gleich große Stücke aus einer alten Jeanshose, die ein bisschen größer sind als das gestempelte Motiv.
<G-vec00047-002-s469><cut.abschneiden><en> Roughly cut out 2 pieces from an old jeans, which are about the same size and a little larger than the stamped image.
<G-vec00047-002-s470><cut.abschneiden><de> Schneidet die Dinge der Welt ab und nehmt die Führerschaft Jesu Christi an, sonst werdet ihr so sicher wie die Welt umkommen.
<G-vec00047-002-s470><cut.abschneiden><en> Cut away the things of the world, accept the leadership of Jesus Christ, or you’ll perish as sure as the world.
<G-vec00047-002-s471><cut.abschneiden><de> Damit schneidet er aus allen möglichen Quellen Samples raus, die dann als Grundmotive für Stücke dienen.
<G-vec00047-002-s471><cut.abschneiden><en> He uses it to cut samples from every possible source, and later these serve as the main themes for pieces.
<G-vec00047-002-s472><cut.abschneiden><de> Bei der Schneidlöschtechnik wird dem Löschwasser über eine spezielle Düse unter hohem Druck (>250 bar) ein Schneidmittel (Abrasivmittel) zugesetzt, mit dessen Hilfe der Wasserstrahl durch alle bekannten Baumaterialien schneidet.
<G-vec00047-002-s472><cut.abschneiden><en> Interreg DiveSMART Baltic Method The Cutting Extinguisher technique consists of a mixture of water and cutting agent (abrasive) being ejected through a special nozzle at high pressure (>250 bar) to cut through all known building and construction materials.
<G-vec00047-002-s473><cut.abschneiden><de> Mit einer guten Küchenschere schneidet Ihr so gut wie alles: Papier, Pappe, Wellpappe, Bindfäden, Stoff, Alu- oder Plastikfolie und andere Verpackungen rund ums Kochen, aber natürlich auch Kräuter, Rosmarinzweige, Rhabarber, Blumen usw..
<G-vec00047-002-s473><cut.abschneiden><en> You can use a good pair of kitchen scissors to cut through practically anything: paper, cardboard, corrugated cardboard, string, fabric, aluminium foil or cling film and other packaging used in the kitchen, as well as of course herbs, rosemary sprigs, rhubarb, flowers etc.
<G-vec00047-002-s474><cut.abschneiden><de> Jetzt schneidet ihr den inneren Kreis der Krempe aus.
<G-vec00047-002-s474><cut.abschneiden><en> Now cut the inside of the brim.
