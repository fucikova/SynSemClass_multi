<G-vec00178-001-s038><arrange.anrichten><de> Das Eis in einem Hippenstanitzel anrichten.
<G-vec00178-001-s038><arrange.anrichten><en> Arrange the ice in an ice cream cone.
<G-vec00178-001-s039><arrange.anrichten><de> Gemüse und Hähnchen aus dem Bräter nehmen, das Fett von der Sauce abschöpfen, auf vorgeheizten Tellern anrichten.
<G-vec00178-001-s039><arrange.anrichten><en> Take the vegetables and chicken pieces out of the casserole, skim the fat from the sauce, arrange on heated plates.
<G-vec00178-001-s040><arrange.anrichten><de> Inzwischen den Salat vorsichtig mit den Linsen mischen und auf Teller anrichten.
<G-vec00178-001-s040><arrange.anrichten><en> Meanwhile mix the salad carefully with the lentils and arrange on plate.
<G-vec00178-001-s041><arrange.anrichten><de> Wenn es etwas wäre, daß Sie anrichten könnten, wurden alle Leute der Welt schon lange Arahats sein.
<G-vec00178-001-s041><arrange.anrichten><en> If it were something you could arrange, all the people in the world would have become arahants long ago.
<G-vec00178-001-s042><arrange.anrichten><de> Die Thymianbutter anrichten und mit etwas schwarzem Pfeffer dekorieren.
<G-vec00178-001-s042><arrange.anrichten><en> Arrange the thyme butter and sprinkle a little black pepper on top.
<G-vec00178-001-s043><arrange.anrichten><de> Sie sind viereckig, damit man den Kartoffelsalat und die Würstchen besonders ordentlich anrichten kann.
<G-vec00178-001-s043><arrange.anrichten><en> They are square, so you can arrange the potato salad and sausages very neat.
<G-vec00178-001-s044><arrange.anrichten><de> Das Fleisch herausnehmen und auf einem Teller anrichten.
<G-vec00178-001-s044><arrange.anrichten><en> Take the meat out and arrange on a platter.
<G-vec00178-001-s045><arrange.anrichten><de> Mit Salz und Pfeffer würzen und in einem Schälchen anrichten.
<G-vec00178-001-s045><arrange.anrichten><en> Season with salt and pepper and arrange in a bowl.
<G-vec00178-001-s046><arrange.anrichten><de> Alle Zutaten abwechselnd am Tellerrand wie einen Salat anrichten.
<G-vec00178-001-s046><arrange.anrichten><en> Arrange all the ingredients alternately around the edge of the plate like a salad.
<G-vec00178-001-s047><arrange.anrichten><de> Lachsrolle in Scheiben schneiden und auf dem Salat anrichten.
<G-vec00178-001-s047><arrange.anrichten><en> Cut salmon roll into slices and arrange on the salad.
<G-vec00178-001-s048><arrange.anrichten><de> "Auch im Bistro legt Becker Wert auf eine entspannte Wohlfühl-Atmosphäre und nutzt dazu die Stärke seiner Antriebe, wie Maik Wiegelmann erklärt: ""Im Bereich der Theke haben wir eine Schleusensteuerung integriert, die uns beim ungestörten Anrichten der Speisen unterstützt und gleichzeitig eine wichtige ästhetische Funktion erfüllt."
<G-vec00178-001-s048><arrange.anrichten><en> "Becker also places great importance on creating a relaxed and comfortable atmosphere in the bistro and utilises the strengths of its drives in the process. As explained by Maik Wiegelmann: ""We have integrated a shutter control system into the counter area that helps us to arrange the food undisturbed and at the same time fulfils an important aesthetic function."
<G-vec00178-001-s049><arrange.anrichten><de> Auf einem Teller anrichten.
<G-vec00178-001-s049><arrange.anrichten><en> Arrange on a plate.
<G-vec00178-001-s050><arrange.anrichten><de> Auf einer Servierplatte schön anrichten.
<G-vec00178-001-s050><arrange.anrichten><en> Arrange nicely on a serving platter.
<G-vec00196-002-s038><cause.anrichten><de> Überspannungen können hier immense Schäden anrichten, die durch althergebrachte Vorsorgemaßnahmen nicht verhindert werden können.
<G-vec00196-002-s038><cause.anrichten><en> Electrical surges can cause severe damages, which cannot be averted by taking traditional preventive measures.
<G-vec00196-002-s039><cause.anrichten><de> Nimm dieses gruselige Pärchen in Gewahrsam, bevor die beiden noch mehr Chaos anrichten.
<G-vec00196-002-s039><cause.anrichten><en> Capture this creepy pair before they cause any more chaos!
<G-vec00196-002-s040><cause.anrichten><de> 2011 In der Geschichte unserer Familie und unseres Hauses ist die Zerstörung die ein Brand anrichten kann noch immer allgegenwärtig.
<G-vec00196-002-s040><cause.anrichten><en> 2011 Because our whole house has been destroyed in the flames, we know that fire can cause a huge disaster.
<G-vec00196-002-s041><cause.anrichten><de> Die breite Palette an Möglichkeiten ist jedoch auch mit Bedenken verbunden, da es für die wenigsten der angebotenen Aktivitäten konkrete Richtlinien gibt und Besucherinnen und Besucher durch falsches Verhalten großen Schaden im empfindlichen Ökosystem der Antarktis anrichten können.
<G-vec00196-002-s041><cause.anrichten><en> The broad range of opportunities is of some concern, however, since few concrete guidelines exist for any of these activities, and improper behaviour by visitors could cause great harm to the sensitive ecosystem in the Antarctic.
<G-vec00196-002-s042><cause.anrichten><de> Zwar ist die TILO nicht offiziell als Vorsatzgerät entworfen worden, da sie jedoch die Militärnorm IP68 erfüllt und Stöße bis 800G aushalten kann, wird der Rückstoß einer Standardjagdwaffe keinerlei Schaden anrichten.
<G-vec00196-002-s042><cause.anrichten><en> Although the TILO has not been officially designed as an attachment, since it meets the military standard IP68 and can withstand shocks up to 800G, the recoil of a standard hunting weapon will not cause any damage.
<G-vec00196-002-s043><cause.anrichten><de> Es handelt sich dabei nicht um Programme, die in das System des Benutzers eindringen und dort Schaden anrichten können.
<G-vec00196-002-s043><cause.anrichten><en> They are not software programs that could penetrate into the operating system of the user and cause damage here.
<G-vec00196-002-s044><cause.anrichten><de> Cookies können keine Schäden auf den verwendeten Geräten anrichten.
<G-vec00196-002-s044><cause.anrichten><en> Cookies cannot cause any damage to the devices used.
<G-vec00196-002-s045><cause.anrichten><de> Auch kurze Blackouts können gravierende wirtschaftliche Schäden anrichten.
<G-vec00196-002-s045><cause.anrichten><en> Even short blackouts may cause serious financial losses.
<G-vec00196-002-s046><cause.anrichten><de> Der General ist sich sicher, dass sie ein unglaubliches Chaos hinter ihren Linien anrichten wird.
<G-vec00196-002-s046><cause.anrichten><en> "Imagine... the chaos we'll cause, once we're in behind their lines!"
<G-vec00196-002-s047><cause.anrichten><de> Sie können für den Schaden stehen, den Kränkungen anrichten, oder für etwas, das kaputt ist, für Verletzungen.
<G-vec00196-002-s047><cause.anrichten><en> They could stand for the damage hurtful remarks cause, for something which is broken (possibly beyond repair), or for injury.
<G-vec00196-002-s048><cause.anrichten><de> Manche Substanzen können nach ihrer Einnahme sehr viel Schaden anrichten, wenn sie erbrochen werden.
<G-vec00196-002-s048><cause.anrichten><en> Some substances, after being ingested, can cause a lot of damage if vomited back up.
<G-vec00196-002-s049><cause.anrichten><de> Dass ein Mann so viel Schaden anrichten kann ist erstaunlich, aber leider wahr.
<G-vec00196-002-s049><cause.anrichten><en> That one man could cause so much damage is astounding, but tragically true.
<G-vec00196-002-s050><cause.anrichten><de> Doch Ich wußte auch seit Ewigkeiten um die Gegnerschaft Meines ersten aus Mir herausgestellten Geistes, Ich wußte um seinen Widerstand und um die Verwirrung, die er anrichten würde unter Meinen Urgeistern....
<G-vec00196-002-s050><cause.anrichten><en> But I have also known about My first externalized spirit’s antagonism for an eternity, I’ve known about his opposition and the confusion he would cause amongst My earliest spirits....
<G-vec00196-002-s051><cause.anrichten><de> Alles Bereiche, wo der Kakerlakenschlappen eher Schaden anrichten würde.
<G-vec00196-002-s051><cause.anrichten><en> All areas where the cockroach slipper would cause more damage than results.
<G-vec00196-002-s052><cause.anrichten><de> Bevor das Wasser Schaden anrichten kann, ertönt ein Warnton.
<G-vec00196-002-s052><cause.anrichten><en> Before the water can cause any damage, a warning is sounded.
<G-vec00196-002-s053><cause.anrichten><de> 17 Ich ermahne euch aber, liebe Brüder, daß ihr achtet auf die, die da Zertrennung und Ärgernis anrichten neben der Lehre, die ihr gelernt habt, und weichet von ihnen.
<G-vec00196-002-s053><cause.anrichten><en> 17 I urge you, brothers and sisters, to watch out for those who cause divisions and put obstacles in your way that are contrary to the teaching you have learned.
<G-vec00196-002-s054><cause.anrichten><de> So lassen sich auch kleinere Fehler und Verschleiß an der Spannschraube rechtzeitig erkennen, bevor sie Schaden anrichten können.
<G-vec00196-002-s054><cause.anrichten><en> That way, minor flaws and any wear to the screw can be repaired before they can cause damage.
<G-vec00196-002-s055><cause.anrichten><de> Die durchdachte Bauweise der Anlasser mit ausgeprägten Luftdurchgängen gewährleistet, dass Fremdkörper kaum Schäden anrichten können.
<G-vec00196-002-s055><cause.anrichten><en> The starters' ingenious design with extensive air passages ensures that foreign bodies are hardly able to cause any damage.
<G-vec00196-002-s056><cause.anrichten><de> Seine Politik folgt einer Logik der Eskalation, sie ist impulsiv und setzt sich über Belege und Fakten hinweg, und sie ist sich des bleibenden Schadens, den sie anrichten könnte, nicht bewusst.
<G-vec00196-002-s056><cause.anrichten><en> His policy follows a logic of escalation, it is impulsive and defies evidence and facts, and it is ignorant of the lasting damage it may cause.
<G-vec00196-002-s020><inflict.anrichten><de> Schon ein infizierter Speicherstick kann auf einem Computer ernsthaften Schaden anrichten.
<G-vec00196-002-s020><inflict.anrichten><en> Just one infected flash drive can inflict serious damage to a computer and its owner.
<G-vec00196-002-s021><inflict.anrichten><de> Eine kleine Gruppe von Personen wäre dann in der Lage, Schäden in einer Größenordnung anzurichten, die bislang nur für Staaten oder Armeen vorstellbar war.
<G-vec00196-002-s021><inflict.anrichten><en> In this event, a small group would be able to inflict damage on a scale previously possible only for States and armies.
<G-vec00196-002-s022><inflict.anrichten><de> Anwendungen sind im Internet permanent Angreifern ausgesetzt, die Mittel und Wege finden, um Schaden anzurichten.
<G-vec00196-002-s022><inflict.anrichten><en> Applications are permanently exposed to attacks on the Internet. Attackers do not rest to contrive means and ways to inflict damage.
<G-vec00196-002-s023><inflict.anrichten><de> Dieses Gruppenentferner-Spiel stellt dich vor die Herausforderung, maximales Chaos anzurichten.
<G-vec00196-002-s023><inflict.anrichten><en> This group remover game will challenge you to inflict maximum chaos.
<G-vec00196-002-s041><inflict.anrichten><de> Dies wird den Feind schwächen, indem man ihm das Zeichen des Lichts überlässt, falls er töricht genug ist, den Mystiker zu beharren, kann er durch das Zeichen des Lichts noch größeren Schaden anrichten.
<G-vec00196-002-s041><inflict.anrichten><en> This will weaken the enemy by leaving Mark of Light on them, should they be foolish enough to persist the Mystic can then inflict even greater damage due to the Mark of Light.
<G-vec00196-002-s019><wreak.anrichten><de> Im Gegensatz zu vielen anderen kommerziellen Firewalls ist die lüfter- und schlitzlose sowie staubresistente FW400 geschützt vor Staub und durch die Luft übertragene Ablagerungen, die verheerenden Schaden an den elektrischen Komponenten anrichten können.
<G-vec00196-002-s019><wreak.anrichten><en> Unlike many other commercial firewalls, the fanless, ventless, and dust-resistant FW400 is protected from the dust and airborne debris that can wreak havoc with electrical components.
<G-vec00196-002-s020><wreak.anrichten><de> Mit seinen neuen Kräften kann Jackie verheerenden Schaden unter seinen Feinden anrichten.
<G-vec00196-002-s020><wreak.anrichten><en> With his new powers, Jackie is able to wreak terrifying havoc on his enemies.
<G-vec00196-002-s021><wreak.anrichten><de> Korrosive Materialien, Schmutz, Vibrationen, Hitze und Feuchtigkeit können bei konventionellen Leuchten und minderwertigen LED-Leuchten verheerende Schäden anrichten.
<G-vec00196-002-s021><wreak.anrichten><en> Corrosive materials, dirt, vibration, heat and moisture can wreak havoc on conventional fixtures and low-quality LED lights.
<G-vec00196-002-s022><wreak.anrichten><de> Wie Sie Zerstörung anrichten, liegt an Ihnen: steuern Sie mächtige Bombers, Sturm-Mechs, Panzer, Boote und Kampfhubschrauber, um Herr über das Schlachtfeld zu werden.
<G-vec00196-002-s022><wreak.anrichten><en> How you wreak destruction is up to you: control power bombers, assault mechs, tanks, boats, and attack helicopters to fully control the battlefield.
<G-vec00196-002-s023><wreak.anrichten><de> Es ist entscheidend, die Zusammenhänge zwischen Lizenzvereinbarungen und installierter Software zu verstehen und Wissen über nicht autorisierte Programme wie Spiele oder Peer-to-Peer-Programme zu haben, die im gesamten Netzwerk verheerenden Schaden anrichten können.
<G-vec00196-002-s023><wreak.anrichten><en> Understanding the correlation between license agreements and installed software is critical, as is the knowledge of unauthorized programs, including games and peer-to-peer programs, which can wreak havoc across an entire network.
<G-vec00196-002-s024><wreak.anrichten><de> Durch diese schnelle Warnung der Sicherheitsbranche konnte keiner der zahlreichen Klone des Wurms den gleichen Schaden anrichten wie der ursprüngliche LoveLetter-Wurm.
<G-vec00196-002-s024><wreak.anrichten><en> As a result of the industry’s timely advice, none of the worm’s numerous clones were able to wreak the same sort of havoc as that caused by the original LoveLetter worm.
<G-vec00196-002-s025><wreak.anrichten><de> Die 'Blumenbombe' bleibt eine mächtige Kraft, die im LFC Chaos anrichten wird, und sie hat die Absicht, ihren Titel so schnell wie möglich zurückzubekommen.
<G-vec00196-002-s025><wreak.anrichten><en> The ‘Flowerbomb’ remains a powerful force who will wreak havoc in the LFC, and she has every intention of getting her title back as soon as humanly possible.
<G-vec00196-002-s026><wreak.anrichten><de> Kaltes Wetter, intensive Strahlen und starker Wind können alle auf den Lippen Verwüstung anrichten.
<G-vec00196-002-s026><wreak.anrichten><en> Cold weather, intense rays, and harsh wind can all wreak havoc on your lips.
<G-vec00196-002-s027><wreak.anrichten><de> Wo niemand von dem spektakulären Technicolor-Process-No-2-Chaos, das wir auf der Leinwand anrichten, verletzt werden wird, weil wir wissen, dass alles mit dem Abspann wieder verschwinden wird.
<G-vec00196-002-s027><wreak.anrichten><en> Where no one will be hurt by the spectacular Two-Strip Technicolor havoc we’ll wreak on the screen, knowing the whole thing will drain away by credit roll.
<G-vec00196-002-s028><wreak.anrichten><de> Wasser in einem Druckluftsystem kann verheerende Schäden im Produktionsprozess anrichten und zu steigenden Wartungskosten und Ausfallzeiten sowie Qualitätsproblemen führen.
<G-vec00196-002-s028><wreak.anrichten><en> Water in a compressed air systems can wreak havoc on a production process increasing maintenance costs and downtime as well as quality problems. Corrosion Prevention
<G-vec00196-002-s029><wreak.anrichten><de> Die Insel, auf der wir in diesem dritten Teil der Just Cause bewegen, ist mehr als 1000 km2 Land, See und Luft, die wir frei erkunden können, plus ein riesiges Arsenal an Waffen, Artefakten und Fahrzeuge; all dies, um Chaos unter den Armeen von General der am meisten Spaß erdenkliche Weise anrichten.
<G-vec00196-002-s029><wreak.anrichten><en> The island where we will move in this third installment of Just Cause, is more than 1000 km2 of land, sea and air that we can freely explore, plus a huge arsenal of weapons, artifacts and vehicles; all this to wreak havoc among the armies of General of the most fun way imaginable.
<G-vec00196-002-s030><wreak.anrichten><de> Erkennen und blockieren Sie Malware, bevor sie Schaden in Ihrem Netzwerk anrichten kann.
<G-vec00196-002-s030><wreak.anrichten><en> Detect and block malware before it has a chance to wreak havoc on your network.
<G-vec00196-002-s052><wreak.anrichten><de> Stress kann viel Unheil mit Haut, Körper und Geist anrichten und die Hormone, die aufgrund von Stress ausgeschüttet werden, können Dinge wie Akne, Psoriasis, Rosazea und Ekzeme fördern.
<G-vec00196-002-s052><wreak.anrichten><en> Stress can wreak havoc on your skin and body as well as your mind, and the hormones your body releases in response to stress can exacerbate things like acne, psoriasis, rosacea, and eczema.
