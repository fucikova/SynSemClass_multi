<G-vec00178-001-s038><arrange.anrichten><de> Das Eis in einem Hippenstanitzel anrichten.
<G-vec00178-001-s038><arrange.anrichten><en> Arrange the ice in an ice cream cone.
<G-vec00178-001-s039><arrange.anrichten><de> Gemüse und Hähnchen aus dem Bräter nehmen, das Fett von der Sauce abschöpfen, auf vorgeheizten Tellern anrichten.
<G-vec00178-001-s039><arrange.anrichten><en> Take the vegetables and chicken pieces out of the casserole, skim the fat from the sauce, arrange on heated plates.
<G-vec00178-001-s040><arrange.anrichten><de> Inzwischen den Salat vorsichtig mit den Linsen mischen und auf Teller anrichten.
<G-vec00178-001-s040><arrange.anrichten><en> Meanwhile mix the salad carefully with the lentils and arrange on plate.
<G-vec00178-001-s041><arrange.anrichten><de> Wenn es etwas wäre, daß Sie anrichten könnten, wurden alle Leute der Welt schon lange Arahats sein.
<G-vec00178-001-s041><arrange.anrichten><en> If it were something you could arrange, all the people in the world would have become arahants long ago.
<G-vec00178-001-s042><arrange.anrichten><de> Die Thymianbutter anrichten und mit etwas schwarzem Pfeffer dekorieren.
<G-vec00178-001-s042><arrange.anrichten><en> Arrange the thyme butter and sprinkle a little black pepper on top.
<G-vec00178-001-s043><arrange.anrichten><de> Sie sind viereckig, damit man den Kartoffelsalat und die Würstchen besonders ordentlich anrichten kann.
<G-vec00178-001-s043><arrange.anrichten><en> They are square, so you can arrange the potato salad and sausages very neat.
<G-vec00178-001-s044><arrange.anrichten><de> Das Fleisch herausnehmen und auf einem Teller anrichten.
<G-vec00178-001-s044><arrange.anrichten><en> Take the meat out and arrange on a platter.
<G-vec00178-001-s045><arrange.anrichten><de> Mit Salz und Pfeffer würzen und in einem Schälchen anrichten.
<G-vec00178-001-s045><arrange.anrichten><en> Season with salt and pepper and arrange in a bowl.
<G-vec00178-001-s046><arrange.anrichten><de> Alle Zutaten abwechselnd am Tellerrand wie einen Salat anrichten.
<G-vec00178-001-s046><arrange.anrichten><en> Arrange all the ingredients alternately around the edge of the plate like a salad.
<G-vec00178-001-s047><arrange.anrichten><de> Lachsrolle in Scheiben schneiden und auf dem Salat anrichten.
<G-vec00178-001-s047><arrange.anrichten><en> Cut salmon roll into slices and arrange on the salad.
<G-vec00178-001-s048><arrange.anrichten><de> "Auch im Bistro legt Becker Wert auf eine entspannte Wohlfühl-Atmosphäre und nutzt dazu die Stärke seiner Antriebe, wie Maik Wiegelmann erklärt: ""Im Bereich der Theke haben wir eine Schleusensteuerung integriert, die uns beim ungestörten Anrichten der Speisen unterstützt und gleichzeitig eine wichtige ästhetische Funktion erfüllt."
<G-vec00178-001-s048><arrange.anrichten><en> "Becker also places great importance on creating a relaxed and comfortable atmosphere in the bistro and utilises the strengths of its drives in the process. As explained by Maik Wiegelmann: ""We have integrated a shutter control system into the counter area that helps us to arrange the food undisturbed and at the same time fulfils an important aesthetic function."
<G-vec00178-001-s049><arrange.anrichten><de> Auf einem Teller anrichten.
<G-vec00178-001-s049><arrange.anrichten><en> Arrange on a plate.
<G-vec00178-001-s050><arrange.anrichten><de> Auf einer Servierplatte schön anrichten.
<G-vec00178-001-s050><arrange.anrichten><en> Arrange nicely on a serving platter.
