<G-vec00367-002-s017><restrain.ausschleißen><de> Der Auktionsleiter kann die Auktionskäufer, die verbotenes Verhalten zeigen, aus der Auktion ausschließen.
<G-vec00367-002-s017><restrain.ausschleißen><en> The auctioneer may restrain the Auction Buyers from the auction who behave in a prohibited way.
