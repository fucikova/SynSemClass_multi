<G-vec00057-001-s038><turn.abbiegen><de> Nach 2.5 Km rechts abbiegen, Richtung Nizza Monferrato (19.5 Km).
<G-vec00057-001-s038><turn.abbiegen><en> After 2.5 Km, turn right in the direction of Nizza Monferrato (Km. 19.5).
<G-vec00057-001-s039><turn.abbiegen><de> Abbiegen Richtung Ockelbo Straße 303. dann Richtung Zentrum und dann an der Kirche vorbei und biegen Sie die erste Straße rechts auf Åmotvägen gegen Rönnåsen.
<G-vec00057-001-s039><turn.abbiegen><en> Turn towards Ockelbo road 303rd Drive then towards the center and then past the church and turn first right on Åmotvägen against Rönnåsen.
<G-vec00057-001-s040><turn.abbiegen><de> Bei die Kreuzung-Straße zu erreichen; rechts abbiegen.
<G-vec00057-001-s040><turn.abbiegen><en> When reaching the crossing road; turn right.
<G-vec00057-001-s041><turn.abbiegen><de> "Am ""Doppel M"" rechts abbiegen in die Alte Messe und 400 m geradeaus bis zum Pantheon."
<G-vec00057-001-s041><turn.abbiegen><en> "Turn right at the ""double M""-sign and go straight for 400 m till you reach the Pantheon."
<G-vec00057-001-s042><turn.abbiegen><de> Im Jahr 1916 bauten wir rechts abbiegen.
<G-vec00057-001-s042><turn.abbiegen><en> In 1916, we built the right turn.
<G-vec00057-001-s043><turn.abbiegen><de> An der Kirche rechts abbiegen und Via Lamarmora nehmen.
<G-vec00057-001-s043><turn.abbiegen><en> At the church turn right and take Via Lamarmora.
<G-vec00057-001-s044><turn.abbiegen><de> Am Ende des König-George Street rechts abbiegen in die Randall Street und weiter einen Block bis zur ersten Ampel, die die Schnittmenge von Randall und Prince George Street ist.
<G-vec00057-001-s044><turn.abbiegen><en> At the end of King George Street make a right turn onto Randall Street and continue one block to the first traffic light, which is the intersection of Randall Street and Prince George Street.
<G-vec00057-001-s045><turn.abbiegen><de> Von Livigno nehmen wir den Passo del Foscagno und gelangen so nach Bormio, wo wir Richtung Umbrailpass/Stilfserjoch abbiegen.
<G-vec00057-001-s045><turn.abbiegen><en> From Livigno we take the Passo del Foscagno and come to Bormio, where we will turn to Umbrailpass/Stilfserjoch.
<G-vec00057-001-s046><turn.abbiegen><de> Gleich danach nach links abbiegen und der Straße folgen.
<G-vec00057-001-s046><turn.abbiegen><en> Turn left shortly afterwards and follow the road.
<G-vec00057-001-s047><turn.abbiegen><de> An den Häusern, rechts abbiegen und dann, höher, weiter in Richtung Les Grangeols.
<G-vec00057-001-s047><turn.abbiegen><en> At the houses, turn right and then, higher up, continue towards Les Grangeols.
<G-vec00057-001-s048><turn.abbiegen><de> (4 km) bis ins Stadtgebiet - 300m nach der Shell-Tankstelle an der großen Ampelkreuzung rechts abbiegen (Ausschilderung Hotelroute), nach 700 m rechts abbiegen und der Ausschilderung Parkhotel folgen.
<G-vec00057-001-s048><turn.abbiegen><en> (4 km) into the town - Turn right 300 m after the Shell gas station at the major traffic light intersection (Hotel route sign), after 700 m turn right and follow signs for the Parkhotel.
<G-vec00057-001-s049><turn.abbiegen><de> An der dritten Ampel rechts abbiegen Richtung Furtwangen/Kurgebiet/Polizei.
<G-vec00057-001-s049><turn.abbiegen><en> At the third traffic lights, turn right towards Furtwangen/Kurgebiet/Polizei.
<G-vec00057-001-s050><turn.abbiegen><de> Richtung Novigrad - Tar: An der Kreuzung bei der Tankstelle rechts zu Lanterna abbiegen.
<G-vec00057-001-s050><turn.abbiegen><en> Novigrad - Tar direction: Turn right at the intersection towards Lanterna at the petrol station.
<G-vec00057-001-s051><turn.abbiegen><de> Sie erreichen eine Kreuzung, an der Sie Rechts auf eine Asphaltstraße abbiegen, die Sie zum Restaurant führt.
<G-vec00057-001-s051><turn.abbiegen><en> You will reach a crossroads where you will turn right onto an asphalt road that will take you to a restaurant.
<G-vec00057-001-s052><turn.abbiegen><de> Wenn Sie links abbiegen, kommen Sie zur Anlegestelle der Spree – gut geeignet für eine Kaffeepause.
<G-vec00057-001-s052><turn.abbiegen><en> If you turn left, you will come to the pier on the Spree, a fine spot for a coffee break.
<G-vec00057-001-s053><turn.abbiegen><de> Vor der Brücke der Mühle, am Kreisverkehr links abbiegen.
<G-vec00057-001-s053><turn.abbiegen><en> Before the paper mill bridge, at the roundabout turn left.
<G-vec00057-001-s054><turn.abbiegen><de> Der Weg führt uns zum Dorf Koti, wo wir rechts abbiegen und bis nach Grčevje und weiter auf der Straße vorbei an der Fischzucht und der Grotte Beceletova jama (Denkmal des Volksbefreiungskampfes NOB) nach Stari grad gelangen.
<G-vec00057-001-s054><turn.abbiegen><en> We cross the stream over the footbridge and afterwards turn left and continue our path towards the Lešnica stream. The trail leads us to the village of Koti, where we turn right and go to Grčevja.
<G-vec00057-001-s055><turn.abbiegen><de> Anfahrt ParkgarageÂ - Wenn Sie sich auf der Hodzovo namestie neben dem Crowne Plaza befinden biegen Sie nach rechts ab auf die Straße Postova – dann die erste links abbiegen in die Vysoka – nach ein paar Metern können Sie unsere Garageneinfahrt sehen und in dieser parken.
<G-vec00057-001-s055><turn.abbiegen><en> Directions Parking garage Hotel Bratislava Â - If you are on the Hodzovo namestie next to the Crowne Plaza turn right onto Postova Street – then the first left into Vysoka – after a few meters you will be able to turn right into our garage.
<G-vec00057-001-s056><turn.abbiegen><de> B7 in Bahnhofstraße abbiegen und dieser folgen- Am Schild Bahngelände, Anlieger fre` vorbeifahren dann noch ca 250m bis zum Alten Bahnhof.
<G-vec00057-001-s056><turn.abbiegen><en> B7 turn into Bahnhofstrasse and the following sign on railway land, riparian fre` pass still 250m to the old railway station.
<G-vec00245-003-s133><turn_up.abbiegen><de> Oben angekommen, biegen Sie bitte rechts ab und gehen 400 Meter geradeaus die Mainzer Landstraße entlang bis zum FBC-Hochhaus, das sich auf der rechten Seite befindet.
<G-vec00245-003-s133><turn_up.abbiegen><en> After arriving upstairs please turn right and walk along the Mainzer Landstraße, after only 400 meters you will find the FBC-Skyscraper on the right side.
<G-vec00245-003-s134><turn_up.abbiegen><de> Anfahrtsbeschreibung Mit dem Auto: Vom Flughafen, Boulevard Mohamed Bouazizi, nehmen Sie die RN8 in Richtung Tunis, biegen rechts in die Avenue Cyrus Legrand ab, nehmen die zweite Ausfahrt rechts zur Rue de Syrie, biegen rechts in die Rue de l'Inde ab und fahren weiter bis zur Avenue Mohamed V. Bahnlinie 2: Bahnhof Nelson Mandela (0,20 km).
<G-vec00245-003-s134><turn_up.abbiegen><en> Directions By car: From the airport, Boulevard Mohamed Bouazizi, take RN8 toward Tunis, turn right toward Avenue Cyrus Legrand, take the second right toward Rue de Syrie, turn right onto Rue de l'Inde and continue until you reach Avenue Mohamed V. Tunis-Carthage Airport (4.3 miles [7 km]), outdoor parking (paying)
<G-vec00245-003-s136><turn_up.abbiegen><de> Beim Passieren unter dem Dolder biegen Sie rechts ab und Sie sind in der RUE DES REMPARTS, das etwa 100 Meter ist unser Zuhause" Le Coeur des Remparts" auf der rechten Seite an der Hausnummer 26.
<G-vec00245-003-s136><turn_up.abbiegen><en> As soon as you pass under the Dolder you turn right and you are in the RUE DES REMPARTS where is located about 100 meters or house " Le Coeur des Remparts" on your right at number 26.
<G-vec00245-003-s137><turn_up.abbiegen><de> Sie biegen ab nach Ponte a Poppi, dann fahren Sie hoch in das alte Dorf Poppi.
<G-vec00245-003-s137><turn_up.abbiegen><en> There you turn left at the main intersection and go up to the old town of Poppi.
<G-vec00245-003-s138><turn_up.abbiegen><de> Fahren Sie auf der Greens Road geradeaus und biegen Sie nach links zum BEST WESTERN PREMIER Ashton Suites ab.
<G-vec00245-003-s138><turn_up.abbiegen><en> Go straight on Greens Road and make a left turn into the BEST WESTERN PREMIER Ashton Suites.
<G-vec00245-003-s139><turn_up.abbiegen><de> Biegen Sie rechts ab und nach 2 km erreichen Sie Volastra.
<G-vec00245-003-s139><turn_up.abbiegen><en> There you should turn right and after two Km. you will reach Volastra.
<G-vec00245-003-s140><turn_up.abbiegen><de> Während Sie dem Weg weiter folgen, biegen Sie nach rechts ab, bis Sie zur Cisterna-Bucht ankommen, wobei wir Ihnen empfehlen, hier einen Parkplatz zu finden.
<G-vec00245-003-s140><turn_up.abbiegen><en> Following tha path, you have to turn right until you reach Cisterna Bay, where we suggest that you find a parking place.
<G-vec00245-003-s141><turn_up.abbiegen><de> Biegen Sie an der Heard Street links ab (91 Meter).
<G-vec00245-003-s141><turn_up.abbiegen><en> Please turn left at the Heard Street 91 meters.
<G-vec00245-003-s142><turn_up.abbiegen><de> Um Mühlbach, Meransen und Vals zu erreichen, biegen Sie vor dem Tunnel rechts ab.
<G-vec00245-003-s142><turn_up.abbiegen><en> To reach Mühlbach, Meransen and Vals, you turn right before the tunnel.
<G-vec00245-003-s143><turn_up.abbiegen><de> Fahren Sie weiter geradeaus, und biegen Sie links ab an der dritten Kreuzung nach der Verkehrsampel auf die White Avenue.
<G-vec00245-003-s143><turn_up.abbiegen><en> Continue to drive straight and make a left turn at the third junction after the traffic light onto White Avenue.
<G-vec00245-003-s144><turn_up.abbiegen><de> Halten Sie sich danach erst Richtung Lüben, dann auf der Straße Richtung Waldhof und biegen schließlich nach einem Einzelgehöft ("Waldhof") in den Wald ab.
<G-vec00245-003-s144><turn_up.abbiegen><en> Then head toward Lüben. Then take the road to Waldhof and turn into the forest right after you pass a farm called Waldhof.
<G-vec00245-003-s145><turn_up.abbiegen><de> Aus Richtung Süden, Ausfahrt Firenze Sud und folgen den Schildern nach Liberty Square, Fortezza da Basso, das Ende der Viale Lavagnini Sie ziehen vorbei und biegen rund um den Park-Festung und weiter geradeaus unter der Eisenbahnbrücke hindurch, vorbei an der Brücke und nach der zweiten Ampel halten Sie die linke, in die Via Guido Monaco geben, an deren Ende biegen Sie rechts ab und Sie kommen nach 50 Metern.
<G-vec00245-003-s145><turn_up.abbiegen><en> Direction from South, exit Firenze Sud and follow signs to Liberty Square, Fortezza da Basso, the end of Viale Lavagnini you pull over and turn around the park's Fortress and continue straight under the railway bridge, past the bridge and after the second traffic light, keep the left, enter in Via Guido Monaco, at the end of which you turn right and you
<G-vec00245-003-s146><turn_up.abbiegen><de> Von den Taxiständen kommend, gehen Sie an den gelben DHL-Postfächern vorbei und biegen links in den Mittelgang mit den Schließfächern ab.
<G-vec00245-003-s146><turn_up.abbiegen><en> Coming from the main entrance please enter the central station and turn left before the escalator you will find us in front if the luggage lockers.
<G-vec00245-003-s147><turn_up.abbiegen><de> Unmittelbar nach der Kirche biegen Sie links ab und fahren die Straße hoch bis zum Haus Christine (befindet sich auf der linken Seite).
<G-vec00245-003-s147><turn_up.abbiegen><en> Right after the church, make a left turn and continue driving until you see Hause Christine (on the left hand side).
<G-vec00245-003-s148><turn_up.abbiegen><de> Im Ausgang der Ortschaft biegen wir links in den Wald ab und folgen dem neu angelegten Mullerthal Trail (Zeichenwechsel).
<G-vec00245-003-s148><turn_up.abbiegen><en> At the end of the village we turn left to enter the forest and follow the new Mullerthal Trail (sign change).
<G-vec00245-003-s149><turn_up.abbiegen><de> In Poysdorf angekommen fahren Sie die B7 weiter Richtung Drasenhofen und biegen am Ortsende links ab.
<G-vec00245-003-s149><turn_up.abbiegen><en> Drive through Poysdorf on the B7 direction to Drasenhofen and turn left at the end of the town.
<G-vec00245-003-s150><turn_up.abbiegen><de> Dort biegen Sie rechts ab und folgen dem Fahrweg bis zum Bauernhof Greidern und weiter in Richtung Seestüberl bis Sie wieder zurück zum Ausgangspunkt am Ostufer ankommen.
<G-vec00245-003-s150><turn_up.abbiegen><en> Here you turn right and follow the road to the farm Greidern and continue towards Seestüberl until you arrive the starting point again.
<G-vec00245-003-s151><turn_up.abbiegen><de> In Bad Ischl Nord biegen wir Richtung Ebensee / Gmunden ab.
<G-vec00245-003-s151><turn_up.abbiegen><en> In Bad Ischl, we turn north towards Ebensee / Gmunden.
<G-vec00309-003-s133><turn_out.abbiegen><de> Oben angekommen, biegen Sie bitte rechts ab und gehen 400 Meter geradeaus die Mainzer Landstraße entlang bis zum FBC-Hochhaus, das sich auf der rechten Seite befindet.
<G-vec00309-003-s133><turn_out.abbiegen><en> After arriving upstairs please turn right and walk along the Mainzer Landstraße, after only 400 meters you will find the FBC-Skyscraper on the right side.
<G-vec00309-003-s134><turn_out.abbiegen><de> Anfahrtsbeschreibung Mit dem Auto: Vom Flughafen, Boulevard Mohamed Bouazizi, nehmen Sie die RN8 in Richtung Tunis, biegen rechts in die Avenue Cyrus Legrand ab, nehmen die zweite Ausfahrt rechts zur Rue de Syrie, biegen rechts in die Rue de l'Inde ab und fahren weiter bis zur Avenue Mohamed V. Bahnlinie 2: Bahnhof Nelson Mandela (0,20 km).
<G-vec00309-003-s134><turn_out.abbiegen><en> Directions By car: From the airport, Boulevard Mohamed Bouazizi, take RN8 toward Tunis, turn right toward Avenue Cyrus Legrand, take the second right toward Rue de Syrie, turn right onto Rue de l'Inde and continue until you reach Avenue Mohamed V. Tunis-Carthage Airport (4.3 miles [7 km]), outdoor parking (paying)
<G-vec00309-003-s136><turn_out.abbiegen><de> Beim Passieren unter dem Dolder biegen Sie rechts ab und Sie sind in der RUE DES REMPARTS, das etwa 100 Meter ist unser Zuhause" Le Coeur des Remparts" auf der rechten Seite an der Hausnummer 26.
<G-vec00309-003-s136><turn_out.abbiegen><en> As soon as you pass under the Dolder you turn right and you are in the RUE DES REMPARTS where is located about 100 meters or house " Le Coeur des Remparts" on your right at number 26.
<G-vec00309-003-s137><turn_out.abbiegen><de> Sie biegen ab nach Ponte a Poppi, dann fahren Sie hoch in das alte Dorf Poppi.
<G-vec00309-003-s137><turn_out.abbiegen><en> There you turn left at the main intersection and go up to the old town of Poppi.
<G-vec00309-003-s138><turn_out.abbiegen><de> Fahren Sie auf der Greens Road geradeaus und biegen Sie nach links zum BEST WESTERN PREMIER Ashton Suites ab.
<G-vec00309-003-s138><turn_out.abbiegen><en> Go straight on Greens Road and make a left turn into the BEST WESTERN PREMIER Ashton Suites.
<G-vec00309-003-s139><turn_out.abbiegen><de> Biegen Sie rechts ab und nach 2 km erreichen Sie Volastra.
<G-vec00309-003-s139><turn_out.abbiegen><en> There you should turn right and after two Km. you will reach Volastra.
<G-vec00309-003-s140><turn_out.abbiegen><de> Während Sie dem Weg weiter folgen, biegen Sie nach rechts ab, bis Sie zur Cisterna-Bucht ankommen, wobei wir Ihnen empfehlen, hier einen Parkplatz zu finden.
<G-vec00309-003-s140><turn_out.abbiegen><en> Following tha path, you have to turn right until you reach Cisterna Bay, where we suggest that you find a parking place.
<G-vec00309-003-s141><turn_out.abbiegen><de> Biegen Sie an der Heard Street links ab (91 Meter).
<G-vec00309-003-s141><turn_out.abbiegen><en> Please turn left at the Heard Street 91 meters.
<G-vec00309-003-s142><turn_out.abbiegen><de> Um Mühlbach, Meransen und Vals zu erreichen, biegen Sie vor dem Tunnel rechts ab.
<G-vec00309-003-s142><turn_out.abbiegen><en> To reach Mühlbach, Meransen and Vals, you turn right before the tunnel.
<G-vec00309-003-s143><turn_out.abbiegen><de> Fahren Sie weiter geradeaus, und biegen Sie links ab an der dritten Kreuzung nach der Verkehrsampel auf die White Avenue.
<G-vec00309-003-s143><turn_out.abbiegen><en> Continue to drive straight and make a left turn at the third junction after the traffic light onto White Avenue.
<G-vec00309-003-s144><turn_out.abbiegen><de> Halten Sie sich danach erst Richtung Lüben, dann auf der Straße Richtung Waldhof und biegen schließlich nach einem Einzelgehöft ("Waldhof") in den Wald ab.
<G-vec00309-003-s144><turn_out.abbiegen><en> Then head toward Lüben. Then take the road to Waldhof and turn into the forest right after you pass a farm called Waldhof.
<G-vec00309-003-s145><turn_out.abbiegen><de> Aus Richtung Süden, Ausfahrt Firenze Sud und folgen den Schildern nach Liberty Square, Fortezza da Basso, das Ende der Viale Lavagnini Sie ziehen vorbei und biegen rund um den Park-Festung und weiter geradeaus unter der Eisenbahnbrücke hindurch, vorbei an der Brücke und nach der zweiten Ampel halten Sie die linke, in die Via Guido Monaco geben, an deren Ende biegen Sie rechts ab und Sie kommen nach 50 Metern.
<G-vec00309-003-s145><turn_out.abbiegen><en> Direction from South, exit Firenze Sud and follow signs to Liberty Square, Fortezza da Basso, the end of Viale Lavagnini you pull over and turn around the park's Fortress and continue straight under the railway bridge, past the bridge and after the second traffic light, keep the left, enter in Via Guido Monaco, at the end of which you turn right and you
<G-vec00309-003-s146><turn_out.abbiegen><de> Von den Taxiständen kommend, gehen Sie an den gelben DHL-Postfächern vorbei und biegen links in den Mittelgang mit den Schließfächern ab.
<G-vec00309-003-s146><turn_out.abbiegen><en> Coming from the main entrance please enter the central station and turn left before the escalator you will find us in front if the luggage lockers.
<G-vec00309-003-s147><turn_out.abbiegen><de> Unmittelbar nach der Kirche biegen Sie links ab und fahren die Straße hoch bis zum Haus Christine (befindet sich auf der linken Seite).
<G-vec00309-003-s147><turn_out.abbiegen><en> Right after the church, make a left turn and continue driving until you see Hause Christine (on the left hand side).
<G-vec00309-003-s148><turn_out.abbiegen><de> Im Ausgang der Ortschaft biegen wir links in den Wald ab und folgen dem neu angelegten Mullerthal Trail (Zeichenwechsel).
<G-vec00309-003-s148><turn_out.abbiegen><en> At the end of the village we turn left to enter the forest and follow the new Mullerthal Trail (sign change).
<G-vec00309-003-s149><turn_out.abbiegen><de> In Poysdorf angekommen fahren Sie die B7 weiter Richtung Drasenhofen und biegen am Ortsende links ab.
<G-vec00309-003-s149><turn_out.abbiegen><en> Drive through Poysdorf on the B7 direction to Drasenhofen and turn left at the end of the town.
<G-vec00309-003-s150><turn_out.abbiegen><de> Dort biegen Sie rechts ab und folgen dem Fahrweg bis zum Bauernhof Greidern und weiter in Richtung Seestüberl bis Sie wieder zurück zum Ausgangspunkt am Ostufer ankommen.
<G-vec00309-003-s150><turn_out.abbiegen><en> Here you turn right and follow the road to the farm Greidern and continue towards Seestüberl until you arrive the starting point again.
<G-vec00309-003-s151><turn_out.abbiegen><de> In Bad Ischl Nord biegen wir Richtung Ebensee / Gmunden ab.
<G-vec00309-003-s151><turn_out.abbiegen><en> In Bad Ischl, we turn north towards Ebensee / Gmunden.
