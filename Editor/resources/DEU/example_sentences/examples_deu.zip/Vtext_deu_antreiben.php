<G-vec00337-002-s049><spur.antreiben><de> Was zählt, ist Deine Einstellung und Deine Neugierde, die Dich antreiben – egal, wie weit Du mit der F 850 GS fahren willst.
<G-vec00337-002-s049><spur.antreiben><en> What matters is that your attitude and curiosity spur you on – regardless of how far you want to travel with the F 850 GS Sport.
