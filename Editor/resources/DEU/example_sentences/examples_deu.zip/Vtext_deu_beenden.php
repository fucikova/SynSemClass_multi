<G-vec00081-001-s060><discontinue.beenden><de> Sollten jedoch Rötungen, ein brennendes Gefühl oder Ausschlag auftreten, beende die Verwendung und konsultiere Deinen Arzt.
<G-vec00081-001-s060><discontinue.beenden><en> However, if redness, burning sensation, or rash occur, discontinue use and consult your physician.
<G-vec00081-001-s118><cease.beenden><de> Wenn Sie mit derartigen Änderungen nicht einverstanden sind, müssen Sie Ihren Zugriff auf die Webseite oder Ihre Nutzung der Webseite sofort beenden.
<G-vec00081-001-s118><cease.beenden><en> If you do not agree with any of such changes, you must immediately cease your access or use of the Website.
<G-vec00081-001-s119><cease.beenden><de> Um dies zu beenden, ist es wichtig zu versuchen, von Ein-und Ausatmen zu flach durch den oberen Teil des Rumpfes weg zu bleiben.
<G-vec00081-001-s119><cease.beenden><en> To cease this, it is important to attempt to stay away from inhaling and exhaling too shallowly by means of the top portion of your torso.
<G-vec00081-001-s120><cease.beenden><de> Um den echten Wunsch nach moksha – Befreiung – zu entwickeln, brauchen wir diese Einstellung: dass die Natur genau dieser Geburt, genau dieses Körpers, Leiden ist und daher wollen wir dies beenden.
<G-vec00081-001-s120><cease.beenden><en> In order to develop genuine desire for moksha – liberation – then we do need that kind of attitude: that this very birth, this body, its very nature is suffering and so we want to cease that.
<G-vec00081-001-s121><cease.beenden><de> Die Parteien haben eine besondere Verantwortung, Provokationen zu beenden und eine förderliche Umgebung für sinnvolle Verhandlungen zu schaffen.
<G-vec00081-001-s121><cease.beenden><en> The parties have a particular responsibility to cease provocations and create a conducive environment for meaningful negotiations.
<G-vec00081-001-s122><cease.beenden><de> Es ist wichtig, nicht die vorgeschriebene Dosierung zu ändern oder zu beenden dieses Medikament zu nehmen, es sei denn, um von Ihrem Arzt dazu aufgefordert werden, wie dabei das Risiko von Nebenwirkungen erhöht.
<G-vec00081-001-s122><cease.beenden><en> It is important not to alter the prescribed dosage or cease taking this medication unless instructed to do so by your physician, as doing so increases the risk of side effects.
<G-vec00081-001-s123><cease.beenden><de> Referenz: Das US Abgeordnetenhaus verabschiedet einstimmig eine Resolution, in der die chinesische Regierung dringend aufgefordert wird, die Unterdrückung von Falun Gong Praktizierenden in den Vereinigten Staaten und in China zu beenden.
<G-vec00081-001-s123><cease.beenden><en> Reference: U.S. House of Representatives Unanimously Passes Resolution Urging Chinese Government to Cease Its Oppression of Falun Gong Practitioners in the United States and in China
<G-vec00081-001-s124><cease.beenden><de> Ich appelliere an die Behörden, die Verfolgung von Falun Gong Praktizierenden sofort zu beenden und den Ruf von Falun Gong und unserem Lehrer anzuerkennen und wiederherzustellen.
<G-vec00081-001-s124><cease.beenden><en> I appeal to the authorities to immediately cease the persecution of Falun Gong practitioners and re-instate and recognize the reputation of Falun Dafa and our Teacher.
<G-vec00081-001-s125><cease.beenden><de> Deshalb unterstützen die Vereinigten Staaten nachdrücklich die heutige Verabschiedung der Resolution 2216 (2015), die die Aktionen der Huthis und des ehemaligen Präsidenten Saleh bestraft, die fordert, dass die Huthis ihre militärischen Operationen beenden und fordert alle Parteien auf, an den Verhandlungstisch zurückzukehren.
<G-vec00081-001-s125><cease.beenden><en> Those actions have caused widespread violence and instability that threaten the security and welfare of the Yemeni people, as well as the region’s security. As a result, the United States strongly supports the adoption of today’s resolution 2216 (2015), which imposes consequences on the Houthi and former President Saleh, demands that the Houthi cease military operations and calls on all sides to once again return to the negotiating table.
<G-vec00081-001-s126><cease.beenden><de> Sollte eine Person den Erhalt dieser E-Mails beenden wollen, muss sie dazu die Drittpartei direkt kontaktieren.
<G-vec00081-001-s126><cease.beenden><en> Should an individual wish to cease receiving such emails he must contact the third party directly to this effect.
<G-vec00081-001-s127><cease.beenden><de> Jede Änderung der Regeln oder der Bedingungen der Vereinbarungen, werden durch ein Pop-up-Fenster bekannt gegeben, so haben Sie die Möglichkeit das Glücksspiel zu beenden und/oder Ihr Konto in Übereinstimmung mit dieser Vereinbarung zu schließen.
<G-vec00081-001-s127><cease.beenden><en> Upon notification of any change to the rules or terms of the Agreements to You by pop-up box, You shall have the option to cease gambling and/or terminate Your Account in accordance with this agreement.
<G-vec00081-001-s128><cease.beenden><de> Table Distractions - PSLive behält sich das Recht vor, Spieler zum Beenden der Nutzung eines oder aller elektronischen Geräte oder anderer Gerätschaften aufzufordern, wenn das Floor-Personal der Meinung ist, dass durch diese Nutzung der Zeitplan oder andere Spieler am Tisch beeinträchtigt werden.
<G-vec00081-001-s128><cease.beenden><en> Table Distractions – PSLive reserves the right to ask players to cease using any and all Electronic Devices or any other items if the Floor Staff determines you are slowing down the pace of play, or otherwise affecting other players at your table.
<G-vec00081-001-s129><cease.beenden><de> Patienten mit Fortpflanzungsproblemen sollten begrenzen oder beenden Rauchen und Alkoholkonsum.
<G-vec00081-001-s129><cease.beenden><en> Patients experiencing reproductive problems should limit or cease smoking and intake of alcohol.
<G-vec00081-001-s130><cease.beenden><de> Beenden wird WACKER im Jahr 2012 die Eigenproduktion von Essigsäure am Standort Burghausen, da wir die benötigten Mengen bei vergleichbarer Versorgungssicherheit kostengünstiger einkaufen können.
<G-vec00081-001-s130><cease.beenden><en> WACKER will cease making its own acetic acid at Burghausen in 2012 because we can buy in the amounts more economically and with a similar level of supply security.
<G-vec00081-001-s131><cease.beenden><de> Sogar außerhalb von China wurden Länder, die der Parteivorsitzende Jiang Zemin besucht hat, einschließlich Deutschland Island und Burma u. a., durch den chinesische Präsidenten unter Druck gesetzt, in gesetzwidriger Weise die Rechte der Praktizierenden einzuschränken, welche lediglich dafür appellieren wollten, die Terror- und Mordkampagne zu beenden.
<G-vec00081-001-s131><cease.beenden><en> Even outside China, places where Chairman Jiang Zemin has visited including Germany, Iceland, Burma and others have been pressured by the Chinese leader to illegally limit the rights of the practitioners who merely want to appeal to cease the campaign of terror and killing.
<G-vec00081-001-s132><cease.beenden><de> Sie sind sich außerdem darüber im Klaren, dass Wir die Bereitstellung Unserer Website, deren Inhalte und Dienste jederzeit beenden können.
<G-vec00081-001-s132><cease.beenden><en> You are aware that We may cease the provision of the Website, its Content or Services at any time.
<G-vec00081-001-s133><cease.beenden><de> Ein gemeinsames Vorgehen gewährleistet, dass das System schneller und besser für die Opfer arbeitet, dass die Opfer geschützt werden und die Unterstützung erhalten, die sie benötigen, und dass die Täter in die Verantwortung genommen und ihr missbräuchliches Verhalten beenden.
<G-vec00081-001-s133><cease.beenden><en> Coordination helps to ensure that the system works faster and better for victims, that victims are protected and receive the services they need, and that batterers are held accountable and cease their abusive behaviour.
<G-vec00081-001-s134><cease.beenden><de> Sie sollten die Einnahme dieses Arzneimittels niemals abrupt beenden, da dies zu Entzugssymptomen führen kann.
<G-vec00081-001-s134><cease.beenden><en> You should never abruptly cease taking this drug, as this may cause withdrawal symptoms.
<G-vec00081-001-s135><cease.beenden><de> Er schlägt vor, dass wir die venezolanischen KapitalistInnen darum bitten, sich zu benehmen, ihre Sabotage zu beenden und patriotisch zu sein.
<G-vec00081-001-s135><cease.beenden><en> He proposes that we ask the Venezuelan capitalists to behave themselves, to cease their sabotage and to be Patriotic .
<G-vec00081-001-s136><cease.beenden><de> Wenn Ihr Einwand gerechtfertigt ist, werden wir Kopien und/oder Kopie der Daten, die wir verarbeiten (Let) zur Verfügung gestellt werden, und dann dauerhaft die Verarbeitung zu beenden.
<G-vec00081-001-s136><cease.beenden><en> If your objection Is justified, we will make copies and/or copy of the data that we process (let) be made available to you and then permanently cease processing.
<G-vec00081-001-s061><discontinue.beenden><de> Wenn Sie Ihre Zustimmung widerrufen, werden wir die personenbezogenen Daten, die wir zu Ihnen haben, anonymisieren und die Verarbeitung beenden, die von der Zustimmung betroffen war, z.
<G-vec00081-001-s061><discontinue.beenden><en> If you withdraw your consent, we will anonymise the personal data we hold about you, and discontinue any processing on the basis of that consent, e.g.
<G-vec00081-001-s062><discontinue.beenden><de> Hyatt Gold Passport kann die Hyatt Gold Passport-Mitgliedschaft ohne Ankündigung beenden, wenn ein Mitglied Hotelrechnungen nicht umgehend bezahlt oder das Programm auf eine nicht diesen Allgemeinen Geschäftsbedingungen oder dem Zweck des Programms entsprechende Art und Weise nutzt, einschließlich − aber nicht hierauf beschränkt − der Einlösung von Hyatt Gold Passport-Punkten und Verwendung von Gutscheinen.
<G-vec00081-001-s062><discontinue.beenden><en> Hyatt Gold Passport may, without notice, discontinue Hyatt Gold Passport membership if a member fails to promptly pay hotel bills or appears to be utilizing the program in a manner inconsistent with these Terms and Conditions or the intent of the program, including, but not limited to, Hyatt Gold Passport point redemption and certificate use.
<G-vec00081-001-s063><discontinue.beenden><de> Systematische Internalisierer können es ablehnen, mit Anlegern eine Geschäftsbeziehung aufzunehmen, oder sie können eine solche beenden, wenn dies aufgrund wirtschaftlicher Erwägungen wie der Bonität des Anlegers, des Gegenparteirisikos und der Abwicklung des Geschäfts erfolgt.
<G-vec00081-001-s063><discontinue.beenden><en> Systematic internalisers may refuse to enter into or discontinue business relationships with investors on the basis of commercial considerations such as the investor credit status, the counterparty risk and the final settlement of the transaction. 6.
<G-vec00081-001-s064><discontinue.beenden><de> Dies ermöglicht es Ihnen einfacher zu atmen, wenn Sie, wie auch beenden Ihre schnarchen ruhen.
<G-vec00081-001-s064><discontinue.beenden><en> This enables you to breathe more straightforward when you rest, as well as discontinue your snore.
<G-vec00081-001-s065><discontinue.beenden><de> Finnair ist jederzeit dazu berechtigt, die Mitgliedschaft eines Mitglieds ohne Angabe von Gründen zu beenden, wenn das betreffende Mitglied hierüber sechs (6) Monate vor Beendigung der Mitgliedschaft informiert wird.
<G-vec00081-001-s065><discontinue.beenden><en> Finnair is entitled at any time to discontinue the membership of any member without the member having given due cause therefor by informing the member in question six (6) months before termination of membership.
<G-vec00081-001-s066><discontinue.beenden><de> Beenden Sie Gespräche, wenn Ihr Gesprächspartner Ihnen Anweisungen erteilt, wie Sie auf Fragen von Western Union antworten sollen.
<G-vec00081-001-s066><discontinue.beenden><en> Discontinue a call if a caller instructs you on how to respond to questions asked by Western Union.
<G-vec00081-001-s067><discontinue.beenden><de> Es ist wichtig, nicht abrupt zu beenden das Medikament nehmen, da dies zu Entzugserscheinungen führen.
<G-vec00081-001-s067><discontinue.beenden><en> It is important not to abruptly discontinue taking this drug, as doing so may cause withdrawal symptoms.
<G-vec00081-001-s068><discontinue.beenden><de> In jenen zeiten ein erbe war von das äußerste wert, besonders wenn henry wollte präsentieren seine männlichkeit und beenden mit dem muster der die königliche fortpflanzungs- ausfall .
<G-vec00081-001-s068><discontinue.beenden><en> In those times an heir was of the utmost importance, especially if Henry wanted to showcase his masculinity and discontinue with the pattern of the royal reproductive failure.
<G-vec00081-001-s069><discontinue.beenden><de> """Diese seit Jahren eingespielte Zusammenarbeit nun zu beenden, ist eine große Gefahr für die Indigenen."
<G-vec00081-001-s069><discontinue.beenden><en> """For the indigenous peoples, the plans to discontinue this well-established cooperation is a great danger."
<G-vec00081-001-s070><discontinue.beenden><de> Mollie behält sich das Recht vor, die Ihnen zur Verfügung stehenden Dienstleistungen unmittelbar zu beenden, Ihnen den Zugriff auf das Zahlungsmodul zu untersagen, und diesen Vertrag aufzuheben, wenn Mollie den Verdacht hat, dass Sie gegen diesen Vertrag verstoßen.
<G-vec00081-001-s070><discontinue.beenden><en> Mollie reserves the right, with immediate effect, to discontinue the provision of its services to you, deny you access to the Payment Module and terminate this Agreement if Mollie suspects that you are acting in conflict with this Agreement.
<G-vec00081-001-s071><discontinue.beenden><de> Microsoft behält sich das Recht vor, Angebote jederzeit zu ändern oder zu beenden.
<G-vec00081-001-s071><discontinue.beenden><en> Microsoft reserves the right to modify or discontinue offers at any time.
<G-vec00081-001-s072><discontinue.beenden><de> Dow hält sich in alleinigem Ermessen das Recht vor, diesen Dienst allgemein oder für etwaige bestimmte Nutzer jederzeit zu beenden.
<G-vec00081-001-s072><discontinue.beenden><en> Dow, in its sole discretion, reserves all rights to discontinue this service generally or to any user at any time.
<G-vec00081-001-s073><discontinue.beenden><de> SCA hat sich entschlossen, das Hygienegeschäft in Indien im ersten Quartal 2017 zu beenden.
<G-vec00081-001-s073><discontinue.beenden><en> SCA has decided to discontinue its hygiene business in India in the first quarter of 2017.
<G-vec00081-001-s074><discontinue.beenden><de> Dies ermöglicht Ihnen einen Atemzug zu nehmen noch einfacher, wenn Sie schlafen, sowie beenden Ihre schnarchen.
<G-vec00081-001-s074><discontinue.beenden><en> This allows you to take a breath even more straightforward when you rest, and discontinue your snoring.
<G-vec00081-001-s075><discontinue.beenden><de> Ferner behählt CERATIZIT sich vor, nach eigenem Ermessen jederzeit unter Wahrung einer angemessenen Ankündigungsfrist von mindestens zwei Wochen vorzunehmen die Website zu überwachen und die Verfügbarkeit zu beenden.
<G-vec00081-001-s075><discontinue.beenden><en> CERATIZIT also reserves the right to monitor the website and to discontinue the availability thereof at any time, at its own discretion and with a reasonable notice period of at least two weeks.
<G-vec00081-001-s076><discontinue.beenden><de> Die Re-quote wird in der Regel auf der Plattform des Händlers angezeigt, ihnen die Möglichkeit zu geben, den neuen Preis zu akzeptieren oder abzulehnen, und fahren Sie mit oder den Handel zu beenden.
<G-vec00081-001-s076><discontinue.beenden><en> The re-quote will usually be displayed on the trader’s platform, giving them the opportunity to accept or reject the new price, and continue with or discontinue the trade.
<G-vec00081-001-s077><discontinue.beenden><de> *Die H&M Gruppe behält sich das Recht vor die genannten Vorteile ohne Vorankündigung einseitig zu ändern oder zu beenden.
<G-vec00081-001-s077><discontinue.beenden><en> *The H&M group reserves the right to amend or discontinue any of these benefits without notice.
<G-vec00081-001-s079><discontinue.beenden><de> Wir können beenden, auszusetzen oder zu modifizieren einem unserer Services in der Services oder der Verfügbarkeit der Dienste auf einem bestimmten Gerät oder Kommunikationsdienst jederzeit und ohne Mitteilung an Sie enthalten keine Funktion.
<G-vec00081-001-s079><discontinue.beenden><en> We may discontinue, suspend or modify any of our Services, any feature included in the Services, or the availability of the Services on any particular device or communications service, at any time and without notice to you.
<G-vec00081-001-s209><stop.beenden><de> Vor dem Neustart des Geräts, jedoch, Sie sollte zwingen Beenden der Facebook-app.
<G-vec00081-001-s209><stop.beenden><en> Before restarting the device, however, you should force stop the Facebook app.
<G-vec00081-001-s210><stop.beenden><de> Vor unseren Augen spielt sich derzeit eine Tragödie ab, die mit Stoppschildern und Grenzschließungen nicht zu beenden ist.
<G-vec00081-001-s210><stop.beenden><en> The tragedy currently unfolding before our eyes is one that cannot be resolved using stop signs and closing borders.
<G-vec00081-001-s211><stop.beenden><de> Das Ziel der primäre Sperr-Taktik, durch den Namen, es ist, ihre Gegner Stück zu beenden, vorübergehend, nicht die Sorgen um morir Verlagerung Ihre Chips schnell.
<G-vec00081-001-s211><stop.beenden><en> The main goal of the blocking strategy, by its title, is to stop your opponent’s chips, temporarily, not worrying about shifting your checkers quickly.
<G-vec00081-001-s212><stop.beenden><de> Die temporären Ausschüsse beenden ihre Tätigkeit nach der Ausführung und Bilanzierung der ihnen übertragenen Arbeit, für die sie gegründet wurden.
<G-vec00081-001-s212><stop.beenden><en> The temporary committees (TC) stop their activity after they have fulfilled and reported on the work that has been assigned to them, because of which they are created.
<G-vec00081-001-s213><stop.beenden><de> Die Europaparlamentarier fordern die EU-Mitgliedstaaten und die europäische Grenzschutzagentur FRONTEX auf, Abschiebungen und Zurückweisungen nach Libyen unverzüglich zu beenden.
<G-vec00081-001-s213><stop.beenden><en> The members of the European Parliament call on the EU member states and on the European border agency FRONTEX to stop deportation and push backs to Libya.
<G-vec00081-001-s214><stop.beenden><de> Wir appellieren an die internationale Gemeinschaft und an alle Menschenrechtsorganisationen, dieser Angelegenheit ihre Aufmerksamkeit zu schenken; wir bitten sie alles in ihrer Macht stehende zu tun um über Jiang ́s grausames Verhalten zu recherchieren und diese Verbrechen gegen die Gesellschaft und die Menschlichkeit zu beenden.
<G-vec00081-001-s214><stop.beenden><en> We appeal to international community, and to all human rights organisations to pay attention to this issue; we ask that you do everything in your power to investigate the savage behaviour of Jiang's regime, and to stop these crimes against human nature, against society, and against humanity.
<G-vec00081-001-s215><stop.beenden><de> Wir fordern Sie und Ihre Regierung auf, diese Verfolgung sofort zu beenden, die Folterungen zu beenden, die Inhaftierten freizulassen, weisen Sie Ihre Polizei an würdevoll zu handeln, stoppen Sie die körperlichen und psychischen Misshandlungen und geben Sie allen Falun Gong Praktizierenden ihre grundlegenden Bürgerrechte zurück.
<G-vec00081-001-s215><stop.beenden><en> We call on you and your government to stop this persecution immediately, stop the torture, release all those jailed, restrain your police to act with dignity, stop the physical and mental abuse, and restore the basic civil rights of all Falun Gong practitioners.
<G-vec00081-001-s217><stop.beenden><de> Sie können uns zum Beenden der Verarbeitung Ihrer personenbezogenen Daten zu Marketingzwecken einschließlich Analysen zwecks gezielter Vermarktung, darunter Online-Werbung, auffordern.
<G-vec00081-001-s217><stop.beenden><en> You may request us to stop processing of your personal information for marketing purposes including analytics for the purposes of targeted marketing, including online advertising.
<G-vec00081-001-s218><stop.beenden><de> "Als ein Falun Gong Praktizierende sagte: ""lasst uns zusammen die Verfolgung beenden"", erntete er eine Runde Applaus."
<G-vec00081-001-s218><stop.beenden><en> When a Dafa practitioner said, “Let us stop this persecution together”, he received a round of applause.
<G-vec00081-001-s219><stop.beenden><de> In Word 2007 kehrst du in den Reiter Entwickler zurück und drückst auf Aufzeichnung beenden, anstatt auf Makros > Aufzeichnung beenden.
<G-vec00081-001-s219><stop.beenden><en> In Word 2007, return to the Developer tab and press Stop Recording instead of clicking Macros > Stop Recording.
<G-vec00081-001-s221><stop.beenden><de> Auf diese Weise wird es eine Orientierungshilfe für die Wahl für die vielen Bürger sein, die den durch Tierversuche verursachten Schaden endlich beenden und dieses Hindernis für wissenschaftlichen und ethischen Fortschritt beseitigen wollen.
<G-vec00081-001-s221><stop.beenden><en> This will provide a clear indication of voting for the many citizens willing to stop the damage caused by animal experimentation, and by the obstacle it poses to scientific progress and to ethics as well.
<G-vec00081-001-s222><stop.beenden><de> Diese Beziehung dauerte an: Es gibt keinen Grund sie zu beenden, wenn man einmal darin war... dann gibt es keinen Weg sich daraus zu entziehen.
<G-vec00081-001-s222><stop.beenden><en> That relationship has continued, there's no reason to stop it, once you've experienced it...there's no way that I would withdraw.
<G-vec00081-001-s223><stop.beenden><de> Wenn Sie noch mehr Details oder umsetzbare Anleitung benötigen, empfehle ich immer ein Duplikat von Brad Pilon essen Beenden Sie essen.
<G-vec00081-001-s223><stop.beenden><en> If you require more info or actionable guide, I recommending obtaining a duplicate of Brad Pilon's Consume Stop Take.
<G-vec00081-001-s224><stop.beenden><de> Noch ist es nicht zu spät es zu beenden.
<G-vec00081-001-s224><stop.beenden><en> It is not too late to stop.
<G-vec00081-001-s225><stop.beenden><de> Also diese Tablette wird Ihren Heißhunger zu beenden, auch wenn Sie nicht über ein hohes Maß an Selbstbeherrschung.
<G-vec00081-001-s225><stop.beenden><en> So this tablet will certainly stop your yearnings, even if you do not have a bunch of self-control.
<G-vec00081-001-s226><stop.beenden><de> Mein Wunsch ist, dass sich alle Menschen mit einem Gefühl für Gerechtigkeit dieser Sache annehmen; lasst uns gemeinsam die Verfolgung beenden.
<G-vec00081-001-s226><stop.beenden><en> I Wish all people with a sense of justice to pay attention to Ms. Yang Cuiling's case, and to stop the persecution together.
<G-vec00081-001-s227><stop.beenden><de> "- ""Die Vereinigten Staaten riefen zu einer Waffenruhe binnen 30 Tagen auf und betonten die Notwendigkeit, die Bombardierung der von Zivilisten bewohnten Gebiete im Jemen zu beenden, die durch die saudisch geführte Arabische Allianz durchgeführt wird."
<G-vec00081-001-s227><stop.beenden><en> """The United States called for a cease-fire in Yemen within 30 days, stressing the need to stop the Arab coalition led by Saudi Arabia, bombing civilian populated areas in Yemen."
<G-vec00081-001-s080><discontinue.beenden><de> Rationale Art, etwas zu beenden; oder es ist rational, etwas aufzuhören.
<G-vec00081-001-s080><discontinue.beenden><en> Rational way of putting an end to something; or, it's rational to discontinue something.
<G-vec00081-001-s082><discontinue.beenden><de> Zunächst genügt es, die Sparpakete zu beenden und auf dem jetzigen Stand innezuhalten.
<G-vec00081-001-s082><discontinue.beenden><en> Initially, it will be enough to discontinue the austerity packages and maintain the present situation.
<G-vec00081-001-s083><discontinue.beenden><de> Reduzieren Sie die Dosierung oder beenden Sie die Einnahme, falls Schlaflosigkeit, Zittern, Benommenheit, Nervosität, Kopfschmerzen oder Herzklopfen auftreten.
<G-vec00081-001-s083><discontinue.beenden><en> Reduce or discontinue use if sleeplessness, tremors, dizziness, nervousness, headaches, or heart palpitations occur.
<G-vec00081-001-s228><stop.beenden><de> Sie fügte hinzu, dass sie ihren Vater retten, und diese Verfolgung von Falun Gong beendet werden müsse.
<G-vec00081-001-s228><stop.beenden><en> Sunny added that, she must rescue her father and stop this persecution of Falun Gong.
<G-vec00081-001-s229><stop.beenden><de> Sie betreiben wissenschaftliche Forschungen um glücklich zu werden, aber diese Schurken, sie wissen nicht, wie man den Tod beendet.
<G-vec00081-001-s229><stop.beenden><en> They are making scientific researches to become happy, but these rascals, they do not know how to stop death.
<G-vec00081-001-s230><stop.beenden><de> Mit Transparentaufschriften wie „Stellt Zhang Dejiang vor Gericht“ und „Beendet den Organraub in China“ brachten sie zum Ausdruck, in welchem Maße sich Zhang an der Verfolgung von Falun Gong in China beteiligt hat.
<G-vec00081-001-s230><stop.beenden><en> With banners reading “Bring Zhang Dejiang to Justice” and “Stop Forced Organ Harvesting in China,” practitioners explained how Zhang had been heavily involved in the suppression of Falun Gong in China.
<G-vec00081-001-s231><stop.beenden><de> "Die australische Delegation der CIPFG fordert außerdem die Umsetzung der Empfehlungen 10, 15, 16 und 17 des Matas-Kilgour Report durch die chinesische Regierung – ""die Unterdrückung, Gefangennahme und harte Behandlung der Falun Gong-Praktizierenden muss sofort beendet werden"", ""der Organraub von exekutierten Gefangenen soll auf der Stelle aufhören"" und ""Organtransplantate dürfen nicht verkauft werden""."
<G-vec00081-001-s231><stop.beenden><en> "The Australian CIPFG also urge the implementation of recommendations 10, 15, 16, and 17 of the Matas-Kilgour Report by the Chinese government - ""the repression, imprisonment and severe treatment of Falun Gong practitioners must stop immediately"", ""organ harvesting from executed prisoner should cease immediately"", and ""organ transplants should not be for sale""."
<G-vec00081-001-s232><stop.beenden><de> Christina fand, dass Gräueltaten wie der Organraub an lebenden Menschen jeden betreffen: „Wir müssen aktiv etwas tun, damit das beendet wird.
<G-vec00081-001-s232><stop.beenden><en> Christina thinks atrocities like live organ harvesting from living people should concern everyone, “We have to take action to stop it.
<G-vec00081-001-s233><stop.beenden><de> Bereits zur Mitte der vergangenen Saison wurde der „Temsa“ Clio mit einem 100 Liter FT3-Tank bestückt, womit ein 4-Stunden-Rennen normalerweise mit nur einem Tankstopp beendet werden kann.
<G-vec00081-001-s233><stop.beenden><en> Mid time last season, the “Temsa” Clio was already equipped with a 100 litres FT3 fuel tank so that a race of 4 hours duration can normally be contested with only one fuel stop.
<G-vec00081-001-s234><stop.beenden><de> Da sowas niemals zum Hauptthema einer Diskussion werden sollte, kann es angebracht sein, hierfür eine vorformulierte Antwort parat zu haben, die so gestaltet ist, dass sie die Diskussion eher beendet als anfeuert.
<G-vec00081-001-s234><stop.beenden><en> Since this is not something you ever want as the main topic of discussion on your list, it might be good to have a canned response ready, of the sort that's more likely to stop discussion than encourage it.
<G-vec00081-001-s235><stop.beenden><de> Dieser Brief trägt die Überschrift „Beendet die Verfolgung von Gläubigen an die Freiheit und bringt eure Verbindung mit den chinesischen Menschen in Ordnung“.
<G-vec00081-001-s235><stop.beenden><en> "That letter addressed the topic, ""Stop Persecuting Believers of Freedom and Mend Your Ties with the Chinese People."""
<G-vec00081-001-s236><stop.beenden><de> 1963 haben diese Bewegungen dafür gesorgt, dass die Nuklearwaffentests in der Atmosphäre beendet wurden, durch die unser Planet vergiftet und der Krebstod von Millionen von Menschen verursacht wurde.
<G-vec00081-001-s236><stop.beenden><en> These movements were able, in 1963, to stop the atmospheric tests of nuclear weapons which were poisoning our planet, and have caused the deaths by cancer of millions of humans.
<G-vec00081-001-s237><stop.beenden><de> Die Falun Gong Praktizierenden zeigen, dass China niemals als zivilisiertes Land betrachtet werden kann, solange die Folter nicht beendet ist.
<G-vec00081-001-s237><stop.beenden><en> (Falun Gong practitioners) show China can never be accepted as a civilized country if it does not stop the torture.
<G-vec00081-001-s238><stop.beenden><de> Nachdem die Erfahrung beendet ist, kann es aktiv werden.
<G-vec00081-001-s238><stop.beenden><en> If it is active while it is there, the experience may stop altogether.
<G-vec00081-001-s239><stop.beenden><de> "Sie zeigten ein Transparent, auf dem stand: ""Nur durch die Auflösung der KPCh kann die Verfolgung beendet werden""."
<G-vec00081-001-s239><stop.beenden><en> "They displayed a banner with the words, ""Only dissolving the CCP can stop the persecution."""
<G-vec00081-001-s240><stop.beenden><de> Beendet das Zurückblicken.
<G-vec00081-001-s240><stop.beenden><en> Stop looking back.
<G-vec00081-001-s241><stop.beenden><de> BEENDET was auch immer es ist, das dieses Gefühl verursacht und ÄNDERT es...
<G-vec00081-001-s241><stop.beenden><en> STOP whatever it is that is causing that feeling and CHANGE it...
<G-vec00081-001-s242><stop.beenden><de> Falls Ihr Widerspruch berechtigt ist, sorgen wir dafür, dass die Verarbeitung Ihrer personenbezogenen Daten beendet wird.
<G-vec00081-001-s242><stop.beenden><en> lodge an objection. If your objection is warranted, we undertake to stop processing your personal data.
<G-vec00081-001-s243><stop.beenden><de> Dadurch werden nicht nur die Aufzeichnungen beendet, sondern die Datenbank könnte zudem durch die unerwartete Abschaltung beschädigt werden Achten Sie darauf, die entsprechenden Funktionen in den Windows-Energieoptionen zu deaktivieren.
<G-vec00081-001-s243><stop.beenden><en> Not only will recordings stop, but database corruption might occur from the unexpected stop. Make sure to disable these functionalities in the Windows Power Options.
<G-vec00081-001-s244><stop.beenden><de> Auf den großen Transparenten der Praktizierenden stand: „Stellt Jiang Zemin vor Gericht“, „Falun Dafa ist großartig“, „Beendet die Verfolgung von Falun Gong“ und mehr.
<G-vec00081-001-s244><stop.beenden><en> The date was October 23, the final day of Xi's visit to England. Falun Gong practitioners held large banners reading “Bring Jiang Zemin to Justice”, “Falun Dafa Is Great”, “Stop the Persecution of Falun Gong” and more.
<G-vec00081-001-s245><stop.beenden><de> Dienste sind derart konzipiert, dass sie bei Bedarf automatisch starten und beendet werden; und wie Elise bei 20:24 darlegt, kann ein beendeter Dienst manuell gestartet werden.
<G-vec00081-001-s245><stop.beenden><en> Services are designed to automatically start and stop when they are needed and when they are not; and, as Elise points out at 8:24, a stopped service can be started manually.
<G-vec00081-001-s246><stop.beenden><de> Wenn ihr das Töten beendet und euch weigert Teil ihres Programms der Übernahme zu sein, sind sie am Ende, denn sie können es nicht ohne euch tun.
<G-vec00081-001-s246><stop.beenden><en> When you stop the killing and refuse to be part of their programme of take-over, they are finished, for they cannot do it without you.
<G-vec00081-001-s109><discontinue.beenden><de> Bei einer hypertensiven Dringlichkeit reicht es, die zahnärztliche Behandlung zu beenden und den Blutdruck nach 30 Minuten Ruhe zu kontrollieren und innerhalb von 24 h zu senken.
<G-vec00081-001-s109><discontinue.beenden><en> In hypertensive urgency, it is sufficient to discontinue dental treatment and control blood pressure after 30 minutes rest and lower it within 24 hours.
<G-vec00081-001-s137><discontinue.beenden><de> Nachhaltige Strategien der Klärschlammbehandlung sind dringend erforderlich – nicht zuletzt, weil die Bundesregierung plant, die Klärschlammausbringung zu Düngezwecken zu beenden.
<G-vec00081-001-s137><discontinue.beenden><en> Sustainable sludge treatment strategies are vital – also in view of the fact that many countries plan to discontinue the use of sludge as fertiliser.
<G-vec00081-001-s139><discontinue.beenden><de> Sollten solche allergischen Reaktionen auftreten, ist es ratsam die Einnahme zu beenden und eine Fortsetzung der Verwendung mit dem behandelnden Arzt abzusprechen.
<G-vec00081-001-s139><discontinue.beenden><en> If such allergic reactions occur, it is advisable to discontinue the usage of Ginkgo and to discuss any further use with the treating physician.
<G-vec00081-001-s207><discontinue.beenden><de> Sie haben jederzeit die Möglichkeit, unseren Service mit einer individuellen Nachricht zu beenden.
<G-vec00081-001-s207><discontinue.beenden><en> You have the option to discontinue our service with a individual message at any time.
<G-vec00081-001-s217><discontinue.beenden><de> Finnair ist berechtigt, die Finnair Plus-Mitgliedschaft eines Kunden durch Entfernen der persönlichen Daten des Kunden sowie das Löschen der Mitgliedsnummer aus dem Finnair Plus-Kundenregister zu beenden, falls im Konto dieses Kunden während der vorangegangenen fünf (5) Jahre keine Transaktionen registriert wurden und der Kunde daher keine gültigen Punkte aufweist.
<G-vec00081-001-s217><discontinue.beenden><en> Finnair is entitled to discontinue the Finnair Plus membership of a customer by removing the customer’s personal details and membership number from the Finnair Plus customer register in the case that no transactions have been registered to that customer’s account during the previous five (5) years and, consequently, the customer has no valid points.
<G-vec00081-001-s290><discontinue.beenden><de> Recht auf Seiten ändern Wir behalten uns vor, jederzeit nach eigenem Ermessen, auf: zu ändern, auszusetzen oder zu beenden die Website oder einen Dienst, den Inhalt, Funktion oder Produkt durch die Website angeboten, mit oder ohne Ankündigung; erheben Gebühren im Zusammenhang mit der Nutzung der Website; modifizieren und / oder verzichten auf jegliche Gebühren in Verbindung mit der Website geladen; und / oder bieten die Chance, einige oder alle Benutzer der Website.
<G-vec00081-001-s290><discontinue.beenden><en> Right to Change Sites We reserve the right, at any time in our sole discretion, to: modify, suspend or discontinue the Site or any service, content, feature or product offered through the Site, with or without notice; charge fees in connection with the use of the Site; modify and/or waive any fees charged in connection with the Site; and/or offer opportunities to some or all users of the Site.
<G-vec00213-002-s075><cease.beenden><de> 10.1 Der Plattformbetreiber behält sich vor, das Projekt zu jedem Zeitpunkt ohne Vorankündigung und ohne Angabe von Gründen abzubrechen oder zu beenden.
<G-vec00213-002-s075><cease.beenden><en> 10.1 The Platform Operator reserves the right to abort or cease the Project at any time without prior notice and without providing reasons.
<G-vec00213-002-s076><cease.beenden><de> Es wird ebenfalls empfohlen, das Medikament zu beenden, wenn Sie nach der Einnahme der Pille ungesund fühlen.
<G-vec00213-002-s076><cease.beenden><en> It is also encouraged to cease the medicine if you are really feeling unwell after taking in the pill.
<G-vec00213-002-s080><cease.beenden><de> Sie haben das Recht, jederzeit den Zugriff auf die Anwendung und die Nutzung dieser zu beenden.
<G-vec00213-002-s080><cease.beenden><en> You have the right to cease accessing and using any Application at any time.
<G-vec00213-002-s081><cease.beenden><de> Im Falle einer Ablehnung von Änderungen an dieser Datenschutzerklärung ist der Nutzer verpflichtet, die Nutzung dieser Anwendung zu beenden und kann die Daten-Controller benötigen, um Ihre persönlichen Informationen zu löschen.
<G-vec00213-002-s081><cease.beenden><en> In case of non-acceptance of the changes made to this privacy policy, the User is required to cease using this Application and may request the Data Controller to remove his Personal Data.
<G-vec00213-002-s082><cease.beenden><de> 4.6 Indem Sie Spiele-Währung erwerben, wie auch die Spiele-Währung gegen Spiele-Vermögenswerte tauschen, verstehen Sie, dass (i) Ihr Zugang zu den Spiele-Services gesperrt werden kann auf Grundlage der vorliegenden Nutzungsbedingungen, und (oder) (ii) die Spiele-Services ihre Verfügbarkeit zu einem beliebigen Zeitpunkt aus einem beliebigen Grund beenden können, und die gegebenen Umstände Ihnen keinen Grund geben, von My.com eine Entschädigung von geldlichen Gebühren, die für die Spiele-Währung bezahlt wurden, zu fordern.
<G-vec00213-002-s082><cease.beenden><en> 4.6 By purchasing in-game currency, as well as exchanging in-game currency for in-game valuables, You realize that (i) Your access to the Game Services may be terminated according to these Terms, and/or (ii) the Game Services may cease to exist at any time for any reason, and this does not give You reason to require from My.com refund of the fees paid for the in-game currency.
<G-vec00213-002-s083><cease.beenden><de> Der Umstieg in erneuerbare Energien ist daher zu beschleunigen und die Kernenergienutzung baldmöglichst zu beenden.
<G-vec00213-002-s083><cease.beenden><en> The changeover to renewable energy sources should thus be accelerated, and the use of nuclear energy should cease as soon as possible.
<G-vec00213-002-s085><cease.beenden><de> Sie erklären sich zu einer Zusammenarbeit mit uns bereit, wenn es darum geht, unberechtigtes Framing oder Verlinken sofort zu beenden.
<G-vec00213-002-s085><cease.beenden><en> You agree to cooperate with us in causing any unauthorized framing or linking immediately to cease.
<G-vec00213-002-s086><cease.beenden><de> Nach Beendigung dieses Vertrages beenden Sie jegliche Nutzung der Anwendung und löschen alle Kopien der Anwendung von Ihrem mobilen Gerät oder von Ihrem Computer.
<G-vec00213-002-s086><cease.beenden><en> Upon termination of this Agreement, you shall cease all use of the Application and delete all copies of the Application from your mobile device or from your computer.
<G-vec00213-002-s087><cease.beenden><de> Mehrere Yoga-Haltungen können nachweislich Menstruationsschmerzen beenden.
<G-vec00213-002-s087><cease.beenden><en> Several Yoga poses are proven to cease Menstrual Pain.
<G-vec00213-002-s171><complete.beenden><de> Verwenden Sie die Cursortasten ▲/▼zur Korrektur der Verzerrung.Drücken Sie die KEYSTONE-Taste erneut zum Schließen des Dialogs und Beenden dieses Vorgangs.
<G-vec00213-002-s171><complete.beenden><en> Use the ◄/► buttons for adjustment. To close the dialog and complete this operation, press KEYSTONE button again.
<G-vec00213-002-s172><complete.beenden><de> Sie haben begrenzte Leben, um jeden Level zu beenden.
<G-vec00213-002-s172><complete.beenden><en> You have limited lives to complete each level.
<G-vec00213-002-s173><complete.beenden><de> Wenn ein Alignment Tool auf einem Laufwerk ausgeführt wird, das bereits ausgerichtet ist, wird das Tool die Ausrichtung erkennen und das Alignment beenden, ohne die Laufwerksfunktion oder das Image zu beeinflussen.
<G-vec00213-002-s173><complete.beenden><en> If a partition alignment tool is run on a drive that is already aligned, the tool will detect the alignment and complete without impacting the drive or image.
<G-vec00213-002-s174><complete.beenden><de> Beenden Sie Ihren Tag mit einem köstlichen Mittag- oder Abendessen.
<G-vec00213-002-s174><complete.beenden><en> Complete your day with a delicious lunch or dinner.
<G-vec00213-002-s175><complete.beenden><de> Beschreibung: Dein Ziel ist, jedes Level so schnell wie möglich zu beenden und die maximale Punktzahl zu erreichen.
<G-vec00213-002-s175><complete.beenden><en> Description: The goal of the game is to complete each level as soon as possible and get maximum scores.
<G-vec00213-002-s176><complete.beenden><de> Du wirst unterschiedlich vorgehen, wenn du deinem besten Freund etwas Heikles unterbreitest und wenn du einen faulen Kollegen motivieren willst, mit dem du ein Projekt beenden musst.
<G-vec00213-002-s176><complete.beenden><en> There will be a different approach between telling your best friend something delicate and motivating a slack co-worker with whom you are trying to complete a project.
<G-vec00213-002-s177><complete.beenden><de> Anpassen jedes Upgrade, um jeden Level zu beenden.
<G-vec00213-002-s177><complete.beenden><en> Customise each upgrade to complete each level.
<G-vec00213-002-s178><complete.beenden><de> Einige haben gerade mit der Bestellung begonnen, andere sind dabei, ihre Aussaat zu beenden.
<G-vec00213-002-s178><complete.beenden><en> Some have come to begin to cultivate, others to complete their sowing.
<G-vec00213-002-s179><complete.beenden><de> Um ein mehrtägiges Etappen-Radrennen wie die Tour de France erfolgreich zu beenden, sind ein gezieltes Training und auch die genetischen Voraussetzungen sehr entscheidend.
<G-vec00213-002-s179><complete.beenden><en> In order to successfully complete a multi-day stage cycling race like the Tour de France, specific training and also the genetic prerequisites are very important.
<G-vec00213-002-s180><complete.beenden><de> Der Ableser muss jedoch zuerst die Ablesung beenden, bevor die Ablesewerte vom Kontrolleur bearbeitet werden können.
<G-vec00213-002-s180><complete.beenden><en> The reader has to complete the reading before the supervisor can edit the meter readings.
<G-vec00213-002-s181><complete.beenden><de> Jede Missionsbedingung, welche den Spieler dazu zwingen, eine der Regeln oder Änderungen zu brechen sind erlaubt, um die Mission zu beenden.
<G-vec00213-002-s181><complete.beenden><en> Any mission objective that explicitly demands that the player break one of the rules above is OK to complete and does not bust the ghost.
<G-vec00213-002-s182><complete.beenden><de> Alles in allem benötigte ich mehr als 60 Stunden, um all diese Levels zu beenden, die komplette Serie.
<G-vec00213-002-s182><complete.beenden><en> All in all I needed more than 60 hours to complete all those levels, the complete series.
<G-vec00213-002-s183><complete.beenden><de> Admin – kann das Projekt bearbeiten und beenden.
<G-vec00213-002-s183><complete.beenden><en> Admin - Can edit and complete the project.
<G-vec00213-002-s184><complete.beenden><de> In deinem Abenteuer kannst du ein Schwert, Fähigkeiten oder sogar geheime Wege finden, die deinem Charakter helfen, Level schneller zu beenden.
<G-vec00213-002-s184><complete.beenden><en> In your adventure, you can find a sword, abilities or even secret ways, that will help your character complete levels faster.
<G-vec00213-002-s185><complete.beenden><de> Wecke den schnarchenden Elefanten auf, um jedes Level zu beenden.
<G-vec00213-002-s185><complete.beenden><en> Wake up the snoring elephant to complete each level.
<G-vec00213-002-s186><complete.beenden><de> Knock down all die Hubschrauber, um jeden Level zu beenden.
<G-vec00213-002-s186><complete.beenden><en> Knock down all the helicopters to complete each level.
<G-vec00213-002-s187><complete.beenden><de> Sie beenden Ihr Studium im vierten Semester mit einem Kolloquium und Ihrer Masterarbeit.
<G-vec00213-002-s187><complete.beenden><en> You will complete the programme in the seventh semester, concluding with a colloquium and your Master’s thesis.
<G-vec00213-002-s188><complete.beenden><de> Es wird Sie dazu bringen jedes einzelne Level zu beenden.
<G-vec00213-002-s188><complete.beenden><en> It will make you rack your brains to complete every single level.
<G-vec00213-002-s189><complete.beenden><de> Führen Sie das Springen Basketball auf dem Niveau und sammeln Sie alle Sterne, um das Level zu beenden.
<G-vec00213-002-s189><complete.beenden><en> Guide the Jumping Basketball around the level and collect all the stars to complete the level.
<G-vec00213-002-s141><conclude.beenden><de> Viel Disziplin aber auch Erholung und Vergnügung: zu Füßen des Gletschers ermöglichen die gute Küche und die Dienste des Hotels Pirovano Quarto, den Tag auf bestmögliche Weise zu beenden.
<G-vec00213-002-s141><conclude.beenden><en> A lot of sport discipline, but also moments of regenerating relaxation and fun: once you get off the glacier, the excellent cuisine and all the “pampering” of the Pirovano Quarto Hotel will allow you to conclude the day in the best possible way!
<G-vec00213-002-s142><conclude.beenden><de> Sie sind die Vollendung und das Ende von Gottes sechstausendjährigem Führungsplan, und sie beenden den Lebensweg des Leidens der Menschheit.
<G-vec00213-002-s142><conclude.beenden><en> They are the completion and the ending of God’s six-thousand-year management plan, and they conclude mankind’s life journey of suffering.
<G-vec00213-002-s143><conclude.beenden><de> Beenden Sie Ihren Abend mit einem Cowboy (oder Cowgirl)-Lagerfeuer unter dem Sternenhimmel (wetterabhängig).
<G-vec00213-002-s143><conclude.beenden><en> Conclude your evening with a cowboy (or cowgirl) campfire under the stars (weather permitting).
<G-vec00213-002-s144><conclude.beenden><de> Auf lange Sicht, beenden wir diese Inhalte von 100% Überweisung von unserer Seite.
<G-vec00213-002-s144><conclude.beenden><en> In the long run, we conclude this material by 100 % suggestion from our side.
<G-vec00213-002-s145><conclude.beenden><de> Wenn das Gericht so leicht ohne einen Verteidiger auskommt, so wird es den Fall sicher auch ohne den Angeklagten beenden können.
<G-vec00213-002-s145><conclude.beenden><en> "If the court so easily dispenses with a defense lawyer, it will also easily conclude the case without the accused.
<G-vec00213-002-s146><conclude.beenden><de> Deshalb möchte ich meine Ausführungen auch mit Dankesworten dem gegenüber beenden, der – zwei Monate vor seiner Wahl – freundlicherweise bereit gewesen war, die Einleitung zu einem Gebetbüchlein zu schreiben, das übrigens auch ein Leitfaden zu einem guten Beichten ist.
<G-vec00213-002-s146><conclude.beenden><en> Which is why I would like to conclude these signs by thanking the person who, two months before being elected pope, agreed to write the introduction to a small book of prayers that also contains the how and what required to make a good confession.
<G-vec00213-002-s147><conclude.beenden><de> Wenn kein Resultat zustande kommt, bevor der Cardroom oder das Stadion schließt und es augenscheinlich ist, dass die Veranstaltung nicht regulär beendet werden kann, werden die Spieler im Vorhinein darüber informiert, dass zum Beenden des Turniers ein Chip Count vonnöten sein kann.
<G-vec00213-002-s147><conclude.beenden><en> If a result has not been reached before the cardroom or stadium approaches closing time, and it is apparent that the contest will not finish naturally, players will be informed well in advance that a chip count maybe required to conclude the tournament.
<G-vec00213-002-s148><conclude.beenden><de> Wir beenden unsere Betrachtungen mit einer vergleichenden Studie über die Socket APIs in Java 2 und Berkeley UNIX und die verteilten Objektmodelle von Java RMI und CORBA.
<G-vec00213-002-s148><conclude.beenden><en> We conclude with a comparative study of the Socket APIs in Java 2 and in Berkeley UNIX and the distributed object models of Java RMI and CORBA.
<G-vec00213-002-s149><conclude.beenden><de> Die Entscheidungen beenden die konstruktiven Gespräche zwischen den Unternehmen sowie den Behörden während der letzten Monate.
<G-vec00213-002-s149><conclude.beenden><en> The decisions conclude constructive discussions during the recent months between the companies and the authorities.
<G-vec00213-002-s150><conclude.beenden><de> „Wir empfehlen, einmonatige Kampagnen während der letzten fünf Tage des Ramadans zu beenden und stattdessen durch eine Kampage zu ersetzen, die den Nutzern ein schönes Eid-al-Fitr wünscht“, so Omar.
<G-vec00213-002-s150><conclude.beenden><en> “We recommend to conclude any month-long campaigns you’re running during the last five days of Ramadan, and replace it with a campaign that wishes users a happy Eid,” Omar says.
<G-vec00213-002-s151><conclude.beenden><de> Arsch zu Mund ist ein fantastischer Weg, um den Analsex zu beenden, wenn es nach den meisten unserer männlichen Models geht.
<G-vec00213-002-s151><conclude.beenden><en> Going ass to mouth is a fantastic way to conclude anal sex according to most of our male models.
<G-vec00213-002-s152><conclude.beenden><de> Wir beenden unsere Fahrt in Kjøllefjord, wo wir wieder das Hurtigruten Schiff besteigen.
<G-vec00213-002-s152><conclude.beenden><en> We conclude our expedition in Kjøllefjord where you rejoin the Hurtigruten ship.
<G-vec00213-002-s153><conclude.beenden><de> Vielen Dank.” So hat er gesagt, um seinen ersten Beitrag zu beenden.
<G-vec00213-002-s153><conclude.beenden><en> “Thank you, very much”, he said to conclude his first intervention.
<G-vec00213-002-s154><conclude.beenden><de> Beenden Sie Ihren Besuch des Palazzo Reale mit einem Bummel über die Dachterrasse.
<G-vec00213-002-s154><conclude.beenden><en> Conclude your visit to the Palazzo Reale with a stroll on the rooftop terrace.
<G-vec00213-002-s155><conclude.beenden><de> Wir beenden den Monat Mai mit dieser eindrucksvollen Marienandacht.
<G-vec00213-002-s155><conclude.beenden><en> We conclude the month of May with this evocative Marian prayer meeting.
<G-vec00213-002-s156><conclude.beenden><de> Auf lange Sicht, beenden wir diese Inhalte von 100% Vorschlag von unserer Seite.
<G-vec00213-002-s156><conclude.beenden><en> In the long run, we conclude this material by 100 % referral from our side.
<G-vec00213-002-s157><conclude.beenden><de> Der Weg verläuft durch 4 Gemeinden und so beginnen wir in Dolenjske Toplice, setzen unseren Weg fort, vorbei an Mirna Peè, durch Dobrniè und beenden ihn in ®u¾emberg beim Schloss.
<G-vec00213-002-s157><conclude.beenden><en> The trail runs through 4 municipalities, so we start off in Dolenjske Toplice, continue past Mirna Peè, through Dobrniè and conclude our trail in ®u¾emberk next to the castle.
<G-vec00213-002-s158><conclude.beenden><de> Beenden Sie diese faszinierende Tour durch das Hinterland der Romagna mit einem Aufstieg in Richtung Gabicce Monte.
<G-vec00213-002-s158><conclude.beenden><en> Conclude this fascinating tour in the hinterland of Romagna by going up towards Gabicce Monte.
<G-vec00213-002-s159><conclude.beenden><de> Um das Thema zu beenden, wer von Gott geliebt wird, wird den Ewigen Aufenthalt im Himmel antreten und Gott gewährt ihm Seine Liebe und Gnade unter denen, die Gutes taten, denen, die mit wahrer Aufrichtigkeit glaubten und die Taten der Rechtschaffenheit verrichteten.
<G-vec00213-002-s159><conclude.beenden><en> To conclude the matter, whoever is loved by God will enter the Abode of Heaven, and God bestows His Love and Grace upon the good doers, those who believe with true sincerity and who do works of righteousness.
<G-vec00213-002-s133><end.beenden><de> Als die Ausstellung beendet wurde, kam eine Frau, die in einer Apotheke arbeitete, vorbei und bot den Praktizierenden heiße Getränke an.
<G-vec00213-002-s133><end.beenden><en> At the end of the exhibition, a lady working in a pharmacy brought hot drinks for the practitioners.
<G-vec00213-002-s134><end.beenden><de> Mitchy Gerber, USA Die Verfolgung von Falun Gong muss beendet werden.
<G-vec00213-002-s134><end.beenden><en> Mitch Gerber from the USA: The ongoing persecution against Falun Gong must truly end.
<G-vec00213-002-s135><end.beenden><de> Nach der Saison 2001 beendet der Finne seine Formel-1-Karriere.
<G-vec00213-002-s135><end.beenden><en> The Finn wound up his Formula One career at the end of the 2001 season.
<G-vec00213-002-s136><end.beenden><de> Wenn Sie einen Vertrag stornieren, weil wir Sie über einen Fehler bei der Preisangabe des von Ihnen bestellten Produkts benachrichtigt haben und Sie möchten den Kauf nicht durchführen, wird der Vertrag sofort beendet und wir erstatten Ihnen den vollen Preis für jegliche Produkte, die nicht geliefert wurden.
<G-vec00213-002-s136><end.beenden><en> If you are ending a contract because we have told you about an error in the price of the product you have ordered and you do not wish to proceed the contract will end immediately and we will refund you in full for any products which have not been provided.
<G-vec00213-002-s137><end.beenden><de> Systemkennwort Sie können ein Systemkennwort für die Bedienoberfläche des Gigaset SX762 WLAN dsl zuweisen und die Zeitdauer angeben, nach der eine Sitzung automatisch beendet wird, wenn keine Eingabe mehr vorgenommen wurde.
<G-vec00213-002-s137><end.beenden><en> System Password You can assign a System Password for the configuration environment of your Gigaset SE551 WLAN dsl/cable, and specify the period after which a session is to end automatically if no further entry is made.
<G-vec00213-002-s138><end.beenden><de> Während die Veranstaltung, an der auch entlassene Akademiker und der Abgeordnete der CHP Ankara, Murat Emir, teilnahmen, kamen Polizisten der Schnellen Eingreiftruppe auf den Cebeci-Campus und sagte, die Veranstaltung solle auf Anordnung des Rektors der Universität Ankara beendet werden.
<G-vec00213-002-s138><end.beenden><en> According to the news appeared in press, while the activity was going on with participation of the expelled academics and CHP Ankara MP Murat Emir, riot police came to Cebeci Campus and told the students to end the activity.
<G-vec00213-002-s139><end.beenden><de> Die Menopause ist der Zeitpunkt der letzten spontanen Menstruation im Leben einer Frau, womit auch die Fruchtbarkeit der Frau beendet ist.
<G-vec00213-002-s139><end.beenden><en> Menopause: a term used to describe the permanent cessation of the primary functions of the human ovaries, signalling the end of the fertile phase of a woman's life.
<G-vec00213-002-s140><end.beenden><de> In Florda, Georgia, North Carolina und Kalifornien ist die Saison so gut wie beendet.
<G-vec00213-002-s140><end.beenden><en> With the end of the season in California, the price is also on a falling trend.
<G-vec00213-002-s141><end.beenden><de> 15 Am Programmende Wenn das Programm beendet ist, leuchtet die Kontrolllampe „Programmende“ und das Display zeigt 0 an.
<G-vec00213-002-s141><end.beenden><en> ENGLISH At the end of the programme The display shows 0 and the end indicator comes on.
<G-vec00213-002-s142><end.beenden><de> Ohne Assads Abgang werden weder der Krieg beendet noch die Flüchtlingswelle gestoppt werden.
<G-vec00213-002-s142><end.beenden><en> Unless Assad goes, neither the war nor the wave of refugees will end.
<G-vec00213-002-s143><end.beenden><de> 1928: Jørgen Jørgensen entschließt sich zur Gründung eines eigenen Unternehmens und beendet seine Teilhaberschaft an Polar.
<G-vec00213-002-s143><end.beenden><en> 1928 - Jørgen Jørgensen decides to start up for himself and end the cooperation in Polar.
<G-vec00213-002-s144><end.beenden><de> Diese werden mit "/*" eingeleitet und "*/" beendet.
<G-vec00213-002-s144><end.beenden><en> They are initiated with "/*" and end with "*/".
<G-vec00213-002-s145><end.beenden><de> Die Familie Pisoni hat über 3 Jahrhunderte Geschichte hinweg viel Weg zurückgelegt, zwei Weltkriege, eine schwere Wirtschaftskrise in den 30er Jahren des vergangenen Jahrhunderts und eine ebenso schwere Wirtschaftskrise überstanden, die 2007 begonnen hat und noch nicht beendet ist.
<G-vec00213-002-s145><end.beenden><en> The Pisoni family has come a long way, over 3 centuries of history, overcoming two world wars, a serious financial crisis in the 1930s and one that is just as serious, which started in 2007 and has not yet come to an end.
<G-vec00213-002-s146><end.beenden><de> e. Wenn bei Shootout- oder Heads-up-Turnieren die Verbindung aller Spieler an einem Tisch abbricht und/oder alle Spieler für eine große Anzahl an Händen (bei Echtgeld-Turnieren üblicherweise 250 Hände oder mehr) aussetzen, wird das Match beendet und der Spieler mit den meisten Chips rückt in die nächste Runde vor.
<G-vec00213-002-s146><end.beenden><en> e. In Shootout and Heads-Up events, if all players at a table are disconnected and / or sitting out for a large number of hands (typically 250 hands or more in real money tournaments), the match will end and the player with the most chips will advance to the next round.
<G-vec00213-002-s147><end.beenden><de> Beendet ist die Konversation dann, wenn sich aus den Umständen entnehmen lässt, dass der betroffene Sachverhalt abschließend geklärt ist.
<G-vec00213-002-s147><end.beenden><en> The conversation has come to an end once circumstances show that the matter concerned has been dealt with conclusively.
<G-vec00213-002-s148><end.beenden><de> Das Leiden unseres süßen kleinen Babys beendet zu haben, ist unbezahlbar.
<G-vec00213-002-s148><end.beenden><en> To see an end to our sweet little baby’s suffering is priceless.
<G-vec00213-002-s149><end.beenden><de> 1 Und es begab sich, als Jesus diese Gebote an seine zwölf Jünger beendet hatte, ging er von dort weiter, zu lehren und zu predigen in ihren Städten.
<G-vec00213-002-s149><end.beenden><en> 1 And it came to pass, when Jesus had made an end of commanding his twelve disciples, he departed thence to teach and to preach in their cities.
<G-vec00213-002-s150><end.beenden><de> Sobald du die Reihe beendet hast, haben wir insgesamt 34 Maschen, also genauso viele, wie zum Beginn deines Projekts.
<G-vec00213-002-s150><end.beenden><en> At the end of the row, we will have a total of 34 stitches, the same number as when we started the project.
<G-vec00213-002-s151><end.beenden><de> Dieser Tag bleibt uns immer im Gedächtnis, er beendet unseren Ritt zu Ehren des Kampfes am Little Big Horn 2014.
<G-vec00213-002-s151><end.beenden><en> This is day that always remind us, it is the end of riding horse for the little Big Horn Memorial Horse Ride 2014.
<G-vec00213-002-s057><finalize.beenden><de> Um Ihre Käufe abzuschließen, können Sie einfachen Schritten gerade folgen um Ihren Auftrag abzuschließen und zu beenden.
<G-vec00213-002-s057><finalize.beenden><en> To make your purchases, you can just follow simple steps to complete and finalize your order.
<G-vec00213-002-s171><finish.beenden><de> Wiederhole von * bis * und beende die Reihe mit einem Stäbchen.
<G-vec00213-002-s171><finish.beenden><en> Repeat from * to * and finish the row with a double crochet.
<G-vec00213-002-s172><finish.beenden><de> Beende den Stern, indem du eine diagonale Linie nach links unten zeichnest, die im Startpunkt des umgedrehten Vs endet.
<G-vec00213-002-s172><finish.beenden><en> Finish your star by drawing a diagonal line downward and to the left to meet the starting point of the upside-down “V.”
<G-vec00213-002-s173><finish.beenden><de> “Und Ich möchte, dass du singst und beende auch jenes Lied.
<G-vec00213-002-s173><finish.beenden><en> “And I want you to sing and finish that song as well.
<G-vec00213-002-s174><finish.beenden><de> Beginne mit deiner Bestellung auf einem Gerät und beende sie auf einem anderen.
<G-vec00213-002-s174><finish.beenden><en> Start your order on one device and finish it on another.
<G-vec00213-002-s175><finish.beenden><de> Ich beende meinen Rundgang mit der Kontrolle der Objekte in der Wechselausstellung.
<G-vec00213-002-s175><finish.beenden><en> I finish my round by checking on the objects in the temporary exhibition.
<G-vec00213-002-s176><finish.beenden><de> Beende ein Match backstage.
<G-vec00213-002-s176><finish.beenden><en> Finish a match backstage.
<G-vec00213-002-s177><finish.beenden><de> Beende 4 Minispiele hintereinander ohne Überspringen.
<G-vec00213-002-s177><finish.beenden><en> Finish 4 Minigames in a row without skipping.
<G-vec00213-002-s178><finish.beenden><de> 40 Leichter Schlaf Beende einen Traumkampf in unter einer Minute.
<G-vec00213-002-s178><finish.beenden><en> 40 Light Sleeper Finish a Dream Battle in under 1 minute.
<G-vec00213-002-s179><finish.beenden><de> Bitte beende deine Bestellung bald.
<G-vec00213-002-s179><finish.beenden><en> Please finish your order soon.
<G-vec00213-002-s180><finish.beenden><de> Beende das Tutorial.
<G-vec00213-002-s180><finish.beenden><en> Finish the tutorial level.
<G-vec00213-002-s181><finish.beenden><de> Beende deine Rasur mit einem After Shave zur Feuchtigkeitsversorgung oder mit einer Lotion, die deine Haut erfrischt und die beim Rasieren verloren gegangene Feuchtigkeit wieder auffüllt.
<G-vec00213-002-s181><finish.beenden><en> Finish up your shave with a moisturizing after shave gel or lotion that refreshes your skin and replenishes moisture to leave your skin feeling more comfortable.
<G-vec00213-002-s182><finish.beenden><de> Beende alle Aufgaben, um alle Dekorationen und Tiere für den Heißluftballon zu erhalten.
<G-vec00213-002-s182><finish.beenden><en> Finish all tasks to earn all the decorations and animals for the hot air balloon.
<G-vec00213-002-s183><finish.beenden><de> Beende 40 verschiedene Kapitel der Horizon-Story.
<G-vec00213-002-s183><finish.beenden><en> Finish 40 different Horizon Story chapters.
<G-vec00213-002-s184><finish.beenden><de> Beende die Abenteuer-Kampagne.
<G-vec00213-002-s184><finish.beenden><en> Finish the Adventure campaign.
<G-vec00213-002-s185><finish.beenden><de> Ich beende dieses Jahr mein Jura-Promotionsstudium an der George-Mason-Universität in Virginia mit den Schwerpunkten Copyright, Patente, Marken, Politik und Ökonomie, außerdem bin ich seit einiger Zeit Herausgeberin des Journal of Law, Economics, and Policy („Zeitschrift des Rechts, der Wirtschaft und Politik“).
<G-vec00213-002-s185><finish.beenden><en> I will finish my JD this year at George Mason, focusing on copyright, patent, trademark, policy, and economics, and have been an editor of the Journal of Law, Economics, and Policy.
<G-vec00213-002-s186><finish.beenden><de> Beende "Fernsehsender".
<G-vec00213-002-s186><finish.beenden><en> Finish "TV Station".
<G-vec00213-002-s187><finish.beenden><de> Fang auf deinem iPhone ein E‑Mail an und beende es auf dem iPad.
<G-vec00213-002-s187><finish.beenden><en> Start an email on your iPhone and finish it on iPad.
<G-vec00213-002-s188><finish.beenden><de> Beende die Umarmung auf eine süsse Weise.
<G-vec00213-002-s188><finish.beenden><en> Finish it off in a cute way.
<G-vec00213-002-s189><finish.beenden><de> Wie Ich sagte, Liebes, beende was auf deinem Teller ist.
<G-vec00213-002-s189><finish.beenden><en> As I said, Dear one, finish what’s on your plate.
<G-vec00213-002-s052><halt.beenden><de> Experten sahen die Ergebnisse als Bestrafung der PRI für ihre Korruption und ihre Unfähigkeit die Unsicherheit, sowie die Wirtschaftskrise zu beenden.
<G-vec00213-002-s052><halt.beenden><en> Analysts believe the results were due to a punishment vote against the PRI for its corruption, inability to halt insecurity, and the economic crisis.
<G-vec00213-002-s053><halt.beenden><de> Landökosysteme schützen, wiederherstellen und ihre nachhaltige Nutzung fördern, Wälder nachhaltig bewirtschaften, Wüstenbildung bekämpfen, Bodendegradation beenden und umkehren und dem Verlust der Biodiversität ein Ende setzen.
<G-vec00213-002-s053><halt.beenden><en> Goal 15: Protect, restore and promote sustainable use of terrestrial ecosystems, sustainably manage forests, combat desertification, halt and reverse land degradation and halt biodiversity loss
<G-vec00213-002-s054><halt.beenden><de> Der Bericht enthält auch eine Reihe von Empfehlungen, um die Übergriffe zu beenden und den Schutz der Kinder, die vom bewaffneten Konflikt in der Arabischen Republik Syrien betroffen sind, zu erhöhen.
<G-vec00213-002-s054><halt.beenden><en> Syrian Arab Republic. The report also contains a series of recommendations to halt violations and increase the protection of children affected by the armed conflict in
<G-vec00213-002-s055><halt.beenden><de> Nova muss schnell handeln und diese Verschwörung ein für alle Mal beenden.
<G-vec00213-002-s055><halt.beenden><en> Nova must act quickly to bring the conspiracy to a halt once and for all.
<G-vec00213-002-s056><halt.beenden><de> Wenn Sie einige extreme schädliche Wirkungen erhalten, beenden Sie diese Tablette sofort zu nehmen und auch Ihren Arzt anrufen.
<G-vec00213-002-s056><halt.beenden><en> If you obtain some extreme adverse effects, halt consuming this supplement right away and also contact your doctor.
<G-vec00213-002-s057><halt.beenden><de> Zudem sind Mindeststeuersätze erforderlich, um den Wettlauf um die niedrigsten Steuersätze für Konzerne zu beenden.
<G-vec00213-002-s057><halt.beenden><en> We also need minimum corporate tax rates in order to put a halt to the detrimental downward race in corporate tax rates.
<G-vec00213-002-s058><halt.beenden><de> Und dies ist das große Verdienst der Arbeiterklasse, den Beweis angetreten zu haben, dass sie die große Barriere gegen den Krieg ist und die einzige Kraft, um ihn zu beenden.
<G-vec00213-002-s058><halt.beenden><en> The revolutionary wave which put an end to World War I has provided practical proof that the combat of the working class constitutes the only force able to halt the military barbarity of capitalist decadence, and this society’s only revolutionary force.
<G-vec00213-002-s228><stop.beenden><de> Wenn Sie versuchen, den Dienst manuell starten, wird dieser erfolgreich gestartet und erneut nach ungefähr 30 Sekunden beendet.
<G-vec00213-002-s228><stop.beenden><en> If you attempt to start the service manually, it will successfully start and then stop, again after approximately 30 seconds.
<G-vec00213-002-s229><stop.beenden><de> Jeder Dienst kann so konfiguriert werden, dass er beim Wechsel des Servers in einen dieser Runlevels automatisch startet oder beendet wird.
<G-vec00213-002-s229><stop.beenden><en> Each service or application may be configured to start or stop at certain runlevel.
<G-vec00213-002-s230><stop.beenden><de> Kurz gesagt lautete ihr Argument, dass der Krieg in der Region des Donezbeckens sofort beendet werden müsse, dass Kanzlerin Merkel nicht nur keinen Druck auf die Machthaber in Kiew ausgeübt habe, sondern sie sie weiterhin unterstützt.
<G-vec00213-002-s230><stop.beenden><en> In a nutshell, her argument was that the war in the Donbass region had to stop immediately, yet that Chancellor Merkel not only did not put any pressure on the rulers in Kiev to do so, but that she gave them continued support.
<G-vec00213-002-s231><stop.beenden><de> Teilnehmer hielten Transparente mit Aufschriften wie: „Unterstützt die 100 Millionen Chinesen, die aus der KPCh austraten“, „Die KPCh ist nicht China“, „Löst die KPCh auf und beendet die Verfolgung“.
<G-vec00213-002-s231><stop.beenden><en> Participants held banners that read “Support the 100 Million Chinese Who Quit the CCP”, “The CCP Is Not China”, “Disintegrate the CCP and Stop the Persecution,” etc.
<G-vec00213-002-s232><stop.beenden><de> Unsere erste Empfehlung ist natürlich, dass die Organentnahmen bei Falun Gong-Praktizierenden sofort beendet werden müssen.
<G-vec00213-002-s232><stop.beenden><en> Our first recommendation, of course, is that the harvesting practice from Falun Gong prisoners must stop immediately.
<G-vec00213-002-s233><stop.beenden><de> Schritt 3: Verweis für 24 Stunden mit Benachrichtigung der Eltern/des Schiffes – Sollte das unangemessene Verhalten nicht beendet werden, wird der/die Jugendliche für 24 Stunden vom Jugendzentrum und aus dem Jugendprogramm ausgeschlossen.
<G-vec00213-002-s233><stop.beenden><en> Step 3: 24-Hour Dismissal with Parent/Ship Notification - If the inappropriate behaviour does not stop, he/she will be dismissed from the Teen Centre and Teen Programme for 24 hours.
<G-vec00213-002-s234><stop.beenden><de> Die Praktizierenden riefen alle Menschen auf der ganzen Welt dazu auf, mitzuhelfen, dass die Verfolgung beendet wird und die verfolgten Praktizierenden gerettet werden.
<G-vec00213-002-s234><stop.beenden><en> The practitioners called on people around the world to help stop the persecution and rescue those practitioners being persecuted.
<G-vec00213-002-s235><stop.beenden><de> Der historische Streit zwischen Polen und der Ukraine kann beendet werden.
<G-vec00213-002-s235><stop.beenden><en> It is possible to stop the war of memory between Poland and Ukraine.
<G-vec00213-002-s236><stop.beenden><de> Letzteres beendet gelegentlich aus einem mir unerfindlichen Grund die Animation der Bilder auf dieser Seite.
<G-vec00213-002-s236><stop.beenden><en> The latter will, for some strange reason, stop the animation of the images on this page.
<G-vec00213-002-s237><stop.beenden><de> Nachdem Sie das Sammeln von Daten beendet haben, können Sie die Verteilungspunkte nicht mehr für die Quell- und die Zielhierarchie gemeinsam verwenden.
<G-vec00213-002-s237><stop.beenden><en> After you stop gathering data, you can no longer share distribution points between the source and destination hierarchies.
<G-vec00213-002-s238><stop.beenden><de> Wenn Sie Skripte ausführen oder Softwareprogramme verwenden, die WMI abfragen, verbraucht der Prozess „Wmiprvse.exe“ möglicherweise viele CPU-Ressourcen, auch nachdem Sie das Skript oder die Software beendet haben.
<G-vec00213-002-s238><stop.beenden><en> If you run scripts or use software that queries WMI, the Wmiprvse.exe process may consume a lot of CPU resources even after you stop the script or software.
<G-vec00213-002-s239><stop.beenden><de> Stellen Sie sicher, dass das Hintergrundupdate beendet wird.
<G-vec00213-002-s239><stop.beenden><en> Make sure to stop the background update.
<G-vec00213-002-s240><stop.beenden><de> HINWEISE: Ist ein Bluetooth-Gerät mit dem UE MINI BOOM verbunden, während Audio über eine AUX-Verbindung abgespielt wird, hat das Bluetooth-Gerät Vorrang und der Stream des AUX-Geräts wird beendet.
<G-vec00213-002-s240><stop.beenden><en> NOTE: If a Bluetooth device is connected to the UE ROLL while playing audio from an auxiliary connection, the Bluetooth device will take priority and the stream from the auxiliary device will stop.
<G-vec00213-002-s241><stop.beenden><de> Nur für Keywords zahlen, die wirkungsvoll sind: Wenn Ihre Anzeige mit einer bestimmten Keyword-Variante keine Klicks erhält, beendet das System umgehend die Anzeigenschaltung für diesen und ähnliche Suchbegriffe.
<G-vec00213-002-s241><stop.beenden><en> Spend your money on keywords that work: If your ad receives no clicks on a particular keyword variation, our system will quickly stop showing your ads for that and similar search terms.
<G-vec00213-002-s242><stop.beenden><de> Die Chatfunktion in der Besprechung wird automatisch deaktiviert, bis der F&A-Manager beendet wird.
<G-vec00213-002-s242><stop.beenden><en> The Meeting IM is automatically turned off until you stop the Q&A Manager.
<G-vec00213-002-s243><stop.beenden><de> Lavendel wird im Sommer geerntet, in den frühen Morgenstunden oder spät am Nachmittag, wenn die Bienen ihre Sammelflüge beendet haben.
<G-vec00213-002-s243><stop.beenden><en> Lavender is harvested in the summer, at dawn or late afternoon when the bees stop collecting nectar.
<G-vec00213-002-s244><stop.beenden><de> Wenn Sie die Maustaste loslassen, wird der Strich beendet.
<G-vec00213-002-s244><stop.beenden><en> Each time you release the mouse button, you stop drawing a stroke.
<G-vec00213-002-s245><stop.beenden><de> Der Kampf gegen veraltete Bräuche, gegen überkommene Traditionen und Regeln, die durch religiöse Ideologie bestimmt werden, ist mit dem Sieg der sozialistischen Weltrevolution noch lange nicht beendet.
<G-vec00213-002-s245><stop.beenden><en> The struggle against outdated customs, traditions, norms and religious ideology will not stop after the victory of the socialist world revolution.
<G-vec00213-002-s246><stop.beenden><de> Wir rufen alle gutherzigen Menschen auf der ganzen Welt auf, mitzuhelfen, dass die Verfolgung von Dafa-Praktizierenden durch die Kommunistische Partei Chinas (KPChs) schnell beendet wird.
<G-vec00213-002-s246><stop.beenden><en> We are calling for kind-hearted people around the world to help quickly stop the persecution of Falun Gong practitioners by the Chinese Communist Party (CCP).
<G-vec00365-002-s088><kill.beenden><de> Wenn du die Prozesse, die du beenden möchtest, ausgewählt hast, klicke auf Prozess beenden.
<G-vec00365-002-s088><kill.beenden><en> Once you've selected the processes you would like to end, click Kill process.
<G-vec00365-002-s089><kill.beenden><de> Bitte schließen oder beenden Sie einige Apps, um Speicherplatz frei zu machen.
<G-vec00365-002-s089><kill.beenden><en> Please close or kill some Apps to release memory.
<G-vec00365-002-s090><kill.beenden><de> Die Zuweisung des Status „Kritisch“ für einen Prozess bedeutet, dass das Programm über erkannte Bedrohungen in solchen Prozessen nur informiert, ohne sie automatisch zu beenden.
<G-vec00365-002-s090><kill.beenden><en> When a process is given ”critical” status, it means that the application will notify you about threats detected in these processes, but will not kill them automatically.
<G-vec00365-002-s091><kill.beenden><de> Pan muss daran gehindert werden, einen weiteren Fluch auf die Bewohner Storybrookes loszulassen, der das Leben von jedem in der Stadt beenden könnte.
<G-vec00365-002-s091><kill.beenden><en> The race is on to stop Pan from enacting another curse on the residents of Storybrooke, which could kill every living soul in town.
<G-vec00365-002-s092><kill.beenden><de> Entsprechend Avi Schroeder, kann einer der Forscher, die neuen nanoparticles kleine Proteine entbinden, um Krebszellen zu zerstören und kann größere Proteine auch entbinden wie Antikörper, die das Immunsystem anregen, um Tumoren zu beenden.
<G-vec00365-002-s092><kill.beenden><en> According to Avi Schroeder, one of the researchers, the novel nanoparticles can deliver tiny proteins to destroy cancer cells and can also deliver larger proteins like antibodies that stimulate the immune system to kill tumors.
<G-vec00365-002-s093><kill.beenden><de> Cytotoxische t-Zellen beenden Zellen direkt, die mit einem Krankheitserreger infiziert werden.
<G-vec00365-002-s093><kill.beenden><en> Cytotoxic T cells kill cells directly that are infected with a pathogen.
<G-vec00365-002-s094><kill.beenden><de> Manchmal führen diese Veränderungen möglicherweise Bakterien, gegen Antibiotika beständig zu werden, die verwendet werden, um sie zu beenden.
<G-vec00365-002-s094><kill.beenden><en> Sometimes these mutations may lead bacteria to become resistant to antibiotics that are used to kill them.
<G-vec00365-002-s095><kill.beenden><de> Wenn dein PC länger benötigt, um Diablo III zu starten, setze diesen Wert (oder die sogenannte "grace period") entsprechend höher, ansonsten wird das Tool den Diablo III Prozess immer wieder beim Starten schon beenden.
<G-vec00365-002-s095><kill.beenden><en> If your PC takes longer to start Diablo III, you'll have to set this value (or the grace period) higher, or the tool will kill the Diablo III process in an infinite loop.
<G-vec00365-002-s096><kill.beenden><de> Mit diesem Menü lassen sich Thread-Prioritäten ändern und Teams zum Beenden zwingen oder debuggen.
<G-vec00365-002-s096><kill.beenden><en> This menu allows you to change thread priorities, kill teams or debug them.
<G-vec00365-002-s097><kill.beenden><de> Er kommt, um mich zu töten und das zu beenden, was wir angefangen haben: euch bis zum Letzten auszulöschen und euren Planeten zu annektieren.
<G-vec00365-002-s097><kill.beenden><en> He's come to kill me and do what we didn't: kill you all to the last and annex your planet.
<G-vec00365-002-s098><kill.beenden><de> Weil nanofactories konstruiert werden, um Nachrichtenübermittlung zu beeinflussen, anstatt zu versuchen, die Bakterien zu beenden, konnten sie helfen, Krankheit zu behandeln, in den Fällen wo eine Spannung von Bakterien gegen Antibiotika beständig geworden ist.
<G-vec00365-002-s098><kill.beenden><en> Because nanofactories are designed to affect communication instead of trying to kill the bacteria, they could help treat illness in cases where a strain of bacteria has become resistant to antibiotics.
<G-vec00376-002-s106><discontinue.beenden><de> Intel empfiehlt, dass Benutzer von Realtek * Audiotreiber für Windows 7 * für PC-Mainboards 6.0.1.7240 deinstallieren und/oder die Nutzung so schnell wie möglich beenden.
<G-vec00376-002-s106><discontinue.beenden><en> Intel recommends that users of Realtek* Audio Driver for Windows 7* for Desktop Boards 6.0.1.7240 uninstall and/or discontinue use as soon as possible.
<G-vec00376-002-s107><discontinue.beenden><de> Intel empfiehlt, dass Benutzer von Realtek *-Audiotreibern für Windows 7 * für ältere PC-Mainboards 6.0.1.6804 deinstallieren und/oder die Nutzung so schnell wie möglich beenden.
<G-vec00376-002-s107><discontinue.beenden><en> Intel recommends that users of Realtek* Audio Driver for Legacy Desktop Boards 6201 uninstall and/or discontinue use as soon as possible. Purpose
<G-vec00376-002-s108><discontinue.beenden><de> Intel empfiehlt, dass Benutzer von Intel® Gigabit Ethernet-Netzwerk Verbindungs Treiber für Windows XP * für Desktop-Mainboards 18,3 deinstallieren und/oder die Verwendung so schnell wie möglich beenden.
<G-vec00376-002-s108><discontinue.beenden><en> Intel recommends that users of Intel® Gigabit Ethernet Network Connection Driver for Windows Vista* for Desktop Boards 18.4 uninstall and/or discontinue use as soon as possible.
<G-vec00376-002-s109><discontinue.beenden><de> Intel empfiehlt, dass Benutzer von Intel® Quick-Start-Kit für Linux * [Debian *] 2,0 Uninstall und/oder die Nutzung so schnell wie möglich beenden.
<G-vec00376-002-s109><discontinue.beenden><en> Intel recommends that users of Audio Driver for Red Hat* 3 Update 7 for Desktop Boards 2.0 uninstall and/or discontinue use as soon as possible.
<G-vec00376-002-s181><shut.beenden><de> Natürlich können keine neuen Verbindungen hergestellt werden, wenn der Listenerprozess beendet wurde.
<G-vec00376-002-s181><shut.beenden><en> Of course, once the listener has been shut down, new connections can't be made.
<G-vec00376-002-s182><shut.beenden><de> Damit wird verhindert, dass das Betriebssystem Android die Ausführung der App automatisch beendet.
<G-vec00376-002-s182><shut.beenden><en> This is necessary to prevent the app from being automatically shut down by the Android operating system.
<G-vec00376-002-s183><shut.beenden><de> •Festlandchina, welches letztes Jahr seinen legalen Elfenbeinhandel beendet hat, ist weltweit der größte Konsument von Elfenbein.
<G-vec00376-002-s183><shut.beenden><en> •Mainland China, which shut down its legal ivory trade last year, is the world’s largest consumer of ivory.
<G-vec00376-002-s184><shut.beenden><de> Beim Windows 10 Update auf das Fall-Update, kann es vorkommen, dass eine Anwendung beim Herunterfahren nicht ordnungsgemäß beendet wird.
<G-vec00376-002-s184><shut.beenden><en> With the Windows 10 Update to the Fall Update, it can happen that an application does not shut down properly when shutting down.
<G-vec00376-002-s185><shut.beenden><de> Die temporären Cookies werden auf dem Computer des Nutzers gespeichert bis die Verbindung zum Browser beendet wird.
<G-vec00376-002-s185><shut.beenden><en> The temporary cookies are stored on the user's computer until the browser is shut down.
