<G-vec00245-002-s038><occur.anfallen><de> "In diesem Fall müsste die Gebühr jedoch ohne Unterschied bei allen Buchungen anfallen", erklärt Barbara Forster.
<G-vec00245-002-s038><occur.anfallen><en> "If this is the case, the fee would occur at every booking, without distinction", Barbara Forster explains.
<G-vec00245-002-s039><occur.anfallen><de> Bei internationalem Versand können, je nach Bestellwert und Zielland, Kosten für die Einfuhr der Produkte anfallen.
<G-vec00245-002-s039><occur.anfallen><en> Depending on the destination country custom clearance fees may occur.
<G-vec00245-002-s040><occur.anfallen><de> Diese methodische Herangehensweise, die auf der Überlegung basiert, dass die Gesamtkosten des Betriebs einer Industrieausrüstung nicht nur von den anfänglichen Anschaffungskosten abhängen, sondern auch von allen Kosten, die während ihrer gesamten Lebensdauer anfallen, darin eingeschlossen die Entsorgung, erweist sich als eine hervorragende Methode zur Bemessung der Gesamtkosten, indem alle Ausgaben, die getragen werden könnten oder müssen, in eindeutigen und messbaren Größen ermittelt werden.
<G-vec00245-002-s040><occur.anfallen><en> This methodological approach, based on the fact that the total cost of ownership of an industrial equipment does not only depend on the initial purchase costs, but also on all the costs that occur during its entire life cycle – including disposal, represents a great method to measure the total costs, by identifying all expenses that may or must be incurred, in clear and measurable terms.
<G-vec00245-002-s041><occur.anfallen><de> Akquisitionsbezogene nicht geldwirksame Bilanzierungseffekte als Bestandteile des Kaufpreises wie die Wertaufstockung von Vorräten und des Auftragsbestands werden nur im Jahr 2011 anfallen.
<G-vec00245-002-s041><occur.anfallen><en> Acquisition-related non-cash purchase price accounting effects such as step-up on inventory and order backlog will occur in 2011 only.
<G-vec00245-002-s042><occur.anfallen><de> Obwohl in der Praxis schwer einzuschätzen ist, welche Luftbelastung genau anfallen wird, mussten sich Kunden bislang entweder für einen Trockenabscheider, der für das Abscheiden der Stäube und Späne optimiert ist, oder einen speziellen Emulsions- und Ölnebelabscheider entscheiden.
<G-vec00245-002-s042><occur.anfallen><en> Although it is difficult to evaluate which type of air pollution will occur in practice, customers thus far have chosen either a dry separating system optimized for the separation of dust and shavings, or a special coolant and oil mist separator.
<G-vec00245-002-s043><occur.anfallen><de> Im Fall der Nacherfüllung sind wir verpflichtet, alle zum Zweck der Mangelbeseitigung erforderlichen Aufwendungen zu tragen, jedoch nur insofern diese nicht dadurch anfallen, dass die Kaufsache nach einem anderen Ort als dem Erfüllungsort verbracht wurde.
<G-vec00245-002-s043><occur.anfallen><en> In case of rectification of defect we are obligated to bear all expenditures necessary for the purpose of rectification of defect, however only if they did not occur due to the object of sale being placed at a location different from the place of performance.
<G-vec00245-002-s044><occur.anfallen><de> Turniere - Wetten werden anhand der Gesamtanzahl an Karten ausgewertet, die bei einem bestimmten FIFA- oder UEFA-Turnier anfallen.
<G-vec00245-002-s044><occur.anfallen><en> Cards/Bookings markets Tournament – bets settled on total number of bookings that occur within a specified FIFA or UEFA tournament.
<G-vec00245-002-s045><occur.anfallen><de> Zeiten und Tätigkeiten werden da erfasst, wo sie anfallen.
<G-vec00245-002-s045><occur.anfallen><en> Times and activities are recorded as and where they occur.
<G-vec00245-002-s046><occur.anfallen><de> Dabei wird eine Mahngebühr von 67 NOK anfallen.
<G-vec00245-002-s046><occur.anfallen><en> A 67 NOK/SEK or 9 EUR reminder fee will occur.
<G-vec00245-002-s047><occur.anfallen><de> Schlamm- und Sandfänge finden überall in Gebieten Einsatz, in denen viel Schlamm, Sand und/oder Erde anfallen, in die Kanalisation gelangen und zu Verstopfungen führen.
<G-vec00245-002-s047><occur.anfallen><en> Sludge and sand traps are used wherever a lot of sludge, sand and/or soil occur, can enter the sewage system and lead to blockages.
<G-vec00245-002-s048><occur.anfallen><de> Die operativen Anlaufverluste werden damit erst ab Beginn des Geschäftsjahres 2016/17 anfallen.
<G-vec00245-002-s048><occur.anfallen><en> The related operating ramp-up losses will not occur until start of financial year 2016/17.
<G-vec00245-002-s049><occur.anfallen><de> Dabei kann man auch erfahren, wie Holzreste, die im Speditionsalltag anfallen, wirtschaftlich genutzt werden und gleichzeitig ein Beitrag zu den hohen Ansprüchen hinsichtlich der Umweltverträglichkeit des eigenen Tuns geleistet wird.
<G-vec00245-002-s049><occur.anfallen><en> Use can also learn how wood residues that occur in everyday forwarding, are used economically and at the same time contribute to the high demands with regard to the environmental impact of their own actions is done.
<G-vec00245-002-s050><occur.anfallen><de> Bei einem Versand in Länder außerhalb der EU können weitere Kosten wie Zölle oder Steuern anfallen.
<G-vec00245-002-s050><occur.anfallen><en> When shipping to countries outside the EU additional costs like customs or taxes may occur.
<G-vec00245-002-s051><occur.anfallen><de> Wichtig: Solltest du das car2go auĂźerhalb des Geschäftsgebiets parken, können zusätzliche Kosten anfallen.
<G-vec00245-002-s051><occur.anfallen><en> If you leave your car2go outside the Home Area, additional costs may occur.
<G-vec00245-002-s052><occur.anfallen><de> Du unterstützt Dennis und Annette bei allen Tätigkeiten, die in der kleinen, einfachen Anlage anfallen.
<G-vec00245-002-s052><occur.anfallen><en> You will, in short, support Dennis and Annette in all activities that occur in the small, simple system.
<G-vec00245-002-s053><occur.anfallen><de> Die Zeiterfassung von Projektron BCS berücksichtigt auch Aufgaben, die außerhalb der Projektarbeit anfallen.
<G-vec00245-002-s053><occur.anfallen><en> Time recording in Projektron BCS even considers tasks which occur beyond the scope of project work.
<G-vec00245-002-s054><occur.anfallen><de> Dazu werten die Wissenschaftler alle Prozesse aus, die in der Automobil- und Zulieferindustrie anfallen und entwickeln daraus resultierend Konzepte zur Nutzung solarer Wärme.
<G-vec00245-002-s054><occur.anfallen><en> To achieve this, they have to evaluate all processes that occur for the automotive industry and their components suppliers and develop concepts for the use of solar thermal heat.
<G-vec00245-002-s055><occur.anfallen><de> Der Magnetascheider dient dem Schutz Ihrer Anlagen vor Metallteilen, welche beim Hackerprozess anfallen und Verunreinigung, Funkenflug oder Explosionen verursachen können.
<G-vec00245-002-s055><occur.anfallen><en> The magnetic separator serves to protect your system from the metal bits that can occur during the hacker process and cause contamination, sparks or explosions.
<G-vec00245-002-s056><occur.anfallen><de> Zur Deckung höchster Kühl - oder Heizlastanforderungen, wie sie in Ausnahmefällen bei einer Sondernutzung von Gebäudeteilen oder besonderen Zweckbauten anfallen können, ist eine ergänzende Anordnung von Wärmepumpen und Plattenwärmetauschern eine ökologisch wie ökonomisch zu empfehlende Anlagenerweiterung.
<G-vec00245-002-s056><occur.anfallen><en> In order to cover the highest heating or cooling requirements, as can occur in exceptional cases through the special use of parts of a building or particular functional buildings, a complementary alignment of heat pumps and plate heat exchangers is recommended for both ecological and economical reasons.
<G-vec00258-002-s019><arise.anfallen><de> Der Kunde anerkennt, dass akkawi.ch im Falle einer Betreibung mit einem Inkassobüro zusammenarbeitet und, dass dabei zusätzliche Kosten für den Auftraggeber anfallen.
<G-vec00258-002-s019><arise.anfallen><en> The customer acknowledges that akkawi.ch cooperates with a collection office in the event of an operation and that additional costs arise for the client.
<G-vec00258-002-s020><arise.anfallen><de> Die Kosten für Wasser, Müllabfuhr, Poolreinigung etc., die während der Mietzeit anfallen, sind grundsätzlich Bestandteil des Mietzinses.
<G-vec00258-002-s020><arise.anfallen><en> Expenses for water, waste disposal, pool cleaning etc., which arise during the lease period, are in general part of the lease amount.
<G-vec00258-002-s021><arise.anfallen><de> Ich selbst betreue die Trainings, die im Rahmen von globalen Projekten anfallen.
<G-vec00258-002-s021><arise.anfallen><en> I myself oversee the training needs that arise from global projects.
<G-vec00258-002-s022><arise.anfallen><de> Die selbst produzierte Energie wird außerdem effizienter genutzt, da hier keine Transportverluste anfallen.
<G-vec00258-002-s022><arise.anfallen><en> Moreover, the self-produced energy is used more efficiently since no losses in transit arise.
<G-vec00258-002-s023><arise.anfallen><de> Dank der vollumfänglichen Integration werden zusätzliche Immissionen und Kosten, welche sonst durch den Transport des Verpackungsmaterials an den Abfüllungsort anfallen würden, vermieden.
<G-vec00258-002-s023><arise.anfallen><en> Thanks to the full integration, additional emissions and costs that would necessarily arise from the transport of the packaging materials to the filling plant are avoided.
<G-vec00258-002-s024><arise.anfallen><de> Sollten höhere Kosten anfallen, kann die Lieferbibliothek zunächst einen Kostenvoranschlag schicken.
<G-vec00258-002-s024><arise.anfallen><en> If higher costs arise, the delivering library may initially send a cost estimate.
<G-vec00258-002-s025><arise.anfallen><de> Im Versand sollen bei Rechnungsschreibung automatisch die Frachtkosten ermittelt werden, welche für die Sendung anfallen, bis sie den Warenempfänger erreicht.
<G-vec00258-002-s025><arise.anfallen><en> In the forwarding department during invoice writing the freight costs shall be calculated automatically, which arise for this delivery until it will reach the goods receiver.
<G-vec00258-002-s026><arise.anfallen><de> An manchen Standorten können zusätzliche Transferkosten anfallen, sollten Sie keinen Bus vor Ort haben.
<G-vec00258-002-s026><arise.anfallen><en> At some locations, additional transfer costs may arise, if you do not have a bus available on-site.
<G-vec00258-002-s027><arise.anfallen><de> Ziel der Software ist es für Beraterinnen von PARTYLITE © Österreich ihre Termine, Adressen und Bestellungen auf EDV-Basis verwalten zu können und damit die "Büro- und Koordinationsarbeiten", die rund um Vorführungen und Bestellungen anfallen zu erleichtern, respektive auf ein Minimum an Zeit herabzusetzen.
<G-vec00258-002-s027><arise.anfallen><en> The aim of the software to enable the advisor of PARTYLITE © Austria to organize their dates, addresses and orders on EDP basis, in order to spend a minimum of time on office and coordination task. Which arise during exhibitions and orders, thus making the task easier and much quicker to execute.
<G-vec00258-002-s028><arise.anfallen><de> Schmutz und Gerüche, die tagtäglich anfallen, sind mit diesem Set ruckzuck erledigt.
<G-vec00258-002-s028><arise.anfallen><en> Dirt and odours that arise every day are quickly removed with this set.
<G-vec00258-002-s029><arise.anfallen><de> Hierzu zählen insbesondere Dienstleistungen, die im Rahmen einer (beabsichtigten) Zuwanderung nach Deutschland anfallen.
<G-vec00258-002-s029><arise.anfallen><en> These include, in particular, services that arise in connection with (intended) immigration to Germany.
<G-vec00258-002-s030><arise.anfallen><de> Sie werden vielmehr dort entlastet, wo Routinetätigkeiten anfallen und erhalten mehr Raum für die Aufgaben, die Kreativität und Ideenreichtum erfordern.
<G-vec00258-002-s030><arise.anfallen><en> Rather, they are relieved where routine tasks arise and are given more room for tasks that require creativity and inventiveness.
<G-vec00258-002-s031><arise.anfallen><de> In unserem Vereinssitz nahm er an der Jahresversammlung teil und arbeitete mit Rudolf an den Finanzen und anderen Aufgaben, die jedes Jahr um diese Zeit anfallen.
<G-vec00258-002-s031><arise.anfallen><en> At the seat of our association he took part at our annual meeting and worked with Rudolf on the finances and other tasks that arise every year around this time.
<G-vec00258-002-s032><arise.anfallen><de> Alle Nebentätigkeiten, die während des Umzugs anfallen, können Sie natürlich auch selbst durchführen.
<G-vec00258-002-s032><arise.anfallen><en> You can of course carry out all secondary activities that arise during the move yourself.
<G-vec00258-002-s033><arise.anfallen><de> Bei der B2C-Werbung ist der Werbetreibende verpflichtet anzugeben, ob Versandkosten anfallen und wie hoch diese sind.
<G-vec00258-002-s033><arise.anfallen><en> In B2C advertising, the advertiser is obligated to indicate whether shipping costs will arise and how high these will be.
<G-vec00258-002-s034><arise.anfallen><de> Bei Umbuchungen oder Änderungen einer Buchung können Gebühren anfallen.
<G-vec00258-002-s034><arise.anfallen><en> Fees may arise upon changes to bookings.
<G-vec00258-002-s035><arise.anfallen><de> Dabei muss jedoch bedacht werden, dass bei Letzteren über die gesamte Betriebsdauer die Kosten für die Primärenergieträger, d. h. Kohle oder Erdgas, anfallen.
<G-vec00258-002-s035><arise.anfallen><en> However, one should bear in mind that costs for the latter’s primary energy carrier, i.e. coal or natural gas, arise throughout the plant's entire operating time.
<G-vec00272-002-s038><apply.anfallen><de> Je nach Tarif können Stornokosten oder Umbuchungsgebühren anfallen.
<G-vec00272-002-s038><apply.anfallen><en> Depending on the rate, cancellation charges or alteration fees may apply.
<G-vec00272-002-s039><apply.anfallen><de> Es können Datengebühren anfallen.
<G-vec00272-002-s039><apply.anfallen><en> * Data fees may apply.
<G-vec00272-002-s040><apply.anfallen><de> Bei Buchung von mehr als 5 Zimmern könnten andere Buchungsbestimmungen gelten und zusätzliche Gebühren anfallen.
<G-vec00272-002-s040><apply.anfallen><en> 1 than 5 rooms, different policies and additional supplements may apply.
<G-vec00272-002-s041><apply.anfallen><de> Zusätzliche Kosten können für den Lounge-Zugang anfallen, wenn die Gästezahl die zulässige Belegung durch das Mitglied plus einen Gast (einschließlich Kindern) übersteigt.
<G-vec00272-002-s041><apply.anfallen><en> Additional charges may apply for Lounge Access where the guest count is greater than the Member plus one allowance (including children).
<G-vec00272-002-s042><apply.anfallen><de> Im Laufe der Zeit können Gebühren des Internetdienstanbieters anfallen und zusätzliche Anforderungen für Updates erforderlich sein.
<G-vec00272-002-s042><apply.anfallen><en> ISP fees may apply and additional requirements may apply over time for updates.
<G-vec00272-002-s043><apply.anfallen><de> 5.2 Sie sind für die Entrichtung aller Steuern und sonstigen Abgaben verantwortlich, die im Zusammenhang mit der Softwarelizenz anfallen.
<G-vec00272-002-s043><apply.anfallen><en> 5.2 You are responsible for the payment of any taxes or other duties which may apply in connection with this software license.
<G-vec00272-002-s044><apply.anfallen><de> Bitte beachten Sie, dass für Buchungen ab 6 Zimmern abweichende Hotelrichtlinien gelten und gegebenenfalls zusätzliche Gebühren anfallen.
<G-vec00272-002-s044><apply.anfallen><en> Please note that for reservation of more than 5 rooms, different policies and additional supplements may apply.
<G-vec00272-002-s045><apply.anfallen><de> Der drahtlose Zugriff auf das Internet erfordert eine Basisstation oder einen anderen drahtlosen Zugangspunkt sowie Internetzugang (hierfür können Gebühren anfallen).
<G-vec00272-002-s045><apply.anfallen><en> Wireless Internet access requires AirPort Card, AirPort Base Station, and Internet access (fees may apply).
<G-vec00272-002-s046><apply.anfallen><de> Hinweis: Unabhängig von der Methode Ihrer Buchungsänderung, kann zusätzlich noch eine Änderungsgebühr laut Tarifbedingungen anfallen.
<G-vec00272-002-s046><apply.anfallen><en> Note: to change a booking via any method, a change fee may apply depending on the fare type purchased.
<G-vec00272-002-s047><apply.anfallen><de> Preis basiert auf 8 Gäste Bei mehr als 8 Gästen kann eine Extra Gebühr anfallen.
<G-vec00272-002-s047><apply.anfallen><en> Price based on 8 guests In case there are more than 8 guests an extra fee per guest may apply
<G-vec00272-002-s048><apply.anfallen><de> Bei Einzelbelegung kann zusätzlich ein Einzelzimmeraufschlag anfallen.
<G-vec00272-002-s048><apply.anfallen><en> For single occupancy an additional single room surcharge may apply.
<G-vec00272-002-s049><apply.anfallen><de> Abhängig von Ihrer bevorzugten Zahlungsmethode kann ein Zahlungszuschlag anfallen.
<G-vec00272-002-s049><apply.anfallen><en> Depending on your preferred method of payment, a payment surcharge may apply.
<G-vec00272-002-s050><apply.anfallen><de> Mehr zeigen Weniger anzeigen AGB Gäste müssen die Unterkunft im Voraus über ihre voraussichtliche Ankunftszeit unterrichten und darüber, ob ein Boottransfer benötigt wird (Extragebühren können anfallen).
<G-vec00272-002-s050><apply.anfallen><en> Show more Show less Policies Guests are required to inform the property in advance of their estimated time of arrival and whether guests require a boat transfer (surcharges may apply) prior to arrival via the Special Request box or contact the property directly.
<G-vec00272-002-s051><apply.anfallen><de> Falls Sie aus dem Ausland anrufen, wählen Sie bitte +353 1 436 9080 (entsprechende Auslandskosten können anfallen).
<G-vec00272-002-s051><apply.anfallen><en> If you are calling from outside of Belgium, use the following telephone number: 00353 1 436 9006 (International call charges may apply).
<G-vec00272-002-s052><apply.anfallen><de> Bei Bestellungen außerhalb der EU können Kosten bei der Verzollung anfallen.
<G-vec00272-002-s052><apply.anfallen><en> For orders outside the EU, fees may apply for the customs clearance.
<G-vec00272-002-s053><apply.anfallen><de> Bei einer Lieferung in andere Länder als Deutschland, Österreich, Schweiz, Liechtenstein, Niederlande, Belgien, Vereinigtes Königreich, Irland, Frankreich, Italien, Polen, Tschechische Republik, Dänemark und Schweden können zusätzlich Steuern, Zölle und/oder Kosten anfallen, die nicht in den Preisen berücksichtigt sind.
<G-vec00272-002-s053><apply.anfallen><en> For a delivery in other countries as Germany, Austria, Switzerland, Liechtenstein, the Netherlands, Belgium, UK, Ireland, France, Italy, Poland, Czech Republic, Denmark and Sweden also taxes, duties and / or charges may apply that are not in are taken into account the prices.
<G-vec00272-002-s054><apply.anfallen><de> Lieferung außerhalb der EU: Wir machen Sie darauf aufmerksam, bei einer Lieferung an eine Lieferanschrift außerhalb der Europäischen Union noch weitere Zollgebühren oder weitere Kosten anfallen können.
<G-vec00272-002-s054><apply.anfallen><en> Delivery outside the EU: We draw your attention, with a delivery to a delivery address outside the European Union still may apply for additional customs fees or other costs.
<G-vec00272-002-s055><apply.anfallen><de> Beim Kauf einer Lizenz zur Nutzung und zum Download bestimmter Inhalte von einer Website können zusätzlich zu den oben genannten Standarddatenkosten weitere Gebühren anfallen („Zusätzliche Gebühren“).
<G-vec00272-002-s055><apply.anfallen><en> When purchasing a licence to use and download certain Content from a Site charges in addition to the standard data charges referred to above may apply to such Content (“Additional Charges”).
<G-vec00272-002-s056><apply.anfallen><de> Amtrak erhebt keine Änderungsgebühr für die Fahrkarte, allerdings können andere Gebühren anfallen.
<G-vec00272-002-s056><apply.anfallen><en> Amtrak doesn't charge a ticket change fee, but other fees may apply.
<G-vec00441-002-s038><attack.anfallen><de> Petit Mal schließt kurzzeitige Ausfälle des Bewusstseins ein und mehr als 70% der Patienten haben ihren ersten Anfall vor ihrem zwanzigsten Lebensjahr.
<G-vec00441-002-s038><attack.anfallen><en> Petit Mal involves momentary lapses of awareness and more than seventy percent (70%) of patients have their first attack before the age of twenty.
<G-vec00441-002-s039><attack.anfallen><de> Zu Anfang hatte ich nicht genügend Energie und als ich einen Anfall bekam, hatte ich Tränen in den Augen und meine Nase lief.
<G-vec00441-002-s039><attack.anfallen><en> At first, I did not have enough energy, and when I had an attack, I had tears in my eyes and a runny nose.
<G-vec00441-002-s040><attack.anfallen><de> Bruder Lee verordnete der Äbtissin eine Beruhigungspille, da sie einen Anfall von Atemnot und Schüttelkrämpfen bekam, den Bruder Chan in einer Ausrede als wilden fehlgeschlagenen Kung Fu Stunt bezeichnete.
<G-vec00441-002-s040><attack.anfallen><en> Brother Lee prescribed a sedative pill for the abbess, for she had an attack of breathlessness and convulsions, brother Chan served as excuse a wild, failed Kung Fu stunt.
<G-vec00441-002-s041><attack.anfallen><de> Unter den Zuschauern befinden sich viele noch sehr junge Mädchen, die mit jedem weiteren Musiker auf der Bühne einen weiteren, leicht hysterischen Anfall bekommen: „Bye Bye Beautiful“ dröhnt aus den Lautsprechern, und die Band legt einen Blitzstart hin.
<G-vec00441-002-s041><attack.anfallen><en> There are many still very young girls in the audience who get another slightly hysterical attack with each further musician on the stage: “Bye Bye Beautiful” booms out of the boxes and the band makes an instant start.
<G-vec00441-002-s042><attack.anfallen><de> Doch sehr überraschend verstarb sie eines Nachts – vermutlich an einem epileptischen Anfall.
<G-vec00441-002-s042><attack.anfallen><en> However very surprisingly she died one night - assumingly from an epileptic attack.
<G-vec00441-002-s043><attack.anfallen><de> Infolge der körperlichen und psychischen Folter erlitt Wang Hongde etwa im Dezember 2002 einen Anfall von Herzkrankheit und fiel ins Koma.
<G-vec00441-002-s043><attack.anfallen><en> Around December 2002, Mr. Wang suffered a heart attack as a result of the torture. He fell into a coma.
<G-vec00441-002-s044><attack.anfallen><de> Frauen leiden mit größerer Wahrscheinlichkeit als Männer an Müdigkeit im Bezug auf das Herz, wobei 70 % der weiblichen Herzinfarkt-Patienten angeben, dass sie vor dem Anfall extrem müde waren.
<G-vec00441-002-s044><attack.anfallen><en> Women are more likely to experience heart-related fatigue than men, with 70% of female heart attack patients reporting that they’d felt extremely tired before their episode.
<G-vec00441-002-s045><attack.anfallen><de> Antwort: Übermässiger Alkoholkonsum kann einen Anfall von Gicht auslösen.
<G-vec00441-002-s045><attack.anfallen><en> Answer: Excessive alcohol consumption can induce an attack of gout.
<G-vec00441-002-s046><attack.anfallen><de> Nach der Geburt meiner letzten Tochter 1959, hatte ich einen schlimmen Asthma Anfall.
<G-vec00441-002-s046><attack.anfallen><en> After the birth of my last daughter in 1959, I had a severe asthma attack.
<G-vec00441-002-s047><attack.anfallen><de> Als die Frau Dekan eines Tages wieder einen Anfall hatte, gebot das Mädchen im Namen Jesu den finsteren Mächten auszufahren.
<G-vec00441-002-s047><attack.anfallen><en> When one day the woman had another attack the girl commanded the evil power to leave in the name of Jesus.
<G-vec00441-002-s048><attack.anfallen><de> Mit einer prophilaktischen Anwendung von Dolorexa® Tabletten 2x2 gegen seine Kopfschmerzen zunächst 4 Mal wöchentlich, sind in der zweiten Woche fast alle Schmerzen verschwunden, bis Ende der Untersuchung hatte er nur noch einen kurzen Anfall mit der Dauer von 1,5 Stunden.
<G-vec00441-002-s048><attack.anfallen><en> With the prophylactic use of Dolorexa® tablets 2x2, the number of headaches decreased first from 7 to 4, the headaches ceased completely in the second week, till the end of the clinical trial he had only one short attack of 1,5 hours.
<G-vec00441-002-s049><attack.anfallen><de> Das Kind nach dem Anfall schwitzt in der Regel stark und schläft ein, am Morgen kann er im normalen Zustand aufwachen.
<G-vec00441-002-s049><attack.anfallen><en> The child after an attack, as a rule, strongly sweats and falls asleep, in the morning he can wake up in a normal state.
<G-vec00441-002-s050><attack.anfallen><de> Um Migräneanfälle zu lindern, sollte das Medikament so schnell wie möglich eingenommen werden - wenn es während einer Aura eingenommen wird, etwa die Hälfte der Zeit, in der sich der Anfall nicht entwickelt.
<G-vec00441-002-s050><attack.anfallen><en> To relieve migraine attacks, the drug should be taken as soon as possible - if taken during an aura, about half the time the attack does not develop.
<G-vec00441-002-s051><attack.anfallen><de> Außer bei einem sehr leichten Anfall wird der Patient in einem abgedunkelten, ruhigen Einzelzimmer hospitalisiert.
<G-vec00441-002-s051><attack.anfallen><en> Unless the attack is mild, patients are hospitalized in a darkened, quiet, private room.
<G-vec00441-002-s052><attack.anfallen><de> Nach dem Anfall kann das Augenlid auf dieser Seite herunterhängen, oft ist die Pupille verengt.
<G-vec00441-002-s052><attack.anfallen><en> After the attack, the eyelid on the same side as the headache may droop, and the pupil often constricts.
<G-vec00441-002-s053><attack.anfallen><de> Dann entspricht ein hyste- risches Dauersymptom einem Hineinragen dieses zweiten Zustandes in die sonst vom normalen Bewusstsein beherrschte Körperinnervation, ein hysterischer Anfall zeugt aber von einer höheren Organisation dieses zweiten Zustandes und bedeutet, wenn er frisch entstanden ist, einen Moment, in dem sich dieses Hypnoidbewusstsein der gesamten Existenz bemächtigt hat, also einer acuten Hysterie; wenn es aber ein wiederkehrender Anfall ist, der eine Erinnerung enthält, einer Wiederkehr eines solchen.
<G-vec00441-002-s053><attack.anfallen><en> A persistent hysterical symptom therefore corresponds -O to a projection of this second state into a bodily innervation otherwise controlled by the normal consciousness. A hysterical attack gives evidence of a higher organization of this second state, and if of recent origin it signifies a moment in which this hypnoid consciousness gained control of the whole existence, and hence we have an acute hysteria, but if it is a recurrent attack containing a memory we simply have a repetition of the same.
<G-vec00441-002-s055><attack.anfallen><de> Der Anfall war recht schlimm und dauerte ungefähr eine Woche, aber Vincent erholte sich recht schnell und nahm das Malen wieder auf- diesmal entstanden vor allem Kopien von Werken anderer Künstler, einerseits wegen des angeschlagenen Gesundheitszustandes, andererseits wegen des schlechten Wetters.
<G-vec00441-002-s055><attack.anfallen><en> The attack was serious and lasted about a week, but Vincent recovered reasonably quickly and resumed painting--this time mainly copies of other artists' works, due to being confined inside, both because of his mental health and also because of the weather.
<G-vec00441-002-s056><attack.anfallen><de> Es wird angenommen, dass ein solcher Effekt auf die Punkte nicht nur den Anfall der Krankheit, sondern den gesamten Verlauf ihres Verlaufs erheblich erleichtern kann.
<G-vec00441-002-s056><attack.anfallen><en> It is believed that such an effect on the points can significantly ease not only the attack of the disease, but the entire course of its course.
